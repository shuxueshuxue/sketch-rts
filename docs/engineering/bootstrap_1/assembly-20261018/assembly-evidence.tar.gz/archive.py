from pathlib import Path
import json,tarfile,hashlib,sys
r=Path('/workspace/bootstrap-1-assembly-20261018');d=Path('/workspace/bootstrap-1-resume/docs/engineering/bootstrap_1/assembly-20261018');name=sys.argv[1];files=[]
for n in sys.argv[2:]:
 p=r/n;assert p.exists(),p;files.extend([p] if p.is_file() else [x for x in p.rglob('*') if x.is_file()])
files=sorted(set(files));manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};p=d/(name+'.tar.gz')
with tarfile.open(p,'x:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(r)),recursive=False)
with tarfile.open(p) as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]
out={'archive':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':manifest};(d/(name+'.sha256.json')).write_text(json.dumps(out,indent=2)+'\n');print(len(files),p.stat().st_size,out['sha256'])
