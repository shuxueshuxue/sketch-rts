from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-escort-20261018');rows=[]
for d in [Path('/workspace/bootstrap-1-capital-20261018/knight-known-capital-normal'),r/'knight-known-response-normal']:
 result=json.loads((d/'result.json').read_text());source=json.loads((d/'source.json').read_text());events=[json.loads(x) for x in (d/'entities.jsonl').open()]
 deaths=[e for e in events if e['event']=='removal' and e['last']['owner']=='p0' and e['last']['id'].startswith('unit-') and 'expiresTick' not in e['last']]
 births=[e for e in events if e['event']=='birth' and e['entity']['owner']=='p0' and e['entity']['id'].startswith('unit-') and 'expiresTick' not in e['entity']]
 hallEvents=[{'tick':e['tick'],'event':e['event'],'entity':e.get('last',e.get('entity'))} for e in events if e.get('last',e.get('entity'))['owner']=='p0' and e.get('last',e.get('entity'))['kind']=='townHall']
 captured=[u for u in result['remaining'] if u['id'].startswith('unit-p0-') and u['owner']!='p0']
 rows.append({'directory':str(d),'head':source['head'],'startTick':result['startTick'],'resume':source['resume'],'tick':result['tick'],'winner':result['winner'],'naturalComplete':result['naturalComplete'],'permanentDeaths':len(deaths),'nativeUnitsLost':result['stats']['unitsLost']['p0'],'permanentBirthsAfterStart':len(births),'permanentOwnAlive':len([u for u in result['remaining'] if u['owner']=='p0' and 'expiresTick' not in u]),'capturedOriginalSurvivors':captured,'originalDeathsUnderOtherOwner':[e for e in events if e['event']=='removal' and e['last']['id'].startswith('unit-p0-') and e['last']['owner']!='p0'],'hallEvents':hallEvents,'sourceChangedDuringRun':result['sourceChangedDuringRun'],'elapsedMs':result['elapsedMs']})
o={'classification':'Known seed normal regression, not unseen; no acceptance implied by duration or casualties.','results':rows,'initialEquivalence':json.loads((r/'initial-equivalence.json').read_text()),'divergence':json.loads((r/'normal-divergence.json').read_text())};(r/'normal-summary.json').write_text(json.dumps(o,indent=2));print(json.dumps(rows,indent=2))
