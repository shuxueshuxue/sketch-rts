import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{routeTravelTicks}from'/workspace/bootstrap-1-resume/src/shared/route-selection.ts';
import{sameGround}from'/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import{combatCapability}from'/workspace/bootstrap-1-resume/src/shared/combat-capabilities.ts';
const cp=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-capital-20261018/formal-30000/frames/31830.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,cp.snapshot,cp.nextId);const s=snapshotGame(g);
const mines=s.resources.filter(m=>m.amount>0).map(m=>({id:m.id,x:m.x,y:m.y,foes:s.units.filter(u=>u.owner==='p2'&&!u.deck&&u.kind!=='worker'&&combatCapability(s,u).armed&&sameGround(s.map,u,m)).map(u=>({id:u.id,kind:u.kind,ticks:routeTravelTicks(s.map,u,m,'land',u.speed)})).filter(x=>x.ticks!==undefined).sort((a,b)=>a.ticks!-b.ticks!).slice(0,8),own:s.units.filter(u=>u.owner==='p0'&&!u.deck&&u.kind!=='worker'&&combatCapability(s,u).armed&&sameGround(s.map,u,m)).map(u=>u.id)}));writeFileSync('/workspace/bootstrap-1-escort-20261018/response31830.json',JSON.stringify(mines,null,2));console.log(JSON.stringify(mines));
