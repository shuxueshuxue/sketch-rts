import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,issuePlayerCommand,stepGame,snapshotGame} from '../../src/shared/sim';
const frame=JSON.parse(readFileSync('.playtest/coastal-withdrawal/full-match.json.frames/96000.json','utf8'));
const results=[];
for(const mode of ['north','east','west','forward']){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
 const ship=game.units.find(u=>u.id==='unit-p0-transport-1046')!,start={x:ship.x,y:ship.y};
 const commands:any[]=[];

 const targets={north:{x:ship.x,y:ship.y-600},east:{x:ship.x+600,y:ship.y},west:{x:ship.x-600,y:ship.y},forward:{x:ship.x+Math.cos(ship.sailing!.heading)*200,y:ship.y+Math.sin(ship.sailing!.heading)*200}};
 commands.push({type:'move',unitIds:[ship.id],...targets[mode as keyof typeof targets],avoidCombat:true});
 for(const command of commands)issuePlayerCommand(game,'p0',command);
 for(let i=0;i<1200;i++)stepGame(game);
 results.push({mode,commands,ship:{x:ship.x,y:ship.y,hp:ship.hp,displacement:Math.hypot(ship.x-start.x,ship.y-start.y),order:ship.order},lost:game.match.stats.unitsLost.p0});
 writeFileSync(`.playtest/supply-demand/traffic-${mode}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/supply-demand/course-results.json',JSON.stringify({scope:'Ordinary move commands, 1200 native ticks, no AI reassignment in any arm; physical diagnosis only',results},null,2));console.log(JSON.stringify(results));
