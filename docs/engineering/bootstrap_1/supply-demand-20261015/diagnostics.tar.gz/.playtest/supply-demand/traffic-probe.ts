import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,issuePlayerCommand,stepGame,snapshotGame} from '../../src/shared/sim';
const frame=JSON.parse(readFileSync('.playtest/coastal-withdrawal/full-match.json.frames/96000.json','utf8'));
const results=[];
for(const mode of ['control','cutter','land','both']){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
 const ship=game.units.find(u=>u.id==='unit-p0-transport-1046')!,start={x:ship.x,y:ship.y};
 const commands:any[]=[];
 if(mode==='cutter'||mode==='both')commands.push({type:'move',unitIds:['unit-p0-cutter-1251'],x:3800,y:4400,avoidCombat:true});
 if(mode==='land'||mode==='both')commands.push({type:'move',unitIds:['unit-p0-worker-1008','unit-p0-footman-2742','unit-p0-footman-3009','unit-p0-footman-3035'],x:3000,y:4650,avoidCombat:true});
 for(const command of commands)issuePlayerCommand(game,'p0',command);
 for(let i=0;i<1200;i++)stepGame(game);
 results.push({mode,commands,ship:{x:ship.x,y:ship.y,hp:ship.hp,displacement:Math.hypot(ship.x-start.x,ship.y-start.y),order:ship.order},lost:game.match.stats.unitsLost.p0});
 writeFileSync(`.playtest/supply-demand/traffic-${mode}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/supply-demand/traffic-results.json',JSON.stringify({scope:'Ordinary move commands, 1200 native ticks, no AI reassignment in any arm; physical diagnosis only',results},null,2));console.log(JSON.stringify(results));
