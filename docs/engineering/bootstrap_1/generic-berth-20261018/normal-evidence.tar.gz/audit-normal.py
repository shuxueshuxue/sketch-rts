from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-generic-berth-20261018');out=r/'knight-known-generic-berth-normal';base=Path('/workspace/bootstrap-1-capital-20261018/knight-known-capital-normal')
read=lambda p:json.loads(p.read_text());gz=lambda p:json.load(gzip.open(p));rows=lambda p:[json.loads(l)for l in p.read_text().splitlines()]
a,b=read(out/'result.json'),read(base/'result.json');cmd=rows(out/'commands.jsonl');old=rows(base/'commands.jsonl');n=next((i for i,(x,y)in enumerate(zip(cmd,old))if x!=y),min(len(cmd),len(old)))
ini=gz(out/'frames/0.json.gz');origin={u['id']:u for u in ini['snapshot']['units']if u['owner']=='p0'};births=[];halls=[]
for e in rows(out/'entities.jsonl'):
 u=e.get('entity',e.get('last',{}))
 if e['event']=='birth' and u['owner']=='p0' and u['id'].startswith('unit-'):births.append(u);origin[u['id']]=u
 if u['owner']=='p0' and u['kind']=='townHall':halls.append(e)
final={u['id']:u for u in a['remaining']};own=[i for i in origin if i in final and final[i]['owner']=='p0'];captured=[i for i in origin if i in final and final[i]['owner']!='p0'];missing=[i for i in origin if i not in final and origin[i].get('expiresTick') is None];tasks=[]
for p in sorted((out/'frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
 c=gz(p);t=c['memories'].get('p0',{}).get('berthRecovery')
 if t:tasks.append({'tick':c['snapshot']['tick'],'task':t})
report={'implementation':read(out/'source.json')['head'],'startTick':a['startTick'],'endTick':a['tick'],'winner':a['winner'],'naturalComplete':a['naturalComplete'],'sourceChangedDuringRun':a['sourceChangedDuringRun'],'initialStateEquivalent':{k:ini[k]==gz(base/'frames/0.json.gz')[k]for k in ['snapshot','nextId','memories','match']},'commandPrefixEqual':n,'candidateCommandCount':len(cmd),'baselineCommandCount':len(old),'allCommandsEqual':cmd==old,'baselineFinalSnapshotEquivalent':gz(out/f"frames/{a['tick']}.json.gz")==gz(base/f"frames/{b['tick']}.json.gz")if a['tick']==b['tick']else False,'berthCommandCount':sum(x['scriptId']=='berthRecovery'for x in cmd),'taskSamples':tasks,'nativeUnitsLost':a['stats']['unitsLost']['p0'],'initialOwnUnits':len([u for u in ini['snapshot']['units']if u['owner']=='p0']),'births':len(births),'ownSurvivors':len(own),'capturedIds':captured,'permanentMissingIds':missing,'hallEvents':halls,'baseline':{'tick':b['tick'],'winner':b['winner'],'nativeUnitsLost':b['stats']['unitsLost']['p0']}}
(r/'normal-audit.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items()if k not in ['taskSamples','hallEvents','permanentMissingIds']})
