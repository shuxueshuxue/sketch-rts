import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {recordScene} from '/workspace/bootstrap-1-resume/src/recorder/record.ts';
const frame=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const x=Number(process.argv[4]??game.map.width/2),y=Number(process.argv[5]??game.map.height/2),zoom=Number(process.argv[6]??(1000/game.map.width));
const result=await recordScene({name:'restored-native-checkpoint',createGame:()=>game},{seconds:0,fps:1,width:1000,height:800,camera:{type:'fixed',x,y,zoom}},[{write(f){writeFileSync(process.argv[3]!,f.canvas.toBuffer('image/png'),{flag:'wx'});},finish(){}}]);
console.log(JSON.stringify({input:process.argv[2],output:process.argv[3],result}));
