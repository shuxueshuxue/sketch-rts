# 本环境实际对局证据

规则固定2，地图brokenSea，种子bootstrap_1-official-brokenSea-archer-v5-v8-20261016，v9_archer Grove侧0，对冻结v5 Ember及v8 Grove。正常500金、3工人、8人口上限。source.json和每个检查点记录完整match。

- baseline：6266950d源码，从0自然失败54426。
- control-8400：baseline检查点同源码续至9000，完整世界与三方记忆、命令、受击、出生死亡逐项相等。
- candidate-8400：同8400输入换出航候选，18000工程终止，无胜者。
- candidate-ordinary0：固定40026e79真正从0启动；本次因运行变慢主动工程中止，最后完整检查点36000，命令流36030，winner=null；没有result.json，准确状态见interruption.json。不能算胜负。

所有frames/*.json.gz内含snapshot、nextId、三方memories、match。hits.jsonl为原生观察器受击，entities.jsonl为出生/移除，commands.jsonl含版本脚本来源。samples为600tick采样。原生PNG由render.mts调用仓库recordScene，无自制视觉模拟。钱包包含所有收支，不是按矿源的收入账本。

## 重放

应在含指定历史提交对象的仓库工作树运行，保留rulesVersion2；安装package-lock规定的依赖。observe.mts和render.mts导入路径写死本轮工作树/workspace/bootstrap-1-resume；移到其他位置时只在运行器副本替换此前缀。工作目录必须为对应源码版本根目录。冻结规划器会git archive d1ae110f2edd99f9c7d899ed61557891ab587639，不能替换成当前AI。

命令：node_modules/.bin/tsx /路径/observe.mts 新的输出目录 终止tick [完整检查点.json.gz]。省略检查点为正常开局。输出目录必须不存在，避免覆盖。运行时不要编辑src或scripts；result.json记录首尾源文件哈希差异。

源码归档baseline-source-complete.tar.gz、candidate-source.tar.gz和frozen-source.tar.gz分别保留本轮两版本及冻结运行树。早期baseline-source.tar.gz漏带冻结清单，另行保留而不覆盖；使用complete版本。观察器不强行存储内存不足的旧会话资料；旧未提交departure、early-fire及旧原始C4/C6检查点仍未恢复。
