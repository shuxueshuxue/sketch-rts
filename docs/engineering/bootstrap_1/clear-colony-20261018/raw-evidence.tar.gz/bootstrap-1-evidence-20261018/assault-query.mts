import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {planAiOwnerCommandEntries} from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import {assaultExpedition} from '/workspace/bootstrap-1-resume/src/ai/policy/naval.ts';
import {effectiveCombatRating} from '/workspace/bootstrap-1-resume/src/ai/policy/v6/strength.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);
const snapshot=snapshotGame(game), memory=structuredClone(f.memories.p0);
const options={memory,teams:game.teams,version:'v9_archer' as const};
const diagnoses=Object.entries(memory.naval.ferries).filter(([,m]:any)=>m.purpose==='assault').map(([id,m]:any)=>{
 const target=snapshot.buildings.find(b=>b.id===m.targetId)??m.targetGround;
 const expedition=assaultExpedition(snapshot,'p0',options,target);
 const cargo=snapshot.units.filter(u=>u.deck?.shipId===id);
 return {id,mission:structuredClone(m),required:expedition.required,globallyReady:expedition.ready,
   availableCrew:expedition.crew.map(u=>u.id),cargo:cargo.map(u=>({id:u.id,strength:effectiveCombatRating(snapshot,u)})),
   outstanding:m.crewIds.filter((id:string)=>!cargo.some(u=>u.id===id))};
});
const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',source:'external-agent',memory},{teams:game.teams});
console.log(JSON.stringify({input:process.argv[2],tick:snapshot.tick,diagnoses,entries,after:memory.naval.ferries},null,2));
