import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {createAiMemoryProvider} from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/workspace/bootstrap-1-resume/scripts/bootstrap_1-planner.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);
const memories=createAiMemoryProvider();for(const [p,m] of Object.entries(f.memories))memories.set!(p,m as any);
const planner=await createBootstrapCommandPlanner(memories),snapshot=snapshotGame(game);
for(const [owner,agent] of Object.entries(f.match.agents)) {
 console.log(JSON.stringify({phase:'plan-start',owner,tick:game.tick}));
 const before=performance.now();const commands=planner({snapshot,owner,agent:agent as any,source:'external-agent',teams:game.teams});
 console.log(JSON.stringify({phase:'plan-done',owner,ms:performance.now()-before,commands}));
}
for(let i=0;i<15;i++) {const before=performance.now();stepGame(game);console.log(JSON.stringify({phase:'step',tick:game.tick,ms:performance.now()-before}));}
