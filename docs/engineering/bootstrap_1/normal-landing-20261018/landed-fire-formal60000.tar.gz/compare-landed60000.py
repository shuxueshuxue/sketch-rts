from pathlib import Path
import json,gzip,collections
r=Path('/workspace/bootstrap-1-normal-landing-20261018');out={};survivors={}
for name in ['knight-after-boarding','landed-formal55800']:
 d=r/name;f=json.loads(gzip.decompress((d/'frames/60000.json.gz').read_bytes()));s=f['snapshot'];births=collections.Counter();lost={}
 for l in (d/'entities.jsonl').open():
  e=json.loads(l)
  if not 55800<=e['tick']<=60000:continue
  u=e.get('last',e.get('entity',{}))
  if u.get('owner')!='p0' or not u.get('id','').startswith('unit-') or 'expiresTick'in u:continue
  if e['event']=='birth':births[u['kind']]+=1
  else:lost[u['id']]={'tick':e['tick'],'kind':u['kind']}
 own=[u for u in s['units'] if u['owner']=='p0' and 'expiresTick'not in u];survivors[name]={u['id']:u for u in own};out[name]={'totalPermanentLosses':s['match']['stats']['unitsLost']['p0'],'alive':len(own),'newBirths':dict(births),'lostAfter55800':lost,'gold':s['players']['p0']['gold'],'goldSpent':s['match']['stats']['goldSpent']['p0'],'winner':s['match']['winner']}
old=out['knight-after-boarding']['lostAfter55800'];new=survivors['landed-formal55800'];out['originalCasualtiesStillAlive']={id:{k:new[id].get(k) for k in ['kind','hp','maxHp','x','y','level','veteranSkill','order']} for id in old if id in new};out['formalSourceChanged']=json.load(open(r/'landed-formal55800/result.json'))['sourceChangedDuringRun'];(r/'landed-formal-comparison60000.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
