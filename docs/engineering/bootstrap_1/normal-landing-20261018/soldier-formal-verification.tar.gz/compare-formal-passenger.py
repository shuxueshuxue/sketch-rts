from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-normal-landing-20261018');checks=[]
for n in ['formal-passenger22800','formal-passenger24000']:
 for f in sorted((r/n/'frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
  t=int(f.name.split('.')[0]);c='safe-passenger22800' if t<=27000 else 'safe-passenger27000';x=json.loads(gzip.decompress((r/c/'frames'/f.name).read_bytes()));y=json.loads(gzip.decompress(f.read_bytes()));checks.append({'tick':t,**{k:x[k]==y[k] for k in ['snapshot','nextId','memories']}})
def cmds(names):
 return [{k:v for k,v in json.loads(l).items() if k!='scriptId'} for name in names for l in (r/name/'commands.jsonl').read_text().splitlines()]
a=cmds(['safe-passenger22800','safe-passenger27000']);b=cmds(['formal-passenger22800','formal-passenger24000']);out={'frames':checks,'uniqueFrames':len(set(c['tick'] for c in checks)),'failedFrames':[c for c in checks if not all(c[k] for k in ['snapshot','nextId','memories'])],'commands':len(b),'commandsEqualIgnoringScriptLabels':a==b,'sourceChangedDuringRuns':[json.loads((r/n/'result.json').read_text())['sourceChangedDuringRun'] for n in ['formal-passenger22800','formal-passenger24000']]};(r/'formal-passenger-equivalence36000.json').write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='frames'});assert not out['failedFrames'] and a==b
