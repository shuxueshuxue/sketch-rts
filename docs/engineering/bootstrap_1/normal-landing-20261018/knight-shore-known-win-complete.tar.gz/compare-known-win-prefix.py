from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-normal-landing-20261018');a=r/'knight-after-boarding';b=r/'knight-shore-known-win'
rows=[]
for f in sorted((b/'frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
 try:y=json.loads(gzip.decompress(f.read_bytes()))
 except (EOFError,json.JSONDecodeError):continue
 p=a/'frames'/f.name
 if not p.exists():continue
 x=json.loads(gzip.decompress(p.read_bytes()));rows.append({'tick':y['snapshot']['tick'],**{k:x[k]==y[k] for k in ['snapshot','nextId','memories']}})
def commands(p):
 out=[]
 for l in (p/'commands.jsonl').open():
  try:out.append(json.loads(l))
  except json.JSONDecodeError:break
 return out
x,y=commands(a),commands(b);different=None
for i,(u,v) in enumerate(zip(x,y)):
 if {k:a for k,a in u.items() if k!='scriptId'}!={k:a for k,a in v.items() if k!='scriptId'}:different={'index':i,'baseline':u,'after':v};break
out={'sampledFrames':len(rows),'firstDifferentState':next((v for v in rows if not all(v[k] for k in ['snapshot','nextId','memories'])),None),'firstDifferentCommand':different,'lastTick':rows[-1]['tick']};(r/'shore-known-win-prefix-comparison.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
