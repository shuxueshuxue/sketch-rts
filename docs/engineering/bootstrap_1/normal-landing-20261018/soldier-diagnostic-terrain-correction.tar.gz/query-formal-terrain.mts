import {readFileSync,writeFileSync} from 'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import{passengerBoardingSafe as formal}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/worker-boarding.ts';
import{groundRevision as actualRevision}from'/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import{groundRevision as externalRevision}from'./query-draft-terrain.ts';
import{passengerBoardingSafe as draft}from'./passenger-boarding-draft.ts';
const root='/workspace/bootstrap-1-normal-landing-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/formal-passenger24000/frames/30270.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),o={memory:f.memories.p0,teams:g.teams},u=s.units.find(u=>u.id==='unit-p0-footman-4244')!,b=s.units.find(u=>u.id==='unit-p0-transport-1067')!;
const revisionsBefore={actual:actualRevision(s.map),external:externalRevision(s.map)};const before={formal:formal(s,'p0',o,u,b),draft:draft(s,'p0',o,u,b)},entries=planAiOwnerCommandEntries(s,{playerId:'p0',version:'v9_knight',memory:o.memory},{teams:g.teams}),after={formal:formal(s,'p0',o,u,b),draft:draft(s,'p0',o,u,b)};const out={tick:s.tick,revisionsBefore,revisionsAfter:{actual:actualRevision(s.map),external:externalRevision(s.map)},before,after,unit:u,commands:entries.filter(e=>'unitIds'in e.command&&e.command.unitIds.includes(u.id))};writeFileSync(root+'/formal-divergence-terrain30270.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out));
