export {groundRevision, isOpenGround} from '/workspace/bootstrap-1-resume/src/shared/terrain';
