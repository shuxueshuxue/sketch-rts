import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import{safeSoldierBoarding}from'./soldier-boarding-draft.ts';
const root='/workspace/bootstrap-1-normal-landing-20261018',rows=[];
for(const version of ['v9_archer','v9_summoner','v9_knight'] as const){const f=JSON.parse(gunzipSync(readFileSync(root+'/fresh-exact22800/frames/23385.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),o={memory:f.memories.p0,teams:g.teams};const entries=planAiOwnerCommandEntries(s,{playerId:'p0',version,memory:o.memory},{teams:g.teams});const original=entries.map(e=>e.command),after=safeSoldierBoarding(s,'p0',o,original),id='unit-p0-footman-3980';rows.push({version,original:original.filter(c=>'unitIds'in c&&c.unitIds.includes(id)),after:after.filter(c=>'unitIds'in c&&c.unitIds.includes(id)),remainingCrew:o.memory.naval.ferries['unit-p0-transport-1067'].crewIds.includes(id)});}
writeFileSync(root+'/soldier-three-routes.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
