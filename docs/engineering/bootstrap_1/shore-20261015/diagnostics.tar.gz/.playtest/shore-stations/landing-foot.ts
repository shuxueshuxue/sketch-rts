import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,issuePlayerCommand,snapshotGame} from '../../src/shared/sim';
import {isWalkable} from '../../src/shared/terrain';
const saved=JSON.parse(readFileSync('.playtest/shore-stations/final-match.json.frames/48000.json','utf8'));const rows=[];
for(const dy of [80,160,-80]){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const worker=game.units.find(u=>u.id==='unit-p0-worker-1')!,ship=game.units.find(u=>u.id==='unit-p0-transport-1046')!;
 const target={x:worker.x,y:worker.y+dy};
 issuePlayerCommand(game,'p0',{type:'move',unitIds:[worker.id],...target,avoidCombat:true});
 for(let i=0;i<1200;i++)stepGame(game);
 rows.push({dy,walkable:isWalkable(game.map,target.x,target.y),worker:{x:worker.x,y:worker.y,order:worker.order},ship:{x:ship.x,y:ship.y}});
 writeFileSync(`.playtest/shore-stations/landing-foot-${dy}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/shore-stations/landing-foot-results.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
