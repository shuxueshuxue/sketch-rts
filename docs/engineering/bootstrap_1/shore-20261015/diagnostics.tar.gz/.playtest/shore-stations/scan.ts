import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,issuePlayerCommand,snapshotGame} from '../../src/shared/sim';
import {hullFits,planShipRoute} from '../../src/shared/ship-navigation';
import {strikeGap} from '../../src/shared/combat-geometry';
import {beginShipMotionFrame} from '../../src/shared/ship-motion';
import {shipSolidTraffic} from '../../src/shared/ship-collisions';
import {shipTraffic} from '../../src/shared/ship-avoidance';
const saved=JSON.parse(readFileSync('.playtest/resume-20261015/archer-islands-final.json.frames/48000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const result=[];
for(const id of ['unit-p0-warship-1071','unit-p0-warship-1120']){
 const ship=game.units.find(u=>u.id===id)!,target=game.units.find(u=>u.id===('targetId' in ship.order?ship.order.targetId:''))!;
 const points=[];
 for(let d=ship.attackRange-8;d>=ship.attackRange*.6;d-=16)for(let a=0;a<72;a++)for(let h=0;h<16;h++){
 const pose={x:target.x+Math.cos(a*Math.PI/36)*d,y:target.y+Math.sin(a*Math.PI/36)*d,heading:h*Math.PI/8};
 if(hullFits(game.map,ship,pose))points.push({...pose,cost:Math.hypot(pose.x-ship.x,pose.y-ship.y)});
 }
 points.sort((a,b)=>a.cost-b.cost);result.push({id,target:target.id,gap:strikeGap(ship,target),count:points.length,nearest:points.slice(0,6)});
}
writeFileSync('.playtest/shore-stations/scan.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
