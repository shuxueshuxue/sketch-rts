import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,issuePlayerCommand,snapshotGame} from '../../src/shared/sim';
import {sameGround,walkingDistance} from '../../src/shared/terrain';
const saved=JSON.parse(readFileSync('.playtest/shore-stations/final-match.json.frames/48000.json','utf8'));
const rows=[];
for(const [label,x,y] of [['east',9300,7000],['southeast',9300,7500],['northeast',9300,6500]] as const){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const ship=game.units.find(u=>u.id==='unit-p0-transport-1046')!,worker=game.units.find(u=>u.id==='unit-p0-worker-1')!;
 const goal={x:8208,y:7120};const start={ship:{x:ship.x,y:ship.y,hp:ship.hp},worker:{x:worker.x,y:worker.y},same:sameGround(game.map,worker,goal),distance:walkingDistance(game.map,worker,goal)};
 issuePlayerCommand(game,'p0',{type:'move',unitIds:[ship.id],x,y,avoidCombat:true});
 for(let i=0;i<2400;i++)stepGame(game);
 rows.push({label,start,end:{ship:{x:ship.x,y:ship.y,hp:ship.hp,order:ship.order},worker:{x:worker.x,y:worker.y,order:worker.order},halls:game.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall').map(b=>({id:b.id,x:b.x,y:b.y,complete:b.complete}))}});
 writeFileSync(`.playtest/shore-stations/landing-${label}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/shore-stations/landing-manual-results.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
