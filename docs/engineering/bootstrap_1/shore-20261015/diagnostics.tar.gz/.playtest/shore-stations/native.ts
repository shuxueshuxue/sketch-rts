import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,snapshotGame} from '../../src/shared/sim';
import {shoreFiringStation} from '../../src/shared/shore-fire';
const saved=JSON.parse(readFileSync('.playtest/resume-20261015/archer-islands-final.json.frames/48000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const ids=['unit-p0-warship-1071','unit-p0-warship-1120'];
const sample=()=>({tick:game.tick,ships:game.units.filter(u=>ids.includes(u.id)).map(u=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order}))});
console.log(ids.map(id=>{const u=game.units.find(u=>u.id===id)!;const t=game.units.find(t=>t.id===('targetId' in u.order?u.order.targetId:''))!;return {id,target:t.id,station:shoreFiringStation(game,u,t)}}));
const samples=[sample()];for(let i=0;i<2400;i++){stepGame(game);if(game.tick%600===0)samples.push(sample());}
writeFileSync('.playtest/shore-stations/native-results.json',JSON.stringify(samples,null,2));
writeFileSync('.playtest/shore-stations/native-final.json',JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));console.log(JSON.stringify(samples));
