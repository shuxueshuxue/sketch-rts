import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,issuePlayerCommand,snapshotGame} from '../../src/shared/sim';
import {nearestShipPose} from '../../src/shared/ship-navigation';
const saved=JSON.parse(readFileSync('.playtest/resume-20261015/archer-islands-final.json.frames/48000.json','utf8'));
const results=[];
for(const id of ['unit-p0-warship-1071','unit-p0-warship-1120']) {
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const ship=game.units.find(u=>u.id===id)!,target=game.units.find(u=>u.id===('targetId' in ship.order?ship.order.targetId:''))!;
 const start={x:ship.x,y:ship.y,hp:ship.hp,targetHp:target.hp};
 const pose=nearestShipPose(game.map,ship,target)!;
 issuePlayerCommand(game,ship.owner as 'p0',{type:'move',unitIds:[id],x:pose.x,y:pose.y,avoidCombat:true});
 for(let i=0;i<1800;i++)stepGame(game);
 const moved={x:ship.x,y:ship.y,hp:ship.hp,targetHp:target.hp};
 issuePlayerCommand(game,ship.owner as 'p0',{type:'attack',unitIds:[id],targetId:target.id});
 for(let i=0;i<1800;i++)stepGame(game);
 results.push({id,target:target.id,start,pose,moved,end:{x:ship.x,y:ship.y,hp:ship.hp,targetHp:target.hp,order:ship.order}});
 writeFileSync(`.playtest/shore-stations/manual-${id}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/shore-stations/manual-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results));
