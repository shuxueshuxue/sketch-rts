import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,stepGame,snapshotGame} from '../../src/shared/sim';
import {shipCollisionImpactCount} from '../../src/shared/ship-collisions';
const saved=JSON.parse(readFileSync('.playtest/shore-stations/final-match.json.frames/12000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const ships=game.units.filter(u=>u.owner==='p0'&&u.kind==='warship');const rows=[];
for(let i=0;i<2400;i++){
 const hp=ships.map(u=>u.hp);const shots=game.projectiles.map(p=>({...p}));stepGame(game);
 for(const [i,u] of ships.entries())if(u.hp<hp[i]!)rows.push({tick:game.tick,id:u.id,loss:hp[i]!-u.hp,hp:u.hp,x:u.x,y:u.y,impacts:shipCollisionImpactCount(game.units),shots:shots.filter(p=>p.targetId===u.id),near:game.units.filter(t=>t.owner!==u.owner&&Math.hypot(t.x-u.x,t.y-u.y)<700).map(t=>({id:t.id,kind:t.kind,x:t.x,y:t.y,order:t.order})),order:u.order});
 if(ships.every(u=>u.hp<=0))break;
}
writeFileSync('.playtest/shore-stations/loss.json',JSON.stringify(rows,null,2));console.log(JSON.stringify({tick:game.tick,hits:rows.length,first:rows.slice(0,3),last:rows.slice(-3)}));
writeFileSync('.playtest/shore-stations/loss-final.json',JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
