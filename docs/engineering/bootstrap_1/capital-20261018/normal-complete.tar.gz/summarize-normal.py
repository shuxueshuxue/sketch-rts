from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-capital-20261018')
rows=[]
for d in [Path('/workspace/bootstrap-1-normal-landing-20261018/knight-shore-holdout'),r/'knight-known-capital-normal']:
 result=json.loads((d/'result.json').read_text());source=json.loads((d/'source.json').read_text());events=[json.loads(x) for x in (d/'entities.jsonl').open()]
 losses=[e for e in events if e['event']=='removal' and e['last']['owner']=='p0' and e['last']['id'].startswith('unit-') and 'expiresTick' not in e['last']]
 births=[e for e in events if e['event']=='birth' and e['entity']['owner']=='p0' and e['entity']['id'].startswith('unit-') and 'expiresTick' not in e['entity']]
 halls=[{'tick':e['tick'],'event':e['event'],'id':e.get('last',e.get('entity'))['id']} for e in events if e.get('last',e.get('entity'))['owner']=='p0' and e.get('last',e.get('entity'))['kind']=='townHall']
 rows.append({'directory':str(d),'head':source['head'],'startTick':result['startTick'],'resume':source['resume'],'tick':result['tick'],'winner':result['winner'],'naturalComplete':result['naturalComplete'],'permanentDeaths':len(losses),'capturedSurvivors':[{'id':u['id'],'owner':u['owner'],'kind':u['kind']} for u in result['remaining'] if u['id'].startswith('unit-p0-') and u['owner']!='p0'],'permanentBirthsAfterStart':len(births),'permanentAlive':len([u for u in result['remaining'] if u['owner']=='p0' and 'expiresTick' not in u]),'hallEvents':halls,'elapsedMs':result['elapsedMs'],'sourceChangedDuringRun':result['sourceChangedDuringRun']})
out={'classification':'known failed seed normal-start regression; not unseen; not acceptance','results':rows,'initialEquivalence':json.loads((r/'normal-initial-equivalence.json').read_text()),'divergence':json.loads((r/'normal-divergence.json').read_text())}
(r/'normal-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(rows,indent=2))
