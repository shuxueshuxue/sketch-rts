import {landingSpot} from '/workspace/bootstrap-1-resume/src/shared/naval';
import {shipPassengers,distanceToHull} from '/workspace/bootstrap-1-resume/src/shared/ship-geometry';
import {sameGround} from '/workspace/bootstrap-1-resume/src/shared/terrain';
import {armedFoes,safeLandTravelTicks} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route';
import type {GameSnapshot,PlayerId,GameCommand,Unit} from '/workspace/bootstrap-1-resume/src/shared/types';
import type {AiPolicyContext} from '/workspace/bootstrap-1-resume/src/ai/policy/types';
export function preventHullLanding(s:GameSnapshot,owner:PlayerId,o:AiPolicyContext,planned:GameCommand[]) {
 let result=planned;const foes=armedFoes(s,owner,o);
 for(const ship of s.units){if(ship.owner!==owner||!ship.sailing)continue;const job=o.memory.naval?.ferries?.[ship.id];if(job?.phase!=='return'||job.purpose!=='settle')continue;
 if(planned.some(c=>c.type==='move'&&c.unitIds.includes(ship.id)))continue;
 const cargo=shipPassengers(s.units,ship);if(!cargo.length)continue;
 const returnPose:Unit={...ship,order:{type:'unload',x:job.from.x,y:job.from.y}};
 const overlaps=(p:{x:number;y:number},u:Unit)=>s.units.some(b=>b.sailing&&b.id!==ship.id&&distanceToHull(b,p)<u.radius+1);
 if(!cargo.some((u,i)=>{const p=landingSpot(s.map,returnPose,i,cargo.length,s.units,u);return p&&overlaps(p,u);}))continue;
 result=result.flatMap((c):GameCommand[]=>{if(c.type==='unloadPassenger'&&c.transportId===ship.id)return[];if('unitIds'in c&&c.unitIds.includes(ship.id)){const ids=c.unitIds.filter(id=>id!==ship.id);return ids.length?[{...c,unitIds:ids}]:[];}return[c];});
 if(ship.order.type!=='idle'){result.push({type:'stop',unitIds:[ship.id]});continue;}
 for(let i=0;i<cargo.length;i++){const u=cargo[i]!,p=landingSpot(s.map,ship,i,cargo.length,s.units,u);if(!p||overlaps(p,u))continue;
 if(!s.buildings.some(h=>h.owner===owner&&h.kind==='townHall'&&h.complete&&h.hp>0&&Math.hypot(h.x-p.x,h.y-p.y)<850&&sameGround(s.map,p,h)&&safeLandTravelTicks(s,{...u,...p,deck:undefined,cabin:undefined},h,foes)!==undefined))continue;
 result.push({type:'unloadPassenger',transportId:ship.id,passengerId:u.id});break;}
 }
 return result;
}
