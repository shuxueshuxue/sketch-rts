import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{shipPassengers,distanceToHull}from'/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
import{canBoard}from'/workspace/bootstrap-1-resume/src/shared/decks.ts';
import{coastalWithdrawalPassage,coastalRefuge}from'/workspace/bootstrap-1-resume/src/ai/policy/coastal-risk.ts';
import{bootstrapPolicyContext}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/knight-cabin-rescue33000/frames/34200.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),ship=s.units.find(u=>u.id==='unit-p0-carrier-2574')!,o=bootstrapPolicyContext(s,'p0','v9_knight',{memory:structuredClone(f.memories.p0),teams:g.teams});
const rows=[];for(const id of ['unit-p0-transport-1068','unit-p0-warship-1249']){const boat=s.units.find(u=>u.id===id)!;let route;const goal=coastalRefuge(s,boat,[ship],p=>{const q=coastalWithdrawalPassage(s,boat,p,o);if(q)route=q;return !!q;});rows.push({id,goal:goal??null,route:route??null});}writeFileSync(root+'/knight-yield-roads34200.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
