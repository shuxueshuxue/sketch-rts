import {strict as assert} from 'node:assert';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame,issuePlayerCommand} from '/workspace/bootstrap-1-resume/src/shared/sim';
import {distanceToHull} from '/workspace/bootstrap-1-resume/src/shared/ship-geometry';
import {preventHullLanding} from './return-landing-draft';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/knight/frames/18600.json.gz')).toString());
const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const boat=g.units.find(u=>u.id==='unit-p0-transport-1068')!,carrier=g.units.find(u=>u.kind==='carrier'&&u.owner==='p0')!,o={memory:f.memories.p0,teams:g.teams};const planned=[{type:'unload' as const,unitIds:[boat.id],x:4496,y:1200}];
const before=JSON.stringify(snapshotGame(g)),gold=g.players.p0!.gold,count=g.units.length;
let commands=preventHullLanding(snapshotGame(g),'p0',o,planned);assert.deepEqual(commands,[{type:'stop',unitIds:[boat.id]}]);assert.equal(JSON.stringify(snapshotGame(g)),before);for(const c of commands)issuePlayerCommand(g,'p0',c);
const checks:any[]=[];
for(let i=0;i<6;i++){commands=preventHullLanding(snapshotGame(g),'p0',o,planned);const c=commands.find(c=>c.type==='unloadPassenger');if(!c||c.type!=='unloadPassenger')break;issuePlayerCommand(g,'p0',c);const u=g.units.find(u=>u.id===c.passengerId)!;assert.equal(u.deck,undefined);assert.ok(distanceToHull(carrier,u)>=u.radius+1);checks.push({passenger:u.id,x:u.x,y:u.y,hullGap:distanceToHull(carrier,u)});}
assert.ok(checks.length);assert.equal(g.players.p0!.gold,gold);assert.equal(g.units.length,count);
const move={type:'move' as const,unitIds:[boat.id],x:4800,y:2000,avoidCombat:true};assert.deepEqual(preventHullLanding(snapshotGame(g),'p0',o,[move]),[move]);
const f2=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-resume/src/ai/bootstrap_1/fixtures/safe-colony-return-13470.json.gz')).toString());const g2=createGame('bareDuel');restoreSnapshotIntoGame(g2,f2.snapshot,f2.nextId);const existing=[{type:'unload' as const,unitIds:['unit-p0-transport-1070'],x:4368,y:6032,avoidCombat:true}];assert.deepEqual(preventHullLanding(snapshotGame(g2),'p0',{memory:f2.memories.p0,teams:g2.teams},existing),existing);
writeFileSync(root+'/generic-landing-contract.json',JSON.stringify({publicLandingChecks:checks,snapshotUnchanged:true,resourcesUnchanged:true,unitCountUnchanged:true,emergencyMovePreserved:true,existingSafeReturnPreserved:true},null,2));console.log('native public landing checks passed',checks.length);
