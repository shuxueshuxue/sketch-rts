import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{shipPassengers,distanceToHull}from'/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
import{canBoard}from'/workspace/bootstrap-1-resume/src/shared/decks.ts';
import{coastalWithdrawalPassage}from'/workspace/bootstrap-1-resume/src/ai/policy/coastal-risk.ts';
import{bootstrapPolicyContext}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/knight/frames/33000.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),ship=s.units.find(u=>u.id==='unit-p0-carrier-2574')!,o=bootstrapPolicyContext(s,'p0','v9_knight',{memory:structuredClone(f.memories.p0),teams:g.teams});
const rows=s.units.filter(u=>u.owner==='p0'&&!u.deck&&!u.sailing&&distanceToHull(ship,u)<100).map(u=>({id:u.id,kind:u.kind,x:u.x,y:u.y,order:u.order,hullGap:distanceToHull(ship,u),canBoard:canBoard(ship,u,s.units)}));const report={tick:s.tick,shipId:ship.id,cargo:shipPassengers(s.units,ship).length,nearby:rows};writeFileSync(root+'/knight-blockers33000.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
