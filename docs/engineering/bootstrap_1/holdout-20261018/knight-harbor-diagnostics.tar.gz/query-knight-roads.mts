import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{beginShipCollisionFrame}from'/workspace/bootstrap-1-resume/src/shared/ship-collisions.ts';
import{shipRouteTraffic}from'/workspace/bootstrap-1-resume/src/shared/ship-avoidance.ts';
import{planVoyageRoute,nearestShipPose}from'/workspace/bootstrap-1-resume/src/shared/ship-navigation.ts';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/knight/frames/33000.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),b=s.units.find(u=>u.id==='unit-p0-carrier-2574')!,goal={x:3664,y:4688};
const cases=[['all',s.units],['withoutGround',s.units.filter(u=>u.sailing||u.deck)],['withoutOtherShips',s.units.filter(u=>!u.sailing||u.id===b.id)],['terrainOnly',[b]] ] as const;const rows=[];
for(const[name,list]of cases){const boat={...b,sailing:{...b.sailing!},order:{type:'move' as const,...goal,avoidCombat:true},orderQueue:[]};delete boat.sailing.route;const units=list.map(u=>u.id===b.id?boat:u);beginShipCollisionFrame(units,s.map,[...s.buildings,...s.obstacles??[]]);const route=planVoyageRoute(s.map,boat,goal,shipRouteTraffic(s.map,boat,units),1024);rows.push({name,route});}
writeFileSync(root+'/knight-roads33000.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(x=>({name:x.name,partial:x.route.partial,points:x.route.points.length,first:x.route.points[0],last:x.route.points.at(-1)}))));
