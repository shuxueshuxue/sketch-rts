import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{landingSpot}from'/workspace/bootstrap-1-resume/src/shared/naval.ts';
import{shipPassengers,distanceToHull}from'/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
const root='/workspace/bootstrap-1-holdout-20261018',rows=[];
for(const tick of [18000,18600,19200,20400,21000]){const f=JSON.parse(gunzipSync(readFileSync(root+'/knight/frames/'+tick+'.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),boat=s.units.find(u=>u.id==='unit-p0-transport-1068')!,cargo=shipPassengers(s.units,boat);rows.push({tick,boat:{x:boat.x,y:boat.y,heading:boat.sailing?.heading,order:boat.order},mission:f.memories.p0.naval.ferries?.[boat.id],landings:cargo.map((u,i)=>{const p=landingSpot(s.map,boat,i,cargo.length,s.units,u);return{id:u.id,spot:p,overlap:p?s.units.filter(b=>b.sailing&&b.id!==boat.id&&distanceToHull(b,p)<u.radius).map(b=>b.id):[]};})});}
writeFileSync(root+'/knight-landings-history.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
