from pathlib import Path
import json,gzip,collections
root=Path('/workspace/bootstrap-1-holdout-20261018');rows=[]
for name in ['archer','summoner','knight']:
 r=root/name;p=max((r/'frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0]));f=json.loads(gzip.decompress(p.read_bytes()));s=f['snapshot'];own=[u for u in s['units'] if u['owner']=='p0' and 'expiresTick' not in u];w=[u for u in own if u['kind']=='worker'];h=[b for b in s['buildings'] if b['owner']=='p0' and b['kind']=='townHall'];rows.append({'case':name,'tick':s['tick'],'winner':s['match'].get('winner'),'resultExists':(r/'result.json').exists(),'crashExists':(r/'crash.json').exists(),'rawLosses':s['match']['stats']['unitsLost'],'gold':s['players']['p0']['gold'],'alive':len(own),'workers':len(w),'miners':sum(u['order']['type']=='mine' and not u.get('deck') for u in w),'halls':len(h),'completeHalls':sum(b['complete'] for b in h),'ships':sum(bool(u.get('sailing')) for u in own),'workerOrders':dict(collections.Counter(u['order']['type'] for u in w)),'ferries':f['memories']['p0'].get('naval',{}).get('ferries',{})})
for row in rows:
 permanent=collections.Counter(); temporaryKilled=collections.Counter();expired=collections.Counter()
 for line in (root/row['case']/'entities.jsonl').open():
  try:event=json.loads(line)
  except json.JSONDecodeError:break
  if event['tick']>row['tick']:break
  unit=event.get('last',{})
  if event['event']!='removal' or not unit.get('id','').startswith('unit-'):continue
  if 'expiresTick' not in unit:permanent[unit['owner']]+=1
  elif event['tick']<unit['expiresTick']:temporaryKilled[unit['owner']]+=1
  else:expired[unit['owner']]+=1
 row['permanentLosses']=dict(permanent);row['temporaryKilled']=dict(temporaryKilled);row['temporaryExpired']=dict(expired)
for row in rows: print(json.dumps({k:v for k,v in row.items() if k not in ['ferries','workerOrders']}))
(root/'latest-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
