import{coastalRefuge,coastalWithdrawalPassage}from'/workspace/bootstrap-1-resume/src/ai/policy/coastal-risk.ts';
import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{DOCK_REPAIR}from'/workspace/bootstrap-1-resume/src/shared/catalog.ts';
import{bootstrapPolicyContext}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
import{transportRecovery,transportNeedsRecovery}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/transport-recovery.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/summoner/frames/9000.json.gz')).toString());
function load(){const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);return{g,m:structuredClone(f.memories.p0)};}
const{g,m}=load(),s=snapshotGame(g),o=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:m,teams:g.teams}),boat=s.units.find(u=>u.id==='unit-p0-transport-1070')!,recovery=transportRecovery(s,'p0',o);
const threats=s.units.filter(u=>u.owner==='p2'&&u.sailing&&u.attackDamage>0&&Math.hypot(u.x-boat.x,u.y-boat.y)<1000);
const roads:any[]=[];const goal=coastalRefuge(s,boat,threats,p=>{const route=coastalWithdrawalPassage(s,boat,p,o);roads.push({goal:p,route:route??null});return !!route;});
const report={tick:s.tick,boatId:boat.id,goal:goal??null,roads,threats:threats.map(u=>({id:u.id,kind:u.kind,x:u.x,y:u.y}))};writeFileSync(root+'/summoner-refuge9000.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
