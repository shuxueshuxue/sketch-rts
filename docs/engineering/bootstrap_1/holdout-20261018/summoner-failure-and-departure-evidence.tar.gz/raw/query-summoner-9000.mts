import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{DOCK_REPAIR}from'/workspace/bootstrap-1-resume/src/shared/catalog.ts';
import{bootstrapPolicyContext}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
import{transportRecovery,transportNeedsRecovery}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/transport-recovery.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
const root='/workspace/bootstrap-1-holdout-20261018',f=JSON.parse(gunzipSync(readFileSync(root+'/summoner/frames/9000.json.gz')).toString());
function load(){const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);return{g,m:structuredClone(f.memories.p0)};}
const{g,m}=load(),s=snapshotGame(g),o=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:m,teams:g.teams}),boat=s.units.find(u=>u.id==='unit-p0-transport-1070')!,recovery=transportRecovery(s,'p0',o);
const fresh=load(),entries=planAiOwnerCommandEntries(snapshotGame(fresh.g),{playerId:'p0',version:'v9_summoner',memory:fresh.m},{teams:fresh.g.teams});
const actual=readFileSync(root+'/summoner/commands.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)).filter(x=>x.tick===9000&&x.owner==='p0').map(({scriptId,command})=>({scriptId,command}));
const projected=entries.map(({scriptId,command})=>({scriptId,command}));
const report={tick:9000,boat,needsRecovery:transportNeedsRecovery(s,boat),recovery:{ids:[...recovery.ids],commands:recovery.commands},repair:DOCK_REPAIR,mission:m.naval?.ferries?.[boat.id],outfit:m.naval?.outfit,docks:s.buildings.filter(b=>b.owner==='p0'&&b.kind==='shipyard').map(b=>({id:b.id,hp:b.hp,x:b.x,y:b.y,distance:Math.hypot(b.x-boat.x,b.y-boat.y)})),nearFoes:s.units.filter(u=>u.owner==='p2'&&Math.hypot(u.x-boat.x,u.y-boat.y)<1000),entries:projected,normalCommandsEqual:JSON.stringify(actual)===JSON.stringify(projected),actual};writeFileSync(root+'/summoner-recovery9000.json',JSON.stringify(report,null,2));console.log(JSON.stringify({needsRecovery:report.needsRecovery,recovery:report.recovery,docks:report.docks,entries:projected,normalCommandsEqual:report.normalCommandsEqual}));
