import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {planAiOwnerCommandEntries} from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import {preventHullLanding} from './return-landing-draft.ts';
const root='/workspace/bootstrap-1-holdout-20261018',rows=[];
for(const version of ['v9_archer','v9_summoner','v9_knight'] as const){const f=JSON.parse(gunzipSync(readFileSync(root+'/knight/frames/18600.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),o={memory:f.memories.p0,teams:g.teams};const old=planAiOwnerCommandEntries(s,{playerId:'p0',version,memory:o.memory},{teams:g.teams});const changed=preventHullLanding(s,'p0',o,old.map(e=>e.command));rows.push({version,old:old.filter(e=>'unitIds'in e.command&&e.command.unitIds.includes('unit-p0-transport-1068')),changed:changed.filter(c=>'unitIds'in c&&c.unitIds.includes('unit-p0-transport-1068'))});}
writeFileSync(root+'/landing-three-routes.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
