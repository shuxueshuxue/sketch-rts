import pathlib,json,gzip
r=pathlib.Path('/workspace/bootstrap-1-holdout-20261018');runs=[('18600','21600'),('21600','33000')];out=[]
for start,end in runs:
 a=r/('knight-generic-landing'+start);b=r/('knight-formal-landing'+start);checks=[]
 for f in sorted((b/'frames').glob('*'),key=lambda p:int(p.name.split('.')[0])):
  try:y=json.loads(gzip.decompress(f.read_bytes()))
  except (EOFError,json.JSONDecodeError):continue
  x=json.loads(gzip.decompress((a/'frames'/f.name).read_bytes()));checks.append({'tick':y['snapshot']['tick'],**{k:x[k]==y[k] for k in ['snapshot','nextId','memories']}})
 cmd=lambda p:[{k:v for k,v in json.loads(l).items() if k!='scriptId'} for l in (p/'commands.jsonl').read_text().splitlines()]
 x,y=cmd(a),cmd(b);finished=(b/'result.json').exists();out.append({'start':start,'end':end,'complete':finished,'frames':checks,'commands':len(y),'commandsEqualIgnoringDiagnosticScriptLabel':x==y if finished else x[:len(y)]==y,'sourceChangedDuringRun':json.loads((b/'result.json').read_text())['sourceChangedDuringRun'] if finished else None})
(r/'formal-landing-equivalence.json').write_text(json.dumps(out,indent=2));print([{'start':x['start'],'complete':x['complete'],'frames':len(x['frames']),'lastTick':x['frames'][-1]['tick'],'failedFrames':sum(not all(c[k] for k in ['snapshot','nextId','memories']) for c in x['frames']),'commands':x['commands'],'commandsEqual':x['commandsEqualIgnoringDiagnosticScriptLabel']} for x in out])
