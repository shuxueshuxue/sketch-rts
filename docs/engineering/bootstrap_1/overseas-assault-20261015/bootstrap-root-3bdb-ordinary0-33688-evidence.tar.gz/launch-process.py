import pathlib,json,subprocess,hashlib,datetime,os
p=pathlib.Path('/tmp/bootstrap-root-3bdb-ordinary0-20261015'); launch=json.load(open(p/'ordinary-launch.json')); assert '--resume' not in launch['argv']; assert not (p/'ordinary-process-start.json').exists()
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with open(launch['stdoutLog'],'x') as log:
 process=subprocess.Popen(launch['argv'],cwd=launch['cwd'],stdout=log,stderr=subprocess.STDOUT)
 record={'classification':'Actual process launch of unmodified inspect runner at ordinary tick0; no resume or manual world/strategy changes.','startedAtUtc':started,'pid':process.pid,'argv':launch['argv'],'cwd':launch['cwd'],'expectedCommit':launch['expectedCommit'],'launchSHA256':hashlib.sha256((p/'ordinary-launch.json').read_bytes()).hexdigest(),'procCmdline':pathlib.Path(f'/proc/{process.pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()}
 (p/'ordinary-process-start.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps(record,ensure_ascii=False),flush=True)
 status=process.wait()
 (p/'ordinary-process-exit.json').write_text(json.dumps({'pid':process.pid,'exitCode':status,'finishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n'); print(json.dumps({'finished':True,'exitCode':status}),flush=True)
 raise SystemExit(status)
