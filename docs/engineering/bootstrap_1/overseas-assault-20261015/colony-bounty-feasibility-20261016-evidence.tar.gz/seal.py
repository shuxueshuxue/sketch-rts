from pathlib import Path
import json, hashlib, gzip, datetime, shutil, tarfile

p=Path('/workspace/.playtest/colony-bounty-feasibility-20261016')
D=Path('/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not (p/'INDEX.json').exists(), 'Already sealed; do not rewrite'
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  return [z for k in sorted(set(a)|set(b)) for z in ([path+'/'+k] if k not in a or k not in b else diff(a[k],b[k],path+'/'+k))]
 if isinstance(a,list):
  if len(a)!=len(b):return [path]
  return [z for i,(x,y)in enumerate(zip(a,b))for z in diff(x,y,path+'/'+str(i))]
 return []if a==b else[path]
original_commands=[json.loads(x)for x in (D/'resume-79800/ordinary0-resume-public-commands.jsonl').read_text().splitlines()]
comparisons=[]
for tick in [112800,145800]:
 b=json.loads((p/f'baseline-{tick}.json').read_text())
 actual=[{'playerId':r['owner'],'source':'external-agent','scriptId':r['scriptId'],'command':r['command']}for r in original_commands if r['tick']==tick and r['owner']=='p0']
 assert actual==b['entries'], ('Original native command mismatch',tick)
 modes=['bounty-feasibility']+(['ungated']if tick==145800 else[])
 for mode in modes:
  j=json.loads((p/f'{mode}-{tick}.json').read_text())
  assert j['entries']==b['entries']and j['nativeWorldUnchanged']and j['sourceChanges']==[]
  ds=diff(b['memoriesAfter'],j['memoriesAfter'])
  assert ds==['/p0/naval/island'], ds
  comparisons.append({'tick':tick,'mode':mode,'baselineCommands':len(b['entries']),'candidateCommands':len(j['entries']),'commandsExactlyOriginalNativeP0AtTick':True,'commandsExactlyBaseline':True,'all3MemoryDiffPaths':ds,'p1p2MemoryExactlyBaseline':True,'newGoal':j['component']['plan']['mine']['id']})
 assert b['sourceChanges']==[]and b['nativeWorldUnchanged']
 for f in [D/f'resume-79800/ordinary0-resume.frames/{tick}.json.gz']:
  shutil.copyfile(f,p/f'input-{tick}.json.gz')
shutil.copyfile(D/'candidate-source.json',p/'original-source-manifest-1443.json')

notes={
 'classification':'Closed read-only feasibility/negative command comparison, not strategy implementation, native continuation or ordinary0 result.',
 'actualTime':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source':'/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control',
 'head':'0f5bf01a05046169d4fb42322376f767b97bcc83',
 'rulesVersion':2,'fixedSourceFiles':1443,'sourceChangeCount':0,
 'queries':comparisons,
 'nativeOriginalCommandComparison':'Full p0 pure planner entries at both saved ticks exactly equal the already executed original public-command records; no command issued by reviewer.',
 'financialFacts':{'goldNow':383.33,'hallCost':400,'gap':16.67,'twoLiveSat2GuardHP':[7,20],'nativeBountyEach':45,'oneKillArithmeticGold':428.33,'oneKillDoesNotProveSafeCombatOrPurchase':True,'paidQueue':{'buildingId':'building-p0-shipyard-1022','jobId':'training-51467','kind':'cutter','remaining':0,'paidGold':160},'publicRefundCommandNotIssued':{'type':'cancelTraining','buildingId':'building-p0-shipyard-1022','jobId':'training-51467'},'refundArithmeticGold':543.33},
 'executionFacts':[
  '112800 actual sole carrier is full health and already assigned old assault/loading; goal-only change preserves its real mission and changes no commands.',
  '145800 sole carrier has no ferry mission, hull479.99730562542345/480, propulsion/steering full, and transportNeedsRecovery=true because ordinary repair is affordable; recovery owns it. Saved native return route is partial/end=current position and traffic key names31227/50739. This is not a new fresh path or continuous impossibility proof.',
  '145800 no own horseArcher; existing dedicated rider crossing cannot produce a camp clearing job for this family from that snapshot.',
  'Existing normal settlement carries engineers and fighters and uses original landingSafe1.4; a target-plan change does not bypass repair/crew/ownership or current attack readiness.',
 ],
 'minimalReviewableNextDesign':[
  'Separate strategic mine admissibility from current purchase affordability: actual same-land live neutral bounty may justify a clear-then-settle objective when enough to close the real hall deficit; mine must still repay the hall, be unclaimed by allies, have no enemy-held hall, and satisfy existing real coast/crew/safety checks.',
  'Filter each underfunded candidate and cached plan by that financing premise; merely deleting the global cash gate selects clear sat3 with zero bounty and cannot earn the missing gold. Never add future bounty to player.gold or issue an unaffordable build.',
  'This exact minimal goal-only prototype is insufficient: it changes only naval.island memory and zero actual commands. An implementation needs a separately reviewed existing naval-owner execution choice/available lift, preserving real committed mission and medical ownership; no new owner/TTL/arbitrary threat reduction is proposed or implemented here.',
  'A distinct smaller capital option is public cancellation of the already-paid stuck discretionary cutter: actual source semantics refunds160 and exact-job identity avoids cancelling the next job. It has not been executed or inserted into the AI. Revalidate the queue/need, preserve essential economic lift, and do not promise a refund will unblock the actual repair path.',
  'Precise future spending must distinguish Hall capital from other reserved purchase costs and actual remaining recoverable mine income. The cutter is not established as the sole loss cause: it was queued87375 with433.33 still present at87600; later88395 hall investment was actually attacked and destroyed88639 while incomplete.',
 ],
 'boundaries':[
  'No Game instantiated, native step, issued command, source/worktree/main/frozen-policy change, opponent alteration or new fullgame.',
  'All3memory preserved in inputs and results; no fields removed to claim equality.',
  'Counterfactual functions exist only in external bundles; they are not prelaunch production or an accepted candidate.',
  'First invocation failed before evaluation because TSX treated the external directory as CJS; original error log retained, then external package.json type=module resolved it. It did not advance a game.',
  'Original0 and its193200 nonnatural stop are parent-case results, not outcomes produced by these queries. Original passenger candidate34800 interruption remains unresolved; no resumed candidate game here.',
  'Original container uncommitted work remains unrecovered; three-route/opponent/map/seed acceptance remains incomplete.',
 ]}
(p/'observations-and-proposal.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
(p/'README.zh.md').write_text('''# 原局殖民赏金与资本的只读可行性

本包属于原 0f5bf 召唤对正常冻结 v5+v7 普通局的事后审查，不是新普通局、策略实现或原生续局。使用实际 112800、145800 完整世界、nextId、三方记忆；固定 1443 源码文件前后变更为零。没有 createGame、step 或发命令。完整结论与下一项最小设计见 observations-and-proposal.json。

145800 原图已实际查看：sat2 矿7500、两名残血 hunter、无己工/厅；主港有军队和多舰。图源是保存帧的原生 drawWorld 渲染，不是此查询新跑截图，也不是历史动画证据。

原生 bounty 每猎手45，383.33+45=428.33 可跨过厅400的购买门槛；这只是目标融资的真实规则算术，不保证安全击杀或真正购买。公开 cancelTraining 精确队列ID可退 paidGold160，算术为543.33；本审查没有执行或加进 AI。

三种纯规划分支：baseline 原函数；ungated 只去掉无income且gold<400的提前退出；bounty-feasibility 按真实同岛活guard原生赏金可补缺口筛选目标及旧缓存。仅移gate选无赏金sat3，融资筛选选sat2。112800原p0有6条命令、145800有5条，每个反事实完整pipeline仍与baseline及已执行原生公令逐项相同；所有三方记忆差异只在p0.nav al.island（实际键naval.island）。没有偷偷重定义军力或强行改船任务。

112800实际运输船健康但被旧assault/loading占用；145800它已无mission，却因0.002694HP损伤、当前可付维修费而由transportRecovery保留返港，原存海路partial停在当前点。没有新路径证明，不把有限站位查询当不可达结论。现有专门跨海清矿入口只收horseArcher，实际该局没有。目标gate改动本身尚不能恢复执行，不能称已解决。

资金历史摘录还纠正归因：cutter87375入队，87600金仍433.33；88395真的请求sat1建厅，厅52659在88639被敌ravager1183摧毁、尚未完工progress11。94800金实际223.33；随后102111/102176/102207己spirit真实击杀sat3三guard，70+45+45共160赏金后才到383.33。不能把这笔增加说成采矿收入，也不能把最后缺钱全归cutter。

input两个gz是原周期档字节复制；original-source-manifest-1443.json是原source清单。原command/event大流不在此重复复制，native-capital-records.json有源路径SHA与选定原记录，主case包另保存完整大流。baseline.mjs / ungated.mjs / bounty-feasibility.mjs是外部只读bundle；query.ts和每次prequery保留真实时间、函数原文及反事实文本。初次CJS setup错误原log保留，外部package.json修正后才成功；没有游戏启动。

零伤亡、取消、获得目标计划或局部查询通过均不构成胜利。原普通局193200无胜者的支持停止归父case；原boarding候选34800中断缺口未解决。规则2、冻结正常对手与三条路线完整验收不变，原故障容器未提交修改仍未恢复。
'''.replace('p0.nav al.island（实际键naval.island）','p0.naval.island'))

payload={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in sorted(p.rglob('*'))if f.is_file()and not f.is_symlink()and f.name!='INDEX.json'}
index={'classification':notes['classification'],'actualSealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':payload}
(p/'INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
archive=p.parent/'colony-bounty-feasibility-20261016-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz')as t:
 for name in sorted(payload):t.add(p/name,arcname=name,recursive=False)
 t.add(p/'INDEX.json',arcname='INDEX.json',recursive=False)
with tarfile.open(archive)as t:
 regular=[m.name for m in t.getmembers()if m.isfile()]
 assert set(regular)==set(payload)|{'INDEX.json'}and len(regular)==len(payload)+1
 for name,row in payload.items():
  b=t.extractfile(name).read();assert len(b)==row['bytes']and sha(b)==row['sha256']
delivery={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'indexedPayloadFiles':len(payload),'archiveRegularFiles':len(regular),'manifest':'INDEX.json','manifestSHA256':sha((p/'INDEX.json').read_bytes()),'allPayloadSHABytesAndCoverageVerified':True,'classification':notes['classification']}
(p.parent/'colony-bounty-feasibility-20261016-delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n');print(json.dumps(delivery,ensure_ascii=False),flush=True)
