# 原局殖民赏金与资本的只读可行性

本包属于原 0f5bf 召唤对正常冻结 v5+v7 普通局的事后审查，不是新普通局、策略实现或原生续局。使用实际 112800、145800 完整世界、nextId、三方记忆；固定 1443 源码文件前后变更为零。没有 createGame、step 或发命令。完整结论与下一项最小设计见 observations-and-proposal.json。

145800 原图已实际查看：sat2 矿7500、两名残血 hunter、无己工/厅；主港有军队和多舰。图源是保存帧的原生 drawWorld 渲染，不是此查询新跑截图，也不是历史动画证据。

原生 bounty 每猎手45，383.33+45=428.33 可跨过厅400的购买门槛；这只是目标融资的真实规则算术，不保证安全击杀或真正购买。公开 cancelTraining 精确队列ID可退 paidGold160，算术为543.33；本审查没有执行或加进 AI。

三种纯规划分支：baseline 原函数；ungated 只去掉无income且gold<400的提前退出；bounty-feasibility 按真实同岛活guard原生赏金可补缺口筛选目标及旧缓存。仅移gate选无赏金sat3，融资筛选选sat2。112800原p0有6条命令、145800有5条，每个反事实完整pipeline仍与baseline及已执行原生公令逐项相同；所有三方记忆差异只在p0.naval.island。没有偷偷重定义军力或强行改船任务。

112800实际运输船健康但被旧assault/loading占用；145800它已无mission，却因0.002694HP损伤、当前可付维修费而由transportRecovery保留返港，原存海路partial停在当前点。没有新路径证明，不把有限站位查询当不可达结论。现有专门跨海清矿入口只收horseArcher，实际该局没有。目标gate改动本身尚不能恢复执行，不能称已解决。

资金历史摘录还纠正归因：cutter87375入队，87600金仍433.33；88395真的请求sat1建厅，厅52659在88639被敌ravager1183摧毁、尚未完工progress11。94800金实际223.33；随后102111/102176/102207己spirit真实击杀sat3三guard，70+45+45共160赏金后才到383.33。不能把这笔增加说成采矿收入，也不能把最后缺钱全归cutter。

input两个gz是原周期档字节复制；original-source-manifest-1443.json是原source清单。原command/event大流不在此重复复制，native-capital-records.json有源路径SHA与选定原记录，主case包另保存完整大流。baseline.mjs / ungated.mjs / bounty-feasibility.mjs是外部只读bundle；query.ts和每次prequery保留真实时间、函数原文及反事实文本。初次CJS setup错误原log保留，外部package.json修正后才成功；没有游戏启动。

零伤亡、取消、获得目标计划或局部查询通过均不构成胜利。原普通局193200无胜者的支持停止归父case；原boarding候选34800中断缺口未解决。规则2、冻结正常对手与三条路线完整验收不变，原故障容器未提交修改仍未恢复。
