import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { gunzipSync } from 'node:zlib';
import { isDeepStrictEqual } from 'node:util';
import { build } from '/workspace/sketch-rts/node_modules/esbuild/lib/main.js';

const source = '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control';
const originalDir = '/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const out = '/workspace/.playtest/colony-bounty-feasibility-20261016';
const [mode, tickText] = process.argv.slice(2), tick = Number(tickText);
if (!['baseline', 'ungated', 'bounty-feasibility'].includes(mode) || ![112800, 145800].includes(tick)) throw Error('Explicit mode and actual saved tick required');
mkdirSync(out, { recursive: true });
const sha = (b: any) => createHash('sha256').update(b).digest('hex');
const cap = JSON.parse(readFileSync(originalDir + '/candidate-source.json', 'utf8'));
if (cap.sourceRoot !== source || cap.head !== '0f5bf01a05046169d4fb42322376f767b97bcc83') throw Error('Unexpected source');
const changes = () => Object.entries(cap.hashes).filter(([p, h]) => sha(readFileSync(source + '/' + p)) !== h).map(([p]) => p);
if (changes().length) throw Error('Source preflight changed');
const input = originalDir + `/resume-79800/ordinary0-resume.frames/${tick}.json.gz`;
const raw = readFileSync(input), saved = JSON.parse(gunzipSync(raw).toString());
const navalPath = source + '/src/ai/policy/naval.ts', original = readFileSync(navalPath, 'utf8');
const start = original.indexOf('function islandPlan('), end = original.indexOf('\n}\n', start) + 2;
if (start < 0 || end < 2) throw Error('Exact islandPlan missing');
const oldBody = original.slice(start, end);
const gate = '    if (!income && playerState(snapshot, owner).gold < BUILDING_DEFS.townHall.cost)\n        return undefined;';
if (!oldBody.includes(gate)) throw Error('Exact gate changed');
let body = oldBody;
if (mode === 'ungated') body = body.replace(gate, '    // External diagnostic: remove the cash gate only; no source file is written.');
if (mode === 'bounty-feasibility') {
  body = body.replace(gate, `    // External target-feasibility prototype only. Future bounty is never current purchase cash.
    const canFinanceMine = (mine: ResourceNode) => income || playerState(snapshot, owner).gold >= BUILDING_DEFS.townHall.cost
        || playerState(snapshot, owner).gold + snapshot.units.filter(unit => unit.owner === 'neutral' && unit.hp > 0
            && sameGround(map, unit, mine) && distance(unit, mine) < 400)
            .reduce((gold, unit) => gold + (unitRules(snapshot, unit).goldBounty ?? 0), 0) >= BUILDING_DEFS.townHall.cost;`);
  body = body.replace('|| !eligible(mine) || mineClaimedByAlly', '|| !eligible(mine) || !canFinanceMine(mine) || mineClaimedByAlly');
  body = body.replace('&& eligible(mine) && !sameGround', '&& eligible(mine) && canFinanceMine(mine) && !sameGround');
  if ((body.match(/canFinanceMine\(mine\)/g) ?? []).length !== 2) throw Error('Both saved/fresh goal eligibility must match');
}
const contents = original.slice(0, start) + body + original.slice(end)
  + '\nexport { islandPlan as diagnosticIslandPlan, landingSafe as diagnosticLandingSafe, landingDefense as diagnosticLandingDefense };\n';
const patched = mode === 'bounty-feasibility' ? contents.replace('BUILDING_DEFS, UNIT_DEFS,', 'BUILDING_DEFS, unitRules, UNIT_DEFS,') : contents;
const classification = mode === 'baseline'
  ? 'Pure original full-p0 planner plus exported internal queries; no Game instantiated, command issued, native step, source edit or candidate game.'
  : 'External bundle target-feasibility counterfactual on unchanged actual saved world/nextId/all3mem. Virtual islandPlan-only text differs; no source file written, Game instantiated, command issued or native step. Not a tested strategy or ordinary0 result.';
writeFileSync(out + `/${mode}-${tick}-prequery.json`, JSON.stringify({ actualTime: new Date().toISOString(), classification,
  source, head: cap.head, input, inputSHA256: sha(raw), driverSHA256: sha(readFileSync(import.meta.filename)),
  sourceFiles: Object.keys(cap.hashes).length, navalSHA256: sha(original), originalFunction: oldBody, evaluatedFunction: body }, null, 2));
await build({ stdin: { contents: `export {planAiOwnerCommandEntries} from '${source}/src/ai/planner-context.ts';
export {bootstrapPolicyContext} from '${source}/src/ai/bootstrap_1/policy.ts';
export {diagnosticIslandPlan,diagnosticLandingSafe,diagnosticLandingDefense,navalBudgetReserve,colonyNavalWantWithMineEligibility} from '${source}/src/ai/policy/naval.ts';
export {mountedMinePlan} from '${source}/src/ai/policy/mounted-mine-plan.ts';
export {unitRules,unitMover,BUILDING_DEFS} from '${source}/src/shared/catalog.ts';
export {sameGround,walkingDistance} from '${source}/src/shared/terrain.ts';
export {shipPassengers} from '${source}/src/shared/ship-geometry.ts';
export {mineClaimedByAlly} from '${source}/src/ai/policy/mine-claims.ts';
export {rankBootstrapGoals} from '${source}/src/ai/bootstrap_1/economy.ts';
export {planRiderCrossing} from '${source}/src/ai/bootstrap_1/rider-crossing.ts';`, resolveDir: source, loader: 'ts' },
  bundle: true, platform: 'node', format: 'esm', outfile: out + `/${mode}.mjs`,
  plugins: [{ name: 'external-island-goal-feasibility-only', setup(b) { b.onLoad({ filter: /\/naval\.ts$/ }, args => {
    if (args.path !== navalPath) return;
    return { contents: patched, loader: 'ts', resolveDir: source + '/src/ai/policy' };
  }); } }] });
const lib = await import(pathToFileURL(out + `/${mode}.mjs`).href);
const n = (v: any) => JSON.parse(JSON.stringify(v)), snapshot = structuredClone(saved.snapshot), memories = structuredClone(saved.memories);
const beforeWorld = n(snapshot), beforeMem = n(memories), began = performance.now();
const entries = lib.planAiOwnerCommandEntries(snapshot, { playerId: 'p0', source: 'external-agent', version: 'v9_summoner', memory: memories.p0 }, { teams: snapshot.teams });
if (!isDeepStrictEqual(n(snapshot), beforeWorld)) throw Error('Query mutated world');
const componentMemory = structuredClone(saved.memories.p0), context = lib.bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory: componentMemory, teams: snapshot.teams });
const camp = lib.mountedMinePlan(snapshot, componentMemory), plan = lib.diagnosticIslandPlan(snapshot, 'p0', context, camp.eligible);
const want = lib.colonyNavalWantWithMineEligibility(snapshot, 'p0', context, camp.eligible);
const goals = lib.rankBootstrapGoals(snapshot, 'p0', context);
const mines = snapshot.resources.filter((r: any) => r.amount > 0).map((mine: any) => {
  const guards = snapshot.units.filter((u: any) => u.owner === 'neutral' && u.hp > 0 && lib.sameGround(snapshot.map, u, mine) && Math.hypot(u.x - mine.x, u.y - mine.y) < 400);
  return { mine, claimedByAlly: lib.mineClaimedByAlly(snapshot, 'p0', mine, context), eligibleMountedMine: camp.eligible(mine),
    guards: guards.map((u: any) => ({ id: u.id, kind: u.kind, hp: u.hp, maxHp: u.maxHp, bounty: lib.unitRules(snapshot, u).goldBounty ?? 0 })),
    bountyPotential: guards.reduce((g: number, u: any) => g + (lib.unitRules(snapshot, u).goldBounty ?? 0), 0),
    actualGold: snapshot.players.p0.gold, affordabilityAfterOne45BountyArithmeticOnly: snapshot.players.p0.gold + 45 >= lib.BUILDING_DEFS.townHall.cost };
});
const result = { actualTime: new Date().toISOString(), classification, mode, tick, nextId: saved.nextId, input, inputSHA256: sha(raw),
  elapsedMs: performance.now() - began, entries, memoriesAfter: n(memories), all3MemoriesBefore: beforeMem, nativeWorldUnchanged: isDeepStrictEqual(n(snapshot), beforeWorld),
  component: { plan, want: want && { id: want.id, cost: want.cost, closeout: want.closeout }, goals: goals.map((g: any) => ({ id: g.id, cost: g.cost, priority: g.priority, save: g.save, hold: g.hold })),
    reserve: lib.navalBudgetReserve(snapshot, 'p0', context), mines, memoryAfterQueries: n(componentMemory) },
  sourceChanges: changes(), bundleSHA256: sha(readFileSync(out + `/${mode}.mjs`)), memoryUsage: process.memoryUsage(),
  noGameNoNativeStepNoCommandIssue: true };
if (!result.nativeWorldUnchanged || result.sourceChanges.length || !isDeepStrictEqual(saved, JSON.parse(gunzipSync(raw).toString()))) throw Error('Query immutability/source failure');
writeFileSync(out + `/${mode}-${tick}.json`, JSON.stringify(result));
console.log(JSON.stringify({ mode, tick, entries: entries.length, plan: plan?.mine?.id ?? null, want: result.component.want,
  sourceChanges: result.sourceChanges, nativeWorldUnchanged: result.nativeWorldUnchanged, elapsedMs: result.elapsedMs, memoryUsage: result.memoryUsage }));
