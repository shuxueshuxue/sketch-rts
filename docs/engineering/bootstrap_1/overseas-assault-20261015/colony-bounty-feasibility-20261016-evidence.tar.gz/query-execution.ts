import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import {isDeepStrictEqual} from 'node:util';
const root='/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control',dir='/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016',out='/workspace/.playtest/colony-bounty-feasibility-20261016',sha=(b:any)=>createHash('sha256').update(b).digest('hex'),load=(p:string)=>import(pathToFileURL(root+'/'+p).href),cap=JSON.parse(readFileSync(dir+'/candidate-source.json','utf8'));
const changes=()=>Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(root+'/'+p))!==h).map(([p])=>p);
if(changes().length)throw Error('Source changed');
const [{transportNeedsRecovery,transportRecovery},{shipNeedsRepair,shipPartMax},{navalServices},{DOCK_REPAIR,unitRules},{shipPassengers},{setBuildingBodies},{bootstrapPolicyContext},{isTransportKind}]=await Promise.all([load('src/ai/bootstrap_1/transport-recovery.ts'),load('src/shared/ship-equipment.ts'),load('src/ai/policy/naval-services.ts'),load('src/shared/catalog.ts'),load('src/shared/ship-geometry.ts'),load('src/shared/terrain.ts'),load('src/ai/bootstrap_1/policy.ts'),load('src/shared/transport-role.ts')]);
const results=[];
for(const tick of [112800,145800]){
 const input=dir+`/resume-79800/ordinary0-resume.frames/${tick}.json.gz`,raw=readFileSync(input),f=JSON.parse(gunzipSync(raw).toString()),s=structuredClone(f.snapshot),mem=structuredClone(f.memories),before=JSON.stringify(s),opts=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:mem.p0,teams:s.teams});
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const services=navalServices(s,'p0',opts),recovery=transportRecovery(s,'p0',opts),boats=s.units.filter((u:any)=>u.owner==='p0'&&isTransportKind(u.kind));
 results.push({tick,input,inputSHA256:sha(raw),nextId:f.nextId,actualGold:s.players.p0.gold,dockRepair:DOCK_REPAIR,
  boats:boats.map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,hullDeficit:u.maxHp-u.hp,parts:u.shipParts,maxParts:shipPartMax(u),needsRepair:shipNeedsRepair(s,u),needsRecovery:transportNeedsRecovery(s,u),serviceReserved:services.reserved.has(u.id),recoveryReserved:recovery.ids.has(u.id),mission:mem.p0.naval?.ferries?.[u.id]??null,cargo:shipPassengers(s.units,u).map((v:any)=>({id:v.id,kind:v.kind,temporary:v.expiresTick!==undefined})),order:u.order,nativeRoute:u.sailing?.route})),
  serviceReserved:[...services.reserved],serviceCommands:services.commands,recoveryReserved:[...recovery.ids],recoveryCommands:recovery.commands,
  paidQueue:s.buildings.filter((b:any)=>b.owner==='p0'&&b.queue.length).map((b:any)=>({id:b.id,kind:b.kind,queue:b.queue})),
  remainingGuardBounties:s.units.filter((u:any)=>u.owner==='neutral'&&u.hp>0).map((u:any)=>({id:u.id,hp:u.hp,bounty:unitRules(s,u).goldBounty??0})),nativeWorldUnchanged:JSON.stringify(s)===before});
 if(JSON.stringify(s)!==before)throw Error('World changed');
}
const report={classification:'Pure actual native-readiness/support queries only; no Game instantiation/step/command. Native route is saved historical route, not a fresh sailing proof. Refund is source-established public-command semantics, not executed in this investigation.',actualTime:new Date().toISOString(),source:root,head:cap.head,sourceFiles:Object.keys(cap.hashes).length,driverSHA256:sha(readFileSync(import.meta.filename)),results,sourceChanges:changes()};
if(report.sourceChanges.length)throw Error('Source changed');
writeFileSync(out+'/execution-readiness.json',JSON.stringify(report,null,2));console.log(JSON.stringify(results.map(r=>({tick:r.tick,boats:r.boats.map(u=>({id:u.id,hullDeficit:u.hullDeficit,needsRecovery:u.needsRecovery,serviceReserved:u.serviceReserved,recoveryReserved:u.recoveryReserved})),serviceCommands:r.serviceCommands.length,recoveryCommands:r.recoveryCommands}))));
