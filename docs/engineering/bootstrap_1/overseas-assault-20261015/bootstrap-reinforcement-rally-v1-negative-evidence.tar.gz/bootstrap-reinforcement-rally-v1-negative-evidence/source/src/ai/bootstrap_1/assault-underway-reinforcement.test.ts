import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import { planBootstrapNaval } from './expedition-recovery';
import { bootstrapPolicyContext } from './policy';

const subject = 'unit-p0-carrier-3780';
const forward = ['unit-p0-transport-1046', 'unit-p0-carrier-3827'];
function setup(tick: 68400 | 69600 | 70800 = 69600) {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/assault-reinforcement-e7-${tick}.json.gz`, import.meta.url))).toString());
  const game = createGame('bareDuel');
  restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), memory = structuredClone(saved.memories.p0);
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory, teams: game.teams });
  return { snapshot, memory, options };
}

it('starts the real loaded reinforcement toward an already sufficient sailing cohort', () => {
  const { snapshot, memory, options } = setup();
  const commands = planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('sailing');
  expect(commands.some(c => c.type === 'move' && c.unitIds.includes(subject) && c.avoidCombat)).toBe(true);
  // The current forward cohort remains under its own native landing commands.
  expect(commands.some(c => c.type === 'stop' && c.unitIds.some(id => forward.includes(id)))).toBe(false);
});

it('does not add the real distant68400 sailing cargo into one local cohort', () => {
  const { snapshot, memory, options } = setup(68400);
  planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('loading');
});

it('does not count an explicitly returning forward force (counterfactual boundary)', () => {
  const { snapshot, memory, options } = setup();
  for (const id of forward) memory.naval.ferries[id].phase = 'return';
  planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('loading');
});

it('does not count a sailing mission with a missing requested crew member (counterfactual boundary)', () => {
  const { snapshot, memory, options } = setup();
  memory.naval.ferries[forward[0]!].crewIds.push('not-actually-aboard');
  planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('loading');
});

it('does not count an unproved landing approach (counterfactual boundary)', () => {
  const { snapshot, memory, options } = setup();
  for (const id of forward) delete memory.naval.ferries[id].approach;
  planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('loading');
});

it('keeps the real70800 returning-force snapshot in loading', () => {
  const { snapshot, memory, options } = setup(70800);
  planBootstrapNaval(snapshot, 'p0', options);
  expect(memory.naval.ferries[subject].phase).toBe('loading');
});
