import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
const [source,label]=process.argv.slice(2),dir='/tmp/bootstrap-land-army-evidence-20261015',input=dir+'/production-root3bdb-archer-full10425.json';
const saved=JSON.parse(readFileSync(input,'utf8')),copy=(v:any)=>JSON.parse(JSON.stringify(v)),load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const {bootstrapMatches,bootstrapGame}=await load('src/ai/bootstrap_1/benchmark.ts'),{restoreSnapshotIntoGame,snapshotGame}=await load('src/shared/sim.ts'),{bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts');
const {mainlandCareAssignments,patientRendezvousCommands}=await load('src/ai/bootstrap_1/land-recovery.ts'),{mountedEscape,mountedThreatReach}=await load('src/ai/bootstrap_1/mounted-micro.ts'),{sameGround}=await load('src/shared/terrain.ts'),{groundSteeringRoute,routePrefix}=await load('src/shared/route-selection.ts');
const {ABILITY_DEFS,UNIT_DEFS}=await load('src/shared/catalog.ts');
const match=bootstrapMatches(saved.setup.seed,[saved.setup.map],10426,saved.setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===saved.setup.side&&m.agents.p0.race===saved.setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),memory=copy(saved.memories.p0),before=copy(memory),options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory,teams:game.teams});
const care=mainlandCareAssignments(snapshot,'p0',options),pair=care.recovering.find((p:any)=>p.patient.id==='unit-p0-footman-1072'),{patient,healer}=pair;
const threats=care.foes.filter((foe:any)=>sameGround(snapshot.map,patient,foe)&&Math.hypot(patient.x-foe.x,patient.y-foe.y)<=mountedThreatReach(snapshot,foe,patient,15)+('speed'in foe?foe.speed:0)*17/20);
const ability=UNIT_DEFS[healer.kind].abilities.find((a:any)=>ABILITY_DEFS[a].behavior==='heal'),gap=Math.hypot(patient.x-healer.x,patient.y-healer.y),rendezvous=patientRendezvousCommands(snapshot,[pair],care.foes,pair.medics),escape=mountedEscape(snapshot,patient,threats,0,healer,true);
const goals=[{label:'old5fActualGoal',x:1714.9452825897258,y:3818.651649597255},{label:'production3bdbActualGoal',x:1713.7887847552404,y:3849.4346946897886}].map(goal=>{
 const road=groundSteeringRoute(snapshot.map,patient,goal),prefix=routePrefix(patient,road.slice(1),patient.speed*15/20);
 return{...goal,road:copy(road),prefix:copy(prefix),healerGap:Math.hypot(goal.x-healer.x,goal.y-healer.y),nearBuildings:snapshot.buildings.map((b:any)=>({id:b.id,kind:b.kind,x:b.x,y:b.y,radius:b.radius,gap:Math.hypot(goal.x-b.x,goal.y-b.y),bodyRadius:b.radius+patient.radius,arrivalEnvelope:b.radius+patient.radius+5})).filter((b:any)=>b.gap<100)};
});
const out={classification:'Read-only native-restored exact common10425 world/nextId/all3mem. No foe/order/memory edits; no replay performed in query process.',source,input,patient:copy(patient),healer:copy(healer),ability:ABILITY_DEFS[ability],gap,inActualHealRange:gap<=ABILITY_DEFS[ability].range,threats:copy(threats),rendezvous:copy(rendezvous),escape:copy(escape),goals,worldUnchanged:isDeepStrictEqual(copy(snapshotGame(game)),saved.snapshot),nextIdUnchanged:game.nextId===saved.nextId,memoryUnchanged:isDeepStrictEqual(before,copy(memory))};
writeFileSync(dir+'/'+label+'.json',JSON.stringify(out,null,2));console.log(JSON.stringify({label,gap,healRange:out.ability.range,rendezvous,escape,goals:goals.map(g=>({label:g.label,healerGap:g.healerGap,nearBuildings:g.nearBuildings})),worldUnchanged:out.worldUnchanged,memoryUnchanged:out.memoryUnchanged},null,2));
