from pathlib import Path
import json,gzip,hashlib
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=lambda n:[json.loads(l)for l in(D/(n+'.jsonl')).read_text().splitlines()]
states=rows('states');effects=[e for e in rows('effects')if e['scriptId']=='diagnostic-public-cabin-swap'];report=json.loads((D/'report.json').read_text());cap=json.loads((D/'fixed-runtime.json').read_text())
assert len(effects)==5 and [e['command']for e in effects]==cap['extraPublicCommands']
assert all(e['legalityBefore'] is None and e['snapshotChanged'] for e in effects)
initial=states[0];first=next(s for s in states if s['tick']==202801 and s['stage']=='after-step');last=states[-1]
find=lambda s,id:next(u for u in s['tracked']if u['id'].endswith('-'+id))
unload=effects[1];leave=effects[3];entry=effects[4]
assert find(initial,'8114')['deck'] and not find(first,'8114').get('deck')
assert find(initial,'37753')['cabin'] and not find(first,'37753').get('cabin') and find(first,'37753')['deck']
assert not find(initial,'18621').get('cabin') and find(first,'18621')['cabin'] and find(last,'18621')['cabin']
assert all(find(initial,id)['hp']==find(first,id)['hp']==find(last,id)['hp'] for id in ['8114','37753','18621'])
entry_before=next(u for u in entry['before']if u['id'].endswith('-18621'));entry_after=next(u for u in entry['after']if u['id'].endswith('-18621'))
assert entry_after['order']['type']=='enterCabin' and not entry_after.get('cabin')
before_ids={u['id']for u in initial['cargo']};after_ids={u['id']for u in first['cargo']}
assert before_ids-after_ids=={'unit-p0-summoner-8114'} and after_ids-before_ids==set()
normal=[c for c in rows('commands')if c['owner']=='p0' and c['scriptId']!='diagnostic-public-cabin-swap']
out={'classification':'One finite180step native capability experiment with5 declared extra public commands, normal3AI otherwise. The swap really stowed18621, but did not increase cargo combat or prove sufficient packing/autonomous AI behavior.',
 'sourceHead':cap['head'],'range':[202800,202980],'restore':report['restore'],'sourcePre':report['sourcePre'],'sourcePost':report['sourcePost'],'frozenPre':report['frozenPre'],'frozenPost':report['frozenPost'],
 'allFiveCommandsRealLegalAndChanged':True,'fivePublicEffects':effects,
 'nativeEntry':{'tick':202801,'stage':'after-step','beforeEntryCommandStillOpen':entry_after,'actualAfterStep':find(first,'18621'),'actualFreedDeckPoint':entry_before['deck'],'quotaAfterLeave':next(s['usage']for s in states if s['stage']=='after-command' and s.get('commandIndex')==5),'quotaAfterNativeEntry':first['usage']},
 'before':{'cargoCount':len(initial['cargo']),'insideCount':sum(bool(u.get('cabin'))for u in initial['cargo']),'usage':initial['usage']},
 'after':{'cargoCount':len(first['cargo']),'insideCount':sum(bool(u.get('cabin'))for u in first['cargo']),'usage':first['usage']},
 'final':{'tick':last['tick'],'cargoCount':len(last['cargo']),'insideCount':sum(bool(u.get('cabin'))for u in last['cargo']),'usage':last['usage'],'tracked':last['tracked']},
 'cargoIdsRemovedOnly':['unit-p0-summoner-8114'],'trackedHPUnchanged':True,'normalP0Commands':normal,
 'actualNormalReaction':'202815 normal naval issued board21331 into the newly real floor opportunity; no further permanent cargo had actually boarded by202980. 202935 onward normal naval moved7979/8114 to actual shore staging goals. This finite window does not prove later failure or success.',
 'ledger':{'commands':report['counts']['commands'],'additionalPublicAttemptsAndEffects':5,'hits':report['counts']['hits'],'events':report['counts']['events'],'steps':report['counts']['steps']},
 'limits':'Initial unload removes a real crew member from cargo; the immediate22 cargo is lower than original23. No future arrival/board/entry intent is counted as real floor or force. No full-game outcome/readiness reduction/new source result. Commands/afterApply can include transient no-op generally, so proof uses each before/after and next native cabin state.',
 'inputs':{'original202800SHA256':cap['inputSHA256'],'driverSHA256':cap['driverSHA256'],'finalSHA256':sha(D/'final.json.gz')}}
(D/'actual-swap-proof.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k in ['range','allFiveCommandsRealLegalAndChanged','before','after','trackedHPUnchanged','actualNormalReaction','ledger','limits']},ensure_ascii=False))
