# 真实202800的额外公开换舱能力诊断

此分支保持固定a7e0ccaa108c7eab1ebd959ff312dd378eb8e804、1474源码和规则2/184冻结，原202800 after-step/pre-think完整world/nextId/3mem严格恢复。它不是新普通0、自动策略结果、完整比赛或装满证明；源与敌人、身体、HP、质量额度、金钱均未手改。

202800全部三方先正常规划；在P0原有两条summon公令之后、P1/P2公令之前，明确追加五条P0公令：unload到7408,6576；portrait卸8114；停船；37753离舱；18621入舱。随后全部正常三方AI运行至202980，共180原生步。没有屏蔽P0策略或修改其memory。实际PID346032，2026-10-16T06:19:57.684Z→06:20:10.025Z正常exit0，92条命令尝试含5额外公令、0hit、16ledger事件、12P0计划。

五条额外操作逐条legalityBefore为空且snapshotChanged为真；`commands`计数本身不能证明有效，因为frame afterApply也可能记录transient no-op。`actual-swap-proof.json`保留五条完整before/after，证实8114真卸至7116,6004、37753真离舱，used20→18。enter18621公令只把order变enterCabin，彼时仍open；202801真实原生step后cabin字段才出现，used18→20、free1，其原甲板点才真正释放。三名参与者HP在180步内不变。

原cargo23变22（只卸去8114）；inside仍10但成员由37753换为18621。37753在原8114的甲板点，18621已在当前真实舱门点，因此这条局部序列不需要猜未来到达或虚拟deckslot。202815正常naval确实尝试board21331利用新地面；到202980尚未有新永久cargo真正加入，后续不能从这180步推成失败或成功。202935起正常naval给7979/8114发岸上集结move，原raw保留。当前军力不因换舱凭空变强，初卸8114反而降低船载总量；未达到原required20.115569的完整装载证据仍缺。

该诊断足以证实公开卸人、真离舱、真入舱与释放实际地面的能力链；未证其它队员可实际走到目标deck布局、机械单位已装上、可出航或可胜。静态前缀与有限48配对研究另封在`cabin-repacking-static-feasibility-20261016`，未运行Game；后续compaction endpoint研究与本180步也分开归属。

`actual-202801-public-swap.png`是该真实完整状态的原生drawWorld静态渲染，不是操作证据的替代；身体、cabin和落点归属以完整字段/逐tick states为准。原a7主包、control和其它活动源均不改。原容器未提交修改的恢复缺口依然存在。
