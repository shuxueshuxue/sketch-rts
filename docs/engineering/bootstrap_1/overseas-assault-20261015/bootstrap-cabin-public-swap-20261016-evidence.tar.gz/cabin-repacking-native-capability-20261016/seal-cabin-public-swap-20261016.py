from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path('/workspace/.playtest/cabin-repacking-native-capability-20261016');P=D.parent;prefix=D.name
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[(p,f'{prefix}/{p.relative_to(D).as_posix()}')for p in sorted(D.rglob('*')) if p.is_file() and not p.is_symlink() and p.relative_to(D).parts[0]not in['node_modules','runtime-tmp']and p.name!='INDEX.json']
files += [(Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016/native-candidate-natural-from195600/frames/202800-periodic-after-step.json.gz'),f'{prefix}/archives/input-202800.json.gz'),(Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016/candidate-source.tar.gz'),f'{prefix}/archives/a7-source1474.tar.gz'),(Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-frozen-source.tar.gz'),f'{prefix}/archives/frozen-source497.tar.gz'),(Path(__file__),f'{prefix}/{Path(__file__).name}')]
base=P/'cabin-repacking-static-feasibility-20261016'
files += [(p,f'{prefix}/static-prefix/{p.relative_to(base).as_posix()}')for p in sorted(base.rglob('*'))if p.is_file()and not p.is_symlink() and p.relative_to(base).parts[0]!='node_modules']
payload=[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p)}for p,n in files]
index={'schema':'bootstrap-evidence-payload-sha256-v1','classification':'Additional5-public-command actual180step capability diagnostic; not autonomous policy/fresh0/full-match/readiness proof. Includes preceding pure static prefix feasibility, no later compaction study.','payloadCount':len(payload),'payload':payload}
idx=D/'INDEX.json';idx.write_text(json.dumps(index,indent=2)+'\n')
archive=P/'bootstrap-cabin-public-swap-20261016-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as t:
 for p,n in files:t.add(p,arcname=n,recursive=False)
 t.add(idx,arcname=prefix+'/INDEX.json',recursive=False)
expected={r['path']:r for r in payload};count=0
with tarfile.open(archive,'r|gz')as t:
 for m in t:
  assert m.isfile();f=t.extractfile(m);h=hashlib.sha256();size=0
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
  if m.name==prefix+'/INDEX.json':assert h.hexdigest()==sha(idx)
  else:r=expected.pop(m.name);assert r['sha256']==h.hexdigest()and r['bytes']==size
  count+=1
assert not expected and count==len(payload)+1
assert all(p.stat().st_size==r['bytes']and sha(p)==r['sha256']for (p,n),r in zip(files,payload))
out={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'payloadCount':len(payload),'regularCount':count,'indexSHA256':sha(idx),'allPayloadSHABytesCoverageTrue':True,'originalsUnchanged':True,'sourceHead':'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804','rulesVersion':2,'liveSourceFiles':1474,'frozenArchiveFiles':497,'frozenManifestFiles':184,'range':[202800,202980],'additionalPublicCommands':5,'commands':92,'hits':0,'events':16,'nativeSteps':180,'actualTrueEntryTick':202801,'autonomousPolicyResult':False,'crewCargoBeforeAfter':[23,22],'insidePeopleBeforeAfter':[10,10],'doesNotProve':'Original required20.115569 reached, enough cargo, all-floor arrangement feasible under actual movement, new policy success, ordinary0 or whole-game improvement.','sealedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'bootstrap-cabin-public-swap-20261016-delivery.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
