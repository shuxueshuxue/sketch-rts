import json,hashlib,pathlib,datetime
O=pathlib.Path('/workspace/.playtest/cabin-repacking-static-feasibility-20261016')
r=json.loads((O/'result.json').read_text())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
selected=next(s for s in r['swapCases'] if s['clearedIds']==['unit-p0-summoner-8114'] and s['outId']=='unit-p0-summoner-37753' and s['inId']=='unit-p0-emberRavager-18621')
commands=[v['command'] for v in selected['prefixEffects']]+[selected['leave']['command'],selected['enterIntent']['command']]
assert len(commands)==5
assert selected['currentReplacementExitPoint']=={k:selected['replacementBefore']['deck'][k] for k in ['x','y']}
assert all(v['ok'] for v in selected['prefixEffects']) and selected['leave']['ok'] and selected['enterIntent']['ok']
unloaded=selected['prefixEffects'][1]['bodyBefore'];out=selected['leave']['bodyAfter']
assert unloaded['radius']==out['radius'] and unloaded['deck']==out['deck']
summary={
 'classification':'有限静态几何/公开动作即时投影。不是实际AI执行，不是已入舱/已获胜；无Game、step、完整planner或测试。',
 'input':r['input'],'sourcePre':r['sourcePre'],'sourcePost':r['sourcePost'],'fixed':r['fixed'],
 'boundedScope':{'insideCurrentExitQueries':len(r['currentExits']),'currentClearExitCount':sum(bool(s['exitPoint']) for s in r['currentExits']),'pairedSwapCases':48,'legalLeavePairCases':36,'legalEnterIntentPairCases':30,'completedEntriesCredited':0,'canonicalAllOpenUnloadSequences':1,'conditionalAlreadyAlongsideReboardOrders':6},
 'selectedLegalActionPrefix':{'commands':commands,'allNativeStaticLegalityPassed':True,'unloadedToCurrentPickupIsland':selected['prefixEffects'][1]['bodyAfter'],'outgoingBefore':selected['outBefore'],'outgoingAfterImmediateLeave':selected['leave']['bodyAfter'],'replacementAlreadyOnDeck':selected['replacementBefore'],'replacementNativeCurrentHatchPoint':selected['currentReplacementExitPoint'],'replacementAlreadyAtNativeHatchPoint':True,'needsCourtesyYieldForAdmission':selected['hatchAdmissionMayRequireCourtesyYield'],'stateAfterLeave':selected['afterLegalLeave'],'stateAfterEnterIntent':selected['enterIntent']['after'],'entryIntentReleasedFloor':False,'immediateOpenDeckFootprintEqualsOriginal':True,'footprintEqualityExplanation':'Unloaded8114 and outgoing37753 have identical radius17 and deck point(-49.84,14.04); before any actual entry, the open body circles are unchanged despite crew identity change. No free floor is credited.','futureBodyAreaDifferenceIfEntryCompletes':selected['eventualAreaDifferenceIfLaterEntryReallyCompletes'],'nextEvidenceRequired':'实际native tick是否真正将18621置inside；未来真实boarding、总force达标与完整比赛仍未由本报告证明。'},
 'insideOutCandidates':[{k:u[k] for k in ['id','radius','rating','quotaCost']} for u in r['currentExits'] if any(u['id'].endswith(suffix) for suffix in ['-4420','-37753','-38054','-40241','-41089','-44159'])],
 'allOpenUnload':{'all13PublicPortraitsLegallyProject':r['openClear']['legal'],'hullGoal':r['fixed']['goal'],'targetGround':'当前补给pickup岛gold-satellite-0，同当前shore；不是原mission.from(2128,4560)','after':r['openClear']['after'],'shoreBodiesHPPositionsAndReach':r['openClear']['actualDerivedShoreBodies'],'alreadyAlongsideIds':r['summary']['actualAlongsideAfterClear'],'notAlongsideUnitsNeverAttachedOrReserved':True},
 'conditionalFiniteReboardResults':[{'name':p['name'],'conditionalFinal':p['final'],'placedIds':p['conditionallyPlacedIds'],'ramFloorPointExistsAtEveryProbedStep':all(s['mechanicalPointBefore'] and s['mechanicalPointAfter'] for s in p['steps']),'ramActuallyAlongsideAtAnyStep':any(s['mechanicalActuallyAlongside'] for s in p['steps']),'ramOrOtherFutureArrivalSlotReserved':False,'reachesOriginalRequired':p['final']['power']>=r['fixed']['originalRequired']} for p in r['reboardCases']],
 'inferences':['直接leave目前全被hatch占用拒绝；先卸8114是已验证合法的有限开门动作。','所选替补18621已在本船实际deck，且其当前deck点等于静态native hatch点；没有借远处walking或预留虚拟槽位。','leave37753只将20已用舱额降至18；enter意图不使其重新升至20，不立即删除18621甲板身体，也不增加总cargo force。','全13open卸后，六条有限仅已alongside条件重装都为16cargo、power12.087608511564172。该数值只描述本固定pose、无移动条件集合，不代表等待走路后的全部packing上界。','机械ram在全卸及这些6人条件重装后均有数学floor点，但它当前离hull816.0169145978674，未装、未占位、未贡献战力。','没有发现达到原required20.115569375546702的完整可执行动作链。本有限集合不足不能推出全局不可行。'],
 'limitations':r['limits'],
 'queryCorrections':[
  {'log':'query-transform-first.log','meaning':'首次TS解析仅因新独立目录缺type:module失败，未执行query；已补新目录package.json。'},
  {'log':'query-live-frozen-root-error.log','meaning':'新增proof初次误将manifest frozen hash对比live文件而提前失败；已改为git show manifest.revision:path核184原冻结文件。不是frozen实际变更；最终proof184一致。'}],
 'result':{'path':str(O/'result.json'),'sha256':sha(O/'result.json'),'bytes':(O/'result.json').stat().st_size}
}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
artifacts=[{'path':str(O/n),'sha256':sha(O/n),'bytes':(O/n).stat().st_size} for n in ['query.ts','query.log','query-transform-first.log','query-live-frozen-root-error.log','package.json','result.json','summary.json','summarize.py']]
index={'classification':'静态研究独立封存索引；不更改a7源或任何既有sealed D。','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'directory':str(O),'source':r['sourcePost'],'inputProvenance':r['provenance'],'artifacts':artifacts,'exclusions':['No Game construction, restore, step, issuePlayerCommand, planner, tests or native simulation.','No actual boarding, entry completion, mechanical slot reservation, victory or bootstrap acceptance credited.','No file edit in fixed source or existing prior D directories.'],'runtimeTmp':'runtime-tmp仅含tsx执行缓存；非源码或对局。','selectedPrefixContract':{'steps':len(commands),'allStaticallyLegal':True,'entryIntentOnly':True},'completion':'当前有限范围已完成；父执行者独占后续真实native能力诊断。'}
(O/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':sha(O/'summary.json'),'index':sha(O/'index.json'),'result':sha(O/'result.json'),'query':sha(O/'query.ts'),'source':r['sourcePost']},indent=2))
