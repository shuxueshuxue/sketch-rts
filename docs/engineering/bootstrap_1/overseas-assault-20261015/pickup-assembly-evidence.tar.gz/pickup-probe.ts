import {shipBodyClearanceAtHeading} from '../../src/shared/ship-collisions';
import {clearTransferLanes} from '../../src/ai/policy/transfer-lanes';
import {readFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame,issuePlayerCommand} from '../../src/shared/sim';
import {boardingBerth,clearBoardingBerth} from '../../src/shared/naval';
import {nearestShipPose} from '../../src/shared/ship-navigation';
import {distanceToHull} from '../../src/shared/ship-geometry';
import {walkableGoal,sameGround} from '../../src/shared/terrain';
import {canBoard} from '../../src/shared/decks';
const p='.playtest/overseas-assault-20261015/summoner-crossing-opening.json',r=JSON.parse(readFileSync(p,'utf8')),row=r.rows.at(-1),frame=JSON.parse(readFileSync(p+'.frames/96000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const boat=game.units.find(u=>u.id==='unit-p0-carrier-50029')!,mission=row.players.p0.policy.naval.ferries[boat.id],point=mission.pickup??mission.from,land=walkableGoal(game.map,point.x,point.y);
const candidates=game.units.filter(u=>u.owner==='p0'&&!u.deck&&!u.expiresTick&&u.kind!=='worker'&&sameGround(game.map,u,land)&&canBoard(boat,u,game.units));
console.log(JSON.stringify({point,land,pose:nearestShipPose(game.map,boat,point),candidates:candidates.map(u=>({id:u.id,kind:u.kind,berth:boardingBerth(game.map,u,boat)}))}));
if(process.argv.includes('--board')){issuePlayerCommand(game,'p0',{type:'board',unitIds:candidates.map(u=>u.id),transportId:boat.id});issuePlayerCommand(game,'p0',{type:'stop',unitIds:[boat.id]});}
for(const u of candidates){const b=boardingBerth(game.map,u,boat)!;console.log(JSON.stringify({id:u.id,clear:clearBoardingBerth(game.map,u,boat,b,game.units),noBystanders:clearBoardingBerth(game.map,u,boat,b,game.units.filter(x=>x.deck||x===boat)),order:u.order}));}
if(process.argv.includes('--blockers')){const b=boardingBerth(game.map,candidates[0]!,boat)!;console.log(JSON.stringify({blockers:game.units.filter(u=>!shipBodyClearanceAtHeading(game.map,boat,b.heading!,[u])(b)).map(u=>({id:u.id,kind:u.kind,x:u.x,y:u.y,order:u.order,deck:u.deck}))}));process.exit(0);}
for(let i=0;i<=3000;i++){if(i%300===0)console.log(JSON.stringify({tick:game.tick,x:boat.x,y:boat.y,order:boat.order,shoreGap:distanceToHull(boat,land),heading:boat.sailing?.heading,loaded:candidates.filter(u=>u.deck?.shipId===boat.id).map(u=>u.id),waiting:candidates.map(u=>({id:u.id,x:u.x,y:u.y,order:u.order}))}));if(process.argv.includes('--clear')&&i%15===0)for(const c of clearTransferLanes(snapshotGame(game),'p0'))issuePlayerCommand(game,'p0',c);stepGame(game);}
