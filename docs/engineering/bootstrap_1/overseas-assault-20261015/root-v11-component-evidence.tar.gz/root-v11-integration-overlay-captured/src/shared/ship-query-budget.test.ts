import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from './sim';
import { shipRouteTraffic } from './ship-avoidance';
import { planShipRoute, planVoyageRoute } from './ship-navigation';

it('rejects an unfinished native traffic search without the terrain-only fallback when explicitly requested', () => {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL('./sim/fixtures/transit-traffic-budget.json.gz', import.meta.url))).toString());
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), boat = snapshot.units.find(unit => unit.id === 'query-carrier')!;
  const traffic = shipRouteTraffic(snapshot.map, boat, snapshot.units), original = JSON.stringify(snapshot);
  const ordinary = planShipRoute(snapshot.map, boat, saved.goal, traffic, 1024);
  expect(ordinary).toEqual(saved.source.expectedDefault);
  expect(ordinary.partial).toBe(false);
  expect(Math.hypot(ordinary.points.at(-1)!.x - saved.goal.x, ordinary.points.at(-1)!.y - saved.goal.y)).toBeGreaterThan(8);
  const bounded = planShipRoute(snapshot.map, boat, saved.goal, traffic, 1024, false, { terrainFallback: false });
  expect(bounded.points).toEqual(ordinary.points);
  expect(bounded.partial).toBe(true);
  expect(planVoyageRoute(snapshot.map, boat, saved.goal, traffic, 1024, { terrainFallback: false }).partial).toBe(true);
  expect(JSON.stringify(snapshot)).toBe(original);
});
