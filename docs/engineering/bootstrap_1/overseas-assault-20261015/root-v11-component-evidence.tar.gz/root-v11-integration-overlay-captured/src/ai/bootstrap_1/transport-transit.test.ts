import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, restoreSnapshotIntoGame, snapshotGame, issuePlayerCommand, stepGame } from '../../shared/sim';
import { bootstrapPolicyContext, BOOTSTRAP_VERSIONS } from './policy';
import { planTransportTransit, transportTransitDisks } from './transport-transit';
import { transitReference, planTransitLeg } from '../policy/transit-route';
import { transitMotionClear, transitPlanningKey, transitRouteClear } from '../policy/transit-route';
import { planBootstrapNaval } from './expedition-recovery';
import { shipMotionLimits } from '../../shared/ship-handling';

function checkpoint(tick: number) {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/transport-transit-${tick}.json.gz`, import.meta.url))).toString());
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  return { game, memory: saved.policies.p0, saved };
}
const shipId = 'unit-p0-carrier-50029';

it.each(BOOTSTRAP_VERSIONS)('%s continues the actual certified native prefix before its hazard approaches', version => {
  const { game, memory } = checkpoint(166800), snapshot = snapshotGame(game);
  const original = JSON.stringify(snapshot), options = bootstrapPolicyContext(snapshot, 'p0', version, { memory, teams: game.teams });
  const commands = planTransportTransit(snapshot, 'p0', options, [{ type: 'unload', unitIds: [shipId], x: 2192, y: 6096 }]);
  expect(commands.some(command => command.type === 'unload')).toBe(true);
  expect(commands.some(command => 'unitIds' in command && command.unitIds.includes(shipId))).toBe(true);
  expect(memory.naval.ferries[shipId].transit).toBeUndefined();
  expect(JSON.stringify(snapshot)).toBe(original);
});

it.each(['creep', 'live-fire', 'final-landing', 'service'] as const)('keeps the existing mission controller for %s', state => {
  const { game, memory } = checkpoint(166800), boat = game.units.find(unit => unit.id === shipId)!;
  const mission = memory.naval.ferries[shipId], original = [{ type: 'unload' as const, unitIds: [shipId], x: 2192, y: 6096 }];
  if (state === 'creep') Object.assign(mission, { purpose: 'creep', riderId: 'rider' });
  if (state === 'final-landing') Object.assign(mission.to, { x: boat.x - 100, y: boat.y });
  if (state === 'live-fire') Object.assign(boat, { x: 6054.924561502759, y: 5785.075438497242 });
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const result = planTransportTransit(snapshot, 'p0', options, original, new Set(state === 'service' ? [shipId] : []));
  expect(result.filter(command => 'unitIds' in command && command.unitIds.includes(shipId))).toEqual(original);
});

it('never declares the already bombarded real 87600 pickup a safe departure', () => {
  const { game, memory } = checkpoint(87600), snapshot = snapshotGame(game), boat = snapshot.units.find(unit => unit.id === 'unit-p0-carrier-3824')!;
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
  const disks = transportTransitDisks(snapshot, boat, memory.naval.ferries[boat.id], options);
  expect(disks.some(disk => Math.hypot(disk.x - boat.x, disk.y - boat.y) < disk.radius)).toBe(true);
  const result = transitReference(snapshot, boat, memory.naval.ferries[boat.id].pickup, disks);
  expect(result.expanded).toBe(0);
  expect(result.complete).toBe(false);
});

it('serializes finite failed candidates and does not call an exhausted reference an impossible voyage', () => {
  const { game, memory } = checkpoint(167400), snapshot = snapshotGame(game), boat = snapshot.units.find(unit => unit.id === shipId)!;
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const mission = memory.naval.ferries[shipId], disks = transportTransitDisks(snapshot, boat, mission, options);
  const reference = transitReference(snapshot, boat, mission.to, disks);
  expect(reference.expanded).toBeLessThanOrEqual(2048);
  expect(reference.points.length).toBeGreaterThan(0);
  let sawProposal = false;
  for (let tries = 0; tries < 40; tries++) {
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
    for (const command of planTransportTransit(snapshot, 'p0', options, [])) issuePlayerCommand(game, 'p0', command);
    const pending = memory.naval.ferries[shipId].transit;
    if (pending.proposal) {
      sawProposal = true;
      expect(JSON.parse(JSON.stringify(pending))).toEqual(pending);
      // A proposed second leg is only hypothetical. It never moves the ship
      // until one native connector from the first leg's arrival is proved.
      expect(pending.mark).toBeUndefined();
    }
    if (memory.naval.ferries[shipId].transit.mark) break;
    for (let tick = 0; tick < 15; tick++) stepGame(game);
  }
  const query = memory.naval.ferries[shipId].transit;
  expect(query.mark).toBeDefined();
  expect(sawProposal).toBe(true);
  expect(JSON.parse(JSON.stringify(query))).toEqual(query);
  const now = snapshotGame(game), current = now.units.find(unit => unit.id === shipId)!;
  expect(planTransitLeg(now, current, query.mark, transportTransitDisks(now, current, mission, options))).toBeDefined();
}, 60000);

it('preserves an ordinary native onward point instead of stranding the v1 corner', () => {
  const { game, memory } = checkpoint(167400);
  let selected: { x: number; y: number } | undefined;
  for (let tries = 0; tries < 40 && !selected; tries++) {
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
    const commands = planTransportTransit(snapshot, 'p0', options, []);
    for (const command of commands) {
      if (command.type === 'move' && command.unitIds.includes(shipId)) selected = command;
      issuePlayerCommand(game, 'p0', command);
    }
    if (!selected) for (let tick = 0; tick < 15; tick++) stepGame(game);
  }
  expect(selected).toBeDefined();
  const snapshot = snapshotGame(game), boat = snapshot.units.find(unit => unit.id === shipId)!;
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const disks = transportTransitDisks(snapshot, boat, memory.naval.ferries[shipId], options);
  const leg = planTransitLeg(snapshot, boat, selected!, disks)!;
  expect(leg).toBeDefined();
  const continuation = memory.naval.ferries[shipId].transit.continuation;
  expect(continuation).toBeDefined();
  const end = leg.points.at(-1)!;
  expect(planTransitLeg(snapshot, { ...boat, ...end, sailing: { ...boat.sailing!, heading: end.heading, speed: 0 } }, continuation, disks)).toBeDefined();
}, 60000);

it('executes the complete short native maneuver from the actual v1 stationary corner using only public move', () => {
  const { game, memory } = checkpoint(168300), snapshot = snapshotGame(game), ship = game.units.find(unit => unit.id === shipId)!;
  const goal = { x: 6336, y: 5696 }, options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const forecast = planTransitLeg(snapshot, snapshot.units.find(unit => unit.id === shipId)!, goal,
    transportTransitDisks(snapshot, snapshot.units.find(unit => unit.id === shipId)!, memory.naval.ferries[shipId], options));
  expect(forecast).toBeDefined();
  const hp = ship.hp, crew = game.units.filter(unit => unit.deck?.shipId === shipId).map(unit => ({ id: unit.id, hp: unit.hp }));
  issuePlayerCommand(game, 'p0', { type: 'move', unitIds: [shipId], ...goal, avoidCombat: true });
  for (let step = 0; step < 480 && Math.hypot(ship.x - goal.x, ship.y - goal.y) > 8; step++) stepGame(game);
  expect(Math.hypot(ship.x - goal.x, ship.y - goal.y)).toBeLessThanOrEqual(8);
  expect(ship.hp).toBe(hp);
  for (const unit of crew) expect(game.units.find(actual => actual.id === unit.id)!.hp).toBe(unit.hp);
}, 60000);

it('discards a staged first-leg proof when a threat moves onto that native curve', () => {
  const { game, memory } = checkpoint(166800), snapshot = snapshotGame(game);
  const boat = snapshot.units.find(unit => unit.id === shipId)!;
  const mission = memory.naval.ferries[shipId];
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const mark = { x: 7104, y: 4800 };
  const points = planTransitLeg(snapshot, boat, mark, transportTransitDisks(snapshot, boat, mission, options))!.points;
  expect(points).toBeDefined();
  mission.transit = { key: `assault:sailing:${mission.targetId}:${mission.to.x}:${mission.to.y}`, goal: mission.to,
    candidates: [], next: 0, referenceComplete: false, queryKey: 'previous hazards', proposal: {
      mark, origin: { x: boat.x, y: boat.y, heading: boat.sailing!.heading }, end: points.at(-1)!, points, base: points,
      inputKey: transitPlanningKey(snapshot, boat),
      candidates: [{ x: 7000, y: 4700 }, { x: 6800, y: 4600 }], next: 0 } };
  Object.assign(game.units.find(unit => unit.id === 'guard-1-0')!, mark);
  const changed = snapshotGame(game), updated = bootstrapPolicyContext(changed, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const commands = planTransportTransit(changed, 'p0', updated, []);
  expect(commands.some(command => command.type === 'move' && command.unitIds.includes(shipId))).toBe(false);
  expect(mission.transit.proposal).toBeUndefined();
});

it('retains untried candidates across a moving threat signature', () => {
  const { game, memory } = checkpoint(167400);
  const think = () => {
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
    planTransportTransit(snapshot, 'p0', options, []);
  };
  think();
  const query = memory.naval.ferries[shipId].transit, candidates = structuredClone(query.candidates), next = query.next;
  game.units.find(unit => unit.id === 'guard-1-0')!.x += 65;
  game.tick += 15;
  think();
  expect(memory.naval.ferries[shipId].transit).toBe(query);
  expect(query.candidates).toEqual(candidates);
  expect(query.next).toBeGreaterThanOrEqual(next);
});

it('holds the hull while preserving existing shore board ownership across a complete naval think', () => {
  const { game, memory } = checkpoint(86400), boatId = 'unit-p0-carrier-3824';
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
  const waiting = snapshot.units.filter(unit => !unit.deck && unit.order.type === 'board' && unit.order.transportId === boatId);
  expect(waiting.length).toBeGreaterThan(0);
  const crew = [...memory.naval.ferries[boatId].crewIds];
  const mission = memory.naval.ferries[boatId];
  mission.transit = { key: `${mission.purpose}:${mission.phase}:${mission.targetId}:${mission.pickup.x}:${mission.pickup.y}`,
    goal: mission.pickup, candidates: [], next: 0, referenceComplete: false, queryKey: '', pendingReference: true };
  const result = planTransportTransit(snapshot, 'p0', options, [{ type: 'board', unitIds: waiting.map(unit => unit.id), transportId: boatId }]);
  expect(result.some(command => command.type === 'board' && command.transportId === boatId)).toBe(false);
  for (const command of result) issuePlayerCommand(game, 'p0', command);
  expect(waiting.every(unit => game.units.find(actual => actual.id === unit.id)!.order.type === 'board')).toBe(true);
  expect(memory.naval.ferries[boatId].crewIds).toEqual(crew);
  const boat = game.units.find(unit => unit.id === boatId)!, position = { x: boat.x, y: boat.y };
  for (let tick = 0; tick < 15; tick++) stepGame(game);
  expect({ x: boat.x, y: boat.y }).toEqual(position);
  const next = snapshotGame(game), updated = bootstrapPolicyContext(next, 'p0', 'v9_archer', { memory, teams: game.teams });
  planBootstrapNaval(next, 'p0', updated);
  expect(memory.naval.ferries[boatId].crewIds).toEqual(expect.arrayContaining(crew));
});

it('releases its hold before a new service owner boards a deck worker', () => {
  const { game, memory } = checkpoint(86400), boatId = 'unit-p0-carrier-3824';
  issuePlayerCommand(game, 'p0', { type: 'holdPosition', unitIds: [boatId] });
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
  const mission = memory.naval.ferries[boatId];
  mission.transit = { key: 'old task', goal: mission.pickup, candidates: [], next: 0, referenceComplete: false, queryKey: '' };
  const crew = snapshot.units.find(unit => unit.owner === 'p0' && unit.deck && unit.deck.shipId !== boatId)!;
  expect(crew).toBeDefined();
  const commands = planTransportTransit(snapshot, 'p0', options, [{ type: 'board', unitIds: [crew.id], transportId: boatId }], new Set([boatId]));
  expect(commands[0]).toEqual({ type: 'stop', unitIds: [boatId] });
  for (const command of commands) issuePlayerCommand(game, 'p0', command);
  expect(game.units.find(unit => unit.id === crew.id)!.order.type).toBe('board');
  expect(mission.transit).toBeUndefined();
});

it('finishes a finite query before physical-stall cancellation without pretending the hull moved', () => {
  const { game, memory } = checkpoint(86400), boatId = 'unit-p0-carrier-3824';
  const boat = game.units.find(unit => unit.id === boatId)!, mission = memory.naval.ferries[boatId];
  mission.progress = { tick: game.tick - 900, x: boat.x, y: boat.y, heading: boat.sailing!.heading, phase: 'loading', crew: '' };
  const lastPhysicalTick = mission.progress.tick;
  mission.transit = { key: `${mission.purpose}:${mission.phase}:${mission.targetId}:${mission.pickup.x}:${mission.pickup.y}`,
    goal: mission.pickup, candidates: [{ x: 3392, y: 7488 }], next: 0, referenceComplete: false, queryKey: '' };
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
  planBootstrapNaval(snapshot, 'p0', options);
  expect(mission.phase).toBe('loading');
  expect(mission.progress.tick).toBe(lastPhysicalTick);
  mission.transit.next = mission.transit.candidates.length;
  delete mission.transit.proposal;
  delete mission.transit.pendingReference;
  game.tick += 15;
  const exhausted = snapshotGame(game), next = bootstrapPolicyContext(exhausted, 'p0', 'v9_archer', { memory, teams: game.teams });
  planBootstrapNaval(exhausted, 'p0', next);
  expect(mission.phase).toBe('return');
});

it.each([87300, 88200])('preserves the real %s warning corridor with a full physical observation interval', tick => {
  const { game, memory } = checkpoint(tick), snapshot = snapshotGame(game), boatId = 'unit-p0-carrier-3824';
  const boat = snapshot.units.find(unit => unit.id === boatId)!, mission = memory.naval.ferries[boatId];
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
  const warning = transportTransitDisks(snapshot, boat, mission, options), physical = transportTransitDisks(snapshot, boat, mission, options, 0);
  expect(transitMotionClear(boat, warning, 15)).toBe(false);
  expect(transitMotionClear(boat, physical, 15)).toBe(true);
  const mark = structuredClone(mission.transit.mark);
  const commands = planTransportTransit(snapshot, 'p0', options, []);
  expect(commands.some(command => 'unitIds' in command && command.unitIds.includes(boatId))).toBe(false);
  expect(mission.transit.mark).toEqual(mark);
});

it('does not mistake a historical arrivedAt for completion of a new ordinary move', () => {
  const { game, memory } = checkpoint(166800), boat = game.units.find(unit => unit.id === shipId)!;
  const mark = { ...boat.arrivedAt! };
  expect(Math.hypot(mark.x - boat.x, mark.y - boat.y)).toBeGreaterThan(800);
  issuePlayerCommand(game, 'p0', { type: 'move', unitIds: [shipId], ...mark, avoidCombat: true });
  for (let ticks = 0; !boat.sailing!.route?.points.length && ticks < 120; ticks++) stepGame(game);
  expect(boat.order.type).toBe('move');
  expect(boat.arrivedAt).toEqual(mark);
  const snapshot = snapshotGame(game), mission = memory.naval.ferries[shipId];
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const query = { key: `${mission.purpose}:${mission.phase}:${mission.targetId}:${mission.to.x}:${mission.to.y}`,
    goal: mission.to, candidates: [], next: 0, referenceComplete: false, queryKey: '', mark };
  mission.transit = query;
  const commands = planTransportTransit(snapshot, 'p0', options, []);
  expect(mission.transit).toBe(query);
  expect(mission.transit.mark).toEqual(mark);
  expect(commands.some(command => 'unitIds' in command && command.unitIds.includes(shipId))).toBe(false);
});

it('holds a marked voyage at a thin neutral provocation boundary before another helm interval', () => {
  const { game, memory } = checkpoint(169500), boatId = shipId, boat = game.units.find(unit => unit.id === boatId)!;
  const mission = memory.naval.ferries[boatId], target = game.units.find(unit => unit.id === 'guard-2-0')!;
  const context = (snapshot: ReturnType<typeof snapshotGame>) => bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const initial = snapshotGame(game), physical = transportTransitDisks(initial, initial.units.find(unit => unit.id === boatId)!, mission, context(initial), 0);
  const threat = physical.find(disk => disk.id === target.id)!;
  const heading = Math.atan2(mission.transit.mark.y - boat.y, mission.transit.mark.x - boat.x);
  const motion = shipMotionLimits(boat).speed * 15 / 20;
  // Construct a boundary case from the real active voyage, without changing
  // hulls, neutral weapon rules, native paths, or the terrain. It is not a
  // historical encounter: the one neutral's position is intentionally moved.
  target.x = boat.x - Math.cos(heading) * (threat.radius + motion / 2);
  target.y = boat.y - Math.sin(heading) * (threat.radius + motion / 2);
  const snapshot = snapshotGame(game), options = context(snapshot), current = snapshot.units.find(unit => unit.id === boatId)!;
  const warning = transportTransitDisks(snapshot, current, mission, options);
  expect(transitRouteClear(current, current.sailing!.route!.points, warning)).toBe(true);
  expect(transitMotionClear(current, transportTransitDisks(snapshot, current, mission, options, 0), 15)).toBe(false);
  const commands = planTransportTransit(snapshot, 'p0', options, []);
  expect(commands.some(command => command.type === 'holdPosition' && command.unitIds.includes(boatId))).toBe(true);
  expect(commands.some(command => command.type === 'move' && command.unitIds.includes(boatId))).toBe(false);
  const before = { x: boat.x, y: boat.y, hp: boat.hp }, crew = game.units.filter(unit => unit.deck?.shipId === boatId).map(unit => ({ id: unit.id, hp: unit.hp }));
  for (const command of commands) issuePlayerCommand(game, 'p0', command);
  for (let tick = 0; tick < 15; tick++) stepGame(game);
  expect({ x: boat.x, y: boat.y, hp: boat.hp }).toEqual(before);
  expect(game.units.filter(unit => crew.some(before => before.id === unit.id)).map(unit => ({ id: unit.id, hp: unit.hp }))).toEqual(crew);
});

it('replans from the real idle pose instead of accepting an old far-away arrivedAt', () => {
  const { game, memory } = checkpoint(166800), boat = game.units.find(unit => unit.id === shipId)!;
  const historical = { ...boat.arrivedAt! };
  issuePlayerCommand(game, 'p0', { type: 'stop', unitIds: [shipId] });
  expect(boat.order.type).toBe('idle');
  expect(boat.arrivedAt).toEqual(historical);
  expect(Math.hypot(boat.x - historical.x, boat.y - historical.y)).toBeGreaterThan(800);
  const mission = memory.naval.ferries[shipId];
  mission.transit = { key: `${mission.purpose}:${mission.phase}:${mission.targetId}:${mission.to.x}:${mission.to.y}`,
    goal: mission.to, candidates: [], next: 0, referenceComplete: false, queryKey: '', mark: historical,
    continuation: { x: historical.x - 128, y: historical.y } };
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', { memory, teams: game.teams });
  const commands = planTransportTransit(snapshot, 'p0', options, []), query = mission.transit;
  expect(query.mark).toBeUndefined();
  expect(query.candidates[0]).toEqual({ x: historical.x - 128, y: historical.y });
  if (query.proposal) expect(query.proposal.origin).toEqual({ x: boat.x, y: boat.y, heading: boat.sailing!.heading });
  expect(commands.some(command => command.type === 'move' && command.unitIds.includes(shipId))).toBe(false);
});
