Combined root71c + exact captured AI/shared overlay

Source: root-v11-integration-source.json and source.tar.gz;1589 files unchanged through all component windows and final check. Overlay10tracked/21explicitnew; rules2 frozen184 all match. Capture17:59:28 UTC15Oct2026.

Actual public naval/initial-crew ability component windows, NOT complete both-AI matches. Integrated naval also calls landedCombat; its commands are included. All public commands, full frame worlds, nextId and both memories retained. p1 keeps existing native orders. See findings.json for scope correction to frozen driver header.

87300->89100: actual corridor progress, hullHP unchanged,0monitored hit; pickup not complete in this window.
92400->92656: all original3 actually aboard92644, new pickup/public move92655; combined memory retains only original3crewIds, unlike isolatedv11 old8.
173100->173761: actual4ballista unloaded, mission gone, hull480/crew150each,0hit. Old isolatedv11 ended174031; do not silently equate source/pose.
All3 full JSON checkpoint resumes match snapshot/nextId/both memories. TSC0.

103935 extra1046hold is current query-model rejection; old15entries exactly unchanged, only extra1046transit memory. No-extra-warning model is conservative capability/provocation coverage, NOT observed shooting. Public one-output240native-tick comparison reproduced no neutral aggression/crew injury. Old commands moved with tiny friendly ship collision; newhold stopped unharmed. This cannot establish safe onward travel or match benefit.

Evidence manifest records every member hash except itself; archive-check verifies every recorded member against package content. Source manifest/inputs are included in nested source archive. Root future production/test changes are distinct and must not alter this frozen source. Old stopped-container uncommitted-work recovery gap and full match/generalization requirements remain.
