import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {createCanvas} from '/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js';
import {installHeadlessCanvas} from '/tmp/sketch-rts-crew-rendezvous-live-maneuver-control/src/recorder/record.ts';
import {drawWorld} from '/tmp/sketch-rts-crew-rendezvous-live-maneuver-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/tmp/sketch-rts-crew-rendezvous-live-maneuver-control/src/client/unit-facing.ts';
const D='/tmp/bootstrap-crew-rendezvous-coast-baseline-20261016';
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),rows=[];installHeadlessCanvas();
for(const spec of [{label:'actual-old1942-before-friendly-contact',path:'first-damage-before.json.gz'},{label:'actual-old1943-after-friendly-contact',path:'first-damage-after.json.gz'},{label:'actual-candidate2520-repair-completed',path:'candidate-38f5/final.json.gz'}]){
 const raw=readFileSync(D+'/'+spec.path),f=JSON.parse(gunzipSync(raw).toString()),before=sha(JSON.stringify(f)),view={x:1230,y:1620,width:1200,height:1050,zoom:2};
 const canvas=createCanvas(view.width,view.height);drawWorld({ctx:canvas.getContext('2d')as any,snapshot:f.snapshot,view,now:f.snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'player',selectedIds:new Set(['unit-player-warship-1000','unit-player-transport-1001','unit-player-worker-1002'])});
 const png=canvas.toBuffer('image/png');writeFileSync(D+'/'+spec.label+'.png',png);if(sha(JSON.stringify(f))!==before)throw new Error('render changed input');
 rows.push({...spec,view,tick:f.snapshot.tick,inputSHA256:sha(raw),pngSHA256:sha(png),inputUnchanged:true});
}
writeFileSync(D+'/native-render-metadata.json',JSON.stringify({classification:'Native client drawWorld post-recording actual saved snapshots; no new Game/step/commands or visual geometry edits; not browser screenshots.',rendererHead:'38f5dd79ae588d578dce15b9baa2cd41f20f2a4b',rows},null,2)+'\n');
