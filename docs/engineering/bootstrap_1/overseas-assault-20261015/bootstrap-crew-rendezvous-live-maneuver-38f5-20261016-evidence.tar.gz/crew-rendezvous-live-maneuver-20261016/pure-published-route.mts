import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {shipTraffic} from '/tmp/sketch-rts-crew-rendezvous-live-maneuver-control/src/shared/ship-avoidance.ts';
import {hullPassageClear} from '/tmp/sketch-rts-crew-rendezvous-live-maneuver-control/src/shared/ship-navigation.ts';
const D='/tmp/bootstrap-crew-rendezvous-coast-baseline-20261016',initial=JSON.parse(gunzipSync(readFileSync(D+'/initial.json.gz')).toString()),w=initial.snapshot,raw=readFileSync(D+'/ticks.jsonl','utf8').split('\n').filter(Boolean).map(s=>JSON.parse(s));
const first=raw.find(r=>r.target.sailing.route?.points.length),route=first.target.sailing.route,ship=w.units.find((u:any)=>u.kind==='transport'),before=JSON.stringify(initial),local=shipTraffic(ship,w.units),all=shipTraffic(ship,w.units,Infinity);
let from={x:route.startX,y:route.startY,heading:route.startHeading};const rows=[];
for(const [index,point]of route.points.entries()){
 rows.push({index,from,to:point,localClear:local(from,point),allShipsClear:all(from,point),terrainClear:hullPassageClear(w.map,ship,from,point)});from=point;
}
if(JSON.stringify(initial)!==before)throw new Error('query changed input');
writeFileSync(D+'/PURE-PUBLISHED-ROUTE.json',JSON.stringify({classification:'Pure geometry of actual first-published tick2 complete route (41 points) against unchanged original initial world, no new Game/step or hypothetical plan. Every actual original first route point is preserved.',publishedAtTick:first.tick,localHasTraffic:local.hasTraffic,allShipsHasTraffic:all.hasTraffic,rows,unchanged:true,earlierPureCauseClarification:'PURE-CAUSE.json publishedRemainingSegmentsAtLiveWorld first row combined original route.start with current remaining first point and is not an actual published segment; do not use that row as route proof. This report uses the complete original tick2 route with actual successive poses. The exact1942 nativeStep/derivedImpact in PURE-CAUSE is valid.'},null,2)+'\n');
console.log(JSON.stringify({publishedAtTick:first.tick,points:rows.length,unsafe:rows.filter(r=>!r.allShipsClear),allLocalClear:rows.every(r=>r.localClear),allTerrainClear:rows.every(r=>r.terrainClear)}));
