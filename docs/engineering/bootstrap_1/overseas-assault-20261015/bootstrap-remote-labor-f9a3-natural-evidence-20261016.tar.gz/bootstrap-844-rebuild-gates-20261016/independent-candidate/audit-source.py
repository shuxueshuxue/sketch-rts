"""Offline commit/blob/inventory audit only. Does not execute game or policy code."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
CONTROL = Path('/workspace/sketch-rts-remote-labor-capital-control')
OLD = Path('/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016')
NEW = HERE.parent
BASE = 'f5081ad3cc012f7f4a442383f4818ed23281cc37'
FIXED = 'f9a3f731f33020605bec21099929fab0c6b14bb3'
ORIGINAL = '84474d599f1886ca0ff32b3edf4897fcdbce9e21'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def inv(rows):
    result = {row['path']: row['sha256'] for row in rows}
    assert len(result) == len(rows)
    return result


def archive(revision, wanted):
    blob = subprocess.check_output(['git', 'archive', revision, '--', *sorted(wanted)], cwd=CONTROL)
    result = {}
    with tarfile.open(fileobj=io.BytesIO(blob), mode='r:') as stream:
        for member in stream:
            if member.isfile() and member.name in wanted:
                result[member.name] = sha(stream.extractfile(member).read())
    assert set(result) == set(wanted)
    return result


original = inv(read(OLD / 'v3-natural15855/source-preflight.json')['files'])
original_post = inv(read(OLD / 'v3-natural15855/source-postflight.json')['source']['files'])
baseline_pre = read(NEW / 'closure27600-28200-source-preflight.json')
baseline = inv(baseline_pre['inherited'] + baseline_pre['extras'])
candidate_pre = read(NEW / 'candidate27600-28200-source-preflight.json')
candidate_post = read(NEW / 'candidate27600-28200-source-postflight.json')
candidate = inv(candidate_pre['inherited'] + candidate_pre['extras'])
candidate_after = inv(candidate_post['source']['inherited'] + candidate_post['source']['extras'])
base_blobs = archive(BASE, original)
original_blobs = archive(ORIGINAL, original)
candidate_blobs = archive(FIXED, candidate)
candidate_disk = {name: sha((CONTROL / name).read_bytes()) for name in candidate}
changed = sorted(name for name in original if candidate[name] != original[name])
added = sorted(set(candidate) - set(original))
outside_runtime_diff = subprocess.check_output(
    ['git', 'diff', '--name-only', ORIGINAL, BASE], cwd=CONTROL, text=True).splitlines()
assert not (set(outside_runtime_diff) & set(original))
assert len(original) == 1467 and len(candidate) == 1470
assert original == original_post == baseline == original_blobs == base_blobs
assert candidate == candidate_after == candidate_blobs == candidate_disk
assert len(changed) == 2 and len(added) == 3
assert inv(candidate_post['frozenPre']) == inv(candidate_post['frozenPost'])
assert len(candidate_post['frozenPre']) == 497
report = {
    'classification': 'Independent offline hash/commit-blob audit; no policy query, test, tsc or simulation.',
    'base': BASE, 'original': ORIGINAL, 'fixedCandidate': FIXED,
    'originalRuntimeInventory': str(OLD / 'v3-natural15855/source-preflight.json'),
    'originalRuntimeFiles': len(original),
    'f508CommitBlobsEqualAll1467Sealed844PrePostAndBaselineWindowFiles': True,
    'original844CommitBlobsEqualAll1467': True,
    'f508Vs844ChangesOutsideRuntimeInventory': outside_runtime_diff,
    'candidateRuntimeFiles': len(candidate),
    'candidateFixedCommitDiskPrePostAll1470Exact': True,
    'changed': changed, 'added': added,
    'candidateFrozenPrePost497Exact': True,
    'portableCapsuleBoundary': 'All1467 entries match sealed844 inventory and exact844/f508 commit blobs. The earlier capsule+patch rebuild verification is referenced, not re-executed here.',
    'portableCapsuleVerification': str(OLD / 'PORTABLE-REBUILD-VERIFICATION.json'),
    'baselineReuseBoundary': 'Existing actual844 continuation from27600 through its96245 terminal is a byte-matched runtime baseline forf508. This does not make the changed candidate equal to that outcome, an ordinary0 run, or a generalization test.',
    'scriptSHA256': sha(Path(__file__).read_bytes()),
}
(HERE / 'source-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
