"""Offline raw ledger/frame audit. No game, planner, test or comparator execution."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
D = OUT.parent
OLD = Path('/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016')
UID = 'unit-p0-horseArcher-4294'


def read(path):
    return json.loads(Path(path).read_text())


def frame(path):
    return json.loads(gzip.decompress(Path(path).read_bytes()))


def rows(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(rows):
    result = {row['path']: row['sha256'] for row in rows}
    assert len(result) == len(rows)
    return result


common_path = OLD / 'v3-natural15855/frames/27600.json.gz'
common = frame(common_path)
focus_initial = frame(D / 'candidate27600-28200.frames/27600.json.gz')
focus_final = frame(D / 'candidate27600-28200-terminal.json.gz')
assert focus_initial == common
assert focus_final == frame(D / 'candidate27600-28200.frames/28200.json.gz')
focus_restore = read(D / 'candidate27600-28200-restore.json')
assert all(focus_restore['checks'].values())
assert focus_restore['sha256'] == digest(common_path)
assert common['setup']['rulesVersion'] == 2
assert set(common['memories']) == {'p0', 'p1', 'p2'}
assert all(unit['hp'] > 0 for unit in common['snapshot']['units'])
results = {}

for label, directory, extra_death, extra_hits in [
    ('baseline844', OLD / 'v3-natural15855', None, None),
    ('candidateF9a', D / 'candidate-natural28200', D / 'candidate27600-28200-native-deaths.jsonl', D / 'candidate27600-28200-native-hits.jsonl'),
]:
    report = read(directory / 'report.json')
    final = frame(directory / 'final.json.gz')
    initial = frame(report['input'])
    restore = read(directory / 'restore.json')
    assert restore['inputSHA256'] == digest(report['input'])
    assert all(restore['checks'].values())
    if label == 'candidateF9a':
        assert initial == focus_final == frame(directory / 'frames/28200.json.gz')
        source_pre = read(directory / 'source-preflight.json')
        source_post = read(directory / 'source-postflight.json')
        focus_pre = read(D / 'candidate27600-28200-source-preflight.json')
        assert source_pre == source_post['source']
        assert inventory(source_pre['files']) == inventory(focus_pre['inherited'] + focus_pre['extras'])
        assert source_post['frozenPre'] == source_post['frozenPost']
        focus_post = read(D / 'candidate27600-28200-source-postflight.json')
        assert source_post['frozenPre'] == focus_post['frozenPre'] == focus_post['frozenPost']
        original_post = read(OLD / 'v3-natural15855/source-postflight.json')
        assert source_post['frozenPre'] == original_post['frozenPre'] == original_post['frozenPost']
        assert len(source_pre['files']) == 1470 and len(source_post['frozenPre']) == 497
    assert common['setup'] == initial['setup'] == final['setup']
    assert final == frame(directory / ('frames/' + str(final['snapshot']['tick']) + '.json.gz'))
    assert report['naturalComplete'] and report['observationStop'] is None
    assert final['snapshot']['tick'] == report['result']['tick'] == final['snapshot']['match']['endedAtTick']
    assert final['snapshot']['match']['winner'] == report['result']['winner'] == 'p0'
    assert final['snapshot']['match']['stats'] == report['fullOriginalStats']
    deaths = (rows(extra_death) if extra_death else []) + rows(directory / 'native-deaths.jsonl')
    hits = (rows(extra_hits) if extra_hits else []) + rows(directory / 'native-hits.jsonl')
    hits_by_index = {hit['index']: hit for hit in hits}
    assert len(hits_by_index) == len(hits)
    states = {}
    for event in deaths:
        if event['type'] == 'native-unit-terminal':
            assert event['id'] not in states
            states[event['id']] = [event, event['confirmation']]
        else:
            assert event['type'] == 'terminal-status-update'
            states[event['id']][1] = event['status']
    final_units = {unit['id']: unit for unit in final['snapshot']['units']}
    final_corpses = {corpse['unitId']: corpse for corpse in final['snapshot']['corpses']}
    assert len(final_corpses) == len(final['snapshot']['corpses'])
    initial_corpse_ids = {corpse['unitId'] for corpse in common['snapshot']['corpses']}
    confirmed_ids = set()
    closure = {}
    for owner, total in final['snapshot']['match']['stats']['unitsLost'].items():
        confirmed = []
        for unit_id, (event, status) in states.items():
            if event['tick'] <= common['snapshot']['tick']:
                continue
            body = event['atObservation'] or event['previous']
            if body['owner'] != owner:
                continue
            assert status in {'absent-at-native-boundary', 'native-removal-after-nonpositive', 'returned-positive'}
            assert event['terminalClass'] != 'removal-cause-unconfirmed'
            if status == 'returned-positive' or event['terminalClass'] != 'death-observed':
                continue
            assert unit_id not in final_units
            assert event['permanent'] == ('expiresTick' not in body)
            evidence = event['evidence']
            fatal = evidence.get('nativePositiveToNonpositiveHit')
            if fatal:
                assert fatal == hits_by_index[fatal['index']]
                assert fatal['target'] == unit_id and fatal['hpBefore'] > 0 and fatal['hpAfter'] <= 0
                assert fatal['positiveToNonpositive']
            else:
                assert evidence.get('hpNonpositive') or evidence.get('corpse') or evidence.get('aboardLivingAtHullFatal') or evidence.get('knownDeadHull')
            if event['permanent']:
                assert unit_id in final_corpses
                assert final_corpses[unit_id]['owner'] == owner
                assert final_corpses[unit_id]['diedAtTick'] >= event['tick']
            confirmed.append(event)
            confirmed_ids.add(unit_id)
        before = common['snapshot']['match']['stats']['unitsLost'][owner]
        permanent = sum(event['permanent'] for event in confirmed)
        temporary = len(confirmed) - permanent
        assert total - before == permanent + temporary
        closure[owner] = {'priorAt27600': before, 'finalNativeUnitsLost': total,
                          'confirmedPermanentDelta': permanent, 'confirmedTemporaryDelta': temporary}
    added_corpses = set(final_corpses) - initial_corpse_ids
    assert added_corpses == confirmed_ids
    assert not report['telemetry']['pendingNativeCleanup']
    assert not [unit for unit in final_units.values() if unit['hp'] <= 0]
    cohort = {}
    for owner in ['p0', 'p1', 'p2']:
        start = {unit['id'] for unit in common['snapshot']['units'] if unit['owner'] == owner}
        alive = start & final_units.keys()
        removed = start - final_units.keys()
        assert removed <= confirmed_ids
        cohort[owner] = {'initialLive': len(start), 'aliveAtEnd': len(alive), 'confirmedDead': len(removed)}
    enemies = {owner: {'units': sum(unit['owner'] == owner for unit in final_units.values()),
                       'buildings': sum(building['owner'] == owner for building in final['snapshot']['buildings'])}
               for owner in ['p1', 'p2']}
    assert enemies == report['enemyAtEnd'] == {'p1': {'units': 0, 'buildings': 0}, 'p2': {'units': 0, 'buildings': 0}}
    rider_initial = next(unit for unit in common['snapshot']['units'] if unit['id'] == UID)
    rider_end = final_units.get(UID)
    rider_death = states.get(UID)
    rider_last = rider_end or rider_death[0]['atObservation'] or rider_death[0]['previous']
    rider_kills = [hit for hit in hits if hit['tick'] > 27600 and hit['attacker'] == UID and hit['targetIsUnit'] and hit['positiveToNonpositive']]
    assert rider_initial['kills'] + len(rider_kills) == rider_last['kills']
    corpse_counts = collections.Counter(corpse['owner'] for corpse in final_corpses.values())
    initial_corpse_counts = collections.Counter(corpse['owner'] for corpse in common['snapshot']['corpses'])
    for owner, total in final['snapshot']['match']['stats']['unitsLost'].items():
        assert corpse_counts[owner] == total
        assert initial_corpse_counts[owner] == common['snapshot']['match']['stats']['unitsLost'][owner]
    results[label] = {
        'result': {key: report['result'][key] for key in ['tick', 'winner']},
        'reportSHA256': digest(directory / 'report.json'), 'finalSHA256': digest(directory / 'final.json.gz'),
        'finalFrameExact': True, 'closureFromCommon27600': closure,
        'initial27600Cohort': cohort, 'finalCorpsesByOwner': dict(corpse_counts),
        'newCorpseIdsExactlyEqualConfirmedWindowDeaths': True,
        'terminalNonpositiveUnits': 0, 'pendingUnconfirmedOrTemporaryDeathDelta': 0,
        'provisionalAfter27600': sum(e.get('confirmation') == 'hp<=0-awaiting-cleanup' and e['tick'] > 27600 for e in deaths),
        'confirmedAfterNonpositiveAfter27600': sum(e.get('status') == 'native-removal-after-nonpositive' and e['tick'] > 27600 for e in deaths),
        'returnedPositiveAfter27600': sum(e.get('status') == 'returned-positive' and e['tick'] > 27600 for e in deaths),
        'ownEnd': {'units': sum(unit['owner'] == 'p0' for unit in final_units.values()),
                   'buildings': sum(building['owner'] == 'p0' for building in final['snapshot']['buildings'])},
        'enemyEnd': enemies,
        'rider4294': {'aliveAtEnd': bool(rider_end), 'killsAt27600': rider_initial['kills'],
                      'subsequentActualFatalUnitHits': len(rider_kills), 'lastKills': rider_last['kills'],
                      'deathTick': rider_death[0]['tick'] if rider_death else None},
    }

audit = {'classification': 'Independent offline raw frames/native hits/removal ledger audit; no new simulation, test or policy query.',
         'input': {'path': str(common_path), 'sha256': digest(common_path), 'tick': 27600,
                   'worldIdAll3MemorySetupExactlyShared': True, 'rulesVersion': 2,
                   'candidateOwn28200FocusEndEqualsNaturalInputAndFirstFrame': True},
         'candidateNaturalSource1470AndFrozen497EqualFocusedAndOriginal844PrePost': True,
         'runs': results,
         'limits': ['Changed-code27600 continuation of existing match, not ordinary0 or a new unseen-seed generalization.',
                    'Native cumulative46/57 includes42 prior p0 deaths at27600; the audited continuation deltas are4/15 confirmed permanent,0 temporary.',
                    'Corpse and removal records corroborate confirmed deaths; provisional observations are not added again.',
                    'Actual final victory on this shared-input archer versusv8+v8 match does not satisfy three-family/all-opponent/map/seed bootstrap acceptance.'],
         'scriptSHA256': digest(__file__)}
(OUT / 'terminal-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
