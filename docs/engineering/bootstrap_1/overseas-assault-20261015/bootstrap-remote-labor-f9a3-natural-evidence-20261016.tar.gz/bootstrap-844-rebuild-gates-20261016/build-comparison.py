import json,gzip,hashlib,collections,math
from pathlib import Path
root=Path('/workspace/.playtest/bootstrap-844-rebuild-gates-20261016')
base=Path('/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016/v3-natural15855')
candidate=root/'candidate-natural28200'
read=lambda p:json.loads(Path(p).read_text())
frame=lambda p:json.load(gzip.open(p))
lines=lambda p:[json.loads(l) for l in Path(p).read_text().splitlines() if l]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
initial=frame(base/'frames/27600.json.gz');bas=frame(base/'final.json.gz');can=frame(candidate/'final.json.gz')
assert initial==frame(root/'closure27600-28200.frames/27600.json.gz')==frame(root/'candidate27600-28200.frames/27600.json.gz')
assert frame(root/'candidate27600-28200-terminal.json.gz')==frame(candidate/'frames/28200.json.gz')
assert read(candidate/'report.json')['sourceExact'] and read(candidate/'report.json')['frozenExact']
ledger=read(root/'independent-candidate/terminal-audit.json')
for filename in ['commands.jsonl','native-hits.jsonl','native-events.jsonl','native-deaths.jsonl']:
 rows=lines(base/filename)
 rows=[r for r in rows if r['tick']>27600 or r['tick']==27600 and (filename=='commands.jsonl' or r.get('commandIndex') is not None)]
 (root/'portable-baseline'/filename).write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows))
payments=lines(candidate/'payment-effects.jsonl');cash=lines(candidate/'cash-transitions.jsonl');events=lines(candidate/'native-events.jsonl')
firstcmd=next(r for r in payments if r['command']['type']=='build' and r['command']['buildingKind']=='townHall')
firstbirth=next(r for r in events if r['type']=='building-birth-observed' and r['building']['owner']=='p0' and r['building']['kind']=='townHall')
firstpaid=next(r for r in cash if r['tick']==firstbirth['tick'])
assert firstcmd['beforeGold']>=400 and firstcmd['beforeGold']==firstcmd['afterGold']
assert abs(firstpaid['after']['spent']-firstpaid['before']['spent']-400)<1e-8
assert abs(firstpaid['before']['gold']-firstpaid['after']['gold']-400)<1e-8
bank=next(r for r in cash if r['tick']>=firstbirth['tick'] and any(math.hypot(d['before']['x']-2128,d['before']['y']-2160)<=220 for d in r['observedReturningWorkerCarryingDrops']))
assert bank['tick']==56759 and len(bank['observedReturningWorkerCarryingDrops'])==1
assert bank['after']['gold']-bank['before']['gold']==10 and bank['after']['spent']==bank['before']['spent']
assert bank['observedReturningWorkerCarryingDrops'][0]['before']['carryingGold']==10
assert bank['observedReturningWorkerCarryingDrops'][0]['after']['carryingGold']==0
assert not [h for h in lines(candidate/'native-hits.jsonl') if h['tick']==bank['tick']]
basebuild=next(r for r in lines(base/'commands.jsonl') if r['tick']>=27600 and r['owner']=='p0' and r['command']['type']=='build' and r['command']['buildingKind']=='townHall')
basebirth=next(r for r in lines(base/'native-events.jsonl') if r['tick']>=27600 and r['type']=='building-birth-observed' and r['building']['owner']=='p0' and r['building']['kind']=='townHall')

def summary(label,saved):
 s=saved['snapshot'];own=[u for u in s['units'] if u['owner']=='p0' and u['hp']>0];stats=s['match']['stats']
 initialIds={u['id'] for u in initial['snapshot']['units'] if u['owner']=='p0' and u['hp']>0};alive={u['id']:u for u in own}
 initialWorkers=[u['id'] for u in initial['snapshot']['units'] if u['owner']=='p0' and u['kind']=='worker' and u['hp']>0]
 deaths=[c for c in s['corpses'] if c['owner']=='p0' and c['unitId'] in initialIds]
 return {'tick':s['tick'],'winner':s['match']['winner'],'fullNativeLoss':stats['unitsLost'],'windowP0PermanentLoss':stats['unitsLost']['p0']-42,'ownLive':len(own),'ownKinds':dict(collections.Counter(u['kind'] for u in own)),'ownBuildings':len([b for b in s['buildings'] if b['owner']=='p0' and b['hp']>0]),'wallet':s['players']['p0']['gold'],'goldSpentNative':stats['goldSpent']['p0'],'allSourceCashPlusSpentFlowFrom27600':s['players']['p0']['gold']+stats['goldSpent']['p0']-initial['snapshot']['players']['p0']['gold']-initial['snapshot']['match']['stats']['goldSpent']['p0'],'flowCaution':'ALL-source observed flow, including bounties and refunds; not labelled net mining income.','initial13AliveIds':sorted(initialIds&alive.keys()),'initial13DeadIds':sorted(initialIds-alive.keys()),'initial4WorkerAliveIds':[i for i in initialWorkers if i in alive],'initial4WorkerDeadIds':[i for i in initialWorkers if i not in alive],'enemyEnd':{o:{'units':len([u for u in s['units'] if u['owner']==o and u['hp']>0]),'buildings':len([b for b in s['buildings'] if b['owner']==o and b['hp']>0])} for o in ['p1','p2']}}
report={'classification':'Full natural SAME actual27600 allworld/id/3mem paired outcome: original844 policy bytes=productionf508, candidatef9a only original remote recruitment admission shared by both entries. No fresh ordinary0/newseed/generalization claim. Original15255 lineage includes an earlier changed-source ab0 case state, without importing ab0 source.','setup':initial['setup'],'sharedInput':{'path':str(base/'frames/27600.json.gz'),'sha256':sha(base/'frames/27600.json.gz'),'worldIdAll3memEqual':True,'p0Live13IncludingWorkers4':True},'focus600':read(root/'candidate27600-28200.json')['full600tickComparison'],'baseline':summary('baseline844',bas),'candidate':summary('candidateF9a',can),'actualRebuild':{'baseline':{'firstPublicRequest':basebuild,'nativeFoundation':basebirth,'firstActualMiningBank':'Not captured per tick in original600-sampled cash observer. The82800 fullframe is completehall and local mine staff. Do not invent exact baseline firstbank.','oldIncomeHallLost23705':23705,'replacementFoundationGap':basebirth['tick']-23705},'candidate':{'firstPublicRequestAndActualWallet':firstcmd,'nativeFoundation':firstbirth,'actualNativeFoundationPayment':firstpaid,'firstNewHallMiningBankWitness':bank,'bankExplanation':'Native updateMineOrder returns to nearest completehall. At56759 actual worker23018 carrying10->0, mine(gen3)return->toMine, gap72.19 from newhall vs oldhall>2000, wallet+10/spent unchanged, supply28, nativeupkeep=10, no nativehit this tick. This is actual10 mining credit, unlike all-source cash+spent totals.','replacementFoundationGap':firstbirth['tick']-23705}},'scopeAndCosts':['Profitability formula/cost/range/THINK/1.4/normal opponents untouched. Full script runner reserves all unpaid build400.','At27885 no worker allows normal v6Economy scan: eight goalAges.seen update; other same-input commands match. Endpoint28200 all3mem reconverges.','Actual59400 baseline normal and longHaul each emit a duplicate worker attempt on one76.95 wallet; actual original only one birth/payment. Candidate emits/pays one profitable recruit. No claim duplicate75 was actually paid twice.','Saved75 does not exclusively finance the hall: next actual candidate payment is29805 lancer110, then profitable workers resume33705. Later world/army/economy changes are genuine closed-loop consequences, not a sole-line causal proof.','Candidate still loses4 workers after27600, including two initial miners and two newly recruited. No combat unit dies in this segment; this does not make all earlier42 losses avoidable.','Candidate41 vs baseline42 survivors and24vs25 ownbuildings; faster outcome is not every quantity higher.','Only global absence of actual remaining-mine own hall activates ROI; total workers >=crew is inherited counting, not a guarantee any builder is free.','No newordinary0 or other route/map tested.3route finalacceptance remains unfinished.'], 'ledgerAudit':{'path':'independent-candidate/terminal-audit.json','sha256':sha(root/'independent-candidate/terminal-audit.json')},'nativeRenders':['native-candidate57000.png','native-candidate69838.png','native-base82200.png']}
(root/'NATURAL-ECONOMY-COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'baseline':{k:report['baseline'][k] for k in ['tick','windowP0PermanentLoss','ownLive']},'candidate':{k:report['candidate'][k] for k in ['tick','windowP0PermanentLoss','ownLive']},'firstCommand':firstcmd['tick'],'firstFoundation':firstbirth['tick'],'firstBank':bank['tick'],'complete':True}))
