这包保存生产 f508（运行源与844逐文件相同）到候选 f9a3f731f33020605bec21099929fab0c6b14bb3 的最小远程招工准入修复与真实同输入完整续局。原844已封D包未修改，候选control已固定clean；本包封存后不再写。root/main没有本代理修改。

实际案例仍是已开发 pineshade→ladder4608²，seed bootstrap_1-unseen-archer-v8-v8-20261015-01，p0 Grove/v9_archer physicalside1 对 frozenv8 Ember+Grove，正常factory500/3/8，rules2/think15/frozen184。名字中unseen不使这个已反复开发例成为新holdout。27600输入继承原844完整自然局；更早15255状态源于ab0负例的换码诊断，未导入ab0源。这些结果不称普通0或最终三路线/泛化验收。原容器未提交改动的恢复缺口仍未取得，未声称继承。

先读 NATURAL-ECONOMY-COMPARISON.json、PORTABLE-SOURCE-DELIVERY.json 和 independent-candidate/terminal-audit.json。独立source审查证明f508与sealed844的1467源字节相同；故原844从共同27600到自然96245的完整已有真实比赛是同政策baseline，不另重跑全长。

原81000并无裸navalReserve0漏洞：完整P0预扣unpaidbuild，实际pending0；bases:3 priority96 cost400以钱包351.95正常保存。42000同样pending0、wallet46.95，原unit:lancer83/save110先于bases:2/save400阻止消费。原有合法gen3候选、真实施工路/护军/800威胁/盟矿/敌基地规则均保留。新的因果来自实际27885完整全P0：普通geometric worker vacancy直接花75，但原longHaulInvestment同输入 payback16435>saving16099.055 明确拒绝。27600→28200原源600tick全world/id/3mem/601命令/12hits闭合，真实27885支付84.95→9.95、paidqueue75、28025出生。59400两个旧分支同看76.95，各发相同train；原实际只付一次/出生一人，不能把两attempt当150消费。

候选仅2生产文件：有实际剩余矿旁own厅（含已付在建基础）或缺原必要crew仍走普通staffing；全局无矿厅而已有crew时只能经现有longHaulInvestment一次。后续v6 workerGoal也共享这个准入，不能裸需求再绕过。longHaul原公式、原1.4、原必要防御/人口、normal pendingbuild400、triage/owner/思考频率/规则/敌人均未改。全局矿厅判据不是每条远矿ROI，原crew按总workers计（含忙工/甲板）不保证可用builder，productionWave仍用原rawmissing；不夸大保障范围。

111项5文件单worker回归+tsc0；新30例含两完整真实输入、3family×2race×4负例、实际矿厅/已付基础、第一建造者和正常行走建造400承诺。首轮唯一红是测试以105金新发build，本体正确拒绝；已保旧日志，最终测试以400合法受理未付walking，再105表示另一已受理消费。最初矿厅fixture距矿100不合法也已明确记录、更正至268，不改本体210下限。

候选从完全同27600 world/id/3mem起跑600ticks，首指令差精确27885去除train，非工人指令同；12hits全等。27885候选继续正常v6Economy扫描，所以8个goalAges.seen从27870变27885；错误审计曾要求全部postmem相等，初始exit1报告/日志保留，INTERPRETATION解释。28200三mem已重新相等，wallet94.95 vs19.95（恰75），少1worker。此后从真实candidate28200完整恢复自然续局，没有命令/钱/对手改造、任意期限或新0。两侧实际每600tick完整world/id/所有3memory、完整commands/hits/native死亡观察/确认/尸体均保留；baseline原始全局仍在已封D包，必要片段与终档已复制本包。

完整结果：候选69838 p0WIN，原84496245 p0WIN，两敌都0units0buildings；候选累计p0永久死46 vs57，27600后4 vs15（临时都0）。原13己兵候选11存2死、对照6存7死；初始4worker候选2存2死，加2新worker死亡构成本段4死。候选终41活兵/24建筑 vs原42/25，不说所有数量更好。骑手4294候选终活316HP/21kills，原37186死/13kills；后续14次真实fatal unit hit与原始7kills核闭合，不把表面命令当输出。所有owner新尸体ID与confirmed死亡/nativeUnitsLost增量闭合，无pending、不把hp0provisional直接当永久死。

新厅55530公开build钱包409.95≥400，受理后未付款；56034真实foundation钱包419.95→19.95、spent+400；56759真实worker23018 gen3 return携10→0、wallet18.95→28.95、spent不变/supply28/本tick无hit，native最近own complete厅为gen3，证明该新厅首笔10金采矿入账。原baseline81915请求/82200foundation，原600observer没有逐tick收款，不能给原首次bank捏造精确tick。矿厅重建gap23705→56034=32329 vs旧58495，早26166。保留资本因果限制：27885省75后，29805实际先买110lancer，33705起又可合法招工；本轮不是单独静态75直接变400，之后战线/收入共同分化。cash+spent所有流入含赏金/退款，绝不通称净采矿收入。

native-candidate57000.png、native-candidate69838.png、native-base82200.png为实际完整frame的drawWorld，前两图作者亲view；只有静态freshfacing、未重建历史动画。父root也收到终图供亲看。4worker仍死在远矿：32484 worker17606被knight20531、43707 worker34685被knight32157、43895 worker36533避战move仍死、44123 worker14230被ballista18612；保留给后续矿路安全，不趁此叠护理变体。

所有错误原记录保留，先读DIAGNOSTIC-ERRATA.json与独立build-admission-errata。新公开build确需≥400，walking本身尚未付款且施工时再检查；‘余额不足仍可新发walkingbuild’的旧说明错误。候选两次自然阶段observer commandIndex是各自外部索引（重置不改游戏），不拼作单次ordinary0。source1470/frozen497 pre/post/hash/blob和源capsule逐成员读回闭合。三路线最终正常0、六配对/官方图/新seed和规则2冻结迁移验收范围仍未完成。
