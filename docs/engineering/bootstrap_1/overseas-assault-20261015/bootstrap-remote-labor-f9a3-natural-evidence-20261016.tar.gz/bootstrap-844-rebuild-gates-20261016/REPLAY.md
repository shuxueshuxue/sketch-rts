固定源码为 `/workspace/sketch-rts-remote-labor-capital-control`，HEAD `f9a3f731f33020605bec21099929fab0c6b14bb3`。不要改这个已固定树、已封原D包或已有报告前缀。源capsule逐成员1470SHA核验、冻结497SHA核验见PORTABLE-SOURCE-DELIVERY.json和independent-candidate/source-audit.json；frozen184原始revision必须保留为可用Git对象（同原工程）。本包不是新的普通0入口。

`closure27600-28200.ts` 是原844同源600tick严格闭合；`candidate27600-28200.ts` 读取完全相同实际27600 full输入，以f9a做600tick正常3AI；`candidate-natural-tail.ts` 从该实际候选28200 fullworld/id/3mem恢复，自然运行至winner。三个driver均校验正常factory/agents、rules2、原冻结revision，不改命令/资源/人口/思考频率。运行时的全部外部观察器复用已预封的NativeTelemetry；SDK发出的命令attempt可能是native transient no-op，所以必须用before/after金币、paidqueue、building birth、真实hit、死亡后原生移除和尸体证明效果。

外部入口命令形式（已执行完毕，不重复覆盖）：

```
FIXED_HEAD=f9a3f731f33020605bec21099929fab0c6b14bb3 node --import /workspace/sketch-rts/node_modules/tsx/dist/loader.mjs /workspace/.playtest/bootstrap-844-rebuild-gates-20261016/candidate27600-28200.ts
node --import /workspace/sketch-rts/node_modules/tsx/dist/loader.mjs /workspace/.playtest/bootstrap-844-rebuild-gates-20261016/candidate-natural-tail.ts
```

如未来确需复验，应复制外部driver到新证据目录并只修改`out`路径；原driver遇已存在out主动拒绝覆盖。必须先执行同一fullworld/id/3mem restore检查，不能仅复制P0 memory。不要把事件流中的after-command中途frame当自动可恢复prethink输入。用于本次续接的是明确28200 beforethink边界末档。

所有原baseline27600之后commands/hits/deaths/events已不改字段复制到portable-baseline。原完整每600全档/最早15255 lineage保留在D包，SHA `5298d3f365989a24d4b81dc9e8c5b09ea59fb9156f5c40e71f43ebeecb812e0d`。本包另含必要27600/28200/42000/81000/82200/82800/终96245完整3mem副本，候选的实际全部新600档及事件完整3mem均封在本包。不要把新source后续成绩归原source，也不要借这次换码续局给当前源普通0或未见seed成绩。
