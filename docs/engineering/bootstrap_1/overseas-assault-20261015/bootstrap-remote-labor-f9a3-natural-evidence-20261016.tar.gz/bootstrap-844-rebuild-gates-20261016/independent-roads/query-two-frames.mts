import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const source = '/workspace/sketch-rts-field-screen-retreat-v3-control';
const expectedHead = '84474d599f1886ca0ff32b3edf4897fcdbce9e21';
const inputDir = '/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016/v3-natural15855/frames';
const out = '/workspace/.playtest/bootstrap-844-rebuild-gates-20261016/independent-roads';
mkdirSync(out, { recursive: true });
const load = (path: string) => import(pathToFileURL(source + '/' + path).href);
const sha = (bytes: any) => createHash('sha256').update(bytes).digest('hex');
const { setBuildingBodies, sameGround, walkingDistance, groundSegmentTravelCost } = await load('src/shared/terrain.ts');
const { groundSteeringRoute, routeTravelTicks } = await load('src/shared/route-selection.ts');
const { BUILDING_DEFS, unitMover } = await load('src/shared/catalog.ts');
const { GOLD_MINE_RULES } = await load('src/shared/mining.ts');
const { isBuildPlacementClear, buildingPlacementBlocker, terrainBlocksPlacement } = await load('src/shared/build-placement.ts');
const { readV6Intel, mineGuards, v9ExpansionTolerance } = await load('src/ai/policy/v6/intel.ts');
const { v6ExpansionPoint } = await load('src/ai/policy/v6/economy.ts');
const { mineClaimedByAlly } = await load('src/ai/policy/mine-claims.ts');
const { isReservedBuilder } = await load('src/ai/policy/world-model.ts');
const { groundThreatWithin } = await load('src/ai/policy/ground-threat.ts');
const { strengthOf } = await load('src/ai/policy/v6/strength.ts');
const { v9ExpansionCovered } = await load('src/ai/policy/v9/front.ts');
const { bootstrapExpansionMine, enemyExpansionPower } = await load('src/ai/bootstrap_1/expansion-target.ts');
const { armedFoes, retreatLandRoad, safeLandTravelTicks } = await load('src/ai/bootstrap_1/safe-land-route.ts');
const { miningJobOrder } = await load('src/ai/bootstrap_1/mining-jobs.ts');
const head = () => execFileSync('git', ['rev-parse', 'HEAD'], { cwd: source, encoding: 'utf8' }).trim();
if (head() !== expectedHead) throw new Error('Fixed source changed');
const resultRows = [];
for (const tick of [42000, 81000]) {
  const input = `${inputDir}/${tick}.json.gz`, bytes = readFileSync(input);
  const saved = JSON.parse(gunzipSync(bytes).toString()), snapshot = saved.snapshot;
  const before = JSON.stringify(saved);
  setBuildingBodies(snapshot.map, [...snapshot.buildings, ...snapshot.obstacles ?? []]);
  const context = { memory: structuredClone(saved.memories.p0), teams: snapshot.teams, version: 'v2', requestedVersion: 'v9' };
  const contextBefore = JSON.stringify(context);
  const distance = (a: any, b: any) => Math.hypot(a.x - b.x, a.y - b.y);
  const point = (x: any) => ({ x: x.x, y: x.y });
  const workers = snapshot.units.filter((u: any) => u.owner === 'p0' && u.kind === 'worker' && !u.deck);
  const halls = snapshot.buildings.filter((b: any) => b.kind === 'townHall');
  const ownHalls = halls.filter((b: any) => b.owner === 'p0' && b.complete);
  const mines = snapshot.resources.filter((m: any) => m.amount > 0);
  const foes = armedFoes(snapshot, 'p0', context), intel = readV6Intel(snapshot, 'p0', context);
  function road(from: any, to: any, speed = 60) {
    const path = groundSteeringRoute(snapshot.map, from, to).map(point);
    const length = path.slice(1).reduce((sum: number, p: any, i: number) => sum + distance(path[i], p), 0);
    const cost = path.slice(1).reduce((sum: number, p: any, i: number) => sum + groundSegmentTravelCost(snapshot.map, path[i], p), 0);
    return { from: point(from), to: point(to), sameGround: sameGround(snapshot.map, from, to), directDistance: distance(from, to),
      terrainWalkingDistance: walkingDistance(snapshot.map, from, to) ?? null,
      terrainRouteTicks: routeTravelTicks(snapshot.map, from, to, 'land', speed) ?? null,
      nativeSteeringPoints: path, nativeSteeringLength: length, nativeSteeringCost: cost,
      nativeSteeringEstimatedTicksToEndpoint: Math.ceil(cost * 20 / speed), endpointGoalGap: distance(path.at(-1), to),
      caution: 'Static center/endpoint geometry; native mining stops at44 entry /74 drop. Continuous terrain pace excludes per-tick rounding, crowd, ship/body movement, status and future threats. terrainRouteTicks is a terrain metric; nativeSteeringPoints additionally include current building occupancy.' };
  }
  const workerRows = workers.map((worker: any) => {
    const job = miningJobOrder(worker), mine = mines.find((mine: any) => mine.id === job?.resourceId);
    // Mirror native nearestCompleteTownHall: same-ground, minimum Euclidean gap.
    const nativeHall = ownHalls.filter((hall: any) => sameGround(snapshot.map, worker, hall))
      .reduce((best: any, hall: any) => !best || distance(worker, hall) < distance(worker, best) ? hall : best, undefined);
    const destination = job?.phase === 'return' ? nativeHall : mine;
    return { id: worker.id, hp: worker.hp, speed: worker.speed, point: point(worker), carryingGold: worker.carryingGold,
      order: worker.order, queued: worker.orderQueue ?? [], mineSlot: worker.mineSlot ?? null,
      reservedByNativeBuildOrUnfinishedRepair: isReservedBuilder(snapshot, 'p0', worker),
      nativeChosenReturnHall: nativeHall?.id ?? null, currentJobDestination: destination?.id ?? null,
      currentJobStaticRoad: destination ? road(worker, destination, worker.speed) : null,
      gatheringAlreadyWithinEntry44: !!mine && distance(worker, mine) <= GOLD_MINE_RULES.entryRange,
      currentPursuers: foes.filter((foe: any) => 'order' in foe && ['attack', 'attackMove'].includes(foe.order.type) && foe.order.targetId === worker.id).map((foe: any) => foe.id) };
  });
  const mineRows = mines.map((mine: any) => {
    const site = v6ExpansionPoint(snapshot, 'p0', mine);
    const guards = mineGuards(snapshot, mine);
    const enemy800 = intel.enemies.flatMap((enemy: any) => enemy.army).filter((unit: any) => unitMover(unit.kind) === 'land' && !unit.deck && groundThreatWithin(snapshot, unit, mine, 800));
    const builderRows = workers.map((worker: any) => {
      const retreat = retreatLandRoad(snapshot, worker, site, foes);
      return { id: worker.id, carryingGold: worker.carryingGold, reserved: isReservedBuilder(snapshot, 'p0', worker), sameGround: sameGround(snapshot.map, worker, site),
        road: road(worker, site, worker.speed),
        existingRetreatRoad: retreat ? { ticks: retreat.ticks, endpointGap: distance(retreat.points.at(-1), site) } : null,
        existingRetreatSingleFoeRejections: retreat ? [] : foes.filter((foe: any) => !retreatLandRoad(snapshot, worker, site, [foe]))
          .map((foe: any) => ({ id: foe.id, owner: foe.owner, kind: foe.kind, ...point(foe), ...('order' in foe ? { order: foe.order } : {}) })),
        existingStrictSafeLandTravelTicks: safeLandTravelTicks(snapshot, worker, site, foes) ?? null };
    }).sort((a: any, b: any) => a.road.nativeSteeringEstimatedTicksToEndpoint - b.road.nativeSteeringEstimatedTicksToEndpoint);
    const blocker = buildingPlacementBlocker(snapshot, 'townHall', site);
    return { id: mine.id, point: point(mine), amount: mine.amount, harvestCooldownRemaining: mine.harvestCooldownRemaining ?? 0,
      claimedByAlly: mineClaimedByAlly(snapshot, 'p0', mine, context),
      assignedOwnWorkers: workers.filter((worker: any) => miningJobOrder(worker)?.resourceId === mine.id).map((worker: any) => worker.id),
      otherAssignedWorkers: snapshot.units.filter((worker: any) => worker.kind === 'worker' && worker.owner !== 'p0' && miningJobOrder(worker)?.resourceId === mine.id)
        .map((worker: any) => ({ id: worker.id, owner: worker.owner, ...point(worker), order: worker.order, carryingGold: worker.carryingGold, directDistanceToMine: distance(worker, mine), armedFoe: foes.includes(worker) })),
      guardsWithin350: guards.map((unit: any) => ({ id: unit.id, kind: unit.kind, hp: unit.hp, directDistance: distance(unit, mine) })),
      halls: halls.map((hall: any) => ({ id: hall.id, owner: hall.owner, complete: hall.complete, point: point(hall), directDistance: distance(hall, mine), withinActive320: distance(hall, mine) <= GOLD_MINE_RULES.baseRange,
        withinAnyHallExclusion340: distance(hall, mine) <= 340, withinEnemyHallExclusion900: hall.owner !== 'p0' && distance(hall, mine) <= 900,
        mineToHallRoad: road(mine, hall) })),
      enemyExpansionPowerAt800: enemyExpansionPower(snapshot, intel, mine, 800), v9ExpansionTolerance: v9ExpansionTolerance(intel),
      enemyLandUnitsWithin800ByExistingGroundThreat: enemy800.map((unit: any) => ({ id: unit.id, kind: unit.kind, hp: unit.hp, point: point(unit), directDistance: distance(unit, mine), terrainWalkingDistance: walkingDistance(snapshot.map, unit, mine) ?? null })),
      existingV9EscortOrTowerCovered: v9ExpansionCovered(snapshot, 'p0', intel, mine),
      originalV6ExpansionSite: site, siteMineDistance: distance(site, mine),
      nativePlacementClear: isBuildPlacementClear(snapshot, 'townHall', site), nativeTerrainBlocked: terrainBlocksPlacement(snapshot.map, 'townHall', site),
      nativeBuildingResourceObstacleBlocker: blocker ? { id: blocker.id, kind: blocker.kind, ...point(blocker) } : null,
      builders: builderRows };
  });
  const selected = bootstrapExpansionMine(snapshot, 'p0', intel, context);
  resultRows.push({ tick, input, inputSHA256: sha(bytes), setup: saved.setup,
    player: snapshot.players.p0, townHallCost: BUILDING_DEFS.townHall.cost, currentGoldBelowHallCost: snapshot.players.p0.gold < BUILDING_DEFS.townHall.cost,
    currentGoldShortfallToOrdinaryHallCostOnly: Math.max(0, BUILDING_DEFS.townHall.cost - snapshot.players.p0.gold),
    ownCurrentArmyCount: intel.army.length, ownCurrentArmyPower: intel.power,
    ownCompleteHalls: ownHalls.map((hall: any) => ({ id: hall.id, ...point(hall), queue: hall.queue })), workers: workerRows, mines: mineRows,
    componentSelectedExpansionMine: selected?.id ?? null,
    componentSelectionCaution: 'Metadata/geometry helper only, not a naked economy call, full pipeline or proof that any build command is selected/accepted. Parent owns budget/priority/claims/postmemory closure.',
    checks: { fullSavedInputUnchanged: before === JSON.stringify(saved), queryContextUnchanged: contextBefore === JSON.stringify(context) } });
}
if (head() !== expectedHead || resultRows.some((row: any) => Object.values(row.checks).some(value => !value))) throw new Error('Source or input changed');
const result = { classification: 'Exactly two existing complete frames, pure map/route/mining/site/territory metadata queries with same-module building overlay. No Game, native step, tests, full/economy planner, financial counterfactual, state edit or newmatch.', source, head: expectedHead,
  constants: { mine: GOLD_MINE_RULES, townHallCost: BUILDING_DEFS.townHall.cost, prepareCoverRange: BUILDING_DEFS.defenseTower.attackRange + GOLD_MINE_RULES.baseRange },
  rows: resultRows, limits: ['Roads and coverage are current snapshot geometry, not future safe travel or eventual construction.','Native build placement/funding rules differ from policy escort/800range gates; no new capital/reserve definition is introduced.','Raw42k/81k gold is not the post-earlier-script budget. Parent full-pipeline evidence determines spending/claims/goal dispatch.'] };
writeFileSync(out + '/query-two-frames.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(resultRows.map((row: any) => ({ tick: row.tick, gold: row.player.gold, workers: row.workers.length, selectedMineComponent: row.componentSelectedExpansionMine,
  mines: row.mines.map((mine: any) => ({ id: mine.id, amount: mine.amount, assigned: mine.assignedOwnWorkers.length, guards: mine.guardsWithin350.length, ally: mine.claimedByAlly,
    power800: mine.enemyExpansionPowerAt800, tolerance: mine.v9ExpansionTolerance, covered: mine.existingV9EscortOrTowerCovered, site: mine.originalV6ExpansionSite, legal: mine.nativePlacementClear,
    emptyEligibleBuilderRoads: mine.builders.filter((builder: any) => !builder.carryingGold && !builder.reserved && builder.sameGround).map((builder: any) => ({ id: builder.id, ticks: builder.road.nativeSteeringEstimatedTicksToEndpoint, safeRoad: builder.existingRetreatRoad })) })), checks: row.checks }))));
