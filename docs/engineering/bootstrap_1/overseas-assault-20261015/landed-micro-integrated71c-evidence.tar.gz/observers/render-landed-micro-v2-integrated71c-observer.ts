import{createCanvas}from'@napi-rs/canvas';import{readFileSync,writeFileSync}from'node:fs';
import{installHeadlessCanvas}from'/workspace/sketch-rts-landed-micro-v2-integrated71c-control/src/recorder/record.ts';
import{drawWorld}from'/workspace/sketch-rts-landed-micro-v2-integrated71c-control/src/client/world-renderer.ts';
import{UnitFacingTracker}from'/workspace/sketch-rts-landed-micro-v2-integrated71c-control/src/client/unit-facing.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',prefix='archer-assault-landed-micro-v2-integrated71c';installHeadlessCanvas();
for(const[tick,label]of[[100996,'sample'],[101596,'sample'],[102451,'terminal']]as const){const{snapshot}=JSON.parse(readFileSync(`${root}/${prefix}.frames/${label}-${tick}.json`,'utf8')),canvas=createCanvas(1600,1400);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:{x:1200,y:5800,width:1600,height:1400,zoom:1},now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(`${root}/${prefix}-observer-${tick}-enemy.png`,canvas.toBuffer('image/png'));}
