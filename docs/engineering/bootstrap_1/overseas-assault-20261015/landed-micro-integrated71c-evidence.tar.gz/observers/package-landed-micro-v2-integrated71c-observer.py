from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,tarfile,tempfile
out=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');prefix='archer-assault-landed-micro-v2-integrated71c';archive=out/(prefix+'-evidence.tar.gz');assert not archive.exists(),'Preserve existing seals'
sha=lambda b:hashlib.sha256(b).hexdigest();cap=json.loads((out/(prefix+'-source.json')).read_text());post=json.loads((out/(prefix+'-source-postflight.json')).read_text());r=json.loads((out/(prefix+'.json')).read_text());audit=json.loads((out/(prefix+'-native-audit.json')).read_text())
assert r['end']==102451 and post['nativeMatch']['winner']=='p0'and post['nativeMatch']['endedAtTick']==102451
assert all(r['restore'].values())and not post['sourceMismatches']and not post['inputMismatches']and post['exitCode']==0
assert cap['sourceFiles']==855 and cap['frozenManifestEntriesVerified']==184
for name,h in cap['files'].items():assert sha((Path(cap['worktree'])/name).read_bytes())==h,name
for name,h in cap['inputHashes'].items():assert sha((out/name).read_bytes())==h,name
assert sha(Path(cap['sourceArchive']).read_bytes())==cap['sourceArchiveSha256']
staging=Path(tempfile.mkdtemp(prefix='bootstrap-landed-v2-integrated71c-evidence-',dir='/tmp'));files={}
def add_bytes(name,data):
 assert not name.startswith('/')and'..'not in Path(name).parts and name not in files
 p=staging/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);files[name]=sha(data)
def add(name,path):add_bytes(name,Path(path).read_bytes())
with tarfile.open(cap['sourceArchive'],'r:gz')as tf:
 index=json.loads(tf.extractfile('INDEX.json').read());assert len(index['files'])==1363
 for name,h in index['files'].items():
  data=tf.extractfile(name).read();assert sha(data)==h,name;add_bytes('prelaunch/'+name,data)
 # Verify frozen manifest again directly from captured bytes.
 manifest=json.loads(tf.extractfile('live/docs/engineering/bootstrap_1/frozen-policy.json').read());assert manifest['rulesVersion']==2 and len(manifest['files'])==184
 for name,h in manifest['files'].items():assert sha(tf.extractfile('frozen/'+name).read())==h,name
add('prelaunch/source-archive.tar.gz',cap['sourceArchive'])
for suffix in ['-source.json','-source-postflight.json','-delta.json','-production.patch','-launch.json','-run.ts','.log','.json','-native-audit.json']:
 add('diagnostic/'+prefix+suffix,out/(prefix+suffix))
frames=sorted((out/(prefix+'.frames')).glob('*.json'))
for p in frames:
 f=json.loads(p.read_text());assert f['tick']==f['snapshot']['tick']and set(f['memories'])=={'p0','p1'}
 add('diagnostic/frames/'+p.name,p);add_bytes('diagnostic/memories/'+p.name,json.dumps({'tick':f['tick'],'nextId':f['nextId'],'memories':f['memories']},sort_keys=True,separators=(',',':')).encode()+b'\n')
for name in ['capture-landed-micro-v2-integrated71c.py','launch-landed-micro-v2-integrated71c.py','audit-landed-micro-v2-integrated71c-observer.py','render-landed-micro-v2-integrated71c-observer.ts','package-landed-micro-v2-integrated71c-observer.py']:
 add('observers/'+name,out/name)
visual=[]
for tick in [100996,101596,102451]:
 p=out/f'{prefix}-observer-{tick}-enemy.png';add('client-images/'+p.name,p);visual.append({'tick':tick,'file':p.name,'sha256':sha(p.read_bytes()),'personallyViewed':True})
for name in ['archer-assault-landed-micro-v2.json','archer-assault-landed-micro-v2-source.json','archer-assault-landed-micro-v2-source-postflight.json']:
 add('separate-prior-v2-comparison/'+name,out/name)
metadata={'classification':'Integrated changed-code diagnostic after manual100396 history, normal complete AI after exact restore. This is not an ordinary tick0 game, standalone AI opening win, pure-micro-only causal comparison or final bootstrap acceptance.','sealedAtUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':cap['baseCommit'],'delta':cap['productionDelta'],'input':cap['input'],'inputFixtureSha256':r['fixtureSha256'],'restore':r['restore'],'start':100396,'nativeEnd':post['nativeMatch'],'remaining':post['remaining'],'windowStatsDelta':post['nativeStatsDelta'],'originalCrew':post['originalCrew'],'commandsCaptured':len(r['issued']),'nativeHitsCaptured':len(r['hits']),'fullFramesWithCompleteWorldNextIdBothMemories':len(frames),'sourceFilesVerified':855,'frozenManifestEntriesVerified':184,'sourceBeforeAfterUnchanged':True,'inputsBeforeAfterUnchanged':True,'visualEvidence':visual,'priorV2Comparison':audit['priorV2Comparison'],'limits':'Two original crew remain aboard at native victory, seven original crew lost during this2055tick window, four enemy units remain on a distant island. A complete genuine0 result for the later integrated source and three-family/v7/v8/pair/map/unseen generalization evidence remain open.','recoveryGap':'Original failed-container uncommitted changes remain unrecovered. Old100396 input and v1/v2 source trees were read only and not edited. No claim these were recovered from the failed container.'}
add_bytes('EVIDENCE.json',json.dumps(metadata,indent=2).encode()+b'\n');index_bytes=json.dumps({'algorithm':'SHA-256','scope':'Every regular member except INDEX.json itself. All855 source bytes and184 frozen manifest files are included and verified individually.','files':dict(sorted(files.items()))},indent=2).encode()+b'\n';(staging/'INDEX.json').write_bytes(index_bytes)
with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
 for name in sorted([*files,'INDEX.json']):
  data=(staging/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tf:
 idx=json.loads(tf.extractfile('INDEX.json').read());assert set(m.name for m in tf.getmembers()if m.isfile())==set(idx['files'])|{'INDEX.json'}
 for name,h in idx['files'].items():assert sha(tf.extractfile(name).read())==h,name
verification={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'indexSha256':sha(index_bytes),'payloadMembersVerified':len(files),'sourceFilesVerified':855,'frozenManifestEntriesVerified':184,'inputTick':100396,'nativeEndTick':102451,'winner':'p0','remaining':post['remaining'],'windowOwnLoss':7,'windowEnemyLoss':24,'originalCrewSurvivors':22,'fullFrames':len(frames),'memories':len(frames),'nativeHits':len(r['hits']),'commands':len(r['issued']),'sourceMismatches':[],'inputMismatches':[],'classification':metadata['classification'],'stagingDirectory':str(staging)}
(out/(prefix+'-evidence.verification.json')).write_text(json.dumps(verification,indent=2)+'\n');(out/(prefix+'-evidence.sha256')).write_text(verification['sha256']+'  '+archive.name+'\n');print(json.dumps(verification,indent=2))
