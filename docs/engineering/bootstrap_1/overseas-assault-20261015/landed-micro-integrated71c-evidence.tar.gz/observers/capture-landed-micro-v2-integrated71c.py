"""Capture fixed integrated diagnostic sources/inputs/driver before any gameplay; no simulation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,subprocess,tarfile
out=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');w=Path('/workspace/sketch-rts-landed-micro-v2-integrated71c-control');prefix='archer-assault-landed-micro-v2-integrated71c';expected='71c2261913fc7e234bbf176cc52e99b1945a0cd2'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
assert git('rev-parse','HEAD').decode().strip()==expected
assert not (out/(prefix+'.json')).exists() and not (out/(prefix+'.frames')).exists()
assert not (out/(prefix+'-source.json')).exists() and not (out/(prefix+'-source.tar.gz')).exists()
delta=json.loads((out/(prefix+'-delta.json')).read_text());assert len(delta['fileHashes'])==10
for name,h in delta['fileHashes'].items():assert sha((w/name).read_bytes())==h,name
assert sha(git('diff','--binary','HEAD'))==delta['copiedPatchSha256']
files={}
for tree in ['src/ai','src/shared','src/sdk']:
 for p in sorted((w/tree).rglob('*')):
  if p.is_file():files[str(p.relative_to(w))]=sha(p.read_bytes())
for p in sorted((w/'scripts').glob('bootstrap_1*.ts')):files[str(p.relative_to(w))]=sha(p.read_bytes())
for name in ['package.json','package-lock.json','tsconfig.json','docs/engineering/bootstrap_1/frozen-policy.json']:files[name]=sha((w/name).read_bytes())
manifest=json.loads((w/'docs/engineering/bootstrap_1/frozen-policy.json').read_text());assert manifest['rulesVersion']==2 and manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639'and len(manifest['files'])==184
frozen_tar=git('archive',manifest['revision'],'package.json','src/ai','src/shared','src/sdk');frozen={}
with tarfile.open(fileobj=io.BytesIO(frozen_tar))as tf:
 for member in tf:
  if member.isfile():frozen[member.name]=tf.extractfile(member).read()
for name,h in manifest['files'].items():assert sha(frozen[name])==h,name
input_names=['archer-assault-commonshore-v5.frames/first-land-unit-p0-archer-2951-100396.json',*[f'archer-assault-commonshore-v{v}.json'for v in [2,3,4,5]],'archer-assault-landed-micro-v2-run.ts',prefix+'-run.ts',prefix+'-delta.json',prefix+'-production.patch']
inputs={name:sha((out/name).read_bytes())for name in input_names};fixture=json.loads((out/input_names[0]).read_text());previous=json.loads((out/'archer-assault-commonshore-v5.json').read_text());assert fixture['tick']==fixture['snapshot']['tick']==100396 and fixture['nextId']==14348 and set(fixture['memories'])=={'p0','p1'}
crew=set(previous['originalCrew']);assert len(crew)==29;living=[u for u in fixture['snapshot']['units']if u['id']in crew];assert len(living)==29 and sum(bool(u.get('deck'))for u in living)==2
# The adapted runner is byte-identical after replacing only the three authorized text fields.
original=(out/'archer-assault-landed-micro-v2-run.ts').read_text();adapted=(out/(prefix+'-run.ts')).read_text();expected_driver=original.replace("wd='/workspace/sketch-rts-landed-micro-v2-control'",f"wd='{w}'").replace('archer-assault-landed-micro-v2',prefix)
old='Normal complete AI using committed97c7fca9+landed micro v2 after human-created100396 checkpoint (27ground+2deck;29ever landed). No manual commands after restore. Source changed fromf267v3; not ordinary opening, independent AI win, pure micro causal result or acceptance.'
new='Complete normal full AI using fixed71c22619 (budget plus actual-yaw/service/wind integration) plus exactly copied root landed-micro-v2 production delta after human-created100396 checkpoint (27ground+2deck;29ever landed). No manual commands after restore. Source changed fromf267v3; integrated changed-code diagnostic, not ordinary tick0, an independent AI opening win, isolated pure-micro causal proof or bootstrap acceptance.'
assert adapted==expected_driver.replace(old,new)
preflight={'classification':'Prelaunch full-source/full-input integrated changed-code diagnostic. Manual100396 history retained; no ordinary opening claim.','capturedAtUtc':datetime.now(timezone.utc).isoformat(),'worktree':str(w),'baseCommit':expected,'productionDelta':delta,'sourceFiles':len(files),'frozenManifestEntriesVerified':184,'input':{'tick':100396,'nextId':fixture['nextId'],'completeMemories':list(fixture['memories']),'originalCrew':len(living),'groundCrew':27,'deckCrew':2,'nativeMatch':fixture['snapshot']['match']},'inputHashes':inputs,'driverSha256':sha(adapted.encode()),'maxTicks':120000,'thinkInterval':15,'noCommandsAfterRestore':True,'noGameplayLaunchedByCapture':True}
archive=out/(prefix+'-source.tar.gz');entries={}
with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
 def add(name,data):
  assert name not in entries;info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(data));entries[name]=sha(data)
 for name,h in sorted(files.items()):data=(w/name).read_bytes();assert sha(data)==h;add('live/'+name,data)
 for name,data in sorted(frozen.items()):add('frozen/'+name,data)
 for name,h in sorted(inputs.items()):data=(out/name).read_bytes();assert sha(data)==h;add('inputs/'+name,data)
 add('capture-landed-micro-v2-integrated71c.py',Path(__file__).read_bytes());add('PREFLIGHT.json',json.dumps(preflight,indent=2).encode()+b'\n')
 data=json.dumps({'algorithm':'SHA-256','files':entries},indent=2).encode()+b'\n';info=tarfile.TarInfo('INDEX.json');info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tf:
 idx=json.loads(tf.extractfile('INDEX.json').read());assert set(m.name for m in tf.getmembers()if m.isfile())==set(idx['files'])|{'INDEX.json'}
 for name,h in idx['files'].items():assert sha(tf.extractfile(name).read())==h,name
capsule={**preflight,'files':files,'sourceArchive':str(archive),'sourceArchiveSha256':sha(archive.read_bytes()),'sourceArchivePayloadsVerified':len(entries),'patchSha256':delta['copiedPatchSha256'],'sourceStatus':git('status','--short').decode()};(out/(prefix+'-source.json')).write_text(json.dumps(capsule,indent=2)+'\n');print(json.dumps({k:capsule[k]for k in ['baseCommit','sourceFiles','sourceArchiveSha256','sourceArchivePayloadsVerified','frozenManifestEntriesVerified','input']},indent=2))
