仅收纳旧封包之后的独立补充，不修改原包、原SHA或原比赛归属，不是新策略/新普通局。

research-cost-supplement确认40968实际研究完成从19695延至20835，共1140tick；这是实在的研究延迟成本，不声称是31331败局唯一原因。

native-primitive-proposal仅设计建议，尚不是AI接线或完整比赛证据；7905后续归因勘误必须同时读：7912实际走到walkDestination(2928,3504)的5范围，旧圆形楼体contact=false；7913索敌、7914主动追击、7921死亡仍成立。不能仅归restsAgainstGoalBody。后续尚在修的primitive实现不纳入。

deck-chase-boundary-review-v2只读旧0f5bf唯一永久损失与公开人工微操边界。单人保命不代表全组hold；整组hold造成另一舰raider2068死亡且两龙仍活。它不是正在开发的deck-casualty-v2代码或成绩。

原0f5bf普通0 44441胜归原包。本补充没有新增普通0、无新胜绩，不取消三路线/对手/地图/种子验收，原故障容器未提交修改仍未恢复。
