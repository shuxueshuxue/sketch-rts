import {readFileSync,writeFileSync,renameSync,watch} from 'node:fs';
import {createHash} from 'node:crypto';
import {unitMover} from '/workspace/sketch-rts-coastal-escape-control/src/shared/catalog';
import {sameGround} from '/workspace/sketch-rts-coastal-escape-control/src/shared/terrain';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const name='summoner-coastal-escape.json',out=root+'/summoner-coastal-escape-observations.json',id='unit-p0-bombardShip-26580';
const initial=JSON.parse(readFileSync(root+'/battery-160800-checkpoint.json.frames/160800.json','utf8')).snapshot;
const enemyHome=initial.buildings.find((b:any)=>b.owner==='p1'&&b.kind==='townHall');
const source=readFileSync(root+'/coastal-escape-runtime-source.json');
const rows:any[]=[];let previous=initial,scheduled:ReturnType<typeof setTimeout>|undefined,watcher:ReturnType<typeof watch>|undefined;
const counts=(list:any[])=>Object.fromEntries([...new Set(list.map(x=>x.kind))].sort().map(kind=>[kind,list.filter(x=>x.kind===kind).length]));
function consume(){
 const report=JSON.parse(readFileSync(root+'/'+name,'utf8'));
 for(const row of report.rows){
  if(rows.some(x=>x.tick===row.tick))continue;
  const s=JSON.parse(readFileSync(root+'/'+name+'.frames/'+row.tick+'.json','utf8')).snapshot;
  const ship=s.units.find((u:any)=>u.id===id),naval=row.players.p0.policy.naval??{},ours=s.units.filter((u:any)=>u.owner==='p0'),foes=s.units.filter((u:any)=>u.owner==='p1'),buildings=s.buildings.filter((b:any)=>b.owner==='p1');
  const prevBuildings=previous.buildings.filter((b:any)=>b.owner==='p1'),prevFoes=previous.units.filter((u:any)=>u.owner==='p1');
  const soldiers=ours.filter((u:any)=>unitMover(u.kind)==='land'&&u.kind!=='worker'&&!u.deck&&!u.cabin&&u.expiresTick===undefined);
  const item={tick:s.tick,winner:s.match.winner,p0:{gold:s.players.p0.gold,units:ours.length,permanentLandArmy:soldiers.length,onEnemyLand:soldiers.filter((u:any)=>sameGround(s.map,u,enemyHome)).map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:u.order})),buildings:s.buildings.filter((b:any)=>b.owner==='p0').length,bases:s.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall').length,unitsLost:s.match.stats.unitsLost.p0},battery:ship&&{x:ship.x,y:ship.y,hp:ship.hp,maxHp:ship.maxHp,kills:ship.kills,xp:ship.xp,level:ship.level,order:ship.order,heading:ship.sailing?.heading,speed:ship.sailing?.speed,route:ship.sailing?.route&&{partial:ship.sailing.route.partial,points:ship.sailing.route.points.length,goal:{x:ship.sailing.route.goalX,y:ship.sailing.route.goalY}},voyage:naval.coastalVoyages?.[id],retreat:naval.coastalRetreat?.[id],observedProjectiles:s.projectiles.filter((p:any)=>p.attackerId===id)},enemy:{units:foes.length,kinds:counts(foes),buildings:buildings.map((b:any)=>({id:b.id,kind:b.kind,hp:b.hp,maxHp:b.maxHp,complete:b.complete})),buildingHp:buildings.reduce((n:number,b:any)=>n+b.hp,0),unitsLost:s.match.stats.unitsLost.p1},fleet:ours.filter((u:any)=>unitMover(u.kind)==='sea').map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,order:u.order,passengers:ours.filter((p:any)=>p.deck?.shipId===u.id).map((p:any)=>({id:p.id,kind:p.kind,order:p.order})),mission:naval.ferries?.[u.id]})),delta:{destroyedBuildings:prevBuildings.filter((b:any)=>!buildings.some((c:any)=>c.id===b.id)).map((b:any)=>b.id),damagedBuildings:buildings.flatMap((b:any)=>{const prior=prevBuildings.find((p:any)=>p.id===b.id);return prior&&b.hp<prior.hp?[{id:b.id,before:prior.hp,after:b.hp}]:[];}),missingEnemyUnits:prevFoes.filter((u:any)=>!foes.some((v:any)=>v.id===u.id)).map((u:any)=>u.id)}};
  rows.push(item);previous=s;
  console.log(JSON.stringify({tick:item.tick,winner:item.winner,battery:item.battery&&{x:item.battery.x,y:item.battery.y,hp:item.battery.hp,maxHp:item.battery.maxHp,kills:item.battery.kills,order:item.battery.order},enemy:{units:item.enemy.units,buildings:item.enemy.buildings.length,hp:item.enemy.buildingHp},onEnemyLand:item.p0.onEnemyLand.length,losses:item.p0.unitsLost,delta:item.delta}));
 }
 const temporary=out+'.tmp';writeFileSync(temporary,JSON.stringify({classification:'Read-only observations of independently pinned changed-code continuation; not an ordinary opening, and horizon completion is not a victory.',runtimeSource:'coastal-escape-runtime-source.json',runtimeSourceSha256:createHash('sha256').update(source).digest('hex'),result:report.result,setup:report.setup,rows},null,2));renameSync(temporary,out);
 if(report.result.completed){console.log(JSON.stringify({observerComplete:true,result:report.result}));watcher?.close();}
}
consume();
const existing=JSON.parse(readFileSync(root+'/'+name,'utf8'));if(!existing.result.completed)watcher=watch(root,(_event,file)=>{if(file!==name)return;if(scheduled)clearTimeout(scheduled);scheduled=setTimeout(()=>{scheduled=undefined;try{consume();}catch(error){console.error(error);process.exitCode=1;}},100);});
