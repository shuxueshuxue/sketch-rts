from pathlib import Path
import json,hashlib,tarfile,subprocess,datetime
art=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');repo=art.parents[1];dest=repo/'docs/engineering/bootstrap_1/overseas-assault-20261015/naval-landed-micro-evidence.tar.gz'
run_names=['archer-assault-landed-baseline97','archer-assault-landed-micro-v1','archer-assault-landed-micro-v2','archer-assault-landed-micro-v1-prelanding'];results={}
for name in run_names:
 f=json.loads((art/(name+'.json')).read_text());crew=set(f['originalCrew']);hits=[h for h in f['hits'] if h['source']['id']in crew and h['target']['owner']=='p1'];units=[h for h in hits if h['target']['id'].startswith('unit-')];deaths=[e for e in f['events'] if e['event']=='tracked-unit-disappeared' and e['unit']['id']in crew];part=f['tickStates'][-1]
 results[name]={'classification':f['classification'],'source':f['source'],'input':f['fixture'],'inputSha256':f['fixtureSha256'],'restore':f['restore'],'start':f['start'],'end':f['end'],'completed':f['completed'],'winner':f['final']['winner'],'enemyHallHp':f['final']['enemyHallHp'],'enemyBuildings':len(f['final']['enemyBuildings']),'enemySurvivingUnits':f['final']['enemyUnits'],'currentCrewPartition':{k:part[k] for k in ['currentGroundOnTarget','currentDeck','currentElsewhere','dead']},'maxActualGround':max(len(t['currentGroundOnTarget']) for t in f['tickStates']),'actualTickPartitionCount':len(f['tickStates']),'firstOriginalDeathTick':deaths[0]['tick'] if deaths else None,'lastOriginalDeathTick':deaths[-1]['tick'] if deaths else None,'nativeCrewHitEvents':len(hits),'nativeCrewDamage':sum(h['damage']for h in hits),'nativeCrewUnitHitEvents':len(units),'nativeCrewUnitDamage':sum(h['damage']for h in units),'nativeCrewLethalUnitHitEvents':[{'tick':h['tick'],'source':h['source']['id'],'target':h['target']['id'],'kind':h['target']['kind']}for h in units if h['lethal']],'hallDestroyedTick':next((e['tick']for e in f['events']if e['event']=='building-destroyed' and e['id']=='building-p1-townhall'),None)}
 assert f['completed'] and all(f['restore'].values()),name
 for t in f['tickStates']:
  ids=[u for k in ['currentGroundOnTarget','currentDeck','currentElsewhere','dead']for u in t[k]];assert len(ids)==len(set(ids))==29,(name,t['tick'])
first=json.loads((art/'archer-assault-landed-micro-v1-first-difference.json').read_text());matched=json.loads((art/'archer-assault-landed-micro-v1-matched-frame-capture.json').read_text())
postflights={name:json.loads((art/(name+'-source-postflight.json')).read_text())for name in run_names[:3]}
facts={'classification':'Exact97c control and isolated landed micro v1/v2 full normal-AI aftermaths of manual landing; plus separate unmanipulated88110 changed-source failure. Not ordinary0 acceptance.','rulesVersion':2,'frozenRevision':'d1ae110f2edd99f9c7d899ed61557891ab587639','frozenManifestFilesVerified':184,'ordinaryOpponentResourcesPopulation':True,'same100396InputAllThree':len({results[name]['inputSha256']for name in run_names[:3]})==1,'importantCorrections':['29 everLanded is not simultaneous army: every100396 branch starts27 actual enemy-ground+2deck.','Wins stop at building-based engine winner; four remote enemy spark archers remain. No full annihilation.','Hit events and damage are native observer evidence, not total attempted shot/projectile launch counts.','The fixture variants used by scope unit tests add one distant own straggler or use a declared two-shore synthetic scene. These are negative query tests, not match scores.','No rules3/main merge, frozen opponent nerf, or recovered original-container uncommitted source is claimed.','Old archer-micro two failures reproduce in clean97c: patient6HP is owned by mobileCare/hold, same in v1; critical volley target dies and spending0. Tests have not been weakened or renamed here.'],'results':results,'firstCommandDifferenceTick':first['firstCommandDifference']['tick'],'firstWorldDifferenceTick':first['firstWorldDifference']['tick'],'matchedVisualReplayExactAt100996':{name:value['originalFullRunAt100996']for name,value in matched['runs'].items()},'sourcePostflight':postflights,'v2Validation':{'relatedTestsPassed':63,'nativeDepartureTestsPassed':15,'typecheckPassed':True,'existingArcherTests':{'clean97c':{'passed':4,'failed':2},'v1':{'passed':4,'failed':2}}},'v2Patch':'archer-assault-landed-micro-v2-production.patch','remainingBlocker':'Original normal88110 continuation never places original crew on enemy island before120000; local combat dispatch alone does not repair convoy sailing/rally/unload execution. Further work must use unmanned full-AI evidence and preserve entry safety/required power.','priorManualProvenanceArchive':{'path':'docs/engineering/bootstrap_1/overseas-assault-20261015/shore-contact-manual-evidence.tar.gz','sha256':'618cbc02dce9ab1f84dfcbfc6f0ee0c155fd2abaf745be7ee2c7d454fd1aa53e'}}
(art/'archer-assault-landed-findings.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
clientarc=art/'archer-assault-landed-client97-source.tar.gz'
subprocess.run(['git','-C',str(repo),'archive','--format=tar.gz','--output='+str(clientarc),'97c7fca95e76da7e9767b87d7858138ecb3a18ec','src/client','src/recorder'],check=True)
paths={}
for path in sorted(art.glob('archer-assault-landed-*')):
 if path.name.endswith('-build-evidence.py'):continue
 if path.is_file():paths['playtest/'+path.name]=path
 elif path.is_dir():
  for f in sorted(path.rglob('*')):
   if f.is_file():paths['playtest/'+str(f.relative_to(art))]=f
for rel in ['archer-assault-commonshore-v5.frames/first-land-unit-p0-archer-2951-100396.json','archer-assault-contact-replay.frames/before-think-88110.json','archer-assault-commonshore-v5.json']:
 paths['playtest/'+rel]=art/rel
for rel in ['archer-assault-landed-micro-source-capture.py','archer-assault-landed-build-evidence.py']:
 paths['playtest/'+rel]=art/rel
for tag,wd in [('v1',Path('/workspace/sketch-rts-landed-micro-control')),('v2',Path('/workspace/sketch-rts-landed-micro-v2-control'))]:
 for f in sorted((wd/'.playtest').glob('*.ts')):paths[f'worktree-helpers/{tag}/.playtest/'+f.name]=f
for rel in ['src/ai/bootstrap_1/landed-combat.ts','src/ai/bootstrap_1/landed-combat.test.ts','src/ai/bootstrap_1/landed-combat-scope.test.ts',*[f'src/ai/bootstrap_1/fixtures/archer-landed-before-think-{tick}.json.gz'for tick in [100410,100650,100800]]]:
 paths['v2-review/'+rel]=Path('/workspace/sketch-rts-landed-micro-v2-control')/rel
index={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':facts['classification'],'payloadCount':len(paths),'payload':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for name,p in paths.items()}}
indexraw=(json.dumps(index,indent=2)+'\n').encode();(art/'naval-landed-micro-evidence-INDEX.json').write_bytes(indexraw)
with tarfile.open(dest,'w:gz')as t:
 import io
 for name,p in paths.items():t.add(p,arcname=name)
 info=tarfile.TarInfo('INDEX.json');info.size=len(indexraw);t.addfile(info,io.BytesIO(indexraw))
with tarfile.open(dest)as t:
 for name,entry in index['payload'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==entry['sha256'],name
result={'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payloadCount':len(paths),'allPayloadShaVerified':True}
(art/'naval-landed-micro-evidence-delivery.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
