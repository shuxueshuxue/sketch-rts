import {createCanvas} from '@napi-rs/canvas';import{readFileSync,writeFileSync}from'node:fs';
import{installHeadlessCanvas}from'../src/recorder/record';import{drawWorld}from'../src/client/world-renderer';import{UnitFacingTracker}from'../src/client/unit-facing';
const art='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';installHeadlessCanvas();
for(const[name,frame]of [
 ['archer-assault-landed-baseline97-100650','archer-assault-landed-baseline97.frames/before-think-100650.json'],
 ['archer-assault-landed-micro-v1-100650','archer-assault-landed-micro-v1.frames/before-think-100650.json'],
 ['archer-assault-landed-baseline97-100800','archer-assault-landed-baseline97.frames/before-think-100800.json'],
 ['archer-assault-landed-micro-v1-100800','archer-assault-landed-micro-v1.frames/before-think-100800.json'],
 ['archer-assault-landed-micro-v1-victory-102524','archer-assault-landed-micro-v1.frames/terminal-102524.json'],
 ['archer-assault-landed-micro-v1-hall-assault-101596','archer-assault-landed-micro-v1.frames/sample-101596.json'],
 ['archer-assault-landed-micro-v1-hall-under-fire-101862','archer-assault-landed-micro-v1.frames/building-destroyed-101862.json']]){
 const {snapshot}=JSON.parse(readFileSync(art+'/'+frame,'utf8'));const canvas=createCanvas(1440,1100);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:{x:1300,y:6350,width:1440,height:1100,zoom:1},now:snapshot.tick*1000/20,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(art+'/'+name+'.png',canvas.toBuffer('image/png'));console.log(name);
}
