import { readFileSync, writeFileSync } from 'node:fs';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../src/shared/sim';
import { sameGround, walkingDistance } from '../src/shared/terrain';
import { bootstrapPolicyContext, BOOTSTRAP_VERSIONS } from '../src/ai/bootstrap_1/policy';
import { planAiOwnerCommandEntries } from '../src/ai/planner-context';
import { planSkirmishPreservation, planRangedKiting } from '../src/ai/policy/skirmish-tactics';
import { mainBase } from '../src/ai/policy/world-model';
import { hostileCombatUnits, combatUnits } from '../src/ai/policy/snapshot';
import { landRecoveryAssignments } from '../src/ai/bootstrap_1/land-recovery';
import { planLandedCombat } from '../src/ai/bootstrap_1/landed-combat';
const art='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const results=[];
for(const tick of [100410,100530,100650,100800,101010]) {
 const saved=JSON.parse(readFileSync(`${art}/archer-assault-landing-checkpoint-capture.frames/before-think-${tick}.json`,'utf8'));
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),original=JSON.stringify(snapshot);
 const hall=snapshot.buildings.find(b=>b.id==='building-p1-townhall')!;
 const landed=snapshot.units.filter(u=>u.owner==='p0'&&!u.deck&&u.kind!=='worker'&&sameGround(snapshot.map,u,hall));
 const options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory:structuredClone(saved.memories.p0),teams:game.teams});
 const care=landRecoveryAssignments(snapshot,'p0',options,landed),reserved=new Set([...care.recovering.flatMap(({patient,healer})=>[patient.id,healer.id]),...care.unmedicated.map(({patient})=>patient.id),...care.posts.map(({patient})=>patient.id)]);
 const raw=planSkirmishPreservation(snapshot,'p0',options);
 const kite=planRangedKiting(snapshot,'p0',options,combatUnits(snapshot,'p0'),hostileCombatUnits(snapshot,'p0',game.teams),mainBase(snapshot,'p0'));
 const local=planLandedCombat(snapshot,'p0',options,reserved);
 const variants=BOOTSTRAP_VERSIONS.map(version=>{
  const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version,memory:structuredClone(saved.memories.p0)},{teams:game.teams});
  return {version,entries:entries.filter(e=>e.scriptId==='naval'),localMoveRoads:entries.filter(e=>e.scriptId==='naval'&&e.command.type==='move').flatMap(e=>{const c=e.command;if(c.type!=='move')return[];return c.unitIds.filter(id=>landed.some(u=>u.id===id)).map(id=>{const u=landed.find(u=>u.id===id)!;return{id,goal:{x:c.x,y:c.y},sameGround:sameGround(snapshot.map,u,c),road:walkingDistance(snapshot.map,u,c,'land')}})})};
 });
 results.push({tick,raw,kite,local,reserved:[...reserved],variants,snapshotUnchanged:JSON.stringify(snapshot)===original});
}
writeFileSync(`${art}/archer-assault-landed-micro-v2-command-audit.json`,JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results.map(r=>({tick:r.tick,raw:r.raw.length,kite:r.kite.length,local:r.local.length,reserved:r.reserved,variants:r.variants.map(v=>({version:v.version,commands:v.entries.length,attacks:v.entries.filter(e=>e.command.type==='attack')}))})),null,2));
