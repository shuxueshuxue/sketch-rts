import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';import{performance}from'node:perf_hooks';
const source='/tmp/sketch-rts-assault-approach-control',pre='/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary';
const{bootstrapAssaultApproach}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/assault-approach.ts').href);
const{coastalVoyagePrefixSafe}=await import(pathToFileURL(source+'/src/ai/policy/coastal-voyage.ts').href);
const{setBuildingBodies}=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
const boundaries=JSON.parse(readFileSync(pre+'-actual-naval-boundaries.json','utf8')).result;
const stages=JSON.parse(readFileSync(pre+'-assault-stage-queries.json','utf8')).result;
const result=[];
for(const tick of[55200,55500,55920]){
 const row=boundaries.find((r:any)=>r.tick===tick),frame=JSON.parse(readFileSync(row.input,'utf8')),s=frame.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const stage=stages.find((r:any)=>r.tick===tick).beforeNavalAssembly;
 const boat=s.units.find((u:any)=>u.id==='unit-p0-carrier-4595'),goal=stage.find((b:any)=>b.id===boat.id).mission.approach;
 const runs=[];for(let i=0;i<6;i++){
  const options=structuredClone(row.boundary.before);for(const b of stage)options.memory.naval.ferries[b.id]=structuredClone(b.mission);
  const t=performance.now(),cpu=process.cpuUsage(),commands=bootstrapAssaultApproach(s,boat,goal,options),used=process.cpuUsage(cpu);
  runs.push({label:i===0?'first-call-for-this-saved-world':'warm-identical-input',wallMs:performance.now()-t,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000,commands});
 }
 result.push({tick,boatId:boat.id,goal,nativePrefixPresent:!!boat.sailing?.route?.points.length,nativePrefixSafe:coastalVoyagePrefixSafe(s,boat,boat.sailing?.route,row.boundary.before),runs});
}
writeFileSync('/tmp/bootstrap-knight-assault-approach-v1-20261015/approach-query-cost.json',JSON.stringify({classification:'Read-only query benchmark. First call for each real saved world then five warm identical inputs; memory cloned before timing, map building bodies initialized before timing. No commands applied or simulation lookahead.',budget:4096,result},null,2)+'\n');console.log(JSON.stringify(result));
