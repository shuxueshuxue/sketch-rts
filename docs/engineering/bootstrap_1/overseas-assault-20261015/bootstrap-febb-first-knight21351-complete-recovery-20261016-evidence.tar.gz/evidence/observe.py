from pathlib import Path
import collections, datetime, gzip, hashlib, json, zlib
SRC = Path('/tmp/bootstrap-febb-first-use-knight-v5-pineshade-v3-20261016')
OUT = Path('/tmp/febb-first-knight-v3-observation-20261016')
PREFIX = 'first-use-knight-v5-febb9951'
OWNERS = ['p0', 'p1']
OUT.mkdir(parents=True, exist_ok=True)
def digest(b): return hashlib.sha256(b).hexdigest()
def dump(path, obj): path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
def stable(path):
    before=path.stat(); raw=path.read_bytes(); after=path.stat()
    return raw, {'path':str(path),'bytesRead':len(raw),'sha256':digest(raw),'statUnchangedDuringRead':(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)}
def members(path):
    raw, meta=stable(path); left=raw; records=[]; complete=0; consumed=0; membermeta=[]; err=None
    while left:
        dec=zlib.decompressobj(31)
        try: part=dec.decompress(left)
        except zlib.error as ex: err=str(ex); break
        if not dec.eof: err='incomplete trailing gzip member excluded'; break
        try:
            lines=part.splitlines()
            if part and not part.endswith(b'\n'): raise ValueError('complete member ends without record newline')
            rows=[json.loads(line) for line in lines]
        except (ValueError,UnicodeError) as ex: err=str(ex); break
        used=len(left)-len(dec.unused_data); consumed+=used; complete+=1
        membermeta.append({'member':complete,'bytes':used,'records':len(rows),'maxTick':max((x.get('tick',-1) for x in rows),default=None)})
        records.extend(rows); left=dec.unused_data
    meta.update({'completeMembers':complete,'completeBytes':consumed,'completePrefixSHA256':digest(raw[:consumed]),'excludedTailBytes':len(raw)-consumed,'excludedTailReason':err,'records':len(records),'maxRecordTick':max((x.get('tick',-1) for x in records),default=None),'members':membermeta})
    return records, meta, raw[:consumed]
report_raw, report_meta=stable(SRC/(PREFIX+'.json')); source_report=json.loads(report_raw)
framepaths=sorted((SRC/(PREFIX+'.frames')).glob('*.json.gz'), key=lambda p:int(p.name.split('.')[0]))
cutoff=max(int(p.name.split('.')[0]) for p in framepaths if int(p.name.split('.')[0])<=source_report['result']['tick'])
if (OUT/f'observation-{cutoff}.json').exists(): raise SystemExit(f'Cutoff {cutoff} already sealed; await a new complete frame')
frames={}; frame_manifest=[]
for path in framepaths:
    tick=int(path.name.split('.')[0])
    if tick>cutoff: continue
    raw,meta=stable(path); dec=zlib.decompressobj(31); data=dec.decompress(raw)
    if not dec.eof or dec.unused_data: raise ValueError('Frame not exactly one complete member: '+str(path))
    frame=json.loads(data); assert frame['snapshot']['tick']==tick
    frames[tick]=frame; meta['tick']=tick; frame_manifest.append(meta)
    if tick in [0,7200,7800,10200,10800,11400,cutoff]: (OUT/(f'evidence-frame-{tick}.json.gz')).write_bytes(raw)
streams={}; stream_manifest={}
for name in ['commands','plans','native-hits','native-events','native-deaths','ship-losses','corpse-events','samples','health-transitions','healing-effects']:
    rows,meta,compressed=members(SRC/(PREFIX+'-'+name+'.jsonl.gz'))
    def before_cutoff(r):
        tick=r.get('tick',-1)
        if tick != cutoff: return tick < cutoff
        if name in ['commands','plans']: return False
        if r.get('stage')=='after-command': return False
        if name=='native-hits' and r.get('commandIndex') is not None: return False
        return True
    streams[name]=[r for r in rows if before_cutoff(r)]
    meta['recordsAtOrBeforeCutoff']=len(streams[name]);stream_manifest[name]=meta
    (OUT/(f'evidence-{cutoff}-{name}.jsonl.gz')).write_bytes(compressed)
latest=frames[cutoff]; snap=latest['snapshot']; deaths=streams['native-deaths']; hits=streams['native-hits']; commands=streams['commands']
def body(e): return e.get('atObservation') or e.get('previous') or e.get('after') or e.get('unit') or {}
def cause(e):
    b=body(e); evidence=e.get('evidence') or {}; hit=evidence.get('nativePositiveToNonpositiveHit')
    if evidence.get('aboardLivingAtHullFatal'): return 'drowning-alive-aboard-fatal-hull'
    if e.get('terminalClass')=='lifetime-expiry-eligible-removal': return 'lifetime-expiry-eligible-removal'
    if hit and hit.get('tick')==e['tick']:
        return 'native-hit-by-neutral' if hit['attackerOwner']=='neutral' else 'native-hit-by-same-owner' if hit['attackerOwner']==b.get('owner') else 'native-hit-by-opponent'
    if e.get('terminalClass')=='death-observed': return 'death-other-or-unresolved'
    return e.get('terminalClass','status-update')
def compact_death(e):
    b=body(e);ev=e.get('evidence')or{};hit=ev.get('nativePositiveToNonpositiveHit') or e.get('lastNativeHit') or {}
    return {'tick':e['tick'],'stage':e.get('stage'),'commandIndex':e.get('commandIndex'),'id':e['id'],'type':e['type'],'owner':b.get('owner'),'kind':b.get('kind'),'permanent':e.get('permanent'),'expiresTick':b.get('expiresTick'),'hpAtPreviousBoundary':b.get('hp'),'terminalClass':e.get('terminalClass'),'confirmation':e.get('confirmation'),'cause':cause(e),'attacker':hit.get('attacker'),'attackerOwner':hit.get('attackerOwner'),'hitTick':hit.get('tick'),'hpBefore':hit.get('hpBefore'),'hpAfter':hit.get('hpAfter'),'corpseId':(ev.get('corpse')or{}).get('id'),'shipId':(b.get('deck')or{}).get('shipId'),'aboardLivingAtHullFatal':ev.get('aboardLivingAtHullFatal'),'expiryEligible':ev.get('expiryEligible')}
terminal=[compact_death(e) for e in deaths if e['type']=='native-unit-terminal']
p0perm=[e for e in terminal if e['owner']=='p0' and e['permanent'] and e['terminalClass']=='death-observed']
first_ids=[e['id'] for e in p0perm[:2]]
first_evidence={}
for uid in first_ids:
    death=next(e for e in deaths if e.get('id')==uid and e['type']=='native-unit-terminal')
    linkedcommands=[c for c in commands if uid in json.dumps(c['command'])]
    first_evidence[uid]={'death':death,'hits':[h for h in hits if h['target']==uid], 'commandAttempts':linkedcommands,'healingTransitions':[h for h in streams['health-transitions'] if h['id']==uid and h['after']['hp']>h['before']['hp']], 'nearbyOwnerPlans':[p for p in streams['plans'] if death['tick']-90<=p['tick']<=death['tick']+15]}
rollups=[]
for tick,frame in frames.items():
    s=frame['snapshot']; ownerrows={}
    for o in OWNERS:
        us=[u for u in s['units'] if u['owner']==o];bs=[b for b in s['buildings'] if b['owner']==o]; m=frame['memories'][o] or {}
        ownerrows[o]={'gold':s['players'][o]['gold'],'supply':s['players'][o]['supplyUsed'],'cap':s['players'][o]['supplyCap'],'units':len(us),'permanentUnits':sum('expiresTick' not in u for u in us),'temporaryUnits':sum('expiresTick' in u for u in us),'unitKinds':dict(collections.Counter(u['kind'] for u in us)),'buildings':len(bs),'buildingKinds':dict(collections.Counter(b['kind'] for b in bs)),'bases':[{k:b.get(k) for k in ['id','x','y','hp','complete']} for b in bs if b['kind']=='townHall'],'unitsLostNativeIncludingTemporary':s['match']['stats']['unitsLost'][o],'unitsKilledNativeIncludingTemporary':s['match']['stats']['unitsKilled'][o],'unitsKilledByNeutral':s['match']['stats']['unitsKilledByNeutral'][o],'goldSpent':s['match']['stats']['goldSpent'][o],'v6':m.get('v6'),'naval':m.get('naval'),'claimKinds':dict(collections.Counter(v.get('kind') for v in m.get('unitClaims',{}).values()))}
    rollups.append({'tick':tick,'match':s['match'],'players':ownerrows})
summary={'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cutoffTick':cutoff,'source':source_report['source'],'head':source_report['head'],'setup':source_report['setup'],'resultAtRead':source_report['result'],'observationOnly':True,'simulationOrPlannerExecutions':0,'framePhase':'600-tick after-step snapshot before same-tick planner; same-tick command/plans excluded', 'nativeCommandAcceptanceCaution':'commands are SDK onCommand attempts; retained orders, births, deck relations, native hits and state counters are distinct execution evidence','sourceReport':report_meta,'frames':frame_manifest,'streams':stream_manifest,'terminalSummary':terminal,'firstTwoP0PermanentLossIds':first_ids,'latestStats':snap['match']['stats'],'latestOwnerMemories':latest['memories'],'latestPlayerSummary':rollups[-1]['players'],'hitKinds':{str(k):v for k,v in collections.Counter((h['attackerOwner'],h['attackerKind']) for h in hits).items()},'allFrames':rollups,'remainingBlockers':['Live match is not complete unless source result naturalComplete is true.','Cold restore is not exercised by this observer; no restoration exactness claimed.','Current output streams may include newer ticks; claims here are capped at the named complete frame.','No browser/native drawWorld visual was run; conclusions use native IDs, saved states, hits, corpses, counters and memories.']}
summary['nativeActivity']={'lastGlobalHitTick':max((h['tick'] for h in hits),default=None),'lastHitByAttackerOwner':{o:max((h['tick'] for h in hits if h['attackerOwner']==o),default=None) for o in ['p0','p1','neutral']},'lastBattleDeathTick':max((e['tick'] for e in terminal if e['terminalClass']=='death-observed'),default=None)}
summary['nativeActivity']['ticksSinceLastGlobalHit']=cutoff-(summary['nativeActivity']['lastGlobalHitTick'] or 0)
summary['nativeActivity']['lastDifferentOwnerHitTick']=max((h['tick'] for h in hits if h['attackerOwner']!=h['targetOwner']),default=None)
summary['nativeActivity']['lastSameOwnerHitTick']=max((h['tick'] for h in hits if h['attackerOwner']==h['targetOwner']),default=None)
checks=[]
for row in rollups:
    for owner in ['p0','p1','neutral']:
        observed=sum(e['owner']==owner and e['terminalClass']=='death-observed' and (e['tick']<row['tick'] or e['tick']==row['tick'] and e.get('stage')!='after-command') for e in terminal)
        native=row['match']['stats']['unitsLost'][owner]
        checks.append({'tick':row['tick'],'owner':owner,'observedDeaths':observed,'nativeUnitsLost':native,'equal':observed==native})
live_positive_ids={u['id'] for u in snap['units'] if u['hp']>0}
status_updates=[e for e in deaths if e['type']=='terminal-status-update']
validation={'terminalStatusUpdates':status_updates,'terminalIdsStillAliveAtCutoff':[e['id'] for e in terminal if e['id'] in live_positive_ids],'cutoffTick':cutoff,'counterChecks':checks,'allCounterChecksMatch':all(c['equal'] for c in checks),'allFrameReadsStable':all(r['statUnchangedDuringRead'] for r in frame_manifest),'planRecordsBeforeFrame':len(streams['plans']),'sourceReportPlanCount':source_report['planCount'],'planRecordsReconcile':len(streams['plans'])==source_report['planCount'],'excludedTailBytes':{k:m['excludedTailBytes'] for k,m in stream_manifest.items()}}
dump(OUT/f'validation-{cutoff}.json',validation)
summary['validation']=validation
dump(OUT/f'observation-{cutoff}.json',summary)
dump(OUT/f'first-two-p0-loss-evidence-{cutoff}.json',first_evidence)
(OUT/f'evidence-source-report-{cutoff}.json').write_bytes(report_raw)
classes={o:dict(collections.Counter(('permanentBattle' if e['permanent'] else 'temporaryBattle') if e['terminalClass']=='death-observed' else e['cause'] for e in terminal if e['owner']==o)) for o in ['p0','p1','neutral']}
textlines=[f'追加观察截止{cutoff} tick；自然终局={source_report["result"]["naturalComplete"]}，winner={source_report["result"]["winner"]}。仅被动Python读取完整rename帧与完整gzip members。本新局只读原始输出未改。', '', '全局terminal分类（永久/临时战斗死亡与寿命到期分开）：',json.dumps(classes,ensure_ascii=False), '', '当前全部两方实际状态：']
for o,r in rollups[-1]['players'].items():
    textlines.append(f'{o}: gold{r["gold"]}, supply{r["supply"]}/{r["cap"]}, 永久{r["permanentUnits"]}, 临时{r["temporaryUnits"]}, unitsLost{r["unitsLostNativeIncludingTemporary"]}, unitsKilled{r["unitsKilledNativeIncludingTemporary"]}, goldSpent{r["goldSpent"]}; unitKinds='+json.dumps(r['unitKinds'],ensure_ascii=False)+'; bases='+json.dumps(r['bases'],ensure_ascii=False))
textlines += ['', '完整两方memory、全部600帧及自然terminal帧账、源路径/SHA256、terminal ID与分类见observation-'+str(cutoff)+'.json；validation-'+str(cutoff)+'.json中counter全部一致='+str(validation['allCounterChecksMatch'])+'，ownerplan计数对齐='+str(validation['planRecordsReconcile'])+'。不从public attempt推导accepted，不将计划或局部无损视为完成或验收。自然结果与实际退出凭据分开核验。']
(OUT/f'UPDATE-{cutoff}.zh.md').write_text('\n'.join(textlines)+'\n')
dump(OUT/'LATEST.json',{'cutoffTick':cutoff,'primaryNarrative':f'UPDATE-{cutoff}.zh.md','summary':f'observation-{cutoff}.json','validation':f'validation-{cutoff}.json','naturalComplete':source_report['result']['naturalComplete'],'winner':source_report['result']['winner']})

print(json.dumps({'out':str(OUT),'cutoffTick':cutoff,'sourceResult':source_report['result'],'frames':len(frames),'terminalRecords':len(terminal),'p0PermanentLosses':p0perm,'p0TemporaryTerminals':[e for e in terminal if e['owner']=='p0' and not e['permanent']],'latestPlayers':{o:{k:r[k] for k in ['gold','supply','cap','units','permanentUnits','temporaryUnits','unitKinds','buildingKinds','bases','unitsLostNativeIncludingTemporary']} for o,r in rollups[-1]['players'].items()},'streamReadStatus':{k:{a:v[a] for a in ['completeMembers','excludedTailBytes','maxRecordTick','recordsAtOrBeforeCutoff']} for k,v in stream_manifest.items()}},ensure_ascii=False,indent=2))
