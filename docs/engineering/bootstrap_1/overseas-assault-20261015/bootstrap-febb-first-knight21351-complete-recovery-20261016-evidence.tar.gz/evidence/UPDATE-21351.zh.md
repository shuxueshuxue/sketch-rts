追加观察截止21351 tick；自然终局=True，winner=p0。仅被动Python读取完整rename帧与完整gzip members。本新局只读原始输出未改。

全局terminal分类（永久/临时战斗死亡与寿命到期分开）：
{"p0": {"permanentBattle": 15}, "p1": {"permanentBattle": 63}, "neutral": {"permanentBattle": 19}}

当前全部两方实际状态：
p0: gold496.68, supply81/94, 永久49, 临时0, unitsLost15, unitsKilled61, goldSpent13668; unitKinds={"worker": 26, "contractArcher": 2, "priest": 4, "witch": 4, "horseArcher": 1, "raider": 3, "knight": 6, "ballista": 3}; bases=[{"id": "building-p0-townhall", "x": 3248, "y": 848, "hp": 900, "complete": true}, {"id": "building-p0-townHall-1408", "x": 3280, "y": 1808, "hp": 900, "complete": true}, {"id": "building-p0-townHall-2970", "x": 2864, "y": 3280, "hp": 900, "complete": true}, {"id": "building-p0-townHall-3471", "x": 2224, "y": 2192, "hp": 900, "complete": true}, {"id": "building-p0-townHall-8797", "x": 1552, "y": 1104, "hp": 900, "complete": true}]
p1: gold74, supply0/0, 永久0, 临时0, unitsLost63, unitsKilled21, goldSpent9921; unitKinds={}; bases=[]

完整两方memory、全部600帧及自然terminal帧账、源路径/SHA256、terminal ID与分类见observation-21351.json；validation-21351.json中counter全部一致=True，ownerplan计数对齐=True。不从public attempt推导accepted，不将计划或局部无损视为完成或验收。自然结果与实际退出凭据分开核验。
