import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const OUT='/tmp/febb-first-knight-v3-observation-20261016';
const config=JSON.parse(readFileSync(OUT+'/render-two-specs.json','utf8'));
const audit=JSON.parse(readFileSync(OUT+'/render-dependency-audit.json','utf8'));
const sha=(x:any)=>createHash('sha256').update(x).digest('hex');
const sourceMatches=()=>audit.runtimeGraphFiles.every((f:any)=>sha(readFileSync(f.path))===f.sha256);
assert.equal(audit.gameConstructorTextMatches.length,0);
assert.equal(audit.issues.length,0);
assert.ok(sourceMatches(),'Renderer dependency bytes changed after preparation');
const {createCanvas}=createRequire(config.source+'/package.json')('@napi-rs/canvas');
// Deliberately avoid recorder/record.ts: its unrelated recording entrypoint imports Game.
const {setScratchCanvasFactory}=await import(pathToFileURL(config.source+'/src/client/art/scratch-canvas.ts').href);
setScratchCanvasFactory((w:number,h:number)=>createCanvas(w,h));
const {drawWorld}=await import(pathToFileURL(config.source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(config.source+'/src/client/unit-facing.ts').href);
for(const spec of config.specs){
  const raw=readFileSync(spec.input);assert.equal(sha(raw),spec.inputSHA256);
  assert.equal(sha(gunzipSync(raw)),spec.beforeSavedWorldBytesSHA256);
  const frame=JSON.parse(gunzipSync(raw).toString());assert.equal(frame.snapshot.tick,spec.tick);
  const before=sha(JSON.stringify(frame));
  const canvas=createCanvas(spec.width,spec.height),ctx=canvas.getContext('2d');
  drawWorld({ctx:ctx as any,snapshot:frame.snapshot,view:spec.view,now:spec.tick*50,facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String},viewer:'p0',selectedIds:new Set(spec.selectedIds)});
  assert.equal(sha(JSON.stringify(frame)),before,'Renderer changed saved frame object');
  assert.equal(sha(readFileSync(spec.input)),spec.inputSHA256,'Input frame bytes changed');
  const output=OUT+'/native-'+spec.label+'.png';writeFileSync(output,canvas.toBuffer('image/png'));
  writeFileSync(output+'.json',JSON.stringify({classification:'Native static drawWorld of exact saved actual full world; no Game/step/commands/planner/restore/browser. Fresh static facing is not historical animation reconstruction.',source:config.source,head:config.head,spec,sourceDependencyBytesUnchanged:sourceMatches(),inputObjectUnchanged:true,beforeWorldObjectSHA256:before,afterWorldObjectSHA256:sha(JSON.stringify(frame)),pngSHA256:sha(readFileSync(output)),output},null,2)+'\n');
  console.log(output);
}
assert.ok(sourceMatches());
