"""V3 active-two prepared launcher. No Game until root actually transfers a slot and every fresh gate passes."""
from pathlib import Path
import subprocess,json,hashlib,datetime,time,shutil,os,sys,traceback
D=Path('/workspace/.playtest/bootstrap-febb-first-use-knight-v5-pineshade-v3-20261016');RAW=Path('/tmp/bootstrap-febb-first-use-knight-v5-pineshade-v3-20261016');S=Path('/workspace/sketch-rts-febb9951-first-knight-fixed-control');HEAD='febb9951ef6639963ac2dde925bccc0e14eb0ac5';SEED='bootstrap_1-first-use-knight-v5-20261016-1517z-a';P=RAW/'first-use-knight-v5-febb9951'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Neither this Python launcher nor its Node child depends on a long tool stdout/stderr pipe.
outfd=os.open(D/'launcher-stdout.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o644)
errfd=os.open(D/'launcher-stderr.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o644)
os.dup2(outfd,1);os.dup2(errfd,2);os.close(outfd);os.close(errfd)
started=time.monotonic();receipt={'sourceHead':HEAD,'seed':SEED,'enteredAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nodeSpawned':False,'preparationRoot':str(D),'outputPrefix':str(P),'stdoutStderrArePersistent':True}
attempt=len(list(D.glob('process-exit-*.json')))+1
try:
 prepared=json.loads((D/'PREPARED.json').read_text());assert prepared['preparedOnlyNoGameNoNode'] and prepared['sourceHead']==HEAD
 for p,h in prepared['launchBoundFiles'].items():assert H(p)==h,p
 b=json.loads((D/'driver-preflight.json').read_text());policy=json.loads((D/'resource-policy.json').read_text())
 assert b['sourceHead']==HEAD and b['sourceRoot']==str(S) and b['outputPrefix']==str(P)
 assert b['sourceManifestFiles']==1517 and b['frozenFullFiles']==497 and b['frozenManifestFiles']==184
 for p,h in b['boundFiles'].items():assert H(p)==h,p
 assert H(D/b['driverFile'])==b['driverSHA256'] and H(D/'package.json')==b['externalModuleContext']['sha256']
 for n,h in b['dependencies'].items():assert H(D/n)==h,n
 assert H(D/'resource-policy.json')==b['resourcePolicySHA256']
 assert not(RAW/'observation-stop.json').exists()
 cap=json.loads(Path(b['runtimeSourceCapPath']).read_text());assert H(b['runtimeSourceCapPath'])==b['runtimeSourceCapSHA256']
 assert len(cap['files'])==1517 and len(cap['frozenFiles'])==497
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True)
 for f in cap['files']:assert H(S/f['path'])==f['sha256'],f['path']
 for path,key in [(cap['sourceArchive'],'sourceArchiveSHA256'),(cap['frozenArchive'],'frozenArchiveSHA256')]:assert H(path)==cap[key]
 assert not list(RAW.glob(P.name+'*')),'Existing factory/raw output must never be overwritten or restarted'
 slot=D/'PARENT-SLOT-TRANSFER.json';assert slot.exists(),'Await actual root slot transfer; no Node'
 auth=json.loads(slot.read_text())
 assert auth.get('authorizedByParent')is True and auth.get('actualSlotTransferred')is True and auth.get('sourceHead')==HEAD and auth.get('sourceManifestFiles')==1517 and auth.get('runtimeSourceCapSHA256')==b['runtimeSourceCapSHA256'] and auth.get('seed')==SEED and auth.get('driverSHA256')==b['driverSHA256'] and auth.get('resourcePolicySHA256')==b['resourcePolicySHA256'] and auth.get('outputPrefix')==str(P)
 cur=int(Path('/sys/fs/cgroup/memory.current').read_text());mx=int(Path('/sys/fs/cgroup/memory.max').read_text());space=shutil.disk_usage(RAW).free;tmp=shutil.disk_usage('/tmp').free
 guard={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':HEAD,'rawHeadroomBeforeSpawn':mx-cur,'requiredHeadroom':2*1024**3,'heapMiB':768,'outputRoot':str(RAW),'outputFreeBytes':space,'requiredOutputFreeBytes':1024**3,'temporaryFreeBytes':tmp,'requiredTemporaryFreeBytes':128*1024**2,'outputAndFrozenTemporaryDataCountTowardCgroupMemory':True,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text(),'parentSlotTransferSHA256':H(slot),'resourcePolicySHA256':b['resourcePolicySHA256'],'driverSHA256':b['driverSHA256'],'factoryNotYetCreated':True}
 guardnum=len(list(D.glob('launch-guard-*.json')))+1;(D/f'launch-guard-{guardnum}.json').write_text(json.dumps(guard,indent=2)+'\n')
 assert mx-cur>=2*1024**3,'Fresh2GiB memory gate failed; no Node'
 assert space>=1024**3,'Fresh1GiB actual /tmp output filesystem gate failed; no Node'
 assert tmp>=128*1024**2,'Fresh128MiB frozen/planner temporary filesystem gate failed; no Node'
 with(D/'LAUNCH-ONCE.json').open('x')as f:json.dump({'atUTC':guard['atUTC'],'sourceHead':HEAD,'seed':SEED,'outputPrefix':str(P),'driverSHA256':b['driverSHA256'],'resourcePolicySHA256':b['resourcePolicySHA256']},f,indent=2)
 args=['node','--max-old-space-size=768','--import','tsx',str(D/b['driverFile']),str(S),HEAD,str(P)];env=os.environ.copy();env.pop('NODE_OPTIONS',None)
 nodeout=RAW/'node-stdout.log';nodeerr=RAW/'node-stderr.log'
 with nodeout.open('xb')as stdout,nodeerr.open('xb')as stderr:
  child=subprocess.Popen(args,cwd=S,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  receipt.update(nodeSpawned=True,nodePid=child.pid,nodeStdout=str(nodeout),nodeStderr=str(nodeerr),guardPath=str(D/f'launch-guard-{guardnum}.json'))
  (D/f'process-start-{attempt}.json').write_text(json.dumps(receipt,indent=2)+'\n')
  code=child.wait();stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
 receipt.update(exitCode=code,elapsedSeconds=time.monotonic()-started,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),nodeStdoutSHA256=H(nodeout),nodeStderrSHA256=H(nodeerr),oomAfter=Path('/sys/fs/cgroup/memory.events').read_text())
 (D/f'process-exit-{attempt}.json').write_text(json.dumps(receipt,indent=2)+'\n')
 raise SystemExit(code)
except SystemExit:raise
except BaseException as error:
 receipt.update(launcherError=repr(error),elapsedSeconds=time.monotonic()-started,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=None)
 (D/f'launcher-failure-{attempt}.json').write_text(json.dumps(receipt,indent=2)+'\n');traceback.print_exc();raise
