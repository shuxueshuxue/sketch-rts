V3只准备，0 Game/Node/tsc；v1/v2全部字节保留，v2另有可验证字节快照。共用独立strict febb9951控制与1517 cap、frozen497、manifest184/rules2。seed仍为从未启动过的原预定seed；没有换seed或开第二局。

workspace本D只放准备driver/元数据/引用/launch凭据；真实factory/native/600帧/全部两方记忆/滚动12行报告/Node stdout与stderr均在独立/tmp输出D。准备位置与raw前缀已在driver、declaration和父槽交接中绑定。/tmp输出与frozen planner临时数据都计入cgroup，不能把磁盘空闲当成独立内存。

保持原2GiB fresh内存、768MiB heap、1GiB actual输出FS、128MiB临时FS启动门，不降门。每600完整after-step状态观测真实输出空闲及cgroup余量：仅在没有自然winner时，若输出<128MiB或cgroup余量<256MiB，仅完整保存world/nextId/全部两方记忆/setup并flush，然后标authorized-resource-checkpoint退出；naturalComplete=false，不作胜负/验收。自然winner优先；此资源政策须父槽交接绑定source1517、driver SHA、policy SHA后才可生效。

两层stdout/stderr均重定向独立持久文件，Node会新建独立session并由Python等待；实际exit码、stdout/stderr hash与进程记录保存在workspace。不能依赖工具连接长pipe，更不能凭final文件猜exit0。

正常generated pineshade原2座位/ring/deepJungle，side0 v9_knight Grove vs正常frozen v5 Ember单敌，500金3工8cap/think15，实际agents仅p0/p1；memoryOwners动态取Object.keys(match.agents)，初始恰为两方null，frame和每次postMemories均只保存全部两方记忆。只选一个工厂配置，不跑矩阵；MAXSAFE自然结果优先，无任意tickdeadline。fullworld仅factory/600/终局异常/永久terminal事件，step timings每600聚合。

PARENT-SLOT-TRANSFER-TEMPLATE.json仅false模板，不是授权；当前没有实际槽交接文件，没有launch，也没有factory0。旧046 resource checkpoint另处封存，actual exit1/未知原因不混为自然结果；原未提交恢复缺口不动。未来cold恢复程度仍待实际验证。
