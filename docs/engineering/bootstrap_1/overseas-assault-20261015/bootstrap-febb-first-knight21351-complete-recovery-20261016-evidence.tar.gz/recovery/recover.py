"""Recover exact archived bytes into a NEW directory; Git/Python only, never launches a game."""
from pathlib import Path, PurePosixPath
import argparse, base64, gzip, hashlib, io, json, os, stat, subprocess, tarfile, zlib

def sha(b):return hashlib.sha256(b).hexdigest()
def gzip_members(data):
 n=0;left=data
 while left:
  d=zlib.decompressobj(31);d.decompress(left)
  if not d.eof:raise ValueError('incomplete gzip member')
  n+=1;left=d.unused_data
 return n
def safe_name(name):
 p=PurePosixPath(name)
 if p.is_absolute()or '..'in p.parts:raise ValueError('unsafe archive path '+name)
 return p
def write_file(path,data,mode,mtime_ns):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb')as f:f.write(data)
 os.chmod(path,mode);os.utime(path,ns=(mtime_ns,mtime_ns))
def blob_oid(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def recover(archive,destination):
 destination=Path(destination);assert not destination.exists(),'Recovery target must be new; originals are never overwritten'
 destination.mkdir();payload=destination/'payload';payload.mkdir()
 with tarfile.open(archive,'r:gz')as t:
  indexbytes=t.extractfile('INDEX.json').read();index=json.loads(indexbytes);rows={r['payloadPath']:r for r in index['payloads']}
  assert len(rows)==len(index['payloads'])
  members=t.getmembers();assert{m.name for m in members}==set(rows)|{'INDEX.json'}
  for m in members:
   safe_name(m.name);assert m.isfile()
   if m.name=='INDEX.json':continue
   r=rows[m.name];data=t.extractfile(m).read()
   assert len(data)==r['bytes']and sha(data)==r['sha256']
   assert m.mode==r['mode']and m.pax_headers['recovery.original_mtime_ns']==str(r['mtime_ns'])
   if r['gzipMemberCount']is not None:assert gzip_members(data)==r['gzipMemberCount']
   write_file(payload/m.name,data,r['mode'],r['mtime_ns'])
  (destination/'INDEX.json').write_bytes(indexbytes)
 meta=index['recovery']
 source_inventory=json.loads((payload/meta['sourceInventoryPayload']).read_text())['files']
 frozen_inventory=json.loads((payload/meta['frozenInventoryPayload']).read_text())['files']
 source=destination/'source';frozen=destination/'frozen';source.mkdir();frozen.mkdir()
 for archive_name,target,inventory in [(meta['sourceArchivePayload'],source,source_inventory),(meta['frozenArchivePayload'],frozen,frozen_inventory)]:
  expected={r['path']:r for r in inventory}
  with tarfile.open(payload/archive_name,'r:gz')as t:
   files={m.name:m for m in t.getmembers()if m.isfile()};assert set(files)==set(expected)
   assert all(m.isdir()or m.isfile()for m in t.getmembers())
   for name,m in files.items():
    safe_name(name);r=expected[name];data=t.extractfile(m).read()
    assert len(data)==r['bytes']and sha(data)==r['sha256']and blob_oid(data)==r['gitBlob']
    assert m.mode==r['archiveMode']and m.mtime==r['archiveMtime']
    write_file(target/name,data,r['mode'],r['mtime_ns'])
 def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=source,input=input)
 git('init','--quiet')
 objects=json.loads(gzip.decompress((payload/meta['gitMetadataPayload']).read_bytes()))['objects']
 def store(kind,data,oid):
  raw=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data
  assert hashlib.sha1(raw).hexdigest()==oid
  path=source/'.git/objects'/oid[:2]/oid[2:];path.parent.mkdir(parents=True,exist_ok=True)
  if not path.exists():path.write_bytes(zlib.compress(raw))
 for obj in objects:store(obj['type'],base64.b64decode(obj['base64']),obj['oid'])
 for target,inventory in [(source,source_inventory),(frozen,frozen_inventory)]:
  for row in inventory:store('blob',(target/row['path']).read_bytes(),row['gitBlob'])
 git('config','core.filemode','true');git('config','core.logallrefupdates','false')
 (source/'.git/refs/heads/recovered-exact').write_text(meta['sourceHead']+'\n');(source/'.git/HEAD').write_text('ref: refs/heads/recovered-exact\n')
 git('read-tree',meta['sourceHead'])
 selected={r['path']for r in source_inventory};all_paths=git('ls-files','-z').split(b'\0');excluded=[p for p in all_paths if p and p.decode()not in selected]
 if excluded:git('update-index','--skip-worktree','-z','--stdin',input=b'\0'.join(excluded)+b'\0')
 assert git('rev-parse','HEAD').decode().strip()==meta['sourceHead']
 assert git('status','--porcelain','--untracked-files=all')==b''
 archived=git('archive',meta['frozenRevision'],'package.json','src/ai','src/sdk','src/shared')
 with tarfile.open(fileobj=io.BytesIO(archived),mode='r:')as t:
  actual={m.name:sha(t.extractfile(m).read())for m in t.getmembers()if m.isfile()}
 assert actual=={r['path']:r['sha256']for r in frozen_inventory}
 assert len(source_inventory)==1517 and len(frozen_inventory)==497
 materialized={str(p.relative_to(source))for p in source.rglob('*')if p.is_file()and '.git'not in p.relative_to(source).parts}
 assert materialized=={r['path']for r in source_inventory}
 assert{str(p.relative_to(frozen))for p in frozen.rglob('*')if p.is_file()}=={r['path']for r in frozen_inventory}
 manifest=json.loads((source/'docs/engineering/bootstrap_1/frozen-policy.json').read_text());assert manifest['rulesVersion']==2 and manifest['revision']==meta['frozenRevision']and len(manifest['files'])==184
 assert all(sha((frozen/p).read_bytes())==h for p,h in manifest['files'].items())
 pathmap={r['originalPath']:str(payload/r['payloadPath'])for r in index['payloads']}
 pathmap[meta['originalSourceRoot']]=str(source)
 (destination/'ORIGINAL-PATH-MAP.json').write_text(json.dumps(pathmap,ensure_ascii=False,indent=2)+'\n')
 report={'archiveSHA256':sha(Path(archive).read_bytes()),'indexSHA256':sha(indexbytes),'payloads':len(rows),'allPayloadBytesModesMtimesVerified':True,'payloadGzipMembersCRCVerified':True,'source1517Exact':True,'frozen497Exact':True,'rules2Manifest184Exact':True,'sourceHead':meta['sourceHead'],'gitStatusClean':True,'frozenGitArchiveFullyRecovers497':True,'sourceMetadataObjects':len(objects),'selectedSourceRepositoryOnlyNotCompleteGitObjectDatabase':True,'onlySelected1517AndFrozen497Materialized':True,'destination':str(destination),'noNodeGameOrSimulation':True,'pathMap':'ORIGINAL-PATH-MAP.json','limits':'Restores exact archived selected source/driver/world/id/setup/memories and Git metadata for required audits/archive; not a complete Git history/object database. No Game snapshot hydration/replay is performed or claimed exact. External runtime dependencies are declared by archived package-lock/context; no Node/vendor binary is launched by this recovery.'}
 (destination/'RECOVERY-VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 return report

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('archive');parser.add_argument('--destination',required=True);args=parser.parse_args();print(json.dumps(recover(args.archive,args.destination),ensure_ascii=False))
