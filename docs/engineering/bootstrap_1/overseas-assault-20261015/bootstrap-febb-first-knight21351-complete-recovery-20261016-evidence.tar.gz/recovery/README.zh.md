完整胜局恢复包：febb1517 / knight vs frozenv5 / pineshade 首次生成 ordinary0。

真实自然P0胜于21351，actual process exit0；P0存活49永久、死亡15永久（3中立/12敌方）；97 terminal另有1延迟cleanup更新，不能算98死亡。P1全部63单位与18建筑清零，最后farm1060在21351受P0弓手1083的19伤，12→-7。此seed首次开局有效，之后已开发见过；不构成三路线或两敌海战全面验收。

包内包含原170文件完整raw、实际V3 driver/launcher/所有launch与exit凭据、sourcecap与初始种子检索、完整1517源码和497 frozen源码nested archives、严格Git commit/tree元数据、审计与micro evidence、root亲看PNG凭据和实际PNG。observer已复制的同raw gzip/frames不再重复加入。INDEX逐payload保存原路径、SHA256、bytes、mode、mtime_ns；nested源码逐文件另有Gitblob与metadata清单。frozen临时目录退出时已清理，包中保存规范归档metadata并明确不冒称原临时目录未记录的metadata。

只恢复到新的空路径：python3 recover.py COMPLETE-GAME.tar.gz --destination NEW_DIRECTORY
该工具仅Python/Git，检查每payload字节/mode/mtime与gzip CRC，恢复source1517和frozen497及其Git出处，核HEAD/clean status及原git archive命令。它不启动Node，不hydrate Game、不重演比赛。完整world/nextId/setup/全部两方mem原件均在payload/actual-raw中。默认绝不写原路径；ORIGINAL-PATH-MAP.json明确恢复后的路径映射。若未来在隔离空workspace原路径重建，可用INDEX映射还原原布局；不得覆盖现有source/raw。

保留原始source与cap字节，不为新路径改写caps/driver。恢复repo仅物化selected1517与frozen497，commit/tree元数据让所需HEAD审计和frozen archive可执行；这不是完整Git历史/对象库，其他docs/art/blob不物化。外部Node/npm运行环境依赖由原package-lock及RUNTIME-DEPENDENCY-CONTEXT声明，不把依赖安装或真实Game恢复测试冒作已完成。下一twoShores不同case的精确source/cap仍待root validated1543，未混入本febb1517包。

V2恢复范围补充：标准运行恢复应将selected1517覆入已有或正常fetch exactfebb9951的完整repo，并具备d1ae frozen revision；包内源/fixture字节不依赖网络，完整Git对象可以来自原repo。这里的离线验证repo只有selected blobs和必要commit/tree元数据，不是完整Git对象库。实际git archive命令exit0且497输出SHA全exact，但对排除的.github workflow blob发出一条非致命stderr；原文与逐命令审计已收入RECOVERY-SCOPE及GIT-PARTIAL-REPOSITORY-COMMAND-AUDIT，不隐去也不伪造补齐。所有原raw/source与v1包保留。
