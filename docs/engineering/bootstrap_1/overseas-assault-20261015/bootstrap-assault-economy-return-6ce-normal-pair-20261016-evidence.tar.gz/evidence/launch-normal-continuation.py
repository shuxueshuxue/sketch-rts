from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import subprocess
import sys

D = Path(__file__).parent
label, = sys.argv[1:]
case = 'continuation'
p = D / 'PREPARED-normal-continuation-256200.json'
manifest_hashes = {'continuation': 'eedbf73e04be9e67a8a749305e4ee739d8bf3f5da9722b55ee922b78639ffb60'}
sha = lambda b: hashlib.sha256(b).hexdigest()
if sha(p.read_bytes()) != manifest_hashes[case]:
    raise SystemExit('prepared manifest changed')
m = json.loads(p.read_text())
for name, expected in m['payloads'].items():
    if sha(Path(name).read_bytes()) != expected:
        raise SystemExit('bound payload changed: ' + name)
source = json.loads(Path(m['sourceManifest']).read_text())
if Path(m['output']).exists():
    raise SystemExit('output exists; no automatic rerun')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source['root'], text=True).strip() != source['head']:
    raise SystemExit('source HEAD changed')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=source['root'], text=True):
    raise SystemExit('source dirty')
record = D / f'{label}-resource.json'
if record.exists():
    raise SystemExit('exclusive launch label already exists')
tmp = Path('/workspace/.playtest/bootstrap-assault-economy-return-runtime-tmp-20261016')
tmp.mkdir(exist_ok=True)
cgroup = Path('/sys/fs/cgroup')
maximum = int((cgroup / 'memory.max').read_text())
current = int((cgroup / 'memory.current').read_text())
disk = os.statvfs(D)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
argv = ['node', '--max-old-space-size=768', '--import', 'tsx', str(D / 'normal-continuation-from-256185-PREPARED.mts'), str(p)]
receipt = {'classification': 'Samefixed6ce normal3AI continuation after exact15tick cold prefix to actual256200. No manual commands or resource addition; naturalwinner or real resource/observer pause, no arbitrary time cutoff. Not bootstrap acceptance.', 'case': case, 'manifest': str(p), 'manifestSHA256': manifest_hashes[case], 'source': source['root'], 'head': source['head'], 'output': m['output'], 'argv': argv, 'heapMiB': 768, 'pre': {'atUTC': now(), 'memoryMax': maximum, 'memoryCurrent': current, 'rawHeadroom': maximum-current, 'requiredHeadroom': 2147483648, 'memoryEvents': (cgroup/'memory.events').read_text(), 'memoryPressure': (cgroup/'memory.pressure').read_text() if (cgroup/'memory.pressure').exists() else None, 'memoryStat': (cgroup/'memory.stat').read_text(), 'diskAvailable': disk.f_bavail*disk.f_frsize, 'requiredDisk': 268435456}, 'spawned': False}
with record.open('x') as target:
    json.dump(receipt, target, indent=2); target.write('\n')
if receipt['pre']['rawHeadroom'] < 2147483648 or receipt['pre']['diskAvailable'] < 268435456:
    print(json.dumps({'spawned': False, 'record': str(record), 'rawHeadroom': maximum-current, 'diskAvailable': receipt['pre']['diskAvailable']}), flush=True)
    raise SystemExit(75)
env = dict(os.environ)
env.pop('NODE_OPTIONS', None)
env['TMPDIR'] = str(tmp)
env['GIT_OPTIONAL_LOCKS'] = '0'
log_path = D / f'{label}.log'
with log_path.open('x') as log:
    child = subprocess.Popen(argv, cwd=source['root'], env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt.update({'spawned': True, 'actualPID': child.pid, 'startedAtUTC': now(), 'log': str(log_path)})
    record.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'spawned': True, 'actualPID': child.pid, 'record': str(record), 'rawHeadroom': maximum-current, 'output': m['output']}), flush=True)
    exit_code = child.wait()
receipt['post'] = {'atUTC': now(), 'exitCode': exit_code, 'maxChildRSSKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, 'memoryEvents': (cgroup/'memory.events').read_text(), 'memoryCurrent': int((cgroup/'memory.current').read_text())}
record.write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'actualPID': child.pid, 'exitCode': exit_code, 'record': str(record), 'finishedAtUTC': receipt['post']['atUTC']}), flush=True)
raise SystemExit(exit_code)
