import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync, readdirSync, statfsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual as equal } from 'node:util';
import { join } from 'node:path';
import { NativeLedger } from './observer-ledger';

const launchManifestPath = process.argv[2]!;
const launch = JSON.parse(readFileSync(launchManifestPath, 'utf8'));
const { sourceManifest: manifest, input, queryResult, output: out } = launch;
const source = JSON.parse(readFileSync(manifest, 'utf8'));
if (existsSync(out) && readdirSync(out).length) throw Error('new empty output required');
mkdirSync(out, { recursive: true });
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
const copy = (value: any) => JSON.parse(JSON.stringify(value));
if (sha(readFileSync(import.meta.filename)) !== launch.driverSHA256) throw Error('bound driver changed');
for (const [path, hash] of Object.entries(launch.payloads)) if (sha(readFileSync(path)) !== hash) throw Error('bound payload changed ' + path);
const diskNow = () => { const disk = statfsSync(out); return { atUTC: new Date().toISOString(), availableBytes: disk.bavail * disk.bsize }; };
if (!Number.isSafeInteger(launch.minimumFreeDiskBytes) || launch.minimumFreeDiskBytes <= 0) throw Error('explicit disk resource profile required');
const diskInitial = diskNow();
if (diskInitial.availableBytes < launch.minimumFreeDiskBytes) throw Error('actual disk headroom below launch resource profile before Game creation');
const audit = () => {
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: source.root, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: source.root, encoding: 'utf8' });
  if (head !== source.head || status) throw Error('source head/status');
  for (const [path, hash] of Object.entries(source.hashes)) {
    if (sha(readFileSync(join(source.root, path))) !== hash) throw Error('source ' + path);
  }
  return { head, status, files: Object.keys(source.hashes).length };
};
const sourcePre = audit(), raw = readFileSync(input!);
if (sha(raw) !== launch.inputSHA256) throw Error('bound actual input changed');
const saved = JSON.parse(gunzipSync(raw).toString()), savedHash = sha(JSON.stringify(saved));
if (saved.snapshot.tick !== 250185) throw Error('wrong actual starting frame');
const load = (path: string) => import(join(source.root, path));
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { sameGround, walkableGoal }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runGameLoop }, { RULES_VERSION }] = await Promise.all([
  load('src/shared/sim.ts'), load('src/shared/terrain.ts'), load('src/ai/planner-context.ts'), load('scripts/bootstrap_1-planner.ts'),
  load('src/sdk/game-runner.ts'), load('src/shared/rules-version.ts'),
]);
if (RULES_VERSION !== 2 || frozenPolicyManifest.rulesVersion !== 2) throw Error('rules');
const game = createGame('bareDuel');
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
const memoryProvider = createAiMemoryProvider(copy(saved.memories));
const full = () => copy({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(saved.memories).map(owner => [owner, memoryProvider.get(owner)])) });
const initial = full(), restore = { persistedWorldExact: equal(initial.snapshot, saved.snapshot),
  nextIdExact: initial.nextId === saved.nextId, all3memoryExact: equal(initial.memories, saved.memories) };
writeFileSync(join(out, 'restore.json'), JSON.stringify(restore, null, 2));
if (Object.values(restore).some(value => !value)) {
  writeFileSync(join(out, 'actual-restored.json.gz'), gzipSync(JSON.stringify(initial)));
  throw Error('persisted input restore differs');
}
const agents = JSON.parse(readFileSync('/tmp/bootstrap-idle-economy-5457-20261016/agents-original.json', 'utf8'));
if (agents.p0.version !== 'v9_summoner' || agents.p1.version !== 'v5' || agents.p2.version !== 'v7'
  || Object.keys(agents).some(owner => agents[owner].controller !== 'external-agent' || agents[owner].team !== saved.snapshot.teams[owner])) throw Error('original normal agents/teams changed');
const normal = await createBootstrapCommandPlanner(memoryProvider), frozenRoot = frozenPolicyRoot();
const frozenCheck = () => {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([path, hash]) => sha(readFileSync(join(frozenRoot, path))) !== hash).map(([path]) => path);
  const paths = execFileSync('git', ['ls-tree', '-r', '--name-only', frozenPolicyManifest.revision, '--', 'package.json', 'src/ai', 'src/sdk', 'src/shared'], { cwd: source.root, encoding: 'utf8' }).trim().split('\n');
  const fullChanged = paths.filter(path => !readFileSync(join(frozenRoot, path)).equals(execFileSync('git', ['show', `${frozenPolicyManifest.revision}:${path}`], { cwd: source.root, maxBuffer: 8 * 1024 * 1024 })));
  if (changed.length || fullChanged.length || paths.length !== 497 || Object.keys(frozenPolicyManifest.files).length !== 184) throw Error('frozen source differs');
  return { revision: frozenPolicyManifest.revision, rulesVersion: 2, manifestFiles: 184, allSourceFiles: paths.length, changed, fullChanged };
};
const frozenPre = frozenCheck();
if (!equal(full(), initial)) throw Error('planner setup mutated input');
const expectedEntries = JSON.parse(readFileSync(join(queryResult!, 'all-entries.json'), 'utf8'));
const expectedMemories = JSON.parse(gunzipSync(readFileSync(join(queryResult!, 'post-p0-all3mem.json.gz'))).toString());
const expectedReport = JSON.parse(readFileSync(join(queryResult, 'REPORT.json'), 'utf8'));
let queryReuse: any = { reused: false };
if (expectedReport.sourcePost.head !== source.head) {
  const proof = JSON.parse(readFileSync(launch.queryReuseProof, 'utf8'));
  const prior = JSON.parse(readFileSync(proof.priorSourceManifest, 'utf8'));
  const path = 'src/ai/bootstrap_1/assault-return-transfers.test.ts';
  if (proof.onlyChangedTest !== path) throw Error('query reuse is not the recorded native hold test correction');
  if (proof.priorHead !== expectedReport.sourcePost.head || proof.currentHead !== source.head
    || prior.head !== proof.priorHead || proof.currentSourceManifest !== manifest
    || !equal(Object.keys(prior.hashes).sort(), Object.keys(source.hashes).sort())) throw Error('query reuse source binding');
  const changed = Object.keys(source.hashes).filter(key => source.hashes[key] !== prior.hashes[key]);
  if (!equal(changed, [path])) throw Error('query reuse is not the single recorded test type correction');
  const priorTest = execFileSync('git', ['show', `${prior.head}:${path}`], { cwd: source.root });
  const currentTest = readFileSync(join(source.root, path));
  const before = " : { type: 'hold' };", after = " : { type: 'hold', x: worker.x, y: worker.y };";
  if (proof.before !== before || proof.after !== after) throw Error('query reuse literal change');
  if (sha(priorTest) !== prior.hashes[path] || sha(currentTest) !== source.hashes[path]
    || priorTest.toString().split(before).length !== 2
    || priorTest.toString().replace(before, after) !== currentTest.toString()) throw Error('query reuse test bytes');
  queryReuse = { reused: true, proof, unchangedFiles: changed.length === 1 ? Object.keys(source.hashes).length - 1 : 0,
    onlyChangedTest: path, productionAndRuntimeFilesExact: true,
    scope: 'Explicitly authorized single test native hold coordinate completion; no production or runtime entry changed. First actual P0 must still match all six entries and all three post-memories exactly.' };
}
if (expectedReport.inputSHA256 !== sha(raw)
  || !expectedReport.worldUnchanged || !expectedReport.inputUnchanged || !expectedReport.p1p2MemoryUnchanged) throw Error('pure P0 proof does not bind this source/input');
const names = ['commands', 'p0-plans', 'hits', 'samples', 'events', 'economy', 'workforce', 'milestones'];
for (const name of names) writeFileSync(join(out, name + '.jsonl'), '', { flag: 'wx' });
const emit = (name: string, row: any) => appendFileSync(join(out, name + '.jsonl'), JSON.stringify(row) + '\n');
const ferryIds = ['unit-p0-carrier-25442'];
const samples = () => copy({ tick: game.tick, ferries: memoryProvider.get('p0').naval?.ferries ?? {},
  players: game.players, winner: game.match.winner,
  hulls: game.units.filter((unit: any) => ferryIds.includes(unit.id)).map((unit: any) => ({ ...unit,
    actualDeckIds: game.units.filter((passenger: any) => passenger.deck?.shipId === unit.id).map((passenger: any) => passenger.id) })) });
let firstP0Proof: any, normalPlannerCalls = 0, commands = 0, hits = 0;
const lastHits = new Map<string, any>();
const ledger = new NativeLedger(game.units, game.buildings);
for (const unit of game.units) if (unit.hp <= 0) ledger.terminal.add(unit.id);
for (const building of game.buildings) if (building.hp <= 0) ledger.buildingTerminal.add(building.id);
const economyNow = () => copy(Object.fromEntries(Object.keys(agents).map(owner => [owner, {
  gold: game.players[owner].gold, goldSpent: game.match.stats.goldSpent[owner], neutralUnitsKilled: game.match.stats.neutralUnitsKilled[owner],
}])));
let priorEconomy = economyNow();
let priorObservation = { tick: game.tick, stage: 'restored-start' }, economySequence = 0;
const originalArmy = saved.snapshot.units.filter((unit: any) => unit.deck?.shipId === ferryIds[0] && unit.expiresTick === undefined).map((unit: any) => unit.id);
const departure = saved.memories.p0.naval.ferries[ferryIds[0]].from;
const departureLand = walkableGoal(game.map, departure.x, departure.y);
const originalBuildings = new Set(saved.snapshot.buildings.map((building: any) => building.id));
const originalResourceAmounts = Object.fromEntries(saved.snapshot.resources.map((mine: any) => [mine.id, mine.amount]));
let previousResourceAmounts = { ...originalResourceAmounts };
const freshPackets = new Set<string>(), milestones: Record<string, any> = {};
const mark = (name: string, stage: string, details: any) => {
  if (milestones[name]) return;
  const frame = `milestone-${name}-${game.tick}-${stage}.json.gz`;
  milestones[name] = { tick: game.tick, stage, frame, details };
  writeFileSync(join(out, frame), gzipSync(JSON.stringify(full())), { flag: 'wx' });
  emit('milestones', { name, ...milestones[name] });
};
function observe(stage: string) {
  for (const worker of game.units.filter((unit: any) => unit.owner === 'p0' && unit.kind === 'worker')) {
    const previous = ledger.units.get(worker.id);
    if (!previous || previous.carryingGold === worker.carryingGold) continue;
    const delta = worker.carryingGold - previous.carryingGold;
    const mineId = previous.order.type === 'mine' ? previous.order.resourceId : undefined;
    const mine = game.resources.find((node: any) => node.id === mineId);
    const mined = delta > 0 && previous.order.type === 'mine' && previous.order.phase === 'gather'
      && mine && previousResourceAmounts[mine.id] - mine.amount === delta;
    const deposited = delta < 0 && worker.hp > 0 && worker.carryingGold === 0
      && previous.order.type === 'mine' && previous.order.phase === 'return'
      && (worker.order.type === 'idle' || worker.order.type === 'mine' && worker.order.phase === 'toMine');
    const fresh = freshPackets.has(worker.id);
    const row = { tick: game.tick, stage, before: copy(previous), after: copy(worker), delta,
      resourceBefore: mine ? previousResourceAmounts[mine.id] : undefined, resourceAfter: mine?.amount,
      nativeGatherTransition: Boolean(mined), nativeDepositTransition: deposited,
      rawCargoSource: mined || fresh ? 'new-gather-observed-in-this-run' : 'original-or-other-unattributed-cargo',
      scope: 'Native carry/resource/order transition;net wallet income still requires the economy state and native upkeep rule, not raw cargo alone.' };
    emit('workforce', row);
    if (mined) { freshPackets.add(worker.id); mark('freshGather', stage, row); }
    if (deposited) { if (fresh) mark('freshDeposit', stage, row); freshPackets.delete(worker.id); }
  }
  previousResourceAmounts = Object.fromEntries(game.resources.map((mine: any) => [mine.id, mine.amount]));
  const hull = game.units.find((unit: any) => unit.id === ferryIds[0] && unit.owner === 'p0' && unit.hp > 0);
  const army = originalArmy.map((id: string) => game.units.find((unit: any) => unit.id === id));
  if (hull && !game.units.some((unit: any) => unit.deck?.shipId === hull.id && unit.expiresTick === undefined)
    && army.every((unit: any) => unit && unit.owner === 'p0' && unit.hp > 0 && !unit.deck && sameGround(game.map, unit, departureLand)))
    mark('originalArmyAshore', stage, { hull: copy(hull), army: copy(army), departureLand });
  const mission = memoryProvider.get('p0').naval?.ferries?.[ferryIds[0]];
  if (hull && mission && ['settle', 'rebase'].includes(mission.purpose)
    && game.resources.some((mine: any) => mine.id === mission.targetId && mine.amount > 0))
    mark('economicTask', stage, { hull: copy(hull), mission: copy(mission), bank: game.players.p0.gold });
  const hall = game.buildings.find((building: any) => building.owner === 'p0' && building.kind === 'townHall'
    && building.hp > 0 && !originalBuildings.has(building.id));
  if (hall) mark('newHallBody', stage, { hall: copy(hall), bank: game.players.p0.gold, spent: game.match.stats.goldSpent.p0,
    scope: 'Actual new native hall body;the same-stage economy/raw command records determine payment, not an unpaid build wish.' });
  const now = economyNow(), p0Changed = !equal(now.p0, priorEconomy.p0);
  const previousP0Workers = p0Changed ? copy([...ledger.units.values()].filter(unit => unit.owner === 'p0' && unit.kind === 'worker')) : undefined;
  const events = ledger.observe(game.tick, stage, game.units, game.buildings, lastHits);
  for (const event of events) emit('events', event);
  if (!equal(now, priorEconomy)) {
    economySequence++;
    const p0StateFile = p0Changed ? `economy-${economySequence}-${game.tick}-${stage}.json.gz` : undefined;
    if (p0StateFile) writeFileSync(join(out, p0StateFile), gzipSync(JSON.stringify(full())), { flag: 'wx' });
    emit('economy', { tick: game.tick, stage, before: priorEconomy, after: now, p0StateFile,
      ...(p0Changed ? { previousObservation: priorObservation, previousP0Workers } : {}),
      scope: 'Actual wallet/spent changes; p0 changes also preserve the complete actual post-state and preceding observed worker state for paid build/queue, carried-gold delivery and income attribution. Wallet deltas alone are not called mining.' });
  }
  priorEconomy = now;
  priorObservation = { tick: game.tick, stage };
  if (events.some(event => event.type === 'native-unit-terminal' && event.permanent || event.type === 'native-building-terminal' || event.type === 'owner-change'))
    writeFileSync(join(out, `${game.tick}-${stage}-terminal-full.json.gz`), gzipSync(JSON.stringify(full())));
}
let stopRequest: any, observationStop: any;
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  hits++; const hit = copy({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind, target: target.id,
    targetOwner: target.owner, targetKind: target.kind, damage, hpBefore, hpAfter: target.hp });
  emit('hits', hit); lastHits.set(target.id, hit);
} };
const planner = (context: any) => {
  const before = full();
  if (context.owner === 'p0') writeFileSync(join(out, `${game.tick}-before-p0.json.gz`), gzipSync(JSON.stringify(before)));
  const entries = normal(context); normalPlannerCalls++;
  if (!equal(copy(snapshotGame(game)), before.snapshot)) throw Error('normal planner changed world');
  if (context.owner === 'p0') {
    const memories = full().memories;
    emit('p0-plans', { tick: game.tick, entries, memories });
    if (!firstP0Proof) {
      firstP0Proof = { tick: game.tick, entriesExact: equal(copy(entries), expectedEntries), all3postMemoryExact: equal(memories, expectedMemories), normalPlannerCalls,
        scope: 'The one actual first normal P0 compared with the bound persisted normal/pure P0 reference after planning; no expected-memory assignment or second think.' };
      writeFileSync(join(out, 'first-p0-proof.json'), JSON.stringify(firstP0Proof, null, 2));
      if (!firstP0Proof.entriesExact || !firstP0Proof.all3postMemoryExact || normalPlannerCalls !== 1) throw Error('first normal P0 differs from bound P0 reference');
    }
  }
  return entries;
};
const startTick = game.tick, initialSample = samples();
const endTick = launch.endTick;
if (!Number.isSafeInteger(endTick) || endTick <= startTick) throw Error('explicit causal observation end required');
writeFileSync(join(out, 'prelaunch.json'), JSON.stringify({ scope: 'Focused causal normal three-AI observation from actual250185 before the candidate loading-to-return decision. Actual loaded army stays native; no direct reallocation to an economic task. Ordinary frozenv5+v7, all original world/resources/population/teams/memory. Explicit launch.endTick is a focused observation boundary, not a whole-match deadline, stagnation criterion, recovery claim, win or acceptance.', sourcePre, input, inputSHA256: sha(raw), agents, restore, frozenPre, queryReuse, diskInitial, startTick, endTick, driverSHA256: sha(readFileSync(import.meta.filename)), launchManifestPath, launchManifestSHA256: sha(readFileSync(launchManifestPath)), launch }, null, 2));
writeFileSync(join(out, 'initial.json.gz'), gzipSync(JSON.stringify(initial)));
emit('samples', initialSample);
const start = performance.now();
const runInput = { name: 'loaded-assault-economic-return', game, agents, commandPlanner: planner,
  maxTicks: endTick, thinkInterval: 15 };
runGameLoop(runInput, {
  onCommand(event: any) { commands++; emit('commands', copy({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, source: event.source, command: event.command })); observe('after-command'); },
  beforeStep() {
    if (!stopRequest && existsSync(join(out, 'observer-stop.json'))) stopRequest = {
      observedAtTick: game.tick, request: JSON.parse(readFileSync(join(out, 'observer-stop.json'), 'utf8')),
    };
    observe('before-step'); ledger.beforeStep(game.units);
  },
  onStep() {
    observe('after-step');
    if (launch.knownPrefix && game.tick === launch.knownPrefix.tick) {
      const bytes = readFileSync(launch.knownPrefix.input);
      if (sha(bytes) !== launch.knownPrefix.sha256) throw Error('known actual prefix frame changed');
      const expected = JSON.parse(gunzipSync(bytes).toString()), actual = full();
      const proof = { tick: game.tick, worldExact: equal(actual.snapshot, expected.snapshot), nextIdExact: actual.nextId === expected.nextId,
        all3memExact: equal(actual.memories, expected.memories), scope: 'Same fixedb393 baseline first15 normal steps compared with its already existing actual250200 full state;no expected assignment or replayed commands.' };
      writeFileSync(join(out, 'known-prefix-proof.json'), JSON.stringify(proof, null, 2));
      if (!proof.worldExact || !proof.nextIdExact || !proof.all3memExact) throw Error('baseline first15 differs from existing actual normal state');
    }
    if ((game.tick - startTick) % 15 === 0) emit('samples', samples());
    if (game.tick % 600 === 0) {
      const disk = diskNow();
      if (!stopRequest && disk.availableBytes < launch.minimumFreeDiskBytes) stopRequest = {
        observedAtTick: game.tick, request: { reason: 'actual-low-disk-headroom', disk, minimumFreeDiskBytes: launch.minimumFreeDiskBytes },
      };
      writeFileSync(join(out, 'progress.json'), JSON.stringify({ tick: game.tick, commands, hits, winner: game.match.winner, disk, latest: samples() }));
      console.log(JSON.stringify({ tick: game.tick, commands, hits, ferries: memoryProvider.get('p0').naval?.ferries ?? {}, winner: game.match.winner }));
      if (stopRequest && !game.match.winner) {
        observationStop = { tick: game.tick, stage: 'after-step-before-next-p0', ...stopRequest };
        runInput.maxTicks = game.tick;
      }
    }
  },
});
const final = full();
writeFileSync(join(out, 'final.json.gz'), gzipSync(JSON.stringify(final)));
const report = { sourcePre, sourcePost: audit(), frozenPre, frozenPost: frozenCheck(),
  inputUnchanged: savedHash === sha(JSON.stringify(saved)) && sha(raw) === sha(readFileSync(input!)),
  startTick, endTick: game.tick, steps: game.tick - startTick, wallMs: performance.now() - start,
  firstP0Proof, normalPlannerCalls, commands, hits, initial: initialSample, finalSample: samples(), finalFerries: memoryProvider.get('p0').naval?.ferries ?? {}, winner: game.match.winner,
  milestones, originalWorkerCarriedRaw: saved.snapshot.units.filter((unit: any) => unit.owner === 'p0' && unit.kind === 'worker').reduce((sum: number, unit: any) => sum + unit.carryingGold, 0),
  naturalComplete: !!game.match.winner, focusedWindowComplete: game.tick === endTick && !observationStop, observationStop,
  limitations: ['Explicit launch-bound causal observation from actual250185; not a complete match/fresh ordinary opening/generalization score.', 'Observed unit removal does not by itself prove killed/captured/expired; native hit/owner-change and expiresTick are retained separately.', 'Gold/spent deltas do not alone attribute mining, refunds, repair, purchases or item income.', 'All existing broken-container uncommitted recovery gaps remain.'] };
writeFileSync(join(out, 'REPORT.json'), JSON.stringify(report, null, 2));
if (!report.inputUnchanged) throw Error('input changed');
console.log(JSON.stringify(report));
