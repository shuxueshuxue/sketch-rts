from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import subprocess
import sys

D = Path(__file__).parent
case, label = sys.argv[1:]
if case not in ('baseline', 'candidate'):
    raise SystemExit('explicit baseline/candidate required')
p = D / f'PREPARED-normal-{case}-250185-256200.json'
manifest_hashes = {'baseline': 'b656c54821e4b13d7237c09552fe07e1f79a682c4d9b370810c6a6055b7fc0d8', 'candidate': '8f956fd09ddd5609d1c12abeb8ed71bebb8db498190fc55d2667816b28d34fff'}
sha = lambda b: hashlib.sha256(b).hexdigest()
if sha(p.read_bytes()) != manifest_hashes[case]:
    raise SystemExit('prepared manifest changed')
m = json.loads(p.read_text())
for name, expected in m['payloads'].items():
    if sha(Path(name).read_bytes()) != expected:
        raise SystemExit('bound payload changed: ' + name)
source = json.loads(Path(m['sourceManifest']).read_text())
if Path(m['output']).exists():
    raise SystemExit('output exists; no automatic rerun')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source['root'], text=True).strip() != source['head']:
    raise SystemExit('source HEAD changed')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=source['root'], text=True):
    raise SystemExit('source dirty')
record = D / f'{label}-resource.json'
if record.exists():
    raise SystemExit('exclusive launch label already exists')
tmp = Path('/workspace/.playtest/bootstrap-assault-economy-return-runtime-tmp-20261016')
tmp.mkdir(exist_ok=True)
cgroup = Path('/sys/fs/cgroup')
maximum = int((cgroup / 'memory.max').read_text())
current = int((cgroup / 'memory.current').read_text())
disk = os.statvfs(D)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
argv = ['node', '--max-old-space-size=768', '--import', 'tsx', str(D / 'normal-from-250185-PREPARED.mts'), str(p)]
receipt = {'classification': 'One original normal3AI finite6015tick causal observation. Not a whole match or bootstrap acceptance.', 'case': case, 'manifest': str(p), 'manifestSHA256': manifest_hashes[case], 'source': source['root'], 'head': source['head'], 'output': m['output'], 'argv': argv, 'heapMiB': 768, 'pre': {'atUTC': now(), 'memoryMax': maximum, 'memoryCurrent': current, 'rawHeadroom': maximum-current, 'requiredHeadroom': 2147483648, 'memoryEvents': (cgroup/'memory.events').read_text(), 'memoryPressure': (cgroup/'memory.pressure').read_text() if (cgroup/'memory.pressure').exists() else None, 'memoryStat': (cgroup/'memory.stat').read_text(), 'diskAvailable': disk.f_bavail*disk.f_frsize, 'requiredDisk': 268435456}, 'spawned': False}
with record.open('x') as target:
    json.dump(receipt, target, indent=2); target.write('\n')
if receipt['pre']['rawHeadroom'] < 2147483648 or receipt['pre']['diskAvailable'] < 268435456:
    print(json.dumps({'spawned': False, 'record': str(record), 'rawHeadroom': maximum-current, 'diskAvailable': receipt['pre']['diskAvailable']}), flush=True)
    raise SystemExit(75)
env = dict(os.environ)
env.pop('NODE_OPTIONS', None)
env['TMPDIR'] = str(tmp)
env['GIT_OPTIONAL_LOCKS'] = '0'
log_path = D / f'{label}.log'
with log_path.open('x') as log:
    child = subprocess.Popen(argv, cwd=source['root'], env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt.update({'spawned': True, 'actualPID': child.pid, 'startedAtUTC': now(), 'log': str(log_path)})
    record.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'spawned': True, 'actualPID': child.pid, 'record': str(record), 'rawHeadroom': maximum-current, 'output': m['output']}), flush=True)
    exit_code = child.wait()
receipt['post'] = {'atUTC': now(), 'exitCode': exit_code, 'maxChildRSSKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, 'memoryEvents': (cgroup/'memory.events').read_text(), 'memoryCurrent': int((cgroup/'memory.current').read_text())}
record.write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'actualPID': child.pid, 'exitCode': exit_code, 'record': str(record), 'finishedAtUTC': receipt['post']['atUTC']}), flush=True)
raise SystemExit(exit_code)
