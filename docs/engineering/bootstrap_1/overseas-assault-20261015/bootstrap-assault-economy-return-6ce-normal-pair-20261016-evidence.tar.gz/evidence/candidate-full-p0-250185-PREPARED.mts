import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { join } from 'node:path';

const [manifest, input, out] = process.argv.slice(2);
const source = JSON.parse(readFileSync(manifest!, 'utf8'));
mkdirSync(out!, { recursive: true });
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
function audit() {
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: source.root, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: source.root, encoding: 'utf8' });
  if (head !== source.head || status) throw Error('source head/status');
  for (const [path, hash] of Object.entries(source.hashes)) {
    if (sha(readFileSync(join(source.root, path))) !== hash) throw Error('source ' + path);
  }
  return { head, status, files: Object.keys(source.hashes).length };
}
const sourcePre = audit(), raw = readFileSync(input!);
const saved = JSON.parse(gunzipSync(raw).toString()), savedHash = sha(JSON.stringify(saved));
if (saved.snapshot.tick !== 250185) throw Error('Only the bound actual250185 input is authorized by this driver');
const snapshot = structuredClone(saved.snapshot), memories = structuredClone(saved.memories);
const worldBefore = sha(JSON.stringify(snapshot));
const [{ createAiMemoryProvider, planAiOwnerCommandEntries }, { RULES_VERSION }] = await Promise.all([
  import(join(source.root, 'src/ai/planner-context.ts')),
  import(join(source.root, 'src/shared/rules-version.ts')),
]);
if (RULES_VERSION !== 2) throw Error('rules');
const provider = createAiMemoryProvider(memories);
const agent = JSON.parse(readFileSync('/tmp/bootstrap-idle-economy-5457-20261016/agents-original.json', 'utf8')).p0;
const ferryIds = ['unit-p0-carrier-25442', 'unit-p0-transport-157929'];
const pre = {
  scope: 'One canonical full P0 public planAiOwnerCommandEntries query on the complete actual input and all three memories. No Game, restore, step, command issue, opponent think, or expected-memory backfill.',
  atUTC: new Date().toISOString(), input, inputSHA256: sha(raw), sourcePre, driverSHA256: sha(readFileSync(import.meta.filename)),
  tick: snapshot.tick, nextId: saved.nextId, teams: snapshot.teams, agent,
  all3memoryInitialExact: isDeepStrictEqual(memories, saved.memories), worldBefore,
  preFerries: structuredClone(memories.p0.naval.ferries ?? {}),
};
writeFileSync(join(out!, 'preflight.json'), JSON.stringify(pre, null, 2));
const start = performance.now(), cpu = process.cpuUsage();
const entries = planAiOwnerCommandEntries(snapshot,
  { playerId: 'p0', version: agent.version, source: 'external-agent' },
  { teams: snapshot.teams, memoryProvider: provider });
const cpuUsed = process.cpuUsage(cpu), wallMs = performance.now() - start;
writeFileSync(join(out!, 'all-entries.json'), JSON.stringify(entries, null, 2));
writeFileSync(join(out!, 'post-p0-all3mem.json.gz'), gzipSync(JSON.stringify(memories)));
const report = {
  ...pre, sourcePost: audit(), wallMs, cpuMs: (cpuUsed.user + cpuUsed.system) / 1000,
  entries: entries.length,
  actualWorldStillHasTenPermanentPassengers: snapshot.units.filter((u: any) => u.deck?.shipId === 'unit-p0-carrier-25442' && u.expiresTick === undefined).length === 10,
  originalRawP0Reference: '/tmp/bootstrap-idle-economy-5457-20261016/normal-candidate-243180-250200/p0-plans.jsonl @tick250185',
  ferryEntries: entries.filter((entry: any) => 'unitIds' in entry.command
    && entry.command.unitIds.some((id: string) => ferryIds.includes(id))),
  postFerries: memories.p0.naval.ferries ?? {},
  worldAfter: sha(JSON.stringify(snapshot)), worldUnchanged: worldBefore === sha(JSON.stringify(snapshot)),
  inputUnchanged: savedHash === sha(JSON.stringify(saved)) && sha(raw) === sha(readFileSync(input!)),
  p1p2MemoryUnchanged: ['p1', 'p2'].every(owner => isDeepStrictEqual(memories[owner], saved.memories[owner])),
};
const unloads = entries.filter((entry: any) => entry.command.type === 'unload' && entry.command.unitIds.includes('unit-p0-carrier-25442'));
const mission = memories.p0.naval.ferries['unit-p0-carrier-25442'];
const expectedUnload = { type: 'unload', unitIds: ['unit-p0-carrier-25442'], ...mission.from, avoidCombat: true };
if (unloads.length !== 1 || unloads[0].scriptId !== 'naval' || !isDeepStrictEqual(unloads[0].command, expectedUnload)
  || mission.phase !== 'return' || !report.actualWorldStillHasTenPermanentPassengers) throw Error('Actual fullP0 did not publish the original naval return unload');
writeFileSync(join(out!, 'REPORT.json'), JSON.stringify(report, null, 2));
if (!report.worldUnchanged || !report.inputUnchanged || !report.p1p2MemoryUnchanged) throw Error('input/world/other memory changed');
console.log(JSON.stringify(report));
