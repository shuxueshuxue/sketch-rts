import {createCanvas} from '@napi-rs/canvas';import{readFileSync,writeFileSync}from'node:fs';
import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';
const dir='/workspace/.playtest/bootstrap-care-native-intent-20261016',source='/tmp/sketch-rts-root-retarget-3bdb-control';
const{installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const{drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const{UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);installHeadlessCanvas();
for(const [name,tick,id,caption]of[
 ['7905',7914,'unit-p0-emberRavager-1079','Native active pursuit after arrival; own weapon52'],
 ['10425',10440,'unit-p0-footman-1072','Care move still active; no native arrival; own weapon55'],
 ['16245',16255,'unit-p0-horseArcher-4294','In-range counterfire without active walk; own weapon330'],
]as const){
 const input=dir+`/native-intent-${name}.frames/${tick}.json.gz`,{snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
 const unit=snapshot.units.find((u:any)=>u.id===id),width=1100,height=900,zoom=1.45,view={x:unit.x-380,y:unit.y-310,width,height,zoom};
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');drawWorld({ctx:ctx as any,snapshot,view,now:tick*50,
  selectedIds:new Set([id]),facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String}});
 ctx.strokeStyle='rgba(255,200,70,.8)';ctx.lineWidth=2;ctx.setLineDash([7,5]);ctx.beginPath();
 ctx.arc((unit.x-view.x)*zoom,(unit.y-view.y)*zoom,unit.attackRange*zoom,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='rgba(0,0,0,.9)';ctx.fillRect(0,0,width,85);ctx.fillStyle='white';ctx.font='21px sans-serif';
 ctx.fillText(`Actual old-source saved boundary tick${tick}; ${unit.hp}/${unit.maxHp}HP`,12,30);
 ctx.fillText(caption+'; gold circle = OWN range',12,63);
 const output=dir+`/native-intent-${name}-${tick}.png`;writeFileSync(output,canvas.toBuffer('image/png'));
 writeFileSync(output+'.json',JSON.stringify({classification:'Native drawWorld of exact original-boundary-equivalent full state. Analytic own weapon circle, fresh facing tracker; not reconstructed historical animation or new game.',source,input,view,patient:id,tick},null,2));console.log(output);
}
