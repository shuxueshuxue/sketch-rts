from pathlib import Path
import json,tarfile,hashlib
D=Path('/workspace/.playtest/bootstrap-care-native-intent-20261016')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=json.loads((D/'native-intent-summary.json').read_text())
assert all(row['verification']['allCheckpointsExact']for row in summary['cases'].values())
original=Path('/tmp/bootstrap-land-army-evidence-20261015')
sourceFrames={'7905':original/'native-care-queued-hold-7905-baseline.frames',
 '10425':original/'production-base5f-archer-boundary10425.frames',
 '16245':original/'production-base5f-secondboundary16245.frames'}
files={str(f.relative_to(D)):f for f in D.rglob('*')if f.is_file()and not f.is_symlink()and 'node_modules'not in f.parts
 and f.name not in ['bootstrap-care-native-intent-evidence.tar.gz','native-intent-index.json','native-intent-delivery.json','seal-native-intent.log']}
for name,row in summary['cases'].items():
 record=json.loads((D/f'native-intent-{name}.json').read_text())
 for check in record['checks']:
  frame=sourceFrames[name]/f'{check["tick"]}.json'
  if not frame.exists():frame=original/f'production-base5f-archer-fine-16200-16800.frames/{check["tick"]}.json'
  files[f'original-expected/{name}/{check["tick"]}.json']=frame
index={'classification':summary['classification'],'files':{name:{'bytes':f.stat().st_size,'sha256':sha(f)}for name,f in sorted(files.items())},
 'dependencies':{'priorThreeBoundaryArchiveSHA256':'62e4837811068754b14558e8441d755a062aeebb9c6daa5784bae201cf812382',
 'prior10425FirstBoundaryArchiveSHA256':'f7f97f5b3caca259dc87c5530cb573b4f3f1bc456849206127b226e139a82b34'}}
ix=D/'native-intent-index.json';ix.write_text(json.dumps(index,indent=2)+'\n');files[ix.name]=ix
archive=D/'bootstrap-care-native-intent-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name)
with tarfile.open(archive)as t:
 for name,v in index['files'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==v['sha256']
delivery={'archive':str(archive),'bytes':archive.stat().st_size,'payloads':len(files),'sha256':sha(archive),
 'result':'Read-only native actual early-arrival/pursuit audit.7905 first active chase7914;10425 no arrival before macro;16245 no active chase16247..16260 despite far help-call target, native reselects in-range target. Not absolute safety or new policy.'}
(D/'native-intent-delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps(delivery))
