// src/sdk/commands/frame.ts
import { checksumGame as checksumGame2 } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sim/checksum.ts";

// src/shared/sim.ts
import { addGold, roundGold } from "/workspace/sketch-rts-land-army-base183-control/src/shared/gold.ts";
import { unitControlsMercenaryCamp } from "/workspace/sketch-rts-land-army-base183-control/src/shared/mercenary-camp.ts";
import { boardingHoldShips, cancelCrewRendezvous, prepareCrewRendezvous } from "/workspace/sketch-rts-land-army-base183-control/src/shared/crew-rendezvous.ts";
import { prepareShipDefenseFrame, combatHull } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-defense.ts";
import { constrainGroundShipStep, drainShipCollisionImpacts, groundShipFrameEmpty, shipBodyClearAtPose } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-collisions.ts";
import { shipLaunchPose, shipLaunchPrototype } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-launch.ts";
import { landSpawnPoint, landSpawnPrototype } from "/workspace/sketch-rts-land-army-base183-control/src/shared/production-spawn.ts";
import { shipFireLaneClear } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-fire-control.ts";
import { beginShipBoarding, cancelShipBoarding, shipBoardingGoal, updateShipGangways, damageShipGangway, gangwayCrewEligible, bindGangwayCrewRules } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-gangway.ts";
import { assignPlayerColors } from "/workspace/sketch-rts-land-army-base183-control/src/shared/player-colors.ts";
import { BUILDING_WORK_REACH, buildingWorkGap, constructionWorkers } from "/workspace/sketch-rts-land-army-base183-control/src/shared/construction.ts";
import { GOLD_MINE_RULES, prepareMiningFrame, upkeepGoldIncome } from "/workspace/sketch-rts-land-army-base183-control/src/shared/mining.ts";
import { canReceiveHealing } from "/workspace/sketch-rts-land-army-base183-control/src/shared/healing.ts";
import { SPARK_FIRE, sparkIgnites } from "/workspace/sketch-rts-land-army-base183-control/src/shared/spark-fire.ts";
import { unitNeedsRepair, unitRepairHpPerGold } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-repair.ts";
import { innateMissile } from "/workspace/sketch-rts-land-army-base183-control/src/shared/attack-presentation.ts";
import { invalidateItemIndex } from "/workspace/sketch-rts-land-army-base183-control/src/shared/item-index.ts";
import { settleGroundItems } from "/workspace/sketch-rts-land-army-base183-control/src/shared/item-surfaces.ts";
import { strikePoint, strikeGap, bodyGap } from "/workspace/sketch-rts-land-army-base183-control/src/shared/combat-geometry.ts";
import { purchasePlacement } from "/workspace/sketch-rts-land-army-base183-control/src/shared/purchase.ts";
import { SHIP_WEAPONS, PREVIOUS_SHIP_TRAIN_COST, damageShipParts, initializeShipEquipment, installedWeapons, mountedWeaponPose, mountedTargetPoint, mountedFireLaneClear, rebuildShipFittings, repairShipParts, shipPartMax, shipGunCanAim, shipMounts, bestFiringHeading } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-equipment.ts";
import { ITEM_DEFS, activeItem, canEquip, dropRefusal, freeItemSlot, itemEquipped, normalizeEquipment, removeFromHands, transferRefusal, weaponRules, wieldRefusal, itemHands, unitItemMass, shipItemMass, itemsFor } from "/workspace/sketch-rts-land-army-base183-control/src/shared/equipment.ts";
import { BREACH_CHARGE, FLAME_CLOAK, GUARDIAN_SCROLL, IVORY_TOWER_HP_SHARE, LIGHTNING_ROD, STORM_STAFF, NEUTRAL_ITEM_TARGET_RANGE, NEUTRAL_STORM_TARGET_RANGE } from "/workspace/sketch-rts-land-army-base183-control/src/shared/item-rules.ts";
import { EXPERIENCE_BOOK_XP, VETERANCY_GAIN_PER_STAR, killXpReward, xpStarThresholds } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-value.ts";
import { automaticTargetAllowed, combatTargetScore, combatVictimId, shouldSwitchCombatTarget } from "/workspace/sketch-rts-land-army-base183-control/src/shared/combat-target.ts";
import { automaticShoreTargetReachable, shoreFiringStation } from "/workspace/sketch-rts-land-army-base183-control/src/shared/shore-fire.ts";
import { crewBeforeHulls, boltIntersection, inWeaponCone, weaponDamage } from "/workspace/sketch-rts-land-army-base183-control/src/shared/weapons.ts";
import { aimAt, aimingProfile, invalidateMovedAim, markAimShot, RANGED_ATTACK_RANGE_THRESHOLD } from "/workspace/sketch-rts-land-army-base183-control/src/shared/aiming.ts";
import { RANGED_ATTACK_RANGE_THRESHOLD as RANGED_ATTACK_RANGE_THRESHOLD2 } from "/workspace/sketch-rts-land-army-base183-control/src/shared/aiming.ts";
import { ABILITY_DEFS, BUILDING_DEFS, DOCK_REPAIR, SUPPORT_BUILDING_HEAL, POISON_DAMAGE, POISON_TICKS, SLOW_PACE, SLOW_TICKS, SPLASH_RADIUS, SPLASH_SHARE, MAX_UPGRADE_LEVEL, MERCENARY_UNIT_KINDS, RACE_DEFS, UNIT_DEFS, UPGRADE_DEFS, UPGRADE_KINDS, canTrainAt, canResearchAt, constructionStartHp, hasSpell, isHealingBuildingKind, maxUpgradeLevel, requiredSupplyCap, unitMover, unitRules } from "/workspace/sketch-rts-land-army-base183-control/src/shared/catalog.ts";
import { abilityCooldown, tickedAbilityCooldowns, withAbilityCooldown } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ability-cooldowns.ts";
import { isStunned, unitAbilities } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-abilities.ts";
import { matchesUnitTarget, NON_MECHANICAL_TARGETS } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-targeting.ts";
import { rollVeteranSkillChoices } from "/workspace/sketch-rts-land-army-base183-control/src/shared/veteran-skills.ts";
import { unitClassOf } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-targeting.ts";
import { veteranWeaponRange } from "/workspace/sketch-rts-land-army-base183-control/src/shared/veteran-stats.ts";
import { buildVeteranFrame, castVeteranAbility, temporaryAttackSpeedMultiplier } from "/workspace/sketch-rts-land-army-base183-control/src/shared/veteran-runtime.ts";
import { checkCommandLegality } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sim/command-validation.ts";
import { resolveUnitDamage, unitAttackDamageProfile } from "/workspace/sketch-rts-land-army-base183-control/src/shared/damage.ts";
import { attackDamageProfile, weaponDamageProfile, DAMAGE_PROFILES, ITEM_DAMAGE_PROFILES } from "/workspace/sketch-rts-land-army-base183-control/src/shared/damage-types.ts";
import { autocastEnabled, canAutocast, withAutocast } from "/workspace/sketch-rts-land-army-base183-control/src/shared/autocast.ts";
import { buildingPlacementBlocker, terrainBlocksPlacement } from "/workspace/sketch-rts-land-army-base183-control/src/shared/build-placement.ts";
import { sameGround, footprintHalf, groundUnder, isOpenGround, isWalkable, openGroundNear, openStep, setBuildingBodies, shareBuildingBodies, snapToFootprint, steerPoint, walkableGoal, walkDestination } from "/workspace/sketch-rts-land-army-base183-control/src/shared/terrain.ts";
import { BOARDING_GAP, alongside, boardingBerth, clearBoardingBerth, canReach, carries, landingSpot } from "/workspace/sketch-rts-land-army-base183-control/src/shared/naval.ts";
import { detCos, detSin } from "/workspace/sketch-rts-land-army-base183-control/src/shared/det-math.ts";
import { canBoard, boardUnit, deckPlacement, deckPointFits, moveOnDeck, restoreCargoDecks, syncDecks, settleGangwayCrossings } from "/workspace/sketch-rts-land-army-base183-control/src/shared/decks.ts";
import { bodyMass } from "/workspace/sketch-rts-land-army-base183-control/src/shared/physical-body.ts";
import { walkConnectedSurfaces, settleDeckSupport, decksCanTransfer } from "/workspace/sketch-rts-land-army-base183-control/src/shared/connected-decks.ts";
import { deckHullDamageShare, passengerDamageMultiplier } from "/workspace/sketch-rts-land-army-base183-control/src/shared/deck-combat.ts";
import { shipsIn, isShipKind, circleInPolygon, distanceToHull, localToWorld, shipPassengers, shipProfile, shareShipProfile, shipWeaponPose, worldToLocal, migrateShipSizes, SHIP_SIZE_MULTIPLIER } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-geometry.ts";
import { keepShipsOnWater, sailToward, turnShipToward } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sailing.ts";
import { followQueuedShipCourse } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-queued-course.ts";
import { shipCanTurnForAttack, shipNavigationTarget, shipPursuitGoal } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-pursuit.ts";
import { beginShipMotionFrame, retainedShipYawRate } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-motion.ts";
import { followStopDistance } from "/workspace/sketch-rts-land-army-base183-control/src/shared/follow-distance.ts";
import { beginShipPlanningFrame, tryAdmitShipPlan } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-planning-budget.ts";
import { cancelShipPlanningJob } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-planning-job.ts";
import { DEFAULT_WIND, updateAutoTrim } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-wind.ts";
import { hypot2 } from "/workspace/sketch-rts-land-army-base183-control/src/shared/hypot.ts";
import { MOVE_ORDER_ARRIVAL_RANGE } from "/workspace/sketch-rts-land-army-base183-control/src/shared/movement-rules.ts";
import { cabinGroupSelection, cabinCrewMovedThisTick, enterCabinStep, hasCabinCrewMovementFrame, isCabinProtected, isInCabin, leaveCabin, updateCabinPassengers } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-cabin.ts";
import { updateWindField } from "/workspace/sketch-rts-land-army-base183-control/src/shared/wind-field.ts";
import { shipTraffic } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-avoidance.ts";
import { headingDifference, hullPassageClear, nearestShipPose } from "/workspace/sketch-rts-land-army-base183-control/src/shared/ship-navigation.ts";
import { BRACE_DAMAGE_SHARE, MAX_SLIDE_STEP, PUSH_FRICTION, blowStrength, canTakeStance, isStaggered, lungeStrength, pushContact, shove, slide } from "/workspace/sketch-rts-land-army-base183-control/src/shared/push.ts";
import {
  createBuilding,
  createInitialBuildings,
  createInitialItems,
  createInitialMercenaryCamps,
  createInitialResources,
  createInitialUnits,
  createUnit,
  createMap,
  DEFAULT_MAP_ID,
  LADDER_MAP_ID,
  trainTimeFor,
  withUnitShape
} from "/workspace/sketch-rts-land-army-base183-control/src/shared/map.ts";
import { generateMap, TERRAIN_CELL } from "/workspace/sketch-rts-land-army-base183-control/src/shared/generated-map.ts";
import { BOOTS_SPEED, HEALING_SCROLL_HEAL, HEALING_SCROLL_RADIUS, IVORY_TOWER_REACH, RING_REGEN_PER_SECOND, buyRefusal, createShop, restockShops, shopBuyer } from "/workspace/sketch-rts-land-army-base183-control/src/shared/shop.ts";
import { poolMap } from "/workspace/sketch-rts-land-army-base183-control/src/shared/map-pool.ts";
import { perTick, seconds, SIM_TICKS_PER_SECOND } from "/workspace/sketch-rts-land-army-base183-control/src/shared/time.ts";
import { ownUnitLookup } from "/workspace/sketch-rts-land-army-base183-control/src/shared/unit-lookup.ts";
var MINE_RANGE = GOLD_MINE_RULES.entryRange;
var TOWN_HALL_DROP_RANGE = GOLD_MINE_RULES.dropRange;
var GOLD_PER_TRIP = GOLD_MINE_RULES.goldPerTrip;
var GATHER_DURATION = seconds(GOLD_MINE_RULES.gatherSeconds);
var GOLD_MINE_ENTRY_COOLDOWN = seconds(GOLD_MINE_RULES.entrySeconds);
var ITEM_PICKUP_RANGE = 72;
var SCORCH_DURATION = seconds(8);
var FLAME_CLOAK_VISUAL_DURATION = seconds(1.7);
var MOON_WELL_HEAL_EFFECT_DURATION = seconds(1.1);
var REPAIR_FULL_COST_FRACTION = 0.35;
var REPAIR_HP_PER_SECOND = UNIT_DEFS.footman.attackDamage / (UNIT_DEFS.footman.attackCooldown / seconds(1));
var REPAIR_HAMMER_EFFECT_DURATION = seconds(3);
var AUTO_ACQUIRE_RANGE = 230;
var PROJECTILE_SPEED = 360;
var NEUTRAL_LEASH_RANGE = 650;
var NEUTRAL_DAMAGE_RESPONSE_RANGE = NEUTRAL_LEASH_RANGE;
var NEUTRAL_RETURN_STOP_RANGE = 8;
var NEUTRAL_ASSIST_RANGE = 360;
var HELP_CALL_RANGE = 300;
var GUARD_LEASH_RANGE = 600;
var DEFAULT_PLAYERS = ["player", "enemy"];
var DEFAULT_TEAMS = { player: "player", enemy: "enemy", enemy2: "enemy2" };
var DEFAULT_RACES = { player: "grove", enemy: "ember", enemy2: "grove" };
var RUNTIME_ID_START = 1e3;
var nativeUnitSpawners = /* @__PURE__ */ new WeakMap();
var NAVAL_FRAME = 1;
var CARGO_FRAME = 2;
var EMPTY_VETERAN_FRAME = 4;
var EMPTY_SHIP_STARTS = /* @__PURE__ */ new Map();
var EMPTY_SHIP_DEFENSES = /* @__PURE__ */ new Map();
function navalFrameFlags(game) {
  let flags = game.observer || nativeUnitSpawners.get(game) !== game.spawnUnit ? NAVAL_FRAME : EMPTY_VETERAN_FRAME;
  for (const unit of game.units) {
    if (unit.cargo) return NAVAL_FRAME | CARGO_FRAME;
    if (unit.veteranSkill !== void 0) flags &= ~EMPTY_VETERAN_FRAME;
    if (flags & NAVAL_FRAME) continue;
    const order = unit.order;
    if (unit.deck || unit.cabin || unit.gangway || unit.sailing || isShipKind(unit.kind) || order.type === "board" || order.type === "boardShip" || order.type === "unload" || order.type === "enterCabin" || order.type === "move" && (order.rendezvousFor || order.deckPoint || order.deckShipId) || order.type === "attackMove" && (order.deckPoint || order.deckShipId)) flags |= NAVAL_FRAME;
  }
  return flags | (flags & NAVAL_FRAME || shipsIn(game.units).length ? NAVAL_FRAME : 0);
}
function createGame(mapId = DEFAULT_MAP_ID, options = {}) {
  const aiPlayers = options.aiPlayers ?? ["enemy"];
  const activePlayers = uniquePlayers(options.players ?? [...DEFAULT_PLAYERS, ...aiPlayers]);
  const teams = Object.fromEntries(activePlayers.map((owner, index) => [owner, options.teams?.[owner] ?? DEFAULT_TEAMS[owner] ?? `team-${index + 1}`]));
  const namedLayout = poolMap(mapId)?.layout;
  const layout = options.layout ?? namedLayout ?? (mapId === LADDER_MAP_ID ? { seed: "ladder" } : void 0);
  const namedShores = namedLayout?.kind === "sides" && (!options.layout || options.layout.kind === namedLayout.kind && options.layout.idea === namedLayout.idea);
  const layoutTeams = namedShores ? Object.fromEntries(activePlayers.map((id, index) => [id, `shore-${index % 2}`])) : teams;
  const generated = layout ? generateMap(layout, activePlayers, layoutTeams) : void 0;
  const shops = (generated?.sites ?? []).filter((site) => site.kind === "shop").map((site, index) => createShop(`shop-${index + 1}`, site.x, site.y));
  const game = {
    equipmentVersion: 1,
    rateUnits: "perSecond",
    tick: 0,
    match: createMatchState(activePlayers),
    map: generated ? { ...createMap(mapId), width: generated.size, height: generated.size, landmarks: generated.landmarks, ...generated.terrain ? { terrain: generated.terrain } : {} } : createMap(mapId),
    players: createPlayerStates(activePlayers, options),
    units: generated?.units ?? createInitialUnits(mapId, activePlayers, teams),
    buildings: generated?.buildings ?? createInitialBuildings(activePlayers, mapId, teams),
    resources: generated?.resources ?? createInitialResources(mapId, activePlayers, teams),
    mercenaryCamps: generated?.mercenaryCamps ?? createInitialMercenaryCamps(mapId),
    ...shops.length > 0 ? { shops } : {},
    items: generated?.items ?? createInitialItems(mapId),
    projectiles: [],
    effects: [],
    ...generated?.obstacles.length ? { obstacles: generated.obstacles } : {},
    nextId: RUNTIME_ID_START,
    activePlayers,
    teams,
    spawnUnit(owner, kind, x, y, launchPose) {
      const at = launchPose ?? walkableGoal(this.map, x, y, unitMover(kind));
      const unit = createUnit(`unit-${owner}-${kind}-${this.nextId}`, owner, kind, at.x, at.y);
      if (shipProfile(unit)) {
        const traffic = shipTraffic(unit, this.units, Infinity);
        const bodies = [...this.units, ...this.buildings, ...this.obstacles ?? []];
        const clear = (pose2) => traffic(pose2, pose2) && shipBodyClearAtPose(this.map, unit, pose2, bodies);
        const pose = launchPose ? clear(launchPose) ? launchPose : void 0 : nearestShipPose(this.map, unit, at, unit, clear);
        if (!pose) throw new Error("No clear water berth for this ship");
        Object.assign(unit, { x: pose.x, y: pose.y });
        unit.sailing = { heading: pose.heading, speed: 0, load: 0, balance: 0 };
      }
      this.nextId += 1;
      applyUnitUpgrades(this, unit);
      this.units.push(unit);
      initializeShipEquipment({ ...this, units: [unit] });
      normalizeEquipment({ ...this, units: [unit] }, true);
      refreshEquipmentMass(this, [unit]);
      return unit;
    }
  };
  game.map.wind = { ...DEFAULT_WIND };
  if (options.scenario) applyScenarioOverride(game, options.scenario);
  for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
  initializeShipEquipment(game);
  normalizeEquipment(game, true);
  refreshEquipmentMass(game);
  keepShipsOnWater(game.map, game.units);
  updateSupplyState(game);
  nativeUnitSpawners.set(game, game.spawnUnit);
  return game;
}
function uniquePlayers(players) {
  return [...new Set(players)];
}
function createMatchState(players) {
  return {
    winner: null,
    endedAtTick: null,
    stats: {
      unitsKilled: { ...zeroPlayerRecord(players), neutral: 0 },
      unitsLost: { ...zeroPlayerRecord(players), neutral: 0 },
      buildingsDestroyed: zeroPlayerRecord(players),
      nonBaseBuildingsDestroyed: zeroPlayerRecord(players),
      goldSpent: zeroPlayerRecord(players),
      mercenaryKills: zeroPlayerRecord(players),
      neutralUnitsKilled: zeroPlayerRecord(players),
      unitsKilledByNeutral: zeroPlayerRecord(players)
    }
  };
}
function createPlayerStates(activePlayers, options) {
  const players = {};
  for (const [index, owner] of [.../* @__PURE__ */ new Set([...activePlayers, "player", "enemy", "enemy2"])].entries()) {
    players[owner] = {
      race: options.races?.[owner] ?? DEFAULT_RACES[owner] ?? (index % 2 === 0 ? "grove" : "ember"),
      gold: 500,
      supplyUsed: 0,
      supplyCap: 0,
      upgrades: createEmptyUpgradeLevels()
    };
  }
  const colors = assignPlayerColors(Object.keys(players));
  for (const [owner, player] of Object.entries(players)) player.color = colors[owner];
  return players;
}
function createEmptyUpgradeLevels() {
  return Object.fromEntries(UPGRADE_KINDS.map((upgradeKind) => [upgradeKind, 0]));
}
function zeroPlayerRecord(players) {
  return Object.fromEntries([.../* @__PURE__ */ new Set([...players, "player", "enemy", "enemy2"])].map((owner) => [owner, 0]));
}
function applyScenarioOverride(game, scenario) {
  if (scenario.replaceDefaultUnits) game.units = [];
  if (scenario.replaceDefaultBuildings) game.buildings = [];
  if (scenario.replaceDefaultResources) game.resources = [];
  if (scenario.replaceDefaultMercenaryCamps) game.mercenaryCamps = [];
  if (scenario.replaceDefaultLandmarks) game.map.landmarks = [];
  const ids = /* @__PURE__ */ new Set([
    ...game.units.map((unit) => unit.id),
    ...game.buildings.map((building) => building.id),
    ...game.resources.map((resource) => resource.id),
    ...game.mercenaryCamps.map((camp) => camp.id),
    ...(game.shops ?? []).map((shop) => shop.id),
    ...game.items.map((item) => item.id),
    ...game.map.landmarks.map((landmark) => landmark.id)
  ]);
  const claimId = (id) => {
    if (ids.has(id)) throw new Error(`Duplicate scenario id ${id}`);
    ids.add(id);
  };
  for (const [owner, seed] of Object.entries(scenario.players ?? {})) {
    const player = game.players[owner];
    if (!player) throw new Error(`Unknown scenario player ${owner}`);
    if (seed.gold !== void 0) {
      if (!Number.isFinite(seed.gold) || seed.gold < 0) throw new Error(`Invalid scenario gold for ${owner}`);
      player.gold = roundGold(seed.gold);
    }
    for (const [upgradeKind, level] of Object.entries(seed.upgrades ?? {})) {
      if (!Number.isInteger(level) || level < 0) throw new Error(`Invalid scenario ${upgradeKind} level for ${owner}`);
      player.upgrades[upgradeKind] = level;
    }
  }
  for (const resource of scenario.addResources ?? []) {
    claimId(resource.id);
    game.resources.push({ ...resource });
  }
  for (const camp of scenario.addMercenaryCamps ?? []) {
    claimId(camp.id);
    game.mercenaryCamps.push({ ...camp });
  }
  for (const shop of scenario.addShops ?? []) {
    claimId(shop.id);
    (game.shops ??= []).push({ ...shop, goods: shop.goods.map((good) => ({ ...good })) });
  }
  for (const item of scenario.addItems ?? []) {
    claimId(item.id);
    game.items.push({ ...item });
  }
  for (const seed of scenario.addUnits ?? []) {
    claimId(seed.id);
    const unit = createUnit(seed.id, seed.owner, seed.kind, seed.x, seed.y);
    applyUnitUpgrades(game, unit);
    if (seed.xp !== void 0) {
      if (!Number.isFinite(seed.xp) || seed.xp < 0) throw new Error(`Invalid scenario xp for ${seed.id}`);
      unit.xp = seed.xp;
      applyXpLevel(game, unit);
    }
    if (seed.hp !== void 0) {
      if (!Number.isFinite(seed.hp) || seed.hp <= 0 || seed.hp > unit.maxHp) throw new Error(`Invalid scenario hp for ${seed.id}`);
      unit.hp = seed.hp;
    }
    if (seed.hpRatio !== void 0) {
      if (!Number.isFinite(seed.hpRatio) || seed.hpRatio <= 0 || seed.hpRatio > 1) throw new Error(`Invalid scenario hpRatio for ${seed.id}`);
      unit.hp = Math.max(1, Math.round(unit.maxHp * seed.hpRatio));
    }
    if (seed.order) unit.order = { ...seed.order };
    game.units.push(unit);
  }
  for (const seed of scenario.addBuildings ?? []) {
    claimId(seed.id);
    const building = createBuilding(seed.id, seed.owner, seed.kind, seed.x, seed.y, seed.complete ?? true);
    if (seed.maxHp !== void 0) {
      if (!Number.isFinite(seed.maxHp) || seed.maxHp <= 0) throw new Error(`Invalid scenario maxHp for ${seed.id}`);
      building.maxHp = seed.maxHp;
    }
    if (seed.hp !== void 0) {
      if (!Number.isFinite(seed.hp) || seed.hp <= 0 || seed.hp > building.maxHp) throw new Error(`Invalid scenario hp for ${seed.id}`);
      building.hp = seed.hp;
    }
    game.buildings.push(building);
  }
  for (const landmark of scenario.addLandmarks ?? []) {
    claimId(landmark.id);
    game.map.landmarks.push({ ...landmark });
  }
}
function issuePlayerCommand(game, owner, command) {
  if (!game.players[owner]) throw new Error(`Unknown player ${owner}`);
  const cabinOperands = "unitIds" in command ? [...command.unitIds] : "unitId" in command ? [command.unitId] : [];
  if ("targetId" in command && command.targetId) cabinOperands.push(command.targetId);
  if ("recipientId" in command && command.recipientId) cabinOperands.push(command.recipientId);
  if (command.type === "unloadPassenger") cabinOperands.push(command.passengerId);
  if (command.type === "transferItem") {
    const item = game.items.find((item2) => item2.id === command.itemId);
    if (item?.carrierId) cabinOperands.push(item.carrierId);
    if ("unitId" in command.destination) cabinOperands.push(command.destination.unitId);
    else if ("installerId" in command.destination && command.destination.installerId) cabinOperands.push(command.destination.installerId);
  }
  if (command.type === "enterCabin" || command.type === "leaveCabin" || game.units.some((unit) => cabinOperands.includes(unit.id) && isInCabin(unit))) {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
  }
  if (command.type === "enterCabin" || command.type === "leaveCabin") {
    const selected = unitsByIds(game, command.unitIds, owner);
    const admitted = command.type === "enterCabin" ? new Set(cabinGroupSelection(game, selected)) : void 0;
    for (const unit of selected) {
      if (command.type === "leaveCabin") leaveCabin(game, unit);
      else if (admitted.has(unit.id)) assignUnitOrder(unit, { type: "enterCabin", shipId: unit.deck.shipId });
    }
    return;
  }
  if (command.type === "boardShip") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const ships = unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship));
    if (!command.queued) cancelCrewRendezvous(game.units, new Set(ships.map((ship) => ship.id)));
    for (const ship of ships)
      assignUnitOrder(ship, { type: "boardShip", targetId: command.targetId }, command.queued);
    return;
  }
  if (command.type === "cancelBoardShip") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const ships = unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship));
    cancelCrewRendezvous(game.units, new Set(ships.map((ship) => ship.id)));
    for (const ship of ships) {
      cancelShipBoarding(ship);
      if (ship.order.type === "boardShip") assignUnitOrder(ship, { type: "idle" });
    }
    settleGangwayCrossings(game.units);
    return;
  }
  if (command.type === "learnVeteranSkill") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const unit = game.units.find((unit2) => unit2.id === command.unitId);
    unit.veteranSkill = command.skill;
    refreshVeteranFrame(game);
    return;
  }
  if ("unitIds" in command && !("queued" in command && command.queued) && ["move", "attackMove", "stop", "holdPosition", "unload", "follow", "aim", "attack"].includes(command.type)) {
    const ships = new Set(unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship)).map((ship) => ship.id));
    if (ships.size) cancelCrewRendezvous(game.units, ships);
  }
  if (command.type === "move") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      assignUnitOrder(unit, deckPointOrder(game, unit, { type: "move", x: command.x, y: command.y, ...command.avoidCombat ? { avoidCombat: true } : {} }), command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", command.x, command.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "attackMove") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      assignUnitOrder(unit, deckPointOrder(game, unit, { type: unit.attackDamage > 0 ? "attackMove" : "move", x: command.x, y: command.y }), command.queued);
    }
    addEffect(game, command.queued ? "queuedAttack" : "attack", command.x, command.y, command.queued ? 42 : 28, { owner });
    return;
  }
  if (command.type === "stop") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) assignUnitOrder(unit, { type: "idle" });
    return;
  }
  if (command.type === "aim") {
    if (!Number.isFinite(command.x) || !Number.isFinite(command.y)) throw new Error("Aim requires a finite point");
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (aimingProfile(weaponRules(game, unit))) assignUnitOrder(unit, { type: "aim", x: clamp(command.x, 0, game.map.width), y: clamp(command.y, 0, game.map.height) }, command.queued);
    }
    return;
  }
  if (command.type === "holdPosition") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit.kind === "worker") continue;
      assignUnitOrder(unit, { type: "hold", x: unit.x, y: unit.y }, command.queued);
    }
    return;
  }
  if (command.type === "attack") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit.attackDamage > 0) assignUnitOrder(unit, { type: "attack", targetId: command.targetId }, command.queued);
    }
    const target = findStrikeTarget(game, command.targetId);
    if (target) addEffect(game, command.queued ? "queuedAttackTarget" : "attackTarget", target.x, target.y, command.queued ? 44 : 32, { owner });
    return;
  }
  if (command.type === "follow") {
    const target = game.units.find((unit) => unit.id === command.targetId && !areEnemyOwners(game, unit.owner, owner));
    if (!target) throw new Error(`Unknown friendly unit ${command.targetId}`);
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit !== target) assignUnitOrder(unit, { type: "follow", targetId: target.id }, command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", target.x, target.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "mine") {
    const resource = game.resources.find((candidate) => candidate.id === command.resourceId);
    if (!resource) throw new Error(`Unknown resource ${command.resourceId}`);
    for (const unit of unitsByIds(game, command.unitIds, owner).filter((unit2) => unit2.kind === "worker")) {
      const order = !command.queued && unit.order.type === "mine" && unit.order.resourceId === resource.id ? unit.order : { type: "mine", resourceId: resource.id, phase: unit.carryingGold > 0 ? "return" : "toMine", timer: 0 };
      assignUnitOrder(unit, order, command.queued);
    }
    addEffect(game, command.queued ? "queuedMine" : "mine", resource.x, resource.y, command.queued ? 44 : 30, { owner });
    return;
  }
  if (command.type === "repair") {
    const building2 = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    if (building2.hp >= building2.maxHp) throw new Error(`${building2.kind} is already fully repaired`);
    for (const unit of unitsByIds(game, command.unitIds, owner).filter((unit2) => unit2.kind === "worker")) {
      assignUnitOrder(unit, { type: "repair", buildingId: building2.id }, command.queued);
      if (unit.order.type === "repair" && unit.order.buildingId === building2.id) unit.cooldown = 0;
    }
    addRepairHammerEffect(game, building2, command.queued);
    return;
  }
  if (command.type === "repairUnit" || command.type === "repairShip") {
    const target = game.units.find((candidate) => candidate.id === command.targetId && candidate.owner === owner && (command.type !== "repairShip" || unitMover(candidate.kind) === "sea"));
    if (!target) throw new Error(`Unknown ${owner} repair target ${command.targetId}`);
    if (!unitNeedsRepair(game, target)) throw new Error(`${target.kind} cannot be repaired or is already fully repaired`);
    for (const worker of unitsByIds(game, command.unitIds, owner).filter((unit) => unit.kind === "worker"))
      assignUnitOrder(worker, { type: "repairUnit", targetId: target.id }, command.queued);
    return;
  }
  if (command.type === "build") {
    const worker = game.units.find((unit) => unit.id === command.unitId && unit.owner === owner && unit.kind === "worker");
    if (!worker) throw new Error(`Unknown ${owner} worker ${command.unitId}`);
    if (!RACE_DEFS[playerState(game, owner).race].buildableBuildings.includes(command.buildingKind)) throw new Error(`${playerState(game, owner).race} race cannot build ${command.buildingKind}`);
    const blocker = buildingPlacementBlocker(game, command.buildingKind, command);
    if (blocker) throw new Error(`${command.buildingKind} placement is too close to ${blocker.kind}`);
    if (terrainBlocksPlacement(game.map, command.buildingKind, command)) throw new Error(`${command.buildingKind} placement is on blocked ground`);
    if (playerState(game, owner).gold < BUILDING_DEFS[command.buildingKind].cost) throw new Error("Not enough gold");
    const at = snapToFootprint(game.map, BUILDING_DEFS[command.buildingKind].radius, command);
    assignUnitOrder(worker, { type: "build", buildingKind: command.buildingKind, ...at, progressTick: game.tick, progressX: worker.x, progressY: worker.y });
    return;
  }
  if (command.type === "cancelTraining") {
    const building2 = game.buildings.find((b) => b.id === command.buildingId && b.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    const index = building2.queue.findIndex((job2) => job2.id === command.jobId);
    if (index < 0) return;
    const [job] = building2.queue.splice(index, 1);
    const refund = job.paidGold ?? UNIT_DEFS[job.unitKind].cost;
    playerState(game, owner).gold = addGold(playerState(game, owner).gold, refund);
    game.match.stats.goldSpent[owner] = Math.max(0, (game.match.stats.goldSpent[owner] ?? 0) - refund);
    updateSupplyState(game);
    return;
  }
  if (command.type === "setRally") {
    setRally(game, owner, command.buildingIds, command.x, command.y, command.target);
    return;
  }
  if (command.type === "cast") {
    const unitCount = game.units.length;
    castAbility(game, owner, command.unitId, command.ability, command.targetId, command.x, command.y, command.queued);
    if (game.units.length !== unitCount) refreshVeteranFrameAfterCommandSpawn(game);
    return;
  }
  if (command.type === "setAutocast") {
    if (!canAutocast(command.ability)) throw new Error(`${command.ability} cannot be autocast`);
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (!unitAbilities(unit).includes(command.ability)) continue;
      const autocast = withAutocast(unit, command.ability, command.enabled);
      if (autocast) unit.autocast = autocast;
      else unit.autocast = void 0;
    }
    return;
  }
  if (command.type === "setStance") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (canTakeStance(unit.kind)) unit.stance = command.stance === "pursue" ? void 0 : command.stance;
    }
    return;
  }
  if (command.type === "hire") {
    hireMercenary(game, owner, command.campId);
    refreshVeteranFrameAfterCommandSpawn(game);
    return;
  }
  if (command.type === "buy") {
    buyGood(game, owner, command.shopId, command.item, command.recipientId);
    return;
  }
  if (command.type === "board") {
    const transport = game.units.find((unit) => unit.id === command.transportId && unit.hp > 0 && carries(unit) > 0);
    if (!transport) throw new Error(`Unknown ${owner} transport ${command.transportId}`);
    const boarders = unitsByIds(game, command.unitIds, owner).filter((unit) => canBoard(transport, unit, game.units));
    const existing = game.units.find((unit) => unit.order.type === "board" && unit.order.transportId === transport.id);
    const shoreBoarder = boarders.find((unit) => !unit.deck);
    const berth = (existing?.order.type === "board" ? existing.order.berth : void 0) ?? (shoreBoarder && boardingBerth(game.map, shoreBoarder, transport));
    for (const unit of boarders) {
      assignUnitOrder(unit, { type: "board", transportId: transport.id, ...!unit.deck && berth ? { berth } : {} }, command.queued);
      const source = unit.deck && game.units.find((ship) => ship.id === unit.deck.shipId && ship.owner === owner);
      if (source && !command.queued && !source.sailing?.gangway) assignUnitOrder(source, { type: "idle" });
    }
    return;
  }
  if (command.type === "unloadPassenger") {
    const transport = unitsByIds(game, [command.transportId], owner)[0];
    if (transport) unloadCargo(game, transport, command.passengerId);
    return;
  }
  if (command.type === "unload") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (carries(unit) > 0) assignUnitOrder(unit, { type: "unload", x: command.x, y: command.y, ...command.avoidCombat ? { avoidCombat: true } : {} }, command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", command.x, command.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "research") {
    const building2 = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    queueResearch(game, building2, command.upgradeKind);
    return;
  }
  if (command.type === "buyShipEquipment") {
    const dock = game.buildings.find((building2) => building2.id === command.buildingId && building2.owner === owner && building2.kind === "shipyard" && building2.complete);
    if (!dock) throw new Error("A completed shipyard is required");
    const delivery = command.recipientId !== void 0 ? purchasePlacement(game, owner, dock, command.item, command.recipientId) : void 0;
    if (delivery && "refusal" in delivery) throw new Error(delivery.refusal);
    const def = SHIP_WEAPONS[command.item];
    spendGold(game, owner, def.cost);
    const at = walkableGoal(game.map, dock.x, dock.y + dock.radius + 36, "land");
    const item = { id: `ship-item-${game.nextId++}`, kind: command.item, x: at.x, y: at.y, durability: def.hp, cooldownRemaining: 0 };
    game.items.push(item);
    if (delivery && "placement" in delivery) deliverPurchase(game, item, delivery.placement);
    else addEffect(game, "summon", at.x, at.y, seconds(0.8));
    return;
  }
  if (command.type === "transferItem") {
    const refusal = transferRefusal(game, owner, command.itemId, command.destination);
    if (refusal) throw new Error(refusal);
    const item = game.items.find((item2) => item2.id === command.itemId);
    const originalShip = item.shipId;
    const source = game.units.find((unit) => unit.id === item.carrierId);
    if (source) removeFromHands(source, item.id);
    delete item.carrierId;
    delete item.slot;
    delete item.shipId;
    delete item.holdSlot;
    delete item.mountId;
    delete item.aim;
    if ("unitId" in command.destination) {
      item.carrierId = command.destination.unitId;
      item.slot = command.destination.slot;
    } else {
      item.shipId = command.destination.shipId;
      if ("mountId" in command.destination) {
        item.mountId = command.destination.mountId;
        item.durability ??= SHIP_WEAPONS[item.kind].hp;
      } else item.holdSlot = command.destination.slot;
    }
    invalidateItemIndex(game.items);
    for (const unit of game.units) {
      if (shipProfile(unit) && (unit.id === originalShip || unit.id === item.shipId)) rebuildShipFittings(game, unit);
      if (unit.id === source?.id || unit.id === item.carrierId || unit.id === originalShip || unit.id === item.shipId) applyDerivedUnitStats(game, unit);
    }
    refreshEquipmentMass(game);
    return;
  }
  if (command.type === "wieldItem") {
    const refusal = wieldRefusal(game, owner, command.unitId, command.itemId, command.hand);
    if (refusal) throw new Error(refusal);
    const unit = game.units.find((unit2) => unit2.id === command.unitId);
    unit.hands ??= {};
    if (command.itemId) {
      removeFromHands(unit, command.itemId);
      unit.hands[command.hand] = command.itemId;
      const item = game.items.find((item2) => item2.id === command.itemId);
      if (itemHands(item) === 2) delete unit.hands.left;
    } else delete unit.hands[command.hand];
    unit.aim = void 0;
    unit.cooldown = Math.max(unit.cooldown, seconds(0.35));
    applyDerivedUnitStats(game, unit);
    return;
  }
  if (command.type === "pickupItem") {
    pickupItem(game, owner, command.unitId, command.itemId, command.queued);
    return;
  }
  if (command.type === "dropItem") {
    dropItem(game, owner, command.unitId, command.itemId, command.x, command.y);
    return;
  }
  if (command.type === "useItem") {
    useItem(game, owner, command.unitId, command.itemId, command.targetId, command.x, command.y);
    return;
  }
  const building = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
  if (!building) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
  queueTraining(game, building, command.unitKind);
}
function stepGame(game) {
  if (game.match.winner) return;
  const entryFlags = navalFrameFlags(game);
  const emptyVeteranFrame = !!(entryFlags & EMPTY_VETERAN_FRAME);
  let navalFrame = !!(entryFlags & NAVAL_FRAME);
  if (navalFrame) {
    bindGangwayCrewRules(game.units, game);
    if (entryFlags & CARGO_FRAME) restoreCargoDecks(game.units);
    syncDecks(game.units);
    updateCabinPassengers(game);
  }
  const entryUnits = game.units, entryCount = game.units.length;
  game.tick += 1;
  updateWindField(game.map, game.tick);
  game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  refreshVeteranFrame(game, emptyVeteranFrame);
  syncBuildingBodies(game);
  updateWorldEffects(game);
  updateProjectiles(game);
  updateUnitStatusEffects(game);
  updateConstruction(game);
  updateTraining(game);
  updateResearch(game);
  updateResources(game);
  game.miningFrame = prepareMiningFrame(game);
  updateMercenaryCamps(game);
  if (game.shops) restockShops(game.shops);
  const unitsChanged = game.units !== entryUnits || game.units.length !== entryCount;
  if (!navalFrame && unitsChanged) navalFrame = !!(navalFrameFlags(game) & NAVAL_FRAME);
  if (navalFrame || unitsChanged) game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  game.unitSpatialByTeam = createTeamSpatialIndexes(game, game.units, 230, game.unitSpatialByTeam);
  game.shipReachPadding = navalFrame ? shipReachPadding(game.units) : 0;
  if (!game.buildingSpatial || game.buildingSpatialCount !== game.buildings.length) {
    game.buildingSpatial = createSpatialIndex(game.buildings, 420);
    game.buildingSpatialByTeam = createTeamSpatialIndexes(game, game.buildings, 260);
    game.buildingSpatialCount = game.buildings.length;
  }
  game.entityById = createEntityIndex(game);
  updateItems(game);
  updateMoonWellHealing(game);
  updateRegeneration(game);
  if (navalFrame) updateDockRepairs(game);
  updateTowerAttacks(game);
  const vessels = shipsIn(game.units);
  const starts = vessels.length ? new Map(vessels.map((ship) => [ship.id, { x: ship.x, y: ship.y, heading: ship.sailing.heading }])) : EMPTY_SHIP_STARTS;
  beginShipMotionFrame(game.units, game.map, game.buildingBodiesSeen ?? game.buildings, vessels);
  let defenses;
  if (navalFrame) {
    beginShipPlanningFrame(game.units, game.tick, vessels);
    updateShipGangways(game.map, game.units, game.tick, game);
    prepareCrewRendezvous(game.map, game.units);
    game.boardingHolds = boardingHoldShips(game.units);
    defenses = prepareShipDefenseFrame(game, (ship, range, visit) => forEachNearbyEnemyUnit(game, ship.owner, ship, range, visit), game.boardingHolds);
    const shoreBoarders = /* @__PURE__ */ new Map();
    for (const unit of game.units) if (unit.hp > 0 && !unit.deck && unit.order.type === "board") {
      const waiting = shoreBoarders.get(unit.order.transportId);
      if (waiting) waiting.push(unit);
      else shoreBoarders.set(unit.order.transportId, [unit]);
    }
    for (const ship of shipsIn(game.units)) {
      const collecting = ship.order.type === "idle" && shoreBoarders.get(ship.id)?.some((unit) => unit.owner === ship.owner && !alongside(unit, ship));
      const idle = game.boardingHolds.has(ship.id) || ship.order.type === "hold" || ship.order.type === "idle" && !collecting && !defenses.has(ship.id) || !!ship.sailing?.gangway && ship.sailing.gangway.phase !== "approach";
      updateAutoTrim(ship, game.map, idle ? "idle" : ship.sailing?.sail?.mode === "idle" ? "sail" : void 0);
    }
  } else {
    if (!game.boardingHolds || game.boardingHolds.size) game.boardingHolds = /* @__PURE__ */ new Set();
    defenses = EMPTY_SHIP_DEFENSES;
  }
  const updateUnitsSource = game.units, updateUnitsCount = game.units.length;
  const ferry = updateUnits(game, defenses, navalFrame, emptyVeteranFrame);
  if (!navalFrame && (ferry || (game.units !== updateUnitsSource || game.units.length !== updateUnitsCount) && navalFrameFlags(game) & NAVAL_FRAME)) navalFrame = true;
  if (navalFrame) updateMountedWeapons(game, starts, defenses);
  if (ferry) ferryUnits(game, ferry, starts);
  if (navalFrame) {
    for (const ship of shipsIn(game.units)) {
      const start = starts.get(ship.id);
      if (start && ship.sailing && start.x === ship.x && start.y === ship.y) ship.sailing.speed = 0;
    }
    updateShipGangways(game.map, game.units, game.tick, game);
    settleGangwayCrossings(game.units);
    syncDecks(game.units);
    settleDeckSupport(game.units, game.map);
    updateCabinPassengers(game);
  }
  slideUnits(game);
  separateUnits(game, navalFrame);
  if (navalFrame) syncDecks(game.units);
  if (game.map.terrain) keepUnitsOutOfBuildings(game);
  for (const impact of drainShipCollisionImpacts(game.units)) {
    const other = impact.other;
    const source = other && !isObstacle(other) ? other : impact.ship;
    if (impact.ship.hp > 0 && impact.shipDamage > 0) {
      const taken = applyDamage(game, source, impact.ship, impact.shipDamage, 0, impact.point, 0, DAMAGE_PROFILES.EXPLOSION);
      if (taken !== void 0 && taken > 0) addHitEffect(game, impact.ship, taken);
    }
    if (other && other.hp > 0 && impact.otherDamage > 0) {
      const taken = applyDamage(game, impact.ship, other, impact.otherDamage, 0, impact.point, 0, DAMAGE_PROFILES.EXPLOSION);
      if (taken !== void 0 && taken > 0) addHitEffect(game, other, taken);
    }
  }
  if (navalFrame) for (const ship of shipsIn(game.units)) {
    const start = starts.get(ship.id);
    if (!ship.sailing) continue;
    ship.sailing.velocityX = start ? (ship.x - start.x) * SIM_TICKS_PER_SECOND : 0;
    ship.sailing.velocityY = start ? (ship.y - start.y) * SIM_TICKS_PER_SECOND : 0;
    ship.sailing.yawRate = retainedShipYawRate(ship, start?.heading);
  }
  for (const unit of game.units) if (unit.aim) invalidateMovedAim(unit, weaponRules(game, unit));
  removeExpiredUnits(game);
  removeDead(game);
  if (settleGroundItems(game.items, game.units, game.map)) refreshEquipmentMass(game);
  if (navalFrame) updateShipOwnership(game);
  syncBuildingBodies(game);
  game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  refreshVeteranFrame(game, emptyVeteranFrame);
  updateVictory(game);
}
function syncBuildingBodies(game) {
  const seen = game.buildingBodiesSeen;
  const obstacles = game.obstacles ?? [];
  const count = game.buildings.length;
  if (seen && seen.length === count + obstacles.length && game.buildings.every((building, index) => building === seen[index]) && obstacles.every((obstacle, index) => obstacle === seen[count + index])) return;
  game.buildingBodiesSeen = [...game.buildings, ...obstacles];
  setBuildingBodies(game.map, game.buildingBodiesSeen);
}
function copyUnitOrder(order) {
  const copy = { ...order };
  if ((copy.type === "move" || copy.type === "attackMove") && copy.deckPoint) copy.deckPoint = { ...copy.deckPoint };
  if (copy.type === "board") {
    if (copy.deckPoint) copy.deckPoint = { ...copy.deckPoint };
    if (copy.rendezvous) copy.rendezvous = { ...copy.rendezvous };
    if (copy.berth) copy.berth = { ...copy.berth };
  }
  return copy;
}
function snapshotGame(game) {
  const snapshot = {
    equipmentVersion: 1,
    rateUnits: "perSecond",
    tick: game.tick,
    match: {
      winner: game.match.winner,
      endedAtTick: game.match.endedAtTick,
      stats: {
        unitsKilled: { ...game.match.stats.unitsKilled },
        unitsLost: { ...game.match.stats.unitsLost },
        buildingsDestroyed: { ...game.match.stats.buildingsDestroyed },
        nonBaseBuildingsDestroyed: { ...game.match.stats.nonBaseBuildingsDestroyed },
        goldSpent: { ...game.match.stats.goldSpent },
        mercenaryKills: { ...game.match.stats.mercenaryKills },
        neutralUnitsKilled: { ...game.match.stats.neutralUnitsKilled },
        unitsKilledByNeutral: { ...game.match.stats.unitsKilledByNeutral }
      }
    },
    map: { ...game.map, ...game.map.wind ? { wind: { ...game.map.wind } } : {} },
    teams: { ...game.teams },
    players: Object.fromEntries(Object.entries(game.players).map(([owner, player]) => [owner, { ...player, upgrades: { ...player.upgrades } }])),
    units: game.units.map((unit) => {
      const copy = { ...unit };
      copy.order = copyUnitOrder(unit.order);
      copy.orderQueue = unit.orderQueue?.map(copyUnitOrder) ?? [];
      if (unit.aim) copy.aim = { ...unit.aim };
      if (unit.deck) copy.deck = { ...unit.deck };
      if (unit.cabin) copy.cabin = { ...unit.cabin };
      if (unit.hands) copy.hands = { ...unit.hands };
      if (unit.shipParts) copy.shipParts = { ...unit.shipParts };
      if (unit.fittings) copy.fittings = unit.fittings.map((fitting) => ({ ...fitting, accepts: [...fitting.accepts] }));
      if (unit.sailing) {
        copy.sailing = { ...unit.sailing };
        if (unit.sailing.sail) copy.sailing.sail = { ...unit.sailing.sail };
        if (unit.sailing.pursuit) copy.sailing.pursuit = { ...unit.sailing.pursuit };
        if (unit.sailing.defense) copy.sailing.defense = { ...unit.sailing.defense };
        if (unit.sailing.gangway) copy.sailing.gangway = { ...unit.sailing.gangway, sourceAnchor: { ...unit.sailing.gangway.sourceAnchor }, targetAnchor: { ...unit.sailing.gangway.targetAnchor } };
        if (unit.sailing.route) copy.sailing.route = { ...unit.sailing.route, end: { ...unit.sailing.route.end }, points: unit.sailing.route.points.map((point) => ({ ...point, ...point.pivot ? { pivot: { ...point.pivot } } : {} })) };
      }
      if (unit.gangway) copy.gangway = { ...unit.gangway };
      if (unit.abilityCooldowns) copy.abilityCooldowns = { ...unit.abilityCooldowns };
      if (unit.autocast) copy.autocast = { ...unit.autocast };
      if (unit.veteranSkillChoices) copy.veteranSkillChoices = [...unit.veteranSkillChoices];
      copy.effects = unit.effects.map((effect) => ({ ...effect, ...effect.damageFilter ? {
        damageFilter: Object.fromEntries(Object.entries(effect.damageFilter).map(([key, value]) => [key, Array.isArray(value) ? [...value] : value]))
      } : {} }));
      return copy;
    }),
    buildings: game.buildings.map((building) => {
      const { rallyTarget, ...rest } = building;
      const copy = rest;
      if (rallyTarget) copy.rallyTarget = { ...rallyTarget };
      copy.queue = building.queue.map((job) => ({ ...job }));
      copy.researchQueue = building.researchQueue.map((job) => ({ ...job }));
      return copy;
    }),
    resources: game.resources.map((resource) => ({ ...resource })),
    mercenaryCamps: game.mercenaryCamps.map((camp) => ({ ...camp })),
    ...game.shops ? { shops: game.shops.map((shop) => ({ ...shop, goods: shop.goods.map((good) => ({ ...good })) })) } : {},
    items: game.items.map((item) => ({ ...item, ...item.aim ? { aim: { ...item.aim } } : {}, ...item.deck ? { deck: { ...item.deck } } : {} })),
    projectiles: game.projectiles.map((projectile) => ({
      ...projectile,
      ...projectile.damageProfile ? { damageProfile: { ...projectile.damageProfile } } : {},
      ...projectile.weapon ? { weapon: { ...projectile.weapon, ...projectile.weapon.damageProfile ? { damageProfile: { ...projectile.weapon.damageProfile } } : {} } } : {}
    })),
    effects: game.effects.map((effect) => ({ ...effect, ...effect.damageProfile ? { damageProfile: { ...effect.damageProfile } } : {} })),
    ...game.corpses ? { corpses: game.corpses.map((corpse) => ({ ...corpse, ...corpse.deck ? { deck: { ...corpse.deck } } : {} })) } : {},
    // A variant's rules are replaced whole when they change, never edited, so the snapshot may share them.
    ...game.variants ? { variants: { ...game.variants } } : {},
    ...game.obstacles ? { obstacles: game.obstacles.map((obstacle) => ({ ...obstacle, along: { ...obstacle.along } })) } : {}
  };
  bindGangwayCrewRules(snapshot.units, snapshot);
  shareBuildingBodies(game.map, snapshot.map);
  return snapshot;
}
function restoreSnapshotIntoGame(game, snapshot, nextId) {
  game.equipmentVersion = 1;
  game.rateUnits = "perSecond";
  game.tick = snapshot.tick;
  game.match = cloneSnapshotValue(snapshot.match);
  game.map = cloneSnapshotValue(snapshot.map);
  game.teams = snapshot.teams ? definedTeams(snapshot.teams) : { ...game.teams };
  game.players = cloneSnapshotValue(snapshot.players);
  const colors = assignPlayerColors(Object.keys(game.players), Object.fromEntries(Object.entries(game.players).map(([owner, player]) => [owner, player.color])));
  for (const [owner, player] of Object.entries(game.players)) player.color = colors[owner];
  if (snapshot.teams) game.activePlayers = Object.keys(snapshot.teams).filter((owner) => snapshot.players[owner] !== void 0);
  game.units = cloneSnapshotValue(snapshot.units).map(withUnitShape);
  game.buildings = cloneSnapshotValue(snapshot.buildings);
  game.resources = cloneSnapshotValue(snapshot.resources);
  game.mercenaryCamps = cloneSnapshotValue(snapshot.mercenaryCamps);
  if (snapshot.shops) game.shops = cloneSnapshotValue(snapshot.shops);
  else delete game.shops;
  game.items = cloneSnapshotValue(snapshot.items);
  game.projectiles = cloneSnapshotValue(snapshot.projectiles);
  game.effects = cloneSnapshotValue(snapshot.effects);
  if (snapshot.corpses) game.corpses = cloneSnapshotValue(snapshot.corpses);
  else delete game.corpses;
  if (snapshot.variants) game.variants = cloneSnapshotValue(snapshot.variants);
  else delete game.variants;
  if (snapshot.obstacles) game.obstacles = cloneSnapshotValue(snapshot.obstacles);
  else delete game.obstacles;
  if (!snapshot.rateUnits) migrateSnapshotRates(game);
  for (const building of game.buildings) for (const job of building.queue) if (job.paidGold === void 0) job.paidGold = isShipKind(job.unitKind) ? PREVIOUS_SHIP_TRAIN_COST[job.unitKind] : UNIT_DEFS[job.unitKind].cost;
  migrateShipSizes(game.units);
  restoreCargoDecks(game.units);
  for (const ship of shipsIn(game.units)) if (ship.shipParts) ship.shipParts.cabin ??= shipPartMax(ship).cabin;
  const removedArmor = game.items.some((item) => item.kind === "legGuards" || item.slot === "legs");
  if (removedArmor) {
    for (const item of game.items) {
      if (item.kind === "legGuards") {
        item.kind = "leatherArmor";
        delete item.slot;
      } else if (item.slot === "legs") delete item.slot;
    }
    normalizeEquipment(game);
    refreshEquipmentMass(game);
  }
  if (game.shops) for (const shop of game.shops) shop.goods = shop.goods.filter((good) => good.kind !== "legGuards");
  if (snapshot.equipmentVersion !== 1) {
    initializeShipEquipment(game);
    normalizeEquipment(game, true);
    refreshEquipmentMass(game);
  }
  game.nextId = nextId;
  normalizeEquipment(game);
  keepShipsOnWater(game.map, game.units);
  syncDecks(game.units);
  invalidateGameRuntimeCaches(game);
  refreshVeteranFrame(game);
  bindGangwayCrewRules(game.units, game);
}
function migrateSnapshotRates(game) {
  const migrate = (unit) => {
    unit.speed *= 20;
    if (unit.pushX !== void 0) unit.pushX *= 20;
    if (unit.pushY !== void 0) unit.pushY *= 20;
    unit.cargo?.forEach(migrate);
  };
  game.units.forEach(migrate);
  for (const rules of Object.values(game.variants ?? {})) {
    rules.speed *= 20;
    if (rules.aimSpeed !== void 0) rules.aimSpeed *= 20;
  }
}
function invalidateGameRuntimeCaches(game) {
  invalidateSeparationFrame(game);
  delete game.veteranFrame;
  delete game.veteranAutocastFrame;
  delete game.boardingHolds;
  delete game.unitSpatial;
  delete game.unitSpatialByTeam;
  delete game.shipReachPadding;
  delete game.buildingSpatial;
  delete game.buildingSpatialByTeam;
  delete game.buildingSpatialCount;
  delete game.buildingBodiesSeen;
  delete game.entityById;
}
function cloneSnapshotValue(value) {
  return JSON.parse(JSON.stringify(value));
}
function definedTeams(teams) {
  return Object.fromEntries(Object.entries(teams).filter((entry) => typeof entry[1] === "string"));
}
function updateConstruction(game) {
  for (const building of game.buildings) {
    if (building.complete) continue;
    const builders = constructionWorkers(game, building);
    if (builders.length === 0) continue;
    for (const builder of builders) emitWorkerWork(game, builder, building);
    const before = building.buildProgress;
    building.buildProgress = Math.min(building.buildTime, building.buildProgress + builders.length);
    const gained = (building.buildProgress - before) / Math.max(1, building.buildTime) * (building.maxHp - constructionStartHp(building.maxHp));
    building.hp = Math.min(building.maxHp, building.hp + gained);
    if (building.buildProgress >= building.buildTime) {
      applyDerivedBuildingStats(game, building);
      building.complete = true;
      for (const builder of builders) builder.order = { type: "idle" };
      updateSupplyState(game);
    }
  }
}
function updateTraining(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.queue.length === 0) continue;
    const job = building.queue[0];
    if (!job) continue;
    job.remaining = Math.max(0, job.remaining - 1);
    if (job.remaining > 0) continue;
    const sea = unitMover(job.unitKind) === "sea";
    const launch = sea ? shipLaunchPose(game, building, shipLaunchPrototype(building, job.unitKind)) : void 0;
    const from = sea ? launch : landSpawnPoint(game, building, landSpawnPrototype(building, job.unitKind));
    if (!from) continue;
    const unit = game.spawnUnit(building.owner, job.unitKind, from.x, from.y, launch);
    building.queue.shift();
    unit.order = rallyOrderForUnit(game, building, unit);
  }
}
function updateResearch(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.researchQueue.length === 0) continue;
    const job = building.researchQueue[0];
    if (!job) continue;
    job.remaining -= 1;
    if (job.remaining > 0) continue;
    building.researchQueue.shift();
    completeResearch(game, building.owner, job.upgradeKind, job.targetLevel);
  }
}
function updateTowerAttacks(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.attackDamage <= 0) continue;
    building.cooldown = Math.max(0, building.cooldown - 1);
    if (building.cooldown > 0) continue;
    const target = nearestEnemyTargetFromPoint(game, building.owner, building, building.attackRange);
    if (!target) continue;
    applyWeaponAttack(game, building, target, building.attackDamage, building.attackRange);
    building.cooldown = building.attackCooldown;
  }
}
function updateMoonWellHealing(game) {
  for (const building of game.buildings) {
    if (!building.complete || !isHealingBuildingKind(building.kind)) continue;
    building.cooldown = Math.max(0, building.cooldown - 1);
    if (building.cooldown > 0) continue;
    const target = mostWoundedSoldierNear(game, building);
    if (!target) continue;
    target.hp = Math.min(target.maxHp, target.hp + SUPPORT_BUILDING_HEAL);
    building.cooldown = building.attackCooldown;
    addEffect(game, "heal", target.x, target.y, MOON_WELL_HEAL_EFFECT_DURATION, { fromX: building.x, fromY: building.y, toX: target.x, toY: target.y });
  }
}
function mostWoundedSoldierNear(game, building) {
  let target;
  let targetScore = 0;
  forEachNearbyUnit(game, building, building.attackRange, (unit) => {
    if (!canReceiveHealing(unit, game) || unit.owner !== building.owner || unit.kind === "worker" || unit.hp >= unit.maxHp || distance(unit, building) > building.attackRange) return;
    const score = (unit.maxHp - unit.hp) * 2 + (1 - unit.hp / Math.max(1, unit.maxHp)) * 80;
    if (score <= targetScore) return;
    target = unit;
    targetScore = score;
  });
  return target;
}
function updateDockRepairs(game) {
  if (game.tick % seconds(1)) return;
  for (const ship of game.units) {
    if (!shipProfile(ship) || !unitNeedsRepair(game, ship) || !isPlayerId(ship.owner) || ship.order.type === "attack" || ship.order.type === "attackMove") continue;
    const dock = game.buildings.find((building) => building.owner === ship.owner && building.kind === "shipyard" && building.complete && distance(ship, building) < DOCK_REPAIR.range);
    if (!dock || playerState(game, ship.owner).gold < DOCK_REPAIR.goldPerSecond) continue;
    spendGold(game, ship.owner, DOCK_REPAIR.goldPerSecond);
    repairShipParts(game, ship, DOCK_REPAIR.hpPerSecond);
  }
}
function updateRegeneration(game) {
  for (const unit of game.units) {
    if (unit.hp <= 0 || unit.hp >= unit.maxHp) continue;
    const regenPerSecond = unitRegenPerSecond(game, unit);
    if (regenPerSecond <= 0) continue;
    unit.hp = Math.min(unit.maxHp, unit.hp + regenPerSecond / 20);
  }
}
function unitRegenPerSecond(game, unit) {
  const veterans = "nextId" in game ? game.veteranFrame : buildVeteranFrame(game);
  const rules = unitRules(game, unit);
  const medicalClasses = NON_MECHANICAL_TARGETS.unitClasses;
  return !medicalClasses || medicalClasses.includes(rules.unitClass ?? UNIT_DEFS[unit.kind].unitClass) ? (rules.regenPerSecond ?? 0) + qualifiedLeadershipRegenPerSecond(game, unit) + (veterans?.get(unit.id)?.regenPerSecond ?? 0) : 0;
}
function veteranNearby(game) {
  return (x, y, radius) => {
    const units = [];
    forEachNearbyUnit(game, { x, y }, radius, (unit) => units.push(unit));
    return units;
  };
}
function refreshVeteranFrameAfterCommandSpawn(game) {
  game.unitSpatial = createSpatialIndex(game.units, 320);
  refreshVeteranFrame(game);
}
function refreshVeteranFrame(game, empty = false) {
  const previous = game.veteranFrame;
  game.veteranFrame = empty ? void 0 : buildVeteranFrame(game, veteranNearby(game));
  if (!previous?.size && !game.veteranFrame?.size) return;
  for (const unit of game.units) {
    if (unit.hp > 0 && (previous?.has(unit.id) || game.veteranFrame?.has(unit.id))) {
      const hp = unit.hp;
      applyDerivedUnitStats(game, unit);
      unit.hp = Math.min(hp, unit.maxHp);
    }
  }
}
function veteranAimSpeed(game, unit) {
  return game.veteranFrame?.get(unit.id)?.aimSpeedMultiplier ?? 1;
}
function applyVeteranAbility(game, caster, ability, automatic) {
  return castVeteranAbility(
    game,
    caster,
    ability.skill,
    automatic,
    (type, x, y, duration, options) => addEffect(game, type, x, y, duration, { ...options, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, toX: x, toY: y }),
    veteranNearby(game),
    game.veteranAutocastFrame
  );
}
function qualifiedLeadershipRegenPerSecond(game, unit) {
  if (!isPlayerId(unit.owner) || unit.level <= 0) return 0;
  const upgrade = UPGRADE_DEFS.leadership;
  const ownerState = game.players[unit.owner];
  if (!ownerState) throw new Error(`Missing player state for ${unit.owner}`);
  const level = ownerState.upgrades.leadership ?? 0;
  const levelDef = upgrade.levels[level - 1];
  return levelDef?.veteranRegenByStars?.[Math.min(MAX_UPGRADE_LEVEL, unit.level) - 1] ?? 0;
}
function updateMercenaryCamps(game) {
  for (const camp of game.mercenaryCamps) {
    camp.cooldownRemaining = Math.max(0, camp.cooldownRemaining - 1);
  }
}
function aimMountedWeapon(game, ship, item, point, pose = mountedWeaponPose(ship, item)) {
  const def = SHIP_WEAPONS[item.kind];
  const mount = shipMounts(ship).find((mount2) => mount2.id === item.mountId);
  const proxy = { ...ship, x: pose.pivot.x, y: pose.pivot.y, deck: { shipId: ship.id, x: mount.x, y: mount.y }, aim: item.aim };
  const { naval: _hull, ...weaponBase } = unitRules(game, ship);
  const ready = aimAt(proxy, { ...weaponBase, attackDamage: def.damage, attackRange: def.range, aimSpeed: def.aimSpeed, weapon: def.weapon }, point, game.tick, veteranAimSpeed(game, ship));
  if (proxy.aim) item.aim = proxy.aim;
  else delete item.aim;
  if (proxy.facing !== void 0) item.facing = proxy.facing;
  return ready ? proxy : void 0;
}
function friendlyFireBlockers(game, ship) {
  return shipsIn(game.units).filter((other) => other.id !== ship.id && other.hp > 0 && !areEnemyOwners(game, ship.owner, other.owner));
}
function mountedShotClear(ship, blockers) {
  if (!blockers.length) return void 0;
  const poses = /* @__PURE__ */ new Map();
  return (item, point, heading) => {
    let aimed = poses.get(heading);
    if (!aimed) {
      aimed = { ...ship, sailing: { ...ship.sailing, heading } };
      shareShipProfile(ship, aimed);
      poses.set(heading, aimed);
    }
    return mountedFireLaneClear(aimed, item, point, blockers);
  };
}
function updateMountedWeapons(game, starts, defenses) {
  const crossing = game.boardingHolds;
  for (const ship of shipsIn(game.units)) {
    if (ship.hp <= 0 || isStaggered(ship) || isStunned(ship) || !shipProfile(ship) || "avoidCombat" in ship.order && ship.order.avoidCombat) continue;
    const order = ship.order;
    const blockers = friendlyFireBlockers(game, ship);
    const weapons = installedWeapons(game, ship), mounts = shipMounts(ship);
    const acquisitionRange = weapons.reduce((reach, item) => {
      if ((item.durability ?? 1) <= 0) return reach;
      const mount = mounts.find((mount2) => mount2.id === item.mountId);
      const def = SHIP_WEAPONS[item.kind];
      return mount ? Math.max(reach, veteranWeaponRange(ship, def.range) + Math.hypot(mount.x, mount.y)) : reach;
    }, ship.attackRange);
    const intrinsic = unitRules(game, ship).intrinsicAttack;
    const ordered = (order.type === "attack" || order.type === "attackMove") && order.targetId ? findStrikeTarget(game, order.targetId) : void 0;
    const explicit = order.type === "attack" && order.leashX === void 0;
    const requested = defenses.get(ship.id)?.target ?? (ordered && (explicit || isObstacle(ordered) || automaticTargetAllowed(game.units, ship.owner, ordered)) ? ordered : void 0);
    let facingPoint = order.type === "aim" ? order : requested ?? (["attackMove", "idle", "hold"].includes(order.type) ? nearestEnemyTarget(game, ship, acquisitionRange) : void 0);
    if (facingPoint && "owner" in facingPoint && !isObstacle(facingPoint)) facingPoint = navalCombatTarget(game, ship, facingPoint);
    const orientHull = ["idle", "hold", "aim"].includes(order.type) || (order.type === "attack" || order.type === "attackMove") && shipCanTurnForAttack(ship);
    if (!crossing.has(ship.id) && facingPoint && (shipCanTurnForAttack(ship) || strikeGap(ship, facingPoint) <= acquisitionRange) && orientHull) {
      turnShipToward(ship, bestFiringHeading(game, ship, facingPoint, 0, mountedShotClear(ship, blockers)), game.map, game.units, Math.abs(headingDifference(starts.get(ship.id).heading, ship.sailing.heading)));
    }
    for (const item of weapons) {
      if ((item.durability ?? 1) <= 0 || item.cooldownRemaining > 0 || item.mountId === "bow" && !intrinsic && ship.cooldown > 0) continue;
      const def = SHIP_WEAPONS[item.kind], pose = mountedWeaponPose(ship, item);
      const range = veteranWeaponRange(ship, def.range);
      const canShoot = (candidate) => {
        const point2 = mountedTargetPoint(game, ship, item, candidate, pose), gap = distance(pose.pivot, point2);
        return shipGunCanAim(ship, item, point2) && gap <= range && gap >= (def.weapon.minRange ?? 0) && (!blockers.length || mountedFireLaneClear(ship, item, point2, blockers));
      };
      const preferred = requested && !isObstacle(requested) ? navalCombatTarget(game, ship, requested) : requested;
      const target = preferred && areEnemyOwners(game, ship.owner, preferred.owner) && canShoot(preferred) ? preferred : nearestEnemyTargetFromPoint(game, ship.owner, pose.pivot, range, ship, (candidate) => canShoot(candidate) && (!["move", "unload", "follow"].includes(order.type) || candidate.attackDamage > 0));
      const aimTarget = order.type === "aim" && !target ? order : target;
      const point = target ? mountedTargetPoint(game, ship, item, target, pose) : aimTarget && strikePoint(pose.pivot, aimTarget);
      if (!point || !shipGunCanAim(ship, item, point) || distance(pose.pivot, point) > range || def.weapon.minRange && distance(pose.pivot, point) < def.weapon.minRange) continue;
      const proxy = aimMountedWeapon(game, ship, item, point, pose);
      if (!proxy || !target) continue;
      const launchPose = mountedWeaponPose(ship, item);
      if (blockers.length && !shipFireLaneClear(launchPose.muzzle, point, def.weapon, blockers)) continue;
      fireWeapon(game, ship, target, Math.round(def.damage * (nonStarUnitStats(game, ship).attackDamage / Math.max(1, weaponRules(game, ship).attackDamage)) * outgoingDamageMultiplier(game, ship)), def.weapon, range, {}, target.id, { item, pose: launchPose, aimPoint: point });
      markAimShot(proxy);
      item.cooldownRemaining = attackCooldownOf(game, ship, def.cooldown);
      if (item.mountId === "bow" && !intrinsic) ship.cooldown = item.cooldownRemaining;
    }
  }
}
function refreshEquipmentMass(game, units = game.units) {
  for (const unit of units) {
    unit.gearMass = unitItemMass(game, unit);
    if (shipProfile(unit)) unit.holdMass = shipItemMass(game, unit);
  }
}
function updateItems(game) {
  let ringed;
  const unitsById = game.entityById;
  for (const item of game.items) {
    if (item.cooldownRemaining > 0) item.cooldownRemaining = Math.max(0, item.cooldownRemaining - 1);
    const entity = item.carrierId ? unitsById.get(item.carrierId) : void 0;
    const carrier = entity && isUnit(entity) ? entity : void 0;
    if (item.shipId) {
      const ship = unitsById.get(item.shipId);
      if (ship) {
        item.x = ship.x;
        item.y = ship.y;
      }
      continue;
    }
    if (!carrier) continue;
    item.x = carrier.x;
    item.y = carrier.y;
    if (!isInCabin(carrier) && item.kind === "flameCloak" && itemEquipped(game, carrier, item)) applyFlameCloak(game, carrier, item);
    if (canReceiveHealing(carrier, game) && item.kind === "regenRing" && itemEquipped(game, carrier, item) && carrier.hp < carrier.maxHp && !ringed?.has(carrier.id)) {
      carrier.hp = Math.min(carrier.maxHp, carrier.hp + perTick(RING_REGEN_PER_SECOND));
      (ringed ??= /* @__PURE__ */ new Set()).add(carrier.id);
    }
    if (!isInCabin(carrier) && carrier.owner === "neutral" && itemEquipped(game, carrier, item)) activateNeutralItem(game, carrier, item);
  }
}
function updateResources(game) {
  for (const resource of game.resources) {
    resource.harvestCooldownRemaining = Math.max(0, (resource.harvestCooldownRemaining ?? 0) - 1);
  }
}
function updateUnits(game, defenses, navalFrame, emptyVeteranFrame) {
  game.veteranAutocastFrame = emptyVeteranFrame ? void 0 : {};
  const autocastFrame = game.tick % AUTOCAST_EVERY_TICKS === 0;
  const cabinMovementFrame = hasCabinCrewMovementFrame(game);
  let ferry;
  const vessels = navalFrame ? shipsIn(game.units) : void 0;
  const ordered = vessels?.length ? [...vessels, ...game.units.filter((unit) => !isShipKind(unit.kind))] : game.units;
  const count = ordered.length;
  const sourceCount = game.units.length;
  for (let i = 0; i < count; i += 1) {
    const unit = ordered[i];
    const navalUnitFrame = navalFrame || game.units.length !== sourceCount;
    if (unit.sailing?.pursuit && !["attack", "attackMove", "follow"].includes(unit.order.type) && !defenses.has(unit.id)) delete unit.sailing.pursuit;
    if (unit.aim) invalidateMovedAim(unit, weaponRules(game, unit));
    unit.cooldown = Math.max(0, unit.cooldown - 1);
    if (unit.abilityCooldowns) {
      const left = tickedAbilityCooldowns(unit.abilityCooldowns);
      if (left) unit.abilityCooldowns = left;
      else unit.abilityCooldowns = void 0;
    }
    if (navalUnitFrame && isInCabin(unit) || (navalUnitFrame || cabinMovementFrame) && cabinCrewMovedThisTick(game, unit)) continue;
    if (unit.order.type === "enterCabin") {
      if (!isStaggered(unit) && !isStunned(unit)) enterCabinStep(game, unit, statusPace(unit), (other) => isStaggered(other) || isStunned(other) ? 0 : statusPace(other));
      continue;
    }
    if (unit.order.type !== "charge") {
      if (unit.pushX !== void 0 && isStaggered(unit) || unit.effects.length !== 0 && isStunned(unit)) continue;
      if (unit.owner !== "neutral" && unit.order.type === "move") {
        advanceMoveOrder(game, unit, unit.order, navalUnitFrame);
        continue;
      }
      activateQueuedOrder(game, unit);
      if (updateNeutralLeash(game, unit)) continue;
      if (navalUnitFrame && autoRepairDeckShip(game, unit)) continue;
      if (autocastFrame) autocastStep(game, unit);
    }
    switch (unit.order.type) {
      case "charge":
        updateChargeOrder(game, unit);
        continue;
      case "move":
        advanceMoveOrder(game, unit, unit.order, navalUnitFrame);
        continue;
      case "attackMove":
        updateAttackMoveOrder(game, unit, navalUnitFrame);
        continue;
      case "hold":
        updateHoldOrder(game, unit, navalUnitFrame);
        continue;
      case "aim":
        updateAimOrder(game, unit, navalUnitFrame);
        continue;
      case "follow":
        updateFollowOrder(game, unit);
        continue;
      case "cast":
        updateCastOrder(game, unit);
        continue;
      case "attack":
        updateAttackOrder(game, unit, navalUnitFrame);
        continue;
      case "mine":
        updateMineOrder(game, unit);
        continue;
      case "build":
        updateBuildOrder(game, unit);
        continue;
      case "repair":
        updateRepairOrder(game, unit);
        continue;
      case "repairUnit":
      case "repairShip":
        updateUnitRepairOrder(game, unit);
        continue;
      case "pickupItem":
        updatePickupItemOrder(game, unit);
        continue;
      case "board":
        updateBoardOrder(game, unit);
        (ferry ??= { boarding: [], unloading: [] }).boarding.push(unit);
        continue;
      case "boardShip":
        updateBoardShipOrder(game, unit);
        continue;
      case "unload":
        moveToward(unit, unit.order.x, unit.order.y, game.map, game.units, navalUnitFrame);
        (ferry ??= { boarding: [], unloading: [] }).unloading.push(unit);
        continue;
    }
    if (unit.kind === "worker" && !unit.deck && updateAutoRepair(game, unit)) continue;
    if (navalUnitFrame && combatHull(unit) && unit.owner !== "neutral") {
      const defense = defenses.get(unit.id);
      if (defense?.target) {
        const target = navalCombatTarget(game, unit, defense.target);
        navigateShipAttack(game, unit, target);
        if (unitRules(game, unit).intrinsicAttack && unit.cooldown === 0 && targetGap(unit, target) <= unit.attackRange && aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) {
          applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
          markAimShot(unit);
          unit.cooldown = attackCooldownOf(game, unit);
        }
      } else if (defense?.returnTo) moveToward(unit, defense.returnTo.x, defense.returnTo.y, game.map, game.units);
      else updateHoldOrder(game, unit);
      continue;
    }
    if (navalUnitFrame && shipProfile(unit)) continue;
    if (unit.kind !== "worker") {
      const target = nearestEnemyTarget(game, unit, unit.owner === "neutral" ? 150 : AUTO_ACQUIRE_RANGE, navalUnitFrame);
      if (target) unit.order = { type: "attack", targetId: target.id, leashX: unit.x, leashY: unit.y };
    }
  }
  return ferry;
}
function deckPointOrder(game, unit, order) {
  if (unitMover(unit.kind) !== "land") return order;
  const ship = game.units.find((ship2) => shipProfile(ship2) && circleInPolygon(worldToLocal(ship2, order), 0, shipProfile(ship2).hull));
  return ship ? { ...order, deckPoint: worldToLocal(ship, order), deckShipId: ship.id } : order;
}
function deckGoal(unit, ship, goal, units) {
  const order = unit.order;
  if (order.type !== "move" && order.type !== "attackMove" || !order.deckPoint || order.x !== goal.x || order.y !== goal.y) return goal;
  const parent = units.find((unit2) => unit2.id === (order.deckShipId ?? ship?.id));
  return parent ? localToWorld(parent, order.deckPoint) : goal;
}
function advanceMoveOrder(game, unit, order, navalFrame) {
  if (unit.sailing && followQueuedShipCourse(unit, game.map, game.units, statusPace(unit))) return;
  moveToward(unit, order.x, order.y, game.map, game.units, navalFrame);
  if (walkEnded(game, unit, order, MOVE_ORDER_ARRIVAL_RANGE)) arrive(unit, order);
}
function updateShipOwnership(game) {
  let changed = false;
  for (const ship of shipsIn(game.units)) {
    const crew = shipPassengers(game.units, ship).filter((unit) => unit.hp > 0);
    if (!crew.length || crew.some((unit) => !areEnemyOwners(game, ship.owner, unit.owner))) continue;
    const occupants = crew.filter((unit) => isPlayerId(unit.owner)).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const owner = occupants[0]?.owner;
    if (!owner || occupants.some((unit) => areEnemyOwners(game, owner, unit.owner))) continue;
    ship.owner = owner;
    ship.order = { type: "idle" };
    ship.orderQueue = [];
    ship.aim = void 0;
    if (ship.sailing) {
      ship.sailing.speed = 0;
      ship.sailing.route = void 0;
      delete ship.sailing.pursuit;
      cancelShipPlanningJob(ship);
    }
    refreshUnitStats(game, ship);
    changed = true;
  }
  if (changed) updateSupplyState(game);
}
function assignUnitOrder(unit, order, queued = false) {
  if (queued) {
    unit.orderQueue = [...unit.orderQueue ?? [], order];
    return;
  }
  if (unit.order.type === "charge") {
    unit.orderQueue = [order];
    return;
  }
  unit.order = order;
  unit.orderQueue = [];
  if (unit.sailing?.gangway) cancelShipBoarding(unit);
  if (unit.sailing) {
    unit.sailing.route = void 0;
    delete unit.sailing.pursuit;
    cancelShipPlanningJob(unit);
    delete unit.sailing.planningRequestedAtTick;
    delete unit.sailing.planningLastRequestedAtTick;
  }
}
function activateQueuedOrder(game, unit) {
  if (unit.order.type !== "idle") return;
  const next = unit.orderQueue?.shift();
  if (!next) return;
  if (shipProfile(unit)) cancelCrewRendezvous(game.units, /* @__PURE__ */ new Set([unit.id]));
  unit.order = next;
  if (unit.sailing?.gangway) cancelShipBoarding(unit);
  if (unit.sailing) {
    unit.sailing.route = void 0;
    delete unit.sailing.pursuit;
    cancelShipPlanningJob(unit);
    delete unit.sailing.planningRequestedAtTick;
    delete unit.sailing.planningLastRequestedAtTick;
  }
}
function updateFollowOrder(game, unit) {
  if (unit.order.type !== "follow") return;
  const order = unit.order;
  const target = game.units.find((candidate) => candidate.id === order.targetId && !areEnemyOwners(game, candidate.owner, unit.owner));
  if (!target) {
    unit.order = { type: "idle" };
    return;
  }
  if (shipProfile(unit)) {
    const goal = shipPursuitGoal(unit, target, game.units, Math.max(72, shipProfile(unit).length * 0.6 + 20), 0, true);
    const pace = statusPace(unit);
    if (goal && pace > 0) sailToward(unit, goal, game.map, game.units, pace);
    return;
  }
  if (distance(unit, target) > followStopDistance(unit, target)) {
    moveToward(unit, target.x, target.y, game.map, game.units);
  }
}
function updateNeutralLeash(game, unit) {
  if (unit.owner !== "neutral" || unit.homeX === void 0 || unit.homeY === void 0) return false;
  const home = { x: unit.homeX, y: unit.homeY };
  const responseOrigin = neutralResponseOrigin(unit) ?? home;
  const homeDistance = distance(unit, home);
  if (homeDistance <= NEUTRAL_RETURN_STOP_RANGE && unit.order.type === "move" && distance(unit.order, home) <= NEUTRAL_RETURN_STOP_RANGE) {
    unit.order = { type: "idle" };
    return false;
  }
  const target = unit.order.type === "attack" ? findTarget(game, unit.order.targetId) : void 0;
  const returning = unit.order.type === "move" && distance(unit.order, home) <= NEUTRAL_RETURN_STOP_RANGE;
  const lostQuarry = !target && (unit.order.type === "idle" || unit.order.type === "attack");
  if (homeDistance <= NEUTRAL_LEASH_RANGE && !returning && (!lostQuarry || homeDistance <= NEUTRAL_RETURN_STOP_RANGE) && (!target || distance(target, responseOrigin) <= NEUTRAL_DAMAGE_RESPONSE_RANGE)) return false;
  unit.order = { type: "move", x: home.x, y: home.y };
  moveToward(unit, home.x, home.y, game.map, game.units);
  if (distance(unit, home) <= NEUTRAL_RETURN_STOP_RANGE) unit.order = { type: "idle" };
  return true;
}
function updateHoldOrder(game, unit, navalFrame = true) {
  if (navalFrame && shipProfile(unit) && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0 || unit.attackDamage <= 0) return;
  const target = nearestEnemyTarget(game, unit, unit.attackRange, navalFrame);
  if (!target) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function updateAimOrder(game, unit, navalFrame = true) {
  if (unit.order.type !== "aim") return;
  const point = unit.order;
  if (distance(unit, point) > unit.attackRange) {
    unit.aim = void 0;
    moveToward(unit, point.x, point.y, game.map, game.units, navalFrame);
    if (distance(unit, point) > unit.attackRange && walkEnded(game, unit, point, 5)) unit.order = { type: "idle" };
    return;
  }
  if (backOutOfDeadZone(game, unit, point, navalFrame)) {
    unit.aim = void 0;
    return;
  }
  if (nearestEnemyTarget(game, unit, unit.attackRange, navalFrame)) updateHoldOrder(game, unit, navalFrame);
  else aimAt(unit, weaponRules(game, unit), point, game.tick, veteranAimSpeed(game, unit));
}
function updateAttackMoveOrder(game, unit, navalFrame = true) {
  if (unit.order.type !== "attackMove") return;
  const order = unit.order;
  if (order.targetId) {
    const target2 = findTarget(game, order.targetId);
    if (!navalFrame && target2 && isUnit(target2) && (target2.deck || target2.cabin || isShipKind(target2.kind))) navalFrame = true;
    if (target2 && target2.hp > 0 && (!navalFrame || automaticTargetAllowed(game.units, unit.owner, target2)) && projectedHpAfterPendingProjectiles(game, unit.owner, target2) > 0 && areEnemyOwners(game, unit.owner, target2.owner) && (!navalFrame && !game.map.terrain || canReach(game.map, unit, target2, game.units)) && (!navalFrame || automaticShoreTargetReachable(game, unit, target2))) {
      const chosen = automaticCombatTarget(game, unit, target2, navalFrame);
      if (chosen.id !== order.targetId) unit.order = { ...order, targetId: chosen.id };
      attackMoveTowardTarget(game, unit, chosen, navalFrame);
      return;
    }
    const { targetId: _lost, ...destination } = order;
    unit.order = destination;
  }
  const profile = navalFrame ? shipProfile(unit) : void 0;
  const acquisition = profile ? Math.max(unit.attackRange, Math.min(700, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange + profile.length * 0.4 + 100))) : unitRules(game, unit).weapon ? Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange) : AUTO_ACQUIRE_RANGE;
  const target = nearestEnemyTarget(game, unit, acquisition, navalFrame);
  if (target) {
    unit.order = { ...order, targetId: target.id };
    attackMoveTowardTarget(game, unit, target, navalFrame);
    return;
  }
  if (unit.sailing) delete unit.sailing.pursuit;
  moveToward(unit, order.x, order.y, game.map, game.units, navalFrame);
  if (walkEnded(game, unit, order, 8)) arrive(unit, order);
}
function attackMoveTowardTarget(game, unit, target, navalFrame = true) {
  if (navalFrame) target = navalCombatTarget(game, unit, target);
  const gap = targetGap(unit, target, navalFrame);
  const ship = navalFrame && Boolean(shipProfile(unit));
  if (ship) navigateShipAttack(game, unit, target);
  else if (backOutOfDeadZone(game, unit, target, false)) return;
  if (gap > unit.attackRange) {
    if (!ship) moveToward(unit, target.x, target.y, game.map, game.units, navalFrame);
    return;
  }
  if (ship && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function __observed_updateAttackOrder(game, unit, navalFrame = true) {
  const order = unit.order;
  if (order.type !== "attack") return;
  let target = findStrikeTarget(game, order.targetId);
  if (!target) {
    unit.order = { type: "idle" };
    return;
  }
  if (!navalFrame && isUnit(target) && (target.deck || target.cabin || isShipKind(target.kind))) navalFrame = true;
  if (navalFrame && !isObstacle(target)) target = navalCombatTarget(game, unit, target);
  if (projectedHpAfterPendingProjectiles(game, unit.owner, target) <= 0 || (navalFrame || game.map.terrain) && !canReach(game.map, unit, target, game.units)) {
    const replacement = nearestEnemyTarget(game, unit, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange), navalFrame);
    if (!replacement) {
      unit.order = { type: "idle" };
      return;
    }
    unit.order = { ...order, targetId: replacement.id };
    updateAttackOrder(game, unit, navalFrame);
    return;
  }
  if (!isObstacle(target) && (unit.owner === "neutral" || order.leashX !== void 0)) {
    if (navalFrame && !automaticTargetAllowed(game.units, unit.owner, target)) {
      unit.order = { type: "idle" };
      return;
    }
    target = automaticCombatTarget(game, unit, target, navalFrame);
    if (target.id !== order.targetId) unit.order = { ...order, targetId: target.id };
  }
  const gap = targetGap(unit, target, navalFrame);
  const ship = navalFrame && Boolean(shipProfile(unit));
  if (!ship && backOutOfDeadZone(game, unit, target, false)) return;
  if (gap > unit.attackRange) {
    if (isPlayerId(unit.owner) && order.leashX !== void 0 && order.leashY !== void 0 && distance(unit, { x: order.leashX, y: order.leashY }) > GUARD_LEASH_RANGE) {
      unit.order = { type: "move", x: order.leashX, y: order.leashY };
      return;
    }
    if (ship) navigateShipAttack(game, unit, target);
    else moveToward(unit, target.x, target.y, game.map, game.units, navalFrame);
    return;
  }
  if (ship) navigateShipAttack(game, unit, target);
  if (ship && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function navigateShipAttack(game, ship, target) {
  if (game.boardingHolds?.has(ship.id)) return;
  const weapons = installedWeapons(game, ship).filter((item) => (item.durability ?? 1) > 0);
  const minimum = weapons.length ? Math.min(...weapons.map((item) => SHIP_WEAPONS[item.kind].weapon.minRange ?? 0)) : weaponRules(game, ship).weapon?.minRange ?? 0;
  const blockers = friendlyFireBlockers(game, ship);
  let firingHeading;
  const canFireFrom = (station, checkTurn) => {
    if (!weapons.length) return targetGap(station, target) <= station.attackRange && targetGap(station, target) >= minimum;
    shareShipProfile(ship, station);
    const start = { x: station.x, y: station.y, heading: station.sailing.heading };
    const shotClear = mountedShotClear(station, blockers);
    for (const margin of [Math.PI / 36, 0]) {
      const heading = bestFiringHeading(game, station, target, margin, shotClear), aimed = { ...station, sailing: { ...station.sailing, heading } }, end = { ...start, heading };
      shareShipProfile(ship, aimed);
      if (checkTurn && (!hullPassageClear(game.map, station, start, end) || !shipTraffic(station, game.units)(start, end))) continue;
      if (weapons.some((item) => {
        const pose = mountedWeaponPose(aimed, item), def = SHIP_WEAPONS[item.kind];
        if (!pose) return false;
        const point = mountedTargetPoint(game, aimed, item, target, pose);
        if (!shipGunCanAim(aimed, item, point)) return false;
        const gap = distance(pose.pivot, point);
        return gap <= veteranWeaponRange(station, def.range) && gap >= (def.weapon.minRange ?? 0) && (!blockers.length || mountedFireLaneClear(aimed, item, point, blockers));
      })) {
        if (checkTurn) firingHeading = heading;
        return true;
      }
    }
    return false;
  };
  const firing = canFireFrom(ship, true);
  const bow = weapons.find((item) => item.mountId === "bow" && veteranWeaponRange(ship, SHIP_WEAPONS[item.kind].range) >= ship.attackRange);
  const bowPose = bow && mountedWeaponPose(ship, bow);
  const stationBowReach = bowPose ? (bowPose.pivot.x - ship.x) * detCos(ship.sailing.heading) + (bowPose.pivot.y - ship.y) * detSin(ship.sailing.heading) : 0;
  const goal = shipPursuitGoal(
    ship,
    target,
    game.units,
    ship.attackRange,
    minimum,
    false,
    () => firing,
    game.map,
    firingHeading,
    stationBowReach,
    (station) => canFireFrom(station, false),
    () => tryAdmitShipPlan(ship),
    () => isObstacle(target) ? void 0 : shoreFiringStation(game, ship, target)
  );
  const pace = statusPace(ship);
  if (goal && pace > 0) sailToward(ship, goal, game.map, game.units, pace);
  else if (!goal && ship.sailing.planningRequestedAtTick !== void 0 && !ship.sailing.route) {
    ship.sailing.speed = 0;
    if (pace > 0) {
      const quarry = shipNavigationTarget(target, game.units);
      turnShipToward(ship, Math.atan2(quarry.y - ship.y, quarry.x - ship.x), game.map, game.units);
    }
  }
}
function updateMineOrder(game, unit) {
  if (unit.order.type !== "mine") return;
  const order = unit.order;
  const resource = game.miningFrame.resources.get(order.resourceId);
  if ((!resource || resource.amount <= 0) && order.phase !== "return") {
    unit.order = { type: "idle" };
    return;
  }
  if (order.phase === "toMine") {
    if (distance(unit, resource) > MINE_RANGE) {
      moveToward(unit, resource.x, resource.y, game.map, game.units);
      return;
    }
    order.timer += 1;
    if ((resource.harvestCooldownRemaining ?? 0) > 0) return;
    if (game.miningFrame.nextWorker.get(order.resourceId) !== unit.id) return;
    unit.mineSlot = order.resourceId;
    resource.harvestCooldownRemaining = GOLD_MINE_ENTRY_COOLDOWN;
    unit.order = { ...order, phase: "gather", timer: GATHER_DURATION };
    return;
  }
  if (order.phase === "gather") {
    order.timer -= 1;
    if (order.timer > 0) return;
    const mined = Math.min(GOLD_PER_TRIP, resource.amount);
    resource.amount -= mined;
    unit.carryingGold = mined;
    unit.order = { ...order, phase: "return", timer: 0 };
    return;
  }
  const townHall = nearestCompleteTownHall(game, unit.owner, unit.x, unit.y);
  if (!townHall) {
    unit.order = { type: "idle" };
    return;
  }
  if (distance(unit, townHall) > TOWN_HALL_DROP_RANGE) {
    moveToward(unit, townHall.x, townHall.y, game.map, game.units);
    return;
  }
  if (isPlayerId(unit.owner)) {
    const player = playerState(game, unit.owner);
    player.gold = addGold(player.gold, upkeepGoldIncome(unit.carryingGold, player.supplyUsed));
  }
  unit.carryingGold = 0;
  unit.order = resource && resource.amount > 0 ? { type: "mine", resourceId: resource.id, phase: "toMine", timer: 0 } : { type: "idle" };
}
function updateBoardShipOrder(game, ship) {
  if (ship.order.type !== "boardShip") return;
  const order = ship.order;
  const target = game.units.find((unit) => unit.id === order.targetId && unit.hp > 0);
  if (!target || !shipProfile(ship) || !ship.sailing) {
    cancelShipBoarding(ship);
    ship.order = { type: "idle" };
    return;
  }
  if (!ship.sailing.gangway && !beginShipBoarding(game.map, game.units, ship, target, game.tick, game)) {
    ship.order = { type: "idle" };
    return;
  }
  const state = ship.sailing.gangway;
  if (state.phase === "approach") {
    const goal = shipBoardingGoal(game.map, game.units, ship, target);
    if (goal) sailToward(ship, goal, game.map, game.units, statusPace(ship));
    return;
  }
  ship.sailing.speed = 0;
  ship.sailing.yawRate = 0;
  if (state.phase !== "ready") return;
  if (areEnemyOwners(game, ship.owner, target.owner)) for (const crew of shipPassengers(game.units, ship)) {
    const crewOrder = crew.order;
    const automaticTarget = crewOrder.type === "attack" && crewOrder.leashX !== void 0 ? game.units.find((unit) => unit.id === crewOrder.targetId) : void 0;
    const automaticAttack = crewOrder.type === "attack" && crewOrder.leashX !== void 0 && (crewOrder.targetId === target.id || automaticTarget?.deck?.shipId === target.id);
    if (crew.owner !== ship.owner || crew.kind === "worker" || !gangwayCrewEligible(crew, game) || unitRules(game, crew).attackRange > RANGED_ATTACK_RANGE_THRESHOLD || crew.attackDamage <= 0 || !["idle", "hold"].includes(crew.order.type) && !automaticAttack || crew.orderQueue?.length) continue;
    assignUnitOrder(crew, { type: "board", transportId: target.id });
  }
  ship.order = { type: "idle" };
}
function updateBoardOrder(game, unit) {
  if (unit.order.type !== "board") return;
  const transport = findTarget(game, unit.order.transportId);
  if (!transport || !isUnit(transport) || transport.hp <= 0 || !unit.deck && transport.owner !== unit.owner) {
    unit.order = { type: "idle" };
    return;
  }
  if (unit.deck) {
    const source = game.units.find((ship) => ship.id === unit.deck.shipId);
    if (!source) return;
    if (source.id !== transport.id && !decksCanTransfer(source, transport, unit)) return;
    if (unit.kind !== "worker" && areEnemyOwners(game, unit.owner, transport.owner) && unit.attackDamage > 0 && unitRules(game, unit).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD) {
      const nearby = navalCombatTarget(game, unit, transport, unit.attackRange);
      const defender = nearby !== transport ? nearby : navalCombatTarget(game, unit, transport);
      if (defender !== transport && isUnit(defender)) {
        const boardingOrder = unit.order;
        unit.order = { type: "attack", targetId: defender.id };
        try {
          updateAttackOrder(game, unit);
        } finally {
          unit.order = boardingOrder;
        }
        return;
      }
    }
    if (source.id !== transport.id && !canBoard(transport, unit, game.units)) {
      unit.order = { type: "idle" };
      addEffect(game, "boardingBlocked", unit.x, unit.y, seconds(0.4), { unitId: unit.id, owner: unit.owner, sourceKind: unit.kind });
      return;
    }
    const ahead = game.units.some((other) => other !== unit && other.hp > 0 && other.deck && other.order.type === "board" && other.order.transportId === transport.id && (other.radius > unit.radius || other.radius === unit.radius && other.id < unit.id));
    if (ahead && source.id !== transport.id) {
      const profile = shipProfile(source), entry = worldToLocal(source, transport);
      const waiting = deckPlacement(source, unit, game.units, { x: profile.length / 4, y: -Math.sign(entry.y) * profile.beam / 2 });
      if (waiting) {
        const at = localToWorld(source, waiting);
        moveToward(unit, at.x, at.y, game.map, game.units);
      }
      return;
    }
    if (unit.order.deckPoint && !deckPointFits(transport, unit, unit.order.deckPoint, game.units, true)) delete unit.order.deckPoint;
    if (!unit.order.deckPoint) {
      const reserved = game.units.map((other) => other !== unit && other.order.type === "board" && other.order.transportId === transport.id && other.order.deckPoint ? { ...other, deck: { shipId: transport.id, ...other.order.deckPoint } } : other);
      const entry = worldToLocal(transport, source), profile = shipProfile(transport);
      const reach = Math.hypot(entry.x, entry.y) || 1;
      const preferred = { x: profile.length / 2, y: -entry.y / reach * profile.beam / 2 };
      const point2 = deckPlacement(transport, unit, reserved, preferred, true);
      if (point2) unit.order.deckPoint = point2;
    }
    const point = unit.order.deckPoint;
    if (!point) return;
    const goal2 = localToWorld(transport, point);
    if (source.id === transport.id) {
      moveToward(unit, goal2.x, goal2.y, game.map, game.units);
      if (distance(unit, goal2) < 1e-6) unit.order = { type: "idle" };
    } else if (decksCanTransfer(source, transport, unit)) moveToward(unit, goal2.x, goal2.y, game.map, game.units);
    return;
  }
  if (alongside(unit, transport)) return;
  const goal = transport.order.type === "idle" ? unit.order.berth?.shore ?? unit.order.berth ?? transport : transport;
  moveToward(unit, goal.x, goal.y, game.map, game.units);
}
function ferryUnits(game, { boarding, unloading }, starts) {
  const approached = /* @__PURE__ */ new Set();
  for (const passenger of boarding) {
    if (passenger.order.type !== "board" || passenger.deck || approached.has(passenger.order.transportId)) continue;
    const boat = findTarget(game, passenger.order.transportId);
    if (!boat || !isUnit(boat) || boat.order.type !== "idle") continue;
    approached.add(boat.id);
    const requested = passenger.order.berth ?? boardingBerth(game.map, passenger, boat);
    if (requested?.shore && distanceToHull(boat, requested.shore) <= passenger.radius + BOARDING_GAP) continue;
    const route = boat.sailing?.route;
    const approaching = requested && route && route.points.length > 0 && (!route.partial || distance(boat, requested) > (shipProfile(boat)?.length ?? boat.radius * 2) * 2) && Math.hypot(route.goalX - requested.x, route.goalY - requested.y) <= (game.map.terrain?.cell ?? 0) / 2;
    const berth = requested && (approaching ? requested : clearBoardingBerth(game.map, passenger, boat, requested, game.units));
    if (berth && berth !== requested) {
      for (const waiting of boarding)
        if (waiting.order.type === "board" && waiting.order.transportId === boat.id) waiting.order.berth = berth;
    }
    if (berth && !alongside(passenger, boat)) sailToward(boat, berth, game.map, game.units);
  }
  for (const passenger of boarding) {
    if (passenger.order.type !== "board" || passenger.deck) continue;
    const ship = findTarget(game, passenger.order.transportId);
    if (!ship || !isUnit(ship) || !alongside(passenger, ship)) continue;
    const boarded = boardUnit(ship, passenger, game.units);
    assignUnitOrder(passenger, { type: "idle" });
    addEffect(game, boarded ? "board" : "boardingBlocked", passenger.x, passenger.y, seconds(0.4), { unitId: passenger.id, owner: passenger.owner, sourceKind: passenger.kind });
  }
  for (const ship of unloading) {
    if (ship.order.type !== "unload" || (ship.sailing?.speed ?? 0) > 0.1) continue;
    const start = starts.get(ship.id);
    if (start && (distance(ship, start) > 1e-6 || Math.abs(headingDifference(start.heading, ship.sailing.heading)) > 1e-6)) continue;
    const arrived = walkEnded(game, ship, ship.order, 8);
    const planning = ship.sailing?.planningJob !== void 0 || ship.sailing?.planningRequestedAtTick !== void 0;
    if (unloadCargo(game, ship) > 0 || arrived || !planning && shipPassengers(game.units, ship).length === 0) ship.order = { type: "idle" };
  }
}
function unloadCargo(game, ship, passengerId) {
  if (ship.cargo) restoreCargoDecks(game.units);
  const crew = shipPassengers(game.units, ship);
  let landed = 0;
  crew.forEach((passenger, index) => {
    if (isInCabin(passenger) || passenger.owner !== ship.owner || passengerId !== void 0 && passenger.id !== passengerId) return;
    const spot = landingSpot(game.map, ship, index, crew.length, game.units, passenger);
    if (!spot) return;
    passenger.deck = void 0;
    passenger.cabin = void 0;
    passenger.aim = void 0;
    Object.assign(passenger, spot);
    assignUnitOrder(passenger, { type: "idle" });
    addEffect(game, "unload", spot.x, spot.y, seconds(0.4), { unitId: passenger.id, owner: passenger.owner, sourceKind: passenger.kind });
    landed++;
  });
  syncDecks(game.units);
  updateSupplyState(game);
  return landed;
}
function cargoSupply(game, ship) {
  return (ship.cargo ?? []).reduce((sum, passenger) => sum + unitRules(game, passenger).supplyUsed, 0);
}
function updateBuildOrder(game, unit) {
  if (unit.order.type !== "build" || !isPlayerId(unit.owner)) return;
  const order = unit.order;
  const def = BUILDING_DEFS[order.buildingKind];
  const half = footprintHalf(def.radius, TERRAIN_CELL);
  const gap = Math.hypot(Math.max(0, Math.abs(unit.x - order.x) - half), Math.max(0, Math.abs(unit.y - order.y) - half));
  if (gap > BUILDING_WORK_REACH) {
    if (order.progressTick === void 0 || Math.hypot(unit.x - (order.progressX ?? unit.x), unit.y - (order.progressY ?? unit.y)) > 24) {
      order.progressTick = game.tick;
      order.progressX = unit.x;
      order.progressY = unit.y;
    } else if (game.tick - order.progressTick > seconds(20)) {
      unit.order = { type: "idle" };
      return;
    }
    moveToward(unit, order.x, order.y, game.map, game.units);
    return;
  }
  if (buildingPlacementBlocker(game, order.buildingKind, order) || terrainBlocksPlacement(game.map, order.buildingKind, order)) {
    unit.order = { type: "idle" };
    return;
  }
  if (playerState(game, unit.owner).gold < def.cost) return;
  spendGold(game, unit.owner, def.cost);
  const building = createBuilding(`building-${unit.owner}-${order.buildingKind}-${game.nextId++}`, unit.owner, order.buildingKind, order.x, order.y, false);
  applyDerivedBuildingStats(game, building);
  building.hp = constructionStartHp(building.maxHp);
  game.buildings.push(building);
  syncBuildingBodies(game);
  unit.order = { type: "repair", buildingId: building.id };
  addEffect(game, "build", building.x, building.y, 60);
}
function updateRepairOrder(game, unit) {
  if (unit.order.type !== "repair" || !isPlayerId(unit.owner)) return;
  const order = unit.order;
  const building = game.buildings.find((candidate) => candidate.id === order.buildingId && candidate.owner === unit.owner);
  if (!building || building.hp <= 0 || building.complete && building.hp >= building.maxHp) {
    unit.order = { type: "idle" };
    return;
  }
  if (buildingWorkGap(unit, building) > BUILDING_WORK_REACH) {
    moveToward(unit, building.x, building.y, game.map, game.units);
    return;
  }
  if (!building.complete || unit.cooldown > 0) return;
  if (!repairBuildingTick(game, unit, building)) unit.order = { type: "idle" };
}
function updateAutoRepair(game, unit) {
  if (unit.order.type !== "idle" || !isPlayerId(unit.owner)) return false;
  if (unit.cooldown > 0) return false;
  const building = game.buildings.find(
    (candidate) => candidate.owner === unit.owner && candidate.complete && candidate.hp > 0 && candidate.hp < candidate.maxHp && buildingWorkGap(unit, candidate) <= BUILDING_WORK_REACH
  );
  if (!building) return false;
  return repairBuildingTick(game, unit, building);
}
function updateUnitRepairOrder(game, worker) {
  if (worker.order.type !== "repairUnit" && worker.order.type !== "repairShip") return;
  if (worker.kind !== "worker" || !isPlayerId(worker.owner)) {
    worker.order = { type: "idle" };
    return;
  }
  const targetId = worker.order.targetId;
  const target = game.units.find((unit) => unit.id === targetId && unit.owner === worker.owner && (worker.order.type !== "repairShip" || unitMover(unit.kind) === "sea"));
  if (!target || !unitNeedsRepair(game, target)) {
    worker.order = { type: "idle" };
    return;
  }
  const ship = Boolean(shipProfile(target));
  const sameWorkSurface = ship ? worker.deck?.shipId === target.id : worker.deck?.shipId === target.deck?.shipId;
  const withinReach = distance(worker, target) <= worker.radius + target.radius + BUILDING_WORK_REACH;
  const canWorkHere = ship ? sameWorkSurface || !worker.deck && withinReach : sameWorkSurface && withinReach;
  if (!canWorkHere) {
    moveToward(worker, target.x, target.y, game.map, game.units);
    return;
  }
  repairUnitTick(game, worker, target);
  if (!unitNeedsRepair(game, target)) worker.order = { type: "idle" };
}
function autoRepairDeckShip(game, worker) {
  if (worker.kind !== "worker" || !worker.deck || !isPlayerId(worker.owner) || worker.orderQueue?.length || !["idle", "hold"].includes(worker.order.type)) return false;
  const ship = game.units.find((unit) => unit.id === worker.deck.shipId && unit.owner === worker.owner && unit.hp > 0);
  if (!ship || !shipProfile(ship) || !unitNeedsRepair(game, ship) || playerState(game, worker.owner).gold < 1) return false;
  repairUnitTick(game, worker, ship);
  return true;
}
function repairUnitTick(game, worker, target) {
  if (worker.kind !== "worker" || !isPlayerId(worker.owner) || target.owner !== worker.owner || !unitNeedsRepair(game, target)) return;
  if (worker.cooldown > 0) return;
  const player = playerState(game, worker.owner);
  if (player.gold < 1) return;
  emitWorkerWork(game, worker, target);
  const healed = unitRepairHpPerGold(game, target);
  spendGold(game, worker.owner, 1);
  if (shipProfile(target)) repairShipParts(game, target, healed);
  else target.hp = Math.min(target.maxHp, target.hp + healed);
  worker.cooldown = seconds(healed / REPAIR_HP_PER_SECOND);
}
function emitWorkerWork(game, worker, target) {
  if (game.effects.some((effect) => effect.type === "repair" && effect.unitId === worker.id)) return;
  game.effects.push({
    id: `work-${worker.id}-${game.tick}`,
    type: "repair",
    x: worker.x,
    y: worker.y,
    duration: seconds(0.65),
    remaining: seconds(0.65),
    unitId: worker.id,
    fromX: target.x,
    fromY: target.y
  });
}
function repairBuildingTick(game, unit, building) {
  if (!isPlayerId(unit.owner)) return false;
  const owner = unit.owner;
  const player = playerState(game, owner);
  if (player.gold < 1 || building.hp >= building.maxHp) return false;
  const fullRepairCost = Math.max(1, Math.round(BUILDING_DEFS[building.kind].cost * REPAIR_FULL_COST_FRACTION));
  const hpPerGold = Math.max(1, building.maxHp / fullRepairCost);
  spendGold(game, owner, 1);
  building.hp = Math.min(building.maxHp, building.hp + hpPerGold);
  unit.cooldown = seconds(hpPerGold / REPAIR_HP_PER_SECOND);
  emitWorkerWork(game, unit, building);
  addRepairHammerEffect(game, building);
  return true;
}
function addRepairHammerEffect(game, building, queued = false) {
  const activeType = queued ? ["repair", "queuedRepair"] : ["repair"];
  if (game.effects.some((effect) => activeType.includes(effect.type) && effect.x === building.x && effect.y === building.y)) return;
  addEffect(game, queued ? "queuedRepair" : "repair", building.x, building.y, REPAIR_HAMMER_EFFECT_DURATION, { owner: building.owner });
}
function queueTraining(game, building, unitKind) {
  if (!building.complete) throw new Error(`Cannot train from incomplete ${building.kind}`);
  if (!canTrainAt(playerState(game, building.owner).race, building.kind, unitKind)) throw new Error(`${building.kind} cannot train ${unitKind} for ${playerState(game, building.owner).race}`);
  const cap = requiredSupplyCap(unitKind);
  if (playerState(game, building.owner).supplyCap < cap) throw new Error(`Need a supply cap of ${cap} to train ${unitKind}`);
  if (projectedSupplyUsed(game, building.owner) + UNIT_DEFS[unitKind].supplyUsed > playerState(game, building.owner).supplyCap) {
    throw new Error(`Need more supply to train ${unitKind}`);
  }
  spendGold(game, building.owner, UNIT_DEFS[unitKind].cost);
  building.queue.push({ id: `training-${game.nextId++}`, unitKind, remaining: trainTimeFor(unitKind), paidGold: UNIT_DEFS[unitKind].cost });
  updateSupplyState(game);
}
function setRally(game, owner, buildingIds, x, y, target) {
  const buildings = buildingsByIds(game, buildingIds, owner);
  const normalized = normalizeRallyTarget(game, owner, x, y, target);
  for (const building of buildings) {
    if (BUILDING_DEFS[building.kind].trains.length === 0) throw new Error(`${building.kind} has no training rally point`);
    building.rallyX = normalized.x;
    building.rallyY = normalized.y;
    building.rallyTarget = normalized.target;
  }
  addEffect(game, "move", normalized.x, normalized.y, 24, { owner });
}
function normalizeRallyTarget(game, owner, x, y, target) {
  if (!target || target.type === "point") {
    return { x: clamp(x, 0, game.map.width), y: clamp(y, 0, game.map.height), target: { type: "point" } };
  }
  if (target.type === "resource") {
    const resource = game.resources.find((candidate) => candidate.id === target.resourceId);
    if (!resource) throw new Error(`Unknown rally resource ${target.resourceId}`);
    return { x: resource.x, y: resource.y, target };
  }
  const unit = game.units.find((candidate) => candidate.id === target.unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} rally unit ${target.unitId}`);
  return { x: unit.x, y: unit.y, target };
}
function rallyOrderForUnit(game, building, unit) {
  const target = building.rallyTarget;
  if (target?.type === "resource" && unit.kind === "worker" && game.resources.some((resource) => resource.id === target.resourceId && resource.amount > 0)) {
    return { type: "mine", resourceId: target.resourceId, phase: "toMine", timer: 0 };
  }
  if (target?.type === "unit" && game.units.some((candidate) => candidate.id === target.unitId && candidate.owner === unit.owner && candidate.hp > 0)) {
    return { type: "follow", targetId: target.unitId };
  }
  return { type: "move", x: building.rallyX, y: building.rallyY };
}
function queueResearch(game, building, upgradeKind) {
  if (!building.complete) throw new Error(`Cannot research from incomplete ${building.kind}`);
  const upgrade = UPGRADE_DEFS[upgradeKind];
  if (!upgrade) throw new Error(`Unknown upgrade ${upgradeKind}`);
  if (!RACE_DEFS[playerState(game, building.owner).race].upgrades.includes(upgradeKind)) throw new Error(`${playerState(game, building.owner).race} race cannot research ${upgradeKind}`);
  if (!canResearchAt(playerState(game, building.owner).race, building.kind, upgradeKind)) {
    throw new Error(`${building.kind} cannot research ${upgradeKind}`);
  }
  const player = playerState(game, building.owner);
  const currentLevel = player.upgrades[upgradeKind] ?? 0;
  if (currentLevel >= maxUpgradeLevel(upgradeKind)) throw new Error(`${upgradeKind} already at max level`);
  if (building.researchQueue.some((job) => job.upgradeKind === upgradeKind)) throw new Error(`${upgradeKind} is already queued`);
  const targetLevel = currentLevel + 1;
  const level = upgrade.levels[targetLevel - 1];
  if (!level) throw new Error(`${upgradeKind} missing level ${targetLevel}`);
  spendGold(game, building.owner, level.cost);
  building.researchQueue.push({ upgradeKind, targetLevel, remaining: level.researchTime });
}
function completeResearch(game, owner, upgradeKind, targetLevel) {
  const player = playerState(game, owner);
  const currentLevel = player.upgrades[upgradeKind] ?? 0;
  if (targetLevel <= currentLevel) return;
  if (targetLevel !== currentLevel + 1) throw new Error(`${upgradeKind} research completed out of order`);
  player.upgrades[upgradeKind] = targetLevel;
  for (const unit of game.units.filter((candidate) => candidate.owner === owner)) {
    applyUpgradeLevelToUnit(game, unit, upgradeKind, targetLevel);
  }
  for (const building of game.buildings.filter((candidate) => candidate.owner === owner)) {
    applyUpgradeLevelToBuilding(game, building, upgradeKind, targetLevel);
  }
}
function applyUnitUpgrades(game, unit) {
  if (!isPlayerId(unit.owner)) return;
  applyDerivedUnitStats(game, unit);
}
function applyUpgradeLevelToUnit(game, unit, upgradeKind, level) {
  const upgrade = UPGRADE_DEFS[upgradeKind];
  const levelDef = upgrade.levels[level - 1];
  if (!levelDef) throw new Error(`${upgradeKind} missing level ${level}`);
  if (!upgrade.affectedUnitKinds.includes(unit.kind)) return;
  applyDerivedUnitStats(game, unit);
}
function applyUpgradeLevelToBuilding(game, building, upgradeKind, level) {
  const upgrade = UPGRADE_DEFS[upgradeKind];
  const levelDef = upgrade.levels[level - 1];
  if (!levelDef) throw new Error(`${upgradeKind} missing level ${level}`);
  if (!levelDef.buildingMaxHpMultiplier) return;
  applyDerivedBuildingStats(game, building);
}
function applyDerivedBuildingStats(game, building) {
  const previousMaxHp = building.maxHp;
  const def = BUILDING_DEFS[building.kind];
  let maxHp = def.hp;
  for (const upgradeKind of UPGRADE_KINDS) {
    const upgradeLevel = playerState(game, building.owner).upgrades[upgradeKind] ?? 0;
    for (let level = 0; level < upgradeLevel; level += 1) {
      const levelDef = UPGRADE_DEFS[upgradeKind].levels[level];
      if (!levelDef?.buildingMaxHpMultiplier) continue;
      maxHp = Math.round(maxHp * levelDef.buildingMaxHpMultiplier);
    }
  }
  building.maxHp = maxHp;
  building.hp = Math.min(building.maxHp, Math.max(1, building.hp + building.maxHp - previousMaxHp));
  building.attackDamage = def.attackDamage;
  building.attackRange = def.attackRange;
  building.attackCooldown = def.attackCooldown;
}
function hireMercenary(game, owner, campId) {
  const camp = game.mercenaryCamps.find((candidate) => candidate.id === campId);
  if (!camp) throw new Error(`Unknown mercenary camp ${campId}`);
  if (camp.stock <= 0) throw new Error(`${camp.id} has no mercenary stock`);
  if (camp.cooldownRemaining > 0) throw new Error(`${camp.id} is restocking`);
  if (!hasFriendlyUnitAtMercenaryCamp(game, owner, camp)) throw new Error(`${camp.id} needs a friendly unit nearby before hiring`);
  if (!canSupply(game, owner, camp.hireKind)) throw new Error(`Need more supply to hire ${camp.hireKind}`);
  spendGold(game, owner, camp.cost);
  camp.stock -= 1;
  camp.cooldownRemaining = camp.cooldown;
  const offset = owner === "player" ? -camp.radius : camp.radius;
  const mercenary = game.spawnUnit(owner, camp.hireKind, camp.x + offset, camp.y);
  addEffect(game, "summon", camp.x, camp.y, 34);
  updateSupplyState(game);
  return mercenary;
}
function buyGood(game, owner, shopId, kind, recipientId) {
  const refusal = buyRefusal(game, owner, shopId, kind, recipientId);
  if (refusal) throw new Error(refusal.message);
  const shop = game.shops.find((candidate) => candidate.id === shopId);
  const good = shop.goods.find((candidate) => candidate.kind === kind);
  const delivery = recipientId !== void 0 ? purchasePlacement(game, owner, shop, kind, recipientId) : void 0;
  if (delivery && "refusal" in delivery) throw new Error(delivery.refusal);
  spendGold(game, owner, good.cost);
  good.stock -= 1;
  if (good.restockRemaining <= 0) good.restockRemaining = good.restock;
  const item = { id: `item-${owner}-${kind}-${game.nextId}`, kind, x: shop.x, y: shop.y + shop.radius + 16, cooldownRemaining: 0 };
  game.nextId += 1;
  game.items.push(item);
  if (delivery && "placement" in delivery) deliverPurchase(game, item, delivery.placement);
  else {
    const buyer = shopBuyer(game, owner, shop, kind);
    if (buyer) attachItemToUnit(game, item, buyer);
    addEffect(game, "summon", shop.x, shop.y, 24);
  }
  return item;
}
function deliverPurchase(game, item, placement) {
  const recipient = game.units.find((unit) => unit.id === ("unitId" in placement ? placement.unitId : placement.shipId));
  if ("unitId" in placement) {
    item.carrierId = recipient.id;
    item.slot = placement.slot;
  } else {
    item.shipId = recipient.id;
    item.holdSlot = placement.slot;
  }
  item.x = recipient.x;
  item.y = recipient.y;
  invalidateItemIndex(game.items);
  applyDerivedUnitStats(game, recipient);
  refreshEquipmentMass(game);
  addEffect(game, "itemReceived", recipient.x, recipient.y, seconds(0.8), { owner: recipient.owner });
}
function hasFriendlyUnitAtMercenaryCamp(game, owner, camp) {
  return game.units.some((unit) => unit.owner === owner && unitControlsMercenaryCamp(unit, camp));
}
function updatePickupItemOrder(game, unit) {
  if (unit.order.type !== "pickupItem") return;
  const itemId = unit.order.itemId;
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item || item.carrierId || item.shipId) {
    unit.order = { type: "idle" };
    return;
  }
  if (distance(unit, item) > ITEM_PICKUP_RANGE) {
    moveToward(unit, item.x, item.y, game.map, game.units);
    return;
  }
  if (freeItemSlot(game, unit, item.kind)) attachItemToUnit(game, item, unit);
  unit.order = { type: "idle" };
}
function pickupItem(game, owner, unitId, itemId, queued = false) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item carrier ${unitId}`);
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item) throw new Error(`Unknown item ${itemId}`);
  if (item.carrierId || item.shipId) throw new Error(`${item.id} is already carried`);
  if (unitMover(unit.kind) === "sea") throw new Error("A ship carries no items");
  if (!canEquip(unit) || !freeItemSlot(game, unit, item.kind)) throw new Error(`${unit.id} has no free equipment position`);
  if (distance(unit, item) > ITEM_PICKUP_RANGE) {
    assignUnitOrder(unit, { type: "pickupItem", itemId }, queued);
    return;
  }
  attachItemToUnit(game, item, unit);
}
function attachItemToUnit(game, item, unit) {
  const slot = freeItemSlot(game, unit, item.kind);
  if (!slot) return;
  item.slot = slot;
  item.carrierId = unit.id;
  delete item.deck;
  invalidateItemIndex(game.items);
  item.x = unit.x;
  item.y = unit.y;
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function dropItem(game, owner, unitId, itemId, x, y) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item carrier ${unitId}`);
  const refusal = dropRefusal(game, owner, unitId, itemId);
  if (refusal) throw new Error(refusal);
  const item = game.items.find((item2) => item2.id === itemId);
  const ship = game.units.find((ship2) => ship2.id === item.shipId);
  delete item.carrierId;
  delete item.slot;
  delete item.shipId;
  delete item.holdSlot;
  delete item.mountId;
  removeFromHands(unit, item.id);
  if (ship) rebuildShipFittings(game, ship);
  invalidateItemIndex(game.items);
  item.x = clamp(x, 0, game.map.width);
  item.y = clamp(y, 0, game.map.height);
  settleGroundItems(game.items, game.units, game.map);
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function useItem(game, owner, unitId, itemId, targetId, x, y) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item user ${unitId}`);
  const item = carriedItem(game, unit, itemId);
  const previousHands = unit.hands ? { ...unit.hands } : void 0;
  if (!ITEM_DEFS[item.kind].passive && !itemEquipped(game, unit, item)) {
    unit.hands ??= {};
    removeFromHands(unit, item.id);
    unit.hands.right = item.id;
    if (itemHands(item) === 2) delete unit.hands.left;
    unit.aim = void 0;
    applyDerivedUnitStats(game, unit);
  }
  activateItem(game, unit, item, targetId, x, y);
  if (previousHands && !game.items.some((candidate) => candidate.id === item.id)) {
    unit.hands = previousHands;
    applyDerivedUnitStats(game, unit);
  }
}
function castAbility(game, owner, unitId, ability, targetId, x, y, queued = false) {
  const caster = game.units.find((unit) => unit.id === unitId && unit.owner === owner);
  if (!caster || caster.hp <= 0) throw new Error(`Unknown ${owner} caster ${unitId}`);
  if (isStunned(caster)) throw new Error(`${caster.kind} is stunned`);
  if (!unitAbilities(caster).includes(ability)) throw new Error(`${caster.kind} cannot cast ${ability}`);
  if (abilityCooldown(caster, ability) > 0) throw new Error(`${caster.kind} is on cooldown`);
  const def = ABILITY_DEFS[ability];
  if (def.behavior === "veteran") {
    if (queued) assignUnitOrder(caster, { type: "cast", ability }, true);
    else applyVeteranAbility(game, caster, def, false);
    return;
  }
  const typedTarget = targetId ? findStrikeTarget(game, targetId) : void 0;
  if (typedTarget && isUnit(typedTarget) && !matchesUnitTarget(typedTarget, def.targets, game)) {
    throw new Error(def.behavior === "heal" ? "Healing cannot restore mechanical units" : "Ability cannot target this unit class");
  }
  const later = (order, at) => {
    assignUnitOrder(caster, order, queued);
    addEffect(game, queued ? "queuedMove" : "move", at.x, at.y, queued ? 38 : 24, { owner });
  };
  if (def.behavior === "weapon") {
    const target = targetId ? findStrikeTarget(game, targetId) : void 0;
    if (def.target === "enemy" && (!target || !areEnemyOwners(game, owner, target.owner))) throw new Error("Weapon skill requires an enemy target");
    const point = target ?? (isNumber(x) && isNumber(y) ? { x, y } : void 0);
    if (!point) throw new Error("Weapon skill requires a target point");
    if (def.weapon.minRange && distance(caster, point) < def.weapon.minRange) throw new Error("Target inside weapon minimum range");
    if (queued || isShipKind(caster.kind) || aimingProfile(unitRules(game, caster)) || distance(caster, point) > def.range + (target && !isUnit(target) ? target.radius : 0)) later({ type: "cast", ability, ...target ? { targetId: target.id } : { x: point.x, y: point.y } }, point);
    else applyWeaponAbility(game, caster, ability, point, def, target?.id);
    return;
  }
  if (def.behavior === "heal") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && !areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Heal requires an allied unit target");
    if (!canReceiveHealing(target, game)) throw new Error("Healing cannot restore mechanical units");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else applyHeal(game, caster, ability, target, def);
    return;
  }
  if (def.behavior === "curse") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Curse requires an enemy unit target");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else applyCurse(game, caster, ability, target, def);
    return;
  }
  if (def.behavior === "charge") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Charge requires an enemy unit target");
    if (distance(caster, target) < def.minRange) throw new Error(`Charge target must be at least ${def.minRange} away`);
    if (!canReach(game.map, caster, target, game.units)) throw new Error("Charge target is out of reach");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else startCharge(game, caster, ability, target, def, true);
    return;
  }
  if (def.behavior !== "summon") throw new Error(`${ability} is cast by its creep alone`);
  if (!isNumber(x) || !isNumber(y)) throw new Error("Summon requires a target point");
  if (queued || distance(caster, { x, y }) > def.range) later({ type: "cast", ability, x, y }, { x, y });
  else applySummon(game, caster, ability, x, y, def);
}
function updateCastOrder(game, unit) {
  const order = unit.order;
  if (order.type !== "cast") return;
  const def = ABILITY_DEFS[order.ability];
  const target = order.targetId === void 0 ? void 0 : findStrikeTarget(game, order.targetId);
  const end = () => {
    unit.order = { type: "idle" };
  };
  if (!def) return end();
  if (def.behavior === "veteran") {
    if (unitAbilities(unit).includes(order.ability) && abilityCooldown(unit, order.ability) <= 0) applyVeteranAbility(game, unit, def, false);
    return end();
  }
  if (order.targetId !== void 0 && (!target || target.hp <= 0 || areEnemyOwners(game, target.owner, unit.owner) !== (def.behavior !== "heal"))) return end();
  if (target && isUnit(target) && !matchesUnitTarget(target, def.targets, game)) return end();
  if (def.behavior === "heal" && target && (!isUnit(target) || !canReceiveHealing(target, game))) return end();
  const at = target ?? (isNumber(order.x) && isNumber(order.y) ? { x: order.x, y: order.y } : void 0);
  if (!at) return end();
  if (def.behavior === "weapon" && def.weapon.minRange && distance(unit, at) < def.weapon.minRange) return end();
  if (distance(unit, at) > def.range + (def.behavior === "weapon" && target && !isUnit(target) ? target.radius : 0)) {
    moveToward(unit, at.x, at.y, game.map, game.units);
    if (walkEnded(game, unit, at, 5)) end();
    return;
  }
  if (abilityCooldown(unit, order.ability) > 0) return end();
  if (def.behavior === "weapon") {
    if (order.ability === "incendiaryFlume" && unit.fittings) {
      const item = installedWeapons(game, unit).find((item2) => item2.kind === "flameProjector" && (item2.durability ?? 1) > 0);
      if (!item) return end();
      if (!shipGunCanAim(unit, item, at)) {
        const mount = shipMounts(unit).find((mount2) => mount2.id === item.mountId);
        turnShipToward(unit, Math.atan2(at.y - unit.y, at.x - unit.x) - mount.bearing, game.map, game.units);
        return;
      }
      item.facing = Math.atan2(at.y - mountedWeaponPose(unit, item).pivot.y, at.x - mountedWeaponPose(unit, item).pivot.x);
      const proxy = aimMountedWeapon(game, unit, item, at);
      if (!proxy) return;
      applyWeaponAbility(game, unit, order.ability, at, def, target?.id);
      markAimShot(proxy);
      end();
      return;
    }
    if (!aimAt(unit, weaponRules(game, unit), at, game.tick, veteranAimSpeed(game, unit))) return;
    applyWeaponAbility(game, unit, order.ability, at, def, target?.id);
    markAimShot(unit);
  } else if (def.behavior === "heal" && target && isUnit(target)) applyHeal(game, unit, order.ability, target, def);
  else if (def.behavior === "curse" && target && isUnit(target)) applyCurse(game, unit, order.ability, target, def);
  else if (def.behavior === "summon") applySummon(game, unit, order.ability, at.x, at.y, def);
  else if (def.behavior === "charge" && target && isUnit(target) && distance(unit, target) >= def.minRange && canReach(game.map, unit, target, game.units)) {
    startCharge(game, unit, order.ability, target, def, false);
    return;
  }
  end();
}
function applyHeal(game, caster, ability, target, def) {
  if (!matchesUnitTarget(target, def.targets, game) || !canReceiveHealing(target, game) || distance(caster, target) > def.range) return;
  target.hp = Math.min(target.maxHp, target.hp + def.healAmount);
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, target.x, target.y, 36, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: target.x, toY: target.y, toHeight: combatVisualHeight(game, target), unitId: caster.id, owner: caster.owner });
}
function syncSummonLoad(game, ship, probe) {
  return shipPassengers(game.units, ship).reduce((mass, unit) => mass + bodyMass(unit), bodyMass(probe)) > shipProfile(ship).loadCapacity;
}
function applySummon(game, caster, ability, x, y, def) {
  if (distance(caster, { x, y }) > def.range) return false;
  const ship = game.units.find((ship2) => {
    const profile = shipProfile(ship2);
    return profile && ship2.owner === caster.owner && circleInPolygon(worldToLocal(ship2, { x, y }), 0, profile.deck);
  });
  if (!ship && !isWalkable(game.map, x, y)) return false;
  const probe = ship && createUnit("summon-probe", caster.owner, def.summonKind, x, y);
  const point = ship && probe && deckPlacement(ship, probe, game.units, worldToLocal(ship, { x, y }));
  if (ship && (!point || syncSummonLoad(game, ship, probe))) return false;
  const spirit = game.spawnUnit(caster.owner, def.summonKind, x, y);
  if (ship && point) {
    spirit.deck = { shipId: ship.id, ...point };
    Object.assign(spirit, localToWorld(ship, point));
  }
  spirit.expiresTick = game.tick + def.summonDuration;
  spirit.order = { type: "idle" };
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, spirit.x, spirit.y, 50, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: spirit.x, toY: spirit.y, toHeight: combatVisualHeight(game, spirit), unitId: caster.id, owner: caster.owner });
  return true;
}
function applyCurse(game, caster, ability, target, def) {
  if (!matchesUnitTarget(target, def.targets, game) || distance(caster, target) > def.range) return;
  const damageMultiplier = target.effects.some((effect) => effect.type === "scorch") ? def.scorchedDamageMultiplier ?? def.damageMultiplier : def.damageMultiplier;
  target.effects = target.effects.filter((effect) => effect.type !== def.statusType);
  target.effects.push({ type: def.statusType, remaining: def.effectDuration, ...damageMultiplier !== 0.4 ? { damageMultiplier } : {} });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, target.x, target.y, 46, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: target.x, toY: target.y, toHeight: combatVisualHeight(game, target), unitId: caster.id, owner: caster.owner });
  if (def.summonedDamage && target.expiresTick !== void 0) applyDamage(game, caster, target, def.summonedDamage, void 0, void 0, 0, DAMAGE_PROFILES.ARCANE);
}
function inChargeWindow(caster, target, def) {
  const gap = distance(caster, target);
  return gap >= def.minRange && gap <= def.range;
}
function startCharge(game, caster, ability, target, def, commanded) {
  if (!matchesUnitTarget(target, def.targets, game)) return;
  const current = caster.order.type === "charge" ? caster.order.resume : caster.order;
  const resume = current.type === "attackMove" ? { type: "attackMove", x: current.x, y: current.y, targetId: target.id } : current.type === "attack" && current.leashX !== void 0 && current.leashY !== void 0 ? { type: "attack", targetId: target.id, leashX: current.leashX, leashY: current.leashY } : current.type === "idle" && !commanded ? { type: "attack", targetId: target.id, leashX: caster.x, leashY: caster.y } : { type: "attack", targetId: target.id };
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  caster.order = { type: "charge", targetId: target.id, resume };
  if (commanded) caster.orderQueue = [];
  const meeting = Math.max(0, distance(caster, target) - caster.radius - target.radius);
  shove(caster, target.x - caster.x, target.y - caster.y, meeting + def.drive);
  const expected = Math.max(1, Math.ceil((distance(caster, target) - caster.attackRange) / MAX_SLIDE_STEP));
  addEffect(game, def.effectType, caster.x, caster.y, expected, { fromX: caster.x, fromY: caster.y, toX: target.x, toY: target.y, owner: caster.owner, sourceKind: caster.kind, unitId: caster.id });
}
function updateChargeOrder(game, unit) {
  const order = unit.order;
  if (order.type !== "charge") return;
  const ability = UNIT_DEFS[unit.kind].abilities.find((candidate) => ABILITY_DEFS[candidate].behavior === "charge");
  const def = ability ? ABILITY_DEFS[ability] : void 0;
  const target = findTarget(game, order.targetId);
  if (!def || def.behavior !== "charge" || !target || !isUnit(target) || target.hp <= 0) {
    endCharge(unit, order.resume);
    return;
  }
  if (distance(unit, target) <= unit.attackRange) {
    const damage = Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit) * def.damageMultiplier));
    applyAttackDamage(game, unit, target, damage, unit.attackRange);
    addEffect(game, "chargeImpact", target.x, target.y, CHARGE_IMPACT_TICKS, { fromX: unit.x, fromY: unit.y, toX: target.x, toY: target.y, owner: unit.owner, sourceKind: unit.kind, unitId: unit.id, sourceId: unit.id, actionMode: "attack", fromHeight: combatVisualHeight(game, unit), toHeight: combatVisualHeight(game, target) });
    unit.cooldown = unit.attackCooldown;
    endCharge(unit, order.resume);
    return;
  }
  if (unit.pushX === void 0) endCharge(unit, order.resume);
}
function endCharge(unit, resume) {
  const next = unit.orderQueue?.shift();
  unit.order = next ?? resume;
}
var AUTOCAST_EVERY_TICKS = 2;
var AUTOCAST_ORDERS = /* @__PURE__ */ new Set(["idle", "attack", "attackMove", "hold", "aim"]);
var SUMMON_ALERT_MARGIN = 100;
var SUMMON_COMPANY_RANGE = 320;
var SUMMON_STEP = 60;
var CHARGE_IMPACT_TICKS = 12;
function autocastStep(game, unit) {
  if (!AUTOCAST_ORDERS.has(unit.order.type)) return;
  for (const ability of unitAbilities(unit)) {
    if (abilityCooldown(unit, ability) > 0 || !autocastEnabled(unit, ability)) continue;
    const def = ABILITY_DEFS[ability];
    if (def.behavior === "veteran") {
      if (applyVeteranAbility(game, unit, def, true)) return;
    } else if (def.behavior === "heal") {
      const target = autocastHealTarget(game, unit, def);
      if (target) return applyHeal(game, unit, ability, target, def);
    } else if (def.behavior === "curse") {
      const target = autocastCurseTarget(game, unit, def);
      if (target) return applyCurse(game, unit, ability, target, def);
    } else if (def.behavior === "summon") {
      const point = autocastSummonPoint(game, unit, def);
      if (point && applySummon(game, unit, ability, point.x, point.y, def)) return;
    } else if (def.behavior === "stomp") {
      if (applyStomp(game, unit, ability, def)) return;
    } else if (def.behavior === "bloodlust") {
      if (applyBloodlust(game, unit, ability, def)) return;
    } else if (def.behavior === "web") {
      if (applyWeb(game, unit, ability, def)) return;
    } else if (def.behavior === "charge" && unit.order.type !== "hold") {
      const target = autocastChargeTarget(game, unit, def);
      if (target) return startCharge(game, unit, ability, target, def, false);
    }
  }
}
function applyStomp(game, caster, ability, def) {
  const struck = [];
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (matchesUnitTarget(candidate, def.targets, game) && distance(caster, candidate) <= def.range && isAutocastFoe(game, caster, candidate)) struck.push(candidate);
  });
  if (struck.length === 0) return false;
  for (const unit of struck) setStatus(unit, { type: "stun", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "stomp", caster.x, caster.y, 24, { radius: def.range, owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, toX: caster.x, toY: caster.y });
  return true;
}
function applyBloodlust(game, caster, ability, def) {
  let best;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || distance(caster, candidate) > def.range || candidate.hp <= 0 || candidate.owner !== caster.owner || !isEngaged(candidate)) return;
    if (candidate.effects.some((effect) => effect.type === "bloodlust")) return;
    if (!best || candidate.attackDamage > best.attackDamage) best = candidate;
  });
  if (!best) return false;
  setStatus(best, { type: "bloodlust", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "bloodlust", best.x, best.y, 30, { owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: best.x, toY: best.y, toHeight: combatVisualHeight(game, best) });
  return true;
}
function applyWeb(game, caster, ability, def) {
  let best;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || distance(caster, candidate) > def.range || !isAutocastFoe(game, caster, candidate) || candidate.effects.some((effect) => effect.type === "root")) return;
    if (!best || distance(caster, candidate) < distance(caster, best)) best = candidate;
  });
  if (!best) return false;
  setStatus(best, { type: "root", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "web", best.x, best.y, def.effectDuration, { owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: best.x, toY: best.y, toHeight: combatVisualHeight(game, best) });
  return true;
}
function setStatus(unit, status) {
  unit.effects = unit.effects.filter((effect) => effect.type !== status.type);
  unit.effects.push(status);
}
function statusPace(unit) {
  if (unit.effects.length === 0) return 1;
  let pace = 1;
  for (const effect of unit.effects) {
    if (effect.type === "root" || effect.type === "stun") return 0;
    if (effect.type === "slow") pace = SLOW_PACE;
  }
  return pace;
}
function attackCooldownOf(game, unit, baseCooldown = unit.attackCooldown) {
  const speed = (game.veteranFrame?.get(unit.id)?.attackSpeedMultiplier ?? 1) * temporaryAttackSpeedMultiplier(unit);
  return speed === 1 ? baseCooldown : Math.max(1, Math.round(baseCooldown / speed));
}
function isEngaged(unit) {
  return unit.order.type === "attack" || unit.order.type === "charge" || unit.order.type === "attackMove" && unit.order.targetId !== void 0;
}
function isAutocastFoe(game, caster, candidate) {
  return candidate.hp > 0 && areEnemyOwners(game, caster.owner, candidate.owner) && (candidate.owner !== "neutral" || isEngaged(candidate));
}
function autocastHealTarget(game, caster, def) {
  let best;
  let bestMissing = def.healAmount / 2;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !canReceiveHealing(candidate, game) || candidate.hp <= 0 || areEnemyOwners(game, caster.owner, candidate.owner) || distance(caster, candidate) > def.range) return;
    const missing = candidate.maxHp - candidate.hp;
    if (missing < bestMissing || missing === bestMissing && best) return;
    best = candidate;
    bestMissing = missing;
  });
  return best;
}
function autocastCurseTarget(game, caster, def) {
  const casterFights = isEngaged(caster);
  const own = caster.order.type === "attack" || caster.order.type === "attackMove" ? caster.order.targetId : void 0;
  let best;
  let bestScore = Number.NEGATIVE_INFINITY;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !isAutocastFoe(game, caster, candidate) || distance(caster, candidate) > def.range) return;
    if (!casterFights && !isEngaged(candidate)) return;
    if (candidate.effects.some((effect) => effect.type === def.statusType)) return;
    const score = (def.summonedDamage && candidate.expiresTick !== void 0 ? 2e3 : 0) + (candidate.id === own ? 1e3 : 0) - distance(caster, candidate);
    if (score <= bestScore) return;
    best = candidate;
    bestScore = score;
  });
  return best;
}
function autocastSummonPoint(game, caster, def) {
  let foe;
  forEachNearbyUnit(game, caster, def.range + SUMMON_ALERT_MARGIN, (candidate) => {
    if (!isAutocastFoe(game, caster, candidate) || distance(caster, candidate) > def.range + SUMMON_ALERT_MARGIN) return;
    if (!foe || distance(caster, candidate) < distance(caster, foe)) foe = candidate;
  });
  if (!foe) return void 0;
  let company = false;
  forEachNearbyUnit(game, caster, SUMMON_COMPANY_RANGE, (candidate) => {
    if (candidate.owner === caster.owner && candidate.kind === def.summonKind && distance(caster, candidate) <= SUMMON_COMPANY_RANGE) company = true;
  });
  if (company) return void 0;
  const gap = distance(caster, foe);
  const step = Math.min(SUMMON_STEP, gap);
  return gap > 0 ? { x: caster.x + (foe.x - caster.x) / gap * step, y: caster.y + (foe.y - caster.y) / gap * step } : { x: caster.x, y: caster.y };
}
function autocastChargeTarget(game, rider, def) {
  const order = rider.order;
  const own = order.type === "attack" || order.type === "attackMove" ? order.targetId : void 0;
  if (own) {
    const target = findTarget(game, own);
    return target && isUnit(target) && matchesUnitTarget(target, def.targets, game) && isAutocastFoe(game, rider, target) && inChargeWindow(rider, target, def) && canReach(game.map, rider, target, game.units) ? target : void 0;
  }
  if (order.type !== "idle" && order.type !== "attackMove") return void 0;
  let charged;
  let free;
  let any;
  forEachNearbyUnit(game, rider, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !isAutocastFoe(game, rider, candidate) || !inChargeWindow(rider, candidate, def) || !canReach(game.map, rider, candidate, game.units)) return;
    charged ??= new Set(game.units.flatMap((unit) => unit.owner === rider.owner && unit.order.type === "charge" ? [unit.order.targetId] : []));
    if (!any || distance(rider, candidate) < distance(rider, any)) any = candidate;
    if (!charged.has(candidate.id) && (!free || distance(rider, candidate) < distance(rider, free))) free = candidate;
  });
  return free ?? any;
}
function outgoingDamageMultiplier(game, unit) {
  const cursed = unit.effects.reduce((multiplier, effect) => Math.min(multiplier, effect.damageMultiplier ?? (effect.type === "curse" ? 0.4 : 1)), 1);
  return (unit.stance === "brace" ? cursed * BRACE_DAMAGE_SHARE : cursed) * passengerDamageMultiplier(game, unit);
}
function carriedItem(game, unit, itemId) {
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item) throw new Error(`Unknown item ${itemId}`);
  if (item.carrierId !== unit.id) throw new Error(`${unit.id} is not carrying ${item.id}`);
  return item;
}
function carrierFor(game, item) {
  return item.carrierId ? game.units.find((unit) => unit.id === item.carrierId) : void 0;
}
function activateNeutralItem(game, carrier, item) {
  if (item.kind === "guardianScroll" || item.kind === "experienceBook" || item.kind === "breachCharge" || isShopOnlyItem(item.kind) || item.cooldownRemaining > 0) return;
  const target = nearestEnemyInRange(game, carrier, item.kind === "stormStaff" ? NEUTRAL_STORM_TARGET_RANGE : NEUTRAL_ITEM_TARGET_RANGE);
  if (!target) return;
  activateItem(game, carrier, item, target.id, target.x, target.y);
}
function activateItem(game, carrier, item, targetId, x, y) {
  if (item.cooldownRemaining > 0) return;
  if (item.kind === "lightningRod") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, carrier.owner, unit.owner)) : void 0;
    if (!target || distance(carrier, target) > LIGHTNING_ROD.range) return;
    applyChainLightning(game, carrier, item, target);
    return;
  }
  if (item.kind === "stormStaff") {
    const point = targetId ? game.units.find((unit) => unit.id === targetId) : isNumber(x) && isNumber(y) ? { x, y } : void 0;
    if (!point || distance(carrier, point) > STORM_STAFF.range) return;
    applyStormStaff(game, carrier, item, point.x, point.y);
    return;
  }
  if (item.kind === "guardianScroll") {
    if (carrier.owner === "neutral") return;
    forEachNearbyUnit(game, carrier, GUARDIAN_SCROLL.radius, (unit) => {
      if (distance(unit, carrier) > GUARDIAN_SCROLL.radius || areEnemyOwners(game, carrier.owner, unit.owner)) return;
      unit.effects = unit.effects.filter((effect) => effect.type !== "guardian");
      unit.effects.push({ type: "guardian", remaining: GUARDIAN_SCROLL.duration });
    });
    addEffect(game, "guardianField", carrier.x, carrier.y, GUARDIAN_SCROLL.duration, { radius: GUARDIAN_SCROLL.radius, sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: carrier.x, toY: carrier.y });
    consumeItem(game, item);
    return;
  }
  if (item.kind === "breachCharge") {
    if (carrier.owner === "neutral") return;
    const target = targetId ? game.buildings.find((building) => building.id === targetId && areEnemyOwners(game, carrier.owner, building.owner)) : void 0;
    if (!target || distance(carrier, target) > BREACH_CHARGE.range) return;
    applyAttackDamage(game, carrier, target, BREACH_CHARGE.damage, BREACH_CHARGE.range, ITEM_DAMAGE_PROFILES.breachCharge);
    consumeItem(game, item);
    return;
  }
  if (item.kind === "experienceBook") {
    if (carrier.owner === "neutral") return;
    carrier.xp += EXPERIENCE_BOOK_XP;
    applyXpLevel(game, carrier);
    addEffect(game, "experienceBurst", carrier.x, carrier.y, 48);
    consumeItem(game, item);
    return;
  }
  if (item.kind === "healingScroll") {
    if (carrier.owner === "neutral") return;
    forEachNearbyUnit(game, carrier, HEALING_SCROLL_RADIUS, (unit) => {
      if (!canReceiveHealing(unit, game) || distance(unit, carrier) > HEALING_SCROLL_RADIUS || areEnemyOwners(game, carrier.owner, unit.owner)) return;
      unit.hp = Math.min(unit.maxHp, unit.hp + HEALING_SCROLL_HEAL);
    });
    addEffect(game, "heal", carrier.x, carrier.y, 30, { radius: HEALING_SCROLL_RADIUS, sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: carrier.x, toY: carrier.y });
    consumeItem(game, item);
    return;
  }
  if (item.kind === "ivoryTower") {
    if (!isPlayerId(carrier.owner) || !isNumber(x) || !isNumber(y)) return;
    if (Math.hypot(x - carrier.x, y - carrier.y) > IVORY_TOWER_REACH) return;
    if (terrainBlocksPlacement(game.map, "defenseTower", { x, y }) || buildingPlacementBlocker(game, "defenseTower", { x, y })) return;
    const at = snapToFootprint(game.map, BUILDING_DEFS.defenseTower.radius, { x, y });
    const tower = createBuilding(`building-${carrier.owner}-defenseTower-${game.nextId}`, carrier.owner, "defenseTower", at.x, at.y, true);
    game.nextId += 1;
    tower.hp = Math.round(tower.maxHp * IVORY_TOWER_HP_SHARE);
    game.buildings.push(tower);
    addEffect(game, "summon", at.x, at.y, 34, { sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: at.x, toY: at.y });
    consumeItem(game, item);
  }
}
function isShopOnlyItem(kind) {
  return kind === "speedBoots" || kind === "regenRing" || kind === "healingScroll" || kind === "ivoryTower";
}
function consumeItem(game, item) {
  const unit = carrierFor(game, item);
  if (unit) removeFromHands(unit, item.id);
  game.items = game.items.filter((candidate) => candidate.id !== item.id);
  if (unit) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function applyChainLightning(game, carrier, item, firstTarget) {
  const struck = /* @__PURE__ */ new Set();
  let current = firstTarget;
  let damage = LIGHTNING_ROD.damage;
  for (let bounce = 0; bounce < LIGHTNING_ROD.hits; bounce += 1) {
    struck.add(current.id);
    applyAttackDamage(game, carrier, current, damage * outgoingDamageMultiplier(game, carrier), 240, ITEM_DAMAGE_PROFILES.lightningRod);
    addEffect(game, "chainLightning", current.x, current.y, 28, { fromX: carrier.x, fromY: carrier.y, toX: current.x, toY: current.y });
    const next = nearestChainTarget(game, carrier, current, struck, LIGHTNING_ROD.bounceRange);
    if (!next) break;
    current = next;
    damage = Math.max(LIGHTNING_ROD.minimumDamage, Math.round(damage * LIGHTNING_ROD.decay));
  }
  item.cooldownRemaining = LIGHTNING_ROD.cooldown;
}
function nearestChainTarget(game, carrier, from, struck, range) {
  const limit = range * range;
  let best;
  let bestDistance = Number.POSITIVE_INFINITY;
  forEachNearbyUnit(game, from, range, (candidate) => {
    if (struck.has(candidate.id) || !areEnemyOwners(game, carrier.owner, candidate.owner)) return;
    const candidateDistance = distanceSquared(from, candidate);
    if (candidateDistance > limit || candidateDistance >= bestDistance) return;
    best = candidate;
    bestDistance = candidateDistance;
  });
  return best;
}
function applyStormStaff(game, carrier, item, x, y) {
  forEachNearbyUnit(game, { x, y }, STORM_STAFF.radius, (target) => {
    if (distance(target, { x, y }) > STORM_STAFF.radius || !areEnemyOwners(game, carrier.owner, target.owner)) return;
    applyAttackDamage(game, carrier, target, STORM_STAFF.impactDamage * outgoingDamageMultiplier(game, carrier), STORM_STAFF.range, ITEM_DAMAGE_PROFILES.stormStaff);
  });
  addEffect(game, "storm", x, y, STORM_STAFF.duration, { sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: x, toY: y, owner: carrier.owner, unitId: carrier.id, damage: STORM_STAFF.pulseDamage * outgoingDamageMultiplier(game, carrier), damageProfile: { ...ITEM_DAMAGE_PROFILES.stormStaff }, radius: STORM_STAFF.radius, tickEvery: STORM_STAFF.pulseEvery });
  item.cooldownRemaining = STORM_STAFF.cooldown;
}
function applyFlameCloak(game, carrier, item) {
  if (item.cooldownRemaining > 0) return;
  let burned = false;
  forEachNearbyUnit(game, carrier, FLAME_CLOAK.radius, (target) => {
    if (distance(target, carrier) > FLAME_CLOAK.radius || !areEnemyOwners(game, carrier.owner, target.owner)) return;
    applyAttackDamage(game, carrier, target, FLAME_CLOAK.damage * outgoingDamageMultiplier(game, carrier), 70, ITEM_DAMAGE_PROFILES.flameCloak);
    addEffect(game, "flameBurn", target.x, target.y, FLAME_CLOAK_VISUAL_DURATION);
    burned = true;
  });
  if (!burned) return;
  item.cooldownRemaining = FLAME_CLOAK.interval;
}
function updateWorldEffects(game) {
  if (game.effects.length === 0) return;
  let expired = false;
  for (const effect of game.effects) {
    applyWorldEffectTick(game, effect);
    effect.remaining -= 1;
    expired ||= !(effect.remaining > 0);
  }
  if (expired) game.effects = game.effects.filter((effect) => effect.remaining > 0);
}
function applyWorldEffectTick(game, effect) {
  if (effect.type === "burningGround" && effect.owner && effect.damage && effect.radius && effect.tickEvery) {
    if (effect.remaining % effect.tickEvery !== 0) return;
    const source = effect.unitId ? findTarget(game, effect.unitId) : void 0;
    const attacker = source ?? scriptSource({ id: effect.unitId ?? effect.id, owner: effect.owner, x: effect.x, y: effect.y });
    for (const target of [...game.units, ...game.buildings]) if (target.hp > 0 && areEnemyOwners(game, effect.owner, target.owner) && distance(effect, target) <= effect.radius + target.radius) {
      if (effect.sourceKind === "sparkArcher" && isUnit(target) && (target.deck || unitMover(target.kind) !== "land")) continue;
      const taken = applyDamage(game, attacker, target, effect.damage, void 0, void 0, 0, effect.damageProfile ?? DAMAGE_PROFILES.BURNING);
      if (taken !== void 0) addHitEffect(game, target, taken, source);
      if (taken !== void 0 && effect.sourceKind === "sparkArcher" && isUnit(target)) setStatus(target, { type: "scorch", remaining: SCORCH_DURATION });
    }
    return;
  }
  if (effect.type !== "storm" || !effect.owner || !effect.damage || !effect.radius || !effect.tickEvery) return;
  if (effect.remaining !== effect.duration && effect.remaining % effect.tickEvery !== 0) return;
  forEachNearbyUnit(game, effect, effect.radius, (target) => {
    if (distance(target, effect) > effect.radius || !areEnemyOwners(game, effect.owner, target.owner)) return;
    applyAttackDamage(game, scriptSource({ id: effect.unitId ?? effect.id, owner: effect.owner, x: effect.x, y: effect.y }), target, effect.damage, 260, effect.damageProfile ?? DAMAGE_PROFILES.STORM);
  });
}
function updateProjectiles(game) {
  if (game.projectiles.length === 0) return;
  const projectiles = game.projectiles;
  let pending;
  for (let index = 0; index < projectiles.length; index++) {
    const projectile = projectiles[index];
    projectile.remaining -= 1;
    if (projectile.remaining > 0) {
      pending?.push(projectile);
      continue;
    }
    pending ??= projectiles.slice(0, index);
    applyProjectileImpact(game, projectile);
  }
  if (pending) game.projectiles = pending;
}
function applyProjectileImpact(game, projectile) {
  withDeckDamageBatch(game, () => {
    if (projectile.weapon) {
      impactWeapon(game, projectile);
      return;
    }
    const target = findStrikeTarget(game, projectile.targetId);
    if (!target || target.hp <= 0 || !areEnemyOwners(game, projectile.owner, target.owner)) return;
    const liveShooter = findTarget(game, projectile.attackerId);
    const shooter = liveShooter?.owner === projectile.owner ? liveShooter : void 0;
    const attacker = shooter ?? projectileAttacker(projectile);
    const taken = applyDamage(game, attacker, target, attackDamageAgainstTarget(game, attacker, target, projectile.damage), projectile.hullDamageShare, void 0, 0, projectile.damageProfile ?? attackDamageProfile(projectile.sourceKind ?? "defenseTower"), projectile.armorAlreadyApplied);
    if (taken === void 0) return;
    applyAttackStatusEffects(game, attacker, target, projectile.sourceKind);
    addHitEffect(game, target, taken, shooter, projectile.attackKind, { x: projectile.fromX, y: projectile.fromY });
  });
}
function projectileAttacker(projectile) {
  return {
    id: projectile.attackerId,
    owner: projectile.owner,
    kind: "defenseTower",
    x: projectile.fromX,
    y: projectile.fromY,
    hp: 1,
    maxHp: 1,
    radius: 0,
    complete: true,
    buildProgress: 0,
    buildTime: 0,
    attackDamage: 0,
    attackRange: 0,
    attackCooldown: 0,
    cooldown: 0,
    rallyX: projectile.fromX,
    rallyY: projectile.fromY,
    queue: [],
    researchQueue: []
  };
}
function updateUnitStatusEffects(game) {
  for (const unit of game.units) {
    if (unit.effects.length === 0) continue;
    let expired = false;
    for (const effect of unit.effects) {
      effect.remaining -= 1;
      expired ||= !(effect.remaining > 0);
    }
    for (const effect of unit.effects) {
      if (effect.type === "poison" && effect.remaining % 20 === 0 && unit.hp > 0) {
        const source = effect.sourceId ? findTarget(game, effect.sourceId) : void 0;
        const attacker = source && source.hp > 0 ? source : scriptSource({ id: effect.sourceId ?? "poison", owner: effect.sourceOwner ?? "neutral", x: unit.x, y: unit.y });
        applyDamage(game, attacker, unit, POISON_DAMAGE, void 0, void 0, 0, DAMAGE_PROFILES.POISON, false, true);
      }
    }
    if (expired) unit.effects = unit.effects.filter((effect) => effect.remaining > 0);
  }
}
function applyWeaponAbility(game, caster, ability, at, def, targetId) {
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  const mounted = ability === "incendiaryFlume" ? installedWeapons(game, caster).find((item) => item.kind === "flameProjector" && (item.durability ?? 1) > 0 && shipGunCanAim(caster, item, at)) : void 0;
  fireWeapon(game, caster, at, def.damage * outgoingDamageMultiplier(game, caster), def.weapon, def.range, { ...def.rootTicks ? { rootTicks: def.rootTicks } : {}, ...def.burnTicks ? { burnTicks: def.burnTicks } : {} }, targetId, mounted ? { item: mounted, pose: mountedWeaponPose(caster, mounted) } : void 0, "cast");
}
function __observed_backOutOfDeadZone(game, unit, target, navalFrame = true) {
  let minimum = weaponRules(game, unit).weapon?.minRange;
  if (navalFrame && isShipKind(unit.kind)) {
    const weapons = installedWeapons(game, unit).filter((item) => (item.durability ?? 1) > 0);
    if (weapons.length) minimum = Math.min(...weapons.map((item) => SHIP_WEAPONS[item.kind].weapon.minRange ?? 0));
  }
  if (!minimum || distance(unit, target) >= minimum) return false;
  const dx = unit.x - target.x, dy = unit.y - target.y, length = Math.hypot(dx, dy) || 1;
  moveToward(unit, unit.x + (dx || 1) / length * (minimum + 32), unit.y + dy / length * (minimum + 32), game.map, game.units);
  return true;
}
function weaponOrigin(attacker) {
  const pose = isUnit(attacker) && shipWeaponPose(attacker);
  return pose ? pose.muzzle : { x: attacker.x, y: attacker.y };
}
function combatVisualHeight(game, entity) {
  const unit = "order" in entity ? entity : "kind" in entity ? void 0 : entity.id && game.units.find((unit2) => unit2.id === entity.id);
  if (!unit) return 0;
  const hull = unit.deck && game.units.find((ship) => ship.id === unit.deck.shipId);
  return hull ? (shipProfile(hull)?.deckHeight ?? 0) + 18 : shipProfile(unit)?.deckHeight ?? 0;
}
function fireWeapon(game, attacker, at, damage, weapon, range, skill = {}, targetId = at.id, mounted, actionMode = "attack") {
  const origin = mounted?.pose.muzzle ?? weaponOrigin(attacker);
  const damageProfile = weaponDamageProfile(weapon);
  const target = targetId ? findStrikeTarget(game, targetId) : void 0;
  const point = mounted?.aimPoint ?? (target ? strikePoint(origin, target) : at);
  const fromHeight = mounted?.pose.height || isUnit(attacker) && shipWeaponPose(attacker)?.height || combatVisualHeight(game, attacker);
  const attackKind = weapon.presentation ?? (weapon.delivery === "cone" ? "grapeshot" : weapon.delivery === "shell" ? "stone" : "bolt");
  const visuals = { actionMode, sourceId: attacker.id, attackKind, fromX: origin.x, fromY: origin.y, fromHeight, toX: point.x, toY: point.y, toHeight: combatVisualHeight(game, at), owner: attacker.owner, sourceKind: attacker.kind, unitId: attacker.id, ...mounted ? { itemId: mounted.item.id } : {} };
  if ((attackKind === "cannon" || attackKind === "mortar" || attackKind === "grapeshot") && (mounted || isUnit(attacker))) addEffect(game, "muzzleFlash", origin.x, origin.y, seconds(0.65), visuals);
  if (weapon.delivery === "ram") {
    const target2 = targetId ? findStrikeTarget(game, targetId) : void 0;
    if (target2 && areEnemyOwners(game, attacker.owner, target2.owner)) hitWeapon(game, attacker, target2, damage, weapon);
    addEffect(game, "siegeImpact", at.x, at.y, 18, { fromX: origin.x, fromY: origin.y, toX: point.x, toY: point.y, owner: attacker.owner, sourceKind: attacker.kind, sourceId: attacker.id, actionMode });
    return;
  }
  if (weapon.delivery === "cone") {
    const hits = [...game.units, ...game.buildings].filter((target2) => target2.hp > 0 && (!isUnit(target2) || !isInCabin(target2)) && areEnemyOwners(game, attacker.owner, target2.owner) && inWeaponCone(origin, point, target2, range, weapon.coneAngle ?? 0.6));
    withDeckDamageBatch(game, () => {
      for (const target2 of crewBeforeHulls(hits)) hitWeapon(game, attacker, target2, damage * (weapon.burst ?? 1), weapon);
    });
    addEffect(game, "grapeshot", point.x, point.y, seconds(0.7), { ...visuals, radius: range });
    return;
  }
  const flight = Math.max(seconds(0.2), Math.ceil(distance(origin, point) / perTick(weapon.delivery === "shell" ? 240 : 560)));
  const projectile = { id: `projectile-${game.nextId++}`, owner: attacker.owner, attackerId: attacker.id, targetId: targetId ?? "", fromX: origin.x, fromY: origin.y, toX: point.x, toY: point.y, damage, damageProfile: { ...damageProfile }, remaining: flight, duration: flight, attackKind, weapon: { ...weapon }, ...isUnit(attacker) ? { sourceKind: attacker.kind } : {}, ...skill };
  game.projectiles.push(projectile);
  addEffect(game, weapon.delivery === "shell" ? "shellFlight" : "siegeBolt", point.x, point.y, flight, { ...visuals, radius: weapon.radius ?? 0 });
}
function hitWeapon(game, attacker, target, damage, weapon, share = 1, rootTicks, impact = strikePoint(attacker, target), profile = weaponDamageProfile(weapon), visualOrigin) {
  const dealt = weaponDamage(weapon, damage, !isUnit(target), isUnit(target) && unitMover(target.kind) === "sea", share);
  const taken = applyDamage(game, attacker, target, dealt, deckHullDamageShare(game, attacker, weapon), impact, weapon.blastRadius ?? weapon.radius ?? 0, profile);
  if (taken === void 0) return;
  addHitEffect(game, target, taken, attacker, weapon.presentation, visualOrigin);
  if (rootTicks && isUnit(target) && target.hp > 0) setStatus(target, { type: "root", remaining: rootTicks });
}
function impactWeapon(game, projectile) {
  const weapon = projectile.weapon;
  const liveSource = findTarget(game, projectile.attackerId);
  const source = liveSource?.owner === projectile.owner ? liveSource : void 0;
  const fallback = projectileAttacker(projectile);
  const attacker = source ?? (projectile.sourceKind ? { ...fallback, kind: projectile.sourceKind, order: { type: "idle" }, effects: [], xp: 0, level: 0, kills: 0, abilityCooldown: 0, speed: 0 } : fallback);
  const from = { x: projectile.fromX, y: projectile.fromY }, to = { x: projectile.toX, y: projectile.toY };
  const flightLength = distance(from, to), impactAt = (along) => {
    const share = flightLength ? Math.max(0, Math.min(1, along / flightLength)) : 0;
    return { x: from.x + (to.x - from.x) * share, y: from.y + (to.y - from.y) * share };
  };
  const foes = [...game.units, ...game.buildings, ...game.obstacles ?? []].filter((t) => t.hp > 0 && (!isUnit(t) || !isInCabin(t)) && areEnemyOwners(game, projectile.owner, t.owner));
  if (weapon.delivery === "bolt") {
    const intersections = foes.map((target) => ({ target, along: boltIntersection(from, to, target, weapon.radius ?? 12) })).filter((h) => h.along !== void 0).sort((a, b) => a.along - b.along);
    const eligible = new Set(crewBeforeHulls(intersections.map((hit) => hit.target)));
    const hits = intersections.filter((hit) => eligible.has(hit.target)).slice(0, weapon.maxHits ?? 1);
    if (weapon.blastRadius && hits[0]) {
      const impact = impactAt(hits[0].along);
      for (const target of crewBeforeHulls(foes.filter((target2) => bodyGap(impact, target2) <= weapon.blastRadius))) {
        const share = Math.max(0.4, 1 - bodyGap(impact, target) / weapon.blastRadius * 0.6);
        hitWeapon(game, attacker, target, projectile.damage, weapon, share, projectile.rootTicks, impact, projectile.damageProfile, from);
      }
      addEffect(game, "siegeImpact", impact.x, impact.y, seconds(0.65), { radius: weapon.blastRadius, owner: projectile.owner, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
      return;
    }
    hits.forEach(({ target, along }, i) => hitWeapon(game, attacker, target, projectile.damage, weapon, (weapon.pierceShare ?? 1) ** i, projectile.rootTicks, impactAt(along), projectile.damageProfile, from));
  } else {
    for (const target of crewBeforeHulls(foes.filter((target2) => bodyGap(to, target2) <= (weapon.radius ?? 0)))) {
      const gap = bodyGap(to, target);
      const falloff = Math.max(0.35, 1 - gap / Math.max(1, weapon.radius ?? 1) * 0.65);
      hitWeapon(game, attacker, target, projectile.damage, weapon, falloff, projectile.rootTicks, to, projectile.damageProfile, from);
    }
    addEffect(game, "siegeImpact", to.x, to.y, 24, { radius: weapon.radius ?? 0, owner: projectile.owner, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
    if (projectile.burnTicks) addEffect(game, "burningGround", to.x, to.y, projectile.burnTicks, { owner: projectile.owner, unitId: projectile.attackerId, damage: 3, damageProfile: { ...DAMAGE_PROFILES.BURNING }, radius: weapon.radius ?? 0, tickEvery: 10, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
  }
}
function applyWeaponAttack(game, attacker, target, damage, attackRange) {
  if (!isObstacle(target)) target = navalCombatTarget(game, attacker, target);
  if (isUnit(attacker) && shipProfile(attacker) && !unitRules(game, attacker).intrinsicAttack) return;
  const weapon = isUnit(attacker) ? weaponRules(game, attacker).weapon : void 0;
  if (weapon) {
    if (weapon.minRange && distance(attacker, target) < weapon.minRange) return;
    fireWeapon(game, attacker, target, damage, weapon, attackRange);
    return;
  }
  const baseRange = isUnit(attacker) ? weaponRules(game, attacker).attackRange : attackRange;
  if (baseRange > RANGED_ATTACK_RANGE_THRESHOLD) {
    launchProjectile(game, attacker, target, buildingTargetDamage(attacker, target, damage));
    return;
  }
  applyAttackDamage(game, attacker, target, damage, baseRange);
}
function launchProjectile(game, attacker, target, damage) {
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  const flight = Math.max(1, Math.ceil(Math.sqrt(dx * dx + dy * dy) / perTick(PROJECTILE_SPEED)));
  const projectile = {
    attackKind: innateMissile(attacker.kind),
    damageProfile: { ...isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind) },
    id: `projectile-${game.nextId}`,
    owner: attacker.owner,
    attackerId: attacker.id,
    targetId: target.id,
    fromX: attacker.x,
    fromY: attacker.y,
    toX: target.x,
    toY: target.y,
    damage,
    remaining: flight,
    duration: flight,
    ...isUnit(attacker) ? { sourceKind: attacker.kind } : {},
    hullDamageShare: deckHullDamageShare(game, attacker)
  };
  game.nextId += 1;
  game.projectiles.push(projectile);
  addEffect(game, "projectile", target.x, target.y, flight, {
    sourceId: attacker.id,
    owner: attacker.owner,
    actionMode: "attack",
    fromX: projectile.fromX,
    fromY: projectile.fromY,
    toX: projectile.toX,
    toY: projectile.toY,
    sourceKind: attacker.kind,
    attackKind: projectile.attackKind,
    fromHeight: combatVisualHeight(game, attacker),
    toHeight: combatVisualHeight(game, target)
  });
}
function applyAttackDamage(game, attacker, target, damage, attackRange, profile) {
  profile ??= isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind);
  const dealt = profile.origin === "spell" ? damage : attackDamageAgainstTarget(game, attacker, target, buildingTargetDamage(attacker, target, damage));
  const taken = applyDamage(game, attacker, target, dealt, void 0, void 0, 0, profile);
  if (taken === void 0) return;
  if (profile.origin !== "spell") applyAttackStatusEffects(game, attacker, target, attacker.kind);
  if (profile.delivery === "melee" && profile.origin !== "spell" && isUnit(attacker) && isUnit(target)) stanceBlow(attacker, target, dealt);
  const from = { x: attacker.x, y: attacker.y };
  const to = { x: target.x, y: target.y };
  const kind = attackRange > RANGED_ATTACK_RANGE_THRESHOLD ? "projectile" : "melee";
  addEffect(game, kind, to.x, to.y, kind === "projectile" ? 22 : 16, { fromX: from.x, fromY: from.y, toX: to.x, toY: to.y, fromHeight: combatVisualHeight(game, attacker), toHeight: combatVisualHeight(game, target), ...isUnit(attacker) ? { sourceId: attacker.id, actionMode: profile.origin === "spell" ? "cast" : "attack" } : {} });
  addHitEffect(game, target, taken, attacker);
}
function addHitEffect(game, target, taken, striker, attackKind, visualOrigin) {
  attackKind ??= striker ? isUnit(striker) && weaponRules(game, striker).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD ? "melee" : innateMissile(striker.kind) : void 0;
  const origin = visualOrigin ?? striker;
  const deck = isUnit(target) && target.deck;
  const hull = deck ? game.units.find((unit) => unit.id === deck.shipId) : void 0;
  addEffect(game, "hit", target.x, target.y, 14, { unitId: target.id, damage: taken, ...attackKind ? { attackKind } : {}, ...striker ? { sourceKind: striker.kind } : {}, ...origin ? { fromX: origin.x, fromY: origin.y } : {}, ...deck && hull ? { targetDeck: { ...deck, heading: hull.sailing?.heading ?? 0 }, toHeight: combatVisualHeight(game, target) } : {}, ...isUnit(target) ? { targetKind: target.kind, targetHpAfter: target.hp, targetMaxHp: target.maxHp, targetRadius: target.radius, targetUnitClass: unitClassOf(target, game) } : {} });
}
function buildingTargetDamage(attacker, target, damage) {
  if (isUnit(attacker) || !isUnit(target) || target.owner !== "neutral") return damage;
  return damage * (BUILDING_DEFS[attacker.kind]?.neutralDamageMultiplier ?? 1);
}
function attackDamageAgainstTarget(game, attacker, target, damage) {
  if (!isUnit(attacker) || !isUnit(target)) return damage;
  const slayer = unitRules(game, attacker).casterSlayer;
  const dealt = slayer && isCasterOrSummoned(target) ? Math.round(damage * slayer) : damage;
  if (!target.effects.some((effect) => effect.type === "scorch")) return dealt;
  if (attacker.kind === "emberRavager") return dealt + 7;
  if (attacker.kind === "cinderRunner") return dealt + 5;
  return dealt;
}
function stanceBlow(attacker, target, dealt) {
  if (!attacker.stance || target.hp <= 0) return;
  const strength = blowStrength(dealt, target);
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  shove(target, dx, dy, strength);
  if (attacker.stance === "shock") shove(attacker, dx, dy, lungeStrength(attacker, strength));
}
function isCasterOrSummoned(unit) {
  return unit.expiresTick !== void 0 || hasSpell(unit.kind);
}
function applyAttackStatusEffects(game, attacker, target, sourceKind) {
  if (sourceKind === "sparkArcher" && isUnit(target) && !target.deck && unitMover(target.kind) === "land" && sparkIgnites(attacker.id, target.id, game.tick)) {
    addEffect(game, "burningGround", target.x, target.y, SPARK_FIRE.duration, {
      owner: attacker.owner,
      unitId: attacker.id,
      sourceKind,
      damageProfile: DAMAGE_PROFILES.BURNING,
      damage: SPARK_FIRE.damage,
      radius: SPARK_FIRE.radius,
      tickEvery: SPARK_FIRE.tickEvery
    });
  }
  if (!isUnit(attacker)) return;
  const rules = unitRules(game, attacker);
  if (rules.splash) {
    const share = Math.max(1, Math.round(attacker.attackDamage * SPLASH_SHARE));
    const burned = [];
    forEachNearbyUnit(game, target, SPLASH_RADIUS, (unit) => {
      if (unit !== target && unit.hp > 0 && distance(unit, target) <= SPLASH_RADIUS && areEnemyOwners(game, attacker.owner, unit.owner)) burned.push(unit);
    });
    for (const unit of burned) applyDamage(game, attacker, unit, share, void 0, void 0, 0, unitAttackDamageProfile(game, attacker));
    addEffect(game, "flameBurn", target.x, target.y, 20);
  }
  if (!isUnit(target)) return;
  if (rules.slowOnHit) setStatus(target, { type: "slow", remaining: SLOW_TICKS });
  if (rules.poisonOnHit) setStatus(target, { type: "poison", remaining: POISON_TICKS, sourceId: attacker.id, sourceOwner: attacker.owner });
}
function applyDamage(game, attacker, target, damage, hullShare, impact, blastRadius = 0, profile = isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind), armorAlreadyApplied = false, existingStatus = false) {
  if (isUnit(attacker) && isInCabin(attacker)) return void 0;
  if (isUnit(target) && isCabinProtected(game, target) && !existingStatus) return void 0;
  if ("invulnerable" in target && target.invulnerable) return void 0;
  if (isObstacle(target)) {
    const hpBefore2 = target.hp;
    target.hp -= damage;
    game.observer?.hit(attacker, target, damage, hpBefore2);
    return damage;
  }
  const impactDamage = damage;
  const resolved = isUnit(target) ? resolveUnitDamage(game, target, damage, profile, game.veteranFrame?.get(target.id)?.reductions, { armorAlreadyApplied }) : void 0;
  if (resolved?.blocked) return void 0;
  const taken = resolved?.damage ?? damage;
  const hpBefore = target.hp;
  target.hp -= taken;
  if (isUnit(target) && shipProfile(target)) {
    damageShipGangway(target, taken);
    damageShipParts(game, target, impact ?? strikePoint(attacker, target), taken, blastRadius);
    if (target.hp > 0) {
      applyDerivedUnitStats(game, target);
      updateCabinPassengers(game);
      for (const passenger of shipPassengers(game.units, target)) if (passenger.hp > 0 && isInCabin(passenger) && !isCabinProtected(game, passenger)) applyDamage(game, attacker, passenger, taken * 0.35, 0, impact, 0, profile);
    }
  }
  if (hpBefore > 0 && isUnit(target)) {
    if (shipProfile(target) && game.deckDamageBatch) {
      const entry = game.deckDamageBatch.get(target.id) ?? { ship: target, direct: 0, collateral: 0 };
      entry.direct += impactDamage;
      game.deckDamageBatch.set(target.id, entry);
    }
    const hull = target.deck && game.units.find((ship) => ship.id === target.deck.shipId && ship.hp > 0);
    if (hull && areEnemyOwners(game, attacker.owner, hull.owner)) {
      const collateral = impactDamage * (hullShare ?? deckHullDamageShare(game, attacker));
      if (game.deckDamageBatch) {
        const entry = game.deckDamageBatch.get(hull.id) ?? { ship: hull, direct: 0, collateral: 0, source: attacker };
        if (collateral > entry.collateral) {
          entry.collateral = collateral;
          entry.source = attacker;
          entry.profile = profile;
        }
        game.deckDamageBatch.set(hull.id, { ...entry, impact: { x: target.x, y: target.y }, blastRadius });
      } else if (collateral > 0) applyDamage(game, attacker, hull, collateral, 0, target, 0, profile);
    }
  }
  game.observer?.hit(attacker, target, taken, hpBefore);
  if (hpBefore > 0 && isUnit(target) && target.owner === "neutral") triggerNeutralAssist(game, target, attacker);
  if (hpBefore > 0 && isPlayerId(target.owner)) triggerPlayerAggro(game, target, attacker);
  if (hpBefore > 0 && target.hp <= 0) {
    recordKill(game, attacker, target);
  }
  return taken;
}
function withDeckDamageBatch(game, body) {
  if (game.deckDamageBatch) {
    body();
    return;
  }
  const batch = /* @__PURE__ */ new Map();
  game.deckDamageBatch = batch;
  try {
    body();
  } finally {
    delete game.deckDamageBatch;
  }
  for (const { ship, direct, collateral, source, impact, blastRadius, profile } of batch.values()) {
    if (source && ship.hp > 0 && collateral > direct) applyDamage(game, source, ship, collateral - direct, 0, impact, blastRadius, profile);
  }
}
function navalCombatTarget(game, attacker, target, crewRange = Infinity) {
  if (!isUnit(target) || !shipProfile(target)) return target;
  const home = isUnit(attacker) && attacker.deck && unitRules(game, attacker).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD ? game.units.find((ship) => ship.id === attacker.deck.shipId) : void 0;
  const passengers = home && home.id !== target.id && decksCanTransfer(home, target, attacker) ? [...shipPassengers(game.units, target), ...shipPassengers(game.units, home)] : shipPassengers(game.units, target);
  const crew = passengers.filter((unit) => unit.hp > 0 && !isInCabin(unit) && areEnemyOwners(game, attacker.owner, unit.owner) && (crewRange === Infinity || distanceSquared(attacker, unit) <= crewRange * crewRange) && (isUnit(attacker) ? canReach(game.map, attacker, unit, game.units) : distance(attacker, unit) <= attacker.attackRange));
  let best, bestScore = -Infinity;
  for (const unit of crew) {
    const score = targetPriorityScore(game, attacker.owner, unit, distanceSquared(attacker, unit), isUnit(attacker) ? attacker : void 0);
    if (score > bestScore) {
      best = unit;
      bestScore = score;
    }
  }
  return best ?? crew[0] ?? target;
}
function triggerNeutralAssist(game, damagedNeutral, attacker) {
  if (!areEnemyOwners(game, damagedNeutral.owner, attacker.owner)) return;
  const origin = neutralHomeOrCurrentPoint(damagedNeutral);
  for (const unit of game.units) {
    if (unit.owner !== "neutral" || unit.hp <= 0) continue;
    if (distance(unit, damagedNeutral) > NEUTRAL_ASSIST_RANGE) continue;
    if (!canReach(game.map, unit, attacker, game.units)) continue;
    const responseOrigin = neutralResponseOrigin(unit) ?? origin;
    if (distance(attacker, responseOrigin) > NEUTRAL_DAMAGE_RESPONSE_RANGE) continue;
    if (neutralHasValidAttackTarget(game, unit) && unit.order.type === "attack") {
      if (incomingThreatOutranks(game, unit, unit.order.targetId, attacker, damagedNeutral)) unit.order = { ...unit.order, targetId: attacker.id };
    } else unit.order = { type: "attack", targetId: attacker.id, leashX: origin.x, leashY: origin.y };
  }
}
function triggerPlayerAggro(game, victim, attacker) {
  if (!areEnemyOwners(game, victim.owner, attacker.owner) || attacker.hp <= 0 || findTarget(game, attacker.id) !== attacker) return;
  if (isUnit(victim)) takeUpAttacker(game, victim, attacker, victim);
  const reach = HELP_CALL_RANGE + (isUnit(victim) ? 0 : victim.radius);
  forEachNearbyUnit(game, victim, reach, (ally) => {
    if (ally === victim || ally.owner !== victim.owner || distance(ally, victim) > reach) return;
    takeUpAttacker(game, ally, attacker, victim);
  });
}
function __observed_takeUpAttacker(game, unit, attacker, victim) {
  if (unit.hp <= 0 || unit.kind === "worker" || unit.attackDamage <= 0 || !canReach(game.map, unit, attacker, game.units)) return;
  const order = unit.order;
  if (shipProfile(unit) && order.type === "idle") return;
  if (order.type === "idle") {
    if (!unit.orderQueue?.length) unit.order = { type: "attack", targetId: attacker.id, leashX: unit.x, leashY: unit.y };
    return;
  }
  if (order.type === "attackMove") {
    if (!order.targetId || incomingThreatOutranks(game, unit, order.targetId, attacker, victim)) unit.order = { ...order, targetId: attacker.id };
    return;
  }
  const selfDirected = order.type === "attack" && order.leashX !== void 0;
  if (selfDirected && incomingThreatOutranks(game, unit, order.targetId, attacker, victim)) unit.order = { ...order, targetId: attacker.id };
}
function incomingThreatOutranks(game, unit, targetId, attacker, victim) {
  if (targetId === attacker.id) return false;
  const current = findTarget(game, targetId);
  if (!current || current.hp <= 0 || !canReach(game.map, unit, current, game.units)) return true;
  const incoming = combatTargetScore(attacker, targetGap(unit, attacker), victim.id === unit.id ? "self" : "ally", projectedHpAfterPendingProjectiles(game, unit.owner, attacker));
  return shouldSwitchCombatTarget(targetPriorityScore(game, unit.owner, current, targetGap(unit, current) ** 2, unit), incoming);
}
function automaticCombatTarget(game, unit, current, navalFrame = true) {
  if (unit.cooldown > 0) return current;
  const next = nearestEnemyTarget(game, unit, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange), navalFrame);
  if (!next || next.id === current.id) return current;
  return shouldSwitchCombatTarget(
    targetPriorityScore(game, unit.owner, current, targetGap(unit, current, navalFrame) ** 2, unit),
    targetPriorityScore(game, unit.owner, next, targetGap(unit, next, navalFrame) ** 2, unit)
  ) ? next : current;
}
function neutralHasValidAttackTarget(game, unit) {
  if (unit.order.type !== "attack") return false;
  const target = findTarget(game, unit.order.targetId);
  if (!target || target.hp <= 0 || !areEnemyOwners(game, unit.owner, target.owner)) return false;
  const responseOrigin = neutralResponseOrigin(unit);
  if (responseOrigin && distance(target, responseOrigin) > NEUTRAL_DAMAGE_RESPONSE_RANGE) return false;
  return true;
}
function neutralResponseOrigin(unit) {
  if (unit.order.type === "attack" && unit.order.leashX !== void 0 && unit.order.leashY !== void 0) return { x: unit.order.leashX, y: unit.order.leashY };
  if (unit.homeX !== void 0 && unit.homeY !== void 0) return { x: unit.homeX, y: unit.homeY };
  return void 0;
}
function neutralHomeOrCurrentPoint(unit) {
  return unit.homeX !== void 0 && unit.homeY !== void 0 ? { x: unit.homeX, y: unit.homeY } : { x: unit.x, y: unit.y };
}
function recordKill(game, attacker, target) {
  if (isUnit(target) && shipProfile(target)) for (const passenger of shipPassengers(game.units, target)) {
    if (passenger.hp > 0) {
      passenger.hp = 0;
      recordKill(game, attacker, passenger);
    }
  }
  if (!areEnemyOwners(game, attacker.owner, target.owner)) return;
  const attackerOwner = attacker.owner;
  if (isPlayerId(attackerOwner) || attackerOwner === "neutral") {
    incrementStat(game.match.stats.unitsKilled, attackerOwner, isUnit(target) ? 1 : 0);
  }
  if (isUnit(attacker) && isUnit(target)) {
    attacker.kills += 1;
    awardKillXp(game, attacker, target);
    if (attacker.owner === "neutral" && isPlayerId(target.owner)) {
      incrementStat(game.match.stats.unitsKilledByNeutral, target.owner, 1);
    }
    if (isPlayerId(attacker.owner) && isMercenaryUnitKind(attacker.kind) && areEnemyOwners(game, attacker.owner, target.owner)) {
      incrementStat(game.match.stats.mercenaryKills, attacker.owner, 1);
    }
  }
  if (isUnit(target) && target.owner === "neutral" && isPlayerId(attackerOwner)) {
    incrementStat(game.match.stats.neutralUnitsKilled, attackerOwner, 1);
    awardNeutralGoldBounty(game, attackerOwner, target);
  }
  if (!isUnit(target) && isPlayerId(attackerOwner)) {
    incrementStat(game.match.stats.buildingsDestroyed, attackerOwner, 1);
    if (target.kind !== "townHall") incrementStat(game.match.stats.nonBaseBuildingsDestroyed, attackerOwner, 1);
  }
}
function addEffect(game, type, x, y, remaining, vectors) {
  game.effects.push({ id: `effect-${game.nextId}`, type, x, y, remaining, duration: remaining, ...vectors, ...vectors?.actionMode ? { actionTick: game.tick } : {} });
  game.nextId += 1;
}
function isUnit(entity) {
  return "order" in entity;
}
function isObstacle(entity) {
  return "along" in entity;
}
function awardKillXp(game, attacker, target) {
  if (attacker.owner === "neutral" || !areEnemyOwners(game, attacker.owner, target.owner)) return;
  attacker.xp += killXpReward(unitRules(game, target), target.level);
  applyXpLevel(game, attacker);
}
function awardNeutralGoldBounty(game, owner, target) {
  const bounty = unitRules(game, target).goldBounty ?? 0;
  if (bounty <= 0) return;
  playerState(game, owner).gold = addGold(playerState(game, owner).gold, bounty);
  addEffect(game, "goldBounty", target.x, target.y, seconds(1.2), { owner, amount: bounty });
}
function applyXpLevel(game, unit) {
  if (unit.variant !== void 0 && game.variants?.[unit.variant]?.heroic) return;
  const nextLevel = xpStarThresholds(unitRules(game, unit)).filter((threshold) => unit.xp >= threshold).length;
  if (nextLevel <= unit.level) return;
  unit.level = Math.min(MAX_UPGRADE_LEVEL, nextLevel);
  if (unit.level === 3 && unit.owner !== "neutral" && unit.expiresTick === void 0 && !unit.veteranSkillChoices) {
    unit.veteranSkillChoices = rollVeteranSkillChoices(unit.kind, unit.id, `${game.map.terrain?.ecology?.seed ?? game.map.id}:${game.tick}`, unitClassOf(unit, game));
  }
  applyDerivedUnitStats(game, unit);
}
function applyDerivedUnitStats(game, unit) {
  const previousMaxHp = unit.maxHp;
  const base = nonStarUnitStats(game, unit);
  const multiplier = 1 + Math.min(MAX_UPGRADE_LEVEL, Math.max(0, unit.level)) * VETERANCY_GAIN_PER_STAR;
  const heavy = itemsFor(game, unit).some((item) => ITEM_DEFS[item.kind].span === 4);
  unit.bodyRadius = unitRules(game, unit).radius * (isShipKind(unit.kind) ? SHIP_SIZE_MULTIPLIER : 1);
  unit.radius = unit.bodyRadius;
  const veterans = game.veteranFrame?.get(unit.id);
  unit.attackDamage = Math.round(base.attackDamage);
  unit.maxHp = Math.round(base.maxHp * multiplier);
  unit.speed = base.speed * (heavy ? 0.45 : 1) * (veterans?.moveSpeedMultiplier ?? 1);
  unit.attackRange = base.attackRange * (veterans?.attackRangeMultiplier ?? 1);
  unit.hp = Math.min(unit.maxHp, Math.max(1, unit.hp + unit.maxHp - previousMaxHp));
}
function nonStarUnitStats(game, unit) {
  const stats = weaponRules(game, unit);
  unit.attackCooldown = stats.attackCooldown;
  let attackDamage = stats.attackDamage;
  let maxHp = stats.hp;
  let speed = stats.speed;
  let attackRange = stats.attackRange;
  if (!isPlayerId(unit.owner)) return { attackDamage, maxHp, speed, attackRange };
  const upgrades = playerState(game, unit.owner).upgrades;
  for (const upgradeKind of UPGRADE_KINDS) {
    const upgrade = UPGRADE_DEFS[upgradeKind];
    if (!upgrade.affectedUnitKinds.includes(unit.kind)) continue;
    for (let level = 0; level < (upgrades[upgradeKind] ?? 0); level += 1) {
      const levelDef = upgrade.levels[level];
      if (!levelDef) throw new Error(`${upgradeKind} missing level ${level + 1}`);
      if (levelDef.attackMultiplier) attackDamage = stats.attackDamage * levelDef.attackMultiplier;
      if (levelDef.maxHpMultiplier) maxHp = stats.hp * levelDef.maxHpMultiplier;
      if (levelDef.speedMultiplier) speed = roundUnitScalar(stats.speed * levelDef.speedMultiplier);
      if (levelDef.attackRangeMultiplier) attackRange = Math.round(stats.attackRange * levelDef.attackRangeMultiplier);
    }
  }
  if (itemsFor(game, unit).some((item) => item.kind === "speedBoots" && itemEquipped(game, unit, item))) speed = roundUnitScalar(speed * BOOTS_SPEED);
  return { attackDamage, maxHp, speed, attackRange };
}
function roundUnitScalar(value) {
  return Math.round(value * 100) / 100;
}
function updateSupplyState(game) {
  for (const owner of game.activePlayers) {
    const player = playerState(game, owner);
    player.supplyCap = game.buildings.filter((building) => building.owner === owner && building.complete).reduce((total, building) => total + BUILDING_DEFS[building.kind].supplyProvided, 0);
    player.supplyUsed = projectedSupplyUsed(game, owner);
  }
}
function projectedSupplyUsed(game, owner) {
  const unitSupply = game.units.filter((unit) => unit.owner === owner).reduce((total, unit) => total + unitRules(game, unit).supplyUsed + (unit.cargo ? cargoSupply(game, unit) : 0), 0);
  const queuedSupply = game.buildings.filter((building) => building.owner === owner).flatMap((building) => building.queue).reduce((total, job) => total + UNIT_DEFS[job.unitKind].supplyUsed, 0);
  return unitSupply + queuedSupply;
}
function unitsByIds(game, unitIds, owner) {
  const unit = ownUnitLookup(game.units, owner, unitIds.length);
  const units = unitIds.map((id) => unit(id));
  const missing = units.findIndex((unit2) => !unit2);
  if (missing >= 0) throw new Error(`Unknown ${owner} unit ${unitIds[missing]}`);
  return units;
}
function buildingsByIds(game, buildingIds, owner) {
  const buildings = buildingIds.map((id) => game.buildings.find((building) => building.id === id && building.owner === owner));
  const missing = buildings.findIndex((building) => !building);
  if (missing >= 0) throw new Error(`Unknown ${owner} building ${buildingIds[missing]}`);
  return buildings;
}
function spendGold(game, owner, amount) {
  spend(playerState(game, owner), amount);
  incrementStat(game.match.stats.goldSpent, owner, amount);
}
function spend(player, amount) {
  if (player.gold < amount) throw new Error(`Need ${amount} gold`);
  player.gold = addGold(player.gold, -amount);
}
function playerState(game, owner) {
  const player = game.players[owner];
  if (!player) throw new Error(`Unknown player ${owner}`);
  return player;
}
function incrementStat(record, owner, amount) {
  record[owner] = (record[owner] ?? 0) + amount;
}
function canSupply(game, owner, unitKind) {
  return projectedSupplyUsed(game, owner) + UNIT_DEFS[unitKind].supplyUsed <= playerState(game, owner).supplyCap;
}
function isMercenaryUnitKind(kind) {
  return MERCENARY_UNIT_KINDS.includes(kind);
}
function completeBuildings(game, owner, kind) {
  return game.buildings.filter((building) => building.owner === owner && building.kind === kind && building.complete);
}
function nearestCompleteTownHall(game, owner, x, y) {
  if (!isPlayerId(owner)) return void 0;
  return (game.miningFrame?.townHalls.get(owner) ?? completeBuildings(game, owner, "townHall")).filter((building) => sameGround(game.map, { x, y }, building)).reduce((best, building) => {
    if (!best) return building;
    return distance({ x, y }, building) < distance({ x, y }, best) ? building : best;
  }, void 0);
}
function nearestEnemyInRange(game, unit, range) {
  const limit = range * range;
  return firstNearbyUnit(game, unit, range, (candidate) => areEnemyOwners(game, unit.owner, candidate.owner) && distanceSquared(unit, candidate) <= limit);
}
function __observed_nearestEnemyTarget(game, unit, range, navalFrame = true) {
  if (unit.attackDamage <= 0) return void 0;
  return nearestEnemyTargetFromPoint(game, unit.owner, unit, range, unit, void 0, navalFrame);
}
function targetGap(from, target, navalFrame = true) {
  if (!navalFrame && isUnit(target)) return hypot2(target.x - from.x, target.y - from.y);
  return strikeGap(from, target);
}
function nearestEnemyTargetFromPoint(game, owner, point, range, attacker, accepts, navalFrame = true) {
  const limit = range * range;
  let best;
  let bestScore = Number.NEGATIVE_INFINITY;
  forEachNearbyEnemyUnit(game, owner, point, range + (navalFrame ? game.shipReachPadding ?? shipReachPadding(game.units) : 0), (candidate) => {
    if (navalFrame && isInCabin(candidate)) return;
    if (navalFrame && !automaticTargetAllowed(game.units, owner, candidate)) return;
    if (navalFrame && shipProfile(candidate) && shipPassengers(game.units, candidate).some((unit) => unit.hp > 0 && !isInCabin(unit) && (!attacker || canReach(game.map, attacker, unit, game.units)))) return;
    if (accepts && !accepts(candidate)) return;
    const candidateDistance = navalFrame && isShipKind(candidate.kind) ? distanceToHull(candidate, point) ** 2 : distanceSquared(point, candidate);
    if (candidateDistance > limit) return;
    if (attacker && !automaticCandidateReachable(game, attacker, candidate, navalFrame)) return;
    const score = targetPriorityScore(game, owner, candidate, candidateDistance, attacker);
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  });
  forEachNearbyEnemyBuilding(game, owner, point, range + MAX_BUILDING_RADIUS, (building) => {
    if (accepts && !accepts(building)) return;
    const gap = targetGap(point, building);
    if (gap > range) return;
    if (attacker && !automaticCandidateReachable(game, attacker, building, navalFrame)) return;
    const score = targetPriorityScore(game, owner, building, gap * gap, attacker);
    if (score > bestScore) {
      best = building;
      bestScore = score;
    }
  });
  return best;
}
function shipReachPadding(units) {
  let padding = 0;
  for (const unit of shipsIn(units)) {
    const profile = shipProfile(unit);
    if (profile) padding = Math.max(padding, ...profile.hull.map((p) => Math.hypot(p.x, p.y)));
  }
  return padding;
}
function automaticCandidateReachable(game, unit, candidate, navalFrame = true) {
  if ((navalFrame || game.map.terrain) && !canReach(game.map, unit, candidate, game.units)) return false;
  if (navalFrame && !automaticShoreTargetReachable(game, unit, candidate)) return false;
  if (unit.owner !== "neutral") return true;
  const origin = neutralResponseOrigin(unit);
  return !origin || distance(candidate, origin) <= NEUTRAL_DAMAGE_RESPONSE_RANGE;
}
function targetPriorityScore(game, owner, target, distanceSq, attacker) {
  const victimId = combatVictimId(target);
  const victim = victimId ? findTarget(game, victimId) : void 0;
  const threat = victim && !areEnemyOwners(game, owner, victim.owner) ? victim === attacker ? "self" : "ally" : "none";
  return combatTargetScore(target, Math.sqrt(distanceSq), threat, projectedHpAfterPendingProjectiles(game, owner, target));
}
function projectedHpAfterPendingProjectiles(game, attackerOwner, target) {
  let pendingDamage = 0;
  for (const projectile of projectilesAt(game, target.id)) if (projectile.owner === attackerOwner && !projectile.weapon) pendingDamage += projectile.damage;
  return target.hp - pendingDamage;
}
var projectilesByTarget = /* @__PURE__ */ new WeakMap();
var NO_PROJECTILES = [];
function projectilesAt(game, targetId) {
  const projectiles = game.projectiles;
  let index = projectilesByTarget.get(projectiles);
  if (!index || index.indexed > projectiles.length) projectilesByTarget.set(projectiles, index = { indexed: 0, byTarget: /* @__PURE__ */ new Map() });
  for (; index.indexed < projectiles.length; index.indexed += 1) {
    const projectile = projectiles[index.indexed];
    const atTarget = index.byTarget.get(projectile.targetId);
    if (atTarget) atTarget.push(projectile);
    else index.byTarget.set(projectile.targetId, [projectile]);
  }
  return index.byTarget.get(targetId) ?? NO_PROJECTILES;
}
function findTarget(game, targetId) {
  const target = game.entityById?.get(targetId) ?? game.units.find((unit) => unit.id === targetId) ?? game.buildings.find((building) => building.id === targetId);
  return target && isUnit(target) && isInCabin(target) ? void 0 : target;
}
function findStrikeTarget(game, targetId) {
  return findTarget(game, targetId) ?? game.obstacles?.find((obstacle) => obstacle.id === targetId);
}
function removeExpiredUnits(game) {
  if (!game.units.some((unit) => unit.expiresTick !== void 0 && unit.expiresTick <= game.tick)) return;
  const expiredUnits = game.units.filter((unit) => unit.expiresTick !== void 0 && unit.expiresTick <= game.tick);
  dropItemsFromDeadUnits(game, expiredUnits);
  const expiredIds = new Set(expiredUnits.map((unit) => unit.id));
  game.units = game.units.filter((unit) => !expiredIds.has(unit.id));
  invalidateSeparationFrame(game);
  updateSupplyState(game);
}
function removeDead(game) {
  if (!game.units.some((unit) => unit.hp <= 0) && !game.buildings.some((building) => building.hp <= 0)) {
    if (game.obstacles?.some((obstacle) => obstacle.hp <= 0)) game.obstacles = game.obstacles.filter((obstacle) => obstacle.hp > 0);
    return;
  }
  const deadUnits = game.units.filter((unit) => unit.hp <= 0);
  const wrecks = new Set(deadUnits.filter((unit) => shipProfile(unit)).map((unit) => unit.id));
  if (wrecks.size) {
    for (const passenger of game.units) if (passenger.deck && wrecks.has(passenger.deck.shipId) && passenger.hp > 0) {
      passenger.hp = 0;
      deadUnits.push(passenger);
    }
  }
  const deadBuildings = game.buildings.filter((building) => building.hp <= 0);
  for (const unit of deadUnits) incrementStat(game.match.stats.unitsLost, unit.owner, 1);
  const deathAppearance = new Map(deadUnits.map((unit) => {
    const right = activeItem(game, unit, "right"), left = activeItem(game, unit, "left");
    return [unit.id, {
      equipmentCaptured: true,
      ...unit.deck ? { deck: { ...unit.deck } } : {},
      ...right?.kind === "greatSword" ? { rightItemKind: "greatSword" } : right?.kind === "issuedWeapon" ? { rightItemKind: "issuedWeapon", ...right.weaponKind ? { weaponKind: right.weaponKind } : {} } : {},
      ...left?.kind === "roundShield" ? { leftItemKind: "roundShield" } : {},
      ...game.players[unit.owner]?.race ? { ownerRace: game.players[unit.owner].race } : {}
    }];
  }));
  dropItemsFromDeadUnits(game, deadUnits);
  for (const unit of deadUnits) if (!(unit.deck && wrecks.has(unit.deck.shipId))) {
    (game.corpses ??= []).push({
      id: `corpse-${unit.id}-${game.tick}`,
      unitId: unit.id,
      kind: unit.kind,
      owner: unit.owner,
      x: unit.x,
      y: unit.y,
      radius: unit.radius,
      diedAtTick: game.tick,
      ...unit.variant ? { variant: unit.variant } : {},
      ...deathAppearance.get(unit.id)
    });
  }
  if (deadUnits.length) {
    game.units = game.units.filter((unit) => unit.hp > 0);
    invalidateSeparationFrame(game);
  }
  if (deadBuildings.length) game.buildings = game.buildings.filter((building) => building.hp > 0);
  if (game.obstacles?.some((obstacle) => obstacle.hp <= 0)) game.obstacles = game.obstacles.filter((obstacle) => obstacle.hp > 0);
  if (deadUnits.length > 0 || deadBuildings.length > 0) updateSupplyState(game);
}
function dropItemsFromDeadUnits(game, deadUnits) {
  if (deadUnits.length === 0) return;
  invalidateItemIndex(game.items);
  const deadById = new Map(deadUnits.map((unit) => [unit.id, unit]));
  for (const item of game.items) {
    if (!item.carrierId && !item.shipId) continue;
    const dead = deadById.get(item.carrierId ?? item.shipId);
    if (!dead) continue;
    delete item.carrierId;
    delete item.slot;
    delete item.shipId;
    delete item.holdSlot;
    delete item.mountId;
    delete item.aim;
    item.x = dead.x;
    item.y = dead.y;
  }
}
function updateVictory(game) {
  if (game.match.winner || game.scriptedVictory) return;
  const activeTeams = /* @__PURE__ */ new Set();
  for (const owner of game.activePlayers) activeTeams.add(teamKey(game, owner));
  let winnerTeam;
  let winner = null;
  for (const building of game.buildings) {
    const team = teamKey(game, building.owner);
    if (!activeTeams.has(team)) continue;
    if (winnerTeam !== void 0 && team !== winnerTeam) return;
    if (winnerTeam === void 0) {
      winnerTeam = team;
      winner = building.owner;
    }
  }
  game.match.winner = winner;
  game.match.endedAtTick = game.tick;
}
function refreshUnitStats(game, unit) {
  const rules = unitRules(game, unit);
  const share = unit.hp / Math.max(1, unit.maxHp);
  if (unit.variant !== void 0) takeVariantFrame(unit, rules);
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  unit.hp = Math.max(1, Math.min(unit.maxHp, Math.round(unit.maxHp * share)));
}
function takeVariantFrame(unit, rules) {
  unit.maxHp = rules.hp;
  unit.hp = Math.min(unit.hp, rules.hp);
  unit.speed = rules.speed;
  unit.radius = rules.radius * (isShipKind(unit.kind) ? SHIP_SIZE_MULTIPLIER : 1);
  unit.bodyRadius = unit.radius;
  unit.attackDamage = rules.attackDamage;
  unit.attackRange = rules.attackRange;
  unit.attackCooldown = rules.attackCooldown;
}
function scriptSource(source) {
  const stand = projectileAttacker({ id: source.id, owner: source.owner, attackerId: source.id, targetId: source.id, fromX: source.x, fromY: source.y, toX: source.x, toY: source.y, damage: 0, remaining: 0, duration: 0 });
  return { ...stand, kind: "farm" };
}
function isPlayerId(owner) {
  return owner !== "neutral";
}
function areEnemyOwners(game, a, b) {
  if (a === b) return false;
  if (a === "neutral" || b === "neutral") return a !== "neutral" || b !== "neutral";
  return game.teams[a] !== game.teams[b];
}
function teamKey(game, owner) {
  return owner === "neutral" ? "neutral" : game.teams[owner] ?? owner;
}
var MAX_BUILDING_RADIUS = Math.max(...Object.values(BUILDING_DEFS).map((def) => def.radius));
var MAX_UNIT_RADIUS = Math.max(...Object.values(UNIT_DEFS).map((def) => def.radius));
function __observed_walkEnded(game, unit, goal, within) {
  const map = game.map;
  const travel = unit.order;
  if ((travel.type === "move" || travel.type === "attackMove") && travel.deckShipId && travel.deckShipId !== unit.deck?.shipId && game.units.some((ship) => ship.id === travel.deckShipId && ship.hp > 0)) return false;
  if (unit.deck && (travel.type === "move" || travel.type === "attackMove") && !travel.deckShipId && isOpenGround(map, goal.x, goal.y, "land")) return false;
  if (unit.deck) {
    const ship = game.units.find((ship2) => ship2.id === unit.deck.shipId);
    if (!ship) return true;
    const order = unit.order;
    if ((order.type === "move" || order.type === "attackMove") && order.deckShipId && order.deckShipId !== ship.id && game.units.some((target) => target.id === order.deckShipId && target.hp > 0)) return false;
    const local = deckPlacement(ship, unit, game.units, worldToLocal(ship, deckGoal(unit, ship, goal, game.units)), false);
    return !local || distance(unit, localToWorld(ship, local)) < within || restsAgainstArrivedFriend(game, unit, goal, localToWorld(ship, local));
  }
  if (shipProfile(unit)) {
    if (travel.type === "move" && travel.heading !== void 0 && Math.abs(headingDifference(unit.sailing.heading, travel.heading)) > 1e-6) return false;
    const route = unit.sailing?.route;
    if (map.terrain && route && route.goalX === goal.x && route.goalY === goal.y) return !route.partial && route.points.length === 0 && distance(unit, route.end) < within;
    const end2 = nearestShipPose(map, unit, goal);
    return !end2 || distance(unit, end2) < within;
  }
  if (!map.terrain) return distance(unit, goal) < within || restsAgainstArrivedFriend(game, unit, goal, goal);
  const mover = unitMover(unit.kind);
  const point = isWalkable(map, goal.x, goal.y, mover) ? goal : walkableGoal(map, goal.x, goal.y, mover);
  const end = walkDestination(map, unit, point, mover);
  return distance(unit, end) < within || restsAgainstGoalBody(game, unit, point, within) || restsAgainstArrivedFriend(game, unit, goal, end);
}
function __observed_arrive(unit, goal) {
  unit.order = { type: "idle" };
  unit.arrivedAt = { x: goal.x, y: goal.y };
}
function restsAgainstGoalBody(game, unit, goal, within) {
  if (distance(unit, goal) > 2 * (MAX_BUILDING_RADIUS + MAX_UNIT_RADIUS) + within + 2) return false;
  let resting = false;
  forEachNearbyBuilding(game, goal, MAX_BUILDING_RADIUS + unit.radius + within, (building) => {
    const reach = building.radius + unit.radius;
    if (!resting && distance(goal, building) < reach + within && distance(unit, building) <= reach + 2) resting = true;
  });
  return resting;
}
var CROWD_REACH = 100;
function restsAgainstArrivedFriend(game, unit, goal, end) {
  const gap = distance(unit, end);
  if (gap > CROWD_REACH) return false;
  const friend = firstNearbyUnit(game, unit, unit.radius + MAX_UNIT_RADIUS + 2, (other) => {
    if (other === unit || other.owner !== unit.owner || distance(other, unit) > other.radius + unit.radius + 2) return false;
    const there = other.order.type === "idle" && other.arrivedAt?.x === goal.x && other.arrivedAt.y === goal.y;
    const huddled = gap <= 2 * (unit.radius + other.radius) && (other.order.type === "move" || other.order.type === "attackMove") && other.order.x === goal.x && other.order.y === goal.y;
    return there || huddled;
  });
  return friend !== void 0;
}
function keepUnitsOutOfBuildings(game) {
  const map = game.map;
  for (const unit of game.units) {
    if (unit.deck) continue;
    if (unitMover(unit.kind) !== "land" || isOpenGround(map, unit.x, unit.y) || !isWalkable(map, unit.x, unit.y)) continue;
    const out = openGroundNear(map, unit);
    if (!out) continue;
    unit.x = out.x;
    unit.y = out.y;
  }
}
function slideUnits(game) {
  for (const unit of game.units) if (!isInCabin(unit) && unit.pushX !== void 0) {
    if (!unit.deck) {
      const from = { x: unit.x, y: unit.y };
      slide(unit, game.map, game.units);
      const at2 = constrainGroundShipStep(game.map, unit, from, unit, game.units);
      if (at2.x !== unit.x || at2.y !== unit.y) {
        unit.x = at2.x;
        unit.y = at2.y;
        unit.pushX = void 0;
        unit.pushY = void 0;
      }
      continue;
    }
    const point = { x: unit.x + perTick(unit.pushX), y: unit.y + perTick(unit.pushY ?? 0) };
    const at = deckSeparationPoint(game, unit, point);
    Object.assign(unit, { x: at.x, y: at.y });
    const speed = Math.hypot(unit.pushX, unit.pushY ?? 0), next = Math.max(0, speed - perTick(PUSH_FRICTION));
    if (next === 0 || at === unit) {
      unit.pushX = void 0;
      unit.pushY = void 0;
    } else {
      unit.pushX *= next / speed;
      unit.pushY = (unit.pushY ?? 0) * next / speed;
    }
  }
}
var separationFrames = /* @__PURE__ */ new WeakMap();
function clearSeparationBuckets(frame) {
  for (const bucket of frame.buckets) {
    for (let i = 0; i < bucket.count; i += 1) bucket.units[i] = void 0;
    bucket.count = 0;
    frame.lookup[bucket.slot] = void 0;
  }
  frame.buckets.length = 0;
  frame.pairs.length = 0;
  frame.valid = false;
}
function clearSeparationMembership(frame) {
  clearSeparationBuckets(frame);
  frame.members.length = frame.cellX.length = frame.cellY.length = frame.x.length = frame.y.length = 0;
}
function invalidateSeparationFrame(game) {
  const frame = separationFrames.get(game);
  if (frame) clearSeparationMembership(frame);
}
function separationBucketSlot(frame, key) {
  let slot = Math.imul(key, 2654435761) >>> frame.shift;
  let bucket;
  while (bucket = frame.lookup[slot]) {
    if (bucket.key === key || bucket.key !== bucket.key && key !== key) return slot;
    slot = slot + 1 & frame.mask;
  }
  return slot;
}
function separationMembershipMatches(game, frame, cellSize, navalFrame) {
  frame.unchangedSource = frame.unchangedMembers = 0;
  if (!frame.valid) return false;
  let member = 0;
  for (let i = 0; i < game.units.length; i += 1) {
    const unit = game.units[i];
    if (navalFrame && (isInCabin(unit) || isShipKind(unit.kind)) || minerGhost(unit)) continue;
    if (frame.members[member] !== unit || !Object.is(frame.x[member], unit.x) && !Object.is(frame.cellX[member], Math.floor(unit.x / cellSize)) || !Object.is(frame.y[member], unit.y) && !Object.is(frame.cellY[member], Math.floor(unit.y / cellSize))) {
      frame.unchangedSource = i;
      frame.unchangedMembers = member;
      return false;
    }
    frame.x[member] = unit.x;
    frame.y[member] = unit.y;
    member += 1;
  }
  frame.unchangedSource = game.units.length;
  frame.unchangedMembers = member;
  return member === frame.members.length;
}
function separateUnits(game, navalFrame) {
  const cellSize = 80;
  let frame = separationFrames.get(game);
  if (!frame) {
    frame = { buckets: [], lookup: new Array(16), mask: 15, shift: 28, pool: [], members: [], cellX: [], cellY: [], x: [], y: [], pairs: [], valid: false, unchangedSource: 0, unchangedMembers: 0 };
    separationFrames.set(game, frame);
  }
  const buckets = frame.buckets;
  const aPoint = { x: 0, y: 0 }, bPoint = { x: 0, y: 0 };
  const openGround = !game.map.terrain && groundShipFrameEmpty(game.units);
  if (!separationMembershipMatches(game, frame, cellSize, navalFrame)) {
    const prefix = frame.unchangedMembers, sourceStart = frame.unchangedSource;
    clearSeparationBuckets(frame);
    let capacity = frame.mask + 1, shift = frame.shift;
    while (capacity < game.units.length * 2) {
      capacity *= 2;
      shift -= 1;
    }
    if (capacity !== frame.mask + 1) {
      frame.lookup = new Array(capacity);
      frame.mask = capacity - 1;
      frame.shift = shift;
    }
    let used = 0, member = 0;
    const insert = (unit, x, y) => {
      const key = numericBucketKey(x, y);
      const slot = separationBucketSlot(frame, key);
      let bucket = frame.lookup[slot];
      if (!bucket) {
        bucket = frame.pool[used++];
        if (bucket) {
          bucket.key = key;
          bucket.slot = slot;
          bucket.x = x;
          bucket.y = y;
          bucket.count = 0;
        } else {
          bucket = { key, slot, x, y, units: [], count: 0 };
          frame.pool.push(bucket);
        }
        frame.lookup[slot] = bucket;
        buckets.push(bucket);
      }
      frame.members[member] = unit;
      frame.x[member] = unit.x;
      frame.y[member] = unit.y;
      frame.cellX[member] = x;
      frame.cellY[member++] = y;
      bucket.units[bucket.count++] = unit;
    };
    for (let i = 0; i < prefix; i += 1) insert(frame.members[i], frame.cellX[i], frame.cellY[i]);
    for (let i = sourceStart; i < game.units.length; i += 1) {
      const unit = game.units[i];
      if (navalFrame && (isInCabin(unit) || isShipKind(unit.kind)) || minerGhost(unit)) continue;
      insert(unit, Math.floor(unit.x / cellSize), Math.floor(unit.y / cellSize));
    }
    frame.members.length = frame.cellX.length = frame.cellY.length = frame.x.length = frame.y.length = member;
    for (const bucket of buckets) {
      frame.pairs.push(bucket, bucket);
      for (const [ox, oy] of SEPARATION_NEIGHBORS) {
        const neighbor = frame.lookup[separationBucketSlot(frame, numericBucketKey(bucket.x + ox, bucket.y + oy))];
        if (neighbor) frame.pairs.push(bucket, neighbor);
      }
    }
    frame.valid = true;
  }
  for (let i = 0; i < frame.pairs.length; i += 2) {
    separateUnitBuckets(game, frame.pairs[i], frame.pairs[i + 1], aPoint, bPoint, openGround, navalFrame);
  }
}
var SEPARATION_NEIGHBORS = [
  [1, -1],
  [1, 0],
  [1, 1],
  [0, 1]
];
function separateUnitBuckets(game, aBucket, bBucket, aPoint, bPoint, openGround, navalFrame) {
  const aUnits = aBucket.units, bUnits = bBucket.units;
  const sameBucket = aBucket === bBucket;
  for (let i = 0; i < aBucket.count; i += 1) {
    const start = sameBucket ? i + 1 : 0;
    const a = aUnits[i];
    for (let j = start; j < bBucket.count; j += 1) {
      const b = bUnits[j];
      const minDistance = a.radius + b.radius;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const distanceSq = dx * dx + dy * dy;
      if (distanceSq >= minDistance * minDistance) continue;
      separateUnitPair(game, a, b, minDistance, dx, dy, aPoint, bPoint, openGround, navalFrame);
    }
  }
}
function minerGhost(unit) {
  return unit.kind === "worker" && unit.order.type === "mine";
}
function separateUnitPair(game, a, b, minDistance, dx, dy, aPoint, bPoint, openGround, navalFrame) {
  let aMover = "land", bMover = "land";
  if (navalFrame) {
    if (a.deck || b.deck) {
      if (!a.deck || !b.deck || a.deck.shipId !== b.deck.shipId) return;
    }
    aMover = unitMover(a.kind);
    bMover = unitMover(b.kind);
    if (aMover !== bMover) return;
  }
  const length = hypot2(dx, dy);
  const nx = length === 0 ? 1 : dx / length;
  const ny = length === 0 ? 0 : dy / length;
  if (a.pushX !== void 0 || b.pushX !== void 0) pushContact(a, b, nx, ny);
  const push = (minDistance - length) / 2;
  const ax = clamp(a.x - nx * push, 0, game.map.width);
  const ay = clamp(a.y - ny * push, 0, game.map.height);
  const bx = clamp(b.x + nx * push, 0, game.map.width);
  const by = clamp(b.y + ny * push, 0, game.map.height);
  if (openGround && !a.deck && !b.deck) {
    a.x = ax;
    a.y = ay;
    b.x = bx;
    b.y = by;
    return;
  }
  aPoint.x = ax;
  aPoint.y = ay;
  const aAt = !navalFrame ? openStep(game.map, a, aPoint, "land") : a.deck ? deckSeparationPoint(game, a, aPoint) : constrainGroundShipStep(game.map, a, a, openStep(game.map, a, aPoint, aMover), game.units);
  bPoint.x = bx;
  bPoint.y = by;
  const bAt = !navalFrame ? openStep(game.map, b, bPoint, "land") : b.deck ? deckSeparationPoint(game, b, bPoint) : constrainGroundShipStep(game.map, b, b, openStep(game.map, b, bPoint, bMover), game.units);
  a.x = aAt.x;
  a.y = aAt.y;
  b.x = bAt.x;
  b.y = bAt.y;
}
function deckSeparationPoint(game, unit, point) {
  const ship = game.units.find((ship2) => ship2.id === unit.deck.shipId);
  if (!ship) return unit;
  const local = worldToLocal(ship, point);
  if (!deckPointFits(ship, unit, local, game.units, false)) return unit;
  Object.assign(unit.deck, local);
  return point;
}
function numericBucketKey(x, y) {
  return x * 1e3 + y;
}
var spatialMembership = /* @__PURE__ */ new WeakMap();
function createSpatialIndex(entities, cellSize, previous) {
  const cached = previous && Object.is(previous.cellSize, cellSize) ? spatialMembership.get(previous) : void 0;
  let prefix = 0;
  if (cached && cached.members.length === entities.length) {
    let unchanged = true;
    for (let i = 0; i < entities.length; i += 1) {
      const entity = entities[i];
      if (cached.members[i] !== entity || !Object.is(cached.x[i], entity.x) && !Object.is(cached.cellX[i], Math.floor(entity.x / cellSize)) || !Object.is(cached.y[i], entity.y) && !Object.is(cached.cellY[i], Math.floor(entity.y / cellSize))) {
        unchanged = false;
        break;
      }
      cached.x[i] = entity.x;
      cached.y[i] = entity.y;
      prefix = i + 1;
    }
    if (unchanged) return previous;
  }
  const buckets = /* @__PURE__ */ new Map();
  if (cached) spatialMembership.delete(previous);
  const members = cached?.members ?? [];
  const cellX = cached?.cellX ?? [], cellY = cached?.cellY ?? [];
  const positionsX = cached ? cached.x : [], positionsY = cached ? cached.y : [];
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (let i = 0; i < entities.length; i += 1) {
    const entity = entities[i];
    const x = i < prefix ? cellX[i] : Math.floor(entity.x / cellSize);
    const y = i < prefix ? cellY[i] : Math.floor(entity.y / cellSize);
    members[i] = entity;
    positionsX[i] = entity.x;
    positionsY[i] = entity.y;
    cellX[i] = x;
    cellY[i] = y;
    left = Math.min(left, x);
    right = Math.max(right, x);
    top = Math.min(top, y);
    bottom = Math.max(bottom, y);
    const key = numericBucketKey(x, y);
    const bucket = buckets.get(key);
    if (bucket) bucket.push(entity);
    else buckets.set(key, [entity]);
  }
  members.length = cellX.length = cellY.length = positionsX.length = positionsY.length = entities.length;
  const index = { team: void 0, cellSize, buckets, left, right, top, bottom };
  spatialMembership.set(index, { members, cellX, cellY, x: positionsX, y: positionsY });
  return index;
}
var teamSpatialMembership = /* @__PURE__ */ new WeakMap();
function createTeamSpatialIndexes(game, entities, cellSize, previous) {
  const cached = previous ? teamSpatialMembership.get(previous) : void 0;
  let prefix = 0;
  if (cached && Object.is(cached.cellSize, cellSize) && cached.members.length === entities.length) {
    let unchanged = true;
    for (let i = 0; i < entities.length; i += 1) {
      const entity = entities[i];
      if (cached.members[i] !== entity || !Object.is(cached.x[i], entity.x) && !Object.is(cached.cellX[i], Math.floor(entity.x / cellSize)) || !Object.is(cached.y[i], entity.y) && !Object.is(cached.cellY[i], Math.floor(entity.y / cellSize)) || cached.teams[i] !== teamKey(game, entity.owner)) {
        unchanged = false;
        break;
      }
      cached.x[i] = entity.x;
      cached.y[i] = entity.y;
      prefix = i + 1;
    }
    if (unchanged) return previous;
  }
  const indexes = /* @__PURE__ */ new Map();
  const reusable = cached && Object.is(cached.cellSize, cellSize) ? cached : void 0;
  if (reusable) teamSpatialMembership.delete(previous);
  const members = reusable?.members ?? [];
  const cellX = reusable?.cellX ?? [], cellY = reusable?.cellY ?? [], teams = reusable?.teams ?? [];
  const positionsX = reusable ? reusable.x : [], positionsY = reusable ? reusable.y : [];
  for (let i = 0; i < entities.length; i += 1) {
    const entity = entities[i];
    const team = i < prefix ? teams[i] : teamKey(game, entity.owner);
    members[i] = entity;
    positionsX[i] = entity.x;
    positionsY[i] = entity.y;
    teams[i] = team;
    let index = indexes.get(team);
    if (!index) indexes.set(team, index = { team, cellSize, buckets: /* @__PURE__ */ new Map(), left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity });
    const x = i < prefix ? cellX[i] : Math.floor(entity.x / cellSize);
    const y = i < prefix ? cellY[i] : Math.floor(entity.y / cellSize);
    cellX[i] = x;
    cellY[i] = y;
    index.left = Math.min(index.left, x);
    index.right = Math.max(index.right, x);
    index.top = Math.min(index.top, y);
    index.bottom = Math.max(index.bottom, y);
    const key = numericBucketKey(x, y), bucket = index.buckets.get(key);
    if (bucket) bucket.push(entity);
    else index.buckets.set(key, [entity]);
  }
  members.length = cellX.length = cellY.length = teams.length = positionsX.length = positionsY.length = entities.length;
  teamSpatialMembership.set(indexes, { cellSize, members, cellX, cellY, teams, x: positionsX, y: positionsY });
  return indexes;
}
var entityIndexes = /* @__PURE__ */ new WeakMap();
function createEntityIndex(game) {
  const cached = entityIndexes.get(game.units);
  if (cached && cached.units === game.units.length && cached.buildings === game.buildings && cached.buildingCount === game.buildings.length) return cached.index;
  const index = /* @__PURE__ */ new Map();
  for (const unit of game.units) index.set(unit.id, unit);
  for (const building of game.buildings) index.set(building.id, building);
  entityIndexes.set(game.units, { units: game.units.length, buildings: game.buildings, buildingCount: game.buildings.length, index });
  return index;
}
function forEachNearbyUnit(game, point, range, visit) {
  forEachNearbyEntity(game.unitSpatial, game.units, point, range, (unit) => {
    if (!isInCabin(unit)) visit(unit);
  });
}
function firstNearbyUnit(game, point, range, test) {
  const index = game.unitSpatial;
  if (!index) return game.units.find((unit) => !isInCabin(unit) && test(unit));
  const size = index.cellSize;
  const right = Math.min(index.right, Math.floor((point.x + range) / size));
  const bottom = Math.min(index.bottom, Math.floor((point.y + range) / size));
  const top = Math.max(index.top, Math.floor((point.y - range) / size));
  for (let x = Math.max(index.left, Math.floor((point.x - range) / size)); x <= right; x += 1) {
    for (let y = top; y <= bottom; y += 1) {
      const bucket = index.buckets.get(numericBucketKey(x, y));
      if (!bucket) continue;
      for (const unit of bucket) if (!isInCabin(unit) && test(unit)) return unit;
    }
  }
  return void 0;
}
function forEachNearbyBuilding(game, point, range, visit) {
  forEachNearbyEntity(game.buildingSpatial, game.buildings, point, range, visit);
}
function forEachNearbyEnemyUnit(game, owner, point, range, visit) {
  const indexes = game.unitSpatialByTeam;
  if (!indexes) {
    forEachNearbyUnit(game, point, range, (unit) => {
      if (areEnemyOwners(game, owner, unit.owner)) visit(unit);
    });
    return;
  }
  const ownTeam = teamKey(game, owner);
  for (const index of indexes.values()) if (index.team !== ownTeam) forEachNearbyEntity(index, game.units, point, range, visit);
}
function forEachNearbyEnemyBuilding(game, owner, point, range, visit) {
  const indexes = game.buildingSpatialByTeam;
  if (!indexes) {
    forEachNearbyBuilding(game, point, range, (building) => {
      if (areEnemyOwners(game, owner, building.owner)) visit(building);
    });
    return;
  }
  const ownTeam = teamKey(game, owner);
  for (const index of indexes.values()) if (index.team !== ownTeam) forEachNearbyEntity(index, game.buildings, point, range, visit);
}
function forEachNearbyEntity(index, unindexedEntities, point, range, visit) {
  if (!index) {
    for (const entity of unindexedEntities) visit(entity);
    return;
  }
  const size = index.cellSize;
  const right = Math.min(index.right, Math.floor((point.x + range) / size));
  const bottom = Math.min(index.bottom, Math.floor((point.y + range) / size));
  const top = Math.max(index.top, Math.floor((point.y - range) / size));
  for (let x = Math.max(index.left, Math.floor((point.x - range) / size)); x <= right; x += 1) {
    for (let y = top; y <= bottom; y += 1) {
      const bucket = index.buckets.get(numericBucketKey(x, y));
      if (!bucket) continue;
      for (const entity of bucket) visit(entity);
    }
  }
}
function __observed_moveToward(unit, x, y, map, units = [], navalFrame = true) {
  const pace = statusPace(unit);
  if (pace === 0) return;
  if (navalFrame && shipProfile(unit)) {
    sailToward(unit, { x, y, ...unit.order.type === "move" && unit.order.heading !== void 0 ? { heading: unit.order.heading } : {} }, map, units, pace);
    return;
  }
  const knownEmpty = !navalFrame || groundShipFrameEmpty(units);
  if (!knownEmpty || unit.deck) {
    const ship = unit.deck && units.find((ship2) => ship2.id === unit.deck.shipId);
    const goal = deckGoal(unit, ship || void 0, { x, y }, units);
    if (walkConnectedSurfaces(unit, goal, units, map, pace)) return;
    if (unit.deck) {
      if (ship) moveOnDeck(unit, ship, goal, units, pace);
      return;
    }
  }
  const from = knownEmpty ? void 0 : { x: unit.x, y: unit.y };
  if (map.terrain) {
    walkToward(unit, x, y, map, pace);
    if (from) {
      const at = constrainGroundShipStep(map, unit, from, unit, units);
      if (at !== unit) {
        unit.x = at.x;
        unit.y = at.y;
      }
    }
    return;
  }
  const speed = perTick(unit.speed) * pace;
  const dx = x - unit.x;
  const dy = y - unit.y;
  const length = hypot2(dx, dy);
  if (length <= speed || length === 0) {
    unit.x = clamp(x, 0, map.width);
    unit.y = clamp(y, 0, map.height);
    if (from) {
      const at = constrainGroundShipStep(map, unit, from, unit, units);
      if (at !== unit) {
        unit.x = at.x;
        unit.y = at.y;
      }
    }
    return;
  }
  unit.x = clamp(unit.x + dx / length * speed, 0, map.width);
  unit.y = clamp(unit.y + dy / length * speed, 0, map.height);
  if (from) {
    const at = constrainGroundShipStep(map, unit, from, unit, units);
    if (at !== unit) {
      unit.x = at.x;
      unit.y = at.y;
    }
  }
}
function walkToward(unit, x, y, map, pace = 1) {
  const mover = unitMover(unit.kind);
  const goal = x >= 0 && y >= 0 && x <= map.width && y <= map.height && isWalkable(map, x, y, mover) ? { x, y } : walkableGoal(map, x, y, mover);
  const aim = steerPoint(map, unit, goal, mover);
  const dx = aim.x - unit.x;
  const dy = aim.y - unit.y;
  const length = Math.sqrt(dx * dx + dy * dy);
  if (length === 0) return;
  const speed = perTick(unit.speed) * pace * groundUnder(map, unit.x, unit.y, mover).pace;
  const nextX = clamp(length <= speed ? aim.x : unit.x + dx / length * speed, 0, map.width);
  const nextY = clamp(length <= speed ? aim.y : unit.y + dy / length * speed, 0, map.height);
  const step = openStep(map, unit, { x: nextX, y: nextY }, mover);
  unit.x = step.x;
  unit.y = step.y;
}
function distance(a, b) {
  return hypot2(a.x - b.x, a.y - b.y);
}
function distanceSquared(a, b) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return dx * dx + dy * dy;
}
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function isNumber(value) {
  return typeof value === "number" && Number.isFinite(value);
}
function __traceNative(event) {
  globalThis.__bootstrapNativeIntentTrace?.(event);
}
function __beforeNative(unit) {
  return { x: unit.x, y: unit.y, hp: unit.hp, order: { ...unit.order }, range: unit.attackRange, cooldown: unit.cooldown, pushX: unit.pushX, pushY: unit.pushY };
}
function moveToward(unit, x, y, map, units = [], navalFrame = true) {
  const before = __beforeNative(unit);
  __observed_moveToward(unit, x, y, map, units, navalFrame);
  __traceNative({ event: "moveToward", unit, before, goal: { x, y }, navalFrame, stack: new Error().stack });
}
function nearestEnemyTarget(game, unit, range, navalFrame = true) {
  const result = __observed_nearestEnemyTarget(game, unit, range, navalFrame);
  __traceNative({ event: "nearestEnemyTarget", unit, range, result, gap: result && targetGap(unit, result, navalFrame), stack: new Error().stack });
  return result;
}
function takeUpAttacker(game, unit, attacker, victim) {
  const before = __beforeNative(unit);
  __observed_takeUpAttacker(game, unit, attacker, victim);
  __traceNative({ event: "takeUpAttacker", unit, before, attacker, victim, gap: targetGap(unit, attacker), stack: new Error().stack });
}
function walkEnded(game, unit, goal, within) {
  const result = __observed_walkEnded(game, unit, goal, within);
  __traceNative({ event: "walkEnded", unit, goal, within, result });
  return result;
}
function arrive(unit, goal) {
  const before = __beforeNative(unit);
  __observed_arrive(unit, goal);
  __traceNative({ event: "arrive", unit, before, goal });
}
function updateAttackOrder(game, unit, navalFrame = true) {
  const before = __beforeNative(unit), target = unit.order.type === "attack" && findStrikeTarget(game, unit.order.targetId), gap = target && targetGap(unit, target, navalFrame);
  __observed_updateAttackOrder(game, unit, navalFrame);
  __traceNative({ event: "updateAttackOrder", unit, before, target, gap, navalFrame });
}
function backOutOfDeadZone(game, unit, target, navalFrame = true) {
  const before = __beforeNative(unit), result = __observed_backOutOfDeadZone(game, unit, target, navalFrame);
  __traceNative({ event: "backOutOfDeadZone", unit, before, target, result });
  return result;
}

// src/shared/sim/command-frame-runtime.ts
import { checkCommandLegality as checkCommandLegality3, narrowFrameCommandToLiveOperands as narrowFrameCommandToLiveOperands2 } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sim/command-validation.ts";

// src/shared/sim/frame.ts
import { checksumGame } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sim/checksum.ts";
import { checkCommandLegality as checkCommandLegality2, narrowFrameCommandToLiveOperands } from "/workspace/sketch-rts-land-army-base183-control/src/shared/sim/command-validation.ts";
function applyCommandFrame(game, frame, hooks = {}) {
  if (frame.tick !== game.tick) throw new Error(`Command frame ${frame.sequence} targets tick ${frame.tick} but game is at tick ${game.tick}`);
  for (const entry of frame.commands) {
    hooks.beforeApply?.(entry);
    issueFrameCommand(game, entry.playerId, entry.command);
    hooks.afterApply?.(entry);
  }
}
function issueFrameCommand(game, owner, command) {
  const currentCommand = narrowFrameCommandToLiveOperands(game, owner, command);
  if (!currentCommand) return;
  const legality = checkCommandLegality2(game, owner, currentCommand);
  if (legality?.transient) return;
  if (legality) throw new Error(legality.message);
  issuePlayerCommand(game, owner, currentCommand);
}

// src/shared/sim/command-frame-runtime.ts
function normalizeCommandFrameEntries(entries) {
  const normalized = [];
  let hiredCampIds;
  let pickedItemIds;
  for (const entry of entries) {
    if (entry.command.type === "hire") {
      hiredCampIds ??= /* @__PURE__ */ new Set();
      if (hiredCampIds.has(entry.command.campId)) continue;
      hiredCampIds.add(entry.command.campId);
    }
    if (entry.command.type === "pickupItem") {
      pickedItemIds ??= /* @__PURE__ */ new Set();
      if (pickedItemIds.has(entry.command.itemId)) continue;
      pickedItemIds.add(entry.command.itemId);
    }
    normalized.push(entry);
  }
  return normalized;
}
function advanceCommandFrameTick(game, frames, options = {}) {
  const frameList = Array.isArray(frames) ? frames : frames ? [frames] : [];
  for (const frame of frameList) applyCommandFrame(game, frame, options.applyHooks);
  stepGame(game);
}
var CommandFrameRuntime = class {
  constructor(options) {
    this.options = options;
  }
  options;
  nextSequence = 0;
  completeAndApply(commands, options = {}) {
    const frame = this.completeFrame(commands, options);
    if (!frame) return void 0;
    options.onFrame?.(frame);
    applyCommandFrame(this.options.game, frame, options.applyHooks);
    return frame;
  }
  tick(commands = [], options = {}) {
    const frame = this.completeFrame(commands, options);
    if (frame) options.onFrame?.(frame);
    advanceCommandFrameTick(this.options.game, frame, options.applyHooks ? { applyHooks: options.applyHooks } : {});
    return frame;
  }
  admit(commands, options = {}) {
    this.validate(normalizeCommandFrameEntries(commands), { purpose: "admission", rejectionLabel: options.rejectionLabel });
  }
  completeFrame(commands, options) {
    const normalizedCommands = normalizeCommandFrameEntries(commands);
    this.validate(normalizedCommands, { purpose: "apply", rejectionLabel: options.rejectionLabel });
    const aiCommands = options.includeAi === false ? [] : this.planAiCommands();
    const completedCommands = normalizeCommandFrameEntries([...normalizedCommands, ...aiCommands]);
    if (options.frame) return { ...options.frame, commands: completedCommands };
    if (completedCommands.length === 0) return void 0;
    const frame = {
      roomId: this.options.roomId,
      tick: this.options.game.tick,
      sequence: this.nextSequence,
      commands: completedCommands
    };
    this.nextSequence += 1;
    return frame;
  }
  planAiCommands() {
    if (!this.options.aiPlanner) return [];
    const checkpoint = this.options.aiPlanner.checkpoint();
    try {
      const commands = this.options.aiPlanner.plan();
      this.validate(commands, { purpose: "apply" });
      return commands;
    } catch (error) {
      this.options.aiPlanner.restore(checkpoint);
      throw error;
    }
  }
  validate(commands, options) {
    if (commands.length === 0) return;
    const game = this.options.game;
    for (const [index, entry] of commands.entries()) {
      const currentCommand = narrowFrameCommandToLiveOperands2(game, entry.playerId, entry.command);
      if (!currentCommand) continue;
      const legality = checkCommandLegality3(game, entry.playerId, currentCommand);
      if (legality && (options.purpose === "admission" || !legality.transient)) throw new Error(`${options.rejectionLabel?.(entry, index) ?? this.options.rejectionLabel}: ${legality.message}`);
    }
  }
};

// src/sdk/commands/frame.ts
function createSdkCommandFrameRuntime(game, options = {}) {
  return new SdkCommandFrameRuntime(game, options);
}
var SdkCommandFrameRuntime = class {
  constructor(game, options = {}) {
    this.game = game;
    this.runtime = new CommandFrameRuntime({ game, roomId: options.roomId ?? "sdk", rejectionLabel: "SDK command frame rejected" });
  }
  game;
  runtime;
  // `checksum: false` skips hashing the whole world after the frame, for callers that never read it (the game runner).
  issue(planned, hooks = {}, options = {}) {
    if (this.game.match.winner) return { commands: [] };
    const issued = normalizeCommandFrameEntries(planned);
    if (issued.length === 0) return { commands: issued };
    let entryIndex = 0;
    const appliedFrame = this.runtime.completeAndApply(
      issued.map((entry) => ({ playerId: entry.playerId, command: entry.command })),
      {
        rejectionLabel(entry, index) {
          const issuedEntry = issued[index];
          return `SDK command frame rejected ${issuedEntry?.playerId ?? entry.playerId} ${issuedEntry?.scriptId ?? "unknown"} command`;
        },
        applyHooks: {
          beforeApply() {
            hooks.beforeIssue?.(issued[entryIndex]);
          },
          afterApply() {
            hooks.afterIssue?.(issued[entryIndex]);
            entryIndex += 1;
          }
        }
      }
    );
    return { commands: issued, ...appliedFrame ? { frame: appliedFrame } : {}, ...options.checksum === false ? {} : { checksum: checksumGame2(this.game) } };
  }
  tick() {
    this.runtime.tick([]);
  }
};

// src/sdk/game-runner.ts
import { summarizeMatchState, summarizeTimelineSample } from "/workspace/sketch-rts-land-army-base183-control/src/sdk/match-report.ts";
import { normalizeWinnerForMode } from "/workspace/sketch-rts-land-army-base183-control/src/sdk/winner-mode.ts";
function runGameLoop(input, hooks = {}) {
  const game = input.game ?? createGame(requireMapId(input), {
    ...input.options ?? {},
    players: playersOf(input),
    aiPlayers: playersOf(input).filter((owner) => input.agents[owner]?.controller === "internal-ai"),
    teams: teamsOf(input),
    races: racesOf(input),
    ...input.options?.scenario ? { scenario: input.options.scenario } : {}
  });
  const players = playersOf(input);
  const teams = teamsOf(input);
  const loopContext = { game, players, teams };
  const frameRuntime = createSdkCommandFrameRuntime(game);
  const started = performance.now();
  const cpuStarted = process.cpuUsage();
  hooks.beforeLoop?.(loopContext);
  let current;
  while (game.tick < input.maxTicks && !game.match.winner) {
    if (game.tick % input.thinkInterval === 0) {
      current = issueDueAgentCommands(frameRuntime, game, input, loopContext, hooks, current);
    }
    hooks.beforeStep?.(loopContext);
    if (!hooks.afterStep) {
      frameRuntime.tick();
      normalizeWinnerForMode(game, teams, input.winnerMode ?? "match");
      current = void 0;
      hooks.onStep?.(loopContext);
      continue;
    }
    const before = current ?? snapshotGame(game);
    frameRuntime.tick();
    normalizeWinnerForMode(game, teams, input.winnerMode ?? "match");
    const after = snapshotGame(game);
    hooks.afterStep({ ...loopContext, before, after });
    current = after;
    hooks.onStep?.(loopContext);
  }
  const cpu = process.cpuUsage(cpuStarted);
  return {
    ...loopContext,
    snapshot: snapshotGame(game),
    elapsedMs: Number((performance.now() - started).toFixed(3)),
    cpuMs: Number(((cpu.user + cpu.system) / 1e3).toFixed(3))
  };
}
function issueDueAgentCommands(frameRuntime, game, input, loopContext, hooks, current) {
  if (!input.commandPlanner) return current;
  const snapshot = plannerView(game);
  const planned = playersOf(input).flatMap((owner) => {
    const agent = input.agents[owner];
    if (!agent) return [];
    const plannerOrigin = "local-command-planner";
    return input.commandPlanner({
      game,
      snapshot,
      owner,
      agent,
      source: traceSourceFor(agent),
      plannerOrigin,
      teams: loopContext.teams
    });
  });
  const { afterCommand, onCommand } = hooks;
  if (!afterCommand && !onCommand) {
    const { commands } = frameRuntime.issue(planned, {}, { checksum: false });
    return commands.length === 0 ? current : void 0;
  }
  let latest = current;
  frameRuntime.issue(
    planned,
    {
      beforeIssue() {
        if (afterCommand) latest ??= snapshotGame(game);
      },
      afterIssue(entry) {
        const event = {
          ...loopContext,
          tick: game.tick,
          owner: entry.playerId,
          source: requireCommandSource(entry),
          plannerOrigin: "local-command-planner",
          scriptId: entry.scriptId,
          command: entry.command
        };
        if (afterCommand) {
          const before = latest;
          latest = snapshotGame(game);
          afterCommand({ ...event, before, after: latest });
        } else {
          latest = void 0;
        }
        onCommand?.(event);
      }
    },
    { checksum: false }
  );
  return latest;
}
function plannerView(game) {
  return {
    tick: game.tick,
    equipmentVersion: 1,
    rateUnits: "perSecond",
    match: game.match,
    map: game.map,
    teams: { ...game.teams },
    players: game.players,
    units: game.units.slice(),
    buildings: game.buildings.slice(),
    resources: game.resources.slice(),
    mercenaryCamps: game.mercenaryCamps.slice(),
    ...game.shops ? { shops: game.shops.slice() } : {},
    items: game.items.slice(),
    projectiles: game.projectiles.slice(),
    effects: game.effects.slice(),
    ...game.corpses ? { corpses: game.corpses.slice() } : {},
    ...game.obstacles ? { obstacles: game.obstacles.slice() } : {},
    ...game.variants ? { variants: { ...game.variants } } : {}
  };
}
function playersOf(input) {
  return Object.keys(input.agents);
}
function teamsOf(input) {
  return Object.fromEntries(Object.entries(input.agents).map(([owner, agent]) => [owner, agent.team]));
}
function racesOf(input) {
  return Object.fromEntries(Object.entries(input.agents).flatMap(([owner, agent]) => agent.race === void 0 ? [] : [[owner, agent.race]]));
}
function traceSourceFor(agent) {
  return agent.traceSource ?? agent.controller;
}
function requireCommandSource(entry) {
  if (!entry.source) throw new Error(`SDK game runner command ${entry.scriptId} for ${entry.playerId} is missing trace source`);
  return entry.source;
}
function requireMapId(input) {
  if (!input.mapId) throw new Error("runGame requires mapId when no game is supplied");
  return input.mapId;
}
export {
  restoreSnapshotIntoGame,
  runGameLoop,
  snapshotGame
};
