三个真实医疗边界的原生本体核对：本包只读，不是新护理候选，不加hold/follow/aim/queued命令，不新开普通0或重跑600tick/矩阵。

原文件保持不变。外部esbuild模块只包装原生moveToward、nearestEnemyTarget、takeUpAttacker、walkEnded、arrive、updateAttackOrder及deadzone函数，原函数逐次原样delegate，记录前后输入和调用栈，不改变返回值。SDK原循环、原三方AI、原完整world/nextId/3mem输入仍使用各自旧源。三个窗口各17个既有完整checkpoint逐值相同；16245另外15tick物理包装和首pass/原档16个逐tick全等。这个等值是观测包装可采信的前提，并不称这些包装就是未加工生产模块。

| 实际窗口 | 单位自身射程 | 原生提前到达 | 首次主动追敌moveToward | 实际意义 |
|---|---:|---|---|---|
|183召唤7905→7921|1079 ravager52|7912|7914|7913 idle在230索敌选86.03外1088，随后真的折返追出护理方向；7920打20，7921被20反杀|
|旧5f弓手10425→10441|1072 footman55|无|无|10426..10440一直执行护理move，10440宏观改attackMove，10441对49.79内1353原地打16；不是建筑到达后的追击|
|旧5f弓手16245→16275|4294 horseArcher330|16246|16247..16260无|早停后实际原地反击，下一16260护理令才16261继续走；依然会受敌击，不等于安全|

7913的快照位移不能称作主动追击：第一次对应attack分支的moveToward调用是7914。原native arrive位置(2926.2815,3502.3891)，离nominal goal34.347，因塔body早停；7913选目标时gap86.030，保存帧末gap83.690，两者处于不同执行阶段，均大于自身52。自动索敌范围230与自身射程52必须区分。目标是1088，反击来源也为1088，不用敌方330替代自己射程。

10425的旧goal虽然近farm，但单位这一正常思考区间没有执行到它。所有walkEnded均false，未发生arrive。10441的开火来自新宏观attackMove，不能按任何“护理到达后自动重攻”归因。现goal-circle一概过滤因此产生真实假阳性。

16245不是“看到早idle就会追远敌”：16247 footman1072受球弩5023伤害后，help-call使rider先接690.473外的ballista目标；同一个unit update里，cooldown0的automaticCombatTarget用原score/hysteresis重选78.626内knight2670，进入实际attack分支前已经换成自己330可射目标，未发任何追敌moveToward。16250发箭、16255对2670造成7伤。16247→16260的坐标移动是native slide和与ravager2297的separateUnitPair，已由物理函数被动包装证实，而非自动追击。

这里阻住早停的楼是townHall1639(1520,3888,r48)，不是附近farm。native arrive点(1568.8711,3925.8376)，距nominal护理goal74.3；该点在native楼body提前到达语义内。16246帧末医师gap254.091仍在heal240外；16260因身体和医师实际运动变237.159，医师CD164，没有治疗。下一正常护理move主动继续接近，16270/71仍被knight5241及ravager2297打28+20到49HP；16275医师CD149仍无治疗。因此这只是无意追路未发生，并非绝对安全/已经治好/只能有益反击的证明。

最窄模型建议仅针对原filter职责“防止早停后意外主动追路”

1. 把nominal goal邻楼与“本轮真正可能提前到达”分开：复用native路径和restsAgainstGoalBody的同一接触语义，得到实际可执行停止点/ETA/bodyId；ETA大于正常15tick则本轮不据该楼拒goal。不能再拿直距或楼中心当实际到达。
2. 将原生有效攻击目标读入口共享为低层查询：idle230、retaliation接来的current、失效替换、automaticCombatTarget的cooldown及score差60重选，最后才判断自身range和guard-leash/deadzone是否会实际向敌移动。不能只看raw目标、selfRange>=230或任何近敌；16247就是远target同tick先被改掉的反证。
3. 原有room/威胁、医疗triage、care所有权及普通avoidCombat命令不动。这个模型不回答点是否绝对安全或一定治疗，不假装预测未来外力/新帮助事件。若候选点需解析到真正可执行的楼外终点，要用那个终点及道路重新评分，不能圆推点后沿用旧room。

需要共享的是已经存在的native目标查询/资格/score/投射物HP和重选语义。优先以一个只读native effective-target入口提供，而不是在AI重复“最近敌”排序或造Game兼容adapter。目标遍历tie顺序亦属原生语义；单抽cooldown/hysteresis十几行、另换AI枚举次序并不保证相同。可先外部read-only probe验证三输入，未授权据此立刻新0或替换生产filter。

适用边界：三实例足以证实统一的“原生是否主动追敌”行为分类，尚不足证明一个覆盖所有未来help-call/敌移动的绝对危险判据。rules2、冻结184、原正常资源/人口均不变；完整比赛与三路线/地图/种子泛化尚未完成。原容器未提交修改恢复缺口继续保留。
