from pathlib import Path
import json,math,gzip,subprocess,tarfile,io,hashlib
D=Path('/workspace/.playtest/bootstrap-care-native-intent-20261016')
load=lambda p:json.loads(Path(p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
cases={}
for name in ['7905','10425','16245']:
 d=load(D/f'native-intent-{name}.json');assert d['verification']['allCheckpointsExact']and d['verification']['sourceSimUnchanged']
 arrivals=[t for t in d['traces']if t['event']=='arrive']
 first=arrivals[0]['tick']if arrivals else None
 moves=[t for t in d['traces']if t['event']=='moveToward']
 automaticMoves=[t for t in moves if t['before']['order']['type']=='attack']
 acquisition=[t for t in d['traces']if t['event']=='nearestEnemyTarget']
 retaliation=[t for t in d['traces']if t['event']=='takeUpAttacker'and t['before']['order']!=t['unit']['order']]
 entry=d['patientStates'][0]['patient']
 row={'source':d['source'],'patient':d['patientId'],'ownWeaponRange':entry['attackRange'],
  'nativeObservedArrival':[{'tick':t['tick'],'position':{'x':t['unit']['x'],'y':t['unit']['y']},'nominalGoal':t['goal'],
    'remainingNominalDistance':math.hypot(t['unit']['x']-t['goal']['x'],t['unit']['y']-t['goal']['y'])}for t in arrivals],
  'activePursuitMoveCalls':[{'tick':t['tick'],'before':t['before'],'goal':t['goal'],'afterPosition':{'x':t['unit']['x'],'y':t['unit']['y']},'stack':t['stack']}for t in automaticMoves],
  'acquisition':[{'tick':t['tick'],'requestedQueryRange':t['range'],'gapAtSelection':t.get('gap'),'targetId':t.get('result',{}).get('id'),'orderAtSelection':t['unit']['order'],'stack':t['stack']}for t in acquisition],
  'retaliation':[{'tick':t['tick'],'attacker':t['attacker']['id'],'victim':t['victim']['id'],'gap':t['gap'],'orderBefore':t['before']['order'],'orderAfter':t['unit']['order']}for t in retaliation],
  'hits':[{'tick':h['tick'],'attacker':h['attacker']['id'],'target':h['target']['id'],'damage':h['taken'],'hpBefore':h['hpBefore'],'hpAfter':h['target']['hp']}for h in d['hits']],
  'healerSamples':[{'tick':r['tick'],'patientHP':r.get('patient',{}).get('hp'),'healerGap':r.get('gap'),'healerCooldown':r.get('healer',{}).get('abilityCooldowns',{}).get('heal')}for r in d['patientStates']if r['tick']in [7905,7912,7913,7920,7921,10425,10440,10441,16245,16246,16247,16260,16270,16271,16275]],
  'verification':d['verification']}
 cases[name]=row
assert cases['7905']['activePursuitMoveCalls'][0]['tick']==7914
assert not cases['10425']['nativeObservedArrival']
assert not cases['16245']['activePursuitMoveCalls']
physics=load(D/'physics/native-intent-16245.json');assert physics['verification']['allCheckpointsExact']
physical=[]
for event in physics['traces']:
 if event['event']not in ['slideUnits','separateUnitPair','keepUnitsOutOfBuildings']:continue
 before=event['before'];unit=event['unit'];dx=unit['x']-before['x'];dy=unit['y']-before['y']
 if abs(dx)+abs(dy)>1e-8:physical.append({'tick':event['tick'],'event':event['event'],'peer':event.get('peer',{}).get('id'),'dx':dx,'dy':dy})
originalPhysics=load(D/'physics/equivalence-to-first-pass.json');assert all(r['allCompleteEqual']for r in originalPhysics)
sourceAudits={}
for source in sorted(set(c['source']for c in cases.values())):
 root=Path(source);commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);assert not status
 archive=subprocess.check_output(['git','archive',commit,'src','scripts','docs/engineering/bootstrap_1/frozen-policy.json'],cwd=root)
 files={};missing=[]
 with tarfile.open(fileobj=io.BytesIO(archive))as t:
  for member in t.getmembers():
   if not member.isfile()or not(member.name.endswith('.ts')or member.name.endswith('.json')or member.name.endswith('.gz')):continue
   p=root/member.name
   if not p.exists():missing.append(member.name);continue
   expected=sha(t.extractfile(member).read());actual=sha(p.read_bytes());assert expected==actual,(source,member.name)
   files[member.name]=actual
 sourceAudits[source]={'commit':commit,'status':status,'comparedExistingSourceFiles':len(files),'files':files,'notCheckedOut':missing,
  'manifestSHA256':sha((root/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes())}
result={'classification':'Read-only native control-intent audit of three already recorded actual old-source care boundaries. Passive wrappers observationally exact at every recorded reference checkpoint; no new candidate, policy changes, commands or ordinary0.',
 'cases':cases,'physicalMotion16246to16260':physical,'sources':sourceAudits,
 'findings':['7905: actual outside-own-range automatic chase begins7914, after idle acquisition7913; the7913 position change alone was not an active chase call.',
  '10425: no native arrival before next normal think;10440 macro attackMove causes10441 in-range native shot. No post-arrival autonomous pursuit exists in this care window.',
  '16245: help-call initially picks far ballista690.47, but same-tick automatic reconsideration picks in-range knight78.63 before any walk. No active pursuit call16247..16260; motion is native slide/separation, healer gap enters240 only by16260, no heal before16275. Still suffers28+20 at16270/71.',
  'These establish a native behavior discriminator, not a universal safety predicate. Own-range coverage does not imply protection from incoming fire, a completed medical approach, or absence of future help-call pursuit.'],
 'minimalNextDesignForReviewOnly':['Gate any geometric decision by actual ability to encounter the obstructing body before the next normal think; do not reject a distant nominal goal that cannot be reached this think (10425).',
  'A nearby building is not by itself an unsafe care endpoint. Evaluate the native executable stopping point and remaining care objective separately from the nominal goal.',
  'If a future online pursuit-risk helper is proposed, it must reuse actual native effective target selection including own range, cooldown, retaliation and automatic reconsideration. Any-local-enemy-in-range or ownRange>=230 alone is insufficient.',
  'Before another policy candidate, compare concrete executable outside-body alternatives by actual road and existing threat/heal scoring. Do not introduce hold/follow, queue, owner or memory changes or globally remove all geometry checks.'],
 'remaining':['No online uniform danger rule proved from only these three states; no new implementation/ordinary0 is authorized by this artifact.','Original container uncommitted recovery gap persists.','Full bootstrap families/opponents/maps/seeds acceptance remains incomplete.']}
(D/'native-intent-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':{k:{'ownRange':v['ownWeaponRange'],'arrivals':[r['tick']for r in v['nativeObservedArrival']],'firstPursuit':v['activePursuitMoveCalls']and v['activePursuitMoveCalls'][0]['tick'],'exactCheckpoints':v['verification']['count']}for k,v in cases.items()},'sourceCounts':{s:v['comparedExistingSourceFiles']for s,v in sourceAudits.items()}},ensure_ascii=False))
