import collections,gzip,hashlib,json,pathlib,re,subprocess
D=pathlib.Path('/workspace/.playtest/land-passenger-boarding-0f5bf')
O=pathlib.Path('/workspace/.playtest/passenger-boarding-independent-review')
S=pathlib.Path('/tmp/sketch-rts-land-passenger-boarding-0f5bf-control')
B=pathlib.Path('/tmp/sketch-rts-timeout-witness-0f5bf-baseline')
ACTUAL=pathlib.Path('/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.load(gzip.open(p) if p.suffix=='.gz' else p.open())
project=lambda x:{k:x[k] for k in ['snapshot','nextId','memories']}
write=lambda name,x:(O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
ids=['unit-p0-emberRavager-5447','unit-p0-emberRavager-5665']
old=(B/'src/ai/bootstrap_1/worker-boarding.ts').read_text()
norm="import { unitMover } from '../../shared/catalog';\n"+re.sub(r'\bworker\b','passenger',old.replace('workerBoardingSafe','passengerBoardingSafe'))
norm=norm.replace("passenger.kind !== 'passenger'","unitMover(passenger.kind) !== 'land'")
normalizedHelperExact=norm==(S/'src/ai/bootstrap_1/passenger-boarding.ts').read_text()
oldTest=(B/'src/ai/bootstrap_1/worker-boarding.test.ts').read_text()
normalizedWorkerTestExact=oldTest.replace('workerBoardingSafe','passengerBoardingSafe').replace("'./worker-boarding'","'./passenger-boarding'")==(S/'src/ai/bootstrap_1/worker-boarding.test.ts').read_text()

cap=load(D/'candidate-source.json');contCap=load(D/'candidate-continuation-source.json')
changed=[p for p,h in cap['hashes'].items() if not (S/p).exists() or sha(S/p)!=h]
capsEqual=cap['hashes']==contCap['hashes']
baseline=load(D/'baseline-22200-23400-report.json');candidate=load(D/'candidate-22200-23400-report.json')
full22200=project(load(ACTUAL/'ordinary0.frames/22200.json.gz'))
full23400=project(load(ACTUAL/'ordinary0.frames/23400.json.gz'))
checks={}
checks['bothRestoredSameActual22200FullWorldId3Mem']=all(project(load(D/f'{side}-22200-23400.frames/22200-before-first-think.json.gz'))==full22200 for side in ['baseline','candidate'])
checks['baselineFinalEqualsActual23400FullWorldId3Mem']=project(baseline['final'])==full23400
for side,r in [('baseline',baseline),('candidate',candidate)]:
 checks[side+'ReportFinalEqualsPersistedFullFinal']=r['final']==load(D/f'{side}-22200-23400-final.json')
 for label in ['commands','hits','events']:
  rows=[json.loads(l) for l in (D/f'{side}-22200-23400-{label}.jsonl').open()]
  checks[side+label+'ReportEqualsNativeJSONL']=rows==r[label]
origcmd=[json.loads(l) for l in (ACTUAL/'ordinary0-public-commands.jsonl').open() if 22200<=json.loads(l)['tick']<23400]
orighits=[json.loads(l) for l in (ACTUAL/'ordinary0-native-hits.jsonl').open() if 22200<json.loads(l)['tick']<=23400]
checks['baselineAll303CommandsEqualOriginalTrue0']=baseline['commands']==origcmd
checks['baselineAll98NativeHitsEqualOriginalTrue0']=baseline['hits']==orighits

replay=load(D/'candidate-22500-23400-report.json')
start22500=project(load(D/'candidate-22200-23400.frames/22500-before-next-think.json.gz'))
checks['candidateColdRestore22500InputExact']=project(load(D/'candidate-22500-23400.frames/22500-before-first-think.json.gz'))==start22500
checks['candidateColdRestoreCompleteFinalWorldId3MemExact']=replay['final']==candidate['final']
checks['candidateColdRestore901FullStateHashesExact']=replay['tickHashes']==[x for x in candidate['tickHashes'] if x['tick']>=22500]
checks['candidateColdRestoreAllCommandsExact']=replay['commands']==[x for x in candidate['commands'] if x['tick']>=22500]
checks['candidateColdRestoreAllHitsExact']=replay['hits']==[x for x in candidate['hits'] if x['tick']>22500]
expectEvents=[x for x in candidate['events'] if x['tick']>22500 or x['tick']==22500 and x['stage'] in ['after-command','before-step']]
mapped=[]
for x in replay['events']:
 x=dict(x)
 if 'commandIndex' in x:x['commandIndex']+=69
 mapped.append(x)
checks['candidateColdRestoreAll56EventsExceptDocumentedLocalRecorderIndexOffsetExact']=mapped==expectEvents
checks['candidateColdRestoreRawLiteralEventsEqual']=replay['events']==expectEvents

window={}
for side,r in [('baseline',baseline),('candidate',candidate)]:
 terms=[e for e in r['events'] if e['type']=='native-unit-terminal' and e['permanent']]
 assert len(terms)==len({e['id'] for e in terms})
 p0=[e for e in terms if e['previous']['owner']=='p0']
 enemy=[e for e in terms if e['previous']['owner'] in ['p1','p2']]
 window[side]={'start':r['start'],'end':r['end'],'result':r['result'],'commands':len(r['commands']),'hits':len(r['hits']),'events':len(r['events']),
 'p0PermanentLosses':len(p0),'p0WorkerLosses':sum(e['previous']['kind']=='worker' for e in p0),'p0NonworkerPermanentLosses':sum(e['previous']['kind']!='worker' for e in p0),'enemyPermanentLosses':len(enemy),'uniquePermanentTerminalEvents':terms,
 'patients':{i:{'terminalTick':next(e['tick'] for e in terms if e['id']==i),'outgoingHits':[h for h in r['hits'] if h['attacker']==i]} for i in ids},'sourcePre':r['sourcePre'],'sourcePost':r['sourcePost'],'frozenPre':r['frozenPre'],'frozenPost':r['frozenPost']}
firstDiff=next({'commandIndex':i,'baseline':a,'candidate':b} for i,(a,b) in enumerate(zip(baseline['commands'],candidate['commands'])) if a!=b)
queryProof={}
for name in ['baseline21885','candidate21885','candidate22335','baseline22515','candidate22515']:
 r=load(D/(name+'-pipeline.json'))
 queryProof[name]={k:r[k] for k in ['tick','restoredExactWorldId','nativeWorldUnchanged','commandsNotIssued','originalEntriesMatch','originalP0AfterMemoryMatch','sourceChanges','entries']}
write('independent-numeric-closure.json',{'classification':'Read-only recomputation from completed files; no simulation, production edits or test execution.','checks':checks,'eventMapping':{'rawLiteralEqual':checks['candidateColdRestoreRawLiteralEventsEqual'],'mapping':'Only per-recorder commandIndex replay+69; all other event fields compared literally. Include tick22500 after-command/before-step events because the checkpoint is before those commands.','expectedEvents':len(expectEvents)},'window':window,'firstActualCandidateCommandDifference':firstDiff,'pureQueriesOnOriginalTrajectory':queryProof})

finding={
 'classification':'Independent read-only production and test-contract review. Candidate is base0f5bf plus an immutable uncommitted diff identified by source manifests, not a distinct committed head. No new game/replay/tests, no edits to candidate/baseline/root sources.',
 'baseHead':cap['head'],'candidate':str(S),'productionPatch':str(D/'production.patch'),'productionPatchSHA256':sha(D/'production.patch'),
 'sourceManifests':{'window':{'path':str(D/'candidate-source.json'),'sha256':sha(D/'candidate-source.json'),'files':len(cap['hashes'])},'continuation':{'path':str(D/'candidate-continuation-source.json'),'sha256':sha(D/'candidate-continuation-source.json'),'files':len(contCap['hashes'])},'sameRuntimeHashes':capsEqual,'changesAtReview':changed},
 'blockingProductionFindings':[],
 'workerValueEquivalence':{'normalizedHelperExact':normalizedHelperExact,'explanation':'Only added unitMover import, identifier/module rename and kind gate generalization. For a real worker, unitMover(worker.kind) is land, so both old/new early kind gates are false; every remaining geometry, projectile, alongside/canBoard and return expression is identical.','oldWorkerTestsUnchangedAssertionsModuloNames':normalizedWorkerTestExact},
 'entryPointReview':[
 {'entry':'planBootstrapNaval existing board cancellation','files':['src/ai/bootstrap_1/expedition-recovery.ts:36'],'finding':'Only own nondeck land boarders with a real own ferry mission are considered; unsafe ones enter released, leave crewIds and get explicit stop. Actual deck/cross-deck work is excluded. No new owner or TTL.'},
 {'entry':'ferryCommands new worker or soldier selection','files':['src/ai/policy/naval.ts:839','src/ai/policy/naval.ts:845','src/ai/bootstrap_1/expedition-recovery.ts:78'],'finding':'The existing worker callback is renamed boardingAvailable and used for all ferry-purpose worker and soldier recruitment. The exact callback rejects same-think released IDs and invokes the shared safety helper. Existing source/target, troop-care, mass, real deck packing and defender checks remain.'},
 {'entry':'planSettlerBoarding supplemental worker recruitment','files':['src/ai/bootstrap_1/ferry-preparation.ts:20','src/ai/bootstrap_1/ferry-preparation.ts:46'],'finding':'All primary commands including the just-created stop reserve that ID, and the helper is identical for workers. Its native-order candidates idle/mine also exclude actual pre-snapshot boarders.'},
 {'entry':'combat-hull home recruitment and navalServices shore maintenance','files':['src/ai/policy/naval.ts:479','src/ai/policy/naval-services.ts:94'],'finding':'These existing separate roles do not consume boardingAvailable. They cannot reclaim a same-think released unit because immutable native order is still board and their candidates exclude board/require idle or hold. They are outside the newly guarded ferry recruitment scope; this patch is not proof every public board in the whole AI is now safety-gated.'},
 {'entry':'rider crossing and shore transfer','files':['src/ai/bootstrap_1/rider-crossing.ts:104','src/ai/bootstrap_1/shore-transfer.ts'],'finding':'Rider crossing schedules a mission but does not itself publish new board and excludes existing board orders from new rider selection. Shore transfer acts only on real deck passengers, so it cannot reboard a released nondeck passenger. Existing cross-deck tasks remain.'},
 {'entry':'later land commands and stop survival','files':['src/ai/bootstrap_1/expedition-recovery.ts:82','src/ai/policy/script-runner.ts:57'],'finding':'The current snapshot board order excludes released patients from same-think recovery/local combat/departure, so their stop is not stripped by local tactical or recovery reservations. Other scripts retain the naval claim/boarding conflict filter for this think. Next native frames may attack or retreat, but stop is not itself a measured rescue.'}
 ],
 'testReview':{'existing':'56 existing tests had assertions preserved; later combined run66/66 and final new10/10 logs read, not rerun by reviewer.','newCases':'Three-route real22515 release, three-route public-stop fresh-recruit refusal, real reconstructed21885 safe recruitment, real archer loading/deck positive, native alongside217155 attach next tick from a separate explicitly identified match, existing cross-deck summoner task. Tests exercise observable commands, memory, native attach and fixture restore rather than just helper-internal implementation.','boundaries':'Nearship requires alongside AND actual canBoard; deck bypass preserves live transfers. Frozen opponents/native simulation are unchanged.','typescript':'Second tsc failure preserved; author clarified the fix snapshot.teams -> f.game.teams, which is valid because Game explicitly overrides optional GameSnapshot.teams with required Record at sim.ts90..99. Third invocation reported exit0, final new tests10green; no source change needed after freeze.'},
 'evidenceClassificationCorrections':['21885 and22335 are safe pure-query points; they do not imply all intervening ticks safe. Actual changed-source candidate first diverges at22365 stop5665, then22410 stop5447.22515 stop-two is a counterfactual query on the original trajectory.','Original 1200window samples[].owners[].miningWorkers incorrectly tested native order gather; it must be ignored. Full world orders, native streams, final fullstate and the independent closure remain literal. The continuing observer uses mine; it is not a policy hot change.','Cold JSON event arrays are not raw-literal-equal: per-recorder commandIndex +69 is documented. All game fields, world/id/3mem,901tickhashes,commands,hits and every other event field compare fully; original22500 after-command birth must be retained.'],
 'measuredLocalOutcome':'22200→23400 changed-code candidate permanent P0 losses9(5nonworker+4worker)→3(2nonworker+1worker); enemy permanent1→3. Both original patients still die, with outgoing native hits0/0→2/8. No natural winner at23400; complete continuation is active under author ownership. No claim of full-match gain or bootstrap acceptance.',
 'limitations':['No independent game or tests were run. Numerical recomputation and static source review only.','The existing finite weapon-road probes and static current enemy coverage are preserved; this patch does not promise future moving-threat, item/spell or all-time landing safety.','Canceling board is not proof the patient survives or a local combat module immediately issues a command.','The broken original-container uncommitted-source recovery gap remains unchanged.']
}
write('FINAL-CANDIDATE-REVIEW.json',finding)
write('INDEX.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.iterdir()) if p.is_file() and p.name!='INDEX.json'}})
assert normalizedHelperExact and normalizedWorkerTestExact and capsEqual and not changed
assert all(v for k,v in checks.items() if k!='candidateColdRestoreRawLiteralEventsEqual')
print(json.dumps({'review':str(O/'FINAL-CANDIDATE-REVIEW.json'),'sha256':sha(O/'FINAL-CANDIDATE-REVIEW.json'),'allFullStateAndNativeStreamChecks':True,'rawEventsLiteralEqual':checks['candidateColdRestoreRawLiteralEventsEqual'],'workerHelperEquivalent':normalizedHelperExact}))
