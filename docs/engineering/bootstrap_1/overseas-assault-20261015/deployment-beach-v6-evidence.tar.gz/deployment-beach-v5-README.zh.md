# v5 卸前协同反证与原生执行器原因

v3 89310完整双方AI复演至89641与原 first-land世界/nextId/双方memories均完全一致，取得实际89625未卸载状态。v5从该状态正常双方AI至93000，不是普通0开局或验收。按现有450近船直距+真实海路组队，逐船逐员 native 落点在 shadow 中占位；全可落且全停才放原unload。没有改required/cancel/资源人口/冻结对手。

89895已同时发两份unload，但89896仅3824的15人落地，3510的14人仍在船上：原生ferryUnits拒绝本tick移动/转向的船卸兵，helm unload当tick重新启动3510，3824因原生路由规划停顿才落地。不是查询落点不存在。

从同一89625完整重演至89896，world/nextId/双mem逐值全等（proof附）；before89895 fullframe供下一候选合法立即portrait卸载的单步对照。

93000最终partition={'currentDeck': 0, 'currentGroundOnTarget': 0, 'currentElsewhere': 14, 'dead': 15}，everLand=15，enemyBuildings=20，hall=900，winner=None。源码全程pre/postflight通过，source capsule已重新验冻结184件。规则2，原容器未提交修改缺口仍在，不归属不同源码成绩。
