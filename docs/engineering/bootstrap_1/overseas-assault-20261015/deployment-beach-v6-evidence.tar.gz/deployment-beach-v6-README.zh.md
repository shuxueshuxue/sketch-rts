# 跨海出征 v6：实际共同登陆与完整胜局

基线为隔离的 rulesVersion 2 183b84879b97902fcb57e9acadbce62b0fcfb872；源码 capsule 包含858个运行源/相关文件，冻结 manifest184件的 revision d1ae110f2edd99f9c7d899ed61557891ab587639 已验证。没有修改 main、root活动源码、资源/人口/地图/出生规则、required 或取消判定；不声称恢复原容器未提交改动。

## 两条独立接续及实际结果

1. 原始未经手工干预88110 full world+nextId+双方memories，固定v6正常双方AI至91820：p0自然获胜，敌楼0。29名原船员全在90031同tick实际登陆；终24敌岛存活、5死、0deck、0其他陆地。敌方冻结v5 Ember正常资源人口；本方v9_archer Grove；官方sapphireArchipelago，bootstrap_1-development seed。
2. v3实际89310存档完整重演至89625（并至89641与原世界/nextId/双mem全等），在89625换为固定v6正常双方AI至91945：p0自然获胜，敌楼0；29人全在89896同tick真正登陆；终21敌岛存活、8死、0deck、0其他陆地。

两条均保留各自换码前历史；都是既有实战完整双方AI的换码后续跑，并非true0普通开局、独立新比赛或bootstrap最终验收，不混用成绩。源恢复、双方memory恢复、运行前后源码哈希全部通过。ordinary frozen opponents及三路线全部单/双对手官方/未见种子最终要求仍未完成。

## 原因与改动

原89040取消由新spirit使真实未来登陆力量低于required引起，而非450船距。单纯保留敌岸目标或强制单波卸载都失败。v3避免不安全半途误卸后，仍只有15人先落地被歼；v4安全hold仍不及另一船部署。v5先对同目标/同海路近船（直距和真实海路均<=450）逐船逐员原生落点顺序占位，并等两船实际停稳，但普通helm unload又在模拟tick中启动3510；3824只因规划停顿卸15人，另一14留船后返，仍败（独立v5反证包附）。

v6保留原强度与cancel，在已改选安全泊位的现有naval owner中，为全组已停稳、每个实际原生落点可落且无当前敌武器覆盖的29名船员，生成公开unloadPassenger指令。指令立即按真实船位合法执行，避免helm下一tick转向造成另一半无法卸载。没有搬动世界/造兵/恢复取消intent，也未把半甲板伤害当完整地面火力。实际既有舰炮不增加，战斗能力来自真实整体登陆。

原88110续跑相对v3首次公开命令差异是89490阻止3824单独helm卸载；90030实际发29条公开portrait卸载，90031全29真上岸。存档/命令/命中/全部建筑摧毁记录见各json及full frames。first-land与91110战斗、终局图片由原生客户端renderer渲染，已人工视觉检查部队确已全组上岸并推进敌基地。

## 验证与交付

22项相关测试及tsc通过，包含真实89895单步因果对照：原命令+原生一步精确复现旧输出与14人仍船上；仅换为公开portrait卸载后29人合法同刻部署。三路线fixture context是共享行为查询，不伪称三条新路线完整比赛。

完整增量补丁deployment-beach-v6-complete.patch包含3处已有文件增量、新174行helper、新测试和5份实际fullframe gzip fixture；SHA b8d18e8dcef98430e4bf8e799fa9e98f18aaea6fe658ad16ed9e13199ff64f00。补丁在已修改树反向check通过。不要整份覆盖root最新naval/general/sim；root已有其他独立增量，应按hunk合并。

已完成独立实验只在运行和source-postflight完成后sparse移出重复tracked docs/art与历史tar包，未动任何原.playtest或运行源。所有本轮新frames/archive位于/tmp。下一步是合并最小增量后以整合后的固定源码验证普通开局与另外两路线及未见种子；本包两局胜利不是最终里程碑。
