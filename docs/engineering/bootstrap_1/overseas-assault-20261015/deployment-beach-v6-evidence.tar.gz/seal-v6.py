from pathlib import Path
import json,hashlib,tarfile,io
p=Path('/tmp/bootstrap-deployment-gate');old=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015')
names=['deployment-beach-v6-README.zh.md','deployment-beach-v6-source.json','deployment-beach-v6-source.tar.gz','deployment-beach-v6-source.patch','deployment-beach-v6-complete.patch','deployment-beach-v6-production-files.json','deployment-beach-v6-source-final-verification.json','deployment-beach-v6-public-command-proof.json','deployment-beach-v6-native-ready-query.json','deployment-beach-v6-input88110.json','deployment-beach-v6-original-crew.json','v6-focused-tests.log','v6-tsc.log','complete-run.mts','source-capture.py','render-frame.mts','deployment-query.mts','prelanding-capture.mts','pre-coordinated-unload-capture.mts','deployment-beach-v3-prelanding-exact-proof.json','deployment-beach-v5-pre-discharge-proof.json','deployment-beach-v5-evidence.tar.gz','deployment-beach-v5-README.zh.md','seal-v6.py']
files={n:p/n for n in names}
for prefix in ['deployment-beach-v6-focused','deployment-beach-v6-original88110']:
 for suffix in ['.json','.log','-source-postflight.json']:files[prefix+suffix]=p/(prefix+suffix)
 for f in (p/(prefix+'.frames')).glob('*.json'):files[str(f.relative_to(p))]=f
for f in p.glob('deployment-beach-v6*png'):files[f.name]=f
for n in ['before-think-89625.json']:
 f=p/'deployment-beach-v3-prelanding.frames'/n;files['lineage/v3-prelanding/'+n]=f
for n in ['before-think-89895.json','terminal-89896.json']:
 f=p/'deployment-beach-v5-pre-discharge.frames'/n;files['lineage/v5-pre-discharge/'+n]=f
for n in ['deployment-beach-v3-source.json','deployment-beach-v3-source.tar.gz','deployment-beach-v3-source.patch']:
 files['lineage/'+n]=old/n
files['lineage/v3-sample-89310.json']=old/'deployment-beach-v3.frames/sample-89310.json'
index={'classification':'Rules2 183b isolated v6 source: two distinct changed-source saved real-match continuations, no true0 or final acceptance claim','payload':{n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}}
arc=p/'deployment-beach-v6-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n)
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('INDEX.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(arc,'r:gz') as t:
 got=json.loads(t.extractfile('INDEX.json').read()); assert len(t.getmembers())==len(files)+1
 for n,v in got['payload'].items():
  data=t.extractfile(n).read();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'],n
result={'archive':str(arc),'bytes':arc.stat().st_size,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'payloadFiles':len(files),'fullV6Frames':sum(1 for n in files if '.frames/' in n),'verified':True}
(p/'deployment-beach-v6-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
