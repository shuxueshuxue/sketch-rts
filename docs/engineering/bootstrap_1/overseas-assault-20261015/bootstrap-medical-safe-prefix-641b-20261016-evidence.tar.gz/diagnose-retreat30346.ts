import { readFileSync,writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const D='/tmp/bootstrap-medical-safe-prefix-8da-20261016', S='/tmp/sketch-rts-medical-safe-prefix-8da-control', B='/workspace/sketch-rts-root-medical-8da5-fixed-control';
const hash=(v:any)=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
async function run(source:string,tick:number){
 const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
 const [{setBuildingBodies,steerPoint},{planMedicalRecoveryTasks,recoveryPatients},{armedFoes},{medicalRoadIsSafe,medicalApproachRoad},{mountedThreatReach,THINK_TICKS},{hostileDamageDisks},{pointSegmentDistanceSquared},{SIM_TICKS_PER_SECOND},{abilityCooldown},{planBootstrapCasterScreen}]=await Promise.all([load('src/shared/terrain.ts'),load('src/ai/bootstrap_1/medical-recovery.ts'),load('src/ai/bootstrap_1/safe-land-route.ts'),load('src/ai/bootstrap_1/medical-task-safety.ts'),load('src/ai/bootstrap_1/mounted-micro.ts'),load('src/ai/bootstrap_1/damage-footprints.ts'),load('src/shared/navigation-math.ts'),load('src/shared/time.ts'),load('src/shared/ability-cooldowns.ts'),load('src/ai/bootstrap_1/caster-screen.ts')]);
 const path=S+'/src/ai/bootstrap_1/fixtures/medical-retreat-'+tick+'.json.gz', raw=readFileSync(path), full=JSON.parse(gunzipSync(raw).toString()), before=hash(full),s=full.snapshot,options={version:'v9_archer',teams:s.teams,memory:full.memories.p0};
 setBuildingBodies(s.map,[...s.buildings,...s.obstacles??[]]);
 const foes=armedFoes(s,'p0',options),patients=recoveryPatients(s,'p0'),tasks=planMedicalRecoveryTasks(s,'p0',patients,options),backline=planBootstrapCasterScreen(s,'p0',options);
 const healers=s.units.filter((u:any)=>u.owner==='p0'&&['priest','fieldMedic'].includes(u.kind));
 const approaches=healers.flatMap((healer:any)=>patients.map((patient:any)=>{
   const point=steerPoint(s.map,healer,patient),road=medicalApproachRoad(s,healer,patient,240),first=medicalApproachRoad(s,healer,point,0);
   const disks=[...foes.map((foe:any)=>({id:foe.id,kind:foe.kind,x:foe.x,y:foe.y,radius:mountedThreatReach(s,foe,healer,THINK_TICKS)+('speed'in foe?foe.speed*THINK_TICKS/SIM_TICKS_PER_SECOND:0)})),...hostileDamageDisks(s,healer,foes,THINK_TICKS).map((d:any)=>({...d,id:'area'}))];
   const margins=(path:any)=>disks.map((d:any)=>({id:d.id,kind:d.kind,radius:d.radius,start:Math.hypot(healer.x-d.x,healer.y-d.y)-d.radius,road:path?Math.min(...path.slice(1).map((p:any,i:number)=>Math.sqrt(pointSegmentDistanceSquared(d,path[i],p))-d.radius)):null})).sort((a:any,b:any)=>a.road-b.road);
   return {healer:healer.id,patient:patient.id,distance:Math.hypot(healer.x-patient.x,healer.y-patient.y),ready:abilityCooldown(healer,'heal')<=0,fullRoadSafe:medicalRoadIsSafe(s,healer,patient,240,foes),fullRoad:road,firstPoint:point,firstRoad:first,firstSafe:medicalRoadIsSafe(s,healer,point,0,foes),firstMargins:margins(first).slice(0,4),fullMargins:margins(road).slice(0,4)};
 }));
 const result={source,tick,input:path,inputSHA256:createHash('sha256').update(raw).digest('hex'),general:full.memories.p0.v6.general,healers,patients,tasks:{commands:tasks.commands,occupied:[...tasks.occupied],released:[...tasks.released],casting:[...tasks.casting]},backline,approaches,fullStateUnchanged:before===hash(full)};
 if(!result.fullStateUnchanged)throw Error('pure leaf mutated input');return result;
}
const cases=[];for(const tick of [30346,30600])for(const source of [B,S])cases.push(await run(source,tick));
writeFileSync(D+'/RETREAT30346-PURE.json',JSON.stringify({classification:'Pure planner leaves and native road geometry only; no Game/fullP0/step/command issue. Candidate v1 is not validated: original30346 contract remains red.',cases},null,2));
console.log(JSON.stringify(cases.map((c:any)=>({source:c.source,tick:c.tick,general:c.general,tasks:c.tasks,backline:c.backline,selected:c.approaches.filter((a:any)=>c.tasks.commands.some((cmd:any)=>cmd.unitIds?.includes(a.healer)))}))));
