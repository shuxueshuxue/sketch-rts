from pathlib import Path
import json,hashlib,subprocess
D=Path('/tmp/bootstrap-medical-safe-prefix-8da-20261016');S=Path('/tmp/sketch-rts-medical-safe-prefix-8da-control');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cap=json.loads((D/'runtime-source.json').read_text()); expected={f['path']:f['sha256']for f in cap['files']}
for label in ['v2-safety4','v2-expedition12','v2-tsc']:
 r=json.loads((D/(label+'-exit.json')).read_text());assert r['exitCode']==0 and r['sourcePrePostExact'],label
 assert all(r['sourcePost']['files'].get(p)==h for p,h in expected.items()),label
b=json.loads((D/'CLINICAL-DRIVER-BINDING.json').read_text());assert H(D/'candidate-clinical8400-9000.ts')==b['driverSHA256'];assert all(H(Path(p))==h for p,h in b['boundFiles'].items());assert not(D/'clinical8400-9000').exists()
raise SystemExit(subprocess.run(['python3',str(D/'run-check.py'),'candidate600', '768',str(2*1024**3),'node','--import','tsx',str(D/'candidate-clinical8400-9000.ts')],cwd=S).returncode)
