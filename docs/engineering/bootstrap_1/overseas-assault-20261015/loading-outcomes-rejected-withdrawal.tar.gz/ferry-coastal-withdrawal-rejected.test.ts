import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {expect,it} from 'vitest';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame,issuePlayerCommand} from '../../shared/sim';
import {planBootstrapNaval} from './expedition-recovery';
import {bootstrapPolicyContext} from './policy';

it('finishes a ferry escape instead of alternating rally points under the real coastal firing squad',()=>{
 const saved=JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/archer-leading-withdrawal.json.gz',import.meta.url))).toString());
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const ship=game.units.find(u=>u.id==='unit-p0-carrier-4445')!,start={x:ship.x,y:ship.y};
 let memory=saved.memory,first:{x:number;y:number}|undefined,kept=false;
 for(let i=0;i<900&&game.units.includes(ship);i++){
  if(i%15===0){
   const s=snapshotGame(game),options=bootstrapPolicyContext(s,'p0','v9_archer',{memory,teams:game.teams});
   const commands=planBootstrapNaval(s,'p0',options);
   const escape=memory.naval?.coastalRetreat?.[ship.id];
   if(i===0){first=structuredClone(escape);expect(first).toBeDefined();}
   if(i===30){expect(escape).toEqual(first);memory=JSON.parse(JSON.stringify(memory));kept=true;}
   for(const command of commands)issuePlayerCommand(game,'p0',command);
  }
  stepGame(game);
  if(Math.hypot(ship.x-start.x,ship.y-start.y)>350)break;
 }
 expect(kept).toBe(true);expect(game.units.includes(ship)).toBe(true);
 expect(Math.hypot(ship.x-start.x,ship.y-start.y)).toBeGreaterThan(350);
},120000);
