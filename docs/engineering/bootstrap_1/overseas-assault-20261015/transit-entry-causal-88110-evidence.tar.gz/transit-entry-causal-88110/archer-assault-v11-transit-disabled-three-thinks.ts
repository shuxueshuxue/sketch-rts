import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
const E='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const configs=[{name:'v11',wd:'/workspace/sketch-rts-root-v11-integration-control',source:'archer-assault-root-v11-prelanding-source.json'},
{name:'disabled',wd:'/workspace/sketch-rts-v11-transit-disabled-control',source:'archer-assault-v11-transit-disabled-source.json'}];
const copy=(x:any)=>JSON.parse(JSON.stringify(x));
const hash=(p:string)=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const audit=(config:any)=>{const s=JSON.parse(fs.readFileSync(path.join(E,config.source),'utf8'));return {files:Object.keys(s.files).length,changed:Object.entries(s.files).filter(([p,h])=>hash(path.join(config.wd,p))!==h).map(([p])=>p)}};
const result:any={scope:'Three actual predecision snapshots; same exact world/nextId/both memories, all ordinary AI for one think and one native tick. Causal probe, no manual orders; not full match.',sourceBefore:configs.map(c=>({name:c.name,...audit(c)})),cases:[]};
for(const tick of [88110,88200,89040]){
 const input=path.join(E,`archer-assault-root-v11-prelanding.frames/before-mission-change-${tick}.json`),f=JSON.parse(fs.readFileSync(input,'utf8'));
 const row:any={tick,input,inputSha256:hash(input),outputs:{}};
 for(const config of configs){
  const imp=(p:string)=>import(pathToFileURL(path.join(config.wd,p)).href);
  const [{bootstrapMatches,bootstrapGame},{runAiGameLoop},{createAiMemoryProvider},{createBootstrapCommandPlanner},{restoreSnapshotIntoGame,snapshotGame}]=await Promise.all([imp('src/ai/bootstrap_1/benchmark.ts'),imp('src/ai/game-runner.ts'),imp('src/ai/planner-context.ts'),imp('scripts/bootstrap_1-planner.ts'),imp('src/shared/sim.ts')]);
  const match=bootstrapMatches('bootstrap_1-development',['sapphireArchipelago'],tick+1,false).find((i:any)=>i.subject==='v9_archer'&&i.agents.p0.race==='grove'&&i.side===0&&Object.values(i.agents).slice(1).map((a:any)=>a.version).join('+')==='v5');
  const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,copy(f.snapshot),f.nextId);for(const[o,m]of Object.entries(f.memories))memories.set(o,copy(m));
  const restore={snapshot:isDeepStrictEqual(copy(snapshotGame(game)),f.snapshot),nextId:game.nextId===f.nextId,memories:isDeepStrictEqual(copy(Object.fromEntries(Object.keys(match.agents).map(o=>[o,memories.get(o)]))),f.memories)};
  if(Object.values(restore).some(v=>!v))throw Error(JSON.stringify(restore));
  const planner=await createBootstrapCommandPlanner(memories),issued:any[]=[],hits:any[]=[];game.observer={hit:(a:any,t:any,damage:number,hpBefore:number)=>hits.push({tick:game.tick,attackerId:a.id,targetId:t.id,damage,hpBefore})};
  runAiGameLoop({...match,game,commandPlanner:planner},{onCommand:({tick,owner,scriptId,command}:any)=>issued.push({tick,owner,scriptId,command:copy(command)})});
  const output={restore,commands:issued,hits,after:{tick:game.tick,snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(o=>[o,memories.get(o)]))}};
  fs.writeFileSync(path.join(E,`archer-assault-v11-three-think-${tick}-${config.name}.json`),JSON.stringify({input:f,source:config.source,...output}));
  row.outputs[config.name]=output;
 }
 const a=row.outputs.v11,b=row.outputs.disabled;
 row.equal={commands:isDeepStrictEqual(a.commands,b.commands),snapshot:isDeepStrictEqual(copy(a.after.snapshot),copy(b.after.snapshot)),nextId:a.after.nextId===b.after.nextId,memories:isDeepStrictEqual(copy(a.after.memories),copy(b.after.memories))};
 result.cases.push(row);console.log(JSON.stringify({tick,equal:row.equal}));
}
result.sourceAfter=configs.map(c=>({name:c.name,...audit(c)}));
fs.writeFileSync(path.join(E,'archer-assault-v11-three-thinks.json'),JSON.stringify(result,null,2));
if([...result.sourceBefore,...result.sourceAfter].some(c=>c.changed.length))throw Error('Source drift');
