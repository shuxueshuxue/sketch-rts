562 固定候选完整证据，未合入。

源码 56237b17ae40f4b9aacc16164a61c41a2a3dd103，基于610；1479当前选定文件、规则2、冻结184 manifest及497全文件前后逐字节相同。candidate-source.tar.gz包含1976 payload并已逐字节回读；原容器不可访问未提交修改仍未恢复。

两个实际实验严格分开：

- component17325-18000：从610实际17325完整before-P0恢复，675tick正常三AI。p0新增永久死亡0，原同输入旧后缀新增8。10920真实避开原双塔命中，末134/150；未证明最初北post抵达，中途已换目标。此局部物理改善不归入下述完整局。
- natural-common11400：仅继承原f508普通开局<=11400前缀，从原11400完整before-P0开始一次同源562、正常三AI，无人工附令，无任意tick终止，p0自然胜于38673；敌方单位/建筑对象严格0。总永久死亡p0/p1/p2/neutral=30/94/68/17。较原f50830778/25慢7895tick、多5损失，不能归为整体改进；较53337965/31慢708tick、少1损失。610改变源码于12720，不能借作同11400前缀公平比较。当前不合入562 bundle。

完整账本 WHOLE-COMMON-START-TERMINAL-LEDGER-AUDIT.json：209唯一永久死亡逐fatal原始hit字段、尸体与移除确认、末态不存在、全owner计数均闭合；25,465 SDK命令尝试与3,685实际命中索引连续，只继承原f508前缀。SDK尝试并非一律执行动作。770完整帧审计涵盖两独立scope，不能称同一完整局770帧。LOSS-COST-LEVEL-COHORT-COMPARISON.json含初始cohort、等级、损失医疗与catalog基础金币成本；562损失基础成本4190、17初始cohort损失、4老兵/等级和5/阵亡者击杀31、6医疗；成本不是装备/佣兵实际付款总价。

唯一终局冷闭合38400→38673，273tick：120命令尝试/14实际命中及全world、nextId、3memory、winner完全一致，源码与冻结前后相同。不是另一次普通0或重复胜场。final38673-overview.png为真实终态drawWorld，未运行Game/step；已实际查看。

验证分开记录：最终13文件194测试exit0，另1文件48测试exit0，tsc exit0；不伪称一个242组合运行。validation-execution.json保全部session/log和早期负例。contracts-final-first.log的36红记录了曾扩大global care过滤破坏原General回收职责，最终已恢复原global语义、仅本帧field参与池过滤；不删除反证。B1/B2 before红与after绿，R1后续缩小合同，不能把三红称完全相同最终断言。

有限静态审查 independent-final-review/ 原样复制，当前公开move/继续旧move/原回收与claim交互无新增阻断。minrange-counterfactual-only/仅明确反事实：移动敌单位到catapult100px近身，发现max-range模型可虚计deadzone；该局当前route的ballista不能归因此反事实，未热改源码。移动安全只证明完整armed静态结构道路，不证明mobile敌军、目的地兵力或存活；无路hold只取消旧危险动作；原activeattack/V8 rangedfight例外保留，逐人post可能分散。

下一项在新独立目录离线诊断实际11400首次8+1回北、11738建塔工死亡、当地矿防与现有微操，不改本封包/固定源，不从562更易后窗借胜。
