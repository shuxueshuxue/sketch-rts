import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { dirname } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { NativeTelemetry } from './native-telemetry';

// One authorized source-frozen official-map summoner ordinary0. No manual gameplay commands.
const [root, expectedHead, prefix] = process.argv.slice(2);
if (!root || !expectedHead || !prefix || !root.startsWith('/') || !prefix.startsWith('/') || !/^[a-f0-9]{40}$/.test(expectedHead))
  throw Error('Usage: ordinary0-combined.ts ABS_SOURCE FULL_EXPECTED_FIXED_HEAD ABS_NEW_PREFIX');
const mode = 'ordinary0-official-summoner-v5v7';
const classification='One source-frozen ordinary0 on official greystonePass, v9_summoner Ember physicalside1 versus normal frozen v5 Grove+v7 Ember on one enemy team, think15/rules2. Seed is a record label only: unseen=false, not a holdout/generalization claim. Original approved factory/terrain/third seat, no restore or manual commands. One match is not bootstrap acceptance.';
const declaration=JSON.parse(readFileSync(dirname(prefix)+'/seed-predeclaration.json','utf8'));
const driverCap=JSON.parse(readFileSync(dirname(prefix)+'/driver-preflight.json','utf8'));
if(shaFile(import.meta.filename)!==driverCap.driverSHA256)throw Error('Driver changed since preflight');
function shaFile(p:string){return createHash('sha256').update(readFileSync(p)).digest('hex');}
for(const p of ['native-ledger.ts','native-telemetry.ts'])if(shaFile(dirname(prefix)+'/'+p)!==driverCap.dependencies[p])throw Error('Observer changed since preflight');
if(declaration.sourceHead!==expectedHead||declaration.sourceRoot!==root||shaFile(dirname(prefix)+'/seed-predeclaration.json')!==driverCap.seedPredeclarationSHA256)throw Error('Wrong predeclared source/seed');
for(const suffix of ['.json','.json.tmp','.frames','.events','-launch.json','-factory0.json.gz','-commands.jsonl','-plans.jsonl','-native-hits.jsonl','-native-events.jsonl','-native-deaths.jsonl','-ship-losses.jsonl','-postflight.json','-commands.jsonl.gz','-plans.jsonl.gz','-native-hits.jsonl.gz','-native-deaths.jsonl.gz'])
  if(existsSync(prefix+suffix))throw Error('Preserve existing game output: '+suffix);
const capsule=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8'));
if(capsule.root!==root||capsule.head!==expectedHead||!capsule.archiveReadbackVerified)
  throw Error('Run prepare-source.py once for this exact fixed root/head/prefix before any factory/game creation');
mkdirSync(dirname(prefix), {recursive:true});
const setup = {
  map:'greystonePass',seed:'bootstrap_1-official-summoner-v5-v7-20261016-01',unseen:false,side:1,
  agents:{p0:{version:'v9_summoner',versionLabel:'v9_summoner',race:'ember',controller:'external-agent',team:'a'},
    p1:{version:'v5',versionLabel:'v5',race:'grove',controller:'external-agent',team:'b'},
    p2:{version:'v7',versionLabel:'v7',race:'ember',controller:'external-agent',team:'b'}},
  thinkInterval:15,rulesVersion:2,frozenRevision:'d1ae110f2edd99f9c7d899ed61557891ab587639',
};
if(declaration.seed!==setup.seed||declaration.physicalSide!==setup.side||declaration.subject!==setup.agents.p0.version||declaration.race!==setup.agents.p0.race||declaration.rulesVersion!==setup.rulesVersion)throw Error('Setup differs from frozen predeclaration');
if(!isDeepStrictEqual(setup,declaration.setup))throw Error('Full setup differs from frozen declaration');
const copy = (v:any) => JSON.parse(JSON.stringify(v));
const sha = (v:any) => createHash('sha256').update(v).digest('hex');
const load = (p:string) => import(pathToFileURL(root+'/'+p).href);
function audit() {
  const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
  if(head!==expectedHead)throw Error('Unexpected source head');
  const paths=['src','scripts','tools','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json'];
  const files=execFileSync('git',['ls-tree','-r','-z',head,'--',...paths],{cwd:root}).toString().split('\0').filter(Boolean).map(line=>{
    const [meta,path]=line.split('\t'),[gitmode,kind,blob]=meta!.split(' '),bytes=readFileSync(root+'/'+path);
    const actual=createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
    return {path,expectedGitBlob:blob,actualGitBlob:actual,sha256:sha(bytes),bytes:bytes.length,matches:actual===blob};
  });
  const gitStatus=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:root,encoding:'utf8'});
  if(gitStatus||files.some(f=>!f.matches))throw Error('Source differs from fixed commit');
  return {root,head,gitStatus,files,frozenManifestSHA256:sha(readFileSync(root+'/docs/engineering/bootstrap_1/frozen-policy.json'))};
}
const pre=audit();
if(!isDeepStrictEqual(pre.files,capsule.files)||pre.head!==capsule.head)throw Error('Pre-saved capsule differs from current fixed source');
for(const [path,expected]of [[capsule.sourceArchive,capsule.sourceArchiveSHA256],[capsule.frozenArchive,capsule.frozenArchiveSHA256]])
 if(sha(readFileSync(path))!==expected)throw Error('Pre-saved source archive hash mismatch');
if(pre.frozenManifestSHA256!=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774')throw Error('Changed rules2 frozen manifest');
// Capsule was already saved by a game-free preflight. Never overwrite it.
const sim=await load('src/shared/sim.ts'),{bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts'),{UNIT_DEFS,ABILITY_DEFS}=await load('src/shared/catalog.ts');
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject===setup.agents.p0.version&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v5+v7');
if(!match||!isDeepStrictEqual(copy(match.agents),setup.agents))throw Error('Approved factory setup no longer resolves');
const game=bootstrapGame(match),owners=Object.keys(match.agents);
if(game.tick!==0||game.map.id!==setup.map||match.side!==setup.side||match.unseen!==false||match.thinkInterval!==15||match.maxTicks!==Number.MAX_SAFE_INTEGER)throw Error('Unexpected true0 official-map setup');
for(const owner of owners){
 const p=game.players[owner],units=game.units.filter((u:any)=>u.owner===owner),halls=game.buildings.filter((b:any)=>b.owner===owner&&b.kind==='townHall');
 if(p.gold!==500||p.supplyUsed!==3||p.supplyCap!==8||units.length!==3||units.some((u:any)=>u.kind!=='worker')||halls.length!==1)throw Error('Changed normal resources/population/start for '+owner);
}
const memories=createAiMemoryProvider(),planner=await createBootstrapCommandPlanner(memories);
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
writeFileSync(prefix+'-factory0.json.gz',gzipSync(JSON.stringify({classification,...frame()})+'\n'));
const frozenRoot=frozenPolicyRoot();
function frozenAudit(){const files=Object.entries(capsule.frozenFiles).map(([path,expected])=>({path,expected,actual:sha(readFileSync(frozenRoot+'/'+path))}));if(files.some(f=>f.expected!==f.actual))throw Error('Complete frozen archived source differs');return{revision:frozenPolicyManifest.revision,rulesVersion:frozenPolicyManifest.rulesVersion,files};}
const frozenPre=frozenAudit();
const frozen=Object.entries(frozenPolicyManifest.files).map(([path,expected])=>({path,expected,actual:sha(readFileSync(frozenRoot+'/'+path))}));
if(frozen.length!==184||frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision||frozen.some(f=>f.expected!==f.actual))throw Error('Frozen184 rules2 source mismatch');
writeFileSync(prefix+'-frozen-source.json',JSON.stringify({revision:frozenPolicyManifest.revision,rulesVersion:frozenPolicyManifest.rulesVersion,files:frozen},null,2)+'\n');
if(Object.values(frame().memories).some(m=>m!==null))throw Error('Fresh ordinary0 memory must remain absent before first think');
mkdirSync(prefix+'.frames');mkdirSync(prefix+'.events');
const streamBuffers=new Map<string,string>();
for(const stream of ['commands','plans','native-hits','native-events','native-deaths','ship-losses','corpse-events','samples','plan-costs','step-costs','health-transitions','healing-effects']){writeFileSync(prefix+'-'+stream+'.jsonl.gz',Buffer.alloc(0),{flag:'wx'});streamBuffers.set(stream,'');}
function appendStream(stream:string,text:string){const buffer=streamBuffers.get(stream);if(buffer===undefined)throw Error('Unknown raw stream '+stream);const next=buffer+text;if(Buffer.byteLength(next)>=65536){appendFileSync(prefix+'-'+stream+'.jsonl.gz',gzipSync(next));streamBuffers.set(stream,'');}else streamBuffers.set(stream,next);}
function flushStreams(){for(const [stream,buffer]of streamBuffers)if(buffer){appendFileSync(prefix+'-'+stream+'.jsonl.gz',gzipSync(buffer));streamBuffers.set(stream,'');}}
let previousHealth=new Map(game.units.map((u:any)=>[u.id,{hp:u.hp,maxHp:u.maxHp,owner:u.owner,kind:u.kind,level:u.level}]));let effectIds=new Set(game.effects.map((e:any)=>e.id));
function observeHealth(stage:string){const next=new Map<string,any>();for(const u of game.units){const now={hp:u.hp,maxHp:u.maxHp,owner:u.owner,kind:u.kind,level:u.level},old:any=previousHealth.get(u.id);if(old&&(old.hp!==now.hp||old.maxHp!==now.maxHp||old.owner!==now.owner))appendStream('health-transitions',JSON.stringify({tick:game.tick,stage,commandIndex:telemetry.commandIndex,id:u.id,before:old,after:now,order:u.order,abilityCooldowns:u.abilityCooldowns,effects:u.effects})+'\n');next.set(u.id,now);}previousHealth=next;const current=new Set<string>();for(const e of game.effects){current.add(e.id);if(!effectIds.has(e.id)&&e.type==='heal')appendStream('healing-effects',JSON.stringify({tick:game.tick,stage,commandIndex:telemetry.commandIndex,effect:e})+'\n');}effectIds=current;}
const telemetry=new NativeTelemetry(game,(stream,event)=>appendStream(stream,JSON.stringify(event)+'\n'));
let commandCount=0,planCount=0,eventStateCount=0;
function eventState(stage:string,events:any[]){if(!events.some(e=>e.type==='native-building-terminal'||e.type==='native-unit-terminal'&&e.permanent||e.type==='owner-change'))return;writeFileSync(prefix+'.events/'+game.tick+'-'+stage+'-'+(++eventStateCount)+'.json.gz',gzipSync(JSON.stringify({...frame(),phase:stage,commandIndex:telemetry.commandIndex,restoreCaution:'Event observation may be mid-think or contain native load/balance. Full world/id/3mem preserved; validate restore and remaining command phase before use as a continuation.'})+'\n'));}
const rows:any[]=[],started=performance.now(),cpuStart=process.cpuUsage();let savedTick=-1,observationStopped=false,stopRequest:any;
let stepStart=0;let corpseIds=new Set((game.corpses ?? []).map((c:any)=>c.id??c.unitId));
function observeCorpses(stage:string){const current=new Set((game.corpses ?? []).map((c:any)=>c.id??c.unitId));for(const corpse of game.corpses ?? []){const id=corpse.id??corpse.unitId;if(!corpseIds.has(id))appendStream('corpse-events',JSON.stringify({tick:game.tick,stage,commandIndex:telemetry.commandIndex,type:'native-corpse-observed',corpse})+'\n');}corpseIds=current;}
function save(completed:boolean){
 flushStreams();
 const f=frame();const temporary=prefix+'.frames/'+game.tick+'.json.gz.tmp';writeFileSync(temporary,gzipSync(JSON.stringify(f)+'\n'));renameSync(temporary,prefix+'.frames/'+game.tick+'.json.gz');savedTick=game.tick;
 const row={tick:game.tick,players:Object.fromEntries(owners.map(owner=>{const units=f.snapshot.units.filter((u:any)=>u.owner===owner),buildings=f.snapshot.buildings.filter((b:any)=>b.owner===owner);return[owner,{policy:f.memories[owner],gold:game.players[owner].gold,supply:game.players[owner].supplyUsed,cap:game.players[owner].supplyCap,
  upgrades:game.players[owner].upgrades,units:units.length,permanentUnits:units.filter((u:any)=>u.expiresTick===undefined).length,workers:units.filter((u:any)=>u.kind==='worker').length,
  healers:units.filter((u:any)=>UNIT_DEFS[u.kind].abilities.some((a:any)=>ABILITY_DEFS[a].behavior==='heal')).map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,cooldowns:u.abilityCooldowns})),
  bases:buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,x:b.x,y:b.y,hp:b.hp,complete:b.complete})),buildings:buildings.length,unitsLost:game.match.stats.unitsLost[owner],goldSpent:game.match.stats.goldSpent[owner]}];}))};
 appendStream('samples',JSON.stringify(row)+'\n');rows.push(copy(row));if(rows.length>12)rows.shift();
 const cpu=process.cpuUsage(cpuStart);const report={classification,mode,source:root,head:pre.head,inputTick:0,setup,result:{tick:game.tick,winner:game.match.winner,completed,naturalComplete:!!game.match.winner,observationStopped,stopRequest},elapsedMs:performance.now()-started,cpuMs:(cpu.user+cpu.system)/1000,resources:{memory:process.memoryUsage(),usage:process.resourceUsage()},commandCount,planCount,telemetry:telemetry.summary(),rows};
 writeFileSync(prefix+'.json.tmp',JSON.stringify(report)+'\n');renameSync(prefix+'.json.tmp',prefix+'.json');
 console.log(JSON.stringify({mode,tick:game.tick,winner:game.match.winner,p0:{gold:row.players.p0.gold,supply:row.players.p0.supply,bases:row.players.p0.bases.length,units:row.players.p0.units,unitsLost:row.players.p0.unitsLost},rss:process.memoryUsage().rss,elapsedMs:report.elapsedMs}));
}
game.observer={hit:(attacker:any,target:any,damage:number,hpBefore:number)=>telemetry.hit(attacker,target,damage,hpBefore)};
writeFileSync(prefix+'-launch.json',JSON.stringify({pid:process.pid,tick:game.tick,startedAtUtc:new Date().toISOString(),expectedHead,sourceArchive:capsule.sourceArchive,sourceArchiveSHA256:capsule.sourceArchiveSHA256,frozenArchive:capsule.frozenArchive,frozenArchiveSHA256:capsule.frozenArchiveSHA256,sourcePre:pre,frozenPre,driverSHA256:sha(readFileSync(new URL('./ordinary0-summoner.ts',import.meta.url))),telemetrySHA256:sha(readFileSync(new URL('./native-telemetry.ts',import.meta.url))),matureLedgerSHA256:sha(readFileSync(new URL('./native-ledger.ts',import.meta.url))),execArgv:process.execArgv,maxTicks:Number.MAX_SAFE_INTEGER,initialMemories:frame().memories,classification,seedPredeclarationSHA256:driverCap.seedPredeclarationSHA256,sourceManifestFiles:pre.files.length,frozenFullFiles:frozenPre.files.length,checkpointProtocol:'Full600 tick after-step states are next-think checkpoints. Event frames can be mid-command and must not be resumed without phase audit. Only12 recent samples in memory; all raw streams append to disk. SDK onCommand entries are attempted-public traces, not proof transient actions executed. No arbitrary tick cutoff. Source-bound parent observation-stop checked only at complete600 boundary with reason/evidence.'},null,2)+'\n');
save(false);
class ObservationStop extends Error{}
let result:any;try{result=runGameLoop({...match,game,commandPlanner:(context:any)=>{telemetry.commandIndex=commandCount;const t=performance.now(),cpu=process.cpuUsage(),entries=planner(context),used=process.cpuUsage(cpu);planCount++;appendStream('plans',JSON.stringify({tick:game.tick,owner:context.owner,entries})+'\n');appendStream('plan-costs',JSON.stringify({tick:game.tick,owner:context.owner,wallMs:performance.now()-t,cpuMs:(used.user+used.system)/1000,entries:entries.length})+'\n');return entries;}},{
 onCommand:(event:any)=>{telemetry.commandIndex=commandCount++;appendStream('commands',JSON.stringify({index:telemetry.commandIndex,tick:game.tick,owner:event.owner,source:event.source,scriptId:event.scriptId,command:event.command,traceKind:'SDK public-command attempt; transient skips also call onCommand'})+'\n');const observed=telemetry.observe('after-command');eventState('after-command',observed);observeCorpses('after-command');observeHealth('after-command');telemetry.commandIndex=commandCount;},
 beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();stepStart=performance.now();},
 onStep:()=>{appendStream('step-costs',JSON.stringify({tick:game.tick,nativeStepWithObserverHitIOWallMs:performance.now()-stepStart})+'\n');const observed=telemetry.observe('after-step');eventState('after-step',observed);observeCorpses('after-step');observeHealth('after-step');if(game.tick%600===0||game.match.winner)save(!!game.match.winner);if(game.tick%600===0&&existsSync(dirname(prefix)+'/observation-stop.json')){const stop=JSON.parse(readFileSync(dirname(prefix)+'/observation-stop.json','utf8'));if(stop.authorizedByParent===true&&stop.sourceHead===expectedHead&&stop.reason&&stop.evidence){observationStopped=true;stopRequest=stop;throw new ObservationStop(stop.reason);}}},
});}catch(error){if(!(error instanceof ObservationStop)){flushStreams();writeFileSync(prefix+'-interruption-fullstate.json.gz',gzipSync(JSON.stringify({...frame(),checkpointStage:'unexpected-error-observation-not-assumed-restorable',commandIndex:telemetry.commandIndex})+'\n'));writeFileSync(prefix+'-interruption.json',JSON.stringify({tick:game.tick,error:String(error),classification:'Unexpected interruption, not natural win or authorized stop',commandCount,planCount},null,2));throw error;}}
flushStreams();
if(savedTick!==game.tick||observationStopped)save(!!game.match.winner);
if(!game.match.winner&&!observationStopped)throw Error('Natural terminal result missing');
writeFileSync(prefix+'-final.json.gz',gzipSync(JSON.stringify({...frame(),checkpointStage:observationStopped?'authorized-observation-stop':'natural-final'})+'\n'));
const post=audit(),sourceEqual=pre.head===post.head&&isDeepStrictEqual(pre.files,post.files),frozenPost=frozenAudit();writeFileSync(prefix+'-postflight.json',JSON.stringify({...post,sourceEqual,frozenPost,telemetry:telemetry.summary()},null,2)+'\n');
if(!sourceEqual||!isDeepStrictEqual(frozenPre,frozenPost))throw Error('Source changed during full tail');
console.log(JSON.stringify({mode,naturalWinner:game.match.winner,tick:game.tick,observationStopped,elapsedMs:result?.elapsedMs,cpuMs:result?.cpuMs,sourceEqual}));
