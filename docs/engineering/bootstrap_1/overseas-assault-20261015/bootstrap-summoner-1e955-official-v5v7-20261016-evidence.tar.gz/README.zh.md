固定源 1e955c0c5f1114812f873f9c3ba06fe7cb19cb1e 的唯一普通开局，官方 greystonePass，v9_summoner Ember、物理 side1，对冻结 v5 Grove + v7 Ember 同敌队，think15、规则2。seed 仅记录标签，unseen=false；这不是未见地图或种子泛化成绩。

82963 tick 自然 p0 获胜，敌方两家均 0 单位、0 建筑。p0 末 31 单位（8 工人、12 召唤师、11 spirit）、24 建筑、3 厅。p0 原生累计损失562 = 59永久单位 + 503召唤物战死；另567自然到期不算战死。v5损失54永久+1临时，v7损失65永久+621临时、另342到期。56非正HP初步观察均核对后续清理，未重复计数；没有未知、待清理或终局非正HP单位。

真实 tick0 全档证实三方各500金、3工人、人口3/8，三份AI记忆全空。没有恢复存档、人工游戏命令、改资源/人口/工厂/地形第三席，也没有另选样本或重开。1470运行源逐字节等于f9a3，运行前后与提交字节相等；冻结184清单及完整497源检查相等。运行前已封存、回读运行源与全部driver依赖。保留optional corpses空数组修正，不沿用旧骑士zero-native retry门。

保留140个600tick/终局完整world、nextId、3mem档；关键永久死亡、建筑死亡和owner-change均保存完整事件档。原始命令尝试、planner、11270真实命中、永久/临时/到期移除、尸体、health变化和实际heal effects分别存为可串接gzip JSONL，缓冲每流至多64KiB并在完整档前flush。SDK onCommand也会记录瞬态跳过，仅为尝试；547条heal effect不自动等于547次有效治疗。本局没有船只死亡、船只接管或甲板parent变化事件。

factory0、21000、64800及terminal图由固定源native drawWorld渲染并亲看；渲染未改变存档。CPU/内存是带observer/IO诊断，不作纯引擎性能基准。游戏约270秒，峰值RSS约493MiB。

该胜局仍有显著代价：59永久死亡包括27工人、4医师；首永久阵亡为8544的二星emberRavager1082，在avoidCombat move中被敌1094命中20，从2到-18。完整原始档保留以供后续改进。单场胜利不代表三路线、所有单敌和双敌组合、官方地图及未见种子验收完成。原容器未提交修改恢复缺口仍未消除。

复核入口为 audit-completed.py（离线、不运行游戏）、COMPLETED-ORDINARY0-AUDIT.json、INITIAL-ORDINARY0-AUDIT.json、PRELAUNCH-SEAL.json。事件档可能处于mid-command，不能未经相位核验当作恢复点；600 tick after-step档为下一次think前的完整边界。
