"""Offline completed-match source, state, stream and native death audit. No simulation."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import subprocess

D = Path(__file__).resolve().parent
P = D / 'game'


def read(path):
    return json.loads(Path(path).read_text())


def frame(path):
    return json.loads(gzip.decompress(Path(path).read_bytes()))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stream(name):
    path = D / ('game-' + name + '.jsonl.gz')
    with gzip.open(path, 'rt') as file:
        for line in file:
            if line.strip():
                yield json.loads(line)


cap = read(D / 'game-runtime-source.json')
launch = read(D / 'game-launch.json')
post = read(D / 'game-postflight.json')
report = read(D / 'game.json')
initial = frame(D / 'game-factory0.json.gz')
final = frame(D / 'game-final.json.gz')
control = Path(cap['root'])
assert cap['head'] == launch['expectedHead'] == post['head'] == report['head'] == '1e955c0c5f1114812f873f9c3ba06fe7cb19cb1e'
assert launch['sourcePre']['files'] == post['files'] == cap['files']
assert len(cap['files']) == 1470 and len(cap['frozenFiles']) == 497
assert post['sourceEqual'] and not post['gitStatus']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=control, text=True).strip() == cap['head']
for entry in cap['files']:
    assert digest(control / entry['path']) == entry['sha256']
for inventory in [launch['frozenPre'], post['frozenPost']]:
    assert len(inventory['files']) == 497
    assert {row['path']: row['actual'] for row in inventory['files']} == cap['frozenFiles']
    assert all(row['actual'] == row['expected'] for row in inventory['files'])
assert len(cap['frozenManifestFiles']) == 184
for path, expected in [(cap['sourceArchive'], cap['sourceArchiveSHA256']), (cap['frozenArchive'], cap['frozenArchiveSHA256'])]:
    assert digest(path) == expected
assert report['setup'] == initial['setup'] == final['setup']
assert initial['setup']['map'] == initial['snapshot']['map']['id'] == 'greystonePass'
assert initial['setup']['unseen'] is False and initial['setup']['side'] == 1
assert initial['memories'] == launch['initialMemories'] == {'p0': None, 'p1': None, 'p2': None}
zero = frame(D / 'game.frames/0.json.gz')
assert all(initial[key] == zero[key] for key in ['snapshot', 'nextId', 'memories', 'setup'])
for owner, race in [('p0', 'ember'), ('p1', 'grove'), ('p2', 'ember')]:
    player = initial['snapshot']['players'][owner]
    units = [unit for unit in initial['snapshot']['units'] if unit['owner'] == owner]
    assert (player['race'], player['gold'], player['supplyUsed'], player['supplyCap']) == (race, 500, 3, 8)
    assert len(units) == 3 and all(unit['kind'] == 'worker' for unit in units)
assert report['result']['naturalComplete'] and not report['result']['observationStopped']
end_tick = final['snapshot']['tick']
assert end_tick == report['result']['tick'] == final['snapshot']['match']['endedAtTick']
assert final['snapshot']['match']['winner'] == report['result']['winner']
last_checkpoint = frame(D / ('game.frames/' + str(end_tick) + '.json.gz'))
assert all(final[key] == last_checkpoint[key] for key in ['snapshot', 'nextId', 'memories', 'setup'])
frame_ticks = sorted(int(path.name.split('.')[0]) for path in (D / 'game.frames').glob('*.json.gz'))
assert frame_ticks == sorted(set(range(0, end_tick + 1, 600)) | {end_tick})
assert not [unit for unit in final['snapshot']['units'] if unit['hp'] <= 0]

states = {}
provisional = 0
returned_positive = 0
for event in stream('native-deaths'):
    if event['type'] == 'native-unit-terminal':
        provisional += event['confirmation'] == 'hp<=0-awaiting-cleanup'
        states[event['id']] = [event, event['confirmation']]
    else:
        assert event['type'] == 'terminal-status-update' and event['id'] in states
        states[event['id']][1] = event['status']
        returned_positive += event['status'] == 'returned-positive'
final_units = {unit['id']: unit for unit in final['snapshot']['units']}
corpse_ids = {corpse['unitId'] for corpse in final['snapshot'].get('corpses', [])}
expected_fatal = {}
closed = collections.defaultdict(collections.Counter)
unknown = []
for unit_id, (event, status) in states.items():
    body = event['atObservation'] or event['previous']
    owner = body['owner']
    if status == 'returned-positive':
        continue
    if status not in {'absent-at-native-boundary', 'native-removal-after-nonpositive'}:
        unknown.append({'id': unit_id, 'status': status})
        continue
    assert unit_id not in final_units
    if event['terminalClass'] == 'lifetime-expiry-eligible-removal':
        assert body.get('expiresTick', 10**20) <= event['tick']
        closed[owner]['lifetimeExpiry'] += 1
        continue
    if event['terminalClass'] != 'death-observed':
        unknown.append({'id': unit_id, 'class': event['terminalClass']})
        continue
    permanent = body.get('expiresTick') is None
    assert event['permanent'] == permanent
    evidence = event['evidence']
    fatal = evidence.get('nativePositiveToNonpositiveHit')
    if fatal:
        assert fatal['target'] == unit_id and fatal['hpBefore'] > 0 and fatal['hpAfter'] <= 0
        expected_fatal[fatal['index']] = fatal
    assert fatal or evidence.get('hpNonpositive') or evidence.get('corpse') or evidence.get('aboardLivingAtHullFatal') or evidence.get('knownDeadHull')
    if unit_id not in corpse_ids:
        assert evidence.get('aboardLivingAtHullFatal') or evidence.get('knownDeadHull'), unit_id
    closed[owner]['confirmedPermanent' if permanent else 'confirmedTemporary'] += 1
assert not unknown, unknown
hit_count = 0
for hit in stream('native-hits'):
    if hit['index'] in expected_fatal:
        assert hit == expected_fatal.pop(hit['index'])
    hit_count += 1
assert not expected_fatal
assert hit_count == report['telemetry']['hitCount']
closure = {}
for owner, total in final['snapshot']['match']['stats']['unitsLost'].items():
    before = initial['snapshot']['match']['stats']['unitsLost'][owner]
    permanent = closed[owner]['confirmedPermanent']
    temporary = closed[owner]['confirmedTemporary']
    assert total - before == permanent + temporary, (owner, total, before, permanent, temporary)
    closure[owner] = {'initial': before, 'nativeUnitsLost': total, 'confirmedPermanent': permanent,
                      'confirmedTemporary': temporary, 'lifetimeExpiryWithoutNativeLoss': closed[owner]['lifetimeExpiry']}
assert not report['telemetry']['pendingNativeCleanup']
captures = []
parent_changes = 0
for event in stream('native-events'):
    if event['type'] == 'owner-change':
        captures.append({'tick': event['tick'], 'stage': event['stage'], 'id': event['after']['id'],
                         'kind': event['after']['kind'], 'beforeOwner': event['before']['owner'], 'afterOwner': event['after']['owner']})
    if event['type'] == 'observed-parent-change':
        parent_changes += 1
counts = {}
for name in ['commands', 'plans', 'native-events', 'native-deaths', 'ship-losses', 'corpse-events', 'samples', 'plan-costs', 'step-costs', 'health-transitions', 'healing-effects']:
    counts[name] = sum(1 for _ in stream(name))
assert counts['commands'] == report['commandCount'] and counts['plans'] == report['planCount']
assert counts['step-costs'] == end_tick
end = {}
for owner in ['p0', 'p1', 'p2']:
    units = [unit for unit in final_units.values() if unit['owner'] == owner]
    buildings = [building for building in final['snapshot']['buildings'] if building['owner'] == owner]
    end[owner] = {'units': len(units), 'permanentUnits': sum(unit.get('expiresTick') is None for unit in units),
                  'unitKinds': dict(collections.Counter(unit['kind'] for unit in units)), 'buildings': len(buildings),
                  'halls': sum(building['kind'] == 'townHall' for building in buildings)}
audit = {'classification': 'Completed unique true ordinary0; offline source/state/raw ledger audit, no second game or policy query.',
         'head': cap['head'], 'source1470AndFrozen497PrePostExact': True, 'frozenManifest184Rules2': True,
         'setup': initial['setup'], 'factory0FullFrameExactAndNormal500_3workers_3of8_Null3mem': True,
         'result': report['result'], 'complete600FrameCount': len(frame_ticks),
         'initialSHA256': digest(D / 'game-factory0.json.gz'), 'finalSHA256': digest(D / 'game-final.json.gz'),
         'lossClosure': closure, 'provisionalNotDoubleCounted': provisional, 'returnedPositive': returned_positive,
         'pendingUnknown': [], 'terminalNonpositiveUnits': 0, 'actualHitCount': hit_count,
         'streams': counts, 'ownerChanges': captures, 'observedDeckParentChanges': parent_changes, 'remaining': end,
         'elapsedMs': report['elapsedMs'], 'cpuMs': report['cpuMs'], 'maxRSSKiB': report['resources']['usage']['maxRSS'],
         'limits': ['This official map/unseen=false seed label is not unseen-map/seed generalization.',
                    'One summoner ordinary0 versusv5+v7 does not complete all three families, singles/pairs/maps/seeds.',
                    'SDK onCommand records public attempts including transient skips; it is not blanket execution or healing proof.',
                    'Event fullstates may be mid-command;600 after-step checkpoints preserve world/id/all3memory at resumable before-think boundaries.',
                    'Native unitsLost includes temporary unit deaths; expiry removals are reported separately and not counted as deaths.'],
         'scriptSHA256': digest(__file__)}
(D / 'COMPLETED-ORDINARY0-AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
