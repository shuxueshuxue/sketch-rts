from pathlib import Path
import json,hashlib,tarfile
D=Path('/workspace/.playtest/bootstrap-knight-repair-origin-20261015');O=Path('/tmp/bootstrap-knight-renewed-service-audit-20261015');P=Path('/workspace/.playtest');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cap=json.loads((D/'origin-source.json').read_text());summary=json.loads((D/'summary.json').read_text());audit=json.loads((D/'full-frame-restore-audit.json').read_text());assert audit['all']and audit['count']==94 and audit['sourceNow'];assert summary['oldV2SourceUnchanged'];assert summary['continuation']['winner']=='p0'and summary['continuation']['end']==81077;assert summary['continuation']['sourcePost']and summary['continuation']['frozenActualPost'];assert all(summary['terminalClosure']['checks'].values())and all(summary['last15Closure']['checks'].values());assert all(sha(Path(cap['worktree'])/p)==h for p,h in cap['files'].items());assert len(cap['files'])==868
payload={}
for p in sorted(D.rglob('*')):
 if p.is_file()and p.name!='payload-index.json'and not p.name.startswith('view-'):payload['origin-candidate/'+str(p.relative_to(D))]=p
for p in sorted(O.glob('*')):
 if p.is_file()and not p.name.startswith('view-'):payload['original-readonly-diagnosis/'+p.name]=p
for name in ['src/shared/crew-rendezvous-origin.test.ts','src/shared/fixtures/knight-repair-origin-68400.json.gz','src/shared/fixtures/knight-repair-origin-85866.json.gz']:payload['proposed-source/'+name]=Path(cap['worktree'])/name
payload['previous-floor-fix/v2-service-query.json']=Path('/tmp/bootstrap-knight-escort-transfer-20261015/v2-service-query.json');payload['previous-floor-fix/summary-v2.json']=Path('/tmp/bootstrap-knight-escort-transfer-20261015/summary-v2.json');payload['old-fixedV2-source.json']=Path('/tmp/bootstrap-deployment-gate/knight-escort-transfer-v2-source.json')
index={n:{'originalPath':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in payload.items()};(D/'payload-index.json').write_text(json.dumps(index,indent=2)+'\n');archive=P/'bootstrap-knight-repair-origin-v1-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for n,p in payload.items():t.add(p,arcname=n,recursive=False)
 t.add(D/'payload-index.json',arcname='payload-index.json')
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(index)+1
 for n,m in index.items():
  b=t.extractfile(n).read();assert len(b)==m['bytes']and hashlib.sha256(b).hexdigest()==m['sha256']
 assert json.load(t.extractfile('payload-index.json'))==index
proof={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'payloadFiles':len(index),'readBackAllBytesAndSHA256':True,'sourceFiles':len(cap['files']),'sourceArchiveSHA256':cap['sourceArchiveSha256'],'onlyNewRuntimePatch':str(D/'origin-only.patch'),'runtimeAndTestsPatch':str(D/'origin-with-tests.patch'),'oldFixedV2Immutable':True,'nativeWindow':[68400,69600],'strictRestoredContinuation':[69600,81077],'winner':'p0','all94FullFrameRestoresExact':True,'actualWorkerParentChangeTick':69651,'firstFullRepairCompleteAndBothUnreserved':70800,'passedTests':58,'identicalPreexistingCoastFailures':2,'tscExitCode':0,'oldFixedV2CompleteEvidenceSHA256':'768c86260addb7f0cdb9208dc50880b3ef739296de590c2d32000d19ce08ec92'};(P/'bootstrap-knight-repair-origin-v1-archive.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
