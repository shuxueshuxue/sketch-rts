import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { setBuildingBodies } from './terrain';
import { reservationTraffic, shipTraffic } from './ship-avoidance';
import { shipSolidTraffic, sweepShipCollision } from './ship-collisions';
import { hullPassageClear, planShipRoute } from './ship-navigation';
import { canBoard } from './decks';
import { decksCanTransfer } from './connected-decks';
import type { GameSnapshot } from './types';

for (const tick of [68400, 85866]) for (const id of ['unit-p0-cutter-1139', 'unit-p0-warship-1935']) {
  it(`starts the real ${tick} ${id} repair rendezvous clear of its partner's current hull`, () => {
    const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/knight-repair-origin-${tick}.json.gz`, import.meta.url))).toString());
    const snapshot: GameSnapshot = saved.snapshot;
    setBuildingBodies(snapshot.map, [...snapshot.buildings, ...(snapshot.obstacles ?? [])]);
    const worker = snapshot.units.find(unit => unit.id === 'unit-p0-worker-1851')!;
    const source = snapshot.units.find(unit => unit.id === worker.deck!.shipId)!;
    const receiver = snapshot.units.find(unit => unit.id === 'unit-p0-warship-1935')!;
    expect(canBoard(receiver, worker, snapshot.units)).toBe(true);
    expect(decksCanTransfer(source, receiver, worker)).toBe(false);
    const ship = snapshot.units.find(unit => unit.id === id)!;
    if (ship.order.type !== 'move') throw new Error('fixture must retain the native rendezvous helm');
    const before = JSON.stringify(snapshot);
    const reserved = reservationTraffic(ship, snapshot.units);
    const solids = shipSolidTraffic(snapshot.map, ship, snapshot.units);
    const traffic = Object.assign((from: Parameters<typeof reserved>[0], to: Parameters<typeof reserved>[1], padding?: number) =>
      reserved(from, to, padding) && solids(from, to), { hasTraffic: reserved.hasTraffic || solids.hasTraffic });
    const route = planShipRoute(snapshot.map, ship, ship.order, traffic, 1024);
    expect(route.points.length).toBeGreaterThan(0);
    const start = { x: ship.x, y: ship.y, heading: ship.sailing!.heading };
    const first = route.points[0]!;
    expect(hullPassageClear(snapshot.map, ship, start, first)).toBe(true);
    expect(shipTraffic(ship, snapshot.units)(start, first)).toBe(true);
    expect(sweepShipCollision(snapshot.map, ship, snapshot.units, start, first)).toBeUndefined();
    expect(JSON.stringify(snapshot)).toBe(before);
  });
}
