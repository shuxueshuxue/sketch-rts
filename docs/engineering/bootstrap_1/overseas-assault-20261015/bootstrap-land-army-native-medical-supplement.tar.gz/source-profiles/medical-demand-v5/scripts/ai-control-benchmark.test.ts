import { execFileSync } from "node:child_process";
import { describe, expect, it } from "vitest";
import { createAiMeleeControlBenchmarkInput } from "../src/ai/benchmark/control";

describe("AI control benchmark CLI", () => {
  it("prints selected side-balanced matches without running simulations in dry-run mode", () => {
    const output = JSON.parse(runControlBenchmarkCli("--seed", "control-cli-seed", "--map-count", "2", "--dry-run"));

    expect(output).toMatchObject({
      name: "AI 1v1 Control Benchmark",
      seed: "control-cli-seed",
      matchCount: 4,
    });
    expect(output.manifest.evaluations[0].matches[0]).toMatchObject({
      name: output.matches[0],
      commandPlanner: "present",
      agents: {
        v2: { controller: "external-agent", team: "north", race: "grove", aiVersion: "v2" },
        v1a: { controller: "external-agent", team: "south", race: "grove", aiVersion: "v1" },
      },
    });
    expect(output.manifest.evaluations[0].matches[3].agents.v2.disabledBehaviors).toEqual(["workerHarassment"]);
    expect(output.selectedMapIds).toHaveLength(2);
    expect(output.matches).toEqual(output.selectedMapIds.flatMap((mapId: string) => [`${mapId} 1v1 control north`, `${mapId} 1v1 control south`]));
    expect(output.manifest.evaluations[0].matches[0]).toMatchObject({ mapId: "ladder" });
  });

  it("runs only the games of the ladder slots named with --maps", () => {
    const slot = createAiMeleeControlBenchmarkInput({ seed: "control-cli-seed", mapCount: 2 }).selection.mapIds[0]!;
    const output = JSON.parse(runControlBenchmarkCli("--seed", "control-cli-seed", "--map-count", "2", "--maps", slot, "--max-ticks", "1", "--workers", "1", "--details"));

    expect(output.matches.map((match: { name: string }) => match.name)).toEqual([`${slot} 1v1 control north`, `${slot} 1v1 control south`]);
  });

  it("prints focused match diagnostics with player benchmark metrics", () => {
    const slot = createAiMeleeControlBenchmarkInput({ seed: "control-cli-seed", mapCount: 2 }).selection.mapIds[1]!;
    const output = JSON.parse(runControlBenchmarkCli("--seed", "control-cli-seed", "--map-count", "2", "--match", `${slot} 1v1 control south`, "--max-ticks", "1", "--workers", "1", "--details"));

    expect(output.matchCount).toBe(1);
    expect(output.matches).toHaveLength(1);
    expect(output.matches[0]).toMatchObject({
      name: `${slot} 1v1 control south`,
      mapId: "ladder",
      players: {
        v2: {
          team: "south",
          race: "grove",
          moonWellHealingEvents: 0,
          moonWellHealingHp: 0,
        },
        v1a: {
          team: "north",
          race: "grove",
        },
      },
    });
  });
});

function runControlBenchmarkCli(...args: string[]) {
  return execFileSync(process.execPath, ["--import", "tsx", "scripts/ai-control-benchmark.ts", ...args], {
    cwd: process.cwd(),
    encoding: "utf8",
    env: { ...process.env, FORCE_COLOR: "0" },
  });
}
