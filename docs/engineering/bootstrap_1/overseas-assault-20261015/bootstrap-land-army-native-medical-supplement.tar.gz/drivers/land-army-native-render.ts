import {createCanvas} from '@napi-rs/canvas';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const[source,frame,out,viewArg='front']=process.argv.slice(2);
const{installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const{drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const{UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
const{snapshot}=JSON.parse(readFileSync(frame,'utf8'));
installHeadlessCanvas();
const view=viewArg==='home'?{x:2200,y:2850,width:1440,height:1080,zoom:.8}:{x:900,y:2500,width:1600,height:1050,zoom:.8};
const canvas=createCanvas(view.width,view.height),ctx=canvas.getContext('2d');
drawWorld({ctx:ctx as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
const patient=snapshot.units.find((u:any)=>u.id==='unit-p0-emberRavager-1079');
ctx.fillStyle='rgba(0,0,0,.8)';ctx.fillRect(12,12,960,58);ctx.fillStyle='white';ctx.font='22px sans-serif';ctx.fillText(`Native snapshot tick ${snapshot.tick}; patient1079 ${patient?`HP ${patient.hp}/${patient.maxHp}`:'dead / absent'}`,26,47);
if(patient){const x=(patient.x-view.x)*view.zoom,y=(patient.y-view.y)*view.zoom;ctx.strokeStyle='#00ffda';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,27,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#00ffda';ctx.font='20px sans-serif';ctx.fillText('1079',x+33,y-20);}
writeFileSync(out,canvas.toBuffer('image/png'));
writeFileSync(out+'.json',JSON.stringify({classification:'Native drawWorld of recorded full native state, with diagnostic patient ring and primitive HUD. New facing tracker does not reconstruct historical sprites or prove any attack.',source,frame,tick:snapshot.tick,view,patient:patient?{id:patient.id,hp:patient.hp,x:patient.x,y:patient.y}:null},null,2));
console.log(out);
