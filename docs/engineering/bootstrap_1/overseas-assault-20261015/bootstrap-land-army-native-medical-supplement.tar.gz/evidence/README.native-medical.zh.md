# 后续原生撤退、纯护理与首医师生产负例

这些是四个已封存 negative 包之后的增量；不替换旧包，不是验收成功。规则 2、冻结 d1ae 的 184 项 manifest 均未改；原容器未提交修改仍未恢复。父分支和活动 control 没有被本实验修改。

- general-retreat-v3：183 的真实普通召唤局11970 attack→hold 完整档换码至13200；窄原生撤退任务与基线最终 world/nextId/全部三方 memory 完全相同，没有实际收益，未合。
- care-only-v4：移除 c18 归队改令后的纯护理，183 真实普通召唤局6600→8400；基线完整重演与原普通8400等值，双方同4名永久前线死亡。全局首 priest 7835 才出生、7956 首 heal；1079 已在7921死。未合。
- medical-demand-v5：真实普通召唤局4800完整档换码至8400。累计可治永久非工人、非甲板、非临时兵缺血达到原生 heal55，提出原 priority65/原比例需求，并走现有合法科技/生产链；5850 开建 producer，但既有资金规划仍使8400没有医师。该局部0死亡不能归因治疗，无新普通0，未合。
- medical-demand-v6 / 97096bf1：仅将同一真实医疗采购意图接到已有 first-healer reserve，保留42科技门槛、35%战术 triage、原人口/价格。6240 付135金训练、6425首 priest、6720 原生施法，6721伤兵1079实际66→118。原先局部探针漏掉立即施法后cooldown239，旧 heal[] 保留且有单独勘误和20tick完整原生对照。
- v6真实普通0：Ember v9_summoner p0 side1，对冻结 v8 Grove p1 + v8 Ember p2，factory greystonePass，actual map.id ladder，seed resume-20261015-knight-expansion-b（已知开发种子，名字不代表路线）。0→12495 自然p1胜，明显早于183召唤基线30151；不推荐合入。600→4800全部world/nextId/三方mem等于旧普通局，8400也等于换码原生对照，源800TS+56数据前后一致。提前科技使自然5790→7440开建，并改变进攻节奏；不能把提前一次治疗当整局收益。

25657（183/c18）、25957（ad791）是独立 true v9_knight 普通局；30151（183）、17919（c18）、12495（97096）是 v9_summoner。详细以 land-army-actual-subject-audit.json 为准，不能靠 seed 名计算路线覆盖。

所有原生窗口完整 frame 含 world、nextId、三方 memory。普通0使用未改 inspect，frame 存 world/nextId，report每行存完整三方 policy；tick0独立工厂见证区分于进程内记录。完整来源和 profile SHA 在 INDEX/source-profiles 中。三路线所有单/双对手与泛化完整比赛要求仍未完成。
