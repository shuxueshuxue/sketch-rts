import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const source='/tmp/sketch-rts-mounted-mineguard-v2-control',dir='/tmp/bootstrap-land-army-evidence-20261015';
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href),copy=(v:any)=>JSON.parse(JSON.stringify(v));
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {restoreSnapshotIntoGame,snapshotGame,stepGame}=await load('src/shared/sim.ts');
const {bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts');
const {mineDefense,mineGuardUnitIds}=await load('src/ai/bootstrap_1/mine-defense.ts');
const {armedFoes}=await load('src/ai/bootstrap_1/safe-land-route.ts');
const {incomingItemDamage}=await load('src/ai/bootstrap_1/damage-footprints.ts');
const {groundSteeringRoute,routePrefix}=await load('src/shared/route-selection.ts');
const {planAiOwnerCommandEntries}=await load('src/ai/planner-context.ts');
const {issueCommandFrame}=await load('src/sdk/commands/frame.ts');
const {itemsFor}=await load('src/shared/equipment.ts');
const setup=JSON.parse(readFileSync(dir+'/archer-base5f-full9600.json','utf8')).setup;
const riderId='unit-p0-horseArcher-2503',rodId='creep-gen-3-1';
const results=[];
for(const tick of [9915,9930]){
 const input=dir+'/mounted-rod-fine-base5f-native9600.frames/'+tick+'.json',saved=JSON.parse(readFileSync(input,'utf8'));
 const match=bootstrapMatches(setup.seed,[setup.map],tick+15,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
 const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const snapshot=snapshotGame(game),memory=copy(saved.memories.p0),before=copy(memory),options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory,teams:game.teams});
 const rider=game.units.find((u:any)=>u.id===riderId)!,foes=armedFoes(snapshot,'p0',options);
 const claim=[...mineGuardUnitIds(snapshot,'p0',options)],commands=mineDefense.run(snapshot,'p0',options);
 const move=commands.find((c:any)=>c.type==='move'&&c.unitIds.includes(riderId));
 const road=move&&copy(groundSteeringRoute(snapshot.map,rider,move)),prefix=road&&copy(routePrefix(rider,road.slice(1),rider.speed*15/20));
 const riderItemDamage=incomingItemDamage(snapshot,snapshot.units.find((u:any)=>u.id===riderId),foes,15);
 const query={worldUnchanged:isDeepStrictEqual(copy(snapshotGame(game)),saved.snapshot),nextIdUnchanged:game.nextId===saved.nextId,memoryUnchanged:isDeepStrictEqual(before,copy(memory))};
 const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',memory:copy(saved.memories.p0)},{teams:game.teams});
 const start=copy(rider),trajectory=[];
 issueCommandFrame(game,entries);
 for(let i=0;i<15;i++){stepGame(game);const r=game.units.find((u:any)=>u.id===riderId),rod=game.units.find((u:any)=>u.id===rodId);trajectory.push({tick:game.tick,rider:r&&copy(r),rod:rod&&{x:rod.x,y:rod.y,items:itemsFor(snapshotGame(game),rod)},gap:r&&rod&&Math.hypot(r.x-rod.x,r.y-rod.y)});}
 results.push({tick,input,classification:'Actual saved ordinary5f fullworld, no entity/order/memory edits. Candidate query and15 native ticks with player planning held after initial p0 fullstack; not a whole match or full3AI continuation.',query,claim,commands,riderItemDamage,move,road,prefix,start,entries:copy(entries),trajectory,final:copy(game.units.find((u:any)=>u.id===riderId)),worldAfter:copy(snapshotGame(game)),nextIdAfter:game.nextId});
}
writeFileSync(dir+'/mounted-mineguard-v2-query-9915-9930.json',JSON.stringify({source,results},null,2));
console.log(JSON.stringify(results.map((r:any)=>({tick:r.tick,query:r.query,claim:r.claim,commands:r.commands,itemDamage:r.riderItemDamage,road:r.road,prefix:r.prefix,endHp:r.final?.hp,minGap:Math.min(...r.trajectory.map((x:any)=>x.gap))})),null,2));
