FFA98D07 守矿内骑手避雷最小候选，未合入。

独立5f基线，仅mine-defense十一增二删：保留原roster、门槛、守点、claim与mounted assignment；现役守矿horseArcher在原incomingItemDamage15>0的真实道具风险窗复用原mountedEscape朝原post避战，其余guard原attackMove。没有修改care、follow、reserved过滤、冻结敌、规则或资源。

原实际9915/9930完整档query与15原生tick证明骑手保持109HP，原生道路prefix与实际移动一致，无敌方数据修改；9915其余六兵命令/目标逐值保持。视觉为真实三方AI换码续局9960的原生drawWorld，仅红圈为240范围说明，非动画重建。

9600→11400为换码三方AI聚焦续局，9615JSON复原重演world/nextId/all3mem完整等值；11400全局0死亡，骑手145/145，没有命中或治疗，HP上限增长来自老兵。该11400完整world/nextId/3mem又与本候选真正新0普通局等值。

真正普通0→19815自然p1获胜，p0单位/建筑全灭，52永久死亡、0中立死、9958花费；原5f为0→43714 p0胜，56永久死、1中立死。不同局长下更少死或零中立死不算整轮改善。救下骑手最后16696死（旧10681），不称终局保全。13800候选6死vs旧9，14400则18vs旧10，远矿和两fieldMedic失守；这是可继续调查的区间，不能把首个避雷命令认作单一终局原因。

普通局完整采样每600含world/nextId/3mem，标准0factory独立起点见opening，与原5f完全相等；前缀到9600全档相同，详细9900也全等，首命令分叉9915。终局19800→19815同源重演完整等值。公共driver默认metadata字符串写changed-code，但此终局重演实际同FFA98来源；evaluation已显式更正，保留原日志。

1479固定源前后不变，普通局1239源/数据字节不变且clean。rules2/frozen184迁移基线及原第三席不变。源capsule固定ff88bd42；可移植测试d4f84425含两个真实完整fixture帧，新3测+旧mine-defense19=22通过，tsc通过；只在独立测试树恢复原5f生产文件后新测试2失败1通过，之后恢复候选且clean。其它reservedCrew旧红未包含到此改动。

本包包含候选代码增量、fixture/test增量、源胶囊、完整普通局、聚焦/终局重演、query、原生视觉、回归与分析。原5f全局与前序负例依赖既有9157e664…/7924a14c…包；本包不重复原5f全局。原容器未提交改动的恢复缺口继续保留。三路线bootstrap最终普通对手/地图种子与完整泛化要求尚未完成。
