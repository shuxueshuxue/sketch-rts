import {readFileSync,writeFileSync}from'node:fs';
import{pathToFileURL}from'node:url';
const source="/workspace/sketch-rts-care-follow-v11-control",opening="/tmp/bootstrap-land-army-evidence-20261015/archer-courier-follow-v11-ordinary0-opening.json",frame="/tmp/bootstrap-land-army-evidence-20261015/archer-courier-follow-v11-ordinary0.json.frames/0.json",selection={"map": "pineshade", "seed": "bootstrap_1-unseen-archer-v8-v8-20261015-01", "subject": "v9_archer", "opponents": "v8+v8", "race": "grove", "side": 1, "unseen": true, "ticks": 96000};
const{bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const{snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const{createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const match=bootstrapMatches(selection.seed,[selection.map],selection.ticks,selection.unseen)
 .find((m:any)=>m.subject===selection.subject&&m.side===selection.side&&m.agents.p0.race===selection.race
 &&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===selection.opponents);
if(!match)throw new Error('Exact ordinary match missing');
const game=bootstrapGame(match),snapshot=snapshotGame(game),provider=createAiMemoryProvider();
const initial=Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,{gold:game.players[owner].gold,
 supplyUsed:game.players[owner].supplyUsed,supplyCap:game.players[owner].supplyCap,
 units:game.units.filter((u:any)=>u.owner===owner).map((u:any)=>u.kind)}]));
const manifest=JSON.parse(readFileSync(source+'/docs/engineering/bootstrap_1/frozen-policy.json','utf8'));
if(game.tick!==0||manifest.rulesVersion!==2||Object.values(initial).some((p:any)=>p.gold!==500
 ||p.supplyUsed!==3||p.supplyCap!==8||p.units.join(',')!=='worker,worker,worker'))throw new Error('Standard opening changed');
const memories=Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,provider.get(owner)??null]));
writeFileSync(frame,JSON.stringify({snapshot,nextId:game.nextId,memories,
 memoryLifecycle:'Fresh policy provider has no initialized owner memories before the first think. Null records that absence, not a seeded strategy.'})+'\n');
writeFileSync(opening,JSON.stringify({classification:'Prelaunch deterministic standard bootstrapGame tick0 witness. The unmodified inspect runner constructs the same factory opening independently. No restore, commands, world edits, or seeded memories.',
 match,initial,rulesVersion:manifest.rulesVersion,frozenRevision:manifest.revision,snapshot,nextId:game.nextId,memories})+'\n');
console.log(JSON.stringify({tick:game.tick,initial,nextId:game.nextId}));
