# bootstrap_1 医疗follow v10–v12闭合证据（均未合入）

本包是失败与收益均保留的独立研究交付，不是bootstrap_1验收。原损坏容器未提交修改仍无法恢复；没有复制成功的声明。root/main与规则3工作区未改。

## 规则与源

所有实际比赛保持rulesVersion2，冻结对手revision d1ae110f2edd99f9c7d899ed61557891ab587639、184 manifest项目，manifest SHA256 0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。三方500金/3已用人口/8上限。独立开局witness与指定基线世界和nextId全等，未编辑地图/世界/策略记忆/对手资源。

v11仅7插入2删除：延续已有合法可达自有医师follow直至满血。v12仅9插入2删除：延续已有合法可达自有医师follow，进入该医师真实heal240范围后恢复原triage。均不改35%门槛，不新增策略记忆，不靠施法冷却猜患者已治疗。v10仅锁等于本帧nearest的目标，实际10275 nearest切换时未保护原旅程，保持未合。

archer固定源v11=0f4e789a9ee091c4c388c76cb0b4e04792f6bca2、v12=0764765d（均基于5f657b38）。summoner固定源v11=118cc3b9558cb630c36f69fe25f5cc46eb36f1d2、v12=3f78c0ed5c61393c5c252690aeb2c0d489451444（均只在纯geometry457e1ec3上叠相同单策略补丁）。四次普通0均源码前后哈希全不变、clean固定commit；详见各runtime-source/postflight。不同worktree的稀疏源覆盖数量不同，公共文件除该生产文件外一致；完整源胶囊与冻结源已保留。

## 真实完整普通0

| 路线/候选 | 自然终局 | 永久死亡 | 临时战斗死亡 | 中立造成死亡 |
|---|---:|---:|---:|---:|
| archer基线5f | 43714 p0胜 |56|0|1|
| archer v11 |38063 p0胜|30|0|0|
| archer v12 |19499 p1胜|55|0|0|
| summoner纯457 |57109 p0胜|57|151|0|
| summoner v11 |19086 p1胜|53|16|0|
| summoner v12 |57109 p0胜|57|151|0|

永久统计包含工人与采购佣兵；本组实际临时单位仅带expiresTick的spirit，临时战斗死亡与自然寿命到期不同，不能把召唤69/208的native unitsLost都叫永久死亡。短败局的更少累计损失不是改善。同18600时summoner v11已52永久死/仅1永久活/0医师，基线18永久死/36永久活/1医师；archer v12为36永久死，基线28，v11为13。完整每600tick代价在care-follow-complete-ordinary-costs.json。

archer实战subject是Grove v9_archer物理side1，对正常frozenv8 Ember+Grove同队；factory pineshade，实际--unseen生成ladder4608²，seed bootstrap_1-unseen-archer-v8-v8-20261015-01。summoner是Ember v9_summoner side1，对正常frozenv8 Grove+Ember同队；factory greystonePass，实际ladder4608²，seed resume-20261015-knight-expansion-b。seed名字含knight不代表路线。均为已开发种子，不冒充新未见泛化，未新增knight验收。

## 连续性与因果界限

四次普通0使用未改inspect脚本，report每row有三方完整policy，paired .json.frames拥有完整world+nextId。v11 archer终局37800->38063及37815checkpoint、v11 summoner18600->19086及18615checkpoint、v12 archer19200->19499及19215checkpoint，各自重演world/nextId/all3mem与原0终局全等。

v12 summoner 96个保存帧（含57109终局）world/nextId/all3mem全等纯457，未见收益；不推断未采样tick每一条命令都相同。v11 summoner与纯457直到7800全部保存帧相同；实际7800->8400两源重演分别吻合各自原0的8400，7815 JSON checkpoint均闭合。

summoner首命令差异8205：8196牧师2001已经将ravager1079从18治至73/118，8205距约71、医师CD231。两源原mineDefense都发attackMove，新v11追加follow覆盖；之后护军/后线/敌军路径分叉。此为最早直接行为，不证明单兵独自导致19086败。新v11将1079延寿至15841，但随后15824..16335护军/医师/召唤群坍塌，未获胜。原牧师2001 v11死16095、基线21754。

v11真实summoner contractArcher1208在9000..15600共12个600tick保存点都82/93、follow同牧师2001；缺11小于原生自动治疗门槛55/2=27.5。多数距离32..146<240，说明until-full可能提出自动医疗无法完成的目标。12点跨度6600tick不等于证明每个中间tick连续follow。独立审查目录保留所有观测与来源。

archer所有候选与5f的普通0直到9600保存帧相同；共同9600->10800三源重演分别吻合各自原0的10800，9615checkpoint全部闭合。首差异10050：骑手25/109原follow2255，而1907已cast heal指向骑手；原策略换向更近1907，v11/v12继续旧2255。首次实际55治疗为10059 vs10060。10125 v11与v12分叉：80/109骑手已进入2255范围，v12恢复camp攻击，v11继续follow。不能只从这条早期行为推出全局唯一败因。

v11真0骑手2503延寿至17069（原10681），16800已3kills192xp；最终仍战死。老兵maxHp增长会同时加hp，不能把125/145->147/167等增长算成治疗；独立审查已明确此限制。

## 换码局部窗

10260输入来自原5f真实普通0完整世界、nextId与三方memory，额外setup只为精确恢复配置。v10未解决nearest医师切换，骑手10680死（原10681）。v11 10260->11400骑手实际10636从80/109治至109/109，11400受两次20伤后69。v12短窗到11400仍80未治疗但存活。因此未治疗本身不是v12短窗失败；不能把该换码续局当普通0成绩，也不能把它误连到新普通0的不同历史。各自10275 JSON checkpoint world/nextId/all3mem均闭合，1479源前后不变。

原10665 near-threat漏掉ogre的假说已被实际fine帧否证：ogre在near，near与fullFoes给相同命令；本补丁没有fullFoes策略修改。完整原query证据保留在baseline相关目录与上层既有交付中。

## 测试与负例

v11最初旧42项测试36过/6红；六红都要求25->80跨35%后立即恢复sortie，原代码与原失败日志保留。test-only d708c982将其有意改为真实连续原生治疗到满血再必须恢复sortie，三路线/镜像6项加实际10275 handoff/queue/fullhealth3项共9过，tsc过；这只验证109HP病人可在两次55治疗后完成，不证明所有缺血可满血。新实际handoff测试在精确5f单文件反事实中1红/2过。

v12 test-only a2de3324保留旧35%六例，新增实际10275和新v11真实8220全档范围边界，共10过，tsc过。同4项新测试精确切旧5f是1红/3过（漏接近），精确切v11是1红/3过（范围内仍护理），生产文件已逐字恢复。所有测试不是胜率替代；v12照样有完整弓手败局。

测试首次tsc报告optional abilityCooldowns未判定，后以真实fixture非空断言修正，仅类型更改；保留两次失败日志。第一次同时存在test-only反事实切源，那个tsc不作为候选验证，最终固定源tsc另存成功。v11 terminal首次调用cwd为证据目录，frozen git lookup在模拟前失败；成功调用改到正确固定control cwd，无生产源码修改，原错误保留。

## 交付与下一步

care-follow-candidate-sources.tar.gz以SHA内容地址完整保存v10/v11/v12三份1479文件profile及d708测试，所有载荷已校验；四场完整普通0的live/frozen源码胶囊另存。v11/v12生产增量patch及各自test-only patch可审查，均不建议现在合入。原geometry457的独立证据/回归不在这里重写。

下一候选应分清“已有合法医疗follow证明尚在接近任务”和“必须锁定旧医师”两件事，保留原nearestByRoute选择能力，并在所选医师实际治疗范围内恢复既有triage。先做真实10050/10275与召唤8205边界短窗，再决定普通0；不新增通用医疗记忆或用他人CD猜患者获治。所有三路线目标、完整对手组合与地图/种子泛化要求仍未完成。
