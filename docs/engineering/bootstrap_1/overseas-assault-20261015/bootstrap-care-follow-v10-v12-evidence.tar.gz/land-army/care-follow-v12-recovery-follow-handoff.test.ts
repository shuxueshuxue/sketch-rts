import { readFileSync } from 'node:fs';
import { expect, it } from 'vitest';
import { createGame, issuePlayerCommand, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import type { GameSnapshot } from '../../shared/types';
import type { AiPolicyMemory } from '../memory';
import { planAiOwnerCommandEntries } from '../planner-context';
import { nearestByRoute } from '../../shared/route-selection';

// Actual rules2 Grove v9_archer ordinary0, pineshade-generated ladder,
// bootstrap_1-unseen-archer-v8-v8-20261015-01, normal frozen v8 Ember+Grove.
// At10275 the wounded rider still follows its reachable medic1907; medic2255 has just become nearer.
const fixture = JSON.parse(readFileSync(new URL('./fixtures/recovery-follow-handoff-10275.json', import.meta.url), 'utf8')) as {
  snapshot: GameSnapshot; nextId: number; memories: Record<string, AiPolicyMemory>;
};
const patientId = 'unit-p0-horseArcher-2503', followedMedic = 'unit-p0-fieldMedic-1907', nearerMedic = 'unit-p0-fieldMedic-2255';

function restore() {
  const game = createGame('bareDuel', { players: ['p0', 'p1', 'p2'], teams: fixture.snapshot.teams!, aiPlayers: [] });
  restoreSnapshotIntoGame(game, structuredClone(fixture.snapshot), fixture.nextId);
  expect(JSON.parse(JSON.stringify(snapshotGame(game)))).toEqual(fixture.snapshot);
  const memory = structuredClone(fixture.memories.p0!);
  const plan = () => planAiOwnerCommandEntries(snapshotGame(game), { playerId: 'p0', version: 'v9_archer', memory }, { teams: game.teams });
  return { game, plan };
}

function patientCare(entries: ReturnType<typeof planAiOwnerCommandEntries>) {
  return entries.filter(entry => entry.scriptId === 'mobileCare' && 'unitIds' in entry.command && entry.command.unitIds.includes(patientId));
}

it('keeps the unfinished native medical follow when another legal healer becomes nearer', () => {
  const { game, plan } = restore(), patient = game.units.find(unit => unit.id === patientId)!;
  const healers = game.units.filter(unit => unit.id === followedMedic || unit.id === nearerMedic);
  expect(patient.order).toEqual({ type: 'follow', targetId: followedMedic });
  expect(nearestByRoute(game.map, healers, patient, 'land')!.id).toBe(nearerMedic);
  expect(nearestByRoute(game.map, healers.filter(unit => unit.id === followedMedic), patient, 'land')!.id).toBe(followedMedic);
  const entries = plan();
  expect(patientCare(entries)).toEqual([{ playerId: 'p0', scriptId: 'mobileCare', command: { type: 'follow', unitIds: [patientId], targetId: followedMedic } }]);
  expect(entries.some(entry => entry.scriptId === 'mountedTasks' && 'unitIds' in entry.command && entry.command.unitIds.includes(patientId))).toBe(false);
});

it('does not add a medical follow claim when a valid subsequent follow is queued', () => {
  const { game, plan } = restore();
  issuePlayerCommand(game, 'p0', { type: 'follow', unitIds: [patientId], targetId: nearerMedic, queued: true });
  expect(game.units.find(unit => unit.id === patientId)!.orderQueue).toEqual([{ type: 'follow', targetId: nearerMedic }]);
  expect(patientCare(plan())).toEqual([]);
});

it('releases the existing medical follow after the patient reaches full health', () => {
  const { game, plan } = restore(), patient = game.units.find(unit => unit.id === patientId)!;
  patient.hp = patient.maxHp;
  expect(patientCare(plan())).toEqual([]);
});

// Actual118cc3b9 changed-code ordinary8220: 1079 was already healed18->73 at8196,
// is following its own medic within native heal range, and the medic is on cooldown.
// This second real fixture is a policy boundary counterfactual, not a new ordinary score.
it('releases an already in-range noncritical follow to the original defense policy without waiting for another heal', () => {
  const saved = JSON.parse(readFileSync(new URL('./fixtures/recovery-follow-in-range-8220.json', import.meta.url), 'utf8')) as typeof fixture;
  const game = createGame('bareDuel', { players: ['p0', 'p1', 'p2'], teams: saved.snapshot.teams!, aiPlayers: [] });
  restoreSnapshotIntoGame(game, structuredClone(saved.snapshot), saved.nextId);
  const patient = game.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  const medic = game.units.find(unit => unit.id === 'unit-p0-priest-2001')!;
  expect(patient.hp).toBe(73);
  expect(patient.order).toEqual({ type: 'follow', targetId: medic.id });
  expect(Math.hypot(patient.x - medic.x, patient.y - medic.y)).toBeLessThan(240);
  expect(medic.abilityCooldowns!.heal).toBeGreaterThan(0);
  const entries = planAiOwnerCommandEntries(snapshotGame(game), { playerId: 'p0', version: 'v9_summoner', memory: structuredClone(saved.memories.p0!) }, { teams: game.teams });
  expect(entries.some(entry => entry.scriptId === 'mobileCare' && 'unitIds' in entry.command && entry.command.unitIds.includes(patient.id))).toBe(false);
});
