"""Prepare a selected fixed-source bootstrap opening; never starts or resumes gameplay."""
import argparse, hashlib, io, json, pathlib, subprocess, tarfile
from datetime import datetime, timezone

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', required=True)
parser.add_argument('--commit', required=True)
parser.add_argument('--out-prefix', required=True)
parser.add_argument('--map', required=True)
parser.add_argument('--seed', required=True)
parser.add_argument('--subject', choices=['v9_archer','v9_summoner','v9_knight'], required=True)
parser.add_argument('--opponents', choices=['v5','v7','v8','v5+v7','v5+v8','v7+v8','v5+v5','v7+v7','v8+v8'], required=True)
parser.add_argument('--race', choices=['grove','ember'], required=True)
parser.add_argument('--side', type=int, choices=[0,1], required=True)
parser.add_argument('--unseen', action='store_true')
parser.add_argument('--ticks', type=int, default=144000)
parser.add_argument('--sample-ticks', type=int, default=1200)
parser.add_argument('--baseline-opening', help='Optional exact-world control only; omit for a deliberately different family, race or generated seed.')
args = parser.parse_args()
source = pathlib.Path(args.source_root).resolve()
prefix = pathlib.Path(args.out_prefix).resolve()
assert source != pathlib.Path('/workspace/sketch-rts-bootstrap-resume'), 'Use an isolated fixed worktree, never the mutable integration tree'

def git(*argv): return subprocess.check_output(['git', *argv], cwd=source)
def sha(data): return hashlib.sha256(data).hexdigest()
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

commit = git('rev-parse','HEAD').decode().strip()
expected = git('rev-parse',args.commit+'^{commit}').decode().strip()
assert commit == expected, (commit, expected)
status = git('status','--porcelain','--untracked-files=normal').decode()
assert not status, 'Source worktree must be clean before source capture: '+status
assert not pathlib.Path(str(prefix)+'.json').exists(), 'Never overwrite a previous game report'
for suffix in ['-runtime-source.json','-opening.json','-launch.json','-sources.tar.gz']:
    assert not pathlib.Path(str(prefix)+suffix).exists(), 'Never overwrite prelaunch evidence '+suffix
frame_dir = pathlib.Path(str(prefix)+'.json.frames')
assert not frame_dir.exists(), 'Never overwrite a previous frame directory'
prefix.parent.mkdir(parents=True, exist_ok=True)
frame_dir.mkdir()
manifest_path = source/'docs/engineering/bootstrap_1/frozen-policy.json'
manifest_data = manifest_path.read_bytes()
manifest = json.loads(manifest_data)
assert manifest['rulesVersion'] == 2
assert manifest['revision'] == 'd1ae110f2edd99f9c7d899ed61557891ab587639'
assert sha(manifest_data) == '0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'

# This witness is prepared before the ordinary run. The unmodified inspect
# script constructs its own game from the same deterministic public factory;
# this is not falsely labelled an in-process game-loop capture.
preflight = pathlib.Path(str(prefix)+'-prelaunch-opening.ts')
preflight.write_text('''import {readFileSync,writeFileSync}from'node:fs';
import{pathToFileURL}from'node:url';
const source=SOURCE,opening=OPENING,frame=FRAME,selection=SELECTION;
const{bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const{snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const{createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const match=bootstrapMatches(selection.seed,[selection.map],selection.ticks,selection.unseen)
 .find((m:any)=>m.subject===selection.subject&&m.side===selection.side&&m.agents.p0.race===selection.race
 &&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===selection.opponents);
if(!match)throw new Error('Exact ordinary match missing');
const game=bootstrapGame(match),snapshot=snapshotGame(game),provider=createAiMemoryProvider();
const initial=Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,{gold:game.players[owner].gold,
 supplyUsed:game.players[owner].supplyUsed,supplyCap:game.players[owner].supplyCap,
 units:game.units.filter((u:any)=>u.owner===owner).map((u:any)=>u.kind)}]));
const manifest=JSON.parse(readFileSync(source+'/docs/engineering/bootstrap_1/frozen-policy.json','utf8'));
if(game.tick!==0||manifest.rulesVersion!==2||Object.values(initial).some((p:any)=>p.gold!==500
 ||p.supplyUsed!==3||p.supplyCap!==8||p.units.join(',')!=='worker,worker,worker'))throw new Error('Standard opening changed');
const memories=Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,provider.get(owner)??null]));
writeFileSync(frame,JSON.stringify({snapshot,nextId:game.nextId,memories,
 memoryLifecycle:'Fresh policy provider has no initialized owner memories before the first think. Null records that absence, not a seeded strategy.'})+'\\n');
writeFileSync(opening,JSON.stringify({classification:'Prelaunch deterministic standard bootstrapGame tick0 witness. The unmodified inspect runner constructs the same factory opening independently. No restore, commands, world edits, or seeded memories.',
 match,initial,rulesVersion:manifest.rulesVersion,frozenRevision:manifest.revision,snapshot,nextId:game.nextId,memories})+'\\n');
console.log(JSON.stringify({tick:game.tick,initial,nextId:game.nextId}));
'''.replace('SELECTION',json.dumps({'map':args.map,'seed':args.seed,'subject':args.subject,'opponents':args.opponents,'race':args.race,'side':args.side,'unseen':args.unseen,'ticks':args.ticks})).replace('SOURCE',json.dumps(str(source))).replace('OPENING',json.dumps(str(prefix)+'-opening.json')).replace('FRAME',json.dumps(str(frame_dir/'0.json'))))
subprocess.run(['node','--import','tsx',str(preflight)],cwd=source,check=True)
opening_path = pathlib.Path(str(prefix)+'-opening.json')
opening = json.loads(opening_path.read_text())
comparison = {'classification':'Prelaunch witness; deliberately selected match, no world edits', 'baselineCompared':False}
if args.baseline_opening:
    baseline_path=pathlib.Path(args.baseline_opening);baseline=json.loads(baseline_path.read_text())
    comparison={'classification':'Requested exact-control structural comparison, no gameplay','baselineCompared':True,
      'baselinePath':str(baseline_path),'baselineSHA256':sha(baseline_path.read_bytes()),
      'snapshotEqual':opening['snapshot']==baseline['snapshot'],'nextIdEqual':opening['nextId']==baseline['nextId'],
      'initialEqual':opening['initial']==baseline['initial']}
    assert all(comparison[k] for k in ['snapshotEqual','nextIdEqual','initialEqual']), 'Requested exact control differs; do not alter world to fit it'
write_json(pathlib.Path(str(prefix)+'-opening-comparison.json'),comparison)

runtime = {}
all_source = {}
# Independent observer also uses the real native client and recorder; capture every src byte.
for tree in ['src']:
    for path in sorted((source/tree).rglob('*')):
        if not path.is_file(): continue
        name = str(path.relative_to(source)); data = path.read_bytes(); all_source[name] = data
        if path.suffix in ('.ts','.tsx'): runtime[name] = sha(data)
for path in sorted((source/'scripts').glob('bootstrap_1*.ts')):
    name = str(path.relative_to(source)); data = path.read_bytes(); all_source[name] = data; runtime[name] = sha(data)
for name in ['package.json','package-lock.json','tsconfig.json']:
    all_source[name] = (source/name).read_bytes()
frozen_tar = git('archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared')
frozen = {}
with tarfile.open(fileobj=io.BytesIO(frozen_tar),mode='r:') as tf:
    for member in tf:
        if member.isfile(): frozen[member.name] = tf.extractfile(member).read()
for name, digest in manifest['files'].items(): assert sha(frozen[name]) == digest, name
archive_path = pathlib.Path(str(prefix)+'-sources.tar.gz')
archive_entries = {}
with tarfile.open(archive_path,mode='w:gz',compresslevel=6) as tf:
    def append(name,data):
        entry = tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644; entry.mtime=0;tf.addfile(entry,io.BytesIO(data));archive_entries[name]=sha(data)
    for name,data in sorted(all_source.items()): append('live/'+name,data)
    for name,data in sorted(frozen.items()): append('frozen/'+name,data)
    append('frozen-policy.json',manifest_data)
    append('prelaunch-opening.ts',preflight.read_bytes())
    append('prepare-fixed-bootstrap-opening.py',pathlib.Path(__file__).read_bytes())
    data=json.dumps({'algorithm':'SHA-256','files':archive_entries},indent=2).encode()+b'\n'
    entry=tarfile.TarInfo('INDEX.json');entry.size=len(data);entry.mode=0o644;entry.mtime=0;tf.addfile(entry,io.BytesIO(data))
with tarfile.open(archive_path,mode='r:gz') as tf:
    index=json.loads(tf.extractfile('INDEX.json').read())
    for name,digest in index['files'].items(): assert sha(tf.extractfile(name).read()) == digest,name
# Use the existing inspect factory and planner without a resume or manual game controller.
command=['node','--import','tsx','scripts/bootstrap_1-inspect.ts','--map',args.map,
 '--seed',args.seed,'--subject',args.subject,'--opponents',args.opponents,'--race',args.race,'--side',str(args.side),
 '--ticks',str(args.ticks),'--sample-ticks',str(args.sample_ticks),'--frames','--out',str(prefix)+'.json']
if args.unseen:command.append('--unseen')
assert git('rev-parse','HEAD').decode().strip() == commit and not git('status','--porcelain','--untracked-files=normal').decode()
capsule={'classification':'Prelaunch clean fixed-commit ordinary tick0 source. No changed-code resume and no manual gameplay commands.',
 'createdAtUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':commit,'sourceRoot':str(source),'trackedDiff':'','newSources':{},
 'runtimeHashes':runtime,'supportingDataHashes':{name:sha(data)for name,data in all_source.items()if name not in runtime},
 'frozenManifestSha256':sha(manifest_data),'frozenRevision':manifest['revision'],'frozenManifestEntriesVerified':len(manifest['files']),
 'fullSourceArchive':str(archive_path),'fullSourceArchiveSHA256':sha(archive_path.read_bytes()),'sourceArchivePayloadsVerified':len(index['files']),
 'openingPath':str(opening_path),'openingSHA256':sha(opening_path.read_bytes()),'openingFrameSHA256':sha((frame_dir/'0.json').read_bytes()),
 'openingComparison':comparison,'observerPreflightScriptSHA256':sha(preflight.read_bytes()),
 'command':command,'cwd':str(source),'inspectionHorizonNote':'144000 is only a recorded inspection horizon; a winner/endedAtTick and actual whole-match evidence decide the result. Continue the same source if the horizon is reached without a winner.'}
write_json(pathlib.Path(str(prefix)+'-runtime-source.json'),capsule)
launch={'preparedOnly':True,'gameplayStarted':False,'expectedCommit':commit,'cwd':str(source),'argv':command,
 'stdoutLog':str(prefix)+'.log','prelaunchRuntimeFiles':len(runtime),'openingComparison':comparison,'selection':{'map':args.map,'seed':args.seed,'subject':args.subject,'opponents':args.opponents,'race':args.race,'side':args.side,'unseen':args.unseen}}
write_json(pathlib.Path(str(prefix)+'-launch.json'),launch)
print(json.dumps(launch,indent=2))
