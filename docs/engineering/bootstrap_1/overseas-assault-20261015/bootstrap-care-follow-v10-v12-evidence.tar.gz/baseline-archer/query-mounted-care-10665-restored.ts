import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const source='/tmp/sketch-rts-mercenary-courier-safe-stop-control';
const dir='/tmp/bootstrap-archer-double-v8-courier-v2-20261015';
const path=dir+'/mounted-loss-fine-10200-10800.frames/10665.json';
const saved=JSON.parse(readFileSync(path,'utf8'));
const {createGame,restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const snapshot=snapshotGame(game),memory=structuredClone(saved.memories.p0);
const {isDeepStrictEqual}=await import('node:util');
if(!isDeepStrictEqual(JSON.parse(JSON.stringify(snapshot)),saved.snapshot)||game.nextId!==saved.nextId)throw new Error('Restore JSON protocol mismatch');
const before={world:JSON.stringify(snapshot),memory:JSON.stringify(memory)};
const {mainlandCareAssignments,patientRendezvousCommands}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/land-recovery.ts').href);
const {mountedEscape,mountedThreatReach,THINK_TICKS}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/mounted-micro.ts').href);
const {bootstrapPolicyContext}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/policy.ts').href);
const {sameGround}=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
const {unitMover,UNIT_DEFS,ABILITY_DEFS}=await import(pathToFileURL(source+'/src/shared/catalog.ts').href);
const {groundSteeringRoute,routePrefix}=await import(pathToFileURL(source+'/src/shared/route-selection.ts').href);
const {capsuleClearsBodies}=await import(pathToFileURL(source+'/src/shared/navigation-math.ts').href);
const {MOVE_ORDER_ARRIVAL_RANGE}=await import(pathToFileURL(source+'/src/shared/movement-rules.ts').href);
const {incomingItemDamage}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/damage-footprints.ts').href);
const options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory,teams:snapshot.teams});
const care=mainlandCareAssignments(snapshot,'p0',options);
const pair=care.recovering.find((p:any)=>p.patient.id==='unit-p0-horseArcher-2503');
if(!pair)throw new Error('Not the asserted recovering branch');
const {patient,healer}=pair,foes=pair.foes;
const gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
const threats=foes.filter((foe:any)=>sameGround(snapshot.map,patient,foe)
 && gap(patient,foe)<=mountedThreatReach(snapshot,foe,patient,THINK_TICKS)+('speed'in foe?foe.speed:0)*(THINK_TICKS+2)/20);
const ability=UNIT_DEFS[healer.kind].abilities.find((a:any)=>ABILITY_DEFS[a].behavior==='heal');
const road=groundSteeringRoute(snapshot.map,patient,healer),prefix=routePrefix(patient,road.slice(1),patient.speed*THINK_TICKS/20+MOVE_ORDER_ARRIVAL_RANGE),point=prefix[prefix.length-1];
const blockers=foes.filter((foe:any)=>'order'in foe&&!foe.deck&&unitMover(foe.kind)==='land').map((foe:any)=>({x:foe.x,y:foe.y,radius:foe.radius+(foe.attackRange<=100?foe.attackRange:0)}));
const report={classification:'Read-only query against actual fixed5f ordinary replay10665; counterfactual query is not a gameplay outcome',source,input:path,patient,healer,
 healerGap:gap(patient,healer),healRange:ABILITY_DEFS[ability].range,roadPrefixPoint:point,roadPrefixBodyClear:capsuleClearsBodies(patient,point,patient.radius,blockers),
 threats:threats.map((foe:any)=>({id:foe.id,kind:foe.kind,gap:gap(patient,foe),reach:mountedThreatReach(snapshot,foe,patient,THINK_TICKS),inclusionLimit:mountedThreatReach(snapshot,foe,patient,THINK_TICKS)+('speed'in foe?foe.speed:0)*17/20})),
 actualRendezvous:patientRendezvousCommands(snapshot,[pair],foes,pair.medics),
 actualNearEscape:mountedEscape(snapshot,patient,threats,0,healer,true),
 counterfactualAllFoesEscape:mountedEscape(snapshot,patient,foes,0,healer,true),
 incomingItemDamage:incomingItemDamage(snapshot,patient,foes,THINK_TICKS),
 worldUnchanged:JSON.stringify(snapshot)===before.world,memoryUnchanged:JSON.stringify(memory)===before.memory};
writeFileSync(dir+'/query-mounted-care-10665-restored.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
