import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const source='/tmp/sketch-rts-mercenary-courier-safe-stop-control',dir='/tmp/bootstrap-archer-double-v8-courier-v2-20261015';
const {mainlandCareAssignments}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/land-recovery.ts').href);
const {bootstrapPolicyContext}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/policy.ts').href);
const {incomingItemDamage}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/damage-footprints.ts').href);
const {abilityCooldown}=await import(pathToFileURL(source+'/src/shared/ability-cooldowns.ts').href);
const {UNIT_DEFS,ABILITY_DEFS}=await import(pathToFileURL(source+'/src/shared/catalog.ts').href);
const {createGame,restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const {routeTravelTicks}=await import(pathToFileURL(source+'/src/shared/route-selection.ts').href);
const {canReach}=await import(pathToFileURL(source+'/src/shared/naval.ts').href);
const {V7_WOUNDED_SHARE}=await import(pathToFileURL(source+'/src/ai/policy/v6/general.ts').href);
const {postRecoveryAssignments}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/front-recovery.ts').href);
const rows=[];
for(const tick of [10200,10260,10275,10290,10380,10620,10635,10665]){
 const saved=JSON.parse(readFileSync(`${dir}/mounted-loss-fine-10200-10800.frames/${tick}.json`,'utf8'));
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const snapshot=snapshotGame(game),memory=structuredClone(saved.memories.p0),before=JSON.stringify({snapshot,memory});
 if(!isDeepStrictEqual(JSON.parse(JSON.stringify(snapshot)),saved.snapshot)||game.nextId!==saved.nextId)throw new Error('Restored JSON protocol mismatch');
 const options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory,teams:snapshot.teams});
 const care=mainlandCareAssignments(snapshot,'p0',options);
 const patient=snapshot.units.find((u:any)=>u.id==='unit-p0-horseArcher-2503');
 const healer=snapshot.units.find((u:any)=>u.id==='unit-p0-fieldMedic-1907');
 const ability=UNIT_DEFS[healer.kind].abilities.find((a:any)=>ABILITY_DEFS[a].behavior==='heal');
 const window=Math.max(15,abilityCooldown(healer,ability));
 const weaponDamage=care.foes.reduce((damage:number,foe:any)=>damage+('order'in foe&&(foe.order.type==='attack'||foe.order.type==='attackMove')&&foe.order.targetId===patient.id?foe.attackDamage*Math.max(0,Math.ceil((window-foe.cooldown)/foe.attackCooldown)):0),0);
 rows.push({tick,restoredJSONWorldAndNextIdEqual:true,patient:{id:patient.id,owner:patient.owner,hp:patient.hp,maxHp:patient.maxHp,x:patient.x,y:patient.y,order:patient.order,orderQueue:patient.orderQueue,onDeck:!!patient.deck,inCabin:!!patient.cabin},healer:{id:healer.id,owner:healer.owner,hp:healer.hp,x:healer.x,y:healer.y,ability,healCooldown:abilityCooldown(healer,ability)},healerGap:Math.hypot(patient.x-healer.x,patient.y-healer.y),nativeReachable:canReach(snapshot.map,patient,healer,snapshot.units),landTravelTicks:routeTravelTicks(snapshot.map,patient,healer,'land',patient.speed),
  recovering:care.recovering.filter((x:any)=>x.patient.id===patient.id).map((x:any)=>({patient:x.patient.id,healer:x.healer.id})),
  unmedicated:care.unmedicated.filter((x:any)=>x.patient.id===patient.id).map((x:any)=>({patient:x.patient.id,cover:x.cover})),
  postMembership:postRecoveryAssignments(snapshot,'p0',options).filter((x:any)=>x.patient.id===patient.id).map((x:any)=>({post:x.post.id,kind:x.post.kind,walk:x.walk,point:x.point})),
  followTargetRiskQuery:{note:'Raw full-world query against the existing follow target; not a complete runner ownership/nearest-healer selection trace',window,criticalThreshold:patient.maxHp*V7_WOUNDED_SHARE,weaponDamage,critical:patient.hp<patient.maxHp*V7_WOUNDED_SHARE,lethalWeaponDamage:patient.hp<=weaponDamage},
  predictedItemDamage15:incomingItemDamage(snapshot,patient,care.foes,15),mountedObjective:memory.mounted,
  queryWorldAndMemoryUnchanged:JSON.stringify({snapshot,memory})===before});
}
writeFileSync(dir+'/query-mounted-care-handoff.json',JSON.stringify({classification:'Read-only actual native checkpoints; ownership and risk queries, not candidate gameplay',source,rows},null,2)+'\n');
console.log(JSON.stringify(rows));
