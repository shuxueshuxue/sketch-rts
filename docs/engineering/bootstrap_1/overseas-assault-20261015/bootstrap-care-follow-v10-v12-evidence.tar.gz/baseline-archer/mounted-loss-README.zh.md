# 获胜原局中的10681骑射手死亡：交给统一care调查

此包没有护理生产修复；固定clean5f657b380bcf85e5653e55b22db6ae68b671869d真实普通0整体43714获胜，唯一中立死为horseArcher2503。两个600tick窗口都从实际普通10200完整世界/nextId/p0+p1+p2全部策略记忆恢复，全三方AI原生执行至10800，endpoint世界、nextId、三方mem均与普通10800完全相等。coarse60与fine15完整checkpoint均保留，source1239 hashes全过程不变，frozen184/rules2不变。

实际死亡：10681 neutral ogreLord creep-gen-3-1携ready lightningRod，native updateItems先于该tick unit移动；10680原生距离237.705253已经在neutral item target240内。第一击84立即伤害，骑射手80/109当场死亡，再弹到p1两ravager，源action/hit/chainLightning与前后完整世界均保存。10680发新逃命命令已无法先移动出圈。原生10665/10681同镜头截图保留并亲看10681：窄道北方ogre、南方p1三ravager，骑射手夹在中间。fresh facing tracker不恢复历史动画；链电和死亡效果是实际保存状态。

必须撤回初猜：我最初估10665 ogre约308会被patientThreats近筛排除，精确fine帧否证。真实gap288.223825<=ready rod240+68×17/20=297.8，ogre在near集合。注册restoreSnapshotIntoGame的真实building-body metadata后只读query证明actualRendezvous==mountedEscape(near)==mountedEscape(allfoes)，命令都是(2068.4438,2773.6524)。此例不能证明直接扩大foes列表能救人。初次未注册map的direct JSON query原样保留，后续-restored才是正式几何query；两者实际命令结果相同。

10665实际进入有医rendezvous：own fieldMedic1907距1220.8>heal240，短路前缀(2084.4163,2904.4688)被身体挡住，转mountedEscape评分。existing incomingItemDamage能正确预测84，不是雷杖完全漏建模。不存在已证明的护理修复/全局胜率结论。

更早且可复现的任务归属：10200–10260 mobileCare真实follow own fieldMedic1907，患者一直80/109未治；10275仍原生follow同合法own healer、orderQueue空、无deck/cabin和board/cast/charge、原生canReach true，地面路程182tick、距离897.944仍远超heal240。raw recovering/unmedicated/postMembership均空，当前weapon-only incomingDamage0/非critical，下一真实命令改由mountedTasks attack creep。该未完成的真实follow医疗任务延续已交land_army统一care候选进一步对照，我没有修改固定源或新造care层。

query-mounted-care-handoff的followTargetRiskQuery只是对现存follow目标的原始完整世界风险计算，不是完整runner/最近医师/ownership选择trace。初始风险注释版本和一次诊断helper访问不存在care.posts的构造错误日志均保留；最终query通过公开postRecoveryAssignments查询，所有查询world/memory不变。10620另有moonWell post walk:true会让raw mobileCare排除，不能只看单个风险数倒推实际归属。

对手是普通frozen v8 Ember+Grove team b，主体Grove v9_archer side1；factory pineshade --unseen实际ladder4608²，seed bootstrap_1-unseen-archer-v8-v8-20261015-01现已开发，approved工厂席位和三方500/3/8未改。原故障容器未提交修改恢复缺口仍在，全部路线/地图/对手及未见泛化验收仍未完成。
