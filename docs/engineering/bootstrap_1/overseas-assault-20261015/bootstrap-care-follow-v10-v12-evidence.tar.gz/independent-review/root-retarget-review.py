from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, gzip, subprocess, io, tarfile

directory=Path('/tmp/bootstrap-care-follow-v11-ordinary0-independent-review')
source=Path('/tmp/bootstrap-root-retarget-3bdb-20261015')
def load(name):return json.loads((source/name).read_text())
def digest(path):return sha256(path.read_bytes()).hexdigest()
pre,restore,launch,result=map(load,['prelaunch-source.json','restore-preflight.json','launch.json','result.json'])
saved=load('input-complete-40860.json');original=json.loads(gzip.decompress((source/'input-original-fixture.json.gz').read_bytes()))
root=Path(pre['sourceRoot']);changed=[name for name,expected in pre['hashes'].items() if digest(root/name)!=expected]
manifest=json.loads((root/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
archive=subprocess.check_output(['git','archive',manifest['revision'],*manifest['files']],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive))as tar:
    frozen_mismatches=[name for name,expected in manifest['files'].items() if sha256(tar.extractfile(name).read()).hexdigest()!=expected]
end=result['final']['snapshot'];permanent=[death for death in result['deaths'] if death['owner']=='p0' and death.get('expiresTick') is None]
actual_landing=[]
for event in result['landings']:
    commands=[command for command in result['commands'] if command['command']['type']=='unloadPassenger' and command['command']['passengerId']==event['id'] and command['tick']<=event['tick']]
    latest=max(commands,key=lambda row:row['tick'])if commands else None
    proof=[]
    if latest:
        for frame in result['frames']:
            if frame['label']!='after-public-portrait' or frame['tick']!=latest['tick']:continue
            world=json.loads(gzip.decompress((source/frame['path']).read_bytes()))['snapshot']
            unit=next((unit for unit in world['units'] if unit['id']==event['id']),None)
            if unit and not unit.get('deck'):proof.append(frame['path'])
    actual_landing.append({'unitId':event['id'],'kind':event['kind'],'onStepFirstObservedTick':event['tick'],
        'publicUnloadTick':latest['tick']if latest else None,'afterPublicFrameProofs':proof,'unloadedBeforeNextStep':bool(proof)})
stats_start=saved['snapshot']['match']['stats'];stats_end=end['match']['stats']
report={'classification':'Independent read-only audit of root3bdb changed-code continuation40860→49964, not an ordinary0 game or new improvement over prior V2.',
    'inputSnapshotNextIdBothMemoriesEqualOriginalFixture':{key:saved[key]==original[key]for key in ['snapshot','nextId','memories']},
    'inputFixtureHashMatches':digest(source/'input-original-fixture.json.gz')==pre['inputFixtureSHA256'],
    'inputCompleteHashMatches':digest(source/'input-complete-40860.json')==pre['inputCompleteSHA256'],
    'restorePreflight':restore['restored'],'activePlayers':restore['activePlayers'],'teams':restore['teams'],'agents':pre['agents'],'setup':pre['originalSetup'],
    'sourceCommit':pre['commit'],'currentCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'currentGitStatus':subprocess.check_output(['git','status','--short'],cwd=root,text=True).strip(),'sourceFilesIndependentlyRechecked':len(pre['hashes']),'sourceMismatches':changed,
    'driverHashMatchesLaunch':digest(source/'run-root-continuation.ts')==launch['driverSHA256'],
    'frozenVerification':{'revision':manifest['revision'],'rulesVersion':manifest['rulesVersion'],'entries':len(manifest['files']),'mismatches':frozen_mismatches},
    'start':result['start'],'end':result['end'],'winner':result['winner'],'endedAtTick':result['endedAtTick'],'naturalEndBeforeHorizon':result['end']<result['horizon']and end['match']['winner']=='p0',
    'finalReplayReportedByRunner':result['replay'],'finalJsonEqualsStandaloneComplete':result['final']==load('final-complete.json'),
    'enemySurvivors':{'units':sum(unit['owner']=='p1'for unit in end['units']),'buildings':sum(building['owner']=='p1'for building in end['buildings'])},
    'p0PermanentDeathsInThisContinuation':permanent,'p0PermanentDeathsByKind':dict(Counter(death['kind']for death in permanent)),
    'p0NativeUnitsLostCumulative':stats_end['unitsLost']['p0'],'p0NativeUnitsLostDelta':stats_end['unitsLost']['p0']-stats_start['unitsLost']['p0'],
    'p0NativeNeutralLossCumulative':stats_end['unitsKilledByNeutral']['p0'],'p0NativeNeutralLossDelta':stats_end['unitsKilledByNeutral']['p0']-stats_start['unitsKilledByNeutral']['p0'],
    'landings':actual_landing,'landingPermanentCombatCount':len(actual_landing),
    'eventTimingCorrection':'All seven permanent combat landings execute through public portrait unload at48825 and are already off deck in afterIssue full saved frames. The landings array tick48826 is the next onStep observation. Preserve both times and do not call48826 the execution tick.',
    'driverReview':'Restores complete snapshot,nextId and both memories; creates ordinary bootstrap planner with frozen v8 delegation and runs both normal agents. Observer/capture hooks read and record only. The final-window replay is same-source verification, not another game. No resource, unit, order, policy-memory or map edits were found in the continuation runner.',
    'noNewGameOrTestOrSourceMutationByReviewer':True,'originalContainerUncommittedGap':'Still unavailable and unrecovered.'}
(directory/'root-retarget-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'resultPath':str(directory/'root-retarget-comparison.json'),'sourceMismatches':changed,'frozenMismatches':frozen_mismatches,'naturalEnd':report['naturalEndBeforeHorizon'],'permanentDeaths':len(permanent),'landingCount':len(actual_landing),'allLandingsHaveImmediatePublicProof':all(row['unloadedBeforeNextStep']for row in actual_landing),'replay':result['replay']},indent=2))
