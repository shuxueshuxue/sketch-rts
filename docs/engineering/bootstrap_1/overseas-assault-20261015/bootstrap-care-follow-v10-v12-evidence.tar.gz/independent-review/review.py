from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, math, subprocess, tarfile, io

out = Path('/tmp/bootstrap-care-follow-v11-ordinary0-independent-review')
inputs = {
    'v11': Path('/tmp/bootstrap-land-army-evidence-20261015/archer-courier-follow-v11-ordinary0.json'),
    '5f': Path('/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary.json'),
}
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def unit_summary(unit):
    return {key: unit.get(key) for key in ['id','kind','x','y','hp','maxHp','order','cooldown','kills','xp','level']}

runs = {}
for label, path in inputs.items():
    report = json.loads(path.read_text())
    frame_dir = Path(str(path)+'.frames')
    frames = {int(p.stem): json.loads(p.read_text()) for p in sorted(frame_dir.glob('*.json'), key=lambda p:int(p.stem))}
    source_manifest_path = Path(str(path).removesuffix('.json')+'-runtime-source.json')
    source_manifest = json.loads(source_manifest_path.read_text())
    root = Path(source_manifest['sourceRoot'])
    source_mismatches = []
    for kind in ['runtimeHashes','supportingDataHashes']:
        for name, expected in source_manifest[kind].items():
            actual = digest(root/name) if (root/name).is_file() else None
            if actual != expected: source_mismatches.append({'kind':kind,'path':name,'expected':expected,'actual':actual})
    terminal = frames[report['result']['tick']]['snapshot']
    corpses = [corpse for corpse in terminal['corpses'] if corpse['owner']=='p0']
    own = [unit for unit in terminal['units'] if unit['owner']=='p0']
    buildings = [building for building in terminal['buildings'] if building['owner']=='p0']
    stats = terminal['match']['stats']
    rider_observations, follow_observations, timeline = [], [], []
    for tick, frame in frames.items():
        snapshot = frame['snapshot']
        own_at = {unit['id']:unit for unit in snapshot['units'] if unit['owner']=='p0'}
        rider = own_at.get('unit-p0-horseArcher-2503')
        if rider: rider_observations.append({'tick':tick,**unit_summary(rider)})
        for unit in own_at.values():
            if unit['kind']=='worker' or unit.get('expiresTick') is not None or unit['order']['type']!='follow':continue
            healer = own_at.get(unit['order']['targetId'])
            follow_observations.append({'tick':tick,**unit_summary(unit),'targetPresentAndOwn':healer is not None,
                'targetKind':healer['kind'] if healer else None,
                'targetDistance':math.hypot(unit['x']-healer['x'],unit['y']-healer['y']) if healer else None})
        stat = snapshot['match']['stats']
        timeline.append({'tick':tick,'unitsLost':stat['unitsLost'].get('p0',0),'unitsKilledByNeutral':stat['unitsKilledByNeutral'].get('p0',0),
            'units':len(own_at),'army':sum(unit['kind']!='worker' and unit.get('expiresTick') is None for unit in own_at.values()),
            'bases':sum(building['owner']=='p0' and building['kind']=='townHall' for building in snapshot['buildings'])})
    runs[label] = {'report':report,'frames':frames,'evidence':{
        'sourceRoot':str(root),'sourceManifestPath':str(source_manifest_path),'sourceManifestSha256':digest(source_manifest_path),
        'sourceCommit':source_manifest['baseCommit'],'currentCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'currentGitStatus':subprocess.check_output(['git','status','--short'],cwd=root,text=True).strip(),
        'runtimeFilesRechecked':len(source_manifest['runtimeHashes']),'supportingFilesRechecked':len(source_manifest['supportingDataHashes']),
        'sourceMismatches':source_mismatches,'frozenRevision':source_manifest['frozenRevision'],'frozenManifestSha256':source_manifest['frozenManifestSha256'],
        'reportPath':str(path),'reportSha256':digest(path),'setup':report['setup'],'result':report['result'],
        'frameCount':len(frames),'openingFrameSha256':digest(frame_dir/'0.json'),'terminalFrameSha256':digest(frame_dir/f"{terminal['tick']}.json"),
        'terminalNextId':frames[terminal['tick']]['nextId'],'terminalMatch':terminal['match'],
        'permanentLossCount':len(corpses),'permanentLossCountEqualsNativeUnitsLost':len(corpses)==stats['unitsLost']['p0'],
        'permanentLossKindCounts':dict(Counter(corpse['kind'] for corpse in corpses)),
        'permanentLosses':corpses,'neutralLossCount':stats['unitsKilledByNeutral']['p0'],
        'endUnits':len(own),'endArmy':sum(unit['kind']!='worker' and unit.get('expiresTick') is None for unit in own),
        'endBuildings':len(buildings),'endHalls':sum(building['kind']=='townHall' for building in buildings),
        'endVeterans':[unit_summary(unit) for unit in own if unit.get('level',0)>=1],
        'rider2503Observations':rider_observations,
        'rider2503Corpse':next((corpse for corpse in corpses if corpse['unitId']=='unit-p0-horseArcher-2503'),None),
        'healerFollowObservations':follow_observations,
        'fullHealthFollowObservations':[row for row in follow_observations if row['hp']>=row['maxHp']],
        'followToAbsentOwnTargetObservations':[row for row in follow_observations if not row['targetPresentAndOwn']],
        'timeline':timeline,
    }}
    sampled_groups=[]
    for unit_id,target_id in sorted({(row['id'],row['order']['targetId']) for row in follow_observations}):
        points=[row['tick'] for row in follow_observations if row['id']==unit_id and row['order']['targetId']==target_id]
        groups=[]
        for point in points:
            if groups and point-groups[-1][-1]==600:groups[-1].append(point)
            else:groups.append([point])
        for group in groups:
            next_frame=frames.get(group[-1]+600)
            next_unit=next((unit for unit in next_frame['snapshot']['units'] if unit['id']==unit_id),None) if next_frame else None
            sampled_groups.append({'unitId':unit_id,'targetId':target_id,'sampledTicks':group,'sampledSpanTicks':group[-1]-group[0],
                'nextSavedTick':group[-1]+600 if next_frame else None,'nextSavedUnit':unit_summary(next_unit) if next_unit else None})
    runs[label]['evidence']['followConsecutiveSampleGroups']=sampled_groups
    runs[label]['evidence']['longestFollowSampleSpanTicks']=max((group['sampledSpanTicks'] for group in sampled_groups),default=0)
    runs[label]['evidence']['followSampleSpanLimit']='Adjacent matching 600-tick observations do not establish uninterrupted follow or exact waiting duration; a zero sampled span means one observation, not zero waiting.'

root=Path(runs['v11']['evidence']['sourceRoot'])
manifest=json.loads((root/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
archive=subprocess.check_output(['git','archive',manifest['revision'],*manifest['files']],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    frozen_mismatches=[name for name,expected in manifest['files'].items() if sha256(tar.extractfile(name).read()).hexdigest()!=expected]

common_ticks=sorted(set(runs['v11']['frames']) & set(runs['5f']['frames']))
same_prefix=[]
for tick in common_ticks:
    a,b=runs['v11']['frames'][tick],runs['5f']['frames'][tick]
    if a['snapshot']==b['snapshot'] and a['nextId']==b['nextId']:same_prefix.append(tick)
    else:break
native_a=runs['v11']['evidence']['terminalMatch']['stats'];native_b=runs['5f']['evidence']['terminalMatch']['stats']
rows_a={row['tick']:row for row in runs['v11']['report']['rows']};rows_b={row['tick']:row for row in runs['5f']['report']['rows']}
prefix_policy=[{'tick':tick,'allThreePolicyMemoriesEqual':all(rows_a[tick]['players'][owner]['policy']==rows_b[tick]['players'][owner]['policy'] for owner in ['p0','p1','p2'])} for tick in same_prefix if tick in rows_a and tick in rows_b]
delta={
    'endTick':runs['v11']['evidence']['result']['tick']-runs['5f']['evidence']['result']['tick'],
    'permanentLosses':native_a['unitsLost']['p0']-native_b['unitsLost']['p0'],
    'neutralLosses':native_a['unitsKilledByNeutral']['p0']-native_b['unitsKilledByNeutral']['p0'],
    'goldSpent':native_a['goldSpent']['p0']-native_b['goldSpent']['p0'],
    'rider2503LifetimeExtensionTicks':runs['v11']['evidence']['rider2503Corpse']['diedAtTick']-runs['5f']['evidence']['rider2503Corpse']['diedAtTick'],
}
result={'classification':'Independent read-only comparison of two complete ordinary tick0 matches on the same already-developed seed. No local changed-code continuation is credited to these runs.',
    'runs':{label:run['evidence'] for label,run in runs.items()},
    'setupEqual':runs['v11']['report']['setup']==runs['5f']['report']['setup'],
    'fixedCommitDiffStat':subprocess.check_output(['git','diff','--stat',runs['5f']['evidence']['sourceCommit'],runs['v11']['evidence']['sourceCommit']],cwd=root,text=True),
    'equalWorldAndNextIdPrefixAtSavedTicks':same_prefix,'firstDifferentSavedTick':common_ticks[len(same_prefix)],
    'prefixPolicyMemoryEquality':prefix_policy,
    'frozenPolicyIndependentVerification':{'revision':manifest['revision'],'rulesVersion':manifest['rulesVersion'],'entries':len(manifest['files']),'mismatches':frozen_mismatches},
    'v11Minus5f':delta,
    'careDelayAssessment':{'scope':'600-tick saved-state observations only; absence of a sampled full-health follow is not proof that no short wait occurred.',
        'observations':'v11 has six wounded healer-follow observations across three patients and no full-health or absent-own-target follow observations. Rider2503 is attacking at10800,12000,13800,14400,16800, interleaved with actual healing and follow states. Lancer5832 follows wounded at13800 and is no longer following at14400; lancer18431 follows wounded at22800 and is no longer following at23400. No obvious persistent care lock is visible, but exact care/wait duration cannot be determined from these coarse saves.',
        'earlyTradeoff':'By13200 v11 has7 permanent losses versus4 in5f. Couriers1347 and1107 die10404/13043 in v11 versus16917/25673 in5f. The complete run has lower aggregate losses but not monotonic local improvement.',
        'causalLimit':'Only land-recovery.ts differs between fixed commits and starts match; paired outcomes support benefit on this development seed. They do not isolate rescued rider2503 as the cause of victory, establish unseen-seed generalization, or complete any family acceptance.'},
    'noSimulationOrSourceMutation':True,'originalContainerUncommittedRecoveryGap':'Still unavailable and unrecovered.'}
(out/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'resultPath':str(out/'comparison.json'),'v11Minus5f':delta,'setupEqual':result['setupEqual'],'prefixLastEqualTick':same_prefix[-1],
    'sourceMismatches':{label:run['evidence']['sourceMismatches'] for label,run in runs.items()},'frozenMismatches':frozen_mismatches,
    'followObservations':{label:len(run['evidence']['healerFollowObservations']) for label,run in runs.items()},
    'fullHealthFollowObservations':{label:len(run['evidence']['fullHealthFollowObservations']) for label,run in runs.items()}},indent=2))
