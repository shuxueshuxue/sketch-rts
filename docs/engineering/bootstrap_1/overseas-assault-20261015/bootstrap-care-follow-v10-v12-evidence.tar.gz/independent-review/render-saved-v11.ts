import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const source='/workspace/sketch-rts-care-follow-v11-control';
const directory='/tmp/bootstrap-care-follow-v11-ordinary0-independent-review';
const {createCanvas}=await import(pathToFileURL(source+'/node_modules/@napi-rs/canvas/index.js').href);
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const outputs=[];
for(const tick of [10200,13200,16800]){
  const input=`/tmp/bootstrap-land-army-evidence-20261015/archer-courier-follow-v11-ordinary0.json.frames/${tick}.json`;
  const bytes=readFileSync(input),{snapshot}=JSON.parse(bytes.toString());
  const rider=snapshot.units.find((unit:any)=>unit.id==='unit-p0-horseArcher-2503');
  const view={x:Math.max(0,rider.x-500),y:Math.max(0,rider.y-450),width:1000,height:900,zoom:1};
  const canvas=createCanvas(view.width,view.height);
  drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
  const output=`${directory}/v11-ordinary0-native-rider-${tick}.png`;
  writeFileSync(output,canvas.toBuffer('image/png'));
  outputs.push({tick,input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),output,view});
}
writeFileSync(directory+'/native-visual.json',JSON.stringify({classification:'Native drawWorld rendering of true ordinary0 saved snapshots only. No game-loop execution. Facing animation is not reconstructed.',source,outputs},null,2)+'\n');
console.log(JSON.stringify(outputs));
