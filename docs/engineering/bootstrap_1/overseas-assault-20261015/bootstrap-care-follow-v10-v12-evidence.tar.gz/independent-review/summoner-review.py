from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, subprocess

directory=Path('/tmp/bootstrap-care-follow-v11-ordinary0-independent-review')
source=Path('/tmp/bootstrap-land-army-evidence-20261015')
labels={'v11':'summoner-bridge-follow-v11-ordinary0','base457':'summoner-bridge-arrival-v9-ordinary0'}
runs={}
def digest(p):return sha256(p.read_bytes()).hexdigest()
for label,name in labels.items():
    p=source/(name+'.json');r=json.loads(p.read_text());frames={int(p.stem):json.loads(p.read_text()) for p in sorted((source/(name+'.json.frames')).glob('*.json'),key=lambda p:int(p.stem))}
    mpath=source/(name+'-runtime-source.json');m=json.loads(mpath.read_text());root=Path(m['sourceRoot']);mismatches=[]
    for kind in ['runtimeHashes','supportingDataHashes']:
        for path,expected in m[kind].items():
            if digest(root/path)!=expected:mismatches.append(path)
    end=frames[r['result']['tick']]['snapshot'];corpses=[c for c in end['corpses'] if c['owner']=='p0'];permanent=[c for c in corpses if c['kind']!='spirit']
    # In this actual pair all p0 temporary combatants are summoned spirits.
    # Verify sampled spirit units carry expiresTick; corpses lack that field.
    spirit_checks=[u.get('expiresTick') is not None for f in frames.values() for u in f['snapshot']['units'] if u['owner']=='p0' and u['kind']=='spirit']
    timeline=[]
    for tick,frame in frames.items():
        s=frame['snapshot'];own=[u for u in s['units'] if u['owner']=='p0'];cs=[c for c in s.get('corpses',[]) if c['owner']=='p0']
        tracked=[{k:u.get(k) for k in ['id','kind','hp','maxHp','x','y','order','kills','xp','level']} for u in own if u['id'] in ['unit-p0-emberRavager-1079','unit-p0-emberRavager-1060','unit-p0-emberRavager-1322','unit-p0-contractArcher-1095','unit-p0-contractArcher-1115','unit-p0-priest-2001'] or u['kind']=='priest']
        timeline.append({'tick':tick,'permanentLosses':sum(c['kind']!='spirit' for c in cs),'temporaryCombatDeaths':sum(c['kind']=='spirit' for c in cs),'nativeUnitsLost':s['match']['stats']['unitsLost']['p0'],
            'neutralLosses':s['match']['stats']['unitsKilledByNeutral']['p0'],'permanentAlive':sum(u.get('expiresTick') is None for u in own),
            'guardAlive':sum(u['kind'] in ['emberRavager','ashWarden'] for u in own),'medicsAlive':sum(u['kind']=='priest' for u in own),'trackedUnits':tracked})
    evidence={'reportPath':str(p),'reportSHA256':digest(p),'result':r['result'],'setup':r['setup'],'sourceRoot':str(root),'commit':m['baseCommit'],
        'currentCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'gitStatus':subprocess.check_output(['git','status','--short'],cwd=root,text=True).strip(),
        'runtimeFilesRechecked':len(m['runtimeHashes']),'supportingFilesRechecked':len(m['supportingDataHashes']),'sourceMismatches':mismatches,
        'frozenRevision':m['frozenRevision'],'frozenManifestSHA256':m['frozenManifestSha256'],'permanentDeaths':len(permanent),'permanentDeathsByKind':dict(Counter(c['kind'] for c in permanent)),
        'temporaryCombatDeaths':sum(c['kind']=='spirit' for c in corpses),'nativeUnitsLost':end['match']['stats']['unitsLost']['p0'],
        'allCorpseCountsEqualNativeUnitsLost':len(corpses)==end['match']['stats']['unitsLost']['p0'],'sampledSpiritsAllHaveExpiresTick':all(spirit_checks),'sampledSpiritChecks':len(spirit_checks),
        'permanentCorpses':permanent,'terminalMatch':end['match'],'terminalEntities':{owner:{'units':sum(u['owner']==owner for u in end['units']),'buildings':sum(b['owner']==owner for b in end['buildings'])}for owner in ['p0','p1','p2']},'timeline':timeline}
    runs[label]={'report':r,'frames':frames,'evidence':evidence}
common=sorted(set(runs['v11']['frames']) & set(runs['base457']['frames']));prefix=[]
for tick in common:
    if runs['v11']['frames'][tick]!=runs['base457']['frames'][tick]:break
    prefix.append(tick)
fine={}
for label,name in [('v11','care-follow-divergence-v11-native7800'),('base457','care-follow-divergence-base457-native7800')]:
    p=source/(name+'.json');f=json.loads(p.read_text());fine[label]={'path':str(p),'sha256':digest(p),'classification':f['metadata']['classification'],'result':f['result'],'verification':f['verification'],
        'commandsAt8205':[entry for group in f['commands'] if group['tick']==8205 for entry in group['entries'] if entry['playerId']=='p0'],
        'healsNear8196':[e for e in f['heals'] if 8190<=e['tick']<=8205]}
result={'classification':'Independent read-only audit of two complete ordinary0 summoner games on one development seed. Focused native7800 continuations are separate causal diagnostics and are not credited as opening results.',
    'runs':{label:r['evidence']for label,r in runs.items()},'setupEqual':runs['v11']['report']['setup']==runs['base457']['report']['setup'],
    'equalSavedWorldNextIdPrefix':prefix,'firstDifferentSavedTick':common[len(prefix)],'focusedDiagnostics':fine,
    'assessment':'v11 locally saves ravager1079 (baseline corpse8665 versus candidate15841; +7176ticks) but the complete candidate loses at19086 with0p0units/0buildings, while baseline wins57109. Candidate permanent deaths53 plus16temporary combat deaths must not be compared as69permanent against baseline208; baseline has57permanent plus151temporary combat deaths over a much longer winning game. At common saved times candidate loses its guards, original medic and summoners around15824..16335; baseline retains a viable army and original medic until21754. The first differing follow at8205 is not by itself a proven unique cause of the eventual defeat.',
    'samplingLimit':'600tick frames show follow1079 at8400/9000 and full118HP with attackMove by9600 or10200; exact care duration and intermediate threats require the separate fine diagnostic, not interpolation from these frames.',
    'noNewSimulationOrSourceMutation':True,'originalContainerUncommittedGap':'Still unavailable and unrecovered.'}
(directory/'summoner-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'resultPath':str(directory/'summoner-comparison.json'),'results':{k:v['evidence']['result'] for k,v in runs.items()},'permanentDeaths':{k:v['evidence']['permanentDeaths']for k,v in runs.items()},'sourceMismatches':{k:v['evidence']['sourceMismatches']for k,v in runs.items()},'lastEqualSavedTick':prefix[-1]},indent=2))
