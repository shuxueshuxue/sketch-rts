import {writeFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
const wd=process.argv[2],imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const [{createGame},{createUnit},{shipProfile},{advanceShip,beginShipMotionFrame},{drainShipCollisionImpacts},{headingDifference},{SIM_TICKS_PER_SECOND}]=await Promise.all([imp('src/shared/sim.ts'),imp('src/shared/map.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/ship-motion.ts'),imp('src/shared/ship-collisions.ts'),imp('src/shared/ship-navigation.ts'),imp('src/shared/time.ts')]);
const map={...createGame('bareDuel').map,width:4096,height:4096,terrain:{cols:128,rows:128,cell:32,cells:'~'.repeat(128*128)}};
const cases=[];
for(const seedYaw of [.3])for(const pivotLever of [50,100,-100])for(const gap of [.05,.5,1,2,3,5,8,12]){
const a=createUnit('a','player','transport',1600,1600),b=createUnit('b','player','transport',1600,1600);a.sailing={heading:0,speed:0,load:0,balance:0,yawRate:seedYaw};b.sailing={heading:0,speed:0,load:0,balance:0};b.y+=2*Math.max(...shipProfile(a).hull.map((p:any)=>p.y))+gap;
const units=[a,b],rows=[];for(let i=0;i<45;i++){
const before=a.sailing.heading;beginShipMotionFrame(units,map);const accepted=advanceShip(a,map,units,{yaw:.015,pivotLever});const impacts=drainShipCollisionImpacts(units).map((im:any)=>({closingSpeed:im.closingSpeed,shipDamage:im.shipDamage,otherDamage:im.otherDamage}));
const afterNative=a.sailing.yawRate;a.sailing.yawRate=accepted ? headingDifference(before,a.sailing.heading)*SIM_TICKS_PER_SECOND : 0;
rows.push({tick:i+1,accepted,before,heading:a.sailing.heading,afterNative,afterBoundary:a.sailing.yawRate,impacts});
}cases.push({seedYaw,pivotLever,gap,rows});}
writeFileSync('/tmp/bootstrap-yaw-regression/native-boundary-pivot-contact-stop-preserved.json',JSON.stringify({wd,classification:'Synthetic native advanceShip + exact new end-boundary assignment; no AI/match score',cases},null,2));
console.log(JSON.stringify(cases.map(c=>({seedYaw:c.seedYaw,pivotLever:c.pivotLever,gap:c.gap,damaging:c.rows.filter(r=>r.impacts.length),partial:c.rows.filter(r=>!r.accepted&&r.heading!==r.before)})),null,2));
