import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const [wd,label]=process.argv.slice(2);
const imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const [{createGame,restoreSnapshotIntoGame,snapshotGame,issuePlayerCommand,stepGame},{currentBerthLandings},{shipProfile},{shipCollisionImpactCount}] = await Promise.all([imp('src/shared/sim.ts'),imp('src/shared/naval.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/ship-collisions.ts')]);
const fixture='/workspace/sketch-rts-bootstrap-resume/src/ai/bootstrap_1/fixtures/ferry-manual-static-92400.json.gz';
const saved=JSON.parse(gunzipSync(readFileSync(fixture)).toString());
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const boat=game.units.find((u:any)=>u.id==='unit-p0-carrier-3510');
const landings=currentBerthLandings(game.map,boat,{x:2192,y:6096},game.units);
for(const {passengerId} of landings)issuePlayerCommand(game,'p0',{type:'unloadPassenger',transportId:boat.id,passengerId});
const rows:any[]=[],frames:any[]=[];
const sample=()=>{
const passengers=landings.map(({passengerId}:any)=>game.units.find((u:any)=>u.id===passengerId));
return {tick:game.tick,passengers:passengers.map((u:any)=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),ships:game.units.filter((u:any)=>shipProfile(u)).map((u:any)=>({id:u.id,hp:u.hp,x:u.x,y:u.y,sailing:structuredClone(u.sailing),order:structuredClone(u.order)})),effects:structuredClone(game.effects),projectiles:structuredClone(game.projectiles),impacts:shipCollisionImpactCount(game.units)};
};
rows.push(sample());frames.push({snapshot:snapshotGame(game),nextId:game.nextId});
for(let i=0;i<45;i++){stepGame(game);rows.push(sample());frames.push({snapshot:snapshotGame(game),nextId:game.nextId});}
mkdirSync('/tmp/bootstrap-yaw-regression',{recursive:true});
writeFileSync('/tmp/bootstrap-yaw-regression/'+label+'.json',JSON.stringify({wd,label,fixture,landings,rows,frames}));
console.log(JSON.stringify({label,start:rows[0].passengers,end:rows.at(-1).passengers,damage:rows.filter((r,i)=>i&&JSON.stringify(r.passengers.map(p=>p.hp))!==JSON.stringify(rows[i-1].passengers.map(p=>p.hp))).map(r=>({tick:r.tick,passengers:r.passengers,effects:r.effects,impacts:r.impacts}))},null,2));
