import {readFileSync,writeFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
const wd='/workspace/sketch-rts-service-yaw-control',imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const [{createGame,restoreSnapshotIntoGame,snapshotGame,stepGame,issuePlayerCommand},{planAiOwnerCommandEntries},{shipNeedsRepair}]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/planner-context.ts'),imp('src/shared/ship-equipment.ts')]);
const r='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015/',saved=JSON.parse(readFileSync(r+'archer-portrait-ordinary.json.frames/39600.json','utf8')),row=JSON.parse(readFileSync(r+'archer-portrait-ordinary.json','utf8')).rows.find(r=>r.tick===39600),memory=structuredClone(row.players.p0.policy);
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const initial={tick:game.tick,gold:game.players.p0.gold,goldSpent:game.match.stats.goldSpent.p0},ledger=[],commands=[];
for(let i=0;i<150;i++){
 if(game.tick%15===0)for(const entry of planAiOwnerCommandEntries(snapshotGame(game),{playerId:'p0',version:'v9_archer',memory},{teams:game.teams})){commands.push({tick:game.tick,...entry});issuePlayerCommand(game,'p0',entry.command);}
 const before={gold:game.players.p0.gold,spent:game.match.stats.goldSpent.p0,workers:game.units.filter(u=>u.owner==='p0'&&u.kind==='worker').map(u=>({id:u.id,carryingGold:u.carryingGold,order:structuredClone(u.order)}))};
 stepGame(game);
 const debit=game.match.stats.goldSpent.p0-before.spent,credit=+(game.players.p0.gold-before.gold+debit).toFixed(8);
 if(debit||credit)ledger.push({tick:game.tick,goldBefore:before.gold,goldAfter:game.players.p0.gold,debit,credit,deliveries:before.workers.filter(u=>u.carryingGold>0&&u.order.type==='mine'&&u.order.phase==='return'&&game.units.find(v=>v.id===u.id)?.carryingGold===0),repair:game.units.filter(u=>u.owner==='p0'&&u.order.type==='repairShip').map(u=>({id:u.id,targetId:u.order.targetId})),bounties:game.effects.filter(e=>e.type==='goldBounty'&&e.owner==='p0')});
 const worker=game.units.find(u=>u.id==='unit-p0-worker-1833'),target=game.units.find(u=>u.id==='unit-p0-warship-1127');
 if(worker.deck?.shipId===target.id&&!shipNeedsRepair(game,target))break;
}
const result={classification:'P0 full-planner isolated ordinary39600 service replay; no opponent replanning, no full-match score',initial,final:{tick:game.tick,gold:game.players.p0.gold,goldSpent:game.match.stats.goldSpent.p0},commands,ledger,totalDebit:ledger.reduce((s,r)=>s+r.debit,0),totalCredit:ledger.reduce((s,r)=>s+r.credit,0)};
writeFileSync('/tmp/bootstrap-service-yaw-integration-audit/gold-ledger.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
