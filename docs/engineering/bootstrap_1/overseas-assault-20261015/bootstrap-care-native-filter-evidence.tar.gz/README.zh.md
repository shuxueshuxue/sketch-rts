# 原生到达/主动追路过滤候选：实际三边界与完整10200续局

候选 `ceedc2f13a0dd2986db3a26089855dd1866660f1` 在独立分支
`codex/bootstrap-care-native-intent-20261016`，基线为
`9119feec0dd4b4933d5f8940b80df98abba80259`。两棵固定源保持不变，
不改 root/main、规则2、冻结184、正常敌方资源人口或地图。

本轮结果：同一个真实完整10200世界、nextId、三方策略memory和setup，
基线自然26107由p1获胜，候选自然43714由p0获胜。它是已开发场景的换代码完整续局，
不是新普通0、未见种子泛化或bootstrap最终验收。10200起点跳过7905中1322已改变目标的早期效应。
原3bdb26107、原5f43714仍分别归原源；本轮两支均实际独立运行，不借旧结果。

## 最小实现与接口边界

`care-native-filter.patch` 只在9119上增加8文件/80行、删除15行。
其中3个为真实完整fixture；`sim.ts` 只有3处参数类型收窄，转译JS逐字节相同，
见 `native-type-only-proof.json`。共享原生primitive的runtime和规则没有改变。

替换原 `clearOfBuildingArrival` 对所有邻楼goal的一概拒绝：先用共享
`buildingMoveArrival` 判断当前静态地路是否会在本次15tick正常决策窗内提前结束；
只有还能经过一次idle acquisition和首次attack branch时，才按共享
`nativeAutomaticAttackIntent` 判断是否会主动 `pursue`。仅此动作拒绝候选。
原room、伤害、药师范围、排序、35% triage、脚本owner、memory、命令种类均保留。
`mountedEscape` 原本启用避战的入口使用此筛选，rendezvous的道路prefix与fallback
共用同一患者的懒建上下文，不复制评分核。

只有确有邻楼提前到达时才建立一次canonical原生query frame。仅患者的pose/order/CD被投影，
同一个posed对象进入units与ID map；敌方桶顺序和其他实体保持观测值。
这不是未来动态世界，不预测外力、敌方运动、伤害、help-call、autocast或下一帧宏观命令。
`engage`、无追路、被允许都不等于安全、已治疗或能够立刻开火。

## 三个真实完整输入及原生短窗

均先经正常restore注册native building overlay。`query-boundaries.json` 的只读重复查询
未改变world/nextId/三memory，完整pipeline和短窗还重新执行全部三方AI。

| 输入 | 实际区别与候选处理 | 原生短窗结果 |
| --- | --- | --- |
| 7905，Ember召唤线1079，自身52射程 | 原危险goal在7912先由native destination到达；7913获取86距离敌人、7914追路。候选仍拒绝该点。不能称circle body-contact，原归因勘误在上一primitive包。 | 目前生产基线与候选到7921都活18HP、无追路；另一患者1322目标也改变、仍活38HP。不能把旧源1079死亡算成候选新增救人。 |
| 10425，Grove弓手线footman1072，自身55 | 原goal在15tick内没有提前到达，不应因将来邻楼被拒。候选恢复原短步。 | 候选10425→10441每tick完整world/ID/三memory等于已封旧5f；两侧99HP，无提前到达。10440 general改令，10441在自身55内原地还击。 |
| 16245，同弓手线rider4294，自身330 | 原goal16246在主厅1639边提前结束；16247 help-call的初始远目标约690，随后native重新选约78.6的近目标，无主动追路。候选允许。 | 候选16245→16275保存31份每tick完整档，其中有旧5f原样本可比的17个checkpoint全部world/ID/三memory相等。候选49HP/医师距136.9，基线35HP/距370.9，两医师CD149均未治疗。候选仍挨伤，不能说点绝对安全。 |

见 `full-planner-boundaries.json`、`short-pair-summary.json` 及六组每tick完整gzip档。
10425短窗全体实际命中数候选3、基线2，并非所有单位均无额外伤害。
16245原生静态图和24000两支全图已亲自查看；所有图为native drawWorld，
fresh facing静态渲染，非重建历史动画。OWN射程圈不是敌方射程。

## 完整10200三方自然续局

`pair-input-provenance.json` 核输入world/ID/三memory/setup与原3bdb和5f的10200档逐值相等。
本轮 `full-tail.ts` 用真实SDK runGameLoop、原生sim及完整三方planner；无observer、
额外rank query或人工命令。没有人为tick截止；顺序运行至自然winner。

| 固定源 | 自然终局 | p0 native损失 | p0终局存活/厅/建筑 | p0实付金 | 敌方终局 |
| --- | --- | --- | --- | --- | --- |
| 9119 baseline | 26107，p1胜 | 71 | 0/0/0 | 13201 | p1 31兵19楼；p2 31兵22楼 |
| ceedc candidate | 43714，p0胜 | 56 | 41/4/29 | 19657 | p1、p2均0兵0楼 |

较早同tick状态也保留：24000基线7兵1厅、损失64，候选27兵3厅、损失38。
终局差异来自整场分叉，不将一发7伤或某个患者动作宣称为最终胜负唯一原因。
完整采样、所有三memory、命令、医师/老兵/经济代价由独立审查另外核对，不能只取胜利指标。

收益不是逐段单调：候选14400有10损失/32兵，基线21损失/23兵；但17400候选
已有28损失/21兵/1医师，基线27损失/29兵/3医师。候选后来获胜不能抹去这段真实代价。
候选仍损失于中立1名，基线4名；两支终局不同tick，不把终局总实付金当等时资源效率。
独立审查还核得所有已存完整sample：新基线28/28个等旧3bdb，新候选57/57个等旧5f，
包含world/ID/三memory/setup。这证明本例恢复既有良好轨迹，未证明超过旧5f；
600tick采样不能声称中间每tick完全相等。两支plans在第46行、实际命令在第167行首次不同，
均10425的1072短步方向，此前完整行均相等。
独审逐兵种的初始+训练+招募−活体−已付款队列−尸体收支余数均0，所有255个owner/sample
完整尸体数等native累计损失，故本例71/56确为永久死亡。候选仍丢掉最初4名老兵、
两名原医师1907/2255；1072在16257、4294在19016最终阵亡，不把短窗改善写成终局保存。

每600tick及终局保存完整snapshot/nextId/all3memory/setup；实际public commands与全部plans逐行保存。
双方source前后各核gitblob与SHA，基线1431文件、候选1436文件全等，
两侧冻结manifest SHA `0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774`。
候选完整源胶囊为 `fixed-source.tar.gz`；9119胶囊见已封primitive-v2独立包，未重复复制。

## 检查、限制与后续

7个相关测试文件65项通过，`tsc --noEmit`通过；见原log。
静态独审为commit之前相同文件草稿，head仍标9119，不冒充最终commit运行报告。
初次短窗esbuild模块解析失败的两个log保留；当时未启动game，后仅在外部证据目录补node_modules链接。

本轮没有修改目标门槛、开新0、跑矩阵或合入main。未见seed、官方地图、三路线所有单敌与六配对
的完整普通对局和泛化要求仍未完成。原故障容器未提交改动无法继承的恢复缺口仍保留。

`ordinary0-known-archer.ts` 是供root最终deck+cache+care组合定源后使用的真正普通0驱动，
**尚未执行**；只做TS语法转译检查。命令在该组合固定control工作目录执行：

```sh
node --import tsx /workspace/.playtest/bootstrap-care-native-filter-20261016/ordinary0-known-archer.ts ABS_COMBINED_SOURCE EXACT_FULL_COMMIT ABS_NEW_PREFIX
```

它从正常原factory创建全新game，强制预期HEAD、clean source、rules2/frozen184、
三方500金/3人口/8上限/3工/1厅，记录0factory全档、全部三memory、600和终局全档、
onCommand与plans、源码前后核；按自然终局运行，无observer或额外inspect查询。
此seed名字含unseen、factory参数unseen=true仅表示生成布局，已经开发过，不能记新泛化。
