import {createCanvas} from '@napi-rs/canvas';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const dir='/workspace/.playtest/bootstrap-care-native-filter-20261016';
const source='/workspace/sketch-rts-care-native-intent-control';
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
for(const tick of [19800,24000]) for(const mode of ['baseline','candidate']) {
 const input=`${dir}/full10200-${mode}.frames/${tick}.json.gz`;
 const {snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
 const width=1280,height=1320,zoom=1280/4608,view={x:0,y:0,width,height,zoom};
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');
 drawWorld({ctx:ctx as any,snapshot,view,now:tick*50,selectedIds:new Set(),facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String}});
 const us=snapshot.units.filter((u:any)=>u.owner==='p0');
 const halls=snapshot.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall');
 ctx.fillStyle='rgba(0,0,0,.93)';ctx.fillRect(0,height-62,width,62);ctx.fillStyle='white';ctx.font='21px sans-serif';
 ctx.fillText(`${mode}; actual full3AI tail tick ${tick}; p0 ${us.length} units / ${halls.length} halls`,14,height-35);
 ctx.fillText('Native drawWorld; static fresh facing; full-map view; no future or tactical overlays',14,height-10);
 const output=`${dir}/native-full-${mode}-${tick}.png`;
 writeFileSync(output,canvas.toBuffer('image/png'));
 writeFileSync(output+'.json',JSON.stringify({classification:'Native drawWorld of actual full3AI tail checkpoint; complete map; static fresh facing, no historical animation reconstruction.',source,input,view,tick,mode},null,2)+'\n');
 console.log(output);
}
