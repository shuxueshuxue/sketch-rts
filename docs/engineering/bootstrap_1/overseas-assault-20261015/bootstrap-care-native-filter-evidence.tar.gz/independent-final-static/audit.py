from pathlib import Path
import gzip, hashlib, json, subprocess

W=Path('/workspace/sketch-rts-care-native-intent-control')
D=Path('/workspace/.playtest/bootstrap-care-native-filter-20261016')
O=Path(__file__).parent
base='9119feec0dd4b4933d5f8940b80df98abba80259'
head='ceedc2f13a0dd2986db3a26089855dd1866660f1'
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def put(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==head
assert git('status','--porcelain','--untracked-files=all')==b''
paths=git('diff','--name-only',base,head).decode().splitlines()
assert len(paths)==8
verified=[]
for p in paths:
    actual=(W/p).read_bytes(); blob=git('show',head+':'+p)
    assert actual==blob
    verified.append({'path':p,'bytes':len(actual),'sha256':sha(actual),'liveExactlyHead':True})
old=git('show',base+':src/shared/sim.ts').decode()
new=(W/'src/shared/sim.ts').read_text()
normalized=new.replace('game: Pick<NativeQueryFrame, "map" | "buildings" | "buildingSpatial">', 'game: NativeQueryFrame')
normalized=normalized.replace('game: Pick<NativeQueryFrame, "buildings" | "buildingSpatial">', 'game: NativeQueryFrame')
assert normalized==old
queries=load(D/'query-boundaries.json')
assert [(j['name'],j['allows']) for j in queries]==[('7905',False),('10425',True),('16245',True)]
assert all(j['inputUnchanged'] and j['repeatEqual'] for j in queries)
fixtures=[]
for tick in [7905,10425,16245]:
    fpath=W/f'src/ai/bootstrap_1/fixtures/recovery-native-arrival-{tick}.json.gz'
    f=json.loads(gzip.decompress(fpath.read_bytes()))
    patient=next(u for u in f['snapshot']['units'] if u['id']==f['patientId'])
    fixtures.append({'tick':tick,'patientId':patient['id'],'kind':patient['kind'],
       'hp':patient['hp'],'ownAttackRange':patient['attackRange'],'cooldown':patient['cooldown'],
       'teams':f['snapshot'].get('teams'),'memoryOwners':list(f['memories']),
       'queryGoal':f['queryGoal'],'sha256':sha(fpath.read_bytes())})
tails=[]
for label in ['baseline','candidate']:
    p=D/f'full10200-{label}.json';j=load(p)
    tails.append({'file':str(p),'sha256':sha(p.read_bytes()),'sourceHead':j['head'],
      'inputTick':j['inputTick'],'classification':j['classification'],'result':j['result']})
assert tails[0]['sourceHead']==base and tails[1]['sourceHead']==head
assert tails[0]['result']=={'tick':26107,'winner':'p1','completed':True}
assert tails[1]['result']=={'tick':43714,'winner':'p0','completed':True}
full=load(D/'full-planner-boundaries.json')
assert full['rows'][0]['p0NonPatientEntriesEqual'] is False
report={
 'classification':'Independent static review of fixed final ceedc code and read-only existing actual evidence. No game, native query, planner query, tests, source edits or driver edits by reviewer.',
 'source':{'head':head,'base':base,'clean':True,'changedFiles':verified,'delta':'8 files,80 insertions,15 deletions; includes three complete fixture gzip files.'},
 'nativeTypeNarrowing':{'candidateSimAfterReversingOnlyThreeParameterTypesExactlyBase':True,
   'authorTranspiledProof':load(D/'native-type-only-proof.json'),
   'reviewLimit':'Reviewer verified textual type-only normalization; did not run transpiler or native sim. Author JS-byte proof was read, not rerun.'},
 'findings':[],
 'contractReview':[
  {'area':'Lazy construction and canonical map',
   'assessment':'Pass within current native snapshot contract.',
   'evidence':'No query frame until a building-overlapping goal has an estimated arrival early enough for both follow-up branches. buildingMoveArrival initially reads the supplied map overlay; restored/native planner snapshots already carry it. createNativeQueryFrame then independently builds canonical native team indexes/entity map/building overlay without writing original snapshot.'},
  {'area':'Projected identity',
   'assessment':'Pass.',
   'evidence':'Exactly one posed patient object replaces that ID in frame.units and frame.entityById; native intent receives that same object. Native targetPriorityScore resolves an enemy current victim through entityById, so victim===attacker preserves self-threat rather than degrading to ally-threat. Per-goal x/y/CD/order are reset from the unchanged patient/arrival, not accumulated from a previous query.'},
  {'area':'Spatial bucket reuse',
   'assessment':'Pass for this current idle/automatic-attack intent call path; not a claim that all projected-frame spatial queries are generally rebuilt.',
   'evidence':'Canonical enemy team buckets retain unchanged enemy objects and observed x-then-y/bucket order. The only moved object is friendly to itself, and forEachNearbyEnemyUnit excludes its own team index. Native attack-intent branch reads enemy buckets, units and entity lookup; canReach and naval crew resolution use the replaced units array. The stale own-team patient entry in canonical unitSpatial is not queried as an enemy on this call path.'},
  {'area':'Arrival and branch clocks',
   'assessment':'Pass for the declared static normal-movement estimate.',
   'evidence':'Native move branch advances and continues on arrival at movement tick m, so idle acquisition first runs m+1 and attack pursuit first runs m+2. The SDK next normal15tick planner comes after native tick15. Filtering only m+2<=15 therefore matches the intended interval. Native unit clocks decrement before branches; posed cooldown=max(0,original-m-1) for acquisition and original-m-2 for attack matches that order.'},
  {'area':'Own attack reach and native reconsideration',
   'assessment':'Pass.',
   'evidence':'The filter asks nativeAutomaticAttackIntent for idle acquisition, then an actual automatic attack/leash order. The native branch applies current reach, target replacement, cooldown-dependent reconsideration, dead zone and targetGap versus patient own attackRange. An in-range horseArcher330 engage is not rejected as pursue; no foe range is substituted for its own attack range.'},
  {'area':'Existing recovery scoring and ownership',
   'assessment':'Preserved outside the intended goal-acceptance change.',
   'evidence':'land-recovery hunks only replace clearOfBuildingArrival with one per-patient arrival callback shared by road prefix and mountedEscape fallback. mounted-micro retains room/damage/body/exit/destination scoring and comparator; avoidCombat=false retains no new arrival query. Same stay-here bypass remains. No assignments,35% triage,claims,memory,new owner,command kind or script priority changes appear in the diff.'}
 ],
 'fixtures':fixtures,
 'existingReadOnlyQueryEvidence':queries,
 'evidenceAttribution':{'fullTails':tails,
   'actual7905NonPatientChange':{'patient1079SameCommand':True,'allThreeMemoriesEqual':True,
      'p1EntriesEqual':True,'p2EntriesEqual':True,'p0NonPatientEntriesEqual':False,
      'meaning':'Another patient1322 also changes goal. Current baseline and candidate1079 both survive7921 with18HP; do not claim newly saved1079 versus the historical183 death.'},
   'full10200Limit':'These two actual independent natural tails start from the same complete10200 save and skip7905 early changes. 26107p1WIN versus43714p0WIN is a developed changed-code continuation pair, not a new ordinary0 or unseen/generalization result; whole-game divergence is not isolated to one patient or one7damage event.',
   'readmeScope':'README explicitly preserves these attribution limits, enemies0units/0buildings at candidate terminal, and complete three-route/official+unseen final requirements remain unmet.'},
 'nonBlockingLimits':[
  'This is a filter for estimated early arrival followed by native active pursue. None/acquire/engage/backOut/return/unsupported or allowed does not mean safe, healed, currently firing or guaranteed to survive.',
  'Only patient pose/order/CD are projected. Other bodies, enemy buckets, current projectiles/HP/effects and target orders remain observed; no future movement, pending damage resolution, help calls, autocasts, queued macro decisions, push/separation or future status changes are predicted.',
  'The static buildingMoveArrival estimate omits crowd/hull interference and requires native/restored building overlay. It should not be described as proof of actual future arrival or complete future target behavior.',
  'The same-code/native short-pair and natural-tail evidence is author execution. This reviewer inspected stored results/provenance and fixed source; no duplicate long tests or games were run.'
 ],
 'conclusion':'No concrete production blocker found in final ceedc relative to9119 within the requested native contract and ownership scope. Ordinary0 integration and broader three-route/full-match acceptance remain separate work.'}
put('FINAL-CEEDC-STATIC-REVIEW.json',report)
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in O.iterdir() if p.is_file() and p.name!='INDEX.json'}
put('INDEX.json',{'classification':'Independent static/narrow evidence review, not gameplay execution.','files':files})
print(json.dumps({'review':str(O/'FINAL-CEEDC-STATIC-REVIEW.json'),'sha256':sha((O/'FINAL-CEEDC-STATIC-REVIEW.json').read_bytes()),'indexSHA256':sha((O/'INDEX.json').read_bytes())},indent=2))
