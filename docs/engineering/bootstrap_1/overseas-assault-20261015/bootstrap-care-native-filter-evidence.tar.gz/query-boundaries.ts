import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{isDeepStrictEqual}from'node:util';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/sketch-rts-care-native-intent-control/src/shared/sim.ts';
import{recoveryArrivalFilter}from'/workspace/sketch-rts-care-native-intent-control/src/ai/bootstrap_1/recovery-arrival.ts';
const p='/workspace/.playtest/bootstrap-care-native-filter-20261016',old='/workspace/.playtest/bootstrap-care-native-intent-20261016';
const specs=[['7905','unit-p0-emberRavager-1079',false],['10425','unit-p0-footman-1072',true],['16245','unit-p0-horseArcher-4294',true]] as const;
const rows=[];
for(const[name,id,expected]of specs){const f=JSON.parse(gunzipSync(readFileSync(`${old}/native-intent-${name}.frames/${name}.json.gz`)).toString()),t=JSON.parse(readFileSync(`${old}/native-intent-${name}.json`,'utf8'));
const g=createGame('bareDuel',{aiPlayers:[]});restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const snap=snapshotGame(g),patient=snap.units.find(u=>u.id===id)!;
const goal=t.commands.find((c:any)=>c.tick===Number(name)&&c.owner==='p0').entries.find((e:any)=>e.command.type==='move'&&e.command.unitIds.includes(id)).command;
const before=JSON.stringify({world:snapshotGame(g),nextId:g.nextId,memories:f.memories});const query=recoveryArrivalFilter(snap,patient,15);const allows=query(goal),second=query(goal);const after=JSON.stringify({world:snapshotGame(g),nextId:g.nextId,memories:f.memories});
rows.push({name,id,goal,allows,expected,repeatEqual:allows===second,inputUnchanged:before===after});}
writeFileSync(p+'/query-boundaries.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows));if(rows.some(r=>r.allows!==r.expected||!r.repeatEqual||!r.inputUnchanged))throw Error('Boundary predicate failed');
