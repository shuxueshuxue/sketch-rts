from pathlib import Path
import hashlib, io, json, tarfile

root = Path('/workspace/.playtest/bootstrap-care-native-filter-20261016')
archive = root / 'bootstrap-care-native-filter-evidence.tar.gz'
index = root / 'evidence-index.json'
seal = root / 'evidence-seal.json'
if archive.exists() or index.exists() or seal.exists():
    raise SystemExit('Preserve existing sealed evidence; use a new incremental package')
files = sorted(p for p in root.rglob('*') if p.is_file() and not p.is_symlink()
               and 'node_modules' not in p.relative_to(root).parts)
rows = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size,
         'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
index.write_text(json.dumps({'classification': 'Closed care native-filter evidence; no ordinary0 or final bootstrap acceptance',
                            'payloadFiles': len(rows), 'files': rows}, ensure_ascii=False, indent=2) + '\n')
with tarfile.open(archive, 'w:gz') as tar:
    for p in files + [index]:
        data = p.read_bytes()
        info = tarfile.TarInfo(str(p.relative_to(root)))
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    names = tar.getnames()
    assert set(names) == {r['path'] for r in rows} | {'evidence-index.json'}
    for row in rows:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert json.loads(tar.extractfile('evidence-index.json').read())['files'] == rows
result = {'archive': str(archive), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'payloadFiles': len(rows), 'archiveMembersIncludingIndex': len(rows) + 1,
          'allArchivePayloadHashesVerified': True,
          'indexSHA256': hashlib.sha256(index.read_bytes()).hexdigest()}
seal.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
