import {readFileSync,writeFileSync}from'node:fs';import{gunzipSync,gzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import{isDeepStrictEqual}from'node:util';
const out='/workspace/.playtest/bootstrap-care-native-filter-20261016',old='/workspace/.playtest/bootstrap-care-native-intent-20261016';
const roots={baseline:'/workspace/sketch-rts-native-primitives-v2-control',candidate:'/workspace/sketch-rts-care-native-intent-control'};
const specs=[['7905','unit-p0-emberRavager-1079'],['10425','unit-p0-footman-1072'],['16245','unit-p0-horseArcher-4294']] as const;
const copy=(v:any)=>JSON.parse(JSON.stringify(v));const results:any={};
for(const[label,root]of Object.entries(roots)){
 const load=(p:string)=>import(pathToFileURL(root+'/'+p).href);
 const sim=await load('src/shared/sim.ts'),{createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{createBootstrapCommandPlanner,frozenPolicyManifest}=await load('scripts/bootstrap_1-planner.ts');
 results[label]={frozenPolicyManifest,cases:{}};
 for(const[name,patientId]of specs){
  const saved=JSON.parse(gunzipSync(readFileSync(`${old}/native-intent-${name}.frames/${name}.json.gz`)).toString());
  const game=sim.createGame('bareDuel',{aiPlayers:[]});sim.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
  const memory=createAiMemoryProvider(copy(saved.memories)),planner=await createBootstrapCommandPlanner(memory),snapshot=sim.snapshotGame(game),before=copy({snapshot:sim.snapshotGame(game),nextId:game.nextId});
  const entries=[],owners=Object.keys(saved.setup.agents);
  for(const owner of owners)entries.push(...planner({snapshot,owner,agent:saved.setup.agents[owner],source:'external-agent',teams:game.teams}));
  const after=copy({snapshot:sim.snapshotGame(game),nextId:game.nextId}),memories=Object.fromEntries(owners.map(owner=>[owner,memory.get(owner)]));
  results[label].cases[name]={saved,patientId,entries,memories,inputWorldIdUnchanged:isDeepStrictEqual(before,after)};
  writeFileSync(`${out}/fullplanner-${name}-${label}.json.gz`,gzipSync(JSON.stringify(results[label].cases[name])+'\n'));
 }
}
const rows=specs.map(([name,id])=>{const a=results.baseline.cases[name],b=results.candidate.cases[name];return{name,patientId:id,inputWorldIdUnchanged:a.inputWorldIdUnchanged&&b.inputWorldIdUnchanged,
 baselinePatient:a.entries.filter((e:any)=>e.command.unitIds?.includes(id)),candidatePatient:b.entries.filter((e:any)=>e.command.unitIds?.includes(id)),
 allMemoriesEqual:isDeepStrictEqual(a.memories,b.memories),p1EntriesEqual:isDeepStrictEqual(a.entries.filter((e:any)=>e.playerId==='p1'),b.entries.filter((e:any)=>e.playerId==='p1')),
 p2EntriesEqual:isDeepStrictEqual(a.entries.filter((e:any)=>e.playerId==='p2'),b.entries.filter((e:any)=>e.playerId==='p2')),
 p0NonPatientEntriesEqual:isDeepStrictEqual(a.entries.filter((e:any)=>e.playerId==='p0'&&!e.command.unitIds?.includes(id)),b.entries.filter((e:any)=>e.playerId==='p0'&&!e.command.unitIds?.includes(id)))};});
writeFileSync(out+'/full-planner-boundaries.json',JSON.stringify({classification:'Complete current candidate/base bootstrap planner on3 actual restored full-world/id/all3mem inputs; native map registration first; all3 frozen normal opponents planned, no game advancement or ordinary0.',roots,rows},null,2)+'\n');console.log(JSON.stringify(rows));
if(rows.some(r=>!r.inputWorldIdUnchanged||!r.p1EntriesEqual||!r.p2EntriesEqual))throw Error('Full planner boundary ownership/input check failed');
