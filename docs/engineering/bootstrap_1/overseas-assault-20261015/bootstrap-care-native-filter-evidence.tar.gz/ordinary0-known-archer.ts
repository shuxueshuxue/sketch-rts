import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { dirname } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

// Prepared for the parent's final combined fixed-source ordinary0. NOT executed by land_army.
const [root, expectedHead, prefix] = process.argv.slice(2);
if (!root || !expectedHead || !prefix || !root.startsWith('/') || !prefix.startsWith('/'))
  throw Error('Usage: ordinary0-known-archer.ts ABS_SOURCE EXPECTED_FIXED_HEAD ABS_NEW_PREFIX');
const mode = 'ordinary0-known-developed-archer';
if (existsSync(prefix + '.json') || existsSync(prefix + '-runtime-source.json'))
  throw Error('Preserve existing report; choose a new explicit prefix');
mkdirSync(dirname(prefix), {recursive:true});
const setup = {
  map:'pineshade',seed:'bootstrap_1-unseen-archer-v8-v8-20261015-01',unseen:true,side:1,
  agents:{p0:{version:'v9_archer',versionLabel:'v9_archer',race:'grove',controller:'external-agent',team:'a'},
    p1:{version:'v8',versionLabel:'v8',race:'ember',controller:'external-agent',team:'b'},
    p2:{version:'v8',versionLabel:'v8',race:'grove',controller:'external-agent',team:'b'}},
  thinkInterval:15,rulesVersion:2,frozenRevision:'d1ae110f2edd99f9c7d899ed61557891ab587639',
};
const copy = (v:any) => JSON.parse(JSON.stringify(v));
const sha = (v:any) => createHash('sha256').update(v).digest('hex');
const load = (p:string) => import(pathToFileURL(root+'/'+p).href);
function audit() {
  const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
  if(head!==expectedHead)throw Error('Unexpected source head');
  const paths=['src','scripts','tools/resource-manifest.ts','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json'];
  const files=execFileSync('git',['ls-tree','-r','-z',head,'--',...paths],{cwd:root}).toString().split('\0').filter(Boolean).map(line=>{
    const [meta,path]=line.split('\t'),[gitmode,kind,blob]=meta!.split(' '),bytes=readFileSync(root+'/'+path);
    const actual=createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
    return {path,expectedGitBlob:blob,actualGitBlob:actual,sha256:sha(bytes),bytes:bytes.length,matches:actual===blob};
  });
  const gitStatus=execFileSync('git',['status','--short'],{cwd:root,encoding:'utf8'});
  if(gitStatus||files.some(f=>!f.matches))throw Error('Source differs from fixed commit');
  return {root,head,gitStatus,files,frozenManifestSHA256:sha(readFileSync(root+'/docs/engineering/bootstrap_1/frozen-policy.json'))};
}
const pre=audit();
if(pre.frozenManifestSHA256!=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774')throw Error('Changed rules2 frozen manifest');
writeFileSync(prefix+'-runtime-source.json',JSON.stringify(pre,null,2)+'\n');
const sim=await load('src/shared/sim.ts'),{bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiPolicyMemory}=await load('src/ai/policy.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts'),{UNIT_DEFS,ABILITY_DEFS}=await load('src/shared/catalog.ts');
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject===setup.agents.p0.version&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
if(!match||!isDeepStrictEqual(copy(match.agents),setup.agents))throw Error('Approved factory setup no longer resolves');
const game=bootstrapGame(match),owners=Object.keys(match.agents);
if(game.tick!==0||game.map.id!=='ladder'||game.map.width!==4608||game.map.height!==4608)throw Error('Unexpected true0 generated map');
for(const owner of owners){
 const p=game.players[owner],units=game.units.filter((u:any)=>u.owner===owner),halls=game.buildings.filter((b:any)=>b.owner===owner&&b.kind==='townHall');
 if(p.gold!==500||p.supplyUsed!==3||p.supplyCap!==8||units.length!==3||units.some((u:any)=>u.kind!=='worker')||halls.length!==1)throw Error('Changed normal resources/population/start for '+owner);
}
const memories=createAiMemoryProvider(Object.fromEntries(owners.map(owner=>[owner,createAiPolicyMemory()]))),planner=await createBootstrapCommandPlanner(memories);
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)])),setup});
writeFileSync(prefix+'-factory0.json.gz',gzipSync(JSON.stringify({classification:'True ordinary0 approved generated factory; no restored game, artificial commands or weakened opponents. Developed seed, not new unseen validation.',...frame()})+'\n'));
const frozenRoot=frozenPolicyRoot();
const frozen=Object.entries(frozenPolicyManifest.files).map(([path,expected])=>({path,expected,actual:sha(readFileSync(frozenRoot+'/'+path))}));
if(frozen.length!==184||frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision||frozen.some(f=>f.expected!==f.actual))throw Error('Frozen184 rules2 source mismatch');
writeFileSync(prefix+'-frozen-source.json',JSON.stringify({revision:frozenPolicyManifest.revision,rulesVersion:frozenPolicyManifest.rulesVersion,files:frozen},null,2)+'\n');
mkdirSync(prefix+'.frames',{recursive:true});writeFileSync(prefix+'-commands.jsonl','');writeFileSync(prefix+'-plans.jsonl','');
const rows:any[]=[],started=performance.now(),cpuStart=process.cpuUsage();let savedTick=-1;
function save(completed:boolean){
 const f=frame();const temporary=prefix+'.frames/'+game.tick+'.json.gz.tmp';writeFileSync(temporary,gzipSync(JSON.stringify(f)+'\n'));renameSync(temporary,prefix+'.frames/'+game.tick+'.json.gz');savedTick=game.tick;
 const row={tick:game.tick,players:Object.fromEntries(owners.map(owner=>{const units=f.snapshot.units.filter((u:any)=>u.owner===owner),buildings=f.snapshot.buildings.filter((b:any)=>b.owner===owner);return[owner,{policy:f.memories[owner],gold:game.players[owner].gold,supply:game.players[owner].supplyUsed,cap:game.players[owner].supplyCap,
  upgrades:game.players[owner].upgrades,units:units.length,permanentUnits:units.filter((u:any)=>u.expiresTick===undefined).length,workers:units.filter((u:any)=>u.kind==='worker').length,
  healers:units.filter((u:any)=>UNIT_DEFS[u.kind].abilities.some((a:any)=>ABILITY_DEFS[a].behavior==='heal')).map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,cooldowns:u.abilityCooldowns})),
  bases:buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,x:b.x,y:b.y,hp:b.hp,complete:b.complete})),buildings:buildings.length,unitsLost:game.match.stats.unitsLost[owner],goldSpent:game.match.stats.goldSpent[owner]}];}))};
 rows.push(copy(row));
 const cpu=process.cpuUsage(cpuStart);const report={classification:'True ordinary0 full3AI natural game on approved original factory and developed archer-v8+v8 seed. No restored input, artificial orders, rank queries or observer. Normal frozen184 resources/population and rules2 preserved. Not fresh unseen validation.',mode,source:root,head:pre.head,inputTick:0,setup,result:{tick:game.tick,winner:game.match.winner,completed},elapsedMs:performance.now()-started,cpuMs:(cpu.user+cpu.system)/1000,rows};
 writeFileSync(prefix+'.json.tmp',JSON.stringify(report)+'\n');renameSync(prefix+'.json.tmp',prefix+'.json');
 console.log(JSON.stringify({mode,tick:game.tick,winner:game.match.winner,p0:{gold:row.players.p0.gold,supply:row.players.p0.supply,bases:row.players.p0.bases.length,units:row.players.p0.units,unitsLost:row.players.p0.unitsLost},rss:process.memoryUsage().rss,elapsedMs:report.elapsedMs}));
}
save(false);
const result=runGameLoop({...match,game,commandPlanner:(context:any)=>{const entries=planner(context);appendFileSync(prefix+'-plans.jsonl',JSON.stringify({tick:game.tick,owner:context.owner,entries})+'\n');return entries;}},{
 onCommand:(event:any)=>appendFileSync(prefix+'-commands.jsonl',JSON.stringify({tick:game.tick,owner:event.owner,source:event.source,scriptId:event.scriptId,command:event.command})+'\n'),
 onStep:()=>{if(game.tick%600===0||game.match.winner)save(!!game.match.winner);},
});
if(savedTick!==game.tick)save(!!game.match.winner);
if(!game.match.winner)throw Error('Natural terminal result missing');
const post=audit(),sourceEqual=pre.head===post.head&&isDeepStrictEqual(pre.files,post.files);writeFileSync(prefix+'-postflight.json',JSON.stringify({...post,sourceEqual},null,2)+'\n');
if(!sourceEqual)throw Error('Source changed during full tail');
console.log(JSON.stringify({mode,naturalWinner:game.match.winner,tick:game.tick,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,sourceEqual}));
