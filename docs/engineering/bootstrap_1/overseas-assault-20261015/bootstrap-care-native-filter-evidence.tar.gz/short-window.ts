import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {resolve,dirname,extname} from 'node:path';import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';import {gzipSync} from 'node:zlib';import {isDeepStrictEqual} from 'node:util';
import {build} from 'esbuild';
const name=process.argv[2],mode=process.argv[3],out='/workspace/.playtest/bootstrap-care-native-filter-20261016';
const roots:any={baseline:'/workspace/sketch-rts-native-primitives-v2-control',candidate:'/workspace/sketch-rts-care-native-intent-control'};if(!roots[mode])throw Error('Specify baseline or candidate');
const old='/tmp/bootstrap-land-army-evidence-20261015';
const cases:any={
 '7905':{source:'/workspace/sketch-rts-land-army-base183-control',frames:old+'/native-care-queued-hold-7905-baseline.frames',patient:'unit-p0-emberRavager-1079',healer:'unit-p0-priest-2001',start:7905,end:7921},
 '10425':{source:'/tmp/sketch-rts-mercenary-courier-safe-stop-control',frames:old+'/production-base5f-archer-boundary10425.frames',patient:'unit-p0-footman-1072',healer:'unit-p0-fieldMedic-2255',start:10425,end:10441},
 '16245':{source:'/tmp/sketch-rts-mercenary-courier-safe-stop-control',frames:old+'/production-base5f-secondboundary16245.frames',fallback:old+'/production-base5f-archer-fine-16200-16800.frames',patient:'unit-p0-horseArcher-4294',healer:'unit-p0-fieldMedic-1907',start:16245,end:16275},
};
const spec=cases[name];if(!spec)throw Error('Specify7905,10425,16245');const source=roots[mode];
const copy=(v:any)=>v===undefined?undefined:JSON.parse(JSON.stringify(v)),sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const input=spec.frames+'/'+spec.start+'.json',saved=JSON.parse(readFileSync(input,'utf8'));
const simPath=source+'/src/shared/sim.ts',simBytes=readFileSync(simPath,'utf8');
const names=['moveToward','nearestEnemyTarget','takeUpAttacker','walkEnded','arrive','updateAttackOrder','backOutOfDeadZone'];
let instrumented=simBytes;
for(const name of names){const text='function '+name+'(';if(instrumented.split(text).length!==2)throw Error('Ambiguous native hook '+name);instrumented=instrumented.replace(text,'function __observed_'+name+'(');}
instrumented+=`
function __traceNative(event:any) { (globalThis as any).__bootstrapNativeIntentTrace?.(event); }
function __beforeNative(unit:any) {return {x:unit.x,y:unit.y,hp:unit.hp,order:{...unit.order},range:unit.attackRange,cooldown:unit.cooldown,pushX:unit.pushX,pushY:unit.pushY};}
function moveToward(unit:any,x:any,y:any,map:any,units:any=[],navalFrame=true) {
 const before=__beforeNative(unit);__observed_moveToward(unit,x,y,map,units,navalFrame);
 __traceNative({event:'moveToward',unit,before,goal:{x,y},navalFrame,stack:new Error().stack});
}
function nearestEnemyTarget(game:any,unit:any,range:any,navalFrame=true) {
 const result=__observed_nearestEnemyTarget(game,unit,range,navalFrame);
 __traceNative({event:'nearestEnemyTarget',unit,range,result,gap:result&&targetGap(unit,result,navalFrame),stack:new Error().stack});return result;
}
function takeUpAttacker(game:any,unit:any,attacker:any,victim:any) {
 const before=__beforeNative(unit);__observed_takeUpAttacker(game,unit,attacker,victim);
 __traceNative({event:'takeUpAttacker',unit,before,attacker,victim,gap:targetGap(unit,attacker),stack:new Error().stack});
}
function walkEnded(game:any,unit:any,goal:any,within:any) {
 const result=__observed_walkEnded(game,unit,goal,within);__traceNative({event:'walkEnded',unit,goal,within,result});return result;
}
function arrive(unit:any,goal:any) {const before=__beforeNative(unit);__observed_arrive(unit,goal);__traceNative({event:'arrive',unit,before,goal});}
function updateAttackOrder(game:any,unit:any,navalFrame=true) {
 const before=__beforeNative(unit),target=unit.order.type==='attack'&&findStrikeTarget(game,unit.order.targetId),gap=target&&targetGap(unit,target,navalFrame);
 __observed_updateAttackOrder(game,unit,navalFrame);__traceNative({event:'updateAttackOrder',unit,before,target,gap,navalFrame});
}
function backOutOfDeadZone(game:any,unit:any,target:any,navalFrame=true) {
 const before=__beforeNative(unit),result=__observed_backOutOfDeadZone(game,unit,target,navalFrame);
 __traceNative({event:'backOutOfDeadZone',unit,before,target,result});return result;
}
`;
const bundled=new Set(['src/shared/sim.ts','src/sdk/game-runner.ts','src/sdk/commands/frame.ts','src/shared/sim/command-frame-runtime.ts','src/shared/sim/frame.ts'].map(p=>source+'/'+p));
const module=out+'/short-'+name+'-'+mode+'.mjs';
await build({stdin:{contents:"export {runGameLoop} from './src/sdk/game-runner.ts';export {restoreSnapshotIntoGame,snapshotGame} from './src/shared/sim.ts';",resolveDir:source,loader:'ts'},
 bundle:true,platform:'node',format:'esm',outfile:module,packages:'external',plugins:[{name:'passive-native-intent',setup(api){
  api.onResolve({filter:/^\./},args=>{let path=resolve(args.resolveDir,args.path);if(!extname(path))path+='.ts';return bundled.has(path)?{path}:{path,external:true};});
  api.onLoad({filter:/\/src\/shared\/sim\.ts$/},args=>({contents:instrumented,loader:'ts',resolveDir:dirname(args.path)}));
 }}]});
const {runGameLoop,restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(module).href);
const {bootstrapMatches,bootstrapGame}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner}=await load('scripts/bootstrap_1-planner.ts');
const setup=saved.setup,match=bootstrapMatches(setup.seed,[setup.map],spec.end,setup.unseen).find((m:any)=>m.subject===setup.agents.p0.version&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memory=createAiMemoryProvider(copy(saved.memories)),planner=await createBootstrapCommandPlanner(memory),owners=Object.keys(match.agents);
const frame=()=>copy({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memory.get(o)])),setup});
if(!isDeepStrictEqual(frame(),saved))throw Error('Complete input restore differs');
const traces:any[]=[],commands:any[]=[],hits:any[]=[],checks:any[]=[],patientStates:any[]=[];
(globalThis as any).__bootstrapNativeIntentTrace=(event:any)=>{if(event.unit?.id===spec.patient || name==='7905'&&event.unit?.id==='unit-p0-emberRavager-1322')traces.push({tick:game.tick,...copy(event)});};
game.observer={hit(a:any,t:any,d:number,h:number){hits.push({tick:game.tick,attacker:copy(a),target:copy(t),taken:d,hpBefore:h});}};
const frames=out+'/short-'+name+'-'+mode+'.frames';mkdirSync(frames,{recursive:true});
const save=()=>{const f=frame();writeFileSync(frames+'/'+game.tick+'.json.gz',gzipSync(JSON.stringify(f)+'\n'));
 const patient=f.snapshot.units.find((u:any)=>u.id===spec.patient),healer=f.snapshot.units.find((u:any)=>u.id===spec.healer);
 patientStates.push({tick:game.tick,patient,healer,gap:patient&&healer&&Math.hypot(patient.x-healer.x,patient.y-healer.y)});
 const path=spec.frames+'/'+game.tick+'.json',fallback=spec.fallback+'/'+game.tick+'.json';
 const expected=existsSync(path)?JSON.parse(readFileSync(path,'utf8')):spec.fallback&&existsSync(fallback)?JSON.parse(readFileSync(fallback,'utf8')):undefined;
 if(expected)checks.push({tick:game.tick,world:isDeepStrictEqual(f.snapshot,expected.snapshot),nextId:f.nextId===expected.nextId,
  memories:Object.fromEntries(owners.map(owner=>[owner,isDeepStrictEqual(f.memories[owner],expected.memories[owner])]))});
};save();
runGameLoop({...match,game,commandPlanner:(c:any)=>{const entries=planner(c);commands.push({tick:game.tick,owner:c.owner,entries:copy(entries)});return entries;}},{onStep:save});
delete(globalThis as any).__bootstrapNativeIntentTrace;
const verification={allCheckpointsExact:checks.every(c=>c.world&&c.nextId&&Object.values(c.memories).every(Boolean)),count:checks.length,
 sourceSimSHA256:sha(simBytes),sourceSimUnchanged:sha(readFileSync(simPath))===sha(simBytes),derivedInstrumentedModuleSHA256:sha(readFileSync(module))};
const result={classification:'Actual full3AI short window on restored complete old input under fixed current baseline/candidate. Native passive wrappers observe actual calls; all3 policy memories are recomputed and saved each tick. Old-source checkpoint differences are reported, not silently treated as reproduction. No input-world edits, no ordinary0.',
 source,input,patientId:spec.patient,start:spec.start,end:game.tick,verification,checks,traces,commands,hits,patientStates};
writeFileSync(out+'/short-'+name+'-'+mode+'.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({name,verification,firstMoves:traces.filter(t=>t.event==='moveToward').map(t=>({tick:t.tick,order:t.before.order,goal:t.goal})),arrivals:traces.filter(t=>t.event==='arrive').map(t=>t.tick)}));
if(!verification.sourceSimUnchanged)throw Error('Fixed source changed');
