import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

const out = '/workspace/.playtest/bootstrap-care-native-filter-20261016';
const roots: Record<string,string> = { baseline:'/workspace/sketch-rts-native-primitives-v2-control', candidate:'/workspace/sketch-rts-care-native-intent-control' };
const mode = process.argv[2], root = roots[mode]; if (!root) throw Error('Specify baseline or candidate');
const prefix = out + '/full10200-' + mode;
if (existsSync(prefix + '.json')) throw Error('Preserve existing full-tail output; choose a new explicit prefix for another execution');
const input = JSON.parse(gunzipSync(readFileSync(out+'/pair-input10200-complete.json.gz')).toString());
const copy = (v:any) => JSON.parse(JSON.stringify(v));
const sha = (v:any) => createHash('sha256').update(v).digest('hex');
const load = (p:string) => import(pathToFileURL(root+'/'+p).href);
function audit() {
  const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
  const paths=['src','scripts','tools/resource-manifest.ts','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json'];
  const files=execFileSync('git',['ls-tree','-r','-z',head,'--',...paths],{cwd:root}).toString().split('\0').filter(Boolean).map(line=>{
    const [meta,path]=line.split('\t'),[gitmode,kind,blob]=meta!.split(' '),bytes=readFileSync(root+'/'+path);
    const actual=createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
    return {path,expectedGitBlob:blob,actualGitBlob:actual,sha256:sha(bytes),bytes:bytes.length,matches:actual===blob};
  });
  const gitStatus=execFileSync('git',['status','--short'],{cwd:root,encoding:'utf8'});
  if(gitStatus||files.some(f=>!f.matches))throw Error('Source differs from fixed commit');
  return {root,head,gitStatus,files,frozenManifestSHA256:sha(readFileSync(root+'/docs/engineering/bootstrap_1/frozen-policy.json'))};
}
const pre=audit();writeFileSync(prefix+'-runtime-source.json',JSON.stringify(pre,null,2)+'\n');
const sim=await load('src/shared/sim.ts'),{bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts'),{UNIT_DEFS,ABILITY_DEFS}=await load('src/shared/catalog.ts');
const setup=input.setup,match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject===setup.agents.p0.version&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
if(!match)throw Error('Original setup no longer resolves');
const game=bootstrapGame(match);sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
const memories=createAiMemoryProvider(copy(input.memories)),planner=await createBootstrapCommandPlanner(memories),owners=Object.keys(match.agents);
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)])),setup});
if(!isDeepStrictEqual(frame(),input))throw Error('Complete10200 input restore failed');
const frozenRoot=frozenPolicyRoot();
const frozen=Object.entries(frozenPolicyManifest.files).map(([path,expected])=>({path,expected,actual:sha(readFileSync(frozenRoot+'/'+path))}));
if(frozen.some(f=>f.expected!==f.actual))throw Error('Frozen source mismatch');
writeFileSync(prefix+'-frozen-source.json',JSON.stringify({revision:frozenPolicyManifest.revision,rulesVersion:frozenPolicyManifest.rulesVersion,files:frozen},null,2)+'\n');
mkdirSync(prefix+'.frames',{recursive:true});writeFileSync(prefix+'-commands.jsonl','');writeFileSync(prefix+'-plans.jsonl','');
const rows:any[]=[],started=performance.now(),cpuStart=process.cpuUsage();let savedTick=-1;
function save(completed:boolean){
 const f=frame();const temporary=prefix+'.frames/'+game.tick+'.json.gz.tmp';writeFileSync(temporary,gzipSync(JSON.stringify(f)+'\n'));renameSync(temporary,prefix+'.frames/'+game.tick+'.json.gz');savedTick=game.tick;
 const row={tick:game.tick,players:Object.fromEntries(owners.map(owner=>{const units=f.snapshot.units.filter((u:any)=>u.owner===owner),buildings=f.snapshot.buildings.filter((b:any)=>b.owner===owner);return[owner,{policy:f.memories[owner],gold:game.players[owner].gold,supply:game.players[owner].supplyUsed,cap:game.players[owner].supplyCap,
  upgrades:game.players[owner].upgrades,units:units.length,permanentUnits:units.filter((u:any)=>u.expiresTick===undefined).length,workers:units.filter((u:any)=>u.kind==='worker').length,
  healers:units.filter((u:any)=>UNIT_DEFS[u.kind].abilities.some((a:any)=>ABILITY_DEFS[a].behavior==='heal')).map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,cooldowns:u.abilityCooldowns})),
  bases:buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,x:b.x,y:b.y,hp:b.hp,complete:b.complete})),buildings:buildings.length,unitsLost:game.match.stats.unitsLost[owner],goldSpent:game.match.stats.goldSpent[owner]}];}))};
 rows.push(copy(row));
 const cpu=process.cpuUsage(cpuStart);const report={classification:'Same complete10200 original state continued under fixed current source; full3AI natural game tail, not ordinary0. No rank inspection queries, native observer or artificial orders. Source/normal frozen opponents/rules2 preserved.',mode,source:root,head:pre.head,inputTick:input.snapshot.tick,setup,result:{tick:game.tick,winner:game.match.winner,completed},elapsedMs:performance.now()-started,cpuMs:(cpu.user+cpu.system)/1000,rows};
 writeFileSync(prefix+'.json.tmp',JSON.stringify(report)+'\n');renameSync(prefix+'.json.tmp',prefix+'.json');
 console.log(JSON.stringify({mode,tick:game.tick,winner:game.match.winner,p0:{gold:row.players.p0.gold,supply:row.players.p0.supply,bases:row.players.p0.bases.length,units:row.players.p0.units,unitsLost:row.players.p0.unitsLost},rss:process.memoryUsage().rss,elapsedMs:report.elapsedMs}));
}
save(false);
const result=runGameLoop({...match,game,commandPlanner:(context:any)=>{const entries=planner(context);appendFileSync(prefix+'-plans.jsonl',JSON.stringify({tick:game.tick,owner:context.owner,entries})+'\n');return entries;}},{
 onCommand:(event:any)=>appendFileSync(prefix+'-commands.jsonl',JSON.stringify({tick:game.tick,owner:event.owner,source:event.source,scriptId:event.scriptId,command:event.command})+'\n'),
 onStep:()=>{if(game.tick%600===0||game.match.winner)save(!!game.match.winner);},
});
if(savedTick!==game.tick)save(!!game.match.winner);
if(!game.match.winner)throw Error('Natural terminal result missing');
const post=audit(),sourceEqual=pre.head===post.head&&isDeepStrictEqual(pre.files,post.files);writeFileSync(prefix+'-postflight.json',JSON.stringify({...post,sourceEqual},null,2)+'\n');
if(!sourceEqual)throw Error('Source changed during full tail');
console.log(JSON.stringify({mode,naturalWinner:game.match.winner,tick:game.tick,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,sourceEqual}));
