from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,datetime
D=Path('/workspace/.playtest/root-046-terminal225-cold-20261016');N=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');P=N/'known-archer0-04669148';S=Path('/workspace/sketch-rts-root-medical-04669148-fixed-control');O=D/'original';O.mkdir();H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();F=Path(str(P)+'.frames/48000.json.gz');saved=json.loads(gzip.decompress(F.read_bytes()));assert saved['snapshot']['tick']==48000 and saved['snapshot']['match']['winner']is None and set(saved['memories'])=={'p0','p1','p2'}
for src,name in [(F,'48000.json.gz'),(Path(str(P)+'-final.json.gz'),'final48225.json.gz')]:shutil.copyfile(src,O/name)
for name in ['native-telemetry.ts','native-ledger.ts']:shutil.copyfile(N/name,D/name)
(D/'package.json').write_text('{"private":true,"type":"module"}\n')
capfile=Path(str(P)+'-runtime-source.json');cap=json.loads(capfile.read_text());post=Path(str(P)+'-postflight.json');assert cap['head']=='0466914857bd7b185a66ec42edb0202b5a884ca5'and len(cap['files'])==1507 and len(cap['frozenFiles'])==497;assert json.loads(post.read_text())['sourceEqual'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['head'];assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True);assert all(H(S/f['path'])==f['sha256']for f in cap['files'])
expectedFinal=json.loads(gzip.decompress((O/'final48225.json.gz').read_bytes()));assert expectedFinal['snapshot']['tick']==48225 and expectedFinal['snapshot']['match']['winner']=='p0'
streams=['commands','plans','native-hits','native-events','native-deaths','ship-losses','corpse-events','health-transitions','healing-effects'];counts={};commandBase=0;planBase=0;hitBase=0;last={};alive={u['id']for u in saved['snapshot']['units']}|{b['id']for b in saved['snapshot']['buildings']}
for name in streams:
 src=Path(str(P)+'-'+name+'.jsonl.gz');count=0
 with gzip.open(src,'rt')as f,(O/(name+'.jsonl')).open('w')as out:
  for line in f:
   if not line.strip():continue
   x=json.loads(line);tick=x['tick'];before=tick<48000 or tick==48000 and name not in ['commands','plans']and x.get('commandIndex')is None and x.get('stage')!='after-command'
   if before:
    if name=='commands':commandBase+=1
    elif name=='plans':planBase+=1
    elif name=='native-hits':hitBase=x['index']+1;last[x['target']]=x
    continue
   assert tick>=48000
   out.write(line);count+=1
 counts[name]={'rows':count,'path':str(O/(name+'.jsonl')),'sha256':H(O/(name+'.jsonl')),'source':str(src),'sourceSHA256':H(src)}
seed={'classification':'Originalordinary0 pre-48000 command/plan prefix and hits through48000native-step but before48000P0. Last-hit refs onlyforcurrentlyliveentities. Telemetrylocalterminalcounts are not originalwholematchcounts.','commandBase':commandBase,'planBase':planBase,'hitBase':hitBase,'lastHit':[[i,h]for i,h in last.items()if i in alive]};(D/'observer-prefix-seed.json').write_text(json.dumps(seed,indent=2))
binding={'classification':'Preparedunique225terminalcoldclosure. NoGame/Node/P0/stepcreatedbythisreadcopy/hashpreparation. Full48000afterstep beforeP0 includesoriginalall3mem/setup; targetnatural48225p0winner. Original046fullmatchremainssoleordinary0score. Source1507/frozen497/184/r2 fullybound byreference, not repacked.','sourceCapPath':str(capfile),'sourceCapSHA256':H(capfile),'sourceHead':cap['head'],'sourceRoot':str(S),'inputSHA256':H(O/'48000.json.gz'),'originalFinalSHA256':H(O/'final48225.json.gz'),'streams':counts,'prefixSeed':seed,'sourceFiles':1507,'frozenFiles':497,'manifestFiles':184,'rulesVersion':2,'boundFiles':{str(p):H(p)for p in[capfile,Path(cap['sourceArchive']),Path(cap['frozenArchive']),post,N/'process-exit-1.json',D/'native-ledger.ts',D/'native-telemetry.ts',D/'package.json',D/'observer-prefix-seed.json',O/'48000.json.gz',O/'final48225.json.gz']}|{c['path']:c['sha256']for c in counts.values()}}
(D/'SOURCE-INPUT-BINDING.json').write_text(json.dumps(binding,indent=2));print(json.dumps({'source':cap['head'],'inputSHA256':binding['inputSHA256'],'commandBase':commandBase,'planBase':planBase,'hitBase':hitBase,'counts':{k:v['rows']for k,v in counts.items()},'noGame':True}))
