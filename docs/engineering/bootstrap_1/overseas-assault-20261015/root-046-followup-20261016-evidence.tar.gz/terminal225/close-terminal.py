from pathlib import Path
import json,gzip,itertools,hashlib,datetime
D=Path('/workspace/.playtest/root-046-terminal225-cold-20261016');O=D/'original';N=D/'replay48000-48225';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with p.open()as f:
  for l in f:
   if l.strip():yield json.loads(l)
def diff(a,b,path='$'):
 if type(a)!=type(b):return{'path':path,'old':a,'new':b}
 if isinstance(a,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:return{'path':path+'.'+k,'old':a.get(k,'<missing>'),'new':b.get(k,'<missing>')}
   z=diff(a[k],b[k],path+'.'+k)
   if z:return z
 elif isinstance(a,list):
  if len(a)!=len(b):return{'path':path+'.length','old':len(a),'new':len(b)}
  for i,(x,y)in enumerate(zip(a,b)):
   z=diff(x,y,path+'['+str(i)+']')
   if z:return z
 elif a!=b:return{'path':path,'old':a,'new':b}
 return None
res={}
for kind in ['commands','plans','native-hits','native-events','native-deaths','ship-losses','corpse-events','health-transitions','healing-effects']:
 a=O/(kind+'.jsonl');b=N/(kind+'.jsonl');ac=bc=bad=0;first=None
 for i,(x,y)in enumerate(itertools.zip_longest(rows(a),rows(b))):
  ac+=x is not None;bc+=y is not None
  if x!=y:
   bad+=1
   if first is None:first={'ordinal':i,'firstField':diff(x,y),'original':x,'replay':y}
 res[kind]={'originalRows':ac,'replayRows':bc,'differentObjects':bad,'firstDifference':first,'originalSHA256':H(a),'replaySHA256':H(b)}
a=json.loads(gzip.decompress((O/'final48225.json.gz').read_bytes()));b=json.loads(gzip.decompress((N/'final.json.gz').read_bytes()));fields={k:a[k]==b[k]for k in ['snapshot','nextId','memories','setup']};r={'classification':'Same046source terminal225strictcoldclosure only; original48225P0win/46loss remainsoneordinary0. Everyrawobject comparedstreaming, perownerplanincludesall3postmem, metadataoutside4finalstatefields excludedexplicitly.','start':48000,'end':48225,'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'streams':res,'completeFinalStateChecks':fields,'firstFinalDifference':None if all(fields.values())else diff({k:a[k]for k in fields},{k:b[k]for k in fields}),'allExact':all(v['differentObjects']==0 for v in res.values())and all(fields.values()),'report':json.loads((N/'report.json').read_text()),'originalFinalSHA256':H(O/'final48225.json.gz'),'replayFinalSHA256':H(N/'final.json.gz')};(D/'EXACT-TERMINAL225-CLOSURE.json').write_text(json.dumps(r,indent=2));print(json.dumps({'allExact':r['allExact'],'counts':{k:[v['originalRows'],v['replayRows'],v['differentObjects']]for k,v in res.items()},'final':fields}));raise SystemExit(0 if r['allExact']else 1)
