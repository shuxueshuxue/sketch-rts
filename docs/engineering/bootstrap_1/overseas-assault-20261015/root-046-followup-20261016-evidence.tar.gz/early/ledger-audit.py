from pathlib import Path
import json,gzip,collections,hashlib,datetime,shutil
D=Path('/workspace/.playtest/root-046-early-continuation-readonly-20261016');N=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');P=N/'known-archer0-04669148';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();final=json.loads(gzip.decompress(Path(str(P)+'-final.json.gz').read_bytes()));initial=json.loads(gzip.decompress(Path(str(P)+'.frames/0.json.gz').read_bytes()));report=json.loads(Path(str(P)+'.json').read_text())
def rows(kind):
 with gzip.open(Path(str(P)+'-'+kind+'.jsonl.gz'),'rt')as f:
  for line in f:
   if line.strip():yield json.loads(line)
terminal={};status={};deathrowcount=0
for x in rows('native-deaths'):
 deathrowcount+=1
 if x['type']=='native-unit-terminal':
  assert x['id']not in terminal;terminal[x['id']]=x;status[x['id']]=x['confirmation']
 else:status[x['id']]=x['status']
removal={};birth={};buildingterminal={};buildingremoval={};ownerchanges=[]
for x in rows('native-events'):
 t=x['type']
 if t=='unit-removal':removal[x['previous']['id']]=x
 elif t=='unit-birth-observed':birth[x['unit']['id']]=x
 elif t=='native-building-terminal':buildingterminal[x['previous']['id']]=x
 elif t=='building-removal':buildingremoval[x['previous']['id']]=x
 elif t=='owner-change':ownerchanges.append(x)
corpses={}
for x in rows('corpse-events'):
 c=x['corpse'];assert c['unitId']not in corpses;corpses[c['unitId']]=x
finalcorpses={c['unitId']:c for c in final['snapshot'].get('corpses',[])};assert set(corpses)==set(finalcorpses);assert all(corpses[i]['corpse']==finalcorpses[i]for i in corpses)
fatal={};fatalbuild={};killcounters=collections.Counter();hitcount=0;ownDamage=collections.defaultdict(lambda:{'hits':0,'damage':0})
for x in rows('native-hits'):
 hitcount+=1
 if x['attackerOwner']=='p0':ownDamage[x['attacker']]['hits']+=1;ownDamage[x['attacker']]['damage']+=x['damage']
 if not x['positiveToNonpositive']:continue
 table=fatal if x['targetIsUnit']else fatalbuild;assert x['target']not in table;table[x['target']]=x
 if x['targetIsUnit']:killcounters[x['attackerOwner']]+=1
completedheals=collections.defaultdict(list)
for x in rows('healing-effects'):
 e=x['effect'];sid=e.get('sourceId')or e.get('unitId')
 if sid:completedheals[sid].append({'tick':x['tick'],'stage':x['stage'],'commandIndex':x['commandIndex'],'effect':e})
unitdeaths={i:x for i,x in terminal.items()if x['terminalClass']=='death-observed'};expiries={i:x for i,x in terminal.items()if x['terminalClass']=='lifetime-expiry-eligible-removal'};unknown={i:x for i,x in terminal.items()if x['terminalClass']=='removal-cause-unconfirmed'}
assert set(unitdeaths)==set(corpses);assert not unknown;assert all(status[i]in['absent-at-native-boundary','native-removal-after-nonpositive']for i in unitdeaths)
assert set(terminal)==set(removal);assert set(finalcorpses)==set(unitdeaths)
alive={u['id']:u for u in final['snapshot']['units']};initialunits={u['id']:u for u in initial['snapshot']['units']};seen=set(initialunits)|set(birth)
byowner={}
for owner in ['p0','p1','p2','neutral','player','enemy','enemy2']:
 owned={i:x for i,x in unitdeaths.items()if(x.get('atObservation')or x['previous'])['owner']==owner};permanent=[i for i,x in owned.items()if x['permanent']];temporary=[i for i,x in owned.items()if not x['permanent']];expired=[i for i,x in expiries.items()if(x.get('atObservation')or x['previous'])['owner']==owner];fids=[i for i,x in fatal.items()if x['targetOwner']==owner];native=final['snapshot']['match']['stats']['unitsLost'].get(owner,0)
 assert len(owned)==native
 byowner[owner]={'nativeUnitsLost':native,'confirmedPermanentDeaths':len(permanent),'confirmedTemporaryDeaths':len(temporary),'expiryRemovalsWithoutDeath':len(expired),'fatalPositiveToNonpositiveUnitCallbacks':len(fids),'corpseAndRemovalDeathIDsExact':all(i in corpses and i in removal for i in owned),'permanentIDs':permanent,'temporaryIDs':temporary,'expiryIDs':expired,'fatalIDs':fids,'finalAlive':sum(u['owner']==owner for u in alive.values())}
extra=[{'id':i,'priorTerminal':terminal.get(i),'nativeFatalLater':fatal[i],'corpseExists':i in corpses,'nativeRemoval':removal.get(i)}for i in fatal.keys()-unitdeaths.keys()]
assert len(extra)==1 and extra[0]['id']=='unit-p1-spirit-17983'and extra[0]['priorTerminal']['tick']==19065 and extra[0]['priorTerminal']['terminalClass']=='lifetime-expiry-eligible-removal'and extra[0]['nativeFatalLater']['tick']==19066
own=[]
for i,x in unitdeaths.items():
 body=(fatal.get(i)or{}).get('targetAtObservation')or x.get('atObservation')or x['previous']
 if body['owner']!='p0':continue
 own.append({'id':i,'tick':x['tick'],'kind':body['kind'],'level':body.get('level',0),'xp':body.get('xp',0),'kills':body.get('kills',0),'maxHp':body['maxHp'],'speed':body['speed'],'attackDamage':body['attackDamage'],'attackRange':body['attackRange'],'hands':body.get('hands'),'gearMass':body.get('gearMass'),'permanent':x['permanent'],'nativeFatal':fatal.get(i),'nativeTerminal':x,'nativeRemoval':removal[i],'corpse':corpses[i],'valueStateEvidence':'nativefatal targetAtObservation, else nativeboundary terminal body','completedHealEffects':completedheals.get(i,[]),'observedDamageHitsAsAttacker':ownDamage.get(i,{'hits':0,'damage':0})})
medics=[x for x in own if x['kind']in['priest','fieldMedic']];veterans=[x for x in own if x['level']>0];own.sort(key=lambda x:x['tick'])
(D/'P0-PERMANENT-LOSSES-AND-VALUE.json').write_text(json.dumps({'classification':'All46P0 confirmedpermanentunitlosses with actualnativefatal+removal+corpse. Veteranstate isactualatdeath. Completedhealeffects bysourceId are nativecompletionwitnesses, not publicattempts or nominal55HPsum; effectivehealHP attribution notinvented. Damage sum isobservedhitamount, includespossibleoverkill and isnot economicvalue.','ownPermanentCount':len(own),'ownTemporaryCount':0,'byKind':dict(collections.Counter(x['kind']for x in own)),'veteranLossCount':len(veterans),'veteranLevelHistogram':dict(collections.Counter(x['level']for x in veterans)),'veteranLossIDs':[x['id']for x in veterans],'doctorLossCount':len(medics),'doctorLosses':[{'id':x['id'],'kind':x['kind'],'tick':x['tick'],'level':x['level'],'xp':x['xp'],'kills':x['kills'],'completedHealEffectsBeforeLoss':len(x['completedHealEffects']),'observedDamageHitsAsAttacker':x['observedDamageHitsAsAttacker']}for x in medics],'losses':own},indent=2))
summary={'classification':'Complete046ordinary0 passiveread ledger, nonewGame/planner/commands. Unitdeaths+corpse+native-removal reconcilebyID for allowners; lifetimeexpiry separate. One laterfatal callback to alreadyexpiredspirit explains unitsKilled versusunitsLost difference without inventingextra death. Whole48225win belongscombined046, not641component.','head':'0466914857bd7b185a66ec42edb0202b5a884ca5','fullRunResult':report['result'],'commandCount':report['commandCount'],'ownerPlanCount':report['planCount'],'nativeHitCount':hitcount,'nativeDeathRowsIncludingStatus':deathrowcount,'uniqueTerminalIDs':len(terminal),'confirmedDeathIDs':len(unitdeaths),'lifetimeExpiryIDs':len(expiries),'unitNativeRemovalIDs':len(removal),'corpseEventsUnique':len(corpses),'finalPersistentCorpses':len(finalcorpses),'allCorpseObjectsExactFinal':True,'unknownRemovalIDs':list(unknown),'pendingCleanupIDs':[i for i in unitdeaths if status[i]=='hp<=0-awaiting-cleanup'],'seenUnitUniverse':len(seen),'terminalPlusFinalUniverse':len(set(terminal)|set(alive)),'seenMissingFromTerminalAndFinal':sorted(seen-(set(terminal)|set(alive))),'terminalOrFinalWithoutBirthBoundary':sorted((set(terminal)|set(alive))-seen),'ownerChanges':ownerchanges,'owners':byowner,'nativeKillsByOwner':final['snapshot']['match']['stats']['unitsKilled'],'positiveFatalUnitCallbacksByAttacker':dict(killcounters),'extraFatalAlreadyExpired':extra,'buildingNativeTerminals':len(buildingterminal),'buildingNativeRemovals':len(buildingremoval),'buildingFatalCallbacks':len(fatalbuild),'buildingIDClosure':set(buildingterminal)==set(buildingremoval)==set(fatalbuild),'originalFinalMemories':'Allp0,p1,p2 fulloriginalmemory objects preserved in originalfinal.json.gz copiedunchanged; no p0-only reconstruction.','originalFinalSHA256':H(Path(str(P)+'-final.json.gz'))}
assert all(summary['nativeKillsByOwner'].get(o,0)==killcounters.get(o,0)for o in summary['nativeKillsByOwner']);assert summary['buildingIDClosure'];assert not summary['seenMissingFromTerminalAndFinal'];assert not summary['terminalOrFinalWithoutBirthBoundary']
shutil.copyfile(Path(str(P)+'-final.json.gz'),D/'original046-final-all3mem.json.gz');(D/'WHOLE-MATCH-LEDGER-CLOSURE.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'owners':{k:{n:v for n,v in x.items()if not n.endswith('IDs')}for k,x in byowner.items()},'terminal':len(terminal),'death':len(unitdeaths),'expiry':len(expiries),'corpse':len(corpses),'extraFatalAfterExpiry':[(x['id'],x['priorTerminal']['tick'],x['nativeFatalLater']['tick'])for x in extra],'p0Kinds':dict(collections.Counter(x['kind']for x in own)),'veterans':len(veterans),'doctors':[(x['id'],x['tick'],len(x['completedHealEffects']))for x in medics]}))
