from pathlib import Path
import json,gzip,hashlib,itertools,datetime,shutil,os
D=Path('/workspace/.playtest/root-046-early-continuation-readonly-20261016');N=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');NP=N/'known-archer0-04669148';O=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016');OP=O/'known-archer0-8da5';C=Path('/tmp/bootstrap-medical-safe-prefix-8da-20261016/clinical8400-9000')
H=lambda b:hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_text())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def state(f):return {k:f[k]for k in ['snapshot','nextId','memories','setup']}
def frame(p):
 a=p.stat();b=p.read_bytes();f=json.loads(gzip.decompress(b));z=p.stat();assert(a.st_size,a.st_mtime_ns)==(z.st_size,z.st_mtime_ns);return f,{'path':str(p),'bytes':len(b),'sha256':H(b),'mtimeNs':z.st_mtime_ns}
def diff(a,b,path='$'):
 if type(a)!=type(b):return {'path':path,'old':a,'new':b}
 if isinstance(a,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:return {'path':path+'.'+k,'old':a.get(k,'<missing>'),'new':b.get(k,'<missing>')}
   d=diff(a[k],b[k],path+'.'+k)
   if d:return d
 elif isinstance(a,list):
  if len(a)!=len(b):return {'path':path+'.length','old':len(a),'new':len(b)}
  for i,(x,y)in enumerate(zip(a,b)):
   d=diff(x,y,path+'['+str(i)+']')
   if d:return d
 elif a!=b:return {'path':path,'old':a,'new':b}
 return None
rows=[]
for t in range(0,8401,600):
 a,ab=frame(Path(str(OP)+'.frames')/(str(t)+'.json.gz'));b,bb=frame(Path(str(NP)+'.frames')/(str(t)+'.json.gz'));checks={k:canonical(a[k])==canonical(b[k])for k in ['snapshot','nextId','memories','setup']};rows.append({'tick':t,'old':ab,'new':bb,'wholeWorldIdAll3MemAndSetup':checks,'oldFieldHashes':{k:H(canonical(a[k]))for k in checks},'newFieldHashes':{k:H(canonical(b[k]))for k in checks},'firstDifference':None if all(checks.values())else diff(state(a),state(b))})
(D/'FRAME0-8400-COMPARISON.json').write_text(json.dumps({'classification':'15completeordinary0 saved600-afterstep frames, eachfullworld/id/all3mem/setup compared; not counts or partialactorchecks, not claim everyunsavednative-tick state.', 'oldHead':'8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d','newHead':'0466914857bd7b185a66ec42edb0202b5a884ca5','all15Exact':all(all(x['wholeWorldIdAll3MemAndSetup'].values())for x in rows),'cases':rows},indent=2))
a,ab=frame(C/'final.json.gz');b,bb=frame(Path(str(NP)+'.frames')/'9000.json.gz');checks={k:canonical(a[k])==canonical(b[k])for k in ['snapshot','nextId','memories','setup']};(D/'FRAME9000-VS-641-CLINICAL.json').write_text(json.dumps({'classification':'Actual046ordinary0 full9000-afterstep compared withsealed641clinical9000 completefinalstate; metadataoutside4statekeys omitted explicitly.', 'clinical':ab,'ordinary0':bb,'checks':checks,'firstDifference':None if all(checks.values())else diff(state(a),state(b))},indent=2));shutil.copyfile(Path(str(NP)+'.frames')/'9000.json.gz',D/'actual046-9000.json.gz')
# Rawstreams areimmutable now: requirepostflightandactualprocess-exit; validatefullgzipincrementally, neverholdJSONLarrays.
post=Path(str(NP)+'-postflight.json');ex=N/'process-exit-1.json';assert post.exists()and ex.exists()and J(ex)['exitCode']==0;assert J(post)['sourceEqual'];bindings={}
for typ in ['commands','plans','native-hits','native-deaths','health-transitions','healing-effects','native-events','corpse-events']:
 p=Path(str(NP)+'-'+typ+'.jsonl.gz');before=p.stat();h=hashlib.sha256()
 with p.open('rb')as f:
  for chunk in iter(lambda:f.read(65536),b''):h.update(chunk)
 decoded=0
 with gzip.open(p,'rb')as f:
  for chunk in iter(lambda:f.read(65536),b''):decoded+=len(chunk)
 after=p.stat();assert(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns);bindings[typ]={'path':str(p),'compressedBytes':after.st_size,'sha256':h.hexdigest(),'mtimeNs':after.st_mtime_ns,'decodedBytes':decoded,'completeGzipCRCVerified':True,'closedPostflight':str(post),'closedExit':str(ex)}
(D/'CLOSED-RAW-STREAM-BINDINGS.json').write_text(json.dumps(bindings,indent=2))
def stream(p):
 opener=gzip.open if str(p).endswith('.gz')else open
 with opener(p,'rt')as f:
  for l in f:
   if l.strip():yield json.loads(l)
def until9000(p,kind):
 for x in stream(p):
  t=x['tick']
  if t<8400:continue
  if t>9000:break
  if t==9000 and(kind in ['commands','plans']or x.get('stage')=='after-command' or x.get('commandIndex')is not None):continue
  yield x
def compare(a,b,kind,filtering=False):
 aa=until9000(a,kind)if filtering else stream(a);bb=until9000(b,kind)if filtering else stream(b);countA=0;countB=0;diffs=0;first=None
 for i,(x,y)in enumerate(itertools.zip_longest(aa,bb)):
  countA+=x is not None;countB+=y is not None
  if canonical(x)!=canonical(y):
   diffs+=1
   if first is None:first={'ordinal':i,'old':x,'new':y,'firstField':diff(x,y)}
 return {'left':str(a),'right':str(b),'leftCount':countA,'rightCount':countB,'differingRows':diffs,'firstDifference':first}
firsts={}
for typ in ['commands','plans']:
 a=Path(str(OP)+'-'+typ+'.jsonl.gz');b=Path(str(NP)+'-'+typ+'.jsonl.gz');same=0;found=None
 for i,(x,y)in enumerate(itertools.zip_longest(stream(a),stream(b))):
  if canonical(x)!=canonical(y):found={'ordinal':i,'samePrefixRows':same,'old':x,'new':y,'firstField':diff(x,y)};break
  same+=1
 firsts[typ]=found
(D/'FIRST-DIFFERENT-PUBLIC-PLAN.json').write_text(json.dumps({'classification':'Old8da vsnew046 originalwholematch rawstreams comparedoneobjectatatime untilfirstdifference. Plansincludeall3postmem, commandsarepublicattempts.', 'streams':firsts},indent=2))
comparisons={}
for typ in ['commands','plans','native-hits','native-deaths','health-transitions','healing-effects','native-events','corpse-events']:
 comparisons[typ]=compare(C/(typ+'.jsonl'),Path(str(NP)+'-'+typ+'.jsonl.gz'),typ,True)
(D/'RAW8400-9000-VS-641-CLINICAL.json').write_text(json.dumps({'classification':'Oneoriginal046wholematch actualsuffix vsalreadysealed641clinical; no newGame/P0/step. Native9000step included,9000think/commands excluded; comparesfullobjects, one row in memory.','allStreamsExact':all(v['differingRows']==0for v in comparisons.values()),'streams':comparisons},indent=2))
ids={'unit-p0-footman-1070','unit-p0-lancer-1979','unit-p0-lancer-1527','unit-p0-archer-1269','unit-p0-archer-1125','unit-p0-fieldMedic-1418','unit-p0-fieldMedic-1602','creep-gen-5-1','creep-gen-5-2'};local={}
for typ in ['native-hits','native-deaths','health-transitions','healing-effects','commands']:
 selected=[]
 for x in until9000(Path(str(NP)+'-'+typ+'.jsonl.gz'),typ):
  c=x.get('command',{});actors=set(c.get('unitIds',[c.get('unitId')]))
  keep=x.get('id')in ids or x.get('target')in ids or x.get('attacker')in ids or bool(ids&actors)or typ=='healing-effects'
  if keep:selected.append(x)
 local[typ]=selected
(D/'ACTUAL046-LOCAL-MEDICAL-EVENTS.json').write_text(json.dumps({'classification':'Extractedoriginal046actual8400..9000 records, selectedIDs only. Thisextractisnot newtelemetry/actualfull8504world if no suchframeexists.','selectedIDs':sorted(ids),'streams':local},indent=2))
# Candidatefull8504 existsbutordinary0doesnot necessarilyrecordthat tick; do notinventone.
frames=list(Path(str(NP)+'.events').glob('8504-*'));boss=list(Path(str(NP)+'.events').glob('8500-*'));frame9000=state(b)if False else frame(Path(str(NP)+'.frames')/'9000.json.gz')[0]
fate={'actual8504FullEventFrames':[str(p)for p in frames],'actual8500FullEventFrames':[str(p)for p in boss],'strict8504Interpretation':'No8504fullworld isclaimedunlesslisted. Infer1979survivalfromfull8500eventunit+no1979deaththrough8504+full9000livingunit, andactualboss8500nativefatalhit.','actual9000RelatedUnits':[u for u in frame9000['snapshot']['units']if u['id']in ids],'actual9000NativeOwnLoss':frame9000['snapshot']['match']['stats']['unitsLost'].get('p0'),'originalWholeMatchResultInformationalOnly':J(Path(str(NP)+'.json'))['result']}
for p in boss:shutil.copyfile(p,D/('actual046-'+p.name))
(D/'ACTUAL8504-9000-FATE.json').write_text(json.dumps(fate,indent=2))
print(json.dumps({'frames15AllExact':all(all(x['wholeWorldIdAll3MemAndSetup'].values())for x in rows),'frame9000vs641':checks,'firstDifferences':{k:None if not v else {'ordinal':v['ordinal'],'tick':v['new']['tick'],'owner':v['new']['owner'],'firstField':v['firstField']}for k,v in firsts.items()},'suffixExact':all(v['differingRows']==0for v in comparisons.values()),'suffixCounts':{k:(v['leftCount'],v['rightCount'],v['differingRows'])for k,v in comparisons.items()},'actual8504Frames':len(frames),'actual9000OwnLoss':fate['actual9000NativeOwnLoss']}))
