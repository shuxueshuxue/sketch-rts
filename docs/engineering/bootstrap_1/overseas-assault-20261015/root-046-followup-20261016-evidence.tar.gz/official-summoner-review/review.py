from pathlib import Path
import json, hashlib, subprocess, tarfile, difflib, datetime

D=Path('/workspace/.playtest/root046-official-summoner-driver-independent-review-20261016')
P=Path('/workspace/.playtest/bootstrap-root046-official-summoner-brokenSea-20261016')
OLD=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016')
S=Path('/workspace/sketch-rts-root-medical-04669148-fixed-control')
H=lambda b:hashlib.sha256(b).hexdigest()
def hf(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
readset={}
def read(p):
 p=Path(p);b=p.read_bytes();readset[str(p)]={'bytes':len(b),'sha256':H(b)};return b
def js(p):return json.loads(read(p))
prepared=js(P/'PREPARED.json');pre=js(P/'driver-preflight.json');decl=js(P/'official-case-declaration.json')
cap=js(P/'official-summoner-v5v8-04669148-runtime-source.json')
assert prepared['preparedOnlyNoGameNoNode'] is True
assert prepared['sourceHead']==cap['head']==pre['sourceHead']=='0466914857bd7b185a66ec42edb0202b5a884ca5'
assert prepared['sourceRoot']==cap['root']==pre['sourceRoot']==str(S)
for p,h in {**prepared['launchBoundFiles'],**pre['boundFiles']}.items():assert H(read(p))==h,p
for n,h in pre['dependencies'].items():assert H(read(P/n))==h,n
driver=read(P/pre['driverFile']).decode();old=read(OLD/'ordinary0-known-archer.mts').decode()
assert H(driver.encode())==pre['driverSHA256']
assert H(read(P/'official-case-declaration.json'))==pre['caseDeclarationSHA256']
assert H(read(P/'official-summoner-v5v8-04669148-runtime-source.json'))==pre['runtimeSourceCapSHA256']
assert js(P/'package.json')['type']=='module' and pre['driverFile'].endswith('.mts')
for n in pre['dependencies']:assert read(P/n)==read(OLD/n),n
launcher=read(P/'launch-ordinary0.py').decode();compile(launcher,str(P/'launch-ordinary0.py'),'exec')
assert "'requiredHeadroom':2*1024**3" in launcher and "'requiredOutputFreeBytes':256*1024**2" in launcher
assert 'subprocess.run(args' in launcher and "'--max-old-space-size=768','--import','tsx'" in launcher
assert not (P/'observation-stop.json').exists()
out_prefix=Path(prepared['prefix']);assert set(P.glob(out_prefix.name+'*'))=={Path(str(out_prefix)+'-runtime-source.json')}
assert decl['officialMap'] is True and decl['unseenGeneratedEvidence'] is False
assert decl['setup']=={'map':'brokenSea','seed':'bootstrap_1-official-summoner-v5-v8-20261016-1354z-a','unseen':False,'side':0,'agents':{'p0':{'version':'v9_summoner','versionLabel':'v9_summoner','race':'grove','controller':'external-agent','team':'a'},'p1':{'version':'v5','versionLabel':'v5','race':'ember','controller':'external-agent','team':'b'},'p2':{'version':'v8','versionLabel':'v8','race':'grove','controller':'external-agent','team':'b'}},'thinkInterval':15,'rulesVersion':2,'frozenRevision':'d1ae110f2edd99f9c7d899ed61557891ab587639'}
setup_text=driver.split('const setup = ',1)[1].split(';\nif(declaration.seed',1)[0]
assert json.loads(setup_text)==decl['setup']
assert 'baselineFactory' not in driver and 'baseline38f' not in driver and 'initial-equality' not in driver
assert "Object.values(frame().memories).some(m=>m!==null)" in driver
assert 'postMemories:Object.fromEntries(owners.map(owner=>[owner,memories.get(owner)??null]))' in driver
assert "if(!game.match.winner&&game.tick%600===0&&existsSync" in driver
assert "if(!game.match.winner&&!observationStopped)throw Error('Natural terminal result missing')" in driver
assert 'match.maxTicks!==Number.MAX_SAFE_INTEGER' in driver
assert driver[driver.index('let result:any;try{'):]==old[old.index('let result:any;try{'):]
assert driver[driver.index('const streamBuffers='):driver.index('game.observer=')]==old[old.index('const streamBuffers='):old.index('game.observer=')]
delta=''.join(difflib.unified_diff(old.splitlines(True),driver.splitlines(True),fromfile='knownarcher.mts',tofile='officialsummoner.mts'))
assert delta==read(P/'DRIVER-DELTA.patch').decode()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['head']
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True)==''
scope=['src','scripts','tools','.gitattributes','.gitignore','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json']
tree=subprocess.check_output(['git','ls-tree','-r','-z',cap['head'],'--',*scope],cwd=S).split(b'\0')
gitfiles={x.split(b'\t',1)[1].decode():x.split(b'\t',1)[0].split()[2].decode() for x in tree if x}
assert len(gitfiles)==len(cap['files'])==1507
assert set(gitfiles)=={f['path']for f in cap['files']}
source_checks=[]
for f in cap['files']:
 b=(S/f['path']).read_bytes();actual={'path':f['path'],'bytes':len(b),'sha256':H(b),'gitBlob':blob(b)}
 assert actual['bytes']==f['bytes'] and actual['sha256']==f['sha256'] and actual['gitBlob']==f['expectedGitBlob']==f['actualGitBlob']==gitfiles[f['path']] and f['matches'] is True
 source_checks.append(actual)
manifest=js(S/'docs/engineering/bootstrap_1/frozen-policy.json')
assert manifest['rulesVersion']==cap['rulesVersion']==2 and manifest['revision']==cap['frozenRevision']==decl['setup']['frozenRevision']
assert len(manifest['files'])==184 and manifest['files']==cap['frozenManifestFiles']
assert hf(S/'docs/engineering/bootstrap_1/frozen-policy.json')==cap['frozenManifestSHA256']=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
archive_checks={}
for key in ['sourceArchive','frozenArchive']:
 a=Path(cap[key]);assert hf(a)==cap[key+'SHA256'] and a.stat().st_size==cap[key+'Bytes']
 expected={f['path']:f['sha256']for f in cap['files']}if key=='sourceArchive'else cap['frozenFiles']
 found={};index=None
 with tarfile.open(a,'r|gz') as tf:
  for m in tf:
   if m.isdir():continue
   assert m.isfile(),m.name
   if m.name=='INDEX.json':index=json.load(tf.extractfile(m));continue
   rel=m.name.removeprefix('live/')if key=='sourceArchive'else m.name
   assert rel in expected and rel not in found,rel
   b=tf.extractfile(m).read();assert H(b)==expected[rel],rel
   if key=='sourceArchive':assert blob(b)==gitfiles[rel]
   else:assert blob(b)==cap['frozenGitBlobsVerified'][rel]
   found[rel]={'sha256':H(b),'bytes':len(b),'gitBlob':blob(b)}
 assert set(found)==set(expected)
 archive_checks[key]={'path':str(a),'sha256':cap[key+'SHA256'],'bytes':a.stat().st_size,'verifiedPayloads':len(found),'INDEXPresent':index is not None,'allPayloadSHA256AndGitBlobsMatch':True}
 assert len(found)==(1507 if key=='sourceArchive' else 497)
 if key=='frozenArchive':
  for p,h in manifest['files'].items():assert found[p]['sha256']==h
for k in ['sourceCapReference','frozenSourceCapReference','rootCombinedValidationReceipt','rootSourceEquivalenceReceipt']:
 hk=k.replace('Receipt','')+'SHA256'if k.endswith('Receipt')else k+'SHA256'
 assert hf(cap[k])==cap[hk],(k,hk)
for rel,h in [('src/shared/map-pool.ts',decl['mapPoolSourceSHA256']),('src/ai/bootstrap_1/benchmark.ts',decl['bootstrapFactorySourceSHA256'])]:assert H(read(S/rel))==h
factory=read(S/'src/ai/bootstrap_1/benchmark.ts').decode();pool=read(S/'src/shared/map-pool.ts').decode();policy=read(S/'src/ai/bootstrap_1/policy.ts').decode();planner=read(S/'scripts/bootstrap_1-planner.ts').decode();runner=read(S/'src/sdk/game-runner.ts').decode()
assert "['v5','v8']" in factory and 'v9_summoner' in policy
assert '{ id: "brokenSea"' in pool and 'players: 4, layout: { seed: "pool-brokenSea-1", kind: "ring", idea: "islandStarts" }' in pool
assert "...(match.unseen ? {layout:{...pool.layout,seed:`${match.seed}:${pool.id}`},teams:physicalTeams} : {})" in factory
assert "if (owners.length === 3 && pool.players === 2) addTeammateStart(game)" in factory
(D/'SOURCE-1507-READBACK.json').write_text(json.dumps(source_checks,indent=2)+'\n')
(D/'READSET.json').write_text(json.dumps(readset,indent=2)+'\n')
report={'classification':'Independent read-only static and full-file hash review of one PREPARED official brokenSea v9_summoner Grove side0 vs frozen normal v5 Ember + v8 Grove ordinary0. No Node/TypeScript import/Game/P0/step/test/compiler/launch performed. Not runtime factory validation or a match result.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preparedDirectory':str(P),'sourceHead':cap['head'],'sourceRoot':str(S),'sourceFiles1507GitAndLiveExact':True,'frozenRulesVersion':2,'frozenManifestFiles':184,'archiveReadbacks':archive_checks,'driverProtocol':{'officialCaseSetupExact':True,'approvedFactoryStaticTrace':'Original official brokenSea full4seat ring/islandStarts retained; side0 maps owned seats0/2/3 to p0/p1/p2, unused seat1 owned entities omitted, neutral entities/terrain/camps/resources retained. unseen=false does not override layout seed or physical teams; addTeammateStart only for 2-seat maps, hence not used.','normal500Gold3Workers8CapRuntimeGuardsPreserved':True,'nullAll3MemoryBeforeFirstThinkGuardPreserved':True,'fullFrameWorldIdAll3MemorySetupPreserved':True,'perOwnerPlanAll3PostMemoryPreserved':True,'observerFilesEqualPreviouslyCompleted046Driver':True,'entireRunLoopAndTerminalClosureTextEqualCompleted046Driver':True,'streamBufferHealthAndCorpseObserverSectionTextEqualCompleted046Driver':True,'knownArcherBaselineWorldEqualityRemovedIntentionally':True,'noGeneratedHoldoutClaim':True,'fullUnboundedNaturalWinnerProtocolPreserved':True,'parentReasonEvidenceStopOnlyAt600BoundaryAndAfterNaturalWinner':True,'fresh2GiB768HeapAnd256MiBOutputGatePreserved':True},'blockers':[],'limits':['No factory/game constructed; runtime guards will validate true0 on parent launch.','No result or bootstrap acceptance established; score must belong to complete046 source and this official case.','Original broken-container uncommitted work recovery gap remains unrecovered.'],'readsetSHA256':hf(D/'READSET.json'),'sourceReadbackSHA256':hf(D/'SOURCE-1507-READBACK.json')}
(D/'REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'blockers':report['blockers'],'sourceFiles':1507,'frozenFiles':497,'manifestFiles':184,'reviewPath':str(D/'REVIEW.json'),'reviewSHA256':hf(D/'REVIEW.json'),'readsetSHA256':report['readsetSHA256']}))
