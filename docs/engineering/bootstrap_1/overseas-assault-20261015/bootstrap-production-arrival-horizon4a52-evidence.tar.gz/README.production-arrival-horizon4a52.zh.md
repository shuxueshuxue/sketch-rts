4a52a5212c4225395c0401010dc12188146e5551，基于production3bdb的独立几何候选，完整普通0自然20012 p1获胜，我方全灭，未合入。49永久死亡/1中立死/10396花费；旧5f43714胜仅归旧源，production3bdb26107败另封0d4b8342…，不得混记。

仅mountedEscape原goal building过滤变窄：nominal goal在原arrival包络内时，还需患者当前离楼≤楼radius+患者radius+原arrival5+当前speed×原15tick/20才拒绝。原clearOfBuildingArrival helper和rendezvous prefix检查原样保留。基于当下正常走路最大位移，地形/status pace≤1；不称可预测外部推撞、未来aura/速度变化。原7905/7913碰塔反例及护理语义保持。无follow变体、临界血量/资源预算/编组门槛更改。

实际10425假阳性与单hunk347消融归因另封f7f97f5b…。4a52固定源600tick10200→10800完整world/nextId/3mem恢复原5f，10215checkpoint完整等值。真实10425fixture增量5841be99；原7905两测与护理/claims/35%/front/expedition共57项通过，tsc0。独立测试树恢复原3bdb mounted-micro后，旧两测试通过、新10425失败（1fail2pass），之后恢复候选字节且clean。

真正标准0用原inspect，无恢复/人工命令/预置memory：三方500/3/8，Grove v9_archer physicalside1 vs frozenv8 Ember+Grove，pineshade生成ladder4608²，已开发seed bootstrap_1-unseen-archer-v8-v8-20261015-01。第三席、规则2、冻结184、manifest0490不变。胶囊9fd75122…，1254运行源/数据及1494全present源前后不变。每600及终局完整world/nextId/3mem，独立factory0与旧5f全等。已保存点至16200同5f；16800首不同保存点，不能推未采样帧全同。600tick修复和57测试不构成完整修复。

同源19800→20012终局及19815复原与原终局world/nextId/3mem完整相等，driver changed-code默认分类已在closed更正。较短败局49死少于旧56不算收益。第二16200→16800首分叉另补包，不改此封档。bootstrap三路线最终完整正常对手/地图/种子泛化要求未完成，原容器未提交修改恢复缺口保持。
