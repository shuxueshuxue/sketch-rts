import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { bootstrapPolicyContext, BOOTSTRAP_VERSIONS } from '../../src/ai/bootstrap_1/policy';
import { planRiderCrossing } from '../../src/ai/bootstrap_1/rider-crossing';
import { planRiderCrossing as before } from './rider-crossing-before';
const fixture = JSON.parse(gunzipSync(readFileSync('src/ai/bootstrap_1/fixtures/archer-economic-rider-lift.json.gz')).toString());
const rows = [];
for (const phase of ['before', 'after']) for (const version of BOOTSTRAP_VERSIONS) for (const [code, run] of [['73d6c4a3', before], ['candidate', planRiderCrossing]] as const) {
  const { snapshot, memory } = structuredClone(fixture[phase]);
  const original = JSON.stringify(snapshot), options = bootstrapPolicyContext(snapshot, 'p0', version, { memory, teams: snapshot.teams });
  const start = performance.now(), commands = run(snapshot, 'p0', options);
  rows.push({ phase, version, code, tick: snapshot.tick, queryMs: performance.now() - start,
    gold: snapshot.players.p0.gold, plan: memory.naval.island.plan,
    mission: memory.naval.ferries['unit-p0-carrier-3510'] ?? null, commands: commands ?? [], snapshotUnchanged: original === JSON.stringify(snapshot) });
}
writeFileSync('.playtest/overseas-assault-20261015/rider-economic-lift-red-green.json', JSON.stringify({ provenance: fixture.provenance, rows }, null, 2));
console.log(rows.map(row => ({ phase: row.phase, version: row.version, code: row.code, mission: row.mission?.purpose ?? null,
  stop: row.commands.length, queryMs: Math.round(row.queryMs * 100) / 100, snapshotUnchanged: row.snapshotUnchanged })));
