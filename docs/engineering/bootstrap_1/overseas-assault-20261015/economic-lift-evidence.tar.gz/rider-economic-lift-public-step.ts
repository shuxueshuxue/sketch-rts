import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createGame, restoreSnapshotIntoGame, snapshotGame, issuePlayerCommand, stepGame } from '../../src/shared/sim';
import { bootstrapPolicyContext } from '../../src/ai/bootstrap_1/policy';
import { planBootstrapNaval } from '../../src/ai/bootstrap_1/expedition-recovery';
const fixture = JSON.parse(gunzipSync(readFileSync('src/ai/bootstrap_1/fixtures/archer-economic-rider-lift.json.gz')).toString());
const saved = fixture.after, game = createGame('bareDuel'), memory = saved.memory;
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
const ferryId = 'unit-p0-carrier-3510', riderId = 'unit-p0-horseArcher-5279';
const path = '.playtest/overseas-assault-20261015/rider-economic-lift-public-step';
mkdirSync(`${path}.json.frames`, { recursive: true });
const rows: any[] = [], commands: any[] = [];
for (let elapsed = 0; elapsed <= 3600; elapsed++) {
  if (elapsed % 300 === 0) {
    const snapshot = snapshotGame(game), ship = snapshot.units.find(unit => unit.id === ferryId)!;
    const workers = snapshot.units.filter(unit => unit.kind === 'worker' && unit.deck?.shipId === ferryId);
    rows.push({ tick: game.tick, gold: snapshot.players.p0!.gold, mission: structuredClone(memory.naval.ferries[ferryId]),
      boat: { x: ship.x, y: ship.y, hp: ship.hp, order: ship.order }, workersAboard: workers.map(unit => unit.id),
      riderOrder: snapshot.units.find(unit => unit.id === riderId)?.order, losses: game.match.stats.unitsLost.p0 });
    writeFileSync(`${path}.json.frames/${game.tick}.json`, JSON.stringify({ snapshot, nextId: game.nextId, memory }));
  }
  if (elapsed === 3600) break;
  if (elapsed % 15 === 0) {
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams: game.teams });
    const planned = planBootstrapNaval(snapshot, 'p0', options);
    if (elapsed < 60) commands.push({ tick: game.tick, commands: planned });
    for (const command of planned) issuePlayerCommand(game, 'p0', command);
  }
  stepGame(game);
}
const report = { provenance: fixture.provenance, scope: '3600 native ticks; p0 bootstrap naval only; inherited p1 orders; diagnostic, not a full AI match', rows, commands };
writeFileSync(`${path}.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(rows, null, 2));
