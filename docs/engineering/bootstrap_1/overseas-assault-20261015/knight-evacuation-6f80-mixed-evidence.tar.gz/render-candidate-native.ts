import {createCanvas} from '@napi-rs/canvas';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {installHeadlessCanvas} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/recorder/record.ts';
import {drawWorld} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/client/unit-facing.ts';
const out='/tmp/knight-evacuation-6f80',sha=(b:any)=>createHash('sha256').update(b).digest('hex'),frames=JSON.parse(gunzipSync(readFileSync(out+'/candidate64800-68400-frames.json.gz')).toString());
installHeadlessCanvas();const records:any[]=[];
for(const [label,tick] of [['candidate-native-empty-transport-fight-65340',65340],['candidate-native-last-archer-65580',65580],['candidate-native-three-guards-dead-hall612-68400',68400]] as const){
 const f=frames.find((f:any)=>f.snapshot.tick===tick&&f.label==='sample');if(!f)throw Error('missing actual sample');const before=sha(JSON.stringify(f)),view={x:1750,y:2000,width:2100,height:1500,zoom:1.4},canvas=createCanvas(view.width,view.height);
 drawWorld({ctx:canvas.getContext('2d') as any,snapshot:f.snapshot,view,now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
 const png=canvas.toBuffer('image/png');writeFileSync(out+'/'+label+'.png',png);if(sha(JSON.stringify(f))!==before)throw Error('frame mutated');records.push({label,tick,view,snapshotSHA256:sha(JSON.stringify(f.snapshot)),pngSHA256:sha(png),fullInputUnchanged:true});
}
writeFileSync(out+'/candidate-native-render.json',JSON.stringify({classification:'Post-run native drawWorld renders of actual fixed-source candidate fullworlds. Not historical live captures, not reconstructed animation, no world edits or game commands.',source:'/tmp/sketch-rts-knight-evacuation-6f80-control',frameFileSHA256:sha(readFileSync(out+'/candidate64800-68400-frames.json.gz')),records},null,2));console.log(JSON.stringify(records));
