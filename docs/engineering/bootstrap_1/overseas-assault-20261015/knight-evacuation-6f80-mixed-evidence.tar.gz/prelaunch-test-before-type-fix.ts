import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {describe,expect,it} from 'vitest';
import {boardUnit} from '../../shared/decks';
import {sameGround,isWalkable} from '../../shared/terrain';
import {shipPassengers} from '../../shared/ship-geometry';
import type {GameSnapshot} from '../../shared/types';
import type {AiPolicyMemory} from '../memory';
import {bootstrapPolicyContext} from '../bootstrap_1/policy';
import {planNavalTactics} from './naval';

const boatId='unit-p0-transport-4873';
function input(tick:number) {
  return JSON.parse(gunzipSync(readFileSync(new URL(`./__fixtures__/knight-evacuation-6f80-${tick}.json.gz`,import.meta.url))).toString()) as {
    snapshot:GameSnapshot;nextId:number;memories:Record<string,AiPolicyMemory>;
  };
}
function plan(f:ReturnType<typeof input>) {
  return planNavalTactics(f.snapshot,'p0',bootstrapPolicyContext(f.snapshot,'p0','v9_knight',{
    memory:f.memories.p0!,teams:f.snapshot.teams,
  }));
}
function mission(f:ReturnType<typeof input>) {return f.memories.p0!.naval!.ferries![boatId]!;}
function stopsFor(f:ReturnType<typeof input>) {
  return plan(f).filter(c=>c.type==='stop').flatMap(c=>'unitIds'in c?c.unitIds:[]);
}
function waiting(f:ReturnType<typeof input>) {
  return f.snapshot.units.filter(u=>u.owner==='p0'&&!u.deck&&u.order.type==='board'&&u.order.transportId===boatId);
}

describe('actual empty evacuation waiting shore reassessment',()=>{
  it('keeps the original first valid evacuation and its actual wounded guards',()=>{
    const f=input(64605),before=JSON.stringify(f.snapshot);
    const commands=plan(f);
    expect(mission(f).purpose).toBe('evacuate');
    expect(mission(f).phase).toBe('loading');
    expect(commands.some(c=>c.type==='board'&&c.transportId===boatId&&c.unitIds.includes('unit-p0-footman-7014'))).toBe(true);
    expect(JSON.stringify(f.snapshot)).toBe(before);
  });
  it('keeps the real64800 withdrawal while three archers still exceed the original1.4 margin',()=>{
    const f=input(64800),ids=waiting(f).map(u=>u.id),before=JSON.stringify(f.snapshot),stops=stopsFor(f);
    expect(mission(f).phase).toBe('loading');
    expect(stops.filter(id=>ids.includes(id))).toEqual([]);
    expect(JSON.stringify(f.snapshot)).toBe(before);
  });
  it('releases the actual eight land boarders after the real threat falls below the original margin',()=>{
    const f=input(66000),ids=waiting(f).map(u=>u.id),before=JSON.stringify(f.snapshot);
    expect(ids).toHaveLength(8);
    const stops=stopsFor(f);
    expect(mission(f).phase).toBe('return');
    expect(mission(f).crewIds).toEqual([]);
    expect(stops.filter(id=>ids.includes(id)).sort()).toEqual(ids.sort());
    expect(JSON.stringify(f.snapshot)).toBe(before);
  });
  it('preserves actual passengers already aboard even when the empty-boat criterion would release the shore',()=>{
    const f=input(66000),boat=f.snapshot.units.find(u=>u.id===boatId)!,passenger=waiting(f)[0]!;
    // Synthetic boundary of the actual fixture: native deck placement creates
    // a real passenger. This is not an observed game outcome or battle result.
    expect(boardUnit(boat,passenger,f.snapshot.units)).toBe(true);
    passenger.order={type:'idle'};
    expect(shipPassengers(f.snapshot.units,boat)).toContain(passenger);
    const ids=waiting(f).map(u=>u.id),stops=stopsFor(f);
    expect(mission(f).phase).toBe('loading');
    expect(stops.filter(id=>ids.includes(id))).toEqual([]);
  });
  it('leaves an unobserved source unknown rather than inferring an island from the water waypoint',()=>{
    const f=input(66000),ids=waiting(f).map(u=>u.id);
    mission(f).crewIds=[];
    const stops=stopsFor(f);
    expect(mission(f).phase).toBe('loading');
    expect(stops.filter(id=>ids.includes(id))).toEqual([]);
  });
  it('does not declare inconsistent real source islands safe',()=>{
    const f=input(66000),anchor=waiting(f)[0]!,other=f.snapshot.units.find(u=>u.owner==='p0'&&!u.deck&&u.kind==='worker'
      &&isWalkable(f.snapshot.map,u.x,u.y)&&!sameGround(f.snapshot.map,anchor,u))!;
    expect(other).toBeDefined();
    other.order={type:'board',transportId:boatId};
    mission(f).crewIds.push(other.id);
    const ids=waiting(f).map(u=>u.id),stops=stopsFor(f);
    expect(mission(f).phase).toBe('loading');
    expect(stops.filter(id=>ids.includes(id))).toEqual([]);
  });
});
