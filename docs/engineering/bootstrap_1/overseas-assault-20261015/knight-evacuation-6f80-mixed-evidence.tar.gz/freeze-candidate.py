import hashlib,json,tarfile,io,subprocess,datetime
from pathlib import Path
r=Path('/tmp/sketch-rts-knight-evacuation-6f80-control');out=Path('/tmp/knight-evacuation-6f80');old=Path('/tmp/knight-colony-defense-6f80')
assert r.resolve()==r
base='6f80a9365e591cbfba9148260806cd4f9033788e'
assert subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip()==base
sha=lambda b:hashlib.sha256(b).hexdigest()
original=json.loads((old/'original-runtime-source.json').read_bytes());names={**original['runtimeHashes'],**original['supportingDataHashes']}
current={p:sha((r/p).read_bytes()) for p in names}
changed=[p for p in names if current[p]!=names[p]]
assert changed==['src/ai/policy/naval.ts'],changed
patch=subprocess.check_output(['git','-C',str(r),'diff','--','src/ai/policy/naval.ts']);(out/'production.patch').write_bytes(patch)
added=['src/ai/policy/naval-evacuation-reassessment.test.ts']+[f'src/ai/policy/__fixtures__/knight-evacuation-6f80-{t}.json.gz' for t in [64605,64800,66000]]
capsule=out/'candidate-source-capsule.tar.gz';files={}
with tarfile.open(old/'original-fixed-6f80-source-capsule.tar.gz','r:gz') as src,tarfile.open(capsule,'w:gz') as dest:
    for member in src.getmembers():
        if member.name=='INDEX.json':continue
        b=(r/member.name[5:]).read_bytes() if member.name.startswith('live/') else src.extractfile(member).read()
        member.size=len(b);dest.addfile(member,io.BytesIO(b));files[member.name]=sha(b)
    for name in added:
        b=(r/name).read_bytes();member=tarfile.TarInfo('live/'+name);member.size=len(b);dest.addfile(member,io.BytesIO(b));files[member.name]=sha(b)
    b=(json.dumps({'algorithm':'SHA-256','classification':'Actual candidate prelaunch immutable source capsule: original6f80 source with only naval evacuation reassessment production change,6case test and3 actual fixtures. Original frozen184 unchanged.','files':files},indent=2)+'\n').encode();member=tarfile.TarInfo('INDEX.json');member.size=len(b);dest.addfile(member,io.BytesIO(b))
with tarfile.open(capsule,'r:gz') as tf:
    assert set(tf.getnames())==set(files)|{'INDEX.json'}
    assert all(sha(tf.extractfile(n).read())==h for n,h in files.items())
frozen=(r/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes();assert sha(frozen)==original['frozenManifestSha256']
frozenManifest=json.loads(frozen);assert frozenManifest['rulesVersion']==2
manifest={'classification':'Actual prelaunch candidate source audit before64800to68400 native bothAI focused test; isolated changed-code continuation, not ordinary0.','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':str(r),'baseCommit':base,'productionChangedFiles':changed,'productionPatchSHA256':sha(patch),'runtimeSupportHashes':current,'addedTestAndFixtureHashes':{p:sha((r/p).read_bytes()) for p in added},'sourceCapsule':str(capsule),'sourceCapsuleSHA256':sha(capsule.read_bytes()),'sourceCapsuleAllPayloadsVerified':len(files),'frozenManifestSHA256':sha(frozen),'frozenRevision':frozenManifest['revision'],'frozenRulesVersion':2,'originalSourceManifestSHA256':sha((old/'original-runtime-source.json').read_bytes()),'testLogSHA256':sha((out/'focused-tests.log').read_bytes()),'driverSHA256':sha((out/'replay-empty-evacuation.ts').read_bytes()),'inputSHA256':sha((old/'complete-64800.json').read_bytes())}
(out/'candidate-prelaunch.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['runtimeSupportHashes','addedTestAndFixtureHashes']}))
