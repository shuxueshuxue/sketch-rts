import {readFileSync,writeFileSync} from 'node:fs';
import {sameGround,isWalkable} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/terrain.ts';
import {unitMover} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/catalog.ts';
import {combatCapability} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/combat-capabilities.ts';
import {strengthOf} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/v6/strength.ts';
import {shipPassengers} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/ship-geometry.ts';

const boatId='unit-p0-transport-4873',rows:any[]=[];
for(const tick of [64605,64800,66000,67200,68400]) {
  const f=JSON.parse(readFileSync(`/tmp/knight-colony-defense-6f80/complete-${tick}.json`,'utf8')),s=f.snapshot,m=f.memories.p0.naval?.ferries?.[boatId],before=JSON.stringify(f),boat=s.units.find((u:any)=>u.id===boatId);
  const own=s.units.filter((u:any)=>u.owner==='p0');
  const waiting=m?own.filter((u:any)=>m.crewIds.includes(u.id)&&!u.deck&&unitMover(u.kind)==='land'&&u.order.type==='board'&&u.order.transportId===boatId):[];
  const source=waiting.find((u:any)=>isWalkable(s.map,u.x,u.y));
  const consistent=!!source&&waiting.every((u:any)=>sameGround(s.map,source,u));
  const localOwn=own.filter((u:any)=>!u.deck&&unitMover(u.kind)==='land'&&!u.expiresTick&&(u.order.type!=='board'||u.order.transportId===boatId));
  const enemies=s.units.filter((u:any)=>u.owner==='p1'&&unitMover(u.kind)==='land'&&combatCapability(s,u).armed);
  const sources=waiting.map((a:any)=>{const local=localOwn.filter((u:any)=>sameGround(s.map,a,u)&&Math.hypot(u.x-a.x,u.y-a.y)<850),threat=enemies.filter((u:any)=>sameGround(s.map,a,u)&&Math.hypot(u.x-a.x,u.y-a.y)<700);return {sourceId:a.id,x:a.x,y:a.y,localIds:local.map((u:any)=>u.id),threatIds:threat.map((u:any)=>u.id),localStrength:strengthOf(local),threatStrength:strengthOf(threat),stillNeedsEvacuation:!!threat.length&&strengthOf(threat)>=1.4*strengthOf(local)};});
  rows.push({tick,mission:m,fromWalkable:m&&isWalkable(s.map,m.from.x,m.from.y),aboard:shipPassengers(s.units,boat).map((u:any)=>u.id),waitingIds:waiting.map((u:any)=>u.id),consistentActualLandSource:consistent,sources,knownEmptyEvacuationCanRelease:m?.purpose==='evacuate'&&m.phase==='loading'&&shipPassengers(s.units,boat).length===0&&consistent&&!sources.some((x:any)=>x.stillNeedsEvacuation),actualInputUnchanged:before===JSON.stringify(f)});
}
writeFileSync('/tmp/knight-evacuation-6f80/waiting-evacuation-query.json',JSON.stringify({classification:'Read-only reproduction of existing850/700/1.4 criterion using actual same-mission on-land waiting bodies. Unknown identity stays unknown; no game steps, no policy or world mutations, no commands issued.',rows},null,2));
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,phase:r.mission?.phase,aboard:r.aboard,waiting:r.waitingIds.length,consistent:r.consistentActualLandSource,range:r.sources.map((s:any)=>({local:s.localStrength,threat:s.threatStrength,needed:s.stillNeedsEvacuation})),release:r.knownEmptyEvacuationCanRelease,unchanged:r.actualInputUnchanged}))));
