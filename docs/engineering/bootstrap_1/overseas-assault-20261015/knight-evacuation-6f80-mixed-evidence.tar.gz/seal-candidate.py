from pathlib import Path
import hashlib,json,tarfile
out=Path('/tmp/knight-evacuation-6f80');archive=Path('/tmp/knight-evacuation-6f80-mixed-evidence.tar.gz')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={str(p.relative_to(out)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and p.name!='INDEX.json'}
(out/'INDEX.json').write_text(json.dumps({'algorithm':'SHA-256','classification':'Post-run mixed/negative actual empty-evacuation reassessment evidence. No wholematch/acceptance or merge claim. Every payload listed; INDEX intentionally excludes itself. Original prelaunch capsule preserved separately from post-run test-only type fix.','files':files},indent=2)+'\n')
with tarfile.open(archive,'w:gz') as tf:
  for name in [*files,'INDEX.json']:tf.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
  assert set(tf.getnames())==set(files)|{'INDEX.json'}
  index=json.load(tf.extractfile('INDEX.json'))
  for n,meta in index['files'].items():
    b=tf.extractfile(n).read();assert len(b)==meta['bytes'] and sha(b)==meta['sha256'],n
receipt={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payloadsVerified':len(files),'entriesVerified':len(files)+1,'nestedCandidateSourcePayloadsIndependentlyVerified':1374,'runtimeSupportVerified':870,'frozenManifestEntriesVerified':184,'jsonWorldNextIdBothMemAllCommandsAllHitsExact':True,'status':'Unmerged mixed/negative candidate; threeguardsdead,enemyarcher44HP,hall612stillunderattackat68400; nofullgameattempt'}
Path('/tmp/knight-evacuation-6f80-mixed-evidence-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
