from pathlib import Path
import hashlib,json,gzip,tarfile,subprocess,shutil,difflib
out=Path('/tmp/knight-evacuation-6f80');r=Path('/tmp/sketch-rts-knight-evacuation-6f80-control');old=Path('/tmp/knight-colony-defense-6f80')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda n:json.loads((out/n).read_bytes())
pre,native,restart,micro=map(load,['candidate-prelaunch.json','candidate64800-68400.json','json-cancellation-result.json','local-micro-query.json'])
assert r.resolve()==r
assert subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip()==pre['baseCommit']
runtimeChanges=[n for n,h in pre['runtimeSupportHashes'].items() if sha((r/n).read_bytes())!=h];assert not runtimeChanges
testChanges=[n for n,h in pre['addedTestAndFixtureHashes'].items() if sha((r/n).read_bytes())!=h]
assert testChanges==['src/ai/policy/naval-evacuation-reassessment.test.ts'],testChanges
production=subprocess.check_output(['git','-C',str(r),'diff','--','src/ai/policy/naval.ts']);assert sha(production)==pre['productionPatchSHA256']
with tarfile.open(out/'candidate-source-capsule.tar.gz','r:gz') as tf:
  index=json.load(tf.extractfile('INDEX.json'))
  assert len(index['files'])==1374 and set(tf.getnames())==set(index['files'])|{'INDEX.json'}
  assert all(sha(tf.extractfile(n).read())==h for n,h in index['files'].items())
  assert all(sha(tf.extractfile('live/'+n).read())==h for n,h in pre['runtimeSupportHashes'].items())
  frozen_bytes=tf.extractfile('frozen-policy.json').read();assert sha(frozen_bytes)==pre['frozenManifestSHA256'];frozen=json.loads(frozen_bytes)
  assert frozen['rulesVersion']==2 and len(frozen['files'])==184
  assert all(sha(tf.extractfile('frozen/'+n).read())==h for n,h in frozen['files'].items())
assert all(native['restored'].values()) and native['sourceChanges']==[]
assert all(restart['restore'].values()) and all(restart['equals'].values()) and restart['runtimeChanges']==[]
assert all(row['actualFullPlannerGuardCommandsEqualRecorded'] and row['fullOriginalInputUnchanged'] for row in micro['rows'])
for t in [64800,68400]:shutil.copyfile(old/f'complete-{t}.json',out/f'original-complete-{t}.json')
shutil.copyfile(old/'original-runtime-source.json',out/'original-runtime-source.json')
shutil.copyfile(old/'original-report-captured.json',out/'original-report-captured.json')
baseline=out/'original-naval.ts';baseline.write_bytes(subprocess.check_output(['git','-C',str(r),'show',pre['baseCommit']+':src/ai/policy/naval.ts']))
originalManifest=json.loads((out/'original-runtime-source.json').read_bytes());assert sha(baseline.read_bytes())==originalManifest['runtimeHashes']['src/ai/policy/naval.ts']
portable=out/'portable-review-files'
for name in pre['addedTestAndFixtureHashes']:
  p=portable/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,p)
shutil.copyfile(r/'src/ai/policy/naval.ts',out/'candidate-naval.ts')
before=(out/'prelaunch-test-before-type-fix.ts').read_text().splitlines(True);after=(r/'src/ai/policy/naval-evacuation-reassessment.test.ts').read_text().splitlines(True)
typefix=''.join(difflib.unified_diff(before,after,fromfile='prelaunch-test',tofile='portable-test'))
(out/'portable-test-type-fix.patch').write_text(typefix)
shutil.copytree('/tmp/knight-evacuation-6f80-incident',out/'operational-incident',dirs_exist_ok=True)
guardIds={'unit-p0-footman-'+str(i) for i in [7014,7043,7155]};attacks=[h for h in native['hits'] if h['sourceId'] in guardIds]
guardCommands=[e for e in native['issued'] if e['owner']=='p0' and guardIds.intersection(e['command'].get('unitIds',[]))]
facts={
 'classification':'Independent empty evacuation reassessment candidate with mixed/negative focused match evidence; retained unmerged. No wholematch run because this did not establish safe/effective defense.',
 'baseCommit':pre['baseCommit'],'sourceRoot':str(r),'rulesVersion':2,'frozenRevision':pre['frozenRevision'],'productionPatchSHA256':sha(production),'productionFileSHA256':sha((r/'src/ai/policy/naval.ts').read_bytes()),
 'sourceCapsuleSHA256':sha((out/'candidate-source-capsule.tar.gz').read_bytes()),'sourceCapsulePayloadsVerified':1374,'frozenManifestEntriesVerified':184,'runtimeSupportFilesVerified':870,'productionRuntimeChangesAfterPrelaunch':runtimeChanges,
 'postRunTestOnlyChange':{'path':testChanges[0],'prelaunchSHA256':pre['addedTestAndFixtureHashes'][testChanges[0]],'portableSHA256':sha((r/testChanges[0]).read_bytes()),'typeOnlyPatch':'portable-test-type-fix.patch','explanation':'Initial new test passed vitest but tsc failed exactOptional teams:undefined. After the actual native run only the test now conditionally spreads teams. Original prelaunch capsule retained unchanged; no production source changed. Portable6case retest and tsc both exited0.'},
 'native':{'start':native['start'],'end':native['end'],'restore':native['restored'],'sourceChanges':native['sourceChanges'],'firstPlanningDifferenceTick':native['firstPlanningDifferenceTick'],'winner':native['final']['snapshot']['match'].get('winner')},
 'firstDifference':{'tick':64935,'classification':'Actual old/new planner query on identical native preplan snapshot/nextId/fullbothmem. Original staysloading; candidate uses originalcancelFerry publicstop/return. Baseline query did not step a second game or issue commands.'},
 'terminalColonyHall':next((b for b in native['final']['snapshot']['buildings'] if b['id']=='building-p0-townHall-1750'),None),
 'guardNativeAttacks':{'hitCount':len(attacks),'rawDamageIncludingOverkill':sum(h['damage'] for h in attacks),'actualHpRemoved':sum(min(h['before'],h['damage']) for h in attacks),'emptyEnemyTransportHits':len([h for h in attacks if h['targetId']=='unit-p1-transport-1502']),'permanentArchersHits':len([h for h in attacks if h['targetKind']=='sparkArcher']),'lethalEnemyHits':[h for h in attacks if h['after']<=0]},
 'guardNativeDeaths':[h for h in native['hits'] if h['targetId'] in guardIds and h['after']<=0],
 'actualGuardCommands':{'move':len([e for e in guardCommands if e['command']['type']=='move']),'attackMove':len([e for e in guardCommands if e['command']['type']=='attackMove']),'stop':len([e for e in guardCommands if e['command']['type']=='stop']),'explicitAttackEnemyTransport':[e for e in guardCommands if e['command'].get('targetId')=='unit-p1-transport-1502'],'resumeOrdersBeforeFirstNativeBoatHit':[e for e in guardCommands if 65190<=e['tick']<=65250]},
 'nativeEvents':native['events'],'jsonRestart':{'start':restart['start'],'end':restart['end'],'restore':restart['restore'],'equals':restart['equals'],'runtimeChanges':restart['runtimeChanges']},
 'actualContextQueries':{'samples':len(micro['rows']),'allFullPlannerGuardCommandsMatchNative':True,'allInputWorldAndBothMemoriesUnchanged':True,'allContextVersions':[row['context'] for row in micro['rows']]},
 'validation':{'newPrelaunchBoundaryTests':'6/6 pass','broadRelevantTests':'111/112 pass; one coordinated nearby-convoy test fails','unchanged6f80SingleConvoyCountercheck':'Same test also fails on unchanged6f80;1failed8filteredskipped. Raw logs preserved; no candidate regression inferred or allgreen claim.','initialTsc':'failed only newtest TS2379 teams undefined','portableTsc':'exit0','portableNewBoundaryRetest':'6/6 pass','staticReview':'Read-only child review found no blocking contract issue; review text separately included. Actual negative outcome outweighs local static/test green.'},
 'limits':['Changed-code continuation from original64800, not trueordinary0 or complete-match win evidence.','68400hall612 remains under archer1121attack, guardsall3dead, fiveworkersidle, gold3.19. Original68400hallgone with threeguardsalivewaitingboard. Trade-off is not a proven successful repair; no fullgame/acceptance claim.','No focus odds/health/join threshold was weakened. Query confirms versionv2 path active; initial eligiblefighters too distant for hybrid meleecontact, later unmedicated reserves and36percenthealth limit focus.','Enemy transport was a native automatic attackMove target, not an explicit attack1502 planner command. Wounded-care coverage drops outside immediate threats; do not attribute all12hits to a dead focus gate.','Original ordinary worktree sparse/disk incident is preserved in operational-incident; postmatchinghashes do not prove no transient fileavailability/diskpressure effects on original ongoing match. These preincident original inputs and the read-only diagnosis archive were already captured/sealed before the incident; candidate run started afterrootrecovery.','Original old-container uncommitted modifications remain unrecovered. No root/main production source changes, opponent nerfs or rules3 adoption.']
}
(out/'candidate-audit.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'candidateProductionSHA256':facts['productionFileSHA256'],'runtimeChanges':runtimeChanges,'sourceCapsulePayloadsVerified':1374,'frozenVerified':184,'jsonEquals':restart['equals'],'postRunTestOnlyChange':facts['postRunTestOnlyChange'],'actualGuardAttacks':facts['guardNativeAttacks']},ensure_ascii=False))
