import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {isDeepStrictEqual} from 'node:util';
import {bootstrapPolicyContext} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/bootstrap_1/policy.ts';
import {planAiOwnerCommandEntries} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/planner-context.ts';
import {planLandedCombat} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/bootstrap_1/landed-combat.ts';
import {landRecoveryAssignments} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/bootstrap_1/land-recovery.ts';
import {planFocusFireCommand} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/spell-tactics.ts';
import {activeUnitClaim} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/claims.ts';
import {enemyCombatUnits} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/snapshot.ts';
import {armyPower} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/combat-math.ts';
import {sameGround,walkingDistance} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/terrain.ts';
import {weaponRules} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/equipment.ts';
import {strikeGap} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/combat-geometry.ts';
import {unitMover} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/catalog.ts';
import {canReach} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/naval.ts';
import {isV5HybridPolicy} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/policy/versions.ts';

const out='/tmp/knight-evacuation-6f80',norm=(v:any)=>JSON.parse(JSON.stringify(v));
const frames=JSON.parse(gunzipSync(readFileSync(out+'/candidate64800-68400-frames.json.gz')).toString()),native=JSON.parse(readFileSync(out+'/candidate64800-68400.json','utf8'));
const guards=new Set(['unit-p0-footman-7014','unit-p0-footman-7043','unit-p0-footman-7155']),rows:any[]=[];
for(const tick of [64980,65100,65160,65220,65280,65340,65400,65520,65580,65700,66000]){
  const f=frames.find((f:any)=>f.snapshot.tick===tick&&f.label==='sample');if(!f)throw Error('actual frame missing '+tick);
  const s=f.snapshot,before=JSON.stringify(f),memory=structuredClone(f.memories.p0),options=bootstrapPolicyContext(s,'p0','v9_knight',{memory,teams:s.teams}),home=s.buildings.find((b:any)=>b.owner==='p0'&&b.kind==='townHall');
  const landed=s.units.filter((u:any)=>u.owner==='p0'&&!u.deck&&unitMover(u.kind)==='land'&&u.kind!=='worker'&&u.order.type!=='board'&&!sameGround(s.map,u,home));
  const care=landRecoveryAssignments(s,'p0',options,landed),reserved=new Set([...care.recovering.flatMap((c:any)=>[c.patient.id,c.healer.id]),...care.unmedicated.map((c:any)=>c.patient.id),...care.posts.map((c:any)=>c.patient.id)]);
  const group=landed.filter((u:any)=>guards.has(u.id));
  const foes=enemyCombatUnits(s,'p0',options.teams).filter((u:any)=>sameGround(s.map,u,{x:2288,y:2736}));
  const canJoin=(fighter:any,target:any)=>sameGround(s.map,fighter,target)&&walkingDistance(s.map,fighter,target,'land')!==undefined&&strikeGap(fighter,target)>=(weaponRules(s,fighter).weapon?.minRange??0);
  const details=group.map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,hpShare:u.hp/u.maxHp,healthPasses36Percent:u.hp>=u.maxHp*.36,activeClaim:activeUnitClaim(s,'p0',u,options),order:u.order,unmedicated:care.unmedicated.some((p:any)=>p.patient.id===u.id),recovering:care.recovering.some((p:any)=>p.patient.id===u.id),postCare:care.posts.some((p:any)=>p.patient.id===u.id),careUnavailable:reserved.has(u.id),foes:foes.map((e:any)=>({id:e.id,hp:e.hp,distance:Math.hypot(u.x-e.x,u.y-e.y),scopeLandJoin:canJoin(u,e),hybridMeleeAlreadyAtTarget:canReach(s.map,u,e)&&Math.hypot(u.x-e.x,u.y-e.y)<=u.attackRange+u.radius+e.radius}))}));
  const army=group.filter((u:any)=>!reserved.has(u.id));
  const directFocus=planFocusFireCommand(s,'p0',{...options,memory:structuredClone(f.memories.p0)},{army,enemies:foes,canJoinTarget:canJoin});
  const landedCommands=planLandedCombat(s,'p0',{...options,memory:structuredClone(f.memories.p0)},reserved).filter((c:any)=>'unitIds'in c&&c.unitIds.some((id:string)=>guards.has(id)));
  const actualEntries=planAiOwnerCommandEntries(s,{playerId:'p0',version:'v9_knight',memory:structuredClone(f.memories.p0)},{teams:s.teams}).filter((e:any)=>'unitIds'in e.command&&e.command.unitIds.some((id:string)=>guards.has(id))).map((e:any)=>({scriptId:e.scriptId,command:e.command}));
  const actualIssued=native.issued.filter((e:any)=>e.tick===tick&&e.owner==='p0'&&e.command.unitIds?.some((id:string)=>guards.has(id))).map((e:any)=>({scriptId:e.scriptId,command:e.command}));
  rows.push({tick,context:{version:options.version,requestedVersion:options.requestedVersion,isV5Hybrid:isV5HybridPolicy(options)},guards:details,careUnmedicated:care.unmedicated.filter((p:any)=>guards.has(p.patient.id)).map((p:any)=>({id:p.patient.id,cover:p.cover,threatIds:p.threats.map((u:any)=>u.id)})),eligibleArmyBeforeKiting:army.map((u:any)=>u.id),focusQueryResult:directFocus,landedCommandsWithActualCareReservation:landedCommands,actualFullPlannerEntries:actualEntries,actualIssued,actualFullPlannerGuardCommandsEqualRecorded:isDeepStrictEqual(norm(actualEntries),norm(actualIssued)),enemyCombatTargets:foes.map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,power:armyPower([u])})),localPowerOfCareAvailableGuards:armyPower(army),emptyEnemyTransport:s.units.find((u:any)=>u.id==='unit-p1-transport-1502'),fullOriginalInputUnchanged:before===JSON.stringify(f)});
}
writeFileSync(out+'/local-micro-query.json',JSON.stringify({classification:'Read-only queries of actual post-release native candidate checkpoints with full memory/context. Full planner guard commands are compared with recorded actual commands. Direct focus is a component query using care-available guards before ranged-kiting occupancy, not a claim to have called private focus internals.36%health,activeclaim,real land callback and hybrid melee-contact gates are exposed without relaxing them; no forced focus or game steps.',rows},null,2));
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,context:r.context,guards:r.guards.map((u:any)=>({id:u.id,hp:u.hp,hp36:u.healthPasses36Percent,care:u.careUnavailable,claim:u.activeClaim?.kind,joins:u.foes.map((e:any)=>({id:e.id,land:e.scopeLandJoin,contact:e.hybridMeleeAlreadyAtTarget}))})),focus:r.focusQueryResult,local:r.landedCommandsWithActualCareReservation,full:r.actualFullPlannerEntries,actualMatches:r.actualFullPlannerGuardCommandsEqualRecorded,unchanged:r.fullOriginalInputUnchanged}))));
