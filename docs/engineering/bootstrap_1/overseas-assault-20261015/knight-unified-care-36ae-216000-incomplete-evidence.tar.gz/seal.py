from pathlib import Path
import hashlib, json, tarfile, datetime

out = Path('/workspace/.playtest/knight-unified-care-36ae')
archive = out.parent/'knight-unified-care-36ae-216000-incomplete-evidence.tar.gz'
sealpath = out.parent/'knight-unified-care-36ae-216000-seal.json'
def sha_file(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

post = json.loads((out/'final-source-postflight.json').read_bytes())
assert not post['candidateSourceChanges'] and not post['old129158SourceChanges']
assert post['winner'] is None and post['finalTick'] == 216000
assert post['segmentBoundaryCompleteWorldIdBothMemEqual']
assert post['allStrictJSONWorldIdBothMemCommandsHitsDeathsAsApplicableEqual']
files = {p.relative_to(out).as_posix(): {'sha256': sha_file(p), 'bytes': p.stat().st_size}
         for p in sorted(out.rglob('*'))
         if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and p.name != 'INDEX.json'}
index = {'classification': 'Immutable independent36ae+unifiedfinitecare216000 unfinished negative; not ordinary0, no winner, no acceptance. Actual stages64800→68400→144000→216000; no further horizon after proved72k strategic stagnation. New root0f5bf timeout-witness is a separate future source, not this result.', 'created': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceRoot': '/tmp/sketch-rts-knight-unified-care-36ae-control', 'payloadCount': len(files), 'files': files, 'excludedSymlinks': ['node_modules'], 'indexSelfHash': 'External archive SHA covers INDEX; INDEX does not hash itself.'}
(out/'INDEX.json').write_text(json.dumps(index, indent=2, ensure_ascii=False)+'\n')
with tarfile.open(archive, 'w:gz', compresslevel=6) as t:
    for name in list(files)+['INDEX.json']:
        t.add(out/name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert set(t.getnames()) == set(files) | {'INDEX.json'}
    assert json.load(t.extractfile('INDEX.json')) == index
    for name, expected in files.items():
        body = t.extractfile(name).read()
        assert len(body) == expected['bytes'] and hashlib.sha256(body).hexdigest() == expected['sha256'], name
        assert sha_file(out/name) == expected['sha256'], name
seal = {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha_file(archive), 'verifiedPayloads': len(files), 'verifiedTarEntries': len(files)+1, 'indexSHA256': sha_file(out/'INDEX.json'), 'sealedTime': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Actual216000 unfinished negative. Local3guard preservation/hall900 not victory: originalfirst expedition6 deck+2shore deaths,13 later ownpermanentlosses,enemy15b alive. Final72k no births/deaths/mining/expansion/enemybuildinghits;16 friendlycollisionhits only. Exactemptydonor predicate shared with root0f5bf; no fulltrajectory equality claim. Strict three JSON windows/fullsource capsule/frozen184 verified; original uncommitted work gap retained.', 'sourceCapsuleSHA256': post['capsuleSHA256'], 'original129158ArchiveUnchangedSHA256': post['old129158ArchiveSHA256']}
sealpath.write_text(json.dumps(seal, indent=2)+'\n')
print(json.dumps(seal, indent=2))
