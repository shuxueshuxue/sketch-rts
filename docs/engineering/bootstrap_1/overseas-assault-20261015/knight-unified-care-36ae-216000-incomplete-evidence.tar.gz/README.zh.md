# 36ae50c6 统一有限护理组合

本轮独立源码位于 `/tmp/sketch-rts-knight-unified-care-36ae-control`，固定基线为 `36ae50c6b41bfcdd9a1144f685ece942b689c5e4`。只加入原 empty/loading 撤离复评、typed 有限恢复腿和隔水武器旧目标判断。生产差异仅三文件：naval 27行（24增3删），memory 2行，expedition-recovery 87行；没有整文件覆回6f80。其余1253个现有src文件逐字节保留，包括root当前land-recovery。root的released/workerAvailable、targetGround、escort、shore transfer和已提交worker/workforce逻辑均保留。没有引入旧naval其它hunk、457旧源、queued hold、新owner、TTL或满血锁。

`root-to-unified-production.patch` 是相对当前root提交的精确三文件增量，SHA256 `7afd0c48bfd8ead44d616eb2e5114ea3f7a0e607efd9f62d8c1b2eac8fe9b6fa`。`3bdb-to-unified-production.patch` 展示从3bdb到本组合的完整生产差异，包含root后续行为，不能把这些差异全部归因于本次护理。`root-to-unified-all.patch` 还带10个便携测试/实档fixture文件，二进制以Git binary patch保留；对应源码包1615 payload全部SHA读回复验，源manifest1430文件。冻结manifest仍规则2、184文件、相同已验证冻结策略；没有更改对手资源、人口或生产API。

两批独立测试140/140通过；最终tsc exit0。mounted-pose契约已核原生spawn由真实shipMounts创建炮位，transferRefusal校验实际合法mount/native也使用mountedWeaponPose非空断言。115个原真实完整frame共345个已安装炮位查询均有效且pure。此契约针对支持的原生生命周期；restore并非任意坏JSON的通用净化器，未盲加防御fallback。

隔水边界针对当前普通工作武器及既有径向think风险；跨岛cap.range gate不保证覆盖普通武器射程外的雷杖/法术。同岛分支保留既有risk，不声称完整原生攻击许可。船炮不预测后续转艏或动态遮挡改变。route_status_recovery仅只读审阅上一轮boundary和原生API，未看到这两批准边界的具体阻断；它没有独立运行，也未审阅本轮三文件整合，不列为整合验证通过。

## 真实64800→68400窗口

同原64800完整world、nextId、双方全部mem切换到本组合，普通v9_knight Grove对正常冻结v5 Ember，原官方sapphire地图与种子不变。实际3601逐tick完整state/mem SHA、103完整frame、双方132命令和162条全图native hit均保存。终大厅900，三兵仍生：7014为67/210 level0，7043为1/210 level0，7155为96/350 level2。没有把最大HP/等级变化猜成医疗。

与旧6f80正例不全等：3600/3601tick摘要不同，世界/nextId/双方全mem/命令/hits均明确不同。首实际命令差64800：root worker安全释放stop1657以及warship1935移动；首保存完整差异帧64860保留targetGround新增、crewIds及nextId等真实字段差。`focus-comparison.json`保存完整字段和命令组；没有删字段声称相同。旧组合终兵130/37/71，不能借其129158胜局给新组合。

103完整frame上的恢复owner连续纯查询均不改world/mem。实际65280的7014/7155已按原生到达释放恢复owner并自动攻击空船；7043仍走未完腿，后续到达释放，65400 typed表清空。保留原.35，非.36；没有到达后hold或永久等待治疗。实际击毁空运输1502的是7155，不能把其空船伤害解释为守军始终有效集火陆军。完整hits/死亡和本岛损失仍保留：原塔2001在64958被毁，3防守兵未死，5个敌永久单位死亡含该空船（此前乘员0）。

三兵的关键窗HP账全部闭合：7014为93−26=67，7043为100−99=1，7155为89−133+140最大HP成长=96，native全伤害ledger的余量均为0。`focus-hp-xp-accounting.json`保留完整输入、命中与采样等级变化；该窗口不需要医疗增量来解释HP，7155的等级成长不能记作治疗。

从真实65220保存frame冷JSON正常双方续到65400：初始world/id/双方mem严格恢复，终world/id/双方mem、全部24命令、23全图hits及本岛hits六项完全一致。原frame无65190，错误选择未有存档的65190导致分析StopIteration和一次ENOENT，均在任何游戏step之前；没有伪造preplan输入，原log及errata保留。

两张PNG由本固定源码真实client drawWorld绘制实际65280/68400保存world，已本人目视；后渲染不是历史live capture，没有修改存档或推进额外游戏。

## 续局和限制

同68400完整world/nextId/双方mem已恢复，用同一固定组合正常双方AI续自然比赛，prefix为continuation68400-natural。原144000无胜后已同码继续到216000。新段已证明战略停滞，按父会话的真实停滞封存授权保留未完档；没有再盲抬horizon，未写自然winner。此为64800换码、68400同码分段续局，不是普通0，不是当前root其它分支成绩。三条路线、v5/v7/v8单对手与六配对、官方地图和未见种子的最终完整比赛/泛化验收仍未完成。原容器未提交改动恢复缺口继续保留。

独立新tree以官方sparse机制建成15MB，未展开docs档案；最初no-checkout的空index在检查处停，确认effective sparse=true后read-tree初始化，没有重现ENOSPC或手改common config。首harness因缺type:module在tsx transform前失败；补harness-only package后又因cwd在Git外导致frozen git archive失败，仅完成restore/prelaunch、未think/step；保留原log/prelaunch，改用绝对candidate工作目录才有真实49617窗口。固定生产源/driver/capsule均未因此改写。所有本轮输出在workspace独立.playtest，root/main及既有固定source/档案未改。


## 完整续局负例与216000未完阻塞

68400→144000实际双方AI续局无胜者、无任何毁楼，敌15楼/大厅900仍在。新增本方13永久损失、敌4永久损失与4临时spirit损失、中立3损失。零本方永久损失只属于64800→68400窗口，不能套到全场。三兵保全与后续HP恢复未形成整场胜利；该组合未通过完整比赛验收。

原生88800→90000首波损失尤需保留：4699甲板上实际死亡的有弩炮3111、牧师1747、三名lancer1275/1110/1071和骑士3336；另外2955、1224死亡前已在岸上。此1200窗仅一次对敌船坞的13HP溅射，没有拆楼。437条issuedcommands、523全图hits、9个原生死亡，与独立冷JSON完整世界/id/双方mem全部闭合。真实88800/90000 client图已目视。2955/1224首离甲板的精确tick未记录，不能从死亡或两端帧伪造；已交ordinary_summoner只读调查原生自动跨岸因果，不重复新全局。

144000→216000的61完整1200周期frame明确：11永久战斗兵数量不变；无任何本方永久新生、任何单位死亡、扩建、毁楼或对敌建筑命中；所有周期采矿worker为0。金76.19→68.19，累计支出仅15565→15573；13个有余矿的矿点与矿量完全未变，均无本方陆上worker在同一陆地component。组件同岛不是安全道路证明。全段16 native hits全部p0友军碰撞，没有对敌攻击。不是整世界bitwise循环：船体、heading、时钟、mission和少量碰撞伤害仍变化，完整raw全部保留。

216000精确component查询显示6933仍assault/loading，真实5人在甲板（4永久非worker陆军+工人1664），progress停在148200，龄67800超过原800tick门槛，船心/船首移动0而旧crew字串相同；唯一续等donor为同target/loading的4699，progress龄15，真实cargo空、永久战斗0。1046仅有worker1774也被该donor续等。实际assaultExpedition要求15.798005524588689，候选总分15.048867013595931、ready=false，未改门槛。由此同时保留首波兵损后的军力/资本不足与共同core空donor问题，不能把cancel视为能打赢。

同一真实216000完整world/id/bothmem下，转译并执行plain36ae、unified36ae、root0f5bf与随后观察到root1453的原progress/timeout源码片段：片段SHA相同、均不refresh/cancel、输入均未变。root0f5bf/1453在naval.ts717–731，调用在619；unified仅被新evac前插偏移到734–748。新evac只处理evacuate+empty，对实际assault+loaded不生效。此只证明组件共享；root后来另有ship-collisions/avoidance变化，不能冒称全planner、完整native轨迹或普通0等值。

最后214800→216000严格冷JSON复现完整world、nextId、双方mem、全部4命令、0hits、0death六项相等。原固定216000档、所有分段的完整双方mem、source capsule、first-expedition负例及donor组件将永久保留。下一timeout-witness候选另起root0f5bf新control，完全不带本组合，不能混淆本包成绩。
