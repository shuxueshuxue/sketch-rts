from pathlib import Path
import json, subprocess, hashlib, datetime, tarfile, gzip

out = Path('/workspace/.playtest/knight-unified-care-36ae')
src = Path('/tmp/sketch-rts-knight-unified-care-36ae-control')
repo = '/workspace/sketch-rts-bootstrap-resume'
sha = lambda b: hashlib.sha256(b).hexdigest()
p = json.loads((out/'timeout-component-root-comparison.json').read_bytes())
checks = []
for f in ['src/shared/ship-geometry.ts', 'src/shared/ship-navigation.ts', 'src/shared/time.ts', 'src/ai/policy/spatial.ts']:
    live = (src/f).read_bytes()
    other = subprocess.check_output(['git', '-C', repo, 'show', p['requestedRoot']+':'+f])
    checks.append({'path': f, 'fixedSHA256': sha(live), 'root0f5bfSHA256': sha(other), 'same': live == other})
assert all(c['same'] for c in checks)
p['componentDirectHelperSources'] = checks
p['helperCheckActualTime'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'timeout-component-root-comparison.json').write_text(json.dumps(p, indent=2))
pre = json.loads((out/'candidate-prelaunch.json').read_bytes())
changes = [f for f, h in pre['sourceHashes'].items() if sha((src/f).read_bytes()) != h]
assert not changes
assert subprocess.check_output(['git', '-C', str(src), 'rev-parse', 'HEAD']).decode().strip() == pre['baseCommit']
with tarfile.open(out/'candidate-source-capsule.tar.gz', 'r:gz') as t:
    index = json.load(t.extractfile('INDEX.json'))
    assert len(index['files']) == 1615 and set(t.getnames()) == set(index['files']) | {'INDEX.json'}
    for f, h in index['files'].items():
        assert sha(t.extractfile(f).read()) == h, f
    frozen = json.load(t.extractfile('frozen-policy.json'))
    assert frozen['rulesVersion'] == 2 and len(frozen['files']) == 184
    assert all(sha(t.extractfile('frozen/'+f).read()) == h for f, h in frozen['files'].items())
a = json.loads((out/'focus64800-68400-final.json').read_bytes())
b = json.loads((out/'continuation68400-natural-final.json').read_bytes())
c = json.loads((out/'continuation144000-natural-final.json').read_bytes())
f1 = json.loads(gzip.decompress((out/'continuation68400-natural-frames.json.gz').read_bytes()))
f2 = json.loads(gzip.decompress((out/'continuation144000-natural-frames.json.gz').read_bytes()))
assert a == f1[0] and b == f2[0]
for name in ['json65220-65400-comparison.json', 'json88800-90000-comparison.json', 'json214800-216000-comparison.json']:
    assert all(json.loads((out/name).read_bytes())['equals'].values()), name
assert c['snapshot']['tick'] == 216000 and c['snapshot']['match']['winner'] is None
oldarchive = Path('/tmp/knight-recovery-waypoint-6f80-win-evidence.tar.gz')
assert sha(oldarchive.read_bytes()) == '4888e582368bfc164af2c141caa853e62796bda94341ab942dc6330704477654'
oldpre = json.loads(Path('/tmp/knight-recovery-waypoint-6f80/candidate-prelaunch.json').read_bytes())
oldsrc = Path(oldpre['sourceRoot'])
oldchanges = [f for f, h in {**oldpre['runtimeSupportHashes'], **oldpre['addedTestAndFixtureHashes']}.items() if sha((oldsrc/f).read_bytes()) != h]
assert not oldchanges
result = {'classification': 'Final postflight of fixed36ae unifiedcare216000 unfinished negative. No naturalwinner or acceptance. Newtimeout candidate must be separate.', 'actualTime': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': pre['baseCommit'], 'sourceFilesVerified': len(pre['sourceHashes']), 'candidateSourceChanges': changes, 'capsulePayloadsVerified': 1615, 'capsuleSHA256': sha((out/'candidate-source-capsule.tar.gz').read_bytes()), 'frozenRulesVersion': 2, 'frozenEntriesVerified': 184, 'old129158SourceChanges': oldchanges, 'old129158ArchiveSHA256': sha(oldarchive.read_bytes()), 'segmentBoundaryCompleteWorldIdBothMemEqual': True, 'finalTick': 216000, 'winner': None, 'strictJSONWindows': ['65220→65400', '88800→90000', '214800→216000'], 'allStrictJSONWorldIdBothMemCommandsHitsDeathsAsApplicableEqual': True, 'allComparedTimeoutComponentsSame': p['allExactComponentsSame'], 'root0f5bfDirectQueryHelpersUnchanged': True, 'sameComponentDoesNotClaimFullNativeTrajectoryEqual': True, 'remaining': 'No victorious newgame; strategic idle/noincome/noeffectiveassault72k. Originaluncommittedcontainer work unrecovered.'}
(out/'final-source-postflight.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
