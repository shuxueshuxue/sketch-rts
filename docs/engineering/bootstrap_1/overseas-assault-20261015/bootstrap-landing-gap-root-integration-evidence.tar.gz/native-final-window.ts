import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

const source = '/workspace/sketch-rts-bootstrap-resume';
const directory = '/tmp/bootstrap-root-gap-integration-20261015';
const prefix = '/tmp/bootstrap-root-3bdb-ordinary0-20261015/ordinary';
const norm = (value: any) => JSON.parse(JSON.stringify(value));
const sha = (value: any) => createHash('sha256').update(value).digest('hex');
const paths = execFileSync('git', ['-C', source, 'ls-files', 'src', 'scripts', 'package.json', 'package-lock.json', 'tsconfig.json',
  'docs/engineering/bootstrap_1/frozen-policy.json'], { encoding: 'utf8' }).trim().split('\n');
const hashes = Object.fromEntries(paths.map(path => [path, sha(readFileSync(source + '/' + path))]));
const initialDiff = execFileSync('git', ['-C', source, 'diff', 'HEAD', '--', 'src', 'scripts'], { encoding: 'utf8' });
if (!initialDiff.includes('const gap=distanceToHull(transport,p)') || initialDiff.split('diff --git ').length !== 2) throw Error('Unexpected production diff');
const base = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
const verify = () => { const changed = paths.filter(path => sha(readFileSync(source + '/' + path)) !== hashes[path]);
  if (changed.length) throw Error('Source changed while native validation ran'); return { files: paths.length, changed }; };
const preflight = verify();
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { runAiGameLoop }] = await Promise.all([imp('src/ai/bootstrap_1/benchmark.ts'),
  imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'), imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts')]);
const report = JSON.parse(readFileSync(prefix + '.json', 'utf8'));
const input = JSON.parse(readFileSync(prefix + '.json.frames/33600.json', 'utf8'));
const expected = JSON.parse(readFileSync(prefix + '.json.frames/33688.json', 'utf8'));
const expectedReplay = JSON.parse(readFileSync('/tmp/bootstrap-root-3bdb-ordinary0-20261015/final-replay-33600-33688.json', 'utf8'));
const row = report.rows.find((row: any) => row.tick === 33600), endRow = report.rows.find((row: any) => row.tick === 33688);
const match = bootstrapMatches(report.setup.seed, [report.setup.map], 33688, report.setup.unseen).find((m: any) =>
  m.subject === report.subject && m.side === report.setup.side && m.agents.p0.race === report.setup.agents.p0.race
  && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v8');
const game = bootstrapGame(match), memories = createAiMemoryProvider();
restoreSnapshotIntoGame(game, input.snapshot, input.nextId);
for (const [owner, player] of Object.entries(row.players) as any[]) memories.set(owner, structuredClone(player.policy));
const full = () => norm({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner)])) });
const restored = full(), startMem = norm(Object.fromEntries(Object.entries(row.players).map(([o, p]: any) => [o, p.policy])));
const restore = { world: isDeepStrictEqual(restored.snapshot, input.snapshot), nextId: restored.nextId === input.nextId,
  allMemories: isDeepStrictEqual(restored.memories, startMem) };
if (Object.values(restore).some(value => !value)) throw Error('Full actual start differs');
const commands: any[] = [], planner = await createBootstrapCommandPlanner(memories);
runAiGameLoop({ ...match, game, commandPlanner: planner }, { onCommand(event: any) {
  commands.push(norm({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command }));
} });
const final = full(), expectedMem = norm(Object.fromEntries(Object.entries(endRow.players).map(([o, p]: any) => [o, p.policy])));
const reproduction = { world: isDeepStrictEqual(final.snapshot, expected.snapshot), nextId: final.nextId === expected.nextId,
  allMemories: isDeepStrictEqual(final.memories, expectedMem), allCommands: isDeepStrictEqual(commands, expectedReplay.commands) };
const result = { classification: 'Root integration of pure landing gap reuse, observer-only native33600→33688 equivalence against actual3bdb ordinary0 ending. Not a new complete match or AI tactical improvement.',
  base, source, initialDiff, hashes, preflight, postflight: verify(), restore, reproduction, commands,
  result: { tick: game.tick, winner: game.match.winner } };
writeFileSync(directory + '/native-final-window.json', JSON.stringify(result));
writeFileSync(directory + '/native-final-window-final.json', JSON.stringify(final));
console.log(JSON.stringify({ restore, reproduction, result: result.result }));
if (Object.values(reproduction).some(value => !value)) throw Error('Native equivalence failed');
