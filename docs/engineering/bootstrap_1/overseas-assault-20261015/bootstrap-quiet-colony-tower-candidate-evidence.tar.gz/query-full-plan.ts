import {readFileSync,writeFileSync} from 'node:fs';import{pathToFileURL}from'node:url';
const root='/tmp/sketch-rts-colony-capital-control';
const {createGame,restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(root+'/src/shared/sim.ts').href);
const {bootstrapPolicyContext,bootstrapScripts}=await import(pathToFileURL(root+'/src/ai/bootstrap_1/policy.ts').href);
const {rankBootstrapGoals,planBootstrapEconomy}=await import(pathToFileURL(root+'/src/ai/bootstrap_1/economy.ts').href);
const {planAiOwnerCommandEntries}=await import(pathToFileURL(root+'/src/ai/planner-context.ts').href);
const saved=JSON.parse(readFileSync('/tmp/bootstrap-neutral-miners-b0/actual-before-37230.json','utf8'));const out:any={};
for(const mode of ['economy','full','full-then-economy']){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),memory=structuredClone(saved.memories.p0);
 const context=()=>bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory,teams:game.teams});
 if(mode==='economy')out[mode]=planBootstrapEconomy(snapshot,'p0',context());
 else{out[mode]=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_summoner',memory},{teams:game.teams});if(mode==='full-then-economy')out['economy-after-full']=planBootstrapEconomy(snapshot,'p0',context());}
}
out.scripts=bootstrapScripts('v9_summoner').map((s:any)=>({id:s.id,runName:s.run.name}));writeFileSync('/tmp/bootstrap-neutral-miners-b0/query-full-plan.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
