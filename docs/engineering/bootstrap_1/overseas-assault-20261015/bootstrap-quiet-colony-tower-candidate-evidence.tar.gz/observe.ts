import{readFileSync,writeFileSync}from'node:fs';
import{createHash}from'node:crypto';
import{execFileSync}from'node:child_process';
import{pathToFileURL}from'node:url';
import{parseArgs}from'node:util';
const{values}=parseArgs({options:{source:{type:'string'},report:{type:'string'},capsule:{type:'string'},from:{type:'string'},end:{type:'string'},out:{type:'string'}}});
const source=values.source!,reportPath=values.report!,from=Number(values.from),end=Number(values.end),out=values.out!;
if(!source||!reportPath||!out||!Number.isInteger(from)||end<=from||end-from>60)throw new Error('A complete input and native window of 1..60ticks are required');
const cap=JSON.parse(readFileSync(values.capsule!,'utf8')),hashes={...cap.runtimeHashes,...cap.supportingDataHashes};
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const verifySource=()=>{const diff=Object.entries(hashes).filter(([name,digest])=>sha(readFileSync(source+'/'+name))!==digest).map(([name])=>name);if(diff.length)throw new Error('Source changed: '+diff.join(','));if(execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim()!==cap.baseCommit||execFileSync('git',['status','--porcelain','--untracked-files=normal'],{cwd:source,encoding:'utf8'}))throw new Error('Source not clean/fixed');return{count:Object.keys(hashes).length,mismatches:diff};};
const preSource=verifySource();
const{bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const{restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const{createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const{createBootstrapCommandPlanner}=await import(pathToFileURL(source+'/scripts/bootstrap_1-planner.ts').href);
const{runAiGameLoop}=await import(pathToFileURL(source+'/src/ai/game-runner.ts').href);
const report=JSON.parse(readFileSync(reportPath,'utf8')),row=report.rows.find((r:any)=>r.tick===from),expectedRow=report.rows.find((r:any)=>r.tick===end);
if(!row||!expectedRow)throw new Error('Recorded complete start and end rows required');
const frame=JSON.parse(readFileSync(reportPath+'.frames/'+from+'.json','utf8')),expected=JSON.parse(readFileSync(reportPath+'.frames/'+end+'.json','utf8')),setup=report.setup;
const match=bootstrapMatches(setup.seed,[setup.map],end,setup.unseen).find((m:any)=>m.subject===report.subject&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===Object.values(setup.agents).slice(1).map((a:any)=>a.version).join('+'));
if(!match)throw new Error('Exact match absent');
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const memories=createAiMemoryProvider();for(const[owner,p]of Object.entries(row.players)as any[])memories.set(owner,structuredClone(p.policy));
const restore={worldSerializedEqual:JSON.stringify(snapshotGame(game))===JSON.stringify(frame.snapshot),nextIdEqual:game.nextId===frame.nextId,allMemoriesSerializedEqual:Object.entries(row.players).every(([owner,p]:any)=>JSON.stringify(memories.get(owner))===JSON.stringify(p.policy))};
if(Object.values(restore).some(v=>!v))throw new Error('Input restore mismatch');
const planner=await createBootstrapCommandPlanner(memories),commands:any[]=[],events:any[]=[];
const state=()=>({gold:Object.fromEntries(Object.entries(game.players).map(([o,p]:any)=>[o,p.gold])),spent:{...game.match.stats.goldSpent},stats:structuredClone(game.match.stats),allUnits:game.units.map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,hp:u.hp,x:u.x,y:u.y,deckShipId:u.deck?.shipId,order:structuredClone(u.order)})),halls:game.buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,owner:b.owner,complete:b.complete,hp:b.hp,x:b.x,y:b.y})),workers:game.units.filter((u:any)=>u.kind==='worker').map((u:any)=>({id:u.id,owner:u.owner,x:u.x,y:u.y,carryingGold:u.carryingGold,order:structuredClone(u.order),deck:structuredClone(u.deck)}))});
const seenHits=new Set<string>(), nativeHits:any[]=[], workerTicks:any[]=[];
let before=state();
runAiGameLoop({...match,game,commandPlanner:planner},{onCommand:({tick,owner,scriptId,command}:any)=>commands.push({tick,owner,scriptId,command:structuredClone(command)}),onStep:({game}:any)=>{
 const after=state(),tick=game.tick;
 for(const effect of game.effects)if(effect.type==='hit'&&!seenHits.has(effect.id)&&Math.hypot(effect.x-4570,effect.y-5030)<650){seenHits.add(effect.id);nativeHits.push({tick,effect:structuredClone(effect),source:structuredClone(game.units.find((u:any)=>u.id===effect.sourceId))});}
 workerTicks.push({tick,worker:structuredClone(game.units.find((u:any)=>u.id==='unit-p0-worker-1010')),projectiles:structuredClone(game.projectiles.filter((p:any)=>p.targetId==='unit-p0-worker-1010'||p.targetId==='building-p0-defenseTower-6646'))});
 for(const hall of after.halls){const old=before.halls.find((h:any)=>h.id===hall.id);if(!old||!old.complete&&hall.complete)events.push({type:old?'hallCompleted':'nativeHallCreated',tick,hall,ownerGoldBefore:before.gold[hall.owner],ownerGoldAfter:after.gold[hall.owner],ownerSpentBefore:before.spent[hall.owner]??0,ownerSpentAfter:after.spent[hall.owner]??0,ownerSpentDelta:(after.spent[hall.owner]??0)-(before.spent[hall.owner]??0)});}
 for(const u of after.workers){const old=before.workers.find((w:any)=>w.id===u.id);if(old&&old.carryingGold>u.carryingGold)events.push({type:'workerCargoReduced',tick,before:old,after:u,ownerGoldBefore:before.gold[u.owner],ownerGoldAfter:after.gold[u.owner],ownerGoldDelta:after.gold[u.owner]-before.gold[u.owner],ownerSpentDelta:(after.spent[u.owner]??0)-(before.spent[u.owner]??0),note:'Native observed cargo and total gold delta; do not assign simultaneous income exclusively to this one worker.'});}
 for(const old of before.allUnits){const u=after.allUnits.find((x:any)=>x.id===old.id);if(!u)events.push({type:'nativeUnitRemoved',tick,previous:old,unitsLostBefore:before.stats.unitsLost[old.owner]??0,unitsLostAfter:after.stats.unitsLost[old.owner]??0,unitsKilledByNeutralBefore:before.stats.unitsKilledByNeutral[old.owner]??0,unitsKilledByNeutralAfter:after.stats.unitsKilledByNeutral[old.owner]??0,killsBefore:before.stats.unitsKilled,killsAfter:after.stats.unitsKilled});else if(old.deckShipId&&!u.deckShipId)events.push({type:'nativeUnitDisembarked',tick,before:old,after:u});}
 before=after;
}});
const finalSnapshot=snapshotGame(game),finalMemories=Object.fromEntries(Object.keys(row.players).map(owner=>[owner,memories.get(owner)]));
const reproduction={worldSerializedEqual:JSON.stringify(finalSnapshot)===JSON.stringify(expected.snapshot),nextIdEqual:game.nextId===expected.nextId,allMemoriesSerializedEqual:Object.entries(expectedRow.players).every(([owner,p]:any)=>JSON.stringify(memories.get(owner))===JSON.stringify(p.policy))};
const result={classification:'Observer-only same-source native both-AI window restored from actual changed-code continuation. Public planner commands unchanged; no manual command injection. Not a new ordinary0.',source,observerSourceSHA256:sha(readFileSync(new URL(import.meta.url))),baseCommit:cap.baseCommit,from,end,restore,reproduction,sourcePreflight:preSource,sourcePostflight:verifySource(),commands,events,nativeHits,workerTicks};
writeFileSync(out+'.json',JSON.stringify(result,null,2)+'\n');writeFileSync(out+'-final.json',JSON.stringify({snapshot:finalSnapshot,nextId:game.nextId,memories:finalMemories})+'\n');
console.log(JSON.stringify({from,end,restore,reproduction,events}));
if(Object.values(reproduction).some(v=>!v))throw new Error('Window does not reproduce the actual recorded branch; preserve and investigate before attribution');
