import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root='/tmp/sketch-rts-colony-capital-control';
const {createGame,restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(root+'/src/shared/sim.ts').href);
const {bootstrapPolicyContext}=await import(pathToFileURL(root+'/src/ai/bootstrap_1/policy.ts').href);
const {rankBootstrapGoals}=await import(pathToFileURL(root+'/src/ai/bootstrap_1/economy.ts').href);
const {v9ChokeTowerPoint}=await import(pathToFileURL(root+'/src/ai/policy/v9/front.ts').href);
const {readV6Intel}=await import(pathToFileURL(root+'/src/ai/policy/v6/intel.ts').href);
const p='/tmp/bootstrap-summoner-incoming9600-20261015/summoner-incoming-b0c8-cont24000.json';
const report=JSON.parse(readFileSync(p,'utf8'));const out=[];
for(const tick of [37230]){
 const frame=JSON.parse(readFileSync('/tmp/bootstrap-neutral-miners-b0/actual-before-37230.json','utf8'));const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
 const row={players:Object.fromEntries(Object.entries(frame.memories).map(([o,m])=>[o,{policy:m}]))},snapshot=snapshotGame(game),before=JSON.stringify(snapshot);
 const context=bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:structuredClone(row.players.p0.policy),teams:game.teams});
 const goals=rankBootstrapGoals(snapshot,'p0',context),intel=readV6Intel(snapshot,'p0',context);
 out.push({tick,chokes:intel.ownHalls.map((hall:any)=>({hallId:hall.id,point:v9ChokeTowerPoint(snapshot,intel,hall)})),goals:goals.filter((g:any)=>g.id.startsWith('tower:')).map((g:any)=>{const command=g.issue(new Set());return {id:g.id,command,nearestNeutrals:command?.type==='build'?snapshot.units.filter((u:any)=>u.owner==='neutral').map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,dist:Math.hypot(u.x-command.x,u.y-command.y)})).sort((a:any,b:any)=>a.dist-b.dist).slice(0,4):[]}})});
 if(JSON.stringify(snapshot)!==before)throw Error('world query mutation');
}
writeFileSync('/tmp/bootstrap-neutral-miners-b0/tower-query-actual37230.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
