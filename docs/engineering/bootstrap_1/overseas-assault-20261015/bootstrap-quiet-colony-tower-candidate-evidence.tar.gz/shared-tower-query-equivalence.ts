import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';import{isDeepStrictEqual}from'node:util';
const oldRoot='/tmp/sketch-rts-colony-capital-control',newRoot='/tmp/sketch-rts-quiet-colony-tower-control';
const prefix='/tmp/bootstrap-summoner-incoming9600-20261015/',names=['summoner-incoming-only-b0c8','summoner-incoming-b0c8-cont24000'];
const reports=names.map(name=>({path:prefix+name+'.json',report:JSON.parse(readFileSync(prefix+name+'.json','utf8'))}));
const modules=await Promise.all([oldRoot,newRoot].map(async root=>({root,sim:await import(pathToFileURL(root+'/src/shared/sim.ts').href),policy:await import(pathToFileURL(root+'/src/ai/bootstrap_1/policy.ts').href),economy:await import(pathToFileURL(root+'/src/ai/bootstrap_1/economy.ts').href)})));
const results=[];
for(const tick of [9600,14400,24000,33000,37020,37230,37560,38400,45000,61200]){
 let saved:any;
 if(tick===37230)saved=JSON.parse(readFileSync('/tmp/bootstrap-neutral-miners-b0/actual-before-37230.json','utf8'));
 else{const source=reports.find(r=>r.report.rows.some((row:any)=>row.tick===tick));if(!source)continue;const row=source.report.rows.find((row:any)=>row.tick===tick);saved={...JSON.parse(readFileSync(source.path+'.frames/'+tick+'.json','utf8')),memories:Object.fromEntries(Object.entries(row.players).map(([o,p]:any)=>[o,p.policy]))};}
 const outputs=modules.map(({sim,policy,economy})=>{const game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=sim.snapshotGame(game),before=JSON.stringify(snapshot);const opts=policy.bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:structuredClone(saved.memories.p0),teams:game.teams});const towers=economy.rankBootstrapGoals(snapshot,'p0',opts).filter((g:any)=>g.id.startsWith('tower:')).map((g:any)=>({id:g.id,priority:g.priority,cost:g.cost,command:g.issue(new Set())}));if(JSON.stringify(snapshot)!==before)throw Error('world mutation');return JSON.parse(JSON.stringify(towers));});
 results.push({tick,defaultTowerQueriesEqual:isDeepStrictEqual(...outputs),old:outputs[0],extracted:outputs[1]});
}
const result={classification:'Mechanical extraction equivalence of the existing default tower goal query on complete real inputs; excludes the intentionally changed naval:footholdTower goal. Not a match score.',cases:results};writeFileSync('/tmp/bootstrap-neutral-miners-b0/shared-tower-query-equivalence.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(results.map(r=>({tick:r.tick,equal:r.defaultTowerQueriesEqual}))));if(results.some(r=>!r.defaultTowerQueriesEqual))throw Error('Default query changed');
