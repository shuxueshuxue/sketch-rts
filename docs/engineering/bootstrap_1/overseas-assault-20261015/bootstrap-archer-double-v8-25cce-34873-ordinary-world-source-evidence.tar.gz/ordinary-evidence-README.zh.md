# Archer 双 v8 普通开局负例（固定25cce）

本次实际执行 unmodified bootstrap_1-inspect，从0开始无resume、手工命令、世界或策略记忆修改。2026-10-15普通局34873 tick自然p1胜，原生endedAtTick34873，p0单位和建筑均清零。并非144000 horizon或一次局部修复胜利。

Grove v9_archer物理side1，对手p1 Ember frozen v8、p2 Grove frozen v8（同team b）；所有玩家500金/3人口/8上限。factory参数pineshade --unseen，实际地图ladder 4608²，seed bootstrap_1-unseen-archer-v8-v8-20261015-01。原approved工厂第三席与地形坐标完全保留；观察后这个seed已属于开发seed。

源码clean25cce06f1567bc68cf08a2b278122f88eebf6b6f，运行前后1167源码和70支持文件全部hash一致。rulesVersion2，冻结对手revision d1ae110f2edd99f9c7d899ed61557891ab587639，manifest184项核验，SHA0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。没有并入main规则4船只平衡。

59个实际比赛checkpoint保存完整世界、nextId和报告中p0/p1/p2全部策略记忆。0.json/ordinary-opening.json是同源独立工厂开局见证；新鲜provider在首次think前未初始化各owner，三个null明确记录该缺席，不是种下策略。preparedOnly的旧launch文件原样保留；ordinary-execution.json记录真正启动PID171705、精确命令、起止与exit0，不能把准备状态称为已跑。

终局p0 unitsLost65（其中2中立）、goldSpent11771、摧毁5栋全部非基地；p1剩33单位/24建筑，p2剩23单位/19建筑。terminal nextId29674；完整原始stats见最后snapshot。

0、17400、34873的原生drawWorld实存档截图与镜头元数据已保留并亲看0总览、17400本营、34873本营。新facing tracker不能恢复历史动画，截图不证明某次射击；后续针对性原生hit/action记录另包归因。

原破损容器的未提交修改仍未恢复。这只是新独立承接源码的真实负例，三条路线的全图、全部单敌和六配对及未见种子最终验收仍未完成。
