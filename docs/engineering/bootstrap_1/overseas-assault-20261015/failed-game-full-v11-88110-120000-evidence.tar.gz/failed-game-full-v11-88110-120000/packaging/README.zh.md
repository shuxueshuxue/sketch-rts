# root-v11 88110→120000 完整失败续局补充证据

这是已有真实存档的换代码续局，双方每15tick完整正常AI，未发手工命令。不是普通0开局、不是独立验收、不是一次新模拟。本包保存原始失败，不把 hold 当成已安全返航。

实际终局120000：winner=null，敌主厅900，敌21建筑/22单位。原29名突击乘员15名仍在3824甲板、14名死亡；没有原乘员曾落到敌岛，敌岛0人。14死亡不是整场总损失（整场p0累计34损失含先前历史）。3510的14名乘员在89072～89467死亡；3824从89040起只收到一次holdPosition，直到120000仍同一位置。

89040首次取消的实际原因是原有航中兵力门槛：incomingPower19.2148897844 < required19.8742076486。新临时spirit使门槛上升；不是450距离、海军outgunned或40秒卡住导致首次取消。3824随后进入空reference/candidate查询，持续过滤正常返航unload。38次810tick原生停滞分支再次取消/重置同一位置，不是物理进展。参考路径为空不证明返岸不可达；hold存活不代表完成返航或跨海进攻。return-gates与return-hold的原始纯查询、完整输入/总结/日志均保留。

原始136个完整world/nextId/双方所有policy memories文件全部收入。54个sample-*文件（88710～119910每600tick及120000），其中53个在89040取消之后；另有start、terminal、每次有保存的决策变化前后与死亡帧。terminal120000与sample120000逐字节相同。55行汇总含start，其记忆逐帧核对一致。完整56.8MB原报告、31,890个逐tick乘员分区、2,126个think记录、4,329条issued、246次hit、原日志及driver保留。

源记录：原有不可变1589文件capsule及原canonical manifest、为完整AI续局适配的derived manifest、原runner preflight/postflight均收入；本次事后审计又核对capsule内1589个SHA以及当前不可变control，全部一致。canonical源capsule原来为3个原生组件窗口封存；其元数据仍如实保留，不改写成“为本完整对局预先封存”。本完整续局的实际原始preflight和postflight由自己的driver记录。

冻结rules2清单revision d1ae110f2edd99f9c7d899ed61557891ab587639，184文件全部与manifest一致。除原184源码tar外，另收入事后从该Git commit按实际historical loader路径package.json/src/ai/src/sdk/src/shared重建的497文件tar，便于离线复原。这份497文件tar明确是事后重建，非prelaunch证据；没有改写184冻结manifest，也未改变对手生产API。

观察器勘误必须随报告阅读：原driver中的 thoughts.boats.sailing=u.sailing 保留共享对象引用，历史heading/speed后来被模拟覆写。例如88110船3510实际磁盘heading12.9658/speed11.5759，而原report最后写出heading13.8579/speed0。原report/driver完整保留，不伪造修复。历史船姿态、route/嵌套对象和memory因果应读完整磁盘世界及deep-cloned before记忆；AUDIT.json收录4例对照。slim的deck/order嵌套对象亦未额外deep clone，不能单独当成完整不可变历史；原生hit的primitive damage/hpBefore、primitive位置/血量与逐tick ID分区另有实际记录。

3张原生client图是事后用真实保存的89040/89467/89910世界经原客户端drawWorld渲染。本包另渲染120000终局，附input SHA/renderer SHA/脚本/日志；均不是手绘重构，也不声称是当时实时截图。渲染不推进模拟。

复现原run需恢复source capsule以及Git冻结revision（或把实际loader指向本包等价源码），安装原lock对应依赖，再按原driver参数：
 npx tsx archer-assault-root-v11-prelanding-run.ts --worktree <immutable-source-root> --prefix <new-prefix> --fixture <before-think-88110.json> --source <archer-assault-root-v11-prelanding-source.json> --history normal --crew <archer-assault-root-v11-prelanding-input.json> --end 120000
此为说明，打包任务没有重新运行整局。原driver保留其绝对路径以便审计，迁移时需显式调整输出root，不能覆盖旧失败证据。

INDEX.json逐payload记录bytes与SHA256；本包构建后逐一读回验证所有条目。build-evidence.py和AUDIT.json记录事后审计，绝不伪称prelaunch。node_modules未包含，旧整局来源文件/早期source仅引用未全部重复；原故障容器未提交修改仍无法恢复。
