from pathlib import Path
import datetime,hashlib,io,json,shutil,subprocess,tarfile
BASE=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015')
OUT=BASE/'failed-game-full-v11-88110-120000'
PAY=OUT/'payload'
WORK=Path('/workspace/sketch-rts-root-v11-integration-control')
PREFIX='archer-assault-root-v11-prelanding'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
manifest=load(BASE/'root-v11-integration-source.json')
derived=load(BASE/(PREFIX+'-source.json'))
report=load(BASE/(PREFIX+'.json'))
source=manifest['sourceSha256']
assert len(source)==1589 and source==derived['files']
assert derived['canonicalSourceSha256']==sha((BASE/'root-v11-integration-source.json').read_bytes())
assert derived['canonicalArchiveSha256']==sha((BASE/'root-v11-integration-source.tar.gz').read_bytes())
source_capsule={}
with tarfile.open(BASE/'root-v11-integration-source.tar.gz') as tar:
 for item in tar:
  assert item.isfile() and item.name not in source_capsule
  source_capsule[item.name]=sha(tar.extractfile(item).read())
assert source_capsule==source
runtime_changed=[name for name,digest in source.items() if not (WORK/name).is_file() or sha((WORK/name).read_bytes())!=digest]
assert not runtime_changed
frozen_path=WORK/'docs/engineering/bootstrap_1/frozen-policy.json'
frozen=load(frozen_path)
assert sha(frozen_path.read_bytes())=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
assert frozen['rulesVersion']==2 and len(frozen['files'])==184
frozen_capsule={}
with tarfile.open(BASE/'root-v11-integration-frozen-source.tar') as tar:
 for item in tar:
  if item.isfile():frozen_capsule[item.name]=sha(tar.extractfile(item).read())
assert frozen_capsule==frozen['files']
# Reconstruct the exact Git archive paths requested by the historical opponent loader.
# This is performed now, after the match, and is never labeled a prelaunch capture.
archive_bytes=subprocess.check_output(['git','archive',frozen['revision'],'package.json','src/ai','src/sdk','src/shared'],cwd=WORK)
(OUT/'frozen-opponent-loader-paths-posthoc.tar').write_bytes(archive_bytes)
with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as tar:
 reconstructed={m.name:sha(tar.extractfile(m).read()) for m in tar if m.isfile()}
assert all(reconstructed.get(name)==digest for name,digest in frozen['files'].items())
input_path=BASE/'archer-assault-contact-replay.frames/before-think-88110.json'
assert sha(input_path.read_bytes())==report['fixtureSha256']=='7af60daacea224f3ef5a0d4b151147a28c4eba4e72bbc972498e78bb83f27513'
input_world=load(input_path)
assert input_world['tick']==88110 and input_world['nextId']==12530
assert set(input_world['memories'])=={'p0','p1'}
frames={}
for path in sorted((BASE/(PREFIX+'.frames')).glob('*.json')):
 d=load(path)
 assert d['tick']==d['snapshot']['tick'] and isinstance(d['nextId'],int) and set(d['memories'])=={'p0','p1'}
 assert all(isinstance(d['memories'][o],dict) for o in ['p0','p1'])
 frames[path.name]={'tick':d['tick'],'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'nextId':d['nextId'],'owners':['p0','p1']}
assert len(frames)==136
samples=sorted([v['tick'] for name,v in frames.items() if name.startswith('sample-')])
assert len(samples)==54 and samples==list(range(88710,120000,600))+[120000]
assert sum(t>=89040 for t in samples)==53
terminal=load(BASE/(PREFIX+'.frames/terminal-120000.json'))
assert terminal['tick']==120000 and terminal['nextId']==17734
assert frames['terminal-120000.json']['sha256']==frames['sample-120000.json']['sha256']
assert len(report['rows'])==55
row_mismatches=[]
for row in report['rows']:
 p=BASE/Path(row['frame']).relative_to(BASE)
 d=load(p)
 if row['tick']!=d['tick'] or any(row['players'][o]['policy']!=d['memories'][o] for o in ['p0','p1']): row_mismatches.append(str(p))
assert not row_mismatches
assert report['completed'] and report['start']==88110 and report['end']==120000
assert report['manualHistory']==[] and report['restore']=={'snapshot':True,'nextId':True,'memories':True}
assert report['sourcePreflight']=={'head':True,'files':True} and load(BASE/(PREFIX+'-source-postflight.json'))=={'exactSourcePreserved':True}
assert report['everLanded']==[] and len(report['originalCrew'])==29
for item in report['tickStates']:
 partitions=[item[k] for k in ['currentDeck','currentGroundOnTarget','currentElsewhere','dead']]
 assert len(set(sum(partitions,[])))==29 and set(sum(partitions,[]))==set(report['originalCrew'])
 assert not item['currentGroundOnTarget']
last=report['tickStates'][-1]
assert len(last['currentDeck'])==15 and len(last['dead'])==14 and not last['currentElsewhere']
assert report['final']['winner'] is None and report['final']['enemyHallHp']==900
assert len(report['final']['enemyBuildings'])==21 and len(report['final']['enemyUnits'])==22
# Demonstrate the observer defect against authoritative serialized disk worlds.
examples=[]
for tick in [88110,89040]:
 d=load(BASE/(PREFIX+f'.frames/before-mission-change-{tick}.json'))
 thought=next(t for t in report['thoughts'] if t['tick']==tick)
 for boat in thought['boats']:
  u=next(u for u in d['snapshot']['units'] if u['id']==boat['id'])
  examples.append({'tick':tick,'id':u['id'],'diskSailing':u['sailing'],'reportThoughtSailing':boat['sailing']})
audit={'classification':'Post-run read-only evidence audit and archive construction; not a new match, prelaunch source capture, or new simulation replay.',
 'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source':{'canonicalManifest':'root-v11-integration-source.json','manifestSha256':derived['canonicalSourceSha256'],'files':len(source),'archiveContentsEqualManifest':True,'currentImmutableRuntimeChanges':runtime_changed,'originalRunnerPreflight':report['sourcePreflight'],'originalRunnerPostflight':load(BASE/(PREFIX+'-source-postflight.json'))},
 'frozen':{'revision':frozen['revision'],'rulesVersion':2,'manifestSha256':sha(frozen_path.read_bytes()),'original184ArchiveEqualManifest':True,'posthocLoaderPathArchiveFiles':len(reconstructed),'posthocLoaderPathArchiveSha256':sha(archive_bytes),'posthocArchiveLabel':'Reconstructed now from the immutable authorized Git commit using the exact loader paths. Not recorded before the game; all184 manifested frozen dependencies agree.'},
 'input':{'sha256':report['fixtureSha256'],'tick':88110,'nextId':12530,'owners':['p0','p1'],'originalNativeRestore':report['restore']},
 'frames':{'count':len(frames),'sampleFiles':len(samples),'sampleTicks':samples,'samplesAfterFirstReturn89040':sum(t>=89040 for t in samples),'rowsIncludingStart':len(report['rows']),'rowMemoryMismatches':row_mismatches,'terminalEqualsSample120000':True,'terminalNextId':terminal['nextId'],'allCompleteWorldNextIdAndBothMemoriesSchema':True,'files':frames},
 'result':{'end':120000,'winner':None,'enemyHallHp':900,'enemyBuildings':21,'enemyUnits':22,'originalCrew':29,'onDeck':15,'dead':14,'enemyGround':0,'elsewhere':0,'everLanded':[],'perNativeTickCrewPartitionsChecked':len(report['tickStates']),'runWholeMatchLosses':report['final']['losses'],'note':'14 dead counts only the29 original assault crew; total match losses include earlier history.'},
 'observerErrata':{'sharedReference':'The original driver stores thoughts.boats.sailing=u.sailing by reference. Later simulation mutations altered historical serialized heading/speed. Preserve the original driver/report; do not silently repair them. Full disk snapshots and cloned before-memories are authoritative. slim also stores nested deck/order objects without deep clone; use disk snapshots for historical nested object states. Primitive x/y/hp, damage/hpBefore, ID arrays, and complete captured disk worlds remain independently recorded.','demonstratedExamples':examples},
 'limits':['No newly invented exact world at89025; the original saved-world gate query explicitly notes it is absent.','No replay of the entire31890-tick segment was performed by this packaging task. Static JSON roundtrips/hashes are not simulation-replay claims.','No per-native-tick ship pose trace; sampled same-pose worlds do not establish the precise last motion tick.','The original unmanipulated88110 save already includes earlier code changes; this segment is a changed-source continuation, not a standard tick0 opening.','The whole earlier match history and its previous source capsules are referenced but not duplicated in this supplemental archive.','Original broken-container uncommitted modifications remain unrecovered.','Dependencies node_modules are not included. Package and lock bytes are in the1589 source capsule.']}
(OUT/'AUDIT.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
readme='''# root-v11 88110→120000 完整失败续局补充证据

这是已有真实存档的换代码续局，双方每15tick完整正常AI，未发手工命令。不是普通0开局、不是独立验收、不是一次新模拟。本包保存原始失败，不把 hold 当成已安全返航。

实际终局120000：winner=null，敌主厅900，敌21建筑/22单位。原29名突击乘员15名仍在3824甲板、14名死亡；没有原乘员曾落到敌岛，敌岛0人。14死亡不是整场总损失（整场p0累计34损失含先前历史）。3510的14名乘员在89072～89467死亡；3824从89040起只收到一次holdPosition，直到120000仍同一位置。

89040首次取消的实际原因是原有航中兵力门槛：incomingPower19.2148897844 < required19.8742076486。新临时spirit使门槛上升；不是450距离、海军outgunned或40秒卡住导致首次取消。3824随后进入空reference/candidate查询，持续过滤正常返航unload。38次810tick原生停滞分支再次取消/重置同一位置，不是物理进展。参考路径为空不证明返岸不可达；hold存活不代表完成返航或跨海进攻。return-gates与return-hold的原始纯查询、完整输入/总结/日志均保留。

原始136个完整world/nextId/双方所有policy memories文件全部收入。54个sample-*文件（88710～119910每600tick及120000），其中53个在89040取消之后；另有start、terminal、每次有保存的决策变化前后与死亡帧。terminal120000与sample120000逐字节相同。55行汇总含start，其记忆逐帧核对一致。完整56.8MB原报告、31,890个逐tick乘员分区、2,126个think记录、4,329条issued、246次hit、原日志及driver保留。

源记录：原有不可变1589文件capsule及原canonical manifest、为完整AI续局适配的derived manifest、原runner preflight/postflight均收入；本次事后审计又核对capsule内1589个SHA以及当前不可变control，全部一致。canonical源capsule原来为3个原生组件窗口封存；其元数据仍如实保留，不改写成“为本完整对局预先封存”。本完整续局的实际原始preflight和postflight由自己的driver记录。

冻结rules2清单revision d1ae110f2edd99f9c7d899ed61557891ab587639，184文件全部与manifest一致。除原184源码tar外，另收入事后从该Git commit按实际historical loader路径package.json/src/ai/src/sdk/src/shared重建的497文件tar，便于离线复原。这份497文件tar明确是事后重建，非prelaunch证据；没有改写184冻结manifest，也未改变对手生产API。

观察器勘误必须随报告阅读：原driver中的 thoughts.boats.sailing=u.sailing 保留共享对象引用，历史heading/speed后来被模拟覆写。例如88110船3510实际磁盘heading12.9658/speed11.5759，而原report最后写出heading13.8579/speed0。原report/driver完整保留，不伪造修复。历史船姿态、route/嵌套对象和memory因果应读完整磁盘世界及deep-cloned before记忆；AUDIT.json收录4例对照。slim的deck/order嵌套对象亦未额外deep clone，不能单独当成完整不可变历史；原生hit的primitive damage/hpBefore、primitive位置/血量与逐tick ID分区另有实际记录。

3张原生client图是事后用真实保存的89040/89467/89910世界经原客户端drawWorld渲染。本包另渲染120000终局，附input SHA/renderer SHA/脚本/日志；均不是手绘重构，也不声称是当时实时截图。渲染不推进模拟。

复现原run需恢复source capsule以及Git冻结revision（或把实际loader指向本包等价源码），安装原lock对应依赖，再按原driver参数：
 npx tsx archer-assault-root-v11-prelanding-run.ts --worktree <immutable-source-root> --prefix <new-prefix> --fixture <before-think-88110.json> --source <archer-assault-root-v11-prelanding-source.json> --history normal --crew <archer-assault-root-v11-prelanding-input.json> --end 120000
此为说明，打包任务没有重新运行整局。原driver保留其绝对路径以便审计，迁移时需显式调整输出root，不能覆盖旧失败证据。

INDEX.json逐payload记录bytes与SHA256；本包构建后逐一读回验证所有条目。build-evidence.py和AUDIT.json记录事后审计，绝不伪称prelaunch。node_modules未包含，旧整局来源文件/早期source仅引用未全部重复；原故障容器未提交修改仍无法恢复。
'''
(OUT/'README.zh.md').write_text(readme)
PAY.mkdir(exist_ok=True)
selected=[]
def add(path,arcname=None):
 path=Path(path);relative=arcname or path.relative_to(BASE).as_posix();dest=PAY/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest);selected.append(relative)
for p in sorted((BASE/(PREFIX+'.frames')).glob('*.json')):add(p)
for name in [PREFIX+'.json',PREFIX+'.log',PREFIX+'-input.json',PREFIX+'-run.ts',PREFIX+'-source.json',PREFIX+'-source-postflight.json',PREFIX+'-render.ts',PREFIX+'-visual.log',PREFIX+'-first-return-89040.png',PREFIX+'-last-lead-cargo-death-89467.png',PREFIX+'-after-return-89910.png','root-v11-integration-source.json','root-v11-integration-source.tar.gz','root-v11-integration-frozen-source.tar','root-v11-integration-frozen-check.json','root-v11-integration-overlay-capture.json','root-v11-integration-root-overlay.patch','root-v11-integration-final-source-check.json']:
 add(BASE/name)
add(input_path)
for pattern in ['archer-assault-root-v11-return-gates-*','archer-assault-root-v11-return-hold-*']:
 for p in sorted(BASE.glob(pattern)):
  if p.is_file():add(p)
for name in ['AUDIT.json','README.zh.md','build-evidence.py','render-terminal.ts','terminal-render.log','terminal-render-metadata.json','terminal-120000-native-client.png','frozen-opponent-loader-paths-posthoc.tar']:
 add(OUT/name,'packaging/'+name)
# Explicit original frozen manifest as a convenient standalone byte-for-byte payload.
add(frozen_path,'frozen-policy.json')
assert len(set(selected))==len(selected)
index={'classification':'Supplemental complete changed-code full-AI failure evidence. All timestamps/packaging audits created after the run are labeled; original source metadata retained.',
 'root':'failed-game-full-v11-88110-120000','payloadCount':len(selected),'files':{name:{'bytes':(PAY/name).stat().st_size,'sha256':sha((PAY/name).read_bytes())} for name in sorted(selected)}}
(PAY/'INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
archive=BASE/'failed-game-full-v11-88110-120000-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(PAY.rglob('*')):
  if p.is_file():tar.add(p,arcname='failed-game-full-v11-88110-120000/'+p.relative_to(PAY).as_posix(),recursive=False)
with tarfile.open(archive) as tar:
 members=[m for m in tar if m.isfile()];prefix='failed-game-full-v11-88110-120000/'
 names=[m.name.removeprefix(prefix) for m in members]
 assert len(names)==len(selected)+1 and len(set(names))==len(names)
 assert set(names)==set(index['files'])|{'INDEX.json'}
 recovered_index=json.loads(tar.extractfile(prefix+'INDEX.json').read())
 assert recovered_index==index
 checked=0
 for name,entry in index['files'].items():
  payload=tar.extractfile(prefix+name).read()
  assert len(payload)==entry['bytes'] and sha(payload)==entry['sha256'];checked+=1
verification={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payloadsVerified':checked,'totalFileEntriesIncludingIndex':checked+1,'sourceCapsuleFilesVerified':len(source),'framesVerified':len(frames),'allPayloadHashesAndLengthsMatch':True,'archiveIndexExact':True,'result':audit['result']}
(OUT/'ARCHIVE-VERIFIED.json').write_text(json.dumps(verification,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(verification,indent=2,ensure_ascii=False))
