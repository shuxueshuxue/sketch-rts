import {createCanvas} from '@napi-rs/canvas';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const artifacts='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const output=artifacts+'/failed-game-full-v11-88110-120000';
const worktree='/workspace/sketch-rts-root-v11-integration-control';
const imp=(p:string)=>import(pathToFileURL(worktree+'/'+p).href);
const [{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([
 imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const input=artifacts+'/archer-assault-root-v11-prelanding.frames/terminal-120000.json';
const bytes=readFileSync(input),{snapshot}=JSON.parse(bytes.toString());
const canvas=createCanvas(1500,1200);
drawWorld({ctx:canvas.getContext('2d') as any,snapshot,
 view:{x:1600,y:5300,width:1500,height:1200,zoom:1},now:snapshot.tick*1000/20,
 facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
const png=canvas.toBuffer('image/png');
writeFileSync(output+'/terminal-120000-native-client.png',png);
writeFileSync(output+'/terminal-render-metadata.json',JSON.stringify({
 classification:'Post-run rendering of the actual unchanged complete terminal snapshot using the immutable game client drawWorld. No simulation, planner, or world edits; not a contemporaneous live screenshot.',
 tick:snapshot.tick,input,inputSha256:createHash('sha256').update(bytes).digest('hex'),worktree,
 view:{x:1600,y:5300,width:1500,height:1200,zoom:1},pngSha256:createHash('sha256').update(png).digest('hex'),
 rendererSources:Object.fromEntries(['src/recorder/record.ts','src/client/world-renderer.ts','src/client/unit-facing.ts'].map(p=>[p,createHash('sha256').update(readFileSync(worktree+'/'+p)).digest('hex')]))
},null,2)+'\n');
console.log('Rendered actual terminal snapshot tick '+snapshot.tick);
