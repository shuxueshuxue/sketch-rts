import{createCanvas}from'@napi-rs/canvas';import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const art='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',wd='/workspace/sketch-rts-root-v11-integration-control',imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const[{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);installHeadlessCanvas();
for(const[label,frame]of [['first-return-89040','before-mission-change-89040'],['last-lead-cargo-death-89467','death-89467'],['after-return-89910','sample-89910']]){
 const {snapshot}=JSON.parse(readFileSync(`${art}/archer-assault-root-v11-prelanding.frames/${frame}.json`,'utf8'));const canvas=createCanvas(1500,1200);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:{x:1600,y:5300,width:1500,height:1200,zoom:1},now:snapshot.tick*1000/20,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(`${art}/archer-assault-root-v11-prelanding-${label}.png`,canvas.toBuffer('image/png'));console.log(label);
}
