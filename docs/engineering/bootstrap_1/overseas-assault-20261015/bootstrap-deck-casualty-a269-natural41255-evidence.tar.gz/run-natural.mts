import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';

const P = '/workspace/.playtest/bootstrap-deck-casualty-v3-20261016';
const D = P + '/native-40350-natural';
assert.equal(existsSync(D), false, 'Never overwrite a prior continuation'); mkdirSync(D);
const W = '/tmp/sketch-rts-deck-casualty-v3-control';
const cap = JSON.parse(readFileSync(`${P}/source.json`, 'utf8'));
for (const path of ['frames', 'launch.json', 'result.json', 'commands.jsonl', 'hits.jsonl', 'events.jsonl'])
  assert.equal(existsSync(`${D}/${path}`), false, `Never overwrite prior ordinary game evidence: ${path}`);
const hash = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex');
const json = (value: any) => JSON.parse(JSON.stringify(value));
const imp = (p: string) => import(pathToFileURL(`${W}/${p}`).href);
const sourceCheck = () => {
  const bad = Object.entries(cap.files).filter(([p, h]) => hash(`${W}/${p}`) !== h).map(([p]) => p);
  assert.deepEqual(bad, []);
  assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: W, encoding: 'utf8' }).trim(), cap.head);
  assert.equal(execFileSync('git', ['status', '--porcelain', '--untracked-files=all'], { cwd: W, encoding: 'utf8' }), '');
  return { exact: true, files: Object.keys(cap.files).length, head: cap.head };
};
const sourcePre = sourceCheck();
const [{ bootstrapGame, bootstrapMatches }, { runAiGameLoop }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { snapshotGame, restoreSnapshotIntoGame, stepGame }, { RULES_VERSION }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/ai/game-runner.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/shared/sim.ts'), imp('src/shared/rules-version.ts'),
]);
assert.equal(RULES_VERSION, 2);
const selection = cap.selection;
const match = bootstrapMatches(selection.seed, [selection.mapId], Number.MAX_SAFE_INTEGER, selection.unseen).find((m: any) =>
  m.subject === selection.subject && m.side === selection.side && m.agents.p0.race === selection.race &&
  Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === selection.opponents.join('+'));
assert.ok(match);
assert.equal(match.thinkInterval, 15);
assert.equal(match.unseen, false);
assert.deepEqual(Object.keys(match.agents), ['p0', 'p1']);
assert.deepEqual(match.agents.p1, { version: 'v5', versionLabel: 'v5', race: 'ember', controller: 'external-agent', team: 'b' });
// Restore the exact post40350-publiccommands native pre-step; do not repeat either AI think at40350.
const inputPath = '/workspace/.playtest/bootstrap-deck-casualty-v2-20261016/oom-phase-diagnostic-40305/phase-inputs/40350-step-enter.json.gz';
const input = JSON.parse(gunzipSync(readFileSync(inputPath)).toString());
const g = bootstrapGame(match);
const mem = createAiMemoryProvider();
const owners = Object.keys(match.agents);
restoreSnapshotIntoGame(g, input.snapshot, input.nextId);
for (const [owner, memory] of Object.entries(input.memories)) if (memory !== null) mem.set(owner, structuredClone(memory));
const memories = () => Object.fromEntries(owners.map(owner => [owner, mem.get(owner) ?? null]));
const restore = { world: isDeepStrictEqual(json(snapshotGame(g)), input.snapshot), nextId: g.nextId === input.nextId,
  bothMem: isDeepStrictEqual(memories(), input.memories) };
assert.ok(Object.values(restore).every(Boolean)); assert.equal(g.tick, 40350); assert.equal(input.event, 'step-enter');
const initial = json(g.match.stats);
const oldParty = JSON.parse(readFileSync('/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015/first-army-input-summary.json','utf8'));
const original13 = oldParty.ships.flatMap((ship: any) => ship.crew.map((unit: any) => ({...unit, oldBaselineShip: ship.id})));
assert.equal(original13.length,13);
writeFileSync(D+'/original13-baseline-manifest.json',JSON.stringify({classification:'Explicit baseline first13 identities from immutable original0f ordinary43725. Candidate ships/load order may change; do not infer candidate landing from the old manifest.', units:original13},null,2)+'\n');
const frozenRoot = frozenPolicyRoot();
const frozenCheck = () => {
  assert.equal(frozenPolicyManifest.rulesVersion, 2);
  assert.equal(frozenPolicyManifest.revision, cap.frozenRevision);
  const bad = Object.entries(cap.frozenFiles).filter(([p, h]) => hash(`${frozenRoot}/${p}`) !== h).map(([p]) => p);
  assert.deepEqual(bad, []);
  return { exact: true, files: Object.keys(cap.frozenFiles).length, revision: cap.frozenRevision };
};
const frozenPre = frozenCheck();
const nativePlanner = await createBootstrapCommandPlanner(mem);
mkdirSync(D+'/decision-inputs'); mkdirSync(D+'/event-inputs');
const planner = (request: any) => {
  if (request.owner === owners[0]) {
    const ferries = mem.get(owners[0])?.naval?.ferries ?? {};
    const nearLanding = Object.entries(ferries).some(([id, mission]: any) => mission.purpose === 'assault' && mission.phase === 'sailing'
      && g.units.some((unit: any) => unit.deck?.shipId === id) && g.units.some((ship: any) => ship.id === id && Math.hypot(ship.x-mission.to.x,ship.y-mission.to.y)<1000));
    if (nearLanding || g.tick <= 42000) writeFileSync(D+'/decision-inputs/'+g.tick+'.json.gz',gzipSync(JSON.stringify({tick:g.tick,snapshot:snapshotGame(g),nextId:g.nextId,memories:memories(),phase:'before first owner planner; next native game loop step uses normal think'})+'\n'));
  }
  return nativePlanner(request);
};
const started = performance.now(), cpuStart = process.cpuUsage();
const provenance = { classification: 'Changed-code continuation: original ordinary0f until35460; d251 deck policy until actual40350 postcommands (both owners already planned/issued), old runtime512/1024MiB OOM unchanged and preserved; new a269 d251+exact FIFO128 native memo resource fix starts at40350. First native step40350→40351 is executed exactly once without repeating40350planners, then both normalAI continue to natural winner. Strategy unchanged at40350 but runtime source changed; not ordinary0, not final bootstrap acceptance. No manual public orders/world changes/resources/opponent/command filtering.',
  source: `${P}/source.json`, sourceArchiveSHA256: cap.sourceArchiveSHA256, sourceHead: cap.head, setup: match, initial,
  inputPath, inputSHA256:hash(inputPath), restore, frozenPre, driverSHA256: hash(`${P}/run-natural.mts`),
  environment:{node:process.version,execArgv:process.execArgv}, parentFocusedResult:'/workspace/.playtest/bootstrap-deck-casualty-v2-20261016/native-focused-35460-36000/result.json',
  predecessorSource:'/workspace/.playtest/bootstrap-deck-casualty-v2-20261016/source.json', predecessorCausalReport:'/workspace/.playtest/bootstrap-deck-casualty-v2-20261016/OOM-40350-CAUSAL-REPORT.json' };

const rows: any[] = [], shipLosses: any[] = [], removals: any[] = [], transitions: any[] = [];
let commands = 0, hits = 0, eventInputCount = 0, beforeUnits = new Map<string, any>();
mkdirSync(`${D}/frames`);
for (const file of ['commands.jsonl', 'hits.jsonl', 'events.jsonl']) writeFileSync(`${D}/${file}`, '');
const slim = (u: any) => ({ id: u.id, owner: u.owner, kind: u.kind, hp: u.hp, maxHp: u.maxHp,
  x: u.x, y: u.y, deck: u.deck ? json(u.deck) : null, expiresTick: u.expiresTick ?? null, isShip: !!u.sailing });
let observedUnits = new Map<string, any>(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
function recordChanges(phase: string) {
  const now = new Map<string, any>(g.units.map((u: any) => [u.id, u]));
  let lostShip = false, changedDeck = false;
  for (const [id, before] of observedUnits) {
    const unit = now.get(id);
    if (!unit || unit.hp <= 0) {
      const event = { tick: g.tick, phase, event: 'native-dead-or-removed', unit: before, permanent: before.expiresTick === null };
      removals.push(event);
      appendFileSync(`${D}/events.jsonl`, JSON.stringify(event) + '\n');
      if (before.isShip) {
        const loss = { tick: g.tick, phase, event: 'ship-removal', ship: before,
          passengers: [...beforeUnits.values()].filter(u => u.deck?.shipId === id),
          observedBeforePassengers: [...observedUnits.values()].filter(u => u.deck?.shipId === id) };
        shipLosses.push(loss);
        appendFileSync(`${D}/events.jsonl`, JSON.stringify(loss) + '\n');
        lostShip = true;
      }
    } else if ((before.deck?.shipId ?? null) !== (unit.deck?.shipId ?? null)) {
      const event = { tick: g.tick, phase, event: 'deck-parent-change', before, after: slim(unit) };
      transitions.push(event); changedDeck = true;
      appendFileSync(`${D}/events.jsonl`, JSON.stringify(event) + '\n');
    }
  }
  if(changedDeck || lostShip) writeFileSync(D+'/event-inputs/'+g.tick+'-'+(++eventInputCount)+'-'+phase.split(';')[0].replaceAll(' ','_')+'.json.gz',gzipSync(JSON.stringify({tick:g.tick,snapshot:snapshotGame(g),nextId:g.nextId,memories:memories(),phase,classification:'Exact recorded event state; restore validity and remaining command phase require separate audit, not automatically an independent resume checkpoint.'})+'\n'));
  observedUnits = new Map(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
  return lostShip;
}
function summary() {
  return Object.fromEntries(owners.map(owner => [owner, { gold: g.players[owner].gold, supplyUsed: g.players[owner].supplyUsed,
    supplyCap: g.players[owner].supplyCap, units: g.units.filter((u: any) => u.owner === owner && u.hp > 0).length,
    buildings: g.buildings.filter((b: any) => b.owner === owner && b.hp > 0).length,
    halls: g.buildings.filter((b: any) => b.owner === owner && b.hp > 0 && b.kind === 'townHall').map((b: any) => ({ id: b.id, hp: b.hp, x: b.x, y: b.y })),
    policy: { naval: json(mem.get(owner)?.naval ?? null) } }]));
}
function publish(done = false) {
  const cpu = process.cpuUsage(cpuStart);
  writeFileSync(`${D}/result.json.tmp`, JSON.stringify({ provenance, pid: process.pid, startedAtTick: 40350, end: g.tick,
    finished: done, completed: !!g.match.winner, winner: g.match.winner, elapsedMs: performance.now() - started,
    cpuMs: (cpu.user + cpu.system) / 1000, resources: {memory:process.memoryUsage(),usage:process.resourceUsage()}, commandCount: commands, hitCount: hits, sourcePre,
    sourcePost: done ? sourceCheck() : null, frozenPost: done ? frozenCheck() : null,
    finalStats: json(g.match.stats), final: summary(), rows, shipLosses, removals, transitions }) + '\n');
  renameSync(`${D}/result.json.tmp`, `${D}/result.json`);
}
function save(reason: string) {
  const state = { tick: g.tick, snapshot: snapshotGame(g), nextId: g.nextId, memories: memories(),
    memoryLifecycle: g.tick === 0 ? 'Null means absent fresh provider memory before first think; no policy memory seeded.' : undefined };
  writeFileSync(`${D}/frames/${g.tick}.json.gz`, gzipSync(JSON.stringify(state) + '\n'));
  rows.push({ tick: g.tick, reason, resources: {memory:process.memoryUsage(),usage:process.resourceUsage()}, stats: json(g.match.stats), players: summary(), nextId: g.nextId,
    worldFrame: `frames/${g.tick}.json.gz` });
  publish();
}
g.observer = { hit(source: any, target: any, damage: number, before: number) {
  hits++;
  const sinkingPassengers = target.sailing && before > 0 && target.hp <= 0 ? g.units.filter((u: any) => u.deck?.shipId === target.id).map(slim) : undefined;
  const hit=json({tick:g.tick,sourceId:source.id,sourceKind:source.kind,sourceOwner:source.owner,targetId:target.id,targetKind:target.kind,targetOwner:target.owner,targetExpiresTick:target.expiresTick??null,damage,before,after:target.hp,sinkingPassengers});
  appendFileSync(`${D}/hits.jsonl`, JSON.stringify(hit)+'\n');
} };
writeFileSync(`${D}/launch.json`, JSON.stringify({ pid: process.pid, tick: g.tick, startedAtUtc: new Date().toISOString(), sourcePre,
  frozenPre, restore, inputPath, actualFactoryStart: false, driverSHA256: provenance.driverSHA256 }, null, 2) + '\n');
save('exact40350 postcommands restore; runtime source changes to pure bounded exact memo, no repeated40350think');
console.log(JSON.stringify({ event: 'actual-restored-start', pid: process.pid, tick: g.tick, head: cap.head, sourcePre, frozenPre, initial }));
// Native-only first step respects the captured post-command phase. The expected
// state comes from the uncached exact diagnostic, independently equal to FIFO128.
beforeUnits = new Map(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
stepGame(g);
recordChanges('after-first-native-step; no40350AIrepeat');
const expected = JSON.parse(gunzipSync(readFileSync('/workspace/.playtest/bootstrap-deck-casualty-v2-20261016/native-cache-disabled-40350/after-state.json.gz')).toString());
const firstNativeStep = {world:isDeepStrictEqual(json(snapshotGame(g)),expected.snapshot),nextId:g.nextId===expected.nextId,bothMem:isDeepStrictEqual(memories(),expected.memories),tick:g.tick};
writeFileSync(D+'/first-native-step-closure.json',JSON.stringify(firstNativeStep,null,2)+'\n');
assert.ok(firstNativeStep.world && firstNativeStep.nextId && firstNativeStep.bothMem && g.tick===40351);
save('40351 first exact native step complete before next normal owner think');
console.log(JSON.stringify({event:'first-native-step-closed',pid:process.pid,...firstNativeStep}));
runAiGameLoop({ ...match, maxTicks: Number.MAX_SAFE_INTEGER, game: g, commandPlanner: planner }, {
  onCommand({ tick, owner, source, scriptId, command }: any) {
    commands++;
    appendFileSync(`${D}/commands.jsonl`, JSON.stringify({ tick, owner, source, scriptId, command }) + '\n');
    recordChanges('after-command; event only, not an independent resume checkpoint');
  },
  beforeStep() {
    beforeUnits = new Map(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
  },
  onStep() {
    const lostShip = recordChanges('after-step');
    if (g.tick % 1200 === 0 || g.match.winner || lostShip) save(lostShip ? 'ship removal; restore validity audited separately' : '1200 periodic or natural terminal');
    if (g.tick % 1200 === 0) console.log(JSON.stringify({ event: 'progress', pid: process.pid, tick: g.tick,
      stats: json(g.match.stats), players: summary() }));
  },
});
if (rows.at(-1)?.tick !== g.tick) save('natural terminal');
publish(true);
console.log(JSON.stringify({ event: 'natural-complete', pid: process.pid, tick: g.tick, winner: g.match.winner,
  sourcePost: sourceCheck(), frozenPost: frozenCheck(), stats: json(g.match.stats) }));
