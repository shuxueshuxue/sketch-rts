import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import assert from'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-sole-loss-0f5bf-20261016',W='/workspace/sketch-rts-knight-integrated-0f5bf-control',imp=(p:string)=>import(pathToFileURL(W+'/'+p).href);
const[{setBuildingBodies},{deckPlacement,deckPointFits,deckStaticPathExists,deckWalkPathExists},{connectedSurfacePath},{localToWorld,shipProfile},{combatCapability},{isInCabin},{canReach}]=await Promise.all([imp('src/shared/terrain.ts'),imp('src/shared/decks.ts'),imp('src/shared/connected-decks.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/combat-capabilities.ts'),imp('src/shared/ship-cabin.ts'),imp('src/shared/naval.ts')]);
const f=JSON.parse(gunzipSync(readFileSync(D+'/key-sole-loss-34800-36000/inputs/35520.json.gz')).toString()),s=f.snapshot;setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const ship=s.units.find((u:any)=>u.id==='unit-p0-warship-1962'),victim=s.units.find((u:any)=>u.id==='unit-p0-raider-2245'),guards=s.units.filter((u:any)=>u.id.startsWith('guard-2-'));
const rows=[];
for(const x of [-24,-40,-56,-72,-88])for(const y of [-16,0,16]){
 const preferred={x,y},local=deckPlacement(ship,victim,s.units,preferred,true);if(!local)continue;
 const world=localToWorld(ship,local),path=connectedSurfacePath(victim,world,s.units,s.map),fits=deckPointFits(ship,victim,local,s.units,true),walk=deckWalkPathExists(ship,victim,local,s.units),staticPath=deckStaticPathExists(ship,victim,local);
 rows.push({preferred,local,world,preferredGap:Math.hypot(local.x-x,local.y-y),fits,walk,staticPath,path,guardGaps:guards.map((g:any)=>({id:g.id,range:combatCapability(s,g).range,gap:Math.hypot(g.x-world.x,g.y-world.y),margin:Math.hypot(g.x-world.x,g.y-world.y)-combatCapability(s,g).range})),distance:Math.hypot(world.x-victim.x,world.y-victim.y)});
}
const legal=rows.filter(r=>r.local.x<-30&&r.fits&&r.walk&&r.staticPath&&r.path?.complete&&r.guardGaps.every(g=>g.margin>25));legal.sort((a,b)=>Math.min(...b.guardGaps.map(g=>g.margin))-Math.min(...a.guardGaps.map(g=>g.margin))||a.distance-b.distance);
const chosen=legal[0]??null;
writeFileSync(D+'/deck-retreat-query.json',JSON.stringify({classification:'Existing native deckPlacement/body/floor/connectedSurfacePath queries on actual35520 input. Hypothetical command destination only; never relocates any body. Instant range margin alone does not prove future safety; public execution test is separate.',tick:35520,ship:ship.id,victim:victim.id,profile:shipProfile(ship),isInCabin:isInCabin(victim),actualDeck:victim.deck,actualWorld:{x:victim.x,y:victim.y},rows,chosen},null,2)+'\n');console.log(JSON.stringify({actualDeck:victim.deck,chosen},null,2));
