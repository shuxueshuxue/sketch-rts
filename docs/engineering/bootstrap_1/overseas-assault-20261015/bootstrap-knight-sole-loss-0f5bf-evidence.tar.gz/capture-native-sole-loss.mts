import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015',Q='/workspace/.playtest/bootstrap-knight-sole-loss-0f5bf-20261016',W='/workspace/sketch-rts-knight-integrated-0f5bf-control';
const start=Number(process.argv[2]),end=Number(process.argv[3]),label=process.argv[4];
assert.ok(Number.isSafeInteger(start)&&start>=1200&&start%1200===0&&end>start&&end<=start+1200&&/^[a-z0-9-]+$/.test(label));
const R=`${Q}/key-${label}-${start}-${end}`;assert.equal(existsSync(R),false);mkdirSync(R);mkdirSync(`${R}/inputs`);
const cap=JSON.parse(readFileSync(`${D}/source.json`,'utf8')),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourceCheck=()=>Object.entries(cap.files).every(([p,h])=>hash(`${W}/${p}`)===h);assert.ok(sourceCheck());
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href),json=(x:any)=>JSON.parse(JSON.stringify(x));
const [{bootstrapGame,bootstrapMatches},{runAiGameLoop},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyRoot},{restoreSnapshotIntoGame,snapshotGame}]=await Promise.all([
 imp('src/ai/bootstrap_1/benchmark.ts'),imp('src/ai/game-runner.ts'),imp('src/ai/planner-context.ts'),imp('scripts/bootstrap_1-planner.ts'),imp('src/shared/sim.ts')]);
const f=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${start}.json.gz`)).toString()),expected=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${end}.json.gz`)).toString());
const selection=cap.selection,match=bootstrapMatches(selection.seed,[selection.mapId],end,false).find((m:any)=>m.subject===selection.subject&&m.side===selection.side&&m.agents.p0.race===selection.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v5');
const g=bootstrapGame(match),mem=createAiMemoryProvider(),memories=()=>Object.fromEntries(Object.keys(match.agents).map(o=>[o,mem.get(o)??null]));
restoreSnapshotIntoGame(g,f.snapshot,f.nextId);for(const[o,m]of Object.entries(f.memories))if(m!==null)mem.set(o,structuredClone(m));
const restore={world:isDeepStrictEqual(json(snapshotGame(g)),f.snapshot),nextId:g.nextId===f.nextId,bothMem:isDeepStrictEqual(memories(),f.memories)};assert.ok(Object.values(restore).every(Boolean));
const frozen=frozenPolicyRoot();assert.ok(Object.entries(cap.frozenFiles).every(([p,h])=>hash(`${frozen}/${p}`)===h));
const planner=await createBootstrapCommandPlanner(mem),commands:any[]=[],hits:any[]=[],observerPhases:any[]=[],parents:any[]=[];
const trace:any[]=[], healingEffects:any[]=[]; const roles=new Set(['unit-p0-warship-1962','unit-p0-raider-2245','unit-p0-knight-2183','unit-p0-cutter-1131','unit-p0-priest-2118','unit-p0-warship-1064','unit-p0-warship-1104','guard-2-0','guard-2-1','guard-2-2']); let lastHeal='';
function observe(){trace.push({tick:g.tick,units:g.units.filter((u:any)=>roles.has(u.id)).map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,order:json(u.order),deck:u.deck?json(u.deck):null,abilityCooldowns:u.abilityCooldowns,autocast:u.autocast,cooldown:u.cooldown,xp:u.xp,level:u.level,effects:json(u.effects),sailing:u.sailing?{heading:u.sailing.heading,speed:u.sailing.speed,velocityX:u.sailing.velocityX,velocityY:u.sailing.velocityY,routePoints:u.sailing.route?.points?.length}:undefined}))}); const heal=g.effects.filter((e:any)=>e.type==='heal'&&e.sourceId==='unit-p0-priest-2118'); const sig=JSON.stringify(heal.map((e:any)=>e.id)); if(sig!==lastHeal){for(const e of heal)if(!healingEffects.some((x:any)=>x.effect.id===e.id))healingEffects.push({observedAt:g.tick,effect:json(e)});lastHeal=sig;}}
let phase='command-phase',previousParents=new Map<string,any>(g.units.map((u:any)=>[u.id,u.deck?.shipId??null]));
const capture=()=>writeFileSync(`${R}/inputs/${g.tick}.json.gz`,gzipSync(JSON.stringify({tick:g.tick,snapshot:snapshotGame(g),nextId:g.nextId,memories:memories()})+'\n'));
capture();observe();
function parentChanges(){for(const u of g.units){const before=previousParents.get(u.id),after=u.deck?.shipId??null;if(before!==undefined&&before!==after)parents.push({tick:g.tick,phase,id:u.id,owner:u.owner,kind:u.kind,before,after,x:u.x,y:u.y,hp:u.hp});}previousParents=new Map(g.units.map((u:any)=>[u.id,u.deck?.shipId??null]));}
g.observer={hit(a:any,t:any,damage:number,before:number){const row={tick:g.tick,sourceId:a.id,sourceKind:a.kind,sourceOwner:a.owner,targetId:t.id,targetKind:t.kind,targetOwner:t.owner,damage,before,after:t.hp,sinkingPassengers:t.sailing&&t.hp<=0?g.units.filter((u:any)=>u.deck?.shipId===t.id).map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:json(u.deck),expiresTick:u.expiresTick??null,isShip:!!u.sailing})):undefined};hits.push(json(row));observerPhases.push({...json(row),phase,targetExpiresTick:t.expiresTick??null});}};
runAiGameLoop({...match,game:g,maxTicks:end,commandPlanner:planner},{onCommand:({tick,owner,source,scriptId,command}:any)=>{commands.push(json({tick,owner,source,scriptId,command}));parentChanges();},beforeStep:()=>{phase='native-step';},onStep:()=>{parentChanges();observe();if(g.tick%15===0||g.match.winner)capture();phase='command-phase';}});
const eCommands=readFileSync(`${D}/commands.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.tick>=start&&x.tick<end);
const allHits=readFileSync(`${D}/hits.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));
// Public command hits at start belong to the resumed window; native-step hits
// at start belong to its predecessor. Preserve the boundary explicitly.
const startCount=hits.filter(x=>x.tick===start).length,endCount=hits.filter(x=>x.tick===end).length;
const atStart=allHits.filter(x=>x.tick===start),atEnd=allHits.filter(x=>x.tick===end);
const eHits=[...(startCount?atStart.slice(-startCount):[]),...allHits.filter(x=>x.tick>start&&x.tick<end),...atEnd.slice(0,endCount)];
const actualHits=hits;
const checks={world:isDeepStrictEqual(json(snapshotGame(g)),expected.snapshot),nextId:g.nextId===expected.nextId,bothMem:isDeepStrictEqual(memories(),expected.memories),commands:isDeepStrictEqual(commands,eCommands),hits:isDeepStrictEqual(actualHits,eHits)};
const out={classification:'Same fixed-source <=1200 replay reconstructs actual ordinary0 decision inputs from its saved periodic fullworld/id/bothmem. This is validation of the existing real game, not another scored game or attribution control. Captured inputs are after-step before-think checkpoints, not live original-process full sampling.',start,end:g.tick,winner:g.match.winner,source:cap.head,sourcePre:true,sourcePost:sourceCheck(),restore,checks,commands:commands.length,hits:actualHits.length,hitBoundary:{note:'At start include trailing command hits, at end include leading native-step hits; counts supplied by replay because original observer did not tag phase. Whole world/id/bothmem and all public commands independently close the complete window.',startCount,endCount,originalStartCount:atStart.length,originalEndCount:atEnd.length},parents,observerPhases,publicFatalHits:observerPhases.filter(h=>h.phase==='command-phase'&&h.before>0&&h.after<=0),startBoundaryHits:observerPhases.filter(h=>h.tick===start)};
writeFileSync(`${R}/role-trace.json`,JSON.stringify(trace)+'\n');writeFileSync(`${R}/healing-effects.json`,JSON.stringify(healingEffects,null,2)+'\n');
writeFileSync(`${R}/result.json`,JSON.stringify(out,null,2)+'\n');writeFileSync(`${R}/commands.json`,JSON.stringify(commands)+'\n');writeFileSync(`${R}/hits.json`,JSON.stringify(hits)+'\n');
if(!Object.values(checks).every(Boolean))writeFileSync(`${R}/actual-end.json.gz`,gzipSync(JSON.stringify({snapshot:snapshotGame(g),nextId:g.nextId,memories:memories()})+'\n'));
console.log(JSON.stringify({...out,observerPhases:out.observerPhases.length,parents:out.parents.length},null,2));assert.ok(Object.values(checks).every(Boolean));
