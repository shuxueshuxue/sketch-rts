只读因果与原生公开指令游玩；不是AI候选成绩，不是ordinary0重跑或bootstrap验收。

来源：固定0f5bf01a05046169d4fb42322376f767b97bcc83，rulesVersion2/frozen184；原普通0 0→44441自然胜另封归原源。本包以原34800全world/nextId/双方memory重建34800→36000，与原36000及265 commands/101 hits严格闭合。15tick完整输入为该精确重演的采集，不冒称原运行每15tick原存档。

sole loss：船1962甲板raider2245@35616被neutral dragonWhelp guard-2-1击杀，此前redDragon等集火。2245与2183 knight攻击距离均72、同idle→原生带leash retaliation，非射手/近战之分。两人无装备/显式接舷、维修、转运任务；1962无ferry/outfit/service，是near-home招募上的combat-hull crew。三个真实fullplanner查询均与原当tick命令完全相等。

35526既有邻船priest2118已经把2245从125补满167，下一heal冷却240尚未到；不是缺治疗。船体425生命、沿岸力量门满足，并不能保船员。2245全过程未对怪输出；1962炮首火35463，支援舰1131首火35641/1104首火35776均晚于阵亡，1064未命中此营地。战略可到达与总力量不等于及时输出。

三个手动分支只对2245加公开命令，双方正常AI照常执行、未移body/改怪/删命令/改资源，source1443前后全同，frozen184实核。35460原地hold：2245末125、骑士末110；35520原生可达甲板move+queuedhold：2245末125、骑士末125；35580已伤91时甲板move+queuedhold：2245末38，仍存活。前三支35880均已清全部3龙且无待飞营地弹，均无我方永久死亡。受害者仍可处于怪瞬时射程，实际由骑士继续前行分担直接火力，退后者仍受6点范围伤；不叫绝对安全点或无代价。

整组反证：35460同时hold同舰2183+2245，至35880两者167/256，但另一舰raider2068@35713被redDragon杀，尚余两龙81/7.40。故不能用单人正例背书全部idle/自发attack船员都hold。此支仅观察至35880，不称营地清理完成。

船舱真实拒绝这些non-walking crew。甲板路径使用native deckPlacement/static/walk，connectedSurfacePath同甲板undefined不等于不能走；手动分支实际执行了甲板步行。深 aft point多数被cabins/mast/body阻挡；保留查询chosen=null而不造安全点。画面为原源native client renderer的35520/35610真实输入。

initial-read-filter-error.json保留早期只看unitId漏unitIds的诊断错误；initial-read.json已正确。35526目前仅逐tick trace/heal effect，并无该tick完整mem输入，不能独立作exact续局起点。
