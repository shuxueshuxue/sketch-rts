# 岸上登船准入与实际放置的独立只读审查

审查源是干净的 `a7e0ccaa108c7eab1ebd959ff312dd378eb8e804`。实际输入是 208201 tick 完整存档，SHA256 `1859a1b5be8049d5de7ef550b8cd2a8872131e192a57fd2bdeb6a976995eb576`。独立复核全部 1474 个源文件和冻结 revision `d1ae110f2edd99f9c7d899ed61557891ab587639` 的 184 项 manifest 哈希，前后均一致；未启动 Game、step、planner、公开命令、测试或修改生产代码。四次放置查询及私有复制上的一次 `boardUnit` 详见 query-result.json。

## 事实与原因

实际只有 25 人登船，其中 10 人在舱内、15 人露天，载荷 4768 / 9060.48、舱内配额 20 / 21，现有战力 19.44819319223813，小于原门槛 20.115569375546702。最后 ashHexer-23349 仍在岸上，离船壳 633.2669843085525 px，未处于 alongside。原始命令和 effect 流独立核实 207480–208200 共 49 次公开 board 尝试，均为 transient 拒绝且快照未变。

`checkCommandLegality` 的 board 分支（src/shared/sim/command-validation.ts:69）调用 `canBoard`；通过后 `issuePlayerCommand`（src/shared/sim.ts:718）再次用 canBoard 筛选，才写入 board 订单并计算岸边泊位。原 canBoard（src/shared/decks.ts:50）在载荷/船类/船舱/所有权等检查后调用 `deckPlacement` 的 center 偏好与默认 spacing=4。原生岸上登船在 `ferryUnits`（src/shared/sim.ts:1997）另等 alongside 后，调用 `boardUnit`（src/shared/decks.ts:59），使用 aft-port 偏好和 spacing=2。后者已在规则 2 源中存在，并非新提出的更宽身体或更大甲板。

同一真实 25 人姿态上，center/grid4 与 aft/grid4 均没有候选，center/grid2 和 aft/grid2 均找到 `(116.16, 0.03999999999999204)`。该点通过原 `deckPointFits` 的船板边界、固定设施和所有露天活人身体间隔，最近乘客净余量约 0.2980324 px；增加的真实体重为 85，仍远低于载荷上限。原生 boardUnit 在私有复制上确实返回 true。因而当前公开入口拒绝是采样漏检；当前所有权、质量和舱内配额不构成这次拒绝的原因。舱内配额只约束 enterCabin，露天登船并不消耗剩余 1 格舱位。

这不证明该远处单位已走到船旁，也不证明岸路、泊位、后来船姿或最后拥挤状态可达。私有复制的 26 人 / 战力 20.34819319223813 只说明当前放置几何，不是公开原生执行、真正第 26 人或胜利。

## 最小修复域

岸上可共享一个内部 shoreBoardingPlacement 调用，保持 boardUnit 原先的 aft-port、occupied=true、spacing=2，分别供岸上 canBoard 和 boardUnit 使用。保留 deckPlacement 本身及其他调用的默认 4px，不做 4→2 重试层、不改变实际放置坐标、不更改任何体型、质量、舱位、所有权、岸路或规则版本。

不能声称全域 `canBoard === boardUnit`：前者还支持另一船甲板上的友方/敌方 transfer，并检查来源船、船板高度或 gangway；后者明确拒绝已有 passenger.deck，另外也供召唤/旧货舱恢复的低层代码调用。转船在 updateBoardOrder（src/shared/sim.ts:1929）和 connected-decks.ts:223 的目的地预定仍为 4px，且 preferred 随入船方向变化。因此本次保持 passenger.deck 分支原查询，不把它扩大为 2px。same-deck、舱内、船类、陌生/同船来源等原否定边界原样保留。

严格数学意义上，也不能保证保留所有旧 canBoard 的 true：旧 center 偏好可直接命中非扫描格点，而实际 aft/grid2 未必能采到这个极窄洞。此前这种 true 本来就不能保证 boardUnit 成功。候选应保留实际 boardUnit 过去可接受的放置及已有正常准入合同，并用同一原语消除岸上查询与附件放置之间的几何分歧；不通过加入额外 center 特例伪造全旧布尔值不变。

## 确定性、成本和冻结边界

deckPlacement 为固定 y 外层、x 内层，严格 value < score 的确定性最近点查询；不读随机、时间或全局预算。共享同一调用不会增加随机性或新存档字段。当前载具 295.68×139.92，上述失败优先点时 4px 格有 2590 个、2px 格有 10360 个。仅枚举数是 4 倍；旧 canBoard 在中心可放时可 O(1) 直接返回，改为实际 aft 偏好后这类查询也可能扫描全格，因此不能保证热路径总成本仅四倍。query-result.json 中单次 9–24ms 包含冷启动/调度，不能作为 benchmark。候选须测实际聚焦成本，并避免把两种采样或缓存回退再叠加。

该查询不消费 ship-planning-budget 的 FIFO 八份船路预算，不能声称新增扫描受其限制。登船之后真实岸边航行仍经原生船路预算与碰撞合同。公开 SDK/网络的 transient 非法命令可记录尝试但不执行，原 49 次空操作与这个入口一致。

冻结加载器 scripts/bootstrap_1-planner.ts:25/42 从固定 Git revision 打包 AI、SDK 和 shared，且 createBootstrapCommandPlanner:61 对 v5/v7/v8 调用其独立 historical planner。manifest 中 decks.ts 哈希属于冻结历史源，不应被覆盖。若改 live shared/decks.ts，冻结策略及其私有 canBoard 不会自动迁移；但真正 Game 的公开命令验证和 native 执行会对所有 owner 统一采用新的 live 源。它是需要独立源归属与回归证据的低层行为修复，不能把之前普通 0 tick 的成绩挂到新源，也不能声称只影响我方 AI。

## 后续证据边界

根代理已另外授权在独立 a7 派生控制准备上述岸上域最小候选。此只读包保留旧拒绝证据，不因后续候选改写；转船、原始 accepted 合同、公开验证到真正 board 订单以及原生相关回归须单列。原 208201 实际 25 人和未获胜的结论保持不变。真实沿 633px 岸路的后来 attachment 仍需另一段原生证据。
