import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const S='/workspace/sketch-rts-cabin-ferry-ade-control';
const P='/workspace/.playtest/cabin-clinical-loading-sequence-resume-20261016';
const O='/workspace/.playtest/boarding-admission-independent-review-20261016';
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const assert=(ok:any,message:string)=>{if(!ok)throw new Error(message);};
const read=(path:string)=>JSON.parse(readFileSync(path,'utf8'));
const cap=read(P+'/fixed-runtime.json');
const manifest=read(S+'/docs/engineering/bootstrap_1/frozen-policy.json');
const proof=()=>{
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
 const changed=Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);
 const frozenChanged=Object.entries(manifest.files).filter(([p,h])=>sha(execFileSync('git',['-C',S,'show',manifest.revision+':'+p],{maxBuffer:8*1024*1024}))!==h).map(([p])=>p);
 assert(head===cap.head&&!status&&!changed.length&&!frozenChanged.length,'Source or frozen baseline changed');
 return {head,status,sourceFiles:Object.keys(cap.hashes).length,changed,frozenRevision:manifest.revision,rulesVersion:manifest.rulesVersion,frozenFiles:Object.keys(manifest.files).length,frozenChanged};
};
const sourcePre=proof();
const raw=readFileSync(P+'/final.json.gz');
const saved=JSON.parse(gunzipSync(raw).toString());
const before=JSON.stringify(saved);
assert(sha(raw)==='1859a1b5be8049d5de7ef550b8cd2a8872131e192a57fd2bdeb6a976995eb576','Wrong actual input');
const snapshot=saved.snapshot;
const load=(p:string)=>import(pathToFileURL(S+'/'+p).href);
const [decks,geometry,cabin,body,naval,legality,strength,math]=await Promise.all([
 load('src/shared/decks.ts'),load('src/shared/ship-geometry.ts'),load('src/shared/ship-cabin.ts'),load('src/shared/physical-body.ts'),
 load('src/shared/naval.ts'),load('src/shared/sim/command-validation.ts'),load('src/ai/policy/v6/strength.ts'),load('src/shared/navigation-math.ts')]);
const hull=snapshot.units.find((u:any)=>u.id==='unit-p0-carrier-25442');
const target=snapshot.units.find((u:any)=>u.id==='unit-p0-ashHexer-23349');
const profile=geometry.shipProfile(hull);
const cargo=geometry.shipPassengers(snapshot.units,hull);
const grid:any[]=[];
for(const spacing of [4,2]) for(const name of ['center','aft']) {
 const preferred=name==='center'?{x:0,y:0}:{x:-profile.length/2,y:-profile.beam/2};
 const at=performance.now();
 const point=decks.deckPlacement(hull,target,snapshot.units,preferred,true,spacing)??null;
 let xCount=0,yCount=0;for(let x=-profile.length/2;x<=profile.length/2;x+=spacing)xCount++;for(let y=-profile.beam/2;y<=profile.beam/2;y+=spacing)yCount++;
 grid.push({spacing,preferred:name,point,wallMs:performance.now()-at,enumeratedGridCandidates:xCount*yCount,preferredFits:decks.deckPointFits(hull,target,preferred,snapshot.units,true)});
}
const actualPublicCanBoard=decks.canBoard(hull,target,snapshot.units);
const publicLegality=legality.checkCommandLegality(snapshot,'p0',{type:'board',unitIds:[target.id],transportId:hull.id})??null;
const copy=structuredClone(snapshot);
const copyHull=copy.units.find((u:any)=>u.id===hull.id),copyTarget=copy.units.find((u:any)=>u.id===target.id);
const conditionalAttach=decks.boardUnit(copyHull,copyTarget,copy.units);
const point=copyTarget.deck;
const open=cargo.filter((u:any)=>!cabin.isInCabin(u));
const nearestCrew=point?open.map((u:any)=>({id:u.id,clearance:Math.hypot(point.x-u.deck.x,point.y-u.deck.y)-target.radius-u.radius-1})).sort((a:any,b:any)=>a.clearance-b.clearance)[0]:null;
const nearestFitting=point?profile.obstacles.map((o:any)=>({type:o.type,clearance:Math.hypot(point.x-o.x,point.y-o.y)-target.radius-o.radius-1})).sort((a:any,b:any)=>a.clearance-b.clearance)[0]:null;
const attempts=readFileSync(P+'/commands.jsonl','utf8').trim().split('\n').map(JSON.parse).filter((x:any)=>x.owner==='p0'&&x.command.type==='board'&&x.command.unitIds.includes(target.id));
const effects=gunzipSync(readFileSync(P+'/effects.jsonl.gz')).toString().trim().split('\n').map(JSON.parse).filter((x:any)=>x.owner==='p0'&&x.command.type==='board'&&x.command.unitIds.includes(target.id));
assert(attempts.length===49&&effects.length===49,'Unexpected clinical attempt count');
assert(!actualPublicCanBoard&&publicLegality&&conditionalAttach,'Mismatch not reproduced');
assert(!grid[0].point&&!grid[1].point&&grid[2].point&&grid[3].point,'Grid mismatch not reproduced');
assert(effects.every((x:any)=>!x.snapshotChanged&&x.legalityBefore?.transient===true),'Unexpected real board command effect');
assert(JSON.stringify(saved)===before&&sha(readFileSync(P+'/final.json.gz'))===sha(raw),'Actual input mutated');
const totalPower=(s:any)=>geometry.shipPassengers(s.units,s.units.find((u:any)=>u.id===hull.id)).reduce((n:number,u:any)=>n+strength.effectiveCombatRating(s,u),0);
const result={
 classification:'Independent read-only actual 208201 boarding admission mismatch. Four placement queries, one native canBoard, one public legality query and one boardUnit mutation on a private copy only. No Game instance, step, planner, public command issuer, tests or production edit; no actual additional passenger credited.',
 sourcePre,sourcePost:proof(),input:{path:P+'/final.json.gz',sha256:sha(raw),tick:snapshot.tick},
 actual:{cargo:cargo.length,inside:cargo.filter(cabin.isInCabin).length,open:open.length,power:totalPower(snapshot),required:20.115569375546702,winner:snapshot.match.winner??null,load:decks.deckLoad(snapshot.units,hull),massToAdd:body.bodyMass(target),capacity:profile.loadCapacity,usage:cabin.shipCabinUsage(snapshot,hull),target:{id:target.id,owner:target.owner,kind:target.kind,hp:target.hp,radius:target.radius,deck:target.deck??null,cabin:target.cabin??null,order:target.order,distanceToHull:geometry.distanceToHull(hull,target),alongside:naval.alongside(target,hull)},hull:{id:hull.id,owner:hull.owner,length:profile.length,beam:profile.beam}},
 pureQueries:{actualPublicCanBoard,publicLegality,grid,conditionalAttachOnPrivateCopy:conditionalAttach,conditionalLocalPoint:point,nativePointFits:point&&decks.deckPointFits(copyHull,copyTarget,point,copy.units,true),nativeFloorDiskFits:point&&math.diskInConvex(point,target.radius+1,profile.deck),nearestCrew,nearestFitting,conditionalCargo:geometry.shipPassengers(copy.units,copyHull).length,conditionalPower:totalPower(copy),scope:'Private copy attachment proves only current deck/mass geometry, not a legal real public board order, shore travel or native arrival.'},
 originalClinicalAttempts:{count:attempts.length,firstTick:attempts[0].tick,lastTick:attempts.at(-1).tick,effectsRecords:effects.length,allTransientRejected:effects.every((x:any)=>x.legalityBefore?.transient===true),allSnapshotUnchanged:effects.every((x:any)=>x.snapshotChanged===false),messages:[...new Set(effects.map((x:any)=>x.legalityBefore?.message))]},
 limitations:['Single-call wall times include module/runtime noise and are not performance benchmarks. Enumerated grid count is deterministic theoretical work when preferred point does not fit.','Pure placement may populate native weak caches but actual serialized save is unchanged.','A shore admission fix must not be represented as universal canBoard === boardUnit: canBoard deliberately supports ship-to-ship boarding, while boardUnit rejects any current deck.','Current original frozen planners keep their own archived shared helpers; changing live shared simulation changes every owner execution and requires separate source attribution, even if rulesVersion remains 2.']
};
writeFileSync(O+'/query-result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({source:result.sourcePost,actual:result.actual,queries:result.pureQueries,attempts:result.originalClinicalAttempts},null,2));
