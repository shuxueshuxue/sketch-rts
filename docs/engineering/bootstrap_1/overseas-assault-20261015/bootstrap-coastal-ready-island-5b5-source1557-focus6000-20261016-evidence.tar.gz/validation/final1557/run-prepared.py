#!/usr/bin/env python3
"""Exactly one root-handed-off validation stage on frozen1557; never auto-chain."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,tarfile,time
D=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('target',choices=['pure56','native-related176','tsc1024']);p.add_argument('--handoff-note',required=True);a=p.parse_args()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();wr=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
capPath=D/'PREPARED-SOURCE-EQUIVALENCE.json';cap=json.loads(capPath.read_text());C=Path(cap['control']);capsha=h(capPath);stem=a.target
assert cap['head']=='5b5aead30978f7a13601b3ae6be848f70a3b1493' and len(cap['sourceFiles'])==1557
assert os.environ.get('TSX_DISABLE_CACHE')=='1','Root externalenv required'
module=C/'node_modules/tsx/dist/index-XurvG3JN.mjs';module_sha=h(module);assert module_sha=='128dc5756da9bec342781ee30127611c958f921e15016b06dd866de28d906245'
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==cap['head']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
 bad=[p for p,r in cap['sourceFiles'].items() if h(C/p)!=r['sha256']];assert not bad,bad
 return True
def frozen():
 fp=json.loads(Path('/tmp/bootstrap-coastal-febb-integration-20261016/PREPARED-VALIDATION-PLAN.json').read_text());archive=Path(fp['frozenArchive']['path']);assert h(archive)==fp['frozenArchive']['sha256'];files={}
 with tarfile.open(archive,'r:gz') as t:
  for member in t.getmembers():
   if member.isfile():files[member.name]={'bytes':member.size,'sha256':hashlib.sha256(t.extractfile(member).read()).hexdigest()}
 assert files==fp['frozenFiles'] and len(files)==497
 manifest=C/'docs/engineering/bootstrap_1/frozen-policy.json';v=json.loads(manifest.read_text());assert len(v['files'])==184 and v['rulesVersion']==2 and h(manifest)=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
 return {'atUTC':now(),'canonicalFrozen497EveryMemberExact':True,'archiveSHA256':h(archive),'manifest184SHA256':h(manifest),'rulesVersion':2}
def prior(target,count):
 r=json.loads((D/(target+'-execution.json')).read_text());assert r['exit']==0 and r['validationExit']==0 and r['sourceHead']==cap['head'] and r['sourceCapSHA256']==capsha and r['source1557ExactAfter'] and r['frozenPost']
 assert r['actualCounts']=={'passed':count,'failed':0,'skipped':0,'unique':count} and r['caseIDsExactlyExpected'];return r
if stem!='pure56':prior('pure56',56)
if stem=='tsc1024':prior('native-related176',176)
plan=None
if stem!='tsc1024':
 plan=json.loads((D/('PREPARED-'+stem.upper()+'-PLAN.json')).read_text());assert plan['sourceHead']==cap['head'] and plan['sourceCapSHA256']==capsha
exact();fp=frozen();assert not(D/(stem+'-execution.json')).exists() and not(D/(stem+'-started.json')).exists() and not(D/(stem+'-guard75.json')).exists(),'One actual stage or guard refusal only, no overwrite/retry'
required=1024**3 if stem=='pure56' else 2*1024**3;fresh=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());heap=512 if stem=='pure56' else 1024 if stem=='tsc1024' else 768
r={'target':stem,'atUTC':now(),'launcherPID':os.getpid(),'handoffNote':a.handoff_note,'classification':'True0Game56 only: pure planning/publication, no createGame/restore/issue/step.' if stem=='pure56' else 'Native-related contracts or noEmit compilation; not0Game or match completion.','sourceHead':cap['head'],'sourceCapSHA256':capsha,'source1557ExactBefore':True,'headroomBefore':fresh,'requiredHeadroom':required,'heapMiB':heap,'singleFork':stem!='tsc1024','moduleIsolation':stem!='tsc1024','parentEnvironment':{'TSX_DISABLE_CACHE':'1'},'tsxInstalledModule':{'path':str(module),'sha256':module_sha,'scope':'Inherited parent env; no assertion Vitest uses tsx or option caused timing/memory change.'},'frozenPre':fp,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text(),'driverSHA256':h(Path(__file__))}
if fresh<required:wr(D/(stem+'-guard75.json'),r);print(json.dumps(r));raise SystemExit(75)
args=['node',f'--max-old-space-size={heap}']
if stem=='tsc1024':args+=['node_modules/typescript/bin/tsc','--noEmit']
else:
 config=D/('vitest-'+stem+'.config.mts');assert h(config)==plan['configSHA256'];r['configSHA256']=h(config);r['planSHA256']=h(D/('PREPARED-'+stem.upper()+'-PLAN.json'))
 args+=['node_modules/vitest/vitest.mjs','run','--config',str(config),'--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(D/(stem+'.json'))]
r.update(args=args,startedAtUTC=now());wr(D/(stem+'-started.json'),r);env=os.environ.copy();env.pop('NODE_OPTIONS',None);start=time.monotonic()
with (D/(stem+'.log')).open('xb') as out:
 child=subprocess.Popen(args,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT);r['actualNodePID']=child.pid;wr(D/(stem+'-started.json'),r);code=child.wait()
r.update(exit=code,endedAtUTC=now(),elapsedSeconds=time.monotonic()-start,oomAfter=Path('/sys/fs/cgroup/memory.events').read_text(),logSHA256=h(D/(stem+'.log')),tsxInstalledModuleExactAfter=h(module)==module_sha)
for name,check in [('source1557ExactAfter',exact),('frozenPost',frozen)]:
 try:r[name]=check()
 except Exception as e:r[name]=False;r[name+'Error']=repr(e);code=code or 1
if plan and (D/(stem+'.json')).exists():
 raw=json.loads((D/(stem+'.json')).read_text());actual=[]
 for suite in raw['testResults']:
  rel=str(Path(suite['name']).relative_to(C))
  for case in suite['assertionResults']:actual.append({'path':rel,'fullName':case['fullName'],'actualStatus':case['status'],'failureMessages':case.get('failureMessages',[])})
 ids={(c['path'],c['fullName']) for c in actual};expected={(c['path'],c['fullName']) for c in plan['cases']};r['actualCases']=actual;r['caseIDsExactlyExpected']=ids==expected and len(actual)==len(ids)
 r['actualCounts']={'passed':sum(c['actualStatus']=='passed' for c in actual),'failed':sum(c['actualStatus']=='failed' for c in actual),'skipped':sum(c['actualStatus'] not in ['passed','failed'] for c in actual),'unique':len(ids)};r['reportSHA256']=h(D/(stem+'.json'))
 if code==0 and (not r['caseIDsExactlyExpected'] or r['actualCounts']!={'passed':plan['caseCount'],'failed':0,'skipped':0,'unique':plan['caseCount']}):r['contractClosureError']=True;code=1
r['validationExit']=code;wr(D/(stem+'-execution.json'),r);print(json.dumps(r));raise SystemExit(code)
