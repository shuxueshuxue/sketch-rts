import {readFileSync} from 'node:fs';
import {transformSync} from '/workspace/sketch-rts/node_modules/esbuild/lib/main.js';
const source=readFileSync(new URL('./native-normal-267285.ts',import.meta.url),'utf8');
const out=transformSync(source,{loader:'ts',format:'esm',target:'node22'});
console.log(JSON.stringify({classification:'Parse/transform only; driver not imported/evaluated; no Game/P0/query/step',bytes:out.code.length,warnings:out.warnings}));
