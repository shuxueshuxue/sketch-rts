#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,resource,shutil,subprocess,time

D=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/workspace/sketch-rts-coastal-battery-explicit-target-control')
O=D/'natural-from-267285'
record=D/'native-launch-resource.json'
assert not record.exists() and not O.exists(), 'one independent normal launch only'
cap=json.loads((D/'fixed-source.json').read_text())
manifest=json.loads((D/'prelaunch-manifest.json').read_text())
assert cap['parentHead']=='ebd6860a1302c2a6efdd3f7061fbe820a6b3cad7'
assert cap['head']==manifest['sourceHead']
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD']).decode().strip()==cap['head']
assert not subprocess.check_output(['git','-C',str(C),'status','--porcelain'])
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(cap['hashes'])==1499
assert all(sha((C/p).read_bytes())==h for p,h in cap['hashes'].items())
assert sha((D/'native-normal-267285.ts').read_bytes())==manifest['driverSHA256']
for p,r in manifest['payloads'].items():
 b=(D/p).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],p
b=pathlib.Path('/sys/fs/cgroup')
pre={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'classification':'One independent fixedsource explicit building target normal3AI actualEBD saved267285 continuation; not ordinary0, same-source recovery or match acceptance',
     'sourceHead':cap['head'],'sourceFiles':1499,'heapMiB':768,
     'rawHeadroomBytes':int((b/'memory.max').read_text())-int((b/'memory.current').read_text()),
     'requiredRawHeadroomBytes':2147483648,'diskFreeBytes':shutil.disk_usage(D).free,
     'requiredDiskFreeBytes':268435456,'eventsBefore':(b/'memory.events').read_text(),
     'driverSHA256':manifest['driverSHA256'],'prelaunchManifestSHA256':sha((D/'prelaunch-manifest.json').read_bytes())}
record.write_text(json.dumps(pre,indent=2)+'\n')
if pre['rawHeadroomBytes']<pre['requiredRawHeadroomBytes'] or pre['diskFreeBytes']<pre['requiredDiskFreeBytes']:
 pre.update(classification='guard refused; zero Node/Game/P0/step',exitCode=75)
 record.write_text(json.dumps(pre,indent=2)+'\n');print(json.dumps(pre),flush=True);raise SystemExit(75)
with (D/'native.log').open('w') as log:
 p=subprocess.Popen(['node','--max-old-space-size=768','--import','tsx',str(D/'native-normal-267285.ts')],
                    cwd=C,stdout=log,stderr=subprocess.STDOUT)
 pre['actualPid']=p.pid;pre['spawnUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record.write_text(json.dumps(pre,indent=2)+'\n')
 print(json.dumps({'actualPid':p.pid,'spawnUTC':pre['spawnUTC'],'rawHeadroomBytes':pre['rawHeadroomBytes'],
                   'diskFreeBytes':pre['diskFreeBytes']}),flush=True)
 t=time.monotonic();rc=p.wait()
pre.update(exitCode=rc,elapsedSeconds=time.monotonic()-t,exitUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
           maxRssKiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
           eventsAfter=(b/'memory.events').read_text())
record.write_text(json.dumps(pre,indent=2)+'\n');print(json.dumps(pre),flush=True)
raise SystemExit(rc)
