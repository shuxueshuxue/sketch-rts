import {readFileSync,writeFileSync,mkdirSync,appendFileSync,renameSync,existsSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual as equal} from 'node:util';
import {NativeLedger} from './observer-ledger';

const D=dirname(import.meta.filename),O=join(D,'natural-from-267285');
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),copy=(v:any)=>JSON.parse(JSON.stringify(v));
const atomic=(path:string,value:any)=>{writeFileSync(path+'.tmp',value);renameSync(path+'.tmp',path);};
const cap=JSON.parse(readFileSync(join(D,'fixed-source.json'),'utf8')),S=cap.sourceRoot;
const prelaunch=JSON.parse(readFileSync(join(D,'prelaunch-manifest.json'),'utf8'));
const load=(p:string)=>import(pathToFileURL(join(S,p)).href);
if(process.cwd()!==S||existsSync(join(O,'actual-launch.json')))throw Error('Exact fixed cwd and new output required');
if(sha(readFileSync(import.meta.filename))!==prelaunch.driverSHA256)throw Error('driver changed');
for(const [name,record] of Object.entries(prelaunch.payloads) as any){const b=readFileSync(join(D,name));if(b.length!==record.bytes||sha(b)!==record.sha256)throw Error('bound payload changed:'+name);}
function verifySource(){
 const changed=Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(join(S,p)))!==h).map(([p])=>p);
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
 if(changed.length||head!==cap.head||status)throw Error('Fixed source changed');
 return{files:Object.keys(cap.hashes).length,head,status,changed};
}
const sourcePre=verifySource();
const raw=readFileSync(join(D,'input-actual267285-before-p0.json.gz'));
if(sha(raw)!=='b246ba179ad0c995edb35c877f21ab2cafc34d3eda7f1e60ce4e4dd791e30e09')throw Error('originalEBD actual267285 input changed');
const saved=JSON.parse(gunzipSync(raw).toString()),agents=JSON.parse(readFileSync(join(D,'agents.json'),'utf8'));
const expected=JSON.parse(readFileSync(join(D,'ORIGINAL-EBD-ACTUAL267285-P0.json'),'utf8'));
const originalHandoffInput=JSON.parse(gunzipSync(readFileSync(join(D,'input-original267300-before-p0.json.gz'))).toString());
const originalPrefix=JSON.parse(readFileSync(join(D,'ORIGINAL-EBD-267285-267300-RAW-PREFIX.json'),'utf8'));
const prefixCommands:any[]=[],prefixHits:any[]=[];
let originalPrefixProof:any;
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},
 {createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest},{runGameLoop},
 {narrowFrameCommandToLiveOperands,checkCommandLegality},{unitMover},{MOVE_ORDER_ARRIVAL_RANGE},{shipShorePoints}]=await Promise.all([
 load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),
 load('src/sdk/game-runner.ts'),load('src/shared/sim/command-validation.ts'),load('src/shared/catalog.ts'),load('src/shared/movement-rules.ts'),load('src/shared/connected-decks.ts')]);
const g=createGame('bareDuel'),m=createAiMemoryProvider();
restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);
for(const [owner,memory] of Object.entries(saved.memories))m.set(owner,copy(memory));
const full=()=>copy({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(Object.keys(saved.memories).map(owner=>[owner,m.get(owner)]))});
const initial=full(),restored={world:equal(initial.snapshot,saved.snapshot),nextId:initial.nextId===saved.nextId,all3mem:equal(initial.memories,saved.memories)};
if(g.tick!==267285||Object.values(restored).some(v=>!v))throw Error('strictworld/id3mem restore failed');
const frozenRoot=frozenPolicyRoot(),frozenFull=JSON.parse(readFileSync(join(D,'frozen-full-source-index.json'),'utf8'));
function verifyFrozen(){
 const changed=Object.entries(frozenPolicyManifest.files).filter(([p,h])=>sha(readFileSync(join(frozenRoot,p)))!==h).map(([p])=>p);
 const changedFull=frozenFull.payloads.filter((r:any)=>{const b=readFileSync(join(frozenRoot,r.path));return b.length!==r.bytes||sha(b)!==r.sha256;}).map((r:any)=>r.path);
 if(changed.length||changedFull.length||frozenFull.payloads.length!==497||frozenPolicyManifest.rulesVersion!==2||Object.keys(frozenPolicyManifest.files).length!==184)throw Error('Frozen rules2 changed');
 return{revision:frozenPolicyManifest.revision,rulesVersion:2,files:184,fullFrozenSourceFiles:497,changed,changedFull};
}
const frozenPre=verifyFrozen(),normal=await createBootstrapCommandPlanner(m);
if(!equal(full(),initial))throw Error('Planner setup mutated input');
mkdirSync(join(O,'frames'),{recursive:true});mkdirSync(join(O,'recent'),{recursive:true});mkdirSync(join(O,'p0-memory-after'),{recursive:true});mkdirSync(join(O,'owner-memory-after'),{recursive:true});
const names=['commands','command-dispositions','hits','events','samples','economy','p0-plans','think-hashes','native-step-costs','selected-leg-states','station-memory-ownership','selected-native-steps','selected-tactical-changes'];
for(const name of names)writeFileSync(join(O,name+'.jsonl'),'');
const emit=(name:string,row:any)=>appendFileSync(join(O,name+'.jsonl'),JSON.stringify(row)+'\n');
const counts={commands:0,hits:0,events:0,thinks:0},start=g.tick,startedAtUtc=new Date().toISOString();
const classification='Fixed explicit battery-target continuation on exact originalEBD actual267285 fullworld/nextId/all3mem. Changed-policy saved continuation, not same-source recovery, ordinary0 or fullmatch/generalization acceptance. Three normal AI, frozenv5+v7 rules2/resources/population/terrain unchanged. No human controls, suppression, injectedmem, private route, range padding or new native budget. Native movement completion, real explicit strategic target damage and later macro outcome are separate evidence. Same Game continues naturally;600cadence is only observation.';
let firstNativeLegCompletion:any,firstSelectedTerminal:any,firstOwnCrewDisembark:any,firstOwnCrewLoss:any,firstOwnCrewOwnerChange:any,firstEnemyBoard:any,previousLegPose:any;
const selectedHullId='unit-p0-bombardShip-50739',selectedCrewId='unit-p0-emberRavager-23742';
const initialSelectedVoyage=saved.memories.p0.naval.coastalVoyages[selectedHullId],initialSelectedLeg=copy(initialSelectedVoyage.waypoint),initialTargetId=initialSelectedVoyage.targetId;
let firstOwnedTargetHit:any;
let selectedLeg:any,firstStationMemoryRelease:any,stationGoalChanges=0,originalHandoffBoundary:any;
if(initialTargetId!=='building-p2-farm-4745'||!initialSelectedLeg)throw Error('Original actualstation voyage required; not injected state');
let commandIndex:number|undefined,stepStart=0,stepCPU:ReturnType<typeof process.cpuUsage>|undefined,selectedDamage=false;
let stopRequest:any,observationStop:any,firstP0Proof:any,first600:any,previousSelectedTactical:any;
const lastHit=new Map(Object.entries(JSON.parse(readFileSync(join(D,'inherited-last-native-hits.json'),'utf8'))));
const ledger=new NativeLedger(g.units,g.buildings);
for(const unit of g.units)if(unit.hp<=0)ledger.terminal.add(unit.id);
for(const building of g.buildings)if(building.hp<=0)ledger.buildingTerminal.add(building.id);
const cost={nativeSteps:0,nativeWallMs:0,nativeCpuMs:0,nativeMaxWallMs:0,p0Thinks:0,p0WallMs:0,p0CpuMs:0,p0MaxWallMs:0};
const capture=(stage:string)=>atomic(join(O,'frames',g.tick+'-'+stage+'.json.gz'),gzipSync(JSON.stringify({...full(),checkpointStage:stage,commandIndex,nextCommandIndex:counts.commands})));
const economyNow=()=>copy(Object.fromEntries(Object.keys(agents).map(owner=>[owner,{gold:g.players[owner].gold,goldSpent:g.match.stats.goldSpent[owner],neutralKills:g.match.stats.neutralUnitsKilled[owner]}])));
let previousEconomy=economyNow();
function economy(stage:string){const after=economyNow();if(!equal(after,previousEconomy)){emit('economy',{tick:g.tick,stage,commandIndex,before:previousEconomy,after,scope:'Actual native wallet/spent/neutralKill changes, not income attribution by itself; correlate actual hits and commands.'});previousEconomy=after;}}
function observe(stage:string){
 const hull=g.units.find((u:any)=>u.id===selectedHullId);
 if(hull&&selectedLeg&&!firstNativeLegCompletion&&!firstSelectedTerminal){
  const pose=copy({...hull,coastalVoyage:m.get('p0')?.naval?.coastalVoyages?.[selectedHullId],coastalRetreat:m.get('p0')?.naval?.coastalRetreat?.[selectedHullId],crew:g.units.find((u:any)=>u.id===selectedCrewId),enemyAboard:g.units.filter((u:any)=>u.hp>0&&(u.owner==='p1'||u.owner==='p2')&&u.deck?.shipId===selectedHullId)});
  if(stage==='after-step'||!equal(pose,previousLegPose)){emit('selected-leg-states',{tick:g.tick,stage,commandIndex,...pose});previousLegPose=pose;}
  const route=hull.sailing?.route,mark=selectedLeg;
  if(hull.owner==='p0' && hull.hp>0 && hull.order.type==='idle' && route?.partial===false && route.points.length===0
    && route.goalX===mark.x && route.goalY===mark.y && hull.arrivedAt?.x===mark.x && hull.arrivedAt?.y===mark.y && route.end && Math.hypot(hull.x-route.end.x,hull.y-route.end.y)<MOVE_ORDER_ARRIVAL_RANGE){
   firstNativeLegCompletion={tick:g.tick,stage,ship:pose,actualShorePoints:shipShorePoints(hull,g.map),selectedLeg:copy(selectedLeg),initialSelectedLeg,precedingGoalOwnershipTransitions:stationGoalChanges,actualDistanceToNativeEnd:Math.hypot(hull.x-route.end.x,hull.y-route.end.y),actualDistanceToPublicGoal:Math.hypot(hull.x-mark.x,hull.y-mark.y),scope:'Actual native idle order, complete empty matching route, matching arrivedAt and strict native distance-to-route.end arrival; not distance-to-publicgoal-only, a shot or strategic victory. Same Game continues.'};
   atomic(join(O,'first-native-leg-completion.json'),JSON.stringify(firstNativeLegCompletion,null,2));capture('first-native-leg-completion');
  }
 }
 const crew=g.units.find((u:any)=>u.id===selectedCrewId),enemyAboard=g.units.filter((u:any)=>u.hp>0&&(u.owner==='p1'||u.owner==='p2')&&u.deck?.shipId===selectedHullId);
 if(stage==='after-step'){
  const route=hull?.sailing?.route,target=g.buildings.find((b:any)=>b.id===initialTargetId);
  const projectiles=(g.projectiles??[]).filter((p:any)=>p.attackerId===selectedHullId||p.attackerId===selectedCrewId);
  emit('selected-native-steps',copy({tick:g.tick,hull:hull?{owner:hull.owner,hp:hull.hp,x:hull.x,y:hull.y,heading:hull.sailing?.heading,speed:hull.sailing?.speed,order:hull.order,cooldown:hull.cooldown,aim:hull.aim}:null,
   crew:crew?{owner:crew.owner,hp:crew.hp,deck:crew.deck,order:crew.order,cooldown:crew.cooldown,aim:crew.aim}:null,target:target?{id:target.id,owner:target.owner,hp:target.hp}:null,projectiles}));
  const tactical=copy({hull:hull?{owner:hull.owner,hp:hull.hp,order:hull.order,arrivedAt:hull.arrivedAt,aimTracking:hull.aim?.tracking,
   route:route?{goalX:route.goalX,goalY:route.goalY,intent:route.intent,targetId:route.targetId,partial:route.partial,end:route.end,pointCount:route.points.length}:null,pursuit:hull.sailing?.pursuit}:null,
   crew:crew?{owner:crew.owner,hp:crew.hp,deckShipId:crew.deck?.shipId,order:crew.order,aimTracking:crew.aim?.tracking}:null,target:target?{id:target.id,owner:target.owner,hp:target.hp}:null,projectileIds:projectiles.map((p:any)=>p.id)});
  if(!equal(tactical,previousSelectedTactical)){
   emit('selected-tactical-changes',{tick:g.tick,stage,before:previousSelectedTactical??null,after:tactical,scope:'Native target/order/route goal or vertex count/aim tracking/projectile/crew ownership changes; full frame saved. Per-step kinematics remain in compact stream.'});
   previousSelectedTactical=tactical;capture('selected-tactical-change');
  }
 }

 if(!firstEnemyBoard&&enemyAboard.length){firstEnemyBoard={tick:g.tick,stage,units:copy(enemyAboard)};capture('first-enemy-board');}
 if(!firstOwnCrewDisembark&&crew&&crew.hp>0&&crew.deck?.shipId!==selectedHullId){firstOwnCrewDisembark={tick:g.tick,stage,unit:copy(crew)};capture('first-owncrew-disembark');}
 if(!firstOwnCrewLoss&&(!crew||crew.hp<=0)){firstOwnCrewLoss={tick:g.tick,stage,unit:crew?copy(crew):null};capture('first-owncrew-terminal');}
 if(!firstOwnCrewOwnerChange&&crew&&crew.owner!=='p0'){firstOwnCrewOwnerChange={tick:g.tick,stage,unit:copy(crew)};capture('first-owncrew-owner-change');}
 if(!firstSelectedTerminal&&(!hull||hull.hp<=0||hull.owner!=='p0')){firstSelectedTerminal={tick:g.tick,stage,reason:!hull||hull.hp<=0?'selectedhull-terminal':'selectedhull-captured',ship:hull?copy(hull):null};capture('first-selected-terminal-or-capture');}
 const events=ledger.observe(g.tick,stage,g.units,g.buildings,lastHit);
 for(const event of events){emit('events',{...event,commandIndex});counts.events++;}
 if(events.some(e=>e.type==='native-unit-terminal'&&e.permanent||e.type==='native-building-terminal'||e.type==='owner-change'
   ||e.type==='observed-parent-change'&&e.after.id==='unit-p0-summoner-39390'||e.type==='unit-birth-observed'&&e.unit.expiresTick===undefined))capture(stage+'-'+(commandIndex??'native'));
 economy(stage);
}
function sample(){
 const own=g.units.filter((u:any)=>u.owner==='p0'&&u.hp>0),naval=m.get('p0')?.naval;
 const row=copy({tick:g.tick,...counts,winner:g.match.winner,players:economyNow(),stats:g.match.stats,
  resources:g.resources.map((r:any)=>({id:r.id,x:r.x,y:r.y,amount:r.amount})),
  actualMineOrderWorkers:own.filter((u:any)=>u.kind==='worker'&&u.order.type==='mine').map((u:any)=>({id:u.id,order:u.order,carryingGold:u.carryingGold})),
  halls:g.buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,owner:b.owner,x:b.x,y:b.y,hp:b.hp,complete:b.complete})),
  ferries:naval?.ferries??{},assault:naval?.assault,island:naval?.island,services:naval?.services,
  ownPermanentArmy:own.filter((u:any)=>unitMover(u.kind)==='land'&&u.kind!=='worker'&&u.expiresTick===undefined).map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,deck:u.deck,order:u.order})),
  hulls:g.units.filter((u:any)=>!!u.sailing).map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,parts:u.shipParts,order:u.order,sailing:u.sailing,
   actualPermanentCargo:g.units.filter((p:any)=>p.deck?.shipId===u.id&&p.expiresTick===undefined).map((p:any)=>p.id),
   actualTemporaryCargo:g.units.filter((p:any)=>p.deck?.shipId===u.id&&p.expiresTick!==undefined).map((p:any)=>p.id),
   actualNativeBoard:g.units.filter((p:any)=>p.order.type==='board'&&p.order.transportId===u.id).map((p:any)=>p.id)})),
  enemyBuildings:g.buildings.filter((b:any)=>b.owner==='p1'||b.owner==='p2').map((b:any)=>({id:b.id,kind:b.kind,owner:b.owner,x:b.x,y:b.y,hp:b.hp,maxHp:b.maxHp})),
  yards:g.buildings.filter((b:any)=>b.kind==='shipyard').map((b:any)=>({id:b.id,owner:b.owner,hp:b.hp,queue:b.queue,researchQueue:b.researchQueue}))});
 emit('samples',row);atomic(join(O,'progress.json'),JSON.stringify({classification,pid:process.pid,start,tick:g.tick,counts,latest:row}));
 console.log(JSON.stringify({tick:g.tick,...counts,winner:row.winner,p0:row.players.p0,hulls:row.hulls.filter((u:any)=>u.owner==='p0').map((u:any)=>({id:u.id,hp:u.hp,cargo:u.actualPermanentCargo.length,order:u.order.type})),ferries:row.ferries}));
}
g.observer={hit(attacker:any,target:any,damage:number,hpBefore:number){
 const hit=copy({tick:g.tick,attacker:attacker.id,attackerOwner:attacker.owner,attackerKind:attacker.kind,target:target.id,targetOwner:target.owner,targetKind:target.kind,damage,hpBefore,hpAfter:target.hp,deck:target.deck});
 emit('hits',hit);lastHit.set(target.id,hit);counts.hits++;
 if(g.tick<267300)prefixHits.push(copy(hit));
 if(target.id===selectedHullId||target.id===selectedCrewId||attacker.owner==='p0'&&target.id.startsWith('building-'))selectedDamage=true;
 if(!firstOwnedTargetHit&&attacker.id===selectedHullId&&target.id===initialTargetId){firstOwnedTargetHit=copy(hit);atomic(join(O,'first-owned-target-hit.json'),JSON.stringify(firstOwnedTargetHit,null,2));}
}};
const planner=(ctx:any)=>{
 if(ctx.owner==='p0'){
  if(g.tick===267300){
   const actual=full();
   originalPrefixProof={tick:g.tick,world:equal(actual.snapshot,originalHandoffInput.snapshot),nextId:actual.nextId===originalHandoffInput.nextId,
    all3mem:equal(actual.memories,originalHandoffInput.memories),commands:equal(prefixCommands,originalPrefix.commands),hits:equal(prefixHits,originalPrefix.hits),
    originalSource:originalPrefix.originalSourceHead,scope:'Actual candidate first15 normalnative ticks closed against originalEBD before the intended267300 P0 change; no extraGame/query or expectedstate injection.'};
   atomic(join(O,'original-first15-prefix-proof.json'),JSON.stringify(originalPrefixProof,null,2));
   if(!originalPrefixProof.world||!originalPrefixProof.nextId||!originalPrefixProof.all3mem||!originalPrefixProof.commands||!originalPrefixProof.hits){capture('original-first15-prefix-mismatch');throw Error('Normal first15 differs from bound originalEBD prefix before intendedcode divergence');}
  }
  capture('before-p0-every-think');
  atomic(join(O,'recent','p0-'+(Math.floor(g.tick/15)%16)+'.json.gz'),gzipSync(JSON.stringify({...full(),checkpointStage:'before-p0',nextCommandIndex:counts.commands})));
  emit('think-hashes',{tick:g.tick,sha256:sha(JSON.stringify(full()))});counts.thinks++;
 }
 const cpuStart=process.cpuUsage(),wallStart=performance.now(),entries=normal(ctx),wallMs=performance.now()-wallStart,cpu=process.cpuUsage(cpuStart);
 atomic(join(O,'owner-memory-after',g.tick+'-'+ctx.owner+'.json.gz'),gzipSync(JSON.stringify({classification:'Actual fullthree memories immediately after this owners one normal planner call, before its published commands; worldhash binds original planning world.',tick:g.tick,owner:ctx.owner,nextId:g.nextId,entries,memories:Object.fromEntries(Object.keys(saved.memories).map(owner=>[owner,m.get(owner)])),worldSHA256:sha(JSON.stringify(snapshotGame(g)))})));
 if(ctx.owner==='p0'){
  const intent=m.get('p0')?.naval?.coastalVoyages?.[selectedHullId],nextLeg=intent?.targetId===initialTargetId?copy(intent.waypoint):undefined;
  if(!equal(selectedLeg,nextLeg)){
   const change={tick:g.tick,before:selectedLeg??null,after:nextLeg??null,ship:copy(g.units.find((u:any)=>u.id===selectedHullId)??null),scope:'Actual normalpolicy station target/waypoint memory changed; cancelled marks are not reported as arrived. Public order and native route are retained separately. No observer action.'};
   emit('station-memory-ownership',change);stationGoalChanges++;
   if(selectedLeg&&!nextLeg&&!firstStationMemoryRelease)firstStationMemoryRelease=copy(change);
   selectedLeg=nextLeg;capture(nextLeg?'station-owned-or-reselected':'station-memory-released');
  }
  atomic(join(O,'p0-memory-after',g.tick+'.json.gz'),gzipSync(JSON.stringify({classification:'Actual fullthree policy memories after this normalP0 and before its commands; worldhash identifies unchanged planning snapshot, not another Game.',tick:g.tick,nextId:g.nextId,memories:Object.fromEntries(Object.keys(saved.memories).map(owner=>[owner,m.get(owner)])),worldSHA256:sha(JSON.stringify(snapshotGame(g)))})));
  cost.p0Thinks++;cost.p0WallMs+=wallMs;cost.p0CpuMs+=(cpu.user+cpu.system)/1000;cost.p0MaxWallMs=Math.max(cost.p0MaxWallMs,wallMs);
  if(g.tick===start){
   firstP0Proof={tick:g.tick,normalPlannerCalls:1,sourceHead:cap.head,originalNormalReferenceInputSHA256:expected.inputSHA256,entries:equal(copy(entries),expected.entries),p0memory:equal(copy(m.get('p0')),expected.p0memory),worldUnchanged:equal(full().snapshot,initial.snapshot),nextIdUnchanged:g.nextId===initial.nextId,p1p2MemoryUnchanged:['p1','p2'].every(owner=>equal(m.get(owner),initial.memories[owner])),scope:'The one actual candidate normal firstP0 compared after planning with the bound originalEBD actualnormal P0, not a new baseline/query or pre-applied expected memory.'};
   atomic(join(O,'first-p0-proof.json'),JSON.stringify(firstP0Proof,null,2));
   if(!firstP0Proof.entries||!firstP0Proof.p0memory||!firstP0Proof.worldUnchanged||!firstP0Proof.nextIdUnchanged||!firstP0Proof.p1p2MemoryUnchanged){capture('first-p0-mismatch');throw Error('Actual firstP0 differs from bound originalEBD actualnormal reference; no commands applied');}
  }
  emit('p0-plans',copy({tick:g.tick,wallMs,cpuMs:(cpu.user+cpu.system)/1000,entries,navalAfter:m.get('p0')?.naval,
   hulls:g.units.filter((u:any)=>u.owner==='p0'&&u.sailing).map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,parts:u.shipParts,order:u.order,queue:u.orderQueue,arrivedAt:u.arrivedAt,sailing:u.sailing}))}));
 }
 return entries;
};
atomic(join(O,'actual-launch.json'),JSON.stringify({classification,startedAtUtc,pid:process.pid,cwd:process.cwd(),argv:process.argv,source:S,head:cap.head,inputPath:join(D,'input-actual267285-before-p0.json.gz'),inputSHA256:sha(raw),agents,start,restored,sourcePre,frozenPre,driverSHA256:prelaunch.driverSHA256,observerSHA256:prelaunch.payloads['observer-ledger.ts'].sha256,firstObservationAt:Math.ceil((start+1)/600)*600,stopProtocol:'Explicit observer-stop.json request for a documented mechanism or real resource checkpoint is read beforeStep; stop at subsequent natural600after-step/before-nextP0 with full world/id/all3mem preserved. Classification comes from actual request; unfinished resource pause is not defeat. First600 alone does not stop. No arbitrary game horizon, source/AI/enemy changes or manual controls.'},null,2));
capture('restored-before-p0');sample();
const runInput={name:'ordinary explicit battery-target task sameactualEBD saved normal3AI from267285',game:g,agents,maxTicks:Number.MAX_SAFE_INTEGER,thinkInterval:15,commandPlanner:planner};
const result=runGameLoop(runInput,{
 afterCommand(event:any){
  const narrowed=narrowFrameCommandToLiveOperands(event.before,event.owner,event.command),legality=narrowed?checkCommandLegality(event.before,event.owner,narrowed):undefined;
  emit('command-dispositions',{tick:event.tick,commandIndex:counts.commands,owner:event.owner,command:event.command,narrowed:narrowed??null,legality:legality??null,disposition:!narrowed?'no-live-operands':legality?.transient?'transient-no-op':legality?'hard-error':'admitted-to-native-issuer',scope:'Read-only supported pre-command snapshot validation; issue attempt/admission is not proof of native movement, shot, damage or task completion.'});
 },
 onCommand(event:any){
  const row=copy({tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:event.command});
  if(g.tick<267300)prefixCommands.push(row);
  commandIndex=counts.commands;emit('commands',row);counts.commands++;observe('after-command');commandIndex=undefined;
 },
 beforeStep(){
  if(!stopRequest&&existsSync(join(O,'observer-stop.json'))){stopRequest={observedAtTick:g.tick,request:JSON.parse(readFileSync(join(O,'observer-stop.json'),'utf8'))};atomic(join(O,'observer-stop-received.json'),JSON.stringify(stopRequest,null,2));}
  observe('before-step');ledger.beforeStep(g.units);stepCPU=process.cpuUsage();stepStart=performance.now();
 },
 onStep(){
  const wallMs=performance.now()-stepStart,cpu=process.cpuUsage(stepCPU);cost.nativeSteps++;cost.nativeWallMs+=wallMs;cost.nativeCpuMs+=(cpu.user+cpu.system)/1000;cost.nativeMaxWallMs=Math.max(cost.nativeMaxWallMs,wallMs);
  emit('native-step-costs',{tick:g.tick,wallMs,cpuMs:(cpu.user+cpu.system)/1000});observe('after-step');
  if(g.tick<=start+300)capture('after-step-initial300-detailed');
  if(selectedDamage){capture('after-step-selected-damage');selectedDamage=false;}
  if(g.tick===267300){const hull=g.units.find((u:any)=>u.id===selectedHullId);originalHandoffBoundary={tick:g.tick,ship:copy(hull??null),crew:copy(g.units.find((u:any)=>u.id===selectedCrewId)??null),actualShorePoints:hull?shipShorePoints(hull,g.map):null,scope:'Actual samecandidate Game at originalEBD actual target-command handoff tick; not an artificial stop or claim of arrival/shot.'};capture('original-ebd-handoff-boundary');atomic(join(O,'original-ebd-handoff-boundary.json'),JSON.stringify(originalHandoffBoundary,null,2));}
  if(g.tick%600===0){capture('before-p0');sample();if(g.tick===Math.ceil((start+1)/600)*600){first600={tick:g.tick,counts:copy(counts),winner:g.match.winner,phase:'after native step, before nextP0, sameGame continues',scope:'Only observation milestone; native result is not arrival/shot/survival or match victory by itself.'};atomic(join(O,'first600-observation.json'),JSON.stringify(first600,null,2));}
   if(stopRequest&&!g.match.winner){observationStop={tick:g.tick,stage:'after-step-before-next-p0',...stopRequest,scope:'Supported explicit observer boundary; see preserved request for resource-pause or documented mechanism classification. Not natural defeat/win or arbitrary deadline.'};runInput.maxTicks=g.tick;}
  }
 }
});
const final=full(),sourcePost=verifySource(),frozenPost=verifyFrozen();capture('final');sample();
atomic(join(O,'final.json.gz'),gzipSync(JSON.stringify(final)));
atomic(join(O,'report.json'),JSON.stringify({classification,startedAtUtc,endedAtUtc:new Date().toISOString(),pid:process.pid,source:S,head:cap.head,start,end:g.tick,winner:g.match.winner,naturalComplete:!!g.match.winner,observationStop,counts,restored,sourcePre,sourcePost,frozenPre,frozenPost,firstP0Proof,originalPrefixProof,first600,originalHandoffBoundary,initialSelectedLeg,stationGoalChanges,firstStationMemoryRelease,firstNativeLegCompletion,firstOwnedTargetHit,firstSelectedTerminal,firstOwnCrewDisembark,firstOwnCrewLoss,firstOwnCrewOwnerChange,firstEnemyBoard,cost,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,limitations:['Raw publiccommands record issue attempts, including transientnoops; admitted disposition not effect.','All owners terminal/capture/expiry observations retained; expiry may be a terminal but is not silently equated with nativeunitsLost. Death owner and capture separate.','NativeLedger recent world maps plus terminal lifetimeID sets are not a constant-memory cap; raw streams append without growing per-tick arrays.','Wholly within-step changes may be missed; lastHit only a correlation. preStepCarryingHull may precede the fatal moment.','Initial strictrestore proof does not establish finalrestore idempotence. Every actual P0 beforeframe and postP0 fullthree memories are retained; Full world/id/all3mem every nativeafterstep only through first300 actualticks, then everyP0/600/damage/major selected tactical or terminal events; compact selected hull/crew/target/projectiles recorded every nativeafterstep. It does not retain every later tick fullworld. All public commands, immediate all3 memories plus entries after each owners normal planner call, all3postP0mem and ledger events retained. Native complete uses route.end tolerance, not an arbitrary combat radius. Memory changes are not themselves native arrival; withinstep changes may remain unobserved.','Original broken container uncommitted gap remains unrecovered. This changed-base+leaf saved continuation does not become same-source recovery, ordinary0/generalization or bootstrap acceptance.']},null,2));
console.log(JSON.stringify({completed:true,tick:g.tick,winner:g.match.winner,counts,sourcePost,frozenPost}));
