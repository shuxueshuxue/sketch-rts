证据包只含已闭合 final5b5/focus6000 记录，不含正在运行的普通0，也不代表 bootstrap 完成。

最终源码 HEAD 5b5aead30978f7a13601b3ae6be848f70a3b1493、完整selected1557仅打包一次；冻结 d1ae110f2edd99f9c7d899ed61557891ab587639 的497文件和184清单仅打包一次。最终232个不同合同及noEmit实际通过；首次外部Vitest配置import解析失败为actualexit1/0case，负证保留。node --check为0Game，随后正常三方AI在原完整329400 world/nextId/all3mem上运行6000tick至335400，支持CP保留下一全owner冷think335400。

实际结果没有4268登船、没有登陆、没有winner。原十名永久陆军仍在返航船上，建筑/资源/现金/战损统计不变。关键旧spirit到330330才过期，任务330210已取消。冻结源始终497而非498。原savedframe没有setup字段；执行配置来自原agents/actuallaunch/driver，不能伪造缺失旧setup或声称恢复原容器未提交修改。

恢复：先用 RESTORE-VERIFY.py --bundle final5b5-evidence.tar.gz --extract-to <全新目录> 校验/解包。INDEX.json记录每个payload的bytes/SHA/mode/mtime和gzip自检；BUNDLE-RECEIPT.json在外层绑定INDEX和整个包的SHA。CRC只证明已闭合成员；原raw及旧失败记录不被修补。包内完整focus/raw含每P0/600/关键变化的world/id/all3mem、全部1200ownerplans/6448公开命令/32hits/583events，45gzip members全部闭合。原prepared里绝对路径作为原始出处保留。新环境重跑应创建新的prepared目录重绑路径/manifest并记录新run，不改历史证据或把新run冒充旧进程。

本包不是完整Git对象仓库或机器快照。标准源码恢复使用另建的普通仓库：
  git clone --no-checkout https://github.com/shuxueshuxue/sketch-rts.git <新仓库>
  git -C <新仓库> fetch origin 5b5aead30978f7a13601b3ae6be848f70a3b1493 d1ae110f2edd99f9c7d899ed61557891ab587639
  git -C <新仓库> switch --detach 5b5aead30978f7a13601b3ae6be848f70a3b1493
  python3 <解包目录>/RESTORE-VERIFY.py --root <解包目录> --repo <新仓库>
如需从包恢复所选文件，只对全新/独立干净且exact5b5的仓库加 --overlay-selected；默认只读验证。其余未选UI/assets等由exact提交正常fetch提供。冻结provider依赖正常仓库中的d1ae提交。node_modules不打包，依赖按完整package-lock安装；本次安装tsx模块SHA和TSX_DISABLE_CACHE=1均留在实际receipts，不声称性能因果。

父协调者已确认5b5推送origin/codex/bootstrap-assault-ready-island-20261016。旧fullsource基线由已push exact提交链恢复；旧8/21及native因果报告明确归旧源，不把历史分数累计至final232。具体边界见SCORE-SOURCES.json。没有凭据、网络安全变更、内部会话目录或activeC覆写。
