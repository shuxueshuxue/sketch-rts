#!/usr/bin/env python3
"""Offline verify/extract evidence; verify selected source over a separately fetched exact repository.
No Git object synthesis, credentials, networking, dependency install or Game launch.
"""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,json,os,stat,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path);p.add_argument('--extract-to',type=Path);p.add_argument('--root',type=Path);p.add_argument('--repo',type=Path);p.add_argument('--overlay-selected',action='store_true');a=p.parse_args()
h=lambda f:hashlib.file_digest(f,'sha256').hexdigest()
def safe(name):
 q=PurePosixPath(name);assert not q.is_absolute() and '..'not in q.parts;return q
if a.bundle:
 assert a.extract_to and not a.extract_to.exists(),'Extract only into a fresh directory'
 a.extract_to.mkdir(parents=True)
 with tarfile.open(a.bundle,'r:gz')as t:
  members=t.getmembers()
  for m in members:assert m.isfile() and safe(m.name)
  for m in members:
   target=a.extract_to/m.name;target.parent.mkdir(parents=True,exist_ok=True)
   with t.extractfile(m)as src,target.open('xb')as dst:
    while chunk:=src.read(1024**2):dst.write(chunk)
   os.chmod(target,m.mode)
   ns=int(m.pax_headers.get('SCHILY.mtime_ns',int(m.mtime*10**9)));os.utime(target,ns=(ns,ns))
 a.root=a.extract_to
assert a.root,'Use --root extracted-directory or --bundle ... --extract-to fresh-directory'
index=json.loads((a.root/'INDEX.json').read_text())
for r in index['payloads']:
 file=a.root/r['archivePath'];assert file.is_file() and file.stat().st_size==r['bytes']
 with file.open('rb')as src:assert h(src)==r['sha256'],r['archivePath']
 assert stat.S_IMODE(file.stat().st_mode)==r['mode'] and file.stat().st_mtime_ns==r['mtimeNs']
 if r.get('gzip'):
  with gzip.open(file,'rb')as src:
   while src.read(1024**2):pass
print(json.dumps({'payloadsVerified':len(index['payloads']),'sourceHead':index['sourceHead'],'rulesVersion':2,'scope':'Bytes/SHA/mode/mtime and complete gzip CRC/ISIZE verified. Not replay or Game acceptance.'}))
if a.repo:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo,text=True).strip()==index['sourceHead'],'Repository must already be checked out at exact5b5'
 subprocess.check_call(['git','cat-file','-e',index['frozenRevision']+'^{commit}'],cwd=a.repo)
 source=a.root/'source/final1557.tar.gz';expected=json.loads((a.root/'source/SOURCE1557-MEMBERS.json').read_text())['members']
 if a.overlay_selected:
  assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=a.repo,text=True),'Use a clean separate repository, never an active worktree'
  with tarfile.open(source,'r:gz')as t:
   for m in t:
    if not m.isfile():continue
    safe(m.name);target=a.repo/m.name;target.parent.mkdir(parents=True,exist_ok=True)
    with t.extractfile(m)as src,target.open('wb')as dst:
     while chunk:=src.read(1024**2):dst.write(chunk)
    os.chmod(target,m.mode)
    ns=expected[m.name]['mtimeNs'];os.utime(target,ns=(ns,ns))
 for name,r in expected.items():
  with (a.repo/name).open('rb')as src:assert h(src)==r['sha256'],name
  assert (a.repo/name).stat().st_size==r['bytes']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=a.repo,text=True),'Selected content differs from exact Git tree'
 print(json.dumps({'repositorySelected1557Verified':True,'head':index['sourceHead'],'frozenCommitPresent':index['frozenRevision'],'notFullGitObjectBackup':True,'GameNotStarted':True}))
