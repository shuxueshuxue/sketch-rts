#!/usr/bin/env python3
"""One low-memory read-only archive attempt; no Node, Game or active source writes."""
from pathlib import Path
from decimal import Decimal
import datetime,gzip,hashlib,json,os,re,stat,subprocess,tarfile,time,struct
D=Path(__file__).resolve().parent;W=Path('/workspace');PREP=Path('/workspace/.playtest/coastal-ready-island-focus329400-335400-prepared-20261016');RAW=Path('/tmp/coastal-ready-island-focus329400-335400-actual-20261016');VALID=Path('/workspace/.playtest/coastal-macro-ready-island-validation2-20261016');ORIG=Path('/workspace/.playtest/coastal-battery-explicit-target-20261016');MACRO=Path('/tmp/coastal-carrier329400-macro-readonly-20261016');ISLAND=Path('/tmp/bootstrap-assault-island-a53-20261016');BASE=Path('/workspace/.playtest/coastal-febb-macro-b-integration-20261016')
MAX_BYTES=35_000_000;RESERVE=64*1024**2;MEM_GATE=1024**3+256*1024**2
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def wr(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def resource():
 fs=os.statvfs(W);return{'atUTC':now(),'fresh':int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()),'workspaceFree':fs.f_bavail*fs.f_frsize,'oomEvents':Path('/sys/fs/cgroup/memory.events').read_text(),'ordinaryPID522654Present':Path('/proc/522654').exists()}
def guard(stage,opening=False):
 r=resource()
 if r['fresh']<MEM_GATE or r['workspaceFree']<RESERVE+(MAX_BYTES+2*1024**2 if opening else 0):
  wr(D/'PACK-GUARD-REFUSAL.json',{'stage':stage,'resources':r,'requiredFresh':MEM_GATE,'reserve':RESERVE,'scope':'No retry; original evidence and active game unchanged. Manifest only.'});raise RuntimeError('Resource guard refused '+stage)
 return r
assert not(D/'PACK-RESULT.json').exists() and not(D/'INDEX.json').exists()
startResource=resource();paths={}
def add(path,name,group):
 path=Path(path);assert path.is_file(),str(path);assert name not in paths;assert not name.startswith('/')and '..'not in Path(name).parts;paths[name]=(path,group)
def tree(root,prefix,group,exclude=()):
 for path in sorted(Path(root).rglob('*')):
  if path.is_file()and path.name not in exclude:add(path,prefix+'/'+str(path.relative_to(root)),group)
# Exactly one final selected-source archive and one full frozen archive.
capPath=VALID/'PREPARED-SOURCE-EQUIVALENCE.json';cap=json.loads(capPath.read_text());assert sha(capPath)=='04a05d4e0a9cfaede3d5b7ba07a666ea6a5992ebfa642dff3774df75b072c5bc'
source=Path(cap['sourceArchive']['path']);frozen=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5-frozen-source.tar.gz');assert sha(source)=='684b4a00a9f537e7cf0a449d1291a759924c079d9ea41d50adb12fdb86d40782';assert sha(frozen)=='34be8981d6eb475173ebd75a787b2776584040ae7fe7e5c909540b478e00a8e5'
add(source,'source/final1557.tar.gz','one complete final selected source');add(frozen,'frozen/frozen497.tar.gz','one complete frozen source');add(capPath,'source/FINAL1557-CAP.json','one final selected cap')
# Entire closed final-source validation and complete focus evidence, no active ordinary0 data.
tree(VALID,'validation/final1557','actual232+tsc',exclude=('PREPARED-SOURCE-EQUIVALENCE.json',));tree(PREP,'focus/prepared','actualfocus driver/config/process receipts');tree(RAW,'focus/raw','complete exitedfocus raw frames/streams/CP/world/id3mem');add(Path(str(RAW)+'-stdout.log'),'focus/process-stdout.log','actualfocus process output')
# Preserve initial zero-case external config parser failure independently.
FIRST=Path('/workspace/.playtest/coastal-macro-ready-island-integration-20261016')
for name in ['pure56-started.json','pure56-execution.json','pure56.log','vitest-pure56.config.mts']:
 add(FIRST/name,'negative/external-config-zero-case/'+name,'actualexit1 before anycase')
# Historical execution configuration, parser and original source binding.
originalNames=['agents.json','native-normal-267285.ts','observer-ledger.ts','fixed-source.json','prelaunch-manifest.json','frozen-full-source-index.json','driver-parse-only.mjs','parse-resource.json','parse.log','native-launch-resource.json','launch-native-once.py','package.json','SOURCE-CAPSULE.json','input-actual267285-before-p0.json.gz','input-original267300-before-p0.json.gz','ORIGINAL-EBD-ACTUAL267285-P0.json','ORIGINAL-EBD-267285-267300-RAW-PREFIX.json','inherited-last-native-hits.json','PRELAUNCH-SAMPLING-CONTRACT.json']
for name in originalNames:add(ORIG/name,'provenance/original-f426/'+name,'historical original config/0Game parser; not finalsource score')
add(ORIG/'natural-from-267285/actual-launch.json','provenance/original-f426/normal-actual-launch.json','historical f426 actualnormal process receipt')
for tick in [329115,329130]:add(ORIG/f'natural-from-267285/frames/{tick}-before-p0-every-think.json.gz',f'provenance/original-f426/{tick}-before-p0.json.gz','original complete frame, never regenerated')
# Minimal component negative controls and patches; no old fullsource tar duplication.
for name in ['PURE8-OLD-NEW-ACTUAL-RESULT.json','OLDRED8-CASE-LEDGER.json','oldred8-EXECUTION.json','oldred8-STARTED.json','oldred8.json','oldred8.log','candidate8-EXECUTION.json','candidate8-STARTED.json','candidate8.json','candidate8.log','run-pure8.py','PURE8-LAUNCHER-PREPARED.json','TSX-CACHE-POLICY-VERIFIED.json','NATIVE3-UNIQUE-CASE-LEDGER.json','A-PERMANENT-PROGRESS-ONLY.patch','B-SUMMON-FLOOR-ONLY.draft.patch','A-PLUS-B.draft.patch','READONLY-MACRO-REPORT.json','CONTRACTS-PREPARED.json','ACTUAL-FIXTURES.json']:
 add(MACRO/name,'history/f426-floor-progress/'+name,'old16410 sixred/twogreen vs22523 eightgreen; distinct from final232/focus')
for root,label in [(Path('/tmp/coastal-carrier329400-native3-save-equality-20261016'),'native3-original-restore-negative'),(Path('/tmp/coastal-carrier329400-native2-exact-cache-20261016'),'native2-original-exact-cache-control')]:
 for path in sorted(root.iterdir()):
  if path.is_file() and path.name!='NATIVE3-SOURCE1499.json':add(path,'history/'+label+'/'+path.name,'originalf426 native0step, explicit cachedfield construction retained; not normalboard score')
# Final fixtures carry most originals, these old native fixture memories are needed for exact historical controls.
tree(Path('/tmp/coastal-carrier329400-native3-save-equality-20261016/fixtures'),'history/native3-original-fixtures','native original complete fixture evidence')
for name in ['production.patch','fixture-provenance.json','SOURCE-SCOPE-CORRECTION.json','FIXED-CANDIDATE-HANDOFF.json','PURE-CONTRACT-PREPARED.json','actual-contract-launch.json','launch-old-new-contract.py','old-new-contracts.mts','old-new-contract-console.log','PERSONAL-NATIVE-VISUAL-OBSERVATION.json']:
 add(ISLAND/name,'history/ready-island-old-new21/'+name,'old a53 sixexpectedred/15green vs final5b5 21green, counted once inside final56')
tree(ISLAND/'old-new-contract-output','history/ready-island-old-new21/output','same21 old/new actual raw outputs, no Game')
for name in ['aaef-to-b-minimal12.patch','PREPARED-VALIDATION-PLAN.json','ACTUAL-PURE35-RESULT.json','pure35-execution.json','pure35-started.json','pure35-ACTUAL-PID-SUPERVISION.json','pure35.json','pure35.log','run-pure35.py','vitest-pure35.config.mts']:
 add(BASE/name,'history/a53-integration/'+name,'earlier a53 pure35 only, not inherited as finalsource validation')
for root,label,patterns in [
 (Path('/tmp/bootstrap-coastal-febb-integration-20261016'),'ba9a-hold-heal-negative',['ACTUAL-PURE9-RESULT.json','pure-regression-execution.json','pure-regression-started.json','pure-regression.json','pure-regression.log']),
 (Path('/tmp/bootstrap-coastal-febb-instant-heal-20261016'),'e72-nativeheal2-and-construction-red',['native2-execution.json','native2-started.json','native2.json','native2.log','pure19-execution.json','pure19-started.json','pure19.json','pure19.log','successor.patch']),
 (Path('/tmp/bootstrap-coastal-febb-instant-heal-cabin-20261016'),'21e-cabin-and-original35595-negative',['cabin1-execution.json','cabin1-started.json','cabin1.json','cabin1.log','coastal-targeted-execution.json','coastal-targeted-started.json','coastal-targeted.json','coastal-targeted.log','preservation-execution.json','preservation-started.json','preservation.json','preservation.log','test-only-successor.patch'])]:
 for name in patterns:add(root/name,'history/'+label+'/'+name,'historical source scores; final232 independently rerun')
# Produce complete nested-source index, verifying every source/frozen member against its authoritative cap.
frozenExpected=json.loads(Path('/tmp/bootstrap-coastal-febb-integration-20261016/PREPARED-VALIDATION-PLAN.json').read_text())['frozenFiles'];manifest=None
for archive,out,expected in [(source,'source/SOURCE1557-MEMBERS.json',{p:{'bytes':r['bytes'],'sha256':r['sha256']}for p,r in cap['sourceFiles'].items()}),(frozen,'frozen/FROZEN497-MEMBERS.json',frozenExpected)]:
 members={}
 with tarfile.open(archive,'r:gz')as t:
  for m in t:
   if m.isdir():continue
   assert m.isfile()and m.name not in members
   raw=t.extractfile(m).read();r={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':m.mode,'mtimeNs':int(Decimal(m.pax_headers.get('mtime',str(m.mtime)))*10**9)};assert {'bytes':r['bytes'],'sha256':r['sha256']}==expected[m.name]
   if raw[:2]==b'\x1f\x8b':r['nestedGzipCRCAndISIZEValid']=True;gzip.decompress(raw)
   members[m.name]=r
   if archive==source and m.name=='docs/engineering/bootstrap_1/frozen-policy.json':manifest=json.loads(raw)
 assert set(members)==set(expected)
 target=D/Path(out).name;wr(target,{'archiveSHA256':sha(archive),'memberCount':len(members),'members':members,'scope':'Complete archived members verified, bytes/SHA/mode/mtime; no Git objects.'});add(target,out,'full nested source membership verification')
assert manifest['rulesVersion']==2 and len(manifest['files'])==184 and manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639';assert all(frozenExpected[p]['sha256']==digest for p,digest in manifest['files'].items());wr(D/'FROZEN184-MANIFEST.json',manifest);add(D/'FROZEN184-MANIFEST.json','frozen/FROZEN184-MANIFEST.json','exact184 manifest verified against full497')
wr(D/'SCORE-SOURCES.json',{'final':{'head':cap['head'],'selectedFiles':1557,'capSHA256':sha(capPath),'actualUniqueContracts':232,'tscNoEmitActualExit':0,'actualFocus6000':{'start':329400,'end':335400,'exit':0,'winner':None,'4268Boarded':False,'tenPermanentCrewStillAboard':True,'classification':'Changed-code finite causalwindow, no win/acceptance.'}},'historical':{'f426':'Original normal continuation and zero-step native floor cause; not newsource game success.','16410_vs_22523':'Same8 purecases old6red2green/new8green; not16 unique or fullGame.','a53_vs_5b5':'Same21 purecases old6red15green/new21green. These21 rerun within final56, not extra finalcases.','a53':'Actual pure35 belongs to a53, not inherited as final56.','ba9a':'Actual pure9 had6 behaviorred/3green; not ordinarygame omitted-heal proof.','e72':'Actual nativeheal2 on e72, not final5b5 scores. pure19 hadone constructionred.','21e':'Cabin1 corrected; coastal78green, preservation96green/1 original35595 integrationred. Final5b5 independently passes that originalcase.'},'sourceRecovery':'Final1557 and fullfrozen497 included once. Historical fullsources are not duplicated; retrieve their exact pushed commits/patch chain in a normal repository.','notIncluded':'Active ordinary0 PID522654 evidence and inaccessible originalcontainer uncommitted changes.','notFullGitObjectRepository':True});add(D/'SCORE-SOURCES.json','SCORE-SOURCES.json','score provenance/limitations')
readme='''证据包只含已闭合 final5b5/focus6000 记录，不含正在运行的普通0，也不代表 bootstrap 完成。

最终源码 HEAD 5b5aead30978f7a13601b3ae6be848f70a3b1493、完整selected1557仅打包一次；冻结 d1ae110f2edd99f9c7d899ed61557891ab587639 的497文件和184清单仅打包一次。最终232个不同合同及noEmit实际通过；首次外部Vitest配置import解析失败为actualexit1/0case，负证保留。node --check为0Game，随后正常三方AI在原完整329400 world/nextId/all3mem上运行6000tick至335400，支持CP保留下一全owner冷think335400。

实际结果没有4268登船、没有登陆、没有winner。原十名永久陆军仍在返航船上，建筑/资源/现金/战损统计不变。关键旧spirit到330330才过期，任务330210已取消。冻结源始终497而非498。原savedframe没有setup字段；执行配置来自原agents/actuallaunch/driver，不能伪造缺失旧setup或声称恢复原容器未提交修改。

恢复：先用 RESTORE-VERIFY.py --bundle final5b5-evidence.tar.gz --extract-to <全新目录> 校验/解包。INDEX.json记录每个payload的bytes/SHA/mode/mtime和gzip自检；BUNDLE-RECEIPT.json在外层绑定INDEX和整个包的SHA。CRC只证明已闭合成员；原raw及旧失败记录不被修补。包内完整focus/raw含每P0/600/关键变化的world/id/all3mem、全部1200ownerplans/6448公开命令/32hits/583events，45gzip members全部闭合。原prepared里绝对路径作为原始出处保留。新环境重跑应创建新的prepared目录重绑路径/manifest并记录新run，不改历史证据或把新run冒充旧进程。

本包不是完整Git对象仓库或机器快照。标准源码恢复使用另建的普通仓库：
  git clone --no-checkout https://github.com/shuxueshuxue/sketch-rts.git <新仓库>
  git -C <新仓库> fetch origin 5b5aead30978f7a13601b3ae6be848f70a3b1493 d1ae110f2edd99f9c7d899ed61557891ab587639
  git -C <新仓库> switch --detach 5b5aead30978f7a13601b3ae6be848f70a3b1493
  python3 <解包目录>/RESTORE-VERIFY.py --root <解包目录> --repo <新仓库>
如需从包恢复所选文件，只对全新/独立干净且exact5b5的仓库加 --overlay-selected；默认只读验证。其余未选UI/assets等由exact提交正常fetch提供。冻结provider依赖正常仓库中的d1ae提交。node_modules不打包，依赖按完整package-lock安装；本次安装tsx模块SHA和TSX_DISABLE_CACHE=1均留在实际receipts，不声称性能因果。

父协调者已确认5b5推送origin/codex/bootstrap-assault-ready-island-20261016。旧fullsource基线由已push exact提交链恢复；旧8/21及native因果报告明确归旧源，不把历史分数累计至final232。具体边界见SCORE-SOURCES.json。没有凭据、网络安全变更、内部会话目录或activeC覆写。
'''
(D/'README.zh.md').write_text(readme);add(D/'README.zh.md','README.zh.md','restoration and honest limitations');add(D/'RESTORE-VERIFY.py','RESTORE-VERIFY.py','noNode offline restore verifier');add(Path(__file__),'tools/prepare-and-pack.py','exact packaging script')
# Per-payload SHA/mode/mtime and full gzip CRC/ISIZE check. INDEX is a catalog, its hash is in the outer receipt.
payloads=[]
for name,(path,group)in paths.items():
 st=path.stat();r={'archivePath':name,'originalPath':str(path),'bytes':st.st_size,'sha256':sha(path),'mode':stat.S_IMODE(st.st_mode),'mtimeNs':st.st_mtime_ns,'uid':st.st_uid,'gid':st.st_gid,'group':group}
 if path.is_symlink():r['originalSymlink']={'target':os.readlink(path),'lstatMode':stat.S_IMODE(path.lstat().st_mode),'lstatMtimeNs':path.lstat().st_mtime_ns,'contentArchivedAsRegularFile':True}
 with path.open('rb')as f:magic=f.read(2)
 if magic==b'\x1f\x8b':
  uncompressed=hashlib.sha256();size=0
  with gzip.open(path,'rb')as f:
   while chunk:=f.read(1024**2):uncompressed.update(chunk);size+=len(chunk)
  with path.open('rb')as f:f.seek(-8,2);crc,isize=struct.unpack('<II',f.read(8))
  r['gzip']={'allMemberCRCAndISIZEValidated':True,'uncompressedBytes':size,'uncompressedSHA256':uncompressed.hexdigest(),'lastMemberCRC32':format(crc,'08x'),'lastMemberISIZE':isize,'scope':'gzip reader consumed all members to EOF. Focus member-specific45 CRC values additionally retained in focus/raw/closed-members.jsonl.'}
 payloads.append(r)
index={'createdAtUTC':now(),'classification':'Complete final1557 + frozen497/184 + exitedfocus6000 actual evidence. Not completeGit repo, ordinary0 completion, win or bootstrap acceptance.','sourceHead':cap['head'],'sourceCapSHA256':sha(capPath),'frozenRevision':manifest['revision'],'frozenFiles':497,'manifestFiles':184,'rulesVersion':2,'payloads':payloads,'payloadCount':len(payloads),'rawPayloadBytes':sum(r['bytes']for r in payloads),'indexSelfHash':'Catalog hash stored outside recursion in BUNDLE-RECEIPT.json/INDEX-SHA256.txt.','sourceArchiveOnlyOnce':True,'frozenArchiveOnlyOnce':True,'historicalSourceRecovery':'Exact pushed commits + recorded minimal patches, no multiple old fullsource tar copies.','remoteConfirmation':{'source':'Parent coordinator confirms actual push; no new network request by packer.','branch':'origin/codex/bootstrap-assault-ready-island-20261016','head':cap['head']},'originalUncommittedGap':'Still unavailable; not recovered.'};wr(D/'INDEX.json',index);(D/'INDEX-SHA256.txt').write_text(sha(D/'INDEX.json')+'  INDEX.json\n')
wr(D/'PACK-PREPARED.json',{'atUTC':now(),'sourceHead':cap['head'],'payloads':len(payloads),'rawPayloadBytes':index['rawPayloadBytes'],'indexSHA256':sha(D/'INDEX.json'),'requiredFresh':MEM_GATE,'workspaceReserve':RESERVE,'maxOuterBytes':MAX_BYTES,'resourceBeforeCatalog':startResource,'NodeOrGameLaunched':False})
try:before=guard('before single archive attempt',opening=True)
except RuntimeError:print(json.dumps({'manifestOnly':True,'reason':'fresh/free guard refused','indexSHA256':sha(D/'INDEX.json')}));raise SystemExit(75)
archive=D/'final5b5-evidence.tar.gz';assert not archive.exists();started=time.monotonic();originalAllExact=True
try:
 with tarfile.open(archive,'w:gz',compresslevel=6,format=tarfile.PAX_FORMAT)as t:
  for i,r in enumerate(payloads):
   guard('payload '+str(i));path=paths[r['archivePath']][0];st=path.stat();assert st.st_size==r['bytes']and st.st_mtime_ns==r['mtimeNs']and stat.S_IMODE(st.st_mode)==r['mode']and sha(path)==r['sha256']
   info=tarfile.TarInfo(r['archivePath']);info.size=r['bytes'];info.mode=r['mode'];info.uid=r['uid'];info.gid=r['gid'];info.mtime=st.st_mtime;info.pax_headers={'mtime':str(Decimal(r['mtimeNs'])/10**9),'SCHILY.mtime_ns':str(r['mtimeNs'])}
   with path.open('rb')as f:t.addfile(info,f)
   if archive.stat().st_size>MAX_BYTES:raise RuntimeError('Outer archive exceeds predeclared35,000,000 bytes')
  for name in ['INDEX.json','INDEX-SHA256.txt']:
   path=D/name;st=path.stat();info=tarfile.TarInfo(name);info.size=st.st_size;info.mode=stat.S_IMODE(st.st_mode);info.mtime=st.st_mtime;info.pax_headers={'mtime':str(Decimal(st.st_mtime_ns)/10**9),'SCHILY.mtime_ns':str(st.st_mtime_ns)}
   with path.open('rb')as f:t.addfile(info,f)
 assert archive.stat().st_size<=MAX_BYTES and resource()['workspaceFree']>=RESERVE
 # Complete outer gzip CRC and every archived payload SHA/bytes/mode/mtime verification without extraction or Node.
 archived={}
 with tarfile.open(archive,'r:gz')as t:
  for m in t:
   assert m.isfile();raw=t.extractfile(m);digest=hashlib.file_digest(raw,'sha256').hexdigest();archived[m.name]={'bytes':m.size,'sha256':digest,'mode':m.mode,'mtimeNs':int(m.pax_headers['SCHILY.mtime_ns'])}
 with gzip.open(archive,'rb')as f:
  while f.read(1024**2):pass
 for r in payloads:assert archived[r['archivePath']]=={k:r[k]for k in['bytes','sha256','mode','mtimeNs']}
 assert len(archived)==len(payloads)+2 and archived['INDEX.json']['sha256']==sha(D/'INDEX.json')
 with archive.open('rb')as f:f.seek(-8,2);crc,isize=struct.unpack('<II',f.read(8))
 receipt={'atUTC':now(),'archivePath':str(archive),'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive),'archiveGzipCRCAndISIZEValidated':True,'archiveFooterCRC32':format(crc,'08x'),'archiveFooterISIZE':isize,'indexSHA256':sha(D/'INDEX.json'),'payloadCount':len(payloads),'allPayloadBytesSHAModeMtimeExactInArchive':True,'nestedFinal1557AndFrozen497FullMembersExact':True,'manifest184Rules2Exact':True,'sourceArchiveCount':1,'frozenArchiveCount':1,'elapsedSeconds':time.monotonic()-started,'resourceBeforePack':before,'resourceAfterPack':resource(),'NodeOrGameLaunched':False,'activeOrdinary0Untouched':True,'noActualBoardingOrWinnerClaim':True,'originalUncommittedGap':'Still unavailable.','notCompleteGitObjectRepo':True}
 wr(D/'BUNDLE-RECEIPT.json',receipt);wr(D/'PACK-RESULT.json',{'status':'complete','receiptSHA256':sha(D/'BUNDLE-RECEIPT.json'),'archiveSHA256':receipt['archiveSHA256'],'indexSHA256':receipt['indexSHA256']});print(json.dumps(receipt))
except Exception as e:
 # Only our incomplete outer archive is discarded; all original/partial historical raw remains untouched.
 if archive.exists():archive.unlink()
 wr(D/'PACK-RESULT.json',{'status':'manifest-only-after-one-attempt','error':repr(e),'indexSHA256':sha(D/'INDEX.json'),'resources':resource(),'originalsAndActiveGameUntouched':True,'retry':False});print(json.dumps({'manifestOnly':True,'error':repr(e)}));raise SystemExit(75)
