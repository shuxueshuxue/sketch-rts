#!/usr/bin/env python3
"""Launch only after actual same-source tests+tsc and explicit root Game handoff."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,tarfile,time
D=Path(__file__).resolve().parent;B=Path('/workspace/.playtest/coastal-macro-ready-island-validation2-20261016')
p=argparse.ArgumentParser();p.add_argument('--handoff-note',required=True);a=p.parse_args()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();wr=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
note=json.loads((D/'PREPARATION-NOTE.json').read_text());capPath=Path(note['sourceCapPath']);assert h(capPath)==note['sourceCapSHA256'];cap=json.loads(capPath.read_text());C=Path(cap['control']);manifest=json.loads((D/'PRELAUNCH-MANIFEST.json').read_text())
assert h(D/'native-normal329400.mjs')==manifest['driverSHA256']
for name,r in manifest['payloads'].items():assert (D/name).stat().st_size==r['bytes'] and h(D/name)==r['sha256'],name
assert os.environ.get('TSX_DISABLE_CACHE')=='1'
module=C/'node_modules/tsx/dist/index-XurvG3JN.mjs';assert h(module)=='128dc5756da9bec342781ee30127611c958f921e15016b06dd866de28d906245'
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==cap['head']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
 assert len(cap['sourceFiles'])==1557
 assert all(h(C/p)==r['sha256'] for p,r in cap['sourceFiles'].items())
 return True
def frozen():
 fp=json.loads((D/'CANONICAL-FROZEN497-INDEX.json').read_text());archive=Path(fp['archive']['path']);assert h(archive)==fp['archive']['sha256'];files={}
 with tarfile.open(archive,'r:gz') as t:
  for m in t.getmembers():
   if m.isfile():files[m.name]={'bytes':m.size,'sha256':hashlib.sha256(t.extractfile(m).read()).hexdigest()}
 assert len(files)==497 and files==fp['files'];return {'canonical497EveryMemberExact':True,'archiveSHA256':h(archive),'rulesVersion':2,'manifest184SHA256':h(C/'docs/engineering/bootstrap_1/frozen-policy.json')}
prerequisites={}
for stage in ['pure56','native-related176','tsc1024']:
 path=B/(stage+'-execution.json');r=json.loads(path.read_text())
 assert r['sourceHead']==cap['head'] and r['sourceCapSHA256']==note['sourceCapSHA256'] and r['exit']==0 and r.get('validationExit',r['exit'])==0 and r['source1557ExactAfter'] and r['frozenPost'],stage
 if stage=='pure56':assert r['actualCounts']=={'passed':56,'failed':0,'skipped':0,'unique':56} and r['caseIDsExactlyExpected']
 if stage=='native-related176':assert r['actualCounts']=={'passed':176,'failed':0,'skipped':0,'unique':176} and r['caseIDsExactlyExpected']
 prerequisites[stage]={'executionPath':str(path),'sha256':h(path),'actualExit':r['exit'],'endedAtUTC':r['endedAtUTC']}
assert not (D/'normal-execution.json').exists() and not (D/'normal-started.json').exists() and not (D/'normal-guard75.json').exists() and not Path(note['normalOutputPath']).exists(),'One launch only; never overwrite prior run/guard or output'
exact();pre=frozen();fresh=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());fs=os.statvfs('/tmp');free=fs.f_bavail*fs.f_frsize
r={'atUTC':now(),'launcherPID':os.getpid(),'handoffNote':a.handoff_note,'sourceHead':cap['head'],'sourceCapSHA256':note['sourceCapSHA256'],'source1557ExactBefore':True,'frozenPre':pre,'headroomBefore':fresh,'requiredHeadroom':2*1024**3,'outputFilesystemFreeBefore':free,'requiredOutputFreeBefore':384*1024**2,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text(),'prerequisitesActual':prerequisites,'driverSHA256':h(D/'native-normal329400.mjs'),'prelaunchSHA256':h(D/'PRELAUNCH-MANIFEST.json'),'parentEnvironment':{'TSX_DISABLE_CACHE':'1'},'tsxInstalledModuleSHA256':h(module),'classification':'Actual final1557 changed-code finite causalwindow329400->335400 on development-seen saved input; no terminal or acceptance inferred.'}
if fresh<r['requiredHeadroom'] or free<r['requiredOutputFreeBefore']:wr(D/'normal-guard75.json',r);print(json.dumps(r));raise SystemExit(75)
args=['node','--max-old-space-size=1024','--import','tsx',str(D/'native-normal329400.mjs')];log=Path(note['normalOutputPath']+'-stdout.log');assert not log.exists();env=os.environ.copy();env.pop('NODE_OPTIONS',None);r.update(args=args,startedAtUTC=now(),stdoutPath=str(log));wr(D/'normal-started.json',r);start=time.monotonic()
with log.open('xb') as out:
 child=subprocess.Popen(args,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT);r['actualNodePID']=child.pid;wr(D/'normal-started.json',r);code=child.wait()
r.update(exit=code,endedAtUTC=now(),elapsedSeconds=time.monotonic()-start,oomAfter=Path('/sys/fs/cgroup/memory.events').read_text(),stdoutSHA256=h(log))
for name,check in [('source1557ExactAfter',exact),('frozenPost',frozen)]:
 try:r[name]=check()
 except Exception as e:r[name]=False;r[name+'Error']=repr(e);code=code or 1
report=Path(note['normalOutputPath'])/'report.json'
if report.exists():
 result=json.loads(report.read_text());r.update(reportPath=str(report),reportSHA256=h(report),actualTick=result['end'],winner=result['winner'],naturalComplete=result['naturalComplete'],observationStop=result.get('observationStop'),observerError=result.get('error'))
r['validationExit']=code;wr(D/'normal-execution.json',r);print(json.dumps(r));raise SystemExit(code)
