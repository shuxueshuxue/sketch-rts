import {readFileSync,writeFileSync,mkdirSync,appendFileSync,renameSync,existsSync,statfsSync,openSync,fsyncSync,closeSync,statSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual as equal} from 'node:util';
import {NativeLedger} from './observer-ledger.ts';

const D=dirname(import.meta.filename),note=JSON.parse(readFileSync(join(D,'PREPARATION-NOTE.json'),'utf8'));
const O=note.normalOutputPath,cap=JSON.parse(readFileSync(note.sourceCapPath,'utf8')),S=cap.control;
const sha=v=>createHash('sha256').update(v).digest('hex'),copy=v=>JSON.parse(JSON.stringify(v));
const prelaunch=JSON.parse(readFileSync(join(D,'PRELAUNCH-MANIFEST.json'),'utf8'));
if(process.cwd()!==S||existsSync(O)||process.env.TSX_DISABLE_CACHE!=='1')throw Error('Fixed cwd, fresh output, external TSX_DISABLE_CACHE=1 required');
if(sha(readFileSync(import.meta.filename))!==prelaunch.driverSHA256)throw Error('Bound driver changed');
for(const [name,r] of Object.entries(prelaunch.payloads)){const b=readFileSync(join(D,name));if(b.length!==r.bytes||sha(b)!==r.sha256)throw Error('Bound payload changed '+name);}
if(sha(readFileSync(note.sourceCapPath))!==note.sourceCapSHA256)throw Error('Final source cap changed');
function verifySource(){
 const changed=Object.entries(cap.sourceFiles).filter(([p,r])=>sha(readFileSync(join(S,p)))!==r.sha256).map(([p])=>p);
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',S,'status','--porcelain','--untracked-files=all'],{encoding:'utf8'});
 if(head!==cap.head||status||changed.length||Object.keys(cap.sourceFiles).length!==1557)throw Error('Final source changed');
 return{head,selectedFiles:1557,status,changed};
}
const sourcePre=verifySource(),setup=JSON.parse(readFileSync(join(D,'EXECUTION-SETUP.json'),'utf8'));
for(const [path,r] of Object.entries(setup.provenance)){const b=readFileSync(path);if(b.length!==r.bytes||sha(b)!==r.sha256)throw Error('Original configuration provenance changed '+path);}
if(setup.observationWindow.startTick!==329400||setup.observationWindow.endTick!==335400||setup.observationWindow.endTick-setup.observationWindow.startTick!==6000||setup.observationWindow.endTick%600!==0)throw Error('Bound focus window mismatch');
const raw=readFileSync(join(D,'input-actual329400-before-p0.json.gz'));
if(sha(raw)!==setup.input.sha256)throw Error('Original329400 full input changed');
const saved=JSON.parse(gunzipSync(raw).toString());
if('setup' in saved||saved.snapshot.tick!==329400||saved.nextId!==227466||saved.checkpointStage!=='before-p0-every-think'||saved.snapshot.tick%setup.thinkInterval!==0)throw Error('Wrong input/cold think phase');
const agents=setup.agents,owners=Object.keys(agents),mission=setup.mission;
if(!equal(owners,setup.ownerOrder)||!equal(Object.keys(saved.memories),owners)||setup.thinkInterval!==15||setup.rulesVersion!==2)throw Error('Execution configuration mismatch');
if(saved.snapshot.match.winner!==null||owners.some(owner=>saved.snapshot.teams[owner]!==agents[owner].team||saved.snapshot.players[owner].race!==agents[owner].race))throw Error('Original native teams/races or nonterminal match mismatch');
const load=p=>import(pathToFileURL(join(S,p)).href);
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest},{runGameLoop},{unitMover}]=await Promise.all([
 load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),load('src/sdk/game-runner.ts'),load('src/shared/catalog.ts')]);
const g=createGame('bareDuel'),m=createAiMemoryProvider();
restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);
for(const [owner,memory] of Object.entries(saved.memories))m.set(owner,copy(memory));
const full=()=>copy({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,m.get(owner)]))});
const initial=full(),restored={world:equal(initial.snapshot,saved.snapshot),nextId:initial.nextId===saved.nextId,all3mem:equal(initial.memories,saved.memories)};
if(Object.values(restored).some(v=>!v))throw Error('Zero-step strict full world/nextId/all3mem restore failed');
const frozenRoot=frozenPolicyRoot(),frozenIndex=JSON.parse(readFileSync(join(D,'CANONICAL-FROZEN497-INDEX.json'),'utf8'));
function verifyFrozen(){
 const changedFull=Object.entries(frozenIndex.files).filter(([p,r])=>{const b=readFileSync(join(frozenRoot,p));return b.length!==r.bytes||sha(b)!==r.sha256;}).map(([p])=>p);
 const changedManifest=Object.entries(frozenPolicyManifest.files).filter(([p,h])=>sha(readFileSync(join(frozenRoot,p)))!==h).map(([p])=>p);
 if(changedFull.length||changedManifest.length||Object.keys(frozenIndex.files).length!==497||Object.keys(frozenPolicyManifest.files).length!==184||frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision)throw Error('Frozen497/manifest184/rules2 mismatch');
 return{revision:frozenPolicyManifest.revision,rulesVersion:2,files:184,fullSourceFiles:497,changedFull,changedManifest};
}
const frozenPre=verifyFrozen(),normal=await createBootstrapCommandPlanner(m);
if(!equal(full(),initial))throw Error('Normal planner setup mutated zero-step input');
mkdirSync(join(O,'frames'),{recursive:true});
const durable=(path,bytes)=>{const fd=openSync(path,'w');try{writeFileSync(fd,bytes);fsyncSync(fd);}finally{closeSync(fd);}};
const atomic=(path,bytes)=>{durable(path+'.tmp',bytes);renameSync(path+'.tmp',path);};
const json=(path,v)=>atomic(path,JSON.stringify(v,null,2)+'\n');
const classification='Declared finite causalwindow329400->335400; supported600full CP at335400 is observation end, not match terminal/defeat/stall/acceptance. Changed-code 5b5aead3 final1557 normal v9_summoner vs frozenv5+v7 rules2 saved continuation from actual329400 beforeP0. Full original saved map/world/nextId/all3mem; existing normal resources/population/teams. Execution config proved by bound original agents/launch/driver; original frame has no setup field. Development-seen map, not ordinary0/unseen generalization/same-source recovery or bootstrap acceptance. No original15prefix equality expectation. No manual controls, AI/enemy/rule edits, injected memory or private movement queries.';
const startedAtUTC=new Date().toISOString(),start=g.tick,counts={commands:0,hits:0,events:0,plans:0,steps:0};
const streams=new Map(),chunkLimit=8*1024*1024;let chunkSerial=0,commandIndex,firstP0Proof,firstBoard4268,firstCarrierMotion,firstOriginalTenLandfall,firstMissionTargetHit,stopRequest,observationStop,lastFullCP,first600;
const focusSet=new Set([mission.carrierId,mission.requestedShoreUnitId,...mission.initialPermanentAboardTen]);
const writeMember=(name,parts,meta)=>{
 const plain=Buffer.from(parts.join('')),compressed=gzipSync(plain,{level:3}),path=join(O,name+'.jsonl.gz'),offset=existsSync(path)?statSync(path).size:0;
 const fd=openSync(path,'a');try{writeFileSync(fd,compressed);fsyncSync(fd);}finally{closeSync(fd);}
 appendFileSync(join(O,'closed-members.jsonl'),JSON.stringify({serial:chunkSerial++,stream:name,...meta,offset,compressedBytes:compressed.length,uncompressedBytes:plain.length,rows:parts.length,crc32:compressed.readUInt32LE(compressed.length-8).toString(16).padStart(8,'0'),isize:compressed.readUInt32LE(compressed.length-4),uncompressedSHA256:sha(plain),compressedSHA256:sha(compressed)})+'\n');
};
function flush(name,reason){const s=streams.get(name);if(!s?.parts.length)return;writeMember(name,s.parts,{fromTick:s.fromTick,toTick:g.tick,reason});streams.set(name,{parts:[],bytes:0,fromTick:g.tick});}
function emit(name,row){const line=JSON.stringify(row)+'\n';let s=streams.get(name);if(!s){s={parts:[],bytes:0,fromTick:g.tick};streams.set(name,s);}const bytes=Buffer.byteLength(line);if(s.bytes+bytes>chunkLimit&&s.parts.length){flush(name,'8MiB observer chunk bound');s=streams.get(name);}s.parts.push(line);s.bytes+=bytes;if(s.bytes>=chunkLimit)flush(name,'single-row or exact 8MiB bound');}
function flushAll(reason){for(const name of streams.keys())flush(name,reason);const path=join(O,'closed-members.jsonl');if(existsSync(path)){const fd=openSync(path,'r');try{fsyncSync(fd);}finally{closeSync(fd);}}}
function capture(stage){const state={...full(),executionSetup:setup,checkpointStage:stage,nextCommandIndex:counts.commands,...(['restored-before-p0','before-p0-every-think','before-p0-full600-cp','final-supported-cp'].includes(stage)?{resumePhase:{tick:g.tick,nextAction:'normal all-owner planning at this tick before commands/step',thinkInterval:15,ownerOrder:owners}}:{})};const plain=Buffer.from(JSON.stringify(state));const file=join(O,'frames',g.tick+'-'+stage+'.json.gz');atomic(file,gzipSync(plain,{level:3}));return{tick:g.tick,stage,path:file,bytes:statSync(file).size,sha256:sha(readFileSync(file)),nextId:g.nextId,all3mem:true,executionSetupBound:true};}
function resources(){const max=Number(readFileSync('/sys/fs/cgroup/memory.max','utf8')),current=Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),fs=statfsSync(O);return{atUTC:new Date().toISOString(),tick:g.tick,max,current,headroom:max-current,outputFreeBytes:fs.bavail*fs.bsize,oomEvents:readFileSync('/sys/fs/cgroup/memory.events','utf8'),memoryPressure:existsSync('/sys/fs/cgroup/memory.pressure')?readFileSync('/sys/fs/cgroup/memory.pressure','utf8'):null};}
function pose(){const hull=g.units.find(u=>u.id===mission.carrierId);return copy({hull:hull?{id:hull.id,owner:hull.owner,hp:hull.hp,x:hull.x,y:hull.y,order:hull.order,sailing:hull.sailing,arrivedAt:hull.arrivedAt}:null,requested:g.units.find(u=>u.id===mission.requestedShoreUnitId)??null,originalTen:g.units.filter(u=>mission.initialPermanentAboardTen.includes(u.id)).map(u=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,x:u.x,y:u.y,deck:u.deck,order:u.order})),ferry:m.get('p0')?.naval?.ferries?.[mission.carrierId]??null});}
const wallets=()=>copy(Object.fromEntries(owners.map(owner=>[owner,{gold:g.players[owner].gold,goldSpent:g.match.stats.goldSpent[owner],neutralKills:g.match.stats.neutralUnitsKilled[owner]}])));
let previousWallets=wallets(),previousPhase=saved.memories.p0.naval.ferries[mission.carrierId]?.phase;
function cash(stage){const after=wallets();if(!equal(previousWallets,after)){emit('cash-events',{tick:g.tick,stage,commandIndex,before:previousWallets,after,scope:'Native wallet/spent/neutral kill deltas; not automatically attributed income.'});previousWallets=after;}}
const lastHit=new Map(),ledger=new NativeLedger(g.units,g.buildings);
for(const u of g.units)if(u.hp<=0)ledger.terminal.add(u.id);
for(const b of g.buildings)if(b.hp<=0)ledger.buildingTerminal.add(b.id);
const originalHull=saved.snapshot.units.find(u=>u.id===mission.carrierId);
function observe(stage){
 const events=ledger.observe(g.tick,stage,g.units,g.buildings,lastHit);let critical=false;
 for(const e of events){emit('events',{...e,commandIndex});counts.events++;const id=e.id??e.after?.id??e.previous?.id??e.unit?.id;
  if(e.type==='native-unit-terminal'&&e.permanent||e.type==='native-building-terminal'||e.type==='owner-change'||focusSet.has(id)&&['observed-parent-change','observed-disembark'].includes(e.type))critical=true;
  if(!firstBoard4268&&e.after?.id===mission.requestedShoreUnitId&&e.after.owner==='p0'&&e.after.hp>0&&e.after.deck?.shipId===mission.carrierId){firstBoard4268={tick:g.tick,stage,commandIndex,event:copy(e),actualPose:pose(),scope:'Actual observed native parent now carrier. Not just board command or reserved floor.'};json(join(O,'first-native-board4268.json'),firstBoard4268);}
  if(!firstOriginalTenLandfall&&mission.initialPermanentAboardTen.includes(e.after?.id)&&e.before?.deck?.shipId===mission.carrierId&&!e.after?.deck&&e.after.hp>0){firstOriginalTenLandfall={tick:g.tick,stage,event:copy(e),actualPose:pose(),scope:'First live original crew observed off carrier; location/owner retained, not automatically enemy beach assault or victory.'};json(join(O,'first-original-ten-off-carrier.json'),firstOriginalTenLandfall);}
 }
 const hull=g.units.find(u=>u.id===mission.carrierId);
 if(!firstCarrierMotion&&hull?.hp>0&&hull.owner==='p0'&&(hull.x!==originalHull.x||hull.y!==originalHull.y)){firstCarrierMotion={tick:g.tick,stage,actualPose:pose(),scope:'First actual carrier coordinate change from restored pose; not route completion, enemyward landing or match victory.'};json(join(O,'first-carrier-motion.json'),firstCarrierMotion);critical=true;}
 if(critical)capture(stage+'-critical-'+counts.events);cash(stage);
}
function sample(stage){const own=g.units.filter(u=>u.owner==='p0'&&u.hp>0);const row=copy({tick:g.tick,stage,counts,winner:g.match.winner,stats:g.match.stats,players:wallets(),resources:g.resources,halls:g.buildings.filter(b=>b.kind==='townHall'),shipyards:g.buildings.filter(b=>b.kind==='shipyard'),enemyBuildings:g.buildings.filter(b=>b.owner==='p1'||b.owner==='p2'),allOwnPermanentArmy:own.filter(u=>u.kind!=='worker'&&unitMover(u.kind)==='land'&&u.expiresTick===undefined).map(u=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:u.deck,order:u.order})),mineWorkers:own.filter(u=>u.kind==='worker'&&u.order.type==='mine').map(u=>({id:u.id,x:u.x,y:u.y,order:u.order,carryingGold:u.carryingGold})),naval:m.get('p0')?.naval,selectedMission:pose(),resourcesObserver:resources()});emit('samples',row);json(join(O,'progress.json'),{classification,pid:process.pid,start,tick:g.tick,counts,winner:g.match.winner,lastFullCP,latest:row});console.log(JSON.stringify({tick:g.tick,counts,winner:g.match.winner,players:row.players,selectedMission:row.selectedMission,resource:row.resourcesObserver}));}
g.observer={hit(attacker,target,damage,hpBefore){const row=copy({tick:g.tick,attacker:attacker.id,attackerOwner:attacker.owner,attackerKind:attacker.kind,target:target.id,targetOwner:target.owner,targetKind:target.kind,damage,hpBefore,hpAfter:target.hp,deck:target.deck});emit('hits',row);lastHit.set(target.id,row);counts.hits++;if(!firstMissionTargetHit&&focusSet.has(attacker.id)&&target.id===mission.initialFerry.targetId){firstMissionTargetHit=row;json(join(O,'first-mission-target-native-hit.json'),row);}}};
const planner=ctx=>{
 if(ctx.owner==='p0')capture('before-p0-every-think');
 const worldHashBefore=sha(JSON.stringify(snapshotGame(g))),idBefore=g.nextId,cpu=process.cpuUsage(),wall=performance.now(),entries=normal(ctx),wallMs=performance.now()-wall,cpuDelta=process.cpuUsage(cpu);
 const memories=copy(Object.fromEntries(owners.map(owner=>[owner,m.get(owner)])));
 emit('owner-plans',{tick:g.tick,owner:ctx.owner,worldSHA256:worldHashBefore,nextId:g.nextId,entries:copy(entries),memories,wallMs,cpuMs:(cpuDelta.user+cpuDelta.system)/1000,scope:'All three actual memories immediately after this owner normal plan, before any published commands for this think.'});counts.plans++;
 if(ctx.owner==='p0'){
  const phase=m.get('p0')?.naval?.ferries?.[mission.carrierId]?.phase;
  if(phase!==previousPhase){emit('mission-phase-changes',{tick:g.tick,before:previousPhase??null,after:phase??null,actualPose:pose(),scope:'Policy phase change; native movement/boarding recorded separately.'});previousPhase=phase;capture('after-p0-mission-phase-change');}
  if(g.tick===start){firstP0Proof={tick:g.tick,normalPlannerCalls:1,sourceHead:cap.head,worldUnchanged:worldHashBefore===sha(JSON.stringify(snapshotGame(g))),nextIdUnchanged:idBefore===g.nextId,p1p2MemoryUnchanged:['p1','p2'].every(owner=>equal(m.get(owner),initial.memories[owner])),originalProgress:initial.memories.p0.naval.ferries[mission.carrierId]?.progress,actualProgressAfter:copy(m.get('p0')?.naval?.ferries?.[mission.carrierId]?.progress??null),scope:'Changed-code first actual cold P0 at329400, no commands applied yet. Permanent cargo progress rekey is intended code divergence. No old15prefix or original-p0 entry equality asserted.'};json(join(O,'first-p0-proof.json'),firstP0Proof);if(!firstP0Proof.worldUnchanged||!firstP0Proof.nextIdUnchanged||!firstP0Proof.p1p2MemoryUnchanged)throw Error('First normal P0 mutated world/id/otherowner memory');}
 }
 return entries;
};
const runInput={name:'final1557 actual329400 changed-code normal3AI continuation',game:g,agents,maxTicks:setup.observationWindow.endTick,thinkInterval:15,commandPlanner:planner};
const launch={classification,startedAtUTC,pid:process.pid,cwd:process.cwd(),argv:process.argv,source:S,head:cap.head,sourceCapSHA256:note.sourceCapSHA256,inputSHA256:sha(raw),agents,executionSetup:setup,start,restored,sourcePre,frozenPre,driverSHA256:prelaunch.driverSHA256,firstObservationAt:330000,parentEnvironment:{TSX_DISABLE_CACHE:process.env.TSX_DISABLE_CACHE},resourcesAtLaunch:resources(),stopProtocol:'Predeclared focused causalwindow ends335400 at full600CP, not match terminal. Otherwise no stop due to speed/stall. At each natural600afterstep-before-nextP0: full world/id/all3mem/execution setup CP first; then close streams. Winner wins classification. If memory headroom<1GiB or output free<256MiB, or explicit documented observer-stop.json request, pause through supported mutable maxTicks. Unfinished checkpoint is not defeat/win. Optional memory.pressure absent is diagnostic null.'};
json(join(O,'actual-launch.json'),launch);capture('restored-before-p0');sample('restored');
let result,error,sourcePost,frozenPost;
const closingFailures=[];
function closingFailure(stage,e){closingFailures.push({stage,name:e?.name,message:String(e?.message??e),stack:e?.stack,tick:g.tick});process.exitCode=1;}
try{
 result=runGameLoop(runInput,{
  onCommand(event){commandIndex=counts.commands;emit('commands',{tick:event.tick,index:commandIndex,owner:event.owner,source:event.source,scriptId:event.scriptId,command:copy(event.command),scope:'Actual public command issue attempt; transient no-op/admission not effect.'});counts.commands++;observe('after-command');commandIndex=undefined;},
  beforeStep(){if(!stopRequest&&existsSync(join(O,'observer-stop.json'))){const request=JSON.parse(readFileSync(join(O,'observer-stop.json'),'utf8'));if(!request.reason)throw Error('Explicit observer stop must explain documented mechanism/resource request');stopRequest={observedAtTick:g.tick,request};json(join(O,'observer-stop-received.json'),stopRequest);}ledger.beforeStep(g.units);},
  onStep(){counts.steps++;observe('after-step');if(g.tick%600===0||g.match.winner){lastFullCP=capture(g.match.winner?'terminal-full-cp':'before-p0-full600-cp');sample('after-step-before-next-p0');flushAll('natural600 or terminal closed member');const resource=resources();if(!first600&&g.tick%600===0){first600={tick:g.tick,checkpoint:lastFullCP,resource,scope:'Observation boundary only. Same game continues unless genuine resource/explicit stop.'};json(join(O,'first600-observation.json'),first600);}if(!g.match.winner){if(!stopRequest&&(resource.headroom<setup.runtimeResourceGate.memoryHeadroomBytes||resource.outputFreeBytes<setup.runtimeResourceGate.outputFreeBytes))stopRequest={observedAtTick:g.tick,request:{kind:'resource',reason:'Actual headroom crossed bound1GiB runtime memory or256MiB output threshold',resource}};if(stopRequest){observationStop={tick:g.tick,stage:'after-step-before-next-p0',checkpoint:lastFullCP,...stopRequest};runInput.maxTicks=g.tick;}else if(g.tick===setup.observationWindow.endTick){observationStop={tick:g.tick,stage:'after-step-before-next-all-owner-cold-think',kind:'declared-focus-window',request:setup.observationWindow,checkpoint:lastFullCP,nextThinkAt:g.tick,thinkInterval:15,scope:'6000 native ticks observed on same changed-source game; supported full CP, not terminal/defeat/acceptance.'};runInput.maxTicks=g.tick;}}}}
 });
}catch(e){error={name:e?.name,message:String(e?.message??e),stack:e?.stack,tick:g.tick,scope:'Actual observer/native exception. Any error frame may be mid-command/think; do not count as supported600 CP or match result.'};try{capture('error-actual-phase');}catch(cpError){closingFailure('loop-error-phase-checkpoint',cpError);}process.exitCode=1;}
try{sourcePost=verifySource();}catch(e){closingFailure('sourcePost',e);}
try{frozenPost=verifyFrozen();}catch(e){closingFailure('frozenPost',e);}
let finalCP,resourcesAtExit;
try{finalCP=capture(error||closingFailures.length?'final-error-actual-phase':g.match.winner?'final-natural-winner':'final-supported-cp');}catch(e){closingFailure('finalCP',e);}
try{sample('final');}catch(e){closingFailure('finalSample',e);}
try{flushAll('actual exit final closure');}catch(e){closingFailure('finalFlush',e);}
try{resourcesAtExit=resources();}catch(e){closingFailure('resourcesAtExit',e);}
const report={classification,startedAtUTC,endedAtUTC:new Date().toISOString(),pid:process.pid,source:S,head:cap.head,sourceCapSHA256:note.sourceCapSHA256,start,end:g.tick,winner:g.match.winner,naturalComplete:!!g.match.winner&&!error&&!closingFailures.length,observationStop,error,firstError:error??closingFailures[0],closingFailures,lastDurable600CP:lastFullCP??null,counts,restored,sourcePre,sourcePost,frozenPre,frozenPost,firstP0Proof,first600,firstBoard4268,firstCarrierMotion,firstOriginalTenLandfall,firstMissionTargetHit,finalCP,elapsedMs:result?.elapsedMs,cpuMs:result?.cpuMs,resourcesAtExit,limitations:['All published commands are issue attempts, not proof of native effect.','Original saved frame has no setup field; external execution configuration is bound to original agents/launch/driver evidence.','No equality claim to old15ticks or f426 firstP0. This source intentionally changes permanent cargo progress and floor publication.','Observer streams close gzip members every600ticks or8MiB; CRC32/ISIZE/SHA/offset ledger binds closed members. No per-tick full-unit selected-leg JSONL.','All owner plans plus all3mem and publiccommands/hits/events/cash retained; fullworld/id3mem at everyP0,600CP,critical terminal/parent/phase transitions. Wholly within-step transient states may remain unseen.','NativeLedger and lastHit lifetime ID sets are not a constant-memory claim; lastHit is observed continuation correlation, not automatic cause.','Declared focus end335400 is finite causalwindow full600CP, not complete match; next all-owner15tick think is due335400.','Initial restore exactness does not establish final restore idempotence.','Development-seen changed-code continuation is not ordinary0, unseen seed, full matrix/generalization or bootstrap acceptance.','Original broken-container uncommitted modifications remain unrecovered.']};
try{json(join(O,'report.json'),report);}catch(e){
 closingFailure('report',e);
 const receipt={classification,pid:process.pid,tick:g.tick,actualWinner:g.match.winner,firstError:error??closingFailures[0],closingFailures,lastDurable600CP:lastFullCP??null,finalCP:finalCP??null,sourcePost,frozenPost,scope:'Small observer closing-error receipt on workspace regular disk. Raw/partial gzip remains untouched; only indexed closed members can pass CRC verification. Error-phase frame is not a supported600 CP or match result.'};
 try{writeFileSync(join(D,'observer-closing-error-receipt.json'),JSON.stringify(receipt,null,2)+'\n');}catch(receiptError){closingFailure('workspaceErrorReceipt',receiptError);console.error(JSON.stringify({receiptFailed:String(receiptError),firstError:receipt.firstError,lastDurable600CP:lastFullCP??null}));}
}
console.log(JSON.stringify({actualExit:process.exitCode??0,tick:g.tick,winner:g.match.winner,naturalComplete:!!g.match.winner&&!error&&!closingFailures.length,observationStop,error,closingFailures,lastDurable600CP:lastFullCP??null,sourcePost,frozenPost}));
