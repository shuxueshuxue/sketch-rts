#!/usr/bin/env python3
"""Read only: verify only indexed fully closed gzip members, including footer CRC."""
from pathlib import Path
import argparse,json,hashlib,zlib,gzip,struct
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();seen=set();count=0;by={}
for line in (a.output/'closed-members.jsonl').read_text().splitlines():
 r=json.loads(line);key=(r['stream'],r['offset']);assert key not in seen;seen.add(key);path=a.output/(r['stream']+'.jsonl.gz')
 with path.open('rb') as f:f.seek(r['offset']);b=f.read(r['compressedBytes'])
 assert len(b)==r['compressedBytes'] and h(b)==r['compressedSHA256'];plain=gzip.decompress(b);crc,size=struct.unpack('<II',b[-8:]);assert format(crc,'08x')==r['crc32'] and size==r['isize']==len(plain)%2**32
 assert zlib.crc32(plain)==crc and h(plain)==r['uncompressedSHA256'] and len(plain)==r['uncompressedBytes'] and len(plain.splitlines())==r['rows']
 for row in plain.splitlines():json.loads(row)
 count+=1;by[r['stream']]=by.get(r['stream'],0)+r['rows']
print(json.dumps({'closedMembersVerified':count,'rowsByStream':by,'scope':'Only indexed closed members; does not claim unindexed active buffer closure, native effects, match completion or acceptance.'}))
