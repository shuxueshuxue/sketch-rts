/** Read-only observations at command and step boundaries, including dead bodies awaiting cleanup. */
const copy = (value: any) => JSON.parse(JSON.stringify(value));
export class NativeLedger {
  units = new Map<string, any>(); buildings = new Map<string, any>();
  terminal = new Set<string>(); buildingTerminal = new Set<string>();
  beforeShips = new Map<string, any>();
  constructor(units: any[], buildings: any[]) {
    this.units = new Map(units.map(u => [u.id, copy(u)]));
    this.buildings = new Map(buildings.map(b => [b.id, copy(b)]));
  }
  beforeStep(units: any[]) {
    // A command may already have killed the hull. Its live passengers still need the pre-cleanup ledger.
    this.beforeShips = new Map(units.filter(u => u.sailing).map(u => [u.id,
      { ship: copy(u), passengers: units.filter(p => p.deck?.shipId === u.id).map(copy) }]));
  }
  observe(tick: number, stage: string, units: any[], buildings: any[], lastHit: Map<string, any>) {
    const events: any[] = [], current = new Map(units.map(u => [u.id, u]));
    const death = (id: string, previous: any, unit: any) => {
      if (this.terminal.has(id)) return;
      this.terminal.add(id);
      events.push({ tick, stage, type: 'native-unit-terminal', id, previous, atObservation: unit ? copy(unit) : null,
        observedAs: unit ? 'hp<=0-before-cleanup' : 'removed-by-native-step',
        permanent: (unit ?? previous).expiresTick === undefined,
        lastNativeHit: lastHit.get(id),
        preStepHull: stage === 'after-step' ? this.beforeShips.get(id) : undefined,
        preStepCarryingHull: stage === 'after-step' ? this.beforeShips.get((unit ?? previous).deck?.shipId) : undefined });
    };
    for (const [id, previous] of this.units) {
      const unit = current.get(id);
      if (!unit) { death(id, previous, undefined); events.push({ tick, stage, type: 'unit-removal', previous,
        lastNativeHit: lastHit.get(id), preStepHull: stage === 'after-step' ? this.beforeShips.get(id) : undefined }); }
      else {
        if (unit.hp <= 0) death(id, previous, unit);
        if (previous.hp <= 0 && unit.hp > 0) { this.terminal.delete(id); events.push({ tick, stage, type: 'unit-returned-positive-hp', before: previous, after: copy(unit) }); }
        if (previous.owner !== unit.owner) events.push({ tick, stage, type: 'owner-change', before: previous, after: copy(unit) });
        if (previous.deck && !unit.deck) events.push({ tick, stage, type: 'observed-disembark', before: previous, after: copy(unit) });
        else if (previous.deck?.shipId !== unit.deck?.shipId) events.push({ tick, stage, type: 'observed-parent-change', before: previous, after: copy(unit) });
      }
    }
    for (const unit of units) if (!this.units.has(unit.id)) {
      if (unit.hp > 0) this.terminal.delete(unit.id);
      events.push({ tick, stage, type: 'unit-birth-observed', unit: copy(unit) });
      if (unit.hp <= 0) death(unit.id, undefined, unit);
    }
    const cb = new Map(buildings.map(b => [b.id, b]));
    for (const [id, previous] of this.buildings) {
      const building = cb.get(id);
      if ((!building || building.hp <= 0) && !this.buildingTerminal.has(id)) {
        this.buildingTerminal.add(id); events.push({ tick, stage, type: 'native-building-terminal', previous,
          atObservation: building ? copy(building) : null, lastNativeHit: lastHit.get(id) });
      }
      if (!building) events.push({ tick, stage, type: 'building-removal', previous });
    }
    for (const building of buildings) if (!this.buildings.has(building.id)) events.push({ tick, stage, type: 'building-birth-observed', building: copy(building) });
    this.units = new Map(units.map(u => [u.id, copy(u)]));
    this.buildings = new Map(buildings.map(b => [b.id, copy(b)]));
    return events;
  }
}
