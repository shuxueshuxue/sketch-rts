from pathlib import Path
import json,hashlib,subprocess,tarfile,os,datetime,resource,re
D=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
p=D/'PURE-CONTRACT-PREPARED.json'
assert sha(p.read_bytes())=='d7affa2ea7852b132ca6bb0c8a34dbc655b66288342d415a6a5e6303f811556a'
m=json.loads(p.read_text());driver=D/'old-new-contracts.mts';assert sha(driver.read_bytes())==m['driverSHA256']
assert not re.search(r'\b(createGame|restoreSnapshotIntoGame|issueCommand|stepGame)\s*\(',driver.read_text())
assert '/sim.ts' not in driver.read_text() and '/game-runner.ts' not in driver.read_text()
assert not Path(m['output']).exists()
sources={k:json.loads(Path(v).read_text()) for k,v in m['sources'].items()}
for path,h in m['payloads'].items():assert sha(Path(path).read_bytes())==h,path
for name,source in sources.items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source['root'],text=True).strip()==source['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=source['root'],text=True)
 for n,h in source['hashes'].items():assert sha((Path(source['root'])/n).read_bytes())==h,n
assert len(sources['original6ce']['hashes'])==1486 and len(sources['baseline']['hashes'])==1553 and len(sources['candidate']['hashes'])==1557
fm=json.loads(Path('/tmp/bootstrap-assault-economy-return-6ce-continuation-v2-20261016/FROZEN-SOURCE-PRECAPTURE.json').read_text());fa=Path(fm['archive']);assert sha(fa.read_bytes())==fm['archiveSHA256']
with tarfile.open(fa) as t:fs={e.name:sha(t.extractfile(e).read()) for e in t if e.isfile()}
assert fs==fm['files'] and len(fs)==497
mf=Path(sources['candidate']['root'])/'docs/engineering/bootstrap_1/frozen-policy.json';manifestHash=sha(mf.read_bytes());frozen=json.loads(mf.read_text());assert frozen['rulesVersion']==2 and len(frozen['files'])==184 and all(fs[n]==h for n,h in frozen['files'].items())
record=D/'actual-contract-launch.json';assert not record.exists();c=Path('/sys/fs/cgroup');maximum=int((c/'memory.max').read_text());current=int((c/'memory.current').read_text());st=os.statvfs(D)
tsx=Path(sources['candidate']['root'])/'node_modules/tsx/dist/index-XurvG3JN.mjs';tb=tsx.read_bytes();assert sha(tb)=='128dc5756da9bec342781ee30127611c958f921e15016b06dd866de28d906245' and b'process.env.TSX_DISABLE_CACHE?new Map:new vr' in tb
r={'classification':'Unique512 pure old/new21 plus actual unexpired full P0; zeroGame/restore/issue/step. No baselineexpected-red misclassified as actual game loss.','atUTC':now(),'sources':{k:{'head':s['head'],'files':len(s['hashes'])} for k,s in sources.items()},'driverSHA256':m['driverSHA256'],'manifestSHA256':sha(p.read_bytes()),'frozenPre':{'all497Exact':True,'manifest184Exact':True,'archiveSHA256':fm['archiveSHA256']},'memory':{'max':maximum,'current':current,'headroom':maximum-current,'required':1073741824,'events':(c/'memory.events').read_text()},'FS':{'available':st.f_bavail*st.f_frsize,'required':268435456},'tsxEnv':{'requested':os.environ.get('TSX_DISABLE_CACHE'),'moduleSHA256':sha(tb),'processLocalMapVerified':True},'spawned':False};record.write_text(json.dumps(r,indent=2))
if r['memory']['headroom']<r['memory']['required'] or r['FS']['available']<r['FS']['required']:
 print(json.dumps(r));raise SystemExit(75)
assert os.environ.get('TSX_DISABLE_CACHE')=='1'
env=dict(os.environ);env.pop('NODE_OPTIONS',None);tmp=D/'contract-runtime-tmp';tmp.mkdir();env['TMPDIR']=str(tmp);env['GIT_OPTIONAL_LOCKS']='0'
with (D/'old-new-contract-console.log').open('x') as log:
 child=subprocess.Popen(['node','--max-old-space-size=512','--import','tsx',str(driver),str(p)],cwd=sources['candidate']['root'],env=env,stdout=log,stderr=subprocess.STDOUT)
 r.update({'spawned':True,'actualPID':child.pid,'startedAtUTC':now()});record.write_text(json.dumps(r,indent=2));print(json.dumps({'actualPID':child.pid,'headroom':maximum-current,'source':sources['candidate']['head'],'driverSHA256':m['driverSHA256']}),flush=True)
 code=child.wait()
r['post']={'atUTC':now(),'exitCode':code,'frozenArchiveAndManifestUnchanged':sha(fa.read_bytes())==fm['archiveSHA256'] and sha(mf.read_bytes())==manifestHash,'maxChildRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'memoryEvents':(c/'memory.events').read_text()};record.write_text(json.dumps(r,indent=2));print(json.dumps(r['post']),flush=True);raise SystemExit(code)
