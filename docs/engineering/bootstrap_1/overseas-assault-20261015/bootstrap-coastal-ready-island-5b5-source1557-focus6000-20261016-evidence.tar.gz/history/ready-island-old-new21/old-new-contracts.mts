import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {isDeepStrictEqual as equal} from 'node:util';
const manifest=JSON.parse(readFileSync(process.argv[2]!,'utf8')),sha=(b:any)=>createHash('sha256').update(b).digest('hex');
if(sha(readFileSync(import.meta.filename))!==manifest.driverSHA256)throw Error('bound driver');
if(existsSync(manifest.output))throw Error('no overwrite');mkdirSync(manifest.output);
const sources=Object.fromEntries(Object.entries(manifest.sources).map(([k,p])=>[k,JSON.parse(readFileSync(p as string,'utf8'))]));
function audit(source:any){const head=execFileSync('git',['rev-parse','HEAD'],{cwd:source.root,encoding:'utf8'}).trim(),status=execFileSync('git',['status','--porcelain'],{cwd:source.root,encoding:'utf8'});if(head!==source.head||status)throw Error('head/status '+source.root);for(const [p,h] of Object.entries(source.hashes))if(sha(readFileSync(join(source.root,p)))!==h)throw Error('source '+p);return{head,status,files:Object.keys(source.hashes).length};}
const pre=Object.fromEntries(Object.entries(sources).map(([k,s])=>[k,audit(s)]));
for(const [p,h] of Object.entries(manifest.payloads))if(sha(readFileSync(p))!==h)throw Error('payload '+p);
const saved=(name:string)=>JSON.parse(gunzipSync(readFileSync(manifest.fixtures[name])).toString());
const modules:any={};
for(const [name,source] of Object.entries(sources) as any){const load=(p:string)=>import(join(source.root,p));const [naval,terrain,policy,planner,catalog,time]=await Promise.all([load('src/ai/policy/naval.ts'),load('src/shared/terrain.ts'),load('src/ai/bootstrap_1/policy.ts'),load('src/ai/planner-context.ts'),load('src/shared/catalog.ts'),load('src/shared/time.ts')]);modules[name]={naval,terrain,policy,planner,catalog,time};}
const versions=['v9_archer','v9_summoner','v9_knight'],kinds=['unexpired','refresh','uncached','loaded','boarding','noArmy','endedEnemy'];
const cases:any[]=[];
for(const sourceName of ['baseline','candidate']){
 const {naval,terrain,policy,catalog,time}=modules[sourceName];
 for(const kind of kinds)for(const version of versions){const frame=saved(kind==='loaded'?'loaded':kind==='boarding'?'boarding':'actual'),world=frame.snapshot,memory=frame.memories.p0;
  const actualBefore=JSON.stringify(frame),old=structuredClone(memory.naval.assault),oldId=(kind==='loaded'||kind==='boarding')?memory.naval.ferries['unit-p0-carrier-25442'].targetId:old?.plan?.targetId;
  const controlled:any[]=[];
  if(kind==='uncached'){delete memory.naval.assault;controlled.push('clear only cached assault objective');}
  else if(kind!=='unexpired'){memory.naval.assault.tick=world.tick-time.seconds(20);controlled.push('expire only assault cache metadata over saved world');}
  if(kind==='noArmy'){world.units=world.units.filter((u:any)=>u.owner!=='p0'||u.kind==='worker'||catalog.unitMover(u.kind)!=='land');controlled.push('remove only own nonworker land army; constructed no-ready boundary');}
  if(kind==='endedEnemy'){world.buildings=world.buildings.filter((b:any)=>b.owner==='p0');controlled.push('remove enemy buildings; constructed finished-objective boundary');}
  terrain.setBuildingBodies(world.map,[...world.buildings,...(world.obstacles??[])]);
  const options=policy.bootstrapPolicyContext(world,'p0',version,{memory,teams:world.teams}),before=JSON.stringify(world),otherBefore=JSON.stringify([frame.memories.p1,frame.memories.p2]);
  const preconditions:any={};
  if(kind==='loaded')preconditions.actualPermanentCargo=world.units.filter((u:any)=>u.owner==='p0'&&u.deck?.shipId==='unit-p0-carrier-25442'&&u.kind!=='worker'&&u.expiresTick===undefined).map((u:any)=>u.id);
  if(kind==='boarding')preconditions.actualPermanentBoarding=world.units.filter((u:any)=>u.owner==='p0'&&u.kind!=='worker'&&u.expiresTick===undefined&&u.order.type==='board'&&u.order.transportId==='unit-p0-carrier-25442').map((u:any)=>u.id);
  if(kind==='refresh'||kind==='loaded'||kind==='boarding'){for(const id of ['building-p1-townhall','building-p2-farm-1409']){const target=world.buildings.find((b:any)=>b.id===id);if(target){const q=naval.assaultExpedition(world,'p0',options,target);preconditions[id]={required:q.required,ready:q.ready,crew:q.crew.map((u:any)=>u.id)};}}}
  const commands=naval.planNavalTacticsWithAssignments(world,'p0',options,{orderCrew:(u:any[])=>u,mineEligible:()=>true,targetAvailable:()=>true,transportReady:()=>false,troopAvailable:()=>false});
  if(JSON.stringify(world)!==before||JSON.stringify([frame.memories.p1,frame.memories.p2])!==otherBefore)throw Error('pure target contract mutated world/othermemory');
  const targetId=memory.naval.assault?.plan?.targetId,target=world.buildings.find((b:any)=>b.id===targetId);
  const pass=kind==='unexpired'?equal(memory.naval.assault,old):kind==='refresh'||kind==='uncached'?target?.owner==='p1':kind==='loaded'||kind==='boarding'?!!target&&terrain.sameGround(world.map,target,world.buildings.find((b:any)=>b.id===oldId)):kind==='noArmy'?targetId==='building-p2-farm-1409':!target&&!memory.naval.assault?.plan;
  const expectedPass=sourceName==='candidate'||!['refresh','uncached'].includes(kind);
  if(pass!==expectedPass)throw Error('unexpected contract '+sourceName+' '+kind+' '+version+' target '+targetId);
  cases.push({sourceName,kind,version,actualSnapshotTick:world.tick,controlled,normalPlanner:false,callbacks:'transportReady/troopAvailable false isolate target selection; do not imply ordinary pipeline availability',oldId,targetId:targetId??null,targetOwner:target?.owner??null,pass,expectedPass,preconditions,commands,postAssault:memory.naval.assault,originalFullInputBytesUnchangedOnDisk:true});
 }
}
const actualP0:any[]=[];
for(const sourceName of ['original6ce','baseline','candidate'])for(const version of sourceName==='original6ce'?['v9_summoner']:versions){
 const {planner}=modules[sourceName],frame=saved('actual'),before=JSON.stringify(frame.snapshot),others=JSON.stringify([frame.memories.p1,frame.memories.p2]);
 const entries=planner.planAiOwnerCommandEntries(frame.snapshot,{playerId:'p0',version,memory:frame.memories.p0,source:'external-agent'},{teams:frame.snapshot.teams});
 if(JSON.stringify(frame.snapshot)!==before||JSON.stringify([frame.memories.p1,frame.memories.p2])!==others)throw Error('full P0 pure mutation');
 const file=sourceName+'-'+version+'-actual285600-P0.json.gz';writeFileSync(join(manifest.output,file),gzipSync(JSON.stringify({classification:'One pure full normal P0 plan at unchanged actual285600 cached state; no command issued, no Game, no step. Version substitutions explicitly controlled.',source:pre[sourceName],version,actualVersion:version==='v9_summoner',entries,postAll3Memories:frame.memories})));actualP0.push({sourceName,version,file,entries,postAll3Memories:frame.memories});
}
for(const version of versions){const a=actualP0.find(r=>r.sourceName==='baseline'&&r.version===version),b=actualP0.find(r=>r.sourceName==='candidate'&&r.version===version);if(!equal(a.entries,b.entries)||!equal(a.postAll3Memories,b.postAll3Memories))throw Error('candidate changed unexpired actual285600 normal P0 '+version);}
const post=Object.fromEntries(Object.entries(sources).map(([k,s])=>[k,audit(s)]));for(const [p,h] of Object.entries(manifest.payloads))if(sha(readFileSync(p))!==h)throw Error('payload post '+p);
const report={classification:'Single process old/new21 pure target contracts plus actual unexpired full P0 outputs. No Game/restore/command issue/step, no route or attack executed. Controlled cache/army/end-boundary variants are not ordinary live history.',pid:process.pid,sourcePre:pre,sourcePost:post,actualTick:285600,ordinary0:false,caseCountEach:21,candidatePassed:cases.filter(r=>r.sourceName==='candidate'&&r.pass).length,baselinePassed:cases.filter(r=>r.sourceName==='baseline'&&r.pass).length,baselineExpectedRed:cases.filter(r=>r.sourceName==='baseline'&&!r.pass).map(r=>({kind:r.kind,version:r.version,targetId:r.targetId})),unexpiredFullP0BaseCandidateEntriesAndAll3MemoriesEqual:true,actualP0:actualP0.map(r=>({sourceName:r.sourceName,version:r.version,file:r.file,entryCount:r.entries.length,assault:r.postAll3Memories.p0.naval.assault})),cases,limitations:['Readiness is a force model only. Actual selected26 crew are scattered and current worker ferry has insufficient packing capacity; this query does not show immediate embarkation/departure or a win.','Original actual6ce source and basea53 are different. Only baselinea53→candidate5b5 isolates this production hunk.','The actual285600 cache remainsP2. A normal live continuation must observe its own first post-expiry reselection; no cache TTL changed.']};writeFileSync(join(manifest.output,'REPORT.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({pid:process.pid,caseCountEach:21,baselinePassed:report.baselinePassed,candidatePassed:report.candidatePassed,expectedBaselineRed:report.baselineExpectedRed,unexpiredActualP0Exact:true}));
