#!/usr/bin/env python3
from pathlib import Path
import argparse,datetime,hashlib,json,os,resource,shutil,subprocess,time
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--handoff-note',required=True);a=p.parse_args()
m=json.loads((D/'NATIVE3-PRELAUNCH.json').read_text());C=Path(m['sourceRoot']);cap=json.loads((D/'NATIVE3-SOURCE1499.json').read_text())
def h(path):
 hh=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):hh.update(b)
 return hh.hexdigest()
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==m['sourceHead']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
 assert len(cap['hashes'])==1499
 bad=[n for n,v in cap['hashes'].items() if h(C/n)!=v];assert not bad,bad
 for n,v in m['payloads'].items():assert (D/n).stat().st_size==v['bytes'] and h(D/n)==v['sha256'],n
 return True
assert not (D/'NATIVE3-STARTED.json').exists() and not (D/'NATIVE3-EXECUTION.json').exists(), 'No repeat actual launch'
exact();cg=Path('/sys/fs/cgroup');mx=int((cg/'memory.max').read_text());cur=int((cg/'memory.current').read_text())
r={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffNote':a.handoff_note,'sourceHead':m['sourceHead'],'sourceSelectedFiles':1499,'fullSelectedSourceExactBefore':True,'sourceCapSHA256':h(D/'NATIVE3-SOURCE1499.json'),'driverSHA256':h(D/'native3-runner.ts'),'launcherSHA256':h(__file__),'heapMiB':768,'rawHeadroomBefore':mx-cur,'requiredRawHeadroom':2147483648,'diskFreeBefore':shutil.disk_usage(D).free,'requiredDiskFree':268435456,'eventsBefore':(cg/'memory.events').read_text(),'classification':'Three native zero-step original f426 public-frame contracts; no normal continuation or candidate claim.'}
if r['rawHeadroomBefore']<r['requiredRawHeadroom'] or r['diskFreeBefore']<r['requiredDiskFree']:
 r.update(exitCode=75,NodeStarted=False,GameConstructors=0,nativeSteps=0)
 (D/'NATIVE3-GUARD75.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);raise SystemExit(75)
args=['node','--max-old-space-size=768','--import','tsx',str(D/'native3-runner.ts')];env=os.environ.copy();env.pop('NODE_OPTIONS',None);start=time.monotonic()
with (D/'native3.stdout.log').open('xb') as out,(D/'native3.stderr.log').open('xb') as err:
 q=subprocess.Popen(args,cwd=C,env=env,stdout=out,stderr=err);r.update(args=args,actualPid=q.pid,startedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),NodeStarted=True)
 (D/'NATIVE3-STARTED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'actualPid':q.pid,'startedAtUTC':r['startedAtUTC'],'rawHeadroomBefore':r['rawHeadroomBefore']}),flush=True)
 rc=q.wait()
r.update(exitCode=rc,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,maxRssKiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,eventsAfter=(cg/'memory.events').read_text(),stdoutSHA256=h(D/'native3.stdout.log'),stderrSHA256=h(D/'native3.stderr.log'))
try:r['fullSelectedSourceExactAfter']=exact()
except Exception as e:r['fullSelectedSourceExactAfter']=False;r['postflightError']=repr(e)
(D/'NATIVE3-EXECUTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);raise SystemExit(rc if r['fullSelectedSourceExactAfter'] else 1)
