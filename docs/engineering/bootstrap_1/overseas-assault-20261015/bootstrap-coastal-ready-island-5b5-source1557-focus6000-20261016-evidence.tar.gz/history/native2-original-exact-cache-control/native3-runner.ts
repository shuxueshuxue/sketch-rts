import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
const D = dirname(fileURLToPath(import.meta.url));
const sha = (b: Buffer | string) => createHash('sha256').update(b).digest('hex');
const manifest = JSON.parse(readFileSync(join(D, 'NATIVE3-PRELAUNCH.json'), 'utf8'));
const C = manifest.sourceRoot;
const cap = JSON.parse(readFileSync(join(D, 'NATIVE3-SOURCE1499.json'), 'utf8'));
// Saved worlds are JSON: withUnitShape adds only omitted undefined runtime keys.
const equal = (a: unknown, b: unknown) => assert.deepEqual(JSON.parse(JSON.stringify(a)), JSON.parse(JSON.stringify(b)));
const copy = <T>(v: T): T => structuredClone(v);
function sourceExact() {
 assert.equal(Object.keys(cap.hashes).length, 1499);
 for (const [p, h] of Object.entries(cap.hashes)) assert.equal(sha(readFileSync(join(C, p))), h, p);
}
for (const [p, row] of Object.entries(manifest.payloads) as [string, any][]) {
 const b = readFileSync(join(D, p)); assert.equal(b.length, row.bytes, p); assert.equal(sha(b), row.sha256, p);
}
sourceExact();
const load = (p: string) => import(pathToFileURL(join(C, p)).href);
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createUnit },
 { boardUnit, canBoard, deckLoad, deckPlacement }, { distanceToHull, shipPassengers, shipProfile, worldToLocal },
 { issueCommandFrame }, { RULES_VERSION }] = await Promise.all([
 load('src/shared/sim.ts'), load('src/shared/map.ts'), load('src/shared/decks.ts'),
 load('src/shared/ship-geometry.ts'), load('src/sdk/commands/frame.ts'), load('src/shared/rules-version.ts'),
]);
assert.equal(RULES_VERSION, 2);
const shipId = 'unit-p0-carrier-25442', hexerId = 'unit-p0-ashHexer-4268';
const shipCasterIds = ['unit-p0-summoner-38054', 'unit-p0-summoner-40241', 'unit-p0-summoner-41089', 'unit-p0-summoner-44159'];
let restorationCalls = 0;
function recorded(tick = 329130) {
 const path = join(D, 'fixtures', `carrier-${tick}-actual-before-p0.json.gz`);
 const saved = JSON.parse(gunzipSync(readFileSync(path)).toString());
 const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
 const memories = copy(saved.memories);
 const normalized = (v: any) => JSON.parse(JSON.stringify(v));
 const helperWorld = normalized(snapshotGame(game));
 const differences: any[] = [];
 const compare = (a: any, b: any, path: string) => {
  if (a !== null && b !== null && typeof a === 'object' && typeof b === 'object') {
   for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) compare(a[k], b[k], path ? path + '.' + k : k);
  } else if (!Object.is(a, b)) differences.push({ path, savedValue: a, helperValue: b });
 };
 compare(saved.snapshot, helperWorld, '');
 const index = saved.snapshot.units.findIndex((u: any) => u.id === shipId);
 equal(differences.map(r => r.path).sort(), [`units.${index}.sailing.balance`, `units.${index}.sailing.load`].sort());
 const originalShip = saved.snapshot.units[index], restoredShip = game.units.find((u: any) => u.id === shipId);
 assert.equal(originalShip.sailing.load, 3368); assert.equal(restoredShip.sailing.load, 3298);
 assert.equal(originalShip.sailing.balance, 0.2980877000610818);
 assert.equal(restoredShip.sailing.balance, 0.29985450881400205);
 // syncDecks recomputes these two runtime caches during restore. Put back exactly the original observed before-P0 values.
 restoredShip.sailing.load = originalShip.sailing.load;
 restoredShip.sailing.balance = originalShip.sailing.balance;
 equal(snapshotGame(game), saved.snapshot); assert.equal(game.nextId, saved.nextId); equal(memories, saved.memories);
 const strictRestoration = { helperDiffExactlyTwoCachedFields: differences, reason: 'restoreSnapshotIntoGame invokes syncDecks after one actual spirit expired; preserve original observed before-P0 cached load/balance verbatim', completeSavedJSONWorldEqualAfterExactCacheRestore: true, nextIdEqual: true, all3MemoryEqual: true };
 writeFileSync(join(D, `native2-strict-cache-restoration-${restorationCalls++}.json`), JSON.stringify(strictRestoration, null, 2) + '\n');
 const ship = game.units.find((u: any) => u.id === shipId), hexer = game.units.find((u: any) => u.id === hexerId);
 assert.ok(ship && hexer);
 return { game, saved, memories, ship, hexer, restore: { world: true, nextId: true, all3memories: true, beforeTick: tick, exactOriginalCacheRestoration: strictRestoration, inputSHA256: sha(readFileSync(path)) } };
}
const original = JSON.parse(readFileSync(join(D, 'fixtures/carrier-329130-actual-entries.json'), 'utf8'));
assert.equal(original.length, 9);
const watch = (game: any, ship: any, hexer: any) => ({ tick: game.tick, nextId: game.nextId,
 hexer: { x: hexer.x, y: hexer.y, hp: hexer.hp, order: copy(hexer.order), queue: copy(hexer.orderQueue), deck: copy(hexer.deck) },
 floorAdmission: canBoard(ship, hexer, game.units), load: deckLoad(game.units, ship), capacity: shipProfile(ship).loadCapacity,
 cargo: shipPassengers(game.units, ship).map((u: any) => ({ id: u.id, kind: u.kind, deck: copy(u.deck), expiresTick: u.expiresTick })),
});
const cases: { id: string; run: () => unknown }[] = [
 { id: 'actual329130-original-full-public-frame-zero-step', run() {
  const { game, saved, memories, ship, hexer, restore } = recorded();
  const preIds = game.units.map((u: any) => u.id), before = watch(game, ship, hexer), trace: any[] = [];
  assert.equal(before.floorAdmission, true);
  issueCommandFrame(game, original, { afterIssue(entry: any) { trace.push({ entry: copy(entry), ...watch(game, ship, hexer) }); } });
  equal(trace.map(r => r.entry), original);
  equal(trace[0].entry.command, { type: 'board', unitIds: [hexerId], transportId: shipId });
  assert.equal(trace[0].hexer.order.type, 'board'); assert.equal(trace[0].floorAdmission, true);
  const spell = trace.find(r => r.entry.command.type === 'cast' && r.entry.command.unitId === shipCasterIds[0]);
  assert.ok(spell); assert.equal(spell.floorAdmission, false);
  assert.ok(spell.cargo.some((u: any) => u.id === 'unit-p0-spirit-227240'));
  assert.equal(hexer.order.type, 'board'); assert.equal(hexer.deck, undefined); assert.equal(canBoard(ship, hexer, game.units), false);
  assert.ok(preIds.every((id: string) => game.units.some((u: any) => u.id === id)));
  assert.equal(game.tick, 329130); assert.equal(game.match.winner, null); equal(memories, saved.memories);
  writeFileSync(join(D, 'native3-original329130-after-frame.json.gz'), gzipSync(JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId, memories })));
  return { restore, originalPublishedEntries: original.length, before, trace, after: watch(game, ship, hexer), steps: 0,
   note: 'Actual public issue-order witness only. Walker remains ashore with board order; no boarding completion or path outcome claimed.' };
 } },
 { id: 'actual329130-conflicting-four-summons-omitted-control-zero-step', run() {
  const { game, saved, memories, ship, hexer, restore } = recorded();
  const before = watch(game, ship, hexer), oldIds = game.units.map((u: any) => u.id), oldCargo = shipPassengers(game.units, ship).map((u: any) => u.id);
  const reserved = [...game.units], copyHexer = copy(hexer);
  assert.equal(boardUnit(ship, copyHexer, reserved), true); reserved.push(copyHexer);
  const conflicts = original.filter((e: any) => e.command.type === 'cast' && shipCasterIds.includes(e.command.unitId));
  assert.equal(conflicts.length, 4);
  const reservations: any[] = [];
  for (const entry of conflicts) {
   const point = { x: entry.command.x, y: entry.command.y };
   const probe = createUnit('pure-packing-probe-only', 'p0', 'spirit', point.x, point.y);
   const floor = deckPlacement(ship, probe, reserved, worldToLocal(ship, point));
   assert.equal(floor, undefined);
   reservations.push({ entry: copy(entry), hexerReservedDeck: copy(copyHexer.deck), summonHasReservedFloor: false });
  }
  // Native map.createUnit above constructs only a detached pure packing probe; no game spawn/nextId allocation.
  assert.equal(game.nextId, saved.nextId); equal(snapshotGame(game), saved.snapshot);
  const accepted = original.filter((e: any) => !conflicts.includes(e)), trace: any[] = [];
  assert.equal(accepted.length, 5);
  issueCommandFrame(game, accepted, { afterIssue(entry: any) { trace.push({ entry: copy(entry), ...watch(game, ship, hexer) }); } });
  equal(trace.map(r => r.entry), accepted);
  assert.equal(canBoard(ship, hexer, game.units), true); assert.equal(hexer.order.type, 'board'); assert.equal(hexer.deck, undefined);
  equal(shipPassengers(game.units, ship).map((u: any) => u.id), oldCargo);
  assert.ok(oldIds.every((id: string) => game.units.some((u: any) => u.id === id)));
  assert.equal(game.tick, 329130); assert.equal(game.match.winner, null); equal(memories, saved.memories);
  writeFileSync(join(D, 'native3-counter329130-after-frame.json.gz'), gzipSync(JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId, memories })));
  return { restore, before, exactOmittedConflictingEntries: conflicts, reservationChecks: reservations, accepted, trace,
   after: watch(game, ship, hexer), steps: 0, note: 'Counterfactual public command frame, not original match trajectory, autonomous candidate, successful boarding or win.' };
 } },
 { id: 'actual329400-native-mass-floor-and-contact-zero-step', run() {
  const { game, saved, memories, ship, hexer, restore } = recorded(329400);
  const before = snapshotGame(game), beforeId = game.nextId, state = watch(game, ship, hexer);
  assert.ok(deckLoad(game.units, ship) < shipProfile(ship).loadCapacity - 5000);
  assert.equal(canBoard(ship, hexer, game.units), false);
  const gap = distanceToHull(ship, hexer); assert.ok(gap > hexer.radius + 24);
  assert.equal(hexer.order.type, 'board'); assert.ok(hexer.order.berth?.shore);
  const berthGap = distanceToHull(ship, hexer.order.berth.shore); assert.ok(berthGap <= hexer.radius + 24);
  equal(snapshotGame(game), before); assert.equal(game.nextId, beforeId); equal(memories, saved.memories); assert.equal(game.tick, 329400);
  return { restore, state, hexerGapToHull: gap, nativeAlongsideLimit: hexer.radius + 24, requestedShoreGapToActualHull: berthGap,
   publicCommands: 0, steps: 0, note: 'Native pure admission geometry on actual world. Walker still outside contact; no impossible path or future attachment conclusion.' };
 } },
];
const results: any[] = [];
for (const c of cases.filter(c => c.id !== 'actual329400-native-mass-floor-and-contact-zero-step')) {
 const startedAtUTC = new Date().toISOString();
 try {
  const detail = c.run(); const row = { id: c.id, status: 'passed', startedAtUTC, endedAtUTC: new Date().toISOString(), detail };
  results.push(row); writeFileSync(join(D, `native3-${c.id}.json`), JSON.stringify(row, null, 2) + '\n');
  console.log(JSON.stringify({ id: c.id, status: 'passed', startedAtUTC, endedAtUTC: row.endedAtUTC }));
 } catch (e: any) {
  const row = { id: c.id, status: 'failed', startedAtUTC, endedAtUTC: new Date().toISOString(), error: String(e?.stack ?? e) };
  results.push(row); writeFileSync(join(D, `native3-${c.id}.json`), JSON.stringify(row, null, 2) + '\n'); console.log(JSON.stringify(row));
 }
}
sourceExact();
const report = { classification: 'Only the two original329130 native zero-step issue-order contracts after exact original cached-field restoration. Prior329400 unique pass is unchanged and not rerun. No normal/candidate/boarding-completion/win claim.',
 sourceHead: manifest.sourceHead, sourceSelectedFiles: 1499, rulesVersion: RULES_VERSION, sourceBeforeAfterExact: true,
 sourceCapSHA256: sha(readFileSync(join(D, 'NATIVE3-SOURCE1499.json'))), driverSHA256: sha(readFileSync(fileURLToPath(import.meta.url))),
 cases: results, passed: results.filter(r => r.status === 'passed').length, failed: results.filter(r => r.status === 'failed').length,
 GameConstructors: restorationCalls, normalPlannerCalls: 0, nativeSteps: 0, endedAtUTC: new Date().toISOString() };
writeFileSync(join(D, 'NATIVE3-ACTUAL-RESULT.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ passed: report.passed, failed: report.failed, nativeSteps: 0, sourceSelectedFiles: 1499 }));
if (report.failed) process.exitCode = 1;
