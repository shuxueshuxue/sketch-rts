#!/usr/bin/env python3
from pathlib import Path
import argparse,datetime,hashlib,json,os,resource,subprocess,time
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('target',choices=['oldred8','candidate8']);p.add_argument('--handoff-note',required=True);a=p.parse_args()
capPath=D/('OLDRED-SOURCE1508.json'if a.target=='oldred8'else'CANDIDATE-SOURCE1509.json');cap=json.loads(capPath.read_text());C=Path(cap['control'])
for ending in ['-STARTED.json','-EXECUTION.json','.log','.json']:
 assert not(D/(a.target+ending)).exists(),'Never overwrite an actual invocation or evidence'
def h(p):
 x=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):x.update(b)
 return x.hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip();assert head in [json.loads((D/n).read_text())['head']for n in ['OLDRED-SOURCE1508.json','CANDIDATE-SOURCE1509.json']]
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
if head!=cap['head']:subprocess.run(['git','switch','--detach',cap['head']],cwd=C,check=True,stdout=subprocess.DEVNULL)
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==cap['head']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
 assert all(h(C/n)==v for n,v in cap['hashes'].items());return True
exact();cg=Path('/sys/fs/cgroup');cur=int((cg/'memory.current').read_text());mx=int((cg/'memory.max').read_text());frozen=json.loads((C/'docs/engineering/bootstrap_1/frozen-policy.json').read_text());assert frozen['rulesVersion']==2 and len(frozen['files'])==184
r={'target':a.target,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffNote':a.handoff_note,'sourceHead':cap['head'],'selectedSourceFiles':len(cap['hashes']),'sourceCapSHA256':h(capPath),'launcherSHA256':h(__file__),'heapMiB':512,'rawHeadroomBefore':mx-cur,'requiredRawHeadroom':1073741824,'sourceExactBefore':True,'frozenManifestRulesVersion':2,'frozenManifestFiles':184,'frozenManifestSHA256':h(C/'docs/engineering/bootstrap_1/frozen-policy.json'),'eventsBefore':(cg/'memory.events').read_text(),'cachePolicy':{'TSX_DISABLE_CACHE':'1','effect':'Only externaltsx disk compilation cache disabled; no source/native/command or simulation changes'},'classification':'Eight unique pure AI contracts on isolatedf426-derived source. No Game constructors or native steps requested, no ordinary0/fullmatch or bootstrap acceptance.'}
if mx-cur<1073741824:
 r.update(exitCode=75,NodeStarted=False);target=D/(a.target+'-GUARD75.json');assert not target.exists();target.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);raise SystemExit(75)
args=['node','--max-old-space-size=512','node_modules/vitest/vitest.mjs','run','--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(D/(a.target+'.json')),'src/ai/bootstrap_1/ferry-meaningful-progress.test.ts','src/ai/bootstrap_1/ferry-summon-floor-publication.test.ts']
env=os.environ.copy();env.pop('NODE_OPTIONS',None);env['TSX_DISABLE_CACHE']='1';start=time.monotonic()
with(D/(a.target+'.log')).open('xb')as f:
 q=subprocess.Popen(args,cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(args=args,actualPid=q.pid,startedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),NodeStarted=True)
 (D/(a.target+'-STARTED.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'actualPid':q.pid,'target':a.target,'startedAtUTC':r['startedAtUTC'],'rawHeadroomBefore':mx-cur}),flush=True);rc=q.wait()
r.update(exitCode=rc,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,maxRssKiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,eventsAfter=(cg/'memory.events').read_text(),sourceExactAfter=exact(),logSHA256=h(D/(a.target+'.log')))
result=D/(a.target+'.json')
if result.exists():
 x=json.loads(result.read_text());r['vitestResult']={k:x.get(k)for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','success']}
(D/(a.target+'-EXECUTION.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);raise SystemExit(rc)
