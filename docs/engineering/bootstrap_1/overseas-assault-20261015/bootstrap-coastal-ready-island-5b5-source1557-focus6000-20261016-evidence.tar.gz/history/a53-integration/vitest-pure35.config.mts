export default {
  test: {
    include: [
      'src/ai/bootstrap_1/coastal-crew-charge.test.ts',
      'src/ai/policy/script-runner-instant-heal.test.ts',
      'src/ai/bootstrap_1/ferry-meaningful-progress.test.ts',
      'src/ai/bootstrap_1/ferry-summon-floor-publication.test.ts',
    ],
    pool: 'forks', poolOptions: { forks: { singleFork: true, isolate: true } },
    minWorkers: 1, maxWorkers: 1, fileParallelism: false,
  },
};
