#!/usr/bin/env python3
"""One root-handed-off true0Game batch; no auto retry or subsequent native stage."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,tarfile,time
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--handoff-note',required=True);a=p.parse_args()
cap=json.loads((D/'PREPARED-SOURCE-EQUIVALENCE.json').read_text());C=Path(cap['control']);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert os.environ.get('TSX_DISABLE_CACHE')=='1','Rootrequested externalenv TSX_DISABLE_CACHE=1 isrequired'
module=C/'node_modules/tsx/dist/index-XurvG3JN.mjs';module_sha=H(module)
assert module_sha=='128dc5756da9bec342781ee30127611c958f921e15016b06dd866de28d906245'
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==cap['head']
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=C,text=True)
 bad=[p for p,r in cap['sourceFiles'].items() if H(C/p)!=r['sha256']];assert not bad,bad
 return True
def frozen():
 plan=json.loads(Path('/tmp/bootstrap-coastal-febb-integration-20261016/PREPARED-VALIDATION-PLAN.json').read_text())
 archive=Path(plan['frozenArchive']['path']);assert H(archive)==plan['frozenArchive']['sha256'];files={}
 with tarfile.open(archive,'r:gz') as t:
  for m in t.getmembers():
   if m.isfile():files[m.name]={'bytes':m.size,'sha256':hashlib.sha256(t.extractfile(m).read()).hexdigest()}
 assert files==plan['frozenFiles'] and len(files)==497
 return {'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonicalFrozen497EveryMemberExact':True,
  'archiveSHA256':H(archive),'manifest184SHA256':H(C/'docs/engineering/bootstrap_1/frozen-policy.json'),'rulesVersion':2,'frozenProviderOrOpponentNotInstantiated':True}
assert not(D/'pure35-execution.json').exists()
exact();pre=frozen();mx=int(Path('/sys/fs/cgroup/memory.max').read_text());cur=int(Path('/sys/fs/cgroup/memory.current').read_text())
r={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffNote':a.handoff_note,'target':'pure35',
 'classification':'Four-file35distinctcase pure publication/planning boundary validation. No createGame, restore, native command issue or step; not completegame or historical casualty proof.',
 'sourceHead':cap['head'],'source1553ExactBefore':True,'sourceCapSHA256':H(D/'PREPARED-SOURCE-EQUIVALENCE.json'),
 'driverSHA256':H(Path(__file__)),'configSHA256':H(D/'vitest-pure35.config.mts'),
 'headroomBefore':mx-cur,'requiredHeadroom':1024**3,'heapMiB':512,'singleFork':True,'moduleIsolation':True,
 'parentEnvironment':{'TSX_DISABLE_CACHE':os.environ.get('TSX_DISABLE_CACHE')},
 'tsxInstalledModule':{'path':str(module),'sha256':module_sha,'scope':'Parentenv inherited. No assertion that Vitest uses tsx or that this option changed timing/memory.'},
 'frozenPre':pre,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text()}
if mx-cur<r['requiredHeadroom']:
 (D/'pure35-guard75.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
args=['node','--max-old-space-size=512','node_modules/vitest/vitest.mjs','run','--config',str(D/'vitest-pure35.config.mts'),
 '--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(D/'pure35.json')]
r['args']=args;r['startedAtUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(D/'pure35-started.json').write_text(json.dumps(r,indent=2)+'\n')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);started=time.monotonic()
with(D/'pure35.log').open('xb') as out:q=subprocess.run(args,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT)
r.update(exit=q.returncode,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-started,
 source1553ExactAfter=exact(),frozenPost=frozen(),oomAfter=Path('/sys/fs/cgroup/memory.events').read_text(),logSHA256=H(D/'pure35.log'),tsxInstalledModuleExactAfter=H(module)==module_sha)
(D/'pure35-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(q.returncode)
