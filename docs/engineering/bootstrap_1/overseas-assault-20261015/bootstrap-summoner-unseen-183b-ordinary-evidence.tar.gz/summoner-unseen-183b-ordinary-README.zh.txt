真实普通0召唤新种子：固定183b，144000观察上限无胜

来源与规则
- 唯一实际游戏进程从未改动的 scripts/bootstrap_1-inspect.ts 普通0启动，未使用resume、人工命令、world/memory种子或对手削弱。独立source worktree=sketch-rts-summoner-unseen-183b-control，HEAD183b84879b97902fcb57e9acadbce62b0fcfb872；856运行TS/数据配置pre/post哈希0差异，git净。
- v9_summoner Ember p0，物理side1；正常冻结v8 Grove p1。双方标准500金、3used、8cap、3worker。think15。
- factory sapphireArchipelago + --unseen，seed bootstrap_1-unseen-summoner-v8-20261015-01；实际snapshot.map.id=ladder，是未见生成图，不称官方固定图。批准出生规则沿用bootstrapGame。
- rulesVersion2；frozenRevision d1ae110f2edd99f9c7d899ed61557891ab587639，manifest184项全部核对，SHA0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。既有生产API标识迁移等价性和冻结归属不改。

结果与局限
- 原进程正常退出0，result tick144000 winner=null completed=true仅代表inspect运行结束；native match没有winner/endedAtTick。不是自然完成比赛、不是平局规则判定、不是赢、不是bootstrap验收。没有因局部改善/慢或窄调查提早停止。
- 自己28单位/12建筑，敌9单位/14建筑；双方主hall均900、自己0建筑摧毁；自己loss3，敌loss19。自己gold4.22，敌205.84。双方主矿耗尽，空岛gold-seat4-main仍6000。最终world nextId22167。
- 第一载worker+3ravager的进攻船在14400样本已返航，未证明成功登陆。第二载工人船原settle目标是空岛，15600已rebase回家。确切15060/15075/15090殖民因果由另行聚焦同源重放核实，本包不凭样本猜测第一次转换原因。
- 67200及144000，9名永久地面军队仍在甲板：1043的3ravager+4summoner已全上船，仍loading since24015，progress停于24345；1624载另2summoner，空crew carrier2423周期建loading。动态spirit刷新进度不是战略到达。此包只记录原局，不修改或降低出航门槛。敌剩陆军弱于早期，仍无攻击敌基地效果。
- 原破损容器未提交改动恢复缺口仍未恢复，不声称复制。三条路线、所有单对手/六种配对、官方地图与未见种子最终自然完整对局要求仍未完成。

完整恢复数据
- ordinary.json每个rows[i]有该tick的p0/p1完整policy memory；ordinary.json.frames/TICK.json有同tick完整snapshot和nextId。按tick合并，不拿其它样本mem凑续局。120个1200间隔完整world/memory配对经postflight核对，终档144000齐。
- frames/0.json是prelaunch deterministic factory独立witness；原inspect在自身进程另建同factory开局，不伪称0witness是实际loop hook采集。该时fresh memory provider无已初始化owner memory，以null明确记录缺失；不是人为策略种子。
- sources.tar.gz保存实际运行live TS/共享模拟/SDK/脚本/配置/数据及frozen源全字节，INDEX逐项核对；runtime-source.json保存prelaunch HEAD/hash/manifest/确切命令。native-client-source.tar.gz为同clean HEAD真实client/recorder源码。
- PNG来自native drawWorld渲染实际存档。0/7200/14400/144000已人工视觉检查；新UnitFacingTracker不重建历史朝向/动画，不用sprite朝向证明射击。
- .log逐样本原进程输出；process-record.json记录启动、进程ID、磁盘维护及正常退出。/workspace曾0空余，只sparse排除本control已重复的docs/*.tar.gz，不改856运行胶囊文件，未重启或换码。root权威包/Git保留。

重现
新建独立detached worktree到183b，安装/复用依赖；python prepare-fixed-bootstrap-opening.py --source-root ABSOLUTE_WORKTREE --commit 183b84879b97902fcb57e9acadbce62b0fcfb872 --out-prefix ABSOLUTE_NEW_PREFIX --map sapphireArchipelago --seed bootstrap_1-unseen-summoner-v8-20261015-01 --subject v9_summoner --opponents v8 --race ember --side 1 --unseen --ticks 144000 --sample-ticks 1200
再完整执行新launch.json中的argv，cwd保持独立worktree，不用resume。已有输入不得覆盖。为诊断可恢复67200/144000世界和该tick双方mem，但必须另标同源续局或换码对照，不拼接成新0局。本局不重复全矩阵。
