from pathlib import Path
import hashlib,json,tarfile
out=Path('/tmp/knight-unmedicated-6f80');archive=Path('/tmp/knight-unmedicated-preplan-evidence.tar.gz');sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((out/'preplan-replay-result.json').read_bytes());queries=json.loads((out/'care-boundaries-query.json').read_bytes());assert all(result['equals'].values()) and not result['sourceChanges'];assert all(r['claimQueryMemoryUnchanged'] and r['originalCompleteInputUnchanged'] for r in queries['rows'])
files={str(p.relative_to(out)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and p.name!='INDEX.json'}
(out/'INDEX.json').write_text(json.dumps({'algorithm':'SHA-256','classification':'Read-only exact180tick native preplan and care boundary evidence, captured before any new waypoint candidate source. References existing mixed fixed source capsule SHA990521460e5cb9b7d180d04ce64045151d980c417bea35d1ae708bc4dfad5e1c in prior separately delivered mixed package. Every payload below verified; INDEX excludes itself.','files':files},indent=2)+'\n')
with tarfile.open(archive,'w:gz') as t:
 for n in [*files,'INDEX.json']:t.add(out/n,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert set(t.getnames())==set(files)|{'INDEX.json'}
 for n,m in files.items():
  b=t.extractfile(n).read();assert len(b)==m['bytes'] and sha(b)==m['sha256']
receipt={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payloadsVerified':len(files),'entriesVerified':len(files)+1,'nativeReplay180TickWorldNextIdBothMemAllCommandsExact':True,'runtimeChanges':[],'careQueriesPureAndInputsUnchanged':True}
Path('/tmp/knight-unmedicated-preplan-evidence-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
