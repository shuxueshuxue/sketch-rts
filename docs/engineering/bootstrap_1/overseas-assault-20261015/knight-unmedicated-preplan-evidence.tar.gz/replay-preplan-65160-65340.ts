import {readFileSync,writeFileSync,realpathSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/shared/sim.ts';
import {createAiMemoryProvider} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/tmp/sketch-rts-knight-evacuation-6f80-control/scripts/bootstrap_1-planner.ts';
import {runAiGameLoop} from '/tmp/sketch-rts-knight-evacuation-6f80-control/src/ai/game-runner.ts';
const source='/tmp/sketch-rts-knight-evacuation-6f80-control',out='/tmp/knight-unmedicated-6f80',old='/tmp/knight-evacuation-6f80',sha=(b:any)=>createHash('sha256').update(b).digest('hex'),norm=(v:any)=>JSON.parse(JSON.stringify(v));
if(realpathSync(process.cwd())!==source)throw Error('wrong git cwd');
const manifest=JSON.parse(readFileSync(old+'/candidate-prelaunch.json','utf8'));
const changes=()=>Object.entries(manifest.runtimeSupportHashes).filter(([p,h])=>sha(readFileSync(source+'/'+p))!==h).map(([p])=>p);if(changes().length)throw Error('fixed source changed');
const native=JSON.parse(readFileSync(old+'/candidate64800-68400.json','utf8')),frames=JSON.parse(gunzipSync(readFileSync(old+'/candidate64800-68400-frames.json.gz')).toString()),start=frames.find((f:any)=>f.snapshot.tick===65160&&f.label==='sample'),expected=frames.find((f:any)=>f.snapshot.tick===65340&&f.label==='sample'),agents=JSON.parse(readFileSync(old+'/original-report-captured.json','utf8')).setup.agents;
writeFileSync(out+'/input-65160.json',JSON.stringify(start));
const g=createGame('bareDuel'),m=createAiMemoryProvider();restoreSnapshotIntoGame(g,start.snapshot,start.nextId);for(const[o,v]of Object.entries(start.memories))m.set!(o,structuredClone(v) as any);
const full=()=>norm({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(['p0','p1'].map(o=>[o,m.get(o)]))});
const restored={world:isDeepStrictEqual(full().snapshot,start.snapshot),nextId:g.nextId===start.nextId,bothMemories:isDeepStrictEqual(full().memories,start.memories)};if(Object.values(restored).some(x=>!x))throw Error('restore mismatch');
writeFileSync(out+'/preplan-replay-prelaunch.json',JSON.stringify({classification:'Actual prelaunch180tick read-only exact fixed evacuation-combination source diagnostic, not a new candidate/fullgame. Fixed production source870 files match prior candidate prelaunch. Test-only type fix is separately documented in original mixed archive.',source,sourceChanges:changes(),runtimeManifestSHA256:sha(readFileSync(old+'/candidate-prelaunch.json')),driverSHA256:sha(readFileSync(import.meta.filename)),inputSHA256:sha(readFileSync(out+'/input-65160.json')),start:65160,end:65340,restored},null,2));
const planner=await createBootstrapCommandPlanner(m),allFrames:any[]=[{label:'start',...full()}],issued:any[]=[],preplans:any[]=[];
runAiGameLoop({name:'Read-only actual unmedicated movement interruption preplans',game:g,agents,maxTicks:65340,thinkInterval:15,commandPlanner:(ctx:any)=>{
 if(ctx.owner==='p0'&&[65190,65205,65265,65280].includes(ctx.snapshot.tick)){
   const f=norm({snapshot:ctx.snapshot,nextId:g.nextId,memories:Object.fromEntries(['p0','p1'].map(o=>[o,m.get(o)]))});writeFileSync(out+`/preplan-${ctx.snapshot.tick}.json`,JSON.stringify(f));preplans.push({tick:ctx.snapshot.tick,SHA256:sha(readFileSync(out+`/preplan-${ctx.snapshot.tick}.json`))});
 }return planner(ctx);
}},{onCommand(e:any){issued.push({tick:e.tick,owner:e.owner,scriptId:e.scriptId,command:structuredClone(e.command)})},onStep(){allFrames.push({label:'actual-native-step',...full()});}});
const final=full(),equals={world:isDeepStrictEqual(final.snapshot,expected.snapshot),nextId:final.nextId===expected.nextId,bothMemories:isDeepStrictEqual(final.memories,expected.memories),allIssuedCommands:isDeepStrictEqual(issued,native.issued.filter((e:any)=>e.tick>=65160&&e.tick<65340))};
writeFileSync(out+'/preplan-replay-result.json',JSON.stringify({classification:'Actual180native-tick exactbothAI reconstruction of missing truepreplans from the prior actual changed-code mixed trial. No new tactical code, no manual gameplay commands/world edits.',source,sourceChanges:changes(),restored,start:65160,end:g.tick,equals,preplans,issued,final}));
writeFileSync(out+'/preplan-replay-frames.json.gz',gzipSync(JSON.stringify(allFrames)));console.log(JSON.stringify({done:true,start:65160,end:g.tick,restored,equals,preplans,sourceChanges:changes()}));
