b0 incomingLanding资本保护：开发种子换码9600 + 同源24000，65739原生自然胜

结果与归属
- 原始183b普通0→144000为inspection horizon，无winner/endedAtTick，不是胜利。原完整证据另包：bootstrap-summoner-unseen-183b-ordinary-evidence.tar.gz，SHA90557d1e487f9eb3ecf7b219d56bc1e45eabaa472e578d8ea9a474e27eddb371。原故障容器未提交修改恢复缺口继续存在，不声称复制。
- 本包唯一生产候选b0c8bd7e173c9038071d01531b8a752d3e9ebb48，相对183b仅incomingLanding局部变更：仍要求sea、敌方、unload、同一地面、武装乘员；增加到目的岸可达海路<=原HOME_WATERS900或当前真实可原生卸下武装乘员。没有削弱敌人、改资源人口、改变规则/技能/地形、降低军力门槛或混入其它AI候选。
- v9_summoner Ember p0物理side1 vs正常冻结v8 Grove p1；factory sapphireArchipelago --unseen实际为ladder生成图，seed bootstrap_1-unseen-summoner-v8-20261015-01。此种子已经观察调试，是开发种子；--unseen仅为生成地图开关，本换码结果不算未见泛化。普通0双方原500金/3used/8cap，批准出生规则与原图保留。
- 从原183b唯一9600完整world/nextId1390/p0+p1全部memory直接恢复，未注入钱、命令、修改world或mem；9600→24000正常双方AI。24000完整档同源继续，native自然65739 winner=p0/endedAtTick65739，敌0单位/0建筑，14建筑全部摧毁(13非基地)。这是changed-code9600 + same-source24000自然胜，不是b0普通0胜、不拼原144k成绩，不是三路线/所有对手地图种子的最终验收。
- 最终自己82单位/24建筑/4个完整900厅；spent18435。损失91不是零损：最终131条持久native corpse与全部阵营unitsLost131完全对账，己方74个spirit临时召唤兵战斗死亡+17永久单位(6worker/6ravager/3summoner/1cutter/1bombard)。17永久死亡按其完整60tick原生计数窗，11记neutral、6非neutral，逐ID/tick/坐标在permanent-losses-and-summons.json。首建工1010后来37619在中央野岛死亡；胜利不抹去这类扩张/打野损失。

实战因果与细窗
- 额外采样查询控制：原183b同9600→12000，未改inspect，仅sample60替换原1200；共同10800/12000完整world帧文件字节、nextId、双方全mem均相等。sampling60-control-result.json保留40样本和856源0差异。无需因raw snapshot含undefined而误判落盘JSON漂移。
- b0首公开build厅命令13710，工人需真实行走；13971原生创建hall1712(7056,8144)，gold556→156/spent4174→4574，实际付400。14531完整900，同tick原生维修费1另行记录。14724工人1010把seat2矿10金存入新厅，carry10→0、return→toMine、gold65→75/无支出，确认首笔收入10；14531至14724相邻native微窗覆盖，无更早殖民送金事件。注意殖民路线也改变为seat2，不假称仅在原seat4轨迹补钱。
- 这些公开正常planner/原生步骤微窗均<=60tick，恢复与末端world/nextId/全部mem与真实主线各三true，858源前后0差异：13920→13980付款；14520→14580完工；14580→14640、14640→14700首次送金路径；14700→14760收入；20700→20760真实敌运输消灭。
- 20757敌空载运输1366在海面(6384,4240)被消灭，p0 kills10→11、p1 loss11→12、neutral未增；原4枪骑最后活样本均在甲板。此局证明海上拦截，不能冒称验证了敌地面兵登陆后的基地防御；近岸/移动/当前真卸载等保留由6项边界测试验证。
- 61200已毁敌6建筑，临时spirit在敌岛地面进攻farm，召唤路线由甲板投射临时兵产生进攻作用；永久军不登陆不能直接等同没有陆攻。65739敌军与建筑均清空。
- carrier2290在40740曾远岛boarder挂靠、loaded/idle；真实45000已离开该loading转经济任务，不将中间片段误说永久死锁。carrier2290-actual-loading-samples.json保留只读原始提取。

恢复与完整定源
- stage1 summoner-incoming-only-b0c8.json及.json.frames：240个每60tick完整世界/nextId与同tick报告行p0/p1全部policy memory，9600输入单独选档，不改原始报告。
- stage2 summoner-incoming-b0c8-cont24000.json及.json.frames：695个每60tick完整档至65700，加自然终局65739，共696对。两阶段共936对，24000输入世界/nextId3295/mem逐项与stage1终档相同，输入帧SHA3185cfd095f437b75b0f553d759eee85c0c72a0853ef1ae18090ae5c3b54b5c9。最终nextId27096/world SHAb557b46df167db760b65484e8fb47667d6bf250e278be72d3f1fb0757f606ff2。
- 两阶段均clean b0固定858源(TS/共享模拟/SDK/策略/脚本/配置数据) pre/post0变化；各-runtime-source.json含源hash、输入hash、精确argv/cwd、restore-only三项通过；各-sources.tar.gz含全部live/frozen运行源和INDEX。规则2/frozenRevision d1ae110f2edd99f9c7d899ed61557891ab587639，184项核对，manifest SHA0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。生产API迁移既有等价性和冻结成绩归属保留，不在此重写旧成绩。
- source tar阶段1 SHAafb4fc62880a5dfc9603db8b91c03862aa86e1024fc5269b45ec3fd16620db07；阶段2 SHA2ac13f65018ea868faa8b5662eb1f7dd59cc2e92fdb0fd9d59fa2ecd80b7d633。采样控制source SHA df8c54e360f8c3f591793d7dee8796e090c62eb633e87604eca3bc725e513ebc。
- 报告row里的policy必须与同tick世界合并恢复，不能混用其它tick。预启动原生snapshotGame含undefined可选属性，raw-object与磁盘JSON isDeepStrictEqual false不代表世界改变；严格JSON序列化字节与nextId/mem核对均true，原错误断言诊断保留。最初/tmp helper无type:module的准备失败也在游戏启动前保留；都没有修改生产或游戏输入。

验证、纠错与视觉
- external-validation/保留b0最终6边界、相邻4文件57测试、tsc日志，以及提交前fixture构建3失败日志(不是b0最终测试失败)。root后续整合检查不混进b0来源。
- 外部预算纠错：[external-review/ERRATA.zh.md]。b0测试顶部“workforce绕过reserve”和fixture knownScopeLimit的同一描述是错误注释，冻结858源期间不改。真实script-runner已给miningWorkforce传budgetAfter(navalReserve+shopReserve)，原183历史75消费发生reserve0；没有第二生产预算修复。external-review/bootstrap-workforce-budget-errata-evidence.tar.gz为完整whole-planner只读反证包，附其SHA。只读raw脚本人工付款诊断不混成比赛事实。
- native-client-source-b0c8.tar.gz为同HEAD client/recorder源码；PNG由native drawWorld渲染真实存档：14760新殖民、61200旧183 vs b0敌基地同相机、65739实际终局，均已人工视觉检查。新facing tracker不重建历史动画，不把朝向当射击证据；camera在敌实体全灭时取输入原厅位置，但所画世界始终为65739。
- 此工作不修改main，不干扰规则3/4工作；没有并v13/deployment/falseprogress/陆战其它候选。下一真正普通0须从新的clean整合提交启动，沿相同开发seed对照，此包仍不计为0局。
