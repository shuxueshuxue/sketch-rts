import{readFileSync,writeFileSync}from'node:fs';import{isDeepStrictEqual}from'node:util';import{pathToFileURL}from'node:url';
const source="/tmp/sketch-rts-colony-capital-control",input="/tmp/bootstrap-summoner-incoming9600-20261015/input-b0c8-24000.json",out="/tmp/bootstrap-summoner-incoming9600-20261015/summoner-incoming-b0c8-cont24000-restore-preflight.json";
const{bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const{restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const{createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const report=JSON.parse(readFileSync(input,'utf8')),row=report.rows.at(-1),setup=report.setup;
const frame=JSON.parse(readFileSync(input+'.frames/'+row.tick+'.json','utf8'));
const match=bootstrapMatches(setup.seed,[setup.map],144000,setup.unseen).find((m:any)=>m.subject===report.subject&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===Object.values(setup.agents).slice(1).map((a:any)=>a.version).join('+'));
if(!match)throw new Error('Exact match absent');const game=bootstrapGame(match);restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const provider=createAiMemoryProvider();for(const[owner,p]of Object.entries(row.players)as any[])provider.set(owner,structuredClone(p.policy));
const restored=snapshotGame(game),memories=Object.fromEntries(Object.keys(row.players).map(owner=>[owner,provider.get(owner)]));
const result={classification:'Restore-only preflight. No native ticks or gameplay commands were executed.',tick:game.tick,nextId:game.nextId,
rawSnapshotObjectEqual:isDeepStrictEqual(restored,frame.snapshot),worldEqual:isDeepStrictEqual(JSON.parse(JSON.stringify(restored)),frame.snapshot),serializedWorldEqual:JSON.stringify(restored)===JSON.stringify(frame.snapshot),nextIdEqual:game.nextId===frame.nextId,
allMemoriesEqual:Object.entries(row.players).every(([owner,p]:any)=>isDeepStrictEqual(provider.get(owner),p.policy)),owners:Object.keys(memories),actualMapId:restored.map.id};
writeFileSync(out,JSON.stringify(result,null,2)+'\n');if(!result.worldEqual||!result.serializedWorldEqual||!result.nextIdEqual||!result.allMemoriesEqual)throw new Error('Restore mismatch');console.log(JSON.stringify(result));
