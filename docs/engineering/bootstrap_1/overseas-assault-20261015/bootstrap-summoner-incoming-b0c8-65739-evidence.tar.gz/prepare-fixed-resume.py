"""Seal a clean, selected source and an unchanged full checkpoint; prepare only."""
import argparse, hashlib, io, json, pathlib, subprocess, tarfile
from datetime import datetime, timezone
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-root',required=True);p.add_argument('--commit',required=True)
p.add_argument('--prefix',required=True);p.add_argument('--input',required=True)
p.add_argument('--expected-tick',type=int,default=9600);p.add_argument('--expected-next-id',type=int);p.add_argument('--end',type=int,default=24000);p.add_argument('--sample-ticks',type=int,default=60)
a=p.parse_args();source=pathlib.Path(a.source_root).resolve();prefix=pathlib.Path(a.prefix).resolve();inp=pathlib.Path(a.input).resolve()
git=lambda *v:subprocess.check_output(['git',*v],cwd=source)
sha=lambda d:hashlib.sha256(d).hexdigest()
dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse',a.commit+'^{commit}').decode().strip()
assert not git('status','--porcelain','--untracked-files=normal').decode(),'Source must be clean and immutable before capture'
for suffix in ['.json','-runtime-source.json','-sources.tar.gz','-launch.json']:
 assert not pathlib.Path(str(prefix)+suffix).exists(),'Never overwrite an existing experiment'
report=json.loads(inp.read_text());assert len(report['rows'])==1
row=report['rows'][0];tick=row['tick'];framepath=pathlib.Path(str(inp)+f'.frames/{tick}.json');frame=json.loads(framepath.read_text())
assert tick==a.expected_tick==frame['snapshot']['tick']
if a.expected_next_id is not None: assert frame['nextId']==a.expected_next_id
assert all(isinstance(row['players'][owner]['policy'],dict)for owner in ['p0','p1'])
manifest_path=source/'docs/engineering/bootstrap_1/frozen-policy.json';manifest_data=manifest_path.read_bytes();manifest=json.loads(manifest_data)
assert manifest['rulesVersion']==2 and manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639'
assert sha(manifest_data)=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
prefix.parent.mkdir(parents=True,exist_ok=True)
preflight=pathlib.Path(str(prefix)+'-restore-preflight.ts')
preflight.write_text('''import{readFileSync,writeFileSync}from'node:fs';import{isDeepStrictEqual}from'node:util';import{pathToFileURL}from'node:url';
const source=SOURCE,input=INPUT,out=OUTPUT;
const{bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const{restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const{createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const report=JSON.parse(readFileSync(input,'utf8')),row=report.rows.at(-1),setup=report.setup;
const frame=JSON.parse(readFileSync(input+'.frames/'+row.tick+'.json','utf8'));
const match=bootstrapMatches(setup.seed,[setup.map],END,setup.unseen).find((m:any)=>m.subject===report.subject&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===Object.values(setup.agents).slice(1).map((a:any)=>a.version).join('+'));
if(!match)throw new Error('Exact match absent');const game=bootstrapGame(match);restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const provider=createAiMemoryProvider();for(const[owner,p]of Object.entries(row.players)as any[])provider.set(owner,structuredClone(p.policy));
const restored=snapshotGame(game),memories=Object.fromEntries(Object.keys(row.players).map(owner=>[owner,provider.get(owner)]));
const result={classification:'Restore-only preflight. No native ticks or gameplay commands were executed.',tick:game.tick,nextId:game.nextId,
rawSnapshotObjectEqual:isDeepStrictEqual(restored,frame.snapshot),worldEqual:isDeepStrictEqual(JSON.parse(JSON.stringify(restored)),frame.snapshot),serializedWorldEqual:JSON.stringify(restored)===JSON.stringify(frame.snapshot),nextIdEqual:game.nextId===frame.nextId,
allMemoriesEqual:Object.entries(row.players).every(([owner,p]:any)=>isDeepStrictEqual(provider.get(owner),p.policy)),owners:Object.keys(memories),actualMapId:restored.map.id};
writeFileSync(out,JSON.stringify(result,null,2)+'\\n');if(!result.worldEqual||!result.serializedWorldEqual||!result.nextIdEqual||!result.allMemoriesEqual)throw new Error('Restore mismatch');console.log(JSON.stringify(result));
'''.replace('SOURCE',json.dumps(str(source))).replace('INPUT',json.dumps(str(inp))).replace('OUTPUT',json.dumps(str(prefix)+'-restore-preflight.json')).replace('END',str(a.end)))
subprocess.run(['node','--import','tsx',str(preflight)],cwd=source,check=True)
runtime={};all_source={}
for tree in ['src/ai','src/shared','src/sdk']:
 for path in sorted((source/tree).rglob('*')):
  if path.is_file():
   name=str(path.relative_to(source));all_source[name]=path.read_bytes()
   if path.suffix in ['.ts','.tsx']:runtime[name]=sha(all_source[name])
for path in sorted((source/'scripts').glob('bootstrap_1*.ts')):
 name=str(path.relative_to(source));all_source[name]=path.read_bytes();runtime[name]=sha(all_source[name])
for name in ['package.json','package-lock.json','tsconfig.json']:all_source[name]=(source/name).read_bytes()
frozen={}
with tarfile.open(fileobj=io.BytesIO(git('archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared')),mode='r:')as tf:
 for member in tf:
  if member.isfile():frozen[member.name]=tf.extractfile(member).read()
for name,digest in manifest['files'].items():assert sha(frozen[name])==digest,name
archive=pathlib.Path(str(prefix)+'-sources.tar.gz');index={}
with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
 def add(name,data):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data));index[name]=sha(data)
 for name,data in sorted(all_source.items()):add('live/'+name,data)
 for name,data in sorted(frozen.items()):add('frozen/'+name,data)
 add('frozen-policy.json',manifest_data);add('input-report.json',inp.read_bytes());add('input-frame.json',framepath.read_bytes())
 add('restore-preflight.ts',preflight.read_bytes());add('restore-preflight.json',pathlib.Path(str(prefix)+'-restore-preflight.json').read_bytes());add('prepare-fixed-resume.py',pathlib.Path(__file__).read_bytes())
 data=json.dumps({'algorithm':'SHA-256','files':index},indent=2).encode()+b'\n';info=tarfile.TarInfo('INDEX.json');info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tf:
 for name,digest in index.items():assert sha(tf.extractfile(name).read())==digest,name
setup=report['setup'];agents=setup['agents'];opponents='+'.join(x['version']for owner,x in agents.items()if owner!='p0')
command=['node','--import','tsx','scripts/bootstrap_1-inspect.ts','--map',setup['map'],'--seed',setup['seed'],'--subject',report['subject'],'--opponents',opponents,'--race',agents['p0']['race'],'--side',str(setup['side']),'--ticks',str(a.end),'--sample-ticks',str(a.sample_ticks),'--frames','--resume',str(inp),'--out',str(prefix)+'.json']
if setup['unseen']:command.append('--unseen')
assert head==git('rev-parse','HEAD').decode().strip()and not git('status','--porcelain','--untracked-files=normal').decode()
classification=('Prelaunch clean fixed-source same-code restore of original ordinary183b tick9600, changed sample frequency control. Never a new tick0 game.' if head=='183b84879b97902fcb57e9acadbce62b0fcfb872' else ('Prelaunch clean fixed-source changed-code continuation from original ordinary183b tick9600. Never a new tick0 game and never concatenated with old144000 result.' if tick==9600 else 'Prelaunch clean fixed-source same-code24000 continuation of b0c8 changed-code9600 experiment. Original ordinary183b history before9600 is preserved and not relabelled ordinary0 victory.'))
capsule={'classification':classification,
'createdAtUtc':datetime.now(timezone.utc).isoformat(),'sourceRoot':str(source),'baseCommit':head,'runtimeHashes':runtime,'supportingDataHashes':{n:sha(d)for n,d in all_source.items()if n not in runtime},'inputReport':str(inp),'inputReportSHA256':sha(inp.read_bytes()),'inputFrame':str(framepath),'inputFrameSHA256':sha(framepath.read_bytes()),'inputTick':tick,'inputNextId':frame['nextId'],'originalOrdinaryCommit':'183b84879b97902fcb57e9acadbce62b0fcfb872','frozenManifestSha256':sha(manifest_data),'frozenRevision':manifest['revision'],'frozenManifestEntriesVerified':len(manifest['files']),'sourceArchive':str(archive),'sourceArchiveSHA256':sha(archive.read_bytes()),'sourceArchivePayloadsVerified':len(index),'command':command,'cwd':str(source),'end':a.end,'sampleTicks':a.sample_ticks,'restorePreflight':json.loads(pathlib.Path(str(prefix)+'-restore-preflight.json').read_text())}
dump(pathlib.Path(str(prefix)+'-runtime-source.json'),capsule);dump(pathlib.Path(str(prefix)+'-launch.json'),{'preparedOnly':True,'gameplayStarted':False,'expectedCommit':head,'cwd':str(source),'argv':command,'stdoutLog':str(prefix)+'.log'})
print(json.dumps({'commit':head,'sourceFiles':len(all_source),'sourceArchiveSHA256':capsule['sourceArchiveSHA256'],'inputTick':tick,'command':command},indent=2))
