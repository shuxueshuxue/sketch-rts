import { NativeLedger } from './native-ledger';
const copy = (value: any) => JSON.parse(JSON.stringify(value));
/** Passive external observer; never issues commands or modifies any game object. */
export class NativeTelemetry {
  ledger: NativeLedger; lastHit = new Map<string, any>(); fatalHits = new Map<string, any>();
  hullFatal = new Map<string, any>(); hitIndex = 0; commandIndex: number | null = null;
  counts: Record<string, Record<string, number>> = {};
  terminalRecords = new Map<string, any>();
  constructor(private game: any, private emit: (stream: string, event: any) => void) {
    this.ledger = new NativeLedger(game.units, game.buildings);
  }
  private count(owner: string, category: string) {
    const row = this.counts[owner] ?? (this.counts[owner] = {}); row[category] = (row[category] ?? 0) + 1;
  }
  hit(attacker: any, target: any, damage: number, hpBefore: number) {
    const positiveToNonpositive = hpBefore > 0 && target.hp <= 0;
    const hullFatal = positiveToNonpositive && !!target.sailing;
    // Native observer.hit precedes recordKill's recursive drowning. Preserve all
    // passengers and the live subset now, including already-dead collateral victims.
    const passengersAtHullFatal = hullFatal ? this.game.units.filter((u: any) => u.deck?.shipId === target.id).map(copy) : undefined;
    const hit = copy({ index: this.hitIndex++, tick: this.game.tick, commandIndex: this.commandIndex,
      attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind,
      target: target.id, targetOwner: target.owner, targetKind: target.kind, targetIsUnit: 'order' in target,
      targetExpiresTick: target.expiresTick ?? null, damage, hpBefore, hpAfter: target.hp, positiveToNonpositive,
      targetAtObservation: target, commandIndexPhase:this.commandIndex===null?'native-step':'anticipated-accepted-public-command; confirmed by following onCommand',passengersAtHullFatal,
      livePassengerIdsAtHullFatal: passengersAtHullFatal?.filter((u: any) => u.hp > 0).map((u: any) => u.id) });
    this.lastHit.set(target.id, hit);
    if (positiveToNonpositive) this.fatalHits.set(target.id, hit);
    if (hullFatal) this.hullFatal.set(target.id, hit);
    this.emit('native-hits', hit);
  }
  beforeStep() { this.observe('before-step'); this.ledger.beforeStep(this.game.units); }
  observe(stage: string) {
    const previousUnits = this.ledger.units;
    const raw = this.ledger.observe(this.game.tick, stage, this.game.units, this.game.buildings, this.lastHit);
    // Born-and-killed inside one native step may not exist at either boundary.
    // Fatal observer target data is still evidence; do not infer no death from absence.
    for (const [id, hit] of this.fatalHits) if (hit.targetIsUnit && !this.ledger.terminal.has(id)
      && !this.game.units.some((u: any) => u.id === id && u.hp > 0)) {
      this.ledger.terminal.add(id);
      raw.push({tick:this.game.tick,stage,type:'native-unit-terminal',id,previous:hit.targetAtObservation,
        atObservation:null,observedAs:'native-positive-to-nonpositive-hit-without-boundary-body',
        permanent:hit.targetAtObservation.expiresTick===undefined,lastNativeHit:hit});
    }
    // A summon can be born, board, and drown inside one step without its own
    // hit callback or a boundary body. The pre-recordKill hull witness retains it.
    for(const hit of this.hullFatal.values())for(const passenger of hit.passengersAtHullFatal??[])
      if(passenger.hp>0&&!this.ledger.terminal.has(passenger.id)
        &&!this.game.units.some((u:any)=>u.id===passenger.id&&u.hp>0)){
        this.ledger.terminal.add(passenger.id);
        raw.push({tick:this.game.tick,stage,type:'native-unit-terminal',id:passenger.id,previous:passenger,
          atObservation:null,observedAs:'alive-aboard-fatal-hull-without-boundary-body',
          permanent:passenger.expiresTick===undefined,lastNativeHit:this.lastHit.get(passenger.id)});
      }
    const lostHulls = new Set(raw.filter((e: any) => e.type === 'native-unit-terminal'
      && (e.atObservation ?? e.previous)?.sailing).map((e: any) => e.id));
    for (const event of raw) {
      const entry: any = { ...event, commandIndex: this.commandIndex };
      if (event.type === 'native-unit-terminal') {
        const body = event.atObservation ?? event.previous, id = event.id;
        const fatalHit = this.fatalHits.get(id), shipId = body?.deck?.shipId;
        const carryingHullFatal = shipId ? this.hullFatal.get(shipId) : undefined;
        const aboardLivingAtHullFatal = !!carryingHullFatal?.livePassengerIdsAtHullFatal?.includes(id);
        const knownDeadHull = shipId && (lostHulls.has(shipId) || event.preStepCarryingHull?.ship?.hp <= 0);
        const corpse = this.game.corpses?.find((c: any) => c.unitId === id);
        const hpNonpositive = event.atObservation?.hp <= 0 || event.previous?.hp <= 0;
        const expiryEligible = body?.expiresTick !== undefined && body.expiresTick <= this.game.tick;
        // Expiry precedes dead-hull cleanup; mere presence on a dead hull cannot
        // turn an already expiring, still-live summon into a proven drowning.
        const deathEvidence = hpNonpositive || !!fatalHit || !!corpse || aboardLivingAtHullFatal || !!knownDeadHull && !expiryEligible;
        entry.terminalClass = deathEvidence ? 'death-observed' : expiryEligible ? 'lifetime-expiry-eligible-removal' : 'removal-cause-unconfirmed';
        entry.evidence = { hpNonpositive, nativePositiveToNonpositiveHit: fatalHit ?? null, corpse: corpse ?? null,
          expiryEligible, carryingHullFatal: carryingHullFatal ?? null, aboardLivingAtHullFatal, knownDeadHull: !!knownDeadHull };
        entry.permanent = body.expiresTick === undefined;
        this.count(body.owner, entry.terminalClass === 'death-observed' ? entry.permanent ? 'permanentDeathObservations' : 'temporaryDeathObservations' : entry.terminalClass);
        entry.confirmation = event.atObservation ? 'hp<=0-awaiting-cleanup' : 'absent-at-native-boundary';
        this.terminalRecords.set(id,{owner:body.owner,permanent:entry.permanent,expiresTick:body.expiresTick,terminalClass:entry.terminalClass,confirmation:entry.confirmation});
        if(entry.terminalClass==='death-observed'&&!event.atObservation)this.count(body.owner,entry.permanent?'permanentDeathRemovedConfirmations':'temporaryDeathRemovedConfirmations');
        this.emit('native-deaths', entry);
        if (body.sailing) this.emit('ship-losses', {tick:this.game.tick,stage,commandIndex:this.commandIndex,
          terminalClass:entry.terminalClass,ship:body,nativeFatalHull:this.hullFatal.get(id)??null,
          previousBoundaryPassengers:[...previousUnits.values()].filter((u:any)=>u.deck?.shipId===id),
          preStepHull:event.preStepHull??null,
          caution:'Passenger presence at fatal hull and live-at-fatal subset are separate; positive-to-nonpositive hit is an observed call boundary, not proof of sole/direct damage cause.'});
      }
      if(event.type==='unit-returned-positive-hp') {
        const id=event.after.id,prior=this.terminalRecords.get(id);
        if(prior){prior.confirmation='returned-positive';this.count(event.after.owner,'returnedPositiveAfterTerminal');this.emit('native-deaths',{tick:this.game.tick,stage,commandIndex:this.commandIndex,type:'terminal-status-update',id,status:'returned-positive',previousTerminal:copy(prior),after:event.after});}
      }
      if(event.type==='unit-removal') {
        const id=event.previous.id,prior=this.terminalRecords.get(id);
        if(prior?.confirmation==='hp<=0-awaiting-cleanup'){
          prior.confirmation='native-removal-after-nonpositive';
          if(prior.terminalClass==='death-observed')this.count(prior.owner,prior.permanent?'permanentDeathRemovedConfirmations':'temporaryDeathRemovedConfirmations');
          this.emit('native-deaths',{tick:this.game.tick,stage,commandIndex:this.commandIndex,type:'terminal-status-update',id,status:prior.confirmation,terminalClass:prior.terminalClass,permanent:prior.permanent,expiryEligible:prior.expiresTick!==undefined&&prior.expiresTick<=this.game.tick});
        }
      }
      this.emit('native-events', entry);
    }
    // Persisted stream owns historical hits. Only live entities need last-hit
    // references; fatal hull evidence is retained through all crew in this boundary.
    for (const event of raw) if (event.type === 'native-unit-terminal' || event.type === 'native-building-terminal') {
      const id = event.id ?? event.previous?.id; this.lastHit.delete(id); this.fatalHits.delete(id);
    }
    for (const id of lostHulls) this.hullFatal.delete(id);
    return raw;
  }
  summary() { return copy({ counts: this.counts, nativeUnitsLost: this.game.match.stats.unitsLost,
    hitCount: this.hitIndex, terminalEntityIds: this.ledger.terminal.size,pendingNativeCleanup:[...this.terminalRecords].filter(([,r])=>r.confirmation==='hp<=0-awaiting-cleanup').map(([id,r])=>({id,...r})),
    caution:'DeathObservations are nonpositive/fatal observations, not irrevocable loss totals; positive returns and later removal confirmations are separate. Native unitsLost includes temporary deaths, and expiry runs before death cleanup. Compare counters/corpses/fatal hits/full states; do not equate every missing body with a permanent death. Event frames after public commands are mid-think observations, not automatically resumable before-think checkpoints.' }); }
}
