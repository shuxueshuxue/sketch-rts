import pathlib,subprocess,json,tarfile,hashlib
p=pathlib.Path(__file__).parent;source='/tmp/sketch-rts-active-worker-threat-control';cap=json.loads((p/'original-ordinary0/candidate-source.json').read_text());oids=set();blobs={};trees={}
def git(*args):return subprocess.check_output(['git','-C',source,*args])
for revision in [cap['head'],cap['frozenRevision']]:
 oids.add(revision)
 for row in git('ls-tree','-r','-t',revision).splitlines():
  meta,path=row.split(b'\t',1);mode,typ,oid=meta.decode().split();path=path.decode()
  if typ=='tree':oids.add(oid);trees[oid]=True
  elif revision==cap['head'] and path in cap['hashes']:oids.add(oid);blobs[revision+':'+path]=oid
  elif revision==cap['frozenRevision'] and (path=='package.json' or path.startswith(('src/ai/','src/sdk/','src/shared/'))):oids.add(oid);blobs[revision+':'+path]=oid
 oids.add(git('rev-parse',revision+'^{tree}').decode().strip())
q=p/'selected-source-objects.pack';q.write_bytes(subprocess.check_output(['git','-C',source,'pack-objects','--stdout'],input=('\n'.join(sorted(oids))+'\n').encode()))
(p/'selected-source-objects.json').write_text(json.dumps({'classification':'Partial Git object capsule for exact selected live/frozen source bytes and all directory trees of exact existing commits. Omitted unrelated binary/documentation blobs and older history; not a full clone or new commit. git archive of frozen runtime and source checkouts are supported.','commits':[cap['head'],cap['frozenRevision']],'objects':len(oids),'selectedBlobs':len(blobs),'packSHA256':hashlib.sha256(q.read_bytes()).hexdigest()},indent=2)+'\n')
print(q.stat().st_size,len(oids))
