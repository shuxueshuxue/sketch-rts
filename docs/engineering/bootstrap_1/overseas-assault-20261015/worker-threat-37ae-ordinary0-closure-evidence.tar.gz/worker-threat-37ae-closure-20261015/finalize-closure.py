import pathlib,json,gzip,hashlib,collections,subprocess,shutil,datetime
p=pathlib.Path(__file__).parent; original=pathlib.Path('/tmp/bootstrap-active-worker-threat-20261015'); baseline=pathlib.Path('/tmp/bootstrap-root-3bdb-ordinary0-20261015'); source=pathlib.Path('/tmp/sketch-rts-active-worker-threat-control')
def load(q):return json.loads(q.read_text())
def gz(q):return json.loads(gzip.decompress(q.read_bytes()))
def write(name,d): (p/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
r=load(original/'ordinary0.json'); final=gz(original/'ordinary0-final.json.gz'); s=final['snapshot']; first=load(p/'loss-ledger-first-pass.json'); own=[d for d in first['deaths'] if d['corpse']['owner']=='p0']; enemy=[d for d in first['deaths'] if d['corpse']['owner']=='p1']
wreck=[]
for label in ['native-sink-25200-25800','native-sink-58200-58800','native-sink-73800-75000','native-sink-62400-63000']:
 d=load(p/(label+'.json')); assert all(d['restore'].values()) and all(d['same'].values())
 for event in d['removed']:
  corpseids={c['unitId'] for c in event['corpsesAtTick']}
  for u in event['gone']:
   if u['owner'] in ['p0','p1'] and u['id'] not in corpseids and u.get('deck') and not u.get('expiresTick'):
    ship=u['deck']['shipId']
    if any(v['id']==ship for v in event['gone']):
     wreck.append({'id':u['id'],'kind':u['kind'],'owner':u['owner'],'tick':event['tick'],'previousNativeState':u,'sameTickHullRemoval':ship,'evidence':label+'.json','nativeLossBefore':event['unitsLostBefore'][u['owner']],'nativeLossAfter':event['unitsLostAfter'][u['owner']],'corpse':None})
assert len(wreck)==5
perma=[d for d in own if not d['temporary']]; temp=[d for d in own if d['temporary']]; ownwreck=[d for d in wreck if d['owner']=='p0'];enemywreck=[d for d in wreck if d['owner']=='p1']
counts=collections.Counter(d['corpse']['kind'] for d in perma);counts.update(d['kind'] for d in ownwreck)
assert len(perma)+len(ownwreck)==35 and len(temp)==36 and len(own)==67 and len(enemy)+len(enemywreck)==63
neutralTemp=[d for d in temp if (d.get('lethalHit') or {}).get('attackerOwner')=='neutral']; neutralPerma=[d for d in perma if (d.get('lethalHit') or {}).get('attackerOwner')=='neutral']
base=load(baseline/'ordinary.json');bf=load(baseline/'ordinary.json.frames/33688.json');bcs={c['unitId']:c for c in bf['snapshot']['corpses']}
wave=[]
for d in first['firstWavePermanentDeaths']:
 c=d['corpse'];bc=bcs[c['unitId']];wave.append({'id':c['unitId'],'kind':c['kind'],'currentTick':c['diedAtTick'],'baseline3bdbTick':bc['diedAtTick'],'deltaTicks':c['diedAtTick']-bc['diedAtTick'],'lethalHit':d['lethalHit'],'damageByAttacker':d['damageByAttacker']})
write('final-loss-reconciliation.json',{'classification':'Actual native losses; permanent bodies and temporary summons separate. Expiry without death is not counted as combat loss. Corpse-free wreckpassengers proven in bounded same-source normalbothAI replay, not inferred only from 600tick disappearance.','ownNativeLost':s['match']['stats']['unitsLost']['p0'],'ownPermanent':35,'ownPermanentCorpses':31,'ownCorpseFreeWreckPassengers':ownwreck,'ownPermanentByKind':dict(counts),'ownTemporarySpiritCombatDeaths':36,'ownTemporaryCorpseRows':temp,'ownPermanentCorpseRows':perma,'neutralLethalPermanentCorpseDeaths':neutralPerma,'neutralLethalTemporaryCorpseDeaths':neutralTemp,'neutralTemporaryCount':len(neutralTemp),'enemyNativeLost':63,'enemyCorpses':62,'enemyCorpseFreeWreckPassengers':enemywreck,'firstWaveFivePermanentComparison':wave,'enemySurvivors':[{k:u[k] for k in ['id','kind','owner','x','y','hp','maxHp','deck','expiresTick','order'] if k in u} for u in s['units'] if u['owner']=='p1']})
write('original-process-observation-gap.json',{'ordinary0SavedStart':r['startedAtUtc'],'ordinary0SavedEnd':r['endedAtUtc'],'savedPID':r['pid'],'originalExecSession':69595,'originalOuterExitCode':None,'handoffPoll':{'tool':'write_stdin','session':69595,'result':'Unknown process id 69595'},'parentConfirmation':'Parent also did not observe original outer exit code; last prior live observation69600, then savedcompleted80645 report after handoff.','supportedConclusion':'Saved samePID report, native winner p0 endedAtTick80645, complete136frames and postflight exist. Terminal245tick same-source replay closes world/nextId/bothmem/allcommands/allhits.','unsupportedConclusion':'Do not claim observed original process exit0.','diagnosticExits':{'nativeFinal80400':1,'nativeFinalExplanation':'Original comparator incorrectly excluded terminalhit; world/id/allmem/allcommands true; comparison-only corrected hit interval (80400,80645] is fullyequal66hits. Both error and correction retained.','nativeSink25200':0,'nativeSink58200':0,'nativeSink74400':1,'nativeSink73800':0,'nativeColony49200':0,'nativeSink62400WrongCwd':1,'nativeSink62400CorrectCwd':0},'wrongCwdExplanation':'First62400 diagnostic launched in evidence subdirectory; frozenPolicyRoot git archive paths are cwd-relative and failed before native ticks. Corrected launch cwd to exact fixed source root, without code/input changes; both logs retained.'})
write('prior-focused-to-ordinary13200.json',{'classification':'Comparison only; prior12000changed-code focused continuation is not ordinary0.','priorPath':str(original/'native-12000-13200-final.json.gz'),'ordinaryPath':str(original/'ordinary0.frames/13200.json.gz'),'priorSHA256':sha(original/'native-12000-13200-final.json.gz'),'ordinarySHA256':sha(original/'ordinary0.frames/13200.json.gz'),'worldNextIdBothMemEqual':gz(original/'native-12000-13200-final.json.gz')==gz(original/'ordinary0.frames/13200.json.gz')})
patch=subprocess.check_output(['git','-C',str(source),'diff','3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71','37ae01cca84c49709d30b3fba8fbb4e309004d46','--','src/ai'],text=True);(p/'mixed37ae-vs3bdb-ai.patch').write_text(patch)
cap=load(original/'candidate-source.json');changed=[q for q,h in cap['hashes'].items() if hashlib.sha256((source/q).read_bytes()).hexdigest()!=h];status=subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True);assert not changed and not status
write('closure-final-source-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(cap['hashes']),'changes':changed,'head':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'gitStatus':status})
a=p/'original-ordinary0';a.mkdir(exist_ok=True)
for name in ['candidate-source.json','candidate-sources.tar.gz','ordinary0.ts','ordinary0.json','ordinary0-final.json.gz','ordinary0-progress.json','ordinary0.log']:
 shutil.copy2(original/name,a/name)
shutil.copytree(original/'ordinary0.frames',a/'ordinary0.frames',dirs_exist_ok=True)
b=p/'baseline3bdb-selected';b.mkdir(exist_ok=True)
for name in ['README.md','ordinary-opening.json']:
 if (baseline/name).exists():shutil.copy2(baseline/name,b/name)
shutil.copy2(baseline/'ordinary.json.frames/33688.json',b/'final33688.json')
write('baseline3bdb-selected/terminal-row-fullmem.json',base['rows'][-1]);write('baseline3bdb-selected/reference.json',{'source':'3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71','reportOriginalPath':str(baseline/'ordinary.json'),'reportSHA256':sha(baseline/'ordinary.json'),'classification':'Independent prior ordinary0 on same now-developed seed, native winner33688; only selected relevant evidence bundled, full original report external reference.','setup':base['setup'],'finalRowTick':base['rows'][-1]['tick'],'permanentCorpseCount':sum(c['owner']=='p0' and c['kind']!='spirit' for c in bf['snapshot']['corpses']),'temporarySpiritCorpseCount':sum(c['owner']=='p0' and c['kind']=='spirit' for c in bf['snapshot']['corpses'])})
print(json.dumps({'ownPermanent':35,'ownTemporary':36,'enemyPermanent':63,'neutralTemporaryLethal':len(neutralTemp),'neutralPermanentLethal':len(neutralPerma),'firstWave':[{k:v for k,v in d.items() if k not in ['damageByAttacker','lethalHit']} for d in wave],'allSourceUnchanged':not changed},ensure_ascii=False))
