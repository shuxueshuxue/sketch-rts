import pathlib,hashlib,tarfile,json,datetime
p=pathlib.Path(__file__).parent
files=sorted(q for q in p.rglob('*') if q.is_file() and not q.is_symlink() and q.name!='INDEX.sha256')
(p/'INDEX.sha256').write_text(''.join(hashlib.sha256(q.read_bytes()).hexdigest()+'  '+str(q.relative_to(p))+'\n' for q in files))
files.append(p/'INDEX.sha256')
archive=p.parent/'worker-threat-37ae-ordinary0-closure-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for q in files:tf.add(q,arcname=p.name+'/'+str(q.relative_to(p)),recursive=False)
expected={p.name+'/'+str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in files}
with tarfile.open(archive) as tf:
 actual={m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest() for m in tf.getmembers() if m.isfile()}
assert actual==expected
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(files),'allPayloadBytesRechecked':True,'indexSHA256':hashlib.sha256((p/'INDEX.sha256').read_bytes()).hexdigest(),'ordinary0':'exact37ae fixedcode independent standard0 p0 native80645WIN; mixedunmerged source, developedseed; not finalacceptance','remainingLimits':['Original outer process exit code unknown; saved native terminal independently closed.','Native74400snapshot restore changes two carrier sailing derived fields; earlier73800 exact replay closes passenger death.','Native aggregate neutral killer attribution10 differs from11 corpse-linked lethal-hit callbacks.','Original broken container uncommitted modifications remain unavailable.']}
(p.parent/'worker-threat-37ae-ordinary0-closure-archive.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
