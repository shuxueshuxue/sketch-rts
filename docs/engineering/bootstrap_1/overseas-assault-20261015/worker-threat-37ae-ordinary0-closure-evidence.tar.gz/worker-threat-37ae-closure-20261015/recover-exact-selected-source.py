import pathlib,sys,subprocess,json,tarfile,hashlib
p=pathlib.Path(__file__).resolve().parent;dst=pathlib.Path(sys.argv[1]).resolve();assert not dst.exists(),'Destination must not exist'
cap=json.loads((p/'original-ordinary0/candidate-source.json').read_text());dst.mkdir()
def git(*args,input=None):return subprocess.check_output(['git','-C',str(dst),*args],input=input,stderr=subprocess.STDOUT)
git('init','-q');git('index-pack','--stdin',input=(p/'selected-source-objects.pack').read_bytes());git('update-ref','HEAD',cap['head']);git('read-tree','HEAD');paths=git('ls-files','-z');git('update-index','--skip-worktree','-z','--stdin',input=paths)
with tarfile.open(p/'original-ordinary0/candidate-sources.tar.gz') as tf:
 for m in tf.getmembers():
  if m.name.startswith('live/') and m.isfile():
   rel=m.name[5:];assert rel in cap['hashes'];q=dst/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tf.extractfile(m).read());q.chmod(m.mode)
git('update-index','--no-skip-worktree','-z','--stdin',input=b''.join(q.encode()+b'\0' for q in cap['hashes']))
(dst/'.git/info/exclude').write_text('/node_modules/\n')
changes=[q for q,h in cap['hashes'].items() if hashlib.sha256((dst/q).read_bytes()).hexdigest()!=h];status=git('status','--porcelain').decode();assert not changes and not status
# The exact old git archive call required by the unchanged planner must work from source root.
frozen=git('archive',cap['frozenRevision'],'package.json','src/ai','src/sdk','src/shared');print(json.dumps({'destination':str(dst),'head':git('rev-parse','HEAD').decode().strip(),'files':len(cap['hashes']),'changes':changes,'status':status,'frozenArchiveBytes':len(frozen),'note':'Exact existing commit and source bytes. Partial object store: unrelated absent paths remain skip-worktree; no history beyond two commits is promised.'}))
