25cce固定源真实普通0：已开发生成种子，65739原生自然胜

唯一游戏进程从0连续运行未改动scripts/bootstrap_1-inspect.ts，exec16460，不使用resume、人工命令、命令过滤、资源/人口/HP修改或策略mem种子。固定clean sparse source=/tmp/sketch-rts-summoner-25cce-ordinary-control，HEAD25cce06f1567bc68cf08a2b278122f88eebf6b6f，859源(802TS+57数据配置)pre/post0差异，运行期间没有更新源码。main及其它规则3/4/quiet-colony等候选不在本局。

v9_summoner Ember p0物理side1 vs正常冻结v8 Grove p1。factory sapphireArchipelago --unseen实际snapshot.map.id=ladder，是生成图。seed bootstrap_1-unseen-summoner-v8-20261015-01已经用于观察/调试，本局称开发种子，绝不算未见泛化成功。--unseen是生成开关，不能凭flag将已看种子重算未见。双方标准500金、3used、8cap、3worker；nextId1000；出生/地形沿已批准bootstrapGame规则，不挪敌人或削弱其经济。

原生65739 winner=p0、endedAtTick65739，进程自然退出0；敌0单位/0建筑，14建筑全毁(13非基地)。自己82单位/24建筑/4个完整900厅，spent18435。终档nextId27096，world SHAb557b46df167db760b65484e8fb47667d6bf250e278be72d3f1fb0757f606ff2。这里现在确有25cce独立真实普通0完整胜局，不能将旧b0换码续局冒称普通0，也不把本单一已开发种子/v8胜利当三路线/全部单对手六配对/官方地图与未见种子的最终验收。

损失完整保留：最终131条native corpse与全阵营unitsLost131相符；自己91战斗死亡=74临时spirit死亡+17永久(6worker/6ravager/3summoner/1cutter/1bombard)。没有零损失声明。首建工1010仍在37619死亡，永久17的ID/种类/坐标/tick与旧b0相同，说明经济改善未消除中央野岛/危险炮塔等问题。ordinary25-permanent-losses.json保留实际尸体；本局1200采样，旧b060tick计数窗的细分neutral归因仍归旧实验，不伪装成本局独立密采。

初始0.json与-opening.json是预启动deterministic factory独立见证，原inspect在实际进程另建同factory开局；不伪称0 witness是游戏loop hook采集。fresh provider在首次think前没有已初始化owner mem，以null明确记录缺失，不是注入策略。后续55个native loop样本(每1200至64800+自然终局65739)均保存完整world/nextId，并在.json报告同tick rows中保存p0/p1全部policy memory；55配对postflight已核对。恢复时必须按同tick配对，不混用其它策略记忆。

预启动完整live/frozen源-sources.tar.gz SHA3f49787dfc03102327ae013f11815a22ac8bcbe4cdfe0bccaafb091123622679；-runtime-source.json包含源哈希/确切argv/cwd/原0factory比较，source tar有逐文件INDEX。规则2、frozenRevision d1ae110f2edd99f9c7d899ed61557891ab587639；冻结184项逐项核对，manifest SHA0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。保持已验证生产API迁移等价性和旧成绩归属，不引入旧标识兼容层。

与旧原183b同种子0 factory world/nextId/500-3-8完全相同；真实1200..9600共8样本帧字节/nextId/双方mem全等。随后与旧b0换码9600+同源24000实验共同47样本(10800..65739)也帧字节/nextId/双方mem全等，这只是两场独立执行的只读对照，不能拼接或反向重标来源。旧183b原0→144000无winner仍是旧源的horizon反证；旧b0自然胜仍归旧换码实验。新25包含b0 incomingLanding保护及已提交caster/tower局部范围修正/测试/正确provenance，本局结果归25整合源。

原生client图：15600真实新殖民厅及矿工、61200敌岛spirit推进、65739清空敌基地与全图，均用同HEAD native drawWorld从本局真实frame渲染并人工查看。native-client-source-25cce.tar.gz保留client/recorder。新facing tracker不重建历史动画，不凭sprite朝向证明射击；终局敌实体全灭时相机取原厅位置，画的仍是当前65739真实世界。

本局没有等待材料收尾后再启动；helper先准备、实际20:14左右启动的时间与exec记录都在-process-record.json。原故障容器未提交修改恢复缺口仍未恢复，不声称已复制。继续bootstrap其它目标应保持独立源/完整实战与泛化证据，本单局不是任务结束。
