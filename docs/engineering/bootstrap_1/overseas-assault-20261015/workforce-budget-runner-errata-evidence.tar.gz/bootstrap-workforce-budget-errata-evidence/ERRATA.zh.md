# 更正：实际15060补工付款没有绕过400金币预留

原始183b普通对局15060发生的75金币worker训练、155→80付款是事实；那一帧旧`incomingLanding`把远海unload意图当成本土威胁，所以预留为0。不能将这次消费归因为worker脚本绕过了已经存在的400保护。

在不可变b0提交`b0c8bd7e173c9038071d01531b8a752d3e9ebb48`，以**相同15060完整snapshot、nextId2018、规划前双方全部memory**只读执行，`navalBudgetReserve=400`。原纯`planMiningWorkforce`和直接`miningWorkforce.run(actualSnapshot)`看到155金币时确实返回train，但它们不是实际整栈调用边界。

既有`script-runner.ts`在运行economy脚本前调用`navalBudgetReserve`；对`miningWorkforce`传入`budgetAfter(navalReserve + shopReserve)`。该帧真正传入的预算视图gold为-245，units/buildings仍是同一真实世界数组，worker脚本返回空。完整`planAiOwnerCommandEntries`只有naval和v6Backline两条移动令，没有worker训练。观测wrapper的完整scriptId+command流、全部结果memory与未观测完整planner一致；owner planner多出的playerId包装字段单独说明，没有误当命令差异。

再从该15060完整档分别恢复后，只公开应用两组命令、不推进新比赛：直接raw脚本命令这个**人工反事实诊断**即时支付75，产生paidGold75/remaining140训练队列；真实完整runner计划即时花费0、gold仍155、队列空。两组完整付款后世界和nextId都在runner-review.json，原来的183b历史付款与这个人工raw诊断严格区分。没有改变敌方、资源、人口、规则或当前正在进行的b0比赛。

因此没有第二个生产预算修复候选，也没有新整局。再在bootstrap worker wrapper里扣一次400会重复预留，反而可能阻止余额之上的合法补工。原纯函数保持调用者提供预算的语义，既有runner已提供这个预算视图。b0最终殖民、资金恢复、防守和完整比赛效果仍须由实际双方AI continuation判断；此只读反证不能称为b0已完成目标。

## 冻结中的错误注释/provenance

为了维持正在进行的b0源码858项全程定源，这些字节**没有改动**：

- `src/ai/bootstrap_1/incoming-landing-capital.test.ts`顶部“Actual15060 ... outside this reserve”和“second production path”是先前未经完整runner核实的错误推断。
- `src/ai/bootstrap_1/fixtures/summoner-unseen-colony-capital-14400.json.gz`的provenance.knownScopeLimit里“can bypass naval reserve”也是同一错误推断。

这些注释不影响测试执行/原生世界，但必须附带本更正阅读。若未来将候选合入root，应改成“原183实际15060在reserve0时付75；b0由既有runner使用预算视图保护400；完整比赛效果另验”。只修注释和provenance元数据，snapshot、nextId、双方memory必须逐项/逐字节保持相同；保留此冻结b0原稿及SHA，不能改写成原先已知正确。

## 证据

`actual183-transition-15060.json.gz`保留原始before/after策略记忆及真实183命令；输入SHA256 `37a2aa310837c8c9fd16ff67149edcff627cd800b93b5163bdb24bd46cbf2cf5`。`runner-review.json`包含完整planner/观测wrapper结果、实际传入预算、纯函数原行为、两组原生公开付款后的完整世界与nextId。六个相关b0源码/fixture哈希前后一致，control git status干净。`source-b0`是这些精确文件的只读副本，不冒充整个858项运行源包。

不修改root，不修改b0 control的任何src/fixture，不修改规则2与冻结对手。原故障容器未提交修改恢复缺口仍然存在。
