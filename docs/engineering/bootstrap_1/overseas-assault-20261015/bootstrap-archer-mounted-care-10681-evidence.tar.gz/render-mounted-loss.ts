import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createCanvas } from '@napi-rs/canvas';
const source='/tmp/sketch-rts-mercenary-courier-safe-stop-control',dir='/tmp/bootstrap-archer-double-v8-courier-v2-20261015';
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const view={x:1700,y:2300,width:1100,height:1000,zoom:1},outputs=[];
for(const path of ['mounted-loss-fine-10200-10800.frames/10665.json','mounted-loss-fine-10200-10800.frames/after-death-unit-p0-horseArcher-2503-10681.json']){
 const bytes=readFileSync(dir+'/'+path),{snapshot}=JSON.parse(bytes.toString()),tick=snapshot.tick;
 const canvas=createCanvas(view.width,view.height);
 drawWorld({ctx:canvas.getContext('2d') as any,snapshot,view,now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
 const output=dir+'/mounted-loss-native-'+tick+'.png';writeFileSync(output,canvas.toBuffer('image/png'));
 outputs.push({tick,input:path,inputSHA256:createHash('sha256').update(bytes).digest('hex'),output,view});
}
writeFileSync(dir+'/mounted-loss-native-visual.json',JSON.stringify({classification:'Native drawWorld actual saved full snapshots. New facing tracker does not reconstruct historic animations;10681 chainLightning/hit effects are real state, not added illustration.',source,outputs},null,2)+'\n');
console.log(JSON.stringify(outputs));
