import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const source='/tmp/sketch-rts-mercenary-courier-safe-stop-control';
const prefix='/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary';
const start=Number(process.argv[2]),end=Number(process.argv[3]);
const out=`/tmp/bootstrap-archer-double-v8-courier-v2-20261015/mounted-loss-${start}-${end}`;
const report=JSON.parse(readFileSync(prefix+'.json','utf8'));
const input=JSON.parse(readFileSync(`${prefix}.json.frames/${start}.json`,'utf8'));
const row=report.rows.find((r:any)=>r.tick===start);
if(!row||!Number.isFinite(end))throw new Error('Missing real checkpoint');
const {bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const {runAiGameLoop}=await import(pathToFileURL(source+'/src/ai/game-runner.ts').href);
const {createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const {createBootstrapCommandPlanner}=await import(pathToFileURL(source+'/scripts/bootstrap_1-planner.ts').href);
const {restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const selection=report.setup;
const match=bootstrapMatches(selection.seed,[selection.map],end,selection.unseen).find((m:any)=>m.subject===report.subject&&m.side===selection.side&&m.agents.p0.race===selection.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')===Object.values(selection.agents).slice(1).map((a:any)=>a.version).join('+'));
const game=bootstrapGame(match),memories=createAiMemoryProvider();
restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
for(const [owner,player]of Object.entries(row.players) as any[])memories.set(owner,structuredClone(player.policy));
const planner=await createBootstrapCommandPlanner(memories),owners=Object.keys(match.agents);
const frame=()=>JSON.parse(JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,memories.get(owner)]))}));
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const restored=frame(),expectedMem=Object.fromEntries(owners.map(owner=>[owner,row.players[owner].policy]));
if(!same(restored.snapshot,input.snapshot)||restored.nextId!==input.nextId||!same(restored.memories,expectedMem))throw new Error('Full JSON restore mismatch');
mkdirSync(out+'.frames',{recursive:true});
const save=(label:string,f:any)=>writeFileSync(out+'.frames/'+label+'.json',JSON.stringify(f)+'\n');
save(String(start),restored);
let previous=restored;
const commands:any[]=[],changes:any[]=[],deaths:any[]=[];
runAiGameLoop({...match,game,commandPlanner:(context:any)=>{
 const entries=planner(context);
 commands.push({tick:context.snapshot.tick,owner:context.owner,entries:structuredClone(entries)});
 return entries;
}},{onStep:()=>{
 const current=frame(),old=new Map(previous.snapshot.units.map((u:any)=>[u.id,u]));
 const now=new Map(current.snapshot.units.map((u:any)=>[u.id,u]));
 for(const [id,unit]of old as any){
  if(unit.owner!=='p0')continue;
  const next:any=now.get(id);
  if(!next){deaths.push({tick:game.tick,before:unit,newEffects:current.snapshot.effects.filter((e:any)=>!previous.snapshot.effects.some((p:any)=>p.id===e.id)),stats:current.snapshot.match.stats});save('before-death-'+id+'-'+previous.snapshot.tick,previous);save('after-death-'+id+'-'+game.tick,current);}
  else if(next.hp!==unit.hp||!same(next.order,unit.order))changes.push({tick:game.tick,id,kind:unit.kind,hpBefore:unit.hp,hpAfter:next.hp,position:{x:next.x,y:next.y},orderBefore:unit.order,orderAfter:next.order,newEffects:current.snapshot.effects.filter((e:any)=>!previous.snapshot.effects.some((p:any)=>p.id===e.id))});
 }
 if(game.tick%60===0||game.tick===end||game.match.winner)save(String(game.tick),current);
 previous=current;
}});
const expected=JSON.parse(readFileSync(`${prefix}.json.frames/${end}.json`,'utf8'));
const endRow=report.rows.find((r:any)=>r.tick===end),actual=frame();
const verification={worldEqual:same(actual.snapshot,expected.snapshot),nextIdEqual:actual.nextId===expected.nextId,allMemoriesEqual:Object.fromEntries(owners.map(owner=>[owner,same(actual.memories[owner],endRow.players[owner].policy)]))};
const output={classification:'Same-source full all-policy native continuation from actual ordinary checkpoint; no manual gameplay commands or modified world',source,start,endTick:game.tick,verification,commands,changes,deaths};
writeFileSync(out+'.json',JSON.stringify(output)+'\n');
console.log(JSON.stringify({out:out+'.json',verification,deaths:deaths.map(({tick,before}:any)=>({tick,id:before.id,kind:before.kind,hp:before.hp,order:before.order}))}));
