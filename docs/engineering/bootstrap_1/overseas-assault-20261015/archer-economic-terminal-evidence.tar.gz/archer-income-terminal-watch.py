from pathlib import Path
import datetime,hashlib,json,subprocess,time
b=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015')
jobs=[{'stem':'archer-mine-prospect-income-144000','observe':'archer-mine-prospect-observe.py','source':'archer-mine-prospect-runtime-source.json','horizon':144000},{'stem':'archer-economic-lift-income','observe':'archer-economic-lift-observe.py','source':'archer-economic-lift-runtime-source.json','horizon':96000}]
last={}; done=set()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
while len(done)<len(jobs):
 for j in jobs:
  if j['stem'] in done:continue
  rp=b/(j['stem']+'.json')
  try:r=json.loads(rp.read_text());tick=r['rows'][-1]['tick']
  except (FileNotFoundError,json.JSONDecodeError,IndexError):continue
  if last.get(j['stem'])!=tick or r['result'].get('completed'):
   check=subprocess.run(['python',str(b/j['observe']),str(rp)],capture_output=True,text=True)
   if check.returncode:print(json.dumps({'job':j['stem'],'observerError':check.stderr}),flush=True);continue
   observation=json.loads((b/(j['stem']+'-observation.json')).read_text());row=observation['rows'][-1]
   brief={k:row[k]for k in ['tick','gold','gainPerMinute','halls','activeMineGold','mineWorkers','idleWorkers','losses','enemyUnits','enemyBuildings','enemyHallHp']};print(json.dumps({'job':j['stem'],'result':r['result'],'last':brief}),flush=True);last[j['stem']]=tick
  if r['result'].get('completed'):
   source=json.loads((b/j['source']).read_text());wd=Path(source['worktree']);mismatch=[]
   for name,want in source['files'].items():
    p=wd/name
    if not p.exists()or sha(p)!=want:mismatch.append(name)
   terminal={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':observation.get('classification'),'source':j['source'],'sourceFilesUnchanged':not mismatch,'sourceHashMismatches':mismatch,'sourceFileCount':len(source['files']),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wd,text=True).strip(),'sourceStatus':subprocess.check_output(['git','status','--porcelain'],cwd=wd,text=True),'rulesVersion':source['rulesVersion'],'frozenRevision':source['frozenRevision'],'frozenVerifiedAtRuntimeCapture':source['frozenFilesVerified'],'requestedHorizon':j['horizon'],'actualResult':r['result'],'winnerConfirmed':r['result'].get('winner') is not None,'report':rp.name,'reportSha256':sha(rp),'lastFrame':f'{rp.name}.frames/{tick}.json','lastFrameSha256':sha(Path(str(rp)+f'.frames/{tick}.json')),'observation':j['stem']+'-observation.json','terminalMetrics':brief,'originalContainerUncommittedGap':'Not recovered; not included in this runtime.'}
   dest=b/(j['stem']+'-terminal-provenance.json');dest.write_text(json.dumps(terminal,indent=2)+'\n');done.add(j['stem']);print(json.dumps({'terminalSaved':dest.name,'winner':r['result'].get('winner'),'sourceFilesUnchanged':not mismatch}),flush=True)
 if len(done)<len(jobs):time.sleep(30)
