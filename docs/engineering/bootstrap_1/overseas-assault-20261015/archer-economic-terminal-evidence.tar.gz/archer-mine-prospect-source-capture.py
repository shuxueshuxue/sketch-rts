from pathlib import Path
import argparse,subprocess,json,hashlib,tarfile,io,re,datetime
p=argparse.ArgumentParser();p.add_argument('--worktree',required=True);p.add_argument('--expected-commit',required=True);p.add_argument('--out',required=True);a=p.parse_args();wd=Path(a.worktree).resolve();out=Path(a.out).resolve()
def git(*args):return subprocess.check_output(['git','-C',str(wd),*args])
head=git('rev-parse','HEAD').decode().strip();assert head==a.expected_commit,(head,a.expected_commit)
tracked=git('status','--porcelain','--untracked-files=no').decode();assert not tracked,tracked
manifest=json.loads((wd/'docs/engineering/bootstrap_1/frozen-policy.json').read_text());rules=(wd/'src/shared/rules-version.ts').read_text();version=int(re.search(r'RULES_VERSION\s*=\s*(\d+)',rules).group(1));assert version==manifest['rulesVersion']==2
paths=['src/ai','src/shared','src/sdk','scripts/bootstrap_1-inspect.ts','scripts/bootstrap_1-planner.ts','package.json','package-lock.json','tsconfig.json','docs/engineering/bootstrap_1/frozen-policy.json']; files=git('ls-files','-z','--',*paths).decode().split('\0');files=[f for f in files if f]
frozen={};archive=git('archive',manifest['revision'],*manifest['files'])
with tarfile.open(fileobj=io.BytesIO(archive))as t:
 for name,expected in manifest['files'].items():
  actual=hashlib.sha256(t.extractfile(name).read()).hexdigest();assert actual==expected,(name,expected,actual);frozen[name]=actual
source_archive=out.with_suffix('.tar.gz'); subprocess.run(['git','-C',str(wd),'archive','--format=tar.gz','--output='+str(source_archive),head,*paths],check=True)
result={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(wd),'commit':head,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'trackedClean':True,'rulesVersion':version,'frozenRevision':manifest['revision'],'frozenFileCount':len(frozen),'frozenFilesVerified':True,'manifestSha256':hashlib.sha256((wd/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes()).hexdigest(),'sourceArchive':str(source_archive),'sourceArchiveSha256':hashlib.sha256(source_archive.read_bytes()).hexdigest(),'files':{name:hashlib.sha256((wd/name).read_bytes()).hexdigest()for name in files}}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['worktree','commit','trackedClean','rulesVersion','frozenFileCount','sourceArchiveSha256']}))
