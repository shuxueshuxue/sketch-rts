这些是 bootstrap_1 陆战的已完成对照与反证。所有候选均未合入承接分支；规则仍为 2，冻结对手仍使用 d1ae110f2edd99f9c7d899ed61557891ab587639，manifest SHA-256 为 0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。对手没有减资源、人口或放宽地形。原故障容器未提交修改仍未恢复，此归档没有填补或伪称复制该缺口。

| 完整普通开局 | 固定源 | 自然结果 | 能说明什么 |
|---|---|---|---|
| knight 已知桥口开发种子，对正常 v8+v8 | 183b84879b97902fcb57e9acadbce62b0fcfb872 | 25657，p1 获胜 | 当前稳定源的真实败局；不是旧 f267 的 10081，也不是旧护理源的 26477 |
| 同局 knight，复杂护理/返程 | ad791181aae6a687ebc35fdd4354dc5a3df0fd73 | 25957，p1 获胜 | 只多活 300 tick、损失 63 对 58，双方均未拆敌建筑；没有整局收益证明 |
| 同局 knight，全 hold/guard 远兵转 move | c18aaf7cd36891d78bd3c4b7f8c1fae7a60846ad | 25657，p1 获胜 | 43 个采样完整世界+nextId、所有三方 policy、购买与终局均与 183 完全相等；该路线原已走 V9 归队语义。只是完整比赛不回归，不是胜利 |
| 同桥口种子，v9_summoner 对正常 v8+v8 | 183b8487 | 30151，p1 获胜 | 真正受影响家族的基线 |
| 同局 summoner，全 hold/guard 远兵转 move | c18aaf7c | 17919，p1 获胜 | 明显更早败北，不建议合入。不得用局部救人替代整局结果 |

上述 map 工厂都是 greystonePass，--unseen 实际生成 map.id=ladder；seed=resume-20261015-knight-expansion-b 已反复观察，是开发种子，不算新泛化证据。所有普通局均从标准 0 tick、三方各 500 金/3 已用/8 上限起步；独立 prepare 工具在开局前保存 factory witness、所有 live AI/shared/SDK 数据源码、冻结完整源码及 184 个 manifest 文件校验。报告每一行有三方完整策略记忆，配套 .json.frames/TICK.json 有完整世界和 nextId；两部分应一起读。*-postflight.json 逐一检查源、manifest、终局与采样对齐。856/859/865 是各局实际封存的源码与数据计数，不冒充整个仓库或不同实验的同一计数。

c18 最初从局部真实 native 对照看似有效：旧手工准备/策略家族实验轨迹的 10500 完整档中，183 的 ravager1079 在 10713 被三塔打死；c18 在 13200 仍满 118，并在 11692、11932 得到实际 native55 治疗。双方都从同一个完整世界、nextId、三方记忆起步，10515 JSON checkpoint 重放到13200，所有世界值/nextId/三方记忆全等；原代码和原生伤害记录俱在。它不是一个普通0召唤局；原输入来自先前 knight 世界上的显式 summoner 家族实验，历史准备不能省略。

只挡 towerBreaker 的 post-only v2 也失败：同10500档，10738仍死。真实轨迹显示10515还向本方 post 行进；随后队友挨塔箭，规则2 triggerPlayerAggro/takeUpAttacker 在 HELP_CALL_RANGE=300 内把其 attackMove 自动填成塔1760目标。10530起掉头追塔，10605 focusFire追 raider，10620 general又attackMove，随后再次被队友求援拖回塔。不能把“少一次 towerBreaker 覆盖”当成已解决撤退。v2 的完整3方AI和10515→13200 JSON闭合仍全真，1392个被审计源码/配置字节全程无变化。它有公开队列/船角色/main-army/care/幂等边界绿测，但没有生存或整局收益，未合入。

c18 普通召唤局的首个命令分叉已用原普通1200完整世界+三方记忆精准重演到1800，分别与两边原1800世界/nextId/全部记忆全等。1260首次创建 general.hold，目标(3425.79,3428.81)在主厅(3696,3696)前面；首个满血新兵1069刚出厂，之前没有 general 或撤退任务。原命令是向前集结 attackMove，c18因距离新post稍超过原450而改move；1275又变回attackMove，多发一次命令/effect，后续nextId与生成单位ID开始偏移。因此 hold/guard+距离大不能证明正在撤离。1261最初只变 order/effect，位置/HP/nextId尚同，不把这个时刻直接冒称伤亡因果，也不拿不同ID的交集假称此后单位轨迹全同。c18公开队列反例也保留：旧空 commands 的 fallback 新增move会清合法queued follow；旧 returning 扫描还会误纳海军。源未被回改来伪造清白。

旧 f267 系列保存在 legacy 归档：v4-joint 普通0在13870自然败北，旧50160→96000同源续局仍无赢家。9600完整档消融中，joint去regroup仍13870败北，new objective+old care在22638败北；care-noobjective到24000尚存活，但用原不变源码续到25957自然败北。该续段1342个src/scripts/配置文件前后0变化；9600→24000旧段只有其旧metadata列出的14文件胶囊检查，不倒称已有全仓预启动审计。旧三路线局部护理（10335→11160）含真实55治疗、1079生存/JSON闭合；但是套回当前183后，原稳定general自然清掉实验targetBuildingId，knight本来就能活到11160且72HP，复杂护理只到76HP、首疗只早2tick，不能把旧joint的死→103HP归给当前基线。老源oldcare普通26477、joint13870和新ad791普通25957必须分别列账。

验证器勘误：最初以 isDeepStrictEqual 将原生 snapshot 对象直接比磁盘JSON，11400→12000被错误报漂移。restore 的可选 undefined 键（如 variant/abilityCooldowns/autocast/stance/pushX）在真实JSON协议中被正常省略；保留所有实际JSON字段后，原无额外rank查询重演到12000的完整世界/nextId/三方记忆与原普通局全等。补一次初始rank查询的独立观察也全等，无任何rank查询副作用证据。原错误断言、失败日志、完整勘误1262个缺省键记录、修正后的实际11970撤退前档与12000闭合都保留；没有忽略任何有意义字段，也没有改导航或规则来让检查通过。原无query失败初版在抛断言前未写12000终档，因此修正后仅为补准确全档重演一次600tick。

当前下一候选（真实 attack→hold/guard 且 retreatedAt 当前帧、仅原攻击group的明确 ordinary move avoidCombat 任务）仍在独立 v3 control 验证。本次“已完成反证”归档不包含其进行中源码/成绩，不推荐以此归档宣称 bootstrap 达标。三家族对所有冻结单对手/六种配对、官方地图与未见生成种子的完整胜局和泛化尚未完成。
