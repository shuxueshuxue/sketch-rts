import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, issuePlayerCommand, restoreSnapshotIntoGame, snapshotGame, stepGame } from '../../shared/sim';
import { bootstrapPolicyContext } from './policy';
import { mobileCare } from './mobile-care';
import { recoveryHealingWindow, recoveryIncomingDamage } from './recovery-threat';
import { careRendezvousHealers, rememberCareRendezvous } from './care-rendezvous';
import { createAiPolicyMemory } from '../memory';
import { groundRangeArrival } from '../policy/ground-arrival';
import { routeTravelTicks } from '../../shared/route-selection';
import { sketchScene } from '../../sdk/scene';
import { ABILITY_DEFS } from '../../shared/catalog';
import { setBuildingBodies } from '../../shared/terrain';
import { bootstrapGame, bootstrapMatches } from './benchmark';
import { createAiMemoryProvider } from '../planner-context';
import { createBootstrapCommandPlanner } from '../../../scripts/bootstrap_1-planner';
import { runAiGameLoop } from '../game-runner';

function field() {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/knight-tower-care-before-10335.json.gz', import.meta.url))).toString());
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  return { saved, game };
}

it('actually heals the recorded care-road patient before releasing it back to the army', async () => {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/knight-care-rendezvous-before-10440.json.gz', import.meta.url))).toString());
  const match = bootstrapMatches(saved.setup.seed, ['greystonePass'], 10500, true).find(match => match.subject === 'v9_knight'
    && match.side === 1 && match.agents.p0!.race === 'ember'
    && Object.values(match.agents).slice(1).map(agent => agent.version).join('+') === 'v8+v8')!;
  const game = bootstrapGame(match); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const memory = createAiMemoryProvider(structuredClone(saved.memories)), planner = await createBootstrapCommandPlanner(memory);
  const original = game.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  expect(original.hp).toBe(96);
  let previousHp = original.hp, healed = false;
  runAiGameLoop({ ...match, game, commandPlanner: planner }, { onStep: () => {
    const patient = game.units.find(unit => unit.id === original.id);
    if (!patient) return;
    if (patient.hp - previousHp === Math.min(ABILITY_DEFS.heal.healAmount, patient.maxHp - previousHp)
      && patient.hp > previousHp && game.units.some(unit => unit.owner === 'p0' && unit.kind === 'priest'
        && unit.abilityCooldowns?.heal === ABILITY_DEFS.heal.cooldown
        && Math.hypot(unit.x - patient.x, unit.y - patient.y) <= ABILITY_DEFS.heal.range)) healed = true;
    previousHp = patient.hp;
  } });
  const snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === original.id)!;
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory: memory.get('p0')!, teams: game.teams });
  expect(healed).toBe(true); expect(patient.hp).toBe(patient.maxHp);
  expect(mobileCare.claimsUnits!(snapshot, 'p0', options).has(patient.id)).toBe(false);
}, 60000);

it('binds only a care-issued native order, survives passive regeneration, and releases on external control or actual arrival', () => {
  const game = sketchScene('care-order-lifecycle').map('openClaims').replaceDefaults()
    .player('us', { race: 'ember', team: 'a' }).player('foe', { race: 'grove', team: 'b' })
    .townHall('us', 300, 3500).townHall('foe', 3700, 3500)
    .unit('us', 'cinderRevenant', 500, 400, { id: 'patient', hp: 20 })
    .unit('us', 'priest', 1000, 400, { id: 'healer' }).build().createGame();
  const options = { memory: createAiPolicyMemory(), teams: game.teams };
  const patient = game.units.find(unit => unit.id === 'patient')!, healer = game.units.find(unit => unit.id === 'healer')!;
  const command = { type: 'move' as const, unitIds: [patient.id], x: 650, y: 400, avoidCombat: true };
  issuePlayerCommand(game, 'us', command);
  expect(careRendezvousHealers(snapshotGame(game), 'us', options).size).toBe(0);
  rememberCareRendezvous(snapshotGame(game), options, patient, healer, command);
  stepGame(game);
  expect(patient.hp).toBeGreaterThan(20);
  expect(careRendezvousHealers(snapshotGame(game), 'us', options).has(patient.id)).toBe(true);
  issuePlayerCommand(game, 'us', { type: 'attackMove', unitIds: [patient.id], x: 2000, y: 400 });
  expect(careRendezvousHealers(snapshotGame(game), 'us', options).size).toBe(0);
  expect(options.memory.careRendezvous).toBeUndefined();
  const meeting = { ...command, x: healer.x, y: healer.y };
  issuePlayerCommand(game, 'us', meeting); rememberCareRendezvous(snapshotGame(game), options, patient, healer, meeting);
  for (let elapsed = 0; elapsed < 200 && Math.hypot(patient.x - healer.x, patient.y - healer.y) > ABILITY_DEFS.heal.range; elapsed++) stepGame(game);
  expect(Math.hypot(patient.x - healer.x, patient.y - healer.y)).toBeLessThanOrEqual(ABILITY_DEFS.heal.range);
  expect(careRendezvousHealers(snapshotGame(game), 'us', options).size).toBe(0);
  expect(options.memory.careRendezvous).toBeUndefined();
});

it.each(['v9_archer', 'v9_summoner', 'v9_knight'] as const)('%s reserves the real three-tower patient before committed arrows outrun healing', version => {
  const { saved, game } = field(), snapshot = snapshotGame(game);
  const patient = snapshot.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  expect(patient.hp).toBe(80); expect(patient.hp).toBeGreaterThan(patient.maxHp * .35);
  const options = bootstrapPolicyContext(snapshot, 'p0', version, { memory: saved.memories.p0, teams: game.teams });
  expect(mobileCare.claimsUnits!(snapshot, 'p0', options).has(patient.id)).toBe(true);
});

it('counts the real released arrow exactly when it arrives, without needing a live shooter assignment', () => {
  const { game } = field(), snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  expect(recoveryIncomingDamage(snapshot, patient, [], 17, { teams: snapshot.teams! })).toBe(0);
  expect(recoveryIncomingDamage(snapshot, patient, [], 18, { teams: snapshot.teams! })).toBe(16);
  const before = patient.hp;
  for (let tick = 0; tick < 18; tick++) stepGame(game);
  expect(before - game.units.find(unit => unit.id === patient.id)!.hp).toBe(16);
});

it('keeps released arrows separate from the tower cooldown and rejects out-of-range future fire', () => {
  const { game } = field(), snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  const tower = snapshot.buildings.find(building => building.id === 'building-p2-defenseTower-1760')!;
  expect(tower.cooldown).toBe(27);
  expect(recoveryIncomingDamage(snapshot, patient, [tower], 26, { teams: snapshot.teams! })).toBe(16);
  // At27 the second recorded arrow arrives and the first tower can release one new shot.
  expect(recoveryIncomingDamage(snapshot, patient, [], 27, { teams: snapshot.teams! })).toBe(32);
  expect(recoveryIncomingDamage(snapshot, patient, [tower], 27, { teams: snapshot.teams! })).toBe(48);
  const outside = { ...patient, x: 3000, y: 3500 };
  expect(recoveryIncomingDamage(snapshot, outside, [tower], 27, { teams: snapshot.teams! })).toBe(32);
  expect(recoveryIncomingDamage(snapshot, patient, [{ ...tower, complete: false }], 27, { teams: snapshot.teams! })).toBe(32);
});

it.each([false, true])('matches native heavy armor and veteran protection on a released arrow (armorAlreadyApplied=%s)', armorAlreadyApplied => {
  const { saved } = field();
  // Explicit one-unit armor laboratory control in the otherwise complete world.
  // This is not a match score or a change to the recorded patient fixture.
  const patient = saved.snapshot.units.find((unit: any) => unit.id === 'unit-p0-emberRavager-1079');
  patient.kind = 'knight'; patient.veteranSkill = 'veteranResilience';
  for (const projectile of saved.snapshot.projectiles) if (projectile.targetId === patient.id) projectile.armorAlreadyApplied = armorAlreadyApplied;
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), live = snapshot.units.find(unit => unit.id === patient.id)!;
  const forecast = recoveryIncomingDamage(snapshot, live, [], 18, { teams: snapshot.teams! });
  let actual: number | undefined;
  game.observer = { hit(_source, target, amount) { if (target.id === patient.id && actual === undefined) actual = amount; } };
  for (let tick = 0; tick < 18; tick++) stepGame(game);
  expect(forecast).toBeGreaterThan(0); expect(actual).toBeCloseTo(forecast, 10);
  expect(forecast).toBeLessThan(16);
});

it('does not treat a native allied arrow as incoming patient damage, including an explicit policy team map', () => {
  const { saved } = field();
  // Explicit alliance laboratory control of an already released arrow. It is
  // never substituted into the normal frozen-opponent match evidence.
  saved.snapshot.teams.p2 = saved.snapshot.teams.p0;
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  expect(recoveryIncomingDamage(snapshot, patient, [], 27, { teams: snapshot.teams! })).toBe(0);
  expect(recoveryIncomingDamage({ ...snapshot, teams: { p2: 'different' } }, patient, [], 27, { teams: game.teams })).toBe(0);
  let hits = 0;
  game.observer = { hit(_source, target) { if (target.id === patient.id) hits++; } };
  for (let tick = 0; tick < 27; tick++) stepGame(game);
  expect(hits).toBe(0);
});

it('uses the actual heal-range road rather than the healer center, and keeps cooldown plus think uncertainty', () => {
  const { game } = field(), snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  const healer = snapshot.units.find(unit => unit.id === 'unit-p0-priest-2777')!;
  const window = recoveryHealingWindow(snapshot, patient, healer)!;
  expect(window).toBeLessThan(routeTravelTicks(snapshot.map, patient, healer, 'land', patient.speed)!);
  expect(recoveryHealingWindow(snapshot, { ...patient, x: healer.x, y: healer.y }, healer)).toBe(15);
  expect(recoveryHealingWindow(snapshot, { ...patient, x: healer.x, y: healer.y },
    { ...healer, abilityCooldowns: { heal: 41 } })).toBe(41);
});

it('reaches the first legal native healing position around a real terrain barrier', () => {
  const game = sketchScene('heal-road-first-range').map('openClaims').replaceDefaults()
    .player('us', { race: 'grove', team: 'a' }).player('foe', { race: 'grove', team: 'b' })
    .townHall('us', 300, 3500).townHall('foe', 3700, 3500)
    .unit('us', 'footman', 400, 400, { id: 'patient', hp: 20 })
    .unit('us', 'priest', 1000, 400, { id: 'healer' }).build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128,
    cells: Array.from({ length: 128 * 128 }, (_, index) => index % 128 === 18 && Math.floor(index / 128) < 40 ? 'T' : '.').join('') };
  setBuildingBodies(game.map, game.buildings);
  const snapshot = snapshotGame(game), patient = snapshot.units.find(unit => unit.id === 'patient')!, healer = snapshot.units.find(unit => unit.id === 'healer')!;
  const forecast = groundRangeArrival(snapshot, patient, healer, ABILITY_DEFS.heal.range)!;
  const straight = (Math.hypot(patient.x - healer.x, patient.y - healer.y) - ABILITY_DEFS.heal.range) / patient.speed * 20;
  expect(forecast.ticks).toBeGreaterThan(straight + 200);
  issuePlayerCommand(game, 'us', { type: 'setAutocast', unitIds: [healer.id], ability: 'heal', enabled: false });
  issuePlayerCommand(game, 'us', { type: 'holdPosition', unitIds: [healer.id] });
  issuePlayerCommand(game, 'us', { type: 'move', unitIds: [patient.id], x: healer.x, y: healer.y });
  let contact: number | undefined;
  for (let elapsed = 1; elapsed < 1800; elapsed++) {
    stepGame(game);
    const live = game.units.find(unit => unit.id === patient.id)!;
    if (Math.hypot(live.x - healer.x, live.y - healer.y) <= ABILITY_DEFS.heal.range) { contact = elapsed; break; }
  }
  expect(contact).toBeDefined(); expect(contact!).toBeGreaterThan(straight + 200);
  expect(Math.abs(contact! - forecast.ticks)).toBeLessThan(60);
  issuePlayerCommand(game, 'us', { type: 'cast', unitId: healer.id, ability: 'heal', targetId: patient.id });
  stepGame(game);
  expect(game.units.find(unit => unit.id === patient.id)!.hp).toBeGreaterThan(patient.hp);
});

it.each(['v9_archer', 'v9_summoner', 'v9_knight'] as const)('%s actually rescues the recorded patient under both normal frozen opponents and restores every saved value', async version => {
  const { saved } = field();
  const match = bootstrapMatches(saved.setup.seed, ['greystonePass'], 11160, true).find(match => match.subject === 'v9_knight'
    && match.side === 1 && match.agents.p0!.race === 'ember'
    && Object.values(match.agents).slice(1).map(agent => agent.version).join('+') === 'v8+v8')!;
  // Controlled policy-family replay of one actual world, not three ordinary openings.
  match.agents.p0!.version = version;
  const game = bootstrapGame(match); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const memory = createAiMemoryProvider(structuredClone(saved.memories)), planner = await createBootstrapCommandPlanner(memory);
  let previousHp = game.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!.hp, healed = false;
  const observeHealing = () => {
    const patient = game.units.find(unit => unit.id === 'unit-p0-emberRavager-1079');
    if (!patient) return;
    if (ABILITY_DEFS.heal.behavior === 'heal' && patient.hp > previousHp && patient.hp - previousHp === Math.min(ABILITY_DEFS.heal.healAmount, patient.maxHp - previousHp) && game.units.some(unit => unit.owner === 'p0'
      && unit.kind === 'priest' && unit.abilityCooldowns?.heal === ABILITY_DEFS.heal.cooldown
      && Math.hypot(unit.x - patient.x, unit.y - patient.y) <= ABILITY_DEFS.heal.range)) healed = true;
    previousHp = patient.hp;
  };
  runAiGameLoop({ ...match, game, commandPlanner: planner, maxTicks: 10350 }, { onStep: observeHealing });
  expect(memory.get('p0')!.careRendezvous?.['unit-p0-emberRavager-1079']).toBeDefined();
  const checkpoint = JSON.parse(JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId,
    memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memory.get(owner)])) }));
  const restored = bootstrapGame(match); restoreSnapshotIntoGame(restored, checkpoint.snapshot, checkpoint.nextId);
  const restoredMemory = createAiMemoryProvider(checkpoint.memories), restoredPlanner = await createBootstrapCommandPlanner(restoredMemory);
  runAiGameLoop({ ...match, game, commandPlanner: planner }, { onStep: observeHealing });
  runAiGameLoop({ ...match, game: restored, commandPlanner: restoredPlanner });
  expect(snapshotGame(restored)).toEqual(snapshotGame(game)); expect(restored.nextId).toBe(game.nextId);
  for (const owner of Object.keys(match.agents)) expect(restoredMemory.get(owner)).toEqual(memory.get(owner));
  expect(healed).toBe(true);
  const survivor = game.units.find(unit => unit.id === 'unit-p0-emberRavager-1079')!;
  // This continuation preserves the stable root's original main objectives.
  // Further combat after a real heal does not have the joint objective prototype's final HP.
  expect(survivor).toBeDefined(); expect(survivor.hp).toBeGreaterThan(0);
  expect(Math.hypot(survivor.x - 1056, survivor.y - 2784)).toBeGreaterThan(480);
  expect(game.match.winner).toBeNull();
}, 60000);
