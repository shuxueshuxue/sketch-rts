import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
const source='/tmp/sketch-rts-mercenary-courier-safe-stop-control',dir='/tmp/bootstrap-land-army-evidence-20261015';
const load=(f:string)=>import(pathToFileURL(source+'/'+f).href),copy=(x:any)=>JSON.parse(JSON.stringify(x));
const {bootstrapMatches,bootstrapGame}=await load('src/ai/bootstrap_1/benchmark.ts');
const {restoreSnapshotIntoGame,snapshotGame}=await load('src/shared/sim.ts');
const {bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts');
const {mountedTasks}=await load('src/ai/bootstrap_1/mounted-tasks.ts');
const {mineGuardUnitIds}=await load('src/ai/bootstrap_1/mine-defense.ts');
const {mobileCare}=await load('src/ai/bootstrap_1/mobile-care.ts');
const {groundSteeringRoute,routePrefix}=await load('src/shared/route-selection.ts');
const {itemsFor}=await load('src/shared/equipment.ts');
const {mountedThreatReach}=await load('src/ai/bootstrap_1/mounted-micro.ts');
const setup=JSON.parse(readFileSync(dir+'/archer-base5f-full9600.json','utf8')).setup;
const results:any[]=[];
for(const [label,input]of [
 ['9915',dir+'/mounted-rod-fine-base5f-native9600.frames/9915.json'],
 ['9930',dir+'/mounted-rod-native9930.frames/9930.json'],
 ['10665','/tmp/bootstrap-archer-double-v8-courier-v2-20261015/mounted-loss-fine-10200-10800.frames/10665.json']]){
 const saved=JSON.parse(readFileSync(input,'utf8'));
 const match=bootstrapMatches(setup.seed,[setup.map],saved.snapshot.tick+1,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
 const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const snapshot=snapshotGame(game),before=copy(snapshot),patient=snapshot.units.find((u:any)=>u.id==='unit-p0-horseArcher-2503')!;
 const query=(fn:any)=>{const memory=copy(saved.memories.p0),memoryBefore=copy(memory),options=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory,teams:game.teams});const value=fn(options);return {value:copy(value),memoryBefore,memoryAfter:copy(memory),memoryUnchanged:isDeepStrictEqual(memoryBefore,copy(memory))};};
 const guard=query((o:any)=>[...mineGuardUnitIds(snapshot,'p0',o)]),mount=query((o:any)=>mountedTasks.run(snapshot,'p0',o)),care=query((o:any)=>mobileCare.run(snapshot,'p0',o));
 const actor=(q:any)=>q.value.filter((e:any)=>e.unitIds?.includes(patient.id));
 const commands=[...actor(mount),...actor(care)];
 const segmentGap=(p:any,a:any,b:any)=>{const dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1)));return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);};
 const geometry=commands.filter((c:any)=>c.type==='move').map((command:any)=>{
  const road=groundSteeringRoute(snapshot.map,patient,command),prefix=routePrefix(patient,road.slice(1),patient.speed*15/20);
  return {command,road,prefix,buildingClearance:snapshot.buildings.map((b:any)=>({id:b.id,x:b.x,y:b.y,radius:b.radius,segmentMargin:segmentGap(b,patient,command)-patient.radius-b.radius})).filter((b:any)=>b.segmentMargin<100),neutralThreats:snapshot.units.filter((u:any)=>u.owner==='neutral'&&u.attackDamage>0&&Math.hypot(u.x-patient.x,u.y-patient.y)<750).map((u:any)=>({id:u.id,kind:u.kind,order:u.order,hp:u.hp,speed:u.speed,gap:Math.hypot(u.x-patient.x,u.y-patient.y),reach:mountedThreatReach(snapshot,u,patient,15+patient.cooldown),goalGap:Math.hypot(u.x-command.x,u.y-command.y),items:itemsFor(snapshot,u)}))};
 });
 results.push({label,input,tick:snapshot.tick,restoredWorldEqual:isDeepStrictEqual(copy(snapshot),saved.snapshot),patient:copy(patient),mountedJobs:saved.memories.p0.mounted,guardIds:guard.value,riderGuardClaimed:guard.value.includes(patient.id),rawMountedActor:actor(mount),rawCareActor:actor(care),queryMemoryUnchanged:{guard:guard.memoryUnchanged,mounted:mount.memoryUnchanged,care:care.memoryUnchanged},geometry,queryWorldUnchanged:isDeepStrictEqual(before,copy(snapshotGame(game))),nextIdUnchanged:game.nextId===saved.nextId});
}
writeFileSync(dir+'/mounted-rod-query-9915-9930-10665.json',JSON.stringify({classification:'Read-only independent restored actual native frames. Each query gets its own full original p0memory clone; no query is run in the scored or native replay games. Geometry is diagnostic, actual physical paths recorded separately.',source,results},null,2));
console.log(JSON.stringify(results.map(r=>({tick:r.tick,riderGuardClaimed:r.riderGuardClaimed,rawMountedActor:r.rawMountedActor,rawCareActor:r.rawCareActor,geometry:r.geometry.map((g:any)=>({command:g.command,road:g.road,prefix:g.prefix,buildingClearance:g.buildingClearance})),queryMemoryUnchanged:r.queryMemoryUnchanged,queryWorldUnchanged:r.queryWorldUnchanged,nextIdUnchanged:r.nextIdUnchanged})),null,2));
