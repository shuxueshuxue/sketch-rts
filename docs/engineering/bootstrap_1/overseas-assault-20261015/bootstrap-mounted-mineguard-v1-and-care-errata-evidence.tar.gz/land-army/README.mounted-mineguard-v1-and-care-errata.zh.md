# bootstrap_1 073f矿防/骑手负例与医疗归因勘误

此增补封存已完成负例与原生路径事实，不是bootstrap验收，不建议合入073f61a7或v13。root/main、规则3和其他运行control未改；旧容器未提交修改仍无法恢复。旧包9157e6647611ed0f418b056281e9b233bb7c23782634b97b18460c547c91b953保持原SHA、README不回写。

## 必须更正的医疗归因

ERRATA.care-follow-medical-causality-v13.json保留完整原史和私有公式输入：原5f骑手10059已由1907真实25/109->80/109治疗55。10200/10215/10230/10245/10260又由mobileCare主动重发follow，因此不能说从未治疗，也不是纯粹残留10050命令。

原land-recovery的私有incomingDamage按所有仍攻击该患者的单位累计、没有距离筛选。10200选1907窗口99时317；10260窗口39时166。10275三个野怪都因原生leash放弃目标，累计直接归0，原triage正常释放。最近医师也在同帧切换，时间重合不能证明nearest导致漏claim。此前range-limited incomingDamage0查询不等于这个私有累计器，应以本次公式与实际命令更正。

新v13固定7a8dc8d0只保留已有合法follow的接近任务、仍使用原nearestByRoute选医师，源码1463路径前后不变。真实共同9600->11400全3AI续局首差10275，改mountedTasks攻击为follow更近2255；但骑手10695仍被同ogre84雷杖杀80（基线10681）。9615JSONcheckpoint world/nextId/3mem闭合。此局部无足够收益，不启动v13普通0，也不靠新医疗记忆/他人施法CD推测患者疗程。

## 原9934第一雷杖的真实机制

同5f源实际9600->10200每15tick存完整world/nextId/3mem，终点与原普通0的10200全等；9615checkpoint全等。再以真实9930档逐原生tick续至9960，9960与该真实fine档全等，9945checkpoint全等。

原mountedTasks到9900仍持续微操撤离。9915 mineDefense把仍在mounted camp任务中的骑手与另6人一起attackMove到矿防post，早于mountedTasks的mineGuard claim阻止后续mounted微操输出。9930无骑手新命令；原生attackMove锁ogre-gen-3-2并停射，9915->9945骑手坐标不变。杆ogre gap9915=299.815、9930=247.878、9933=237.492且CD0；9934 updateItems先于移动对109HP骑手造成84，剩25。

独立恢复真实body metadata查询9930：raw mountedTasks本会发move(1964.083443817938,2902.9189624504734)，但实际完整栈没有执行。该候选groundSteeringRoute直达，附近100px内无建筑线段障碍。query世界/nextId/原p0记忆均不变；查询未插入原生重演进程。实际native9934图已用原drawWorld渲染并亲看，红240圈是分析叠加，fresh facing不重建历史动画。

## 原10681死亡的独立路径事实

10665->10695每原生tick全3AI续局的10695 world/nextId/3mem与原fine档全等，10680checkpoint也闭合。10665实际care命令(2068.4438036480205,2773.652396073518)道路直达；raw mounted另一命令也直达，均无附近建筑。实际10680位置(2071.7050402634795,2777.44242717339)与查询15tick直线prefix相差仅约4.55e-13px，没有建筑/身体投射绕路偏差证据。10679杆gap240.396，10680 gap237.705且杆CD0，10681原生item更新直接84杀80。

所以首例是矿防停微操，后例是所选直线本身进入杆圈；不是同一个建筑绕路bug。near漏杆假说也已被旧fine反证，未据此加fullFoes层。中立杆实际范围240，骑手此时升级后攻击范围304，不能拿基础264或普通玩家杆范围替代真实规则。

## 独立073f61a7候选及实际完整代价

固定源073f61a776caf2233d003bb7be3210548a949700，/tmp/sketch-rts-mounted-mineguard-v1-control；只在5f657b38上把已有mounted任务unitIds从detachment池过滤，2插入1删除，不叠任何follow候选。现有mainArmyIntel已同样排除mounted任务，但矿防更早优先级是有实战意义的策略选择，因此不能仅凭对称性证明改动正确。

聚焦真实9600->11400首命令差9915：原7人矿防因移除一名现役rider后无法达到原门槛而整体取消；并非仅过滤发令中的一人后其余6人照发。兵力倍率、60%HP、人数/前线分离等门槛全部原值。骑手11400仍109/109、零伤零治疗、已作业另一个camp，但原队友lancer2286在10944被ogre34杀，archer1107在11031被雷杖84杀；此时新2中立死，旧1中立死。9615checkpoint world/nextId/all3mem全等。

已真实启动未改inspect普通0（session12271，已exit0），而非只做存档回放。subject Grove v9_archer物理side1，正常冻结v8 Ember+Grove同队，factory pineshade / 实际unseen生成ladder4608²，seed bootstrap_1-unseen-archer-v8-v8-20261015-01。标准三方500金/3已用/8上限，独立factory0 witness与5f基线世界/nextId全等。规则2、冻结revision d1ae110f2edd99f9c7d899ed61557891ab587639、184 manifest条、SHA0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774全保持。

实际0->34864 p1自然胜，p0全单位/建筑清零；p0原生71单位死亡（本局全为永久）、2中立死，支出13661；原5f0->43714 p0胜/56永久死/1中立死。不能因骑手短窗零伤称胜或以短败局花钱较少当经济改善。073f保持未合，不开召唤跨路线普通0。

本例是三方：每600tick report row含p0/p1/p2完整policy，paired frames含完整world+nextId。0 factory witness及600..9600全部与5f匹配，首存档差10200；上述临床11400 world/nextId/3mem与新普通0的11400逐值全等，故该9915真实分叉与两个初始死亡属于新0历史。34800->34864全3AI同源终局、34815JSONcheckpoint与原0终局均全等。前后1239源码/支持数据哈希全不变，clean固定073f；起点live/frozen源码胶囊SHA21f07270e2aded17a09ebe4e91865db53e0494028bcafe23b355fc8945380c58。

## 回归与交付

test-only0bfc8755含真实完整9930 fixture和两项原生回归：旧attackMove静止15tick吃84的对照、生产栈必须执行mounted逃离并保持109HP。两项均过；原mine-defense19、field真实snapshot1、ground assignments18、expedition priority18一起共58项，52过/6红。六红均reservedCrew旧断言，不回写旧测试；只把mine-defense.ts精确恢复5f原文件后，同6红仍在，新9930生产例才额外红，20项变7红/13过。最后逐字恢复候选，tsc0。它们不授权捆绑修复naval、mercenary或shopping owner。

生产patch与test-only patch分别提供，当前用于review/负例，不建议合入。mounted-mineguard-v1-candidate-sources.tar.gz以SHA内容地址保留v13、073f各1463源码/数据路径和另标test-only文件；每载荷已核验。普通0另有完整live/frozen源码胶囊。原5f完整基线及冻结迁移证据继续见原9157包；本增补不覆盖它。

下一步遵root要求仅只读追新实际普通0第一处实质损失、原7人取消后的去向/防线与后期败局的关系，再区分“转交macro并清mounted任务”和“最低生存微操跨macro覆盖”两种不同语义。不立即改ownership、不放宽门槛、不混改其他reserved owner。三路线最终完整对手组合/地图/未见种子要求仍未完成。
