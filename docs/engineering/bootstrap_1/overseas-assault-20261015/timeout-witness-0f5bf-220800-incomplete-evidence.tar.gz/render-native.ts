import {createCanvas} from '@napi-rs/canvas';
import {readFileSync, writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {installHeadlessCanvas} from '/tmp/sketch-rts-timeout-witness-0f5bf-control/src/recorder/record.ts';
import {drawWorld} from '/tmp/sketch-rts-timeout-witness-0f5bf-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/tmp/sketch-rts-timeout-witness-0f5bf-control/src/client/unit-facing.ts';

const out = '/workspace/.playtest/timeout-witness-0f5bf';
const source = '/tmp/sketch-rts-timeout-witness-0f5bf-control';
const sha = (b: any) => createHash('sha256').update(b).digest('hex');

installHeadlessCanvas();
const records: any[] = [];
for (const spec of [
 {label:'native-before-216000',tick:216000,input:'input-216000.json',view:{x:7350,y:3600,width:2000,height:1800,zoom:1.0}},
 {label:'native-baseline-217200',tick:217200,input:'baseline-216000-217200-final.json',view:{x:7350,y:3600,width:2000,height:1800,zoom:1.0}},
 {label:'native-candidate-217200',tick:217200,input:'candidate-216000-217200-final.json',view:{x:7350,y:3600,width:2000,height:1800,zoom:1.0}}
]) {
  const frame = JSON.parse(readFileSync(out + '/' + spec.input, 'utf8'));
  if (!frame || frame.snapshot.tick !== spec.tick) throw Error('missing exact frame ' + spec.tick);
  const before = sha(JSON.stringify(frame));
  const canvas = createCanvas(spec.view.width, spec.view.height);
  drawWorld({ctx:canvas.getContext('2d') as any,snapshot:frame.snapshot,view:spec.view,now:spec.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
  const png = canvas.toBuffer('image/png');
  writeFileSync(out + '/' + spec.label + '.png', png);
  const after = sha(JSON.stringify(frame));
  if (before !== after) throw Error('renderer changed frame');
  records.push({...spec,pngSha256:sha(png),snapshotSha256:sha(JSON.stringify(frame.snapshot)),inputSha256:sha(readFileSync(out+'/'+spec.input)),fullInputUnchanged:true});
}
writeFileSync(out + '/native-render-metadata.json', JSON.stringify({classification:'Post-run native client drawWorld renders of exact216000 input and217200 baseline/candidate native worlds. No snapshot edits or game steps; not historical live screenshots or fullgame acceptance.',source,records,renderSourceHashes:Object.fromEntries(['src/recorder/record.ts','src/client/world-renderer.ts','src/client/unit-facing.ts'].map(p=>[p,sha(readFileSync(source+'/'+p))]))},null,2));
console.log(JSON.stringify(records));
