# Timeout witness: independent root0f5bf counterfactual

The narrow donor predicate removes a demonstrated false wait witness. It does **not** produce a win or effective attack in the recorded native windows. The final state is an unfinished match at220800; no complete-game benefit or bootstrap acceptance is claimed.

## Attribution and preserved gap

The input216000 is SHA8559f746a0388d068467aa8a691058fe50c7f0e43537def05fa014adea5a8b32, complete world/nextId12073/both full memories, from the separately sealed36ae+unified-care changed-code continuation. Its prefix was64800 code change,68400 same-code continuation, not ordinary0. Here BOTH controls change that old source to root0f5bf01a05046169d4fb42322376f767b97bcc83; only the candidate adds the donor predicate. Neither carries unified-care. Engine/static rating changes already in0f5bf mean neither trajectory may be relabeled as old36ae or a root ordinary0. The original old-container uncommitted-work recovery gap remains open.

RulesVersion2, actual frozen184 manifest revisiond1ae110f2edd99f9c7d899ed61557891ab587639, normal p1v5 Ember and p0v9_knight Grove, original world/map/resources/population retained. No manual gameplay command, teleport, army change, weakened enemy, new owner, TTL, required reduction, or matrix rerun. Test counterfactuals are expressly labeled separately.

## Production and tests

Only naval.ts723's existing same-target/same-purpose/same-phase fresh-companion exemption changes. Witness now requires an owned live permanent nonworker LAND unit actually attached to that hull or holding a CURRENT top-level native board order to it. An unarmed permanent priest/summoner counts; queued-only intents, worker-only cargo, temporary units and crewIds declarations do not. This merely grants waiting permission; it does not credit a boarder as arrived combat strength. Original40s/20s/32px, physical progress updates, departure/required/assembly gates and loading/worker/service ownership remain intact.

`production.patch` SHAa2873236790b16112a6b38aeb7a6ee12437817513067b93b832e810d08306a72. Portable all-changes.patch includes the precise old expected-contract updates, six new cases and real216000 gzfixture. Forward--check against baseline and reverse--check against candidate both pass without index/worktree mutation.

The first46 existing tests were run before test changes:40passed/6failed (existing-tests.log). Those six expected a stale loaded convoy to wait on a physically empty search boat. Final52/52 pass in tests-second.log; tsc--noEmit exit0 (empty tsc-first.log). Original pickup/from/world-immutability assertions remain, and two-think rendezvous positives now issue real public native board. Six new cases cover actual216000, declaration-only/worker/temporary negatives and native priest/summoner positives. Their spawn/zero-basic-attack/native-board manipulations are controlled test boundaries, not observed match evidence. Independent reviewer only read source/tests/logs/queries and did not independently run tests/game.

## Actual full planner and native consequence

Complete p0 all-script pure query restores fullworld/id and leaves it unchanged. Plainroot0f5bf:0 commands. Candidate:1046 unload, stop six actual land boarders to6933 (includingpriest2356),6933 unload to originalfrom. All nine full-memory differences are the two cancellations and retry; p1memory matches. Query is not a native run.

Both native controls restore the exact same full216000 input and run normal bothAI through217200. Source/driver actual prelaunch records precede running. Baseline:4 enemy commands,0hits,0events; all three missions still loading. Candidate:15commands,0hits,19actual deck transitions.216001 really disembarks6933's five passengers and1046's worker,216015 orders the released force to4699, and three actually board216285–318.4699 later stops making physical progress and the unchanged40s logic cancels it217140;217141 actual offdeck then217155 reassigns1046/6933. First full native state difference is216001.

Same fixed candidate continues217200→220800:102commands,0hits,51actual deck transitions. Two more real unloading/reboarding cycles218685→219105 and220185→220605 occur. Combined4800ticks:117commands,70actualdeck transitions,0terminal events,0births,0hits, no enemybuildingdamage, no new mining/army/capital and no winner. Both owners' gold/spending/unit/building summaries remain equal to initial. These are repeated strategic outcomes, NOT a proof of a bitwise state cycle or future impossibility.

Read-only exported current-source assaultExpedition at216000,217200,220800: required19.509563045254225, selected permanent army15.048867013595931, readyfalse. Prior36ae required15.798005524588689 belongs only to that old source; current gates were not changed. Additional boarding/capital/readiness problems remain; this candidate cannot be accepted because cancel/reboard worked or losses stayedzero. No blind horizon increase follows these observed cycles.

Cold restore219600 (actual normal before-next-think periodic checkpoint)→220800 matches original continuation in ALL complete final world, nextId, both full memories,1201 whole-state hashes,43 public commands,0hits and20nativeevents. No fields were removed to claim equality.

## Evidence integrity and viewing

`window-driver.ts` uses the supported normal game runner; actual cwd is each absolute Git control. Every native command, hit and command/step-boundary terminal/parent transition is retained; beforeStep ledger includes hp0 hulls pending cleanup. Events are observations, not automatically certified restart points. Native periodic frames are full world/id/bothmem every15ticks; significant event frames retain stage/command index. Fullstate hashes are per tick. Terminal and raw removal are separate; temporary expiry is never silently counted as native unitsLost.

Native-client drawWorld PNGs render the exact216000 and217200 saved worlds after the run. They were personally viewed: the occupied left hull is emptied and cargo changes hull near the same colony shore, with troops still gathered locally. They are post-run native renders, not historical live screenshots. The renderer did not modify full inputs or step the game. Metadata hashes source/input/PNG.

Controls baseline1426/candidate1428 files and frozen184 have0 runtime source changes at every run's pre/postflight and final postflight. Both immutable source capsules and actual frozen revision capsule were hash-verified. Frozen archival recovery was post-run and is explicitly marked as such, not invented prelaunch evidence. Creation/setup/test/query/fullgame command logs and immutable prior-archive reference are retained. No root/main/fixed old source was edited.

This package supports the false-donor correction and exposes remaining repeated assembly, not final three-route/multi-opponent/generalization success. Ordinary matches and shared strategic changes are coordinated by the parent agent.
