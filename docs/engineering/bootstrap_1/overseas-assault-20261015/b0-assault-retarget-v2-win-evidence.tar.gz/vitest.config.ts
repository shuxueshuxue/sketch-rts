import{defineConfig}from'vitest/config';export default defineConfig({root:'/tmp/b0-assault-retarget-v2',test:{include:['v2-boundaries.test.ts'],testTimeout:60000}});
