from pathlib import Path
import json,hashlib,shutil
O=Path('/workspace/.playtest/coastal-33582-capture-readonly-20261016');P=Path('/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016')
sha=lambda b:hashlib.sha256(b).hexdigest();report=json.loads((O/'CAPTURE-33582-REPORT.json').read_text());shutil.copyfile(O/'CAPTURE-33582-REPORT.json',O/'CAPTURE-33582-REPORT-v1-bounded.json')
ids={'unit-p0-warship-33582','unit-p0-priest-32497'};inputs=[];allEvents=[];allCommands=[]
for relative in ['ordinary0-native-events.jsonl','ordinary0-public-commands.jsonl','resume-79800/ordinary0-resume-native-events.jsonl']:
 p=P/relative;b=p.read_bytes();inputs.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'scope':'Historical closed0f ordinary output, copied rows below have exact original line numbers. No game/planner executed; not current7f68 strategy output.'})
 for i,line in enumerate(b.splitlines(),1):
  if not any(id.encode() in line for id in ids):continue
  r=json.loads(line)
  if 'events' in relative and r['type'] in ['unit-birth-observed','observed-parent-change','observed-disembark','owner-change']:
   allEvents.append({'source':str(p),'line':i,'raw':r})
  if 'commands' in relative and r['tick']<=64415 and r['command']['type'] in ['board','boardShip','stop']:
   allCommands.append({'source':str(p),'line':i,'raw':r})
assert [e['raw']['tick'] for e in allEvents]==[62135,64165,64415]
board=next(r for r in allCommands if r['raw']['command']['type']=='board');assert board['raw']['tick']==64170
history={'classification':'Old0f actualordinary birth and firstboarding ancestry only. Current7f68 capture remains separate changed-code continuation. No simulation or neworders.','inputs':inputs,'originalBirthsAndBoardingEvents':allEvents,'originalNativeIssueAttempts':allCommands,'scope':'Ship33582 actualborn64165, priest32497 born62135, navalboardorder64170, actualdeckentry64415. No owner-change/disembarkfor these IDs in the two checked original0f event streams through original193200stop. Intervening changed-source193200→226890 ancestry is not claimed fullyrescanned; current226890 snapshot independently confirms only32497 aboard.'}
(O/'ORIGINAL-CREW-HISTORY.json').write_text(json.dumps(history,indent=2)+'\n')
report['inputManifests']+=inputs;report['originalCrewHistory']={'path':'ORIGINAL-CREW-HISTORY.json','sha256':sha((O/'ORIGINAL-CREW-HISTORY.json').read_bytes()),'priestBirth':62135,'shipBirth':64165,'publicBoardOrder':64170,'actualFirstDeckEntry':64415,'checkedOriginalNoOwnerChangeOrDisembark':True}
report['limits']=[s for s in report['limits'] if not s.startswith('No earliest shipbirth')]+['Original0f64165shipbirth/64415priestboarding have since been looked up and added in separate historicalreport. We did not re-audit every intermediarychangedsource segment193200→226890, so lifetime owner-event completeness is bounded to checked original0f and current7f68 streams.']
report['previousBoundedReport']={'path':'CAPTURE-33582-REPORT-v1-bounded.json','sha256':sha((O/'CAPTURE-33582-REPORT-v1-bounded.json').read_bytes()),'scope':'Initial current226890-only version preserved; finalreport adds true originalbirth/boarding evidence without changing raw/frames/source.'}
(O/'CAPTURE-33582-REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'reportSHA256':sha((O/'CAPTURE-33582-REPORT.json').read_bytes()),'historicalSHA256':sha((O/'ORIGINAL-CREW-HISTORY.json').read_bytes()),'sourceFiles':len(inputs),'events':len(allEvents),'commands':len(allCommands)}))
