"""Prepared launcher. Parent runs onlyafter scheduling resources. Preparing thisfile doesnotstart Node."""
from pathlib import Path
import subprocess,json,hashlib,datetime,time,shutil,os,sys
D=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');S=Path('/workspace/sketch-rts-root-medical-04669148-fixed-control');HEAD='0466914857bd7b185a66ec42edb0202b5a884ca5';P=D/'known-archer0-04669148';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prepared=json.loads((D/'PREPARED.json').read_text());assert prepared['preparedOnlyNoGameNoNode'] and prepared['sourceHead']==HEAD
for p,h in prepared['launchBoundFiles'].items():assert H(Path(p))==h,p
b=json.loads((D/'driver-preflight.json').read_text());assert b['sourceHead']==HEAD and b['sourceRoot']==str(S) and b['sourceManifestFiles']==1507 and b['frozenFullFiles']==497 and b['frozenManifestFiles']==184
for p,h in b['boundFiles'].items():assert H(Path(p))==h,p
assert H(D/b['driverFile'])==b['driverSHA256'] and H(D/'package.json')==b['externalModuleContext']['sha256'];assert json.loads((D/'package.json').read_text())['type']=='module' and b['driverFile'].endswith('.mts')
for n,h in b['dependencies'].items():assert H(D/n)==h,n
assert H(D/'known-case-declaration.json')==b['knownCaseDeclarationSHA256'];assert not(D/'observation-stop.json').exists(),'Do notcarryastaleobservationalstopintonewordinary0'
cap=json.loads(Path(str(P)+'-runtime-source.json').read_text());assert H(Path(str(P)+'-runtime-source.json'))==b['runtimeSourceCapSHA256'];assert len(cap['files'])==1507 and len(cap['frozenFiles'])==497
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True)
for f in cap['files']:assert H(S/f['path'])==f['sha256'],f['path']
allowed={Path(str(P)+'-runtime-source.json'),Path(str(P)+'-source.tar.gz')}
assert not set(D.glob(P.name+'*'))-allowed,'Preserveexistingrunoutput; nosilentoverwrite/restart'
cur=int(Path('/sys/fs/cgroup/memory.current').read_text());mx=int(Path('/sys/fs/cgroup/memory.max').read_text());space=shutil.disk_usage(D).free;tmp=shutil.disk_usage('/tmp').free
r={'classification':'Actualparentinitiatedpre-spawnguard; source/input binding checked beforeNode. DoesnotbyitselfproveGame/factoryinitialequality orruncompletion.','startUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':HEAD,'rawHeadroomBeforeSpawn':mx-cur,'requiredHeadroom':2*1024**3,'outputFreeBytes':space,'temporaryFreeBytes':tmp,'requiredOutputFreeBytes':256*1024**2,'heapMiB':768,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text(),'driverSHA256':b['driverSHA256'],'preparedSHA256':H(D/'PREPARED.json')}
i=len(list(D.glob('launch-guard-*.json')))+1;(D/f'launch-guard-{i}.json').write_text(json.dumps(r,indent=2));assert mx-cur>=r['requiredHeadroom'],'fresh2GiB gate; noNode';assert space>=r['requiredOutputFreeBytes'],'fresh256MiBoutputgate; noNode'
args=['node','--max-old-space-size=768','--import','tsx',str(D/b['driverFile']),str(S),HEAD,str(P)];t=time.monotonic();env=os.environ.copy();env.pop('NODE_OPTIONS',None)
p=subprocess.run(args,cwd=S,env=env);r.update(exitCode=p.returncode,elapsedSeconds=time.monotonic()-t,endUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),oomAfter=Path('/sys/fs/cgroup/memory.events').read_text());(D/f'process-exit-{i}.json').write_text(json.dumps(r,indent=2));raise SystemExit(p.returncode)
