"""Read/hash/archive only; no Node, factory, Game, planner or compiler."""
from pathlib import Path
import subprocess,sys,json,hashlib,tarfile,io,datetime,os
assert len(sys.argv)==4
W=Path(sys.argv[1]);HEAD=sys.argv[2];P=Path(sys.argv[3]);D=P.parent
assert W==Path('/workspace/sketch-rts-root-medical-04669148-fixed-control') and HEAD=='0466914857bd7b185a66ec42edb0202b5a884ca5' and D==Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','--untracked-files=all').strip()
assert not Path(str(P)+'-runtime-source.json').exists() and not Path(str(P)+'-source.tar.gz').exists()
paths=['src','scripts','tools','.gitattributes','.gitignore','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json'];files=[];live={}
for row in git('ls-tree','-r','-z',HEAD,'--',*paths).split(b'\0'):
 if not row:continue
 meta,path=row.split(b'\t');mode,kind,blob=meta.decode().split(' ');name=path.decode();assert kind=='blob';data=(W/name).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==blob,name
 files.append({'path':name,'expectedGitBlob':blob,'actualGitBlob':actual,'sha256':sha(data),'bytes':len(data),'matches':True});live[name]=data
assert len(files)==1507
manifest=json.loads(live['docs/engineering/bootstrap_1/frozen-policy.json']);manifest_sha=sha(live['docs/engineering/bootstrap_1/frozen-policy.json']);assert manifest_sha=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774' and manifest['rulesVersion']==2 and len(manifest['files'])==184 and manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639'
oldcap_path=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5-runtime-source.json');oldcap=json.loads(oldcap_path.read_text());F=Path(oldcap['frozenArchive']);assert sha(F.read_bytes())==oldcap['frozenArchiveSHA256']=='34be8981d6eb475173ebd75a787b2776584040ae7fe7e5c909540b478e00a8e5'
with tarfile.open(F,'r:gz')as t:frozen={m.name:t.extractfile(m).read()for m in t if m.isfile()}
assert len(frozen)==497 and {n:sha(b)for n,b in frozen.items()}==oldcap['frozenFiles']
fgit={}
for row in git('ls-tree','-r','-z',manifest['revision'],'--','package.json','src/ai','src/sdk','src/shared').split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t');mode,kind,blob=meta.decode().split();name=p.decode();assert kind=='blob';b=frozen[name];actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert actual==blob,name;fgit[name]=blob
assert len(fgit)==497 and set(fgit)==set(frozen)
for name,h in manifest['files'].items():assert sha(frozen[name])==h,name
validation=Path('/workspace/.playtest/root-medical-safe-prefix-integration-20261016/COMBINED-VALIDATION.json');v=json.loads(validation.read_text());assert v['head']==HEAD and len(v['sequential'])==3 and all(r['exit']==0 and r['all1507SelectedSourcePrePostExact']for r in v['sequential'])
eq_path=validation.with_name('SOURCE-EQUIVALENCE.json');eq=json.loads(eq_path.read_text());assert eq['head']==HEAD and eq['selectedFiles']==1507 and eq['rootAndControlEveryGitBlobSHA256Exact'];assert {x['path']:x['sha256']for x in files}=={x['path']:x['sha256']for x in eq['files']}
archive=Path(str(P)+'-source.tar.gz');index={}
with tarfile.open(str(archive)+'.tmp','w:gz')as t:
 for name,data in sorted(live.items()):
  e=tarfile.TarInfo('live/'+name);e.size=len(data);e.mode=0o644;e.mtime=0;t.addfile(e,io.BytesIO(data));index[e.name]=sha(data)
 data=(json.dumps({'algorithm':'SHA256','classification':'Onlynewlive1507source; completeunchanged497frozenarchive separatelyreferenced, not duplicated.','files':index},indent=2)+'\n').encode();e=tarfile.TarInfo('INDEX.json');e.size=len(data);t.addfile(e,io.BytesIO(data))
os.rename(str(archive)+'.tmp',archive)
with tarfile.open(archive,'r:gz')as t:
 regular=[m for m in t if m.isfile()];assert len(regular)==1508
 for name,h in index.items():assert sha(t.extractfile(name).read())==h,name
cap={'classification':'Preparedread/hash/archive only. Actual046factory/worldequality hasNOTbeenexecuted; driverwillrequireexactoriginal0beforefirstthink. Newlive1507archived; complete497frozenarchive reused bySHA/readback/Gitblob, no oldrawrepack.','root':str(W),'head':HEAD,'gitStatus':'','files':files,'frozenManifestSHA256':manifest_sha,'frozenRevision':manifest['revision'],'rulesVersion':2,'frozenManifestFiles':manifest['files'],'frozenFiles':{n:sha(b)for n,b in frozen.items()},'frozenGitBlobsVerified':fgit,'sourceArchive':str(archive),'sourceArchiveSHA256':sha(archive.read_bytes()),'sourceArchiveBytes':archive.stat().st_size,'archivePayloadCount':len(index),'archiveRegularIncludingINDEX':1508,'archiveReadbackVerified':True,'frozenArchive':str(F),'frozenArchiveSHA256':sha(F.read_bytes()),'frozenArchiveBytes':F.stat().st_size,'frozenArchiveReusedWithoutCopy':True,'frozenSourceCapReference':str(oldcap_path),'frozenSourceCapReferenceSHA256':sha(oldcap_path.read_bytes()),'rootCombinedValidationReceipt':str(validation),'rootCombinedValidationSHA256':sha(validation.read_bytes()),'rootSourceEquivalenceReceipt':str(eq_path),'rootSourceEquivalenceSHA256':sha(eq_path.read_bytes()),'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','--untracked-files=all').strip()
for e in files:assert sha((W/e['path']).read_bytes())==e['sha256'],e['path']
Path(str(P)+'-runtime-source.json').write_text(json.dumps(cap,indent=2)+'\n')
print(json.dumps({k:v for k,v in cap.items()if k not in ['files','frozenFiles','frozenManifestFiles','frozenGitBlobsVerified']}))
