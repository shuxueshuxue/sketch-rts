# 046 固定源普通开局：仅准备，尚未启动

源 `0466914857bd7b185a66ec42edb0202b5a884ca5`，严格控制树 `/workspace/sketch-rts-root-medical-04669148-fixed-control`，1507 文件已逐 Gitblob/live SHA 核实并封存。已有冻结497文件包只引用，全部内容已重新读验并与冻结Git对象和184 manifest闭合；不重复打包旧raw。

真实普通0计划：v9_archer Grove，对正常冻结v7 Ember+v8 Grove；pineshade已知生成seed，side0，500金/3worker/8cap，think15，rules2。`unseen=true`只复制原factory地形，不是新holdout。

本目录尚未运行Node、编译器、Game、factory或planner。`.mts`与`package.json type:module`、driver、telemetry、ledger、初档87a42…、完整sourcecap及父组合验证均绑定。真正启动后，driver须在首次P0前严格比较新factory全部world/id/null3mem/setup；准备阶段没有伪称已生成相同新world。

父线程完成实际资源协调后，执行 `python3 /workspace/.playtest/bootstrap-root-046-known-archer0-20261016/launch-ordinary0.py`。launcher每次重新验2GiB内存余量及输出所在filesystem的256MiB余量；临时/tmp余量记录供协调。现在不执行launcher。

沿用旧固定driver的完整协议：每owner每think全3postmem、600边界完整存档、原生事件/命中/死亡/治疗、attempt命令及成本记录。无任意tick截止；只有自然winner或父线程有具体理由和证据的600边界观察停止。旧38f/8da完整负局和641b局部600成绩各自归属；原未提交工作区缺口仍未恢复。
