from pathlib import Path
import json,hashlib,subprocess
from datetime import datetime,timezone
p=Path('/tmp/bootstrap-land-army-evidence-20261015');source=Path('/tmp/sketch-rts-root-retarget-3bdb-control');prefix=p/'production-root3bdb-archer-double-v8-ordinary0'
expected='3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71'
def git(*a):return subprocess.check_output(['git',*a],cwd=source)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==expected
assert not git('status','--porcelain').strip()
assert not Path(str(prefix)+'.json').exists() and not Path(str(prefix)+'.json.frames').exists()
metadata=Path('/tmp/bootstrap-root-retarget-3bdb-20261015/prelaunch-source.json');fixed=json.loads(metadata.read_text())
assert fixed['commit']==expected and len(fixed['hashes'])==1555
changes=[n for n,h in fixed['hashes'].items() if sha((source/n).read_bytes())!=h];assert not changes,changes
archive=Path('/tmp/bootstrap-root-retarget-3bdb-20261015/prelaunch-source-capsule.tar.gz')
assert sha(archive.read_bytes())==fixed['sourceCapsuleSHA256']=='26f1193abc078ff0100299beaa03600da893200a026908036df2d6059cfe4a06'
oldprefix=p/'archer-mounted-mineguard-v2-ordinary0'
script=Path(str(prefix)+'-prelaunch-opening.ts')
script.write_text(Path(str(oldprefix)+'-prelaunch-opening.ts').read_text().replace('/tmp/sketch-rts-mounted-mineguard-v2-control',str(source)).replace(str(oldprefix),str(prefix)))
Path(str(prefix)+'.json.frames').mkdir()
subprocess.run(['node','--import','tsx',str(script)],cwd=source,check=True)
opening=Path(str(prefix)+'-opening.json');new=json.loads(opening.read_text());oldpath=Path('/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary-opening.json');old=json.loads(oldpath.read_text())
compare={'classification':'Independent actual public factory0 witness before unmodified inspect ordinary0, same developed original5f archer dualv8 case; no restoration/world/memory edits.','baselinePath':str(oldpath),'baselineSHA256':sha(oldpath.read_bytes()),'snapshotEqual':new['snapshot']==old['snapshot'],'nextIdEqual':new['nextId']==old['nextId'],'initialEqual':new['initial']==old['initial']}
assert all(compare[k] for k in ['snapshotEqual','nextIdEqual','initialEqual'])
put(Path(str(prefix)+'-opening-comparison.json'),compare)
pre=json.loads(Path('/tmp/bootstrap-root-3bdb-ordinary0-20261015/ordinary-runtime-source.json').read_text())
command=['node','--import','tsx','scripts/bootstrap_1-inspect.ts','--map','pineshade','--seed','bootstrap_1-unseen-archer-v8-v8-20261015-01','--subject','v9_archer','--opponents','v8+v8','--race','grove','--side','1','--ticks','144000','--sample-ticks','600','--frames','--out',str(prefix)+'.json','--unseen']
pre.update({'classification':'New true ordinary0 prelaunch, current production clean3bdb; independent same public factory opening as old5f archer dualv8. Reuses immutable2052-payload full source capsule captured previously; prior continuation/summoner results are not this run.','createdAtUtc':datetime.now(timezone.utc).isoformat(),'fullSourceArchive':str(archive),'fullSourceArchiveSHA256':fixed['sourceCapsuleSHA256'],'sourceArchivePayloadsVerified':fixed['sourceCapsulePayloadsVerified'],'allLiveHashes':fixed['hashes'],'allLiveFilesVerified':len(fixed['hashes']),'sharedFullSourceMetadata':str(metadata),'sharedFullSourceMetadataSHA256':sha(metadata.read_bytes()),'openingPath':str(opening),'openingSHA256':sha(opening.read_bytes()),'openingFrameSHA256':sha((Path(str(prefix)+'.json.frames')/'0.json').read_bytes()),'openingComparison':compare,'observerPreflightScriptSHA256':sha(script.read_bytes()),'command':command,'cwd':str(source)})
assert pre['baseCommit']==expected and pre['frozenManifestEntriesVerified']==184
assert sha((source/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes())==pre['frozenManifestSha256']=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
assert not git('status','--porcelain').strip()
put(Path(str(prefix)+'-runtime-source.json'),pre)
put(Path(str(prefix)+'-launch.json'),{'preparedOnly':True,'gameplayStarted':False,'expectedCommit':expected,'cwd':str(source),'argv':command,'stdoutLog':str(prefix)+'.log','fullLiveFilesVerified':1555,'openingComparison':compare})
print(json.dumps({'prefix':str(prefix),'commit':expected,'sourceFiles':1555,'sourceCapsuleSHA256':fixed['sourceCapsuleSHA256'],'openingComparison':compare},indent=2))
