import{readFileSync,writeFileSync}from'node:fs';
import{rankBootstrapGoals,planBootstrapEconomy}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/bootstrap_1/economy.ts';
import{bootstrapPolicyContext}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/bootstrap_1/policy.ts';
import{navalBudgetReserve,navalReservePurchase}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/policy/naval.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',report=JSON.parse(readFileSync(root+'/archer-portrait-ordinary.json','utf8')),samples=[];
for(const tick of[20400,21600,22800,24000,25200,26400,27600,28800,30000]){
 const row=report.rows.find((r:any)=>r.tick===tick);if(!row)continue;
 const frame=JSON.parse(readFileSync(root+`/archer-portrait-ordinary.json.frames/${tick}.json`,'utf8')),s=frame.snapshot;
 const options=bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(row.players.p0.policy),teams:s.teams});
 const reserve=navalBudgetReserve(s,'p0',options),ranked=rankBootstrapGoals(s,'p0',options);
 const commands=planBootstrapEconomy(s,'p0',bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(row.players.p0.policy),teams:s.teams}));
 samples.push({tick,gold:s.players.p0.gold,reserve,goals:ranked.map(g=>({id:g.id,cost:g.cost,priority:g.priority,save:g.save,productionReserve:g.productionReserve,ownReservePurchase:navalReservePurchase(g.id),affordableAfterReserve:g.cost<=s.players.p0.gold-(navalReservePurchase(g.id)?0:reserve),wouldBreakIfUnaffordable:g.save&&g.cost>s.players.p0.gold})),commands});
}
writeFileSync(root+'/archer-portrait-ordinary-budget-observer.json',JSON.stringify({classification:'Pure queries on clones of recorded ordinary-opening samples; no state advancement or command execution',samples},null,2));console.log(JSON.stringify(samples,null,2));
