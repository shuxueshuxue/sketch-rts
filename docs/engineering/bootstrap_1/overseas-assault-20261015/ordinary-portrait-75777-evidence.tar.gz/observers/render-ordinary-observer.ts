import { createCanvas } from '@napi-rs/canvas';
import { readFileSync, writeFileSync } from 'node:fs';
import { installHeadlessCanvas } from '/workspace/sketch-rts-portrait-endgame-control/src/recorder/record.ts';
import { drawWorld } from '/workspace/sketch-rts-portrait-endgame-control/src/client/world-renderer.ts';
import { UnitFacingTracker } from '/workspace/sketch-rts-portrait-endgame-control/src/client/unit-facing.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
installHeadlessCanvas();
const tick=Number(process.argv[2]??22800);
const {snapshot}=JSON.parse(readFileSync(`${root}/archer-portrait-ordinary.json.frames/${tick}.json`,'utf8'));
for(const [label,view] of [['world-overview',{x:-1800,y:-200,width:1500,height:1100,zoom:.1}],['north-pickup',{x:2900,y:600,width:1500,height:1100,zoom:.65}],['home',{x:6800,y:2400,width:1500,height:1100,zoom:.65}],['enemy',{x:1200,y:5500,width:1500,height:1100,zoom:.8}],['sailing-duel',{x:2000,y:3400,width:1500,height:1100,zoom:1.5}]]as const){
 const canvas=createCanvas(1500,1100);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:snapshot.tick*1000/20,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
 writeFileSync(`${root}/archer-portrait-ordinary-${tick}-${label}.png`,canvas.toBuffer('image/png'));
}
