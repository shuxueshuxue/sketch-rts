import { readFileSync, writeFileSync } from 'node:fs';
import { bootstrapGame, bootstrapMatches } from '/workspace/sketch-rts-portrait-endgame-control/src/ai/bootstrap_1/benchmark.ts';
import { snapshotGame } from '/workspace/sketch-rts-portrait-endgame-control/src/shared/sim.ts';
const root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const match = bootstrapMatches('bootstrap_1-development', ['sapphireArchipelago'], 144000, false)
  .find(m => m.subject === 'v9_archer' && m.agents.p0!.race === 'grove' && m.side === 0
    && Object.values(m.agents).slice(1).map(a => a.version).join('+') === 'v5')!;
const game = bootstrapGame(match), snapshot = snapshotGame(game);
const manifest = JSON.parse(readFileSync('/workspace/sketch-rts-portrait-endgame-control/docs/engineering/bootstrap_1/frozen-policy.json', 'utf8'));
const initial = Object.fromEntries(Object.keys(match.agents).map(owner => [owner, {
  gold: game.players[owner]!.gold, supplyUsed: game.players[owner]!.supplyUsed,
  supplyCap: game.players[owner]!.supplyCap, units: game.units.filter(unit => unit.owner === owner).map(({kind}) => kind),
}]));
if (game.tick !== 0 || manifest.rulesVersion !== 2 || Object.values(initial).some(s => s.gold !== 500 || s.supplyUsed !== 3 || s.supplyCap !== 8)) throw new Error('Ordinary opening preflight failed');
writeFileSync(root + '/archer-portrait-ordinary-opening.json', JSON.stringify({
  classification: 'Deterministic reconstruction of the exact standard bootstrapGame opening used by the ordinary run. No commands, world edits or memory edits.', match, initial,
  rulesVersion: manifest.rulesVersion, frozenRevision: manifest.revision, snapshot, nextId: game.nextId,
}));
console.log({tick: game.tick, initial});
