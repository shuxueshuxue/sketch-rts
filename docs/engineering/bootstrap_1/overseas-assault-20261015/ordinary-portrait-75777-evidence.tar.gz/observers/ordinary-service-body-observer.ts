import{readFileSync,writeFileSync}from'node:fs';
import{connectedSurfacePath}from'/workspace/sketch-rts-service-yaw-control/src/shared/connected-decks.ts';
import{deckWalkPathExists,deckStaticPathExists,deckPlacement,deckPointFits,canBoard}from'/workspace/sketch-rts-service-yaw-control/src/shared/decks.ts';
import{localToWorld,worldToLocal,shipProfile}from'/workspace/sketch-rts-service-yaw-control/src/shared/ship-geometry.ts';
import{capsuleClearsCircles}from'/workspace/sketch-rts-service-yaw-control/src/shared/navigation-math.ts';
import{clearTransferLanes}from'/workspace/sketch-rts-service-yaw-control/src/ai/policy/transfer-lanes.ts';
const input=process.argv[2]??'/tmp/bootstrap-service-yaw-candidate/public-normal-planner-final.json',d=JSON.parse(readFileSync(input,'utf8')),s=d.snapshot,p=s.units.find((u:any)=>u.id==='unit-p0-worker-1833'),a=s.units.find((u:any)=>u.id==='unit-p0-warship-1064'),b=s.units.find((u:any)=>u.id==='unit-p0-warship-1127'),crew=s.units.filter((u:any)=>u.deck&&[a.id,b.id].includes(u.deck.shipId)&&u.id!==p.id),priest=crew.find((u:any)=>u.kind==='priest');
const exactGoal=localToWorld(b,p.order.deckPoint),cases=[];
for(let mask=0;mask<(1<<crew.length);mask++){
 const excluded=crew.filter((_:any,i:number)=>!!(mask&(1<<i))).map((u:any)=>u.id),units=s.units.filter((u:any)=>!excluded.includes(u.id));
 cases.push({excluded,workerToCenter:connectedSurfacePath(p,b,units,s.map),workerToActualDeckPoint:connectedSurfacePath(p,exactGoal,units,s.map),priestToIssuedGoal:deckWalkPathExists(a,priest,priest.order.deckPoint,units)});
}
const ideal=connectedSurfacePath(p,b,s.units.filter((u:any)=>!crew.some((v:any)=>v.id===u.id)),s.map);
const blocks=(body:any)=>ideal?.points.slice(1).some((point:any,i:number)=>!capsuleClearsCircles(ideal.points[i]!,point,p.radius+1,[body]));
const profile=shipProfile(a)!,priestYields:any[]=[],archerYields:any[]=[],archerLiveMoves:any[]=[],otherDeckYields:any[]=[],archer=crew.find((u:any)=>u.kind==='archer');
for(let y=-profile.beam/2;y<=profile.beam/2;y+=4)for(let x=-profile.length/2;x<=profile.length/2;x+=4){
 const point={x,y};
 if(deckPointFits(a,priest,point,s.units)&&!blocks({...priest,...localToWorld(a,point)})&&deckWalkPathExists(a,priest,point,s.units))priestYields.push(point);
 if(!deckPointFits(a,archer,point,s.units)||!deckWalkPathExists(a,archer,point,s.units))continue;
 archerLiveMoves.push(point);
 const moved={...archer,...localToWorld(a,point),deck:{shipId:a.id,...point}},units=s.units.map((u:any)=>u.id===archer.id?moved:u);
 if(deckWalkPathExists(a,priest,priest.order.deckPoint,units))archerYields.push(point);
}
for(const troop of[archer,priest])for(let y=-profile.beam/2;y<=profile.beam/2;y+=4)for(let x=-profile.length/2;x<=profile.length/2;x+=4){
 const point={x,y},world=localToWorld(b,point);
 if(!deckPointFits(b,troop,point,s.units)||!connectedSurfacePath(troop,world,s.units,s.map)?.complete)continue;
 const moved={...troop,...world,deck:{shipId:b.id,...point}},units=s.units.map((u:any)=>u.id===troop.id?moved:u);
 otherDeckYields.push({id:troop.id,point,world,workerPath:connectedSurfacePath(p,b,units,s.map)});
}
priestYields.sort((q:any,r:any)=>Math.hypot(q.x-priest.deck.x,q.y-priest.deck.y)-Math.hypot(r.x-priest.deck.x,r.y-priest.deck.y));
archerYields.sort((q:any,r:any)=>Math.hypot(q.x-archer.deck.x,q.y-archer.deck.y)-Math.hypot(r.x-archer.deck.x,r.y-archer.deck.y));
function findYield(troop:any,units:any[]){
 for(const ship of[a,b].sort((q:any,r:any)=>Number(r.id===troop.deck.shipId)-Number(q.id===troop.deck.shipId))){
  if(ship.id!==troop.deck.shipId&&!canBoard(ship,troop,units))continue;
  const profile=shipProfile(ship)!,clear=(point:any)=>deckPointFits(ship,troop,point,units)&&!blocks({...troop,...localToWorld(ship,point)});
  const reachable=(point:any)=>ship.id===troop.deck.shipId?deckWalkPathExists(ship,troop,point,units):connectedSurfacePath(troop,localToWorld(ship,point),units,s.map)?.complete;
  const saved=troop.order.type==='move'&&(troop.order.deckShipId??troop.deck.shipId)===ship.id?worldToLocal(ship,troop.order):undefined;
  if(saved&&clear(saved)&&reachable(saved))return{shipId:ship.id,point:saved};
  const candidates=[] as any[];
  for(let y=-profile.beam/2;y<=profile.beam/2;y+=4)for(let x=-profile.length/2;x<=profile.length/2;x+=4)if(clear({x,y}))candidates.push({x,y});
  const point=candidates.sort((q:any,r:any)=>Math.hypot(localToWorld(ship,q).x-troop.x,localToWorld(ship,q).y-troop.y)-Math.hypot(localToWorld(ship,r).x-troop.x,localToWorld(ship,r).y-troop.y)).find(reachable);
  if(point)return{shipId:ship.id,point};
 }
}
const nativeBackoffQueries=[];
for(const preferred of[{x:0,y:0},{x:profile.length/4,y:0},{x:-profile.length/4,y:0}]){
 const retreat=deckPlacement(a,p,s.units,preferred);if(!retreat){nativeBackoffQueries.push({preferred,retreat});continue;}
 const at=localToWorld(a,retreat),distance=Math.hypot(at.x-p.x,at.y-p.y),path=connectedSurfacePath(p,at,s.units,s.map),backed={...p,...at,deck:{shipId:a.id,...retreat}},units=s.units.map((u:any)=>u.id===p.id?backed:u);
 const yieldAlongRetreat=[0,.25,.5,.625,.75,1].map(fraction=>{const point={x:p.deck.x+(retreat.x-p.deck.x)*fraction,y:p.deck.y+(retreat.y-p.deck.y)*fraction},world=localToWorld(a,point),hypo={...p,...world,deck:{shipId:a.id,...point}},replaced=s.units.map((u:any)=>u.id===p.id?hypo:u);return{fraction,moved:distance*fraction,yield:findYield(priest,replaced)};});
 nativeBackoffQueries.push({preferred,retreat,distance,path,afterRetreatYield:findYield(priest,units),yieldAlongRetreat});
}
const out={nativeBackoffQueries,idealWorkerRoute:ideal,archerLiveMoves,otherDeckYields:otherDeckYields.map(q=>({...q,blocksOriginalIdealWorkerRoute:blocks({...crew.find((u:any)=>u.id===q.id),...q.world})})),priestLiveReachableYieldPoints:priestYields,archerLiveReachablePointsReleasingPriest:archerYields,classification:'Read-only pure queries on derived yaw-candidate state; no extra simulation or command execution',input,tick:s.tick,exactGoal,crew,worker:p,profiles:{source:shipProfile(a),target:shipProfile(b)},priestIssuedGoalStatic:deckStaticPathExists(a,priest,priest.order.deckPoint),priestIssuedGoalBodyClear:deckPointFits(a,priest,priest.order.deckPoint,s.units),actualClearTransferCommands:clearTransferLanes(s,'p0'),cases};
writeFileSync(`/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015/archer-portrait-ordinary-service-body-observer${process.argv[3]?'-'+process.argv[3]:''}.json`,JSON.stringify(out,null,2));console.log(JSON.stringify({archerLiveMoves:archerLiveMoves.length,otherDeckYields:otherDeckYields.slice(0,4),priestYields:priestYields.slice(0,8),archerYields:archerYields.slice(0,8),priest:priest.id,goal:priest.order.deckPoint,static:out.priestIssuedGoalStatic,bodyClear:out.priestIssuedGoalBodyClear,commands:out.actualClearTransferCommands,cases},null,2));
