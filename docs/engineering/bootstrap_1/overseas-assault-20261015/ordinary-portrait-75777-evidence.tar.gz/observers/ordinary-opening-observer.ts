import {readFileSync,writeFileSync}from'node:fs';
import {createHash}from'node:crypto';
import {walkingDistance,sameGround,isOpenGround}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/terrain.ts';
import {clearBoardingBerth,BOARDING_GAP}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/naval.ts';
import {hullFits}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/ship-navigation.ts';
import {distanceToHull}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/ship-geometry.ts';
import {shipPassengers}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/ship-geometry.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',file=root+'/archer-portrait-ordinary.json';
const report=JSON.parse(readFileSync(file,'utf8')),samples:any[]=[];
for(const row of report.rows){
 const path=root+`/archer-portrait-ordinary.json.frames/${row.tick}.json`,raw=readFileSync(path),frame=JSON.parse(raw.toString()),s=frame.snapshot,boat=s.units.find((u:any)=>u.id==='unit-p0-transport-1046');
 if(!boat)continue;
 const units=s.units.filter((u:any)=>u.owner==='p0'),memory=row.players.p0.policy,boarders=units.filter((u:any)=>u.order.type==='board'&&u.order.transportId===boat.id),berth=boarders[0]?.order.berth;
 const clear=berth?clearBoardingBerth(s.map,boarders[0],boat,berth,s.units):undefined;
 const route=boat.sailing?.route,end=route?.end;
 const passengers=shipPassengers(s.units,boat);
 samples.push({tick:row.tick,worldSHA256:createHash('sha256').update(raw).digest('hex'),nextId:frame.nextId,boat:{x:boat.x,y:boat.y,hp:boat.hp,heading:boat.sailing?.heading,speed:boat.sailing?.speed,order:boat.order,passengers:passengers.map((u:any)=>u.id),route:route?{goalX:route.goalX,goalY:route.goalY,partial:route.partial,end,points:route.points?.length,pointsFirst:route.points?.[0],pointsLast:route.points?.at(-1)}:undefined},boarders:boarders.map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,landRoadToBerthShore:berth?.shore?walkingDistance(s.map,u,berth.shore):undefined})),clearBerth:clear?{...clear,hullFits:hullFits(s.map,boat,{...clear,heading:clear.heading??boat.sailing.heading}),hullGapAtArrival:distanceToHull({...boat,...clear,sailing:{...boat.sailing,heading:clear.heading??boat.sailing.heading}},clear.shore??boarders[0]),requiredGap:boarders[0].radius+BOARDING_GAP}:undefined,seaTerrainRoadToBerth:clear?walkingDistance(s.map,boat,clear,'sea'):undefined,partialEndSeaTerrainRoadToBerth:clear&&end?walkingDistance(s.map,end,clear,'sea'):undefined,mission:memory.naval?.ferries?.[boat.id],economy:{gold:s.players.p0.gold,workforce:units.filter((u:any)=>u.kind==='worker').map((u:any)=>({id:u.id,x:u.x,y:u.y,order:u.order})),mines:s.resources.map((m:any)=>({id:m.id,amount:m.amount}))},allPolicyMemories:Object.fromEntries(Object.entries(row.players).map(([owner,p]:[string,any])=>[owner,p.policy]))});
}
const out={classification:'read-only ordinary-opening observation; source fixed before opening; no world/memory/commands changed, no extra simulation',setup:report.setup,observedResult:report.result,notes:['walkingDistance sea is terrain flow cost for a point; it is a topology-aware lower bound/reference, not a full-hull route or arrival proof','sampled displacement omits between-sample motion; route end and physical pose are read from the native live saved game','all policy memories are exact report row copies; frame hashes identify full worlds+nextId'],samples};
writeFileSync(root+'/archer-portrait-ordinary-observer.json',JSON.stringify(out,null,2));
console.log(JSON.stringify(samples.map(s=>({tick:s.tick,xy:[Math.round(s.boat.x),Math.round(s.boat.y)],crew:s.boat.passengers.length,berth:s.clearBerth,sea:s.seaTerrainRoadToBerth,endSea:s.partialEndSeaTerrainRoadToBerth,partial:s.boat.route?.partial})),null,2));
