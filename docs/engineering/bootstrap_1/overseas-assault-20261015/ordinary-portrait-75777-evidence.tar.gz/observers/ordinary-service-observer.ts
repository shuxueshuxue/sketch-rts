import{readFileSync,writeFileSync}from'node:fs';
import{connectedSurfacePath,decksCanTransfer,decksSupportCrossing,decksAllowCrossing}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/connected-decks.ts';
import{hullGap}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/ship-geometry.ts';
import{canBoard}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/decks.ts';
import{shipNeedsRepair}from'/workspace/sketch-rts-portrait-endgame-control/src/shared/ship-equipment.ts';
import{navalServices}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/policy/naval-services.ts';
import{clearTransferLanes}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/policy/transfer-lanes.ts';
import{bootstrapPolicyContext}from'/workspace/sketch-rts-portrait-endgame-control/src/ai/bootstrap_1/policy.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',report=JSON.parse(readFileSync(root+'/archer-portrait-ordinary.json','utf8')),samples=[];
for(const tick of[30000,31200,32400,33600,34800,36000,37200,38400,39600]){
 const row=report.rows.find((r:any)=>r.tick===tick);if(!row)continue;
 const {snapshot:s}=JSON.parse(readFileSync(root+`/archer-portrait-ordinary.json.frames/${tick}.json`,'utf8')),p=s.units.find((u:any)=>u.id==='unit-p0-worker-1833'),a=s.units.find((u:any)=>u.id==='unit-p0-warship-1064'),b=s.units.find((u:any)=>u.id==='unit-p0-warship-1127');
 const without=s.units.filter((u:any)=>u.id===p.id||!u.deck||![a.id,b.id].includes(u.deck.shipId));
 const options=bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(row.players.p0.policy),teams:s.teams}),services=navalServices(s,'p0',options);
 samples.push({tick,passenger:p,source:a,target:b,needsRepair:shipNeedsRepair(s,b),hullGap:hullGap(a,b),supportedSeam:decksSupportCrossing(a,b,p),allowCrossing:decksAllowCrossing(a,b,p),zeroYawPureQuery:{canTransfer:decksCanTransfer({...a,sailing:{...a.sailing,yawRate:0}},b,p),connected:connectedSurfacePath(p,b,s.units.map((u:any)=>u.id===a.id?{...a,sailing:{...a.sailing,yawRate:0}}:u),s.map)},canBoard:canBoard(b,p,s.units),decksCanTransfer:decksCanTransfer(a,b,p),actualConnectedPath:connectedSurfacePath(p,b,s.units,s.map),emptyConnectedPath:connectedSurfacePath(p,b,without,s.map),services:{commands:services.commands,reserved:[...services.reserved]},clearLanes:clearTransferLanes(s,'p0')});
}
writeFileSync(root+'/archer-portrait-ordinary-service-observer.json',JSON.stringify({classification:'Pure recorded-state query on clones; no simulation or source edit',samples},null,2));console.log(JSON.stringify(samples.map(s=>({tick:s.tick,passenger:[s.passenger.x,s.passenger.y,s.passenger.order],needsRepair:s.needsRepair,canBoard:s.canBoard,decksCanTransfer:s.decksCanTransfer,actual:s.actualConnectedPath,empty:s.emptyConnectedPath,gap:s.hullGap,supported:s.supportedSeam,zeroYaw:s.zeroYawPureQuery,service:s.services,lanes:s.clearLanes})),null,2));
