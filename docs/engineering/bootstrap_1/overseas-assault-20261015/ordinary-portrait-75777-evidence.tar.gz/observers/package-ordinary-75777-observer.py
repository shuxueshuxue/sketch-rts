import hashlib, io, json, pathlib, shutil, subprocess, tarfile, tempfile
from datetime import datetime, timezone
root = pathlib.Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015')
live = pathlib.Path('/workspace/sketch-rts-portrait-endgame-control')
archive = root / 'ordinary-portrait-75777-evidence.tar.gz'
assert not archive.exists(), 'Do not overwrite a sealed evidence archive'
staging = pathlib.Path(tempfile.mkdtemp(prefix='bootstrap-ordinary-75777-evidence-', dir='/tmp'))
files = {}
def add_bytes(name, data):
    assert name and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    if name in files:
        assert files[name] == hashlib.sha256(data).hexdigest()
        return
    path = staging / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    files[name] = hashlib.sha256(data).hexdigest()
def add(name, path): add_bytes(name, pathlib.Path(path).read_bytes())
report = json.loads((root/'archer-portrait-ordinary.json').read_text())
assert report['result'] == {'tick':75777,'winner':'p0','completed':True}
assert len(report['rows']) == 64
source = json.loads((root/'archer-portrait-ordinary-runtime-source.json').read_text())
assert len(source['runtimeHashes']) == 834
for name, sha in source['runtimeHashes'].items():
    data = (live/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == sha, name
    add_bytes('source/live/'+name, data)
# Also preserve supporting fixture/data files that the TS-only prelaunch capsule
# did not count. These are separately listed by SHA in the archive INDEX.
extra_data = 0
for tree in ['src/ai','src/shared','src/sdk']:
    for path in sorted((live/tree).rglob('*')):
        if path.is_file() and path.suffix not in ('.ts','.tsx'):
            add('source/live/'+str(path.relative_to(live)), path)
            extra_data += 1
for name in ['package.json','package-lock.json','tsconfig.json']:
    add('source/live/'+name, live/name)
manifest_path = live/'docs/engineering/bootstrap_1/frozen-policy.json'
manifest_bytes = manifest_path.read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == source['frozenManifestSha256']
manifest = json.loads(manifest_bytes)
assert manifest['rulesVersion'] == 2 and manifest['revision'] == 'd1ae110f2edd99f9c7d899ed61557891ab587639'
add_bytes('source/frozen-policy.json',manifest_bytes)
# Preserve the real frozen tree used by bootstrap_1-planner's git archive,
# rather than assuming the live AI implements the unchanged opponents.
frozen_tar = subprocess.check_output(['git','archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared'],cwd=live)
frozen_members = {}
with tarfile.open(fileobj=io.BytesIO(frozen_tar),mode='r:') as tf:
    for member in tf:
        if not member.isfile(): continue
        data = tf.extractfile(member).read()
        frozen_members[member.name] = data
        add_bytes('source/frozen/'+member.name,data)
for name, sha in manifest['files'].items():
    assert hashlib.sha256(frozen_members[name]).hexdigest() == sha, name
add('ordinary/report.json',root/'archer-portrait-ordinary.json')
add('ordinary/log.txt',root/'archer-portrait-ordinary.log')
add('ordinary/standard-opening-fullworld-and-preflight.json',root/'archer-portrait-ordinary-opening.json')
add('ordinary/prelaunch-source-capsule.json',root/'archer-portrait-ordinary-runtime-source.json')
add('ordinary/terminal-postflight.json',root/'archer-portrait-ordinary-terminal-observer.json')
for row in report['rows']:
    tick = row['tick']
    add(f'ordinary/frames/{tick}.json',root/f'archer-portrait-ordinary.json.frames/{tick}.json')
    add_bytes(f'ordinary/memories/{tick}.json',json.dumps({owner:player['policy'] for owner,player in row['players'].items()},sort_keys=True,separators=(',',':')).encode()+b'\n')
# Observer files are queries and renderers, not extra game controllers.
observer_files = [
 'portrait-ordinary-opening-preflight.ts','ordinary-opening-observer.ts','ordinary-budget-observer.ts',
 'ordinary-service-observer.ts','ordinary-cohort-observer.ts','ordinary-service-body-observer.ts',
 'render-ordinary-observer.ts','render-budget-observer.ts','package-ordinary-75777-observer.py',
 'archer-portrait-ordinary-observer.json','archer-portrait-ordinary-budget-observer.json',
 'archer-portrait-ordinary-service-observer.json','archer-portrait-ordinary-service-body-observer.json',
 'archer-portrait-ordinary-service-body-observer-v2-39900.json','archer-portrait-ordinary-cohort-observer.json',
 'archer-portrait-ordinary-cohort-observer-follow.json','ordinary-opening-observer-notes.md',
 'archer-saving-budget-damage-observer.json']
for name in observer_files: add('observers/'+name,root/name)
for name in [
 'archer-portrait-ordinary-22800-north-pickup.png','archer-portrait-ordinary-30000-home.png',
 'archer-portrait-ordinary-42000-world-overview.png','archer-portrait-ordinary-72000-world-overview.png',
 'archer-portrait-ordinary-72000-sailing-duel.png','archer-portrait-ordinary-72000-enemy.png',
 'archer-portrait-ordinary-75777-world-overview.png','archer-portrait-ordinary-75777-enemy.png',
 'archer-saving-budget-observer-29400.png','archer-saving-budget-observer-30000.png']:
    add('client-images/'+name,root/name)
# These are explicitly separate earlier changed-code diagnostics. Do not apply
# the ordinary run's source/score to them or silently upgrade a partial run.
for label,directory in [
 ('yaw-only-after39600','/tmp/bootstrap-service-yaw-candidate'),
 ('yaw-live-yield-v2-after39600','/tmp/bootstrap-service-yaw-live-yield-v2-from39600')]:
    for name in ['provenance.json','public-normal-planner.json','public-normal-planner-final.json']:
        add('diagnostics/'+label+'/'+name,pathlib.Path(directory)/name)
add('diagnostics/budget-after20400/prelaunch-source-capsule.json',root/'naval-saving-budget-runtime-source.json')
for tick in [28800,29400,30000,30600,31200,32400,33000]:
    add(f'diagnostics/budget-after20400/frames/{tick}.json',root/f'archer-saving-budget.json.frames/{tick}.json')
metadata = {
 'classification':'Natural ordinary tick0 victory evidence; independent observations and explicitly separate changed-code diagnostics.',
 'sealedAtUtc':datetime.now(timezone.utc).isoformat(),
 'ordinaryResult':report['result'],'ordinarySetup':report['setup'],
 'normalOpening':{'p0':{'gold':500,'supplyUsed':3,'supplyCap':8},'p1':{'gold':500,'supplyUsed':3,'supplyCap':8}},
 'initialWitness':'Deterministic reconstruction of exact standard bootstrapGame opening, including full snapshot and nextId. It is labelled reconstruction, not falsely claimed an in-process prelaunch frame capture.',
 'liveSourceBase':source['baseCommit'],'runtimeFilesVerifiedPrelaunchToTerminal':834,
 'additionalSupportingDataFiles':extra_data,'frozenSourceFilesIncluded':len(frozen_members),'frozenManifestEntriesVerified':len(manifest['files']),
 'sourceCapsuleBeforeAfterTrackedDiffEqual':subprocess.check_output(['git','diff'],cwd=live).decode()==source['trackedDiff'],
 'ordinaryRows':64,'ordinaryFullFrames':64,'ordinaryMemoryPairs':64,
 'nativeWinBoundary':{'winner':'p0','endedAtTick':75777,'enemyBuildings':0,'enemyUnits':3,'enemyUnitsNotWiped':True},
 'ownLosses':{'total':2,'neutralKilledCutter1174':1,'enemyKilledWorker1841':1,'individualLastShotNotCaptured':True},
 'knownUnresolved':'Warships1064/1127 still reserved by the real engineer1833 service task at the ordinary terminal; yaw/live-yield fixes are separate later candidates.',
 'diagnosticBoundary':'Budget evidence is a changed-code full-AI resume at20400, not a new ordinary opening. Service evidence is native short diagnostics from39600, not a match score. Service inputs/provenance are included; observer did not capture a prelaunch full source for those temporary changing candidate worktrees and does not claim one. Their source lineage and later independent review remain separate from this normal victory.',
 'scoreLimits':'One v9_archer/Grove side0 official sapphireArchipelago development-seed victory versus frozenv5/Ember only; no three-route, v7/v8, paired-opponent or unseen-seed acceptance claimed.',
 'recoveryGap':'Original broken container uncommitted changes remain unrecovered; this archive does not purport to copy them.',
 'oldSeals':'Existing earlier inProgress evidence archives are not overwritten or reclassified by this archive.'}
add_bytes('EVIDENCE.json',json.dumps(metadata,indent=2).encode()+b'\n')
index = {'algorithm':'SHA-256','scope':'Every regular payload member other than INDEX.json itself; index digest is also stored in the external verification file.','files':dict(sorted(files.items()))}
index_bytes=json.dumps(index,indent=2).encode()+b'\n'
(staging/'INDEX.json').write_bytes(index_bytes)
with tarfile.open(archive,mode='w:gz',compresslevel=6) as tf:
    for name in sorted([*files,'INDEX.json']):
        data=(staging/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
        tf.addfile(info,io.BytesIO(data))
verified=0
with tarfile.open(archive,mode='r:gz') as tf:
    actual_index=json.loads(tf.extractfile('INDEX.json').read())
    names={m.name for m in tf.getmembers()if m.isfile()}
    assert names==set(actual_index['files'])|{'INDEX.json'}
    for name,sha in actual_index['files'].items():
        assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==sha,name
        verified+=1
verification={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'indexSha256':hashlib.sha256(index_bytes).hexdigest(),'payloadMembersVerified':verified,'ordinaryFrames':64,'ordinaryMemoryPairs':64,'liveRuntimeFilesVerified':834,'frozenManifestFilesVerified':len(manifest['files']),'noExistingArchiveOverwritten':True,'stagingDirectory':str(staging)}
(root/'ordinary-portrait-75777-evidence.verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(root/'ordinary-portrait-75777-evidence.sha256').write_text(verification['sha256']+'  '+archive.name+'\n')
print(json.dumps(verification,indent=2))
