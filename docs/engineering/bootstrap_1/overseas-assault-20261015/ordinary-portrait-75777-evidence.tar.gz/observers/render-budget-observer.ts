import{createCanvas}from'@napi-rs/canvas';
import{readFileSync,writeFileSync}from'node:fs';
import{installHeadlessCanvas}from'/workspace/sketch-rts-budget-control/src/recorder/record.ts';
import{drawWorld}from'/workspace/sketch-rts-budget-control/src/client/world-renderer.ts';
import{UnitFacingTracker}from'/workspace/sketch-rts-budget-control/src/client/unit-facing.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';installHeadlessCanvas();
for(const tick of[29400,30000]){const{snapshot}=JSON.parse(readFileSync(`${root}/archer-saving-budget.json.frames/${tick}.json`,'utf8')),canvas=createCanvas(1500,1100);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:{x:1500,y:5500,width:1500,height:1100,zoom:.7},now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(`${root}/archer-saving-budget-observer-${tick}.png`,canvas.toBuffer('image/png'));}
