import { ITEM_DEFS } from "./equipment";
import { describe, expect, it } from "vitest";
import {
  assertCreateRoomInput,
  parseGameSetupOptions,
  parseResetRoomRequest,
  parseSlotPatch,
  parseSlotCountsRequest,
  roomCreateInputFromRequest,
} from "./room-schema";
import { MAP_IDS } from "./map-ids";
import { MAP_SCENARIOS } from "./map";

describe("shared room setup schema", () => {
  it("normalizes create-room requests before room helpers consume them", () => {
    const request = { host: { id: "host", name: "Host" }, mapId: "bareDuel", visibility: "private", humanCount: 1, aiCount: 1 };

    expect(roomCreateInputFromRequest(request, "room-generated")).toEqual({
      id: "room-generated",
      host: { id: "host", name: "Host" },
      mapId: "bareDuel",
      visibility: "private",
      humanCount: 1,
      aiCount: 1,
    });
    expect(assertCreateRoomInput({ ...request, id: "room-static" })).toMatchObject({ id: "room-static", mapId: "bareDuel" });
    expect(() => assertCreateRoomInput({ ...request, id: "room-bad", humanCount: 0 })).toThrow("Malformed room create input");
    expect(() => assertCreateRoomInput({ ...request, id: "room-overflow", humanCount: 30 })).toThrow("Malformed room create input");
  });

  it("parses slot, slot-count, and reset payloads through one runtime contract", () => {
    expect(parseSlotPatch({ controller: "ai", team: "south", race: "ember", ready: false, ignored: true })).toEqual({
      controller: "ai",
      team: "south",
      race: "ember",
      ready: false,
    });
    expect(parseSlotPatch({ controller: "bot" })).toBeUndefined();
    expect(parseSlotPatch({ aiVersion: "v9_knight" })).toEqual({ aiVersion: "v9_knight" });
    for (const aiVersion of ["v5", "v7", "v8"]) expect(parseSlotPatch({ aiVersion })).toBeUndefined();
    expect(parseSlotPatch({ aiVersion: "v6" })).toBeUndefined();
    expect(parseSlotCountsRequest({ humanCount: 2, aiCount: 3 })).toEqual({ humanCount: 2, aiCount: 3 });
    expect(parseSlotCountsRequest({ humanCount: 0, aiCount: 3 })).toBeUndefined();
    expect(parseSlotCountsRequest({ humanCount: 30, aiCount: 29 })).toBeUndefined();

    expect(parseResetRoomRequest({ mapId: "bareDuel", options: { aiPlayers: ["enemy"], races: { player: "grove", enemy: "ember" } } })).toEqual({
      mapId: "bareDuel",
      options: { aiPlayers: ["enemy"], races: { player: "grove", enemy: "ember" } },
    });
    expect(parseResetRoomRequest({ mapId: "missing", options: {} })).toBeUndefined();
    // A generated layout goes through as asked, its idea included (see @@@generated-ideas); an idea there is none of is not.
    expect(parseResetRoomRequest({ mapId: "ladder", options: { layout: { seed: "isle2-f", idea: "northIsles" } } })).toEqual({ mapId: "ladder", options: { layout: { seed: "isle2-f", idea: "northIsles" } } });
    expect(parseResetRoomRequest({ mapId: "ladder", options: { layout: { seed: "isle2-f", idea: "archipelago" } } })).toBeUndefined();
    expect(parseResetRoomRequest({ mapId: "ladder", options: { layout: { seed: "isle2-f", kind: "square" } } })).toBeUndefined();
    expect(parseResetRoomRequest({ mapId: "ladder", options: { layout: { seed: "pool-r2-1", kind: "ring", size: 4096 } } })).toEqual({ mapId: "ladder", options: { layout: { seed: "pool-r2-1", kind: "ring", size: 4096 } } });
    expect(parseResetRoomRequest({ mapId: "ladder", options: { layout: { seed: "pool-r2-1", size: "big" } } })).toBeUndefined();
  });

  it("validates scenario seeds in the same place as reset options", () => {
    expect(
      parseGameSetupOptions({
        scenario: {
          replaceDefaultUnits: true,
          addUnits: [{ id: "unit-a", owner: "neutral", kind: "wildling", x: 10, y: 20, hp: 30 }],
          addBuildings: [{ id: "tower-a", owner: "player", kind: "defenseTower", x: 40, y: 50, hp: 90, maxHp: 120, complete: true }],
        },
      }),
    ).toEqual({
      scenario: {
        replaceDefaultUnits: true,
        addUnits: [{ id: "unit-a", owner: "neutral", kind: "wildling", x: 10, y: 20, hp: 30 }],
        addBuildings: [{ id: "tower-a", owner: "player", kind: "defenseTower", x: 40, y: 50, hp: 90, maxHp: 120, complete: true }],
      },
    });
    expect(parseGameSetupOptions({ scenario: { addUnits: [{ id: "unit-a", owner: "neutral", kind: "wildling", x: 10, y: 20, hp: 9999 }] } })).toBeUndefined();
    expect(parseGameSetupOptions({ scenario: { addBuildings: [{ id: "tower-a", owner: "player", kind: "defenseTower", x: 40, y: 50, hp: 9999 }] } })).toBeUndefined();
  });

  it("uses the same map id set as the visible room setup catalog", () => {
    expect(MAP_SCENARIOS.map((scenario) => scenario.id).sort()).toEqual([...MAP_IDS].sort());
  });
});


it('validates portable seat settings and strips live identities before creation', () => {
  const input = { id: 'shared', host: { id: 'host', name: 'Host' }, humanCount: 1, aiCount: 1, layoutSeed: 'world',
    seatSetup: [
      { controller: 'human', team: 'ffa', race: 'grove', userId: 'somebody', ready: false },
      { controller: 'ai', team: 'ffa', race: 'ember', aiVersion: 'v9_knight', userId: 'injected' },
    ] };
  const room = assertCreateRoomInput(input);
  expect(room.layoutSeed).toBe('world');
  expect(room.seatSetup).toEqual([{ controller: 'human', team: 'ffa', race: 'grove' }, { controller: 'ai', team: 'ffa', race: 'ember', aiVersion: 'v9_knight' }]);
  for (const patch of [{ layoutSeed: '' }, { seatSetup: input.seatSetup.slice(0, 1) }, { humanCount: 2, aiCount: 0 }, { seatSetup: [{ ...input.seatSetup[0], controller: 'ai' }, input.seatSetup[1]] }]) {
    expect(() => assertCreateRoomInput({ ...input, ...patch })).toThrow('Malformed room create input');
  }
});

// SDK scenarios must accept the same equipment catalogue as shops and live play.
it("accepts every current item seed and rejects unknown item names", () => {
  for (const kind of Object.keys(ITEM_DEFS)) {
    const request = { mapId: "bareDuel", options: { scenario: { addItems: [{ id: `seed-${kind}`, kind, x: 1200, y: 960, carrierId: "soldier", cooldownRemaining: 0 }] } } };
    expect(parseResetRoomRequest(request), kind).toEqual(request);
  }
  expect(parseResetRoomRequest({ mapId: "bareDuel", options: { scenario: { addItems: [{ id: "bad", kind: "unknownItem", x: 0, y: 0, cooldownRemaining: 0 }] } } })).toBeUndefined();
});
