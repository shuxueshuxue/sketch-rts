# Actual ordinary service reroute (2026-10-15)

This is a local p0 full-planner/native continuation from actual ordinary28800. The opponent retains its restored native orders; it is not replanned here. It is not a complete-match victory, normal0-opening result, or final bootstrap/generalization acceptance. The original broken-container uncommitted-workspace recovery gap remains. No root/main/performance tree or running original source was modified by this work.

## Original actual evidence

The fixed budget-only ordinary source is97ee2df9, sourceRoot sketch-rts-budget-ordinary-97ee-control. Its manifest has792 runtime hashes; all are verified unchanged. Normal original28800 and41612 leave worker1713 on sourcewarship1127 trying to board cutter1174, with horseArcher2297 physically sealing the connected deck route. Both ships are still, seam and canTransfer are true; removing only the horse makes the worker path complete. Visual original/41612 PNG was actually viewed; it is a later original ordinary frame, not the start tick of the new continuation.

Final-root pure query shows why clearTransferLanes returned[]: all18 fitting horse positions on cutter intersect the one stored ideal path. Two of them are natively reachable and, after the horse stands there, the engineer can find a different complete actual route. The old ideal-path predicate discarded those legitimate possibilities.

## Final policy

The same deckYieldPoint selector ranks original-clear candidates first (including existing legal engineer retreat placements), then accepts another fitting/native-live-reachable position only if substituting that body in a local shadow unit list gives the actual engineer a complete native connectedSurfacePath. There is no separate movement/ownership/task layer or rule change. Old saved-yield, original source preference, closest positions and the existing three worker retreat candidates remain part of this one choice.

A crossing bystander can temporarily consume every valid receiving slot. In that interval native board legitimately cancels to idle if left active. The policy therefore preserves the same queued boarding task using the already-supported worker follow of its real source hull, inside the native follow-stop distance, or the existing move→queued follow→queued board retreat. Once actual capacity/path reopen, the public board resumes. No hull goal/mission or private simulation field is forced.

## Actual result

accepted/candidate-v4 starts28800 and completes28897. Horse publicly moves to cutter; engineer genuinely crosses and cutter HP97.9648907922973→126, shipNeedsRepair=false. Both hulls remain in the exact original pose until the engineer crosses. After that, released ships return to their normal plans while the deck engineer finishes native repair. Raw final.json contains the complete world,nextId,both memories, not only a summary. This short local fact does not prove a match win.

Original39600 and the independent yaw-only-derived41400 fixture both retain actual boarding/repair success. The41400 first public queue/positions remain the prior green maneuver and finish41515. Tests compare full commands/world/nextId/memory after JSON restore from the original input and from the actual worker-follow waiting state.

## Failed candidates retained

v1 accepts the alternate reachable horse position, but leaves engineer board active. Native canBoard temporarily becomesfalse at28813..28815, board cancels28814, service reservation releases and ships leave. The final28800→29700 state is still unrepaired. Every first45tick fullworld/nextId/memory is included.

v2 adds legal source-follow waiting and succeeds28800→28897, but regresses the older41400 actual crossing. v3 always tries the first available worker retreat before waiting; it still regresses41400 because it selects a newly replanned route before the proven old clear route available after a different existing retreat. Their source archives/logs are kept. Finalv4 ranks the original-clear corridor across the same direct/retreat placements before the alternate actual-road choice; this preserves the old result without weakening its completion assertion.

The failed v1/v2/v3 source manifests are explicitly postflight captures of unchanged source and do not claim prelaunch capture. Accepted final842-file source capsule was frozen before the final28800 replay; postflight checks all842 unchanged. Source is97ee plus the recorded root yaw/contact/live-yield/follow/wind overlays and this policy. No frozen tactic/manifest or rules2 constants are edited.

## Validation/deliverables

6 relevant suites,62 tests pass: new actual28800 and restore2; old39600/41400 service4; real deck-transfer3; crowded shore2; three-family ferry24; portrait berth27. tsc --noEmit and git diff --check pass. Newfixture pure-query test was red before the policy. Failed actual41400 checks were kept until fixed, not weakened.

increment.patch changes only transfer-lanes.ts, the new service-deck-reroute test and the actual28800 gz fixture. git apply --check passed against root without applying it. Portrait/yaw/contact source is a prior reviewed increment, not repeated in this patch.

The new image actual-changedcode-28897-home-service.png was rendered with this candidate's real drawWorld and actually viewed. It shows the engineer and horse on the cutter after repair. It is a changed-code local continuation image; the original41612 image is separately labelled and is not a same-clock before/after match comparison. Coastal ballista178800 remains a distinct unproven case. Full ordinary complete-match and unseen-seed/family validation remain root's next work.
