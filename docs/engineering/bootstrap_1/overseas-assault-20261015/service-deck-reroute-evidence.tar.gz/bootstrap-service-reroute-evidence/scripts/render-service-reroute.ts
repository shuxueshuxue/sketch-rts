import{createCanvas}from'@napi-rs/canvas';
import{readFileSync,writeFileSync}from'node:fs';
import{installHeadlessCanvas}from'/workspace/sketch-rts-service-reroute-control/src/recorder/record.ts';
import{drawWorld}from'/workspace/sketch-rts-service-reroute-control/src/client/world-renderer.ts';
import{UnitFacingTracker}from'/workspace/sketch-rts-service-reroute-control/src/client/unit-facing.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',tick=28897,{snapshot}=JSON.parse(readFileSync('/tmp/bootstrap-service-reroute-candidate-v4/final.json','utf8'));installHeadlessCanvas();
for(const [name,v]of Object.entries({'home-service':{x:7400,y:4000,width:1000,height:900,zoom:1.1},'home-muster':{x:6700,y:3000,width:1600,height:1200,zoom:.85},'southern-colony':{x:7200,y:5600,width:1600,height:1200,zoom:.8},'enemy-expansion':{x:3000,y:5700,width:1600,height:1200,zoom:.85},'enemy':{x:1500,y:5500,width:1600,height:1200,zoom:.7},'world-overview':{x:0,y:0,width:1600,height:1600,zoom:1600/Math.max(snapshot.map.width,snapshot.map.height)}})){
if(name!=='home-service')continue;const canvas=createCanvas(v.width,v.height);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:v,now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync('/tmp/bootstrap-service-reroute-evidence/actual-changedcode-28897-home-service.png',canvas.toBuffer('image/png'));}
