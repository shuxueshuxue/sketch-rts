# Current-berth public portraits: local mechanism evidence

This packet belongs to the isolated worktree `sketch-rts-unload-control` at
`93204ca4cec68f6c48c27690bc8f0fa12959a7b9` plus `candidate.patch`.
It changes only the existing ferry policy and a pure native-geometry query.
Rules version 2, the frozen manifest, native collision/turning/landing rules,
opponent resources/population, and mission intent are unchanged.

The original broken container's uncommitted modifications remain unavailable.
This packet does not claim to recover them.

## Source and result classification

`audit-evidence.tar.gz` preserves the prior read-only/raw-native audit, including
the original f267+v3 runtime manifest and original 90571/90586/90810/91110/91710/
92400 frames. Its SHA256 remains
`cd5e713ea555ab8edeac107a1cbd34a3d3c398f774ed97e405659d81dbcbe524`.
It retains the original-goal versus current-center whole-hull diagnostics;
these experiments were not replaced or relabelled as the new policy.

All three new test fixtures are explicitly labelled **manual public boat-only
derived worlds**, not ordinary openings or AI wins. The underlying fixed
original runtime is f267 plus v3 reinforcement changes, not 932. Ferry 3510's
actual remembered mission is already `return`; the manual run still directed
its hull to the enemy shore. The complete planner regression preserves that
return destination and never changes it into an assault to manufacture success.

`original-portrait-probe/` uses the fixed original f267+v3 runtime and direct
native public commands, preserving the existing helm and AI memory. It shows
that the existing public `unloadPassenger` API already unloads the seven crew
while a stationary hull rotates, so no engine fix or new helm command is needed.

`candidate-source.json` and `candidate-source.tar.gz` freeze 1277 source/config/
fixture files before the separate `candidate-probe.mts` launch. The launch
checks every listed file. The original v3 manifest's 803 runtime hashes also
matched at capture. The candidate probe is another **native-only mechanism
replay**, not a whole-policy game: it compares the exact same 92400 world for
45 ticks with no AI updates. The original existing unload leaves all seven
aboard; the query's seven public portraits land all seven immediately, preserve
the original ship order after every command, and retain their HP and island
through tick 92445. Each predicted point equals the native point immediately
before that command and the actual landing. An independent complete JSON
snapshot+nextId restoration repeats the complete command sequence and ends
with the identical full world and nextId. Memory remains byte-for-byte unchanged.

The parent is separately comparing complete AI continuations. Its 932 continuation
from original tick 99600 did not win by 120000; the old source won at 105314.
That difference cannot yet be attributed to this AI integration: the first
observed divergence is an enemy empty transport's native route at 99645, before
frozen-opponent commands diverge at 99705. This packet makes no complete-game,
ordinary-opening, victory, generalization, or bootstrap acceptance claim.

## Policy and verification

The query requires an existing native unload on the intended land component,
an owned exposed crew, and no hull translation; in-place turning is allowed.
It reuses actual `passengerLandingSpot` against local shadow landed bodies in
command order. It cannot prove later whole-crew completion. A failed radius is
reused only in that same shadow world while bodies can only be added; it is
never cached across worlds. Moving, empty, wrong-island, cabin/foreign crew,
and the real blocked 90571 pose produce no false landings.

The existing return/sailing ferry branches retain all cancellation, force,
and safety decisions. Only an already-executing exact destination and matching
avoidCombat flag can use portraits. A different destination/flag first receives
the original public unload. Actual or queued cross-deck boarding retains its
existing task: ferry portraits wait, because a preceding native board can change
the source helm and invalidate the snapshot geometry. The new double-ferry
counterexample failed for all three families before that guard and now passes
through the complete public command sequence.

Recorded checks:

- `portrait-policy-red.log`: the initial three-family ferry test failed against
  the original 932 policy, which emitted no portraits.
- `portrait-transfer-red.log`: all three double-ferry transfer cases failed
  against the initial portrait candidate, before the pending transfer guard.
- `portrait-query-green.log`: all 27 new focused cases pass, including three
  routes, exact destination/flag, missing-target cancellation, JSON command/output
  restoration, native 45-tick comparison, blockers, motion, ownership/cabin,
  failed-radius deduplication, and a changed-world query.
- `normal-ferry-regression.log`: 99 existing tests pass in shared native naval,
  ferry return/summons, ferry departure, and assault reinforcement. This run
  preceded only the final pending-transfer guard; the new 27-case run includes
  that guard. No wide matrix was run.
- `typecheck.log`: `tsc --noEmit` passes after the final guard.
- `git diff --check` passes.

To replay the separate candidate mechanism from the extracted repository source,
install/use its existing dependencies and run:

```sh
node_modules/.bin/tsx .playtest/unload-20261015/candidate-probe.mts
```

The probe writes the complete command list, per-command predicted/actual points,
original-final, after-public-commands, candidate-final, and restored-final worlds.
