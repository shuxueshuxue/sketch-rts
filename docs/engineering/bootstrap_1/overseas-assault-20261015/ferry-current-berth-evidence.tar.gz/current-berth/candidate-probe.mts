import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
import { createGame, restoreSnapshotIntoGame, snapshotGame, issuePlayerCommand, stepGame } from '../../src/shared/sim';
import { currentBerthLandings, passengerLandingSpot } from '../../src/shared/naval';
import { shipPassengers } from '../../src/shared/ship-geometry';
import { sameGround } from '../../src/shared/terrain';

const out = new URL('./candidate-probe/', import.meta.url); mkdirSync(out, { recursive: true });
const source = JSON.parse(readFileSync(new URL('./candidate-source.json', import.meta.url), 'utf8'));
for (const [path, hash] of Object.entries(source.files)) assert.equal(createHash('sha256').update(readFileSync(path)).digest('hex'), hash);
const fixture = readFileSync('src/ai/bootstrap_1/fixtures/ferry-manual-static-92400.json.gz');
const saved = JSON.parse(gunzipSync(fixture).toString());
const load = () => { const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId); return game; };
const original = load(), candidate = load(), restored = load(), id = 'unit-p0-carrier-3510', goal = { x: 2192, y: 6096 };
const ship = candidate.units.find(unit => unit.id === id)!, originalOrder = structuredClone(ship.order);
const initialCrew = shipPassengers(candidate.units, ship).map(unit => unit.id);
const memoryBefore = JSON.stringify(saved.memories), before = JSON.stringify(snapshotGame(candidate));
const landings = currentBerthLandings(candidate.map, ship, goal, candidate.units);
const replayShip = restored.units.find(unit => unit.id === id)!;
assert.equal(JSON.stringify(snapshotGame(candidate)), before);
assert.deepEqual(currentBerthLandings(restored.map, replayShip, goal, restored.units), landings);
assert.equal(landings.length, 7);
const commands = landings.map(({ passengerId }) => ({ type: 'unloadPassenger' as const, transportId: id, passengerId }));
const issued = [];
for (const [index, command] of commands.entries()) {
  const expected = landings[index]!.point;
  for (const [game, boat] of [[candidate, ship], [restored, replayShip]] as const) {
    assert.deepEqual(passengerLandingSpot(game.map, boat, command.passengerId, game.units), expected);
    issuePlayerCommand(game, 'p0', command);
    const passenger = game.units.find(unit => unit.id === command.passengerId)!;
    assert.equal(passenger.deck, undefined); assert.deepEqual({ x: passenger.x, y: passenger.y }, expected);
    assert.deepEqual(boat.order, originalOrder); assert(sameGround(game.map, goal, passenger));
  }
  assert.deepEqual(snapshotGame(restored), snapshotGame(candidate)); assert.equal(restored.nextId, candidate.nextId);
  issued.push({ command, predicted: expected, actual: expected, shipOrder: structuredClone(ship.order), cargo: shipPassengers(candidate.units, ship).length });
}
const save = (name: string, game: ReturnType<typeof createGame>) => writeFileSync(new URL(name, out), JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId, memories: saved.memories }) + '\n');
save('after-public-commands.json', candidate);
for (let index = 0; index < 45; index++) { stepGame(original); stepGame(candidate); stepGame(restored); }
assert.equal(shipPassengers(original.units, original.units.find(unit => unit.id === id)!).length, 7);
assert.equal(shipPassengers(candidate.units, ship).length, 0);
assert.deepEqual(snapshotGame(restored), snapshotGame(candidate)); assert.equal(restored.nextId, candidate.nextId);
assert.equal(JSON.stringify(saved.memories), memoryBefore); assert.equal(saved.memories.p0.naval.ferries[id].phase, 'return');
const finalCrew = initialCrew.map(passengerId => {
  const passenger = candidate.units.find(unit => unit.id === passengerId)!;
  assert.equal(passenger.hp, saved.snapshot.units.find((unit: { id: string }) => unit.id === passengerId).hp);
  assert(!passenger.deck && sameGround(candidate.map, goal, passenger));
  return { id: passengerId, hp: passenger.hp, x: passenger.x, y: passenger.y, ashoreOnOriginalIsland: true };
});
const result = {
  classification: 'Native-only 45-tick candidate mechanism replay from an explicitly manual public boat-only derived world. Not a policy/full-AI result; the original AI return intent is unchanged and is not used to justify assault.',
  fixtureProvenance: saved.provenance, fixtureSha256: createHash('sha256').update(fixture).digest('hex'),
  sourceCapturedBeforeRun: source.capturedAtUtc, sourcePatchSha256: source.patchSha256,
  startTick: saved.snapshot.tick, finalTick: candidate.tick, originalOrder,
  originalMission: saved.memories.p0.naval.ferries[id], commands, issued, finalCrew,
  originalAfter45Cargo: 7, candidateAfter45Cargo: 0, fullJsonQueryCommandOutputReplayEqual: true,
};
save('original-final.json', original); save('candidate-final.json', candidate); save('restored-final.json', restored);
writeFileSync(new URL('result.json', out), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
