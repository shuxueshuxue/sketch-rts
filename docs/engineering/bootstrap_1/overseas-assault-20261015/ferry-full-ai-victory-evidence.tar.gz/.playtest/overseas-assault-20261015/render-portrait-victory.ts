import { createCanvas } from '@napi-rs/canvas';
import { readFileSync, writeFileSync } from 'node:fs';
import { installHeadlessCanvas } from '../../src/recorder/record';
import { drawWorld } from '../../src/client/world-renderer';
import { UnitFacingTracker } from '../../src/client/unit-facing';
const root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
installHeadlessCanvas();
for (const [label, tick] of [['932', 104100], ['portrait', 104100], ['portrait', 104700], ['portrait', 105153]] as const) {
  const { snapshot } = JSON.parse(readFileSync(`${root}/archer-${label}-endgame.json.frames/${tick}.json`, 'utf8'));
  const canvas = createCanvas(1500, 1100);
  drawWorld({ ctx: canvas.getContext('2d') as any, snapshot,
    view: { x: 1250, y: 5500, width: 1500, height: 1100, zoom: 1 }, now: snapshot.tick * 1000 / 20,
    facing: new UnitFacingTracker(), labels: { mercenaryStock: String, unitKind: String } });
  writeFileSync(`${root}/archer-${label}-endgame-${tick}.png`, canvas.toBuffer('image/png'));
}
