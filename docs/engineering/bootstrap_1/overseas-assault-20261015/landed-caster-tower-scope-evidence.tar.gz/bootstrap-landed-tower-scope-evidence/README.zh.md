# 岸军施法者的敌岛炮塔查询缺口（2026-10-15）

候选基于独立承接提交 `183b84879b97902fcb57e9acadbce62b0fcfb872`。代码仅在 `/workspace/sketch-rts-landed-scope-control` 实施；root、main、规则 3/4 性能树和正在运行的普通召唤开局源均未改动。这是局部候选证据，不是完整对局获胜或 bootstrap 验收。

## 发现与范围

`planLandedCombat` 调用既有 `planCasterScreen`，后者通过 `enemyBuildings` 取得炮塔；该查询有意只保留我方已有完整基地所在的地面，所以会漏掉尚未殖民的敌方登陆岛。三个真实完整档 100410、100650、100800 没有任何敌方武装建筑，故此缺口不能追认为那些原局死亡或输赢的原因。

修复仅向共享 helper 增加可选 `localTowers` 纯参数，默认仍调用原有查询；landed 传同一真实岛上的敌方建筑列表，helper 仍使用原 `complete && attackDamage>0` 筛选及原距离/90余量/close分支。没有扩大默认大陆行为、改变塔或兵的规则数值，也没有新增任务 owner、兼容回退、运输 v11 API 或未合入的 army objective/care 联合方案。友方岛塔不进入敌塔列表。

## 原生反事实对照

反事实场景由公开 `sketchScene` 建立，双方先公开 hold，调用一次真实 landed 查询并执行公开命令，随后原生运行 240 tick。它没有历史比赛前史，不是双 AI 普通开局。双方都有正常原生单位和塔，未调整任何数值。三条路线使用同一物理场景，完整初始世界、nextId、双方全部记忆逐字节一致。

施法者为原生 summoner（95 HP，radius17），在(2250,1700)，敌塔(2600,2050)，攻击范围480。塔→单位的原生 `strikeGap` 初值494.9747468305833，单位→塔边缘距离是另一指标。旧码公开 move 到(2400,1700)，终点塔→单位403.11288741492746；单位→塔为373.11288741492734，不能互换。实际原生箭在138、165、195、225 tick命中施法者，各16伤害，95→31 HP。修复后该施法者维持原公开 hold，240 tick仍为95 HP、0次命中。原生 hit observer 和完整终态都保存，未用纸面射程代替实伤。

每条路线两版均从120 tick中点经JSON恢复并运行到240：完整 snapshot、nextId、双方记忆相同。只证明这一局部执行窗口；没有将其称为完整比赛改善。原生前后 baseline1226/candidate1227项源哈希均0变化。基线随后才添加新测试文件运行红测；该测试文件不在此前原生源审计或基线源包内。

## 真实档与边界

三份真实完整档 × 三条路线共9组合，完整公开命令（81条）及被规划方全部 memory 逐字节相同，输入snapshot未修改。原始gz完整世界、nextId、双方记忆包含在源包现有fixtures中。这支持修复未改变这些无敌塔档的行为，不能证明全部地图/种子不变。

新测试在旧183源码上实际3失败/1通过；新候选3 suites/22测试通过，包含上述原生等待/JSON恢复、旧大陆helper默认行为和友方岛塔边界。`tsc --noEmit`、`git diff --check`、对root的`git apply --check increment.patch`均通过。保留完整红、绿日志。

## 冻结与复现

规则2 manifest SHA256 `0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774` 未变；其真正执行的历史revision `d1ae110f2edd99f9c7d899ed61557891ab587639` 通过与 `frozenPolicyRoot` 相同的 git archive 路径读取，184项SHA全部匹配，历史源码包附带。`live-path-naive-audit.json` 是曾错误地将manifest与可变当前源码路径直接对照的诊断，明确标为非历史冻结执行树；不能将这些预期差异误报冻结损坏。

`baseline-source.tar.gz` 是183提交的src/package.json/tsconfig；`candidate-source.tar.gz` 是增量候选完整对应源；`increment.patch`只含2生产文件和新测试，不整文件覆盖。`replay.mjs SOURCE_ROOT baseline|candidate` 分别生成真实9组合和反事实完整中点/终态；运行时用已安装tsx加载器，并为解包后的源提供同版node_modules。`source-before/after`、`source-audit`、`comparison.json`保留完整字节核查。

磁盘满时，新增control最初复制的1719个docs文件逐项证明均已跟踪、未修改、SHA与root完全相同、无未跟踪文件；安全地对该control实施sparse checkout释放重复副本，root证据未动。最初整目录删除请求被自动审批拒绝，未执行；后续通过上述证明和仅移出已跟踪副本的较窄操作完成，无剩余权限阻塞。所有新封档移至/tmp，避免占用比赛存档空间。

原故障容器的未提交改动仍未恢复。三路线完整比赛、全部冻结对手及配对、官方地图与未见种子要求仍未完成。
