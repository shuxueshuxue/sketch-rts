from pathlib import Path
import json,hashlib,tarfile
D=Path('/tmp/bootstrap-knight-shore-diagnostic-20261015'); G=Path('/tmp/bootstrap-deployment-gate')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ship='unit-p0-warship-1101'
windows=[('normal60',D/'normal-60tick.json',D/'input-34800.json',D/'after-34860.json'),('normal1140',D/'control34860/result.json',D/'control-input-34860.json',D/'control34860/after-36000.json'),('v1approach1200',D/'prototype34800/result.json',D/'input-34800.json',D/'prototype34800/after-36000.json'),('controlContact240',D/'contact-control36000/result.json',D/'prototype-input-36000.json',D/'contact-control36000/after-36240.json'),('v1Contact240',D/'contact-prototype36000/result.json',D/'prototype-input-36000.json',D/'contact-prototype36000/after-36240.json'),('v1Retreat600',D/'withdraw-prototype36240/result.json',D/'prototype-input-36240.json',D/'withdraw-prototype36240/after-36840.json')]
summary={'classification':'Negative native shore-skirmish experiment; no candidate merge or acceptance claim. Ordinary baseline, changed-history contact control, and changed-source prototype are separated.','rulesVersion':2,'windows':[]}
for name,rp,ip,ep in windows:
 r,i,e=read(rp),read(ip),read(ep);initial={p['id'] for p in i['snapshot']['projectiles']};newshots=[p for p in r.get('shots',[]) if p['id'] not in initial];hits=[h for h in r['hits'] if h['targetId']==ship or h['sourceId']==ship]
 endship=next(u for u in e['snapshot']['units'] if u['id']==ship)
 startship=next(u for u in i['snapshot']['units'] if u['id']==ship)
 summary['windows'].append({'name':name,'input':str(ip),'result':str(rp),'endframe':str(ep),'start':i['tick'],'end':e['tick'],'sourcePre':r['pre'],'restore':r['restore'],'sourcePost':r['post'],'initialProjectileIds':sorted(initial),'projectileObserverEnabled':'shots' in r,'newObservedProjectiles':len(newshots) if 'shots' in r else None,'newObservedShipProjectiles':sum(p.get('attackerId')==ship for p in newshots),'allHits':len(r['hits']),'shipRelatedHits':hits,'shipHP':[startship['hp'],endship['hp']],'endingIncomingProjectiles':[p for p in e['snapshot']['projectiles'] if p.get('targetId')==ship],'endGuard2':[{'id':u['id'],'kind':u['kind'],'hp':u['hp'],'x':u['x'],'y':u['y'],'order':u['order']} for u in e['snapshot']['units'] if u['id'].startswith('guard-2-')],'endStats':e['snapshot']['match']['stats'],'winner':e['snapshot']['match']['winner']})
(D/'v1-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
readme='''# Native shore-fire diagnostic on original 6f80 true0 knight-v5

This package is a negative experiment, not a bootstrap win or acceptance. The input is the untouched ordinary match at tick 34800, sapphireArchipelago, seed bootstrap_1-knight-v5-official-sapphire-20261015-01. RulesVersion 2, think15, Grove v9_knight p0 vs normal Ember frozen v5 p1, frozen184. Full source archives and exact SHA manifests are attached. World, nextId and both memories are restored and saved every15 ticks; all source pre/post checks are true.

## Original cause

Original warship1101 and cutter1139 stay held roughly884/892 from guard-2-0. Native physical firing stations exist and are sea reachable. The existing destination coast gate refuses them because neutral camp strength exceeds nearby support at unchanged knight margin1.6, inside native range+160 hull warning. The neutral objective remains selected, so it holds rather than proceeds to the fleet objective. query.json has exact weapon/hull/support data. 192 alternative probes per hull found no pose passing the existing risk gate (33 warship /12 cutter physical stations existed). These probes are read-only JSON clones, not manual world positioning.

## Native comparisons and source attribution

- Normal60 plus normal1140 are one original34800→36000 continuation. Terminal world,nextId,bothmem equal the active ordinary original36000 checkpoint (baseline36000-ordinary-proof.json). The initial60tick harness has no projectile collector; all saved frames show no projectile and the1140tick collector observed none. The helper's failed observer log is preserved; its clone-of-Game failure produced no claimed result.
- Experimental v1 source only:34800→36000,1200 ticks. It uses actual station/weapon aim, hull geometry and a one-think native speed/turn upper bound, retains original risk/withdrawal whenever unsafe. No fullsim prediction is called by runtime. It moves1101 close but does not yet fire. Cutter remains held.
- Both240 tick contact windows start from the SAME REAL v1 native36000 state, not the unmodified ordinary history. Original6f80 control withdraws early, keeps464HP and does not shoot the camp (two unrelated melee hits elsewhere). V1 actually shoots:9 new observed projectiles, ship HP464→396; camp HP600→484,170→155,170→109. No own/camp death by36240.
- V1 then continues actual36240→36840,600 ticks, to close the immediate escape. Original withdrawal starts36120 before first damage36166 but reverse speed11.7462px/s is too slow against whelps84px/s. At36840 ship survives83/464HP, one neutral whelp killed, remaining dragon248HP and whelp4HP reset near camp. No incoming projectile remains. Whole-match p0/p1 unitsLost remain0; neutral unitsLost1. No match winner.

The one-think safety bound does account for next15tick foe movement (first whelp advances exact63px), but cannot guarantee an exit over later intervals once activated. This is a causal counterexample to allowing the engagement merely because the current station is outside instantaneous enemy range. Do not merge v1 or weaken the global+160 warning from it. All raw projectiles are retained; summary excludes continuation input projectile IDs when counting new observed projectiles. Native images were personally inspected: the camp visibly pursues to the shore while the ship reverses, then resets as the surviving badly injured ship clears the coast.

Full results and exact source links are in v1-summary.json. Original true0 match is owned elsewhere and remains separate from these bounded experiments. Previous changed-source 88110 wins and original unrecovered uncommitted workspace gap are not reclassified by this evidence.
'''
(D/'README.md').write_text(readme)
# Fixed payload list: package is sealed before any subsequent experiment.
paths=[p for p in D.rglob('*') if p.is_file()]
paths += [G/(prefix+suffix) for prefix in ['root6f80-combined','knight-shore-v1'] for suffix in ['-source.json','-source.patch','-source.tar.gz']]
index={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(paths)}
(D/'v1-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
arc=G/'knight-shore-v1-negative-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for p in paths:t.add(p,arcname=('diagnostic/'+str(p.relative_to(D))) if p.is_relative_to(D) else 'sources/'+p.name)
 t.add(D/'v1-evidence-index.json',arcname='v1-evidence-index.json')
proof={'archive':str(arc),'bytes':arc.stat().st_size,'sha256':sha(arc),'payloadFiles':len(paths),'allSourceChecks':all(w['sourcePre'] and w['sourcePost'] and all(w['restore'].values()) for w in summary['windows'])}
(G/'knight-shore-v1-negative-archive.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof));print([(w['name'],w['shipHP'],w['newObservedProjectiles'],w['newObservedShipProjectiles']) for w in summary['windows']])
