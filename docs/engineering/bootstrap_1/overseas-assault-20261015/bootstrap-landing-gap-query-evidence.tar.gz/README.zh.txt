这是单独gap复用纯查询优化的review包，不是登陆战术改善或新比赛结果。
固定候选25a3cec08a0ab2a26bdb9aa640bd8d08a5bab410（父4bc50dc2）唯一生产增量src/shared/naval.ts：clear(p)通过原bounds/openGround/sameGround后，只计算一次distanceToHull，将同值用于gap>=radius+1 && gap<=LANDING_REACH。保留原lazy顺序、NaN拒绝、nearest优先、完整扫描grid/逐次+=step、严格value<score平局、所有body碰撞。没有跨point/乘员/姿态缓存，没有AABB改变。gap-only.patch可独立应用；父4bc的naval.ts与原6f80相同，不需连带bounded API。
只做一次profile session，里面一个已记录失败transport pose与一个已记录成功pose各一次实际native assaultBeachBodies，非全岸重扫。100us V8采样有JIT/GC和短样本限度；失败331samples中distanceToHull50，成功157samples中43，clear内部还有匿名units.some。原始匿名naval叶聚合不能全称clear自耗。profile源码未改，对照输入是保存世界里的hypothetical query-only pose，没有真实gameplay指令或tick。
69个已保存姿态批次来自原7个actual native contexts、v2四个actual context，以及已记录失败/完整joint shadow（35成功/34失败），旧新完整返回Unit与落点deepEqual、原世界SHA不变。初次等价pass后，五轮交替old/new实际CPU：2048.456→1787.909ms，合计下降12.719%，每轮改善9.90–19.13%，中位446.981→391.843ms，每轮256 landed的digest一致。此结果只属于这69case，未重跑原98秒冷search，更不代表joint冷预算已可用或完整比赛变好。
相关原4文件47/47回归与tsc exit0。source和frozen184完整核验；API4bc旧树不变。单独commit未推远端/未合main/root，root协调只增量应用gap。
独立审查拒绝裸旋转AABB±72的严格等价主张：detSin/Cos实际有限精度给出原生scalar反例，但并非已证明实际地图原lattice的整函数结果不同；审查JSON保留其准确限度。未将它混入候选。
compare-recorded-choices.ts是实际执行runner及成本源。generic版本仅把baseline/candidate/out-dir参数化以便root复核，未替换原结果；输出路径已有文件会拒绝覆盖。
原broken容器未提交恢复缺口及所有bootstrap全局验收要求仍保留；无新ordinary0，无手工资源/人口/敌人修改，不将局部CPU节约当AI路线或获胜里程碑。
