import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { pathToFileURL } from 'node:url';
const D='/workspace/.playtest/cabin-ferry-implementation-ade-20261016';
const O=D+'/cold-return-window-207600-208200', F=D+'/native-candidate-natural-from195600';
const S='/workspace/sketch-rts-cabin-ferry-ade-control', start=207600, end=208200;
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const json=(data:any)=>JSON.parse(JSON.stringify(data));
const read=(path:string)=>JSON.parse(readFileSync(path,'utf8'));
const gz=(path:string)=>JSON.parse(gunzipSync(readFileSync(path)).toString());
const rows=(path:string)=>{const lines=readFileSync(path,'utf8').split('\n');lines.pop();const result:any[]=[];for(const line of lines){if(!line)continue;const row=JSON.parse(line);if(row.tick>=end)break;if(row.tick>=start)result.push(row);}return result;};
const assert=(value:any,message:string)=>{if(!value)throw new Error(message);};
const load=(path:string)=>import(pathToFileURL(S+'/'+path).href);
const resource=()=>({currentBytes:Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),maxBytes:Number(readFileSync('/sys/fs/cgroup/memory.max','utf8'))});
mkdirSync(O+'/frames',{recursive:true});
assert(process.cwd()===S&&!existsSync(O+'/actual-launch.json'),'Exact fixed cwd and one new cold run required');
const resourceBeforeImport=resource();
if(resourceBeforeImport.maxBytes-resourceBeforeImport.currentBytes<2_147_483_648){
 writeFileSync(O+'/prepared-blocked-max-headroom-v2.json',JSON.stringify({status:'prepared_not_started_resource_guard',resourceBeforeImport,minimumHeadroomBytes:2_147_483_648,range:[start,end],pid:process.pid},null,2)+'\n');
 console.log('Prepared only: actual cgroup max-current headroom is below2GiB; no Game or native step started.');
 process.exit(0);
}
const cap=read(D+'/fixed-runtime-candidate.json');
const sourceCheck=()=>{
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
 const changed=Object.entries(cap.hashes).filter(([path,hash])=>sha(readFileSync(S+'/'+path))!==hash).map(([path])=>path);
 assert(head==='a7e0ccaa108c7eab1ebd959ff312dd378eb8e804'&&head===cap.head&&!status&&!changed.length,'Fixed source mismatch');
 return {head,files:Object.keys(cap.hashes).length,status,changed};
};
const sourcePre=sourceCheck();
const inputPath=F+'/frames/207600-periodic-after-step.json.gz', inputBytes=readFileSync(inputPath), saved=gz(inputPath);
assert(sha(inputBytes)==='db97d98837ebd68ad379b7b936e47828f28ad63e436d6385515974d2cc29bc1a','Expected original periodic207600 input SHA mismatch');
assert(saved.snapshot.tick===start&&Object.keys(saved.memories).length===3,'Expected full 207600 world/id/all3mem input');
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot},{runAiGameLoop}]=await Promise.all([
 load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),load('src/ai/game-runner.ts')]);
const frozenRoot=frozenPolicyRoot();
const frozenCheck=()=>{
 const changed=Object.entries(frozenPolicyManifest.files).filter(([path,hash])=>sha(readFileSync(frozenRoot+'/'+path))!==hash).map(([path])=>path);
 assert(frozenPolicyManifest.rulesVersion===2&&Object.keys(frozenPolicyManifest.files).length===184&&!changed.length,'Frozen rules2 policy mismatch');
 return {rulesVersion:2,files:184,revision:frozenPolicyManifest.revision,changed};
};
const frozenPre=frozenCheck(),resourceBeforeGame=resource();
if(resourceBeforeGame.maxBytes-resourceBeforeGame.currentBytes<2_147_483_648){
 writeFileSync(O+'/prepared-blocked-max-headroom-v2.json',JSON.stringify({status:'prepared_not_started_resource_guard',resourceBeforeImport,resourceBeforeGame,minimumHeadroomBytes:2_147_483_648,range:[start,end],sourcePre,sourcePost:sourceCheck(),frozenPre,frozenPost:frozenCheck()},null,2)+'\n');
 console.log('Prepared only: actual cgroup max-current headroom is below2GiB before Game restoration; no native step started.');
 process.exit(0);
}
const g=createGame('bareDuel'),memory=createAiMemoryProvider();
restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);
for(const [owner,value]of Object.entries(saved.memories))memory.set(owner,json(value));
const full=()=>json({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(Object.keys(saved.memories).map(owner=>[owner,memory.get(owner)]))});
const initial=full(),restored={world:isDeepStrictEqual(initial.snapshot,saved.snapshot),nextId:initial.nextId===saved.nextId,all3mem:isDeepStrictEqual(initial.memories,saved.memories)};
assert(Object.values(restored).every(Boolean),'Strict full input restore mismatch');
const normal=await createBootstrapCommandPlanner(memory);
assert(isDeepStrictEqual(full(),initial),'Planner setup mutated restored input');
const agents=read(F+'/actual-launch.json').agents;
const referenceCommandRows=rows(F+'/commands.jsonl').filter((row:any)=>row.tick>=start&&row.tick<end);
const expectedCommands=referenceCommandRows.map(({commandIndex,...row}:any)=>row);
assert(referenceCommandRows.every((row:any,i:number)=>row.commandIndex===referenceCommandRows[0].commandIndex+i),'Noncontiguous original command indices');
const referenceHitRows=rows(F+'/hits.jsonl').filter((row:any)=>row.tick>=start&&row.tick<end);
const expectedHits=referenceHitRows.map(({hitIndex,...row}:any)=>row);
const referenceThinkHashes=new Map(rows(F+'/think-hashes.jsonl').filter((row:any)=>row.tick>=start&&row.tick<end).map((row:any)=>[row.tick,row.sha256]));
const [{planFerryDisembark},{walkableGoal},{checkCommandLegality}]=await Promise.all([load('src/ai/policy/ferry-disembark.ts'),load('src/shared/terrain.ts'),load('src/shared/sim/command-validation.ts')]);
const effects:any[]=[],landingIds=new Set<string>();let projection:any;
writeFileSync(O+'/return-command-effects.jsonl','');
const actualCommands:any[]=[],actualHits:any[]=[],beforeFrames:any[]=[];
const classification='One finite cold normal3AI closure from actual tail207600 periodic after-step/pre-think full world/id/all3mem to 208200. Same fixed a7e0ccaa and frozen rules2 v5/v7; zero added human commands; exactly 600 native steps maximum. Not a new match, full-game result, or enemy-coast deployment proof.';
const launch={classification,startedAtUtc:new Date().toISOString(),pid:process.pid,source:S,inputPath,inputSHA256:sha(inputBytes),helperSHA256:sha(readFileSync(import.meta.filename)),start,end,thinkInterval:15,agents,restored,sourcePre,frozenPre,resourceBeforeImport,resourceBeforeGame,reference:{commandIndexBase:referenceCommandRows[0]?.commandIndex,hitIndexBase:referenceHitRows[0]?.hitIndex,commands:expectedCommands.length,hits:expectedHits.length,beforeP0Ticks:Array.from({length:40},(_,i)=>start+i*15)},protectedTailPid:333917};
writeFileSync(O+'/actual-launch.json',JSON.stringify(launch,null,2)+'\n');
for(const name of ['commands','hits'])writeFileSync(O+'/'+name+'.jsonl','');
const emit=(name:string,row:any)=>{const values=name==='commands'?actualCommands:actualHits;values.push(row);writeFileSync(O+'/'+name+'.jsonl',JSON.stringify(row)+'\n',{flag:'a'});};
g.observer={hit(attacker:any,target:any,damage:number,hpBefore:number){emit('hits',json({tick:g.tick,attacker:attacker.id,attackerOwner:attacker.owner,attackerKind:attacker.kind,target:target.id,targetOwner:target.owner,targetKind:target.kind,damage,hpBefore,hpAfter:target.hp,deck:target.deck}));}};
const planner=(ctx:any)=>{
 if(ctx.owner==='p0'){
  const value={...full(),checkpointStage:'before-p0'};
  beforeFrames.push({tick:g.tick,value});
  if(g.tick===207915){const boat=ctx.snapshot.units.find((u:any)=>u.id==='unit-p0-carrier-25442'),mission=memory.get('p0')?.naval?.ferries?.[boat?.id];assert(boat&&mission?.phase==='return','Expected actual return boat');const before=sha(JSON.stringify(full()));projection=planFerryDisembark(ctx.snapshot,boat,mission.from,walkableGoal(ctx.snapshot.map,mission.from.x,mission.from.y));assert(projection,'No native whole-body return projection');for(const unit of projection.landed)landingIds.add(unit.id);assert(sha(JSON.stringify(full()))===before,'Projection changed restored runtime fields');writeFileSync(O+'/return-projection-207915.json',JSON.stringify({classification:'Reconstructed same-source normal3AI input; not original live full capture.',tick:g.tick,phase:mission.phase,goal:mission.from,projection},null,2));}
  writeFileSync(O+'/frames/'+g.tick+'-before-p0.json.gz',gzipSync(JSON.stringify(value)));
 }
 return normal(ctx);
};
let steps=0,maxMemory=resourceBeforeGame.currentBytes;
const loop=runAiGameLoop({name:'cold normal3AI actual return closure207600-208200',game:g,agents,maxTicks:end,thinkInterval:15,commandPlanner:planner},{
 afterCommand(entry:any){const command=entry.command;if(entry.tick!==207915||entry.owner!=='p0'||!((command.type==='unloadPassenger'&&command.transportId==='unit-p0-carrier-25442')||(command.type==='leaveCabin'&&command.unitIds.some((id:string)=>landingIds.has(id)))))return;const ids=new Set(command.type==='unloadPassenger'?[command.passengerId]:command.unitIds),effect=json({tick:entry.tick,owner:entry.owner,scriptId:entry.scriptId,command,legalityBefore:checkCommandLegality(entry.before,entry.owner,command)??null,before:entry.before.units.filter((u:any)=>ids.has(u.id)),after:entry.after.units.filter((u:any)=>ids.has(u.id)),snapshotChanged:!isDeepStrictEqual(entry.before,entry.after)});effects.push(effect);writeFileSync(O+'/return-command-effects.jsonl',JSON.stringify(effect)+'\n',{flag:'a'});},
 onCommand(entry:any){emit('commands',json({tick:entry.tick,owner:entry.owner,scriptId:entry.scriptId,command:entry.command}));},
 onStep(){steps++;maxMemory=Math.max(maxMemory,resource().currentBytes);},
});
const final=full();
writeFileSync(O+'/final.json.gz',gzipSync(JSON.stringify(final)));
const sourcePost=sourceCheck(),frozenPost=frozenCheck();
const differences=(actual:any,expected:any,path='$',out:any[]=[]):any[]=>{
 if(isDeepStrictEqual(actual,expected)||out.length>=30)return out;
 if(actual&&expected&&typeof actual==='object'&&typeof expected==='object'&&Array.isArray(actual)===Array.isArray(expected)){
  for(const key of new Set([...Object.keys(actual),...Object.keys(expected)])){
   if(out.length>=30)break;
   if(!(key in actual)||!(key in expected))out.push({path:path+'.'+key,actual:actual[key]??null,expected:expected[key]??null,missing:!(key in actual)?'actual':'expected'});
   else differences(actual[key],expected[key],path+'.'+key,out);
  }
 }else out.push({path,actual,expected});
 return out;
};
const frameComparisons=beforeFrames.map(({tick,value})=>{
 const {checkpointStage,...state}=value,expectedSHA256=referenceThinkHashes.get(tick),actualSHA256=sha(JSON.stringify(state));
 return {tick,completeWorldNextIdAll3MemoryHashEqual:actualSHA256===expectedSHA256,actualSHA256,expectedSHA256,
  scope:'Original full state before planner was hashed in the live tail; this run reconstructs the full frame. No original full before-p0 file is claimed.'};
});
const originalFinal=gz(F+'/frames/208200-periodic-after-step.json.gz');
const expectedFinal={snapshot:originalFinal.snapshot,nextId:originalFinal.nextId,memories:originalFinal.memories};
const physical=(unit:any)=>json({id:unit.id,x:unit.x,y:unit.y,radius:unit.radius,hp:unit.hp,deck:unit.deck,cabin:unit.cabin});
const actualPortraits=effects.filter(e=>e.command.type==='unloadPassenger').map(e=>e.after.find((u:any)=>u.id===e.command.passengerId));
const projectionPhysical=projection?.landed.map(physical),actualPhysical=actualPortraits.map(physical);
const actualReturnCommands=effects.map(e=>e.command),expectedReturnCommands=projection?.commands;
const returnEvidence={tick:207915,source:'Reconstructed complete before-p0 via exact normal3AI window',steps:effects.length,portraits:actualPortraits.length,
 leaveCommands:effects.filter(e=>e.command.type==='leaveCabin').length,
 everyCommandLegal:effects.every(e=>e.legalityBefore===null),everyCommandChangedWorld:effects.every(e=>e.snapshotChanged),
 publicSequenceEqualsProjection:isDeepStrictEqual(actualReturnCommands,expectedReturnCommands),
 all23PhysicalBodiesMatchProjection:actualPortraits.length===23&&isDeepStrictEqual(actualPhysical,projectionPhysical),
 actualPhysical,projectionPhysical,scope:'Actual SDK command snapshots and native effects of all33 public return commands, including real leave before portrait. Geometry/HP/radius/parent fields are compared, not unrelated order metadata. This is own-source return, not enemy deployment.'};
writeFileSync(O+'/return-effect-proof.json',JSON.stringify(returnEvidence,null,2)+'\n');
const closure={
 exact600NativeSteps:steps===600&&g.tick===end,
 beforeP0TicksExactlyExpected:isDeepStrictEqual(beforeFrames.map(row=>row.tick),Array.from({length:40},(_,i)=>start+i*15)),
 beforeP0FramesAllFieldsEqual:frameComparisons.length===40&&frameComparisons.every(row=>row.completeWorldNextIdAll3MemoryHashEqual),
 commandRowsExactlyEqual:isDeepStrictEqual(actualCommands,expectedCommands),
 hitRowsExactlyEqual:isDeepStrictEqual(actualHits,expectedHits),
 finalFullEqual:isDeepStrictEqual(final,expectedFinal),
 finalWorldEqual:isDeepStrictEqual(final.snapshot,expectedFinal.snapshot),
 finalNextIdEqual:final.nextId===expectedFinal.nextId,
 finalAll3MemoryEqual:isDeepStrictEqual(final.memories,expectedFinal.memories),
 returnEffectProofAllTrue:returnEvidence.everyCommandLegal&&returnEvidence.everyCommandChangedWorld&&returnEvidence.publicSequenceEqualsProjection&&returnEvidence.all23PhysicalBodiesMatchProjection,
};
const result={classification,status:Object.values(closure).every(Boolean)?'exact_finite_cold_closure':'finite_cold_closure_mismatch',startedAtUtc:launch.startedAtUtc,endedAtUtc:new Date().toISOString(),sourcePre,sourcePost,frozenPre,frozenPost,input:{path:inputPath,sha256:sha(inputBytes),restored},range:{start,endActual:g.tick,steps,thinkInterval:15,actualBeforeP0Ticks:beforeFrames.map(row=>row.tick)},closure,
 frameComparisons,returnEvidence,commands:{actual:actualCommands.length,expected:expectedCommands.length,scope:'Every normal planner command field/order by all p0/p1/p2 at40 frames. Original observational commandIndex omitted from row comparison; contiguous indexBase verified separately. No gameplay command filtering or human input.',actualJSONSHA256:sha(JSON.stringify(actualCommands)),expectedJSONSHA256:sha(JSON.stringify(expectedCommands)),differences:differences(actualCommands,expectedCommands)},
 hits:{actual:actualHits.length,expected:expectedHits.length,scope:'All native hit callback rows in [207600,208200), compared all native callback fields; original observational hitIndex stripped, base recorded separately. Not broad combat coverage.',actualJSONSHA256:sha(JSON.stringify(actualHits)),expectedJSONSHA256:sha(JSON.stringify(expectedHits)),differences:differences(actualHits,expectedHits)},
 final:{actualJSONSHA256:sha(JSON.stringify(final)),expectedJSONSHA256:sha(JSON.stringify(expectedFinal)),differences:differences(final,expectedFinal)},
 resources:{resourceBeforeImport,resourceBeforeGame,resourceAfter:resource(),maxObservedMemoryBytes:maxMemory,maxNativeWindowHeapBytes:process.memoryUsage().heapUsed,maxRSSKiB:process.resourceUsage().maxRSS},
 elapsedMs:loop.elapsedMs,cpuMs:loop.cpuMs,winner:g.match.winner,
 scope:'One actual600tick normal3AI return closure only, not original live pre-planner full captures. No native/unit-terminal ledger events compared or reconstructed. This does not close an earlier interval, a complete match, enemy shore landing, or bootstrap acceptance. Original inaccessible-container uncommitted-work gap remains.',protectedTailPid:333917,tailProcessControlPerformed:false};
writeFileSync(O+'/result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,range:result.range,closure,commands:result.commands,hits:result.hits,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,sourcePost,frozenPost,resources:result.resources},null,2));
