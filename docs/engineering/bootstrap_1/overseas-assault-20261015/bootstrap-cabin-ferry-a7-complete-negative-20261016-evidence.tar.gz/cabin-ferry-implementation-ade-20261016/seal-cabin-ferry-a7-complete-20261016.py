from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016')
P=Path('/workspace/.playtest'); prefix=D.name
archive=P/'bootstrap-cabin-ferry-a7-complete-negative-20261016-evidence.tar.gz'
delivery=P/'bootstrap-cabin-ferry-a7-complete-negative-20261016-delivery.json'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
files=[]
for p in sorted(D.rglob('*')):
 rel=p.relative_to(D)
 if p.is_symlink() or not p.is_file() or rel.parts[0] in ['node_modules','runtime-tmp'] or p.name=='INDEX.json':continue
 files.append((p,f'{prefix}/{rel.as_posix()}'))
extras=[
 (Path('/workspace/.playtest/cabin-load-capability-ade-20261016/input-194400.json.gz'),f'{prefix}/archives/input-194400.json.gz'),
 (Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-source-ade41241.tar.gz'),f'{prefix}/archives/root-source-ade41241.tar.gz'),
 (Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-frozen-source.tar.gz'),f'{prefix}/archives/root-frozen-source.tar.gz'),
 (Path(__file__).resolve(),f'{prefix}/seal-cabin-ferry-a7-complete-20261016.py')]
for n in ['cabin-actual-shortfall-readonly-20261016','cabin-order-feasibility-readonly-20261016','cabin-batch-publication-independent-review-20261016']:
 base=P/n
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.is_symlink():extras.append((p,f'{prefix}/independent/{n}/{p.relative_to(base).as_posix()}'))
files+=extras
payload=[{'path':name,'bytes':p.stat().st_size,'sha256':digest(p)}for p,name in files]
assert len({e['path']for e in payload})==len(payload)
index={'schema':'bootstrap-evidence-payload-sha256-v1','classification':'Sealed original fixed a7 true normal3AI changed-code continuation and local/native counterexamples. Observation stop310800 winnernull, not natural defeat/ordinary0/acceptance. Static limited permutations are not a single-hull impossibility proof.',
 'sourceHead':'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804','parentSource':'ade412414d9232206f39e20f0182f0086605433c','rulesVersion':2,'manifestFiles':184,
 'payloadCount':len(payload),'payload':payload}
indexpath=D/'INDEX.json';indexpath.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p,name in files:t.add(p,arcname=name,recursive=False)
 t.add(indexpath,arcname=f'{prefix}/INDEX.json',recursive=False)
expected={r['path']:r for r in payload};readback=[];embedded={}
with tarfile.open(archive,'r|gz') as t:
 for m in t:
  assert m.isfile(),m.name
  h=hashlib.sha256();count=0
  f=t.extractfile(m)
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);count+=len(b)
  if m.name==f'{prefix}/INDEX.json':assert count==indexpath.stat().st_size and h.hexdigest()==digest(indexpath)
  else:
   r=expected.pop(m.name);assert count==r['bytes'] and h.hexdigest()==r['sha256'];readback.append(m.name)
assert not expected and len(readback)==len(payload)
unchanged=[r['path'] for (p,_),r in zip(files,payload) if p.stat().st_size!=r['bytes'] or digest(p)!=r['sha256']]
assert not unchanged
manifest=json.loads(Path('/workspace/sketch-rts-cabin-ferry-ade-control/docs/engineering/bootstrap_1/frozen-policy.json').read_text())
for p,label in [(D/'candidate-source.tar.gz','candidate'),(extras[2][0],'frozen')]:
 bank={}
 with tarfile.open(p,'r|gz') as t:
  for m in t:
   if m.isfile():bank[m.name.removeprefix('./')]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
 embedded[label]={'regularFiles':len(bank),'manifestAll184Equal':all(bank.get(n)==h for n,h in manifest['files'].items()) if label=='frozen' else None}
 if label=='frozen':assert embedded[label]['regularFiles']==497 and embedded[label]['manifestAll184Equal']
 else:assert bank==json.loads((D/'fixed-runtime-natural-tail.json').read_text())['hashes']
out={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'payloadCount':len(payload),'regularCount':len(payload)+1,'indexPath':str(indexpath),'indexSHA256':digest(indexpath),'payloadReadbackAllSHABytesCoverage':True,'originalFilesUnchanged':not unchanged,'embedded':embedded,'sealedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceHead':index['sourceHead'],'candidateNotIntegrated':True,'baselineRange':[194400,195000],'candidateRange':[194400,310800],'stop':'parent-authorized supported observation stop','winner':None,'naturalComplete':False,
 'counts':{'commands':156343,'hits':256,'ledgerEvents':12469},'ownPermanentLosses':8,'ownCaptured':0,'currentCandidateScore':'No complete natural result/ordinary0 or acceptance. Cabin effects and source-return closure verified; force below original readiness, later empty evac hull deaths and bounded strategic stagnation remain unresolved.','excluded':'No next repacking static research, no new Game, no other active control, no restored historical docs tar; runtime-tmp/node_modules excluded.'}
delivery.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
