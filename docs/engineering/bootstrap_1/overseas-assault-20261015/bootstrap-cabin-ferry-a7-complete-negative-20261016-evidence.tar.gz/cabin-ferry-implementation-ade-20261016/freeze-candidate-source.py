from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
D=Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016')
S=Path('/workspace/sketch-rts-cabin-ferry-ade-control')
C=Path('/workspace/.playtest/cabin-load-capability-ade-20261016')
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True),'candidate must be committed and clean'
base=json.loads((D/'fixed-runtime-baseline.json').read_text())
tracked=subprocess.check_output(['git','-C',str(S),'ls-files','-z']).decode().split('\0')
paths=sorted(set(base['hashes'])|{p for p in tracked if p.startswith(('src/','scripts/'))})
hashes={p:sha((S/p).read_bytes()) for p in paths}
assert sha((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes())=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
manifest=json.loads((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
assert manifest['rulesVersion']==2 and len(manifest['files'])==184
with tarfile.open(D/'candidate-source.tar.gz','w:gz') as tf:
 for p in paths:tf.add(S/p,arcname=p,recursive=False)
with tarfile.open(D/'candidate-source.tar.gz','r:gz') as tf:
 restored={m.name:sha(tf.extractfile(m).read()) for m in tf if m.isfile()}
assert restored==hashes
frozen=C/'root-frozen-source.tar.gz';frozenhash=sha(frozen.read_bytes())
with tarfile.open(frozen,'r:gz') as tf:
 frozenfiles={m.name.removeprefix('./'):sha(tf.extractfile(m).read()) for m in tf if m.isfile()}
assert len(frozenfiles)==497
assert all(frozenfiles[p]==h for p,h in manifest['files'].items())
driver=D/'native-cabin-policy-window-v2.ts'
cap={'sourceRoot':str(S),'head':head,'hashes':hashes,'driverSHA256':sha(driver.read_bytes()),
 'observerSHA256':sha((D/'observer-ledger.ts').read_bytes()),'inputSHA256':sha((C/'input-194400.json.gz').read_bytes()),'endTick':195600,
 'classification':'Fixed independent ade-base cabin candidate. Actual194400 complete snapshot/nextId/all3mem normal three AI continuation; no diagnostic public additions. Not ordinary0, complete match, or acceptance.'}
(D/'fixed-runtime-candidate.json').write_text(json.dumps(cap,indent=2)+'\n')
proof={'sourceRoot':str(S),'head':head,'sourceFiles':len(hashes),'sourceArchive':{'path':str(D/'candidate-source.tar.gz'),'bytes':(D/'candidate-source.tar.gz').stat().st_size,'sha256':sha((D/'candidate-source.tar.gz').read_bytes()),'readbackAllEqual':restored==hashes},
 'frozenArchive':{'path':str(frozen),'bytes':frozen.stat().st_size,'sha256':frozenhash,'files':len(frozenfiles),'manifestFiles':184,'allManifestBytesEqual':True,'revision':manifest['revision'],'rulesVersion':2},
 'inputSHA256':cap['inputSHA256'],'driverSHA256':cap['driverSHA256'],'observerSHA256':cap['observerSHA256'],'configSHA256':sha((D/'fixed-runtime-candidate.json').read_bytes())}
(D/'candidate-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
