import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { pathToFileURL } from 'node:url';
const D='/workspace/.playtest/cabin-ferry-implementation-ade-20261016';
const O=D+'/cold-final-window-195570-195600', F=D+'/native-candidate-194400-195600';
const S='/workspace/sketch-rts-cabin-ferry-ade-control', start=195570, end=195600;
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const json=(data:any)=>JSON.parse(JSON.stringify(data));
const read=(path:string)=>JSON.parse(readFileSync(path,'utf8'));
const gz=(path:string)=>JSON.parse(gunzipSync(readFileSync(path)).toString());
const rows=(path:string)=>readFileSync(path,'utf8').split('\n').filter(Boolean).map(line=>JSON.parse(line));
const assert=(value:any,message:string)=>{if(!value)throw new Error(message);};
const load=(path:string)=>import(pathToFileURL(S+'/'+path).href);
const resource=()=>({currentBytes:Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),maxBytes:Number(readFileSync('/sys/fs/cgroup/memory.max','utf8'))});
mkdirSync(O+'/frames',{recursive:true});
assert(process.cwd()===S&&!existsSync(O+'/actual-launch.json'),'Exact fixed cwd and one new cold run required');
const resourceBeforeImport=resource();
if(resourceBeforeImport.currentBytes>14_500_000_000){
 writeFileSync(O+'/prepared-blocked.json',JSON.stringify({status:'prepared_not_started_resource_guard',resourceBeforeImport,limitBytes:14_500_000_000,range:[start,end],pid:process.pid},null,2)+'\n');
 console.log('Prepared only: cgroup memory exceeds 14.5GB; no Game or native step started.');
 process.exit(0);
}
const cap=read(D+'/fixed-runtime-candidate.json');
const sourceCheck=()=>{
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
 const changed=Object.entries(cap.hashes).filter(([path,hash])=>sha(readFileSync(S+'/'+path))!==hash).map(([path])=>path);
 assert(head==='a7e0ccaa108c7eab1ebd959ff312dd378eb8e804'&&head===cap.head&&!status&&!changed.length,'Fixed source mismatch');
 return {head,files:Object.keys(cap.hashes).length,status,changed};
};
const sourcePre=sourceCheck();
const inputPath=F+'/frames/195570-before-p0.json.gz', inputBytes=readFileSync(inputPath), saved=gz(inputPath);
assert(saved.snapshot.tick===start&&Object.keys(saved.memories).length===3,'Expected full 195570 world/id/all3mem input');
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot},{runAiGameLoop}]=await Promise.all([
 load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),load('src/ai/game-runner.ts')]);
const frozenRoot=frozenPolicyRoot();
const frozenCheck=()=>{
 const changed=Object.entries(frozenPolicyManifest.files).filter(([path,hash])=>sha(readFileSync(frozenRoot+'/'+path))!==hash).map(([path])=>path);
 assert(frozenPolicyManifest.rulesVersion===2&&Object.keys(frozenPolicyManifest.files).length===184&&!changed.length,'Frozen rules2 policy mismatch');
 return {rulesVersion:2,files:184,revision:frozenPolicyManifest.revision,changed};
};
const frozenPre=frozenCheck(),resourceBeforeGame=resource();
if(resourceBeforeGame.currentBytes>14_500_000_000){
 writeFileSync(O+'/prepared-blocked.json',JSON.stringify({status:'prepared_not_started_resource_guard',resourceBeforeImport,resourceBeforeGame,limitBytes:14_500_000_000,range:[start,end],sourcePre,sourcePost:sourceCheck(),frozenPre,frozenPost:frozenCheck()},null,2)+'\n');
 console.log('Prepared only: cgroup memory exceeds 14.5GB before Game restoration; no native step started.');
 process.exit(0);
}
const g=createGame('bareDuel'),memory=createAiMemoryProvider();
restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);
for(const [owner,value]of Object.entries(saved.memories))memory.set(owner,json(value));
const full=()=>json({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(Object.keys(saved.memories).map(owner=>[owner,memory.get(owner)]))});
const initial=full(),restored={world:isDeepStrictEqual(initial.snapshot,saved.snapshot),nextId:initial.nextId===saved.nextId,all3mem:isDeepStrictEqual(initial.memories,saved.memories)};
assert(Object.values(restored).every(Boolean),'Strict full input restore mismatch');
const normal=await createBootstrapCommandPlanner(memory);
assert(isDeepStrictEqual(full(),initial),'Planner setup mutated restored input');
const agents=read(F+'/actual-launch.json').agents;
const expectedCommands=rows(F+'/commands.jsonl').filter((row:any)=>row.tick>=start&&row.tick<end);
const expectedHits=rows(F+'/hits.jsonl').filter((row:any)=>row.tick>=start&&row.tick<end);
const actualCommands:any[]=[],actualHits:any[]=[],beforeFrames:any[]=[];
const classification='One finite cold normal3AI closure from actual focus 195570-before-p0 full world/id/all3mem to 195600. Same fixed a7e0ccaa and frozen rules2 v5/v7; zero added human commands; exactly 30 native steps maximum. Not a new match, full-game result, or enemy-coast deployment proof.';
const launch={classification,startedAtUtc:new Date().toISOString(),pid:process.pid,source:S,inputPath,inputSHA256:sha(inputBytes),helperSHA256:sha(readFileSync(import.meta.filename)),start,end,thinkInterval:15,agents,restored,sourcePre,frozenPre,resourceBeforeImport,resourceBeforeGame,reference:{commands:expectedCommands.length,hits:expectedHits.length,beforeP0Ticks:[start,start+15]},protectedTailPid:333917};
writeFileSync(O+'/actual-launch.json',JSON.stringify(launch,null,2)+'\n');
for(const name of ['commands','hits'])writeFileSync(O+'/'+name+'.jsonl','');
const emit=(name:string,row:any)=>{const values=name==='commands'?actualCommands:actualHits;values.push(row);writeFileSync(O+'/'+name+'.jsonl',JSON.stringify(row)+'\n',{flag:'a'});};
g.observer={hit(attacker:any,target:any,damage:number,hpBefore:number){emit('hits',json({tick:g.tick,attacker:attacker.id,attackerOwner:attacker.owner,attackerKind:attacker.kind,target:target.id,targetOwner:target.owner,targetKind:target.kind,damage,hpBefore,hpAfter:target.hp,deck:target.deck}));}};
const planner=(ctx:any)=>{
 if(ctx.owner==='p0'){
  const value={...full(),checkpointStage:'before-p0'};
  beforeFrames.push({tick:g.tick,value});
  writeFileSync(O+'/frames/'+g.tick+'-before-p0.json.gz',gzipSync(JSON.stringify(value)));
 }
 return normal(ctx);
};
let steps=0,maxMemory=resourceBeforeGame.currentBytes;
const loop=runAiGameLoop({name:'cold normal3AI final closure195570-195600',game:g,agents,maxTicks:end,thinkInterval:15,commandPlanner:planner},{
 afterCommand(){ /* Preserve the original snapshot cadence; no observer ledger or world writes. */ },
 onCommand(entry:any){emit('commands',json({tick:entry.tick,owner:entry.owner,scriptId:entry.scriptId,command:entry.command}));},
 onStep(){steps++;maxMemory=Math.max(maxMemory,resource().currentBytes);},
});
const final=full();
writeFileSync(O+'/final.json.gz',gzipSync(JSON.stringify(final)));
const sourcePost=sourceCheck(),frozenPost=frozenCheck();
const differences=(actual:any,expected:any,path='$',out:any[]=[]):any[]=>{
 if(isDeepStrictEqual(actual,expected)||out.length>=30)return out;
 if(actual&&expected&&typeof actual==='object'&&typeof expected==='object'&&Array.isArray(actual)===Array.isArray(expected)){
  for(const key of new Set([...Object.keys(actual),...Object.keys(expected)])){
   if(out.length>=30)break;
   if(!(key in actual)||!(key in expected))out.push({path:path+'.'+key,actual:actual[key]??null,expected:expected[key]??null,missing:!(key in actual)?'actual':'expected'});
   else differences(actual[key],expected[key],path+'.'+key,out);
  }
 }else out.push({path,actual,expected});
 return out;
};
const frameComparisons=beforeFrames.map(({tick,value})=>{
 const expected=gz(F+'/frames/'+tick+'-before-p0.json.gz');
 return {tick,allFieldsEqual:isDeepStrictEqual(value,expected),worldEqual:isDeepStrictEqual(value.snapshot,expected.snapshot),nextIdEqual:value.nextId===expected.nextId,all3MemoryEqual:isDeepStrictEqual(value.memories,expected.memories),actualJSONSHA256:sha(JSON.stringify(value)),expectedJSONSHA256:sha(JSON.stringify(expected)),differences:differences(value,expected)};
});
const expectedFinal=gz(F+'/final.json.gz');
const closure={
 exact30NativeSteps:steps===30&&g.tick===end,
 beforeP0TicksExactlyExpected:isDeepStrictEqual(beforeFrames.map(row=>row.tick),[start,start+15]),
 beforeP0FramesAllFieldsEqual:frameComparisons.length===2&&frameComparisons.every(row=>row.allFieldsEqual),
 commandRowsExactlyEqual:isDeepStrictEqual(actualCommands,expectedCommands),
 hitRowsExactlyEqual:isDeepStrictEqual(actualHits,expectedHits),
 finalFullEqual:isDeepStrictEqual(final,expectedFinal),
 finalWorldEqual:isDeepStrictEqual(final.snapshot,expectedFinal.snapshot),
 finalNextIdEqual:final.nextId===expectedFinal.nextId,
 finalAll3MemoryEqual:isDeepStrictEqual(final.memories,expectedFinal.memories),
};
const result={classification,status:Object.values(closure).every(Boolean)?'exact_finite_cold_closure':'finite_cold_closure_mismatch',startedAtUtc:launch.startedAtUtc,endedAtUtc:new Date().toISOString(),sourcePre,sourcePost,frozenPre,frozenPost,input:{path:inputPath,sha256:sha(inputBytes),restored},range:{start,endActual:g.tick,steps,thinkInterval:15,actualBeforeP0Ticks:beforeFrames.map(row=>row.tick)},closure,
 frameComparisons,commands:{actual:actualCommands.length,expected:expectedCommands.length,scope:'Every normal planner command by all p0/p1/p2 at ticks195570 and195585, preserving publication order, compared all fields; no human inputs or command filtering.',actualJSONSHA256:sha(JSON.stringify(actualCommands)),expectedJSONSHA256:sha(JSON.stringify(expectedCommands)),differences:differences(actualCommands,expectedCommands)},
 hits:{actual:actualHits.length,expected:expectedHits.length,scope:'All native hit callback rows in [195570,195600), compared all fields; zero reference hits is an explicitly empty closure, not broad combat coverage.',actualJSONSHA256:sha(JSON.stringify(actualHits)),expectedJSONSHA256:sha(JSON.stringify(expectedHits)),differences:differences(actualHits,expectedHits)},
 final:{actualJSONSHA256:sha(JSON.stringify(final)),expectedJSONSHA256:sha(JSON.stringify(expectedFinal)),differences:differences(final,expectedFinal)},
 resources:{resourceBeforeImport,resourceBeforeGame,resourceAfter:resource(),maxObservedMemoryBytes:maxMemory,maxNativeWindowHeapBytes:process.memoryUsage().heapUsed,maxRSSKiB:process.resourceUsage().maxRSS},
 elapsedMs:loop.elapsedMs,cpuMs:loop.cpuMs,winner:g.match.winner,
 scope:'One actual 30tick normal3AI closure only. No native/unit-terminal ledger events compared or reconstructed. This does not close an earlier interval, a complete match, enemy shore landing, or bootstrap acceptance. Original inaccessible-container uncommitted-work gap remains.',protectedTailPid:333917,tailProcessControlPerformed:false};
writeFileSync(O+'/result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,range:result.range,closure,commands:result.commands,hits:result.hits,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,sourcePost,frozenPost,resources:result.resources},null,2));
