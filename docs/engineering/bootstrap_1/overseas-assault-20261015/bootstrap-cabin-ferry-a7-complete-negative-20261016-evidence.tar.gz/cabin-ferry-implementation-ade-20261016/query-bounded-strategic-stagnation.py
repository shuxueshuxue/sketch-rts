from pathlib import Path
import json,gzip,hashlib
D=Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016');T=D/'native-candidate-natural-from195600';start,end=228600,282600
rows=[]
for tick in range(start,end+1,600):
 p=T/'frames'/f'{tick}-periodic-after-step.json.gz';raw=p.read_bytes();f=json.loads(gzip.decompress(raw));s=f['snapshot'];owners=list(f['memories'])
 row={'tick':tick,'inputSHA256':hashlib.sha256(raw).hexdigest(),'stats':s['match']['stats'],'p0gold':s['players']['p0']['gold'],'permanent':{o:sorted(u['id']for u in s['units']if u['owner']==o and u['hp']>0 and u.get('expiresTick')is None)for o in owners},'buildings':{o:sorted(b['id']for b in s['buildings']if b['owner']==o and b['hp']>0)for o in owners},'resourceAmounts':sorted((r['id'],r['amount'])for r in s['resources']),'queues':[{'id':b['id'],'owner':b['owner'],'queue':b['queue']}for b in s['buildings']if b.get('queue')],'p0ferries':f['memories']['p0'].get('naval',{}).get('ferries',{})}
 rows.append(row)
base=rows[0];checks={key:all(r[key]==base[key]for r in rows)for key in ['stats','p0gold','permanent','buildings','resourceAmounts','queues','p0ferries']}
hits=[json.loads(line)for line in(T/'hits.jsonl').read_text().splitlines()if line];term=[]
for line in(T/'events.jsonl').read_text().splitlines():
 e=json.loads(line)
 if start<=e['tick']<=end and(e.get('type')=='native-unit-terminal'and e.get('permanent')or e.get('type')=='native-building-terminal'):term.append(e)
result={'classification':'Bounded observed strategic stagnation on still-running fixed a7e0ccaa, not natural defeat, no stop request made by this pure query and no mathematical infinite-loop claim. Earlier223200 range did contain real repair spending and is preserved separately.','start':start,'end':end,'completePeriodicFrames':len(rows),'allChecks':checks,'nativeHitsInRange':[h for h in hits if start<=h['tick']<=end],'permanentOrBuildingTerminalsInRange':term,'lastNativeHitBeforeEnd':next((h for h in reversed(hits)if h['tick']<=end),None),'p0gold':base['p0gold'],'permanentCounts':{o:len(a)for o,a in base['permanent'].items()},'buildingCounts':{o:len(a)for o,a in base['buildings'].items()},'resourceAmountSum':sum(a for _,a in base['resourceAmounts']),'stats':base['stats'],'queues':base['queues'],'ferries':base['p0ferries'],'frameSHA256':[{'tick':r['tick'],'inputSHA256':r['inputSHA256']}for r in rows],'scope':'All91 complete600tick samples compared for explicit fields, plus complete native hit and permanent/building-terminal streams for this range. Does not claim all world coordinates/temporary summons/commands unchanged or future recovery mathematically impossible.'}
(D/'bounded-natural-stagnation-228600-query.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['frameSHA256','stats']},indent=2))
