import { describe, expect, it } from 'vitest';
import { issueCommandFrame } from '../../sdk/commands/frame';
import { boardUnit, deckLoad, syncDecks } from '../../shared/decks';
import { createUnit } from '../../shared/map';
import { bodyMass } from '../../shared/physical-body';
import { cabinExitPoint, enterCabinStep, isInCabin } from '../../shared/ship-cabin';
import { localToWorld, shipPassengers } from '../../shared/ship-geometry';
import { hullFits } from '../../shared/ship-navigation';
import { createGame, issuePlayerCommand, snapshotGame } from '../../shared/sim';
import type { GameCommand, Unit } from '../../shared/types';
import { planFerryDisembark } from './ferry-disembark';

const goal = { x: 1210, y: 1600 }, target = { x: 1100, y: 1600 };
function coast() {
  const game = createGame('bareDuel', { aiPlayers: [] });
  game.units = []; game.buildings = []; game.resources = []; game.items = []; game.scriptedVictory = true;
  game.map.width = game.map.height = 4000;
  game.map.terrain = { cell: 40, cols: 100, rows: 100, cells: ('.'.repeat(30) + ',' + '~'.repeat(69)).repeat(100) };
  const boat = game.spawnUnit('player', 'carrier', 1320, 1600);
  boat.sailing!.heading = Math.PI / 2;
  expect(hullFits(game.map, boat)).toBe(true);
  return { game, boat };
}
function passenger(game: ReturnType<typeof coast>['game'], boat: Unit, kind: Unit['kind'], inside = false) {
  const unit = game.spawnUnit('player', kind, boat.x, boat.y);
  expect(boardUnit(boat, unit, game.units)).toBe(true);
  if (inside) {
    // This fixture exercises egress. Native admission/entry creates the cabin
    // attachment at its real legal door, without simulating a new AI match.
    const point = cabinExitPoint(game, boat, unit)!;
    expect(point).toBeDefined();
    unit.deck = { shipId: boat.id, ...point }; Object.assign(unit, localToWorld(boat, point));
    issuePlayerCommand(game, 'player', { type: 'enterCabin', unitIds: [unit.id] });
    enterCabinStep(game, unit);
    expect(isInCabin(unit)).toBe(true);
  }
  syncDecks(game.units);
  return unit;
}
const json = (value: unknown) => JSON.parse(JSON.stringify(value));

describe('ferry public disembark projection', () => {
  it('matches every immediate native public exit and landing without advancing the clock or mutating its input', () => {
    const { game, boat } = coast();
    const a = passenger(game, boat, 'priest', true), b = passenger(game, boat, 'footman', true);
    const open = passenger(game, boat, 'siegeRam');
    const before = snapshotGame(game), saved = structuredClone(before), startLoad = deckLoad(game.units, boat);
    const query = planFerryDisembark(before, before.units.find(unit => unit.id === boat.id)!, goal, target)!;
    expect(query).toBeDefined();
    expect(before).toEqual(saved);
    expect(query.commands).toEqual([
      { type: 'unload', unitIds: [boat.id], ...goal, avoidCombat: true },
      { type: 'unloadPassenger', transportId: boat.id, passengerId: open.id },
      { type: 'leaveCabin', unitIds: [a.id] },
      { type: 'unloadPassenger', transportId: boat.id, passengerId: a.id },
      { type: 'leaveCabin', unitIds: [b.id] },
      { type: 'unloadPassenger', transportId: boat.id, passengerId: b.id },
    ]);
    const effects: { command: GameCommand; load: number; aboard: string[]; inside: string[] }[] = [];
    issueCommandFrame(game, query.commands.map(command => ({ playerId: 'player', scriptId: 'ferry-disembark-contract', command })), {
      afterIssue(entry) {
        effects.push({ command: entry.command, load: deckLoad(game.units, boat), aboard: shipPassengers(game.units, boat).map(unit => unit.id),
          inside: shipPassengers(game.units, boat).filter(isInCabin).map(unit => unit.id) });
      },
    });
    expect(game.tick).toBe(before.tick);
    expect(effects.map(effect => effect.aboard.length)).toEqual([3, 2, 2, 1, 1, 0]);
    expect(effects.map(effect => effect.inside.length)).toEqual([2, 2, 1, 1, 0, 0]);
    expect(effects[2]!.load).toBe(effects[1]!.load);
    expect(effects[4]!.load).toBe(effects[3]!.load);
    expect(startLoad - effects[1]!.load).toBe(bodyMass(open));
    for (const projected of query.landed) {
      const actual = game.units.find(unit => unit.id === projected.id)!;
      expect(json(actual)).toEqual(json(projected));
      expect(actual.deck).toBeUndefined(); expect(actual.cabin).toBeUndefined();
    }
    expect(boat.sailing!.load).toBe(0);
    expect(before).toEqual(saved);
  });

  it('does not confuse the SDK trace of a rejected inside portrait with a landing', () => {
    const { game, boat } = coast(), unit = passenger(game, boat, 'priest', true);
    boat.order = { type: 'unload', ...goal };
    let traceRows = 0;
    issueCommandFrame(game, [{ playerId: 'player', scriptId: 'rejected-inside-portrait',
      command: { type: 'unloadPassenger', transportId: boat.id, passengerId: unit.id } }], { afterIssue() { traceRows++; } });
    expect(traceRows).toBe(1);
    expect(isInCabin(unit)).toBe(true); expect(unit.deck?.shipId).toBe(boat.id);
    const query = planFerryDisembark(snapshotGame(game), boat, goal, target)!;
    expect(query.commands.map(command => command.type)).toEqual(['leaveCabin', 'unloadPassenger']);
    issueCommandFrame(game, query.commands.map(command => ({ playerId: 'player', scriptId: 'real-cabin-exit', command })));
    expect(unit.deck).toBeUndefined(); expect(unit.cabin).toBeUndefined();
    expect(unit.hp).toBe(unit.maxHp);
  });

  it.each([false, true])('matches native dead passenger egress rather than assuming the trace proves a landing (inside=%s)', inside => {
    const { game, boat } = coast(), unit = passenger(game, boat, 'footman', inside);
    unit.hp = 0;
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const query = planFerryDisembark(snapshot, boat, goal, target);
    if (inside) expect(query).toBeUndefined();
    else expect(query?.landed.map(body => body.id)).toEqual([unit.id]);
    const commands: GameCommand[] = query?.commands ?? [
      { type: 'unload', unitIds: [boat.id], ...goal },
      { type: 'leaveCabin', unitIds: [unit.id] },
      { type: 'unloadPassenger', transportId: boat.id, passengerId: unit.id },
    ];
    let traced = 0;
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'dead-egress-semantics', command })), {
      afterIssue() { traced++; },
    });
    expect(traced).toBe(commands.length);
    if (inside) {
      expect(unit.deck?.shipId).toBe(boat.id); expect(isInCabin(unit)).toBe(true);
    } else {
      // Portrait unload does not require a living passenger; it still moves
      // this dead body. Deployment strength must independently exclude it.
      expect(unit.deck).toBeUndefined(); expect(unit.cabin).toBeUndefined();
      expect(json(unit)).toEqual(json(query!.landed[0]));
    }
    expect(unit.hp).toBe(0); expect(game.tick).toBe(snapshot.tick); expect(snapshot).toEqual(before);
  });

  it('matches native landing orders when an exposed passenger is still finishing a charge', () => {
    const { game, boat } = coast(); passenger(game, boat, 'priest', true);
    const unit = passenger(game, boat, 'footman');
    unit.order = { type: 'charge', targetId: 'charge-target', resume: { type: 'idle' } };
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const query = planFerryDisembark(snapshot, boat, goal, target)!;
    issueCommandFrame(game, query.commands.map(command => ({ playerId: 'player', scriptId: 'charge-egress-contract', command })));
    expect(unit.order.type).toBe('charge'); expect(unit.orderQueue).toEqual([{ type: 'idle' }]);
    expect(json(unit)).toEqual(json(query.landed.find(projected => projected.id === unit.id)));
    expect(snapshot).toEqual(before);
  });

  it('clears actual open-deck bodies before releasing several crew through the same hatch', () => {
    const { game, boat } = coast();
    const people = [passenger(game, boat, 'priest', true), passenger(game, boat, 'footman', true), passenger(game, boat, 'summoner', true)];
    const open: Unit[] = [];
    for (let index = 0; index < 3; index++) open.push(passenger(game, boat, 'footman'));
    const before = snapshotGame(game), query = planFerryDisembark(before, boat, goal, target)!;
    expect(query).toBeDefined();
    expect(query.commands.slice(1, 1 + open.length)).toEqual(open.map(unit =>
      ({ type: 'unloadPassenger', transportId: boat.id, passengerId: unit.id })));
    issueCommandFrame(game, query.commands.map(command => ({ playerId: 'player', scriptId: 'ordered-egress', command })));
    expect(shipPassengers(game.units, boat)).toEqual([]);
    expect(query.landed).toHaveLength(open.length + people.length);
    for (const projected of query.landed) expect(json(game.units.find(unit => unit.id === projected.id))).toEqual(json(projected));
  });

  it('refuses the entire projection when there is no real shore, without removing cabin or deck bodies', () => {
    const { game, boat } = coast(); passenger(game, boat, 'priest', true); passenger(game, boat, 'footman');
    game.map.terrain = { ...game.map.terrain!, cells: '~'.repeat(10000) };
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    expect(planFerryDisembark(snapshot, boat, goal, target)).toBeUndefined();
    expect(snapshot).toEqual(before);
    expect(shipPassengers(game.units, boat)).toHaveLength(2);
    expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
  });

  it('does not teleport a cabin passenger through a hatch occupied by other owners', () => {
    const { game, boat } = coast(), unit = passenger(game, boat, 'priest', true);
    // Actual legal deck placements of hostile boarders remain obstructions;
    // this ferry cannot clear them with its own public passenger portraits.
    for (let index = 0; index < 60; index++) {
      const boarder = createUnit(`hostile-boarder-${index}`, 'enemy', 'worker', boat.x, boat.y);
      if (!boardUnit(boat, boarder, game.units)) break;
      game.units.push(boarder);
    }
    expect(cabinExitPoint(game, boat, unit)).toBeUndefined();
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    expect(planFerryDisembark(snapshot, boat, goal, target)).toBeUndefined();
    expect(snapshot).toEqual(before); expect(isInCabin(unit)).toBe(true);
  });

  it('does not claim a landing on a different island or migrate old cargo during a query', () => {
    const { game, boat } = coast(); const unit = passenger(game, boat, 'priest', true);
    const terrain = game.map.terrain!, cells = terrain.cells.split('');
    for (let row = 30; row < 35; row++) for (let col = 60; col < 65; col++) cells[row * terrain.cols + col] = '.';
    game.map.terrain = { ...terrain, cells: cells.join('') };
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    expect(planFerryDisembark(snapshot, boat, goal, { x: 2500, y: 1300 })).toBeUndefined();
    const legacy = { ...boat, cargo: [structuredClone(unit)] }, legacyBefore = structuredClone(legacy);
    expect(planFerryDisembark(snapshot, legacy, goal, target)).toBeUndefined();
    expect(legacy).toEqual(legacyBefore); expect(snapshot).toEqual(before);
  });
});
