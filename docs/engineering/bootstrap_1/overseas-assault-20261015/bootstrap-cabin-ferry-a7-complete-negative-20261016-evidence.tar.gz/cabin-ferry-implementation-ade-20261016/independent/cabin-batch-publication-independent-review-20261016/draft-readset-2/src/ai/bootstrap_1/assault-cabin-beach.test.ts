import { describe, expect, it } from 'vitest';
import { issueCommandFrame } from '../../sdk/commands/frame';
import { boardUnit, syncDecks } from '../../shared/decks';
import { createBuilding } from '../../shared/map';
import { cabinExitPoint, enterCabinStep, isInCabin } from '../../shared/ship-cabin';
import { hullContact, localToWorld, shipPassengers } from '../../shared/ship-geometry';
import { hullFits } from '../../shared/ship-navigation';
import { createGame, issuePlayerCommand, snapshotGame } from '../../shared/sim';
import { checkCommandLegality } from '../../shared/sim/command-validation';
import type { GameCommand, Unit } from '../../shared/types';
import { createAiPolicyMemory } from '../memory';
import { planFerryDisembark } from '../policy/ferry-disembark';
import { assaultExpedition } from '../policy/naval';
import { navalServices } from '../policy/naval-services';
import { effectiveCombatRating } from '../policy/v6/strength';
import { assaultBeachBodies, assaultBeachExposure, orderBootstrapAssaultLanding, planBootstrapAssaultLandings } from './assault-beach';
import { bootstrapPolicyContext } from './policy';
import { planBootstrapNaval } from './expedition-recovery';

const goal = { x: 1210, y: 1600 };
function coast() {
  const game = createGame('bareDuel', { aiPlayers: [] });
  game.units = []; game.buildings = []; game.resources = []; game.items = []; game.scriptedVictory = true;
  game.map.width = game.map.height = 4000;
  game.map.terrain = { cell: 40, cols: 100, rows: 100, cells: ('.'.repeat(30) + ',' + '~'.repeat(69)).repeat(100) };
  const boat = game.spawnUnit('player', 'carrier', 1320, 1600); boat.sailing!.heading = Math.PI / 2;
  const target = createBuilding('target', 'enemy', 'townHall', 600, 1600, true);
  game.buildings.push(target);
  const unit = game.spawnUnit('player', 'footman', boat.x, boat.y);
  expect(boardUnit(boat, unit, game.units)).toBe(true);
  const point = cabinExitPoint(game, boat, unit)!;
  unit.deck = { shipId: boat.id, ...point }; Object.assign(unit, localToWorld(boat, point));
  issuePlayerCommand(game, 'player', { type: 'enterCabin', unitIds: [unit.id] }); enterCabinStep(game, unit);
  expect(isInCabin(unit)).toBe(true); syncDecks(game.units);
  const memory = createAiPolicyMemory();
  memory.naval = { ferries: { [boat.id]: { purpose: 'assault', targetId: target.id, from: { x: 1210, y: 3000 },
    to: goal, phase: 'sailing', crewIds: [], sinceTick: game.tick } } };
  return { game, boat, unit, target, memory };
}
const ordinary = (boat: Unit): GameCommand[] => [{ type: 'unload', unitIds: [boat.id], ...goal }];

function mixedConvoy() {
  const f = coast(), companion = f.game.spawnUnit('player', 'carrier', 1320, 2000);
  companion.sailing!.heading = Math.PI / 2;
  const passengers = [0, 1].map(() => {
    const unit = f.game.spawnUnit('player', 'footman', companion.x, companion.y);
    expect(boardUnit(companion, unit, f.game.units)).toBe(true);
    return unit;
  });
  syncDecks(f.game.units);
  const companionGoal = { x: 1210, y: 2000 };
  f.memory.naval!.ferries![companion.id] = { purpose: 'assault', targetId: f.target.id, from: { x: 1210, y: 3000 },
    to: companionGoal, phase: 'sailing', crewIds: [], sinceTick: f.game.tick };
  return { ...f, companion, passengers, companionGoal };
}

function chainConvoy(centerCrew = 1) {
  const f = coast();
  f.boat.y = 1200; f.memory.naval!.ferries![f.boat.id]!.to = { x: 1210, y: 1200 };
  const add = (y: number, count: number) => {
    const boat = f.game.spawnUnit('player', 'carrier', 1320, y); boat.sailing!.heading = Math.PI / 2;
    for (let index = 0; index < count; index++) {
      const unit = f.game.spawnUnit('player', 'footman', boat.x, boat.y);
      expect(boardUnit(boat, unit, f.game.units)).toBe(true);
    }
    f.memory.naval!.ferries![boat.id] = { purpose: 'assault', targetId: f.target.id, from: { x: 1210, y: 3000 },
      to: { x: 1210, y }, phase: 'sailing', crewIds: [], sinceTick: f.game.tick };
    return boat;
  };
  const center = add(1600, centerCrew), far = add(2000, 1);
  for (let index = 0; index < 2; index++) f.game.spawnUnit('enemy', 'footman', 600, 1000 + index * 40);
  syncDecks(f.game.units);
  const snapshot = snapshotGame(f.game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory: f.memory });
  const request = (boat: Unit) => {
    const goal = f.memory.naval!.ferries![boat.id]!.to;
    return { boat, goal, ordinary: [{ type: 'unload' as const, unitIds: [boat.id], ...goal }] };
  };
  return { ...f, center, far, snapshot, context, request };
}

describe('cabin assault landing uses its projected public sequence', () => {
  it.each(['v9_archer', 'v9_summoner', 'v9_knight'] as const)('unloads %s cabin crew at the real stopped safe berth before assigning an approach', version => {
    const { game, boat, unit, target, memory } = coast(), snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const context = bootstrapPolicyContext(snapshot, 'player', version, { memory });
    const query = assaultBeachBodies(snapshot, boat, goal, target, true)!;
    expect(query.landed).toHaveLength(1); expect(query.landed[0]!.id).toBe(unit.id);
    expect(assaultBeachExposure(snapshot, 'player', context, boat, goal, target, true)?.guards).toEqual([]);
    const commands = orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat));
    expect(commands).toEqual(planFerryDisembark(snapshot, boat, goal, target)!.commands);
    expect(commands.map(command => command.type)).toEqual(['unload', 'leaveCabin', 'unloadPassenger']);
    expect(snapshot).toEqual(before);
    expect(context.memory.naval!.ferries![boat.id]!.phase).toBe('sailing');
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'native-cabin-assault', command })));
    expect(unit.deck).toBeUndefined(); expect(unit.cabin).toBeUndefined();
    expect({ x: unit.x, y: unit.y }).toEqual({ x: query.landed[0]!.x, y: query.landed[0]!.y });
    expect(game.tick).toBe(snapshot.tick);
  });

  it('retains the existing stop gate instead of exiting a moving hull', () => {
    const { game, boat, target, memory } = coast();
    boat.sailing!.speed = 1;
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    expect(assaultBeachExposure(snapshot, 'player', context, boat, goal, target, true)?.guards).toEqual([]);
    expect(orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat)))
      .toEqual([{ type: 'stop', unitIds: [boat.id] }]);
    expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
  });

  it('does not publish the cabin sequence when native guards cover the projected bodies', () => {
    const { game, boat, target, memory } = coast();
    game.spawnUnit('enemy', 'archer', 1100, 1600);
    memory.naval!.ferries![boat.id]!.approach = { x: boat.x, y: boat.y };
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    expect(assaultBeachExposure(snapshot, 'player', context, boat, goal, target, true)!.guards).toHaveLength(1);
    expect(orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat)))
      .toEqual([{ type: 'move', unitIds: [boat.id], x: boat.x, y: boat.y, avoidCombat: true }]);
    expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
  });

  it('approaches the future native berth explicitly when current cabin cargo cannot all land', () => {
    const { game, boat, target, memory } = coast();
    boat.x += 400; syncDecks(game.units);
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    expect(assaultBeachBodies(snapshot, boat, goal, target, true)).toBeUndefined();
    const future = assaultBeachBodies(snapshot, boat, goal, target)!;
    expect(future).toBeDefined();
    expect(orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat)))
      .toEqual([{ type: 'move', unitIds: [boat.id], x: future.pose.x, y: future.pose.y, avoidCombat: true }]);
    expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
  });

  it('does not release the first cabin force while a nearby companion cannot deploy its actual bodies', () => {
    const { game, boat, target, memory } = coast();
    const companion = game.spawnUnit('player', 'carrier', 1500, 1840); companion.sailing!.heading = Math.PI / 2;
    const passenger = game.spawnUnit('player', 'footman', companion.x, companion.y);
    expect(boardUnit(companion, passenger, game.units)).toBe(true); syncDecks(game.units);
    memory.naval!.ferries![companion.id] = { purpose: 'assault', targetId: target.id, from: { x: 1210, y: 3000 },
      to: { x: 1210, y: 1840 }, phase: 'sailing', crewIds: [], sinceTick: game.tick };
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    expect(assaultBeachBodies(snapshot, boat, goal, target, true)).toBeDefined();
    expect(assaultBeachBodies(snapshot, companion, memory.naval!.ferries![companion.id]!.to, target, true)).toBeUndefined();
    const commands = orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat));
    expect(commands).toEqual([]);
    const companionGoal = memory.naval!.ferries![companion.id]!.to;
    const companionCommands = orderBootstrapAssaultLanding(snapshot, 'player', context, companion, companionGoal,
      [{ type: 'unload', unitIds: [companion.id], ...companionGoal }]);
    expect(companionCommands.every(command => command.type === 'move' || command.type === 'stop')).toBe(true);
    expect(companionCommands.some(command => command.type === 'move')).toBe(true);
    expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
    expect(shipPassengers(game.units, companion)).toHaveLength(1);
  });

  it('keeps a stopped open-deck companion aboard while its nearby cabin force cannot land', () => {
    const { game, boat, target, memory } = coast();
    boat.x = 1500; syncDecks(game.units);
    const companion = game.spawnUnit('player', 'carrier', 1320, 1840); companion.sailing!.heading = Math.PI / 2;
    const passenger = game.spawnUnit('player', 'footman', companion.x, companion.y);
    expect(boardUnit(companion, passenger, game.units)).toBe(true); syncDecks(game.units);
    const companionGoal = { x: 1210, y: 1840 };
    memory.naval!.ferries![companion.id] = { purpose: 'assault', targetId: target.id, from: { x: 1210, y: 3000 },
      to: companionGoal, phase: 'sailing', crewIds: [], sinceTick: game.tick };
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    expect(assaultBeachBodies(snapshot, companion, companionGoal, target, true)).toBeDefined();
    expect(assaultBeachBodies(snapshot, boat, goal, target, true)).toBeUndefined();
    expect(orderBootstrapAssaultLanding(snapshot, 'player', context, companion, companionGoal,
      [{ type: 'unload', unitIds: [companion.id], ...companionGoal }])).toEqual([]);
    expect(passenger.deck?.shipId).toBe(companion.id);
  });

  it('deploys a safe mixed cabin/open convoy with the exact projected bodies in one public frame', () => {
    const { game, boat, target, memory } = coast();
    const companion = game.spawnUnit('player', 'carrier', 1320, 2000); companion.sailing!.heading = Math.PI / 2;
    const passenger = game.spawnUnit('player', 'footman', companion.x, companion.y);
    expect(boardUnit(companion, passenger, game.units)).toBe(true); syncDecks(game.units);
    const companionGoal = { x: 1210, y: 2000 };
    memory.naval!.ferries![companion.id] = { purpose: 'assault', targetId: target.id, from: { x: 1210, y: 3000 },
      to: companionGoal, phase: 'sailing', crewIds: [], sinceTick: game.tick };
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    const bodies = [assaultBeachBodies(snapshot, boat, goal, target, true)!,
      assaultBeachBodies(snapshot, companion, companionGoal, target, true)!].flatMap(query => query.landed);
    const commands = [orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, ordinary(boat)),
      orderBootstrapAssaultLanding(snapshot, 'player', context, companion, companionGoal,
        [{ type: 'unload', unitIds: [companion.id], ...companionGoal }])].flat();
    expect(commands.filter(command => command.type === 'leaveCabin')).toHaveLength(1);
    expect(commands.filter(command => command.type === 'unloadPassenger')).toHaveLength(2);
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'mixed-convoy-contract', command })));
    expect(shipPassengers(game.units, boat)).toEqual([]); expect(shipPassengers(game.units, companion)).toEqual([]);
    for (const body of bodies) {
      const actual = game.units.find(unit => unit.id === body.id)!;
      expect({ x: actual.x, y: actual.y }).toEqual({ x: body.x, y: body.y });
      expect(actual.deck).toBeUndefined(); expect(actual.cabin).toBeUndefined();
    }
    expect(game.tick).toBe(snapshot.tick);
  });

  it('keeps the ordinary return value for a hull without cabin cargo and without a selected approach', () => {
    const { game, boat, unit, memory } = coast();
    issuePlayerCommand(game, 'player', { type: 'leaveCabin', unitIds: [unit.id] });
    const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    const commands = ordinary(boat);
    expect(orderBootstrapAssaultLanding(snapshot, 'player', context, boat, goal, commands)).toBe(commands);
  });

  it.each(['outfit', 'services', 'source-board', 'target-board', 'source-queued', 'target-queued'] as const)(
    'keeps the other half aboard when the cabin convoy member is busy with %s', task => {
      const { game, boat, memory, companion, companionGoal } = mixedConvoy();
      if (task === 'outfit') {
        memory.naval!.outfit = { shipId: boat.id, kind: 'shipCannon', mountId: 'port-bow' };
      } else {
        const outside = game.spawnUnit('player', 'warship', 1800, 2000), source = task.startsWith('target') ? outside : boat;
        const recipient = task === 'services' ? outside : task.startsWith('target') ? boat : companion;
        const crew = game.spawnUnit('player', 'footman', source.x, source.y);
        expect(boardUnit(source, crew, game.units)).toBe(true);
        if (task.endsWith('queued')) issuePlayerCommand(game, 'player', { type: 'holdPosition', unitIds: [crew.id] });
        issuePlayerCommand(game, 'player', { type: 'board', unitIds: [crew.id], transportId: recipient.id,
          ...(task.endsWith('queued') ? { queued: true } : {}) });
        syncDecks(game.units);
      }
      const snapshot = snapshotGame(game), context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
      if (task === 'services') expect(navalServices(snapshot, 'player', context).reserved.has(boat.id)).toBe(true);
      const commands = orderBootstrapAssaultLanding(snapshot, 'player', context, companion, companionGoal,
        [{ type: 'unload', unitIds: [companion.id], ...companionGoal }]);
      expect(commands).toEqual([]);
      expect(shipPassengers(game.units, companion)).toHaveLength(2);
      expect(shipPassengers(game.units, boat).filter(isInCabin)).toHaveLength(1);
    });

  it.each([false, true])('matches the complete native sequence on two narrow piers with a non-prefix portrait subset (reverse hull order=%s)', reverse => {
    const { game, boat, target, memory, companion, passengers, companionGoal } = mixedConvoy();
    // Only one terrain row reaches each berth; the two open passengers have
    // to reserve distinct real shore positions rather than share the goal.
    game.map.terrain = { cell: 40, cols: 100, rows: 100, cells: Array.from({ length: 100 }, (_, row) =>
      '.'.repeat(29) + (row === 40 || row === 50 ? '.,' : '~~') + '~'.repeat(69)).join('') };
    expect(hullFits(game.map, boat) && hullFits(game.map, companion)).toBe(true);
    expect(hullContact(boat, companion)).toBeUndefined();
    issuePlayerCommand(game, 'player', { type: 'unload', unitIds: [companion.id], ...companionGoal });
    if (reverse) game.units = [companion, ...game.units.filter(unit => unit.id !== companion.id)];
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    const hulls = snapshot.units.filter(unit => unit.id === boat.id || unit.id === companion.id);
    expect(hulls.map(unit => unit.id)).toEqual(reverse ? [companion.id, boat.id] : [boat.id, companion.id]);
    let shadow = snapshot;
    const expected = hulls.flatMap(ship => {
      const destination = memory.naval!.ferries![ship.id]!.to;
      const query = assaultBeachBodies(shadow, ship, destination, target, true)!;
      expect(query).toBeDefined();
      const bodies = new Map(query.landed.map(unit => [unit.id, unit]));
      shadow = { ...shadow, units: shadow.units.map(unit => bodies.get(unit.id) ?? unit) };
      return query.landed;
    });
    const commands = hulls.flatMap(ship => orderBootstrapAssaultLanding(snapshot, 'player', context, ship,
      memory.naval!.ferries![ship.id]!.to, ship.id === companion.id
        ? [{ type: 'unloadPassenger', transportId: companion.id, passengerId: passengers[1]!.id }]
        : ordinary(ship)));
    expect(commands.filter(command => command.type === 'unloadPassenger' && command.transportId === companion.id))
      .toEqual(passengers.map(unit => ({ type: 'unloadPassenger', transportId: companion.id, passengerId: unit.id })));
    const nativeBodies: Unit[] = [], beforePortraitIds: string[] = [];
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'ordered-tight-cabin-convoy', command })), {
      beforeIssue(entry) {
        const command = entry.command;
        expect(checkCommandLegality(game, 'player', command)).toBeUndefined();
        if (command.type !== 'unloadPassenger') return;
        const passenger = game.units.find(unit => unit.id === command.passengerId)!;
        expect(passenger.deck?.shipId).toBe(command.transportId); expect(isInCabin(passenger)).toBe(false);
        beforePortraitIds.push(passenger.id);
      },
      afterIssue(entry) {
        const command = entry.command;
        if (command.type !== 'unloadPassenger') return;
        const passenger = game.units.find(unit => unit.id === command.passengerId)!;
        expect(passenger.deck).toBeUndefined(); expect(passenger.cabin).toBeUndefined();
        nativeBodies.push(structuredClone(passenger));
      },
    });
    expect(beforePortraitIds).toEqual(expected.map(unit => unit.id));
    expect(nativeBodies.map(unit => unit.id)).toEqual(expected.map(unit => unit.id));
    for (const body of nativeBodies) {
      const prediction = expected.find(unit => unit.id === body.id)!;
      expect({ x: body.x, y: body.y }).toEqual({ x: prediction.x, y: prediction.y });
      expect(body.y).toBeGreaterThanOrEqual(body.id === passengers[0]!.id || body.id === passengers[1]!.id ? 2000 : 1600);
      expect(body.y).toBeLessThan(body.id === passengers[0]!.id || body.id === passengers[1]!.id ? 2040 : 1640);
    }
    expect(shipPassengers(game.units, boat)).toEqual([]); expect(shipPassengers(game.units, companion)).toEqual([]);
    expect(game.tick).toBe(snapshot.tick); expect(snapshot).toEqual(before);
  });
});

describe('batch assault landings publish only real callback members', () => {
  it.each(['center-only', 'all'] as const)('does not borrow undeploying A/C through a chain of local neighbours (%s callbacks)', callbacks => {
    const f = chainConvoy();
    expect(assaultExpedition(f.snapshot, 'player', f.context, f.target).required).toBeCloseTo(2.8);
    const boats = callbacks === 'center-only' ? [f.center] : [f.boat, f.center, f.far];
    const commands = planBootstrapAssaultLandings(f.snapshot, 'player', f.context, boats.map(f.request));
    expect(commands).toEqual([]);
    expect([f.boat, f.center, f.far].map(boat => shipPassengers(f.game.units, boat).length)).toEqual([1, 1, 1]);
    issueCommandFrame(f.game, commands.map(command => ({ playerId: 'player', scriptId: 'no-chain-borrowing', command })));
    expect(f.game.tick).toBe(f.snapshot.tick);
    expect([f.boat, f.center, f.far].map(boat => shipPassengers(f.game.units, boat).length)).toEqual([1, 1, 1]);
  });

  it('publishes all actual A-B-C callbacks when each real local neighbourhood has the unchanged required force', () => {
    const f = chainConvoy(2);
    const commands = planBootstrapAssaultLandings(f.snapshot, 'player', f.context,
      [f.far, f.center, f.boat].map(f.request));
    expect(commands.filter(command => command.type === 'unloadPassenger')).toHaveLength(4);
    expect(commands.filter(command => command.type === 'unloadPassenger').map(command => command.transportId))
      .toEqual([f.boat.id, f.center.id, f.center.id, f.far.id]);
    issueCommandFrame(f.game, commands.map(command => ({ playerId: 'player', scriptId: 'real-chain-members', command })));
    expect([f.boat, f.center, f.far].map(boat => shipPassengers(f.game.units, boat).length)).toEqual([0, 0, 0]);
    expect(f.game.tick).toBe(f.snapshot.tick);
  });

  it.each([false, true])('does not borrow a nearby loading cabin hull (listed as a request=%s)', listed => {
    const f = chainConvoy();
    f.memory.naval!.ferries![f.boat.id]!.phase = 'loading';
    const commands = planBootstrapAssaultLandings(f.snapshot, 'player', f.context,
      (listed ? [f.boat, f.center] : [f.center]).map(f.request));
    expect(commands).toEqual([]);
    expect(shipPassengers(f.game.units, f.boat).filter(isInCabin)).toHaveLength(1);
    expect(shipPassengers(f.game.units, f.center)).toHaveLength(1);
  });

  it('can deploy its own sufficient real force without waiting for an absent loading cabin request', () => {
    const f = chainConvoy(3);
    f.memory.naval!.ferries![f.boat.id]!.phase = 'loading';
    const commands = planBootstrapAssaultLandings(f.snapshot, 'player', f.context, [f.request(f.center)]);
    expect(commands.filter(command => command.type === 'unloadPassenger')).toHaveLength(3);
    expect(commands.some(command => command.type === 'leaveCabin')).toBe(false);
    issueCommandFrame(f.game, commands.map(command => ({ playerId: 'player', scriptId: 'sufficient-actual-request', command })));
    expect(shipPassengers(f.game.units, f.center)).toEqual([]);
    expect(shipPassengers(f.game.units, f.boat).filter(isInCabin)).toHaveLength(1);
  });

  it('does not use the legacy minimum rating of a dead open passenger to reach the required live force', () => {
    const f = chainConvoy(4), crew = shipPassengers(f.game.units, f.center);
    crew[2]!.hp = crew[2]!.maxHp * .75; crew[3]!.hp = 0;
    f.memory.naval!.ferries![f.boat.id]!.phase = 'loading';
    const snapshot = snapshotGame(f.game);
    expect(crew.reduce((sum, unit) => sum + effectiveCombatRating(snapshot, unit), 0)).toBeCloseTo(2.85);
    expect(crew.filter(unit => unit.hp > 0).reduce((sum, unit) => sum + effectiveCombatRating(snapshot, unit), 0)).toBeCloseTo(2.75);
    expect(assaultExpedition(snapshot, 'player', f.context, f.target).required).toBeCloseTo(2.8);
    expect(planFerryDisembark(snapshot, f.center, f.request(f.center).goal, f.target)?.landed).toHaveLength(4);
    expect(planBootstrapAssaultLandings(snapshot, 'player', f.context, [f.request(f.center)])).toEqual([]);
    expect(shipPassengers(f.game.units, f.center)).toHaveLength(4);
  });

  it('does not treat a dead body on the target island as the existing landed army', () => {
    const f = chainConvoy(), dead = f.game.spawnUnit('player', 'footman', 600, 800);
    dead.hp = 0;
    const snapshot = snapshotGame(f.game);
    expect(planBootstrapAssaultLandings(snapshot, 'player', f.context, [f.request(f.center)])).toEqual([]);
    dead.hp = dead.maxHp;
    const alive = snapshotGame(f.game);
    const commands = planBootstrapAssaultLandings(alive, 'player', f.context, [f.request(f.center)]);
    expect(commands.filter(command => command.type === 'unloadPassenger')).toHaveLength(1);
    issueCommandFrame(f.game, commands.map(command => ({ playerId: 'player', scriptId: 'living-landed-army', command })));
    expect(shipPassengers(f.game.units, f.center)).toEqual([]);
  });

  it.each([false, true])('uses the real publication order and preceding bodies at a shared tight corner (reverse hull order=%s)', reverse => {
    const { game, boat, target, memory, companion, passengers } = mixedConvoy();
    game.map.terrain = { cell: 40, cols: 100, rows: 100, cells: Array.from({ length: 10000 }, (_, index) => {
      const x = index % 100, y = Math.floor(index / 100);
      return x < 30 && y < 40 ? '.' : x <= 30 && y <= 40 ? ',' : '~';
    }).join('') };
    target.y = 800; boat.x = 1280; boat.y = 1480;
    companion.x = 1100; companion.y = 1680; companion.sailing!.heading = 0;
    const goal = { x: 1210, y: 1590 };
    for (const ship of [boat, companion]) memory.naval!.ferries![ship.id]!.to = goal;
    syncDecks(game.units);
    expect(hullFits(game.map, boat) && hullFits(game.map, companion)).toBe(true);
    expect(hullContact(boat, companion)).toBeUndefined();
    issuePlayerCommand(game, 'player', { type: 'unload', unitIds: [companion.id], ...goal });
    if (reverse) game.units = [companion, ...game.units.filter(unit => unit.id !== companion.id)];
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    const hulls = snapshot.units.filter(unit => unit.id === boat.id || unit.id === companion.id);
    let shadow = snapshot;
    const expected = hulls.flatMap(ship => {
      const query = assaultBeachBodies(shadow, ship, goal, target, true)!;
      expect(query).toBeDefined();
      const bodies = new Map(query.landed.map(unit => [unit.id, unit]));
      shadow = { ...shadow, units: shadow.units.map(unit => bodies.get(unit.id) ?? unit) };
      return query.landed;
    });
    const second = hulls[1]!, standalone = assaultBeachBodies(snapshot, second, goal, target, true)!.landed[0]!;
    const afterFirstHull = expected.find(unit => unit.id === standalone.id)!;
    expect({ x: afterFirstHull.x, y: afterFirstHull.y }).not.toEqual({ x: standalone.x, y: standalone.y });
    const requests = [...hulls].reverse().map(ship => ({ boat: ship, goal, ordinary: ship.id === companion.id
      ? [{ type: 'unloadPassenger' as const, transportId: companion.id, passengerId: passengers[1]!.id }]
      : [{ type: 'unload' as const, unitIds: [ship.id], ...goal }] }));
    const commands = planBootstrapAssaultLandings(snapshot, 'player', context, requests), actual: Unit[] = [];
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'tight-batch-members', command })), {
      beforeIssue(entry) {
        expect(checkCommandLegality(game, 'player', entry.command)).toBeUndefined();
      },
      afterIssue(entry) {
        const command = entry.command;
        if (command.type !== 'unloadPassenger') return;
        const unit = game.units.find(unit => unit.id === command.passengerId)!;
        expect(unit.deck).toBeUndefined(); expect(unit.cabin).toBeUndefined(); actual.push(structuredClone(unit));
      },
    });
    expect(actual.map(unit => unit.id)).toEqual(expected.map(unit => unit.id));
    for (const unit of actual) {
      const projected = expected.find(body => body.id === unit.id)!;
      expect({ x: unit.x, y: unit.y }).toEqual({ x: projected.x, y: projected.y });
    }
    expect(shipPassengers(game.units, boat)).toEqual([]); expect(shipPassengers(game.units, companion)).toEqual([]);
    expect(game.tick).toBe(snapshot.tick); expect(snapshot).toEqual(before);
  });

  it('the real naval caller publishes the assault batch before another ferry adds return bodies on the same tight shore', () => {
    const { game, boat, target, memory, companion, passengers } = mixedConvoy();
    game.map.terrain = { cell: 40, cols: 100, rows: 100, cells: Array.from({ length: 10000 }, (_, index) => {
      const x = index % 100, y = Math.floor(index / 100);
      return x < 30 && y < 40 ? '.' : x <= 30 && y <= 40 ? ',' : '~';
    }).join('') };
    target.y = 800; boat.x = 1280; boat.y = 1480;
    companion.x = 1100; companion.y = 1680; companion.sailing!.heading = 0;
    const open = game.spawnUnit('player', 'footman', boat.x, boat.y);
    expect(boardUnit(boat, open, game.units)).toBe(true);
    const goal = { x: 1210, y: 1590 };
    memory.naval!.ferries![boat.id]!.to = goal;
    Object.assign(memory.naval!.ferries![companion.id]!, { purpose: 'settle', phase: 'return', from: goal });
    game.buildings.push(createBuilding('home', 'player', 'townHall', 400, 400, true));
    syncDecks(game.units);
    expect(hullFits(game.map, boat) && hullFits(game.map, companion)).toBe(true);
    expect(hullContact(boat, companion)).toBeUndefined();
    issuePlayerCommand(game, 'player', { type: 'unload', unitIds: [companion.id], ...goal, avoidCombat: true });
    // The shared loop visits this ordinary return first; publication must
    // still reserve the batch's proven bodies before that return can unload.
    game.units = [companion, ...game.units.filter(unit => unit.id !== companion.id)];
    const snapshot = snapshotGame(game), before = structuredClone(snapshot);
    const context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory });
    const expected = planFerryDisembark(snapshot, boat, goal, target)!;
    expect(expected.landed).toHaveLength(2);
    const returnFirst = planFerryDisembark(snapshot, companion, goal, target)!;
    const bodies = new Map(returnFirst.landed.map(unit => [unit.id, unit]));
    const reversed = planFerryDisembark({ ...snapshot, units: snapshot.units.map(unit => bodies.get(unit.id) ?? unit) }, boat, goal, target)!;
    expect(reversed.landed.map(unit => ({ id: unit.id, x: unit.x, y: unit.y })))
      .not.toEqual(expected.landed.map(unit => ({ id: unit.id, x: unit.x, y: unit.y })));
    const commands = planBootstrapNaval(snapshot, 'player', context);
    const assault = commands.flatMap((command, index) => command.type === 'unloadPassenger' && command.transportId === boat.id ? [index] : []);
    const returning = commands.flatMap((command, index) => command.type === 'unloadPassenger' && command.transportId === companion.id ? [index] : []);
    expect(assault).toHaveLength(2); expect(returning).toHaveLength(passengers.length);
    expect(Math.max(...assault)).toBeLessThan(Math.min(...returning));
    issueCommandFrame(game, commands.map(command => ({ playerId: 'player', scriptId: 'batch-before-return-caller', command })));
    for (const projected of expected.landed) {
      const actual = game.units.find(unit => unit.id === projected.id)!;
      expect(actual.deck).toBeUndefined(); expect(actual.cabin).toBeUndefined();
      expect({ x: actual.x, y: actual.y }).toEqual({ x: projected.x, y: projected.y });
    }
    expect(shipPassengers(game.units, companion)).toEqual([]);
    expect(game.tick).toBe(snapshot.tick); expect(snapshot).toEqual(before);
  });
});
