import { ferryCabinActors } from '../policy/ferry-cabin';
import { isInCabin } from '../../shared/ship-cabin';
import type { GameCommand, GameSnapshot, PlayerId } from '../../shared/types';
import type { AiPolicyContext } from '../policy/types';

/** Bootstrap's explicit ferry task owns its staged actors before the runner
 * records commands. Other actors in a mixed command retain their orders. */
export function withoutFerryCabinConflicts(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext,
  commands: readonly GameCommand[]): GameCommand[] {
  const { actors, hulls } = ferryCabinActors(snapshot, owner, options.memory.naval);
  if (!hulls.size) return commands as GameCommand[];
  const inside = new Set(snapshot.units.filter(unit => unit.owner === owner && actors.has(unit.id) && isInCabin(unit)).map(unit => unit.id));
  return commands.flatMap((command): GameCommand[] => {
    if ('targetId' in command && command.targetId && inside.has(command.targetId)) return [];
    if (command.type === 'board' && hulls.has(command.transportId)
      || command.type === 'boardShip' && hulls.has(command.targetId)
      || command.type === 'unloadPassenger' && (hulls.has(command.transportId) || actors.has(command.passengerId))) return [];
    if (command.type === 'transferItem') {
      const source = snapshot.items.find(item => item.id === command.itemId);
      const destination = command.destination;
      if (source && (source.carrierId && actors.has(source.carrierId) || source.shipId && hulls.has(source.shipId))
        || 'unitId' in destination && actors.has(destination.unitId)
        || 'shipId' in destination && hulls.has(destination.shipId)
        || 'installerId' in destination && destination.installerId && actors.has(destination.installerId)) return [];
    }
    if ('recipientId' in command && command.recipientId && actors.has(command.recipientId)) return [];
    if ('unitId' in command && actors.has(command.unitId)) return [];
    if ('unitIds' in command) {
      const unitIds = command.unitIds.filter(id => !actors.has(id));
      return unitIds.length ? [{ ...command, unitIds }] : [];
    }
    return [command];
  });
}
