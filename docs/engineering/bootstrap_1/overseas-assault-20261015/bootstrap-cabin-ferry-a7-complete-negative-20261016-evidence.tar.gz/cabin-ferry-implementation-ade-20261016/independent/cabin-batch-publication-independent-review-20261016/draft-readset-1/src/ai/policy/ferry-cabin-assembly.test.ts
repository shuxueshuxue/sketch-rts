import { describe, expect, it } from 'vitest';
import { boardUnit, syncDecks } from '../../shared/decks';
import { createBuilding } from '../../shared/map';
import { createGame, snapshotGame } from '../../shared/sim';
import { walkingDistance } from '../../shared/terrain';
import type { Unit } from '../../shared/types';
import { createAiPolicyMemory, type NavalPlanMemory } from '../memory';
import { assaultExpedition, planNavalTacticsWithAssignments } from './naval';
import type { AiPolicyContext } from './types';

// Component geometry, not a restored match or an acceptance result. The public
// planner sees the real three-island terrain and actual boarded passengers.
function assembly() {
  const game=createGame('bareDuel',{players:['us','foe'],teams:{us:'a',foe:'b'},aiPlayers:[]});
  game.units=[];game.items=[];game.buildings=[];game.resources=[];game.mercenaryCamps=[];game.scriptedVictory=true;
  game.map.width=game.map.height=4096;
  game.map.terrain={cell:32,cols:128,rows:128,cells:Array.from({length:128*128},(_,i)=>{
    const x=i%128,y=Math.floor(i/128);
    return x<32 || x>70 && x<92 && y<64 || x>102 ? '.' : '~';
  }).join('')};
  const target=createBuilding('target','foe','townHall',3500,1300,true);
  game.buildings.push(createBuilding('home','us','townHall',500,500,true),target);
  for(let i=0;i<8;i++)game.spawnUnit('foe','footman',3800,2800+i*40);
  const boats=[600,1000,1400].map(y=>game.spawnUnit('us','carrier',3100,y));
  for(const boat of boats)for(let i=0;i<4;i++){
    const unit=game.spawnUnit('us','footman',boat.x,boat.y);
    expect(boardUnit(boat,unit,game.units)).toBe(true);
  }
  syncDecks(game.units);
  const memory=createAiPolicyMemory();memory.naval={ferries:{}};
  for(const boat of boats)memory.naval.ferries![boat.id]={purpose:'assault',phase:'sailing',targetId:target.id,
    from:{x:1008,y:1400},to:{x:3280,y:1000},crewIds:[],sinceTick:0};
  const options:AiPolicyContext={version:'v9',teams:game.teams,memory};
  return {game,target,boats:boats as [Unit,Unit,Unit],options};
}
function plan(f:ReturnType<typeof assembly>,cabin=true){
  const requested:string[]=[],snapshot=snapshotGame(f.game),before=structuredClone(snapshot);
  const commands=planNavalTacticsWithAssignments(snapshot,'us',f.options,{
    ...(cabin?{assaultCargo:'cabin' as const}:{}),troopAvailable:()=>true,transportReady:()=>true,orderCrew:units=>units,mineEligible:()=>true,targetAvailable:()=>true,
    orderAssaultLanding:(boat,_goal,ordinary)=>{requested.push(boat.id);return ordinary;},
  });
  expect(snapshot).toEqual(before);
  return {commands,requested,snapshot};
}
function mission(f:ReturnType<typeof assembly>,boat:Unit){
  return f.options.memory.naval!.ferries![boat.id] as NonNullable<NavalPlanMemory['ferries']>[string];
}
describe('cabin deployment keeps actual nearby assembly',()=>{
  it('does not let the middle hull of a three-ship chain deploy while both ends must rally',()=>{
    const f=assembly(),[a,b,c]=f.boats;
    const s=snapshotGame(f.game);
    expect(walkingDistance(s.map,a,b,'sea')).toBeLessThanOrEqual(450);
    expect(walkingDistance(s.map,b,c,'sea')).toBeLessThanOrEqual(450);
    expect(Math.hypot(a.x-c.x,a.y-c.y)).toBeGreaterThan(450);
    expect(assaultExpedition(s,'us',f.options,f.target).required).toBeCloseTo(11.2);
    const {commands,requested}=plan(f);
    expect(requested).toEqual([]);
    expect(commands.some(command=>command.type==='unload'||command.type==='unloadPassenger')).toBe(false);
    for(const boat of f.boats){
      expect(mission(f,boat).phase).toBe('sailing');
      expect(mission(f,boat).rally).toEqual(mission(f,a).rally);
      expect(mission(f,boat).rally).toBeDefined();
    }
    expect(commands).toContainEqual({type:'move',unitIds:[b.id],...mission(f,b).rally,avoidCombat:true});
    expect(commands).toContainEqual({type:'move',unitIds:[c.id],...mission(f,c).rally,avoidCombat:true});
  });
  it('releases the rally after all contributing sailing hulls really fit the original local force gate',()=>{
    const f=assembly();
    f.boats.forEach((boat,i)=>{boat.y=900+i*150;mission(f,boat).rally={x:3100,y:900};});
    syncDecks(f.game.units);
    const {requested}=plan(f);
    expect(requested).toEqual(f.boats.map(boat=>boat.id));
    for(const boat of f.boats)expect(mission(f,boat).rally).toBeUndefined();
  });
  it('keeps nearby loading cargo as unfinished assembly rather than borrowing it for deployment',()=>{
    const f=assembly(),[a,b,c]=f.boats;
    // One underway hull has only four power. Two real loading hulls contribute
    // eight more potential power, but neither reaches this frame's landing callback.
    b.y=750;c.y=900;syncDecks(f.game.units);
    mission(f,b).phase='loading';mission(f,c).phase='loading';
    const {requested}=plan(f);
    expect(requested).not.toContain(a.id);
    expect(mission(f,a).phase).toBe('sailing');
    expect(mission(f,a).rally).toBeDefined();
  });
  it('preserves the original generic three-ship callback behavior when cabin mode is absent',()=>{
    const f=assembly();
    const {requested}=plan(f,false);
    expect(requested).toContain(f.boats[1].id);
  });
});
