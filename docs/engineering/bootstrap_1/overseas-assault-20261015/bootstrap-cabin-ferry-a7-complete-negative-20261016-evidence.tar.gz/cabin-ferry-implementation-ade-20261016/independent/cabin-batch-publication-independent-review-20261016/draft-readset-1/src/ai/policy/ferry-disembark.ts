import { passengerLandingSpot } from '../../shared/naval';
import { isInCabin, leaveCabin } from '../../shared/ship-cabin';
import { shipPassengers, shipProfile } from '../../shared/ship-geometry';
import { sameGround } from '../../shared/terrain';
import type { GameCommand, GameSnapshot, Unit } from '../../shared/types';

type Point = { x: number; y: number };

/** Project immediate public commands at this actual hull pose. Each landed
 * body reserves ground before the next hatch exit/portrait is considered.
 * The caller still owns stopping the hull and judging the whole army's safety;
 * this query never changes the snapshot or credits actual disembarkation. */
export function planFerryDisembark(snapshot: GameSnapshot, boat: Unit, goal: Point, target: Point):
  { commands: GameCommand[]; landed: Unit[] } | undefined {
  // Live games have already restored legacy cargo. Do not migrate or expand a
  // hull in a feasibility query, and do not model a different physical pose.
  if (boat.cargo !== undefined || boat.hp <= 0 || !shipProfile(boat)) return undefined;
  const ship: Unit = { ...boat, order: boat.order.type === 'charge' ? boat.order : { type: 'unload', ...goal },
    ...(boat.sailing ? { sailing: { ...boat.sailing } } : {}) };
  const shadow = snapshot.units.map(unit => unit.id === boat.id ? ship
    : unit.deck?.shipId === boat.id ? { ...unit } : unit);
  const passengers = shipPassengers(shadow, ship).filter(unit => unit.owner === boat.owner);
  if (!passengers.length) return undefined;
  const commands: GameCommand[] = [];
  if (boat.order.type !== 'unload' || boat.order.x !== goal.x || boat.order.y !== goal.y)
    commands.push({ type: 'unload', unitIds: [boat.id], ...goal, avoidCombat: true });
  const landed: Unit[] = [];
  // Empty the open deck first. A large deck-only body can occupy the real
  // hatch approach even when the compartment itself has plenty of room.
  for (const passenger of [...passengers.filter(unit => !isInCabin(unit)), ...passengers.filter(isInCabin)]) {
    if (isInCabin(passenger)) {
      // Native leaveCabin uses cabinExitPoint and changes only this cloned
      // passenger: a real deck point is required before its public unload.
      if (passenger.hp <= 0 || !leaveCabin({ ...snapshot, units: shadow }, passenger)) return undefined;
      commands.push({ type: 'leaveCabin', unitIds: [passenger.id] });
    }
    const point = passengerLandingSpot(snapshot.map, ship, passenger.id, shadow);
    if (!point || !sameGround(snapshot.map, point, target)) return undefined;
    const charging = passenger.order.type === 'charge';
    const unit: Unit = { ...passenger, ...point, deck: undefined, cabin: undefined,
      aim: undefined, order: charging ? passenger.order : { type: 'idle' }, orderQueue: charging ? [{ type: 'idle' }] : [] };
    shadow[shadow.indexOf(passenger)] = unit;
    landed.push(unit);
    commands.push({ type: 'unloadPassenger', transportId: boat.id, passengerId: passenger.id });
  }
  return { commands, landed };
}
