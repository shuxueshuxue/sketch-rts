from pathlib import Path
from copy import deepcopy
import ast,gzip,json,math,hashlib,subprocess
S=Path('/workspace/sketch-rts-cabin-ferry-ade-control');D=Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016');T=D/'native-candidate-natural-from195600';OLD=Path('/workspace/.playtest/cabin-actual-shortfall-readonly-20261016');O=Path('/workspace/.playtest/cabin-order-feasibility-readonly-20261016')
sha=lambda b:hashlib.sha256(b).hexdigest()
cap=json.loads((D/'fixed-runtime-natural-tail.json').read_text())
def proof():
 h=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True);changed=[p for p,x in cap['hashes'].items()if sha((S/p).read_bytes())!=x];assert h==cap['head']and not status and not changed
 return {'head':h,'status':status,'files':len(cap['hashes']),'changed':changed}
pre=proof();inputpath=T/'frames/199834-after-step-native.json.gz';original=json.loads(gzip.decompress(inputpath.read_bytes()));unchanged=json.dumps(original,sort_keys=True);snap=original['snapshot'];H='unit-p0-carrier-25442';units={u['id']:u for u in snap['units']};boat=units[H]
prior=json.loads((OLD/'result.json').read_text());witness=[u['id']for u in prior['missingFive']]
metric=json.loads((D/'actual-ferry-force-202800.json').read_text())['rows'][0];allids=metric['globalSelectedWitness'];cargo=[u for u in snap['units']if u.get('deck',{}).get('shipId')==H];baseids={u['id']for u in cargo};remaining=[units[id]for id in allids if id not in baseids];assert len(cargo)==15 and len(remaining)==13
raw=json.loads((S/'src/shared/generated/ship-geometry.json').read_text())['ships']['carrier'];scale=1.1*1.2;L=raw['length']*scale;W=raw['beam']*scale;poly=[(x*scale,y*scale)for x,y in raw['deck']];obstacles=[(o['x']*scale,o['y']*scale,o['radius']*scale)for o in raw['obstacles']];planes=[]
for i,(x,y)in enumerate(poly):
 nx,ny=poly[(i+1)%len(poly)];a=y-ny;b=nx-x;planes.append((a,b,min(a*px+b*py for px,py in poly)))
# Load only four pure function definitions from the sealed preceding audit.
# Never import/execute that module's top level, which writes its own outputs.
tree=ast.parse((OLD/'audit.py').read_text());names={'static_fits','static_placement','rating','mass'};defs=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in names];assert len(defs)==4
ns={'math':math,'planes':planes,'obstacles':obstacles,'L':L,'W':W,'caster':{'summoner':.6,'priest':.8,'ashHexer':.9},'footman':math.sqrt(145*16/(22/20))}
exec(compile(ast.Module(body=defs,type_ignores=[]),str(OLD/'audit.py')+' pure definitions only','exec'),ns)
place=ns['static_placement'];rating=ns['rating'];mass=ns['mass'];capacity=raw['loadCapacity']*scale**2;required=metric['required'];quota=20
assert sum(bool(u.get('cabin'))for u in cargo)==10 and sum(mass(u)for u in cargo)==1555
public=[r['id']for r in prior['earliestObservedAdmissionGap']['proposedBoardOrderPoints']]
arrived=[r['id']for r in prior['actualArrivalOrder']]
ids=[u['id']for u in remaining];rank={id:i for i,id in enumerate(ids)}
def rest(first):return first+[id for id in ids if id not in first]
shore={'x':7120,'y':5968};pickup={'x':7408,'y':6576}
def dist(u,p):return math.hypot(u['x']-p['x'],u['y']-p['y'])
orders=[
 ('published_nine_then_unrequested','Actual199860 public nine first, then remaining four in original global witness order.',rest(public)),
 ('actual_arrivals_then_waiter','Actual eight successful arrival order, then pending7979, then the remaining four.',rest(arrived+['unit-p0-summoner-7979'])),
 ('global_witness_order','Original28 witness order restricted to the real remaining13.',ids),
 ('largest_body_first','Descending physical radius, then descending current combat rating, then ID.',[u['id']for u in sorted(remaining,key=lambda u:(-u['radius'],-rating(u),u['id']))]),
 ('highest_combat_first','Descending current combat rating, then descending radius, then ID.',[u['id']for u in sorted(remaining,key=lambda u:(-rating(u),-u['radius'],u['id']))]),
 ('combat_per_floor_disk','Descending combat rating per (radius+1)^2, then ID.',[u['id']for u in sorted(remaining,key=lambda u:(-rating(u)/(u['radius']+1)**2,u['id']))]),
 ('nearest_actual_shore','199834 actual straight-line distance to later native shared boarding shore7120,5968; not road distance or ETA.',[u['id']for u in sorted(remaining,key=lambda u:(dist(u,shore),u['id']))]),
 ('nearest_announced_pickup','199834 actual straight-line distance to pickup7408,6576 announced199845; not road distance or ETA.',[u['id']for u in sorted(remaining,key=lambda u:(dist(u,pickup),u['id']))]),
 ('farthest_actual_shore','Farthest straight-line shore distance first; explicit delayed-nearby-arrival thought experiment.',[u['id']for u in sorted(remaining,key=lambda u:(-dist(u,shore),u['id']))]),
 ('healthy_first_then_combat','Full-HP bodies first, then current combat rating, radius and ID.',[u['id']for u in sorted(remaining,key=lambda u:(u['hp']<u['maxHp'],-rating(u),-u['radius'],u['id']))])]
results=[]
for name,description,order in orders:
 assert len(order)==13 and set(order)==set(ids)
 projected=deepcopy(cargo);steps=[];accepted=[];rejected=[]
 for id in order:
  unit=units[id];beforemass=sum(mass(u)for u in projected);point=place(unit,projected)if beforemass+mass(unit)<=capacity else None
  accepted_now=point is not None
  if accepted_now:
   copy=deepcopy(unit);copy['deck']={'shipId':H,**point};assert not copy.get('cabin');projected.append(copy);accepted.append(id)
  else:rejected.append(id)
  steps.append({'id':id,'hp':unit['hp'],'radius':unit['radius'],'mass':mass(unit),'rating':rating(unit),'accepted':accepted_now,'localDeckPoint':point,'reason':None if accepted_now else 'mass'if beforemass+mass(unit)>capacity else'no_native_grid_floor_point','cargoAfter':len(projected),'loadAfter':sum(mass(u)for u in projected),'combatAfter':sum(rating(u)for u in projected),'insideAfter':10,'quotaUsedAfter':20,'quotaFreeAfter':1})
 assert all(next(u for u in projected if u['id']==id)==units[id]for id in baseids)
 power=sum(rating(u)for u in projected)
 results.append({'name':name,'description':description,'order':order,'acceptedAdditional':len(accepted),'totalCargo':len(projected),'openDeckAfter':len(projected)-10,'insideAfter':10,'massAfter':sum(mass(u)for u in projected),'quotaUsedAfter':20,'quotaFreeAfter':1,'combatRatingAfter':power,'required':required,'meetsOriginalRequired':power>=required,'gapToRequired':required-power,'acceptedIds':accepted,'rejectedIds':rejected,'steps':steps})
assert json.dumps(original,sort_keys=True)==unchanged
result={'classification':'Finite read-only JSON geometry exploration, fixed actual199834 existing15 cargo/10 inside, current saved HP, original required20.115569375546702. Literal original greedy board-floor/mass formulas. No source edits, Game/native/commands/fullplanner/tests or actual arrival/timing claim.',
 'sourcePre':pre,'sourcePost':proof(),'input':{'path':str(inputpath),'sha256':sha(inputpath.read_bytes()),'checkpointStage':original.get('checkpointStage'),'restorableBoundary':original.get('restorableBoundary'),'usedForJSONGeometryOnly':True},
 'fixedInitial':{'tick':199834,'existingIds':[u['id']for u in cargo],'existingCargo':15,'existingInside':10,'existingOpen':5,'existingMass':1555,'existingCombat':sum(rating(u)for u in cargo),'cabinCapacity':21,'quotaUsed':20,'quotaFree':1,'required':required,'massCapacity':capacity,'existingPositionsAndBodiesNeverMoved':True},
 'realRemaining13':[{'id':u['id'],'kind':u['kind'],'hp':u['hp'],'maxHp':u['maxHp'],'radius':u['radius'],'mass':mass(u),'rating':rating(u),'actualPosition':{'x':u['x'],'y':u['y']}}for u in remaining],
 'finiteOrderCount':len(orders),'results':results,
 'summary':{'successfulMathematicalOrders':[r['name']for r in results if r['meetsOriginalRequired']],'bestByCombat':max(results,key=lambda r:r['combatRatingAfter'])['name'],'maxCombatInTestedOrders':max(r['combatRatingAfter']for r in results),'maximumAdditionalCountAmongTested':max(r['acceptedAdditional']for r in results)},
 'modelDetails':['Every attempted body sees all fixed existing occupants and every preceding accepted actual-size projected body. A rejected body reserves no slot. Candidate order is fully fixed before each calculation.',
 'New bodies remain exposed on deck. The actual cabin budget is20/21; all remaining walking bodies cost2, and mechanical ram cannot enter. No fictitious quota or floor is released.',
 'This uses local deck geometry only. Original199834 world remains byte-semantically unchanged; all original15 unit objects, floor points, cabin attachments and HP are fixed.',
 'Source-defined geometry was previously checked against8/8 actual boarding points in the independent shortfall audit. These new orders are mathematical sequences only and have not occurred in the live match.'],
 'limits':['Ten explicit orders only, not an exhaustive search or a global impossibility proof. If none reaches required, untested orders/repacking/legal swaps/multiple actual hulls remain unproven possibilities.',
 'Straight-line distance orders are deliberately labeled; no road, ground route, sailing ETA, body traffic, shore reach, timing, native board failure, or implementation claim follows.',
 'A successful mathematical order, if any, still requires parent actual public micro and complete-game validation. No source/HP/threshold reduction; original unavailable-container recovery gap remains.'],
 'provenance':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in [OLD/'audit.py',OLD/'result.json',OLD/'index.json',D/'actual-ferry-force-202800.json',S/'src/shared/generated/ship-geometry.json',S/'src/shared/decks.ts',S/'src/shared/navigation-math.ts']]}
(O/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':result['sourcePost'],'fixed':result['fixedInitial'],'summary':result['summary'],'orders':[{k:r[k]for k in ['name','acceptedAdditional','totalCargo','massAfter','combatRatingAfter','meetsOriginalRequired','gapToRequired']}for r in results]},indent=2))
