from pathlib import Path
import json,hashlib
O=Path('/workspace/.playtest/cabin-order-feasibility-readonly-20261016')
r=json.loads((O/'result.json').read_text());power=r['fixedInitial']['existingCombat'];rows=[]
for count,unit in enumerate(sorted(r['realRemaining13'],key=lambda u:(-u['rating'],u['id'])),1):
 power+=unit['rating'];rows.append({'additionalCount':count,'nextHighestRatingId':unit['id'],'maximumCombatIgnoringAllFloorAndArrivalConstraints':power,'meetsOriginalRequired':power>=r['fixedInitial']['required']})
minimum=next(row['additionalCount']for row in rows if row['meetsOriginalRequired'])
bound={'classification':'Pure arithmetic necessary count bound for these fixed15 current-HP existing bodies and the actual remaining13 only. It ignores all floor geometry, cabin changes and arrival constraints; it is an optimistic upper combat bound for each additional count, not a feasible loading plan.',
 'basisResultSHA256':hashlib.sha256((O/'result.json').read_bytes()).hexdigest(),'fixedInitialCombat':r['fixedInitial']['existingCombat'],'required':r['fixedInitial']['required'],
 'optimisticSortedPrefixBounds':rows,'necessaryAdditionalCountAtLeast':minimum,'necessaryTotalCargoAtLeast':15+minimum,'necessaryOpenFloorBodiesAtLeastWithoutCabinChanges':5+minimum,
 'bestTenAdditionalUpperCombat':rows[9]['maximumCombatIgnoringAllFloorAndArrivalConstraints'],'bestTenStillShortBy':r['fixedInitial']['required']-rows[9]['maximumCombatIgnoringAllFloorAndArrivalConstraints'],
 'interpretation':'For this exact fixed roster, even its best10 additional bodies reach only20.085184<20.115569. At least11 additional live bodies are necessary, for26 total/16 open bodies if actual10 inside remain unchanged. This is not a general unit-count acceptance threshold or a proof that no geometric ordering can fit those11.',
 'finiteOrdersObserved':{'tested':r['finiteOrderCount'],'maxAdditionalActuallyProjected':r['summary']['maximumAdditionalCountAmongTested'],'bestProjectedCombat':r['summary']['maxCombatInTestedOrders']},
 'limits':'No cabin swap, existing passenger motion, extra hull or wider packing search performed; none is ruled impossible. No Game/native/planner/test execution.'}
(O/'force-count-bound.json').write_text(json.dumps(bound,ensure_ascii=False,indent=2)+'\n')
files=[]
for name in ['explore.py','result.json','query.log','force-count-bound.py','force-count-bound.json']:
 data=(O/name).read_bytes();files.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
index={'status':'ten_finite_orders_below_original_required_no_global_impossibility_claim','sourceHead':r['sourcePost']['head'],'sourceFilesBeforeAfterVerifiedUnchanged':r['sourcePost']['files'],'input':r['input'],'artifacts':files,'summary':r['summary'],'necessaryCountBound':{'additional':minimum,'totalCargo':15+minimum,'openBodiesWithoutCabinChanges':5+minimum,'best10UpperCombat':bound['bestTenAdditionalUpperCombat']},'nativeOrGameOrFullPlannerOrTestRuns':0,'limits':r['limits']}
p=O/'index.json';p.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'bound':index['necessaryCountBound'],'summary':index['summary'],'artifacts':files,'index':{'file':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}},indent=2))
