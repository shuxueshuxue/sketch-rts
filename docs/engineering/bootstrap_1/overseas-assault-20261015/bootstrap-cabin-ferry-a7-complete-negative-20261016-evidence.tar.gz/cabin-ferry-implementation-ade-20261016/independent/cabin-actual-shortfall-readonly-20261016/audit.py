from pathlib import Path
from collections import deque,Counter
from copy import deepcopy
import gzip,hashlib,json,math,subprocess
S=Path('/workspace/sketch-rts-cabin-ferry-ade-control')
D=Path('/workspace/.playtest/cabin-ferry-implementation-ade-20261016')
T=D/'native-candidate-natural-from195600'
O=Path('/workspace/.playtest/cabin-actual-shortfall-readonly-20261016')
H='unit-p0-carrier-25442'
def digest(data):return hashlib.sha256(data).hexdigest()
def jread(path):return json.loads(Path(path).read_text())
def gz(path):return json.loads(gzip.decompress(Path(path).read_bytes()))
cap=jread(D/'fixed-runtime-natural-tail.json')
def source_proof():
 head=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
 status=subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True)
 changed=[p for p,h in cap['hashes'].items()if digest((S/p).read_bytes())!=h]
 assert head=='a7e0ccaa108c7eab1ebd959ff312dd378eb8e804'and not status and not changed
 return {'head':head,'files':len(cap['hashes']),'status':status,'changed':changed}
pre=source_proof()
input_provenance=[{'path':str(D/'fixed-runtime-natural-tail.json'),'bytes':(D/'fixed-runtime-natural-tail.json').stat().st_size,'sha256':digest((D/'fixed-runtime-natural-tail.json').read_bytes())}]
def tracked_gz(name):
 path=T/'frames'/name;data=path.read_bytes();input_provenance.append({'path':str(path),'bytes':len(data),'sha256':digest(data)})
 return gz(path)
def log_prefix(name,cutoff=208200):
 path=T/(name+'.jsonl');out=[];raw=[]
 # Only immutable completed lines through the bounded diagnostic interval.
 with path.open('rb')as stream:
  for line in stream:
   if not line.endswith(b'\n'):break
   row=json.loads(line)
   if row['tick']>cutoff:break
   out.append(row);raw.append(line)
 data=b''.join(raw)
 input_provenance.append({'path':str(path),'scope':'complete immutable prefix tick <= '+str(cutoff),'rows':len(out),'bytes':len(data),'sha256':digest(data)})
 return out
metric=jread(D/'actual-ferry-force-202800.json')['rows'][0]
input_provenance.append({'path':str(D/'actual-ferry-force-202800.json'),'sha256':digest((D/'actual-ferry-force-202800.json').read_bytes())})
frames={}
for name in ['198664-cabin-unit-p0-ashHexer-4420-after-step.json.gz','199834-after-step-native.json.gz','200400-periodic-after-step.json.gz','202447-after-step-native.json.gz','202461-after-step-native.json.gz','202488-after-step-native.json.gz','202490-after-step-native.json.gz','202502-after-step-native.json.gz','202512-after-step-native.json.gz','202517-after-step-native.json.gz','202548-after-step-native.json.gz','202800-periodic-after-step.json.gz','203400-periodic-after-step.json.gz','207600-periodic-after-step.json.gz','208200-periodic-after-step.json.gz']:
 frames[name]=tracked_gz(name)
base=frames['202800-periodic-after-step.json.gz'];snap=base['snapshot'];memory=base['memories']['p0'];unit_by_id={u['id']:u for u in snap['units']};boat=unit_by_id[H];mission=memory['naval']['ferries'][H]
missing=[id for id in metric['globalSelectedWitness']if id not in metric['cargoIds']]
assert len(missing)==5
commands=log_prefix('commands');events=log_prefix('events');cabins=log_prefix('cabin-events');hits=log_prefix('hits');thinks=log_prefix('think-hashes')
recruit=next(row for row in commands if row['tick']==199860 and row['owner']=='p0'and row['command']['type']=='board'and row['command']['transportId']==H)
# Terrain-only connected components duplicate the documented sameGround cell
# rule, including no diagonal corner cutting. No navigation/native code loaded.
terrain=snap['map']['terrain'];cols=terrain['cols'];rows=terrain['rows'];cells=terrain['cells'];cell=terrain['cell'];labels=[0]*len(cells);count=0
for at,char in enumerate(cells):
 if char not in '.,m='or labels[at]:continue
 count+=1;labels[at]=count;q=deque([at])
 while q:
  cur=q.popleft();x=cur%cols;y=cur//cols
  for dx,dy in [(1,0),(0,1),(-1,0),(0,-1),(1,1),(-1,1),(-1,-1),(1,-1)]:
   nx=x+dx;ny=y+dy
   if not(0<=nx<cols and 0<=ny<rows):continue
   nxt=ny*cols+nx
   if labels[nxt]or cells[nxt]not in '.,m=':continue
   if dx and dy and(cells[y*cols+nx]not in '.,m='or cells[ny*cols+x]not in '.,m='):continue
   labels[nxt]=count;q.append(nxt)
def ground(point):
 col=math.floor(point['x']/cell);row=math.floor(point['y']/cell);at=row*cols+col
 return {'terrain':cells[at],'component':labels[at]}
# Literal static arithmetic for the current a7e0ccaa native deck model. This
# never calls canBoard/boardUnit, moves a real body, or runs a policy planner.
raw_geom=jread(S/'src/shared/generated/ship-geometry.json')['ships']['carrier'];scale=1.1*1.2
assert boat.get('deckScale')is None and boat.get('cargoCapacity')is None and boat['fittings']==[]
L=raw_geom['length']*scale;W=raw_geom['beam']*scale
poly=[(x*scale,y*scale)for x,y in raw_geom['deck']]
obstacles=[(o['x']*scale,o['y']*scale,o['radius']*scale)for o in raw_geom['obstacles']]
planes=[]
for i,(x,y)in enumerate(poly):
 nx,ny=poly[(i+1)%len(poly)];a=y-ny;b=nx-x;planes.append((a,b,min(a*px+b*py for px,py in poly)))
def static_fits(x,y,r,occupants,ignored):
 if not all(x*a+y*b>=mn+(r+1)*math.hypot(a,b)-1e-6 for a,b,mn in planes):return False
 if any(math.hypot(x-ox,y-oy)<orr+r+1-1e-6 for ox,oy,orr in obstacles):return False
 return not any(u['id']!=ignored and u['hp']>0 and not u.get('cabin')and math.hypot(x-u['deck']['x'],y-u['deck']['y'])<r+u['radius']+1-1e-6 for u in occupants)
def static_placement(unit,occupants):
 px=-L/2;py=-W/2
 if static_fits(px,py,unit['radius'],occupants,unit['id']):return {'x':px,'y':py}
 best=None;score=float('inf');y=-W/2
 while y<=W/2:
  x=-L/2
  while x<=L/2:
   distance=(x-px)**2+(y-py)**2
   if distance<score and static_fits(x,y,unit['radius'],occupants,unit['id']):best={'x':x,'y':y};score=distance
   x+=2
  y+=2
 return best
caster={'summoner':.6,'priest':.8,'ashHexer':.9}
footman=math.sqrt(145*(16/(22/20)))
def rating(unit):
 base=caster.get(unit['kind'])
 if base is None:base=math.sqrt(unit['maxHp']*(unit['attackDamage']/max(1,unit['attackCooldown']/20)))/footman
 return base*max(.1,unit['hp']/max(1,unit['maxHp']))
def mass(unit):
 if unit['kind']=='siegeRam':return 2200+(unit.get('gearMass')or 0)
 # These saved units have unchanged bodyRadius==radius and no gear.
 assert unit.get('bodyRadius',unit['radius'])==unit['radius']
 return math.floor(85*(unit['radius']/16)**3+.5)+(unit.get('gearMass')or 0)
assert all(not unit_by_id[i].get('gearMass')and not unit_by_id[i].get('hands')for i in metric['globalSelectedWitness'])
actual_power=sum(rating(unit_by_id[i])for i in metric['cargoIds']);global_power=sum(rating(unit_by_id[i])for i in metric['globalSelectedWitness'])
assert abs(actual_power-metric['actualPermanentArmyPower'])<1e-12
assert sum(mass(unit_by_id[i])for i in metric['cargoIds'])==2392
cargo=[u for u in snap['units']if u.get('deck',{}).get('shipId')==H]
missing_rows=[]
for id in missing:
 u=unit_by_id[id]
 owner_commands=[row for row in commands if row['tick']<=203400 and row['owner']=='p0'and(id in row['command'].get('unitIds',[])or row['command'].get('unitId')==id)]
 assert u['hp']>0 and not u.get('deck')and not u.get('cabin')and not u.get('orderQueue')
 missing_rows.append({'id':id,'kind':u['kind'],'hp':u['hp'],'maxHp':u['maxHp'],'mass':mass(u),'power':rating(u),'position':{'x':u['x'],'y':u['y']},'ground':ground(u),
  'order':u['order'],'orderQueue':u.get('orderQueue',[]),'claim':memory['unitClaims'].get(id),'mounted':any(id in job['unitIds']for job in memory.get('mounted',[])),
  'ferryAssignments':[{'hull':hid,'purpose':job['purpose'],'phase':job['phase'],'targetId':job['targetId']}for hid,job in memory['naval']['ferries'].items()if id in job['crewIds']],
  'p0IssuedCommandsThrough203400':owner_commands,'lateStaticFloorPoint':static_placement(u,cargo)})
# Earlier actual deck geometry has the same 15 initial local bodies as the
# last source's approach. Planned points below are hypothetical reservations,
# not actual future boarding or persisted native deck targets.
prior=frames['199834-after-step-native.json.gz']['snapshot'];prior_units={u['id']:u for u in prior['units']};prior_cargo=[u for u in prior['units']if u.get('deck',{}).get('shipId')==H]
later15=[unit_by_id[u['id']]for u in prior_cargo]
assert all(u['deck']==v['deck']and u.get('cabin')==v.get('cabin')and u['radius']==v['radius']for u,v in zip(prior_cargo,later15))
reserved=deepcopy(prior_cargo);planning=[]
for id in recruit['command']['unitIds']:
 point=static_placement(prior_units[id],reserved);assert point is not None
 planning.append({'id':id,'hypotheticalReservedPoint':point})
 clone=deepcopy(prior_units[id]);clone['deck']={'shipId':H,**point};reserved.append(clone)
four=[i for i in missing if i not in recruit['command']['unitIds']]
assert len(four)==4
remaining_after_plan=[{'id':id,'hypotheticalPointAfterNine':static_placement(prior_units[id],reserved)}for id in four]
assert all(row['hypotheticalPointAfterNine']is None for row in remaining_after_plan)
actual_arrivals=[]
for event in events:
 if event['type']!='observed-parent-change'or not(202400<=event['tick']<=202600):continue
 after=event['after']
 if after.get('deck',{}).get('shipId')!=H:continue
 tick=event['tick'];id=after['id'];frame=frames[str(tick)+'-after-step-native.json.gz'];all_units=frame['snapshot']['units']
 actual=next(u for u in all_units if u['id']==id);others=[u for u in all_units if u.get('deck',{}).get('shipId')==H and u['id']!=id]
 point=static_placement(actual,others)
 assert point=={k:actual['deck'][k]for k in ['x','y']}
 actual_arrivals.append({'id':id,'tick':tick,'eventIndex':event['eventIndex'],'actualDeckPoint':actual['deck'],'staticPointWithJustThisArrivingBodyExcluded':point,'exact':True})
assert len(actual_arrivals)==8
pickup_component=ground(mission['pickup'])['component'];missing_components={ground(unit_by_id[i])['component']for i in missing};assert missing_components=={pickup_component}
# All five are still alive with unchanged HP in bracketing actual frames.
status_frames=[]
for name in ['199834-after-step-native.json.gz','200400-periodic-after-step.json.gz','202548-after-step-native.json.gz','202800-periodic-after-step.json.gz','203400-periodic-after-step.json.gz']:
 frame=frames[name];s=frame['snapshot'];us={u['id']:u for u in s['units']};b=us[H];job=frame['memories']['p0']['naval']['ferries'][H]
 status_frames.append({'file':name,'tick':s['tick'],'boat':{'x':b['x'],'y':b['y'],'heading':b['sailing']['heading'],'order':b['order'],'load':b['sailing']['load']},'phase':job['phase'],'cabinStage':job.get('cabinLoad'),'pickup':job.get('pickup'),'progressTick':job['progress']['tick'],'manifestCount':len(job['crewIds']),'cargoCount':sum(u.get('deck',{}).get('shipId')==H for u in s['units']),
  'missing':[{'id':id,'hp':us[id]['hp'],'x':us[id]['x'],'y':us[id]['y'],'order':us[id]['order'],'deck':us[id].get('deck'),'cabin':us[id].get('cabin')}for id in missing]})
late=frames['203400-periodic-after-step.json.gz'];job=late['memories']['p0']['naval']['ferries'][H]
assert job['phase']=='return'and job['progress']['tick']==203370
cancel=next(row for row in commands if row['tick']==203370 and row['owner']=='p0'and H in row['command'].get('unitIds',[])and row['command']['type']=='unload')
shore_commands=[row for row in commands if row['tick']==207915 and row['owner']=='p0'and(row['command'].get('transportId')==H or row['command']['type']=='leaveCabin')]
assert len([r for r in shore_commands if r['command']['type']=='unloadPassenger'])==23
assert len([r for r in shore_commands if r['command']['type']=='leaveCabin'])==10
source_refs=[
 {'file':'src/ai/policy/naval.ts','line':421,'meaning':'cabin roster applies actual availability and same-target assignment before force witness fills'},
 {'file':'src/ai/policy/naval.ts','line':891,'meaning':'source roster/crew admission; current pickup defines loadGround'},
 {'file':'src/ai/policy/naval.ts','line':930,'meaning':'same-ground available sourceSoldiers, then riderFerryCrew arrival ordering'},
 {'file':'src/ai/policy/naval.ts','line':962,'meaning':'future boardUnit reserved shadow filters crew in sequential proposed order; those deck points are not put in public board intent'},
 {'file':'src/ai/policy/naval.ts','line':976,'meaning':'boarding/crew/cabin waiting precede actual expedition-force departure check'},
 {'file':'src/ai/policy/naval.ts','line':1012,'meaning':'alternative pickups exclude units on current loadGround and require physical convoyCanCarry'},
 {'file':'src/ai/policy/naval.ts','line':784,'meaning':'physical progress only; strict 40s timeout and no other same-phase ferry exception here'},
 {'file':'src/ai/policy/ferry-cabin.ts','line':69,'meaning':'free quota reserved at actual cabin cost; if only1 remains, 2-cost walkers are not selected'},
 {'file':'src/shared/decks.ts','line':59,'meaning':'native actual boardUnit uses the current floor and does not honor a prior future reservation'},
 {'file':'src/shared/sim.ts','line':1997,'meaning':'alongside attempt clears board order to idle even when boardUnit fails'},
 {'file':'src/shared/ship-cabin-quota.ts','line':37,'meaning':'actual 10 inside cost20; remaining budget1 is distinct from people, floor and weight'},
 {'file':'src/ai/policy/naval.ts','line':1102,'meaning':'global force witness is sorted by rating/mass, not a fully packed actual convoy'}]
result={
 'classification':'Independent read-only shortfall diagnosis at fixed a7e0ccaa. Python reads stored JSON and literal source-defined geometry/arithmetic only. No Game/native run/step/command apply, no TS imports, no test or full planner; no source or original D edits.',
 'sourcePre':pre,'sourcePost':source_proof(),
 'anchor':{'tick':202800,'actualCargoCount':23,'inside':10,'openDeckCount':13,'mass':2392,'required':metric['required'],'actualPower':actual_power,'recordedOriginalFunctionPower':metric['actualPermanentArmyPower'],'staticArithmeticDifference':actual_power-metric['actualPermanentArmyPower'],'deficitToRequired':metric['required']-actual_power,'globalWitnessCount':28,'globalWitnessPower':global_power,'globalWitnessMass':sum(mass(unit_by_id[i])for i in metric['globalSelectedWitness']),'globalReadyFromExistingMetric':metric['globalReady'],'globalWitnessIsNotLoaded':True},
 'missingFive':missing_rows,
 'island':{'pickup':mission['pickup'],'nativeSharedBoardShore':{'x':7120,'y':5968},'nativeSharedBerth':{'x':7024,'y':5880,'heading':0},'pickupGround':ground(mission['pickup']),'boardShoreGround':ground({'x':7120,'y':5968}),'originalSource':mission['from'],'originalSourceGround':ground(mission['from']),'enemyTargetGround':ground({'x':8352,'y':5504}),
  'onPickupGroundMines':[{'id':m['id'],'x':m['x'],'y':m['y'],'amount':m['amount']}for m in snap['resources']if ground(m)['component']==pickup_component],
  'ownBuildingsOnPickupGround':[b['id']for b in snap['buildings']if b['owner']=='p0'and ground(b)['component']==pickup_component],
  'hostileLandUnitsOnPickupGround':[u['id']for u in snap['units']if u['owner']in ['p1','p2']and not u.get('deck')and ground(u)['component']==pickup_component]},
 'ownershipAndQueueEvidence':{'soleFerry':list(memory['naval']['ferries']),'outfit':memory['naval'].get('outfit'),'mounted':memory.get('mounted'), 'allMissingOwnAliveNoDeckNoCabinNoQueueNoClaims':True,'notes':'Four excluded from actual board manifest have no p0-issued unit command in natural-tail prefix through203400. Summoner7979 is the only missing unit in this ferry manifest. No other ferry/service or paid production queue is shown as the cause. Wounded19557/19660 are alive and unchanged; not casualties during loading.'},
 'capacity':{'actualLoad':2392,'profileLoadCapacity':raw_geom['loadCapacity']*scale**2,'globalWitnessMass':5057,'weightNotTheLimit':True,'cabinCapacity':21,'actualCabinUsed':20,'freeCabinQuota':1,'walkingCost':2,'lastRealCabinEntry':{'tick':198664,'id':'unit-p0-ashHexer-4420'},'gate':'Free1 rejects every further 2-cost walking crew; stage deck returns normal deck admission. Remaining live open bodies continue to occupy floor.'},
 'earliestObservedAdmissionGap':{'publicRecruitmentTick':199860,'publicCommand':recruit,'earlierActualGeometryFrame':'199834-after-step-native.json.gz','initialCargo':15,'inside':10,'initial15LocalDeckGeometryMatches202800':True,'proposedBoardOrderPoints':planning,'fourNotRequestedAfterNinePacking':remaining_after_plan,
  'scope':'These nine points are read-only hypothetical future reservations using the actual prior local geometry. They were not stored public deck targets and are not claimed as actual boarding. No exact199860 before-p0 full frame exists in this evidence set.'},
 'actualArrivalOrder':actual_arrivals,
 'lastBoarder':{'id':'unit-p0-summoner-7979','wasActuallyRequested':True,'actualAttachmentEventThrough203400':False,'lastObservedBoardingFrame':'202548-after-step-native.json.gz','lastObservedBoardPosition':{'x':7100.964061847055,'y':5984.0458202314285},'by202800':{'x':7120,'y':5968,'order':'idle','deck':None},'allMissingHaveNoPointInActual202800Layout':all(r['lateStaticFloorPoint']is None for r in missing_rows),
  'inference':'Actual floor is filled by a different arrival order. The saved command history contains no p0 stop/replacement for7979 between its199860 board and203370 cast; with its living own target ship and no attachment event, native ferryUnits failure-to-idle is the supported cause. The exact failed-attempt tick/boardingBlocked effect was not captured and is not asserted.'},
 'timeout':{'lastMeasuredProgressTickFromSavedMemory':202560,'lastActualCargoAttachmentTick':202548,'timeoutTicks':800,'previousThink':203355,'previousElapsed':795,'firstStrictTimeoutThink':203370,'elapsed':810,'otherFerryExceptionAvailable':False,'observedCommand':cancel,'returnConfirmedByActual203400Full':True,
  'path':'No new cargo/cabin transition, >32 hull displacement, sufficient yaw sweep or actual enter-cabin walk refreshes progress. Actual force remains17.57895<20.11557; same-island missing bodies cannot be chosen as a different-island pickup. Strict physical-progress timeout cancels and preserves cargo for source return.'},
 'storedFrameCoverage':{'202560FullExists':False,'203370FullExists':False,'lastNearbyBoardingFull':'202548-after-step-native.json.gz','anchorFull':'202800-periodic-after-step.json.gz','afterTimeoutFull':'203400-periodic-after-step.json.gz','noReconstructionPerformed':True},
 'returnEvidence':{'publicTick':207915,'openPortraitsBeforeFirstLeave':next(i for i,r in enumerate(shore_commands)if r['command']['type']=='leaveCabin'),'leaveCommands':10,'portraitCommands':23,'interpretation':'Real return to original source, not an enemy landing. Parent independently owns the only207600→208200 native cold validation; this diagnosis only reads the original live-tail records.'},
 'actualStatusFrames':status_frames,'sourceReferences':source_refs,
 'limits':['No exact199860 roster/private availability trace was saved; exclusion by sequential deck fitting is a source-chain inference supported by the identical earlier local deck state, actual public9-man request and exhausted floor. The global28 witness is sampled202800, not falsely claimed as a saved199860 planner result.',
 'Python deck arithmetic matches all eight observed actual boarding local points exactly, but is not a new native simulation or a strategy result.',
 'Historical raw commands/hits/events are captured immutable prefixes through208200 while the natural tail continues. No ledger attribution is reconstructed.',
 'This is a loading/readiness failure followed by source return; no full match victory, enemy-coast deployment, generalized bootstrap acceptance or recovery of original inaccessible-container uncommitted work is claimed.'],
 'inputProvenance':input_provenance
}
(O/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'relevant-commands.json').write_text(json.dumps({'recruit':recruit,'missingIssuerCommands':{row['id']:row['p0IssuedCommandsThrough203400']for row in missing_rows},'cancel':cancel,'returnSequence':shore_commands},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'anchor':result['anchor'],'missing':[{k:r[k]for k in ['id','hp','mass','power','lateStaticFloorPoint']}for r in missing_rows],'geometry':'8/8 actual local points exactly match source arithmetic','sourcePost':result['sourcePost'],'resultBytes':(O/'result.json').stat().st_size},indent=2))
