from pathlib import Path
import json,hashlib,subprocess,tarfile
D=Path(__file__).resolve().parent; cap=json.loads((D/'fixed-runtime-natural-tail.json').read_text());root=Path(cap['sourceRoot'])
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[p for p,h in cap['hashes'].items() if sha((root/p).read_bytes())!=h]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
archive=D/'candidate-source.tar.gz';members={}
with tarfile.open(archive,'r|gz') as tar:
 for m in tar:
  if m.isfile():members[m.name.removeprefix('./')]=sha(tar.extractfile(m).read())
archive_exact=members==cap['hashes']
manifest=json.loads((root/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
result={'sourceHead':head,'files':len(cap['hashes']),'changed':changed,'gitStatus':status,'sourceArchiveFiles':len(members),'sourceArchiveMatchesRuntimeHashesExactly':archive_exact,'rulesVersion':manifest['rulesVersion'],'originalUncommittedRecoveryGap':'Original inaccessible container uncommitted changes remain unrecovered; this isolated candidate derives only from committed ade and explicit local candidate work.'}
assert not changed and not status and head==cap['head'] and archive_exact
(D/'final-source-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
