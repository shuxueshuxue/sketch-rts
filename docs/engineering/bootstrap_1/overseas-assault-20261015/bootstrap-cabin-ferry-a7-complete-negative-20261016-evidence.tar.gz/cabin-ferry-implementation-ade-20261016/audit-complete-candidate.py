from pathlib import Path
import gzip, json, hashlib, collections, datetime

D=Path(__file__).resolve().parent
W=D/'native-candidate-194400-195600'
T=D/'native-candidate-natural-from195600'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def full(p): return json.loads(gzip.decompress(p.read_bytes()))
def stream(p):
    with p.open() as h:
        for line in h:
            if line.strip(): yield json.loads(line)
launch=json.loads((W/'actual-launch.json').read_text())
initial=full(Path(launch['inputPath'])); final=full(T/'final.json.gz')
reports=[json.loads((p/'report.json').read_text()) for p in [W,T]]
events=[e for p in [W,T] for e in stream(p/'events.jsonl')]
permanent=[e for e in events if e['type']=='native-unit-terminal' and e['permanent']]
owners=[e for e in events if e['type']=='owner-change']
births=[e['unit'] for e in events if e['type']=='unit-birth-observed' and e['unit'].get('expiresTick') is None]
removed={e['previous']['id']:e for e in events if e['type']=='unit-removal'}
death_rows=[]
for e in permanent:
    u=e.get('atObservation') or e['previous']; removal=removed.get(e['id'])
    death_rows.append({'id':e['id'],'owner':u['owner'],'kind':u['kind'],'tick':e['tick'],
      'terminalObservedAs':e['observedAs'],'terminalHp':u['hp'],'removalConfirmed':removal is not None,
      'removalTick':removal and removal['tick'],'lastNativeHit':e.get('lastNativeHit'),
      'preStepHull':e.get('preStepHull'),'preStepCarryingHull':e.get('preStepCarryingHull'),
      'deckAtTerminal':u.get('deck'),'cabinAtTerminal':u.get('cabin')})
ship_ids={u['id'] for u in initial['snapshot']['units']+final['snapshot']['units']+births if u.get('sailing')}
ships=[]
for id in sorted(ship_ids):
    before=next((u for u in initial['snapshot']['units'] if u['id']==id),None)
    after=next((u for u in final['snapshot']['units'] if u['id']==id),None)
    born=next((u for u in births if u['id']==id),None)
    if (before or after or born)['owner']!='p0': continue
    ships.append({'id':id,'initial':before,'birth':born,'final':after,
      'terminals':[e for e in death_rows if e['id']==id],
      'ownerChanges':[e for e in owners if e['before']['id']==id],
      'classification':'native death/removal confirmed' if any(e['id']==id and e['removalConfirmed'] for e in death_rows) else 'present at final' if after else 'unexplained absence'})
balance={}
for owner in ['p0','p1','p2']:
    start={u['id'] for u in initial['snapshot']['units'] if u['owner']==owner and u['hp']>0 and u.get('expiresTick') is None}
    end={u['id'] for u in final['snapshot']['units'] if u['owner']==owner and u['hp']>0 and u.get('expiresTick') is None}
    born={u['id'] for u in births if u['owner']==owner}
    dead={e['id'] for e in death_rows if e['owner']==owner}
    incoming={e['after']['id'] for e in owners if e['after']['owner']==owner and e['after'].get('expiresTick') is None}
    outgoing={e['before']['id'] for e in owners if e['before']['owner']==owner and e['before'].get('expiresTick') is None}
    expected=(start|born|incoming)-dead-outgoing
    balance[owner]={'start':len(start),'births':len(born),'nativePermanentTerminals':len(dead),'capturedIn':len(incoming),'capturedOut':len(outgoing),'final':len(end),'exactSetBalance':expected==end,'missing':sorted(expected-end),'unexpected':sorted(end-expected)}
raw={}
for name,key in [('commands','commandIndex'),('hits','hitIndex'),('events','eventIndex')]:
    seq=[x for p in [W,T] for x in stream(p/(name+'.jsonl'))]
    raw[name]={'rows':len(seq),'firstOrdinal':0 if seq else None,'lastOrdinal':len(seq)-1 if seq else None,'explicitIndicesExactlyMatchCombinedOrdinal':all(key not in row or row[key]==i for i,row in enumerate(seq)),
      'indexScope':'Focus stream has implicit zero-based line ordinals; tail carries explicit candidate-global indices. No missing index field is invented in original raw.',
      'files':[{'path':str(p/(name+'.jsonl')),'bytes':(p/(name+'.jsonl')).stat().st_size,'sha256':sha(p/(name+'.jsonl'))} for p in [W,T]]}
    if name=='hits': raw[name]['last']=seq[-1] if seq else None
stats_initial=initial['snapshot']['match']['stats'];stats_final=final['snapshot']['match']['stats']
statdiff={k:{owner:stats_final[k].get(owner,0)-stats_initial[k].get(owner,0) for owner in ['p0','p1','p2']} for k in stats_final}
out={'classification':'Closed normal3AI changed-code a7 continuation194400 through supported observation stop310800. True ade baseline exists only194400..195000. No ordinary0/full-win claim.',
 'sourceHead':reports[-1]['head'],'range':[initial['snapshot']['tick'],final['snapshot']['tick']],
 'winner':final['snapshot']['match']['winner'],'naturalComplete':reports[-1]['naturalComplete'],'observationStopped':reports[-1]['observationStopped'],
 'sourceFrozenPrePost':[{k:r[k] for k in ['sourcePre','sourcePost','frozenPre','frozenPost','restored']} for r in reports],
 'raw':raw,'permanentBalance':balance,'permanentTerminals':death_rows,'allOwnerChanges':owners,'ownHulls':ships,
 'nativeStatsInitial':stats_initial,'nativeStatsFinal':stats_final,'nativeStatsDelta':statdiff,
 'accountingLimit':'Native unitsLost counts permanent and temporary combat losses under native semantics; cumulative92 is neither8 own permanent losses of this continuation nor56 of the unrelated e566 ordinary0. Terminal vs cleanup, temporary expiry, owner capture and hull passengers remain separate.',
 'input':{'path':launch['inputPath'],'sha256':sha(Path(launch['inputPath']))},
 'final':{'path':str(T/'final.json.gz'),'sha256':sha(T/'final.json.gz'),'bytes':(T/'final.json.gz').stat().st_size},
 'process':{'pid':reports[-1]['pid'],'startUtc':reports[-1]['startedAtUtc'],'endUtc':reports[-1]['endedAtUtc'],'actualExecSession':3670,'observedToolExitCode':0},
 'scope':'No replay, Game, planner, test or source mutation performed by this audit. Full streamed rows and explicit complete-state identity accounting only.'}
assert all(x['exactSetBalance'] for x in balance.values())
assert all(x['explicitIndicesExactlyMatchCombinedOrdinal'] for x in raw.values())
assert all(e['removalConfirmed'] for e in death_rows)
(D/'complete-candidate-ledger-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'range':out['range'],'winner':out['winner'],'naturalComplete':out['naturalComplete'],'observationStopped':out['observationStopped'],'rawCounts':{k:v['rows'] for k,v in raw.items()},'permanentBalance':balance,'ownHulls':[{k:s[k] for k in ['id','classification','ownerChanges']} for s in ships],'nativeUnitsLostDelta':statdiff['unitsLost'],'auditSHA256':sha(D/'complete-candidate-ledger-audit.json')},ensure_ascii=False))
