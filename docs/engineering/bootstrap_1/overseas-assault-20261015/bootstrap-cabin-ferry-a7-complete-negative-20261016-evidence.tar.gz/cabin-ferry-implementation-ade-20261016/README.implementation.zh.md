# 独立 cabin ferry 候选，当前未完成整局验证

固定源码 `/workspace/sketch-rts-cabin-ferry-ade-control`，detached `a7e0ccaa108c7eab1ebd959ff312dd378eb8e804`，基于 `ade412414d9232206f39e20f0182f0086605433c`。15 个文件包括 8 生产文件、6 测试文件和原始完整 fixture。root、main、af 活动源码不改；未提交旧容器修改的恢复缺口仍然存在。

本候选只让 bootstrap 显式选择 `assaultCargo: 'cabin'`。同一实际目标的可用 roster 用于 source、本岸 loading 和 pickup；实际质量、holdMass、quota、native board packing 与静态 hatch 连通分别检查。只有真实入舱才腾出实际甲板地面，不把 issued enter/stage/schema 当进展；保留原 40/20 秒窗口、思考 15 tick 和 required 1.4。机械单位只有实际合法的源岸公开 portrait 序列才能清门，再由正常 AI 决定重新装载。

卸岸用逐人真实 open portrait、inside leave、portrait 的同序 shadow。shared 岸前部署只计 sailing 的原 450 邻近贡献；A-B-C 中每艘局部贡献船都必须过同一门，未完成则保留原 rally。bootstrap 收集本帧真正到达 callback 的船，排除 loading/缺席/blocked 成员，重算实际发布集合与 shadow。真正投影计划按 snapshot 船序先发布，其余 batch 普通输出及普通 naval prefix 随后执行，避免先落岸的其它身体污染投影。有限 actor/target 保护位于 bootstrap 记命令 memory 之前，通用 runner 未改。

`candidate-source.tar.gz` 包含 1474 份完整源码，SHA256 `5896df3b433a782c515499f2e021d1861deab23d0ec88cb9b34cedba308c5c91`，4,487,394 B，全部读回相同。`candidate-source-proof.json` 另记录原 497 份冻结 archive、184 项 manifest 全字节核对，rulesVersion 2、revision d1ae110f。冻结策略战术与生产 API 等价基线未改，不增减对手资源或人口。

验证分两次，不相加覆盖数量：最终发布顺序修正前 17 文件 200 项为 196 通过、4 失败；唯一失败来自既有 `assault-retarget-deployment.test.ts` 的 89625 反事实期望，独立原 ade 同 6 项也为 2 通过、4 同样失败，保留全部日志与 fixture。最后发布顺序修正后，受影响 4 文件 60 项全部通过；最终 tsc 工具进程 exit0，diffcheck 干净。原 helper/new batch SDK 合同区分了 open hp0 原生可卸与 inside hp0 原生不可出舱；新部署力和 alreadyLanded 只计活兵，不改全局 rating。

正常 AI 原始对照是 **ade 194400→195000，仅600 tick**：完整 world/nextId/3mem 恢复一致；1464 源与规则2/184冻结前后不变，709 command trace、0 hit、76 ledger events、40 p0 plans。194610 真实 loading 超时返程，195000 cargo0/inside0/winnernull。此前能力封包中的人工 enter/unload 分支独立归属，不能当此正常对照或候选成绩。

正常候选聚焦是 **a7e0ccaa 194400→195600，1200 tick**，无任何人工追加公开命令：1019 command trace、4 native hit、126 ledger events、80 p0 plans。1474 源与184冻结前后不变。三 ram 真正公开卸岸，8 原 walking crew 在194418/433/447/467/489/510/532/572 的 after-step 真实入舱，实际 cargo mass873、quota used16/21。195600 仍 loading，原 required20.115569375546702，8 实际永久 cargo strength6.375518456350104，未足够出航。1180 仍在另一枯矿岛(3472,2416)发真实 board 意图，不能算已装入；carrier 已实际朝 pickup 航行。

原生 client 图片是完整实际帧的静态 drawWorld 渲染，非人工操作或 Game 重造。`true-baseline-194400.png` 显示三 ram 与八 walking crew 的实际拥挤甲板；`candidate-194580-actual-inside.png` 的露天甲板为空，inside 人数由原生完整字段与 cabin events 证实；`candidate-195600-actual-pickup.png` 显示实际航程位置。每张附输入/PNG/renderer SHA 与 full-state 未变记录。

同源自然尾局已单独恢复195600完整末态，driver `native-cabin-natural-tail.ts`，输出 `native-candidate-natural-from195600/`。195600 是原 window 完成 native step 后、下个 think 前，不 doublethink。命令/命中/永久死亡及 cabin transition 全流保存；原窗口 counts 作为 candidate 内连续索引基数。只有12个 recent samples 留内存，每600 tick完整 after-step world/id/3mem checkpoint；mid-command/transition capture 只是观察档，不能自动当恢复起点。Number.MAX_SAFE_INTEGER 只是无实际任意 horizon；明确父授权 observation-stop 可在完整600边界 observer异常保全，不改 winner。当前未有自然结局，不是新 ordinary0 或 bootstrap 验收。

尾局 stdout 的 `carrierInside` 数字实际是 `shipCabinUsage.used` **额度**，不是人数；完整 `cargo` 的 cabin 字段提供人数。这一观察字段命名限制保留，不热改已运行 driver。历史 lastHit 只继承真实旧分支 tick<194400 与本候选 window tick<195600，不能混旧078在194400之后的反事实命中。

原同源尾局现已完成受支持的观察停止：实际 PID333917 于2026-10-16T06:08:12.423Z正常 exit0，195600→310800，winnernull、naturalCompletefalse、observationStoppedtrue。请求在06:08:09.728822Z写入，下一个600完整边界由原 driver 自行保全；未杀进程、改世界或 winner。尾段155324 command、252 hit、12343 ledger events、7680 p0 plans；连同前1200聚焦为156343 command、256 hit、12469 events。完整原始流、全部周期 fullworld/nextId/3mem、最终 gzip、输入恢复与1474源/184冻结前后字节不变记录均保留。这是换码续局，不是普通0、自然败、获胜或三路线验收。

实际装载最大为202800的23永久 cargo、10 inside、quota20/21、load2392/9060.48，永久军力17.578949757679904仍低于原required20.115569375546702。最后实际cargo变动202548，progress202560；203370严格810>800后原超时门返程。203370仅原始命令/观察流，不冒称当时现场已有完整pre-planner档。207915正常AI真发13条open portrait，再10组leave/portrait，23人真回原出发岸，208200 ferry解除。此处是返程卸岸，不能称敌岸部署。原全局28名单/质量5057并不等于实际可装；三个ravager与ram在preboard floor已不合，7979虽发board却在实际到达顺序中失去甲板位置。独立有限十种排序最好18.885184仍不足；固定原15人、剩余13名单与HP时，即使忽略几何最强十增援也仅20.085184，至少十一增援才能过门槛。该下界不适用于换舱/治疗/新单位，不证明所有装法不可能。

唯一207600→208200冷重放已封在`cold-return-window-207600-208200/`：600原生步、40个before-p0全world/id/3mem hash、874公开命令、2 native hits和最终完整状态全等。before-p0完整帧由重建保存，对照原局现场完整hash，不能把它写成原局原始fullcapture。207915的33条实际命令均原生合法且确实改快照，23人的即时身体/落点/HP/亲属字段与逐人shadow全等。207923另有两次己方碰撞实伤（船受0.001036245，8581受1.285129119），所以不是整个窗口零伤。最初保守guard只prepared、不创建Game；随后父授权新名字guard在真实cgroup余量≥2GiB且heap1024时唯一启动，原日志保留。另195570→195600的30tick冷闭合也只是该范围，未覆盖入舱/卸岸。

完整续局己方永久损失8：ravager23742、summoner42066/38359、bombardShip50739、warship4058、cutter124021、carrier25442、transport151315。所有原生cleanup有证，所有owner-change为0，未被俘；五艘船死亡前无活乘员，42066/38359是在warship4058尚活时分别被敌射手击杀。194400原己79永久+期间2真出生−8死=终73，敌p1损3/p2损1，集合逐ID闭合。native累计unitsLost是92，本段原生统计增12，其中8永久；它不等于永久死亡数，也不能混成别的e566普通0的56。最后carrier220045和新transport222876均空船在正常evacuate任务走敌岸途中被ravager杀死；不是本候选已打过敌主岛或cabin直接害死所有船的证明。ade正常基线只跑600，不能擅自向后推比较胜负或总损。

停止依据是有界战略停滞。授权前228600→282600共91个完整600tick检查与全raw证实stats、现金93.33、永久兵/建筑ID、22500剩矿、空paidqueue与ferries{}不变，0hit/0永久或建筑terminal。封档后扩到310800共138个同样检查仍全真。223200→228300确有真实维修支出，旧含该范围的非均一query保留，不能把全程说成静止；临时灵体、命令和坐标也不声称不变。

终态纯导出`final-strategic-state-query.json`给出所有军队实际order/pose/target与完整当前宏目标：38永久陆军全部idle、32工全部idle；3艘存活warship为hold/idle/idle，没有ferry或mine命令。现金93.33，另4工各携10共40不可漏；无在产可退款队列。三剩矿各7500，均无本方同岛军工，sat1有6敌陆兵；sat2两neutral仍7/20HP、各45赏金，但未证明可安全触及，不能据当前现金称数学无恢复途径。实际transport240/carrier420，不能借别源价格。现物仅三舰已装的shipCannon，无散落/携带物，当前GameCommand没有卖物命令；装备效用或购价不当作可花现金。原生全图、202800拥挤甲板、208200回岸部队和310800主军图均由实际完整状态静态drawWorld生成，亲看后归档。

候选尚未合入root。它证实正常AI会真实清ram/入舱/接兵/出舱，却未达到原required或完成进攻；下一工作需用真实floor packing、换舱和合法装载次序做充分微操，再以完整比赛验证，不能降低required、改船体/HP/舱位或人工补金。原容器未提交修改的恢复缺口继续保留。
