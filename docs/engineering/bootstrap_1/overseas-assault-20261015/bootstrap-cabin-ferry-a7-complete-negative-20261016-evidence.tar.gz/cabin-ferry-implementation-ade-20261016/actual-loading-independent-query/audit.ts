import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { passengerLandingSpot } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/naval.ts';
import { shipPassengers } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/ship-geometry.ts';
import { bodyMass } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/physical-body.ts';
import { deckLoad } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/decks.ts';
import { isInCabin, cabinSpaceRequired, shipCabinUsage } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/ship-cabin.ts';
import { assaultExpedition } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/ai/policy/naval.ts';
import { effectiveCombatRating } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/ai/policy/v6/strength.ts';
import { sameGround, walkableGoal } from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/terrain.ts';
const D='/workspace/.playtest/cabin-ferry-implementation-ade-20261016';
const O=D+'/actual-loading-independent-query', C=D+'/native-candidate-194400-195600', B=D+'/native-baseline-194400-195000';
const root='/workspace/sketch-rts-cabin-ferry-ade-control', hullId='unit-p0-carrier-25442';
const sha=(value:any)=>createHash('sha256').update(value).digest('hex');
const read=(path:string)=>JSON.parse(readFileSync(path,'utf8'));
const gz=(path:string)=>JSON.parse(gunzipSync(readFileSync(path)).toString());
const rows=(path:string)=>readFileSync(path,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));
const assert=(yes:any,message:string)=>{if(!yes)throw new Error(message);};
const cap=read(D+'/fixed-runtime-candidate.json');
const sourceProof=()=>{
 const head=execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
 const status=execFileSync('git',['-C',root,'status','--porcelain'],{encoding:'utf8'});
 const changed=Object.entries(cap.hashes).filter(([path,hash])=>sha(readFileSync(root+'/'+path))!==hash).map(([path])=>path);
 assert(head==='a7e0ccaa108c7eab1ebd959ff312dd378eb8e804'&&!status&&!changed.length,'fixed source changed');
 return {head,status,files:Object.keys(cap.hashes).length,changed};
};
const pre=sourceProof();
const firstPath=C+'/frames/194400-before-p0.json.gz',first=gz(firstPath),baselineFirst=gz(B+'/frames/194400-before-p0.json.gz');
assert(isDeepStrictEqual(first,baselineFirst),'candidate/baseline full first frame differ');
const original=JSON.stringify(first), snapshot=first.snapshot, boat=snapshot.units.find((u:any)=>u.id===hullId);
const cargo=shipPassengers(snapshot.units,boat), walkers=cargo.filter((u:any)=>u.kind!=='siegeRam'), rams=cargo.filter((u:any)=>u.kind==='siegeRam');
const commands=rows(C+'/commands.jsonl'),effects=rows(C+'/frame-entry-effects.jsonl'),cabinEvents=rows(C+'/cabin-events.jsonl');
const initialCommands=commands.filter((r:any)=>r.tick===194400&&r.owner==='p0'&&r.scriptId==='naval');
assert(isDeepStrictEqual(initialCommands.map((r:any)=>r.command.type),['unload','unloadPassenger','unloadPassenger','unloadPassenger','stop']),'first public clear sequence differs');
const unload=initialCommands[0].command,shore={x:unload.x,y:unload.y};
assert(Math.abs(boat.sailing.speed)<=.1&&Math.hypot(boat.sailing.velocityX??0,boat.sailing.velocityY??0)<=1e-6,'initial hull moving');
const ship={...boat,order:{type:'unload',...shore,avoidCombat:true}};
const shadow=snapshot.units.map((u:any)=>u.id===hullId?ship:u);
const ramChecks=[];
for(const entry of initialCommands.filter((r:any)=>r.command.type==='unloadPassenger')){
 const id=entry.command.passengerId, passenger=shadow.find((u:any)=>u.id===id);
 const point=passengerLandingSpot(snapshot.map,ship,id,shadow);
 const effect=effects.find((r:any)=>r.tick===entry.tick&&r.command.type==='unloadPassenger'&&r.command.passengerId===id);
 const before=effect?.before.find((u:any)=>u.id===id),after=effect?.after.find((u:any)=>u.id===id);
 const beforeHull=effect?.before.find((u:any)=>u.id===hullId),afterHull=effect?.after.find((u:any)=>u.id===hullId);
 assert(point&&effect&&before&&after&&beforeHull&&afterHull,'missing native ram effect');
 assert(effect.legalityBefore===null&&effect.snapshotChanged===true,'ram trace without real legal effect');
 assert(before.deck?.shipId===hullId&&!before.cabin&&!after.deck&&!after.cabin,'ram did not detach');
 assert(point.x===after.x&&point.y===after.y,'native ram xy differs from original sequential shadow');
 assert(sameGround(snapshot.map,point,walkableGoal(snapshot.map,shore.x,shore.y)),'ram lands on wrong source ground');
 assert(before.hp===after.hp&&bodyMass(before)===bodyMass(after),'ram hp/mass changed during portrait');
 assert(beforeHull.sailing.load-afterHull.sailing.load===bodyMass(passenger),'ram unloading did not remove exact mass');
 ramChecks.push({id,tick:entry.tick,point,actual:{x:after.x,y:after.y},exactXY:true,sourceGround:true,
  before:{hp:before.hp,deck:before.deck,cabin:before.cabin??null,boatLoad:beforeHull.sailing.load},
  after:{hp:after.hp,deck:after.deck??null,cabin:after.cabin??null,boatLoad:afterHull.sailing.load},
  bodyMass:bodyMass(passenger),legalityBefore:effect.legalityBefore,snapshotChanged:effect.snapshotChanged});
 shadow[shadow.findIndex((u:any)=>u.id===id)]={...passenger,...point,deck:undefined,cabin:undefined};
}
assert(ramChecks.length===3,'expected three real rams');
const lastRam=effects.find((r:any)=>r.tick===194400&&r.command.type==='unloadPassenger'&&r.command.passengerId===rams.at(-1)!.id);
const afterRamCargo=lastRam.after.filter((u:any)=>u.deck?.shipId===hullId),afterRamHull=lastRam.after.find((u:any)=>u.id===hullId);
assert(afterRamCargo.length===8&&afterRamCargo.every((u:any)=>!isInCabin(u)),'walkers unloaded or credited cabin during clear');
assert(afterRamHull.sailing.load===873&&deckLoad(lastRam.after,afterRamHull)===873,'after-clear payload mismatch');
const enter=effects.find((r:any)=>r.command.type==='enterCabin'&&r.command.unitIds.every((id:string)=>walkers.some((u:any)=>u.id===id)));
assert(enter&&enter.command.unitIds.length===8&&enter.tick===194415,'missing real enter order');
const entering=enter.after.filter((u:any)=>enter.command.unitIds.includes(u.id));
assert(entering.length===8&&entering.every((u:any)=>!isInCabin(u)&&u.deck?.shipId===hullId&&u.order.type==='enterCabin'),'enter trace already credited as entry');
const afterEnterHull=enter.after.find((u:any)=>u.id===hullId);
assert(afterEnterHull&&deckLoad(enter.after,afterEnterHull)===873&&afterEnterHull.sailing.load===873,'entry intent released mass');
const enterUsage=shipCabinUsage({units:enter.after,variants:snapshot.variants},afterEnterHull);
assert(enterUsage.used===0,'entry intent prematurely credited cabin quota');
const firstAfter=gz(C+'/frames/194415-before-p0.json.gz'),firstAfterHull=firstAfter.snapshot.units.find((u:any)=>u.id===hullId);
assert(firstAfterHull.order.type==='idle'&&firstAfterHull.sailing.load===873,'first subsequent complete frame lacks stopped cleared hull');
const firstAfterRams=rams.map((ram:any)=>firstAfter.snapshot.units.find((u:any)=>u.id===ram.id));
assert(firstAfterRams.every((u:any)=>u&&u.hp===420&&!u.deck&&!u.cabin),'rams not retained alive ashore at next think');
const entryChecks=[];
assert(cabinEvents.length===8,'unexpected native cabin transitions');
for(let index=0;index<cabinEvents.length;index++){
 const event=cabinEvents[index], initial=walkers.find((u:any)=>u.id===event.id);
 const framePath=C+'/frames/'+event.tick+'-cabin-'+event.id+'-'+event.stage+'.json.gz';
 const frame=gz(framePath),s=frame.snapshot,h=s.units.find((u:any)=>u.id===hullId),u=s.units.find((u:any)=>u.id===event.id);
 const all=shipPassengers(s.units,h),inside=all.filter(isInCabin),usage=shipCabinUsage(s,h),mass=deckLoad(s.units,h);
 assert(initial&&event.stage==='after-step'&&event.from===null&&event.to===hullId&&isInCabin(u),'trace without actual cabin attachment');
 assert(u.hp===initial.hp&&u.hp===event.unit.hp&&u.maxHp===initial.maxHp,'crew hp changed at entry');
 assert(all.length===8&&mass===873&&h.sailing.load===873,'cabin entry released payload mass');
 assert(inside.length===index+1&&usage.used===2*(index+1)&&usage.overCapacity===0&&isDeepStrictEqual(usage,event.usage),'native quota mismatch');
 entryChecks.push({id:event.id,tick:event.tick,stage:event.stage,kind:u.kind,hp:u.hp,maxHp:u.maxHp,bodyMass:bodyMass(u),
  quotaCost:cabinSpaceRequired(s,u),usage,cargoCount:all.length,openFloorBodies:all.filter((u:any)=>!isInCabin(u)).length,
  actualInsideIds:inside.map((u:any)=>u.id),payloadMass:mass,sailingLoad:h.sailing.load,frame:framePath.slice(C.length+1)});
}
const final=gz(C+'/final.json.gz'),fs=final.snapshot,fh=fs.units.find((u:any)=>u.id===hullId),finalCargo=shipPassengers(fs.units,fh),finalMission=final.memories.p0.naval.ferries[hullId];
assert(final.snapshot.tick===195600,'candidate incomplete');
const persistence=[];
for(const name of readdirSync(C+'/frames').filter(name=>/^\d+-before-p0\.json\.gz$/.test(name)||name==='195600-final.json.gz').sort()){
 const frame=gz(C+'/frames/'+name),s=frame.snapshot,h=s.units.find((u:any)=>u.id===hullId),all=shipPassengers(s.units,h);
 const expectedEntered=cabinEvents.filter((e:any)=>e.tick<=s.tick).length;
 if(s.tick>194400){assert(all.length===8&&deckLoad(s.units,h)===873&&h.sailing.load===873,'later observed payload changes');}
 assert(all.filter(isInCabin).length===expectedEntered,'cabin transition regressed or credited early');
 const expectedCargo=s.tick===194400?cargo:walkers;
 assert(all.every((u:any)=>expectedCargo.some((v:any)=>v.id===u.id&&v.hp===u.hp&&v.maxHp===u.maxHp)),'crew state changed');
 persistence.push({tick:s.tick,inside:expectedEntered,openFloorBodies:all.filter((u:any)=>!isInCabin(u)).length});
}
assert(finalCargo.length===8&&finalCargo.every(isInCabin),'final eight not sheltered');
const baselineFinal=gz(B+'/final.json.gz'),bs=baselineFinal.snapshot,bh=bs.units.find((u:any)=>u.id===hullId),bc=shipPassengers(bs.units,bh);
const candidateReport=read(C+'/report.json'),baselineReport=read(B+'/report.json');
const finalBefore=JSON.stringify(final);
// The original admission helper reads only memory and teams from its context;
// do not invoke bootstrap context wants/planner or any route search.
const context={memory:final.memories.p0,teams:fs.teams};
const target=fs.buildings.find((b:any)=>b.id===finalMission.targetId);
assert(target,'actual target absent');
const required=assaultExpedition(fs,'p0',context,target).required;
const permanentCrew=finalCargo.filter((u:any)=>u.hp>0&&u.expiresTick===undefined&&u.kind!=='worker');
const crewPower=permanentCrew.reduce((sum:number,u:any)=>sum+effectiveCombatRating(fs,u),0);
const pending=fs.units.find((u:any)=>u.id==='unit-p0-emberRavager-1180');
const pendingEffect=effects.find((e:any)=>e.command.type==='board'&&e.command.unitIds.includes(pending.id));
assert(pending&&!pending.deck&&!pending.cabin&&pending.order.type==='board'&&pending.order.transportId===hullId,'pending pickup was not a real waiting board order');
assert(pendingEffect&&pendingEffect.after.find((u:any)=>u.id===pending.id)?.deck===undefined,'board trace already credited as aboard');
const pickup=walkableGoal(fs.map,finalMission.pickup.x,finalMission.pickup.y),originalShore=walkableGoal(fs.map,finalMission.from.x,finalMission.from.y);
const pendingAudit={id:pending.id,hp:pending.hp,maxHp:pending.maxHp,bodyMass:bodyMass(pending),quotaCost:cabinSpaceRequired(fs,pending),
 position:{x:pending.x,y:pending.y},deck:pending.deck??null,cabin:pending.cabin??null,order:pending.order,
 actualBoardOrderTick:pendingEffect.tick,legalityBefore:pendingEffect.legalityBefore,boardOrderAfterStillOffDeck:!pendingEffect.after.find((u:any)=>u.id===pending.id)?.deck,
 sameGroundAsActualPickup:sameGround(fs.map,pending,pickup),sameGroundAsOriginalSource:sameGround(fs.map,pending,originalShore),sameGroundAsEnemyTarget:sameGround(fs.map,pending,target),
 ownHallsOnPickupGround:fs.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall'&&sameGround(fs.map,b,pending)).map((b:any)=>({id:b.id,x:b.x,y:b.y})),
 pickupGroundMines:fs.resources.filter((m:any)=>sameGround(fs.map,m,pending)).map((m:any)=>({id:m.id,x:m.x,y:m.y,amount:m.amount}))};
assert(JSON.stringify(final)===finalBefore,'original admission query mutated final world/memory');
const baselineOriginalWalkers=walkers.map((u:any)=>bs.units.find((v:any)=>v.id===u.id));
const files=[firstPath,C+'/frames/194415-before-p0.json.gz',C+'/frame-entry-effects.jsonl',C+'/commands.jsonl',C+'/cabin-events.jsonl',C+'/final.json.gz',C+'/report.json',B+'/frames/194400-before-p0.json.gz',B+'/final.json.gz',B+'/report.json'];
const result={
 classification:'Read-only independent native static query audit of actual normal3AI continuation at fixed a7e0ccaa. No Game creation/step/command apply or full planner invoked; existing source and existing artifacts untouched.',
 sourcePre:pre,sourcePost:sourceProof(),inputFirstFrameEqualsBaselineWorldIdAll3Mem:true,
 initial:{tick:snapshot.tick,hullId,boatPose:{x:boat.x,y:boat.y,heading:boat.sailing.heading},boatLoad:boat.sailing.load,
  cargoCount:cargo.length,walkers:walkers.map((u:any)=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mass:bodyMass(u),quota:cabinSpaceRequired(snapshot,u)})),
  rams:rams.map((u:any)=>u.id),cabinUsage:shipCabinUsage(snapshot,boat)},
 clearDoor:{publicSequence:initialCommands.map((r:any)=>r.command),checks:ramChecks,afterLastPortrait:{cargoCount:afterRamCargo.length,openFloorBodies:afterRamCargo.filter((u:any)=>!isInCabin(u)).length,
  cabinUsed:shipCabinUsage({units:lastRam.after,variants:snapshot.variants},afterRamHull).used,payloadMass:deckLoad(lastRam.after,afterRamHull),nativeLoad:afterRamHull.sailing.load},
  firstSubsequentFullFrame:{tick:194415,boatOrder:firstAfterHull.order,boatLoad:firstAfterHull.sailing.load,threeRamsStillAliveAshore:firstAfterRams.every((u:any)=>u.hp===420&&!u.deck&&!u.cabin)},
  complete194400AfterFrameSaved:false,coverage:'All three native portrait before/after states are recorded. The stop has command trace only, no afterCommand effect row because this driver filters stop; the earliest subsequent full frame is 194415-before-p0, not a zero-step after-frame.'},
 enterOrder:{tick:enter.tick,ids:enter.command.unitIds,legalityBefore:enter.legalityBefore,snapshotChanged:enter.snapshotChanged,
  actualInsideImmediatelyAfter:entering.filter(isInCabin).length,stillOpenDeckAfter:entering.length,actualUsageAfterIntent:enterUsage,payloadMassAfterIntent:deckLoad(enter.after,afterEnterHull),nativeLoadAfterIntent:afterEnterHull.sailing.load,pendingQuota:entering.reduce((sum:number,u:any)=>sum+cabinSpaceRequired(snapshot,u),0),
  meaning:'This trace assigns walking intent. All eight still occupy open deck; actual cabin occupancy remains zero until after-step entry events.'},
 entries:entryChecks,persistence:{fullFramesChecked:persistence.length,allObservedCrewHPAndPayloadUnchanged:true,allObservedInsideCountsMatchActualTransitions:true,first:persistence[0],last:persistence.at(-1)},
 final:{tick:fs.tick,inside:finalCargo.filter(isInCabin).length,openFloorBodies:finalCargo.filter((u:any)=>!isInCabin(u)).length,
  payloadMass:deckLoad(fs.units,fh),nativeLoad:fh.sailing.load,usage:shipCabinUsage(fs,fh),boatHP:fh.hp,phase:finalMission.phase,
  from:finalMission.from,pickup:finalMission.pickup??null,to:finalMission.to,crewIds:finalMission.crewIds,winner:fs.match.winner},
 admissionAt195600:{required,actualPermanentCarrierCrew:permanentCrew.length,actualCrewPower:crewPower,powerBelowRequired:crewPower<required,payloadMass:deckLoad(fs.units,fh),crewRatings:permanentCrew.map((u:any)=>({id:u.id,rating:effectiveCombatRating(fs,u)})),pendingPickup:pendingAudit,scope:'Original assaultExpedition required only; unboarded global roster is not credited as real carrier force.'},
 baseline:{tick:bs.tick,originalEightStillPresent:baselineOriginalWalkers.every(Boolean),originalEightOffDeck:baselineOriginalWalkers.filter((u:any)=>u&&!u.deck&&!u.cabin).length,originalEightHPUnchanged:baselineOriginalWalkers.every((u:any)=>u&&walkers.some((v:any)=>v.id===u.id&&v.hp===u.hp)),head:baselineReport.sourcePost.head,cabinEventRows:rows(B+'/cabin-events.jsonl').length,cargoCount:bc.length,
  inside:bc.filter(isInCabin).length,payloadMass:deckLoad(bs.units,bh),nativeLoad:bh.sailing.load,boatHP:bh.hp},
 reportSourceProofs:{candidateSourcePost:candidateReport.sourcePost,candidateFrozenPost:candidateReport.frozenPost,baselineSourcePost:baselineReport.sourcePost},
 geometryScope:'This is actual source-coast door clearing and native cabin entry. This audited ferry made no enemy-coast joint landing in this window; SDK component contracts are not classified as real match deployment. No victory, full-match effect, or bootstrap completion claimed.',
 remainingEvidenceGap:'No complete same-tick 194400 after-frame was captured. Command-specific actual before/after records and later complete frames support the listed narrower claims. Original unavailable-container uncommitted-work gap remains.',
 provenance:files.map(path=>({path,bytes:readFileSync(path).length,sha256:sha(readFileSync(path))}))
};
assert(JSON.stringify(first)===original,'query mutated original frame');
writeFileSync(O+'/result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({result:O+'/result.json',source:pre.head,rams:ramChecks.map(r=>({id:r.id,point:r.point,loadBefore:r.before.boatLoad,loadAfter:r.after.boatLoad})),entries:entryChecks.map(e=>({id:e.id,tick:e.tick,hp:e.hp,mass:e.bodyMass,used:e.usage.used})),persistence:result.persistence,final:result.final,admission:result.admissionAt195600,baseline:result.baseline},null,2));
