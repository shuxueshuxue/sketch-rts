import{readFileSync,writeFileSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{createHash}from'node:crypto';
import{pathToFileURL}from'node:url';
const S='/workspace/sketch-rts-cabin-ferry-ade-control',D='/workspace/.playtest/cabin-ferry-implementation-ade-20261016';
const load=(p:string)=>import(pathToFileURL(S+'/'+p).href),sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const input='/workspace/.playtest/cabin-load-capability-ade-20261016/input-194400.json.gz';
const raw=readFileSync(input),f=JSON.parse(gunzipSync(raw).toString()),before=JSON.stringify(f),s=f.snapshot;
const[{setBuildingBodies,walkableGoal,walkingDistance},{routeTravelTicks},{coastOnWater,assaultExpedition},{bootstrapPolicyContext},{bodyMass}]=await Promise.all([
 load('src/shared/terrain.ts'),load('src/shared/route-selection.ts'),load('src/ai/policy/naval.ts'),load('src/ai/bootstrap_1/policy.ts'),load('src/shared/physical-body.ts')]);
setBuildingBodies(s.map,s.buildings);
const context=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:f.memories.p0,teams:s.teams}),boat=s.units.find((u:any)=>u.id==='unit-p0-carrier-25442'),mission=context.memory.naval.ferries[boat.id],target=s.buildings.find((b:any)=>b.id===mission.targetId),expedition=assaultExpedition(s,'p0',context,target);
const members=expedition.crew.map((u:any)=>{
 if(u.deck)return{id:u.id,kind:u.kind,x:u.x,y:u.y,deck:u.deck,mass:bodyMass(u),routeScope:'already physically aboard; not assigned a land route'};
 const shore=coastOnWater(s,u,boat),ground=shore&&walkableGoal(s.map,shore.x,shore.y);
 const landRoad=ground&&walkingDistance(s.map,u,ground,'land'),landTicks=ground&&routeTravelTicks(s.map,u,ground,'land',u.speed),seaRoad=shore&&walkingDistance(s.map,boat,shore,'sea');
 return{id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:u.order,mass:bodyMass(u),shore:shore??null,ground:ground??null,landRoad:landRoad??null,terrainTravelTicks:landTicks??null,seaRoad:seaRoad??null,
  routeScope:'Current native terrain/building-overlay query only; excludes dynamic bodies, ship boarding berth, future crowd movement, wind and actual sailing. Finite ETA is not actual boarding.'};
});
if(JSON.stringify(f)!==before)throw Error('Actual full input mutated');
const out={classification:'New permitted read-only native geometry/terrain query, no Game/native step or command publication; uncommitted candidate geometry source',input,inputSHA256:sha(raw),snapshotNextIdAll3MemUnchanged:true,required:expedition.required,selected:members.length,selectedMass:members.reduce((n:number,u:any)=>n+u.mass,0),members};
writeFileSync(D+'/actual194400-roster-routes.json',JSON.stringify(out,null,2));
console.log(JSON.stringify({required:out.required,selected:out.selected,aboard:members.filter((u:any)=>u.deck).length,finiteLandRoads:members.filter((u:any)=>u.landRoad!==undefined&&u.landRoad!==null).length,ram:members.find((u:any)=>u.id==='unit-p0-siegeRam-12085')}));
