import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {sameGround,setBuildingBodies} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/terrain.ts';
import {unitRules,UNIT_DEFS} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/catalog.ts';
import {shipProfile,shipPassengers} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/ship-geometry.ts';
import {isInCabin,shipCabinUsage} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/ship-cabin.ts';
import {ITEM_DEFS} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/equipment.ts';
import {SHOP_GOODS} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/shared/shop.ts';
import {effectiveCombatRating} from '/workspace/sketch-rts-cabin-ferry-ade-control/src/ai/policy/v6/strength.ts';
const D='/workspace/.playtest/cabin-ferry-implementation-ade-20261016';
const path=D+'/native-candidate-natural-from195600/final.json.gz',raw=readFileSync(path);
const full=JSON.parse(gunzipSync(raw).toString()),s=full.snapshot;
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),before=sha(JSON.stringify(full));
setBuildingBodies(s.map,s.buildings);
const own=s.units.filter((u:any)=>u.owner==='p0'&&u.hp>0),permanent=own.filter((u:any)=>u.expiresTick===undefined);
const enemies=s.units.filter((u:any)=>['p1','p2'].includes(u.owner)&&u.hp>0);
const refs=(u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,radius:u.radius,deck:u.deck,cabin:u.cabin,order:u.order,orderQueue:u.orderQueue,carryingGold:u.carryingGold,effects:u.effects,hands:u.hands,kills:u.kills,xp:u.xp,level:u.level,claims:full.memories.p0.unitClaims?.[u.id]});
const army=permanent.filter((u:any)=>u.kind!=='worker'&&!shipProfile(u));
const mines=s.resources.filter((r:any)=>r.amount>0).map((r:any)=>({...r,
 sameGroundOwnWorkers:own.filter((u:any)=>u.kind==='worker'&&!u.deck&&sameGround(s.map,u,r)).map(refs),
 sameGroundOwnArmy:army.filter((u:any)=>!u.deck&&sameGround(s.map,u,r)).map((u:any)=>u.id),
 sameGroundEnemyLand:enemies.filter((u:any)=>!u.deck&&!shipProfile(u)&&sameGround(s.map,u,r)).map(refs),
 ownBuildingsOnGround:s.buildings.filter((b:any)=>b.owner==='p0'&&b.hp>0&&sameGround(s.map,b,r)).map((b:any)=>({id:b.id,kind:b.kind,x:b.x,y:b.y})),
 limitation:'Ground-component identity only, no routed reachability, safe path, effective mining or affordable construction inferred.'}));
const itemFacts=s.items.map((i:any)=>({...i,definition:ITEM_DEFS[i.kind as keyof typeof ITEM_DEFS],shopPurchaseCost:SHOP_GOODS.find(g=>g.kind===i.kind)?.cost,
 economicNote:'Existing equipment retained as actual utility, no sell command exists in current GameCommand union; purchase list value is not spendable gold.'}));
const out={classification:'Pure final-state diagnostic of supported observation stop310800. No Game/step/planner/commands or source edits; all poses/orders are this actual full frame, not evidence all coordinates froze.',
 sourceHead:'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804',tick:s.tick,input:{path,sha256:sha(raw)},
 winner:s.match.winner,allPermanentOwnArmy:army.map((u:any)=>({...refs(u),effectiveCampaignRating:effectiveCombatRating(s,u)})),
 workers:permanent.filter((u:any)=>u.kind==='worker').map(refs),
 hulls:permanent.filter((u:any)=>shipProfile(u)).map((u:any)=>({...refs(u),sailing:u.sailing,shipParts:u.shipParts,cargo:shipPassengers(s.units,u).map(refs),usage:shipCabinUsage(s,u),insideCount:shipPassengers(s.units,u).filter(isInCabin).length})),
 currentGoals:{naval:full.memories.p0.naval,v6:full.memories.p0.v6,strategicPlan:full.memories.p0.strategicPlan,jobs:full.memories.p0.jobs,mounted:full.memories.p0.mounted},
 capital:{spendableSnapshotGold:s.players.p0.gold,workerCarriedGold:own.reduce((n:number,u:any)=>n+(u.carryingGold??0),0),paidQueues:s.buildings.filter((b:any)=>b.owner==='p0'&&(b.queue?.length||b.trainingQueue?.length||b.research)),
 actualMineOrders:own.filter((u:any)=>u.order.type==='mine').map(refs),
 currentCosts:{worker:UNIT_DEFS.worker.cost,transport:UNIT_DEFS.transport.cost,carrier:UNIT_DEFS.carrier.cost},
 activeNeutralGuards:s.units.filter((u:any)=>u.owner==='neutral'&&u.hp>0).map((u:any)=>({...refs(u),goldBounty:unitRules(s,u).goldBounty??0})),
 caveat:'Neutral bounties are possible actual resources only if native combat reaches/kills the guards; no safe/reachable kill is proven. No cash closure/infinite-future impossibility claim.'},
 remainingMines:mines,items:itemFacts,allOwnBuildings:s.buildings.filter((b:any)=>b.owner==='p0'&&b.hp>0),
 fullInputUnchanged:before===sha(JSON.stringify(full))};
if(!out.fullInputUnchanged)throw Error('Pure final-state query mutated input');
writeFileSync(D+'/final-strategic-state-query.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({tick:s.tick,winner:s.match.winner,army:army.length,workers:out.workers.length,hulls:out.hulls.length,capital:out.capital,remainingMines:mines.map((r:any)=>({id:r.id,amount:r.amount,workers:r.sameGroundOwnWorkers.length,army:r.sameGroundOwnArmy.length,enemies:r.sameGroundEnemyLand.length})),items:itemFacts.length,unchanged:out.fullInputUnchanged}));
