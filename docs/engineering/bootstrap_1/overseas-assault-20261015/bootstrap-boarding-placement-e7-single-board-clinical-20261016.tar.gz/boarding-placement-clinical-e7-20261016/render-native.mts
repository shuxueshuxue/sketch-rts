import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createCanvas } from '/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js';
const D='/tmp/boarding-placement-clinical-e7-20261016',S='/workspace/sketch-rts-boarding-placement-a7-control',load=(p:string)=>import(pathToFileURL(S+'/'+p).href),sha=(b:any)=>createHash('sha256').update(b).digest('hex');
const [{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([load('src/recorder/record.ts'),load('src/client/world-renderer.ts'),load('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const rows=[];
for(const spec of [{label:'actual-208201-shore-start',path:'input-208201.json.gz',view:{x:6800,y:5600,width:1320,height:1300,zoom:1.3}}, {label:'actual-208416-native-attachment',path:'final.json.gz',view:{x:6800,y:5730,width:1400,height:950,zoom:2.5}}]) {
 const raw=readFileSync(D+'/'+spec.path),saved=JSON.parse(gunzipSync(raw).toString()),before=sha(JSON.stringify(saved));
 const canvas=createCanvas(spec.view.width,spec.view.height);
 drawWorld({ctx:canvas.getContext('2d') as any,snapshot:saved.snapshot,view:spec.view,now:saved.snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0',selectedIds:new Set(['unit-p0-carrier-25442','unit-p0-ashHexer-23349'])});
 const png=canvas.toBuffer('image/png');writeFileSync(D+'/'+spec.label+'.png',png);
 if(sha(JSON.stringify(saved))!==before)throw Error('Renderer modified actual full input');
 rows.push({...spec,inputSHA256:sha(raw),pngSHA256:sha(png),tick:saved.snapshot.tick,fullInputUnchanged:true});
}
writeFileSync(D+'/native-render-metadata.json',JSON.stringify({classification:'Native client drawWorld post-recording renders of actual saved initial and actual public single-board attachment. No Game/step/commands or geometry/body edits. This is not a live browser screenshot or autonomous AI result.',sourceHead:'e7cdb8d67f8070a6548b527a25a38f62e18f0a0a',rows},null,2)+'\n');
