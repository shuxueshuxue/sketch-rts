import { readFileSync, writeFileSync, appendFileSync, renameSync, existsSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const D='/tmp/boarding-placement-clinical-e7-20261016',cap=JSON.parse(readFileSync(D+'/fixed-runtime.json','utf8')),S=cap.sourceRoot;
const H='unit-p0-carrier-25442',W='unit-p0-ashHexer-23349';
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),copy=(v:any)=>JSON.parse(JSON.stringify(v));
const assert=(v:any,m:string)=>{if(!v)throw Error(m);};
const load=(p:string)=>import(pathToFileURL(S+'/'+p).href);
const atomic=(p:string,v:any)=>{writeFileSync(p+'.tmp',v);renameSync(p+'.tmp',p);};
const emit=(n:string,v:any)=>appendFileSync(D+'/'+n+'.jsonl',JSON.stringify(v)+'\n');
const verify=()=>{
 const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
 const changed=Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);
 assert(head===cap.head&&!status&&!changed.length,'Fixed source mismatch');return{head,status,files:Object.keys(cap.hashes).length,changed};
};
assert(!existsSync(D+'/actual-launch.json'),'Already launched');
const prelaunch=JSON.parse(readFileSync(D+'/prelaunch.json','utf8'));
assert(sha(readFileSync(import.meta.filename))===prelaunch.driverSHA256,'Driver changed');
const raw=readFileSync(D+'/input-208201.json.gz');assert(sha(raw)===prelaunch.inputSHA256,'Input changed');
const input=JSON.parse(gunzipSync(raw).toString()),startedAtUtc=new Date().toISOString(),sourcePre=verify();
const [sim,context,bootstrap,runner,validation,geo,cabin,decks,naval,frames,strength]=await Promise.all([
 load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),load('src/ai/game-runner.ts'),load('src/shared/sim/command-validation.ts'),
 load('src/shared/ship-geometry.ts'),load('src/shared/ship-cabin.ts'),load('src/shared/decks.ts'),load('src/shared/naval.ts'),load('src/sdk/commands/frame.ts'),load('src/ai/policy/v6/strength.ts')]);
const g=sim.createGame('bareDuel'),memory=context.createAiMemoryProvider();
sim.restoreSnapshotIntoGame(g,input.snapshot,input.nextId);for(const[o,m]of Object.entries(input.memories))memory.set(o,copy(m));
const full=()=>copy({snapshot:sim.snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(Object.keys(input.memories).map(o=>[o,memory.get(o)]))});
const initial=full(),restore={world:isDeepStrictEqual(initial.snapshot,input.snapshot),nextId:g.nextId===input.nextId,all3mem:isDeepStrictEqual(initial.memories,input.memories)};
assert(g.tick===208201&&Object.values(restore).every(Boolean),'Full JSON-save restore mismatch');
const frozenRoot=bootstrap.frozenPolicyRoot();
const frozenCheck=()=>{
 const m=bootstrap.frozenPolicyManifest,changed=Object.entries(m.files).filter(([p,h])=>sha(readFileSync(frozenRoot+'/'+p))!==h).map(([p])=>p);
 assert(m.rulesVersion===2&&m.revision===cap.frozenRevision&&Object.keys(m.files).length===184&&!changed.length,'Frozen mismatch');
 return{revision:m.revision,rulesVersion:2,files:184,changed};
};
const frozenPre=frozenCheck(),normal=await bootstrap.createBootstrapCommandPlanner(memory);
assert(isDeepStrictEqual(full(),initial),'Planner/frozen setup altered input');
const agents={p0:{version:'v9_summoner',versionLabel:'v9_summoner',race:'ember',controller:'external-agent',team:'a'},p1:{version:'v5',versionLabel:'v5',race:'grove',controller:'external-agent',team:'b'},p2:{version:'v7',versionLabel:'v7',race:'ember',controller:'external-agent',team:'b'}};
const hull0=g.units.find((u:any)=>u.id===H),initialCargo=geo.shipPassengers(g.units,hull0),cohortIds=initialCargo.map((u:any)=>u.id),initialHP=Object.fromEntries(initialCargo.map((u:any)=>[u.id,u.hp]));
assert(initialCargo.length===25&&initialCargo.filter(cabin.isInCabin).length===10,'Wrong actual cargo');
const counts={manualP0Commands:0,commands:0,hits:0,steps:0,p0NoCommandPlans:0,enemyPlans:0,events:0};
for(const n of ['commands','hits','events','plans'])writeFileSync(D+'/'+n+'.jsonl','');writeFileSync(D+'/states.jsonl.gz','');
const startedWall=performance.now(),startedCPU=process.cpuUsage();
const capture=(stage:string)=>atomic(D+'/frames/'+g.tick+'-'+stage+'.json.gz',gzipSync(JSON.stringify(full())));
const state=(stage:string)=>{
 const hull=g.units.find((u:any)=>u.id===H),walker=g.units.find((u:any)=>u.id===W),cargo=hull?geo.shipPassengers(g.units,hull):[];
 return copy({tick:g.tick,stage,hull,walker,cohort:cohortIds.map((id:string)=>g.units.find((u:any)=>u.id===id)??{id,missing:true}),cargoIds:cargo.map((u:any)=>u.id),cargoCount:cargo.length,insideCount:cargo.filter(cabin.isInCabin).length,usage:hull?cabin.shipCabinUsage(g,hull):null,load:hull?decks.deckLoad(g.units,hull):null,capacity:hull?geo.shipProfile(hull)?.loadCapacity:null,power:cargo.reduce((n:number,u:any)=>n+strength.effectiveCombatRating(g,u),0),alongside:hull&&walker&&!walker.deck?naval.alongside(walker,hull):null,gap:hull&&walker&&!walker.deck?geo.distanceToHull(hull,walker):null,counts});
};
const observe=(stage:string)=>{const row=state(stage);appendFileSync(D+'/states.jsonl.gz',gzipSync(JSON.stringify(row)+'\n',{level:3}));if(g.tick%15===0)atomic(D+'/progress.json',JSON.stringify({tick:g.tick,counts,pid:process.pid,cargo:row.cargoCount,inside:row.insideCount,walker:row.walker,shipOrder:row.hull?.order,gap:row.gap}));return row;};
g.observer={hit(a:any,t:any,d:number,b:number){emit('hits',{tick:g.tick,attacker:a.id,attackerOwner:a.owner,target:t.id,targetOwner:t.owner,damage:d,hpBefore:b,hpAfter:t.hp});counts.hits++;}};
const initialCommand={type:'board',unitIds:[W],transportId:H};
const legality=validation.checkCommandLegality(g,'p0',initialCommand)??null;assert(!legality,'Candidate public admission failed');
const actualLaunch={classification:'Manual clinical subject: exactly one P0 public board at actual208201; thereafter P0 planner returns no commands and keeps its AI memory unchanged. P1/P2 normal frozen v5/v7 15tick. No cargo/pose/order/HP/quota edits, no public corrective moves. Focused native attachment evidence, not autonomous policy or complete-game score.',startedAtUtc,pid:process.pid,argv:process.argv,head:cap.head,sourcePre,frozenPre,restore,inputSHA256:sha(raw),driverSHA256:prelaunch.driverSHA256,agents,initialCargoIds:cohortIds,initialCargoHP:initialHP,initialCommand,legality,stopPolicy:'Observe to actual attachment, concrete loss/ownership/order failure, natural winner, or explicit diagnosed observer stop file at normal600 after-step boundary; no fixed max horizon accepted as capability.'};
atomic(D+'/actual-launch.json',JSON.stringify(actualLaunch,null,2));capture('before-manual');observe('before-manual');
let manualBefore:any;
frames.createSdkCommandFrameRuntime(g).issue([{playerId:'p0',source:'external-agent',scriptId:'clinical-single-board',command:initialCommand}],{
 beforeIssue(){manualBefore=full();},
 afterIssue(){counts.manualP0Commands++;counts.commands++;const after=full();emit('commands',{tick:g.tick,index:0,owner:'p0',scriptId:'clinical-single-board',command:initialCommand});atomic(D+'/manual-command-effect.json',JSON.stringify({legality,before:manualBefore,after,snapshotChanged:!isDeepStrictEqual(manualBefore.snapshot,after.snapshot)},null,2));}
},{checksum:false});
assert(counts.manualP0Commands===1,'Manual command count');capture('after-manual');observe('after-manual');
class ObservedStop extends Error{}
let stopReason:any,result:any;
const stop=(reason:any)=>{stopReason={tick:g.tick,...reason};capture('observed-stop');observe('observed-stop');throw new ObservedStop(reason.type);};
const planner=(c:any)=>{if(c.owner==='p0'){counts.p0NoCommandPlans++;emit('plans',{tick:g.tick,owner:c.owner,manualNoCommands:true});return [];}counts.enemyPlans++;const entries=normal(c);emit('plans',{tick:g.tick,owner:c.owner,entryCount:entries.length});return entries;};
try {
 result=runner.runAiGameLoop({name:'e7 single public shore-board attachment',game:g,agents,maxTicks:Number.MAX_SAFE_INTEGER,thinkInterval:15,commandPlanner:planner},{
  onCommand(e:any){assert(e.owner!=='p0','Unexpected extra P0 command');emit('commands',{tick:e.tick,index:counts.commands++,owner:e.owner,scriptId:e.scriptId,command:e.command});},
  onStep(){
   counts.steps++;const row=observe('after-step');if(g.tick%15===0)capture('after-step');
   if(!row.hull||row.hull.hp<=0||row.hull.owner!=='p0')stop({type:'hull-lost-or-transferred',hull:row.hull??null});
   if(!row.walker||row.walker.hp<=0)stop({type:'walker-lost',walker:row.walker??null});
   if(row.walker.deck?.shipId===H)stop({type:'actual-attached',walker:row.walker});
   if(row.walker.deck)stop({type:'attached-other-hull',walker:row.walker});
   if(row.walker.order.type!=='board'||row.walker.order.transportId!==H)stop({type:'original-board-order-ended-without-attachment',walker:row.walker});
   const missing=row.cohort.filter((u:any)=>u.missing||u.hp<=0||u.deck?.shipId!==H||u.owner!=='p0');if(missing.length)stop({type:'original-passenger-cohort-lost-or-detached',missing});
   if(g.tick%600===0&&existsSync(D+'/STOP.json'))stop({type:'explicit-diagnosed-observer-stop',request:JSON.parse(readFileSync(D+'/STOP.json','utf8'))});
  }
 });
}catch(e){if(!(e instanceof ObservedStop)){capture('unexpected-interruption');atomic(D+'/interruption.json',JSON.stringify({tick:g.tick,error:String(e),counts},null,2));throw e;}}
const final=full(),finalState=state('final'),sourcePost=verify(),frozenPost=frozenCheck(),p0MemoryUnchanged=isDeepStrictEqual(final.memories.p0,input.memories.p0);
assert(p0MemoryUnchanged&&counts.manualP0Commands===1,'Manual subject scope violated');
capture('final');atomic(D+'/final.json.gz',gzipSync(JSON.stringify(final)));
const cpu=process.cpuUsage(startedCPU),report={classification:actualLaunch.classification,startedAtUtc,endedAtUtc:new Date().toISOString(),start:208201,end:g.tick,stopReason:stopReason??{type:g.match.winner?'natural-winner':'unexpected-max-horizon'},winner:g.match.winner,counts,restore,sourcePre,sourcePost,frozenPre,frozenPost,p0MemoryUnchanged,final:finalState,originalCohortAllAliveOnOriginalHull:finalState.cohort.every((u:any)=>!u.missing&&u.hp>0&&u.deck?.shipId===H&&u.owner==='p0'),originalCohortHPChanges:finalState.cohort.filter((u:any)=>u.hp!==initialHP[u.id]).map((u:any)=>({id:u.id,before:initialHP[u.id],after:u.hp??null})),autonomousPolicyResult:false,ordinaryZeroOpening:false,elapsedWallMs:performance.now()-startedWall,cpuMs:(cpu.user+cpu.system)/1000,finalSHA256:sha(readFileSync(D+'/final.json.gz'))};
atomic(D+'/report.json',JSON.stringify(report,null,2));console.log(JSON.stringify({end:g.tick,stopReason:report.stopReason,cargo:report.final.cargoCount,inside:report.final.insideCount,power:report.final.power,original25Alive:report.originalCohortAllAliveOnOriginalHull,hpChanges:report.originalCohortHPChanges,counts,finalSHA256:report.finalSHA256},null,2));
