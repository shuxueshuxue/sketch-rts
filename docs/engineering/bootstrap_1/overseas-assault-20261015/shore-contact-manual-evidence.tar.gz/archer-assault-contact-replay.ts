import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const wd = '/workspace/sketch-rts-reinforcement-control';
const imp = (path: string) => import(pathToFileURL(join(wd, path)).href);
const [{ bootstrapMatches, bootstrapGame }, { runAiGameLoop }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { restoreSnapshotIntoGame, snapshotGame },
  { bootstrapPolicyContext }, { assaultExpedition }, { effectiveCombatRating },
  { shipPassengers }, { sameGround, walkingDistance }, { unitMover }, { combatCapability }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/ai/game-runner.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/shared/sim.ts'), imp('src/ai/bootstrap_1/policy.ts'),
  imp('src/ai/policy/naval.ts'), imp('src/ai/policy/v6/strength.ts'), imp('src/shared/ship-geometry.ts'),
  imp('src/shared/terrain.ts'), imp('src/shared/catalog.ts'), imp('src/shared/combat-capabilities.ts'),
]);
const reportPath = join(root, 'archer-assault-reinforcement-candidate-v3.json');
const report = JSON.parse(readFileSync(reportPath, 'utf8'));
const start = 87600, end = 88800;
const row = report.rows.find((item: any) => item.tick === start);
const frame = JSON.parse(readFileSync(`${reportPath}.frames/${start}.json`, 'utf8'));
const match = bootstrapMatches('bootstrap_1-development', ['sapphireArchipelago'], end, false).find((item: any) =>
  item.subject === 'v9_archer' && item.agents.p0.race === 'grove' && item.side === 0
  && Object.values(item.agents).slice(1).map((agent: any) => agent.version).join('+') === 'v5');
const game = bootstrapGame(match), memories = createAiMemoryProvider();
restoreSnapshotIntoGame(game, frame.snapshot, frame.nextId);
for (const [owner, player] of Object.entries(row.players)) memories.set(owner, structuredClone((player as any).policy));
const planner = await createBootstrapCommandPlanner(memories);
const ships = ['unit-p0-carrier-3510', 'unit-p0-carrier-3824'];
const target = frame.snapshot.buildings.find((building: any) => building.id === 'building-p1-shipyard-1016');
const originalCrew = new Set<string>(frame.snapshot.units.filter((unit: any) => ships.includes(unit.deck?.shipId)).map((unit: any) => unit.id));
const selected = new Set([...ships, ...originalCrew]);
const hits: any[] = [], thoughts: any[] = [], issued: any[] = [], events: any[] = [], matches: any[] = [];
const outFrames = join(root, 'archer-assault-contact-replay.frames');
mkdirSync(outFrames, { recursive: true });
const summarize = (unit: any) => ({ id: unit.id, kind: unit.kind, owner: unit.owner, x: unit.x, y: unit.y,
  hp: unit.hp, maxHp: unit.maxHp, order: unit.order, deck: unit.deck, expiresTick: unit.expiresTick,
  attackDamage: unit.attackDamage, attackRange: unit.attackRange, radius: unit.radius });
const cargoPower = (snapshot: any, cargo: any[]) => cargo.filter(unit => unit.kind !== 'worker' && !unit.expiresTick)
  .reduce((sum, unit) => sum + effectiveCombatRating(snapshot, unit), 0);
function capture(label: string) {
  writeFileSync(join(outFrames, `${label}.json`), JSON.stringify({ tick: game.tick, snapshot: snapshotGame(game),
    nextId: game.nextId, memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner)])) }) + '\n');
}
game.observer = { hit(attacker: any, struck: any, damage: number, before: number) {
  if (selected.has(attacker.id) || selected.has(struck.id) || attacker.owner === 'p1' && struck.owner === 'p0') {
    hits.push({ tick: game.tick, source: summarize(attacker), target: summarize(struck), damage, hpBefore: before,
      lethal: before > 0 && struck.hp <= 0, centerDistance: Math.hypot(attacker.x - struck.x, attacker.y - struck.y) });
  }
} };
let previous = new Map(game.units.filter((unit: any) => selected.has(unit.id)).map((unit: any) => [unit.id, summarize(unit)]));
capture('start-87600');
runAiGameLoop({ ...match, game, commandPlanner: (context: any) => {
  if (context.owner !== 'p0') return planner(context);
  const snapshot = context.snapshot, before = structuredClone(memories.get('p0').naval?.ferries ?? {});
  const options = bootstrapPolicyContext(snapshot, 'p0', report.subject, { memory: structuredClone(memories.get('p0')), teams: context.teams });
  const required = assaultExpedition(snapshot, 'p0', options, target).required;
  const ownShips = snapshot.units.filter((unit: any) => ships.includes(unit.id));
  const landed = snapshot.units.filter((unit: any) => unit.owner === 'p0' && !unit.deck && !unit.expiresTick
    && unit.kind !== 'worker' && unitMover(unit.kind) === 'land' && sameGround(snapshot.map, unit, target));
  const incoming = snapshot.units.filter((unit: any) => before[unit.id]?.purpose === 'assault'
    && before[unit.id]?.phase === 'sailing' && before[unit.id]?.targetId === target.id)
    .flatMap((unit: any) => shipPassengers(snapshot.units, unit));
  const diagnostic = { tick: snapshot.tick, required, landedIds: landed.map((unit: any) => unit.id),
    actualSailingPower: cargoPower(snapshot, [...incoming, ...landed]),
    boats: ownShips.map((boat: any) => {
      const nearby = snapshot.units.filter((ship: any) => before[ship.id]?.purpose === 'assault'
        && before[ship.id]?.phase !== 'return' && before[ship.id]?.targetId === target.id
        && (ship.id === boat.id || Math.hypot(ship.x - boat.x, ship.y - boat.y) <= 450
          && (walkingDistance(snapshot.map, ship, boat, 'sea') ?? Infinity) <= 450));
      return { ...summarize(boat), heading: boat.sailing.heading, mission: before[boat.id],
        distanceToLanding: Math.hypot(boat.x - before[boat.id]?.to.x, boat.y - before[boat.id]?.to.y),
        local450Power: cargoPower(snapshot, [...nearby.flatMap((ship: any) => shipPassengers(snapshot.units, ship)), ...landed]),
        nearbyIds: nearby.map((ship: any) => ship.id), cargo: shipPassengers(snapshot.units, boat).map(summarize),
        otherRoad: ownShips.filter((ship: any) => ship.id !== boat.id).map((ship: any) => ({ id: ship.id,
          road: walkingDistance(snapshot.map, boat, ship, 'sea'), distance: Math.hypot(boat.x - ship.x, boat.y - ship.y) })) };
    }) };
  capture(`before-think-${snapshot.tick}`);
  const commands = planner(context);
  const after = structuredClone(memories.get('p0').naval?.ferries ?? {});
  thoughts.push({ ...diagnostic, after, commands });
  for (const id of ships) if (before[id]?.phase !== 'return' && after[id]?.phase === 'return') {
    events.push({ tick: snapshot.tick, event: 'first-policy-return-transition', shipId: id, before: before[id], after: after[id],
      required, actualSailingPower: diagnostic.actualSailingPower, ownLocalPower: diagnostic.boats.find((boat: any) => boat.id === id)?.local450Power });
  }
  return commands;
} }, {
  onCommand: ({ tick, owner, scriptId, command }: any) => issued.push({ tick, owner, scriptId, command }),
  onStep: ({ game }: any) => {
    const current = new Map(game.units.filter((unit: any) => selected.has(unit.id)).map((unit: any) => [unit.id, summarize(unit)]));
    for (const id of selected) {
      const old: any = previous.get(id), unit: any = current.get(id);
      if (old && !unit) { events.push({ tick: game.tick, event: 'entity-disappeared', old }); capture(`disappeared-${game.tick}`); }
      if (old && unit && old.deck?.shipId !== unit.deck?.shipId) events.push({ tick: game.tick, event: 'deck-transition', before: old, after: unit });
      if (unit && originalCrew.has(id) && !unit.deck && sameGround(game.map, unit, target)) events.push({ tick: game.tick, event: 'original-passenger-on-enemy-ground', unit });
    }
    previous = current;
    if (game.tick % 600 === 0) {
      const actual = snapshotGame(game), expected = JSON.parse(readFileSync(`${reportPath}.frames/${game.tick}.json`, 'utf8'));
      const expectedRow = report.rows.find((item: any) => item.tick === game.tick);
      matches.push({ tick: game.tick, snapshotMatches: JSON.stringify(actual) === JSON.stringify(expected.snapshot),
        nextIdMatches: game.nextId === expected.nextId, allPolicyMemoriesMatch: Object.keys(match.agents).every(owner =>
          JSON.stringify(memories.get(owner)) === JSON.stringify(expectedRow.players[owner].policy)) });
      capture(`sample-${game.tick}`);
    }
  },
});
const result = { classification: 'read-only-hit-observer faithful full normalAI replay from v3 87600 complete world/bothmemories, not a new candidate',
  source: 'archer-assault-reinforcement-v3-runtime-source.json', start, end: game.tick,
  originalCrew: [...originalCrew], originalMatches: matches, events, thoughts, issued, hits,
  lethalSelectedHits: hits.filter(hit => hit.lethal && originalCrew.has(hit.target.id)),
  final: { nextId: game.nextId, losses: game.match.stats.unitsLost, winner: game.match.winner } };
writeFileSync(join(root, 'archer-assault-contact-replay.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ matches, events: events.filter(event => event.event !== 'original-passenger-on-enemy-ground'),
  lethalHits: result.lethalSelectedHits.map(hit => ({ tick: hit.tick, source: hit.source, target: hit.target.id,
    targetDeck: hit.target.deck, damage: hit.damage, hpBefore: hit.hpBefore })), final: result.final }));
if (matches.some(check => !check.snapshotMatches || !check.nextIdMatches || !check.allPolicyMemoriesMatch)) process.exitCode = 1;
