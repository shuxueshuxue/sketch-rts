import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = '/workspace/sketch-rts-bootstrap-resume', evidence = join(root, '.playtest/overseas-assault-20261015');
const original = '/workspace/sketch-rts-reinforcement-control';
const imp = (base: string, path: string) => import(pathToFileURL(join(base, path)).href);
const [{ coastalAsternStep, coastalAsternPassageClear, outmatchingCoast }, { bootstrapPolicyContext },
  { effectiveCombatRating }, { sameGround }] = await Promise.all([
  imp(root, 'src/ai/policy/coastal-risk.ts'), imp(original, 'src/ai/bootstrap_1/policy.ts'),
  imp(original, 'src/ai/policy/v6/strength.ts'), imp(original, 'src/shared/terrain.ts'),
]);
const rows = [];
for (const tick of [88110, 88200, 88290, 88305]) {
  const checkpoint = JSON.parse(readFileSync(join(evidence, `archer-assault-contact-replay.frames/before-think-${tick}.json`), 'utf8'));
  const s = checkpoint.snapshot, before = JSON.stringify(s);
  const options = bootstrapPolicyContext(s, 'p0', 'v9_archer', { memory: structuredClone(checkpoint.memories.p0), teams: s.teams });
  const boats = s.units.filter((unit: any) => ['unit-p0-carrier-3510', 'unit-p0-carrier-3824'].includes(unit.id)).map((boat: any) => {
    const threats = outmatchingCoast(s, 'p0', boat, boat, options);
    const goal = threats.length ? coastalAsternStep(s, boat, threats, options) : undefined;
    return { id: boat.id, x: boat.x, y: boat.y, heading: boat.sailing.heading, order: boat.order,
      threats: threats.map((unit: any) => unit.id), asternGoal: goal,
      nativeCoordinateOnlyPassageClear: goal ? coastalAsternPassageClear(s, boat, goal, options) : null,
      caveat: 'Pure normal-move/hull/fire-disk query only; no commands issued and no deck survival claim.' };
  });
  const target = s.buildings.find((building: any) => building.id === 'building-p1-shipyard-1016');
  const enemies = s.units.filter((unit: any) => unit.owner === 'p1' && !unit.deck && sameGround(s.map, unit, target))
    .map((unit: any) => ({ id: unit.id, kind: unit.kind, hp: unit.hp, expiresTick: unit.expiresTick, rating: effectiveCombatRating(s, unit) }));
  rows.push({ tick, boats, enemies });
  if (JSON.stringify(s) !== before) throw Error('Query mutated snapshot');
}
const output = { classification: 'Captured current-root coastalAstern helper queries on exact v3 replay snapshots; not a new full AI candidate',
  querySource: 'archer-assault-astern-query-source.json', snapshotSource: 'archer-assault-reinforcement-v3-runtime-source.json', rows };
writeFileSync(join(evidence, 'archer-assault-astern-query.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(rows.map(row => ({ tick: row.tick, boats: row.boats }))));
