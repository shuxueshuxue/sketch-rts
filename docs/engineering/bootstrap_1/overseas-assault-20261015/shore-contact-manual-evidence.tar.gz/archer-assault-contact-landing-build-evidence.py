from pathlib import Path
import json,hashlib,tarfile,io,datetime,shutil
p=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');docs=Path('/workspace/sketch-rts-bootstrap-resume/docs/engineering/bootstrap_1/overseas-assault-20261015');docs.mkdir(parents=True,exist_ok=True)
shutil.copy2('/tmp/build-contact-landing-facts.py',p/'archer-assault-contact-landing-build-facts.py')
shutil.copy2(__file__,p/'archer-assault-contact-landing-build-evidence.py')
prefixes=('archer-assault-contact-','archer-assault-astern-query','archer-assault-passenger-window-query','archer-assault-altshore','archer-assault-current-shore','archer-assault-commonshore','archer-assault-normal-after-','archer-assault-ground-disjoint-replay','archer-assault-landing-ownership-replay','archer-assault-landing-checkpoint-capture','archer-assault-deck-query-audit')
omit={'archer-assault-commonshore.json','archer-assault-commonshore.log','archer-assault-commonshore-run.ts','archer-assault-commonshore-v5-full29-100396.png','archer-assault-commonshore-v5-full29-100396-render.log'}
files={}
for f in p.iterdir():
 if not f.name.startswith(prefixes)or f.name in omit:continue
 if f.is_file():files[f.name]=f
 elif f.is_dir()and f.name.endswith('.frames'):
  for child in f.glob('*.json'):files[str(child.relative_to(p))]=child
for name in ['archer-assault-landing-ownership-blocked.json','archer-assault-reinforcement-v3-runtime-source.json','archer-assault-reinforcement-v3-runtime-source.tar.gz','archer-assault-reinforcement-v3-runtime-source.patch','archer-assault-reinforcement-candidate-v3.json','archer-assault-assembly-render.ts','render-shore-close.ts']:
 files[name]=p/name
for f in (p/'archer-assault-reinforcement-candidate-v3.json.frames').glob('*.json'):files[str(f.relative_to(p))]=f
files={name:f for name,f in files.items()if not name.endswith('-INDEX.json')}
index={'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'Rules2 manual-public-command contact/landing probes, faithful per-tick ownership audit and normal-AI aftermath; not independent AI acceptance','baseDirectory':str(p),'payloadFileCount':len(files),'canonicalFacts':'archer-assault-contact-landing-findings.json','importantCorrection':'100396:29 original crew alive,27 on target ground+2 reboarded deck,0elsewhere,0dead.29 is everLanded only. Native every-tick audit confirms max27; not29 grounded simultaneously.','runtimeSource':'archer-assault-reinforcement-v3-runtime-source.json','runtimeCapsuleSha256':'398b810ccd6e72e98659a55d504559fbe8d3bb22737658ebd7e96c10e7cac7b5','fixedOriginalRuntime':'f2676829+frozen ferryv3 SHA684ac7f1e37d9b263bf191374146a32398e6abe150f168967b19a233b66a954a;803 files unchanged','queryAdvisorCapsules':['archer-assault-astern-query-source.tar.gz','archer-assault-commonshore-helper-source.tar.gz'],'oldAltshoreAdvisorRecipe':'The captured astern-query capsule has781 AI/shared files. The actual altshore helper was supplemented with37 SDK files from the frozen originalv3 runtime capsule, exactly hashed in archer-assault-altshore-helper-sdk-supplement.json. No live rootWIP source is needed. New commonshore helper is complete824-file git93204ca4 capsule and only advises public commands.','criticalFullCheckpoints':'archer-assault-landing-checkpoint-capture.frames/before-think-100410/100530/100650/100800/101010.json: originalnormal AI world and both memories, exactly faithful to original100996 sample after a602tick capture.','outcomes':'Manualv5 battle then normal102000→105599:p0 enginewin, all enemy buildings destroyed,4remote enemy units remain. Normal immediately fromsame100396→120000:no winner, hall900,26original landed combat troops dead. No independent AIwin claim.','sourceAndWorldScope':'Original full v3 report/world frames and all contact/alternate/manual continuation sample worlds with both memories and nextId included. Existing original broken-container uncommitted recovery gap persists.','omittedHistoricalAliases':sorted(omit),'reproduction':'Scripts retain their original absolute artifact path. Preserve originals; change output root in a copied script or restore capsules in isolated worktrees when replaying. Full source/fixtures/hashes/think cadence are recorded, no private route/heading/world/resource assignments used.','files':{name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for name,f in sorted(files.items())}}
(p/'shore-contact-manual-evidence-INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
target=docs/'shore-contact-manual-evidence.tar.gz'
out=docs/'shore-contact-manual-evidence.tar.gz.tmp'
with tarfile.open(out,'w:gz',compresslevel=6)as tar:
 b=(p/'shore-contact-manual-evidence-INDEX.json').read_bytes();info=tarfile.TarInfo('INDEX.json');info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
with tarfile.open(out,'r:gz')as tar:
 archived=json.loads(tar.extractfile('INDEX.json').read());verified=0
 for name,data in archived['files'].items():
  b=tar.extractfile(name).read();assert len(b)==data['bytes']and hashlib.sha256(b).hexdigest()==data['sha256'],name;verified+=1
assert verified==len(files)
out.replace(target);out=target
result={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloadVerified':verified,'index':str(p/'shore-contact-manual-evidence-INDEX.json')};(p/'shore-contact-manual-evidence-delivery.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
