from pathlib import Path
import hashlib,json,collections
root=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015')
rp=root/'archer-assault-contact-replay.json';raw=rp.read_bytes();replay=json.loads(raw);base=json.loads((root/'archer-assault-reinforcement-candidate-v3.json.frames/87600.json').read_text())['snapshot'];ships=['unit-p0-carrier-3510','unit-p0-carrier-3824'];origin={u['id']:u['deck']['shipId']for u in base['units']if u.get('deck',{}).get('shipId')in ships}
assert len(origin)==29 and all(c['snapshotMatches']and c['nextIdMatches']and c['allPolicyMemoriesMatch']for c in replay['originalMatches'])
assert not any(e['event']=='deck-transition'for e in replay['events'])
transitions=[];previous=None
for thought in replay['thoughts']:
 relation=thought['boats'][0]['otherRoad'][0];inside=relation['distance']<=450 and relation['road']<=450
 if inside!=previous:transitions.append({'tick':thought['tick'],'within450CurrentHullQuery':inside,'centerDistance':relation['distance'],'seaRoad':relation['road']});previous=inside
split=next(t['tick']for t in transitions if not t['within450CurrentHullQuery']);returns=[e for e in replay['events']if e['event']=='first-policy-return-transition'];ret=min(e['tick']for e in returns)
windows=[('before-first-observed450-separation',87600,split),('after-separation-before88200',split,88200),('88200-before-return',88200,ret),('after-return',ret,88801)]
def aggregate(hits):
 return {'hits':len(hits),'nativeReportedDamage':sum(h['damage']for h in hits),'effectiveHpDamageCappedAtHpBefore':sum(min(max(h['damage'],0),max(h['hpBefore'],0))for h in hits),'lethalHits':sum(bool(h['lethal'])for h in hits),'targetIds':sorted({h['target']['id']for h in hits}),'sourceIds':sorted({h['source']['id']for h in hits}),'firstHitTick':min((h['tick']for h in hits),default=None),'lastHitTick':max((h['tick']for h in hits),default=None)}
out={'sourceReplay':rp.name,'sourceReplaySha256':hashlib.sha256(raw).hexdigest(),'classification':replay['classification'],'runtimeSource':replay['source'],'interval':[replay['start'],replay['end']],'faithfulReplayMatches':replay['originalMatches'],'originalCrew':origin,'nativeThoughtSeparationTransitions':transitions,'separationTickPrecision':'15tick policy-thought samples; does not claim exact intervening physical first crossing','returnTransitions':returns,'byOriginalShip':{},'strictSourceDeck':{},'recoveredMissingDeckSourceHits':[],'timeWindows':[]}
for ship in ships:
 strict=[h for h in replay['hits']if h['source'].get('deck',{}).get('shipId')==ship and h['source']['owner']=='p0'and h['target']['owner']=='p1'];all_origin=[h for h in replay['hits']if h['source']['id']in origin and origin[h['source']['id']]==ship and h['source']['owner']=='p0'and h['target']['owner']=='p1'];out['strictSourceDeck'][ship]=aggregate(strict);out['byOriginalShip'][ship]=aggregate(all_origin)
 for h in all_origin:
  if not h['source'].get('deck'):out['recoveredMissingDeckSourceHits'].append({'hit':h,'originalShip':ship,'reason':'Original29crew ID and zero deck-transition events identify ship. This posthumous projectile uses native scriptSource fallback kind=defenseTower and omits deck; not an actual defense tower shot.'})
for name,start,end in windows:
 values={'name':name,'startInclusive':start,'endExclusive':end,'shipOutgoing':{},'incomingTo3824Crew':aggregate([h for h in replay['hits']if start<=h['tick']<end and h['source']['owner']=='p1'and h['target'].get('deck',{}).get('shipId')==ships[1]]),'incomingCollateralTo3824Hull':aggregate([h for h in replay['hits']if start<=h['tick']<end and h['source']['owner']=='p1'and h['target']['id']==ships[1]])}
 for ship in ships:values['shipOutgoing'][ship]=aggregate([h for h in replay['hits']if start<=h['tick']<end and origin.get(h['source']['id'])==ship and h['source']['owner']=='p0'and h['target']['owner']=='p1'])
 out['timeWindows'].append(values)
# Native heal effects live36ticks, while complete before-think snapshots are15ticks apart.
# Retain exact actionTick/sourceId; effects omit targetId, so do not invent recipient IDs.
heals={};snapshots=[]
for p in sorted((root/'archer-assault-contact-replay.frames').glob('*.json')):
 f=json.loads(p.read_text());s=f['snapshot'];snapshots.append((s['tick'],p.name,s))
 for effect in s['effects']:
  if effect.get('type')=='heal'and effect.get('sourceId')in['unit-p0-priest-2370','unit-p0-priest-7778']and replay['start']<=effect.get('actionTick',-1)<=replay['end']:
   rec=heals.setdefault(effect['id'],{'effect':effect,'firstObservedFrame':p.name,'firstObservedTick':s['tick'],'casterOriginalShip':origin.get(effect['sourceId'])})
   if s['tick']<rec['firstObservedTick']:rec.update(effect=effect,firstObservedFrame=p.name,firstObservedTick=s['tick'])
out['healEffects']=list(heals.values());out['healingEvidenceLimit']='Native heal effects contain caster sourceId/actionTick and target coordinates, but no targetId. No recipient identity is guessed. No3510 priest heal effect was observed in complete15tick snapshots;36tick effect lifetime covers this cadence.'
out['neverLandedDuringReplay']=not any(e['event']=='original-passenger-on-enemy-ground'for e in replay['events']);out['incomingTo3824Crew']=aggregate([h for h in replay['hits']if h['source']['owner']=='p1'and h['target'].get('deck',{}).get('shipId')==ships[1]]);out['incomingCollateralTo3824Hull']=aggregate([h for h in replay['hits']if h['source']['owner']=='p1'and h['target']['id']==ships[1]]);out['permanentOwnDeaths']=replay['lethalSelectedHits'];out['damageSemantics']='Native observer.damage includes overkill. EffectiveHpDamage caps each hit at positive hpBefore. Deck-hull collateral is reported separately and not double-counted as crew damage.'
path=root/'archer-assault-contact-fire-support-hits.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'separationTransitions':transitions,'returns':[{'tick':x['tick'],'shipId':x['shipId'],'required':x['required'],'actualSailingPower':x['actualSailingPower']}for x in returns],'shipOutgoing':out['byOriginalShip'],'heals':out['healEffects'],'recoveredMissingDeckSources':len(out['recoveredMissingDeckSourceHits']),'neverLandedDuringReplay':out['neverLandedDuringReplay']},indent=2))
