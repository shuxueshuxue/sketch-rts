# v3接岸火力互援：88200固定几何与原生命中

88200的3510不能为正在接岸的3824提供对敌射击或跨船治疗。两船中心相距551.3166，真实海路614.4；3510的14名乘员到22名实际敌岸伤害来源最近623.749，最高实际射程319.2，原生canReach全为false。其牧师到3824最近乘员422.902，超过原生heal240。3824牧师到3510最近乘员444.462，也无法互疗。

这是实际world上的原生combatCapability、strikeGap、canReach、deckPlacement、automaticShoreTargetReachable、治疗目标类别/范围查询，未推进任何tick。88200完整关系包含29乘员×22实际敌伤害来源＝638对，见 `archer-assault-contact-fire-support-88200-geometry.json` 与同名relations.csv；每名乘员摘要见per-crew.json。两艘carrier自身fittings为空且combatCapability不武装，没有额外船炮可计入。

## 可达与现位射击

普通步兵/弓手不使用船炮shipGunCanAim的炮塔射界。这里按原生strikeGap到敌兵中心、实际range、canReach、cabin与stun检查现位几何；真实射击仍需原生瞄准/冷却，最终贡献由hit observer证明。canReach会投影 `deckPlacement(...,occupied=false)`，忽略乘员当前占位，属于当前船位上的原生潜在可达判断，不能计成已经完成甲板换位或已射击。

| tick | 两船海路 | 3510最近实际敌射手 | 3510现位可射关系 | 3824最近实际敌射手 | 3824现位可射关系 |
|---|---:|---:|---:|---:|---:|
| 87600 | 345.6 | 344.023 | 0 | 552.718 | 0 |
| 88110 | 454.4 | 513.547 | 0 | 310.588 | 3 |
| 88200 | 614.4 | 623.749 | 0 | 266.690 | 15 |

87600在450计力范围内，仍没有任何对这些实际岸射手的现位射击。88110是15tick policy thought里首次超450海路（中心仍441.174）；不伪称取得了逐tick精确越界时间。88200的15条可射关系只来自3824上的4名弓兵，另有76条nativeCanReach关系包含可能的甲板换位，均未当成实际命中。

原生 `combatCapability.dps` 也不直接等于甲板输出：`deck-combat.passengerDamageMultiplier` 为0.5，普通弓17点unit attackDamage在无其他状态时先发射round(17×0.5)=9，再受目标防护影响。此处没有改动对手或规则，也不据计力半径提出450→900改法。

## 真实命中贡献

父代理的87600→88800正常全AI逐tickreplay保留完整world/双policy；88200与88800的worldJSON、nextId和双memory均精确match原v3。全部269 hit按来源与目标归档，未运行新的模拟。

| 原乘员所属船 | 对敌命中 | 原生记录damage | 截至hpBefore有效HP伤害 | 永久击杀 |
|---|---:|---:|---:|---:|
| 3510 | 0 | 0 | 0 | 0 |
| 3824 | 67 | 573 | 550 | 5 |

严格按命中时 `source.deck.shipId`，3824是66次/564damage/543有效HP/4杀。额外1次是弓2830在88678已死、88689飞矢命中3598：native source退化成无deck的scriptSource，kind为defenseTower；稳定原始crew ID与全窗口零deck-transition事件，确认仍归3824原乘员，补9damage/7有效HP/1杀。没有把它误算成真实塔伤害。

所有选定乘员命中都发生在return之后：两船首return88305；首个被击88312；首个己方命中88339；首死亡88376。return时required19.935671已超过实际sailing19.271213，所以不能把撤退说成阵亡之后才触发。87600→首次450分离、分离→88200、88200→88305的双方选定乘员伤害均0。

同窗口3824乘员承受101次命中：898原生damage、864有效HP伤害、8永久弓兵死亡；另101点甲板连带船体伤害单独列出，未与乘员伤害混算。本窗口5敌永久击杀为4弓1牧，87313敌运输已在窗口开始前死亡，不重复计入。没有把召唤过期计为击杀。

## 治疗与登陆

87600时3824牧师可覆盖3510两名满血弓（213.603/232.883），但没有符合缺血至少27.5的自动治疗目标；3510牧师到3824最近270.039，已超过240。88110及88200两船双向都无法跨船治疗。

逐15tick完整快照里的36tick原生heal效果仅两次，均由3824牧师7778发出，actionTick88335、88575；未见3510牧师2370任何heal效果。效果没有targetId，保留来源/坐标，不猜具体治疗对象。

正常replay的逐tick onStep证明87600→88800没有任何原29乘员踏上敌岛，8名己方阵亡均有3824甲板尸体。900计力、sailing/unload命令、两船曾合流都不足以证明能在同一接岸战场互援。

本轮仍不是普通新开局或验收完成；原容器未提交修改缺口保持。

## 88200逐乘员摘要

最近距离针对同一组22名实际打伤3824的岸上单位；原始JSON/CSV保留每一对完整ID、坐标、射程与原生查询值。

| 船 | 乘员 | 种类 | 实际射程 | 最近敌距 | nativeCanReach敌数 | 现位可射敌数 |
|---|---|---|---:|---:|---:|---:|
| 3510 | unit-p0-archer-2351 | archer | 319.2 | 786.023 | 0 | 0 |
| 3510 | unit-p0-priest-2370 | priest | 201.6 | 671.732 | 0 | 0 |
| 3510 | unit-p0-archer-2380 | archer | 319.2 | 757.578 | 0 | 0 |
| 3510 | unit-p0-archer-2384 | archer | 319.2 | 623.749 | 0 | 0 |
| 3510 | unit-p0-archer-2466 | archer | 319.2 | 733.628 | 0 | 0 |
| 3510 | unit-p0-archer-2756 | archer | 319.2 | 723.563 | 0 | 0 |
| 3510 | unit-p0-archer-2782 | archer | 319.2 | 701.513 | 0 | 0 |
| 3510 | unit-p0-archer-2841 | archer | 319.2 | 629.697 | 0 | 0 |
| 3510 | unit-p0-archer-2849 | archer | 319.2 | 663.482 | 0 | 0 |
| 3510 | unit-p0-archer-2858 | archer | 319.2 | 756.937 | 0 | 0 |
| 3510 | unit-p0-archer-2882 | archer | 319.2 | 677.816 | 0 | 0 |
| 3510 | unit-p0-archer-2893 | archer | 319.2 | 689.509 | 0 | 0 |
| 3510 | unit-p0-archer-2910 | archer | 319.2 | 647.538 | 0 | 0 |
| 3510 | unit-p0-archer-2951 | archer | 319.2 | 650.769 | 0 | 0 |
| 3824 | unit-p0-archer-1238 | archer | 319.2 | 266.690 | 7 | 7 |
| 3824 | unit-p0-worker-2325 | worker | 36.0 | 267.623 | 0 | 0 |
| 3824 | unit-p0-archer-2411 | archer | 319.2 | 299.920 | 7 | 3 |
| 3824 | unit-p0-archer-2610 | archer | 319.2 | 335.570 | 7 | 0 |
| 3824 | unit-p0-archer-2749 | archer | 319.2 | 366.281 | 7 | 0 |
| 3824 | unit-p0-archer-2767 | archer | 319.2 | 444.344 | 7 | 0 |
| 3824 | unit-p0-archer-2795 | archer | 319.2 | 301.558 | 7 | 3 |
| 3824 | unit-p0-archer-2812 | archer | 319.2 | 306.447 | 7 | 2 |
| 3824 | unit-p0-archer-2830 | archer | 319.2 | 411.121 | 7 | 0 |
| 3824 | unit-p0-archer-2926 | archer | 319.2 | 404.001 | 7 | 0 |
| 3824 | unit-p0-horseArcher-3795 | horseArcher | 264.0 | 375.228 | 3 | 0 |
| 3824 | unit-p0-lancer-5275 | lancer | 74.0 | 372.055 | 0 | 0 |
| 3824 | unit-p0-priest-7778 | priest | 201.6 | 339.917 | 0 | 0 |
| 3824 | unit-p0-archer-8190 | archer | 319.2 | 422.929 | 7 | 0 |
| 3824 | unit-p0-horseArcher-8194 | horseArcher | 264.0 | 402.569 | 3 | 0 |
