import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const wd = '/workspace/sketch-rts-reinforcement-control', root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const imp = (path: string) => import(pathToFileURL(join(wd, path)).href);
const [{ passengerLandingSpot }, { sameGround }, { shipPassengers }] = await Promise.all([
  imp('src/shared/naval.ts'), imp('src/shared/terrain.ts'), imp('src/shared/ship-geometry.ts'),
]);
const rows = [];
for (const file of readdirSync(join(root, 'archer-assault-contact-replay.frames')).filter(file => file.startsWith('before-think-')).sort()) {
  const { snapshot: s } = JSON.parse(readFileSync(join(root, 'archer-assault-contact-replay.frames', file), 'utf8'));
  if (s.tick < 88110) continue;
  const target = s.buildings.find((building: any) => building.id === 'building-p1-shipyard-1016');
  const boats = s.units.filter((unit: any) => ['unit-p0-carrier-3510', 'unit-p0-carrier-3824'].includes(unit.id));
  rows.push({ tick: s.tick, boats: boats.map((boat: any) => ({ id: boat.id, speed: boat.sailing.speed, order: boat.order,
    legalPortraitUnloads: shipPassengers(s.units, boat).flatMap((passenger: any) => {
      const spot = passengerLandingSpot(s.map, boat, passenger.id, s.units);
      return spot && sameGround(s.map, spot, target) ? [{ id: passenger.id, kind: passenger.kind, spot }] : [];
    }) })) });
}
writeFileSync(join(root, 'archer-assault-passenger-window-query.json'), JSON.stringify({
  classification: 'read-only fixedv3 native public portrait-unload legality, no commands or snapshot mutations',
  source: 'archer-assault-reinforcement-v3-runtime-source.json', rows }, null, 2) + '\n');
console.log(JSON.stringify(rows.filter(row => row.boats.some((boat: any) => boat.legalPortraitUnloads.length))));
