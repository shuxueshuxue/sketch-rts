from pathlib import Path
import os,json,subprocess,time,resource,hashlib
D=Path('/tmp/bootstrap-medical-owner-contract-v9-20261016');w=Path('/tmp/sketch-rts-medical-owner-contract-v9-control');cap=json.loads((D/'final-runtime-source.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def audit():
 assert subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip()==cap['head'];assert not subprocess.check_output(['git','-C',str(w),'status','--porcelain','--untracked-files=all']).strip()
 for f in cap['files']:assert sha((w/f['path']).read_bytes())==f['sha256'],f['path']
 return {'head':cap['head'],'files':len(cap['files']),'capsuleSHA256':sha((D/'final-runtime-source.json').read_bytes())}
audit()
steps=[('narrow-actual12',768,['/workspace/sketch-rts/node_modules/.bin/vitest','run','src/ai/bootstrap_1/landed-combat.test.ts','--dir','src','--maxWorkers=1','--minWorkers=1','--pool=forks']),('tsc',1024,['/workspace/sketch-rts/node_modules/.bin/tsc','--noEmit'])]
for name,heap,args in steps:
 limit=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text());before=Path('/sys/fs/cgroup/memory.events').read_text();start=time.time();pre={'atUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'free':limit-current,'gate':2*1024**3,'heapMiB':heap,'source':audit(),'memoryEvents':before,'classification':'Finalsource actual12 with strengthened current cooldown-motion contract; then sequential single tsc. No ordinary0.'};(D/(name+'-resource.json')).write_text(json.dumps(pre,indent=2)+'\n');assert limit-current>2*1024**3
 env=dict(os.environ,NODE_OPTIONS=f'--max-old-space-size={heap}')
 with(D/(name+'.log')).open('x')as out:r=subprocess.run(args,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
 post={'actualExit':r.returncode,'elapsedSeconds':time.time()-start,'source':audit(),'memoryEventsAfter':Path('/sys/fs/cgroup/memory.events').read_text(),'logSHA256':sha((D/(name+'.log')).read_bytes()),'allPriorFilesUnchanged':True};(D/(name+'-result.json')).write_text(json.dumps(post,indent=2)+'\n');print(name,'actualexit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
