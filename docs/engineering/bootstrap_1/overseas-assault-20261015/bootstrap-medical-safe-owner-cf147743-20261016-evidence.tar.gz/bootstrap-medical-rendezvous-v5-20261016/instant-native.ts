import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual as same } from 'node:util';
import { NativeTelemetry } from './native-telemetry';

const D='/tmp/bootstrap-medical-rendezvous-v5-20261016';
const [startText,prefix]=process.argv.slice(2),start=Number(startText),end=start===30660?30705:30712;
if(![30660,30705].includes(start)||!prefix?.startsWith(D+'/')) throw Error('Expected actual30660|30705 and new absolute output prefix');
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const sha=(b:any)=>createHash('sha256').update(b).digest('hex');
const cap=read(D+'/final-runtime-source.json'),source=cap.root,head=cap.head;
const preflight=read(D+'/instant-preflight.json');
for(const [p,h] of Object.entries(preflight.files)) if(sha(readFileSync(D+'/'+p))!==h)throw Error('Driver/input/capsule changed '+p);
for(const suffix of ['-launch.json','-restore.json','-result.json','-final.json.gz','-commands.jsonl'])if(existsSync(prefix+suffix))throw Error('Preserve attempt '+suffix);
function guard(phase:string){const current=Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),limit=Number(readFileSync('/sys/fs/cgroup/memory.max','utf8'));const r={phase,current,limit,free:limit-current,atUTC:new Date().toISOString()};writeFileSync(prefix+'-resource-'+phase+'.json',JSON.stringify(r,null,2)+'\n',{flag:'wx'});if(r.free<=2*1024**3)throw Error('No Game: below2GiB '+r.free);}
function audit(){const actualHead=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'});if(actualHead!==head||status)throw Error('Source not fixed');return {head,status,files:cap.files.map((r:any)=>{const b=readFileSync(source+'/'+r.path),h=sha(b),blob=createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(h!==r.sha256||blob!==r.expectedGitBlob)throw Error('Source changed '+r.path);return{path:r.path,sha256:h,blob};})};}
guard('before-imports');const pre=audit();
for(const [p,h]of[[cap.sourceArchive,cap.sourceArchiveSHA256],[cap.frozenArchive,cap.frozenArchiveSHA256]])if(sha(readFileSync(p))!==h)throw Error('Capsule changed '+p);
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const sim=await load('src/shared/sim.ts'),{bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts');
const {ABILITY_DEFS}=await load('src/shared/catalog.ts');
const {armedFoes}=await load('src/ai/bootstrap_1/safe-land-route.ts');
const {medicalEscapeRoadAllows}=await load('src/ai/bootstrap_1/medical-task-safety.ts');
const input=JSON.parse(gunzipSync(readFileSync(D+'/'+start+'-actual-before-p0.json.gz')).toString());
const setup=input.setup;if(input.snapshot.tick!==start||setup.rulesVersion!==2||input.phase!=='actual-before-p0')throw Error('Wrong actual input');
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===0&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v7+v8');
if(!match||!same(copy(match.agents),setup.agents))throw Error('Ordinary setup changed');
guard('before-factory');
const game=bootstrapGame(match);sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
const owners=Object.keys(match.agents),memories=createAiMemoryProvider(copy(input.memories));
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
const restored=frame(),restore={world:same(restored.snapshot,input.snapshot),id:restored.nextId===input.nextId,all3mem:same(restored.memories,input.memories),setup:same(restored.setup,input.setup)};
writeFileSync(prefix+'-restored.json.gz',gzipSync(JSON.stringify(restored)+'\n'));writeFileSync(prefix+'-restore.json',JSON.stringify(restore,null,2)+'\n');if(!Object.values(restore).every(Boolean))throw Error('Restore failed, zero command/step');
const planner=await createBootstrapCommandPlanner(memories),frozenRoot=frozenPolicyRoot();
function frozenAudit(){if(frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision||Object.keys(frozenPolicyManifest.files).length!==184)throw Error('Frozen manifest changed');const rows=Object.entries(cap.frozenFiles).map(([p,h])=>{const actual=sha(readFileSync(frozenRoot+'/'+p));if(actual!==h)throw Error('Frozen changed '+p);return{path:p,sha256:actual};});if(rows.length!==497)throw Error('Not frozen497');return rows;}
const frozenPre=frozenAudit();
for(const stream of ['commands','plans','native-hits','native-events','native-deaths','ship-losses','clinical'])writeFileSync(prefix+'-'+stream+'.jsonl','',{flag:'wx'});
const frames=prefix+'-frames';mkdirSync(frames);
let commandIndex=input.commandIndex??0,steps=0,planCount=0,commandCount=0;
const telemetry=new NativeTelemetry(game,(s,e)=>appendFileSync(prefix+'-'+s+'.jsonl',JSON.stringify(e)+'\n'));
game.observer={hit:(a:any,t:any,d:number,h:number)=>telemetry.hit(a,t,d,h)};
const healerId=start===30660?'unit-p0-fieldMedic-1602':'unit-p0-fieldMedic-1418';
const patientId=start===30660?'unit-p0-priest-15352':'unit-p0-fieldMedic-1602';
const clinical:any[]=[];
const save=(phase:string,before?:any,after?:any)=>writeFileSync(frames+'/'+game.tick+'-'+phase+'.json.gz',gzipSync(JSON.stringify(before?{before,after,current:frame()}:frame())+'\n'));
writeFileSync(prefix+'-launch.json',JSON.stringify({pid:process.pid,atUTC:new Date().toISOString(),source,head,start,end,healerId,patientId,classification:'Changed-code actual-input normal3AI clinical component. No manual commands, no ordinary0, no victory inference.'},null,2)+'\n');
console.log(JSON.stringify({pid:process.pid,start,end,restore}));
const loop=runGameLoop({...match,maxTicks:end,game,commandPlanner:(ctx:any)=>{telemetry.commandIndex=commandIndex;const entries=planner(ctx);appendFileSync(prefix+'-plans.jsonl',JSON.stringify({tick:game.tick,owner:ctx.owner,entries})+'\n');planCount++;return entries;}},{
 afterCommand:(e:any)=>{
  if(e.owner!=='p0'||game.tick!==start)return;
  const isHeal=e.command.type==='cast'&&e.command.unitId===healerId&&e.command.ability==='heal'&&e.command.targetId===patientId;
  const isPhysical=['move','holdPosition'].includes(e.command.type)&&e.command.unitIds?.includes(healerId);
  if(!isHeal&&!isPhysical)return;
  const hb=e.before.units.find((u:any)=>u.id===healerId),ha=e.after.units.find((u:any)=>u.id===healerId),pb=e.before.units.find((u:any)=>u.id===patientId),pa=e.after.units.find((u:any)=>u.id===patientId);
  const actualRoadAllowed=isPhysical&&e.command.type==='move'?medicalEscapeRoadAllows(e.before,hb,armedFoes(e.before,'p0',{teams:e.before.teams}))(e.command):null;
  const row={commandIndex,tick:game.tick,owner:e.owner,scriptId:e.scriptId,command:e.command,isHeal,isPhysical,healerBefore:hb,healerAfter:ha,patientBefore:pb,patientAfter:pa,actualRoadAllowed,
   nativeInstantHeal:isHeal?pa.hp-pb.hp===Math.min(ABILITY_DEFS.heal.healAmount,pb.maxHp-pb.hp)&&(ha.abilityCooldowns?.heal??0)===ABILITY_DEFS.heal.cooldown&&same(hb.order,ha.order):null,
   physicalAccepted:isPhysical?e.command.type==='holdPosition'?ha.order.type==='hold':ha.order.type==='move'&&ha.order.x===e.command.x&&ha.order.y===e.command.y:null};
  clinical.push(copy(row));appendFileSync(prefix+'-clinical.jsonl',JSON.stringify(row)+'\n');save('clinical-'+commandIndex,e.before,e.after);
 },
 onCommand:(e:any)=>{telemetry.commandIndex=commandIndex++;commandCount++;appendFileSync(prefix+'-commands.jsonl',JSON.stringify({index:telemetry.commandIndex,tick:game.tick,owner:e.owner,source:e.source,scriptId:e.scriptId,command:e.command,traceKind:'SDK public attempt, acceptance proved separately in clinical before/after snapshots'})+'\n');telemetry.observe('after-command');telemetry.commandIndex=commandIndex;},
 beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();if(game.tick===start)save('after-all-commands-before-step');},
 onStep:()=>{steps++;telemetry.observe('after-step');}
});
const final=frame();writeFileSync(prefix+'-final.json.gz',gzipSync(JSON.stringify(final)+'\n'));
const post=audit(),frozenPost=frozenAudit();writeFileSync(prefix+'-source-audit.json',JSON.stringify({pre,post,frozenPre,frozenPost},null,2)+'\n');
const heals=clinical.filter(r=>r.isHeal),physical=clinical.filter(r=>r.isPhysical);
const checks={restore:Object.values(restore).every(Boolean),fixedRuntime:same(pre,post),fixedFrozen:same(frozenPre,frozenPost),steps:steps===end-start,oneOriginalTargetHeal:heals.length===1,instantHealApplied:heals.length===1&&heals[0].nativeInstantHeal===true,oneExistingPhysicalOwner:physical.length===1&&physical[0].owner==='p0'&&physical[0].scriptId==='v6Backline',physicalAccepted:physical.length===1&&physical[0].physicalAccepted===true,roadAllowed:physical.length===1&&(physical[0].actualRoadAllowed===true||physical[0].command.type==='holdPosition'),healBeforeEscape:heals.length===1&&physical.length===1&&heals[0].commandIndex<physical[0].commandIndex};
const result={source,head,start,end:game.tick,checks,counts:{steps,commands:commandCount,plans:planCount,runtime:pre.files.length,frozen497:frozenPre.length},clinical,telemetry:telemetry.summary(),healerFinal:final.snapshot.units.find((u:any)=>u.id===healerId)??null,patientFinal:final.snapshot.units.find((u:any)=>u.id===patientId)??null,elapsedMs:loop.elapsedMs,cpuMs:loop.cpuMs,classification:'52ticks in two exact actual inputs total. No ordinary0, full-match improvement or holdout claim.'};
writeFileSync(prefix+'-result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({start,end:game.tick,checks,counts:result.counts}));if(!Object.values(checks).every(Boolean))process.exitCode=1;
