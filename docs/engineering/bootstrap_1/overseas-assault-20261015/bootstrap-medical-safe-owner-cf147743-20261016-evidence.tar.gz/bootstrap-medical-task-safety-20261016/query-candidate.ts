import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {setBuildingBodies} from '/tmp/sketch-rts-medical-task-safety-control/src/shared/terrain.ts';
import {planAiOwnerCommandEntries} from '/tmp/sketch-rts-medical-task-safety-control/src/ai/planner-context.ts';
import {planBootstrapCasterScreen} from '/tmp/sketch-rts-medical-task-safety-control/src/ai/bootstrap_1/caster-screen.ts';
import {planMedicalRecovery,recoveryPatients,medicalRecoveryUnitIds} from '/tmp/sketch-rts-medical-task-safety-control/src/ai/bootstrap_1/medical-recovery.ts';
import {bootstrapPolicyContext} from '/tmp/sketch-rts-medical-task-safety-control/src/ai/bootstrap_1/policy.ts';
const prefix='/tmp/bootstrap-archer-38f-losses-27000-33000-readonly-20261016/';
const rows=[];
for(const file of ['events/30302-after-step-87.json.gz','events/30346-after-step-88.json.gz','frames/30600.json.gz']){
 const f=JSON.parse(gunzipSync(readFileSync(prefix+file)).toString());const s=f.snapshot;setBuildingBodies(s.map,s.buildings);
 const opt={version:'v9_archer',memory:structuredClone(f.memories.p0),teams:s.teams};
 const ctx=bootstrapPolicyContext(s,'p0','v9_archer',opt as any);
 const filter=(c:any)=>[...(c.command?.unitIds??c.unitIds??[]),c.command?.unitId??c.unitId].some(id=>s.units.some((u:any)=>u.id===id&&u.owner==='p0'&&['priest','fieldMedic'].includes(u.kind)));
 const patients=recoveryPatients(s,'p0');
 rows.push({file,tick:s.tick,healers:s.units.filter((u:any)=>u.owner==='p0'&&['priest','fieldMedic'].includes(u.kind)),patients,medicalIds:[...medicalRecoveryUnitIds(s,'p0')],medical:planMedicalRecovery(s,'p0',patients),backline:planBootstrapCasterScreen(s,'p0',ctx).filter(filter),entries:planAiOwnerCommandEntries(s,{playerId:'p0',...opt} as any,{teams:s.teams}).filter(filter)});
}
writeFileSync('/tmp/bootstrap-medical-task-safety-20261016/candidate-query.json',JSON.stringify(rows,null,2)+'\n');
console.log(rows.map(r=>({tick:r.tick,medical:r.medical,backline:r.backline,entries:r.entries})));
