import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import{createHash}from'node:crypto';
const D='/tmp/bootstrap-medical-task-safety-20261016',rows=[];
for(const[source,label]of[['/workspace/sketch-rts-archer-firstuse-38f-control','original38f'],['/tmp/sketch-rts-medical-task-safety-control','acba']]){
 const load=(p:string)=>import(pathToFileURL(source+'/'+p).href),{setBuildingBodies}=await load('src/shared/terrain.ts'),{planAiOwnerCommandEntries}=await load('src/ai/planner-context.ts'),{ABILITY_DEFS}=await load('src/shared/catalog.ts'),{abilityCooldown}=await load('src/shared/ability-cooldowns.ts');
 for(const tick of[30660,30705]){
  const bytes=readFileSync(D+'/baseline-window-frames/'+tick+'-actual-before-p0.json.gz'),f=JSON.parse(gunzipSync(bytes).toString()),s=f.snapshot;setBuildingBodies(s.map,[...s.buildings,...s.obstacles??[]]);const before=JSON.stringify(s),casterId=tick===30660?'unit-p0-fieldMedic-1602':'unit-p0-fieldMedic-1418',targetId=tick===30660?'unit-p0-priest-15352':'unit-p0-fieldMedic-1602',caster=s.units.find((u:any)=>u.id===casterId),target=s.units.find((u:any)=>u.id===targetId);
  const entries=planAiOwnerCommandEntries(s,{playerId:'p0',version:'v9_archer',memory:f.memories.p0},{teams:s.teams}),commands=entries.filter((e:any)=>e.command.unitId===casterId||(e.command.unitIds??[]).includes(casterId));
  rows.push({label,source,tick,inputSHA256:createHash('sha256').update(bytes).digest('hex'),snapshotUnchanged:JSON.stringify(s)===before,caster,target,originalOpportunity:{distance:Math.hypot(caster.x-target.x,caster.y-target.y),range:ABILITY_DEFS.heal.range,healCooldown:abilityCooldown(caster,'heal'),targetCritical:target.hp<target.maxHp*.35},commands,spellTargets:commands.filter((e:any)=>e.command.type==='cast').map((e:any)=>({entry:e,target:s.units.find((u:any)=>u.id===e.command.targetId)})),allEntries:entries});
 }
}
writeFileSync(D+'/ACTUAL-INSTANT-OPPORTUNITIES-QUERY.json',JSON.stringify(rows,null,2)+'\n');console.log(rows.map(r=>({label:r.label,tick:r.tick,op:r.originalOpportunity,commands:r.commands})));
