import {readFileSync,writeFileSync,appendFileSync,mkdirSync,existsSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {isDeepStrictEqual as same} from 'node:util';
import {NativeTelemetry} from './native-telemetry';
const [source,head,kind,prefix]=process.argv.slice(2),D='/tmp/bootstrap-medical-task-safety-20261016';
if(!source||!head||!prefix||!['baseline','candidate'].includes(kind))throw Error('ABS_SOURCE FULL_HEAD baseline|candidate ABS_PREFIX');
const sha=(b:any)=>createHash('sha256').update(b).digest('hex'),copy=(x:any)=>JSON.parse(JSON.stringify(x));
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const cap=read(D+'/'+(kind==='candidate'?'candidate-v2':kind)+'-runtime-source.json'),preflight=read(D+'/'+kind+'-driver-preflight.json');
for(const[p,h]of Object.entries(preflight.files))if(sha(readFileSync(D+'/'+p))!==h)throw Error('Driver/input/capsule changed '+p);
if(cap.root!==source||cap.head!==head||!cap.archiveReadbackVerified)throw Error('Source binding changed');
for(const suffix of ['-launch.json','-restore.json','-result.json','-final.json.gz','-commands.jsonl'])if(existsSync(prefix+suffix))throw Error('Preserve prior native attempt '+suffix);
function guard(phase:string){const current=Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),limit=Number(readFileSync('/sys/fs/cgroup/memory.max','utf8')),sample={phase,current,limit,free:limit-current,atUTC:new Date().toISOString()};writeFileSync(prefix+'-resource-'+phase+'.json',JSON.stringify(sample,null,2)+'\n',{flag:'wx'});if(sample.free<=2*1024**3)throw Error('No Game: below2GiB gate '+sample.free);return sample;}
function audit(){const actualHead=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'});if(actualHead!==head||status)throw Error('Source not fixed');const files=cap.files.map((r:any)=>{const b=readFileSync(source+'/'+r.path),h=sha(b),blob=createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(h!==r.sha256||blob!==r.expectedGitBlob)throw Error('Runtime bytes changed '+r.path);return{path:r.path,sha256:h,blob};});return{head:actualHead,status,files};}
guard('before-imports');const pre=audit();
for(const[p,h]of[[cap.sourceArchive,cap.sourceArchiveSHA256],[cap.frozenArchive,cap.frozenArchiveSHA256]])if(sha(readFileSync(p))!==h)throw Error('Archive changed');
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const sim=await load('src/shared/sim.ts'),{bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts'),{createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const{createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest}=await load('scripts/bootstrap_1-planner.ts');const{runGameLoop}=await load('src/sdk/game-runner.ts');
const input=JSON.parse(gunzipSync(readFileSync(D+'/input30346.json.gz')).toString()),expected=JSON.parse(gunzipSync(readFileSync(D+'/reference30600.json.gz')).toString());
const setup=input.setup,start=30346,end=30600;if(input.snapshot.tick!==start||expected.snapshot.tick!==end||setup.rulesVersion!==2)throw Error('Wrong actual window');
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===0&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v7+v8');
if(!match||!same(copy(match.agents),setup.agents))throw Error('Ordinary opponent/setup changed');
guard('before-factory');
const game=bootstrapGame(match);sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);const owners=Object.keys(match.agents),memories=createAiMemoryProvider(copy(input.memories));
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
const restored=frame(),checksRestore={world:same(restored.snapshot,input.snapshot),id:restored.nextId===input.nextId,all3mem:same(restored.memories,input.memories),setup:same(restored.setup,input.setup)};
writeFileSync(prefix+'-restored.json.gz',gzipSync(JSON.stringify(restored)+'\n'));writeFileSync(prefix+'-restore.json',JSON.stringify(checksRestore,null,2)+'\n');if(!Object.values(checksRestore).every(Boolean))throw Error('Strict restore failed before any step');
const planner=await createBootstrapCommandPlanner(memories),frozenRoot=frozenPolicyRoot();
function frozenAudit(){if(frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision||Object.keys(frozenPolicyManifest.files).length!==184)throw Error('Frozen manifest changed');const files=Object.entries(cap.frozenFiles).map(([p,h])=>{const actual=sha(readFileSync(frozenRoot+'/'+p));if(actual!==h)throw Error('Frozen bytes changed '+p);return{path:p,sha256:actual};});if(files.length!==497)throw Error('Wrong frozen497');for(const[p,h]of Object.entries(frozenPolicyManifest.files))if(sha(readFileSync(frozenRoot+'/'+p))!==h)throw Error('Wrong manifest184');return files;}
const frozenPre=frozenAudit(),refCommands=read(D+'/reference-commands.json'),refHits=read(D+'/reference-native-hits.json'),refPlans=read(D+'/reference-plans.json');
const rows:any={commands:[],hits:[],plans:[]};let commandIndex=refCommands[0].index,steps=0;
for(const stream of ['commands','plans','native-hits','native-events','native-deaths','ship-losses'])writeFileSync(prefix+'-'+stream+'.jsonl','',{flag:'wx'});
const telemetry=new NativeTelemetry(game,(stream,event)=>{appendFileSync(prefix+'-'+stream+'.jsonl',JSON.stringify(event)+'\n');if(stream==='native-hits')rows.hits.push(copy(event));});telemetry.hitIndex=refHits[0].index;
game.observer={hit:(a:any,t:any,d:number,h:number)=>telemetry.hit(a,t,d,h)};
const frames=prefix+'-frames';mkdirSync(frames);const capture=(phase:string)=>writeFileSync(frames+'/'+game.tick+'-'+phase+'.json.gz',gzipSync(JSON.stringify({...frame(),phase,commandIndex:telemetry.commandIndex})+'\n'));
writeFileSync(prefix+'-launch.json',JSON.stringify({pid:process.pid,atUTC:new Date().toISOString(),kind,source,head,start,end,checksRestore,classification:'Actual normal3AI254tick component, unchanged full input. Baseline closes original30600. Candidate changed-code component only, not ordinary0 or match result.'},null,2)+'\n');
console.log(JSON.stringify({kind,pid:process.pid,start,end,checksRestore}));
let loop:any;
const runNative=(limit:number)=>runGameLoop({...match,maxTicks:limit,game,commandPlanner:(ctx:any)=>{telemetry.commandIndex=commandIndex;if(kind==='baseline'&&ctx.owner==='p0'&&[30660,30705].includes(game.tick))capture('actual-before-p0');const entries=planner(ctx),row={tick:game.tick,owner:ctx.owner,entries};rows.plans.push(copy(row));appendFileSync(prefix+'-plans.jsonl',JSON.stringify(row)+'\n');return entries;}},{onCommand:(e:any)=>{telemetry.commandIndex=commandIndex++;const row={index:telemetry.commandIndex,tick:game.tick,owner:e.owner,source:e.source,scriptId:e.scriptId,command:e.command,traceKind:'SDK public-command attempt; transient skips also call onCommand'};rows.commands.push(copy(row));appendFileSync(prefix+'-commands.jsonl',JSON.stringify(row)+'\n');telemetry.observe('after-command');if(e.owner==='p0'&&game.tick===30360&&[...(e.command.unitIds??[]),e.command.unitId].some(id=>input.snapshot.units.some((u:any)=>u.id===id&&u.owner==='p0'&&['priest','fieldMedic'].includes(u.kind))))capture('after-'+telemetry.commandIndex+'-'+e.scriptId);telemetry.commandIndex=commandIndex;},beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();if(game.tick===start||game.tick%15===0)capture('before-step');},onStep:()=>{steps++;telemetry.observe('after-step');}});
try{loop=runNative(end);}catch(e){writeFileSync(prefix+'-interruption.json.gz',gzipSync(JSON.stringify(frame())+'\n'));throw e;}
const final=frame();writeFileSync(prefix+'-checkpoint30600.json.gz',gzipSync(JSON.stringify(final)+'\n'));writeFileSync(prefix+'-final.json.gz',gzipSync(JSON.stringify(final)+'\n'));const post=audit(),frozenPost=frozenAudit();
const expectedFrame={snapshot:expected.snapshot,nextId:expected.nextId,memories:expected.memories,setup:expected.setup};
const first=(a:any[],b:any[])=>{for(let i=0;i<Math.max(a.length,b.length);i++)if(!same(a[i],b[i]))return{position:i,actual:a[i]??null,original:b[i]??null};return null;};
const checks={restore:Object.values(checksRestore).every(Boolean),fixedRuntime:same(pre,post),fixedFrozen:same(frozenPre,frozenPost),steps254:steps===254,commands:same(rows.commands,refCommands),hits:same(rows.hits,refHits),plans:same(rows.plans,refPlans),finalWorld:same(final.snapshot,expected.snapshot),finalId:final.nextId===expected.nextId,final3mem:same(final.memories,expected.memories),finalWholeSavedObject:same(final,expectedFrame)};
writeFileSync(prefix+'-source-audit.json',JSON.stringify({pre,post,frozenPre,frozenPost},null,2)+'\n');
const healerIds=input.snapshot.units.filter((u:any)=>u.owner==='p0'&&['priest','fieldMedic'].includes(u.kind)).map((u:any)=>u.id);
const report={kind,source,head,classification:'Two-source focused native component; no victory or generalization claim.',start,end:game.tick,checks,counts:{steps,commands:rows.commands.length,hits:rows.hits.length,plans:rows.plans.length,runtime:pre.files.length,frozen497:frozenPre.length},firstCommandDifference:first(rows.commands,refCommands),firstHitDifference:first(rows.hits,refHits),healers:final.snapshot.units.filter((u:any)=>healerIds.includes(u.id)),healerHits:rows.hits.filter((h:any)=>healerIds.includes(h.target)),telemetry:telemetry.summary(),elapsedMs:loop.elapsedMs,cpuMs:loop.cpuMs};
if(kind==='baseline'&&Object.values(checks).every(Boolean)) {
  // Continue this very same restored Game only to recover the two original
  // ready/in-range command frames; not a third factory or an extra match.
  const tailExpected=JSON.parse(gunzipSync(readFileSync(D+'/reference30712.json.gz')).toString());
  const tailFrame={snapshot:tailExpected.snapshot,nextId:tailExpected.nextId,memories:tailExpected.memories,setup:tailExpected.setup};
  const beforeTailSteps=steps;runNative(30712);const tailFinal=frame();
  writeFileSync(prefix+'-tail-final30712.json.gz',gzipSync(JSON.stringify(tailFinal)+'\n'));
  const tailChecks={steps112:steps-beforeTailSteps===112,commands:same(rows.commands,[...refCommands,...read(D+'/tail-reference-commands.json')]),hits:same(rows.hits,[...refHits,...read(D+'/tail-reference-native-hits.json')]),plans:same(rows.plans,[...refPlans,...read(D+'/tail-reference-plans.json')]),wholeSavedObject:same(tailFinal,tailFrame),source:same(pre,audit()),frozen:same(frozenPre,frozenAudit())};
  (report as any).originalInputRecoveryTail={start:30600,end:game.tick,steps:steps-beforeTailSteps,checks:tailChecks,allExact:Object.values(tailChecks).every(Boolean),classification:'Same original Game after its exact254 checkpoint. Full original30660 and30705 beforeP0 frames captured; original30712 full world/id/3mem/setup closes extra112.'};
  if(!Object.values(tailChecks).every(Boolean))process.exitCode=1;
}
writeFileSync(prefix+'-result.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({kind,checks,counts:report.counts}));if(!checks.restore||!checks.fixedRuntime||!checks.fixedFrozen||!checks.steps254||kind==='baseline'&&!Object.values(checks).every(Boolean))process.exitCode=1;
