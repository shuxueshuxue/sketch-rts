8a40ae71 是基于 201b 的隔离候选，尚未合入。它只给现有 landed-combat owner 增加接敌微操，复用 mountedMicro 的射击窗口、真实地形/建筑道路和身体避让；保留原35%入口、治疗优先级、55治疗、正常对手与规则2冻结策略。没有增加任务记忆、指挥层或计时阈值。

原201b镜像营地1800tick完整诊断：136条命令、66次命中，front最终61HP，但shooter-2在441死亡。两营地敌人清除并不抵消己方永久损失。最早物理分歧在150发布命令（201b保留未完成医疗move），165世界首次分歧；不能套用此前7b的390/405→504前排死亡因果。360时shooter-2冷却8、无aim、速度60，brute速度70、距离61.575686249891014、近战覆盖94。旧微操算24像素后因原30像素下限返回空，随后attackMove让射手停下，365受第一击。375旧撤退线穿shooter-0身体（17.459像素<所需32）。原生435/441画面已亲看，完整raw与SHA见D6 FIRST-SHOOTER-LOSS-CAUSAL.json。

同一份360/375实际完整快照构成6个纯合同（三条路线）。固定201b旧源6红，8a40候选6绿。正例要求真实非零移动、增加对brute距离、原生可达道路、完整身体清路，并保375原healer→front唯一即时heal；没有降低原无损/营地清空断言。

固定源码完整头：8a40ae71f9481d10a6e130fc20762469e9e20346。fixed-runtime-source.json及fixed-source.tar.gz封存1490个live文件和497个冻结源文件，INDEX逐项回读一致。source archive 5,939,583 bytes，SHA256 7348a996b5269e96d7f80b4d6e79d779bb1479f4bdb7232b003d8bdfd3e9e460。冻结manifest rules2 /184 files/revision d1ae110f保持原字节。封源第一次完整头手写错误被rev-parse断言拒绝，记录保留；更正为实际HEAD后才生成完整capsule。

原mirror1800候选诊断两次启动均在before-imports的严格2GiB门拒绝：free分别2,086,170,624及2,131,947,520 bytes，零游戏模块import、零factory、零command/step，不能记作原生比赛运行。只读封闭Git pack/自有archive页缓存建议不改变文件数据或系统安全设置，receipt逐项验证size/mtime/inode不变。没有降资源门或停止其他Game。

旧fd实验按root支持的完整367200资源checkpoint暂停（未终局，winnernull）实际退出后，唯一原mirror1800确实完成：初始精确、1490源前后真，168命令/70命中，4名射手均存活，但front531死亡，native永久损失1。之后一次原12精准筛为9绿3红（Grove镜像三条路线），所以8a40否决，不合入。相对201b首次命令差在135：新微操让当时距brute约127、尚在原生近战94外的ready shooter-3先逃，改变了此后前排承伤/治疗与战斗；不能只看360叶绿或射手存活。完整原因账见NEGATIVE-8A40-NATIVE.json，原raw与531完整首死世界保留。

没有继续83邻域、42原纯合同、tsc、52原始临床或ordinary0。下一步仍沿实际接敌/可执行道路缩窄战斗owner，保全部失败证据。原seed完整archer普通0比赛由root在最终合源封存后负责。当前6纯绿不证明能跑赢更快敌人、无损、完整比赛获胜或bootstrap验收。原容器未提交改动仍无法恢复。
