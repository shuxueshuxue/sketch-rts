import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual as same } from 'node:util';
const D='/tmp/bootstrap-medical-task-safety-v4-20261016';
const [capsule,prefix,mode]=process.argv.slice(2),cap=JSON.parse(readFileSync(capsule!,'utf8')),source=cap.root,head=cap.head;
if(!prefix?.startsWith(D+'/')||!['original','changed'].includes(mode!))throw Error('CAPSULE ABS_NEW_PREFIX original|changed');
const sha=(b:any)=>createHash('sha256').update(b).digest('hex'),copy=(v:any)=>JSON.parse(JSON.stringify(v));
function guard(phase:string){const current=Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),limit=Number(readFileSync('/sys/fs/cgroup/memory.max','utf8')),r={phase,current,limit,free:limit-current,atUTC:new Date().toISOString()};writeFileSync(prefix+'-resource-'+phase+'.json',JSON.stringify(r,null,2)+'\n',{flag:'wx'});if(r.free<=2*1024**3)throw Error('No factory below2GiB');}
function audit(){if(execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim()!==head||execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'}).trim())throw Error('Source not fixed');for(const r of cap.files)if(sha(readFileSync(source+'/'+r.path))!==r.sha256)throw Error('Source changed '+r.path);return{head,files:cap.files.length,sha256:sha(readFileSync(capsule!))};}
for(const suffix of ['-launch.json','-result.json','-commands.jsonl'])if(existsSync(prefix+suffix))throw Error('Preserve prior attempt');
guard('before-imports');const pre=audit();
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const {sketchScene}=await load('src/sdk/scene.ts'),{SdkCommandFrameRuntime}=await load('src/sdk/commands/frame.ts');
const {snapshotGame,restoreSnapshotIntoGame,stepGame}=await load('src/shared/sim.ts');
const {createAiPolicyMemory}=await load('src/ai/memory.ts');
const {runAiCommandEntriesFromScripts}=await load('src/ai/policy/script-runner.ts');
const {bootstrapPolicyContext,bootstrapScripts}=await load('src/ai/bootstrap_1/policy.ts');
guard('before-factory');
const x=(v:number)=>4096-v;
let scene=sketchScene('expedition-rotation').map('bareDuel').replaceDefaults()
 .player('us',{race:'grove',team:'a'}).player('foe',{race:'grove',team:'b'})
 .townHall('us',x(500),500).townHall('foe',x(500),3500)
 .unit('us','lancer',x(3000),1800,{id:'front'}).unit('us','priest',x(2850),1680,{id:'healer'})
 .unit('neutral','deepSnapper',x(3210),1700,{id:'brute'}).unit('neutral','tidePriest',x(3100),1700,{id:'guard'});
for(let i=0;i<4;i++)scene=scene.unit('us','archer',x(2810+i%2*35),1560+Math.floor(i/2)*35,{id:'shooter-'+i});
const game=scene.build().createGame();game.map.terrain={cell:32,cols:128,rows:128,cells:Array.from({length:128*128},(_,i)=>{const col=127-i%128;return col<25||col>=76?'.':'~';}).join('')};
let memory=createAiPolicyMemory();const initialPath=D+'/expedition-initial.json.gz';
if(mode==='changed'){const initial=JSON.parse(gunzipSync(readFileSync(initialPath)).toString());restoreSnapshotIntoGame(game,initial.snapshot,initial.nextId);memory=copy(initial.memory);}
const frame=()=>copy({snapshot:snapshotGame(game),nextId:game.nextId,memory});
const initial=frame();if(mode==='original')writeFileSync(initialPath,gzipSync(JSON.stringify(initial)+'\n'),{flag:'wx'});
const saved=JSON.parse(gunzipSync(readFileSync(initialPath)).toString());if(!same(initial,saved))throw Error('Full world/id/memory restore failed, zero command/step');
writeFileSync(prefix+'-launch.json',JSON.stringify({pid:process.pid,atUTC:new Date().toISOString(),head,source,mode,initialSHA256:sha(readFileSync(initialPath)),driverSHA256:sha(readFileSync(D+'/expedition-negative-native.ts')),originalFixtureSHA256:sha(readFileSync(source+'/src/ai/bootstrap_1/expedition-recovery.test.ts')),fullInitialWorldIdMemoryExact:true,classification:'Single existing v9_archer Grove mirror=true expedition-recovery native fixture; not a normal3AI match. No added gameplay commands.'},null,2)+'\n');
const frames=prefix+'-frames';mkdirSync(frames);for(const suffix of ['commands','hits','plans','deaths'])writeFileSync(prefix+'-'+suffix+'.jsonl','',{flag:'wx'});
const sdk=new SdkCommandFrameRuntime(game),scripts=bootstrapScripts('v9_archer').filter((s:any)=>s.id==='naval');let commandCount=0,hits=0,firstOwnDeath:any=null,previousHP=new Map(game.units.map((u:any)=>[u.id,u.hp]));
const rows=(snapshot:any)=>snapshot.units.filter((u:any)=>u.owner==='us').map((u:any)=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order,healCooldown:u.abilityCooldowns?.heal??0}));
const capture=(phase:string)=>writeFileSync(frames+'/'+game.tick+'-'+phase+'.json.gz',gzipSync(JSON.stringify({...frame(),phase})+'\n'));
game.observer={hit:(a:any,t:any,d:number,h:number)=>{appendFileSync(prefix+'-hits.jsonl',JSON.stringify({index:hits++,tick:game.tick,attacker:copy(a),target:copy(t),damage:d,hpBefore:h,hpAfter:t.hp})+'\n');}};
for(let tick=0;tick<1800;tick++){
 if(tick%15===0){capture('before-plan');const snapshot=snapshotGame(game),options=bootstrapPolicyContext(snapshot,'us','v9_archer',{memory,teams:game.teams}),entries=runAiCommandEntriesFromScripts(snapshot,'us',scripts,options);appendFileSync(prefix+'-plans.jsonl',JSON.stringify({tick:game.tick,entries,own:rows(snapshot),memory:copy(memory)})+'\n');
  sdk.issue(entries.map((e:any)=>({...e,playerId:'us'})),{afterIssue:(entry:any)=>{appendFileSync(prefix+'-commands.jsonl',JSON.stringify({index:commandCount++,tick:game.tick,entry,own:rows(snapshotGame(game))})+'\n');}},{checksum:false});
 }
 stepGame(game);
 for(const [id,hp] of previousHP){const u=game.units.find((v:any)=>v.id===id);if(hp>0&&(!u||u.hp<=0)){const death={tick:game.tick,id,atObservation:u?copy(u):null,own:rows(snapshotGame(game))};appendFileSync(prefix+'-deaths.jsonl',JSON.stringify(death)+'\n');if(id==='front'&&!firstOwnDeath){firstOwnDeath=death;capture('first-front-death');}}}
 previousHP=new Map(game.units.map((u:any)=>[u.id,u.hp]));
}
const final=frame();writeFileSync(prefix+'-final.json.gz',gzipSync(JSON.stringify(final)+'\n'));const post=audit();
const result={head,source,mode,pre,post,fixedSource:same(pre,post),initialExact:true,tick:game.tick,commands:commandCount,hits,firstOwnDeath,ownFinal:rows(final.snapshot),nativeUnitsLost:game.match.stats.unitsLost,remainingEnemies:game.units.filter((u:any)=>['brute','guard'].includes(u.id)).map(copy),initialSHA256:sha(readFileSync(initialPath)),driverSHA256:sha(readFileSync(D+'/expedition-negative-native.ts'))};
writeFileSync(prefix+'-result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({head,tick:game.tick,commands:commandCount,hits,frontAlive:game.units.some((u:any)=>u.id==='front'&&u.hp>0),firstFrontDeathTick:firstOwnDeath?.tick??null,fixedSource:result.fixedSource}));
