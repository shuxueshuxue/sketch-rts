from pathlib import Path
import json,hashlib,tarfile,io,os,sys
P=Path('/tmp/bootstrap-medical-safe-owner-cf147743-20261016');inventory=Path(str(P)+'-INVENTORY.json');archive=Path(str(P)+'-evidence.tar.gz');receipt=Path(str(P)+'-seal-receipt.json')
sha=lambda p:hashfile(p)
def hashfile(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
roots=[Path('/tmp/'+n)for n in ['bootstrap-medical-task-safety-20261016','bootstrap-medical-task-safety-v3-20261016','bootstrap-medical-task-safety-v4-20261016','bootstrap-medical-rendezvous-v5-20261016','bootstrap-medical-goal-v6-20261016','bootstrap-medical-landed-contact-v7-20261016','bootstrap-medical-landed-contact-v8-20261016','bootstrap-medical-owner-contract-v9-20261016','medical-exposed-shooter-static-201b-20261016','bootstrap-medical-7b2a-independent-static-review-20261016']]
if sys.argv[1:] == ['inventory']:
 files={}
 for root in roots:
  for p in sorted(root.rglob('*')):
   if p.is_symlink()or not p.is_file()or'node_modules'in p.parts:continue
   s=p.stat();files[root.name+'/'+str(p.relative_to(root))]={'source':str(p),'bytes':s.st_size,'sha256':sha(p)}
 script=Path(__file__);files['support/SEAL_RECIPE.py']={'source':str(script),'bytes':script.stat().st_size,'sha256':sha(script)}
 out={'classification':'Complete SHA/size inventory only. No archive created. Stream seal explicitly deferred by parent until sufficient capacity after knownordinary0 initialization; do not delete originalraw.','finalCommit':'cf1477432b35844d891c22aac21afc15b8e7bef6','payloadFiles':len(files),'payloadBytes':sum(r['bytes']for r in files.values()),'files':files};inventory.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'inventory':str(inventory),'sha256':sha(inventory),'files':len(files),'bytes':out['payloadBytes'],'archiveCreated':False}));raise SystemExit(0)
if sys.argv[1:]!=['seal']:raise SystemExit('inventory | seal; runseal only after parent capacity handoff')
i=json.loads(inventory.read_text());assert not archive.exists()and not receipt.exists();st=os.statvfs(archive.parent);assert st.f_bavail*st.f_frsize>i['payloadBytes']+256*1024**2,'capacitygate: enoughforwholeuncompressedpayload plus256MiB reserved afterworstcase write'
for name,r in i['files'].items():
 p=Path(r['source']);assert p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'changedpayload '+name
with tarfile.open(archive,'x:gz',compresslevel=1)as tar:
 for name,r in sorted(i['files'].items()):
  e=tarfile.TarInfo(name);e.size=r['bytes'];e.mode=0o644;e.mtime=0
  with Path(r['source']).open('rb')as f:tar.addfile(e,f)
 data=(json.dumps(i,indent=2)+'\n').encode();e=tarfile.TarInfo('INDEX.json');e.size=len(data);e.mode=0o644;e.mtime=0;tar.addfile(e,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 names=[]
 for e in tar:
  if not e.isfile():continue
  names.append(e.name)
  if e.name=='INDEX.json':assert json.load(tar.extractfile(e))==i;continue
  r=i['files'][e.name];assert e.size==r['bytes'];h=hashlib.sha256()
  with tar.extractfile(e)as f:
   while b:=f.read(1024*1024):h.update(b)
  assert h.hexdigest()==r['sha256'],e.name
 assert len(names)==len(i['files'])+1 and len(names)==len(set(names))
r={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'payloadFiles':len(i['files']),'regularMembersIncludingINDEX':len(i['files'])+1,'readbackAllSHA256Exact':True,'inventorySHA256':sha(inventory),'classification':'All own medical raw/source/negative history preserved; native52 scope not a continuousgame or acceptance; sourcecf147.'};receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
