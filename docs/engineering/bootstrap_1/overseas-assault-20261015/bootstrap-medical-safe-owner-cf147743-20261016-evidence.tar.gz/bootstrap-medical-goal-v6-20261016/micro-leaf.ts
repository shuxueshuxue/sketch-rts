import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const D='/tmp/bootstrap-medical-goal-v6-20261016', root='/tmp/sketch-rts-medical-goal-v6-control';
const free=Number(readFileSync('/sys/fs/cgroup/memory.max','utf8'))-Number(readFileSync('/sys/fs/cgroup/memory.current','utf8'));
if(free<=1024**3)throw Error('Pure noGame leaf1GiB guard');
const {mountedMicro,mountedThreatReach,mountedEscape}=await import(root+'/src/ai/bootstrap_1/mounted-micro.ts');
const {planRangedKiting}=await import(root+'/src/ai/policy/skirmish-tactics.ts');
const {bootstrapPolicyContext}=await import(root+'/src/ai/bootstrap_1/policy.ts');
const {planLandedCombat}=await import(root+'/src/ai/bootstrap_1/landed-combat.ts');
const sha=(b:any)=>createHash('sha256').update(b).digest('hex');const rows=[];
for(const tick of [150,345,360,375,390,405,435]){
 const input=D+'/expedition201b-frames/'+tick+'-before-plan.json.gz',raw=readFileSync(input),f=JSON.parse(gunzipSync(raw).toString()),s=f.snapshot,original=JSON.stringify(f),u=s.units.find((u:any)=>u.id==='shooter-2'),foe=s.units.find((u:any)=>u.id==='brute'),cover=s.units.find((u:any)=>u.id==='healer'),options=bootstrapPolicyContext(s,'us','v9_archer',{memory:f.memory});
 const foes=s.units.filter((u:any)=>u.owner==='neutral');const local=planLandedCombat(s,'us',options,new Set(['front']));
 const old=planRangedKiting(s,'us',options,[u],foes,cover),micro=mountedMicro(s,u,foe,foes,{kind:'camp'});
 rows.push({tick,inputSHA256:sha(raw),u,foe,distance:Math.hypot(u.x-foe.x,u.y-foe.y),reach:mountedThreatReach(s,foe,u,15),old,micro,local:local.filter((c:any)=>c.unitIds?.includes(u.id)),directEscape:mountedEscape(s,u,foes,0,undefined,false),snapshotUnchanged:JSON.stringify(s)===JSON.parse(original).snapshot?true:JSON.stringify(s)===JSON.stringify(JSON.parse(original).snapshot)});
}
writeFileSync(D+'/micro-leaf.json',JSON.stringify({classification:'Pure existing native-geometry planner leaf on fixed201b saved synthetic fixture; no factory/Game/step/fullP0/new orders accepted. Memory is cloned input and per-query planners only.',head:'201b70498c6f5331820d0e60a56e3be60ab10b50',freeBeforeImports:free,driverSHA256:sha(readFileSync(D+'/micro-leaf.ts')),rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,old:r.old,micro:r.micro,local:r.local,distance:r.distance,reach:r.reach,unchanged:r.snapshotUnchanged}))));
