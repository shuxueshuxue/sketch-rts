# Transfer lane V2: real62400 counter and native repair recovery

Use transfer-v2-only.patch for the proposed incremental change. It applies cleanly to root's current independent bootstrap branch (git apply --check only; no root changes were made). Do not apply transfer-only.patch: that read-only V1 incorrectly narrowed passenger eligibility to land. Parent review caught this before any native run; V1 source/control/queries are retained, while separate sparse V2 restores original non-ship/non-cabin permission, including legal air passengers.

## Exact scope and provenance

This follows the immutable loading-escort-only history from original ordinary50400 to62400. That history still failed the first enemy-island deployment; see prior26,594,423byte package SHAe988bcc68955b7f2ddf3e772f7cd4a8058764ce32e632e8bd99b36f7b57830e6. The current test changes code only at the actual verified periodic62400 frame. It is not an original ordinary62400 checkpoint, fresh opening, completed match or acceptance result.

Rules2, same original normal frozen184 v5, same Grove v9_knight seed/map/setup, both complete owner memories and nextId. V2 and old-loading counter input world/id/bothmem are exactly equal. Each source-fixed native window is only62400→63600 (1200ticks), with compressed full snapshots every15ticks and monitored deck-parent/life events. Source manifests capture865files; all source pre/post and full starting restore checks pass. Both source archives preserve native canBoard, decks, connected-surface, rule and ship implementations byte-for-byte. TypeScript passed. No manual body/ship placement or private engine command was applied.

## Mechanism

Original worker1851 hasfollow1935 with queuedboard1139. Receiving cutter has one witch2089 occupying the only worker landing area. Native canBoard=false, connectedSurfacePath=null although actual load and unoccupied physical floor permit the worker. clearDeckTransfers skips at!canBoard and also unconditionally skips queuedfollow/hold after failing its boarding path test, so it never tries its existing bystander yielding routine.

V2 keeps load/profile/cabin/physical-contact/static-floor legality before planning a yield, then lets queuedfollow/hold enter the existing deckYieldPoint / connected-path clearing. It does not weaken actual boarding: the later public board command still requires actual occupied canBoard and a complete current path; native command validation/execution is unchanged. It adds no owner, fallback compatibility system, per-think simulation or changed repair priority.

## Real native result and necessary counter

Old-loading counter, same62400 input→63600: no monitored command, no parent transition. Worker stays on1935 following its own ship with queuedboard1139. Cutter remains119.49949641240516HP;1935 remains425.4823180591221HP; both service-reserved. The blockage does not clear naturally over this window.

V2 actual public commands:62400 and62415 only two identical witch moves to(7006.571151661239,6430.476605322405), on her real cutter.62430 workerboard1139;62444 actual deck parent changes to1139;62460 repairShip1139.62505 board1935;62507 actual parent returns1935;62535 repairShip1935. First saved native repair-complete predicates: cutter at62505, warship1935 at62580. Both hulls are observed unreserved at saved frames beginning62460 and later through62880; this is an intermittent saved-frame observation, not one asserted continuous interval.62895 worker takes the next existing repair assignment to1064, so1935 is again reserved at63600. Cutter is free and has actual move orders; both HP are full160/464. The original two-hull reservation has recovered, but there is no claim that all naval service occupancy ends.

Worker70HP and witch133HP survive, with no monitored hit or parent loss. Witch remains on her actual receiving cutter, only changes to the queried local point(15.44,-2.36), and receives no further repeated yield command after62415. There are no new whole-match unit/building losses in either1200tick window; pre-existing p0loss4/neutralLoss6 remain. This does not repair the prior failed attack or count as new enemy-island deployment. Native crossing/counter/final images were personally inspected.

## Validation limits

Positive evidence covers this real physical maintenance blockage and a source-matched necessary counter. Full earlier-history interaction with joint landing/loading escort remains pending parent review; no additional ordinary0 or matrix was launched. V2 CPU/elapsed20.05s/15.93s and counter26.39s/27.61s are observational process timings under concurrent workload, not a stable performance benchmark; no fullsim is added to runtime. Inputs are the verified periodic62400 frame; the three prior death-event restore exceptions are described in the earlier sealed loading package and are not used as current starts. The transient exec-server disconnect recovered on harmless pwd retry and is not a permission blocker.
