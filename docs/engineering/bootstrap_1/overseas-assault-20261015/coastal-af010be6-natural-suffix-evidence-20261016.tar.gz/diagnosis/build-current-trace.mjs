import{readFileSync}from'node:fs';import{build}from'/workspace/sketch-rts/node_modules/esbuild/lib/main.js';
const D='/workspace/.playtest/coastal-objectives-ade-20261016',B=D+'/downstream-blockage-readonly';
function edit(raw,from,to){if(raw.split(from).length!==2)throw Error('instrument cardinality '+from);return raw.replace(from,to);}
await build({entryPoints:[B+'/trace-current-fullp0.ts'],outfile:B+'/trace-current-fullp0.bundle.mjs',bundle:true,platform:'node',format:'esm',packages:'external',plugins:[{name:'external-current-branches',setup(b){b.onLoad({filter:/\/ai\/policy\/(naval|coastal-bombardment|coastal-voyage|fleet-engagement)\.ts$/},args=>{let raw=readFileSync(args.path,'utf8');const name=args.path.split('/').at(-1);const note=`const __note=(r:any)=>(globalThis as any).__currentBranches.push(JSON.parse(JSON.stringify(r)));\n`;
if(name==='naval.ts'){
raw=edit(raw,'    const commands: GameCommand[] = [...clearTransferLanes(snapshot,owner),...services.commands];',"    __note({branch:'naval-initial',tick:snapshot.tick,outfit,services:{reserved:[...services.reserved],commands:services.commands},ferries:navalMemory(options).ferries}); const commands: GameCommand[] = [...clearTransferLanes(snapshot,owner),...services.commands];");
raw=edit(raw,'    const immediateCoasts=new Map(available.map(ship=>[ship.id,outmatchingCoast(snapshot,owner,ship,ship,options)]));',"    __note({branch:'naval-available',fighters:fighters.map(s=>s.id),available:available.map(s=>s.id),escorts:[...escorts].map(([id,s])=>[id,s.id]),commands}); const immediateCoasts=new Map(available.map(ship=>[ship.id,outmatchingCoast(snapshot,owner,ship,ship,options)]));");
raw=edit(raw,'    let guards:Unit[]|undefined;',"    __note({branch:'naval-priority',priority:[...priorityEngagement],immediate:[...immediateCoasts].map(([id,foes])=>[id,foes.map(f=>f.id)])}); let guards:Unit[]|undefined;");
raw=edit(raw,'        bombardments.set(ship.id,chosen);',"        __note({branch:'bombardment-selected',shipId:ship.id,chosen}); bombardments.set(ship.id,chosen);");
raw=edit(raw,'    for(const ship of available){',"    __note({branch:'naval-stations',stations:[...stations],fleetGoal,muster:navalMemory(options).muster}); for(const ship of available){");
raw=edit(raw,'        const boat = escorts.get(ship.id);',"        __note({branch:'naval-local',shipId:ship.id,bombardmentPlan,bombardmentIntent,local:local.map(t=>t.id),targets:targets.map(t=>t.id),localShots:[...localShots],order:ship.order}); const boat = escorts.get(ship.id);");
raw=edit(raw,'        if (destinationCoast.length) {',"        __note({branch:'naval-final-choice',shipId:ship.id,gathering,station,attackers:attackers.map(t=>t.id),threats:threats.map(t=>t.id),candidates:candidates.map(t=>t.id),bombardment,target,attackStation,destination,immediateCoast:immediateCoast.map(t=>t.id),destinationCoast:destinationCoast.map(t=>t.id),beforeCommands:commands}); if (destinationCoast.length) {");
raw=edit(raw,"                if(unsafe)commands.push({type:'stop',unitIds:[ship.id]});","                __note({branch:'naval-publish-voyage',shipId:ship.id,unsafe,waypoint,installedRoute:ship.sailing?.route}); if(unsafe)commands.push({type:'stop',unitIds:[ship.id]});");
raw=note+raw;
}else if(name==='coastal-bombardment.ts'){
raw=edit(raw,'  if(distance(ship,plan)<1e-5 || continuingWaypoint(snapshot,ship,plan,options))return plan;',"  if(distance(ship,plan)<1e-5 || continuingWaypoint(snapshot,ship,plan,options)){__note({branch:'coastal-reachable-retain',shipId:ship.id,plan});return plan;}");
raw=edit(raw,'  const voyage=planCoastalVoyage(snapshot,ship,plan,options);',"  const voyage=planCoastalVoyage(snapshot,ship,plan,options); __note({branch:'coastal-reachable-query',shipId:ship.id,plan,voyage});");
raw=note+raw;
}else if(name==='coastal-voyage.ts'){
raw=edit(raw,'    const route = planVoyageRoute(snapshot.map, hull, destination, traffic, budget);',"    const route = planVoyageRoute(snapshot.map, hull, destination, traffic, budget); __note({branch:'voyage-native-return',shipId:ship.id,from,destination,speed,budget,route});");
raw=edit(raw,'  if (!fullRoute(detour, goal)) return prefix();',"  __note({branch:'voyage-detour-return',shipId:ship.id,goal,budget,detour}); if (!fullRoute(detour, goal)) return prefix();");
raw=note+raw;
}else if(name==='fleet-engagement.ts'){
raw=edit(raw,'  if (!best) { delete orders[ship.id]; return; }',"  if (!best) { __note({branch:'fleet-no-target',shipId:ship.id,candidates:candidates.map(c=>c.id),old:orders[ship.id]}); delete orders[ship.id]; return; }");raw=note+raw;
}return{contents:raw,loader:'ts'};});}}]});
