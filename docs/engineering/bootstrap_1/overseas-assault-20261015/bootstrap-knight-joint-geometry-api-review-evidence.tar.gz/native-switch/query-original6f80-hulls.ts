import{readFileSync,writeFileSync,readdirSync}from'node:fs';import{pathToFileURL}from'node:url';
const root='/tmp/bootstrap-knight-current-shore-v2-native-switch-20261015',prefix='/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary';
const source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const mod=(p:string)=>import(pathToFileURL(source+'/src/'+p+'.ts').href);
const {bootstrapScripts}=await mod('ai/bootstrap_1/policy');
const {planAiOwnerCommandEntries,createAiMemoryProvider}=await mod('ai/planner-context');
const {readyAssaultConvoy,reviseAssaultBeaches,assaultBeachBodies,assaultBeachExposure}=await mod('ai/bootstrap_1/assault-beach');
const {shipProfile,localToWorld,hullContact,hullGap}=await mod('shared/ship-geometry');
const {shipBodyClearAtPose,shipBodyClearanceAtHeading}=await mod('shared/ship-collisions');
const {hullFits,nearestShipPose}=await mod('shared/ship-navigation');
const {setBuildingBodies,walkingDistance}=await mod('shared/terrain');
const near=['unit-p0-carrier-4595','unit-p0-transport-1046'],all=[...near,'unit-p0-carrier-4699'];
function hulls(s:any,o:any){
 const ferries=o.memory.naval?.ferries??{};
 const originals=all.map(id=>s.units.find((u:any)=>u.id===id)).filter(Boolean);
 function scene(label:string,ships:any[]){const arr=s.units.map((u:any)=>ships.find(b=>b.id===u.id)??u);const bodies=[...arr,...s.buildings,...(s.obstacles??[])];
  const poses=ships.map(b=>({id:b.id,kind:b.kind,phase:ferries[b.id]?.phase,pose:{x:b.x,y:b.y,heading:b.sailing.heading},goal:ferries[b.id]?.to,approach:ferries[b.id]?.approach,terrainHullFits:hullFits(s.map,b,{x:b.x,y:b.y,heading:b.sailing.heading}),bodyClear:shipBodyClearAtPose(s.map,b,{x:b.x,y:b.y,heading:b.sailing.heading},bodies),bodyClearAtHeading:shipBodyClearanceAtHeading(s.map,b,b.sailing.heading,bodies)(b),worldHull:shipProfile(b).hull.map((p:any)=>localToWorld(b,p))}));
  const pairs=[];for(let i=0;i<ships.length;i++)for(let j=i+1;j<ships.length;j++){const a=ships[i],b=ships[j];pairs.push({ids:[a.id,b.id],direct:Math.hypot(a.x-b.x,a.y-b.y),seaRoad:walkingDistance(s.map,a,b,'sea'),contact:hullContact(a,b)??null,hullGap:hullGap(a,b),aClearOfB:shipBodyClearanceAtHeading(s.map,a,a.sailing.heading,[a,b])(a),bClearOfA:shipBodyClearanceAtHeading(s.map,b,b.sailing.heading,[a,b])(b)});}
  return{label,poses,pairs};
 }
 const future=originals.map(b=>{const goal=ferries[b.id]?.to;const pose=goal&&nearestShipPose(s.map,b,goal);return pose?{...b,x:pose.x,y:pose.y,sailing:{...b.sailing,heading:pose.heading,speed:0,velocityX:0,velocityY:0}}:undefined}).filter(Boolean);
 const routeEnd=originals.filter(b=>near.includes(b.id)&&b.sailing?.route?.end).map(b=>{const p=b.sailing.route.end;return{...b,x:p.x,y:p.y,sailing:{...b.sailing,heading:p.heading??b.sailing.heading,speed:0,velocityX:0,velocityY:0}}});
 return{nativeRoutes:originals.map(b=>({id:b.id,routeGoal:b.sailing?.route&&{x:b.sailing.route.goalX,y:b.sailing.route.goalY},partial:b.sailing?.route?.partial,end:b.sailing?.route?.end,first:b.sailing?.route?.points?.[0]})),nativeNearRouteEnds:scene('Actual saved native route endpoints at pre-p0; partial endpoints are finite prefixes, not proof of destination',routeEnd),current:scene('Actual current three hulls, including remote loading4699',originals),nearFuture:scene('Two underway hulls simultaneously at independently selected future poses; remote4699 stays actual',future.filter(b=>near.includes(b.id))),allFuture:scene('All three independently selected future poses, including remote loading4699; not a claim all belong nearby450',future)};
}
function metrics(s:any,o:any){const fs=o.memory.naval?.ferries??{},boat=s.units.find((u:any)=>u.id===near[0]),other=s.units.find((u:any)=>u.id===near[1]),target=s.buildings.find((b:any)=>b.id===fs[boat.id]?.targetId);return{missions:Object.fromEntries(all.map(id=>[id,structuredClone(fs[id])])),readyIds:'Notqueried: original6f80 has no v2 readyAssaultConvoy',direct:Math.hypot(boat.x-other.x,boat.y-other.y),seaRoad:walkingDistance(s.map,boat,other,'sea'),placements:near.map(id=>{const b=s.units.find((u:any)=>u.id===id),goal=fs[id].to;const p=assaultBeachExposure(s,'p0',o,b,goal,target),c=assaultBeachExposure(s,'p0',o,b,goal,target,true);return{id,planned:p?{pose:p.pose,passengers:p.landed.map((u:any)=>u.id),guardIds:p.guards.map((u:any)=>u.id)}:null,current:c?{pose:c.pose,passengers:c.landed.map((u:any)=>u.id),guardIds:c.guards.map((u:any)=>u.id)}:null}}),hulls:hulls(s,o)};}
const actual=JSON.parse(readFileSync(prefix+'-actual-naval-boundaries.json','utf8'));const result=[];
for(const r of actual.result){const f=JSON.parse(readFileSync(r.input,'utf8')),s=f.snapshot,o=structuredClone(r.boundary.before);setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);const before=metrics(s,o);reviseAssaultBeaches(s,'p0',o);result.push({tick:r.tick,beforeRevise:before,afterRevise:metrics(s,o)});}
writeFileSync(root+'/original6f80-hulls.json',JSON.stringify({classification:'Static hull geometry from original6f80 exactnative boundary contexts. No new replay and no candidate v2 outcome attribution.',source,result})+'\n');console.log(JSON.stringify(result.map(r=>({tick:r.tick,before:r.beforeRevise.hulls.nearFuture.pairs,after:r.afterRevise.hulls.nearFuture.pairs,nativeRouteEnds:r.beforeRevise.hulls.nativeNearRouteEnds.pairs})),null,2));
