import{readFileSync,writeFileSync,readdirSync}from'node:fs';import{pathToFileURL}from'node:url';
const root='/tmp/bootstrap-knight-current-shore-v2-native-switch-20261015',prefix='/tmp/bootstrap-knight-current-shore-v2-20261015/knight-current-shore-v2';
const source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const mod=(p:string)=>import(pathToFileURL(source+'/src/'+p+'.ts').href);
const {bootstrapScripts}=await mod('ai/bootstrap_1/policy');
const {planAiOwnerCommandEntries,createAiMemoryProvider}=await mod('ai/planner-context');
const {readyAssaultConvoy,reviseAssaultBeaches,assaultBeachBodies,assaultBeachExposure}=await mod('ai/bootstrap_1/assault-beach');
const {shipProfile,localToWorld,hullContact,hullGap}=await mod('shared/ship-geometry');
const {shipBodyClearAtPose,shipBodyClearanceAtHeading}=await mod('shared/ship-collisions');
const {hullFits,nearestShipPose}=await mod('shared/ship-navigation');
const {setBuildingBodies,walkingDistance}=await mod('shared/terrain');
const near=['unit-p0-carrier-4595','unit-p0-transport-1046'],all=[...near,'unit-p0-carrier-4699'];
function hulls(s:any,o:any){
 const ferries=o.memory.naval?.ferries??{};
 const originals=all.map(id=>s.units.find((u:any)=>u.id===id)).filter(Boolean);
 function scene(label:string,ships:any[]){const arr=s.units.map((u:any)=>ships.find(b=>b.id===u.id)??u);const bodies=[...arr,...s.buildings,...(s.obstacles??[])];
  const poses=ships.map(b=>({id:b.id,kind:b.kind,phase:ferries[b.id]?.phase,pose:{x:b.x,y:b.y,heading:b.sailing.heading},goal:ferries[b.id]?.to,approach:ferries[b.id]?.approach,terrainHullFits:hullFits(s.map,b,{x:b.x,y:b.y,heading:b.sailing.heading}),bodyClear:shipBodyClearAtPose(s.map,b,{x:b.x,y:b.y,heading:b.sailing.heading},bodies),bodyClearAtHeading:shipBodyClearanceAtHeading(s.map,b,b.sailing.heading,bodies)(b),worldHull:shipProfile(b).hull.map((p:any)=>localToWorld(b,p))}));
  const pairs=[];for(let i=0;i<ships.length;i++)for(let j=i+1;j<ships.length;j++){const a=ships[i],b=ships[j];pairs.push({ids:[a.id,b.id],direct:Math.hypot(a.x-b.x,a.y-b.y),seaRoad:walkingDistance(s.map,a,b,'sea'),contact:hullContact(a,b)??null,hullGap:hullGap(a,b),aClearOfB:shipBodyClearanceAtHeading(s.map,a,a.sailing.heading,[a,b])(a),bClearOfA:shipBodyClearanceAtHeading(s.map,b,b.sailing.heading,[a,b])(b)});}
  return{label,poses,pairs};
 }
 const future=originals.map(b=>{const goal=ferries[b.id]?.to;const pose=goal&&nearestShipPose(s.map,b,goal);return pose?{...b,x:pose.x,y:pose.y,sailing:{...b.sailing,heading:pose.heading,speed:0,velocityX:0,velocityY:0}}:undefined}).filter(Boolean);
 const routeEnd=originals.filter(b=>near.includes(b.id)&&b.sailing?.route?.end).map(b=>{const p=b.sailing.route.end;return{...b,x:p.x,y:p.y,sailing:{...b.sailing,heading:p.heading??b.sailing.heading,speed:0,velocityX:0,velocityY:0}}});
 return{nativeRoutes:originals.map(b=>({id:b.id,routeGoal:b.sailing?.route&&{x:b.sailing.route.goalX,y:b.sailing.route.goalY},partial:b.sailing?.route?.partial,end:b.sailing?.route?.end,first:b.sailing?.route?.points?.[0]})),nativeNearRouteEnds:scene('Actual saved native route endpoints at pre-p0; partial endpoints are finite prefixes, not proof of destination',routeEnd),current:scene('Actual current three hulls, including remote loading4699',originals),nearFuture:scene('Two underway hulls simultaneously at independently selected future poses; remote4699 stays actual',future.filter(b=>near.includes(b.id))),allFuture:scene('All three independently selected future poses, including remote loading4699; not a claim all belong nearby450',future)};
}
function metrics(s:any,o:any){const fs=o.memory.naval?.ferries??{},boat=s.units.find((u:any)=>u.id===near[0]),other=s.units.find((u:any)=>u.id===near[1]),target=s.buildings.find((b:any)=>b.id===fs[boat.id]?.targetId);return{missions:Object.fromEntries(all.map(id=>[id,structuredClone(fs[id])])),readyIds:readyAssaultConvoy(s,'p0',o,boat,target)?.map((u:any)=>u.id)??null,direct:Math.hypot(boat.x-other.x,boat.y-other.y),seaRoad:walkingDistance(s.map,boat,other,'sea'),placements:near.map(id=>{const b=s.units.find((u:any)=>u.id===id),goal=fs[id].to;const p=assaultBeachExposure(s,'p0',o,b,goal,target),c=assaultBeachExposure(s,'p0',o,b,goal,target,true);return{id,planned:p?{pose:p.pose,passengers:p.landed.map((u:any)=>u.id),guardIds:p.guards.map((u:any)=>u.id)}:null,current:c?{pose:c.pose,passengers:c.landed.map((u:any)=>u.id),guardIds:c.guards.map((u:any)=>u.id)}:null}}),hulls:hulls(s,o)};}
const files=readdirSync(root+'/switch-inputs').filter(n=>n.endsWith('.json')).sort();const result:any[]=[];
for(const name of files){const f=JSON.parse(readFileSync(root+'/switch-inputs/'+name,'utf8')),s=f.snapshot;setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);let boundary:any;
 const provider=createAiMemoryProvider(structuredClone(f.memories));const scripts=bootstrapScripts('v9_knight').map((script:any)=>script.id==='naval'?{...script,run:(snapshot:any,owner:any,options:any)=>{
  const before=JSON.parse(JSON.stringify(options));const rawCommands=script.run(snapshot,owner,options);boundary={before,after:JSON.parse(JSON.stringify(options)),rawCommands:structuredClone(rawCommands)};return rawCommands;
 }}:script);
 const publicEntries=planAiOwnerCommandEntries(s,{playerId:'p0',version:'v9_knight',scripts},{teams:s.teams,memoryProvider:provider});
 const staged=structuredClone(boundary.before),beforeRevise=metrics(s,staged);reviseAssaultBeaches(s,'p0',staged);const afterRevise=metrics(s,staged);
 result.push({tick:s.tick,input:root+'/switch-inputs/'+name,boundary,publicEntries,p0MemoryAfter:provider.get('p0'),beforeRevise,afterRevise});
}
const replay=JSON.parse(readFileSync(root+'/switch.json','utf8')),final=JSON.parse(readFileSync(root+'/switch-final.json','utf8'));
for(let i=0;i<result.length;i++){const r=result[i],next=i+1<result.length?JSON.parse(readFileSync(result[i+1].input,'utf8')).memories.p0:final.memories.p0;const native=replay.commands.filter((x:any)=>x.tick===r.tick);const tracking=(c:any)=>c.unitIds?.some((id:string)=>all.includes(id))||all.includes(c.transportId);const actual=r.publicEntries.filter((x:any)=>tracking(x.command));r.proof={p0AfterEqualNextNativePreInput:JSON.stringify(r.p0MemoryAfter)===JSON.stringify(next),trackedCommandsEqualActualNative:JSON.stringify(actual.map((x:any)=>({scriptId:x.scriptId,command:x.command})))===JSON.stringify(native.map((x:any)=>({scriptId:x.scriptId,command:x.command}))),nativeCommands:native,queryCommands:actual};}
const out={classification:'Exact same-source normalbothAI60tick replay endpoints proven; standalone fullnative scriptstack boundary queries return unchanged commands and compare against actualnative commands+p0mem. Hull pose scenarios are static geometry tests, not runtimeclone or fullsimlookahead.',source,from:55260,end:55320,reproduction:replay.reproduction,result};writeFileSync(root+'/actual-boundaries-and-hulls.json',JSON.stringify(out)+'\n');console.log(JSON.stringify(result.map(r=>({tick:r.tick,proof:r.proof,beforeGoal:r.beforeRevise.missions[near[0]].to,afterGoal:r.afterRevise.missions[near[0]].to,ready:r.beforeRevise.readyIds,road:r.beforeRevise.seaRoad,futureNear:r.beforeRevise.hulls.nearFuture.pairs,current:r.beforeRevise.hulls.current.pairs.filter((x:any)=>x.ids.every((id:string)=>near.includes(id)))})),null,2));
if(result.some(r=>Object.values(r.proof).some(v=>v===false)))throw Error('Native boundary equivalence differs; do not attribute until resolved');
