import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const prefix=process.argv[2],from=55260,end=55320,out='/tmp/bootstrap-knight-current-shore-v2-native-switch-20261015/switch';
const cap=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')),source=cap.sourceRoot;
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const hashes={...cap.runtimeHashes,...cap.supportingDataHashes};
function verifySource(){
 const changed=Object.entries(hashes).filter(([p,h])=>sha(readFileSync(source+'/'+p))!==h).map(([p])=>p);
 if(changed.length||execFileSync('git',['-C',source,'rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim()!==cap.baseCommit||execFileSync('git',['-C',source,'status','--porcelain','--untracked-files=normal'],{cwd:source,encoding:'utf8'}))throw Error('Fixed source mismatch');
 return {files:Object.keys(hashes).length,changed};
}
const sourceBefore=verifySource();
const {bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const {restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const {createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const {createBootstrapCommandPlanner}=await import(pathToFileURL(source+'/scripts/bootstrap_1-planner.ts').href);
const {runAiGameLoop}=await import(pathToFileURL(source+'/src/ai/game-runner.ts').href);
const report=JSON.parse(readFileSync(prefix+'.json','utf8')),setup=report.setup;
const row=report.rows.find((r:any)=>r.tick===from),expectedRow=report.rows.find((r:any)=>r.tick===end);
if(!row||!expectedRow)throw Error('Recorded complete endpoints required');
const frame=JSON.parse(readFileSync(prefix+'.json.frames/'+from+'.json','utf8'));
const expected=JSON.parse(readFileSync(prefix+'.json.frames/'+end+'.json','utf8'));
const match=bootstrapMatches(setup.seed,[setup.map],end,setup.unseen).find((m:any)=>m.subject===report.subject&&m.side===setup.side&&m.agents.p0.race===setup.agents.p0.race&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v5');
if(!match)throw Error('Exact match absent');
const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
for(const [owner,p]of Object.entries(row.players) as any[])memories.set(owner,structuredClone(p.policy));
const restore={world:JSON.stringify(snapshotGame(game))===JSON.stringify(frame.snapshot),nextId:game.nextId===frame.nextId,allMemories:Object.entries(row.players).every(([o,p]:any)=>JSON.stringify(memories.get(o))===JSON.stringify(p.policy))};
if(Object.values(restore).some(v=>!v))throw Error('Restore mismatch');
const planner=await createBootstrapCommandPlanner(memories),commands:any[]=[],states:any[]=[],events:any[]=[];
const tracked=new Set(['unit-p0-carrier-4595','unit-p0-transport-1046','unit-p0-carrier-4699']);
const initialCrew=game.units.filter((u:any)=>u.deck&&tracked.has(u.deck.shipId)).map((u:any)=>u.id);for(const id of initialCrew)tracked.add(id);
for(const f of Object.values(memories.get('p0')?.naval?.ferries??{}) as any[])for(const id of f.crewIds)tracked.add(id);
function state(){return {tick:game.tick,units:game.units.filter((u:any)=>tracked.has(u.id)).map((u:any)=>({id:u.id,kind:u.kind,owner:u.owner,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,deck:structuredClone(u.deck),order:structuredClone(u.order),sailing:structuredClone(u.sailing)})),ferries:structuredClone(memories.get('p0')?.naval?.ferries),stats:structuredClone(game.match.stats)};}
const keyTicks=new Set([55260,55275,55290,55305]),keyInputs:any[]=[];mkdirSync(out+'-inputs',{recursive:false});
const observingPlanner=(context:any)=>{if(context.owner==='p0'&&keyTicks.has(context.snapshot.tick)){const path=out+'-inputs/'+context.snapshot.tick+'.json';const value={snapshot:context.snapshot,nextId:game.nextId,memories:Object.fromEntries(Object.keys(row.players).map(o=>[o,memories.get(o)])),lifecycle:'Exact native pre-p0-planner input; normal both-AI replay, no command injection'};writeFileSync(path,JSON.stringify(value)+'\n');keyInputs.push({tick:context.snapshot.tick,path,SHA256:sha(readFileSync(path))});}return planner(context);};
let before=state();states.push(before);const seenEffects=new Set(game.effects.map((e:any)=>e.id));
runAiGameLoop({...match,game,commandPlanner:observingPlanner},{onCommand:({tick,owner,scriptId,command}:any)=>{
 if(owner==='p0'&&('unitIds'in command&&command.unitIds.some((id:string)=>tracked.has(id))||'transportId'in command&&tracked.has(command.transportId)))commands.push({tick,owner,scriptId,command:structuredClone(command)});
},onStep:()=>{
 const after=state();
 for(const e of game.effects)if(!seenEffects.has(e.id)){
  seenEffects.add(e.id);if(e.unitId&&tracked.has(e.unitId)&&e.type==='hit')events.push({tick:game.tick,type:'nativeHitEffect',effect:structuredClone(e)});
 }
 for(const old of before.units){const u=after.units.find((u:any)=>u.id===old.id);
  if(!u)events.push({tick:game.tick,type:'removed',previous:old,stats:after.stats});
  else if(u.hp<old.hp)events.push({tick:game.tick,type:'nativeHpReduced',id:u.id,hpBefore:old.hp,hpAfter:u.hp,xy:[u.x,u.y],deck:u.deck,order:u.order});
  if(u&&old.deck&&!u.deck)events.push({tick:game.tick,type:'disembarked',before:old,after:u});
 }
 if(game.tick%15===0)states.push(after);before=after;
}});
const final={snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(row.players).map(o=>[o,memories.get(o)]))};
const reproduction={world:JSON.stringify(final.snapshot)===JSON.stringify(expected.snapshot),nextId:final.nextId===expected.nextId,allMemories:Object.entries(expectedRow.players).every(([o,p]:any)=>JSON.stringify(final.memories[o])===JSON.stringify(p.policy))};
const result={classification:'Observer-only same-source both-AI replay of changed-code-v2 55260..55320. No commands inserted or filtered. Diagnostic replay is not a new ordinary0 or a continuation result.',baseCommit:cap.baseCommit,source,from,end,inputWorldSHA256:sha(readFileSync(prefix+'.json.frames/'+from+'.json')),observerSHA256:sha(readFileSync(new URL(import.meta.url))),restore,reproduction,sourceBefore,sourceAfter:verifySource(),keyInputs,commands,states,events};
writeFileSync(out+'.json',JSON.stringify(result)+'\n');writeFileSync(out+'-final.json',JSON.stringify(final)+'\n');
console.log(JSON.stringify({from,end,restore,reproduction,sourceBefore,keyInputs,commands:commands.length,states:states.length,events:events.length,firstDamage:events.find(e=>e.type==='nativeHpReduced'),firstDisembark:events.find(e=>e.type==='disembarked')}));
if(Object.values(reproduction).some(v=>!v))throw Error('Native endpoint differs: preserve diagnostic, no causal attribution until resolved');
