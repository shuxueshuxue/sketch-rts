import { describe, expect, it } from 'vitest';
import { createUnit } from './map';
import { createGame } from './sim';
import { nearestShipPose, type ShipPose, type ShipPoseSearchDomain } from './ship-navigation';
import type { GameMap } from './types';

function water(): GameMap {
  return { ...createGame('bareDuel').map, width: 1280, height: 1024,
    terrain: { cell: 32, cols: 40, rows: 32, cells: '~'.repeat(40 * 32) } };
}
const inside = (domain: ShipPoseSearchDomain, pose: ShipPose) =>
  Math.hypot(pose.x-domain.center.x, pose.y-domain.center.y) <= domain.radius;

describe('finite ship placement domain', () => {
  it.each(['transport', 'carrier'] as const)('keeps default %s placement and filtered-domain order', kind => {
    const map = water(), boat = createUnit('boat', 'player', kind, 800, 512);
    const goal = { x: 128, y: 96 }, domain = { center: { x: 656, y: 496 }, radius: 160 };
    expect(nearestShipPose(map, boat, { x: 640, y: 512 })).toEqual({ x: 640, y: 512, heading: 0 });
    const expectedCalls: ShipPose[] = [], actualCalls: ShipPose[] = [];
    const accepts = (pose: ShipPose) => pose.x >= 640 && pose.heading === Math.PI / 2;
    const expected = nearestShipPose(map, boat, goal, boat, pose => {
      if (!inside(domain, pose)) return false;
      expectedCalls.push(pose); return accepts(pose);
    });
    const actual = nearestShipPose(map, boat, goal, boat, pose => {
      actualCalls.push(pose); return accepts(pose);
    }, domain);
    expect(actual).toBeDefined();
    expect(actual).toEqual(expected);
    expect(actualCalls).toEqual(expectedCalls);
  });

  it('searches a zero-radius domain containing one cell center even when the goal is outside it', () => {
    const map = water(), boat = createUnit('boat', 'player', 'transport', 800, 512);
    const center = { x: 656, y: 496 };
    expect(nearestShipPose(map, boat, { x: 128, y: 96 }, boat, () => true, { center, radius: 0 }))
      .toEqual({ ...center, heading: 0 });
  });

  it('clips circular corners and returns undefined only for the finite domain without querying outside it', () => {
    const map = water(), boat = createUnit('boat', 'player', 'transport', 800, 512);
    const domain = { center: { x: 656, y: 496 }, radius: 64 }, calls: ShipPose[] = [];
    expect(nearestShipPose(map, boat, { x: 128, y: 96 }, boat, pose => {
      calls.push(pose); return false;
    }, domain)).toBeUndefined();
    expect(calls.length).toBeGreaterThan(0);
    expect(calls.every(pose => inside(domain, pose))).toBe(true);
    expect(calls.some(pose => Math.hypot(pose.x-domain.center.x, pose.y-domain.center.y) === domain.radius)).toBe(true);
    expect(new Set(calls.map(pose => `${pose.x}:${pose.y}`)).size).toBe(13);
    let outsideCalls = 0;
    expect(nearestShipPose(map, boat, { x: 128, y: 96 }, boat, () => { outsideCalls++; return true; },
      { center: { x: -500, y: -500 }, radius: 1 })).toBeUndefined();
    expect(outsideCalls).toBe(0);
  });

  it('keeps the authored radial ordering without terrain', () => {
    const { terrain: _terrain, ...map } = water(), boat = createUnit('boat', 'player', 'transport', 800, 512);
    const goal = { x: 320, y: 320 }, domain = { center: { x: 400, y: 320 }, radius: 48 };
    const calls: ShipPose[] = [], expectedCalls: ShipPose[] = [];
    const expected = nearestShipPose(map, boat, goal, boat, pose => {
      if (!inside(domain, pose)) return false;
      expectedCalls.push(pose); return true;
    });
    const actual = nearestShipPose(map, boat, goal, boat, pose => { calls.push(pose); return true; }, domain);
    expect(actual).toBeDefined(); expect(actual).toEqual(expected); expect(calls).toEqual(expectedCalls);
  });
});
