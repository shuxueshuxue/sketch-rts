本包分三类事实，不能拼为新ordinary0或候选胜局。
1. 固定89f已结束的55200换码聚焦续局，在55260→55320做唯一60tick同源正常双方AI重放，完整world/nextId/双方mem端点全等；4个pre-p0实际native边界的命令和memory也全等。55305真实由近2448,6576改选1936,5936（直442.6003/海492.8>450），并实际发两个公共move。没有证据表明该段间距增加由正在接触的船体collision造成：4个当前hull无contact。
2. 静态几何证实原6f80也有未来船体冲突。原55200默认两future中心2512,6576相同；原55500未来南岸2064/2032,7312相距32但SAT重叠147.831。55920/55935实际保存的两条full native route.end也相同冲突，均非partial。完整worldhullpoly/clearance在native-switch查询JSON。不是v2独有，不等于已证明动态avoidance的唯一因果。
3. 纯几何API独立提交4bc50dc2，基线6f80，仅给nearestShipPose增加第6参domain{center,radius}。默认边界和循环顺序不变；圆域包围格界裁掉不可能tile/heading；域内仍按原ring/score/heading/accept顺序，undefined仅指该有限域未找到。API不证明sea-road、到达、真实heading或可卸。5新tests+原16=21/21、tsc exit0；7真实native contexts×3船×to/approach=42默认结果和accept回调顺序全等，显式全图domain也全等。
最初nearest只验hull，返回后才验最终passenger-shadows的搜索是不完备的有界负例。初称3船可行方案在补最后fullbody后被拒，纠正完整保留。之后把完整落点/guard/fullbody放进accept：unbounded在原55200前三shore各约672k poses，实际80wall/69CPU秒后主动SIGTERM，exit143，并未穷尽53shore，不能说全岛无解。
加450这个现有同批登陆几何域后，同一原55200两actual-sailing船只读搜索真实exit0，第7shore找出完整plan：1046(2512,6704,7π/4)6crew；4595(2608,6512,π)11crew。最终全部同岛/原守军与中立风险均空、全shadow船体互清、hullGap37.108、future直214.663/海230.4。远loading4699保持真实原处，未预留/未计近岸战力。实际current力26.091>=原required20.726、current直281.264/海281.6。
但cold搜索wall98.319s/CPU79.731s，23231pose，仍不能进每15tick planner。保存该plan十次只读复核：55200 valid，warm约25–33CPUms；原同源另一实际55500状态正确拒绝guards（该状态属于原历史，不是执行此plan的候选history）。不能缓存永久safe结论。尚未将joint规划定源/跑任何native候选局，不能声称登陆成功或比赛改进。公共move不携heading；futureheading只供查询，原当前落点/停船/portrait门槛必须实际证实。
unrun-joint-prototype仅保存未提交/未测试/未执行的草稿diff，缺完整predicate，不可合入。API独立可review；是否合入和继续优化由root协调，不改main。
原6f80整局另包：自然胜135692，43永久死亡且敌12单位残留；其活动目录sparse操作事故限度已完整封档。旧容器未提交恢复缺口保留。
