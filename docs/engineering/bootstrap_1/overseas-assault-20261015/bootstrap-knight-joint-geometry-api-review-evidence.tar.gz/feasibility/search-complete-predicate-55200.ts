import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const source='/tmp/sketch-rts-knight-6f80a-ordinary-control',root='/tmp/bootstrap-knight-joint-berth-feasibility-20261015';
const mod=(p:string)=>import(pathToFileURL(source+'/src/'+p+'.ts').href);
const {assaultBeachExposure}=await mod('ai/bootstrap_1/assault-beach');const {assaultExpedition}=await mod('ai/policy/naval');
const {shipPassengers,localToWorld,shipProfile,hullContact,hullGap}=await mod('shared/ship-geometry');
const {shipBodyClearanceAtHeading}=await mod('shared/ship-collisions');const {nearestShipPose}=await mod('shared/ship-navigation');
const {sameGround,setBuildingBodies,shoreSpots,walkableGoal,walkingDistance}=await mod('shared/terrain');const {BUILDING_DEFS}=await mod('shared/catalog');
const data=JSON.parse(readFileSync('/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary-actual-naval-boundaries.json','utf8')).result.find((r:any)=>r.tick===55200);
const input=JSON.parse(readFileSync(data.input,'utf8')),s=input.snapshot,o=structuredClone(data.boundary.before);setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const ferries=o.memory.naval.ferries,target=s.buildings.find((b:any)=>b.id==='building-p1-shipyard-1016');
const boats=s.units.filter((u:any)=>['unit-p0-transport-1046','unit-p0-carrier-4595'].includes(u.id)&&ferries[u.id]?.purpose==='assault'&&ferries[u.id].phase==='sailing');
const totals={poseCalls:0,hull:0,passengers:0,guard:0,finalfullbody:0,cohort450:0,accepted:0};
function plan(point:any){let shadow=s;const result:any[]=[],futureShips:any[]=[];
 for(const original of boats){const boat=shadow.units.find((u:any)=>u.id===original.id),bodies=[...shadow.units,...shadow.buildings,...(shadow.obstacles??[])],byHeading=new Map();
  function query(pose:any){
   totals.poseCalls++;if(totals.poseCalls%1000===0)console.log(JSON.stringify({progress:true,...totals}));
   let clear=byHeading.get(pose.heading);if(!clear){clear=shipBodyClearanceAtHeading(s.map,boat,pose.heading,bodies);byHeading.set(pose.heading,clear);}if(!clear(pose)){totals.hull++;return;}
   if(futureShips.some(a=>Math.hypot(a.x-pose.x,a.y-pose.y)>450||(walkingDistance(s.map,a,pose,'sea')??Infinity)>450)){totals.cohort450++;return;}
   const goal={x:pose.x,y:pose.y},ship={...boat,...goal,sailing:{...boat.sailing,heading:pose.heading,speed:0,velocityX:0,velocityY:0}};
   const posed={...shadow,units:shadow.units.map((u:any)=>u.id===boat.id?ship:u.deck?.shipId===boat.id?{...u,...localToWorld(ship,u.deck)}:u)};
   const exposure=assaultBeachExposure(posed,'p0',o,ship,goal,target,true);
   if(!exposure){totals.passengers++;return;}if(exposure.guards.length){totals.guard++;return;}
   const landed=new Map(exposure.landed.map((u:any)=>[u.id,u]));const complete={...posed,units:posed.units.map((u:any)=>landed.get(u.id)??u)},allBodies=[...complete.units,...complete.buildings,...(complete.obstacles??[])];
   // Each candidate reserves BOTH future hulls and ALL native passenger land
   // bodies before accepts returns true. A rejected pose lets nearest continue.
   for(const previous of [...futureShips,ship]){const hull=complete.units.find((u:any)=>u.id===previous.id);if(!shipBodyClearanceAtHeading(s.map,hull,hull.sailing.heading,allBodies)(hull)){totals.finalfullbody++;return;}}
   totals.accepted++;return{goal,pose,ship,exposure,complete};
  }
  const pose=nearestShipPose(s.map,boat,point,boat,p=>!!query(p));if(!pose)return;
  const accepted=query(pose);if(!accepted)throw Error('Unchanged accepted pose differs');
  shadow=accepted.complete;futureShips.push(accepted.ship);result.push({id:boat.id,goal:accepted.goal,pose,landed:accepted.exposure.landed.map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,radius:u.radius})),guards:accepted.exposure.guards,road:walkingDistance(s.map,boat,pose,'sea')});
 }
 const a=futureShips[0],b=futureShips[1];return{result,pair:{direct:Math.hypot(a.x-b.x,a.y-b.y),seaRoad:walkingDistance(s.map,a,b,'sea'),hullGap:hullGap(a,b),contact:hullContact(a,b)??null}};
}
const tile=s.map.terrain.cell*Math.max(1,Math.ceil(Math.max(...boats.map((b:any)=>shipProfile(b).beam))/s.map.terrain.cell)),seen=new Set();
const candidates=shoreSpots(s.map,BUILDING_DEFS.shipyard.radius).filter((p:any)=>sameGround(s.map,p,target)).map((p:any)=>walkableGoal(s.map,p.x,p.y,'sea')).flatMap((point:any)=>{const key=`${Math.floor(point.x/tile)}:${Math.floor(point.y/tile)}`;if(seen.has(key)||boats.some((b:any)=>!sameGround(s.map,b,point,'sea')))return[];const roads=boats.map((b:any)=>walkingDistance(s.map,b,point,'sea'));if(roads.some((r:any)=>r===undefined))return[];seen.add(key);return[{point,road:Math.max(...roads)}];}).sort((a:any,b:any)=>a.road-b.road).slice(0,64);
const t=performance.now(),cpu=process.cpuUsage(),attempts=[];let found;
for(const c of candidates){const prior=totals.poseCalls;const test=plan(c.point);attempts.push({candidate:c,valid:!!test,poseCalls:totals.poseCalls-prior});console.log(JSON.stringify({shoreCompleted:true,...attempts.at(-1)}));if(test){found=test;break;}}
const usage=process.cpuUsage(cpu),out={classification:'One original55200 actual two-sailing-hull read-only fullpredicate search. Originalnormalguards/neutralrisk/passengers/real450pair andsea-road, remote loading4699 unreserved and never counted. Native nearestShipPose accepts includes fullhypothetical land/hull world BEFORE accepting each pose. No commands/simulation/source edit.',source,input:data.input,required:assaultExpedition(s,'p0',o,target).required,boats:boats.map((b:any)=>b.id),attempts,found:found??null,totals,wallMilliseconds:performance.now()-t,cpuMilliseconds:(usage.user+usage.system)/1000};writeFileSync(root+'/result-complete-predicate-55200.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({finished:true,...out},null,2));
