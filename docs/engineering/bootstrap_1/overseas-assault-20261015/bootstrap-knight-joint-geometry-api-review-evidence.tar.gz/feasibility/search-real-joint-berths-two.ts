import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const source='/tmp/sketch-rts-knight-6f80a-ordinary-control',root='/tmp/bootstrap-knight-joint-berth-feasibility-20261015';
const mod=(p:string)=>import(pathToFileURL(source+'/src/'+p+'.ts').href);
const {assaultBeachExposure}=await mod('ai/bootstrap_1/assault-beach');const {assaultExpedition}=await mod('ai/policy/naval');
const {shipPassengers,localToWorld,shipProfile,hullContact}=await mod('shared/ship-geometry');
const {shipBodyClearanceAtHeading}=await mod('shared/ship-collisions');const {nearestShipPose,headingDifference}=await mod('shared/ship-navigation');
const {sameGround,setBuildingBodies,shoreSpots,walkableGoal,walkingDistance}=await mod('shared/terrain');
const {BUILDING_DEFS}=await mod('shared/catalog');
const data=JSON.parse(readFileSync('/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary-actual-naval-boundaries.json','utf8')).result.find((r:any)=>r.tick===Number(process.argv[2]??55200));
const input=JSON.parse(readFileSync(data.input,'utf8')),s=input.snapshot,o=structuredClone(data.boundary.before);setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const ferries=o.memory.naval.ferries,target=s.buildings.find((b:any)=>b.id==='building-p1-shipyard-1016');
const boats=s.units.filter((u:any)=>['unit-p0-transport-1046','unit-p0-carrier-4595'].includes(u.id)&&ferries[u.id]?.purpose==='assault'&&ferries[u.id].phase==='sailing'&&shipPassengers(s.units,u).length);
function plan(goals:any[],adjust:boolean){let shadow=s;const result=[];
 for(let i=0;i<boats.length;i++){const old=boats[i],boat=shadow.units.find((u:any)=>u.id===old.id),goal=goals[i],bodies=[...shadow.units,...shadow.buildings,...(shadow.obstacles??[])];let calls=0;
  const byHeading=new Map();const accepts=(pose:any)=>{calls++;let clear=byHeading.get(pose.heading);if(!clear){clear=shipBodyClearanceAtHeading(s.map,boat,pose.heading,bodies);byHeading.set(pose.heading,clear);}return clear(pose);};
  const pose=adjust?nearestShipPose(s.map,boat,goal,boat,accepts):nearestShipPose(s.map,boat,goal);
  if(!pose||!accepts(pose))return{valid:false,reason:'hull',id:boat.id,calls};
  const point={x:pose.x,y:pose.y};if(walkingDistance(s.map,boat,point,'sea')===undefined)return{valid:false,reason:'road',id:boat.id};
  const ship={...boat,...point,sailing:{...boat.sailing,heading:pose.heading,speed:0,velocityX:0,velocityY:0}};
  const posed={...shadow,units:shadow.units.map((u:any)=>u.id===boat.id?ship:u.deck?.shipId===boat.id?{...u,...localToWorld(ship,u.deck)}:u)};
  const query=assaultBeachExposure(posed,'p0',o,ship,point,target,true);
  if(!query||query.guards.length)return{valid:false,reason:query?'guard':'passengers',id:boat.id,calls,guardIds:query?.guards.map((u:any)=>u.id),pose};
  const land=new Map(query.landed.map((u:any)=>[u.id,u]));shadow={...posed,units:posed.units.map((u:any)=>land.get(u.id)??u)};
  result.push({id:boat.id,goal:point,pose,landed:query.landed.map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y})),guards:query.guards,road:walkingDistance(s.map,boat,point,'sea'),calls});
 }
 const hulls=result.map(x=>shadow.units.find((u:any)=>u.id===x.id));for(const b of hulls){if(!shipBodyClearanceAtHeading(s.map,b,b.sailing.heading,[...shadow.units,...shadow.buildings,...(shadow.obstacles??[])])(b))return{valid:false,reason:'finalfullbody',id:b.id};}const contacts=[];for(let i=0;i<hulls.length;i++)for(let j=i+1;j<hulls.length;j++)contacts.push({ids:[hulls[i].id,hulls[j].id],contact:hullContact(hulls[i],hulls[j])??null});
 return{valid:true,result,contacts};
}
const tile=s.map.terrain.cell*Math.max(1,Math.ceil(Math.max(...boats.map((boat:any)=>shipProfile(boat).beam))/s.map.terrain.cell)),seen=new Set();
const candidates=shoreSpots(s.map,BUILDING_DEFS.shipyard.radius).filter((p:any)=>sameGround(s.map,p,target)).map((p:any)=>walkableGoal(s.map,p.x,p.y,'sea')).flatMap((point:any)=>{const key=`${Math.floor(point.x/tile)}:${Math.floor(point.y/tile)}`;if(seen.has(key)||boats.some((b:any)=>!sameGround(s.map,b,point,'sea')))return[];const roads=boats.map((b:any)=>walkingDistance(s.map,b,point,'sea'));if(roads.some((r:any)=>r===undefined))return[];seen.add(key);return[{point,road:Math.max(...roads)}];}).sort((a:any,b:any)=>a.road-b.road).slice(0,64);
const initial=plan(boats.map((b:any)=>ferries[b.id].to),false),attempts=[];const t=performance.now(),cpu=process.cpuUsage();let found;
for(const c of candidates){const test=plan(boats.map(()=>c.point),true);attempts.push({candidate:c,valid:test.valid,reason:test.reason,rejectId:test.id,guardIds:test.guardIds,calls:test.calls,pose:test.pose});if(test.valid){found=test;break;}}
const elapsed=performance.now()-t,usage=process.cpuUsage(cpu);const out={classification:'Read-only cheap geometry search from actual original6f80 pre-p0-55200 world and realnative navalcontext. Not a simulation or gameplay result. No source/world/memory edit. Sameoriginal64candidateordering, onlyactualsailing1046and4595; remote loading4699 remains actual and notreserved, originalneutralandopponentguardavoidance, realpassengerbody+sea-road.',input:data.input,source,required:assaultExpedition(s,'p0',o,target).required,boats:boats.map((b:any)=>b.id),initial,attempts,found:found??null,wallMilliseconds:elapsed,cpuMilliseconds:(usage.user+usage.system)/1000};writeFileSync(root+'/result-two-'+s.tick+'.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({boats:out.boats,attempts:attempts.length,found,wallMilliseconds:elapsed,cpuMilliseconds:out.cpuMilliseconds},null,2));
