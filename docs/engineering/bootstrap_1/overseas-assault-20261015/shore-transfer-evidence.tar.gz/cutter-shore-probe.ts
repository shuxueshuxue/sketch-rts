import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame,issuePlayerCommand} from '../../src/shared/sim';
import {passengerLandingSpot,boardingBerth} from '../../src/shared/naval';
import {clearTransferLanes} from '../../src/ai/policy/transfer-lanes';
const f=JSON.parse(readFileSync('.playtest/overseas-assault-20261015/summoner-pickup-assembly.json.frames/104400.json','utf8')),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);
const a=g.units.find(u=>u.id==='unit-p0-transport-1046')!,b=g.units.find(u=>u.id==='unit-p0-cutter-1130')!,p=g.units.find(u=>u.id==='unit-p0-summoner-1488')!;
const spot=passengerLandingSpot(g.map,a,p.id,g.units);console.log({spot,berth:spot&&boardingBerth(g.map,{...p,...spot,deck:undefined},b)});
if(spot){issuePlayerCommand(g,'p0',{type:'unloadPassenger',transportId:a.id,passengerId:p.id});issuePlayerCommand(g,'p0',{type:'board',unitIds:[p.id],transportId:b.id});}
if(process.argv.includes('--save-only')){writeFileSync('.playtest/overseas-assault-20261015/summoner-manual-shore.json.frames/104400.json',JSON.stringify({snapshot:snapshotGame(g),nextId:g.nextId}));process.exit(0);}
for(let i=0;i<1800&&p.deck?.shipId!==b.id;i++){if(i%15===0)for(const c of clearTransferLanes(snapshotGame(g),'p0'))issuePlayerCommand(g,'p0',c);stepGame(g);}
console.log(JSON.stringify({tick:g.tick,deck:p.deck,order:p.order}));
