import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { createRequire } from 'node:module';

// This is a separate external diagnostic, never the untouched native window.
// It may run once, only after fixed source and the native 223215 frame exist.
const D = '/workspace/.playtest/general-coastal-fleet-078026-20261016';
const O = D + '/cost-trace';
const P = '/workspace/.playtest/macro-choice-recovery-e566-20261016';
const start = 223200, end = 223215;
const cap = JSON.parse(readFileSync(D + '/fixed-source.json', 'utf8'));
const S = cap.sourceRoot;
const normalFramePath = D + '/native-223200-224400/frames/223215-before-p0.json.gz';
const req = createRequire('/workspace/sketch-rts/package.json');
const { build } = req('esbuild');
const ts = req('typescript');
const sha = value => createHash('sha256').update(value).digest('hex');
const n = value => JSON.parse(JSON.stringify(value));
const classification = 'External instrumented diagnostic only: exact fixed candidate and normal three-AI sequence from full 223200 world/nextId/all3mem through 223215. Entrance/exit wall+CPU timings include instrumentation overhead and are not untouched native timings. Exactly 15 ticks, not a full-window benchmark or a gameplay acceptance result.';
if (process.argv[2] !== '--run-authorized-first15') throw Error('Explicit first15 run signal required');
if (process.cwd() !== S || existsSync(O + '/actual-launch.json')) throw Error('Exact fixed cwd and a new one-shot diagnostic output required');
if (!existsSync(normalFramePath)) throw Error('Uninstrumented normal 223215 pre-p0 checkpoint required first');

function verify() {
  const changed = Object.entries(cap.hashes).filter(([p, h]) => sha(readFileSync(S + '/' + p)) !== h).map(([p]) => p);
  const top = execFileSync('git', ['-C', S, 'rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
  const head = execFileSync('git', ['-C', S, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', S, 'status', '--porcelain'], { encoding: 'utf8' });
  if (top !== S || changed.length || head !== cap.head || status) throw Error('Fixed production source changed');
  return { files: Object.keys(cap.hashes).length, changed, head, status, top };
}
const sourcePre = verify();
mkdirSync(O + '/derived', { recursive: true });
const instrumentation = [];
function instrumentFunctions(path, source, targets) {
  const tree = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const edits = [], found = new Set();
  for (const node of tree.statements) {
    if (!ts.isFunctionDeclaration(node) || !node.name || !node.body) continue;
    const name = node.name.text, config = targets[name];
    if (!config) continue;
    if (found.has(name)) throw Error('Duplicate instrumentation target ' + name);
    found.add(name);
    const enter = '\nconst __rendezvousCostHandle = globalThis.__bootstrapRendezvousCostTrace.enter(' + JSON.stringify(name) + ', ' + config + ');\ntry {\n';
    const exit = '\n} finally { globalThis.__bootstrapRendezvousCostTrace.leave(__rendezvousCostHandle); }\n';
    edits.push({ at: node.body.getStart(tree) + 1, text: enter }, { at: node.body.getEnd() - 1, text: exit });
  }
  if (found.size !== Object.keys(targets).length) throw Error('Instrumentation target set mismatch: ' + [...found]);
  let derived = source;
  for (const edit of edits.sort((a, b) => b.at - a.at)) derived = derived.slice(0, edit.at) + edit.text + derived.slice(edit.at);
  const derivedPath = O + '/derived/' + path.split('/').at(-1);
  writeFileSync(derivedPath, derived);
  instrumentation.push({ sourcePath: path, sourceSHA256: sha(source), derivedPath, derivedSHA256: sha(derived), functions: [...found], modification: 'AST-located original function bodies retained verbatim; only enter + try/finally + leave inserted. Original parameters/returns/algorithms/budgets remain unchanged.' });
  return derived;
}
const plugin = {
  name: 'external-first15-rendezvous-cost-only',
  setup(b) {
    b.onResolve({ filter: /^esbuild$/ }, () => ({ path: req.resolve('esbuild'), external: true }));
    b.onLoad({ filter: /\/(crew-rendezvous|ship-navigation)\.ts$/ }, args => {
      if (![S + '/src/shared/crew-rendezvous.ts', S + '/src/shared/ship-navigation.ts'].includes(args.path)) throw Error('Unexpected native instrumentation path');
      const source = readFileSync(args.path, 'utf8');
      const targets = args.path.endsWith('/crew-rendezvous.ts') ? {
        prepareCrewRendezvous: '({units:units.length})',
        rendezvous: '({source:source.id,target:target.id,crew:crew.id})',
        rendezvousCanStart: '({source:source.id,target:target.id,crew:crew.id,plan:{...plan}})',
      } : {
        planShipRoute: '({ship:ship.id,goal:{...goal},budget:Number.isFinite(budget)?budget:"Infinity",voyage,from:{x:ship.x,y:ship.y,heading:ship.sailing?.heading}})',
      };
      return { contents: instrumentFunctions(args.path, source, targets), loader: 'ts', resolveDir: S + '/src/shared' };
    });
    b.onLoad({ filter: /\/scripts\/bootstrap_1-planner\.ts$/ }, args => {
      if (args.path !== S + '/scripts/bootstrap_1-planner.ts') throw Error('Unexpected bootstrap planner path');
      const source = readFileSync(args.path, 'utf8');
      const originalURL = pathToFileURL(args.path).href;
      const locations = source.match(/import\.meta\.url/g) ?? [];
      if (locations.length !== 2) throw Error('Unexpected bootstrap source-location references');
      const derived = source.replaceAll('import.meta.url', JSON.stringify(originalURL));
      const derivedPath = O + '/derived/bootstrap_1-planner.ts';
      writeFileSync(derivedPath, derived);
      instrumentation.push({ sourcePath: args.path, sourceSHA256: sha(source), derivedPath, derivedSHA256: sha(derived), modification: 'Only import.meta.url rebased to original module URL, preserving native frozen manifest and git-archive source locations after bundling. No planner logic change.' });
      return { contents: derived, loader: 'ts', resolveDir: S + '/scripts' };
    });
  },
};
const bundlePath = O + '/instrumented-first15-runtime.mjs';
await build({ stdin: { contents: "export{createGame,restoreSnapshotIntoGame,snapshotGame}from'./src/shared/sim';export{createAiMemoryProvider}from'./src/ai/planner-context';export{createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest}from'./scripts/bootstrap_1-planner';export{runAiGameLoop}from'./src/ai/game-runner';", resolveDir: S, loader: 'ts' }, bundle: true, packages: 'external', platform: 'node', format: 'esm', outfile: bundlePath, plugins: [plugin] });
if (instrumentation.length !== 3) throw Error('Missing target module transformation');
const rows = [], stack = []; let tick = start, phase = 'setup', nextCallId = 0;
globalThis.__bootstrapRendezvousCostTrace = {
  enter(name, metadata) {
    const handle = { id: nextCallId++, parentId: stack.at(-1)?.id ?? null, name, tick, phase, metadata, depth: stack.length, rendezvousCallId: [...stack].reverse().find(v => v.name === 'rendezvous')?.id ?? null, candidateCallId: [...stack].reverse().find(v => v.name === 'rendezvousCanStart')?.id ?? null, wallStarted: performance.now(), cpuStarted: process.cpuUsage() };
    stack.push(handle); return handle;
  },
  leave(handle) {
    const wallMs = performance.now() - handle.wallStarted;
    const cpu = process.cpuUsage(handle.cpuStarted);
    if (stack.pop() !== handle) throw Error('Diagnostic stack corruption');
    const { wallStarted, cpuStarted, ...record } = handle;
    rows.push({ ...record, wallMs, cpuMs: (cpu.user + cpu.system) / 1000 });
  },
};
const R = await import(pathToFileURL(bundlePath).href);
const inputPath = D + '/input-223200.json.gz', raw = readFileSync(inputPath), saved = JSON.parse(gunzipSync(raw));
const normalRaw = readFileSync(normalFramePath), expected = JSON.parse(gunzipSync(normalRaw));
const g = R.createGame('bareDuel'), m = R.createAiMemoryProvider();
R.restoreSnapshotIntoGame(g, saved.snapshot, saved.nextId);
for (const [owner, memory] of Object.entries(saved.memories)) m.set(owner, n(memory));
const full = () => n({ snapshot: R.snapshotGame(g), nextId: g.nextId, memories: Object.fromEntries(Object.keys(saved.memories).map(owner => [owner, m.get(owner)])) });
const initial = full();
const restored = { world: isDeepStrictEqual(initial.snapshot, saved.snapshot), nextId: initial.nextId === saved.nextId, all3mem: isDeepStrictEqual(initial.memories, saved.memories) };
if (g.tick !== start || Object.values(restored).some(v => !v)) throw Error('Strict full input restore mismatch');
const frozenRoot = R.frozenPolicyRoot();
function frozenCheck() {
  const changed = Object.entries(R.frozenPolicyManifest.files).filter(([p, h]) => sha(readFileSync(frozenRoot + '/' + p)) !== h).map(([p]) => p);
  if (changed.length || R.frozenPolicyManifest.rulesVersion !== 2 || Object.keys(R.frozenPolicyManifest.files).length !== 184) throw Error('Frozen rules2 mismatch');
  return { files: 184, changed, revision: R.frozenPolicyManifest.revision, rulesVersion: 2 };
}
const frozenPre = frozenCheck();
const normalPlanner = await R.createBootstrapCommandPlanner(m);
if (!isDeepStrictEqual(full(), initial)) throw Error('Planner setup mutated full input');
const agents = JSON.parse(readFileSync(P + '/native-193200/actual-launch.json', 'utf8')).agents;
const commands = [], steps = [], startedAtUtc = new Date().toISOString();
let stepStart;
writeFileSync(O + '/actual-launch.json', JSON.stringify({ classification, startedAtUtc, pid: process.pid, cwd: process.cwd(), argv: process.argv, sourceRoot: S, head: cap.head, sourcePre, frozenPre, restored, inputPath, inputSHA256: sha(raw), normalFramePath, normalFrameSHA256: sha(normalRaw), scriptSHA256: sha(readFileSync(fileURLToPath(import.meta.url))), bundleSHA256: sha(readFileSync(bundlePath)), instrumentation, agents, start, end }, null, 2));
const result = R.runAiGameLoop({ name: 'external first15 instrumentation diagnostic', game: g, agents, maxTicks: end, thinkInterval: 15, commandPlanner(ctx) { tick = g.tick; phase = 'planner:' + ctx.owner; const entries = normalPlanner(ctx); phase = 'after-planner'; return entries; } }, {
  onCommand(e) { tick = g.tick; phase = 'after-command'; commands.push(n({ tick: e.tick, owner: e.owner, scriptId: e.scriptId, command: e.command })); },
  beforeStep() { tick = g.tick; phase = 'native-step'; stepStart = { wall: performance.now(), cpu: process.cpuUsage() }; },
  onStep() { const wallMs = performance.now() - stepStart.wall, cpu = process.cpuUsage(stepStart.cpu); steps.push({ tickBefore: tick, tickAfter: g.tick, wallMs, cpuMs: (cpu.user + cpu.system) / 1000 }); tick = g.tick; phase = 'after-step'; },
});
if (stack.length || g.tick !== end) throw Error('Unexpected instrumented endpoint or active span');
const final = full(), equal = { world: isDeepStrictEqual(final.snapshot, expected.snapshot), nextId: final.nextId === expected.nextId, all3mem: isDeepStrictEqual(final.memories, expected.memories) };
const sourcePost = verify(), frozenPost = frozenCheck();
const normalCommands = readFileSync(D + '/native-223200-224400/commands.jsonl', 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line)).filter(e => e.tick >= start && e.tick < end);
const commandsEqual = isDeepStrictEqual(commands, normalCommands);
const groups = Object.fromEntries(['prepareCrewRendezvous', 'rendezvous', 'rendezvousCanStart', 'planShipRoute', 'planShipRouteNestedInCanStart'].map(name => {
  const selected = rows.filter(row => name === 'planShipRouteNestedInCanStart' ? row.name === 'planShipRoute' && row.candidateCallId !== null : row.name === name);
  return [name, { calls: selected.length, wallMsInclusive: selected.reduce((sum, row) => sum + row.wallMs, 0), cpuMsInclusive: selected.reduce((sum, row) => sum + row.cpuMs, 0), maxWallMs: Math.max(0, ...selected.map(row => row.wallMs)), nativeStepCalls: selected.filter(row => row.phase === 'native-step').length }];
}));
writeFileSync(O + '/instrumented-final-223215.json.gz', gzipSync(JSON.stringify(final)));
writeFileSync(O + '/calls.jsonl', rows.sort((a, b) => a.id - b.id).map(row => JSON.stringify(row)).join('\n') + '\n');
writeFileSync(O + '/commands.jsonl', commands.map(row => JSON.stringify(row)).join('\n') + '\n');
writeFileSync(O + '/steps.json', JSON.stringify(steps, null, 2));
const prepareCalls = rows.filter(row => row.name === 'prepareCrewRendezvous');
const prepareReevaluation = { calls: prepareCalls.length, withRendezvousEnumeration: prepareCalls.filter(prepare => rows.some(row => row.name === 'rendezvous' && row.parentId === prepare.id)).length, withoutRendezvousEnumeration: prepareCalls.filter(prepare => !rows.some(row => row.name === 'rendezvous' && row.parentId === prepare.id)).length };
const countsByTick = Object.fromEntries([...new Set(rows.map(row => row.tick))].sort((a, b) => a - b).map(atTick => [atTick, { prepare: rows.filter(row => row.tick === atTick && row.name === 'prepareCrewRendezvous').length, enumeration: rows.filter(row => row.tick === atTick && row.name === 'rendezvous').length, candidates: rows.filter(row => row.tick === atTick && row.name === 'rendezvousCanStart').length, nestedRoute: rows.filter(row => row.tick === atTick && row.name === 'planShipRoute' && row.candidateCallId !== null).length }]));
const report = { classification, startedAtUtc, endedAtUtc: new Date().toISOString(), pid: process.pid, sourceRoot: S, head: cap.head, start, end: g.tick, winner: g.match.winner, naturalComplete: !!g.match.winner, sourcePre, sourcePost, frozenPre, frozenPost, restored, equalToUninstrumented223215BeforeP0: equal, commandStreamEqual: commandsEqual, fullFinalSHA256: sha(JSON.stringify(final)), normalFullPayloadSHA256: sha(JSON.stringify({ snapshot: expected.snapshot, nextId: expected.nextId, memories: expected.memories })), inputSHA256: sha(raw), normalFrameSHA256: sha(normalRaw), bundleSHA256: sha(readFileSync(bundlePath)), scriptSHA256: sha(readFileSync(fileURLToPath(import.meta.url))), runtimeElapsedMsIncludingDiagnosticHooks: result.elapsedMs, runtimeCpuMsIncludingDiagnosticHooks: result.cpuMs, groups, prepareReevaluation, countsByTick, limitations: ['Timings include the external clock/stack/metadata instrumentation and bundling effects; untouched native-window step timings are recorded separately by its own driver.', 'Inclusive nested timings overlap; do not add rendezvous, candidate, and nested-route totals as independent costs.', 'Exactly this actual 15-tick window; no claim about all blocked cases, a global per-tick bound, full 1200-tick costs, completed boarding, victory, or generalization.', 'The original algorithms and parameters are retained; bootstrap module location is explicitly rebased only so frozen source paths match native execution. Strict final world/nextId/all3mem and issued command-stream equality is required.'], instrumentation };
writeFileSync(O + '/report.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify({ complete: true, head: cap.head, start, end: g.tick, equal, commandsEqual, groups, sourcePost, frozenPost }));
if (Object.values(equal).some(v => !v) || !commandsEqual) throw Error('Instrumented diagnostic failed strict normal native closure');
