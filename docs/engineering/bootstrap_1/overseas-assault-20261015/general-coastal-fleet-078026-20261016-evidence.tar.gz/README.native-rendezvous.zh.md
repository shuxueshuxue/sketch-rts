# 原生接舷起步修复：固定 e47fd045

独立源码 `/workspace/sketch-rts-general-coastal-fleet-078026-control`，父版本078026，提交e47fd04573c8af5363571ea8409843c060ae60fb。生产差异仅三个shared文件；078026的两个宏观策略文件不是本修复内容，也未因此取得验收。保留规则2、184文件冻结正常v5/v7对手、三AI原始world/nextId/全部memory。1470文件源码胶囊逐payload验证。没有改root/main、旧固定源或任何敌方/资源/身体参数。

原223200存档两船静态接触终点合法，实际首departure在t=.2486099274撞伙伴；非起点穿透、非预算不足。候选保留原泊位枚举/epsilon优先级/服务所有权，仅在已证空partial且伙伴也不在approach时重评，并要求至少一船有真实非零安全起步pose。假订单只参与reservation；solid视图共享原units已注册建筑/障碍frame。仍用原1024局部预算，不新加时间回退、取消策略或owner。

真实三AI换码223200→224400，随后同码224400→225600：

- 223546：原已付160的cutter140825原生出生，旧基线同tick段仍阻产。
- 224379：首次物理touch；224380：相对速度满足decksCanTransfer。末30冷JSON逐tick观察与原全部world/id/3mem、命令、命中、事件严格闭合。
- 224400：现有naval让24230和31259公move清路，未删身体或手动发令。
- 224435：39390进入receiver31227，此时board尚未结束。
- 224445：既有naval公move50739触发cancelCrewRendezvous，39390变idle；距重选deckPoint0.1672698894px，不能称updateBoardOrder自身exact到点结单。另30tick冷JSON及完整流严格闭合。
- 224445/224460/225600：原始数组顺序下，39390当前位置deckPointFits(occupied=true)、radius+1整圆在receiver deck/hull均真；唯一整身支撑为31227，无gangway/cabin，HP95保留。旧source已离泊，故不只是中心跨线。

两个实际段合计2430命令、0命中、0永久死亡；金383.33→377.33、native goldSpent+6，31227从1.916386→19.916386是六次正常付费码头修理。其余原有船HP/parts未损；不能称舰队健康、收入恢复、打野/攻城或胜利。225600无自然胜负。新cutter是原付款兑现，没有新注资；宏观运输/资本/目标问题仍在。

`native-task-outcome.json`、`receiver-whole-body-support.json`、`existing-baseline-frame-comparison.json`给精确因果、健康和已有基线对照。两个真实drawWorld PNG来自224385和224400完整存档，无示意修改。

最终33项相关测试与tsc exit0；两项headland coast旧断言在干净078026也红，保留原日志且未放宽。初次手算wall不能实际挡路的红日志同样保留，最终以真实hull support构建壁障通过。`candidate-source.json`和早期patch属于冻结前诊断，不冒充最终固定版本；最终为fixed-source.json和candidate-production-final.patch。

唯一外部instrument223200→223215与普通段world/id/三mem/命令严格相等：15次prepare、1次重枚举、3候选、4直接route和3个原有递归fallback。398ms为含诊断开销的枚举时间，父子时间不能相加；只说明此15tick，没有全场/最坏成本证明。正常1200段native step cost原始1200行另存，未从中虚推helper调用。

`aftercontact-observer-stop-errata.json`明确：外部driver意图通过修改runInput.maxTicks在转船后停，但wrapper复制对象使意图失效；driver未热改，正常走完已授权225600。原始report的observationStop是请求意图，不是实际停止时刻。

本包不是新普通0、未见种子分数、自然胜局或bootstrap最终验收。原broken容器未提交修改恢复缺口仍在；另passenger候选34800中断续程也未在此恢复。完整比赛及三路线共同目标继续，失败078026宏观包成绩保持原归属。
