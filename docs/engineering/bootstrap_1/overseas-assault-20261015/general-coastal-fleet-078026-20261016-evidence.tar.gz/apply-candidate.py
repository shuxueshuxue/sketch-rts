from pathlib import Path
P=Path('/workspace/sketch-rts-general-coastal-fleet-078026-control')
n=P/'src/shared/sailing.ts';s=n.read_text();s=s.replace('headingDifference, hullFits, hullPassageClear, nearestShipPose, planShipRoute,', 'headingDifference, hullFits, hullPassageClear, nearestShipPose, planShipRoute, SHIP_LOCAL_ROUTE_BUDGET,');assert s.count('traffic.hasTraffic?1024:Infinity')==2;s=s.replace('traffic.hasTraffic?1024:Infinity','traffic.hasTraffic?SHIP_LOCAL_ROUTE_BUDGET:Infinity');n.write_text(s)
n=P/'src/shared/crew-rendezvous.ts';s=n.read_text().replace("import { shipContactGoal } from './ship-avoidance';", "import { reservationTraffic, shipContactGoal } from './ship-avoidance';").replace("import { shipBodyClearAtPose } from './ship-collisions';", "import { shipBodyClearAtPose, shipSolidTraffic } from './ship-collisions';").replace("import { headingDifference, hullFits, type ShipPose }", "import { headingDifference, hullFits, planShipRoute, SHIP_LOCAL_ROUTE_BUDGET, type ShipPose }")
needle='function rendezvous(map:GameMap'
helper='''/** A contact-preserving terminal pose is not a route out of this quay.
 * Use the same local planner/traffic as the precise native move. One hull may
 * wait while its partner leaves; a finite safe prefix is not arrival proof. */
function rendezvousCanStart(map:GameMap,units:readonly Unit[],source:Unit,target:Unit,crew:Unit,plan:CrewRendezvous) {
  const order=(x:number,y:number):UnitOrder=>({type:'move',x,y,heading:plan.heading,rendezvousFor:crew.id});
  const a={...source,order:order(plan.sourceX,plan.sourceY)},b={...target,order:order(plan.targetX,plan.targetY)};
  const pending=units.map(unit=>unit===source?a:unit===target?b:unit===crew?{...crew,order:{type:'board' as const,transportId:target.id,rendezvous:plan}}:unit);
  return (plan.reciprocal?[a,b]:[a]).some(ship=>{
    const goal=ship.order as Extract<UnitOrder,{type:'move'}>;
    if(Math.hypot(ship.x-goal.x,ship.y-goal.y)<1e-6 && Math.abs(headingDifference(ship.sailing!.heading,plan.heading))<1e-6)return false;
    const hull=reservationTraffic(ship,pending),solids=shipSolidTraffic(map,ship,pending);
    const traffic=Object.assign((from:ShipPose,to:ShipPose,padding?:number)=>hull(from,to,padding)&&solids(from,to),{hasTraffic:hull.hasTraffic||solids.hasTraffic});
    return planShipRoute(map,ship,goal,traffic,traffic.hasTraffic?SHIP_LOCAL_ROUTE_BUDGET:Infinity).points.length>0;
  });
}

/** Reassess a known empty native result only when neither hull is still
 * approaching. Missing/stale route state is not evidence of a blocked task. */
function rendezvousCannotAdvance(source:Unit,target:Unit,crew:Unit,plan:CrewRendezvous) {
  const state=(ship:Unit,x:number,y:number)=>{
    if(Math.hypot(ship.x-x,ship.y-y)<1e-6 && Math.abs(headingDifference(ship.sailing!.heading,plan.heading))<1e-6)return 'arrived';
    const route=ship.sailing?.route,order=ship.order;
    return order.type==='move' && order.rendezvousFor===crew.id && order.x===x && order.y===y && order.heading===plan.heading
      && route?.goalX===x && route.goalY===y && route.partial && !route.points.length
      && route.startX===ship.x && route.startY===ship.y && route.startHeading===ship.sailing!.heading ? 'blocked':'approaching';
  };
  const a=state(source,plan.sourceX,plan.sourceY),b=plan.reciprocal?state(target,plan.targetX,plan.targetY):'arrived';
  return a!=='approaching' && b!=='approaching' && (a==='blocked'||b==='blocked');
}

'''
assert s.count(needle)==1;s=s.replace(needle,helper+needle)
s=s.replace('let best:CrewRendezvous|undefined,bestScore=Infinity;', 'const candidates:{plan:CrewRendezvous;score:number}[]=[];')
old="if(score<bestScore-1e-6){bestScore=score;best={sourceId:source.id,sourceX:sourceAt.x,sourceY:sourceAt.y,heading,targetX:targetAt.x,targetY:targetAt.y,reciprocal};}"
new="candidates.push({score,plan:{sourceId:source.id,sourceX:sourceAt.x,sourceY:sourceAt.y,heading,targetX:targetAt.x,targetY:targetAt.y,reciprocal}});"
assert old in s;s=s.replace(old,new)
assert s.count('return best;')==1;s=s.replace('return best;', "return candidates.sort((a,b)=>a.score-b.score).find(candidate=>rendezvousCanStart(map,units,source,target,crew,candidate.plan))?.plan;")
old='|| plan.reciprocal && !participating(target))plan=rendezvous(map,units,source,target,crew);';new='|| plan.reciprocal && !participating(target) || rendezvousCannotAdvance(source,target,crew,plan))plan=rendezvous(map,units,source,target,crew);';assert old in s;s=s.replace(old,new);n.write_text(s)
