// src/shared/terrain.ts
var CELL_GROUND = {
  ".": { land: true, sea: false, pace: 1, drag: 1 },
  ",": { land: true, sea: true, pace: 0.75, drag: 1.6 },
  m: { land: true, sea: false, pace: 0.6, drag: 2 },
  "=": { land: true, sea: false, pace: 1, drag: 1 },
  T: { land: false, sea: false, pace: 0, drag: 1 },
  "#": { land: false, sea: false, pace: 0, drag: 1 },
  "~": { land: false, sea: true, pace: 0, drag: 1 }
};
var PASSABLE = {
  land: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].land)),
  sea: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].sea))
};
var UNREACHED = 1073741823;
var UNKNOWN = -2;
var STRAIGHT = 5;
var DIAGONAL = 7;
var SECTOR = 10;
var MAX_REGIONS = 64;
var GROUND_WEIGHT = 4;
var BUCKETS = 64;
function isWalkable(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
function footprintHalf(radius, cell) {
  return Math.ceil(2 * radius / cell) * cell / 2;
}
function footprintCells(cell, x, y, radius) {
  const half = footprintHalf(radius, cell);
  const first = (from) => Math.ceil(from / cell - 0.5);
  return { left: first(x - half), right: first(x + half) - 1, top: first(y - half), bottom: first(y + half) - 1 };
}
function walkableGoal(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return { x, y };
  const state = runtime(terrain, mover);
  const cx = Math.min(Math.max(x, 0), map.width);
  const cy = Math.min(Math.max(y, 0), map.height);
  const at2 = padAt(state, Math.min(cx, terrain.cols * terrain.cell - 1e-3), Math.min(cy, terrain.rows * terrain.cell - 1e-3));
  if (state.walk[at2] === 1) return { x: cx, y: cy };
  const nearest = nearestWalkable(state, at2);
  return nearest < 0 ? { x: cx, y: cy } : centerOf(state, nearest);
}
function redoTiles(state, tiles, dirty) {
  const sectors = [...dirty].sort((a, b) => a - b);
  const touched = /* @__PURE__ */ new Set();
  const borders = /* @__PURE__ */ new Set();
  for (const sector of sectors) {
    labelRegions(state, tiles, sector);
    const col = sector % tiles.columns;
    const row = Math.floor(sector / tiles.columns);
    touched.add(sector);
    for (const lower of [0, 1]) borders.add(sector * 2 + lower);
    if (col > 0) {
      borders.add((sector - 1) * 2);
      touched.add(sector - 1);
    }
    if (row > 0) {
      borders.add((sector - tiles.columns) * 2 + 1);
      touched.add(sector - tiles.columns);
    }
    if (col + 1 < tiles.columns) touched.add(sector + 1);
    if (row + 1 < tiles.rows) touched.add(sector + tiles.columns);
  }
  for (const border of [...borders].sort((a, b) => a - b)) {
    for (const key of tiles.borders.get(border) ?? []) {
      tiles.nodes.delete(key);
      tiles.nodes.delete(key ^ 1);
    }
    layWindows(state, tiles, border);
  }
  for (const sector of [...touched].sort((a, b) => a - b)) linkSector(state, tiles, sector);
  labelIslands(state, tiles);
  for (const target of [...tiles.goals.keys()]) {
    const sector = sectorOf(state, tiles, target);
    const near = sectors.some((dirty2) => Math.abs(dirty2 % tiles.columns - sector % tiles.columns) <= 2 && Math.abs(Math.floor(dirty2 / tiles.columns) - Math.floor(sector / tiles.columns)) <= 2);
    if (near) tiles.goals.delete(target);
  }
  tiles.exits.clear();
  tiles.nearest.clear();
}
function sectorBox(state, tiles, sector) {
  const col = sector % tiles.columns * SECTOR;
  const row = Math.floor(sector / tiles.columns) * SECTOR;
  return { left: col + 1, top: row + 1, width: Math.min(SECTOR, state.terrain.cols - col), height: Math.min(SECTOR, state.terrain.rows - row) };
}
function sectorOf(state, tiles, at2) {
  const col = at2 % state.width - 1;
  const row = Math.floor(at2 / state.width) - 1;
  return Math.floor(row / SECTOR) * tiles.columns + Math.floor(col / SECTOR);
}
function local(box, at2, width) {
  const col = at2 % width;
  const row = (at2 - col) / width;
  if (col < box.left || row < box.top || col >= box.left + box.width || row >= box.top + box.height) return -1;
  return (row - box.top) * box.width + (col - box.left);
}
function labelRegions(state, tiles, sector) {
  const { walk, offsets, width } = state;
  const box = sectorBox(state, tiles, sector);
  for (let row = box.top; row < box.top + box.height; row += 1) for (let col = box.left; col < box.left + box.width; col += 1) tiles.region[row * width + col] = -1;
  let count = 0;
  for (let row = box.top; row < box.top + box.height; row += 1) {
    for (let col = box.left; col < box.left + box.width; col += 1) {
      const seed = row * width + col;
      if (walk[seed] !== 1 || tiles.region[seed] !== -1) continue;
      const label = sector * MAX_REGIONS + Math.min(count, MAX_REGIONS - 1);
      count += 1;
      tiles.region[seed] = label;
      for (let index = 0, queue = [seed]; index < queue.length; index += 1) {
        const at2 = queue[index];
        for (let direction = 0; direction < 8; direction += 1) {
          const next = at2 + offsets[direction];
          if (walk[next] !== 1 || tiles.region[next] !== -1 || local(box, next, width) < 0 || !stepAllowed(state, at2, direction)) continue;
          tiles.region[next] = label;
          queue.push(next);
        }
      }
    }
  }
}
function labelIslands(state, tiles) {
  const { walk, offsets } = state;
  tiles.island.fill(-1);
  const queue = new Int32Array(walk.length);
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || tiles.island[seed] !== -1) continue;
    tiles.island[seed] = seed;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at2 = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at2 + offsets[direction];
        if (walk[next] !== 1 || tiles.island[next] !== -1 || !stepAllowed(state, at2, direction)) continue;
        tiles.island[next] = seed;
        queue[tail++] = next;
      }
    }
  }
}
function layWindows(state, tiles, border) {
  const sector = border >> 1;
  const lower = border & 1;
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [];
  tiles.borders.set(border, keys);
  if (lower ? row + 1 >= tiles.rows : col + 1 >= tiles.columns) return;
  const { walk, width } = state;
  const box = sectorBox(state, tiles, sector);
  const across = lower ? width : 1;
  const span = lower ? box.width : box.height;
  const first = lower ? (box.top + box.height - 1) * width + box.left : box.top * width + box.left + box.width - 1;
  const along = lower ? 1 : width;
  let run = [];
  const close = () => {
    if (run.length === 0) return;
    const key = run[0] * 4 + lower * 2;
    keys.push(key);
    const blank = () => ({ box, dist: new Int32Array(0), next: new Int32Array(0) });
    tiles.nodes.set(key, { key, sector, cells: run, across, field: blank(), edges: [] });
    const other = lower ? sector + tiles.columns : sector + 1;
    tiles.nodes.set(key + 1, { key: key + 1, sector: other, cells: run.map((cell) => cell + across), across: -across, field: blank(), edges: [] });
    run = [];
  };
  for (let step = 0; step < span; step += 1) {
    const at2 = first + step * along;
    if (walk[at2] === 1 && walk[at2 + across] === 1) run.push(at2);
    else close();
  }
  close();
}
function sectorNodes(tiles, sector) {
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [...tiles.borders.get(sector * 2) ?? [], ...tiles.borders.get(sector * 2 + 1) ?? []];
  if (col > 0) keys.push(...(tiles.borders.get((sector - 1) * 2) ?? []).map((key) => key + 1));
  if (row > 0) keys.push(...(tiles.borders.get((sector - tiles.columns) * 2 + 1) ?? []).map((key) => key + 1));
  return keys.sort((a, b) => a - b).map((key) => tiles.nodes.get(key));
}
function linkSector(state, tiles, sector) {
  const box = sectorBox(state, tiles, sector);
  const nodes = sectorNodes(tiles, sector);
  for (const node of nodes) node.field = growBox(state, box, node.cells);
  for (const from of nodes) {
    from.edges = [];
    for (const to of nodes) {
      if (to === from) continue;
      let cost = UNREACHED;
      for (const cell of from.cells) cost = Math.min(cost, to.field.dist[local(box, cell, state.width)]);
      if (cost < UNREACHED) from.edges.push({ to: to.key, cost });
    }
  }
}
var STEP_COLS = [1, 0, -1, 0, 1, -1, -1, 1];
var STEP_ROWS = [0, 1, 0, -1, 1, 1, -1, -1];
function growBox(state, box, seeds, costs) {
  const size = box.width * box.height;
  return growBoxInto(state, box, seeds, costs, { dist: new Int32Array(size), next: new Int32Array(size) });
}
function growBoxInto(state, box, seeds, costs, arrays) {
  const { walk, offsets, width, weight } = state;
  const columns = box.width;
  const rows = box.height;
  const origin = box.top * width + box.left;
  const { dist, next } = arrays;
  dist.fill(UNREACHED);
  next.fill(UNKNOWN);
  const buckets = state.boxBuckets;
  const order = seeds.map((_, index) => index);
  if (costs) order.sort((a, b) => costs[a] - costs[b] || a - b);
  const costOf = (index) => costs ? costs[order[index]] : 0;
  let seeded = 0;
  let pending = 0;
  for (let cost = order.length > 0 ? costOf(0) : 0; pending > 0 || seeded < order.length; cost += 1) {
    if (pending === 0) cost = costOf(seeded);
    for (; seeded < order.length && costOf(seeded) === cost; seeded += 1) {
      const index = local(box, seeds[order[seeded]], width);
      if (index < 0 || cost >= dist[index]) continue;
      dist[index] = cost;
      buckets[cost % BUCKETS].push(index);
      pending += 1;
    }
    const bucket = buckets[cost % BUCKETS];
    while (bucket.length > 0) {
      const index = bucket.pop();
      pending -= 1;
      if (dist[index] !== cost) continue;
      const col = index % columns;
      const row = (index - col) / columns;
      const at2 = origin + row * width + col;
      for (let direction = 0; direction < 8; direction += 1) {
        const stepCol = col + STEP_COLS[direction];
        const stepRow = row + STEP_ROWS[direction];
        if (stepCol < 0 || stepRow < 0 || stepCol >= columns || stepRow >= rows) continue;
        const step = at2 + offsets[direction];
        if (walk[step] !== 1) continue;
        const there = stepRow * columns + stepCol;
        const reached = cost + (direction < 4 ? STRAIGHT : DIAGONAL) * weight[step];
        if (reached >= dist[there] || !stepAllowed(state, at2, direction)) continue;
        dist[there] = reached;
        buckets[reached % BUCKETS].push(there);
        pending += 1;
      }
    }
  }
  return { box, dist, next };
}
function sameGround(map, a, b, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  const { labels } = wholesOf(state);
  const from = padAt(state, a.x, a.y);
  const to = padAt(state, b.x, b.y);
  return from >= 0 && to >= 0 && labels[from] !== 0 && labels[from] === labels[to];
}
function wholesOf(state) {
  if (state.wholes) return state.wholes;
  const { walk, offsets, terrain, width } = state;
  const labels = new Int32Array(walk.length);
  const queue = new Int32Array(walk.length);
  let count = 0;
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || labels[seed] !== 0) continue;
    count += 1;
    labels[seed] = count;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at2 = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at2 + offsets[direction];
        if (walk[next] !== 1 || labels[next] !== 0 || !stepAllowed(state, at2, direction)) continue;
        labels[next] = count;
        queue[tail++] = next;
      }
    }
  }
  const deep = new Int32Array(count + 1);
  for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
    if (terrain.cells[index] !== "~") continue;
    const col = index % terrain.cols;
    deep[labels[((index - col) / terrain.cols + 1) * width + col + 1]] += 1;
  }
  deep[0] = 0;
  state.wholes = { labels, count, deep };
  return state.wholes;
}
var overlays = /* @__PURE__ */ new WeakMap();
var nextGroundRevision = 1;
function setBuildingBodies(map, bodies) {
  const terrain = map.terrain;
  if (!terrain) return;
  if (bodies.length === 0) {
    overlays.delete(map);
    return;
  }
  const current = overlays.get(map);
  if (current?.terrain === terrain && current.bodies.length === bodies.length && bodies.every((body, index) => body.x === current.bodies[index].x && body.y === current.bodies[index].y && body.radius === current.bodies[index].radius)) return;
  const ground = runtime(terrain, "land");
  let overlay = current;
  if (!overlay || overlay.terrain !== terrain || overlay.shared) {
    const fresh = createRuntime(terrain, "land");
    overlay = { terrain, state: fresh, previous: new Uint8Array(fresh.walk.length), revision: nextGroundRevision++, bodies: [], shared: false };
    overlays.set(map, overlay);
  }
  overlay.bodies = bodies.map(({ x, y, radius }) => ({ x, y, radius }));
  const state = overlay.state;
  overlay.previous.set(state.walk);
  state.walk.set(ground.walk);
  const size = terrain.cell;
  for (const body of bodies) {
    const { left, right, top, bottom } = footprintCells(size, body.x, body.y, body.radius);
    for (let row = Math.max(0, top); row <= Math.min(terrain.rows - 1, bottom); row += 1) {
      for (let col = Math.max(0, left); col <= Math.min(terrain.cols - 1, right); col += 1) state.walk[pad(state, col, row)] = 0;
    }
  }
  const dirty = /* @__PURE__ */ new Set();
  for (let at2 = 0; at2 < state.walk.length; at2 += 1) {
    if (state.walk[at2] === overlay.previous[at2]) continue;
    const col = at2 % state.width - 1;
    const row = Math.floor(at2 / state.width) - 1;
    dirty.add(Math.floor(row / SECTOR) * Math.ceil(terrain.cols / SECTOR) + Math.floor(col / SECTOR));
  }
  if (dirty.size === 0) return;
  overlay.revision = nextGroundRevision++;
  if (state.clearance) {
    state.clearance.fill(0);
    fillClearance(state);
  }
  state.nearest.clear();
  if (state.tiles) redoTiles(state, state.tiles, dirty);
}
var runtimes = /* @__PURE__ */ new WeakMap();
var lastTerrain;
var lastRuntimes = {};
function runtime(terrain, mover) {
  if (terrain !== lastTerrain) {
    lastTerrain = terrain;
    lastRuntimes = runtimes.get(terrain) ?? {};
    runtimes.set(terrain, lastRuntimes);
  }
  return mover === "land" ? lastRuntimes.land ??= createRuntime(terrain, "land") : lastRuntimes.sea ??= createRuntime(terrain, "sea");
}
function createRuntime(terrain, mover) {
  const width = terrain.cols + 2;
  const count = width * (terrain.rows + 2);
  const walk = new Uint8Array(count);
  const weight = new Uint8Array(count);
  const passable = PASSABLE[mover];
  for (let row = 0; row < terrain.rows; row += 1) {
    for (let col = 0; col < terrain.cols; col += 1) {
      const char = terrain.cells[row * terrain.cols + col];
      if (!passable.has(char)) continue;
      const at2 = (row + 1) * width + col + 1;
      walk[at2] = 1;
      weight[at2] = mover === "sea" ? GROUND_WEIGHT : Math.round(GROUND_WEIGHT / (CELL_GROUND[char]?.pace ?? 1));
    }
  }
  const offsets = Int32Array.from([1, width, -1, -width, width + 1, width - 1, -width - 1, -width + 1]);
  const state = {
    terrain,
    width,
    walk,
    weight,
    fields: /* @__PURE__ */ new Map(),
    clock: 0,
    spare: [],
    nearest: /* @__PURE__ */ new Map(),
    tops: new Int32Array(8),
    boxBuckets: Array.from({ length: BUCKETS }, () => []),
    offsets
  };
  return state;
}
function pad(state, col, row) {
  return (row + 1) * state.width + col + 1;
}
function padAt(state, x, y) {
  const { terrain } = state;
  const col = Math.floor(x / terrain.cell);
  const row = Math.floor(y / terrain.cell);
  if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return -1;
  return (row + 1) * state.width + col + 1;
}
function centerOf(state, at2) {
  const col = at2 % state.width - 1;
  const row = Math.floor(at2 / state.width) - 1;
  return { x: (col + 0.5) * state.terrain.cell, y: (row + 0.5) * state.terrain.cell };
}
function stepAllowed(state, at2, direction) {
  if (direction < 4) return true;
  const { walk, width } = state;
  const dx = direction === 4 || direction === 7 ? 1 : -1;
  const dy = direction === 4 || direction === 5 ? width : -width;
  return walk[at2 + dx] === 1 && walk[at2 + dy] === 1;
}
function fillClearance(state) {
  const { walk, offsets } = state;
  const clearance = state.clearance ??= new Uint16Array(walk.length);
  const queue = new Int32Array(walk.length);
  let tail = 0;
  for (let at2 = 0; at2 < walk.length; at2 += 1) {
    if (walk[at2] !== 1) continue;
    for (let direction = 0; direction < 8; direction += 1) {
      if (walk[at2 + offsets[direction]] === 1) continue;
      clearance[at2] = 1;
      queue[tail++] = at2;
      break;
    }
  }
  for (let head = 0; head < tail; head += 1) {
    const at2 = queue[head];
    const value = clearance[at2] + 1;
    for (let direction = 0; direction < 8; direction += 1) {
      const next = at2 + offsets[direction];
      if (walk[next] !== 1 || clearance[next] !== 0) continue;
      clearance[next] = value;
      queue[tail++] = next;
    }
  }
}
function nearestWalkable(state, at2) {
  if (at2 >= 0 && state.walk[at2] === 1) return at2;
  const known = state.nearest.get(at2);
  if (known !== void 0) return known;
  const { terrain, width } = state;
  const col = at2 < 0 ? 0 : at2 % width - 1;
  const row = at2 < 0 ? 0 : Math.floor(at2 / width) - 1;
  let best = -1;
  let bestDistance = Infinity;
  const limit = Math.max(terrain.cols, terrain.rows);
  for (let ring = 1; ring <= limit; ring += 1) {
    if (ring * ring > bestDistance) break;
    for (let r = row - ring; r <= row + ring; r += 1) {
      for (let c = col - ring; c <= col + ring; c += 1) {
        if (Math.max(Math.abs(c - col), Math.abs(r - row)) !== ring) continue;
        if (c < 0 || r < 0 || c >= terrain.cols || r >= terrain.rows) continue;
        const index = pad(state, c, r);
        if (state.walk[index] !== 1) continue;
        const gap = (c - col) * (c - col) + (r - row) * (r - row);
        if (gap < bestDistance || gap === bestDistance && index < best) {
          bestDistance = gap;
          best = index;
        }
      }
    }
  }
  if (state.nearest.size > 4096) state.nearest.clear();
  state.nearest.set(at2, best);
  return best;
}

// src/shared/det-math.ts
var S1 = -0.16666666666666632;
var S2 = 0.00833333333332249;
var S3 = -1984126982985795e-19;
var S4 = 27557313707070068e-22;
var S5 = -25050760253406863e-24;
var S6 = 158969099521155e-24;
var C1 = 0.0416666666666666;
var C2 = -0.001388888888887411;
var C3 = 2480158728947673e-20;
var C4 = -27557314351390663e-23;
var C5 = 2087572321298175e-24;
var C6 = -11359647557788195e-27;
var INV_PIO2 = 0.6366197723675814;
var PIO2_1 = 1.5707963267341256;
var PIO2_1T = 6077100506506192e-26;
var PIO2_2 = 6077100506303966e-26;
var PIO2_2T = 20222662487959506e-37;
var PI_4 = 0.7853981633974483;
var MAX_ARGUMENT = 823549.6;
function kernelSin(x, y, hasTail) {
  const z = x * x;
  const w = z * z;
  const r = S2 + z * (S3 + z * S4) + z * w * (S5 + z * S6);
  const v = z * x;
  if (!hasTail) return x + v * (S1 + z * r);
  return x - (z * (0.5 * y - v * r) - y - v * S1);
}
function kernelCos(x, y) {
  const z = x * x;
  const w = z * z;
  const r = z * (C1 + z * (C2 + z * C3)) + w * w * (C4 + z * (C5 + z * C6));
  const hz = 0.5 * z;
  const u = 1 - hz;
  return u + (1 - u - hz + (z * r - x * y));
}
function reduce(x) {
  if (!(Math.abs(x) <= MAX_ARGUMENT)) throw new Error(`det-math: angle ${x} outside the supported range`);
  const n = Math.round(x * INV_PIO2);
  const first = x - n * PIO2_1;
  let w = n * PIO2_1T;
  const r = first - n * PIO2_2;
  w = n * PIO2_2T - (first - r - n * PIO2_2);
  const head = r - w;
  return { n, head, tail: r - head - w };
}
function detSin(x) {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (Math.abs(x) <= PI_4) return x === 0 ? x : kernelSin(x, 0, false);
  const { n, head, tail } = reduce(x);
  switch (n & 3) {
    case 0:
      return kernelSin(head, tail, true);
    case 1:
      return kernelCos(head, tail);
    case 2:
      return -kernelSin(head, tail, true);
    default:
      return -kernelCos(head, tail);
  }
}
function detCos(x) {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (Math.abs(x) <= PI_4) return kernelCos(x, 0);
  const { n, head, tail } = reduce(x);
  switch (n & 3) {
    case 0:
      return kernelCos(head, tail);
    case 1:
      return -kernelSin(head, tail, true);
    case 2:
      return -kernelCos(head, tail);
    default:
      return kernelSin(head, tail, true);
  }
}

// src/shared/generated/ship-geometry.json
var ship_geometry_default = {
  sourceSha256: "22acecf80139ea9f084dbc3411a61d94128d400092ef1428e3a45ee86f5ea01e",
  camera: {
    tilt: 0.72,
    frameSize: 384,
    worldSize: 360,
    directions: 32,
    anchorY: 24
  },
  ships: {
    cutter: {
      length: 116,
      beam: 46,
      deckHeight: 18,
      hullMass: 7e3,
      loadCapacity: 450,
      acceleration: 72,
      turnRate: 0.628318531,
      obstacles: [
        {
          x: -35,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -39,
          y: 0,
          radius: 14,
          type: "cabin"
        }
      ],
      weaponMount: [
        31,
        0,
        11
      ],
      mastHeight: 78,
      weaponPivot: null,
      hull: [
        [
          -58,
          -12.88
        ],
        [
          -51.04,
          -18.86
        ],
        [
          -31.900000000000002,
          -23
        ],
        [
          0,
          -23
        ],
        [
          23.200000000000003,
          -20.7
        ],
        [
          42.339999999999996,
          -12.88
        ],
        [
          58,
          0
        ],
        [
          42.339999999999996,
          12.88
        ],
        [
          23.200000000000003,
          20.7
        ],
        [
          0,
          23
        ],
        [
          -31.900000000000002,
          23
        ],
        [
          -51.04,
          18.86
        ],
        [
          -58,
          12.88
        ]
      ],
      deck: [
        [
          -53,
          -10.080000000000002
        ],
        [
          -46.64,
          -14.76
        ],
        [
          -29.150000000000002,
          -18
        ],
        [
          0,
          -18
        ],
        [
          21.200000000000003,
          -16.2
        ],
        [
          38.69,
          -10.080000000000002
        ],
        [
          53,
          0
        ],
        [
          38.69,
          10.080000000000002
        ],
        [
          21.200000000000003,
          16.2
        ],
        [
          0,
          18
        ],
        [
          -29.150000000000002,
          18
        ],
        [
          -46.64,
          14.76
        ],
        [
          -53,
          10.080000000000002
        ]
      ]
    },
    transport: {
      length: 184,
      beam: 80,
      deckHeight: 26,
      hullMass: 14e3,
      loadCapacity: 1800,
      acceleration: 48,
      turnRate: 0.383972435,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 64,
      weaponPivot: null,
      hull: [
        [
          -92,
          -22.400000000000002
        ],
        [
          -80.96,
          -32.8
        ],
        [
          -50.6,
          -40
        ],
        [
          0,
          -40
        ],
        [
          36.800000000000004,
          -36
        ],
        [
          67.16,
          -22.400000000000002
        ],
        [
          92,
          0
        ],
        [
          67.16,
          22.400000000000002
        ],
        [
          36.800000000000004,
          36
        ],
        [
          0,
          40
        ],
        [
          -50.6,
          40
        ],
        [
          -80.96,
          32.8
        ],
        [
          -92,
          22.400000000000002
        ]
      ],
      deck: [
        [
          -87,
          -19.6
        ],
        [
          -76.56,
          -28.7
        ],
        [
          -47.85,
          -35
        ],
        [
          0,
          -35
        ],
        [
          34.800000000000004,
          -31.5
        ],
        [
          63.51,
          -19.6
        ],
        [
          87,
          0
        ],
        [
          63.51,
          19.6
        ],
        [
          34.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -47.85,
          35
        ],
        [
          -76.56,
          28.7
        ],
        [
          -87,
          19.6
        ]
      ]
    },
    warship: {
      length: 170,
      beam: 72,
      deckHeight: 28,
      hullMass: 23e3,
      loadCapacity: 850,
      acceleration: 44,
      turnRate: 0.314159265,
      obstacles: [
        {
          x: -45,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 34,
          y: 0,
          radius: 16,
          type: "gun"
        },
        {
          x: -58,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        60,
        0,
        35
      ],
      mastHeight: 102,
      weaponPivot: [
        34,
        0,
        28
      ],
      hull: [
        [
          -85,
          -20.160000000000004
        ],
        [
          -74.8,
          -29.52
        ],
        [
          -46.75000000000001,
          -36
        ],
        [
          0,
          -36
        ],
        [
          34,
          -32.4
        ],
        [
          62.05,
          -20.160000000000004
        ],
        [
          85,
          0
        ],
        [
          62.05,
          20.160000000000004
        ],
        [
          34,
          32.4
        ],
        [
          0,
          36
        ],
        [
          -46.75000000000001,
          36
        ],
        [
          -74.8,
          29.52
        ],
        [
          -85,
          20.160000000000004
        ]
      ],
      deck: [
        [
          -80,
          -17.360000000000003
        ],
        [
          -70.4,
          -25.419999999999998
        ],
        [
          -44,
          -31
        ],
        [
          0,
          -31
        ],
        [
          32,
          -27.900000000000002
        ],
        [
          58.4,
          -17.360000000000003
        ],
        [
          80,
          0
        ],
        [
          58.4,
          17.360000000000003
        ],
        [
          32,
          27.900000000000002
        ],
        [
          0,
          31
        ],
        [
          -44,
          31
        ],
        [
          -70.4,
          25.419999999999998
        ],
        [
          -80,
          17.360000000000003
        ]
      ]
    },
    bombardShip: {
      length: 184,
      beam: 70,
      deckHeight: 30,
      hullMass: 31e3,
      loadCapacity: 1300,
      acceleration: 30,
      turnRate: 0.226892803,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 30,
          y: 0,
          radius: 23,
          type: "mortar"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        38,
        0,
        54
      ],
      mastHeight: 58,
      weaponPivot: [
        30,
        0,
        30
      ],
      hull: [
        [
          -92,
          -19.6
        ],
        [
          -80.96,
          -28.7
        ],
        [
          -50.6,
          -35
        ],
        [
          0,
          -35
        ],
        [
          36.800000000000004,
          -31.5
        ],
        [
          67.16,
          -19.6
        ],
        [
          92,
          0
        ],
        [
          67.16,
          19.6
        ],
        [
          36.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -50.6,
          35
        ],
        [
          -80.96,
          28.7
        ],
        [
          -92,
          19.6
        ]
      ],
      deck: [
        [
          -87,
          -16.8
        ],
        [
          -76.56,
          -24.599999999999998
        ],
        [
          -47.85,
          -30
        ],
        [
          0,
          -30
        ],
        [
          34.800000000000004,
          -27
        ],
        [
          63.51,
          -16.8
        ],
        [
          87,
          0
        ],
        [
          63.51,
          16.8
        ],
        [
          34.800000000000004,
          27
        ],
        [
          0,
          30
        ],
        [
          -47.85,
          30
        ],
        [
          -76.56,
          24.599999999999998
        ],
        [
          -87,
          16.8
        ]
      ]
    },
    fireShip: {
      length: 158,
      beam: 60,
      deckHeight: 26,
      hullMass: 19e3,
      loadCapacity: 700,
      acceleration: 56,
      turnRate: 0.453785606,
      obstacles: [
        {
          x: -41,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 25,
          y: 0,
          radius: 18,
          type: "flame"
        },
        {
          x: -54,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        67,
        0,
        32
      ],
      mastHeight: 44,
      weaponPivot: [
        25,
        0,
        26
      ],
      hull: [
        [
          -79,
          -16.8
        ],
        [
          -69.52,
          -24.599999999999998
        ],
        [
          -43.45,
          -30
        ],
        [
          0,
          -30
        ],
        [
          31.6,
          -27
        ],
        [
          57.67,
          -16.8
        ],
        [
          79,
          0
        ],
        [
          57.67,
          16.8
        ],
        [
          31.6,
          27
        ],
        [
          0,
          30
        ],
        [
          -43.45,
          30
        ],
        [
          -69.52,
          24.599999999999998
        ],
        [
          -79,
          16.8
        ]
      ],
      deck: [
        [
          -74,
          -14.000000000000002
        ],
        [
          -65.12,
          -20.5
        ],
        [
          -40.7,
          -25
        ],
        [
          0,
          -25
        ],
        [
          29.6,
          -22.5
        ],
        [
          54.019999999999996,
          -14.000000000000002
        ],
        [
          74,
          0
        ],
        [
          54.019999999999996,
          14.000000000000002
        ],
        [
          29.6,
          22.5
        ],
        [
          0,
          25
        ],
        [
          -40.7,
          25
        ],
        [
          -65.12,
          20.5
        ],
        [
          -74,
          14.000000000000002
        ]
      ]
    },
    carrier: {
      length: 224,
      beam: 106,
      deckHeight: 32,
      hullMass: 55e3,
      loadCapacity: 5200,
      acceleration: 32,
      turnRate: 0.20943951,
      obstacles: [
        {
          x: -60,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: 26,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: -76,
          y: 0,
          radius: 26,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 128,
      weaponPivot: null,
      hull: [
        [
          -112,
          -29.680000000000003
        ],
        [
          -98.56,
          -43.46
        ],
        [
          -61.60000000000001,
          -53
        ],
        [
          0,
          -53
        ],
        [
          44.800000000000004,
          -47.7
        ],
        [
          81.75999999999999,
          -29.680000000000003
        ],
        [
          112,
          0
        ],
        [
          81.75999999999999,
          29.680000000000003
        ],
        [
          44.800000000000004,
          47.7
        ],
        [
          0,
          53
        ],
        [
          -61.60000000000001,
          53
        ],
        [
          -98.56,
          43.46
        ],
        [
          -112,
          29.680000000000003
        ]
      ],
      deck: [
        [
          -107,
          -26.880000000000003
        ],
        [
          -94.16,
          -39.36
        ],
        [
          -58.85,
          -48
        ],
        [
          0,
          -48
        ],
        [
          42.800000000000004,
          -43.2
        ],
        [
          78.11,
          -26.880000000000003
        ],
        [
          107,
          0
        ],
        [
          78.11,
          26.880000000000003
        ],
        [
          42.800000000000004,
          43.2
        ],
        [
          0,
          48
        ],
        [
          -58.85,
          48
        ],
        [
          -94.16,
          39.36
        ],
        [
          -107,
          26.880000000000003
        ]
      ]
    },
    shipOfTheLine: {
      length: 292,
      beam: 144,
      deckHeight: 38,
      hullMass: 72e3,
      loadCapacity: 3800,
      acceleration: 24,
      turnRate: 0.148352986,
      obstacles: [
        {
          x: -53,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -10,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: 76,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -126,
          y: 0,
          radius: 20,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 150,
      mastHeights: [
        118,
        150,
        136
      ],
      mastBeamScales: [
        0.79,
        1,
        0.88
      ],
      weaponPivot: null,
      hull: [
        [
          -146,
          -40.32000000000001
        ],
        [
          -128.48,
          -59.04
        ],
        [
          -80.30000000000001,
          -72
        ],
        [
          0,
          -72
        ],
        [
          58.400000000000006,
          -64.8
        ],
        [
          106.58,
          -40.32000000000001
        ],
        [
          146,
          0
        ],
        [
          106.58,
          40.32000000000001
        ],
        [
          58.400000000000006,
          64.8
        ],
        [
          0,
          72
        ],
        [
          -80.30000000000001,
          72
        ],
        [
          -128.48,
          59.04
        ],
        [
          -146,
          40.32000000000001
        ]
      ],
      deck: [
        [
          -141,
          -37.52
        ],
        [
          -124.08,
          -54.94
        ],
        [
          -77.55000000000001,
          -67
        ],
        [
          0,
          -67
        ],
        [
          56.400000000000006,
          -60.300000000000004
        ],
        [
          102.92999999999999,
          -37.52
        ],
        [
          141,
          0
        ],
        [
          102.92999999999999,
          37.52
        ],
        [
          56.400000000000006,
          60.300000000000004
        ],
        [
          0,
          67
        ],
        [
          -77.55000000000001,
          67
        ],
        [
          -124.08,
          54.94
        ],
        [
          -141,
          37.52
        ]
      ]
    }
  }
};

// src/shared/ship-geometry.ts
var shipGeometry = ship_geometry_default.ships;
var SHIP_CAMERA = ship_geometry_default.camera;
var SHIP_KINDS = Object.keys(shipGeometry);
var SHIP_SIZE_MULTIPLIER = 1.2;
var AUTHORED_DEFAULT_SHIP_SCALE = 1.1;
var DEFAULT_SHIP_SCALE = AUTHORED_DEFAULT_SHIP_SCALE * SHIP_SIZE_MULTIPLIER;
function isShipKind(kind) {
  return kind in shipGeometry;
}
function authoredShipScale(ship) {
  return ship.deckScale ?? (ship.cargoCapacity === void 0 ? AUTHORED_DEFAULT_SHIP_SCALE : Math.sqrt(ship.cargoCapacity / (ship.kind === "carrier" ? 24 : 8)));
}
function shipScale(ship) {
  return authoredShipScale(ship) * SHIP_SIZE_MULTIPLIER;
}
var profiles = /* @__PURE__ */ new WeakMap();
function shipProfile(ship) {
  if (!isShipKind(ship.kind)) return void 0;
  const scale = shipScale(ship), cached = profiles.get(ship);
  if (cached && cached.kind === ship.kind && cached.scale === scale && cached.fittings === ship.fittings) return cached.profile;
  const profile = computeShipProfile(ship, ship.kind, scale);
  profiles.set(ship, { kind: ship.kind, scale, fittings: ship.fittings, profile });
  return profile;
}
function computeShipProfile(ship, kind, scale) {
  const raw = shipGeometry[kind];
  return {
    ...raw,
    length: raw.length * scale,
    beam: raw.beam * scale,
    deckHeight: raw.deckHeight * scale,
    mastHeight: raw.mastHeight * scale,
    hullMass: raw.hullMass * scale ** 3,
    loadCapacity: raw.loadCapacity * scale ** 2,
    hull: raw.hull.map(([x, y]) => ({ x: x * scale, y: y * scale })),
    deck: raw.deck.map(([x, y]) => ({ x: x * scale, y: y * scale })),
    weaponMount: raw.weaponMount?.map((value) => value * scale) ?? null,
    weaponPivot: raw.weaponPivot?.map((value) => value * scale) ?? null,
    obstacles: [...raw.obstacles.filter((o) => !["gun", "mortar", "flame"].includes(o.type) || !ship.fittings), ...(ship.fittings ?? []).map((fitting) => ({ ...fitting, type: "weapon" }))].map((o) => ({ ...o, x: o.x * ("accepts" in o ? 1 : scale), y: o.y * ("accepts" in o ? 1 : scale), radius: o.radius * ("accepts" in o ? 1 : scale) }))
  };
}
var shipLists = /* @__PURE__ */ new WeakMap();
function shipsIn(units) {
  const cached = shipLists.get(units);
  if (cached?.length === units.length) return cached.ships;
  const ships = units.filter((unit) => isShipKind(unit.kind));
  shipLists.set(units, { length: units.length, ships });
  return ships;
}
function localToWorld(ship, point) {
  const angle2 = ship.sailing?.heading ?? 0, c = detCos(angle2), s = detSin(angle2);
  return { x: ship.x + point.x * c - point.y * s, y: ship.y + point.x * s + point.y * c };
}
function worldToLocal(ship, point) {
  const angle2 = ship.sailing?.heading ?? 0, c = detCos(angle2), s = detSin(angle2), x = point.x - ship.x, y = point.y - ship.y;
  return { x: x * c + y * s, y: -x * s + y * c };
}
function circleInPolygon(point, radius, polygon) {
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], dx = b.x - a.x, dy = b.y - a.y;
    if ((dx * (point.y - a.y) - dy * (point.x - a.x)) / Math.hypot(dx, dy) < radius - 1e-6) return false;
  }
  return true;
}
function distanceToHull(ship, world) {
  const profile = shipProfile(ship);
  if (!profile) return Math.hypot(world.x - ship.x, world.y - ship.y);
  const point = worldToLocal(ship, world);
  if (circleInPolygon(point, 0, profile.hull)) return 0;
  let gap = Infinity;
  for (let i = 0; i < profile.hull.length; i++) {
    const a = profile.hull[i], b = profile.hull[(i + 1) % profile.hull.length], dx = b.x - a.x, dy = b.y - a.y;
    const t = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy)));
    gap = Math.min(gap, Math.hypot(point.x - a.x - dx * t, point.y - a.y - dy * t));
  }
  return gap;
}
function hullGap(a, b) {
  const aa = shipProfile(a), bb = shipProfile(b);
  if (!aa || !bb) return Infinity;
  if (hullContact(a, b)) return 0;
  return Math.min(...aa.hull.map((point) => distanceToHull(b, localToWorld(a, point))), ...bb.hull.map((point) => distanceToHull(a, localToWorld(b, point))));
}
function hullContact(a, b) {
  const aa = shipProfile(a), bb = shipProfile(b);
  if (!aa || !bb) return void 0;
  const ap = aa.hull.map((p) => localToWorld(a, p)), bp = bb.hull.map((p) => localToWorld(b, p));
  let overlap = Infinity, normal = { x: 1, y: 0 };
  for (const polygon of [ap, bp]) for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i], q = polygon[(i + 1) % polygon.length], length = Math.hypot(q.x - p.x, q.y - p.y);
    const axis = { x: -(q.y - p.y) / length, y: (q.x - p.x) / length };
    const av = ap.map((p2) => p2.x * axis.x + p2.y * axis.y), bv = bp.map((p2) => p2.x * axis.x + p2.y * axis.y);
    const forward = Math.max(...av) - Math.min(...bv), backward = Math.max(...bv) - Math.min(...av);
    const depth = Math.min(forward, backward);
    if (depth <= 0) return void 0;
    if (depth < overlap) {
      overlap = depth;
      normal = forward <= backward ? axis : { x: -axis.x, y: -axis.y };
    }
  }
  return { ...normal, overlap };
}

// src/shared/ship-handling.ts
var partMaxima = /* @__PURE__ */ new WeakMap();
function shipPartMax(ship) {
  const profile = shipProfile(ship);
  const cached = partMaxima.get(profile);
  if (cached?.maxHp === ship.maxHp) return cached.parts;
  const parts = Object.freeze({
    rigging: Math.round(profile.length * 0.55),
    rudder: Math.round(profile.beam * 0.8),
    cabin: ship.kind === "cutter" ? 0 : Math.round(ship.maxHp * 0.4)
  });
  partMaxima.set(profile, { maxHp: ship.maxHp, parts });
  return parts;
}
var motionLimits = /* @__PURE__ */ new WeakMap();
function shipMotionLimits(ship) {
  const profile = shipProfile(ship), motion = ship.sailing ?? { load: 0, balance: 0 }, parts = shipPartMax(ship);
  const rigging = ship.shipParts?.rigging ?? parts.rigging, rudder = ship.shipParts?.rudder ?? parts.rudder;
  const cached = motionLimits.get(ship);
  if (cached?.profile === profile && cached.speed === ship.speed && cached.load === motion.load && cached.balance === motion.balance && cached.rigging === rigging && cached.rudder === rudder) return cached.limits;
  const load = motion.load / profile.loadCapacity;
  const propulsion = rigging / parts.rigging;
  const steering = rudder / parts.rudder;
  const speed = ship.speed * Math.sqrt(Math.max(0, propulsion)) / (1 + 0.2 * load);
  const limits = Object.freeze({
    speed,
    reverseSpeed: speed * 0.4,
    acceleration: profile.acceleration / (1 + 0.4 * load),
    turnRate: profile.turnRate * steering / (1 + 0.35 * load + 0.25 * motion.balance)
  });
  motionLimits.set(ship, { profile, speed: ship.speed, load: motion.load, balance: motion.balance, rigging, rudder, limits });
  return limits;
}

// src/shared/time.ts
var SIM_TICKS_PER_SECOND = 20;
function seconds(value) {
  return Math.max(1, Math.round(value * SIM_TICKS_PER_SECOND));
}

// src/shared/wind-field.ts
var DEFAULT_WIND = { direction: Math.PI / 4, speed: 80 };
var WIND_CHANGE_INTERVAL_TICKS = seconds(8 * 60);
var angleDifference = (from, to) => ((to - from + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
var uniformSamples = /* @__PURE__ */ new WeakMap();
function windAt(map, _point) {
  const source = map.wind ?? DEFAULT_WIND;
  const sourceDirection = Number.isFinite(source.direction) ? source.direction : DEFAULT_WIND.direction;
  const speed = Number.isFinite(source.speed) ? Math.max(0, source.speed) : DEFAULT_WIND.speed;
  const cached = uniformSamples.get(map);
  if (cached?.direction === sourceDirection && cached.speed === speed) return cached.sample;
  const direction = angleDifference(0, sourceDirection);
  const sample = Object.freeze({
    direction,
    speed,
    x: speed * detCos(direction),
    y: speed * detSin(direction),
    from: angleDifference(0, direction + Math.PI),
    key: `${direction}:${speed}`
  });
  uniformSamples.set(map, { direction: sourceDirection, speed, sample });
  return sample;
}

// src/shared/ship-wind.ts
var SAIL_RULES = {
  trimRate: Math.PI / 3,
  setRate: 0.8,
  billowRate: 2,
  auxiliaryShare: 0.2,
  // RTS courses deliberately sail closer than historical square-riggers.
  // Each rig retains its own no-go sector without making an upwind order
  // spend almost all its travel crossing sideways across the map.
  lateen: { noGoAngle: Math.PI * 38 / 180, maxAngle: Math.PI * 65 / 180 },
  lug: { noGoAngle: Math.PI * 43 / 180, maxAngle: Math.PI * 65 / 180 },
  square: { noGoAngle: Math.PI * 48 / 180, maxAngle: Math.PI * 50 / 180 }
};
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
var angleDifference2 = (from, to) => ((to - from + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
var angleOf = (x, y) => Math.round(Math.atan2(y, x) * 1e9) / 1e9;
var POLAR_KNOTS = {
  lateen: [[SAIL_RULES.lateen.noGoAngle, 0], [SAIL_RULES.lateen.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.66]],
  lug: [[SAIL_RULES.lug.noGoAngle, 0], [SAIL_RULES.lug.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.78]],
  square: [[SAIL_RULES.square.noGoAngle, 0], [SAIL_RULES.square.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.97]]
};
var PERFORMANCE_OPTIONS = {};
function sailRig(kind) {
  return kind === "transport" ? "lug" : kind === "warship" || kind === "carrier" || kind === "shipOfTheLine" ? "square" : "lateen";
}
function polar(rig, angle2) {
  const noGo = SAIL_RULES[rig].noGoAngle;
  if (angle2 <= noGo) return 0;
  const knots = POLAR_KNOTS[rig];
  for (let i = 1; i < knots.length; i++) {
    const [end, high] = knots[i], [start, low] = knots[i - 1];
    if (angle2 <= end) {
      const t = clamp((angle2 - start) / (end - start), 0, 1);
      return low + (high - low) * t * t * (3 - 2 * t);
    }
  }
  return knots.at(-1)[1];
}
function bestBeatAngle(rig) {
  let best = SAIL_RULES[rig].noGoAngle, bestVmg = 0;
  for (let degree = 1; degree < 90; degree++) {
    const angle2 = degree * Math.PI / 180, vmg = polar(rig, angle2) * detCos(angle2);
    if (vmg > bestVmg) {
      bestVmg = vmg;
      best = angle2;
    }
  }
  return best;
}
var BEAT_ANGLES = { lateen: bestBeatAngle("lateen"), lug: bestBeatAngle("lug"), square: bestBeatAngle("square") };
function windAngles(ship, map, heading) {
  const wind = windAt(map, ship), motion = ship.sailing;
  const x = wind.x - (motion?.velocityX ?? 0), y = wind.y - (motion?.velocityY ?? 0);
  const apparentSpeed = Math.hypot(x, y);
  const apparentWindAngle = apparentSpeed > 1e-7 ? angleDifference2(heading, angleOf(-x, -y)) : 0;
  return { wind, apparentWindAngle, apparentSpeed, trueWindAngle: Math.abs(angleDifference2(heading, wind.from)) };
}
function trimAngle(rig, apparentAngle, unloaded) {
  if (unloaded) return 0;
  const side = apparentAngle < 0 ? -1 : 1, absolute = Math.abs(apparentAngle);
  return rig === "square" ? -side * clamp(Math.PI - absolute, 0, SAIL_RULES.square.maxAngle) : side * clamp(absolute - Math.PI / 9, 0, SAIL_RULES[rig].maxAngle);
}
function coursePerformance(ship, map, heading = ship.sailing?.heading ?? 0, options = PERFORMANCE_OPTIONS) {
  const rig = sailRig(ship.kind), limits = shipMotionLimits(ship);
  const { wind, trueWindAngle, apparentWindAngle, apparentSpeed } = windAngles(ship, map, heading);
  const calm = wind.speed <= 1e-7, noGoAngle = SAIL_RULES[rig].noGoAngle;
  const noGo = !calm && trueWindAngle <= noGoAngle + 1e-9;
  const targetSailAngle = trimAngle(rig, apparentWindAngle, calm || noGo);
  const sail = ship.sailing?.sail;
  const alignment = options.assumeTrimmed ? 1 : Math.max(0, detCos((sail?.angle ?? 0) - targetSailAngle)) ** 2;
  const deployed = options.assumeTrimmed ? 1 : clamp(sail?.set ?? 0, 0, 1);
  const trimmedMode = options.assumeTrimmed || !sail || sail.mode === "sail" || sail.mode === "tacking";
  const trimEfficiency = alignment * deployed;
  const maxForwardSpeed = limits.speed;
  const windDrive = Math.sqrt(Math.min(1, wind.speed / DEFAULT_WIND.speed));
  const targetSpeed = calm || noGo || !trimmedMode ? 0 : maxForwardSpeed * windDrive * polar(rig, trueWindAngle) * trimEfficiency;
  return {
    targetSpeed,
    noGo,
    noGoAngle,
    beatAngle: BEAT_ANGLES[rig],
    maxForwardSpeed,
    auxiliarySpeed: maxForwardSpeed * SAIL_RULES.auxiliaryShare,
    trueWindAngle,
    apparentWindAngle,
    apparentSpeed,
    targetSailAngle,
    trimEfficiency,
    windKey: wind.key,
    calm,
    rig
  };
}

// src/shared/navigation-math.ts
var planes = /* @__PURE__ */ new WeakMap();
var supportCandidates = /* @__PURE__ */ new WeakSet();
function supportScale(polygon) {
  if (!supportCandidates.has(polygon) || polygon.length < 12) return;
  let scale = 0;
  for (const p of polygon) {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) return;
    scale = Math.max(scale, Math.abs(p.x), Math.abs(p.y));
  }
  if (scale < 1e-100 || scale > 1e100) return;
  let wraps = 0;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], c = polygon[(i + 2) % polygon.length];
    const ax = b.x - a.x, ay = b.y - a.y, bx = c.x - b.x, by = c.y - b.y;
    const left = ax * by, right = ay * bx;
    const error = 16 * Number.EPSILON * (Math.abs(left) + Math.abs(right) + scale * (Math.abs(ax) + Math.abs(ay) + Math.abs(bx) + Math.abs(by))) + 16 * Number.MIN_VALUE;
    if (!(left - right > error)) return;
    const upperA = ay > 0 || ay === 0 && ax > 0;
    const upperB = by > 0 || by === 0 && bx > 0;
    if (!upperA && upperB) wraps++;
  }
  if (wraps !== 1) return;
  return scale;
}
function projectionSupport(polygon, x, y, start, scale, minimum, state) {
  const first = polygon[start];
  let index = start, value = first.x * x + first.y * y;
  const error = 8 * Number.EPSILON * scale * (Math.abs(x) + Math.abs(y)) + 32 * Number.MIN_VALUE;
  for (let direction = -1; direction <= 1; direction += 2) {
    let cursor = start;
    for (let visited = 1; visited < polygon.length; visited++) {
      cursor += direction;
      if (cursor < 0) cursor += polygon.length;
      else if (cursor === polygon.length) cursor = 0;
      const point = polygon[cursor], projection = point.x * x + point.y * y;
      if (minimum) {
        if (projection < value) index = cursor;
        value = Math.min(value, projection);
        if (projection > value + error) break;
      } else {
        if (projection > value) index = cursor;
        value = Math.max(value, projection);
        if (projection < value - error) break;
      }
    }
  }
  state.index = index;
  return value;
}
var radii = /* @__PURE__ */ new WeakMap();
function polygonRadius(polygon) {
  const cached = radii.get(polygon);
  if (cached !== void 0) return cached;
  let radius = 0;
  for (const point of polygon) radius = Math.max(radius, Math.hypot(point.x, point.y));
  radii.set(polygon, radius);
  return radius;
}
function polygonPlaneState(polygon) {
  let state = planes.get(polygon);
  if (!state) {
    state = { result: [], scale: supportScale(polygon), minIndex: 0, maxIndex: 0, index: 0, maxima: 0 };
    planes.set(polygon, state);
  }
  return state;
}
function appendSupportingPlane(polygon, state) {
  const i = state.result.length;
  const a = polygon[i], b = polygon[(i + 1) % polygon.length], x = a.y - b.y, y = b.x - a.x;
  let min = Infinity;
  if (state.scale !== void 0 && i) {
    min = projectionSupport(polygon, x, y, state.minIndex, state.scale, true, state);
    state.minIndex = state.index;
  } else if (state.scale !== void 0) {
    for (let j = 0; j < polygon.length; j++) {
      const p = polygon[j], v = p.x * x + p.y * y;
      if (v < min) state.minIndex = j;
      min = Math.min(min, v);
    }
  } else {
    for (const p of polygon) {
      const v = p.x * x + p.y * y;
      min = Math.min(min, v);
    }
  }
  const plane = { x, y, min, max: NaN };
  state.result.push(plane);
  return plane;
}
function polygonSupportingPlanes(polygon) {
  const state = polygonPlaneState(polygon);
  while (state.result.length < polygon.length) appendSupportingPlane(polygon, state);
  return state.result;
}
function polygonPlanes(polygon) {
  const state = polygonPlaneState(polygon);
  polygonSupportingPlanes(polygon);
  while (state.maxima < polygon.length) {
    const i = state.maxima, plane = state.result[i], x = plane.x, y = plane.y;
    let max = -Infinity;
    if (state.scale !== void 0 && i) {
      max = projectionSupport(polygon, x, y, state.maxIndex, state.scale, false, state);
      state.maxIndex = state.index;
    } else if (state.scale !== void 0) {
      for (let j = 0; j < polygon.length; j++) {
        const p = polygon[j], v = p.x * x + p.y * y;
        if (v > max) state.maxIndex = j;
        max = Math.max(max, v);
      }
    } else {
      for (const p of polygon) {
        const v = p.x * x + p.y * y;
        max = Math.max(max, v);
      }
    }
    plane.max = max;
    state.maxima++;
  }
  return state.result;
}
function polygonTouchesCell(axes, left, top, cell) {
  for (const p of axes) {
    const min = (p.x >= 0 ? left : left + cell) * p.x + (p.y >= 0 ? top : top + cell) * p.y;
    const max = min + cell * (Math.abs(p.x) + Math.abs(p.y));
    if (p.max <= min + 1e-7 || max <= p.min + 1e-7)
      return false;
  }
  return true;
}
function pointSegmentDistanceSquared(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, l = dx * dx + dy * dy;
  const t = l ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l)) : 0;
  return (p.x - a.x - dx * t) ** 2 + (p.y - a.y - dy * t) ** 2;
}
function capsuleClearsCircles(a, b, radius, obstacles) {
  return obstacles.every((o) => pointSegmentDistanceSquared(o, a, b) >= (o.radius + radius) ** 2 - 1e-7);
}
function diskInConvex(p, radius, polygon) {
  return polygonPlanes(polygon).every((axis) => p.x * axis.x + p.y * axis.y >= axis.min + radius * Math.hypot(axis.x, axis.y) - 1e-6);
}
function convexHull(points) {
  const sorted = [...points].sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  const half = (first, limit, step) => {
    const out = [];
    for (let i = first; i !== limit; i += step) {
      const p = sorted[i];
      const last = out[out.length - 1];
      if (last && (p.x - last.x) ** 2 + (p.y - last.y) ** 2 < 1e-16) continue;
      while (out.length > 1) {
        const a = out[out.length - 2], b = out[out.length - 1];
        const turn = cross(a, b, p), abX = b.x - a.x, abY = b.y - a.y, bpX = p.x - b.x, bpY = p.y - b.y;
        if (turn > 0 && turn * turn > 1e-20 * (abX * abX + abY * abY) * (bpX * bpX + bpY * bpY)) break;
        out.pop();
      }
      out.push(p);
    }
    return out;
  };
  const lower = half(0, sorted.length, 1), upper = half(sorted.length - 1, -1, -1);
  lower.pop();
  upper.pop();
  const result = lower;
  for (const point of upper) result.push(point);
  if (result.length > 1 && (result[0].x - result[result.length - 1].x) ** 2 + (result[0].y - result[result.length - 1].y) ** 2 < 1e-16) result.pop();
  supportCandidates.add(result);
  return result;
}
function minkowskiSum(a, b) {
  if (!a.length || !b.length) return [];
  const first = (p) => p.reduce((best, point, i2) => point.y < p[best].y || point.y === p[best].y && point.x < p[best].x ? i2 : best, 0);
  const ai = first(a), bi = first(b), at2 = (p, start, i2) => p[(start + i2) % p.length];
  let i = 0, j = 0;
  const out = [];
  while (i < a.length || j < b.length) {
    const aa = at2(a, ai, i), bb = at2(b, bi, j);
    out.push({ x: aa.x + bb.x, y: aa.y + bb.y });
    const an = at2(a, ai, i + 1), bn = at2(b, bi, j + 1), cross = (an.x - aa.x) * (bn.y - bb.y) - (an.y - aa.y) * (bn.x - bb.x);
    if (!Number.isFinite(cross)) throw new Error("Convex sums require finite polygon vertices");
    const takeA = i < a.length && (j === b.length || cross >= -1e-9), takeB = j < b.length && (i === a.length || cross <= 1e-9);
    if (takeA) i++;
    if (takeB) j++;
  }
  return convexHull(out);
}
function segmentDistanceSquared(a, b, c, d) {
  const cross = (p, q, r) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
  if (cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0 && Math.max(Math.min(a.x, b.x), Math.min(c.x, d.x)) <= Math.min(Math.max(a.x, b.x), Math.max(c.x, d.x)) && Math.max(Math.min(a.y, b.y), Math.min(c.y, d.y)) <= Math.min(Math.max(a.y, b.y), Math.max(c.y, d.y)))
    return 0;
  return Math.min(pointSegmentDistanceSquared(a, c, d), pointSegmentDistanceSquared(b, c, d), pointSegmentDistanceSquared(c, a, b), pointSegmentDistanceSquared(d, a, b));
}
function clipToConvex(a, b, polygon) {
  let low = 0, high = 1;
  const dx = b.x - a.x, dy = b.y - a.y;
  const state = polygonPlaneState(polygon);
  for (let i = 0; i < polygon.length; i++) {
    const plane = state.result[i] ?? appendSupportingPlane(polygon, state);
    const d = dx * plane.x + dy * plane.y, need = plane.min - a.x * plane.x - a.y * plane.y;
    if (Math.abs(d) < 1e-10) {
      if (need > 1e-7)
        return;
      continue;
    }
    if (d > 0)
      low = Math.max(low, need / d);
    else
      high = Math.min(high, need / d);
    if (low > high + 1e-9)
      return;
  }
  return [low, high];
}
function expandConvex(polygon, amount) {
  const ps = polygonSupportingPlanes(polygon);
  if (!ps.length) return [];
  const result = [];
  let a = ps[ps.length - 1], am = a.min - amount * Math.hypot(a.x, a.y);
  for (const b of ps) {
    const bm = b.min - amount * Math.hypot(b.x, b.y), det = a.x * b.y - a.y * b.x;
    result.push({ x: (am * b.y - a.y * bm) / det, y: (a.x * bm - am * b.x) / det });
    a = b;
    am = bm;
  }
  if (amount >= 0 && Number.isFinite(amount)) supportCandidates.add(result);
  return result;
}

// src/shared/generated/ship-navigation-masks.json
var ship_navigation_masks_default = { cutter: [[{ bounds: [-60.56, -14.360000000000003, 92.56, 46.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-62.42784958007972, -50.16447789755643, 92.5663303326195, 70.14265096979601], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, -2, -1, -2, 0, -2, 1, 2, 2, 2] }, { bounds: [-62.42784958007972, -38.142650969795994, 92.5663303326195, 82.16447789755644], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, -2, 2, -2] }, { bounds: [-60.56, -14.360000000000003, 124.56, 46.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-60.56, -14.360000000000003, 92.56, 78.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-92.56, -14.360000000000003, 92.56, 46.36], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-60.56, -46.36, 92.56, 46.36], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-50.15804181866329, -50.158041818663285, 70.13609516764208, 70.13609516764208], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-50.16447789755645, -62.42784958007973, 70.142650969796, 92.5663303326195], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2, 0, 2, 1, -2, -1, 2] }, { bounds: [-62.42784958007972, -50.164477897556445, 92.5663303326195, 70.14265096979601], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2, 2, 0, -2, 1, 2, -1] }, { bounds: [-50.15804181866329, -50.158041818663285, 102.13609516764208, 102.13609516764208], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 3, 2, 2, 3, 3, 3] }, { bounds: [-82.15804181866329, -50.158041818663285, 70.13609516764208, 102.13609516764208], cells: [-2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 0, 3, 1, 3] }, { bounds: [-82.15804181866329, -82.15804181866329, 70.13609516764208, 70.13609516764208], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-50.15804181866329, -82.15804181866329, 102.13609516764208, 70.13609516764208], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 1, 2, 2, 2] }], [{ bounds: [-14.360000000000005, -60.56, 46.36, 92.56], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-38.142650969795994, -62.42784958007972, 82.16447789755644, 92.5663303326195], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 2, -2, 2, -1, 2, 0, -2, 1, -2, 2] }, { bounds: [-50.16447789755644, -62.42784958007973, 70.14265096979601, 92.5663303326195], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -2, -2, -2, -1, -2, 0, 2, 1, 2, 2] }, { bounds: [-14.360000000000005, -60.56, 46.36, 124.56], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-46.36000000000001, -60.56, 46.36, 92.56], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-14.360000000000005, -92.56, 46.36, 92.56], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-14.360000000000005, -60.56, 78.36, 92.56], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-38.136095167642075, -50.15804181866329, 82.15804181866329, 70.13609516764208], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2] }, { bounds: [-60.5663303326195, -50.16447789755644, 94.42784958007974, 70.14265096979601], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, -2, 0, 2, 1, -2, -1] }, { bounds: [-38.142650969795994, -62.42784958007972, 82.16447789755644, 92.5663303326195], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, -1, -2, 1, 2] }, { bounds: [-70.13609516764208, -50.15804181866329, 82.15804181866329, 102.13609516764208], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3] }, { bounds: [-70.13609516764208, -82.15804181866329, 82.15804181866329, 70.13609516764208], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2] }, { bounds: [-38.136095167642075, -82.15804181866329, 114.15804181866329, 70.13609516764208], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2] }, { bounds: [-38.136095167642075, -50.15804181866329, 114.15804181866329, 102.13609516764208], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3] }], [{ bounds: [-60.56, -14.360000000000008, 92.56, 46.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-60.56633033261951, -38.142650969795994, 94.42784958007972, 82.16447789755645], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 2, 2, 1, 2, 0, 2, -2, -2, -1, -2] }, { bounds: [-60.5663303326195, -50.16447789755644, 94.42784958007974, 70.14265096979601], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 2, -2, 1, -2, 0, -2, -2, 2, -1, 2] }, { bounds: [-92.56, -14.360000000000008, 92.56, 46.36], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-60.56, -46.36000000000001, 92.56, 46.36], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-60.56, -14.360000000000008, 124.56, 46.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-60.56, -14.360000000000008, 92.56, 78.36], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-38.13609516764209, -38.136095167642075, 82.15804181866329, 82.15804181866329], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-38.142650969796016, -60.56633033261951, 82.16447789755644, 94.42784958007972], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 0, -2, -1, 2, 1, -2] }, { bounds: [-60.56633033261951, -38.142650969795994, 94.42784958007972, 82.16447789755645], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, -2, 0, 2, -1, -2, 1] }, { bounds: [-70.13609516764208, -70.13609516764208, 82.15804181866329, 82.15804181866329], cells: [-3, -3, -2, -3, -3, -2, -2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-38.13609516764209, -70.13609516764208, 114.15804181866329, 82.15804181866329], cells: [-1, -3, 0, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-38.13609516764209, -38.136095167642075, 114.15804181866329, 114.15804181866329], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-70.13609516764208, -38.136095167642075, 82.15804181866329, 114.15804181866329], cells: [-2, -2, -1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-14.360000000000003, -60.56, 46.360000000000014, 92.56], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-50.164477897556424, -60.56633033261951, 70.14265096979598, 94.42784958007972], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -2, 2, -2, 1, -2, 0, 2, -2, 2, -1] }, { bounds: [-38.142650969796016, -60.56633033261951, 82.16447789755644, 94.42784958007972], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 2, 2, 2, 1, 2, 0, -2, -2, -2, -1] }, { bounds: [-14.360000000000003, -92.56, 46.360000000000014, 92.56], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-14.360000000000003, -60.56, 78.36000000000001, 92.56], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-14.360000000000003, -60.56, 46.360000000000014, 124.56], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-46.36, -60.56, 46.360000000000014, 92.56], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-50.15804181866328, -38.13609516764209, 70.13609516764207, 82.15804181866329], cells: [1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-62.42784958007972, -38.14265096979601, 92.5663303326195, 82.16447789755644], cells: [1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 2, 0, -2, -1, 2, 1] }, { bounds: [-50.164477897556424, -60.56633033261951, 70.14265096979598, 94.42784958007972], cells: [1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 0, -2, 1, 2, -1, -2] }, { bounds: [-50.15804181866328, -70.13609516764208, 102.13609516764207, 82.15804181866329], cells: [2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-50.15804181866328, -38.13609516764209, 102.13609516764207, 114.15804181866329], cells: [1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-82.15804181866328, -38.13609516764209, 70.13609516764207, 114.15804181866329], cells: [1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-82.15804181866328, -70.13609516764208, 70.13609516764207, 82.15804181866329], cells: [0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }]], transport: [[{ bounds: [-105.44000000000001, -36.800000000000004, 137.44, 68.80000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-108.99097602869695, -90.78266872567798, 137.4438685270237, 101.87498679369766], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 4, 1, -4, -2, 3, 2, -3, -3, -2, -3, -1, -3, 0, -3, 1, 3, 2, 3, 3, 3] }, { bounds: [-108.99097602869695, -69.87498679369769, 137.44386852702368, 122.78266872567798], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 4, -1, -4, 2, 3, -2, -3, 3, -2, 3, -1, 3, 0, 3, 1, -3, 2, -3, 3, -3] }, { bounds: [-105.44000000000001, -36.800000000000004, 169.44, 68.80000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-105.44000000000001, -36.800000000000004, 137.44, 100.80000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3] }, { bounds: [-137.44, -36.800000000000004, 137.44, 68.80000000000001], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-105.44000000000001, -68.80000000000001, 137.44, 68.80000000000001], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-90.7787808134182, -90.77878081341818, 101.87104750729435, 101.87104750729434], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-90.78266872567798, -108.99097602869698, 101.87498679369769, 137.44386852702368], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3, -2, -4, -1, -4, 0, 3, 0, -4, 1, -3, 1, 4, -1, 3, 1, -4, 0, 4, 2, -2, 2, -3] }, { bounds: [-108.99097602869695, -90.78266872567798, 137.4438685270237, 101.87498679369766], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3, -4, -2, -4, -1, 3, 0, -4, 0, -3, 1, 4, 1, 3, -1, -4, 1, 4, 0, -2, 2, -3, 2] }, { bounds: [-90.7787808134182, -90.77878081341818, 133.87104750729435, 133.87104750729435], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 2, 4, 3, 4, 4, 4] }, { bounds: [-122.7787808134182, -90.77878081341818, 101.87104750729435, 133.87104750729435], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 0, 4, 1, 4, 2, 4] }, { bounds: [-122.7787808134182, -122.77878081341818, 101.87104750729435, 101.87104750729434], cells: [-4, -4, -3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-90.7787808134182, -122.77878081341818, 133.87104750729435, 101.87104750729434], cells: [-2, -4, -1, -4, 0, -4, 1, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 1, 3, 2, 3, 3, 3] }], [{ bounds: [-36.80000000000001, -105.44000000000001, 68.80000000000001, 137.44], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-69.87498679369769, -108.99097602869695, 122.78266872567795, 137.44386852702368], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4, -1, 4, 2, -4, -2, 3, 3, -3, 3, -2, 3, -1, 3, 0, -3, 1, -3, 2, -3, 3] }, { bounds: [-90.78266872567798, -108.99097602869698, 101.87498679369769, 137.44386852702368], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 0, 4, 1, 4, -2, -4, 2, 3, -3, -3, -3, -2, -3, -1, -3, 0, 3, 1, 3, 2, 3, 3] }, { bounds: [-36.80000000000001, -105.44000000000001, 68.80000000000001, 169.44], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, 0, 5] }, { bounds: [-68.80000000000001, -105.44000000000001, 68.80000000000001, 137.44], cells: [-2, -4, -1, -4, 0, -4, 1, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4] }, { bounds: [-36.80000000000001, -137.44, 68.80000000000001, 137.44], cells: [-1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-36.80000000000001, -105.44000000000001, 100.80000000000001, 137.44], cells: [-1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3, 0, 4, 1, 4] }], [{ bounds: [-69.87104750729434, -90.7787808134182, 122.77878081341818, 101.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-105.44386852702367, -90.78266872567798, 140.99097602869696, 101.87498679369767], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 4, -2, 4, -1, -3, 0, 4, 0, 3, 1, -4, 1, -3, -1, 4, 1, -4, 0, 2, 2, 3, 2] }, { bounds: [-69.87498679369769, -108.99097602869695, 122.78266872567795, 137.44386852702368], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 2, -4, 1, -4, 0, 3, 0, -4, -1, -3, -1, 4, 1, 3, -1, -4, 0, 4, -2, -2, -2, -3] }, { bounds: [-101.87104750729434, -90.7787808134182, 122.77878081341818, 133.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, -4, 4, -3, 4, -2, 4] }, { bounds: [-101.87104750729434, -122.7787808134182, 122.77878081341818, 101.87104750729435], cells: [-1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-69.87104750729434, -122.7787808134182, 154.7787808134182, 101.87104750729435], cells: [1, -4, 2, -4, 3, -4, 4, -4, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-69.87104750729434, -90.7787808134182, 154.7787808134182, 133.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4] }], [{ bounds: [-105.44000000000001, -36.80000000000001, 137.44, 68.80000000000001], cells: [-1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-105.44386852702367, -69.87498679369767, 140.99097602869696, 122.78266872567798], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, -1, 4, 2, -3, -2, 2, 3, 3, 3, 1, 3, 0, 3, -2, -3, -1, -3, -3, -3] }, { bounds: [-105.44386852702367, -90.78266872567798, 140.99097602869696, 101.87498679369767], cells: [-1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 1, 4, -2, -3, 2, 2, -3, 3, -3, 1, -3, 0, -3, -2, 3, -1, 3, -3, 3] }, { bounds: [-137.44, -36.80000000000001, 137.44, 68.80000000000001], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-105.44000000000001, -68.80000000000001, 137.44, 68.80000000000001], cells: [-1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-105.44000000000001, -36.80000000000001, 169.44, 68.80000000000001], cells: [-1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }, { bounds: [-105.44000000000001, -36.80000000000001, 137.44, 100.80000000000001], cells: [-1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3] }], [{ bounds: [-69.87104750729436, -69.87104750729434, 122.7787808134182, 122.77878081341818], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.8749867936977, -105.44386852702367, 122.782668725678, 140.99097602869696], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, 2, 4, 1, 4, 0, -3, 0, 4, -1, 3, -1, -4, 1, -3, -1, 4, 0, -4, -2, 2, -2, 3] }, { bounds: [-105.44386852702367, -69.87498679369767, 140.99097602869696, 122.78266872567798], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 2, 4, 1, -3, 0, 4, 0, 3, -1, -4, -1, -3, 1, 4, -1, -4, 0, 2, -2, 3, -2] }, { bounds: [-101.87104750729436, -101.87104750729434, 122.7787808134182, 122.77878081341818], cells: [-4, -4, -3, -4, -2, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.87104750729436, -101.87104750729434, 154.7787808134182, 122.77878081341818], cells: [-2, -4, -1, -4, 0, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.87104750729436, -69.87104750729434, 154.7787808134182, 154.7787808134182], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4, 4, 4] }, { bounds: [-101.87104750729436, -69.87104750729434, 122.7787808134182, 154.7787808134182], cells: [-3, -3, -2, -3, -1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -1, 4, 0, 4, 1, 4, 2, 4] }], [{ bounds: [-36.800000000000004, -105.44000000000001, 68.80000000000001, 137.44], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-90.78266872567796, -105.44386852702365, 101.87498679369767, 140.99097602869696], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 1, -4, -2, 4, 2, -3, -3, 2, -3, 3, -3, 1, -3, 0, 3, -2, 3, -1, 3, -3] }, { bounds: [-69.8749867936977, -105.44386852702367, 122.782668725678, 140.99097602869696], cells: [0, -4, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, -1, -4, 2, 4, -2, -3, 3, 2, 3, 3, 3, 1, 3, 0, -3, -2, -3, -1, -3, -3] }, { bounds: [-36.800000000000004, -137.44, 68.80000000000001, 137.44], cells: [0, -5, -1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-36.800000000000004, -105.44000000000001, 100.80000000000001, 137.44], cells: [0, -4, 1, -4, -1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -1, 4, 0, 4, 1, 4, 2, 4] }, { bounds: [-36.800000000000004, -105.44000000000001, 68.80000000000001, 169.44], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5] }, { bounds: [-68.80000000000001, -105.44000000000001, 68.80000000000001, 137.44], cells: [-1, -4, 0, -4, -2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4] }], [{ bounds: [-90.77878081341817, -69.87104750729436, 101.87104750729432, 122.7787808134182], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-108.99097602869698, -69.87498679369772, 137.44386852702368, 122.782668725678], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3, -4, 2, -4, 1, 3, 0, -4, 0, -3, -1, 4, -1, 3, 1, -4, -1, 4, 0, -2, -2, -3, -2] }, { bounds: [-90.78266872567796, -105.44386852702365, 101.87498679369767, 140.99097602869696], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3, -2, 4, -1, 4, 0, -3, 0, 4, 1, 3, 1, -4, -1, -3, 1, 4, 0, -4, 2, 2, 2, 3] }, { bounds: [-90.77878081341817, -101.87104750729436, 133.87104750729432, 122.7787808134182], cells: [2, -4, 3, -4, 4, -4, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-90.77878081341817, -69.87104750729436, 133.87104750729432, 154.7787808134182], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4] }, { bounds: [-122.77878081341817, -69.87104750729436, 101.87104750729432, 154.7787808134182], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, -4, 4, -3, 4, -2, 4, -1, 4] }, { bounds: [-122.77878081341817, -101.87104750729436, 101.87104750729432, 122.7787808134182], cells: [0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }]], warship: [[{ bounds: [-96.2, -31.520000000000003, 128.2, 63.52], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-99.31463361123781, -82.15859516874396, 128.2042183174472, 95.34169835189697], cells: [-2, -2, -1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, -2, -3, -2, 1, 2, 0, 2, 2, 2, 3, 2, -2, -3, -3, -3, -1, -3, 1, -2, 0, -3] }, { bounds: [-99.31463361123784, -63.341698351896966, 128.2042183174472, 114.15859516874396], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, -3, 2, 1, -2, 0, -2, 2, -2, 3, -2, -2, 3, -3, 3, -1, 3, 1, 2, 0, 3] }, { bounds: [-96.2, -31.520000000000003, 160.2, 63.52], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-96.2, -31.520000000000003, 128.2, 95.52000000000001], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-128.2, -31.520000000000003, 128.2, 63.52], cells: [-5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-96.2, -63.52, 128.2, 63.52], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }], [{ bounds: [-82.15434082464209, -82.15434082464208, 95.33738084913064, 95.33738084913062], cells: [-2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-82.15859516874397, -99.31463361123782, 95.34169835189698, 128.20421831744721], cells: [-2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, 2, 3, 1, 3, -3, -3, 0, 3, -1, -4, 0, -4, 1, -3, -1, 3, 1, -4, 0, 4] }, { bounds: [-99.31463361123782, -82.15859516874394, 128.2042183174472, 95.34169835189697], cells: [-2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 3, 2, 3, 1, -3, -3, 3, 0, -4, -1, -4, 0, -3, 1, 3, -1, -4, 1, 4, 0] }, { bounds: [-82.15434082464209, -82.15434082464208, 127.33738084913064, 127.33738084913062], cells: [-2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-114.15434082464209, -82.15434082464208, 95.33738084913064, 127.33738084913062], cells: [-2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }, { bounds: [-114.15434082464209, -114.15434082464208, 95.33738084913064, 95.33738084913062], cells: [-3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-82.15434082464209, -114.15434082464208, 127.33738084913064, 95.33738084913062], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-31.520000000000007, -96.2, 63.52, 128.2], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-63.341698351896966, -99.3146336112378, 114.15859516874396, 128.2042183174472], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4, 2, 0, 2, -3, -2, 1, -2, 0, -2, 2, -2, 3, 3, -2, 3, -3, 3, -1, 2, 1, 3, 0] }, { bounds: [-82.15859516874397, -99.31463361123782, 95.34169835189698, 128.20421831744721], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4, -2, 0, -2, -3, 2, 1, 2, 0, 2, 2, 2, 3, -3, -2, -3, -3, -3, -1, -2, 1, -3, 0] }, { bounds: [-31.520000000000007, -96.2, 63.52, 160.2], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, 0, 5] }, { bounds: [-63.52000000000001, -96.2, 63.52, 128.2], cells: [-2, -4, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4] }, { bounds: [-31.520000000000007, -128.2, 63.52, 128.2], cells: [-1, -5, 0, -5, 1, -5, -1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-31.520000000000007, -96.2, 95.52000000000001, 128.2], cells: [-1, -4, 0, -4, 1, -4, 2, -4, -1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3, 0, 4, 1, 4] }], [{ bounds: [-63.337380849130625, -82.15434082464209, 114.15434082464208, 95.33738084913064], cells: [0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-96.20421831744721, -82.15859516874399, 131.31463361123778, 95.341698351897], cells: [0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 1, 3, -3, -3, 0, 4, -1, 4, 0, 3, 1, -3, -1, 4, 1, -4, 0] }, { bounds: [-63.341698351896966, -99.3146336112378, 114.15859516874396, 128.2042183174472], cells: [0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 3, -3, 0, 3, 1, -4, 0, -4, -1, -3, 1, 3, -1, -4, 0, 4] }, { bounds: [-95.33738084913062, -82.15434082464209, 114.15434082464208, 127.33738084913064], cells: [0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-95.33738084913062, -114.15434082464209, 114.15434082464208, 95.33738084913064], cells: [-1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2] }, { bounds: [-63.337380849130625, -114.15434082464209, 146.15434082464208, 95.33738084913064], cells: [1, -4, 2, -4, 3, -4, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-63.337380849130625, -82.15434082464209, 146.15434082464208, 127.33738084913064], cells: [0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-96.2, -31.52000000000001, 128.2, 63.52], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-96.20421831744721, -63.341698351896966, 131.3146336112378, 114.158595168744], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 1, 2, 2, 2, 0, 2, 3, 2, -1, -2, 0, -2, -2, -2, -3, -2, 2, 3, 3, 3, 1, 3, -1, 2, 0, 3] }, { bounds: [-96.20421831744721, -82.15859516874399, 131.31463361123778, 95.341698351897], cells: [1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 0, -2, 3, -2, -1, 2, 0, 2, -2, 2, -3, 2, 2, -3, 3, -3, 1, -3, -1, -2, 0, -3] }, { bounds: [-128.2, -31.52000000000001, 128.2, 63.52], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-96.2, -63.52000000000001, 128.2, 63.52], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-96.2, -31.52000000000001, 160.2, 63.52], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1] }, { bounds: [-96.2, -31.52000000000001, 128.2, 95.52000000000001], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }], [{ bounds: [-63.33738084913065, -63.337380849130625, 114.1543408246421, 114.15434082464209], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3] }, { bounds: [-63.341698351896994, -96.20421831744721, 114.15859516874401, 131.3146336112378], cells: [-2, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, -1, -3, 3, 3, 0, -3, 1, 4, -1, 3, 0, 4, 1, -3, -1, 4, 0, -4] }, { bounds: [-96.20421831744721, -63.341698351896966, 131.3146336112378, 114.158595168744], cells: [-3, -2, -2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, -3, -1, 3, 3, -3, 0, 4, 1, 3, -1, 4, 0, -3, 1, 4, -1, -4, 0] }, { bounds: [-95.33738084913065, -95.33738084913062, 114.1543408246421, 114.15434082464209], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3] }, { bounds: [-63.33738084913065, -95.33738084913062, 146.1543408246421, 114.15434082464209], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3] }, { bounds: [-63.33738084913065, -63.337380849130625, 146.1543408246421, 146.15434082464208], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4] }, { bounds: [-95.33738084913065, -63.337380849130625, 114.1543408246421, 146.15434082464208], cells: [-3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4] }], [{ bounds: [-31.520000000000003, -96.2, 63.52000000000001, 128.2], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-82.15859516874396, -96.20421831744721, 95.34169835189695, 131.3146336112378], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, -2, 0, -2, 3, 2, -1, 2, 0, 2, -2, 2, -3, -3, 2, -3, 3, -3, 1, -2, -1, -3, 0] }, { bounds: [-63.341698351896994, -96.20421831744721, 114.15859516874401, 131.3146336112378], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, 2, 0, 2, 3, -2, -1, -2, 0, -2, -2, -2, -3, 3, 2, 3, 3, 3, 1, 2, -1, 3, 0] }, { bounds: [-31.520000000000003, -128.2, 63.52000000000001, 128.2], cells: [0, -5, -1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-31.520000000000003, -96.2, 95.52000000000001, 128.2], cells: [0, -4, 1, -4, -1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 2, 4] }, { bounds: [-31.520000000000003, -96.2, 63.52000000000001, 160.2], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, -1, 5, 0, 5, 1, 5] }, { bounds: [-63.52, -96.2, 63.52000000000001, 128.2], cells: [-1, -4, 0, -4, -2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3, -2, 4, -1, 4, 0, 4, 1, 4] }], [{ bounds: [-82.15434082464208, -63.33738084913065, 95.33738084913061, 114.1543408246421], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3] }, { bounds: [-99.31463361123781, -63.34169835189699, 128.2042183174472, 114.15859516874401], cells: [0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 3, -1, -3, 3, 3, 0, -4, 1, -3, -1, -4, 0, 3, 1, -4, -1, 4, 0] }, { bounds: [-82.15859516874396, -96.20421831744721, 95.34169835189695, 131.3146336112378], cells: [2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, -3, -3, 3, 0, -3, -1, 4, 1, 3, 0, 4, -1, -3, 1, 4, 0, -4] }, { bounds: [-82.15434082464208, -95.33738084913065, 127.33738084913061, 114.1543408246421], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3] }, { bounds: [-82.15434082464208, -63.33738084913065, 127.33738084913061, 146.1543408246421], cells: [0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-114.15434082464208, -63.33738084913065, 95.33738084913061, 146.1543408246421], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, -3, 4, -2, 4, -1, 4] }, { bounds: [-114.15434082464208, -95.33738084913065, 95.33738084913061, 114.1543408246421], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3] }]], bombardShip: [[{ bounds: [-105.44000000000001, -30.200000000000003, 137.44, 62.2], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-108.16919982978644, -88.16941850058984, 137.44400309757768, 101.87523632275817], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, -2, -1, -2, -3, -2, 4, 1, 0, -2, 1, 2, -4, -2, 2, 2, 0, 2, 3, 2, -3, -3, -2, -3, -1, -3, 3, 3, 2, 3, 1, -2, 1, 3, 0, -3] }, { bounds: [-108.16919982978645, -69.87523632275817, 137.44400309757765, 120.16941850058983], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, -3, 2, 4, -1, 0, 2, 1, -2, -4, 2, 2, -2, 0, -2, 3, -2, -3, 3, -2, 3, -1, 3, 3, -3, 2, -3, 1, 2, 1, -3, 0, 3] }, { bounds: [-105.44000000000001, -30.200000000000003, 169.44, 62.2], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-105.44000000000001, -30.200000000000003, 137.44, 94.2], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-137.44, -30.200000000000003, 137.44, 62.2], cells: [-5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-105.44000000000001, -62.2, 137.44, 62.2], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }], [{ bounds: [-88.16531415015271, -88.1653141501527, 101.87104750729435, 101.87104750729434], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-88.16941850058986, -108.16919982978644, 101.87523632275818, 137.44400309757765], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3, -1, 2, -2, -4, -1, -4, 0, 3, 0, -4, 1, -3, 1, 4, 1, -4, -1, 3, 0, 4] }, { bounds: [-108.16919982978642, -88.16941850058984, 137.44400309757768, 101.87523632275817], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3, 2, -1, -4, -2, -4, -1, 3, 0, -4, 0, -3, 1, 4, 1, 3, -1, 4, 0, -4, 1] }, { bounds: [-88.16531415015271, -88.1653141501527, 133.87104750729435, 133.87104750729435], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 1, 3, 2, 3, 3, 3, 4, 3, 2, 4, 3, 4, 4, 4] }, { bounds: [-120.16531415015271, -88.1653141501527, 101.87104750729435, 133.87104750729435], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 0, 4, 1, 4, 2, 4] }, { bounds: [-120.16531415015271, -120.1653141501527, 101.87104750729435, 101.87104750729434], cells: [-4, -4, -3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-88.16531415015271, -120.1653141501527, 133.87104750729435, 101.87104750729434], cells: [-2, -4, -1, -4, 0, -4, 1, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 1, 3, 2, 3, 3, 3] }], [{ bounds: [-30.200000000000006, -105.44000000000001, 62.2, 137.44], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-69.87523632275817, -108.16919982978644, 120.16941850058983, 137.44400309757765], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4, 2, -2, 2, -1, 2, -3, -1, 4, 2, 0, -2, 1, 2, -4, -2, 2, -2, 0, -2, 3, 3, -3, 3, -2, 3, -1, -3, 3, -3, 2, 2, 1, -3, 1, 3, 0] }, { bounds: [-88.16941850058986, -108.16919982978644, 101.87523632275818, 137.44400309757765], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4, -2, -2, -2, -1, -2, -3, 1, 4, -2, 0, 2, 1, -2, -4, 2, 2, 2, 0, 2, 3, -3, -3, -3, -2, -3, -1, 3, 3, 3, 2, -2, 1, 3, 1, -3, 0] }, { bounds: [-30.200000000000006, -105.44000000000001, 62.2, 169.44], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, 0, 5] }, { bounds: [-62.2, -105.44000000000001, 62.2, 137.44], cells: [-2, -4, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4] }, { bounds: [-30.200000000000006, -137.44, 62.2, 137.44], cells: [-1, -5, 0, -5, 1, -5, -1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 0, 4] }, { bounds: [-30.200000000000006, -105.44000000000001, 94.2, 137.44], cells: [-1, -4, 0, -4, 1, -4, 2, -4, -1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3, 0, 4, 1, 4] }], [{ bounds: [-69.87104750729434, -88.16531415015271, 120.1653141501527, 101.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-105.44400309757768, -88.16941850058984, 140.16919982978646, 101.87523632275818], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3, -2, -1, 4, -2, 4, -1, -3, 0, 4, 0, 3, 1, -4, 1, -3, -1, -4, 0, 4, 1] }, { bounds: [-69.87523632275817, -108.16919982978644, 120.16941850058983, 137.44400309757765], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3, 1, 2, 2, -4, 1, -4, 0, 3, 0, -4, -1, -3, -1, 4, -1, -4, 1, 3, 0, 4] }, { bounds: [-101.87104750729434, -88.16531415015271, 120.1653141501527, 133.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, -4, 4, -3, 4, -2, 4] }, { bounds: [-101.87104750729434, -120.16531415015271, 120.1653141501527, 101.87104750729435], cells: [-1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-69.87104750729434, -120.16531415015271, 152.1653141501527, 101.87104750729435], cells: [1, -4, 2, -4, 3, -4, 4, -4, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-69.87104750729434, -88.16531415015271, 152.1653141501527, 133.87104750729435], cells: [0, -3, 1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -2, 4, -1, 4, 0, 4] }], [{ bounds: [-105.44000000000001, -30.20000000000001, 137.44, 62.2], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-105.44400309757768, -69.87523632275816, 140.16919982978646, 120.16941850058983], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 2, 2, 1, 2, 3, 2, -4, -1, 0, 2, -1, -2, 4, 2, -2, -2, 0, -2, -3, -2, 2, 3, 3, 3, 1, 3, -3, -3, -2, -3, -1, 2, -1, -3, 0, 3] }, { bounds: [-105.44400309757768, -88.16941850058984, 140.16919982978646, 101.87523632275818], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 2, -2, 1, -2, 3, -2, -4, 1, 0, -2, -1, 2, 4, -2, -2, 2, 0, 2, -3, 2, 2, -3, 3, -3, 1, -3, -3, 3, -2, 3, -1, -2, -1, 3, 0, -3] }, { bounds: [-137.44, -30.20000000000001, 137.44, 62.2], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-105.44000000000001, -62.20000000000001, 137.44, 62.2], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-105.44000000000001, -30.20000000000001, 169.44, 62.2], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1] }, { bounds: [-105.44000000000001, -30.20000000000001, 137.44, 94.2], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }], [{ bounds: [-69.87104750729436, -69.87104750729434, 120.16531415015272, 120.1653141501527], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.8752363227582, -105.44400309757768, 120.16941850058986, 140.16919982978646], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, 1, -2, 2, 4, 1, 4, 0, -3, 0, 4, -1, 3, -1, -4, 0, -4, 1, -3, -1, 4] }, { bounds: [-105.44400309757768, -69.87523632275816, 140.16919982978646, 120.16941850058983], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, -2, 1, 4, 2, 4, 1, -3, 0, 4, 0, 3, -1, -4, -1, 4, -1, -4, 0, -3, 1] }, { bounds: [-101.87104750729436, -101.87104750729434, 120.16531415015272, 120.1653141501527], cells: [-4, -4, -3, -4, -2, -4, -4, -3, -3, -3, -2, -3, -1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.87104750729436, -101.87104750729434, 152.1653141501527, 120.1653141501527], cells: [-2, -4, -1, -4, 0, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-69.87104750729436, -69.87104750729434, 152.1653141501527, 152.1653141501527], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4, 4, 4] }, { bounds: [-101.87104750729436, -69.87104750729434, 120.16531415015272, 152.1653141501527], cells: [-3, -3, -2, -3, -1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -1, 4, 0, 4, 1, 4, 2, 4] }], [{ bounds: [-30.200000000000003, -105.44000000000001, 62.20000000000002, 137.44], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-88.16941850058984, -105.44400309757769, 101.87523632275816, 140.16919982978646], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, -2, 2, -2, 1, -2, 3, 1, -4, -2, 0, 2, -1, -2, 4, 2, -2, 2, 0, 2, -3, -3, 2, -3, 3, -3, 1, 3, -3, 3, -2, -2, -1, 3, -1, -3, 0] }, { bounds: [-69.8752363227582, -105.44400309757768, 120.16941850058986, 140.16919982978646], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, 2, 2, 2, 1, 2, 3, -1, -4, 2, 0, -2, -1, 2, 4, -2, -2, -2, 0, -2, -3, 3, 2, 3, 3, 3, 1, -3, -3, -3, -2, 2, -1, -3, -1, 3, 0] }, { bounds: [-30.200000000000003, -137.44, 62.20000000000002, 137.44], cells: [0, -5, -1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-30.200000000000003, -105.44000000000001, 94.20000000000002, 137.44], cells: [0, -4, 1, -4, -1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 2, 4] }, { bounds: [-30.200000000000003, -105.44000000000001, 62.20000000000002, 169.44], cells: [0, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4, -1, 5, 0, 5, 1, 5] }, { bounds: [-62.2, -105.44000000000001, 62.20000000000002, 137.44], cells: [-1, -4, 0, -4, -2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3, -2, 4, -1, 4, 0, 4, 1, 4] }], [{ bounds: [-88.16531415015268, -69.87104750729436, 101.87104750729432, 120.16531415015272], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-108.16919982978644, -69.8752363227582, 137.44400309757762, 120.16941850058984], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3, 2, 1, -4, 2, -4, 1, 3, 0, -4, 0, -3, -1, 4, -1, -4, -1, 4, 0, 3, 1] }, { bounds: [-88.16941850058984, -105.44400309757769, 101.87523632275816, 140.16919982978646], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3, -1, -2, -2, 4, -1, 4, 0, -3, 0, 4, 1, 3, 1, -4, 0, -4, -1, -3, 1, 4] }, { bounds: [-88.16531415015268, -101.87104750729436, 133.87104750729432, 120.16531415015272], cells: [2, -4, 3, -4, 4, -4, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-88.16531415015268, -69.87104750729436, 133.87104750729432, 152.1653141501527], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4] }, { bounds: [-120.16531415015268, -69.87104750729436, 101.87104750729432, 152.1653141501527], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, -4, 4, -3, 4, -2, 4, -1, 4] }, { bounds: [-120.16531415015268, -101.87104750729436, 101.87104750729432, 120.16531415015272], cells: [0, -4, 1, -4, 2, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3, 0, 3] }]], fireShip: [[{ bounds: [-88.28, -23.6, 120.28, 55.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-90.61576632279092, -73.42269352701177, 120.28468141130227, 89.74199281283092], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, -2, -1, -2, -3, -2, 0, -2, 1, 2, 2, 2, 3, 2, 0, 2, -2, -3, -1, -3] }, { bounds: [-90.61576632279093, -57.741992812830915, 120.28468141130227, 105.42269352701179], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, -3, 2, 0, 2, 1, -2, 2, -2, 3, -2, 0, -2, -2, 3, -1, 3] }, { bounds: [-88.28, -23.6, 152.28, 55.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-88.28, -23.6, 120.28, 87.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-120.28, -23.6, 120.28, 55.6], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-88.28, -55.6, 120.28, 55.6], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }], [{ bounds: [-73.41789512172606, -73.41789512172605, 89.73709514213319, 89.73709514213317], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-73.42269352701179, -90.61576632279092, 89.74199281283093, 120.28468141130224], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 2, 3, 0, -3, 1, 3, 1, -2, -1, 2, 0, 3, 1, -3, -1, 3] }, { bounds: [-90.61576632279095, -73.42269352701177, 120.28468141130226, 89.74199281283094], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 3, 2, -3, 0, 3, 1, -2, 1, 2, -1, 3, 0, -3, 1, 3, -1] }, { bounds: [-73.41789512172606, -73.41789512172605, 121.73709514213319, 121.73709514213317], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-105.41789512172606, -73.41789512172605, 89.73709514213319, 121.73709514213317], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }, { bounds: [-105.41789512172606, -105.41789512172605, 89.73709514213319, 89.73709514213317], cells: [-3, -4, -2, -4, -4, -3, -3, -3, -2, -3, -1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-73.41789512172606, -105.41789512172605, 121.73709514213319, 89.73709514213317], cells: [-1, -4, 0, -4, -2, -3, -1, -3, 0, -3, 1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-23.600000000000005, -88.28, 55.6, 120.28], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-57.74199281283092, -90.61576632279093, 105.42269352701177, 120.28468141130229], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 2, -2, 2, -1, 2, -3, 2, 0, -2, 1, -2, 2, -2, 3, -2, 0, 3, -2, 3, -1] }, { bounds: [-73.42269352701177, -90.61576632279092, 89.74199281283093, 120.28468141130224], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -2, -2, -2, -1, -2, -3, -2, 0, 2, 1, 2, 2, 2, 3, 2, 0, -3, -2, -3, -1] }, { bounds: [-23.600000000000005, -88.28, 55.6, 152.28], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-55.60000000000001, -88.28, 55.6, 120.28], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3] }, { bounds: [-23.600000000000005, -120.28, 55.6, 120.28], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-23.600000000000005, -88.28, 87.6, 120.28], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }], [{ bounds: [-57.73709514213317, -73.41789512172606, 105.41789512172605, 89.73709514213319], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-88.28468141130227, -73.42269352701179, 122.61576632279092, 89.74199281283094], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, -3, 2, 3, 0, -3, 1, 2, 1, -2, -1, -3, 0, 3, 1, -3, -1] }, { bounds: [-57.74199281283092, -90.61576632279095, 105.42269352701177, 120.28468141130229], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, -2, 3, 0, -3, -1, 3, -1, -2, 1, 2, 0, 3, -1, -3, 1, 3] }, { bounds: [-89.73709514213317, -73.41789512172606, 105.41789512172605, 121.73709514213319], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-89.73709514213317, -105.41789512172606, 105.41789512172605, 89.73709514213319], cells: [0, -4, 1, -4, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2] }, { bounds: [-57.73709514213317, -105.41789512172606, 137.41789512172605, 89.73709514213319], cells: [2, -4, 3, -4, 1, -3, 2, -3, 3, -3, 4, -3, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-57.73709514213317, -73.41789512172606, 137.41789512172605, 121.73709514213319], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-88.28, -23.60000000000001, 120.28, 55.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-88.28468141130227, -57.74199281283092, 122.61576632279093, 105.42269352701177], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 1, 2, 2, 2, 3, 2, 0, 2, -2, -2, -1, -2, -3, -2, 0, -2, 2, 3, 1, 3] }, { bounds: [-88.28468141130227, -73.42269352701179, 122.61576632279092, 89.74199281283094], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 1, -2, 2, -2, 3, -2, 0, -2, -2, 2, -1, 2, -3, 2, 0, 2, 2, -3, 1, -3] }, { bounds: [-120.28, -23.60000000000001, 120.28, 55.6], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-88.28, -55.60000000000001, 120.28, 55.6], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-88.28, -23.60000000000001, 152.28, 55.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-88.28, -23.60000000000001, 120.28, 87.6], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-57.7370951421332, -57.73709514213317, 105.41789512172608, 105.41789512172605], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-57.74199281283095, -88.28468141130227, 105.4226935270118, 122.6157663227909], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, -2, -3, 0, 3, -1, -3, -1, 2, 1, -2, 0, -3, -1, 3, 1, -3] }, { bounds: [-88.28468141130227, -57.74199281283092, 122.61576632279093, 105.42269352701177], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, -3, -2, 3, 0, -3, -1, 2, -1, -2, 1, -3, 0, 3, -1, -3, 1] }, { bounds: [-89.7370951421332, -89.73709514213317, 105.41789512172608, 105.41789512172605], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-57.7370951421332, -89.73709514213317, 137.41789512172608, 105.41789512172605], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-57.7370951421332, -57.73709514213317, 137.41789512172608, 137.41789512172605], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 1, 3, 2, 3, 3, 3, 4, 3, 2, 4, 3, 4] }, { bounds: [-89.7370951421332, -57.73709514213317, 105.41789512172608, 137.41789512172605], cells: [-3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -1, 3, 0, 3, 1, 3, 2, 3, 0, 4, 1, 4] }], [{ bounds: [-23.6, -88.28, 55.60000000000001, 120.28], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-73.42269352701176, -88.28468141130229, 89.7419928128309, 122.61576632279093], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -2, 1, -2, 2, -2, 3, -2, 0, 2, -2, 2, -1, 2, -3, 2, 0, -3, 2, -3, 1] }, { bounds: [-57.74199281283095, -88.28468141130227, 105.4226935270118, 122.6157663227909], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 2, 1, 2, 2, 2, 3, 2, 0, -2, -2, -2, -1, -2, -3, -2, 0, 3, 2, 3, 1] }, { bounds: [-23.6, -120.28, 55.60000000000001, 120.28], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-23.6, -88.28, 87.60000000000001, 120.28], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }, { bounds: [-23.6, -88.28, 55.60000000000001, 152.28], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-55.6, -88.28, 55.60000000000001, 120.28], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-73.41789512172605, -57.7370951421332, 89.73709514213316, 105.41789512172608], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3] }, { bounds: [-90.61576632279093, -57.74199281283096, 120.28468141130229, 105.4226935270118], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3, 3, -2, -3, 0, 3, -1, -2, -1, 2, 1, 3, 0, -3, -1, 3, 1] }, { bounds: [-73.42269352701176, -88.28468141130229, 89.7419928128309, 122.61576632279093], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3, 2, -3, 0, 3, 1, -3, 1, 2, -1, -2, 0, -3, 1, 3, -1, -3] }, { bounds: [-73.41789512172605, -89.7370951421332, 121.73709514213316, 105.41789512172608], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3] }, { bounds: [-73.41789512172605, -57.7370951421332, 121.73709514213316, 137.41789512172608], cells: [0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4] }, { bounds: [-105.41789512172605, -57.7370951421332, 89.73709514213316, 137.41789512172608], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, -4, 3, -3, 3, -2, 3, -1, 3, -3, 4, -2, 4] }, { bounds: [-105.41789512172605, -89.7370951421332, 89.73709514213316, 105.41789512172608], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3] }]], carrier: [[{ bounds: [-131.84, -53.96000000000001, 163.84, 85.96000000000001], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-136.94595558153554, -116.56194287824172, 163.8431779475796, 120.54184830823036], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, -2, 5, 1, -2, -3, -3, -3, 4, 2, -4, -3, -1, -3, 0, -3, 1, 3, 2, 3, 3, 3, 0, 3, -3, -4, -2, -4, 4, 3, -1, -4, 1, -3] }, { bounds: [-136.94595558153554, -88.54184830823036, 163.8431779475796, 148.56194287824172], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 2, 5, -1, -2, 3, -3, 3, 4, -2, -4, 3, -1, 3, 0, 3, 1, -3, 2, -3, 3, -3, 0, -3, -3, 4, -2, 4, 4, -3, -1, 4, 1, 3] }, { bounds: [-131.84, -53.96000000000001, 195.84, 85.96000000000001], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }, { bounds: [-131.84, -53.96000000000001, 163.84, 117.96000000000001], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-163.84, -53.96000000000001, 163.84, 85.96000000000001], cells: [-5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-131.84, -85.96000000000001, 163.84, 85.96000000000001], cells: [-4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-116.55876268462978, -116.55876268462978, 120.5386665306192, 120.53866653061918], cells: [-3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-116.56194287824174, -136.9459555815356, 120.54184830823034, 163.8431779475796], cells: [-3, -4, -2, -4, -1, -4, 0, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, 3, 4, -1, 3, 2, 4, 1, 4, -2, -5, -1, -5, 0, 4, 1, -4, 0, -5, 2, -3, 1, -5, -1, 4, 1, 5, 2, -4, 0, 5, -2, 3] }, { bounds: [-136.9459555815356, -116.56194287824172, 163.8431779475796, 120.54184830823036], cells: [-3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 3, -1, 4, 2, 4, 1, -5, -2, -5, -1, 4, 0, -4, 1, -5, 0, -3, 2, -5, 1, 4, -1, 5, 1, -4, 2, 5, 0, 3, -2] }, { bounds: [-116.55876268462978, -116.55876268462978, 152.5386665306192, 152.5386665306192], cells: [-3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4, 4, 4] }, { bounds: [-148.55876268462978, -116.55876268462978, 120.5386665306192, 152.5386665306192], cells: [-3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4] }, { bounds: [-148.55876268462978, -148.55876268462978, 120.5386665306192, 120.53866653061918], cells: [-4, -5, -3, -5, -2, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-116.55876268462978, -148.55876268462978, 152.5386665306192, 120.53866653061918], cells: [-2, -5, -1, -5, 0, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3] }], [{ bounds: [-53.960000000000015, -131.84, 85.96000000000001, 163.84], cells: [-1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 0, 5] }, { bounds: [-88.54184830823036, -136.94595558153557, 148.56194287824172, 163.8431779475796], cells: [-1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 0, 5, 2, -5, -1, 5, 3, -2, 3, -3, -2, 4, 3, -4, 3, -1, 3, 0, -3, 1, -3, 2, -3, 3, -3, 0, 4, -3, 4, -2, -3, 4, 4, -1, 3, 1] }, { bounds: [-116.56194287824174, -136.9459555815356, 120.54184830823034, 163.8431779475796], cells: [-1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 0, 5, -2, -5, 1, 5, -3, -2, -3, -3, 2, 4, -3, -4, -3, -1, -3, 0, 3, 1, 3, 2, 3, 3, 3, 0, -4, -3, -4, -2, 3, 4, -4, -1, -3, 1] }, { bounds: [-53.960000000000015, -131.84, 85.96000000000001, 195.84], cells: [-1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5, 0, 6] }, { bounds: [-85.96000000000001, -131.84, 85.96000000000001, 163.84], cells: [-2, -5, -1, -5, 0, -5, 1, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, -1, 5, 0, 5] }, { bounds: [-53.960000000000015, -163.84, 85.96000000000001, 163.84], cells: [-1, -6, 0, -6, 1, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4, 1, 4, 0, 5] }, { bounds: [-53.960000000000015, -131.84, 117.96000000000001, 163.84], cells: [-1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -1, 4, 0, 4, 1, 4, 2, 4, 0, 5, 1, 5] }], [{ bounds: [-88.53866653061918, -116.55876268462978, 148.55876268462978, 120.5386665306192], cells: [1, -4, 2, -4, 3, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-131.84317794757962, -116.56194287824174, 168.94595558153557, 120.54184830823034], cells: [1, -4, 2, -4, 3, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, -4, 3, -3, -1, -4, 2, -4, 1, 5, -2, 5, -1, -4, 0, 4, 1, 5, 0, 3, 2, 5, 1, -4, -1, -5, 1, 4, 2, -5, 0, -3, -2] }, { bounds: [-88.54184830823036, -136.94595558153557, 148.56194287824172, 163.8431779475796], cells: [0, -4, 1, -4, 2, -4, 3, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, -3, 4, 1, 3, -2, 4, -1, 4, 1, -5, 2, -5, 0, 4, -1, -4, 0, -5, -2, -3, -1, -5, 1, 4, -1, 5, -2, -4, 0, 5, 2, 3] }, { bounds: [-120.53866653061918, -116.55876268462978, 148.55876268462978, 152.5386665306192], cells: [1, -4, 2, -4, 3, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -4, 4, -3, 4, -2, 4, -1, 4] }, { bounds: [-120.53866653061918, -148.55876268462978, 148.55876268462978, 120.5386665306192], cells: [0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-88.53866653061918, -148.55876268462978, 180.55876268462978, 120.5386665306192], cells: [2, -5, 3, -5, 4, -5, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3] }, { bounds: [-88.53866653061918, -116.55876268462978, 180.55876268462978, 152.5386665306192], cells: [1, -4, 2, -4, 3, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4] }], [{ bounds: [-131.84, -53.96000000000002, 163.84, 85.96000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }, { bounds: [-131.8431779475796, -88.54184830823033, 168.9459555815356, 148.56194287824172], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -5, -1, 2, 3, 3, 3, -4, -2, 4, 3, 1, 3, 0, 3, -1, -3, -2, -3, -3, -3, 0, -3, 3, 4, 2, 4, -4, -3, 1, 4, -1, 3] }, { bounds: [-131.84317794757962, -116.56194287824174, 168.94595558153557, 120.54184830823034], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, -2, -5, 1, 2, -3, 3, -3, -4, 2, 4, -3, 1, -3, 0, -3, -1, 3, -2, 3, -3, 3, 0, 3, 3, -4, 2, -4, -4, 3, 1, -4, -1, -3] }, { bounds: [-163.84, -53.96000000000002, 163.84, 85.96000000000001], cells: [-4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }, { bounds: [-131.84, -85.96000000000002, 163.84, 85.96000000000001], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2] }, { bounds: [-131.84, -53.96000000000002, 195.84, 85.96000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2] }, { bounds: [-131.84, -53.96000000000002, 163.84, 117.96000000000001], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3] }], [{ bounds: [-88.53866653061921, -88.53866653061918, 148.5587626846298, 148.55876268462978], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4] }, { bounds: [-88.54184830823034, -131.8431779475796, 148.56194287824172, 168.94595558153557], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 0, 4, 1, 4, 2, 4, 3, 4, -3, -4, -2, -4, 1, -3, -1, -4, 1, 5, 2, 5, 0, -4, -1, 4, 0, 5, -2, 3, -1, 5, -1, -5, 1, -4, -2, 4, 0, -5, 2, -3] }, { bounds: [-131.8431779475796, -88.54184830823033, 168.9459555815356, 148.56194287824172], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4, -4, -3, -4, -2, -3, 1, -4, -1, 5, 1, 5, 2, -4, 0, 4, -1, 5, 0, 3, -2, 5, -1, -5, -1, -4, 1, 4, -2, -5, 0, -3, 2] }, { bounds: [-120.53866653061921, -120.53866653061918, 148.5587626846298, 148.55876268462978], cells: [-4, -4, -3, -4, -2, -4, -1, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4] }, { bounds: [-88.53866653061921, -120.53866653061918, 180.5587626846298, 148.55876268462978], cells: [-3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 1, 4, 2, 4, 3, 4] }, { bounds: [-88.53866653061921, -88.53866653061918, 180.5587626846298, 180.55876268462978], cells: [-3, -3, -2, -3, -1, -3, 0, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 2, 5, 3, 5, 4, 5] }, { bounds: [-120.53866653061921, -88.53866653061918, 148.5587626846298, 180.55876268462978], cells: [-4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 0, 5, 1, 5, 2, 5] }], [{ bounds: [-53.96000000000001, -131.84, 85.96000000000002, 163.84], cells: [0, -5, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5] }, { bounds: [-116.56194287824171, -131.84317794757962, 120.54184830823027, 168.94595558153557], cells: [0, -5, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5, -2, 5, 1, -5, -3, 2, -3, 3, 2, -4, -3, 4, -3, 1, -3, 0, 3, -1, 3, -2, 3, -3, 3, 0, -4, 3, -4, 2, 3, -4, -4, 1, -3, -1] }, { bounds: [-88.54184830823034, -131.8431779475796, 148.56194287824172, 168.94595558153557], cells: [0, -5, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5, 2, 5, -1, -5, 3, 2, 3, 3, -2, -4, 3, 4, 3, 1, 3, 0, -3, -1, -3, -2, -3, -3, -3, 0, 4, 3, 4, 2, -3, -4, 4, 1, 3, -1] }, { bounds: [-53.96000000000001, -163.84, 85.96000000000002, 163.84], cells: [0, -6, -1, -5, 0, -5, 1, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -1, 5, 0, 5, 1, 5] }, { bounds: [-53.96000000000001, -131.84, 117.96000000000002, 163.84], cells: [0, -5, 1, -5, -1, -4, 0, -4, 1, -4, 2, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -1, 5, 0, 5, 1, 5, 2, 5] }, { bounds: [-53.96000000000001, -131.84, 85.96000000000002, 195.84], cells: [0, -5, -1, -4, 0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -1, 6, 0, 6, 1, 6] }, { bounds: [-85.96000000000001, -131.84, 85.96000000000002, 163.84], cells: [-1, -5, 0, -5, -2, -4, -1, -4, 0, -4, 1, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5] }], [{ bounds: [-116.55876268462977, -88.53866653061921, 120.53866653061917, 148.5587626846298], cells: [0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -3, 4, -2, 4, -1, 4] }, { bounds: [-136.9459555815356, -88.54184830823036, 163.84317794757956, 148.56194287824178], cells: [0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -3, 4, -2, 4, -1, 4, 4, -3, 4, -2, 3, 1, 4, -1, -5, 1, -5, 2, 4, 0, -4, -1, -5, 0, -3, -2, -5, -1, 5, -1, 4, 1, -4, -2, 5, 0, 3, 2] }, { bounds: [-116.56194287824171, -131.84317794757962, 120.54184830823027, 168.94595558153557], cells: [0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -3, 4, -2, 4, -1, 4, 0, 4, 3, -4, 2, -4, -1, -3, 1, -4, -2, 5, -1, 5, 0, -4, 1, 4, 0, 5, 2, 3, 1, 5, 1, -5, -1, -4, 2, 4, 0, -5, -2, -3] }, { bounds: [-116.55876268462977, -120.53866653061921, 152.53866653061917, 148.5587626846298], cells: [1, -4, 2, -4, 3, -4, 4, -4, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -3, 4, -2, 4, -1, 4] }, { bounds: [-116.55876268462977, -88.53866653061921, 152.53866653061917, 180.5587626846298], cells: [0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5] }, { bounds: [-148.55876268462976, -88.53866653061921, 120.53866653061917, 180.5587626846298], cells: [0, -3, 1, -3, 2, -3, 3, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, -4, 5, -3, 5, -2, 5] }, { bounds: [-148.55876268462976, -120.53866653061921, 120.53866653061917, 148.5587626846298], cells: [-1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, -3, 4, -2, 4, -1, 4] }]], shipOfTheLine: [[{ bounds: [-176.72, -79.04, 208.72, 111.04], cells: [-5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-183.93641318471984, -159.03008817296478, 208.72247525475328, 153.11613640671555], cells: [-5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -6, -3, 4, 3, -3, -4, -2, -4, -4, -4, 6, 2, -5, -4, -1, -4, 5, 3, 0, -4, -4, -5, -3, -5, 1, 4, 2, 4, 3, 4, -2, -5, 4, 4, 0, 4, 5, 4, -1, -5, 1, -4, 0, -5] }, { bounds: [-183.93641318471984, -121.11613640671551, 208.72247525475328, 191.03008817296478], cells: [-5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -6, 3, 4, -3, -3, 4, -2, 4, -4, 4, 6, -2, -5, 4, -1, 4, 5, -3, 0, 4, -4, 5, -3, 5, 1, -4, 2, -4, 3, -4, -2, 5, 4, -4, 0, -4, 5, -4, -1, 5, 1, 4, 0, 5] }, { bounds: [-176.72, -79.04, 240.72, 111.04], cells: [-5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, 7, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, 7, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3] }, { bounds: [-176.72, -79.04, 208.72, 143.04000000000002], cells: [-5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -6, 3, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4] }, { bounds: [-208.72, -79.04, 208.72, 111.04], cells: [-6, -3, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -7, -2, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -7, -1, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -7, 0, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -7, 1, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -7, 2, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -6, 3, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3] }, { bounds: [-176.72, -111.04, 208.72, 111.04], cells: [-5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -6, -3, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3] }], [{ bounds: [-159.02759596269382, -159.02759596269382, 153.11366172632106, 153.11366172632106], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4] }, { bounds: [-159.03008817296478, -183.93641318471978, 153.11613640671553, 208.72247525475328], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, -3, -6, -2, -6, 4, 5, -1, -6, -1, 4, 3, 5, 2, 5, 1, 5, 1, -5, 0, -6, 0, 5, 2, -4, 2, 6, 1, -6, 2, -5, 1, 6, -1, 5, -2, 4, 3, -3, 2, -6, 0, 6, 3, -4, -3, 3, 3, -5, -2, 5, -1, 6] }, { bounds: [-183.93641318471984, -159.03008817296478, 208.72247525475328, 153.11613640671555], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, -6, -3, -6, -2, 5, 4, -6, -1, 4, -1, 5, 3, 5, 2, 5, 1, -5, 1, -6, 0, 5, 0, -4, 2, 6, 2, -6, 1, 6, 1, -5, 2, 5, -1, 4, -2, -3, 3, 6, 0, -6, 2, -4, 3, 3, -3, -5, 3, 5, -2, 6, -1] }, { bounds: [-159.02759596269382, -159.02759596269382, 185.11366172632106, 185.11366172632103], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 1, 5, 2, 5, 3, 5, 4, 5, 5, 5] }, { bounds: [-191.02759596269382, -159.02759596269382, 153.11366172632106, 185.11366172632103], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -6, -3, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5] }, { bounds: [-191.02759596269382, -191.0275959626938, 153.11366172632106, 153.11366172632106], cells: [-5, -6, -4, -6, -3, -6, -2, -6, -1, -6, -6, -5, -5, -5, -4, -5, -3, -5, -2, -5, -1, -5, 0, -5, -6, -4, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -6, -3, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4] }, { bounds: [-159.02759596269382, -191.0275959626938, 185.11366172632106, 153.11366172632106], cells: [-3, -6, -2, -6, -1, -6, 0, -6, 1, -6, -4, -5, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4] }], [{ bounds: [-79.04000000000002, -176.72, 111.04, 208.72], cells: [-2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -1, 6, 0, 6, 1, 6] }, { bounds: [-121.11613640671551, -183.93641318471984, 191.03008817296478, 208.72247525475325], cells: [-2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -1, 6, 0, 6, 1, 6, 3, -6, -3, 4, 4, -3, 4, -2, 4, -4, -2, 6, 4, -5, 4, -1, -3, 5, 4, 0, 5, -4, 5, -3, -4, 1, -4, 2, -4, 3, 5, -2, -4, 4, -4, 0, -4, 5, 5, -1, 4, 1, 5, 0] }, { bounds: [-159.03008817296478, -183.93641318471978, 153.11613640671553, 208.72247525475328], cells: [-2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -1, 6, 0, 6, 1, 6, -3, -6, 3, 4, -4, -3, -4, -2, -4, -4, 2, 6, -4, -5, -4, -1, 3, 5, -4, 0, -5, -4, -5, -3, 4, 1, 4, 2, 4, 3, -5, -2, 4, 4, 4, 0, 4, 5, -5, -1, -4, 1, -5, 0] }, { bounds: [-79.04000000000002, -176.72, 111.04, 240.72], cells: [-2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6, -1, 7, 0, 7, 1, 7] }, { bounds: [-111.04000000000002, -176.72, 111.04, 208.72], cells: [-3, -6, -2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -4, -5, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -2, 6, -1, 6, 0, 6, 1, 6] }, { bounds: [-79.04000000000002, -208.72, 111.04, 208.72], cells: [-2, -7, -1, -7, 0, -7, 1, -7, 2, -7, -3, -6, -2, -6, -1, -6, 0, -6, 1, -6, 2, -6, 3, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -1, 6, 0, 6, 1, 6] }, { bounds: [-79.04000000000002, -176.72, 143.04000000000002, 208.72], cells: [-2, -6, -1, -6, 0, -6, 1, -6, 2, -6, 3, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -1, 6, 0, 6, 1, 6, 2, 6] }], [{ bounds: [-121.11366172632106, -159.02759596269382, 191.0275959626938, 153.11366172632106], cells: [0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4] }, { bounds: [-176.72247525475325, -159.0300881729648, 215.9364131847198, 153.11613640671553], cells: [0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 6, -3, 6, -2, -5, 4, -4, -1, 6, -1, -5, 3, -5, 2, -5, 1, 5, 1, 6, 0, -5, 0, 4, 2, -6, 2, 6, 1, -6, 1, 5, 2, -5, -1, -4, -2, 3, 3, -6, 0, 6, 2, 4, 3, -3, -3, 5, 3, -5, -2, -6, -1] }, { bounds: [-121.11613640671551, -183.93641318471984, 191.03008817296478, 208.72247525475325], cells: [0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 2, -6, 3, -6, -4, 5, 1, -6, 1, 4, -3, 5, -2, 5, -1, 5, -1, -5, 0, -6, 0, 5, -2, -4, -2, 6, -1, -6, -2, -5, -1, 6, 1, 5, 2, 4, -3, -3, -2, -6, 0, 6, -3, -4, 3, 3, -3, -5, 2, 5, 1, 6] }, { bounds: [-153.11366172632106, -159.02759596269382, 191.0275959626938, 185.11366172632106], cells: [0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -5, 5, -4, 5, -3, 5, -2, 5, -1, 5] }, { bounds: [-153.11366172632106, -191.02759596269382, 191.0275959626938, 153.11366172632106], cells: [-1, -6, 0, -6, 1, -6, 2, -6, 3, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4] }, { bounds: [-121.11366172632106, -191.02759596269382, 223.0275959626938, 153.11366172632106], cells: [1, -6, 2, -6, 3, -6, 4, -6, 5, -6, 0, -5, 1, -5, 2, -5, 3, -5, 4, -5, 5, -5, 6, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, 6, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, 6, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4] }, { bounds: [-121.11366172632106, -159.02759596269382, 223.0275959626938, 185.11366172632106], cells: [0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, 6, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5] }], [{ bounds: [-176.72, -79.04000000000002, 208.72, 111.04], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3] }, { bounds: [-176.7224752547533, -121.11613640671554, 215.9364131847198, 191.0300881729648], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, 3, -4, -3, 3, 4, 2, 4, 4, 4, -6, -2, 5, 4, 1, 4, -5, -3, 0, 4, 4, 5, 3, 5, -3, -4, -2, -4, -1, -4, 2, 5, -4, -4, 0, -4, -5, -4, 1, 5, -1, 4, 0, 5] }, { bounds: [-176.72247525475325, -159.0300881729648, 215.9364131847198, 153.11613640671553], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, -3, -4, 3, 3, -4, 2, -4, 4, -4, -6, 2, 5, -4, 1, -4, -5, 3, 0, -4, 4, -5, 3, -5, -3, 4, -2, 4, -1, 4, 2, -5, -4, 4, 0, 4, -5, 4, 1, -5, -1, -4, 0, -5] }, { bounds: [-208.72, -79.04000000000002, 208.72, 111.04], cells: [-4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -7, -1, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -7, 0, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -7, 1, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3] }, { bounds: [-176.72, -111.04000000000002, 208.72, 111.04], cells: [-3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, 6, -3, -6, -2, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3] }, { bounds: [-176.72, -79.04000000000002, 240.72, 111.04], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, 6, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, 7, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, 7, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, 7, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, 7, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, 3] }, { bounds: [-176.72, -79.04000000000002, 208.72, 143.04000000000002], cells: [-3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, 6, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4] }], [{ bounds: [-121.11366172632108, -121.11366172632106, 191.02759596269385, 191.02759596269382], cells: [-4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5] }, { bounds: [-121.11613640671557, -176.72247525475328, 191.03008817296484, 215.9364131847198], cells: [-4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5, 2, 6, 3, 6, -4, -5, -3, -5, 1, -4, 1, 6, -2, -5, -1, -5, -1, 5, 0, 6, 0, -5, -2, 4, -2, -6, -1, 6, -1, -6, -2, 5, 1, -5, 2, -4, -3, 3, 0, -6, -2, 6, -3, 4, 3, -3, -3, 5, 2, -5, 1, -6] }, { bounds: [-176.7224752547533, -121.11613640671554, 215.9364131847198, 191.0300881729648], cells: [-4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5, 6, 2, 6, 3, -5, -4, -5, -3, -4, 1, 6, 1, -5, -2, -5, -1, 5, -1, 6, 0, -5, 0, 4, -2, -6, -2, 6, -1, 5, -2, -6, -1, -5, 1, -4, 2, 3, -3, 6, -2, -6, 0, 4, -3, -3, 3, 5, -3, -5, 2, -6, 1] }, { bounds: [-153.11366172632108, -153.11366172632106, 191.02759596269385, 191.02759596269382], cells: [-5, -5, -4, -5, -3, -5, -2, -5, -1, -5, -5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5] }, { bounds: [-121.11366172632108, -153.11366172632106, 223.02759596269385, 191.02759596269382], cells: [-4, -5, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, 6, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5] }, { bounds: [-121.11366172632108, -121.11366172632106, 223.02759596269385, 223.02759596269382], cells: [-4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, 6, 3, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, 6, 4, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5, 5, 5, 6, 5, 1, 6, 2, 6, 3, 6, 4, 6, 5, 6] }, { bounds: [-153.11366172632108, -121.11366172632106, 191.02759596269385, 223.02759596269382], cells: [-5, -4, -4, -4, -3, -4, -2, -4, -1, -4, 0, -4, -5, -3, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 5, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 5, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, 5, 4, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5, -1, 6, 0, 6, 1, 6, 2, 6, 3, 6] }], [{ bounds: [-79.04, -176.72, 111.04000000000002, 208.72], cells: [-1, -6, 0, -6, 1, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6] }, { bounds: [-159.03008817296475, -176.72247525475325, 153.11613640671553, 215.9364131847198], cells: [-1, -6, 0, -6, 1, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6, -3, 6, 3, -4, -4, 3, -4, 2, -4, 4, 2, -6, -4, 5, -4, 1, 3, -5, -4, 0, -5, 4, -5, 3, 4, -3, 4, -2, 4, -1, -5, 2, 4, -4, 4, 0, 4, -5, -5, 1, -4, -1, -5, 0] }, { bounds: [-121.11613640671557, -176.72247525475328, 191.03008817296484, 215.9364131847198], cells: [-1, -6, 0, -6, 1, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6, 3, 6, -3, -4, 4, 3, 4, 2, 4, 4, -2, -6, 4, 5, 4, 1, -3, -5, 4, 0, 5, 4, 5, 3, -4, -3, -4, -2, -4, -1, 5, 2, -4, -4, -4, 0, -4, -5, 5, 1, 4, -1, 5, 0] }, { bounds: [-79.04, -208.72, 111.04000000000002, 208.72], cells: [-1, -7, 0, -7, 1, -7, -2, -6, -1, -6, 0, -6, 1, -6, 2, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6] }, { bounds: [-79.04, -176.72, 143.04000000000002, 208.72], cells: [-1, -6, 0, -6, 1, -6, 2, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, 3, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, 4, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, 4, 5, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6, 3, 6] }, { bounds: [-79.04, -176.72, 111.04000000000002, 240.72], cells: [-1, -6, 0, -6, 1, -6, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -3, 6, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6, 3, 6, -2, 7, -1, 7, 0, 7, 1, 7, 2, 7] }, { bounds: [-111.04, -176.72, 111.04000000000002, 208.72], cells: [-2, -6, -1, -6, 0, -6, 1, -6, -3, -5, -2, -5, -1, -5, 0, -5, 1, -5, 2, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, 3, 5, -3, 6, -2, 6, -1, 6, 0, 6, 1, 6, 2, 6] }], [{ bounds: [-159.0275959626938, -121.11366172632108, 153.11366172632106, 191.02759596269385], cells: [0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5] }, { bounds: [-183.93641318471978, -121.11613640671554, 208.72247525475328, 191.03008817296484], cells: [0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, -6, 2, -6, 3, 5, -4, 5, -3, -6, 1, 4, 1, 5, -2, 5, -1, -5, -1, -6, 0, 5, 0, -4, -2, 6, -2, -6, -1, -5, -2, 6, -1, 5, 1, 4, 2, -3, -3, -6, -2, 6, 0, -4, -3, 3, 3, -5, -3, 5, 2, 6, 1] }, { bounds: [-159.03008817296475, -176.72247525475325, 153.11613640671553, 215.9364131847198], cells: [0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, -3, 6, -2, 6, 4, -5, 3, -5, -1, -4, -1, 6, 2, -5, 1, -5, 1, 5, 0, 6, 0, -5, 2, 4, 2, -6, 1, 6, 1, -6, 2, 5, -1, -5, -2, -4, 3, 3, 0, -6, 2, 6, 3, 4, -3, -3, 3, 5, -2, -5, -1, -6] }, { bounds: [-159.0275959626938, -153.11366172632108, 185.11366172632106, 191.02759596269385], cells: [1, -5, 2, -5, 3, -5, 4, -5, 5, -5, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5] }, { bounds: [-159.0275959626938, -121.11366172632108, 185.11366172632106, 223.02759596269385], cells: [0, -4, 1, -4, 2, -4, 3, -4, 4, -4, 5, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, 5, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, 5, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, 5, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, 2, 4, 3, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, 1, 5, 2, 5, -3, 6, -2, 6, -1, 6, 0, 6, 1, 6] }, { bounds: [-191.02759596269382, -121.11366172632108, 153.11366172632106, 223.02759596269385], cells: [0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -6, 3, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -6, 4, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -6, 5, -5, 5, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5, -5, 6, -4, 6, -3, 6, -2, 6, -1, 6] }, { bounds: [-191.02759596269382, -153.11366172632108, 153.11366172632106, 191.02759596269385], cells: [-1, -5, 0, -5, 1, -5, 2, -5, 3, -5, 4, -5, -3, -4, -2, -4, -1, -4, 0, -4, 1, -4, 2, -4, 3, -4, 4, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -5, -2, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -6, -1, -5, -1, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -6, 0, -5, 0, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -6, 1, -5, 1, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -6, 2, -5, 2, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -6, 3, -5, 3, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -5, 4, -4, 4, -3, 4, -2, 4, -1, 4, 0, 4, 1, 4, -4, 5, -3, 5, -2, 5, -1, 5, 0, 5] }]] };

// src/shared/generated/ship-navigation-masks-64.json
var ship_navigation_masks_64_default = { cutter: [[{ bounds: [-44.56, 1.639999999999997, 108.56, 62.36], cells: [-1, 0, 0, 0, 1, 0] }, { bounds: [-46.42784958007972, -34.16447789755643, 108.5663303326195, 86.14265096979601], cells: [-1, 0, 0, 0, 1, 0, -1, -1, 0, -1, 0, 1, 1, 1] }, { bounds: [-46.42784958007972, -22.142650969795994, 108.56633033261951, 98.16447789755642], cells: [-1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 0, -1, 1, -1] }, { bounds: [-44.56, 1.639999999999997, 172.56, 62.36], cells: [-1, 0, 0, 0, 1, 0, 2, 0] }, { bounds: [-44.56, 1.639999999999997, 108.56, 126.36], cells: [-1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-108.56, 1.639999999999997, 108.56, 62.36], cells: [-2, 0, -1, 0, 0, 0, 1, 0] }, { bounds: [-44.56, -62.36, 108.56, 62.36], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0] }], [{ bounds: [-34.15804181866329, -34.158041818663285, 86.13609516764208, 86.13609516764208], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-34.164477897556445, -46.42784958007973, 86.14265096979601, 108.5663303326195], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-46.42784958007972, -34.16447789755644, 108.56633033261949, 86.14265096979601], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-34.15804181866329, -34.158041818663285, 150.13609516764208, 150.13609516764208], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-98.15804181866329, -34.158041818663285, 86.13609516764208, 150.13609516764208], cells: [-1, -1, 0, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-98.15804181866329, -98.15804181866329, 86.13609516764208, 86.13609516764208], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-34.15804181866329, -98.15804181866329, 150.13609516764208, 86.13609516764208], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 0, 1, 1, 1] }], [{ bounds: [1.6399999999999935, -44.56, 62.36, 108.56], cells: [0, -1, 0, 0, 0, 1] }, { bounds: [-22.14265096979599, -46.42784958007972, 98.16447789755642, 108.56633033261951], cells: [0, -1, 0, 0, 0, 1, 1, -1, 1, 0, -1, 0, -1, 1] }, { bounds: [-34.164477897556445, -46.42784958007973, 86.14265096979601, 108.5663303326195], cells: [0, -1, 0, 0, 0, 1, -1, -1, -1, 0, 1, 0, 1, 1] }, { bounds: [1.6399999999999935, -44.56, 62.36, 172.56], cells: [0, -1, 0, 0, 0, 1, 0, 2] }, { bounds: [-62.36, -44.56, 62.36, 108.56], cells: [-1, -1, 0, -1, -1, 0, 0, 0, -1, 1, 0, 1] }, { bounds: [1.6399999999999935, -108.56, 62.36, 108.56], cells: [0, -2, 0, -1, 0, 0, 0, 1] }, { bounds: [1.6399999999999935, -44.56, 126.36, 108.56], cells: [0, -1, 1, -1, 0, 0, 1, 0, 0, 1, 1, 1] }], [{ bounds: [-22.136095167642075, -34.15804181866329, 98.15804181866329, 86.13609516764208], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-44.56633033261951, -34.16447789755645, 110.42784958007975, 86.14265096979601], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-22.14265096979599, -46.42784958007972, 98.16447789755642, 108.56633033261951], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-86.13609516764208, -34.15804181866329, 98.15804181866329, 150.13609516764208], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, -2, 2, -1, 2] }, { bounds: [-86.13609516764208, -98.15804181866329, 98.15804181866329, 86.13609516764208], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-22.136095167642075, -98.15804181866329, 162.1580418186633, 86.13609516764208], cells: [1, -2, 2, -2, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-22.136095167642075, -34.15804181866329, 162.1580418186633, 150.13609516764208], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }], [{ bounds: [-44.56, 1.6399999999999935, 108.56, 62.36], cells: [-1, 0, 0, 0, 1, 0] }, { bounds: [-44.56633033261951, -22.142650969795994, 110.42784958007972, 98.16447789755644], cells: [-1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, -1, -1, -1] }, { bounds: [-44.56633033261951, -34.16447789755645, 110.42784958007974, 86.14265096979601], cells: [-1, 0, 0, 0, 1, 0, 0, -1, 1, -1, 0, 1, -1, 1] }, { bounds: [-108.56, 1.6399999999999935, 108.56, 62.36], cells: [-2, 0, -1, 0, 0, 0, 1, 0] }, { bounds: [-44.56, -62.360000000000014, 108.56, 62.36], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0] }, { bounds: [-44.56, 1.6399999999999935, 172.56, 62.36], cells: [-1, 0, 0, 0, 1, 0, 2, 0] }, { bounds: [-44.56, 1.6399999999999935, 108.56, 126.36], cells: [-1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }], [{ bounds: [-22.13609516764209, -22.136095167642075, 98.15804181866329, 98.15804181866329], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-22.142650969796016, -44.56633033261951, 98.16447789755644, 110.42784958007972], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-44.56633033261951, -22.142650969795994, 110.42784958007974, 98.16447789755644], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-86.13609516764208, -86.13609516764208, 98.15804181866329, 98.15804181866329], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-22.13609516764209, -86.13609516764208, 162.1580418186633, 98.15804181866329], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 0, 1, 1, 1] }, { bounds: [-22.13609516764209, -22.136095167642075, 162.1580418186633, 162.1580418186633], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-86.13609516764208, -22.136095167642075, 98.15804181866329, 162.1580418186633], cells: [-1, -1, 0, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }], [{ bounds: [1.639999999999997, -44.56, 62.360000000000014, 108.56], cells: [0, -1, 0, 0, 0, 1] }, { bounds: [-34.16447789755643, -44.56633033261951, 86.14265096979598, 110.42784958007974], cells: [0, -1, 0, 0, 0, 1, -1, 0, -1, 1, 1, 0, 1, -1] }, { bounds: [-22.142650969796016, -44.56633033261951, 98.16447789755644, 110.42784958007972], cells: [0, -1, 0, 0, 0, 1, 1, 0, 1, 1, -1, 0, -1, -1] }, { bounds: [1.639999999999997, -108.56, 62.360000000000014, 108.56], cells: [0, -2, 0, -1, 0, 0, 0, 1] }, { bounds: [1.639999999999997, -44.56, 126.36000000000001, 108.56], cells: [0, -1, 1, -1, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [1.639999999999997, -44.56, 62.360000000000014, 172.56], cells: [0, -1, 0, 0, 0, 1, 0, 2] }, { bounds: [-62.36, -44.56, 62.360000000000014, 108.56], cells: [-1, -1, 0, -1, -1, 0, 0, 0, -1, 1, 0, 1] }], [{ bounds: [-34.15804181866328, -22.13609516764209, 86.13609516764207, 98.15804181866329], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-46.42784958007972, -22.14265096979601, 108.56633033261951, 98.16447789755642], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-34.16447789755643, -44.56633033261951, 86.14265096979598, 110.42784958007974], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-34.15804181866328, -86.13609516764208, 150.13609516764205, 98.15804181866329], cells: [1, -2, 2, -2, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-34.15804181866328, -22.13609516764209, 150.13609516764205, 162.1580418186633], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }, { bounds: [-98.15804181866328, -22.13609516764209, 86.13609516764207, 162.1580418186633], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, -2, 2, -1, 2] }, { bounds: [-98.15804181866328, -86.13609516764208, 86.13609516764207, 98.15804181866329], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }]], transport: [[{ bounds: [-89.44000000000001, -20.800000000000004, 153.44, 84.80000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-92.99097602869695, -74.78266872567796, 153.4438685270237, 117.87498679369767], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, -2, 0, -2] }, { bounds: [-92.99097602869695, -53.874986793697666, 153.44386852702368, 138.78266872567798], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, -1, -1, 2, 0, 2] }, { bounds: [-89.44000000000001, -20.800000000000004, 217.44, 84.80000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -20.800000000000004, 153.44, 148.8], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-153.44, -20.800000000000004, 153.44, 84.80000000000001], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-89.44000000000001, -84.80000000000001, 153.44, 84.80000000000001], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }], [{ bounds: [-74.7787808134182, -74.77878081341818, 117.87104750729435, 117.87104750729434], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-74.782668725678, -92.99097602869696, 117.8749867936977, 153.4438685270237], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 1, 2, 0, 2, 1, -2] }, { bounds: [-92.99097602869695, -74.78266872567796, 153.44386852702368, 117.87498679369767], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 2, 0, -2, 1] }, { bounds: [-74.7787808134182, -74.77878081341818, 181.87104750729435, 181.87104750729435], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-138.7787808134182, -74.77878081341818, 117.87104750729435, 181.87104750729435], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-138.7787808134182, -138.77878081341817, 117.87104750729435, 117.87104750729434], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-74.7787808134182, -138.77878081341817, 181.87104750729435, 117.87104750729434], cells: [0, -3, 1, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-20.800000000000008, -89.44000000000001, 84.80000000000001, 153.44], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-53.87498679369767, -92.99097602869696, 138.78266872567798, 153.4438685270237], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, -1, 2, 2, -1, 2, 0] }, { bounds: [-74.782668725678, -92.99097602869696, 117.8749867936977, 153.4438685270237], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, 1, 2, -2, -1, -2, 0] }, { bounds: [-20.800000000000008, -89.44000000000001, 84.80000000000001, 217.44], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 0, 3] }, { bounds: [-84.80000000000001, -89.44000000000001, 84.80000000000001, 153.44], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-20.800000000000008, -153.44, 84.80000000000001, 153.44], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-20.800000000000008, -89.44000000000001, 148.8, 153.44], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }], [{ bounds: [-53.871047507294335, -74.7787808134182, 138.77878081341817, 117.87104750729435], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-89.44386852702367, -74.78266872567798, 156.990976028697, 117.8749867936977], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, -2, 1, -2, 0, 2, 1] }, { bounds: [-53.87498679369767, -92.99097602869696, 138.78266872567798, 153.4438685270237], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, -1, -2] }, { bounds: [-117.87104750729434, -74.7787808134182, 138.77878081341817, 181.87104750729435], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-117.87104750729434, -138.7787808134182, 138.77878081341817, 117.87104750729435], cells: [-1, -3, 0, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-53.871047507294335, -138.7787808134182, 202.7787808134182, 117.87104750729435], cells: [1, -3, 2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-53.871047507294335, -74.7787808134182, 202.7787808134182, 181.87104750729435], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-89.44000000000001, -20.80000000000001, 153.44, 84.80000000000001], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44386852702368, -53.874986793697666, 156.99097602869696, 138.78266872567798], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, -1, 1, 2, 0, 2] }, { bounds: [-89.44386852702367, -74.78266872567798, 156.990976028697, 117.8749867936977], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, 1, 1, -2, 0, -2] }, { bounds: [-153.44, -20.80000000000001, 153.44, 84.80000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -84.80000000000001, 153.44, 84.80000000000001], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -20.80000000000001, 217.44, 84.80000000000001], cells: [-1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-89.44000000000001, -20.80000000000001, 153.44, 148.8], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-53.871047507294364, -53.871047507294335, 138.7787808134182, 138.77878081341817], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }, { bounds: [-53.8749867936977, -89.44386852702368, 138.78266872567798, 156.99097602869696], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, -1, -2, 0, -2, -1, 2] }, { bounds: [-89.44386852702368, -53.874986793697666, 156.99097602869696, 138.78266872567798], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, -2, -1, -2, 0, 2, -1] }, { bounds: [-117.87104750729436, -117.87104750729434, 138.7787808134182, 138.77878081341817], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }, { bounds: [-53.871047507294364, -117.87104750729434, 202.7787808134182, 138.77878081341817], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }, { bounds: [-53.871047507294364, -53.871047507294335, 202.7787808134182, 202.7787808134182], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-117.87104750729436, -53.871047507294335, 138.7787808134182, 202.7787808134182], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3] }], [{ bounds: [-20.800000000000004, -89.44000000000001, 84.80000000000001, 153.44], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-74.78266872567796, -89.44386852702367, 117.87498679369767, 156.99097602869696], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 1, -2, -2, 1, -2, 0] }, { bounds: [-53.8749867936977, -89.44386852702368, 138.78266872567798, 156.99097602869696], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, -2, 2, 1, 2, 0] }, { bounds: [-20.800000000000004, -153.44, 84.80000000000001, 153.44], cells: [0, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-20.800000000000004, -89.44000000000001, 148.8, 153.44], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-20.800000000000004, -89.44000000000001, 84.80000000000001, 217.44], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-84.80000000000001, -89.44000000000001, 84.80000000000001, 153.44], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-74.77878081341817, -53.871047507294364, 117.87104750729432, 138.7787808134182], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-92.99097602869696, -53.8749867936977, 153.44386852702368, 138.78266872567798], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 2, -1, 2, 0, -2, -1] }, { bounds: [-74.78266872567796, -89.44386852702367, 117.87498679369767, 156.99097602869696], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, -2, 0, -2, 1, 2] }, { bounds: [-74.77878081341817, -117.87104750729436, 181.87104750729432, 138.7787808134182], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-74.77878081341817, -53.871047507294364, 181.87104750729432, 202.7787808134182], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, 0, 3, 1, 3] }, { bounds: [-138.77878081341817, -53.871047507294364, 117.87104750729432, 202.7787808134182], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3, -1, 3] }, { bounds: [-138.77878081341817, -117.87104750729436, 117.87104750729432, 138.7787808134182], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }]], warship: [[{ bounds: [-80.2, -15.520000000000003, 144.2, 79.52000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-83.31463361123781, -66.15859516874397, 144.20421831744721, 111.34169835189698], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, -2] }, { bounds: [-83.31463361123784, -47.341698351896966, 144.20421831744721, 130.15859516874397], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, -1, -1, 2] }, { bounds: [-80.2, -15.520000000000003, 208.2, 79.52000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-80.2, -15.520000000000003, 144.2, 143.52], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-144.2, -15.520000000000003, 144.2, 79.52000000000001], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-80.2, -79.52000000000001, 144.2, 79.52000000000001], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }], [{ bounds: [-66.15434082464209, -66.15434082464208, 111.33738084913064, 111.33738084913062], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-66.15859516874397, -83.31463361123784, 111.34169835189698, 144.20421831744721], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, -2, 1, 2, 0, 2, 1, -2] }, { bounds: [-83.31463361123782, -66.15859516874397, 144.20421831744721, 111.341698351897], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -2, 0, 2, 1, 2, 0, -2, 1] }, { bounds: [-66.15434082464209, -66.15434082464208, 175.33738084913062, 175.33738084913062], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-130.1543408246421, -66.15434082464208, 111.33738084913064, 175.33738084913062], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-130.1543408246421, -130.15434082464208, 111.33738084913064, 111.33738084913062], cells: [-2, -3, -3, -2, -2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-66.15434082464209, -130.15434082464208, 175.33738084913062, 111.33738084913062], cells: [0, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-15.520000000000007, -80.2, 79.52000000000001, 144.2], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-47.341698351896966, -83.3146336112378, 130.15859516874397, 144.2042183174472], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, -1, 2, 2, -1] }, { bounds: [-66.15859516874397, -83.31463361123784, 111.34169835189698, 144.2042183174472], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, 1, 2, -2, -1] }, { bounds: [-15.520000000000007, -80.2, 79.52000000000001, 208.2], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 0, 3] }, { bounds: [-79.52000000000001, -80.2, 79.52000000000001, 144.2], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-15.520000000000007, -144.2, 79.52000000000001, 144.2], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-15.520000000000007, -80.2, 143.52, 144.2], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }], [{ bounds: [-47.337380849130625, -66.15434082464209, 130.15434082464208, 111.33738084913064], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-80.20421831744721, -66.15859516874397, 147.3146336112378, 111.34169835189698], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 0, -2, 1, -2, 0, 2, 1] }, { bounds: [-47.341698351896966, -83.3146336112378, 130.15859516874397, 144.2042183174472], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, -2, -1, 2, 0, 2, -1, -2] }, { bounds: [-111.33738084913062, -66.15434082464209, 130.15434082464208, 175.33738084913062], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-111.33738084913062, -130.1543408246421, 130.15434082464208, 111.33738084913064], cells: [0, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-47.337380849130625, -130.1543408246421, 194.15434082464208, 111.33738084913064], cells: [2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-47.337380849130625, -66.15434082464209, 194.15434082464208, 175.33738084913062], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-80.2, -15.52000000000001, 144.2, 79.52000000000001], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-80.20421831744721, -47.341698351896966, 147.3146336112378, 130.15859516874397], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, -1, 1, 2] }, { bounds: [-80.20421831744721, -66.15859516874397, 147.3146336112378, 111.34169835189698], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, 1, 1, -2] }, { bounds: [-144.2, -15.52000000000001, 144.2, 79.52000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-80.2, -79.52000000000001, 144.2, 79.52000000000001], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-80.2, -15.52000000000001, 208.2, 79.52000000000001], cells: [-1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-80.2, -15.52000000000001, 144.2, 143.52], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-47.33738084913065, -47.337380849130625, 130.1543408246421, 130.15434082464208], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-47.341698351897, -80.20421831744723, 130.15859516874403, 147.3146336112378], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 0, 2, -1, -2, 0, -2, -1, 2] }, { bounds: [-80.20421831744721, -47.341698351896966, 147.3146336112378, 130.15859516874397], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 0, -2, -1, -2, 0, 2, -1] }, { bounds: [-111.33738084913065, -111.33738084913062, 130.1543408246421, 130.15434082464208], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-47.33738084913065, -111.33738084913062, 194.1543408246421, 130.15434082464208], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-47.33738084913065, -47.337380849130625, 194.1543408246421, 194.15434082464208], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 3, 2, 2, 3] }, { bounds: [-111.33738084913065, -47.337380849130625, 130.1543408246421, 194.15434082464208], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 0, 3] }], [{ bounds: [-15.520000000000003, -80.2, 79.52000000000001, 144.2], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-66.15859516874397, -80.20421831744721, 111.34169835189698, 147.3146336112378], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 1, -2, -2, 1] }, { bounds: [-47.341698351897, -80.20421831744723, 130.15859516874403, 147.3146336112378], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, -2, 2, 1] }, { bounds: [-15.520000000000003, -144.2, 79.52000000000001, 144.2], cells: [0, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-15.520000000000003, -80.2, 143.52, 144.2], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-15.520000000000003, -80.2, 79.52000000000001, 208.2], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-79.52000000000001, -80.2, 79.52000000000001, 144.2], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-66.15434082464208, -47.33738084913065, 111.33738084913061, 130.1543408246421], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }, { bounds: [-83.31463361123782, -47.341698351896994, 144.2042183174472, 130.15859516874403], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, -2, 0, 2, -1, 2, 0, -2, -1] }, { bounds: [-66.15859516874397, -80.20421831744721, 111.34169835189698, 147.3146336112378], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, -2, 0, -2, 1, 2] }, { bounds: [-66.15434082464208, -111.33738084913065, 175.33738084913062, 130.1543408246421], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }, { bounds: [-66.15434082464208, -47.33738084913065, 175.33738084913062, 194.1543408246421], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, 0, 3] }, { bounds: [-130.15434082464208, -47.33738084913065, 111.33738084913061, 194.1543408246421], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3] }, { bounds: [-130.15434082464208, -111.33738084913065, 111.33738084913061, 130.1543408246421], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }]], bombardShip: [[{ bounds: [-89.44000000000001, -14.200000000000003, 153.44, 78.2], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-92.16919982978644, -72.16941850058983, 153.44400309757765, 117.87523632275817], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, -2] }, { bounds: [-92.16919982978645, -53.87523632275817, 153.44400309757765, 136.16941850058987], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, -1, -1, 2] }, { bounds: [-89.44000000000001, -14.200000000000003, 217.44, 78.2], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -14.200000000000003, 153.44, 142.2], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-153.44, -14.200000000000003, 153.44, 78.2], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-89.44000000000001, -78.2, 153.44, 78.2], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }], [{ bounds: [-72.16531415015271, -72.1653141501527, 117.87104750729435, 117.87104750729434], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.16941850058984, -92.16919982978644, 117.87523632275817, 153.44400309757765], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, -2, 1, 2, 0, 2, 1, -2] }, { bounds: [-92.16919982978642, -72.16941850058983, 153.44400309757768, 117.87523632275817], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -2, 0, 2, 1, 2, 0, -2, 1] }, { bounds: [-72.16531415015271, -72.1653141501527, 181.87104750729435, 181.87104750729435], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-136.1653141501527, -72.1653141501527, 117.87104750729435, 181.87104750729435], cells: [-1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-136.1653141501527, -136.1653141501527, 117.87104750729435, 117.87104750729434], cells: [-2, -3, -3, -2, -2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.16531415015271, -136.1653141501527, 181.87104750729435, 117.87104750729434], cells: [0, -3, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-14.200000000000006, -89.44000000000001, 78.2, 153.44], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-53.87523632275817, -92.16919982978645, 136.16941850058987, 153.44400309757765], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, -1, 2, 2, -1] }, { bounds: [-72.16941850058984, -92.16919982978644, 117.87523632275817, 153.44400309757765], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, 1, 2, -2, -1] }, { bounds: [-14.200000000000006, -89.44000000000001, 78.2, 217.44], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 0, 3] }, { bounds: [-78.20000000000002, -89.44000000000001, 78.2, 153.44], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-14.200000000000006, -153.44, 78.2, 153.44], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-14.200000000000006, -89.44000000000001, 142.2, 153.44], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }], [{ bounds: [-53.871047507294335, -72.16531415015271, 136.1653141501527, 117.87104750729435], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-89.44400309757768, -72.16941850058984, 156.16919982978644, 117.8752363227582], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 0, -2, 1, -2, 0, 2, 1] }, { bounds: [-53.87523632275817, -92.16919982978645, 136.16941850058987, 153.44400309757765], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, -2, -1, 2, 0, 2, -1, -2] }, { bounds: [-117.87104750729434, -72.16531415015271, 136.1653141501527, 181.87104750729435], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-117.87104750729434, -136.1653141501527, 136.1653141501527, 117.87104750729435], cells: [0, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-53.871047507294335, -136.1653141501527, 200.1653141501527, 117.87104750729435], cells: [2, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-53.871047507294335, -72.16531415015271, 200.1653141501527, 181.87104750729435], cells: [1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-89.44000000000001, -14.20000000000001, 153.44, 78.2], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44400309757768, -53.87523632275818, 156.16919982978644, 136.16941850058987], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, -1, 1, 2] }, { bounds: [-89.44400309757768, -72.16941850058984, 156.16919982978644, 117.8752363227582], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, 1, 1, -2] }, { bounds: [-153.44, -14.20000000000001, 153.44, 78.2], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -78.20000000000002, 153.44, 78.2], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-89.44000000000001, -14.20000000000001, 217.44, 78.2], cells: [-1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-89.44000000000001, -14.20000000000001, 153.44, 142.2], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-53.871047507294364, -53.871047507294335, 136.1653141501527, 136.1653141501527], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-53.8752363227582, -89.44400309757769, 136.16941850058984, 156.16919982978646], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 0, 2, -1, -2, 0, -2, -1, 2] }, { bounds: [-89.44400309757768, -53.87523632275818, 156.16919982978644, 136.16941850058987], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 0, -2, -1, -2, 0, 2, -1] }, { bounds: [-117.87104750729436, -117.87104750729434, 136.1653141501527, 136.1653141501527], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-53.871047507294364, -117.87104750729434, 200.1653141501527, 136.1653141501527], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2] }, { bounds: [-53.871047507294364, -53.871047507294335, 200.1653141501527, 200.1653141501527], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 3, 2, 2, 3] }, { bounds: [-117.87104750729436, -53.871047507294335, 136.1653141501527, 200.1653141501527], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 0, 3] }], [{ bounds: [-14.200000000000003, -89.44000000000001, 78.20000000000002, 153.44], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-72.16941850058983, -89.44400309757768, 117.87523632275817, 156.16919982978644], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 1, -2, -2, 1] }, { bounds: [-53.8752363227582, -89.44400309757769, 136.16941850058984, 156.16919982978646], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, -2, 2, 1] }, { bounds: [-14.200000000000003, -153.44, 78.20000000000002, 153.44], cells: [0, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-14.200000000000003, -89.44000000000001, 142.20000000000002, 153.44], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-14.200000000000003, -89.44000000000001, 78.20000000000002, 217.44], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-78.2, -89.44000000000001, 78.20000000000002, 153.44], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-72.16531415015268, -53.871047507294364, 117.87104750729432, 136.1653141501527], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }, { bounds: [-92.16919982978642, -53.875236322758205, 153.44400309757765, 136.16941850058984], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, -2, 0, 2, -1, 2, 0, -2, -1] }, { bounds: [-72.16941850058983, -89.44400309757768, 117.87523632275817, 156.16919982978644], cells: [-1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, -2, 0, -2, 1, 2] }, { bounds: [-72.16531415015268, -117.87104750729436, 181.87104750729432, 136.1653141501527], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }, { bounds: [-72.16531415015268, -53.871047507294364, 181.87104750729432, 200.1653141501527], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, 0, 3] }, { bounds: [-136.16531415015268, -53.871047507294364, 117.87104750729432, 200.1653141501527], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -2, 3] }, { bounds: [-136.16531415015268, -117.87104750729436, 117.87104750729432, 136.1653141501527], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2] }]], fireShip: [[{ bounds: [-72.28, -7.600000000000001, 136.28, 71.6], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-74.61576632279093, -57.42269352701177, 136.28468141130227, 105.74199281283092], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, -2, -1, 2, 1] }, { bounds: [-74.61576632279093, -41.74199281283092, 136.28468141130227, 121.42269352701179], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, -2, 1, 2, -1] }, { bounds: [-72.28, -7.600000000000001, 200.28, 71.6], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-72.28, -7.600000000000001, 136.28, 135.6], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-136.28, -7.600000000000001, 136.28, 71.6], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.28, -71.6, 136.28, 71.6], cells: [-1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }], [{ bounds: [-57.41789512172606, -57.41789512172605, 105.73709514213319, 105.73709514213317], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-57.422693527011795, -74.61576632279093, 105.74199281283093, 136.28468141130227], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, -1, -2, 0, -2, 1, 2, 0, 2, 1, -1, -1, 1] }, { bounds: [-74.61576632279095, -57.42269352701178, 136.28468141130227, 105.74199281283092], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, -2, -1, -2, 0, 2, 1, 2, 0, -1, 1, 1, -1] }, { bounds: [-57.41789512172606, -57.41789512172605, 169.73709514213317, 169.73709514213317], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-121.41789512172606, -57.41789512172605, 105.73709514213319, 169.73709514213317], cells: [-2, -1, -1, -1, 0, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-121.41789512172606, -121.41789512172605, 105.73709514213319, 105.73709514213317], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-57.41789512172606, -121.41789512172605, 169.73709514213317, 105.73709514213317], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-7.600000000000005, -72.28, 71.6, 136.28], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-41.74199281283093, -74.61576632279092, 121.42269352701176, 136.28468141130227], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, 1, -2, -1, 2] }, { bounds: [-57.42269352701178, -74.61576632279092, 105.74199281283093, 136.28468141130227], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, -1, -2, 1, 2] }, { bounds: [-7.600000000000005, -72.28, 71.6, 200.28], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 0, 3] }, { bounds: [-71.6, -72.28, 71.6, 136.28], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }, { bounds: [-7.600000000000005, -136.28, 71.6, 136.28], cells: [0, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-7.600000000000005, -72.28, 135.6, 136.28], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }], [{ bounds: [-41.73709514213317, -57.41789512172606, 121.41789512172605, 105.73709514213319], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-72.28468141130227, -57.42269352701178, 138.61576632279096, 105.74199281283093], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 2, -1, 2, 0, -2, 1, -2, 0, 1, 1, -1, -1] }, { bounds: [-41.74199281283093, -74.61576632279095, 121.42269352701176, 136.28468141130227], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, -2, 0, -2, -1, 2, 0, 2, -1, -1, 1, 1] }, { bounds: [-105.73709514213317, -57.41789512172606, 121.41789512172605, 169.73709514213317], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, -2, 2, -1, 2] }, { bounds: [-105.73709514213317, -121.41789512172606, 121.41789512172605, 105.73709514213319], cells: [-1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1] }, { bounds: [-41.73709514213317, -121.41789512172606, 185.41789512172605, 105.73709514213319], cells: [1, -2, 2, -2, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-41.73709514213317, -57.41789512172606, 185.41789512172605, 169.73709514213317], cells: [0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-72.28, -7.6000000000000085, 136.28, 71.6], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.28468141130227, -41.74199281283092, 138.61576632279096, 121.42269352701175], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -2, -1] }, { bounds: [-72.28468141130227, -57.42269352701178, 138.61576632279096, 105.74199281283093], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, -1, -2, 1] }, { bounds: [-136.28, -7.6000000000000085, 136.28, 71.6], cells: [-2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.28, -71.60000000000001, 136.28, 71.6], cells: [-1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1] }, { bounds: [-72.28, -7.6000000000000085, 200.28, 71.6], cells: [-1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-72.28, -7.6000000000000085, 136.28, 135.6], cells: [-1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-41.7370951421332, -41.73709514213317, 121.41789512172608, 121.41789512172605], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-41.74199281283096, -72.28468141130229, 121.4226935270118, 138.61576632279096], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 2, 0, 2, -1, -2, 0, -2, -1, 1, 1, -1] }, { bounds: [-72.28468141130227, -41.74199281283092, 138.61576632279096, 121.42269352701175], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 2, 0, -2, -1, -2, 0, 1, -1, -1, 1] }, { bounds: [-105.7370951421332, -105.73709514213317, 121.41789512172608, 121.41789512172605], cells: [-2, -2, -1, -2, -2, -1, -1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1] }, { bounds: [-41.7370951421332, -105.73709514213317, 185.41789512172608, 121.41789512172605], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, 0, 1, 1, 1, 2, 1] }, { bounds: [-41.7370951421332, -41.73709514213317, 185.41789512172608, 185.41789512172605], cells: [-1, -1, 0, -1, -1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2] }, { bounds: [-105.7370951421332, -41.73709514213317, 121.41789512172608, 185.41789512172605], cells: [-2, -1, -1, -1, 0, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-7.600000000000001, -72.28, 71.60000000000001, 136.28], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-57.42269352701176, -72.28468141130227, 105.74199281283092, 138.61576632279096], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, -1, 2, 1, -2] }, { bounds: [-41.74199281283096, -72.28468141130229, 121.4226935270118, 138.61576632279096], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2, 1, 2, -1, -2] }, { bounds: [-7.600000000000001, -136.28, 71.60000000000001, 136.28], cells: [0, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 2] }, { bounds: [-7.600000000000001, -72.28, 135.60000000000002, 136.28], cells: [0, -2, 1, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2] }, { bounds: [-7.600000000000001, -72.28, 71.60000000000001, 200.28], cells: [0, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 0, 3] }, { bounds: [-71.6, -72.28, 71.60000000000001, 136.28], cells: [-1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2] }], [{ bounds: [-57.41789512172604, -41.7370951421332, 105.73709514213316, 121.41789512172608], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-74.61576632279093, -41.74199281283095, 136.28468141130227, 121.42269352701179], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, -2, 1, -2, 0, 2, -1, 2, 0, -1, -1, 1, 1] }, { bounds: [-57.42269352701176, -72.28468141130227, 105.74199281283092, 138.61576632279096], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, -1, 2, 0, 2, 1, -2, 0, -2, 1, 1, -1, -1] }, { bounds: [-57.41789512172604, -105.7370951421332, 169.73709514213317, 121.41789512172608], cells: [1, -2, 2, -2, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1] }, { bounds: [-57.41789512172604, -41.7370951421332, 169.73709514213317, 185.41789512172608], cells: [0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-121.41789512172605, -41.7370951421332, 105.73709514213316, 185.41789512172608], cells: [0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, -2, 2, -1, 2] }, { bounds: [-121.41789512172605, -105.7370951421332, 105.73709514213316, 121.41789512172608], cells: [-1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1] }]], carrier: [[{ bounds: [-115.84, -37.96000000000001, 179.84, 101.96000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-120.9459555815356, -100.56194287824171, 179.8431779475796, 136.54184830823036], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, -2, -1, -2, 0, -2, 1, 2, 2, 2, 0, 2] }, { bounds: [-120.94595558153557, -72.54184830823033, 179.8431779475796, 164.56194287824172], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, -2, 2, -2, 0, -2] }, { bounds: [-115.84, -37.96000000000001, 243.84, 101.96000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-115.84, -37.96000000000001, 179.84, 165.96], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-179.84, -37.96000000000001, 179.84, 101.96000000000001], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-115.84, -101.96000000000001, 179.84, 101.96000000000001], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }], [{ bounds: [-100.55876268462978, -100.55876268462978, 136.5386665306192, 136.5386665306192], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-100.56194287824174, -120.94595558153557, 136.54184830823033, 179.8431779475796], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 1, -2, -1, 2] }, { bounds: [-120.94595558153556, -100.56194287824171, 179.8431779475796, 136.54184830823036], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, -2, 1, 2, -1] }, { bounds: [-100.55876268462978, -100.55876268462978, 200.5386665306192, 200.5386665306192], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-164.55876268462978, -100.55876268462978, 136.5386665306192, 200.5386665306192], cells: [-2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-164.55876268462978, -164.55876268462978, 136.5386665306192, 136.5386665306192], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-100.55876268462978, -164.55876268462978, 200.5386665306192, 136.5386665306192], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-37.96000000000001, -115.84, 101.96000000000001, 179.84], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-72.54184830823034, -120.94595558153557, 164.56194287824172, 179.84317794757956], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 2, -2, 2, -1, 2, 0, -2, 1, -2, 2, -2, 0] }, { bounds: [-100.56194287824174, -120.94595558153557, 136.54184830823033, 179.8431779475796], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -2, -2, -2, -1, -2, 0, 2, 1, 2, 2, 2, 0] }, { bounds: [-37.96000000000001, -115.84, 101.96000000000001, 243.84], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-101.96000000000001, -115.84, 101.96000000000001, 179.84], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }, { bounds: [-37.96000000000001, -179.84, 101.96000000000001, 179.84], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-37.96000000000001, -115.84, 165.96, 179.84], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-72.53866653061918, -100.55876268462978, 164.55876268462978, 136.5386665306192], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-115.84317794757959, -100.56194287824171, 184.9459555815356, 136.54184830823033], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 2, 1, -2, -1] }, { bounds: [-72.54184830823034, -120.94595558153557, 164.56194287824172, 179.8431779475796], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, -1, -2, 1, 2] }, { bounds: [-136.5386665306192, -100.55876268462978, 164.55876268462978, 200.5386665306192], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-136.5386665306192, -164.55876268462978, 164.55876268462978, 136.5386665306192], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-72.53866653061918, -164.55876268462978, 228.55876268462978, 136.5386665306192], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-72.53866653061918, -100.55876268462978, 228.55876268462978, 200.5386665306192], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-115.84, -37.96000000000002, 179.84, 101.96000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-115.84317794757959, -72.54184830823034, 184.9459555815356, 164.56194287824172], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 1, 2, 2, 2, 0, 2, -1, -2, -2, -2, 0, -2] }, { bounds: [-115.84317794757959, -100.56194287824171, 184.9459555815356, 136.54184830823033], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 1, -2, 2, -2, 0, -2, -1, 2, -2, 2, 0, 2] }, { bounds: [-179.84, -37.96000000000002, 179.84, 101.96000000000001], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-115.84, -101.96000000000001, 179.84, 101.96000000000001], cells: [-2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1] }, { bounds: [-115.84, -37.96000000000002, 243.84, 101.96000000000001], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-115.84, -37.96000000000002, 179.84, 165.96], cells: [-2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2] }], [{ bounds: [-72.53866653061921, -72.53866653061918, 164.5587626846298, 164.55876268462978], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-72.54184830823036, -115.84317794757958, 164.56194287824178, 184.9459555815356], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, -1, 2, 1, -2] }, { bounds: [-115.84317794757959, -72.54184830823034, 184.9459555815356, 164.56194287824172], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 2, -1, -2, 1] }, { bounds: [-136.5386665306192, -136.5386665306192, 164.5587626846298, 164.55876268462978], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-72.53866653061921, -136.5386665306192, 228.5587626846298, 164.55876268462978], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-72.53866653061921, -72.53866653061918, 228.5587626846298, 228.55876268462978], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-136.5386665306192, -72.53866653061918, 164.5587626846298, 228.55876268462978], cells: [-2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-37.96000000000001, -115.84, 101.96000000000002, 179.84], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-100.5619428782417, -115.84317794757959, 136.5418483082303, 184.94595558153557], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -2, 1, -2, 2, -2, 0, 2, -1, 2, -2, 2, 0] }, { bounds: [-72.54184830823036, -115.84317794757958, 164.56194287824178, 184.9459555815356], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, 2, 1, 2, 2, 2, 0, -2, -1, -2, -2, -2, 0] }, { bounds: [-37.96000000000001, -179.84, 101.96000000000002, 179.84], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2] }, { bounds: [-37.96000000000001, -115.84, 165.96000000000004, 179.84], cells: [-1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2] }, { bounds: [-37.96000000000001, -115.84, 101.96000000000002, 243.84], cells: [-1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-101.96000000000001, -115.84, 101.96000000000002, 179.84], cells: [-2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2] }], [{ bounds: [-100.55876268462977, -72.53866653061921, 136.53866653061917, 164.5587626846298], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-120.9459555815356, -72.54184830823037, 179.8431779475796, 164.56194287824175], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, -2, -1, 2, 1] }, { bounds: [-100.5619428782417, -115.84317794757959, 136.5418483082303, 184.94595558153557], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -1, -2] }, { bounds: [-100.55876268462977, -136.5386665306192, 200.53866653061917, 164.5587626846298], cells: [1, -3, 2, -3, 3, -3, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-100.55876268462977, -72.53866653061921, 200.53866653061917, 228.5587626846298], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-164.55876268462976, -72.53866653061921, 136.53866653061917, 228.5587626846298], cells: [0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-164.55876268462976, -136.5386665306192, 136.53866653061917, 164.5587626846298], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2] }]], shipOfTheLine: [[{ bounds: [-160.72, -63.040000000000006, 224.72, 127.04], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-167.9364131847198, -143.03008817296478, 224.7224752547533, 169.1161364067155], cells: [-2, -2, -1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, -2, -3, -2, 1, 2, 0, 2, 2, 2, 3, 2, -2, -3, -1, -3, 1, -2] }, { bounds: [-167.9364131847198, -105.11613640671554, 224.72247525475328, 207.03008817296478], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, -3, 2, 1, -2, 0, -2, 2, -2, 3, -2, -2, 3, -1, 3, 1, 2] }, { bounds: [-160.72, -63.040000000000006, 288.72, 127.04], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-160.72, -63.040000000000006, 224.72, 191.04000000000002], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }, { bounds: [-224.72, -63.040000000000006, 224.72, 127.04], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-160.72, -127.04, 224.72, 127.04], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }], [{ bounds: [-143.02759596269382, -143.02759596269382, 169.11366172632106, 169.11366172632103], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-143.0300881729648, -167.93641318471975, 169.11613640671553, 224.7224752547533], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, -1, 2, 0, -3, 2, 3, 1, 3, 0, 3, 1, -3, -1, 3] }, { bounds: [-167.9364131847198, -143.03008817296478, 224.72247525475328, 169.1161364067155], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2, 2, -1, -3, 0, 3, 2, 3, 1, 3, 0, -3, 1, 3, -1] }, { bounds: [-143.02759596269382, -143.02759596269382, 233.11366172632106, 233.11366172632103], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 3, 3] }, { bounds: [-207.02759596269382, -143.02759596269382, 169.11366172632106, 233.11366172632103], cells: [-2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }, { bounds: [-207.02759596269382, -207.0275959626938, 169.11366172632106, 169.11366172632103], cells: [-3, -4, -2, -4, -4, -3, -3, -3, -2, -3, -1, -3, 0, -3, -4, -2, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2] }, { bounds: [-143.02759596269382, -207.0275959626938, 233.11366172632106, 169.11366172632103], cells: [-1, -4, 0, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-63.04000000000001, -160.72, 127.04, 224.72], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-105.11613640671554, -167.9364131847198, 207.03008817296478, 224.72247525475328], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, 2, 0, 2, -3, -2, 1, -2, 0, -2, 2, -2, 3, 3, -2, 3, -1, 2, 1] }, { bounds: [-143.0300881729648, -167.93641318471975, 169.11613640671553, 224.7224752547533], cells: [-1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -2, 0, -2, -3, 2, 1, 2, 0, 2, 2, 2, 3, -3, -2, -3, -1, -2, 1] }, { bounds: [-63.04000000000001, -160.72, 127.04, 288.72], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-127.04000000000002, -160.72, 127.04, 224.72], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3] }, { bounds: [-63.04000000000001, -224.72, 127.04, 224.72], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-63.04000000000001, -160.72, 191.04000000000002, 224.72], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }], [{ bounds: [-105.11366172632106, -143.02759596269382, 207.0275959626938, 169.11366172632106], cells: [1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-160.72247525475325, -143.0300881729648, 231.93641318471978, 169.1161364067155], cells: [1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, -2, -1, 3, 0, -3, 2, -3, 1, -3, 0, 3, 1, -3, -1] }, { bounds: [-105.11613640671554, -167.9364131847198, 207.03008817296478, 224.72247525475328], cells: [1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2, 1, 2, 0, -3, -2, 3, -1, 3, 0, 3, -1, -3, 1, 3] }, { bounds: [-169.11366172632103, -143.02759596269382, 207.0275959626938, 233.11366172632106], cells: [1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -3, 3, -2, 3, -1, 3] }, { bounds: [-169.11366172632103, -207.02759596269382, 207.0275959626938, 169.11366172632106], cells: [0, -4, 1, -4, -2, -3, -1, -3, 0, -3, 1, -3, 2, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2] }, { bounds: [-105.11366172632106, -207.02759596269382, 271.0275959626938, 169.11366172632106], cells: [2, -4, 3, -4, 0, -3, 1, -3, 2, -3, 3, -3, 4, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, 4, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -2, 2, -1, 2, 0, 2] }, { bounds: [-105.11366172632106, -143.02759596269382, 271.0275959626938, 233.11366172632106], cells: [1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-160.72, -63.04000000000002, 224.72, 127.04], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-160.72247525475325, -105.11613640671554, 231.9364131847198, 207.0300881729648], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 1, 2, 2, 2, 0, 2, 3, 2, -1, -2, 0, -2, -2, -2, -3, -2, 1, 3, 2, 3, -1, 2] }, { bounds: [-160.72247525475325, -143.0300881729648, 231.93641318471978, 169.1161364067155], cells: [1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 0, -2, 3, -2, -1, 2, 0, 2, -2, 2, -3, 2, 1, -3, 2, -3, -1, -2] }, { bounds: [-224.72, -63.04000000000002, 224.72, 127.04], cells: [-4, -1, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-160.72, -127.04000000000002, 224.72, 127.04], cells: [-3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1] }, { bounds: [-160.72, -63.04000000000002, 288.72, 127.04], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, 4, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1] }, { bounds: [-160.72, -63.04000000000002, 224.72, 191.04000000000002], cells: [-3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2] }], [{ bounds: [-105.11366172632108, -105.11366172632106, 207.02759596269385, 207.02759596269382], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-105.11613640671557, -160.72247525475328, 207.03008817296484, 231.93641318471978], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, 1, -2, 0, 3, -2, -3, -1, -3, 0, -3, -1, 3, 1, -3] }, { bounds: [-160.72247525475325, -105.11613640671554, 231.9364131847198, 207.0300881729648], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3, -2, 1, 3, 0, -3, -2, -3, -1, -3, 0, 3, -1, -3, 1] }, { bounds: [-169.11366172632108, -169.11366172632106, 207.02759596269385, 207.02759596269382], cells: [-3, -3, -2, -3, -1, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-105.11366172632108, -169.11366172632106, 271.02759596269385, 207.02759596269382], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 1, 3, 2, 3] }, { bounds: [-105.11366172632108, -105.11366172632106, 271.02759596269385, 271.0275959626938], cells: [-2, -2, -1, -2, 0, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, 4, 2, 0, 3, 1, 3, 2, 3, 3, 3, 4, 3, 2, 4, 3, 4] }, { bounds: [-169.11366172632108, -105.11366172632106, 207.02759596269385, 271.0275959626938], cells: [-3, -2, -2, -2, -1, -2, 0, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, 3, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, 0, 4, 1, 4] }], [{ bounds: [-63.040000000000006, -160.72, 127.04000000000002, 224.72], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-143.03008817296475, -160.72247525475325, 169.11613640671553, 231.93641318471978], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -2, 0, -2, 3, 2, -1, 2, 0, 2, -2, 2, -3, -3, 1, -3, 2, -2, -1] }, { bounds: [-105.11613640671557, -160.72247525475328, 207.03008817296484, 231.93641318471978], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 0, 2, 3, -2, -1, -2, 0, -2, -2, -2, -3, 3, 1, 3, 2, 2, -1] }, { bounds: [-63.040000000000006, -224.72, 127.04000000000002, 224.72], cells: [-1, -4, 0, -4, 1, -4, -1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3] }, { bounds: [-63.040000000000006, -160.72, 191.04000000000002, 224.72], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -1, -2, 0, -2, 1, -2, 2, -2, -1, -1, 0, -1, 1, -1, 2, -1, -1, 0, 0, 0, 1, 0, 2, 0, -1, 1, 0, 1, 1, 1, 2, 1, -1, 2, 0, 2, 1, 2, 2, 2, -1, 3, 0, 3, 1, 3, 2, 3] }, { bounds: [-63.040000000000006, -160.72, 127.04000000000002, 288.72], cells: [-1, -3, 0, -3, 1, -3, -1, -2, 0, -2, 1, -2, -1, -1, 0, -1, 1, -1, -1, 0, 0, 0, 1, 0, -1, 1, 0, 1, 1, 1, -1, 2, 0, 2, 1, 2, -1, 3, 0, 3, 1, 3, -1, 4, 0, 4, 1, 4] }, { bounds: [-127.04, -160.72, 127.04000000000002, 224.72], cells: [-2, -3, -1, -3, 0, -3, 1, -3, -2, -2, -1, -2, 0, -2, 1, -2, -2, -1, -1, -1, 0, -1, 1, -1, -2, 0, -1, 0, 0, 0, 1, 0, -2, 1, -1, 1, 0, 1, 1, 1, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 0, 3, 1, 3] }], [{ bounds: [-143.0275959626938, -105.11366172632108, 169.11366172632106, 207.02759596269385], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3] }, { bounds: [-167.93641318471978, -105.11613640671557, 224.72247525475328, 207.03008817296487], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, 2, 1, -3, 0, 3, -2, 3, -1, 3, 0, -3, -1, 3, 1] }, { bounds: [-143.03008817296475, -160.72247525475325, 169.11613640671553, 231.93641318471978], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3, -1, -2, 0, 3, 2, -3, 1, -3, 0, -3, 1, 3, -1, -3] }, { bounds: [-143.0275959626938, -169.11366172632108, 233.11366172632106, 207.02759596269385], cells: [1, -3, 2, -3, 3, -3, -1, -2, 0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3] }, { bounds: [-143.0275959626938, -105.11366172632108, 233.11366172632106, 271.02759596269385], cells: [0, -2, 1, -2, 2, -2, 3, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, 3, -1, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, 3, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, 2, 1, 3, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, 2, 2, -2, 3, -1, 3, 0, 3, 1, 3, 2, 3, -1, 4, 0, 4] }, { bounds: [-207.02759596269382, -105.11366172632108, 169.11366172632106, 271.02759596269385], cells: [0, -2, 1, -2, 2, -2, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -4, 2, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -4, 3, -3, 3, -2, 3, -1, 3, 0, 3, -3, 4, -2, 4] }, { bounds: [-207.02759596269382, -169.11366172632108, 169.11366172632106, 207.02759596269385], cells: [-1, -3, 0, -3, 1, -3, 2, -3, -3, -2, -2, -2, -1, -2, 0, -2, 1, -2, 2, -2, -3, -1, -2, -1, -1, -1, 0, -1, 1, -1, 2, -1, -4, 0, -3, 0, -2, 0, -1, 0, 0, 0, 1, 0, 2, 0, -4, 1, -3, 1, -2, 1, -1, 1, 0, 1, 1, 1, -3, 2, -2, 2, -1, 2, 0, 2, 1, 2, -2, 3, -1, 3] }]] };

// src/shared/navigation-masks.ts
var angle = Math.PI / 4;
var steps = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
function buildNavigationMasks(hull, cell) {
  const radius = polygonRadius(hull);
  const outline3 = (x, y, heading) => {
    const c = detCos(heading), s = detSin(heading);
    return hull.map((p) => ({ x: x + p.x * c - p.y * s, y: y + p.x * s + p.y * c }));
  };
  const sweep = (h, turn, dx, dy) => {
    const count = Math.max(1, Math.ceil(Math.abs(turn) * radius / 2)), covered = /* @__PURE__ */ new Set();
    const error = turn ? radius * (turn / count) ** 2 / 8 + 1e-7 : 0;
    let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
    let previous = outline3(cell / 2, cell / 2, h);
    for (let i = 0; i < count; i++) {
      const next = outline3(cell / 2 + dx * (i + 1) / count, cell / 2 + dy * (i + 1) / count, h + (i + 1) * turn / count);
      const envelope = convexHull([...previous, ...next]);
      previous = next;
      const poly = error ? expandConvex(envelope, error) : envelope;
      let l = Infinity, t = Infinity, r = -Infinity, b = -Infinity;
      for (const point of poly) {
        l = Math.min(l, point.x);
        t = Math.min(t, point.y);
        r = Math.max(r, point.x);
        b = Math.max(b, point.y);
      }
      left = Math.min(left, l);
      top = Math.min(top, t);
      right = Math.max(right, r);
      bottom = Math.max(bottom, b);
      const axes = polygonPlanes(poly);
      for (let row = Math.floor(t / cell); row <= Math.floor((b - 1e-7) / cell); row++)
        for (let col = Math.floor(l / cell); col <= Math.floor((r - 1e-7) / cell); col++)
          if (polygonTouchesCell(axes, col * cell, row * cell, cell))
            covered.add(`${col},${row}`);
    }
    return { bounds: [left, top, right, bottom], cells: [...covered].flatMap((key) => key.split(",").map(Number)) };
  };
  return Array.from({ length: 8 }, (_, h) => [sweep(h * angle, 0, 0, 0), sweep(h * angle, angle, 0, 0), sweep(h * angle, -angle, 0, 0), ...Array.from({ length: 4 }, (_2, m) => {
    const [dx, dy] = steps[(h + m * 2) % 8];
    return sweep(h * angle, 0, dx * cell, dy * cell);
  })]);
}

// src/shared/ship-navigation-potential.ts
var SEA_STEPS = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
function seaCostPlanes(directionCosts) {
  const weights = SEA_STEPS.map(([x, y], h) => (x && y ? Math.SQRT2 : 1) * directionCosts[h]);
  const polygon = convexHull(SEA_STEPS.map(([x, y], h) => ({ x: x / weights[h], y: y / weights[h] })));
  return polygon.map((a, i) => {
    const b = polygon[(i + 1) % polygon.length], det = a.x * b.y - a.y * b.x;
    const x = (b.y - a.y) / det, y = (a.x - b.x) / det;
    let ratio = 1;
    for (let h = 0; h < SEA_STEPS.length; h++) {
      const [dx, dy] = SEA_STEPS[h];
      ratio = Math.max(ratio, (x * dx + y * dy) / weights[h]);
    }
    const scale = ratio * (1 + 1e-12);
    return { x: x / scale, y: y / scale };
  });
}
function freeSeaDistance(planes2, x, y) {
  let value = 0;
  for (const plane of planes2) value = Math.max(value, plane.x * x + plane.y * y);
  return value;
}
function seaPotentialAt(field, x, y) {
  if (x >= field.left && y >= field.top && x < field.left + field.cols && y < field.top + field.rows) {
    const value = field.values[(y - field.top) * field.cols + x - field.left];
    if (Number.isFinite(value)) return value;
  }
  return freeSeaDistance(field.planes, (field.seedX - x) * field.cell, (field.seedY - y) * field.cell);
}
function buildSeaPotential(water, mapCols, mapRows, cell, bounds, seed, directionCosts, frontier) {
  const cols = bounds.right - bounds.left, rows = bounds.bottom - bounds.top;
  const planes2 = seaCostPlanes(directionCosts), values = new Float64Array(cols * rows);
  values.fill(Infinity);
  const field = { left: bounds.left, top: bounds.top, cols, rows, cell, seedX: seed.x, seedY: seed.y, planes: planes2, values };
  const weights = SEA_STEPS.map(([x, y], h) => cell * (x && y ? Math.SQRT2 : 1) * directionCosts[h]);
  const open = (x, y) => x >= 0 && y >= 0 && x < mapCols && y < mapRows && water[y * mapCols + x] === 1;
  frontier.reset();
  const add = (x, y, cost) => {
    if (!open(x, y)) return;
    const id = (y - bounds.top) * cols + x - bounds.left;
    if (cost >= values[id]) return;
    values[id] = cost;
    frontier.push(id, cost, cost);
  };
  add(seed.x, seed.y, 0);
  const border = (x, y) => {
    add(x, y, freeSeaDistance(planes2, (seed.x - x) * cell, (seed.y - y) * cell));
  };
  for (let x = bounds.left; x < bounds.right; x++) {
    border(x, bounds.top);
    if (rows > 1) border(x, bounds.bottom - 1);
  }
  for (let y = bounds.top + 1; y < bounds.bottom - 1; y++) {
    border(bounds.left, y);
    if (cols > 1) border(bounds.right - 1, y);
  }
  while (frontier.length) {
    const id = frontier.pop(), cost = frontier.poppedCost;
    if (cost !== values[id]) continue;
    const x = id % cols + bounds.left, y = Math.floor(id / cols) + bounds.top;
    for (let h = 0; h < SEA_STEPS.length; h++) {
      const [dx, dy] = SEA_STEPS[h], nx = x + dx, ny = y + dy;
      if (nx < bounds.left || ny < bounds.top || nx >= bounds.right || ny >= bounds.bottom || !open(nx, ny)) continue;
      const to = (ny - bounds.top) * cols + nx - bounds.left, distance = cost + weights[(h + 4) % SEA_STEPS.length];
      if (distance >= values[to]) continue;
      values[to] = distance;
      frontier.push(to, distance, distance);
    }
  }
  return field;
}

// src/shared/ship-navigation.ts
function curvedSegment(from, to) {
  const curvature = to.curvature ?? 0;
  if (Math.abs(curvature) < 1e-9) return 0;
  const x = from.x + (detSin(to.heading) - detSin(from.heading)) / curvature;
  const y = from.y - (detCos(to.heading) - detCos(from.heading)) / curvature;
  return Math.hypot(x - to.x, y - to.y) < 1e-5 ? curvature : 0;
}
function shipPoseAt(from, to, fraction) {
  const heading = from.heading + headingDifference(from.heading, to.heading) * fraction;
  if (to.pivot) {
    const lever = (from.x - to.pivot.x) * detCos(from.heading) + (from.y - to.pivot.y) * detSin(from.heading);
    return { x: to.pivot.x + lever * detCos(heading), y: to.pivot.y + lever * detSin(heading), heading };
  }
  const curvature = curvedSegment(from, to);
  if (curvature) return { x: from.x + (detSin(heading) - detSin(from.heading)) / curvature, y: from.y - (detCos(heading) - detCos(from.heading)) / curvature, heading };
  return { x: from.x + (to.x - from.x) * fraction, y: from.y + (to.y - from.y) * fraction, heading };
}
var waterFields = /* @__PURE__ */ new WeakMap();
function openWaterBox(map, left, top, right, bottom) {
  if (left < 0 || top < 0 || right > map.width || bottom > map.height)
    return false;
  const t = map.terrain;
  if (!t)
    return true;
  let field = waterFields.get(t);
  if (!field || field.cells !== t.cells || field.cols !== t.cols || field.rows !== t.rows) {
    const w2 = t.cols + 1, sums = new Uint32Array(w2 * (t.rows + 1));
    for (let y = 0; y < t.rows; y++) {
      let row = 0;
      for (let x = 0; x < t.cols; x++) {
        row += CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea ? 0 : 1;
        sums[(y + 1) * w2 + x + 1] = sums[y * w2 + x + 1] + row;
      }
    }
    field = { cells: t.cells, cols: t.cols, rows: t.rows, sums };
    waterFields.set(t, field);
  }
  const x0 = Math.max(0, Math.floor(left / t.cell)), y0 = Math.max(0, Math.floor(top / t.cell));
  const x1 = Math.min(t.cols, Math.ceil(right / t.cell)), y1 = Math.min(t.rows, Math.ceil(bottom / t.cell)), w = t.cols + 1, s = field.sums;
  return s[y1 * w + x1] - s[y0 * w + x1] - s[y1 * w + x0] + s[y0 * w + x0] === 0;
}
var DIRECTIONS = 8;
var ANGLE = Math.PI / 4;
var STEPS = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
function headingDifference(from, to) {
  return ((to - from + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
}
function outline(hull, pose) {
  const c = detCos(pose.heading), s = detSin(pose.heading);
  return hull.map((p) => ({ x: pose.x + p.x * c - p.y * s, y: pose.y + p.x * s + p.y * c }));
}
function clearOutline(map, polygon) {
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (const point of polygon) {
    left = Math.min(left, point.x);
    right = Math.max(right, point.x);
    top = Math.min(top, point.y);
    bottom = Math.max(bottom, point.y);
  }
  if (left < -1e-7 || top < -1e-7 || right > map.width + 1e-7 || bottom > map.height + 1e-7)
    return false;
  const terrain = map.terrain;
  if (!terrain)
    return true;
  if (openWaterBox(map, left, top, right, bottom))
    return true;
  const cell = terrain.cell;
  let axes;
  for (let row = Math.floor(top / cell); row <= Math.floor((bottom - 1e-7) / cell); row++)
    for (let col = Math.floor(left / cell); col <= Math.floor((right - 1e-7) / cell); col++) {
      const char = col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows ? void 0 : terrain.cells[row * terrain.cols + col];
      if (!CELL_GROUND[char ?? "."]?.sea && polygonTouchesCell(axes ??= polygonPlanes(polygon), col * cell, row * cell, cell))
        return false;
    }
  return true;
}
function hullFits(map, ship, pose = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }) {
  const profile = shipProfile(ship);
  return Boolean(profile && clearOutline(map, outline(profile.hull, pose)));
}
function hullPassageClear(map, ship, from, to) {
  const hull = shipProfile(ship).hull;
  const turn = headingDifference(from.heading, to.heading);
  const curvature = curvedSegment(from, to);
  const hullRadius = polygonRadius(hull);
  const lever = to.pivot ? Math.hypot(from.x - to.pivot.x, from.y - to.pivot.y) : curvature ? 1 / Math.abs(curvature) : 0;
  const radius = hullRadius + lever;
  const pivotArc = !to.pivot || [0, 1].every((fraction) => {
    const at2 = shipPoseAt(from, to, fraction), endpoint = fraction ? to : from;
    return Math.hypot(at2.x - endpoint.x, at2.y - endpoint.y) < 1e-5;
  });
  const corridorRadius = pivotArc ? hullRadius + lever * turn * turn / 8 + (lever ? 1e-5 : 0) : radius;
  if (openWaterBox(map, Math.min(from.x, to.x) - corridorRadius, Math.min(from.y, to.y) - corridorRadius, Math.max(from.x, to.x) + corridorRadius, Math.max(from.y, to.y) + corridorRadius))
    return true;
  if (turn && (!hullFits(map, ship, from) || !hullFits(map, ship, to))) return false;
  const steps2 = Math.max(1, Math.ceil(Math.abs(turn) * Math.sqrt(radius / (8 * 0.025))));
  const error = turn ? radius * (turn / steps2) ** 2 / 8 + 1e-7 : 0;
  for (let i = 0; i < steps2; i++) {
    const a = shipPoseAt(from, to, i / steps2);
    const b = shipPoseAt(from, to, (i + 1) / steps2);
    const envelope = convexHull([...outline(hull, a), ...outline(hull, b)]);
    if (!clearOutline(map, error ? expandConvex(envelope, error) : envelope))
      return false;
  }
  return true;
}
function nearestShipPose(map, ship, point, seaOrigin = ship, accepts = () => true) {
  const preferred = ship.sailing?.heading ?? 0;
  const seaStart = isWalkable(map, seaOrigin.x, seaOrigin.y, "sea") ? seaOrigin : walkableGoal(map, seaOrigin.x, seaOrigin.y, "sea");
  const headings = [preferred, ...Array.from({ length: DIRECTIONS }, (_, i) => i * ANGLE)];
  if (!map.terrain) {
    const hull = outline(shipProfile(ship).hull, { x: 0, y: 0, heading: preferred });
    const x = Math.max(-Math.min(...hull.map((p) => p.x)), Math.min(map.width - Math.max(...hull.map((p) => p.x)), point.x));
    const y = Math.max(-Math.min(...hull.map((p) => p.y)), Math.min(map.height - Math.max(...hull.map((p) => p.y)), point.y));
    if (hullFits(map, ship, { x, y, heading: preferred }) && accepts({ x, y, heading: preferred })) return { x, y, heading: preferred };
    for (let distance = 16; distance <= shipProfile(ship).length * 4; distance += 16) for (let i = 0; i < 16; i++) {
      const angle2 = i * Math.PI / 8, at2 = { x: x + distance * detCos(angle2), y: y + distance * detSin(angle2), heading: preferred };
      if (hullFits(map, ship, at2) && accepts(at2)) return at2;
    }
    return void 0;
  }
  for (const heading of headings)
    if (hullFits(map, ship, { ...point, heading }) && accepts({ ...point, heading }) && sameGround(map, seaStart, point, "sea"))
      return { ...point, heading };
  const t = map.terrain, col = Math.max(0, Math.min(t.cols - 1, Math.floor(point.x / t.cell))), row = Math.max(0, Math.min(t.rows - 1, Math.floor(point.y / t.cell)));
  for (let ring = 0; ring <= Math.max(t.cols, t.rows); ring++) {
    let best, score = Infinity;
    for (let y = Math.max(0, row - ring); y <= Math.min(t.rows - 1, row + ring); y++)
      for (let x = Math.max(0, col - ring); x <= Math.min(t.cols - 1, col + ring); x++) {
        if (ring && Math.max(Math.abs(x - col), Math.abs(y - row)) !== ring)
          continue;
        const at2 = { x: (x + 0.5) * t.cell, y: (y + 0.5) * t.cell };
        if (!CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea || !sameGround(map, seaStart, at2, "sea"))
          continue;
        for (const heading of headings) {
          const value = Math.hypot(at2.x - point.x, at2.y - point.y) + Math.abs(headingDifference(preferred, heading)) * 1e-3;
          if (value < score && hullFits(map, ship, { ...at2, heading }) && accepts({ ...at2, heading })) {
            best = { ...at2, heading };
            score = value;
          }
        }
      }
    if (best)
      return best;
  }
  return void 0;
}
var grids = /* @__PURE__ */ new WeakMap();
function createSearchWorkspace(size) {
  return {
    costs: new Float64Array(size),
    parents: new Int32Array(size),
    stamps: new Uint32Array(size),
    trafficFits: new Int32Array(size),
    basePotentials: new Float64Array(size / DIRECTIONS),
    baseStamps: new Uint32Array(size / DIRECTIONS),
    generation: 0
  };
}
var search = createSearchWorkspace(0);
function searchWorkspace(size, nested = false) {
  if (nested) {
    const workspace = createSearchWorkspace(size);
    workspace.generation = 1;
    return workspace;
  }
  if (search.costs.length < size)
    search = createSearchWorkspace(size);
  if (++search.generation === 2147483647) {
    search.stamps.fill(0);
    search.trafficFits.fill(0);
    search.baseStamps.fill(0);
    search.generation = 1;
  }
  return search;
}
var geometryMasks = /* @__PURE__ */ new Map();
function masksFor(ship, cell) {
  const profile = shipProfile(ship), key = `${ship.kind}:${profile.length}:${profile.beam}:${cell}`;
  const cached = geometryMasks.get(key);
  if (cached) return cached;
  const prepared = cell === 32 ? ship_navigation_masks_default : cell === 64 ? ship_navigation_masks_64_default : void 0;
  const masks = prepared && shipScale(ship) === DEFAULT_SHIP_SCALE ? prepared[ship.kind] : buildNavigationMasks(profile.hull, cell);
  if (geometryMasks.size >= 64) geometryMasks.delete(geometryMasks.keys().next().value);
  geometryMasks.set(key, masks);
  return masks;
}
function gridFor(map, ship) {
  const t = map.terrain, key = `${ship.kind}:${shipProfile(ship).length}:${map.width}:${map.height}:${t.cell}:${t.cols}:${t.rows}`;
  let group = grids.get(t);
  if (!group) {
    group = /* @__PURE__ */ new Map();
    grids.set(t, group);
  }
  let grid = group.get(key);
  if (!grid || grid.cells !== t.cells) {
    const cell = t.cell, cols = Math.ceil(map.width / cell), rows = Math.ceil(map.height / cell);
    const size = cols * rows * DIRECTIONS;
    const masks = masksFor(ship, t.cell);
    const water = new Uint8Array(cols * rows);
    for (let y = 0; y < Math.min(rows, t.rows) && (y + 0.5) * cell < map.height; y++)
      for (let x = 0; x < Math.min(cols, t.cols) && (x + 0.5) * cell < map.width; x++)
        water[y * cols + x] = CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea ? 1 : 0;
    grid = { cells: t.cells, cell, cols, rows, water, masks, fits: new Int8Array(size), turns: new Int8Array(size * 2), moves: new Int8Array(size * 4) };
    if (group.size >= 32)
      group.delete(group.keys().next().value);
    group.set(key, grid);
  }
  return grid;
}
function maskFits(map, grid, id, mask) {
  const tile = Math.floor(id / DIRECTIONS), col = tile % grid.cols, row = Math.floor(tile / grid.cols), x = col * grid.cell, y = row * grid.cell;
  const [left, top, right, bottom] = mask.bounds;
  if (x + left < -1e-7 || y + top < -1e-7 || x + right > map.width + 1e-7 || y + bottom > map.height + 1e-7)
    return false;
  if (openWaterBox(map, x + left, y + top, x + right, y + bottom))
    return true;
  const t = map.terrain;
  for (let i = 0; i < mask.cells.length; i += 2) {
    const xx = col + mask.cells[i], yy = row + mask.cells[i + 1];
    if (xx < 0 || yy < 0 || xx >= t.cols || yy >= t.rows || !CELL_GROUND[t.cells[yy * t.cols + xx] ?? "."]?.sea)
      return false;
  }
  return true;
}
var Frontier = class {
  length = 0;
  poppedCost = 0;
  ids = new Int32Array(1024);
  costs = new Float64Array(1024);
  scores = new Float64Array(1024);
  reset() {
    this.length = 0;
    if (this.ids.length > 65536) {
      this.ids = new Int32Array(65536);
      this.costs = new Float64Array(65536);
      this.scores = new Float64Array(65536);
    }
    return this;
  }
  save() {
    return Array.from({ length: this.length }, (_, i) => ({ id: this.ids[i], cost: this.costs[i], score: this.scores[i] }));
  }
  restore(slots) {
    this.reset();
    const capacity = Math.max(1024, 2 ** Math.ceil(Math.log2(Math.max(1, slots.length))));
    if (this.ids.length < capacity) {
      this.ids = new Int32Array(capacity);
      this.costs = new Float64Array(capacity);
      this.scores = new Float64Array(capacity);
    }
    this.length = slots.length;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      this.ids[i] = slot.id;
      this.costs[i] = slot.cost;
      this.scores[i] = slot.score;
    }
    return this;
  }
  push(id, cost, score) {
    if (this.length === this.ids.length) {
      const ids = new Int32Array(this.length * 2), costs = new Float64Array(this.length * 2), scores = new Float64Array(this.length * 2);
      ids.set(this.ids);
      costs.set(this.costs);
      scores.set(this.scores);
      this.ids = ids;
      this.costs = costs;
      this.scores = scores;
    }
    let i = this.length++;
    while (i) {
      const parent = i - 1 >>> 2;
      if (!this.less(score, id, this.scores[parent], this.ids[parent]))
        break;
      this.copy(parent, i);
      i = parent;
    }
    this.ids[i] = id;
    this.costs[i] = cost;
    this.scores[i] = score;
  }
  copy(from, to) {
    this.ids[to] = this.ids[from];
    this.costs[to] = this.costs[from];
    this.scores[to] = this.scores[from];
  }
  less(aScore, aId, bScore, bId) {
    return aScore < bScore || aScore === bScore && aId < bId;
  }
  pop() {
    const result = this.ids[0], last = --this.length;
    this.poppedCost = this.costs[0];
    const id = this.ids[last], cost = this.costs[last], score = this.scores[last];
    if (last) {
      let i = 0;
      while (i * 4 + 1 < last) {
        let child = i * 4 + 1;
        const end = Math.min(last, child + 4);
        for (let next = child + 1; next < end; next++)
          if (this.less(this.scores[next], this.ids[next], this.scores[child], this.ids[child]))
            child = next;
        if (!this.less(this.scores[child], this.ids[child], score, id))
          break;
        this.copy(child, i);
        i = child;
      }
      this.ids[i] = id;
      this.costs[i] = cost;
      this.scores[i] = score;
    }
    return result;
  }
};
var routeFrontier = new Frontier();
var distanceFrontier = new Frontier();
var emptyTraffic = () => true;
var seaDistances = /* @__PURE__ */ new WeakMap();
function terrainDistances(map, grid, start, target, directionCosts) {
  const terrain = map.terrain, span = 16, blockX = Math.floor(target.x / (grid.cell * span)), blockY = Math.floor(target.y / (grid.cell * span));
  const fromX = Math.floor(start.x / (grid.cell * span)), fromY = Math.floor(start.y / (grid.cell * span));
  const key = `${map.width}:${map.height}:${grid.cell}:${grid.cols}:${grid.rows}:${fromX}:${fromY}:${blockX}:${blockY}:${directionCosts.join(":")}`;
  let group = seaDistances.get(terrain);
  if (!group) {
    group = /* @__PURE__ */ new Map();
    seaDistances.set(terrain, group);
  }
  const cached = group.get(key);
  if (cached?.cells === terrain.cells) return cached.field;
  const open = (x, y) => x >= 0 && y >= 0 && x < grid.cols && y < grid.rows && grid.water[y * grid.cols + x] === 1;
  const centerX = (blockX + 0.5) * span, centerY = (blockY + 0.5) * span;
  let seed = -1, seedGap = Infinity;
  for (let y = Math.max(0, blockY * span - 2); y < Math.min(grid.rows, (blockY + 1) * span + 2); y++)
    for (let x = Math.max(0, blockX * span - 2); x < Math.min(grid.cols, (blockX + 1) * span + 2); x++) {
      if (!open(x, y)) continue;
      const id = y * grid.cols + x, gap = (x + 0.5 - centerX) ** 2 + (y + 0.5 - centerY) ** 2;
      if (gap < seedGap) {
        seed = id;
        seedGap = gap;
      }
    }
  if (seed < 0) return void 0;
  const bounds = {
    left: Math.max(0, (Math.min(fromX, blockX) - 2) * span),
    top: Math.max(0, (Math.min(fromY, blockY) - 2) * span),
    right: Math.min(grid.cols, (Math.max(fromX, blockX) + 3) * span),
    bottom: Math.min(grid.rows, (Math.max(fromY, blockY) + 3) * span)
  };
  const field = buildSeaPotential(
    grid.water,
    grid.cols,
    grid.rows,
    grid.cell,
    bounds,
    { x: seed % grid.cols, y: Math.floor(seed / grid.cols) },
    directionCosts,
    distanceFrontier
  );
  if (group.size >= 8 && !group.has(key)) group.delete(group.keys().next().value);
  group.set(key, { cells: terrain.cells, field });
  return field;
}
function routeTime(map, ship, from, points) {
  const limits = shipMotionLimits(ship);
  let time = 0, previous = from;
  for (const point of points) {
    const yaw = Math.abs(headingDifference(previous.heading, point.heading));
    const dx = point.x - previous.x, dy = point.y - previous.y;
    const performance = coursePerformance(ship, map, point.heading, { assumeTrimmed: true });
    const speed = dx * detCos(point.heading) + dy * detSin(point.heading) < -1e-7 ? Math.min(limits.reverseSpeed, performance.auxiliarySpeed) : Math.max(performance.targetSpeed, performance.auxiliarySpeed);
    time += yaw / Math.max(1e-6, limits.turnRate) + Math.hypot(dx, dy) / Math.max(1e-6, speed);
    previous = point;
  }
  return time;
}
function keelCandidates(ship, from, goal) {
  const gap = Math.hypot(goal.x - from.x, goal.y - from.y);
  if (gap < 1e-7) return [goal.heading === void 0 || Math.abs(headingDifference(from.heading, goal.heading)) < 1e-7 ? [] : [{ ...goal, heading: goal.heading }]];
  const direction = Math.atan2(goal.y - from.y, goal.x - from.x);
  const length = shipProfile(ship).length;
  const headings = gap <= (goal.heading !== void 0 ? length : length / 2) ? [direction, direction + Math.PI] : [direction];
  return headings.map((heading) => {
    const turned = { x: from.x, y: from.y, heading }, end = { x: goal.x, y: goal.y, heading };
    const points = Math.abs(headingDifference(from.heading, heading)) < 1e-7 ? [end] : [turned, end];
    if (goal.heading !== void 0 && Math.abs(headingDifference(heading, goal.heading)) > 1e-7) points.push({ ...end, heading: goal.heading });
    return points;
  });
}
function connectorClear(map, ship, from, points, traffic) {
  return points.every((point, i) => {
    const previous = points[i - 1] ?? from;
    return hullPassageClear(map, ship, previous, point) && traffic(previous, point);
  });
}
function keelConnector(map, ship, from, goal, traffic) {
  return keelCandidates(ship, from, goal).sort((a, b) => routeTime(map, ship, from, a) - routeTime(map, ship, from, b)).find((points) => connectorClear(map, ship, from, points, traffic));
}
function departureRoute(map, ship, goal, traffic, latticeEscape = false) {
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }, length = shipProfile(ship).length;
  const desired = Math.atan2(goal.y - start.y, goal.x - start.x);
  const differences = [headingDifference(start.heading, desired), headingDifference(start.heading, desired + Math.PI)];
  for (const difference of differences) for (const lever of [length / 2, -length / 2]) {
    if (Math.abs(difference) < 1e-7) continue;
    const angle2 = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, difference));
    const pivot = { x: start.x - lever * detCos(start.heading), y: start.y - lever * detSin(start.heading) };
    const heading = start.heading + angle2, end = { x: pivot.x + lever * detCos(heading), y: pivot.y + lever * detSin(heading), heading, pivot };
    if (hullPassageClear(map, ship, start, end) && traffic(start, end)) return [end];
  }
  let escape;
  for (const direction of [1, -1]) for (let distance = map.terrain.cell; distance <= length * 4; distance += map.terrain.cell) {
    const end = { x: start.x + direction * distance * detCos(start.heading), y: start.y + direction * distance * detSin(start.heading), heading: start.heading };
    if (!hullPassageClear(map, ship, start, end) || !traffic(start, end)) break;
    if (keelConnector(map, ship, end, goal, traffic)) return [end];
    if (latticeEscape && !escape) {
      const cell = map.terrain.cell, col = Math.floor(end.x / cell), row = Math.floor(end.y / cell);
      for (let y = row - 1; y <= row + 1 && !escape; y++) for (let x = col - 1; x <= col + 1 && !escape; x++) for (let h = 0; h < DIRECTIONS; h++) {
        const entrance = { x: (x + 0.5) * cell, y: (y + 0.5) * cell, heading: h * ANGLE };
        if (hullFits(map, ship, entrance) && keelConnector(map, ship, end, entrance, traffic)) {
          escape = end;
          break;
        }
      }
    }
  }
  if (escape) return [{ ...escape, exact: true }];
}
function arrivalConnectorFor(map, ship, goal, traffic) {
  const length = shipProfile(ship).length;
  const arcs = [];
  for (const angle2 of [Math.PI / 4, -Math.PI / 4, Math.PI / 2, -Math.PI / 2]) for (const lever of [length / 2, -length / 2]) {
    const pivot = { x: goal.x - lever * detCos(goal.heading), y: goal.y - lever * detSin(goal.heading) }, heading = goal.heading - angle2;
    const stage = { x: pivot.x + lever * detCos(heading), y: pivot.y + lever * detSin(heading), heading }, end = { ...goal, pivot };
    if (!hullFits(map, ship, stage) || !traffic(stage, stage)) continue;
    if (!hullPassageClear(map, ship, stage, end) || !traffic(stage, end)) continue;
    arcs.push({ stage, end, angle: angle2 });
  }
  return (from) => {
    let best, bestCost = Infinity;
    for (const { stage, end, angle: angle2 } of arcs) {
      const connection = keelConnector(map, ship, from, stage, traffic);
      if (!connection) continue;
      const last = connection.at(-1) ?? from;
      if (!hullPassageClear(map, ship, last, stage) || !traffic(last, stage)) continue;
      const cost = routeTime(map, ship, from, [...connection, ...Math.abs(headingDifference(last.heading, stage.heading)) > 1e-7 ? [stage] : [], end]);
      if (cost >= bestCost) continue;
      bestCost = cost;
      best = [...connection, ...Math.abs(headingDifference(last.heading, stage.heading)) > 1e-7 ? [stage] : [], end];
    }
    return best;
  };
}
var routeSearchDepth = 0;
function planShipRoute(map, ship, goal, trafficClear = emptyTraffic, budget = Infinity, voyage = false) {
  routeSearchDepth++;
  try {
    return planShipRouteImpl(map, ship, goal, trafficClear, budget, voyage, routeSearchDepth > 1);
  } finally {
    routeSearchDepth--;
  }
}
function planShipRouteImpl(map, ship, goal, trafficClear, budget, voyage, nested, state) {
  const noTraffic = trafficClear === emptyTraffic || trafficClear.hasTraffic === false;
  const originalTraffic = trafficClear;
  let trafficBlocked = state?.trafficBlocked ?? false;
  trafficClear = noTraffic ? emptyTraffic : (from, to) => {
    const clear = originalTraffic(from, to);
    trafficBlocked ||= !clear;
    return clear;
  };
  const t = map.terrain;
  if (!t)
    return { points: [{ ...goal, heading: Math.round(Math.atan2(goal.y - ship.y, goal.x - ship.x) * 1e9) / 1e9 }], partial: false };
  const grid = gridFor(map, ship), size = grid.fits.length;
  const limits = shipMotionLimits(ship), cruise = Math.max(1e-6, coursePerformance(ship, map, 0, { assumeTrimmed: true }).maxForwardSpeed), turnSpeed = Math.max(1e-6, limits.turnRate);
  const courseSpeeds = Array.from({ length: DIRECTIONS }, (_, h) => {
    const performance = coursePerformance(ship, map, h * ANGLE, { assumeTrimmed: true });
    return { forward: Math.max(performance.targetSpeed, performance.auxiliarySpeed), reverse: Math.min(limits.reverseSpeed, performance.auxiliarySpeed) };
  });
  const edgeWeights = courseSpeeds.map((performance, h) => {
    const [dx, dy] = STEPS[h], distance = grid.cell * (dx && dy ? Math.SQRT2 : 1);
    return { forward: distance / Math.max(1e-6, performance.forward), reverse: distance / Math.max(1e-6, performance.reverse) };
  });
  const lattice = grid;
  const pose = (id) => {
    const cell = Math.floor(id / DIRECTIONS);
    return { x: (cell % lattice.cols + 0.5) * lattice.cell, y: (Math.floor(cell / lattice.cols) + 0.5) * lattice.cell, heading: id % DIRECTIONS * ANGLE };
  };
  const savedTraffic = new Map(state?.trafficFits?.map((entry) => [entry.id, entry.clear]));
  const fits = (id) => {
    if (!grid.fits[id])
      grid.fits[id] = maskFits(map, grid, id, grid.masks[id % DIRECTIONS][0]) ? 1 : -1;
    if (grid.fits[id] !== 1) return false;
    if (noTraffic) return true;
    if (trafficFits[id] !== generation && trafficFits[id] !== -generation) {
      const at2 = pose(id);
      const clear = trafficClear(at2, at2);
      trafficFits[id] = clear ? generation : -generation;
      if (state) savedTraffic.set(id, clear);
    }
    return trafficFits[id] === generation;
  };
  const requested = goal.heading === void 0 ? void 0 : { x: goal.x, y: goal.y, heading: goal.heading };
  let preparedTarget = state?.target, deferred = state?.deferred ?? false;
  const length = shipProfile(ship).length;
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  if (!preparedTarget) {
    const terrainTarget = requested && hullFits(map, ship, requested) ? requested : nearestShipPose(map, ship, goal);
    preparedTarget = terrainTarget && trafficClear(terrainTarget, terrainTarget) ? terrainTarget : nearestShipPose(map, ship, goal, ship, (pose2) => trafficClear(pose2, pose2));
    const target2 = preparedTarget;
    deferred = !!terrainTarget && (!target2 || Math.hypot(target2.x - terrainTarget.x, target2.y - terrainTarget.y) > 1e-7 || goal.heading !== void 0 && Math.abs(headingDifference(target2.heading, terrainTarget.heading)) > 1e-7);
    if (!target2) return { points: [], partial: deferred };
    const destination2 = requested ? target2 : { x: target2.x, y: target2.y };
    const direct = keelConnector(map, ship, start, destination2, trafficClear);
    if (direct) return { points: direct.filter((point, i) => i !== 0 || Math.hypot(point.x - start.x, point.y - start.y) > 1e-7 || Math.abs(headingDifference(start.heading, point.heading)) > 1e-7 || direct.length === 1), partial: deferred };
    const arrival = arrivalConnectorFor(map, ship, target2, trafficClear)(start);
    if (arrival) return { points: arrival, partial: deferred };
    const direction = Math.atan2(target2.y - start.y, target2.x - start.x);
    if ([direction, direction + Math.PI].every((heading) => !hullPassageClear(map, ship, start, { ...start, heading }) || !trafficClear(start, { ...start, heading }))) {
      const departure = departureRoute(map, ship, target2, trafficClear);
      if (departure) return { points: departure, partial: true };
    }
    if (state) {
      state.target = target2;
      state.deferred = deferred;
      state.trafficBlocked = trafficBlocked;
      state.phase = "entrance";
      return;
    }
  }
  const target = preparedTarget;
  const destination = requested ? target : { x: target.x, y: target.y };
  const arrive = arrivalConnectorFor(map, ship, target, trafficClear);
  const workspace = searchWorkspace(size, nested), {
    costs,
    parents: previous,
    stamps,
    trafficFits,
    basePotentials,
    baseStamps,
    generation
  } = workspace, frontier = nested ? new Frontier() : routeFrontier.reset();
  const useDistances = voyage && !Number.isFinite(budget) && lattice.cols * lattice.rows <= 262144 && Math.hypot(target.x - start.x, target.y - start.y) > lattice.cell * 24 && !openWaterBox(
    map,
    Math.min(start.x, target.x) - lattice.cell / 2,
    Math.min(start.y, target.y) - lattice.cell / 2,
    Math.max(start.x, target.x) + lattice.cell / 2,
    Math.max(start.y, target.y) + lattice.cell / 2
  );
  const directionCosts = courseSpeeds.map((performance, h) => cruise / Math.max(1e-6, performance.forward, courseSpeeds[(h + 4) % DIRECTIONS].reverse));
  const distances = useDistances ? terrainDistances(map, grid, start, target, directionCosts) : void 0;
  const targetCol = Math.floor(target.x / lattice.cell), targetRow = Math.floor(target.y / lattice.cell);
  let terminalPotential = 0;
  if (distances) {
    for (let y = Math.max(0, targetRow - 2); y <= Math.min(lattice.rows - 1, targetRow + 2); y++)
      for (let x = Math.max(0, targetCol - 2); x <= Math.min(lattice.cols - 1, targetCol + 2); x++)
        if (grid.water[y * grid.cols + x] === 1 && Math.hypot((x + 0.5) * lattice.cell - target.x, (y + 0.5) * lattice.cell - target.y) <= lattice.cell * 1.5)
          terminalPotential = Math.max(terminalPotential, seaPotentialAt(distances, x, y));
  }
  const basePotential = (tile, x, y) => {
    if (baseStamps[tile] === generation) return basePotentials[tile];
    const distance = distances ? seaPotentialAt(distances, tile % lattice.cols, Math.floor(tile / lattice.cols)) : 0;
    const lowerBound = distance - terminalPotential;
    baseStamps[tile] = generation;
    return basePotentials[tile] = Math.max(Math.hypot(x - target.x, y - target.y), Number.isFinite(lowerBound) ? lowerBound : 0) / cruise;
  };
  const heuristic = (id, x, y) => basePotential(Math.floor(id / DIRECTIONS), x, y);
  const cost = (id) => stamps[id] === generation ? costs[id] : Infinity;
  const reached = new Map(state?.nodes?.map((entry) => [entry.id, entry]));
  for (const entry of reached.values()) {
    stamps[entry.id] = generation;
    costs[entry.id] = entry.cost;
    previous[entry.id] = entry.parent;
  }
  for (const [id, clear] of savedTraffic) trafficFits[id] = clear ? generation : -generation;
  if (state?.heap) frontier.restore(state.heap);
  const setCost = (id, value, parent) => {
    stamps[id] = generation;
    costs[id] = value;
    previous[id] = parent;
    if (state) reached.set(id, { id, cost: value, parent });
  };
  const prefixes = new Map(state?.prefixes?.map((entry) => [entry.id, entry.points])), entrances = new Map(state?.entrances?.map((entry) => [entry.cell, entry.points]));
  const pause = () => {
    state.nodes = Array.from(reached.values());
    state.trafficFits = Array.from(savedTraffic, ([id, clear]) => ({ id, clear }));
    state.heap = frontier.save();
    state.prefixes = Array.from(prefixes, ([id, points]) => ({ id, points }));
    state.entrances = Array.from(entrances, ([cell, points]) => ({ cell, points }));
    state.trafficBlocked = trafficBlocked;
  };
  const col = Math.floor(ship.x / lattice.cell), row = Math.floor(ship.y / lattice.cell);
  let entranceCursor = 0, entranceWork = 0;
  if (!state || state.phase === "entrance") for (let y = Math.max(0, row - 1); y <= Math.min(lattice.rows - 1, row + 1); y++)
    for (let x = Math.max(0, col - 1); x <= Math.min(lattice.cols - 1, col + 1); x++)
      for (let h = 0; h < DIRECTIONS; h++) {
        if (state && entranceCursor++ < (state.entranceCursor ?? 0)) continue;
        if (state && entranceWork++ >= 16) {
          state.entranceCursor = entranceCursor - 1;
          pause();
          return;
        }
        const id = (y * lattice.cols + x) * DIRECTIONS + h, p = pose(id);
        if (!fits(id))
          continue;
        const cell = y * lattice.cols + x;
        if (!entrances.has(cell)) entrances.set(cell, keelCandidates(ship, start, { x: p.x, y: p.y }).filter((points) => connectorClear(map, ship, start, points, trafficClear)));
        let prefix2, g = Infinity;
        for (const entrance of entrances.get(cell)) {
          const end = entrance.at(-1) ?? start;
          if (!hullPassageClear(map, ship, end, p) || !trafficClear(end, p)) continue;
          const points = [...entrance, ...Math.abs(headingDifference(end.heading, p.heading)) > 1e-7 ? [p] : []], time = routeTime(map, ship, start, points);
          if (time < g) {
            g = time;
            prefix2 = points;
          }
        }
        if (!prefix2) continue;
        setCost(id, g, -1);
        prefixes.set(id, prefix2);
        frontier.push(id, g, g + heuristic(id, p.x, p.y));
      }
  if (state && state.phase === "entrance") {
    state.phase = "search";
    pause();
    return;
  }
  if (!frontier.length) {
    const departure = departureRoute(map, ship, target, trafficClear, true);
    return { points: departure ?? [], partial: !!departure || deferred || trafficBlocked };
  }
  let best = state?.best ?? -1, bestGap = state?.bestGap ?? Infinity, visited = state?.visited ?? 0, partial = false, terminal, expanded = 0;
  const visit = (id, nodeCost, p, to, weight, slot, index, mask) => {
    const value = nodeCost + weight;
    if (value >= cost(to) || !fits(to))
      return;
    if (!slot[index])
      slot[index] = maskFits(map, grid, id, mask) ? 1 : -1;
    if (slot[index] !== 1)
      return;
    const tile = Math.floor(to / DIRECTIONS), px = (tile % lattice.cols + 0.5) * lattice.cell, py = (Math.floor(tile / lattice.cols) + 0.5) * lattice.cell;
    if (!noTraffic && !trafficClear(p, { x: px, y: py, heading: to % DIRECTIONS * ANGLE }))
      return;
    setCost(to, value, id);
    frontier.push(to, value, value + heuristic(to, px, py));
  };
  while (frontier.length) {
    if (state && expanded >= (noTraffic ? 4096 : 128)) {
      state.best = best;
      if (Number.isFinite(bestGap)) state.bestGap = bestGap;
      state.visited = visited;
      pause();
      return;
    }
    const id = frontier.pop();
    const nodeCost = cost(id);
    if (frontier.poppedCost !== nodeCost)
      continue;
    const h = id % DIRECTIONS, cell = Math.floor(id / DIRECTIONS), x = cell % lattice.cols, y = Math.floor(cell / lattice.cols);
    const px = (x + 0.5) * lattice.cell, py = (y + 0.5) * lattice.cell;
    const p = noTraffic ? void 0 : { x: px, y: py, heading: h * ANGLE };
    expanded++;
    if (++visited > budget) {
      best = id;
      partial = true;
      break;
    }
    const gap = Math.hypot(px - target.x, py - target.y);
    if (gap < bestGap || gap === bestGap && cost(id) < (best < 0 ? Infinity : cost(best))) {
      best = id;
      bestGap = gap;
    }
    if (gap <= lattice.cell * 1.5) {
      const at2 = p ?? { x: px, y: py, heading: h * ANGLE };
      const connection = keelConnector(map, ship, at2, destination, trafficClear) ?? arrive(at2);
      if (connection) {
        best = id;
        terminal = connection;
        break;
      }
    }
    visit(id, nodeCost, p, cell * DIRECTIONS + (h + 1) % DIRECTIONS, ANGLE / turnSpeed, grid.turns, id * 2, grid.masks[h][1]);
    visit(id, nodeCost, p, cell * DIRECTIONS + (h + DIRECTIONS - 1) % DIRECTIONS, ANGLE / turnSpeed, grid.turns, id * 2 + 1, grid.masks[h][2]);
    for (const maneuver of [0, 2]) {
      const [dx, dy] = STEPS[(h + maneuver * 2) % DIRECTIONS], nx = x + dx, ny = y + dy;
      if (voyage && maneuver === 2) {
        const ax = (nx + 0.5) * lattice.cell - start.x, ay = (ny + 0.5) * lattice.cell - start.y;
        if (Math.abs(ax) > length || Math.abs(ay) > length || Math.hypot(ax, ay) > length) continue;
      }
      if (nx >= 0 && ny >= 0 && nx < lattice.cols && ny < lattice.rows)
        visit(id, nodeCost, p, (ny * lattice.cols + nx) * DIRECTIONS + h, maneuver === 2 ? edgeWeights[h].reverse : edgeWeights[h].forward, grid.moves, id * 4 + maneuver, grid.masks[h][maneuver + 3]);
    }
  }
  if (state) state.visited = visited;
  if (best < 0)
    return { points: [], partial: false };
  const path = [];
  for (let at2 = best; at2 >= 0; at2 = previous[at2])
    path.push(pose(at2));
  path.reverse();
  const root = path[0];
  const rootId = (Math.floor(root.y / lattice.cell) * lattice.cols + Math.floor(root.x / lattice.cell)) * DIRECTIONS + Math.round(root.heading / ANGLE) % DIRECTIONS;
  const prefix = prefixes.get(rootId) ?? [root];
  path.splice(0, 1, ...prefix);
  if (terminal) path.push(...terminal);
  if (!terminal && trafficBlocked && !partial) {
    if (state) {
      state.phase = "fallback";
      state.path = path;
      state.fallback = { phase: "prepare" };
      state.deferred = deferred;
      delete state.nodes;
      delete state.trafficFits;
      delete state.heap;
      delete state.prefixes;
      delete state.entrances;
      delete state.best;
      delete state.bestGap;
      delete state.visited;
      delete state.entranceCursor;
      return;
    }
    const unobstructed = planShipRoute(map, ship, goal, void 0, Infinity, voyage), end = path.at(-1) ?? start, possible = unobstructed.points.at(-1) ?? start;
    partial = unobstructed.partial || Math.hypot(end.x - possible.x, end.y - possible.y) > 1e-7;
  }
  return { points: path, partial: partial || deferred };
}

// src/shared/veteran-skills.ts
var VETERAN_ACTIVE_SKILL_IDS = ["veteranRally", "veteranHealingWave", "veteranInnerFire"];
var VETERAN_SKILLS = {
  veteranResilience: {
    id: "veteranResilience",
    name: { zh: "\u767E\u6218\u4E4B\u8EAF", en: "Battle Hardened" },
    icon: "\u25C6",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\u3002", en: "Passive: take 25% less damage." },
    effect: { type: "passive", modifiers: { damageReduction: 0.25 } }
  },
  veteranMobility: {
    id: "veteranMobility",
    name: { zh: "\u8FC5\u6377\u884C\u52A8", en: "Swift Movement" },
    icon: "\u27A4",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 30%\u3002", en: "Passive: gain 30% movement speed." },
    effect: { type: "passive", modifiers: { moveSpeedMultiplier: 1.3 } }
  },
  veteranCommand: {
    id: "veteranCommand",
    name: { zh: "\u534F\u540C\u4F5C\u6218", en: "Coordinated Assault" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 35%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 35% attack speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { attackSpeedMultiplier: 1.35 } }
  },
  veteranVigilance: {
    id: "veteranVigilance",
    name: { zh: "\u8B66\u6212\u4E92\u52A9", en: "Watchful Company" },
    icon: "\u25C7",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 18%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 160, including self, take 18% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 160, modifiers: { damageReduction: 0.18 } }
  },
  veteranRally: {
    id: "veteranRally",
    name: { zh: "\u6218\u6597\u53F7\u4EE4", en: "Rallying Cry" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A160 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 60%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002", en: "Active / autocast: up to 5 allies within 160 gain 60% attack speed for 8 seconds. Cooldown: 24 seconds." },
    effect: { type: "active", action: "buff", radius: 160, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { attackSpeedMultiplier: 1.6 } }
  },
  veteranPhalanx: {
    id: "veteranPhalanx",
    name: { zh: "\u575A\u5B88\u9635\u7EBF", en: "Hold the Line" },
    icon: "\u25A3",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A130 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 130, including self, take 25% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 130, modifiers: { damageReduction: 0.25 } }
  },
  veteranSteadyAim: {
    id: "veteranSteadyAim",
    name: { zh: "\u6C89\u7740\u7784\u51C6", en: "Steady Aim" },
    icon: "\u25CE",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u7784\u51C6\u901F\u5EA6\u63D0\u9AD8 80%\uFF0C\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 20%\uFF1B\u79FB\u52A8\u4ECD\u9075\u5B88\u539F\u6709\u7784\u51C6\u9650\u5236\u3002", en: "Passive: gain 80% aiming speed and 20% attack speed. Movement retains its normal effect on aim." },
    effect: { type: "passive", modifiers: { aimSpeedMultiplier: 1.8, attackSpeedMultiplier: 1.2 } }
  },
  veteranMarch: {
    id: "veteranMarch",
    name: { zh: "\u884C\u519B\u9886\u961F", en: "March Leader" },
    icon: "\xBB",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 25%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 25% movement speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { moveSpeedMultiplier: 1.25 } }
  },
  veteranHealingWave: {
    id: "veteranHealingWave",
    name: { zh: "\u7FA4\u4F53\u6062\u590D", en: "Restoring Wave" },
    icon: "\u271A",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A\u6062\u590D 180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u5404 90 \u70B9\u751F\u547D\uFF0C\u4F18\u5148\u4F24\u8005\uFF1B\u51B7\u5374 18 \u79D2\u3002\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Active / autocast: heal up to 5 allies within 180 for 90 health each, prioritizing wounded units. Cooldown: 18 seconds. Does not affect mechanical units." },
    effect: { type: "active", action: "heal", targets: { unitClasses: ["nonMechanical"] }, radius: 180, maxTargets: 5, cooldown: seconds(18), healAmount: 90 }
  },
  veteranInnerFire: {
    id: "veteranInnerFire",
    name: { zh: "\u5FC3\u7075\u4E4B\u706B", en: "Inner Fire" },
    icon: "\u2726",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 35%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002\u77ED\u65F6\u9632\u62A4\u53EA\u53D6\u6700\u5F3A\u3002", en: "Active / autocast: up to 5 allies within 180 take 35% less damage for 8 seconds. Cooldown: 24 seconds. Only the strongest temporary ward applies." },
    effect: { type: "active", action: "buff", radius: 180, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { damageReduction: 0.35 } }
  },
  veteranRenewal: {
    id: "veteranRenewal",
    name: { zh: "\u4F11\u517B\u5E87\u62A4", en: "Renewing Presence" },
    icon: "\u274B",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A150 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u6BCF\u79D2\u6062\u590D 3 \u70B9\u751F\u547D\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\uFF0C\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Aura: allies within 150, including self, restore 3 health per second. Identical auras do not stack. Does not affect mechanical units." },
    effect: { type: "aura", targets: { unitClasses: ["nonMechanical"] }, radius: 150, modifiers: { regenPerSecond: 3 } }
  },
  veteranSiegeDrill: {
    id: "veteranSiegeDrill",
    name: { zh: "\u6D4B\u8DDD\u8BAD\u7EC3", en: "Rangefinding" },
    icon: "\u2316",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u653B\u51FB\u5C04\u7A0B\u63D0\u9AD8 10%\uFF1B\u6700\u5C0F\u5C04\u7A0B\u4FDD\u6301\u4E0D\u53D8\u3002", en: "Passive: gain 10% attack range. Minimum range is unchanged." },
    effect: { type: "passive", modifiers: { attackRangeMultiplier: 1.1 } }
  },
  veteranEndurance: {
    id: "veteranEndurance",
    name: { zh: "\u575A\u97E7\u6062\u590D", en: "Enduring Recovery" },
    icon: "\u2665",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u975E\u673A\u68B0\u5355\u4F4D\u81EA\u8EAB\u6BCF\u79D2\u6062\u590D 6 \u70B9\u751F\u547D\u3002", en: "Passive: non-mechanical units restore 6 health per second." },
    effect: { type: "passive", targets: { unitClasses: ["nonMechanical"] }, modifiers: { regenPerSecond: 6 } }
  }
};

// src/shared/ship-equipment.ts
var SHIP_HULL_COST = { cutter: 160, transport: 240, warship: 320, bombardShip: 470, fireShip: 340, carrier: 420, shipOfTheLine: 1080 };
var SHIP_WEAPONS = {
  shipCannon: { cost: 220, mass: 160, hp: 90, damage: 20, range: 312, cooldown: seconds(2), aimSpeed: 440, weapon: { presentation: "cannon", delivery: "bolt", radius: 8, blastRadius: 48, maxHits: 1, navalMultiplier: 2, hullDamageShare: 1.25 }, art: "warship" },
  shipMortar: { cost: 330, mass: 240, hp: 100, damage: 36, range: 576, cooldown: seconds(3.6), aimSpeed: 400, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2, navalMultiplier: 1.7, hullDamageShare: 1.5 }, art: "bombardShip" },
  flameProjector: { cost: 180, mass: 120, hp: 80, damage: 10, range: 144, cooldown: seconds(1.2), aimSpeed: 480, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 }, art: "fireShip" }
};

// src/shared/unit-value.ts
var VETERANCY_GAIN_PER_STAR = 1 / 3;
function unitValue(def) {
  return def.cost > 0 ? def.cost : (def.creepFoodPower ?? 2) * 36 * (def.threat ?? 1);
}
function creepGoldBounty(foodPower, threat = 1) {
  return Math.max(20, Math.round((20 * foodPower + 1.25 * foodPower ** 2) * threat / 5) * 5);
}

// src/shared/damage-types.ts
var DAMAGE_PROFILES = {
  MELEE_CUT: { school: "physical", delivery: "melee", physicalType: "cut", origin: "unit" },
  MELEE_PIERCE: { school: "physical", delivery: "melee", physicalType: "pierce", origin: "unit" },
  MELEE_BLUNT: { school: "physical", delivery: "melee", physicalType: "blunt", origin: "unit" },
  RANGED_PIERCE: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "unit" },
  RANGED_BLUNT: { school: "physical", delivery: "ranged", physicalType: "blunt", origin: "unit" },
  FIRE_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", element: "fire", origin: "unit" },
  MAGIC_MELEE: { school: "magic", delivery: "melee", element: "arcane", origin: "unit" },
  MAGIC_RANGED: { school: "magic", delivery: "ranged", element: "arcane", origin: "unit" },
  FIRE_RANGED: { school: "magic", delivery: "ranged", element: "fire", origin: "unit" },
  TOWER_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "tower" },
  ARCANE: { school: "magic", delivery: "effect", element: "arcane", origin: "spell" },
  BURNING: { school: "magic", delivery: "effect", element: "fire", origin: "spell" },
  POISON: { school: "magic", delivery: "effect", element: "poison", origin: "spell" },
  LIGHTNING: { school: "magic", delivery: "ranged", element: "lightning", origin: "spell" },
  STORM: { school: "magic", delivery: "effect", element: "lightning", origin: "spell" },
  EXPLOSION: { school: "physical", delivery: "effect", physicalType: "blunt", origin: "spell" }
};
var P = DAMAGE_PROFILES;
var UNIT_DAMAGE_PROFILES = {
  worker: P.MELEE_CUT,
  footman: P.MELEE_CUT,
  archer: P.RANGED_PIERCE,
  horseArcher: P.RANGED_PIERCE,
  raider: P.MELEE_CUT,
  lancer: P.MELEE_PIERCE,
  ashWarden: P.MELEE_PIERCE,
  emberRavager: P.MELEE_CUT,
  cinderRunner: P.MELEE_CUT,
  sparkArcher: P.FIRE_ARROW,
  ashHexer: P.MAGIC_RANGED,
  knight: P.MELEE_CUT,
  priest: P.MAGIC_RANGED,
  summoner: P.MAGIC_RANGED,
  witch: P.MAGIC_RANGED,
  golem: P.MELEE_BLUNT,
  ashChieftain: P.MELEE_CUT,
  cinderRevenant: P.MELEE_CUT,
  spirit: P.MAGIC_MELEE,
  mercenary: P.MELEE_CUT,
  contractArcher: P.RANGED_PIERCE,
  fieldMedic: P.MAGIC_RANGED,
  wildling: P.MELEE_BLUNT,
  mossGnawer: P.MELEE_PIERCE,
  thornSlinger: P.RANGED_PIERCE,
  barkMender: P.MAGIC_RANGED,
  stonebackBrute: P.MELEE_BLUNT,
  gladeWitch: P.MAGIC_RANGED,
  // Bare transport/carrier hulls cannot attack; a mounted gun supplies its own profile.
  transport: P.MELEE_BLUNT,
  warship: P.RANGED_BLUNT,
  shipOfTheLine: P.RANGED_BLUNT,
  cutter: P.RANGED_PIERCE,
  bombardShip: P.RANGED_BLUNT,
  fireShip: P.FIRE_RANGED,
  carrier: P.MELEE_BLUNT,
  siegeRam: P.MELEE_BLUNT,
  ballista: P.RANGED_PIERCE,
  catapult: P.RANGED_BLUNT,
  organGun: P.RANGED_PIERCE,
  ancientStag: P.MELEE_PIERCE,
  murlocPeon: P.MELEE_PIERCE,
  murlocHunter: P.RANGED_PIERCE,
  tidePriest: P.MAGIC_RANGED,
  deepSnapper: P.MELEE_PIERCE,
  rubbleGolem: P.MELEE_BLUNT,
  rockGolem: P.MELEE_BLUNT,
  graniteGolem: P.MELEE_BLUNT,
  ogreWarrior: P.MELEE_BLUNT,
  ogreMage: P.MAGIC_RANGED,
  ogreLord: P.MELEE_BLUNT,
  spiderling: P.MELEE_PIERCE,
  venomSpider: P.MELEE_PIERCE,
  spiderQueen: P.MELEE_PIERCE,
  dragonWhelp: P.FIRE_RANGED,
  redDragon: P.FIRE_RANGED
};
var WEAPON_DAMAGE_PROFILES = {
  melee: P.MELEE_BLUNT,
  arrow: P.RANGED_PIERCE,
  spear: P.RANGED_PIERCE,
  stone: P.RANGED_BLUNT,
  magic: P.MAGIC_RANGED,
  fire: P.FIRE_RANGED,
  bolt: P.RANGED_PIERCE,
  cannon: P.RANGED_BLUNT,
  mortar: P.RANGED_BLUNT,
  flame: P.FIRE_RANGED,
  grapeshot: P.RANGED_PIERCE
};
var ITEM_DAMAGE_PROFILES = {
  greatSword: P.MELEE_CUT,
  shipCannon: P.RANGED_BLUNT,
  shipMortar: P.RANGED_BLUNT,
  flameProjector: P.FIRE_RANGED,
  flameCloak: P.BURNING,
  lightningRod: P.LIGHTNING,
  stormStaff: P.STORM,
  breachCharge: P.EXPLOSION
};
var ABILITY_DAMAGE_PROFILES = {
  curse: P.ARCANE,
  ashCurse: P.ARCANE,
  pinningBolt: P.RANGED_PIERCE,
  incendiaryFlume: P.FIRE_RANGED
};

// src/shared/damage-reduction.ts
var HEAVY_ARMOR_DAMAGE = { rangedUnit: 0.5, tower: 0.7 };
var DAMAGE_REDUCTION_RULES = {
  armor: { stacking: "highest", cap: 1 },
  equipment: { stacking: "add", cap: 0.3 },
  passive: { stacking: "highest", cap: 1 },
  aura: { stacking: "highest", cap: 1 },
  ward: { stacking: "highest", cap: 1 }
};
var GROUPS = Object.keys(DAMAGE_REDUCTION_RULES);

// src/shared/transport-role.ts
var TRANSPORT_COMBAT = {
  rangedDamageTaken: HEAVY_ARMOR_DAMAGE.tower,
  passengerDamageMultiplier: 0.5
};

// src/shared/catalog.ts
var SLOW_TICKS = seconds(3);
var POISON_TICKS = seconds(4);
var UNIT_RULES = {
  worker: { hp: 70, speed: 60, radius: 15, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.7), cost: 75, trainTime: seconds(7), supplyUsed: 1, abilities: [] },
  footman: { hp: 145, speed: 62, radius: 18, attackDamage: 16, attackRange: 48, attackCooldown: seconds(1.1), cost: 100, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  archer: { hp: 83, speed: 60, radius: 16, attackDamage: 13, attackRange: 319.2, aimSpeed: 480, attackCooldown: seconds(1.5), cost: 115, trainTime: seconds(7.75), supplyUsed: 2, abilities: [] },
  // The cavalry strikes from the saddle with a reach a little under the lancer's 74 (it had a footman's, 48 and 52).
  horseArcher: { hp: 109, speed: 90, radius: 19, attackDamage: 10, attackRange: 264, aimSpeed: 600, attackCooldown: seconds(1.5), cost: 150, trainTime: seconds(10), supplyUsed: 2, abilities: [], tier: 2, aimMoveTolerance: 72 },
  raider: { hp: 115, speed: 82, radius: 18, attackDamage: 14, attackRange: 72, attackCooldown: seconds(1), cost: 115, trainTime: seconds(8.5), supplyUsed: 2, abilities: ["charge"], tier: 2 },
  lancer: { hp: 130, speed: 68, radius: 18, attackDamage: 18, attackRange: 74, attackCooldown: seconds(1.4), cost: 110, trainTime: seconds(8.75), supplyUsed: 2, abilities: [] },
  ashWarden: { hp: 165, speed: 60, radius: 19, attackDamage: 15, attackRange: 52, attackCooldown: seconds(1.15), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  emberRavager: { hp: 118, speed: 76, radius: 18, attackDamage: 20, attackRange: 52, attackCooldown: seconds(1.25), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  cinderRunner: { hp: 96, speed: 87, radius: 17, attackDamage: 14, attackRange: 48, attackCooldown: seconds(0.95), cost: 110, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  sparkArcher: { hp: 85, speed: 63, radius: 16, attackDamage: 9, attackRange: 288, aimSpeed: 540, attackCooldown: seconds(1.35), cost: 110, trainTime: seconds(7.25), supplyUsed: 2, abilities: [] },
  ashHexer: { hp: 82, speed: 64, radius: 16, attackDamage: 7, attackRange: 240, aimSpeed: 520, attackCooldown: seconds(1.7), cost: 140, trainTime: seconds(9), supplyUsed: 2, abilities: ["ashCurse"], tier: 2 },
  knight: { hp: 220, speed: 72, radius: 22, attackDamage: 24, attackRange: 72, attackCooldown: seconds(1.3), cost: 190, trainTime: seconds(11.5), supplyUsed: 3, abilities: ["charge"], armor: "heavy", tier: 3 },
  priest: { hp: 90, speed: 60, radius: 16, attackDamage: 7, attackRange: 201.6, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 135, trainTime: seconds(9.25), supplyUsed: 2, abilities: ["heal"], tier: 2 },
  summoner: { hp: 95, speed: 56, radius: 17, attackDamage: 8, attackRange: 218.4, aimSpeed: 400, attackCooldown: seconds(1.9), cost: 180, trainTime: seconds(10.5), supplyUsed: 2, abilities: ["summon"], tier: 2 },
  witch: { hp: 92, speed: 62, radius: 16, attackDamage: 8, attackRange: 252, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 145, trainTime: seconds(9.75), supplyUsed: 2, abilities: ["curse"], tier: 2 },
  golem: { unitClass: "mechanical", hp: 340, speed: 42, radius: 28, attackDamage: 34, attackRange: 58, attackCooldown: seconds(2.1), cost: 230, trainTime: seconds(14), supplyUsed: 4, abilities: [], armor: "heavy", tier: 3 },
  // Ember's heavies, raised in the ashen hall and heavy-armored like the grove's knight and golem, but built for
  // other jobs. The chieftain hunts casters and what they summon (half again as much damage to both); the revenant is
  // light for an elite and burns its wounds away, back to full health in about twenty seconds.
  ashChieftain: { hp: 210, speed: 66, radius: 20, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.2), cost: 190, trainTime: seconds(11), supplyUsed: 3, abilities: [], armor: "heavy", casterSlayer: 1.5, tier: 3 },
  cinderRevenant: { hp: 150, speed: 70, radius: 19, attackDamage: 21, attackRange: 52, attackCooldown: seconds(1.15), cost: 210, trainTime: seconds(12), supplyUsed: 3, abilities: [], armor: "heavy", regenPerSecond: 7, tier: 3 },
  spirit: { hp: 85, speed: 70, radius: 15, attackDamage: 13, attackRange: 55, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, abilities: [] },
  mercenary: { hp: 155, speed: 74, radius: 18, attackDamage: 28, attackRange: 62, attackCooldown: seconds(0.9), cost: 160, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  contractArcher: { hp: 93, speed: 64, radius: 16, attackDamage: 19, attackRange: 352.8, aimSpeed: 600, attackCooldown: seconds(1.35), cost: 145, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  fieldMedic: { hp: 105, speed: 62, radius: 16, attackDamage: 8, attackRange: 210.4, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 155, trainTime: seconds(0.05), supplyUsed: 2, abilities: ["heal"] },
  wildling: { hp: 76, speed: 76, radius: 15, attackDamage: 10, attackRange: 42, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  mossGnawer: { hp: 54, speed: 84, radius: 13, attackDamage: 8, attackRange: 34, attackCooldown: seconds(1.3), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  thornSlinger: { hp: 83, speed: 68, radius: 18, attackDamage: 13, attackRange: 132, aimSpeed: 400, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [] },
  barkMender: { hp: 68, speed: 64, radius: 18, attackDamage: 7, attackRange: 88, aimSpeed: 400, attackCooldown: seconds(2.1), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: ["heal"] },
  stonebackBrute: { hp: 210, speed: 72, radius: 24, attackDamage: 28, attackRange: 48, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  gladeWitch: { hp: 110, speed: 66, radius: 22, attackDamage: 13, attackRange: 120, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["curse"] },
  // @@@ships - Both races can board every ship. Troop ferry passengers deal half damage;
  // warships have sturdier hulls and a cannon. Deck space and mass determine crew capacity.
  transport: { unitClass: "mechanical", hp: 270, speed: 64, radius: 30, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.transport, trainTime: seconds(12), supplyUsed: 1, abilities: [], naval: true, ...TRANSPORT_COMBAT },
  warship: { unitClass: "mechanical", hp: 320, speed: 60, radius: 28, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.warship + SHIP_WEAPONS.shipCannon.cost, trainTime: seconds(14), supplyUsed: 3, abilities: [], naval: true, weapon: SHIP_WEAPONS.shipCannon.weapon },
  // Four removable cannons are included in the purchase; the hull has no extra intrinsic shot.
  shipOfTheLine: { unitClass: "mechanical", hp: 740, speed: 46, radius: 48, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.shipOfTheLine + SHIP_WEAPONS.shipCannon.cost * 4, trainTime: seconds(30), supplyUsed: 7, abilities: [], naval: true, armor: "heavy", tier: 3, weapon: SHIP_WEAPONS.shipCannon.weapon },
  cutter: { unitClass: "mechanical", hp: 110, speed: 84, radius: 24, attackDamage: 10, attackRange: 264, aimSpeed: 540, attackCooldown: seconds(1.3), cost: SHIP_HULL_COST.cutter, trainTime: seconds(9), supplyUsed: 2, abilities: [], naval: true, intrinsicAttack: true },
  bombardShip: { unitClass: "mechanical", hp: 260, speed: 44, radius: 32, attackDamage: 36, attackRange: 576, aimSpeed: 400, attackCooldown: seconds(3.6), cost: SHIP_HULL_COST.bombardShip + SHIP_WEAPONS.shipMortar.cost, trainTime: seconds(19), supplyUsed: 4, abilities: [], naval: true, tier: 2, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2 } },
  fireShip: { unitClass: "mechanical", hp: 340, speed: 70, radius: 28, attackDamage: 10, attackRange: 144, aimSpeed: 480, attackCooldown: seconds(1.2), cost: SHIP_HULL_COST.fireShip + SHIP_WEAPONS.flameProjector.cost, trainTime: seconds(15), supplyUsed: 3, abilities: ["incendiaryFlume"], naval: true, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 } },
  carrier: { unitClass: "mechanical", hp: 480, speed: 54, radius: 38, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.carrier, trainTime: seconds(18), supplyUsed: 3, abilities: [], naval: true, ...TRANSPORT_COMBAT, tier: 2 },
  siegeRam: { unitClass: "mechanical", hp: 420, speed: 50, radius: 26, attackDamage: 22, attackRange: 64, attackCooldown: seconds(1.8), cost: 240, trainTime: seconds(16), supplyUsed: 3, abilities: [], armor: "heavy", tier: 2, weapon: { presentation: "melee", delivery: "ram", buildingMultiplier: 3.3 } },
  ballista: { unitClass: "mechanical", hp: 150, speed: 46, radius: 24, attackDamage: 27, attackRange: 472, aimSpeed: 420, attackCooldown: seconds(2.4), cost: 300, trainTime: seconds(15), supplyUsed: 3, abilities: ["pinningBolt"], tier: 2, weapon: { presentation: "bolt", delivery: "bolt", radius: 18, maxHits: 3, pierceShare: 0.7, buildingMultiplier: 0.75, navalMultiplier: 1.4 } },
  catapult: { unitClass: "mechanical", hp: 180, speed: 38, radius: 27, attackDamage: 38, attackRange: 608, aimSpeed: 360, attackCooldown: seconds(3.8), cost: 390, trainTime: seconds(19), supplyUsed: 4, abilities: [], tier: 2, weapon: { presentation: "stone", delivery: "shell", radius: 90, minRange: 180, buildingMultiplier: 2 } },
  organGun: { unitClass: "mechanical", hp: 190, speed: 46, radius: 25, attackDamage: 12, attackRange: 304, aimSpeed: 480, attackCooldown: seconds(2.5), cost: 350, trainTime: seconds(17), supplyUsed: 3, abilities: [], tier: 2, weapon: { presentation: "grapeshot", delivery: "cone", coneAngle: 0.42, burst: 3, buildingMultiplier: 0.45 } },
  ancientStag: { hp: 360, speed: 88, radius: 32, attackDamage: 38, attackRange: 68, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [] },
  // @@@creep-families - The camp families (see shared/camps.ts), a creep's level its food power, bounty and experience by
  // level (20/35/50/68/85/100/130 gold at levels 1-8). A tier's camps are as hard as the old wildling camps of that tier:
  // health and damage were set so that a squad of two footmen to an archer sized to the tier (3, 5, 7) loses as much,
  // for the camp's level, clearing the new templates as the old ones, within a tenth on average (green 0.96, orange
  // 1.09, red 1.06); a power changes how a camp fights, not how hard it is. Each has one trait or ability at most (see
  // @@@creep-traits), and none reaches past a tower's 480, so no creep wakes from farther than today. None is wider
  // than 28: a blow's reach is measured from center to center, and a footman (radius 18, reach 48) could not strike a
  // wider one through their bodies.
  murlocPeon: { hp: 80, speed: 72, radius: 14, attackDamage: 11, attackRange: 40, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  murlocHunter: { hp: 98, speed: 72, radius: 15, attackDamage: 13, attackRange: 120, aimSpeed: 480, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], slowOnHit: true, threat: 1.05 },
  tidePriest: { hp: 100, speed: 64, radius: 17, attackDamage: 10, attackRange: 160, aimSpeed: 440, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["heal"] },
  deepSnapper: { hp: 350, speed: 70, radius: 26, attackDamage: 31, attackRange: 52, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [], armor: "heavy", threat: 1.25 },
  rubbleGolem: { unitClass: "mechanical", hp: 190, speed: 50, radius: 22, attackDamage: 22, attackRange: 48, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [], armor: "heavy" },
  rockGolem: { unitClass: "mechanical", hp: 235, speed: 50, radius: 25, attackDamage: 25, attackRange: 52, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [], armor: "heavy", threat: 1.3 },
  graniteGolem: { unitClass: "mechanical", hp: 390, speed: 48, radius: 28, attackDamage: 35, attackRange: 58, attackCooldown: seconds(2.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: ["stomp"], armor: "heavy", threat: 1.3 },
  ogreWarrior: { hp: 178, speed: 68, radius: 22, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  ogreMage: { hp: 145, speed: 64, radius: 22, attackDamage: 15, attackRange: 160, aimSpeed: 400, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: ["bloodlust"], threat: 1.15 },
  ogreLord: { hp: 380, speed: 68, radius: 28, attackDamage: 34, attackRange: 56, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: [], threat: 1.35 },
  spiderling: { hp: 65, speed: 88, radius: 12, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  venomSpider: { hp: 105, speed: 84, radius: 15, attackDamage: 13, attackRange: 44, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], poisonOnHit: true, threat: 1.7 },
  spiderQueen: { hp: 350, speed: 80, radius: 26, attackDamage: 33, attackRange: 52, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: ["web"] },
  dragonWhelp: { hp: 170, speed: 84, radius: 22, attackDamage: 17, attackRange: 144, aimSpeed: 540, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [] },
  redDragon: { hp: 600, speed: 80, radius: 28, attackDamage: 42, attackRange: 176, aimSpeed: 480, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 8, abilities: [], splash: true, threat: 1.3 }
};
var UNIT_DEFS = Object.fromEntries(
  Object.entries(UNIT_RULES).map(([kind, row]) => {
    const def = { unitClass: "nonMechanical", ...row, xpReward: 0 };
    def.xpReward = kind === "spirit" ? 0 : Math.round(unitValue(def) / 3);
    if (def.creepFoodPower) def.goldBounty = creepGoldBounty(def.creepFoodPower, def.threat);
    return [kind, def];
  })
);
var UNIT_KINDS = Object.keys(UNIT_DEFS);
var NAVAL_KINDS = new Set(UNIT_KINDS.filter((kind) => UNIT_DEFS[kind].naval));
var ABILITY_KINDS = ["heal", "summon", "curse", "ashCurse", "charge", "stomp", "bloodlust", "web", "pinningBolt", "incendiaryFlume", ...VETERAN_ACTIVE_SKILL_IDS];
var CURSE_SUMMONED_DAMAGE = 100;
var ABILITY_DEFS = {
  ...Object.fromEntries(VETERAN_ACTIVE_SKILL_IDS.map((skill) => {
    const effect = VETERAN_SKILLS[skill].effect;
    if (effect.type !== "active") throw new Error(`Veteran ability ${skill} must be active`);
    return [skill, {
      behavior: "veteran",
      skill,
      range: effect.radius,
      plannerRange: effect.radius,
      cooldown: effect.cooldown,
      effectType: effect.action === "heal" ? "heal" : effect.modifiers.damageReduction ? "guardianField" : "bloodlust",
      autocast: "on",
      ...effect.targets ? { targets: effect.targets } : {}
    }];
  })),
  pinningBolt: { behavior: "weapon", target: "enemy", weapon: { presentation: "bolt", delivery: "bolt", radius: 20, maxHits: 3, pierceShare: 0.7 }, range: 472, plannerRange: 472, cooldown: seconds(14), damage: 36, rootTicks: seconds(2), effectType: "siegeBolt", autocast: "none" },
  incendiaryFlume: { behavior: "weapon", target: "point", weapon: { presentation: "fire", delivery: "shell", radius: 85, buildingMultiplier: 0.7 }, range: 224, plannerRange: 224, cooldown: seconds(18), damage: 14, burnTicks: seconds(4), effectType: "burningGround", autocast: "none" },
  // With spells on their own cooldowns (see ability-cooldowns) a healer heals through every fight. At one heal every 6s,
  // 9 health a second, two mirrored default AIs fought for 41 minutes on verdantCrossroads (12.7 before) and never ended on
  // wildMarches. Every 12s is Warcraft III's measure: a priest's mana holds it to about a third of a footman's damage.
  heal: { behavior: "heal", targets: { unitClasses: ["nonMechanical"] }, range: 240, plannerRange: 220, cooldown: seconds(12), healAmount: 55, effectType: "heal", autocast: "on" },
  summon: { behavior: "summon", range: 260, plannerRange: 240, cooldown: seconds(40), summonKind: "spirit", summonDuration: seconds(60), effectType: "summon", autocast: "on" },
  curse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.4, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "curse", autocast: "on" },
  ashCurse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.45, scorchedDamageMultiplier: 0.3, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "scorch", autocast: "on" },
  // The cavalry's charge: from 180 to 300 away, a slide that would carry the rider `drive` past the unit it meets (see
  // @@@charge), and a blow of twice the weapon's.
  charge: { behavior: "charge", minRange: 180, range: 300, plannerRange: 288, cooldown: seconds(15), damageMultiplier: 2, drive: 100, effectType: "chargeTrail", autocast: "on" },
  // @@@creep-abilities - The creeps' own, cast by themselves only: a granite golem's stomp stuns every enemy unit within
  // 160 for 1.5s, every 12s; an ogre mage's bloodlust quickens a fighting ally's blows by 30% for 15s, every 20s; a spider
  // queen's web roots one enemy within 220 in place for 2s, every 10s.
  stomp: { behavior: "stomp", range: 160, plannerRange: 150, cooldown: seconds(12), effectDuration: seconds(1.5), effectType: "stomp", autocast: "on" },
  bloodlust: { behavior: "bloodlust", range: 300, plannerRange: 280, cooldown: seconds(20), effectDuration: seconds(15), attackSpeed: 1.3, effectType: "bloodlust", autocast: "on" },
  web: { behavior: "web", range: 220, plannerRange: 200, cooldown: seconds(10), effectDuration: seconds(2), effectType: "web", autocast: "on" }
};
var BUILDING_RULES = {
  townHall: { hp: 900, radius: 48, cost: 400, buildTime: seconds(28), researches: ["buildingDurability"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 8 },
  barracks: { race: "grove", hp: 620, radius: 40, cost: 170, buildTime: seconds(11), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  archeryRange: { race: "grove", hp: 520, radius: 38, cost: 150, buildTime: seconds(10), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  stables: { race: "grove", hp: 560, radius: 42, cost: 175, buildTime: seconds(11.5), researches: ["speedTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  sanctum: { race: "grove", hp: 500, radius: 38, cost: 175, buildTime: seconds(11.25), researches: ["leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  workshop: { hp: 580, radius: 42, cost: 205, buildTime: seconds(12.5), researches: ["rangeTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  defenseTower: { neutralDamageMultiplier: 0.5, hp: 200, radius: 30, cost: 125, buildTime: seconds(6.5), researches: [], attackDamage: 16, attackRange: 480, attackCooldown: seconds(1.5), supplyProvided: 0 },
  moonWell: { race: "grove", hp: 300, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  emberForge: { race: "ember", hp: 560, radius: 40, cost: 165, buildTime: seconds(10.5), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  cinderSpire: { race: "ember", hp: 500, radius: 38, cost: 170, buildTime: seconds(10.75), researches: ["speedTraining", "rangeTraining", "leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  emberShrine: { race: "ember", hp: 280, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  // Ember's heavy-unit hall, its stables and workshop in one: one building for both heavies, priced above either.
  ashenHall: { race: "ember", hp: 600, radius: 42, cost: 215, buildTime: seconds(13), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  // Supply is the tech (see unit-tiers), so it is dear: a farm's 6 cost 120, a hall's 8 are priced the same inside its 400.
  farm: { hp: 320, radius: 30, cost: 120, buildTime: seconds(7), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 6 },
  // Ships are built here (see @@@naval); every race builds it, as it does a tower or a farm.
  shipyard: { hp: 600, radius: 44, cost: 170, buildTime: seconds(12), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0, shore: true }
};
var BUILDABLE_BUILDING_KINDS = Object.keys(BUILDING_RULES);
var COMMON_PRODUCTION = {
  worker: { at: "townHall" },
  transport: { at: "shipyard" },
  warship: { at: "shipyard" },
  shipOfTheLine: { at: "shipyard" },
  cutter: { at: "shipyard" },
  bombardShip: { at: "shipyard" },
  fireShip: { at: "shipyard" },
  carrier: { at: "shipyard" }
};
var RACE_TECH_RULES = {
  grove: { units: {
    ...COMMON_PRODUCTION,
    footman: { at: "barracks" },
    lancer: { at: "barracks" },
    archer: { at: "archeryRange" },
    horseArcher: { at: "stables" },
    raider: { at: "stables" },
    knight: { at: "stables" },
    priest: { at: "sanctum" },
    summoner: { at: "sanctum" },
    witch: { at: "sanctum" },
    golem: { at: "workshop" },
    ballista: { at: "workshop" }
  } },
  ember: { units: {
    ...COMMON_PRODUCTION,
    ashWarden: { at: "emberForge" },
    emberRavager: { at: "emberForge" },
    cinderRunner: { at: "emberForge" },
    sparkArcher: { at: "cinderSpire" },
    priest: { at: "cinderSpire" },
    ashHexer: { at: "cinderSpire" },
    summoner: { at: "cinderSpire" },
    ashChieftain: { at: "ashenHall" },
    cinderRevenant: { at: "ashenHall" },
    siegeRam: { at: "workshop" },
    catapult: { at: "workshop" },
    organGun: { at: "workshop" }
  } }
};
var PRODUCTION = {
  grove: RACE_TECH_RULES.grove.units,
  ember: RACE_TECH_RULES.ember.units
};
function trainingBuildingFor(race, kind) {
  return PRODUCTION[race][kind]?.at;
}
function canTrainAt(race, building, kind) {
  return trainingBuildingFor(race, kind) === building;
}
var TRAINABLE_UNIT_KINDS = UNIT_KINDS.filter(
  (kind) => canTrainForAnyRace(kind)
);
function canTrainForAnyRace(kind) {
  return Object.values(PRODUCTION).some((units) => units[kind] !== void 0);
}
var TRAINING_BY_RACE = Object.fromEntries(
  Object.keys(PRODUCTION).map((race) => [race, Object.fromEntries(
    BUILDABLE_BUILDING_KINDS.map((building) => [
      building,
      Object.freeze(TRAINABLE_UNIT_KINDS.filter((kind) => canTrainAt(race, building, kind)))
    ])
  )])
);
var BUILDING_DEFS = Object.fromEntries(
  BUILDABLE_BUILDING_KINDS.map((kind) => [kind, { ...BUILDING_RULES[kind], trains: TRAINABLE_UNIT_KINDS.filter((unit) => Object.values(PRODUCTION).some((units) => units[unit]?.at === kind)) }])
);
var ORDINARY_COMBAT_UNITS = TRAINABLE_UNIT_KINDS.filter((kind) => kind !== "worker");
var UPGRADE_RULES = {
  weaponTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 150, researchTime: seconds(34.5), attackMultiplier: 1.15 },
      { cost: 175, researchTime: seconds(46.5), attackMultiplier: 1.3 },
      { cost: 200, researchTime: seconds(60), attackMultiplier: 1.45 }
    ]
  },
  reinforcedPlating: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 180, researchTime: seconds(40.5), maxHpMultiplier: 1.15 },
      { cost: 210, researchTime: seconds(52.5), maxHpMultiplier: 1.3 },
      { cost: 240, researchTime: seconds(66), maxHpMultiplier: 1.45 }
    ]
  },
  buildingDurability: {
    affectedUnitKinds: [],
    levels: [
      { cost: 200, researchTime: seconds(54), buildingMaxHpMultiplier: 1.2 }
    ]
  },
  // A tenth faster a level: at a quarter a level (1.25, 1.38, 1.5) a footman at the third outran a raider untrained (4.5
  // against 82), and the riders' speed was theirs no more.
  speedTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 185, researchTime: seconds(46), speedMultiplier: 1.1 },
      { cost: 285, researchTime: seconds(60), speedMultiplier: 1.2 },
      { cost: 420, researchTime: seconds(76), speedMultiplier: 1.3 }
    ]
  },
  rangeTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 195, researchTime: seconds(48), attackRangeMultiplier: 1.15 },
      { cost: 305, researchTime: seconds(64), attackRangeMultiplier: 1.25 },
      { cost: 450, researchTime: seconds(82), attackRangeMultiplier: 1.35 }
    ]
  },
  leadership: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    // @@@leadership-by-stars - A second and a third star are worth more than the first. One star regenerates 1, 2 and 3
    // health a second by the research's level, as it always did; two stars 3, 5 and 7; three stars 6, 9 and 12. A single
    // three-star veteran repays the first level on its own: 6 a second for 200 gold, where a moon well gives 3.3 for 115.
    // Each later level adds one a second per star, for armies with many veterans. At one a second per star for 220 gold,
    // the two to four stars a gauntlet army carries at 5-13 minutes regenerated half of what a well bought for the gold.
    levels: [
      { cost: 200, researchTime: seconds(52), veteranRegenByStars: [1, 3, 6] },
      { cost: 300, researchTime: seconds(70), veteranRegenByStars: [2, 5, 9] },
      { cost: 450, researchTime: seconds(90), veteranRegenByStars: [3, 7, 12] }
    ]
  }
};
var UPGRADE_KINDS = ["weaponTraining", "reinforcedPlating", "buildingDurability", "speedTraining", "rangeTraining", "leadership"];
var UPGRADE_DEFS = Object.fromEntries(
  UPGRADE_KINDS.map((kind) => [kind, {
    ...UPGRADE_RULES[kind],
    researchBuildingKinds: BUILDABLE_BUILDING_KINDS.filter((building) => BUILDING_DEFS[building].researches.includes(kind))
  }])
);
function canResearchAt(race, building, upgrade) {
  const rules = BUILDING_DEFS[building];
  return (rules.race === void 0 || rules.race === race) && rules.researches.includes(upgrade);
}
function raceDef(id, name, note) {
  const owns = (race) => race === void 0 || race === id;
  return {
    id,
    name,
    note,
    trainableUnits: TRAINABLE_UNIT_KINDS.filter((kind) => trainingBuildingFor(id, kind) !== void 0),
    buildableBuildings: BUILDABLE_BUILDING_KINDS.filter((kind) => owns(BUILDING_DEFS[kind].race)),
    upgrades: UPGRADE_KINDS.filter((upgrade) => BUILDABLE_BUILDING_KINDS.some((building) => canResearchAt(id, building, upgrade)))
  };
}
var RACE_DEFS = {
  grove: raceDef("grove", "Grove Kin", "Durable line holders, conventional ranged units, heavy tech, and moon-well recovery."),
  ember: raceDef("ember", "Ember Pact", "Faster fragile fighters, early support casters, ashen-hall heavies, and ember-shrine recovery.")
};

// src/shared/ship-collisions.ts
var frames = /* @__PURE__ */ new WeakMap();
var CELL = 192;
function unitBody(body) {
  return "order" in body;
}
function activeBody(map, body) {
  return body.hp > 0 && (!unitBody(body) || !body.deck && (shipProfile(body) || isWalkable(map, body.x, body.y, "land")));
}
function velocity(body) {
  if (!unitBody(body)) return { x: 0, y: 0 };
  const motion = body.sailing, speed = motion?.speed ?? 0, heading = motion?.heading ?? 0;
  if (motion && speed <= 1e-7 && body.pushX === void 0) return { x: 0, y: 0 };
  return { x: motion?.velocityX ?? speed * detCos(heading) + (body.pushX ?? 0), y: motion?.velocityY ?? speed * detSin(heading) + (body.pushY ?? 0) };
}
function physicalSolidOutline(map, body) {
  const half = map.terrain ? footprintHalf(body.radius, map.terrain.cell) : body.radius;
  return [{ x: body.x - half, y: body.y - half }, { x: body.x + half, y: body.y - half }, { x: body.x + half, y: body.y + half }, { x: body.x - half, y: body.y + half }];
}
function circleOutline(body) {
  const count = 32, radius = body.radius / detCos(Math.PI / count);
  return Array.from({ length: count }, (_, i) => ({ x: body.x + radius * detCos(i * Math.PI * 2 / count), y: body.y + radius * detSin(i * Math.PI * 2 / count) }));
}
function hullOutline(ship, pose) {
  const c = detCos(pose.heading), s = detSin(pose.heading);
  return shipProfile(ship).hull.map((p) => ({ x: pose.x + p.x * c - p.y * s, y: pose.y + p.x * s + p.y * c }));
}
function outline2(map, body) {
  return unitBody(body) ? shipProfile(body) ? hullOutline(body, { x: body.x, y: body.y, heading: body.sailing?.heading ?? 0 }) : circleOutline(body) : physicalSolidOutline(map, body);
}
function radiusOf(map, body) {
  const profile = unitBody(body) && shipProfile(body);
  return profile ? polygonRadius(profile.hull) : unitBody(body) ? body.radius * 1.01 : Math.SQRT2 * (map?.terrain ? footprintHalf(body.radius, map.terrain.cell) : body.radius);
}
function updateEntry(frame, entry) {
  const { body } = entry, radius = entry.radius + 24;
  const left = Math.floor((body.x - radius) / CELL), right = Math.floor((body.x + radius) / CELL), top = Math.floor((body.y - radius) / CELL), bottom = Math.floor((body.y + radius) / CELL);
  const bounds = `${left},${right},${top},${bottom}`;
  if (entry.bounds === bounds) return;
  const ship = unitBody(body) && shipProfile(body);
  for (const key of entry.keys) for (const buckets of ship ? [frame.buckets, frame.shipBuckets] : [frame.buckets]) {
    const bucket = buckets.get(key);
    bucket?.delete(entry);
    if (bucket?.size === 0) buckets.delete(key);
  }
  entry.keys = [];
  entry.bounds = bounds;
  for (let y = top; y <= bottom; y++)
    for (let x = left; x <= right; x++) {
      const key = `${x},${y}`;
      let bucket = frame.buckets.get(key);
      if (!bucket) frame.buckets.set(key, bucket = /* @__PURE__ */ new Set());
      bucket.add(entry);
      entry.keys.push(key);
      if (ship) {
        let ships = frame.shipBuckets.get(key);
        if (!ships) frame.shipBuckets.set(key, ships = /* @__PURE__ */ new Set());
        ships.add(entry);
      }
    }
}
function beginShipCollisionFrame(units, map, solids = [], vessels = units) {
  let frame = frames.get(units);
  if (frame) {
    frame.buckets.clear();
    frame.shipBuckets.clear();
    frame.entries.clear();
    frame.velocities.clear();
    frame.yawRates.clear();
    frame.impacts.length = 0;
    frame.hitPairs.clear();
    if (map) frame.map = map;
    else delete frame.map;
  } else {
    frame = { ...map ? { map } : {}, hasShips: false, buckets: /* @__PURE__ */ new Map(), shipBuckets: /* @__PURE__ */ new Map(), entries: /* @__PURE__ */ new Map(), velocities: /* @__PURE__ */ new Map(), yawRates: /* @__PURE__ */ new Map(), impacts: [], hitPairs: /* @__PURE__ */ new Set() };
    frames.set(units, frame);
  }
  frame.hasShips = vessels.some((unit) => unit.hp > 0 && isShipKind(unit.kind));
  if (!frame.hasShips) return;
  for (let i = 0; i < units.length + solids.length; i++) {
    const body = i < units.length ? units[i] : solids[i - units.length];
    if (body.hp <= 0 || unitBody(body) && body.deck) continue;
    const entry = { body, radius: radiusOf(map, body), keys: [] };
    frame.entries.set(body, entry);
    frame.velocities.set(body, velocity(body));
    updateEntry(frame, entry);
    if (unitBody(body) && body.sailing) frame.yawRates.set(body, body.sailing.yawRate ?? 0);
  }
}
function frameFor(units, map) {
  if (!frames.has(units)) beginShipCollisionFrame(units, map);
  const frame = frames.get(units);
  frame.map = map;
  return frame;
}
function nearby(frame, from, to, radius, shipsOnly = false) {
  const found = /* @__PURE__ */ new Set();
  const buckets = shipsOnly ? frame.shipBuckets : frame.buckets;
  for (let y = Math.floor((Math.min(from.y, to.y) - radius) / CELL); y <= Math.floor((Math.max(from.y, to.y) + radius) / CELL); y++)
    for (let x = Math.floor((Math.min(from.x, to.x) - radius) / CELL); x <= Math.floor((Math.max(from.x, to.x) + radius) / CELL); x++)
      for (const entry of buckets.get(`${x},${y}`) ?? []) found.add(entry);
  return [...found].sort((a, b) => a.body.id.localeCompare(b.body.id));
}
function segmentContact(from, to, polygon) {
  const clip = clipToConvex(from, to, polygon);
  if (!clip || clip[0] >= 1 - 1e-8 || clip[1] - clip[0] < 1e-8) return;
  const dx = to.x - from.x, dy = to.y - from.y, mid = (clip[0] + clip[1]) / 2;
  if (polygonPlanes(polygon).some((p) => (from.x + dx * mid) * p.x + (from.y + dy * mid) * p.y <= p.min + 1e-6)) return;
  const planes2 = polygonPlanes(polygon);
  let distance = Infinity;
  const gaps = [];
  for (const plane of planes2) {
    const length2 = Math.hypot(plane.x, plane.y), at2 = { x: from.x + dx * clip[0], y: from.y + dy * clip[0] };
    const gap = Math.abs(at2.x * plane.x + at2.y * plane.y - plane.min) / length2;
    gaps.push({ plane, gap });
    distance = Math.min(distance, gap);
  }
  const combined = { x: 0, y: 0 };
  for (const { plane, gap } of gaps) if (gap <= distance + 1e-6) {
    const length2 = Math.hypot(plane.x, plane.y);
    combined.x += plane.x / length2;
    combined.y += plane.y / length2;
  }
  const length = Math.hypot(combined.x, combined.y);
  if (length < 1e-8) return;
  const normal = { x: combined.x / length, y: combined.y / length };
  if (clip[0] <= 1e-8 && dx * normal.x + dy * normal.y <= 1e-8) return;
  return { fraction: Math.max(0, clip[0]), normal };
}
function supportPoint(polygon, normal) {
  let best = -Infinity, x = 0, y = 0, count = 0;
  for (const p of polygon) {
    const dot = p.x * normal.x + p.y * normal.y;
    if (dot > best + 1e-5) {
      best = dot;
      x = p.x;
      y = p.y;
      count = 1;
    } else if (Math.abs(dot - best) <= 1e-5) {
      x += p.x;
      y += p.y;
      count++;
    }
  }
  return { x: x / count, y: y / count };
}
function sweepShape(ship, from, to, bodyPolygon, sum = minkowskiSum) {
  const radius = polygonRadius(shipProfile(ship).hull), turn = headingDifference(from.heading, to.heading);
  const lever = to.pivot ? Math.hypot(from.x - to.pivot.x, from.y - to.pivot.y) : 0;
  const steps2 = Math.max(1, Math.ceil(Math.abs(turn) * Math.sqrt((radius + lever) / (8 * 0.025))));
  for (let i = 0; i < steps2; i++) {
    const a = shipPoseAt(from, to, i / steps2), b = shipPoseAt(from, to, (i + 1) / steps2);
    const shape = convexHull([...hullOutline(ship, { ...a, x: 0, y: 0 }), ...hullOutline(ship, { ...b, x: 0, y: 0 })]);
    const error = turn ? (radius + lever) * (turn / steps2) ** 2 / 8 + 1e-7 : 0;
    const configuration = sum(bodyPolygon, (error ? expandConvex(shape, error) : shape).map((p) => ({ x: -p.x, y: -p.y })));
    let contact = segmentContact(a, b, configuration);
    if (!contact && Math.abs(turn) > 1e-8) {
      const inside = polygonPlanes(configuration).every((p) => a.x * p.x + a.y * p.y > p.min + 1e-6);
      const before = sum(bodyPolygon, hullOutline(ship, { ...a, x: 0, y: 0 }).map((p) => ({ x: -p.x, y: -p.y })));
      if (inside && !polygonPlanes(before).every((p) => a.x * p.x + a.y * p.y > p.min + 1e-6)) {
        const plane = polygonPlanes(configuration).reduce((best, p) => (a.x * p.x + a.y * p.y - p.min) / Math.hypot(p.x, p.y) < (a.x * best.x + a.y * best.y - best.min) / Math.hypot(best.x, best.y) ? p : best);
        const length = Math.hypot(plane.x, plane.y);
        contact = { fraction: 0, normal: { x: plane.x / length, y: plane.y / length } };
      }
    }
    if (!contact) continue;
    const fraction = (i + contact.fraction) / steps2, pose = shipPoseAt(from, to, fraction);
    const own = supportPoint(hullOutline(ship, pose), contact.normal), other = supportPoint(bodyPolygon, { x: -contact.normal.x, y: -contact.normal.y });
    return { fraction, normal: contact.normal, point: { x: (own.x + other.x) / 2, y: (own.y + other.y) / 2 } };
  }
}
function shipBodyClearAtPose(map, ship, pose, bodies) {
  const hull = hullOutline(ship, pose);
  for (const body of bodies) {
    if (body === ship || !activeBody(map, body)) continue;
    if (Math.hypot(body.x - pose.x, body.y - pose.y) > polygonRadius(shipProfile(ship).hull) + radiusOf(map, body)) continue;
    const config = minkowskiSum(outline2(map, body), hull.map((p) => ({ x: pose.x - p.x, y: pose.y - p.y })));
    if (polygonPlanes(config).every((p) => pose.x * p.x + pose.y * p.y > p.min + 1e-6)) return false;
  }
  return true;
}
function shipSolidTraffic(map, ship, units) {
  const frame = frameFor(units, map), radius = polygonRadius(shipProfile(ship).hull);
  const solid = (body) => !("kind" in body && isShipKind(body.kind)) && activeBody(map, body);
  const hasTraffic = [...frame.entries.keys()].some(solid);
  const sums = /* @__PURE__ */ new Map();
  const samePolygon = (a, b) => a.length === b.length && a.every((point, i) => Object.is(point.x, b[i].x) && Object.is(point.y, b[i].y));
  const copyPolygon = (polygon) => polygon.map((point) => ({ x: point.x, y: point.y }));
  const numberKey = (value) => Object.is(value, -0) ? "-0" : String(value);
  const polygonKey = (polygon) => `${polygon.length}:` + polygon.map((point) => `${numberKey(point.x)},${numberKey(point.y)}`).join(";");
  const bodySweep = (from, to, body) => sweepShape(ship, from, to, outline2(map, body), (a, b) => {
    let cached = sums.get(body);
    if (!cached || !samePolygon(a, cached.a)) {
      cached = { a: copyPolygon(a), byHull: /* @__PURE__ */ new Map() };
      sums.set(body, cached);
    }
    const key = polygonKey(b), previous = cached.byHull.get(key);
    if (previous && samePolygon(b, previous.b)) return previous.result;
    const result = minkowskiSum(a, b);
    if (cached.byHull.size >= 128) cached.byHull.delete(cached.byHull.keys().next().value);
    cached.byHull.set(key, { b: copyPolygon(b), result });
    return result;
  });
  return Object.assign((from, to) => !nearby(frame, from, to, radius).some(({ body }) => solid(body) && bodySweep(from, to, body) !== void 0), { hasTraffic });
}

// src/shared/ship-avoidance.ts
var trafficShapes = /* @__PURE__ */ new Map();
var trafficBases = /* @__PURE__ */ new Map();
var trafficBasePoints = 0;
var TRAFFIC_BASE_POINTS = 16384;
var trafficSweepScratch = [];
var TRAFFIC_SWEEP_SCRATCH_POINTS = 2048;
function cacheTrafficBase(key, polygon) {
  if (polygon.length > TRAFFIC_BASE_POINTS) return;
  while (trafficBases.size >= 512 || trafficBasePoints + polygon.length > TRAFFIC_BASE_POINTS) {
    const oldest = trafficBases.keys().next().value;
    trafficBasePoints -= trafficBases.get(oldest).length;
    trafficBases.delete(oldest);
  }
  trafficBases.set(key, polygon);
  trafficBasePoints += polygon.length;
}
function shipTraffic(ship, units, range = 600) {
  const ownProfile = shipProfile(ship), hull = ownProfile.hull, radius = polygonRadius(hull);
  const bodies = [];
  for (const other of shipsIn(units)) {
    if (other === ship || other.hp <= 0 || Math.hypot(other.x - ship.x, other.y - ship.y) >= range) continue;
    const profile = shipProfile(other);
    bodies.push({ other, center: { x: other.x, y: other.y }, radius: polygonRadius(profile.hull), profile, heading: other.sailing?.heading ?? 0 });
  }
  const configurations = /* @__PURE__ */ new Map(), sweeps = /* @__PURE__ */ new Map();
  const configuration = (from, to, body, padding) => {
    const key = `${from}:${to}:${body.other.id}:${padding}`, known = configurations.get(key);
    if (known) return known;
    const profile = body.profile, angle2 = body.heading;
    const baseKey = `${ship.kind}:${ownProfile.length}:${from}:${to}:${body.other.kind}:${profile.length}:${angle2}`;
    const shapeKey = `${baseKey}:${padding}`;
    let polygon = trafficShapes.get(shapeKey);
    if (!polygon) {
      let base = trafficBases.get(baseKey);
      if (!base) {
        const sweepKey = `${from}:${to}`;
        let negative = sweeps.get(sweepKey);
        if (!negative) {
          const turn = headingDifference(from, to), steps2 = Math.max(1, Math.ceil(Math.abs(turn) * radius / 4)), points = [];
          for (let i = 0; i <= steps2; i++) {
            const heading = from + turn * i / steps2, c = detCos(heading), s = detSin(heading);
            for (const p of hull) {
              const index = points.length;
              const point = index < TRAFFIC_SWEEP_SCRATCH_POINTS ? trafficSweepScratch[index] ?? (trafficSweepScratch[index] = { x: 0, y: 0 }) : { x: 0, y: 0 };
              point.x = p.x * c - p.y * s;
              point.y = p.x * s + p.y * c;
              points.push(point);
            }
          }
          let shape = convexHull(points);
          if (turn) shape = expandConvex(shape, radius * (turn / steps2) ** 2 / 8 + 1e-7);
          negative = shape.map((p) => ({ x: -p.x, y: -p.y }));
          sweeps.set(sweepKey, negative);
        }
        if (!body.outline) {
          const c = detCos(angle2), s = detSin(angle2);
          body.outline = profile.hull.map((p) => ({ x: p.x * c - p.y * s, y: p.x * s + p.y * c }));
        }
        base = minkowskiSum(body.outline, negative);
        cacheTrafficBase(baseKey, base);
      }
      polygon = padding ? expandConvex(base, padding) : base;
      if (trafficShapes.size >= 512) trafficShapes.delete(trafficShapes.keys().next().value);
      trafficShapes.set(shapeKey, polygon);
    }
    configurations.set(key, polygon);
    return polygon;
  };
  const interior = (x, y, polygon) => {
    for (const p of polygonSupportingPlanes(polygon)) if (!(x * p.x + y * p.y > p.min + 1e-6)) return false;
    return true;
  };
  const start = { x: 0, y: 0 }, end = { x: 0, y: 0 };
  let curves;
  const clear = (from, to, padding = 0) => {
    if (!bodies.length) return true;
    if (to.pivot || Math.abs(to.curvature ?? 0) > 1e-9) {
      const key = `${from.x}:${from.y}:${from.heading}:${to.x}:${to.y}:${to.heading}:${to.curvature}:${to.pivot?.x}:${to.pivot?.y}:${padding}`;
      const known = curves?.get(key);
      if (known !== void 0) return known;
      const turn2 = headingDifference(from.heading, to.heading), lever = to.pivot ? Math.hypot(from.x - to.pivot.x, from.y - to.pivot.y) : 1 / Math.abs(to.curvature);
      const steps2 = Math.max(1, Math.ceil(Math.abs(turn2) * Math.sqrt((radius + lever) / (8 * 0.025))));
      const error = lever * (turn2 / steps2) ** 2 / 8 + 1e-7;
      let result = true;
      for (let i = 0; i < steps2; i++) if (!clear(shipPoseAt(from, to, i / steps2), shipPoseAt(from, to, (i + 1) / steps2), error)) {
        result = false;
        break;
      }
      curves ??= /* @__PURE__ */ new Map();
      if (curves.size >= 256) curves.delete(curves.keys().next().value);
      curves.set(key, result);
      return result;
    }
    const dx = to.x - from.x, dy = to.y - from.y, turn = headingDifference(from.heading, to.heading);
    for (const body of bodies) {
      if (pointSegmentDistanceSquared(body.center, from, to) > (radius + body.radius + padding) ** 2) continue;
      const polygon = configuration(from.heading, to.heading, body, padding);
      start.x = from.x - body.center.x;
      start.y = from.y - body.center.y;
      end.x = to.x - body.center.x;
      end.y = to.y - body.center.y;
      const clip = clipToConvex(start, end, polygon);
      if (!clip || clip[1] - clip[0] < 1e-7) continue;
      const middle = (clip[0] + clip[1]) / 2;
      if (!interior(start.x + dx * middle, start.y + dy * middle, polygon)) continue;
      if (!(Math.abs(turn) < 1e-7 && clip[0] <= 1e-7 && dx * (from.x - body.center.x) + dy * (from.y - body.center.y) > 0)) return false;
    }
    return true;
  };
  return Object.assign(clear, { hasTraffic: bodies.length > 0 });
}
function reservationTraffic(ship, units, range = 600) {
  const rendezvousFor = ship.order.type === "move" ? ship.order.rendezvousFor : void 0;
  const crew = rendezvousFor ? units.find((unit) => unit.id === rendezvousFor) : void 0;
  const boarding = crew?.order.type === "board" ? crew.order : void 0, plan = boarding?.rendezvous;
  if (!plan?.reciprocal || !boarding || ship.id !== plan.sourceId && ship.id !== boarding.transportId) return shipTraffic(ship, units, range);
  const partnerId = ship.id === plan.sourceId ? boarding.transportId : plan.sourceId;
  const reserved = units.map((other) => {
    if (other.id !== partnerId || other.order.type !== "move" || other.order.rendezvousFor !== rendezvousFor || !other.sailing) return other;
    const x = other.id === plan.sourceId ? plan.sourceX : plan.targetX, y = other.id === plan.sourceId ? plan.sourceY : plan.targetY;
    return { ...other, x, y, sailing: { ...other.sailing, heading: plan.heading } };
  });
  const planned = shipTraffic(ship, reserved, range), live = shipTraffic(ship, units, range);
  const originX = ship.x, originY = ship.y;
  return Object.assign(
    (from, to, padding) => planned(from, to, padding) && (Math.hypot(from.x - originX, from.y - originY) > 1e-7 || live(from, to, padding)),
    { hasTraffic: planned.hasTraffic || live.hasTraffic }
  );
}
function shipContactGoal(ship, goal, units) {
  const other = shipsIn(units).find((other2) => other2 !== ship && other2.hp > 0 && circleInPolygon(worldToLocal(other2, goal), 0, shipProfile(other2).hull));
  if (!other) return;
  const dx = goal.x - ship.x, dy = goal.y - ship.y, length = Math.hypot(dx, dy);
  if (length < 1e-7) return;
  const direction = Math.atan2(dy, dx), preferred = ship.sailing?.heading ?? 0;
  const headings = [preferred, ...[direction, direction + Math.PI].sort((a, b) => Math.abs(headingDifference(preferred, a)) - Math.abs(headingDifference(preferred, b)))];
  for (const heading of headings) {
    const c = detCos(heading), s = detSin(heading), hull = shipProfile(ship).hull.map((p) => ({ x: p.x * c - p.y * s, y: p.x * s + p.y * c }));
    const polygon = minkowskiSum(shipProfile(other).hull.map((p) => localToWorld(other, p)), hull.map((a) => ({ x: -a.x, y: -a.y })));
    const clip = clipToConvex(ship, goal, polygon);
    if (!clip || clip[0] <= 1e-7) continue;
    const fraction = Math.max(0, clip[0] - 0.05 / length);
    return { x: ship.x + dx * fraction, y: ship.y + dy * fraction, heading };
  }
}

// src/shared/support-surface.ts
var at = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
var edge = (a, b) => ({ a, b, left: Math.min(a.x, b.x), top: Math.min(a.y, b.y), right: Math.max(a.x, b.x), bottom: Math.max(a.y, b.y) });
function supportSurface(polygons, ground, bounds) {
  const boundary = [], landBoundary = [];
  const land = (p) => !!ground && ground.open(Math.floor(p.x / ground.cell), Math.floor(p.y / ground.cell));
  const exposed = (a, b, owner, allowGround) => {
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    if (!len)
      return;
    const shift = { x: (b.y - a.y) / len * 1e-5, y: -(b.x - a.x) / len * 1e-5 };
    const aa = { x: a.x + shift.x, y: a.y + shift.y }, bb = { x: b.x + shift.x, y: b.y + shift.y };
    const cuts = [];
    for (let i = 0; i < polygons.length; i++)
      if (i !== owner) {
        const interval = clipToConvex(aa, bb, polygons[i]);
        if (interval)
          cuts.push(interval);
      }
    if (allowGround && ground) {
      const split = [0, 1];
      for (const axis of ["x", "y"])
        if (aa[axis] !== bb[axis]) {
          for (let line = (Math.floor(Math.min(aa[axis], bb[axis]) / ground.cell) + 1) * ground.cell; line < Math.max(aa[axis], bb[axis]); line += ground.cell)
            split.push((line - aa[axis]) / (bb[axis] - aa[axis]));
        }
      split.sort((a2, b2) => a2 - b2);
      for (let i = 1; i < split.length; i++)
        if (land(at(aa, bb, (split[i - 1] + split[i]) / 2)))
          cuts.push([split[i - 1], split[i]]);
    }
    cuts.sort((a2, b2) => a2[0] - b2[0]);
    let start = 0;
    for (const [low, high] of cuts) {
      if (low > start + 1e-9)
        boundary.push(edge(at(a, b, start), at(a, b, low)));
      start = Math.max(start, high);
    }
    if (start < 1 - 1e-9)
      boundary.push(edge(at(a, b, start), b));
  };
  for (let owner = 0; owner < polygons.length; owner++) {
    const poly = polygons[owner];
    for (let i = 0; i < poly.length; i++)
      exposed(poly[i], poly[(i + 1) % poly.length], owner, true);
  }
  if (ground) {
    const { cell } = ground;
    for (let row = Math.max(0, Math.floor(bounds.top / cell)); row < Math.min(ground.rows, Math.ceil(bounds.bottom / cell)); row++)
      for (let col = Math.max(0, Math.floor(bounds.left / cell)); col < Math.min(ground.cols, Math.ceil(bounds.right / cell)); col++)
        if (ground.open(col, row)) {
          const x = col * cell, y = row * cell;
          for (const [dx, dy, a, b] of [[0, -1, { x, y }, { x: x + cell, y }], [1, 0, { x: x + cell, y }, { x: x + cell, y: y + cell }], [0, 1, { x: x + cell, y: y + cell }, { x, y: y + cell }], [-1, 0, { x, y: y + cell }, { x, y }]])
            if (!ground.open(col + dx, row + dy)) {
              landBoundary.push(edge(a, b));
              exposed(a, b, -1, false);
            }
        }
  }
  const supported = (p) => land(p) || polygons.some((poly) => diskInConvex(p, 0, poly));
  const diskClear = (p, r, edges) => {
    const left = p.x - r, right = p.x + r, top = p.y - r, bottom = p.y + r, rr = r * r - 1e-7;
    for (const e of edges)
      if (e.right >= left && e.left <= right && e.bottom >= top && e.top <= bottom && pointSegmentDistanceSquared(p, e.a, e.b) < rr)
        return false;
    return true;
  };
  const capsuleClear = (a, b, r) => {
    const left = Math.min(a.x, b.x) - r, right = Math.max(a.x, b.x) + r, top = Math.min(a.y, b.y) - r, bottom = Math.max(a.y, b.y) + r, rr = r * r - 1e-7;
    for (const e of boundary)
      if (e.right >= left && e.left <= right && e.bottom >= top && e.top <= bottom && segmentDistanceSquared(a, b, e.a, e.b) < rr)
        return false;
    return true;
  };
  return {
    boundary,
    diskFits: (p, r) => supported(p) && diskClear(p, r, boundary),
    diskOnLand: (p, r) => land(p) && diskClear(p, r, landBoundary),
    capsuleFits: (a, b, r) => supported(a) && supported(b) && capsuleClear(a, b, r)
  };
}

// src/shared/ship-gangway.ts
var GANGWAY_SETUP_TICKS = seconds(3);
var GANGWAY_COOLDOWN_TICKS = seconds(20);

// src/shared/connected-decks.ts
var CONTACT_CLEARANCE = 0.5;
function seamPoints(a, b) {
  const points = [];
  for (const [hull, other] of [[a, b], [b, a]]) for (let i = 0; i < hull.length; i++) {
    const from = hull[i], to = hull[(i + 1) % hull.length], interval = clipToConvex(from, to, other);
    if (!interval) continue;
    for (const fraction of [0.25, 0.5, 0.75]) {
      const t = interval[0] + (interval[1] - interval[0]) * fraction;
      points.push({ x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t });
    }
  }
  return points;
}
function decksTouch(a, b, passenger) {
  const aa = shipProfile(a), bb = shipProfile(b);
  return Boolean(a.hp > 0 && b.hp > 0 && aa && bb && Math.abs(aa.deckHeight - bb.deckHeight) <= passenger.radius * 2 && Math.hypot(a.x - b.x, a.y - b.y) < (aa.length + bb.length) / 2 && hullGap(a, b) <= CONTACT_CLEARANCE);
}
function supportedSeamPoints(a, b, passenger) {
  if (!decksTouch(a, b, passenger)) return [];
  const hulls = [a, b].map((ship) => expandConvex(shipProfile(ship).hull.map((point) => localToWorld(ship, point)), CONTACT_CLEARANCE / 2));
  const floor = supportSurface(hulls, void 0, { left: 0, top: 0, right: 0, bottom: 0 });
  const obstacles = [a, b].flatMap((ship) => shipProfile(ship).obstacles.map((obstacle) => ({ ...localToWorld(ship, obstacle), radius: obstacle.radius })));
  return seamPoints(hulls[0], hulls[1]).filter((point) => floor.diskFits(point, passenger.radius + 1) && capsuleClearsCircles(point, point, passenger.radius + 1, obstacles));
}
function decksSupportCrossing(a, b, passenger) {
  return supportedSeamPoints(a, b, passenger).length > 0;
}

// src/shared/aiming.ts
var AIM_SPEED_MULTIPLIER = 2 / 3;

// src/shared/crew-rendezvous.ts
function contactPose(source, target, heading, side, along) {
  const reach = shipProfile(source).length + shipProfile(target).length;
  const goal = { x: target.x + along * detCos(heading), y: target.y + along * detSin(heading) };
  const probe = { ...source, x: goal.x - side * detSin(heading) * reach, y: goal.y + side * detCos(heading) * reach, sailing: { ...source.sailing, heading } };
  return shipContactGoal(probe, goal, [target]);
}
function rendezvous(map, units, source, target, crew) {
  const direction = Math.atan2(target.y - source.y, target.x - source.x);
  const reciprocal = source.owner === target.owner && ["idle", "hold"].includes(target.order.type) && !target.orderQueue?.length;
  const headings = (reciprocal ? [direction - Math.PI / 2, direction + Math.PI / 2, source.sailing.heading, target.sailing.heading] : [target.sailing.heading]).sort((a, b) => Math.abs(headingDifference(source.sailing.heading, a)) + (reciprocal ? Math.abs(headingDifference(target.sailing.heading, a)) : 0) - Math.abs(headingDifference(source.sailing.heading, b)) - (reciprocal ? Math.abs(headingDifference(target.sailing.heading, b)) : 0));
  const candidates = [];
  let best, bestScore = Infinity;
  const offset = Math.min(shipProfile(source).length, shipProfile(target).length) * 0.1;
  for (const heading of headings) for (const side of [-1, 1]) for (const along of [0, -offset, offset]) {
    const targetPose = { x: target.x, y: target.y, heading };
    const other = { ...target, ...targetPose, sailing: { ...target.sailing, heading } };
    const sourcePose = contactPose(source, other, heading, side, along);
    if (!sourcePose) continue;
    if (reciprocal) {
      const dx = (source.x + target.x - sourcePose.x - targetPose.x) / 2, dy = (source.y + target.y - sourcePose.y - targetPose.y) / 2;
      sourcePose.x += dx;
      sourcePose.y += dy;
      targetPose.x += dx;
      targetPose.y += dy;
    }
    const offsets = reciprocal ? [
      { x: 0, y: 0 },
      { x: source.x - sourcePose.x, y: source.y - sourcePose.y },
      { x: target.x - targetPose.x, y: target.y - targetPose.y }
    ] : [{ x: 0, y: 0 }];
    for (const shift of offsets) {
      const sourceAt = { ...sourcePose, x: sourcePose.x + shift.x, y: sourcePose.y + shift.y };
      const targetAt = { ...targetPose, x: targetPose.x + shift.x, y: targetPose.y + shift.y };
      const a = { ...source, x: sourceAt.x, y: sourceAt.y, sailing: { ...source.sailing, heading } }, b = { ...target, x: targetAt.x, y: targetAt.y, sailing: { ...target.sailing, heading } };
      const traffic = units.filter((unit) => unit !== source && unit !== target);
      if (!hullFits(map, source, sourceAt) || !hullFits(map, target, targetAt) || !decksSupportCrossing(a, b, crew) || !sameGround(map, source, sourceAt, "sea") || !sameGround(map, target, targetAt, "sea") || !shipBodyClearAtPose(map, a, sourceAt, traffic) || !shipBodyClearAtPose(map, b, targetAt, traffic)) continue;
      const score = Math.hypot(sourceAt.x - source.x, sourceAt.y - source.y) + Math.abs(headingDifference(source.sailing.heading, heading)) * shipProfile(source).length / 2 + (reciprocal ? Math.hypot(targetAt.x - target.x, targetAt.y - target.y) + Math.abs(headingDifference(target.sailing.heading, heading)) * shipProfile(target).length / 2 : 0);
      candidates.push({ sourceId: source.id, sourceX: sourceAt.x, sourceY: sourceAt.y, heading, targetX: targetAt.x, targetY: targetAt.y, reciprocal, score });
      if (score < bestScore - 1e-6) {
        bestScore = score;
        best = { sourceId: source.id, sourceX: sourceAt.x, sourceY: sourceAt.y, heading, targetX: targetAt.x, targetY: targetAt.y, reciprocal };
      }
    }
  }
  return { best, candidates };
}
export {
  rendezvous as diagnosticRendezvous,
  hullPassageClear,
  planShipRoute,
  reservationTraffic,
  setBuildingBodies,
  shipSolidTraffic
};
