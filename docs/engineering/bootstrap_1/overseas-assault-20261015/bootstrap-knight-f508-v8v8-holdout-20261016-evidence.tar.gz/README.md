固定 f508 的唯一骑士新种子普通开局，在 30,778 tick 自然 p0 胜。p1/p2 严格无单位或建筑对象；p0 留44单位、16工人、5大厅，损失25（14工人）。全owner162死亡逐项与native计数/移除确认/尸体对应；根审计另核fatal hit原记录逐字段相等。

原首harness在任何planner/native前因可选corpses观察错误退出。原日志/driver/完整factory0都保留；新名retry外部驱动仅修观察器，先严格比同factory world/id/null3mem一致才启动唯一实际比赛。不算native失败或重复选种。

1467运行源、184冻结manifest与497完整冻结源前后同字节。53完整周期档与208关键event档全部核world/id/3mem/setup。唯一30600→30778终局短闭合：83命令、15命中、全world/id/3mem及自然winner都exact。没有重跑0。

前矿11449/11400、首五工人11500..11555死亡、13200满血raid返程均保存实际证据与drawWorld。胜局不掩盖工人安全/部队任务成本缺口；不把单局当三路线最终验收。原容器未提交修改的恢复缺口仍保留。
