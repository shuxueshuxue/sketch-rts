import {writeFileSync,readFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';

const out='/workspace/.playtest/bootstrap-native-primitives-v2-20261016';
const roots={v1:'/workspace/sketch-rts-native-primitives-control',v2:'/workspace/sketch-rts-native-primitives-v2-control'};
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const results:any={};
for(const [version,root] of Object.entries(roots)){
 const sim=await import(pathToFileURL(root+'/src/shared/sim.ts').href),map=await import(pathToFileURL(root+'/src/shared/map.ts').href);
 const game=sim.createGame('bareDuel',{aiPlayers:[]});
 game.units=[];game.buildings=[];game.resources=[];game.items=[];game.mercenaryCamps=[];game.projectiles=[];game.effects=[];game.shops=[];game.obstacles=[];
 game.scriptedVictory=true;delete game.map.terrain;game.teams.player='home';game.teams.enemy='hostile';
 const guard=game.spawnUnit('player','footman',1000,1000);guard.cooldown=9999;guard.order={type:'hold',x:1000,y:1000};
 function foe(x:number){const u=game.spawnUnit('enemy','footman',x,1000);u.order={type:'hold',x,y:1000};u.cooldown=9999;return u;}
 const doomed=foe(1080),original=foe(1600);
 sim.stepGame(game);
 const replacement=map.createUnit(original.id,original.owner,original.kind,960,1000);replacement.order={type:'hold',x:960,y:1000};replacement.cooldown=9999;
 game.units[game.units.indexOf(original)]=replacement;
 sim.stepGame(game);
 guard.order={type:'attack',targetId:doomed.id,leashX:guard.x,leashY:guard.y};guard.cooldown=8;
 game.projectiles.push({id:'pending-finisher',owner:guard.owner,attackerId:guard.id,targetId:doomed.id,fromX:guard.x,fromY:guard.y,toX:doomed.x,toY:doomed.y,damage:doomed.hp+1,duration:60,remaining:60});
 const before=copy({snapshot:sim.snapshotGame(game),nextId:game.nextId});
 const live=sim.nativeAutomaticAttackIntent(game,guard),canonical=sim.nativeAutomaticAttackIntent(sim.createNativeQueryFrame(game),guard);
 const afterQueries=copy({snapshot:sim.snapshotGame(game),nextId:game.nextId});
 const indices={lookupIsOld:game.entityById.get(original.id)===original,spatialContainsNew:[...game.unitSpatialByTeam.get('hostile').buckets.values()].flat().includes(replacement),lookupBody:copy(original),sourceArrayBody:copy(replacement)};
 sim.stepGame(game);
 const afterNative=copy({snapshot:sim.snapshotGame(game),nextId:game.nextId});
 results[version]={root,indices,live,canonical,inputUnchanged:isDeepStrictEqual(before,afterQueries),before,afterNative,
  actualGuard:copy(guard),simSHA256:createHash('sha256').update(readFileSync(root+'/src/shared/sim.ts')).digest('hex')};
 writeFileSync(out+'/stale-frame-'+version+'-complete.json.gz',gzipSync(JSON.stringify(results[version])+'\n'));
}
const checks={sameInput:isDeepStrictEqual(results.v1.before,results.v2.before),sameNativeAfter:isDeepStrictEqual(results.v1.afterNative,results.v2.afterNative),
 v1Mismatch:results.v1.live.action==='engage'&&results.v1.live.gap===40,v2NativeMatch:results.v2.live.action==='pursue'&&results.v2.live.gap===600,
 readonly:results.v1.inputUnchanged&&results.v2.inputUnchanged,actualPursuitBoth:results.v1.actualGuard.x>1000&&results.v2.actualGuard.x>1000,
 staleLookupBoth:results.v1.indices.lookupIsOld&&results.v2.indices.lookupIsOld&&results.v1.indices.spatialContainsNew&&results.v2.indices.spatialContainsNew};
writeFileSync(out+'/stale-frame-witness.json',JSON.stringify({classification:'Artificial native stale-frame component built through two actual native steps, same-ID public body-array replacement and an ordinary native tracking shot. Not a recorded bootstrap match or ordinary0. Full before/after world/id and stale runtime metadata preserved.',checks,
 queries:Object.fromEntries(Object.entries(results).map(([v,r]:any)=>[v,{live:r.live,canonical:r.canonical,actualGuard:r.actualGuard,simSHA256:r.simSHA256}])),initialFixtureCorrection:'First test setup accidentally permitted a hold strike during native index refresh, so only the final max-HP assertion failed(129vs145). Preserved log; setup cooldown9999 now isolates stale lookup; no production behavior changed.'},null,2)+'\n');
console.log(JSON.stringify(checks));if(!Object.values(checks).every(Boolean))throw Error('Stale-frame witness not closed');
