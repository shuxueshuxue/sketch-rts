最终共享 primitive 定源 `9119feec0dd4b4933d5f8940b80df98abba80259`，独立树 `/workspace/sketch-rts-native-primitives-v2-control`，旧5db控制树和原6.69MB包未改。此补件只将 query 替换目标后按 ID 重新 findStrikeTarget，缺失则 none；原生 runtime 没有变化。

新增辨别测试用两次真实 native step 建立旧实体缓存、再同ID替换身体，保留新空间桶与旧 entityById：冷却期间 A 被跟踪箭预判必死，5db 查询误判近新B为 engage40；原生递归重查得到远旧B并 pursue600。9119 查询与原生相符，canonical快照重建仍正确使用新B。完整人工组件前后world/id保存为两个gz，v1/v2原生结果全等、输入未改。不是实际 bootstrap 比赛。

单worker目标文件12/12通过。首次新测试 setup 允许 hold 开火，只有末尾满血断言129vs145失败，日志保留；用 setup cooldown9999 隔离索引刷新的修订只改测试。v1的73项相关检查、tsc和三个真实短窗65个完整world/id闭合保持原归属，未伪称在v2重跑；runtime抽取/arrival算式完全相同。

`query-relookup-incremental.patch` 是5db→9119两文件最小增量；`native-primitives.patch` 是0f→9119最终三文件完整patch。`fixed-source.tar.gz`+清单封存1431个匹配提交的源码/数据/配置，冻结manifest仍0490...1774。尚未接AI/改订单/改评分/改规则，未新开普通0，未合入root。原容器未提交恢复缺口保留。
