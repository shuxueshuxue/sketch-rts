from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, io

root = Path('/workspace/sketch-rts-native-primitives-v2-control')
out = Path('/workspace/.playtest/bootstrap-native-primitives-v2-20261016')
mode = sys.argv[1]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
paths = ['src', 'scripts', 'tools/resource-manifest.ts', 'package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html', 'docs/engineering/bootstrap_1/frozen-policy.json']
tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', head, '--', *paths], cwd=root)
rows = []
for record in tree.split(b'\0'):
    if not record: continue
    meta, raw = record.split(b'\t', 1)
    gitmode, kind, blob = meta.decode().split()
    name = raw.decode()
    if kind != 'blob': continue
    p = root / name
    data = p.read_bytes() if p.is_file() else None
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() if data is not None else None
    rows.append({'path': name, 'gitBlob': blob, 'actualGitBlob': actual, 'sha256': hashlib.sha256(data).hexdigest() if data is not None else None, 'bytes': len(data) if data is not None else None, 'matchesCommit': actual == blob})
result = {'classification': 'Complete selected runtime/test/config tracked file audit of exact independent source; no AI policy changes', 'head': head, 'base': '0f5bf01a05046169d4fb42322376f767b97bcc83', 'files': rows, 'allMatchCommit': all(r['matchesCommit'] for r in rows), 'gitStatus': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True), 'frozenManifestSHA256': next(r['sha256'] for r in rows if r['path'].endswith('frozen-policy.json'))}
if mode == 'post':
    pre = json.loads((out / 'source-preflight.json').read_text())
    result['prePostSourceEqual'] = rows == pre['files'] and head == pre['head']
(out / ('source-' + ('preflight' if mode == 'pre' else 'postflight') + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
if mode == 'pre':
    with tarfile.open(out / 'fixed-source.tar.gz', 'w:gz') as archive:
        for row in rows:
            data = (root / row['path']).read_bytes()
            info = tarfile.TarInfo(row['path']); info.size = len(data); info.mode = 0o644; info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    patch = subprocess.check_output(['git', 'diff', '--binary', result['base'], head, '--'], cwd=root)
    (out / 'native-primitives.patch').write_bytes(patch)
print(json.dumps({'head': head, 'fileCount': len(rows), 'allMatchCommit': result['allMatchCommit'], 'prePostSourceEqual': result.get('prePostSourceEqual'), 'frozenManifestSHA256': result['frozenManifestSHA256']}))
if not result['allMatchCommit'] or result['gitStatus'] or mode == 'post' and not result['prePostSourceEqual']: raise SystemExit('Fixed source audit failed')
