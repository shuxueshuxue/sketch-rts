from pathlib import Path
import subprocess,json,hashlib,datetime,time,os
D=Path(__file__).parent;S=Path('/workspace/sketch-rts-root-mining-046-integration-control');cap=json.loads((D/'PREPARED-SOURCE-EQUIVALENCE.json').read_text());files=cap['sourceFiles'];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def exact():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['baseHead'];bad=[n for n,r in files.items() if H(S/n)!=r['sha256']];assert not bad,bad
 return True
runs=[('combined38',768,['node','--max-old-space-size=768','node_modules/vitest/vitest.mjs','run','--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(D/'combined38.json'),'src/ai/bootstrap_1/mining-building-fire-behavior.test.ts','src/ai/bootstrap_1/mining-building-fire-timing.test.ts','src/ai/bootstrap_1/mining-fire.test.ts','src/ai/bootstrap_1/mining-range-entry.test.ts','src/ai/bootstrap_1/medical-safe-prefix.test.ts','src/ai/bootstrap_1/landed-combat.test.ts']),('combined-tsc1024',1024,['node','--max-old-space-size=1024','node_modules/typescript/bin/tsc','--noEmit'])]
rows=[]
for name,heap,args in runs:
 assert not(D/(name+'-execution.json')).exists();exact();mx=int(Path('/sys/fs/cgroup/memory.max').read_text());cur=int(Path('/sys/fs/cgroup/memory.current').read_text());r={'name':name,'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headroomBefore':mx-cur,'requiredHeadroom':2*1024**3,'heapMiB':heap,'selectedSource1517ExactBefore':True,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text()}
 if mx-cur<r['requiredHeadroom']:(D/(name+'-guard75.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
 env=os.environ.copy();env.pop('NODE_OPTIONS',None);t=time.monotonic()
 with(D/(name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 r.update(exit=p.returncode,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,selectedAll1517ExactAfter=exact(),oomAfter=Path('/sys/fs/cgroup/memory.events').read_text(),logSHA256=H(D/(name+'.log')));(D/(name+'-execution.json')).write_text(json.dumps(r,indent=2)+'\n');rows.append(r);print(json.dumps(r),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
r={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Root046 preserved plusonly86143 14filedelta,staged1517','runs':rows,'currentActualDistinctCases':40,'counting':'combined38 includes3timing already inearlierfivepure; thosefive had2actualaimed.38+2=40distinct, no doublecount.','ordinary0ForThisNewCombinedSourceNotRun':True,'rulesVersion':2};(D/'COMBINED-VALIDATION.json').write_text(json.dumps(r,indent=2)+'\n')
