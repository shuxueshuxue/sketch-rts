from pathlib import Path
import subprocess,json,hashlib,datetime,time,os
D=Path(__file__).parent;S=Path('/workspace/sketch-rts-root-mining-046-integration-control');p=D/'combined-five-pure-execution.json';assert not p.exists();cap=json.loads((D/'PREPARED-SOURCE-EQUIVALENCE.json').read_text());expected=cap['sourceFiles'];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['baseHead'];bad=[n for n,r in expected.items() if H(S/n)!=r['sha256']];assert not bad,bad
 return True
check();mx=int(Path('/sys/fs/cgroup/memory.max').read_text());cur=int(Path('/sys/fs/cgroup/memory.current').read_text());r={'classification':'Only5 existing actualsnapshot-based pure planner cases, noGame/step/command issuance. Mining3actual reconstructedtimes+aimed2actual parent-referencecases. Combinedstaged1517source; no adoptionclaim.','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'heapMiB':512,'headroomBefore':mx-cur,'requiredHeadroom':1024**3,'selectedSourceFiles':len(expected),'sourceExactBefore':True,'oomBefore':Path('/sys/fs/cgroup/memory.events').read_text()}
if mx-cur<1024**3:(D/'five-pure-guard75.json').write_text(json.dumps(r,indent=2));raise SystemExit(75)
args=['node','--max-old-space-size=512','node_modules/vitest/vitest.mjs','run','--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(D/'combined-five-pure.json'),'src/ai/bootstrap_1/mining-building-fire-timing.test.ts','src/ai/policy/script-runner-aimed-cast.test.ts','--testNamePattern','actual11565|actual11745|actual12285|actual374']
env=os.environ.copy();env.pop('NODE_OPTIONS',None);t=time.monotonic()
with (D/'combined-five-pure.log').open('xb') as f:q=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
r.update(exit=q.returncode,endedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,sourceAll1517ExactAfter=check(),oomAfter=Path('/sys/fs/cgroup/memory.events').read_text(),logSHA256=H(D/'combined-five-pure.log'));p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(q.returncode)
