固定 fb881165，本目录待唯一共同起点真实对照，当前不得写成实战改善。

source=/tmp/sketch-rts-local-defense-562-control，branch=codex/bootstrap-local-defense-20261016，base56237b17ae40f4b9aacc16164a61c41a2a3dd103。仅2生产文件：末命令防守路由对齐native walkableGoal，保留原public目标/当前订单；同一帧传递原defendingHall，原当地posts优先、原实际rally次之，二者无安全完整路时保留原其它厅安全逃离能力。逃离不证明本地经济已受保护，未给builder虚构掩护。

原完整结果分开归属：f508普通开局30778/25；533从共同f50811400源固定续37965/31；610在53312720热换后34581/35；562共同f50811400固定续38673/30。562不合，另actual17325同输入675tick0新增本方死只是局部物理证据，不能进入共同起点完整局。原容器无法访问的未提交修改缺口仍未恢复。

新证据根因在已封 /tmp/bootstrap-fieldv2-11400-local-defense-diagnosis-20261016，及外部-ERRATUM.json：11400原9人向敌公开目标道路均清4敌塔，field contact100而首射ETA357..811、ready0；拒战后原fallback林地名义点被末路由当无路。原生正式投影为1360,1968、九人均有完整安全路；旧router却按allhall单兵最短ETA送8+1北返。两版旧前塔同11449毁，533当地厅11700有598血、562厅11698毁；562建塔工保持旧build在11702开始挨打、11738死亡；53311730仍70血。无需把塔早毁/没有本帧siege当成因，也不据此认全部终局+5损失唯一因。

新fixture字节正是共同原f50811400 before-P0完整world/nextId/3memory/setup，FIXTURE-PROVENANCE.json绑定原SHA d21e558b...。1481选定live源+497frozen=1978 capsule payload逐字节回读，规则2、184manifest保持。新源冻结后不热改。

验证按阶段分开：首draft68pass/6red保留，strictlocal使原10920retained逃离变hold是实质反证，不能吞；原rawforest断言未查native投影、一tick方向受crowd影响亦记录。随后7文件90+另pursuit2通过，未谎称一组8文件92。最终Point类型纠正后，4受影响文件37测试exit0、1024MiB compiler tsc exit0；768编译器heapOOM和5类型红日志均保留，不冒充系统OOM或策略负例。validation-execution.json有确切session/阶段/字节范围。

正常native driver已固定：normal3AI，普通冻结v8+v8资源人口不变，无human追加命令，从共同f50811400完整档同一Game自然到winner，无任意结束tick；前18000每15tick完整帧、其后每600及所有重要死亡；原始SDK命令尝试与真实命中分开，只有原f508前缀继承，不借533/610/562后窗。父明确observer stop才在600完整batch+step边界保存停下。自己的tests/tsc均已退出；parent协调先旧c8/58e恢复，随后即时cgroup≥2GiB、native768heap启动。

范围：仍只证明静态完整armed structures道路；当前可射模型不含catapult minRange（既有纯反事实单列，不归此局ballista）；不预测mobile战斗/未来动作，不保证post防得住全敌或伤员生存。原active attack/V8 rangedfire例外、General recovery/claims、原1.4/.9/.4等规则阈值不改。无路hold只取消旧危险动作。其它厅撤出时仍无新的builder不能保护通知，这是既有任务边界，不能说已全面消除弃矿。
