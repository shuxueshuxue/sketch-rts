固定 fb881165 完整证据，未合入，也非 bootstrap 验收。

独立源码 /tmp/sketch-rts-local-defense-562-control，branch codex/bootstrap-local-defense-20261016，base562；2生产文件对齐真实native walkableGoal和原当地防守任务，localposts→原actualrally→其它completehall仅无前两类safe路时逃离。源码1481 +冻结497=1978 capsule payload全部回读；规则2、184manifest、原正常对手资源人口不变，源/输入/driver/冻结prepost全同。

唯一共同起点普通三AI Game：只继承原f508普通0 <=11400，11400完整world/id3memory/setup开始同源固定执行到44624 p0WIN，敌p1/p2所有单位/建筑严格0。没有人工附令、任意截止tick、533/610/562后窗或新unseen声称。原f50830778/25、53337965/31、61034581/35（不同12720前缀）、56238673/30各自归属。新19损失较原25少6，但慢13846tick，军损15vs11、医疗5vs3、老兵6/等级和7vs4/5；基础catalog损失2215vs2525，非实际佣兵/装备/升级付款估值。不得直接称整体改进。

191唯一永久死亡19/81/74/17逐真实positive→nonpositive fatal原始hit、last原始hit、尸体/移除/末态/owner counter全闭合，temporary0。35165 SDK命令尝试、3577真实hit索引连续，只有原f508前缀；SDKattempt不等于全部实际执行。703完整帧含world/nextId/3mem/setup逐核。唯一终局44400→44624，224tick冷恢复26commands/13hits及全部world/id/3mem/winner精确相等；不计额外比赛或胜场。final44624-overview.png实际drawWorld已亲看。

首次whole账审红保留：41909 ashWarden27278先被witch4775 raw2866从6→−6，再被knight4468 raw2868从−6→−11.4追加overkill。旧审计错误要求lastHit必为fatal；observer原本另存真实fatal evidence，现二者独立逐字段核raw，不改raw、不把overkill冒充fatal。audit-first-last-hit-assumption.py/log及audit-first-failure-diagnosis.json保留。

验证阶段分开：首draft68pass6red（strictlocal反而让17325的10920 hold、rawforest断言遗漏投影、一step受crowd影响）全部保留；后7文件90+独立pursuit2通过；最终Point类型纠正后4受影响文件37+tsc1024exit0。768编译器V8heapOOM与5类型红亦保留，不当系统OOM/策略失败。没有伪称单一最终92组合；validation-execution.json有exact session/scope。独立3文件静审原样附，范围内无具体blocker。

实际早段：新local厅11700有598、11730建塔工70，2510已死；但1057/1066/1175在11765/11835/11873早死，最后命令多属mobileCare/中间有battlefield与General接管，不能把fatal native attack直接归General。建塔工实际建出新tower5478转repair，仍在11966被golem两39杀，只较562晚228，不能说已救成功。后续完整慢局与军医损失须另从实际帧诊断。

能力边界：静态armed结构道路不证明mobile战斗/本地强度/生存；无路hold仅取消旧危险步，逃去其它厅不证明守住原矿。没有新的cannotProtect反馈。既有activeattack/V8rangedfire例外保留；catapult minRange模型边界另有纯反事实，不归此局ballista。原阈值/对手/冻结未改。原容器不可访问未提交修改始终未恢复。

环境：/tmp曾被另新cone工作树填满，root已回收该失败树，原native未受热改。为恢复sandbox一度把自己的旧562已封30MB archive逐SHA临时迁盘，随后原路径regular archive已完整迁回，外部收据保留；不删旧raw/他人目录。driver/prelaunch metadata和*-pre-runtime文件保其历史值，不代表当前尚未执行。
