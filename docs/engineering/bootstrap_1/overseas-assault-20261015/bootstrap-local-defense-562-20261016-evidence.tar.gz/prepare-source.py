"""Read/hash/archive only. Never imports game code or starts a match."""
from pathlib import Path
import subprocess,sys,json,hashlib,tarfile,io,gzip,datetime,os
assert len(sys.argv)==4,'prepare-source.py ABS_FIXED_ROOT FULL_EXPECTED_HEAD ABS_NEW_PREFIX'
W=Path(sys.argv[1]);HEAD=sys.argv[2];P=Path(sys.argv[3]);assert W.is_absolute()and P.is_absolute()and len(HEAD)==40
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain','--untracked-files=all').strip(),'Source must be clean'
for suffix in ['.json','.frames','-launch.json','-runtime-source.json','-source.tar.gz','-frozen-source.tar.gz','-factory0.json.gz','-commands.jsonl','-plans.jsonl','-native-hits.jsonl','-native-events.jsonl','-native-deaths.jsonl','-ship-losses.jsonl','-postflight.json']:
 assert not Path(str(P)+suffix).exists(),'Preserve prior capsule/game: '+suffix
P.parent.mkdir(parents=True,exist_ok=True)
paths=['src','scripts','tools','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','docs/engineering/bootstrap_1/frozen-policy.json']
files=[];live={}
for row in git('ls-tree','-r','-z',HEAD,'--',*paths).split(b'\0'):
 if not row:continue
 meta,path=row.split(b'\t');mode,kind,blob=meta.decode().split(' ');name=path.decode();assert kind=='blob';data=(W/name).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==blob,name
 files.append({'path':name,'expectedGitBlob':blob,'actualGitBlob':actual,'sha256':sha(data),'bytes':len(data),'matches':True});live[name]=data
manifest_name='docs/engineering/bootstrap_1/frozen-policy.json';manifest=json.loads(live[manifest_name]);manifest_sha=sha(live[manifest_name]);assert manifest_sha=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
assert manifest['rulesVersion']==2 and manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639' and len(manifest['files'])==184
frozen_tar=git('archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared')
with tarfile.open(fileobj=io.BytesIO(frozen_tar),mode='r:')as t:frozen={m.name:t.extractfile(m).read()for m in t if m.isfile()}
for name,h in manifest['files'].items():assert sha(frozen[name])==h,name
archive=Path(str(P)+'-source.tar.gz');index={}
with tarfile.open(str(archive)+'.tmp','w:gz')as t:
 for prefix,group in [('live',live),('frozen',frozen)]:
  for name,data in sorted(group.items()):
   entry=tarfile.TarInfo(prefix+'/'+name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;t.addfile(entry,io.BytesIO(data));index[entry.name]=sha(data)
 data=(json.dumps({'algorithm':'SHA256','files':index},indent=2)+'\n').encode();entry=tarfile.TarInfo('INDEX.json');entry.size=len(data);t.addfile(entry,io.BytesIO(data))
os.rename(str(archive)+'.tmp',archive)
with tarfile.open(archive)as t:
 for name,h in index.items():assert sha(t.extractfile(name).read())==h,name
frozen_archive=Path(str(P)+'-frozen-source.tar.gz');frozen_archive.write_bytes(gzip.compress(frozen_tar))
cap={'classification':'Fixed local-defense task and native projected-goal successor for one common originalf50811400 before-P0 start, then same-source normal3AI natural game. Prior f508/a75/533/610/562 evidence stays separately attributed. This observed seed is not unseen for this source; no new ordinary0 is started.','root':str(W),'head':HEAD,'gitStatus':'','files':files,'frozenManifestSHA256':manifest_sha,'frozenRevision':manifest['revision'],'rulesVersion':2,'frozenManifestFiles':manifest['files'],'frozenFiles':{n:sha(b)for n,b in frozen.items()},'sourceArchive':str(archive),'sourceArchiveSHA256':sha(archive.read_bytes()),'sourceArchiveBytes':archive.stat().st_size,'archivePayloadCount':len(index),'archiveReadbackVerified':True,'frozenArchive':str(frozen_archive),'frozenArchiveSHA256':sha(frozen_archive.read_bytes()),'frozenArchiveBytes':frozen_archive.stat().st_size,'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
# Recheck actual source bytes after archival, before publishing the capsule manifest.
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','--untracked-files=all').strip()
for entry in files:assert sha((W/entry['path']).read_bytes())==entry['sha256'],entry['path']
Path(str(P)+'-runtime-source.json').write_text(json.dumps(cap,indent=2)+'\n')
print(json.dumps({k:v for k,v in cap.items()if k not in ['files','frozenFiles','frozenManifestFiles']}))
