import { readFileSync, writeFileSync } from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/tmp/sketch-rts-safe-worker-boarding-v1-control',directory='/tmp/bootstrap-safe-worker-boarding-v1-20261015';
const imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const [{createCanvas},{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([imp('node_modules/@napi-rs/canvas/index.js'),imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const run=JSON.parse(readFileSync(directory+'/candidate-v1/result.json','utf8'));
const input=directory+'/candidate-v1/'+run.frames.find((frame:any)=>frame.tick===134700&&frame.label==='complete-checkpoint').path;
const {snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
const views={coast:{x:4050,y:5250,width:1500,height:950,zoom:1},voyage:{x:2350,y:5100,width:1800,height:1000,zoom:.55}};
for(const[name,view]of Object.entries(views)){const canvas=createCanvas(view.width,view.height);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(directory+'/native134700-'+name+'.png',canvas.toBuffer('image/png'));}
writeFileSync(directory+'/native-visual.json',JSON.stringify({classification:'Native drawWorld of actual134700 complete world; no simulation/geometry edits. New facing tracker does not reconstruct historical animation.',source,input,views},null,2)+'\n');
