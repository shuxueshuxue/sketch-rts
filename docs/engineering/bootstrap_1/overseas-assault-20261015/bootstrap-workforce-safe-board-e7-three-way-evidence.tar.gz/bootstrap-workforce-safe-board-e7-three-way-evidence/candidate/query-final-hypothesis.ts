import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/tmp/sketch-rts-safe-worker-boarding-v1-control',imp=(p:string)=>import(pathToFileURL(source+'/'+p).href),dir='/tmp/bootstrap-safe-worker-boarding-v1-20261015';
const [sim,safety,bootstrap,planner,naval]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/bootstrap_1/worker-boarding.ts'),imp('src/ai/bootstrap_1/policy.ts'),imp('src/ai/planner-context.ts'),imp('src/ai/bootstrap_1/expedition-recovery.ts')]);
const cases=[];
for(const[tick,id]of [[134175,'unit-p0-worker-11845'],[134595,'unit-p0-worker-13542'],[134160,'unit-p0-worker-3'],[134580,'unit-p0-worker-11845'],[135000,'unit-p0-worker-13542']]as const){
 const input=JSON.parse(gunzipSync(readFileSync(source+`/src/ai/bootstrap_1/fixtures/worker-boarding-knight-${tick}.json.gz`)).toString()),game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);const snapshot=sim.snapshotGame(game),worker=snapshot.units.find((u:any)=>u.id===id),boat=snapshot.units.find((u:any)=>u.id==='unit-p0-carrier-6933'),options=bootstrap.bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(input.memories.p0),teams:{p0:'a',p1:'b'}});
 cases.push({tick,id,safe:safety.workerBoardingSafe(snapshot,'p0',options,worker,boat),hp:worker.hp,order:worker.order});
}
const sample=JSON.parse(gunzipSync(readFileSync(source+'/src/ai/bootstrap_1/fixtures/summoner-pickup-quay.json.gz')).toString()),pickups=[];
for(const version of ['v9_archer','v9_summoner','v9_knight']){
 const game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,sample.snapshot,sample.nextId);const snapshot=sim.snapshotGame(game),options=bootstrap.bootstrapPolicyContext(snapshot,'p0',version,{memory:structuredClone(sample.memory),teams:game.teams}),commands=naval.planBootstrapNaval(snapshot,'p0',options);
 const original=JSON.parse(readFileSync(dir+'/prehook-hypothesis-query.json','utf8')).pickups.find((entry:any)=>entry.version===version);
 const workers=original.workerChecks.map((entry:any)=>({worker:snapshot.units.find((u:any)=>u.id===entry.workerId),boat:snapshot.units.find((u:any)=>u.id===entry.boatId)}));
 pickups.push({version,candidateNativeBoardRequests:commands.filter((c:any)=>c.type==='board'),workerChecks:workers.map(({worker,boat}:any)=>({workerId:worker.id,boatId:boat.id,safe:safety.workerBoardingSafe(snapshot,'p0',options,worker,boat)}))});
}
writeFileSync(dir+'/final-hypothesis-query.json',JSON.stringify({classification:'Read-only native safety queries after final geometry/packing corrections. No new game or stepping. See prehook-hypothesis-query.json for original request selection.',cases,pickups},null,2)+'\n');console.log(JSON.stringify({cases:cases.map(({order,...c})=>c),pickups},null,2));
