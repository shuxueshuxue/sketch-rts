import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
const source=process.argv[2],name=process.argv[3];
if(!source||!name)throw Error('Expected absolute source path and unique output name');
const directory='/tmp/bootstrap-safe-worker-boarding-v1-20261015/'+name;
if(existsSync(directory))throw Error('Never overwrite a previous continuation');
mkdirSync(directory);
const input='/tmp/bootstrap-knight-economy-independent-review-20261015/input-complete-132000.json';
const inputBytes=readFileSync(input),saved=JSON.parse(inputBytes.toString());
const sha=(bytes:any)=>createHash('sha256').update(bytes).digest('hex'),norm=(value:any)=>JSON.parse(JSON.stringify(value));
const git=(...args:string[])=>execFileSync('git',['-C',source,...args],{encoding:'utf8'}).trim();
const sourcePaths=git('ls-files','src','scripts','package.json','package-lock.json','tsconfig.json','docs/engineering/bootstrap_1/frozen-policy.json').split('\n').filter(path=>existsSync(source+'/'+path));
const sourceHashes=()=>Object.fromEntries(sourcePaths.map(path=>[path,sha(readFileSync(source+'/'+path))]));
if(git('status','--porcelain'))throw Error('Continuation source must be committed and clean');
const beforeSource=sourceHashes(),commit=git('rev-parse','HEAD');
const imp=(path:string)=>import(pathToFileURL(source+'/'+path).href);
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyManifest},{runAiGameLoop},{upkeepGoldIncome}]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/planner-context.ts'),imp('scripts/bootstrap_1-planner.ts'),imp('src/ai/game-runner.ts'),imp('src/shared/mining.ts')]);
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memories=createAiMemoryProvider();for(const [owner,memory]of Object.entries(saved.memories))memories.set(owner,structuredClone(memory));
const agents=saved.setup.agents,owners=Object.keys(agents),planner=await createBootstrapCommandPlanner(memories);
const full=()=>norm({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,memories.get(owner)]))});
const initial=full(),restored={world:isDeepStrictEqual(initial.snapshot,saved.snapshot),nextId:initial.nextId===saved.nextId,allMemories:isDeepStrictEqual(initial.memories,saved.memories)};
if(!Object.values(restored).every(Boolean))throw Error('Full state restore failed');
const write=(file:string,value:any)=>writeFileSync(directory+'/'+file,JSON.stringify(value));
const frames:any[]=[],capture=(label:string)=>{const state=full(),path=`${game.tick}-${frames.length}-${label}.json.gz`;writeFileSync(directory+'/'+path,gzipSync(JSON.stringify(state)));frames.push({tick:game.tick,label,path});return state;};
capture('initial');
const initialWorkerIds=new Set(game.units.filter((unit:any)=>unit.owner==='p0'&&unit.kind==='worker').map((unit:any)=>unit.id));
const originalPermanentIds=new Set(game.units.filter((unit:any)=>unit.owner==='p0'&&unit.expiresTick===undefined).map((unit:any)=>unit.id));
const births:any[]=[],deposits:any[]=[],trainingPayments:any[]=[],commands:any[]=[],rows:any[]=[],removedPermanent:any[]=[],seenNewWorkers=new Set<string>();
const boardingRequests:any[]=[],workerInjuries:any[]=[],workerDeckChanges:any[]=[],boardingSamples:any[]=[];
let previousWorkers=new Map<string,any>();
let previousPermanent=new Set(originalPermanentIds),returning:any[]=[],goldBeforeStep=0,spentBeforeStep=0,commandGold=game.players.p0.gold,commandSpent=game.match.stats.goldSpent.p0,lastCheckpoint=initial;
const summary=()=>({tick:game.tick,winner:game.match.winner,gold:game.players.p0.gold,supply:game.players.p0.supplyUsed,cap:game.players.p0.supplyCap,stats:structuredClone(game.match.stats),workers:game.units.filter((unit:any)=>unit.owner==='p0'&&unit.kind==='worker').map((unit:any)=>({id:unit.id,order:unit.order,x:unit.x,y:unit.y,carryingGold:unit.carryingGold,deck:unit.deck})),opponents:Object.fromEntries(owners.filter(owner=>owner!=='p0').map(owner=>[owner,{units:game.units.filter((unit:any)=>unit.owner===owner).length,buildings:game.buildings.filter((building:any)=>building.owner===owner).length}]))});
const classification='Fixed-source changed-code continuation of actual6f80 ordinary0 saved132000, with full both-AI restoration. This is not a fresh opening or a new whole-match acceptance result.';
write('launch.json',{classification,source,commit,input,inputSHA256:sha(inputBytes),restored,setup:saved.setup,frozenRevision:frozenPolicyManifest.revision,frozenRulesVersion:frozenPolicyManifest.rulesVersion,sourceHashes:beforeSource,driverSHA256:sha(readFileSync(import.meta.filename)),horizon:144000});
console.log(JSON.stringify({launched:true,name,source,commit,start:game.tick,restored}));
runAiGameLoop({name:'Complete both-AI workforce destination control '+name,game,agents,maxTicks:144000,thinkInterval:15,commandPlanner:(context:any)=>{if(context.owner==='p0'){commandGold=game.players.p0.gold;commandSpent=game.match.stats.goldSpent.p0;}return planner(context);}},{
  onCommand(event:any){
    commands.push({tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)});
    if(event.owner!=='p0')return;
    const command=event.command;
    if(command.type==='board')for(const id of command.unitIds){const worker=game.units.find((unit:any)=>unit.id===id),boat=game.units.find((unit:any)=>unit.id===command.transportId);if(worker?.kind==='worker')boardingRequests.push({tick:game.tick,id,command,nativeOrder:structuredClone(worker.order),worker:{x:worker.x,y:worker.y,hp:worker.hp},boat:boat&&{x:boat.x,y:boat.y,order:structuredClone(boat.order)},mission:structuredClone(memories.get('p0')?.naval?.ferries?.[command.transportId])});}
    if(command.type==='train'&&command.unitKind==='worker'){
      trainingPayments.push({tick:event.tick,buildingId:command.buildingId,goldBefore:commandGold,goldAfter:game.players.p0.gold,goldPaid:commandGold-game.players.p0.gold,spendDelta:game.match.stats.goldSpent.p0-commandSpent,queue:structuredClone(game.buildings.find((building:any)=>building.id===command.buildingId)?.queue)});
      capture('after-worker-payment');
    }
    commandGold=game.players.p0.gold;commandSpent=game.match.stats.goldSpent.p0;
  },
  beforeStep(){
    previousWorkers=new Map(game.units.filter((unit:any)=>unit.owner==='p0'&&unit.kind==='worker').map((unit:any)=>[unit.id,structuredClone({id:unit.id,x:unit.x,y:unit.y,hp:unit.hp,order:unit.order,deck:unit.deck})]));
    returning=game.units.filter((unit:any)=>unit.owner==='p0'&&unit.kind==='worker'&&unit.carryingGold>0&&unit.order.type==='mine'&&unit.order.phase==='return').map((unit:any)=>({id:unit.id,carryingGold:unit.carryingGold,resourceId:unit.order.resourceId,newWorker:seenNewWorkers.has(unit.id)}));
    goldBeforeStep=game.players.p0.gold;spentBeforeStep=game.match.stats.goldSpent.p0;
  },
  onStep(){
    for(const[id,before]of previousWorkers){const after=game.units.find((unit:any)=>unit.id===id);if(!after||after.hp<before.hp)workerInjuries.push({tick:game.tick,before,after:after?{x:after.x,y:after.y,hp:after.hp,order:structuredClone(after.order),deck:after.deck}:null});if(after&&before.deck?.shipId!==after.deck?.shipId)workerDeckChanges.push({tick:game.tick,id,before:before.deck,after:after.deck,x:after.x,y:after.y,hp:after.hp,order:structuredClone(after.order)});}
    if(game.tick%15===0){const boarders=game.units.filter((unit:any)=>unit.owner==='p0'&&unit.kind==='worker'&&unit.order.type==='board');if(boarders.length)boardingSamples.push({tick:game.tick,workers:boarders.map((unit:any)=>({id:unit.id,x:unit.x,y:unit.y,hp:unit.hp,order:structuredClone(unit.order),deck:unit.deck}))});}
    for(const unit of game.units)if(unit.owner==='p0'&&unit.kind==='worker'&&!initialWorkerIds.has(unit.id)&&!seenNewWorkers.has(unit.id)){
      seenNewWorkers.add(unit.id);births.push({tick:game.tick,id:unit.id,x:unit.x,y:unit.y,hp:unit.hp,order:structuredClone(unit.order)});capture('new-worker-born');
    }
    const completed=returning.filter(before=>game.units.some((unit:any)=>unit.id===before.id&&unit.carryingGold===0));
    for(const before of completed)if(before.newWorker){
      const unit=game.units.find((unit:any)=>unit.id===before.id);
      deposits.push({tick:game.tick,...before,order:structuredClone(unit.order),x:unit.x,y:unit.y,goldBefore:goldBeforeStep,goldAfter:game.players.p0.gold,netGoldChange:game.players.p0.gold-goldBeforeStep,spendDelta:game.match.stats.goldSpent.p0-spentBeforeStep,allDepositorsThisTick:completed,expectedNativeIncome:upkeepGoldIncome(before.carryingGold,game.players.p0.supplyUsed)});
      if(!deposits.some((entry:any)=>entry.id===unit.id&&entry.tick<game.tick))capture('first-new-worker-income');
    }
    const now=new Set(game.units.filter((unit:any)=>unit.owner==='p0'&&unit.expiresTick===undefined).map((unit:any)=>unit.id));
    for(const id of previousPermanent)if(!now.has(id))removedPermanent.push({tick:game.tick,id,initial:originalPermanentIds.has(id)});previousPermanent=now;
    if(game.tick%300===0){lastCheckpoint=capture('complete-checkpoint');rows.push(summary());write('progress.json',{classification,summary:rows.at(-1),trainingPayments,births,newWorkerDeposits:deposits.length});console.log(JSON.stringify({tick:game.tick,winner:game.match.winner,gold:game.players.p0.gold,paidWorkers:trainingPayments.length,bornWorkers:births.length,deposits:deposits.length}));}
  }
});
const final=capture('terminal'),endSummary=summary();
let replay:any=null;
if(lastCheckpoint.snapshot.tick<game.tick){
  const g=createGame('bareDuel');restoreSnapshotIntoGame(g,lastCheckpoint.snapshot,lastCheckpoint.nextId);const provider=createAiMemoryProvider();for(const [owner,memory]of Object.entries(lastCheckpoint.memories))provider.set(owner,structuredClone(memory));
  const replayPlanner=await createBootstrapCommandPlanner(provider),replayCommands:any[]=[];
  runAiGameLoop({name:'Same fixed-source final-window JSON replay '+name,game:g,agents,maxTicks:game.tick,thinkInterval:15,commandPlanner:replayPlanner},{onCommand(event:any){replayCommands.push({tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)});}});
  replay={start:lastCheckpoint.snapshot.tick,end:g.tick,world:isDeepStrictEqual(norm(snapshotGame(g)),final.snapshot),nextId:g.nextId===final.nextId,allMemories:isDeepStrictEqual(norm(Object.fromEntries(owners.map(owner=>[owner,provider.get(owner)]))),final.memories),allCommands:isDeepStrictEqual(replayCommands,commands.filter(entry=>entry.tick>=lastCheckpoint.snapshot.tick))};
}
const afterSource=sourceHashes(),result={classification,source,commit,start:132000,end:game.tick,winner:game.match.winner,endedAtTick:game.match.endedAtTick,completed:!!game.match.winner,restored,setup:saved.setup,initial,final,summary:endSummary,trainingPayments,births,deposits,removedPermanent,commands,rows,frames,replay,boardingRequests,workerInjuries,workerDeckChanges,boardingSamples,sourceUnchanged:isDeepStrictEqual(beforeSource,afterSource),sourceStatus:git('status','--porcelain')};
write('result.json',result);console.log(JSON.stringify({done:true,name,end:game.tick,winner:game.match.winner,paidWorkers:trainingPayments,bornWorkers:births.length,deposits:deposits.length,sourceUnchanged:result.sourceUnchanged,sourceStatus:result.sourceStatus,replay}));
