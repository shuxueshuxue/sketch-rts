from pathlib import Path
import hashlib,json,subprocess,tarfile

p=Path('/workspace/.playtest/bootstrap-land-army-continued-20261015')
root=Path('/workspace/sketch-rts-medical-arrival-hold-control')
load=lambda f:json.loads(Path(f).read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def dump(name,v):
    (p/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

prefix=p/'medical-arrival-hold9ba-archer-double-v8-ordinary0'
report=load(str(prefix)+'.json')
post=load(str(prefix)+'-postflight.json')
assert report['result']=={'tick':24840,'winner':'p1','completed':True}
assert post['result']==report['result'] and not post['changes'] and not post['fullChanges']
pre=load(p/'medical-arrival-hold9ba-native-preflight.json')
changes=[n for n,h in pre['files'].items()if sha(root/n)!=h]
assert not changes
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='9ba65d0644db73c365273bb94ce2ff04ccf41330'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
dump('medical-arrival-hold9ba-final-source-verification.json',{'source':str(root),'commit':pre['commit'],'verifiedFiles':len(pre['files']),'changes':changes,'gitStatus':'','note':'After all genuine ordinary0, three boundary windows, terminal replay and first-material-boundary diagnostics. No production file edits after source freeze.'})

nf=p/'medical-arrival-hold9ba-fine-16200-16800'
of=Path('/tmp/bootstrap-land-army-evidence-20261015/production-base5f-archer-fine-16200-16800')
new,old=load(str(nf)+'.json'),load(str(of)+'.json')
assert all(new['verification']['allMemoriesEqual'].values()) and new['verification']['worldEqual'] and new['verification']['nextIdEqual']
assert all(old['verification']['allMemoriesEqual'].values()) and old['verification']['worldEqual'] and old['verification']['nextIdEqual']
owners=['p0','p1','p2']
closures=[]
for label,fine in [('medical-arrival-hold9ba-prefix16200-16245',nf),('medical-arrival-hold9ba-old5f-prefix16200-16245',of)]:
    a=load(p/(label+'.frames')/'16245.json');b=load(str(fine)+'.frames/16245.json')
    eq={k:a[k]==b[k]for k in ['snapshot','nextId','memories']};assert all(eq.values())
    q=load(p/(label+'.json'))
    closures.append({'label':label,'ownActualFineCheckpointEqual':eq,'startPlus15Replay':q['verification']})
# Compare all units every native tick, excluding commands/aim from physical metrics.
def frame(which,t):
    if t<=16245:
        label='medical-arrival-hold9ba-prefix16200-16245'if which=='new'else'medical-arrival-hold9ba-old5f-prefix16200-16245'
        return load(p/(label+'.frames')/f'{t}.json')
    if which=='new':return load(p/'medical-arrival-hold9ba-actual16245-detail.frames'/f'{t}.json')
    return load(Path('/tmp/bootstrap-land-army-evidence-20261015/production-base5f-secondboundary16245.frames')/f'{t}.json')
def first_diff(keys):
    for t in range(16200,16261):
        a,b=frame('new',t),frame('old',t)
        am={u['id']:u for u in a['snapshot']['units']};bm={u['id']:u for u in b['snapshot']['units']}
        ds=[]
        for uid in sorted(am.keys()&bm.keys()):
            d={k:{'old':bm[uid].get(k),'new':am[uid].get(k)}for k in keys if bm[uid].get(k)!=am[uid].get(k)}
            if d:ds.append({'id':uid,'fields':d})
        if ds:return {'tick':t,'differences':ds}
    return None
physical=['x','y','hp','maxHp','cooldown','xp','kills']
hp=first_diff(['hp']);aim=first_diff(['facing','aim']);phys=first_diff(physical)
by={(r['tick'],r['owner']):r['entries']for r in old['commands']}
first_nonqueue=None
for row in new['commands']:
    entries=[e for e in row['entries']if not(e['scriptId']=='mobileCare'and e['command']['type']=='holdPosition'and e['command'].get('queued'))]
    original=by[row['tick'],row['owner']]
    if entries!=original:
        first_nonqueue={'tick':row['tick'],'owner':row['owner'],'old':original,'newIgnoringOnlyAddedMedicalQueuedHold':entries};break
def native_death(r,uid):
    ds=[d for d in r['deaths']if d['before']['id']==uid]
    return None if not ds else {'tick':ds[0]['tick'],'unit':ds[0]['before'],'hits':[e for e in ds[0]['newEffects']if e.get('unitId')==uid and e['type']=='hit']}
def timeline(fine,uid):
    values=[]
    for t in range(16245,16801,15):
        f=load(str(fine)+f'.frames/{t}.json');u=next((u for u in f['snapshot']['units']if u['id']==uid),None);h=next((u for u in f['snapshot']['units']if u['id']=='unit-p0-fieldMedic-1907'),None)
        values.append({'tick':t,'patient':None if u is None else {k:u.get(k)for k in ['id','x','y','hp','maxHp','order','cooldown','orderQueue']},'healer':None if h is None else {k:h.get(k)for k in ['id','hp','order','abilityCooldowns']},'gap':((u['x']-h['x'])**2+(u['y']-h['y'])**2)**.5 if u and h else None})
    return values
lastold=load(str(of)+'.frames/16800.json')['snapshot'];lastnew=load(str(nf)+'.frames/16800.json')['snapshot']
corpse=lambda s,uid:next((c for c in s['corpses']if c['unitId']==uid),None)
analysis={'classification':'Read-only exact own-source native first material boundary. Full600tick9ba replay closes actual9ba16800; reference5f600 closes its own16800. First45tick prefix on both sources additionally closes actual16245 and compares every tick. No new candidate or ordinary0.',
 'closures':closures,'fineEndpoint':{'new':new['verification'],'old':old['verification']},'firstAimFacingDifference':aim,'firstPhysicalMetricsDifference':phys,'firstHpDifference':hp,
 'firstNonQueueCommandDifference':first_nonqueue,
 'timeline':{'old5f':timeline(of,'unit-p0-horseArcher-4294'),'candidate9ba':timeline(nf,'unit-p0-horseArcher-4294')},
 'deaths':{'old5f':[{'tick':d['tick'],'id':d['before']['id'],'kind':d['before']['kind']}for d in old['deaths']],'candidate9ba':[{'tick':d['tick'],'id':d['before']['id'],'kind':d['before']['kind']}for d in new['deaths']]},
 'riderDeath':native_death(new,'unit-p0-horseArcher-4294'),
 'enemyDeaths':{uid:{'old':corpse(lastold,uid),'new':corpse(lastnew,uid)}for uid in ['unit-p2-knight-2670','unit-p2-knight-5241']},
 'factsAndLimits':['Actual9ba16245 differs from original5f16245 only by archer2042 pending hold queue; all memories/nextId equal. Prior target-only short window did not contain that real queue. Both actual prefix closures preserve it; no upgraded claim based on the earlier input.',
 '16247 old4294 is attack2670, new4294 is hold. At16248 aim/facing first differ; at16250 old shoots (cooldown30), new still aiming(cooldown0); first HP difference follows. Not simply an instantaneous16247 seven damage event.',
 '16260 both rider positions and97HP are identical, healer1907 gap237.159<240 but heal cooldown164. Both take28/20/28 at16270/16271/16297, ending21HP. No healing in the short window.',
 'New rider dies16381 to native28 from knight6027; old rider survives this600tick window. This is a real lost asset, not proof of a single sufficient cause of final24840 defeat.',
 'New healer1907 dies16531, old16450; new priest5844 dies16466, old16424. Cannot claim the new loss is simply earlier medic deaths.',
 'Native idle acquisition here is230(sim1485), not max(weaponRange,230). The latter applies to attackMove/automatic attack reconsideration. A330range idle rider initially acquires only230, but help-call and an already acquired target moving away can still cause pursuit beyond330.',
 'Native hold only strikes own weapon range and does not chase. takeUpAttacker changes idle only with empty queue, attackMove and self-directed attack, not hold; hold is not damage immunity. Exact first7damage target transfer is observed; no unsupported claim of a unique specific help-call trigger.',
 'Whole match9ba natural24840 p1win/53permanent deaths differs from old5f43714 p0win/56deaths and production3bdb26107 p1win/71deaths. Shorter defeat having fewer losses is not improvement. All remain correctly attributed.']}
dump('medical-arrival-hold9ba-first-material-boundary.json',analysis)

(p/'README.medical-arrival-hold9ba.zh.md').write_text('''9ba65d0644db73c365273bb94ce2ff04ccf41330，基于生产3bdb的独立医疗到达候选。完整普通0在24840 tick自然p1胜，我方0单位/0建筑；53永久死、1中立死、花费10774。候选保持未合入，停止叠加护理变体和新普通局。旧5f43714胜和生产3bdb26107败各归其源，不能把旧胜绩记给当前生产或候选，短败局少死不能当收益。\n\n只2生产文件/16插入9删除：有医recovering患者的patientRendezvous实际move后公开queued holdPosition；follow不加hold。mountedEscape共用评分核加显式arrival='hold'，仅此医疗入口恢复原5f几何；其余escape保生产建筑过滤。未改unmedicated逻辑、35%/incomingDamage、owner/记忆、生产预算、非医疗mounted/camp/海军。新队列自然会参与既有原生任务语义，并不保证其他路径行为无变化；非queued后续命令清队列，不锁到满血。\n\n固定源7905→7935原1079未被闲置追击杀，18HP存活；10425→10455原医疗短步不绕路，后续宏观清队列，完整末态同原5f；16245→16275仍接近至heal240内，但hold在射程内改选目标且病人继续受击，非无敌。原56相关检查+新3实际fixture/script runner检查共59通过，tsc0；不改旧断言。测试树2cdb177f只增3测试和完整7905/10425/16245存档，生产patch与test patch均独立可审。局部测试不构成完整修复。\n\n标准0沿原inspect/factory，无换码恢复或人工命令：Grove v9_archer physicalside1，对双正常frozenv8 Ember+Grove；三方500/3/8。pineshade --unseen生成ladder4608²；seed bootstrap_1-unseen-archer-v8-v8-20261015-01已开发，不计新泛化。rules2、冻结184、manifest0490、生产API迁移等价基线未改。源胶囊8648eec2…/1754 payload，1254运行源数据与1494 present源全过程逐hash不变。42个600tick/终局完整world/nextId档与三方policy成对，另factory0 witness。\n\n实际24600→24840终局及24615复原完整闭合原新0。初版诊断observer JSON.parse(undefined)报错保留；v2只安全复制缺省order，不改游戏源。实际新0 16200→16800同源600tick严格闭合16800；原5f同窗也闭合其16800。另双方16200→16245每tick重放分别闭合实际16245，用于排除采样间隙。原较早target-only16245短窗遗漏2042真实pendinghold，已明确，未借它假称实际新0全态相同。\n\n实际16247原骑手4294 attack2670，新hold；首aim/facing差在16248，首attack cooldown差16250，随后7伤从2670转到5241。16260双方骑手位置/97HP相同，离医师237.159<240，但heal CD164；后来双方都掉到21HP。2670原16345死、新16378死；新骑手4294在16381被6027原生28伤杀，旧骑手撑过16800。新1907医师16531死反而晚于旧16450，不能捏造先死医师单因。16800新27死vs旧25，这是实际战斗代价；仍不能把一个微小首差宣称整局唯一充分败因。详细HP/命令/CD/尸体/全存档在first-material-boundary JSON与fine档。\n\n原生hold不追击、仍在自身range选敌开火，仍受击/被推。idle直接acquire是230；max(weaponRange,230)用于attackMove和自动attack重选。330射程骑手在初次idle索敌时不会取得230外单位，但help-call、已锁目标移远仍可引发追击，不能概称远程无需防追。queuedhold屏蔽idle/help反应并改变逐帧选敌，具有实战代价。此轮不再追hold/follow小变体，后续应依完整主军/敌压制/基地战略证据决定。\n\n已亲看native终局overview及16260局部图。图用原生drawWorld与新facing tracker，只证明完整状态布局；绿圈为heal240分析叠加，不代表历史动画/额外治疗。三路线全部标准完整比赛、官方地图/未见种子要求尚未完成；原容器未提交修改恢复缺口继续保留。\n''')

files={}
for pat in ['medical-arrival-hold9ba*','README.medical-arrival-hold9ba.zh.md','native-medical-queued-hold-window*.ts','focused-medical-hold9ba-fine.ts','seal-medical-arrival-hold9ba.py']:
    for q in p.glob(pat):
        if q.name.endswith('-closed-index.json'):continue
        for f in ([q]if q.is_file()else q.rglob('*')):
            if f.is_file():files[str(f.relative_to(p))]=f
# Reference600tick and first true-native aim/damage boundary, already closed and immutable.
for q in [Path(str(of)+'.json'),Path(str(of)+'.log'),Path(str(of)+'.frames'),Path('/tmp/bootstrap-land-army-evidence-20261015/production-base5f-secondboundary16245.frames'),Path('/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary-runtime-source.json')]:
    for f in ([q]if q.is_file()else q.rglob('*')):
        if f.is_file():files['reference5f/'+(str(f.relative_to(q.parent)))]=f
index={'classification':'Medical-arrival9ba rejected after genuine ordinary0 natural24840 loss, fixedsource/3true native windows/59tests/terminal/firstmaterialboundary all sealed. No merged candidate or final bootstrap acceptance.',
 'source':'9ba65d0644db73c365273bb94ce2ff04ccf41330','base':'3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71',
 'dependencies':{'previous3boundaryDiagnostics':'62e4837811068754b14558e8441d755a062aeebb9c6daa5784bae201cf812382','production3bdbLoss':'0d4b83429de9b5ff3736b23f88985574ef1ed240e54bfdf1b0d366a6cabda7ac','productionFirstBoundary':'f7f97f5b3caca259dc87c5530cb573b4f3f1bc456849206127b226e139a82b34','horizon4a52Loss':'5cfda074b7c95804024b9c66b175971889d5aec35fbb39ce4281bbb40778b5be'},
 'files':{n:{'bytes':f.stat().st_size,'sha256':sha(f)}for n,f in sorted(files.items())}}
ix=p/'medical-arrival-hold9ba-closed-index.json';dump(ix.name,index);files[ix.name]=ix
archive=p/'bootstrap-medical-arrival-hold9ba-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
    for n,f in sorted(files.items()):tf.add(f,arcname=n)
with tarfile.open(archive,'r:gz')as tf:
    for n,v in index['files'].items():assert hashlib.sha256(tf.extractfile(n).read()).hexdigest()==v['sha256']
delivery={'archive':str(archive),'bytes':archive.stat().st_size,'payloads':len(files),'sha256':sha(archive),'result':'Unmerged9ba genuine standard0 natural24840 p1loss; first material boundary and terminal full world/nextId/3mem closed.'}
dump('bootstrap-medical-arrival-hold9ba-delivery.json',delivery)
print(json.dumps({'delivery':delivery,'firstAim':aim,'firstPhysical':phys,'firstHp':hp},ensure_ascii=False))
