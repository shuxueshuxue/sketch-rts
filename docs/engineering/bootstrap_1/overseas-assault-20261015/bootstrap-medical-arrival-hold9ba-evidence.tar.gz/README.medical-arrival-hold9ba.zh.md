9ba65d0644db73c365273bb94ce2ff04ccf41330，基于生产3bdb的独立医疗到达候选。完整普通0在24840 tick自然p1胜，我方0单位/0建筑；53永久死、1中立死、花费10774。候选保持未合入，停止叠加护理变体和新普通局。旧5f43714胜和生产3bdb26107败各归其源，不能把旧胜绩记给当前生产或候选，短败局少死不能当收益。

只2生产文件/16插入9删除：有医recovering患者的patientRendezvous实际move后公开queued holdPosition；follow不加hold。mountedEscape共用评分核加显式arrival='hold'，仅此医疗入口恢复原5f几何；其余escape保生产建筑过滤。未改unmedicated逻辑、35%/incomingDamage、owner/记忆、生产预算、非医疗mounted/camp/海军。新队列自然会参与既有原生任务语义，并不保证其他路径行为无变化；非queued后续命令清队列，不锁到满血。

固定源7905→7935原1079未被闲置追击杀，18HP存活；10425→10455原医疗短步不绕路，后续宏观清队列，完整末态同原5f；16245→16275仍接近至heal240内，但hold在射程内改选目标且病人继续受击，非无敌。原56相关检查+新3实际fixture/script runner检查共59通过，tsc0；不改旧断言。测试树2cdb177f只增3测试和完整7905/10425/16245存档，生产patch与test patch均独立可审。局部测试不构成完整修复。

标准0沿原inspect/factory，无换码恢复或人工命令：Grove v9_archer physicalside1，对双正常frozenv8 Ember+Grove；三方500/3/8。pineshade --unseen生成ladder4608²；seed bootstrap_1-unseen-archer-v8-v8-20261015-01已开发，不计新泛化。rules2、冻结184、manifest0490、生产API迁移等价基线未改。源胶囊8648eec2…/1754 payload，1254运行源数据与1494 present源全过程逐hash不变。42个600tick/终局完整world/nextId档与三方policy成对，另factory0 witness。

实际24600→24840终局及24615复原完整闭合原新0。初版诊断observer JSON.parse(undefined)报错保留；v2只安全复制缺省order，不改游戏源。实际新0 16200→16800同源600tick严格闭合16800；原5f同窗也闭合其16800。另双方16200→16245每tick重放分别闭合实际16245，用于排除采样间隙。原较早target-only16245短窗遗漏2042真实pendinghold，已明确，未借它假称实际新0全态相同。

实际16247原骑手4294 attack2670，新hold；首aim/facing差在16248，首attack cooldown差16250，随后7伤从2670转到5241。16260双方骑手位置/97HP相同，离医师237.159<240，但heal CD164；后来双方都掉到21HP。2670原16345死、新16378死；新骑手4294在16381被6027原生28伤杀，旧骑手撑过16800。新1907医师16531死反而晚于旧16450，不能捏造先死医师单因。16800新27死vs旧25，这是实际战斗代价；仍不能把一个微小首差宣称整局唯一充分败因。详细HP/命令/CD/尸体/全存档在first-material-boundary JSON与fine档。

原生hold不追击、仍在自身range选敌开火，仍受击/被推。idle直接acquire是230；max(weaponRange,230)用于attackMove和自动attack重选。330射程骑手在初次idle索敌时不会取得230外单位，但help-call、已锁目标移远仍可引发追击，不能概称远程无需防追。queuedhold屏蔽idle/help反应并改变逐帧选敌，具有实战代价。此轮不再追hold/follow小变体，后续应依完整主军/敌压制/基地战略证据决定。

已亲看native终局overview及16260局部图。图用原生drawWorld与新facing tracker，只证明完整状态布局；绿圈为heal240分析叠加，不代表历史动画/额外治疗。三路线全部标准完整比赛、官方地图/未见种子要求尚未完成；原容器未提交修改恢复缺口继续保留。
