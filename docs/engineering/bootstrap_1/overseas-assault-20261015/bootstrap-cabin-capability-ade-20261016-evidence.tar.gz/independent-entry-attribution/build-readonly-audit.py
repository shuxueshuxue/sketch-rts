"""Parse existing archived data only. No simulation, planners, queries, tests, or source edits."""
from pathlib import Path
import gzip, json, hashlib, math, subprocess, datetime
D=Path('/workspace/.playtest/cabin-load-capability-ade-20261016')
N=D/'native-cabin-metadata-retry-194400-195000'
L=D/'native-cabin-leave-195000-195030'
OUT=Path(__file__).parent
CONTROL=Path('/workspace/sketch-rts-cabin-load-ade-control')
SHIP='unit-p0-carrier-25442'; INSIDE='unit-p0-summoner-40241'
def read(p):
    return json.load(gzip.open(p,'rt') if str(p).endswith('.gz') else open(p))
def rows(p): return [json.loads(x) for x in p.read_text().splitlines() if x]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def units(f): return {u['id']:u for u in f['snapshot']['units']}
def ferry(f): return f['memories']['p0']['naval']['ferries'][SHIP]
def ref(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def brief(u): return {k:u.get(k) for k in ['id','kind','hp','order','deck','cabin','abilityCooldowns']}
def operand_ids(c): return set(c.get('unitIds',[]))|({c['unitId']} if 'unitId' in c else set())
commands=rows(N/'commands.jsonl'); events=rows(N/'events.jsonl'); cabin=rows(N/'cabin-events.jsonl')
query=read(D/'actual194400-cabin-query.json'); selected=commands[2]['command']['unitIds']; pending=[i for i in selected if i!=INSIDE]
after=read(N/'frames/194400-after-diagnostic-public-action.json.gz')
restored=read(N/'frames/194400-restored.json.gz'); entered=read(N/'frames/194401-cabin-unit-p0-summoner-40241-after-step.json.gz')
frames=[]; sampled=[]
for p in sorted((N/'frames').glob('*before-p0.json.gz')):
    f=read(p); u=units(f); m=ferry(f); b=u[SHIP]; passengers=[x for x in u.values() if x.get('deck',{}).get('shipId')==SHIP]
    row={'tick':f['snapshot']['tick'],'frame':p.name,'phase':m['phase'],'sinceTick':m['sinceTick'],'progressTick':m['progress']['tick'],'progressPhase':m['progress']['phase'],'ferryCount':len(f['memories']['p0']['naval']['ferries']),'aboardCount':len(passengers),'insideCount':sum(x.get('cabin',{}).get('shipId')==SHIP for x in passengers),'pendingSevenStillEnter':sum(u[i]['order']=={'type':'enterCabin','shipId':SHIP} for i in pending),'carrierOrder':b['order'],'carrierXY':[b['x'],b['y']],'carrierHeading':b['sailing']['heading']}
    sampled.append(row);frames.append(ref(p))
before610=read(N/'frames/194610-before-p0.json.gz');before595=read(N/'frames/194595-before-p0.json.gz');before625=read(N/'frames/194625-before-p0.json.gz')
b=units(before610)[SHIP];m=ferry(before610);p=m['progress'];raw=read(CONTROL/'src/shared/generated/ship-geometry.json')['ships']['carrier']
scale=b.get('deckScale',math.sqrt(b['cargoCapacity']/24) if 'cargoCapacity' in b else 1.1)*1.2
length=raw['length']*scale
aboard='|'.join(u['id'] for u in before610['snapshot']['units'] if u.get('deck',{}).get('shipId')==SHIP)
angle=abs((b['sailing']['heading']-p['heading']+math.pi)%(2*math.pi)-math.pi)
per=[]
for i in selected:
    e=next((dict(e,rawEventIndex=j) for j,e in enumerate(events) if e.get('type')=='observed-disembark' and e.get('before',{}).get('id')==i),None)
    firstLater=next((dict(c,rawCommandIndex=j) for j,c in enumerate(commands) if c['tick']>194611 and i in operand_ids(c['command'])),None)
    per.append({'id':i,'afterPublic':brief(units(after)[i]),'enteredAt':194401 if i==INSIDE else None,'at194610':brief(units(before610)[i]),'firstObservedEntryOrderTermination':{'tick':194401,'reason':'successful native entry; cabin flag added and order idle'} if i==INSIDE else {'tick':e['tick'],'stage':e['stage'],'rawEventIndex':e['rawEventIndex'],'reason':'native unloadCargo disembark assigns idle','before':brief(e['before']),'after':brief(e['after'])},'firstLaterCommandTrace':firstLater})
early=[dict(c,rawCommandIndex=j) for j,c in enumerate(commands) if c['tick']<=194610 and operand_ids(c['command'])&set(pending)]
report=read(N/'report.json');leaveReport=read(L/'report.json');leaveCommands=rows(L/'commands.jsonl');leaveEvents=rows(L/'events.jsonl');leaveCabin=rows(L/'cabin-events.jsonl')
leaveStates={name:brief(units(read(L/'frames'/f'{name}.json.gz'))[INSIDE]) for name in ['195000-before-p0','195000-after-diagnostic-public-action','195015-before-p0','195030-final']}
casters=[commands[j]['command']['unitId'] for j in [0,1]]
castStates={name:[brief(units(f)[i]) for i in casters] for name,f in [('restored',restored),('afterPublic',after),('afterFirstStep',entered)]}
sources=['src/ai/policy/naval.ts','src/shared/ship-cabin.ts','src/shared/ship-geometry.ts','src/shared/generated/ship-geometry.json','src/shared/sim.ts','src/shared/sim/command-validation.ts','src/shared/sim/frame.ts','src/sdk/commands/frame.ts','src/sdk/game-runner.ts']
rawPaths=[D/'actual194400-cabin-query.json',D/'input-194400.json.gz',D/'diagnostic-metadata-correction.json',D/'native-cabin-capability.ts',D/'native-cabin-capability-metadata-retry.ts',D/'observer-ledger.ts']
for root in [N,L]:
    rawPaths += [root/name for name in ['report.json','actual-launch.json','first-normal-plus-public-diagnostic.json','commands.jsonl','events.jsonl','cabin-events.jsonl','final.json.gz','native-step-costs.jsonl']]
    rawPaths += sorted((root/'frames').glob('*.json.gz'))
audit={
 'classification':'Independent read-only attribution of an existing public cabin capability playprobe and its already-completed leave follow-up. No new AI capability, ordinary opening, full-game victory, or bootstrap acceptance inferred.',
 'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewScope':{'productionChanges':False,'newNativeRuns':0,'newQueryRuns':0,'newTestRuns':0,'originalEvidenceWrites':False,'source':str(CONTROL),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=CONTROL,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=CONTROL,text=True),'primary':str(N),'followUpReadOnly':str(L)},
 'outcome':{
  'allEightHaveEnterAfterPublic':all(units(after)[i]['order']=={'type':'enterCabin','shipId':SHIP} and not units(after)[i].get('cabin') for i in selected),
  'onlyActualEntry':{'tick':194401,'id':INSIDE,'capacity':21,'used':2,'free':19,'selectedBudget':query['selectedBudget']},
  'sevenInterruptedByOtherPolicyBeforeUnload':False,
  'firstReturnDecisionTick':194610,'firstSavedReturnBeforeThinkTick':194625,'firstNativeUnloadTick':194611,
  'cause':'The pre-existing ferry loading progress timeout fires at 194610; cancelFerry publishes the carrier unload order, and the next native step unloads all 10 exposed deck occupants, assigning idle to the 7 still waiting to enter. 194415 updates pickup/sinceTick only and is not a return transition.',
  'geometryBoundary':'The saved deck poses and native queue implementation support a crowded hatch approach with no further completed entry in this window. They do not identify an exact blocking obstacle or prove a hatch/pathfinding bug or impossibility of all routes. No internal per-tick hatch-active/route diagnostic was recorded.',
  'followUp':'Public leave succeeds at 195000; original naval publishes unload at 195015; native disembark occurs at 195016, preserving 95 HP. No additional human unloadPassenger action appears.'},
 'initialPublicAction':{'zeroBasedRawCommandIndex':2,'entry':commands[2],'selectedIds':selected,'selectedQueryIdsMatch':selected==query['selectedIds'],'firstAfterPublicFrame':ref(N/'frames/194400-after-diagnostic-public-action.json.gz'),'twoPrecedingNormalCommandTraces':commands[:2],'twoCastersDisjointFromSelected':set(casters).isdisjoint(selected),'twoNormalCastStateEvidence':castStates,'twoCastInterpretation':'These are normal abilities intents on other hulls, not the diagnostic metadata exception and not orders replacing the 8 selected units. Their archived cooldowns stay absent and no corresponding birth is observed; do not claim two successful summons. Command traces alone do not attest to native effects.'},
 'perSelectedUnit':per,
 'allEarlyCommandTracesTouchingPendingSeven':early,
 'earlyCastDoesNotCancelEntry':{'rawCommandIndex':124,'entry':commands[124],'at194610StillEnter':units(before610)['unit-p0-summoner-37753']['order'],'at194610SummonCooldown':units(before610)['unit-p0-summoner-37753'].get('abilityCooldowns'),'interpretation':'The 194505 summon intent has a real cooldown/birth effect in this run but leaves the pending enterCabin order in place; it is not the later entry cancellation.'},
 'missionTimeline':{
  'all40BeforeP0Frames':sampled,
  'pickupUpdate':{'tick':194415,'rawCommandIndex':19,'entry':commands[19],'source':'naval.ts:929-936','phaseAt194415Before':'loading','phaseAt194430Before':'loading','sinceTickAt194430':194415,'progressAt194430':193800,'meaning':'New pickup goal does not reset measured physical progress.'},
  'boardingStop':{'tick':194430,'rawCommandIndices':[36,37],'entries':[commands[36],commands[37]],'source':'naval.ts:868-879','meaning':'Normal recruitment requests shore summoner 8114 and stops the moving carrier for rendezvous. It does not change any of the 7 passenger entry orders or set return phase.'},
  'timeoutGate':{'source':'naval.ts:716-733','simTicksPerSecond':20,'timeoutTicks':800,'comparison':'strict >','progressTick':p['tick'],'at194595Age':194595-p['tick'],'at194595Fires':194595-p['tick']>800,'at194610Age':194610-p['tick'],'at194610Fires':194610-p['tick']>800,'samePhase':p['phase']==m['phase'],'sameActualAboardIdString':p['crew']==aboard,'carrierProfileLength':length,'translationSinceProgress':math.hypot(b['x']-p['x'],b['y']-p['y']),'bowTravelSinceProgress':angle*length/2,'movementGate':32,'otherFerryCount':len(before610['memories']['p0']['naval']['ferries'])-1,'convoyException':False,'sinceTickIsNotUsedByThisGate':True,'cabinStatusAndDeckLocalWalkingNotMeasured':'The progress key records hull translation/heading, mission phase and aboard ID membership. Entry into cabin changes no membership ID and does not reset progress.'},
  'cancel':{'tick':194610,'rawCommandIndex':247,'entry':commands[247],'source':'naval.ts:973-987','phaseAfter':'return','crewIdsAfter':ferry(before625)['crewIds'],'progressTickAfter':ferry(before625)['progress']['tick'],'retryUntilAfter':before625['memories']['p0']['naval']['ferryRetryUntil'][SHIP]},
  'unload':{'tick':194611,'stage':'after-step','events':[{'rawEventIndex':j,'id':e['before']['id'],'beforeOrder':e['before']['order'],'afterOrder':e['after']['order']} for j,e in enumerate(events) if e['tick']==194611 and e['type']=='observed-disembark'],'source':'sim.ts:2021-2041','inside40241Skipped':True},
  'returnWait':'ferryRetryUntil=195010 blocks ferryCommands during the rest of the 600-tick first window. The endpoint alone is not evidence of a permanent return deadlock.'},
 'physicalApproachEvidence':{
  'door':query['ship']['door'],'scaledStaticObstacles':query['ship']['deckObstacles'],
  'at194610Deck':[brief(u) for u in before610['snapshot']['units'] if u.get('deck',{}).get('shipId')==SHIP],
  'queueImplementation':'ship-cabin.ts:172-201 selects the closest waiting crew per native frame; failure to find/advance to a temporary hatch endpoint retains enterCabin, and only eligible walking friendly idle/entry crew yield. Rams are mechanical, ineligible for cabin entry and yield. canEnter permits a static route without temporary bodies; it does not promise a dynamically free path through this 11-body arrangement.',
  'observedLocalMotion':[{ 'id':i,'afterPublicDeck':units(after)[i].get('deck'),'at194610Deck':units(before610)[i].get('deck'),'localTranslation':math.hypot(units(after)[i]['deck']['x']-units(before610)[i]['deck']['x'],units(after)[i]['deck']['y']-units(before610)[i]['deck']['y'])} for i in pending],
  'limit':'No attribution to a particular ram, exact hatch-active crew, or route-search failure without recorded internal route observations. The parent separately viewed the 194610 world; this review independently uses raw positions and source, not a new visual render.'},
 'traceSemantics':{
  'source':'shared/sim/frame.ts:18-24,37-46; sdk/commands/frame.ts:57-64; sdk/game-runner.ts:347-364; shared/sim/command-validation.ts:36-38',
  'meaning':'applyCommandFrame calls afterApply even when issueFrameCommand transiently returns. SDK then calls afterIssue/onCommand. Therefore commands.jsonl counts are issued intent/trace rows, not counts of successful native effects.',
  'primaryTraceRows':len(commands),'followUpTraceRows':len(leaveCommands),
  'inside40241CastTraces':[{'rawCommandIndex':j,'tick':c['tick']} for j,c in enumerate(commands) if c['command'].get('unitId')==INSIDE and c['command']['type']=='cast'],
  'certainTransientExample':{'followUpRawCommandIndex':1,'entry':leaveCommands[1],'beforeInside':leaveStates['195000-before-p0']['cabin'],'afterPublicCooldown':leaveStates['195000-after-diagnostic-public-action']['abilityCooldowns'],'why':'Legality returns transient Leave the cabin before acting. Entry is still traced; no native cast, no cooldown/body effect.'},
  'actualCastCounterexample':{'followUpRawCommandIndex':16,'entry':leaveCommands[16],'actualBirthEvent':[e for e in leaveEvents if e.get('commandIndex')==16],'nativeDisembarkBeforeCooldown':next(e['before']['abilityCooldowns'] for e in leaveEvents if e['type']=='observed-disembark'),'why':'At 195015 the passenger is exposed on deck, so the cast can take effect after the carrier unload order and before the next native step.'}},
 'leaveFollowUp':{'normalThreeAi':True,'onlyDiagnosticAction':leaveCommands[5],'cabinEvents':leaveCabin,'stateFrames':leaveStates,'unloadTrace':leaveCommands[14],'actualDisembarkEvents':[e for e in leaveEvents if e['type']=='observed-disembark'],'noAdditionalHumanUnload':not any(c['command']['type']=='unloadPassenger' or c.get('scriptId','').startswith('diagnostic') and c['command']['type']=='unload' for c in leaveCommands)},
 'oldHarnessFailure':read(D/'diagnostic-metadata-correction.json'),
 'existingRunProvenance':{'primary':{k:report[k] for k in ['classification','head','start','end','winner','naturalComplete','counts','sourcePre','sourcePost','frozenPre','frozenPost','restored']},'leave':{k:leaveReport[k] for k in ['classification','head','start','end','winner','naturalComplete','counts','sourcePre','sourcePost','frozenPre','frozenPost','restored']},'verificationLimit':'Clean current source HEAD/status and hashes below are independently read. Per-run 1464-source/184-frozen invariance and full restore closure are retained original report evidence, not a new historical rerun.'},
 'nextMinimalValidationBoundary':['Use a ferry-owned cargo stage for entry/queue observation and a leave-before-unload stage; the public probe does not add these to policy.','Progress must distinguish real cabin transitions and deck queue motion from hull/membership-only progress. Do not simply increase a timeout or append enterCabin once.','Keep real physical paths/capacity and native unload rules; inspect a controlled actual crowded-deck case before claiming additional passenger capacity or exact door geometry fix.','After a real policy candidate, compare actual crossing/landing/combat in normal full-game continuations. This capability probe alone meets no victory/generalization milestone.'],
 'blockers':{'audit':[],'remainingUnproven':['Exact dynamic door approach obstruction/internal queue route','AI ownership and cargo-stage implementation','Actual additional useful combat payload and complete-game benefit']},
 'sourceFiles':[ref(CONTROL/p) for p in sources],
 'evidenceFiles':[ref(p) for p in dict.fromkeys(rawPaths)]
}
path=OUT/'CABIN-ACTUAL-ATTRIBUTION-REVIEW.json';path.write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
readme='''# Cabin actual attribution review

Read-only audit of existing fixed `ade412414d9232206f39e20f0182f0086605433c`, rules 2 probe evidence. No production edits, native runs, policy queries, or tests were performed. All outputs here are separate from the original evidence directory.

- At 194400, zero-based command row 2 is the sole public entry group action. Its after-action full frame proves all eight selected units hold `enterCabin`; only summoner 40241 actually enters at 194401.
- The other seven retain that entry order through every saved pre-think frame up to 194610. Their first observed termination is **194611 native unload**, after normal naval row 247 at **194610** orders the carrier back to the original departure shore. Native `unloadCargo` assigns `idle` on actual disembark. The later naval/backline/general orders are subsequent orders ashore, not causes of the failed entry attempt.
- **194415 is not a transition to return.** Naval row 19 selects another pickup and updates `sinceTick`; phase stays `loading`, and measured `progress.tick` stays 193800. At 194595, age is 795; at 194610, age is 810, first exceeding the strict 800-tick gate. Carrier displacement and bow travel are both about 3.538 pixels, below the 32-pixel progress gate; aboard IDs and phase are unchanged, and no other ferry supplies the convoy exception. This is the original loading progress timeout.
- Rams occupy the deck and cannot yield as walking cabin crew. Retained orders and saved local poses support waiting on a crowded approach. They do **not** prove a particular ram is the cause, identify an internal hatch route failure, or prove the door is broken. The probe records no internal per-tick hatch-active/path diagnostics.
- The already-completed separate leave follow-up proves public `leaveCabin` at **195000** opens the passenger onto deck; original naval `unload` at **195015** then produces real disembark at **195016**, still 95 HP. No extra human unload command was needed. This is a public capability demonstration, not an AI cargo-stage implementation.
- **708 primary + 28 follow-up command rows are traces, not 736 successfully executed actions.** SDK `afterApply` / `onCommand` also runs when a transient legality check skips an intent. In particular 40241's 195000 inside-cabin cast trace has no effect, while its 195015 exposed-deck cast has a recorded real birth and cooldown. The two initial other-hull cast rows are normal nonfatal intents and do not replace any selected entry orders; their frames do not show successful summons.
- The older driver attempt remains an external trace-metadata error, exit 1 with two recorded normal intents and **zero native steps**. Its files are preserved separately; it is not evidence of a native entry failure or game loss.

`CABIN-ACTUAL-ATTRIBUTION-REVIEW.json` contains per-unit first-change attribution, all 40 pre-think phase records, exact zero-based command/event indices, source locations, timing arithmetic, the leave evidence, source SHA-256 values, and original raw-file hashes. `build-readonly-audit.py` only parses existing archives and source; it does not import or run simulation code.

The original reports retain exact restore and unchanged production/frozen source evidence. Neither short window establishes an AI win, ordinary-start result, improved combat payload, or bootstrap acceptance. No audit blocker remains. Exact physical approach attribution and a ferry-owned entry/leave/landing sequence still require focused policy/physics evidence before any broader claim.
'''
(OUT/'README.md').write_text(readme)
index={'classification':'Independent review outputs; original evidence is read-only.','files':[ref(p) for p in [OUT/'build-readonly-audit.py',path,OUT/'README.md']]}
(OUT/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'review':ref(path),'readme':ref(OUT/'README.md'),'index':ref(OUT/'INDEX.json'),'allEightEnter':audit['outcome']['allEightHaveEnterAfterPublic'],'preThinkFrames':len(sampled),'pendingSevenAt194610':sampled[14]['pendingSevenStillEnter'],'primaryRows':len(commands),'leaveRows':len(leaveCommands)},indent=2))
