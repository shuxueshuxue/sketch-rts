import os,json,time,pathlib,hashlib,sys
D=pathlib.Path('/workspace/.playtest/cabin-auto-loading-a7-20261016'); cap=json.loads((D/'fixed-runtime.json').read_text()); O=D/'native-normal-202800'
if (O/'actual-launch.json').exists(): raise SystemExit('Actual launch already exists; no restart')
maximum=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text()); current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()); free=maximum-current
record={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'cgroupMax':maximum,'cgroupCurrent':current,'headroom':free,'minimum':2*1024**3,'heapMiB':1024,'sourceHead':cap['head'],'runtimeSHA256':hashlib.sha256((D/'fixed-runtime.json').read_bytes()).hexdigest(),'launchAllowed':free>=2*1024**3,'command':['node','--max-old-space-size=1024','--import','tsx',str(D/'native-normal-202800.ts')],'label':'unique fixed normal3AI202800 continuation, not clinical or fresh0'}
(D/'launch-guard-normal-v1.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record),flush=True)
if not record['launchAllowed']: raise SystemExit(75)
tmp=D/'runtime-tmp';tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp);os.chdir(cap['sourceRoot']);os.execvp('node',record['command'])
