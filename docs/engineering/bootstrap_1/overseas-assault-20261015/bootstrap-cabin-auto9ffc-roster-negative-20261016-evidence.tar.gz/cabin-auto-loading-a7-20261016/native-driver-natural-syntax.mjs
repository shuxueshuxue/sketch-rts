// .playtest/cabin-auto-loading-a7-20261016/native-normal-202800.ts
import { readFileSync, writeFileSync, mkdirSync, appendFileSync, renameSync, existsSync } from "node:fs";
import { gzipSync, gunzipSync } from "node:zlib";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { isDeepStrictEqual } from "node:util";

// .playtest/cabin-auto-loading-a7-20261016/observer-ledger.ts
var copy = (value) => JSON.parse(JSON.stringify(value));
var NativeLedger = class {
  units = /* @__PURE__ */ new Map();
  buildings = /* @__PURE__ */ new Map();
  terminal = /* @__PURE__ */ new Set();
  buildingTerminal = /* @__PURE__ */ new Set();
  beforeShips = /* @__PURE__ */ new Map();
  constructor(units, buildings) {
    this.units = new Map(units.map((u) => [u.id, copy(u)]));
    this.buildings = new Map(buildings.map((b) => [b.id, copy(b)]));
  }
  beforeStep(units) {
    this.beforeShips = new Map(units.filter((u) => u.sailing).map((u) => [
      u.id,
      { ship: copy(u), passengers: units.filter((p) => p.deck?.shipId === u.id).map(copy) }
    ]));
  }
  observe(tick, stage, units, buildings, lastHit2) {
    const events = [], current = new Map(units.map((u) => [u.id, u]));
    const death = (id, previous, unit) => {
      if (this.terminal.has(id)) return;
      this.terminal.add(id);
      events.push({
        tick,
        stage,
        type: "native-unit-terminal",
        id,
        previous,
        atObservation: unit ? copy(unit) : null,
        observedAs: unit ? "hp<=0-before-cleanup" : "removed-by-native-step",
        permanent: (unit ?? previous).expiresTick === void 0,
        lastNativeHit: lastHit2.get(id),
        preStepHull: stage === "after-step" ? this.beforeShips.get(id) : void 0,
        preStepCarryingHull: stage === "after-step" ? this.beforeShips.get((unit ?? previous).deck?.shipId) : void 0
      });
    };
    for (const [id, previous] of this.units) {
      const unit = current.get(id);
      if (!unit) {
        death(id, previous, void 0);
        events.push({
          tick,
          stage,
          type: "unit-removal",
          previous,
          lastNativeHit: lastHit2.get(id),
          preStepHull: stage === "after-step" ? this.beforeShips.get(id) : void 0
        });
      } else {
        if (unit.hp <= 0) death(id, previous, unit);
        if (previous.hp <= 0 && unit.hp > 0) {
          this.terminal.delete(id);
          events.push({ tick, stage, type: "unit-returned-positive-hp", before: previous, after: copy(unit) });
        }
        if (previous.owner !== unit.owner) events.push({ tick, stage, type: "owner-change", before: previous, after: copy(unit) });
        if (previous.deck && !unit.deck) events.push({ tick, stage, type: "observed-disembark", before: previous, after: copy(unit) });
        else if (previous.deck?.shipId !== unit.deck?.shipId) events.push({ tick, stage, type: "observed-parent-change", before: previous, after: copy(unit) });
      }
    }
    for (const unit of units) if (!this.units.has(unit.id)) {
      if (unit.hp > 0) this.terminal.delete(unit.id);
      events.push({ tick, stage, type: "unit-birth-observed", unit: copy(unit) });
      if (unit.hp <= 0) death(unit.id, void 0, unit);
    }
    const cb = new Map(buildings.map((b) => [b.id, b]));
    for (const [id, previous] of this.buildings) {
      const building = cb.get(id);
      if ((!building || building.hp <= 0) && !this.buildingTerminal.has(id)) {
        this.buildingTerminal.add(id);
        events.push({
          tick,
          stage,
          type: "native-building-terminal",
          previous,
          atObservation: building ? copy(building) : null,
          lastNativeHit: lastHit2.get(id)
        });
      }
      if (!building) events.push({ tick, stage, type: "building-removal", previous });
    }
    for (const building of buildings) if (!this.buildings.has(building.id)) events.push({ tick, stage, type: "building-birth-observed", building: copy(building) });
    this.units = new Map(units.map((u) => [u.id, copy(u)]));
    this.buildings = new Map(buildings.map((b) => [b.id, copy(b)]));
    return events;
  }
};

// .playtest/cabin-auto-loading-a7-20261016/native-normal-202800.ts
var D = "/workspace/.playtest/cabin-auto-loading-a7-20261016";
var cap = JSON.parse(readFileSync(D + "/fixed-runtime.json", "utf8"));
var S = cap.sourceRoot;
var O = D + "/native-normal-202800";
var H = cap.observedHull;
var sha = (v) => createHash("sha256").update(v).digest("hex");
var copy2 = (v) => JSON.parse(JSON.stringify(v));
var load = (p) => import(pathToFileURL(S + "/" + p).href);
var atomic = (p, v) => {
  writeFileSync(p + ".tmp", v);
  renameSync(p + ".tmp", p);
};
var emit = (name, v) => appendFileSync(O + "/" + name + ".jsonl.gz", gzipSync(JSON.stringify(v) + "\n", { level: 3 }));
if (process.cwd() !== S || existsSync(O + "/actual-launch.json")) throw Error("Fixed cwd and new output required");
if (sha(readFileSync(import.meta.filename)) !== cap.driverSHA256 || sha(readFileSync(D + "/observer-ledger.ts")) !== cap.observerSHA256) throw Error("Driver/observer changed");
function sourceProof() {
  const changed = Object.entries(cap.hashes).filter(([p, h]) => sha(readFileSync(S + "/" + p)) !== h).map(([p]) => p), head = execFileSync("git", ["-C", S, "rev-parse", "HEAD"], { encoding: "utf8" }).trim(), status = execFileSync("git", ["-C", S, "status", "--porcelain"], { encoding: "utf8" });
  if (changed.length || head !== cap.head || status) throw Error("Source not fixed");
  return { head, files: Object.keys(cap.hashes).length, changed, status };
}
var raw = readFileSync(cap.inputPath);
if (sha(raw) !== cap.inputSHA256) throw Error("Original normal202800 input changed");
var input = JSON.parse(gunzipSync(raw).toString());
var sourcePre = sourceProof();
mkdirSync(O + "/frames", { recursive: true });
for (const n of ["commands", "hits", "events", "effects", "states", "think-inputs", "cabin-events"]) writeFileSync(O + "/" + n + ".jsonl.gz", "");
var startedAtUtc = (/* @__PURE__ */ new Date()).toISOString();
var [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider }, { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runAiGameLoop }, { shipPassengers }, { isInCabin, shipCabinUsage }, { effectiveCombatRating }, { deckLoad, deckPointFits }, { shipProfile }, { checkCommandLegality }] = await Promise.all([
  load("src/shared/sim.ts"),
  load("src/ai/planner-context.ts"),
  load("scripts/bootstrap_1-planner.ts"),
  load("src/ai/game-runner.ts"),
  load("src/shared/ship-geometry.ts"),
  load("src/shared/ship-cabin.ts"),
  load("src/ai/policy/v6/strength.ts"),
  load("src/shared/decks.ts"),
  load("src/shared/ship-geometry.ts"),
  load("src/shared/sim/command-validation.ts")
]);
var g = createGame("bareDuel");
var memory = createAiMemoryProvider();
restoreSnapshotIntoGame(g, input.snapshot, input.nextId);
for (const [owner, m] of Object.entries(input.memories)) memory.set(owner, copy2(m));
var full = () => copy2({ snapshot: snapshotGame(g), nextId: g.nextId, memories: Object.fromEntries(Object.keys(input.memories).map((owner) => [owner, memory.get(owner)])) });
var initial = full();
var restore = { world: isDeepStrictEqual(initial.snapshot, input.snapshot), nextId: g.nextId === input.nextId, all3mem: isDeepStrictEqual(initial.memories, input.memories) };
if (g.tick !== cap.start || Object.values(restore).some((v) => !v)) throw Error("Strict full restore failed");
var frozenRoot = frozenPolicyRoot();
var frozenProof = () => {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([p, h]) => sha(readFileSync(frozenRoot + "/" + p)) !== h).map(([p]) => p);
  if (changed.length || Object.keys(frozenPolicyManifest.files).length !== 184 || frozenPolicyManifest.rulesVersion !== 2) throw Error("Rules2 frozen184 changed");
  return { rulesVersion: 2, revision: frozenPolicyManifest.revision, files: 184, changed };
};
var frozenPre = frozenProof();
var normal = await createBootstrapCommandPlanner(memory);
if (!isDeepStrictEqual(full(), initial)) throw Error("Planner setup altered input");
var agents = cap.agents;
var counts = { steps: 0, commands: 0, hits: 0, events: 0, p0Plans: 0 };
var ledger = new NativeLedger(g.units, g.buildings);
var lastHit = new Map(Object.entries(cap.inheritedLastHits ?? {}));
var cabins = new Map(g.units.map((u) => [u.id, u.cabin?.shipId ?? null]));
var commandIndex;
var signature = "";
var observedRequiredCheckpoint = false;
var observationStopped = false;
var stopRequest;
var capture = (stage) => atomic(O + "/frames/" + g.tick + "-" + stage + (commandIndex === void 0 ? "" : "-" + commandIndex) + ".json.gz", gzipSync(JSON.stringify({ ...full(), checkpointStage: stage, commandIndex })));
function state(stage) {
  const hull2 = g.units.find((u) => u.id === H), cargo2 = hull2 ? shipPassengers(g.units, hull2) : [], mission = memory.get("p0")?.naval?.ferries?.[H], world = snapshotGame(g);
  const force = cargo2.filter((u) => u.hp > 0 && u.expiresTick === void 0).reduce((n, u) => n + effectiveCombatRating(world, u), 0);
  const row = copy2({ tick: g.tick, stage, commandIndex, winner: g.match.winner, gold: g.players.p0.gold, counts, hull: hull2, mission, cargo: cargo2.map((u) => ({ id: u.id, kind: u.kind, x: u.x, y: u.y, hp: u.hp, radius: u.radius, deck: u.deck, cabin: u.cabin, order: u.order, orderQueue: u.orderQueue })), usage: hull2 ? shipCabinUsage(g, hull2) : null, mass: hull2 ? deckLoad(g.units, hull2) : null, loadCapacity: hull2 ? shipProfile(hull2)?.loadCapacity : null, actualCargoPower: force, originalRequired: cap.originalRequired });
  emit("states", row);
  const next = JSON.stringify([mission?.phase, mission?.cabinLoad?.stage, mission?.cabinLoad?.packing?.phase, cargo2.map((u) => [u.id, isInCabin(u)])]);
  if (next !== signature) {
    signature = next;
    capture("physical-transition-" + stage);
  }
  if (force >= cap.originalRequired && !observedRequiredCheckpoint) {
    observedRequiredCheckpoint = true;
    capture("actual-original-force-reached-" + stage);
  }
  if (g.tick % 300 === 0 || g.match.winner) atomic(O + "/progress.json", JSON.stringify({ classification: cap.classification, pid: process.pid, tick: g.tick, counts, latest: row }));
}
function observe(stage, relevantCommand = false) {
  let physical = false;
  for (const e of ledger.observe(g.tick, stage, g.units, g.buildings, lastHit)) {
    emit("events", { ...e, eventIndex: counts.events++, commandIndex });
    if (e.type === "native-unit-terminal" && e.permanent || e.type === "native-building-terminal") capture("terminal-" + stage);
    if (e.type === "observed-parent-change" && (e.after?.deck?.shipId === H || e.before?.deck?.shipId === H)) {
      physical = true;
      capture("actual-parent-" + stage);
    }
  }
  for (const u of g.units) {
    const now = u.cabin?.shipId ?? null, old = cabins.get(u.id) ?? null;
    if (now !== old) {
      emit("cabin-events", copy2({ tick: g.tick, stage, commandIndex, id: u.id, from: old, to: now, unit: u }));
      cabins.set(u.id, now);
      if (now === H || old === H) {
        physical = true;
        capture("actual-cabin-" + stage);
      }
    }
  }
  const packing = memory.get("p0")?.naval?.ferries?.[H]?.cabinLoad?.packing;
  if (stage !== "before-step" && (relevantCommand || physical || stage === "after-step" && (g.tick % 300 === 0 || packing && g.tick % 15 === 0))) state(stage);
}
g.observer = { hit(a, t, damage, hpBefore) {
  const h = copy2({ tick: g.tick, attacker: a.id, attackerOwner: a.owner, attackerKind: a.kind, target: t.id, targetOwner: t.owner, targetKind: t.kind, damage, hpBefore, hpAfter: t.hp, attackerDeck: a.deck, targetDeck: t.deck });
  emit("hits", h);
  lastHit.set(t.id, h);
  counts.hits++;
} };
var planner = (ctx) => {
  if (ctx.owner === "p0") {
    if (g.tick <= cap.detailedPreThinkUntil || g.tick % 600 === 0) capture("before-p0");
    emit("think-inputs", { tick: g.tick, sha256: sha(JSON.stringify(full())) });
    counts.p0Plans++;
  }
  return normal(ctx);
};
atomic(O + "/actual-launch.json", JSON.stringify({ classification: cap.classification, startedAtUtc, pid: process.pid, cwd: process.cwd(), argv: process.argv, driverSHA256: cap.driverSHA256, observerSHA256: cap.observerSHA256, inputPath: cap.inputPath, inputSHA256: sha(raw), sourcePre, frozenPre, restore, agents, start: cap.start, observationEnd: cap.end, subjectMode: "All three normal planners; normal(ctx) returned unchanged; zero added manual commands. Fixed changed-code continuation, not fresh0. Input is original normal-a7 202800, never human202801.", originalRequiredScope: "Original202800 requirement is only an observed checkpoint, never an admission override. All sailing/deployment uses the normal dynamic policy gates.", observerProtocol: cap.observerProtocol, rawEncoding: "Concatenated gzip members, each decodes to one original JSONL record; full states/3mem are gzip files. commandIndex is this continuation local zero-based.", lastHitBoundary: "Inherited actual normal-a7 streams strictly before202800; no same-tick later-command hit is presumed already observed." }, null, 2));
capture("strict-restored-before-think");
state("restored");
function relevant(command) {
  const hull2 = g.units.find((u) => u.id === H), ids = /* @__PURE__ */ new Set([H, ...shipPassengers(g.units, hull2 ?? { id: H }).map((u) => u.id), ...memory.get("p0")?.naval?.ferries?.[H]?.crewIds ?? []]);
  return [...command.unitIds ?? [], command.unitId, command.transportId, command.passengerId, command.targetId].some((id) => ids.has(id));
}
var ObservationStop = class extends Error {
};
var result;
try {
  result = runAiGameLoop({ name: "automatic physical ferry packing", game: g, agents, maxTicks: cap.end, thinkInterval: 15, commandPlanner: planner }, { afterCommand(e) {
    if (e.owner === "p0" && e.scriptId === "naval" && relevant(e.command)) {
      const ids = new Set(e.command.unitIds ?? [e.command.passengerId]), hullId = e.command.transportId;
      emit("effects", copy2({ tick: e.tick, commandIndex: counts.commands, owner: e.owner, scriptId: e.scriptId, command: e.command, legalityBefore: checkCommandLegality(e.before, e.owner, e.command) ?? null, snapshotChanged: !isDeepStrictEqual(e.before, e.after), before: e.before.units.filter((u) => ids.has(u.id) || u.id === hullId || u.deck?.shipId === hullId), after: e.after.units.filter((u) => ids.has(u.id) || u.id === hullId || u.deck?.shipId === hullId) }));
    }
  }, onCommand(e) {
    commandIndex = counts.commands++;
    emit("commands", copy2({ tick: e.tick, commandIndex, owner: e.owner, scriptId: e.scriptId, command: e.command }));
    observe("after-command", e.owner === "p0" && relevant(e.command));
    commandIndex = void 0;
  }, beforeStep() {
    observe("before-step");
    ledger.beforeStep(g.units);
  }, onStep() {
    counts.steps++;
    observe("after-step");
    if (g.tick % 600 === 0 || g.match.winner) capture("complete-periodic-after-step");
    if (g.tick % 600 === 0 && existsSync(O + "/observation-stop.json")) {
      const request = JSON.parse(readFileSync(O + "/observation-stop.json", "utf8"));
      if (request.authorizedByParent === true && request.sourceHead === cap.head && request.reason && request.evidence) {
        observationStopped = true;
        stopRequest = request;
        throw new ObservationStop(request.reason);
      }
    }
  } });
} catch (error) {
  if (!(error instanceof ObservationStop)) {
    capture("unexpected-interruption");
    atomic(O + "/interruption.json", JSON.stringify({ tick: g.tick, pid: process.pid, counts, error: String(error), warning: "Not a natural outcome; midstep/midcommand emergency capture is not automatically a clean resume boundary." }, null, 2));
    throw error;
  }
}
var final = full();
var sourcePost = sourceProof();
var frozenPost = frozenProof();
var hull = g.units.find((u) => u.id === H);
var cargo = hull ? shipPassengers(g.units, hull) : [];
capture("final");
atomic(O + "/final.json.gz", gzipSync(JSON.stringify(final)));
atomic(O + "/report.json", JSON.stringify({ classification: cap.classification, startedAtUtc, endedAtUtc: (/* @__PURE__ */ new Date()).toISOString(), pid: process.pid, start: cap.start, end: g.tick, winner: g.match.winner, naturalComplete: !!g.match.winner, observationStopped, stopRequest, finiteObservationOnly: !g.match.winner, counts, restore, sourcePre, sourcePost, frozenPre, frozenPost, elapsedMs: result.elapsedMs, cpuMs: result.cpuMs, observedOriginalRequiredCheckpoint: observedRequiredCheckpoint, actualFinal: { cargo: cargo.length, inside: cargo.filter(isInCabin).length, usage: hull ? shipCabinUsage(g, hull) : null, mass: hull ? deckLoad(g.units, hull) : null, allOpenNativeFit: hull ? cargo.filter((u) => !isInCabin(u)).every((u) => deckPointFits(hull, u, u.deck, g.units)) : false }, finalSHA256: sha(readFileSync(O + "/final.json.gz")) }, null, 2));
console.log(JSON.stringify({ end: g.tick, winner: g.match.winner, counts, observedOriginalRequiredCheckpoint: observedRequiredCheckpoint, sourcePost, frozenPost }));
