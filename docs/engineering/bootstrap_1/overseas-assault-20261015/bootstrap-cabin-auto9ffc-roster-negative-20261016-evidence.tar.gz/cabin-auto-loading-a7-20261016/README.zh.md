# 自动舱室与甲板装载候选：固定源码验证中

本目录只对应独立 `9ffc75b9b3a4d3e42c4b941776bf5f87ad43448d`。它从原正常三方 AI 的 a7 完整 202800 档换代码继续，绝非 fresh0、人工 202801 临床延续、普通对局验收或已获胜。输入、驱动、观察器、全部已检出 tracked 文件的 SHA 均由 `fixed-runtime.json`、`source-capsule.json` 固定。`native-normal-202800/actual-launch.json` 是真实 PID/UTC/严格恢复的事实来源。

## 代码归属

父 `68cad5b018b82b64cd8813d8ea056e04bc94f8f4` 相对原 a7 仅引入 root `97cecc14cc0e3a1e670f451b574e59057e1c83fa` 的 native shore canBoard/boardUnit 2px 放置一致性三文件，逐字节相等。当前提交只新增五份生产文件/修改点及四份检查/fixture，共九文件；`candidate-vs-native-base.patch`、`native-admission-only.patch` 分别保留。没有 root/main/其它活动树写入。冻结规则 2/184 manifest 与完整 historical 497 源逐项等于 Git d1ae；原三路线、required1.4、思考15、正常对手保留。原容器未提交修改恢复缺口仍在。

纯布局使用实际船型/身体/质量/舱额与 native deck 原语构造候选；执行器只发公共命令，按真实卸岸、board、inside、deck 位置推进。布局不是预留实际 floor，也不把 inside 当现时海战可开火军力。202800 的 20.115569 门槛只作观测，策略仍按动态原准入决定出航/部署。

## 检查与边界

最终 `final-targeted-tests-v5.log` 为三文件 24/24 通过，`final-tsc-v3.log` 对应实际 exit0。此前较大检查 `final-related-tests-v1.log` 是 11 文件 130 项，125通过/5失败；四项旧同时 board 六人断言已改为保完整六人名单/原军力且真实串行执行，最终复验通过。余一默认 escort 的 x368>504 在独立 clean68cad 基线完全同错，见 `baseline68cad-escort-focused.log`。这不是全套全绿；早期红日志均保留。子审 readset 早于最后 pointer 归属小防护，不能冒称其核过最后新增字节。

## 真实执行协议

唯一 `native-normal-202800.ts` 从原正常档严格恢复全 world、nextId、三方 memory；三方 planner 均原样返回 normal(ctx)，无额外人工公令、资源、位置、队列或 HP 写入。所有真实 commands/hits/events/cabin 转变用逐条 gzip member 流式保存。真实公令效果含合法性和 before/after，trace 意图不当作成功效果。每600 native after-step 完整保存；前12000 tick 每15保存 preP0，之后每600，全部 P0 思考输入 hash 始终保留。HP0、cleanup、到期与永久损失分开。

同一个 Game 持续到自然 winner；没有 12000/144000 任意比赛截止。若后续实际证实阻塞，需要 parent 授权的 observation-stop 文件，仅在600完整边界执行；winnernull、观察停止与自然失败必须区分。实际装载力达标、26人、无伤、局部测试都不是完整比赛改进或 bootstrap 完成。

人工三段26人实际能力只归已封 `bootstrap-cabin-three-segment-public-clinical-20261016-evidence.tar.gz`，旧 a7 310800 停滞负例只归其已封来源，本运行不拼接其成绩。

## 本轮最终归属

固定9ffc于207000完整600边界按parent授权正常观察停止（exit0，08:22:23.019Z），winnernull，非自然败。原202800至207000为4200步、3031公令、21命中、329事件、280次P0规划；source1559/frozen184前后完全同。未达原观测门槛，最终2cargo均inside。两份完整204645/204660纯查询均逐项重现真实全部P0公令及下一实际mission记忆，确认最小贪心名单排出合法已有actor导致6真inside被清。具体见actual-roster-invalidation-proof.json，不将相关治疗变化单独认作已证唯一上游。未运行独立全窗cold重放；后续v2另控制树/另包。
