import json,gzip,pathlib,collections
D=pathlib.Path(__file__).resolve().parent;O=D/'native-normal-202800'
def records(name):
 try:
  with gzip.open(O/(name+'.jsonl.gz'),'rt') as f:
   for l in f:yield json.loads(l)
 except EOFError:pass
j=json.loads((O/'progress.json').read_text());r=j['latest'];m=r.get('mission')or{};p=(m.get('cabinLoad')or{}).get('packing')or{}
transition=[];last=None
for x in records('states'):
 key=(len(x['cargo']),sum(bool(u.get('cabin'))for u in x['cargo']),(x.get('mission')or{}).get('phase'),((x.get('mission')or{}).get('cabinLoad')or{}).get('stage'),(((x.get('mission')or{}).get('cabinLoad')or{}).get('packing')or{}).get('phase'))
 if key!=last:transition.append({'tick':x['tick'],'stage':x['stage'],'cargo':key[0],'inside':key[1],'phase':key[2],'cabinStage':key[3],'packingPhase':key[4],'power':x['actualCargoPower']});last=key
permanent=[];targetHits=collections.Counter();enemyHits=0
for e in records('events'):
 if e.get('type')=='native-unit-terminal' and e.get('permanent'):permanent.append(e)
for h in records('hits'):
 targetHits[h['target']]+=1
 if h.get('attackerOwner')=='p0' and h.get('targetOwner') in ('p1','p2'):enemyHits+=1
out={'observedAtTick':j['tick'],'countsAtProgress':j['counts'],'actualCargo':len(r['cargo']),'actualInside':sum(bool(u.get('cabin'))for u in r['cargo']),'actualCargoPower':r['actualCargoPower'],'originalObservedRequirement':r['originalRequired'],'missionPhase':m.get('phase'),'packingPhase':p.get('phase'),'progressTick':m.get('progress',{}).get('tick'),'hullPose':{k:r['hull'].get(k)for k in ('x','y','hp','order')},'physicalTransitions':transition,'permanentTerminalsRead':permanent,'hitTargetCountsRead':dict(targetHits),'actualP0EnemyHitsRead':enemyHits,'scope':'Live bounded extraction; progress atomic sample may be earlier than raw read; not a final outcome or source attribution.'}
(D/'live-physical-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ('physicalTransitions','permanentTerminalsRead')},indent=2))
