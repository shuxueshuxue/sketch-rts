import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{gzipSync}from'node:zlib';import{createHash}from'node:crypto';
import{bootstrapGame}from'/workspace/sketch-rts-summoner-unseen-183b-control/src/ai/bootstrap_1/benchmark.ts';
import{createAiMemoryProvider}from'/workspace/sketch-rts-summoner-unseen-183b-control/src/ai/planner-context.ts';
import{createBootstrapCommandPlanner}from'/workspace/sketch-rts-summoner-unseen-183b-control/scripts/bootstrap_1-planner.ts';
import{runAiGameLoop}from'/workspace/sketch-rts-summoner-unseen-183b-control/src/ai/game-runner.ts';
import{restoreSnapshotIntoGame,snapshotGame}from'/workspace/sketch-rts-summoner-unseen-183b-control/src/shared/sim.ts';
const canonical=(v:any):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',prefix=root+'/summoner-unseen-183b-ordinary',out='/tmp/bootstrap-summoner-settle-183b-diagnose';mkdirSync(out,{recursive:true});
const report=JSON.parse(readFileSync(prefix+'.json','utf8')),opening=JSON.parse(readFileSync(prefix+'-opening.json','utf8')),source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')),raw=readFileSync(prefix+'.json.frames/14400.json'),frame=JSON.parse(raw.toString()),row=report.rows.find((r:any)=>r.tick===14400);if(!row)throw Error('missing14400');
const savedMem=Object.fromEntries(Object.entries(row.players).map(([owner,p]:[string,any])=>[owner,p.policy])),provider=createAiMemoryProvider();for(const[owner,m]of Object.entries(savedMem))provider.set!(owner,m as any);
const match={...opening.match,maxTicks:15600},game=bootstrapGame(match);restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
function memories(){return Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,structuredClone(provider.get(owner))]));}
function full(){return{snapshot:snapshotGame(game),nextId:game.nextId,memories:memories()};}
const restored={world:canonical(snapshotGame(game))===canonical(frame.snapshot),nextId:game.nextId===frame.nextId,memory:canonical(memories())===canonical(savedMem)};if(Object.values(restored).some(x=>!x))throw Error('restore failed '+JSON.stringify(restored));
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');function checkSource(){return Object.entries({...source.runtimeHashes,...source.supportingDataHashes}).filter(([p,h])=>sha(readFileSync(source.sourceRoot+'/'+p))!==h).map(([p])=>p);}
if(checkSource().length)throw Error('source changed beforediagnose');
const planner=await createBootstrapCommandPlanner(provider),events:any[]=[],commands:any[]=[],boatId='unit-p0-transport-1624';
function keep(name:string,value:any){writeFileSync(out+'/'+name+'.json.gz',gzipSync(JSON.stringify(value)));}
keep('initial-14400',full());
const commandPlanner=(context:any)=>{const before=memories(),entries=planner(context),after=memories(),a=before.p0?.naval?.ferries?.[boatId],b=after.p0?.naval?.ferries?.[boatId];
if(context.owner==='p0'&&canonical(a&&[a.purpose,a.phase,a.targetId])!==canonical(b&&[b.purpose,b.phase,b.targetId])){const event={tick:game.tick,owner:context.owner,before:a,after:b,entries};events.push(structuredClone(event));keep('transition-'+game.tick,{snapshot:context.snapshot,nextId:game.nextId,memories:before,afterMemories:after,entries});console.log(JSON.stringify({tick:game.tick,before:a,after:b}));}
for(const entry of entries){const c=entry.command;if(context.owner==='p0'&&('unitIds'in c&&c.unitIds.includes(boatId)||c.type==='build'))commands.push({tick:game.tick,owner:context.owner,...structuredClone(entry)});}
return entries;};
runAiGameLoop({...match,game,commandPlanner},{onStep(){if(game.tick%60===0)keep('sample-'+game.tick,full());}});
const original=JSON.parse(readFileSync(prefix+'.json','utf8')),expectedRow=original.rows.find((r:any)=>r.tick===15600),expected=JSON.parse(readFileSync(prefix+'.json.frames/15600.json','utf8')),expectedMemory=Object.fromEntries(Object.entries(expectedRow.players).map(([owner,p]:[string,any])=>[owner,p.policy]));
const final=full(),equal={world:canonical(final.snapshot)===canonical(expected.snapshot),nextId:final.nextId===expected.nextId,memories:canonical(final.memories)===canonical(expectedMemory)};
keep('terminal-15600',final);writeFileSync(out+'/summary.json',JSON.stringify({classification:'Same183b source diagnostic continuation of its ordinary14400 complete sample. Both ordinaryAIs, no manual commands. Not an independent ordinary0 result.',inputSha256:sha(raw),source:source.baseCommit,sourceChanged:checkSource(),restore:restored,equalsOriginal15600:equal,events,commands,final:{tick:game.tick,winner:game.match.winner}})+'\n');
console.log(JSON.stringify({done:true,equal,sourceChanged:checkSource()}));
