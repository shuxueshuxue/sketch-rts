from pathlib import Path
import subprocess, json, hashlib, tarfile, io, gzip, datetime

W=Path('/workspace/sketch-rts-solid-memo-bounded-control')
D=Path('/workspace/.playtest/bootstrap-solid-memo-bounded-20261016')
HEAD='600d67cb049f11f7a94f22735d8a2d50757ef4b2'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain','--untracked-files=all').strip()
manifest_name='docs/engineering/bootstrap_1/frozen-policy.json'
manifest_data=(W/manifest_name).read_bytes();manifest=json.loads(manifest_data)
assert manifest['rulesVersion']==2
assert manifest['revision']=='d1ae110f2edd99f9c7d899ed61557891ab587639'
assert sha(manifest_data)=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
names=git('ls-files','-z','src','scripts','tools','package.json','package-lock.json','tsconfig.json','vite.config.ts',manifest_name).decode().strip('\0').split('\0')
live={name:(W/name).read_bytes() for name in names}
for name,data in live.items():assert data==git('show',HEAD+':'+name),name
frozen_tar=git('archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared')
with tarfile.open(fileobj=io.BytesIO(frozen_tar),mode='r:')as t:
 frozen={m.name:t.extractfile(m).read()for m in t if m.isfile()}
for name,h in manifest['files'].items():assert sha(frozen[name])==h,name
archive=D/'source.tar.gz';index={}
with tarfile.open(archive,'w:gz')as t:
 for prefix,files in [('live',live),('frozen',frozen)]:
  for name,data in sorted(files.items()):
   entry=tarfile.TarInfo(prefix+'/'+name);entry.size=len(data);entry.mtime=0;entry.mode=0o644;t.addfile(entry,io.BytesIO(data));index[entry.name]=sha(data)
 b=(json.dumps({'algorithm':'SHA256','files':index},indent=2)+'\n').encode();entry=tarfile.TarInfo('INDEX.json');entry.size=len(b);t.addfile(entry,io.BytesIO(b))
with tarfile.open(archive)as t:
 for name,h in index.items():assert sha(t.extractfile(name).read())==h,name
(D/'frozen-source.tar.gz').write_bytes(gzip.compress(frozen_tar))
cap={'classification':'Independent clean native pure exact solid-traffic memo FIFO128 fix on production19ef. No deck AI candidate. Rules/frozen unchanged. Not a match or win source. Independent sparse-before-checkout tree. Includes all tracked src/scripts/tools, package/lock/config and frozen manifest; frozen execution tree independently archived and184 hashes verified.',
 'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(W),'head':HEAD,'status':'','rulesVersion':2,
 'files':{n:sha(b)for n,b in live.items()},'fileCount':len(live),'frozenRevision':manifest['revision'],'frozenManifestSHA256':sha(manifest_data),'frozenFiles':manifest['files'],'frozenFileCount':len(manifest['files']),
 'sourceArchive':str(archive),'sourceArchiveSHA256':sha(archive.read_bytes()),'sourceArchiveBytes':archive.stat().st_size,'sourceArchivePayloadsVerified':len(index),
 'frozenArchive':str(D/'frozen-source.tar.gz'),'frozenArchiveSHA256':sha((D/'frozen-source.tar.gz').read_bytes()),
 'selection':{'mapId':'sapphireArchipelago','seed':'bootstrap_1-knight-v5-official-sapphire-20261015-01','subject':'v9_knight','race':'grove','side':0,'opponents':['v5'],'unseen':False,'thinkInterval':15},
 'scope':'Production19ef6d0d plus only native exact solid-traffic memo bound and meaningful tests. Actual fixture source40350 d251 and expected uncached40351 retain changed-code provenance. No AI edits. No new0, unapproved rule/opponent modification or other AI candidate. All original and prior continuation evidence remains immutable.'}
(D/'source.json').write_text(json.dumps(cap,indent=2)+'\n')
print(json.dumps({k:v for k,v in cap.items()if k not in ['files','frozenFiles']},indent=2))
