Draft independent control: `/workspace/sketch-rts-landed-instant-v5-control`, based exactly on fixed1b. No live1b/fd/root edits, no candidate Game started yet.

The exact original218040 full-planner closure proves fourteen ready raw summon requests rejected only when the later abilities script meets prior naval physical actor reservations. Within one naval array the runner does not reserve per command, so an instantaneous spell and movement may coexist. The proposed patch keeps that owner and the original native effects.

`planLandedCombat` gathers its existing eligible army from actual active island fights (unavailable, cargo/board, queue, cast/charge/care tasks still excluded). It then takes only these actors from the original whole-owner `planBootstrapAbilities` allocation. This keeps target allocation with the original single `cursed` set, including earlier nonlanded casters; it publishes none of those other actors. The initially considered independent caster-list selector was removed because it could allocate targetA twice across two script batches. Shared spell-tactics and default weapon-targets have zero source delta.

Only currently legal, unqueued native instantaneous heal/curse/summon is prepended. Cooldown/stun/target existence/native target class/range remain native gates. Weapon, charge and out-of-range approach keep the original path. Local summon publication proves an actual walkable ground point outside any native-selected friendly deck, rather than promising an unverified deck spawn.

This is a prefix of the existing *local* actions, after the existing assault landing batch / ordinary naval prefix. Do not move ground summons ahead of the landing batch: their new bodies could invalidate the batch's immutable landing projection. For37753, its unchanged raw naval attackMove therefore precedes its instant summon in the same script array; native instant casting preserves that existing order and still executes immediately. The other local screening moves follow the spell prefix.

The sole duplicate map is after the original runner returns accepted entries, at the same integration location as cf147743's new heal deduplication. It records only accepted naval instantaneous casts, and removes a later same actor+ability instantaneous request in this think. It does not add a runner exception, persistent memory or alternate raw-script ownership layer.

Future cf147743 hunk integration:

- Keep its `medicalRecoveryCastingUnitIds(snapshot, owner, options)` inside the original `planBootstrapAbilities` implementation. This draft does not edit that file, so root's medical API change is reused directly when merged.
- Merge the postaccepted cast filter with cf147's existing heal map as a single pass: preserve cf147's already accepted heal dedup across medical/naval and extend only the newly coordinated landed native instant spell keys. Do not stack two wrappers or restore older medical files.
- Keep cf147's actual medical tasks/occupied/released-medics logic, current healing-before-local *selection*, and its continuing patient jobs. Pass only its genuinely released/eligible landed actors to the new scoped ability call. Its healing publication order may then coexist with the original local physical order because instant spells do not replace that order.
- Keep this branch's ground-anchor opt-in and its native `shipHullAtPoint` behavior. No full-file overwrite of root/medical/af naval work.

Required validation before fixed-source native comparison: nine new contracts cover the actual14 requests, native effects/order preservation, unchanged global targeting/actor scope, unavailable and queued jobs, readiness/range/native legality, ground versus deck spawn, existing medical priority, accepted same-think dedup, and the cross-batch two-caster/two-enemy curse allocation. Then shared spell/default landed/cabin ownership/medical neighbors and one1024tsc. These results are pending, not green by design.

The candidate's first normal comparison must use the original217800 complete input, all3 normal AI, no manual spell injection. The old ground v4 case is a negative (all27 died) and is not evidence that earlier spells win. Current-source complete outcome and subsequent fresh0/generalization remain separate work.
