from pathlib import Path
from collections import Counter
import gzip,json,hashlib
D=Path(__file__).resolve().parent;cap=json.loads((D/'fixed-runtime.json').read_text());O=Path(cap['nativeOutputRoot']);ids=set(cap['observedCrewIds'])
initial=json.loads(gzip.decompress(Path(cap['inputPath']).read_bytes()));original={u['id']:u for u in initial['snapshot']['units'] if u['id'] in ids}
def rows(name):
 with gzip.open(O/f'{name}.jsonl.gz','rt') as f:
  for line in f:
   r=json.loads(line)
   if r['tick']>=219000:break
   yield r
commands=list(rows('commands'));events=list(rows('events'))
dead={e['id']:e for e in events if e['type']=='native-unit-terminal'and e['id']in ids}
effects={}
for tick in range(217800,219000,15):
 p=O/'frames'/f'{tick}-before-p0.json.gz'
 if not p.exists():continue
 f=json.loads(gzip.decompress(p.read_bytes()))
 for e in f['snapshot']['effects']:
  if e.get('sourceId')in ids and e.get('actionMode')=='cast':effects[e['id']]=e
def involves(command,id):
 return id in command.get('unitIds',[]) or id in [command.get(k)for k in ['unitId','passengerId']]
table=[]
for id in cap['observedCrewIds']:
 u=original[id];death=dead[id];last=death.get('atObservation')or death['previous'];own=[r for r in commands if r['owner']=='p0'and involves(r['command'],id)]
 care=[r for r in own if r['scriptId']=='medicalRecovery' or r['command']['type']=='follow' or r['command']['type']=='move'and r['command'].get('avoidCombat') or r['command']['type']=='cast'and r['command']['ability']=='heal']
 table.append({'id':id,'kind':u['kind'],'initial':{k:u[k]for k in ['hp','maxHp','level','xp','kills']},'death':{'tick':death['tick'],'observedAs':death['observedAs'],'level':last['level'],'xp':last['xp'],'kills':last['kills'],'order':last['order'],'lastNativeHit':death.get('lastNativeHit')},'acceptedScriptIds':dict(Counter(r['scriptId']for r in own)),'actualCareOrAvoidCombatCommands':care,'nativeCastEffectsSeen':[e for e in effects.values()if e.get('sourceId')==id]})
report={'classification':'Actual first1200 fixedf4 normal3AI cohort and medical-command ledger; no new planner/query/replay','head':cap['head'],'scope':{'start':217800,'endExclusive':219000,'commands':'Original accepted raw public entries. Naval does not tag internal subplans: avoidCombat/follow are evidence of an actual retreat command, not alone proof of which subplanner produced it.','effects':'Deduplicated actual native cast effects in full before-P0 samples every15 ticks. Heal effect lasts36ticks in fixedsource, so these records cover first1200 successful heal effects; effect has source and target position, not targetId. Do not invent healed recipient ID.'},'kindCounts':dict(Counter(u['kind']for u in original.values())),'initialLevelCounts':dict(Counter(u['level']for u in original.values())),'all27PermanentTerminals':len(dead),'table':table,'nativeHealEffects':[e for e in effects.values()if e['type']=='heal'],'nativeCurseEffects':[e for e in effects.values()if e['type']=='scorch'],'remaining':'Static medical assignment and road queries are separate, not native survival counterfactual. Three original veterans all died; no rescue claim.'}
p=D/'cohort27-medical-native-ledger.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kinds':report['kindCounts'],'levels':report['initialLevelCounts'],'nativeHealEffects':report['nativeHealEffects'],'nativeCurseCount':len(report['nativeCurseEffects']),'careActors':[{ 'id':u['id'],'kind':u['kind'],'death':u['death']['tick'],'careCommands':len(u['actualCareOrAvoidCombatCommands'])}for u in table if u['actualCareOrAvoidCombatCommands']]},indent=2))
