from pathlib import Path
import json,datetime,time,subprocess,sys,os,hashlib
D=Path(__file__).resolve().parent;plan=json.loads((D/'planned-validation.json').read_text());S=Path(plan['sourceRoot']);stage=sys.argv[1]
assert stage in ['new','related','tsc']
receipt=D/f'validation-{stage}-receipt.json';assert not receipt.exists(),'Keep prior attempts and use a distinct receipt path after a justified change'
c=Path('/sys/fs/cgroup');limit=int((c/'memory.max').read_text());current=int((c/'memory.current').read_text())
r={'classification':'Independent landed instant owner coordination validation, not match acceptance','stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':limit,'current':current,'headroom':limit-current,'required':2<<30,'oomBefore':(c/'memory.events').read_text()}
if r['headroom']<r['required']:
 r['exit']=75;(D/f'prepared-only-{stage}-{time.time_ns()}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
files=[plan['newContractFile']] if stage=='new' else plan['relatedFiles'];heap=1024 if stage=='tsc' else 768
argv=['node',f'--max-old-space-size={heap}',str(S/'node_modules/typescript/bin/tsc'),'--noEmit'] if stage=='tsc' else ['node','--max-old-space-size=768',str(S/'node_modules/vitest/vitest.mjs'),'run','--pool=forks','--maxWorkers=1','--minWorkers=1',*files]
env={**os.environ};env['NODE_OPTIONS']=f'--max-old-space-size={heap}'
r.update(argv=argv,heapMiB=heap,headBefore=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),statusBefore=subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True));start=time.monotonic()
with (D/f'validation-{stage}.log').open('w') as log:
 q=subprocess.Popen(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT);r['pid']=q.pid;r['exit']=q.wait()
r.update(wallSeconds=time.monotonic()-start,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),oomAfter=(c/'memory.events').read_text(),statusAfter=subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True));receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print((D/f'validation-{stage}.log').read_text()[-12000:]);raise SystemExit(q.returncode)
