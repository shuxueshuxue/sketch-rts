import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {localToWorld} from '/workspace/sketch-rts-landed-instant-v5-control/src/shared/ship-geometry.ts';
import {deckPointFits} from '/workspace/sketch-rts-landed-instant-v5-control/src/shared/decks.ts';
import {isWalkable,setBuildingBodies} from '/workspace/sketch-rts-landed-instant-v5-control/src/shared/terrain.ts';
import {bootstrapPolicyContext,planBootstrapScriptEntries} from '/workspace/sketch-rts-landed-instant-v5-control/src/ai/bootstrap_1/policy.ts';
import {planLandedAbilityCasts} from '/workspace/sketch-rts-landed-instant-v5-control/src/ai/bootstrap_1/landed-abilities.ts';
import {planBootstrapAbilities} from '/workspace/sketch-rts-landed-instant-v5-control/src/ai/bootstrap_1/weapon-targets.ts';
const D='/workspace/.playtest/landed-instant-spells-v5-20261016',S='/workspace/sketch-rts-landed-instant-v5-control';
const path='/workspace/.playtest/landed-native-ground-v4-20261016/native-normal-from217800/frames/218040-before-p0.json.gz';
const sha=(x:any)=>createHash('sha256').update(x).digest('hex'),raw=readFileSync(path),original=JSON.parse(gunzipSync(raw).toString()),before=JSON.stringify(original),f=structuredClone(original),s=f.snapshot;
setBuildingBodies(s.map,[...s.buildings,...s.obstacles??[]]);
const first=s.units.find((u:any)=>u.id==='unit-p0-ashHexer-4268'),local=s.units.find((u:any)=>u.id==='unit-p0-ashHexer-4420'),ship=s.units.find((u:any)=>u.id==='unit-p0-carrier-25442');
first.deck={shipId:ship.id,x:0,y:40};Object.assign(first,localToWorld(ship,first.deck));
const a=s.units.find((u:any)=>u.id==='unit-p1-archer-9414'),b=s.units.find((u:any)=>u.id==='unit-p1-archer-7581');
a.x=local.x+32;a.y=local.y-36;b.x=local.x-58;b.y=local.y-36;
s.units=s.units.filter((u:any)=>u.owner!=='p1'||u===a||u===b);
f.memories.p0.naval.ferries={};
const options=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:f.memories.p0,teams:s.teams});
const spellPath=S+'/src/ai/policy/spell-tactics.ts',source=readFileSync(spellPath,'utf8');
const anchor='for (const caster of units(snapshot, owner).filter(canCast)) {';
if(source.split(anchor).length!==2)throw Error('Private-set instrument anchor changed');
const instrument=source.replace(anchor,'for (const caster of ((globalThis as any).__privateCasterSubset ?? units(snapshot, owner)).filter(canCast)) {');
const bundle=D+'/private-cursed-set-counterexample.mjs';
await build({stdin:{contents:`export {planAbilityCommands} from '${spellPath}';`,loader:'ts',resolveDir:S},bundle:true,platform:'node',format:'esm',outfile:bundle,plugins:[{name:'observe-private-caster-set-counterexample',setup(builder){builder.onLoad({filter:/\/src\/ai\/policy\/spell-tactics\.ts$/},args=>{if(args.path!==spellPath)throw Error('Wrong source');return {contents:instrument,loader:'ts',resolveDir:S+'/src/ai/policy'};});}}]});
const old=await import(pathToFileURL(bundle).href);
(globalThis as any).__privateCasterSubset=[local];
const previousScoped=old.planAbilityCommands(s,'p0',options).filter((c:any)=>c.type==='cast'&&c.unitId===local.id&&c.ability==='ashCurse');
delete (globalThis as any).__privateCasterSubset;
const whole=planBootstrapAbilities(s,'p0',options).filter(c=>c.type==='cast'&&[first.id,local.id].includes(c.unitId));
const selected=planLandedAbilityCasts(s,'p0',options,[local]);
const scripts:any[]=[{id:'naval',phase:'tactics',run:()=>selected},{id:'abilities',phase:'tactics',run:planBootstrapAbilities}];
const final=planBootstrapScriptEntries(s,'p0',scripts,options).filter(e=>e.command.type==='cast'&&[first.id,local.id].includes(e.command.unitId));
const expected=[{type:'cast',unitId:first.id,ability:'ashCurse',targetId:a.id},{type:'cast',unitId:local.id,ability:'ashCurse',targetId:b.id}];
const result={classification:'Explicit typed component from a cloned actual world, not an observed historical battle, fresh0, Game, step, fullP0 or issued command. Normal17damage archers retain original combat stats; only two target positions, one native-supported open-deck attachment, otherP1 removal and empty ferry memory define this target-allocation counterexample.',inputPath:path,inputSHA256:sha(raw),originalWorldIdMemUnchanged:JSON.stringify(original)===before,
 nativeChecks:{openDeckFits:deckPointFits(ship,first,first.deck,s.units),bothTargetsWalkable:isWalkable(s.map,a.x,a.y)&&isWalkable(s.map,b.x,b.y)},
 actors:{first:{id:first.id,x:first.x,y:first.y,deck:first.deck},local:{id:local.id,x:local.x,y:local.y}},targets:[a,b].map(u=>({id:u.id,kind:u.kind,x:u.x,y:u.y,attackDamage:u.attackDamage})),
 oldPrivateScoped:previousScoped,originalWholeAllocation:whole,currentEligibleSubset:selected,finalAcceptedEntries:final,
 equality:{oldPrivatePickedA:previousScoped[0]?.targetId===a.id,wholeAllocationExpected:JSON.stringify(whole)===JSON.stringify(expected),currentLocalPickedB:selected.some(c=>c.type==='cast'&&c.unitId===local.id&&c.targetId===b.id),acceptedOneAOneB:JSON.stringify(final.map(e=>e.command))===JSON.stringify([expected[1],expected[0]])},
 source:{sharedSHA256:sha(source),instrumentedCounterexampleSHA256:sha(instrument),sharedFileUnchanged:readFileSync(spellPath,'utf8')===source},rss:process.memoryUsage().rss};
writeFileSync(D+'/cross-batch-curse-component.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({nativeChecks:result.nativeChecks,equality:result.equality,rss:result.rss}));
if(!result.originalWorldIdMemUnchanged||Object.values(result.nativeChecks).some(v=>!v)||Object.values(result.equality).some(v=>!v))throw Error('Component did not close');
