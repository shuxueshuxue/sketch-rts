from pathlib import Path
import subprocess,json,os,datetime,time
D=Path(__file__).resolve().parent
S=Path('/workspace/sketch-rts-landed-instant-v5-control')
O=Path('/tmp/landed-instant-spells-v5-normal-217800-20261016')
receipt=D/'actual-three-native-render-receipt.json'
assert not receipt.exists()
rows=[]
for tick,cx,cy,zoom in [(218055,9050,6000,.95),(218175,9110,6090,1.3),(218400,9110,6090,1.3)]:
 c=Path('/sys/fs/cgroup');limit=int((c/'memory.max').read_text());current=int((c/'memory.current').read_text())
 r={'tick':tick,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':limit,'current':current,'headroom':limit-current,'required':1<<30,'heapMiB':512,'oomBefore':(c/'memory.events').read_text()}
 if limit-current<1<<30:
  r['exit']=75;rows.append(r);receipt.write_text(json.dumps({'classification':'Static native drawWorld only; no Game, planner, step or commands','rows':rows},indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
 argv=['node','--max-old-space-size=512','--import','tsx',str(D/'render-actual-v5-state.ts'),str(O/'frames'/f'{tick}-before-p0.json.gz'),str(D/f'actual-v5-native-battle-{tick}.png'),str(cx),str(cy),str(zoom)]
 start=time.monotonic()
 with (D/f'actual-native-render-{tick}.log').open('w') as log:
  p=subprocess.Popen(argv,cwd=S,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=512'},stdout=log,stderr=subprocess.STDOUT);r['pid']=p.pid;r['exit']=p.wait()
 r.update(endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wallSeconds=time.monotonic()-start,oomAfter=(c/'memory.events').read_text());rows.append(r)
 receipt.write_text(json.dumps({'classification':'Static native drawWorld only; no Game, planner, step or commands','rows':rows},indent=2)+'\n');print(json.dumps(r),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
