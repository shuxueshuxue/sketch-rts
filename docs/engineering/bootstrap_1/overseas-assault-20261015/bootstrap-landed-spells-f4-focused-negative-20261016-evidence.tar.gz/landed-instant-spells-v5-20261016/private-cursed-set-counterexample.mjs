// src/shared/generated/ship-geometry.json
var ship_geometry_default = {
  sourceSha256: "22acecf80139ea9f084dbc3411a61d94128d400092ef1428e3a45ee86f5ea01e",
  camera: {
    tilt: 0.72,
    frameSize: 384,
    worldSize: 360,
    directions: 32,
    anchorY: 24
  },
  ships: {
    cutter: {
      length: 116,
      beam: 46,
      deckHeight: 18,
      hullMass: 7e3,
      loadCapacity: 450,
      acceleration: 72,
      turnRate: 0.628318531,
      obstacles: [
        {
          x: -35,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -39,
          y: 0,
          radius: 14,
          type: "cabin"
        }
      ],
      weaponMount: [
        31,
        0,
        11
      ],
      mastHeight: 78,
      weaponPivot: null,
      hull: [
        [
          -58,
          -12.88
        ],
        [
          -51.04,
          -18.86
        ],
        [
          -31.900000000000002,
          -23
        ],
        [
          0,
          -23
        ],
        [
          23.200000000000003,
          -20.7
        ],
        [
          42.339999999999996,
          -12.88
        ],
        [
          58,
          0
        ],
        [
          42.339999999999996,
          12.88
        ],
        [
          23.200000000000003,
          20.7
        ],
        [
          0,
          23
        ],
        [
          -31.900000000000002,
          23
        ],
        [
          -51.04,
          18.86
        ],
        [
          -58,
          12.88
        ]
      ],
      deck: [
        [
          -53,
          -10.080000000000002
        ],
        [
          -46.64,
          -14.76
        ],
        [
          -29.150000000000002,
          -18
        ],
        [
          0,
          -18
        ],
        [
          21.200000000000003,
          -16.2
        ],
        [
          38.69,
          -10.080000000000002
        ],
        [
          53,
          0
        ],
        [
          38.69,
          10.080000000000002
        ],
        [
          21.200000000000003,
          16.2
        ],
        [
          0,
          18
        ],
        [
          -29.150000000000002,
          18
        ],
        [
          -46.64,
          14.76
        ],
        [
          -53,
          10.080000000000002
        ]
      ]
    },
    transport: {
      length: 184,
      beam: 80,
      deckHeight: 26,
      hullMass: 14e3,
      loadCapacity: 1800,
      acceleration: 48,
      turnRate: 0.383972435,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 64,
      weaponPivot: null,
      hull: [
        [
          -92,
          -22.400000000000002
        ],
        [
          -80.96,
          -32.8
        ],
        [
          -50.6,
          -40
        ],
        [
          0,
          -40
        ],
        [
          36.800000000000004,
          -36
        ],
        [
          67.16,
          -22.400000000000002
        ],
        [
          92,
          0
        ],
        [
          67.16,
          22.400000000000002
        ],
        [
          36.800000000000004,
          36
        ],
        [
          0,
          40
        ],
        [
          -50.6,
          40
        ],
        [
          -80.96,
          32.8
        ],
        [
          -92,
          22.400000000000002
        ]
      ],
      deck: [
        [
          -87,
          -19.6
        ],
        [
          -76.56,
          -28.7
        ],
        [
          -47.85,
          -35
        ],
        [
          0,
          -35
        ],
        [
          34.800000000000004,
          -31.5
        ],
        [
          63.51,
          -19.6
        ],
        [
          87,
          0
        ],
        [
          63.51,
          19.6
        ],
        [
          34.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -47.85,
          35
        ],
        [
          -76.56,
          28.7
        ],
        [
          -87,
          19.6
        ]
      ]
    },
    warship: {
      length: 170,
      beam: 72,
      deckHeight: 28,
      hullMass: 23e3,
      loadCapacity: 850,
      acceleration: 44,
      turnRate: 0.314159265,
      obstacles: [
        {
          x: -45,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 34,
          y: 0,
          radius: 16,
          type: "gun"
        },
        {
          x: -58,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        60,
        0,
        35
      ],
      mastHeight: 102,
      weaponPivot: [
        34,
        0,
        28
      ],
      hull: [
        [
          -85,
          -20.160000000000004
        ],
        [
          -74.8,
          -29.52
        ],
        [
          -46.75000000000001,
          -36
        ],
        [
          0,
          -36
        ],
        [
          34,
          -32.4
        ],
        [
          62.05,
          -20.160000000000004
        ],
        [
          85,
          0
        ],
        [
          62.05,
          20.160000000000004
        ],
        [
          34,
          32.4
        ],
        [
          0,
          36
        ],
        [
          -46.75000000000001,
          36
        ],
        [
          -74.8,
          29.52
        ],
        [
          -85,
          20.160000000000004
        ]
      ],
      deck: [
        [
          -80,
          -17.360000000000003
        ],
        [
          -70.4,
          -25.419999999999998
        ],
        [
          -44,
          -31
        ],
        [
          0,
          -31
        ],
        [
          32,
          -27.900000000000002
        ],
        [
          58.4,
          -17.360000000000003
        ],
        [
          80,
          0
        ],
        [
          58.4,
          17.360000000000003
        ],
        [
          32,
          27.900000000000002
        ],
        [
          0,
          31
        ],
        [
          -44,
          31
        ],
        [
          -70.4,
          25.419999999999998
        ],
        [
          -80,
          17.360000000000003
        ]
      ]
    },
    bombardShip: {
      length: 184,
      beam: 70,
      deckHeight: 30,
      hullMass: 31e3,
      loadCapacity: 1300,
      acceleration: 30,
      turnRate: 0.226892803,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 30,
          y: 0,
          radius: 23,
          type: "mortar"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        38,
        0,
        54
      ],
      mastHeight: 58,
      weaponPivot: [
        30,
        0,
        30
      ],
      hull: [
        [
          -92,
          -19.6
        ],
        [
          -80.96,
          -28.7
        ],
        [
          -50.6,
          -35
        ],
        [
          0,
          -35
        ],
        [
          36.800000000000004,
          -31.5
        ],
        [
          67.16,
          -19.6
        ],
        [
          92,
          0
        ],
        [
          67.16,
          19.6
        ],
        [
          36.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -50.6,
          35
        ],
        [
          -80.96,
          28.7
        ],
        [
          -92,
          19.6
        ]
      ],
      deck: [
        [
          -87,
          -16.8
        ],
        [
          -76.56,
          -24.599999999999998
        ],
        [
          -47.85,
          -30
        ],
        [
          0,
          -30
        ],
        [
          34.800000000000004,
          -27
        ],
        [
          63.51,
          -16.8
        ],
        [
          87,
          0
        ],
        [
          63.51,
          16.8
        ],
        [
          34.800000000000004,
          27
        ],
        [
          0,
          30
        ],
        [
          -47.85,
          30
        ],
        [
          -76.56,
          24.599999999999998
        ],
        [
          -87,
          16.8
        ]
      ]
    },
    fireShip: {
      length: 158,
      beam: 60,
      deckHeight: 26,
      hullMass: 19e3,
      loadCapacity: 700,
      acceleration: 56,
      turnRate: 0.453785606,
      obstacles: [
        {
          x: -41,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 25,
          y: 0,
          radius: 18,
          type: "flame"
        },
        {
          x: -54,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        67,
        0,
        32
      ],
      mastHeight: 44,
      weaponPivot: [
        25,
        0,
        26
      ],
      hull: [
        [
          -79,
          -16.8
        ],
        [
          -69.52,
          -24.599999999999998
        ],
        [
          -43.45,
          -30
        ],
        [
          0,
          -30
        ],
        [
          31.6,
          -27
        ],
        [
          57.67,
          -16.8
        ],
        [
          79,
          0
        ],
        [
          57.67,
          16.8
        ],
        [
          31.6,
          27
        ],
        [
          0,
          30
        ],
        [
          -43.45,
          30
        ],
        [
          -69.52,
          24.599999999999998
        ],
        [
          -79,
          16.8
        ]
      ],
      deck: [
        [
          -74,
          -14.000000000000002
        ],
        [
          -65.12,
          -20.5
        ],
        [
          -40.7,
          -25
        ],
        [
          0,
          -25
        ],
        [
          29.6,
          -22.5
        ],
        [
          54.019999999999996,
          -14.000000000000002
        ],
        [
          74,
          0
        ],
        [
          54.019999999999996,
          14.000000000000002
        ],
        [
          29.6,
          22.5
        ],
        [
          0,
          25
        ],
        [
          -40.7,
          25
        ],
        [
          -65.12,
          20.5
        ],
        [
          -74,
          14.000000000000002
        ]
      ]
    },
    carrier: {
      length: 224,
      beam: 106,
      deckHeight: 32,
      hullMass: 55e3,
      loadCapacity: 5200,
      acceleration: 32,
      turnRate: 0.20943951,
      obstacles: [
        {
          x: -60,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: 26,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: -76,
          y: 0,
          radius: 26,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 128,
      weaponPivot: null,
      hull: [
        [
          -112,
          -29.680000000000003
        ],
        [
          -98.56,
          -43.46
        ],
        [
          -61.60000000000001,
          -53
        ],
        [
          0,
          -53
        ],
        [
          44.800000000000004,
          -47.7
        ],
        [
          81.75999999999999,
          -29.680000000000003
        ],
        [
          112,
          0
        ],
        [
          81.75999999999999,
          29.680000000000003
        ],
        [
          44.800000000000004,
          47.7
        ],
        [
          0,
          53
        ],
        [
          -61.60000000000001,
          53
        ],
        [
          -98.56,
          43.46
        ],
        [
          -112,
          29.680000000000003
        ]
      ],
      deck: [
        [
          -107,
          -26.880000000000003
        ],
        [
          -94.16,
          -39.36
        ],
        [
          -58.85,
          -48
        ],
        [
          0,
          -48
        ],
        [
          42.800000000000004,
          -43.2
        ],
        [
          78.11,
          -26.880000000000003
        ],
        [
          107,
          0
        ],
        [
          78.11,
          26.880000000000003
        ],
        [
          42.800000000000004,
          43.2
        ],
        [
          0,
          48
        ],
        [
          -58.85,
          48
        ],
        [
          -94.16,
          39.36
        ],
        [
          -107,
          26.880000000000003
        ]
      ]
    },
    shipOfTheLine: {
      length: 292,
      beam: 144,
      deckHeight: 38,
      hullMass: 72e3,
      loadCapacity: 3800,
      acceleration: 24,
      turnRate: 0.148352986,
      obstacles: [
        {
          x: -53,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -10,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: 76,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -126,
          y: 0,
          radius: 20,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 150,
      mastHeights: [
        118,
        150,
        136
      ],
      mastBeamScales: [
        0.79,
        1,
        0.88
      ],
      weaponPivot: null,
      hull: [
        [
          -146,
          -40.32000000000001
        ],
        [
          -128.48,
          -59.04
        ],
        [
          -80.30000000000001,
          -72
        ],
        [
          0,
          -72
        ],
        [
          58.400000000000006,
          -64.8
        ],
        [
          106.58,
          -40.32000000000001
        ],
        [
          146,
          0
        ],
        [
          106.58,
          40.32000000000001
        ],
        [
          58.400000000000006,
          64.8
        ],
        [
          0,
          72
        ],
        [
          -80.30000000000001,
          72
        ],
        [
          -128.48,
          59.04
        ],
        [
          -146,
          40.32000000000001
        ]
      ],
      deck: [
        [
          -141,
          -37.52
        ],
        [
          -124.08,
          -54.94
        ],
        [
          -77.55000000000001,
          -67
        ],
        [
          0,
          -67
        ],
        [
          56.400000000000006,
          -60.300000000000004
        ],
        [
          102.92999999999999,
          -37.52
        ],
        [
          141,
          0
        ],
        [
          102.92999999999999,
          37.52
        ],
        [
          56.400000000000006,
          60.300000000000004
        ],
        [
          0,
          67
        ],
        [
          -77.55000000000001,
          67
        ],
        [
          -124.08,
          54.94
        ],
        [
          -141,
          37.52
        ]
      ]
    }
  }
};

// src/shared/det-math.ts
var S1 = -0.16666666666666632;
var S2 = 0.00833333333332249;
var S3 = -1984126982985795e-19;
var S4 = 27557313707070068e-22;
var S5 = -25050760253406863e-24;
var S6 = 158969099521155e-24;
var C1 = 0.0416666666666666;
var C2 = -0.001388888888887411;
var C3 = 2480158728947673e-20;
var C4 = -27557314351390663e-23;
var C5 = 2087572321298175e-24;
var C6 = -11359647557788195e-27;
var INV_PIO2 = 0.6366197723675814;
var PIO2_1 = 1.5707963267341256;
var PIO2_1T = 6077100506506192e-26;
var PIO2_2 = 6077100506303966e-26;
var PIO2_2T = 20222662487959506e-37;
var PI_4 = 0.7853981633974483;
var MAX_ARGUMENT = 823549.6;
function kernelSin(x, y, hasTail) {
  const z = x * x;
  const w = z * z;
  const r = S2 + z * (S3 + z * S4) + z * w * (S5 + z * S6);
  const v = z * x;
  if (!hasTail) return x + v * (S1 + z * r);
  return x - (z * (0.5 * y - v * r) - y - v * S1);
}
function kernelCos(x, y) {
  const z = x * x;
  const w = z * z;
  const r = z * (C1 + z * (C2 + z * C3)) + w * w * (C4 + z * (C5 + z * C6));
  const hz = 0.5 * z;
  const u = 1 - hz;
  return u + (1 - u - hz + (z * r - x * y));
}
function reduce(x) {
  if (!(Math.abs(x) <= MAX_ARGUMENT)) throw new Error(`det-math: angle ${x} outside the supported range`);
  const n = Math.round(x * INV_PIO2);
  const first = x - n * PIO2_1;
  let w = n * PIO2_1T;
  const r = first - n * PIO2_2;
  w = n * PIO2_2T - (first - r - n * PIO2_2);
  const head = r - w;
  return { n, head, tail: r - head - w };
}
function detCos(x) {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (Math.abs(x) <= PI_4) return kernelCos(x, 0);
  const { n, head, tail } = reduce(x);
  switch (n & 3) {
    case 0:
      return kernelCos(head, tail);
    case 1:
      return -kernelSin(head, tail, true);
    case 2:
      return -kernelCos(head, tail);
    default:
      return kernelSin(head, tail, true);
  }
}

// src/shared/ship-geometry.ts
var shipGeometry = ship_geometry_default.ships;
var SHIP_CAMERA = ship_geometry_default.camera;
var SHIP_KINDS = Object.keys(shipGeometry);
var SHIP_SIZE_MULTIPLIER = 1.2;
var AUTHORED_DEFAULT_SHIP_SCALE = 1.1;
var DEFAULT_SHIP_SCALE = AUTHORED_DEFAULT_SHIP_SCALE * SHIP_SIZE_MULTIPLIER;
function isShipKind(kind) {
  return kind in shipGeometry;
}
var shipLists = /* @__PURE__ */ new WeakMap();
function shipsIn(units2) {
  const cached = shipLists.get(units2);
  if (cached?.length === units2.length) return cached.ships;
  const ships = units2.filter((unit) => isShipKind(unit.kind));
  shipLists.set(units2, { length: units2.length, ships });
  return ships;
}

// src/shared/hypot.ts
function hypot2(x, y) {
  const absX = Math.abs(x), absY = Math.abs(y);
  if (absX === Infinity || absY === Infinity) return Infinity;
  const max = Math.max(absX, absY);
  if (max === 0) return 0;
  const a = absX / max, b = absY / max;
  return Math.sqrt(a * a + b * b) * max;
}

// src/shared/time.ts
var SIM_TICKS_PER_SECOND = 20;
function seconds(value) {
  return Math.max(1, Math.round(value * SIM_TICKS_PER_SECOND));
}

// src/shared/wind-field.ts
var DEFAULT_WIND = { direction: Math.PI / 4, speed: 80 };
var WIND_CHANGE_INTERVAL_TICKS = seconds(8 * 60);

// src/shared/ship-wind.ts
var SAIL_RULES = {
  trimRate: Math.PI / 3,
  setRate: 0.8,
  billowRate: 2,
  auxiliaryShare: 0.2,
  // RTS courses deliberately sail closer than historical square-riggers.
  // Each rig retains its own no-go sector without making an upwind order
  // spend almost all its travel crossing sideways across the map.
  lateen: { noGoAngle: Math.PI * 38 / 180, maxAngle: Math.PI * 65 / 180 },
  lug: { noGoAngle: Math.PI * 43 / 180, maxAngle: Math.PI * 65 / 180 },
  square: { noGoAngle: Math.PI * 48 / 180, maxAngle: Math.PI * 50 / 180 }
};
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
var POLAR_KNOTS = {
  lateen: [[SAIL_RULES.lateen.noGoAngle, 0], [SAIL_RULES.lateen.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.66]],
  lug: [[SAIL_RULES.lug.noGoAngle, 0], [SAIL_RULES.lug.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.78]],
  square: [[SAIL_RULES.square.noGoAngle, 0], [SAIL_RULES.square.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.97]]
};
function polar(rig, angle2) {
  const noGo = SAIL_RULES[rig].noGoAngle;
  if (angle2 <= noGo) return 0;
  const knots = POLAR_KNOTS[rig];
  for (let i = 1; i < knots.length; i++) {
    const [end, high] = knots[i], [start, low] = knots[i - 1];
    if (angle2 <= end) {
      const t = clamp((angle2 - start) / (end - start), 0, 1);
      return low + (high - low) * t * t * (3 - 2 * t);
    }
  }
  return knots.at(-1)[1];
}
function bestBeatAngle(rig) {
  let best = SAIL_RULES[rig].noGoAngle, bestVmg = 0;
  for (let degree = 1; degree < 90; degree++) {
    const angle2 = degree * Math.PI / 180, vmg = polar(rig, angle2) * detCos(angle2);
    if (vmg > bestVmg) {
      bestVmg = vmg;
      best = angle2;
    }
  }
  return best;
}
var BEAT_ANGLES = { lateen: bestBeatAngle("lateen"), lug: bestBeatAngle("lug"), square: bestBeatAngle("square") };

// src/shared/terrain.ts
var CELL_GROUND = {
  ".": { land: true, sea: false, pace: 1, drag: 1 },
  ",": { land: true, sea: true, pace: 0.75, drag: 1.6 },
  m: { land: true, sea: false, pace: 0.6, drag: 2 },
  "=": { land: true, sea: false, pace: 1, drag: 1 },
  T: { land: false, sea: false, pace: 0, drag: 1 },
  "#": { land: false, sea: false, pace: 0, drag: 1 },
  "~": { land: false, sea: true, pace: 0, drag: 1 }
};
var PASSABLE = {
  land: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].land)),
  sea: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].sea))
};
var GROUND_WEIGHT = 4;
var BUCKETS = 64;
function isWalkable(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
function isFootprintBuildable(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, "land");
  return everyFootprintCell(terrain, x, y, radius, (at, cell) => state.walk[at] === 1 && terrain.cells[cell] !== "," && terrain.levels?.[cell] !== "2");
}
function isShoreFootprint(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return false;
  const land = runtime(terrain, "land");
  const sea = runtime(terrain, "sea");
  const { labels, deep } = wholesOf(sea);
  let dry = false;
  let wet = false;
  const fits = everyFootprintCell(terrain, x, y, radius, (at, cell) => {
    if (land.walk[at] === 1) dry = true;
    if (sea.walk[at] === 1 && deep[labels[at]] >= OPEN_WATER) wet = true;
    return (sea.walk[at] === 1 || land.walk[at] === 1) && terrain.levels?.[cell] !== "2";
  });
  return fits && dry && wet;
}
var OPEN_WATER = 64;
function footprintHalf(radius, cell) {
  return Math.ceil(2 * radius / cell) * cell / 2;
}
function snapToFootprint(map, radius, point) {
  const terrain = map.terrain;
  if (!terrain) return { x: point.x, y: point.y };
  const cell = terrain.cell;
  const offset = Math.ceil(2 * radius / cell) % 2 === 1 ? cell / 2 : 0;
  return { x: Math.round((point.x - offset) / cell) * cell + offset, y: Math.round((point.y - offset) / cell) * cell + offset };
}
function footprintCells(cell, x, y, radius) {
  const half = footprintHalf(radius, cell);
  const first = (from) => Math.ceil(from / cell - 0.5);
  return { left: first(x - half), right: first(x + half) - 1, top: first(y - half), bottom: first(y + half) - 1 };
}
function everyFootprintCell(terrain, x, y, radius, passes) {
  const size = terrain.cell;
  const width = terrain.cols + 2;
  const { left, right, top, bottom } = footprintCells(size, x, y, radius);
  for (let row = top; row <= bottom; row += 1) {
    for (let col = left; col <= right; col += 1) {
      if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return false;
      if (!passes((row + 1) * width + col + 1, row * terrain.cols + col)) return false;
    }
  }
  return true;
}
function sameGround(map, a, b, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  const { labels } = wholesOf(state);
  const from = padAt(state, a.x, a.y);
  const to = padAt(state, b.x, b.y);
  return from >= 0 && to >= 0 && labels[from] !== 0 && labels[from] === labels[to];
}
function wholesOf(state) {
  if (state.wholes) return state.wholes;
  const { walk, offsets, terrain, width } = state;
  const labels = new Int32Array(walk.length);
  const queue = new Int32Array(walk.length);
  let count = 0;
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || labels[seed] !== 0) continue;
    count += 1;
    labels[seed] = count;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at + offsets[direction];
        if (walk[next] !== 1 || labels[next] !== 0 || !stepAllowed(state, at, direction)) continue;
        labels[next] = count;
        queue[tail++] = next;
      }
    }
  }
  const deep = new Int32Array(count + 1);
  for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
    if (terrain.cells[index] !== "~") continue;
    const col = index % terrain.cols;
    deep[labels[((index - col) / terrain.cols + 1) * width + col + 1]] += 1;
  }
  deep[0] = 0;
  state.wholes = { labels, count, deep };
  return state.wholes;
}
var runtimes = /* @__PURE__ */ new WeakMap();
var lastTerrain;
var lastRuntimes = {};
function runtime(terrain, mover) {
  if (terrain !== lastTerrain) {
    lastTerrain = terrain;
    lastRuntimes = runtimes.get(terrain) ?? {};
    runtimes.set(terrain, lastRuntimes);
  }
  return mover === "land" ? lastRuntimes.land ??= createRuntime(terrain, "land") : lastRuntimes.sea ??= createRuntime(terrain, "sea");
}
function createRuntime(terrain, mover) {
  const width = terrain.cols + 2;
  const count = width * (terrain.rows + 2);
  const walk = new Uint8Array(count);
  const weight = new Uint8Array(count);
  const passable = PASSABLE[mover];
  for (let row = 0; row < terrain.rows; row += 1) {
    for (let col = 0; col < terrain.cols; col += 1) {
      const char = terrain.cells[row * terrain.cols + col];
      if (!passable.has(char)) continue;
      const at = (row + 1) * width + col + 1;
      walk[at] = 1;
      weight[at] = mover === "sea" ? GROUND_WEIGHT : Math.round(GROUND_WEIGHT / (CELL_GROUND[char]?.pace ?? 1));
    }
  }
  const offsets = Int32Array.from([1, width, -1, -width, width + 1, width - 1, -width - 1, -width + 1]);
  const state = {
    terrain,
    width,
    walk,
    weight,
    fields: /* @__PURE__ */ new Map(),
    clock: 0,
    spare: [],
    nearest: /* @__PURE__ */ new Map(),
    tops: new Int32Array(8),
    boxBuckets: Array.from({ length: BUCKETS }, () => []),
    offsets
  };
  return state;
}
function padAt(state, x, y) {
  const { terrain } = state;
  const col = Math.floor(x / terrain.cell);
  const row = Math.floor(y / terrain.cell);
  if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return -1;
  return (row + 1) * state.width + col + 1;
}
function stepAllowed(state, at, direction) {
  if (direction < 4) return true;
  const { walk, width } = state;
  const dx = direction === 4 || direction === 7 ? 1 : -1;
  const dy = direction === 4 || direction === 5 ? width : -width;
  return walk[at + dx] === 1 && walk[at + dy] === 1;
}

// src/shared/navigation-masks.ts
var angle = Math.PI / 4;

// src/shared/ship-navigation.ts
var DIRECTIONS = 8;
var ANGLE = Math.PI / 4;
function createSearchWorkspace(size) {
  return {
    costs: new Float64Array(size),
    parents: new Int32Array(size),
    stamps: new Uint32Array(size),
    trafficFits: new Int32Array(size),
    basePotentials: new Float64Array(size / DIRECTIONS),
    baseStamps: new Uint32Array(size / DIRECTIONS),
    generation: 0
  };
}
var search = createSearchWorkspace(0);
var Frontier = class {
  length = 0;
  poppedCost = 0;
  ids = new Int32Array(1024);
  costs = new Float64Array(1024);
  scores = new Float64Array(1024);
  reset() {
    this.length = 0;
    if (this.ids.length > 65536) {
      this.ids = new Int32Array(65536);
      this.costs = new Float64Array(65536);
      this.scores = new Float64Array(65536);
    }
    return this;
  }
  save() {
    return Array.from({ length: this.length }, (_, i) => ({ id: this.ids[i], cost: this.costs[i], score: this.scores[i] }));
  }
  restore(slots) {
    this.reset();
    const capacity = Math.max(1024, 2 ** Math.ceil(Math.log2(Math.max(1, slots.length))));
    if (this.ids.length < capacity) {
      this.ids = new Int32Array(capacity);
      this.costs = new Float64Array(capacity);
      this.scores = new Float64Array(capacity);
    }
    this.length = slots.length;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      this.ids[i] = slot.id;
      this.costs[i] = slot.cost;
      this.scores[i] = slot.score;
    }
    return this;
  }
  push(id, cost, score) {
    if (this.length === this.ids.length) {
      const ids = new Int32Array(this.length * 2), costs = new Float64Array(this.length * 2), scores = new Float64Array(this.length * 2);
      ids.set(this.ids);
      costs.set(this.costs);
      scores.set(this.scores);
      this.ids = ids;
      this.costs = costs;
      this.scores = scores;
    }
    let i = this.length++;
    while (i) {
      const parent = i - 1 >>> 2;
      if (!this.less(score, id, this.scores[parent], this.ids[parent]))
        break;
      this.copy(parent, i);
      i = parent;
    }
    this.ids[i] = id;
    this.costs[i] = cost;
    this.scores[i] = score;
  }
  copy(from, to) {
    this.ids[to] = this.ids[from];
    this.costs[to] = this.costs[from];
    this.scores[to] = this.scores[from];
  }
  less(aScore, aId, bScore, bId) {
    return aScore < bScore || aScore === bScore && aId < bId;
  }
  pop() {
    const result = this.ids[0], last = --this.length;
    this.poppedCost = this.costs[0];
    const id = this.ids[last], cost = this.costs[last], score = this.scores[last];
    if (last) {
      let i = 0;
      while (i * 4 + 1 < last) {
        let child = i * 4 + 1;
        const end = Math.min(last, child + 4);
        for (let next = child + 1; next < end; next++)
          if (this.less(this.scores[next], this.ids[next], this.scores[child], this.ids[child]))
            child = next;
        if (!this.less(this.scores[child], this.ids[child], score, id))
          break;
        this.copy(child, i);
        i = child;
      }
      this.ids[i] = id;
      this.costs[i] = cost;
      this.scores[i] = score;
    }
    return result;
  }
};
var routeFrontier = new Frontier();
var distanceFrontier = new Frontier();

// src/shared/veteran-skills.ts
var VETERAN_ACTIVE_SKILL_IDS = ["veteranRally", "veteranHealingWave", "veteranInnerFire"];
var VETERAN_SKILLS = {
  veteranResilience: {
    id: "veteranResilience",
    name: { zh: "\u767E\u6218\u4E4B\u8EAF", en: "Battle Hardened" },
    icon: "\u25C6",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\u3002", en: "Passive: take 25% less damage." },
    effect: { type: "passive", modifiers: { damageReduction: 0.25 } }
  },
  veteranMobility: {
    id: "veteranMobility",
    name: { zh: "\u8FC5\u6377\u884C\u52A8", en: "Swift Movement" },
    icon: "\u27A4",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 30%\u3002", en: "Passive: gain 30% movement speed." },
    effect: { type: "passive", modifiers: { moveSpeedMultiplier: 1.3 } }
  },
  veteranCommand: {
    id: "veteranCommand",
    name: { zh: "\u534F\u540C\u4F5C\u6218", en: "Coordinated Assault" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 35%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 35% attack speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { attackSpeedMultiplier: 1.35 } }
  },
  veteranVigilance: {
    id: "veteranVigilance",
    name: { zh: "\u8B66\u6212\u4E92\u52A9", en: "Watchful Company" },
    icon: "\u25C7",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 18%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 160, including self, take 18% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 160, modifiers: { damageReduction: 0.18 } }
  },
  veteranRally: {
    id: "veteranRally",
    name: { zh: "\u6218\u6597\u53F7\u4EE4", en: "Rallying Cry" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A160 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 60%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002", en: "Active / autocast: up to 5 allies within 160 gain 60% attack speed for 8 seconds. Cooldown: 24 seconds." },
    effect: { type: "active", action: "buff", radius: 160, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { attackSpeedMultiplier: 1.6 } }
  },
  veteranPhalanx: {
    id: "veteranPhalanx",
    name: { zh: "\u575A\u5B88\u9635\u7EBF", en: "Hold the Line" },
    icon: "\u25A3",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A130 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 130, including self, take 25% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 130, modifiers: { damageReduction: 0.25 } }
  },
  veteranSteadyAim: {
    id: "veteranSteadyAim",
    name: { zh: "\u6C89\u7740\u7784\u51C6", en: "Steady Aim" },
    icon: "\u25CE",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u7784\u51C6\u901F\u5EA6\u63D0\u9AD8 80%\uFF0C\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 20%\uFF1B\u79FB\u52A8\u4ECD\u9075\u5B88\u539F\u6709\u7784\u51C6\u9650\u5236\u3002", en: "Passive: gain 80% aiming speed and 20% attack speed. Movement retains its normal effect on aim." },
    effect: { type: "passive", modifiers: { aimSpeedMultiplier: 1.8, attackSpeedMultiplier: 1.2 } }
  },
  veteranMarch: {
    id: "veteranMarch",
    name: { zh: "\u884C\u519B\u9886\u961F", en: "March Leader" },
    icon: "\xBB",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 25%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 25% movement speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { moveSpeedMultiplier: 1.25 } }
  },
  veteranHealingWave: {
    id: "veteranHealingWave",
    name: { zh: "\u7FA4\u4F53\u6062\u590D", en: "Restoring Wave" },
    icon: "\u271A",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A\u6062\u590D 180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u5404 90 \u70B9\u751F\u547D\uFF0C\u4F18\u5148\u4F24\u8005\uFF1B\u51B7\u5374 18 \u79D2\u3002\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Active / autocast: heal up to 5 allies within 180 for 90 health each, prioritizing wounded units. Cooldown: 18 seconds. Does not affect mechanical units." },
    effect: { type: "active", action: "heal", targets: { unitClasses: ["nonMechanical"] }, radius: 180, maxTargets: 5, cooldown: seconds(18), healAmount: 90 }
  },
  veteranInnerFire: {
    id: "veteranInnerFire",
    name: { zh: "\u5FC3\u7075\u4E4B\u706B", en: "Inner Fire" },
    icon: "\u2726",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 35%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002\u77ED\u65F6\u9632\u62A4\u53EA\u53D6\u6700\u5F3A\u3002", en: "Active / autocast: up to 5 allies within 180 take 35% less damage for 8 seconds. Cooldown: 24 seconds. Only the strongest temporary ward applies." },
    effect: { type: "active", action: "buff", radius: 180, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { damageReduction: 0.35 } }
  },
  veteranRenewal: {
    id: "veteranRenewal",
    name: { zh: "\u4F11\u517B\u5E87\u62A4", en: "Renewing Presence" },
    icon: "\u274B",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A150 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u6BCF\u79D2\u6062\u590D 3 \u70B9\u751F\u547D\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\uFF0C\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Aura: allies within 150, including self, restore 3 health per second. Identical auras do not stack. Does not affect mechanical units." },
    effect: { type: "aura", targets: { unitClasses: ["nonMechanical"] }, radius: 150, modifiers: { regenPerSecond: 3 } }
  },
  veteranSiegeDrill: {
    id: "veteranSiegeDrill",
    name: { zh: "\u6D4B\u8DDD\u8BAD\u7EC3", en: "Rangefinding" },
    icon: "\u2316",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u653B\u51FB\u5C04\u7A0B\u63D0\u9AD8 10%\uFF1B\u6700\u5C0F\u5C04\u7A0B\u4FDD\u6301\u4E0D\u53D8\u3002", en: "Passive: gain 10% attack range. Minimum range is unchanged." },
    effect: { type: "passive", modifiers: { attackRangeMultiplier: 1.1 } }
  },
  veteranEndurance: {
    id: "veteranEndurance",
    name: { zh: "\u575A\u97E7\u6062\u590D", en: "Enduring Recovery" },
    icon: "\u2665",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u975E\u673A\u68B0\u5355\u4F4D\u81EA\u8EAB\u6BCF\u79D2\u6062\u590D 6 \u70B9\u751F\u547D\u3002", en: "Passive: non-mechanical units restore 6 health per second." },
    effect: { type: "passive", targets: { unitClasses: ["nonMechanical"] }, modifiers: { regenPerSecond: 6 } }
  }
};
function isVeteranSkillId(value) {
  return typeof value === "string" && Object.hasOwn(VETERAN_SKILLS, value);
}
function isVeteranActiveSkillId(value) {
  return isVeteranSkillId(value) && VETERAN_SKILLS[value].effect.type === "active";
}

// src/shared/ship-equipment.ts
var SHIP_HULL_COST = { cutter: 160, transport: 240, warship: 320, bombardShip: 470, fireShip: 340, carrier: 420, shipOfTheLine: 1080 };
var SHIP_WEAPONS = {
  shipCannon: { cost: 220, mass: 160, hp: 90, damage: 20, range: 312, cooldown: seconds(2), aimSpeed: 440, weapon: { presentation: "cannon", delivery: "bolt", radius: 8, blastRadius: 48, maxHits: 1, navalMultiplier: 2, hullDamageShare: 1.25 }, art: "warship" },
  shipMortar: { cost: 330, mass: 240, hp: 100, damage: 36, range: 576, cooldown: seconds(3.6), aimSpeed: 400, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2, navalMultiplier: 1.7, hullDamageShare: 1.5 }, art: "bombardShip" },
  flameProjector: { cost: 180, mass: 120, hp: 80, damage: 10, range: 144, cooldown: seconds(1.2), aimSpeed: 480, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 }, art: "fireShip" }
};

// src/shared/unit-value.ts
var VETERANCY_GAIN_PER_STAR = 1 / 3;
function unitValue(def) {
  return def.cost > 0 ? def.cost : (def.creepFoodPower ?? 2) * 36 * (def.threat ?? 1);
}
function creepGoldBounty(foodPower, threat = 1) {
  return Math.max(20, Math.round((20 * foodPower + 1.25 * foodPower ** 2) * threat / 5) * 5);
}

// src/shared/damage-types.ts
var DAMAGE_PROFILES = {
  MELEE_CUT: { school: "physical", delivery: "melee", physicalType: "cut", origin: "unit" },
  MELEE_PIERCE: { school: "physical", delivery: "melee", physicalType: "pierce", origin: "unit" },
  MELEE_BLUNT: { school: "physical", delivery: "melee", physicalType: "blunt", origin: "unit" },
  RANGED_PIERCE: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "unit" },
  RANGED_BLUNT: { school: "physical", delivery: "ranged", physicalType: "blunt", origin: "unit" },
  FIRE_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", element: "fire", origin: "unit" },
  MAGIC_MELEE: { school: "magic", delivery: "melee", element: "arcane", origin: "unit" },
  MAGIC_RANGED: { school: "magic", delivery: "ranged", element: "arcane", origin: "unit" },
  FIRE_RANGED: { school: "magic", delivery: "ranged", element: "fire", origin: "unit" },
  TOWER_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "tower" },
  ARCANE: { school: "magic", delivery: "effect", element: "arcane", origin: "spell" },
  BURNING: { school: "magic", delivery: "effect", element: "fire", origin: "spell" },
  POISON: { school: "magic", delivery: "effect", element: "poison", origin: "spell" },
  LIGHTNING: { school: "magic", delivery: "ranged", element: "lightning", origin: "spell" },
  STORM: { school: "magic", delivery: "effect", element: "lightning", origin: "spell" },
  EXPLOSION: { school: "physical", delivery: "effect", physicalType: "blunt", origin: "spell" }
};
var P = DAMAGE_PROFILES;
var UNIT_DAMAGE_PROFILES = {
  worker: P.MELEE_CUT,
  footman: P.MELEE_CUT,
  archer: P.RANGED_PIERCE,
  horseArcher: P.RANGED_PIERCE,
  raider: P.MELEE_CUT,
  lancer: P.MELEE_PIERCE,
  ashWarden: P.MELEE_PIERCE,
  emberRavager: P.MELEE_CUT,
  cinderRunner: P.MELEE_CUT,
  sparkArcher: P.FIRE_ARROW,
  ashHexer: P.MAGIC_RANGED,
  knight: P.MELEE_CUT,
  priest: P.MAGIC_RANGED,
  summoner: P.MAGIC_RANGED,
  witch: P.MAGIC_RANGED,
  golem: P.MELEE_BLUNT,
  ashChieftain: P.MELEE_CUT,
  cinderRevenant: P.MELEE_CUT,
  spirit: P.MAGIC_MELEE,
  mercenary: P.MELEE_CUT,
  contractArcher: P.RANGED_PIERCE,
  fieldMedic: P.MAGIC_RANGED,
  wildling: P.MELEE_BLUNT,
  mossGnawer: P.MELEE_PIERCE,
  thornSlinger: P.RANGED_PIERCE,
  barkMender: P.MAGIC_RANGED,
  stonebackBrute: P.MELEE_BLUNT,
  gladeWitch: P.MAGIC_RANGED,
  // Bare transport/carrier hulls cannot attack; a mounted gun supplies its own profile.
  transport: P.MELEE_BLUNT,
  warship: P.RANGED_BLUNT,
  shipOfTheLine: P.RANGED_BLUNT,
  cutter: P.RANGED_PIERCE,
  bombardShip: P.RANGED_BLUNT,
  fireShip: P.FIRE_RANGED,
  carrier: P.MELEE_BLUNT,
  siegeRam: P.MELEE_BLUNT,
  ballista: P.RANGED_PIERCE,
  catapult: P.RANGED_BLUNT,
  organGun: P.RANGED_PIERCE,
  ancientStag: P.MELEE_PIERCE,
  murlocPeon: P.MELEE_PIERCE,
  murlocHunter: P.RANGED_PIERCE,
  tidePriest: P.MAGIC_RANGED,
  deepSnapper: P.MELEE_PIERCE,
  rubbleGolem: P.MELEE_BLUNT,
  rockGolem: P.MELEE_BLUNT,
  graniteGolem: P.MELEE_BLUNT,
  ogreWarrior: P.MELEE_BLUNT,
  ogreMage: P.MAGIC_RANGED,
  ogreLord: P.MELEE_BLUNT,
  spiderling: P.MELEE_PIERCE,
  venomSpider: P.MELEE_PIERCE,
  spiderQueen: P.MELEE_PIERCE,
  dragonWhelp: P.FIRE_RANGED,
  redDragon: P.FIRE_RANGED
};
var WEAPON_DAMAGE_PROFILES = {
  melee: P.MELEE_BLUNT,
  arrow: P.RANGED_PIERCE,
  spear: P.RANGED_PIERCE,
  stone: P.RANGED_BLUNT,
  magic: P.MAGIC_RANGED,
  fire: P.FIRE_RANGED,
  bolt: P.RANGED_PIERCE,
  cannon: P.RANGED_BLUNT,
  mortar: P.RANGED_BLUNT,
  flame: P.FIRE_RANGED,
  grapeshot: P.RANGED_PIERCE
};
var ITEM_DAMAGE_PROFILES = {
  greatSword: P.MELEE_CUT,
  shipCannon: P.RANGED_BLUNT,
  shipMortar: P.RANGED_BLUNT,
  flameProjector: P.FIRE_RANGED,
  flameCloak: P.BURNING,
  lightningRod: P.LIGHTNING,
  stormStaff: P.STORM,
  breachCharge: P.EXPLOSION
};
var ABILITY_DAMAGE_PROFILES = {
  curse: P.ARCANE,
  ashCurse: P.ARCANE,
  pinningBolt: P.RANGED_PIERCE,
  incendiaryFlume: P.FIRE_RANGED
};

// src/shared/damage-reduction.ts
var HEAVY_ARMOR_DAMAGE = { rangedUnit: 0.5, tower: 0.7 };
var DAMAGE_REDUCTION_RULES = {
  armor: { stacking: "highest", cap: 1 },
  equipment: { stacking: "add", cap: 0.3 },
  passive: { stacking: "highest", cap: 1 },
  aura: { stacking: "highest", cap: 1 },
  ward: { stacking: "highest", cap: 1 }
};
var GROUPS = Object.keys(DAMAGE_REDUCTION_RULES);

// src/shared/transport-role.ts
var TRANSPORT_COMBAT = {
  rangedDamageTaken: HEAVY_ARMOR_DAMAGE.tower,
  passengerDamageMultiplier: 0.5
};

// src/shared/catalog.ts
var SLOW_TICKS = seconds(3);
var POISON_TICKS = seconds(4);
var UNIT_RULES = {
  worker: { hp: 70, speed: 60, radius: 15, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.7), cost: 75, trainTime: seconds(7), supplyUsed: 1, abilities: [] },
  footman: { hp: 145, speed: 62, radius: 18, attackDamage: 16, attackRange: 48, attackCooldown: seconds(1.1), cost: 100, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  archer: { hp: 83, speed: 60, radius: 16, attackDamage: 13, attackRange: 319.2, aimSpeed: 480, attackCooldown: seconds(1.5), cost: 115, trainTime: seconds(7.75), supplyUsed: 2, abilities: [] },
  // The cavalry strikes from the saddle with a reach a little under the lancer's 74 (it had a footman's, 48 and 52).
  horseArcher: { hp: 109, speed: 90, radius: 19, attackDamage: 10, attackRange: 264, aimSpeed: 600, attackCooldown: seconds(1.5), cost: 150, trainTime: seconds(10), supplyUsed: 2, abilities: [], tier: 2, aimMoveTolerance: 72 },
  raider: { hp: 115, speed: 82, radius: 18, attackDamage: 14, attackRange: 72, attackCooldown: seconds(1), cost: 115, trainTime: seconds(8.5), supplyUsed: 2, abilities: ["charge"], tier: 2 },
  lancer: { hp: 130, speed: 68, radius: 18, attackDamage: 18, attackRange: 74, attackCooldown: seconds(1.4), cost: 110, trainTime: seconds(8.75), supplyUsed: 2, abilities: [] },
  ashWarden: { hp: 165, speed: 60, radius: 19, attackDamage: 15, attackRange: 52, attackCooldown: seconds(1.15), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  emberRavager: { hp: 118, speed: 76, radius: 18, attackDamage: 20, attackRange: 52, attackCooldown: seconds(1.25), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  cinderRunner: { hp: 96, speed: 87, radius: 17, attackDamage: 14, attackRange: 48, attackCooldown: seconds(0.95), cost: 110, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  sparkArcher: { hp: 85, speed: 63, radius: 16, attackDamage: 9, attackRange: 288, aimSpeed: 540, attackCooldown: seconds(1.35), cost: 110, trainTime: seconds(7.25), supplyUsed: 2, abilities: [] },
  ashHexer: { hp: 82, speed: 64, radius: 16, attackDamage: 7, attackRange: 240, aimSpeed: 520, attackCooldown: seconds(1.7), cost: 140, trainTime: seconds(9), supplyUsed: 2, abilities: ["ashCurse"], tier: 2 },
  knight: { hp: 220, speed: 72, radius: 22, attackDamage: 24, attackRange: 72, attackCooldown: seconds(1.3), cost: 190, trainTime: seconds(11.5), supplyUsed: 3, abilities: ["charge"], armor: "heavy", tier: 3 },
  priest: { hp: 90, speed: 60, radius: 16, attackDamage: 7, attackRange: 201.6, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 135, trainTime: seconds(9.25), supplyUsed: 2, abilities: ["heal"], tier: 2 },
  summoner: { hp: 95, speed: 56, radius: 17, attackDamage: 8, attackRange: 218.4, aimSpeed: 400, attackCooldown: seconds(1.9), cost: 180, trainTime: seconds(10.5), supplyUsed: 2, abilities: ["summon"], tier: 2 },
  witch: { hp: 92, speed: 62, radius: 16, attackDamage: 8, attackRange: 252, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 145, trainTime: seconds(9.75), supplyUsed: 2, abilities: ["curse"], tier: 2 },
  golem: { unitClass: "mechanical", hp: 340, speed: 42, radius: 28, attackDamage: 34, attackRange: 58, attackCooldown: seconds(2.1), cost: 230, trainTime: seconds(14), supplyUsed: 4, abilities: [], armor: "heavy", tier: 3 },
  // Ember's heavies, raised in the ashen hall and heavy-armored like the grove's knight and golem, but built for
  // other jobs. The chieftain hunts casters and what they summon (half again as much damage to both); the revenant is
  // light for an elite and burns its wounds away, back to full health in about twenty seconds.
  ashChieftain: { hp: 210, speed: 66, radius: 20, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.2), cost: 190, trainTime: seconds(11), supplyUsed: 3, abilities: [], armor: "heavy", casterSlayer: 1.5, tier: 3 },
  cinderRevenant: { hp: 150, speed: 70, radius: 19, attackDamage: 21, attackRange: 52, attackCooldown: seconds(1.15), cost: 210, trainTime: seconds(12), supplyUsed: 3, abilities: [], armor: "heavy", regenPerSecond: 7, tier: 3 },
  spirit: { hp: 85, speed: 70, radius: 15, attackDamage: 13, attackRange: 55, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, abilities: [] },
  mercenary: { hp: 155, speed: 74, radius: 18, attackDamage: 28, attackRange: 62, attackCooldown: seconds(0.9), cost: 160, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  contractArcher: { hp: 93, speed: 64, radius: 16, attackDamage: 19, attackRange: 352.8, aimSpeed: 600, attackCooldown: seconds(1.35), cost: 145, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  fieldMedic: { hp: 105, speed: 62, radius: 16, attackDamage: 8, attackRange: 210.4, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 155, trainTime: seconds(0.05), supplyUsed: 2, abilities: ["heal"] },
  wildling: { hp: 76, speed: 76, radius: 15, attackDamage: 10, attackRange: 42, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  mossGnawer: { hp: 54, speed: 84, radius: 13, attackDamage: 8, attackRange: 34, attackCooldown: seconds(1.3), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  thornSlinger: { hp: 83, speed: 68, radius: 18, attackDamage: 13, attackRange: 132, aimSpeed: 400, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [] },
  barkMender: { hp: 68, speed: 64, radius: 18, attackDamage: 7, attackRange: 88, aimSpeed: 400, attackCooldown: seconds(2.1), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: ["heal"] },
  stonebackBrute: { hp: 210, speed: 72, radius: 24, attackDamage: 28, attackRange: 48, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  gladeWitch: { hp: 110, speed: 66, radius: 22, attackDamage: 13, attackRange: 120, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["curse"] },
  // @@@ships - Both races can board every ship. Troop ferry passengers deal half damage;
  // warships have sturdier hulls and a cannon. Deck space and mass determine crew capacity.
  transport: { unitClass: "mechanical", hp: 270, speed: 64, radius: 30, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.transport, trainTime: seconds(12), supplyUsed: 1, abilities: [], naval: true, ...TRANSPORT_COMBAT },
  warship: { unitClass: "mechanical", hp: 320, speed: 60, radius: 28, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.warship + SHIP_WEAPONS.shipCannon.cost, trainTime: seconds(14), supplyUsed: 3, abilities: [], naval: true, weapon: SHIP_WEAPONS.shipCannon.weapon },
  // Four removable cannons are included in the purchase; the hull has no extra intrinsic shot.
  shipOfTheLine: { unitClass: "mechanical", hp: 740, speed: 46, radius: 48, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.shipOfTheLine + SHIP_WEAPONS.shipCannon.cost * 4, trainTime: seconds(30), supplyUsed: 7, abilities: [], naval: true, armor: "heavy", tier: 3, weapon: SHIP_WEAPONS.shipCannon.weapon },
  cutter: { unitClass: "mechanical", hp: 110, speed: 84, radius: 24, attackDamage: 10, attackRange: 264, aimSpeed: 540, attackCooldown: seconds(1.3), cost: SHIP_HULL_COST.cutter, trainTime: seconds(9), supplyUsed: 2, abilities: [], naval: true, intrinsicAttack: true },
  bombardShip: { unitClass: "mechanical", hp: 260, speed: 44, radius: 32, attackDamage: 36, attackRange: 576, aimSpeed: 400, attackCooldown: seconds(3.6), cost: SHIP_HULL_COST.bombardShip + SHIP_WEAPONS.shipMortar.cost, trainTime: seconds(19), supplyUsed: 4, abilities: [], naval: true, tier: 2, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2 } },
  fireShip: { unitClass: "mechanical", hp: 340, speed: 70, radius: 28, attackDamage: 10, attackRange: 144, aimSpeed: 480, attackCooldown: seconds(1.2), cost: SHIP_HULL_COST.fireShip + SHIP_WEAPONS.flameProjector.cost, trainTime: seconds(15), supplyUsed: 3, abilities: ["incendiaryFlume"], naval: true, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 } },
  carrier: { unitClass: "mechanical", hp: 480, speed: 54, radius: 38, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.carrier, trainTime: seconds(18), supplyUsed: 3, abilities: [], naval: true, ...TRANSPORT_COMBAT, tier: 2 },
  siegeRam: { unitClass: "mechanical", hp: 420, speed: 50, radius: 26, attackDamage: 22, attackRange: 64, attackCooldown: seconds(1.8), cost: 240, trainTime: seconds(16), supplyUsed: 3, abilities: [], armor: "heavy", tier: 2, weapon: { presentation: "melee", delivery: "ram", buildingMultiplier: 3.3 } },
  ballista: { unitClass: "mechanical", hp: 150, speed: 46, radius: 24, attackDamage: 27, attackRange: 472, aimSpeed: 420, attackCooldown: seconds(2.4), cost: 300, trainTime: seconds(15), supplyUsed: 3, abilities: ["pinningBolt"], tier: 2, weapon: { presentation: "bolt", delivery: "bolt", radius: 18, maxHits: 3, pierceShare: 0.7, buildingMultiplier: 0.75, navalMultiplier: 1.4 } },
  catapult: { unitClass: "mechanical", hp: 180, speed: 38, radius: 27, attackDamage: 38, attackRange: 608, aimSpeed: 360, attackCooldown: seconds(3.8), cost: 390, trainTime: seconds(19), supplyUsed: 4, abilities: [], tier: 2, weapon: { presentation: "stone", delivery: "shell", radius: 90, minRange: 180, buildingMultiplier: 2 } },
  organGun: { unitClass: "mechanical", hp: 190, speed: 46, radius: 25, attackDamage: 12, attackRange: 304, aimSpeed: 480, attackCooldown: seconds(2.5), cost: 350, trainTime: seconds(17), supplyUsed: 3, abilities: [], tier: 2, weapon: { presentation: "grapeshot", delivery: "cone", coneAngle: 0.42, burst: 3, buildingMultiplier: 0.45 } },
  ancientStag: { hp: 360, speed: 88, radius: 32, attackDamage: 38, attackRange: 68, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [] },
  // @@@creep-families - The camp families (see shared/camps.ts), a creep's level its food power, bounty and experience by
  // level (20/35/50/68/85/100/130 gold at levels 1-8). A tier's camps are as hard as the old wildling camps of that tier:
  // health and damage were set so that a squad of two footmen to an archer sized to the tier (3, 5, 7) loses as much,
  // for the camp's level, clearing the new templates as the old ones, within a tenth on average (green 0.96, orange
  // 1.09, red 1.06); a power changes how a camp fights, not how hard it is. Each has one trait or ability at most (see
  // @@@creep-traits), and none reaches past a tower's 480, so no creep wakes from farther than today. None is wider
  // than 28: a blow's reach is measured from center to center, and a footman (radius 18, reach 48) could not strike a
  // wider one through their bodies.
  murlocPeon: { hp: 80, speed: 72, radius: 14, attackDamage: 11, attackRange: 40, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  murlocHunter: { hp: 98, speed: 72, radius: 15, attackDamage: 13, attackRange: 120, aimSpeed: 480, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], slowOnHit: true, threat: 1.05 },
  tidePriest: { hp: 100, speed: 64, radius: 17, attackDamage: 10, attackRange: 160, aimSpeed: 440, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["heal"] },
  deepSnapper: { hp: 350, speed: 70, radius: 26, attackDamage: 31, attackRange: 52, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [], armor: "heavy", threat: 1.25 },
  rubbleGolem: { unitClass: "mechanical", hp: 190, speed: 50, radius: 22, attackDamage: 22, attackRange: 48, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [], armor: "heavy" },
  rockGolem: { unitClass: "mechanical", hp: 235, speed: 50, radius: 25, attackDamage: 25, attackRange: 52, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [], armor: "heavy", threat: 1.3 },
  graniteGolem: { unitClass: "mechanical", hp: 390, speed: 48, radius: 28, attackDamage: 35, attackRange: 58, attackCooldown: seconds(2.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: ["stomp"], armor: "heavy", threat: 1.3 },
  ogreWarrior: { hp: 178, speed: 68, radius: 22, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  ogreMage: { hp: 145, speed: 64, radius: 22, attackDamage: 15, attackRange: 160, aimSpeed: 400, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: ["bloodlust"], threat: 1.15 },
  ogreLord: { hp: 380, speed: 68, radius: 28, attackDamage: 34, attackRange: 56, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: [], threat: 1.35 },
  spiderling: { hp: 65, speed: 88, radius: 12, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  venomSpider: { hp: 105, speed: 84, radius: 15, attackDamage: 13, attackRange: 44, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], poisonOnHit: true, threat: 1.7 },
  spiderQueen: { hp: 350, speed: 80, radius: 26, attackDamage: 33, attackRange: 52, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: ["web"] },
  dragonWhelp: { hp: 170, speed: 84, radius: 22, attackDamage: 17, attackRange: 144, aimSpeed: 540, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [] },
  redDragon: { hp: 600, speed: 80, radius: 28, attackDamage: 42, attackRange: 176, aimSpeed: 480, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 8, abilities: [], splash: true, threat: 1.3 }
};
var UNIT_DEFS = Object.fromEntries(
  Object.entries(UNIT_RULES).map(([kind, row]) => {
    const def = { unitClass: "nonMechanical", ...row, xpReward: 0 };
    def.xpReward = kind === "spirit" ? 0 : Math.round(unitValue(def) / 3);
    if (def.creepFoodPower) def.goldBounty = creepGoldBounty(def.creepFoodPower, def.threat);
    return [kind, def];
  })
);
function unitRules(game, unit) {
  if (unit.variant === void 0 || !game.variants) return UNIT_DEFS[unit.kind];
  const rules = game.variants[unit.variant];
  if (!rules) throw new Error(`Unknown unit variant ${unit.variant}`);
  return rules;
}
var UNIT_KINDS = Object.keys(UNIT_DEFS);
var NAVAL_KINDS = new Set(UNIT_KINDS.filter((kind) => UNIT_DEFS[kind].naval));
function unitMover(kind) {
  return NAVAL_KINDS.has(kind) ? "sea" : "land";
}
var ABILITY_KINDS = ["heal", "summon", "curse", "ashCurse", "charge", "stomp", "bloodlust", "web", "pinningBolt", "incendiaryFlume", ...VETERAN_ACTIVE_SKILL_IDS];
var CURSE_SUMMONED_DAMAGE = 100;
var ABILITY_DEFS = {
  ...Object.fromEntries(VETERAN_ACTIVE_SKILL_IDS.map((skill) => {
    const effect = VETERAN_SKILLS[skill].effect;
    if (effect.type !== "active") throw new Error(`Veteran ability ${skill} must be active`);
    return [skill, {
      behavior: "veteran",
      skill,
      range: effect.radius,
      plannerRange: effect.radius,
      cooldown: effect.cooldown,
      effectType: effect.action === "heal" ? "heal" : effect.modifiers.damageReduction ? "guardianField" : "bloodlust",
      autocast: "on",
      ...effect.targets ? { targets: effect.targets } : {}
    }];
  })),
  pinningBolt: { behavior: "weapon", target: "enemy", weapon: { presentation: "bolt", delivery: "bolt", radius: 20, maxHits: 3, pierceShare: 0.7 }, range: 472, plannerRange: 472, cooldown: seconds(14), damage: 36, rootTicks: seconds(2), effectType: "siegeBolt", autocast: "none" },
  incendiaryFlume: { behavior: "weapon", target: "point", weapon: { presentation: "fire", delivery: "shell", radius: 85, buildingMultiplier: 0.7 }, range: 224, plannerRange: 224, cooldown: seconds(18), damage: 14, burnTicks: seconds(4), effectType: "burningGround", autocast: "none" },
  // With spells on their own cooldowns (see ability-cooldowns) a healer heals through every fight. At one heal every 6s,
  // 9 health a second, two mirrored default AIs fought for 41 minutes on verdantCrossroads (12.7 before) and never ended on
  // wildMarches. Every 12s is Warcraft III's measure: a priest's mana holds it to about a third of a footman's damage.
  heal: { behavior: "heal", targets: { unitClasses: ["nonMechanical"] }, range: 240, plannerRange: 220, cooldown: seconds(12), healAmount: 55, effectType: "heal", autocast: "on" },
  summon: { behavior: "summon", range: 260, plannerRange: 240, cooldown: seconds(40), summonKind: "spirit", summonDuration: seconds(60), effectType: "summon", autocast: "on" },
  curse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.4, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "curse", autocast: "on" },
  ashCurse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.45, scorchedDamageMultiplier: 0.3, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "scorch", autocast: "on" },
  // The cavalry's charge: from 180 to 300 away, a slide that would carry the rider `drive` past the unit it meets (see
  // @@@charge), and a blow of twice the weapon's.
  charge: { behavior: "charge", minRange: 180, range: 300, plannerRange: 288, cooldown: seconds(15), damageMultiplier: 2, drive: 100, effectType: "chargeTrail", autocast: "on" },
  // @@@creep-abilities - The creeps' own, cast by themselves only: a granite golem's stomp stuns every enemy unit within
  // 160 for 1.5s, every 12s; an ogre mage's bloodlust quickens a fighting ally's blows by 30% for 15s, every 20s; a spider
  // queen's web roots one enemy within 220 in place for 2s, every 10s.
  stomp: { behavior: "stomp", range: 160, plannerRange: 150, cooldown: seconds(12), effectDuration: seconds(1.5), effectType: "stomp", autocast: "on" },
  bloodlust: { behavior: "bloodlust", range: 300, plannerRange: 280, cooldown: seconds(20), effectDuration: seconds(15), attackSpeed: 1.3, effectType: "bloodlust", autocast: "on" },
  web: { behavior: "web", range: 220, plannerRange: 200, cooldown: seconds(10), effectDuration: seconds(2), effectType: "web", autocast: "on" }
};
var BUILDING_RULES = {
  townHall: { hp: 900, radius: 48, cost: 400, buildTime: seconds(28), researches: ["buildingDurability"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 8 },
  barracks: { race: "grove", hp: 620, radius: 40, cost: 170, buildTime: seconds(11), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  archeryRange: { race: "grove", hp: 520, radius: 38, cost: 150, buildTime: seconds(10), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  stables: { race: "grove", hp: 560, radius: 42, cost: 175, buildTime: seconds(11.5), researches: ["speedTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  sanctum: { race: "grove", hp: 500, radius: 38, cost: 175, buildTime: seconds(11.25), researches: ["leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  workshop: { hp: 580, radius: 42, cost: 205, buildTime: seconds(12.5), researches: ["rangeTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  defenseTower: { neutralDamageMultiplier: 0.5, hp: 200, radius: 30, cost: 125, buildTime: seconds(6.5), researches: [], attackDamage: 16, attackRange: 480, attackCooldown: seconds(1.5), supplyProvided: 0 },
  moonWell: { race: "grove", hp: 300, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  emberForge: { race: "ember", hp: 560, radius: 40, cost: 165, buildTime: seconds(10.5), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  cinderSpire: { race: "ember", hp: 500, radius: 38, cost: 170, buildTime: seconds(10.75), researches: ["speedTraining", "rangeTraining", "leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  emberShrine: { race: "ember", hp: 280, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  // Ember's heavy-unit hall, its stables and workshop in one: one building for both heavies, priced above either.
  ashenHall: { race: "ember", hp: 600, radius: 42, cost: 215, buildTime: seconds(13), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  // Supply is the tech (see unit-tiers), so it is dear: a farm's 6 cost 120, a hall's 8 are priced the same inside its 400.
  farm: { hp: 320, radius: 30, cost: 120, buildTime: seconds(7), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 6 },
  // Ships are built here (see @@@naval); every race builds it, as it does a tower or a farm.
  shipyard: { hp: 600, radius: 44, cost: 170, buildTime: seconds(12), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0, shore: true }
};
var BUILDABLE_BUILDING_KINDS = Object.keys(BUILDING_RULES);
var COMMON_PRODUCTION = {
  worker: { at: "townHall" },
  transport: { at: "shipyard" },
  warship: { at: "shipyard" },
  shipOfTheLine: { at: "shipyard" },
  cutter: { at: "shipyard" },
  bombardShip: { at: "shipyard" },
  fireShip: { at: "shipyard" },
  carrier: { at: "shipyard" }
};
var RACE_TECH_RULES = {
  grove: { units: {
    ...COMMON_PRODUCTION,
    footman: { at: "barracks" },
    lancer: { at: "barracks" },
    archer: { at: "archeryRange" },
    horseArcher: { at: "stables" },
    raider: { at: "stables" },
    knight: { at: "stables" },
    priest: { at: "sanctum" },
    summoner: { at: "sanctum" },
    witch: { at: "sanctum" },
    golem: { at: "workshop" },
    ballista: { at: "workshop" }
  } },
  ember: { units: {
    ...COMMON_PRODUCTION,
    ashWarden: { at: "emberForge" },
    emberRavager: { at: "emberForge" },
    cinderRunner: { at: "emberForge" },
    sparkArcher: { at: "cinderSpire" },
    priest: { at: "cinderSpire" },
    ashHexer: { at: "cinderSpire" },
    summoner: { at: "cinderSpire" },
    ashChieftain: { at: "ashenHall" },
    cinderRevenant: { at: "ashenHall" },
    siegeRam: { at: "workshop" },
    catapult: { at: "workshop" },
    organGun: { at: "workshop" }
  } }
};
var PRODUCTION = {
  grove: RACE_TECH_RULES.grove.units,
  ember: RACE_TECH_RULES.ember.units
};
function trainingBuildingFor(race, kind) {
  return PRODUCTION[race][kind]?.at;
}
function canTrainAt(race, building, kind) {
  return trainingBuildingFor(race, kind) === building;
}
var TRAINABLE_UNIT_KINDS = UNIT_KINDS.filter(
  (kind) => canTrainForAnyRace(kind)
);
function canTrainForAnyRace(kind) {
  return Object.values(PRODUCTION).some((units2) => units2[kind] !== void 0);
}
var TRAINING_BY_RACE = Object.fromEntries(
  Object.keys(PRODUCTION).map((race) => [race, Object.fromEntries(
    BUILDABLE_BUILDING_KINDS.map((building) => [
      building,
      Object.freeze(TRAINABLE_UNIT_KINDS.filter((kind) => canTrainAt(race, building, kind)))
    ])
  )])
);
var BUILDING_DEFS = Object.fromEntries(
  BUILDABLE_BUILDING_KINDS.map((kind) => [kind, { ...BUILDING_RULES[kind], trains: TRAINABLE_UNIT_KINDS.filter((unit) => Object.values(PRODUCTION).some((units2) => units2[unit]?.at === kind)) }])
);
var ORDINARY_COMBAT_UNITS = TRAINABLE_UNIT_KINDS.filter((kind) => kind !== "worker");
var UPGRADE_RULES = {
  weaponTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 150, researchTime: seconds(34.5), attackMultiplier: 1.15 },
      { cost: 175, researchTime: seconds(46.5), attackMultiplier: 1.3 },
      { cost: 200, researchTime: seconds(60), attackMultiplier: 1.45 }
    ]
  },
  reinforcedPlating: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 180, researchTime: seconds(40.5), maxHpMultiplier: 1.15 },
      { cost: 210, researchTime: seconds(52.5), maxHpMultiplier: 1.3 },
      { cost: 240, researchTime: seconds(66), maxHpMultiplier: 1.45 }
    ]
  },
  buildingDurability: {
    affectedUnitKinds: [],
    levels: [
      { cost: 200, researchTime: seconds(54), buildingMaxHpMultiplier: 1.2 }
    ]
  },
  // A tenth faster a level: at a quarter a level (1.25, 1.38, 1.5) a footman at the third outran a raider untrained (4.5
  // against 82), and the riders' speed was theirs no more.
  speedTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 185, researchTime: seconds(46), speedMultiplier: 1.1 },
      { cost: 285, researchTime: seconds(60), speedMultiplier: 1.2 },
      { cost: 420, researchTime: seconds(76), speedMultiplier: 1.3 }
    ]
  },
  rangeTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 195, researchTime: seconds(48), attackRangeMultiplier: 1.15 },
      { cost: 305, researchTime: seconds(64), attackRangeMultiplier: 1.25 },
      { cost: 450, researchTime: seconds(82), attackRangeMultiplier: 1.35 }
    ]
  },
  leadership: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    // @@@leadership-by-stars - A second and a third star are worth more than the first. One star regenerates 1, 2 and 3
    // health a second by the research's level, as it always did; two stars 3, 5 and 7; three stars 6, 9 and 12. A single
    // three-star veteran repays the first level on its own: 6 a second for 200 gold, where a moon well gives 3.3 for 115.
    // Each later level adds one a second per star, for armies with many veterans. At one a second per star for 220 gold,
    // the two to four stars a gauntlet army carries at 5-13 minutes regenerated half of what a well bought for the gold.
    levels: [
      { cost: 200, researchTime: seconds(52), veteranRegenByStars: [1, 3, 6] },
      { cost: 300, researchTime: seconds(70), veteranRegenByStars: [2, 5, 9] },
      { cost: 450, researchTime: seconds(90), veteranRegenByStars: [3, 7, 12] }
    ]
  }
};
var UPGRADE_KINDS = ["weaponTraining", "reinforcedPlating", "buildingDurability", "speedTraining", "rangeTraining", "leadership"];
var UPGRADE_DEFS = Object.fromEntries(
  UPGRADE_KINDS.map((kind) => [kind, {
    ...UPGRADE_RULES[kind],
    researchBuildingKinds: BUILDABLE_BUILDING_KINDS.filter((building) => BUILDING_DEFS[building].researches.includes(kind))
  }])
);
function canResearchAt(race, building, upgrade) {
  const rules = BUILDING_DEFS[building];
  return (rules.race === void 0 || rules.race === race) && rules.researches.includes(upgrade);
}
function raceDef(id, name, note) {
  const owns = (race) => race === void 0 || race === id;
  return {
    id,
    name,
    note,
    trainableUnits: TRAINABLE_UNIT_KINDS.filter((kind) => trainingBuildingFor(id, kind) !== void 0),
    buildableBuildings: BUILDABLE_BUILDING_KINDS.filter((kind) => owns(BUILDING_DEFS[kind].race)),
    upgrades: UPGRADE_KINDS.filter((upgrade) => BUILDABLE_BUILDING_KINDS.some((building) => canResearchAt(id, building, upgrade)))
  };
}
var RACE_DEFS = {
  grove: raceDef("grove", "Grove Kin", "Durable line holders, conventional ranged units, heavy tech, and moon-well recovery."),
  ember: raceDef("ember", "Ember Pact", "Faster fragile fighters, early support casters, ashen-hall heavies, and ember-shrine recovery.")
};

// src/shared/unit-targeting.ts
function unitClassOf(unit, snapshot = {}) {
  return unitRules(snapshot, unit).unitClass ?? UNIT_DEFS[unit.kind].unitClass;
}
function matchesUnitTarget(unit, filter, snapshot) {
  return !filter?.unitClasses || filter.unitClasses.includes(unitClassOf(unit, snapshot));
}
var NON_MECHANICAL_TARGETS = { unitClasses: ["nonMechanical"] };

// src/shared/healing.ts
function canReceiveHealing(unit, snapshot) {
  return matchesUnitTarget(unit, NON_MECHANICAL_TARGETS, snapshot);
}

// src/shared/unit-abilities.ts
function unitAbilities(unit) {
  const innate = UNIT_DEFS[unit.kind].abilities;
  return isVeteranActiveSkillId(unit.veteranSkill) ? [...innate, unit.veteranSkill] : innate;
}

// src/shared/ability-cooldowns.ts
function abilityCooldown(unit, ability) {
  return unit.abilityCooldowns?.[ability] ?? 0;
}
function canCast(unit) {
  return unitAbilities(unit).some((ability) => abilityCooldown(unit, ability) <= 0);
}

// src/shared/ship-gangway.ts
var GANGWAY_SETUP_TICKS = seconds(3);
var GANGWAY_COOLDOWN_TICKS = seconds(20);
var crewRules = /* @__PURE__ */ new WeakMap();
function bindGangwayCrewRules(units2, snapshot) {
  for (const source of shipsIn(units2)) if (source.sailing?.gangway) crewRules.set(source, snapshot);
}

// src/sdk/snapshot/range-index.ts
var RANGE_CELL = 256;
var RANGE_INDEX_MIN_ITEMS = 32;
function createRangeIndex(items) {
  const plain = (point, range, matches) => matches ? items.filter((item) => withinRange(item, point, range) && matches(item)) : items.filter((item) => withinRange(item, point, range));
  if (items.length < RANGE_INDEX_MIN_ITEMS) return plain;
  let grid;
  return (point, range, matches) => {
    const span = Math.ceil((range + 1) / RANGE_CELL);
    const cx = Math.floor(point.x / RANGE_CELL);
    const cy = Math.floor(point.y / RANGE_CELL);
    if (!Number.isFinite(span) || !Number.isFinite(cx) || !Number.isFinite(cy) || (2 * span + 1) ** 2 > items.length) return plain(point, range, matches);
    grid ??= indexCells(items);
    const hits = [];
    for (let x = cx - span; x <= cx + span; x += 1) {
      for (let y = cy - span; y <= cy + span; y += 1) {
        for (const index of grid.cells.get(cellKey(x, y)) ?? []) if (withinRange(items[index], point, range)) hits.push(index);
      }
    }
    for (const index of grid.offGrid) if (withinRange(items[index], point, range)) hits.push(index);
    hits.sort((a, b) => a - b);
    if (!matches) return hits.map((index) => items[index]);
    const selected = [];
    for (const index of hits) {
      const item = items[index];
      if (matches(item)) selected.push(item);
    }
    return selected;
  };
}
function indexCells(items) {
  const cells = /* @__PURE__ */ new Map();
  const offGrid = [];
  for (let index = 0; index < items.length; index += 1) {
    const x = Math.floor(items[index].x / RANGE_CELL);
    const y = Math.floor(items[index].y / RANGE_CELL);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      offGrid.push(index);
      continue;
    }
    const key = cellKey(x, y);
    const bucket = cells.get(key);
    if (bucket) bucket.push(index);
    else cells.set(key, [index]);
  }
  return { cells, offGrid };
}
function cellKey(x, y) {
  return x * 4096 + y;
}
function withinRange(a, b, range) {
  const dx = a.x - b.x, dy = a.y - b.y;
  if (Math.abs(dx) > range || Math.abs(dy) > range) return false;
  return hypot2(dx, dy) <= range;
}

// src/sdk/snapshot/query.ts
function createSnapshotQuery(snapshot, options = {}) {
  bindGangwayCrewRules(snapshot.units, snapshot);
  const teamFor = (owner) => owner === "neutral" ? "neutral" : options.teams?.[owner] ?? owner;
  const isOpponent = (owner, other) => other !== "neutral" && teamFor(owner) !== teamFor(other);
  const visibleItems = options.excludeIssuedWeapons ? snapshot.items.filter((item) => item.kind !== "issuedWeapon") : snapshot.items;
  let ground;
  const carriedByOwner = /* @__PURE__ */ new Map();
  let activePlayers;
  const cachedActivePlayers = () => activePlayers ??= Object.keys(snapshot.players).filter((owner) => snapshot.units.some((unit) => unit.owner === owner) || snapshot.buildings.some((building) => building.owner === owner));
  const unitsByOwner = /* @__PURE__ */ new Map();
  const combatUnitsByOwner = /* @__PURE__ */ new Map();
  const buildingsByOwner = /* @__PURE__ */ new Map();
  const completeBuildingsByOwner = /* @__PURE__ */ new Map();
  const hostileCombatUnitsByOwner = /* @__PURE__ */ new Map();
  const viewByOwner = /* @__PURE__ */ new Map();
  let unitsById;
  let buildingsById;
  let neutralUnits;
  const nearIndexes = /* @__PURE__ */ new Map();
  const combatUnit = (unit) => unit.kind !== "worker";
  const unitsNear = (key, matches) => {
    let near = nearIndexes.get(key);
    if (!near) nearIndexes.set(key, near = createRangeIndex(snapshot.units.filter(matches)));
    return near;
  };
  const cachedPlayerView = (owner, query) => {
    let view = viewByOwner.get(owner);
    if (!view) {
      const ownTeam = teamFor(owner);
      const entities = playerEntityViews(snapshot, owner, ownTeam, teamFor);
      view = {
        owner,
        team: ownTeam,
        ...entities,
        resources: entitySet(snapshot.resources),
        mercenaryCamps: entitySet(snapshot.mercenaryCamps),
        items: { ground: query.groundItems(), carried: query.carriedItemsFor(owner) }
      };
      viewByOwner.set(owner, view);
    }
    return view;
  };
  return {
    snapshot,
    teamFor,
    isOpponent,
    activePlayerIds() {
      return cachedActivePlayers().slice();
    },
    opponentPlayerIds(owner) {
      return cachedActivePlayers().filter((candidate) => isOpponent(owner, candidate));
    },
    unitById(id) {
      unitsById ??= firstById(snapshot.units);
      return unitsById.get(id);
    },
    buildingById(id) {
      buildingsById ??= firstById(snapshot.buildings);
      return buildingsById.get(id);
    },
    resourceById(id) {
      return snapshot.resources.find((resource) => resource.id === id);
    },
    mercenaryCampById(id) {
      return snapshot.mercenaryCamps.find((camp) => camp.id === id);
    },
    itemById(id) {
      return snapshot.items.find((item) => item.id === id);
    },
    targetById(id) {
      return this.unitById(id) ?? this.buildingById(id) ?? this.resourceById(id) ?? this.mercenaryCampById(id) ?? this.itemById(id);
    },
    resources() {
      return snapshot.resources;
    },
    activeResources() {
      return snapshot.resources.filter((resource) => resource.amount > 0);
    },
    mercenaryCamps() {
      return snapshot.mercenaryCamps;
    },
    items() {
      return visibleItems;
    },
    groundItems() {
      ground ??= visibleItems.filter((item) => !item.carrierId && !item.shipId);
      return ground.slice();
    },
    carriedItemsFor(owner) {
      let carried = carriedByOwner.get(owner);
      if (!carried) {
        const ownUnitIds = new Set(this.unitsFor(owner).map((unit) => unit.id));
        carried = visibleItems.filter((item) => item.carrierId && ownUnitIds.has(item.carrierId));
        carriedByOwner.set(owner, carried);
      }
      return carried.slice();
    },
    buildings() {
      return snapshot.buildings;
    },
    unitsFor(owner) {
      let units2 = unitsByOwner.get(owner);
      if (!units2) unitsByOwner.set(owner, units2 = snapshot.units.filter((unit) => unit.owner === owner));
      return units2.slice();
    },
    combatUnitsFor(owner) {
      let units2 = combatUnitsByOwner.get(owner);
      if (!units2) combatUnitsByOwner.set(owner, units2 = this.unitsFor(owner).filter((unit) => unit.kind !== "worker"));
      return units2.slice();
    },
    buildingsFor(owner) {
      let buildings2 = buildingsByOwner.get(owner);
      if (!buildings2) buildingsByOwner.set(owner, buildings2 = snapshot.buildings.filter((building) => building.owner === owner));
      return buildings2.slice();
    },
    completeBuildingsFor(owner, kind) {
      let byKind = completeBuildingsByOwner.get(owner);
      if (!byKind) completeBuildingsByOwner.set(owner, byKind = /* @__PURE__ */ new Map());
      let buildings2 = byKind.get(kind);
      if (!buildings2) byKind.set(kind, buildings2 = this.buildingsFor(owner).filter((building) => building.complete && (kind === void 0 || building.kind === kind)));
      return buildings2.slice();
    },
    neutralUnitsNear(point, range) {
      neutralUnits ??= snapshot.units.filter((unit) => unit.owner === "neutral");
      return neutralUnits.filter((unit) => distance(unit, point) <= range);
    },
    opponentUnitsNear(owner, point, range) {
      return unitsNear(`opponent ${owner}`, (unit) => isOpponent(owner, unit.owner))(point, range);
    },
    opponentCombatUnitsNear(owner, point, range) {
      return unitsNear(`opponent ${owner}`, (unit) => isOpponent(owner, unit.owner))(point, range, combatUnit);
    },
    opponentBuildingsNear(owner, point, range) {
      return snapshot.buildings.filter((building) => isOpponent(owner, building.owner) && distance(building, point) <= range);
    },
    hostileUnitsNear(owner, point, range) {
      return unitsNear(`hostile ${owner}`, (unit) => isOpponent(owner, unit.owner) || unit.owner === "neutral")(point, range);
    },
    hostileCombatUnitsFor(owner) {
      let units2 = hostileCombatUnitsByOwner.get(owner);
      if (!units2) hostileCombatUnitsByOwner.set(owner, units2 = snapshot.units.filter((unit) => (isOpponent(owner, unit.owner) || unit.owner === "neutral") && unit.kind !== "worker"));
      return units2.slice();
    },
    playerUnits(owner, relation, kind) {
      const view = cachedPlayerView(owner, this)[relation];
      return (kind === "worker" ? view.workers : kind === "combat" ? view.combatUnits : view.units).slice();
    },
    playerBuildings(owner, relation, completeOnly) {
      const view = cachedPlayerView(owner, this)[relation];
      return (completeOnly ? view.completeBuildings : view.buildings).slice();
    },
    neutralUnitsFor(owner) {
      return cachedPlayerView(owner, this).neutral.units.slice();
    },
    forPlayer(owner) {
      const view = cachedPlayerView(owner, this);
      return {
        owner: view.owner,
        team: view.team,
        own: copyEntityView(view.own),
        allied: copyEntityView(view.allied),
        enemy: copyEntityView(view.enemy),
        neutral: { units: view.neutral.units.slice() },
        resources: entitySet(snapshot.resources),
        mercenaryCamps: entitySet(snapshot.mercenaryCamps),
        items: { ground: view.items.ground.slice(), carried: view.items.carried.slice() }
      };
    }
  };
}
function firstById(entities) {
  const byId = /* @__PURE__ */ new Map();
  for (const entity of entities) if (!byId.has(entity.id)) byId.set(entity.id, entity);
  return byId;
}
function playerEntityViews(snapshot, owner, ownTeam, teamFor) {
  const emptyView = () => ({ units: [], workers: [], combatUnits: [], buildings: [], completeBuildings: [] });
  const own = emptyView(), allied = emptyView(), enemy = emptyView();
  const neutral = [];
  const addUnit = (view, unit) => {
    view.units.push(unit);
    (unit.kind === "worker" ? view.workers : view.combatUnits).push(unit);
  };
  const addBuilding = (view, building) => {
    view.buildings.push(building);
    if (building.complete) view.completeBuildings.push(building);
  };
  snapshot.units.forEach((unit) => {
    const candidate = unit.owner;
    if (candidate === "neutral") neutral.push(unit);
    if (candidate === owner) addUnit(own, unit);
    if (candidate !== "neutral") {
      const team = teamFor(candidate);
      if (candidate !== owner && team === ownTeam) addUnit(allied, unit);
      if (team !== ownTeam) addUnit(enemy, unit);
    }
  });
  snapshot.buildings.forEach((building) => {
    const candidate = building.owner;
    if (candidate === owner) addBuilding(own, building);
    if (candidate !== "neutral") {
      const team = teamFor(candidate);
      if (candidate !== owner && team === ownTeam) addBuilding(allied, building);
      if (team !== ownTeam) addBuilding(enemy, building);
    }
  });
  return { own, allied, enemy, neutral: { units: neutral } };
}
function copyEntityView(view) {
  return {
    units: view.units.slice(),
    workers: view.workers.slice(),
    combatUnits: view.combatUnits.slice(),
    buildings: view.buildings.slice(),
    completeBuildings: view.completeBuildings.slice()
  };
}
function entitySet(all) {
  return {
    all,
    nearestTo(point) {
      return nearestEntity(all, point);
    }
  };
}
function nearestEntity(candidates, point) {
  return candidates.map((candidate) => ({ candidate, distance: distance(candidate, point) })).sort((a, b) => a.distance - b.distance)[0]?.candidate;
}
function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// src/ai/policy/ground.ts
function withoutShips(snapshot, units2) {
  return shipsAfloat(snapshot) ? units2.filter((unit) => unitMover(unit.kind) === "land" && !unit.deck) : units2;
}
var afloat = /* @__PURE__ */ new WeakMap();
function shipsAfloat(snapshot) {
  let known = afloat.get(snapshot);
  if (known === void 0) {
    known = snapshot.units.some((unit) => unitMover(unit.kind) === "sea");
    afloat.set(snapshot, known);
  }
  return known;
}

// src/ai/policy/snapshot.ts
var noTeamsQueryKey = {};
var snapshotQueryCache = /* @__PURE__ */ new WeakMap();
var budgetWorlds = /* @__PURE__ */ new WeakMap();
var lastQuery;
function aiSnapshotQuery(snapshot, teams) {
  const key = teams ?? noTeamsQueryKey;
  if (lastQuery && lastQuery.snapshot === snapshot && lastQuery.key === key) return lastQuery.query;
  let byTeams = snapshotQueryCache.get(snapshot);
  if (!byTeams) {
    byTeams = /* @__PURE__ */ new WeakMap();
    snapshotQueryCache.set(snapshot, byTeams);
  }
  let query = byTeams.get(key);
  if (!query) {
    const world = budgetWorlds.get(snapshot);
    if (teams && Object.entries(teams).every(([owner, team]) => owner === team)) query = aiSnapshotQuery(snapshot);
    else if (world) query = { ...aiSnapshotQuery(world, teams), snapshot };
    else query = createSnapshotQuery(snapshot, { ...teams ? { teams } : {}, excludeIssuedWeapons: true });
    byTeams.set(key, query);
  }
  lastQuery = { snapshot, key, query };
  return query;
}
function units(snapshot, owner) {
  return aiSnapshotQuery(snapshot).unitsFor(owner);
}
function neutralUnitsNear(snapshot, point, range) {
  return aiSnapshotQuery(snapshot).neutralUnitsNear(point, range);
}
function enemyCombatUnits(snapshot, owner, teams) {
  return withoutShips(snapshot, aiSnapshotQuery(snapshot, teams).playerUnits(owner, "enemy", "combat"));
}
function enemyUnitsNear(snapshot, owner, point, range, teams) {
  return aiSnapshotQuery(snapshot, teams).opponentUnitsNear(owner, point, range);
}

// src/ai/policy/ownership.ts
function isEnemyOwner(snapshot, owner, other, options) {
  if (other === "neutral") return true;
  return isOpponentOwner(snapshot, owner, other, options);
}
function isOpponentOwner(snapshot, owner, other, options) {
  if (other === "neutral") return false;
  return aiSnapshotQuery(snapshot, options.teams).isOpponent(owner, other);
}

// src/shared/mining.ts
var GOLD_MINE_RULES = {
  radius: 42,
  entryRange: 44,
  dropRange: 74,
  workstations: 5,
  // Standard worker budget; admission timing determines actual saturation.
  goldPerTrip: 10,
  // Keep the 400 gold/minute admission cap after shortening the hauling lane.
  // At a 216-unit hall distance, a 60-unit/s worker cycles in about 6.5s:
  // 3.2s working + 2 * (216 - 44 - 74) / 60 travelling. Five workers
  // saturate the 1.5s admission interval; a sixth can still help longer routes.
  gatherSeconds: 3.2,
  entrySeconds: 1.5,
  townHallDistance: 210,
  mainDistance: 216,
  baseRange: 320
};

// src/shared/build-placement.ts
var BUILDING_PLACEMENT_GAP = 4;
function buildingPlacementBlocker(snapshot, kind, point) {
  const radius = BUILDING_DEFS[kind].radius;
  const map = snapshot.map;
  let near = (body) => distance2(point, body) < radius + body.radius + BUILDING_PLACEMENT_GAP;
  if (map?.terrain) {
    const cell = map.terrain.cell;
    const at = snapToFootprint(map, radius, point);
    const own = footprintCells(cell, at.x, at.y, radius);
    near = (body) => {
      const other = footprintCells(cell, body.x, body.y, body.radius);
      return own.left <= other.right && other.left <= own.right && own.top <= other.bottom && other.top <= own.bottom;
    };
  }
  const blocker = snapshot.buildings.find(near) ?? snapshot.obstacles?.find(near);
  if (blocker) return blocker;
  return snapshot.resources?.find((resource) => resourceBlocksPlacement(map, kind, point, resource));
}
function resourceBlocksPlacement(map, kind, point, resource) {
  const radius = BUILDING_DEFS[kind].radius;
  const at = map ? snapToFootprint(map, radius, point) : point;
  if (kind === "townHall" && distance2(at, resource) < GOLD_MINE_RULES.townHallDistance) return true;
  const half = map?.terrain ? footprintHalf(radius, map.terrain.cell) : radius;
  const dx = Math.max(0, Math.abs(resource.x - at.x) - half);
  const dy = Math.max(0, Math.abs(resource.y - at.y) - half);
  return Math.hypot(dx, dy) < GOLD_MINE_RULES.radius + BUILDING_PLACEMENT_GAP;
}
function terrainBlocksPlacement(map, kind, point) {
  if (map === void 0) return false;
  const { radius, shore } = BUILDING_DEFS[kind];
  const at = snapToFootprint(map, radius, point);
  return shore ? !isShoreFootprint(map, at.x, at.y, radius) : !isFootprintBuildable(map, at.x, at.y, radius);
}
function isBuildPlacementClear(snapshot, kind, point) {
  return !terrainBlocksPlacement(snapshot.map, kind, point) && !buildingPlacementBlocker(snapshot, kind, point);
}
function distance2(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// src/shared/mining-site.ts
var candidatesByMap = /* @__PURE__ */ new WeakMap();
function miningHallSite(snapshot, mine, preferred = mine) {
  const radius = BUILDING_DEFS.townHall.radius;
  const cell = snapshot.map.terrain?.cell ?? 16;
  let cache = candidatesByMap.get(snapshot.map);
  if (!cache) {
    cache = /* @__PURE__ */ new Map();
    candidatesByMap.set(snapshot.map, cache);
  }
  const key = `${mine.x}:${mine.y}:${preferred.x}:${preferred.y}`;
  let points = cache.get(key);
  if (!points) {
    points = [];
    const center = snapToFootprint(snapshot.map, radius, mine);
    const steps = Math.ceil(300 / cell);
    for (let row = -steps; row <= steps; row++) {
      for (let col = -steps; col <= steps; col++) {
        const point = { x: center.x + col * cell, y: center.y + row * cell };
        if (Math.hypot(point.x - mine.x, point.y - mine.y) > 300) continue;
        if (point.x - radius < 0 || point.y - radius < 0 || point.x + radius > snapshot.map.width || point.y + radius > snapshot.map.height) continue;
        if (!isFootprintBuildable(snapshot.map, point.x, point.y, radius)) continue;
        if (resourceBlocksPlacement(snapshot.map, "townHall", point, mine)) continue;
        points.push(point);
      }
    }
    points.sort((a, b) => (a.x - preferred.x) ** 2 + (a.y - preferred.y) ** 2 - ((b.x - preferred.x) ** 2 + (b.y - preferred.y) ** 2));
    cache.set(key, points);
  }
  return points.find((point) => sameGround(snapshot.map, point, mine) && isBuildPlacementClear(snapshot, "townHall", point));
}

// src/shared/unit-lookup.ts
var LOOKUP_MAP_MIN_IDS = 8;
function ownUnitLookup(units2, owner, idCount) {
  if (idCount < LOOKUP_MAP_MIN_IDS) return (id) => units2.find((unit) => unit.id === id && unit.owner === owner);
  const byId = /* @__PURE__ */ new Map();
  for (const unit of units2) if (unit.owner === owner && !byId.has(unit.id)) byId.set(unit.id, unit);
  return (id) => byId.get(id);
}

// src/sdk/commands/intent.ts
function resolveSdkCommandIntent(snapshot, owner, intent, options = {}) {
  if (intent.type === "learnVeteranSkill") return { ...intent };
  if (intent.type === "move" || intent.type === "gatherArmy") return { type: "move", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "combat"), x: intent.x, y: intent.y };
  if (intent.type === "attackMove") return { type: "attackMove", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "combat"), x: intent.x, y: intent.y };
  if (intent.type === "focusFire") return { type: "attack", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "combat"), targetId: intent.targetId };
  if (intent.type === "focusFireNear") return { type: "attack", unitIds: selectedFocusFireNearUnitIds(snapshot, owner, intent.unitIds ?? "combat", intent.targetId, intent.joinRange ?? 95), targetId: intent.targetId };
  if (intent.type === "retreat") {
    const point = intent.x !== void 0 && intent.y !== void 0 ? { x: intent.x, y: intent.y } : retreatPoint(snapshot, owner);
    return { type: "move", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "combat"), x: point.x, y: point.y };
  }
  if (intent.type === "retreatWounded") {
    const point = intent.x !== void 0 && intent.y !== void 0 ? { x: intent.x, y: intent.y } : retreatPoint(snapshot, owner);
    return { type: "move", unitIds: selectedWoundedUnitIds(snapshot, owner, intent.unitIds ?? "combat", intent.hpRatio ?? 0.5), x: point.x, y: point.y };
  }
  if (intent.type === "mine") return { type: "mine", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "workers"), resourceId: intent.resourceId ?? nearestResourceId(snapshot, owner) };
  if (intent.type === "repair") return { type: "repair", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "workers"), buildingId: intent.buildingId };
  if (intent.type === "repairShip" || intent.type === "repairUnit") return { type: intent.type, unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "workers"), targetId: intent.targetId };
  if (intent.type === "expand") {
    const resource = expansionResource(snapshot, owner, intent.resourceId);
    const site = miningHallSite(snapshot, resource);
    if (!site) throw new Error(`No legal town hall site near ${resource.id}`);
    return { type: "build", unitId: intent.unitId ?? nearestWorkerId(snapshot, owner, site), buildingKind: "townHall", ...site };
  }
  if (intent.type === "creepCamp") {
    const point = creepCampPoint(snapshot, owner, intent.campId, options);
    return { type: "attackMove", unitIds: selectedUnitIds(snapshot, owner, intent.unitIds ?? "combat"), x: point.x, y: point.y };
  }
  if (intent.type === "build") return { type: "build", unitId: intent.unitId ?? nearestWorkerId(snapshot, owner, { x: intent.x, y: intent.y }), buildingKind: intent.buildingKind, x: intent.x, y: intent.y };
  if (intent.type === "train") return { type: "train", buildingId: intent.buildingId ?? trainingBuildingId(snapshot, owner, intent.unitKind), unitKind: intent.unitKind };
  if (intent.type === "research") return { type: "research", buildingId: intent.buildingId ?? researchBuildingId(snapshot, owner, intent.upgradeKind), upgradeKind: intent.upgradeKind };
  if (intent.type === "hire") return { type: "hire", campId: intent.campId };
  if (intent.type === "cast") return { type: "cast", unitId: intent.unitId ?? casterForAbility(snapshot, owner, intent.ability), ability: intent.ability, ...intent.targetId ? { targetId: intent.targetId } : {}, ...intent.x !== void 0 ? { x: intent.x } : {}, ...intent.y !== void 0 ? { y: intent.y } : {} };
  if (intent.type === "pickupItem") return { type: "pickupItem", unitId: intent.unitId ?? carrierForItem(snapshot, owner, intent.itemId), itemId: intent.itemId };
  if (intent.type === "useItem") return { type: "useItem", unitId: intent.unitId ?? carrierForItem(snapshot, owner, intent.itemId), itemId: intent.itemId, ...intent.targetId ? { targetId: intent.targetId } : {}, ...intent.x !== void 0 ? { x: intent.x } : {}, ...intent.y !== void 0 ? { y: intent.y } : {} };
  return assertNever(intent);
}
function selectedUnitIds(snapshot, owner, selector) {
  if (Array.isArray(selector)) {
    const ownUnit = ownUnitLookup(snapshot.units, owner, selector.length);
    for (const id of selector) {
      const unit = ownUnit(id);
      if (!unit) throw new Error(`Unknown ${owner} unit ${id}`);
    }
    return selector;
  }
  const units2 = snapshot.units.filter((unit) => unit.owner === owner && matchesSelector(unit, selector));
  if (units2.length === 0) throw new Error(`No ${owner} units match selector ${selector}`);
  return units2.map((unit) => unit.id);
}
function selectedWoundedUnitIds(snapshot, owner, selector, hpRatio) {
  if (!Number.isFinite(hpRatio) || hpRatio <= 0 || hpRatio > 1) throw new Error(`retreatWounded hpRatio must be within (0, 1], got ${hpRatio}`);
  const selected = new Set(selectedUnitIds(snapshot, owner, selector));
  const wounded = snapshot.units.filter((unit) => selected.has(unit.id) && unit.hp / unit.maxHp <= hpRatio);
  if (wounded.length === 0) throw new Error(`No ${owner} wounded units match selector ${selector} at hp ratio ${hpRatio}`);
  return wounded.map((unit) => unit.id);
}
function selectedFocusFireNearUnitIds(snapshot, owner, selector, targetId, joinRange) {
  if (!Number.isFinite(joinRange) || joinRange < 0) throw new Error(`focusFireNear joinRange must be a non-negative finite number, got ${joinRange}`);
  const target = snapshot.units.find((unit) => unit.id === targetId) ?? snapshot.buildings.find((building) => building.id === targetId);
  if (!target) throw new Error(`Unknown focus target ${targetId}`);
  const selected = new Set(selectedUnitIds(snapshot, owner, selector));
  const joiners = snapshot.units.filter((unit) => selected.has(unit.id) && distance3(unit, target) <= unit.attackRange + unit.radius + ("radius" in target ? target.radius : 0) + joinRange);
  if (joiners.length === 0) throw new Error(`No ${owner} units near enough to focus ${targetId}`);
  return joiners.map((unit) => unit.id);
}
function controlledPoint(snapshot, owner) {
  return armyCenter(snapshot.units.filter((unit) => unit.owner === owner && unit.kind !== "worker")) ?? retreatPoint(snapshot, owner);
}
function matchesSelector(unit, selector) {
  if (selector === "all") return true;
  if (selector === "combat") return unit.kind !== "worker";
  if (selector === "workers") return unit.kind === "worker";
  return assertNever(selector);
}
function retreatPoint(snapshot, owner) {
  return baseCenter(snapshot.buildings.filter((building) => building.owner === owner)) ?? armyCenter(snapshot.units.filter((unit) => unit.owner === owner)) ?? { x: snapshot.map.width / 2, y: snapshot.map.height / 2 };
}
function nearestResourceId(snapshot, owner) {
  const point = retreatPoint(snapshot, owner);
  const resource = nearest(snapshot.resources, point);
  if (!resource) throw new Error("No resources exist in this command intent context");
  return resource.id;
}
function expansionResource(snapshot, owner, resourceId) {
  if (resourceId) {
    const resource2 = snapshot.resources.find((candidate) => candidate.id === resourceId);
    if (!resource2) throw new Error(`Unknown resource ${resourceId}`);
    return resource2;
  }
  const ownedBases = snapshot.buildings.filter((building) => building.owner === owner && building.kind === "townHall");
  const resource = snapshot.resources.filter((candidate) => !ownedBases.some((base) => distance3(base, candidate) <= 300)).map((candidate) => ({ candidate, distance: distance3(candidate, retreatPoint(snapshot, owner)) })).sort((a, b) => a.distance - b.distance)[0]?.candidate;
  if (!resource) throw new Error(`No expansion resource available for ${owner}`);
  return resource;
}
function creepCampPoint(snapshot, owner, campId, options) {
  if (campId) {
    const query = createSnapshotQuery(snapshot, options);
    const camp2 = query.mercenaryCampById(campId);
    if (camp2) return { x: camp2.x, y: camp2.y };
    const neutral = query.unitById(campId);
    if (neutral?.owner === "neutral") return { x: neutral.x, y: neutral.y };
    throw new Error(`Unknown creep camp ${campId}`);
  }
  const point = controlledPoint(snapshot, owner);
  const camp = nearest(snapshot.mercenaryCamps, point) ?? nearest(snapshot.units.filter((unit) => unit.owner === "neutral"), point);
  if (!camp) throw new Error("No creep camp target exists in this command intent context");
  return { x: camp.x, y: camp.y };
}
function nearestWorkerId(snapshot, owner, point) {
  const workers = snapshot.units.filter((unit) => unit.owner === owner && unit.kind === "worker");
  const worker = nearest(workers.filter(isAvailableBuilder), point) ?? nearest(workers, point);
  if (!worker) throw new Error(`No ${owner} workers available`);
  return worker.id;
}
function isAvailableBuilder(unit) {
  return unit.order.type === "idle" || unit.order.type === "mine";
}
function trainingBuildingId(snapshot, owner, unitKind) {
  const building = snapshot.buildings.find((candidate) => candidate.owner === owner && candidate.complete && BUILDING_DEFS[candidate.kind].trains.includes(unitKind));
  if (!building) throw new Error(`No ${owner} complete building can train ${unitKind}`);
  return building.id;
}
function researchBuildingId(snapshot, owner, upgradeKind) {
  const building = snapshot.buildings.find((candidate) => candidate.owner === owner && candidate.complete && BUILDING_DEFS[candidate.kind].researches.includes(upgradeKind));
  if (!building) throw new Error(`No ${owner} complete building can research ${upgradeKind}`);
  return building.id;
}
function carrierForItem(snapshot, owner, itemId) {
  const item = snapshot.items.find((candidate) => candidate.id === itemId);
  if (!item) throw new Error(`Unknown item ${itemId}`);
  if (item.carrierId && snapshot.units.some((unit2) => unit2.id === item.carrierId && unit2.owner === owner)) return item.carrierId;
  const unit = nearest(snapshot.units.filter((candidate) => candidate.owner === owner), item);
  if (!unit) throw new Error(`No ${owner} units available to use ${itemId}`);
  return unit.id;
}
function casterForAbility(snapshot, owner, ability) {
  const unit = snapshot.units.find((candidate) => candidate.owner === owner && candidate.hp > 0 && unitAbilities(candidate).includes(ability));
  if (!unit) throw new Error(`No ${owner} unit can cast ${ability}`);
  return unit.id;
}
function armyCenter(units2) {
  if (units2.length === 0) return void 0;
  return { x: average(units2.map((unit) => unit.x)), y: average(units2.map((unit) => unit.y)) };
}
function baseCenter(buildings2) {
  const bases = buildings2.filter((building) => building.kind === "townHall");
  return armyCenter(bases.length > 0 ? bases : buildings2);
}
function nearest(candidates, point) {
  return candidates.map((candidate) => ({ candidate, distance: distance3(candidate, point) })).sort((a, b) => a.distance - b.distance)[0]?.candidate;
}
function distance3(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
function average(values) {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function assertNever(value) {
  throw new Error(`Unhandled SDK command intent ${JSON.stringify(value)}`);
}

// src/ai/policy/commands.ts
function resolveAiCommandIntent(snapshot, owner, intent, options) {
  return resolveSdkCommandIntent(snapshot, owner, intent, options.teams ? { teams: options.teams } : {});
}

// src/ai/policy/claims.ts
var OBJECTIVE_ABANDON_GRACE_TICKS = 300;
function activeUnitClaim(snapshot, owner, unit, options) {
  const claim = options.memory?.unitClaims[unit.id];
  if (!claim || claim.expiresTick < snapshot.tick || unit.owner !== owner) return void 0;
  if (objectiveClaimAbandoned(unit, claim, snapshot.tick)) return void 0;
  return claimTargetExists(aiSnapshotQuery(snapshot), owner, claim) ? claim : void 0;
}
function objectiveClaimAbandoned(unit, claim, currentTick) {
  if (claim.kind !== "creep" && claim.kind !== "mercenary" && claim.kind !== "expansion") return false;
  if (currentTick < claim.sinceTick + OBJECTIVE_ABANDON_GRACE_TICKS) return false;
  if (unit.order.type !== "idle") return false;
  if (claim.kind === "mercenary" && distance4(unit, claim) <= 220) return true;
  return distance4(unit, claim) > 260;
}
function claimTargetExists(query, owner, claim) {
  if (claim.kind === "mercenary") return Boolean(query.mercenaryCampById(claim.targetId));
  if (claim.kind === "expansion") return expansionClaimStillNeedsArmy(query, owner, claim);
  if (claim.kind === "creep") return Boolean(query.unitById(claim.targetId));
  if (claim.kind === "harass") return Boolean(query.targetById(claim.targetId));
  if (claim.kind === "build") return query.unitsFor(owner).some((unit) => unit.order.type === "build" && distance4(unit.order, claim) <= 80) || claim.sinceTick >= query.snapshot.tick || query.buildingsFor(owner).some((building) => !building.complete && distance4(building, claim) <= 80);
  return true;
}
function expansionClaimStillNeedsArmy(query, owner, claim) {
  const resource = query.resourceById(claim.targetId);
  if (!resource) return false;
  return !query.buildings().some((building) => building.owner === owner && building.kind === "townHall" && distance4(building, resource) <= GOLD_MINE_RULES.baseRange);
}
function distance4(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// src/ai/policy/versions.ts
function isV5HybridPolicy(options) {
  return options.requestedVersion === "v5" || options.requestedVersion === "v6" || options.requestedVersion === "v7" || options.requestedVersion === "v8" || options.requestedVersion === "v9";
}
function isV6Policy(options) {
  return options.requestedVersion === "v6" || options.requestedVersion === "v7" || options.requestedVersion === "v8" || options.requestedVersion === "v9";
}
function isV7Policy(options) {
  return options.requestedVersion === "v7" || options.requestedVersion === "v8" || options.requestedVersion === "v9";
}
function isV8Policy(options) {
  return options.requestedVersion === "v8" || options.requestedVersion === "v9";
}
var SHOOTER_UNIT_KINDS = /* @__PURE__ */ new Set(["archer", "horseArcher", "sparkArcher", "contractArcher"]);
var SUMMONING_UNIT_KINDS = new Set(
  Object.keys(UNIT_DEFS).filter((kind) => UNIT_DEFS[kind].abilities.some((ability) => ABILITY_DEFS[ability].behavior === "summon"))
);
var V8_FORBIDDEN_UNIT_KINDS = /* @__PURE__ */ new Set([...SHOOTER_UNIT_KINDS, ...SUMMONING_UNIT_KINDS]);

// src/ai/policy/spatial.ts
function nearestEntity2(entities, from) {
  let nearest2, gap = Infinity;
  entities.forEach((entity) => {
    const next = distance5(entity, from);
    if (nearest2 === void 0 || next < gap) {
      nearest2 = entity;
      gap = next;
    }
  });
  return nearest2;
}
function averagePoint(points) {
  const total = { x: 0, y: 0 };
  points.forEach((point) => {
    total.x += point.x / points.length;
    total.y += point.y / points.length;
  });
  return total;
}
function distance5(a, b) {
  return hypot2(a.x - b.x, a.y - b.y);
}
var RANGE_GRID_MIN_ITEMS = 32;
function anyWithinRangeOf(items, range) {
  const near = (item, point) => !(distance5(item, point) > range);
  if (items.length < RANGE_GRID_MIN_ITEMS) return (point) => items.some((item) => near(item, point));
  const cell = range + 1;
  let grid;
  return (point) => {
    const cx = Math.floor(point.x / cell);
    const cy = Math.floor(point.y / cell);
    if (!Number.isFinite(cx) || !Number.isFinite(cy)) return items.some((item) => near(item, point));
    grid ??= pointGrid(items, (item) => item, cell);
    for (let x = cx - 1; x <= cx + 1; x += 1) {
      for (let y = cy - 1; y <= cy + 1; y += 1) {
        if (grid.cells.get(gridCellKey(x, y))?.some((item) => near(item, point))) return true;
      }
    }
    return grid.offGrid.some((item) => near(item, point));
  };
}
function pointGrid(entries, at, cell) {
  const cells = /* @__PURE__ */ new Map();
  const offGrid = [];
  for (const entry of entries) {
    const x = Math.floor(at(entry).x / cell);
    const y = Math.floor(at(entry).y / cell);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      offGrid.push(entry);
      continue;
    }
    const key = gridCellKey(x, y);
    const bucket = cells.get(key);
    if (bucket) bucket.push(entry);
    else cells.set(key, [entry]);
  }
  return { cells, offGrid };
}
function gridCellKey(x, y) {
  return x * 4096 + y;
}

// src/ai/policy/threats.ts
function nearestEnemyUnit(snapshot, owner, from, range, options) {
  return nearestEntity2([...enemyUnitsNear(snapshot, owner, from, range, options.teams), ...neutralUnitsNear(snapshot, from, range)], from);
}

// src/shared/equipment.ts
var ITEM_DEFS = {
  shipCannon: { hands: 2, mass: SHIP_WEAPONS.shipCannon.mass, span: 4, passive: true },
  shipMortar: { hands: 2, mass: SHIP_WEAPONS.shipMortar.mass, span: 4, passive: true },
  flameProjector: { hands: 2, mass: SHIP_WEAPONS.flameProjector.mass, span: 4, passive: true },
  issuedWeapon: { hands: 1, mass: 4, passive: true },
  flameCloak: { slot: "body", mass: 3, passive: true },
  speedBoots: { slot: "feet", mass: 2, passive: true },
  regenRing: { slot: "head", mass: 1, passive: true },
  leatherArmor: { slot: "body", mass: 8, protection: 0.08, passive: true },
  roundShield: { hands: 1, mass: 5, protection: 0.12, passive: true },
  greatSword: { hands: 2, mass: 6, weapon: { damage: 22, range: 48, cooldown: seconds(1.8) }, passive: true },
  lightningRod: { hands: 1, mass: 3 },
  stormStaff: { hands: 2, mass: 5 },
  guardianScroll: { hands: 1, mass: 0.3 },
  healingScroll: { hands: 1, mass: 0.3 },
  experienceBook: { hands: 1, mass: 1 },
  breachCharge: { hands: 1, mass: 6 },
  ivoryTower: { hands: 1, mass: 2 }
};

// src/ai/policy/v6/strength.ts
var CASTER_STRENGTH = { summoner: 0.6, priest: 0.8, fieldMedic: 0.9, witch: 0.9, ashHexer: 0.9 };
var FOOTMAN_RATING = Math.sqrt(UNIT_DEFS.footman.hp * (UNIT_DEFS.footman.attackDamage / (UNIT_DEFS.footman.attackCooldown / SIM_TICKS_PER_SECOND)));
function unitStrength(unit) {
  if (unit.kind === "worker") return 0;
  const cost = UNIT_DEFS[unit.kind].cost;
  const base = CASTER_STRENGTH[unit.kind] ?? (cost > 0 ? cost / 100 : void 0) ?? Math.sqrt(unit.maxHp * (unit.attackDamage / Math.max(1, unit.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
  return base * Math.max(0.1, unit.hp / Math.max(1, unit.maxHp)) * (1 + VETERANCY_GAIN_PER_STAR * unit.level) * (UNIT_DEFS[unit.kind].threat ?? 1);
}
var SPIRIT_STRENGTH = Math.sqrt(UNIT_DEFS.spirit.hp * (UNIT_DEFS.spirit.attackDamage / (UNIT_DEFS.spirit.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
var SUMMON = ABILITY_DEFS.summon;
var SPIRITS_PER_CASTER = SUMMON.behavior === "summon" ? SUMMON.summonDuration / SUMMON.cooldown : 1;

// src/ai/policy/spell-tactics.ts
function clusteredWeaponScore(_snapshot, _caster, def, targets, target) {
  return targets.filter((other) => distance5(other, target) < (def.weapon.radius ?? 80)).length + (!("order" in target) ? (def.weapon.buildingMultiplier ?? 1) * 2 : target.attackDamage / 15);
}
function planAbilityCommands(snapshot, owner, options) {
  return planAbilityCommandsWithWeaponScore(snapshot, owner, options, clusteredWeaponScore);
}
function planAbilityCommandsWithWeaponScore(snapshot, owner, options, scoreWeaponTarget) {
  const commands = [];
  const cursed = /* @__PURE__ */ new Set();
  let enemyWithin620;
  const regroupPointHasEnemy = (point) => (enemyWithin620 ??= anyWithinRangeOf(enemyCombatUnits(snapshot, owner, options.teams), 620))(point);
  for (const caster of (globalThis.__privateCasterSubset ?? units(snapshot, owner)).filter(canCast)) {
    if (caster.order.type === "board") continue;
    const abilities = UNIT_DEFS[caster.kind].abilities.filter((ability) => abilityCooldown(caster, ability) <= 0);
    for (const ability of abilities) {
      const def = ABILITY_DEFS[ability];
      if (def.behavior !== "weapon" || abilityCooldown(caster, ability) > 0) continue;
      const targets = [...snapshot.units, ...snapshot.buildings].filter((target2) => (!("order" in target2) || matchesUnitTarget(target2, def.targets, snapshot)) && isEnemyOwner(snapshot, owner, target2.owner, options) && distance5(caster, target2) <= def.range + target2.radius && distance5(caster, target2) >= (def.weapon.minRange ?? 0));
      const target = targets.map((target2) => ({ target: target2, score: scoreWeaponTarget(snapshot, caster, def, targets, target2) })).sort((a, b) => b.score - a.score || distance5(caster, a.target) - distance5(caster, b.target))[0]?.target;
      if (target) commands.push(def.target === "point" ? { type: "cast", unitId: caster.id, ability, x: target.x, y: target.y } : { type: "cast", unitId: caster.id, ability, targetId: target.id });
    }
    const healAbility = abilities.find((ability) => ABILITY_DEFS[ability].behavior === "heal");
    if (healAbility) {
      const def = ABILITY_DEFS[healAbility];
      const target = (isV8Policy(options) && def.behavior === "heal" ? v8HealTarget(snapshot, owner, caster, def, options) : void 0) ?? healTarget(snapshot, owner, caster, def.plannerRange, options, def.targets);
      if (target) {
        commands.push(resolveAiCommandIntent(snapshot, owner, { type: "cast", unitId: caster.id, ability: healAbility, targetId: target.id }, options));
        continue;
      }
      const regroup = healerRegroupCommand(snapshot, owner, caster, def.plannerRange, regroupPointHasEnemy, options, def.targets);
      if (regroup) {
        commands.push(regroup);
        continue;
      }
    }
    const summonAbility = abilities.find((ability) => ABILITY_DEFS[ability].behavior === "summon");
    if (summonAbility) {
      const def = ABILITY_DEFS[summonAbility];
      const target = nearestEnemyUnit(snapshot, owner, caster, def.plannerRange, options);
      const hasSpirit = units(snapshot, owner).some((unit) => unit.kind === "spirit" && distance5(unit, caster) < 320);
      const holding = isV6Policy(options) && options.memory?.v6?.general?.stage === "gather" && options.memory.v6.general.mode === "attack" && !nearestEnemyUnit(snapshot, owner, caster, 400, options);
      if (!holding && (isV6Policy(options) || target && !hasSpirit)) {
        const point = isV6Policy(options) ? v6SummonPoint(snapshot, owner, caster, def.plannerRange, options) : { x: caster.x + 54, y: caster.y + 28 };
        if (point) {
          commands.push(resolveAiCommandIntent(snapshot, owner, { type: "cast", unitId: caster.id, ability: summonAbility, x: point.x, y: point.y }, options));
          continue;
        }
      }
    }
    const curseAbility = abilities.find((ability) => ABILITY_DEFS[ability].behavior === "curse");
    if (curseAbility) {
      const def = ABILITY_DEFS[curseAbility];
      if (def.behavior !== "curse") continue;
      const target = curseTarget(snapshot, owner, caster, def, options, cursed);
      if (target) {
        cursed.add(target.id);
        commands.push(resolveAiCommandIntent(snapshot, owner, { type: "cast", unitId: caster.id, ability: curseAbility, targetId: target.id }, options));
      }
    }
  }
  return commands;
}
function healingAllies(snapshot, owner, options, targets) {
  return (isV5HybridPolicy(options) ? snapshot.units.filter((unit) => !isEnemyOwner(snapshot, owner, unit.owner, options)) : units(snapshot, owner)).filter((unit) => canReceiveHealing(unit, snapshot) && matchesUnitTarget(unit, targets, snapshot));
}
function healTarget(snapshot, owner, caster, healRange, options, targets) {
  return healingAllies(snapshot, owner, options, targets).filter((unit) => unit.hp < unit.maxHp * 0.7 && distance5(unit, caster) <= healRange).sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp || b.maxHp - b.hp - (a.maxHp - a.hp) || distance5(a, caster) - distance5(b, caster))[0];
}
function v8HealTarget(snapshot, owner, caster, def, options) {
  let best;
  let bestPriority = 0;
  for (const unit of healingAllies(snapshot, owner, options, def.targets)) {
    if (unit.kind === "worker" || unit.maxHp - unit.hp < def.healAmount / 2 || distance5(unit, caster) > def.plannerRange) continue;
    const priority = unitStrength({ ...unit, hp: unit.maxHp }) * (1 - unit.hp / unit.maxHp);
    if (priority > bestPriority) {
      best = unit;
      bestPriority = priority;
    }
  }
  return best;
}
function healerRegroupCommand(snapshot, owner, caster, healRange, enemyNear, options, targets) {
  if (options.version !== "v2" || activeUnitClaim(snapshot, owner, caster, options)) return void 0;
  const wounded = units(snapshot, owner).filter((unit) => canReceiveHealing(unit, snapshot) && matchesUnitTarget(unit, targets, snapshot) && unit.id !== caster.id && unit.kind !== "worker" && unit.hp < unit.maxHp * 0.7 && distance5(unit, caster) > healRange && distance5(unit, caster) <= 1400);
  const groups = wounded.map((anchor) => wounded.filter((unit) => distance5(unit, anchor) <= 260)).filter((group) => group.length >= 2).map((group) => ({ group, point: averagePoint(group) })).filter(({ point }) => !enemyNear(point) && neutralUnitsNear(snapshot, point, 420).length === 0).sort((a, b) => b.group.length - a.group.length || distance5(caster, a.point) - distance5(caster, b.point));
  const target = groups[0]?.point;
  if (!target || !healerRegroupOrderCanMove(caster, target)) return void 0;
  return resolveAiCommandIntent(snapshot, owner, { type: "move", unitIds: [caster.id], x: target.x, y: target.y }, options);
}
function healerRegroupOrderCanMove(caster, target) {
  if (caster.order.type === "idle") return true;
  return caster.order.type === "move" && distance5(caster.order, target) > 180;
}
function curseTarget(snapshot, owner, caster, def, options, cursed) {
  const candidates = [...enemyUnitsNear(snapshot, owner, caster, def.plannerRange, options.teams), ...neutralUnitsNear(snapshot, caster, def.plannerRange)].filter((target) => !cursed.has(target.id) && matchesUnitTarget(target, def.targets, snapshot) && !target.effects.some((effect) => effect.type === def.statusType));
  const summoned = def.summonedDamage && isV7Policy(options) ? candidates.filter((target) => target.expiresTick !== void 0).sort((a, b) => distance5(a, caster) - distance5(b, caster))[0] : void 0;
  if (summoned) return summoned;
  if (isV6Policy(options)) return candidates.sort((a, b) => damagePerSecond(b) - damagePerSecond(a) || distance5(a, caster) - distance5(b, caster))[0];
  if (def.scorchedDamageMultiplier !== void 0) {
    const scorched = candidates.filter((target) => target.effects.some((effect) => effect.type === "scorch")).sort((a, b) => distance5(a, caster) - distance5(b, caster))[0];
    if (scorched) return scorched;
  }
  return candidates.sort((a, b) => distance5(a, caster) - distance5(b, caster))[0];
}
function v6SummonPoint(snapshot, owner, caster, reach, options) {
  const spirits = units(snapshot, owner).filter((unit) => unit.kind === "spirit" && distance5(unit, caster) <= 700);
  const toward = nearestEnemyUnit(snapshot, owner, caster, 900, options) ?? (spirits.length > 0 ? averagePoint(spirits) : void 0);
  const gap = toward ? distance5(caster, toward) : 0;
  const point = toward && gap >= 1 ? { x: caster.x + (toward.x - caster.x) / gap * Math.min(reach, gap), y: caster.y + (toward.y - caster.y) / gap * Math.min(reach, gap) } : { x: caster.x + 54, y: caster.y + 28 };
  return Array.from({ length: 13 }, (_, index) => ({
    x: caster.x + (point.x - caster.x) * (12 - index) / 12,
    y: caster.y + (point.y - caster.y) * (12 - index) / 12
  })).find((at) => caster.deck || isWalkable(snapshot.map, at.x, at.y) && sameGround(snapshot.map, caster, at));
}
function damagePerSecond(unit) {
  return unit.attackDamage / Math.max(1, unit.attackCooldown);
}
export {
  planAbilityCommands
};
