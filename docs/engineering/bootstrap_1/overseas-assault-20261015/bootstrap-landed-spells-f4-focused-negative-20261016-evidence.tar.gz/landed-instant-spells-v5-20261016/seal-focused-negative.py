from pathlib import Path
from collections import Counter
import gzip,json,hashlib,datetime,tarfile,io
D=Path(__file__).resolve().parent;O=Path('/tmp/landed-instant-spells-v5-normal-217800-20261016');A=Path('/workspace/.playtest/bootstrap-landed-spells-f4-focused-negative-20261016-evidence.tar.gz');delivery=A.with_name('bootstrap-landed-spells-f4-focused-negative-20261016-delivery.json')
assert not A.exists() and not delivery.exists()
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
cap=json.loads((D/'fixed-runtime.json').read_text());report=json.loads((O/'report.json').read_text());final=json.loads(gzip.decompress((O/'final.json.gz').read_bytes()));initial=json.loads(gzip.decompress(Path(cap['inputPath']).read_bytes()));end=report['end'];ids=set(cap['observedCrewIds']);hulls={u['id']:u for u in initial['snapshot']['units']if u['owner']=='p0'and u.get('sailing')}
assert report['observationStopped'] and report['winner']is None and not report['naturalComplete']
assert not report['sourcePost']['changed'] and not report['sourcePost']['status'] and not report['frozenPost']['changed']
assert digest(O/'final.json.gz')==report['finalSHA256']
events=[]
with gzip.open(O/'events.jsonl.gz','rt')as f:
 for line in f:events.append(json.loads(line))
terminal=[e for e in events if e['type']=='native-unit-terminal'and e['permanent']];removed={e['previous']['id']for e in events if e['type']=='unit-removal'and e['stage']=='after-step'}
confirmed=[e for e in terminal if e['id']in removed];unconfirmed=[e['id']for e in terminal if e['id']not in removed]
tail={};lastenemy=None;lastneutral=None
for name in ['commands','hits','events','think-inputs']:
 rows=[]
 with gzip.open(O/f'{name}.jsonl.gz','rt')as f:
  for line in f:
   r=json.loads(line)
   if end-15<=r['tick']<end:rows.append(r)
   if name=='hits'and r['attackerOwner']=='p0':
    if r['targetOwner']in ['p1','p2']:lastenemy=r
    elif r['targetOwner']=='neutral':lastneutral=r
 tail[name]=rows
fullpre=sorted(int(p.name.split('-')[0])for p in(O/'frames').glob('*-before-p0.json.gz'))
audit={'classification':'Supported focused negative continuation; no natural result or fresh0/milestone','head':cap['head'],'start':report['start'],'end':end,'winner':report['winner'],'counts':report['counts'],'finalSHA256':report['finalSHA256'],'restore':report['restore'],'sourcePre':report['sourcePre'],'sourcePost':report['sourcePost'],'frozenPre':report['frozenPre'],'frozenPost':report['frozenPost'],'confirmedNativePermanentTerminalsByObservedOwner':dict(Counter((e.get('atObservation')or e['previous'])['owner']for e in confirmed)),'unconfirmedPermanentTerminalIds':unconfirmed,'cohort27ConfirmedDead':len([e for e in confirmed if e['id']in ids]),'initialHullHistory':{id:{'initial':u,'events':[e for e in events if e['type']=='owner-change'and e['before']['id']==id or e['type']=='native-unit-terminal'and e['id']==id],'final':next((x for x in final['snapshot']['units']if x['id']==id),None)}for id,u in hulls.items()},'finalLivingPermanentKindsByOwner':{owner:dict(Counter(u['kind']for u in final['snapshot']['units']if u['owner']==owner and u['hp']>0and'expiresTick'not in u))for owner in cap['agents']},'finalLivingBuildingsByOwner':dict(Counter(b['owner']for b in final['snapshot']['buildings']if b['hp']>0)),'goldInitial':initial['snapshot']['players']['p0']['gold'],'goldFinal':final['snapshot']['players']['p0']['gold'],'nativeCumulativeStatsFinal':final['snapshot']['match']['stats'],'cumulativeStatsScope':'Includes original-prefix statistics and temporary units; do not equate with new confirmed permanent terminal ledger. A captured hull is not a P0 death until observed as such; history keeps ownership.','lastActualEnemyDirectedHit':lastenemy,'lastActualNeutralHit':lastneutral,'last15':tail,'lastFullBeforeP0':max(fullpre),'lastThinkFullCaptured':end-15in fullpre,'lastThinkGap':'All before-P0 input hashes exist, but after219000 fullbeforeP0 onlyevery600. Missing last-think world is not backfilled. No new end-window Game/cold was run.','stopRequest':report['stopRequest'],'limits':'Actual later destruction/income/capture/continued movement retained; observation stop does not prove global frozen/infinite/physical defeat. Original container uncommitted gap remains.'}
(D/'final-native-case-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
capsule=json.loads((D/'source-capsule.json').read_text());frozen=Path(capsule['frozen']['path']);assert digest(frozen)==capsule['frozen']['sha256'];assert digest(Path(capsule['sourceArchive']['path']))==capsule['sourceArchive']['sha256']
payload=[]
for root,prefix in[(D,'landed-instant-spells-v5-20261016'),(O,'landed-instant-spells-v5-normal')]:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if p.is_file()and not p.is_symlink()and not any(part in ['node_modules','runtime-tmp','__pycache__']for part in rel.parts):payload.append((p,prefix+'/'+rel.as_posix()))
payload.extend([(frozen,'source/original-frozen497.tar.gz'),(Path(cap['inputPath']),'source/original-fd217800-complete.json.gz')])
entries={name:{'sourcePath':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}for p,name in payload};assert len(entries)==len(payload)
index={'classification':'Immutable actual fixedf4 focused negative, source-qualified and not natural outcome','payload':len(entries),'entries':entries};indexraw=(json.dumps(index,indent=2)+'\n').encode();indexname='INDEX.json'
with tarfile.open(A,'w:gz',compresslevel=6)as archive:
 for p,name in payload:archive.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo(indexname);info.size=len(indexraw);archive.addfile(info,io.BytesIO(indexraw))
seen=set();indexseen=False
with tarfile.open(A,'r|gz')as archive:
 for m in archive:
  assert m.isfile()
  f=archive.extractfile(m);h=hashlib.sha256();size=0
  for block in iter(lambda:f.read(1<<20),b''):h.update(block);size+=len(block)
  if m.name==indexname:assert h.hexdigest()==hashlib.sha256(indexraw).hexdigest()and size==len(indexraw);indexseen=True
  else:
   assert m.name not in seen and m.name in entries;assert size==entries[m.name]['bytes']and h.hexdigest()==entries[m.name]['sha256'];seen.add(m.name)
assert seen==set(entries)and indexseen
changed=[str(p)for p,name in payload if p.stat().st_size!=entries[name]['bytes']or digest(p)!=entries[name]['sha256']];assert not changed
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(A),'bytes':A.stat().st_size,'sha256':digest(A),'payload':len(entries),'regularIncludingIndex':len(entries)+1,'indexSHA256':hashlib.sha256(indexraw).hexdigest(),'allPayloadBytesHashesAndCoverageVerified':True,'originalsChanged':changed,'sourceHead':cap['head'],'sourceFiles':len(cap['hashes']),'rulesVersion':2,'frozenRuntimeManifest184PrePost':True,'historicalFrozen497ArchiveIncluded':True,'start':report['start'],'end':end,'winner':None,'naturalComplete':False,'classification':'Supported finite focused negative; not normal0, win, naturaldefeat, or completedbootstrap','sourceDirSealed':str(D),'normalOutputDirSealed':str(O),'readme':'landed-instant-spells-v5-20261016/README.final-focused-negative.zh.md','knownBaseline1bArchive':{'path':'/tmp/bootstrap-landed-ground-1b-complete-negative-20261016-evidence.tar.gz','bytes':85947709,'sha256':'e42d9b5dd61a2044601131415c4e84f8f9c572f1fcc3d88c438ef3abaaeaef2f'},'auditSummary':{'cohort27ConfirmedDead':audit['cohort27ConfirmedDead'],'confirmedPermanentByObservedOwner':audit['confirmedNativePermanentTerminalsByObservedOwner'],'unconfirmed':unconfirmed,'lastFullBeforeP0':audit['lastFullBeforeP0'],'lastThinkFullCaptured':audit['lastThinkFullCaptured']}}
delivery.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
