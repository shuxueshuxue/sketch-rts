import datetime, json, os, pathlib, subprocess, sys, time
D=pathlib.Path(__file__).resolve().parent
cap=json.loads((D/'fixed-runtime.json').read_text())
S=pathlib.Path(cap['sourceRoot']); O=pathlib.Path(cap['nativeOutputRoot'])
assert not O.exists(), 'Do not restart or overwrite an existing ordinary continuation'
cgroup=pathlib.Path('/sys/fs/cgroup')
limit=int((cgroup/'memory.max').read_text());current=int((cgroup/'memory.current').read_text())
guard={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':limit,'current':current,
       'headroom':limit-current,'required':2<<30,'heapMiB':768,'head':cap['head'],
       'classification':'One fixed v5 normal3AI continuation from actualfd217800, no human commands/notfresh0',
       'oomBefore':(cgroup/'memory.events').read_text()}
if limit-current<2<<30:
    guard['exit']=75
    (D/f'prepared-only-launch-guard-{time.time_ns()}.json').write_text(json.dumps(guard,indent=2)+'\n')
    print(json.dumps(guard));sys.exit(75)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['head']
temp=D/'runtime-tmp';temp.mkdir(exist_ok=True)
environment={**os.environ,'TMPDIR':str(temp)}
command=['node','--max-old-space-size=768','--import','tsx',str(D/'native-normal-from217800.ts')]
with (D/'native-normal-launch.log').open('w') as output:
    child=subprocess.Popen(command,cwd=S,env=environment,stdout=output,stderr=subprocess.STDOUT)
    guard.update(pid=child.pid,argv=command,TMPDIR=str(temp),actualProcessStarted=True,
                 processStartedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    receipt=D/f'actual-process-launch-{child.pid}.json'
    receipt.write_text(json.dumps(guard,indent=2)+'\n')
    print(json.dumps(guard),flush=True)
    status=child.wait()
guard.update(exit=status,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             oomAfter=(cgroup/'memory.events').read_text())
receipt.write_text(json.dumps(guard,indent=2)+'\n')
print(json.dumps({'pid':child.pid,'exit':status,'endedAtUtc':guard['endedAtUtc']}),flush=True)
sys.exit(status)
