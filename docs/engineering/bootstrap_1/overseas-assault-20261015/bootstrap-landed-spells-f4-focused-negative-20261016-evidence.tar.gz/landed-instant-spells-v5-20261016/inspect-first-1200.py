"""Read only an already complete first1200 checkpoint and bounded raw prefixes.

This is an observer report, not a replay or proof of equivalence. Commands at
the end tick belong to the next think and are excluded. Native after-step
observations at that tick are included; no later after-command row is included.
"""
from pathlib import Path
from collections import Counter
import gzip, hashlib, json

D = Path(__file__).resolve().parent
cap = json.loads((D / 'fixed-runtime.json').read_text())
O = Path(cap['nativeOutputRoot'])
end = cap['start'] + 1200
frame_path = O / 'frames' / f'{end}-complete-periodic-after-step.json.gz'
frame_raw = frame_path.read_bytes()
frame = json.loads(gzip.decompress(frame_raw))
assert frame['snapshot']['tick'] == end
crew = set(cap['observedCrewIds'])

def prefix(name):
    with gzip.open(O / f'{name}.jsonl.gz', 'rt') as source:
        for line in source:
            row = json.loads(line)
            if row['tick'] > end:
                break
            if row['tick'] == end and (name in ['commands', 'effects', 'think-inputs'] or row.get('stage') != 'after-step'):
                continue
            yield row

commands = list(prefix('commands'))
hits = list(prefix('hits'))
events = list(prefix('events'))
effects = list(prefix('effects'))
terminals = [e for e in events if e['type'] == 'native-unit-terminal' and e['permanent']]
cohort_casts = [r for r in commands if r['command']['type'] == 'cast' and r['command']['unitId'] in crew]
cohort_effects = [r for r in effects if r['command']['type'] == 'cast' and r['command']['unitId'] in crew]
unit_by_id = {u['id']: u for u in frame['snapshot']['units']}
cohort_dead = [e for e in terminals if e['id'] in crew]
survivors = [unit_by_id[i] for i in cap['observedCrewIds'] if i in unit_by_id and unit_by_id[i]['hp'] > 0]
births = [e for e in events if e['type'] == 'unit-birth-observed']
reboards = [e for e in events if e['type'] == 'observed-parent-change' and e['after']['id'] in crew and e['after'].get('deck')]
report = {
    'classification': 'First1200 read-only ledger; not native replay, fresh0, or whole-match result',
    'head': cap['head'], 'start': cap['start'], 'end': end,
    'frame': {'path': str(frame_path), 'bytes': len(frame_raw), 'sha256': hashlib.sha256(frame_raw).hexdigest(), 'stage': frame['checkpointStage']},
    'boundary': 'Commands/effects/hits strictly before end; terminal/birth native after-step observations at end included; later think/commands excluded.',
    'winnerAtFrame': frame['snapshot']['match']['winner'],
    'commands': len(commands), 'hits': len(hits),
    'cohort': {'initial': len(crew), 'alive': len(survivors), 'permanentTerminal': len(cohort_dead), 'reboardObservations': len(reboards),
               'survivors': survivors, 'permanentTerminals': cohort_dead},
    'allOwnerPermanentTerminals': dict(Counter((e.get('atObservation') or e['previous'])['owner'] for e in terminals)),
    'cohortPublicCasts': cohort_casts,
    'cohortActualCommandEffects': [{'tick': r['tick'], 'commandIndex': r['commandIndex'], 'command': r['command'], 'legalityBefore': r['legalityBefore'],
                                   'newNativeEffects': r['newNativeEffects'], 'newUnits': r['newUnits']} for r in cohort_effects],
    'observedBirthsByOwnerKind': dict(Counter(f"{e['unit']['owner']}:{e['unit']['kind']}" for e in births)),
    'prior1bScope': 'Separate fixed1b from same217800 input: all27 cohort died by218677 with0reboards. No equivalence to this candidate is asserted.',
    'remainingLimits': 'Public-command effect rows do not include native autocasts during steps. Birth ledger includes them but does not by itself identify their caster. No full replay has been run by this report.'
}
target = D / 'first1200-readonly-ledger.json'
assert not target.exists(), 'Keep prior reports immutable'
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'end': end,
                  'cohortAlive': len(survivors), 'cohortDead': len(cohort_dead), 'reboards': len(reboards),
                  'publicCasts': len(cohort_casts), 'nativeBirths': report['observedBirthsByOwnerKind']}, indent=2))
