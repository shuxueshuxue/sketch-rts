# v4 安全部队等待反证

来自 v3 89641 实际首次安全登陆的完整 world/nextId/双方 memories；完整双方 AI 正常继续至 94000。没有手工指令、重登岛或恢复已取消 intent。不是普通开局、不是独立新比赛、未验收。

v4 在已有 naval owner 预留安全首批陆军并 hold，原 required 与取消均保留；危险、敌方在飞弹、治疗与保护中的行动交还原 micro。等待未使第二艘船及时部署，89805 已取消，不能并入生产。

94000 精确分组：{'currentDeck': 0, 'currentGroundOnTarget': 0, 'currentElsewhere': 12, 'dead': 17}。曾登陆 15，敌楼 20，主厅 900，winner=None。source pre/postflight 均真。6 项新增测试、20 项关联回归和 tsc 最终通过。早期工具启动与测试脚手架可选字段错误日志保留，不作因果证据。

来源为规则2基线183b + v3 + 当前存档源码，不声称恢复原容器未提交修改；冻结 manifest184件已重新验证。
