# Actual yaw and native worker transfer waiting

Independent worktree: `/workspace/sketch-rts-service-yaw-control`, base
`97c7fca95e76da7e9767b87d7858138ecb3a18ec`. It never modifies the running
ordinary source, root economy work, the sailing wind extraction, main, or the
separate rules-3/performance work. The original container's uncommitted gap
remains unavailable.

## What was proved

The actual ordinary-opening tick39600 world and both policy memories come from
`archer-portrait-ordinary.json` / `.json.frames/39600.json`. Its original fixed
portrait runtime has **834** listed hashes, not 1361. Every listed original
hash matched before and after the diagnostics. Normal resources/population and
rules2 remain unchanged.

Warship1064 and target1127 have usable, touching decks and no actual translation
or rotation. Source1064 nevertheless retains `yawRate=.23412897530169097`, so
the physical seam query rejects its engineer1833. The fixed original source
was tested separately with native continuation, public Stop, public Board,
Stop+Board (300ticks each), and complete p0 planning at the original 15tick
cadence for1800ticks. None clears the stale rate or completes repair. These are
short mechanism branches: the opponent's existing native orders continue;
they do not run new opponent AI decisions and are not full-match scores.

`bootstrap-ship-yaw-boundary.patch` records actual angular displacement at the
same completed-tick boundary that already records velocityX/Y. It also preserves
real in-place weapon rotation: the old engine rotates -.01513566rad/tick while
its saved point velocity says zero; the candidate records the actual nonzero
rotation. It does not grant workers Hold Position or relax seam safety.

Yaw alone is insufficient. From39600→41400 the engineer moves along its deck,
but still cannot cross; cabin128 remains unrepaired. The existing yield selector
accepts a priest goal using only static deck clearance and reuses a saved goal
without checking its live route. An archer blocks that priest; the priest blocks
the engineer. Live deck-path checks, including saved goals, allow the existing
worker retreat sequence to run. The41400 derived sample then completes in115ticks.

Applying those two corrections from the earlier actual39600 world exposes one
more public-command mismatch: Hold Position explicitly ignores workers, so its
queued hold is absent and the queued Board restarts before the priest moves.
That candidate's600tick regression failure is retained, not hidden as success.

The final policy preserves the same boarding queue and lets only a worker
follow its actual source hull while waiting. That is an existing legal command;
the existing native follow stopping distance is extracted unchanged and reused
by the planner. Ordinary healer/formation follows, follows of a different hull,
nonworker follows, and follows without a queued Board are not claimed as this
waiting task. No new task memory or ownership layer is introduced.

From the original39600 full world, the final complete p0 planner issues nine
public entries and finishes at**39730**: engineer1833 is really on1127, then
idle, target cabin128→186, `shipNeedsRepair=false`, cumulative p0 loss remains0,
gold107.91→61.95. At39630 it is actually waiting in the source-hull Follow order,
then receives Board after clearance; at39675 it receives Repair Ship. No private
world fields or body positions are changed by the diagnostic.

## Source, restore and checks

`final-candidate-source.json` / `.tar.gz` freeze839 source/config/fixture files
before the final native probe. Their postflight records all839 unchanged. The
original ordinary source also stays unchanged. Earlier source capsules are
retained for the yaw-only and intermediate live-yield failures.

The actual39600 and yaw-only41400 regression cases execute complete public
planner entries against independently JSON-restored snapshot+nextId+both
memories. A third branch is restored while the worker is actually following its
source with the queued boarding task. All subsequent command lists, complete
worlds, nextId and memories agree through real transfer and completed repair.

- Original yaw regression:5 meaningful failures recorded before the engine fix.
- Final related regression:38 tests pass (actual service/restore, native yaw,
  existing deck transfer, crowded shore transfer, and all three bootstrap
  families'24 ferry return/summons cases).
- Earlier74 native motion/steering/collision/crossing tests pass after the yaw
  fix. Final follow-distance extraction preserves the old native expression.
- Final `tsc --noEmit` and `git diff --check` pass.

The synthetic rotation test's original restore initially omitted the authored
`scriptedVictory` setting, which is not in a snapshot. That test setup was
corrected before the green runs; the original pre-probe capsule is retained and
its test file is not imported by the native probe.

## Remaining coastal case

The separate fixed coastal-v3 tick178800 sample is not a yaw failure: native
transfer is already allowed. Its two ballistas jointly block the worker; removing
either one alone in a pure query does not clear the path. No executable repair
sequence has been established for that case. Single-hull fit and connected
surface support are different queries, so the old ballista's single-hull fit
failure is not labelled a corrupted world. The recorded4px endpoint searches do
not prove continuous impossibility. Both v3 and the later v4 samples remain
unresolved and are not credited to this fix.

This packet establishes an actual local service repair and restores it exactly.
It is not an ordinary-opening victory, a complete match, generalization evidence,
or bootstrap acceptance. Root owns subsequent complete normal-AI validation.
