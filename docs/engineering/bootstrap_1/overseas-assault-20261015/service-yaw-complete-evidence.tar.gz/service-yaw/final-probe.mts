import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
const args = process.argv.slice(2), wd = args[0] ?? '/workspace/sketch-rts-portrait-endgame-control';
const label = args[1] ?? 'original', root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const out = `/tmp/bootstrap-service-yaw-${label}`; mkdirSync(out, { recursive: true });
const imp = (path: string) => import(pathToFileURL(`${wd}/${path}`).href);
const [{createGame,restoreSnapshotIntoGame,snapshotGame,stepGame,issuePlayerCommand},{decksCanTransfer,decksSupportCrossing,connectedSurfacePath},{shipNeedsRepair},{planAiOwnerCommandEntries}] = await Promise.all([
  imp('src/shared/sim.ts'),imp('src/shared/connected-decks.ts'),imp('src/shared/ship-equipment.ts'),imp('src/ai/planner-context.ts')]);
const manifestPath = root + '/archer-portrait-ordinary-runtime-source.json', source = JSON.parse(readFileSync(manifestPath, 'utf8'));
const verify = () => Object.entries(source.runtimeHashes).filter(([path, hash]) => createHash('sha256').update(readFileSync('/workspace/sketch-rts-portrait-endgame-control/' + path)).digest('hex') !== hash).map(([path]) => path);
assert.deepEqual(verify(), []);
const framePath = root + '/archer-portrait-ordinary.json.frames/39600.json', raw = readFileSync(framePath), frame = JSON.parse(raw.toString());
const row = JSON.parse(readFileSync(root + '/archer-portrait-ordinary.json', 'utf8')).rows.find((row: any) => row.tick === 39600);
const memories = Object.fromEntries(Object.entries(row.players).map(([owner, player]: any) => [owner, player.policy]));
const variants = ['public-normal-planner'];
const results = [];
for (const variant of variants) {
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, frame.snapshot, frame.nextId);
  assert.deepEqual(JSON.parse(JSON.stringify(snapshotGame(game))), frame.snapshot); assert.equal(game.nextId, frame.nextId);
  const savedMemory = structuredClone(memories), sourceShip = game.units.find((unit: any) => unit.id === 'unit-p0-warship-1064')!, target = game.units.find((unit: any) => unit.id === 'unit-p0-warship-1127')!, worker = game.units.find((unit: any) => unit.id === 'unit-p0-worker-1833')!;
  const issued: any[] = [], samples: any[] = [];
  const issue = (command: any, scriptId = 'native-diagnostic') => { issued.push({ tick: game.tick, scriptId, command }); issuePlayerCommand(game, 'p0', command); };
  const sample = () => ({ tick: game.tick, source: {x:sourceShip.x,y:sourceShip.y,heading:sourceShip.sailing.heading,speed:sourceShip.sailing.speed,yawRate:sourceShip.sailing.yawRate,velocityX:sourceShip.sailing.velocityX,velocityY:sourceShip.sailing.velocityY,order:structuredClone(sourceShip.order)}, target:{x:target.x,y:target.y,heading:target.sailing.heading,speed:target.sailing.speed,yawRate:target.sailing.yawRate,order:structuredClone(target.order),parts:structuredClone(target.shipParts)}, worker:{x:worker.x,y:worker.y,deck:structuredClone(worker.deck),order:structuredClone(worker.order)},supported:decksSupportCrossing(sourceShip,target,worker),canTransfer:decksCanTransfer(sourceShip,target,worker),path:connectedSurfacePath(worker,target,game.units,game.map),needsRepair:shipNeedsRepair(game,target),gold:game.players.p0.gold,lost:game.match.stats.unitsLost.p0});
  samples.push(sample());
  if (variant.includes('stop')) issue({type:'stop',unitIds:[sourceShip.id,target.id]});
  if (variant.includes('board')) issue({type:'board',unitIds:[worker.id],transportId:target.id});
  const duration = variant === 'public-normal-planner' ? 1200 : 300;
  for (let tick = 0; tick < duration; tick++) {
    if (variant === 'public-normal-planner' && game.tick % 15 === 0) for (const entry of planAiOwnerCommandEntries(snapshotGame(game), {playerId:'p0',version:'v9_archer',memory:savedMemory.p0}, {teams:game.teams})) issue(entry.command,entry.scriptId);
    stepGame(game);
    if (variant === 'public-normal-planner' && worker.deck?.shipId === target.id && !shipNeedsRepair(game,target)) { samples.push(sample()); break; }
    if (tick < 4 || game.tick % 30 === 0 || tick === duration - 1) samples.push(sample());
  }
  const result = {variant,source:wd,label,start:frame.snapshot.tick,end:game.tick,issued,samples}; results.push(result);
  writeFileSync(out + `/${variant}.json`,JSON.stringify(result,null,2)+'\n');
  writeFileSync(out + `/${variant}-final.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:savedMemory})+'\n');
}
assert.deepEqual(verify(), []);
writeFileSync(out+'/provenance.json',JSON.stringify({classification:'Isolated public-command/native short diagnostic from actual ordinary opening39600 fullworld+both memories; normal planner branch uses p0 full planner, no private state edits. Not a full-match score.',fixedOriginalManifest:manifestPath,fixedOriginalRuntimeHashesVerified:Object.keys(source.runtimeHashes).length,originalSourceStableBeforeAfter:true,framePath,frameSha256:createHash('sha256').update(raw).digest('hex'),runtime:wd,label},null,2)+'\n');
console.log(JSON.stringify(results.map(result=>({variant:result.variant,final:result.samples.at(-1),issued:result.issued.length})),null,2));
