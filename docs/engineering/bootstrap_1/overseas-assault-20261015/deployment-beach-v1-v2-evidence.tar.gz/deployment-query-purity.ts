import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
const art = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const configs = [
 { name: 'query-once', wd: '/workspace/sketch-rts-deployment-beach-v1-control', source: 'deployment-beach-v1-source.json', extraQuery: false },
 { name: 'query-twice-reset-memory', wd: '/workspace/sketch-rts-deployment-beach-v1-control', source: 'deployment-beach-v1-source.json', extraQuery: true },
];
const inputPath = join(art, 'archer-assault-contact-replay.frames/before-think-88110.json');
const raw = readFileSync(inputPath), input = JSON.parse(raw.toString());
const copy = (value: any) => JSON.parse(JSON.stringify(value));
const hash = (path: string) => createHash('sha256').update(readFileSync(path)).digest('hex');
const reports: any[] = [];
for (const config of configs) {
  const sourcePath = join(art, config.source), source = JSON.parse(readFileSync(sourcePath, 'utf8'));
  const sourceExact = () => Object.entries(source.files).every(([path, sha]) => hash(join(config.wd, path)) === sha);
  if (!sourceExact()) throw Error('Source drift ' + config.name);
  const imp = (path: string) => import(pathToFileURL(join(config.wd, path)).href);
  const [{ bootstrapMatches, bootstrapGame }, { runAiGameLoop }, { createAiMemoryProvider },
    { createBootstrapCommandPlanner }, { restoreSnapshotIntoGame, snapshotGame }] = await Promise.all([
    imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/ai/game-runner.ts'), imp('src/ai/planner-context.ts'),
    imp('scripts/bootstrap_1-planner.ts'), imp('src/shared/sim.ts'),
  ]);
  const end = 88230;
  const match = bootstrapMatches('bootstrap_1-development', ['sapphireArchipelago'], end, false).find((match: any) =>
    match.subject === 'v9_archer' && match.side === 0 && match.agents.p0.race === 'grove'
    && Object.values(match.agents).slice(1).map((agent: any) => agent.version).join('+') === 'v5');
  const game = bootstrapGame(match), memories = createAiMemoryProvider();
  restoreSnapshotIntoGame(game, copy(input.snapshot), input.nextId);
  for (const [owner, memory] of Object.entries(input.memories)) memories.set(owner, copy(memory));
  if (!isDeepStrictEqual(copy(snapshotGame(game)), input.snapshot)) throw Error('World restore');
  if (game.nextId !== input.nextId || !Object.keys(match.agents).every(owner => isDeepStrictEqual(memories.get(owner), input.memories[owner]))) throw Error('Memory restore');
  const [{reviseAssaultBeaches},{bootstrapPolicyContext}] = await Promise.all([imp('src/ai/bootstrap_1/assault-beach.ts'), imp('src/ai/bootstrap_1/policy.ts')]);
  const planner = await createBootstrapCommandPlanner(memories), commands: any[] = [], hits: any[] = [], checkpoints: any[] = [];
  const directory = join(art, `deployment-query-purity-${config.name}.frames`); mkdirSync(directory, { recursive: true });
  const capture = (label: string) => {
    const frame = { tick: game.tick, snapshot: snapshotGame(game), nextId: game.nextId,
      memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner)])) };
    const path = join(directory, label + '.json'); writeFileSync(path, JSON.stringify(frame) + '\n');
    checkpoints.push({ tick: game.tick, label, path });
  };
  game.observer = { hit: (a: any, t: any, damage: number, hpBefore: number) => hits.push({ tick: game.tick, sourceId: a.id, targetId: t.id, damage, hpBefore }) };
  capture('start');
  runAiGameLoop({ ...match, game, commandPlanner: (context: any) => {
    if (context.owner === 'p0') capture('before-think-' + context.snapshot.tick);
    if (config.extraQuery && context.owner === 'p0' && context.snapshot.tick === input.tick) {
      const before = copy(memories.get('p0'));
      reviseAssaultBeaches(context.snapshot, 'p0', bootstrapPolicyContext(context.snapshot, 'p0', 'v9_archer', {memory:memories.get('p0'), teams:context.teams}));
      memories.set('p0', before);
    }
    return planner(context);
  } }, { onCommand: ({ tick, owner, scriptId, command }: any) => commands.push({ tick, owner, scriptId, command: copy(command) }),
    onStep: () => { if (game.tick <= input.tick + 2 || game.tick % 15 === 0 || game.tick % 15 === 1) capture('after-native-' + game.tick); } });
  if (!sourceExact()) throw Error('Source changed ' + config.name);
  reports.push({ ...config, sourceManifest: sourcePath, sourceManifestSha256: hash(sourcePath), sourceUnchanged: true, checkpoints, commands, hits });
}
const a = reports[0], b = reports[1];
const ships = ['unit-p0-carrier-3510', 'unit-p0-carrier-3824'];
const comparable = a.checkpoints.filter((c: any) => c.label.startsWith('after-native-')).map((c: any) => {
  const other = b.checkpoints.find((o: any) => o.label === c.label), left = JSON.parse(readFileSync(c.path, 'utf8')), right = JSON.parse(readFileSync(other.path, 'utf8'));
  return { tick: c.tick, fullWorldEqual: isDeepStrictEqual(left.snapshot, right.snapshot),
    ferryUnitsEqual: isDeepStrictEqual(left.snapshot.units.filter((u: any) => ships.includes(u.id)), right.snapshot.units.filter((u: any) => ships.includes(u.id))),
    ferryPositionEqual: ships.every(id => { const x = left.snapshot.units.find((u: any) => u.id === id), y = right.snapshot.units.find((u: any) => u.id === id); return x.x === y.x && x.y === y.y; }),
    nextIdEqual: left.nextId === right.nextId };
});
const out = { classification: 'Actual full normal both-AI short causal replay, original 88110 complete input restored. No manual commands, no source edits during runs. All historical fields are cloned or written complete to disk.', inputPath, inputSha256: createHash('sha256').update(raw).digest('hex'), reports, comparable };
writeFileSync(join(art, 'deployment-query-purity.json'), JSON.stringify(out, null, 2) + '\n');
console.log(JSON.stringify(comparable));
