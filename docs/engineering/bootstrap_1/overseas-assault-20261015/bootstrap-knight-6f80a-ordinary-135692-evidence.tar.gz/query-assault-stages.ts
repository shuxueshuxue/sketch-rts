import{readFileSync,writeFileSync}from'node:fs';
import{pathToFileURL}from'node:url';
const prefix=process.argv[2],source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const mod=(path:string)=>import(pathToFileURL(source+'/src/'+path+'.ts').href);
const {reviseAssaultBeaches,assaultBeachBodies,assaultBeachExposure,orderBootstrapAssaultLanding}=await mod('ai/bootstrap_1/assault-beach');
const {assaultExpedition,cancelFerry,planNavalTacticsWithAssignments}=await mod('ai/policy/naval');
const {planRiderCrossing,riderFerryCrew}=await mod('ai/bootstrap_1/rider-crossing');
const {mountedMinePlan}=await mod('ai/policy/mounted-mine-plan');
const {transportRecovery,transportNeedsRecovery}=await mod('ai/bootstrap_1/transport-recovery');
const {landRecoveryAssignments,mainlandCareAssignments}=await mod('ai/bootstrap_1/land-recovery');
const {expeditionDeparture}=await mod('ai/bootstrap_1/expedition-departure');
const {planShoreTransfers}=await mod('ai/bootstrap_1/shore-transfer');
const {sameGround,walkingDistance,setBuildingBodies}=await mod('shared/terrain');
const {shipPassengers}=await mod('shared/ship-geometry');
const {isInCabin}=await mod('shared/ship-cabin');
const {unitMover}=await mod('shared/catalog');
const {effectiveCombatRating}=await mod('ai/policy/v6/strength');
const data=JSON.parse(readFileSync(prefix+'-actual-naval-boundaries.json','utf8'));
const clone=(x:any)=>structuredClone(x),dist=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
const result:any[]=[];
for(const point of data.result){
 const f=JSON.parse(readFileSync(point.input,'utf8')),s=f.snapshot,owner='p0',o=clone(point.boundary.before);
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 function metrics(){
  const fs=o.memory.naval?.ferries??{},own=s.units.filter((u:any)=>u.owner===owner);
  return Object.entries(fs).filter(([,m]:any)=>m.purpose==='assault').map(([id,m]:any)=>{
   const b=own.find((u:any)=>u.id===id),target=s.buildings.find((x:any)=>x.id===m.targetId);if(!b||!target)return {id,missing:true};
   const crew=(ship:any)=>shipPassengers(s.units,ship).filter((u:any)=>u.kind!=='worker'&&!u.expiresTick);
   const power=(u:any[])=>u.reduce((n:any,u:any)=>n+effectiveCombatRating(s,u),0);
   const landed=own.filter((u:any)=>!u.deck&&unitMover(u.kind)==='land'&&u.kind!=='worker'&&!u.expiresTick&&sameGround(s.map,u,target));
   const ships=own.filter((u:any)=>fs[u.id]?.purpose==='assault'&&fs[u.id]?.targetId===m.targetId);
   const nearby=ships.filter((ship:any)=>fs[ship.id].phase!=='return'&&(ship.id===id||dist(b,ship)<=450&&(walkingDistance(s.map,ship,b,'sea')??Infinity)<=450));
   const incoming=ships.filter((ship:any)=>fs[ship.id].phase==='sailing'&&sameGround(s.map,b,ship,'sea'));
   const pack=(current:boolean)=>{const v=assaultBeachExposure(s,owner,o,b,m.to,target,current);return v?{pose:v.pose,passengers:v.landed.map((u:any)=>({id:u.id,x:u.x,y:u.y})),guards:v.guards.map((g:any)=>({id:g.id,kind:g.kind,x:g.x,y:g.y}))}:{undefined:true};};
   return {id,xy:[b.x,b.y],order:b.order,motion:b.sailing,mission:clone(m),required:assaultExpedition(s,owner,o,target).required,nearby450Power:power(nearby.flatMap(crew))+power(landed),nearby450ShipIds:nearby.map((x:any)=>x.id),incomingSailingPower:power(incoming.flatMap(crew))+power(landed),allGroupPassengerPower:power(ships.flatMap(crew)),landedPower:power(landed),otherShips:ships.map((ship:any)=>({id:ship.id,phase:fs[ship.id].phase,direct:dist(b,ship),seaRoad:walkingDistance(s.map,b,ship,'sea'),passengers:shipPassengers(s.units,ship).map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,cabin:isInCabin(u),expiresTick:u.expiresTick,power:effectiveCombatRating(s,u)}))})),plannedPlacement:pack(false),currentPlacement:pack(true)};
  });
 }
 const beforeRevise=metrics();reviseAssaultBeaches(s,owner,o);const afterRevise=metrics();
 // Mechanically mirror only the unchanged exported prelude of planBootstrapNaval.
 // The native script-stack boundary file is the authority; equivalence below
 // checks this observer staging rather than assuming it matches production.
 planRiderCrossing(s,owner,o);
 const ferries=o.memory.naval?.ferries;if(ferries)for(const boat of s.units.filter((u:any)=>u.owner===owner)){
  const m=ferries[boat.id];if(m?.purpose==='rebase'&&m.phase!=='return'&&s.resources.some((x:any)=>x.id===m.targetId&&x.amount===0))cancelFerry(s,boat,m,o);
 }
 const mines=mountedMinePlan(s,o.memory),ports=transportRecovery(s,owner,o),home=s.buildings.find((b:any)=>b.owner===owner&&b.kind==='townHall');
 const landed=s.units.filter((u:any)=>u.owner===owner&&!u.deck&&unitMover(u.kind)==='land'&&u.kind!=='worker'&&u.order.type!=='board'&&home&&!sameGround(s.map,u,home));
 const {recovering,unmedicated,posts}=landRecoveryAssignments(s,owner,o,landed),medics=new Set(recovering.map(({healer}:any)=>healer.id));
 const departing=expeditionDeparture(s,owner,o,ports.ids,new Set([...recovering.map(({patient}:any)=>patient.id),...unmedicated.map(({patient}:any)=>patient.id),...posts.map(({patient}:any)=>patient.id),...medics]));
 const reserved=new Set([...recovering.map(({patient}:any)=>patient.id),...unmedicated.map(({patient}:any)=>patient.id),...posts.map(({patient}:any)=>patient.id),...medics,...ports.ids,...departing.ids]);
 const mounted=new Set(o.memory.mounted?.flatMap((j:any)=>j.unitIds)),mainland=mainlandCareAssignments(s,owner,o);
 const mainlandCare=new Set([...(mainland?.unmedicated??[]).map(({patient}:any)=>patient.id),...(mainland?.recovering??[]).flatMap(({patient,healer}:any)=>[patient.id,healer.id])]);
 planShoreTransfers(s,owner,o);const beforeNavalAssembly=metrics(),callbacks:any[]=[];
 const commands=planNavalTacticsWithAssignments(s,owner,o,{orderAssaultLanding:(boat:any,goal:any,ordinary:any)=>{
  const before=metrics();const commands=orderBootstrapAssaultLanding(s,owner,o,boat,goal,ordinary);callbacks.push({boatId:boat.id,goal,ordinary,before,after:metrics(),commands});return commands;
 },orderCrew:(soldiers:any,shore:any,boat:any)=>riderFerryCrew(s,soldiers,shore,boat,o),mineEligible:mines.eligible,targetAvailable:mines.targetAvailable,transportReady:(b:any)=>!transportNeedsRecovery(s,b),troopAvailable:(u:any)=>!mounted.has(u.id)&&!reserved.has(u.id)&&!mainlandCare.has(u.id)});
 const ids=new Set(['unit-p0-carrier-4595','unit-p0-transport-1046','unit-p0-carrier-4699']);
 const relevant=(c:any)=>c.unitIds?.some((id:string)=>ids.has(id))||ids.has(c.transportId);
 const expected=point.boundary.rawCommands.filter(relevant),actual=commands.filter(relevant);
 result.push({tick:point.tick,beforeRevise,afterRevise,beforeNavalAssembly,callbacks,assemblyCommands:commands,proof:{trackedRawCommandsEqual:JSON.stringify(actual)===JSON.stringify(expected),ferriesAfterAssemblyEqual:JSON.stringify(o.memory.naval?.ferries)===JSON.stringify(point.boundary.after.memory.naval?.ferries)}});
}
writeFileSync(prefix+'-assault-stage-queries.json',JSON.stringify({classification:'Read-only staged queries from exact native naval.run contexts; production source unchanged. Exported prelude is mechanically mirrored only in this observer, with explicit comparisons to the actual whole native script-stack result. Metrics queries do not issue commands.',source,result})+'\n');console.log(JSON.stringify(result.map(r=>({tick:r.tick,proof:r.proof,callbacks:r.callbacks.map((c:any)=>({boatId:c.boatId,commands:c.commands}))}))));
