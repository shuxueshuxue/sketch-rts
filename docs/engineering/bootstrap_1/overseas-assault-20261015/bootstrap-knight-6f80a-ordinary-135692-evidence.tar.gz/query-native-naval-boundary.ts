import {readFileSync,writeFileSync,readdirSync}from'node:fs';
import {pathToFileURL}from'node:url';
const prefix=process.argv[2],source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const {bootstrapScripts}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/policy.ts').href);
const {planAiOwnerCommandEntries,createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const dir=prefix+'-assault-55200-56400-v2-inputs';
const result:any[]=[];
for(const name of readdirSync(dir).filter(n=>n.endsWith('.json')).sort()){
 const f=JSON.parse(readFileSync(dir+'/'+name,'utf8'));let boundary:any;
 const provider=createAiMemoryProvider(structuredClone(f.memories));
 const scripts=bootstrapScripts('v9_knight').map((script:any)=>script.id==='naval'?{...script,run:(snapshot:any,owner:any,options:any)=>{
  const before=JSON.parse(JSON.stringify(options));const commands=script.run(snapshot,owner,options);
  boundary={before,after:JSON.parse(JSON.stringify(options)),rawCommands:structuredClone(commands)};return commands;
 }}:script);
 const entries=planAiOwnerCommandEntries(f.snapshot,{playerId:'p0',version:'v9_knight',scripts},{teams:f.snapshot.teams,memoryProvider:provider});
 result.push({tick:f.snapshot.tick,input:dir+'/'+name,boundary,publicEntries:entries,p0MemoryAfter:provider.get('p0')});
}
const out=prefix+'-actual-naval-boundaries.json';writeFileSync(out,JSON.stringify({classification:'Read-only full native script-stack query with the exact native naval script wrapped only to record its actual input/output. All commands are returned unchanged; no simulation or manual command injection.',source,result})+'\n');console.log(JSON.stringify({out,ticks:result.map(r=>r.tick)}));
