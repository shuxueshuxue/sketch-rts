"""Read-only verification/summary for an ordinary run prepared by the fixed-source tool."""
import argparse, collections, hashlib, json, pathlib, subprocess
from datetime import datetime, timezone

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--prefix', required=True)
p.add_argument('--exit-code', type=int)
args = p.parse_args()
prefix = pathlib.Path(args.prefix).resolve()
capsule = json.loads(pathlib.Path(str(prefix)+'-runtime-source.json').read_text())
source = pathlib.Path(capsule['sourceRoot'])
report_path = pathlib.Path(str(prefix)+'.json')
report = json.loads(report_path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
hashes = {**capsule['runtimeHashes'], **capsule['supportingDataHashes']}
mismatches = []
for name, expected in hashes.items():
    path = source/name
    actual = sha(path.read_bytes()) if path.is_file() else None
    if actual != expected: mismatches.append({'path':name,'expected':expected,'actual':actual})
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
status = subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=source,text=True)
assert head == capsule['baseCommit'], (head,capsule['baseCommit'])
assert not status and not mismatches, {'status':status,'mismatches':mismatches}
manifest = source/'docs/engineering/bootstrap_1/frozen-policy.json'
assert sha(manifest.read_bytes()) == capsule['frozenManifestSha256']
opening = json.loads(pathlib.Path(capsule['openingPath']).read_text())
assert all(player['gold']==500 and player['supplyUsed']==3 and player['supplyCap']==8 for player in opening['initial'].values())
owners = list(report['setup']['agents'])
frames = pathlib.Path(str(prefix)+'.json.frames')
verified = []
summaries = []
for row in report['rows']:
    tick = row['tick']; frame_path = frames/f'{tick}.json'
    frame = json.loads(frame_path.read_text()); snapshot = frame['snapshot']
    assert snapshot['tick'] == tick and isinstance(frame['nextId'],int)
    assert list(row['players']) == owners
    assert all(isinstance(row['players'][owner]['policy'],dict) for owner in owners)
    verified.append({'tick':tick,'worldSHA256':sha(frame_path.read_bytes()),'memorySHA256':sha(json.dumps({owner:row['players'][owner]['policy'] for owner in owners},separators=(',',':'),sort_keys=True).encode())})
    summaries.append({'tick':tick,'winner':snapshot['match'].get('winner'), 'players':{owner:{
      'gold':snapshot['players'][owner]['gold'],
      'supply':snapshot['players'][owner]['supplyUsed'],
      'cap':snapshot['players'][owner]['supplyCap'],
      'units':dict(collections.Counter(u['kind'] for u in snapshot['units'] if u['owner']==owner)),
      'buildings':dict(collections.Counter(b['kind'] for b in snapshot['buildings'] if b['owner']==owner)),
      'halls':[{'id':b['id'],'hp':b['hp'],'x':b['x'],'y':b['y']} for b in snapshot['buildings'] if b['owner']==owner and b['kind']=='townHall'],
      'naval':row['players'][owner]['policy'].get('naval',{})
    } for owner in owners}})
terminal_path = frames/f"{report['result']['tick']}.json"
terminal = json.loads(terminal_path.read_text())['snapshot']
value = {'checkedAtUtc':datetime.now(timezone.utc).isoformat(),
 'classification':'Actual unmodified inspect ordinary tick0 run, with independent prelaunch factory witness; no resume or manual commands.',
 'processExitCode':args.exit_code,'baseCommit':head,'sourceRoot':str(source),
 'result':report['result'],'nativeMatch':terminal['match'],
 'setup':report['setup'],'actualMapId':terminal['map']['id'],
 'openingInitial':opening['initial'],'sourceFileCount':len(hashes),'sourceMismatches':mismatches,
 'frozenManifestSHA256':sha(manifest.read_bytes()),'verifiedCheckpointCount':len(verified),
 'checkpoints':verified,'terminalNextId':json.loads(terminal_path.read_text())['nextId'],
 'remaining':{owner:{'units':sum(u['owner']==owner for u in terminal['units']),
    'buildings':sum(b['owner']==owner for b in terminal['buildings'])} for owner in owners},
 'reportSHA256':sha(report_path.read_bytes()),'terminalWorldSHA256':sha(terminal_path.read_bytes()),
 'note':'A completed runner with winner=null is only an inspection horizon. This single map seed/opponent is not bootstrap acceptance.'}
pathlib.Path(str(prefix)+'-postflight.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
pathlib.Path(str(prefix)+'-checkpoint-summary.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k not in ['checkpoints','nativeMatch']},ensure_ascii=False,indent=2))
