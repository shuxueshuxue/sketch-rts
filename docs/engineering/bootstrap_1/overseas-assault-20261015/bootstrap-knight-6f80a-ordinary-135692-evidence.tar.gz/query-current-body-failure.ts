import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const prefix=process.argv[2],source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const{setBuildingBodies,sameGround}=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
const{shipPassengers,localToWorld,distanceToHull}=await import(pathToFileURL(source+'/src/shared/ship-geometry.ts').href);
const{passengerLandingSpot,LANDING_REACH}=await import(pathToFileURL(source+'/src/shared/naval.ts').href);
const{isInCabin}=await import(pathToFileURL(source+'/src/shared/ship-cabin.ts').href);
const stages=JSON.parse(readFileSync(prefix+'-assault-stage-queries.json','utf8')),out:any[]=[];
for(const tick of[55500,55920,55935,55950]){
 const f=JSON.parse(readFileSync(prefix+'-assault-55200-56400-v2-inputs/'+tick+'.json','utf8')),s=f.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const stage=stages.result.find((r:any)=>r.tick===tick);
 for(const id of['unit-p0-carrier-4595','unit-p0-transport-1046']){
  const state=stage.afterRevise.find((b:any)=>b.id===id),boat=s.units.find((u:any)=>u.id===id),target=s.buildings.find((b:any)=>b.id===state.mission.targetId);
  const ship={...boat,order:{type:'unload',...state.mission.to},sailing:{...boat.sailing,speed:0,velocityX:0,velocityY:0}};
  const shadow=s.units.map((u:any)=>u.id===id?ship:u.deck?.shipId===id?{...u,...localToWorld(ship,u.deck)}:u),passengers=shipPassengers(shadow,ship),checks:any[]=[];
  for(const u of passengers){const point=passengerLandingSpot(s.map,ship,u.id,shadow);checks.push({id:u.id,kind:u.kind,cabin:isInCabin(u),point,sameTargetGround:point?sameGround(s.map,point,target):null,distanceToHull:point?distanceToHull(ship,point):null});if(!point||!sameGround(s.map,point,target))break;shadow[shadow.indexOf(u)]={...u,...point,deck:undefined,cabin:undefined};}
  out.push({tick,id,goal:state.mission.to,actualPose:{x:ship.x,y:ship.y,heading:ship.sailing.heading},LANDING_REACH,totalPassengers:passengers.length,cabins:passengers.filter(isInCabin).map((u:any)=>u.id),checks});
 }
}
writeFileSync(prefix+'-current-body-failure.json',JSON.stringify({classification:'Read-only mechanical expansion of native assaultBeachBodies at the actual hull pose, preserving native passengerLandingSpot and shadow-body order. No rule or command edits.',out})+'\n');console.log(JSON.stringify(out));
