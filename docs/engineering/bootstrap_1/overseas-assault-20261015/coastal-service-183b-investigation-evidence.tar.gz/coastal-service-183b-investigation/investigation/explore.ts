import {readFileSync,writeFileSync} from 'node:fs';import{gunzipSync}from'node:zlib';
import {connectedSurfacePath} from '/tmp/sketch-rts-coastal-service-183b-control/src/shared/connected-decks.ts';
import {canBoard,deckPointFits,deckPlacement} from '/tmp/sketch-rts-coastal-service-183b-control/src/shared/decks.ts';
import {shipProfile,localToWorld,worldToLocal,circleInPolygon} from '/tmp/sketch-rts-coastal-service-183b-control/src/shared/ship-geometry.ts';
const saved=JSON.parse(gunzipSync(readFileSync('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015/coastal-return-v4-continuation-full-ai.json.frames/final-178800.json.gz')).toString()),s=saved.snapshot;
const passenger=s.units.find((u:any)=>u.id==='unit-p0-worker-1'),source=s.units.find((u:any)=>u.id==='unit-p0-warship-1100'),target=s.units.find((u:any)=>u.id==='unit-p0-bombardShip-26580');
const ids=['unit-p0-ballista-7539','unit-p0-ballista-12972'];
const metric=(r:any)=>{const p=r?.points.at(-1)??passenger;return{complete:r?.complete,points:r?.points,distance:Math.hypot(p.x-target.x,p.y-target.y),reachesTarget:r?.points.some((at:any)=>circleInPolygon(worldToLocal(target,at),0,shipProfile(target)!.hull))??false}};
const goal=localToWorld(target,passenger.order.deckPoint),original={center:metric(connectedSurfacePath(passenger,target,s.units,s.map)),board:metric(connectedSurfacePath(passenger,goal,s.units,s.map))};
const retreats=[undefined,...[{x:0,y:0},{x:shipProfile(source)!.length/4,y:0},{x:-shipProfile(source)!.length/4,y:0}].map(pref=>deckPlacement(source,passenger,s.units,pref))];
const result:any={original,goal,groups:[],combined:[]};
for(const retreat of retreats){const at=retreat&&localToWorld(source,retreat);const worker=at?{...passenger,...at,deck:{shipId:source.id,...retreat}}:passenger;
 const units=s.units.map((u:any)=>u===passenger?worker:u),group:any={retreat,retreatReachable:!at||connectedSurfacePath(passenger,at,s.units,s.map)?.complete,worker:{x:worker.x,y:worker.y,deck:worker.deck},bodies:[],pairs:[]};
 const sets:any[]=[];
 for(const id of ids){const unit=units.find((u:any)=>u.id===id),points:any[]=[];
  for(const ship of[source,target]){if(ship.id!==unit.deck.shipId&&!canBoard(ship,unit,units))continue;const profile=shipProfile(ship)!;
   for(let y=-profile.beam/2;y<=profile.beam/2;y+=4)for(let x=-profile.length/2;x<=profile.length/2;x+=4){const point={x,y};if(!deckPointFits(ship,unit,point,units))continue;const world=localToWorld(ship,point);if(!connectedSurfacePath(unit,world,units,s.map)?.complete)continue;
    const moved={...unit,...world,deck:{shipId:ship.id,...point}},projected=units.map((u:any)=>u.id===id?moved:u),center=metric(connectedSurfacePath(worker,target,projected,s.map)),board=metric(connectedSurfacePath(worker,goal,projected,s.map));points.push({id,shipId:ship.id,point,world,center,board,moved});
   }
  }
  sets.push(points);group.bodies.push({id,count:points.length,candidates:points.map(({moved,...r})=>r).sort((a:any,b:any)=>a.board.distance-b.board.distance).slice(0,8)});
 }
 for(const a of sets[0])for(const b of sets[1]){if(Math.hypot(a.world.x-b.world.x,a.world.y-b.world.y)<a.moved.radius+b.moved.radius+1)continue;const projected=units.map((u:any)=>u.id===a.id?a.moved:u.id===b.id?b.moved:u);const board=metric(connectedSurfacePath(worker,goal,projected,s.map)),center=metric(connectedSurfacePath(worker,target,projected,s.map));
  if(board.reachesTarget||center.complete)group.pairs.push({a:{id:a.id,point:a.point,shipId:a.shipId,world:a.world},b:{id:b.id,point:b.point,shipId:b.shipId,world:b.world},board,center});
 }
 result.groups.push(group);
}
writeFileSync('/tmp/coastal-service-183b-evidence/explore.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
