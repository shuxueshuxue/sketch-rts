from pathlib import Path
import json,gzip,hashlib,tarfile,subprocess,datetime,shutil
B=Path('/tmp/coastal-service-183b-evidence');R=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
audits={}
for n,w in [('baseline183b','/tmp/sketch-rts-coastal-service-183b-baseline'),('candidate-v1','/tmp/sketch-rts-coastal-service-183b-control')]:
 m=J(B/(n+'-source.json'));actual={}
 with tarfile.open(B/(n+'-source.tar.gz'))as t:
  for x in t:
   if x.isfile():actual[x.name]=H(t.extractfile(x).read())
 assert actual==m['files'] and len(actual)==1405
 changed=[p for p,h in actual.items()if H((Path(w)/p).read_bytes())!=h];assert not changed
 audits[n]={'sourceManifestSha256':H((B/(n+'-source.json')).read_bytes()),'sourceCapsuleSha256':H((B/(n+'-source.tar.gz')).read_bytes()),'files':len(actual),'capsuleEqualsManifest':True,'currentSourceChanges':changed}
parent=J(R/'coastal-service-183b-probe.json');baseline=J(B/'baseline183b-source.json')['files'];missing=[p for p in parent['sources']if p not in baseline];mismatch=[p for p,h in parent['sources'].items()if baseline.get(p)!=h];assert not missing and not mismatch and not parent['changed']
parent_frames=json.loads(gzip.decompress((R/'coastal-service-183b-probe-frames.json.gz').read_bytes()));assert all(set(f['memories'])=={'p0','p1'}and f['snapshot']['tick']>=178800 for f in parent_frames)
run_audits={}
for n in ['baseline183b-both-ai','candidate-v1-both-ai','native-yard-probe']:
 d=J(B/(n+'.json'));assert not d.get('sourceChanged',d.get('sourceChanges'))
 replay=d['replay'];assert replay['snapshot']and replay['nextId'];assert replay.get('memories',replay.get('memoriesUnchanged'))
 if 'issued'in replay:assert replay['issued']
 frames=json.loads(gzip.decompress((B/(n+'-frames.json.gz')).read_bytes()));assert all(set(f['memories'])=={'p0','p1'}and isinstance(f['nextId'],int) for f in frames)
 run_audits[n]={'start':d.get('start',178800),'end':d['end'],'frames':len(frames),'replay':replay,'sourceChanges':[],'classification':d['classification']}
collision=J(B/'yard-collision-replay.json');assert collision['snapshotMatchesOriginal']and collision['nextIdMatchesOriginal']and collision['memoriesUnchanged']
base=J(B/'baseline183b-both-ai.json');candidate=J(B/'candidate-v1-both-ai.json');firstbase=[e for e in base['issued']if e['tick']==174690];firstcandidate=[e for e in candidate['issued']if e['tick']==174690]
frozen_path=Path('/tmp/sketch-rts-coastal-service-183b-baseline/docs/engineering/bootstrap_1/frozen-policy.json');frozen=J(frozen_path);assert H(frozen_path.read_bytes())=='0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774'
raw=subprocess.check_output(['git','archive',frozen['revision'],'package.json','src/ai','src/sdk','src/shared'],cwd='/tmp/sketch-rts-coastal-service-183b-baseline');(B/'frozen-loader-paths-posthoc.tar').write_bytes(raw)
import io
with tarfile.open(fileobj=io.BytesIO(raw))as t:fs={m.name:H(t.extractfile(m).read())for m in t if m.isfile()}
assert all(fs.get(p)==h for p,h in frozen['files'].items())
audit={'classification':'Post-run static audit of failed service investigation; this does not convert any diagnostic into an ordinary opening or accepted fix.','checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':audits,'parentRootProbe':{'base':parent['sourceCommit'],'sourceFiles':len(parent['sources']),'allEqualArchivedBaseline':True,'sourceChanges':parent['changed'],'frames':len(parent_frames),'start':178800,'end':179400},'runs':run_audits,'first174690BothAiEntries':{'baseline':firstbase,'candidate':firstcandidate},'collisionReplay':{k:collision[k]for k in ['inputTick','end','snapshotMatchesOriginal','nextIdMatchesOriginal','memoriesUnchanged']},'frozen':{'revision':frozen['revision'],'rulesVersion':frozen['rulesVersion'],'manifestSha256':H(frozen_path.read_bytes()),'verifiedFiles':len(frozen['files']),'reconstructedLoaderArchiveFiles':len(fs),'archiveSha256':H(raw),'provenance':'Reconstructed now after runs from the exact authorized Git commit. Never labeled prelaunch. Original per-run live source preflight/postflight and manifest are retained.'},'decision':'Keep candidate unmerged: neither body crossing nor paid repair is achieved by this candidate/fullAI or manual-yard test. Root production and frozen source were not edited.'}
(B/'INVESTIGATION-AUDIT.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
(B/'README.zh.md').write_text('''# coastal178800 服务堵塞：完整反证与未并入候选

本包保存真实旧续局178800跨舰工程师堵塞，及首次新维修任务174690的因果调查。未修改root生产或冻结源；所有新执行在/tmp独立稀疏183b工作树中。原故障容器未提交修改仍未恢复。任何局部、零死亡、hold存活、静态泊位、JSON通过都不构成完整比赛胜利或bootstrap验收。

原root183b两AI178800→179400失败：炮船28HP，工人仍源舰，原probe完整report/log/driver/fullframes及3组geometry查询全部收入。最初JSON.parse(object)的setup错误源/log保留；错误发生在推进游戏前。修正后原局p0=v9_summoner/Grove、p1=普通冻结v5/Ember，参数正确。原probe记录的全部源码SHA与本包纯183b源码capsule逐项相同；原sourceChanged为空。

固定泊位的只读4格候选枚举不是连续空间不可达证明。必须去两台弩炮身体才可走完整中心路线；接收弩炮身体跨联合floor，单船deckWalk误拒而真实connectedSurfacePath允许58个候选。源弩炮当前5个4格点、原工程师3种偏好退位均未给出可执行通路，两个弩炮的有限二次组合亦未解决。原board保存的(78.56,5.8)与AI所查船中心不同：即使删乘员，前者仍partial但路径可进入目标船，不能把完整到中心与native跨父船混同。

手动source-ballista move诊断：只有一次合法公开move，随后300tick仅native。工人0位移；弩炮因原生move约5px到达容差提前idle，没有到影子端点。保留所有原世界演员，不能从投影端点宣称身体实际到达。

首次174690新任务的真实因果：原navalServices在两船距离约1393px且canBoard=true时发stop炮船+board工人，抢走原旧coastalReturns返港腿。真实完整p0输出后1native tick产生原引擎rendezvous；对全部实际乘员随计划终位刚体投影，静态seam可转移但工程师真实board目标和中心路线均partial且未进入接收舰。此投影是查询，不是已执行的移动。

未并入candidate-v1仅复用原native择泊函数（机械导出无执行语义变化），在创建新的跨舰维修任务前检查接收路径/现有合法让路；已有board保留，无超时取消、新owner或容量调整。独立完整双方AI174690→178800：炮船一直28HP/hold，worker1后来接transport1046任务，没有付费维修。183b没有旧coastalReturns控制；拒绝拦截不等于它会自动续跑旧返港腿。纯183b对照174690→175500则原board/rendezvous持续，未跨船，源舰实际受损至309.676。两者完整世界/nextId/双方所有mem及issued在174990的JSON续跑至各终点逐项一致。1405文件源码capsule逐项验证，前后0变化。两运行是换代码续局，不能当普通开局或孤立归因整场成绩。

真实维修点查询与手动港口负例：原native nearestShipPose给(7824,3632,π/2)，距yard64<原维修240，hullFits/同海域为true。岸上唯一650范围工人已有carrier40005 boarding，未抢任务。手动公开follow源舰+queued原board保留工人任务，再公开move炮船到该yard点，随后178800→181800只native：未发生任何付费维修，28HP→27.028228。180781与原真实空闲carrier36426碰撞（炮船0.9717719伤、carrier0.55802伤），当时距yard377；之后航线绕回，终点距yard614。179100完整JSON续跑至181800全世界/nextId/双方mem一致。额外180750→180900无新命令重放亦与原完整采样一致，并保存180780/180781精确tick边界世界与双方mem。该静态泊位实际被港口船体/航线影响，不能称为已验证可执行返港维修。

测试：5套34项，32通过；2项headland旧“源舰必须满血”断言失败314.97705695 vs320，纯183b独立对照同样两失败，同样数值。保留原失败日志，不放宽断言。tsc --noEmit通过。首次稀疏配置漏tools、一次错误cwd、历史JSON key order/undefined键对照失败和onCommand试图clone含game方法的hook错误均保留原脚本/log；最终runner只记录tick/owner/scriptId/command，重新从原完整存档启动。前几次错误均未推进native tick，不混入最终证据。

2个完整1405文件源码capsule及前置manifest、原184冻结manifest、事后从同一冻结Git revision按实际loader路径重建497文件tar一起保留；后者明确是事后重建，不冒充prelaunch。node_modules不含，package/lock在capsule内。实际178800原生client存档渲染图明确是事后使用未改183b客户端，不是手绘或实时截图。

结论：无候选交付生产。固定拥挤泊位仍缺可实际跨船的公开动作；新维修admission单改也未修复，码头静态可放置不等于当前船群能执行付费维修。root的新普通召唤144000停滞将作为下一项独立调查，不继续拼接旧coastalReturns语义。INDEX.json逐payload SHA/bytes；逐条读回验证收据在包外ARCHIVE-VERIFIED.json。
''')
STAGE=B/'service-investigation-stage';STAGE.mkdir(exist_ok=True)
selected=[]
def add(p,name):
 dest=STAGE/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);selected.append(name)
for p in sorted(B.iterdir()):
 if p.is_file()and p.name not in ['ARCHIVE-VERIFIED.json']and not p.name.endswith('-evidence.tar.gz'):add(p,'investigation/'+p.name)
for p in sorted(R.glob('coastal-service-183b-*')):
 if p.is_file():add(p,'root183b-original/'+p.name)
for p in [R/'coastal-return-v4-continuation-full-ai.json.frames/final-178800.json.gz',R/'coastal-return-v3-full-ai.json.frames/174690-commands-p0.json.gz',frozen_path]:add(p,'original-inputs/'+p.name)
assert len(selected)==len(set(selected))
index={'classification':'Post-run archive of complete negative service diagnostics and unmerged admission prototype. No accepted production fix.','files':{n:{'bytes':(STAGE/n).stat().st_size,'sha256':H((STAGE/n).read_bytes())}for n in sorted(selected)}};(STAGE/'INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
archive=Path('/tmp/coastal-service-183b-investigation-evidence.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=6)as t:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():t.add(p,arcname='coastal-service-183b-investigation/'+p.relative_to(STAGE).as_posix(),recursive=False)
with tarfile.open(archive)as t:
 prefix='coastal-service-183b-investigation/';names=[x.name.removeprefix(prefix)for x in t if x.isfile()];assert len(names)==len(selected)+1 and set(names)==set(selected)|{'INDEX.json'}
 assert json.loads(t.extractfile(prefix+'INDEX.json').read())==index
 for n,e in index['files'].items():
  payload=t.extractfile(prefix+n).read();assert len(payload)==e['bytes']and H(payload)==e['sha256']
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':H(archive.read_bytes()),'verifiedPayloads':len(selected),'totalFileEntriesIncludingIndex':len(selected)+1,'allPayloadHashesAndLengthsMatch':True,'nestedSourceCapsulesVerifiedFiles':[1405,1405],'originalRootProbeSourceHashesMatchBaseline':True,'decision':'UNMERGED: all tested repair pathways remain unsuccessful; preserve negative evidence.'};(B/'ARCHIVE-VERIFIED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
