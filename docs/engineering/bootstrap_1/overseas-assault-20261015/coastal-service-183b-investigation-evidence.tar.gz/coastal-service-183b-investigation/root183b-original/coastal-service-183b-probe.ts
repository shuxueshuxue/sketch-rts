import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/sketch-rts-bootstrap-resume/src/shared/sim.ts';
import {createAiMemoryProvider} from '/workspace/sketch-rts-bootstrap-resume/src/ai/planner-context.ts';
import {runAiGameLoop} from '/workspace/sketch-rts-bootstrap-resume/src/ai/game-runner.ts';
import {createBootstrapCommandPlanner} from '/workspace/sketch-rts-bootstrap-resume/scripts/bootstrap_1-planner.ts';
import {clearTransferLanes} from '/workspace/sketch-rts-bootstrap-resume/src/ai/policy/transfer-lanes.ts';
import {connectedSurfacePath,decksCanTransfer} from '/workspace/sketch-rts-bootstrap-resume/src/shared/connected-decks.ts';
import {canBoard} from '/workspace/sketch-rts-bootstrap-resume/src/shared/decks.ts';
const r='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const input=r+'/coastal-return-v4-continuation-full-ai.json.frames/final-178800.json.gz', raw=readFileSync(input), saved=JSON.parse(gunzipSync(raw).toString());
const memoryProvider=createAiMemoryProvider();for(const [owner,memory] of Object.entries(saved.memories))memoryProvider.set!(owner,memory as any);
const planner=await createBootstrapCommandPlanner(memoryProvider),game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const sources=execFileSync('git',['ls-files','-z','src','scripts','package.json','package-lock.json','docs/engineering/bootstrap_1/frozen-policy.json']).toString().split('\0').filter(Boolean).reduce((s,p)=>(s[p]=hash(readFileSync(p)),s),{} as Record<string,string>);
const targetId='unit-p0-bombardShip-26580',workerId='unit-p0-worker-1',sourceId='unit-p0-warship-1100';
const rows:any[]=[],commands:any[]=[],frames:any[]=[];
function row(){const snap=snapshotGame(game),worker=snap.units.find(u=>u.id===workerId)!,target=snap.units.find(u=>u.id===targetId)!,source=snap.units.find(u=>u.id===sourceId)!;return{tick:snap.tick,worker,target,source,canTransfer:decksCanTransfer(source,target,worker),canBoard:canBoard(target,worker,snap.units),surface:connectedSurfacePath(worker,target,snap.units,snap.map),clear:clearTransferLanes(snap,'p0'),gold:snap.players.p0.gold,lost:snap.match.stats.unitsLost.p0};}
function full(){return{snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(['p0','p1'].map(owner=>[owner,memoryProvider.get(owner)]))};}
rows.push(structuredClone(row()));frames.push(full());
const result=runAiGameLoop({name:'real coastal178800 current183b bothAI probe',game,maxTicks:179400,thinkInterval:15,agents:{p0:{version:'v9_summoner',race:'grove',controller:'external-agent',team:'a'},p1:{version:'v5',race:'ember',controller:'external-agent',team:'b'}},commandPlanner:planner},{onCommand({tick,owner,scriptId,command}){if('unitIds'in command&&command.unitIds.some(id=>[targetId,sourceId,workerId,'unit-p0-ballista-7539','unit-p0-ballista-12972'].includes(id)))commands.push({tick,owner,scriptId,command:structuredClone(command)});},onStep(){if(game.tick%15===0){const next=structuredClone(row());rows.push(next);if(game.tick%150===0){frames.push(full());console.log(JSON.stringify({tick:game.tick,workerDeck:next.worker.deck,workerOrder:next.worker.order.type,targetHp:next.target.hp,clear:next.clear.length,canTransfer:next.canTransfer,surface:next.surface?.complete}));}}}});
frames.push(full());const changed=Object.entries(sources).filter(([p,d])=>hash(readFileSync(p))!==d);
writeFileSync(r+'/coastal-service-183b-probe.json',JSON.stringify({classification:'Changed-code full bothAI diagnostic of real prior failed178800 complete saved world; not ordinary opening or completed bootstrap',sourceCommit:execFileSync('git',['rev-parse','HEAD']).toString().trim(),input,inputSha256:hash(raw),rulesVersion:2,sources,changed,rows,commands,result:{tick:game.tick,winner:game.match.winner},snapshot:result.snapshot,nextId:game.nextId,memories:full().memories})+'\n');
writeFileSync(r+'/coastal-service-183b-probe-frames.json.gz',gzipSync(JSON.stringify(frames)));
console.log(JSON.stringify({done:true,tick:game.tick,winner:game.match.winner,changed:changed.length,targetHp:game.units.find(u=>u.id===targetId)?.hp,workerDeck:game.units.find(u=>u.id===workerId)?.deck}));
