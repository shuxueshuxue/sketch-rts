import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createCanvas } from '@napi-rs/canvas';
const source='/tmp/sketch-rts-archer-double-v8-25cce-control';
const dir='/tmp/bootstrap-archer-double-v8-25cce-20261015';
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const view={x:1300,y:2700,width:1300,height:1000,zoom:1};
const outputs=[];
for(const [label,path] of [
 ['original','focused-camp-entry-6000-7200.frames/6300.json'],
 ['candidate-v2','courier-safe-stop-v2-6000-7200.frames/6300.json'],
] as const){
 const data=readFileSync(dir+'/'+path),{snapshot}=JSON.parse(data.toString());
 const canvas=createCanvas(view.width,view.height);
 drawWorld({ctx:canvas.getContext('2d') as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
 const output=dir+'/courier-focused-native-'+label+'-6300.png';
 writeFileSync(output,canvas.toBuffer('image/png'));
 outputs.push({label,input:path,inputSHA256:createHash('sha256').update(data).digest('hex'),output,view,tick:snapshot.tick,
  actors:snapshot.units.filter((u:any)=>['unit-p0-archer-1347','creep-gen-7-1'].includes(u.id)).map(({id,x,y,hp,order}:any)=>({id,x,y,hp,order}))});
}
writeFileSync(dir+'/courier-focused-native-visual.json',JSON.stringify({classification:'Actual saved native world snapshots, drawn by original fixed25cce native drawWorld; policy candidate only changes mercenary owner. A fresh facing tracker does not reconstruct historic animations.',rendererSource:source,outputs},null,2)+'\n');
console.log(JSON.stringify(outputs));
