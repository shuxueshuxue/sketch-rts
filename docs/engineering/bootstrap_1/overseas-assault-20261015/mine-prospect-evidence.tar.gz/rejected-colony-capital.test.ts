import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { sketchScene } from '../../sdk/scene';
import { issueCommandFrame } from '../../sdk/commands/frame';
import { BUILDING_DEFS } from '../../shared/catalog';
import { boardUnit } from '../../shared/decks';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import { createAiPolicyMemory } from '../memory';
import { navalBudgetReserve } from '../policy/naval';
import { runAiCommandEntriesFromScripts } from '../policy/script-runner';
import { BOOTSTRAP_VERSIONS, bootstrapPolicyContext, bootstrapScripts } from './policy';
import { footholdCanUseCapital } from './colony-capital';

it.each(BOOTSTRAP_VERSIONS.flatMap(version => [41655, 41910].map(tick => ({ version, tick })) ))(
  '$version retains colony capital at the actual $tick exhausted-island garrison purchase', ({ version, tick }) => {
    const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/archer-colony-capital-${tick}.json.gz`, import.meta.url))).toString());
    const game = createGame('bareDuel');
    restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', version, { memory: saved.memory, teams: game.teams });
    expect(navalBudgetReserve(snapshot, 'p0', options)).toBe(BUILDING_DEFS.townHall.cost);
    const entries = runAiCommandEntriesFromScripts(snapshot, 'p0', bootstrapScripts(version), options);
    expect(entries.some(({ command }) => command.type === 'build' && command.buildingKind === 'barracks')).toBe(false);
    expect(entries.some(({ command }) => command.type === 'train' && command.buildingId === 'building-p0-barracks-5265')).toBe(false);
    issueCommandFrame(game, entries.map(entry => ({ ...entry, playerId: 'p0' })));
    expect(game.players.p0!.gold).toBe(snapshot.players.p0!.gold);
  },
);

const threats = ['idle', 'attack', 'unload', 'other-island', 'ordinary-budget'] as const;
it.each(BOOTSTRAP_VERSIONS.flatMap(version => threats.map(threat => ({ version, threat })) ))(
  '$version permits the $threat colony purchase according to actual threat and available capital', ({ version, threat }) => {
    const game = sketchScene('colony-capital-emergency').map('bareDuel').replaceDefaults()
      .player('us', { team: 'a' }).player('foe', { team: 'b' })
      .playerState('us', { gold: threat === 'ordinary-budget' ? 1000 : BUILDING_DEFS.barracks.cost })
      .townHall('us', 500, 500).townHall('us', 2500, 500).townHall('foe', 3500, 500)
      .worker('us', 2600, 650).goldMine('remote', 3500, 800, 6000)
      .unit('foe', 'footman', 2600, 1300, { id: 'raider' })
      .unit('foe', 'transport', 1500, 500, { id: 'convoy' }).build().createGame();
    game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) => {
      const col = index % 128;
      return col < 32 || col > 70 && col < 92 || col > 102 ? '.' : '~';
    }).join('') };
    const raider = game.units.find(unit => unit.id === 'raider')!, convoy = game.units.find(unit => unit.id === 'convoy')!;
    const hall = game.buildings.find(building => building.owner === 'us' && building.x === 2500)!;
    if (threat === 'attack') raider.order = { type: 'attack', targetId: hall.id };
    if (threat === 'unload' || threat === 'other-island') {
      expect(boardUnit(convoy, raider, game.units)).toBe(true);
      convoy.order = { type: 'unload', x: threat === 'unload' ? 2400 : 3500, y: 500 };
    }
    const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'us', version,
      { memory: createAiPolicyMemory(), teams: game.teams });
    expect(navalBudgetReserve(snapshot, 'us', options)).toBeGreaterThan(0);
    const emergency = threat === 'attack' || threat === 'unload';
    expect(footholdCanUseCapital(snapshot, 'us', { type: 'build', unitId: snapshot.units.find(unit => unit.owner === 'us')!.id,
      buildingKind: 'barracks', x: 2680, y: 600 }, options)).toBe(emergency);
    const entries = runAiCommandEntriesFromScripts(snapshot, 'us', bootstrapScripts(version), options);
    expect(entries.some(({ command }) => command.type === 'build' && command.buildingKind === 'barracks')).toBe(emergency || threat === 'ordinary-budget');
  },
);
