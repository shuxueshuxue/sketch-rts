import { unitMover } from '../../shared/catalog';
import { combatCapability } from '../../shared/combat-capabilities';
import { strikeGap } from '../../shared/combat-geometry';
import { shipPassengers, shipProfile } from '../../shared/ship-geometry';
import { automaticShoreTargetReachable } from '../../shared/shore-fire';
import { sameGround } from '../../shared/terrain';
import type { GameCommand, GameSnapshot, PlayerId } from '../../shared/types';
import { nearestByRoute } from '../../shared/route-selection';
import { isEnemyOwner, isOpponentOwner } from '../policy/ownership';
import { groundThreatWithin } from '../policy/ground-threat';
import type { AiPolicyContext } from '../policy/types';

/** A standing enemy on the island requests a garrison; only an actual attack can spend the next colony's capital. */
export function footholdCanUseCapital(snapshot: GameSnapshot, owner: PlayerId, command: GameCommand | undefined, options: AiPolicyContext): boolean {
  const point = command?.type === 'build' ? command : command?.type === 'train'
    ? snapshot.buildings.find(building => building.id === command.buildingId) : undefined;
  if (!point) return false;
  const hall = nearestByRoute(snapshot.map, snapshot.buildings.filter(building => building.owner === owner
    && building.kind === 'townHall' && building.complete && sameGround(snapshot.map, point, building)), point, 'land');
  if (!hall) return false;
  const buildings = snapshot.buildings.filter(building => building.owner === owner && sameGround(snapshot.map, hall, building));
  const assets = [...buildings, ...snapshot.units.filter(unit => unit.owner === owner && !unit.deck
    && sameGround(snapshot.map, hall, unit) && unit.kind === 'worker')];
  return snapshot.units.some(foe => {
    if (!isEnemyOwner(snapshot, owner, foe.owner, options)) return false;
    if (unitMover(foe.kind) === 'sea') {
      if (!isOpponentOwner(snapshot, owner, foe.owner, options)) return false;
      if (foe.order.type === 'unload' && sameGround(snapshot.map, hall, foe.order)
        && shipPassengers(snapshot.units, foe).some(unit => combatCapability(snapshot, unit).armed)) return true;
      const capability = combatCapability(snapshot, foe);
      return capability.armed && strikeGap(foe, hall) <= capability.range + shipProfile(foe)!.length / 2
        && automaticShoreTargetReachable(snapshot, foe, hall);
    }
    if (foe.deck || !combatCapability(snapshot, foe).armed || !sameGround(snapshot.map, hall, foe)) return false;
    return assets.some(asset => strikeGap(foe, asset) <= foe.attackRange
      || (foe.order.type === 'attack' || foe.order.type === 'attackMove') && foe.order.targetId === asset.id
      || foe.order.type === 'attackMove' && strikeGap(foe.order, asset) <= foe.attackRange
        && groundThreatWithin(snapshot, foe, asset, foe.attackRange + foe.speed));
  });
}
