from pathlib import Path
import json,hashlib,tarfile,datetime
root=Path('/tmp/knight-recovery-waypoint-6f80');archive=Path('/tmp/knight-recovery-waypoint-6f80-win-evidence.tar.gz');sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['candidate64800-68400.json','continuation-report.json','ending-window-result.json','combat-accounting-result.json','final-source-postflight.json','whole-match-outcome.json']:
 r=json.loads((root/name).read_bytes())
 if 'equals'in r:assert all(r['equals'].values()),(name,r['equals'])
 if 'sourceChanges'in r:assert not r['sourceChanges'],name
assert json.loads((root/'continuation-report.json').read_bytes())['winner']=='p0'
assert json.loads((root/'whole-match-outcome.json').read_bytes())['nativeLossAccountingClosed']=={'p0':True,'p1':True,'neutral':True}
files={};sizes={}
for p in sorted(root.rglob('*')):
 if not p.is_file()or p.is_symlink()or p.name=='INDEX.json':continue
 name=p.relative_to(root).as_posix();b=p.read_bytes();files[name]=sha(b);sizes[name]=len(b)
index={'classification':'Complete isolated6f80+priorunmergedempty-evacuation+typedfinitecriticalrecoverywaypoint actual64800code-switch+68400same-source normalbothAI natural129158p0win. Notordinary0/root3bdb/finalbootstrapacceptance. Originalpriorcontaineruncommittedgap retained.','createdAtPostRun':datetime.datetime.now(datetime.timezone.utc).isoformat(),'algorithm':'SHA-256','payloadCount':len(files),'payloadBytes':sum(sizes.values()),'files':files,'sizes':sizes,'sourceCapsulePayloadsVerified':1374,'frozenEntries':184,'rulesVersion':2,'jsonRestartValidation':'65190→65400 and65400→66000 fiveitem; actual1200periodic127200→128400 and128400→129158 nineitem exactnativebothAI','operationalLimits':'Originalactiveordinary0 sparse/fileavailabilitydiskpressureincident copied, not hidden by postflightsourcehashes. Currentindependentfixedcandidate did notmodifyoriginalcontrol/root.','staticBoundary':'sameGround rememberedgoal safety checks same-landweaponcoverage only; naval/deck/across-water coverage not guaranteed; notobservedcasefailure.'};(root/'INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(archive,'w:gz')as t:
 for name in list(files)+['INDEX.json']:t.add(root/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as t:
 members=t.getmembers();assert len(members)==len(files)+1
 assert set(t.getnames())==set(files)|{'INDEX.json'}
 for name,h in files.items():
  b=t.extractfile(name).read();assert len(b)==sizes[name]and sha(b)==h,name
 assert t.extractfile('INDEX.json').read()==(root/'INDEX.json').read_bytes()
b=archive.read_bytes();result={'archive':str(archive),'bytes':len(b),'sha256':sha(b),'payloadsVerified':len(files),'totalTarEntriesVerified':len(files)+1,'indexSHA256':sha((root/'INDEX.json').read_bytes()),'capsuleSHA256':files['candidate-source-capsule.tar.gz'],'sourceCapsulePayloadsVerified':1374,'frozenManifestEntriesVerified':184,'naturalEnd':129158,'winner':'p0','classification':index['classification']};Path('/tmp/knight-recovery-waypoint-6f80-seal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
