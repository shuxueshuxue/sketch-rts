import hashlib,json,tarfile,io,subprocess,datetime
from pathlib import Path
r=Path('/tmp/sketch-rts-knight-recovery-waypoint-6f80-control');out=Path('/tmp/knight-recovery-waypoint-6f80');old=Path('/tmp/knight-colony-defense-6f80')
assert r.resolve()==r
base='6f80a9365e591cbfba9148260806cd4f9033788e';assert subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip()==base
sha=lambda b:hashlib.sha256(b).hexdigest()
original=json.loads((old/'original-runtime-source.json').read_bytes());hashes={**original['runtimeHashes'],**original['supportingDataHashes']};current={p:sha((r/p).read_bytes()) for p in hashes}
changed=[p for p in hashes if current[p]!=hashes[p]];assert changed==['src/ai/bootstrap_1/expedition-recovery.ts','src/ai/memory.ts','src/ai/policy/naval.ts'],changed
evac=json.loads(Path('/tmp/knight-evacuation-6f80/candidate-prelaunch.json').read_bytes());assert current['src/ai/policy/naval.ts']==evac['runtimeSupportHashes']['src/ai/policy/naval.ts']
assert current['src/ai/bootstrap_1/land-recovery.ts']==hashes['src/ai/bootstrap_1/land-recovery.ts']
patch=subprocess.check_output(['git','-C',str(r),'diff','--','src/ai/memory.ts','src/ai/bootstrap_1/expedition-recovery.ts']);(out/'waypoint-only.patch').write_bytes(patch)
combined=subprocess.check_output(['git','-C',str(r),'diff','--','src/ai/memory.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/policy/naval.ts']);(out/'combined-production.patch').write_bytes(combined)
added=['src/ai/bootstrap_1/recovery-waypoint.test.ts']+[f'src/ai/bootstrap_1/__fixtures__/knight-unmedicated-{t}.json.gz' for t in [65160,65205,65280]]
capsule=out/'candidate-source-capsule.tar.gz';files={}
with tarfile.open(old/'original-fixed-6f80-source-capsule.tar.gz','r:gz') as src,tarfile.open(capsule,'w:gz') as dest:
 for member in src.getmembers():
  if member.name=='INDEX.json':continue
  b=(r/member.name[5:]).read_bytes() if member.name.startswith('live/') else src.extractfile(member).read()
  member.size=len(b);dest.addfile(member,io.BytesIO(b));files[member.name]=sha(b)
 for name in added:
  b=(r/name).read_bytes();member=tarfile.TarInfo('live/'+name);member.size=len(b);dest.addfile(member,io.BytesIO(b));files[member.name]=sha(b)
 b=(json.dumps({'algorithm':'SHA-256','classification':'Actual prelaunch6f80+priorunmergedempty-evacuation+newtypedcritical-recovery-waypoint combination. land-recovery.ts bytewise6f80, no457/bodyavoidance. Frozen184unchanged.','files':files},indent=2)+'\n').encode();member=tarfile.TarInfo('INDEX.json');member.size=len(b);dest.addfile(member,io.BytesIO(b))
with tarfile.open(capsule,'r:gz') as tf:
 assert len(files)==1374 and set(tf.getnames())==set(files)|{'INDEX.json'}
 assert all(sha(tf.extractfile(n).read())==h for n,h in files.items())
 frozen_bytes=tf.extractfile('frozen-policy.json').read();assert sha(frozen_bytes)==original['frozenManifestSha256'];frozen=json.loads(frozen_bytes);assert frozen['rulesVersion']==2 and len(frozen['files'])==184
 assert all(sha(tf.extractfile('frozen/'+n).read())==h for n,h in frozen['files'].items())
manifest={'classification':'Actual prelaunch fixed combination source audit before actual64800to68400 normalbothAI focused test. Changed-code continuation, not ordinary0 or completed match.','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':str(r),'baseCommit':base,'combination':'6f80+prior empty-evacuation patch9283dee7+typednavalrecoverywaypoints; no457, no3bdb or currentroot source copied.','productionChangedFiles':changed,'newWaypointOnlyPatchSHA256':sha(patch),'combinedProductionPatchSHA256':sha(combined),'priorEvacuationPatchSHA256':evac['productionPatchSHA256'],'runtimeSupportHashes':current,'addedTestAndFixtureHashes':{p:sha((r/p).read_bytes()) for p in added},'sourceCapsule':str(capsule),'sourceCapsuleSHA256':sha(capsule.read_bytes()),'sourceCapsuleAllPayloadsVerified':len(files),'frozenManifestSHA256':sha(frozen_bytes),'frozenRevision':frozen['revision'],'frozenManifestEntriesVerified':184,'frozenRulesVersion':2,'unchanged6f80LandRecoverySHA256':current['src/ai/bootstrap_1/land-recovery.ts'],'sourceConstantV7WoundedShare':0.35,'focus36FilterUnchanged':True,'validation':{'newAndExistingUnmedicatedTests':'26/26pass','tscExitCode':0,'confirmedToolSession':78243},'testLogSHA256':sha((out/'relevant-tests.log').read_bytes()),'tscLogSHA256':sha((out/'tsc.log').read_bytes()),'driverSHA256':sha((out/'replay-recovery-waypoint.ts').read_bytes()),'inputSHA256':sha((old/'complete-64800.json').read_bytes())}
(out/'candidate-prelaunch.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['runtimeSupportHashes','addedTestAndFixtureHashes']}))
