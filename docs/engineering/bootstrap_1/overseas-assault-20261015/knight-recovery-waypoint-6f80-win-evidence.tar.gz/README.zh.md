# 6f80 撤离复评 + 有限恢复航点：真实组合源证据

这是 `6f80a9365e591cbfba9148260806cd4f9033788e` 加先前未并入的空船撤离复评补丁、再加本次 typed recovery waypoint 的独立组合源。它不是当前 root/main、3bdb 或规则 3 的成绩，也不是普通 0 tick 起跑。规则仍为 2，冻结对手仍是已验证的 184 文件 manifest；生产 API 迁移等价基线未修改。原旧容器未提交改动的恢复缺口仍存在，未宣称已复制。

## 代码与归属

新增生产变更只在 `memory.ts` 和 `expedition-recovery.ts`。`naval.ts` 是原已封、结果混合的空船撤离复评补丁，本轮未继续修改。`land-recovery.ts` 与 6f80 逐字节相同，没有混入 457 的身体避让、满血等待、到达后 hold 或当前 root 的医疗修改。

已有 expedition/naval owner 只在实际发布临界无药患者的 `move + avoidCombat` 时记录 unitId→goal。claims 查询仅验证读取；当前原生命令坐标不匹配、队列或其他任务接管、跨岛、伤势不再符合、原生到达、重新生成医疗/cover 后释放。保留原 .35 临界，不将 focus 的 .36 过滤阈值混为恢复门槛。新 care 优先；不等待满血、无永久无药锁。

静态审阅限制：旧 goal 的敌武器覆盖复验当前使用 `sameGround(goal, foe)`，覆盖同陆地敌人。甲板、海船或隔水远程射击可以原生覆盖 goal，却不在这个分支的保证范围。没有观察到它是本真实续局的败因；不能因此宣称全武器安全。修订该边界需要另定源码，不能回写本次固定成绩。

## 实际执行顺序

1. `candidate-prelaunch.json` 于 2026-10-15 22:17:46 UTC 真实生成，早于聚焦原生执行。870 runtime/support 文件及新增测试/fixture 定版，1374 payload capsule 全部 SHA 复验，冻结 184 条全部复验。
2. 从已封、事件前捕获的原普通局 64800 完整 world/nextId/双方全部 memory 换码。正常双方 AI 实际运行至 68400，未发手工命令、改敌人、瞬移或削弱规则。初始三项恢复全真，结束源变化 0。首次发布航点 65115；首次 p0 command difference 65190。
3. 首差异比较是在相同候选前置 world/memory 上调用此前固定撤离源，旧 planner 忽略新字段。没有对照游戏 step/issue；它只证明 command query 首差异，不能称旧/新 memory 全前缀等价。元数据先改变，重复原生 move 也可改变 effects/nextId，不能隐去这些差异。
4. 从真实 65190 全输入 JSON 续到 65400，world/nextId/双方 memory/全部 issued commands/本岛 native hit facts 五项完全闭合。再从验证过的 65400 续至 66000 做每 tick 原生 HP/XP 诊断，同样五项闭合。不是额外普通局或全矩阵。
5. 同一固定组合源从真实 68400 完整输入续到自然胜负。每 1200 tick 保存完整 gzip world/nextId/双方 memory 与之前区间的全部 commands、native hits、永久出生/移除/建筑损失。分段只为保存，源和双方 AI 未换；到 144000 无胜者仍同进程同源继续。结果以 `continuation-report.json` 为准。
6. 自然结束后从前一个真实 1200 周期档原生复现末窗，不能虚构结束前检查点或将事后记录称作原始开局 prelaunch。

启动故障也保留：首次完整续局 driver 的 `isShipKind` import 写成 catalog，ESM 在函数体/还原/任何 tick 前失败。`continuation-setup-failed.ts/.log/.json` 保留原样，只修 driver 到 ship-geometry 后真实重启。112800 只读装载查询的首版误用 `services.ships`，实际是 `reserved`；失败源/log 同样保留，未推进游戏或改固定代码。查询仅使用独立 policy memory 副本。

## 聚焦原生成果与边界

68400 大厅1750为 900/900，三名近战仍存活：7014为130/350、2星；7043为37/210；7155为71/210。五名当地工人存活，但全部 idle，gold-seat4-main=0、整窗这些工人无 mine 指令，金币仅3.19。塔2001在64958实际死亡；没有“全防御建筑无损”或“采矿恢复”的结论。无敌军仍在该殖民岛地面。

7014 的血量增加是原生击杀升级：65425击杀空 transport 后 XP0→80、maxHP210→280、HP75→145；65701击杀弓手后 XP117→154、maxHP280→350、HP60→130。每次 +70 都由 `awardKillXp → applyXpLevel → applyDerivedUnitStats` 同步加最大与当前生命值。实际 queried regen/leadership regen 全为0，科技未变，不能称治疗。7014在HP75/210时本就高于 .35，不能把它的所有移动都归因于新记忆；新保留主要作用在7155/7043，改变了阵位和交战顺序。

三兵合计22次实际命中、506 raw damage，其中12次仍打空敌船1502；随后4次命中弓手1121、2次命中1791、4次命中敌工2，四个最终击杀均由7014完成。到达后的原生自动进攻仍存在：7155在65231到达→65232自动攻空船，7043在65366到达→65367自动攻船。没有虚构 hold 能关闭自动攻击，也没有把这次当成 focus/空船选敌修复。

实际航点清理见 `focused-outcome-audit.json`：到达后下一已捕获完整帧已移除；最终整张表不存在，后续原有 boarding 重新接管。这里只记录实际捕获粒度，未声称所有 think 都有帧。

此前仅空船撤离组合到68400三兵死亡、大厅612；原6f80普通局同tick大厅已失而三兵仍等远船。原普通局后来确实 p0 于135692自然获胜，不能将殖民地丢失等同整局失败，也不能凭本次局部存活声称胜率或速度已提升。

## 完整比赛观察方式

`continuation-frames/*.json.gz` 的 `previousInterval` 保存前一周期的全部 issued/native facts，因此末窗具备可复现输入、输出和命令。永久移除保留上一原生 tick 的实际 unit；船只另保留乘员和下一状态，不能把 expiresTick 中立/召唤过期当永久军全灭。清算还要与原生 match.stats 差额核对。帧/全策略存档采用完整序列化而不是 live reference。

112800真实查询：required15.536640848688922、global expedition ready；4船实装永久军 assembledPower24.827563121130257、无缺员/原生 board、service reserved为空。各船 nearbyPower 不足原门槛，所以既有 owner 设置同一 rally；其余3船确有 avoidCombat move。112800→120000 三船实际位移4364/6695/4513像素，不能把无新增击杀的海路集结段称无Move或死锁。新候选没有降低 required、替换 owner 或取消原登船/卸工/服务契约。

PNG 是事后对精确原生 world 调用真实 client drawWorld 的观察截图，非历史 live capture；没有修改快照或推进游戏。metadata 保存输入/渲染源/PNG SHA，均本人目视。不能用单张图代替完整比赛。

## 历史与运维限制

`historical-original0-reference.json` 只读记录原普通局最终结果和文件 SHA，且明确保留 `original-source-sparse-incident.json` 与 root 支持的恢复记录。此前错误 sparse 命令临时影响原正在运行的普通局文件可用性/磁盘压力；结束870 hash相同不能证明运行期间从未受影响。本候选由后来受控 no-checkout 小稀疏建立；原64800输入与只读诊断在该事件前已捕获封存。不得隐去原普通局这项运维证据限度。

本组合的一场换码续局只检验此真实局部修复在该整场的作用，不满足 bootstrap_1 三路线、v5/v7/v8 单对手及六配对、官方地图和未见种子的最终完整对局与泛化验收。任何自然胜负都应保留这个范围。


## 已闭合自然终局

同固定组合源在 **129158 tick 原生 p0 获胜**，52份完整周期/末帧。68400后累计摧毁敌15楼（14非基地），敌 townHall 于128959摧毁，最后 shipyard 于129158摧毁。3名原防守近战均实际登陆敌岛并生还：7014=350/350、2星；7043=272/280、1星；7155=210/210。原殖民大厅仍900。最终敌建筑0，但仍余敌工人1名，原生比赛已结束；不称全敌兵歼灭。

68400后己永久仅损失 lancer1275（128121），己船沉0。敌永久损失26、中立永久损失3；敌另损失临时 spirit9287：实际原生127992出生、expiresTick129192、128128被杀，不能混入永久军。唯一沉船为敌空 transport7921（68994），载员0；各owner unitsLost差额已逐项闭合。最终己方仍无mine命令工人，不称经济恢复。

纠正本次中间消息里7043“后续打野升1星”的过度归因：实际68994由7043击毁敌空transport7921，native damage23、before17→after-6，69600周期档已HP37→107/max210→280。后来的3个中立杀不是它此次升级来源。7014早期两次+70的原生逐tick证明不受此勘误影响。

后续恢复的周期 evidence 另记 `late-guard-recovery-periodic-evidence.json`：记录55HP级的后期增量和实际116400 snapshot的healing effect，但没有为每个后来治疗增量另造逐tick归因。原任务明确要求辨清的早期75→130已经实际逐tick验证为升级，不是治疗。终值仅是实际血量记录。

从真正128400周期档到129158末窗，以及127200→128400用于临时精灵清算的窗口，均正常双方AI实际复验：world、nextId、双方全部memory、全部issued commands、全部native hits、永久死亡、建筑死亡、永久出生、船载清算 **9项全等**，两窗运行源变化0。1374 capsule payload与实际所有live源码、870runtime/support+4新fixture/test、冻结184条全部复验。

相较历史未改6f80普通0的135692胜，本组合换码续局早6534tick；这是同历史前缀上的一个组合反事实，不是新普通0，不隔离单独waypoint的整体时间因果，也不是胜率或泛化证明。原普通局运维incident限度继续保留。不得把三兵存活、自然一胜、局部测试通过或这包封存当成完整bootstrap_1验收。
