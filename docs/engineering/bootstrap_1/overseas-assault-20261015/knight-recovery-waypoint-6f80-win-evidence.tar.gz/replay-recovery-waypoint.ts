import {readFileSync,writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/shared/sim.ts';
import {createAiMemoryProvider} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/scripts/bootstrap_1-planner.ts';
import {createBootstrapCommandPlanner as baselinePlannerFactory} from '/tmp/sketch-rts-knight-evacuation-6f80-control/scripts/bootstrap_1-planner.ts';
import {runAiGameLoop} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/ai/game-runner.ts';
import {sameGround} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/shared/terrain.ts';
import {unitMover} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/shared/catalog.ts';
import {shipPassengers} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/shared/ship-geometry.ts';

const out='/tmp/knight-recovery-waypoint-6f80',source='/tmp/sketch-rts-knight-recovery-waypoint-6f80-control',old='/tmp/knight-colony-defense-6f80';
const sha=(b:any)=>createHash('sha256').update(b).digest('hex'),norm=(v:any)=>JSON.parse(JSON.stringify(v));
const preflight=JSON.parse(readFileSync(out+'/candidate-prelaunch.json','utf8'));
const sourceChanges=()=>Object.entries({...preflight.runtimeSupportHashes,...preflight.addedTestAndFixtureHashes}).filter(([p,h])=>sha(readFileSync(source+'/'+p))!==h).map(([p])=>p);
if(sourceChanges().length||sha(readFileSync(import.meta.filename))!==preflight.driverSHA256)throw Error('prelaunch source/driver changed');
const saved=JSON.parse(readFileSync(old+'/complete-64800.json','utf8')),report=JSON.parse(readFileSync(old+'/original-report-captured.json','utf8')),expectedOriginal=JSON.parse(readFileSync(old+'/complete-68400.json','utf8'));
const g=createGame('bareDuel'),m=createAiMemoryProvider(),baselineMemory=createAiMemoryProvider();
restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);for(const[o,v]of Object.entries(saved.memories))m.set!(o,structuredClone(v) as any);
const full=()=>norm({snapshot:snapshotGame(g),nextId:g.nextId,memories:Object.fromEntries(['p0','p1'].map(o=>[o,m.get(o)]))});
const restored={world:isDeepStrictEqual(full().snapshot,saved.snapshot),nextId:g.nextId===saved.nextId,bothMemories:isDeepStrictEqual(full().memories,saved.memories)};if(Object.values(restored).some(x=>!x))throw Error('bad restore');
const planner=await createBootstrapCommandPlanner(m),baseline=await baselinePlannerFactory(baselineMemory),hallId='building-p0-townHall-1750',boatId='unit-p0-transport-4873',colony={x:2288,y:2736},guardIds=['unit-p0-footman-7014','unit-p0-footman-7043','unit-p0-footman-7155'];
const frames:any[]=[],issued:any[]=[],hits:any[]=[],plans:any[]=[],events:any[]=[],rows:any[]=[];let firstDifference:any, firstWaypointPublication:any;
const capture=(label:string)=>frames.push({label,...full()});
const localUnits=(s:any)=>s.units.filter((u:any)=>!u.deck&&unitMover(u.kind)==='land'&&sameGround(s.map,u,colony));
let previous=new Map(g.units.map((u:any)=>[u.id,{hp:u.hp,deck:u.deck?.shipId,order:structuredClone(u.order),owner:u.owner,kind:u.kind}])),previousBuildings=new Map(g.buildings.map((b:any)=>[b.id,{owner:b.owner,kind:b.kind,hp:b.hp,x:b.x,y:b.y}]));
g.observer={hit(s:any,t:any,d:number,b:number){if(sameGround(g.map,t,colony)||sameGround(g.map,s,colony)||t.id===hallId)hits.push({tick:g.tick,sourceId:s.id,sourceKind:s.kind,targetId:t.id,targetKind:t.kind,damage:d,before:b,after:t.hp})}};
capture('start');
runAiGameLoop({name:'Independent typed recovery waypoint plus evacuation actual bothAI64800to68400',game:g,agents:report.setup.agents,maxTicks:68400,thinkInterval:15,commandPlanner:(ctx:any)=>{
  if(ctx.owner!=='p0')return planner(ctx);
  const before=structuredClone(m.get('p0')),entries=planner(ctx),after=structuredClone(m.get('p0')),bm=before.naval?.ferries?.[boatId],am=after.naval?.ferries?.[boatId];
  if(!firstWaypointPublication && after.naval?.recoveryWaypoints && !isDeepStrictEqual(before.naval?.recoveryWaypoints,after.naval.recoveryWaypoints)){firstWaypointPublication={tick:ctx.snapshot.tick,snapshot:norm(ctx.snapshot),nextId:g.nextId,memories:{p0:before,p1:structuredClone(m.get('p1'))},after,entries:norm(entries)};writeFileSync(out+'/first-waypoint-publication.json',JSON.stringify(firstWaypointPublication));console.log(JSON.stringify({firstWaypointPublication:ctx.snapshot.tick}));}
  if(!firstDifference){baselineMemory.set!('p0',structuredClone(before));const originalEntries=baseline(ctx),baselineAfter=norm(baselineMemory.get('p0'));if(!isDeepStrictEqual(norm(entries),norm(originalEntries))){
    firstDifference={tick:ctx.snapshot.tick,classification:'Actual first p0 command difference against fixed6f80+empty-evacuation source querying the identical pre-plan world and candidate-before policy memory; the old planner ignores the new typed field. This is a command query, not an assertion that old/new fullmem match. No baseline commands issued and no second game stepped.',snapshot:norm(ctx.snapshot),nextId:g.nextId,memories:{p0:before,p1:structuredClone(m.get('p1'))},candidateEntries:norm(entries),originalEntries:norm(originalEntries),candidateMemory:after,originalMemory:baselineAfter};
    writeFileSync(out+'/first-planning-difference.json',JSON.stringify(firstDifference));console.log(JSON.stringify({firstPlanningDifference:ctx.snapshot.tick,candidateMission:am?.phase,oldMission:baselineAfter.naval?.ferries?.[boatId]?.phase}));
  }}
  if(ctx.snapshot.tick%60===0||bm?.phase!==am?.phase||bm?.purpose!==am?.purpose||entries.some((e:any)=>e.command.type==='stop'&&e.command.unitIds?.some((id:string)=>guardIds.includes(id)))){
    plans.push({tick:ctx.snapshot.tick,before,after,colonyUnits:structuredClone(localUnits(ctx.snapshot)),colonyBuildings:ctx.snapshot.buildings.filter((b:any)=>sameGround(ctx.snapshot.map,b,colony)),boat:structuredClone(ctx.snapshot.units.find((u:any)=>u.id===boatId)),entries});
    if(bm?.phase!==am?.phase||bm?.purpose!==am?.purpose)events.push({tick:ctx.snapshot.tick,type:'actual-planned-evacuation-transition',before:bm,after:am});
  }return entries;
}},{onCommand(e:any){issued.push({tick:e.tick,owner:e.owner,scriptId:e.scriptId,command:structuredClone(e.command)})},onStep(){
  const now=new Map(g.units.map((u:any)=>[u.id,{hp:u.hp,deck:u.deck?.shipId,order:structuredClone(u.order),owner:u.owner,kind:u.kind}]));
  for(const u of g.units){const old:any=previous.get(u.id);if(guardIds.includes(u.id)||u.owner==='p0'&&u.kind==='worker'&&sameGround(g.map,u,colony)){
    if(!old||old.deck!==u.deck?.shipId||old.order.type!==u.order.type){events.push({tick:g.tick,type:'actual-own-colony-unit-state-change',unit:structuredClone(u),previous:old});capture('actual-unit-state-change');}
  }}
  for(const[id,u]of previous)if(!now.has(id)&&guardIds.includes(id))events.push({tick:g.tick,type:'actual-guard-removed',id,previous:u});
  const buildings=new Map(g.buildings.map((b:any)=>[b.id,{owner:b.owner,kind:b.kind,hp:b.hp,x:b.x,y:b.y}]));
  for(const[id,b]of previousBuildings)if(!buildings.has(id)&&sameGround(g.map,b,colony)){events.push({tick:g.tick,type:'actual-colony-building-removed',id,...b});capture('actual-colony-building-removed');}
  previous=now;previousBuildings=buildings;
  if(g.tick%60===0){const s=snapshotGame(g),hall=g.buildings.find((b:any)=>b.id===hallId),boat=g.units.find((u:any)=>u.id===boatId);rows.push({tick:g.tick,hallHp:hall?.hp,gold:g.players.p0.gold,boat:boat&&{x:boat.x,y:boat.y,hp:boat.hp,order:structuredClone(boat.order),sailing:structuredClone(boat.sailing)},aboard:boat&&shipPassengers(g.units,boat).map(u=>u.id),mission:structuredClone(m.get('p0')?.naval?.ferries?.[boatId]),localUnits:structuredClone(localUnits(s))});capture('sample');if(g.tick%300===0)console.log(JSON.stringify({tick:g.tick,hallHp:hall?.hp,gold:g.players.p0.gold,guards:g.units.filter((u:any)=>guardIds.includes(u.id)).map((u:any)=>({id:u.id,hp:u.hp,order:u.order})),boat:boat&&{x:boat.x,y:boat.y,hp:boat.hp},mission:m.get('p0')?.naval?.ferries?.[boatId]?.purpose}));}
}});
capture('terminal');const final=full();
writeFileSync(out+'/candidate64800-68400.json',JSON.stringify({classification:'Actual isolated typed-recovery-waypoint plus prior empty-evacuation changed-code focused bothAI continuation from6f80, with no457/bodyavoidance. Not ordinary0 or fullgame/acceptance. No manual commands, enemy edits, unit teleport or rules/frozen changes. First baseline planner difference is a query only.',prelaunchSHA256:sha(readFileSync(out+'/candidate-prelaunch.json')),restored,sourceChanges:sourceChanges(),start:64800,end:g.tick,firstPlanningDifferenceTick:firstDifference?.tick,firstWaypointPublicationTick:firstWaypointPublication?.tick,agents:report.setup.agents,plans,issued,hits,events,rows,final,original68400Reference:{hall:expectedOriginal.snapshot.buildings.find((b:any)=>b.id===hallId),guards:expectedOriginal.snapshot.units.filter((u:any)=>guardIds.includes(u.id)),gold:expectedOriginal.snapshot.players.p0.gold}}));
writeFileSync(out+'/candidate64800-68400-frames.json.gz',gzipSync(JSON.stringify(frames)));console.log(JSON.stringify({done:true,end:g.tick,firstPlanningDifferenceTick:firstDifference?.tick,sourceChanges:sourceChanges(),winner:g.match.winner,hall:g.buildings.find((b:any)=>b.id===hallId),guardSurvivors:g.units.filter((u:any)=>guardIds.includes(u.id)).map((u:any)=>({id:u.id,hp:u.hp,order:u.order}))}));
