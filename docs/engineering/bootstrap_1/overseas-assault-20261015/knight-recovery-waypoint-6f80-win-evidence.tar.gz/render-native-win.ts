import {createCanvas} from '@napi-rs/canvas';
import {readFileSync, writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {installHeadlessCanvas} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/recorder/record.ts';
import {drawWorld} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control/src/client/unit-facing.ts';

const out = '/tmp/knight-recovery-waypoint-6f80';
const source = '/tmp/sketch-rts-knight-recovery-waypoint-6f80-control';
const sha = (b: any) => createHash('sha256').update(b).digest('hex');
const frames = JSON.parse(gunzipSync(readFileSync(out + '/candidate64800-68400-frames.json.gz')).toString());
installHeadlessCanvas();
const records: any[] = [];
for (const spec of [
 {label:'native-combo-natural-win-enemy-base-129158',tick:129158,input:'visual-input-natural-win.json',view:{x:1400,y:5600,width:1600,height:1600,zoom:1.0}}
]) {
  const frame = spec.input.endsWith('.gz')
    ? frames.find((f: any) => f.snapshot.tick === spec.tick)
    : JSON.parse(readFileSync(out + '/' + spec.input, 'utf8'));
  if (!frame || frame.snapshot.tick !== spec.tick) throw Error('missing exact frame ' + spec.tick);
  const before = sha(JSON.stringify(frame));
  const canvas = createCanvas(spec.view.width, spec.view.height);
  drawWorld({ctx:canvas.getContext('2d') as any,snapshot:frame.snapshot,view:spec.view,now:spec.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
  const png = canvas.toBuffer('image/png');
  writeFileSync(out + '/' + spec.label + '.png', png);
  const after = sha(JSON.stringify(frame));
  if (before !== after) throw Error('renderer changed frame');
  records.push({...spec,pngSha256:sha(png),snapshotSha256:sha(JSON.stringify(frame.snapshot)),inputSha256:sha(readFileSync(out+'/'+spec.input)),fullInputUnchanged:true});
}
writeFileSync(out + '/native-win-render-metadata.json', JSON.stringify({classification:'Post-run native client drawWorld renders of exact changed-code64800/samecombo68400 game worlds; not historical live captures or replayed animation. No snapshot edits or game steps.',source,records,renderSourceHashes:Object.fromEntries(['src/recorder/record.ts','src/client/world-renderer.ts','src/client/unit-facing.ts'].map(p=>[p,sha(readFileSync(source+'/'+p))]))},null,2));
console.log(JSON.stringify(records));
