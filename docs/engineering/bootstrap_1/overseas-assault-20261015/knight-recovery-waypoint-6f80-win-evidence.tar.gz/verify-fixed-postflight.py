import json,hashlib,tarfile,subprocess,datetime
from pathlib import Path
root=Path('/tmp/sketch-rts-knight-recovery-waypoint-6f80-control');out=Path('/tmp/knight-recovery-waypoint-6f80');sha=lambda b:hashlib.sha256(b).hexdigest();pre=json.loads((out/'candidate-prelaunch.json').read_bytes());assert root.resolve()==root
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip();assert head==pre['baseCommit'];hashes={**pre['runtimeSupportHashes'],**pre['addedTestAndFixtureHashes']};changes=[p for p,h in hashes.items()if sha((root/p).read_bytes())!=h];assert not changes,changes
with tarfile.open(out/'candidate-source-capsule.tar.gz','r:gz')as t:
 idx=json.load(t.extractfile('INDEX.json'));files=idx['files'];assert len(files)==1374 and set(t.getnames())==set(files)|{'INDEX.json'}
 for p,h in files.items():
  b=t.extractfile(p).read();assert sha(b)==h,p
  if p.startswith('live/'):
   assert sha((root/p[5:]).read_bytes())==h,p
 frozen=json.load(t.extractfile('frozen-policy.json'));assert frozen['rulesVersion']==2 and len(frozen['files'])==184
 assert all(sha(t.extractfile('frozen/'+p).read())==h for p,h in frozen['files'].items())
report=json.loads((out/'continuation-report.json').read_bytes());result={'classification':'Actual postflight after fixed combo continuation completion, notprelaunch. Every1374 capsule payload rehashed, all live capsule entries equal actualfixedsource,870runtime/support plus4newtestfiles unchanged; frozen184 remainrule2.','actualTime':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':head,'completed':report['completed'],'end':report['end'],'winner':report['winner'],'runtimeSupportCount':len(pre['runtimeSupportHashes']),'addedTestAndFixtureCount':len(pre['addedTestAndFixtureHashes']),'runtimeChanges':changes,'allCapsulePayloadsVerified':len(files),'allCapsuleLiveEntriesEqualSource':True,'frozenEntriesVerified':184,'frozenRulesVersion':2,'sourceCapsuleSHA256':sha((out/'candidate-source-capsule.tar.gz').read_bytes()),'prelaunchSHA256':sha((out/'candidate-prelaunch.json').read_bytes())};assert report['completed'] and report['winner'];(out/'final-source-postflight.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
