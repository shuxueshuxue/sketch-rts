# Loading escort: source-fixed native audit and changed-history experiment

This package closes a narrow loading-escort candidate. It is not a bootstrap acceptance win. Original ordinary tick0 exact6f80 knight-v5 sapphire completed naturally at135692 withp0 winner; that match remains a separate history. The candidate starts by changing code at original50400, continues with both normal AIs to62400, and has no winner or enemy-island landing.

## Source and scope

RulesVersion2, frozen184 manifest/API migration unchanged. Seed bootstrap_1-knight-v5-official-sapphire-20261015-01, sapphireArchipelago, Grovev9_knight p0 vs normal frozen Emberv5 p1. Source6f80 plus exactly one naval.ts station change: an assigned escort follows its current ferry while loading, as it already did while sailing/returning. No v2 neutral filter, risk160/margin1800 change, repair priority, ship rule, opponent weakening, manual game command, body move or private route injection. TypeScript check passed. Candidate865 source files and original870 runtime/support files still exactly match captures after all execution. Controls were created sparse before checkout; root/main and active ordinary source never changed.

## Original six-checkpoint read-only evidence

Inputs49200/50400/51600/52800/54000/55200 contain original world,nextId,all both-owner memories, original frame/report/sourceSHA provenance. Public full planner queries were made on independent clones, never applied. Native helper reconstruction is labeled as reconstruction, not observed execution. Reusing previous v2 objective filter produces exactly the same public commands at all six checkpoints; no v2 game was launched here.

At49200 loaded1046 isreturn; only1935 is inside1800 (direct876/sea915.2). Three early held hulls are too far. At50400 only1935 is assigned1046 (618/665.6); at51600 it is assigned4595 (522/544). No service/outfit occupancy exists in these two assignments. Their loading station is the enemy coast(2602.31,6434.21), refused by5 sparkArchers under unchanged risk. Original code explicitly said: While loading, clear and cover the landing coast. This is an intended forward-clearance role; the candidate deliberately changes that role to close loading protection. It does not establish that all forward coastal clearing should be removed.

At52800 the original1935 already escorts the sailing carrier with an existing move. By54000/55200 1101 and1139 actually escort the two front ferries.1064+1935 are then reserved by worker1851's real repair-board rendezvous; four nominal guns are not four available escorts. The exact first eligibility transition lies between the1200tick original samples; the read-only audit does not invent a precise first tick.

## Candidate red-to-green and native sequence

Original50400/51600 full-planner1935 queries change from no command/remote risk to actual current ferry/no risk and public move. loading-escort-red-green-proof.json records exact commands. Source-fixed50400→51600 native bothAI1200ticks:1935 moves1563.972px, ends293.515px from loaded1046 instead of original1760.657px, remains464HP.0projectiles,0hits,0losses. This proves physical following only.

Same source, actual51600 state→56400:0deaths and0proper landings.9hits include8friendly hull collisions and1ballista shot at a neutral whelp. At56400 both ferries still physically progress (speed48.11 and7.34; routes complete,blockedTicks0), current native passenger landings do not exist yet; their goal berths are clear. Direct boat separation437.865 but sea road454.4 exceeds450; normal next planner stops the leader and regroups. This is not a completed safe assault.

Same actual56400 world/id/bothmem→62400:600tick gzip frames plus every original17 status change. First deck deaths57775/57911, third58226. At58035 both boats issue public unload to their origin withavoidCombat and enterreturn. Causal57600→58200 replay captures missing58035 and closes exact world,nextId,bothmem against the already executed mainline. Actual incomingPower21.069240969938075<required21.18227351727268; no armed enemy ship within900. Do not lower the requirement from this result.

No original17 unit ever lands on the enemy island. At59968 the first survivor exits onto the central neutral dragon island (about4923,6036).8carrier survivors eventually leave there; one knight later dies to neutral fire. Final17 partition:7otherLand alive+6on1046deck+4dead; wholep0loss4,p1loss0,neutralLoss6. Enemy36units/14buildings/hall900 remain. Candidate remains a failed first enemy-island deployment; casualties may be delayed, not solved. Native images were personally inspected and show the ships returning via the dragon island and the surviving land force there.

## Real saved-event restore limitation

Every one of the10 saved600tick periodic frames57000..62400 passes read-only exact world values,nextId,bothmem restore. Three shipboard death-event frames57775/57911/58226 do not restore field-for-field: restore recomputes stale carrier.sailing.load/balance after a passenger dies late in the tick. These are real value differences, not JSON key order.57911 restore attempt failed before any simulation; full failurelog and precise diff are retained. That event frame must not independently be used as an exact continuation origin. Original mainline execution and its validated50400/51600/56400 starts remain valid. No restore/engine/rules change was made. The successful causal replay instead starts from verified57600 and proves58200 exact equality.

## Remaining service boundary (read only)

1935 follows the loaded boat early, but worker1851 requests boarding cutter1139 at53430 after a0.5005 friendly collision injury.54150 a physical yielding task leaves workerfollow1935 plus queuedboard1139. At62400 both damaged hulls remain reserved. They are77.93 apart, native decksCanTransfer=true, canBoard=false, connected pathnull, no lane/service/public commands. Targetcutter carries only one witch (85mass, capacity784.08); the worker has no free physical deck position. Native unoccupied-floor placement exists. Read-only projected witch poses include30 that admit the worker and9 complete native connected crossings; none was applied to the running world. Existing clearDeckTransfers skips at!canBoard before trying its bystander yielding routine, while service reservations persist. This motivates the next independent lane-feasibility candidate, not an untested repair priority change. This fixed loading-escort source and its results must remain immutable.
