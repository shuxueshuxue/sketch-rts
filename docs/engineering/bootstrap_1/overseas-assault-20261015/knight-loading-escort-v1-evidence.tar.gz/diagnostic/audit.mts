import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const wd=process.argv[2],out=process.argv[3],D='/tmp/bootstrap-knight-escort-audit-20261015',imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const [{navalUnitIds},{navalServices},{fleetStations},{fleetTarget},{bootstrapPolicyContext},{planAiOwnerCommandEntries},{mountedMinePlan},{combatCapability},{canReach,shipPassengers:unused},{shipPassengers,shipProfile},{combatHull},{setBuildingBodies,isWalkable,sameGround,walkingDistance},{automaticShoreTargetReachable,shoreFiringStation},{outmatchingCoast},{isEnemyOwner,isOpponentOwner},{unitMover,BUILDING_DEFS}]=await Promise.all([imp('src/ai/policy/naval.ts'),imp('src/ai/policy/naval-services.ts'),imp('src/ai/policy/fleet-formation.ts'),imp('src/ai/policy/fleet-engagement.ts'),imp('src/ai/bootstrap_1/policy.ts'),imp('src/ai/planner-context.ts'),imp('src/ai/policy/mounted-mine-plan.ts'),imp('src/shared/combat-capabilities.ts'),imp('src/shared/naval.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/ship-defense.ts'),imp('src/shared/terrain.ts'),imp('src/shared/shore-fire.ts'),imp('src/ai/policy/coastal-risk.ts'),imp('src/ai/policy/ownership.ts'),imp('src/shared/catalog.ts')]);
const candidateFilter=wd.includes('shore-v2')?(await imp('src/ai/bootstrap_1/coastal-objectives.ts')).coastalTargetAvailable:undefined;
const dist=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y),owner='p0',reports=[];
function offshore(s:any,landing:any,from:any){const step=s.map.terrain?.cell??32,l=dist(landing,from)||1;for(let k=1;k<=8;k++){const p={x:landing.x+(landing.x-from.x)/l*step*k,y:landing.y+(landing.y-from.y)/l*step*k};if(isWalkable(s.map,p.x,p.y,'sea')&&!isWalkable(s.map,p.x,p.y))return p;}return landing;}
for(const tick of [49200,50400,51600,52800,54000,55200]){
 const input=D+'/input-original-'+tick+'.json',original=JSON.parse(readFileSync(input,'utf8'));
 // Public planner reads its own separate full checkpoint clone. No commands are applied.
 const queried=structuredClone(original);setBuildingBodies(queried.snapshot.map,[...queried.snapshot.buildings,...(queried.snapshot.obstacles??[])]);
 const entries=planAiOwnerCommandEntries(queried.snapshot,{playerId:owner,version:'v9_knight'},{teams:queried.snapshot.teams,memory:queried.memories.p0});
 const f=structuredClone(original),s=f.snapshot,memory=f.memories.p0;setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const options=bootstrapPolicyContext(s,owner,'v9_knight',{teams:s.teams,memory});
 const beforeOutfit=structuredClone(memory.naval?.outfit),beforeCombat=structuredClone(memory.naval?.combat);
 // This public ownership query invokes the exact native outfitting and service owners.
 navalUnitIds(s,owner,options,()=>true);
 const services=navalServices(s,owner,options),outfit=memory.naval?.outfit,own=s.units.filter((u:any)=>u.owner===owner&&u.hp>0),hulls=own.filter((u:any)=>shipProfile(u));
 const ferries=memory.naval?.ferries??{},convoy=hulls.filter((u:any)=>shipPassengers(s.units,u).length&&ferries[u.id]?.purpose!=='creep'&&!combatHull(u));
 const fighters=own.filter((u:any)=>combatHull(u)&&combatCapability(s,u).armed&&!services.reserved.has(u.id)&&u.id!==outfit?.shipId&&!ferries[u.id]);
 const escorts=new Map<string,any>();
 for(const ship of fighters.filter((u:any)=>u.kind!=='bombardShip')){
  const boat=[...convoy].filter((b:any)=>sameGround(s.map,ship,b,'sea')&&dist(ship,b)<1800&&[...escorts.values()].filter((e:any)=>e.id===b.id).length<2).sort((a:any,b:any)=>[...escorts.values()].filter((e:any)=>e.id===a.id).length-[...escorts.values()].filter((e:any)=>e.id===b.id).length||dist(ship,a)-dist(ship,b))[0];if(boat)escorts.set(ship.id,boat);
 }
 const assault=memory.naval?.assault?.plan,targetBuilding=assault&&s.buildings.find((b:any)=>b.id===assault.targetId),goal=targetBuilding?offshore(s,assault.landing,targetBuilding):undefined;
 const stations=fleetStations(s,fighters.filter((u:any)=>!escorts.has(u.id)&&u.hp>=u.maxHp*.4),goal,memory.naval),mines=mountedMinePlan(s,memory),foes=[...s.units,...s.buildings].filter((u:any)=>isEnemyOwner(s,owner,u.owner,options));
 const ships=[];
 for(const ship of hulls){
  const boat=escorts.get(ship.id),mission=boat&&ferries[boat.id],pre=beforeCombat?.[ship.id];
  const row:any={id:ship.id,kind:ship.kind,position:{x:ship.x,y:ship.y},hp:ship.hp,maxHp:ship.maxHp,order:ship.order,weapon:combatCapability(s,ship),crew:shipPassengers(s.units,ship).map((u:any)=>({id:u.id,kind:u.kind,order:u.order})),fighter: fighters.some((u:any)=>u.id===ship.id),serviceReserved:services.reserved.has(ship.id),outfitReserved:outfit?.shipId===ship.id,ownMission:ferries[ship.id],savedCombat:pre,escort:boat?.id,convoyDistances:convoy.map((b:any)=>({id:b.id,phase:ferries[b.id]?.phase,purpose:ferries[b.id]?.purpose,crew:shipPassengers(s.units,b).length,direct:dist(ship,b),seaRoad:walkingDistance(s.map,ship,b,'sea'),sameSea:sameGround(s.map,ship,b,'sea'),inside1800:dist(ship,b)<1800})),publicShipCommands:entries.filter((e:any)=>'unitIds'in e.command&&e.command.unitIds.includes(ship.id)).map((e:any)=>({scriptId:e.scriptId,command:e.command}))};
  if(row.fighter){
   const local=foes.filter((t:any)=>dist(ship,t)<Math.max(900,combatCapability(s,ship).range+150)&&canReach(s.map,ship,t,s.units,combatCapability(s,ship).range)&&automaticShoreTargetReachable(s,ship,t));
   const danger=local.filter((t:any)=>'order'in t&&combatCapability(s,t).armed);
   const towers=s.buildings.filter((b:any)=>b.kind==='defenseTower'&&b.complete&&isOpponentOwner(s,owner,b.owner,options));
   const targets=local.filter((t:any)=>mines.targetAvailable(t)&&(ship.kind==='bombardShip'||!towers.some((twr:any)=>dist(twr,t)<=BUILDING_DEFS.defenseTower.attackRange))).sort((a:any,b:any)=>(ship.kind==='bombardShip'?Number('order'in a)-Number('order'in b):Number(!('order'in a))-Number(!('order'in b)))||dist(a,ship)-dist(b,ship));
   const station=boat?(mission?.phase==='loading'?offshore(s,mission.to,foes.find((t:any)=>t.id===mission.targetId)??mission.to):boat):stations.get(ship.id)??goal;
   const attackers=boat?danger.filter((t:any)=>'order'in t&&(dist(t,boat)<combatCapability(s,t).range+160||t.order.type==='attack'&&t.order.targetId===boat.id)):[];
   const gathering=stations.has(ship.id)&&!memory.naval.muster?.launched;
   const threats=danger.filter((t:any)=>'order'in t&&unitMover(t.kind)==='sea'&&(!gathering||dist(ship,t)<combatCapability(s,ship).range+100)&&(!boat||dist(t,boat)<700||station&&dist(t,station)<700));
   const candidates=attackers.length?attackers:threats.length?threats:!gathering&&(!boat||station&&dist(ship,station)<250)?targets.filter((t:any)=>!boat||station&&dist(t,station)<450):[];
   const available=candidateFilter?candidates.filter((t:any)=>candidateFilter(s,owner,options,ship,t)):candidates;
   const chosen=fleetTarget(ship,available,memory.naval),fire=chosen&&(!('order'in chosen)||unitMover(chosen.kind)==='land')?shoreFiringStation(s,ship,chosen):undefined,destination=fire??station,immediate=outmatchingCoast(s,owner,ship,ship,options),rejected=immediate.length?immediate:destination?outmatchingCoast(s,owner,ship,destination,options):[];
   const info=(u:any)=>({id:u.id,kind:u.kind,owner:u.owner,order:u.order,x:u.x,y:u.y});
   Object.assign(row,{waiting:own.filter((u:any)=>u.order.type==='board'&&u.order.transportId===ship.id).map((u:any)=>u.id),station:station&&{x:station.x,y:station.y},stationSeaRoad:station?walkingDistance(s.map,ship,station,'sea'):undefined,gathering,candidates:candidates.map(info),available:available.map(info),chosen:chosen&&info(chosen),nativeFiringStation:fire,destination:destination&&{x:destination.x,y:destination.y},immediateCoast:immediate.map(info),destinationRejected:rejected.map(info),modelNote:'Read-only reconstruction of non-bombardment branches from unchanged naval.ts; publicShipCommands are direct full planner query, not applied gameplay.'});
  }
  ships.push(row);
 }
 reports.push({tick,input,inputSha256:hash(input),outfitBefore:beforeOutfit,outfitAfterNativeOwnership:outfit,serviceReserved:[...services.reserved],serviceCommands:services.commands,fleetGoal:goal,convoy:convoy.map((b:any)=>({id:b.id,mission:ferries[b.id],crew:shipPassengers(s.units,b).map((u:any)=>u.id)})),escorts:[...escorts].map(([ship,boat])=>({ship,boat:boat.id})),ships,allPublicPlannerCommands:entries,postPlannerNavalMemory:queried.memories.p0.naval});
}
writeFileSync(out,JSON.stringify({classification:'Read-only full-checkpoint public planner plus independent source-matched geometry reconstruction, no gameplay commands applied/no simulation advanced/no edits to original source',sourceRoot:wd,reports},null,2)+'\n');console.log(JSON.stringify(reports.map(r=>({tick:r.tick,escorts:r.escorts,services:r.serviceReserved,ships:r.ships.filter((x:any)=>x.fighter).map((x:any)=>({id:x.id,boat:x.escort,chosen:x.chosen?.id,destinationRisk:x.destinationRejected?.length,commands:x.publicShipCommands}))})),null,2));
