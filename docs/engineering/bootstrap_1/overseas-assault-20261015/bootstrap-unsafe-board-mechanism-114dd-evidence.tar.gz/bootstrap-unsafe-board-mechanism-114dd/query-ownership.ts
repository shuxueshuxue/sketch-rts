import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
const source='/tmp/sketch-rts-workforce-destination-v1-control',dir='/tmp/bootstrap-workforce-destination-v1-20261015',out='/tmp/bootstrap-unsafe-board-mechanism-114dd',imp=(p:string)=>import(pathToFileURL(source+'/'+p).href),norm=(x:any)=>JSON.parse(JSON.stringify(x));
const [sim,policy,planner,geom]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/bootstrap_1/policy.ts'),imp('src/ai/planner-context.ts'),imp('src/shared/ship-geometry.ts')]);
const full=JSON.parse(readFileSync(dir+'/candidate-v1/result.json','utf8')),diag=JSON.parse(readFileSync(dir+'/worker-loss-diagnostic/result.json','utf8'));
const cases=[];
for(const[tick,id]of [[134160,'unit-p0-worker-3'],[134580,'unit-p0-worker-11845'],[135000,'unit-p0-worker-13542']]as const){
 const path=dir+'/worker-loss-diagnostic/'+readdirSync(dir+'/worker-loss-diagnostic').find(p=>p.startsWith(tick+'-')&&p.includes('complete-before-think'));
 const input=JSON.parse(gunzipSync(readFileSync(path)).toString()),game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);const snapshot=sim.snapshotGame(game),worldBefore=norm(snapshot),worker=snapshot.units.find((u:any)=>u.id===id)!,teams=Object.fromEntries(Object.entries(full.setup.agents).map(([id,a]:[string,any])=>[id,a.team]));
 const memory=structuredClone(input.memories.p0),options=policy.bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory,teams}),scripts=policy.bootstrapScripts('v9_knight');
 const claims=scripts.map((s:any)=>({script:s.id,claimsWorker:!!s.claimsUnits?.(snapshot,'p0',options)?.has(id)})).filter((s:any)=>s.claimsWorker);
 const entries=planner.planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_knight',memory:structuredClone(input.memories.p0)},{teams});
 const actual=full.commands.filter((x:any)=>x.tick===tick&&x.owner==='p0').map(({scriptId,command}:any)=>({scriptId,command}));
 const queried=entries.map(({scriptId,command}:any)=>({scriptId,command}));
 const includes=(c:any)=>'unitIds'in c?c.unitIds.includes(id):'unitId'in c&&c.unitId===id;
 const boat=snapshot.units.find((u:any)=>u.id===worker.order.transportId);
 cases.push({tick,id,input:path,worker:{x:worker.x,y:worker.y,hp:worker.hp,maxHp:worker.maxHp,order:worker.order,orderQueue:worker.orderQueue},boat:{x:boat.x,y:boat.y,order:boat.order,hullGapToWaitingShore:geom.distanceToHull(boat,worker),requestedRouteGoal:boat.sailing?.route&&{x:boat.sailing.route.goalX,y:boat.sailing.route.goalY}},claimsInStackOrder:claims,queriedCommandsForWorker:queried.filter((x:any)=>includes(x.command)),entireQueriedP0FrameEqualsActual:isDeepStrictEqual(norm(queried),norm(actual)),snapshotUnchanged:isDeepStrictEqual(worldBefore,norm(snapshot)),actualCommands:actual});
}
const deathHull=diag.frames.filter((f:any)=>f.label==='after-native-death').map((f:any)=>{const s=JSON.parse(gunzipSync(readFileSync(dir+'/worker-loss-diagnostic/'+f.path)).toString()).snapshot,b=s.units.find((u:any)=>u.id==='unit-p0-carrier-6933');return{tick:s.tick,x:b.x,y:b.y,hullGapToSharedShore:geom.distanceToHull(b,{x:4240,y:5584}),boardingReach:39,order:b.order,routeGoal:b.sailing?.route&&{x:b.sailing.route.goalX,y:b.sailing.route.goalY}};});
const intervals=['unit-p0-worker-3','unit-p0-worker-11845','unit-p0-worker-13542'].map(id=>{const obs=diag.observations.flatMap((o:any)=>o.units.filter((u:any)=>u.id===id).map((u:any)=>({tick:o.tick,...u}))),shore=obs.filter((u:any)=>u.x===4240&&u.y===5584),low=obs.filter((u:any)=>u.hp===2);return{id,firstSampledAtBerth:shore[0]?.tick,lastSampledAtBerth:shore.at(-1)?.tick,firstSampledHP2:low[0]?.tick,lastSampledHP2:low.at(-1)?.tick,death:diag.deaths.find((x:any)=>x.before.id===id)?.tick,sampling:'15-tick observations134100→135300, so first sample is not necessarily first actual arrival'};});
writeFileSync(out+'/ownership-query.json',JSON.stringify({classification:'No stepping: actual complete before-think snapshots, cloned policy memories, pure current p0 full planner/ownership queries. All three p0 command frames compare with the real same-code diagnostic/continuation logs.',source,cases,deathHull,intervals},null,2)+'\n');
console.log(JSON.stringify({cases:cases.map(({actualCommands,...c})=>c),deathHull,intervals},null,2));
