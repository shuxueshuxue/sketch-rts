import { readFileSync, writeFileSync } from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/tmp/sketch-rts-workforce-destination-v1-control',directory='/tmp/bootstrap-unsafe-board-mechanism-114dd';
const imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const [{createCanvas},{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([imp('node_modules/@napi-rs/canvas/index.js'),imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const input='/tmp/bootstrap-workforce-destination-v1-20261015/worker-loss-diagnostic/134175-7-complete-before-think.json.gz';
const {snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
const views={coast:{x:4050,y:5250,width:1500,height:950,zoom:1},voyage:{x:2350,y:5100,width:1800,height:1000,zoom:.55}};
for(const[name,view]of Object.entries(views)){const canvas=createCanvas(view.width,view.height);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(directory+'/native134175-'+name+'.png',canvas.toBuffer('image/png'));}
writeFileSync(directory+'/native-visual.json',JSON.stringify({classification:'Native drawWorld of actual134175 complete world; no simulation/geometry edits. New facing tracker does not reconstruct historical animation.',source,input,views},null,2)+'\n');
