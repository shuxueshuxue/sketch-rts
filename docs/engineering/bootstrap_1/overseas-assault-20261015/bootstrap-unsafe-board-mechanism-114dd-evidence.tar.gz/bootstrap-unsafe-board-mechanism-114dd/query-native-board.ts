import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
const source='/tmp/sketch-rts-workforce-destination-v1-control';
const dir='/tmp/bootstrap-workforce-destination-v1-20261015';
const out='/tmp/bootstrap-unsafe-board-mechanism-114dd';
const imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const [sim,naval,terrain,routes,geom,math,policy,care]=await Promise.all([imp('src/shared/sim.ts'),imp('src/shared/naval.ts'),imp('src/shared/terrain.ts'),imp('src/shared/route-selection.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/navigation-math.ts'),imp('src/ai/policy/naval.ts'),imp('src/ai/bootstrap_1/land-recovery.ts')]);
const full=JSON.parse(readFileSync(dir+'/candidate-v1/result.json','utf8'));
const load=(p:string)=>JSON.parse(gunzipSync(readFileSync(p)).toString());
const norm=(x:any)=>JSON.parse(JSON.stringify(x));
const point=(u:any)=>({id:u.id,kind:u.kind,owner:u.owner,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,attackRange:u.attackRange,attackDamage:u.attackDamage,order:u.order,deck:u.deck,sailing:u.sailing});
const cases:any[]=[];
for(const [tick,id] of [[134175,'unit-p0-worker-11845'],[134595,'unit-p0-worker-13542']] as const){
 const path=dir+'/worker-loss-diagnostic/'+readdirSync(dir+'/worker-loss-diagnostic').find(p=>p.startsWith(tick+'-')&&p.includes('complete-before-think'))!;
 const input=load(path),game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
 const snapshot=sim.snapshotGame(game),before=norm(snapshot),boat=snapshot.units.find((u:any)=>u.id==='unit-p0-carrier-6933')!,worker=snapshot.units.find((u:any)=>u.id===id)!,mission=input.memories.p0.naval.ferries[boat.id],guard=snapshot.units.find((u:any)=>u.id==='guard-3-1')!;
 const berth=naval.boardingBerth(snapshot.map,worker,boat)!;
 const target=terrain.walkDestination(snapshot.map,worker,berth.shore??berth),road=routes.groundSteeringRoute(snapshot.map,worker,target);
 const loadGround=terrain.walkableGoal(snapshot.map,(mission.pickup??mission.from).x,(mission.pickup??mission.from).y);
 const minRoadDistance=(to:any)=>Math.sqrt(Math.min(...road.slice(1).map((p:any,i:number)=>math.pointSegmentDistanceSquared(to,road[i],p))));
 const actualBoard=full.commands.find((x:any)=>x.tick===tick&&x.command.type==='board'&&x.command.unitIds.includes(id));
 const alreadyWaiting=snapshot.units.filter((u:any)=>u.order.type==='board'&&u.order.transportId===boat.id).map(point);
 const counters=Object.entries({atMissionFrom:mission.from,atActualBerth:{x:berth.x,y:berth.y}}).map(([label,position])=>({label,classification:'Pure counterfactual berth geometry query: only hypothetical boat x/y for this calculation; no game or command execution.',boatPose:position,berth:naval.boardingBerth(snapshot.map,worker,{...boat,...position})}));
 const options={...full.setup,version:'v9_knight',memory:structuredClone(input.memories.p0),teams:snapshot.teams};
 const mainland=care.mainlandCareAssignments(snapshot,'p0',options);
 cases.push({tick,id,input:path,actualBoard,worker:point(worker),boat:point(boat),mission,guard:point(guard),alreadyWaiting,computedNativeBerth:berth,loadGround,sameLandWorkerLoad:terrain.sameGround(snapshot.map,worker,loadGround),sameLandWorkerActualShore:terrain.sameGround(snapshot.map,worker,berth.shore??berth),sameSeaBoatBerth:terrain.sameGround(snapshot.map,boat,berth,'sea'),loadGroundToActualBerthStraight:Math.hypot(loadGround.x-target.x,loadGround.y-target.y),workerToLoadGroundRoad:terrain.walkingDistance(snapshot.map,worker,loadGround,'land'),workerToActualBerthRoad:terrain.walkingDistance(snapshot.map,worker,target,'land'),workerToActualBerthTravelEstimateTicks:routes.routeTravelTicks(snapshot.map,worker,target,'land',worker.speed),nativeSteeringRoad:road,guardToRoadMinimumCenterDistance:minRoadDistance(guard),guardToBerthCenterDistance:Math.hypot(guard.x-target.x,guard.y-target.y),boatToActualBerthSeaRoad:terrain.walkingDistance(snapshot.map,boat,berth,'sea'),boatToActualBerthStraight:Math.hypot(boat.x-berth.x,boat.y-berth.y),currentHullGapToBerthShore:geom.distanceToHull(boat,target),boardingReach:worker.radius+naval.BOARDING_GAP,boatSpeed:boat.sailing?.speed,boatMaxSpeed:boat.speed,sourceCoasts:snapshot.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall').map((b:any)=>({hallId:b.id,x:b.x,y:b.y,coast:policy.coastOnWater(snapshot,b,boat)})),counterfactualGeometry:counters,workerInMainlandCare:!!mainland&&[...mainland.recovering,...mainland.unmedicated].some((x:any)=>x.patient.id===id),snapshotUnchanged:isDeepStrictEqual(norm(snapshot),before)});
}
const observations:any[]=[];
for(const f of full.frames){const s=load(dir+'/candidate-v1/'+f.path).snapshot;if(s.tick<133500)continue;const boat=s.units.find((u:any)=>u.id==='unit-p0-carrier-6933');if(!boat)continue;const workers=s.units.filter((u:any)=>['unit-p0-worker-3','unit-p0-worker-11845','unit-p0-worker-13542','unit-p0-worker-11858'].includes(u.id));observations.push({tick:s.tick,label:f.label,boat:point(boat),hullGapToSharedShore:geom.distanceToHull(boat,{x:4240,y:5584}),workers:workers.map(point)});}
writeFileSync(out+'/native-query.json',JSON.stringify({classification:'Read-only pure native/planner geometry queries from complete same-code114dd frames. No new game, no stepping, no source changes. Counterfactual boat pose probes are not observed trajectories.',source,cases,actualSampledHullObservations:observations},null,2)+'\n');
console.log(JSON.stringify(cases.map(({tick,id,computedNativeBerth,loadGround,workerToActualBerthRoad,workerToLoadGroundRoad,workerToActualBerthTravelEstimateTicks,guardToRoadMinimumCenterDistance,guardToBerthCenterDistance,boatToActualBerthSeaRoad,currentHullGapToBerthShore,boardingReach,boatSpeed,boatMaxSpeed,counterfactualGeometry,snapshotUnchanged})=>({tick,id,computedNativeBerth,loadGround,workerToActualBerthRoad,workerToLoadGroundRoad,workerToActualBerthTravelEstimateTicks,guardToRoadMinimumCenterDistance,guardToBerthCenterDistance,boatToActualBerthSeaRoad,currentHullGapToBerthShore,boardingReach,boatSpeed,boatMaxSpeed,counterfactualGeometry,snapshotUnchanged})),null,2));
