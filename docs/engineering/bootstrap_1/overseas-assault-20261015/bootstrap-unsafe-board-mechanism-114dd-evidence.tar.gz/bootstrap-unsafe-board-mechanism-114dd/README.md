# Unsafe shore boarding: read-only mechanism evidence on fixed 114dd

This is an audit of the actual candidate changed-code continuation132000→135322, not a fresh opening, candidate fix, new game, or acceptance result. No world/command/resource edits, stepping, or production changes were performed for the pure queries in this directory. The preceding full134100→135300 native observer replay is retained in `/tmp/bootstrap-workforce-114dd-complete-evidence.tar.gz` (SHA256 `da423bbdb4de99ff0fe04647d6604462429bd3f89ef43836ccef2626d30a9c52`); world, nextId, both policy memories and all commands match the original candidate checkpoint135300.

## What actually happened

Carrier6933 receives three replacement engineer requests: worker3 at133740, worker11845 at134175, newly born worker13542 at134595. All receive the same native shore(4240,5584), while mission.from remains(5232,6000), a legitimate coast of own central hall11835. The native shore and mission.from are on the same real land component, separated1075.695px. There is no source-island mistake.

At actual complete before-think134175 and134595, `boardingBerth(map, worker, boat)` reconstructs each real berth including its distinct score exactly; there are no surviving older boarders to inherit a stale berth. Ground road distance to mission.from is236.8/224; to actual berth1036.8/1068.8. Native building-aware steering roads pass within66.06/47.92 center distance of then-current dragonWhelp guard-3-1. These are geometric road queries; actual hits/deaths, rather than a radius-only inference, establish combat harm.

The real dragon inflicts17-damage native hits. All three workers persist in board with empty queue through2/70HP. Actual deaths are134164/134594/135023. At those complete after-step death worlds, hull-to-waiting-shore distances are1673.37/1250.13/533.90, versus native boarding reach39. At natural terminal135322 the same hull is still80.20 from the shore. The match ends before it can load this crew; no exact future docking time has been observed.

The ship is genuinely sailing toward the correct native precise berth(4240,5584,headingπ/4). Recorded world positions progress2676,6583 at134100→3655,6004 at135000→4108,5740 at135322. Its order being idle or sampled sailing.speed0 does not establish that it is stuck. Live route geometry retains the requested exact position and heading. This is consistent with the previous verified native precise-berth movement finding.

## Why mission.from does not protect the workers

`shared/naval.ts boardingBerth` ranks all actual shared land/sea shallow shores by2×straight boat distance+.15×straight passenger distance, then checks reachable land endpoint and hull/boarding pose. It receives passenger+boat, not ferry memory, and does not inspect enemies or path safety. `sim.ts` board command obtains that berth (or an existing boarder's berth) without any mission.from argument. For an idle hull `updateBoardOrder` walks the unit to that berth's shore, and `ferryUnits` sails the hull there with the precise heading. A board command cannot specify a shore or override a berth.

The AI's loading logic uses `walkableGoal(mission.pickup??mission.from)` to choose an island and rank miners, then issues plain native board and stops a moving hull. Its worker selection excludes existing build/retreat claims, reserves3 miners, and for assault recruits one worker when at least6 eligible miners remain. It does not re-evaluate the native shore's land road or enemy exposure. If that worker dies, the next planner drops the dead attachment and recruits another miner. The newly added workforce capacity allows replacement purchases and exposes this pre-existing shared loading behavior.

As a narrowly labeled counterfactual geometry calculation only, placing the hypothetical boat x/y at mission.from causes the same native query to choose shore5232,6000 with valid hull pose5232,6064. This is not a simulated trajectory or proposed universal wait-at-from rule. It confirms the far actual boat position drives the observed shore selection. Merely changing the source point in memory would not override the native API.

## Why low HP does not release ownership

At actual before-think134160/134580/135000, full current P0 planner queries using cloned exact policy memories produce exactly the recorded real command frames, with no command for the2HP worker. Per-script claims show only `naval` owns that worker. Queries leave snapshot JSON unchanged.

Both expedition recovery and mainland recovery callers exclude worker and board at their entries. Shell evasion excludes board. MiningJobSafety accepts only mine or move+queued mine and targets active hauling jobs outside a paying hall; these board orders have empty queues. The naval script claims all board units/ferry crew, and script-runner suppresses unrelated tactics. Thus the existing owner must handle danger or explicitly release ownership; no ordinary worker healing/avoidCombat path takes over automatically.

## Minimal boundary and constraints for a subsequent fix

The observed failing boundary is known hostile exposure on the *actual native shore and its real land road*, with pending shore boarders and a hull that remains out of boarding reach. Safe rendezvous must continue to work when coarse mission.from differs from the real precise berth. Existing pickup-quay-snapshot tests explicitly require requesting native board before contact with the coarse pickup point, across all3 routes, and retain a real successful native pickup. A blanket return to “reach coarse from before any board” would erase that behavior.

A repair belongs under the existing naval loading owner and must distinguish pending shore walkers from actual deck/cabin crew; retain mission cancellation/return ownership, one crew reservation, native precise berth heading, and higher build/retreat ownership. A low-HP override alone would leave healthy replacement workers walking the same dangerous route. No threshold tuning, native rule changes, copied old naval layer, or proposed candidate has been implemented here.

## Files and limitations

`native-query.json` contains actual two pre-board queries, native roads, actual hull observations and explicitly counterfactual pose probes. `ownership-query.json` closes3 exact2HP planner frames, records exact death hull geometry and15-tick arrival/HP observations (sampled arrival is not exact arrival). `native134175-*.png` are unedited native drawWorld renders of a real complete frame; both coast and voyage images were visually reviewed. Facing is a new rendering tracker, not reconstructed historic animation. Complete relevant inputs and unchanged critical source files are included with hashes. The inaccessible original-container uncommitted changes remain unrecovered. Workforce114dd is not merged and earlier natural victory is not established as a net benefit.
