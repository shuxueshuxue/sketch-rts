import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {planLandedCombat} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/landed-combat.ts';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/policy.ts';
import {shipHullAtPoint,distanceToHull,shipProfile} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/ship-geometry.ts';
import {setBuildingBodies} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/terrain.ts';
const fixture='/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/fixtures/summoner-landed-native-ground-218040.json.gz';
const saved=JSON.parse(gunzipSync(readFileSync(fixture)).toString()),before=JSON.stringify(saved);
setBuildingBodies(saved.snapshot.map,saved.snapshot.buildings);
const context=bootstrapPolicyContext(saved.snapshot,'p0','v9_summoner',{memory:saved.memories.p0,teams:saved.snapshot.teams});
const start=performance.now(),commands=planLandedCombat(saved.snapshot,'p0',context,new Set());
const moves=commands.filter(command=>command.type==='move').map(command=>({...command,
  selectedHull:shipHullAtPoint(saved.snapshot.units,command)?.id??null,
  nearestHullGap:Math.min(...saved.snapshot.units.filter(ship=>ship.hp>0&&shipProfile(ship)).map(ship=>distanceToHull(ship,command)))}));
const result={classification:'Pure landed local query only, noGame/noStep/noFullP0/noissuedcommands.',fixtureSha256:createHash('sha256').update(readFileSync(fixture)).digest('hex'),tick:saved.snapshot.tick,elapsedMs:performance.now()-start,commands,moves,inputUnchanged:JSON.stringify(saved)===before,usage:process.resourceUsage(),rss:process.memoryUsage().rss};
writeFileSync('/workspace/.playtest/landed-native-ground-v4-20261016/first-landed-anchor-query.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({tick:result.tick,commands:commands.length,moves:moves.length,selectedHulls:moves.filter(m=>m.selectedHull),inputUnchanged:result.inputUnchanged,elapsedMs:result.elapsedMs,rss:result.rss}));
