# 1b landed-ground v4：真实全尾局负例与施法冲突诊断

固定源码 `1b15724175c01a444a1a83a0182826fcebf4024f`，从原 fd 的真实 `217800` 完整 world / nextId / 三方 memory 开始，三方均原正常 AI，无额外公开指令。P0 是 Ember `v9_summoner`，P1 / P2 分别为正常冻结 `v5` Grove / `v7` Ember。规则 2、冻结 manifest 184 不变。这是已开发生成 case 的换码续局，不能称 fresh ordinary0、未见泛化或新策略整局胜。

实际 `217800→319200`，101400 原生步、66916 公令、361 命中、6639 ledger 事件、6760 P0 决策，进程正常 exit0。终点为启动前已支持的 observation-stop 边界：winner null，非自然败、非数学无限循环、非任意 tick 验收。

已有 126 个真实 600tick 完整档 `240000→315000`：资金全为 200.33、剩矿 22500、32 工人无采矿令、无已付生产队列或未付 build、永久兵种及双方建筑数相同。该区间 46804 公令、0 命中、0 永久死亡；船队仍反复装载 / 返程，因此不称全世界冻结。225567 曾真实打野获赏金，240000 前真实造出 transport；这些恢复进展没有抹掉。

本版只改变 bootstrap 已登陆 caster 的 ground-anchor：复用原生 plainXY 选船语义，避免地面 move 指向船体。初始 27 人装载和此前出航是 fd 的实际结果，不归给 v4。218025 的 27 人均真上岸；同 `217800≤tick<219000` 对照，fd 有 8 次重登、20 永久死亡、7 人仍活；v4 为 0 重登、27 永久死亡、0 人活。v4 不合入生产，不能拿局部 0 重登称改善。

`actual-admission-211140-and-landing218025.json` 使用现有完整档纯查询：211125 距目标岸 935.6707、首观测入 HOME_WATERS 的决策 211140 距 898.9249，及 218025 登陆时，实际永久 cargo power 均为 20.81395449764956，原动态 required 均为 20.115569375546702。敌全岛 19 archer + 1 armed worker + 1 tower；弓手 weapon/speed/range 升级各 2、17 damage / 399 range / 30 cooldown 早已存在，不是临登陆突然升级。门槛满足不证明战术安全。

`original218040-full-planner-instrument.json` 是唯一原始 beforeP0 全决策只读 instrument：P0 live 与 P1/P2 冻结正常 planner 按原顺序运行，31 条 entries 与实际 raw 逐条相同，三方 post-memory 全等实际 after-command190 档，输入 world/id/memory 不变、1568 源文件不变。abilities 原始 14 个已就绪召唤请求全被原 runner 丢弃；其 actor 均已收到先前 naval 的 physical 命令。外部 bundle 仅插观测 trace，未创建 Game / step / 发令。早前 after-command 组件查询单独标为反事实，不替代该闭合。

`actual-caster-execution-timeline-218040-219000.json` 分开公令和实际 effect / birth：14 人最终全部真召唤，9 次公令、5 次原生 autocast；14 个 effect 都匹配真实新 spirit。首名前排 218117 死前仅 3 次召唤，9 名前排 218428 全死前 14 次已完成；最终第 27 人在 218677 死。另有 3 次真实 heal、4 次 scorch。非 weapon summon/heal/curse 在范围内原生即时生效；唯一 public heal218100 走施后 218102 完成。原 afterCommand 记录中没有已有 cohort cast order 被 naval 覆写的实例，不能虚称取消了施法 windup。早施法是否能改善战局仍待独立候选验证。

两张实际原生 client 图 `actual-v4-native-battle-218115.png` / `218400.png` 已亲看：前排向内陆弓群推进，casters 仍散在岸边，随后前排大量尸体、船已离岸；视觉不替代 deck / hit / death / effect 字段。静态 drawWorld 无 Game / step / command。

`terminal-audit/FINAL-CASE-AUDIT.json` 保留所有全尾局永久死亡、真实出生、终点完整三方记忆、setup、raw 逐行数和末 15tick 绑定。末段 `319185≤tick<319200` 原 11 条公令 / 0 hit / 2 events / 1 P0 input hash；最后实际 full beforeP0 是 318600，319185 的原 full 不存在。319200 为 afterstep、下一 P0 之前的实际完整档，没有另造 beforeP0。未重跑末段 cold，不能冒称末段逐世界闭合。

源码完整 archive1568 与 capsule 逐文件相符，driver pre/post clean。冻结运行时 manifest184 pre/post 全真；完整历史冻结 archive497 另与 d1ae110f Git 所有文件 byte/hash 相同。其余313运行时文件未在 loader exit cleanup 前另做 posthash，不能把 archive497 验证说成497 runtime postflight。原容器未提交修改的恢复缺口仍未恢复。

下一独立 v5 仅研究既有 landed owner 的即时技能与物理动作协调；不改默认 runner、整栈顺序、医疗归属、原 1.4 或敌规则。它不在本包成绩中。
