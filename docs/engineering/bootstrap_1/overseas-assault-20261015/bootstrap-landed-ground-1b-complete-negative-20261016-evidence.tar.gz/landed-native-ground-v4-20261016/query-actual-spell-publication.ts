import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {planBootstrapAbilities} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/weapon-targets.ts';
import {withoutFerryCabinConflicts} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/ferry-cabin-ownership.ts';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/policy.ts';
import {setBuildingBodies} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/terrain.ts';
import {ABILITY_DEFS} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/catalog.ts';
import {shipHullAtPoint} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/ship-geometry.ts';
const D='/workspace/.playtest/landed-native-ground-v4-20261016';
const cap=JSON.parse(readFileSync(D+'/fixed-runtime.json','utf8')),cohort=new Set(cap.observedCrewIds);
const input=D+'/native-normal-from217800/frames/218040-physical-transition-after-command-190.json.gz';
const raw=readFileSync(input),saved=JSON.parse(gunzipSync(raw).toString()),before=JSON.stringify(saved),snapshot=saved.snapshot;
setBuildingBodies(snapshot.map,snapshot.buildings);
const options=bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:saved.memories.p0,teams:snapshot.teams});
const rawAbilities=planBootstrapAbilities(snapshot,'p0',options);
const wrapped=withoutFerryCabinConflicts(snapshot,'p0',options,rawAbilities);
const candidates=wrapped.filter(command=>command.type==='cast'&&cohort.has(command.unitId)).map(command=>{
  const unit=snapshot.units.find(unit=>unit.id===command.unitId),def=ABILITY_DEFS[command.ability];
  const target=command.targetId?snapshot.units.find(unit=>unit.id===command.targetId):command;
  return {command,kind:unit.kind,hp:unit.hp,order:unit.order,cooldown:unit.abilityCooldowns?.[command.ability]??0,
    range:def.range,distance:Math.hypot(unit.x-target.x,unit.y-target.y),selectedHull:'x'in command?shipHullAtPoint(snapshot.units,command)?.id??null:null};
});
const allCommands=gunzipSync(readFileSync(D+'/native-normal-from217800/commands.jsonl.gz')).toString().trim().split('\n').map(row=>JSON.parse(row)).filter(row=>row.tick===218040);
const earlierMovement=allCommands.filter(row=>row.owner==='p0'&&row.scriptId==='naval'&&['move','attackMove','holdPosition','attack','aim'].includes(row.command.type));
const moved=new Set(earlierMovement.flatMap(row=>row.command.unitIds));
const result={classification:'One pure component query on actual live captured218040 after first naval publiccommand190, not a Game/replay/fullP0 or extra public issue. Actual P0 planning memory already changed empty ferry toreturn.',input,inputSHA256:createHash('sha256').update(raw).digest('hex'),head:cap.head,tick:snapshot.tick,
  general:saved.memories.p0.v6?.general,mission:{phase:saved.memories.p0.naval.ferries[cap.observedHull].phase,crewIds:saved.memories.p0.naval.ferries[cap.observedHull].crewIds},
  rawInnateCasts:candidates,earlierActualNavalMovement:earlierMovement,eachRawCastHasEarlierActualMovedActor:candidates.map(row=>({id:row.command.unitId,moved:moved.has(row.command.unitId)})),
  actualSameThinkCohortCasts:allCommands.filter(row=>row.command.type==='cast'&&cohort.has(row.command.unitId)),
  rule:'script-runner removeOrderedUnitConflicts removes every latercast if movedUnitIds already has actor. This is rejection before native issue, not cancellation of an applied spell.',
  inputUnchanged:JSON.stringify(saved)===before,rss:process.memoryUsage().rss,usage:process.resourceUsage()};
if(!result.inputUnchanged)throw Error('Input mutated');
writeFileSync(D+'/actual218040-spell-publication-query.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({rawInnateCasts:candidates.length,kinds:candidates.map(row=>row.kind),allReadyInRange:candidates.every(row=>row.cooldown===0&&row.distance<=row.range),allEarlierMoved:result.eachRawCastHasEarlierActualMovedActor.every(row=>row.moved),actualIssued:result.actualSameThinkCohortCasts.length,inputUnchanged:result.inputUnchanged,rss:result.rss}));
