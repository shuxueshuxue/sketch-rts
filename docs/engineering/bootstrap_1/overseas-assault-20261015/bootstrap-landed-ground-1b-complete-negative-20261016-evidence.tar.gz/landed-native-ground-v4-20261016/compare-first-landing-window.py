import gzip, hashlib, json, pathlib
D=pathlib.Path(__file__).resolve().parent
old=pathlib.Path('/workspace/.playtest/cabin-loading-shore-v3-20261016/native-normal-202800')
new=D/'native-normal-from217800'
start,end=217800,219000
progress=json.loads((new/'progress.json').read_text())
assert progress['tick']>=219600, 'Wait for completed checkpoint and complete later raw members'
cap=json.loads((D/'fixed-runtime.json').read_text());crew=set(cap['observedCrewIds'])
def rows(root,name):
    result=[]
    with gzip.open(root/f'{name}.jsonl.gz','rt') as stream:
        for line in stream:
            row=json.loads(line)
            if row['tick']>=end:break
            if row['tick']>=start:result.append(row)
    return result
def normalized(command):return {k:command[k] for k in ['tick','owner','scriptId','command']}
def summarize(root):
    commands,hits,events=[rows(root,name) for name in ['commands','hits','events']]
    reboards=[];landings=[];deaths=[]
    for event in events:
        before=event.get('before') or {};after=event.get('after') or {}
        entity=event.get('id') or before.get('id') or after.get('id')
        if entity not in crew:continue
        if event['type']=='observed-disembark' and before.get('deck',{}).get('shipId')==cap['observedHull'] and not after.get('deck'):
            landings.append({'id':entity,'tick':event['tick'],'stage':event['stage'],'commandIndex':event.get('commandIndex')})
        if event['type']=='observed-parent-change' and after.get('deck',{}).get('shipId')==cap['observedHull'] and before.get('deck',{}).get('shipId')!=cap['observedHull']:
            reboards.append({'id':entity,'tick':event['tick'],'stage':event['stage'],'commandIndex':event.get('commandIndex')})
        if event['type']=='native-unit-terminal' and event.get('permanent'):deaths.append(event)
    finalPath=root/'frames'/f'{end}-complete-periodic-after-step.json.gz'
    final=json.loads(gzip.decompress(finalPath.read_bytes()))
    living=[unit for unit in final['snapshot']['units'] if unit['id'] in crew and unit['hp']>0]
    perOwner={}
    for event in events:
        if event['type']=='native-unit-terminal' and event.get('permanent'):
            unit=event.get('atObservation') or event.get('previous') or {}
            owner=unit.get('owner','unknown');perOwner[owner]=perOwner.get(owner,0)+1
    return {'commands':commands,'hits':hits,'events':events,'landings':landings,'reboards':reboards,
        'cohortDeaths':deaths,'allOwnerPermanentDeaths':perOwner,
        'p0Hits':[hit for hit in hits if hit['attackerOwner']=='p0'],
        'hitsOnCohort':[hit for hit in hits if hit['target'] in crew],
        'finalCheckpoint':{'path':str(finalPath),'sha256':hashlib.sha256(finalPath.read_bytes()).hexdigest(),
            'tick':final['snapshot']['tick'],'winner':final['snapshot']['match']['winner'],
            'cohortLiving':[{'id':u['id'],'kind':u['kind'],'hp':u['hp'],'x':u['x'],'y':u['y'],'deck':u.get('deck'),'cabin':u.get('cabin'),'order':u['order']} for u in living],
            'nativeStats':final['snapshot']['match']['stats']}}
a,b=summarize(old),summarize(new)
first=None
for i in range(max(len(a['commands']),len(b['commands']))):
    av=normalized(a['commands'][i]) if i<len(a['commands']) else None
    bv=normalized(b['commands'][i]) if i<len(b['commands']) else None
    if av!=bv:first={'ordinal':i,'old':av,'candidate':bv};break
beforeOld=json.loads(gzip.decompress(pathlib.Path('/workspace/.playtest/cabin-loading-shore-v3-20261016/cold-first-landing-217800-218400/218040-reconstructed-before-p0.json.gz').read_bytes()))
beforeNew=json.loads(gzip.decompress((new/'frames/218040-before-p0.json.gz').read_bytes()))
inputEqual={key:beforeOld[key]==beforeNew[key] for key in ['snapshot','nextId','memories']}
def compact(value):
    return {'commands':len(value['commands']),'allHits':len(value['hits']),'p0Hits':len(value['p0Hits']),
        'hitsOnCohort':len(value['hitsOnCohort']),'allOwnerPermanentDeaths':value['allOwnerPermanentDeaths'],
        'trueCohortLandings':value['landings'],'trueCohortReboards':value['reboards'],'cohortPermanentDeaths':value['cohortDeaths'],
        'finalCheckpoint':value['finalCheckpoint']}
result={'classification':'Observed normal3AI actual first-landing comparison between two fixed sources, not a fresh0/fullmatch verdict or replay equality after divergence.',
    'baselineSource':'fd42820ae802cc716157a848f216f0a7700de62b','candidateSource':cap['head'],
    'rawTickInterval':{'startInclusive':start,'endExclusive':end},'rawBoundaryScope':'All raw commands/hits/events compared uniformly at tick>=217800 and<219000. Final checkpoint is complete afterstep219000; same-tick219000 native/command effects are deliberately outside the raw summary, not silently conflated.',
    'beforeFirstMove218040FullInputEqual':inputEqual,'firstCommandDifference':first,'baseline':compact(a),'candidate':compact(b),
    'limits':['Both sources continue their own Game; this bounded result is not a full-match or generalization outcome.','27 loaded troops are inherited from prior normalfd, not candidate loading credit.','Original218040 fullinput was newly reconstructed by a same-source600 closure, while candidate218040 beforeP0 is live actualcapture.','Command ordinals are window local; original source commandIndex and candidate source commandIndex have different starts.']}
(D/'first-landing-normal-comparison-217800-219000.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'firstCommandDifference':first,'inputEqual':inputEqual,
    'baseline':{'landings':len(a['landings']),'reboards':len(a['reboards']),'cohortDeaths':len(a['cohortDeaths']),'living':len(a['finalCheckpoint']['cohortLiving']),'allOwnerPermanentDeaths':a['allOwnerPermanentDeaths'],'p0hits':len(a['p0Hits'])},
    'candidate':{'landings':len(b['landings']),'reboards':len(b['reboards']),'cohortDeaths':len(b['cohortDeaths']),'living':len(b['finalCheckpoint']['cohortLiving']),'allOwnerPermanentDeaths':b['allOwnerPermanentDeaths'],'p0hits':len(b['p0Hits'])}},indent=2))
