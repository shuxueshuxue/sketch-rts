import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/ai/bootstrap_1/policy.ts';
import {assaultExpedition} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/ai/policy/naval.ts';
import {effectiveCombatRating,structureRating,TOWER_STRENGTH} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/ai/policy/v6/strength.ts';
import {setBuildingBodies,sameGround} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/shared/terrain.ts';
import {shipPassengers} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/shared/ship-geometry.ts';
import {combatCapability} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/shared/combat-capabilities.ts';
import {weaponRules} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/shared/equipment.ts';
import {isOpponentOwner} from '/workspace/sketch-rts-cabin-loading-shore-v3-control/src/ai/policy/ownership.ts';
const D='/workspace/.playtest/landed-native-ground-v4-20261016',old='/workspace/.playtest/cabin-loading-shore-v3-20261016';
const paths=[old+'/native-normal-202800/frames/211125-before-p0.json.gz',old+'/native-normal-202800/frames/211140-before-p0.json.gz',D+'/native-normal-from217800/frames/218025-before-p0.json.gz'];
const sha=(x:any)=>createHash('sha256').update(x).digest('hex');
const cap=JSON.parse(readFileSync(old+'/fixed-runtime.json','utf8'));
const proof=()=>Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(cap.sourceRoot+'/'+p))!==h).map(([p])=>p);
if(proof().length)throw Error('Original fd source changed');
const rows=[];
for(const path of paths){
 const raw=readFileSync(path),f=JSON.parse(gunzipSync(raw).toString()),before=JSON.stringify(f),s=f.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...s.obstacles??[]]);
 const options=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(f.memories.p0),teams:s.teams});
 const boat=s.units.find((u:any)=>u.id===cap.observedHull),mission=f.memories.p0.naval.ferries[boat.id];
 const target=s.buildings.find((b:any)=>b.id===mission.targetId),exp=assaultExpedition(s,'p0',options,target);
 const crew=shipPassengers(s.units,boat).filter((u:any)=>u.owner==='p0'&&u.hp>0&&u.expiresTick===undefined);
 const hostile=s.units.filter((u:any)=>!u.deck&&isOpponentOwner(s,'p0',u.owner,options)&&sameGround(s.map,u,target)&&combatCapability(s,u).armed);
 const towers=s.buildings.filter((b:any)=>isOpponentOwner(s,'p0',b.owner,options)&&b.attackDamage>0&&sameGround(s.map,b,target));
 const enemies=hostile.map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,attackDamage:u.attackDamage,attackRange:u.attackRange,attackCooldown:u.attackCooldown,
  weaponCooldown:weaponRules(s,u).attackCooldown,actualCapability:combatCapability(s,u),rating:u.kind==='worker'?structureRating({hp:u.maxHp,attackDamage:combatCapability(s,u).dps,attackCooldown:20})*Math.max(0.1,u.hp/Math.max(1,u.maxHp)):effectiveCombatRating(s,u),level:u.level,effects:u.effects,order:u.order}));
 const actualCargoPower=crew.reduce((sum:number,u:any)=>sum+effectiveCombatRating(s,u),0);
 if(JSON.stringify(f)!==before)throw Error('Input mutated');
 rows.push({path,sha256:sha(raw),tick:s.tick,frameSource:s.tick===218025?'actual1b fullframe before firstlanding; before first code divergence at218040':'actualfd fullframe',
  mission:{targetId:mission.targetId,phase:mission.phase,to:mission.to,approach:mission.approach},distanceToTargetBerth:Math.hypot(boat.x-mission.to.x,boat.y-mission.to.y),boat:{x:boat.x,y:boat.y,hp:boat.hp},
  dynamicRequired:exp.required,actualCargoPower,permanentCargo:crew.length,meetsDynamicGate:actualCargoPower>=exp.required,
  sameIslandArmedEnemies:enemies,towers:towers.map((b:any)=>({id:b.id,owner:b.owner,kind:b.kind,x:b.x,y:b.y,hp:b.hp,attackDamage:b.attackDamage,attackRange:b.attackRange,attackCooldown:b.attackCooldown,rating:TOWER_STRENGTH})),
  enemyPlayerUpgrades:Object.fromEntries(Object.entries(s.players).filter(([o])=>o!=='p0').map(([o,p]:any)=>[o,p.upgrades])),worldNextIdAllMemoryUnchanged:true});
}
const result={classification:'Pure leaf scoring/statistics on actual complete source-qualified snapshots; no Game, step, fullplanner or issued commands. First sampled HOME_WATERS-entry think is211140, prior211125 think is outside900. No claim to exact intermediate native crossing tick.',scoringSource:cap.head,rows,sourceAfter:proof(),rss:process.memoryUsage().rss};
writeFileSync(D+'/actual-admission-211140-and-landing218025.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({rows:rows.map(r=>({tick:r.tick,distance:r.distanceToTargetBerth,force:r.actualCargoPower,required:r.dynamicRequired,cargo:r.permanentCargo,enemies:r.sameIslandArmedEnemies.length,towers:r.towers.length,meets:r.meetsDynamicGate})),sourceAfter:result.sourceAfter,rss:result.rss}));
