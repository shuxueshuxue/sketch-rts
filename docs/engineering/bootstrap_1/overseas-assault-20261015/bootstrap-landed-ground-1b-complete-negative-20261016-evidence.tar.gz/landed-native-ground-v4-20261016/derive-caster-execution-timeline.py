from pathlib import Path
import gzip,json,hashlib,math
D=Path('/workspace/.playtest/landed-native-ground-v4-20261016');O=D/'native-normal-from217800';F=O/'frames'
cap=json.loads((D/'fixed-runtime.json').read_text());cohort=set(cap['observedCrewIds'])
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
start=load(F/'218040-before-p0.json.gz');initial={u['id']:u for u in start['snapshot']['units'] if u['id'] in cohort}
casters={i:u for i,u in initial.items() if u['kind'] in ['summoner','priest','ashHexer']}
front={i for i,u in initial.items() if u['kind']=='emberRavager'}
def stream(name):
 with gzip.open(O/(name+'.jsonl.gz'),'rt') as f:
  for line in f:
   row=json.loads(line)
   if row['tick']<218025:continue
   if row['tick']>=219000:break
   yield row
commands=list(stream('commands'));events=list(stream('events'));hits=list(stream('hits'));effects={};frames=[];samples={i:[] for i in casters}
for tick in range(218040,219001,15):
 p=F/f'{tick}-before-p0.json.gz'
 if not p.exists():raise RuntimeError('Missing actual frame '+str(p))
 b=p.read_bytes();frame=json.loads(gzip.decompress(b));frames.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 for e in frame['snapshot']['effects']:
  if e.get('sourceId') in cohort and e.get('actionMode')=='cast' and e.get('actionTick',0)>=218040:effects.setdefault(e['id'],e)
 units={u['id']:u for u in frame['snapshot']['units']}
 for i in casters:
  u=units.get(i)
  if u:samples[i].append({'tick':tick,'x':u['x'],'y':u['y'],'hp':u['hp'],'order':u['order'],'cooldowns':u.get('abilityCooldowns',{}),'deck':u.get('deck'),'cabin':u.get('cabin'),'effects':u.get('effects',[])})
terminals={e['id']:e for e in events if e['type']=='native-unit-terminal' and e.get('permanent') and e['id'] in cohort}
births=[e for e in events if e['type']=='unit-birth-observed' and e.get('unit',{}).get('owner')=='p0' and e['unit']['kind']=='spirit']
cast_effects=sorted(effects.values(),key=lambda e:(e['actionTick'],e['id']))
for e in cast_effects:
 public=[r for r in commands if r['command']['type']=='cast' and r['command']['unitId']==e['sourceId'] and r['tick']<=e['actionTick']]
 matching=[r for r in public if r['tick']==e['actionTick'] or (e['type']=='heal' and e['actionTick']-r['tick']<15)]
 e['actualPublicCastInSameExecution']=matching
 e['executionClassification']='public-request actual instant/approach completion' if matching else 'native completion/autocast without same-execution public request'
 if e['type']=='summon':
  # Native-step births are observed after the tick increments and may already
  # have moved. homeX/Y retain the actual spawn location; this is not a later
  # same-kind proximity guess.
  matches=[b for b in births if b['tick'] in [e['actionTick'],e['actionTick']+1] and math.hypot(b['unit']['homeX']-e['x'],b['unit']['homeY']-e['y'])<1e-9]
  e['actualBirths']=[{'id':b['unit']['id'],'tick':b['tick'],'eventIndex':b['eventIndex'],'stage':b['stage']} for b in matches]
rows=[]
for i,u in casters.items():
 rows.append({'id':i,'kind':u['kind'],'initialHp':u['hp'],'initialOrder':u['order'],'initialCooldowns':u.get('abilityCooldowns',{}),
  'actualSpellEffects':[e for e in cast_effects if e['sourceId']==i],
  'actualPublicCasts':[r for r in commands if r['command']['type']=='cast' and r['command']['unitId']==i],
  'actualIssuedPhysicalOrders':[r for r in commands if i in r['command'].get('unitIds',[])],
  'actualTerminal':terminals.get(i),'observedBeforeP0States':samples[i]})
front_deaths=sorted([terminals[i] for i in front if i in terminals],key=lambda e:e['tick'])
summons=[e for e in cast_effects if e['type']=='summon'];first=front_deaths[0]['tick'];last=front_deaths[-1]['tick']
out={'classification':'Read-only derivation from actual fixed1b normal3AI first landing; no replay/Game/extra command. Public request and native effect completion are separate. beforeP0 cadence15 retains every36/46/50tick spell effect in this window.',
 'sourceHead':cap['head'],'window':{'start':218040,'endExclusive':219000},'frameInventory':frames,
 'summary':{'casters':len(casters),'summonerCount':sum(u['kind']=='summoner' for u in casters.values()),'actualSummons':len(summons),'summonsWithBirthMatch':sum(len(e.get('actualBirths',[])) for e in summons),
  'publicCohortCastRequests':sum(r['command']['type']=='cast' and r['command']['unitId'] in casters for r in commands),
  'firstFrontDeathTick':first,'allNineFrontDeadTick':last,'frontDead':len(front_deaths),
  'actualSummonsBeforeFirstFrontDeath':sum(e['actionTick']<first for e in summons),'actualSummonsBeforeAllFrontDead':sum(e['actionTick']<last for e in summons),
  'all27PermanentlyDead':len(terminals)==27,'lastCohortDeathTick':max(e['tick'] for e in terminals.values())},
 'frontDeaths':[{'id':e['id'],'tick':e['tick'],'lastNativeHit':e.get('lastNativeHit'),'lastOrder':(e.get('atObservation') or e.get('previous'))['order']} for e in front_deaths],
 'spellExecutionSummary':[{'sourceId':e['sourceId'],'type':e['type'],'actualTick':e['actionTick'],'requestKind':e['executionClassification'],'birthIds':[x['id'] for x in e.get('actualBirths',[])]} for e in cast_effects],
 'casters':rows,'limits':['No claim that instantaneous summon/heal/curse had weapon windup. Source in-range actions apply immediately; public out-of-range heal218100 completed218102.','A later movement command after an applied instantaneous spell cannot cancel its prior effect.','This timing and exact original218040 runner rejection establish delayed spell use, not that earlier casting guarantees victory.','The fixedv4 whole continuation remains separate and ongoing; this is its first1200 window, not full-match acceptance.']}
(D/'actual-caster-execution-timeline-218040-219000.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary']));print(json.dumps(out['frontDeaths']));print(json.dumps(out['spellExecutionSummary']))
