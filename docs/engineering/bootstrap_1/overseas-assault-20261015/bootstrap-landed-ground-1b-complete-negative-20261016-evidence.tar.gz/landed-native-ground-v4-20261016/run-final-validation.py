import datetime, hashlib, json, os, pathlib, subprocess, sys, time
D=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/workspace/sketch-rts-landed-ground-screen-v4-control')
stage=sys.argv[1]
assert stage in {'related','tsc'}
receipt=D/f'final-{stage}-receipt.json'
assert not receipt.exists(), 'Keep the original receipt; use a new explicit attempt for a failure'
cgroup=pathlib.Path('/sys/fs/cgroup')
limit=int((cgroup/'memory.max').read_text())
current=int((cgroup/'memory.current').read_text())
proof={'stage':stage,'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'limit':limit,'current':current,'headroom':limit-current,'required':2<<30,
       'headBefore':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),
       'statusBefore':subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True),
       'oomBefore':(cgroup/'memory.events').read_text()}
if limit-current<2<<30:
    proof['exit']=75
    (D/f'prepared-only-{stage}-guard-{time.time_ns()}.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(proof));sys.exit(75)
files=json.loads((D/'planned-validation.json').read_text())['targetedFiles']
command=(['node','--max-old-space-size=768',str(S/'node_modules/vitest/vitest.mjs'),'run',
          '--pool=forks','--maxWorkers=1','--minWorkers=1',*files] if stage=='related'
         else ['node','--max-old-space-size=1024',str(S/'node_modules/typescript/bin/tsc'),'--noEmit'])
environment={**os.environ}
if stage=='related':environment['NODE_OPTIONS']='--max-old-space-size=768'
proof.update(argv=command,heapMiB=768 if stage=='related' else 1024)
start=time.monotonic()
with (D/f'final-{stage}.log').open('w') as log:
    child=subprocess.Popen(command,cwd=S,env=environment,stdout=log,stderr=subprocess.STDOUT)
    proof['pid']=child.pid
    proof['exit']=child.wait()
proof.update(endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wallSeconds=time.monotonic()-start,
    oomAfter=(cgroup/'memory.events').read_text(),
    headAfter=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),
    statusAfter=subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True))
receipt.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
print((D/f'final-{stage}.log').read_text()[-16000:])
sys.exit(proof['exit'])
