import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {deepStrictEqual,strictEqual,ok} from 'node:assert';
import {planLandedCombat} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/landed-combat.ts';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/policy.ts';
import {planCasterScreen} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/policy/v6/backline.ts';
import {shipHullAtPoint,distanceToHull,shipProfile} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/ship-geometry.ts';
import {groundSteeringRoute} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/route-selection.ts';
import {constrainGroundShipStep} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/ship-collisions.ts';
import {setBuildingBodies,sameGround,isOpenGround} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/terrain.ts';
import {MOVE_ORDER_ARRIVAL_RANGE} from '/workspace/sketch-rts-landed-ground-screen-v4-control/src/shared/movement-rules.ts';
const fixture='/workspace/sketch-rts-landed-ground-screen-v4-control/src/ai/bootstrap_1/fixtures/summoner-landed-native-ground-218040.json.gz';
const saved=JSON.parse(gunzipSync(readFileSync(fixture)).toString()),before=JSON.stringify(saved);
const snapshot=saved.snapshot;
setBuildingBodies(snapshot.map,snapshot.buildings);
const context=bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:saved.memories.p0,teams:snapshot.teams});
const commands=planLandedCombat(snapshot,'p0',context,new Set());
const proofs=[];
for(const command of commands.filter(command=>command.type==='move'))for(const id of command.unitIds){
  const unit=snapshot.units.find(unit=>unit.id===id),road=groundSteeringRoute(snapshot.map,unit,command);
  const ships=snapshot.units.filter(ship=>ship.hp>0&&shipProfile(ship));
  const bodies=snapshot.units.filter(other=>other.id!==id&&other.hp>0&&!other.deck&&!shipProfile(other));
  const segments=road.slice(1).map((to,index)=>{const from=road[index],nativeEnd=constrainGroundShipStep(snapshot.map,unit,from,to,snapshot.units);return {from,to,nativeEnd,error:Math.hypot(to.x-nativeEnd.x,to.y-nativeEnd.y)};});
  const proof={id,goal:{x:command.x,y:command.y},radius:unit.radius,arrival:MOVE_ORDER_ARRIVAL_RANGE,
    isOpenGround:isOpenGround(snapshot.map,command.x,command.y),sameGround:sameGround(snapshot.map,unit,command),selectedHull:shipHullAtPoint(snapshot.units,command)?.id??null,
    finalRoadError:Math.hypot(road.at(-1).x-command.x,road.at(-1).y-command.y),segments,
    hullMargins:ships.map(ship=>({id:ship.id,gap:distanceToHull(ship,command),margin:distanceToHull(ship,command)-unit.radius-MOVE_ORDER_ARRIVAL_RANGE})),
    minimumBodyMargin:Math.min(...bodies.map(other=>Math.hypot(other.x-command.x,other.y-command.y)-other.radius-unit.radius-MOVE_ORDER_ARRIVAL_RANGE))};
  ok(proof.isOpenGround&&proof.sameGround&&!proof.selectedHull&&proof.finalRoadError<=MOVE_ORDER_ARRIVAL_RANGE);
  ok(proof.segments.every(segment=>segment.error<=1e-7)&&proof.hullMargins.every(row=>row.margin>0)&&proof.minimumBodyMargin>0);
  proofs.push(proof);
}
strictEqual(proofs.length,17);
const caster=snapshot.units.find(unit=>unit.id==='unit-p0-summoner-4085'),post={x:9296,y:6256};
const noThreats={...snapshot,units:[caster,...snapshot.units.filter(unit=>unit.owner==='p0'&&shipProfile(unit))]};
const defaultCommands=planCasterScreen(noThreats,'p0',context,post,post,[],[caster],false,true,()=>undefined);
deepStrictEqual(defaultCommands,[{type:'move',unitIds:[caster.id],...post}]);
deepStrictEqual(planCasterScreen(noThreats,'p0',context,post,post,[],[caster],false,true,()=>undefined,()=>true,undefined,(_unit,point)=>point),defaultCommands);
strictEqual(JSON.stringify(saved),before);
const result={classification:'Pure leaf only: noGame/noStep/noFullP0/noissuedcommands; finite static endpoints/roads do not prove dynamic movement or battle success.',tick:snapshot.tick,
 fixtureSha256:createHash('sha256').update(readFileSync(fixture)).digest('hex'),proofs,inputUnchanged:true,sharedDefaultCommands:defaultCommands,identityOptInEqualDefault:true,rss:process.memoryUsage().rss,usage:process.resourceUsage()};
writeFileSync('/workspace/.playtest/landed-native-ground-v4-20261016/ground-contract-leaf-proof.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({tick:snapshot.tick,goals:proofs.length,allRoadSegmentsNativeClear:true,allBodyArrivalMarginsPositive:true,sharedDefaultPreserved:true,inputUnchanged:true,rss:result.rss}));
