from pathlib import Path
import json,gzip,hashlib,collections,datetime
D=Path('/workspace/.playtest/landed-native-ground-v4-20261016');O=D/'native-normal-from217800';P=O/'frames'
progress=json.loads((O/'progress.json').read_text());end=progress['tick']//600*600;start=240000
rows=[]
for tick in range(start,end+1,600):
 p=P/f'{tick}-complete-periodic-after-step.json.gz'
 if not p.exists():continue
 raw=p.read_bytes();f=json.loads(gzip.decompress(raw));s=f['snapshot'];own=[u for u in s['units'] if u['owner']=='p0' and u.get('expiresTick') is None]
 buildings=[b for b in s['buildings'] if b['owner']=='p0'];military=[u for u in own if u['kind']!='worker']
 rows.append({'tick':tick,'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'winner':s['match']['winner'],'gold':s['players']['p0']['gold'],
  'resourcesTotal':sum(r['amount'] for r in s['resources']),'nonemptyMines':[{'id':r['id'],'amount':r['amount'],'x':r['x'],'y':r['y']} for r in s['resources'] if r['amount']>0],
  'permanentCounts':dict(collections.Counter(u['kind'] for u in own)),'ownBuildings':len(buildings),'ownHalls':sum(b['kind']=='townHall' for b in buildings),
  'enemyBuildings':dict(collections.Counter(b['owner'] for b in s['buildings'] if b['owner'] not in ['p0','neutral'])),
  'mineWorkers':[{'id':u['id'],'order':u['order']} for u in own if u['kind']=='worker' and u['order']['type']=='mine'],
  'workerOrderCounts':dict(collections.Counter(u['order']['type'] for u in own if u['kind']=='worker')),
  'paidQueues':[{'id':b['id'],'kind':b['kind'],'queue':b.get('queue')} for b in buildings if b.get('queue')],
  'unpaidBuildOrders':[{'id':u['id'],'order':u['order']} for u in own if u['order']['type']=='build'],
  'ferries':f['memories']['p0'].get('naval',{}).get('ferries',{}),
  'allPermanentMilitary':[{'id':u['id'],'kind':u['kind'],'hp':u['hp'],'x':u['x'],'y':u['y'],'order':u['order'],'deck':u.get('deck'),'cabin':u.get('cabin')} for u in military]})
counts=collections.Counter();new_hits=[];permanent_deaths=[];last_hit=None
for name in ['commands','hits','events']:
 with gzip.open(O/(name+'.jsonl.gz'),'rt') as lines:
  for line in lines:
   r=json.loads(line)
   if r['tick']>=end:break
   if name=='hits':last_hit=r
   if r['tick']<start:continue
   if name=='commands':counts[(r['owner'],r['command']['type'])]+=1
   if name=='hits':new_hits.append(r)
   if name=='events' and r['type']=='native-unit-terminal' and r.get('permanent'):permanent_deaths.append(r)
summary={'capturedCompleteFrames':len(rows),'start':start,'end':end,'winnerNullEveryFrame':all(r['winner'] is None for r in rows),'goldValues':sorted(set(r['gold'] for r in rows)),
 'resourceTotalValues':sorted(set(r['resourcesTotal'] for r in rows)), 'anyMineWorker':any(r['mineWorkers'] for r in rows),'anyPaidQueue':any(r['paidQueues'] for r in rows),'anyUnpaidBuildOrder':any(r['unpaidBuildOrders'] for r in rows),
 'constantPermanentCounts':all(r['permanentCounts']==rows[0]['permanentCounts'] for r in rows),'constantOwnAndEnemyBuildingCounts':all((r['ownBuildings'],r['enemyBuildings'])==(rows[0]['ownBuildings'],rows[0]['enemyBuildings']) for r in rows),
 'actualHits':len(new_hits),'actualPermanentDeaths':len(permanent_deaths),'lastActualHitBeforeEnd':last_hit,
 'actualCommands':sum(counts.values()),'actualCommandsByOwnerType':[{'owner':o,'type':t,'count':n} for (o,t),n in sorted(counts.items())]}
out={'classification':'Read-only bounded progress audit of live fixed1b ordinary continuation after all27 initial landing casualties. It records source-qualified observed strategic inactivity, not a natural defeat, whole-world freeze or mathematical infinite loop. No Game/planner/step/commands executed.',
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'1b15724175c01a444a1a83a0182826fcebf4024f','summary':summary,'rows':rows,
 'preservedEarlierChanges':['Actual27 landed218025 and all diedby218677; this differs from oldfd20dead/7aboard.','After219000 normal policy retargeted a P2 farm and built a real transport by240000, so the whole continuation is not called static from landing.','Current carrier/transport loading/return movements and spirit birth/expiry continue; no claim that every order or position is fixed.'],
 'limits':['Mines listed with actual amounts and positions; these raw records alone do not establish current safe access or mining profitability.','No new fullP0 query, source change, observer stop request, kill or source hot edit.']}
(D/'actual-post-assault-strategic-status.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(summary))
