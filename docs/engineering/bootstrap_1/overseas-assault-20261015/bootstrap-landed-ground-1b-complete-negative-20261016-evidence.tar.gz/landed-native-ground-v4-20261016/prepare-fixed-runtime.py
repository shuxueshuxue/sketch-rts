import gzip, hashlib, json, pathlib, subprocess, tarfile
D=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/workspace/sketch-rts-landed-ground-screen-v4-control')
OLD=pathlib.Path('/workspace/.playtest/cabin-loading-shore-v3-20261016')
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(S),*args])
head=git('rev-parse','HEAD').decode().strip()
assert head!='fd42820ae802cc716157a848f216f0a7700de62b' and not git('status','--porcelain')
assert not (D/'fixed-runtime.json').exists(), 'Do not overwrite a fixed capsule'
paths=[p for p in git('ls-files','-z').decode().split('\0') if p and (S/p).is_file()]
hashes={p:sha((S/p).read_bytes()) for p in paths}
sizes={p:(S/p).stat().st_size for p in paths}
archive=D/'candidate-source.tar.gz'
with gzip.open(archive,'wb',compresslevel=6) as output:
    process=subprocess.Popen(['git','-C',str(S),'archive',head,'--',*paths],stdout=subprocess.PIPE)
    while data:=process.stdout.read(1024*1024):output.write(data)
    assert process.wait()==0
seen=set()
with tarfile.open(archive,'r|gz') as stream:
    for member in stream:
        if member.isfile():
            data=stream.extractfile(member).read()
            assert len(data)==sizes[member.name] and sha(data)==hashes[member.name]
            seen.add(member.name)
assert seen==set(paths)
oldProof=json.loads((OLD/'source-capsule.json').read_text())
frozen=pathlib.Path(oldProof['frozen']['path'])
assert sha(frozen.read_bytes())==oldProof['frozen']['sha256']
manifest=json.loads((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
assert manifest['rulesVersion']==2 and len(manifest['files'])==184
frozenHashes={}
with tarfile.open(frozen,'r|gz') as stream:
    for member in stream:
        if member.isfile():frozenHashes[member.name]=sha(stream.extractfile(member).read())
assert len(frozenHashes)==497 and all(frozenHashes[p]==h for p,h in manifest['files'].items())
process=subprocess.Popen(['git','-C',str(S),'archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared'],stdout=subprocess.PIPE)
expected={}
with tarfile.open(fileobj=process.stdout,mode='r|') as stream:
    for member in stream:
        if member.isfile():expected[member.name]=sha(stream.extractfile(member).read())
assert process.wait()==0 and expected==frozenHashes
cap=json.loads((OLD/'fixed-runtime.json').read_text())
inputPath=OLD/'native-normal-202800/frames/217800-complete-periodic-after-step.json.gz'
raw=inputPath.read_bytes()
assert sha(raw)=='0d79cbaa67c247c169a26890edd5f445291c7c81a106b3408e741e4f38f97ba7'
saved=json.loads(gzip.decompress(raw))
assert saved['snapshot']['tick']==217800 and set(saved['memories'])=={'p0','p1','p2'}
crew=[u['id'] for u in saved['snapshot']['units'] if u.get('deck',{}).get('shipId')==cap['observedHull']]
assert len(crew)==27 and all(u['expiresTick'] is None if 'expiresTick' in u else True for u in saved['snapshot']['units'] if u['id'] in crew)
lastHits={}
with gzip.open(OLD/'native-normal-202800/hits.jsonl.gz','rt') as stream:
    for line in stream:
        row=json.loads(line)
        if row['tick']>=217800:break
        lastHits[row['target']]=row
cap.update(sourceRoot=str(S),head=head,hashes=hashes,
    driverSHA256=sha((D/'native-normal-from217800.ts').read_bytes()),observerSHA256=sha((D/'observer-ledger.ts').read_bytes()),
    inputPath=str(inputPath),inputSHA256=sha(raw),start=217800,detailedPreThinkUntil=219000,
    observedCrewIds=crew,inheritedLastHits=lastHits,
    classification='Fixedv4 normal3AI changed-code continuation from original fd217800 complete world/id/3mem. Scoped landed caster ground anchor; zero extra public commands, not fresh0.')
cap['observerProtocol'].update(completeFrames='world/nextId/all3mem every600 afterstep; all before-P0 every15 through219000 and600 thereafter; every original P0 input hash retained.',
    actualEffects='Initial27 cohort remains relevant after empty hull clears crewIds; actual normal naval before/after and legality, true parent/disembark/cabin transitions.',
    inheritance='Only actual fd hit rows strictly before217800 seed lastHit; local ledger starts at217800 and does not turn inherited stats into new deaths.',
    priorComparison='Original fixedfd217800→218400 cold normal3AI closed world/id/3mem+800cmd/157hit/40P0hash. Candidate is separate source, not claimed equivalent after first actual behavior difference.')
(D/'fixed-runtime.json').write_text(json.dumps(cap,indent=2)+'\n')
proof={'head':head,'base':'fd42820ae802cc716157a848f216f0a7700de62b','files':len(paths),'hashes':hashes,'sizes':sizes,
    'sourceArchive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payload':len(paths),'allPayloadMatchesWorktreeAndGit':True},
    'frozen':{**oldProof['frozen'],'all497MatchHistoricalGit':True,'all184MatchManifest':True},'manifestSHA256':sha((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes()),
    'nativeFix':oldProof['nativeFix'],'input':{'path':str(inputPath),'bytes':len(raw),'sha256':sha(raw),'tick':217800,'scope':'Original fixedfd complete afterstep before nextP0. Not human/manual/notfresh0.'},
    'actual218040Fixture':json.loads((D/'fixture-provenance.json').read_text())}
(D/'source-capsule.json').write_text(json.dumps(proof,indent=2)+'\n')
(D/'v4-vs-fd.patch').write_bytes(git('diff',proof['base'],head))
summary={'head':head,'sourceFiles':len(paths),'sourceArchive':proof['sourceArchive'],'sourceCapsuleSHA256':sha((D/'source-capsule.json').read_bytes()),'runtimeSHA256':sha((D/'fixed-runtime.json').read_bytes()),'driverSHA256':cap['driverSHA256'],'observerSHA256':cap['observerSHA256'],'input':proof['input'],'frozen':proof['frozen'],'scope':'NoGame launched by this source capsule preparation; no local or match outcome yet.'}
(D/'freeze-and-launch-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
