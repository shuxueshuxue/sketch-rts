import {readFileSync, writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
import {build} from 'esbuild';
import {frozenPolicyModules, frozenPolicyManifest} from '/workspace/sketch-rts-landed-ground-screen-v4-control/scripts/bootstrap_1-planner.ts';

const D='/workspace/.playtest/landed-native-ground-v4-20261016';
const S='/workspace/sketch-rts-landed-ground-screen-v4-control';
const copy=(x:any)=>JSON.parse(JSON.stringify(x));
const sha=(x:any)=>createHash('sha256').update(x).digest('hex');
const cap=JSON.parse(readFileSync(D+'/fixed-runtime.json','utf8'));
const inputPath=D+'/native-normal-from217800/frames/218040-before-p0.json.gz';
const postPath=D+'/native-normal-from217800/frames/218040-physical-transition-after-command-190.json.gz';
const raw=readFileSync(inputPath),saved=JSON.parse(gunzipSync(raw).toString());
const original=JSON.stringify(saved),expectedPost=JSON.parse(gunzipSync(readFileSync(postPath)).toString());
const reference=JSON.parse(readFileSync(D+'/original218040-command-reference.json','utf8'));
const proof=()=>Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);
const sourceBefore=proof();if(sourceBefore.length)throw Error('Fixed source changed');
const runnerPath=S+'/src/ai/policy/script-runner.ts';
const runnerOriginal=readFileSync(runnerPath,'utf8');
const pre='    const rawScriptCommands = withoutUnitsClaimedElsewhere(asCommands(script.run(script.id === "shopping" ? budgetAfter(0) : snapshot, owner, policyOptions)), claims, script.id);';
const after='    if (scriptCommands.length === 0) continue;\n    recordAiMemoryForCommands(snapshot, script.id, scriptCommands, policyOptions.memory';
if(runnerOriginal.split(pre).length!==2||runnerOriginal.split(after).length!==2)throw Error('Instrument anchors not unique');
const hook='(globalThis as any).__original218040Trace';
const instrumented=runnerOriginal.replace(pre,
  `    const traceBefore = ${hook} && (script.id === 'abilities' || script.id === 'naval') ? JSON.parse(JSON.stringify({memory:policyOptions.memory,movedUnitIds:[...movedUnitIds],boardingUnitIds,claims:[...claims]})) : undefined;\n`+pre)
 .replace(after,
  `    if (traceBefore) ${hook}({owner,scriptId:script.id,before:traceBefore,raw:rawScriptCommands,accepted:scriptCommands,afterRunMemory:policyOptions.memory});\n`+after);
const outfile=D+'/original218040-instrumented-planner.mjs';
await build({stdin:{contents:`export {planAiOwnerCommandEntries,createAiMemoryProvider} from '${S}/src/ai/planner-context.ts';`,resolveDir:S,loader:'ts'},bundle:true,platform:'node',format:'esm',outfile,
  plugins:[{name:'external-readonly-runner-observer',setup(builder){builder.onLoad({filter:/\/src\/ai\/policy\/script-runner\.ts$/},args=>{if(args.path!==runnerPath)throw Error('Unexpected runner');return {contents:instrumented,loader:'ts',resolveDir:S+'/src/ai/policy'};});}}]});
const trace:any[]=[];(globalThis as any).__original218040Trace=(row:any)=>trace.push(copy(row));
const {planAiOwnerCommandEntries,createAiMemoryProvider}=await import(pathToFileURL(outfile).href);
const historical=await frozenPolicyModules();
const memories=copy(saved.memories),provider=createAiMemoryProvider(memories);
// The SDK planner view has copied lists and shared entity bodies; planning never applies commands.
const snapshot=copy(saved.snapshot),worldBefore=JSON.stringify(snapshot);
const entries:any[]=[];
for(const owner of Object.keys(cap.agents)){
  const agent=cap.agents[owner],version=agent.policyVersion??agent.version;
  const frozen=['v5','v7','v8'].includes(version),plan=frozen?historical.planAiOwnerCommandEntries:planAiOwnerCommandEntries;
  if(frozen)historical.setBuildingBodies(snapshot.map,[...snapshot.buildings,...snapshot.obstacles??[]]);
  entries.push(...plan(snapshot,{playerId:owner,version,source:agent.traceSource??agent.controller},{teams:snapshot.teams,memoryProvider:provider}));
}
delete (globalThis as any).__original218040Trace;
const normalized=entries.map(({playerId,scriptId,command}:any)=>({owner:playerId,scriptId,command}));
const actual=reference.commands.map(({owner,scriptId,command}:any)=>({owner,scriptId,command}));
const ability=trace.find(row=>row.owner==='p0'&&row.scriptId==='abilities');
if(!ability)throw Error('Missing actual abilities trace');
const cohort=new Set(cap.observedCrewIds),cohortCasts=ability.raw.filter((c:any)=>c.type==='cast'&&cohort.has(c.unitId));
const acceptedCohort=ability.accepted.filter((c:any)=>c.type==='cast'&&cohort.has(c.unitId));
const moved=new Set(ability.before.movedUnitIds);
const result={classification:'One original218040 complete planner think, no Game, no step, no issued commands. External observational bundle only; source bytes unchanged. P0 live source and P1/P2 frozen source execute once in original SDK owner order on the original before-P0 world and memories.',
 sourceHead:cap.head,sourceFiles:Object.keys(cap.hashes).length,inputPath,inputSHA256:sha(raw),postPath,postSHA256:sha(readFileSync(postPath)),frozenRevision:frozenPolicyManifest.revision,frozenFiles:Object.keys(frozenPolicyManifest.files).length,
 instrumentation:{runnerSHA256:sha(runnerOriginal),instrumentedSHA256:sha(instrumented),bundleSHA256:sha(readFileSync(outfile)),onlyChanges:'Local observational trace copies immediately before each naval/abilities run and after original conflict filtering, before original record-memory calls.'},
 equality:{allEntries:isDeepStrictEqual(normalized,actual),entryCount:normalized.length,actualEntryCount:actual.length,all3PostMemories:isDeepStrictEqual(memories,expectedPost.memories),postMemoryByOwner:Object.fromEntries(Object.keys(memories).map(owner=>[owner,isDeepStrictEqual(memories[owner],expectedPost.memories[owner])])),inputFileObjectUnchanged:JSON.stringify(saved)===original,plannerWorldUnchanged:JSON.stringify(snapshot)===worldBefore,nextIdUntouched:saved.nextId===JSON.parse(gunzipSync(raw).toString()).nextId},
 actualEntries:normalized,actualPostMemories:memories,trace,
 blockedCohortCasts:cohortCasts.map((command:any)=>({command,movedEarlier:moved.has(command.unitId),accepted:acceptedCohort.some((c:any)=>isDeepStrictEqual(c,command))})),
 counts:{rawCohortCasts:cohortCasts.length,acceptedCohortCasts:acceptedCohort.length},sourceAfter:proof(),rss:process.memoryUsage().rss,usage:process.resourceUsage()};
writeFileSync(D+'/original218040-full-planner-instrument.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({equality:result.equality,counts:result.counts,allRawCohortActorsMoved:result.blockedCohortCasts.every((r:any)=>r.movedEarlier),sourceAfter:result.sourceAfter,rss:result.rss}));
if(!result.equality.allEntries||!result.equality.all3PostMemories||!result.equality.inputFileObjectUnchanged||!result.equality.plannerWorldUnchanged||result.sourceAfter.length)throw Error('Original full planner closure failed');
