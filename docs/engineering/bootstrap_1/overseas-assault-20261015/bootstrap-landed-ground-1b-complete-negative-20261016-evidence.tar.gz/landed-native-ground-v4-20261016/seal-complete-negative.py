from pathlib import Path
import json,hashlib,tarfile,io,gzip,datetime
D=Path('/workspace/.playtest/landed-native-ground-v4-20261016')
out=Path('/tmp/bootstrap-landed-ground-1b-complete-negative-20261016-evidence.tar.gz')
delivery=Path('/workspace/.playtest/bootstrap-landed-ground-1b-complete-negative-20261016-delivery.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not out.exists() and not delivery.exists()
sources={str(p.relative_to(D)):p for p in D.rglob('*') if p.is_file() and not p.is_symlink() and 'runtime-tmp' not in p.relative_to(D).parts and p.name!='INDEX.json'}
sources['root-frozen-source.tar.gz']=Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-frozen-source.tar.gz')
rows=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for name,p in sorted(sources.items())]
index={'classification':'Sealed fixed1b normal3AI changed-code complete continuation to supported observation stop; no natural winner/fresh0/acceptance. runtime-tmp and symlink dependency caches excluded. Every other closed artifact below the case directory is preserved. Fullsource1568 and historical frozen497 are nested archives with separate complete proofs.','root':D.name,'payloadFiles':len(rows),'files':rows}
indexBytes=(json.dumps(index,indent=2)+'\n').encode();(D/'INDEX.json').write_bytes(indexBytes)
with out.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',compresslevel=3,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tf:
 for row in rows:
  p=sources[row['path']];b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
  info=tarfile.TarInfo(D.name+'/'+row['path']);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
 info=tarfile.TarInfo(D.name+'/INDEX.json');info.size=len(indexBytes);info.mode=0o644;tf.addfile(info,io.BytesIO(indexBytes))
expect={D.name+'/'+r['path']:r for r in rows};seen=set();regular=0
with tarfile.open(out,'r|gz') as tf:
 for item in tf:
  if not item.isfile():continue
  regular+=1;b=tf.extractfile(item).read()
  if item.name==D.name+'/INDEX.json':assert b==indexBytes;continue
  assert item.name not in seen and item.name in expect
  row=expect[item.name];assert item.size==row['bytes'] and len(b)==row['bytes'] and sha(b)==row['sha256'];seen.add(item.name)
assert seen==set(expect) and regular==len(rows)+1
for row in rows:
 p=sources[row['path']];assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256']
result={'sealedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'payloadFiles':len(rows),'regularFilesIncludingIndex':regular,'indexSHA256':sha(indexBytes),'allPayloadHashesBytesCoverageVerified':True,'originalPayloadsUnchanged':True,'sourceHead':'1b15724175c01a444a1a83a0182826fcebf4024f','liveSourceFiles':1568,'frozenManifestFiles':184,'historicalFullFrozenArchiveFiles':497,'start':217800,'end':319200,'winner':None,'naturalComplete':False,'observationStopped':True,'ordinary0':False,'productionMerged':False,'principalFinding':'Ground-target fix removes8reboards but first27 all die versus oldfd20deaths/7survivors. Actual original218040 fullplanner14ready summon requests rejected after naval physical ownership; all14 later truly summon, so delayed execution is diagnosed without claiming a guaranteed tactical rescue.','report':str(D/'native-normal-from217800/report.json'),'audit':str(D/'terminal-audit/FINAL-CASE-AUDIT.json'),'readme':str(D/'README.final-negative.zh.md'),'runtimeFrozenScopeGap':'Full497 historicalarchive verified; runtime184 prepost verified. Remaining313 runtime files lack separateposthash before loadercleanup.','originalContainerUncommittedGap':'Unrecovered'}
delivery.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
