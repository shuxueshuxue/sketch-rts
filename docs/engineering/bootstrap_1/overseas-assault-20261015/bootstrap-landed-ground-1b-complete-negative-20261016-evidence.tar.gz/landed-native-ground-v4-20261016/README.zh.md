# v4 草稿：真实登陆施法站位的地面点选

基于固定 fd42820a 的独立控制树，原 fd Game 继续。本候选不使用人工装载端点或命令，不改变规则 2、184 冻结策略、1.4 动态准入、normal 敌方或三条路线。原容器未提交修改仍未恢复。

问题来自真实正常三方 218040：plain ground move 的公开坐标位于己方 carrier 船壳，native deckPointOrder 因此记录 deckShipId，8 名健康 casters 随后实际重登船。27 人已于 218025 全部真实登岸，不能误记成部署未发生。完整原源 cold600 对照和新重建输入的范围见 fixture-provenance.json；20 人随后死亡的完整反事实因果仍待正常三方对照。

草稿将 native 原有首 hull 点选提为同一纯 helper，保留敌船、已死但未 cleanup 船、多船原序与 hull 而非仅 deck 的语义；共享默认 screen 不传 opt-in 时保原逻辑。只有 bootstrap landed 调用额外站位选择，在目标实际冲突当前船体时，用当前 hull 外轮廓/有限地面 cell 选择真正可站、同地面、terrain road 原生 hull sweep 不截断的目标，保留 body+原生 5 像素到达净空。动态身体/船运动仍由真实模拟决定，有限候选不证明任意可达。

首个 leaf512 纯查询不建 Game、不 step、不做 fullP0、不发布命令：真实输入不变，17 个新地面目标均不点中 hull；另一个近安全点 caster 无需重发。最终 6 文件 36 项相关合同通过（含 8 项新增 native 点选/岸路合同），单次 1024 MiB 类型检查实际退出 0。固定源为 `1b15724175c01a444a1a83a0182826fcebf4024f`，1568 文件源码已逐字节封存，184 manifest / 497 历史冻结档仍完全相同；见 validation-final-source-binding.json 与 source-capsule.json。尚未启动 v4 正常三方对照，未合生产。

v4 的对照起点是原 fd 的真实 217800 完整 after-step/before-next-P0 档；27 人已由 fd 正常策略自动装载并航行，本候选继承其真实身体和所有三方记忆，不能把输入时已有 27 cargo 归为 v4 新装载成果。先核第一行为差和 218025 实卸，再看再登船、实际命中/伤亡和同源全局后果。
