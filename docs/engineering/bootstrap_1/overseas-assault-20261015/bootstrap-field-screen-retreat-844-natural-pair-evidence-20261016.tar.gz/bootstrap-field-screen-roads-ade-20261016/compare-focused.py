import json,gzip,hashlib,math,collections
from pathlib import Path
p=Path(__file__).parent
uid='unit-p0-horseArcher-4294'
def readlines(name):return [json.loads(l) for l in (p/name).read_text().splitlines() if l.strip()]
def endpoint(name):return json.loads(gzip.decompress((p/(name+'-terminal.json.gz')).read_bytes()))
def branch(name):
    report=json.loads((p/(name+'.json')).read_text());end=endpoint(name);hits=readlines(name+'-native-hits.jsonl');launch=readlines(name+'-launches.jsonl');health=readlines(name+'-health-transitions.jsonl');heals=readlines(name+'-healing-effects.jsonl');effects=readlines(name+'-command-effects.jsonl');rows=[]
    for e in health:
        matching=[h for h in heals if h['tick']==e['tick']and h['phase']==e['phase']]
        for u in e['rows']:
            candidates=[h for h in matching if h['effect'].get('owner')==u['owner']]
            if not u['maxHPChanged']:
                assert len(candidates)==1,'Ambiguous heal balance'
                effect=candidates[0]['effect']
                assert effect['actionMode']=='cast'and effect['actionTick']==e['tick']
                before=u['before'];after=u['after']
                assert before['maxHp']==after['maxHp']
                assert abs(u['restorationIncludingGrowthAndRegeneration']-min(55,before['maxHp']-before['hp']+u['damageToPositiveHP']))<1e-8
                rows.append(dict(tick=e['tick'],target=u['id'],owner=u['owner'],effectiveHP=u['restorationIncludingGrowthAndRegeneration'],caster=effect['sourceId'],nativeEffectId=effect['id'],beforeHP=before['hp'],afterHP=after['hp'],sameStepPositiveHPDamage=u['damageToPositiveHP'],maxHP=after['maxHp']))
    rider=next(u for u in end['snapshot']['units']if u['id']==uid)
    initial=json.loads(gzip.decompress(Path(report['input']).read_bytes()));initialCorpses={x['id']for x in initial['snapshot']['corpses']};deaths=[x for x in end['snapshot']['corpses']if x['id']not in initialCorpses]
    damage=lambda owner:sum(max(0,min(h['damage'],h['hpBefore']))for h in hits if h['attackerOwner']==owner)
    return dict(reportFile=str(p/(name+'.json')),source=report['source'],head=report['head'],mandatory=report['mandatory'],restore=json.loads((p/(name+'-restore.json')).read_text()),riderAtEnd=rider,riderLaunches=[x for x in launch if x['projectile']['attackerId']==uid],riderOutgoing=[h for h in hits if h['attacker']==uid],riderIncoming=[h for h in hits if h['target']==uid],riderCommandLiveEffects=effects,effectiveDamageByOwner={o:damage(o)for o in ['p0','p1','p2','neutral']},effectiveHealing=rows,effectiveHealingByOwner={o:sum(x['effectiveHP']for x in rows if x['owner']==o)for o in ['p0','p1','p2','neutral']},excludedMaxHPChangeRestorations=[dict(tick=e['tick'],id=u['id'],gain=u['restorationIncludingGrowthAndRegeneration'])for e in health for u in e['rows']if u['maxHPChanged']],newCorpses=deaths,nativeLossBefore=initial['snapshot']['match']['stats']['unitsLost'],nativeLossAfter=end['snapshot']['match']['stats']['unitsLost'],pendingTowerArrowsAtEnd=[x for x in end['snapshot']['projectiles']if x['targetId']==uid and x['attackerId'].startswith('building')])

a=branch('/workspace/.playtest/bootstrap-mounted-cooldown-20261016/base15255-15855');b=branch(str(p/'v3-actual15255-15855'))
baseCmd=readlines('/workspace/.playtest/bootstrap-mounted-cooldown-20261016/base15255-15855-commands.jsonl');candCmd=readlines(str(p/'v3-actual15255-15855-commands.jsonl'))
first=next(dict(position=i,baseline=x,candidate=y)for i,(x,y)in enumerate(zip(baseCmd,candCmd))if x!=y)
assert first['baseline']['tick']==first['candidate']['tick']==15285
assert a['restore']['sha256']==b['restore']['sha256']
assert all(a['mandatory'].values())and all(b['mandatory'].values())
result=dict(classification='FOCUSED ONLY currentade versus844 field-front-road from sameactual15255 input,600ticks normal3AI. No naturalcomplete/ordinary0/acceptance claim. Independently conserved negativev1/v2contracts not erased.',baseline=a,candidate=b,firstCommandDifference=first,limits=['All effective damage is capped at positiveHP; emittedcommands may be transientno-op, live firstmove effects/projectiles/hits retained.','Observed heals here are unique same-step native cast effects with55 cap and exactHP balance, excludingmaxHPgrowth; not a universal healer-attribution algorithm.','Candidate125HP southreturn is not proof of rejoining or winning. Fullteamdamage and kills lower too.','Same-input fullP0plan10states proves no directnon-rider orpostmemorysourceintent change in those states, not universal getter purity.','General15645 guard is actual changedworld intrusion, not a claimed unique cause of eventualresult.'])
(p/'FOCUSED-COMPARISON.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({label:{'hp':d['riderAtEnd']['hp'],'position':[d['riderAtEnd']['x'],d['riderAtEnd']['y']],'damage':d['effectiveDamageByOwner'],'healing':d['effectiveHealingByOwner'],'newCorpses':[(c['owner'],c['kind'])for c in d['newCorpses']],'riderOutgoing':[(h['tick'],h['damage'])for h in d['riderOutgoing']],'riderIncoming':[(h['tick'],h['damage'])for h in d['riderIncoming']]}for label,d in [('base',a),('v3',b)]},indent=2))
