import {writeFileSync} from 'node:fs';
import { expect, it } from 'vitest';
import { sketchScene } from '/workspace/sketch-rts-field-screen-retreat-control/src/sdk/scene';
import { issueCommandFrame } from '/workspace/sketch-rts-field-screen-retreat-control/src/sdk/commands/frame';
import { issuePlayerCommand, snapshotGame, stepGame } from '/workspace/sketch-rts-field-screen-retreat-control/src/shared/sim';
import { setBuildingBodies, snapToFootprint } from '/workspace/sketch-rts-field-screen-retreat-control/src/shared/terrain';
import { UNIT_DEFS, UPGRADE_DEFS } from '/workspace/sketch-rts-field-screen-retreat-control/src/shared/catalog';
import { createAiPolicyMemory } from '/workspace/sketch-rts-field-screen-retreat-control/src/ai/memory';
import { planAiOwnerCommandEntries } from '/workspace/sketch-rts-field-screen-retreat-control/src/ai/planner-context';

it.each((['v9_archer', 'v9_summoner', 'v9_knight'] as const).flatMap(version =>
  ([{ kind: 'footman', speed: false }, { kind: 'footman', speed: true }, { kind: 'emberRavager', speed: true }] as const)
    .flatMap(setup => [false, true].map(mirror => ({ version, ...setup, mirror }))))) (
  '$version uses two paid riders to kill six $kind pursuers without injury (speed=$speed mirror=$mirror)', ({ version, kind, speed, mirror }) => {
    const x = (value: number) => mirror ? 4096 - value : value;
    let scene = sketchScene('mounted-field-without-mine-or-camp').map('bareDuel').replaceDefaults()
      .player('us', { race: 'grove', team: 'a' }).player('foe', { race: kind === 'footman' ? 'grove' : 'ember', team: 'b' })
      .townHall('us', x(500), 500).townHall('foe', x(3500), 3500)
      .building('us', 'stables', x(1000), 1600, { id: 'stables' }).farms('us', 7, x(400), 3000);
    for (let i = 0; i < 6; i++) scene = scene.unit('foe', kind, x(1800 + i % 3 * 45), 1700 + Math.floor(i / 3) * 45,
      { id: `pursuer-${i}` });
    const game = scene.build().createGame(), memory = createAiPolicyMemory();
    game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: '.'.repeat(128 * 128) };
    for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
    setBuildingBodies(game.map, game.buildings);
    issuePlayerCommand(game, 'foe', { type: 'holdPosition', unitIds: game.units.filter(unit => unit.owner === 'foe').map(unit => unit.id) });
    for (let i = 0; i < 2; i++) {
      issuePlayerCommand(game, 'us', { type: 'train', buildingId: 'stables', unitKind: 'horseArcher' });
      for (let tick = 0; tick <= UNIT_DEFS.horseArcher.trainTime; tick++) stepGame(game);
    }
    const technology = UPGRADE_DEFS.speedTraining.levels[0]!;
    if (speed) {
      issuePlayerCommand(game, 'us', { type: 'research', buildingId: 'stables', upgradeKind: 'speedTraining' });
      for (let tick = 0; tick <= technology.researchTime; tick++) stepGame(game);
      expect(game.players.us!.upgrades.speedTraining).toBe(1);
    }
    const riders = game.units.filter(unit => unit.owner === 'us' && unit.kind === 'horseArcher');
    expect(riders).toHaveLength(2);
    const dealt = new Map(riders.map(rider => [rider.id, 0]));
    let injury = 0, tookFieldCommand = false;
    const copy=(v:any)=>JSON.parse(JSON.stringify(v));
    let firstDamage:any=null;
    const stepRing:any[]=[], thinkRing:any[]=[], traceSteps:any[]=[], traceThinks:any[]=[], observedHits:any[]=[], traceFrames:any[]=[];
    const compact=()=>copy({tick:game.tick,units:game.units.filter(u=>u.kind==='horseArcher'||u.id.startsWith('pursuer-')),projectiles:game.projectiles,effects:game.effects});
    const stepRecord=()=>{const f=compact();stepRing.push(f);if(stepRing.length>60)stepRing.shift();if(game.tick<=2000)traceSteps.push(f);};
    game.observer = { hit(source, target, damage) {
      const hit=copy({tick:game.tick,source,target,damage});
      if(firstDamage===null||game.tick<=firstDamage.tick+45)observedHits.push(hit);
      if(firstDamage===null&&'order' in target&&riders.includes(target)){
        firstDamage=hit;
      }
      if ('order' in target && riders.includes(target)) injury += damage;
      if (riders.some(rider => rider.id === source.id) && target.id.startsWith('pursuer-'))
        dealt.set(source.id, dealt.get(source.id)! + damage);
    } };
    for (let tick = 0; tick < 6000 && game.units.some(unit => unit.id.startsWith('pursuer-'))
      && riders.some(rider => rider.hp > 0); tick++) {
      if (tick % 15 === 0) {
        const planningSnapshot=snapshotGame(game);
        const complete=copy({snapshot:planningSnapshot,nextId:game.nextId,memory});
        thinkRing.push(complete);if(thinkRing.length>5)thinkRing.shift();
        if(game.tick<=2000)traceThinks.push(complete);
        const entries = planAiOwnerCommandEntries(planningSnapshot,
          { playerId: 'us', version, memory, policyMode: 'combat' }, { teams: game.teams });
        tookFieldCommand ||= entries.some(entry => entry.scriptId === 'mountedField');
        const liveBefore=compact();
        issueCommandFrame(game, entries);
        if(firstDamage===null||game.tick<=firstDamage.tick+45)traceFrames.push(copy({tick:game.tick,entries,before:liveBefore,after:compact()}));
        for (const pursuer of game.units.filter(unit => unit.id.startsWith('pursuer-'))) {
          const target = riders.filter(rider => rider.hp > 0).sort((a, b) =>
            Math.hypot(pursuer.x - a.x, pursuer.y - a.y) - Math.hypot(pursuer.x - b.x, pursuer.y - b.y))[0]!;
          issuePlayerCommand(game, 'foe', { type: 'attack', unitIds: [pursuer.id], targetId: target.id });
        }
      }
      stepGame(game);stepRecord();
    }
    writeFileSync('/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016/v1-ravager-prefix-trace.json',JSON.stringify({classification:'Passive exact original test: imports+observation only; original commands/assertions preserved, first-hit mid-step observer state is labelled as such.',firstDamage,traceSteps,traceThinks,traceFrames,observedHits,final:{tick:game.tick,injury,dealt:Object.fromEntries(dealt),remaining:game.units.filter(u=>u.id.startsWith('pursuer-')),riders}})+'\n');
    const diagnostic = JSON.stringify({ tick: game.tick, injury, tookFieldCommand, dealt: Object.fromEntries(dealt),
      riders: riders.map(rider => ({ hp: rider.hp, maxHp: rider.maxHp, order: rider.order })),
      remaining: game.units.filter(unit => unit.id.startsWith('pursuer-')), memory });
    expect(tookFieldCommand, diagnostic).toBe(true);
    expect(game.units.some(unit => unit.id.startsWith('pursuer-')), diagnostic).toBe(false);
    expect(injury, diagnostic).toBe(0);
    expect(riders.every(rider => game.units.includes(rider) && rider.hp === rider.maxHp), diagnostic).toBe(true);
    expect(game.match.stats.unitsLost.us).toBe(0);
    const cost = 2 * UNIT_DEFS.horseArcher.cost + (speed ? technology.cost : 0);
    expect(game.match.stats.goldSpent.us).toBe(cost);
    expect(game.players.us!.gold).toBe(500 - cost);
    expect(game.match.winner).toBeNull();
  }, 30000);
