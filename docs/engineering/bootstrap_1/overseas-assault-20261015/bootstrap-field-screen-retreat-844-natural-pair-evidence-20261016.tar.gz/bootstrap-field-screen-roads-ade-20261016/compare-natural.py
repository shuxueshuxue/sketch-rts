import json,gzip,collections,hashlib
from pathlib import Path
P=Path(__file__).parent
UID='unit-p0-horseArcher-4294'
def lines(p):return [json.loads(l)for l in p.read_text().splitlines()if l]
def frame(p):return json.loads(gzip.decompress(p.read_bytes()))
def one(label):
 p=P/(label+'-natural15855');r=json.loads((p/'report.json').read_text());f=frame(p/'final.json.gz');initial=frame(Path(r['input']));es=lines(p/'native-deaths.jsonl');state={}
 for e in es:
  if e['type']=='native-unit-terminal':state[e['id']]={'event':e,'status':e['confirmation']}
  elif e['type']=='terminal-status-update'and e['id']in state:state[e['id']]['status']=e['status']
 confirmed=[s['event']for s in state.values()if s['status']in['absent-at-native-boundary','native-removal-after-nonpositive']and s['event']['terminalClass']=='death-observed']
 unknown=[{'id':i,'status':s['status'],'terminalClass':s['event']['terminalClass']}for i,s in state.items()if s['status']not in['absent-at-native-boundary','native-removal-after-nonpositive','returned-positive']or s['event']['terminalClass']=='removal-cause-unconfirmed']
 stats0=initial['snapshot']['match']['stats']['unitsLost'];stats1=f['snapshot']['match']['stats']['unitsLost'];closure={}
 for owner in stats1:
  perm=[e for e in confirmed if(e.get('atObservation')or e['previous'])['owner']==owner and e['permanent']]
  temp=[e for e in confirmed if(e.get('atObservation')or e['previous'])['owner']==owner and not e['permanent']]
  expired=[s['event']for s in state.values()if(s['event'].get('atObservation')or s['event']['previous'])['owner']==owner and s['event']['terminalClass']=='lifetime-expiry-eligible-removal']
  corpses=[c for c in f['snapshot']['corpses']if c['owner']==owner]
  closure[owner]={'priorNativeLoss':stats0[owner],'finalNativeLoss':stats1[owner],'delta':stats1[owner]-stats0[owner],'confirmedPermanent':len(perm),'confirmedTemporary':len(temp),'expiryEligible':len(expired),'nativeDeltaEqualConfirmedDeaths':stats1[owner]-stats0[owner]==len(perm)+len(temp),'finalRetainedCorpses':len(corpses),'corpseIsCappedNativeHistory':True}
 hits=lines(p/'native-hits.jsonl');riderHits=[h for h in hits if h['attacker']==UID];riderIncoming=[h for h in hits if h['target']==UID];riderTerminal=state.get(UID)
 cohorts=[u for u in initial['snapshot']['units']if u['owner']=='p0'and (u.get('level',0)>0 or u['kind']in['priest','fieldMedic']or u['id']==UID)]
 cohort=[]
 for u in cohorts:
  t=state.get(u['id']);end=next((x for x in f['snapshot']['units']if x['id']==u['id']),None)
  cohort.append({'id':u['id'],'kind':u['kind'],'levelAtStart':u.get('level'),'killsAtStart':u.get('kills'),'startHP':u['hp'],'terminal':t,'end':end})
 return {'report':r,'restoreReport':json.loads((p/'restore.json').read_text()),'ledgerClosure':closure,'unknownTerminals':unknown,'riderTerminal':riderTerminal,'riderNativeHits':len(riderHits),'riderEffectiveDamageAfter15855':sum(max(0,min(h['hpBefore'],h['damage']))for h in riderHits),'riderIncomingHits':len(riderIncoming),'riderObservedHealEffects':[(e['tick'],e['effect'])for e in lines(p/'healing-effects.jsonl')if e['effect'].get('sourceId')==UID],'initialVeteranAndHealerCohort':cohort,'finalRetainedCorpses':f['snapshot']['corpses'],'finalOwnLive':[(u['id'],u['kind'],u['hp'],u.get('level'),u.get('kills'))for u in f['snapshot']['units']if u['owner']=='p0'and u['hp']>0],'finalOwnBuildings':[(b['id'],b['kind'],b['hp'])for b in f['snapshot']['buildings']if b['owner']=='p0'and b['hp']>0]}
a=one('ade');b=one('v3')
assert all(c['nativeDeltaEqualConfirmedDeaths']for d in[a,b]for c in d['ledgerClosure'].values())
assert not a['unknownTerminals']and not b['unknownTerminals']
assert all(d['report']['sourceExact']and d['report']['frozenExact']and d['report']['naturalComplete']for d in[a,b])
samples={label:{s['tick']:s for s in lines(P/(label+'-natural15855')/'samples.jsonl')}for label in ['ade','v3']}
timeline=[{'tick':t,'ade':samples['ade'][t],'v3':samples['v3'][t]}for t in sorted(set(samples['ade'])&set(samples['v3']))if t==15855 or t%3000==0]
out={'classification':'Natural full3AI strategy pair, each15255 same complete actual input via respective600focus and15855 ownfullstate onward. NOTordinary0/newseed/unseen. ade currentproduction baseline;844 candidate onlyfieldfrontroad. e56643714win andab041057loss remain independent lineage references, not pair baselines. No weakening or newdeadline.','baseline':a,'candidate':b,'comparableTimeline':timeline,'limits':['Corpses are native capped history; all-owner confirmed-removal ledger andnativeunitsLostDelta close separately. Nonpositiveprovisional observations not directly counted as irrevocable losses.','Fulltail HP-restoration stream records stepbalance, includesgrowth/regen; instantaneouscommand healing may not be represented there. Nativeheal effects andraw commands retained; not allcasts counted as effectivehealing. Focused600 separately proves4actualheals.','Candidate singlecase naturalresult is notthreefamily/fullmatrix/generalization acceptance.','Dynamicreturn target is currentactualfront; futuremovement/survival/crowdnotpredicted. Source39contracts includeall3family publicfieldcases but do not substituteactualcompletefamilymatches.']}
(P/'NATURAL-PAIR-COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({label:{'result':d['report']['result'],'nativeLoss':d['report']['fullOriginalStats']['unitsLost'],'ownEnd':len(d['finalOwnLive']),'ownBuildings':len(d['finalOwnBuildings']),'enemyEnd':d['report']['enemyAtEnd'],'riderTerminal':None if not d['riderTerminal']else {'tick':d['riderTerminal']['event']['tick'],'status':d['riderTerminal']['status'],'unit':d['riderTerminal']['event'].get('atObservation')or d['riderTerminal']['event']['previous']},'riderDamageAfter15855':d['riderEffectiveDamageAfter15855'],'closure':d['ledgerClosure']}for label,d in [('ade',a),('v3',b)]},indent=2))
