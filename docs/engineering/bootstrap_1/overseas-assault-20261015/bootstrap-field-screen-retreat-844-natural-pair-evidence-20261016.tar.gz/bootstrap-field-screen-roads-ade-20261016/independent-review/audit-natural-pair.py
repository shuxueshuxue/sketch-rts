"""Offline evidence audit only. Does not import/execute game or comparator code."""
import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016')
OUT = Path(__file__).parent
UID = 'unit-p0-horseArcher-4294'
PRIOR = Path('/workspace/.playtest/bootstrap-mounted-cooldown-20261016/base15255-15855')
COMMON = Path('/workspace/.playtest/bootstrap-mercenary-return-postloss-diagnostic-20261016/horse4294-native/ade-approach15000-15410.prethink/15255.json.gz')


def read(path):
    return json.loads(Path(path).read_text())


def frame(path):
    return json.loads(gzip.decompress(Path(path).read_bytes()))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mapping(items):
    result = {row['path']: row['sha256'] for row in items}
    assert len(result) == len(items), 'Duplicate audited source paths'
    return result


comparison = read(ROOT / 'NATURAL-PAIR-COMPARISON.json')
common = frame(COMMON)
capsule = read('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game-runtime-source.json')
frozen_expected = capsule['frozenFiles']
results = {}
source_maps = {}
frozen_maps = {}

for label, comparison_key, prefix in [('ade', 'baseline', PRIOR), ('v3', 'candidate', ROOT / 'v3-actual15255-15855')]:
    directory = ROOT / (label + '-natural15855')
    report = read(directory / 'report.json')
    compared = comparison[comparison_key]
    assert report == compared['report']
    restore = read(directory / 'restore.json')
    initial_path = Path(report['input'])
    initial = frame(initial_path)
    final = frame(directory / 'final.json.gz')
    assert digest(initial_path) == restore['inputSHA256']
    assert all(restore['checks'].values()) and report['restore'] == restore['checks']
    assert initial == frame(str(prefix) + '-terminal.json.gz')
    assert initial == frame(str(prefix) + '.frames/15855.json.gz')
    assert initial == frame(directory / 'frames/15855.json.gz')
    assert final == frame(directory / ('frames/' + str(final['snapshot']['tick']) + '.json.gz'))
    assert frame(str(prefix) + '.frames/15255.json.gz') == common
    focus_restore = read(str(prefix) + '-restore.json')
    assert focus_restore['input'] == str(COMMON) and focus_restore['sha256'] == digest(COMMON)
    assert all(focus_restore['checks'].values())
    focus_report = read(str(prefix) + '.json')
    assert focus_report['input'] == str(COMMON) and focus_report['result']['tick'] == 15855
    assert all(focus_report['mandatory'].values())
    assert set(initial['memories']) == {'p0', 'p1', 'p2'}
    assert initial['setup'] == common['setup'] == final['setup']
    assert final['snapshot']['tick'] == report['result']['tick'] == final['snapshot']['match']['endedAtTick']
    assert final['snapshot']['match']['winner'] == report['result']['winner']
    assert report['naturalComplete'] and report['observationStop'] is None
    assert final['snapshot']['match']['stats'] == report['fullOriginalStats']

    source = Path(report['source'])
    pre = read(directory / 'source-preflight.json')
    post = read(directory / 'source-postflight.json')
    assert pre == post['source'] and pre['head'] == report['head'] and pre['status'] == ''
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == report['head']
    assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source, text=True) == ''
    recorded = mapping(pre['files'])
    assert len(recorded) == report['sourceFiles']
    tree = subprocess.check_output(['git', 'ls-tree', '-r', report['head']], cwd=source).decode()
    blobs = {line.split('\t', 1)[1]: line.split('\t', 1)[0].split()[2] for line in tree.splitlines()}
    for path, expected in recorded.items():
        data = (source / path).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, path
        assert hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest() == blobs[path], path
    focus_pre = read(str(prefix) + '-source-preflight.json')
    focus_post = read(str(prefix) + '-source-postflight.json')
    assert focus_pre == focus_post['source']
    assert mapping(focus_pre['inherited'] + focus_pre['extras']) == recorded
    source_maps[label] = recorded
    assert post['frozenPre'] == post['frozenPost']
    frozen_maps[label] = mapping(post['frozenPre'])
    assert frozen_maps[label] == frozen_expected
    assert focus_post['frozenPre'] == focus_post['frozenPost'] == post['frozenPre']
    assert len(frozen_maps[label]) == report['frozenFiles'] == 497
    manifest = read(source / 'docs/engineering/bootstrap_1/frozen-policy.json')
    assert manifest['rulesVersion'] == initial['setup']['rulesVersion'] == 2
    assert manifest['revision'] == initial['setup']['frozenRevision']

    # Final status, rather than a provisional nonpositive observation, determines
    # inclusion. Check both positive-HP native hits and disappearance evidence.
    deaths = rows(directory / 'native-deaths.jsonl')
    states = {}
    for event in deaths:
        if event['type'] == 'native-unit-terminal':
            states[event['id']] = [event, event['confirmation']]
        else:
            assert event['type'] == 'terminal-status-update' and event['id'] in states
            states[event['id']][1] = event['status']
    hits = rows(directory / 'native-hits.jsonl')
    hits_by_index = {hit['index']: hit for hit in hits}
    final_ids = {unit['id'] for unit in final['snapshot']['units']}
    accepted_statuses = {'absent-at-native-boundary', 'native-removal-after-nonpositive'}
    closure = {}
    for owner, total in final['snapshot']['match']['stats']['unitsLost'].items():
        confirmed = []
        for unit_id, (event, status) in states.items():
            body = event['atObservation'] or event['previous']
            if body['owner'] != owner:
                continue
            assert status in accepted_statuses | {'returned-positive'}
            assert event['terminalClass'] != 'removal-cause-unconfirmed'
            if status not in accepted_statuses or event['terminalClass'] != 'death-observed':
                continue
            assert unit_id not in final_ids
            assert event['permanent'] == ('expiresTick' not in body)
            evidence = event['evidence']
            if evidence.get('nativePositiveToNonpositiveHit'):
                fatal = evidence['nativePositiveToNonpositiveHit']
                assert fatal == hits_by_index[fatal['index']] and fatal['target'] == unit_id
                assert fatal['hpBefore'] > 0 and fatal['hpAfter'] <= 0 and fatal['positiveToNonpositive']
            else:
                assert evidence.get('hpNonpositive') or evidence.get('corpse') or evidence.get('aboardLivingAtHullFatal') or evidence.get('knownDeadHull')
            confirmed.append(event)
        before = initial['snapshot']['match']['stats']['unitsLost'][owner]
        permanent = sum(event['permanent'] for event in confirmed)
        temporary = len(confirmed) - permanent
        assert total - before == permanent + temporary
        expected = compared['ledgerClosure'][owner]
        assert (before, total, permanent, temporary) == (expected['priorNativeLoss'], expected['finalNativeLoss'], expected['confirmedPermanent'], expected['confirmedTemporary'])
        closure[owner] = {'initial': before, 'final': total, 'confirmedPermanentDelta': permanent, 'confirmedTemporaryDelta': temporary}
    assert not compared['unknownTerminals']
    assert not report['telemetry']['pendingNativeCleanup']
    terminal, status = states[UID]
    body = terminal['atObservation'] or terminal['previous']
    assert UID not in final_ids and status in accepted_statuses
    assert terminal == compared['riderTerminal']['event'] and status == compared['riderTerminal']['status']
    initial_rider = next(unit for unit in initial['snapshot']['units'] if unit['id'] == UID)
    rider_fatal_hits = [hit for hit in hits if hit['attacker'] == UID and hit['targetIsUnit'] and hit['positiveToNonpositive']]
    assert initial_rider['kills'] + len(rider_fatal_hits) == body['kills']
    own = [unit for unit in final['snapshot']['units'] if unit['owner'] == 'p0' and unit['hp'] > 0]
    own_buildings = [building for building in final['snapshot']['buildings'] if building['owner'] == 'p0' and building['hp'] > 0]
    assert [[u['id'], u['kind'], u['hp'], u.get('level'), u.get('kills')] for u in own] == compared['finalOwnLive']
    assert [[b['id'], b['kind'], b['hp']] for b in own_buildings] == compared['finalOwnBuildings']
    enemies = {owner: {'units': sum(unit['owner'] == owner and unit['hp'] > 0 for unit in final['snapshot']['units']), 'buildings': sum(building['owner'] == owner and building['hp'] > 0 for building in final['snapshot']['buildings'])} for owner in ['p1', 'p2']}
    assert enemies == report['enemyAtEnd']
    building_teams = {final['snapshot']['teams'][building['owner']] for building in final['snapshot']['buildings'] if building['owner'] in ['p0', 'p1', 'p2']}
    assert building_teams == {final['snapshot']['teams'][report['result']['winner']]}
    first_building = next(building for building in final['snapshot']['buildings'] if building['owner'] in ['p0', 'p1', 'p2'])
    assert first_building['owner'] == report['result']['winner']
    results[label] = {'head': report['head'], 'sourceFiles': len(recorded), 'frozenFiles': len(frozen_maps[label]),
        'common15255DeepEqual': True, 'own600EndAndNatural15855DeepEqual': True, 'finalFrameDeepEqual': True,
        'input15855SHA256': digest(initial_path), 'sourceAndCommitBlobChecks': 'all matched',
        'sourceAndFrozenPrePostExact': True, 'focusSourceAndFrozenMatchNatural': True,
        'result': {key: report['result'][key] for key in ['tick', 'winner']},
        'closure': closure, 'provisionalObservations': sum(event.get('confirmation') == 'hp<=0-awaiting-cleanup' for event in deaths),
        'confirmedAfterNonpositive': sum(event.get('status') == 'native-removal-after-nonpositive' for event in deaths),
        'returnedPositiveUpdates': sum(event.get('status') == 'returned-positive' for event in deaths),
        'rider': {'deathTick': terminal['tick'], 'confirmation': status, 'lastKills': body['kills'], 'lastLevel': body['level'], 'lastMaxHP': body['maxHp'], 'initialKillsAt15855': initial_rider['kills'], 'confirmedUnitFatalHitsAfter15855': len(rider_fatal_hits), 'aliveAtEnd': False,
            'fatalHit': {key: terminal['lastNativeHit'][key] for key in ['attacker', 'attackerKind', 'tick', 'damage', 'hpBefore', 'hpAfter']}},
        'ownEnd': {'units': len(own), 'buildings': len(own_buildings)}, 'enemyEnd': enemies,
        'remainingBuildingTeams': sorted(building_teams),
        'baselineSurvivors': [{key: unit[key] for key in ['id', 'kind', 'hp', 'kills', 'level']} for unit in own] if label == 'ade' else None}

assert frozen_maps['ade'] == frozen_maps['v3']
source = Path(comparison['candidate']['report']['source'])
revision = common['setup']['frozenRevision']
archive = subprocess.check_output(['git', 'archive', revision, 'package.json', 'src/ai', 'src/sdk', 'src/shared'], cwd=source)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    archived = {member.name: hashlib.sha256(tar.extractfile(member).read()).hexdigest() for member in tar.getmembers() if member.isfile()}
assert archived == frozen_expected
changed = [path for path in source_maps['ade'].keys() & source_maps['v3'].keys() if source_maps['ade'][path] != source_maps['v3'][path]]
added = sorted(source_maps['v3'].keys() - source_maps['ade'].keys())
audit = {'classification': 'Independent offline raw-evidence audit; no simulation, query, test, tsc or parent comparator execution.',
    'comparisonSHA256': digest(ROOT / 'NATURAL-PAIR-COMPARISON.json'), 'scriptSHA256': digest(__file__),
    'commonInput': {'path': str(COMMON), 'sha256': digest(COMMON), 'tick': common['snapshot']['tick'], 'rulesVersion': common['setup']['rulesVersion'], 'memories': sorted(common['memories'])},
    'frozenArchiveRevision': revision, 'frozen497ExactToGitArchiveAndAllFourPrePostInventories': True,
    'sourceDelta': {'changed': sorted(changed), 'added': added, 'removed': sorted(source_maps['ade'].keys() - source_maps['v3'].keys())},
    'runs': results,
    'limits': ['Same existing actual15255 state with each source then its own15855 continuation, not ordinary0 or a fresh unseen generalization trial.',
        'Native victory depends on remaining active-team buildings, not all own units being dead. Baseline has two live p0 lancers and no p0 buildings; winner p1 identifies surviving team b, which also includes p2.',
        '4294 achieved13 recorded unit kills but died at37186. It is absent from the winning terminal world.',
        'Provisional observations are counted only after confirmed native removal. UnitsLost total includes inherited pre15855 losses; only each respective delta is covered by the continuation ledger.',
        'No independent proof of three-family complete matches, all opponents/pairs/maps/seeds or full bootstrap acceptance. No attempt to infer real healing from emitted casts or growth-inclusive HP balances.']}
(OUT / 'natural-pair-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'commonInputSHA256': audit['commonInput']['sha256'], 'frozen497ArchiveExact': True, 'sourceDelta': audit['sourceDelta'], 'runs': {label: {key: row[key] for key in ['result', 'ownEnd', 'enemyEnd', 'provisionalObservations', 'confirmedAfterNonpositive', 'rider']} for label, row in results.items()}}, ensure_ascii=False))
