import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { pathToFileURL } from 'node:url';

const source = '/workspace/sketch-rts-field-screen-retreat-control';
const out = '/workspace/.playtest/bootstrap-field-screen-retreat-independent-review-20261016';
const load = (path: string) => import(pathToFileURL(`${source}/${path}`).href);
const { UNIT_DEFS } = await load('src/shared/catalog.ts');
const { createAiPolicyMemory } = await load('src/ai/memory.ts');
const { mountedMicro, chargeMinimum, THINK_TICKS } = await load('src/ai/bootstrap_1/mounted-micro.ts');
const { groundMoveForecast } = await load('src/shared/route-selection.ts');
const beforeGuard = await import('./mounted-field.guard-before-query.ts');
const afterGuard = await import('./mounted-field.guard-after-query.ts');
const input = `${source}/src/ai/bootstrap_1/fixtures/archer-field-screen-retreat-15285.json.gz`;
const saved = JSON.parse(gunzipSync(readFileSync(input)).toString());

// Synthetic component only: retain snapshot metadata, replace the world with
// bare ground and four ordinary catalog units. Never instantiate or step Game.
function component() {
  const snapshot = structuredClone(saved.snapshot);
  const template = snapshot.units.find((unit: any) => unit.kind === 'horseArcher');
  function unit(kind: string, owner: string, id: string, x: number, y: number, order: object) {
    const rules = UNIT_DEFS[kind];
    return { ...structuredClone(template), kind, owner, id, x, y, homeX: x, homeY: y,
      hp: rules.hp, maxHp: rules.hp, radius: rules.radius, bodyRadius: rules.radius,
      speed: rules.speed, attackRange: rules.attackRange, attackDamage: rules.attackDamage,
      attackCooldown: rules.attackCooldown, cooldown: 0, abilityCooldowns: {},
      aim: undefined, effects: [], order, orderQueue: [], deck: undefined, sailing: undefined,
      pushX: undefined, pushY: undefined, arrivedAt: undefined, expiresTick: undefined,
      kills: 0, xp: 0, level: 0, hands: {}, gearMass: 0 };
  }
  const rider = unit('horseArcher', 'p0', 'rider', 1000, 1000, { type: 'idle' });
  const knight = unit('knight', 'p1', 'knight', 830, 1000, { type: 'attack', targetId: rider.id });
  const archer = unit('archer', 'p1', 'archer', 650, 1000, { type: 'attack', targetId: rider.id });
  const screen = unit('footman', 'p0', 'screen', 2000, 1000, { type: 'hold', x: 2000, y: 1000 });
  const hall = structuredClone(snapshot.buildings.find((building: any) => building.owner === 'p0' && building.kind === 'townHall'));
  Object.assign(hall, { id: 'own-hall', x: 3000, y: 3000, complete: true, hp: hall.maxHp });
  snapshot.map = { ...snapshot.map, width: 4000, height: 4000 };
  delete snapshot.map.terrain;
  snapshot.units = [rider, knight, archer, screen];
  snapshot.buildings = [hall];
  snapshot.obstacles = []; snapshot.items = []; snapshot.resources = [];
  snapshot.effects = []; snapshot.projectiles = []; snapshot.mercenaryCamps = []; snapshot.shops = [];
  snapshot.match = { ...snapshot.match, winner: undefined };
  const memory = createAiPolicyMemory();
  memory.v6 = { general: { mode: 'hold', target: { x: 2200, y: 1000 }, holdingSince: snapshot.tick } };
  const context = { memory, teams: snapshot.teams, version: 'v2', requestedVersion: 'v9' };
  return { snapshot, rider, knight, archer, screen, context, foes: [knight, archer] };
}

const rows = [];
for (const [label, implementation] of [['reconstructed-guard-before-draft', beforeGuard], ['guard-after-current-copy', afterGuard]] as const) {
  const { snapshot, rider, knight, context, foes } = component();
  const before = structuredClone(snapshot);
  const command = mountedMicro(snapshot, rider, knight, foes, { kind: 'field' });
  const road = implementation.mountedFieldRetreatRoad(snapshot, 'p0', rider, foes, context);
  const forecast = road ? groundMoveForecast(snapshot.map, rider, road.points[1], rider.speed, THINK_TICKS) : undefined;
  const minRange = chargeMinimum(knight, rider, THINK_TICKS + rider.cooldown)[0];
  const gap = (point: any) => Math.hypot(point.x - knight.x, point.y - knight.y);
  rows.push({ label, rider: { x: rider.x, y: rider.y, speed: rider.speed, cooldown: rider.cooldown },
    knight: { x: knight.x, y: knight.y, speed: knight.speed, abilityCooldowns: knight.abilityCooldowns, order: knight.order },
    otherPressure: foes[1], originalMicro: command, currentChargeMinimum: minRange,
    originalCommandGapToCurrentKnight: gap(command), road: road ?? null, forecast: forecast ?? null,
    forecastGapToCurrentKnight: forecast ? gap(forecast) : null,
    checks: { originalMicroMove: command.type === 'move', explicitPursuer: knight.order.targetId === rider.id,
      originalCommandStaysInsideMinimum: command.type === 'move' && gap(command) < minRange,
      worldUnchanged: isDeepStrictEqual(snapshot, before),
      ...(label === 'reconstructed-guard-before-draft'
        ? { roadExistsAndCrossesMinimum: !!forecast && gap(forecast) > minRange }
        : { guardedRoadNotEmitted: road === undefined }) } });
}
const result = { classification: 'Pure synthetic component counterexample and guard closure. No Game/native/test/full-planner execution. This proves changed static charge-window admission; it does not prove a charge fired or damage happened.',
  source, base: 'ade412414d9232206f39e20f0182f0086605433c',
  inputMetadataTemplate: { path: input, sha256: createHash('sha256').update(readFileSync(input)).digest('hex') }, rows };
writeFileSync(`${out}/query-charge-window.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(rows.map(({ label, currentChargeMinimum, originalCommandGapToCurrentKnight, forecastGapToCurrentKnight, checks }) => ({ label, currentChargeMinimum, originalCommandGapToCurrentKnight, forecastGapToCurrentKnight, checks }))));
if (rows.some(row => Object.values(row.checks).some(value => value !== true))) process.exitCode = 1;
