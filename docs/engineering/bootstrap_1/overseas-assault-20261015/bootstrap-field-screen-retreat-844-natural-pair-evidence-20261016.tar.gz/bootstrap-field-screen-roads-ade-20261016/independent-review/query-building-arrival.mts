import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

const source = '/workspace/sketch-rts-field-screen-retreat-control';
const out = '/workspace/.playtest/bootstrap-field-screen-retreat-independent-review-20261016';
const input = '/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016/ravager-first-injury-trace.json';
const load = (path: string) => import(pathToFileURL(`${source}/${path}`).href);
const { setBuildingBodies } = await load('src/shared/terrain.ts');
const { groundMoveForecast, routeLeavesDisks } = await load('src/shared/route-selection.ts');
const { createNativeQueryFrame, buildingMoveArrival } = await load('src/shared/sim.ts');
const { mountedField, mountedFieldRetreatRoad } = await load('src/ai/bootstrap_1/mounted-field.ts');
const { armedFoes } = await load('src/ai/bootstrap_1/safe-land-route.ts');
const { threatLandDisks, threatRoadCommands } = await load('src/ai/bootstrap_1/threat-roads.ts');
const { bootstrapPolicyContext } = await load('src/ai/bootstrap_1/policy.ts');
const raw = JSON.parse(readFileSync(input, 'utf8'));
const frame = structuredClone(raw.traceThinks.find((row: any) => row.snapshot.tick === 1788));
const snapshot = frame.snapshot, riderId = 'unit-us-horseArcher-1003';
setBuildingBodies(snapshot.map, [...snapshot.buildings, ...snapshot.obstacles ?? []]);
const rider = snapshot.units.find((unit: any) => unit.id === riderId);
const worldBefore = structuredClone(snapshot);
const context = bootstrapPolicyContext(snapshot, 'us', 'v9_archer', { memory: frame.memory, teams: snapshot.teams, policyMode: 'combat' });
// This is the single script component, not the complete planner. It sets the
// existing per-frame allocation cache so the other field rider is not a screen.
const componentCommands = mountedField.run(snapshot, 'us', context)
  .filter((command: any) => command.unitIds?.includes(riderId));
const traceCommands = raw.traceFrames.find((row: any) => row.tick === 1788).entries
  .filter((entry: any) => entry.scriptId === 'mountedField' && entry.command.unitIds?.includes(riderId))
  .map((entry: any) => entry.command);
const foes = armedFoes(snapshot, 'us', context);
const road = mountedFieldRetreatRoad(snapshot, 'us', rider, foes, context);
if (!road) throw new Error('The observed 1788 road no longer admits under fixed source');
const goal = road.points[1], forecast = groundMoveForecast(snapshot.map, rider, goal, rider.speed, 15);
const readonlyFrame = createNativeQueryFrame(snapshot);
const arrival = buildingMoveArrival(readonlyFrame, rider, goal, 15);
const disks = threatLandDisks(snapshot, rider, foes);
const gap = (a: any, b: any) => Math.hypot(a.x - b.x, a.y - b.y);
const margins = (point: any) => disks.map((disk: any, index: number) => ({ id: foes[index].id,
  radius: disk.radius, margin: gap(point, disk) - disk.radius })).sort((a: any, b: any) => a.margin - b.margin);
const observations = [1788, 1797, 1798, 1803, 1818, 1833, 1834].map(tick => {
  const row = raw.traceSteps.find((row: any) => row.tick === tick);
  const unit = row.units.find((unit: any) => unit.id === riderId);
  const realFoes = row.units.filter((unit: any) => unit.owner === 'foe');
  return { tick, point: { x: unit.x, y: unit.y }, hp: unit.hp, order: unit.order, cooldown: unit.cooldown,
    minimumMarginAgainstOriginal1788PressureDisks: margins(unit)[0],
    minimumCurrentPhysicalMargin: Math.min(...realFoes.map((foe: any) => gap(unit, foe) - (foe.attackRange + foe.radius + unit.radius))) };
});
const actual1797 = observations.find(row => row.tick === 1797)!;
const result = { classification: 'Pure source queries over already recorded passive trace; no Game instance, native step, test runner, or full planner. All observed live positions/orders/damage come from existing trace. buildingMoveArrival is a static geometry query, not future gameplay.',
  source, fixedHead: '3331e8d2db8d8a61a7d5685ad70a25dc4ee0baa7', input,
  inputSHA256: createHash('sha256').update(readFileSync(input)).digest('hex'),
  road, componentCommands, traceCommands, forecast, staticArrival: arrival ?? null,
  forecastMargins: margins(forecast), arrivalMargins: arrival ? margins(arrival.point) : null,
  forecastLeavesOriginalDisks: routeLeavesDisks([rider, forecast], disks),
  arrivalLeavesOriginalDisks: arrival ? routeLeavesDisks([rider, arrival.point], disks) : null,
  observations, recordedFirstDamage: raw.firstDamage,
  checks: { commandsMatchObserved1788: isDeepStrictEqual(componentCommands, traceCommands),
    emittedRoadMatchesObserved: isDeepStrictEqual(threatRoadCommands(rider, road), traceCommands),
    staticArrivalMatchesObserved1797: !!arrival && isDeepStrictEqual(arrival.point, actual1797.point),
    staticArrivalMovementTick9: arrival?.movementTick === 9,
    worldUnchanged: isDeepStrictEqual(snapshot, worldBefore) },
  conclusion: 'Early building arrival changes predicted pose and native order lifetime, but the actual early stop still leaves every original 1788 pressure disk. Replacing this forecast with buildingMoveArrival alone does not reject this exact road under the same admission condition. First injury at1834 follows several later think/native decisions; no unique cause is established by this one frame.' };
writeFileSync(`${out}/query-building-arrival.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ forecast, arrival, minimumForecastMargin: result.forecastMargins[0], minimumArrivalMargin: result.arrivalMargins?.[0],
  forecastLeavesOriginalDisks: result.forecastLeavesOriginalDisks, arrivalLeavesOriginalDisks: result.arrivalLeavesOriginalDisks, checks: result.checks }));
if (Object.values(result.checks).some(value => value !== true)) process.exitCode = 1;
