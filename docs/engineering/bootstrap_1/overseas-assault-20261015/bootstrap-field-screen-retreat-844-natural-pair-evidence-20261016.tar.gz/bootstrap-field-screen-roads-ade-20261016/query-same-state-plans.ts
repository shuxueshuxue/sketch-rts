import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import{isDeepStrictEqual}from'node:util';
const dir='/workspace/.playtest/bootstrap-field-screen-roads-ade-20261016',paths={ade:'/workspace/sketch-rts-mounted-aim-ade-baseline-control',v3:'/workspace/sketch-rts-field-screen-retreat-v3-control'},copy=(v:any)=>JSON.parse(JSON.stringify(v)),uid='unit-p0-horseArcher-4294';
const results=[];for(const origin of['base','v3'])for(const tick of[15285,15345,15645,15705,15840]){
 const prefix=origin==='base'?'/workspace/.playtest/bootstrap-mounted-cooldown-20261016/base15255-15855':dir+'/v3-actual15255-15855';
 const input=prefix+'.prethink/'+tick+'.json.gz',saved=JSON.parse(gunzipSync(readFileSync(input)).toString()),rows:any={};
 for(const[label,source]of Object.entries(paths)){
  const snapshot=copy(saved.snapshot),pre=copy(snapshot),provider=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href),terrain=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
  terrain.setBuildingBodies(snapshot.map,[...snapshot.buildings,...snapshot.obstacles??[]]);
  const memories=provider.createAiMemoryProvider(copy(saved.memories)),entries=provider.planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',source:'external-agent'},{teams:snapshot.teams,memoryProvider:memories});
  rows[label]={entries,afterMemory:copy(memories.get('p0')),worldUnchanged:isDeepStrictEqual(copy(snapshot),pre)};
 }
 const strip=(es:any[])=>es.filter(e=>!e.command.unitIds?.includes(uid));
 results.push({origin,tick,input,nonRiderEntriesEqual:isDeepStrictEqual(strip(rows.ade.entries),strip(rows.v3.entries)),afterMemoryEqual:isDeepStrictEqual(rows.ade.afterMemory,rows.v3.afterMemory),rows});
}
writeFileSync(dir+'/same-state-plans.json',JSON.stringify({classification:'Full P0 planner only, no native steps. Identical complete saved world and all3memory supplied independently to immutable ade and844v3. Raw map bodies registered first. No opponent plans or commands applied. Same-state equality limits source intent, not later-world global causality.',results},null,2)+'\n');console.log(results.map(({origin,tick,nonRiderEntriesEqual,afterMemoryEqual,rows})=>({origin,tick,nonRiderEntriesEqual,afterMemoryEqual,worldUnchanged:rows.ade.worldUnchanged&&rows.v3.worldUnchanged})));
