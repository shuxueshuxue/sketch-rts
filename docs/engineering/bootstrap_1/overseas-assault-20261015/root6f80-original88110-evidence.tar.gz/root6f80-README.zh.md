# 6f80a936 整合版：原88110完整双方AI至自然胜

干净隔离工作树/tmp/sketch-rts-root6f80-combined-control，精确提交6f80a9365e591cbfba9148260806cd4f9033788e。严格先--no-checkout建立，再sparse排除无关历史docs/art包后checkout；status为空。未改任何源/主分支/旧控制，未开重复比赛。865件源码capsule与冻结manifest184件验证通过；实际src/shared/rules-version.ts常量2；源前后及终后当前逐文件SHA均通过。

原始未受手工操作的88110 full snapshot、nextId、双方完整memory全部恢复一致，显式使用原29船员identity/originDeck。实际主线为v9_archer Grove p0对正常冻结v5 Ember p1，官方sapphireArchipelago，bootstrap_1-development seed，think15。此为旧真实比赛在88110换为整合版源码的双方AI续跑，不是true0普通开局、新seed或最终bootstrap验收；原容器未提交修改缺口仍未恢复。

完整双方AI自动运行至91820自然判p0胜，最后敌楼shipyard1016摧毁，敌楼与厅均0。原29人均于90031同tick实际上岸；终24人在敌岛、0deck、0其他陆地、5死（4archer+1lancer）。我方最终60单位、28楼、4厅均完整900HP；敌方仍4sparkArcher，没有建筑或厅。敌余军1035/1179/2866/4000在约(4910..4961,8769..8801)处idle，不能声称消灭了全部敌单位。原29生存/死亡完整ID与位置、HP及敌余军详列result.json，所有fullframes与命中/指令记录保留。

整局unitsLost我25/敌50/neutral4；仅此续跑段我5/敌25。原船队5死不是整局只损5。全部原始match.stats及单位/建筑细分在result.json。

与隔离183b-v7的既有同输入续跑相比：本6f80终world、nextId、双方完整memories、全部公开指令、逐tick原29人分组都严格全等；因此这是整合无回归验证，不声称courier/25cce在本接续窗口产生新收益，也不把两次当独立泛化胜局。6f80的源码和证据独立归属。原生客户端源来自同一精确6f80控制，90031登陆图与91820终图已人工查看；visual-source.json记录渲染器/输入/图片哈希。

此次未修改代码，没有新增权限阻塞。下一步仍需整合固定源码普通0开局、另外两路线与单/双敌及官方/未见种子完整比赛证据；本局只闭合父任务要求的原88110整合验证。
