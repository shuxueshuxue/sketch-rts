from pathlib import Path
import json,hashlib,tarfile,io
p=Path('/tmp/bootstrap-deployment-gate');w=Path('/tmp/sketch-rts-root6f80-combined-control')
visual={'commit':'6f80a9365e591cbfba9148260806cd4f9033788e','sourceFiles':{n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in ['src/client/world-renderer.ts','src/client/unit-facing.ts','src/recorder/record.ts']},'driverSha256':hashlib.sha256((p/'root6f80-render.mts').read_bytes()).hexdigest(),'images':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['root6f80-first-land-90031.png','root6f80-won-91820.png']},'inputs':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['root6f80-original88110.frames/first-target-ground-90031.json','root6f80-original88110.frames/terminal-91820.json']}}
(p/'root6f80-visual-source.json').write_text(json.dumps(visual,indent=2)+'\n')
names=['root6f80-README.zh.md','root6f80-combined-source.json','root6f80-combined-source.tar.gz','root6f80-combined-source.patch','root6f80-original88110.json','root6f80-original88110.log','root6f80-original88110-result.json','root6f80-original88110-source-postflight.json','root6f80-first-land-90031.png','root6f80-won-91820.png','root6f80-visual-source.json','root6f80-render.mts','complete-run.mts','source-capture.py','deployment-beach-v6-input88110.json','deployment-beach-v6-original-crew.json','seal-root6f80.py']
files={n:p/n for n in names}
for f in (p/'root6f80-original88110.frames').glob('*.json'):files[str(f.relative_to(p))]=f
index={'classification':'Clean exact6f80 combined-source normal full both-AI continuation of original unmanipulated88110; natural p0 win91820; not true0 or final acceptance','files':{n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}}
arc=p/'root6f80-original88110-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n)
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('INDEX.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(arc,'r:gz') as t:
 assert len(t.getmembers())==len(files)+1
 for n,h in index['files'].items():
  data=t.extractfile(n).read();assert len(data)==h['bytes'] and hashlib.sha256(data).hexdigest()==h['sha256'],n
result={'archive':str(arc),'bytes':arc.stat().st_size,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'payloadFiles':len(files),'fullFrames':len(list((p/'root6f80-original88110.frames').glob('*.json'))),'verified':True};(p/'root6f80-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
