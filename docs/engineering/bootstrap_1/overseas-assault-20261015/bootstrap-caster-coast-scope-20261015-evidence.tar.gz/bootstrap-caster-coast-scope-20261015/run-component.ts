import { writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const source=process.argv[2]!,out=process.argv[3]!;
const imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const [{sketchScene},{setBuildingBodies},{snapshotGame,issuePlayerCommand,stepGame},{bootstrapPolicyContext},{createAiPolicyMemory},{planLandedCombat},{strikeGap},{canReach}]=await Promise.all([imp('src/sdk/scene.ts'),imp('src/shared/terrain.ts'),imp('src/shared/sim.ts'),imp('src/ai/bootstrap_1/policy.ts'),imp('src/ai/memory.ts'),imp('src/ai/bootstrap_1/landed-combat.ts'),imp('src/shared/combat-geometry.ts'),imp('src/shared/naval.ts')]);
function coast() {
  const game = sketchScene('counterfactual-landed-caster-coast').map('bareDuel').replaceDefaults()
    .player('us', { race: 'grove', team: 'a' }).player('foe', { race: 'ember', team: 'b' })
    .townHall('us', 500, 500).townHall('foe', 3300, 1500)
    .unit('us', 'summoner', 2250, 1700, { id: 'caster' })
    .unit('us', 'footman', 2600, 1660, { id: 'screen-1' })
    .unit('us', 'footman', 2600, 1700, { id: 'screen-2' })
    .unit('us', 'footman', 2600, 1740, { id: 'screen-3' })
    .unit('foe', 'footman', 2900, 1700, { id: 'land-foe' })
    .unit('foe', 'warship', 2400, 1950, { id: 'coastal-shooter' }).build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) =>
    index % 128 < 25 || index % 128 >= 65 && Math.floor(index / 128) < 60 ? '.' : '~').join('') };
  setBuildingBodies(game.map, game.buildings);
  return game;
}

const game=coast();
for(const owner of ['us','foe'])issuePlayerCommand(game,owner,{type:'holdPosition',unitIds:game.units.filter((u:any)=>u.owner===owner).map((u:any)=>u.id)});
const initialNextId=game.nextId,snapshot=snapshotGame(game),context=bootstrapPolicyContext(snapshot,'us','v9_summoner',{memory:createAiPolicyMemory(),teams:game.teams}),caster=snapshot.units.find((u:any)=>u.id==='caster')!,shooter=snapshot.units.find((u:any)=>u.id==='coastal-shooter')!;
const commands=planLandedCombat(snapshot,'us',context,new Set());
const hits:any[]=[];game.observer={hit(a:any,t:any,damage:number,hpBefore:number){hits.push({tick:game.tick,attacker:a.id,target:t.id,damage,hpBefore,hpAfter:t.hp});}};
issuePlayerCommand(game,'foe',{type:'attack',unitIds:['coastal-shooter'],targetId:'caster'});
for(const command of commands)issuePlayerCommand(game,'us',command);
const samples:any[]=[];for(let tick=0;tick<240;tick++){stepGame(game);if(game.tick%15===0){const u=game.units.find((u:any)=>u.id==='caster');samples.push({tick:game.tick,caster:u?{x:u.x,y:u.y,hp:u.hp,order:u.order}:null});}}
const result={classification:'Counterfactual component scene, not historical army or causal result. Exact same scene constructor as regression; one initial native landed query, ordinary public commands,240 native ticks without further AI.',source,initial:{snapshot,nextId:initialNextId,strikeGap:strikeGap(shooter,caster),range:shooter.attackRange,canReach:canReach(snapshot.map,shooter,caster,snapshot.units,shooter.attackRange)},commands,hits,samples,final:{snapshot:snapshotGame(game),nextId:game.nextId}};
writeFileSync(out,JSON.stringify(result));console.log(JSON.stringify({source,commands,caster:game.units.find((u:any)=>u.id==='caster'),hits:hits.filter(h=>h.target==='caster')}));
