import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const source = process.argv[2]!, output = process.argv[3]!;
const directory = '/tmp/bootstrap-caster-coast-scope-20261015';
const imp = (p: string) => import(pathToFileURL(source + '/' + p).href);
const [{ bootstrapPolicyContext }, { planAiOwnerCommandEntries }, { hostileCombatThreats },
  { sameGround }, { unitMover }, { isBacklineKind }, { canReach }, { strikeGap }] = await Promise.all([
  imp('src/ai/bootstrap_1/policy.ts'), imp('src/ai/planner-context.ts'), imp('src/ai/bootstrap_1/combat-threats.ts'),
  imp('src/shared/terrain.ts'), imp('src/shared/catalog.ts'), imp('src/ai/policy/v6/backline.ts'),
  imp('src/shared/naval.ts'), imp('src/shared/combat-geometry.ts'),
]);
const hash = (v: any) => createHash('sha256').update(JSON.stringify(v)).digest('hex');
const cases = JSON.parse(readFileSync(directory + '/inputs.json', 'utf8'));
const results = [];
for (const test of cases) {
  const saved = JSON.parse(gunzipSync(readFileSync(test.path)).toString()), snapshot = saved.snapshot;
  const before = hash(saved), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_summoner', {
    memory: structuredClone(saved.memories.p0), teams: snapshot.teams,
  });
  const home = snapshot.buildings.find((b: any) => b.owner === 'p0' && b.kind === 'townHall');
  const landed = snapshot.units.filter((u: any) => u.owner === 'p0' && !u.deck && unitMover(u.kind) === 'land'
    && u.kind !== 'worker' && home && !sameGround(snapshot.map, u, home));
  const foes = hostileCombatThreats(snapshot, 'p0', options);
  const casters = landed.filter(isBacklineKind).map((caster: any) => ({
    id: caster.id, kind: caster.kind, x: caster.x, y: caster.y, hp: caster.hp,
    order: caster.order, orderQueue: caster.orderQueue,
    nearby: foes.filter((foe: any) => Math.hypot(foe.x - caster.x, foe.y - caster.y) <= 900).map((foe: any) => ({
      id: foe.id, kind: foe.kind, x: foe.x, y: foe.y, hp: foe.hp, deck: foe.deck,
      attackRange: foe.attackRange, sameGround: sameGround(snapshot.map, caster, foe),
      distance: Math.hypot(foe.x - caster.x, foe.y - caster.y), strikeGap: strikeGap(foe, caster),
      canReach: canReach(snapshot.map, foe, caster, snapshot.units, foe.attackRange), order: foe.order,
    })),
  }));
  const entries = planAiOwnerCommandEntries(snapshot, { playerId: 'p0', version: 'v9_summoner',
    memory: structuredClone(saved.memories.p0) }, { teams: snapshot.teams });
  const allEntries = JSON.parse(JSON.stringify(entries));
  const landedIds = new Set(landed.map((u: any) => u.id));
  const relevant = entries.filter(({ command }: any) => 'unitIds' in command && command.unitIds.some((id: string) => landedIds.has(id)));
  results.push({ label: test.label, inputSHA256: test.sha256, tick: snapshot.tick, nextId: saved.nextId,
    memoryHashes: Object.fromEntries(Object.entries(saved.memories).map(([o, v]) => [o, hash(v)])),
    landed: landed.map((u: any) => ({ id: u.id, kind: u.kind, hp: u.hp, order: u.order })),
    activeWorkers: foes.filter((u: any) => u.kind === 'worker').map((u: any) => ({ id: u.id, order: u.order })),
    casters, allEntries, relevant, completeInputUnchanged: hash(saved) === before,
  });
}
writeFileSync(output, JSON.stringify({ classification: 'Pure full-planner queries of unchanged real complete inputs; no command issue or simulation.', source, results }, null, 2));
console.log(JSON.stringify(results.map(r => ({ label: r.label, tick: r.tick, landed: r.landed.length,
  casterCount: r.casters.length, offGroundThreats: r.casters.reduce((n: number, c: any) => n + c.nearby.filter((f: any) => !f.sameGround).length, 0),
  inputUnchanged: r.completeInputUnchanged, relevant: r.relevant }))));
