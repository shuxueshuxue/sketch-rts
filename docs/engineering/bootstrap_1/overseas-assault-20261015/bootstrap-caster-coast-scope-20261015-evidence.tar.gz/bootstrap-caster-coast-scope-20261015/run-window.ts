import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync } from 'node:zlib';

const directory = '/tmp/bootstrap-caster-coast-scope-20261015';
const source = '/tmp/sketch-rts-active-worker-screen-scope-control';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const prefix = '/tmp/bootstrap-root-3bdb-ordinary0-20261015/ordinary';
const report = JSON.parse(readFileSync(prefix + '.json', 'utf8'));
const from = 12000, end = Number(process.argv[2] ?? 13200);
const output = directory + `/native-${from}-${end}`;
const json = (value: any) => JSON.parse(JSON.stringify(value));
const hash = (value: any) => createHash('sha256').update(value).digest('hex');
function verify() {
  const changes = Object.entries(cap.hashes).filter(([path, sha]) => hash(readFileSync(source + '/' + path)) !== sha).map(([path]) => path);
  const head = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', source, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Frozen candidate changed');
  return { files: Object.keys(cap.hashes).length, changes, head, status };
}
const preflight = verify();
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { runAiGameLoop }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts'),
]);
const match = bootstrapMatches(report.setup.seed, [report.setup.map], end, report.setup.unseen).find((match: any) =>
  match.subject === report.subject && match.side === report.setup.side && match.agents.p0.race === report.setup.agents.p0.race
  && Object.values(match.agents).slice(1).map((a: any) => a.version).join('+') === 'v8');
if (!match) throw Error('Original match absent');
const input = JSON.parse(readFileSync(prefix + `.json.frames/${from}.json`, 'utf8'));
const row = report.rows.find((row: any) => row.tick === from);
const expectedRow = report.rows.find((row: any) => row.tick === end);
const memories = createAiMemoryProvider(), game = bootstrapGame(match);
restoreSnapshotIntoGame(game, input.snapshot, input.nextId);
for (const [owner, player] of Object.entries(row.players) as any[]) memories.set(owner, structuredClone(player.policy));
const full = () => json({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner)])) });
const restored = full();
const restore = { world: isDeepStrictEqual(restored.snapshot, input.snapshot), nextId: restored.nextId === input.nextId,
  allMemories: isDeepStrictEqual(restored.memories, json(Object.fromEntries(Object.entries(row.players).map(([o, p]: any) => [o, p.policy])))) };
if (Object.values(restore).some(value => !value)) throw Error('Original full input differs');
mkdirSync(output + '.frames', { recursive: true });
const commands: any[] = [], hits: any[] = [], samples: any[] = [], preplannerInputs: any[] = [];
const capture = () => { const state = full(); writeFileSync(output + `.frames/${game.tick}.json.gz`, gzipSync(JSON.stringify(state)));
  samples.push({ tick: game.tick, loss: game.match.stats, units: game.units.filter((u: any) => u.owner === 'p0').length }); };
capture();
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  hits.push(json({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, target: target.id,
    targetOwner: target.owner, damage, hpBefore, hpAfter: target.hp, deck: target.deck }));
} };
const planner = await createBootstrapCommandPlanner(memories);
runAiGameLoop({ ...match, game, commandPlanner: (context: any) => {
  if (context.owner === 'p0' && [12390,12570].includes(context.snapshot.tick)) {
    const path = directory + `/inputs/corrected-before${game.tick}.json.gz`;
    const value = full(); writeFileSync(path, gzipSync(JSON.stringify(value)));
    preplannerInputs.push({tick:game.tick,path,sha256:hash(readFileSync(path))});
  }
  return planner(context);
} }, {
  onCommand(event: any) { commands.push(json({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command })); },
  onStep() { if (game.tick % 600 === 0 || game.match.winner) { capture(); console.log(JSON.stringify({ tick: game.tick, winner: game.match.winner })); } },
});
if (samples.at(-1).tick !== game.tick) capture();
const final = full();
const comparison = expectedRow ? (() => { const expected = JSON.parse(readFileSync(prefix + `.json.frames/${end}.json`, 'utf8'));
  return { world: isDeepStrictEqual(final.snapshot, expected.snapshot), nextId: final.nextId === expected.nextId,
    allMemories: isDeepStrictEqual(final.memories, json(Object.fromEntries(Object.entries(expectedRow.players).map(([o, p]: any) => [o, p.policy])))) }; })() : undefined;
const old = JSON.parse(readFileSync('/tmp/bootstrap-active-worker-threat-20261015/native-12000-13200.json', 'utf8'));
const oldFinal = JSON.parse((await import('node:zlib')).gunzipSync(readFileSync('/tmp/bootstrap-active-worker-threat-20261015/native-12000-13200-final.json.gz')).toString());
const comparisonTo37ae = {world:isDeepStrictEqual(final.snapshot,oldFinal.snapshot),nextId:final.nextId===oldFinal.nextId,allMemories:isDeepStrictEqual(final.memories,oldFinal.memories),allCommands:isDeepStrictEqual(commands,old.commands),allHits:isDeepStrictEqual(hits,old.hits)};
const result = { classification: 'Changed-code candidate continuation of original true0 root3bdb full12000, both AI/frozen opponent normal. Not ordinary0 or production score.',
  from, end: game.tick, source, commit: cap.head, restore, comparison, comparisonTo37ae, preplannerInputs, preflight, postflight: verify(),
  commands, hits, samples, result: { winner: game.match.winner, stats: game.match.stats } };
writeFileSync(output + '.json', JSON.stringify(result));
writeFileSync(output + '-final.json.gz', gzipSync(JSON.stringify(final)));
console.log(JSON.stringify({ from, end: game.tick, restore, comparison, result: result.result, comparisonTo37ae, preplannerInputs, hits: hits.length, commands: commands.length }));
