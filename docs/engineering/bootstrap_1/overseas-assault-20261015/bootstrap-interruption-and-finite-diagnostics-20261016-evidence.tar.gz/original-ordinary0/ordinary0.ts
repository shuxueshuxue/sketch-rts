import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync } from 'node:zlib';
import { NativeLedger } from './observer-ledger';

const directory = '/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8')), source = cap.sourceRoot;
const declaration = JSON.parse(readFileSync(directory + '/seed-predeclaration.json', 'utf8'));
const opening = JSON.parse(readFileSync(directory + '/ordinary-opening.json', 'utf8'));
const output = directory + '/ordinary0';
const atomic = (path: string, value: any) => { writeFileSync(path + '.tmp', value); renameSync(path + '.tmp', path); };
const json = (value: any) => JSON.parse(JSON.stringify(value));
const sha = (value: any) => createHash('sha256').update(value).digest('hex');
function verify() {
  const changes = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(source + '/' + path)) !== hash).map(([path]) => path);
  const head = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', source, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Fixed source changed');
  return { files: Object.keys(cap.hashes).length, changes, head, status };
}
const preflight = verify(), startedAtUtc = new Date().toISOString();
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runAiGameLoop }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts')]);
const match = bootstrapMatches(declaration.seed, [declaration.factory], Number.MAX_SAFE_INTEGER, true).find((m: any) =>
  m.subject === 'v9_summoner' && m.side === 1 && m.agents.p0.race === 'ember'
  && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v5+v7');
if (!match || !isDeepStrictEqual(match.agents, opening.match.agents)) throw Error('Exact predeclared match missing');
const game = bootstrapGame(match), memories = createAiMemoryProvider(), owners = Object.keys(match.agents);
const full = () => json({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null])) });
const initial = full();
const openingComparison = { world: isDeepStrictEqual(initial.snapshot, opening.snapshot), nextId: initial.nextId === opening.nextId,
  allMemories: isDeepStrictEqual(initial.memories, opening.memories) };
if (Object.values(openingComparison).some(v => !v) || game.tick !== 0 || initial.nextId !== 1000
  || Object.values(initial.memories).some(m => m !== null) || owners.some(owner => {
    const p = game.players[owner], own = game.units.filter((u: any) => u.owner === owner);
    return p.gold !== 500 || p.supplyUsed !== 3 || p.supplyCap !== 8 || own.length !== 3 || own.some((u: any) => u.kind !== 'worker');
  })) throw Error('Fresh ordinary0 opening differs');
const frozenRoot = frozenPolicyRoot();
function frozenCheck() {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([path, hash]) => sha(readFileSync(frozenRoot + '/' + path)) !== hash);
  if (changed.length || frozenPolicyManifest.rulesVersion !== 2 || Object.keys(frozenPolicyManifest.files).length !== 184) throw Error('Actual historical tree changed');
  return { files: 184, changed: [], revision: frozenPolicyManifest.revision };
}
const frozenPre = frozenCheck();
const planner = await createBootstrapCommandPlanner(memories);
if (!Object.values(full().memories).every(m => m === null)) throw Error('Memory initialized before first think');
if (existsSync(output + '-progress.json')) throw Error('Never overwrite an existing actual run');
mkdirSync(output + '.frames', { recursive: true });
for (const suffix of ['-public-commands.jsonl', '-native-hits.jsonl', '-native-events.jsonl']) writeFileSync(output + suffix, '');
atomic(directory + '/in-process-opening.json', JSON.stringify(initial));
const classification = 'Predeclared single new holdout ordinary tick0 on fixed production0f5bf: v9_summoner vs normal historicalv5+v7 same-team enemies, approved generator/seats, rules2. No restore, manual command, seeded memory or changed-code continuation. One seed only; once observed it becomes a development case.';
const samples: any[] = [], commands: any[] = [], hits: any[] = [], events: any[] = [], lastHit = new Map<string, any>();
const ledger = new NativeLedger(game.units, game.buildings);
let currentCommandIndex: number | undefined, observationStopped = false;
function sample() {
  const summary = { tick: game.tick, winner: game.match.winner, commands: commands.length, hits: hits.length,
    terminalObservations: events.filter(e => e.type === 'native-unit-terminal').length,
    births: events.filter(e => e.type === 'unit-birth-observed').length,
    mineAmountTotal: game.resources.reduce((sum: number, r: any) => sum + r.amount, 0), stats: json(game.match.stats),
    owners: Object.fromEntries(owners.map(owner => [owner, { gold: game.players[owner].gold,
      supply: game.players[owner].supplyUsed, cap: game.players[owner].supplyCap,
      units: game.units.filter((u: any) => u.owner === owner && u.hp > 0).length,
      buildings: game.buildings.filter((b: any) => b.owner === owner && b.hp > 0).length,
      halls: game.buildings.filter((b: any) => b.owner === owner && b.hp > 0 && b.kind === 'townHall').map((b: any) => ({ id: b.id, x: b.x, y: b.y, hp: b.hp, complete: b.complete })) }])) };
  samples.push(summary); return summary;
}
function progress(completed = false) {
  atomic(output + '-progress.json', JSON.stringify({ classification, commit: cap.head, startedAtUtc, pid: process.pid,
    setup: match, tick: game.tick, winner: game.match.winner, completed, observationStopped, samples }));
}
function capture(reason = 'periodic-before-next-think') {
  atomic(output + `.frames/${game.tick}.json.gz`, gzipSync(JSON.stringify({ ...full(), checkpointStage: reason })));
  const summary = sample(); progress(); console.log(JSON.stringify(summary));
}
function observe(stage: string) {
  const observed = ledger.observe(game.tick, stage, game.units, game.buildings, lastHit);
  for (const event of observed) {
    const entry = { ...event, commandIndex: currentCommandIndex }; events.push(entry);
    appendFileSync(output + '-native-events.jsonl', JSON.stringify(entry) + '\n');
  }
  const significant = observed.some(e => (e.type === 'native-unit-terminal' && e.permanent)
    || e.type === 'native-building-terminal' || (e.type === 'observed-disembark' && e.after.expiresTick === undefined));
  if (significant) atomic(output + `.frames/${game.tick}-${stage}-${currentCommandIndex ?? 'native'}.json.gz`, gzipSync(JSON.stringify({ ...full(),
    checkpointStage: stage, commandIndex: currentCommandIndex,
    restoreCaution: stage === 'after-command' ? 'Mid-think command-boundary observation; may include hp<=0 pending native cleanup. Do not assume ordinary before-think restart without explicit audit.' : 'Post-step event can contain native derived-load states; restore must be checked before reuse.' })));
}
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  const hit = json({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind,
    target: target.id, targetOwner: target.owner, targetKind: target.kind, damage, hpBefore, hpAfter: target.hp, deck: target.deck });
  hits.push(hit); lastHit.set(target.id, hit); appendFileSync(output + '-native-hits.jsonl', JSON.stringify(hit) + '\n');
} };
atomic(directory + '/actual-launch.json', JSON.stringify({ startedAtUtc, pid: process.pid, cwd: process.cwd(), argv: process.argv,
  driverSHA256: sha(readFileSync(new URL('./ordinary0.ts', import.meta.url))), observerSHA256: sha(readFileSync(new URL('./observer-ledger.ts', import.meta.url))),
  sourcePre: preflight, frozenPre, openingComparison, maxTicks: Number.MAX_SAFE_INTEGER,
  protocol: 'Natural result;144000 is only a checkpoint. An external observation-stop.json requires explicit parent instruction supported by real stagnation evidence; it stops observation without issuing gameplay commands and is not a natural match result.' }, null, 2));
capture('fresh0-before-first-think');
class ObservationStop extends Error {}
let runResult: any;
try {
  runResult = runAiGameLoop({ ...match, game, commandPlanner: planner }, {
    onCommand(event: any) {
      currentCommandIndex = commands.length;
      const entry = json({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command });
      commands.push(entry); appendFileSync(output + '-public-commands.jsonl', JSON.stringify(entry) + '\n');
      observe('after-command'); currentCommandIndex = undefined;
    },
    beforeStep() { observe('before-step'); ledger.beforeStep(game.units); },
    onStep() {
      observe('after-step');
      if (game.tick % 600 === 0 || game.match.winner) capture();
      if (existsSync(directory + '/observation-stop.json')) {
        const stop = JSON.parse(readFileSync(directory + '/observation-stop.json', 'utf8'));
        if (stop.authorizedByParent === true && stop.reason && stop.evidence) { observationStopped = true; throw new ObservationStop(stop.reason); }
      }
    },
  });
} catch (error) { if (!(error instanceof ObservationStop)) throw error; }
if (samples.at(-1).tick !== game.tick) capture(observationStopped ? 'explicit-observation-stop' : 'natural-terminal');
const final = full(), postflight = verify(), frozenPost = frozenCheck();
atomic(output + '-final.json.gz', gzipSync(JSON.stringify(final)));
atomic(output + '.json', JSON.stringify({ classification, commit: cap.head, source, startedAtUtc, endedAtUtc: new Date().toISOString(),
  pid: process.pid, setup: match, openingComparison, initial, preflight, postflight, frozenPre, frozenPost,
  runResult: runResult ? { elapsedMs: runResult.elapsedMs, cpuMs: runResult.cpuMs } : null,
  result: { tick: game.tick, winner: game.match.winner, naturalComplete: !!game.match.winner, observationStopped, stats: game.match.stats },
  commands, hits, events, samples }));
progress(true); console.log(JSON.stringify({ completed: true, tick: game.tick, winner: game.match.winner, observationStopped, postflight, frozenPost }));
