from pathlib import Path
import os,stat,json,hashlib,shutil,datetime
roots=[Path('/tmp/bootstrap-transit-v12-evidence'),Path('/tmp/bootstrap-land-army-evidence-20261015')]
destination=Path('/workspace/.playtest/relocated-tmp-evidence')
record=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/root-20261016-tmp-evidence-relocation.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def inventory(root):
 rows={}
 def walk(p,rel):
  s=p.lstat();r={'mode':oct(stat.S_IMODE(s.st_mode)),'mtimeNs':s.st_mtime_ns}
  if stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p),bytes=s.st_size)
  elif stat.S_ISREG(s.st_mode):r.update(type='file',bytes=s.st_size,sha256=digest(p))
  elif stat.S_ISDIR(s.st_mode):
   r.update(type='directory');rows[rel]=r
   for c in sorted(p.iterdir(),key=lambda x:x.name):walk(c,c.name if rel=='.'else rel+'/'+c.name)
   return
  else:raise RuntimeError('Unsupported nonregular payload '+str(p))
  rows[rel]=r
 walk(root,'.');return rows
result={'classification':'Reversible preservation-only relocation of explicitlyclosed evidence; no gameplay/source/result change. Copy+hashverify stage only until process-reference uncertainty is resolved.','startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processAudit':'root-20261016-tmp-evidence-process-audit.json','uncertainty':'No native/game process live; inaccessible basicdaemon/wrapper /proc cwd/fd cannot be certified. Originals stay untouched until parent lifecycle scope determination.','records':[]}
destination.mkdir(parents=True,exist_ok=True)
for source in roots:
 assert source.is_dir()and not source.is_symlink();target=destination/source.name;assert not target.exists()and not target.is_symlink()
 before=inventory(source);total=sum(r.get('bytes',0)for r in before.values()if r['type']=='file');assert shutil.disk_usage(destination).free>total+128*1024*1024
 item={'source':str(source),'target':str(target),'before':before,'regularBytes':total,'payloadCount':len(before),'copyStartedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'switchDone':False,'originalRemoved':False};result['records'].append(item);record.write_text(json.dumps(result,indent=2))
 shutil.copytree(source,target,symlinks=True,copy_function=shutil.copy2)
 copied=inventory(target);after=inventory(source);assert before==copied,'copy payloadmetadata/hash mismatch';assert before==after,'source changed while copying'
 item.update(copyEndedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),allCopiedPayloadSHABytesModeSymlinkAndMtimeVerified=True,sourceUnchangedDuringCopy=True,inventorySHA256=sha(json.dumps(before,sort_keys=True,separators=(',',':')).encode()))
 record.write_text(json.dumps(result,indent=2));print(json.dumps({'copied':str(source),'to':str(target),'payloadCount':len(before),'regularBytes':total,'allMetadataHashesVerified':True}),flush=True)
result['copyPhaseCompleteAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['originalsUnchanged']=True;record.write_text(json.dumps(result,indent=2));print(json.dumps({'copyPhaseComplete':True,'record':str(record),'originalsUnchanged':True}),flush=True)
