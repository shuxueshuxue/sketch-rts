from pathlib import Path
import os,stat,json,hashlib,shutil,datetime
record=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/root-20261016-tmp-evidence-relocation.json');result=json.loads(record.read_text());assert result.get('copyPhaseCompleteAtUtc')and result['originalsUnchanged']
result['authorizationScope']='Parent explicitlyconfirmed closed ownerlifecycle; land_army confirmed noactiveFD/writes; no native/TSX/gameprocess live. Inaccessible basicdaemon procFDs remain a disclosedlimit, not proof of a heldreference. Authorizedswitch after fullcopyverification; no otherdirectories.'
result['uncertainty']='Some basicdaemon/wrapper /proc cwd/fd PermissionDenied remain recorded. Neverclaim allFDs wereproved free. Scope determined by explicit closed-owner lifecycle and no relevant active nativeprocess.'
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def inventory(root):
 rows={}
 def walk(p,rel):
  s=p.lstat();r={'mode':oct(stat.S_IMODE(s.st_mode)),'mtimeNs':s.st_mtime_ns}
  if stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p),bytes=s.st_size)
  elif stat.S_ISREG(s.st_mode):r.update(type='file',bytes=s.st_size,sha256=digest(p))
  elif stat.S_ISDIR(s.st_mode):
   r.update(type='directory');rows[rel]=r
   for c in sorted(p.iterdir(),key=lambda x:x.name):walk(c,c.name if rel=='.'else rel+'/'+c.name)
   return
  else:raise RuntimeError('Unsupported payload '+str(p))
  rows[rel]=r
 walk(root,'.');return rows
record.write_text(json.dumps(result,indent=2))
for item in result['records']:
 source,target=Path(item['source']),Path(item['target']);before=item['before'];backup=source.with_name(source.name+'.verified-relocation-backup-20261016')
 assert str(source)in ['/tmp/bootstrap-transit-v12-evidence','/tmp/bootstrap-land-army-evidence-20261015'];assert source.is_dir()and not source.is_symlink()and target.is_dir()and not target.is_symlink();assert not backup.exists()and not backup.is_symlink();assert inventory(source)==before and inventory(target)==before
 item.update(switchStartedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),temporaryBackup=str(backup));record.write_text(json.dumps(result,indent=2))
 source.rename(backup)
 try:source.symlink_to(target,target_is_directory=True)
 except BaseException:
  backup.rename(source);raise
 assert source.is_symlink()and os.readlink(source)==str(target)and source.resolve()==target.resolve()
 assert inventory(source.resolve())==before and inventory(backup)==before
 item.update(switchDone=True,originalPathLookupFullManifestVerified=True,backupStillAllVerified=True,switchVerifiedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rootSymlinkTarget=os.readlink(source),rootSymlinkMode=oct(stat.S_IMODE(source.lstat().st_mode)));record.write_text(json.dumps(result,indent=2))
 # Only this fullyverified originalbackup is removed; allbytes live at target and originalpath resolves there.
 assert backup.is_dir()and not backup.is_symlink();shutil.rmtree(backup)
 assert not backup.exists()and source.is_symlink()and inventory(source.resolve())==before
 item.update(originalRemoved=True,removedOnlyVerifiedBackup=True,finalOriginalPathFullManifestVerified=True,finalVerifiedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());record.write_text(json.dumps(result,indent=2));print(json.dumps({'source':str(source),'target':str(target),'payloadsVerified':len(before),'bytes':item['regularBytes'],'originalReferenceLookupVerified':True,'onlyVerifiedBackupRemoved':True}),flush=True)
result.update(completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=True,originalsUnchanged=False,allOriginalReferencesPreservedBySymlink=True,regularTmpfsBytesRelocated=sum(x['regularBytes']for x in result['records']),resultIsNotGameplayOrSourceChange=True);record.write_text(json.dumps(result,indent=2));print(json.dumps({'completed':True,'regularTmpfsBytesRelocated':result['regularTmpfsBytesRelocated'],'record':str(record),'recordSHA256':hashlib.sha256(record.read_bytes()).hexdigest()}),flush=True)
