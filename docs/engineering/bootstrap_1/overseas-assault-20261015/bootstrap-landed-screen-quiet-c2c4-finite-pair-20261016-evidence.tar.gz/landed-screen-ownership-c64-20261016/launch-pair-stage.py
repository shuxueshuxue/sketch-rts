from pathlib import Path
import sys,json,os,subprocess,datetime,time,hashlib,shutil

D=Path(__file__).resolve().parent;label=sys.argv[1];assert label in ['baseline','candidate']
runtime=D/(label+'-runtime.json');cap=json.loads(runtime.read_text());O=Path(cap['outputRoot']);S=Path(cap['sourceRoot'])
assert not O.exists(),'Never overwrite an actual output'
c=Path('/sys/fs/cgroup');headroom=int((c/'memory.max').read_text())-int((c/'memory.current').read_text())
disk=shutil.disk_usage(D).free
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'headroom':headroom,'requiredHeadroom':2<<30,'diskAvailable':disk,'requiredDisk':128<<20,'heapMiB':768,'oomBefore':(c/'memory.events').read_text(),'runtimeSHA256':hashlib.sha256(runtime.read_bytes()).hexdigest()}
if headroom<2<<30 or disk<128<<20:
    receipt['exit']=75;(D/('prepared-only-'+label+'-'+str(time.time_ns())+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(75)
argv=['node','--max-old-space-size=768','--import',str(S/'node_modules/tsx/dist/loader.mjs'),str(D/'native-local-pair.ts'),str(runtime)]
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(D/('runtime-tmp-'+label)),'TSX_DISABLE_CACHE':'1'}
Path(env['TMPDIR']).mkdir(exist_ok=True)
receipt['argv']=argv;receipt['sourceHead']=cap['head'];receipt['outputRoot']=str(O)
with(D/('native-'+label+'-launch.log')).open('x') as log:
    process=subprocess.Popen(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT);receipt['pid']=process.pid
    (D/('native-'+label+'-spawn.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True);receipt['exit']=process.wait()
receipt.update(endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),oomAfter=(c/'memory.events').read_text())
(D/('native-'+label+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(receipt['exit'])
