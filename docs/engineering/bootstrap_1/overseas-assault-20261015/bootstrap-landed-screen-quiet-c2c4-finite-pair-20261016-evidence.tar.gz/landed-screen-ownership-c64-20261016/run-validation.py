from pathlib import Path
import sys,subprocess,datetime,time,json,os,hashlib
D=Path(__file__).resolve().parent;S=Path('/workspace/sketch-rts-landed-screen-ownership-c64-control');stage=sys.argv[1]
assert stage in ['old-red','new','new-ownership-pure','new-abilities','related','tsc']
receipt=D/f'validation-{stage}-receipt.json';assert not receipt.exists()
c=Path('/sys/fs/cgroup');limit=int((c/'memory.max').read_text());current=int((c/'memory.current').read_text());pure=stage in ['old-red','new-ownership-pure'];heap=512 if pure else 1024 if stage=='tsc'else 768;required=1<<30 if pure else 2<<30
r={'stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headroom':limit-current,'required':required,'heapMiB':heap,'oomBefore':(c/'memory.events').read_text(),'expectedExit':1 if stage=='old-red'else 0,'scope':'old-red is one pure AI contract with committedc64 override; equivalent extracted native helper remains available only to resolve unused test imports. New tests include native public issue, no whole match.'}
if stage=='new-ownership-pure':r['scope']='Sixteen raw-snapshot naval/landed/geometry contracts; no createGame, native step, public issue or fullP0. Existing pure512/1GiB profile.'
elif stage=='new-abilities':r['scope']='Nine ability contracts including native public command effects; native768/2GiB profile. No whole match.'
if limit-current<required:
 r['exit']=75;(D/f'prepared-only-{stage}-{time.time_ns()}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
if stage=='tsc':argv=['node','--max-old-space-size=1024',str(S/'node_modules/typescript/bin/tsc'),'--noEmit']
else:
 argv=['node',f'--max-old-space-size={heap}',str(S/'node_modules/vitest/vitest.mjs'),'run','--pool=forks','--maxWorkers=1','--minWorkers=1']
 if stage=='old-red':argv+=['--config',str(D/'baseline-red.config.ts'),'-t','actual218100 settled post']
 elif stage=='new':argv+=['src/ai/bootstrap_1/landed-screen-ownership.test.ts','src/ai/bootstrap_1/landed-abilities.test.ts']
 elif stage=='new-ownership-pure':argv+=['src/ai/bootstrap_1/landed-screen-ownership.test.ts']
 elif stage=='new-abilities':argv+=['src/ai/bootstrap_1/landed-abilities.test.ts']
 else:argv+=['src/ai/bootstrap_1/landed-combat.test.ts','src/ai/bootstrap_1/landed-caster-tower.test.ts','src/ai/policy/v6/backline.test.ts','src/ai/bootstrap_1/medical-allocation.test.ts','src/ai/bootstrap_1/medical-spell-publication.test.ts']
def source_hashes():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=S).decode().split('\0')
 return {p:hashlib.sha256((S/p).read_bytes()).hexdigest() for p in paths if p and (S/p).is_file()}
before=source_hashes()
r.update(argv=argv,headBefore=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),statusBefore=subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True),sourceFiles=len(before),sourceBefore=before);start=time.monotonic()
with(D/f'validation-{stage}.log').open('w')as log:
 q=subprocess.Popen(argv,cwd=S,env={**os.environ,'NODE_OPTIONS':f'--max-old-space-size={heap}'},stdout=log,stderr=subprocess.STDOUT);r['pid']=q.pid;r['exit']=q.wait()
after=source_hashes()
r.update(endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wallSeconds=time.monotonic()-start,oomAfter=(c/'memory.events').read_text(),statusAfter=subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True),changedSourceFiles=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]);receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='sourceBefore'}));print((D/f'validation-{stage}.log').read_text()[-14000:]);raise SystemExit(q.returncode if before==after else 99)
