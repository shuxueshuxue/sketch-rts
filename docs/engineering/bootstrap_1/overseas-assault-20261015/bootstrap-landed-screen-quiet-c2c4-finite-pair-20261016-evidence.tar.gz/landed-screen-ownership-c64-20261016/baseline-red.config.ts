import {defineConfig} from 'vitest/config';
import {execFileSync} from 'node:child_process';
const S='/workspace/sketch-rts-landed-screen-ownership-c64-control';
const paths=['src/ai/bootstrap_1/landed-combat.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/bootstrap_1/policy.ts','src/ai/policy/v6/backline.ts'];
const old=new Map(paths.map(path=>[S+'/'+path,execFileSync('git',['-C',S,'show','HEAD:'+path],{encoding:'utf8'})]));
export default defineConfig({root:S,plugins:[{name:'readonly-committed-c64-ai',enforce:'pre',transform(_code,id){const source=old.get(id.split('?')[0]!);return source===undefined?undefined:{code:source,map:null};}}],test:{include:['src/ai/bootstrap_1/landed-screen-ownership.test.ts']}});
