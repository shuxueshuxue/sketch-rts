# c64 landed 当轮任务归属：独立候选

本目录是新的实现与验证目录，原 f4/1b/fd 封档均保持不变。基线为 `c64d70c91a1ba8027a5b64c1af651537f41563ed`。当前候选已完成旧源真实抢令断言的预期失败与 16 项纯规划检查；9 项含原生施令的能力检查、相关测试、编译及原生对照尚未运行，不能算生产改进或 bootstrap 验收。

候选只把已证实的 whole-owner 瞬时能力分配结果按获准 landed actor 筛入同一 naval 批次，并让既有 landed planner 返回真实命令及本轮有效任务的 actor 集合。站位有效且无需重复移动的 actor 仍保留当轮任务；没有有效任务的 actor 释放。原医疗分配、board、charge、cast、queue 等优先级继续生效；不添加持久指挥状态或 TTL。

`shipHullAtPoint` 是单列的原生等价提取：native 原有 `units.find` predicate、顺序、敌船/零 HP 船、半径 0 和边界容差保持相同。它不是纯 AI 文件改动。候选没有搬入 fd/f4 的装船、联合卸载、ground-anchor 搜索；actual218040 原旧 XY 指令仍会选中船体，这个限制原样留给原生对照。

五份 gzip fixture 来自已封 f4 的实际完整 before-P0，包含世界、nextId 和三方记忆。它们是新 c64 候选的共同输入，不是历史 c64 现场档，也不是 fresh0。`fixture-provenance.json` 保存字节与来源。

独立有限静审见相邻 `landed-screen-ownership-c64-20261016-independent-review`。它发现并促成修正 native `hold`、建筑/障碍物攻击域及 deck-relative 旧移动三处边界；审查未运行测试或模拟。原 `actual-posts-query-attempt2.json` 是修正前三个边界的纯查询证据：218100 37753 已经 idle，旧 naval 宏观令再次推进它；候选可只保任务而不额外发令。该查询没有 Game、step 或真实施令，不能代替后续测试及完整状态原生比较。

准备的有限对照从实际已落地的 **218040** 同 world/nextId/all3mem 开始，两个独立固定源分别运行正常三方 AI 至 219240 或自然胜者。该 1200 tick 是局部因果观察范围，不是完整比赛验收，也不给新候选归属原先 27 人的装载或卸岸。无额外人工公开指令。后续必须以真实重登、施法、伤亡、敌建筑作用判断结果，不由 owner 合同或瞬时施法成功推断胜利。

规则 2、冻结 manifest 184 和历史源码 archive 497 均保留。冻结 v5/v7 对手执行历史代码；正常资源、人口、地图及既有出生规则不变。原容器未提交修改的恢复缺口仍未补齐。
