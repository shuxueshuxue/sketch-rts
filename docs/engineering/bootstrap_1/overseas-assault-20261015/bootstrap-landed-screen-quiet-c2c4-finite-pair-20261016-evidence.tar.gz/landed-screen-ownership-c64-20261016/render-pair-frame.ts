import {createCanvas} from '/workspace/sketch-rts-landed-screen-ownership-c64-control/node_modules/@napi-rs/canvas/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const [runtime,input,output,cx,cy,z]=process.argv.slice(2),cap=JSON.parse(readFileSync(runtime!,'utf8'));
if(!input!.startsWith(cap.outputRoot+'/frames/'))throw Error('Actual frame from this source capsule required');
const sha=(value:any)=>createHash('sha256').update(value).digest('hex'),raw=readFileSync(input!),frame=JSON.parse(gunzipSync(raw).toString()),before=sha(JSON.stringify(frame));
const load=(path:string)=>import(pathToFileURL(cap.sourceRoot+'/'+path).href);
const [{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([load('src/recorder/record.ts'),load('src/client/world-renderer.ts'),load('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const width=1500,height=1050,zoom=Number(z),view={x:Number(cx)-width/zoom/2,y:Number(cy)-height/zoom/2,width,height,zoom},canvas=createCanvas(width,height);
drawWorld({ctx:canvas.getContext('2d')as any,snapshot:frame.snapshot,view,now:frame.snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
if(before!==sha(JSON.stringify(frame)))throw Error('Static native render changed input');
const png=canvas.toBuffer('image/png');writeFileSync(output!,png);
writeFileSync(output!+'.json',JSON.stringify({classification:'Actual native client drawWorld of this fixedsource sameinput218040 finite normal3AI component. No Game/step/publiccommands; no loading/landing or whole-match credit.',sourceHead:cap.head,input,inputSHA256:sha(raw),output,pngSHA256:sha(png),tick:frame.snapshot.tick,view,fullStateUnchanged:true},null,2));
