from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,datetime

D=Path(__file__).resolve().parent
S=Path('/workspace/sketch-rts-landed-screen-ownership-c64-control')
B=Path('/workspace/sketch-rts-landed-screen-baseline-c64-control')
BASE='c64d70c91a1ba8027a5b64c1af651537f41563ed'
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda root,*args:subprocess.check_output(['git','-C',str(root),*args])
assert not (D/'pair-source-summary.json').exists()
assert git(B,'rev-parse','HEAD').decode().strip()==BASE
assert git(S,'rev-parse','HEAD').decode().strip()!=BASE
assert not git(S,'status','--porcelain') and not git(B,'status','--porcelain')
input_path=S/'src/ai/bootstrap_1/fixtures/landed-screen-ownership-f4-218040.json.gz'
input_bytes=input_path.read_bytes();saved=json.loads(gzip.decompress(input_bytes))
assert saved['snapshot']['tick']==218040 and set(saved['memories'])=={'p0','p1','p2'}
old=Path('/workspace/.playtest/landed-instant-spells-v5-20261016')
oldcap=json.loads((old/'fixed-runtime.json').read_text())
cohort=oldcap['observedCrewIds'];assert len(cohort)==27
units={unit['id']:unit for unit in saved['snapshot']['units']}
assert all(id in units and not units[id].get('deck') for id in cohort)
last_hits=dict(oldcap.get('inheritedLastHits',{}))
assert all(row['tick']<218040 for row in last_hits.values())
with gzip.open('/tmp/landed-instant-spells-v5-normal-217800-20261016/hits.jsonl.gz','rt') as stream:
    for line in stream:
        row=json.loads(line)
        if row['tick']>=218040:break
        last_hits[row['target']]=row
frozen_path=Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-frozen-source.tar.gz')
frozen_sha=sha(frozen_path.read_bytes());assert frozen_sha=='a43493bbbdb0e8b7e9810d64da6014e40b333d28f15f408249b5e74fe475f90a'
frozen={}
with tarfile.open(frozen_path,'r|gz') as stream:
    for member in stream:
        if member.isfile():frozen[member.name]=sha(stream.extractfile(member).read())
assert len(frozen)==497
manifest=json.loads((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
assert manifest==json.loads((B/'docs/engineering/bootstrap_1/frozen-policy.json').read_text())
assert manifest['rulesVersion']==2 and len(manifest['files'])==184
assert all(frozen[path]==value for path,value in manifest['files'].items())
process=subprocess.Popen(['git','-C',str(S),'archive',manifest['revision'],'package.json','src/ai','src/sdk','src/shared'],stdout=subprocess.PIPE)
historical={}
with tarfile.open(fileobj=process.stdout,mode='r|') as stream:
    for member in stream:
        if member.isfile():historical[member.name]=sha(stream.extractfile(member).read())
assert process.wait()==0 and historical==frozen
sources={}
for label,root in [('baseline',B),('candidate',S)]:
    head=git(root,'rev-parse','HEAD').decode().strip()
    paths=[path for path in git(root,'ls-files','-z').decode().split('\0') if path and (root/path).is_file()]
    hashes={path:sha((root/path).read_bytes()) for path in paths}
    sizes={path:(root/path).stat().st_size for path in paths}
    archive=D/(label+'-source.tar.gz')
    assert not archive.exists()
    with gzip.open(archive,'wb',compresslevel=6) as output:
        process=subprocess.Popen(['git','-C',str(root),'archive',head,'--',*paths],stdout=subprocess.PIPE)
        while data:=process.stdout.read(1024*1024):output.write(data)
        assert process.wait()==0
    seen=set()
    with tarfile.open(archive,'r|gz') as stream:
        for member in stream:
            if member.isfile():
                content=stream.extractfile(member).read();assert len(content)==sizes[member.name] and sha(content)==hashes[member.name]
                seen.add(member.name)
    assert seen==set(paths)
    cap={'classification':label+' fixed source, same actualf4 already-landed218040 finite normal3AI component, not fresh0 or historicalc64 capture.',
        'sourceRoot':str(root),'head':head,'hashes':hashes,'outputRoot':str(D/('native-'+label+'-218040-219240')),
        'inputPath':str(input_path),'inputSHA256':sha(input_bytes),'start':218040,'end':219240,'agents':oldcap['agents'],
        'frozenRevision':manifest['revision'],'cohortIds':cohort,'inheritedLastHits':last_hits,
        'driverSHA256':sha((D/'native-local-pair.ts').read_bytes()),'observerSHA256':sha((D/'observer-ledger.ts').read_bytes())}
    runtime=D/(label+'-runtime.json');runtime.write_text(json.dumps(cap,indent=2)+'\n')
    sources[label]={'sourceRoot':str(root),'head':head,'files':len(paths),'hashes':hashes,'sizes':sizes,
        'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'allPayloadMatchesGitAndWorkingCopy':True},
        'runtime':{'path':str(runtime),'sha256':sha(runtime.read_bytes())}}
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'base':BASE,
    'input':{'path':str(input_path),'bytes':len(input_bytes),'sha256':sha(input_bytes),'scope':'Actualf4 original complete218040 beforeP0; 27 already truly landed. Both new sources start from this same world/id/all3mem. Neither source receives packing/landing credit.'},
    'frozen':{'path':str(frozen_path),'bytes':frozen_path.stat().st_size,'sha256':frozen_sha,'497HistoricalGitMatches':True,'184ManifestMatches':True,'rulesVersion':2},
    'manifestSHA256':sha((S/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes()),
    'inheritedLastHitScope':'Originalf4 capsule inherited actualfd hits before217800, then actualf4 raw hits strictly before218040. No same-tick later hit presumed observed.',
    'nativeExtraction':'Candidate extracts original c64 first-hull predicate into shared helper and native reuses it; separately tested identical ordering/dead/enemy/boundary behavior, not AI-only delta.',
    'nativeScope':'NoGame launched by preparation. Next pair is finite1200 normal3AI local causal comparison, no manual public commands. Native hull-relative XY/reboarding remains originalc64 behavior; no ground-anchor/packing ancestor imported.'}
(D/'pair-source-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(D/'candidate-vs-c64.patch').write_bytes(git(S,'diff',BASE,'HEAD'))
print(json.dumps({key:value for key,value in summary.items() if key!='sources'},indent=2))
print(json.dumps({label:{key:value for key,value in data.items() if key not in ['hashes','sizes']} for label,data in sources.items()},indent=2))
