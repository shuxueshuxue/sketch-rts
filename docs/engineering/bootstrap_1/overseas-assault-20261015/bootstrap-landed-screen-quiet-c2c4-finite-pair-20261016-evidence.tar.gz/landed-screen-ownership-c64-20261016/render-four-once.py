from pathlib import Path
import subprocess,os,datetime,json,resource

D=Path(__file__).resolve().parent;c=Path('/sys/fs/cgroup');result=D/'four-native-renders-receipt.json';assert not result.exists()
receipts=[]
for label in ['baseline','candidate']:
    cap=json.loads((D/(label+'-runtime.json')).read_text());S=Path(cap['sourceRoot'])
    for tick in [218100,218400]:
        frame=Path(cap['outputRoot'])/'frames'/(str(tick)+'-before-p0.json.gz');assert frame.exists()
        headroom=int((c/'memory.max').read_text())-int((c/'memory.current').read_text())
        row={'label':label,'tick':tick,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headroom':headroom,'required':1<<30,'heapMiB':512,'oomBefore':(c/'memory.events').read_text()}
        if headroom<1<<30:
            row['exit']=75;receipts.append(row);result.write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(row));raise SystemExit(75)
        output=D/(label+'-native-'+str(tick)+'.png')
        argv=['node','--max-old-space-size=512','--import',str(S/'node_modules/tsx/dist/loader.mjs'),str(D/'render-pair-frame.ts'),str(D/(label+'-runtime.json')),str(frame),str(output),'9100','6050','1.4']
        with(D/(label+'-render-'+str(tick)+'.log')).open('x') as log:
            process=subprocess.Popen(argv,cwd=S,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=512','TSX_DISABLE_CACHE':'1'},stdout=log,stderr=subprocess.STDOUT);row['pid']=process.pid;row['exit']=process.wait()
        row.update(endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),oomAfter=(c/'memory.events').read_text(),maxRSSKiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
        receipts.append(row);result.write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(row),flush=True)
        if process.returncode:raise SystemExit(process.returncode)
