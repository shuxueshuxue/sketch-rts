from pathlib import Path
import json,gzip,hashlib,collections

D=Path(__file__).resolve().parent
sha=lambda content:hashlib.sha256(content).hexdigest()
def rows(path):
    with gzip.open(path,'rt') as stream:
        return [json.loads(line) for line in stream]
def full(path):return json.loads(gzip.decompress(path.read_bytes()))
summary=json.loads((D/'pair-source-summary.json').read_text())
data={}
for label in ['baseline','candidate']:
    cap=json.loads((D/(label+'-runtime.json')).read_text());O=Path(cap['outputRoot'])
    report=json.loads((O/'report.json').read_text());initial=full(O/'frames/218040-strict-restored-before-p0.json.gz');final=full(O/'final.json.gz')
    expected=full(Path(cap['inputPath']))
    assert all(report['restore'].values()) and not report['sourcePre']['changed'] and not report['sourcePost']['changed']
    assert not report['frozenPre']['changed'] and not report['frozenPost']['changed']
    assert all(initial[key]==expected[key] for key in ['snapshot','nextId','memories'])
    streams={name:rows(O/(name+'.jsonl.gz')) for name in ['commands','hits','events','plans','effects']}
    assert len(streams['commands'])==report['counts']['commands'] and len(streams['hits'])==report['counts']['hits']
    assert len(streams['events'])==report['counts']['events'] and len(streams['plans'])==report['counts']['plans']
    cohort=set(cap['cohortIds']);before={unit['id']:unit for unit in initial['snapshot']['units']};after={unit['id']:unit for unit in final['snapshot']['units']}
    terminal={event['id']:event for event in streams['events'] if event['type']=='native-unit-terminal' and event['id'] in cohort}
    reboard=[event for event in streams['events'] if event['type']=='observed-parent-change' and event['after']['id'] in cohort and event['after'].get('deck')]
    removals={event['previous']['id']:event for event in streams['events'] if event['type']=='unit-removal'}
    cohort_deaths=[]
    for id,event in terminal.items():
        removed=removals.get(id)
        cohort_deaths.append({'id':id,'kind':before[id]['kind'],'firstTerminalTick':event['tick'],'firstTerminalObservedAs':event['observedAs'],'nativeRemovalTick':removed['tick'] if removed else None,'lastHit':event.get('lastNativeHit'),'ownerAtFirstTerminal':(event.get('atObservation')or event['previous'])['owner']})
    permanent_by_owner=collections.Counter((event.get('atObservation')or event['previous'])['owner'] for event in streams['events'] if event['type']=='native-unit-terminal' and event['permanent'])
    buildings_by_owner=collections.Counter(event['previous']['owner'] for event in streams['events'] if event['type']=='native-building-terminal')
    by_source=collections.Counter((hit['attackerOwner'],hit['attackerKind'],hit['targetOwner']) for hit in streams['hits'])
    native_summons=[effect for effect in streams['effects'] if effect['command']['type']=='cast' and effect['command']['ability']=='summon']
    result={'head':cap['head'],'start':report['start'],'end':report['end'],'winner':report['winner'],'naturalComplete':report['naturalComplete'],'finiteObservationOnly':report['finiteObservationOnly'],
        'counts':report['counts'],'strictCompleteInputRestored':True,'sourcePrePostUnchanged':True,'frozen184PrePostUnchanged':True,
        'cohortKinds':dict(collections.Counter(before[id]['kind'] for id in cohort)),'cohortDeaths':sorted(cohort_deaths,key=lambda row:(row['firstTerminalTick'],row['id'])),
        'cohortLiving':report['livingCohort'],'cohortObservedReboards':[{'tick':event['tick'],'id':event['after']['id'],'deck':event['after']['deck']} for event in reboard],
        'firstObservedPermanentTerminalsByOwner':dict(permanent_by_owner),'buildingTerminalsByOwner':dict(buildings_by_owner),
        'hitCategories':[{'attackerOwner':key[0],'attackerKind':key[1],'targetOwner':key[2],'hits':count,'damage':sum(hit['damage'] for hit in streams['hits'] if (hit['attackerOwner'],hit['attackerKind'],hit['targetOwner'])==key)} for key,count in by_source.items()],
        'nativeSummonIssues':[{'tick':effect['tick'],'actor':effect['command']['unitId'],'legalityBefore':effect['legalityBefore'],'births':[{'id':unit['id'],'kind':unit['kind'],'owner':unit['owner']} for unit in effect['newUnits']],'effects':[native['type'] for native in effect['newEffects']]} for effect in native_summons],
        'finalWorldSHA256':sha(json.dumps(final['snapshot'],separators=(',',':')).encode()),'finalNextId':final['nextId'],
        'finalBuildingCountsByOwner':dict(collections.Counter(building['owner'] for building in final['snapshot']['buildings'] if building['hp']>0)),
        'terminalScope':'First observed nonpositiveHP/removal is not silently equated with native cumulativeunitsLost; native removal tick is retained separately. An ownerchange/capture is separate from a death.'}
    data[label]={'result':result,'streams':streams,'initial':initial,'final':final}
def first_difference(a,b):
    for index in range(max(len(a),len(b))):
        left=a[index] if index<len(a) else None;right=b[index] if index<len(b) else None
        if left!=right:return {'index':index,'baseline':left,'candidate':right}
    return None
command_first=first_difference(data['baseline']['streams']['commands'],data['candidate']['streams']['commands'])
plan_first=first_difference(data['baseline']['streams']['plans'],data['candidate']['streams']['plans'])
audit={'scope':'Finite sameactual218040 already-landed normal3AI changed-source component; neither source receives original27 loading/landing credit. Not fresh0, completegame, acceptance or survivalproof beyond observed window.',
    'sameCompleteInput':all(data['baseline']['initial'][key]==data['candidate']['initial'][key] for key in ['snapshot','nextId','memories']),
    'cases':{label:item['result'] for label,item in data.items()},'firstActualPublicCommandDifference':command_first,'firstPlanOrPostmemDifference':plan_first,
    'finalEquality':{key:data['baseline']['final'][key]==data['candidate']['final'][key] for key in ['snapshot','nextId','memories']},
    'perActorCommands':{id:{label:[row for row in item['streams']['commands'] if id in row['command'].get('unitIds',[]) or row['command'].get('unitId')==id] for label,item in data.items()} for id in ['unit-p0-summoner-37753','unit-p0-summoner-40241','unit-p0-priest-3174','unit-p0-emberRavager-19557']}}
assert audit['sameCompleteInput']
output=D/'finite-native-pair-audit.json';assert not output.exists();output.write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'cases':{label:{key:item['result'][key] for key in ['head','start','end','winner','counts','buildingTerminalsByOwner']} for label,item in data.items()}},indent=2))
