import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
const D='/workspace/.playtest/landed-screen-ownership-c64-20261016',S='/workspace/sketch-rts-landed-screen-ownership-c64-control';
const attempt=process.argv[2];if(!attempt)throw Error('Explicit attempt name required');
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),clone=(v:any)=>JSON.parse(JSON.stringify(v));
const paths=['src/ai/bootstrap_1/landed-combat.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/bootstrap_1/policy.ts','src/ai/policy/v6/backline.ts','src/shared/sim.ts','src/shared/ship-geometry.ts'];
const readset=Object.fromEntries([...paths,'src/ai/bootstrap_1/landed-abilities.ts'].map(p=>[p,sha(readFileSync(S+'/'+p))]));
const old=new Map(paths.map(p=>[S+'/'+p,execFileSync('git',['-C',S,'show','HEAD:'+p],{encoding:'utf8'})]));
const modules:any={};
for(const label of ['old','new']){
 const outfile=D+'/actual-posts-'+label+'-'+attempt+'.mjs';
 await build({stdin:{contents:`export {planLandedCombat} from '${S}/src/ai/bootstrap_1/landed-combat.ts'; export {planBootstrapNaval} from '${S}/src/ai/bootstrap_1/expedition-recovery.ts'; export {bootstrapPolicyContext} from '${S}/src/ai/bootstrap_1/policy.ts'; export {setBuildingBodies} from '${S}/src/shared/terrain.ts';`,loader:'ts',resolveDir:S},bundle:true,platform:'node',format:'esm',outfile,plugins:label==='new'?[]:[{name:'committed-c64-only',setup(builder){builder.onLoad({filter:/\.ts$/},args=>old.has(args.path)?{contents:old.get(args.path)!,loader:'ts',resolveDir:dirname(args.path)}:undefined);}}]});
 modules[label]=await import(pathToFileURL(outfile).href);
}
const ids=['unit-p0-summoner-37753','unit-p0-summoner-40241'];
const rows:any[]=[];
for(const tick of [218040,218100,218250,218385,218700]){
 const inputPath=S+`/src/ai/bootstrap_1/fixtures/landed-screen-ownership-f4-${tick}.json.gz`,raw=readFileSync(inputPath),saved=JSON.parse(gunzipSync(raw).toString()),before=JSON.stringify(saved),row:any={tick,inputPath,inputSHA256:sha(raw),actors:{}};
 for(const label of ['old','new']){
  const m=modules[label],snapshot=clone(saved.snapshot),context=m.bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:clone(saved.memories.p0),teams:snapshot.teams});
  m.setBuildingBodies(snapshot.map,[...snapshot.buildings,...snapshot.obstacles??[]]);
  const snapshotBefore=JSON.stringify(snapshot),plan=m.planLandedCombat(snapshot,'p0',context,new Set()),commands=Array.isArray(plan)?plan:plan.commands;
  row[label]={localCommands:commands,assignments:Array.isArray(plan)?null:[...plan.assignments],quietAssignments:Array.isArray(plan)?[]:[...plan.assignments].filter(id=>!commands.some((c:any)=>c.unitIds?.includes(id))),worldUnchanged:JSON.stringify(snapshot)===snapshotBefore};
  for(const id of ids){row.actors[id]??={};row.actors[id][label]={commands:commands.filter((c:any)=>c.unitIds?.includes(id)||c.unitId===id),assigned:!Array.isArray(plan)&&plan.assignments.has(id)};}
 }
 if(row.new.quietAssignments.some((id:string)=>ids.includes(id))){
  for(const label of ['old','new']){
   const m=modules[label],snapshot=clone(saved.snapshot),context=m.bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:clone(saved.memories.p0),teams:snapshot.teams});m.setBuildingBodies(snapshot.map,[...snapshot.buildings,...snapshot.obstacles??[]]);
   row[label].navalCommands=m.planBootstrapNaval(snapshot,'p0',context).filter((c:any)=>ids.some(id=>c.unitIds?.includes(id)||c.unitId===id));
  }
 }
 if(JSON.stringify(saved)!==before)throw Error('Original full input mutated');rows.push(row);
}
const after=Object.entries(readset).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);if(after.length)throw Error('Draft source changed during query');
const result={classification:'Pure committedc64 vs independent draft component on actual fixedf4 full inputs; no Game, fullP0, step or issued commands. Not originalc64 historical capture.',readset,rows,sourceAfter:after,rss:process.memoryUsage().rss,usage:process.resourceUsage()};
writeFileSync(D+'/actual-posts-query-'+attempt+'.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({rows:rows.map(r=>({tick:r.tick,actors:r.actors,quiet:r.new.quietAssignments,naval:{old:r.old.navalCommands,new:r.new.navalCommands}})),sourceAfter:after,rss:result.rss}));
