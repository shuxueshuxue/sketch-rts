import {readFileSync,writeFileSync,mkdirSync,appendFileSync,renameSync,existsSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
import {NativeLedger} from './observer-ledger.ts';

const cap=JSON.parse(readFileSync(process.argv[2]!,'utf8')),S=cap.sourceRoot,O=cap.outputRoot;
const sha=(value:any)=>createHash('sha256').update(value).digest('hex'),copy=(value:any)=>JSON.parse(JSON.stringify(value));
const load=(path:string)=>import(pathToFileURL(S+'/'+path).href);
const atomic=(path:string,value:any)=>{writeFileSync(path+'.tmp',value);renameSync(path+'.tmp',path);};
const emit=(stream:string,value:any)=>appendFileSync(O+'/'+stream+'.jsonl.gz',gzipSync(JSON.stringify(value)+'\n',{level:3}));
if(process.cwd()!==S||existsSync(O+'/actual-launch.json'))throw Error('Exact fixed cwd and new output required');
if(sha(readFileSync(import.meta.filename))!==cap.driverSHA256||sha(readFileSync(new URL('./observer-ledger.ts',import.meta.url)))!==cap.observerSHA256)throw Error('Fixed observer/driver changed');
function sourceProof(){
  const changed=Object.entries(cap.hashes).filter(([path,hash])=>sha(readFileSync(S+'/'+path))!==hash).map(([path])=>path);
  const head=execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),status=execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'});
  if(changed.length||head!==cap.head||status)throw Error('Source changed');
  return {head,files:Object.keys(cap.hashes).length,changed,status};
}
const raw=readFileSync(cap.inputPath);if(sha(raw)!==cap.inputSHA256)throw Error('Actual complete input changed');
const input=JSON.parse(gunzipSync(raw).toString()),sourcePre=sourceProof();
mkdirSync(O+'/frames',{recursive:true});for(const name of ['commands','hits','events','effects','plans'])writeFileSync(O+'/'+name+'.jsonl.gz','');
const startedAtUtc=new Date().toISOString();
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest},{runAiGameLoop},{checkCommandLegality}]=await Promise.all([
  load('src/shared/sim.ts'),load('src/ai/planner-context.ts'),load('scripts/bootstrap_1-planner.ts'),load('src/ai/game-runner.ts'),load('src/shared/sim/command-validation.ts')]);
const game=createGame('bareDuel'),memory=createAiMemoryProvider();restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
for(const [owner,value]of Object.entries(input.memories))memory.set(owner,copy(value));
const full=()=>copy({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(input.memories).map(owner=>[owner,memory.get(owner)]))});
const initial=full(),restore={world:isDeepStrictEqual(initial.snapshot,input.snapshot),nextId:game.nextId===input.nextId,all3mem:isDeepStrictEqual(initial.memories,input.memories)};
if(game.tick!==cap.start||Object.values(restore).some(value=>!value))throw Error('Strict complete restore failed');
const frozenRoot=frozenPolicyRoot();
function frozenProof(){
  const changed=Object.entries(frozenPolicyManifest.files).filter(([path,hash])=>sha(readFileSync(frozenRoot+'/'+path))!==hash).map(([path])=>path);
  if(changed.length||Object.keys(frozenPolicyManifest.files).length!==184||frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==cap.frozenRevision)throw Error('Frozen source/rules changed');
  return {rulesVersion:2,files:184,revision:frozenPolicyManifest.revision,changed};
}
const frozenPre=frozenProof(),normal=await createBootstrapCommandPlanner(memory);
if(!isDeepStrictEqual(full(),initial))throw Error('Planner preparation mutated complete input');
const counts={steps:0,commands:0,hits:0,events:0,plans:0},cohort=new Set<string>(cap.cohortIds),ledger=new NativeLedger(game.units,game.buildings),lastHit=new Map<string,any>(Object.entries(cap.inheritedLastHits??{}));
let commandIndex:number|undefined;
const capture=(stage:string)=>atomic(O+'/frames/'+game.tick+'-'+stage+(commandIndex===undefined?'':'-'+commandIndex)+'.json.gz',gzipSync(JSON.stringify({...full(),checkpointStage:stage,commandIndex})));
function observe(stage:string){
  for(const event of ledger.observe(game.tick,stage,game.units,game.buildings,lastHit)){
    emit('events',{...event,eventIndex:counts.events++,commandIndex});
    if(event.type==='native-unit-terminal'&&cohort.has(event.id)||event.type==='native-building-terminal')capture('terminal-'+stage);
  }
}
game.observer={hit(attacker:any,target:any,damage:number,hpBefore:number){
  const hit=copy({tick:game.tick,attacker:attacker.id,attackerOwner:attacker.owner,attackerKind:attacker.kind,target:target.id,targetOwner:target.owner,targetKind:target.kind,damage,hpBefore,hpAfter:target.hp,attackerDeck:attacker.deck,targetDeck:target.deck});
  emit('hits',hit);lastHit.set(target.id,hit);counts.hits++;
}};
const planner=(context:any)=>{
  const before=full();if(context.owner==='p0')capture('before-p0');
  const entries=normal(context),after=full();
  if(!isDeepStrictEqual(before.snapshot,after.snapshot)||before.nextId!==after.nextId)throw Error('Normal planner changed native world or nextId');
  emit('plans',{tick:game.tick,owner:context.owner,inputFullSHA256:sha(JSON.stringify(before)),entries,all3postmem:after.memories});counts.plans++;
  return entries;
};
atomic(O+'/actual-launch.json',JSON.stringify({classification:cap.classification,startedAtUtc,pid:process.pid,cwd:process.cwd(),argv:process.argv,sourcePre,frozenPre,restore,inputPath:cap.inputPath,inputSHA256:sha(raw),driverSHA256:cap.driverSHA256,observerSHA256:cap.observerSHA256,agents:cap.agents,start:cap.start,end:cap.end,subjectMode:'All three normal planners; normal(context) returned unchanged. No additional public commands or world edits. Actual218040 already-landed f4 input is a common changed-source component boundary, not historicalc64 capture or fresh0.',observerBoundary:'Command attempts and before/after native effects are separate. First observed hp<=0 and actual cleanup/removal are separate ledger facts. All public commands, native hits and three-owner postmemories retained; finite local window is not a full match.'},null,2));
capture('strict-restored-before-p0');
const result=runAiGameLoop({name:'sameinput218040 landed owner finite normal3AI',game,agents:cap.agents,maxTicks:cap.end,thinkInterval:15,commandPlanner:planner},{
  afterCommand(event:any){
    const command=event.command,ids=new Set([...(command.unitIds??[]),command.unitId,command.passengerId,command.targetId].filter(Boolean));
    if(event.owner!=='p0'||![...ids].some(id=>cohort.has(id)))return;
    emit('effects',copy({tick:event.tick,commandIndex:counts.commands,owner:event.owner,scriptId:event.scriptId,command,legalityBefore:checkCommandLegality(event.before,event.owner,command)??null,snapshotChanged:!isDeepStrictEqual(event.before,event.after),before:event.before.units.filter((unit:any)=>ids.has(unit.id)),after:event.after.units.filter((unit:any)=>ids.has(unit.id)),newEffects:event.after.effects.filter((effect:any)=>!event.before.effects.some((old:any)=>old.id===effect.id)),newUnits:event.after.units.filter((unit:any)=>!event.before.units.some((old:any)=>old.id===unit.id))}));
  },
  onCommand(event:any){commandIndex=counts.commands++;emit('commands',copy({tick:event.tick,commandIndex,owner:event.owner,scriptId:event.scriptId,command:event.command}));observe('after-command');commandIndex=undefined;},
  beforeStep(){observe('before-step');ledger.beforeStep(game.units);},
  onStep(){counts.steps++;observe('after-step');if(game.tick%600===0||game.match.winner)capture('complete-after-step');},
});
const final=full(),sourcePost=sourceProof(),frozenPost=frozenProof();capture('final');atomic(O+'/final.json.gz',gzipSync(JSON.stringify(final)));
const livingCohort=game.units.filter((unit:any)=>cohort.has(unit.id)&&unit.hp>0).map((unit:any)=>({id:unit.id,kind:unit.kind,owner:unit.owner,hp:unit.hp,x:unit.x,y:unit.y,deck:unit.deck,cabin:unit.cabin,order:unit.order}));
const report={classification:cap.classification,start:cap.start,end:game.tick,startedAtUtc,endedAtUtc:new Date().toISOString(),pid:process.pid,winner:game.match.winner,naturalComplete:!!game.match.winner,finiteObservationOnly:!game.match.winner,counts,restore,sourcePre,sourcePost,frozenPre,frozenPost,livingCohort,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,finalSHA256:sha(readFileSync(O+'/final.json.gz'))};
atomic(O+'/report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
