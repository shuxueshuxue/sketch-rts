from pathlib import Path
import json,hashlib,tarfile,io,datetime

D=Path(__file__).resolve().parent
archive=D.parent/'bootstrap-landed-screen-quiet-c2c4-finite-pair-20261016-evidence.tar.gz'
delivery=D.parent/'bootstrap-landed-screen-quiet-c2c4-finite-pair-20261016-delivery.json'
assert not archive.exists() and not delivery.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
files={str(path.relative_to(D.parent)):path for path in sorted(D.rglob('*')) if path.is_file() and not path.is_symlink()}
frozen=Path('/workspace/.playtest/cabin-load-capability-ade-20261016/root-frozen-source.tar.gz')
assert sha(frozen.read_bytes())=='a43493bbbdb0e8b7e9810d64da6014e40b333d28f15f408249b5e74fe475f90a'
files['frozen-source-original-497.tar.gz']=frozen
entries={name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for name,path in files.items()}
index={'classification':'Fixedc2c4 vs exactc64 sameactual218040 finite normal3AI1200; neither a fresh0 nor fullmatch victory. Two complete live source archives and original frozen497 included. Original27 packing/disembark belongs to fd/f4 antecedent.','files':entries,'payload':len(entries),'rulesVersion':2,'runtimeFrozenManifestFiles':184,'candidate':'c2c4df13ec35d49daa3edae10122ee9f005945f9','baseline':'c64d70c91a1ba8027a5b64c1af651537f41563ed'}
data=(json.dumps(index,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz',compresslevel=6) as output:
    for name,path in files.items():output.add(path,arcname=name,recursive=False)
    member=tarfile.TarInfo('INDEX.json');member.size=len(data);output.addfile(member,io.BytesIO(data))
seen=set()
with tarfile.open(archive,'r|gz') as stream:
    for member in stream:
        if not member.isfile():continue
        content=stream.extractfile(member).read()
        if member.name=='INDEX.json':assert content==data;continue
        assert member.name not in seen and member.name in entries
        assert len(content)==entries[member.name]['bytes'] and sha(content)==entries[member.name]['sha256'];seen.add(member.name)
assert seen==set(entries)
changed=[name for name,path in files.items() if path.stat().st_size!=entries[name]['bytes'] or sha(path.read_bytes())!=entries[name]['sha256']]
assert not changed
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payload':len(entries),'regularIncludingIndex':len(entries)+1,'indexSHA256':sha(data),'allPayloadSHABytesCoverageVerified':True,'originalsChanged':changed,'candidate':index['candidate'],'baseline':index['baseline'],'start':218040,'end':219240,'winnerBoth':None,'classification':index['classification'],'candidateSourceFiles':1586,'baselineSourceFiles':1578,'frozenRuntime184PrePost':True,'frozenHistorical497Included':True,'rulesVersion':2,'distinctTests':69,'tscExit':0,'localCohort':{'baselineConfirmedRemoved':19,'baselineAliveOnDeck':8,'candidateConfirmedRemoved':12,'candidateAliveAllGround':15,'candidateUniqueReboards':3,'buildingsDestroyedBoth':0},'readme':'landed-screen-ownership-c64-20261016/README.final-finite-pair.zh.md','sealedDirectory':str(D),'remaining':'Finite coupled local evidence only. No complete natural continuation or fresh0 result for c2c4, no productionmerge. Subsequent work must use a new external evidence directory and retain fixed source.'}
delivery.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
