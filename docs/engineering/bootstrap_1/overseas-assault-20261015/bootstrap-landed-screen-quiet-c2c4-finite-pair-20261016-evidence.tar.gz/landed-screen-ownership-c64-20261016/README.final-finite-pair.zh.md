# c64 landed 瞬时技能与有效任务归属：有限原生对照

候选固定为 **c2c4df13ec35d49daa3edae10122ee9f005945f9**，基线是 **c64d70c91a1ba8027a5b64c1af651537f41563ed**。这是独立控制树的有限组件对照，未合入生产。原 27 人的装载和 218025 卸岸来自 fd/f4 前史；本候选不取得这些成绩。原容器未提交修改的恢复缺口仍未补齐。

双方从真实 f4 **218040 before-P0** 的同一完整世界、nextId、三方记忆开始，正常运行三方 AI 到 219240。该初档为 33,556 字节，SHA256 `0220ac4f4b19c9d0086d729d28bd35672258cef5a4ab9624ca90a83b4ebbabe3`。它不是历史 c64 现场捕获，也不是普通 0 开局。没有额外人工命令、资源或身体改动。对手继续执行规则 2 的冻结 v5/v7，原 1.4 门槛、三路线风格、资源人口和思考间隔未改。

## 实际结果与范围

| 218040→219240 | c64 基线 | c2c4 候选 |
| --- | ---: | ---: |
| 原 27 人确认原生移除 | 19 | 12 |
| 窗口终点仍活 | 8，均已回 carrier | 15，均无 deck/cabin |
| 曾实际重登船的不同成员 | 8 | 3 |
| P1 永久单位 terminal | 5 | 11 |
| 灵体对敌实伤 | 364 | 780 |
| ravager 对敌实伤 | 180 | 400 |
| 被摧毁建筑 | 0 | 0 |
| 胜者 | null | null |

候选终点 15 人为 13 summoner、1 priest、1 ashHexer；原 9 ravager 最迟在 219092 全灭。候选 14 名 summoner 在 218040 真正生出 14 个 spirit；3 人早期仍曾重登，后由正常 AI 真卸岸，因此不能称“零重登”。死亡列表保留首次非正 HP 和实际原生移除两个 tick，27 人的已记死亡均已确认 cleanup。捕获、到期、永久死亡和原生累计 stats 不互相替代。

实际 37753 在旧源有 21 move/9 attackMove，218556 死；新源有 48 move/2 holdPosition/3 attackMove，219240 仍 95 HP，首次 holdPosition 在 218070。没有把所有宏观命令一律屏蔽。这是 **instant + quiet owner 组合** 的局部效果，不能单独归因某一个组件，也不能把 15 人当前存活说成终局保全、攻岛成功或 bootstrap 验收。下一步仍需完整自然战斗和完整比赛证据。

双方各 1200 原生步、240 次三方 planner 调用（其中各 80 次 P0）。基线 1435 公开命令/311 hit/199 ledger event；候选 2136/358/211。所有公开命令、真实命中、三方每次规划后的记忆、完整 before-P0 与周期/终点状态均保留。两边 world/id/all3mem 严格恢复全真，live source、冻结 184、规则 2 前后无变化。source archive 还逐文件匹配 Git 与工作树，历史冻结 archive 497 匹配历史 Git；不要把 497 称为额外 runtime 184 以外的现场校验。

## 源码职责

同一个 landed owner 从原 whole-owner 能力分配中筛出自己获准且当轮原生可瞬时执行的 actor，保留全局 curse 目标分配。晚到 abilities 仅对本轮已接受的同 actor+ability 瞬时项去重；不改通用 runner，不放行所有 cast。c64 的选定医疗法术优先级和物理释放合同保持。

既有 landed planner 返回 commands 和本轮有效 assignments。有效 quiet post 可在没有重复移动令时保留任务；无合法任务则释放，board/queue/charge/cast/医疗等原优先级继续生效。没有持久 commander、TTL、全体 backline 占有或兼容回退。

`shipHullAtPoint` 单列为原生等价提取：原 native `units.find` 的 predicate、顺序、敌/零 HP 船及半径 0 边界未变，native 自己也调用同一 helper。因此不是“只改 AI”。原 c64 的旧 XY 船壳目标继续原样留在候选；没有暗带 fd/f4 ground-anchor 或装船/联合卸岸祖先。

## 检查与原失败

最终 **69 项不同检查**：新 16 ownership +9 ability，原相关 12 landed +4 tower +6 backline +12 medical-allocation +10 medical-publication，单 1024 类型检查 exit 0。重复运行不累加为新覆盖。

原日志都保留：旧源 actual218100 settled actor 的断言正确因宏观 attackMove 而红；第一次能力检查 8 绿 1 红，是旧 f4 合同误要求即时 healer 占移动权，测试修成 c64 的 casting=true/occupied=false/唯一 heal；第一次相关检查 43 绿 1 红，是旧 tower whole-array 只期望 move，测试改成精确新增 summon 后原 move，shared default 的精确断言保留。两次修正均不改生产字节；所有生产文件在各验证阶段完全相同。

有限独立静审促成修复 native hold、全 native attack target 域、deck-relative 旧 move 三处草稿边界；其后未见该有限范围的新具体 blocker。审查本身未执行测试或 Game。driver 审查还补齐更早 fd 命中历史继承；这只影响观察账，不改世界或命令。

## 原生图与复核入口

四张 `{baseline,candidate}-native-{218100,218400}.png` 都从对应源实际完整帧调用 native client `drawWorld`，不创建 Game 或 step。已亲看：218100 候选灵体更早进入敌弓阵前；218400 双方后排与岸边/船壳距离显著不同。图片只是视觉线索，实际 parent、owner、HP 与命中取自完整状态和 raw；不能按衣色或船壳覆盖推断归属。

主要结构化资料：`fixed-validation.json`、`pair-source-summary.json`、`finite-native-pair-audit.json`、`actual-actors-and-boundaries.json`，以及两侧 runtime、launch/receipt/report、frames 和 gzip JSONL streams。gzip JSONL 是逐记录 concatenated members，普通 `gzip.open` 可无损逐行读取。

`baseline-red.config.ts` 与 `query-actual-posts.ts` 是 **提交前实际使用的历史脚本**，当时 HEAD 为 c64；提交后不能把其 HEAD 动态引用当成新的固定旧源重放。历史 query 的 old/new bundle 和 readset 已保留。原生对照使用两个完整独立控制树和固定 capsule，不依赖这项历史 override。

原 f4 有限负例仍独立封存为 `bootstrap-landed-spells-f4-focused-negative-20261016-evidence.tar.gz`，95,977,681 字节，SHA256 `7ba3c9075eb4b1e859adea646302b3b2273e754d3479620d925609ec9d7e37de`；217800→349800 的支持观察停止不是自然败。此包不会改写该来源或把不同源的尾局拼成普通 0 胜局。
