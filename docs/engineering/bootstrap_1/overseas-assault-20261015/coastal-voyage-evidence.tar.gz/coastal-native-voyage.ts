import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame,issuePlayerCommand,stepGame} from '../../src/shared/sim';
import {coastalVoyagePrefixSafe,planCoastalVoyage,coastalFireDisks,coastalFireSegmentClear} from '../../src/ai/policy/coastal-voyage';
const root='.playtest/overseas-assault-20261015',results=[];
for(const [name,fixture,goal]of [['opening','summoner-distant-battery',{x:2788.6,y:6752}],['transit','summoner-battery-transit',{x:2724.6,y:6912}]] as const){
 const f=JSON.parse(gunzipSync(readFileSync('src/ai/bootstrap_1/fixtures/'+fixture+'.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const ship=g.units.find(u=>u.id==='unit-p0-bombardShip-26580')!,startTick=g.tick,events:any[]=[],rows:any[]=[];let current:ReturnType<typeof planCoastalVoyage>,outcome='running';const hp=ship.hp;
 for(let count=0;count<20000&&g.units.includes(ship);count++){
  if(count%15===0){const s=snapshotGame(g),seen=s.units.find(u=>u.id===ship.id)!,options={teams:g.teams},route=ship.sailing?.route;const unsafe=!!route?.points.length&&!coastalVoyagePrefixSafe(s,seen,route,options),arrived=!!current&&Math.hypot(ship.x-current.waypoint.x,ship.y-current.waypoint.y)<=5&&ship.order.type==='idle';
   if(!current||unsafe||arrived){
    if(unsafe)issuePlayerCommand(g,'p0',{type:'stop',unitIds:[ship.id]});
    const fresh=snapshotGame(g),hull=fresh.units.find(u=>u.id===ship.id)!,plan=planCoastalVoyage(fresh,hull,goal,options);events.push({tick:g.tick,unsafe,arrived,position:{x:ship.x,y:ship.y},hp:ship.hp,plan:plan&&{proof:plan.proof,waypoint:plan.waypoint,points:plan.proof==='prefix'?plan.prefix.length:plan.reference.length,legs:plan.legs.length}});
    if(!plan){outcome='blocked-query';break;}current=plan;issuePlayerCommand(g,'p0',{type:'move',unitIds:[ship.id],...plan.waypoint,avoidCombat:true});
   }
   if(count%300===0){const row={tick:g.tick,x:ship.x,y:ship.y,hp:ship.hp,proof:current?.proof,waypoint:current?.waypoint,partial:route?.partial};rows.push(row);console.log(JSON.stringify({name,...row}));}
  }
  stepGame(g);
  if(Math.hypot(ship.x-goal.x,ship.y-goal.y)<=5&&ship.order.type==='idle'){outcome='arrived';break;}
  if(ship.hp<hp){outcome='damaged';break;}
 }
 if(!g.units.includes(ship))outcome='ship-lost';
 const result={name,startTick,endTick:g.tick,outcome,hpBefore:hp,hpAfter:ship.hp,position:{x:ship.x,y:ship.y},goal,events,rows};results.push(result);writeFileSync(root+'/coastal-native-voyage-'+name+'.json',JSON.stringify({snapshot:snapshotGame(g),nextId:g.nextId,result},null,2));console.log(JSON.stringify({result}));
}
writeFileSync(root+'/coastal-native-voyage.json',JSON.stringify(results,null,2));
