import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {bootstrapGame,bootstrapMatches} from '../../src/ai/bootstrap_1/benchmark';
import {createAiMemoryProvider} from '../../src/ai/planner-context';
import {createBootstrapCommandPlanner} from '../../scripts/bootstrap_1-planner';
import {runAiGameLoop} from '../../src/ai/game-runner';
import {restoreSnapshotIntoGame,snapshotGame} from '../../src/shared/sim';
import {bootstrapPolicyContext} from '../../src/ai/bootstrap_1/policy';
import {coastalBombardment} from '../../src/ai/policy/coastal-bombardment';
import {coastalFireDisks,coastalFireSegmentClear,coastalVoyagePrefixSafe} from '../../src/ai/policy/coastal-voyage';
import {shoreFiringStation} from '../../src/shared/shore-fire';
import {outmatchingCoast} from '../../src/ai/policy/coastal-risk';
import {combatCapability} from '../../src/shared/combat-capabilities';
import {isEnemyOwner} from '../../src/ai/policy/ownership';
const output=process.argv[2]??'coastal-local-switch';
const root='.playtest/overseas-assault-20261015',base='summoner-safe-battery',report=JSON.parse(readFileSync(`${root}/${base}.json`,'utf8'));
const start=164400,match=bootstrapMatches(report.setup.seed,['sapphireArchipelago'],165000,false).find(m=>m.subject==='v9_summoner'&&m.side===0&&m.agents.p0!.race==='grove'&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!;
const frame=JSON.parse(readFileSync(`${root}/${base}.json.frames/${start}.json`,'utf8')),row=report.rows.find((r:any)=>r.tick===start),game=bootstrapGame(match),memory=createAiMemoryProvider();
restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);for(const[owner,p]of Object.entries(row.players))memory.set!(owner,(p as any).policy);
const planner=await createBootstrapCommandPlanner(memory),events:any[]=[],samples:any[]=[];const id='unit-p0-bombardShip-26580';
const commandPlanner:Parameters<typeof runAiGameLoop>[0]['commandPlanner']=context=>{
 const before=structuredClone(memory.get(context.owner)),entries=planner(context),{snapshot:s}=context,ship=s.units.find(u=>u.id===id)!;
 if(context.owner==='p0')for(const entry of entries.filter(e=>'unitIds'in e.command&&e.command.unitIds.includes(id))){
  const opts=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(before!),teams:s.teams});
  const bombardment=coastalBombardment(s,ship,s.buildings.filter(b=>b.owner==='p1'),opts),targetId=memory.get('p0')?.naval?.combat?.[id]?.targetId,target=[...s.units,...s.buildings].find(t=>t.id===targetId),station=target&&shoreFiringStation(s,ship,target),disks=coastalFireDisks(s,ship,opts);
  const attackers=s.units.filter(u=>isEnemyOwner(s,'p0',u.owner,opts)&&'targetId'in u.order&&u.order.targetId===id).map(u=>({id:u.id,order:u.order,distance:Math.hypot(u.x-ship.x,u.y-ship.y)}));
  const event={tick:s.tick,command:entry.command,scriptId:entry.scriptId,ship:{x:ship.x,y:ship.y,hp:ship.hp,order:ship.order},routeSafe:coastalVoyagePrefixSafe(s,ship,ship.sailing?.route,opts),targetId,station:station&&{...station,fireClear:coastalFireSegmentClear(station,station,disks),outmatched:outmatchingCoast(s,'p0',ship,station,opts).map(u=>u.id)},bombardment:bombardment&&{...bombardment,target:{id:bombardment.target.id,kind:bombardment.target.kind}},attackers};events.push(event);console.log(JSON.stringify(event));
  if(entry.command.type==='attackMove'&&!events.some(e=>e!==event&&e.command.type==='attackMove'))writeFileSync(`${root}/${output}-first.json`,JSON.stringify({snapshot:s,nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,owner==='p0'?before:memory.get(owner)])),event}));
 }
 return entries;
};
const result=runAiGameLoop({...match,game,commandPlanner},{onStep:({game})=>{if(game.tick%15!==0)return;const s=snapshotGame(game),ship=s.units.find(u=>u.id===id)!;const opts=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(memory.get('p0')!),teams:s.teams});samples.push({tick:s.tick,x:ship.x,y:ship.y,hp:ship.hp,order:ship.order,routeSafe:coastalVoyagePrefixSafe(s,ship,ship.sailing?.route,opts),route:ship.sailing?.route});}});
writeFileSync(`${root}/${output}.json`,JSON.stringify({provenance:{base,start,end:game.tick,head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),diff:execFileSync('git',['diff'],{encoding:'utf8'}),note:'Short changed-code full-AI diagnostic, not match result; both original saved policy memories restored; frozen v5 retained'},events,samples,snapshot:result.snapshot,nextId:game.nextId},null,2));console.log(JSON.stringify({complete:true,start,end:game.tick,events:events.length,samples:samples.length}));
