import {readFileSync,writeFileSync} from 'node:fs';
import {planVoyageRoute,planShipRoute,shipPoseAt,headingDifference,hullPassageClear,type ShipPose} from '../../src/shared/ship-navigation';
import {shipProfile} from '../../src/shared/ship-geometry';
import {polygonRadius,pointSegmentDistanceSquared} from '../../src/shared/navigation-math';
import {routeClearsDisks} from '../../src/shared/route-selection';
import {combatCapability} from '../../src/shared/combat-capabilities';
import {unitMover} from '../../src/shared/catalog';
import {isInCabin} from '../../src/shared/ship-cabin';
import {shoreFiringStation} from '../../src/shared/shore-fire';
const root='.playtest/overseas-assault-20261015',path=process.argv[2]??root+'/summoner-battery-muster.json.frames/163200.json';
const frame=JSON.parse(readFileSync(path,'utf8')),s=frame.snapshot,ship=s.units.find((u:any)=>u.id==='unit-p0-bombardShip-26580');
const target=s.buildings.find((b:any)=>b.id==='building-p1-farm-1082');
const goal=shoreFiringStation(s,ship,target)!;
const radius=polygonRadius(shipProfile(ship)!.hull),from:ShipPose={x:ship.x,y:ship.y,heading:ship.sailing.heading};
const threats=[...s.units.filter((u:any)=>u.hp>0&&unitMover(u.kind)==='land'&&!isInCabin(u)&&u.owner!==ship.owner&&combatCapability(s,u).armed),...s.buildings.filter((b:any)=>b.hp>0&&b.owner!==ship.owner&&b.attackDamage>0)];
const disks=threats.map((u:any)=>({x:u.x,y:u.y,radius:Math.max(150,'order'in u?combatCapability(s,u).range:u.attackRange)+160+radius,id:u.id}));
let calls=0;
const arcExtra=(a:ShipPose,b:ShipPose)=>{
 const turn=Math.abs(headingDifference(a.heading,b.heading));
 if(!turn)return 0;
 // shipPoseAt preserves only valid curved/pivot metadata. Its middle pose
 // reveals the actual centre sagitta; R theta²/8 bounds that full arc.
 const mid=shipPoseAt(a,b,.5),chordMid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};
 const sagitta=Math.hypot(mid.x-chordMid.x,mid.y-chordMid.y);
 if(!sagitta)return 0;
 const denom=1-Math.cos(turn/2);
 return denom>1e-12?sagitta/denom*turn*turn/8+1e-5:sagitta+1e-5;
};
const clear=(a:ShipPose,b:ShipPose)=>{calls++;const extra=arcExtra(a,b);return routeClearsDisks([a,b],extra?disks.map(d=>({...d,radius:d.radius+extra})):disks);};
const metrics=(points:ShipPose[],origin=from)=>{let a=origin;let clearAll=true,terrainAll=true;const samples=[];for(const b of points){clearAll&&=clear(a,b);terrainAll&&=hullPassageClear(s.map,ship,a,b);for(let i=0;i<=8;i++){const p=shipPoseAt(a,b,i/8);samples.push(p);}a=b;}return{clearAll,terrainAll,length:points.reduce((v,b,i)=>v+Math.hypot(b.x-(points[i-1]??origin).x,b.y-(points[i-1]??origin).y),0),minSampleClearance:Math.min(...samples.flatMap(p=>disks.map(d=>Math.hypot(p.x-d.x,p.y-d.y)-d.radius)))};};
console.log(JSON.stringify({tick:s.tick,ship:from,goal,radius,threats:disks.length,startThreats:disks.filter(d=>Math.hypot(from.x-d.x,from.y-d.y)<=d.radius),goalThreats:disks.filter(d=>Math.hypot(goal.x-d.x,goal.y-d.y)<=d.radius)}));
const started=Date.now(),plan=planVoyageRoute(s.map,ship,{x:goal.x,y:goal.y},clear,100000);
const old=ship.sailing.route?.points??[];const info={tick:s.tick,path,goal,radius,disks,calls,elapsedMs:Date.now()-started,oldMetrics:metrics(old),plan:{...plan,metrics:metrics(plan.points)}};
writeFileSync(root+'/coastal-route-query.json',JSON.stringify(info,null,2));
console.log(JSON.stringify({calls,elapsedMs:Date.now()-started,oldMetrics:info.oldMetrics,partial:plan.partial,points:plan.points.length,last:plan.points.at(-1),metrics:info.plan.metrics}));
// Query the existing physical planner for ordinary move destinations. These
// do not inject a route or change terrain/physics. Every returned segment is
// independently checked against the same static hazard corridor.
const {shipRouteTraffic}=await import('../../src/shared/ship-avoidance');
const marks=[{x:3792,y:7952},{x:3504,y:7952},{x:3300,y:7750}];
const ordinary=[];
for(const mark of marks){
 const probe={...ship,order:{type:'move',...mark,avoidCombat:true},orderQueue:[],sailing:{...ship.sailing,route:undefined}};
 const units=s.units.map((u:any)=>u===ship?probe:u),traffic=shipRouteTraffic(s.map,probe,units);
 const started=Date.now(),route=planVoyageRoute(s.map,probe,mark,traffic,100000);
 ordinary.push({mark,partial:route.partial,elapsedMs:Date.now()-started,points:route.points,metrics:metrics(route.points)});
}
const final={...info,ordinary};writeFileSync(root+'/coastal-route-query.json',JSON.stringify(final,null,2));
console.log(JSON.stringify({ordinary:ordinary.map(({points,...r})=>({...r,points:points.length,last:points.at(-1)}))}));

const firstLeg=ordinary[0],arrival=firstLeg.points.at(-1)!;const second=[];
for(const speed of [0,ship.sailing.speed]){
 const probe={...ship,x:arrival.x,y:arrival.y,order:{type:'move',x:goal.x,y:goal.y,avoidCombat:true},orderQueue:[],sailing:{...ship.sailing,heading:arrival.heading,speed,route:undefined}};
 const units=s.units.map((u:any)=>u===ship?probe:u),traffic=shipRouteTraffic(s.map,probe,units);
 const route=planVoyageRoute(s.map,probe,{x:goal.x,y:goal.y},traffic,100000);
 second.push({speed,partial:route.partial,points:route.points,metrics:metrics(route.points,arrival)});
}
writeFileSync(root+'/coastal-route-query.json',JSON.stringify({...final,second},null,2));
console.log(JSON.stringify({second:second.map(({points,...r})=>({...r,points:points.length,last:points.at(-1)}))}));

const {advanceShipRouteSearch}=await import('../../src/shared/ship-navigation');
const state:any={phase:'prepare'};let slices=0,searchResult;const searchStarted=Date.now(),beforeCalls=calls;
while(!searchResult && slices++<1000)searchResult=advanceShipRouteSearch(s.map,ship,{x:goal.x,y:goal.y},clear,100000,true,state);
const search={visited:state.visited,phase:state.phase,slices,partial:searchResult?.partial,trafficCalls:calls-beforeCalls,elapsedMs:Date.now()-searchStarted};
writeFileSync(root+'/coastal-route-query.json',JSON.stringify({...final,second,search},null,2));console.log(JSON.stringify({search}));
