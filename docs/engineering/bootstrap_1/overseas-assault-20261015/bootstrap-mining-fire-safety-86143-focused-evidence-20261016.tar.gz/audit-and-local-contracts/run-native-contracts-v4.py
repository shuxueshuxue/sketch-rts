from pathlib import Path
import subprocess,json,hashlib,datetime,resource,os,sys
C=Path('/workspace/sketch-rts-mining-fire-safety-8da-control')
D=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-contracts-20261016')
stage=sys.argv[1]
assert stage in ['terrain-old1','candidate19','existing3','final-tsc']
assert C.resolve()==C
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()=='8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d'
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=[p for base in ['src','scripts','tools','data'] if (C/base).exists() for p in (C/base).rglob('*') if p.is_file()]
paths += [C/p for p in ['package.json','package-lock.json','tsconfig.json','frozen-policy.json'] if (C/p).is_file()]
pre={str(p.relative_to(C)):sha(p.read_bytes()) for p in paths}
helper=C/'src/ai/bootstrap_1/mining-fire.ts'; proposed=helper.read_bytes()
recordPath=D/(stage+'-run.json')
assert not recordPath.exists(), 'Never overwrite prior run'
maximum=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text())
fs=os.statvfs(D);disk=fs.f_bavail*fs.f_frsize
record={'classification':'Constructed native contracts / existing native regression contracts / compiler only. No real normal match or new ordinary0.', 'stage':stage,'spawned':False,'pre':{'atUTC':now(),'headroom':maximum-current,'disk':disk,'requiredMemory':2*1024**3,'requiredDisk':256*1024**2,'events':Path('/sys/fs/cgroup/memory.events').read_text()},'sourceHashes':pre}
if maximum-current<2*1024**3 or disk<256*1024**2:
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
 (D/(stage+'-guard-'+stamp+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'guardBlocked':True,'stage':stage,'headroom':maximum-current,'disk':disk}),flush=True);sys.exit(75)
if stage=='final-tsc':
 argv=['node','--max-old-space-size=1024','/workspace/sketch-rts/node_modules/typescript/bin/tsc','--noEmit']
else:
 files=['src/ai/bootstrap_1/mining-range-entry.test.ts'] if stage=='terrain-old1' else ['src/ai/bootstrap_1/mining-building-fire-behavior.test.ts','src/ai/bootstrap_1/mining-fire.test.ts','src/ai/bootstrap_1/mining-range-entry.test.ts','src/ai/bootstrap_1/mining-building-fire-timing.test.ts'] if stage=='candidate19' else ['src/ai/bootstrap_1/mining-assignments.test.ts','src/ai/bootstrap_1/mining-job-defense.test.ts']
 argv=['node','--max-old-space-size=768','/workspace/sketch-rts/node_modules/vitest/vitest.mjs','run',*files,'--pool=forks','--poolOptions.forks.singleFork=true']
 if stage=='terrain-old1':argv+=['--testNamePattern','grass-to-mud']
 if stage=='existing3':argv+=['--testNamePattern','bootstrap_1 mining assignments|v9_archer/grove.*raid.*mirror=false']
record['argv']=argv
try:
 if stage=='terrain-old1': helper.write_bytes(Path('/tmp/bootstrap-mining-fire-safety-8da-20261016/pre-terrain-step-correction/mining-fire.ts').read_bytes())
 record['actualSourceHashes']={str(p.relative_to(C)):sha(p.read_bytes()) for p in paths}
 with (D/(stage+'.log')).open('wb') as log:
  proc=subprocess.Popen(argv,cwd=C,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(D)})
  record.update(spawned=True,actualPID=proc.pid,startedAtUTC=now());recordPath.write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'started':stage,'pid':proc.pid,'headroom':maximum-current,'disk':disk}),flush=True)
  code=proc.wait()
 record['post']={'atUTC':now(),'exit':code,'peakChildRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'events':Path('/sys/fs/cgroup/memory.events').read_text(),'actualSourceUnchanged':record['actualSourceHashes']=={str(p.relative_to(C)):sha(p.read_bytes()) for p in paths}}
finally:
 if stage=='terrain-old1':helper.write_bytes(proposed)
 record['proposalRestoredExact']=pre=={str(p.relative_to(C)):sha(p.read_bytes()) for p in paths}
 recordPath.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'finished':stage,'post':record.get('post'),'proposalRestoredExact':record['proposalRestoredExact']}),flush=True)
