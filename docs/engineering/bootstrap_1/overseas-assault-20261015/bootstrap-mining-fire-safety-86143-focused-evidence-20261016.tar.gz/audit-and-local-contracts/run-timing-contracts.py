from pathlib import Path
import subprocess, json, hashlib, datetime, resource, os, sys
C=Path('/workspace/sketch-rts-mining-fire-safety-8da-control')
D=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-contracts-20261016')
D.mkdir(parents=True,exist_ok=True)
stage=sys.argv[1]
assert stage in ['old-timing3','candidate-timing3']
assert C.resolve()==C
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()=='8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d'
recordPath=D/(stage+'-run.json')
assert not recordPath.exists(), 'Do not overwrite a prior stage'
tracked=['src/ai/bootstrap_1/mining-assignments.ts','src/ai/bootstrap_1/mining-job-defense.ts','src/ai/bootstrap_1/policy.ts','src/ai/policy/core.ts']
watch=tracked+['src/ai/bootstrap_1/mining-fire.ts','src/ai/bootstrap_1/mining-building-fire-behavior.test.ts','src/ai/bootstrap_1/mining-fire.test.ts','src/ai/bootstrap_1/mining-range-entry.test.ts','src/ai/bootstrap_1/mining-building-fire-timing.test.ts']
sha=lambda b:hashlib.sha256(b).hexdigest()
proposal={f:(C/f).read_bytes() for f in watch}
proposalHashes={f:sha(b) for f,b in proposal.items()}
manifest=D/(stage+'-proposal-source.json')
manifest.write_text(json.dumps(proposalHashes,indent=2)+'\n')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
maxmem=int(Path('/sys/fs/cgroup/memory.max').read_text())
current=int(Path('/sys/fs/cgroup/memory.current').read_text())
events=Path('/sys/fs/cgroup/memory.events').read_text()
fs=os.statvfs(D);disk=fs.f_bavail*fs.f_frsize
record={'classification':'Singleworker contract stage; old tracked source only in this inactive independent candidate is restored in finally. No real match Game or planner replay. Native range-entry contracts create constructed scenes only.','stage':stage,'pre':{'atUTC':now(),'current':current,'max':maxmem,'headroom':maxmem-current,'events':events,'diskPath':str(D),'diskAvailable':disk,'requiredHeadroomBytes':2*1024**3,'requiredDiskBytes':256*1024**2,'heapMiB':512,'proposalHashes':proposalHashes},'spawned':False}
recordPath.write_text(json.dumps(record,indent=2)+'\n')
if maxmem-current<2*1024**3 or disk<256*1024**2:
 print(json.dumps({'guardBlocked':True,'stage':stage,'headroom':maxmem-current,'disk':disk}),flush=True)
 sys.exit(3)
files=['src/ai/bootstrap_1/mining-building-fire-timing.test.ts']
if stage=='candidate-timing3':files+=['src/ai/bootstrap_1/mining-assignments.test.ts','src/ai/bootstrap_1/mining-job-defense.test.ts']
argv=['node','--max-old-space-size=512','/workspace/sketch-rts/node_modules/vitest/vitest.mjs','run',*files,'--pool=forks','--poolOptions.forks.singleFork=true']
if stage=='candidate-timing3':argv+=['--testNamePattern','actual11565|actual11745|actual12285|bootstrap_1 mining assignments|v9_archer/grove.*raid.*mirror=false']
try:
 if stage=='old-timing3':
  for f in tracked:(C/f).write_bytes(subprocess.check_output(['git','-C',str(C),'show','HEAD:'+f]))
 record['actualSourceHashes']={f:sha((C/f).read_bytes()) for f in watch}
 record['argv']=argv
 with (D/(stage+'.log')).open('wb') as log:
  proc=subprocess.Popen(argv,cwd=C,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(D)})
  record['spawned']=True;record['actualPID']=proc.pid;record['startedAtUTC']=now()
  recordPath.write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'started':stage,'pid':proc.pid,'headroom':maxmem-current,'disk':disk}),flush=True)
  code=proc.wait()
 record['post']={'atUTC':now(),'exit':code,'peakChildRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'events':Path('/sys/fs/cgroup/memory.events').read_text(),'actualStageHashesUnchanged':all(sha((C/f).read_bytes())==h for f,h in record['actualSourceHashes'].items())}
finally:
 if stage=='old-timing3':
  for f in tracked:(C/f).write_bytes(proposal[f])
 record['proposalRestoredExact']={f:sha((C/f).read_bytes())==h for f,h in proposalHashes.items()}
 recordPath.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'finished':stage,'post':record.get('post'),'allProposalRestored':all(record['proposalRestoredExact'].values())}),flush=True)
