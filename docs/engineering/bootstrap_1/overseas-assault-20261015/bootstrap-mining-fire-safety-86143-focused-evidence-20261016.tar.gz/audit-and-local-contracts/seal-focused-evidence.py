from pathlib import Path
import json,hashlib,tarfile,io,datetime,stat
P=Path('/tmp/bootstrap-mining-fire-safety-8da-20261016');O=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016');R=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-reconstruct-11400-12300-20261016');A=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-prelaunch-standard1507-20261016');V=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-contracts-20261016');K=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016')
report=json.loads((O/'report.json').read_text());assert report['end']==12600 and not report['naturalComplete']and report['sourcePost']['head']=='86143dafab28180e5ff055639dd4f5561f96081d'
archive=Path('/workspace/.playtest/bootstrap-mining-fire-safety-86143-focused-evidence-20261016.tar.gz');assert not archive.exists()
selected={}
def add(p,name):
 assert p.is_file(),p
 assert name not in selected,name
 selected[name]=p
def tree(root,prefix):
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,prefix+'/'+str(p.relative_to(root)))
tree(O,'candidate-normal1200');tree(R,'original-reconstruction900');tree(A,'fixed1507-prelaunch');tree(P/'reconstruct-original-11400-12300','original900-driver-and-errors');tree(P/'candidate-focused-11400-12600-standard1507','candidate1200-driver');tree(P/'pre-terrain-step-correction','preserved-pre-terrain-test-source')
for p in sorted(P.iterdir()):
 if p.is_file():add(p,'audit-and-local-contracts/'+p.name)
for p in sorted(V.iterdir()):
 if p.is_file():add(p,'local-check-logs/'+p.name)
for t in [11400,12000,12600]:add(K/f'known-archer0-8da5.frames/{t}.json.gz',f'original-inputs/{t}.json.gz')
for name in ['known-archer0-8da5-runtime-source.json','known-archer0-8da5-source.tar.gz','known-archer0-8da5-frozen-source.tar.gz']:add(K/name,'original-fixed-source/'+name)
review=Path('/tmp/mining-focused-driver-independent-review-20261016')
if review.exists():tree(review,'independent-driver-readonly-review')
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for name,p in sorted(selected.items()):
 b=p.read_bytes();s=p.stat();rows.append({'path':name,'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sourcePath':str(p),'sourceWasSymlink':p.is_symlink()})
index={'classification':'Closed exact original900 + fixed86143 changed-code normal1200/local-contract/source/visual/ledger evidence only. No natural result, newordinary0 or bootstrap acceptance. Future prepared natural drivers deliberately not included.','sealedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'86143dafab28180e5ff055639dd4f5561f96081d','baseHead':'8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d','sourceStandardLivePayload':1507,'frozenFullPayload':497,'frozenApprovedManifest':184,'rulesVersion':2,'indexExcludesItself':True,'payloadCount':len(rows),'originalContainerUncommittedGap':'Unrecovered, not claimed copied','payloads':rows}
raw=(json.dumps(index,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz',dereference=True)as tar:
 for row in rows:tar.add(selected[row['path']],arcname=row['path'],recursive=False)
 info=tarfile.TarInfo('INDEX.json');info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();regular=[m for m in members if m.isfile()];assert len(regular)==len(rows)+1 and len(members)==len(regular)
 actual={m.name:(sha(tar.extractfile(m).read()),m.size)for m in regular};expected={r['path']:(r['sha256'],r['bytes'])for r in rows};expected['INDEX.json']=(sha(raw),len(raw));assert actual==expected
indexPath=archive.with_name('bootstrap-mining-fire-safety-86143-focused-INDEX.json');assert not indexPath.exists();indexPath.write_bytes(raw)
receipt={'classification':index['classification'],'archive':str(archive),'archiveSHA256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'payloadCount':len(rows),'regularCountIncludingINDEX':len(rows)+1,'payloadBytes':sum(r['bytes']for r in rows),'everyPayloadHashAndBytesVerified':True,'index':str(indexPath),'indexSHA256':sha(raw),'source':index['sourceHead'],'currentNaturalTail':'Prepared/guard75, not started, not included in closed archive.','originalContainerUncommittedGap':index['originalContainerUncommittedGap']};out=archive.with_name('bootstrap-mining-fire-safety-86143-focused-DELIVERY.json');assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
