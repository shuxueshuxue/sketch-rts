from pathlib import Path
import json,subprocess,datetime,resource,os,hashlib
D=Path('/tmp/bootstrap-mining-fire-safety-8da-20261016');C=Path('/workspace/sketch-rts-mining-fire-safety-8da-control');rpath=D/'RENDER-RESOURCE.json';assert not rpath.exists()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();m=int(Path('/sys/fs/cgroup/memory.max').read_text());c=int(Path('/sys/fs/cgroup/memory.current').read_text());fs=os.statvfs('/workspace');disk=fs.f_bavail*fs.f_frsize
r={'classification':'Pure512 native drawWorld only: no Game/P0/query/step. Two actual saved frames, samefixed86143.','spawned':False,'pre':{'atUTC':now(),'headroom':m-c,'requiredHeadroom':1024**3,'disk':disk,'events':Path('/sys/fs/cgroup/memory.events').read_text()},'driverSHA256':hashlib.sha256((D/'render-actual-focused.mts').read_bytes()).hexdigest()}
if m-c<1024**3 or disk<256*1024**2:rpath.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
with (D/'render-actual-focused.log').open('xb')as log:
 p=subprocess.Popen(['node','--max-old-space-size=512','--import','tsx',str(D/'render-actual-focused.mts')],cwd=C,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':'/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-runtime-tmp-20261016'});r.update(spawned=True,actualPID=p.pid,startedAtUTC=now());rpath.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'started':p.pid,'pre':r['pre']}),flush=True);code=p.wait()
r['post']={'atUTC':now(),'exit':code,'peakChildRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'events':Path('/sys/fs/cgroup/memory.events').read_text()};rpath.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['post']),flush=True);raise SystemExit(code)
