import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {createCanvas} from '/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js';
import {installHeadlessCanvas} from '/workspace/sketch-rts-mining-fire-safety-8da-control/src/recorder/record.ts';
import {drawWorld} from '/workspace/sketch-rts-mining-fire-safety-8da-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/workspace/sketch-rts-mining-fire-safety-8da-control/src/client/unit-facing.ts';
installHeadlessCanvas();
const D='/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016';
const sha=(b:any)=>createHash('sha256').update(b).digest('hex');
mkdirSync(D+'/visual',{recursive:true});
for (const job of [{input:D+'/frames/11610-before-p0.json.gz',name:'actual11610-before-worker-withdrawal',cx:2200,cy:1000,zoom:.54},
{input:D+'/final.json.gz',name:'actual12600-after-worker-withdrawal',cx:2400,cy:1000,zoom:.60}]) {
 const raw=readFileSync(job.input),full=JSON.parse(gunzipSync(raw).toString()),before=sha(JSON.stringify(full));
 const width=1400,height=1100,view={x:job.cx-width/job.zoom/2,y:job.cy-height/job.zoom/2,width,height,zoom:job.zoom};
 const canvas=createCanvas(width,height);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot:full.snapshot,view,now:full.snapshot.tick*50,facing:new UnitFacingTracker(),
  labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
 if(sha(JSON.stringify(full))!==before)throw Error('Renderer changed full state');
 const png=canvas.toBuffer('image/png'),out=D+'/visual/'+job.name+'.png';writeFileSync(out,png,{flag:'wx'});
 writeFileSync(out+'.json',JSON.stringify({classification:'Actual fixed86143 normal3AI changed-code11400→12600 saved world rendered by its native drawWorld. No Game/P0/query/step/command, no geometry reconstruction or image edits.',sourceHead:'86143dafab28180e5ff055639dd4f5561f96081d',input:job.input,inputSHA256:sha(raw),tick:full.snapshot.tick,view,output:out,pngSHA256:sha(png),fullStateUnchanged:true},null,2));
 console.log(JSON.stringify({tick:full.snapshot.tick,out,pngSHA256:sha(png)}));
}
