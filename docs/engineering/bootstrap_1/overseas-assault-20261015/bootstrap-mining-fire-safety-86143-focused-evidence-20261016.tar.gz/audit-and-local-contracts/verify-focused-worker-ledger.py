from pathlib import Path
import json,gzip,math,hashlib,datetime
P=Path('/tmp/bootstrap-mining-fire-safety-8da-20261016')
O=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016')
R=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-reconstruct-11400-12300-20261016')
read=lambda p:json.loads(p.read_text())
rows=lambda p:[json.loads(l)for l in p.read_text().splitlines()if l]
audit=read(P/'WORKER-FIRE-AND-DEPOSIT-AUDIT.json');cash=read(P/'NATIVE-DEPOSIT-CASH-CONSERVATION.json');report=read(O/'report.json')
workers={r['tick']:{u['id']:u for u in r['workers']}for r in rows(O/'watched-workers.jsonl')}
original=json.loads(gzip.decompress(Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5.frames/11400.json.gz').read_bytes()))
initial={u['id']:u for u in original['snapshot']['units']if u['owner']=='p0'and u['kind']=='worker'}
for event in audit['allObservedDepositEvents']:
 t=event['tick'];i=event['id'];before=workers[t-1][i]if t-1 in workers else initial[i];after=workers[t][i]
 assert before['carryingGold']==event['rawGoldDropped']>0 and after['carryingGold']==0 and after['hp']>0
 assert after['order']['type']=='idle'or after['order']['type']=='mine'and after['order']['phase']=='toMine'
 batch=event['batch']
 if batch['origin']=='new-native-gather':
  g=batch['gatherTick'];b=workers[g-1][i]if g-1 in workers else initial[i];a=workers[g][i]
  assert b['order']['type']=='mine'and b['order']['phase']=='gather'and b['order']['timer']<=1
  assert a['order']['type']=='mine'and a['order']['phase']=='return'and a['carryingGold']==event['rawGoldDropped']
 else:assert batch['origin']=='initial-carried'and initial[i]['carryingGold']>0
for row in cash['allCreditRows']:
 assert row['exactCentEqual']and row['settledExpectedCredit']==row['actualCashPlusSpendCredit']
assert len(audit['allObservedDepositEvents'])==75 and audit['cashAccounting']['nativeRawDeposited']==750
assert audit['cashAccounting']['newRawDeposited']==720 and audit['cashAccounting']['initialCarriedRawDeposited']==30
assert cash['actualSettledCredit']==749.04 and not cash['mismatches']
assert len(audit['allP0PermanentDeaths'])==5
assert {d['id']for d in audit['allP0PermanentDeaths']}=={'unit-p0-horseArcher-3093','unit-p0-lancer-4266','unit-p0-lancer-1527','unit-p0-worker-2','unit-p0-worker-3'}
assert report['sourcePre']==report['sourcePost']and report['frozenPre']==report['frozenPost']and all(report['restored'].values())
assert report['referenceCoverage']['referenceComparedCount']==180 and report['referenceCoverage']['uncomparedTailPlanCount']==60
for k in ['snapshot','nextId','memories','setup']:
 a=json.loads(gzip.decompress((O/'frames/11610-before-p0.json.gz').read_bytes()))[k];b=json.loads(gzip.decompress((R/'frames/11610-before-p0.json.gz').read_bytes()))[k];assert a==b
checks={'all75NativeDropsAndBatchOrigins':True,'allNativeUpkeepCashCreditsExact':True,'permanentDeathUnique5':True,'firstDifferenceSameCompleteInput':True,'source1507Frozen497Manifest184Rules2PrePost':True,'original900ReferenceTailExplicit':True}
sourcePaths=[O/'report.json',O/'watched-workers.jsonl',O/'money-changes.jsonl',O/'native-deaths.jsonl',P/'WORKER-FIRE-AND-DEPOSIT-AUDIT.json',P/'NATIVE-DEPOSIT-CASH-CONSERVATION.json']
out=P/'FOCUSED-WORKER-LEDGER-VERIFICATION.json';assert not out.exists()
out.write_text(json.dumps({'classification':'Postlaunch readonly independent recomputation of saved native ledger relationships; no Game/P0/query/step. Not a win or original0.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in sourcePaths},'verifierSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps(checks))
