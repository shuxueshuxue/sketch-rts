from pathlib import Path
import json,os,subprocess,datetime,resource,hashlib
D=Path(__file__).parent;C=Path('/workspace/sketch-rts-mining-fire-safety-8da-control')
O=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016')
assert C.resolve()==C and not O.exists()
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()=='86143dafab28180e5ff055639dd4f5561f96081d'
assert subprocess.check_output(['git','-C',str(C),'status','--porcelain','--untracked-files=all'],text=True)==''
record=D/'LAUNCH-RESOURCE.json';assert not record.exists()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
maximum=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text());fs=os.statvfs('/workspace');disk=fs.f_bavail*fs.f_frsize
argv=['node','--max-old-space-size=768','--import','tsx',str(D/'candidate-focused.mts')]
r={'classification':'Fixed86143 candidate changed-code normal3AI focused11400→12600. Not original900/newordinary0/natural result.','spawned':False,'source':str(C),'head':'86143dafab28180e5ff055639dd4f5561f96081d','driverSHA256':hashlib.sha256((D/'candidate-focused.mts').read_bytes()).hexdigest(),'launcherSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'argv':argv,'pre':{'atUTC':now(),'headroom':maximum-current,'requiredHeadroom':2*1024**3,'diskPath':'/workspace','diskAvailable':disk,'requiredDisk':256*1024**2,'heapMiB':768,'events':Path('/sys/fs/cgroup/memory.events').read_text()}}
if maximum-current<2*1024**3 or disk<256*1024**2:
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');(D/('GUARD-'+stamp+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(75)
runtime=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-runtime-tmp-20261016');runtime.mkdir(exist_ok=True)
with (D/'native-candidate.log').open('xb') as log:
 proc=subprocess.Popen(argv,cwd=C,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(runtime),'GIT_OPTIONAL_LOCKS':'0'})
 r.update(spawned=True,actualPID=proc.pid,startedAtUTC=now());record.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'started':True,'pid':proc.pid,'pre':r['pre']}),flush=True);code=proc.wait()
r['post']={'atUTC':now(),'exit':code,'peakChildRSSKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'events':Path('/sys/fs/cgroup/memory.events').read_text()};record.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'finished':True,'post':r['post']}),flush=True);raise SystemExit(code)
