import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual as eq } from 'node:util';
import { NativeTelemetry } from './native-telemetry.ts';

// Prepared only. A guarded launcher must bind these exact bytes before execution.
const D = '/tmp/bootstrap-mining-fire-safety-8da-20261016/candidate-focused-11400-12600-standard1507';
const O = '/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016';
const preparation = JSON.parse(readFileSync(D + '/PREPARATION.json', 'utf8'));
const cap = JSON.parse(readFileSync(preparation.sourceManifest, 'utf8'));
const S = cap.root;
const bind = JSON.parse(readFileSync(D + '/DRIVER-BINDING.json', 'utf8'));
const expected = JSON.parse(gunzipSync(readFileSync(preparation.expectedStreams)).toString());
const raw = readFileSync(preparation.input), saved = JSON.parse(gunzipSync(raw).toString());
const original12600 = JSON.parse(gunzipSync(readFileSync(preparation.actual12600)).toString());
if (saved.snapshot.tick !== 11400 || original12600.snapshot.tick !== 12600) throw Error('Input/reference actual tick mismatch');
const sha = (b: any) => createHash('sha256').update(b).digest('hex');
const n = (v: any) => JSON.parse(JSON.stringify(v));
const load = (p: string) => import(pathToFileURL(S + '/' + p).href);
if (expected.sourceHead !== '8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d') throw Error('Original reference source mismatch');
if (process.cwd() !== S || existsSync(O) || sha(readFileSync(import.meta.filename)) !== bind.driverSHA256
  || sha(raw) !== preparation.inputSHA256) throw Error('Fixed cwd/new output/input/driver binding required');
for (const [p, h] of Object.entries(bind.boundFiles)) if (sha(readFileSync(p)) !== h) throw Error('Bound file changed: ' + p);
function verifySource() {
  const changed = cap.files.filter((f: any) => sha(readFileSync(S + '/' + f.path)) !== f.sha256).map((f: any) => f.path);
  const head = execFileSync('git', ['-C', S, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', S, 'status', '--porcelain', '--untracked-files=all'], { encoding: 'utf8' });
  if (changed.length || head !== cap.head || status) throw Error('Candidate fixed source drift');
  return { files: cap.files.length, changed, head, status };
}
const sourcePre = verifySource();
mkdirSync(O); mkdirSync(O + '/frames');
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runGameLoop }] = await Promise.all([
  load('src/shared/sim.ts'), load('src/ai/planner-context.ts'), load('scripts/bootstrap_1-planner.ts'), load('src/sdk/game-runner.ts'),
]);
const game = createGame('bareDuel'), memories = createAiMemoryProvider(), owners = Object.keys(saved.setup.agents);
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
for (const owner of owners) memories.set(owner, n(saved.memories[owner]));
const full = () => n({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null])), setup: saved.setup });
const initial = full(), restored = { world: eq(initial.snapshot, saved.snapshot), nextId: initial.nextId === saved.nextId,
  all3mem: eq(initial.memories, saved.memories), setupMetadataCopied: eq(initial.setup, saved.setup) };
writeFileSync(O + '/restore.json', JSON.stringify(restored, null, 2));
if (Object.values(restored).some(value => !value)) throw Error('Strict actual11400 restore mismatch');
function verifyFrozen() {
  const root = frozenPolicyRoot(), changed = Object.entries(cap.frozenFiles)
    .filter(([p, h]) => sha(readFileSync(root + '/' + p)) !== h).map(([p]) => p);
  if (changed.length || Object.keys(cap.frozenFiles).length !== 497 || frozenPolicyManifest.rulesVersion !== 2
    || Object.keys(frozenPolicyManifest.files).length !== 184 || frozenPolicyManifest.revision !== saved.setup.frozenRevision)
    throw Error('Frozen rules2 source changed');
  return { fullFiles: 497, manifestFiles: 184, rulesVersion: 2, revision: frozenPolicyManifest.revision, changed };
}
const frozenPre = verifyFrozen(), normal = await createBootstrapCommandPlanner(memories);
if (!eq(full(), initial)) throw Error('Planner setup mutated restored state');
const streams = ['commands', 'plans', 'native-hits', 'native-events', 'native-deaths', 'ship-losses', 'watched-workers', 'money-changes'];
for (const stream of streams) writeFileSync(O + '/' + stream + '.jsonl', '', { flag: 'wx' });
const emit = (stream: string, row: any) => appendFileSync(O + '/' + stream + '.jsonl', JSON.stringify(row) + '\n');
const telemetry = new NativeTelemetry(game, emit);
telemetry.hitIndex = expected.hitBase;
for (const [id, hit] of expected.lastHit) telemetry.lastHit.set(id, hit);
let commandCount = 0, planCount = 0, hitCount = 0;
let firstPlanDifference: any = null, equalPlanPrefixCount = 0, referenceComparedCount = 0, referenceDifferentCount = 0, uncomparedTailPlanCount = 0;
const money = () => n({ players: game.players, spent: game.match.stats.goldSpent });
let previousMoney = money();
function compareReferencePlan(plan: any) {
  const original = expected.streams.plans[planCount];
  if (!original) { uncomparedTailPlanCount++; return; }
  if (original.tick !== plan.tick || original.owner !== plan.owner) throw Error('Reference planner row identity mismatch');
  referenceComparedCount++;
  const same = eq(n(plan), original);
  if (!same) referenceDifferentCount++;
  if (!firstPlanDifference && !same) {
    firstPlanDifference = { classification: 'Changed-code candidate versus exact original8da reconstructed planner stream; not a new match.', tick: game.tick, index: planCount, actual: n(plan), original };
    writeFileSync(O + '/FIRST-PLAN-DIFFERENCE.json', JSON.stringify(firstPlanDifference, null, 2));
  } else if (!firstPlanDifference) equalPlanPrefixCount++;
}
const capture = (phase: string) => writeFileSync(O + '/frames/' + game.tick + '-' + phase + '.json.gz',
  gzipSync(JSON.stringify({ ...full(), checkpointStage: phase }) + '\n'));
game.observer = { hit: (attacker: any, target: any, damage: number, before: number) => {
  telemetry.hit(attacker, target, damage, before);
  // NativeTelemetry serializes this observation at the original hit callback.
  const hit = telemetry.lastHit.get(target.id);
  hitCount++;
} };
const classification = 'Changed-code mining-fire fixed candidate normal3AI focused11400→12600 from exact original8da complete world/id/all3mem. '
  + 'No manual commands or extra P0 query. Actual frozenv7/v8, normal resources and rules2 unchanged. '
  + 'A finite focused window, not ordinary0, natural match result or bootstrap acceptance.';
writeFileSync(O + '/launch.json', JSON.stringify({ classification, pid: process.pid, sourcePre, frozenPre, restored,
  input: preparation.input, inputSHA256: sha(raw), driverSHA256: bind.driverSHA256, sourceManifest: preparation.sourceManifest,
  commandBase: expected.commandBase, hitBase: expected.hitBase, setup: saved.setup }, null, 2));
capture('initial-before-p0');
const result = runGameLoop({ name: classification, game, agents: saved.setup.agents, thinkInterval: 15, maxTicks: 12600,
  commandPlanner: (context: any) => {
    telemetry.commandIndex = expected.commandBase + commandCount;
    if (context.owner === 'p0') capture('before-p0');
    const entries = normal(context), postMemories = Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null]));
    const plan = { tick: game.tick, owner: context.owner, entries, postMemories };
    emit('plans', plan); compareReferencePlan(plan); planCount++;
    return entries;
  } }, {
  onCommand(event: any) {
    telemetry.commandIndex = expected.commandBase + commandCount;
    const command = { index: telemetry.commandIndex, tick: game.tick, owner: event.owner, source: event.source,
      scriptId: event.scriptId, command: event.command, traceKind: 'SDK public-command attempt; transient skips also call onCommand' };
    emit('commands', command); commandCount++;
    telemetry.observe('after-command'); telemetry.commandIndex = expected.commandBase + commandCount;
  },
  beforeStep() { telemetry.commandIndex = null; telemetry.beforeStep(); },
  onStep() {
    telemetry.observe('after-step');
    emit('watched-workers', { tick: game.tick,
      workers: game.units.filter((unit: any) => unit.owner === 'p0' && unit.kind === 'worker'),
      projectiles: game.projectiles.filter((projectile: any) => game.units.some((unit: any) => unit.owner === 'p0'
        && unit.kind === 'worker' && unit.id === projectile.targetId)) });
    if (game.tick % 15 === 0) capture('after-step-before-p0');
    const currentMoney = money();
    if (!eq(currentMoney, previousMoney)) { emit('money-changes', { tick: game.tick, before: previousMoney, after: currentMoney,
      caution: 'Cash/spending observations, not automatic mining-income attribution; native bounties and other transfers require their own evidence.' }); previousMoney = currentMoney; }

  },
});
const final = full(); writeFileSync(O + '/final.json.gz', gzipSync(JSON.stringify({ ...final, checkpointStage: 'after-step-before-p0' }) + '\n'));
if (game.tick !== 12600 && !game.match.winner) throw Error('Focused endpoint mismatch');
const summarize = (snapshot: any) => ({ players: snapshot.players, stats: snapshot.match.stats,
  ownWorkers: snapshot.units.filter((u: any) => u.owner === 'p0' && u.kind === 'worker'),
  allHalls: snapshot.buildings.filter((b: any) => b.kind === 'townHall'),
  allMines: snapshot.resources.filter((r: any) => r.kind === 'goldMine') });
writeFileSync(O + '/ACTUAL-VERSUS-ORIGINAL-12600.json', JSON.stringify({classification, actual: summarize(final.snapshot),
  original: summarize(original12600.snapshot), caution: 'These trajectories deliberately differ in code after11400. Compare observed commands, hit, worker deaths, delivered gold and buildings; survival alone is not match victory.'}, null, 2));
const report = { classification, start: 11400, end: game.tick, sourcePre, sourcePost: verifySource(), frozenPre, frozenPost: verifyFrozen(),
  restored, commandCount, planCount, hitCount, equalPlanPrefixCount, firstPlanDifferenceTick: firstPlanDifference?.tick ?? null,
  referenceCoverage: { referencePlanCount: expected.streams.plans.length, referenceStart: 11400,
    referenceLastPlanTick: expected.streams.plans.at(-1)?.tick, referenceEndAfterStep: 12300,
    referenceComparedCount, referenceDifferentCount, uncomparedTailPlanCount,
    caution: 'Reference streams cover only original900; null first difference cannot imply equality of the unreferenced12300→12600 tail.' },
  setupCaution: 'setupMetadataCopied is copied metadata equality; engine restore evidence is strict snapshot/nextId/all3mem equality.',
  elapsedMs: result.elapsedMs, cpuMs: result.cpuMs, telemetry: telemetry.summary(),
  inputUnchanged: sha(readFileSync(preparation.input)) === sha(raw), winner: game.match.winner, naturalComplete: !!game.match.winner,
  finiteFocusComplete: game.tick === 12600, finalSHA256: sha(readFileSync(O + '/final.json.gz')) };
writeFileSync(O + '/report.json', JSON.stringify(report, null, 2)); console.log(JSON.stringify(report));
