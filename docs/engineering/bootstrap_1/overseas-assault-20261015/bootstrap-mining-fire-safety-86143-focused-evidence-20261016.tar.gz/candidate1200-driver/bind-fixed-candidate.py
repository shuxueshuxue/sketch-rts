from pathlib import Path
import json,subprocess,hashlib,tarfile,io,datetime,os
C=Path('/workspace/sketch-rts-mining-fire-safety-8da-control');D=Path(__file__).parent
O=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-candidate-11400-12600-20261016')
A=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-prelaunch-standard1507-20261016')
oldPath=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5-runtime-source.json');old=json.loads(oldPath.read_text())
assert C.resolve()==C and not O.exists() and not A.exists()
head=subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip();assert head!=old['head']
status=subprocess.check_output(['git','-C',str(C),'status','--porcelain','--untracked-files=all'],text=True);assert status==''
V=Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-contracts-20261016')
for stage in ['candidate19','existing3','existing-raid1-v2','final-tsc']:
 r=json.loads((V/(stage+'-run.json')).read_text());assert r['post']['exit']==0 and r['post']['actualSourceUnchanged'] and r['proposalRestoredExact']
 for rel,h in r['sourceHashes'].items():assert hashlib.sha256((C/rel).read_bytes()).hexdigest()==h
sha=lambda b:hashlib.sha256(b).hexdigest()
originalPaths={r['path'] for r in old['files']}; delta=subprocess.check_output(['git','-C',str(C),'diff','--name-only',old['head'],head],text=True).splitlines()
paths=sorted(p for p in originalPaths|set(delta) if (C/p).is_file())
excluded=sorted(originalPaths-set(paths));assert not excluded and len(paths)==1507
files=[]
for rel in paths:
 b=(C/rel).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 expected=subprocess.check_output(['git','-C',str(C),'rev-parse',head+':'+rel],text=True).strip();assert actual==expected
 files.append({'path':rel,'sha256':sha(b),'bytes':len(b),'expectedGitBlob':expected,'actualGitBlob':actual,'matches':True})
rawFrozen=subprocess.check_output(['git','-C',str(C),'archive',old['frozenRevision'],'package.json','src/ai','src/sdk','src/shared'])
with tarfile.open(fileobj=io.BytesIO(rawFrozen),mode='r:') as tar:
 frozen={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
assert {p:sha(b) for p,b in frozen.items()}==old['frozenFiles'] and len(frozen)==497
manifest=C/'docs/engineering/bootstrap_1/frozen-policy.json';assert sha(manifest.read_bytes())==old['frozenManifestSHA256']
A.mkdir()
archive=A/'candidate-source.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for row in files:tar.add(C/row['path'],arcname='live/'+row['path'],recursive=False)
 for rel,b in sorted(frozen.items()):
  info=tarfile.TarInfo('frozen/'+rel);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
expectedArchive={'live/'+r['path']:(r['sha256'],r['bytes']) for r in files};expectedArchive.update({'frozen/'+p:(sha(b),len(b)) for p,b in frozen.items()})
with tarfile.open(archive,'r:gz') as tar:
 actualArchive={m.name:(sha(tar.extractfile(m).read()),m.size) for m in tar.getmembers() if m.isfile()}
assert expectedArchive==actualArchive
cap={'classification':'Fixed clean candidate prelaunch source/frozen archive; no Game/planner/step instantiated. Standard original1497 full selected scope plus10 new source/tests/fixtures; actual live1507/Gitblob checked.', 'root':str(C),'head':head,'gitStatus':status,'files':files,'excludedOriginalScopePaths':excluded,'originalScope':str(oldPath),'frozenFiles':old['frozenFiles'],'frozenManifestSHA256':old['frozenManifestSHA256'],'frozenRevision':old['frozenRevision'],'rulesVersion':2,'frozenManifestFiles':old['frozenManifestFiles'],'sourceArchive':str(archive),'sourceArchiveSHA256':sha(archive.read_bytes()),'sourceArchiveBytes':archive.stat().st_size,'archivePayloadCount':len(expectedArchive),'archiveReadbackVerified':True,'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
capPath=A/'candidate-runtime-source.json';capPath.write_text(json.dumps(cap,indent=2)+'\n')
inputPath=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5.frames/11400.json.gz')
expectedStreams=D.parent/'reconstruct-original-11400-12300/original-expected-streams-v2.json.gz'
prep={'sourceManifest':str(capPath),'input':str(inputPath),'inputSHA256':sha(inputPath.read_bytes()),'actual12600':'/workspace/.playtest/bootstrap-next-root-known-archer0-20261016/known-archer0-8da5.frames/12600.json.gz','expectedStreams':str(expectedStreams),'expectedStreamsSHA256':sha(expectedStreams.read_bytes())}
prepPath=D/'PREPARATION.json';assert not prepPath.exists();prepPath.write_text(json.dumps(prep,indent=2)+'\n')
driver=D/'candidate-focused.mts'
bound=[prepPath,capPath,archive,inputPath,Path(prep['actual12600']),expectedStreams,D/'native-telemetry.ts',D/'native-ledger.ts',Path(__file__)]
bind={'classification':'Prelaunch binding only; strict source and support payloads required before actual Game.', 'driverSHA256':sha(driver.read_bytes()),'boundFiles':{str(p):sha(p.read_bytes()) for p in bound}}
(D/'DRIVER-BINDING.json').write_text(json.dumps(bind,indent=2)+'\n');print(json.dumps({'head':head,'sourceFiles':len(files),'frozen':len(frozen),'sourceManifest':str(capPath),'sourceArchiveSHA256':cap['sourceArchiveSHA256'],'driverSHA256':bind['driverSHA256']}))
