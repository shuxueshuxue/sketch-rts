from pathlib import Path
import json, hashlib, datetime, subprocess

D = Path('/tmp/bootstrap-mining-fire-safety-8da-20261016/reconstruct-original-11400-12300')
p = json.loads((D / 'PREPARATION-V2.json').read_text())
cap = json.loads(Path(p['sourceManifest']).read_text())
S = Path(cap['root'])
assert S.resolve() == S and S.is_absolute()
assert subprocess.check_output(['git', '-C', str(S), 'rev-parse', 'HEAD'], text=True).strip() == cap['head']
assert not subprocess.check_output(['git', '-C', str(S), 'status', '--porcelain', '--untracked-files=all']).strip()
assert not Path(p['output']).exists()
assert not (D / 'DRIVER-BINDING.json').exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
changed = [f['path'] for f in cap['files'] if sha((S / f['path']).read_bytes()) != f['sha256']]
assert not changed, changed
bound = [p['input'], p['actual12000'], p['expectedStreams'], p['sourceManifest'],
         str(D / 'PREPARATION-V2.json'), str(D / 'native-telemetry.ts'), str(D / 'native-ledger.ts')]
binding = {'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'classification': 'Prelaunch read/hash binding only; no Game, planner or step. Existing original8da source capsule reused by exact SHA, not a new ordinary0 source epoch.',
           'source': str(S), 'head': cap['head'], 'sourceFiles': len(cap['files']), 'sourceChanged': changed,
           'driverSHA256': sha((D / 'reconstruct.ts').read_bytes()),
           'boundFiles': {path: sha(Path(path).read_bytes()) for path in bound},
           'sourceArchive': cap['sourceArchive'], 'sourceArchiveSHA256': cap['sourceArchiveSHA256'],
           'frozenArchive': cap['frozenArchive'], 'frozenArchiveSHA256': cap['frozenArchiveSHA256'],
           'sourceCountsScope': 'Original manifest selection, without claiming equality to other control manifests.'}
(D / 'DRIVER-BINDING.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps({k: v for k, v in binding.items() if k != 'boundFiles'}, indent=2))
