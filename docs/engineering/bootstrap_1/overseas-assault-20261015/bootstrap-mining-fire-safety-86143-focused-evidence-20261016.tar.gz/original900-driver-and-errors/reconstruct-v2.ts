import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual as eq } from 'node:util';
import { NativeTelemetry } from './native-telemetry';

// Prepared only. A guarded launcher must bind these exact bytes before execution.
const D = '/tmp/bootstrap-mining-fire-safety-8da-20261016/reconstruct-original-11400-12300';
const O = '/workspace/.playtest/bootstrap-mining-fire-safety-8da-reconstruct-11400-12300-20261016';
const preparation = JSON.parse(readFileSync(D + '/PREPARATION-V2.json', 'utf8'));
const cap = JSON.parse(readFileSync(preparation.sourceManifest, 'utf8'));
const S = cap.root;
const bind = JSON.parse(readFileSync(D + '/DRIVER-BINDING-V2.json', 'utf8'));
const expected = JSON.parse(gunzipSync(readFileSync(preparation.expectedStreams)).toString());
const raw = readFileSync(preparation.input), saved = JSON.parse(gunzipSync(raw).toString());
const original12000 = JSON.parse(gunzipSync(readFileSync(preparation.actual12000)).toString());
const sha = (b: any) => createHash('sha256').update(b).digest('hex');
const n = (v: any) => JSON.parse(JSON.stringify(v));
const load = (p: string) => import(pathToFileURL(S + '/' + p).href);
if (expected.sourceHead !== cap.head) throw Error('Original stream/source revision mismatch');
if (process.cwd() !== S || existsSync(O) || sha(readFileSync(import.meta.filename)) !== bind.driverSHA256
  || sha(raw) !== preparation.inputSHA256) throw Error('Fixed cwd/new output/input/driver binding required');
for (const [p, h] of Object.entries(bind.boundFiles)) if (sha(readFileSync(p)) !== h) throw Error('Bound file changed: ' + p);
function verifySource() {
  const changed = cap.files.filter((f: any) => sha(readFileSync(S + '/' + f.path)) !== f.sha256).map((f: any) => f.path);
  const head = execFileSync('git', ['-C', S, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', S, 'status', '--porcelain', '--untracked-files=all'], { encoding: 'utf8' });
  if (changed.length || head !== cap.head || status) throw Error('Original fixed8da source drift');
  return { files: cap.files.length, changed, head, status };
}
const sourcePre = verifySource();
mkdirSync(O); mkdirSync(O + '/frames');
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runGameLoop }] = await Promise.all([
  load('src/shared/sim.ts'), load('src/ai/planner-context.ts'), load('scripts/bootstrap_1-planner.ts'), load('src/sdk/game-runner.ts'),
]);
const game = createGame('bareDuel'), memories = createAiMemoryProvider(), owners = Object.keys(saved.setup.agents);
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
for (const owner of owners) memories.set(owner, n(saved.memories[owner]));
const full = () => n({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null])), setup: saved.setup });
const initial = full(), restored = { world: eq(initial.snapshot, saved.snapshot), nextId: initial.nextId === saved.nextId,
  all3mem: eq(initial.memories, saved.memories), setup: eq(initial.setup, saved.setup) };
writeFileSync(O + '/restore.json', JSON.stringify(restored, null, 2));
if (Object.values(restored).some(value => !value)) throw Error('Strict actual11400 restore mismatch');
function verifyFrozen() {
  const root = frozenPolicyRoot(), changed = Object.entries(cap.frozenFiles)
    .filter(([p, h]) => sha(readFileSync(root + '/' + p)) !== h).map(([p]) => p);
  if (changed.length || Object.keys(cap.frozenFiles).length !== 497 || frozenPolicyManifest.rulesVersion !== 2
    || Object.keys(frozenPolicyManifest.files).length !== 184 || frozenPolicyManifest.revision !== saved.setup.frozenRevision)
    throw Error('Frozen rules2 source changed');
  return { fullFiles: 497, manifestFiles: 184, rulesVersion: 2, revision: frozenPolicyManifest.revision, changed };
}
const frozenPre = verifyFrozen(), normal = await createBootstrapCommandPlanner(memories);
if (!eq(full(), initial)) throw Error('Planner setup mutated restored state');
const streams = ['commands', 'plans', 'native-hits', 'native-events', 'native-deaths', 'ship-losses', 'watched-workers'];
for (const stream of streams) writeFileSync(O + '/' + stream + '.jsonl', '', { flag: 'wx' });
const emit = (stream: string, row: any) => appendFileSync(O + '/' + stream + '.jsonl', JSON.stringify(row) + '\n');
const telemetry = new NativeTelemetry(game, emit);
telemetry.hitIndex = expected.hitBase;
for (const [id, hit] of expected.lastHit) telemetry.lastHit.set(id, hit);
let commandCount = 0, planCount = 0, hitCount = 0;
let at12000: any = null;
function assertEqual(kind: string, index: number, actual: any, original: any) {
  if (!eq(n(actual), original)) {
    writeFileSync(O + '/FIRST-MISMATCH.json', JSON.stringify({ tick: game.tick, kind, index, actual: n(actual), original }, null, 2));
    throw Error('Original stream mismatch: ' + kind + '/' + index);
  }
}
const capture = (phase: string) => writeFileSync(O + '/frames/' + game.tick + '-' + phase + '.json.gz',
  gzipSync(JSON.stringify({ ...full(), checkpointStage: phase }) + '\n'));
game.observer = { hit: (attacker: any, target: any, damage: number, before: number) => {
  telemetry.hit(attacker, target, damage, before);
  // NativeTelemetry serializes this observation at the original hit callback.
  const hit = telemetry.lastHit.get(target.id);
  assertEqual('native-hits', hitCount, hit, expected.streams['native-hits'][hitCount]);
  hitCount++;
} };
const classification = 'Exact original8da normal3AI 11400→12300 reconstruction; no manual commands or extra P0 query. '
  + 'Only newly captured preP0 states become reconstructed evidence after raw commands/hits/plans and original12000 full closure. '
  + 'Not a new ordinary0, candidate result or whole-game acceptance.';
writeFileSync(O + '/launch.json', JSON.stringify({ classification, pid: process.pid, sourcePre, frozenPre, restored,
  input: preparation.input, inputSHA256: sha(raw), driverSHA256: bind.driverSHA256, sourceManifest: preparation.sourceManifest,
  commandBase: expected.commandBase, hitBase: expected.hitBase, setup: saved.setup }, null, 2));
capture('initial-before-p0');
const result = runGameLoop({ name: classification, game, agents: saved.setup.agents, thinkInterval: 15, maxTicks: 12300,
  commandPlanner: (context: any) => {
    telemetry.commandIndex = expected.commandBase + commandCount;
    if (context.owner === 'p0') capture('before-p0');
    const entries = normal(context), postMemories = Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null]));
    const plan = { tick: game.tick, owner: context.owner, entries, postMemories };
    emit('plans', plan); assertEqual('plans', planCount, plan, expected.streams.plans[planCount]); planCount++;
    return entries;
  } }, {
  onCommand(event: any) {
    telemetry.commandIndex = expected.commandBase + commandCount;
    const command = { index: telemetry.commandIndex, tick: game.tick, owner: event.owner, source: event.source,
      scriptId: event.scriptId, command: event.command, traceKind: 'SDK public-command attempt; transient skips also call onCommand' };
    emit('commands', command); assertEqual('commands', commandCount, command, expected.streams.commands[commandCount]); commandCount++;
    telemetry.observe('after-command'); telemetry.commandIndex = expected.commandBase + commandCount;
  },
  beforeStep() { telemetry.commandIndex = null; telemetry.beforeStep(); },
  onStep() {
    telemetry.observe('after-step');
    emit('watched-workers', { tick: game.tick,
      workers: game.units.filter((unit: any) => unit.owner === 'p0' && unit.kind === 'worker'),
      projectiles: game.projectiles.filter((projectile: any) => game.units.some((unit: any) => unit.owner === 'p0'
        && unit.kind === 'worker' && unit.id === projectile.targetId)) });
    if (game.tick % 15 === 0) capture('after-step-before-p0');
    if (game.tick === 12000) {
      const actual = full(); at12000 = { world: eq(actual.snapshot, original12000.snapshot), nextId: actual.nextId === original12000.nextId,
        all3mem: eq(actual.memories, original12000.memories), setup: eq(actual.setup, original12000.setup) };
      writeFileSync(O + '/ORIGINAL-12000-CLOSURE.json', JSON.stringify(at12000, null, 2));
      if (Object.values(at12000).some(value => !value)) throw Error('Original12000 full closure mismatch');
    }
  },
});
const final = full(); writeFileSync(O + '/final.json.gz', gzipSync(JSON.stringify({ ...final, checkpointStage: 'after-step-before-p0' }) + '\n'));
if (commandCount !== expected.streams.commands.length || planCount !== expected.streams.plans.length
  || hitCount !== expected.streams['native-hits'].length || game.tick !== 12300 || game.match.winner)
  throw Error('Original finite reconstruction stream/count/endpoint mismatch');
const report = { classification, start: 11400, end: game.tick, sourcePre, sourcePost: verifySource(), frozenPre, frozenPost: verifyFrozen(),
  restored, original12000Closure: at12000, commandCount, planCount, hitCount, elapsedMs: result.elapsedMs, cpuMs: result.cpuMs,
  inputUnchanged: sha(readFileSync(preparation.input)) === sha(raw), winner: game.match.winner, naturalComplete: false,
  finalSHA256: sha(readFileSync(O + '/final.json.gz')) };
writeFileSync(O + '/report.json', JSON.stringify(report, null, 2)); console.log(JSON.stringify(report));
