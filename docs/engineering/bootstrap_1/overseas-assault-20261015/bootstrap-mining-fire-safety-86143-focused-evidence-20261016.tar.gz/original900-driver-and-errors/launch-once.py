from pathlib import Path
import json, os, subprocess, datetime, resource

D = Path('/tmp/bootstrap-mining-fire-safety-8da-20261016/reconstruct-original-11400-12300')
p = json.loads((D / 'PREPARATION-V2.json').read_text())
binding = json.loads((D / 'DRIVER-BINDING.json').read_text())
record = D / 'LAUNCH-RESOURCE.json'
assert not record.exists() and not Path(p['output']).exists()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
memmax = int(Path('/sys/fs/cgroup/memory.max').read_text())
current = int(Path('/sys/fs/cgroup/memory.current').read_text())
fs = os.statvfs('/workspace')
disk = fs.f_bavail * fs.f_frsize
argv = ['node', '--max-old-space-size=768', '--import', 'tsx', str(D / 'reconstruct.ts')]
r = {'classification': 'Unique authorized original8da normal3AI finite900 reconstruction, not a new match or candidate outcome.',
     'pre': {'atUTC': now(), 'memoryMax': memmax, 'memoryCurrent': current, 'headroom': memmax-current,
             'requiredHeadroom': 2*1024**3, 'outputDisk': '/workspace', 'diskAvailable': disk,
             'requiredDisk': 256*1024**2, 'heapMiB': 768, 'events': Path('/sys/fs/cgroup/memory.events').read_text()},
     'spawned': False, 'argv': argv, 'cwd': binding['source']}
record.write_text(json.dumps(r, indent=2) + '\n')
if memmax-current < 2*1024**3 or disk < 256*1024**2:
    print(json.dumps(r)); raise SystemExit(3)
runtimeTmp = Path('/workspace/.playtest/bootstrap-mining-fire-safety-8da-runtime-tmp-20261016')
runtimeTmp.mkdir(exist_ok=True)
with (D / 'native-original.log').open('xb') as log:
    proc = subprocess.Popen(argv, cwd=binding['source'], stdout=log, stderr=subprocess.STDOUT,
                            env={**os.environ, 'TMPDIR': str(runtimeTmp), 'GIT_OPTIONAL_LOCKS': '0'})
    r['spawned'] = True; r['actualPID'] = proc.pid; r['startedAtUTC'] = now()
    record.write_text(json.dumps(r, indent=2) + '\n')
    print(json.dumps({'started': True, 'pid': proc.pid, 'pre': r['pre']}), flush=True)
    code = proc.wait()
r['post'] = {'atUTC': now(), 'exit': code, 'peakChildRSSKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
             'events': Path('/sys/fs/cgroup/memory.events').read_text()}
record.write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps({'finished': True, 'post': r['post']}), flush=True)
raise SystemExit(code)
