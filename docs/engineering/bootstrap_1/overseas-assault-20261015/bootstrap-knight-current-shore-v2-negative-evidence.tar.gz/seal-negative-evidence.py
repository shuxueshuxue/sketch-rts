import json,pathlib,hashlib,subprocess,tarfile,io,gzip,shutil
from datetime import datetime,timezone
p=pathlib.Path(__file__).resolve().parent
prefix=p/'knight-current-shore-v2'
load=lambda q:json.loads(pathlib.Path(q).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda q,v:pathlib.Path(q).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
cap=load(str(prefix)+'-runtime-source.json');source=pathlib.Path(cap['sourceRoot'])
git=lambda *a:subprocess.check_output(['git','-C',str(source),*a])
assert str(source)=='/tmp/sketch-rts-assault-current-shore-control'
assert git('rev-parse','HEAD').decode().strip()==cap['baseCommit']=='89f463046a34a35e443d362e03e3a583f42bdc8f'
assert not git('status','--porcelain','--untracked-files=normal').strip()
allhashes=cap['runtimeHashes']|cap['supportingDataHashes']
mismatch=[n for n,h in allhashes.items()if not(source/n).exists()or sha((source/n).read_bytes())!=h]
assert not mismatch
assert sha(pathlib.Path(cap['inputReport']).read_bytes())==cap['inputReportSHA256']
assert sha(pathlib.Path(cap['inputFrame']).read_bytes())==cap['inputFrameSHA256']
assert sha(pathlib.Path(cap['sourceArchive']).read_bytes())==cap['sourceArchiveSHA256']
manifest=source/'docs/engineering/bootstrap_1/frozen-policy.json'
assert sha(manifest.read_bytes())==cap['frozenManifestSha256']
frozen=load(manifest)
with tarfile.open(cap['sourceArchive'],'r:gz')as t:
 for n,h in frozen['files'].items():assert sha(t.extractfile('frozen/'+n).read())==h
report=load(str(prefix)+'.json');inputframe=load(cap['inputFrame']);before=inputframe['snapshot']
rows=report['rows'];assert len(rows)==20 and [r['tick']for r in rows]==list(range(55260,56401,60))
checks=[];enemy= {b['id']:b for b in before['buildings']if b['owner']=='p1'}
minhp={n:b['hp'] for n,b in enemy.items()};missing=[]
for r in rows:
 fpath=pathlib.Path(str(prefix)+f'.json.frames/{r["tick"]}.json');f=load(fpath)
 assert f['snapshot']['tick']==r['tick']and isinstance(f['nextId'],int)
 assert set(r['players'])=={'p0','p1'}and all(isinstance(v['policy'],dict)for v in r['players'].values())
 checks.append({'tick':r['tick'],'nextId':f['nextId'],'worldFileSHA256':sha(fpath.read_bytes()),'allMemoriesSHA256':sha(json.dumps({o:v['policy']for o,v in r['players'].items()},sort_keys=True,separators=(',',':')).encode())})
 bmap={b['id']:b for b in f['snapshot']['buildings']}
 for n in enemy:
  if n in bmap:minhp[n]=min(minhp[n],bmap[n]['hp'])
  else:missing.append({'tick':r['tick'],'id':n})
last=load(str(prefix)+'.json.frames/56400.json')['snapshot']
old=load('/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary.json.frames/56400.json')['snapshot']
assert last['match']['winner']is None and last['match']['endedAtTick']is None
assert last['match']['stats']['unitsLost']['p0']==5
assert old['match']['stats']['unitsLost']['p0']==7
assert last['match']['stats']['unitsKilled']['p0']==0
assert last['match']['stats']['buildingsDestroyed']['p0']==0
corpses=[c for c in last['corpses']if c['owner']=='p0'];assert len(corpses)==5 and all(c.get('deck')for c in corpses)
post={'classification':'Fixed89f changed-code55200 focused1200tick bothAI. Notordinary0, notfullmatch, notacceptance.','createdAtUtc':datetime.now(timezone.utc).isoformat(),'sourceFilesVerified':len(allhashes),'sourceMismatches':mismatch,'commit':cap['baseCommit'],'gitStatusClean':True,'frozenFilesVerified':len(frozen['files']),'manifestSHA256':cap['frozenManifestSha256'],'unchangedInputReportSHA256':cap['inputReportSHA256'],'unchangedInputFrameSHA256':cap['inputFrameSHA256'],'checkpoints':checks,'initialNextId':inputframe['nextId'],'finalNextId':checks[-1]['nextId'],'completeSamples':len(rows),'result':report['result'],'nativeMatch':last['match']}
dump(str(prefix)+'-postflight.json',post)
assessment={'classification':post['classification'],'verdict':'Negative. Do not merge or extend to a fullmatch on this evidence.','originalSource':cap['originalOrdinaryCommit'],'candidateSource':cap['baseCommit'],'interval':[55200,56400],'candidatePermanentDeaths':corpses,'candidateOwnLost':5,'originalSameTickOwnLost':7,'candidateOwnKills':0,'originalSameTickOwnKills':old['match']['stats']['unitsKilled']['p0'],'candidateEnemyBuildingsDestroyed':0,'originalSameTickEnemyBuildingsDestroyed':old['match']['stats']['buildingsDestroyed']['p0'],'sampledEnemyOpeningBuildingHPDeclines':[{'id':n,'initialHP':enemy[n]['hp'],'minimumSampledHP':h}for n,h in minhp.items()if h<enemy[n]['hp']],'sampledEnemyOpeningBuildingsMissing':missing,'buildingDamageLimit':'These 60tick saves show sampled HP only. No destroyed building does not prove no transient HP damage between samples.','landingEvidence':'0 own land military found on original enemy landmass in all20samples; all5actual deaths have native corpse.deck; viewed actual56400client shows heavycrew still aboard. No claim of exact intermediate unload absence without per-tick replay.','deployedCandidateStatus':'All observed hulls retain a distant goal and original heavycrew never establishes sampled land combat.','sampledFailureFacts':['55260 both near sailing boats admitted: direct352.80, sea371.2, original near2448,6576; futureplacements6+11valid, currentplacementsundefined.','55320 direct442.6 but sea492.8 exceeds existing450; no admitted cohort, destination now1936,5936. Switch only bounded55260..55320, not exactnative stage.','55380 sea428.8 admits again, but current placements still undefined and mission already heading for farther north goal.','No sampled enemy-shore deployment.5deaths cannot be treated as a successful approach even though original has7 atsame56400.'],'unprovenNextHypothesis':'Retaining an admitted cohort destination across temporary physical dispersion may avoid far-beach churn, while retaining original strict450/body/requiredforce gates at actual deployment. Requires exactnative stage proof before furtherproduction edits.','limits':['Whole6f80 ordinary0 separately reached native victory135692 with43permanentdeaths and12enemyunits stillalive. Neither this candidate norv1 produced that result.','Original6f80 firstattack diagnosed separately with exactnormalbothAI replay; its actual risky intermediate approach remains unresolved.','No main/rules3/4 changes, no opponent/resource/seed modifications.','Original broken-container uncommitted source remains unrecovered.']}
dump(str(prefix)+'-negative-assessment.json',assessment)
for f in ['/tmp/bootstrap-assault-current-shore-v2-fixed-source-tests.log','/tmp/bootstrap-assault-current-shore-v2-fixed-source-tsc.log']:
 shutil.copy2(f,p/pathlib.Path(f).name)
client=p/'native-client-source-89f46304.tar.gz'
with gzip.GzipFile(filename=str(client),mode='wb',mtime=0)as z:z.write(git('archive','HEAD','src/client','src/recorder','src/shared'))
readme='''本包是89f46304从真实6f80普通0的55200完整世界/nextId/双方全部mem换码后的1200tick聚焦对照，绝不是新ordinary0、整局或泛化成绩。无人工游戏命令，双方正常AI；规则2和冻结184文件不变。
固定代码13/13 tests及tsc通过；实际游戏到56400正常exit0，5永久损失（原同刻7），0杀敌、0摧毁敌建筑，20个60tick样本均无敌岛实际陆战。实际56400原生画面已查看，重兵仍在甲板。两名少死不能判定修复有效，不合并，不用零登陆结果延长昂贵整局。
样本55260→55320间，原近岸任务由2448,6576切成1936,5936；55320直距442.6但海路492.8，超原450。该查询基于完整存档样本，并非精确naval.run入口，首变化tick/调用次序仍需针对性原生复核。所有原生当前落位查询仍不成立。
源胶囊、preflight、postflight、20全世界和双方全部mem、样本诊断、真实原生client画面和client源、测试/编译日志均在包中。原始ordinary0独立135692自然胜不归于此候选；其43永久损失、敌12单位残留与活动树sparse事故完整记录在已交原整局包。本候选运行前仅排除已提交重复非运行docs/art和docs/reviews，872源前后相同。
原容器未提交修改恢复缺口依旧保留。
'''
(p/'README.zh.txt').write_text(readme)
files={str(q.relative_to(p)):sha(q.read_bytes())for q in sorted(p.rglob('*'))if q.is_file()and not q.is_symlink()and'node_modules'not in q.parts and q.name!='INDEX.json'}
dump(p/'INDEX.json',{'algorithm':'SHA-256','files':files})
target=p.parent/'bootstrap-knight-current-shore-v2-negative-evidence.tar.gz'
with tarfile.open(target,'w:gz',compresslevel=6)as t:
 for n in list(files)+['INDEX.json']:t.add(p/n,arcname=n,recursive=False)
with tarfile.open(target,'r:gz')as t:
 index=json.loads(t.extractfile('INDEX.json').read())
 for n,h in index['files'].items():assert sha(t.extractfile(n).read())==h,n
archive={'path':str(target),'bytes':target.stat().st_size,'SHA256':sha(target.read_bytes()),'payloadsVerified':len(files),'commit':cap['baseCommit'],'sourceFilesVerified':len(allhashes),'verdict':'Negative focusedcontinuation; no merge, no ordinary0/fullmatch/acceptance claim.'}
dump(p.parent/'bootstrap-knight-current-shore-v2-negative-archive.json',archive)
print(json.dumps(archive,indent=2));print('enemySampledHPDeclines',assessment['sampledEnemyOpeningBuildingHPDeclines'])
