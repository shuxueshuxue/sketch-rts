import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const prefix=process.argv[2],source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const{setBuildingBodies,walkingDistance}=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
const{bootstrapPolicyContext}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/policy.ts').href);
const{readyAssaultConvoy,assaultBeachExposure}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/assault-beach.ts').href);
const{assaultExpedition}=await import(pathToFileURL(source+'/src/ai/policy/naval.ts').href);
const report=JSON.parse(readFileSync(prefix+'.json','utf8')),out=[];
for(const row of report.rows){
 const s=JSON.parse(readFileSync(prefix+'.json.frames/'+row.tick+'.json','utf8')).snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const context=bootstrapPolicyContext(s,'p0','v9_knight',{teams:s.teams,memory:structuredClone(row.players.p0.policy)});
 const target=s.buildings.find((b:any)=>b.id==='building-p1-shipyard-1016');
 const boats=s.units.filter((u:any)=>['unit-p0-carrier-4595','unit-p0-transport-1046'].includes(u.id));
 out.push({tick:s.tick,boats:boats.map((boat:any)=>{
  const m=context.memory.naval.ferries[boat.id],at=assaultBeachExposure(s,'p0',context,boat,m.to,target,true),planned=assaultBeachExposure(s,'p0',context,boat,m.to,target),other=boats.find((u:any)=>u.id!==boat.id);
  return {id:boat.id,xy:[boat.x,boat.y],phase:m.phase,to:m.to,approach:m.approach,order:boat.order,required:assaultExpedition(s,'p0',context,target).required,readyIds:readyAssaultConvoy(s,'p0',context,boat,target)?.map((u:any)=>u.id),otherDirect:other?Math.hypot(boat.x-other.x,boat.y-other.y):null,otherSeaRoad:other?walkingDistance(s.map,boat,other,'sea'):null,planned:planned?{passengers:planned.landed.length,guards:planned.guards.map((g:any)=>({id:g.id,owner:g.owner}))}:{undefined:true},current:at?{passengers:at.landed.length,guards:at.guards.map((g:any)=>({id:g.id,owner:g.owner}))}:{undefined:true}};
 })});
}
writeFileSync(prefix+'-deployment-feasibility.json',JSON.stringify({classification:'Read-only queries from actual60tick candidate snapshots and full p0memory. These are sample prethink queries, not captured exact naval.run boundaries or synthetic games.',out})+'\n');console.log(JSON.stringify(out.slice(0,5)));
