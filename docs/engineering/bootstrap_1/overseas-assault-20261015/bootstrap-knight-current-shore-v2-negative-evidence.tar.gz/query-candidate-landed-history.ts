import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const prefix=process.argv[2],source=JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).sourceRoot;
const{sameGround,setBuildingBodies}=await import(pathToFileURL(source+'/src/shared/terrain.ts').href);
const{unitMover}=await import(pathToFileURL(source+'/src/shared/catalog.ts').href);
const r=JSON.parse(readFileSync(prefix+'.json','utf8')),opening=JSON.parse(readFileSync(JSON.parse(readFileSync(prefix+'-runtime-source.json','utf8')).inputFrame,'utf8'));
const target=opening.snapshot.buildings.find((b:any)=>b.owner==='p1'&&b.kind==='townHall'),out=[];
for(const row of r.rows){
 const s=JSON.parse(readFileSync(prefix+'.json.frames/'+row.tick+'.json','utf8')).snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const own=s.units.filter((u:any)=>u.owner==='p0'&&!u.deck&&unitMover(u.kind)==='land'&&u.kind!=='worker'&&!u.expiresTick&&sameGround(s.map,u,target));
 if(own.length)out.push({tick:s.tick,units:own.map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,order:u.order})),enemyBuildings:s.buildings.filter((b:any)=>b.owner==='p1').length});
}
writeFileSync(prefix+'-landed-enemy-island-history.json',JSON.stringify({classification:'Read-only native sample history on the original enemy landmass. Each60tick save only bounds first arrival; does not invent exact unload tick.',enemyOpeningHall:target,firstObservedTick:out[0]?.tick,samples:out})+'\n');console.log(JSON.stringify({firstObservedTick:out[0]?.tick,firstObservedUnits:out[0]?.units.length,lastObservedUnits:out.at(-1)?.units.length}));
