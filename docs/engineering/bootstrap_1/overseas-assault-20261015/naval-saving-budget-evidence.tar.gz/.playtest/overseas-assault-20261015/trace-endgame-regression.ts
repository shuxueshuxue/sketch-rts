import { readFileSync, writeFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';
import { pathToFileURL } from 'node:url';
const [worktree, label, end = '99900', checkpoint = 'archer-99600-regression-checkpoint'] = process.argv.slice(2);
const load = (path: string) => import(pathToFileURL(worktree + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { runAiGameLoop }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { restoreSnapshotIntoGame, snapshotGame }] = await Promise.all([
  load('src/ai/bootstrap_1/benchmark.ts'), load('src/ai/game-runner.ts'), load('src/ai/planner-context.ts'),
  load('scripts/bootstrap_1-planner.ts'), load('src/shared/sim.ts')]);
const root = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const report = JSON.parse(readFileSync(root + '/' + checkpoint + '.json', 'utf8'));
const row = report.rows.at(-1), frame = JSON.parse(readFileSync(root + '/' + checkpoint + '.json.frames/' + row.tick + '.json', 'utf8'));
const match = bootstrapMatches(report.setup.seed, ['sapphireArchipelago'], Number(end), false)
  .find((m: any) => m.subject === report.subject && m.side === report.setup.side && isDeepStrictEqual(m.agents, report.setup.agents));
const game = bootstrapGame(match), memories = createAiMemoryProvider();
restoreSnapshotIntoGame(game, frame.snapshot, frame.nextId);
for (const [owner, player] of Object.entries(row.players) as [string, any][]) memories.set(owner, player.policy);
if (!isDeepStrictEqual(JSON.parse(JSON.stringify(snapshotGame(game))), frame.snapshot) || game.nextId !== frame.nextId) throw new Error('Restore mismatch');
const planner = await createBootstrapCommandPlanner(memories), decisions: any[] = [], frames: any[] = [];
runAiGameLoop({ ...match, game, commandPlanner: (context: any) => {
  const before = structuredClone(memories.get(context.owner));
  const entries = planner(context);
  decisions.push({ tick: context.snapshot.tick, owner: context.owner, entries: structuredClone(entries), before, after: structuredClone(memories.get(context.owner)) });
  return entries;
}}, { onStep: ({ game }: any) => {
  if (game.tick % 15 === 0 || game.match.winner) frames.push({ tick: game.tick, snapshot: snapshotGame(game), nextId: game.nextId,
    memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, structuredClone(memories.get(owner))])) });
}});
writeFileSync(root + '/' + label + '.json', JSON.stringify({ classification: 'Paired normal full-AI changed-code regression trace from the exact checkpoint world, nextId and both memories.', checkpoint, worktree, decisions, frames }));
console.log(JSON.stringify({ label, tick: game.tick, winner: game.match.winner, decisions: decisions.length, frames: frames.length }));
