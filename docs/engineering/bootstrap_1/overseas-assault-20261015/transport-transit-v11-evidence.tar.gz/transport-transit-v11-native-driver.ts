import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { createGame, restoreSnapshotIntoGame, snapshotGame, issuePlayerCommand, stepGame } from '../src/shared/sim';
import { setBuildingBodies } from '../src/shared/terrain';
import { bootstrapPolicyContext } from '../src/ai/bootstrap_1/policy';
import { planBootstrapNaval } from '../src/ai/bootstrap_1/expedition-recovery';
import { planBootstrapAbilities } from '../src/ai/bootstrap_1/weapon-targets';
const dir = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const source = JSON.parse(readFileSync(`${dir}/transport-transit-v11-source.json`, 'utf8'));
const sourceCheck = () => {
  const changed = Object.entries(source.sourceSha256).flatMap(([path, expected]) => createHash('sha256').update(readFileSync(path)).digest('hex') === expected ? [] : [path]);
  if (changed.length) throw Error(`Frozen v11 source changed: ${changed.join(',')}`);
  return { files: Object.keys(source.sourceSha256).length, changed };
};
for (const spec of [
  { label: 'warning-corridor', tick: 87300, duration: 1800, shipId: 'unit-p0-carrier-3824', version: 'v9_archer' },
  { label: 'pickup-handoff', tick: 92400, duration: 600, shipId: 'unit-p0-carrier-3824', version: 'v9_archer' },
  { label: 'return-handoff', tick: 173100, duration: 1800, shipId: 'unit-p0-carrier-50029', version: 'v9_summoner' },
] as const) {
  const inputPath = `.playtest/v11-inputs/${spec.tick}.json`, saved = JSON.parse(readFileSync(inputPath, 'utf8'));
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const mission = saved.policies.p0.naval.ferries[spec.shipId], initialPickup = structuredClone(mission.pickup);
  const requestedCrew = new Set<string>(mission.crewIds), originalDeck = new Set(game.units.filter(unit => unit.deck?.shipId === spec.shipId).map(unit => unit.id));
  const monitored = new Set([...requestedCrew, ...originalDeck]);
  const report: any = { classification: 'Frozen independent v11 tree. Public native naval + initial crew weapon commands only, all other units retain original native orders. All original p0/p1 policy memories retained. NOT full AI match, ordinary fresh opening, victory, or final bootstrap acceptance.',
    sourceManifest: 'transport-transit-v11-source.json', input: { path: inputPath, sha256: createHash('sha256').update(readFileSync(inputPath)).digest('hex') }, spec,
    sourceBefore: sourceCheck(), rows: [], commands: [], hits: [], planning: [] };
  const output = `${dir}/transport-transit-v11-${spec.label}`; mkdirSync(`${output}.json.frames`, { recursive: true });
  game.observer = { hit(attacker, target, damage, hpBefore) {
    if (attacker.id === spec.shipId || target.id === spec.shipId || monitored.has(attacker.id) || monitored.has(target.id))
      report.hits.push({ tick: game.tick, attacker: attacker.id, attackerKind: attacker.kind, target: target.id, targetKind: target.kind, damage, hpBefore });
  } };
  const plan = (game: ReturnType<typeof createGame>, policies: any) => {
    const snapshot = snapshotGame(game); setBuildingBodies(snapshot.map, [...snapshot.buildings, ...(snapshot.obstacles ?? [])]);
    const options = bootstrapPolicyContext(snapshot, 'p0', spec.version, { memory: policies.p0, teams: game.teams }), began = performance.now();
    const commands = [...planBootstrapNaval(snapshot, 'p0', options), ...planBootstrapAbilities(snapshot, 'p0', options).filter(command => command.type === 'cast' && monitored.has(command.unitId))];
    return { commands, ms: performance.now() - began };
  };
  let restored: ReturnType<typeof createGame> | undefined, restoredPolicies: any, firstAllBoarded: number | undefined;
  for (let elapsed = 0; elapsed <= spec.duration; elapsed++) {
    const active = saved.policies.p0.naval.ferries[spec.shipId], boat = game.units.find(unit => unit.id === spec.shipId);
    const allAboard = requestedCrew.size > 0 && [...requestedCrew].every(id => game.units.some(unit => unit.id === id && unit.deck?.shipId === spec.shipId));
    if (allAboard && firstAllBoarded === undefined) firstAllBoarded = game.tick;
    const pickupHandedOff = firstAllBoarded !== undefined && !!active && JSON.stringify(active.pickup) !== JSON.stringify(initialPickup);
    const returned = originalDeck.size > 0 && [...originalDeck].every(id => game.units.some(unit => unit.id === id && !unit.deck)) && !active;
    const success = spec.label === 'pickup-handoff' ? pickupHandedOff : spec.label === 'return-handoff' ? returned : false;
    const end = elapsed === spec.duration || success || !boat;
    if (elapsed % 150 === 0 || allAboard && firstAllBoarded === game.tick || end) {
      const snapshot = snapshotGame(game), row = { tick: game.tick, boat: boat && { x: boat.x, y: boat.y, hp: boat.hp, order: structuredClone(boat.order) },
        mission: structuredClone(active), crew: snapshot.units.filter(unit => monitored.has(unit.id)).map(unit => ({ id: unit.id, hp: unit.hp, x: unit.x, y: unit.y, deck: unit.deck, order: unit.order })),
        losses: snapshot.match.stats.unitsLost.p0, allAboard, firstAllBoarded, pickupHandedOff, returned, success };
      report.rows.push(row); writeFileSync(`${output}.json.frames/${game.tick}.json`, JSON.stringify({ snapshot, nextId: game.nextId, policies: saved.policies }));
      writeFileSync(`${output}.json`, JSON.stringify(report, null, 2)); console.log(JSON.stringify({ label: spec.label, tick: game.tick, boat: row.boat, success, firstAllBoarded }));
    }
    if (end) break;
    if (elapsed === 30) {
      const checkpoint = JSON.parse(JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId, policies: saved.policies }));
      restored = createGame('bareDuel'); restoreSnapshotIntoGame(restored, checkpoint.snapshot, checkpoint.nextId); restoredPolicies = checkpoint.policies;
    }
    if (game.tick % 15 === 0) {
      const result = plan(game, saved.policies); report.planning.push({ tick: game.tick, ms: result.ms }); report.commands.push({ tick: game.tick, owner: 'p0', commands: structuredClone(result.commands) });
      for (const command of result.commands) issuePlayerCommand(game, 'p0', command);
      if (restored) for (const command of plan(restored, restoredPolicies).commands) issuePlayerCommand(restored, 'p0', command);
    }
    stepGame(game);
    if (restored) {
      stepGame(restored);
      if (elapsed === 89) {
        report.restoredEqual = { snapshot: isDeepStrictEqual(JSON.parse(JSON.stringify(snapshotGame(game))), JSON.parse(JSON.stringify(snapshotGame(restored)))),
          nextId: game.nextId === restored.nextId, policies: isDeepStrictEqual(saved.policies, restoredPolicies) };
        if (!Object.values(report.restoredEqual).every(Boolean)) throw Error('Full JSON restore diverged');
        restored = undefined;
      }
    }
  }
  report.sourceAfter = sourceCheck(); writeFileSync(`${output}.json`, JSON.stringify(report, null, 2));
}
