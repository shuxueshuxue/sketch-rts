import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import type { Unit } from '../../shared/types';
import { transitRouteClear, transitRoutePrefixClear, planTransitLeg, transitFireDisks, transitMotionClear } from './transit-route';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import { planDirectVoyage } from '../../shared/ship-navigation';
import { shipRouteTraffic } from '../../shared/ship-avoidance';
import { shipMotionLimits } from '../../shared/ship-handling';
import { shipProfile } from '../../shared/ship-geometry';
import { SIM_TICKS_PER_SECOND } from '../../shared/time';

const saved = JSON.parse(gunzipSync(readFileSync(new URL('../bootstrap_1/fixtures/transport-transit-166800.json.gz', import.meta.url))).toString());
const source = saved.snapshot.units.find((unit: Unit) => unit.id === 'unit-p0-carrier-50029') as Unit;
const boat: Unit = { ...source, x: 0, y: 0, sailing: { ...source.sailing!, heading: 0 } };

it('keeps prefix coverage distinct from the full future route', () => {
  const points = [{ x: 100, y: 0, heading: 0 }, { x: 300, y: 0, heading: 0 }];
  const disks = [{ id: 'later', x: 250, y: 0, radius: 10 }];
  expect(transitRoutePrefixClear(boat, points, disks, 100)).toBe(true);
  expect(transitRouteClear(boat, points, disks)).toBe(false);
  expect(transitRoutePrefixClear(boat, points, disks, 150)).toBe(false);
  expect(transitRoutePrefixClear(boat, [], [], 100)).toBe(false);
  expect(transitRoutePrefixClear(boat, points.slice(0, 1), [], 101)).toBe(false);
});

it('checks the whole native curve rather than clipping its endpoint chord', () => {
  const points = [{ x: 100, y: 100, heading: Math.PI / 2, curvature: .01 }];
  const disks = [{ id: 'on-arc', x: Math.SQRT1_2 * 100, y: 100 - Math.SQRT1_2 * 100, radius: 4 }];
  expect(transitRoutePrefixClear(boat, points, disks, 10)).toBe(false);
});

it('does not certify unknown first motion at a thin provocation boundary', () => {
  const travel = shipMotionLimits(boat).speed * 15 / SIM_TICKS_PER_SECOND;
  expect(transitMotionClear(boat, [{ id: 'near', x: travel + 9, y: 0, radius: 10 }], 15)).toBe(false);
  expect(transitMotionClear(boat, [{ id: 'clear', x: travel + 11, y: 0, radius: 10 }], 15)).toBe(true);
});

it('rejects the real 170685 geometric leg whose native wind tack enters the dragon camp', () => {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/transit-wind-170685.json.gz', import.meta.url))).toString());
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), ship = snapshot.units.find(unit => unit.id === 'unit-p0-bombardShip-26580')!;
  const goal = { x: 5952, y: 6208 }, disks = transitFireDisks(snapshot, ship, {});
  const raw: Unit = { ...ship, order: { type: 'move', ...goal, avoidCombat: true }, orderQueue: [], sailing: { ...ship.sailing! } };
  delete raw.sailing!.route;
  const direct = planDirectVoyage(snapshot.map, raw, goal, shipRouteTraffic(snapshot.map, raw, snapshot.units.map(unit => unit.id === raw.id ? raw : unit)))!;
  expect(direct).toBeDefined();
  expect(transitRouteClear(ship, direct, disks)).toBe(true);
  const original = JSON.stringify(snapshot);
  expect(planTransitLeg(snapshot, ship, goal, disks)).toBeUndefined();
  expect(JSON.stringify(snapshot)).toBe(original);
}, 20000);

it('retains an enemy weapon ability range in the actual fire boundary', () => {
  const snapshot = structuredClone(saved.snapshot);
  const enemy = { ...snapshot.units.find((unit: Unit) => unit.kind === 'ballista')!, owner: 'p1' as const, id: 'enemy-bolt' };
  snapshot.units = [source, enemy]; snapshot.buildings = [];
  const actual = transitFireDisks(snapshot, source, {}, undefined, 0).find(disk => disk.id === enemy.id)!;
  expect(actual.radius).toBeGreaterThanOrEqual(472 + Math.max(...shipProfile(source)!.hull.map(point => Math.hypot(point.x, point.y))));
});
