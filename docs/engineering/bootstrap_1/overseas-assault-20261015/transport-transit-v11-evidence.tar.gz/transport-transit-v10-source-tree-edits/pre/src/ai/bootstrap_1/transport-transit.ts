import { routeClearsDisks, routePrefix } from '../../shared/route-selection';
import { shipProfile, type Point } from '../../shared/ship-geometry';
import { shipTrafficKey } from '../../shared/ship-avoidance';
import { MOVE_ORDER_ARRIVAL_RANGE } from '../../shared/movement-rules';
import type { ShipPose } from '../../shared/ship-navigation';
import { segmentWalkable, sameGround } from '../../shared/terrain';
import type { GameCommand, GameSnapshot, PlayerId, Unit } from '../../shared/types';
import { coastalFireSegmentClear, type CoastalFireDisk } from '../policy/coastal-voyage';
import { transitFireDisks, transitReference, planTransitLeg, transitRouteClear, transitDepartureCandidates,
  transitRoutePrefixClear, transitMotionClear, transitObservationDistance, transitPlanningKey } from '../policy/transit-route';
import type { AiPolicyContext } from '../policy/types';
import type { NavalPlanMemory } from '../memory';
import { navalServices } from '../policy/naval-services';
import { THINK_TICKS } from './mounted-micro';

type Mission = NonNullable<NavalPlanMemory['ferries']>[string];
/** This is the existing ferry's finite query, never a second ownership claim.
 * A coarse reference is not proof of native arrival. Only mark is validated
 * as a complete ordinary native leg; the next leg needs a fresh query. */
export type TransportTransitPlan = {
  key: string;
  goal: Point;
  candidates: Point[];
  next: number;
  referenceComplete: boolean;
  queryKey: string;
  pendingReference?: true;
  mark?: Point;
  continuation?: Point;
  entry?: Point;
  reference?: Point[];
  proposal?: { mark: Point; origin: ShipPose; end: ShipPose; points: ShipPose[]; base: ShipPose[]; inputKey: string;
    candidates: Point[]; next: number; pendingReference?: true; approved?: Point };
};

function legCandidates(snapshot: GameSnapshot, boat: Unit, reference: readonly Point[], disks: readonly CoastalFireDisk[]): Point[] {
  const length = shipProfile(boat)!.length;
  return routePrefix(boat, reference, length * 6).slice(1)
    .filter(point => Math.hypot(point.x - boat.x, point.y - boat.y) > MOVE_ORDER_ARRIVAL_RANGE
      && segmentWalkable(snapshot.map, boat, point, 'sea') && routeClearsDisks([boat, point], disks)).reverse();
}

/** The mark came from routePrefix, including its interpolated final point. */
function beyondMark(reference: readonly Point[], mark: Point): Point[] {
  for (let i = 0; i < reference.length; i++) {
    const end = reference[i]!;
    if (Math.hypot(end.x - mark.x, end.y - mark.y) < 1e-6) return reference.slice(i + 1);
    const previous = reference[i - 1];
    if (previous && Math.abs(Math.hypot(mark.x - previous.x, mark.y - previous.y) + Math.hypot(end.x - mark.x, end.y - mark.y)
      - Math.hypot(end.x - previous.x, end.y - previous.y)) < 1e-6) return reference.slice(i);
  }
  return [];
}

export function transportTransitDisks(snapshot: GameSnapshot, boat: Unit, mission: Mission, options: AiPolicyContext, warningMargin = 160, observationTicks = 0): CoastalFireDisk[] {
  const landing = snapshot.buildings.find(building => building.id === mission.targetId);
  return transitFireDisks(snapshot, boat, options, target => !!(mission.purpose === 'assault' && mission.phase === 'sailing'
    && target.owner !== 'neutral' && landing && sameGround(snapshot.map, landing, target)), warningMargin, observationTicks);
}

/** The ferry continues owning its hull and crew. While its finite query/mark
 * is active, ordinary public commands also cancel old implicit boarding
 * courses, and later board commands wait until the verified leg completes. */
export function planTransportTransit(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext, commands: GameCommand[], unavailable: ReadonlySet<string> = new Set()): GameCommand[] {
  const controlled = new Set<string>(), orders: GameCommand[] = [], releases: GameCommand[] = [];
  const services = navalServices(snapshot, owner, options).reserved;
  const boats = snapshot.units.filter(boat => boat.owner === owner && shipProfile(boat) && options.memory.naval?.ferries?.[boat.id]);
  const first = boats.length ? Math.floor(snapshot.tick / THINK_TICKS) % boats.length : 0;
  let built = false, probed = false;
  for (const boat of [...boats.slice(first), ...boats.slice(0, first)]) {
    const mission = options.memory.naval?.ferries?.[boat.id], profile = shipProfile(boat);
    const releaseHold = () => {
      if (mission?.transit && boat.order.type === 'hold' && !commands.some(command => 'unitIds' in command && command.unitIds.includes(boat.id)
        || 'unitId' in command && command.unitId === boat.id)) releases.push({ type: 'stop', unitIds: [boat.id] });
    };
    if (!mission || mission.purpose === 'creep' || boat.owner !== owner || !profile || !boat.sailing || unavailable.has(boat.id)
      || services.has(boat.id) || options.memory.naval?.outfit?.shipId === boat.id) {
      releaseHold(); if (mission) delete mission.transit; continue;
    }
    const goal = mission.phase === 'return' ? mission.from : mission.phase === 'sailing' ? mission.to : mission.pickup;
    if (!goal || Math.hypot(goal.x - boat.x, goal.y - boat.y) < 900) { releaseHold(); delete mission.transit; continue; }
    const disks = transportTransitDisks(snapshot, boat, mission, options, 160, THINK_TICKS);
    const exposure = transportTransitDisks(snapshot, boat, mission, options, 0);
    const intervalClear = transitMotionClear(boat, exposure, THINK_TICKS);
    const current = { x: boat.x, y: boat.y, heading: boat.sailing.heading };
    // Prevention is not an escape proof from fire that already contains us.
    // Preserve the live combat/retreat controller rather than call a stop safe.
    if (!coastalFireSegmentClear(current, current, exposure)) { releaseHold(); delete mission.transit; continue; }
    const key = `${mission.purpose}:${mission.phase}:${mission.targetId}:${goal.x}:${goal.y}`;
    let query = mission.transit;
    if (query && query.key !== key) { releaseHold(); delete mission.transit; query = undefined; }
    const route = boat.sailing.route;
    // An existing native prefix may safely establish a better departure pose.
    // The separate motion bound covers wind/traffic changes before next think,
    // including a fresh ordinary command which has no route yet.
    if (!query && intervalClear && (!route?.points.length
      || !route.partial && transitRouteClear(boat, route.points, disks)
      || transitRoutePrefixClear(boat, route.points, disks, transitObservationDistance(boat, THINK_TICKS)))) continue;
    const inputKey = transitPlanningKey(snapshot, boat);
    const queryKey = disks.map(disk => `${disk.id}:${Math.round(disk.x / 64)}:${Math.round(disk.y / 64)}:${Math.round(disk.radius)}`).join('|')
      + shipTrafficKey(boat, snapshot.units) + inputKey;
    if (query?.mark && (Math.hypot(query.mark.x - boat.x, query.mark.y - boat.y) <= MOVE_ORDER_ARRIVAL_RANGE
      || boat.order.type === 'idle' && boat.arrivedAt?.x === query.mark.x && boat.arrivedAt.y === query.mark.y)) {
      // Preserve the proved onward point across terrain seed rounding. The
      // actual arrival can be a fraction of a pixel off the planned endpoint;
      // rebuilding a shortest reference must not throw its valid leg away.
      query = { key, goal: { ...goal }, candidates: [], next: 0, referenceComplete: false, queryKey, pendingReference: true,
        ...(query.continuation ? { entry: query.continuation } : {}) };
    }
    if (query?.mark) {
      const following = boat.order.type === 'move' && boat.order.x === query.mark.x && boat.order.y === query.mark.y;
      if (following && intervalClear && route?.points.length && transitRouteClear(boat, route.points, disks)) { controlled.add(boat.id); continue; }
      // Do not reinstall a private route or assume an empty route is arrival.
      query = undefined;
    }
    if (!query || !query.proposal && query.next >= query.candidates.length && query.queryKey !== queryKey) {
      query = { key, goal: { ...goal }, candidates: [], next: 0, referenceComplete: false, queryKey, pendingReference: true };
    }
    if (query.pendingReference && !built) {
      built = true;
      const reference = transitReference(snapshot, boat, goal, disks);
      // Bound the geometric connector's swept rectangle as well as the A*
      // node count. Long trips advance through ordinary local legs.
      const candidates = [...(query.entry ? [query.entry] : []), ...legCandidates(snapshot, boat, reference.points, disks), ...transitDepartureCandidates(snapshot, boat, disks)];
      query = { key, goal: { ...goal }, candidates, next: 0, referenceComplete: reference.complete, queryKey, reference: reference.points };
    }
    mission.transit = query;
    controlled.add(boat.id);
    let accepted: Point | undefined;
    const proposal = query.proposal;
    if (proposal && (proposal.origin.x !== current.x || proposal.origin.y !== current.y || proposal.origin.heading !== current.heading
      || proposal.inputKey !== inputKey || !transitRouteClear(boat, proposal.points, disks) || !transitRouteClear(boat, proposal.base, disks))) {
      // A stop is public and can finish motion before the next think. A proof
      // from the previous pose cannot authorize a different departure.
      delete query.proposal;
    }
    if (!probed && query.proposal) {
      const proposal = query.proposal;
      const arrived: Unit = { ...boat, ...proposal.end, sailing: { ...boat.sailing, heading: proposal.end.heading, speed: 0 } };
      if (proposal.approved) {
        // Traffic may change during the lookahead. Re-prove this actual first
        // command immediately before sending it, within the same one-probe
        // budget. A changed arrival pose needs a new continuation query.
        probed = true;
        const fresh = planTransitLeg(snapshot, boat, proposal.mark, disks), end = fresh?.points.at(-1);
        if (fresh && end && JSON.stringify(end) === JSON.stringify(proposal.end)) {
          accepted = proposal.mark; query.continuation = proposal.approved; delete query.proposal;
        } else delete query.proposal;
      }
      if (!probed && proposal.pendingReference && !built) {
        built = true;
        const reference = transitReference(snapshot, arrived, goal, disks);
        proposal.candidates = legCandidates(snapshot, arrived, reference.points, disks);
        delete proposal.pendingReference;
      }
      const next = !probed && !proposal.pendingReference ? proposal.candidates[proposal.next] : undefined;
      if (next) {
        probed = true; proposal.next++;
        if (planTransitLeg(snapshot, arrived, next, disks)) proposal.approved = next;
      }
      if (!accepted && !proposal.approved && !proposal.pendingReference && proposal.next >= proposal.candidates.length) delete query.proposal;
    } else if (!probed && !query.pendingReference) {
      const mark = query.candidates[query.next];
      if (mark) {
        probed = true; query.next++;
        const leg = planTransitLeg(snapshot, boat, mark, disks), end = leg?.points.at(-1);
        if (end) {
          if (Math.hypot(mark.x - goal.x, mark.y - goal.y) < 900) accepted = mark;
          else {
            const arrived: Unit = { ...boat, ...end, sailing: { ...boat.sailing, heading: end.heading, speed: 0 } };
            // A safe arrival beside a disk can have no room for the next
            // forward turn. Prove a subsequent ordinary leg from the native
            // arrival heading before committing this mark. This is geometry
            // only; neither leg is installed as a private engine route.
            const remainder = beyondMark(query.reference ?? [], mark);
            const candidates = legCandidates(snapshot, arrived, remainder, disks);
            if (candidates.length || !remainder.length) query.proposal = { mark, origin: current, end, points: leg!.points, base: leg!.base,
              inputKey, candidates, next: 0,
              ...(!remainder.length ? { pendingReference: true as const } : {}) };
          }
        }
      }
    }
    if (accepted && intervalClear) {
      query.mark = accepted;
      orders.push({ type: 'move', unitIds: [boat.id], ...accepted, avoidCombat: true });
    } else if (boat.order.type !== 'hold' || boat.sailing.route?.points.length) orders.push({ type: 'holdPosition', unitIds: [boat.id] });
  }
  // Hold only the hull while querying. Shore board orders keep their ferry
  // ownership, but native ferryUnits approaches only idle hulls. A public stop
  // releases this hold when the normal boarding controller takes over again.
  return [...releases, ...commands.flatMap((command): GameCommand[] => {
    if (command.type === 'board' && controlled.has(command.transportId)) return [];
    if (!('unitIds' in command)) return [command];
    const unitIds = command.unitIds.filter(id => !controlled.has(id));
    return unitIds.length ? [{ ...command, unitIds }] : [];
  }), ...orders];
}
