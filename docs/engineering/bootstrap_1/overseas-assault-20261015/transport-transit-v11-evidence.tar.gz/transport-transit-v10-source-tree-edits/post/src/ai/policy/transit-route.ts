import { ABILITY_DEFS, UNIT_DEFS, unitMover } from '../../shared/catalog';
import { combatCapability } from '../../shared/combat-capabilities';
import { AUTO_ACQUIRE_RANGE } from '../../shared/sim';
import { polygonRadius } from '../../shared/navigation-math';
import { routeClearsDisks } from '../../shared/route-selection';
import { shipPassengers, shipProfile, type Point } from '../../shared/ship-geometry';
import { shipRouteTraffic } from '../../shared/ship-avoidance';
import { planVoyageRoute, hullPassageClear, voyageTurnRadius, type ShipPose } from '../../shared/ship-navigation';
import { planVoyageWindLeg, voyageCompanion } from '../../shared/ship-voyage-wind';
import { shipMotionLimits } from '../../shared/ship-handling';
import { SIM_TICKS_PER_SECOND } from '../../shared/time';
import { windAt } from '../../shared/wind-field';
import { isInCabin } from '../../shared/ship-cabin';
import { MOVE_ORDER_ARRIVAL_RANGE } from '../../shared/movement-rules';
import { isWalkable, segmentWalkable } from '../../shared/terrain';
import type { Building, GameSnapshot, PlayerId, Unit } from '../../shared/types';
import { coastalFireSegmentClear, type CoastalFireDisk } from './coastal-voyage';
import { isEnemyOwner, type TeamPolicyOptions } from './ownership';
const REFERENCE_BUDGET = 2048;

/** The next observation interval plus the native turn diameter and braking
 * distance. This is a route observation budget, not a new threat radius. */
export function transitObservationDistance(boat: Unit, ticks: number): number {
  const limits = shipMotionLimits(boat);
  return voyageTurnRadius(boat) * 2 + limits.speed * ticks / SIM_TICKS_PER_SECOND
    + limits.speed ** 2 / (2 * Math.max(1e-6, limits.acceleration)) + MOVE_ORDER_ARRIVAL_RANGE;
}

/** Bound every possible helm/traffic/wind path until the next think. Native
 * advanceShip shares this total translation budget, including pivot travel. */
export function transitMotionClear(boat: Unit, disks: readonly CoastalFireDisk[], ticks: number): boolean {
  const distance = shipMotionLimits(boat).speed * ticks / SIM_TICKS_PER_SECOND;
  return disks.every(disk => Math.hypot(boat.x - disk.x, boat.y - disk.y) > disk.radius + distance);
}

/** Environment and handling inputs for a staged proof. Live traffic is checked
 * again by the final native probe, without restarting the finite queue. */
export function transitPlanningKey(snapshot: GameSnapshot, boat: Unit): string {
  return JSON.stringify([windAt(snapshot.map, boat).key, boat.kind, boat.speed, boat.maxHp, boat.sailing?.load, boat.sailing?.balance,
    boat.sailing?.speed, boat.shipParts,
    [...snapshot.buildings, ...(snapshot.obstacles ?? [])].filter(body => body.hp > 0).map(body => [body.id, body.kind, body.x, body.y, body.radius])]);
}

/** Warning is early strategic clearance. An observation budget additionally
 * preserves room for any native helm change until the next AI observation;
 * zero warning/ticks gives the actual observed fire/provocation boundary. */
export function transitFireDisks(snapshot: GameSnapshot, boat: Unit, options: TeamPolicyOptions,
  ignoreThreat: (target: Unit | Building) => boolean = () => false, warningMargin = 160, observationTicks = 0): CoastalFireDisk[] {
  const profile = shipProfile(boat);
  if (!profile) return [];
  const crew = shipPassengers(snapshot.units, boat).filter(unit => !isInCabin(unit));
  const reach = Math.max(0, ...crew.filter(unit => combatCapability(snapshot, unit).armed).map(unit => Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange)),
    ...crew.flatMap(unit => UNIT_DEFS[unit.kind].abilities.flatMap(ability => {
      const def = ABILITY_DEFS[ability]; return def.behavior === 'weapon' ? [def.range] : [];
    })));
  return [...snapshot.units.filter(unit => unit.hp > 0 && unitMover(unit.kind) === 'land' && !isInCabin(unit)),
    ...snapshot.buildings.filter(building => building.hp > 0)]
    .filter(target => isEnemyOwner(snapshot, boat.owner as PlayerId, target.owner, options)
      && !ignoreThreat(target))
    .flatMap(target => {
      const gun = combatCapability(snapshot, target);
      const fireRange = 'order' in target ? Math.max(gun.range, ...UNIT_DEFS[target.kind].abilities.flatMap(ability => {
        const def = ABILITY_DEFS[ability]; return def.behavior === 'weapon' ? [def.range] : [];
      })) : gun.range;
      const provocation = target.owner === 'neutral' ? reach + target.radius + MOVE_ORDER_ARRIVAL_RANGE : 0;
      const exposure = Math.max(fireRange, provocation);
      // Native walking pace/statuses only reduce the observed land speed.
      // A deck target can also be carried by its current live platform.
      // This does not forecast a new cast, teleport, upgrade, or future order.
      const platform = 'order' in target && target.deck ? snapshot.units.find(unit => unit.id === target.deck!.shipId && shipProfile(unit)) : undefined;
      const targetSpeed = 'order' in target ? target.speed + (platform ? shipMotionLimits(platform).speed : 0) : 0;
      const observation = (shipMotionLimits(boat).speed + targetSpeed) * observationTicks / SIM_TICKS_PER_SECOND;
      return gun.armed ? [{ id: target.id, x: target.x, y: target.y, radius: polygonRadius(profile.hull)
        + Math.max(fireRange + warningMargin, provocation, exposure + observation) }] : [];
    });
}

/** Geometry only: the same sea terrain is queried, never changed to fake
 * blockers. Fixed expansions bound a reference; exhaustion means a prefix,
 * not that an island or a voyage is physically unreachable. */
export function transitReference(snapshot: GameSnapshot, start: Point, goal: Point, disks: readonly CoastalFireDisk[]) {
  const step = (snapshot.map.terrain?.cell ?? 32) * 4;
  const cols = Math.ceil(snapshot.map.width / step), count = cols * Math.ceil(snapshot.map.height / step);
  const point = (id: number) => ({ x: (id % cols + .5) * step, y: (Math.floor(id / cols) + .5) * step });
  const gap = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
  const clear = (a: Point, b: Point) => segmentWalkable(snapshot.map, a, b, 'sea') && routeClearsDisks([a, b], disks);
  const valid = new Int8Array(count), done = new Uint8Array(count), costs = new Float64Array(count).fill(Infinity);
  const parents = new Int32Array(count).fill(-1), heap: { id: number; cost: number; score: number }[] = [];
  const push = (id: number, cost: number) => {
    let index = heap.length; const item = { id, cost, score: cost + gap(point(id), goal) }; heap.push(item);
    while (index) { const parent = (index - 1) >> 1; if (heap[parent]!.score <= item.score) break; heap[index] = heap[parent]!; index = parent; }
    heap[index] = item;
  };
  const pop = () => {
    const first = heap[0]!, last = heap.pop()!; if (!heap.length) return first;
    let index = 0;
    while (index * 2 + 1 < heap.length) {
      let child = index * 2 + 1; if (child + 1 < heap.length && heap[child + 1]!.score < heap[child]!.score) child++;
      if (heap[child]!.score >= last.score) break; heap[index] = heap[child]!; index = child;
    }
    heap[index] = last; return first;
  };
  const okay = (id: number) => {
    if (id < 0 || id >= count) return false;
    if (!valid[id]) { const p = point(id); valid[id] = isWalkable(snapshot.map, p.x, p.y, 'sea') && routeClearsDisks([p, p], disks) ? 1 : -1; }
    return valid[id] === 1;
  };
  const seed = Math.floor(start.y / step) * cols + Math.floor(start.x / step);
  if (routeClearsDisks([start, start], disks)) for (let y = -1; y <= 1; y++) for (let x = -1; x <= 1; x++) {
    const id = seed + y * cols + x;
    if (okay(id) && clear(start, point(id))) { costs[id] = gap(start, point(id)); push(id, costs[id]!); }
  }
  let expanded = 0, end: number | undefined, best: number | undefined, complete = false;
  while (heap.length && expanded < REFERENCE_BUDGET) {
    const item = pop(); if (done[item.id] || item.cost !== costs[item.id]) continue;
    done[item.id] = 1; expanded++; const here = point(item.id);
    if (best === undefined || gap(here, goal) < gap(point(best), goal)) best = item.id;
    if (gap(here, goal) <= step * 1.5 && clear(here, goal)) { end = item.id; complete = true; break; }
    for (let y = -1; y <= 1; y++) for (let x = -1; x <= 1; x++) {
      if (!x && !y) continue;
      const id = item.id + y * cols + x;
      if (!okay(id) || done[id] || Math.abs(id % cols - item.id % cols) > 1) continue;
      const p = point(id), cost = item.cost + gap(here, p);
      if (cost >= costs[id]! || !clear(here, p)) continue;
      costs[id] = cost; parents[id] = item.id; push(id, cost);
    }
  }
  end ??= best;
  const points: Point[] = [];
  if (end !== undefined && gap(point(end), goal) + step < gap(start, goal)) {
    for (let id = end; id >= 0; id = parents[id]!) points.push(point(id));
    points.reverse(); if (complete) points.push(goal);
  }
  return { points, complete, expanded };
}

export function transitRouteClear(boat: Unit, points: readonly ShipPose[], disks: readonly CoastalFireDisk[]): boolean {
  if (!points.length) return false;
  let previous = { x: boat.x, y: boat.y, heading: boat.sailing?.heading ?? 0 };
  return points.every(point => { const clear = coastalFireSegmentClear(previous, point, disks); previous = point; return clear; });
}

/** Prove at least length of the existing native route, retaining each complete
 * curved segment. Chord length is a lower bound; missing coverage is unknown,
 * never a safe voyage. This does not plan or install an engine route. */
export function transitRoutePrefixClear(boat: Unit, points: readonly ShipPose[], disks: readonly CoastalFireDisk[], length: number): boolean {
  if (!points.length || !Number.isFinite(length) || length <= 0) return false;
  let previous = { x: boat.x, y: boat.y, heading: boat.sailing?.heading ?? 0 }, covered = 0;
  for (const point of points) {
    if (!coastalFireSegmentClear(previous, point, disks)) return false;
    covered += Math.hypot(point.x - previous.x, point.y - previous.y);
    if (covered >= length) return true;
    previous = point;
  }
  return false;
}

export function transitDepartureCandidates(snapshot: GameSnapshot, boat: Unit, disks: readonly CoastalFireDisk[]): Point[] {
  // A terrain road can start behind a forward-only hull. Its present heading
  // and the native nominal turn diameter give finite open-water departure
  // candidates; each still needs actual native first- and second-leg proof.
  const radius = voyageTurnRadius(boat), heading = boat.sailing!.heading;
  return [radius * 2, radius * 4].map(distance => ({ x: boat.x + Math.cos(heading) * distance, y: boat.y + Math.sin(heading) * distance }))
    .filter(point => segmentWalkable(snapshot.map, boat, point, 'sea') && routeClearsDisks([boat, point], disks));
}

export type TransitLegProof = { points: ShipPose[]; base: ShipPose[] };

/** One ordinary native search with budget 1024 plus the native wind suffix
 * with its own budget 1024. Unfinished traffic rejects without the executor's
 * terrain-only fallback. These are search budgets, not a wall-clock bound.
 * Neither partial result certifies arrival; no route is installed. */
export function planTransitLeg(snapshot: GameSnapshot, boat: Unit, goal: Point, disks: readonly CoastalFireDisk[]): TransitLegProof | undefined {
  const hull: Unit = { ...boat, order: { type: 'move', ...goal, avoidCombat: true }, orderQueue: [], sailing: { ...boat.sailing! } };
  delete hull.sailing!.route;
  const units = snapshot.units.map(unit => unit.id === boat.id ? hull : unit);
  const traffic = shipRouteTraffic(snapshot.map, hull, units);
  const ordinary = planVoyageRoute(snapshot.map, hull, goal, traffic, 1024, { terrainFallback: false });
  if (ordinary.partial) return;
  const direct = ordinary.points;
  const end = direct?.at(-1);
  const clear = (points: readonly ShipPose[]) => {
    if (!transitRouteClear(boat, points, disks)) return false;
    let previous = { x: boat.x, y: boat.y, heading: boat.sailing?.heading ?? 0 };
    return points.every(point => { const okay = hullPassageClear(snapshot.map, hull, previous, point); previous = point; return okay; });
  };
  if (!direct || !end || Math.hypot(end.x - goal.x, end.y - goal.y) > MOVE_ORDER_ARRIVAL_RANGE || !clear(direct)) return;
  const bearing = Math.atan2(goal.y - hull.y, goal.x - hull.x);
  const windTraffic = shipRouteTraffic(snapshot.map, hull, units.filter(unit => !voyageCompanion(hull, unit, goal, bearing, true)), Infinity);
  const wind = direct.some(point => point.pivot) ? undefined : planVoyageWindLeg(snapshot.map, hull, end, windTraffic, units, false, undefined, { terrainFallback: false });
  if (!wind) return { points: direct, base: direct };
  const finish = wind.points.at(-1);
  if (wind.kind === 'departure' || wind.partial || !finish || Math.hypot(finish.x - goal.x, finish.y - goal.y) > MOVE_ORDER_ARRIVAL_RANGE
    || !clear(wind.points)) return;
  return { points: wind.points, base: direct };
}

