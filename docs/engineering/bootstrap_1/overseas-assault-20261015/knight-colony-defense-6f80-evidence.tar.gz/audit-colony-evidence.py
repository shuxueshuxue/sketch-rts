import hashlib, json, shutil, tarfile
from pathlib import Path

out = Path('/tmp/knight-colony-defense-6f80')
source = Path('/tmp/sketch-rts-knight-6f80a-ordinary-control')
original = Path('/tmp/bootstrap-knight-6f80a-ordinary-20261015')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda n: json.loads((out / n).read_bytes())
report, native, queries, manifest = map(load, ['original-report-captured.json','native63600-64800.json','defense-ownership-query.json','original-runtime-source.json'])
(out / 'original-frames').mkdir(exist_ok=True)
joins = []
for tick in [62400,63600,64800,66000,67200,68400]:
    raw = (original / f'knight-6f80a-ordinary.json.frames/{tick}.json').read_bytes()
    (out / f'original-frames/{tick}.json').write_bytes(raw)
    frame, complete = json.loads(raw), load(f'complete-{tick}.json')
    row = next(row for row in report['rows'] if row['tick'] == tick)
    matches = {
        'world': frame['snapshot'] == complete['snapshot'],
        'nextId': frame['nextId'] == complete['nextId'],
        'bothFullPolicyMemories': complete['memories'] == {owner:row['players'][owner]['policy'] for owner in ['p0','p1']}
    }
    assert all(matches.values()), (tick,matches)
    joins.append({'tick':tick,'originalFrameSHA256':sha(raw),'combinedInputSHA256':sha((out/f'complete-{tick}.json').read_bytes()),'matches':matches})

for tail in ['launch.json','process.json','opening.json','opening-comparison.json','prelaunch-opening.ts']:
    shutil.copyfile(original / ('knight-6f80a-ordinary-'+tail), out / ('original-'+tail))
assert sha((out/'original-opening.json').read_bytes()) == manifest['openingSHA256']
runtime = {**manifest['runtimeHashes'], **manifest['supportingDataHashes']}
assert len(runtime) == 870
changes = [name for name,want in runtime.items() if sha((source/name).read_bytes()) != want]
assert not changes, changes
capsule = out / 'original-fixed-6f80-source-capsule.tar.gz'
assert sha(capsule.read_bytes()) == manifest['fullSourceArchiveSHA256']
with tarfile.open(capsule, 'r:gz') as tf:
    index = json.load(tf.extractfile('INDEX.json'))
    members = {m.name:m for m in tf.getmembers() if m.isfile()}
    assert set(members) == set(index['files']) | {'INDEX.json'}
    failures = [name for name,want in index['files'].items() if sha(tf.extractfile(name).read()) != want]
    assert not failures, failures
    assert len(index['files']) == 1370
    assert all(sha(tf.extractfile('live/'+name).read()) == want for name,want in runtime.items())
    frozen_bytes = tf.extractfile('frozen-policy.json').read()
    assert sha(frozen_bytes) == manifest['frozenManifestSha256']
    frozen = json.loads(frozen_bytes)
    assert frozen['rulesVersion'] == 2 and frozen['revision'] == manifest['frozenRevision']
    assert len(frozen['files']) == 184
    assert all(sha(tf.extractfile('frozen/'+name).read()) == want for name,want in frozen['files'].items())

assert all(native['restored'].values()) and all(native['equals'].values()) and not native['sourceChanges']
assert native['start'] == 63600 and native['end'] == 64800
assert all(row['snapshotUnchanged'] and row['storedBothMemoryUnchanged'] for row in queries['rows'])
ids = {'unit-p0-footman-'+str(i) for i in [7014,7020,7043,7155]}
evac = next(plan for plan in native['plans'] if plan['tick'] == 64605)
first_admission = evac['evacuationAdmission'][0]
damage = []
for label,after in [('before64605',False),('64605through64800',True)]:
    filtered = [h for h in native['hits'] if (h['tick'] >= 64605) == after]
    attacks = [h for h in filtered if h['sourceId'] in ids]
    incoming = [h for h in filtered if h['targetId'] in ids]
    damage.append({'window':label,'attackHitCount':len(attacks),'rawOutgoingDamageIncludingOverkill':sum(h['damage'] for h in attacks),'actualOutgoingHpRemoved':sum(min(h['before'],h['damage']) for h in attacks),'targetIds':sorted(set(h['targetId'] for h in attacks)),'receivedRawDamageIncludingOverkill':sum(h['damage'] for h in incoming),'actualReceivedHpRemoved':sum(min(h['before'],h['damage']) for h in incoming)})
tower = [h for h in native['hits'] if h['sourceId'] == 'building-p0-defenseTower-2001']
board = [e for e in native['issued'] if e['owner'] == 'p0' and e['command'].get('transportId') == 'unit-p0-transport-4873']
facts = {
  'classification':'Read-only failure diagnosis of actual true ordinary tick0 source6f80a game; this diagnostic restores63600 and runs only1200 native ticks. No policy changes, no manual commands, no duplicate fullgame.',
  'source':str(source), 'baseCommit':manifest['baseCommit'], 'setup':report['setup'],
  'originalReportCapturedAtResult':report['result'], 'originalReportSHA256':sha((out/'original-report-captured.json').read_bytes()),
  'fullInputJoins':joins,
  'sourceValidation':{'runtimeAndSupportingFiles':870,'changedFiles':changes,'capsuleSHA256':sha(capsule.read_bytes()),'capsuleAllPayloadsVerified':1370,'capsuleTotalEntries':1371,'frozenManifestEntriesVerified':184,'rulesVersion':frozen['rulesVersion'],'frozenRevision':frozen['revision'],'classification':'Post-run independent readback verification against the already existing original prelaunch manifest/capsule; not a newly invented prelaunch record.'},
  'nativeRestore':native['restored'],'nativeTerminalEqualsOriginal64800':native['equals'],'allQueriesOriginalWorldAndStoredBothMemoriesUnchanged':True,
  'firstNativeEvacuationTick':64605,'admissionSource':first_admission['source'],'firstAdmissionLocalStrength':first_admission['localStrength'],'firstAdmissionThreatStrength':first_admission['threatStrength'],'originalMargin':1.4,'firstAdmissionPassesOriginalMargin':first_admission['admitted'],
  'guardsBeforeFirstEvacuation':[{'id':u['id'],'hp':u['hp'],'maxHp':u['maxHp'],'order':u['order']} for u in evac['colonyUnits'] if u['id'] in ids],
  'nativeBoardCommands':board,'actualLocalEvents':native['events'],'localGuardDamage':damage,
  'tower':{'id':'building-p0-defenseTower-2001','hitCount':len(tower),'rawDamageIncludingOverkill':sum(h['damage'] for h in tower),'nativeLethalHits':[h for h in tower if h['after']<=0]},
  'actualCheckpointConsequences':[{'tick':q['tick'],'hallHp':q.get('hallHp'),'hallExists':q['hallExists'],'gold':q['gold'],'guardHPAndOrders':[{'id':g['id'],'hp':g['hp'],'maxHp':g['maxHp'],'order':g['order'],'navalClaimed':g['navalClaimed']} for g in q['guardDetails']],'freeWorkers':q['localWorkersFreeForExistingProducerOrTower'],'mission':q.get('mission'),'boat':q.get('boat'),'pickupMetric':q['pickupMetric'],'enemyStrength':q['enemyStrength'],'localArmyStrength':q['localArmyStrength']} for q in queries['rows']],
  'limits':[
    'No proposed code fix or counterfactual outcome is claimed by this diagnostic. The three guards were wounded, not healthy; maxHp210.',
    'Native hit instrumentation covers only63600through64800. Later consequences are original complete checkpoints, not a newly observed continuous hit stream.',
    'The boat genuinely moves via native boarding collection, including partial sea routes. Do not describe it as stationary, no move issued, or continuously proven unreachable.',
    'Existing optimistic road travel estimate1662 at64605 is not an arrival/deadline proof; load, wind, turning, partial path steering and berth packing are omitted.',
    'Original purchases records are planned commands. Actual constructed barracks and four native spawned units separately establish the production happened; no purchase failure is inferred.',
    'Original report capture ends69600 with no winner;68400 colony hall death is not whole-match defeat, a win, or bootstrap acceptance.',
    'Original old-container uncommitted source/workspace modifications remain unrecovered; no new claim of their recovery.',
    'Native client images are post-run exact-snapshot drawWorld observations, not historical live captures or reconstructed animation.'
  ]
}
(out/'colony-defense-audit.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'joins':len(joins),'allNativeTerminalFieldsExact':native['equals'],'sourceRuntimeSupportVerified':870,'capsulePayloadsVerified':1370,'frozenVerified':184,'rawDamageVersusHpDamage':damage},ensure_ascii=False))
