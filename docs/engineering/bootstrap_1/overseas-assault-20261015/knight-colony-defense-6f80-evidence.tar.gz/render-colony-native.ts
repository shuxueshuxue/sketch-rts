import {createCanvas} from '@napi-rs/canvas';
import {readFileSync, writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {installHeadlessCanvas} from '/tmp/sketch-rts-knight-6f80a-ordinary-control/src/recorder/record.ts';
import {drawWorld} from '/tmp/sketch-rts-knight-6f80a-ordinary-control/src/client/world-renderer.ts';
import {UnitFacingTracker} from '/tmp/sketch-rts-knight-6f80a-ordinary-control/src/client/unit-facing.ts';

const out = '/tmp/knight-colony-defense-6f80';
const source = '/tmp/sketch-rts-knight-6f80a-ordinary-control';
const sha = (b: any) => createHash('sha256').update(b).digest('hex');
const frames = JSON.parse(gunzipSync(readFileSync(out + '/native63600-64800-frames.json.gz')).toString());
installHeadlessCanvas();
const records: any[] = [];
for (const spec of [
  {label:'native-first-enemy-landing-64103', tick:64103, input:'native63600-64800-frames.json.gz', view:{x:1750,y:2000,width:2100,height:1500,zoom:1.4}},
  {label:'native-before-evacuation-64605', tick:64605, input:'complete-64605.json', view:{x:1750,y:2000,width:2100,height:1500,zoom:1.4}},
  {label:'native-awaiting-boat-hall27-67200', tick:67200, input:'complete-67200.json', view:{x:1750,y:2000,width:2100,height:1500,zoom:1.4}},
  {label:'native-colony-boat-distance-67200', tick:67200, input:'complete-67200.json', view:{x:1750,y:2000,width:2100,height:1500,zoom:0.35}}
]) {
  const frame = spec.input.endsWith('.gz')
    ? frames.find((f: any) => f.snapshot.tick === spec.tick)
    : JSON.parse(readFileSync(out + '/' + spec.input, 'utf8'));
  if (!frame || frame.snapshot.tick !== spec.tick) throw Error('missing exact frame ' + spec.tick);
  const before = sha(JSON.stringify(frame));
  const canvas = createCanvas(spec.view.width, spec.view.height);
  drawWorld({ctx:canvas.getContext('2d') as any,snapshot:frame.snapshot,view:spec.view,now:spec.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
  const png = canvas.toBuffer('image/png');
  writeFileSync(out + '/' + spec.label + '.png', png);
  const after = sha(JSON.stringify(frame));
  if (before !== after) throw Error('renderer changed frame');
  records.push({...spec,pngSha256:sha(png),snapshotSha256:sha(JSON.stringify(frame.snapshot)),inputSha256:sha(readFileSync(out+'/'+spec.input)),fullInputUnchanged:true});
}
writeFileSync(out + '/native-render-metadata.json', JSON.stringify({classification:'Post-run native client drawWorld renders of exact original/reproduced game worlds; not historical live captures or replayed animation. No snapshot edits or game steps.',source,records,renderSourceHashes:Object.fromEntries(['src/recorder/record.ts','src/client/world-renderer.ts','src/client/unit-facing.ts'].map(p=>[p,sha(readFileSync(source+'/'+p))]))},null,2));
console.log(JSON.stringify(records));
