import hashlib,json,tarfile
from pathlib import Path
out=Path('/tmp/knight-colony-defense-6f80')
archive=Path('/tmp/knight-colony-defense-6f80-evidence.tar.gz')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={str(p.relative_to(out)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and p.name!='INDEX.json'}
(out/'INDEX.json').write_text(json.dumps({'algorithm':'SHA-256','classification':'Post-run self-contained read-only63600to64800 colony-defense diagnosis; original ordinary0 continues separately. Every payload below is verified again from the finished archive. INDEX excludes itself.','files':files},indent=2)+'\n')
with tarfile.open(archive,'w:gz') as tf:
    for name in [*files,'INDEX.json']:
        tf.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    assert set(tf.getnames())==set(files)|{'INDEX.json'}
    index=json.load(tf.extractfile('INDEX.json'))
    for name,metadata in index['files'].items():
        b=tf.extractfile(name).read()
        assert len(b)==metadata['bytes'] and sha(b)==metadata['sha256'],name
receipt={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payloadsVerified':len(files),'entriesVerified':len(files)+1,'sourceCapsulePayloadsIndependentlyVerified':1370,'sourceRuntimeSupportVerified':870,'frozenManifestEntriesVerified':184}
Path('/tmp/knight-colony-defense-6f80-evidence-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
