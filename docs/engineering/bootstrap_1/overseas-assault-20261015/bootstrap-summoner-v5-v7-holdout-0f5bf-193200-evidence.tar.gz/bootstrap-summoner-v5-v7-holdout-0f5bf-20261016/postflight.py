"""Read-only integrity verification after natural end or explicitly authorized observation stop. Outcome is separate."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

directory = Path(__file__).parent
report = json.loads((directory / 'resume-79800/ordinary0-resume.json').read_text())
final = json.loads(gzip.decompress((directory / 'resume-79800/ordinary0-resume-final.json.gz').read_bytes()))
cap = json.loads((directory / 'candidate-source.json').read_text())
launch = json.loads((directory / 'actual-launch.json').read_text())
opening = json.loads((directory / 'ordinary-opening.json').read_text())
source = Path(cap['sourceRoot'])
sha = lambda data: hashlib.sha256(data).hexdigest()
stream_files = {'commands': 'public-commands', 'hits': 'native-hits', 'events': 'native-events'}
original_streams = {key: [json.loads(line) for line in (directory / ('ordinary0-' + name + '.jsonl')).read_text().splitlines() if line] for key, name in stream_files.items()}
resume_streams = {key: [json.loads(line) for line in (directory / 'resume-79800' / ('ordinary0-resume-' + name + '.jsonl')).read_text().splitlines() if line] for key, name in stream_files.items()}
prior_progress = json.loads((directory / 'ordinary0-progress.json').read_text())
prior_sample = next(s for s in prior_progress['samples'] if s['tick'] == 79800)
event_base = next(i for i, e in enumerate(original_streams['events']) if e['tick'] > 79800 or e['tick'] == 79800 and e['stage'] != 'after-step')
base_counts = {'commands': prior_sample['commands'], 'hits': prior_sample['hits'], 'events': event_base}
streams = {key: original_streams[key][:base_counts[key]] + resume_streams[key] for key in stream_files}
resume_launch = json.loads((directory / 'resume-79800/ordinary0-resume-launch.json').read_text())
resume_input = json.loads(gzip.decompress((directory / 'ordinary0.frames/79800.json.gz').read_bytes()))
changes = [name for name, digest in cap['hashes'].items() if sha((source / name).read_bytes()) != digest]
status = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
checks = {
    'sourceUnchanged': not changes and not status and head == cap['head'],
    'liveRulesVersion2': 'export const RULES_VERSION = 2;' in (source / 'src/shared/rules-version.ts').read_text(),
    'driverUnchanged': sha((directory / 'ordinary0.ts').read_bytes()) == launch['driverSHA256'],
    'resumeDriverUnchanged': sha((directory / 'resume-79800/ordinary0-resume.ts').read_bytes()) == resume_launch['driverSHA256'],
    'resumeInputWorldIdMemoryExact': all(report['resumeInitial'][k] == resume_input[k] for k in ['snapshot', 'nextId', 'memories']),
    'persistedOriginalTailPrefixExact': all(report['prefixVerification']['comparison'].values()) and report['prefixVerification']['matchedTailCounts'] == report['prefixVerification']['expectedTailCounts'],
    'originalStreamsGuarded': all(report['originalPreflight'].values()) and all(report['originalPostflight'].values()),
    'observerUnchanged': sha((directory / 'observer-ledger.ts').read_bytes()) == launch['observerSHA256'],
    'initialWorldEqualsDeclaredFactory': report['initial']['snapshot'] == opening['snapshot'],
    'initialIdEqualsDeclaredFactory': report['initial']['nextId'] == opening['nextId'],
    'initialAllMemoryEqualsDeclaredFactory': report['initial']['memories'] == opening['memories'],
    **{key + 'CompleteStreamEqualsFinalReport': stream == report[key] for key, stream in streams.items()},
    'frozen184PrePost': report['frozenPre']['files'] == report['frozenPost']['files'] == 184
        and report['frozenPre']['changed'] == report['frozenPost']['changed'] == []
        and report['frozenPre']['revision'] == report['frozenPost']['revision'] == 'd1ae110f2edd99f9c7d899ed61557891ab587639',
}
stop = json.loads((directory / 'observation-stop.json').read_text())
trigger = json.loads((directory / 'observation-stop-trigger.json').read_text())
checks['authorizedObservationStopAtCaptured600Boundary'] = (stop['authorizedByParent'] is True
    and report['result']['observationStopped'] is True and report['result']['winner'] is None
    and report['result']['naturalComplete'] is False
    and report['result']['tick'] == trigger['observedPeriodicCheckpoint']
    and report['result']['tick'] % 600 == 0)
checks['finalCompleteFrameMatchesPeriodic'] = all(final[k] == json.loads(gzip.decompress((directory / ('resume-79800/ordinary0-resume.frames/' + str(report['result']['tick']) + '.json.gz')).read_bytes()))[k] for k in ['snapshot','nextId','memories'])
events = streams['events']
terminal = [e for e in events if e['type'] == 'native-unit-terminal']
corpses = {c['unitId']: c for c in final['snapshot'].get('corpses', [])}
terminal_by_key = {(e['id'], e['tick']): e for e in terminal}
death_rows, removals_without_native_death = [], []
for event in terminal:
    unit = event.get('atObservation') or event.get('previous')
    corpse = corpses.get(event['id'])
    hull = event.get('preStepCarryingHull')
    hull_death = terminal_by_key.get((unit.get('deck', {}).get('shipId'), event['tick']))
    sunk = (hull is not None and (hull_death is not None or hull['ship']['hp'] <= 0)
            and unit.get('expiresTick', event['tick'] + 1) > event['tick'])
    native_death = corpse is not None or sunk
    row = {'id': event['id'], 'tick': event['tick'], 'stage': event['stage'], 'owner': unit['owner'],
           'kind': unit['kind'], 'permanent': event['permanent'],
           'nativeDeathEvidence': 'native field corpse' if corpse else 'pre-step passenger and same-step hull terminal or pre-step hp<=0 hull' if sunk else None,
           'corpse': corpse, 'hullId': unit.get('deck', {}).get('shipId'), 'lastNativeHit': event.get('lastNativeHit')}
    (death_rows if native_death else removals_without_native_death).append(row)
counts = collections.Counter(row['owner'] for row in death_rows)
native_stats = final['snapshot']['match']['stats']['unitsLost']
checks['observedNativeDeathsReconcileAllOwnerStats'] = all(counts[owner] == value for owner, value in native_stats.items())
checks['allNativeCorpsesHaveTerminalObservation'] = set(corpses).issubset({e['id'] for e in terminal})
owners = list(report['setup']['agents'])
remaining = {owner: {'units': [u for u in final['snapshot']['units'] if u['owner'] == owner and u['hp'] > 0],
                     'buildings': [b for b in final['snapshot']['buildings'] if b['owner'] == owner and b['hp'] > 0]}
             for owner in owners}
result = {
    'classification': 'Postflight for the one predeclared holdout ordinary0 case, with explicit SIGKILL and exact same-source recovery segments. Native natural winner is reported separately from full elimination, temporary expiry and three-route acceptance.',
    'seed': report['setup']['seed'], 'head': cap['head'], 'sourceFiles': len(cap['hashes']), 'sourceChanges': changes,
    'result': report['result'], 'naturalWinner': bool(report['result']['winner']), 'observationStop': stop, 'stopTrigger': trigger, 'segments': report['segments'], 'prefixVerification': report['prefixVerification'], 'checks': checks,
    'counts': {key: len(value) for key, value in streams.items()},
    'nativeDeaths': death_rows,
    'terminalObservationStages': dict(collections.Counter(e['stage'] for e in terminal)),
    'commandHpNonpositiveTerminalCount': sum(e['stage'] == 'after-command' and e['observedAs'] == 'hp<=0-before-cleanup' for e in terminal),
    'nativeDeathsByOwner': dict(counts),
    'permanentNativeDeathsByOwner': dict(collections.Counter(row['owner'] for row in death_rows if row['permanent'])),
    'temporaryNativeDeathsByOwner': dict(collections.Counter(row['owner'] for row in death_rows if not row['permanent'])),
    'terminalRemovalsWithoutNativeDeathEvidence': removals_without_native_death,
    'remaining': remaining,
    'limitations': ['A field last-hit record may be older than the final blow for indirect native causes; cause requires the actual corpse/hull/HP boundary.',
                   'This single holdout became a development case upon observation. No performance, shared-hunk causality or full bootstrap acceptance is inferred.',
                   'Original inaccessible container uncommitted changes remain unrecovered; this validation starts only from committed0f5bf.'],
}
(directory / 'postflight.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'result': result['result'], 'checks': checks, 'nativeDeathsByOwner': dict(counts),
                  'permanent': result['permanentNativeDeathsByOwner'],
                  'remaining': {owner: {key: len(value) for key, value in items.items()} for owner, items in remaining.items()}}))
if not all(checks.values()):
    raise SystemExit('Postflight gap: preserve and investigate without editing the fixed run')
