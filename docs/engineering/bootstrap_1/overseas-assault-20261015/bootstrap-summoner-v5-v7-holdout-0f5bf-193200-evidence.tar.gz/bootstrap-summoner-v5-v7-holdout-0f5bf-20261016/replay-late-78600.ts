import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync, gunzipSync } from 'node:zlib';
import { NativeLedger } from './observer-ledger';
const directory = '/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const out = directory + '/late-replay-78600-79200', from = 78600, end = 79200;
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8')), source = cap.sourceRoot;
const launch = JSON.parse(readFileSync(directory + '/actual-launch.json', 'utf8'));
const declaration = JSON.parse(readFileSync(directory + '/seed-predeclaration.json', 'utf8'));
const sha = (data: any) => createHash('sha256').update(data).digest('hex');
const copy = (x: any) => JSON.parse(JSON.stringify(x));
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
function verify() {
  const changes = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(source + '/' + path)) !== hash).map(([path]) => path);
  const head = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', source, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Fixed source changed');
  if (sha(readFileSync(directory + '/ordinary0.ts')) !== launch.driverSHA256
    || sha(readFileSync(directory + '/observer-ledger.ts')) !== launch.observerSHA256) throw Error('Actual observer changed');
  return { files: Object.keys(cap.hashes).length, changes, head, status };
}
const preflight = verify();
const [{ bootstrapGame, bootstrapMatches }, { snapshotGame, restoreSnapshotIntoGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { runAiGameLoop }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts')]);
const input = JSON.parse(gunzipSync(readFileSync(directory + `/ordinary0.frames/${from}.json.gz`)).toString());
const expected = JSON.parse(gunzipSync(readFileSync(directory + `/ordinary0.frames/${end}.json.gz`)).toString());
const match = bootstrapMatches(declaration.seed, [declaration.factory], end, true).find((m: any) => m.subject === 'v9_summoner'
  && m.side === 1 && m.agents.p0.race === 'ember' && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v5+v7');
if (!match) throw Error('Exact setup missing');
const owners = Object.keys(match.agents), game = bootstrapGame(match), memories = createAiMemoryProvider();
restoreSnapshotIntoGame(game, input.snapshot, input.nextId);
for (const [owner, memory] of Object.entries(input.memories)) if (memory !== null) memories.set(owner, copy(memory));
const full = () => copy({ snapshot: snapshotGame(game), nextId: game.nextId, memories: Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null])) });
const restored = full(), restore = { world: isDeepStrictEqual(restored.snapshot, input.snapshot), nextId: restored.nextId === input.nextId,
  allMemories: isDeepStrictEqual(restored.memories, input.memories) };
if (Object.values(restore).some(v => !v)) throw Error('Initial restore differs');
const basePlanner = await createBootstrapCommandPlanner(memories), commands: any[] = [], hits: any[] = [], events: any[] = [], lastHit = new Map<string, any>();
const ledger = new NativeLedger(game.units, game.buildings);
mkdirSync(out + '.inputs', { recursive: true });
const planner = (context: any) => {
  // Reconstructed before-owner-planner inputs, not original live capture. No future state is supplied to the planner.
  const before = full(), entries = basePlanner(context);
  if (context.owner === 'p0') writeFileSync(out + `.inputs/${game.tick}-p0.json.gz`, gzipSync(JSON.stringify({
    classification: 'Reconstructed from exact recorded78600; original79200 final/commands/hits closure required.',
    ...before, plannerContext: copy(context), entries: copy(entries), afterMemory: copy(memories.get(context.owner)) })));
  return entries;
};
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  const hit = copy({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind,
    target: target.id, targetOwner: target.owner, targetKind: target.kind, damage, hpBefore, hpAfter: target.hp, deck: target.deck });
  hits.push(hit); lastHit.set(target.id, hit);
} };
const observe = (stage: string) => events.push(...ledger.observe(game.tick, stage, game.units, game.buildings, lastHit));
const result = runAiGameLoop({ ...match, game, commandPlanner: planner }, {
  onCommand(event: any) { commands.push(copy({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command })); observe('after-command'); },
  beforeStep() { observe('before-step'); ledger.beforeStep(game.units); },
  onStep() { observe('after-step'); },
});
const final = full();
const stream = (name: string) => readFileSync(directory + '/ordinary0-' + name + '.jsonl', 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line));
const expectedCommands = stream('public-commands').filter((e: any) => e.tick >= from && e.tick < end);
const expectedHits = stream('native-hits').filter((e: any) => e.tick > from && e.tick <= end);
const comparison = { world: isDeepStrictEqual(final.snapshot, expected.snapshot), nextId: final.nextId === expected.nextId,
  allMemories: isDeepStrictEqual(final.memories, expected.memories), allCommands: isDeepStrictEqual(commands, expectedCommands),
  allNativeHits: isDeepStrictEqual(hits, expectedHits) };
const summary = { classification: 'Observer-only same-source native3AI replay78600→79200 from actual ordinary0 checkpoint. Reconstructed input frames are separately identified; no changed-code result, manual command or newordinary0.',
  source, head: cap.head, scriptSHA256: sha(readFileSync(new URL(import.meta.url))), from, end, restore, comparison, preflight, postflight: verify(),
  elapsedMs: result.elapsedMs, cpuMs: result.cpuMs, commands, expectedCommandCount: expectedCommands.length,
  hits, expectedHitCount: expectedHits.length, events };
writeFileSync(out + '.json', JSON.stringify(summary, null, 2) + '\n');
writeFileSync(out + '-final.json.gz', gzipSync(JSON.stringify(final)));
console.log(JSON.stringify({ from, end, restore, comparison, commands: commands.length, hits: hits.length }));
if (Object.values(comparison).some(v => !v)) throw Error('Replay not closed; preserve gap before attribution');
