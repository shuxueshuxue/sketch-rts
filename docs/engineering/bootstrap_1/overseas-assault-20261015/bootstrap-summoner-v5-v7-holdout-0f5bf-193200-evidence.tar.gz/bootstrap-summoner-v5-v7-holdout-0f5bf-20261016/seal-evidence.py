from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile
D=Path(__file__).parent
archive=D.parent/'bootstrap-summoner-v5-v7-holdout-0f5bf-193200-evidence.tar.gz'
receipt=archive.with_name('bootstrap-summoner-v5-v7-holdout-0f5bf-193200-evidence.archive.json')
if archive.exists() or receipt.exists() or (D/'INDEX.json').exists():raise RuntimeError('Never overwrite sealed evidence')
sha=lambda b:hashlib.sha256(b).hexdigest()
payload=[]
for p in sorted(D.rglob('*')):
 rel=p.relative_to(D)
 if any(part in {'node_modules','runtime-tmp','__pycache__'} for part in rel.parts) or p.is_symlink() or not p.is_file():continue
 payload.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
index={'classification':'Immutable evidence payload index for one fixed0f rules2 holdout ordinary0, original137 interrupted and exact same-source resumed to authorized193200 strategic-stagnation observation stop, winnernull. No natural result or bootstrap completion.', 'payloadCount':len(payload),'exclusions':['node_modules dependency symlink','runtime-tmp tsx compiled cache only','__pycache__'],'sourceCapsule':'source.tar.gz (1443live+497historical readback proof retained)','payload':payload}
(D/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True)as out:
 for row in payload:out.add(D/row['path'],arcname=D.name+'/'+row['path'],recursive=False)
 out.add(D/'INDEX.json',arcname=D.name+'/INDEX.json',recursive=False)
checks=[]
with tarfile.open(archive,'r:gz')as inp:
 members={m.name:m for m in inp if m.isfile()}
 for row in payload:
  b=inp.extractfile(members[D.name+'/'+row['path']]).read()
  checks.append(len(b)==row['bytes'] and sha(b)==row['sha256'])
 actualIndex=inp.extractfile(members[D.name+'/INDEX.json']).read()
 keysCorrect=set(members)=={D.name+'/'+r['path'] for r in payload}|{D.name+'/INDEX.json'}
 indexExact=actualIndex==(D/'INDEX.json').read_bytes()
result={'sealedAtUtc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payloadCount':len(payload),'regularMembersIncludingIndex':len(members),'allPayloadReadbackSHAAndBytesExact':all(checks),'allPayloadNamesExact':keysCorrect,'indexReadbackExact':indexExact,'indexSHA256':sha(actualIndex),'sourceHead':'0f5bf01a05046169d4fb42322376f767b97bcc83','actualFinalTick':193200,'winner':None,'naturalComplete':False,'observationStopped':True,'originalProcessExit':137,'resumedProcessExit':0,'originalUncommittedWorkspaceGapStillUnrecovered':True}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
if not(all(checks)and keysCorrect and indexExact):raise RuntimeError('Readback failed')
