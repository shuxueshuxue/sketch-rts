import ctypes,json,os,re,struct,time
from pathlib import Path
from datetime import datetime,timezone
D=Path(__file__).parent
if (D/'observation-stop.json').exists():raise RuntimeError('Stop request already exists')
payload={'authorizedByParent':True,'authorization':'/root message 2026-10-16: use pre-existing observation-stop.json at next complete600tick boundary; do not kill process, alter winner, or impose a deadline.','reason':'Bounded strategic stagnation:132000..174600 no native hit, permanent military birth/death/disembark, building destruction, mine depletion or any player gold/stat change despite36406 public commands; fleet missions remain empty, expedition requirement38.2485 exceeds all current permanent army34.7083, no active miners or land production. Existing45gold bounties/160paid training refund are available recovery routes but not selected by this strategy. This is not a mathematical infinite-loop proof or natural defeat.','evidence':['late-loading-and-income/bounded-native-ledger-132000-current.json','late-loading-and-income/income-145800.json','late-loading-and-income/recovery-options-145800.json','late-loading-and-income/query-current-expedition-145800.json'],'protocol':'External inotify watch on the next numeric periodic full-frame temporary file creation. Publish existing supported stop request without editing active driver or issuing a game command. Actual final tick must be checked against observed numeric checkpoint.'}
prepared=D/'observation-stop-prepared.json'
prepared.write_text(json.dumps(payload,indent=2)+'\n')
libc=ctypes.CDLL(None,use_errno=True);fd=libc.inotify_init1(0);assert fd>=0
watch=libc.inotify_add_watch(fd,os.fsencode(D/'resume-79800/ordinary0-resume.frames'),0x100);assert watch>=0
print(json.dumps({'watchingAtUtc':datetime.now(timezone.utc).isoformat(),'watcherPid':os.getpid()}),flush=True)
while True:
 data=os.read(fd,65536);offset=0
 while offset<len(data):
  wd,mask,cookie,length=struct.unpack_from('iIII',data,offset);offset+=16
  name=data[offset:offset+length].split(b'\0',1)[0].decode();offset+=length
  match=re.fullmatch(r'(\d+)\.json\.gz\.tmp',name)
  if not match or int(match[1])%600:continue
  observed=int(match[1]);os.link(prepared,D/'observation-stop.json')
  witness={'triggeredAtUtc':datetime.now(timezone.utc).isoformat(),'observedPeriodicCheckpoint':observed,'triggerName':name,'protocol':payload['protocol'],'actualStopTick':'Read final report; do not infer from notification alone.'}
  (D/'observation-stop-trigger.json').write_text(json.dumps(witness,indent=2)+'\n')
  print(json.dumps(witness),flush=True);os.close(fd);raise SystemExit(0)
