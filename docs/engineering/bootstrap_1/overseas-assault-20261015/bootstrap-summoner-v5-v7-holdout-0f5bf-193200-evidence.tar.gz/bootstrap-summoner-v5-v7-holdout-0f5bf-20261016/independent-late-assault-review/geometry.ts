import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import {sameGround} from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/terrain.ts';
import {unitMover} from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/catalog.ts';

const D='/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const O='/workspace/.playtest/holdout-late-assault-independent-review';
const sha=(raw:any)=>crypto.createHash('sha256').update(raw).digest('hex');
const first={x:7248,y:4464},second={x:7120,y:6640};
const events=fs.readFileSync(D+'/ordinary0-native-events.jsonl','utf8').trim().split('\n').map(s=>JSON.parse(s));
const relevantDisembark=events.filter(e=>e.type==='observed-disembark'&&e.after.owner==='p0'&&((e.tick>=56000&&e.tick<=57600)||(e.tick>=78600&&e.tick<=79800)));
const rows:any[]=[];
for(const tick of [55200,56131,57000,57600,58200,58800,60000,78600,79126,79200,79800]){
 const preferred=`${D}/ordinary0.frames/${tick}.json.gz`;
 const alt=fs.readdirSync(D+'/ordinary0.frames').find(n=>n.startsWith(tick+'-')&&n.includes('after-step'));
 const path=fs.existsSync(preferred)?preferred:alt?D+'/ordinary0.frames/'+alt:undefined;
 if(!path)continue;
 const raw=fs.readFileSync(path),f=JSON.parse(zlib.gunzipSync(raw).toString()),s=f.snapshot,before=sha(JSON.stringify(f));
 const island=(anchor:any)=>({
  enemyBuildings:s.buildings.filter((b:any)=>b.hp>0&&['p1','p2'].includes(b.owner)&&sameGround(s.map,b,anchor)).map((b:any)=>({id:b.id,kind:b.kind,owner:b.owner,hp:b.hp,x:b.x,y:b.y})),
  enemyPermanentLandUnits:s.units.filter((u:any)=>u.hp>0&&['p1','p2'].includes(u.owner)&&!u.deck&&u.expiresTick===undefined&&unitMover(u.kind)==='land'&&sameGround(s.map,u,anchor)).map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,order:u.order})),
  ownPermanentLandUnits:s.units.filter((u:any)=>u.hp>0&&u.owner==='p0'&&!u.deck&&u.expiresTick===undefined&&unitMover(u.kind)==='land'&&sameGround(s.map,u,anchor)).map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,level:u.level,x:u.x,y:u.y,order:u.order})),
 });
 rows.push({tick,path,sha256:sha(raw),checkpointStage:f.checkpointStage,nextId:f.nextId,memoryKeys:Object.keys(f.memories),firstIsland:island(first),secondIsland:island(second),
  actualDisembarksAtThisTick:relevantDisembark.filter(e=>e.tick===tick).map(e=>({tick:e.tick,stage:e.stage,id:e.after.id,kind:e.after.kind,expiresTick:e.after.expiresTick??null,fromShip:e.before.deck.shipId,hp:e.after.hp,x:e.after.x,y:e.after.y,onFirstIsland:sameGround(s.map,e.after,first),onSecondIsland:sameGround(s.map,e.after,second)})),
  enemyMainHalls:s.buildings.filter((b:any)=>['building-p1-townhall','building-p2-townhall'].includes(b.id)).map((b:any)=>({id:b.id,owner:b.owner,hp:b.hp,x:b.x,y:b.y})),
  inputUnchanged:sha(JSON.stringify(f))===before});
}
const map=JSON.parse(zlib.gunzipSync(fs.readFileSync(D+'/ordinary0.frames/79800.json.gz')).toString()).snapshot.map;
const disembarks=relevantDisembark.map(e=>({tick:e.tick,stage:e.stage,id:e.after.id,kind:e.after.kind,expiresTick:e.after.expiresTick??null,fromShip:e.before.deck.shipId,hp:e.after.hp,x:e.after.x,y:e.after.y,onFirstIsland:sameGround(map,e.after,first),onSecondIsland:sameGround(map,e.after,second)}));
const firstIds=new Set(disembarks.filter(e=>e.onFirstIsland&&e.expiresTick===null&&e.kind!=='worker').map(e=>e.id));
const secondIds=new Set(disembarks.filter(e=>e.onSecondIsland&&e.expiresTick===null&&e.kind!=='worker').map(e=>e.id));
fs.writeFileSync(O+'/island-and-arrival-query.json',JSON.stringify({classification:'Read-only native sameGround classification on existing complete original ordinary0 snapshots and actual disembark events. No restore, simulation, planner, commands or source edits. After-step/after-command critical frames are event evidence, not claimed independent preplanner inputs.',source:'/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control',base:'0f5bf01a05046169d4fb42322376f767b97bcc83',firstIslandAnchor:first,secondIslandAnchor:second,rows,disembarks,actualPermanentNonworkerIdsObservedLandingOnBothIslands:[...firstIds].filter(id=>secondIds.has(id))},null,2));
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,firstBuildings:r.firstIsland.enemyBuildings.length,firstEnemyGround:r.firstIsland.enemyPermanentLandUnits.length,firstOwnGround:r.firstIsland.ownPermanentLandUnits.length,secondBuildings:r.secondIsland.enemyBuildings.length,secondEnemyGround:r.secondIsland.enemyPermanentLandUnits.length,secondOwnGround:r.secondIsland.ownPermanentLandUnits.length,landed:r.actualDisembarksAtThisTick.length,unchanged:r.inputUnchanged}))));
