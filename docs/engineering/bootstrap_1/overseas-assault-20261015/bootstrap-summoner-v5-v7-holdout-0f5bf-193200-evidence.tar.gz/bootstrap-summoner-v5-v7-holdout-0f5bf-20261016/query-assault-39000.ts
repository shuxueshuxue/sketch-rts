import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const directory='/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const cap=JSON.parse(readFileSync(directory+'/candidate-source.json','utf8'));
const imp=(path:string)=>import(pathToFileURL(cap.sourceRoot+'/'+path).href);
const [{assaultExpedition},{effectiveCombatRating},{shipPassengers},{sameGround},{unitMover}]=await Promise.all([
  imp('src/ai/policy/naval.ts'),imp('src/ai/policy/v6/strength.ts'),imp('src/shared/ship-geometry.ts'),
  imp('src/shared/terrain.ts'),imp('src/shared/catalog.ts')]);
const frame=JSON.parse(gunzipSync(readFileSync(directory+'/ordinary0.frames/39000.json.gz')).toString());
const before=structuredClone(frame),snapshot=frame.snapshot,options={memory:frame.memories.p0,teams:snapshot.teams,requestedVersion:'v9_summoner',version:'v7'};
const mission=frame.memories.p0.naval.ferries['unit-p0-transport-1071'];
const target=snapshot.buildings.find((b:any)=>b.id===mission.targetId);
const boat=snapshot.units.find((u:any)=>u.id==='unit-p0-transport-1071');
const expedition=assaultExpedition(snapshot,'p0',options,target);
const cargo=shipPassengers(snapshot.units,boat);
const summary=(u:any)=>({id:u.id,kind:u.kind,hp:u.hp,x:u.x,y:u.y,deck:u.deck,order:u.order,strength:effectiveCombatRating(snapshot,u)});
const ownPermanent=snapshot.units.filter((u:any)=>u.owner==='p0'&&u.kind!=='worker'&&!u.expiresTick&&unitMover(u.kind)==='land');
const result={classification:'Read-only query of exported current assaultExpedition on original recorded39000 full input; no native game, source edit, future data or private landingSafe imitation.',
  tick:39000,source:cap.sourceRoot,head:cap.head,target,mission,boat:summary(boat),
  expedition:{required:expedition.required,ready:expedition.ready,crew:expedition.crew.map(summary)},
  actualCargo:cargo.map(summary),permanentNonworkerCargoPower:cargo.filter((u:any)=>u.kind!=='worker'&&!u.expiresTick).reduce((n:number,u:any)=>n+effectiveCombatRating(snapshot,u),0),
  ownPermanentArmy:ownPermanent.map(summary),ownLandedTarget:ownPermanent.filter((u:any)=>!u.deck&&sameGround(snapshot.map,u,target)).map(summary),
  inputUnchanged:isDeepStrictEqual(frame,before),limitations:['Actual39000 is before last40s progress timeout; it does not independently capture39210 preplanner.','A ready strategic expedition can include permanent units outside the one actual loaded boat. It does not prove safe departure/landing or native victory.']};
writeFileSync(directory+'/query-assault-39000.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({required:expedition.required,ready:expedition.ready,strategicCrew:expedition.crew.map((u:any)=>u.id),cargoPower:result.permanentNonworkerCargoPower,inputUnchanged:result.inputUnchanged}));
if(!result.inputUnchanged)throw Error('Pure query mutated input');
