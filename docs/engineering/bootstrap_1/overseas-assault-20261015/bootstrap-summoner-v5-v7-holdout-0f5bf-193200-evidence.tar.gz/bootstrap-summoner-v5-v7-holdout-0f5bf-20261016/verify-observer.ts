import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { NativeLedger } from './observer-ledger';
const hull = { id: 'ship', owner: 'p0', kind: 'transport', hp: 100, sailing: {} };
const passenger = { id: 'passenger', owner: 'p0', kind: 'worker', hp: 70, deck: { shipId: 'ship' } };
const hall = { id: 'hall', owner: 'p1', hp: 100 };
const ledger = new NativeLedger([hull, passenger], [hall]);
// Synthetic observer-only state transitions; no engine/game/simulation is instantiated.
hull.hp = 0; hall.hp = 0;
const before = JSON.stringify({ units: [hull, passenger], buildings: [hall] });
const command = ledger.observe(15, 'after-command', [hull, passenger], [hall], new Map());
assert.equal(command.filter(e => e.type === 'native-unit-terminal').length, 1);
assert.equal(command.find(e => e.type === 'native-unit-terminal').observedAs, 'hp<=0-before-cleanup');
assert.equal(command.filter(e => e.type === 'native-building-terminal').length, 1);
assert.equal(JSON.stringify({ units: [hull, passenger], buildings: [hall] }), before);
ledger.beforeStep([hull, passenger]);
assert.equal(ledger.beforeShips.get('ship').ship.hp, 0);
assert.equal(ledger.beforeShips.get('ship').passengers[0].hp, 70);
const cleanup = ledger.observe(16, 'after-step', [], [], new Map());
assert.equal(cleanup.filter(e => e.type === 'native-unit-terminal').length, 1);
assert.equal(cleanup.find(e => e.type === 'native-unit-terminal').id, 'passenger');
assert.equal(cleanup.find(e => e.type === 'native-unit-terminal').preStepCarryingHull.ship.id, 'ship');
assert.equal(cleanup.filter(e => e.type === 'native-building-terminal').length, 0);
assert.equal(cleanup.filter(e => e.type === 'unit-removal').length, 2);
const result = { classification: 'Observer-only plain-object boundary verification before real launch; no game instantiated.',
  hpNonpositiveDuringCommandDetected: true, deadHullPassengersPreservedBeforeCleanup: true,
  terminalDeduplicatedFromRemoval: true, commandBuildingDeathDetected: true, observerDoesNotMutateInputs: true };
writeFileSync(new URL('./observer-verification.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
