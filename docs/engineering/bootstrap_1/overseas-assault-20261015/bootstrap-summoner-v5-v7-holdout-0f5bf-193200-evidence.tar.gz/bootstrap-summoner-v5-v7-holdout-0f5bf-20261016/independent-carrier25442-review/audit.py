from pathlib import Path
import gzip, hashlib, json, subprocess

D = Path('/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016')
W = Path('/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control')
O = Path(__file__).parent
ship = 'unit-p0-carrier-25442'
ash = ['unit-p0-ashHexer-4268', 'unit-p0-ashHexer-4420']
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v): (O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
rows=[]; inputs=[]
for tick in [114000,114600,115200,115800]:
    p=D/f'resume-79800/ordinary0-resume.frames/{tick}.json.gz'
    f=json.loads(gzip.decompress(p.read_bytes())); s=f['snapshot']; units=s['units']
    boat=next(u for u in units if u['id']==ship)
    m=f['memories']['p0']['naval']; mission=m['ferries'][ship]
    cargo=[u for u in units if u.get('deck',{}).get('shipId')==ship]
    waiting=[u for u in units if not u.get('deck') and u['order']['type']=='board' and u['order']['transportId']==ship]
    target=next(b for b in s['buildings'] if b['id']==mission['targetId'])
    rows.append({'tick':tick,'nextId':f['nextId'],'checkpointStage':f.get('checkpointStage'),
       'boat':{k:boat[k] for k in ['id','x','y','hp','maxHp','order']},
       'sailing':{k:boat['sailing'].get(k) for k in ['speed','heading']},
       'mission':mission,'allFerryIds':list(m['ferries']),
       'retryUntil':m.get('ferryRetryUntil',{}).get(ship),
       'permanentCargo':[u['id'] for u in cargo if u.get('expiresTick') is None],
       'temporaryCargo':[{k:u[k] for k in ['id','kind','expiresTick']} for u in cargo if u.get('expiresTick') is not None],
       'waitingCrew':[u['id'] for u in waiting],
       'shoreAsh':[{k:u.get(k) for k in ['id','x','y','hp','deck','order']} for u in units if u['id'] in ash],
       'target':{k:target[k] for k in ['id','kind','x','y','hp','maxHp']}})
    inputs.append({'file':str(p),'sha256':digest(p)})
commands=[]
raw=D/'resume-79800/ordinary0-resume-public-commands.jsonl'
for line in raw.open():
    j=json.loads(line); c=j['command']
    ids=c.get('unitIds',[])+([c['unitId']] if c.get('unitId') else [])
    if 101400<=j['tick']<=115800 and any(i in [ship,*ash] for i in ids): commands.append(j)
events=[]
for line in (D/'resume-79800/ordinary0-resume-native-events.jsonl').open():
    j=json.loads(line)
    if j['tick']!=114465:continue
    u=j.get('unit',j.get('previous',{}))
    if u.get('id') not in ['unit-p0-spirit-66377','unit-p0-spirit-66829']:continue
    events.append({'tick':j['tick'],'stage':j.get('stage'),'type':j['type'],'commandIndex':j.get('commandIndex'),
        'unit':{k:u.get(k) for k in ['id','kind','hp','expiresTick','deck']}})
assert all(len(r['permanentCargo'])==10 for r in rows)
assert all(r['permanentCargo']==rows[0]['permanentCargo'] for r in rows)
assert all(r['allFerryIds']==[ship] for r in rows)
assert rows[1]['waitingCrew']==rows[2]['waitingCrew']==rows[3]['waitingCrew']==[]
assert rows[1]['mission']['progress']['tick']==rows[2]['mission']['progress']['tick']==114480
assert rows[1]['boat']['x']==rows[2]['boat']['x'] and rows[1]['boat']['y']==rows[2]['boat']['y']
unload=next(j for j in commands if j['tick']==115290 and j['command']['type']=='unload')
assert all(unload['command'][k]==rows[0]['mission']['from'][k] for k in ['x','y'])
assert rows[3]['retryUntil']==115690 and rows[3]['mission']['phase']=='return'
assert all(r['target']['hp']==320 for r in rows)
source=W/'src/ai/policy/naval.ts'; live=source.read_bytes()
head=subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()
blob=subprocess.check_output(['git','-C',str(W),'show',head+':src/ai/policy/naval.ts'])
assert live==blob
put('observed-frames-and-commands.json',{'inputs':inputs,'rows':rows,'selectedActualPublicCommands':commands,'ephemeralProgressEvents':events})
review={
 'classification':'Independent read-only existing periodic frames, actual command/event ledgers and fixed-source semantics; no native replay, full-planner query, tests or source/driver edits.',
 'source':{'head':head,'navalFile':str(source),'navalSHA256':hashlib.sha256(live).hexdigest(),'liveNavalExactlyGitHead':live==blob},
 'scope':'Actual 0f5bf ordinary0 unseen summoner versus normal frozen v5+v7, same-source resume after original79800 interruption. This review isolates carrier25442 101460..115800, with no new game.',
 'findings':[
  {'fact':'Real payload remained ten permanent land soldiers; no new effective delivery is shown in this interval.','evidence':'Exact deck.shipId in114000/114600/115200/115800; all ten IDs identical. Original timeline also records ten from102000 onward; crewIds alone were not counted.'},
  {'fact':'The northern pickup did approach a real native berth and then stopped.','evidence':'114000 carrier6515.84,2790.03, actual sailing speed9.66 and ash4268 board berth6576,2672/shore6640,2608;114600 and115200 carrier6563.67,2685.99 speed0. Mission coarse pickup6835.43,2831.32 differs from native precise berth. Long approach is not proof of stuck or unreachable route.'},
  {'fact':'The actual115290 unload-return follows the carrier own 40-second stale-progress timeout.','evidence':'Only one ferry at all four exact frames. Latest loading progress114480 unchanged at115200;115290-114480=810>800. At115800 retryUntil115690 is exactly115290+400; source719..730 is the only ferryRetryUntil assignment in this fixed file and calls cancelFerry, clearing crewIds and returning unload to original from.'},
  {'fact':'The last loading progress freshness is not ten new permanent arrivals.','evidence':'Its aboardIds includes ephemeral spirit66829; raw114465 after-step removes expired66377 and after-command births66829 on this deck. At next think114480 crew string changes while permanent ten are unchanged. Native source compares all passenger IDs including temporary summons.'},
  {'fact':'This is not the old empty-other-donor continuation case.','evidence':'There is no second ferry to satisfy the same-phase same-target other-ferry predicate at114000/114600/115200/115800. The timeout-witness donor patch does not change this own-cargo freshness rule.'},
  {'fact':'Actual shore recruitment and move commands are preserved, but initial board-to-idle cause is unresolved.','evidence':'101475 board4268 and114465 board4420;114480/114495/114510/114525/114540 naval move4268 to6919.075938,2760.619866. Both remain shore/nondeck by114600. There is no closed preplanner114465/114480 input in scope. clearTransferLanes can move an already idle/hold bystander; it does not override an active board passenger. Therefore the move does not prove how the earlier native board first ceased.'}],
 'sourceContract':{'lines':'src/ai/policy/naval.ts719..730 and975..987','progress':'phase/any passenger ID/more than32px hull displacement or equivalent bow turn reset freshness; then strict age>40s timeout unless matching fresh other assault ferry. No own permanent-soldier requirement on progress resets.','cancel':'retry20s, return phase, clear crewIds; stop actual native boarders and unload actual cargo at original departure coast.'},
 'limits':['Periodic snapshots alone do not establish which loading no-command branch withheld departure before timeout, actual current required/strength, floor-packing feasibility, or complete route ETA. No new full-planner query was run.',
 'Do not infer first board101475/114465 was unsafe, deck full, or impossible; two idle shore units and actual avoidance moves are observations, not that causal proof.',
 'Original ordinary process ended137 at last complete79800, not a natural result. Per owner report this same-source resume was explicitly stopped at193200 with winner null; this review did not independently audit that final stop record.',
 'No whole-match benefit, completed acceptance, or source change is claimed. Original broken-container uncommitted recovery gap remains.'],
 'blockers':[]}
put('FINAL-CARRIER25442-REVIEW.json',review)
files={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in O.iterdir() if p.is_file() and p.name!='INDEX.json'}
put('INDEX.json',{'classification':'Independent finite read-only review, not a game result.','files':files})
print(json.dumps({'output':str(O),'reviewSHA256':digest(O/'FINAL-CARRIER25442-REVIEW.json'),'indexSHA256':digest(O/'INDEX.json'),'files':len(files)},indent=2))
