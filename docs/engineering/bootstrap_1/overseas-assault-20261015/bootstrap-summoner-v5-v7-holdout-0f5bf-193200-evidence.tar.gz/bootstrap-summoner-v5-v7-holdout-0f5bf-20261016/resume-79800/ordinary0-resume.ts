import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync, gunzipSync } from 'node:zlib';
import { NativeLedger } from '../observer-ledger';

const directory = '/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8')), source = cap.sourceRoot;
const declaration = JSON.parse(readFileSync(directory + '/seed-predeclaration.json', 'utf8'));
const opening = JSON.parse(readFileSync(directory + '/ordinary-opening.json', 'utf8'));
const output = directory + '/resume-79800/ordinary0-resume';
const priorLaunch=JSON.parse(readFileSync(directory+'/actual-launch.json','utf8'));
const interruption=JSON.parse(readFileSync(directory+'/interruption-79800.json','utf8'));
const priorProgress=JSON.parse(readFileSync(directory+'/ordinary0-progress.json','utf8'));
const from=79800, priorSample=priorProgress.samples.find((s:any)=>s.tick===from);
const originalStreams=Object.fromEntries(['public-commands','native-hits','native-events'].map(name=>[name,readFileSync(directory+'/ordinary0-'+name+'.jsonl','utf8').split('\n').filter(Boolean).map(line=>JSON.parse(line))]));
const originalCommands=originalStreams['public-commands'],originalHits=originalStreams['native-hits'],originalEvents=originalStreams['native-events'];
const originalEventBase=originalEvents.findIndex((e:any)=>e.tick>from||e.tick===from&&e.stage!=='after-step');
if(!priorSample||priorProgress.completed||priorProgress.tick!==from||originalEventBase<0)throw Error('Interrupted ordinary boundary differs');
const atomic = (path: string, value: any) => { writeFileSync(path + '.tmp', value); renameSync(path + '.tmp', path); };
const json = (value: any) => JSON.parse(JSON.stringify(value));
const sha = (value: any) => createHash('sha256').update(value).digest('hex');
function verify() {
  const changes = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(source + '/' + path)) !== hash).map(([path]) => path);
  const head = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', source, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Fixed source changed');
  return { files: Object.keys(cap.hashes).length, changes, head, status };
}
function verifyOriginal(){
 if(sha(readFileSync(directory+'/ordinary0.ts'))!==priorLaunch.driverSHA256||sha(readFileSync(directory+'/observer-ledger.ts'))!==priorLaunch.observerSHA256)throw Error('Original driver/observer changed');
 const diffs=Object.entries(interruption.streams).filter(([name,row]:any)=>sha(readFileSync(row.path))!==row.sha256).map(([name])=>name);if(diffs.length)throw Error('Original stream changed');return{driverUnchanged:true,observerUnchanged:true,allOriginalStreamsUnchanged:true};}
const preflight=verify(), originalPreflight=verifyOriginal(), startedAtUtc=new Date().toISOString();
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { snapshotGame, restoreSnapshotIntoGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runAiGameLoop }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts')]);
const match = bootstrapMatches(declaration.seed, [declaration.factory], Number.MAX_SAFE_INTEGER, true).find((m: any) =>
  m.subject === 'v9_summoner' && m.side === 1 && m.agents.p0.race === 'ember'
  && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v5+v7');
if (!match || !isDeepStrictEqual(match.agents, opening.match.agents)) throw Error('Exact predeclared match missing');
const game = bootstrapGame(match), memories = createAiMemoryProvider(), owners = Object.keys(match.agents);
const input=JSON.parse(gunzipSync(readFileSync(directory+`/ordinary0.frames/${from}.json.gz`)).toString());
restoreSnapshotIntoGame(game,input.snapshot,input.nextId);for(const[owner,m]of Object.entries(input.memories))if(m!==null)memories.set(owner,json(m));
const full = () => json({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(owners.map(owner => [owner, memories.get(owner) ?? null])) });
const resumeInitial=full(),initial=JSON.parse(readFileSync(directory+'/in-process-opening.json','utf8'));
const openingComparison=priorLaunch.openingComparison;
const restoreComparison={world:isDeepStrictEqual(resumeInitial.snapshot,input.snapshot),nextId:resumeInitial.nextId===input.nextId,allMemories:isDeepStrictEqual(resumeInitial.memories,input.memories)};
if(game.tick!==from||Object.values(restoreComparison).some(v=>!v))throw Error('Resume complete input restore differs');
const frozenRoot = frozenPolicyRoot();
function frozenCheck() {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([path, hash]) => sha(readFileSync(frozenRoot + '/' + path)) !== hash);
  if (changed.length || frozenPolicyManifest.rulesVersion !== 2 || Object.keys(frozenPolicyManifest.files).length !== 184) throw Error('Actual historical tree changed');
  return { files: 184, changed: [], revision: frozenPolicyManifest.revision };
}
const frozenPre = frozenCheck();
const planner = await createBootstrapCommandPlanner(memories);
if(!isDeepStrictEqual(full().memories,input.memories))throw Error('Planner creation changed restored policy memories');
if (existsSync(output + '-progress.json')) throw Error('Never overwrite an existing actual run');
mkdirSync(output + '.frames', { recursive: true });
for (const suffix of ['-public-commands.jsonl', '-native-hits.jsonl', '-native-events.jsonl']) writeFileSync(output + suffix, '');
atomic(output+'-restored-input.json.gz',gzipSync(JSON.stringify(resumeInitial)));
const classification='Same fixed0f ordinary0 case resumed after original process exit137: exact79800 world/nextId/all3mem restore and full original executed command/hit/event tail-prefix verification before extension. This process did not start at0; no new seed, changed-code continuation or manual gameplay command.';
const samples:any[]=[],commands:any[]=json(originalCommands.slice(0,priorSample.commands)),hits:any[]=json(originalHits.slice(0,priorSample.hits)),events:any[]=json(originalEvents.slice(0,originalEventBase)),lastHit=new Map<string,any>();
for(const hit of hits)lastHit.set(hit.target,hit);
let prefixSaved=false;const prefixCounts={commands:0,hits:0,events:0};
function prefixItem(kind:'commands'|'hits'|'events',index:number,entry:any){const expected=kind==='commands'?originalCommands:kind==='hits'?originalHits:originalEvents;if(index<expected.length){if(!isDeepStrictEqual(entry,expected[index])){atomic(output+'-prefix-mismatch.json',JSON.stringify({kind,index,tick:game.tick,actual:entry,expected:expected[index]},null,2));throw Error('Original executed tail prefix differs: '+kind+' '+index);}prefixCounts[kind]++;}}
function prefixProof(){return{comparison:{allCommands:commands.length>=originalCommands.length,allNativeHits:hits.length>=originalHits.length,allNativeEvents:events.length>=originalEvents.length},matchedTailCounts:{...prefixCounts},expectedTailCounts:{commands:originalCommands.length-priorSample.commands,hits:originalHits.length-priorSample.hits,events:originalEvents.length-originalEventBase},originalCheckpoint:from,lastOriginalCommandTick:originalCommands.at(-1).tick,lastOriginalHitTick:originalHits.at(-1).tick,lastOriginalEventTick:originalEvents.at(-1).tick,note:'Exact original full input and all persisted executed tail observations. No original full world/memory checkpoint exists after79800; reconstructed79951 state is not falsely called an original capture.'};}
const ledger = new NativeLedger(game.units, game.buildings);
let currentCommandIndex: number | undefined, observationStopped = false;
function sample() {
  const summary = { tick: game.tick, winner: game.match.winner, commands: commands.length, hits: hits.length,
    terminalObservations: events.filter(e => e.type === 'native-unit-terminal').length,
    births: events.filter(e => e.type === 'unit-birth-observed').length,
    mineAmountTotal: game.resources.reduce((sum: number, r: any) => sum + r.amount, 0), stats: json(game.match.stats),
    owners: Object.fromEntries(owners.map(owner => [owner, { gold: game.players[owner].gold,
      supply: game.players[owner].supplyUsed, cap: game.players[owner].supplyCap,
      units: game.units.filter((u: any) => u.owner === owner && u.hp > 0).length,
      buildings: game.buildings.filter((b: any) => b.owner === owner && b.hp > 0).length,
      halls: game.buildings.filter((b: any) => b.owner === owner && b.hp > 0 && b.kind === 'townHall').map((b: any) => ({ id: b.id, x: b.x, y: b.y, hp: b.hp, complete: b.complete })) }])) };
  samples.push(summary); return summary;
}
function progress(completed = false) {
  atomic(output + '-progress.json', JSON.stringify({ classification, commit: cap.head, startedAtUtc, pid: process.pid,
    setup: match, tick: game.tick, winner: game.match.winner, completed, observationStopped, samples }));
}
function capture(reason = 'periodic-before-next-think') {
  atomic(output + `.frames/${game.tick}.json.gz`, gzipSync(JSON.stringify({ ...full(), checkpointStage: reason })));
  const summary = sample(); progress(); console.log(JSON.stringify(summary));
}
function observe(stage: string) {
  const observed = ledger.observe(game.tick, stage, game.units, game.buildings, lastHit);
  for (const event of observed) {
    const entry=json({ ...event, commandIndex: currentCommandIndex });prefixItem('events',events.length,entry); events.push(entry);
    appendFileSync(output + '-native-events.jsonl', JSON.stringify(entry) + '\n');
  }
  const significant = observed.some(e => (e.type === 'native-unit-terminal' && e.permanent)
    || e.type === 'native-building-terminal' || (e.type === 'observed-disembark' && e.after.expiresTick === undefined));
  if (significant) atomic(output + `.frames/${game.tick}-${stage}-${currentCommandIndex ?? 'native'}.json.gz`, gzipSync(JSON.stringify({ ...full(),
    checkpointStage: stage, commandIndex: currentCommandIndex,
    restoreCaution: stage === 'after-command' ? 'Mid-think command-boundary observation; may include hp<=0 pending native cleanup. Do not assume ordinary before-think restart without explicit audit.' : 'Post-step event can contain native derived-load states; restore must be checked before reuse.' })));
}
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  const hit = json({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind,
    target: target.id, targetOwner: target.owner, targetKind: target.kind, damage, hpBefore, hpAfter: target.hp, deck: target.deck });
  prefixItem('hits',hits.length,hit);hits.push(hit); lastHit.set(target.id, hit); appendFileSync(output + '-native-hits.jsonl', JSON.stringify(hit) + '\n');
} };
atomic(output + '-launch.json', JSON.stringify({ startedAtUtc, pid: process.pid, cwd: process.cwd(), argv: process.argv,
  driverSHA256:sha(readFileSync(new URL(import.meta.url))),observerSHA256:sha(readFileSync(directory+'/observer-ledger.ts')),originalDriverSHA256:priorLaunch.driverSHA256,originalPreflight,restoreComparison,interruptionPath:directory+'/interruption-79800.json',
  sourcePre: preflight, frozenPre, openingComparison, maxTicks: Number.MAX_SAFE_INTEGER,
  protocol:'One sole same-source resume process after explicit resource coordination. Natural result;144000 is only a checkpoint. First restore complete79800 then strictly match every persisted original tail command/hit/event before new continuation. Original artifacts remain untouched.' }, null, 2));
capture('restored79800-before-first-resumed-think');
class ObservationStop extends Error {}
let runResult: any;
try {
  runResult = runAiGameLoop({ ...match, game, commandPlanner: planner }, {
    onCommand(event: any) {
      currentCommandIndex = commands.length;
      const entry = json({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command });
      prefixItem('commands',commands.length,entry);commands.push(entry); appendFileSync(output + '-public-commands.jsonl', JSON.stringify(entry) + '\n');
      observe('after-command'); currentCommandIndex = undefined;
    },
    beforeStep() { observe('before-step'); ledger.beforeStep(game.units); },
    onStep() {
      observe('after-step');
      if(!prefixSaved&&game.tick>=79951){const proof=prefixProof();atomic(output+'-prefix-proof.json',JSON.stringify({...proof,checkedAtTick:game.tick},null,2));if(Object.values(proof.comparison).some(v=>!v))throw Error('Original tail prefix incomplete');atomic(output+'.frames/'+game.tick+'-reconstructed-prefix.json.gz',gzipSync(JSON.stringify({...full(),checkpointStage:'Reconstructed matching original observable tail, no original full state exists here.'})));prefixSaved=true;}
      if (game.tick % 600 === 0 || game.match.winner) capture();
      if (existsSync(directory + '/observation-stop.json')) {
        const stop = JSON.parse(readFileSync(directory + '/observation-stop.json', 'utf8'));
        if (stop.authorizedByParent === true && stop.reason && stop.evidence) { observationStopped = true; throw new ObservationStop(stop.reason); }
      }
    },
  });
} catch (error) { if (!(error instanceof ObservationStop)) throw error; }
if (samples.at(-1).tick !== game.tick) capture(observationStopped ? 'explicit-observation-stop' : 'natural-terminal');
const final=full(),postflight=verify(),frozenPost=frozenCheck(),originalPostflight=verifyOriginal();if(!prefixSaved)throw Error('Cannot conclude before original prefix verified');
atomic(output + '-final.json.gz', gzipSync(JSON.stringify(final)));
atomic(output + '.json', JSON.stringify({ classification, commit: cap.head, source, startedAtUtc, endedAtUtc: new Date().toISOString(),
  pid:process.pid,setup:match,openingComparison,initial,resumeInitial,restoreComparison,prefixVerification:prefixProof(),originalPreflight,originalPostflight,preflight,postflight,frozenPre:priorLaunch.frozenPre,resumeFrozenPre:frozenPre,frozenPost,segments:{original:{startedAtUtc:priorLaunch.startedAtUtc,pid:priorLaunch.pid,lastFullTick:79800,exitCode:137,interruptionPath:directory+'/interruption-79800.json'},resume:{startedAtUtc,pid:process.pid,from:79800,sourceHead:cap.head}},
  runResult: runResult ? { elapsedMs: runResult.elapsedMs, cpuMs: runResult.cpuMs } : null,
  result: { tick: game.tick, winner: game.match.winner, naturalComplete: !!game.match.winner, observationStopped, stats: game.match.stats },
  commands,hits,events,samples:[...priorProgress.samples.filter((s:any)=>s.tick<from),...samples] }));
progress(true); console.log(JSON.stringify({ completed: true, tick: game.tick, winner: game.match.winner, observationStopped, postflight, frozenPost }));
