# 护理患者与新进攻登船的组合归属

独立工作树以 f2676829 为基线，叠加父分支当时的沿岸/会合/mobile-care 候选；原样 overlay 清单和候选源码归 runtime-source.json。规则 2、frozen manifest 与父分支逐字相同。没有修改父工作树、main 或冻结策略。

原有 mainland 护理 query 已认领危重兵，但 naval 在该帧先产生 board 并写入 crew，mobile-care 再次评估时便让出。新代码将现有 landRecoveryAssignments、patientRendezvousCommands 和 mainland assignments 原样抽入 land-recovery.ts；原回调 troopAvailable 用于新 assault 招募和跨岛 pickup，提前排除护理患者与必要治疗者。已有 board/crew 和 evacuate 生存运输仍保留。未修改 runner 过滤，未新增归属记忆或 HP/任务兼容层。

assault-care-ownership.test.ts 从真实 72000 fixture 明确构造“2411 为20HP、唯一本岛牧师已阵亡或仍在、本船接兵点已选此岛”的反事实，不冒充未改动的真实比赛。原候选7项中6项失败；修复后新增9项全部通过。另原样健康72000、实际v3 80400及既有危重兵/JSON完整策略回归合计三文件40项通过，tsc与diff检查通过。日志均归本目录。

native-boarding.ts 对无牧师反事实只规划一次，再逐条执行公开命令并运行原生物理；没有后续AI，故不是完整比赛。74400已有11名健康援军实际登上3824；76200仍为11名，危重2411保持本岛hold、20HP、没有deck，船HP463.53334744450285不变。73200完整世界和全部策略记忆经JSON保存，恢复支路与原支路自然执行至76200，终局完整快照及nextId严格相同。native-initial/checkpoint/final、命令列表和逐段记录均保留。真实客户端图 native-boarded-patient-ashore.png 显示军队在船上而重伤兵在主厅旁。

runtime-source.json 的完整源码胶囊在该原生命令探针启动后记录；独立工作树生产源码自启动前完成后未再编辑，明确保留记录时点，不伪称启动前胶囊。探针只证明公开登船仍可执行并没有带走护理患者；没有完整胜局、跨种子或最终bootstrap验收结论，原容器未提交修改恢复缺口也未改变。
