from pathlib import Path
import json,gzip,hashlib,tarfile,subprocess
D=Path('/workspace/.playtest/bootstrap-land-income-lead-20261015')
load=lambda f:json.loads(Path(f).read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
short=load(D/'reserve40968-from17400-to21600.json');tail=load(D/'reserve40968-from21600-natural.json')
assert short['firstPublicDifference']['tick']==18495
assert all(c['world']and c['nextId']and all(c['memories'].values())for c in short['prefixChecks']if c['tick']<=18495)
assert [(e['tick'],e['type'])for e in short['hallEvents']]==[(19806,'foundation'),(20366,'complete')]
assert not [r for r in short['deliveries']+tail['deliveries']if r['resourceId']=='gold-gen-5']
assert tail['endTick']==31331 and tail['winner']=='p1'
observer=load(D/'reserve40968-builder-loss-20370-20700.json')
assert all(c['allCompleteEqual']for c in observer['checks'])
assert [(e['tick'],e['id'])for e in observer['events']]==[(20448,'unit-p0-worker-1678'),(20696,'building-p0-townHall-17183')]
for tick in [20370,20430,21600]:
 q=load(D/f'reserve40968-worker-refusal-{tick}.json')
 assert q['publicEntriesEqual']and q['worldUnchanged']and q['nextIdUnchanged']
for name in ['baseline3bdb-fine-17400-18000','baseline3bdb-fine-18600-19200']:
 v=load(D/(name+'.json'))['verification'];assert v['worldEqual']and v['nextIdEqual']and all(v['allMemoriesEqual'].values())
post=load(D/'income-reserve40968-postflight-source.json');assert not post['changed']and post['filesVerified']==1364 and not post['gitStatus']
for tick in [17400,17520,17715,17925,18120,18495,19035]:
 q=load(D/f'fixed68302-{tick}.json');assert q['worldUnchanged']and q['nextIdUnchanged']and q['rawEconomyReproduced']
for tick in [17400,18495,19035]:
 q=load(D/f'fixed40968-{tick}.json');assert q['worldUnchanged']and q['nextIdUnchanged']and q['rawEconomyReproduced']
final=json.loads(gzip.decompress((D/'reserve40968-from21600-natural.frames/31331.json.gz').read_bytes()))
assert not [u for u in final['snapshot']['units']if u['owner']=='p0']
assert not [b for b in final['snapshot']['buildings']if b['owner']=='p0']
assert len([c for c in final['snapshot']['corpses']if c['owner']=='p0'])==70
nativeStats=final['snapshot']['match']['stats'];assert nativeStats['unitsLost']['p0']==70 and nativeStats['unitsKilledByNeutral']['p0']==4 and nativeStats['goldSpent']['p0']==13703
summary={'classification':'Unmerged fixed40968 research-only income-timing reserve. Complete changed-code continuation from genuine3bdb17400; not ordinary0. Funding/hall restored, new-mine income0, natural31331p1 loss.',
 'source':post,'fixedMetricSource':'68302e3a8151293f0f322922e41fccb1b984452a',
 'firstPublicDifference':{'tick':18495,'onlyP0CommandRemoved':{'type':'research','buildingId':'building-p0-barracks-1013','upgradeKind':'weaponTraining'}},
 'short':{'start':17400,'end':21600,'exactCompleteSampledPrefixThrough':18495,'prefixInterval':15,'firstChangedWorldCheckpoint':18510,
  'actualBuildOrderTick':19035,'builder':'unit-p0-worker-1678','foundationTick':19806,'completeTick':20366,'builderDeathTick':20448,'hallDeathTick':20696,'newMineBankGold':0,
  'at21600Losses':41,'old3bdbAt21600Losses':48},
 'naturalTail':{'start':21600,'end':31331,'winner':'p1','ordinary0':False,'permanentLosses':70,'neutralLosses':4,'spent':13703,'newMineBankGold':0,'allP0UnitsAndBuildingsGone':True},
 'old3bdbOrdinary0':{'end':26107,'winner':'p1','losses':71,'neutralLosses':4,'spent':13201},
 'observer':{'start':20370,'end':20700,'exactFullWorldId3MemCheckpoints':len(observer['checks']),
  'workerHits':[{'tick':h['tick'],'sourceId':h['source']['id'],'sourceKind':h['source']['kind'],'taken':h['taken'],'hpBefore':h['hpBefore'],'hpAfter':h['target']['hp']}for h in observer['hits']if h['target']['id']=='unit-p0-worker-1678']},
 'limits':['No production integration or bootstrap completion.','Static first-bank timing excludes future body queues, control, orders, combat and speed changes. Expiry is current-order baseline and not final delivery.','Any-expiring owned mine is not all income exhausted; gen2 remains active. Reserve only changes research while original legal hall goal and safe canonical empty builder exist.','All actual home-defense recruitment preserved; no new owner, memory, TTL, geometry/care/escort/naval consumer or threshold change.','Original container uncommitted recovery gap remains.','Independent main-army/guard ownership and road review by ordinary_summoner continues separately.']}
(D/'income-reserve40968-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files={str(f.relative_to(D)):f for f in D.rglob('*')if f.is_file()and not f.is_symlink()and 'node_modules'not in f.parts
 and f.name not in ['bootstrap-land-income-reserve40968-evidence.tar.gz','income-reserve40968-index.json','income-reserve40968-delivery.json','seal-income-reserve40968.log']}
original=Path('/tmp/bootstrap-land-army-evidence-20261015/production-root3bdb-archer-double-v8-ordinary0')
files['original3bdb/ordinary0.json']=Path(str(original)+'.json')
for tick in [0,17400,21600,26107]:files[f'original3bdb/frames/{tick}.json']=Path(str(original)+f'.json.frames/{tick}.json')
index={'classification':summary['classification'],'files':{name:{'bytes':f.stat().st_size,'sha256':sha(f)}for name,f in sorted(files.items())},
 'dependencies':{'old3bdbOrdinary0ArchiveSHA256':'0d4b83429de9b5ff3736b23f88985574ef1ed240e54bfdf1b0d366a6cabda7ac',
 'earlierMacroArchiveSHA256':'13cd70b48e666db1559117b97a2a4576ef5cc220ea90cd63fa062d0bcc889c8d'}}
ix=D/'income-reserve40968-index.json';ix.write_text(json.dumps(index,indent=2)+'\n');files[ix.name]=ix
archive=D/'bootstrap-land-income-reserve40968-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name)
with tarfile.open(archive)as t:
 for name,v in index['files'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==v['sha256']
delivery={'archive':str(archive),'bytes':archive.stat().st_size,'payloads':len(files),'sha256':sha(archive),
 'source':'40968d8412205831d1f2a75c29a21ee908062eb0','result':'Changed at17400; natural31331p1 loss,70permanent/4neutral losses,13703spent,0gen5 income. Unmerged. No ordinary0 or bootstrap acceptance.'}
(D/'income-reserve40968-delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps(delivery))
