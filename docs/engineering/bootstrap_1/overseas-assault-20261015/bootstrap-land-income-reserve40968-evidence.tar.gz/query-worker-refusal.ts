import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';import {isDeepStrictEqual} from 'node:util';
const source='/workspace/sketch-rts-land-income-reserve-control',dir='/workspace/.playtest/bootstrap-land-income-lead-20261015';
const tick=Number(process.argv[2]),copy=(v:any)=>JSON.parse(JSON.stringify(v));
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const saved=JSON.parse(gunzipSync(readFileSync(dir+`/reserve40968-from17400-to21600.frames/${tick}.json.gz`)).toString());
const report=JSON.parse(readFileSync(dir+'/reserve40968-from17400-to21600.json','utf8'));
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {restoreSnapshotIntoGame,snapshotGame}=await load('src/shared/sim.ts');
const {planAiOwnerCommandEntries}=await load('src/ai/planner-context.ts');
const {bootstrapScripts}=await load('src/ai/bootstrap_1/policy.ts');
const {readV6Intel}=await load('src/ai/policy/v6/intel.ts');
const {sameGround}=await load('src/shared/terrain.ts');
const {routeTravelTicks,groundSteeringRoute}=await load('src/shared/route-selection.ts');
const {armedFoes,retreatLandTravelTicks}=await load('src/ai/bootstrap_1/safe-land-route.ts');
const setup=report.setup,match=bootstrapMatches(setup.seed,[setup.map],tick+1,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===setup.side&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game);
const memory=copy(saved.memories.p0),claims:any[]=[],runs:any[]=[];let captured:any;
const scripts=bootstrapScripts('v9_archer').map((script:any)=>({...script,
 ...(script.claimsUnits?{claimsUnits(view:any,owner:any,options:any){const ids=script.claimsUnits(view,owner,options);claims.push({script:script.id,ids:[...ids]});return ids;}}:{}),
 run(view:any,owner:any,options:any){const memoryBefore=copy(options.memory),result=script.run(view,owner,options);
  if(script.id==='economy')captured={snapshot:view,options:{...options,memory:memoryBefore},raw:copy(result??null)};
  runs.push({script:script.id,raw:copy(result??null)});return result;},
}));
const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',source:'external-agent',scripts,memory},{teams:game.teams});
const expected=(report.commands.find((row:any)=>row.tick===tick&&row.owner==='p0')??JSON.parse(readFileSync(dir+'/reserve40968-from21600-natural.json','utf8')).commands.find((row:any)=>row.tick===tick&&row.owner==='p0')).entries;
if(!captured)throw Error('No actual core economy input');
const view=captured.snapshot,options=captured.options,intel=readV6Intel(view,'p0',options),halls=view.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall'&&b.complete);
const intrusion=intel.intrusion,excluded=intrusion&&halls.slice().sort((a:any,b:any)=>Math.hypot(a.x-intrusion.building.x,a.y-intrusion.building.y)-Math.hypot(b.x-intrusion.building.x,b.y-intrusion.building.y))[0];
const mine=view.resources.find((m:any)=>m.id==='gold-gen-5'),foes=armedFoes(view,'p0',options);
const idle=view.units.filter((u:any)=>u.owner==='p0'&&u.kind==='worker'&&u.order.type==='idle');
const roads=idle.map((u:any)=>({id:u.id,hp:u.hp,x:u.x,y:u.y,sameGround:sameGround(view.map,u,mine),
 centerRoadTicks:routeTravelTicks(view.map,u,mine,'land',u.speed),safeRoadTicks:retreatLandTravelTicks(view,u,mine,foes),
 road:groundSteeringRoute(view.map,u,mine)}));
const output={classification:'Isolated exact full-pipeline wrapper delegates each actual script once, captures core economy input/raw commands and ownership callbacks. Supplemental no-feed/road queries occur after planner, never in native continuation. Static roads do not establish future safety.',source,tick,
 publicEntriesEqual:isDeepStrictEqual(copy(entries),expected),worldUnchanged:isDeepStrictEqual(copy(snapshotGame(game)),saved.snapshot),nextIdUnchanged:game.nextId===saved.nextId,
 rawEconomy:captured.raw,intrusion,halls,excludedHall:excluded,claims,rawScripts:runs,entries,roads,
 gen5:mine,gen5Hall:halls.find((b:any)=>Math.hypot(b.x-mine.x,b.y-mine.y)<=320),
 relevantWorkers:view.units.filter((u:any)=>u.owner==='p0'&&u.kind==='worker').map((u:any)=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order,carryingGold:u.carryingGold}))};
writeFileSync(dir+`/reserve40968-worker-refusal-${tick}.json`,JSON.stringify(output,null,2)+'\n');
if(!output.publicEntriesEqual||!output.worldUnchanged||!output.nextIdUnchanged)throw Error('Supplemental wrapper failed exact boundaries');
console.log(JSON.stringify({tick,publicEntriesEqual:output.publicEntriesEqual,worldUnchanged:output.worldUnchanged,
 coreRaw:captured.raw,excluded:excluded?.id,intrusionBuilding:intrusion?.building.id,intrusionThreat:intrusion?.threat,
 idle:roads.map((r:any)=>({id:r.id,centerRoadTicks:r.centerRoadTicks,safeRoadTicks:r.safeRoadTicks}))}));
