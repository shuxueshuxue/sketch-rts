import { readFileSync,writeFileSync,mkdirSync } from 'node:fs';
import { gzipSync,gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const source='/workspace/sketch-rts-land-income-reserve-control',dir='/workspace/.playtest/bootstrap-land-income-lead-20261015';
const inputDir=dir+'/reserve40968-from17400-to21600.frames',out=dir+'/reserve40968-builder-loss-20430-20700';
const copy=(v:any)=>JSON.parse(JSON.stringify(v)),load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const saved=JSON.parse(gunzipSync(readFileSync(inputDir+'/20430.json.gz')).toString());
const report=JSON.parse(readFileSync(dir+'/reserve40968-from17400-to21600.json','utf8'));
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {restoreSnapshotIntoGame,snapshotGame}=await load('src/shared/sim.ts');
const {runAiGameLoop}=await load('src/ai/game-runner.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner}=await load('scripts/bootstrap_1-planner.ts');
const setup=report.setup,match=bootstrapMatches(setup.seed,[setup.map],20700,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===setup.side&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
for(const [owner,memory]of Object.entries(saved.memories))memories.set(owner,copy(memory));
const planner=await createBootstrapCommandPlanner(memories),owners=Object.keys(setup.agents);
const frame=()=>copy({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)]))});
if(!isDeepStrictEqual(frame(),saved))throw Error('Initial complete restoration mismatch');
mkdirSync(out+'.frames',{recursive:true});const save=(label:string,f:any)=>writeFileSync(out+'.frames/'+label+'.json.gz',gzipSync(JSON.stringify(f)+'\n'));
const patient='unit-p0-worker-1678',hall='building-p0-townHall-17183',hits:any[]=[],events:any[]=[],commands:any[]=[],checks:any[]=[];
game.observer={hit(source:any,target:any,taken:number,hpBefore:number){if([patient,hall,'unit-p0-lancer-12771'].includes(target.id))hits.push({tick:game.tick,source:copy(source),target:copy(target),taken,hpBefore});}};
let previous=frame();save('20430',previous);
runAiGameLoop({...match,game,commandPlanner:(context:any)=>{const entries=planner(context);commands.push({tick:context.snapshot.tick,owner:context.owner,entries:copy(entries)});return entries;}},{onStep:()=>{
 const current=frame();
 for(const id of [patient,hall]){
  const before=[...previous.snapshot.units,...previous.snapshot.buildings].find((u:any)=>u.id===id),after=[...current.snapshot.units,...current.snapshot.buildings].find((u:any)=>u.id===id);
  if(before&&!after){events.push({tick:game.tick,id,before});save('before-loss-'+id,previous);save('after-loss-'+id,current);}
 }
 if(game.tick%15===0){save(String(game.tick),current);const expected=JSON.parse(gunzipSync(readFileSync(inputDir+'/'+game.tick+'.json.gz')).toString());checks.push({tick:game.tick,allCompleteEqual:isDeepStrictEqual(current,expected)});}
 previous=current;
}});
if(!checks.every(c=>c.allCompleteEqual))throw Error('Observer changed native replay');
writeFileSync(out+'.json',JSON.stringify({classification:'Passive native hit observer of fixed40968 actual changed-code continuation; all saved15tick fullworld/nextId/all3mem exactly match original40968 window. Not new0 or extra policy.',source,commit:report.commit,checks,hits,events,commands})+'\n');
console.log(JSON.stringify({out,checks,events,killingHits:hits.filter(h=>h.target.id===patient&&h.target.hp<=0)}));
