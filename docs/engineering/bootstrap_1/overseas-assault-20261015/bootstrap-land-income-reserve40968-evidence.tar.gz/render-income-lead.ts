import { createCanvas } from '@napi-rs/canvas';
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
const dir='/workspace/.playtest/bootstrap-land-income-lead-20261015',source='/workspace/sketch-rts-land-income-reserve-control';
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);installHeadlessCanvas();
for(const tick of [19035,20370,21600]){
 const input=dir+`/reserve40968-from17400-to21600.frames/${tick}.json.gz`,saved=JSON.parse(gunzipSync(readFileSync(input)).toString()),snapshot=saved.snapshot;
 const size=1400,view={x:0,y:0,width:size,height:size,zoom:size/snapshot.map.width},canvas=createCanvas(size,size),ctx=canvas.getContext('2d');
 drawWorld({ctx:ctx as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),
  selectedIds:new Set(['unit-p0-worker-1678','unit-p0-lancer-12771']),labels:{mercenaryStock:String,unitKind:String}});
 const mine=snapshot.resources.find((mine:any)=>mine.id==='gold-gen-5');
 ctx.strokeStyle='white';ctx.lineWidth=2;ctx.strokeRect((mine.x-260)*view.zoom,(mine.y-260)*view.zoom,520*view.zoom,520*view.zoom);
 ctx.fillStyle='rgba(0,0,0,.9)';ctx.fillRect(0,0,size,80);ctx.fillStyle='white';ctx.font='22px sans-serif';
 ctx.fillText(`Native saved changed-code continuation40968 tick${tick}; NOT ordinary0`,15,32);
 ctx.fillText(`cash ${snapshot.players.p0.gold}; gen5 ore ${mine.amount}; original controls/normal enemies`,15,63);
 const output=dir+`/income-reserve40968-native-${tick}.png`;writeFileSync(output,canvas.toBuffer('image/png'));
 writeFileSync(output+'.json',JSON.stringify({classification:'Native drawWorld of full saved changed-code continuation. Labelled white square is gen5; fresh facing tracker does not reproduce animation history.',source,input,view,tick},null,2));console.log(output);
}
