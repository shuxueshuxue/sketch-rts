import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const source='/workspace/sketch-rts-land-income-reserve-control';
const dir='/workspace/.playtest/bootstrap-land-income-lead-20261015';
const prefix='/tmp/bootstrap-land-army-evidence-20261015/production-root3bdb-archer-double-v8-ordinary0';
const out=dir+'/reserve40968-from17400-to21600',start=17400,end=21600;
const copy=(value:any)=>JSON.parse(JSON.stringify(value));
const load=(path:string)=>import(pathToFileURL(source+'/'+path).href);
const report=JSON.parse(readFileSync(prefix+'.json','utf8'));
const input=JSON.parse(readFileSync(dir+'/baseline3bdb-fine-17400-18000.frames/17400.json','utf8'));
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {runAiGameLoop}=await load('src/ai/game-runner.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner}=await load('scripts/bootstrap_1-planner.ts');
const {restoreSnapshotIntoGame,snapshotGame}=await load('src/shared/sim.ts');
const {upkeepGoldIncome}=await load('src/shared/mining.ts');
const selection=report.setup;
const match=bootstrapMatches(selection.seed,[selection.map],end,selection.unseen).find((m:any)=>m.subject===report.subject
 &&m.side===selection.side&&m.agents.p0.race===selection.agents.p0.race
 &&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
const game=bootstrapGame(match),memories=createAiMemoryProvider(),owners=Object.keys(match.agents);
restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
for(const owner of owners)memories.set(owner,copy(input.memories[owner]));
const planner=await createBootstrapCommandPlanner(memories);
const frame=()=>copy({snapshot:snapshotGame(game),nextId:game.nextId,
 memories:Object.fromEntries(owners.map(owner=>[owner,memories.get(owner)]))});
if(!isDeepStrictEqual(frame(),input))throw Error('Full input world/nextId/all3memory restore mismatch');
mkdirSync(out+'.frames',{recursive:true});
const save=(f:any)=>writeFileSync(out+'.frames/'+f.snapshot.tick+'.json.gz',gzipSync(JSON.stringify(f)+'\n'));
const baselinePaths=[dir+'/baseline3bdb-fine-17400-18000',
 '/workspace/.playtest/bootstrap-land-army-macro-20261015/production3bdb-economic-fine-18000-18600',
 dir+'/baseline3bdb-fine-18600-19200',
 '/workspace/.playtest/bootstrap-land-army-macro-20261015/production3bdb-economic-fine-19200-19800'];
const baseCommands=new Map<string,any>();
for(const path of baselinePaths)for(const row of JSON.parse(readFileSync(path+'.json','utf8')).commands)
 baseCommands.set(row.tick+':'+row.owner,row.entries);
const baseline=(tick:number)=>{
 const path=baselinePaths[tick<=18000?0:tick<=18600?1:tick<=19200?2:3];
 return JSON.parse(readFileSync(path+'.frames/'+tick+'.json','utf8'));
};
const commands:any[]=[],economy:any[]=[],deaths:any[]=[],deliveries:any[]=[],hallEvents:any[]=[],prefixChecks:any[]=[],rows:any[]=[];
let firstPublicDifference:any,firstCheckpointDifference:any,previousUnits=new Map<string,any>(copy(game.units).map((u:any)=>[u.id,u]));
let knownHalls=new Map<string,any>(copy(game.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall')).map((b:any)=>[b.id,b]));
const summarize=()=>({tick:game.tick,winner:game.match.winner??null,cash:game.players.p0.gold,
 supplyUsed:game.players.p0.supplyUsed,supplyCap:game.players.p0.supplyCap,
 mines:copy(game.resources.filter((m:any)=>['gold-seat1-main','gold-gen-2','gold-gen-5'].includes(m.id))),
 ownHalls:copy(game.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall')),
 ownWorkers:copy(game.units.filter((u:any)=>u.owner==='p0'&&u.kind==='worker')),
 stats:copy(game.match.stats)});
save(frame());rows.push(summarize());
runAiGameLoop({...match,game,commandPlanner:(context:any)=>{
 const entries=planner(context),row={tick:context.snapshot.tick,owner:context.owner,entries:copy(entries)};
 commands.push(row);
 const expected=baseCommands.get(row.tick+':'+row.owner);
 if(expected&&!firstPublicDifference&&!isDeepStrictEqual(copy(entries),expected))firstPublicDifference={...row,expected};
 if(context.owner==='p0')for(const entry of entries)if(entry.scriptId==='v6Economy')economy.push({tick:row.tick,entry:copy(entry),budgetCash:context.snapshot.players.p0.gold});
 return entries;
}},{onStep:()=>{
 const units=new Map<string,any>(game.units.map((u:any)=>[u.id,u]));
 for(const [id,before] of previousUnits){
  if(before.owner!=='p0')continue;
  const current=units.get(id);
  if(!current)deaths.push({tick:game.tick,before});
  else if(before.kind==='worker'&&before.order.type==='mine'&&before.order.phase==='return'&&before.carryingGold>0
    &&current.carryingGold===0&&current.order.type==='mine'&&current.order.phase==='toMine')deliveries.push({tick:game.tick,id,
     resourceId:before.order.resourceId,raw:before.carryingGold,net:upkeepGoldIncome(before.carryingGold,game.players.p0.supplyUsed),cashAfter:game.players.p0.gold});
 }
 previousUnits=new Map(copy(game.units).map((u:any)=>[u.id,u]));
 const halls=game.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall');
 for(const hall of halls){const old=knownHalls.get(hall.id);if(!old||!old.complete&&hall.complete)
  hallEvents.push({tick:game.tick,type:!old?'foundation':'complete',hall:copy(hall),cash:game.players.p0.gold,stats:copy(game.match.stats)});}
 knownHalls=new Map(copy(halls).map((b:any)=>[b.id,b]));
 if(game.tick%15===0||game.tick===end||game.match.winner){
  const f=frame();save(f);
  if(game.tick<=19800&&!firstCheckpointDifference){
   const expected=baseline(game.tick),check={tick:game.tick,world:isDeepStrictEqual(f.snapshot,expected.snapshot),
    nextId:f.nextId===expected.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,isDeepStrictEqual(f.memories[owner],expected.memories[owner])]))};
   prefixChecks.push(check);if(!check.world||!check.nextId||!Object.values(check.memories).every(Boolean))firstCheckpointDifference=check;
  }
 }
 if(game.tick%600===0||game.tick===end||game.match.winner){rows.push(summarize());
  writeFileSync(out+'.progress.json',JSON.stringify({classification:'Changed-code continuation, not ordinary0',source,tick:game.tick,
   firstPublicDifference,firstCheckpointDifference,hallEvents,newMineDeliveries:deliveries.filter(row=>row.resourceId==='gold-gen-5'),last:rows.at(-1)})+'\n');
  console.log(JSON.stringify({tick:game.tick,cash:game.players.p0.gold,halls:halls.length,
   hallEvents:hallEvents.map(e=>({tick:e.tick,type:e.type,id:e.hall.id})),newMineDeliveries:deliveries.filter(row=>row.resourceId==='gold-gen-5').length}));
 }
}});
const output={classification:'Fixed40968 changed-code full3AI native continuation from actual3bdb ordinary17400 world/nextId/all3memory. Not a new ordinary0 or completed acceptance.',source,commit:'40968d8412205831d1f2a75c29a21ee908062eb0',
 inputFrame:dir+'/baseline3bdb-fine-17400-18000.frames/17400.json',setup:selection,start,endTick:game.tick,winner:game.match.winner??null,
 firstPublicDifference,firstCheckpointDifference,prefixChecks,commands,economy,deaths,deliveries,hallEvents,rows};
writeFileSync(out+'.json',JSON.stringify(output)+'\n');
console.log(JSON.stringify({out,firstPublicDifference,firstCheckpointDifference,permanentDeaths:deaths.filter(d=>d.before.expiresTick===undefined).length,
 hallEvents,newMineDeliveries:deliveries.filter(row=>row.resourceId==='gold-gen-5')}));
