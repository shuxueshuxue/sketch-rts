# 7f68d379 真实自然后缀负例（规则 2）

固定源 7f68d379，1476 项 runtime 源与184项冻结对手前后全真。实际226890完整before-P0严格恢复，正常3AI重放30tick，以33公开attempt/0hit及226920全部world/id/3mem逐值闭合；评价后缀从226920算。此前是225600 af→226650 1a→226875 7f换码链，绝非普通0或新种子分数。

后缀到250411，winner=null。21619次公开attempt、319原生命中、2419观察事件、1567次P0规划。226896首leg属于重复prefix；227079第二短leg原生完整结束是新后缀证据。50739随后231960/232032/232104炮击farm1409从320到104，未摧毁；232650被敌spirit击沉。4058杀7敌永久兵；两甲板召唤师、上岸ravager、priest及四艘舰艇合计8己永久死亡。33582在232868因己priest死且敌甲板乘员而被p2接管，单列为被俘非沉船/nonNativeUnitsLost，其后炮杀三艘友船。native XP导致4058 maxHP320→427并补最大血量差，非治疗。

资本377.33→349.33，28金原生码头维修支出，未恢复中立赏金或矿收入。243000..250200共13份周期完整档：carrier同pose/HP/10永久cargo、无实际nativeboard、同loading/target与farm104/gold349.33，临时spirit变化仍刷新progress。不是整个world固定或无限失败证明。最后P0对敌实际伤害233662；较早状态误将234257所有owner流当末次P0敌伤，原raw保留并在outcome勘误。

实际正常250410完整3AI思考后before-step观察器请求，再执行1步至250411停止；不是600边界、自然败局或任意horizon验收。后到600边界偏好未成为原source协议，不重跑改数字。末窗从真实严格可恢复250320输入正常3AI重放91tick：7个pre-P0世界/id/3mem、77公开attempt/0hit与最终250411全部严格相等。辅助event流未重演，未假定final再restore幂等。

50739真实232380/530近敌均在mortar min180以内，arc/lane有效，232380 cooldown0也无合法近身射击；原aggregate coast odds仍计完整舰队战力。原native已在后退17.2348px/s，队列为空，直到232590才策略撤退；本包只读query不叫修复，不以改1.3/血线掩盖。query-v1错误导入/失败日志保留，v2正确原生导出成功；无Game/step/fullplanner。

原137 boarding34800续局缺口与原容器未提交修改恢复缺口仍在。原source及已封focused包永久不改；本负例未合入root/main，三路线、正常冻结v5/v7/v8与完整最终矩阵/地图/未见种子验收仍未完成。
