import { readFileSync, writeFileSync, mkdirSync, appendFileSync, renameSync, existsSync } from "node:fs";
import { gzipSync, gunzipSync } from "node:zlib";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { isDeepStrictEqual } from "node:util";
import { NativeLedger } from "./observer-ledger.ts";
const D = "/workspace/.playtest/cabin-clinical-loading-sequence-20261016", cap = JSON.parse(readFileSync(D + "/fixed-runtime.json", "utf8")), S = cap.sourceRoot, H = "unit-p0-carrier-25442", sha = (v) => createHash("sha256").update(v).digest("hex"), copy = (v) => JSON.parse(JSON.stringify(v)), load = (p) => import(pathToFileURL(S + "/" + p).href), atomic = (p, v) => {
  writeFileSync(p + ".tmp", v);
  renameSync(p + ".tmp", p);
}, emit = (n, v) => appendFileSync(D + "/" + n + ".jsonl", JSON.stringify(v) + "\n");
if (existsSync(D + "/actual-launch.json")) throw Error("Already launched");
if (sha(readFileSync(import.meta.filename)) !== cap.driverSHA256 || sha(readFileSync(D + "/observer-ledger.ts")) !== cap.observerSHA256) throw Error("Fixed driver mismatch");
function verify() {
  const changed = Object.entries(cap.hashes).filter(([p, h]) => sha(readFileSync(S + "/" + p)) !== h).map(([p]) => p), head = execFileSync("git", ["-C", S, "rev-parse", "HEAD"], { encoding: "utf8" }).trim(), status = execFileSync("git", ["-C", S, "status", "--porcelain"], { encoding: "utf8" });
  if (changed.length || head !== cap.head || status) throw Error("Source changed");
  return { files: Object.keys(cap.hashes).length, head, status, changed };
}
const raw = readFileSync(cap.inputPath);
if (sha(raw) !== cap.inputSHA256) throw Error("Input changed");
for (const [k, h] of [["layoutPath", "layoutSHA256"], ["orderPath", "orderSHA256"]]) if (sha(readFileSync(cap[k])) !== cap[h]) throw Error("Mathematical plan changed");
const input = JSON.parse(gunzipSync(raw).toString()), layout = JSON.parse(readFileSync(cap.layoutPath, "utf8")), construct = JSON.parse(readFileSync(cap.orderPath, "utf8"));
if (!construct.foundFull16) throw Error("Constructive static order absent");
const startedAtUtc = (/* @__PURE__ */ new Date()).toISOString(), sourcePre = verify();
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider }, { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runAiGameLoop }, { checkCommandLegality }, { shipCabinUsage, isInCabin, leaveCabin, cabinGroupSelection }, { shipPassengers, localToWorld, shipProfile }, { passengerLandingSpot }, { sameGround, walkableGoal }, { effectiveCombatRating }, { deckPointFits, deckLoad }, { assaultExpedition }] = await Promise.all([load("src/shared/sim.ts"), load("src/ai/planner-context.ts"), load("scripts/bootstrap_1-planner.ts"), load("src/ai/game-runner.ts"), load("src/shared/sim/command-validation.ts"), load("src/shared/ship-cabin.ts"), load("src/shared/ship-geometry.ts"), load("src/shared/naval.ts"), load("src/shared/terrain.ts"), load("src/ai/policy/v6/strength.ts"), load("src/shared/decks.ts"), load("src/ai/policy/naval.ts")]);
const g = createGame("bareDuel"), memory = createAiMemoryProvider();
restoreSnapshotIntoGame(g, input.snapshot, input.nextId);
for (const [o, v] of Object.entries(input.memories)) memory.set(o, copy(v));
const full = () => copy({ snapshot: snapshotGame(g), nextId: g.nextId, memories: Object.fromEntries(Object.keys(input.memories).map((o) => [o, memory.get(o)])) }), initial = full(), restore = { world: isDeepStrictEqual(initial.snapshot, input.snapshot), nextId: g.nextId === input.nextId, all3mem: isDeepStrictEqual(initial.memories, input.memories) };
if (g.tick !== cap.start || Object.values(restore).some((v) => !v)) throw Error("Full restore mismatch");
const fr = frozenPolicyRoot(), frozenCheck = () => {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([p, h]) => sha(readFileSync(fr + "/" + p)) !== h).map(([p]) => p);
  if (changed.length || frozenPolicyManifest.rulesVersion !== 2 || Object.keys(frozenPolicyManifest.files).length !== 184) throw Error("Frozen changed");
  return { rulesVersion: 2, revision: frozenPolicyManifest.revision, files: 184, changed };
}, frozenPre = frozenCheck(), normal = await createBootstrapCommandPlanner(memory);
if (!isDeepStrictEqual(full(), initial)) throw Error("Setup changed input");
const agents = JSON.parse(readFileSync("/workspace/.playtest/cabin-repacking-native-capability-20261016/actual-launch.json", "utf8")).agents;
const counts = { commands: 0, hits: 0, events: 0, p0ClinicalPlans: 0, steps: 0 }, ledger = new NativeLedger(g.units, g.buildings), lastHit = /* @__PURE__ */ new Map();
for (const p of ["/workspace/.playtest/cabin-ferry-implementation-ade-20261016/native-candidate-194400-195600/hits.jsonl", "/workspace/.playtest/cabin-ferry-implementation-ade-20261016/native-candidate-natural-from195600/hits.jsonl"]) for (const l of readFileSync(p, "utf8").split("\n")) if (l) {
  const h = JSON.parse(l);
  if (h.tick < 202800) lastHit.set(h.target, h);
}
const wantedInside = layout.insideIds, openOrder = construct.projectedInsertionOrder, goal = { x: 7408, y: 6576 };
let phase = "clear", nextOpen = 0, commandIndex, lastSignature = "", completed = false, result, clinicalFailureReason;
class ClinicalFailure extends Error {
}
for (const n of ["commands", "hits", "events", "effects", "states", "controller-decisions"]) writeFileSync(D + "/" + n + ".jsonl", "");
mkdirSync(D + "/frames");
const controller = () => ({ phase, nextOpen, order: openOrder.map((x) => x.id) }), capture = (stage) => atomic(D + "/frames/" + g.tick + "-" + stage + ".json.gz", gzipSync(JSON.stringify({ ...full(), clinicalController: controller(), checkpointStage: stage, commandIndex })));
function state(stage) {
  const boat2 = g.units.find((u) => u.id === H), cargo2 = boat2 ? shipPassengers(g.units, boat2) : [], row = copy({ tick: g.tick, stage, commandIndex, controller: controller(), hull: boat2, usage: boat2 ? shipCabinUsage(g, boat2) : null, cargo: cargo2.map((u) => ({ id: u.id, hp: u.hp, deck: u.deck, cabin: u.cabin, order: u.order })), targetArmy: g.units.filter((u) => wantedInside.includes(u.id) || openOrder.some((x) => x.id === u.id)).map((u) => ({ id: u.id, x: u.x, y: u.y, hp: u.hp, radius: u.radius, deck: u.deck, cabin: u.cabin, order: u.order })) });
  emit("states", row);
  const signature = JSON.stringify([phase, nextOpen, row.cargo.map((u) => [u.id, u.cabin?.shipId])]);
  if (signature !== lastSignature) {
    lastSignature = signature;
    capture("physical-" + stage + (commandIndex === void 0 ? "" : "-" + commandIndex));
  }
  if (g.tick % 15 === 0) atomic(D + "/progress.json", JSON.stringify({ tick: g.tick, phase, nextOpen, cargo: cargo2.length, inside: cargo2.filter(isInCabin).length, counts, pid: process.pid }));
}
function observe(stage) {
  for (const e of ledger.observe(g.tick, stage, g.units, g.buildings, lastHit)) emit("events", { ...e, eventIndex: counts.events++, commandIndex });
  state(stage);
}
g.observer = { hit(a, t, d, b) {
  const h = copy({ tick: g.tick, attacker: a.id, attackerOwner: a.owner, target: t.id, targetOwner: t.owner, damage: d, hpBefore: b, hpAfter: t.hp });
  emit("hits", h);
  lastHit.set(t.id, h);
  counts.hits++;
} };
function physicalReady(s, boat2) {
  const crew = shipPassengers(s.units, boat2), expected = /* @__PURE__ */ new Set([...wantedInside, ...openOrder.map((x) => x.id)]), inside = new Set(wantedInside);
  return boat2.owner === "p0" && crew.length === 26 && crew.every((u) => u.owner === "p0" && expected.has(u.id) && u.hp > 0 && isInCabin(u) === inside.has(u.id)) && openOrder.every((p) => {
    const u = crew.find((u2) => u2.id === p.id);
    return u?.deck?.shipId === H && !isInCabin(u) && Math.hypot(u.deck.x - p.target.x, u.deck.y - p.target.y) <= 1e-6;
  }) && crew.filter((u) => !isInCabin(u)).every((u) => deckPointFits(boat2, u, u.deck, s.units, true)) && !shipCabinUsage(s, boat2).overCapacity && deckLoad(s.units, boat2) <= shipProfile(boat2).loadCapacity && crew.reduce((n, u) => n + effectiveCombatRating(s, u), 0) >= layout.required;
}
function publicPlan(s) {
  const boat2 = s.units.find((u) => u.id === H && u.hp > 0);
  if (!boat2) throw new ClinicalFailure("Clinical hull lost");
  const cargo2 = shipPassengers(s.units, boat2);
  const commands = [];
  if (phase === "clear") {
    if (!cargo2.length) phase = "inside";
    else {
      const ordered = [...cargo2.filter((u) => !isInCabin(u)), ...cargo2.filter(isInCabin)];
      for (const u of ordered) {
        const shadow = s.units.map((v) => structuredClone(v)), h = shadow.find((v) => v.id === H), p = shadow.find((v) => v.id === u.id);
        h.order = { type: "unload", ...goal, avoidCombat: true };
        if (isInCabin(p) && !leaveCabin({ ...s, units: shadow }, p)) continue;
        const spot = passengerLandingSpot(s.map, h, p.id, shadow);
        if (!spot || !sameGround(s.map, spot, goal)) continue;
        commands.push({ type: "unload", unitIds: [H], ...goal, avoidCombat: true });
        if (isInCabin(u)) commands.push({ type: "leaveCabin", unitIds: [u.id] });
        commands.push({ type: "unloadPassenger", transportId: H, passengerId: u.id }, { type: "stop", unitIds: [H] }, { type: "move", unitIds: [u.id], ...goal, avoidCombat: true });
        return commands;
      }
      return [];
    }
  }
  if (phase === "inside") {
    const units = wantedInside.map((id) => s.units.find((u) => u.id === id && u.hp > 0));
    if (units.some((u) => !u)) throw new ClinicalFailure("An intended cabin body died");
    if (units.every((u) => u.cabin?.shipId === H)) {
      phase = "open";
      commands.push({ type: "stop", unitIds: [H] });
    } else {
      const ashore = units.filter((u) => !u.deck && !(u.order.type === "board" && u.order.transportId === H));
      if (ashore.length) commands.push({ type: "board", unitIds: ashore.map((u) => u.id), transportId: H });
      const entering = cabinGroupSelection(s, units.filter((u) => u.deck?.shipId === H && !isInCabin(u) && u.order.type !== "enterCabin"));
      if (entering.length) commands.push({ type: "enterCabin", unitIds: entering });
      return commands;
    }
  }
  if (phase === "open") {
    const drifted = openOrder.slice(0, nextOpen).findIndex((p) => {
      const u = s.units.find((u2) => u2.id === p.id);
      return !u || u.hp <= 0 || u.deck?.shipId !== H || u.cabin || Math.hypot(u.deck.x - p.target.x, u.deck.y - p.target.y) > 1e-6;
    });
    if (drifted >= 0) nextOpen = drifted;
    while (nextOpen < openOrder.length) {
      const plan = openOrder[nextOpen], u = s.units.find((v) => v.id === plan.id && v.hp > 0);
      if (!u) throw new ClinicalFailure("Open body died");
      if (u.cabin) throw new ClinicalFailure("Unexpected inside open-body candidate");
      if (u.deck?.shipId !== H) {
        if (!(u.order.type === "board" && u.order.transportId === H)) commands.push({ type: "board", unitIds: [u.id], transportId: H });
        return commands;
      }
      const p = plan.target;
      if (Math.hypot(u.deck.x - p.x, u.deck.y - p.y) > 1e-6) {
        const target2 = localToWorld(boat2, p);
        commands.push({ type: "move", unitIds: [u.id], ...target2, avoidCombat: true });
        return commands;
      }
      nextOpen++;
    }
    if (physicalReady(s, boat2)) phase = "complete";
  }
  return commands;
}
const planner = (ctx) => {
  if (ctx.owner !== "p0") return normal(ctx);
  counts.p0ClinicalPlans++;
  capture("before-clinical-p0");
  const commands = publicPlan(ctx.snapshot);
  emit("controller-decisions", { tick: g.tick, controller: controller(), commands });
  return commands.map((command) => ({ playerId: "p0", scriptId: "manual-clinical-packing", source: ctx.source, command }));
};
atomic(D + "/actual-launch.json", JSON.stringify({ classification: cap.classification, startedAtUtc, pid: process.pid, cwd: process.cwd(), argv: process.argv, sourcePre, frozenPre, restore, inputPath: cap.inputPath, inputSHA256: sha(raw), head: cap.head, start: cap.start, maximumObservationEnd: cap.end, agents, subjectMode: "P0 policy replaced by the declared clinical public cargo controller; its original AI memory is not advanced or edited. P1/P2 frozen normal15tick AI unchanged. Existing unrelated P0 orders continue native updates without new P0 policy instructions.", manualControllerScope: "Carrier25442 and intended28 actual roster only. Public waves unload to actual pickup island, native board/stow, then exact move attempts; no positions/body/HP/gold/quota overwritten.", driverSHA256: cap.driverSHA256, observerSHA256: cap.observerSHA256, layoutSHA256: cap.layoutSHA256, orderSHA256: cap.orderSHA256 }, null, 2));
capture("strict-restored");
state("restored");
class CapabilityComplete extends Error {
}
try {
  result = runAiGameLoop({ name: "Declared clinical packing capability", game: g, agents, maxTicks: cap.end, thinkInterval: 15, commandPlanner: planner }, { afterCommand(e) {
    if (e.scriptId !== "manual-clinical-packing") return;
    emit("effects", copy({ tick: e.tick, owner: e.owner, scriptId: e.scriptId, command: e.command, legalityBefore: checkCommandLegality(e.before, e.owner, e.command) ?? null, snapshotChanged: !isDeepStrictEqual(e.before, e.after), before: e.before.units.filter((u) => u.id === H || wantedInside.includes(u.id) || openOrder.some((x) => x.id === u.id)), after: e.after.units.filter((u) => u.id === H || wantedInside.includes(u.id) || openOrder.some((x) => x.id === u.id)) }));
  }, onCommand(e) {
    commandIndex = counts.commands++;
    emit("commands", copy({ tick: e.tick, commandIndex, owner: e.owner, scriptId: e.scriptId, command: e.command }));
    observe("after-command");
    commandIndex = void 0;
  }, beforeStep() {
    observe("before-step");
    ledger.beforeStep(g.units);
  }, onStep() {
    counts.steps++;
    observe("after-step");
    if (g.tick % 15 === 0) capture("after-step");
    if (phase === "complete") {
      const hull = g.units.find((u) => u.id === H);
      if (hull && physicalReady(g, hull)) {
        completed = true;
        throw new CapabilityComplete();
      }
      phase = "open";
      nextOpen = 0;
    }
  } });
} catch (e) {
  if (e instanceof ClinicalFailure) {
    clinicalFailureReason = String(e);
    capture("controlled-clinical-failure");
  } else if (!(e instanceof CapabilityComplete)) {
    capture("unexpected-interruption");
    atomic(D + "/interruption.json", JSON.stringify({ tick: g.tick, counts, controller: controller(), error: String(e), scope: "Unexpected harness failure, not capability result; latest full frame is observational, not automatic resume boundary." }, null, 2));
    throw e;
  }
}
const final = full(), boat = g.units.find((u) => u.id === H), cargo = boat ? shipPassengers(g.units, boat) : [], power = cargo.reduce((n, u) => n + effectiveCombatRating(g, u), 0), target = g.buildings.find((b) => b.id === input.memories.p0.naval.ferries[H].targetId), currentExpedition = target ? assaultExpedition(final.snapshot, "p0", { version: "v7", teams: { p0: "a", p1: "b", p2: "b" }, memory: memory.get("p0") }, target) : void 0;
const sourcePost = verify(), frozenPost = frozenCheck(), p0MemoryUnchanged = isDeepStrictEqual(final.memories.p0, input.memories.p0);
if (!p0MemoryUnchanged) throw Error("Manual clinical mode changed P0 policy memory");
capture("final");
atomic(D + "/final.json.gz", gzipSync(JSON.stringify(final)));
atomic(D + "/report.json", JSON.stringify({ classification: cap.classification, startedAtUtc, endedAtUtc: (/* @__PURE__ */ new Date()).toISOString(), pid: process.pid, start: cap.start, end: g.tick, completedClinicalSequence: completed, finiteObservationOnly: !completed, clinicalFailureReason, winner: g.match.winner, counts, restore, sourcePre, sourcePost, frozenPre, frozenPost, p0PolicyMemoryUnchanged: true, controller: controller(), cargoCount: cargo.length, insideCount: cargo.filter(isInCabin).length, usage: boat ? shipCabinUsage(g, boat) : null, mass: boat ? deckLoad(g.units, boat) : null, capacity: boat ? shipProfile(boat)?.loadCapacity : null, allActualOpenFit: boat ? cargo.filter((u) => !isInCabin(u)).every((u) => deckPointFits(boat, u, u.deck, g.units, true)) : false, actualCargoPower: power, originalRequired: layout.required, currentEnemyRequired: currentExpedition?.required, actualReachedOriginalRequired: power >= layout.required, autonomousPolicyResult: false, elapsedMs: result?.elapsedMs, cpuMs: result?.cpuMs, finalSHA256: sha(readFileSync(D + "/final.json.gz")) }, null, 2));
console.log(JSON.stringify({ completedClinicalSequence: completed, end: g.tick, phase, nextOpen, cargo: cargo.length, power, originalRequired: layout.required, counts }));
