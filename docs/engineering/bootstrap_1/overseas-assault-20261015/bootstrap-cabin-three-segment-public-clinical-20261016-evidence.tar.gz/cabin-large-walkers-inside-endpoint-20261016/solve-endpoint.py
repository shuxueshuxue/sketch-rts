from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,math,hashlib,time
import numpy as np
from scipy.optimize import minimize
D=Path(__file__).resolve().parent;D.mkdir(exist_ok=True)
input=Path('/workspace/.playtest/cabin-compaction-static-layout-20261016/result.json');original=input.read_bytes();d=json.loads(original)
roster=json.loads((D/'actual-roster28.json').read_text())['bodies']
dropped=['unit-p0-summoner-8114','unit-p0-summoner-4085']
retained=[u for u in roster if u['id']not in dropped]
insideIds=[u['id']for u in retained if u['kind']=='emberRavager']+['unit-p0-summoner-38054']
assert len(retained)==26 and len(insideIds)==10
insideBodies=[u for u in retained if u['id']in insideIds]
assert all(u['cabinEligible']for u in insideBodies)and sum(u['cabinCost']for u in insideBodies)<=21
chosen=sorted([u for u in retained if u['id']not in insideIds],key=lambda u:(-u['rating'],u['id']))
insidePower=sum(u['rating']for u in insideBodies)
profile=d['actual']['profile'];poly=np.array([[p['x'],p['y']]for p in profile['deck']]);edges=np.roll(poly,-1,axis=0)-poly
normals=np.stack([-edges[:,1],edges[:,0]],axis=1);normals/=np.linalg.norm(normals,axis=1)[:,None]
radii=np.array([u['radius']for u in chosen]);obs=np.array([[p['x'],p['y'],p['radius']]for p in profile['obstacles']])
n=len(chosen);pairs=[(i,j)for i in range(n)for j in range(i+1,n)];rows=n*len(poly)+n*len(obs)+len(pairs)
def constraints(x,jac=False):
 p=x[:-1].reshape(n,2);t=x[-1];vals=[];J=[]
 for i in range(n):
  for a,normal in zip(poly,normals):
   vals.append(float((p[i]-a)@normal-radii[i]-1-t))
   if jac:
    row=np.zeros(2*n+1);row[2*i:2*i+2]=normal;row[-1]=-1;J.append(row)
  for o in obs:
   diff=p[i]-o[:2];dist=float(np.linalg.norm(diff));vals.append(dist-o[2]-radii[i]-1-t)
   if jac:
    row=np.zeros(2*n+1);row[2*i:2*i+2]=diff/max(dist,1e-12);row[-1]=-1;J.append(row)
 for i,j in pairs:
  diff=p[i]-p[j];dist=float(np.linalg.norm(diff));vals.append(dist-radii[i]-radii[j]-1-t)
  if jac:
   row=np.zeros(2*n+1);row[2*i:2*i+2]=diff/max(dist,1e-12);row[2*j:2*j+2]=-diff/max(dist,1e-12);row[-1]=-1;J.append(row)
 return np.asarray(J)if jac else np.asarray(vals)
obj=np.zeros(2*n+1);obj[-1]=-1
results=[];best=None;started=time.time()
for k in range(8):
 rng=np.random.default_rng(20261016+k)
 base=np.array([(x,y)for y in [-45,-15,15,45]for x in [-90,-30,30,90]],float)
 if k:base=base[rng.permutation(n)]+rng.uniform(-10,10,(n,2))
 else:
  prior=json.loads(Path('/workspace/.playtest/cabin-compartment-allocation-endpoint-20261016/result.json').read_text())['best']['endpoint']
  points={u['id']:np.array([u['x'],u['y']])for u in prior};missing=[u['id']for u in chosen if u['id']not in points]
  unused=[p for id,p in points.items()if id not in {u['id']for u in chosen}]
  assert len(missing)==len(unused)
  for id,p in zip(missing,unused):points[id]=p
  base=np.array([points[u['id']]for u in chosen])
 x0=np.r_[base.ravel(),-50.]
 res=minimize(lambda x:-x[-1],x0,jac=lambda x:obj,method='SLSQP',bounds=[(-profile['length']/2,profile['length']/2),(-profile['beam']/2,profile['beam']/2)]*n+[(-100,20)],constraints={'type':'ineq','fun':constraints,'jac':lambda x:constraints(x,True)},options={'maxiter':600,'ftol':1e-9,'disp':False})
 margin=float(np.min(constraints(np.r_[res.x[:-1],0.])))
 row={'start':k,'seed':20261016+k,'success':bool(res.success),'message':res.message,'iterations':int(res.nit),'objectiveSlack':float(res.x[-1]),'actualMinimumNativeGeometryClearance':margin,'endpoint':[{'id':u['id'],'radius':u['radius'],'rating':u['rating'],'x':float(res.x[2*i]),'y':float(res.x[2*i+1])}for i,u in enumerate(chosen)]}
 results.append(row)
 if best is None or margin>best['actualMinimumNativeGeometryClearance']:best=row
 (D/'progress.json').write_text(json.dumps({'starts':len(results),'bestMargin':best['actualMinimumNativeGeometryClearance'],'elapsedSeconds':time.time()-started},indent=2)+'\n')
 print(json.dumps({'start':k,'margin':margin,'iterations':int(res.nit),'elapsedSeconds':time.time()-started}),flush=True)
 if margin>1e-5:break
out={'classification':'Finite continuous mathematical endpoint feasibility search, no Game/step/planner/native simulation/production mutation. Hypothetical native-eligible inside allocation9actual ravagers plus38054; actual8114/4085 stay ashore, all other26 retained at unchanged HP/body. This allocation has NOT been executed. Native deckPointFits still must independently verify any positive endpoint. This cannot prove public move/board reachability or impossibility from negative optimization.',
 'inputPath':str(input),'inputSHA256':hashlib.sha256(original).hexdigest(),'sourceHead':'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804','maximumDeterministicStarts':8,'maximumIterationsPerStart':600,'actualStarts':len(results),'elapsedSeconds':time.time()-started,
 'insideIds':insideIds,'droppedIds':dropped,'hypotheticalAllocationNotExecuted':True,'insideQuota':sum(u['cabinCost']for u in insideBodies),'totalCargoMass':sum(u['mass']for u in retained),'insidePower':insidePower,'selectedOpenPower':sum(u['rating']for u in chosen),'totalPower':insidePower+sum(u['rating']for u in chosen),'required':d['actual']['originalRequired'],'totalPeople':26,
 'profile':profile,'chosen':chosen,'best':best,'allResults':results,'scope':'Coordinates are hypothetical endpoint layout only; no actual entity is moved and no future floor is credited. No claim optimizer is exhaustive or globally optimal.'}
assert input.read_bytes()==original
(D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
