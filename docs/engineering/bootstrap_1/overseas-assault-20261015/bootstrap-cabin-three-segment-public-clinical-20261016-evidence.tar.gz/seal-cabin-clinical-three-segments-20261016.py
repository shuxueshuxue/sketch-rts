from pathlib import Path
import json,hashlib,tarfile,datetime,io,os
B=Path('/workspace/.playtest');D=B/'cabin-clinical-three-segment-evidence-20261016';A=B/'bootstrap-cabin-three-segment-public-clinical-20261016-evidence.tar.gz'
assert not A.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=[B/x for x in ['cabin-clinical-loading-sequence-20261016','cabin-clinical-loading-sequence-resume-20261016','cabin-clinical-public-intent-handoff-20261016','cabin-clinical-raw-storage-20261016','cabin-large-walkers-inside-endpoint-20261016','cabin-final-admission-readonly-20261016','cabin-final-handoff-bridge-readonly-20261016','cabin-admitted-intent-return-readonly-20261016',D.name]]
files={}
for root in roots:
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if any(x in ['node_modules','runtime-tmp','__pycache__'] for x in rel.parts) or p.is_symlink() or not p.is_file() or p.name in ['syntax-check.mjs','INDEX.json']:continue
  files[str(p.relative_to(B))]=p
for p in [B/'cabin-compaction-static-layout-20261016/result.json',B/'cabin-compartment-allocation-endpoint-20261016/result.json',B/'cabin-repacking-native-capability-20261016/frames/202801-physical-after-step.json.gz',B/'cabin-ferry-implementation-ade-20261016/candidate-source.tar.gz',B/'cabin-load-capability-ade-20261016/root-frozen-source.tar.gz',B/'cabin-clinical-driver-independent-review-20261016/review.json',B/'reclaim-own-closed-clinical-raw-20261016.py',B/'cabin-clinical-raw-reclamation-20261016.log',Path(__file__)]:
 assert p.is_file(),str(p)
 files[str(p.relative_to(B))]=p
rows=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)}for name,p in sorted(files.items())]
index={'classification':'Sealed three-segment extra-public/manualP0 clinical capability, not autonomousAI/ordinary0/combat/victory. All actual raw streams/fullframes + immutable1474source/184manifest/497frozen archive + independent actual verification.','sourceHead':'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804','payloadFiles':len(rows),'payloadBytes':sum(r['bytes']for r in rows),'files':rows}
ib=(json.dumps(index,indent=2)+'\n').encode();(D/'INDEX.json').write_bytes(ib)
with tarfile.open(A,'w:gz',compresslevel=6)as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
 t.add(D/'INDEX.json',arcname=D.name+'/INDEX.json',recursive=False)
expected={r['path']:r for r in rows};seen=set();indices=[]
with tarfile.open(A,'r|gz')as t:
 for m in t:
  assert m.isfile(),m.name
  f=t.extractfile(m);h=hashlib.sha256();n=0
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
  if m.name==D.name+'/INDEX.json':assert n==len(ib) and h.hexdigest()==hashlib.sha256(ib).hexdigest();indices.append(m.name);continue
  assert m.name in expected and m.name not in seen,m.name
  r=expected[m.name];assert n==m.size==r['bytes']and h.hexdigest()==r['sha256'],m.name
  seen.add(m.name)
assert seen==set(expected)and len(indices)==1
assert all(p.stat().st_size==expected[name]['bytes']and sha(p)==expected[name]['sha256']for name,p in files.items()),'originals changed'
record={'sealedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(A),'bytes':A.stat().st_size,'sha256':sha(A),'payload':len(rows),'regularMembers':len(rows)+1,'indexPath':str(D/'INDEX.json'),'indexSHA256':hashlib.sha256(ib).hexdigest(),'streamAllPayloadSHABytesCoverage':True,'originalsUnchanged':True,'sourceHead':index['sourceHead'],'actualManualCapability':{'from':202801,'through':208741,'segments':3,'actualCargo':26,'inside':10,'open':16,'actualMass':4853,'actualPower':20.34819319223813,'required':20.115569375546702,'autonomousPolicyResult':False,'winner':None},'sourceCapsule':{'files':1474,'bytes':4487394,'sha256':'5896df3b433a782c515499f2e021d1861deab23d0ec88cb9b34cedba308c5c91'},'frozenSource':{'archiveFiles':497,'manifestFiles':184,'rulesVersion':2,'revision':'d1ae110f2edd99f9c7d899ed61557891ab587639','bytes':1190331,'sha256':'a43493bbbdb0e8b7e9810d64da6014e40b333d28f15f408249b5e74fe475f90a'}}
(B/'bootstrap-cabin-three-segment-public-clinical-20261016-delivery.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
