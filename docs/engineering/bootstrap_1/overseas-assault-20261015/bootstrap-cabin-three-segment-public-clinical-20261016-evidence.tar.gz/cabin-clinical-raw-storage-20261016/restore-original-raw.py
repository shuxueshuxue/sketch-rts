from pathlib import Path
import json,hashlib,tarfile,sys,os
O=Path(__file__).resolve().parent;meta=json.loads((O/'storage-manifest.json').read_text());destination=Path(sys.argv[1]).resolve()
if not(str(destination).startswith('/workspace/')or str(destination).startswith('/tmp/')):raise SystemExit('Choose a writable external restore directory under/workspace or/tmp')
destination.mkdir(parents=True,exist_ok=True)
expected={r['member']:r for r in meta['payload']}
with tarfile.open(meta['archive'],'r|gz')as t:
 for m in t:
  if m.name not in expected:continue
  r=expected.pop(m.name);assert m.isfile()and Path(m.name).name==m.name
  out=destination/m.name;tmp=destination/(m.name+'.tmp');assert not out.exists()and not tmp.exists(),'Refuse to overwrite an existing file'
  h=hashlib.sha256();size=0
  with tmp.open('wb')as f:
   source=t.extractfile(m)
   for b in iter(lambda:source.read(1024*1024),b''):f.write(b);h.update(b);size+=len(b)
  assert size==r['bytes']and h.hexdigest()==r['sha256'],'Exact raw restore failed'
  os.chmod(tmp,r['mode']);os.utime(tmp,ns=(r['mtimeNs'],r['mtimeNs']));os.replace(tmp,out)
  print(json.dumps({'restored':str(out),'bytes':size,'sha256':h.hexdigest()}))
assert not expected,'Missing original stream'
