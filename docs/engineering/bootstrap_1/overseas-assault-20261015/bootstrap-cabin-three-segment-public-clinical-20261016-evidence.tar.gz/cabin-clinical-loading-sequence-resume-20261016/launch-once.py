from pathlib import Path
import os,json,datetime
D=Path(__file__).resolve().parent
maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
current=int(Path('/sys/fs/cgroup/memory.current').read_text())
record={'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cgroupMax':maximum,'cgroupCurrent':current,'headroom':maximum-current,'requiredHeadroom':2*1024**3,'heapMiB':1024,'classification':'One bounded manual-subject clinical loading capability; normal frozen opponents unchanged, no autonomous policy score.'}
assert not(D/'actual-launch.json').exists(),'Already launched'
if maximum-current<2*1024**3:
 record['status']='prepared_only_insufficient_headroom';(D/'launch-guard.json').write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(75)
record['status']='launching_once';(D/'launch-guard.json').write_text(json.dumps(record,indent=2)+'\n')
os.environ['TMPDIR']=str(D/'runtime-tmp')
os.chdir('/workspace/sketch-rts-cabin-ferry-ade-control')
os.execvp('node',['node','--max-old-space-size=1024','--import','tsx',str(D/'resume-clinical-sequence-v2.ts')])
