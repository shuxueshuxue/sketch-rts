from pathlib import Path
import json,hashlib,tarfile,datetime,stat
D=Path('/workspace/.playtest/cabin-clinical-loading-sequence-20261016');O=Path('/workspace/.playtest/cabin-clinical-raw-storage-20261016');O.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
assert(D/'report.json').exists()
payload=[]
for name in ['states.jsonl','effects.jsonl']:
 p=D/name;s=p.stat();payload.append({'originalPath':str(p),'member':name,'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode),'mtimeNs':s.st_mtime_ns})
index=O/'INDEX.json';index.write_text(json.dumps({'classification':'Lossless archival storage of two closed exclusively owned clinical raw streams; all bytes retained, no simulation/source changes. Parent explicitly authorized reclaiming reconstructable duplicate plain copies.','payload':payload},indent=2)+'\n')
archive=O/'clinical-segment1-original-raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as t:
 for r in payload:t.add(r['originalPath'],arcname=r['member'],recursive=False)
 t.add(index,arcname='INDEX.json',recursive=False)
expected={r['member']:r for r in payload};count=0
with tarfile.open(archive,'r|gz')as t:
 for m in t:
  assert m.isfile();f=t.extractfile(m);h=hashlib.sha256();size=0
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
  if m.name=='INDEX.json':assert h.hexdigest()==sha(index)
  else:r=expected.pop(m.name);assert r['bytes']==size and r['sha256']==h.hexdigest()
  count+=1
assert not expected and count==3
for r in payload:
 p=Path(r['originalPath']);assert p.stat().st_size==r['bytes']and sha(p)==r['sha256']
# Only these two closed, exclusively owned duplicate plain files are removed,
# after full independent archive decompression SHA and size checks above.
for r in payload:Path(r['originalPath']).unlink()
out={'archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive),'payload':payload,'archiveRegularCount':3,'allDecompressionSHABytesVerified':True,'plainDuplicateCopiesReclaimed':True,'reclaimedPlainBytes':sum(r['bytes']for r in payload),'netBytesFreed':sum(r['bytes']for r in payload)-archive.stat().st_size,'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentAuthorization':'/root2026-10-16: own closed raw may be losslessly gzipped with full decompression SHA/bytes/restore metadata before reclaiming duplicate plain copies. No other raw/source/archive touched.','restore':'python3 /workspace/.playtest/cabin-clinical-raw-storage-20261016/restore-original-raw.py /workspace/.playtest/CHOSEN_EMPTY_RESTORE_DIR; writes states.jsonl/effects.jsonl, verifies exact bytes/SHA before atomic publish.'}
(O/'storage-manifest.json').write_text(json.dumps(out,indent=2)+'\n');(D/'RAW_STORAGE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
