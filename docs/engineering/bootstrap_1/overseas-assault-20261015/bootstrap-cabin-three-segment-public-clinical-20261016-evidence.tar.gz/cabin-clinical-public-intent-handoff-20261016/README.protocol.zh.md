# 原a7人工公开队列交接诊断（新第三段）

此段只验证原生能力，不是bootstrap自主AI成绩、普通0或完整比赛胜局。源仍为不可变a7；P0策略规划器由已声明人工临床controller替代，P0原策略memory不推进。P1/P2普通冻结对手照常每15tick执行，所有现有单位仍接受正常原生更新。

起点是第二段208201完整实际snapshot/nextId/三方memory。其25cargo、10inside和15open均为原生实际状态，实际兵力19.448193小于原门槛20.115569；此处未把静态26人终点当成实际。

只改变本外部诊断controller：真实portrait卸3174，在真实空位开放时同时接受两个岸上单位的合法公开board意图。3174先走三个实际shore waypoints，再执行其queued board；23349即时执行board。每个人只在实际附着后接受公开move校准，其实际终点误差须≤1e-6。岸路/到达顺序/后来boardUnit是否成功都由原生实际推进决定，不预写deck、order、queue、HP或到达时刻，不绕过公开命令发布。

原生契约区分：canBoard(grid4)在公开board发布时验证；queued board激活与后来ferryUnits附着不重新调用该门，实际甲板插入仍用boardUnit(grid2)。若附着失败，原生会取消board；不能据原先合法接受就冒称保证成功。本诊断完整记录公开合法性、snapshotChanged、实际frames/队列与死亡账。手动shore往返只是声明的额外公开微操，不是AI自动规划进展。

观察上限3600tick仅为有限能力试验，非比赛失败期限。只有poststep真实26cargo（9rav+38054真inside）、16open各到原合法终点、质量/舱容/实际HP兵力满足原门槛时才报告临床完成。若有限范围未成只保留实际末档，不声明全局不可能。临床装载成功亦不证明可安全海战、卸岸、获胜或bootstrap验收。

旧D1/D2/封a7包不改写。原容器未提交修改缺口仍未恢复。
