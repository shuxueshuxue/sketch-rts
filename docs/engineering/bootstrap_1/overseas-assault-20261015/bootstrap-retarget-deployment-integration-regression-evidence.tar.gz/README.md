# Retarget × native deployment integration regression

This package is an incremental review artifact, not a fixed-source complete-game result. The 89625 fixture is the existing unmodified full saved world with nextId and both policy memories. Its SHA256 is in AUDIT.json. The regression explicitly removes the old observed enemy shipyard and assigns the companion another actually live enemy hall on the same island. That objective combination is counterfactual; it was not observed as a match failure. No resource, population, enemy army, map, seed, production API, or game-rule change is part of this review.

## Concrete issue and result

The archived one-pass V2 retargeted only the stale first boat. A live companion retained another building ID on the same island. Downstream assembly and landing use targetId, so the real 15+14 crew cohort was split and the full planner returned both boats. Root now triggers on a real own ferry with a stale observed target, then synchronizes active real ferries on that observed island while keeping a selected approach and a live companion's existing sea goal.

The new portable test contains six cases: three family versions of the real two-hull planner and public-command/native-step integration (both sailing, first waits, all 29 passengers stay on their original boats at tick89626); live companion without approach retains its original to; no stale target leaves valid objectives distinct; another observed island retains its target/anchor/to/approach and ordinary cancellation. Mission state comparison excludes targetId, targetGround and normal progress refresh; all other real mission fields are preserved in the same-island positive cases. Snapshot mutation and other owners' policy-memory mutation are rejected.

New integration source: 6/6 pass, strict tsc exit0. Replacing only retargetAssaultFerries with the archived V2 implementation recreates naval.ts byte-for-byte SHA56171c0831fd57e57d3b6879214a451992434ff9830a60d6058f72a23532d0cc, identical to the original read-only query source. The same regression then has four expected failures and two passing boundary cases. The root source, main, other fixed worktrees and active games were not changed or restarted.

## Portable file and execution

Copy only portable/src/ai/bootstrap_1/assault-retarget-deployment.test.ts into the integration checkout, which already contains the referenced fixture. The fixture is included here only to make the evidence self-contained. Run the project's vitest on that single file. The local review was run with `/workspace/sketch-rts/node_modules/.bin/vitest run src/ai/bootstrap_1/assault-retarget-deployment.test.ts --reporter=verbose` under /tmp/retarget-v2-deployment-review. Read-only symlinks resolved project imports; the isolated test is the only new source file. Current selected integration modules and the exact old naval source are captured for audit; they do not replace a complete source manifest.

## Preserved negative evidence and limits

The initial other-island case wrongly required the first boat to remain sailing even when the other boat genuinely belonged to another island, removing assembly strength. That assertion was removed; ordinary admission is deliberately retained, not relaxed. The failed initial log remains. The first standalone tsc invocation used an incomplete symlink mirror and had missing-module errors plus one strict optional teams issue; its log remains, and the final tsc passed after resolving imports and asserting the fixture's present teams.

The original query's post-return direct gate field was not meaningful once the planner had already cancelled the mission; that raw earlier output is retained separately. The authoritative query compares full-planner branches from restored prequery memory. The original construction-error log is retained.

No complete new match was run by this review. These local checks do not establish a win, family acceptance, frozen-opponent generalization, or fulfillment of the bootstrap_1 goal. Rules2, the frozen migration baseline and normal opponents remain requirements. Original-container uncommitted changes remain unavailable and unrecovered.
