import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import inspector from 'node:inspector';
import { build } from '/workspace/sketch-rts-deck-casualty-v2-control/node_modules/esbuild/lib/main.js';
const P='/workspace/.playtest/bootstrap-deck-casualty-v2-20261016', W='/workspace/sketch-rts-deck-casualty-v2-control', D=P+'/native-step-allocation-40350';
assert.equal(existsSync(D),false,'Never overwrite prior evidence');mkdirSync(D);
const cap=JSON.parse(readFileSync(P+'/source.json','utf8')),sha=v=>createHash('sha256').update(v).digest('hex'),json=v=>JSON.parse(JSON.stringify(v));
function check(){const bad=Object.entries(cap.files).filter(([p,h])=>sha(readFileSync(W+'/'+p))!==h).map(([p])=>p);assert.deepEqual(bad,[]);assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:W,encoding:'utf8'}).trim(),cap.head);assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:W,encoding:'utf8'}),'');return{files:Object.keys(cap.files).length,head:cap.head,bad};}
const sourcePre=check(), changes=[];
function replaceExact(text,old,next,label){assert.equal(text.split(old).length,2,'Exactly one '+label);changes.push({label,old,next});return text.replace(old,next);}
const originals=Object.fromEntries(['sim.ts','ship-navigation.ts','route-selection.ts','ship-collisions.ts'].map(p=>[p,readFileSync(W+'/src/shared/'+p,'utf8')]));
let sim=originals['sim.ts'];
const st=sim.indexOf('export function stepGame(game: Game) {'), en=sim.indexOf('\nexport function snapshotGame(',st);assert.ok(st>=0&&en>st);
let step=sim.slice(st,en);
for(const call of ['bindGangwayCrewRules(game.units,game);','updateWindField(game.map, game.tick);','refreshVeteranFrame(game, emptyVeteranFrame);','syncBuildingBodies(game);','updateWorldEffects(game);','updateProjectiles(game);','updateUnitStatusEffects(game);','updateConstruction(game);','updateTraining(game);','updateResearch(game);','updateResources(game);','game.miningFrame = prepareMiningFrame(game);','updateMercenaryCamps(game);','updateItems(game);','updateMoonWellHealing(game);','updateRegeneration(game);','updateTowerAttacks(game);','beginShipMotionFrame(game.units,game.map,game.buildingBodiesSeen ?? game.buildings,vessels);','beginShipPlanningFrame(game.units,game.tick,vessels);','updateShipGangways(game.map,game.units,game.tick,game);','prepareCrewRendezvous(game.map,game.units);','game.boardingHolds=boardingHoldShips(game.units);','defenses=prepareShipDefenseFrame(game,(ship,range,visit)=>forEachNearbyEnemyUnit(game,ship.owner,ship,range,visit),game.boardingHolds);','const ferry = updateUnits(game,defenses,navalFrame,emptyVeteranFrame);','slideUnits(game);','separateUnits(game, navalFrame);','removeExpiredUnits(game);','removeDead(game);']){
 assert.ok(step.includes(call),call);step=step.replaceAll(call,`(globalThis as any).__nativeMark('stage',${JSON.stringify(call)},{tick:game.tick});\n  ${call}`);
}
sim=sim.slice(0,st)+step+sim.slice(en);
sim=replaceExact(sim,'    const unit = ordered[i]!;','    const unit = ordered[i]!;\n    (globalThis as any).__nativeMark("unit-enter",unit.id,{kind:unit.kind,order:unit.order,tick:game.tick});','updateUnits unit marker');
let ship=originals['ship-navigation.ts'];
const signature='function planShipRouteImpl(map: SeaMap, ship: Unit, goal: Point & {heading?:number}, trafficClear: (from:ShipPose,to:ShipPose)=>boolean, budget:number, voyage:boolean, nested:boolean,state?:ShipRouteSearchState): RouteResult|undefined {';
ship=replaceExact(ship,signature,signature+'\n  (globalThis as any).__nativeMark("ship-route-enter",ship.id,{goal,budget,voyage,nested,state:state?.phase,depth:routeSearchDepth,nodes:state?.nodes?.length,heap:state?.heap?.length,entrances:state?.entrances?.map(e=>({cell:e.cell,paths:e.points.length,points:e.points.map(p=>p.length)})),prefixes:state?.prefixes?.length,trafficFits:state?.trafficFits?.length,cursor:state?.entranceCursor});','ship route enter');
const loop='  for (let at = best; at >= 0; at = previous[at]!)\n    path.push(pose(at));';
ship=replaceExact(ship,loop,`  const diagnosticSeen=new Map<number,number>(),diagnosticChain:number[]=[];
  for (let at = best; at >= 0; at = previous[at]!) {
    const prior=diagnosticSeen.get(at);
    if(prior!==undefined){
      const trace=diagnosticChain.map(id=>({id,parent:previous[id],cost:cost(id),rawCost:costs[id],stamp:stamps[id]}));
      (globalThis as any).__nativeMark('SHIP_PARENT_CYCLE',ship.id,{goal,best,size,generation,nested,routeSearchDepth,state:state?.phase,repeat:at,firstIndex:prior,trace});
      throw new Error('DIAGNOSTIC_EXACT_SHIP_PARENT_CYCLE');
    }
    diagnosticSeen.set(at,diagnosticChain.length);diagnosticChain.push(at);
    path.push(pose(at));
  }
  (globalThis as any).__nativeMark('ship-route-reconstructed',ship.id,{best,size,generation,nested,routeSearchDepth,state:state?.phase,nodes:diagnosticChain.length});`,'ship parent exact repeated ID throw');
ship=replaceExact(ship,'  const pause=()=>{','  const pause=()=>{\n    (globalThis as any).__nativeMark("ship-pause",ship.id,{phase:state?.phase,nodes:reached.size,heap:frontier.length,entrances:entrances.size,prefixes:prefixes.size,trafficFits:savedTraffic.size,cursor:state?.entranceCursor});','pause counts');
let collision=originals['ship-collisions.ts'];
collision=replaceExact(collision,'    cached.byHull.set(key, { b: copyPolygon(b), result });','    cached.byHull.set(key, { b: copyPolygon(b), result });\n    const n=cached.byHull.size;if((n&(n-1))===0)(globalThis as any).__nativeMark("solid-cache-size",ship.id,{bodyId:body.id,entries:n,keyLength:key.length,bPoints:b.length,resultPoints:result.length});','solid cache counts');
let route=originals['route-selection.ts'];
const rs=route.indexOf('export function groundSteeringRoute('),re=route.indexOf('\n}\n',rs)+2;assert.ok(rs>=0&&re>rs);
const oldRoute=route.slice(rs,re);
const newRoute=`export function groundSteeringRoute(map: Pick<GameMap, "terrain">, from: Point, goal: Point): [Point, ...Point[]] {
 (globalThis as any).__nativeMark('ground-route-enter','',{from,goal,caller:new Error('ground route').stack});
 const route:[Point,...Point[]]=[from],seen=new Map<string,number>();seen.set(JSON.stringify([from.x,from.y]),0);
 let point=from,next=steerPoint(map,point,goal);
 while(next.x!==point.x||next.y!==point.y){const key=JSON.stringify([next.x,next.y]),prior=seen.get(key);
  if(prior!==undefined){(globalThis as any).__nativeMark('GROUND_XY_CYCLE','',{from,goal,route,next,prior});throw new Error('DIAGNOSTIC_EXACT_GROUND_XY_CYCLE');}
  seen.set(key,route.length);route.push(next);point=next;next=steerPoint(map,point,goal);
 }
 (globalThis as any).__nativeMark('ground-route-exit','',{points:route.length});return route;
}`;
changes.push({label:'ground exact repeatedXY throw',old:oldRoute,next:newRoute});route=route.slice(0,rs)+newRoute+route.slice(re);
const inputPath=P+'/oom-phase-diagnostic-40305/phase-inputs/40350-step-enter.json.gz',raw=readFileSync(inputPath),input=JSON.parse(gunzipSync(raw).toString());
writeFileSync(D+'/instrumentation.json',JSON.stringify({classification:'External bundle only, exact repeated parent/XY throws diagnostic, never truncates/returns fallback. One native step from actual post40350 commands; no AI planner, public commands or simulation rule modifications. Fixed source immutable.',sourcePre,inputPath,inputSHA256:sha(raw),driverSHA256:sha(readFileSync(import.meta.filename)),changes,originalFileSHA:Object.fromEntries(Object.entries(originals).map(([k,v])=>[k,sha(v)]))},null,2));
await build({stdin:{contents:`export {bootstrapGame,bootstrapMatches} from '${W}/src/ai/bootstrap_1/benchmark.ts'; export {stepGame,snapshotGame,restoreSnapshotIntoGame} from '${W}/src/shared/sim.ts';`,resolveDir:W,loader:'ts'},bundle:true,platform:'node',format:'esm',outfile:D+'/instrumented.mjs',sourcemap:true,plugins:[{name:'external-native-diagnostic',setup(b){b.onLoad({filter:/\/shared\/(sim|ship-navigation|route-selection|ship-collisions)\.ts$/},args=>{const file=args.path.slice(args.path.lastIndexOf('/')+1);assert.equal(args.path,W+'/src/shared/'+file);return{contents:({'sim.ts':sim,'ship-navigation.ts':ship,'route-selection.ts':route,'ship-collisions.ts':collision})[file],loader:'ts',resolveDir:W+'/src/shared'};});}}]});
const profiler=new inspector.Session();profiler.connect();let samples=0;profiler.post('HeapProfiler.startSampling',{samplingInterval:32768},()=>{});
let marks=0;globalThis.__nativeMark=(event,id,data)=>{appendFileSync(D+'/markers.jsonl',JSON.stringify({index:marks++,event,id,data,memory:process.memoryUsage()})+'\n');if(event==='ship-route-enter'||event==='ship-pause'){profiler.post('HeapProfiler.getSamplingProfile',{},(err,res)=>{if(!err)writeFileSync(D+'/heap-sample-'+(++samples)+'.json',JSON.stringify(res));});}};
const m=await import(pathToFileURL(D+'/instrumented.mjs').href),s=cap.selection,match=m.bootstrapMatches(s.seed,[s.mapId],Number.MAX_SAFE_INTEGER,s.unseen).find(x=>x.subject===s.subject&&x.side===s.side&&x.agents.p0.race===s.race&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')===s.opponents.join('+'));
assert.ok(match);const g=m.bootstrapGame(match);m.restoreSnapshotIntoGame(g,input.snapshot,input.nextId);
const restore={world:isDeepStrictEqual(json(m.snapshotGame(g)),input.snapshot),nextId:g.nextId===input.nextId};assert.ok(Object.values(restore).every(Boolean));assert.equal(g.tick,40350);
writeFileSync(D+'/launch.json',JSON.stringify({pid:process.pid,sourcePre,restore,inputPath,actualPhase:input.event,bundleSHA256:sha(readFileSync(D+'/instrumented.mjs')),execArgv:process.execArgv},null,2));
let error=null;const started=performance.now();globalThis.__nativeMark('step-enter','',{tick:g.tick});try{m.stepGame(g);globalThis.__nativeMark('step-exit','',{tick:g.tick});}catch(e){error={name:e.name,message:e.message,stack:e.stack};globalThis.__nativeMark('caught-error','',error);}
writeFileSync(D+'/after-state.json.gz',gzipSync(JSON.stringify({tick:g.tick,snapshot:m.snapshotGame(g),nextId:g.nextId,memories:input.memories,classification:'Diagnostic mutated native state after failed/successful single step, not a valid scored continuation.'})));
const result={pid:process.pid,error,restore,elapsedMs:performance.now()-started,tick:g.tick,marks,sourcePost:check(),resources:process.memoryUsage()};writeFileSync(D+'/result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
