固定独立源码 `5db730d574bf6dc20e29b1874e442c043d24f122`，基于 `0f5bf01a05046169d4fb42322376f767b97bcc83`。只抽取原生只读接口，未接入 AI 过滤、订单、评分或规则；root/main、其他控制树和冻结对手未改。原容器未提交修改的恢复缺口仍保留。

`native-primitives.patch` 仅涉及 sim.ts 和两个可移植组件测试；`fixed-source.tar.gz` 与 pre/post 清单封存 1431 个逐文件匹配提交的源码、数据、测试及配置。冻结 manifest 仍为 `0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774`。

- `createNativeQueryFrame` 用同一个原生构造器新建索引，保留队伍首次出现顺序、x/y 桶顺序、桶内原数组顺序。新 map 壳拥有自己的建筑 overlay，不把 Game 的 factory/callback/旧缓存拷进去，也不转移原 runtime previous-index 证书。直接查询真实运行时 frame 可保留其旧桶和 live body 语义；快照重建不被冒称任意 mid-pass 等价。
- `nativeAutomaticAttackIntent` 直接复用原生候选资格、目标评分、跟踪投射物预扣、冷却及严格 +60 重选。原 unit 引用保证 self-threat 身份；输出 acquire/pursue/engage/return/backOut 等分支意图，engage 不承诺本 tick 已开火或安全。查询不运行未来 help-call、队列、autocast、伤害或移动。
- `buildingMoveArrival` 复用原生 walkToward、walkDestination 和身体接触算式，输出 destination/bodyContact 原因。它是当前速度和状态下的静态正常地面移动步估计，不预测推挤、分离、移动身体、未来控制、群体到达或船体碰撞。

顺序单 worker 检查：9 文件 63 项通过，原 sim.test 精准选取 10 项通过、104 项无关测试跳过，tsc --noEmit 退出 0。先前 circle-only 初稿的两项失败和静态诊断已保留，未隐藏成通过。

| 真实边界 | 静态接口与原生观察 |
| --- | --- |
| 7905→7921（召唤） | 静态第7步 destination；真实7912提前到达，7913 acquire 86.030/自身52，7914开始追击。不是圆形身体接触；详见独立 errata。原7921死亡保留。 |
| 10425→10441（弓手路线 footman） | 15步内无提前到达；10440宏观命令改为 attackMove，10441在自身55射程内原地作战。 |
| 16245→16275（弓手路线骑射） | 第1步 bodyContact；真实16246早停，16247原690.47 help-call 目标重选为78.63内骑士（自身330），未发生追敌 move。仍受伤、治疗冷却未好，不据此称安全或已治疗。 |

共65个逐tick完整 world+nextId 检查点：候选加只读查询与 exact0f 原生源码逐值全等，也与原封真实档全等。三个观察点中 live frame 与 canonical snapshot 查询输出也相等；这不是所有时刻的普遍证明。`original-witness/` 保存完整原 world/id/3memory 与原命令。组件重放只重新执行已录公开命令和原生模拟，三方 policy memory 是未变的原始输入见证，未伪称重新运行 AI。

尚未集成 primitive，尚未接 AI filter，未开新普通0比赛，未宣称 bootstrap 完成。后续需 root 审查该共享接口后，再单独定源评估过滤候选。旧3bdb26107败、9ba24840败和5f43714胜的成绩归属保持独立。
