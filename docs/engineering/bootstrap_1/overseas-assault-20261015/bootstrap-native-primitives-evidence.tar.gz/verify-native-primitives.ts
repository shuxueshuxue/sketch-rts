import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, dirname, extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { build } from '/workspace/sketch-rts/node_modules/esbuild/lib/main.js';

const root = '/workspace/sketch-rts-native-primitives-control';
const out = '/workspace/.playtest/bootstrap-native-primitives-20261016';
const old = '/workspace/.playtest/bootstrap-care-native-intent-20261016';
const base = '0f5bf01a05046169d4fb42322376f767b97bcc83';
const copy = (v: any) => JSON.parse(JSON.stringify(v));
const sha = (v: any) => createHash('sha256').update(v).digest('hex');
const source = readFileSync(root + '/src/shared/sim.ts', 'utf8');
const baseSource = execFileSync('git', ['show', base + ':src/shared/sim.ts'], { cwd: root, encoding: 'utf8' });
const spec: Record<string, any> = {
  '7905': { patient: 'unit-p0-emberRavager-1079', start: 7905, end: 7921 },
  '10425': { patient: 'unit-p0-footman-1072', start: 10425, end: 10441 },
  '16245': { patient: 'unit-p0-horseArcher-4294', start: 16245, end: 16275 },
};
const name = process.argv[2]; if (!spec[name]) throw Error('Specify 7905,10425,16245');
const current = spec[name], archived = JSON.parse(readFileSync(old + '/native-intent-' + name + '.json', 'utf8'));
const loadFrame = (tick: number) => JSON.parse(gunzipSync(readFileSync(old + '/native-intent-' + name + '.frames/' + tick + '.json.gz')).toString());
const saved = loadFrame(current.start);
mkdirSync(out + '/component-' + name + '.frames', { recursive: true });

const hooks = ['updateAttackOrder', 'backOutOfDeadZone', 'moveToward', 'advanceMoveOrder'];
const wrappers = `
function __nativeQueryObserve(event:any){(globalThis as any).__nativePrimitiveTrace?.(event);}
let __checkingNativeQuery=false,__attackRecord:any;
function __queryPair(game:any,unit:any,navalFrame:boolean){
 const before=JSON.stringify(snapshotGame(game)),id=game.nextId;
 __checkingNativeQuery=true;
 try{
 const live=nativeAutomaticAttackIntent(game,unit,navalFrame);
 const canonical=nativeAutomaticAttackIntent(createNativeQueryFrame(game),unit);
 if(before!==JSON.stringify(snapshotGame(game))||id!==game.nextId)throw Error('Query mutated native world');
 return {live,canonical,navalFrame,inputUnchanged:true};
 }finally{__checkingNativeQuery=false;}
}
function updateAttackOrder(game:any,unit:any,navalFrame=true){
 if(unit.id!==${JSON.stringify(current.patient)})return __observed_updateAttackOrder(game,unit,navalFrame);
 if(__attackRecord)return __observed_updateAttackOrder(game,unit,navalFrame);
 const record:any={event:'attack',tick:game.tick,before:{x:unit.x,y:unit.y,order:{...unit.order},cooldown:unit.cooldown},...__queryPair(game,unit,navalFrame),moves:[]};
 const previous=__attackRecord;__attackRecord=record;
 try{__observed_updateAttackOrder(game,unit,navalFrame);}finally{__attackRecord=previous;}
 record.after={x:unit.x,y:unit.y,order:{...unit.order},cooldown:unit.cooldown};
 record.actualAction=record.actualBackOut?'backOut':record.moves.length?'pursue':unit.order.type==='move'?'return':record.actualTargetId?'engage':'none';
 record.intentMatches=record.actualAction===record.live.action&&(!record.actualTargetId||record.actualTargetId===record.live.targetId);
 __nativeQueryObserve(record);
}
function backOutOfDeadZone(game:any,unit:any,target:any,navalFrame=true){
 const result=__observed_backOutOfDeadZone(game,unit,target,navalFrame);
 if(!__checkingNativeQuery&&__attackRecord&&unit.id===${JSON.stringify(current.patient)}){__attackRecord.actualTargetId=target.id;__attackRecord.actualBackOut=result;}
 return result;
}
function moveToward(unit:any,x:any,y:any,map:any,units:any=[],navalFrame=true){
 const before={x:unit.x,y:unit.y};__observed_moveToward(unit,x,y,map,units,navalFrame);
 if(!__checkingNativeQuery&&__attackRecord&&unit.id===${JSON.stringify(current.patient)})__attackRecord.moves.push({before,goal:{x,y},after:{x:unit.x,y:unit.y}});
}
function advanceMoveOrder(game:any,unit:any,order:any,navalFrame:boolean){
 if(unit.id!==${JSON.stringify(current.patient)})return __observed_advanceMoveOrder(game,unit,order,navalFrame);
 const before=JSON.stringify(snapshotGame(game)),id=game.nextId;
 const one=buildingMoveArrival(game,unit,order,1),horizon=buildingMoveArrival(game,unit,order,15);
 const canonical=buildingMoveArrival(createNativeQueryFrame(game),unit,order,15);
 if(before!==JSON.stringify(snapshotGame(game))||id!==game.nextId)throw Error('Arrival query mutated native world');
 __observed_advanceMoveOrder(game,unit,order,navalFrame);
 __nativeQueryObserve({event:'move',tick:game.tick,one,horizon,canonical,after:{x:unit.x,y:unit.y,order:{...unit.order}},
 inputUnchanged:true,oneMatches:!one||unit.order.type==='idle'&&one.point.x===unit.x&&one.point.y===unit.y});
}
`;

async function compile(mode: 'baseline' | 'candidate') {
  let sim = mode === 'baseline' ? baseSource : source;
  if (mode === 'candidate') {
    for (const hook of hooks) {
      if (sim.split('function ' + hook + '(').length !== 2) throw Error('Ambiguous hook ' + hook);
      sim = sim.replace('function ' + hook + '(', 'function __observed_' + hook + '(');
    }
    const needle = 'const target = nearestEnemyTarget(game, unit, unit.owner === "neutral" ? 150 : AUTO_ACQUIRE_RANGE, navalUnitFrame);';
    if (sim.split(needle).length !== 2) throw Error('Idle acquisition hook ambiguous');
    sim = sim.replace(needle, `const query = unit.id===${JSON.stringify(current.patient)}?__queryPair(game,unit,navalUnitFrame):undefined;\n${needle}\nif(query)__nativeQueryObserve({event:'idle',tick:game.tick,...query,actualTargetId:target?.id,intentMatches:query.live.targetId===target?.id});`);
    sim += wrappers;
  }
  const module = out + '/component-' + name + '-' + mode + '.mjs';
  const bundled = new Set(['src/shared/sim.ts','src/sdk/commands/frame.ts','src/shared/sim/command-frame-runtime.ts','src/shared/sim/frame.ts'].map(p => root + '/' + p));
  await build({ stdin: { contents: "export {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame} from './src/shared/sim.ts';export {issueCommandFrame} from './src/sdk/commands/frame.ts';", resolveDir: root, loader: 'ts' },
    bundle: true, platform: 'node', format: 'esm', outfile: module, packages: 'external', plugins: [{ name: 'native-primitives-proof', setup(api) {
      api.onResolve({ filter: /^\./ }, args => { let path = resolve(args.resolveDir, args.path); if (!extname(path)) path += '.ts'; return bundled.has(path) ? { path } : { path, external: true }; });
      api.onLoad({ filter: /\/src\/shared\/sim\.ts$/ }, args => ({ contents: sim, loader: 'ts', resolveDir: dirname(args.path) }));
    } }] });
  return import(pathToFileURL(module).href);
}

const results: any = {}, traces: any[] = [];
for (const mode of ['baseline', 'candidate'] as const) {
  const sim = await compile(mode), game = sim.createGame('bareDuel', { aiPlayers: [] });
  sim.restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  // The original sealed boundary replay also has a real hit observer. Keep
  // that same native complete-frame path, rather than inventing a certificate.
  game.observer = { hit() {} };
  const allMemory = copy(saved.memories), memoryBefore = JSON.stringify(allMemory);
  const frames: any[] = [], checks: any[] = [];
  (globalThis as any).__nativePrimitiveTrace = (event: any) => traces.push(copy(event));
  function save() {
    const actual = copy({ snapshot: sim.snapshotGame(game), nextId: game.nextId });
    const expected = loadFrame(game.tick);
    checks.push({ tick: game.tick, oldWorld: isDeepStrictEqual(actual.snapshot, expected.snapshot), oldId: actual.nextId === expected.nextId });
    frames.push(actual);
    writeFileSync(out + '/component-' + name + '.frames/' + game.tick + '-' + mode + '.json.gz', gzipSync(JSON.stringify(actual) + '\n'));
  }
  save();
  while (game.tick < current.end) {
    const commands = archived.commands.filter((c: any) => c.tick === game.tick).flatMap((c: any) => c.entries);
    if (commands.length) sim.issueCommandFrame(game, commands);
    sim.stepGame(game); save();
  }
  delete (globalThis as any).__nativePrimitiveTrace;
  results[mode] = { frames, checks, allInputMemoryUnchanged: JSON.stringify(allMemory) === memoryBefore };
}
const sameNative = results.candidate.frames.map((f: any, i: number) => ({ tick: current.start + i, world: isDeepStrictEqual(f.snapshot, results.baseline.frames[i].snapshot), nextId: f.nextId === results.baseline.frames[i].nextId }));
const result = {
  classification: 'Three real saved boundaries, recorded public-command native component replay. Candidate readonly queries instrument native branches; baseline is exact original0f5bf sim with the same unchanged dependency files. This is not a new AI ordinary0 or full-policy replay. All3 policy memories are read-only input witnesses, not recomputed.',
  name, start: current.start, end: current.end, patient: current.patient, base,
  source: { path: root, sim: sha(source), originalSim: sha(baseSource), simUnchanged: sha(readFileSync(root + '/src/shared/sim.ts')) === sha(source) },
  checks: { baselineOld: results.baseline.checks, candidateOld: results.candidate.checks, sameNative, all3MemoryInputUnchanged: results.baseline.allInputMemoryUnchanged && results.candidate.allInputMemoryUnchanged,
    readonlyQueries: traces.every(t => t.inputUnchanged), attackIntentMatches: traces.filter(t => t.event === 'attack' || t.event === 'idle').every(t => t.intentMatches), oneStepBuildingMatches: traces.filter(t => t.event === 'move').every(t => t.oneMatches) },
  traces,
};
writeFileSync(out + '/component-' + name + '.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ name, sameNative: sameNative.every((c: any) => c.world && c.nextId), oldExact: result.checks.baselineOld.every((c: any) => c.oldWorld && c.oldId), readonly: result.checks.readonlyQueries, intent: result.checks.attackIntentMatches, arrival: result.checks.oneStepBuildingMatches, traceCount: traces.length }));
if (!sameNative.every((c: any) => c.world && c.nextId) || !result.checks.readonlyQueries || !result.checks.attackIntentMatches || !result.checks.oneStepBuildingMatches || !result.source.simUnchanged) throw Error('Native primitive proof failed; preserve output');
