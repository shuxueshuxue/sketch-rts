import {readFileSync} from 'node:fs';import{gunzipSync}from'node:zlib';
import{createNativeQueryFrame,buildingMoveArrival}from'/workspace/sketch-rts-native-primitives-control/src/shared/sim.ts';
const base='/workspace/.playtest/bootstrap-care-native-intent-20261016';
for(const [name,id] of [['7905','unit-p0-emberRavager-1079'],['10425','unit-p0-footman-1072'],['16245','unit-p0-horseArcher-4294']]) {
const input=JSON.parse(gunzipSync(readFileSync(`${base}/native-intent-${name}.frames/${name}.json.gz`)).toString());const trace=JSON.parse(readFileSync(`${base}/native-intent-${name}.json`,'utf8'));
const command=trace.commands.find((v:any)=>v.tick===Number(name)&&v.owner==='p0').entries.find((v:any)=>v.command.type==='move'&&v.command.unitIds.includes(id)).command;
const unit=input.snapshot.units.find((u:any)=>u.id===id),q=createNativeQueryFrame(input.snapshot);
console.log(JSON.stringify({name,unit,command,predicted:buildingMoveArrival(q,unit,command,15)}));}
