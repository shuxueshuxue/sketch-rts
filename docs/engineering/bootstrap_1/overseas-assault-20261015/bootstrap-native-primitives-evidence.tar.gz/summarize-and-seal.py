from pathlib import Path
import hashlib, io, json, subprocess, tarfile, shutil
from gzip import decompress

p = Path('/workspace/.playtest/bootstrap-native-primitives-20261016')
old = Path('/workspace/.playtest/bootstrap-care-native-intent-20261016')
root = Path('/workspace/sketch-rts-native-primitives-control')
sha = lambda data: hashlib.sha256(data).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
rows = []
for name in ['7905', '10425', '16245']:
    case = json.loads((p / f'component-{name}.json').read_text())
    original = json.loads((old / f'native-intent-{name}.json').read_text())
    traces = case['traces']
    rows.append({
        'case': name, 'start': case['start'], 'end': case['end'], 'patient': case['patient'],
        'checkpointCount': len(case['checks']['sameNative']),
        'allCandidateBaselineWorldIdEqual': all(c['world'] and c['nextId'] for c in case['checks']['sameNative']),
        'allOriginalWorldIdEqual': all(c['oldWorld'] and c['oldId'] for c in case['checks']['candidateOld']),
        'all3MemoryInputWitnessesUnchanged': case['checks']['all3MemoryInputUnchanged'],
        'allQueriesWorldIdUnchanged': case['checks']['readonlyQueries'],
        'allNativeAttackIntentMatches': case['checks']['attackIntentMatches'],
        'allReturnedOneStepArrivalPredictionsMatch': case['checks']['oneStepBuildingMatches'],
        'allLiveAndCanonicalIntentEqualInTheseObservedBranches': all(t['live'] == t['canonical'] for t in traces if t['event'] in ['attack', 'idle']),
        'allLiveAndCanonicalArrivalEqualInTheseObservedBranches': all(t.get('horizon') == t.get('canonical') for t in traces if t['event'] == 'move'),
        'actualEarlyArrivals': [t for t in traces if t['event'] == 'move' and t.get('one')],
        'actualAcquisitions': [t for t in traces if t['event'] == 'idle'],
        'actualAttackIntents': [t for t in traces if t['event'] == 'attack'],
        'firstStatic15StepEstimate': next((t.get('horizon') for t in traces if t['event'] == 'move'), None),
        'recordedPublicCommandCount': sum(len(c['entries']) for c in original['commands']),
    })
    # Full original world/id/all3mem witnesses stay distinct from component's
    # recomputed native world/id. No fictitious recomputation of policy memory.
    dest = p / 'original-witness' / name; dest.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(old / f'native-intent-{name}.json', dest / 'recorded-commands-and-original-trace.json')
    for tick in range(case['start'], case['end'] + 1):
        shutil.copyfile(old / f'native-intent-{name}.frames' / f'{tick}.json.gz', dest / f'{tick}-complete-world-id-all3mem.json.gz')

pre = json.loads((p / 'source-preflight.json').read_text())
post = json.loads((p / 'source-postflight.json').read_text())
summary = {
    'classification': 'Native readonly primitive extraction only; no AI consumer/filter/score/order/rules change. Recorded-public-command component validation, not an ordinary0 or full-policy replay.',
    'branch': 'codex/bootstrap-native-primitives-20261016', 'source': str(root), 'head': head, 'base': post['base'],
    'scope': ['src/shared/sim.ts', 'src/shared/sim/native-query.test.ts', 'src/shared/sim/building-move-arrival.test.ts'],
    'sourceProof': {'files': len(post['files']), 'allMatchCommit': post['allMatchCommit'], 'prePostSourceEqual': post['prePostSourceEqual'], 'gitClean': not post['gitStatus'], 'frozenManifestSHA256': post['frozenManifestSHA256']},
    'tests': {'focusedFiles': 9, 'focusedPassed': 63, 'selectedOriginalSimPassed': 10, 'selectedOriginalSimSkipped': 104, 'tscExit': 0, 'workerCount': 1},
    'cases': rows,
    'limits': [
        'Snapshot constructor uses exact native canonical index constructors, but its fresh current-coordinate buckets are not asserted equal to an arbitrary live mid-pass bucket frame. All observed three-boundary queries matched both ways; no universal equivalence claim.',
        'Native direct query requires the original world unit reference, branch-time cooldown and existing native full/grounded flag. It does not synthesize a Game or a grounded-frame certificate. Snapshot frame defaults to complete target rules.',
        'Automatic intent applies to a living nonship idle/automatic-attack branch only. Queues, autocasts, neutral prelude cleanup, future help calls, firing/aim readiness and future motion are not simulated.',
        'Building arrival is static current-speed/status normal-land-step geometry. Destination-envelope buildingId is a witness, not proof that one body alone caused the route endpoint. No crowd/hull/push/separation/future control prediction.',
        'Returned one-step arrival aggregate is one-directional; the three independently known real boundaries are separately recorded. It is not a general no-false-negative theorem.',
        'All3 memories are complete original recorded inputs preserved unchanged, not recomputed by this recorded-command native replay.',
        'No ordinary0/new AI game, no strategy acceptance, no AI score/ownership/filter/goal integration. 3bdb26107 and9ba24840 losses and5f43714 win remain distinct prior source results.',
        'Original broken-container uncommitted recovery gap remains.'
    ],
}
(p / 'native-primitives-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

# Explicitly correct prior design wording without rewriting any sealed package.
frame = json.loads(decompress((old / 'native-intent-7905.frames/7912.json.gz').read_bytes()))
t = rows[0]['actualEarlyArrivals'][0]
u = next(u for u in frame['snapshot']['units'] if u['id'] == rows[0]['patient'])
b = next(b for b in frame['snapshot']['buildings'] if b['id'] == t['one']['buildingId'])
at = t['after']
gap = ((at['x'] - b['x']) ** 2 + (at['y'] - b['y']) ** 2) ** .5
errata = {'classification': 'Independent attribution erratum; earlier sealed evidence/archive and hashes unchanged', 'supersedes': 'The earlier proposal/notes that described7905 early arrival solely as restsAgainstGoalBody circle contact', 'actual': {'tick':7912, 'nativePrePhysicsStop': {'x': at['x'], 'y': at['y']}, 'bodyId': b['id'], 'bodyRadius': b['radius'], 'patientRadius': u['radius'], 'circleGap': gap, 'circleContactLimit': b['radius'] + u['radius'] + 2, 'circleContactFalse': gap > b['radius'] + u['radius'] + 2, 'arrivalReason':'native walkEnded first terrain disjunct: within5 of walkDestination(2928,3504)'}, 'preservedFacts':['7913 acquires target86.030122 away with own range52','7914 first actual pursuit move','7921 original death unchanged'], 'nativePrimitiveFix':'Share actual walkDestination as well as circle-contact geometry; no runtime order/selection changes'}
(p / 'native-7905-arrival-attribution-errata.json').write_text(json.dumps(errata, ensure_ascii=False, indent=2) + '\n')

readme = f'''固定独立源码 `{head}`，基于 `0f5bf01a05046169d4fb42322376f767b97bcc83`。只抽取原生只读接口，未接入 AI 过滤、订单、评分或规则；root/main、其他控制树和冻结对手未改。原容器未提交修改的恢复缺口仍保留。

`native-primitives.patch` 仅涉及 sim.ts 和两个可移植组件测试；`fixed-source.tar.gz` 与 pre/post 清单封存 {len(post['files'])} 个逐文件匹配提交的源码、数据、测试及配置。冻结 manifest 仍为 `0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774`。

- `createNativeQueryFrame` 用同一个原生构造器新建索引，保留队伍首次出现顺序、x/y 桶顺序、桶内原数组顺序。新 map 壳拥有自己的建筑 overlay，不把 Game 的 factory/callback/旧缓存拷进去，也不转移原 runtime previous-index 证书。直接查询真实运行时 frame 可保留其旧桶和 live body 语义；快照重建不被冒称任意 mid-pass 等价。
- `nativeAutomaticAttackIntent` 直接复用原生候选资格、目标评分、跟踪投射物预扣、冷却及严格 +60 重选。原 unit 引用保证 self-threat 身份；输出 acquire/pursue/engage/return/backOut 等分支意图，engage 不承诺本 tick 已开火或安全。查询不运行未来 help-call、队列、autocast、伤害或移动。
- `buildingMoveArrival` 复用原生 walkToward、walkDestination 和身体接触算式，输出 destination/bodyContact 原因。它是当前速度和状态下的静态正常地面移动步估计，不预测推挤、分离、移动身体、未来控制、群体到达或船体碰撞。

顺序单 worker 检查：9 文件 63 项通过，原 sim.test 精准选取 10 项通过、104 项无关测试跳过，tsc --noEmit 退出 0。先前 circle-only 初稿的两项失败和静态诊断已保留，未隐藏成通过。

| 真实边界 | 静态接口与原生观察 |
| --- | --- |
| 7905→7921（召唤） | 静态第7步 destination；真实7912提前到达，7913 acquire 86.030/自身52，7914开始追击。不是圆形身体接触；详见独立 errata。原7921死亡保留。 |
| 10425→10441（弓手路线 footman） | 15步内无提前到达；10440宏观命令改为 attackMove，10441在自身55射程内原地作战。 |
| 16245→16275（弓手路线骑射） | 第1步 bodyContact；真实16246早停，16247原690.47 help-call 目标重选为78.63内骑士（自身330），未发生追敌 move。仍受伤、治疗冷却未好，不据此称安全或已治疗。 |

共65个逐tick完整 world+nextId 检查点：候选加只读查询与 exact0f 原生源码逐值全等，也与原封真实档全等。三个观察点中 live frame 与 canonical snapshot 查询输出也相等；这不是所有时刻的普遍证明。`original-witness/` 保存完整原 world/id/3memory 与原命令。组件重放只重新执行已录公开命令和原生模拟，三方 policy memory 是未变的原始输入见证，未伪称重新运行 AI。

尚未集成 primitive，尚未接 AI filter，未开新普通0比赛，未宣称 bootstrap 完成。后续需 root 审查该共享接口后，再单独定源评估过滤候选。旧3bdb26107败、9ba24840败和5f43714胜的成绩归属保持独立。
'''
(p / 'README.native-primitives.zh.md').write_text(readme)

# Keep initial failed design and all executed scripts/logs; exclude debug module
# source duplication and npm symlinks. Initial source is deliberately retained.
include = [q for q in p.rglob('*') if q.is_file() and not q.is_symlink()
           and q.name not in {'bootstrap-native-primitives-evidence.tar.gz','native-primitives-index.json','native-primitives-delivery.json'}
           and q.suffix != '.mjs']
index = {'head':head,'files':[{'path':str(q.relative_to(p)), 'bytes':q.stat().st_size, 'sha256':sha(q.read_bytes())} for q in sorted(include)]}
(p / 'native-primitives-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
include.append(p / 'native-primitives-index.json')
archive = p / 'bootstrap-native-primitives-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for q in sorted(include): tf.add(q, arcname=str(q.relative_to(p)), recursive=False)
delivery = {'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payload':len(include),'head':head,'patch':str(p/'native-primitives.patch'),'patchSHA256':sha((p/'native-primitives.patch').read_bytes()),'sourceArchiveSHA256':sha((p/'fixed-source.tar.gz').read_bytes())}
(p / 'native-primitives-delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery))
