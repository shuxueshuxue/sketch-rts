返港修复固定：`a53eee411c6950bafffc69c2c950a6fbbc825876`，base `760ef777eeaf0eb13a67bef5b2221fbf777126a9`。仅 naval.ts 一生产文件及5项合同；不修改规则2、原40%门槛、原生维修费用或冻结对手。

原行为以偏离码头实际中心的watergoal及250距离放行，未满足原生实际中心strict240。新行为为原naval owner选择实际可进入维修范围的船体站位，以普通move避免战斗接近，入范围后hold取消旧出航令，按原生规则实付恢复，达到原40%后释放。没有TTL、失败cache、资源折扣、兼容层或新指挥层。

旧源5合同4红1绿；候选5绿，海军服务/查询邻域15绿，tsc0。1477源文件与Git/capsule全回读一致；冻结497文件与manifest184逐项一致，manifest0490e7d4…原样。

原actual229800完整存档世界/nextId/三mem从原值起：首次JS对象strictguard拒绝且零command/step；逐项2541差全是missing→explicitundefined，所有持久值相等，保完整diff后仅用持久JSON值比较。885tick组件中229959实际进入strict240，229960..230680共37次每次+3HP/−1gold，HP19.916→130.916，原40%放行。仅move+hold两令，0hit。三名永久乘员至230685均在船，原spirit230085正常到期。

随后同760baseline与候选各一次完整P0只读：原naval发布(1936,5104)，候选同naval发布(2122.7951796002008,5142.913111507788)，精确等真实native组件首令。两源其余11条命令及全三方postmem完全同；原世界/输入/对手mem不变，无Game或step。见FULL-P0-INTEGRATION.json及两源完整entries/postmem。

实际before/after native drawWorld图片在actual229800-native-renders；为记录帧只读重绘，已亲看，非人工示意/实时UI/新Game。距离、生命、收费以native账为准。

此为局部任务闭合，不是正常三方完整比赛、普通0开局、获胜、泛化或后续载员必存活的证明。仍保单个nearestShipPose候选并非全港位穷尽、此前海岸危险优先等范围；完整比赛影响由parent继续验证。原坏容器未提交修改恢复缺口保留。

第一次错误cone sparse展开docs致/tmp满及c8中断已完整披露，恢复receipt见RESOURCE-INCIDENT-OWNER.json；所有失败/资源拒绝日志保留。原native数据不改，receiptv1的一个猜测ID查表已由v2明确纠正。
