import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
const D='/tmp/bootstrap-hurt-hull-dock-760-20261016';
const source=JSON.parse(readFileSync(join(D,'fixed-source.json'),'utf8'));
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
function audit(){if(execFileSync('git',['rev-parse','HEAD'],{cwd:source.root,encoding:'utf8'}).trim()!==source.head||execFileSync('git',['status','--porcelain'],{cwd:source.root,encoding:'utf8'}))throw Error('source changed');for(const [p,h] of Object.entries(source.hashes))if(sha(readFileSync(join(source.root,p)))!==h)throw Error('hash '+p);}
audit();
const input='/tmp/bootstrap-coastal-station-admission-225600-20261016/natural-from-225600/frames/229800-before-p0.json.gz';
const raw=readFileSync(input),saved=JSON.parse(gunzipSync(raw).toString());
const {createGame,restoreSnapshotIntoGame,snapshotGame}=await import(join(source.root,'src/shared/sim.ts'));
const game=createGame('bareDuel',{aiPlayers:[]});restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const actual=snapshotGame(game);
let differences:any[]=[];function diff(a:any,b:any,p=''){if(isDeepStrictEqual(a,b))return;if(a&&b&&typeof a==='object'&&typeof b==='object'){for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const ap=Object.hasOwn(a,k),bp=Object.hasOwn(b,k);if(ap!==bp)differences.push({path:p+'/'+k,originalPresent:ap,restoredPresent:bp,originalType:typeof a[k],restoredType:typeof b[k],original:a[k],restored:b[k]});else diff(a[k],b[k],p+'/'+k);}}else differences.push({path:p,original:a,restored:b});}diff(saved.snapshot,actual);
const report={scope:'restore only; zero commands, zero native steps, no policy think or query',source:source.head,inputSHA256:sha(raw),sameTick:game.tick===saved.snapshot.tick,nextId:game.nextId===saved.nextId,differences,worldExact:isDeepStrictEqual(saved.snapshot,actual),persistedJSONExact:isDeepStrictEqual(saved.snapshot,JSON.parse(JSON.stringify(actual)))};
writeFileSync(join(D,'actual229800-restored-only.json.gz'),gzipSync(JSON.stringify({snapshot:actual,nextId:game.nextId,memories:saved.memories})));
writeFileSync(join(D,'RESTORE-DIFF.json'),JSON.stringify(report,null,2));audit();console.log(JSON.stringify(report));
