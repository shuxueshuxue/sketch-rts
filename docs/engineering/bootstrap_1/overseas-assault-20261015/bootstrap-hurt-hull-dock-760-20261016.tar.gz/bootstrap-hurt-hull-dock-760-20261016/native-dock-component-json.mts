import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { resolve, join } from 'node:path';

const D = '/tmp/bootstrap-hurt-hull-dock-760-20261016';
const source = JSON.parse(readFileSync(join(D, 'fixed-source.json'), 'utf8'));
const input = resolve(process.argv[2]!);
const output = resolve(process.argv[3]!);
mkdirSync(output, { recursive: true });
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
function sourceAudit() {
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: source.root, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: source.root, encoding: 'utf8' });
  if (head !== source.head || status) throw new Error('Fixed source HEAD/status changed');
  for (const [path, digest] of Object.entries(source.hashes))
    if (sha(readFileSync(join(source.root, path))) !== digest) throw new Error(`Changed source: ${path}`);
  return { head, status, files: Object.keys(source.hashes).length };
}
const sourcePre = sourceAudit();
const raw = readFileSync(input), saved = JSON.parse(gunzipSync(raw).toString());
const savedBytes = JSON.stringify(saved), memories = structuredClone(saved.memories);
const [{ createGame, restoreSnapshotIntoGame, snapshotGame, issuePlayerCommand, stepGame },
  { navalDockRepair }, { DOCK_REPAIR }, { RULES_VERSION }] = await Promise.all([
  import(join(source.root, 'src/shared/sim.ts')),
  import(join(source.root, 'src/ai/policy/naval.ts')),
  import(join(source.root, 'src/shared/catalog.ts')),
  import(join(source.root, 'src/shared/rules-version.ts')),
]);
if (RULES_VERSION !== 2) throw new Error('This task component requires fixed rules 2');
const game = createGame('bareDuel', { aiPlayers: [] });
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
const restoredView = snapshotGame(game);
const restoreDifferenceProof = JSON.parse(readFileSync(join(D,'RESTORE-DIFF-CLASSIFICATION.json'),'utf8'));
if (!restoreDifferenceProof.persistedJSONExact || restoreDifferenceProof.inputSHA256 !== sha(raw) || restoreDifferenceProof.head !== source.head) throw new Error('Unbound restore proof');
const nativeObjectExact = isDeepStrictEqual(restoredView, saved.snapshot);
const restored = { worldPersistedJSON: isDeepStrictEqual(JSON.parse(JSON.stringify(restoredView)), saved.snapshot), nextId: game.nextId === saved.nextId,
  all3mem: isDeepStrictEqual(memories, saved.memories) };
writeFileSync(join(output, 'preflight.json'), JSON.stringify({
  classification: 'Short native task component from complete original actual world/nextId/all3mem. No full P0 or other policy think; only the production naval dock-repair leaf issues ordinary commands to its actual hurt hull. Existing other native orders continue. Not an ordinary0/full3AI/full-match result.',
  input, inputSHA256: sha(raw), sourcePre, restored, nativeObjectExact, restoreDifferenceProofSHA256: sha(readFileSync(join(D,'RESTORE-DIFF-CLASSIFICATION.json'))), start: game.tick,
  maxComponentTicks: 1200, originalMemoriesPreserved: true, rulesVersion: RULES_VERSION,
}, null, 2));
if (!Object.values(restored).every(Boolean)) throw new Error('Original complete checkpoint did not restore exactly; no commands or step');
const start = game.tick, targetId = 'unit-p0-warship-31227', owner = 'p0';
const rows: any[] = [], commands: any[] = [], hits: any[] = [], healing: any[] = [];
const target = () => game.units.find((unit: any) => unit.id === targetId);
const dockDistance = (ship: any) => Math.min(...game.buildings.filter((building: any) =>
  building.owner === owner && building.kind === 'shipyard' && building.complete)
  .map((building: any) => Math.hypot(ship.x - building.x, ship.y - building.y)));
const frame = (name: string) => writeFileSync(join(output, `${name}.json.gz`), gzipSync(JSON.stringify({
  snapshot: snapshotGame(game), nextId: game.nextId, memories, checkpointStage: 'native-task-component-before-next-leaf',
})));
frame('initial');
game.observer = { hit(attacker: any, victim: any, damage: number, hpBefore: number) {
  hits.push({ tick: game.tick, attacker: attacker.id, target: victim.id, damage, hpBefore, hpAfter: victim.hp });
} };
let release: any, firstInside: number | undefined;
for (let count = 0; count < 1200 && !game.match.winner && target(); count++) {
  const ship = target()!;
  if ((game.tick - start) % 15 === 0) {
    const view = snapshotGame(game), before = JSON.stringify(view), result = navalDockRepair(view, view.units.find((unit: any) => unit.id === targetId)!);
    if (JSON.stringify(view) !== before) throw new Error('Repair leaf mutated its snapshot');
    if (result === undefined) { release = { tick: game.tick, hp: ship.hp, maxHp: ship.maxHp, qualifies: ship.hp >= ship.maxHp * .4 }; break; }
    for (const command of result) {
      commands.push({ tick: game.tick, playerId: owner, source: 'external-agent', scriptId: 'naval', command });
      issuePlayerCommand(game, owner, command);
    }
  }
  const before = { hp: ship.hp, gold: game.players[owner]!.gold, dockDistance: dockDistance(ship), order: structuredClone(ship.order) };
  stepGame(game);
  const after = target();
  if (!after) { frame(`loss-${game.tick}`); break; }
  const row = { tick: game.tick, x: after.x, y: after.y, hp: after.hp, gold: game.players[owner]!.gold,
    dockDistance: dockDistance(after), order: structuredClone(after.order) };
  rows.push(row);
  if (firstInside === undefined && row.dockDistance < DOCK_REPAIR.range) { firstInside = game.tick; frame(`first-inside-${game.tick}`); }
  if (after.hp > before.hp) {
    healing.push({ tick: game.tick, hpBefore: before.hp, hpAfter: after.hp, hpDelta: after.hp - before.hp,
      goldBefore: before.gold, goldAfter: row.gold, goldDelta: row.gold - before.gold,
      dockDistanceBefore: before.dockDistance, dockDistanceAfter: row.dockDistance, order: before.order });
    if (healing.length === 1) frame(`first-heal-${game.tick}`);
  }
}
frame('final');
const sourcePost = sourceAudit();
if (savedBytes !== JSON.stringify(saved) || !isDeepStrictEqual(memories, saved.memories)) throw new Error('Original input/3mem changed');
writeFileSync(join(output, 'rows.jsonl'), rows.map(row => JSON.stringify(row)).join('\n') + '\n');
writeFileSync(join(output, 'commands.jsonl'), commands.map(row => JSON.stringify(row)).join('\n') + '\n');
writeFileSync(join(output, 'hits.jsonl'), hits.map(row => JSON.stringify(row)).join('\n') + '\n');
writeFileSync(join(output, 'healing.json'), JSON.stringify(healing, null, 2));
const summary = { classification: 'Same fixed production leaf/native component only. Complete initial actual checkpoint; no other AI thinks, no enemy/resource/population edits. No full-match or generalization conclusion.',
  sourcePre, sourcePost, restored, nativeObjectExact, start, end: game.tick, steps: game.tick - start,
  firstInside, initialHP: saved.snapshot.units.find((unit: any) => unit.id === targetId).hp,
  finalHP: target()?.hp, finalDockDistance: target() && dockDistance(target()), release,
  healingEvents: healing.length, healing, commands: commands.length, hits: hits.length,
  inputUnchanged: savedBytes === JSON.stringify(saved), all3memUnchanged: isDeepStrictEqual(memories, saved.memories),
  targetAlive: !!target(), winner: game.match.winner ?? null };
writeFileSync(join(output, 'REPORT.json'), JSON.stringify(summary, null, 2));
process.stdout.write(JSON.stringify({ start, end: game.tick, firstInside, finalHP: target()?.hp,
  release, healingEvents: healing.length, commands: commands.length, hits: hits.length, targetAlive: !!target() }) + '\n');
