import {readFileSync,writeFileSync,mkdirSync,existsSync,renameSync,openSync,writeSync,closeSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {isDeepStrictEqual} from 'node:util';
const source='/tmp/sketch-rts-safe-worker-boarding-v1-control',out='/tmp/bootstrap-knight-e7-ordinary0-20261015';
const expectedCommit='e7f47f3226d8eabfe94ca7c75d489b0e273b452e';
if(existsSync(out+'/launch.json'))throw Error('Never overwrite or relaunch an existing ordinary game');
const git=(...a:string[])=>execFileSync('git',['-C',source,...a],{encoding:'utf8'}).trim(),sha=(v:any)=>createHash('sha256').update(v).digest('hex'),norm=(v:any)=>JSON.parse(JSON.stringify(v));
if(git('rev-parse','HEAD')!==expectedCommit||git('status','--porcelain'))throw Error('Expected immutable clean e7 source');
const files=git('ls-files','src','scripts','package.json','package-lock.json','tsconfig.json','docs/engineering/bootstrap_1/frozen-policy.json').split('\n').filter(p=>existsSync(source+'/'+p));
const sourceHashes=()=>Object.fromEntries(files.map(p=>[p,sha(readFileSync(source+'/'+p))])),preSource=sourceHashes();
const imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const [sim,benchmark,mem,bootstrap,runner]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/bootstrap_1/benchmark.ts'),imp('src/ai/planner-context.ts'),imp('scripts/bootstrap_1-planner.ts'),imp('src/ai/game-runner.ts')]);
const seed='bootstrap_1-knight-v5-official-sapphire-20261015-01';
const match=benchmark.bootstrapMatches(seed,['sapphireArchipelago'],144000,false).find((m:any)=>m.subject==='v9_knight'&&m.side===0&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v5');
if(!match)throw Error('Missing exact approved normal factory selection');
const game=benchmark.bootstrapGame(match),owners=Object.keys(match.agents),provider=mem.createAiMemoryProvider(),planner=await bootstrap.createBootstrapCommandPlanner(provider);
const full=()=>norm({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,provider.get(owner)??null]))});
const initial=full(),original0=JSON.parse(readFileSync('/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary.json.frames/0.json','utf8'));
const opening={classification:'New standard factory0, no resume and no world/coordinate/order/resource edits. Known official development case, unseen false.',worldMatchesOriginal6f80Factory0:isDeepStrictEqual(initial.snapshot,original0.snapshot),nextIdMatches:initial.nextId===original0.nextId,bothMemoriesMatchUninitialized:isDeepStrictEqual(initial.memories,original0.memories),players:Object.fromEntries(owners.map(owner=>[owner,{gold:game.players[owner].gold,supply:game.players[owner].supplyUsed,cap:game.players[owner].supplyCap,workers:game.units.filter((u:any)=>u.owner===owner&&u.kind==='worker').length}]))};
if(!opening.worldMatchesOriginal6f80Factory0||!opening.nextIdMatches||!opening.bothMemoriesMatchUninitialized)throw Error('Standard factory0 mismatch; do not pretend original game recovered');
for(const p of Object.values(opening.players)as any[])if(p.gold!==500||p.supply!==3||p.cap!==8||p.workers!==3)throw Error('Normal opponent/subject opening changed');
const frozenRoot=bootstrap.frozenPolicyRoot(),frozenFiles=bootstrap.frozenPolicyManifest.files,frozenBad=Object.entries(frozenFiles).filter(([p,h])=>sha(readFileSync(frozenRoot+'/'+p))!==h).map(([p])=>p);
if(frozenBad.length||bootstrap.frozenPolicyManifest.rulesVersion!==2)throw Error('Frozen184/rules2 preflight failed');
const setup={map:match.mapId,seed:match.seed,unseen:match.unseen,side:match.side,agents:match.agents,thinkInterval:match.thinkInterval,rulesVersion:2,frozenRevision:bootstrap.frozenPolicyManifest.revision};
const framesDir=out+'/frames';mkdirSync(framesDir);const frames:any[]=[],commands:any[]=[],purchases:any[]=[],deaths:any[]=[],workerInjuries:any[]=[],workerDeckChanges:any[]=[],workerBoardRequests:any[]=[],rows:any[]=[];
const atomic=(name:string,value:any)=>{const p=out+'/'+name;writeFileSync(p+'.tmp',JSON.stringify(value));renameSync(p+'.tmp',p);};
const capture=(label:string)=>{const state=full(),file=`${game.tick}-${frames.length}-${label}.json.gz`;writeFileSync(framesDir+'/'+file,gzipSync(JSON.stringify(state)));frames.push({tick:game.tick,label,file});return state;};
const initialFrame=capture('factory0');
atomic('prelaunch-source.json',{source,commit:expectedCommit,sourceHashes:preSource,driverSHA256:sha(readFileSync(import.meta.filename)),frozenPolicy:{revision:bootstrap.frozenPolicyManifest.revision,rulesVersion:2,count:Object.keys(frozenFiles).length,files:frozenFiles,bad:frozenBad}});
atomic('opening-preflight.json',opening);
atomic('launch.json',{launched:true,pid:process.pid,source,commit:expectedCommit,setup,opening,initialFrame:frames[0],classification:'True standard0 full both-AI match under immutable e7. Known development seed; not a new unseen seed or full matrix acceptance. Continue the same live game past inspection boundaries until natural outcome.',firstInspectionBoundary:144000,checkpointInterval:1200,sourceFileCount:files.length,frozenFileCount:Object.keys(frozenFiles).length});
const summary=()=>({tick:game.tick,winner:game.match.winner,endedAtTick:game.match.endedAtTick,stats:structuredClone(game.match.stats),players:Object.fromEntries(owners.map(owner=>[owner,{gold:game.players[owner].gold,supply:game.players[owner].supplyUsed,cap:game.players[owner].supplyCap,workers:game.units.filter((u:any)=>u.owner===owner&&u.kind==='worker').map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,deck:u.deck})),permanentUnits:game.units.filter((u:any)=>u.owner===owner&&u.expiresTick===undefined).length,buildings:game.buildings.filter((b:any)=>b.owner===owner).map((b:any)=>({id:b.id,kind:b.kind,x:b.x,y:b.y,hp:b.hp,complete:b.complete,queue:b.queue}))}]))});
const commandFd=openSync(out+'/commands.ndjson','a');
let beforeUnits=new Map<string,any>(),lastCheckpoint=initialFrame;
const cash:Record<string,any>={},initialIds=new Set(game.units.filter((u:any)=>u.owner==='p0'&&u.expiresTick===undefined).map((u:any)=>u.id));
console.log(JSON.stringify({launched:true,pid:process.pid,source,commit:expectedCommit,tick:game.tick,opening,frozenFileCount:Object.keys(frozenFiles).length,sourceFiles:files.length}));
const hooks={onCommand(event:any){
 const row={tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)};commands.push(row);writeSync(commandFd,JSON.stringify(row)+'\n');
 const owner=event.owner,c=event.command,now={gold:game.players[owner].gold,spent:game.match.stats.goldSpent[owner]},old=cash[owner];
 if(['build','train','research','hire','buy','buyShipEquipment'].includes(c.type))purchases.push({...row,goldBefore:old?.gold,goldAfter:now.gold,actualGoldPaid:old&&old.gold-now.gold,spendDelta:old&&now.spent-old.spent});cash[owner]=now;
 if(c.type==='board')for(const id of c.unitIds){const u=game.units.find((u:any)=>u.id===id);if(u?.kind==='worker')workerBoardRequests.push({...row,workerId:id,x:u.x,y:u.y,hp:u.hp,nativeOrder:structuredClone(u.order)});}
},beforeStep(){
 beforeUnits=new Map(game.units.filter((u:any)=>u.owner==='p0'&&u.expiresTick===undefined).map((u:any)=>[u.id,{id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:structuredClone(u.order),deck:u.deck&&{...u.deck}}]));
},onStep(){
 const after=new Map(game.units.filter((u:any)=>u.owner==='p0'&&u.expiresTick===undefined).map((u:any)=>[u.id,u]));
 for(const[id,old]of beforeUnits){const now:any=after.get(id);if(!now)deaths.push({tick:game.tick,id,kind:old.kind,initial:initialIds.has(id),lastBeforeNativeStep:old});if(old.kind==='worker'){if(!now||now.hp<old.hp)workerInjuries.push({tick:game.tick,before:old,after:now?{x:now.x,y:now.y,hp:now.hp,order:now.order,deck:now.deck}:null});if(now&&old.deck?.shipId!==now.deck?.shipId)workerDeckChanges.push({tick:game.tick,id,before:old.deck,after:now.deck,x:now.x,y:now.y,hp:now.hp,order:structuredClone(now.order)});}}
 if(game.tick%1200===0||game.match.winner){lastCheckpoint=capture(game.match.winner?'natural-terminal':'complete-checkpoint');rows.push(summary());atomic('progress.json',{classification:'Live true standard0 full match; completed only when native winner exists.',setup,result:{tick:game.tick,winner:game.match.winner,completed:!!game.match.winner},lastFrame:frames.at(-1),rows,purchases,deaths,workerInjuries,workerDeckChanges,workerBoardRequests,frames});console.log(JSON.stringify({tick:game.tick,winner:game.match.winner,p0gold:game.players.p0.gold,p0bases:game.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall').length,p0permanentLosses:deaths.length,workerInjuries:workerInjuries.length}));}
}};
while(!game.match.winner){const boundary=game.tick+48000;runner.runAiGameLoop({...match,game,maxTicks:boundary,commandPlanner:(context:any)=>{cash[context.owner]={gold:game.players[context.owner].gold,spent:game.match.stats.goldSpent[context.owner]};return planner(context);}},hooks);if(!game.match.winner)console.log(JSON.stringify({inspectionBoundary:game.tick,completed:false,continuingSameLiveGame:true}));}
closeSync(commandFd);
const final=full(),beforeLast=frames.filter((f:any)=>f.label==='complete-checkpoint').at(-1);let replay:any=null;
if(beforeLast){const {gunzipSync}=await import('node:zlib'),saved=JSON.parse(gunzipSync(readFileSync(framesDir+'/'+beforeLast.file)).toString()),g=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(g,saved.snapshot,saved.nextId);const memories=mem.createAiMemoryProvider();for(const[owner,m]of Object.entries(saved.memories))if(m!==null)memories.set(owner,structuredClone(m));const rp=await bootstrap.createBootstrapCommandPlanner(memories),replayed:any[]=[];runner.runAiGameLoop({...match,game:g,maxTicks:game.tick,commandPlanner:rp},{onCommand(e:any){replayed.push({tick:e.tick,owner:e.owner,scriptId:e.scriptId,command:structuredClone(e.command)});}});replay={start:saved.snapshot.tick,end:g.tick,world:isDeepStrictEqual(norm(sim.snapshotGame(g)),final.snapshot),nextId:g.nextId===final.nextId,bothMemories:isDeepStrictEqual(norm(Object.fromEntries(owners.map(owner=>[owner,memories.get(owner)??null]))),final.memories),commands:isDeepStrictEqual(replayed,commands.filter((x:any)=>x.tick>=saved.snapshot.tick))};}
const postSource=sourceHashes(),sourceUnchanged=isDeepStrictEqual(preSource,postSource),status=git('status','--porcelain');
atomic('result.json',{classification:'True standard factory0 full match under fixed e7. Known official development seed, not unseen/generalization acceptance.',source,commit:expectedCommit,setup,opening,initial:initialFrame,final,result:{tick:game.tick,winner:game.match.winner,endedAtTick:game.match.endedAtTick,completed:!!game.match.winner},summary:summary(),rows,purchases,deaths,workerInjuries,workerDeckChanges,workerBoardRequests,frames,replay,sourceUnchanged,sourceStatus:status});
atomic('postflight-source.json',{source,commit:git('rev-parse','HEAD'),sourceUnchanged,sourceStatus:status,sourceHashes:postSource});
console.log(JSON.stringify({done:true,tick:game.tick,winner:game.match.winner,completed:true,permanentLosses:deaths.length,workerInjuries:workerInjuries.length,sourceUnchanged,status,replay}));
