import {readFileSync,writeFileSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{pathToFileURL}from'node:url';
const source='/tmp/sketch-rts-safe-worker-boarding-v1-control',directory='/tmp/bootstrap-knight-e7-ordinary0-20261015',imp=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const[{createCanvas},{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([imp('node_modules/@napi-rs/canvas/index.js'),imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);installHeadlessCanvas();
const report=JSON.parse(readFileSync(directory+'/progress.json','utf8')),tick=38400,frame=report.frames.find((f:any)=>f.tick===tick),input=directory+'/frames/'+frame.file,{snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
const views={north:{x:5000,y:800,width:1400,height:1000,zoom:1},south:{x:4500,y:7900,width:1600,height:1200,zoom:1}};
for(const[name,view]of Object.entries(views)){const canvas=createCanvas(view.width,view.height);drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(directory+`/native${tick}-${name}.png`,canvas.toBuffer('image/png'));}
writeFileSync(directory+`/native${tick}-visual.json`,JSON.stringify({classification:'Native drawWorld of exact true ordinary0 full checkpoint, no stepping or world edit. New facing tracker is not a historic animation reconstruction.',source,input,tick,views},null,2)+'\n');
