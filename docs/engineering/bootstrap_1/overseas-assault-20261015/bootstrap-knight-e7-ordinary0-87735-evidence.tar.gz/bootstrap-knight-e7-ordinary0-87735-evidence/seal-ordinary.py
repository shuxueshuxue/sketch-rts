from pathlib import Path
import shutil,json,hashlib,subprocess,tarfile,gzip
p=Path('/workspace/bootstrap-knight-e7-ordinary0-recovered-20261015');dest=Path('/workspace/bootstrap-knight-e7-ordinary0-87735-evidence');assert not dest.exists();shutil.copytree(p,dest)
source=Path('/tmp/sketch-rts-safe-worker-boarding-v1-control');base='3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71';end='e7f47f3226d8eabfe94ca7c75d489b0e273b452e';paths=subprocess.check_output(['git','-C',str(source),'diff','--name-only',base,end],text=True).splitlines()
for f in paths:
 d=dest/'source'/f;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/f,d)
patch=dest/'source/workforce-and-safety-from-3bdb.patch';patch.write_bytes(subprocess.check_output(['git','-C',str(source),'diff','--binary',base,end]))
pre=json.load(open(p/'segment0/prelaunch-source.json'));bad=[f for f,h in pre['sourceHashes'].items()if hashlib.sha256((source/f).read_bytes()).hexdigest()!=h];assert not bad
(dest/'SOURCE-FINAL-AUDIT.json').write_text(json.dumps({'source':str(source),'commit':end,'base':base,'productionFiles':[f for f in paths if not f.endswith('.gz')and not f.endswith('.test.ts')],'allChangedFiles':paths,'physicalTracked1418HashesSameSinceTrue0Launch':not bad,'status':subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True),'priorThreeWayArchive':{'path':'/tmp/bootstrap-workforce-safe-board-e7-three-way-evidence.tar.gz','sha256':'97c5cf07f1a8454bc71fecf18076acee5a3773ba2142a16d22889abbb8472692'},'workforce49PassedAt':'114dd','safety91BeforeFinalTwoLineBoundaryCorrection':True,'finalE7Affected27AndStrictTscGreen':True},indent=2)+'\n')
index={str(f.relative_to(dest)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in sorted(dest.rglob('*'))if f.is_file()};(dest/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n');archive=dest.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz')as t:t.add(dest,arcname=dest.name)
with tarfile.open(archive,'r:gz')as t:
 for f,info in index.items():
  data=t.extractfile(dest.name+'/'+f).read();assert hashlib.sha256(data).hexdigest()==info['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(index),'allIndexVerified':True},indent=2))
