from pathlib import Path
import json,hashlib
prior=Path('/tmp/bootstrap-knight-e7-ordinary0-20261015');out=Path('/workspace/bootstrap-knight-e7-ordinary0-recovered-20261015')
assert not (out/'launch.json').exists()
text=(prior/'run-ordinary0.ts').read_text().replace("import {gzipSync} from 'node:zlib';","import {gzipSync,gunzipSync} from 'node:zlib';")
text=text.replace("out='/tmp/bootstrap-knight-e7-ordinary0-20261015'","out='/workspace/bootstrap-knight-e7-ordinary0-recovered-20261015'")
a=text.index('const game=benchmark.bootstrapGame(match)');b=text.index('const frozenRoot=',a)
text=text[:a]+'''const prior=JSON.parse(readFileSync(out+'/segment0/progress.json','utf8')),priorPreflight=JSON.parse(readFileSync(out+'/segment0/prelaunch-source.json','utf8'));
if(!isDeepStrictEqual(preSource,priorPreflight.sourceHashes))throw Error('Source changed since true0 launch');
const savedPath=out+'/segment0/frames/'+prior.lastFrame.file,saved=JSON.parse(gunzipSync(readFileSync(savedPath)).toString());
if(saved.snapshot.tick!==68400||saved.snapshot.match.winner)throw Error('Wrong last complete checkpoint');
const game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const owners=Object.keys(match.agents),provider=mem.createAiMemoryProvider();for(const [owner,m] of Object.entries(saved.memories))if(m!==null)provider.set(owner,structuredClone(m));
const planner=await bootstrap.createBootstrapCommandPlanner(provider);
const full=()=>norm({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(owner=>[owner,provider.get(owner)??null]))});
const initial=full(),opening=JSON.parse(readFileSync(out+'/segment0/opening-preflight.json','utf8'));
if(!isDeepStrictEqual(initial,saved))throw Error('Full checkpoint restore mismatch');
const originalCommands=readFileSync(out+'/segment0/commands.ndjson','utf8').trim().split('\\n').map(x=>JSON.parse(x)),expectedOverlap=originalCommands.filter(x=>x.tick>=68400);
let overlapIndex=0;
''' +text[b:]
old="const framesDir=out+'/frames';mkdirSync(framesDir);const frames:any[]=[],commands:any[]=[],purchases:any[]=[],deaths:any[]=[],workerInjuries:any[]=[],workerDeckChanges:any[]=[],workerBoardRequests:any[]=[],rows:any[]=[];"
new="const framesDir=out+'/frames';mkdirSync(framesDir);const frames:any[]=prior.frames.map((f:any)=>({...f,directory:'segment0/frames'})),commands:any[]=originalCommands.filter(x=>x.tick<68400),purchases:any[]=[...prior.purchases],deaths:any[]=[...prior.deaths],workerInjuries:any[]=[...prior.workerInjuries],workerDeckChanges:any[]=[...prior.workerDeckChanges],workerBoardRequests:any[]=[...prior.workerBoardRequests],rows:any[]=[...prior.rows];"
assert old in text;text=text.replace(old,new).replace("frames.push({tick:game.tick,label,file});","frames.push({tick:game.tick,label,file,directory:'frames'});").replace("capture('factory0')","capture('recovered-complete-68400')")
text=text.replace("classification:'True standard0 full both-AI match under immutable e7. Known development seed; not a new unseen seed or full matrix acceptance. Continue the same live game past inspection boundaries until natural outcome.'","classification:'Continuation of genuine standard0 under the exact unchanged e7 source after ENOSPC. Full world+nextId+both memories from last complete68400; original segment0 preserved incl zero-byte69600 incomplete file. Not a new ordinary0 and no code switch.',resume:{tick:68400,completeInput:savedPath,fullRestoreEqual:true,all1418SourceHashesEqualToTrue0Launch:true,interruption:'ENOSPC during69600 capture; original process exited',priorCommandLastTick:originalCommands.at(-1)?.tick,overlapExpected:expectedOverlap.length}")
text=text.replace("const row={tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)};commands.push(row);", "const row={tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)};if(event.tick<69600){if(!isDeepStrictEqual(row,expectedOverlap[overlapIndex]))throw Error('Recovered overlap command mismatch '+overlapIndex);overlapIndex++;}commands.push(row);")
prefix="""runner.runAiGameLoop({...match,game,maxTicks:69600,commandPlanner:(context:any)=>{cash[context.owner]={gold:game.players[context.owner].gold,spent:game.match.stats.goldSpent[context.owner]};return planner(context);}},hooks);
if(overlapIndex!==expectedOverlap.length)throw Error('Missing overlap commands');
atomic('interruption-recovery-preflight.json',{originalStartedAt0:true,resumeTick:68400,replayedThrough:game.tick,sameSource:true,fullWorldNextIdBothMemRestore:true,allRecordedOverlapCommandsEqual:true,overlapCommandCount:overlapIndex,originalLastCommandTick:originalCommands.at(-1)?.tick,invalidOriginalFrame:'segment0/frames/69600-58-complete-checkpoint.json.gz',noClaimOfRecovered69600OriginalWorld:true});
console.log(JSON.stringify({recoveryVerified:true,tick:game.tick,overlapCommands:overlapIndex}));
"""
marker='while(!game.match.winner){const boundary=';assert marker in text;text=text.replace(marker,prefix+marker)
text=text.replace("readFileSync(framesDir+'/'+beforeLast.file)","readFileSync(out+'/'+beforeLast.directory+'/'+beforeLast.file)")
text=text.replace("classification:'True standard factory0 full match under fixed e7. Known official development seed, not unseen/generalization acceptance.'","classification:'Genuine standard factory0 full match under unchanged e7 with explicit ENOSPC interruption/resume68400. Known official development seed, not unseen/generalization acceptance.',interruption:{atCaptureTick:69600,lastComplete:68400,allRecorded48OverlapCommandsMatched:true,restoredWorldNextIdBothMemories:true,sourceUnchangedAcrossResume:true}")
commands=[json.loads(x) for x in (prior/'commands.ndjson').read_text().splitlines() if x.strip()]
(out/'commands.ndjson').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in commands if x['tick']<68400))
(out/'run-recovered.ts').write_text(text)
print(json.dumps({'prepared':True,'out':str(out),'driverSHA256':hashlib.sha256(text.encode()).hexdigest(),'segment0Preserved':True,'pre68400Commands':sum(x['tick']<68400 for x in commands)}))
