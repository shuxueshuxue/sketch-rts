# deployment beach v3：正常双方 AI 完整存档续局证据

这是从未施加手动命令的真实 88110 tick 存档接续至 92000 tick 的固定源码对照段；双方正常 AI 每 15 tick 思考。不是新普通开局、不是完整比赛结局、不是 bootstrap_1 最终验收。原始比赛为官方 sapphireArchipelago、bootstrap_1-development 种子，v9_archer（Grove，p0）对冻结 v5（Ember，p1），rulesVersion 2；未削弱对手资源、人口或规则。

## 精确来源

运行 HEAD 为 `183b84879b97902fcb57e9acadbce62b0fcfb872`，叠加封存的 v3 工作区修改。`deployment-beach-v3-source.tar.gz` 保存全部 856 个选定运行源码、测试、fixture 与配置文件，`source.json` 列出逐文件 SHA-256，`source.patch` 保存 tracked diff。它是该运行源码胶囊，不声称包含整份 Git 历史或原容器未提交改动。

冻结对手 revision 为 `d1ae110f2edd99f9c7d899ed61557891ab587639`；原捕获验证 184 个冻结文件。manifest SHA-256 为 `0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774`，规则 2 与已验证迁移基线保持不变。原容器未提交修改的恢复缺口仍保留；本证据包不能补回该缺口。

真实输入在 `archer-assault-contact-replay.frames/before-think-88110.json`，包含完整 world、nextId、双方策略 memories；恢复验证三者均 true。29 人身份与 originDeck 由这份原始完整存档直接提取，`deployment-gate-original-crew.json` 只是身份元数据，不引入手动历史、状态或命令。实际 driver SHA、输入 SHA、源代码 preflight/postflight 与本次独立封存核对见 `deployment-beach-v3-sealing-verification.json`。

## 实际结果

v3 将重新选择的安全海滩分成接近海上站位与原生卸载命令：实际未处于可全员安全登陆的站位时使用公开 move/stop。它阻止了 v2 在 89146 tick 因航线停顿提前向北岸卸出半波的已知触发。到 89310 tick，29 人全部仍在船上，原 29 人零死亡。此项局部改善不表示进攻成功。

89641 tick，3824 船的 15 人（包括一名工人）同时首次在敌岛登陆，另船 3510 的 14 人仍在船上。原生执行器是在当时实际可达、无当前武器覆盖的同岛岸边落地；这些落点不等于最终目标海滩坐标。随后已登陆的单波立即推进并与守军交战，未等到另一波实际展开，15 人最终全部阵亡。首个死亡为 89837 tick，最后一个为 90639 tick。

| tick | 敌岛地面 | 船上 | 其他陆地 | 死亡 |
| --- | ---: | ---: | ---: | ---: |
| 89310 | 0 | 29 | 0 | 0 |
| 89641 | 15 | 14 | 0 | 0 |
| 90510 | 1 | 14 | 0 | 14 |
| 90556 | 1 | 0 | 14 | 14 |
| 90639 | 0 | 0 | 14 | 15 |
| 92000 | 0 | 0 | 14 | 15 |

另一船的 14 人后来返航，在 90556 tick 卸回出发岸；不得把他们误记成最终仍在船上。92000 tick 两船仍存活，最终没有原 29 人留在敌岛。敌方建筑由 21 减至 20，仅 `building-p1-farm-4261` 在 90378 tick 被毁；主厅保持 900 HP，winner 为 null。这段进攻未成功，比赛尚未结束，仍需继续解决部队分波推进的问题并检验完整比赛结果。

## 验证范围与限制

5 个相关测试套件、53 个测试及 TypeScript 检查通过。三条路线的 fixture 测试只是相同原生站位/承诺逻辑的上下文覆盖，不是三家族新的真实比赛，不替代全部单对手、六配对、官方地图与未见种子的最终要求。保留首次失败测试日志：该失败来自因果 fixture 未施加真实原有 4 条命令，随后按完整实际命令修正测试前提；未放宽生产断言。最终通过日志单独列名。

`deployment-beach-v3.frames/` 包含全部 100 份完整 JSON 帧（world、nextId、双方 memories）：包括每次任务变化前后、600 tick 采样、首次实际登陆、逐死亡事件、建筑摧毁和终帧。运行主 JSON 另保留逐 tick 的 29 人互斥 partition、双方发出的普通命令、命中与策略思考。driver 对嵌套 deck/order/sailing 记录做深拷贝，避免历史记录随实时对象变化；全帧仍是位置与状态的权威证据。

v1/v2 与原生诊断已有独立证据包，本包不重复复制。可衔接 `deployment-beach-v1-v2-evidence.tar.gz`（SHA-256 `45ef370d347c594d70b1e5ce15ae18e045472c1b70922e245dc80cf8a86e0a1a`）。不能把相邻不同源码段合成一份固定源码普通开局。

## 封存与空间清理

该局结束且原 source postflight 通过后，父执行者才对四个已关闭控制树运行 sparse-checkout，排除重复 `docs/art/` 及 docs 中已跟踪的历史 tar.gz。没有清理原 `.playtest` 证据，也没有修改运行源码。本次封存独立重算源码胶囊内和清理后控制树内全部 856 个文件哈希，均与原 manifest 一致；控制树 docs Git status 为空。此说明不将运行后 checkout 内容调整伪称为整个工作区始终未动。

`INDEX.json` 对包内每个载荷列出 SHA-256 与字节数；INDEX 本身不递归自签。外部 `.sha256` 对最终 tar.gz 签名。封存只读取原证据，在 `/tmp/bootstrap-deployment-gate` 写入新产物，未更改源码或原始记录。
