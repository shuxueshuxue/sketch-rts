import {readFileSync,writeFileSync} from 'node:fs';import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame} from '../../src/shared/sim';import {clearBoardingBerth} from '../../src/shared/naval';
const f=JSON.parse(readFileSync('.playtest/overseas-assault-20261015/quay-opening-archer.json.frames/84000.json','utf8'));const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const boat=g.units.find(u=>u.id==='unit-p0-carrier-3777')!,crew=g.units.find(u=>u.order.type==='board'&&u.order.transportId===boat.id)!;
if(crew.order.type!=='board'||!crew.order.berth)throw new Error('No berth');console.log(JSON.stringify({crew:crew.id,requested:crew.order.berth,clear:clearBoardingBerth(g.map,crew,boat,crew.order.berth,g.units),boat:{x:boat.x,y:boat.y}}));
if(process.argv.includes('--walk'))for(let i=0;i<1800;i++){stepGame(g);if(i%300===299)console.log(JSON.stringify({tick:g.tick,x:boat.x,y:boat.y,heading:boat.sailing?.heading,boarded:g.units.filter(u=>u.deck?.shipId===boat.id).length}));}

if(process.argv.includes('--walk'))writeFileSync('.playtest/overseas-assault-20261015/berth-native-85800.json',JSON.stringify({snapshot:snapshotGame(g),nextId:g.nextId}));
