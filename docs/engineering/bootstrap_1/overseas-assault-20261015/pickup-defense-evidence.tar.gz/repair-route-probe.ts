import {readFileSync} from 'node:fs';import {createGame,restoreSnapshotIntoGame,stepGame} from '../../src/shared/sim';
const f=JSON.parse(readFileSync('.playtest/overseas-assault-20261015/summoner-auto-shore.json.frames/144000.json','utf8'));const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const b=g.units.find(u=>u.id==='unit-p0-carrier-40005')!;
for(let i=0;i<120;i++){stepGame(g);if(i<10||i%15===14)console.log(JSON.stringify({t:g.tick,x:b.x,y:b.y,h:b.sailing?.heading,n:b.sailing?.route?.points[0],age:b.sailing?.route?.age}));}
