import fs from 'node:fs';
import crypto from 'node:crypto';
import { sketchScene } from '../src/sdk/scene';
import { issuePlayerCommand, snapshotGame, stepGame } from '../src/shared/sim';
import { setBuildingBodies, snapToFootprint, walkDestination } from '../src/shared/terrain';
import { createAiPolicyMemory } from '../src/ai/memory';
import { AI_SCRIPT_LIBRARY } from '../src/ai/policy/core';
import { runAiCommandEntriesFromScripts } from '../src/ai/policy/script-runner';
import { bootstrapPolicyContext } from '../src/ai/bootstrap_1/policy';
import { mineDefense, planBootstrapGeneral } from '../src/ai/bootstrap_1/mine-defense';
import { readV6Intel } from '../src/ai/policy/v6/intel';
import { mobileCare } from '../src/ai/bootstrap_1/mobile-care';
import { mainlandCareAssignments } from '../src/ai/bootstrap_1/land-recovery';
import { GOLD_MINE_RULES } from '../src/shared/mining';
const E='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const copy=(x:any)=>JSON.parse(JSON.stringify(x));
import { planAiOwnerCommandEntries } from '../src/ai/planner-context';
import { issueCommandFrame } from '../src/sdk/commands/frame';
function twoFronts(raiders = 4, guard: 'lancer' | 'knight' | 'ashWarden' = 'lancer', race: 'grove' | 'ember' = 'grove', naturalGold = 4000) {
  const shooter = race === 'grove' ? 'horseArcher' : 'sparkArcher';
  let scene = sketchScene('independent-mine-defense').replaceDefaults()
    .player('us', { team: 'a', race }).player('fa', { team: 'b', race: 'grove' }).player('fb', { team: 'b', race: 'grove' })
    .townHall('us', 400, 1000).townHall('us', 1600, 1600, { id: 'mine-hall' })
    // These are ordinary five-worker lanes, rather than an intentional long
    // haul. Follow the standard economy while keeping both combat fronts fixed.
    .goldMine('main', 400 + GOLD_MINE_RULES.mainDistance, 1000, 4000)
    .goldMine('natural', 1600 + GOLD_MINE_RULES.mainDistance, 1600, naturalGold)
    .townHall('fa', 3500, 3000, { id: 'attack-hall' }).townHall('fb', 3500, 800)
    .farms('us', 8, 400, 2200);
  for (let i = 0; i < 5; i++) scene = scene.worker('us', 1650 + i * 35, 1700, { id: `miner-${i}` });
  for (let i = 0; i < 2; i++) scene = scene.unit('us', guard, 1750 + i * 50, 1800, { id: `guard-melee-${i}` });
  for (let i = 0; i < 3; i++) scene = scene.unit('us', shooter, 1650 + i * 50, 1850, { id: `guard-ranged-${i}` });
  for (let i = 0; i < 10; i++) scene = scene.unit('us', shooter, 2650 + i % 3 * 40, 2800 + Math.floor(i / 3) * 40,
    { id: `striker-${i}`, order: { type: 'attackMove', x: 3500, y: 3000 } });
  for (let i = 0; i < raiders; i++) scene = scene.unit('fb', 'footman', 1560 + i % 3 * 35, 1120 - Math.floor(i / 3) * 35,
    { id: `raider-${i}`, order: { type: 'attackMove', x: 1600, y: 1600 } });
  const game = scene.build().createGame(), memory = createAiPolicyMemory();
  issuePlayerCommand(game, 'us', { type: 'mine', unitIds: game.units.filter(unit => unit.kind === 'worker').map(unit => unit.id), resourceId: 'natural' });
  memory.v6 = { phase: 3, general: { mode: 'attack', targetHallId: 'attack-hall', target: { x: 3500, y: 3000 },
    group: game.units.filter(unit => unit.id.startsWith('striker')).map(unit => unit.id), groupStart: 15 } };
  return { game, memory, context: () => bootstrapPolicyContext(snapshotGame(game), 'us', 'v9_archer', { memory, teams: game.teams, policyMode: 'combat' }) };
}

function field(race: 'grove' | 'ember', mirror: boolean, well: 'working' | 'absent' | 'incomplete' | 'covered' = 'working', wall = false) {
  const x = (value: number) => mirror ? 4096 - value : value;
  const fighter = race === 'grove' ? 'lancer' : 'emberRavager';
  let scene = sketchScene('critical-front-actual-well').map('openClaims').replaceDefaults()
    .player('us', { race, team: 'a' }).player('foe', { race: 'grove', team: 'b' })
    .townHall('us', x(500), 500).townHall('foe', x(3500), 3500)
    .unit('us', fighter, x(820), 500, { id: 'patient' });
  if (well !== 'absent') scene = scene.building('us', race === 'grove' ? 'moonWell' : 'emberShrine', x(500), 900,
    { id: 'well', complete: well !== 'incomplete' });
  if (well === 'covered') scene = scene.building('foe', 'defenseTower', x(300), 1100);
  if (wall) scene = scene.building('us', race === 'grove' ? 'moonWell' : 'emberShrine', x(1056), 500, { id: 'across-wall' });
  for (let index = 0; index < 5; index++) scene = scene.unit('us', fighter, x(400 + index * 80), 700, { id: `screen-${index}` });
  for (const [index, angle] of [-0.3, 0, 0.3].entries()) scene = scene.unit('foe', 'ballista',
    x(820 + (wall ? Math.sin(angle) * 300 : Math.cos(angle) * 380)),
    500 + (wall ? -Math.cos(angle) * 380 : Math.sin(angle) * 380), { id: `gun-${index}` });
  const game = scene.build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) => {
    const col = mirror ? 127 - index % 128 : index % 128;
    return wall && col === 29 && Math.floor(index / 128) < 96 ? 'T' : '.';
  }).join('') };
  for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
  setBuildingBodies(game.map, game.buildings);
  const own = game.units.filter(unit => unit.owner === 'us'), guns = game.units.filter(unit => unit.owner === 'foe');
  const patient = own.find(unit => unit.id === 'patient')!;
  issuePlayerCommand(game, 'us', { type: 'holdPosition', unitIds: own.map(unit => unit.id) });
  for (const gun of guns) issuePlayerCommand(game, 'foe', { type: 'cast', unitId: gun.id, ability: 'pinningBolt', targetId: patient.id });
  for (let tick = 0; tick < 100 && game.projectiles.length < 3; tick++) stepGame(game);
  if(game.projectiles.length!==3)throw Error('projectiles');
  issuePlayerCommand(game, 'foe', { type: 'move', unitIds: guns.map(unit => unit.id), x: x(wall ? 500 : 3500), y: wall ? 64 : 3000 });
  for (let tick = 0; tick < (wall ? 130 : 30); tick++) stepGame(game);
  if(patient.hp!==patient.maxHp-108)throw Error('patient hp');
  return { game, patient };
}


function setup() {
  const result=twoFronts(8,'knight'), {game}=result;
  for(const u of game.units.filter(u=>u.id.startsWith('raider-')))u.y-=520;
  let scene=sketchScene('outpost-battle').replaceDefaults().player('us').player('fa').tower('us',3000,2600,{id:'outpost'});
  for(let i=0;i<11;i++)scene=scene.unit('fa','footman',3100+i%4*35,2200+Math.floor(i/4)*35,{id:`outpost-foe-${i}`});
  const battle=scene.build().createGame();game.buildings.push(...battle.buildings);game.units.push(...battle.units);
  issuePlayerCommand(game,'fa',{type:'holdPosition',unitIds:battle.units.map(u=>u.id)});
  return result;
}

function run(name:string, setupFn:()=>any, until:number, observe:boolean) {
 const {game,patient}=setupFn(),memory=createAiPolicyMemory();
 if(name==='workingmine')memory.v6={phase:3,general:{mode:'attack',targetHallId:'attack-hall',target:{x:3500,y:3000},group:game.units.filter(u=>u.id.startsWith('striker')).map(u=>u.id),groupStart:15}};
 const fd=observe?fs.openSync(`${E}/front-care-source0-full-${name}.jsonl`,'w'):undefined;
 const row=(x:any)=>{if(fd!==undefined)fs.writeSync(fd,JSON.stringify(x)+'\n')};
 const hits:any[]=[],deaths:any[]=[];
 if(observe)game.observer={hit(a,t,damage,hpBefore){const r={phase:'hit',tick:game.tick,attacker:copy(a),target:copy(t),damage,hpBefore};row(r);hits.push(r)}};
 row({phase:'start',world:snapshotGame(game),nextId:game.nextId,memory,teams:game.teams});
 let last=copy(game.units);
 for(let t=0;t<until;t++){
  if(t%15===0){
   const snapshot=snapshotGame(game),before=copy(memory);
   const entries=planAiOwnerCommandEntries(snapshot,{playerId:'us',version:'v9_knight',memory},{teams:game.teams,policyMode:'combat'});
   row({phase:'think',tick:game.tick,world:snapshot,nextId:game.nextId,memoryBefore:before,memoryAfter:memory,commands:entries});
   issueCommandFrame(game,entries);
  }
  stepGame(game);
  for(const u of last)if(!game.units.some(v=>v.id===u.id)){const r={phase:'death',tick:game.tick,unit:u};row(r);deaths.push({tick:game.tick,id:u.id})}
  last=copy(game.units);
 }
 const terminal={world:snapshotGame(game),nextId:game.nextId,memory};row({phase:'end',...terminal});if(fd!==undefined)fs.closeSync(fd);
 return {terminal,summary:{tick:game.tick,patient:patient&&game.units.find(u=>u.id===patient.id),miners:game.units.filter(u=>u.id.startsWith('miner-')).map(u=>({id:u.id,hp:u.hp})),mineHall:game.buildings.find(b=>b.id==='mine-hall')?.hp,gold:game.players.us!.gold,goldSpent:game.match.stats.goldSpent.us,winner:game.match.winner,deaths,hitsOnPatient:hits.filter(r=>r.target.id==='patient').map(r=>({tick:r.tick,from:r.attacker.id,damage:r.damage,hpBefore:r.hpBefore}))}};
}
const summary:any={source:'97ee2df9c5fd427152dd24db421931ae006ce467',scope:'complete bootstrap combat-mode planner in exact legacy fixtures, ordinary native enemy orders; not full match',runs:{}};
for(const [name,setupFn,until]of [
 ['workingmine',()=>setup(),1400],
 ...(['absent','incomplete','covered'] as const).flatMap(well=>(['grove','ember']as const).flatMap(race=>[false,true].map(mirror=>[`${well}-${race}-${mirror}`,()=>field(race,mirror,well),1200])))
]as any[]){
 const obs=run(name,setupFn,until,true),native=run(name,setupFn,until,false);
 summary.runs[name]={...obs.summary,observerTerminalEqual:JSON.stringify(obs.terminal)===JSON.stringify(native.terminal)};
}
fs.writeFileSync(`${E}/front-care-source0-full-summary.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
