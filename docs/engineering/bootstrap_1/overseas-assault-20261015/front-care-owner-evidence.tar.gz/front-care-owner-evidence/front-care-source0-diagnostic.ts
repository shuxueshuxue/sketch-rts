import fs from 'node:fs';
import crypto from 'node:crypto';
import { sketchScene } from '../src/sdk/scene';
import { issuePlayerCommand, snapshotGame, stepGame } from '../src/shared/sim';
import { setBuildingBodies, snapToFootprint, walkDestination } from '../src/shared/terrain';
import { createAiPolicyMemory } from '../src/ai/memory';
import { AI_SCRIPT_LIBRARY } from '../src/ai/policy/core';
import { runAiCommandEntriesFromScripts } from '../src/ai/policy/script-runner';
import { bootstrapPolicyContext } from '../src/ai/bootstrap_1/policy';
import { mineDefense, planBootstrapGeneral } from '../src/ai/bootstrap_1/mine-defense';
import { readV6Intel } from '../src/ai/policy/v6/intel';
import { mobileCare } from '../src/ai/bootstrap_1/mobile-care';
import { mainlandCareAssignments } from '../src/ai/bootstrap_1/land-recovery';
import { GOLD_MINE_RULES } from '../src/shared/mining';
const E='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const copy=(x:any)=>JSON.parse(JSON.stringify(x));
function twoFronts(raiders = 4, guard: 'lancer' | 'knight' | 'ashWarden' = 'lancer', race: 'grove' | 'ember' = 'grove', naturalGold = 4000) {
  const shooter = race === 'grove' ? 'horseArcher' : 'sparkArcher';
  let scene = sketchScene('independent-mine-defense').replaceDefaults()
    .player('us', { team: 'a', race }).player('fa', { team: 'b', race: 'grove' }).player('fb', { team: 'b', race: 'grove' })
    .townHall('us', 400, 1000).townHall('us', 1600, 1600, { id: 'mine-hall' })
    // These are ordinary five-worker lanes, rather than an intentional long
    // haul. Follow the standard economy while keeping both combat fronts fixed.
    .goldMine('main', 400 + GOLD_MINE_RULES.mainDistance, 1000, 4000)
    .goldMine('natural', 1600 + GOLD_MINE_RULES.mainDistance, 1600, naturalGold)
    .townHall('fa', 3500, 3000, { id: 'attack-hall' }).townHall('fb', 3500, 800)
    .farms('us', 8, 400, 2200);
  for (let i = 0; i < 5; i++) scene = scene.worker('us', 1650 + i * 35, 1700, { id: `miner-${i}` });
  for (let i = 0; i < 2; i++) scene = scene.unit('us', guard, 1750 + i * 50, 1800, { id: `guard-melee-${i}` });
  for (let i = 0; i < 3; i++) scene = scene.unit('us', shooter, 1650 + i * 50, 1850, { id: `guard-ranged-${i}` });
  for (let i = 0; i < 10; i++) scene = scene.unit('us', shooter, 2650 + i % 3 * 40, 2800 + Math.floor(i / 3) * 40,
    { id: `striker-${i}`, order: { type: 'attackMove', x: 3500, y: 3000 } });
  for (let i = 0; i < raiders; i++) scene = scene.unit('fb', 'footman', 1560 + i % 3 * 35, 1120 - Math.floor(i / 3) * 35,
    { id: `raider-${i}`, order: { type: 'attackMove', x: 1600, y: 1600 } });
  const game = scene.build().createGame(), memory = createAiPolicyMemory();
  issuePlayerCommand(game, 'us', { type: 'mine', unitIds: game.units.filter(unit => unit.kind === 'worker').map(unit => unit.id), resourceId: 'natural' });
  memory.v6 = { phase: 3, general: { mode: 'attack', targetHallId: 'attack-hall', target: { x: 3500, y: 3000 },
    group: game.units.filter(unit => unit.id.startsWith('striker')).map(unit => unit.id), groupStart: 15 } };
  return { game, memory, context: () => bootstrapPolicyContext(snapshotGame(game), 'us', 'v9_archer', { memory, teams: game.teams, policyMode: 'combat' }) };
}

function field(race: 'grove' | 'ember', mirror: boolean, well: 'working' | 'absent' | 'incomplete' | 'covered' = 'working', wall = false) {
  const x = (value: number) => mirror ? 4096 - value : value;
  const fighter = race === 'grove' ? 'lancer' : 'emberRavager';
  let scene = sketchScene('critical-front-actual-well').map('openClaims').replaceDefaults()
    .player('us', { race, team: 'a' }).player('foe', { race: 'grove', team: 'b' })
    .townHall('us', x(500), 500).townHall('foe', x(3500), 3500)
    .unit('us', fighter, x(820), 500, { id: 'patient' });
  if (well !== 'absent') scene = scene.building('us', race === 'grove' ? 'moonWell' : 'emberShrine', x(500), 900,
    { id: 'well', complete: well !== 'incomplete' });
  if (well === 'covered') scene = scene.building('foe', 'defenseTower', x(300), 1100);
  if (wall) scene = scene.building('us', race === 'grove' ? 'moonWell' : 'emberShrine', x(1056), 500, { id: 'across-wall' });
  for (let index = 0; index < 5; index++) scene = scene.unit('us', fighter, x(400 + index * 80), 700, { id: `screen-${index}` });
  for (const [index, angle] of [-0.3, 0, 0.3].entries()) scene = scene.unit('foe', 'ballista',
    x(820 + (wall ? Math.sin(angle) * 300 : Math.cos(angle) * 380)),
    500 + (wall ? -Math.cos(angle) * 380 : Math.sin(angle) * 380), { id: `gun-${index}` });
  const game = scene.build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) => {
    const col = mirror ? 127 - index % 128 : index % 128;
    return wall && col === 29 && Math.floor(index / 128) < 96 ? 'T' : '.';
  }).join('') };
  for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
  setBuildingBodies(game.map, game.buildings);
  const own = game.units.filter(unit => unit.owner === 'us'), guns = game.units.filter(unit => unit.owner === 'foe');
  const patient = own.find(unit => unit.id === 'patient')!;
  issuePlayerCommand(game, 'us', { type: 'holdPosition', unitIds: own.map(unit => unit.id) });
  for (const gun of guns) issuePlayerCommand(game, 'foe', { type: 'cast', unitId: gun.id, ability: 'pinningBolt', targetId: patient.id });
  for (let tick = 0; tick < 100 && game.projectiles.length < 3; tick++) stepGame(game);
  if(game.projectiles.length!==3)throw Error('projectiles');
  issuePlayerCommand(game, 'foe', { type: 'move', unitIds: guns.map(unit => unit.id), x: x(wall ? 500 : 3500), y: wall ? 64 : 3000 });
  for (let tick = 0; tick < (wall ? 130 : 30); tick++) stepGame(game);
  if(patient.hp!==patient.maxHp-108)throw Error('patient hp');
  return { game, patient };
}


function setup() {
  const result=twoFronts(8,'knight'), {game}=result;
  for(const u of game.units.filter(u=>u.id.startsWith('raider-')))u.y-=520;
  let scene=sketchScene('outpost-battle').replaceDefaults().player('us').player('fa').tower('us',3000,2600,{id:'outpost'});
  for(let i=0;i<11;i++)scene=scene.unit('fa','footman',3100+i%4*35,2200+Math.floor(i/4)*35,{id:`outpost-foe-${i}`});
  const battle=scene.build().createGame();game.buildings.push(...battle.buildings);game.units.push(...battle.units);
  issuePlayerCommand(game,'fa',{type:'holdPosition',unitIds:battle.units.map(u=>u.id)});
  return result;
}
function run(name:string, care:boolean, observe:boolean) {
 const {game,memory,context}=setup();
 const fd=observe?fs.openSync(`${E}/front-care-source0-${name}.jsonl`,'w'):undefined;
 const row=(x:any)=>{if(fd!==undefined)fs.writeSync(fd,JSON.stringify(x)+'\n')};
 row({phase:'start',world:snapshotGame(game),nextId:game.nextId,memory,teams:game.teams});
 if(observe)game.observer={hit(a,t,damage,hpBefore){row({phase:'hit',tick:game.tick,attacker:copy(a),target:copy(t),damage,hpBefore})}};
 const general=name.startsWith('legacy')?AI_SCRIPT_LIBRARY.v6General:{...AI_SCRIPT_LIBRARY.v6General,run:planBootstrapGeneral};
 const scripts=care?[mineDefense,mobileCare,general]:[mineDefense,general];
 const last=new Map();
 for(let t=0;t<1400;t++){
   if(t%15===0){
     const snapshot=snapshotGame(game),options=context(), before=copy(memory);
     const probe={...options,memory:copy(memory)};
     const claims=[...mobileCare.claimsUnits!(snapshot,'us',probe)], careCommands=mobileCare.run(snapshot,'us',probe);
     const guard=[...mineDefense.claimsUnits!(snapshot,'us',{...options,memory:copy(memory)})];
     const entries=runAiCommandEntriesFromScripts(snapshot,'us',scripts,options);
     row({phase:'think',tick:game.tick,world:snapshot,nextId:game.nextId,memoryBefore:before,memoryAfter:memory,guard,careClaims:claims,careCommands,commands:entries});
     for(const {command} of entries)issuePlayerCommand(game,'us',command);
   }
   stepGame(game);
   for(const [id,unit] of last)if(!game.units.some(u=>u.id===id))row({phase:'death',tick:game.tick,unit});
   last.clear();for(const u of game.units)last.set(u.id,copy(u));
 }
 row({phase:'end',world:snapshotGame(game),nextId:game.nextId,memory});if(fd!==undefined)fs.closeSync(fd);
 const terminal={world:snapshotGame(game),nextId:game.nextId,memory};
 return {terminal,summary:{tick:game.tick,miners:game.units.filter(u=>u.id.startsWith('miner-')).map(u=>({id:u.id,hp:u.hp,order:u.order})),guards:game.units.filter(u=>u.id.startsWith('guard-')).map(u=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),raiders:game.units.filter(u=>u.id.startsWith('raider-')).map(u=>({id:u.id,hp:u.hp})),gold:game.players.us!.gold,mineHall:game.buildings.find(b=>b.id==='mine-hall')?.hp,stats:game.match.stats}};
}
const summary:any={source:'97ee2df9c5fd427152dd24db421931ae006ce467',scope:'synthetic legacy exact two-script fixture, diagnostic; not full AI/match',runs:{}};
for(const [name,care]of [['legacy',false],['bootstrap',false],['bootstrap-care',true]] as const){
 const observed=run(name,care,true), native=run(name,care,false);
 summary.runs[name]={...observed.summary,observerTerminalEqual:JSON.stringify(observed.terminal)===JSON.stringify(native.terminal)};
}
summary.front=[];
for(const well of ['absent','incomplete','covered'] as const){
 const {game,patient}=field('grove',false,well),memory=createAiPolicyMemory();
 const snapshot=snapshotGame(game),options=bootstrapPolicyContext(snapshot,'us','v9_knight',{memory,teams:game.teams});
 const careClaims=[...mobileCare.claimsUnits!(snapshot,'us',{...options,memory:copy(memory)})];
 const careCommands=mobileCare.run(snapshot,'us',{...options,memory:copy(memory)});
 const general=planBootstrapGeneral(snapshot,'us',options);
 summary.front.push({well,tick:game.tick,patient:copy(patient),careClaims,careCommands,general});
 fs.writeFileSync(`${E}/front-care-source0-front-${well}.json`,JSON.stringify({world:snapshot,nextId:game.nextId,memory,teams:game.teams,careClaims,careCommands,general}));
}
fs.writeFileSync(`${E}/front-care-source0-summary.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
