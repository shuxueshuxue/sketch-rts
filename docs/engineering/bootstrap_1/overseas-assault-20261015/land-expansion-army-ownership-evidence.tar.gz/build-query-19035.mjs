import { build } from '/workspace/sketch-rts/node_modules/esbuild/lib/main.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const dir='/workspace/.playtest/land-expansion-army-audit-20261016';
const source='/workspace/sketch-rts-land-income-reserve-control';
const changed=[];
await build({entryPoints:[dir+'/query-army-19035.ts'],outfile:dir+'/query-army-19035.mjs',bundle:true,platform:'node',format:'esm',target:'node22',packages:'external',plugins:[{name:'read-only-army-observation',setup(build){build.onLoad({filter:/src\/ai\/(bootstrap_1\/mine-defense|policy\/v6\/general)\.ts$/},async args=>{let contents=readFileSync(args.path,'utf8');const before=contents;
if(args.path.endsWith('/mine-defense.ts'))contents+='\nexport {miningRaids,detachment};\n';
else {const anchor='  const defense = plan.defenseTarget(snapshot, intel, options);';if(!contents.includes(anchor))throw Error('General anchor mismatch');contents=contents.replace(anchor,anchor+'\n  (globalThis as any).__armyAudit?.({intel,available,front,strength,miningFirst,constructing,reserveExpansion:plan.reserveExpansion,outweighed,escort,rally,defense,memoryGeneralBefore:memory.general});');}
changed.push({path:args.path,originalSHA256:createHash('sha256').update(before).digest('hex'),transformOnlyInExternalBundle:true});return{contents,loader:'ts',resolveDir:args.path.slice(0,args.path.lastIndexOf('/'))};});}}]});
writeFileSync(dir+'/instrumentation-19035.json',JSON.stringify({source,changed,productionFilesWritten:false},null,2));
