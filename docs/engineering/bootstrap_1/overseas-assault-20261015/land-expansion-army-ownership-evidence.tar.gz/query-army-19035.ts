import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { planAiOwnerCommandEntries } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/planner-context';
import { bootstrapScripts } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/bootstrap_1/policy';
import { readV6Intel } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/policy/v6/intel';
import { strengthOf } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/policy/v6/strength';
import { routeTravelTicks, groundSteeringRoute, routeArrivals } from '/workspace/sketch-rts-land-income-reserve-control/src/shared/route-selection';
import { sameGround, walkingDistance } from '/workspace/sketch-rts-land-income-reserve-control/src/shared/terrain';
import { mineGuardUnitIds, miningRaids, detachment } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/bootstrap_1/mine-defense';
import { isBacklineKind } from '/workspace/sketch-rts-land-income-reserve-control/src/ai/policy/v6/backline';
const source='/workspace/sketch-rts-land-income-reserve-control';
const base='/workspace/.playtest/bootstrap-land-income-lead-20261015';
const out='/workspace/.playtest/land-expansion-army-audit-20261016';
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const sha=(b:any)=>createHash('sha256').update(b).digest('hex');
const preflight=JSON.parse(readFileSync(base+'/income-reserve40968-preflight-source.json','utf8'));
function checkSource(){const changes=Object.entries(preflight.hashes).filter(([p,h])=>sha(readFileSync(source+'/'+p))!==h).map(([p])=>p);if(changes.length)throw Error('Fixed source changed');return{files:Object.keys(preflight.hashes).length,changes};}
const sourceBefore=checkSource();
const report=JSON.parse(readFileSync(base+'/reserve40968-from17400-to21600.json','utf8'));
const rows:any[]=[];
for(const tick of [19035]){
  const inputPath=out+'/original-saved-19035.json',inputBytes=readFileSync(inputPath),saved=JSON.parse(inputBytes.toString());
  const inputBefore=JSON.stringify(saved),snapshot=saved.snapshot,memory=copy(saved.memories.p0);
  const claims:any[]=[],runs:any[]=[];let general:any;
  (globalThis as any).__armyAudit=(data:any)=>{general=copy(data);};
  const scripts=bootstrapScripts('v9_archer').map(script=>({...script,
    ...(script.claimsUnits?{claimsUnits(view:any,owner:any,options:any){const ids=script.claimsUnits!(view,owner,options);claims.push({scriptId:script.id,ids:[...ids]});return ids;}}:{}),
    run(view:any,owner:any,options:any){const before=copy(options.memory),result=script.run(view,owner,options);runs.push({scriptId:script.id,memoryBefore:before,options:Object.fromEntries(Object.entries(options).filter(([k])=>k!=='memory')),commands:copy(result??[])});return result;},
  }));
  const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',source:'external-agent',scripts,memory},{teams:snapshot.teams});
  const expected=report.commands.find((c:any)=>c.tick===tick&&c.owner==='p0')?.entries??[];
  const commandsExactlyMatchOriginal=isDeepStrictEqual(copy(entries),expected);
  const ownerById:any={};for(const c of claims)for(const id of c.ids)ownerById[id]??=c.scriptId;
  const generalRun=runs.find(r=>r.scriptId==='v6General');
  const opts={...generalRun.options,memory:copy(generalRun.memoryBefore)};
  const intel=readV6Intel(snapshot,'p0',opts),hall=snapshot.buildings.find((b:any)=>b.id==='building-p0-townHall-17183'),mine=snapshot.resources.find((m:any)=>m.id==='gold-gen-5');
  const raids=miningRaids(snapshot,intel);
  const pool=intel.army.filter((u:any)=>!u.deck&&u.hp>=u.maxHp*.6&&!['board','cast','charge'].includes(u.order.type));
  const raidsDetails=raids.map((r:any)=>{
    const arrivals=routeArrivals(snapshot.map,pool,r.hall,'land');
    const nearby=arrivals.filter(({unit,ticks}:any)=>ticks<20*1300/unit.speed&&(unit.expiresTick===undefined||unit.expiresTick>snapshot.tick+ticks)).map(({unit}:any)=>unit);
    const fighters=nearby.filter((u:any)=>!isBacklineKind(u)&&u.attackDamage>0);
    return{hallId:r.hall.id,hall:{x:r.hall.x,y:r.hall.y},attackers:r.attackers.map((u:any)=>({id:u.id,kind:u.kind,owner:u.owner,x:u.x,y:u.y,order:u.order,power:strengthOf([u])})),attackerPower:strengthOf(r.attackers),nearby1300Ids:nearby.map((u:any)=>u.id),nearbyFrontlineIds:fighters.map((u:any)=>u.id),nearbyFrontlinePower:strengthOf(fighters),arrivalTicks:arrivals.map(({unit,ticks}:any)=>({id:unit.id,ticks,passes1300:ticks<20*1300/unit.speed})),towerCoverAtHall:intel.ownTowers.filter((t:any)=>Math.hypot(t.x-r.hall.x,t.y-r.hall.y)<=t.attackRange).map((t:any)=>t.id)};
  });
  const points:any={newHall:hall,newMine:mine,nativeGeneralBefore:generalRun.memoryBefore.v6?.general?.target,nativeGeneralAfter:memory.v6?.general?.target,oldWorkingHall:snapshot.buildings.find((b:any)=>b.id==='building-p0-townHall-1639')};
  const routes=(u:any)=>Object.fromEntries(Object.entries(points).filter(([,p])=>!!p).map(([name,p]:any)=>[name,{x:p.x,y:p.y,direct:Math.hypot(u.x-p.x,u.y-p.y),sameLandComponent:sameGround(snapshot.map,u,p),terrainRoad:walkingDistance(snapshot.map,u,p),nativeCenterRouteTicks:routeTravelTicks(snapshot.map,u,p,'land',u.speed),bodySteeringPoints:groundSteeringRoute(snapshot.map,u,p)}]));
  const army=snapshot.units.filter((u:any)=>u.owner==='p0'&&u.kind!=='worker').map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,speed:u.speed,power:strengthOf([u]),backline:isBacklineKind(u),order:u.order,claimOwner:ownerById[u.id]??null,allClaims:claims.filter(c=>c.ids.includes(u.id)).map(c=>c.scriptId),inActualMainArmy:general.intel.army.some((a:any)=>a.id===u.id),inActualAvailableArmy:general.available.some((a:any)=>a.id===u.id),inActualFront:general.front.some((a:any)=>a.id===u.id),actualEntries:entries.filter((e:any)=>'unitIds'in e.command?e.command.unitIds.includes(u.id):e.command.unitId===u.id),routes:routes(u)}));
  const enemyFronts=snapshot.units.filter((u:any)=>['p1','p2'].includes(u.owner)&&u.kind!=='worker').map((u:any)=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,power:strengthOf([u]),x:u.x,y:u.y,order:u.order,routeToNewHall:hall?walkingDistance(snapshot.map,u,hall):undefined,routeToOldWorkingHall:walkingDistance(snapshot.map,u,points.oldWorkingHall)}));
  rows.push({tick,inputPath,inputSHA256:sha(inputBytes),allCompleteWorldNextIdAllMemoriesUnchanged:JSON.stringify(saved)===inputBefore,commandsExactlyMatchOriginal,entries,claims,runs,generalDecision:general,mainGeneralBefore:generalRun.memoryBefore.v6?.general,mainGeneralAfter:memory.v6?.general,allP0MemoryAfter:memory,newHall:hall,newMine:mine,raidsDetails,mineGuardIds:[...mineGuardUnitIds(snapshot,'p0',opts)],detachment:detachment(snapshot,'p0',opts),army,enemyFronts});
  console.log(JSON.stringify({tick,commandsExactlyMatchOriginal,allInputUnchanged:JSON.stringify(saved)===inputBefore,mainGeneralBefore:generalRun.memoryBefore.v6?.general,mainGeneralAfter:memory.v6?.general,mainStrength:general.strength,frontIds:general.front.map((u:any)=>u.id),outweighed:general.outweighed,escort:general.escort,defense:general.defense,raidHallIds:raidsDetails.map((r:any)=>r.hallId)}));
  if(!commandsExactlyMatchOriginal||JSON.stringify(saved)!==inputBefore)throw Error('Read-only actual planner query closure failed');
}
writeFileSync(out+'/army-19035.json',JSON.stringify({classification:'Read-only full public p0 planner at existing saved frames with original claim/run callbacks delegated once. No command applied, no simulation or new world. External source transform only exports existing private pure queries and observes existing locals after defense selection; fixed source bytes unchanged. Native center-route time is an unobstructed-current-world query, not actual arrival guarantee.',source,commit:preflight.commit,sourceBefore,sourceAfter:checkSource(),rows},null,2));
