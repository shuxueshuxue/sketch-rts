import {writeFileSync} from "node:fs";
import {
  createGame,
  issuePlayerCommand,
  snapshotGame,
  stepGame,
} from "../../src/shared/sim";
import { boardUnit, syncDecks } from "../../src/shared/decks";
import { seconds } from "../../src/shared/time";
import { combatCapability } from "../../src/shared/combat-capabilities";
import { installedWeapons } from "../../src/shared/ship-equipment";
import { hullContact } from "../../src/shared/ship-geometry";
import { hullFits } from "../../src/shared/ship-navigation";
import { createAiPolicyMemory } from "../../src/ai/memory";
import { navalServices } from "../../src/ai/policy/naval-services";
import { fleetStations } from "../../src/ai/policy/fleet-formation";
import { createBuilding } from '../../src/shared/map';

function sea() {
  const game = createGame("bareDuel", { aiPlayers: [] });
  game.units = [];
  game.buildings = [];
  game.resources = [];
  game.map.terrain = {
    cell: 40,
    cols: 100,
    rows: 100,
    cells: "~".repeat(10000),
  };
  game.map.width = game.map.height = 4000;
  game.scriptedVictory = true;
  game.players.player!.gold = 3000;
  return game;
}
    const game = sea();
    game.map.terrain!.cells = Array.from({ length: 100 }, () => '.'.repeat(25) + ',' + '~'.repeat(74)).join('');
    game.buildings.push(createBuilding('dock', 'player', 'shipyard', 1000, 600, true));
    const ship = game.spawnUnit('player', 'warship', 1250, 900);
    game.spawnUnit('player', 'warship', 1800, 1500);
    const workers = Array.from({ length: 7 }, (_, i) => game.spawnUnit('player', 'worker', 900, 750 + i * 40));
    const engineer = workers[4]!;
    ship.order = { type: 'hold', x: ship.x, y: ship.y };
    const services = navalServices(snapshotGame(game), 'player', { version: 'v8', memory: createAiPolicyMemory() });
    for (const command of services.commands) issuePlayerCommand(game, 'player', command);
    const trace:any[]=[];
    let approachSail = 0, travel = 0, totalYaw = 0;
    // The aligned berth can use a short astern approach at auxiliary speed.
    // Bound distance and turning as well as completion time.
    for (let tick = 0; tick < seconds(30); tick++) {
      const before = {x:ship.x,y:ship.y,heading:ship.sailing!.heading};
      stepGame(game);
      travel += Math.hypot(ship.x-before.x,ship.y-before.y);
      const turn=ship.sailing!.heading-before.heading;totalYaw+=Math.abs(Math.atan2(Math.sin(turn),Math.cos(turn)));
      if(tick%20===0)trace.push({tick:game.tick,ship:structuredClone(ship),worker:structuredClone(engineer)});
      if (!engineer.deck) approachSail = Math.max(approachSail, ship.sailing!.sail?.set ?? 0);
    }
console.log({travel,totalYaw});writeFileSync(process.argv[2]!,JSON.stringify({trace,travel,totalYaw,snapshot:snapshotGame(game)}));
