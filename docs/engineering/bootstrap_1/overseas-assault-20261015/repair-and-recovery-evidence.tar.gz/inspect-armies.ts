import {readFileSync,writeFileSync} from 'node:fs';
import {sameGround,walkingDistance} from '../../src/shared/terrain';
import {unitMover} from '../../src/shared/catalog';
import {effectiveCombatRating} from '../../src/ai/policy/v6/strength';
import {bootstrapPolicyContext} from '../../src/ai/bootstrap_1/policy';
import {rankBootstrapGoals} from '../../src/ai/bootstrap_1/economy';
import {colonyNavalWant,navalBudgetReserve} from '../../src/ai/policy/naval';
const [reportPath='.playtest/shore-traffic/candidate.json',out='.playtest/overseas-assault-20261015/armies.json']=process.argv.slice(2);
const report=JSON.parse(readFileSync(reportPath,'utf8')),row=report.rows.at(-1),{snapshot:s}=JSON.parse(readFileSync(`${reportPath}.frames/${row.tick}.json`,'utf8'));
const groups:any[]=[];
for(const u of s.units.filter((u:any)=>!u.deck&&unitMover(u.kind)==='land'&&u.owner!=='neutral')){
 let g=groups.find(g=>g.owner===u.owner&&sameGround(s.map,g.at,u));
 if(!g){g={owner:u.owner,at:{x:u.x,y:u.y},units:[],halls:[],mines:[]};groups.push(g);}
 g.units.push(u);
}
for(const g of groups){g.halls=s.buildings.filter((b:any)=>b.kind==='townHall'&&b.owner===g.owner&&sameGround(s.map,g.at,b)).map((b:any)=>({id:b.id,x:b.x,y:b.y}));g.mines=s.resources.filter((m:any)=>sameGround(s.map,g.at,m)).map((m:any)=>({id:m.id,amount:m.amount}));g.kinds=Object.fromEntries([...new Set(g.units.map((u:any)=>u.kind))].map(k=>[k,g.units.filter((u:any)=>u.kind===k).length]));g.strength=g.units.filter((u:any)=>u.kind!=='worker').reduce((n:number,u:any)=>n+effectiveCombatRating(s,u),0);g.orders=Object.fromEntries([...new Set(g.units.map((u:any)=>u.order.type))].map(k=>[k,g.units.filter((u:any)=>u.order.type===k).length]));delete g.units;}
const context=bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(row.players.p0.policy),teams:s.teams});
const result={tick:s.tick,groups,naval:context.memory.naval,goals:rankBootstrapGoals(s,'p0',context).map(({id,cost,priority})=>({id,cost,priority})),navalWant:colonyNavalWant(s,'p0',context)?.id,reserve:navalBudgetReserve(s,'p0',context),ships:s.units.filter((u:any)=>u.owner==='p0'&&unitMover(u.kind)==='sea').map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:u.order,passengers:s.units.filter((p:any)=>p.deck?.shipId===u.id).map((p:any)=>({id:p.id,kind:p.kind}))})),enemyBuildings:s.buildings.filter((b:any)=>b.owner==='p1').map((b:any)=>({id:b.id,kind:b.kind,x:b.x,y:b.y,hp:b.hp}))};
writeFileSync(out,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
