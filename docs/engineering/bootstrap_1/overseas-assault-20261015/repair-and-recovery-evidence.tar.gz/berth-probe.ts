import {readFileSync} from 'node:fs';
import {shipSolidTraffic,shipBodyClearAtPose} from '../../src/shared/ship-collisions';
import {hullFits} from '../../src/shared/ship-navigation';
import {distanceToHull} from '../../src/shared/ship-geometry';
const {snapshot:s}=JSON.parse(readFileSync('.playtest/overseas-assault-20261015/pickup-trace.json','utf8'));
const boat=s.units.find((u:any)=>u.kind==='carrier'),passenger=s.units.find((u:any)=>u.order.type==='board'),berth=passenger.order.berth;
const clear=shipSolidTraffic(s.map,boat,s.units);
for(let offset=-48;offset<=16;offset+=8){const pose={...berth,x:berth.x+offset},dock={...boat,...pose,sailing:{...boat.sailing,heading:pose.heading}};console.log({offset,terrain:hullFits(s.map,boat,pose),solid:shipBodyClearAtPose(s.map,boat,pose,s.units),gap:distanceToHull(dock,passenger),shoreGap:distanceToHull(dock,berth.shore)});}
