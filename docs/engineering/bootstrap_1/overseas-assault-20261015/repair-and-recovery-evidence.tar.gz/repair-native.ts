import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame} from '../../src/shared/sim';
import {shipNeedsRepair} from '../../src/shared/ship-equipment';
const saved=JSON.parse(readFileSync('.playtest/overseas-assault-20261015/berth-opening.json.frames/36000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const boat=game.units.find(u=>u.id==='unit-p0-transport-1046')!,worker=game.units.find(u=>u.id==='unit-p0-worker-1669')!,trace:any[]=[];
for(let i=0;i<6000;i++){
 stepGame(game);
 if(i%300===0)trace.push({tick:game.tick,boat:structuredClone(boat),worker:structuredClone(worker)});
 if(worker.deck?.shipId===boat.id && !shipNeedsRepair(snapshotGame(game),boat))break;
}
console.log({tick:game.tick,worker:worker.deck,order:worker.order,repair:shipNeedsRepair(snapshotGame(game),boat)});
writeFileSync('.playtest/overseas-assault-20261015/repair-native.json',JSON.stringify({trace,snapshot:snapshotGame(game),nextId:game.nextId}));
