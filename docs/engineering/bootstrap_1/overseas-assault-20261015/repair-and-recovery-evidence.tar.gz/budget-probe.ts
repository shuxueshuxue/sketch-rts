import {readFileSync,writeFileSync} from 'node:fs';
import {bootstrapGame,bootstrapMatches} from '../../src/ai/bootstrap_1/benchmark';
import {runAiGameLoop} from '../../src/ai/game-runner';
import {createAiMemoryProvider} from '../../src/ai/planner-context';
import {createBootstrapCommandPlanner} from '../../scripts/bootstrap_1-planner';
import {restoreSnapshotIntoGame} from '../../src/shared/sim';
import {bootstrapPolicyContext} from '../../src/ai/bootstrap_1/policy';
import {navalBudgetReserve} from '../../src/ai/policy/naval';
import {sameGround} from '../../src/shared/terrain';
const source='.playtest/overseas-assault-20261015/berth-opening.json',report=JSON.parse(readFileSync(source,'utf8')),row=report.rows.find((r:any)=>r.tick===36000),saved=JSON.parse(readFileSync(source+'.frames/36000.json','utf8'));
const match=bootstrapMatches('bootstrap_1-development',['sapphireArchipelago'],36100).find(m=>m.subject==='v9_archer'&&m.agents.p0!.race==='grove'&&m.side===0&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!;
const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
for(const [owner,p]of Object.entries(row.players))memories.set!(owner,(p as any).policy);
const planner=await createBootstrapCommandPlanner(memories),trace:any[]=[];
runAiGameLoop({...match,game,commandPlanner:context=>{
 const entries=planner(context),s=context.snapshot;
 if(context.owner==='p0'){
 const options=bootstrapPolicyContext(s,'p0','v9_archer',{memory:memories.get('p0')!,teams:s.teams});
 const halls=s.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall');
 trace.push({tick:s.tick,gold:s.players.p0!.gold,reserve:navalBudgetReserve(s,'p0',options),builds:s.units.filter(u=>u.owner==='p0'&&u.order.type==='build').map(u=>u.order),local:s.resources.filter(m=>m.amount>0&&halls.some(h=>sameGround(s.map,h,m))).map(m=>({id:m.id,amount:m.amount})),entries});
 }
 return entries;
}});
writeFileSync('.playtest/overseas-assault-20261015/budget-probe.json',JSON.stringify(trace,null,2));console.log(JSON.stringify(trace,null,2));
