import { restoreCargoDecks, boardUnit } from "../../src/shared/decks";
import {writeFileSync} from "node:fs";
import { createUnit } from "../../src/shared/map";
import { createGame, issuePlayerCommand, snapshotGame as rawSnapshotGame, stepGame } from "../../src/shared/sim";
import { isShoreFootprint, isWalkable, sameGround, type Terrain } from "../../src/shared/terrain";
import { createAiPolicyMemory } from "../../src/ai/memory";
import { desiredExpansionMine } from "../../src/ai/policy/expansion-model";
import { navalUnitIds, navalWant, navalBudgetReserve, planNavalTactics } from "../../src/ai/policy/naval";
import { nextExpansionMine, readV6Intel } from "../../src/ai/policy/v6/intel";
import { projectedSupplyUsed } from "../../src/ai/policy/world-model";
import { installedWeapons, shipPartMax } from '../../src/shared/ship-equipment';
import { headingDifference, planShipRoute } from '../../src/shared/ship-navigation';
import { createAiRuntime, createPresetAiRuntimeFramePlanner } from '../../src/ai/runtime';
import { CommandFrameRuntime } from '../../src/shared/sim/command-frame-runtime';
import { seconds } from '../../src/shared/time';
import { runAiCommandEntriesFromScripts } from '../../src/ai/policy/script-runner';
import { planNavalEconomy } from '../../src/ai/policy/naval';
import { frozenPolicyModules } from '../../scripts/bootstrap_1-planner';
import { hullFits } from '../../src/shared/ship-navigation';
import { BUILDING_DEFS, UNIT_DEFS } from '../../src/shared/catalog';
import { LANDING_REACH, passengerLandingSpot } from '../../src/shared/naval';
import { shipProfile } from '../../src/shared/ship-geometry';

// Tests that model old cargo saves observe the same restored live crew as the runtime.
function snapshotGame(game: ReturnType<typeof createGame>) {
  restoreCargoDecks(game.units);
  return rawSnapshotGame(game);
}

// A 30 by 20 grid: land in columns 0-8, shallows down column 9, the sea beyond, and in it an island (columns 20-24, rows
// 7-12) ringed with shallows.
function coast(): Terrain {
  let cells = "";
  for (let row = 0; row < 20; row += 1) {
    for (let col = 0; col < 30; col += 1) {
      const island = col >= 20 && col <= 24 && row >= 7 && row <= 12;
      const rim = col >= 19 && col <= 25 && row >= 6 && row <= 13;
      cells += col <= 8 || island ? "." : col === 9 || rim ? "," : "~";
    }
  }
  return { cell: 32, cols: 30, rows: 20, cells };
}

const at = (col: number, row: number) => ({ x: col * 32 + 16, y: row * 32 + 16 });

// The player holds two halls on the land with workers mining; the only other mine is the island's.
function islandGame(terrain = coast(), players = ["player", "enemy"]) {
  const game = createGame("bareDuel", {
    players,
    scenario: {
      players: { player: { gold: 1_000 } },
      replaceDefaultUnits: true,
      replaceDefaultBuildings: true,
      replaceDefaultResources: true,
      replaceDefaultMercenaryCamps: true,
      replaceDefaultLandmarks: true,
      addBuildings: [
        { id: "hall-a", owner: "player", kind: "townHall", ...at(3, 3) },
        { id: "hall-b", owner: "player", kind: "townHall", ...at(3, 15) },
        { id: "farm", owner: "player", kind: "farm", ...at(5, 18) },
      ],
      addResources: [
        { id: "main", kind: "goldMine", ...at(1, 3), amount: 6_000 },
        { id: "natural", kind: "goldMine", ...at(1, 15), amount: 6_000 },
        { id: "island", kind: "goldMine", ...at(22, 9), amount: 6_000 },
      ],
      addUnits: [
        { id: "w1", owner: "player", kind: "worker", ...at(2, 4), order: { type: "mine", resourceId: "main", phase: "toMine", timer: 0 } },
        { id: "w2", owner: "player", kind: "worker", ...at(2, 14), order: { type: "mine", resourceId: "natural", phase: "toMine", timer: 0 } },
      ],
    },
  });
  game.map = { ...game.map, width: terrain.cols * terrain.cell, height: terrain.rows * terrain.cell, terrain };
  for(let i=3;i<=6;i++)game.units.push({...createUnit(`w${i}`,"player","worker",at(3,4+i).x,at(3,4+i).y),order:{type:"mine",resourceId:"main",phase:"toMine",timer:0}});
  return game;
}

const version="v5" as const;const started=Date.now();
    // The island fits a hall outside the ordinary 280-unit hauling distance.
    const terrain=coast();terrain.cols=36;
    terrain.cells=Array.from({length:terrain.rows},(_,row)=>Array.from({length:terrain.cols},(_,col)=>
      col<=8 || col>=20 && col<=33 && row>=5 && row<=14 ? '.' : col===9 || col>=19 && col<=34 && row>=4 && row<=15 ? ',' : '~').join('')).join('');
    const game=islandGame(terrain);game.scriptedVictory=true;
    game.players.player!.gold=3000;
    game.buildings.push({...game.buildings[0]!,id:'colony-yard',kind:'shipyard',x:275,y:336,radius:44,complete:true});
    game.spawnUnit('player','transport',400,336);
    const ai=createAiRuntime(['player'],{version});
    const runtime=new CommandFrameRuntime({game,roomId:'colony-test',rejectionLabel:'colony-test',aiPlanner:createPresetAiRuntimeFramePlanner(game,ai)});
    let arrived=false,mined=false,colony=false;
    const mine=game.resources.find(m=>m.id==='island')!;
    for(let tick=0;tick<seconds(240) && !(mined&&colony);tick++){
      runtime.tick();
      if(tick%300===0)console.log(JSON.stringify({tick:game.tick,seconds:(Date.now()-started)/1000,units:game.units.length}));
      arrived ||= game.units.some(u=>u.kind==='worker' && !u.deck && sameGround(game.map,u,mine));
      mined ||= game.units.some(u=>u.kind==='worker' && u.order.type==='mine' && u.order.resourceId===mine.id && u.carryingGold>0);
      colony ||= game.buildings.some(b=>b.kind==='townHall' && b.complete && sameGround(game.map,b,mine));
    }

writeFileSync(".playtest/overseas-assault-20261015/colony-profile.json",JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memory:ai.memories.player}));
