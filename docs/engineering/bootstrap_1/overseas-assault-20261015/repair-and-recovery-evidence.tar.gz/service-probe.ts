import {readFileSync} from 'node:fs';
import {shipNeedsRepair,shipPartMax,installedWeapons} from '../../src/shared/ship-equipment';
import {navalServices} from '../../src/ai/policy/naval-services';
import {bootstrapPolicyContext} from '../../src/ai/bootstrap_1/policy';
import {planBootstrapNaval} from '../../src/ai/bootstrap_1/expedition-recovery';
const path=process.argv[2]!,r=JSON.parse(readFileSync(path,'utf8')),row=r.rows.at(-1),{snapshot:s}=JSON.parse(readFileSync(`${path}.frames/${row.tick}.json`,'utf8'));
const options=bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(row.players.p0.policy),teams:s.teams});
for(const boat of s.units.filter((u:any)=>u.owner==='p0'&&u.sailing))console.log({id:boat.id,repair:shipNeedsRepair(s,boat),parts:boat.shipParts,max:shipPartMax(boat),guns:installedWeapons(s,boat)});
const service=navalServices(s,'p0',options);console.log({services:{commands:service.commands,reserved:[...service.reserved]},commands:planBootstrapNaval(s,'p0',options),naval:options.memory.naval});
