import {writeFileSync} from 'node:fs';
const expect=(v:any,_?:any)=>({toBe:(x:any)=>{if(v!==x)throw Error(String(v));},toBeDefined:()=>{if(v===undefined)throw Error('undefined');},toBeGreaterThanOrEqual:(_:any)=>{}});
import {sketchScene} from '../../src/sdk/scene';
import {snapshotGame} from '../../src/shared/sim';
import {createAiPolicyMemory} from '../../src/ai/memory';
import {assaultExpedition} from '../../src/ai/policy/naval';
import {effectiveCombatRating} from '../../src/ai/policy/v6/strength';

function scenario() {
 const game=sketchScene('island-expedition').map('bareDuel').replaceDefaults()
  .player('us',{team:'a'}).player('foe',{team:'b'})
  .townHall('us',500,500).townHall('foe',3500,500).build().createGame();
 game.map.terrain={cell:32,cols:128,rows:128,cells:Array.from({length:128*128},(_,i)=>{const x=i%128;return x<32||x>70&&x<92||x>102?'.':'~';}).join('')};
 for(let i=0;i<30;i++)game.spawnUnit('us','footman',500+i*10,800);
 for(let i=0;i<6;i++)game.spawnUnit('foe','footman',3500+i*10,800);
 return game;
}
 const {boardUnit}=await import('../../src/shared/decks');
 const {issuePlayerCommand,stepGame}=await import('../../src/shared/sim');
 const {planNavalTactics}=await import('../../src/ai/policy/naval');
 const game=scenario();game.units=game.units.filter(u=>u.owner==='foe');
 const boat=game.spawnUnit('us','carrier',1200,1400);boat.sailing!.heading=Math.PI/2;
 for(let i=0;i<2;i++){const soldier=game.spawnUnit('us','footman',1200,1400);expect(boardUnit(boat,soldier,game.units)).toBe(true);}
 for(let i=0;i<12;i++)game.spawnUnit('us','footman',2500+i*15,1500);
 const memory=createAiPolicyMemory();memory.naval={ferries:{[boat.id]:{purpose:'assault',targetId:game.buildings[1]!.id,
  from:{x:1008,y:1400},to:{x:3280,y:1400},phase:'loading',crewIds:[],sinceTick:0}}};
 const options={version:'v9' as const,memory,teams:game.teams};
 const commands=planNavalTactics(snapshotGame(game),'us',options);
 expect(memory.naval.ferries![boat.id]!.pickup).toBeDefined();
 expect(commands.some(c=>c.type==='unload' && c.unitIds.includes(boat.id))).toBe(false);
 for(const c of commands)issuePlayerCommand(game,'us',c);
 let loaded=2;const trace:any[]=[];
 for(let tick=0;tick<6000;tick++){
  if(tick%15===0)for(const c of planNavalTactics(snapshotGame(game),'us',options))issuePlayerCommand(game,'us',c);
  stepGame(game);
  if(tick%300===0)trace.push({tick:game.tick,boat:structuredClone(boat),mission:structuredClone(memory.naval.ferries![boat.id]),units:structuredClone(game.units)});
  loaded=Math.max(loaded,game.units.filter(u=>u.deck?.shipId===boat.id).length);
  if(loaded>=10)break;
 }
 writeFileSync('.playtest/overseas-assault-20261015/pickup-berth.json',JSON.stringify({trace,snapshot:snapshotGame(game),nextId:game.nextId}));
 expect(loaded,JSON.stringify({boat,mission:memory.naval.ferries![boat.id]})).toBeGreaterThanOrEqual(10);
