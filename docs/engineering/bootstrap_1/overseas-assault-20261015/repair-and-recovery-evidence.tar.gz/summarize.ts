import {readFileSync,writeFileSync} from 'node:fs';
for(const name of process.argv.slice(2)){
 const path=`.playtest/overseas-assault-20261015/${name}.json`,r=JSON.parse(readFileSync(path,'utf8')),last=r.rows.at(-1);
 const {snapshot:s}=JSON.parse(readFileSync(`${path}.frames/${last.tick}.json`,'utf8'));
 const result={name,result:r.result,players:Object.fromEntries(Object.entries(last.players).map(([id,p]:[string,any])=>[id,{phase:p.policy.v6?.phase,gold:p.gold,supply:p.supply,cap:p.cap,bases:p.bases.length,units:p.units.length,armyKinds:Object.fromEntries([...new Set(p.units.map((u:any)=>u.kind))].map(k=>[k,p.units.filter((u:any)=>u.kind===k).length])),buildings:p.buildings.length,naval:p.policy.naval}])),match:s.match,statistics:s.statistics};
 writeFileSync(`.playtest/overseas-assault-20261015/${name}-summary.json`,JSON.stringify(result,null,2));
 console.log(JSON.stringify(result));
}
