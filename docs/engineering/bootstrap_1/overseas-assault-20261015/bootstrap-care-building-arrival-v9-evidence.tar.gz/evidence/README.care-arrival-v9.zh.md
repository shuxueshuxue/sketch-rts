# Bootstrap 护理建筑终点：457e1ec3 固定源码证据

生产改动仅 bootstrap_1/land-recovery.ts 与 mounted-micro.ts：有医师护理的短路前缀终点必须避开 native 建筑身体+原 MOVE_ORDER_ARRIVAL_RANGE=5；不满足则复用现有 mountedEscape，其 avoidCombat 候选同样检查终点。没有规则、对手、人口/资源、战术 triage、归队所有权或采购预算改动。生产 patch 10增2删，SHA见 INDEX。

## 真实因果与限制

183 普通召唤局7905完整档中，1079的62px避战move目标2956.33/3519.02落在自己未完工防御塔2976/3488（radius30）身体内，兵radius18。7912离目标33.89仍native arrive→idle，7913自动attack，7921被反打18→-2。walkDestination仍返回请求点；本例是 native 建筑身体提前到达语义，不是投点/导航缓存副作用。精确7860→7980观察与旧档 world/nextId/三方mem全等。

仅修改 mountedEscape 的 v8没有影响，因为实际经过有医rendezvous短前缀分支，旧分支绕过该函数；v8负例和其旧driver静态metadata误称same-source的勘误一起保留。两处完整几何修改v9在7905选塔外点，1079到8160仍18HP，8196实际18→73；但8665后续又被lancer杀死，9600累计损失6对183的4，不能将此局部称作净收益或保全完成。

## 完整普通0

- 457e1ec3 v9_summoner Ember p0 side1，对正常冻结v8 Grove p1+v8 Ember p2：0→57109自然p0胜，终局p1/p2各0单位0建筑；183对应普通0为30151自然p1胜。
- 同457 v9_knight Ember、相同对手/side/map/seed的独立普通0：0→40398自然p1胜，仍未获胜；183原25657败。不能将时间更长算胜利，也不能因seed里有knight字样将召唤比赛算骑士。
- 两局 factory greystonePass，--unseen实际map.id ladder，4608²，seed resume-20261015-knight-expansion-b。这是已开发已知种子；不是新泛化证据。
- 每局标准500金/3已用/8人口开局，独立prelaunch factory witness与相应183原0逐值相同。未改inspect，无restore/手工命令参与这两场0→自然终局。
- 召唤600→7800全部采样world/nextId/三方mem与183相同；8400/9000/9600全等局部换码native链；57000→57109同源重演、57015 checkpoint重演均全等原终局。
- 骑士40200→40398同源重演、40215 checkpoint重演均全等原终局。两局各800TS+56数据源pre/post零变化、clean457源，规则2冻结184项manifest完整核验。

这些只支持评审这一个共同几何组件。三路线所有旧单对手/六种配对、官方地图及新生成种子的最终完整比赛要求仍未完成；本包不含first-healer生产候选或任何follow所有权新候选的成绩，原容器未提交修改仍未恢复。

## 可移植回归

独立test-only f16b7065加入真实7905完整fixture（103KB，含world/nextId/三方mem/setup），967fc609只给已记录存在的teams补TS非空标记。运行现有公开restore、生产mobileCare/medicalRecovery、native step，不依赖历史git/planner提取。

相同2测试：457上2/2过；独立183树1过1失败，准确失败“recovery rejoined combat at tick7913”。unsafe旧目标提前arrive对照在两树均过，故不是引擎改动。原始test-only tsc可选teams错误日志保留；967fc609最终tsc过。另457既有6文件39测试及其tsc通过。推荐完整测试补丁 care-arrival-v9-regression-complete.patch；若先应用f16，增量types patch只改teams!。

v7首医师门槛候选（原opening.advanceBases完成才采购）也保留为负例：4800→8400与183 world/nextId/全部mem及所有公开命令完全相同，不跑新的普通0。其完整源码以已封存medical-v6源+本包source-overlays/v7-policy.ts及完整audit重建；v8以git183/已封存baseline源+本包source-overlays/v8-mounted-micro.ts重建。正例457完整source-profile和两普通局原source capsule在包内。
