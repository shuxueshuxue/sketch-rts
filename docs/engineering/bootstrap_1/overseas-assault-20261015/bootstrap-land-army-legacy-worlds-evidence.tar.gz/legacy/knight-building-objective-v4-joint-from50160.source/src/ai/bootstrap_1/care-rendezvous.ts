import { ABILITY_DEFS, UNIT_DEFS } from '../../shared/catalog';
import { canReceiveHealing } from '../../shared/healing';
import { MOVE_ORDER_ARRIVAL_RANGE } from '../../shared/movement-rules';
import type { GameCommand, GameSnapshot, PlayerId, Unit } from '../../shared/types';
import { groundRangeArrival } from '../policy/ground-arrival';
import { distance } from '../policy/spatial';
import type { AiPolicyContext } from '../policy/types';

/** Continue only an actual order issued by the existing care owner. A possible
 * future meeting is not completion, and an unrelated kite is not a care task. */
export function careRendezvousHealers(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext) {
  const tasks = options.memory.careRendezvous, attending = new Map<string, Unit>();
  for (const [id, task] of Object.entries(tasks ?? {})) {
    const patient = snapshot.units.find(unit => unit.id === id), healer = snapshot.units.find(unit => unit.id === task.healerId);
    const ability = healer && UNIT_DEFS[healer.kind].abilities.find(ability => ABILITY_DEFS[ability].behavior === 'heal');
    // All scripts plan against the same pre-command snapshot. The command
    // emitted in this frame becomes native state only after planning finishes.
    const bound = task.issuedTick === snapshot.tick || patient && (task.order.type === 'follow'
      ? patient.order.type === 'follow' && patient.order.targetId === task.healerId
      : patient.order.type === 'move' && patient.order.x === task.order.x && patient.order.y === task.order.y
        || patient.order.type === 'idle' && patient.arrivedAt !== undefined
          && distance(patient.arrivedAt, task.order) <= MOVE_ORDER_ARRIVAL_RANGE && distance(patient, task.order) <= MOVE_ORDER_ARRIVAL_RANGE);
    if (patient && healer && ability && patient.owner === owner && healer.owner === owner
      && patient.hp > 0 && patient.hp < patient.maxHp && healer.hp > 0 && !patient.deck && !healer.deck && healer.order.type !== 'board'
      && !patient.orderQueue?.length && bound && canReceiveHealing(patient, snapshot)
      && distance(patient, healer) > ABILITY_DEFS[ability].range
      && groundRangeArrival(snapshot, patient, healer, ABILITY_DEFS[ability].range)) attending.set(id, healer);
    else delete tasks![id];
  }
  if (tasks && !Object.keys(tasks).length) delete options.memory.careRendezvous;
  return attending;
}

export function rememberCareRendezvous(snapshot: GameSnapshot, options: AiPolicyContext, patient: Unit, healer: Unit, command: GameCommand) {
  const order = command.type === 'move' && command.avoidCombat ? { type: 'move' as const, x: command.x, y: command.y }
    : command.type === 'follow' && command.targetId === healer.id ? { type: 'follow' as const } : undefined;
  if (order) (options.memory.careRendezvous ??= {})[patient.id] = { healerId: healer.id, issuedTick: snapshot.tick, order };
}
