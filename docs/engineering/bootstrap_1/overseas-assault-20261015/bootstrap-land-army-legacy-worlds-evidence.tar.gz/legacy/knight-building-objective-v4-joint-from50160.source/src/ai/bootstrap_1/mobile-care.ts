import { unitMover } from '../../shared/catalog';
import { MOVE_ORDER_ARRIVAL_RANGE } from '../../shared/movement-rules';
import { sameGround } from '../../shared/terrain';
import type { GameCommand, GameSnapshot, PlayerId } from '../../shared/types';
import { navalUnitIds } from '../policy/naval';
import { isBacklineKind } from '../policy/v6/backline';
import { V7_WOUNDED_SHARE } from '../policy/v6/general';
import { distance } from '../policy/spatial';
import type { AiPolicyContext, AiScript } from '../policy/types';
import { landRecoveryAssignments, patientRendezvousCommands } from './expedition-recovery';
import { mountedEscape, mountedThreatReach, THINK_TICKS } from './mounted-micro';
import { retreatLandRoad } from './safe-land-route';
import { SIM_TICKS_PER_SECOND } from '../../shared/time';

function assignments(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext) {
  const home = snapshot.buildings.find(building => building.owner === owner && building.kind === 'townHall');
  if (!home) return undefined;
  const own = snapshot.units.filter(unit => unit.owner === owner && !unit.deck && unitMover(unit.kind) === 'land'
    && unit.kind !== 'worker' && unit.order.type !== 'board' && sameGround(snapshot.map, unit, home));
  if (!own.some(unit => unit.expiresTick === undefined && unit.hp < unit.maxHp)) return undefined;
  const reserved = navalUnitIds(snapshot, owner, options, () => false);
  const care = landRecoveryAssignments(snapshot, owner, options, own.filter(unit => !reserved.has(unit.id)));
  const medics = new Set(care.recovering.map(({ healer }) => healer.id));
  const recovering = care.recovering.filter(({ patient }) => !medics.has(patient.id)
    && !options.memory.v6?.creep?.group.includes(patient.id))
    .map(pair => ({ ...pair, foes: care.foes, medics }));
  const occupied = new Set([...reserved, ...care.posts.map(({ patient }) => patient.id), ...care.recovering.map(({ patient }) => patient.id),
    ...options.memory.v6?.creep?.group ?? [], ...options.memory.mounted?.flatMap(job => job.unitIds) ?? [],
    ...options.memory.v6?.raid?.unitIds ?? [], ...options.memory.v6?.closeout?.unitIds ?? [], ...options.memory.support?.unitIds ?? [],
    ...[options.memory.loot?.unitId, options.memory.shopping?.unitId, options.memory.mercenaryCourier?.unitId].filter((id): id is string => !!id),
    ...Object.entries(options.memory.unitClaims).filter(([, claim]) => claim.expiresTick > snapshot.tick).map(([id]) => id)]);
  // A mainland attack needs the same unmedicated escape as a landed force.
  // Remain safe while critically wounded even after leaving current coverage;
  // an absent medic is not permission to turn around and resume the assault.
  const unmedicated = own.filter(unit => unit.expiresTick === undefined && !occupied.has(unit.id) && !isBacklineKind(unit)
    && unit.hp < unit.maxHp * V7_WOUNDED_SHARE && !unit.orderQueue?.length
    && !['cast', 'charge', 'repairShip', 'repair', 'repairUnit', 'pickupItem'].includes(unit.order.type)).map(patient => {
      const planned = care.unmedicated.find(pair => pair.patient.id === patient.id);
      return planned ?? { patient, cover: patient.order.type === 'move' && patient.order.avoidCombat
        ? { x: patient.order.x, y: patient.order.y } : { x: patient.x, y: patient.y } };
    });
  return { recovering, unmedicated, foes: care.foes };
}

/** Home-ground patients rendezvous with an existing medic while expeditions and camps keep their own care. */
export const mobileCare: AiScript = {
  id: 'mobileCare', phase: 'tactics',
  claimsUnits: (snapshot, owner, options) => {
    const care = assignments(snapshot, owner, options);
    return new Set([...(care?.recovering ?? []), ...(care?.unmedicated ?? [])].map(({ patient }) => patient.id));
  },
  run(snapshot, owner, options): GameCommand[] {
    const care = assignments(snapshot, owner, options);
    if (!care) return [];
    return [...care.recovering.flatMap(({ patient, healer, foes, medics }) => patientRendezvousCommands(snapshot, [{ patient, healer }], foes, medics, options)),
      ...care.unmedicated.map(({ patient, cover }): GameCommand => {
        const threats = care.foes.filter(foe => sameGround(snapshot.map, patient, foe)
          && distance(patient, foe) <= mountedThreatReach(snapshot, foe, patient, THINK_TICKS)
            + ('speed' in foe ? foe.speed : 0) * (THINK_TICKS + 2) / SIM_TICKS_PER_SECOND);
        if (distance(patient, cover) > MOVE_ORDER_ARRIVAL_RANGE && retreatLandRoad(snapshot, patient, cover, care.foes))
          return { type: 'move', unitIds: [patient.id], ...cover, avoidCombat: true };
        return threats.length ? mountedEscape(snapshot, patient, threats, 0, cover, true)
          : { type: 'holdPosition', unitIds: [patient.id] };
      })];
  },
};
