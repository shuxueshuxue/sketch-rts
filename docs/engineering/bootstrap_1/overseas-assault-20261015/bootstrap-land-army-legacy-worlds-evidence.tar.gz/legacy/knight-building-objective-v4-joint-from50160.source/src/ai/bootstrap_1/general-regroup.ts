import type { GameCommand, GameSnapshot, PlayerId, Unit } from '../../shared/types';
import type { V6PolicyMemory } from '../memory';
import { isBacklineKind } from '../policy/v6/backline';
import { GUARD_LEASH, ORDER_SLACK } from '../policy/v6/general';
import { distance } from '../policy/spatial';

function post(general: V6PolicyMemory['general']) {
  return general?.mode === 'hold' || general?.mode === 'guard' ? general.target : undefined;
}

/** These units already have the main commander's ordinary return destination. */
export function generalReturningUnitIds(snapshot: GameSnapshot, owner: PlayerId, general: V6PolicyMemory['general']) {
  const target = post(general);
  return new Set(target ? snapshot.units.filter(unit => unit.owner === owner && !unit.deck && !isBacklineKind(unit)
    && unit.kind !== 'worker' && unit.attackDamage > 0 && distance(unit, target) > (general!.leash ?? GUARD_LEASH)
    && (unit.order.type === 'move' || unit.order.type === 'attackMove') && distance(unit.order, target) <= ORDER_SLACK)
    .map(unit => unit.id) : []);
}

/** Apply the existing V9 walk-back contract to this bootstrap main army too.
 * Otherwise attackMove immediately reacquires the tower it is leaving. */
export function regroupBootstrapGeneral(snapshot: GameSnapshot, owner: PlayerId, front: Unit[], commands: GameCommand[], general: V6PolicyMemory['general']) {
  const target = post(general);
  if (!target) return commands;
  const far = new Set(front.filter(unit => distance(unit, target) > (general!.leash ?? GUARD_LEASH)).map(unit => unit.id));
  const ordered = new Set(commands.flatMap(command => 'unitIds' in command ? command.unitIds : 'unitId' in command ? [command.unitId] : []));
  const result = commands.flatMap((command): GameCommand[] => {
    if (command.type !== 'attackMove' || distance(command, target) > ORDER_SLACK) return [command];
    const walking = command.unitIds.filter(id => far.has(id) && !front.some(unit => unit.id === id
      && unit.order.type === 'move' && distance(unit.order, command) <= ORDER_SLACK));
    const fighting = command.unitIds.filter(id => !far.has(id));
    return [...(walking.length ? [{ ...command, type: 'move' as const, unitIds: walking }] : []),
      ...(fighting.length ? [{ ...command, unitIds: fighting }] : [])];
  });
  const returning = generalReturningUnitIds(snapshot, owner, general);
  const walking = front.filter(unit => returning.has(unit.id) && !ordered.has(unit.id) && unit.order.type === 'attackMove');
  if (walking.length) result.push({ type: 'move', unitIds: walking.map(unit => unit.id), ...target });
  return result;
}
