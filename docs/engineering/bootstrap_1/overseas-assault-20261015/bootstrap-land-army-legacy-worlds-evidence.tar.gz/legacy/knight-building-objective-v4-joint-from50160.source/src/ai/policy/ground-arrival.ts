import { groundSteeringRoute } from '../../shared/route-selection';
import { groundTravelCost, isOpenGround } from '../../shared/terrain';
import { SIM_TICKS_PER_SECOND } from '../../shared/time';
import type { GameSnapshot, Unit } from '../../shared/types';
import type { Point } from './spatial';

/** First legal standing point in a range band along native building-aware steering.
 * Terrain pace is included; live bodies, cooldowns and aim remain execution work. */
export function groundRangeArrival(snapshot: Pick<GameSnapshot, 'map'>, unit: Pick<Unit, 'x' | 'y' | 'speed'>,
  target: Point, range: number, minimum = 0, gapAt: (point: Point) => number = point => Math.hypot(point.x - target.x, point.y - target.y)) {
  const inRange = (point: Point) => gapAt(point) <= range;
  const legal = (point: Point) => inRange(point) && Math.hypot(point.x - target.x, point.y - target.y) >= minimum
    && isOpenGround(snapshot.map, point.x, point.y);
  if (legal(unit)) return { ticks: 0, point: { x: unit.x, y: unit.y } };
  if (!(unit.speed > 0)) return undefined;
  const gap = Math.hypot(unit.x - target.x, unit.y - target.y);
  // Inside a shell's dead zone the native order backs directly away. Query
  // that outward road; walking farther toward the building cannot make a shot legal.
  const goal = gap < minimum ? { x: target.x + (unit.x - target.x || 1) / (gap || 1) * minimum,
    y: target.y + (unit.y - target.y) / (gap || 1) * minimum } : target;
  const route = groundSteeringRoute(snapshot.map, unit, goal);
  let cost = 0;
  for (let index = 1; index < route.length; index++) {
    const from = route[index - 1]!, to = route[index]!, dx = to.x - from.x, dy = to.y - from.y;
    const lengthSquared = dx * dx + dy * dy;
    const fraction = lengthSquared ? Math.max(0, Math.min(1,
      ((target.x - from.x) * dx + (target.y - from.y) * dy) / lengthSquared)) : 0;
    const nearest = { x: from.x + dx * fraction, y: from.y + dy * fraction };
    let stand: Point | undefined;
    if (gap < minimum) {
      if (legal(to)) {
        let low = 0, high = 1;
        for (let step = 0; step < 32; step++) {
          const mid = (low + high) / 2, at = { x: from.x + dx * mid, y: from.y + dy * mid };
          if (Math.hypot(at.x - target.x, at.y - target.y) >= minimum) high = mid; else low = mid;
        }
        stand = { x: from.x + dx * high, y: from.y + dy * high };
      }
    } else if (inRange(nearest)) {
      let low = 0, high = fraction;
      for (let step = 0; step < 32; step++) {
        const mid = (low + high) / 2;
        if (inRange({ x: from.x + dx * mid, y: from.y + dy * mid })) high = mid; else low = mid;
      }
      stand = { x: from.x + dx * high, y: from.y + dy * high };
    }
    if (stand && legal(stand)) {
      const last = groundTravelCost(snapshot.map, from, stand);
      if (last !== undefined) return { ticks: Math.ceil((cost + last) / unit.speed * SIM_TICKS_PER_SECOND), point: stand };
    }
    const leg = groundTravelCost(snapshot.map, from, to);
    if (leg === undefined) return undefined;
    cost += leg;
  }
  return undefined;
}

