import { strikeGap } from '../../shared/combat-geometry';
import { resolveUnitDamage } from '../../shared/damage';
import { attackDamageProfile } from '../../shared/damage-types';
import { buildVeteranFrame } from '../../shared/veteran-runtime';
import type { Building, GameSnapshot, Unit } from '../../shared/types';
import { isEnemyOwner } from '../policy/ownership';

const projections = new WeakMap<GameSnapshot, ReturnType<typeof buildVeteranFrame>>();

/** The existing pursuit forecast plus committed ordinary missiles and live tower coverage.
 * A released arrow remains dangerous after its shooter changes target or dies. */
export function recoveryIncomingDamage(snapshot: GameSnapshot, patient: Unit, foes: readonly (Unit | Building)[], window: number) {
  const pursuit = foes.reduce((damage, foe) => damage + ('order' in foe
    && (foe.order.type === 'attack' || foe.order.type === 'attackMove') && foe.order.targetId === patient.id
    ? foe.attackDamage * Math.max(0, Math.ceil((window - foe.cooldown) / foe.attackCooldown)) : 0), 0);
  let projection = projections.get(snapshot);
  if (!projection) { projection = buildVeteranFrame(snapshot); projections.set(snapshot, projection); }
  const reductions = projection.get(patient.id)?.reductions;
  const pending = snapshot.projectiles.reduce((damage, projectile) => damage + (!projectile.weapon
    && projectile.targetId === patient.id && projectile.remaining <= window
    && isEnemyOwner(snapshot, patient.owner, projectile.owner, {})
    ? resolveUnitDamage(snapshot, patient, projectile.damage,
      projectile.damageProfile ?? attackDamageProfile(projectile.sourceKind ?? 'defenseTower'), reductions,
      { armorAlreadyApplied: projectile.armorAlreadyApplied }).damage : 0), 0);
  const towers = foes.reduce((damage, foe) => {
    if ('order' in foe || !foe.complete || strikeGap(foe, patient) > foe.attackRange) return damage;
    const firstShot = Math.max(1, foe.cooldown);
    const shots = window < firstShot ? 0 : 1 + Math.floor((window - firstShot) / foe.attackCooldown);
    return damage + shots * resolveUnitDamage(snapshot, patient, foe.attackDamage, attackDamageProfile(foe.kind), reductions).damage;
  }, 0);
  return pursuit + pending + towers;
}
