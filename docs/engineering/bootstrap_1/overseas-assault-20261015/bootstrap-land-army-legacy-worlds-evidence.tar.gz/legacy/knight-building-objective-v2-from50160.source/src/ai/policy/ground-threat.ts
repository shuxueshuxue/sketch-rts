import { strikeGap } from '../../shared/combat-geometry';
import { groundSteeringRoute, routeWithinDistance } from '../../shared/route-selection';
import { combatCapability } from '../../shared/combat-capabilities';
import { weaponRules } from '../../shared/equipment';
import { canReach } from '../../shared/naval';
import { groundTravelCost, isOpenGround } from '../../shared/terrain';
import { GOLD_MINE_RULES } from '../../shared/mining';
import type { Building, GameSnapshot, Unit } from '../../shared/types';
import type { Point } from './spatial';
import type { V6Intel } from './v6/intel';
import { strengthOf, TOWER_STRENGTH } from './v6/strength';
import { LOCAL_RANGE } from './v6/general';
import { SIM_TICKS_PER_SECOND } from '../../shared/time';
import { THINK_TICKS } from '../bootstrap_1/mounted-micro';

/** Fire crosses terrain; a land reinforcement outside firing range needs a road. */
export function groundThreatWithin(snapshot: GameSnapshot, unit: Unit, point: Point, range: number) {
  const gap = strikeGap(unit, point);
  if (gap <= unit.attackRange) return true;
  if (gap > range) return false;
  return routeWithinDistance(snapshot.map, unit, point, 'land', range);
}

/** First legal firing stand on the native steering road, before walking into a building.
 * This is movement time, not a first-shot promise: aiming, cooldowns and bodies remain native execution work. */
export function groundAttackArrival(snapshot: GameSnapshot, unit: Unit, target: Building) {
  const capability = combatCapability(snapshot, unit), minimum = weaponRules(snapshot, unit).weapon?.minRange ?? 0;
  if (!capability.armed || !canReach(snapshot.map, unit, target, snapshot.units, capability.range)) return undefined;
  const inRange = (point: Point) => strikeGap(point, target) <= capability.range;
  const legal = (point: Point) => inRange(point) && Math.hypot(point.x - target.x, point.y - target.y) >= minimum
    && isOpenGround(snapshot.map, point.x, point.y);
  if (legal(unit)) return { ticks: 0, point: { x: unit.x, y: unit.y } };
  if (!(unit.speed > 0)) return undefined;
  const gap = Math.hypot(unit.x - target.x, unit.y - target.y);
  // Inside a shell's dead zone the native order backs directly away. Query
  // that outward road; walking farther toward the building cannot make a shot legal.
  const goal = gap < minimum ? { x: target.x + (unit.x - target.x || 1) / (gap || 1) * minimum,
    y: target.y + (unit.y - target.y) / (gap || 1) * minimum } : target;
  const route = groundSteeringRoute(snapshot.map, unit, goal);
  let cost = 0;
  for (let index = 1; index < route.length; index++) {
    const from = route[index - 1]!, to = route[index]!, dx = to.x - from.x, dy = to.y - from.y;
    const lengthSquared = dx * dx + dy * dy;
    const fraction = lengthSquared ? Math.max(0, Math.min(1,
      ((target.x - from.x) * dx + (target.y - from.y) * dy) / lengthSquared)) : 0;
    const nearest = { x: from.x + dx * fraction, y: from.y + dy * fraction };
    let stand: Point | undefined;
    if (gap < minimum) {
      if (legal(to)) {
        let low = 0, high = 1;
        for (let step = 0; step < 32; step++) {
          const mid = (low + high) / 2, at = { x: from.x + dx * mid, y: from.y + dy * mid };
          if (Math.hypot(at.x - target.x, at.y - target.y) >= minimum) high = mid; else low = mid;
        }
        stand = { x: from.x + dx * high, y: from.y + dy * high };
      }
    } else if (inRange(nearest)) {
      let low = 0, high = fraction;
      for (let step = 0; step < 32; step++) {
        const mid = (low + high) / 2;
        if (inRange({ x: from.x + dx * mid, y: from.y + dy * mid })) high = mid; else low = mid;
      }
      stand = { x: from.x + dx * high, y: from.y + dy * high };
    }
    if (stand && legal(stand)) {
      const last = groundTravelCost(snapshot.map, from, stand);
      if (last !== undefined) return { ticks: Math.ceil((cost + last) / unit.speed * SIM_TICKS_PER_SECOND), point: stand };
    }
    const leg = groundTravelCost(snapshot.map, from, to);
    if (leg === undefined) return undefined;
    cost += leg;
  }
  return undefined;
}

/** Enemy reinforcements and counterraids use the same first-firing-stand clock as our army. */
export function groundRespondingPower(snapshot: GameSnapshot, intel: V6Intel, target: Building, front: Unit[]) {
  const arrival = front.reduce((last, unit) => Math.max(last, groundAttackArrival(snapshot, unit, target)?.ticks ?? Infinity), 0);
  const army = intel.enemies.flatMap(enemy => enemy.army);
  const responders = army.filter(unit => (groundAttackArrival(snapshot, unit, target)?.ticks ?? Infinity) <= arrival);
  const income = intel.ownHalls.filter(hall => hall.complete && snapshot.resources.some(mine =>
    mine.amount > 0 && Math.hypot(mine.x - hall.x, mine.y - hall.y) <= GOLD_MINE_RULES.baseRange));
  const counterraiders = income.flatMap(hall => army.filter(unit => (groundAttackArrival(snapshot, unit, hall)?.ticks ?? Infinity) <= arrival));
  return strengthOf([...new Set([...responders, ...counterraiders])]);
}

/** A remote member cannot move the center away from the soldiers actually exposed to fire. */
export function groundFrontThreat(snapshot: GameSnapshot, intel: V6Intel, front: Unit[]) {
  const army = intel.enemies.flatMap(enemy => enemy.army).filter(enemy =>
    front.some(unit => groundThreatWithin(snapshot, enemy, unit, LOCAL_RANGE)));
  const towers = intel.enemies.flatMap(enemy => enemy.buildings).filter(tower => tower.complete && tower.attackDamage > 0
    && front.some(unit => strikeGap(tower, unit) <= tower.attackRange + unit.speed * THINK_TICKS / SIM_TICKS_PER_SECOND));
  return strengthOf(army) + towers.length * TOWER_STRENGTH;
}
