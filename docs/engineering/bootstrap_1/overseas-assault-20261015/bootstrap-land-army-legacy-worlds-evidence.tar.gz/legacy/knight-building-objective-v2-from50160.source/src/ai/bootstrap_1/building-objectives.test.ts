import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import { isOpenGround } from '../../shared/terrain';
import { BUILDING_DEFS } from '../../shared/catalog';
import { planAiOwnerCommandEntries } from '../planner-context';
import { bootstrapPolicyContext } from './policy';
import { planBootstrapGeneral } from './mine-defense';

const load = (name: string) => JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/${name}.json.gz`, import.meta.url))).toString());
const baseline = load('army-objective-default-baseline');
const defaults: { field: any; version: 'v5' | 'v7' | 'v8'; tick: number }[] = baseline.cases
  .flatMap((field: any) => (['v5', 'v7', 'v8'] as const).map(version => ({ field, version, tick: field.snapshot.tick })));

it.each(defaults)('preserves every default $version command and memory byte at the original $tick frame', ({ field, version }) => {
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, structuredClone(field.snapshot), field.nextId);
  const memory = structuredClone(field.memory);
  const entries = planAiOwnerCommandEntries(snapshotGame(game), { playerId: 'p0', version, memory }, { teams: game.teams });
  expect(JSON.stringify({ entries, memory })).toBe(field.expected[version]);
});

function ready(version: 'v9_archer' | 'v9_summoner' | 'v9_knight') {
  const saved = load('knight-original-building-objective');
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  // Selector control only: exercise the commander's existing stale-army gate.
  // The full-AI replay starts with the untouched original memory instead.
  const memory = saved.memories.p0;
  memory.v6.general = { mode: 'hold', target: { x: 2797.725830020305, y: 3437.725830020305 }, holdingSince: game.tick - 5400 };
  delete memory.v6.retreatedAt;
  const snapshot = snapshotGame(game);
  const options = bootstrapPolicyContext(snapshot, 'p0', version, { memory, teams: game.teams });
  return { game, snapshot, options, version };
}

it.each(['v9_archer', 'v9_summoner', 'v9_knight'] as const)('%s gives its existing army a real production objective with native gathering', version => {
  const { snapshot, options } = ready(version);
  const commands = planBootstrapGeneral(snapshot, 'p0', options), general = options.memory.v6!.general!;
  const target = snapshot.buildings.find(building => building.id === general.targetBuildingId)!;
  expect(target).toBeDefined();
  expect(target.kind).not.toBe('townHall');
  expect(BUILDING_DEFS[target.kind].trains.length).toBeGreaterThan(0);
  expect(general.targetHallId).toBeUndefined();
  expect(general.group).toContain('unit-p0-catapult-21262');
  expect(general.group).not.toContain('unit-p0-ashHexer-12529');
  expect(general.stage).toBe('gather');
  for (const command of commands) if (command.type === 'move' || command.type === 'attackMove') {
    expect(isOpenGround(snapshot.map, command.x, command.y)).toBe(true);
  }
});

it.each(['destroyed', 'captured'] as const)('clears the original building identity when the target is %s', change => {
  const { game, snapshot, options, version } = ready('v9_knight');
  planBootstrapGeneral(snapshot, 'p0', options);
  const target = game.buildings.find(building => building.id === options.memory.v6!.general!.targetBuildingId)!;
  if (change === 'destroyed') game.buildings.splice(game.buildings.indexOf(target), 1);
  else target.owner = 'p0';
  planBootstrapGeneral(snapshotGame(game), 'p0', bootstrapPolicyContext(snapshotGame(game), 'p0', version,
    { memory: options.memory, teams: game.teams }));
  expect(options.memory.v6?.general?.targetBuildingId).not.toBe(target.id);
  expect(options.memory.v6?.general?.targetHallId).toBeUndefined();
});

it.each(['v9_archer', 'v9_summoner', 'v9_knight'] as const)('%s continues the real cleared location with the same original loss budget', version => {
  const saved = load('knight-building-completed-56760');
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), memory = saved.memories.p0, before = structuredClone(memory.v6.general);
  const retreatedAt = memory.v6.retreatedAt;
  const options = bootstrapPolicyContext(snapshot, 'p0', version, { memory, teams: game.teams });
  planBootstrapGeneral(snapshot, 'p0', options);
  expect(memory.v6.general.targetBuildingId).toBe('building-p1-sanctum-1631');
  expect(memory.v6.general.targetHallId).toBeUndefined();
  expect(memory.v6.general.group).toEqual(before.group);
  expect(memory.v6.general.groupStart).toBe(before.groupStart);
  expect(memory.v6.general.stage).toBe('strike');
  expect(memory.v6.retreatedAt).toBe(retreatedAt);
});

it('does not erase cumulative army losses when a building disappears', () => {
  const saved = load('knight-building-completed-56760');
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  // Explicit policy-only worn-army control, not a continuation score.
  saved.memories.p0.v6.general.groupStart *= 3;
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight',
    { memory: saved.memories.p0, teams: game.teams });
  planBootstrapGeneral(snapshot, 'p0', options);
  expect(options.memory.v6?.general?.mode).toBe('hold');
  expect(options.memory.v6?.general?.targetBuildingId).toBeUndefined();
  expect(options.memory.v6?.retreatedAt).toBe(game.tick);
});
