import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, issuePlayerCommand, restoreSnapshotIntoGame, snapshotGame, stepGame } from '../../shared/sim';
import { strikeGap } from '../../shared/combat-geometry';
import { weaponRules } from '../../shared/equipment';
import { groundAttackArrival } from '../policy/ground-threat';
import { routeTravelTicks } from '../../shared/route-selection';
import { isOpenGround } from '../../shared/terrain';
import { bootstrapGame, bootstrapMatches } from './benchmark';
import { createAiMemoryProvider } from '../planner-context';
import { createBootstrapCommandPlanner } from '../../../scripts/bootstrap_1-planner';
import { runAiGameLoop } from '../game-runner';

function field() {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/knight-building-completed-56760.json.gz', import.meta.url))).toString());
  const game = createGame('bareDuel'); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), unit = snapshot.units.find(unit => unit.id === 'unit-p0-catapult-21262')!;
  return { saved, game, snapshot, unit };
}

it('counts the real slow cannon already firing at the next building as zero movement time', () => {
  const { game, snapshot, unit } = field(), target = snapshot.buildings.find(building => building.id === 'building-p1-sanctum-1631')!;
  expect(groundAttackArrival(snapshot, unit, target)?.ticks).toBe(0);
  expect(routeTravelTicks(snapshot.map, unit, target, 'land', unit.speed)).toBeGreaterThan(400);
  // Ordinary public attack on the complete recorded world; no other order or entity edits.
  issuePlayerCommand(game, 'p0', { type: 'attack', unitIds: [unit.id], targetId: target.id });
  let firstShot: number | undefined;
  for (let elapsed = 1; elapsed <= 60; elapsed++) {
    stepGame(game);
    if (game.projectiles.some(projectile => projectile.attackerId === unit.id && projectile.targetId === target.id)) {
      firstShot = elapsed; break;
    }
  }
  expect(firstShot).toBe(44);
  expect(game.units.find(candidate => candidate.id === unit.id)?.x).toBe(unit.x);
  expect(game.units.find(candidate => candidate.id === unit.id)?.y).toBe(unit.y);
});

it('follows the real road to the enemy tower rather than subtracting weapon range from a straight distance', () => {
  const { game, snapshot, unit } = field(), target = snapshot.buildings.find(building => building.id === 'building-p2-defenseTower-1978')!;
  const forecast = groundAttackArrival(snapshot, unit, target)!;
  const direct = (strikeGap(unit, target) - unit.attackRange) / unit.speed * 20;
  expect(forecast.ticks).toBeGreaterThan(direct + 300);
  expect(isOpenGround(snapshot.map, forecast.point.x, forecast.point.y)).toBe(true);
  expect(strikeGap(forecast.point, target)).toBeLessThanOrEqual(unit.attackRange);
  issuePlayerCommand(game, 'p0', { type: 'attack', unitIds: [unit.id], targetId: target.id });
  let contact: number | undefined, shot: number | undefined;
  for (let elapsed = 1; elapsed <= 720; elapsed++) {
    stepGame(game);
    const current = game.units.find(candidate => candidate.id === unit.id)!, building = game.buildings.find(candidate => candidate.id === target.id);
    if (contact === undefined && building && strikeGap(current, building) <= current.attackRange) contact = elapsed;
    if (game.projectiles.some(projectile => projectile.attackerId === unit.id && projectile.targetId === target.id)) { shot = elapsed; break; }
  }
  expect(contact).toBe(595); expect(shot).toBe(646);
  expect(contact!).toBeGreaterThan(direct + 300);
  expect(Math.abs(contact! - forecast.ticks)).toBeLessThan(40);
});

it('does not count a shell weapon inside its native minimum range as ready to fire', () => {
  const { snapshot, unit } = field(), target = snapshot.buildings.find(building => building.id === 'building-p1-sanctum-1631')!;
  const minimum = weaponRules(snapshot, unit).weapon!.minRange!;
  // Explicit geometry-only control; it is never substituted into a scored world.
  const inside = { ...unit, x: target.x + minimum * .75, y: target.y };
  expect(strikeGap(inside, target)).toBeLessThan(unit.attackRange);
  expect(groundAttackArrival(snapshot, inside, target)?.ticks).not.toBe(0);
});

it('restores the full normal three-player AI continuation through a cleared-building transition', async () => {
  const { saved } = field();
  const match = bootstrapMatches(saved.setup.seed, ['greystonePass'], 57360, true).find(match => match.subject === 'v9_knight'
    && match.side === 1 && match.agents.p0!.race === 'ember'
    && Object.values(match.agents).slice(1).map(agent => agent.version).join('+') === 'v8+v8')!;
  const game = bootstrapGame(match); restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const memory = createAiMemoryProvider(structuredClone(saved.memories)), planner = await createBootstrapCommandPlanner(memory);
  runAiGameLoop({ ...match, game, commandPlanner: planner, maxTicks: 57060 });
  const checkpoint = JSON.parse(JSON.stringify({ snapshot: snapshotGame(game), nextId: game.nextId,
    memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memory.get(owner)])) }));
  const restored = bootstrapGame(match); restoreSnapshotIntoGame(restored, checkpoint.snapshot, checkpoint.nextId);
  const restoredMemory = createAiMemoryProvider(checkpoint.memories), restoredPlanner = await createBootstrapCommandPlanner(restoredMemory);
  runAiGameLoop({ ...match, game, commandPlanner: planner });
  runAiGameLoop({ ...match, game: restored, commandPlanner: restoredPlanner });
  expect(snapshotGame(restored)).toEqual(snapshotGame(game)); expect(restored.nextId).toBe(game.nextId);
  for (const owner of Object.keys(match.agents)) expect(restoredMemory.get(owner)).toEqual(memory.get(owner));
  expect(game.buildings.some(building => building.id === 'building-p1-sanctum-1631')).toBe(false);
  expect(memory.get('p0')!.v6!.general!.groupStart).toBe(saved.memories.p0.v6.general.groupStart);
  expect(game.match.winner).toBeNull();
}, 60000);
