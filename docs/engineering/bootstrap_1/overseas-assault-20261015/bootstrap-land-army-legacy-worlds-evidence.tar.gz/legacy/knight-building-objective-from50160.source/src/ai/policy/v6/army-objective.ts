import type { Building } from '../../../shared/types';
import type { V6PolicyMemory } from '../../memory';
import { distance } from '../spatial';
import type { V6BaseIntel, V6Intel } from './intel';

/** A hall assault and a peripheral building assault share the commander's army. */
export type ArmyObjective = { kind: 'base'; base: V6BaseIntel }
  | { kind: 'building'; building: Building; towers: Building[] };

export function objectiveBuilding(objective: ArmyObjective): Building {
  return objective.kind === 'base' ? objective.base.hall : objective.building;
}

export function objectiveTowers(objective: ArmyObjective): Building[] {
  return objective.kind === 'base' ? objective.base.towers : objective.towers;
}

export function buildingObjective(intel: V6Intel, building: Building): ArmyObjective {
  const towers = intel.enemies.flatMap(enemy => enemy.buildings).filter(tower => tower.complete
    && tower.kind === 'defenseTower' && distance(tower, building) <= tower.attackRange + building.radius);
  return { kind: 'building', building, towers };
}

export function objectiveIdentity(objective: ArmyObjective) {
  const building = objectiveBuilding(objective);
  return objective.kind === 'base' ? { targetHallId: building.id } : { targetBuildingId: building.id };
}

export function matchesObjective(memory: V6PolicyMemory['general'], objective: ArmyObjective) {
  const building = objectiveBuilding(objective);
  return objective.kind === 'base' ? memory?.targetHallId === building.id : memory?.targetBuildingId === building.id;
}
