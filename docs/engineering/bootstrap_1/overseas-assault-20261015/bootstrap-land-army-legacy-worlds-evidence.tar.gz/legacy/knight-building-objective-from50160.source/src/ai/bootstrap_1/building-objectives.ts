import { BUILDING_DEFS } from '../../shared/catalog';
import { walkingDistance } from '../../shared/terrain';
import type { GameSnapshot, Unit } from '../../shared/types';
import type { V6Intel } from '../policy/v6/intel';

/** The main army can remove exposed production or a defensive barrier before a hall assault is viable. */
export function bootstrapBuildingTargets(snapshot: GameSnapshot, intel: V6Intel, front: Unit[]) {
  return intel.enemies.flatMap(enemy => enemy.buildings).filter(building => building.kind !== 'townHall'
    && (building.attackDamage > 0 || BUILDING_DEFS[building.kind].trains.length > 0)
    && front.length > 0 && front.every(unit => walkingDistance(snapshot.map, unit, building, 'land') !== undefined));
}
