import{readFileSync,writeFileSync,mkdirSync,copyFileSync}from'node:fs';
import{dirname}from'node:path';
import{createHash}from'node:crypto';
import{execFileSync}from'node:child_process';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{createAiMemoryProvider}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner,frozenPolicyManifest}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',label=process.argv[2]??'knight-tower-care-v1-from10335';
const end=Number(process.argv[4]??11160);
const input=`${dir}/knight-tower-care-before-10335.json`,saved=JSON.parse(readFileSync(input,'utf8'));
const match=bootstrapMatches(saved.setup.seed,['greystonePass'],end,true).find(x=>x.subject==='v9_knight'&&x.side===1&&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
if(process.argv[3])match.agents.p0!.version=process.argv[3] as 'v9_archer'|'v9_summoner'|'v9_knight';
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
const hash=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex'),runtimeFiles=['src/ai/memory.ts','src/ai/policy/v6/general.ts','src/ai/policy/v6/army-objective.ts','src/ai/policy/ground-threat.ts','src/ai/policy/ground-arrival.ts','src/ai/bootstrap_1/mine-defense.ts','src/ai/bootstrap_1/building-objectives.ts','src/ai/bootstrap_1/mobile-care.ts','src/ai/bootstrap_1/general-regroup.ts','src/ai/bootstrap_1/policy.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/bootstrap_1/recovery-threat.ts','src/ai/bootstrap_1/care-rendezvous.ts','src/ai/bootstrap_1/medical-recovery.ts'];
for(const file of runtimeFiles){const target=`${dir}/${label}.source/${file}`;mkdirSync(dirname(target),{recursive:true});copyFileSync(file,target);}
const metadata={classification:'Complete normal three-player changed-code AI care window from actual10335 prethink, no operator/world/order/memory edits; not an ordinary opening or victory. Optional policy-family replay is explicit.',family:match.agents.p0!.version,input,inputSha256:hash(input),sourceHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),runtimeHashes:Object.fromEntries(runtimeFiles.map(file=>[file,hash(file)])),sourceDiff:execFileSync('git',['diff','--','src/ai'],{encoding:'utf8'}),frozenPolicyManifest,setup:saved.setup,startTick:game.tick,maxTick:end};
writeFileSync(`${dir}/${label}.metadata.json`,JSON.stringify(metadata,null,2));
const frames=`${dir}/${label}.frames`;mkdirSync(frames,{recursive:true});const entries:any[]=[],hits:any[]=[];
const allMemories=()=>Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]));
const save=()=>writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:allMemories()}));
game.observer={hit(source,target,amount){if(target.owner==='p0'||target.id.startsWith('building-'))hits.push({tick:game.tick,source:source.id,target:target.id,amount,hp:target.hp});}};
save();runAiGameLoop({...match,game,commandPlanner:context=>{const planned=planner(context);if(context.owner==='p0')entries.push({tick:game.tick,general:structuredClone(memory.get('p0')?.v6?.general),entries:planned});return planned;}},{onStep:()=>{if(game.tick%15===0)save();}});save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({metadata,result:game.match,entries,hits},null,2));
console.log(JSON.stringify({label,tick:game.tick,patient:game.units.find(u=>u.id==='unit-p0-emberRavager-1079'),death:game.corpses.find(c=>c.unitId==='unit-p0-emberRavager-1079'),ownLost:game.match.stats.unitsLost.p0,
 enemyTarget:game.buildings.find(b=>b.id==='building-p2-defenseTower-1760')}));
