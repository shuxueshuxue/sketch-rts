import{readFileSync,writeFileSync}from'node:fs';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{isOpenGround,walkingDistance}from'../src/shared/terrain';
import{groundSteeringRoute,routeTravelTicks}from'../src/shared/route-selection';
import{strikeGap}from'../src/shared/combat-geometry';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{armedFoes,safeLandTravelTicks}from'../src/ai/bootstrap_1/safe-land-route';
import{mountedThreatReach}from'../src/ai/bootstrap_1/mounted-micro';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';const saved=JSON.parse(readFileSync(`${dir}/knight-periphery-main-51195-replay.json.frames/51195.json`,'utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams});
const artillery=snapshot.units.find(u=>u.id==='unit-p0-catapult-21262')!,foes=armedFoes(snapshot,'p0',options),group=snapshot.units.filter(u=>saved.operator.ids.includes(u.id)),front=group.filter(u=>!isBacklineKind(u)&&u.attackDamage>0);
const towers=snapshot.buildings.filter(b=>(b.owner==='p1'||b.owner==='p2')&&b.kind==='defenseTower');
const results=towers.map(target=>{const reach=target.radius+artillery.attackRange-16;const points=Array.from({length:64},(_,i)=>{const a=i*Math.PI*2/64;return{x:target.x+Math.cos(a)*reach,y:target.y+Math.sin(a)*reach};}).filter(p=>isOpenGround(snapshot.map,p.x,p.y)).map(p=>{
 const margin=Math.min(...foes.map(foe=>Math.hypot(foe.x-p.x,foe.y-p.y)-mountedThreatReach(snapshot,foe,artillery,15)));
 return{...p,targetGap:strikeGap(p,target),margin,artilleryRoad:walkingDistance(snapshot.map,artillery,p,'land'),artilleryArrival:routeTravelTicks(snapshot.map,artillery,p,'land',artillery.speed),safeArtilleryTicks:safeLandTravelTicks(snapshot,artillery,p,foes),
 longestFrontArrival:Math.max(...front.map(u=>routeTravelTicks(snapshot.map,u,p,'land',u.speed)??Infinity)),
 firingFoes:foes.filter(foe=>strikeGap(foe,{...artillery,...p})<=foe.attackRange).map(foe=>foe.id)};
 }).sort((a,b)=>Number(b.safeArtilleryTicks!==undefined)-Number(a.safeArtilleryTicks!==undefined)||Number(b.margin>0)-Number(a.margin>0)||a.longestFrontArrival-b.longestFrontArrival||a.artilleryArrival!-b.artilleryArrival!);
 return{target:target.id,x:target.x,y:target.y,hp:target.hp,radius:target.radius,points};});
writeFileSync(`${dir}/knight-tower-range-query.json`,JSON.stringify({classification:'Read-only native firing geometry from exact manual-main51195 complete world. No commands, no entity edits. Source is independent f267+old-care+mine-defense, not root932.',artillery,results},null,2));console.log(JSON.stringify(results.map(x=>({...x,points:x.points.slice(0,8)})),null,2));
