import{readFileSync,writeFileSync}from'node:fs';
import{createBootstrapCommandPlanner}from'../scripts/bootstrap_1-planner';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{createAiMemoryProvider}from'../src/ai/planner-context';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const label='knight-siege-answer-full-from21000';const saved=JSON.parse(readFileSync(`${dir}/${label}.json.frames/50100.json`,'utf8'));
const metadata=JSON.parse(readFileSync(`${dir}/${label}.metadata.json`,'utf8'));
const match=bootstrapMatches(metadata.setup.seed,['greystonePass'],50400,true).find(x=>x.subject==='v9_knight'&&x.side===1&&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const memory=createAiMemoryProvider(saved.memories),planner=await createBootstrapCommandPlanner(memory);
const trace:any[]=[];runAiGameLoop({...match,game,commandPlanner:context=>{const before=structuredClone(memory.get(context.owner));
 if(context.owner==='p0'&&[50145,50160,50175].includes(context.snapshot.tick))writeFileSync(`${dir}/knight-last-attack-before-${context.snapshot.tick}.json`,JSON.stringify({snapshot:context.snapshot,nextId:game.nextId,
 memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)])),setup:metadata.setup,provenance:{classification:'Exact-source full three-player replay from50100, immediately before p0 planning; not changed-source result',source:metadata.sourceHashes}}));
 const result=planner(context);if(context.owner==='p0')trace.push({tick:context.snapshot.tick,before:before?.v6?.general,after:structuredClone(memory.get('p0')?.v6?.general),entries:result});return result;}});
const expected=JSON.parse(readFileSync(`${dir}/${label}.json.frames/50400.json`,'utf8')),current=JSON.parse(JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]))}));
writeFileSync(`${dir}/knight-last-attack-trace.json`,JSON.stringify({source:metadata.sourceHashes,replayFullSnapshotNextIdAndAllMemoriesMatch:JSON.stringify(expected)===JSON.stringify(current),trace},null,2));console.log(JSON.stringify({exact:JSON.stringify(expected)===JSON.stringify(current),tick:game.tick}));
