import{readFileSync,writeFileSync}from'node:fs';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{readV6Intel,enemyPowerNear}from'../src/ai/policy/v6/intel';
import{planV6CloseoutArmy}from'../src/ai/policy/v6/closeout';
import{strengthOf,TOWER_STRENGTH}from'../src/ai/policy/v6/strength';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
import{distance}from'../src/ai/policy/spatial';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const saved=JSON.parse(readFileSync(`${dir}/knight-last-attack-before-50160.json`,'utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams}),intel=readV6Intel(snapshot,'p0',options);
const target=snapshot.buildings.find(b=>b.id==='building-p2-emberForge-8527')!;
const targetTowers=intel.enemies.flatMap(enemy=>enemy.buildings).filter(b=>b.kind==='defenseTower'&&b.complete&&distance(b,target)<=b.attackRange+target.radius);
const targetDefense=enemyPowerNear(intel,target,900)+targetTowers.length*TOWER_STRENGTH;
const candidates=intel.army.filter(unit=>!isBacklineKind(unit)&&unit.attackDamage>0&&unit.hp>=unit.maxHp*.5)
 .sort((a,b)=>distance(a,target)-distance(b,target));
const squad:typeof candidates=[];for(const unit of candidates){if(squad.length===8||squad.length>=3&&strengthOf(squad)>targetDefense*1.3)break;squad.push(unit);}
const commands=planV6CloseoutArmy(snapshot,'p0',options,intel);
const result={classification:'Read-only audit of original50160 unmodified closeout eligibility. Hypothetical direct-target squad is an arithmetic explanation only, not a command or simulation.',
 constants:{BEATEN_POWER:2,BEATEN_WORKERS:2,DETACHMENT_MIN:3,DETACHMENT_MAX:8,GUARD_RANGE:900},
 enemies:intel.enemies.map(enemy=>({owner:enemy.owner,power:enemy.power,workers:enemy.workers.length,state:enemy.state,beaten:enemy.power<2&&enemy.workers.length<=2,buildings:enemy.buildings.length})),
 earlyPushingAbort:intel.enemies.some(enemy=>enemy.state==='pushing'),beatenBuildingCandidates:intel.enemies.filter(enemy=>enemy.power<2&&enemy.workers.length<=2).flatMap(enemy=>enemy.buildings).map(b=>b.id),
 commands,closeoutMemoryAfter:options.memory.v6?.closeout??null,
 peripheral:{id:target.id,targetDefense,coveringTowers:targetTowers.map(t=>t.id),contested:intel.enemies.some(enemy=>!(enemy.power<2&&enemy.workers.length<=2)),
 hypotheticalActualCloseoutSelectorCrew:squad.map(unit=>({id:unit.id,kind:unit.kind,power:strengthOf([unit]),distance:distance(unit,target)})),squadPower:strengthOf(squad),ownArmyPower:intel.power,requiredDefensePower:targetDefense*1.3,preservesLargerMain:strengthOf(squad)*2<intel.power},
 interpretation:'No enemy is beaten, so beatenBuildings is empty and ordinary closeout returns before any squad selection. This is a main-army peripheral assault problem rather than a defeated-enemy cleanup opportunity. The earlier three-unit injected probe used true-road nearest10503/11039/21262, not this normal straight-nearest cleanup selector.'};
writeFileSync(`${dir}/knight-closeout-audit.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
