import{readFileSync,writeFileSync,mkdirSync,copyFileSync}from'node:fs';
import{dirname}from'node:path';
import{createHash}from'node:crypto';
import{execFileSync}from'node:child_process';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{createAiMemoryProvider}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner,frozenPolicyManifest}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{snapshotGame}from'../src/shared/sim';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const [label='knight-building-objective-v2-opening',sourceLabel='knight-building-objective-v2-from50160']=process.argv.slice(2);
const continuation=JSON.parse(readFileSync(`${dir}/${sourceLabel}.metadata.json`,'utf8'));
const match=bootstrapMatches(continuation.setup.seed,['greystonePass'],96000,true).find(x=>x.subject==='v9_knight'&&x.side===1
 &&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const hash=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex');
const runtimeFiles=Object.keys(continuation.runtimeHashes);
for(const file of runtimeFiles){if(hash(file)!==continuation.runtimeHashes[file])throw new Error(`Source changed since v2: ${file}`);
 const target=`${dir}/${label}.source/${file}`;mkdirSync(dirname(target),{recursive:true});copyFileSync(file,target);}
const game=bootstrapGame(match),memory=createAiMemoryProvider(),planner=await createBootstrapCommandPlanner(memory);
const metadata={classification:`Independent fixed-${sourceLabel}-source ordinary0 native three-player AI match. No restored world, policy seeding, operator or command overrides. Same observed development seed, not generalization or final acceptance.`,
 sourceHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),runtimeHashes:continuation.runtimeHashes,frozenPolicyManifest,match,setup:continuation.setup,startTick:0,maxTick:96000};
writeFileSync(`${dir}/${label}.metadata.json`,JSON.stringify(metadata,null,2));
const frames=`${dir}/${label}.json.frames`;mkdirSync(frames,{recursive:true});
const allMemories=()=>Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]));
const save=()=>writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:allMemories()}));
const transitions:any[]=[],hits:any[]=[];let previous='';
game.observer={hit(source,target,amount){if(target.id.startsWith('building-')||target.hp<=0)hits.push({tick:game.tick,source:source.id,target:target.id,amount,hp:target.hp});}};
save();runAiGameLoop({...match,game,commandPlanner:context=>{const entries=planner(context);if(context.owner==='p0'){
 const general=memory.get('p0')?.v6?.general,key=JSON.stringify(general&&{mode:general.mode,targetHallId:general.targetHallId,targetBuildingId:general.targetBuildingId,stage:general.stage,group:general.group});
 if(key!==previous){transitions.push({tick:context.snapshot.tick,general:structuredClone(general),entries});previous=key;}
 }return entries;}
},{onStep:()=>{if(game.tick%1200===0)save();}});save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({metadata,result:game.match,termination:game.match.winner?'natural-result':'horizon',transitions,hits},null,2));
console.log(JSON.stringify({label,tick:game.tick,termination:game.match.winner?'natural-result':'horizon',winner:game.match.winner,
 ownArmy:game.units.filter(u=>u.owner==='p0'&&u.kind!=='worker').length,ownHalls:game.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall').length,stats:game.match.stats}));
