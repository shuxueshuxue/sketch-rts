import{readFileSync,writeFileSync}from'node:fs';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{walkingDistance}from'../src/shared/terrain';
import{groundSteeringRoute,routeTravelTicks}from'../src/shared/route-selection';
import{strikeGap}from'../src/shared/combat-geometry';
import{SIM_TICKS_PER_SECOND}from'../src/shared/time';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{armedFoes,safeLandTravelTicks,retreatLandRoad}from'../src/ai/bootstrap_1/safe-land-route';
import{readV6Intel}from'../src/ai/policy/v6/intel';
import{strengthOf}from'../src/ai/policy/v6/strength';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
import{mobileCare}from'../src/ai/bootstrap_1/mobile-care';
import{shoppingUnitIds}from'../src/ai/bootstrap_1/shopping';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',saved=JSON.parse(readFileSync(`${dir}/knight-last-attack-before-50160.json`,'utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams});
const intel=readV6Intel(snapshot,'p0',options),foes=armedFoes(snapshot,'p0',options),care=mobileCare.claimsUnits!(snapshot,'p0',options),shop=shoppingUnitIds(snapshot,'p0',options);
const target=snapshot.buildings.find(b=>b.id==='building-p2-emberForge-8527')!;
const candidates=intel.army.filter(u=>!isBacklineKind(u)&&u.hp>=u.maxHp*.5&&u.attackDamage>0&&!care.has(u.id)&&!shop.has(u.id)).map(u=>({unit:u,road:walkingDistance(snapshot.map,u,target,'land')})).filter(x=>x.road!==undefined).sort((a,b)=>a.road!-b.road!);
const crew=candidates.slice(0,3).map(x=>x.unit),power=strengthOf(crew);
const roads=crew.map(u=>{const route=groundSteeringRoute(snapshot.map,u,target),goal=route.at(-1)!;return{id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,level:u.level,speed:u.speed,attackDamage:u.attackDamage,attackCooldown:u.attackCooldown,
 road:route,walkingDistance:walkingDistance(snapshot.map,u,target,'land'),arrivalTicks:routeTravelTicks(snapshot.map,u,target,'land',u.speed),safeLandTravelTicks:safeLandTravelTicks(snapshot,u,goal,foes),retreatRoad:retreatLandRoad(snapshot,u,goal,foes),goal,strikeGapAtGoal:strikeGap(goal,target)};});
const response=intel.enemies.flatMap(e=>e.army.filter(u=>u.attackDamage>0).map(u=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,speed:u.speed,attackRange:u.attackRange,
 roadToTarget:walkingDistance(snapshot.map,u,target,'land'),roadTicksToTarget:routeTravelTicks(snapshot.map,u,target,'land',u.speed),minimumContactTicks:Math.min(...roads.map(r=>Math.max(0,(routeTravelTicks(snapshot.map,u,r.goal,'land',u.speed)??Infinity)-u.attackRange/u.speed*SIM_TICKS_PER_SECOND)))}))).sort((a,b)=>a.minimumContactTicks-b.minimumContactTicks);
const dps=crew.reduce((sum,u)=>sum+u.attackDamage/u.attackCooldown,0),arrival=Math.max(...roads.map(x=>x.arrivalTicks??Infinity)),burnTicks=Math.ceil(target.hp/dps);
const out={classification:'Read-only complete50160 before-commander frame. No orders or entity changes. Potential peripheral-production target, not a hall surrogate.',source:saved.provenance,
 target,care:[...care],shop:[...shop],crew:crew.map(u=>u.id),power,totalOwnPower:intel.power,preservesMajority:power*2<intel.power,roads,response,optimisticAllArriveAt:arrival,optimisticBurnTicks:burnTicks,optimisticTotalWindow:arrival+burnTicks,respondingBeforeWindow:response.filter(x=>x.minimumContactTicks<=arrival+burnTicks),warning:'Response contact estimates subtract weapon reach from actual native road ticks as a lower bound, not a dynamic combat simulation. Full normal frozen opponents must still answer the real raid.'};
writeFileSync(`${dir}/knight-periphery-query.json`,JSON.stringify(out,null,2));console.log(JSON.stringify({crew:out.crew,power,totalOwnPower:intel.power,roads:roads.map(({road,retreatRoad,...rest})=>rest),arrival,burnTicks,response:response.slice(0,8)},null,2));
