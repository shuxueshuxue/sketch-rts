import {createCanvas} from '@napi-rs/canvas';
import {readFileSync, writeFileSync} from 'node:fs';
import {installHeadlessCanvas} from '../src/recorder/record';
import {drawWorld} from '../src/client/world-renderer';
import {UnitFacingTracker} from '../src/client/unit-facing';
const [input, output, focus='p0', zoomArg='0.65'] = process.argv.slice(2);
const {snapshot} = JSON.parse(readFileSync(input!, 'utf8'));
const center=focus==='overview' ? {x:snapshot.map.width/2,y:snapshot.map.height/2} :
 snapshot.units.find((u:any)=>u.id===focus) ?? snapshot.buildings.find((b:any)=>b.id===focus) ?? snapshot.buildings.find((b:any)=>b.owner===focus&&b.kind==='townHall');
if(!center)throw new Error('Unknown focus '+focus);
const zoom=focus==='overview' ? 0.135 : Number(zoomArg), width=1440,height=1440;
installHeadlessCanvas();
const canvas=createCanvas(width,height);
drawWorld({ctx:canvas.getContext('2d') as any,snapshot,
 view:{x:center.x-width/(2*zoom),y:center.y-height/(2*zoom),width,height,zoom},
 now:snapshot.tick*1000/30,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String},viewer:'p0'});
writeFileSync(output!,canvas.toBuffer('image/png'));
console.log(JSON.stringify({tick:snapshot.tick,focus,center:{x:center.x,y:center.y},zoom}));
