import {readFileSync,writeFileSync}from'node:fs';
import {createHash}from'node:crypto';
import {restoreSnapshotIntoGame,snapshotGame,createGame}from'../src/shared/sim';
import {bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import {readV6Intel}from'../src/ai/policy/v6/intel';
import {availableV6Army,attackMargin}from'../src/ai/policy/v6/general';
import {strengthOf,marchStrength,TOWER_STRENGTH}from'../src/ai/policy/v6/strength';
import {v6Doctrine}from'../src/ai/policy/v6/select';
import {groundRespondingPower,groundThreatWithin}from'../src/ai/policy/ground-threat';
import {walkingDistance}from'../src/shared/terrain';
import {mobileCare}from'../src/ai/bootstrap_1/mobile-care';
import {postRecoveryAssignments}from'../src/ai/bootstrap_1/front-recovery';
import {mercenaryControlUnitIds}from'../src/ai/bootstrap_1/mercenary-control';
import {lootRecoveryUnitIds}from'../src/ai/bootstrap_1/loot-recovery';
import {shoppingUnitIds}from'../src/ai/bootstrap_1/shopping';
import {mineGuardUnitIds,planBootstrapGeneral}from'../src/ai/bootstrap_1/mine-defense';
import {mountedFieldOwns}from'../src/ai/bootstrap_1/mounted-field';
import {summonedMiningRaids}from'../src/ai/bootstrap_1/summoned-raids';
import {isBacklineKind}from'../src/ai/policy/v6/backline';
import {distance,averagePoint}from'../src/ai/policy/spatial';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const rows=[49800,50100,50400,54000,96000].map(tick=>{
 const saved=JSON.parse(readFileSync(`${dir}/knight-siege-answer-full-from21000.json.frames/${tick}.json`,'utf8'));
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game);
 const options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams});
 const raw=readV6Intel(snapshot,'p0',options);
 const exclusion={care:[...mobileCare.claimsUnits!(snapshot,'p0',options)],posts:postRecoveryAssignments(snapshot,'p0',options).filter(x=>!x.walk).map(x=>x.patient.id),
  merc:[...mercenaryControlUnitIds(snapshot,'p0',options)],loot:[...lootRecoveryUnitIds(snapshot,'p0',options)],shop:[...shoppingUnitIds(snapshot,'p0',options)],mineGuard:[...mineGuardUnitIds(snapshot,'p0',options)],
  summoned:summonedMiningRaids(snapshot,'p0',options).map(x=>x.spirit.id),mounted:options.memory.mounted?.flatMap(x=>x.unitIds)??[]};
 const busy=new Set(Object.values(exclusion).flat()),army=raw.army.filter(unit=>!busy.has(unit.id)&&!mountedFieldOwns(snapshot,'p0',unit.id));
 const intel={...raw,army,power:strengthOf(army),armyCenter:averagePoint(army)};
 if(raw.intrusion||exclusion.mineGuard.length)throw new Error('Unhandled active intrusion/guard');
 const available=availableV6Army(snapshot,options,intel),front=available.filter(x=>!isBacklineKind(x)&&x.attackDamage>0);
 const {profile}=v6Doctrine(snapshot,'p0',options),marching=marchStrength(available)*(1+profile.aggression),general=options.memory.v6?.general;
 const idle=general?.mode==='hold'&&tick-(general.holdingSince??tick)>=1800;
 const stale=general?.mode==='hold'&&tick-(general.holdingSince??tick)>=5400;
 const maxed=stale&&snapshot.players.p0!.supplyUsed>=81;
 const mainFloor=raw.ownTowers.length>=5?8:18;
 const choices=raw.enemies.flatMap(enemy=>{
  const main=enemy.bases.map(base=>({hall:base.hall,around:enemy.buildings.filter(b=>distance(b,base.hall)<=700).length})).sort((a,b)=>b.around-a.around)[0]!.hall;
  return enemy.bases.map(base=>{
   const expansion=base.hall.id!==main.id;
   const defenders=raw.enemies.reduce((total,other)=>total+strengthOf(other.army.filter(unit=>groundThreatWithin(snapshot,unit,base.hall,900)))
    +(expansion?0:strengthOf(other.army.filter(unit=>!groundThreatWithin(snapshot,unit,base.hall,900)&&groundThreatWithin(snapshot,unit,base.hall,1800)))*.5),0);
   const defended=defenders+base.towers.length*TOWER_STRENGTH,need=defended*attackMargin(options)+2;
   const exposed=enemy.power<marching*.5,ready=expansion||marching>=mainFloor||exposed&&marching>=need;
   const nearHome=[intel.home,...intel.ownHalls].some(hall=>(walkingDistance(snapshot.map,hall,base.hall)??Infinity)<=1500);
   const response=groundRespondingPower(snapshot,intel,base,front),committed=nearHome||stale||marching>=response*1.5;
   return{owner:enemy.owner,id:base.hall.id,position:{x:base.hall.x,y:base.hall.y},expansion,defenders,towerCount:base.towers.length,defended,need,marching,mainFloor,ready,idle,stale,maxed,response,nearHome,committed,
    eligible:ready&&(maxed||committed&&(marching>=need||idle&&marching>=defended)),defenderIds:raw.enemies.flatMap(other=>other.army.filter(unit=>groundThreatWithin(snapshot,unit,base.hall,900)).map(unit=>unit.id))};
  });
 });
 const commands=planBootstrapGeneral(snapshot,'p0',bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams}));
 return{tick,exclusion,rawPower:raw.power,availablePower:strengthOf(available),marching,profile,mainFloor,idle,stale,maxed,choices,
  ownArmy:raw.army.map(u=>({id:u.id,kind:u.kind,level:u.level,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,order:u.order})),enemyPower:raw.enemies.map(x=>({owner:x.owner,power:x.power,state:x.state,army:x.army.map(u=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y}))})),
  previousGeneral:general,commands,allMines:snapshot.resources.map(x=>({id:x.id,amount:x.amount})),memory:saved.memories.p0};
});
const sourceHashes=Object.fromEntries(['src/ai/bootstrap_1/mine-defense.ts','src/ai/bootstrap_1/mobile-care.ts','src/ai/policy/v6/general.ts'].map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
writeFileSync(`${dir}/knight-exhausted-query.json`,JSON.stringify({classification:'Read-only target selector reconstruction, no simulated ticks. Independent mine-defense+old mobile-care source; not root new shared-care combination.',sourceHashes,notes:['Private attackChoices/eligibility reconstructed from current general.ts, constants unchanged.','At queried checkpoints no intrusion or mine guard; exposed assumptions hard-stop otherwise.','nearHome range1500 is verified against V7_HOME_REACH before interpreting.'],rows},null,2));
console.log(JSON.stringify(rows.map(x=>({tick:x.tick,exclusion:x.exclusion,available:x.availablePower,marching:x.marching,mainFloor:x.mainFloor,idle:x.idle,stale:x.stale,choices:x.choices.map(({defenderIds,...rest})=>rest)})),null,2));
