import{readFileSync,writeFileSync,mkdirSync}from'node:fs';
import{createHash}from'node:crypto';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{bootstrapScripts}from'../src/ai/bootstrap_1/policy';
import{createAiMemoryProvider,planAiOwnerCommandEntries}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{groundFrontThreat}from'../src/ai/policy/ground-threat';
import{readV6Intel}from'../src/ai/policy/v6/intel';
import{strengthOf}from'../src/ai/policy/v6/strength';
import{retreatV6Front}from'../src/ai/policy/v6/general';
import{V7_GATHERED_RANGE}from'../src/ai/policy/v7/creep';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
import{distance}from'../src/ai/policy/spatial';
import{mobileCare}from'../src/ai/bootstrap_1/mobile-care';
import{medicalRecoveryUnitIds}from'../src/ai/bootstrap_1/medical-recovery';
import{shoppingUnitIds}from'../src/ai/bootstrap_1/shopping';
import type{AiScript}from'../src/ai/policy/types';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',label='knight-periphery-main-public-probe';
const saved=JSON.parse(readFileSync(`${dir}/knight-last-attack-before-50160.json`,'utf8'));
const match=bootstrapMatches(saved.setup.seed,['greystonePass'],56160,true).find(x=>x.subject==='v9_knight'&&x.side===1&&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
const operator={phase:'gather',ids:saved.memories.p0.v6.general.group as string[],targetId:'building-p2-emberForge-8527',
 // First native road waypoint shared by the approaching ranged escort and the main's route.
 rally:{x:1360,y:2736},sinceTick:50160};
const events:any[]=[],hits:any[]=[],commands:any[]=[];
const base=bootstrapScripts('v9_knight').find(script=>script.id==='v6General')!;
const probe:AiScript={...base,run(snapshot,owner,options){
 const intel=readV6Intel(snapshot,owner,options),care=mobileCare.claimsUnits!(snapshot,owner,options),medics=medicalRecoveryUnitIds(snapshot,owner),shop=shoppingUnitIds(snapshot,owner,options);
 const group=intel.army.filter(unit=>operator.ids.includes(unit.id)&&!care.has(unit.id)&&!medics.has(unit.id)&&!shop.has(unit.id));
 const front=group.filter(unit=>!isBacklineKind(unit)&&unit.attackDamage>0&&!['cast','charge','board'].includes(unit.order.type));
 const target=snapshot.buildings.find(building=>building.id===operator.targetId);
 if(operator.phase==='gather'&&front.every(unit=>distance(unit,operator.rally)<=V7_GATHERED_RANGE)){
  operator.phase='advance';events.push({tick:snapshot.tick,type:'entire-eligible-front-gathered',front:front.map(u=>({id:u.id,x:u.x,y:u.y})),power:strengthOf(group)});
 }
 const threat=front.length?groundFrontThreat(snapshot,intel,front):0;
 if(operator.phase==='advance'&&(!target||strengthOf(group)<threat*1.15)){
  operator.phase='return';events.push({tick:snapshot.tick,type:'return',targetGone:!target,power:strengthOf(group),threat});
 }
 const point=operator.phase==='advance'&&target?target:operator.rally;
 const before=structuredClone(options.memory.v6!.general);
 options.memory.v6!.general={mode:operator.phase==='advance'?'attack':'guard',target:{x:point.x,y:point.y},group:group.map(u=>u.id),groupStart:strengthOf(group)};
 if(snapshot.tick===50160)events.push({tick:snapshot.tick,type:'manual-general-policy-override',before,after:structuredClone(options.memory.v6!.general),operator:structuredClone(operator)});
 if(operator.phase==='return')return retreatV6Front(snapshot,owner,front,operator.rally,options).map(command=>({...command,avoidCombat:true}));
 const walking=front.filter(unit=>{
  if(unit.order.type==='attack'&&snapshot.units.some(foe=>foe.id===unit.order.targetId))return false;
  return !(unit.order.type==='attackMove'&&distance(unit.order,point)<20);
 });
 return walking.length?[{type:'attackMove',unitIds:walking.map(u=>u.id),x:point.x,y:point.y}]:[];
}};
const scripts=bootstrapScripts('v9_knight').map(script=>script.id==='v6General'?probe:script);
const frames=`${dir}/${label}.json.frames`;mkdirSync(frames,{recursive:true});
const save=()=>writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,
 memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)])),operator:structuredClone(operator)}));
game.observer={hit(source,target,amount){if(target.id===operator.targetId||operator.ids.includes(target.id)||operator.ids.includes(source.id))hits.push({tick:game.tick,source:source.id,target:target.id,amount,hp:target.hp});}};
const provenance={classification:'Manual main-army policy/command override tactical probe, NOT unmodified AI or ordinary opening. Only eligible original main unit set advances through public attackMove; no entity/order injection or opponent memory edits. Original medical, spells, caster screen and both normal frozen-v8 planners remain active.',source:saved.provenance,
 sourceHashes:Object.fromEntries(['src/ai/bootstrap_1/mobile-care.ts','src/ai/bootstrap_1/mine-defense.ts','.playtest/knight-periphery-main-probe.ts'].map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')])),manualOperatorInitial:structuredClone(operator)};
save();runAiGameLoop({...match,game,commandPlanner:context=>{const entries=context.owner==='p0'?planAiOwnerCommandEntries(context.snapshot,
 {playerId:'p0',version:'v9_knight',source:context.source,scripts},{teams:context.teams,memoryProvider:memory}):planner(context);
 if(context.owner==='p0')commands.push({tick:context.snapshot.tick,operator:structuredClone(operator),entries});return entries;}},{onStep:()=>{if(game.tick%120===0)save();}});save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({provenance,events,hits,commands,result:game.match,
 final:{tick:game.tick,operator,target:game.buildings.find(b=>b.id===operator.targetId),crew:game.units.filter(u=>operator.ids.includes(u.id))}},null,2));
console.log(JSON.stringify({tick:game.tick,events,targetHp:game.buildings.find(b=>b.id===operator.targetId)?.hp,crew:game.units.filter(u=>operator.ids.includes(u.id)).map(u=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),stats:game.match.stats}));
