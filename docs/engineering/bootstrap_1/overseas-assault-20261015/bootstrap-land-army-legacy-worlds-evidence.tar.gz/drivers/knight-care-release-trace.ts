import{readFileSync,writeFileSync,mkdirSync}from'node:fs';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{recoveryHealingWindow,recoveryIncomingDamage}from'../src/ai/bootstrap_1/recovery-threat';
import{mobileCare}from'../src/ai/bootstrap_1/mobile-care';
import{createAiMemoryProvider}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{abilityCooldown}from'../src/shared/ability-cooldowns';
import{distance}from'../src/ai/policy/spatial';
import{landRecoveryAssignments}from'../src/ai/bootstrap_1/expedition-recovery';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',label=process.argv[2]??'knight-care-release-v4',sourceLabel=process.argv[3]??'knight-objective-v4-care-risk-first-tower';
const input=`${dir}/${sourceLabel}.frames/10440.json`,saved=JSON.parse(readFileSync(input,'utf8'));
const setup=JSON.parse(readFileSync(`${dir}/${sourceLabel}.first-building-input.json`,'utf8')).setup;
const match=bootstrapMatches(setup.seed,['greystonePass'],10680,true).find(m=>m.subject==='v9_knight'&&m.side===1&&m.agents.p0!.race==='ember'&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
mkdirSync(`${dir}/${label}.frames`,{recursive:true});const entries:any[]=[],healing:any[]=[];let priorHp=game.units.find(u=>u.id==='unit-p0-emberRavager-1079')?.hp;
runAiGameLoop({...match,game,commandPlanner:context=>{if(context.owner==='p0'){
 const snapshot=context.snapshot,memories=Object.fromEntries(Object.keys(match.agents).map(o=>[o,memory.get(o)])),patient=snapshot.units.find(u=>u.id==='unit-p0-emberRavager-1079');
 writeFileSync(`${dir}/${label}.frames/${game.tick}.json`,JSON.stringify({snapshot,nextId:game.nextId,memories,setup}));
 if(patient){const options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(memories.p0!),teams:game.teams});
 const own=snapshot.units.filter(u=>u.owner==='p0'&&!u.deck&&u.kind!=='worker'),foes=[...snapshot.units,...snapshot.buildings].filter(e=>e.owner!=='p0'&&e.attackDamage>0&&e.hp>0);
 const care=landRecoveryAssignments(snapshot,'p0',options,own);
 entries.push({tick:game.tick,patient:{hp:patient.hp,order:patient.order,x:patient.x,y:patient.y},general:memories.p0?.v6?.general,claimed:mobileCare.claimsUnits!(snapshot,'p0',options).has(patient.id),assigned:care.recovering.find(x=>x.patient.id===patient.id)?.healer.id,
 healers:own.filter(u=>u.kind==='priest').map(h=>{const window=recoveryHealingWindow(snapshot,patient,h);return{id:h.id,x:h.x,y:h.y,gap:distance(patient,h),cd:abilityCooldown(h,'heal'),order:h.order,window,damage:window===undefined?null:recoveryIncomingDamage(snapshot,patient,foes,window,{teams:game.teams})};}),
 pending:structuredClone(snapshot.projectiles.filter(p=>p.targetId===patient.id))});
 }}return planner(context);}},{onStep:()=>{const live=game.units.find(u=>u.id==='unit-p0-emberRavager-1079');if(live&&priorHp!==undefined&&live.hp>priorHp)healing.push({tick:game.tick,before:priorHp,after:live.hp,healers:game.units.filter(u=>u.owner==='p0'&&u.kind==='priest').map(h=>({id:h.id,gap:distance(live,h),cooldown:abilityCooldown(h,'heal')}))});priorHp=live?.hp;}});
const actual={snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(o=>[o,memory.get(o)]))},expected=JSON.parse(readFileSync(`${dir}/${sourceLabel}.frames/10680.json`,'utf8'));
writeFileSync(`${dir}/${label}.json`,JSON.stringify({classification:'Read-only prethink diagnosis from recorded10440 complete frame; normal frozen three-player policy. No command/world/memory edits.',input,entries,healing,exact10680:JSON.stringify(actual)===JSON.stringify(expected)},null,2));
console.log(JSON.stringify({entries:entries.length,exact10680:JSON.stringify(actual)===JSON.stringify(expected)}));
