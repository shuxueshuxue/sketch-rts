import{readFileSync,writeFileSync}from'node:fs';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{readV6Intel}from'../src/ai/policy/v6/intel';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
import{strengthOf,marchStrength}from'../src/ai/policy/v6/strength';
import{groundRespondingPower,groundAttackArrival}from'../src/ai/policy/ground-threat';
import{routeArrivals,routeWithinDistance}from'../src/shared/route-selection';
import{strikeGap}from'../src/shared/combat-geometry';
import{GOLD_MINE_RULES}from'../src/shared/mining';
import{V7_HOME_REACH}from'../src/ai/policy/v7/creep';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const scenarios=[{input:'knight-objective-v3-first-tower.first-building-input.json',report:'knight-objective-v3-first-tower.json',tick:9930,target:'building-p2-defenseTower-1760'},
 {input:'knight-building-objective-from50160.first-objective-input.json',report:'knight-building-objective-from50160.json',tick:55560,target:'building-p2-workshop-6143'}];
const results=scenarios.map(case_=>{
 const saved=JSON.parse(readFileSync(`${dir}/${case_.input}`,'utf8')),report=JSON.parse(readFileSync(`${dir}/${case_.report}`,'utf8'));
 const ids=(report.events?.find((e:any)=>e.tick===case_.tick)?.after??report.transitions.find((e:any)=>e.tick===case_.tick)?.general).group;
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game);
 const options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams}),intel=readV6Intel(snapshot,'p0',options);
 const target=snapshot.buildings.find(b=>b.id===case_.target)!,group=snapshot.units.filter(u=>ids.includes(u.id)),front=group.filter(u=>!isBacklineKind(u)&&u.attackDamage>0);
 const arrivals=routeArrivals(snapshot.map,front,target,'land'),window=arrivals.reduce((last,u)=>Math.max(last,u.ticks),0),army=intel.enemies.flatMap(e=>e.army);
 const firing=army.filter(u=>strikeGap(u,target)<=u.attackRange),responders=routeArrivals(snapshot.map,army.filter(u=>!firing.includes(u)),target,'land').filter(u=>u.ticks<=window);
 const income=intel.ownHalls.filter(h=>h.complete&&snapshot.resources.some(m=>m.amount>0&&Math.hypot(m.x-h.x,m.y-h.y)<=GOLD_MINE_RULES.baseRange));
 const counterraiders=income.flatMap(hall=>routeArrivals(snapshot.map,army,hall,'land').filter(u=>u.ticks<=window).map(u=>({hall:hall.id,...u})));
 const union=[...new Set([...firing,...responders.map(x=>x.unit),...counterraiders.map(x=>x.unit)])],response=groundRespondingPower(snapshot,intel,target,front);
 if(Math.abs(response-strengthOf(union))>1e-9)throw new Error('Response reconstruction mismatch');
 const homeReach=[intel.home,...intel.ownHalls].map(hall=>({hall,within:routeWithinDistance(snapshot.map,hall,target,'land',V7_HOME_REACH)}));
 const current=saved.memories.p0.v6.general,stale=current?.mode==='hold'&&snapshot.tick-(current.holdingSince??snapshot.tick)>=5400;
 return{tick:snapshot.tick,target,group:group.map(u=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp})),marching:marchStrength(group),homeReach,farOff:!homeReach.some(h=>h.within),stale,
  originalCommitted:homeReach.some(h=>h.within)||stale||marchStrength(group)>=response*1.5,withoutHomeExemptionCommitted:stale||marchStrength(group)>=response*1.5,
  response,requiredResponseMargin:response*1.5,window,frontArrivals:arrivals.map(u=>({id:u.unit.id,ticks:u.ticks,firingArrival:groundAttackArrival(snapshot,u.unit,target)})),
  firing:firing.map(u=>u.id),responders:responders.map(u=>({id:u.unit.id,kind:u.unit.kind,power:strengthOf([u.unit]),ticks:u.ticks,firingArrival:groundAttackArrival(snapshot,u.unit,target)})),
  counterraiders:counterraiders.map(u=>({id:u.unit.id,kind:u.unit.kind,power:strengthOf([u.unit]),hall:u.hall,ticks:u.ticks})),union:union.map(u=>u.id),
  allEnemyArrivals:routeArrivals(snapshot.map,army,target,'land').map(u=>({id:u.unit.id,kind:u.unit.kind,ticks:u.ticks,power:strengthOf([u.unit])}))};
});
writeFileSync(`${dir}/knight-building-response-query.json`,JSON.stringify({classification:'Read-only exact native-road reconstruction of the original response commitment gate, actual selected groups and all3 memories. No world/order changes or simulation.',results},null,2));
console.log(JSON.stringify(results.map(({target,group,homeReach,responders,counterraiders,allEnemyArrivals,frontArrivals,...r})=>({...r,target:target.id,homeReach,responders,counterraiders,frontArrivals})),null,2));
