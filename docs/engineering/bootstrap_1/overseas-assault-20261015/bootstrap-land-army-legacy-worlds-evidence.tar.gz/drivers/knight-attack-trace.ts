import {readFileSync,writeFileSync}from'node:fs';
import {bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import {createAiMemoryProvider}from'../src/ai/planner-context';
import {createBootstrapCommandPlanner}from'../scripts/bootstrap_1-planner';
import {runAiGameLoop}from'../src/ai/game-runner';
import {restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',base='knight-f267-expansion-b';
const report=JSON.parse(readFileSync(`${dir}/${base}.json`,'utf8')),frame=JSON.parse(readFileSync(`${dir}/${base}.json.frames/6000.json`,'utf8'));
const match=bootstrapMatches(report.setup.seed,['greystonePass'],7500,true).find(m=>m.subject==='v9_knight'&&m.side===1&&m.agents.p0!.race==='ember'&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match),memory=createAiMemoryProvider();restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
for(const[owner,p]of Object.entries(report.rows.find((r:any)=>r.tick===6000).players))memory.set!(owner,(p as any).policy);
const planner=await createBootstrapCommandPlanner(memory),rows:any[]=[],events:any[]=[],ids=['unit-p0-emberRavager-1069','unit-p0-emberRavager-1079'];let attackFrame=false,exposureFrame=false;
const commandPlanner:Parameters<typeof runAiGameLoop>[0]['commandPlanner']=context=>{
 const before=structuredClone(memory.get(context.owner)),entries=planner(context);
 if(context.owner==='p0'){
  const saved={snapshot:context.snapshot,nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,owner==='p0'?before:structuredClone(memory.get(owner))])),setup:report.setup};
  if(!attackFrame&&memory.get('p0')?.v6?.general?.mode==='attack'){writeFileSync(`${dir}/knight-f267-first-attack.json`,JSON.stringify(saved));attackFrame=true;}
  const patients=context.snapshot.units.filter(u=>ids.includes(u.id));
  if(!exposureFrame&&patients.some(u=>u.hp<u.maxHp)){writeFileSync(`${dir}/knight-f267-first-attack-damage.json`,JSON.stringify(saved));exposureFrame=true;}
  events.push({tick:context.snapshot.tick,generalBefore:before?.v6?.general,generalAfter:memory.get('p0')?.v6?.general,entries:entries.filter(e=>'unitIds'in e.command&&e.command.unitIds.some(id=>ids.includes(id))||'unitId'in e.command&&ids.includes(e.command.unitId))});
 }
 return entries;
};
runAiGameLoop({...match,game,commandPlanner},{onStep:({game})=>{
 if(game.tick===7200){const target=JSON.parse(readFileSync(`${dir}/${base}.json.frames/7200.json`,'utf8'));const current={snapshot:JSON.parse(JSON.stringify(snapshotGame(game))),nextId:game.nextId};writeFileSync(`${dir}/knight-f267-trace-7200-replay.json`,JSON.stringify({snapshotAndNextIdMatch:JSON.stringify(current)===JSON.stringify(target),snapshot:current.snapshot,nextId:current.nextId}));}
 if(game.tick%15!==0)return;const s=snapshotGame(game);rows.push({tick:game.tick,troops:s.units.filter(u=>ids.includes(u.id)).map(u=>({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order})),towers:s.buildings.filter(b=>b.owner==='p2'&&b.kind==='defenseTower').map(b=>({id:b.id,x:b.x,y:b.y,hp:b.hp,complete:b.complete,cooldown:b.cooldown})),corpses:s.corpses.filter(c=>ids.includes(c.unitId))});
}});
writeFileSync(`${dir}/knight-f267-attack-trace.json`,JSON.stringify({classification:'Same-source full-AI focused replay6000 to7500; not a new opening score',events,rows},null,2));console.log(JSON.stringify({done:true,end:game.tick,attackFrame,exposureFrame}));
