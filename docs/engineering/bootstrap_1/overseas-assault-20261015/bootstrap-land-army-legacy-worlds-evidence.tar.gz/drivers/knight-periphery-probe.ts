import{readFileSync,writeFileSync,mkdirSync}from'node:fs';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{bootstrapScripts}from'../src/ai/bootstrap_1/policy';
import{createAiMemoryProvider,planAiOwnerCommandEntries}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{groundThreatWithin}from'../src/ai/policy/ground-threat';
import{strengthOf}from'../src/ai/policy/v6/strength';
import{retreatV6Front}from'../src/ai/policy/v6/general';
import type{AiScript}from'../src/ai/policy/types';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const audit=process.argv.includes('--seed-audit-only'),label=audit?'knight-periphery-seed-audit':'knight-periphery-public-probe',saved=JSON.parse(readFileSync(`${dir}/knight-last-attack-before-50160.json`,'utf8'));
const query=JSON.parse(readFileSync(`${dir}/knight-periphery-query.json`,'utf8'));
const match=bootstrapMatches(saved.setup.seed,['greystonePass'],audit?50280:53760,true).find(x=>x.subject==='v9_knight'&&x.side===1&&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
const base=bootstrapScripts('v9_knight').find(script=>script.id==='v6Closeout')!;
const events:any[]=[],hits:any[]=[];let started=false;
const probe:AiScript={...base,run(snapshot,owner,options){
 const v6=options.memory.v6!;
 if(!started){started=true;const beforeMemory=structuredClone(options.memory);v6.closeout={unitIds:query.crew,targetId:query.target.id,sinceTick:snapshot.tick};events.push({tick:snapshot.tick,type:'manual-policy-seed-injected',job:structuredClone(v6.closeout),beforeMemory,afterMemory:structuredClone(options.memory)});}
 const job=v6.closeout;if(!job)return[];
 const target=snapshot.buildings.find(building=>building.id===job.targetId);
 const squad=snapshot.units.filter(unit=>unit.owner===owner&&job.unitIds.includes(unit.id));
 const foes=snapshot.units.filter(unit=>(unit.owner==='p1'||unit.owner==='p2')&&unit.kind!=='worker');
 const facing=foes.filter(foe=>squad.some(unit=>groundThreatWithin(snapshot,foe,unit,900)));
 if(!target||squad.length<3||squad.some(unit=>unit.hp<unit.maxHp*.35)||strengthOf(facing)>strengthOf(squad)){
  events.push({tick:snapshot.tick,type:'release',targetGone:!target,squad:squad.map(unit=>({id:unit.id,hp:unit.hp})),facing:facing.map(unit=>unit.id),facingPower:strengthOf(facing),squadPower:strengthOf(squad)});
  delete v6.closeout;
  const home=snapshot.buildings.find(building=>building.owner===owner&&building.kind==='townHall')!;
  return retreatV6Front(snapshot,owner,squad,home,options).map(command=>({...command,avoidCombat:true}));
 }
 return squad.filter(unit=>!(unit.order.type==='attack'&&unit.order.targetId===target.id))
  .map(unit=>({type:'attack' as const,unitIds:[unit.id],targetId:target.id}));
}};
const scripts=bootstrapScripts('v9_knight').map(script=>script.id==='v6Closeout'?probe:script);
const frames=`${dir}/${label}.json.frames`;mkdirSync(frames,{recursive:true});
const save=()=>writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,
 memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]))}));
game.observer={hit(source,target,amount){if(target.id===query.target.id||query.crew.includes(target.id))hits.push({tick:game.tick,source:source.id,target:target.id,amount,hp:target.hp});}};
save();runAiGameLoop({...match,game,commandPlanner:context=>context.owner==='p0'?planAiOwnerCommandEntries(context.snapshot,
 {playerId:'p0',version:'v9_knight',source:context.source,scripts},{teams:context.teams,memoryProvider:memory}):planner(context)},{onStep:()=>{if(game.tick%120===0)save();}});save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({classification:'Explicit one-off public-command diagnostic: selects actual forge for existing closeout ownership slot; not a production candidate or ordinary match result. All original entities/normal opponents retained. Existing general/abilities/medical and both frozen v8 planners remain active.',source:saved.provenance,query,events,hits,result:game.match,
 final:{tick:game.tick,target:game.buildings.find(b=>b.id===query.target.id),crew:game.units.filter(u=>query.crew.includes(u.id))}},null,2));
console.log(JSON.stringify({tick:game.tick,events,targetHp:game.buildings.find(b=>b.id===query.target.id)?.hp,crew:game.units.filter(u=>query.crew.includes(u.id)).map(u=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),hits:hits.length}));
