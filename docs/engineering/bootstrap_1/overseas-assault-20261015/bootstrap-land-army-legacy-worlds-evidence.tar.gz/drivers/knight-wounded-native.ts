import { readFileSync, writeFileSync } from 'node:fs';
import { createGame, restoreSnapshotIntoGame, snapshotGame, stepGame, issuePlayerCommand } from '../src/shared/sim';
import { bootstrapPolicyContext } from '../src/ai/bootstrap_1/policy';
import { landRecoveryAssignments } from '../src/ai/bootstrap_1/expedition-recovery';
import { unitMover } from '../src/shared/catalog';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const report=JSON.parse(readFileSync(`${dir}/knight-f267-expansion-b.json`,'utf8'));
const frame=JSON.parse(readFileSync(`${dir}/knight-f267-expansion-b.json.frames/7200.json`,'utf8'));
const results=[];
for(const mode of ['control','cover'] as const){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
 const snapshot=snapshotGame(game),memory=structuredClone(report.rows.find((r:any)=>r.tick===7200).players.p0.policy);
 const options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory,teams:snapshot.teams});
 const care=landRecoveryAssignments(snapshot,'p0',options,snapshot.units.filter(u=>u.owner==='p0'&&!u.deck&&u.kind!=='worker'&&unitMover(u.kind)==='land'));
 const commands=care.unmedicated.map(({patient,cover})=>({type:'move' as const,unitIds:[patient.id],...cover,avoidCombat:true}));
 if(mode==='cover')for(const command of commands)issuePlayerCommand(game,'p0',command);
 const observations=[];let old='';
 for(let tick=0;tick<240;tick++){
  stepGame(game);
  const units=['unit-p0-emberRavager-1069','unit-p0-emberRavager-1079'].map(id=>game.units.find(u=>u.id===id)).map(u=>u&&({id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order}));
  const next=JSON.stringify(units.map(u=>u?.hp));if(tick%15===0||next!==old){observations.push({tick:game.tick,units});old=next;}
 }
 const result={mode,classification:'240-tick bare native command diagnostic from full7200 world; no AI replanning or match score',commands:mode==='cover'?commands:[],observations,endTick:game.tick,alive:game.units.filter(u=>['unit-p0-emberRavager-1069','unit-p0-emberRavager-1079'].includes(u.id)).map(u=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),corpses:game.corpses.filter(c=>['unit-p0-emberRavager-1069','unit-p0-emberRavager-1079'].includes(c.unitId))};
 writeFileSync(`${dir}/knight-wounded-native-${mode}.json`,JSON.stringify({result,snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.entries(report.rows.find((r:any)=>r.tick===7200).players).map(([owner,p]:any)=>[owner,p.policy]))}));results.push(result);
}
writeFileSync(`${dir}/knight-wounded-native-comparison.json`,JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
