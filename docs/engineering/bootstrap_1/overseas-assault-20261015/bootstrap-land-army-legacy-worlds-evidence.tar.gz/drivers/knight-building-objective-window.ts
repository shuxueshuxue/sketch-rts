import{readFileSync,writeFileSync,mkdirSync,copyFileSync}from'node:fs';
import{dirname}from'node:path';
import{createHash}from'node:crypto';
import{execFileSync}from'node:child_process';
import{bootstrapGame,bootstrapMatches}from'../src/ai/bootstrap_1/benchmark';
import{createAiMemoryProvider}from'../src/ai/planner-context';
import{createBootstrapCommandPlanner,frozenPolicyManifest}from'../scripts/bootstrap_1-planner';
import{runAiGameLoop}from'../src/ai/game-runner';
import{restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const[label='knight-building-objective-from50160',endArg='96000']=process.argv.slice(2),end=Number(endArg);
const input=`${dir}/knight-last-attack-before-50160.json`,saved=JSON.parse(readFileSync(input,'utf8'));
if(saved.operator||saved.snapshot.tick!==50160||saved.memories.p0.v6.general.targetBuildingId)throw new Error('Input is not the original unmodified-policy50160 checkpoint');
const match=bootstrapMatches(saved.setup.seed,['greystonePass'],end,true).find(x=>x.subject==='v9_knight'&&x.side===1&&x.agents.p0!.race==='ember'&&Object.values(x.agents).slice(1).map(a=>a.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
const hash=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex');
const runtimeFiles=['src/ai/memory.ts','src/ai/policy/v6/general.ts','src/ai/policy/v6/army-objective.ts','src/ai/policy/ground-threat.ts',
 'src/ai/bootstrap_1/mine-defense.ts','src/ai/bootstrap_1/building-objectives.ts','src/ai/bootstrap_1/mobile-care.ts','src/ai/bootstrap_1/general-regroup.ts','src/ai/bootstrap_1/policy.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/bootstrap_1/recovery-threat.ts','src/ai/bootstrap_1/care-rendezvous.ts','src/ai/policy/ground-arrival.ts','src/ai/bootstrap_1/medical-recovery.ts'];
for(const file of runtimeFiles){const target=`${dir}/${label}.source/${file}`;mkdirSync(dirname(target),{recursive:true});copyFileSync(file,target);}
const metadata={classification:'Fixed-source complete three-player AI continuation from original50160 world+all3 policy memories. No artificial objective, operator, command override or world/order edit. Not an ordinary0 match or root97 source.',
 input,inputSha256:hash(input),sourceHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),runtimeHashes:Object.fromEntries(runtimeFiles.map(path=>[path,hash(path)])),
 sourceDiff:execFileSync('git',['diff','--','src/ai'],{encoding:'utf8'}),frozenPolicyManifest,setup:saved.setup,startTick:game.tick,maxTick:end};
writeFileSync(`${dir}/${label}.metadata.json`,JSON.stringify(metadata,null,2));
const frames=`${dir}/${label}.json.frames`;mkdirSync(frames,{recursive:true});
const allMemories=()=>Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]));
const save=()=>writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:allMemories()}));
const transitions:any[]=[],hits:any[]=[];let firstObjective=false,previous='';
game.observer={hit(source,target,amount){if(target.id.startsWith('building-')||target.hp<=0)hits.push({tick:game.tick,source:source.id,target:target.id,amount,hp:target.hp});}};
save();runAiGameLoop({...match,game,commandPlanner:context=>{
 const before=context.owner==='p0'?structuredClone(allMemories()):undefined;
 const entries=planner(context);if(context.owner==='p0'){
  const general=memory.get('p0')?.v6?.general,key=JSON.stringify(general&&{mode:general.mode,targetHallId:general.targetHallId,targetBuildingId:general.targetBuildingId,stage:general.stage,group:general.group});
  if(key!==previous){transitions.push({tick:context.snapshot.tick,general:structuredClone(general),entries});previous=key;}
  if(!firstObjective&&general?.targetBuildingId){firstObjective=true;writeFileSync(`${dir}/${label}.first-objective-input.json`,JSON.stringify({snapshot:context.snapshot,nextId:game.nextId,memories:before,setup:saved.setup}));}
 }return entries;}
},{onStep:()=>{if(game.tick%300===0)save();}});save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({metadata,result:game.match,termination:game.match.winner?'natural-result':'horizon',transitions,hits},null,2));
console.log(JSON.stringify({label,tick:game.tick,termination:game.match.winner?'natural-result':'horizon',winner:game.match.winner,firstObjective,
 ownArmy:game.units.filter(u=>u.owner==='p0'&&u.kind!=='worker').length,ownHalls:game.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall').length,
 stats:game.match.stats}));
