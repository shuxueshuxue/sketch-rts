import{readFileSync,writeFileSync}from'node:fs';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'../src/shared/sim';
import{bootstrapPolicyContext}from'../src/ai/bootstrap_1/policy';
import{readV6Intel}from'../src/ai/policy/v6/intel';
import{availableV6Army,attackMargin}from'../src/ai/policy/v6/general';
import{buildingObjective,objectiveTowers}from'../src/ai/policy/v6/army-objective';
import{strengthOf,marchStrength,TOWER_STRENGTH}from'../src/ai/policy/v6/strength';
import{v6Doctrine}from'../src/ai/policy/v6/select';
import{groundAttackArrival,groundRespondingPower,groundThreatWithin}from'../src/ai/policy/ground-threat';
import{routeWithinDistance}from'../src/shared/route-selection';
import{mobileCare}from'../src/ai/bootstrap_1/mobile-care';
import{postRecoveryAssignments}from'../src/ai/bootstrap_1/front-recovery';
import{mercenaryControlUnitIds}from'../src/ai/bootstrap_1/mercenary-control';
import{lootRecoveryUnitIds}from'../src/ai/bootstrap_1/loot-recovery';
import{shoppingUnitIds}from'../src/ai/bootstrap_1/shopping';
import{mineGuardUnitIds,planBootstrapGeneral}from'../src/ai/bootstrap_1/mine-defense';
import{mountedFieldOwns}from'../src/ai/bootstrap_1/mounted-field';
import{summonedMiningRaids}from'../src/ai/bootstrap_1/summoned-raids';
import{bootstrapBuildingTargets}from'../src/ai/bootstrap_1/building-objectives';
import{isBacklineKind}from'../src/ai/policy/v6/backline';
import{distance,averagePoint}from'../src/ai/policy/spatial';
const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',label='knight-building-objective-v2-from50160';
const saved=JSON.parse(readFileSync(`${dir}/${label}.json.frames/96000.json`,'utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game);
const options=bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams}),raw=readV6Intel(snapshot,'p0',options);
const exclusion={care:[...mobileCare.claimsUnits!(snapshot,'p0',options)],posts:postRecoveryAssignments(snapshot,'p0',options).filter(x=>!x.walk).map(x=>x.patient.id),
 merc:[...mercenaryControlUnitIds(snapshot,'p0',options)],loot:[...lootRecoveryUnitIds(snapshot,'p0',options)],shop:[...shoppingUnitIds(snapshot,'p0',options)],mineGuard:[...mineGuardUnitIds(snapshot,'p0',options)],
 summoned:summonedMiningRaids(snapshot,'p0',options).map(x=>x.spirit.id),mounted:options.memory.mounted?.flatMap(x=>x.unitIds)??[]};
if(raw.intrusion||exclusion.mineGuard.length)throw new Error('Active intrusion/guard needs mainArmyIntel reconstruction');
const busy=new Set(Object.values(exclusion).flat()),army=raw.army.filter(unit=>!busy.has(unit.id)&&!mountedFieldOwns(snapshot,'p0',unit.id));
const intel={...raw,army,power:strengthOf(army),armyCenter:averagePoint(army)},available=availableV6Army(snapshot,options,intel),front=available.filter(u=>!isBacklineKind(u)&&u.attackDamage>0);
const {profile}=v6Doctrine(snapshot,'p0',options),marching=marchStrength(available)*(1+profile.aggression),general=options.memory.v6?.general;
const idle=general?.mode==='hold'&&snapshot.tick-(general.holdingSince??snapshot.tick)>=1800,stale=general?.mode==='hold'&&snapshot.tick-(general.holdingSince??snapshot.tick)>=5400;
const maxed=stale&&snapshot.players.p0!.supplyUsed>=81,mainFloor=raw.ownTowers.length>=5?8:18;
const choices=[...intel.enemies.flatMap(enemy=>enemy.bases.map(base=>({kind:'base' as const,base,building:base.hall,towers:base.towers}))),
 ...bootstrapBuildingTargets(snapshot,intel,front).map(building=>({kind:'building' as const,building,towers:objectiveTowers(buildingObjective(intel,building)),base:undefined}))].map(choice=>{
 const {building,towers,kind,base}=choice,enemy=intel.enemies.find(e=>e.owner===building.owner)!;
 const main=enemy.bases.map(b=>({hall:b.hall,around:enemy.buildings.filter(x=>distance(x,b.hall)<=700).length})).sort((a,b)=>b.around-a.around)[0]?.hall;
 const expansion=kind==='base'&&building.id!==main?.id;
 const defenders=intel.enemies.reduce((total,e)=>total+strengthOf(e.army.filter(u=>groundThreatWithin(snapshot,u,building,900)))
  +(kind==='base'&&!expansion?strengthOf(e.army.filter(u=>!groundThreatWithin(snapshot,u,building,900)&&groundThreatWithin(snapshot,u,building,1800)))*.5:0),0);
 const defended=defenders+towers.length*TOWER_STRENGTH,need=defended*attackMargin(options)+2;
 const ready=kind!=='base'||expansion||marching>=mainFloor||enemy.power<marching*.5&&marching>=need;
 const nearHome=[intel.home,...intel.ownHalls].some(hall=>routeWithinDistance(snapshot.map,hall,building,'land',1500));
 const response=groundRespondingPower(snapshot,intel,building,front),committed=nearHome||stale||marching>=response*1.5;
 return{id:building.id,kind,position:{x:building.x,y:building.y},hp:building.hp,towerIds:towers.map(t=>t.id),defenders,defended,need,marching,ready,nearHome,response,committed,
  eligible:ready&&(maxed||committed&&(marching>=need||idle&&marching>=defended)),frontArrivals:front.map(u=>({id:u.id,...groundAttackArrival(snapshot,u,building)})),
  defenderIds:intel.enemies.flatMap(e=>e.army.filter(u=>groundThreatWithin(snapshot,u,building,900)).map(u=>u.id))};
}).sort((a,b)=>a.need-b.need);
const commands=planBootstrapGeneral(snapshot,'p0',options);
const result={classification:'Read-only exact v2 horizon army/eligibility reconstruction. No simulated ticks or source changes; private thresholds transcribed unchanged from general.ts.',tick:game.tick,general,exclusion,marching,availablePower:strengthOf(available),idle,stale,maxed,mainFloor,choices,commands,
 ownArmy:army,enemyArmies:intel.enemies.map(e=>({owner:e.owner,power:e.power,army:e.army})),mines:snapshot.resources};
writeFileSync(`${dir}/knight-objective-v2-hold-query.json`,JSON.stringify(result,null,2));console.log(JSON.stringify({...result,ownArmy:undefined,enemyArmies:undefined,choices:choices.map(({frontArrivals,defenderIds,...r})=>r)},null,2));
