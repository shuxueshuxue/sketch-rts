import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const source='/workspace/sketch-rts-bootstrap-combined-ordinary0-control';
const out='/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016';
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const {setBuildingBodies}=await load('src/shared/terrain.ts');
const {groundSteeringRoute,routeTravelTicks}=await load('src/shared/route-selection.ts');
const {unitMover,UNIT_DEFS,ABILITY_DEFS}=await load('src/shared/catalog.ts');
const diagnostic=JSON.parse(readFileSync(out+'/loss-diagnostic.json','utf8'));
const rows:any[]=[];
const gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
for(const record of diagnostic.units.filter((u:any)=>['fieldMedic','priest'].includes(u.kind))){
 const input=record.nearestPreviousCompleteFrame.file,bytes=readFileSync(input);
 const saved=JSON.parse(gunzipSync(bytes).toString()),before=JSON.stringify(saved),s=saved.snapshot;
 // This isolated parsed copy is never a Game. Register the existing building
 // overlay for the shared static steering query, without stepping or planning.
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const unit=s.units.find((u:any)=>u.id===record.id);if(!unit)throw Error('Missing live doctor in earlier state');
 const own=s.units.filter((u:any)=>u.owner==='p0'&&u.id!==unit.id&&!u.deck&&unitMover(u.kind)==='land');
 const melee=own.filter((u:any)=>u.kind!=='worker'&&u.attackDamage>0&&u.attackRange<=100&&!UNIT_DEFS[u.kind].abilities.some((a:string)=>ABILITY_DEFS[a].behavior==='heal')).sort((a:any,b:any)=>gap(unit,a)-gap(unit,b)).slice(0,3);
 const foes=s.units.filter((u:any)=>['p1','p2'].includes(u.owner)&&!u.deck&&unitMover(u.kind)==='land').sort((a:any,b:any)=>gap(unit,a)-gap(unit,b)).slice(0,3);
 const post=saved.memories.p0?.v6?.general?.target;
 function road(from:any,to:any,speed:number){
  const points=groundSteeringRoute(s.map,from,to);
  const length=points.slice(1).reduce((sum:number,p:any,i:number)=>sum+gap(points[i],p),0);
  const endpoint=points.at(-1);
  return {centerStraightGap:gap(from,to),staticSteeringRoadLength:length,staticSteeringEndpoint:endpoint,endpointGapToGoal:gap(endpoint,to),observedSpeed:speed,sharedRouteTravelTicks:routeTravelTicks(s.map,from,to,'land',speed)??null,points};
 }
 rows.push({id:record.id,kind:record.kind,input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),inputTick:s.tick,inputPhase:saved.phase??'regular-before-think',unit:{x:unit.x,y:unit.y,hp:unit.hp,maxHp:unit.maxHp,speed:unit.speed,order:unit.order,healCooldown:unit.abilityCooldowns?.heal},
  toObservedGeneralPost:post?{point:post,...road(unit,post,unit.speed)}:null,
  nearestOwnMeleeByCenter:melee.map((friend:any)=>({id:friend.id,kind:friend.kind,hp:friend.hp,order:friend.order,declaredClaim:saved.memories.p0?.unitClaims?.[friend.id]??null,doctorToBody:road(unit,friend,unit.speed)})),
  nearestEnemyLandByCenter:foes.map((foe:any)=>({id:foe.id,kind:foe.kind,hp:foe.hp,order:foe.order,attackRange:foe.attackRange,foeToDoctor:road(foe,unit,foe.speed)})),
  fullWorldIdAll3memSerializedUnchanged:JSON.stringify(saved)===before});
 if(JSON.stringify(saved)!==before)throw Error('Static query changed complete input');
}
const result={classification:'Pure static shared terrain/steering queries on isolated copies of existing complete raw frames; no Game creation, restore, native stepping, planner, source/raw edits or orders.',head:diagnostic.head,rows,
 limits:['Centers/roads use each frame contemporaneous live doctor position; not the later fatal-hit position.','Nearest own melee is a visible body, not proof of available escort, cover or ownership.','Steering includes the registered static building occupancy and ends at its native reachable waypoint; endpoint gap is explicit, so no claim of reaching a building center.','sharedRouteTravelTicks is native static terrain/pace estimate at observed speed, not a guarantee of actual moving-body arrival, status, pushes, combat interception or safety.','General post can be distant and its route is a metric, not a retreat recommendation.','These closest pre-death full states generally are not the exact final hold-think input; no historical assignment target is invented.']};
writeFileSync(out+'/static-roads.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(rows.map(r=>({id:r.id,tick:r.inputTick,toPost:r.toObservedGeneralPost?.staticSteeringRoadLength,melee:r.nearestOwnMeleeByCenter.map((m:any)=>({id:m.id,straight:m.doctorToBody.centerStraightGap,road:m.doctorToBody.staticSteeringRoadLength,eta:m.doctorToBody.sharedRouteTravelTicks})),foes:r.nearestEnemyLandByCenter.map((f:any)=>({id:f.id,straight:f.foeToDoctor.centerStraightGap,road:f.foeToDoctor.staticSteeringRoadLength,eta:f.foeToDoctor.sharedRouteTravelTicks}))}))));
