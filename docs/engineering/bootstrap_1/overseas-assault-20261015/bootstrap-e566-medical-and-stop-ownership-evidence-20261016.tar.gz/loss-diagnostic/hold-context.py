import json,gzip,pathlib,math,collections,hashlib
SRC=pathlib.Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016');OUT=pathlib.Path('/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016')
D=json.load(open(OUT/'loss-diagnostic.json'));C=[json.loads(x)|{'line':i+1} for i,x in enumerate(open(SRC/'game-commands.jsonl'))];H=[json.loads(x)|{'line':i+1} for i,x in enumerate(open(SRC/'game-native-hits.jsonl'))]
frames=[]
for p in list((SRC/'game.frames').glob('*.json.gz'))+list((SRC/'game.events').glob('*.json.gz')):
 a=json.load(gzip.open(p,'rt'));frames.append({'file':str(p),'frame':a,'tick':a['snapshot']['tick'],'regular':p.parent.name=='game.frames'})
def gap(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def unit(u):return None if u is None else {k:u[k] for k in ['id','owner','kind','x','y','hp','maxHp','speed','attackDamage','attackRange','cooldown','abilityCooldowns','order','level','deck'] if k in u}
def preframe(t):return max((f for f in frames if f['tick']<=t),key=lambda f:(f['tick'],f['regular']))
def precontext(f,id):
 a=f['frame'];s=a['snapshot'];u=next((u for u in s['units'] if u['id']==id),None);mem=a['memories']['p0'] or {}
 if u is None:return {'unit':None,'unitClaim':mem.get('unitClaims',{}).get(id),'stateTick':f['tick'],'file':f['file']}
 own=[x for x in s['units'] if x['owner']=='p0' and x['hp']>0 and not x.get('deck') and x['id']!=id];en=[x for x in s['units'] if x['owner'] in ['p1','p2'] and x['hp']>0 and not x.get('deck')];front=[x for x in own if x['kind'] in ['footman','lancer','knight','mercenary','emberRavager','golem']]
 return {'unit':unit(u),'unitClaim':mem.get('unitClaims',{}).get(id),'stateTick':f['tick'],'file':f['file'],
 'ownPotentialFrontWithin480':[unit(x)|{'euclideanGap':gap(x,u)} for x in front if gap(x,u)<=480],
 'ownAllKindsWithin240':dict(collections.Counter(x['kind'] for x in own if gap(x,u)<=240)),
 'enemyWithin240':[unit(x)|{'euclideanGap':gap(x,u)} for x in en if gap(x,u)<=240],
 'coverCaution':'These are actual living bodies at recorded frame, with orders and straight-line separation. Usable road/attack interception/cover is not established; no route or native query was executed.',
 'scriptClaimCaution':'memory.unitClaims is a persistent job record, not a certificate of phase-level script unit claims. Actual accepted command scriptId is authoritative for last public issuer.'}
def refcmd(c):return {k:v for k,v in c.items() if k!='line'}|{'rawLine':c['line']}
result=[]
for u in D['units'][4:]:
 id=u['id'];death=u['death']['tick'];cs=[c for c in C if c['tick']<death and (c['command'].get('unitId')==id or id in c['command'].get('unitIds',[]))];holds=[c for c in cs if c['scriptId']=='medicalRecovery' and c['command']['type']=='holdPosition'];rows=[]
 for label,hold in [('first-ever-medical-hold',holds[0]),('final-medical-hold-before-death',holds[-1])]:
  prevcasts=[c for c in cs if c['index']<hold['index'] and c['command'].get('type')=='cast' and c['command'].get('ability')=='heal'];prevcast=prevcasts[-1] if prevcasts else None;f=preframe(hold['tick']);targetId=prevcast['command'].get('targetId') if prevcast else None
  hh=[h for h in H if h['target']==id and h['tick']<=hold['tick']]
  rows.append({'label':label,'acceptedHold':refcmd(hold),'priorCommandToThisHealer':refcmd(cs[cs.index(hold)-1]) if cs.index(hold) else None,
   'previousAcceptedHealCastFromThisHealer':refcmd(prevcast) if prevcast else None,
   'holdTargetIdentity':{'known':False,'reason':'holdPosition has no targetId; internal recovery assignment is not persisted. The prior explicit cast target below may be stale or dead and is not asserted to be this hold target.'},
   'completeFrameAtOrBeforeHold':{'file':f['file'],'tick':f['tick'],'lagTicks':hold['tick']-f['tick'],'sha256':hashlib.sha256(pathlib.Path(f['file']).read_bytes()).hexdigest(),'containsWorldNextIdAll3Memories':True},
   'healerAtAvailableFrame':precontext(f,id),'priorExplicitCastTargetAtAvailableFrame':precontext(f,targetId) if targetId else None,
   'priorExplicitTargetDeathTick':next((x['death']['tick'] for x in D['units'] if x['id']==targetId),None),
   'lastNativeHitAtOrBeforeHold':None if not hh else {k:hh[-1][k] for k in ['index','tick','line','attacker','attackerOwner','attackerKind','damage','hpBefore','hpAfter','targetAtObservation']},
   'nativeHitsBetweenHoldAndDeath':[{'index':h['index'],'tick':h['tick'],'line':h['line'],'attacker':h['attacker'],'damage':h['damage'],'hpBefore':h['hpBefore'],'hpAfter':h['hpAfter']} for h in H if h['target']==id and hold['tick']<h['tick']<=death]})
 result.append({'id':id,'holds':rows})
heal_cases=[]
for id,start,end,casters in [('unit-p0-priest-3733',16170,16182,['unit-p0-fieldMedic-1907','unit-p0-priest-5844']),('unit-p0-footman-1190',16185,16202,['unit-p0-priest-5844'])]:
 at=next(f for f in frames if f['tick']==end and not f['regular']);s=at['frame']['snapshot'];deathrow=next(u for u in D['units'] if u['id']==id);point=deathrow['fatalNativeHit']['targetAtObservation'];hs=[h for h in H if h['target']==id and start-15<=h['tick']<=end]
 heal_cases.append({'patient':id,'window':[start,end],'acceptedHealCasts':[refcmd(c) for c in C if start<=c['tick']<end and c['command'].get('ability')=='heal' and c['command'].get('targetId')==id],
  'observedNativeHits':[{'tick':h['tick'],'attacker':h['attacker'],'hpBefore':h['hpBefore'],'hpAfter':h['hpAfter'],'damage':h['damage'],'rawLine':h['line']} for h in hs],
  'casterAtPatientDeath':[unit(c)|{'euclideanGapToFatalPatientPose':gap(c,point)} for c in s['units'] if c['id'] in casters],
  'deathFrame':at['file'],'observation':'Accepted commands did not establish completed heal. Patient hit HP chain remains monotonically decreasing through fatal hit; no HP increase between these observed hits. No exact full state at every command tick is present; no reconstruction was run.'})
out={'sourceHead':D['head'],'classification':'Read-only context from existing raw files and source references. No new engine, planner, route query, restore, or tests.',
 'holdContexts':result,'deferredMedicalCases':heal_cases,
 'directHealEffectReferences':[{'sourceId':v['effect']['sourceId'],'actionTick':v['effect']['actionTick'],'effect':v['effect'],'witnesses':v['witnesses']} for u in D['units'][4:] for v in u['lastObservedActualHealEffectsAsCaster'] if v['effect']['actionTick']>=16000],
 'sourceReferences':[{'path':'src/ai/bootstrap_1/medical-recovery.ts','line':42,'observation':'CD>0 and target in spell range produces holdPosition; no enemy/threat input in this branch.'},{'path':'src/ai/bootstrap_1/medical-recovery.ts','line':55,'observation':'medicalRecovery declares claimsUnits for assigned healer.'},{'path':'src/ai/bootstrap_1/land-recovery.ts','line':97,'observation':'mainland recovering medics are excluded from patient rendezvous escaping.'},{'path':'src/shared/sim.ts','line':2473,'observation':'accepted cast may assign deferred cast order if target out of range.'},{'path':'src/shared/sim.ts','line':2558,'observation':'applyHeal raises HP and emits heal effect with source and coords, no targetId.'}],
 'staticRoadProposalOnly':{'notExecuted':True,'neededInputs':'One exact recorded complete snapshot, caster/patient/foe/front body IDs, registered building+obstacle bodies, unit mover and speed, selected point and current CD; use actual map from same snapshot, not another seed.',
 'functions':['groundSteeringRoute(snapshot.map, caster, point)','routeTravelTicks(snapshot.map, caster, point, land, caster.speed)','sameGround(snapshot.map, caster, candidate)'],
 'questions':['Can a potential front body be reached without traversing current melee bodies?','Does the detour preserve arrival before a useful heal and next THINK boundary?'],
 'limit':'Static road length/reachability does not prove future safety, interception, native movement crowd resolution, or actual healing; do not create Game/stepGame/restore for this metric.'}}
(OUT/'hold-context.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for row in result:
 print(row['id'])
 for x in row['holds']:
  hf=x['healerAtAvailableFrame'];th=x['lastNativeHitAtOrBeforeHold'];print(x['label'],x['acceptedHold']['tick'],'frame',hf['stateTick'],'hp',hf.get('unit',{}).get('hp'),'prevcast',x['previousAcceptedHealCastFromThisHealer'] and (x['previousAcceptedHealCastFromThisHealer']['tick'],x['previousAcceptedHealCastFromThisHealer']['command']['targetId']),'cover480',[(y['id'],round(y['euclideanGap'],1),y['hp']) for y in hf.get('ownPotentialFrontWithin480',[])],'lastHit',th and(th['tick'],th['attacker'],th['hpBefore'],th['hpAfter']))
print('medical HP chains',json.dumps(heal_cases,ensure_ascii=False))
