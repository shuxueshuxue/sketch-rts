import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/workspace/sketch-rts-bootstrap-combined-ordinary0-control',out='/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016';
const {createCanvas}=await import(pathToFileURL('/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js').href);
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const diagnosis=JSON.parse(readFileSync(out+'/loss-diagnostic.json','utf8'));
for(const id of ['unit-p0-fieldMedic-2255','unit-p0-priest-5844']){
 const record=diagnosis.units.find((u:any)=>u.id===id),input=record.nearestPreviousCompleteFrame.file;
 const {snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString()),unit=snapshot.units.find((u:any)=>u.id===id);
 const width=1100,height=950,zoom=1.1,view={x:unit.x-width/zoom/2,y:unit.y-height/zoom/2,width,height,zoom};
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');
 drawWorld({ctx:ctx as any,snapshot,view,now:snapshot.tick*50,selectedIds:new Set([id]),facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String}});
 ctx.fillStyle='rgba(0,0,0,.93)';ctx.fillRect(0,height-82,width,82);ctx.fillStyle='white';ctx.font='20px sans-serif';
 ctx.fillText(`actual e566 saved tick${snapshot.tick}; ${id}; ${unit.hp}/${unit.maxHp}HP; healCD${unit.abilityCooldowns?.heal??0}`,12,height-53);
 ctx.fillText(`order ${unit.order.type}; native static fresh facing; later raw death tick${record.death.tick}`,12,height-25);
 const path=out+'/native-loss-'+unit.kind+'-'+snapshot.tick+'.png';writeFileSync(path,canvas.toBuffer('image/png'));
 writeFileSync(path+'.json',JSON.stringify({classification:'Native static drawWorld of actual new0 full pre-death frame; not a native step, future forecast or historical animation reconstruction',source,head:diagnosis.head,input,unit:id,tick:snapshot.tick,observed:unit,view,rawLaterDeathTick:record.death.tick},null,2)+'\n');console.log(path);
}
