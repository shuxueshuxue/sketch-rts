import json,gzip,pathlib,hashlib,math,collections
SRC=pathlib.Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016'); OUT=pathlib.Path('/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016')
TRACK=['unit-p0-footman-1190','unit-p0-archer-1213','unit-p0-archer-1347','unit-p0-archer-2042','unit-p0-fieldMedic-1907','unit-p0-fieldMedic-2255','unit-p0-priest-3733','unit-p0-priest-5844']
def readlines(name):
 return [dict(json.loads(line),_line=i+1,_path=str(SRC/name)) for i,line in enumerate(open(SRC/name))]
D=readlines('game-native-deaths.jsonl');H=readlines('game-native-hits.jsonl');C=readlines('game-commands.jsonl');E=readlines('game-native-events.jsonl')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(v):return {'file':v['_path'],'line':v['_line']}
def cc(c):return {k:v for k,v in c.items() if not k.startswith('_')}|{'reference':ref(c)}
def unit(u):
 return None if u is None else {k:u[k] for k in ['id','owner','kind','x','y','hp','maxHp','speed','radius','attackRange','attackDamage','attackCooldown','cooldown','abilityCooldowns','kills','xp','level','order','orderQueue','veteranSkill','deck','expiresTick'] if k in u}
def hit(h):
 return {k:h.get(k) for k in ['index','tick','attacker','attackerOwner','attackerKind','target','damage','hpBefore','hpAfter','positiveToNonpositive','commandIndexPhase']}|{'targetAtObservation':unit(h.get('targetAtObservation')),'reference':ref(h)}
def gap(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
files=list((SRC/'game.frames').glob('*.json.gz'))+list((SRC/'game.events').glob('*.json.gz'))
frames=[];effects={}
for p in files:
 a=json.load(gzip.open(p,'rt'));s=a['snapshot'];frames.append({'file':p,'tick':s['tick'],'frame':a,'regular':p.parent.name=='game.frames'})
 for e in s['effects']:
  if e['type']=='heal' and e.get('owner')=='p0':
   row=effects.setdefault(e['id'],{'effect':e,'witnesses':[]})
   row['witnesses'].append({'file':str(p),'tick':s['tick']})
frames.sort(key=lambda f:(f['tick'],not f['regular']))
R=json.load(open(SRC/'game.json')); snapshot0=next(f['frame']['snapshot'] for f in frames if f['regular'] and f['tick']==0)
healCommands=[c for c in C if c['command'].get('type')=='cast' and c['command'].get('ability')=='heal']
for row in effects.values():
 ef=row['effect']; ts=ef.get('actionTick');candidate=[c for c in healCommands if c['command']['unitId']==ef.get('sourceId') and c['tick']==ts]
 row['sameSourceTickAcceptedCasts']=[cc(c) for c in candidate]
 # applyHeal effects omit targetId. Exactly matching public cast is stronger source/time
 # corroboration, still not direct target identity for deferred/autocast effects.
 row['targetIdentityCaution']='Native heal effect contains source and coordinates, but no targetId. A same-source/tick public cast is corroboration, not an unconditional target-ID certificate.'

def frameRef(f):
 a=f['frame'];return {'file':str(f['file']),'sha256':sha(f['file']),'tick':f['tick'],'phase':a.get('phase','regular-before-think-checkpoint'),'completeWorld':True,'nextId':a['nextId'],'memoryOwners':list(a['memories']),'restoreCaution':a.get('restoreCaution'),'containsNativeCertificate':False}
def surrounding(f,point):
 s=f['frame']['snapshot']; living=[u for u in s['units'] if u['hp']>0 and not u.get('deck')];out={}
 for r in [100,240,480,800]:
  near=[u for u in living if gap(u,point)<=r]
  out[str(r)]={'metric':'Euclidean center distance only; not road distance, reachability, threat, or projection',
   'own':dict(collections.Counter(u['kind'] for u in near if u['owner']=='p0')),
   'enemy':dict(collections.Counter(u['kind'] for u in near if u['owner'] in ['p1','p2'])),
   'neutral':dict(collections.Counter(u['kind'] for u in near if u['owner']=='neutral')),
   'ownHealers':[unit(u)|{'centerGap':gap(u,point)} for u in near if u['owner']=='p0' and u['kind'] in ['priest','fieldMedic']],
   'enemyUnits':[unit(u)|{'centerGap':gap(u,point)} for u in near if u['owner'] in ['p1','p2']] if r==240 else None,
   'attackingEnemyBuildings':[unit(b)|{'centerGap':gap(b,point)} for b in s['buildings'] if b['hp']>0 and b['owner'] in ['p1','p2'] and b.get('attackDamage',0)>0 and gap(b,point)<=r]}
 return out
units=[]
for id in TRACK:
 ds=[d for d in D if d.get('type')=='native-unit-terminal' and d.get('id')==id];assert len(ds)==1
 d=ds[0];t=d['tick'];body=d['lastNativeHit']['targetAtObservation'];lastcmd=[c for c in C if c['tick']<t and (c['command'].get('unitId')==id or id in c['command'].get('unitIds',[]))];hits=[h for h in H if h['target']==id and h['tick']<=t]
 pre=max((f for f in frames if f['tick']<t),key=lambda f:(f['tick'],f['regular']));regular=max((f for f in frames if f['regular'] and f['tick']<t),key=lambda f:f['tick']);at=next(f for f in frames if f['tick']==t and not f['regular']);birth=next((e for e in E if e['type']=='unit-birth-observed' and e.get('unit',{}).get('id')==id),None)
 scopedHeal=[c for c in healCommands if c['tick']<=t and (c['command'].get('unitId')==id or c['command'].get('targetId')==id)]
 observedOwnEffects=sorted([v for v in effects.values() if v['effect'].get('sourceId')==id and v['effect'].get('actionTick',0)<=t],key=lambda v:v['effect'].get('actionTick',0))
 nearbyEffects=sorted([v for v in effects.values() if t-480<=v['effect'].get('actionTick',0)<=t and gap(v['effect'],body)<=480],key=lambda v:v['effect']['actionTick'])
 memories={}
 for who in ['p0','p1','p2']:
  m=pre['frame']['memories'][who];memories[who]={'present':m is not None,'keys':list(m or {})}
 m=pre['frame']['memories']['p0'] or {};relevantMemory={'unitClaim':m.get('unitClaims',{}).get(id),'v6general':m.get('v6',{}).get('general'),'v6raid':m.get('v6',{}).get('raid'),'v6creep':m.get('v6',{}).get('creep'),'strategicPlan':m.get('strategicPlan')}
 row={'id':id,'kind':d['previous']['kind'],'group':'four veteran bodies at 10200' if id in TRACK[:4] else 'two original hired fieldMedic' if 'fieldMedic' in id else 'first two trained priest',
  'birth':None if birth is None else {'tick':birth['tick'],'unit':unit(birth['unit']),'reference':ref(birth)},
  'death':{'tick':t,'terminalClass':d['terminalClass'],'permanent':d['permanent'],'confirmation':d['confirmation'],'corpse':d['evidence']['corpse'],'previousNativeBoundary':unit(d['previous']),'reference':ref(d)},
  'fatalNativeHit':hit(hits[-1]),'allNativeHitCount':len(hits),'nativeHitsLast480':[hit(h) for h in hits if h['tick']>=t-480],
  'lastAcceptedPublicCommand':cc(lastcmd[-1]),'acceptedCommandsLast300':[cc(c) for c in lastcmd if c['tick']>=t-300],
  'nearestPreviousCompleteFrame':frameRef(pre),'nearestPreviousRegularCheckpoint':frameRef(regular),'deathEventCompleteFrame':frameRef(at),
  'unitInPreviousCompleteFrame':unit(next((u for u in pre['frame']['snapshot']['units'] if u['id']==id),None)),
  'allThreeMemoriesPresent':memories,'relevantP0MemoryAtPreviousFrame':relevantMemory,
  'surroundingAtDeathEvent':surrounding(at,body),'surroundingAtPreviousFrame':surrounding(pre,body),
  'acceptedHealCommandsAsCasterOrTargetLast600':[cc(c) for c in scopedHeal if c['tick']>=t-600],
  'acceptedHealCommandCountAsCasterOrTarget':len(scopedHeal),
  'observedActualHealEffectCountAsCaster':len(observedOwnEffects),'lastObservedActualHealEffectsAsCaster':observedOwnEffects[-3:],
  'observedActualNearbyHealEffectsLast480':nearbyEffects,
  'healEvidenceLimitation':'Existing native ledger has no heal callback. Effects are direct applyHeal witnesses (source/time/coordinates); accepted cast alone may only install deferred cast order. Effect stream here is a sparse union of saved regular/event frames, not complete healing history; no effect does not prove no healing.'}
 units.append(row)
firstPriests=[e for e in E if e['type']=='unit-birth-observed' and e.get('unit',{}).get('owner')=='p0' and e['unit']['kind']=='priest'][:2]
out={'classification':'Read-only diagnostic of fixed e566 natural true ordinary0. No game creation/restore/step, native simulation, tests, source edits, or new match. Existing raw evidence only.',
 'sourceRoot':'/workspace/sketch-rts-bootstrap-combined-ordinary0-control','head':R['head'],'rawPrefix':str(SRC/'game'),
 'result':R['result'],'developedSeedNotFreshGeneralization':True,'rulesVersion':R['setup']['rulesVersion'],
 'firstTwoTrainedPriests':[{'id':e['unit']['id'],'kind':e['unit']['kind'],'tick':e['tick'],'reference':ref(e)} for e in firstPriests],
 'inputFiles':[{'file':str(SRC/n),'sha256':sha(SRC/n)} for n in ['game.json','game-native-deaths.jsonl','game-native-hits.jsonl','game-native-events.jsonl','game-commands.jsonl']],
 'units':units,
 'candidate':{'name':'Threatened cooling healer movement ownership','status':'One reusable failure candidate supported by four observed deaths; not a tested fix or causal proof that all four were preventable.',
  'observation':'All four medical bodies die with hold order last issued by medicalRecovery. Cooling healer in heal range receives holdPosition from medical-recovery.ts regardless enemy threat; medicalRecovery claims healer, and mainland care excludes assigned medics from its patient escape commands.',
  'nextFocusedQuestion':'On these preserved complete states, can an enemy-threat-aware healer position preserve imminent usable healing while avoiding reachable melee, using existing native intent/route/threat primitives rather than changing HP thresholds or adding ownership fallback?',
  'scope':'No claim about all 56 permanent deaths. Archer1213 tower sortie is a distinct failure; three veteran bodies die later in base defense/retreat. No counterfactual, road queries, or strategy run performed.'}}
(OUT/'loss-diagnostic.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
small={'sourceHead':R['head'],'result':R['result'],'firstTwoTrainedPriests':out['firstTwoTrainedPriests'],'candidate':out['candidate'],'deaths':[]}
for u in units:
 s=u['surroundingAtDeathEvent']['240'];cmd=u['lastAcceptedPublicCommand'];small['deaths'].append({'id':u['id'],'tick':u['death']['tick'],'kind':u['kind'],'hpBefore':u['fatalNativeHit']['hpBefore'],'killer':u['fatalNativeHit']['attacker'],'lastPublicTick':cmd['tick'],'lastScriptId':cmd['scriptId'],'lastCommand':cmd['command'],'previousCompleteTick':u['nearestPreviousCompleteFrame']['tick'],'previousRegularTick':u['nearestPreviousRegularCheckpoint']['tick'],'near240Own':s['own'],'near240Enemy':s['enemy'],'healCDAtDeath':u['death']['previousNativeBoundary'].get('abilityCooldowns'),'lastActualHealEffectsAsCaster':[{'effectId':v['effect']['id'],'actionTick':v['effect'].get('actionTick'),'to':[v['effect']['x'],v['effect']['y']]} for v in u['lastObservedActualHealEffectsAsCaster']]})
(OUT/'summary.json').write_text(json.dumps(small,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(small,ensure_ascii=False,indent=2));print('detail bytes',(OUT/'loss-diagnostic.json').stat().st_size)
