import json,gzip,pathlib,math,collections
OUT=pathlib.Path('/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016');d=json.load(open(OUT/'loss-diagnostic.json'))
def dist(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def unit(u):return {k:u[k] for k in ['id','owner','kind','x','y','hp','maxHp','attackDamage','attackRange','cooldown','abilityCooldowns','order'] if k in u}
for u in d['units']:
 a=json.load(gzip.open(u['nearestPreviousCompleteFrame']['file'],'rt'));s=a['snapshot'];patient=next(x for x in s['units'] if x['id']==u['id']);result={}
 for r in [100,240,480,800]:
  near=[x for x in s['units'] if x['hp']>0 and not x.get('deck') and dist(x,patient)<=r]
  result[str(r)]={'own':dict(collections.Counter(x['kind'] for x in near if x['owner']=='p0')),'enemy':dict(collections.Counter(x['kind'] for x in near if x['owner'] in ['p1','p2'])),'neutral':dict(collections.Counter(x['kind'] for x in near if x['owner']=='neutral')),
   'ownNonWorkerBodies':[unit(x)|{'euclideanGap':dist(x,patient)} for x in near if x['owner']=='p0' and x['kind']!='worker'],
   'enemyBodies':[unit(x)|{'euclideanGap':dist(x,patient)} for x in near if x['owner'] in ['p1','p2']]}
 u['surroundingAtPreviousFrameActualUnitCenter']={'tick':s['tick'],'center':{'id':patient['id'],'x':patient['x'],'y':patient['y']},'rings':result,'caution':'Same-frame actual unit position; Euclidean only, not road/cover/reachability.'}
 u['surroundingAtDeathEventCenter']={'tick':u['death']['tick'],'x':u['fatalNativeHit']['targetAtObservation']['x'],'y':u['fatalNativeHit']['targetAtObservation']['y'],'meaning':'Native fatal hit target pose at same game tick, before later physics/corpse placement in that native step.'}
 u['surroundingAtPreviousFrameCenter']['comparisonPurpose']='Earlier world evaluated at later fatal point. Use surroundingAtPreviousFrameActualUnitCenter instead for same-frame patient cover; retained explicitly as spatial comparison only.'
(OUT/'loss-diagnostic.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(next(u['surroundingAtPreviousFrameActualUnitCenter'] for u in d['units'] if u['id']=='unit-p0-fieldMedic-2255'),ensure_ascii=False)[:2200])
