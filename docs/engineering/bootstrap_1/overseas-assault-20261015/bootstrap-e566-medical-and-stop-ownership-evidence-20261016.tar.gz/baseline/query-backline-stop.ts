import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='/workspace/sketch-rts-bootstrap-combined-ordinary0-control',out='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016';
const load=(p:string)=>import(pathToFileURL(root+'/'+p).href);
const {setBuildingBodies}=await load('src/shared/terrain.ts');
const {bootstrapScripts,bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts');
const {pruneAiPolicyMemory}=await load('src/ai/policy/claims.ts');
const {units,hostileCombatUnits}=await load('src/ai/policy/snapshot.ts');
const {isBacklineKind,casterScreenNeighbors}=await load('src/ai/policy/v6/backline.ts');
const {casterMeleeMicro,planBootstrapCasterScreen}=await load('src/ai/bootstrap_1/caster-screen.ts');
const {mercenaryControl,returningMercenaries}=await load('src/ai/bootstrap_1/mercenary-control.ts');
const {groundSteeringRoute,routeTravelTicks}=await load('src/shared/route-selection.ts');
const {aimingProfile}=await load('src/shared/aiming.ts');
const {UNIT_DEFS}=await load('src/shared/catalog.ts');
const query=await import(pathToFileURL(out+'/script-runner-query-export.ts').href);
const input=out+'/baseline13800-13964-prethink-13875.json.gz',bytes=readFileSync(input),saved=JSON.parse(gunzipSync(bytes).toString());
const before=JSON.stringify(saved),s=saved.snapshot,copy=(v:any)=>JSON.parse(JSON.stringify(v)),gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const context=bootstrapPolicyContext(s,'p0','v9_archer',{memory:copy(saved.memories.p0),teams:s.teams});
pruneAiPolicyMemory(s,'p0',context.memory);
const scripts=bootstrapScripts('v9_archer'),claims=query.readonlyUnitClaims(s,'p0',scripts,context);
const doctor=s.units.find((u:any)=>u.id==='unit-p0-fieldMedic-2255');
const front=units(s,'p0').filter((u:any)=>u.kind!=='worker'&&!isBacklineKind(u));
const screen=casterScreenNeighbors(front)(doctor),enemies=hostileCombatUnits(s,'p0',context.teams);
const on=enemies.filter((u:any)=>gap(doctor,u)<=230);
const micro=casterMeleeMicro(s,'p0',context)(doctor,on);
const commands=planBootstrapCasterScreen(s,'p0',context);
const stop=commands.find((c:any)=>c.type==='stop'&&c.unitIds.includes(doctor.id));
const filtered=stop?query.readonlyClaimFilter([stop],claims,'v6Backline'):[];
const returns=returningMercenaries(s,'p0',context);
const body=(u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,speed:u.speed,attackRange:u.attackRange,attackDamage:u.attackDamage,order:u.order,orderQueue:u.orderQueue,aim:u.aim,abilityCooldowns:u.abilityCooldowns,effects:u.effects,pushX:u.pushX,pushY:u.pushY});
const ret=returns.find((r:any)=>r.unit.id===doctor.id);
const points=ret?groundSteeringRoute(s.map,doctor,ret.home):[];
const result={classification:'Pure original-component/private-claim query on the actual13875 prethink copy; no Game/native steps/full planner/issued commands/source edits. Working context memory is separately copied/pruned; original full input remains unchanged.',input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),doctor:body(doctor),aimProfile:aimingProfile(UNIT_DEFS[doctor.kind]),frontScreenWithin700:screen.map(body),onWithinNativeAcquire230:on.map(body),
 meleeMicroReturned:micro??null,earlyUndefinedConditions:{casterRangeAtMost100:doctor.attackRange<=100,casterDamageNonpositive:doctor.attackDamage<=0,currentOrderCast:doctor.order.type==='cast',someFoeAtLeastCasterSpeed:on.some((u:any)=>u.speed>=doctor.speed)},
 actualStandBranchConditions:{frontCount:screen.length,lessThanExistingMinScreen3:screen.length<3,foesPresent:on.length>0,allFoesPermanentMelee100:on.every((u:any)=>u.attackRange<=100&&u.expiresTick===undefined)},
 mercenaryReturnRecognized:!!ret,mercenaryReturnHome:ret?{id:ret.home.id,x:ret.home.x,y:ret.home.y,hp:ret.home.hp,complete:ret.home.complete,straight:gap(doctor,ret.home),steeringRoadLength:points.slice(1).reduce((n:number,p:any,i:number)=>n+gap(points[i],p),0),endpoint:points.at(-1),endpointGap:gap(points.at(-1),ret.home),terrainTravelTicks:routeTravelTicks(s.map,doctor,ret.home,'land',doctor.speed),points}:null,
 mercenaryClaimsDoctor:mercenaryControl.claimsUnits(s,'p0',context).has(doctor.id),actualFirstPriorityClaimOwner:claims.get(doctor.id)??null,backlineRawStop:stop??null,originalClaimFilterOutput:filtered,
 stopPassesClaimFilterEvenThoughClaimedElsewhere:!!stop&&claims.get(doctor.id)!=='v6Backline'&&filtered.length===1,
 fullOriginalWorldNextIdAll3memSerializedUnchanged:JSON.stringify(saved)===before,
 limits:['This demonstrates existing script ownership/filter behavior, not that preserving a faster-pursued return walk saves the doctor.','A static route to an own hall is reachable geometry, not a safe corridor, usable escort, healing readiness or future survival.','All current speeds/statuses/push/aim are observations; no future charge, terrain detour or collision is forecast.','Native V9 stand-against-faster-permanent-melee policy is deliberately preserved here; no stand rule/health threshold/order changed.']};
if(JSON.stringify(saved)!==before)throw Error('Original copied full input mutated');
writeFileSync(out+'/backline-stop-query.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
