import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';
const source='/workspace/sketch-rts-bootstrap-combined-ordinary0-control';
const out='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016';
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const module=await import(pathToFileURL(out+'/medical-assignment-export.ts').href);
const original=await load('src/ai/bootstrap_1/medical-recovery.ts');
const {setBuildingBodies}=await load('src/shared/terrain.ts');
const {groundSteeringRoute,routeTravelTicks}=await load('src/shared/route-selection.ts');
const {abilityCooldown}=await load('src/shared/ability-cooldowns.ts');
const {UNIT_DEFS,ABILITY_DEFS,unitMover}=await load('src/shared/catalog.ts');
const copy=(v:any)=>JSON.parse(JSON.stringify(v)),gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
const actualPlans=readFileSync(out+'/baseline13800-13964-plans.jsonl','utf8').trim().split('\n').map(l=>JSON.parse(l));
const actualCommands=readFileSync(out+'/baseline13800-13964-commands.jsonl','utf8').trim().split('\n').map(l=>JSON.parse(l));
const affects=(c:any,id:string)=>c.unitId===id||c.unitIds?.includes(id);
const rows:any[]=[];
for(const tick of [13800,13860,13875,13935,13950]){
 const path=out+'/baseline13800-13964-prethink-'+tick+'.json.gz',bytes=readFileSync(path);
 const saved=JSON.parse(gunzipSync(bytes).toString()),before=JSON.stringify(saved),s=saved.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const patients=module.recoveryPatients(s,'p0'),pairs=module.readonlyAssignments(s,'p0',patients);
 const originalPlan=copy(original.planMedicalRecovery(s,'p0',original.recoveryPatients(s,'p0')));
 const exportedCopyPlan=copy(module.planMedicalRecovery(s,'p0',patients));
 if(!isDeepStrictEqual(originalPlan,exportedCopyPlan))throw Error('Private export changed public component output');
 const doctor=s.units.find((u:any)=>u.id==='unit-p0-fieldMedic-2255');
 const own=s.units.filter((u:any)=>u.owner==='p0'&&u.kind!=='worker'&&!u.deck&&unitMover(u.kind)==='land'&&u.attackDamage>0&&u.attackRange<=100&&!UNIT_DEFS[u.kind].abilities.some((a:string)=>ABILITY_DEFS[a].behavior==='heal')).sort((a:any,b:any)=>gap(doctor,a)-gap(doctor,b)).slice(0,3);
 const foes=s.units.filter((u:any)=>['p1','p2'].includes(u.owner)&&!u.deck&&unitMover(u.kind)==='land'&&u.attackDamage>0).sort((a:any,b:any)=>gap(doctor,a)-gap(doctor,b)).slice(0,3);
 const body=(u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,order:u.order,healCD:u.abilityCooldowns?.heal??null,speed:u.speed,attackRange:u.attackRange});
 function road(from:any,to:any){const points=groundSteeringRoute(s.map,from,to);return{straight:gap(from,to),steeringLength:points.slice(1).reduce((sum:number,p:any,i:number)=>sum+gap(points[i],p),0),endpoint:points.at(-1),endpointGap:gap(points.at(-1),to),staticTerrainTravelTicks:routeTravelTicks(s.map,from,to,'land',from.speed)??null,points};}
 const actualPlan=actualPlans.find(p=>p.tick===tick&&p.owner==='p0');
 rows.push({tick,input:path,inputSHA256:createHash('sha256').update(bytes).digest('hex'),phase:saved.phase,doctor:body(doctor),isCriticalRecoveryPatient:patients.some((u:any)=>u.id===doctor.id),patients:patients.map(body),
  medicalPairs:pairs.map(({healer,target,ability}:any)=>({healer:body(healer),target:body(target),ability,abilityCooldown:abilityCooldown(healer,ability),healRange:ABILITY_DEFS[ability].range,inHealRange:gap(healer,target)<=ABILITY_DEFS[ability].range,road:road(healer,target)})),
  originalComponentEqualsExportedCopy:true,componentPlan:originalPlan,
  actualPublicEntriesForDoctor:actualPlan.entries.filter((e:any)=>affects(e.command,doctor.id)),
  actualAcceptedForDoctor:actualCommands.filter((e:any)=>e.tick===tick&&affects(e.command,doctor.id)),
  nearestOwnMelee:own.map((u:any)=>({body:body(u),doctorToBody:road(doctor,u)})),nearestEnemyLand:foes.map((u:any)=>({body:body(u),foeToDoctor:road(u,doctor)})),
  fullWorldNextIdAll3memSerializedUnchanged:JSON.stringify(saved)===before});
 if(JSON.stringify(saved)!==before)throw Error('Readonly private query changed full input');
}
writeFileSync(out+'/prethink-private-assignment-query.json',JSON.stringify({classification:'Original private function exported from an external exact source copy; only relative imports redirected to actual original modules. Pure queries on captured actual prethink full-state copies, no Game, planner, native step or issued orders.',rows,limits:['Component output is checked against the original public function at each input; actual full-planner/public entries are retained separately.','Persistent jobclaims do not certify transient phase ownership.','Static roads and current threats do not prove safe movement or future survival; no changed strategy/counterfactual is run.']},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,doctor:r.doctor,critical:r.isCriticalRecoveryPatient,doctorsPairs:r.medicalPairs.filter((p:any)=>p.healer.id===r.doctor.id),actual:r.actualAcceptedForDoctor}))));
