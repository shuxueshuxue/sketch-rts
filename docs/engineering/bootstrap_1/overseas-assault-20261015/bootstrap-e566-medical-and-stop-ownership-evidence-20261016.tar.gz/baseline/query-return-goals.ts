import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const root='/workspace/sketch-rts-bootstrap-combined-ordinary0-control',out='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016';
const load=(p:string)=>import(pathToFileURL(root+'/'+p).href);
const {setBuildingBodies}=await load('src/shared/terrain.ts');
const {bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts');
const {armedFoes,safeLandTravelTicks,retreatLandRoad}=await load('src/ai/bootstrap_1/safe-land-route.ts');
const {groundSteeringRoute,routeTravelTicks}=await load('src/shared/route-selection.ts');
const {AUTO_ACQUIRE_RANGE}=await load('src/shared/sim.ts');
const {UNIT_DEFS}=await load('src/shared/catalog.ts');
const copy=(v:any)=>JSON.parse(JSON.stringify(v)),gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y),rows:any[]=[];
for(const tick of [13800,13860,13875]){
 const input=out+'/baseline13800-13964-prethink-'+tick+'.json.gz',saved=JSON.parse(gunzipSync(readFileSync(input)).toString()),before=JSON.stringify(saved),s=saved.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const unit=s.units.find((u:any)=>u.id==='unit-p0-fieldMedic-2255');
 const options=bootstrapPolicyContext(s,'p0','v9_archer',{memory:copy(saved.memories.p0),teams:s.teams}),foes=armedFoes(s,'p0',options);
 const halls=s.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall'&&b.complete);
 const goals=halls.map((home:any)=>{
  const points=groundSteeringRoute(s.map,unit,home),retreat=retreatLandRoad(s,unit,home,foes);
  return {home:{id:home.id,x:home.x,y:home.y,hp:home.hp},centerStraightGap:gap(unit,home),nativeSteeringRoadLength:points.slice(1).reduce((n:number,p:any,i:number)=>n+gap(points[i],p),0),endpoint:points.at(-1),endpointGapToHomeCenter:gap(points.at(-1),home),terrainTravelTicks:routeTravelTicks(s.map,unit,home,'land',unit.speed)??null,safeLandTravelTicks:safeLandTravelTicks(s,unit,home,foes)??null,retreatLandRoad:retreat??null,points};
 });
 const knight=s.units.find((u:any)=>u.id==='unit-p2-knight-2670');
 rows.push({tick,input,doctor:unit,knight,knightDefinedAbilities:UNIT_DEFS.knight.abilities,nativeAcquireRange:AUTO_ACQUIRE_RANGE,foeCount:foes.length,goals,fullWorldNextIdAll3memSerializedUnchanged:JSON.stringify(saved)===before});
 if(JSON.stringify(saved)!==before)throw Error('Readonly query changed input');
}
writeFileSync(out+'/return-goal-safety-query.json',JSON.stringify({classification:'Pure shared existing safeLandTravelTicks + retreatLandRoad + native steering queries on captured actual prethink copies; no Game, steps, planner, new scoring or orders.',rows,limits:['Existing metric admission is static known-threat route eligibility, not proof of actual future survival under a faster pursuer.','safeLandTravelTicks uses original terrain approach geometry; native steering and retreat road endpoints are retained separately including hall-center gaps.','No health/HP thresholds, owner or tactic altered; V9 stand-against-melee remains intact.']},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,goals:r.goals.map((g:any)=>({home:g.home,safeTicks:g.safeLandTravelTicks,retreatTicks:g.retreatLandRoad?.ticks??null,road:g.nativeSteeringRoadLength,endGap:g.endpointGapToHomeCenter}))}))));
