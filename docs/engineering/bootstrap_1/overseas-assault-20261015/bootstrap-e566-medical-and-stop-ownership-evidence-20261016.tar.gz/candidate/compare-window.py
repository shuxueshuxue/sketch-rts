import json, gzip
from pathlib import Path
out=Path(__file__).parent
base=Path('/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016/baseline13800-13964')
candidate=out/'candidate13800-13964'
def rows(prefix, suffix):
    return [json.loads(line) for line in open(str(prefix)+suffix) if line.strip()]
def frame(prefix, suffix):
    return json.load(gzip.open(str(prefix)+suffix, 'rt'))
def first_sequence(a,b):
    for i,(x,y) in enumerate(zip(a,b)):
        if x!=y:return {'position':i,'baseline':x,'candidate':y}
    if len(a)!=len(b):
        i=min(len(a),len(b));return {'position':i,'baseline':a[i] if i<len(a) else None,'candidate':b[i] if i<len(b) else None}
    return None
unit='unit-p0-fieldMedic-2255'
def hit(h):
    return {k:h[k] for k in ['tick','attacker','target','damage','hpBefore','hpAfter','positiveToNonpositive','commandIndex']}
commands={label:rows(prefix,'-commands.jsonl') for label,prefix in [('baseline',base),('candidate',candidate)]}
hits={label:rows(prefix,'-native-hits.jsonl') for label,prefix in [('baseline',base),('candidate',candidate)]}
observations=[]
for tick in [13800,13860,13875,13935,13950]:
    pair={}
    for label,prefix in [('baseline',base),('candidate',candidate)]:
        f=frame(prefix,'-prethink-'+str(tick)+'.json.gz');s=f['snapshot']
        pair[label]={'doctor':next((u for u in s['units'] if u['id']==unit),None),
                     'knight':next((u for u in s['units'] if u['id']=='unit-p2-knight-2670'),None),
                     'unitsLost':s['match']['stats']['unitsLost']}
    observations.append({'tick':tick,**pair})
report={'classification':'One original164tick same-e566 baseline replay vs one a90c0119 code-switch candidate from identical actualordinary0 13800 completeworld/id/3mem; no fresh0/no whole-game claim.',
'baseHead':'e5663c338f9c544a5e65a66a6ed278d35f74a8f4','candidateHead':out.joinpath('fixed-head.txt').read_text().strip(),
'mandatory':json.load(open(str(candidate)+'.json'))['mandatory'],'baselineClosed':json.load(open(str(base)+'.json'))['allChecksExact'],
'firstCommandSequenceDifference':first_sequence(commands['baseline'],commands['candidate']),
'firstNativeHitSequenceDifference':first_sequence(hits['baseline'],hits['candidate']),
'counts':{**{label+'Commands':len(values) for label,values in commands.items()},**{label+'NativeHits':len(values) for label,values in hits.items()}},
'doctor':{},'allDeathIds':{},'terminalNativeLoss':{},'prethinkObservations':observations,
'limits':['Stop now respects the existing owner/protocol. Preserving that original return walk does not make its destination safe.',
'Doctor dies22ticks earlier13942 vs13964; no complete-game benefit is established.',
'Original V9 stand policy and all healer thresholds, owners, abilities, return destination and native rules are unchanged.',
'The first command sequence difference is actual publiccommand; a later fatal death is not claimed as all future global outcomes.']}
for label,prefix in [('baseline',base),('candidate',candidate)]:
    report['doctor'][label+'Commands']=[x for x in commands[label] if unit in json.dumps(x['command'])]
    report['doctor'][label+'IncomingHits']=[hit(x) for x in hits[label] if x['target']==unit]
    report['doctor'][label+'OutgoingHits']=[hit(x) for x in hits[label] if x['attacker']==unit]
    deaths=rows(prefix,'-native-deaths.jsonl')
    report['doctor'][label+'Death']=[x for x in deaths if x['id']==unit]
    report['allDeathIds'][label]=sorted({x['id'] for x in deaths})
    report['terminalNativeLoss'][label]=frame(prefix,'-terminal.json.gz')['snapshot']['match']['stats']['unitsLost']
assert report['baselineClosed'] and all(report['mandatory'].values())
assert report['firstCommandSequenceDifference']['baseline']['tick']==13875
assert report['doctor']['baselineDeath'][0]['tick']==13964
assert report['doctor']['candidateDeath'][0]['tick']==13942
assert report['terminalNativeLoss']['baseline']==report['terminalNativeLoss']['candidate']
out.joinpath('comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'firstCommandDifference':report['firstCommandSequenceDifference'],'firstHitDifference':report['firstNativeHitSequenceDifference'],'counts':report['counts'],'baselineDeathTick':13964,'candidateDeathTick':13942,'nativeTerminalLossEqual':True}))
