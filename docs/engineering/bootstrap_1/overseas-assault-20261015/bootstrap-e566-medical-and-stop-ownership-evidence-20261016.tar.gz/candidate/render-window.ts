import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/workspace/sketch-rts-stop-ownership-e566-control',out='/workspace/.playtest/bootstrap-stop-ownership-e566-20261016';
const {createCanvas}=await import(pathToFileURL('/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js').href);
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const id='unit-p0-fieldMedic-2255';
for(const label of ['baseline','candidate']){
 const input=label==='baseline'?'/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016/baseline13800-13964-prethink-13935.json.gz':out+'/candidate13800-13964-prethink-13935.json.gz';
 const saved=JSON.parse(gunzipSync(readFileSync(input)).toString()),snapshot=saved.snapshot,unit=snapshot.units.find((u:any)=>u.id===id);
 const width=1100,height=950,zoom=1.25,view={x:2075-width/zoom/2,y:2470-height/zoom/2,width,height,zoom};
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');
 drawWorld({ctx:ctx as any,snapshot,view,now:snapshot.tick*50,selectedIds:new Set([id]),facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String}});
 ctx.fillStyle='rgba(0,0,0,.93)';ctx.fillRect(0,height-82,width,82);ctx.fillStyle='white';ctx.font='20px sans-serif';
 ctx.fillText(`${label} actual saved tick13935; fieldMedic2255 ${unit.hp}/${unit.maxHp}HP healCD${unit.abilityCooldowns.heal}`,12,height-53);
 ctx.fillText(`order=${unit.order.type}; native static fresh facing; NOT predicted future`,12,height-25);
 const path=out+'/native-'+label+'-13935.png';writeFileSync(path,canvas.toBuffer('image/png'));
 writeFileSync(path+'.json',JSON.stringify({classification:'Native static drawWorld of actual focused fullsnapshot, not a step or historical animation recreation',source,input,unit,tick:snapshot.tick,view},null,2)+'\n');console.log(path);
}
