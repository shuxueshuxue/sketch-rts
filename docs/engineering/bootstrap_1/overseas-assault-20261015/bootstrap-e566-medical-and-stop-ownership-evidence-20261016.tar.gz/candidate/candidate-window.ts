import {readFileSync,writeFileSync,appendFileSync,mkdirSync,existsSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';

const source='/workspace/sketch-rts-stop-ownership-e566-control';
const head=readFileSync(new URL('./fixed-head.txt',import.meta.url),'utf8').trim();
const original='/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game';
const out='/workspace/.playtest/bootstrap-stop-ownership-e566-20261016/candidate13800-13964';
const driver='/workspace/.playtest/prepared-combined-ordinary0-driver';
const start=13800,end=13964;
if(existsSync(out+'.json'))throw Error('Preserve existing replay');
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const lines=(p:string)=>readFileSync(p,'utf8').trim().split('\n').filter(Boolean).map(t=>JSON.parse(t));
const frameFile=(tick:number)=>original+'.frames/'+tick+'.json.gz';
const input=JSON.parse(gunzipSync(readFileSync(frameFile(start))).toString());
const expectedFile=original+'.events/13964-after-step-58.json.gz';
const expectedSaved=JSON.parse(gunzipSync(readFileSync(expectedFile)).toString());
const expected={snapshot:expectedSaved.snapshot,nextId:expectedSaved.nextId,memories:expectedSaved.memories,setup:expectedSaved.setup};
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
const moduleLoad=(p:string)=>import(pathToFileURL(driver+'/'+p).href);
const capsule=read(original+'-runtime-source.json');
function audit(){
 const actualHead=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim();
 const status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'});
 if(actualHead!==head||status)throw Error('Fixed source changed');
 const gitBlobs=new Map(execFileSync('git',['ls-tree','-r',head],{cwd:source,encoding:'utf8',maxBuffer:8*1024*1024}).trim().split('\n').map(line=>{const [meta,path]=line.split('\t');return [path,meta!.split(' ')[2]];}));
 const files=capsule.files.map((f:any)=>{const b=readFileSync(source+'/'+f.path),blob=createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
  if(blob!==gitBlobs.get(f.path))throw Error('Source differs from fixed git '+f.path);
  if(f.path!=='src/ai/policy/script-runner.ts'&&(blob!==f.expectedGitBlob||sha(b)!==f.sha256))throw Error('Unexpected source delta '+f.path);
  return {path:f.path,blob,sha256:sha(b)};});
 return {head:actualHead,status,files};
}
const pre=audit();writeFileSync(out+'-source-preflight.json',JSON.stringify(pre,null,2)+'\n');
const allCommands=lines(original+'-commands.jsonl'),allHits=lines(original+'-native-hits.jsonl');
const expectedCommands=allCommands.filter(e=>e.tick>=start&&e.tick<=end);
// Saved13800 is after its native step and before its next AI think. Native
// step hits at13800 are already in that input; public-command hits at13800
// follow the input and belong to this replay. Future streams beyond13964 are excluded.
const expectedHits=allHits.filter(e=>(e.tick>start||e.tick===start&&e.commandIndex!==null)&&e.tick<=end);
const commandOffset=expectedCommands[0].index,hitOffset=expectedHits[0].index;
if(expectedCommands[0]?.index!==commandOffset||expectedHits[0]?.index!==hitOffset)throw Error('Window index boundary not contiguous');
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const sim=await load('src/shared/sim.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts');
const {NativeTelemetry}=await moduleLoad('native-telemetry.ts');
const setup=input.setup,match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===1&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');
if(!match||!isDeepStrictEqual(copy(match.agents),setup.agents))throw Error('Changed setup');
const game=bootstrapGame(match);sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
const memories=createAiMemoryProvider(copy(input.memories)),owners=Object.keys(match.agents);
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
const restored=frame(),restoreExact=isDeepStrictEqual(restored,input);
writeFileSync(out+'-restore.json',JSON.stringify({input:frameFile(start),inputSHA256:sha(readFileSync(frameFile(start))),restoreWorld:isDeepStrictEqual(restored.snapshot,input.snapshot),restoreNextId:restored.nextId===input.nextId,restoreAll3mem:isDeepStrictEqual(restored.memories,input.memories),restoreSetup:isDeepStrictEqual(restored.setup,input.setup),restoreExact,commandOffset,hitOffset,expectedCommands:expectedCommands.length,expectedHits:expectedHits.length},null,2)+'\n');
if(!restoreExact)throw Error('Strict complete input restoration failed before replay');
const planner=await createBootstrapCommandPlanner(memories),frozenRoot=frozenPolicyRoot();
const frozenAudit=()=>Object.entries(capsule.frozenFiles).map(([p,expected])=>{const actual=sha(readFileSync(frozenRoot+'/'+p));if(actual!==expected)throw Error('Frozen changed '+p);return{path:p,sha256:actual};});
const frozenPre=frozenAudit();
if(frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision)throw Error('Changed frozen rules');
for(const suffix of ['commands','plans','native-hits','native-events','native-deaths','ship-losses'])writeFileSync(out+'-'+suffix+'.jsonl','',{flag:'wx'});
const actualCommands:any[]=[],actualHits:any[]=[],telemetry=new NativeTelemetry(game,(stream:string,e:any)=>{appendFileSync(out+'-'+stream+'.jsonl',JSON.stringify(e)+'\n');if(stream==='native-hits')actualHits.push(e);});
telemetry.hitIndex=hitOffset;
let commandCount=commandOffset,planCount=0,eventCount=0;const positions:any[]=[];
const observePositions=()=>{const snapshot=sim.snapshotGame(game);positions.push({tick:game.tick,doctor:snapshot.units.find((u:any)=>u.id==='unit-p0-fieldMedic-2255')??null,knight:snapshot.units.find((u:any)=>u.id==='unit-p2-knight-2670')??null,unitsLost:snapshot.match.stats.unitsLost});};observePositions();
mkdirSync(out+'.events');
const eventState=(stage:string,events:any[])=>{if(!events.some(e=>e.type==='native-building-terminal'||e.type==='native-unit-terminal'&&e.permanent))return;writeFileSync(out+'.events/'+game.tick+'-'+stage+'-'+(++eventCount)+'.json.gz',gzipSync(JSON.stringify({...frame(),phase:stage,commandIndex:telemetry.commandIndex})+'\n'));};
game.observer={hit:(a:any,t:any,d:number,h:number)=>telemetry.hit(a,t,d,h)};
const result=runGameLoop({...match,maxTicks:end,game,commandPlanner:(context:any)=>{telemetry.commandIndex=commandCount;
 if(context.owner==='p0'&&[13800,13860,13875,13935,13950].includes(game.tick))writeFileSync(out+'-prethink-'+game.tick+'.json.gz',gzipSync(JSON.stringify({...frame(),phase:'before-p0-first-owner-planning',commandIndex:commandCount})+'\n'));
 const entries=planner(context);planCount++;appendFileSync(out+'-plans.jsonl',JSON.stringify({tick:game.tick,owner:context.owner,entries})+'\n');return entries;}},{
 onCommand:(e:any)=>{telemetry.commandIndex=commandCount++;const row={index:telemetry.commandIndex,tick:game.tick,owner:e.owner,source:e.source,scriptId:e.scriptId,command:e.command};actualCommands.push(copy(row));appendFileSync(out+'-commands.jsonl',JSON.stringify(row)+'\n');const events=telemetry.observe('after-command');eventState('after-command',events);telemetry.commandIndex=commandCount;},
 beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();},
 onStep:()=>{observePositions();const events=telemetry.observe('after-step');eventState('after-step',events);},
});
const final=frame();writeFileSync(out+'-terminal.json.gz',gzipSync(JSON.stringify(final)+'\n'));
function first(a:any,b:any,path=''):any {
 if(typeof a!==typeof b||a===null!== (b===null))return {path,actual:a,expected:b};
 if(a&&typeof a==='object'){
  if(Array.isArray(a)!==Array.isArray(b))return {path,actual:a,expected:b};
  if(Array.isArray(a)){if(a.length!==b.length)return {path:path+'/length',actual:a.length,expected:b.length};for(let i=0;i<a.length;i++){const d=first(a[i],b[i],path+'/'+i);if(d)return d;}}
  else for(const key of new Set([...Object.keys(a),...Object.keys(b)])){if(!(key in a)||!(key in b))return {path:path+'/'+key,actual:a[key],expected:b[key],missingActual:!(key in a),missingExpected:!(key in b)};const d=first(a[key],b[key],path+'/'+key);if(d)return d;}
 }else if(a!==b)return {path,actual:a,expected:b};return null;
}
const post=audit(),frozenPost=frozenAudit();
const checks={restoreExact,terminalWorldExact:isDeepStrictEqual(final.snapshot,expected.snapshot),terminalNextIdExact:final.nextId===expected.nextId,terminalAll3memExact:isDeepStrictEqual(final.memories,expected.memories),terminalSetupExact:isDeepStrictEqual(final.setup,expected.setup),commandsExact:isDeepStrictEqual(actualCommands,expectedCommands),hitsExact:isDeepStrictEqual(actualHits,expectedHits),sourceExact:isDeepStrictEqual(pre,post),frozenExact:isDeepStrictEqual(frozenPre,frozenPost)};
const mandatory={restoreExact,sourceExact:checks.sourceExact,frozenExact:checks.frozenExact};writeFileSync(out+'-positions.json',JSON.stringify(positions)+'\n');
const report={classification:'Authorized164tick code-switch candidate from actuale566 ordinary0 complete13800 world/id/all3mem input; ONLY current strategy runner stop ownership/conflict/reservation changed. Full3AI/normal frozen opponents. Different output is expected; not ordinary0, full match or survival proof beyond13964.',baselineHead:'e5663c338f9c544a5e65a66a6ed278d35f74a8f4',mandatory,allMandatoryExact:Object.values(mandatory).every(Boolean),source,head,input:frameFile(start),expected:expectedFile,result:{tick:game.tick,winner:game.match.winner,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs},checks,allChecksExact:Object.values(checks).every(Boolean),counts:{actualCommands:actualCommands.length,expectedCommands:expectedCommands.length,actualHits:actualHits.length,expectedHits:expectedHits.length,plans:planCount,sourceFiles:post.files.length,frozenFiles:frozenPost.length},firstWorldDifference:first(final.snapshot,expected.snapshot),firstMemoryDifference:first(final.memories,expected.memories),firstCommandDifference:first(actualCommands,expectedCommands),firstHitDifference:first(actualHits,expectedHits),telemetry:telemetry.summary()};
writeFileSync(out+'-source-postflight.json',JSON.stringify({source:post,frozenPre,frozenPost},null,2)+'\n');
writeFileSync(out+'.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
if(!report.allMandatoryExact)process.exitCode=1;
