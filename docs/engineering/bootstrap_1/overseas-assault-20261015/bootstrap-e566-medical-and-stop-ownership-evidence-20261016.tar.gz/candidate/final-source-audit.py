import hashlib,json,subprocess
from pathlib import Path
out=Path(__file__).parent
raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game-runtime-source.json')
cap=json.loads(raw.read_text())
heads={'base':'e5663c338f9c544a5e65a66a6ed278d35f74a8f4','candidate':out.joinpath('fixed-head.txt').read_text().strip()}
roots={'base':Path('/workspace/sketch-rts-bootstrap-combined-ordinary0-control'),'candidate':Path('/workspace/sketch-rts-stop-ownership-e566-control')}
result={}
for label,root in roots.items():
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==heads[label]
    status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True);assert not status
    blobs={line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in subprocess.check_output(['git','ls-tree','-r',head],cwd=root,text=True).splitlines()}
    files=[]
    for row in cap['files']:
        path=row['path'];b=root.joinpath(path).read_bytes();sha=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        assert blob==blobs[path]
        if label=='base' or path!='src/ai/policy/script-runner.ts':assert sha==row['sha256'] and blob==row['expectedGitBlob']
        files.append({'path':path,'sha256':sha,'gitBlob':blob})
    extra=[]
    if label=='candidate':
        path='src/ai/policy/script-runner-stop.test.ts';b=root.joinpath(path).read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert blob==blobs[path]
        extra.append({'path':path,'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':blob})
        changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',head],cwd=root,text=True).splitlines()
        assert sorted(changed)==['src/ai/policy/script-runner-stop.test.ts','src/ai/policy/script-runner.ts']
    result[label]={'root':str(root),'head':head,'status':status,'inheritedCapsuleFiles':len(files),'extraFiles':len(extra),'files':files+extra}
result['originalRuntimeCapsule']={'file':str(raw),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
result['classification']='Currentpostflight1462 inherited files per base/current plus newcandidate test, everylive byte exact respective fixedcommit; original runtime/frozen capsule untouched. Native candidate window itself separately checks497 frozenfiles beforeafter.'
out.joinpath('final-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{q:v[q] for q in ['head','inheritedCapsuleFiles','extraFiles']} for k,v in result.items() if k in roots}))
