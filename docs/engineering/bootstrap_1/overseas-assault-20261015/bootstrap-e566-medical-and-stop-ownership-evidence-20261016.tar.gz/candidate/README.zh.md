# e566 真实损失诊断与 stop 所有权最小候选

本包连接实际 e566 普通0胜局的只读损失调查、唯一 13800→13964 原源闭合重放，以及同一完整输入的 a90c0119 换代码短窗。候选没有救下医师：2255 在13942阵亡，比原13964早22tick。它继续原北厅路线，13918额外受到 golem2491 的39伤害，同时失去原地反击的三次各4伤输出。窗口两边都仅新增一名永久死者2255；这不构成完整比赛或泛化改进。

固定候选 `a90c0119d7166baad1c9222781baab107deedbcb`，独立分支 `codex/bootstrap-stop-ownership-20261016`，控制树 `/workspace/sketch-rts-stop-ownership-e566-control`。基线 `e5663c338f9c544a5e65a66a6ed278d35f74a8f4` 与原始source/driver/raw从未被本任务修改。唯一生产变更为 `src/ai/policy/script-runner.ts` 三处既有unitIds处理增加stop：他人claim过滤、既有命令冲突过滤、已发命令reservation。没有改变backline战术、医疗阈值、瞬时施法/装备/冲锋区别、返回地点、规则或冻结敌。

25项相关单worker测试通过（原15、新10），随后一次tsc通过。`query-actual13875.json` 核对真实完整p0 pipeline：原计划逐值等于原记录；候选仅去掉2255那条越权stop，原始world/id/3memory输入不变。新增tests覆盖混合ids、自有claim、首stop挡后move/attack/stop、先move挡后stop、boarding owner、显式bypass不绕claim，以及instant heal/装备与charge的既有区别。独立review仅只读，不另开模拟。

## 真实原局与归属

原普通0：p0 Grove/v9_archer、physicalside1、factory pineshade、生成ladder4608²，seed `bootstrap_1-unseen-archer-v8-v8-20261015-01`，对正常 frozenv8 Ember+Grove两敌。名字含unseen但此例已经开发，不作新holdout。三方正常500金/3已用/8人口、规则2、已验证冻结184 manifest。原真正0自然43714 p0胜、56永久死亡；终局敌0单位0建筑。其完整独立证据包为 `bootstrap-combined-e566-terminal-audit-20261016/complete-e566-ordinary0-evidence.tar.gz`，SHA256 `585c209b4ec89e7ad80563c16ea0820723359b1397fcd6f06208615d532348ee`。该成绩始终归e566真正0；本包candidate只是164tick换代码续跑。

7905/1079/1322 是另一个 Ember/v9_summoner greystonePass 案例。不能写成此archer局10200跳过同局7905影响；已封勘误保留在原普通0证据包。本任务没有补做召唤整局或骑士整局。

## 损失调查与时钟

`loss-diagnostic/` 原子代理部分仅从原始事件/命令/完整档取证，随后父代理增加既有原生道路纯查询和native静态drawWorld图。没有用图预测未来，也未把直距当路程。原字段 surroundingAtPreviousFrame 曾以稍后致死点为中心，已明确标注并另加 ActualUnitCenter 同帧版本，不能混读。

原两名雇佣治疗单位是fieldMedic，不是priest：2255(出生8610/死13964)、1907(7680/16450)。首两名实际训练priest为3733(10565/16182)、5844(12800/16424)。10200仍在场老兵：archer1213死11692、footman1190死16202、archer2042死16253、archer1347死16917。四名医生临死前最后public命令都是medicalRecovery hold；这本身不证明hold导致死亡，更不能证明都可救。

2255在13860受到28伤后真实自疗至105HP。13875其105HP、healCD225、移动返回北厅，附近只有两名也在撤退的射手，不满足原3人screen；62速医师面对72速近身knight，既有meleeMicro有意返回undefined，v9 backline选择原地反击。此时mercenaryControl仍是第一claim owner，原runner却遗漏stop，允许v6Backline越权停它。13950才第一次成为原35%critical patient，私有assignments配自己但CD150，其余三医生真实道路距离924~2324，无法在240治疗范围内立刻救治。前一边界与致死hit的CD会相差tick，JSON保留各自时钟。

`baseline/` 中外部private-assignment/script-runner export是原文件的精确复制，仅重写导入和导出私有query；provenance记录字节/变换。真正固定源未改。copy上的完整planner与原public计划相等，查询不改变原world/id/3mem。不是猜上次cast目标就是本次患者。

## 完整短窗对照

原13800完整world/id/3mem严格恢复后，e566到实际13964事件：terminal world/id/3mem/setup、157条public commands、14条native hits全部逐值闭合；1462 inheritedsource与497 frozenfiles前后相同。

同一原13800完整输入换a90c0119：restore/world/id/3mem/setup严格相同；源固定/497冻结文件前后相同；164条命令、11次native hit。首个public command序列分叉在13875，去掉上述stop。候选继续危险北厅路线，13942原生致死hit、尸体和实际移除闭合。没有新0、没有改变任何敌的命令能力/人口/资源、没有只跑单方AI。终局world/3mem不再等于原局是预期行为差异，报告没有把这些false当restore失败。

`comparison.json` 是最终可复现衍生报告；`compare-window.py` 保存生成器。首次stdin衍生报告与存成脚本后的JSON字段顺序不同；旧序列化已按原SHA逐字节恢复到 comparison-prior-serialization.json，parsed JSON逐值相等。独立review明确复核最终SHA。任何raw/native/source未因这一序列化更正被改写。

原14次hit中，医师原地对knight造成三次各4伤；候选没有这些输出，增加golem2491的39伤，不能把更少总hit或双方相同死亡数称作收益。native-baseline/candidate-13935.png均由实际保存的完整快照原生drawWorld绘制；静态fresh facing，不是历史动画重建。

## 后续证据边界

现成safeLandTravelTicks/retreatLandRoad纯查询：13800原北厅两指标均undefined；南分厅有safe438/retreat419tick，主厅694/680。13860与13875已有当前近身危险，南侧两厅仍有可离开当前火圈的retreat road；北厅仍没有。所有路径均保留真实building-body终点（距厅心64），不能用回不到厅中心误判不可达。这些是静态已见威胁指标，不预测敌追击，不保证更改目的地可救；本候选完全未改return目标，下一项应分别核目的地/实际路线与现有owner接续。

继承原容器未提交修改的恢复缺口仍存在。三路线与官方地图/未见种子的普通单敌、六配对完整验收尚未完成。本包不改变这些要求，不将局部协议修复、护理存活或既有已开发胜局当最终bootstrap完成。
