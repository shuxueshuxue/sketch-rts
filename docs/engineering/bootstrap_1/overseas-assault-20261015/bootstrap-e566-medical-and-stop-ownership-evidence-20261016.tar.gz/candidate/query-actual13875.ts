import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { execFileSync } from 'node:child_process';
const out='/workspace/.playtest/bootstrap-stop-ownership-e566-20261016',base='/workspace/sketch-rts-bootstrap-combined-ordinary0-control',candidate='/workspace/sketch-rts-stop-ownership-e566-control';
const input='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016/baseline13800-13964-prethink-13875.json.gz';
const bytes=readFileSync(input),original=JSON.parse(gunzipSync(bytes).toString()),before=JSON.stringify(original);
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const actual=readFileSync('/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016/baseline13800-13964-plans.jsonl','utf8').trim().split('\n').map(t=>JSON.parse(t)).find(x=>x.tick===13875&&x.owner==='p0').entries;
const results:any[]=[];
for(const source of [base,candidate]){
 const {planAiOwnerCommandEntries,createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
 const saved=copy(original),worldBefore=JSON.stringify(saved.snapshot),memoryProvider=createAiMemoryProvider(copy(saved.memories));
 const entries=copy(planAiOwnerCommandEntries(saved.snapshot,{playerId:'p0',source:'external-agent',version:'v9_archer'},{teams:saved.snapshot.teams,memoryProvider}));
 results.push({source,head:execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),entries,afterMemory:copy(memoryProvider.get('p0')),worldUnchanged:JSON.stringify(saved.snapshot)===worldBefore,nextIdUnchanged:saved.nextId===original.nextId,otherOwnersUnchanged:['p1','p2'].every(o=>isDeepStrictEqual(copy(memoryProvider.get(o)),original.memories[o]))});
}
const old=results[0],changed=results[1],withoutStop=old.entries.filter((e:any)=>!(e.scriptId==='v6Backline'&&e.command.type==='stop'&&e.command.unitIds.includes('unit-p0-fieldMedic-2255')));
const report={classification:'Read-only fullp0 planner query on actual13875 prethink copy, original baseline replay independently closed. No Game/native/order issuance. Planner memory output intentionally separate; input fullworld/id/all3mem unchanged.',input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),checks:{inputUnchanged:JSON.stringify(original)===before,baselineMatchesActualPlan:isDeepStrictEqual(old.entries,actual),candidateOnlyRemovesClaimViolatingStop:isDeepStrictEqual(changed.entries,withoutStop),worldUnchanged:results.every(r=>r.worldUnchanged),otherOwnersUnchanged:results.every(r=>r.otherOwnersUnchanged)},results};
writeFileSync(out+'/query-actual13875.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({checks:report.checks,base:old.entries,candidate:changed.entries}));if(!Object.values(report.checks).every(Boolean))process.exitCode=1;
