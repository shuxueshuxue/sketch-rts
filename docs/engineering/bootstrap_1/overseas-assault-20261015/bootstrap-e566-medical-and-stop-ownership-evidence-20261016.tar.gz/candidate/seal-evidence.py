from pathlib import Path
import hashlib,json,tarfile,io
out=Path(__file__).parent
roots={'candidate':out,'baseline':Path('/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016'),'loss-diagnostic':Path('/workspace/.playtest/bootstrap-e566-loss-diagnostic-20261016')}
files=[]
for prefix,root in roots.items():
    for p in sorted(root.rglob('*')):
        if p.is_file():
            data=p.read_bytes();files.append({'name':prefix+'/'+str(p.relative_to(root)),'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
index={'classification':'Closed actuale566 lossdiagnosis + exactbaseline164tick + minimalstopcandidate164tick negative. No newordinary0/fullmatch or generalization claim.','payloadFiles':len(files),'payloadBytes':sum(f['bytes'] for f in files),'files':files}
indexbytes=(json.dumps(index,indent=2)+'\n').encode()
archive=Path('/workspace/.playtest/bootstrap-e566-medical-and-stop-ownership-evidence-20261016.tar.gz')
if archive.exists():raise RuntimeError('Preserve sealed existingarchive')
with tarfile.open(archive,'w:gz') as tar:
    info=tarfile.TarInfo('INDEX.json');info.size=len(indexbytes);tar.addfile(info,io.BytesIO(indexbytes))
    for row in files:tar.add(row['source'],arcname=row['name'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    stored=json.load(tar.extractfile('INDEX.json'));assert stored==index
    assert len(tar.getmembers())==len(files)+1
    for row in files:
        data=tar.extractfile(row['name']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
for row in files:
    data=Path(row['source']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
seal={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(files),'members':len(files)+1,'payloadBytes':index['payloadBytes'],'indexSHA256':hashlib.sha256(indexbytes).hexdigest(),'allPayloadHashesReadBackExact':True,'allOriginalPayloadFilesUnchangedDuringSeal':True,'base':'e5663c338f9c544a5e65a66a6ed278d35f74a8f4','candidate':out.joinpath('fixed-head.txt').read_text().strip(),'patchSHA256':hashlib.sha256(out.joinpath('stop-ownership.patch').read_bytes()).hexdigest()}
Path('/workspace/.playtest/bootstrap-e566-medical-and-stop-ownership-index-20261016.json').write_bytes(indexbytes)
Path('/workspace/.playtest/bootstrap-e566-medical-and-stop-ownership-seal-20261016.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal))
