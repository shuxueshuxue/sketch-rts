from pathlib import Path
import hashlib,json,subprocess,tarfile,io,datetime,argparse
p=argparse.ArgumentParser();p.add_argument('--worktree',required=True);p.add_argument('--prefix',required=True);p.add_argument('--expected-commit',default='97c7fca95e76da7e9767b87d7858138ecb3a18ec');a=p.parse_args()
w=Path(a.worktree);out=Path('/tmp/bootstrap-deployment-gate');prefix=a.prefix
def git(*args):return subprocess.check_output(['git','-C',str(w),*args])
head=git('rev-parse','HEAD').decode().strip();expected=git('rev-parse',a.expected_commit).decode().strip();assert head==expected,(head,expected)
files=[]
for folder in ['src/ai','src/shared','src/sdk']:files+=sorted(p for p in (w/folder).rglob('*') if p.is_file())
files += [w/p for p in ['scripts/bootstrap_1-planner.ts','package.json','package-lock.json','tsconfig.json','docs/engineering/bootstrap_1/frozen-policy.json']]
manifest=json.loads((w/'docs/engineering/bootstrap_1/frozen-policy.json').read_text());frozen=git('archive',manifest['revision'],*manifest['files'])
with tarfile.open(fileobj=io.BytesIO(frozen)) as t:
 for name,expected in manifest['files'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==expected,name
arc=out/(prefix+'-source.tar.gz')
with tarfile.open(arc,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(w)))
patch=git('diff','HEAD');(out/(prefix+'-source.patch')).write_bytes(patch)
s={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktree':str(w),'commit':head,'classification':'Exact expected HEAD plus captured worktree diff and new runtime source; no unrecorded changes authorized','rulesVersion':2,'frozenRevision':manifest['revision'],'frozenFileCount':len(manifest['files']),'frozenFilesVerified':True,'status':git('status','--short').decode(),'files':{str(f.relative_to(w)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'sourceArchive':str(arc),'sourceArchiveSha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'diffSha256':hashlib.sha256(patch).hexdigest()}
(out/(prefix+'-source.json')).write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:s[k] for k in ['commit','frozenFilesVerified','sourceArchiveSha256']}))
