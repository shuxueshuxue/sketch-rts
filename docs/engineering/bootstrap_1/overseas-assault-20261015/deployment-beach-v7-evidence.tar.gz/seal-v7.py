from pathlib import Path
import json,hashlib,tarfile,io
p=Path('/tmp/bootstrap-deployment-gate')
names=['deployment-beach-v7-README.zh.md','deployment-beach-v6-terminal-statistics.json','deployment-beach-v7-source.json','deployment-beach-v7-source.patch','deployment-beach-v7-source.tar.gz','deployment-beach-v7-final-source-verification.json','deployment-beach-v7-range-increment.patch','deployment-beach-v7-original88110-v6-equivalence.json','v7-range-test.log','v7-tsc.log','v7-range-tests-final.log','v7-tsc-final.log','complete-run.mts','source-capture.py','native-mortar-range.mts','native-mortar-range-query1.mts','native-mortar-range-query1.json','native-mortar-range.log','native-mortar-range-run.log','native-mortar-range-run2.log','native-coast-range.mts','native-coast-range-two-sea.log','render-native-range.mts','native-mortar-range-query15.png','native-mortar-range-hit62.png','deployment-beach-v6-input88110.json','deployment-beach-v6-original-crew.json','seal-v7.py']
files={n:p/n for n in names}
for prefix in ['deployment-beach-v7-original88110','native-mortar-range-warm15','native-mortar-range-v7']:
 for suffix in ['.json','.log','-source-postflight.json']:
  f=p/(prefix+suffix)
  if f.exists():files[f.name]=f
 for f in (p/(prefix+'.frames')).glob('*.json'):files[str(f.relative_to(p))]=f
index={'classification':'v7 one-line actual weapon range correction; v6 terminal-statistics supplement; separate rules2 synthetic native proof and fixed-source full both-AI continuation','files':{n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}}
arc=p/'deployment-beach-v7-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n)
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('INDEX.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(arc,'r:gz') as t:
 for n,h in index['files'].items():
  data=t.extractfile(n).read();assert len(data)==h['bytes'] and hashlib.sha256(data).hexdigest()==h['sha256'],n
result={'archive':str(arc),'bytes':arc.stat().st_size,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'payloadFiles':len(files),'verified':True};(p/'deployment-beach-v7-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
