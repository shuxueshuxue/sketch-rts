# v7 实际长炮射程与 v6 终局统计补充

旧 v6 的858件源码、两场换码续跑及21,838,434字节封包保持不变；旧包SHA256仍为67d4d2b734f76f2321dbed11c93fae06e7a322dac2321c0018a2e2fbef6b10a9。所有新控制及证据位于/tmp，未改root/main/naval/sim，未恢复原容器未提交修改。

## 精确终局（整局与原29人分开）

|v6接续|自然胜 tick|我方末单位/建筑/厅|敌方末单位/建筑/厅|整局unitsLost我/敌|本段unitsLost我/敌|原29阵亡|
|---|---:|---|---|---|---|---|
|原88110换码|91820|60 / 28 / 4厅均900HP|4 sparkArcher / 0 / 0|25 / 50|5 / 25|4 archer+1 lancer；24敌岛存活|
|89625换码|91945|57 / 28 / 4厅均900HP|4 sparkArcher / 0 / 0|28 / 50|8 / 25|7 archer+1 lancer；21敌岛存活|

双方总损失不等于原船队5/8损失。另中立方整局unitsLost均4；全部原始统计、兵种/建筑细分、原队死亡ID和致命命中、终帧SHA已列deployment-beach-v6-terminal-statistics.json。自然胜判定后仍有4敌弓手，不能声称已清除所有敌单位。

## 原生合法长炮反例

健康常规船安装武器会同步derived attackRange，不能靠手改该字段制造反例。初期武装cutter实验只证明264/312查询不同，未证明实际开火，不归属正例。真实89895旧泊位也未暴露此差异。

本反例为单独合成海岸原生实验，不是实际比赛：标准bombardShip与transport分处一条陆地两侧独立水体。初始scenario仅设损坏mortar和工人携带cannon；公开transferItem把cannon装到starboard0，原生派生unit.attackRange=312。公开repairShip实际花金币修回mortar，tick15时mortar durability15，金币500→485，working combatCapability.range=576，但aggregate attackRange仍312。没有手工赋值attackRange，双船hullFits和既有townHall地形合法性均验证通过。

真实native passenger落点(1076,628)在同一陆地；默认canReach=false，传实际576=true。旧v6 beach guards=[]。从这份tick15完整状态执行公开卸载并hold，原生于tick30（15tick窗内）向既有合法自有厅发射mortar；tick62爆炸同时伤登陆archer14HP（83→69）和厅72HP（900→828）。射击主要目标是厅，士兵受爆炸波及；不伪称默认reach下原生曾直接锁定该士兵，也不把15tick发射说成15tick命中。

v7仅在beach guard的canReach调用补传combatCapability.range，一行生产变更。相同原生场景与公开指令下v7正确列出bombardShip，原生世界、发射与命中不变。没有改规则、sim或武器统计。

## 验证及完整比赛作用

新完整fixture回归把tick15恢复后精确走15tick，world与nextId逐值等于原tick30，继续至62精确复现两次命中。10项针对性测试、tsc通过。初版测试缺少synthetic scenario-controlled victory运行flag（GameSnapshot不含该flag）会提前结束而循环不前，已终止该自有测试进程；最终明确恢复同flag并用固定步数和精确tick/world断言。早期类型/安装站位脚手架错误日志保留，不是原生比赛反证。

固定v7 860件源码（rulesVersion2、冻结revision d1ae110f2edd99f9c7d899ed61557891ab587639、184件验证）重新从原88110完整双方AI续跑到91820自然胜。该局终world、nextId、双方memories、全部公开指令、每tick原29人分组与旧v6该局完全相等；pre/postflight及最终源码校验通过。该对手本局无武装船，不能声称此一行在该局带来新的获胜增益。

增量补丁deployment-beach-v7-range-increment.patch为9110字节，SHA256 66016a9231f9fd0cb607184222a41ee763307fa0dbd6d596fcd55d2c9773b87d；仅v6 helper一行与新测试/fixture，反向check通过。先按增量整合v6，再按此补丁增量整合，不覆盖root最新naval或incoming/塔scope。旧v6和新v7分开归属。以上均不是true0普通开局或最终bootstrap验收；普通开局、三路线全对手与六配对、官方图及未见种子完整比赛要求继续保留。
