import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
import { createGame, restoreSnapshotIntoGame, snapshotGame, stepGame } from '../../src/shared/sim';
const saved=JSON.parse(gunzipSync(readFileSync('src/ai/bootstrap_1/fixtures/archer-return-neighbors.json.gz')).toString());
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const ids=['unit-p0-carrier-3510','unit-p0-transport-1046'],starts=ids.map(id=>{const u=game.units.find(u=>u.id===id)!;return{x:u.x,y:u.y,hp:u.hp};});
let restored:ReturnType<typeof createGame>|undefined;
for(let i=0;i<720;i++){
 if(i===120){const middle={snapshot:snapshotGame(game),nextId:game.nextId,memories:saved.memories};writeFileSync('.playtest/overseas-assault-20261015/neighbor-departure-proof-middle.json',JSON.stringify(middle));restored=createGame('bareDuel');restoreSnapshotIntoGame(restored,JSON.parse(JSON.stringify(middle.snapshot)),middle.nextId);}
 stepGame(game);if(restored)stepGame(restored);
 if(i%60===59)console.log(JSON.stringify({tick:game.tick,ships:ids.map((id,index)=>{const u=game.units.find(u=>u.id===id)!;return{id,x:u.x,y:u.y,hp:u.hp,travel:Math.hypot(u.x-starts[index]!.x,u.y-starts[index]!.y),route:u.sailing?.route&&{partial:u.sailing.route.partial,points:u.sailing.route.points.length}};})}));
}
assert.deepEqual(snapshotGame(restored!),snapshotGame(game));assert.equal(restored!.nextId,game.nextId);
writeFileSync('.playtest/overseas-assault-20261015/neighbor-departure-proof-end.json',JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:saved.memories}));
console.log(JSON.stringify({fullSnapshotAndNextIdMatch:true,classification:'focused native continuation; no AI replanning and no match victory attributed'}));
