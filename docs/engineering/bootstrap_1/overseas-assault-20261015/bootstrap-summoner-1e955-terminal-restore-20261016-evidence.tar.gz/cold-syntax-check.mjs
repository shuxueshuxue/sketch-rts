import { readFileSync, writeFileSync, appendFileSync, existsSync } from "node:fs";
import { gunzipSync, gzipSync } from "node:zlib";
import { dirname } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { isDeepStrictEqual } from "node:util";
import { NativeTelemetry } from "./native-telemetry";
const [source, head, prefix] = process.argv.slice(2);
if (!source || !head || !prefix) throw Error("ABS_SOURCE FULL_FIXED_HEAD ABS_NEW_PREFIX required");
const directory = dirname(prefix), sha = (b) => createHash("sha256").update(b).digest("hex");
const read = (name) => JSON.parse(readFileSync(directory + "/" + name, "utf8"));
const copy = (v) => JSON.parse(JSON.stringify(v));
const gate = read("driver-preflight.json");
for (const [name, expected2] of Object.entries(gate.files))
  if (sha(readFileSync(directory + "/" + name)) !== expected2) throw Error("Presealed driver/input changed " + name);
const cap = read("cold-runtime-source.json");
if (cap.root !== source || cap.head !== head || !cap.archiveReadbackVerified) throw Error("Wrong presealed runtime capsule");
for (const name of ["-restore.json", "-launch.json", "-result.json", "-final.json.gz", "-commands.jsonl", "-native-hits.jsonl"])
  if (existsSync(prefix + name)) throw Error("Preserve prior restore attempt " + name);
const load = (p) => import(pathToFileURL(source + "/" + p).href);
function audit() {
  const actualHead = execFileSync("git", ["rev-parse", "HEAD"], { cwd: source, encoding: "utf8" }).trim();
  const status = execFileSync("git", ["status", "--porcelain", "--untracked-files=all"], { cwd: source, encoding: "utf8" });
  if (actualHead !== head || status) throw Error("Source changed");
  const files = cap.files.map((entry) => {
    const bytes = readFileSync(source + "/" + entry.path), actual = sha(bytes);
    const blob = createHash("sha1").update(Buffer.from("blob " + bytes.length + "\0")).update(bytes).digest("hex");
    if (actual !== entry.sha256 || blob !== entry.expectedGitBlob) throw Error("Source byte mismatch " + entry.path);
    return { path: entry.path, sha256: actual, blob };
  });
  if (files.length !== 1470) throw Error("Wrong source inventory");
  return { head: actualHead, status, files };
}
const pre = audit();
writeFileSync(prefix + "-source-preflight.json", JSON.stringify(pre, null, 2) + "\n");
for (const [path, expected2] of [[cap.sourceArchive, cap.sourceArchiveSHA256], [cap.frozenArchive, cap.frozenArchiveSHA256]])
  if (sha(readFileSync(path)) !== expected2) throw Error("Source archive mismatch");
const input = JSON.parse(gunzipSync(readFileSync(directory + "/input82800.json.gz")).toString());
const expected = JSON.parse(gunzipSync(readFileSync(directory + "/reference-final.json.gz")).toString());
const setup = input.setup, start = 82800, end = 82963;
if (input.snapshot.tick !== start || expected.snapshot.tick !== end || !isDeepStrictEqual(setup, expected.setup)) throw Error("Wrong window");
const sim = await load("src/shared/sim.ts");
const { bootstrapGame, bootstrapMatches } = await load("src/ai/bootstrap_1/benchmark.ts");
const { createAiMemoryProvider } = await load("src/ai/planner-context.ts");
const { createBootstrapCommandPlanner, frozenPolicyManifest, frozenPolicyRoot } = await load("scripts/bootstrap_1-planner.ts");
const { runGameLoop } = await load("src/sdk/game-runner.ts");
const match = bootstrapMatches(setup.seed, [setup.map], Number.MAX_SAFE_INTEGER, setup.unseen).find((m) => m.subject === "v9_summoner" && m.side === 1 && m.agents.p0.race === "ember" && Object.values(m.agents).slice(1).map((a) => a.version).join("+") === "v5+v7");
if (!match || !isDeepStrictEqual(copy(match.agents), setup.agents) || setup.unseen !== false || setup.rulesVersion !== 2) throw Error("Setup changed");
const game = bootstrapGame(match);
sim.restoreSnapshotIntoGame(game, input.snapshot, input.nextId);
const owners = Object.keys(match.agents), memories = createAiMemoryProvider(copy(input.memories));
const frame = () => copy({ snapshot: sim.snapshotGame(game), nextId: game.nextId, memories: Object.fromEntries(owners.map((o) => [o, memories.get(o) ?? null])), setup });
const restored = frame();
const restoreChecks = {
  world: isDeepStrictEqual(restored.snapshot, input.snapshot),
  nextId: restored.nextId === input.nextId,
  all3mem: isDeepStrictEqual(restored.memories, input.memories),
  setup: isDeepStrictEqual(restored.setup, input.setup)
};
writeFileSync(prefix + "-restored-fullstate.json.gz", gzipSync(JSON.stringify(restored) + "\n"));
writeFileSync(prefix + "-restore.json", JSON.stringify({ inputSHA256: sha(readFileSync(directory + "/input82800.json.gz")), checks: restoreChecks }, null, 2) + "\n");
if (!Object.values(restoreChecks).every(Boolean)) throw Error("Strict restore failed before any native step; preserved without normalization relaxation");
const planner = await createBootstrapCommandPlanner(memories), frozenRoot = frozenPolicyRoot();
function frozenAudit() {
  const files = Object.entries(cap.frozenFiles).map(([path, expected2]) => {
    const actual = sha(readFileSync(frozenRoot + "/" + path));
    if (actual !== expected2) throw Error("Frozen byte mismatch " + path);
    return { path, sha256: actual };
  });
  if (files.length !== 497 || Object.keys(frozenPolicyManifest.files).length !== 184 || frozenPolicyManifest.rulesVersion !== 2 || frozenPolicyManifest.revision !== setup.frozenRevision) throw Error("Wrong frozen rules/manifest");
  for (const [path, expected2] of Object.entries(frozenPolicyManifest.files)) if (sha(readFileSync(frozenRoot + "/" + path)) !== expected2) throw Error("Frozen184 mismatch");
  return files;
}
const frozenPre = frozenAudit(), referenceCommands = read("reference-commands.json"), referenceHits = read("reference-hits.json");
let commandCount = referenceCommands[0].index, planCount = 0, steps = 0;
const commands = [], hits = [], plans = [];
for (const stream of ["commands", "plans", "native-hits", "native-events", "native-deaths", "ship-losses"]) writeFileSync(prefix + "-" + stream + ".jsonl", "", { flag: "wx" });
const telemetry = new NativeTelemetry(game, (stream, event) => {
  appendFileSync(prefix + "-" + stream + ".jsonl", JSON.stringify(event) + "\n");
  if (stream === "native-hits") hits.push(copy(event));
});
telemetry.hitIndex = referenceHits[0].index;
game.observer = { hit: (attacker, target, damage, hpBefore) => telemetry.hit(attacker, target, damage, hpBefore) };
writeFileSync(prefix + "-launch.json", JSON.stringify({
  pid: process.pid,
  startedAtUtc: (/* @__PURE__ */ new Date()).toISOString(),
  start,
  end,
  head,
  classification: "Unique163tick cold restoration closure, not another ordinary0 or additional win.",
  restoreChecks,
  sourceFiles: 1470,
  frozenFiles: 497,
  manifestFiles: 184
}, null, 2) + "\n");
console.log(JSON.stringify({ pid: process.pid, start, end, restoreChecks }));
let result;
try {
  result = runGameLoop({ ...match, maxTicks: end, game, commandPlanner: (context) => {
    telemetry.commandIndex = commandCount;
    const entries = planner(context);
    planCount++;
    const row = { tick: game.tick, owner: context.owner, entries };
    plans.push(copy(row));
    appendFileSync(prefix + "-plans.jsonl", JSON.stringify(row) + "\n");
    return entries;
  } }, {
    onCommand: (event) => {
      telemetry.commandIndex = commandCount++;
      const row = {
        index: telemetry.commandIndex,
        tick: game.tick,
        owner: event.owner,
        source: event.source,
        scriptId: event.scriptId,
        command: event.command,
        traceKind: "SDK public-command attempt; transient skips also call onCommand"
      };
      commands.push(copy(row));
      appendFileSync(prefix + "-commands.jsonl", JSON.stringify(row) + "\n");
      telemetry.observe("after-command");
      telemetry.commandIndex = commandCount;
    },
    beforeStep: () => {
      telemetry.commandIndex = null;
      telemetry.beforeStep();
    },
    onStep: () => {
      steps++;
      telemetry.observe("after-step");
    }
  });
} catch (error) {
  writeFileSync(prefix + "-interruption-fullstate.json.gz", gzipSync(JSON.stringify({ ...frame(), phase: "unexpected-interruption", commandIndex: telemetry.commandIndex }) + "\n"));
  writeFileSync(prefix + "-interruption.json", JSON.stringify({ tick: game.tick, steps, error: String(error) }, null, 2) + "\n");
  throw error;
}
const final = { ...frame(), checkpointStage: "natural-final" };
writeFileSync(prefix + "-final.json.gz", gzipSync(JSON.stringify(final) + "\n"));
const post = audit(), frozenPost = frozenAudit();
const firstDifference = (a, b) => {
  for (let i = 0; i < Math.max(a.length, b.length); i++) if (!isDeepStrictEqual(a[i], b[i])) return { position: i, actual: a[i] ?? null, reference: b[i] ?? null };
  return null;
};
const checks = {
  restoreExact: Object.values(restoreChecks).every(Boolean),
  source1470: isDeepStrictEqual(pre, post),
  frozen497: isDeepStrictEqual(frozenPre, frozenPost),
  commands: isDeepStrictEqual(commands, referenceCommands),
  hits: isDeepStrictEqual(hits, referenceHits),
  finalWorld: isDeepStrictEqual(final.snapshot, expected.snapshot),
  finalNextId: final.nextId === expected.nextId,
  final3mem: isDeepStrictEqual(final.memories, expected.memories),
  finalSetup: isDeepStrictEqual(final.setup, expected.setup),
  finalWholeSavedObject: isDeepStrictEqual(final, expected),
  actual163Steps: steps === 163
};
writeFileSync(prefix + "-source-postflight.json", JSON.stringify({ source: post, frozenPre, frozenPost }, null, 2) + "\n");
const report = {
  classification: "One cold normal3AI163tick replay of the sealed ordinary0 terminal. Not a second ordinary0 or extra win.",
  head,
  inputTick: start,
  result: { tick: game.tick, winner: game.match.winner },
  checks,
  allExact: Object.values(checks).every(Boolean),
  counts: { steps, commands: commands.length, hits: hits.length, plans: planCount, sourceFiles: 1470, frozenFiles: 497, manifestFiles: 184 },
  firstCommandDifference: firstDifference(commands, referenceCommands),
  firstHitDifference: firstDifference(hits, referenceHits),
  elapsedMs: result.elapsedMs,
  cpuMs: result.cpuMs,
  telemetry: telemetry.summary(),
  limits: "No source/strategy/manual command/seed change. Exact original window and input only, not generalized restore or gameplay acceptance."
};
writeFileSync(prefix + "-result.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report));
if (!report.allExact) process.exitCode = 1;
