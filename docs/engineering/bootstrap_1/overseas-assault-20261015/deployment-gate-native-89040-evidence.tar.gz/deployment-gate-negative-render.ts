import{createCanvas}from'@napi-rs/canvas';import{readFileSync,writeFileSync}from'node:fs';import{pathToFileURL}from'node:url';
const art='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',wd='/workspace/sketch-rts-deployment-gate-control',imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const[{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);installHeadlessCanvas();
for(const[label,frame]of [['portrait-first-ground-89041','first-ground-89041'],['portrait-decimated-89280','sample-89280']]){
 const {snapshot}=JSON.parse(readFileSync(`${art}/deployment-gate-native-discharge-89040.frames/${frame}.json`,'utf8'));const canvas=createCanvas(1500,1200);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view:{x:1600,y:5300,width:1500,height:1200,zoom:1},now:snapshot.tick*1000/20,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});writeFileSync(`${art}/deployment-gate-${label}.png`,canvas.toBuffer('image/png'));console.log(label);
}
