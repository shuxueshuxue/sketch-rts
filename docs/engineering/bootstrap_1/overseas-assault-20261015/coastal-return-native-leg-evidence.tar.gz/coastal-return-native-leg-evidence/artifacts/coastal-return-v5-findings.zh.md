# 返港有限原生 leg API 对齐：局部有效，未抵港

v4 原170400→175200→178800 完整正常AI及服务堵塞负结果保留在 coastal-return-evidence.tar.gz（SHA256 5f1d95bfae3c02354982c68bf44ad6dca93951bb6283487a6e198af90ff22656）。该结果不能改写为已到港或已修理。

v5 对齐共享唯一 API `planTransitLeg(snapshot,ship,goal,disks) -> {points,base}|undefined`。base 是同原生预算1024的普通航路，points 是可能的原生迎风替代；两者都必须安全且完整，partial 不算到达。coastal owner 分阶段记忆使用 base 与 wind points，保留 inputKey、真实到站后重验 continuation、发令前 fresh-first 复核。没有旧名转发、没有增加服务层、没有给命令塞私有 heading/route 字段。生产源码在独立 return-control，root 其它工作未覆盖。

源胶囊 coastal-return-v5-runtime-source.json（10生产全文、1333 hash），SHA256 94f2762e8df6a8c79f3d74d89f1d4be0ca1e045968589c559646b6da5b25fc79。5 项真实完整 fixture 回归与 tsc 通过。正常全AI从原170400完整world/nextId/双方memory运行到171600，恢复三项全等、运行后1333 hash全部相同，没过滤或注入实际命令。

171375实际到首mark(5696,6336)；171420公开move到(6080,6080)；171600船在(5757.66807964361,6305.735145952177)，28HP，弩车200HP，正在执行第二段。与v4实际171375/171420完整世界和nextId逐值相等；171420策略记忆因stage缓存base/direct API差异不同，不能写全部memory等价。

这验证新API在所记录真实航段可执行，不证明完整返港、修理、全场少损或胜利。已证178800工程师接驳物理通道问题继续由独立原生/通道审查处理，未用ordinary局部让路候选冒充coastal已证解。完整比赛/泛化验收、三条路线全部要求、规则2正常冻结对手保持不变；原容器未提交修改恢复缺口保持不变。

最新增量：coastal-return-v5-owner-incremental.patch，只含memory一字段、naval HURT owner/优先级/budget及新coastal-return.ts。依赖共享helper27dc306d3565a1fc34fe9db8b01d8596b6d302d96a82eca8771e522306abc994与原生wind机械提取两文件；不能把整个4ab naval覆盖当前root。
