import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
const source = process.argv[2]!, out = process.argv[3]!;
const imp = (p: string) => import(pathToFileURL(source + '/' + p).href);
const [{ bootstrapPolicyContext }, { assaultExpedition }, { sameGround, setBuildingBodies },
  { combatCapability }, { effectiveCombatRating, structureRating }, { reviseAssaultBeaches }, { shipPassengers },
  { planAiOwnerCommandEntries }, { unitMover }] = await Promise.all([
  imp('src/ai/bootstrap_1/policy.ts'), imp('src/ai/policy/naval.ts'), imp('src/shared/terrain.ts'),
  imp('src/shared/combat-capabilities.ts'), imp('src/ai/policy/v6/strength.ts'), imp('src/ai/bootstrap_1/assault-beach.ts'),
  imp('src/shared/ship-geometry.ts'), imp('src/ai/planner-context.ts'), imp('src/shared/catalog.ts'),
]);
const rows: any[] = [];
for (const tick of [88110, 89145]) {
  const saved = JSON.parse(gunzipSync(readFileSync(source + `/src/ai/bootstrap_1/fixtures/assault-deployment-original-${tick}.json.gz`)).toString());
  const s = saved.snapshot, before = JSON.stringify(saved), options = bootstrapPolicyContext(s, 'p0', 'v9_archer', { teams: s.teams, memory: structuredClone(saved.memories.p0) });
  setBuildingBodies(s.map, [...s.buildings, ...(s.obstacles ?? [])]);
  const ferries = options.memory.naval.ferries, target = s.buildings.find((b: any) => b.id === ferries['unit-p0-carrier-3824'].targetId);
  const workerDefenders = s.units.filter((u: any) => u.owner === 'p1' && !u.deck && u.kind === 'worker' && sameGround(s.map, u, target) && combatCapability(s, u).armed);
  const boats = s.units.filter((u: any) => ['unit-p0-carrier-3510', 'unit-p0-carrier-3824'].includes(u.id));
  const actualCrew = boats.flatMap((u: any) => shipPassengers(s.units, u)).filter((u: any) => u.kind !== 'worker' && !u.expiresTick);
  const landed = s.units.filter((u: any) => u.owner === 'p0' && !u.deck && unitMover(u.kind) === 'land' && u.kind !== 'worker' && !u.expiresTick && sameGround(s.map, u, target));
  const result = assaultExpedition(s, 'p0', options, target), oldMissions = structuredClone(ferries);
  reviseAssaultBeaches(s, 'p0', options);
  const entries = planAiOwnerCommandEntries(s, { playerId: 'p0', version: 'v9_archer', memory: structuredClone(saved.memories.p0) }, { teams: s.teams });
  rows.push({ tick, target: target.id, result, boatIds: boats.map((u: any) => u.id), crewPower: actualCrew.reduce((n: number, u: any) => n + effectiveCombatRating(s, u), 0),
    landedPower: landed.reduce((n: number, u: any) => n + effectiveCombatRating(s, u), 0),
    workers: workerDefenders.map((u: any) => ({ id: u.id, hp: u.hp, maxHp: u.maxHp, dps: combatCapability(s, u).dps,
      physicalRating: structureRating({ hp: u.maxHp, attackDamage: combatCapability(s, u).dps, attackCooldown: 20 }) * Math.max(.1, u.hp / Math.max(1, u.maxHp)) })),
    beforeMissions: oldMissions, afterMissions: ferries, entries, worldAndInputMemoryUnchanged: JSON.stringify(saved) === before });
}
writeFileSync(out, JSON.stringify({ source, rows }, null, 2));
console.log(JSON.stringify(rows.map(r => ({ tick: r.tick, required: r.result.required, ready: r.result.ready, crewPower: r.crewPower,
  landedPower: r.landedPower, workers: r.workers, selected: r.afterMissions['unit-p0-carrier-3824'], commands: r.entries.filter((e: any) => e.scriptId === 'naval') }))));
