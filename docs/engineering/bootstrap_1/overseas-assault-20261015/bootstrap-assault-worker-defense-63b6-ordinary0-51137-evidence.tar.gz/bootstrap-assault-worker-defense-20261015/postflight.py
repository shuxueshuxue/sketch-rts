"""Read-only source/game evidence verification; run after the natural game closes."""
import datetime, gzip, hashlib, io, json, pathlib, subprocess, tarfile

directory = pathlib.Path(__file__).resolve().parent
cap = json.loads((directory/'candidate-source.json').read_text())
source = pathlib.Path(cap['sourceRoot'])
report = json.loads((directory/'ordinary0.json').read_text())
final = json.load(gzip.open(directory/'ordinary0-final.json.gz', 'rt'))
opening = json.loads((directory/'ordinary-opening.json').read_text())
old_opening = json.load(open('/tmp/bootstrap-root-3bdb-ordinary0-20261015/ordinary-opening.json'))
runtime = json.loads((directory/'ordinary-runtime-source.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()

def git(*args): return subprocess.check_output(['git', *args], cwd=source).decode().strip()
live_differences = [name for name, digest in cap['hashes'].items() if sha((source/name).read_bytes()) != digest]
runtime_differences = [name for name, digest in {**runtime['runtimeHashes'], **runtime['supportingDataHashes']}.items()
                       if sha((source/name).read_bytes()) != digest]
manifest_bytes = (source/'docs/engineering/bootstrap_1/frozen-policy.json').read_bytes()
manifest = json.loads(manifest_bytes)
frozen_bytes = subprocess.check_output(['git', 'archive', manifest['revision'], *manifest['files']], cwd=source)
with tarfile.open(fileobj=io.BytesIO(frozen_bytes)) as archive:
    frozen_differences = [name for name, digest in manifest['files'].items()
                          if sha(archive.extractfile(name).read()) != digest]
sources = {'head': git('rev-parse', 'HEAD'), 'gitStatus': git('status', '--porcelain'),
           'liveFiles': len(cap['hashes']), 'liveDifferences': live_differences,
           'runtimeAndDataFiles': len(runtime['runtimeHashes']) + len(runtime['supportingDataHashes']),
           'runtimeDifferences': runtime_differences, 'frozenFiles': len(manifest['files']),
           'frozenDifferences': frozen_differences, 'manifestSHA256': sha(manifest_bytes)}
assert sources['head'] == cap['head'] and not sources['gitStatus']
assert not live_differences and not runtime_differences and not frozen_differences
assert sha(manifest_bytes) == cap['manifestSHA256']

def read_lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]
streams = {'commands': read_lines(directory/'ordinary0-public-commands.jsonl'),
           'hits': read_lines(directory/'ordinary0-native-hits.jsonl'),
           'events': read_lines(directory/'ordinary0-native-events.jsonl')}
stream_equality = {name: report[name] == rows for name, rows in streams.items()}
assert all(stream_equality.values())
initial = json.loads((directory/'in-process-opening.json').read_text())
opening_equality = {name: initial[name] == old_opening[name] == opening[name]
                    for name in ['snapshot', 'nextId', 'memories']}
assert all(opening_equality.values())
checkpoints = []
for path in sorted((directory/'ordinary0.frames').glob('*.json.gz'), key=lambda p: p.name):
    stem = path.name.removesuffix('.json.gz')
    if not stem.isdigit(): continue
    value = json.load(gzip.open(path, 'rt'))
    assert value['snapshot']['tick'] == int(stem)
    assert set(value['memories']) == {'p0', 'p1'}
    checkpoints.append({'tick': int(stem), 'nextId': value['nextId'], 'sha256': sha(path.read_bytes())})
checkpoints.sort(key=lambda v: v['tick'])
assert checkpoints[0]['tick'] == 0 and checkpoints[-1]['tick'] == report['result']['tick']
assert final['snapshot']['tick'] == report['result']['tick']
assert json.load(gzip.open(directory/f'ordinary0.frames/{report["result"]["tick"]}.json.gz', 'rt')) == final

permanent = [event for event in streams['events'] if event['type'] == 'removed'
             and event['previous']['owner'] == 'p0' and 'expiresTick' not in event['previous']]
deaths = [{'tick': event['tick'], 'id': event['previous']['id'], 'kind': event['previous']['kind'],
           'lastNativeHit': event.get('lastNativeHit'),
           'lastHitWasLethal': (event.get('lastNativeHit') or {}).get('hpAfter', 1) <= 0}
          for event in permanent]
baseline_ids = ['unit-p0-worker-1', 'unit-p0-emberRavager-1080', 'unit-p0-emberRavager-1051',
                'unit-p0-emberRavager-1101', 'unit-p0-transport-1043']
baseline_survival = {}
for unit_id in baseline_ids:
    unit = next((u for u in final['snapshot']['units'] if u['id'] == unit_id), None)
    baseline_survival[unit_id] = {'final': unit, 'removalEvents': [d for d in deaths if d['id'] == unit_id]}
remaining = {owner: {'units': [u for u in final['snapshot']['units'] if u['owner'] == owner],
                     'buildings': [b for b in final['snapshot']['buildings'] if b['owner'] == owner]}
             for owner in ['p0', 'p1']}
result = {'classification': 'Postflight of one standard0 fixed63b6 ordinary match; no changed-code resume or manual world manipulation. '
                           'This verifies recorded facts and does not establish bootstrap milestone or generalization.',
          'verifiedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sources': sources,
          'normalOpeningFullEquality': opening_equality, 'allAppendOnlyStreamsEqualFinalReport': stream_equality,
          'completeCheckpoints': checkpoints, 'result': report['result'], 'runResult': report['runResult'],
          'permanentP0Removals': deaths, 'originalFirstWaveFiveIds': baseline_survival,
          'remainingOwners': remaining, 'finalNextId': final['nextId'],
          'finalMemorySHA256': {o: sha(json.dumps(m, sort_keys=True).encode()) for o, m in final['memories'].items()},
          'nativeCorpses': final['snapshot'].get('corpses')}
(directory/'postflight.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'result': report['result'], 'permanentP0Deaths': len(deaths), 'sourceFiles': sources['liveFiles'],
                  'runtimeFiles': sources['runtimeAndDataFiles'], 'frozenFiles': sources['frozenFiles'],
                  'streamEquality': stream_equality, 'remaining': {o: {k: len(v) for k, v in state.items()}
                                                               for o, state in remaining.items()}}, indent=2))
