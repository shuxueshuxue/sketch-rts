import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const { sameGround } = await import(pathToFileURL(cap.sourceRoot + '/src/shared/terrain.ts').href);
const report = JSON.parse(readFileSync(directory + '/ordinary0.json', 'utf8'));
const final = JSON.parse(gunzipSync(readFileSync(directory + '/ordinary0-final.json.gz')).toString());
const initialHome = report.initial.snapshot.buildings.find((b: any) => b.owner === 'p1' && b.kind === 'townHall');
const grouped = new Map<number, any[]>();
for (const e of report.events) if (e.type === 'first-post-step-disembark' && e.after.owner === 'p0'
  && e.after.kind !== 'worker' && e.after.expiresTick === undefined) {
  grouped.set(e.tick, [...(grouped.get(e.tick) ?? []), e]);
}
const landings = [];
for (const [tick, group] of grouped) {
  const path = directory + `/ordinary0.frames/${tick}-observed-disembark.json.gz`;
  if (!existsSync(path)) throw Error('Observed full landing frame missing');
  const frame = JSON.parse(gunzipSync(readFileSync(path)).toString());
  const matches = frame.snapshot.buildings.filter((b: any) => b.owner === 'p1'
    && group.some(e => sameGround(frame.snapshot.map, e.after, b)));
  const originalEnemyIsland = group.some(e => sameGround(frame.snapshot.map, e.after, initialHome));
  if (matches.length || originalEnemyIsland) landings.push({ tick, classification: 'First after-step observation, not an inferred public-command execution tick.',
    path, originalEnemyIsland, currentEnemyBuildingsOnIsland: matches.map((b: any) => b.id),
    units: group.map(e => ({ id: e.after.id, kind: e.after.kind, x: e.after.x, y: e.after.y, hp: e.after.hp, previousDeck: e.before.deck })) });
}
const removals = report.events.filter((e: any) => e.type === 'removed' && e.previous.owner === 'p0');
const corpses = final.snapshot.corpses.filter((c: any) => c.owner === 'p0');
const corpseIds = new Set(corpses.map((c: any) => c.unitId));
const sunkHullIdsByTick = new Map<number, Set<string>>();
for (const e of removals) if (e.previous.sailing && e.lastNativeHit?.hpAfter <= 0) {
  const set = sunkHullIdsByTick.get(e.tick) ?? new Set(); set.add(e.previous.id); sunkHullIdsByTick.set(e.tick, set);
}
const missingCorpseOnSunkHull = removals.filter((e: any) => !corpseIds.has(e.previous.id)
  && e.previous.deck && sunkHullIdsByTick.get(e.tick)?.has(e.previous.deck.shipId));
const permanentCorpses = corpses.filter((c: any) => c.kind !== 'spirit');
const temporaryCorpses = corpses.filter((c: any) => c.kind === 'spirit');
const reconciledLost = corpses.length + missingCorpseOnSunkHull.length;
const sinkCases = missingCorpseOnSunkHull.map((e: any) => ({ tick: e.tick, id: e.previous.id, kind: e.previous.kind,
  hpBeforeRemoval: e.previous.hp, expiresTick: e.previous.expiresTick, previousDeck: e.previous.deck,
  lastNativeHit: e.lastNativeHit,
  hullRemoval: removals.find((r: any) => r.tick === e.tick && r.previous.id === e.previous.deck.shipId) }));
const summary = { classification: 'Read-only exact native event and complete same-tick landing-frame audit of the one finished fixed63b6 ordinary0.',
  source: cap.sourceRoot, commit: cap.head, tick: report.result.tick, winner: report.result.winner,
  enemyIslandPermanentLandings: landings, lastBuildingNativeHits: report.hits.filter((h: any) => h.target === initialHome.id).slice(-10),
  nativeLossReconciliation: { recordedP0UnitsLost: report.result.stats.unitsLost.p0, permanentCorpses: permanentCorpses.length,
    temporarySpiritCorpses: temporaryCorpses.length, corpsesTotal: corpses.length, missingCorpseOnSunkHull: sinkCases,
    reconciledLost, equalsNativeUnitsLost: reconciledLost === report.result.stats.unitsLost.p0 },
  remainingP1: { units: final.snapshot.units.filter((u: any) => u.owner === 'p1'), buildings: final.snapshot.buildings.filter((b: any) => b.owner === 'p1') } };
writeFileSync(directory + '/native-summary.json', JSON.stringify(summary, null, 2));
console.log(JSON.stringify({ landings, loss: summary.nativeLossReconciliation, lastHit: summary.lastBuildingNativeHits.at(-1) }));
if (!summary.nativeLossReconciliation.equalsNativeUnitsLost) throw Error('Native loss reconciliation incomplete');
