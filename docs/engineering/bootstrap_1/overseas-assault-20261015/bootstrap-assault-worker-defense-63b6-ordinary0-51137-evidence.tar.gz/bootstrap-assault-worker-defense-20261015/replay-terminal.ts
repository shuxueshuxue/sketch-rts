import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const original = JSON.parse(readFileSync(directory + '/ordinary0.json', 'utf8'));
const end = original.result.tick, from = Math.floor((end - 1) / 600) * 600;
const input = JSON.parse(gunzipSync(readFileSync(directory + `/ordinary0.frames/${from}.json.gz`)).toString());
const expected = JSON.parse(gunzipSync(readFileSync(directory + '/ordinary0-final.json.gz')).toString());
const imp = (p: string) => import(pathToFileURL(cap.sourceRoot + '/' + p).href);
const [{ bootstrapGame, bootstrapMatches }, { restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner }, { runAiGameLoop }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts'),
]);
const setup = original.setup;
const match = bootstrapMatches(setup.seed, [setup.map], end, setup.unseen).find((m: any) => m.subject === setup.agents.p0.version
  && m.side === setup.side && m.agents.p0.race === setup.agents.p0.race
  && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v8');
if (!match) throw Error('Actual match absent');
const game = bootstrapGame(match), memories = createAiMemoryProvider();
restoreSnapshotIntoGame(game, input.snapshot, input.nextId);
for (const [owner, memory] of Object.entries(input.memories)) memories.set(owner, structuredClone(memory));
const json = (v: any) => JSON.parse(JSON.stringify(v));
const full = () => json({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner)])) });
if (!isDeepStrictEqual(full(), input)) throw Error('Full restore differs');
const hits: any[] = [], commands: any[] = [];
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  hits.push(json({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind: attacker.kind,
    target: target.id, targetOwner: target.owner, targetKind: target.kind, damage, hpBefore, hpAfter: target.hp, deck: target.deck }));
} };
const planner = await createBootstrapCommandPlanner(memories);
runAiGameLoop({ ...match, game, commandPlanner: planner }, { onCommand(e: any) {
  commands.push(json({ tick: e.tick, owner: e.owner, scriptId: e.scriptId, command: e.command }));
} });
const final = full(), comparison = {
  world: isDeepStrictEqual(final.snapshot, expected.snapshot), nextId: final.nextId === expected.nextId,
  bothMemories: isDeepStrictEqual(final.memories, expected.memories),
  allCommands: isDeepStrictEqual(commands, original.commands.filter((e: any) => e.tick >= from && e.tick <= end)),
  allNativeHits: isDeepStrictEqual(hits, original.hits.filter((e: any) => e.tick >= from && e.tick <= end)),
};
writeFileSync(directory + '/terminal-replay-final.json.gz', gzipSync(JSON.stringify(final)));
writeFileSync(directory + '/terminal-replay.json', JSON.stringify({ classification: 'Observer-only same-source both-normal-AI terminal replay from an exact complete checkpoint. No new ordinary0, no manual command or world edits.',
  source: cap.sourceRoot, commit: cap.head, from, end: game.tick, comparison, hits, commands }, null, 2));
console.log(JSON.stringify({ from, end: game.tick, winner: game.match.winner, comparison }));
if (Object.values(comparison).some(value => !value)) throw Error('Replay differs');
