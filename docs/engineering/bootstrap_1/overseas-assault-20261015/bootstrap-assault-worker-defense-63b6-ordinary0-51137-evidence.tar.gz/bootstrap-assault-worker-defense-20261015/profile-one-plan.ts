import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015', tick = 18600;
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const imp = (p: string) => import(pathToFileURL(cap.sourceRoot + '/' + p).href);
const [{ bootstrapScripts }, { planAiOwnerCommandEntries }] = await Promise.all([
  imp('src/ai/bootstrap_1/policy.ts'), imp('src/ai/planner-context.ts'),
]);
const saved = JSON.parse(gunzipSync(readFileSync(directory + `/ordinary0.frames/${tick}.json.gz`)).toString());
const before = JSON.stringify(saved), samples: any[] = [];
const scripts = bootstrapScripts('v9_summoner').map((script: any) => {
  const copy = { ...script };
  for (const name of ['run', 'claimsUnits']) if (script[name]) copy[name] = (...args: any[]) => {
    const started = performance.now();
    try { return Reflect.apply(script[name], script, args); }
    finally { samples.push({ script: script.id, operation: name, ms: performance.now() - started }); }
  };
  return copy;
});
const started = performance.now();
const entries = planAiOwnerCommandEntries(saved.snapshot, { playerId: 'p0', version: 'v9_summoner',
  memory: structuredClone(saved.memories.p0), scripts }, { teams: saved.snapshot.teams });
const elapsedMs = performance.now() - started;
const expected = readFileSync(directory + '/ordinary0-public-commands.jsonl', 'utf8').split('\n').filter(Boolean)
  .map(line => JSON.parse(line)).filter(e => e.tick === tick && e.owner === 'p0');
const actual = entries.map(({ scriptId, command }: any) => ({ tick, owner: 'p0', scriptId, command }));
const result = { classification: 'One read-only public p0 planner query of a real complete18600 input. Wrappers only time existing run/claims calls, return the original results unchanged. No simulation, no live process instrumentation, no source edits. Time includes one cold query and is not a benchmark claim.',
  source: cap.sourceRoot, commit: cap.head, tick, elapsedMs, snapshotAndSavedMemoryUnchanged: JSON.stringify(saved) === before,
  publicCommandsEqualActualOrdinaryThink: isDeepStrictEqual(actual, expected), actual, expected,
  samples: samples.sort((a, b) => b.ms - a.ms) };
writeFileSync(directory + '/one-plan-profile.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
