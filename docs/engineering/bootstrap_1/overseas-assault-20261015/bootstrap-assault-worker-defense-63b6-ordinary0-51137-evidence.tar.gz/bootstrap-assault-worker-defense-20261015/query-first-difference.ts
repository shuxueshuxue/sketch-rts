import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015';
const path = '/tmp/bootstrap-root-3bdb-ordinary0-20261015/capital-exact-divergence-6000-6600.frames/6585-0-complete-6585-after-p0-command.json';
const saved = JSON.parse(readFileSync(path, 'utf8'));
const rows = [];
for (const source of ['/tmp/sketch-rts-root-retarget-3bdb-control', '/tmp/sketch-rts-assault-worker-defense-control']) {
  const imp = (p: string) => import(pathToFileURL(source + '/' + p).href);
  const [{ bootstrapPolicyContext }, { assaultExpedition }, { combatCapability }, { effectiveCombatRating },
    { sameGround }, { shipPassengers }] = await Promise.all([
    imp('src/ai/bootstrap_1/policy.ts'), imp('src/ai/policy/naval.ts'), imp('src/shared/combat-capabilities.ts'),
    imp('src/ai/policy/v6/strength.ts'), imp('src/shared/terrain.ts'), imp('src/shared/ship-geometry.ts'),
  ]);
  const s = saved.snapshot, options = bootstrapPolicyContext(s, 'p0', 'v9_summoner', { teams: s.teams, memory: structuredClone(saved.memories.p0) });
  const mission = options.memory.naval.ferries['unit-p0-transport-1043'];
  const target = s.buildings.find((b: any) => b.id === mission.targetId), boat = s.units.find((u: any) => u.id === 'unit-p0-transport-1043');
  const defenders = s.units.filter((u: any) => u.owner === 'p1' && !u.deck && combatCapability(s, u).armed && sameGround(s.map, u, target));
  const cargo = shipPassengers(s.units, boat).filter((u: any) => u.kind !== 'worker' && !u.expiresTick);
  rows.push({ source, tick: s.tick, target: target.id, mission, defenders: defenders.map((u: any) => ({ id: u.id, kind: u.kind, hp: u.hp, maxHp: u.maxHp, dps: combatCapability(s, u).dps })),
    cargo: cargo.map((u: any) => ({ id: u.id, kind: u.kind, power: effectiveCombatRating(s, u) })), cargoPower: cargo.reduce((n: number, u: any) => n + effectiveCombatRating(s, u), 0),
    expedition: assaultExpedition(s, 'p0', options, target) });
}
writeFileSync(directory + '/first-difference-score.json', JSON.stringify({ classification: 'Pure counter-query of exact original6585 after-first-p0-command full input. Not a candidate6585 preplanner capture. Bodies/HP/cargo establish local arithmetic; current ordinary0 only changed this score.', path, rows }, null, 2));
console.log(JSON.stringify(rows.map(r => ({ source: r.source, tick: r.tick, required: r.expedition.required, cargoPower: r.cargoPower, defenders: r.defenders }))));
