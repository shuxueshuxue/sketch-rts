import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const source = cap.sourceRoot, tick = Number(process.argv[2]);
const imp = (p: string) => import(pathToFileURL(source + '/' + p).href);
const [{ assaultExpedition }, { sameGround }, { combatCapability }, { effectiveCombatRating }, { unitMover }] = await Promise.all([
  imp('src/ai/policy/naval.ts'), imp('src/shared/terrain.ts'), imp('src/shared/combat-capabilities.ts'),
  imp('src/ai/policy/v6/strength.ts'), imp('src/shared/catalog.ts'),
]);
const saved = JSON.parse(gunzipSync(readFileSync(directory + `/ordinary0.frames/${tick}.json.gz`)).toString());
const snapshot = saved.snapshot, before = JSON.stringify(saved);
// assaultExpedition reads these existing context fields only. No full planner,
// strategy script, command issue or world/memory mutation is run here.
const options = { version: 'v2', requestedVersion: 'v7', teams: snapshot.teams, memory: structuredClone(saved.memories.p0) };
const rows = snapshot.buildings.filter((b: any) => b.owner === 'p1' && b.kind === 'townHall').map((target: any) => {
  const result = assaultExpedition(snapshot, 'p0', options, target);
  const landed = snapshot.units.filter((u: any) => u.owner === 'p0' && !u.deck && u.kind !== 'worker' && !u.expiresTick
    && unitMover(u.kind) === 'land' && sameGround(snapshot.map, u, target));
  const defenders = snapshot.units.filter((u: any) => u.owner === 'p1' && !u.deck && combatCapability(snapshot, u).armed && sameGround(snapshot.map, u, target));
  return { target: target.id, x: target.x, y: target.y, required: result.required, ready: result.ready,
    selectedCrew: result.crew.map((u: any) => ({ id: u.id, kind: u.kind, hp: u.hp, power: effectiveCombatRating(snapshot, u) })),
    selectedCrewPower: result.crew.reduce((n: number, u: any) => n + effectiveCombatRating(snapshot, u), 0),
    landedPower: landed.reduce((n: number, u: any) => n + effectiveCombatRating(snapshot, u), 0),
    defenders: defenders.map((u: any) => ({ id: u.id, kind: u.kind, hp: u.hp, maxHp: u.maxHp, dps: combatCapability(snapshot, u).dps })) };
});
writeFileSync(directory + `/strategic-${tick}.json`, JSON.stringify({ classification: 'Pure exact function query of one real complete ordinary0 checkpoint; no extra AI/game run. Readiness is existing model readiness, not demonstrated native safety.',
  source, commit: cap.head, tick, rows, snapshotAndMemoryUnchanged: JSON.stringify(saved) === before }, null, 2));
console.log(JSON.stringify(rows.map((r: any) => ({ target: r.target, required: r.required, ready: r.ready, selectedCrewPower: r.selectedCrewPower,
  landedPower: r.landedPower, defenders: r.defenders.map((u: any) => u.kind) }))));
