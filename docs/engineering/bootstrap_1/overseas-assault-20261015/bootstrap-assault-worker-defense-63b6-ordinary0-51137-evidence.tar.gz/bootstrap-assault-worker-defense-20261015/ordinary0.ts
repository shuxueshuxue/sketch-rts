import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync } from 'node:zlib';

const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015';
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8')), source = cap.sourceRoot;
const oldPrefix = '/tmp/bootstrap-root-3bdb-ordinary0-20261015/ordinary';
const old = JSON.parse(readFileSync(oldPrefix + '.json', 'utf8'));
const opening = JSON.parse(readFileSync(oldPrefix + '-opening.json', 'utf8'));
const output = directory + '/ordinary0';
const atomic = (path:string,value:any) => {writeFileSync(path+'.tmp',value);renameSync(path+'.tmp',path);};
const json = (value: any) => JSON.parse(JSON.stringify(value));
const sha = (value: any) => createHash('sha256').update(value).digest('hex');
function verify() {
  const changes = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(source + '/' + path)) !== hash).map(([path]) => path);
  const head = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', source, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Frozen candidate changed');
  return { files: Object.keys(cap.hashes).length, changes, head, status };
}
const preflight = verify(), startedAtUtc = new Date().toISOString();
const imp = (path: string) => import(pathToFileURL(source + '/' + path).href);
const [{ bootstrapGame, bootstrapMatches }, { snapshotGame }, { createAiMemoryProvider }, { createBootstrapCommandPlanner },
  { runAiGameLoop }] = await Promise.all([imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/shared/sim.ts'),
  imp('src/ai/planner-context.ts'), imp('scripts/bootstrap_1-planner.ts'), imp('src/ai/game-runner.ts')]);
const match = bootstrapMatches(old.setup.seed, [old.setup.map], 144000, old.setup.unseen).find((m: any) =>
  m.subject === old.subject && m.side === old.setup.side && m.agents.p0.race === old.setup.agents.p0.race
  && Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === 'v8');
if (!match) throw Error('Actual standard match missing');
const game = bootstrapGame(match), memories = createAiMemoryProvider();
const full = () => json({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, memories.get(owner) ?? null])) });
const initial = full();
const openingComparison = { world: isDeepStrictEqual(initial.snapshot, opening.snapshot), nextId: initial.nextId === opening.nextId,
  allMemories: isDeepStrictEqual(initial.memories, opening.memories) };
if (Object.values(openingComparison).some(value => !value)) throw Error('Standard full opening differs');
if(game.tick!==0||initial.nextId!==1000||Object.values(initial.memories).some(m=>m!==null)
 ||Object.keys(match.agents).some(owner=>{const p=game.players[owner];return p.gold!==500||p.supplyUsed!==3||p.supplyCap!==8;}))throw Error('Standard opening state differs');
atomic(directory+'/in-process-opening.json',JSON.stringify(initial));
mkdirSync(output + '.frames', { recursive: true });
const classification = 'Independent standard ordinary tick0, fixed defender-worker-score candidate, normal frozen opponent and original factory resources/population. No restore/resume/manual commands. Developed known seed, not unseen holdout evidence.';
const samples: any[] = [], commands: any[] = [], hits: any[] = [], events: any[] = [];
const lastHit=new Map<string,any>(); let previousUnits=json(game.units),previousBuildings=json(game.buildings);
function saveProgress(completed: boolean) {
  writeFileSync(output + '-progress.json.tmp', JSON.stringify({ classification, commit: cap.head, startedAtUtc, pid: process.pid,
    setup: old.setup, tick: game.tick, winner: game.match.winner, completed, samples }));
  renameSync(output + '-progress.json.tmp', output + '-progress.json');
}
function capture() {
  const state = full();
  atomic(output + `.frames/${game.tick}.json.gz`, gzipSync(JSON.stringify(state)));
  const originalRow = old.rows.find((r: any) => r.tick === game.tick);
  let originalComparison;
  if (originalRow) {
    const originalFrame = JSON.parse(readFileSync(oldPrefix + `.json.frames/${game.tick}.json`, 'utf8'));
    originalComparison = { world: isDeepStrictEqual(state.snapshot, originalFrame.snapshot), nextId: state.nextId === originalFrame.nextId,
      allMemories: isDeepStrictEqual(state.memories, json(Object.fromEntries(Object.entries(originalRow.players).map(([o, p]: any) => [o, p.policy])))) };
  }
  samples.push({ tick: game.tick, winner: game.match.winner, originalComparison,
    owners: Object.fromEntries(Object.keys(match.agents).map(owner => [owner, {
      units: game.units.filter((u: any) => u.owner === owner).length,
      buildings: game.buildings.filter((b: any) => b.owner === owner).length,
      gold: game.players[owner].gold, supply: game.players[owner].supplyUsed, cap: game.players[owner].supplyCap,
    }])) });
  saveProgress(false);
  console.log(JSON.stringify(samples.at(-1)));
}
capture();
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  const hit=json({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, attackerKind:attacker.kind,target: target.id,
    targetOwner: target.owner,targetKind:target.kind, damage, hpBefore, hpAfter: target.hp, deck: target.deck });hits.push(hit);lastHit.set(target.id,hit);appendFileSync(output+'-native-hits.jsonl',JSON.stringify(hit)+'\n');
} };
const planner = await createBootstrapCommandPlanner(memories);
const runResult = runAiGameLoop({ ...match, game, commandPlanner: planner }, {
  onCommand(event: any) {const entry=json({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, command: event.command });commands.push(entry);appendFileSync(output+'-public-commands.jsonl',JSON.stringify(entry)+'\n');},
  onStep() {
    const eventStart=events.length,current=new Map(game.units.map((u:any)=>[u.id,u]));let observeLanding=false;
    for(const oldUnit of previousUnits){const unit:any=current.get(oldUnit.id);
      if(!unit){events.push({tick:game.tick,type:'removed',previous:oldUnit,lastNativeHit:lastHit.get(oldUnit.id)});}
      else if(oldUnit.deck&&!unit.deck){events.push({tick:game.tick,type:'first-post-step-disembark',before:oldUnit,after:json(unit)});if(unit.owner==='p0'&&!unit.expiresTick&&unit.kind!=='worker')observeLanding=true;}
      else if(oldUnit.owner!==unit.owner)events.push({tick:game.tick,type:'owner-change',before:oldUnit,after:json(unit)});
    }
    const buildings=new Set(game.buildings.map((b:any)=>b.id));
    for(const oldBuilding of previousBuildings)if(!buildings.has(oldBuilding.id))events.push({tick:game.tick,type:'building-removed',previous:oldBuilding,lastNativeHit:lastHit.get(oldBuilding.id)});
    for(const event of events.slice(eventStart))appendFileSync(output+'-native-events.jsonl',JSON.stringify(event)+'\n');
    previousUnits=json(game.units);previousBuildings=json(game.buildings);
    if(observeLanding)atomic(output+`.frames/${game.tick}-observed-disembark.json.gz`,gzipSync(JSON.stringify(full())));
    if (game.tick % 600 === 0 || game.match.winner) capture();
  },
});
if (samples.at(-1).tick !== game.tick) capture();
const final = full(), postflight = verify();
atomic(output + '-final.json.gz', gzipSync(JSON.stringify(final)));
atomic(output + '.json', JSON.stringify({ classification, commit: cap.head, source, startedAtUtc, endedAtUtc: new Date().toISOString(),
  pid: process.pid, setup: old.setup, openingComparison, initial, preflight, postflight, runResult,
  result: { tick: game.tick, winner: game.match.winner, stats: game.match.stats }, commands, hits, events, samples }));
saveProgress(true);
console.log(JSON.stringify({ completed: true, tick: game.tick, winner: game.match.winner, postflight }));
