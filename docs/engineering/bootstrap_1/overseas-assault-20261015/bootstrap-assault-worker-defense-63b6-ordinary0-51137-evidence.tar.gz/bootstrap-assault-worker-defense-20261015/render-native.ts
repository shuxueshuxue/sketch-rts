import{createCanvas}from'@napi-rs/canvas';
import{readFileSync,writeFileSync,existsSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{pathToFileURL}from'node:url';
const prefix=process.argv[2],tick=Number(process.argv[3]);
if(!prefix||!Number.isFinite(tick))throw new Error('Usage: render-fixed-bootstrap-opening.ts ABSOLUTE_PREFIX TICK');
const directory=prefix.slice(0,prefix.lastIndexOf('/'));
const capsule=JSON.parse(readFileSync(directory+'/candidate-source.json','utf8')),source=capsule.sourceRoot;
const{installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const{drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const{UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
const numericPath=`${prefix}.frames/${tick}.json.gz`;
const framePath=existsSync(numericPath)?numericPath:`${prefix}.frames/${tick}-observed-disembark.json.gz`;
const{snapshot}=JSON.parse(gunzipSync(readFileSync(framePath)).toString());
const referencePath=directory+'/ordinary-opening.json';
const reference=referencePath?JSON.parse(readFileSync(referencePath,'utf8')):undefined;
installHeadlessCanvas();
const views:Record<string,{x:number;y:number;width:number;height:number;zoom:number}>={
 'world-overview':{x:0,y:0,width:1600,height:1600,zoom:1600/Math.max(snapshot.map.width,snapshot.map.height)}
};
for(const owner of Object.keys(snapshot.players)){
 const hall=snapshot.buildings.find((b:any)=>b.owner===owner&&b.kind==='townHall');
 const halls=snapshot.buildings.filter((b:any)=>b.owner===owner&&b.kind==='townHall');
 for(const [index,base]of halls.entries())if(index>0)views[`${owner}-colony-${index}`]={x:Math.max(0,base.x-700),y:Math.max(0,base.y-500),width:1400,height:1000,zoom:1};
 const units=snapshot.units.filter((u:any)=>u.owner===owner);
 const center=hall??units[0]??reference?.snapshot?.buildings.find((b:any)=>b.owner===owner&&b.kind==='townHall');if(!center)continue;
 views[`${owner}-base`]={x:Math.max(0,center.x-1000),y:Math.max(0,center.y-800),width:1600,height:1280,zoom:.8};
 const army=units.filter((u:any)=>u.kind!=='worker');
 if(army.length){const at=army.reduce((a:any,u:any)=>({x:a.x+u.x/army.length,y:a.y+u.y/army.length}),{x:0,y:0});
 views[`${owner}-army-center`]={x:Math.max(0,at.x-1000),y:Math.max(0,at.y-800),width:1600,height:1280,zoom:.8};}
}
for(const owner of Object.keys(snapshot.players)){
 const origin=reference?.snapshot?.buildings.find((b:any)=>b.owner===owner&&b.kind==='townHall');
 if(origin)views[`original-${owner}-base`]={x:Math.max(0,origin.x-1000),y:Math.max(0,origin.y-800),width:1600,height:1280,zoom:.8};
}
if(existsSync(prefix+'.json')){
 const report=JSON.parse(readFileSync(prefix+'.json','utf8'));
 const landing=report.events.filter((e:any)=>e.type==='first-post-step-disembark'&&e.tick===tick&&e.after.owner==='p0'&&e.after.kind!=='worker'&&e.after.expiresTick===undefined);
 if(landing.length){const at=landing.reduce((a:any,e:any)=>({x:a.x+e.after.x/landing.length,y:a.y+e.after.y/landing.length}),{x:0,y:0});
 views['observed-landing']={x:Math.max(0,at.x-1000),y:Math.max(0,at.y-800),width:1600,height:1280,zoom:.8};}
}
const outputs=[];
for(const[name,view]of Object.entries(views)){
 if(process.argv[4]&&!process.argv[4].split(',').includes(name))continue;
 const canvas=createCanvas(view.width,view.height);
 drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
 const path=`${prefix}-observer-${tick}-${name}.png`;if(existsSync(path))throw new Error('Never overwrite previous observer image: '+path);writeFileSync(path,canvas.toBuffer('image/png'));outputs.push({name,path,view});
}
const metadataPath=`${prefix}-observer-${tick}.json`,previous=existsSync(metadataPath)?JSON.parse(readFileSync(metadataPath,'utf8')).outputs:[];
writeFileSync(metadataPath,JSON.stringify({classification:'Native drawWorld rendering of recorded actual game snapshot. New facing tracker does not reconstruct historic animation and does not prove shots. If an owner has no surviving entities, its camera uses the original input hall position; the rendered world is always the current saved tick.',tick,framePath,source,baseCommit:capsule.head,actualMapId:snapshot.map.id,referenceCameraPath:referencePath,outputs:[...previous,...outputs]},null,2)+'\n');
console.log(JSON.stringify({tick,outputs}));
