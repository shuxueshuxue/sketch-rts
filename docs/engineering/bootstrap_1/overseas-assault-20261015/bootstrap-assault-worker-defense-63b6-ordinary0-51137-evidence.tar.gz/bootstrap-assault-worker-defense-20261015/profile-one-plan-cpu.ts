import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const directory = '/workspace/.playtest/bootstrap-assault-worker-defense-20261015', tick = 18600;
const cap = JSON.parse(readFileSync(directory + '/candidate-source.json', 'utf8'));
const sha = (bytes: any) => createHash('sha256').update(bytes).digest('hex');
const verify = () => {
  const changes = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(cap.sourceRoot + '/' + path)) !== hash).map(([path]) => path);
  const head = execFileSync('git', ['-C', cap.sourceRoot, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['-C', cap.sourceRoot, 'status', '--porcelain'], { encoding: 'utf8' });
  if (changes.length || head !== cap.head || status) throw Error('Fixed source changed');
  return { head, status, changes, sourceFiles: Object.keys(cap.hashes).length };
};
const preflight = verify(), path = directory + `/ordinary0.frames/${tick}.json.gz`, bytes = readFileSync(path);
const saved = JSON.parse(gunzipSync(bytes).toString()), before = JSON.stringify(saved);
const imp = (p: string) => import(pathToFileURL(cap.sourceRoot + '/' + p).href);
const [{ bootstrapScripts }, { planAiOwnerCommandEntries }] = await Promise.all([
  imp('src/ai/bootstrap_1/policy.ts'), imp('src/ai/planner-context.ts'),
]);
const log = readFileSync(directory + '/ordinary0-public-commands.jsonl', 'utf8');
const lines = log.split('\n'); lines.pop();
const expected = lines.filter(Boolean).map(line => JSON.parse(line)).filter(e => e.tick === tick && e.owner === 'p0');
const results: any[] = [];
for (const mode of ['cold', 'warm']) {
  const samples: any[] = [], memory = structuredClone(saved.memories.p0);
  const scripts = bootstrapScripts('v9_summoner').map((script: any) => {
    const copy = { ...script };
    for (const name of ['run', 'claimsUnits']) if (script[name]) copy[name] = (...args: any[]) => {
      const started = performance.now();
      try { return Reflect.apply(script[name], script, args); }
      finally { samples.push({ script: script.id, operation: name, ms: performance.now() - started }); }
    };
    return copy;
  });
  const started = performance.now();
  const entries = planAiOwnerCommandEntries(saved.snapshot, { playerId: 'p0', version: 'v9_summoner', memory, scripts }, { teams: saved.snapshot.teams });
  const elapsedMs = performance.now() - started;
  const actual = entries.map(({ scriptId, command }: any) => ({ tick, owner: 'p0', scriptId, command }));
  results.push({ mode, elapsedMs, publicCommandsEqualActualOrdinaryThink: isDeepStrictEqual(actual, expected),
    commands: actual, afterMemory: memory, afterMemorySHA256: sha(JSON.stringify(memory)),
    samples: samples.sort((a, b) => b.ms - a.ms) });
}
const result = { classification: 'One CPU-profile process with two exact18600 public p0 planner queries, cold then warm on the same real input. No simulation, process attach, source edits or independent ordinary0. Cold/warm post-think p0 memories are compared to each other; actual ordinary0 has no saved18600 post-think memory, so that specific memory equality is not claimed.',
  source: cap.sourceRoot, commit: cap.head, tick, inputPath: path, inputSHA256: sha(bytes), preflight,
  snapshotAndBothSavedMemoriesUnchanged: JSON.stringify(saved) === before,
  coldWarmCommandsEqual: isDeepStrictEqual(results[0].commands, results[1].commands),
  coldWarmAfterMemoryEqual: isDeepStrictEqual(results[0].afterMemory, results[1].afterMemory), results, postflight: verify() };
writeFileSync(directory + '/one-plan-cpu-profile-query.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify({ ...result, results: results.map(({ afterMemory, ...r }) => r) }));
if (!result.snapshotAndBothSavedMemoriesUnchanged || !result.coldWarmCommandsEqual || !result.coldWarmAfterMemoryEqual
  || results.some(r => !r.publicCommandsEqualActualOrdinaryThink)) throw Error('Query equivalence failed');
