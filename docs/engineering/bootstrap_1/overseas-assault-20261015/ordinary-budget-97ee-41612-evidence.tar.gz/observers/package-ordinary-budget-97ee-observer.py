"""Seal the already running fixed-97ee ordinary match after its native terminal or inspection horizon. Never simulates."""
import hashlib,io,json,pathlib,subprocess,tarfile,tempfile
from datetime import datetime,timezone
root=pathlib.Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');prefix='archer-budget-ordinary-97ee';live=pathlib.Path('/workspace/sketch-rts-budget-ordinary-97ee-control');commit='97ee2df9c5fd427152dd24db421931ae006ce467'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((root/(prefix+'.json')).read_text());result=report['result'];tick=result['tick'];assert result['completed'] or tick>=144000,'Still inProgress before inspection horizon; preserve live evidence and keep following'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=live).decode().strip()==commit
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=live)==b''
source=json.loads((root/(prefix+'-runtime-source.json')).read_text());hashes={**source['runtimeHashes'],**source['supportingDataHashes']};assert len(hashes)==842
for name,h in hashes.items():assert sha((live/name).read_bytes())==h,name
assert report['setup']['rulesVersion']==2 and report['setup']['frozenRevision']=='d1ae110f2edd99f9c7d899ed61557891ab587639'
archive=root/f'ordinary-budget-97ee-{tick}-evidence.tar.gz';assert not archive.exists(),'Do not overwrite an existing evidence seal'
staging=pathlib.Path(tempfile.mkdtemp(prefix=f'bootstrap-ordinary-budget-97ee-{tick}-',dir='/tmp'));files={}
def add_bytes(name,data):
 assert name and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 assert name not in files
 p=staging/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);files[name]=sha(data)
def add(name,path):add_bytes(name,pathlib.Path(path).read_bytes())
source_archive=root/(prefix+'-sources.tar.gz');assert sha(source_archive.read_bytes())==source['fullSourceArchiveSHA256'];nested_count=0
with tarfile.open(source_archive,'r:gz')as tf:
 idx=json.loads(tf.extractfile('INDEX.json').read());assert set(m.name for m in tf.getmembers()if m.isfile())==set(idx['files'])|{'INDEX.json'}
 for name,h in idx['files'].items():
  data=tf.extractfile(name).read();assert sha(data)==h,name;nested_count+=1;add_bytes('source/prelaunch/'+name,data)
 manifest=json.loads(tf.extractfile('frozen-policy.json').read());assert manifest['rulesVersion']==2 and len(manifest['files'])==184
 assert sha(tf.extractfile('frozen-policy.json').read())==source['frozenManifestSha256']
 for name,h in manifest['files'].items():assert sha(tf.extractfile('frozen/'+name).read())==h,name
add('source/prelaunch-full-source-archive.tar.gz',source_archive)
for name in ['runtime-source.json','opening.json','opening-comparison.json','launch.json','launch-actual.json','postflight.json']:
 add('ordinary/'+name,root/(prefix+'-'+name))
for name in ['json','log']:add('ordinary/report.json'if name=='json'else'ordinary/log.txt',root/(prefix+'.'+name))
add('ordinary/frames/0.json',root/(prefix+'.json.frames/0.json'))
last_snapshot=None;loss_windows=[];previous=None
for row in report['rows']:
 t=row['tick'];p=root/f'{prefix}.json.frames/{t}.json';frame=json.loads(p.read_text());s=frame['snapshot'];assert s['tick']==t;add(f'ordinary/frames/{t}.json',p)
 add_bytes(f'ordinary/memories/{t}.json',json.dumps({owner:player['policy']for owner,player in row['players'].items()},sort_keys=True,separators=(',',':')).encode()+b'\n')
 if previous:
  prev_ids={u['id']:u for u in previous['units']};cur_ids={u['id']for u in s['units']}
  gone=[{k:u.get(k)for k in ['id','owner','kind','x','y','hp','order','deck']}for uid,u in prev_ids.items()if uid not in cur_ids and u['owner']in('p0','p1')]
  if gone:loss_windows.append({'after':previous['tick'],'through':t,'missingPreviouslySampledUnits':gone,'nativeStatsBefore':previous['match']['stats'],'nativeStatsAfter':s['match']['stats'],'lastShotBoundary':'Native counters establish aggregate causes; sampled disappearing units are not all individual final-shot attribution.'})
 previous=s;last_snapshot=s
assert last_snapshot and last_snapshot['tick']==tick
post=json.loads((root/(prefix+'-postflight.json')).read_text())
# Postflight schema is retained whole; independently verify native end-state here.
remaining={owner:{'units':len([u for u in last_snapshot['units']if u['owner']==owner]),'buildings':len([b for b in last_snapshot['buildings']if b['owner']==owner])}for owner in('p0','p1')}
known_service=[]
for u in last_snapshot['units']:
 if u['owner']=='p0'and u['kind']=='worker'and u.get('deck')and u['order']['type']in('board','repairShip'):known_service.append(u)
observer=json.loads((root/(prefix+'-observer.json')).read_text());assert observer['observedResult']==result and observer['sourceFilesChecked']==842 and not observer['sourceMismatches']
audit={'classification':'Independent read-only native terminal/horizon audit of one genuine fixed-source from-zero game; no replay or source change.', 'sourceCommit':commit,'setup':report['setup'],'result':result,'nativeMatch':last_snapshot['match'],'remaining':remaining,'terminalFrameSha256':sha((root/f'{prefix}.json.frames/{tick}.json').read_bytes()),'reportSha256':sha((root/(prefix+'.json')).read_bytes()),'fullFrameCount':len(report['rows'])+1,'memoryPairCount':len(report['rows']),'sourceFilesVerified':len(hashes),'knownRemainingDeckServiceOrders':known_service,'nativeSurvivingKillLedger':observer['samples'][-1]['nativeOwnKillLedger'],'landedEnemyStartArmy':observer['samples'][-1]['enemyGroundArmy'],'lossWindows':loss_windows}
add_bytes('ordinary/terminal-native-audit.json',json.dumps(audit,indent=2).encode()+b'\n');(root/(prefix+'-terminal-observer.json')).write_text(json.dumps(audit,indent=2)+'\n')
for name in ['prepare-fixed-ordinary-opening.py','ordinary-budget-97ee-observer.ts','ordinary-budget-97ee-service-observer.ts','render-ordinary-budget-97ee-observer.ts','package-ordinary-budget-97ee-observer.py',prefix+'-prelaunch-opening.ts',prefix+'-observer.json',prefix+'-visual-observer.json']:
 add('observers/'+name,root/name)
for p in sorted(root.glob(prefix+'-service-observer-*.json')):add('observers/'+p.name,p)
for p in sorted(root.glob(prefix+'-observer-*.png')):add('client-images/'+p.name,p)
old=json.loads((root/'archer-portrait-ordinary.json').read_text());first=lambda r:next((p['tick']for p in r['purchases']if p['command'].get('unitKind')=='bombardShip'),None)
metadata={'classification':'One fixed-source genuine ordinary tick0 match, with prelaunch deterministic opening witness and complete sampled world/policy evidence.','sealedAtUtc':datetime.now(timezone.utc).isoformat(),'sourceCommit':commit,'sourceIncludes':'97c7fca9 plus only 97ee2df9 protected naval saving-budget fix; no later yaw, service-yield, wind or other integrated changes.','result':result,'nativeEnd':last_snapshot['match'],'remaining':remaining,'liveSourceFilesVerified':len(hashes),'frozenManifestEntriesVerified':len(manifest['files']),'nestedSourcePayloadsVerified':nested_count,'fullFramesIncludingOpeningWitness':len(report['rows'])+1,'policyMemoryPairs':len(report['rows']),'openingWitnessBoundary':'Prelaunch fresh standard bootstrapGame factory capture with exact snapshot/nextId; inspector then independently starts the same deterministic factory. Frame0 is this explicitly labelled witness, not falsely claimed an inspector onStep callback.','comparison':{'baselineResult':old['result'],'nativeSurvivingKillLedger':observer['samples'][-1]['nativeOwnKillLedger'],'comparisonAudit':observer['comparison'],'lastEqualWorldAndMemorySample':9600,'firstDifferentSample':10800,'firstBombardPurchase':{'baselineOrdinary':first(old),'budgetOrdinary':first(report),'separateChangedCode20400Resume':22140},'causalityLimit':'Both ordinary fixed-source from-zero runs have matching setup and opening. Single-seed deterministic comparison is evidence, not three-route or seed-generalization acceptance; changed-code20400 replay is separate.'},'knownServiceBoundary':{'worker1713ToCutter1174At28800':'Actual seam/canTransfer true and yaw0, but native path blocked by horseArcher2297; clearTransferLanes empty. Pure read-only query included.','atTerminal':known_service},'lossAttributionBoundary':'Native aggregate own/enemy/neutral totals are complete; individual final shots are only asserted where available from native state. Sample windows retain disappearance evidence separately.','scoreLimits':'v9_archer/Grove p0 versus normal frozen v5/Ember, official sapphireArchipelago, bootstrap_1-development seed, rulesVersion2 only. v9_summoner/v9_knight, v7/v8, six opponent pairs, official-map coverage and unseen-seed acceptance remain outstanding.','recoveryGap':'Original failed-container uncommitted changes remain unrecovered; no claim this archive copied them.','previousSeals':'The original ordinary75777 archive and earlier inProgress seals remain unchanged.'}
add_bytes('EVIDENCE.json',json.dumps(metadata,indent=2).encode()+b'\n')
index={'algorithm':'SHA-256','scope':'Every regular payload other than INDEX.json itself; nested full source archive has its own independently verified INDEX.','files':dict(sorted(files.items()))};index_bytes=json.dumps(index,indent=2).encode()+b'\n';(staging/'INDEX.json').write_bytes(index_bytes)
with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
 for name in sorted([*files,'INDEX.json']):
  data=(staging/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(data))
verified=0
with tarfile.open(archive,'r:gz')as tf:
 actual=json.loads(tf.extractfile('INDEX.json').read());assert set(m.name for m in tf.getmembers()if m.isfile())==set(actual['files'])|{'INDEX.json'}
 for name,h in actual['files'].items():assert sha(tf.extractfile(name).read())==h,name;verified+=1
verification={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'indexSha256':sha(index_bytes),'payloadMembersVerified':verified,'frozenManifestEntriesVerified':len(manifest['files']),'nestedSourcePayloadsVerified':nested_count,'ordinaryFullFramesIncludingOpening':len(report['rows'])+1,'memoryPairs':len(report['rows']),'sourceFilesVerified':len(hashes),'result':result,'remaining':remaining,'noExistingArchiveOverwritten':True,'stagingDirectory':str(staging)}
(root/f'ordinary-budget-97ee-{tick}-evidence.verification.json').write_text(json.dumps(verification,indent=2)+'\n');(root/f'ordinary-budget-97ee-{tick}-evidence.sha256').write_text(verification['sha256']+'  '+archive.name+'\n');print(json.dumps(verification,indent=2))
