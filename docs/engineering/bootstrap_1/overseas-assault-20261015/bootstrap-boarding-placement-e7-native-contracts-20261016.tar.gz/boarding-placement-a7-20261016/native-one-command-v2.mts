import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const O='/tmp/boarding-placement-a7-20261016',C='/workspace/sketch-rts-boarding-placement-a7-control',B='/workspace/sketch-rts-cabin-ferry-ade-control';
const sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const assert=(v:any,m:string)=>{if(!v)throw Error(m);};
const raw=readFileSync(C+'/src/shared/fixtures/cabin-clinical-208201.json.gz'),saved=JSON.parse(gunzipSync(raw).toString()),original=JSON.stringify(saved);
const load=(s:string,p:string)=>import(pathToFileURL(s+'/'+p).href);
const [native,decks,oldDecks,validation,geo]=await Promise.all([load(C,'src/shared/sim.ts'),load(C,'src/shared/decks.ts'),load(B,'src/shared/decks.ts'),load(C,'src/shared/sim/command-validation.ts'),load(C,'src/shared/ship-geometry.ts')]);
const H='unit-p0-carrier-25442',W='unit-p0-ashHexer-23349';
const command={type:'board',unitIds:[W],transportId:H};
const outputs:any[]=[];
const persisted=(v:any)=>JSON.parse(JSON.stringify(v));
const undefinedPaths=(v:any,path=''):string[]=>v&&typeof v==='object'?Object.entries(v).flatMap(([k,x])=>x===undefined?[path+'/'+k]:undefinedPaths(x,path+'/'+k)):[];
for(let run=0;run<2;run++) {
 const game=native.createGame('bareDuel',{aiPlayers:[]});
 native.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 const rawBefore=native.snapshotGame(game),before=persisted(rawBefore);
 const restoreShape={rawInMemoryEqual:isDeepStrictEqual(rawBefore,saved.snapshot),serializedWholeWorldEqual:isDeepStrictEqual(before,saved.snapshot),undefinedPropertiesOmittedByNativeSaveFormat:undefinedPaths(rawBefore)};
 assert(isDeepStrictEqual(before,saved.snapshot)&&game.nextId===saved.nextId,'Restore mismatch');
 const walker=game.units.find((u:any)=>u.id===W),hull=game.units.find((u:any)=>u.id===H);
 const admission=validation.checkCommandLegality(game,'p0',command)??null;
 assert(!admission,'Candidate rejects original actual input');
 const cpu=process.cpuUsage(),at=performance.now();
 native.issuePlayerCommand(game,'p0',command);
 const cpuDelta=process.cpuUsage(cpu),issueWallMs=performance.now()-at;
 const after=persisted(native.snapshotGame(game));
 const changedUnits=after.units.filter((u:any,i:number)=>!isDeepStrictEqual(u,before.units[i]));
 const allowed=structuredClone(before),allowedWalker=allowed.units.find((u:any)=>u.id===W);
 allowedWalker.order=structuredClone(walker.order);
 assert(isDeepStrictEqual(after,allowed),'Unintended world changes besides target order');
 assert(changedUnits.length===1&&walker.order.type==='board'&&walker.order.transportId===H,'No unique native board order');
 assert(!walker.deck&&geo.shipPassengers(game.units,hull).length===25&&game.tick===208201&&game.nextId===saved.nextId,'Unexpected attachment, advance or id allocation');
 const result={snapshot:after,nextId:game.nextId,memories:saved.memories};
 writeFileSync(O+`/native-public-board-${run}.json.gz`,gzipSync(JSON.stringify(result)));
 outputs.push({run,strictRestore:true,restoreShape,admission,issueWallMs,issueCpuMs:(cpuDelta.user+cpuDelta.system)/1000,changedUnitIds:changedUnits.map((u:any)=>u.id),walkerOrder:walker.order,walkerDeck:walker.deck??null,cargo:geo.shipPassengers(game.units,hull).length,worldSha256:sha(JSON.stringify(after)),memoriesUnchanged:isDeepStrictEqual(result.memories,saved.memories),nextId:game.nextId});
}
assert(outputs[0].worldSha256===outputs[1].worldSha256,'Non-deterministic public order');
const costs:any[]=[];
for(const scenario of ['actual-crowded','empty-deck-derived']) {
 const snap=structuredClone(saved.snapshot),hull=snap.units.find((u:any)=>u.id===H),walker=snap.units.find((u:any)=>u.id===W);
 if(scenario==='empty-deck-derived')snap.units=snap.units.filter((u:any)=>u.deck?.shipId!==H);
 const before=JSON.stringify(snap);
 for(const [label,api] of [['original-a7',oldDecks],['candidate',decks]] as const) {
  api.canBoard(hull,walker,snap.units); // one warm-up, excluded from samples
  const samples:any[]=[];
  for(let n=0;n<3;n++) {
   const cpu=process.cpuUsage(),at=performance.now(),accepted=api.canBoard(hull,walker,snap.units),wallMs=performance.now()-at,delta=process.cpuUsage(cpu);
   samples.push({accepted,wallMs,cpuMs:(delta.user+delta.system)/1000});
  }
  costs.push({scenario,source:label,samples});
 }
 assert(JSON.stringify(snap)===before,'Pure canBoard query mutated copied state');
}
assert(JSON.stringify(saved)===original,'Fixture changed');
const result={classification:'New fixed-source shore-placement candidate: two independent strict restorations of actual 208201 and one native public issue per restore. No native ticks, no AI planner, no extra actual attachment. Focused pure canBoard cost queries use actual crowded geometry plus clearly derived empty-deck case; not a full-game benchmark.',inputSha256:sha(raw),base:'a7e0ccaa108c7eab1ebd959ff312dd378eb8e804',outputs,deterministicWholeWorldAfterOrder:true,costs,bounds:{nativeGameRestores:2,publicCommands:2,nativeSteps:0,pureCostQueriesIncludingWarmups:16,actualPassengersBefore:25,actualPassengersAfter:25,autonomousPolicyResult:false,naturalWin:false},limits:['Each wall/CPU sample is a focused local query and includes scheduler/JIT noise. No broad runtime speed claim.','The far walker has only acquired a normal board order; reaching the real berth and physical attachment are explicitly untested.','The default grid4 placement is unchanged, as are transfer/same-deck/owner/cabin/payload refusal branches.']};
writeFileSync(O+'/native-one-command-v2-result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
