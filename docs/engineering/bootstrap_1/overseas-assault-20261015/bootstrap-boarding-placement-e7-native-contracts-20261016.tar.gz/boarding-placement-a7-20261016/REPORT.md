# 岸上登船采样一致性候选 e7

独立分支 `codex/bootstrap-boarding-placement-20261016`，固定源 `e7cdb8d67f8070a6548b527a25a38f62e18f0a0a`，父源 `a7e0ccaa108c7eab1ebd959ff312dd378eb8e804`。控制位于 `/workspace/sketch-rts-boarding-placement-a7-control`，用 no-checkout / noncone sparse 创建，原 a7 控制保持干净不变。尚未整合到根运行源 1e。

生产只改 `src/shared/decks.ts`，9 行新增、3 行删除。岸上 canBoard 与 boardUnit 共享原生实际附件放置的 aft-port / occupied=true / 2px 查询。原 boardUnit 的位置、身体/障碍间隔、质量和实际行为完全保留；转船 canBoard 仍采用其原 4px 查询。未改变 owner、same-deck、船舱、来源船、转船高度、道路、配额、规则版本或冻结档案，没有 4→2 兼容/重试层。函数并非全域同一 bool 合同：canBoard 支持已在另一船上的转船，boardUnit 明确拒绝所有已有 deck 的单位。

真实 208201 完整档只有 25 人。原代码新回归准确复现 2 红 / 5 绿；修复后 7 绿。14 个 native 相关测试文件共 141 项，139 绿，2 红为 crew-rendezvous-coast 的原船 HP 314.97705695148625 ≠ 320；在干净 a7 同用例准确复现同样 2 红、相同 HP。没有改测试或弱化既有身体/比例合同。TypeScript 退出 0。

固定后两次独立的真实完整档恢复，各只发一条原生公开 board，得到完全一致的全存档世界 SHA `fcb08a0dbd9fcd6632e1fdba76d021c08699ea6b4ae3d6a07c3c1c3c02403195`：仅 23349 的订单改为合法 board / berth，0 tick、仍 25 人。第一版辅助驱动在任何命令前因原生内存中 undefined 属性与 JSON 存档省略属性的严格比较而退出，源/log 保留。v2 用完整原生 JSON 存档序列化比较所有世界值、nextId 和全部记忆；未删改任何游戏字段或物理状态。

之后独立真实临床包 `bootstrap-boarding-placement-e7-single-board-clinical-20261016` 验证了真正登船效果：同 208201 档，一条 P0 公开 board 后 P0 不再发命令，P1/P2 保持正常冻结 v5/v7 的 15 tick 计划。215 真实 tick 后，208416 原生实际附件 23349，变成 26 cargo / 10 inside / 16 open，露天 16 人全部通过真实 deckPointFits，载荷 4853 / 9060.48，舱位 20/21。原 25 人全程仍在原船、所有 HP 不变，23349 82 HP 不变，0 hit，原船位置与 HP 全程不变。实际 26 人战力 20.34819319223813 超过原门槛 20.115569375546702。胜者 null；这只是人工装载临床上的低层入口修复效果，不是自主 ferry 规划、完整胜局或 bootstrap 验收。

局部查询有明确 CPU 成本。真实拥挤档原 canBoard 三次 3.32–3.54 ms，候选 9.78–18.05 ms；明确派生的空甲板场景原 0.0056–0.0094 ms，候选 0.846–0.959 ms。仅 16 次含暖身的局部纯查询，存在 JIT/调度及同机工作影响，不能当完整速度基准。旧中心可直接早退，候选 aft/2px 会枚举，不能把总体开销一律称为 4 倍。候选公开 issue 总 132–203 ms 还包含原有 boardingBerth 搜索，不全部归因于新增 placement。这类采样不消费船路 FIFO 八份预算。

固定 1476 个源文件已核验，source capsule 包含 1476 live + 497 冻结源以及自身 index；冻结 manifest 184 项、revision `d1ae110f2edd99f9c7d899ed61557891ab587639`、rulesVersion 2 不变。历史 v5/v7/v8 planner 私有 shared 依赖仍用档案原源，但所有 owner 真正执行命令的 live Game 会统一采用新入口，所以新的成绩必须单独归属新运行源。

当前没有权限阻塞。根代理仍需独立复核再决定是否单独整合该低层候选；自主装载调度、实战跨海攻击与完整比赛作用另需后续证据。原容器未提交修改的恢复缺口不变。
