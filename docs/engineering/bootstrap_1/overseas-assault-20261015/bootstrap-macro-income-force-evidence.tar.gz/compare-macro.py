from pathlib import Path
import json,collections,math,hashlib,subprocess
p=Path('/workspace/.playtest/bootstrap-land-army-macro-20261015')
cases={
 'baseline5f':{'source':'/tmp/sketch-rts-mercenary-courier-safe-stop-control','prefix':'/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary','commit':'5f657b380bcf85e5653e55b22db6ae68b671869d'},
 'production3bdb':{'source':'/tmp/sketch-rts-root-retarget-3bdb-control','prefix':'/tmp/bootstrap-land-army-evidence-20261015/production-root3bdb-archer-double-v8-ordinary0','commit':'3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71'},
 'candidate9ba':{'source':'/workspace/sketch-rts-medical-arrival-hold-control','prefix':'/workspace/.playtest/bootstrap-land-army-continued-20261015/medical-arrival-hold9ba-archer-double-v8-ordinary0','commit':'9ba65d0644db73c365273bb94ce2ff04ccf41330'},
}
load=lambda f:json.loads(Path(f).read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
out={}
for label,c in cases.items():
 report=load(c['prefix']+'.json');rows=[]
 for row in report['rows']:
  tick=row['tick']
  if tick<15000:continue
  frame=Path(c['prefix']+f'.json.frames/{tick}.json');s=load(frame)['snapshot'];ps={}
  for owner in ['p0','p1','p2']:
   units=[u for u in s['units']if u['owner']==owner];army=[u for u in units if u['kind']!='worker'and u.get('expiresTick')is None];workers=[u for u in units if u['kind']=='worker'];buildings=[b for b in s['buildings']if b['owner']==owner]
   ps[owner]={'gold':s['players'][owner]['gold'],'spent':s['match']['stats']['goldSpent'][owner],'supply':s['players'][owner]['supplyUsed'],'cap':s['players'][owner]['supplyCap'],'upgrades':s['players'][owner]['upgrades'],
   'permanentArmy':len(army),'kinds':dict(collections.Counter(u['kind']for u in army)),'hp':sum(u['hp']for u in army),'maxHp':sum(u['maxHp']for u in army),'veterans':[{k:u.get(k)for k in ['id','kind','hp','maxHp','xp','kills','level','x','y','order']}for u in army if u.get('level',0)>0],
   'workers':len(workers),'workerOrders':dict(collections.Counter(u['order'].get('resourceId',u['order']['type'])for u in workers)),'healers':[{k:u.get(k)for k in ['id','kind','x','y','hp','abilityCooldowns','order']}for u in army if u['kind']in ['priest','fieldMedic']],
   'halls':[{k:b.get(k)for k in ['id','x','y','hp','maxHp','complete']}for b in buildings if b['kind']=='townHall'],'towers':[{k:b.get(k)for k in ['id','x','y','hp','complete']}for b in buildings if b['kind']=='defenseTower'],
   'training':[{ 'buildingId':b['id'],'buildingKind':b['kind'],'jobs':b['queue']}for b in buildings if b['queue']], 'research':[{ 'buildingId':b['id'],'jobs':b['researchQueue']}for b in buildings if b['researchQueue']],
   'nativeDeaths':s['match']['stats']['unitsLost'][owner],
   'nearNaturalEuclidean750':[{k:u.get(k)for k in ['id','kind','x','y','hp','maxHp','order']}for u in army if math.hypot(u['x']-1520,u['y']-3888)<=750],
   'nearGen5Euclidean800':[{k:u.get(k)for k in ['id','kind','x','y','hp','maxHp','order']}for u in army if math.hypot(u['x']-1164,u['y']-1893)<=800]}
  rows.append({'tick':tick,'players':ps,'resources':s['resources'],'general':row['players']['p0']['policy'].get('v6',{}).get('general'),'mounted':row['players']['p0']['policy'].get('mounted'),'goals':row['goals'],'frame':str(frame),'frameSHA256':sha(frame)})
 out[label]={'source':c['source'],'commit':c['commit'],'report':c['prefix']+'.json','reportSHA256':sha(c['prefix']+'.json'),'setup':report['setup'],'result':report['result'],'rows':rows,'actualPurchases15000plus':[x for x in report['purchases']if x['tick']>=15000]}
for label,metadata in [('production3bdb','/tmp/bootstrap-root-retarget-3bdb-20261015/prelaunch-source.json'),('baseline5f','/tmp/bootstrap-archer-double-v8-courier-v2-20261015/ordinary-runtime-source.json'),('candidate9ba','/workspace/.playtest/bootstrap-land-army-continued-20261015/medical-arrival-hold9ba-native-preflight.json')]:
 c=cases[label];m=load(metadata);hashes=m.get('hashes')or m.get('files')or{**m['runtimeHashes'],**m['supportingDataHashes']};missing=[n for n in hashes if not(Path(c['source'])/n).exists()];changes=[n for n,h in hashes.items()if(Path(c['source'])/n).exists()and sha(Path(c['source'])/n)!=h];status=subprocess.check_output(['git','status','--porcelain'],cwd=c['source'],text=True).strip();commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c['source'],text=True).strip();assert not changes and not missing and not status and commit==c['commit'];out[label]['currentSourceVerification']={'metadata':metadata,'metadataSHA256':sha(metadata),'filesVerified':len(hashes),'missing':missing,'changes':changes,'gitStatus':status,'commit':commit}
result={'classification':'Read-only full ordinary0 macro comparison. All three results belong to their own fixed sources; no changed-code resume or synthetic commands. Spatial rings are explicitly Euclidean visual summaries; native road/strength/eligibility diagnostics are separate. No production edits or new ordinary0.', 'cases':out,'limits':['600tick samples do not establish continuous behavior between frames.','Army HP and native deaths do not measure casualty quality alone; veterans, composition, ownership and local arrival matter.','Purchase log entries are issued public commands; a build command pays later at physical foundation start and is not proof of completed or paid construction.','Mine amount decline is extraction, not tax-adjusted delivered income; no new capital helper defined here.']}
(p/'macro-comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{'result':v['result'],'rows':len(v['rows']),'source':v['currentSourceVerification']}for k,v in out.items()},ensure_ascii=False))
