# 8041 mining-capital candidate: complete development evidence

The economic funding defect is reproduced and repaired. This complete changed-code match is slower and loses more permanent units than fixed e7, so it is not evidence of an overall stronger AI. The consumer patch is not merged into root/main and no additional8041 ordinary0 was launched.

| Evidence | Fixed e7 | Candidate8041 |
| --- | --- | --- |
| Source | e7f47f3226d8eabfe94ca7c75d489b0e273b452e | 8041e163c5ef43f67c5a5ff51fa3fdc9ef9748c5 |
| Start | genuine standard factory0, with retained ENOSPC interruption/resume68400 | changed-code continuation of exact original57600 world+nextId+both memories |
| Natural outcome | p0 wins87735 | p0 wins104669 |
| Enemy remaining | 0 units/0 buildings | 0 units/0 buildings |
| Permanent losses | 6 whole true0 | 8 in continued window plus1 unchanged original prefix=9 reconstructed whole trajectory |
| Neutral-caused losses | 1 cumulative | 1 cumulative |
| Final workers | 28, all70HP,25idle | 31, all70HP,25idle |
| Final own halls | 7 | 8 |

Both use rulesVersion2, approved frozen revision d1ae110f2edd99f9c7d899ed61557891ab587639/184 files, Grove v9_knight versus normal Ember v5 on official sapphireArchipelago. The known development seed is bootstrap_1-knight-v5-official-sapphire-20261015-01, unseen=false. Original factory0 is normal500gold/3workers/3used/8cap for both sides. No map/seat, resource, population, enemy or thinking-frequency weakening occurs. This is not three-route, nine-opponent-combination or unseen/generalization acceptance; the1620 derived matrix was not rerun.

The real58620 full policy commands bought an ordinary farm (v6Economy, goal farm), not naval:population. Its actual native payment is58702:120gold. Real58620 cash121.82 plus current-population native taxed income from known funded mining and carried ore582.12 gives703.94, enough for hall400+economic transport240. That ordinary farm reduces it to583.94. In the original game the last owned mine runs dry with338.69 cash after paying transport240, leaving the hall unfunded. The existing2500-raw-ore threshold only begins protecting funds after that farm command.

8041 retains the existing danger, local-expansion, queued/unpaid-build and reserved-purchase paths and the2500 threshold. It additionally preserves the liquid gap between next-income capital and current known funded mining income. At58620 it preserves57.88, preventing that ordinary120 farm purchase. Required naval population/transport, dangerous home defense and the real already-paid hall retain their existing command behavior in component tests. Already-paid queues are reported, never refunded or debited twice. The existing needsLift check still uses actual ships, so a paid transport queue may conservatively retain its price until the ship is born; this candidate does not claim optimal queue credit. The reusable helper holds current population and current physical access; it does not credit future halls/mines, bounties, cancellation refunds or predict combat/traffic/future population. The shared mine-prospect change extracts its existing per10gold rounded native formula without changing forecast behavior.

Actual economic results: transport240 pays60180; hall400 pays67923, completes68483; worker3802 deposits new satellite0 mine income68621. Native67923→69600 replay matches both complete68400/69600 worlds, nextIds and both memories plus111 commands. Fourteen unique new-mine deliveries each yield2.29, total32.06 through69600; same-step repair expense is accounted for rather than confusing net wallet change with mining income. A second hall400 pays94398. These are real economic recoveries, not a victory claim.

The full combat cost is retained. Six original1046 crew die74357..74710 while still on that deck in the native death records. Warship1064 and its full-HP raider1748 die together75305. No claim is made that the reserve arithmetic directly causes every subsequent navigation/combat difference. Native full outcome remains later and more costly; root should assess this consumer with the newer landing/care integration before treating it as a net gain. The shared helper is supplied separately for land income timing work.

143 unique related tests pass, including7 new actual-state/boundary regressions and16 prospect tests. Three old colony-capital-snapshot assertions still fail in the original clean e7 source; all three full command-entry arrays equal the candidate, and the original assertions are preserved. The final cents-rounding change reran the affected7 tests and strict typecheck; do not mislabel all143 as rerun after that final cents-rounding change. Initial red test/type error logs and corrected results remain in this package.

The final104400→104669 replay matches world, nextId, both memories and commands. All1423 physical source hashes remain equal to launch; the worktree remains clean. Native drawWorld views were generated from actual complete checkpoints and visually inspected. A fresh facing tracker does not reconstruct historical animation. The candidate step ledger does not by itself cover instantaneous public-command changes; missing ledger rows are not proof of no death or no landing. Full commands and native states are preserved.

Deliverables:
- FINAL-OUTCOME-AUDIT.json: exact economic chain, outcome, losses, replay and limits.
- continuation/: every complete input/checkpoint/native terminal world+nextId+bothmem, command trace, source pre/postflight and actual native visuals.
- income-boundary-verification.json and income-boundary/: native completion/new-income proof.
- source/full-change-from-e7.patch: portable full change including binary fixtures; production-from-e7.patch: three readable production files; mining-capital-helper-only.patch: two reusable helper files only.
- TEST-RESULTS.json and unchanged test logs, including the old failing baseline assertions.
- baseline/: selected actual complete e7 states and original diagnosis, not a second full baseline simulation. The full original true0 archive remains /workspace/bootstrap-knight-e7-ordinary0-87735-evidence.tar.gz, SHA25605de4d2a3ff10de11aca2dae64a5c840e19d652e4d4237f755c975c3285b1b1d.

An original diagnosis filename58621-complete-after-native-payment is retained to preserve the audit trail, but its JSON never showed payment. Correct native payment is58702, proven in native-payment-boundary-verification.json. The unavailable original broken-container uncommitted changes remain a recovery gap; nothing here claims to copy them. Root/main, other fixed sources and the independent rules3 performance work were not edited.
