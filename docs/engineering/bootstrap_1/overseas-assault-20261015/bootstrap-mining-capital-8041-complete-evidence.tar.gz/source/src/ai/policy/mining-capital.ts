import { roundGold } from '../../shared/gold';
import { GOLD_MINE_RULES, upkeepGoldIncome } from '../../shared/mining';
import { remainingMiningGold } from '../../shared/mining-prospect';
import { groundApproachRoute } from '../../shared/route-selection';
import { sameGround } from '../../shared/terrain';
import type { GameSnapshot, PlayerId } from '../../shared/types';
import { mineClaimedByAlly } from './mine-claims';
import type { AiPolicyContext } from './types';

/** Current-population income from known, already funded mining access.
 * This does not credit a future hall, combat income, cancellation or refund. */
export function miningCapital(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext) {
  const halls = snapshot.buildings.filter(hall => hall.owner === owner && hall.kind === 'townHall' && hall.complete && hall.hp > 0);
  const workers = snapshot.units.filter(unit => unit.owner === owner && unit.kind === 'worker' && unit.hp > 0 && !unit.deck);
  const supplyUsed = snapshot.players[owner]!.supplyUsed;
  const nearestHall = (point: { x: number; y: number }) => halls.filter(hall => sameGround(snapshot.map, hall, point))
    .sort((a, b) => Math.hypot(a.x - point.x, a.y - point.y) - Math.hypot(b.x - point.x, b.y - point.y))[0];
  const mines = snapshot.resources.flatMap(mine => {
    if (mine.amount <= 0 || mineClaimedByAlly(snapshot, owner, mine, options)) return [];
    const hall = nearestHall(mine);
    if (!hall || Math.hypot(hall.x - mine.x, hall.y - mine.y) > GOLD_MINE_RULES.baseRange
      || !groundApproachRoute(snapshot.map, mine, hall)
      || !workers.some(worker => (worker.order.type === 'mine' || worker.order.type === 'idle')
        && sameGround(snapshot.map, worker, mine) && groundApproachRoute(snapshot.map, worker, mine))) return [];
    return [{ id: mine.id, amount: mine.amount, netGold: remainingMiningGold(mine.amount, supplyUsed) }];
  });
  const carried = workers.flatMap(worker => {
    if (worker.carryingGold <= 0 || worker.order.type !== 'mine' || worker.order.phase !== 'return') return [];
    const hall = nearestHall(worker);
    return hall && groundApproachRoute(snapshot.map, worker, hall)
      ? [{ id: worker.id, amount: worker.carryingGold, netGold: upkeepGoldIncome(worker.carryingGold, supplyUsed) }] : [];
  });
  const futureGold = roundGold([...mines, ...carried].reduce((sum, entry) => sum + entry.netGold, 0));
  // Queue fees already left the wallet; expose the commitments without
  // treating them as available gold or subtracting their prices a second time.
  const paidQueues = snapshot.buildings.filter(building => building.owner === owner)
    .flatMap(building => building.queue.map(job => ({ buildingId: building.id, unitKind: job.unitKind, paidGold: job.paidGold })));
  return { gold: snapshot.players[owner]!.gold, supplyUsed, mines, carried, futureGold,
    availableGold: roundGold(snapshot.players[owner]!.gold + futureGold), paidQueues };
}
