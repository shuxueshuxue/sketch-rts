import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { createGame, restoreSnapshotIntoGame, snapshotGame, stepGame } from '../../shared/sim';
import { sameGround, walkableGoal } from '../../shared/terrain';
import { canSupply, projectedSupplyUsed } from '../policy/world-model';
import { miningCapital } from '../policy/mining-capital';
import { navalBudgetReserve, navalReservePurchase } from '../policy/naval';
import { planAiOwnerCommandEntries } from '../planner-context';
import { bootstrapPolicyContext } from './policy';
import { rankBootstrapGoals } from './economy';

function setup(tick: 38400 | 57600 | 58620 = 58620) {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/naval-income-solvency-e7-${tick}.json.gz`, import.meta.url))).toString());
  const game = createGame('bareDuel');
  restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  const snapshot = snapshotGame(game), memory = structuredClone(saved.memories.p0);
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory, teams: game.teams });
  return { saved, game, snapshot, options };
}

function entries(snapshot: ReturnType<typeof snapshotGame>, saved: ReturnType<typeof setup>['saved']) {
  return planAiOwnerCommandEntries(snapshot, { playerId: 'p0', version: 'v9_knight', memory: structuredClone(saved.memories.p0) }, { ...(snapshot.teams ? { teams: snapshot.teams } : {}) });
}

it('preserves real58620 next-income capital before an ordinary army farm spends it', () => {
  const { snapshot, saved, options } = setup();
  expect(snapshot.players.p0!.gold).toBe(121.82);
  expect(projectedSupplyUsed(snapshot, 'p0')).toBe(140);
  expect(canSupply(snapshot, 'p0', 'transport')).toBe(true);
  expect(navalReservePurchase('farm')).toBe(false);
  expect(navalReservePurchase('naval:population')).toBe(true);
  const capital = miningCapital(snapshot, 'p0', options);
  expect(capital.futureGold).toBe(582.12);
  expect(capital.availableGold).toBe(703.94);
  expect(navalBudgetReserve(snapshot, 'p0', options)).toBe(57.88);
  expect(entries(snapshot, saved).some(e => e.command.type === 'build' && e.command.buildingKind === 'farm')).toBe(false);
});

it('keeps a native immediate harvest in remaining capital instead of losing its timer0 delivery (controlled boundary)', () => {
  const { game, saved } = setup();
  const worker = game.units.find(u => u.id === 'unit-p0-worker-3802')!;
  if (worker.order.type !== 'mine') throw Error('real miner missing');
  worker.order.timer = 0;
  const before = snapshotGame(game), options = bootstrapPolicyContext(before, 'p0', 'v9_knight', { memory: structuredClone(saved.memories.p0), teams: game.teams });
  const capital = miningCapital(before, 'p0', options);
  stepGame(game);
  const after = snapshotGame(game);
  expect(after.resources.find(m => m.id === 'gold-satellite-5')!.amount).toBe(2500);
  expect(miningCapital(after, 'p0', options).availableGold).toBe(capital.availableGold);
  expect(capital.availableGold).toBe(703.94);
});

it('does not refund the real already-paid knight queue into the available wallet', () => {
  const { snapshot, saved, options } = setup(57600);
  const capital = miningCapital(snapshot, 'p0', options);
  expect(capital.paidQueues).toContainEqual({ buildingId: 'building-p0-stables-1333', unitKind: 'knight', paidGold: 190 });
  expect(capital.gold).toBe(6.32);
  expect(capital.availableGold).toBe(703.94);
  expect(entries(snapshot, saved).map(({ scriptId, command }) => ({ scriptId, command }))).toEqual(saved.expectedP0Commands);
});

it.each([false, true])('still permits the economic transport prerequisite when population is needed=%s (counterfactual affordability)', population => {
  const { game, saved } = setup();
  game.resources.find(m => m.id === 'gold-satellite-5')!.amount = 2490;
  game.players.p0!.gold = population ? 120 : 240;
  if (population) game.players.p0!.supplyCap = 140;
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory: structuredClone(saved.memories.p0), teams: game.teams });
  const goals = rankBootstrapGoals(snapshot, 'p0', options);
  expect(goals.some(g => g.id === (population ? 'naval:population' : 'naval:transport'))).toBe(true);
  const commands = entries(snapshot, saved).map(e => e.command);
  const home = snapshot.buildings.find(b => b.id === 'building-p0-townhall')!;
  expect(commands.some(c => population
    ? c.type === 'build' && c.buildingKind === 'farm' && sameGround(snapshot.map, c, home)
    : c.type === 'train' && c.unitKind === 'transport')).toBe(true);
});

it('keeps the original dangerous-home reserve exemption (counterfactual threat)', () => {
  const { game, saved } = setup(), home = game.buildings.find(b => b.id === 'building-p0-townhall')!;
  const enemy = game.units.find(u => u.owner === 'p1' && u.kind !== 'worker' && !u.deck && u.attackDamage > 0)!;
  Object.assign(enemy, walkableGoal(game.map, home.x + 240, home.y));
  const snapshot = snapshotGame(game), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory: structuredClone(saved.memories.p0), teams: game.teams });
  expect(navalBudgetReserve(snapshot, 'p0', options)).toBe(0);
});

it('preserves the real already-paid rising hall and its full current command frame', () => {
  const { snapshot, saved, options } = setup(38400);
  expect(snapshot.buildings.some(b => b.owner === 'p0' && b.kind === 'townHall' && !b.complete)).toBe(true);
  expect(miningCapital(snapshot, 'p0', options).gold).toBe(142.86);
  expect(entries(snapshot, saved).map(({ scriptId, command }) => ({ scriptId, command }))).toEqual(saved.expectedP0Commands);
});
