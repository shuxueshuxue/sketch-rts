import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
const out='/workspace/bootstrap-mining-capital-e7-20261015', old='/tmp/sketch-rts-safe-worker-boarding-v1-control', candidate='/workspace/sketch-rts-mining-capital-e7-control',norm=(x:any)=>JSON.parse(JSON.stringify(x));
const imp=(source:string,p:string)=>import(pathToFileURL(source+'/'+p).href);
const cases:any[]=[];
for (const source of [old,candidate]) {
 const [sim,p,runner,planner,n,cap]=await Promise.all([imp(source,'src/shared/sim.ts'),imp(source,'src/ai/bootstrap_1/policy.ts'),imp(source,'src/ai/policy/script-runner.ts'),imp(source,'src/ai/planner-context.ts'),imp(source,'src/ai/policy/naval.ts'),source===candidate?imp(source,'src/ai/policy/mining-capital.ts'):Promise.resolve(null)]);
 for(const tick of [57600,58620,58800]){
  const report=JSON.parse(readFileSync('/workspace/bootstrap-knight-e7-ordinary0-recovered-20261015/result.json','utf8')),f=report.frames.find((f:any)=>f.tick===tick),input=tick===58620?'/workspace/bootstrap-e7-economy-readonly-20261015/payment-frames/58620-complete-before-think.json.gz':'/workspace/bootstrap-knight-e7-ordinary0-recovered-20261015/'+f.directory+'/'+f.file,saved=JSON.parse(gunzipSync(readFileSync(input)).toString());
  const game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=sim.snapshotGame(game),before=norm(snapshot),options=p.bootstrapPolicyContext(snapshot,'p0','v9_knight',{memory:structuredClone(saved.memories.p0),teams:game.teams});
  const entries=planner.planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_knight',memory:structuredClone(saved.memories.p0)},{teams:game.teams});
  cases.push({source,tick,input,gold:snapshot.players.p0.gold,reserve:n.navalBudgetReserve(snapshot,'p0',options),capital:cap?.miningCapital(snapshot,'p0',options),entries,snapshotUnchanged:isDeepStrictEqual(before,norm(snapshot))});
 }
 const saved=JSON.parse(gunzipSync(readFileSync(source+'/src/ai/bootstrap_1/fixtures/knight-colony-capital.json.gz')).toString());
 for(const version of ['v9_archer','v9_summoner','v9_knight']){const game=sim.createGame('bareDuel');sim.restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=sim.snapshotGame(game),options=p.bootstrapPolicyContext(snapshot,'p0',version,{memory:structuredClone(saved.memory),teams:game.teams});cases.push({source,oldColonyCase:version,entries:runner.runAiCommandEntriesFromScripts(snapshot,'p0',p.bootstrapScripts(version),options)});}
}
const comparisons=[57600,58620,58800].map(tick=>({tick,equal:isDeepStrictEqual(cases.find(c=>c.source===old&&c.tick===tick)?.entries,cases.find(c=>c.source===candidate&&c.tick===tick)?.entries)}));
const oldColonyComparisons=['v9_archer','v9_summoner','v9_knight'].map(version=>({version,fullEntriesEqual:isDeepStrictEqual(cases.find(c=>c.source===old&&c.oldColonyCase===version)?.entries,cases.find(c=>c.source===candidate&&c.oldColonyCase===version)?.entries)}));
writeFileSync(out+'/fixed-8041-candidate-query.json',JSON.stringify({classification:'Pure exact full-pipeline comparison on original e7 states. No new match or native steps; original failed colony assertions preserved.',cases,comparisons,oldColonyComparisons},null,2));console.log(JSON.stringify({comparisons,oldColonyComparisons,cases:cases.filter(c=>c.tick).map(c=>({source:c.source,tick:c.tick,reserve:c.reserve,gold:c.gold,future:c.capital?.futureGold,entries:c.entries,snapshotUnchanged:c.snapshotUnchanged}))},null,2));
