from pathlib import Path
import json,hashlib,tarfile,gzip
D=Path('/workspace/bootstrap-mining-capital-e7-20261015');archive=Path('/workspace/bootstrap-mining-capital-8041-complete-evidence.tar.gz');sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((D/'continuation/result.json').read_text());assert result['result']=={'tick':104669,'winner':'p0','completed':True};assert result['sourceUnchanged']and not result['sourceStatus'];assert all(result['replay'][k]for k in ['world','nextId','bothMemories','commands'])
files=sorted(p for p in D.rglob('*')if p.is_file()and p.name!='INDEX.json');payload={str(p.relative_to(D)):sha(p.read_bytes())for p in files}
for p in files:
 if p.name.endswith('.json.gz'):json.loads(gzip.decompress(p.read_bytes()))
(D/'INDEX.json').write_text(json.dumps({'algorithm':'SHA256','files':payload},indent=2)+'\n')
assert not archive.exists(),'Do not overwrite a sealed archive'
with tarfile.open(archive,'w:gz')as t:
 for p in sorted(D.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(D)),recursive=False)
with tarfile.open(archive)as t:
 index=json.load(t.extractfile('INDEX.json'));bad=[p for p,h in index['files'].items()if sha(t.extractfile(p).read())!=h]
 assert not bad,bad
seal={'archive':str(archive),'SHA256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payloadsVerified':len(payload),'bad':bad,'sourceCommit':result['commit'],'naturalResult':result['result'],'classification':'Known-seed fixed8041 changed-code57600 complete continuation. Economic bridge succeeds, full match slower/higher losses; not a new ordinary0 or final acceptance.'}
Path('/workspace/bootstrap-mining-capital-8041-complete-evidence.seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal))
