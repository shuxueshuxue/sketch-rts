import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015',W='/workspace/sketch-rts-knight-integrated-0f5bf-control';
const report=JSON.parse(readFileSync(`${D}/result.json`,'utf8'));assert.equal(report.finished,true);
const cap=JSON.parse(readFileSync(`${D}/source.json`,'utf8')),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourceCheck=()=>Object.entries(cap.files).every(([p,h])=>hash(`${W}/${p}`)===h);assert.ok(sourceCheck());
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href),json=(v:any)=>JSON.parse(JSON.stringify(v));
const [{bootstrapGame,bootstrapMatches},{restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider}]=await Promise.all([
 imp('src/ai/bootstrap_1/benchmark.ts'),imp('src/shared/sim.ts'),imp('src/ai/planner-context.ts')]);
const match=bootstrapMatches(cap.selection.seed,[cap.selection.mapId],Number.MAX_SAFE_INTEGER,false).find((m:any)=>m.subject==='v9_knight'&&m.agents.p0.race==='grove'&&m.side===0&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v5');
function diff(a:any,b:any,path='',out:any[]=[]){if(isDeepStrictEqual(a,b))return out;if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){out.push({path,restored:a,saved:b});return out;}for(const key of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[key],b[key],`${path}/${key}`,out);return out;}
const rows=[];
for(const path of readdirSync(`${D}/frames`).filter(p=>p.endsWith('.json.gz')).sort((a,b)=>parseInt(a)-parseInt(b))){
 const frame=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${path}`)).toString()),g=bootstrapGame(match),mem=createAiMemoryProvider();
 restoreSnapshotIntoGame(g,frame.snapshot,frame.nextId);for(const[o,m]of Object.entries(frame.memories))if(m!==null)mem.set(o,structuredClone(m));
 const restored=json(snapshotGame(g)),world=isDeepStrictEqual(restored,frame.snapshot),nextId=g.nextId===frame.nextId,
 bothMem=isDeepStrictEqual(Object.fromEntries(Object.keys(match.agents).map(o=>[o,mem.get(o)??null])),frame.memories);
 rows.push({tick:frame.tick,file:`frames/${path}`,periodic:frame.tick%1200===0,terminal:frame.tick===report.end,world,nextId,bothMem,sha256:hash(`${D}/frames/${path}`),differences:world?[]:diff(restored,frame.snapshot)});
}
const output={classification:'Read-only restore roundtrip of every original live ordinary0 full frame after completion. This does not replay a game. A failed event frame must not be used as an exact resume checkpoint.',source:cap.head,sourceFiles:cap.fileCount,sourcePre:true,sourcePost:sourceCheck(),count:rows.length,all:rows.every(r=>r.world&&r.nextId&&r.bothMem),periodicAll:rows.filter(r=>r.periodic).every(r=>r.world&&r.nextId&&r.bothMem),terminalAll:rows.filter(r=>r.terminal).every(r=>r.world&&r.nextId&&r.bothMem),failures:rows.filter(r=>!r.world||!r.nextId||!r.bothMem),rows};
writeFileSync(`${D}/full-frame-restore-audit.json`,JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify({...output,rows:undefined},null,2));
