import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015', W='/workspace/sketch-rts-knight-integrated-0f5bf-control';
const cap=JSON.parse(readFileSync(`${D}/source.json`,'utf8'));
const sourceCheck=()=>Object.entries(cap.files).every(([p,h])=>createHash('sha256').update(readFileSync(`${W}/${p}`)).digest('hex')===h);
assert.ok(sourceCheck());
const tick=Number(process.argv[2]), focus=process.argv[3]??'world';
const frame=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${tick}.json.gz`)).toString()),snapshot=frame.snapshot;
const {createCanvas}=createRequire(`${W}/package.json`)('@napi-rs/canvas');
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href);
const [{installHeadlessCanvas},{drawWorld},{UnitFacingTracker}]=await Promise.all([
  imp('src/recorder/record.ts'),imp('src/client/world-renderer.ts'),imp('src/client/unit-facing.ts')]);
installHeadlessCanvas();
const opening=JSON.parse(gunzipSync(readFileSync(`${D}/frames/0.json.gz`)).toString()).snapshot;
const center=focus==='p1'?opening.buildings.find((b:any)=>b.owner==='p1'&&b.kind==='townHall'):
  focus==='p0'?opening.buildings.find((b:any)=>b.owner==='p0'&&b.kind==='townHall'):null;
const width=center?1800:1400,height=center?1000:1400;
const view=center?{x:center.x-2100,y:center.y-1166.6666666666667,width:4200,height:2333.3333333333335,zoom:1800/4200}:
  {x:0,y:0,width:snapshot.map.width,height:snapshot.map.height,zoom:1400/snapshot.map.width};
const canvas=createCanvas(width,height);
drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:tick*1000/20,
  facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
const output=`${D}/native-${tick}-${focus}.png`;writeFileSync(output,canvas.toBuffer('image/png'));
assert.ok(sourceCheck());
writeFileSync(`${output}.json`,JSON.stringify({classification:'Read-only exact-head native drawWorld render of actual complete ordinary0 frame. No world/body/order edits; fresh facing tracker does not recreate historical animation.',tick,focus,view,frame:`${D}/frames/${tick}.json.gz`,source:cap.head,sourceFilesExact:true,output},null,2)+'\n');
console.log(output);
