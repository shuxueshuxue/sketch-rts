import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015',W='/workspace/sketch-rts-knight-integrated-0f5bf-control';
const cap=JSON.parse(readFileSync(`${D}/source.json`,'utf8')),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourceCheck=()=>Object.entries(cap.files).every(([p,h])=>hash(`${W}/${p}`)===h);assert.ok(sourceCheck());
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href);
const [{sameGround,setBuildingBodies},{unitMover}]=await Promise.all([imp('src/shared/terrain.ts'),imp('src/shared/catalog.ts')]);
const paths=readdirSync(`${D}/frames`).filter(p=>p.endsWith('.json.gz')).sort((a,b)=>parseInt(a)-parseInt(b));
const opening=JSON.parse(gunzipSync(readFileSync(`${D}/frames/0.json.gz`)).toString()).snapshot;
const enemyHall=opening.buildings.find((b:any)=>b.owner==='p1'&&b.kind==='townHall');
const rows=[];
for(const path of paths){
 const f=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${path}`)).toString()),s=f.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const enemyLand=s.units.filter((u:any)=>u.owner==='p0'&&u.hp>0&&!u.deck&&!u.sailing&&u.kind!=='worker'&&unitMover(u.kind)==='land'&&sameGround(s.map,u,enemyHall)).map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,x:u.x,y:u.y,order:u.order}));
 const ships=s.units.filter((u:any)=>u.owner==='p0'&&u.sailing&&u.hp>0).map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,heading:u.sailing.heading,speed:u.sailing.speed,order:u.order,routeAge:u.sailing.route?.planningAge,passengers:s.units.filter((p:any)=>p.deck?.shipId===u.id).map((p:any)=>({id:p.id,kind:p.kind,hp:p.hp,permanent:p.expiresTick===undefined})),mission:f.memories.p0?.naval?.ferries?.[u.id],service:f.memories.p0?.navalServices?.[u.id]}));
 rows.push({tick:f.tick,frame:`frames/${path}`,stats:s.match.stats,enemyLand,ships,enemyBuildings:s.buildings.filter((b:any)=>b.owner==='p1'&&b.hp>0).map((b:any)=>({id:b.id,kind:b.kind,hp:b.hp,x:b.x,y:b.y})),p0Naval:f.memories.p0?.naval});
}
assert.ok(sourceCheck());
const output={classification:'Read-only actual full-frame native ground/ship/order/memory inventory, no simulation or diagnostic AI planning. Periodic first observations are not exact event ticks.',source:cap.head,sourceFilesExact:true,frameCount:rows.length,rows};
writeFileSync(`${D}/observation-index.json`,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,enemyLand:r.enemyLand.map((u:any)=>u.id),ships:r.ships.map((s:any)=>({id:s.id,hp:s.hp,x:s.x,y:s.y,order:s.order,crew:s.passengers.length,mission:s.mission?.purpose,phase:s.mission?.phase})),enemyBuildings:r.enemyBuildings.length})),null,2));
