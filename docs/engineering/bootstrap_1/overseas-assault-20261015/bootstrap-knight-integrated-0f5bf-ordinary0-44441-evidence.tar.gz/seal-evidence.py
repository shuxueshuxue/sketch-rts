from pathlib import Path
import json,hashlib,tarfile,io
D=Path('/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015')
W=Path('/workspace/sketch-rts-knight-integrated-0f5bf-control')
P=Path('/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-44441-evidence.tar.gz')
assert not P.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
cap=json.loads((D/'source.json').read_text());summary=json.loads((D/'summary.json').read_text())
assert summary['naturalEndTick']==44441 and summary['winner']=='p0'
assert all(sha((W/p).read_bytes())==h for p,h in cap['files'].items())
names=sorted(str(p.relative_to(D))for p in D.rglob('*')if p.is_file()and p.name!='payload-index.json')
index={'classification':'Complete single actual ordinary0 integration0f5bf 0→44441 natural win. Key windows are exact reconstructed validations, not extra scored matches. Known logger limitation, sole raider loss, all frame/source/frozen checks and remaining acceptance scope preserved.','algorithm':'SHA256','files':{n:{'bytes':(D/n).stat().st_size,'sha256':sha((D/n).read_bytes())}for n in names}}
index_bytes=(json.dumps(index,indent=2)+'\n').encode();(D/'payload-index.json').write_bytes(index_bytes)
with tarfile.open(P,'w:gz')as t:
 for n in names:t.add(D/n,arcname=n,recursive=False)
 i=tarfile.TarInfo('INDEX.json');i.size=len(index_bytes);i.mode=0o644;t.addfile(i,io.BytesIO(index_bytes))
with tarfile.open(P)as t:
 assert len(t.getmembers())==len(names)+1
 for n,r in index['files'].items():
  b=t.extractfile(n).read();assert len(b)==r['bytes']and sha(b)==r['sha256'],n
 assert t.extractfile('INDEX.json').read()==index_bytes
meta={'archive':str(P),'bytes':P.stat().st_size,'sha256':sha(P.read_bytes()),'payloadFiles':len(names),'indexFiles':1,'readBackAllBytesAndSHA256':True,'sourceHead':cap['head'],'sourceFiles':cap['fileCount'],'sourceArchiveSHA256':cap['sourceArchiveSHA256'],'frozen184PrePostExact':True,'actualOrdinaryStart':0,'naturalWinTick':44441,'originalFullFrames':40,'allFullFrameRestoresExact':True,'friendlyPermanentLoss':1,'enemyPermanentLoss':38,'first13LandingPartyAllAliveOnEnemyLand':True,'enemyFinalUnits':0,'enemyFinalBuildings':0,'notFinalBootstrapAcceptance':True}
Path('/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-44441-archive.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
