这是固定 0f5bf01a05046169d4fb42322376f767b97bcc83 的一次真实普通开局整合验证；0→44441，同一游戏进程 PID244199，自然 p0 获胜，敌单位、建筑及主厅均为0。不是换码续局、单个 hunk 归因实验或 bootstrap_1 最终验收。

独立 control 为 /workspace/sketch-rts-knight-integrated-0f5bf-control，严格 --detach --no-checkout 后先写 per-worktree sparse patterns 再首次 checkout。docs 只检出冻结 manifest，没有复制旧 tar，未改变 root/main/其他 control。1443 项 src/scripts/tools/config 与确切提交逐字节相同，source.tar.gz 保存 live 全源及实际 d1ae 冻结执行树；184 项冻结 manifest 核验与实际运行 pre/post 均通过。最终 root 的 docs 提交未改变本 detached control。未含 unifiedcare/8041 候选。

Grove p0 v9_knight vs Ember p1 正常冻结 v5；官方 sapphireArchipelago，seed bootstrap_1-knight-v5-official-sapphire-20261015-01，side0、unseen=false、think15。实际游戏仅调用一次 bootstrapGame，未 restore 或注入记忆、命令、资源、人口、HP。tick0 nextId1000、双方500金/3worker/3used8cap、fresh memory absent/null；完整开局逐字段等6f80标准 factory 见证。比赛 maxTicks=Number.MAX_SAFE_INTEGER，未以144000或其他检查时点代替胜负。

保留40个原现场完整 gzip（0、每1200、31996船沉、44441终局），每份含world/nextId/双方全部mem；全部原生恢复全等。4797公开命令、504原生命中逐条保留。27600→28800首岸火短窗 world/id/bothmem/220commands/38hits全等，27945精确事前think输入保存；43200→44400首登陆短窗164commands/225hits全等，43725事前think输入及双方全mem保存；44400→44441末41ticks 0commands/16hits及同winner全等。短窗输入是从原普通局周期完整档严格闭合重建，不能写成原进程现场逐15采样。重演不是额外计分局，不改源。capture-key-window.mts 在首岸火后仅扩展允许≤1200终窗并增加winner输出；游戏运行源始终同一1443项。

实战：27957炮舰2135首射敌岸，29196开始伤楼，31996沉敌空运输船。43725 transport1046公开卸5人；carrier5812余8人43745/43759/43771原生自动落地，不能称同tick13公开joint-unload。终局13人全部活着、无deck且原生sameGround敌岛。43828陆军首次伤楼，15座敌楼由炮舰摧毁7座、陆军摧毁8座，最后44441 witch2593摧毁hall。炮击先清除主要守军；陆军仍实际杀剩余工人及后续新兵、拆余楼，但这不证明重守岸登陆。

最终p0 56单位/27建筑/4满血900主厅；p1 0单位/0建筑/0主厅。永久损失己1/敌38：己raider2245于35616在warship1962甲板被中立dragonWhelp guard-2-1杀；敌26sparkArcher、1ashHexer、1summoner、1priest、8worker、1transport。另清3中立龙。永久尸体、首次致命命中、移除账与native stats完全相符；唯一沉船31996敌transport1515，beforeStep和fatal-hit乘员皆空，我方无船沉。

记录器缺口原样保留：公共cast/useItem可令仍在units中的hp0实体漏过!unit移除事件；发现时真实0已运行，未改活动driver或重启。这4797公开命令实际没有cast/useItem，全部永久尸体都有独立移除事件；命中、尸体、统计、船fatal乘员交叉核对通过。空removal账从未单独作为零死证明。after-command parent事件只是精确事件记录，不能充独立resume fullcheckpoint。

已实际查看本提交native drawWorld的12000全图、28800敌岸炮击和44441敌岛终局图；新facing tracker不还原历史动画，伤害来自原生命中。独立driver审计为 independent-driver-audit.json；无新测试/规则更改。原容器未提交修改仍未恢复。旧e7/36ae/原V2与origin81077续局成绩各归原源，不能拼接。本局只验证当前整合在此已知官方单敌种子能完成；三条路线、v5/v7/v8及六配对、其他官方图和未见生成种子的完整比赛/泛化仍待完成。

主要入口：summary.json、source.json/source.tar.gz、setup.json、launch.json、result.json、frames/、commands.jsonl/hits.jsonl/events.jsonl、final-inventory.json、full-frame-restore-audit.json、key-*/inputs/、first-army-input-summary.json、recorder-limits.json。完整驱动和所有只读审计 helper 一并保留。
