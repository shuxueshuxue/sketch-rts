import { readFileSync, writeFileSync, appendFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';

const D = '/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015';
const W = '/workspace/sketch-rts-knight-integrated-0f5bf-control';
const cap = JSON.parse(readFileSync(`${D}/source.json`, 'utf8'));
for (const path of ['frames', 'launch.json', 'result.json', 'commands.jsonl', 'hits.jsonl', 'events.jsonl'])
  assert.equal(existsSync(`${D}/${path}`), false, `Never overwrite prior ordinary game evidence: ${path}`);
const hash = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex');
const json = (value: any) => JSON.parse(JSON.stringify(value));
const imp = (p: string) => import(pathToFileURL(`${W}/${p}`).href);
const sourceCheck = () => {
  const bad = Object.entries(cap.files).filter(([p, h]) => hash(`${W}/${p}`) !== h).map(([p]) => p);
  assert.deepEqual(bad, []);
  assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: W, encoding: 'utf8' }).trim(), cap.head);
  assert.equal(execFileSync('git', ['status', '--porcelain', '--untracked-files=all'], { cwd: W, encoding: 'utf8' }), '');
  return { exact: true, files: Object.keys(cap.files).length, head: cap.head };
};
const sourcePre = sourceCheck();
const [{ bootstrapGame, bootstrapMatches }, { runAiGameLoop }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { snapshotGame }, { RULES_VERSION }] = await Promise.all([
  imp('src/ai/bootstrap_1/benchmark.ts'), imp('src/ai/game-runner.ts'), imp('src/ai/planner-context.ts'),
  imp('scripts/bootstrap_1-planner.ts'), imp('src/shared/sim.ts'), imp('src/shared/rules-version.ts'),
]);
assert.equal(RULES_VERSION, 2);
const selection = cap.selection;
const match = bootstrapMatches(selection.seed, [selection.mapId], Number.MAX_SAFE_INTEGER, selection.unseen).find((m: any) =>
  m.subject === selection.subject && m.side === selection.side && m.agents.p0.race === selection.race &&
  Object.values(m.agents).slice(1).map((a: any) => a.version).join('+') === selection.opponents.join('+'));
assert.ok(match);
assert.equal(match.thinkInterval, 15);
assert.equal(match.unseen, false);
assert.deepEqual(Object.keys(match.agents), ['p0', 'p1']);
assert.deepEqual(match.agents.p1, { version: 'v5', versionLabel: 'v5', race: 'ember', controller: 'external-agent', team: 'b' });
// This is the only gameplay factory invocation. Never restore, seed policy memory,
// alter entity state, filter planner commands, or call diagnostic policy queries.
const g = bootstrapGame(match);
const mem = createAiMemoryProvider();
const owners = Object.keys(match.agents);
const memories = () => Object.fromEntries(owners.map(owner => [owner, mem.get(owner) ?? null]));
assert.equal(g.tick, 0);
assert.equal(g.nextId, 1000);
assert.equal(g.map.id, 'sapphireArchipelago');
assert.deepEqual(memories(), { p0: null, p1: null });
const initial = Object.fromEntries(owners.map(owner => [owner, { gold: g.players[owner].gold,
  supplyUsed: g.players[owner].supplyUsed, supplyCap: g.players[owner].supplyCap,
  units: g.units.filter((u: any) => u.owner === owner).map((u: any) => u.kind) }]));
for (const state of Object.values(initial) as any[]) assert.deepEqual(state, { gold: 500, supplyUsed: 3, supplyCap: 8, units: ['worker', 'worker', 'worker'] });
const opening = json(snapshotGame(g));
const baselinePath = '/tmp/bootstrap-knight-6f80a-ordinary-20261015/knight-6f80a-ordinary-opening.json';
const baseline = JSON.parse(readFileSync(baselinePath, 'utf8'));
const openingComparison = { baseline: baselinePath, baselineSHA256: hash(baselinePath), worldEqual: isDeepStrictEqual(opening, baseline.snapshot), nextIdEqual: g.nextId === baseline.nextId, initialEqual: isDeepStrictEqual(initial, baseline.initial) };
assert.ok(openingComparison.worldEqual && openingComparison.nextIdEqual && openingComparison.initialEqual);
const frozenRoot = frozenPolicyRoot();
const frozenCheck = () => {
  assert.equal(frozenPolicyManifest.rulesVersion, 2);
  assert.equal(frozenPolicyManifest.revision, cap.frozenRevision);
  const bad = Object.entries(cap.frozenFiles).filter(([p, h]) => hash(`${frozenRoot}/${p}`) !== h).map(([p]) => p);
  assert.deepEqual(bad, []);
  return { exact: true, files: Object.keys(cap.frozenFiles).length, revision: cap.frozenRevision };
};
const frozenPre = frozenCheck();
const planner = await createBootstrapCommandPlanner(mem);
const started = performance.now(), cpuStart = process.cpuUsage();
const provenance = { classification: 'Actual ordinary tick0 both-normal-AI integration game at clean exact0f5bf01a. No resumed state, manual gameplay orders, resource/population/entity edits or seeded memories. Natural native match winner, no arbitrary tick acceptance horizon. One known official development seed; not three-route/final generalization acceptance.',
  source: `${D}/source.json`, sourceArchiveSHA256: cap.sourceArchiveSHA256, sourceHead: cap.head, setup: match, initial,
  openingComparison, frozenPre, driverSHA256: hash(`${D}/run-ordinary.mts`), sourcePreparation: `${D}/setup.json` };
const rows: any[] = [], shipLosses: any[] = [], removals: any[] = [], transitions: any[] = [];
let commands = 0, hits = 0, beforeUnits = new Map<string, any>();
mkdirSync(`${D}/frames`);
for (const file of ['commands.jsonl', 'hits.jsonl', 'events.jsonl']) writeFileSync(`${D}/${file}`, '');
const slim = (u: any) => ({ id: u.id, owner: u.owner, kind: u.kind, hp: u.hp, maxHp: u.maxHp,
  x: u.x, y: u.y, deck: u.deck ? json(u.deck) : null, expiresTick: u.expiresTick ?? null, isShip: !!u.sailing });
let observedUnits = new Map<string, any>(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
function recordChanges(phase: string) {
  const now = new Map<string, any>(g.units.map((u: any) => [u.id, u]));
  let lostShip = false;
  for (const [id, before] of observedUnits) {
    const unit = now.get(id);
    if (!unit) {
      const event = { tick: g.tick, phase, event: 'unit-removal', unit: before, permanent: before.expiresTick === null };
      removals.push(event);
      appendFileSync(`${D}/events.jsonl`, JSON.stringify(event) + '\n');
      if (before.isShip) {
        const loss = { tick: g.tick, phase, event: 'ship-removal', ship: before,
          passengers: [...beforeUnits.values()].filter(u => u.deck?.shipId === id),
          observedBeforePassengers: [...observedUnits.values()].filter(u => u.deck?.shipId === id) };
        shipLosses.push(loss);
        appendFileSync(`${D}/events.jsonl`, JSON.stringify(loss) + '\n');
        lostShip = true;
      }
    } else if ((before.deck?.shipId ?? null) !== (unit.deck?.shipId ?? null)) {
      const event = { tick: g.tick, phase, event: 'deck-parent-change', before, after: slim(unit) };
      transitions.push(event);
      appendFileSync(`${D}/events.jsonl`, JSON.stringify(event) + '\n');
    }
  }
  observedUnits = new Map(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
  return lostShip;
}
function summary() {
  return Object.fromEntries(owners.map(owner => [owner, { gold: g.players[owner].gold, supplyUsed: g.players[owner].supplyUsed,
    supplyCap: g.players[owner].supplyCap, units: g.units.filter((u: any) => u.owner === owner && u.hp > 0).length,
    buildings: g.buildings.filter((b: any) => b.owner === owner && b.hp > 0).length,
    halls: g.buildings.filter((b: any) => b.owner === owner && b.hp > 0 && b.kind === 'townHall').map((b: any) => ({ id: b.id, hp: b.hp, x: b.x, y: b.y })),
    policy: { naval: json(mem.get(owner)?.naval ?? null) } }]));
}
function publish(done = false) {
  const cpu = process.cpuUsage(cpuStart);
  writeFileSync(`${D}/result.json.tmp`, JSON.stringify({ provenance, pid: process.pid, startedAtTick: 0, end: g.tick,
    finished: done, completed: !!g.match.winner, winner: g.match.winner, elapsedMs: performance.now() - started,
    cpuMs: (cpu.user + cpu.system) / 1000, commandCount: commands, hitCount: hits, sourcePre,
    sourcePost: done ? sourceCheck() : null, frozenPost: done ? frozenCheck() : null,
    finalStats: json(g.match.stats), final: summary(), rows, shipLosses, removals, transitions }) + '\n');
  renameSync(`${D}/result.json.tmp`, `${D}/result.json`);
}
function save(reason: string) {
  const state = { tick: g.tick, snapshot: snapshotGame(g), nextId: g.nextId, memories: memories(),
    memoryLifecycle: g.tick === 0 ? 'Null means absent fresh provider memory before first think; no policy memory seeded.' : undefined };
  writeFileSync(`${D}/frames/${g.tick}.json.gz`, gzipSync(JSON.stringify(state) + '\n'));
  rows.push({ tick: g.tick, reason, stats: json(g.match.stats), players: summary(), nextId: g.nextId,
    worldFrame: `frames/${g.tick}.json.gz` });
  publish();
}
g.observer = { hit(source: any, target: any, damage: number, before: number) {
  hits++;
  const sinkingPassengers = target.sailing && target.hp <= 0 ? g.units.filter((u: any) => u.deck?.shipId === target.id).map(slim) : undefined;
  appendFileSync(`${D}/hits.jsonl`, JSON.stringify({ tick: g.tick, sourceId: source.id, sourceKind: source.kind,
    sourceOwner: source.owner, targetId: target.id, targetKind: target.kind, targetOwner: target.owner,
    damage, before, after: target.hp, sinkingPassengers }) + '\n');
} };
writeFileSync(`${D}/launch.json`, JSON.stringify({ pid: process.pid, tick: g.tick, startedAtUtc: new Date().toISOString(), sourcePre,
  frozenPre, openingComparison, actualFactoryStart: true, driverSHA256: provenance.driverSHA256 }, null, 2) + '\n');
save('actual ordinary factory tick0 before first think');
console.log(JSON.stringify({ event: 'actual-start', pid: process.pid, tick: g.tick, head: cap.head, sourcePre, frozenPre, initial }));
runAiGameLoop({ ...match, maxTicks: Number.MAX_SAFE_INTEGER, game: g, commandPlanner: planner }, {
  onCommand({ tick, owner, source, scriptId, command }: any) {
    commands++;
    appendFileSync(`${D}/commands.jsonl`, JSON.stringify({ tick, owner, source, scriptId, command }) + '\n');
    recordChanges('after-command; event only, not an independent resume checkpoint');
  },
  beforeStep() {
    beforeUnits = new Map(g.units.filter((u: any) => u.hp > 0).map((u: any) => [u.id, slim(u)]));
  },
  onStep() {
    const lostShip = recordChanges('after-step');
    if (g.tick % 1200 === 0 || g.match.winner || lostShip) save(lostShip ? 'ship removal; restore validity audited separately' : '1200 periodic or natural terminal');
    if (g.tick % 1200 === 0) console.log(JSON.stringify({ event: 'progress', pid: process.pid, tick: g.tick,
      stats: json(g.match.stats), players: summary() }));
  },
});
if (rows.at(-1)?.tick !== g.tick) save('natural terminal');
publish(true);
console.log(JSON.stringify({ event: 'natural-complete', pid: process.pid, tick: g.tick, winner: g.match.winner,
  sourcePost: sourceCheck(), frozenPost: frozenCheck(), stats: json(g.match.stats) }));
