import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const D='/workspace/.playtest/bootstrap-knight-integrated-0f5bf-ordinary0-20261015',W='/workspace/sketch-rts-knight-integrated-0f5bf-control';
const report=JSON.parse(readFileSync(`${D}/result.json`,'utf8'));assert.ok(report.finished&&report.completed&&report.winner==='p0');
const cap=JSON.parse(readFileSync(`${D}/source.json`,'utf8')),hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourceCheck=()=>Object.entries(cap.files).every(([p,h])=>hash(`${W}/${p}`)===h);assert.ok(sourceCheck());
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href),[{sameGround,setBuildingBodies},{unitMover}]=await Promise.all([imp('src/shared/terrain.ts'),imp('src/shared/catalog.ts')]);
const frame=(tick:number)=>JSON.parse(gunzipSync(readFileSync(`${D}/frames/${tick}.json.gz`)).toString());
const opening=frame(0).snapshot,final=frame(report.end).snapshot,enemyHall=opening.buildings.find((b:any)=>b.owner==='p1'&&b.kind==='townHall');
setBuildingBodies(final.map,[...final.buildings,...(final.obstacles??[])]);
const commands=readFileSync(`${D}/commands.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));
const hits=readFileSync(`${D}/hits.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));
const events=readFileSync(`${D}/events.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));
const removalEvents=events.filter(e=>e.event==='unit-removal'),unitMetadata=new Map<string,any>();
for(const path of readdirSync(`${D}/frames`).filter(p=>p.endsWith('.json.gz'))){const s=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${path}`)).toString()).snapshot;for(const u of s.units)unitMetadata.set(u.id,{id:u.id,kind:u.kind,owner:u.owner,expiresTick:u.expiresTick??null});}
for(const e of removalEvents)unitMetadata.set(e.unit.id,e.unit);
const count=(a:any[],key:(v:any)=>string)=>Object.fromEntries([...new Set(a.map(key))].map(k=>[k,a.filter(v=>key(v)===k).length]));
const permanentCorpses=final.corpses.filter((c:any)=>{const metadata=unitMetadata.get(c.unitId);assert.ok(metadata,`Missing expiration metadata for corpse ${c.unitId}`);return metadata.expiresTick===null;});
const casualtyRows=permanentCorpses.map((c:any)=>({corpse:c,metadata:unitMetadata.get(c.unitId),removalEvent:removalEvents.find(e=>e.unit.id===c.unitId)??null,
 firstFatalHit:hits.find(h=>h.targetId===c.unitId&&h.before>0&&h.after<=0)??null}));
const missingRemovalEvents=casualtyRows.filter((r:any)=>!r.removalEvent);
const shipFatals=hits.filter(h=>h.before>0&&h.after<=0&&Object.hasOwn(h,'sinkingPassengers'));
const enemyLandingEvents=events.filter(e=>e.event==='deck-parent-change'&&e.after.owner==='p0'&&e.after.kind!=='worker'&&e.before.deck&&!e.after.deck&&unitMover(e.after.kind)==='land'&&sameGround(final.map,e.after,enemyHall));
const landingIds=[...new Set(enemyLandingEvents.map(e=>e.after.id))];
const landingParty=landingIds.map(id=>{const u=final.units.find((v:any)=>v.id===id);return{id,landingEvents:enemyLandingEvents.filter(e=>e.after.id===id).map(e=>({tick:e.tick,phase:e.phase,sourceShip:e.before.deck.shipId,x:e.after.x,y:e.after.y,hp:e.after.hp})),final:u?{kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:u.deck??null,enemyLand:!u.deck&&sameGround(final.map,u,enemyHall)}:null,death:casualtyRows.find((r:any)=>r.corpse.unitId===id)??null};});
const ownerInventory=Object.fromEntries(['p0','p1'].map(owner=>{const units=final.units.filter((u:any)=>u.owner===owner&&u.hp>0),buildings=final.buildings.filter((b:any)=>b.owner===owner&&b.hp>0);return[owner,{units:units.map((u:any)=>({id:u.id,kind:u.kind,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:u.deck??null,order:u.order})),unitKinds:count(units,(u:any)=>u.kind),buildings:buildings.map((b:any)=>({id:b.id,kind:b.kind,hp:b.hp,maxHp:b.maxHp,x:b.x,y:b.y})),halls:buildings.filter((b:any)=>b.kind==='townHall').map((b:any)=>({id:b.id,hp:b.hp,x:b.x,y:b.y}))}];}));
const buildingFirstHits=hits.filter(h=>h.sourceOwner==='p0'&&h.targetOwner==='p1'&&h.targetId.startsWith('building-'));
const buildingDeaths=buildingFirstHits.filter(h=>h.before>0&&h.after<=0);
const publicDamageCommands=commands.filter(c=>c.command.type==='cast'||c.command.type==='useItem');
const reconciliation=Object.fromEntries(['p0','p1','neutral'].map(owner=>{const corpseRows=casualtyRows.filter((r:any)=>r.corpse.owner===owner),fatalPassengers=shipFatals.flatMap(h=>h.sinkingPassengers??[]).filter((p:any)=>p.owner===owner&&p.expiresTick===null);
 return[owner,{nativeUnitsLost:final.match.stats.unitsLost[owner],permanentCorpses:corpseRows.length,corpseKinds:count(corpseRows,(r:any)=>r.corpse.kind),fatalSinkingPassengers:fatalPassengers,recordedPermanentRemovals:removalEvents.filter(e=>e.unit.owner===owner&&e.permanent).length,corpsesPlusFatalPassengersEqualNative:corpseRows.length+fatalPassengers.length===final.match.stats.unitsLost[owner]}];}));
assert.ok(Object.values(reconciliation).every((r:any)=>r.corpsesPlusFatalPassengersEqualNative));
assert.equal(missingRemovalEvents.length,0);
assert.equal(publicDamageCommands.length,0);
assert.equal(ownerInventory.p1.units.length,0);assert.equal(ownerInventory.p1.buildings.length,0);
assert.ok(landingParty.every((p:any)=>p.final?.enemyLand&&!p.death));
assert.ok(sourceCheck());
const output={classification:'Read-only complete ordinary0 final native inventory and casualty reconciliation, using actual gz, all commands/hits/events and native ground query. No simulation, world edits or policy queries. The known public-command logger gap is retained; here no public cast/useItem command occurred and every permanent corpse has its logged removal.',source:cap.head,sourcePre:true,sourcePost:true,pid:report.pid,start:0,end:report.end,winner:report.winner,stats:final.match.stats,reconciliation,missingRemovalEvents,publicDamageCommands,
 firstHostileHit:hits.find(h=>['p0','p1'].includes(h.sourceOwner)&&['p0','p1'].includes(h.targetOwner)&&h.sourceOwner!==h.targetOwner),firstEnemyBuildingHit:buildingFirstHits[0],firstGroundArmyEnemyBuildingHit:buildingFirstHits.find(h=>!['bombardShip','warship','cutter','transport','carrier'].includes(h.sourceKind)),buildingDeaths,
 landingEventsByTick:count(enemyLandingEvents,(e:any)=>String(e.tick)),firstArmyLanding:enemyLandingEvents[0],landingParty,shipFatalHits:shipFatals,shipLosses:report.shipLosses,casualties:casualtyRows,final:ownerInventory};
writeFileSync(`${D}/final-inventory.json`,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({...output,final:{p0:{units:ownerInventory.p0.units.length,unitKinds:ownerInventory.p0.unitKinds,buildings:ownerInventory.p0.buildings.length,halls:ownerInventory.p0.halls},p1:{units:ownerInventory.p1.units.length,buildings:ownerInventory.p1.buildings.length}},casualties:undefined,buildingDeaths:buildingDeaths.length,landingParty:landingParty.length},null,2));
