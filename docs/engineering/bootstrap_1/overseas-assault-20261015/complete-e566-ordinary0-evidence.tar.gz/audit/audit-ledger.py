from pathlib import Path
from collections import Counter, defaultdict
import gzip, json, hashlib

raw = Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016')
out = Path('/workspace/.playtest/bootstrap-combined-e566-terminal-audit-20261016')
prefix = raw / 'game'
read = lambda p: json.loads(Path(p).read_text())
frame = lambda tick: json.loads(gzip.decompress((raw / f'game.frames/{tick}.json.gz').read_bytes()))
stream = lambda name: [json.loads(line) for line in (raw / f'game-{name}.jsonl').read_text().splitlines() if line]
report = read(str(prefix)+'.json')
assert report['result']['completed'] and report['result']['tick'] == 43714 and report['result']['winner'] == 'p0'
final = frame(43714); snapshot = final['snapshot']
hits, deaths, events, commands, plans = [stream(n) for n in ['native-hits','native-deaths','native-events','commands','plans']]
assert [h['index'] for h in hits] == list(range(len(hits)))
assert [c['index'] for c in commands] == list(range(len(commands)))
hit_by_index = {h['index']: h for h in hits}
epochs = defaultdict(list); latest = {}; status_counts = Counter(); fatal_references = []
for event in deaths:
    if event['type'] == 'native-unit-terminal':
        body = event.get('atObservation') or event['previous']
        assert event['id'] == body['id']
        assert event['permanent'] == ('expiresTick' not in body)
        confirmation = event['confirmation']
        record = {'id':event['id'],'owner':body['owner'],'kind':body['kind'],
                  'permanent':event['permanent'],'expiresTick':body.get('expiresTick'),
                  'terminalClass':event['terminalClass'],'firstTick':event['tick'],
                  'confirmation':confirmation,'confirmedRemoved':confirmation=='absent-at-native-boundary',
                  'returnedPositive':False,'observedAs':event['observedAs'],
                  'firstStage':event['stage'],'lastNativeHitIndex':(event.get('lastNativeHit') or {}).get('index')}
        epochs[event['id']].append(record); latest[event['id']] = record
        native_fatal = event['evidence'].get('nativePositiveToNonpositiveHit')
        if native_fatal:
            assert native_fatal == hit_by_index[native_fatal['index']]
            assert native_fatal['target'] == event['id'] and native_fatal['hpBefore'] > 0 and native_fatal['hpAfter'] <= 0
            fatal_references.append({'id':event['id'],'hitIndex':native_fatal['index']})
    else:
        assert event['type'] == 'terminal-status-update'
        record = latest[event['id']]; status_counts[event['status']] += 1
        if event['status'] == 'returned-positive':
            record['returnedPositive'] = True; record['confirmedRemoved'] = False
        elif event['status'] == 'native-removal-after-nonpositive':
            record['confirmedRemoved'] = True; record['confirmation'] = event['status']
        else:
            raise AssertionError('Unknown terminal status '+event['status'])

confirmed = {id:r for id,r in latest.items() if r['terminalClass']=='death-observed' and r['confirmedRemoved'] and not r['returnedPositive']}
provisional = {id:r for id,r in latest.items() if r['terminalClass']=='death-observed' and not r['confirmedRemoved'] and not r['returnedPositive']}
expired = {id:r for id,r in latest.items() if r['terminalClass']=='lifetime-expiry-eligible-removal' and not r['returnedPositive']}
unknown = {id:r for id,r in latest.items() if r['terminalClass']=='removal-cause-unconfirmed' and not r['returnedPositive']}
returned = {id:r for id,r in latest.items() if r['returnedPositive']}
corpses = snapshot.get('corpses',[])
assert len({c['unitId'] for c in corpses}) == len(corpses)
corpse_by_id = {c['unitId']:c for c in corpses}
counts = Counter(r['owner'] for r in confirmed.values())
native = snapshot['match']['stats']['unitsLost']
corpse_counts = Counter(c['owner'] for c in corpses)
assert not provisional and not expired and not unknown and not returned
assert set(confirmed) == set(corpse_by_id)
for id,record in confirmed.items():
    corpse=corpse_by_id[id]
    assert corpse['owner']==record['owner'] and corpse['kind']==record['kind']
    assert not any(u['id']==id for u in snapshot['units'])
for owner in set(native)|set(counts)|set(corpse_counts):
    assert counts[owner] == native.get(owner,0) == corpse_counts[owner]

samples=[]; historical=[]
oldroot=Path('/tmp/bootstrap-archer-double-v8-courier-v2-20261015')
oldreport=read(oldroot/'ordinary.json'); oldrows={r['tick']:r for r in oldreport['rows']}
for row in report['rows']:
    saved=frame(row['tick']); s=saved['snapshot']; checks={}
    for owner in ['p0','p1','p2']:
        units=[u for u in s['units'] if u['owner']==owner]
        buildings=[b for b in s['buildings'] if b['owner']==owner]
        p=row['players'][owner]
        checks[owner] = p['policy']==saved['memories'][owner] and p['units']==len(units) and p['buildings']==len(buildings) and p['permanentUnits']==sum('expiresTick' not in u for u in units) and p['gold']==s['players'][owner]['gold'] and p['unitsLost']==s['match']['stats']['unitsLost'][owner]
    cs=Counter(c['owner'] for c in s.get('corpses',[])); ns=s['match']['stats']['unitsLost']
    corpse_exact=all(cs[o]==ns.get(o,0) for o in set(cs)|set(ns))
    assert all(checks.values()) and corpse_exact
    samples.append({'tick':row['tick'],'reportWorldAll3memReconcile':checks,'completeCorpsesEqualNativeCounter':corpse_exact})
    oldfile=oldroot/f'ordinary.json.frames/{row["tick"]}.json'
    if oldfile.exists():
        old=read(oldfile); mem={o:oldrows[row['tick']]['players'][o]['policy'] for o in ['p0','p1','p2']} if row['tick'] in oldrows else None
        historical.append({'tick':row['tick'],'world':old['snapshot']==s,'nextId':old['nextId']==saved['nextId'],'all3mem':{o:mem[o]==saved['memories'][o] for o in mem} if mem else 'Old0 raw has no memory witness; new freshnull default separately verified','setup':oldreport['setup']==saved['setup']})

for h in hits:
    assert h['positiveToNonpositive'] == (h['hpBefore']>0 and h['hpAfter']<=0)
    assert h['targetAtObservation']['hp']==h['hpAfter']
    if h['commandIndex'] is not None:
        c=commands[h['commandIndex']]
        assert c['tick']==h['tick']

summary={'classification':'Independent reconstruction from actual new e566 true0 raw streams/corpses/full snapshots; provisional HP0 is never counted as permanent loss without removal confirmation',
 'source':report['head'],'result':report['result'],'counts':{'hits':len(hits),'acceptedCommands':len(commands),'plans':len(plans),'deathStreamRows':len(deaths),'nativeEvents':len(events),'confirmedRemoved':len(confirmed),'provisionalPending':len(provisional),'expiryEligibleRemoved':len(expired),'unconfirmedRemoval':len(unknown),'returnedPositiveFinal':len(returned),'corpses':len(corpses),'nativeUnitsLost':native,'statusUpdateCounts':dict(status_counts)},
 'byOwner':{o:{'nativeLoss':native.get(o,0),'confirmedRemoved':counts[o],'corpses':corpse_counts[o],'permanent':sum(r['owner']==o and r['permanent'] for r in confirmed.values()),'temporary':sum(r['owner']==o and not r['permanent'] for r in confirmed.values()),'neutralLossCounter':snapshot['match']['stats']['unitsKilledByNeutral'].get(o,0)} for o in ['p0','p1','p2','neutral']},
 'terminal':{o:{'units':sum(u['owner']==o for u in snapshot['units']),'buildings':sum(b['owner']==o for b in snapshot['buildings'])} for o in ['p0','p1','p2']},
 'allNativeLossLedgerAndCorpseExact':True,'allSamplesReconcile':True,'sampleCount':len(samples),
 'historicalComparableSampleCount':len(historical),'allHistoricalWorldIdSetupEqual':all(h['world'] and h['nextId'] and h['setup'] for h in historical),'allHistoricalAvailable3memEqual':all(all(h['all3mem'].values()) for h in historical if isinstance(h['all3mem'],dict)),
 'fatalHitReferenceCount':len(fatal_references),'allHitIndicesAndCommandPhasesValid':True,'shipLossRows':len(stream('ship-losses')),
 'limits':['Observer hit is the actual native damage callback, not proof of sole tactical cause.','This game has no confirmed temporary deaths/expiries/unknown removals; that zero observation is not a universal ledger correctness proof.','No ship loss was recorded in this land case; recursive drowning handling is not exercised.','Historical equality covers saved checkpoints only; this actual new0 remains independently attributed to e566.','No new seed/generalization/three-family final acceptance follows.']}
(out/'ledger-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(out/'confirmed-death-ledger.json').write_text(json.dumps({'confirmed':list(confirmed.values()),'provisional':provisional,'expired':expired,'unknown':unknown,'returned':returned,'epochs':dict(epochs),'fatalReferences':fatal_references},ensure_ascii=False,indent=2)+'\n')
(out/'all-sample-and-history-checks.json').write_text(json.dumps({'samples':samples,'historical':historical},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
