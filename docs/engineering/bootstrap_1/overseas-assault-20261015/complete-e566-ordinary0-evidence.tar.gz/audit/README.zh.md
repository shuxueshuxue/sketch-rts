# e566 实际普通0：完整证据与终窗闭合

固定控制树 `/workspace/sketch-rts-bootstrap-combined-ordinary0-control`，
HEAD `e5663c338f9c544a5e65a66a6ed278d35f74a8f4`。
根实际启动的本局从0自然到43714，p0胜；这是该组合源码自己的新普通0，不能借旧5f成绩。

场景为已开发 seed `bootstrap_1-unseen-archer-v8-v8-20261015-01`，原pineshade工厂生成
ladder4608²，Grove v9_archer physicalside1，对正常冻结v8 Ember+Grove联盟。
三方均500金、3人口/8上限、3工/1厅、无升级，首次think前记忆各null。
factory参数unseen=true表示生成布局，此seed已经开发，不能计新泛化。

独立源审对1462源文件、497冻结归档文件及184 manifest逐字节/Git对象/前后记录核验。
规则2、manifest0490未变。运行时冻结临时目录已按进程退出清理，独审核完整归档及既有前后实际哈希，
未伪称重读已删除目录；唯一恢复窗还重新独立解出同497文件并前后核。

整局有3505次native hits、41213条实际public commands、8745次owner plans。
226行death stream分别是219终端实体记录与7次稍后原生移除确认。
本审按ID追踪，HP0等待cleanup只作provisional；最终219确认移除全部对应完整219尸体和原生unitsLost：
p0=56、p1=76、p2=68、neutral=19。本局全部永久单位；最终临时到期、未知移除、返回正血及pending均0。
这不证明未发生在本局的临时到期或船沉逻辑；本局没有船沉记录。
p0仍有1个野怪损失；终局41兵、4厅、29楼，p1/p2均0兵0楼。

74份完整sample的report/world/三memory和尸体统计均闭合。与原5f可比的74个world/id/setup
全部逐值相等，73个有旧策略记忆见证的sample三memory也相等；原0档无memory字段，
仅新0的freshnull经默认provider与factory见证确认。相等范围是采样点，不能泛称两局每tick完全相等。

根授权的唯一短恢复为43200真实after-step/before-think全档到自然43714，共514个原生tick。
严格restore全world/id/三memory/setup，然后完整三方AI与原封只读observer；
终world/id/三memory/setup、163条完整public commands、27条完整native hits全部逐值相等，
含globalindex与targetAtObservation，不剔除有意义字段。窗口无新单位死亡，只发生剩余建筑终结，
因此该窗口不替代对前期死亡事件的整局账本审计。

`native-ordinary0-{16200,24000,43714}.png` 由新0真实完整档经本源native drawWorld渲染。
16200局部与43714全图已亲看：前者仍有近战压入主厅线与后方医师，后者敌方全部兵楼已灭。
静态fresh facing不是历史动画重建，没有预测或目标圈叠层。

初次launch在游戏创建前因ESM/CJS loader失败，其原log、预封driver和独立loader correction保留；
成功新0与该失败明确分开。没有改任何原raw、driver、固定源或frozen；包内保留它们原字节。

另附独立勘误：7905的emberRavager1079/1322属于另一个Ember召唤/greystonePass/seed案例。
不能把“10200续局未从0覆盖此前决策”写成它们属于本弓手局的早期因果或跨局收敛。
该召唤案例1322变更仍待自身全局评估，原care封包保持不变。

本包只证明这一新普通0及唯一终窗。三路线全部单敌/六配对、官方图和真正未见种子的最终验收
仍未完成；原故障容器未提交修改的恢复缺口仍保留。后续真实56损失的可复用问题另作只读诊断，
不把本次胜利或某伤兵短窗生存当作护理/老兵保存已完成。
