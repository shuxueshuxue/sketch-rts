import {createCanvas} from '@napi-rs/canvas';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const source='/workspace/sketch-rts-bootstrap-combined-ordinary0-control';
const prefix='/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game';
const out='/workspace/.playtest/bootstrap-combined-e566-terminal-audit-20261016';
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
for(const tick of [16200,24000,43714]){
 const input=`${prefix}.frames/${tick}.json.gz`,{snapshot}=JSON.parse(gunzipSync(readFileSync(input)).toString());
 const local=tick===16200,width=1280,height=1320,zoom=local?1.5:1280/4608;
 const view={x:local?1150:0,y:local?3300:0,width,height,zoom};
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');
 drawWorld({ctx:ctx as any,snapshot,view,now:tick*50,selectedIds:new Set(),facing:new UnitFacingTracker(),labels:{unitKind:String,mercenaryStock:String}});
 const counts=Object.fromEntries(['p0','p1','p2'].map(owner=>[owner,{units:snapshot.units.filter((u:any)=>u.owner===owner).length,buildings:snapshot.buildings.filter((b:any)=>b.owner===owner).length,halls:snapshot.buildings.filter((b:any)=>b.owner===owner&&b.kind==='townHall').length}]));
 ctx.fillStyle='rgba(0,0,0,.93)';ctx.fillRect(0,height-62,width,62);ctx.fillStyle='white';ctx.font='21px sans-serif';
 ctx.fillText(`e566 actual ordinary0 tick${tick}; p0 ${counts.p0.units}u/${counts.p0.halls}h; p1 ${counts.p1.units}u/${counts.p1.buildings}b; p2 ${counts.p2.units}u/${counts.p2.buildings}b`,14,height-35);
 ctx.fillText(`${local?'Local native view':'Full-map native view'}; fresh facing; actual saved world; no future/target overlays`,14,height-10);
 const output=`${out}/native-ordinary0-${tick}.png`;writeFileSync(output,canvas.toBuffer('image/png'));
 writeFileSync(output+'.json',JSON.stringify({classification:'Native drawWorld of actual new e566 ordinary0 checkpoint; static fresh facing, not historical animation reconstruction; no simulation stepped.',source,head:'e5663c338f9c544a5e65a66a6ed278d35f74a8f4',input,tick,view,counts},null,2)+'\n');console.log(output);
}
