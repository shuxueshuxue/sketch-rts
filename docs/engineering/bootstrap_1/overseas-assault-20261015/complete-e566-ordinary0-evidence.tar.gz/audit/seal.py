from pathlib import Path
import hashlib, io, json, tarfile
raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016')
out=Path('/workspace/.playtest/bootstrap-combined-e566-terminal-audit-20261016')
archive=out/'complete-e566-ordinary0-evidence.tar.gz'
index=out/'EVIDENCE-INDEX.json';seal=out/'EVIDENCE-SEAL.json'
if any(p.exists() for p in [archive,index,seal]): raise SystemExit('Preserve existing closed evidence')
files=[]
for base,tag in [(raw,'ordinary0'),(out,'audit')]:
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.is_symlink() and 'node_modules' not in p.relative_to(base).parts:
   files.append((p,tag+'/'+str(p.relative_to(base))))
rows=[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,name in files]
index.write_text(json.dumps({'classification':'Complete independently attributed e566 actual ordinary0 plus only43200→43714 native closure; developed seed, not final bootstrap acceptance','payloadFiles':len(rows),'files':rows},ensure_ascii=False,indent=2)+'\n')
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p,name in files+[(index,'EVIDENCE-INDEX.json')]:
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())=={r['path'] for r in rows}|{'EVIDENCE-INDEX.json'}
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert json.loads(tar.extractfile('EVIDENCE-INDEX.json').read())['files']==rows
for (p,name),row in zip(files,rows): assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(rows),'archiveMembersIncludingIndex':len(rows)+1,'archiveIndexSHA256':hashlib.sha256(index.read_bytes()).hexdigest(),'allArchivePayloadVerified':True,'allOriginalRawAndAuditBytesUnchangedDuringSeal':True}
seal.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
