from pathlib import Path
import json,hashlib,shutil,tarfile,tempfile,datetime
repo=Path('/workspace/sketch-rts-bootstrap-resume'); root=repo/'.playtest/overseas-assault-20261015'; control=Path('/workspace/sketch-rts-coastal-escape-control')
out=repo/'docs/engineering/bootstrap_1/overseas-assault-20261015/coastal-escape-evidence.tar.gz'
stage=Path(tempfile.mkdtemp(prefix='coastal-escape-evidence-',dir='/tmp'))/'coastal-escape-evidence'; stage.mkdir()
def copy(src,dest):
 target=stage/dest;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
def write(dest,obj):
 target=stage/dest;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(obj,ensure_ascii=False,indent=2))
selected=['coastal-death-fixed.json','coastal-death-fixed.log','coastal-death-fixed.ts','coastal-death-fixed-executed.ts','coastal-death-fixed-source.json','coastal-death-fixed-raw-inline-references.json','coastal-death-replay-equivalence.json','coastal-final-runtime-source.json','coastal-final-restore-preflight.json','coastal-escape-runtime-source.json','coastal-escape-candidate-source.json','coastal-escape-baseline-preparation.json','coastal-escape-restore-preflight.json','coastal-escape-restore-preflight.ts','coastal-escape-query.ts','coastal-escape-query.json','coastal-escape-query.log','coastal-escape-query-cost.json','coastal-escape-micro.ts','coastal-escape-full-ai.ts','coastal-escape-full-ai.json','coastal-escape-full-ai.log','coastal-escape-full-ai-source.json','coastal-escape-full-ai-summary.json','coastal-escape-micro-long-equivalence.json','coastal-escape-pretrigger-equivalence.json','coastal-escape-production.patch','coastal-escape-red.log','coastal-escape-green.log','coastal-escape-types.log','coastal-escape-findings.zh.md','coastal-query-profile.test.ts','coastal-query-profile.json','coastal-query-profile.log','coastal-escape-166425.json','coastal-escape-166425.png','coastal-escape-166425-render.log','coastal-escape-166800.json','coastal-escape-166800.png','coastal-escape-166800-render.log','coastal-escape-observer.ts','coastal-final-observer.ts','safe-battery-source.json']
selected.extend(['coastal-escape-midrestore.ts','coastal-escape-midrestore.json','coastal-escape-midrestore.log','coastal-escape-midrestore-source.json','coastal-return-death-fixed.ts','coastal-return-death-fixed.json','coastal-return-death-fixed.log','coastal-return-death-fixed-source.json','coastal-return-death-summary.json','coastal-return-provocation.ts','coastal-return-provocation.json','coastal-return-provocation.log','coastal-return-first-hit.json','coastal-return-first-hit.png','coastal-return-first-hit-render.log'])
for mode in ['short-avoid','short-fire','back-then-long']:
 selected.extend(['coastal-escape-micro-'+mode+'.json','coastal-escape-micro-'+mode+'.log'])
for name in selected:copy(root/name,Path('artifacts')/name)
for dirname in ['coastal-death-fixed.json.frames','coastal-escape-full-ai.json.frames','coastal-escape-midrestore.json.frames','coastal-return-death-fixed.json.frames']:
 for file in (root/dirname).iterdir():
  if file.is_file():copy(file,Path('artifacts')/dirname/file.name)
for name in ['coastal-escape.test.ts','coastal-objective-priority.test.ts','distant-battery.test.ts','coastal-voyage.test.ts']:
 copy(repo/'src/ai/bootstrap_1'/name,Path('tests/src/ai/bootstrap_1')/name)
copy(repo/'src/ai/policy/coastal-risk.test.ts','tests/src/ai/policy/coastal-risk.test.ts')
for file in (repo/'src/ai/bootstrap_1/fixtures').iterdir():
 if file.name.startswith(('coastal-','summoner-battery-','summoner-distant-battery')):copy(file,Path('tests/src/ai/bootstrap_1/fixtures')/file.name)
source=json.loads((root/'coastal-escape-runtime-source.json').read_text())
for path,entry in source['sources'].items():
 data=(control/path).read_bytes()
 assert hashlib.sha256(data).hexdigest()==entry['sha256'],path
 copy(control/path,Path('runtime')/path)
# Verify all runtime identities against the prelaunch capture; no running file is changed.
for path,digest in source['runtimeHashes'].items():assert hashlib.sha256((control/path).read_bytes()).hexdigest()==digest,path

def complete_input(report_name,tick,dest):
 report=json.loads((root/report_name).read_text());row=next(r for r in report['rows'] if r['tick']==tick)
 frame=json.loads((root/(report_name+'.frames')/(str(tick)+'.json')).read_text())
 write(dest,{'snapshot':frame['snapshot'],'nextId':frame['nextId'],'memories':{o:p['policy'] for o,p in row['players'].items()},'agents':report['setup']['agents'],'sourceReport':report_name,'actualTick':tick})
complete_input('battery-160800-checkpoint.json',160800,'inputs/original-160800.json')
complete_input('summoner-coastal-final.json',165600,'inputs/fixed-oldcandidate-165600.json')
complete_input('summoner-safe-battery.json',165600,'inputs/old6fb-comparison-165600.json')
complete_input('summoner-safe-battery.json',166800,'inputs/old6fb-comparison-166800.json')
progress=[]
for label,name,source_name in [('old-control','summoner-coastal-final.json','coastal-final-runtime-source.json'),('escape-candidate','summoner-coastal-escape.json','coastal-escape-runtime-source.json')]:
 # Capture the atomically replaced report, then its latest complete frame. The
 # simulations continue; this archive is explicitly a progress snapshot.
 data=(root/name).read_bytes();report=json.loads(data);latest=report['rows'][-1];tick=latest['tick']
 copy(root/(name+'.frames')/(str(tick)+'.json'),Path('progress')/label/(str(tick)+'.json'))
 target=stage/'progress'/label/name;target.write_bytes(data)
 state={'state':'completed' if report['result']['completed'] else 'inProgress','completed':report['result']['completed'],'winner':report['result']['winner'],'latestCompleteWorldTick':tick,'runtimeSource':source_name,'liveReportResultAtCapture':report['result'],'note':'Diagnostic changed-code continuation from160800; captured progress only, not acceptance or victory. Raw report is retained without relabeling inherited metadata.'}
 write(Path('progress')/label/'status.json',state);progress.append({'label':label,**state})
# The full AI166800 equivalence witness also carries all memory via its row.
complete_input('summoner-coastal-escape.json',166800,'inputs/independent-escape-long-166800.json')
complete_input('summoner-coastal-escape.json',170400,'inputs/escape-return-170400.json')
complete_input('summoner-coastal-escape.json',171600,'inputs/escape-return-dead-171600.json')
copy(root/'package-coastal-escape-evidence.py','package-coastal-escape-evidence.py')
readme='''# Coastal escape evidence — WIP, rulesVersion 2

All games in this archive are diagnostic changed-code continuations, not ordinary-opening acceptance games. The original160800 world is retained with both policy memories and nextId. Report result metadata inherited192000 is not a start tick. No wins or bootstrap_1 completion are claimed.

- `artifacts/coastal-death-fixed.json`: exact fixed-oldcandidate normal full-AI165600→166800 death replay; crew died166101, ship166159. The replay matches its separate old long run. Complete before/after worlds and both memories are in its `.frames` directory. Raw inline-reference recording and exact executed script are preserved; see recordingNote.
- `artifacts/coastal-escape-micro-*.json`: explicitly manual public-command micro diagnostics for this hull only; all other normal AI commands retained. short-avoid and back-then-long die166210. short-fire survives28HP and6shots. These are not autonomous AI outcomes.
- `artifacts/coastal-escape-full-ai.json`: exact165915 full world+both memories, fixed candidate runtime, normal fullAI with every planner entry retained, no command overrides, to166800. First short retreat165915; actual warning-clear166365; original HURT return166440; ship28HP and crew200HP alive at166800. Full frames/trace/source/canonical restore and six real projectiles retained. Crew maxHP200 is combat progression, not rule change.
- `artifacts/coastal-escape-micro-long-equivalence.json`: normal165915 replay and independent160800 candidate long run have equal world/nextId/bothmemories at166800. Enemy units36→20, p0losses remain9, but all14 enemy buildings remain and no own permanent army has landed. Not a whole-game win or loss reduction claim.
- `artifacts/coastal-escape-midrestore.json`: full JSON world/nextId/both-memory restore at166170 in mid-astern maneuver, normal fullAI to166800, exact end-state equivalence to original micro and independent long run.
- `artifacts/coastal-return-death-fixed.json`: negative normal-fullAI170400→171600 replay, exact world/nextId/both-memory match to candidate long run. Ship171172 dies en route home. Passive-observer70tick `coastal-return-provocation.json` proves crew bolt hit idle guard170906, waking all3guards. Dragon fire171018 first hits crew, hull collateral kills1.5HP hull171172. Crew removed with sinking hull; not directly killed39HP by17damage. This invalidates any return-success or whole-game survival claim. Full mid-restore/return frames and both memories preserved.
- `runtime/`: exactly six modified/new production files from immutable escape-control; restore them on base4ab8411d5ac93243e414df272e63c602913d6b2f, matching `coastal-escape-runtime-source.json`. All1330 original runtime hashes were verified at packaging. Excludes later root rider/departure work. The incremental new escape strategy changes four coastal files; the full pinned stack additionally contains unchanged coastal-bombardment and shared/naval boarding fix.
- `tests/`: true165915 regression fixture and new+retained tests. Four red failures before the minimal change,31 effective root cases after; green log's38 includes7 accidental old copied test duplicates. Type check succeeded. These tests are not game acceptance.
- `progress/`: source-attributed, explicitly inProgress snapshots of both still-running long continuations; latest full world and report rows retain complete policy memory. Completion may occur after packaging and must be recorded separately. Do not turn these raw captured report horizons into victories.
- `artifacts/coastal-query-profile.json`: native voyage query counting on real saved naval decisions. One prefix query at160800; none on sampled162000–165600 cached voyages. Failed-search repetition is possible in code but was not observed in these frames. JSON-restored cold-map timing is not steady runtime timing.

Internal paths recorded in original traces are absolute artifact provenance. Their basenames map to `artifacts/` here, including the `.frames` subdirectories. Diagnostic scripts import the frozen control worktree explicitly; restore the base+six sources at that path or adjust these diagnostic-only paths before rerunning. Do not run them against current main or rulesVersion3+.

The original broken container's uncommitted-work recovery gap remains. Three families, normal opponent resources/population, all required v5/v7/v8 singles and six pairs, official maps and unseen seeds remain final requirements. No main merge is authorized by this archive.
'''
(stage/'README.md').write_text(readme)
write('INDEX.json',{'classification':'RulesVersion2 WIP diagnostic changed-code continuations; neither win nor bootstrap acceptance','baseCommit':source['baseCommit'],'runtimeSource':'artifacts/coastal-escape-runtime-source.json','guide':'README.md','findings':'artifacts/coastal-escape-findings.zh.md','proofs':{'old165600Death':'artifacts/coastal-death-fixed.json','manualPositiveNegative':'artifacts/coastal-escape-micro-*.json','normal165915FullAi':'artifacts/coastal-escape-full-ai-summary.json','completeMidJsonRestore166170':'artifacts/coastal-escape-midrestore.json','independentLongMicroEquality166800':'artifacts/coastal-escape-micro-long-equivalence.json','return171172Failure':'artifacts/coastal-return-death-summary.json','exactNeutralProvocation':'artifacts/coastal-return-provocation.json','queryProfile':'artifacts/coastal-query-profile.json','redGreen':'artifacts/coastal-escape-red.log / coastal-escape-green.log'},'progress':progress,'recoverableInputs':'inputs/ and artifacts/*.json.frames contain complete world/nextId/both policy memories','sourceScope':'Fixed4ab +6 production files; excludes later root rider/departure changes','originalContainerUncommittedRecoveryGap':'unresolved'})
manifest={'classification':'Diagnostic changed-code coastal escape WIP evidence; rulesVersion2; no acceptance or victory claim','capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':source['baseCommit'],'runtimeSource':'artifacts/coastal-escape-runtime-source.json','originalArtifactRoot':str(root),'progress':progress,'files':{str(p.relative_to(stage)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(stage.rglob('*')) if p.is_file()}}
write('manifest.json',manifest)
out.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(out,'w:gz',compresslevel=9) as tar:tar.add(stage,arcname='coastal-escape-evidence')
# Verify every archived regular file and its exact content hashes after closing.
with tarfile.open(out,'r:gz') as tar:
 for name,entry in manifest['files'].items():assert hashlib.sha256(tar.extractfile('coastal-escape-evidence/'+name).read()).hexdigest()==entry['sha256'],name
receipt={'archive':str(out.relative_to(repo)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'files':len(manifest['files'])+1,'capturedAtUtc':manifest['capturedAtUtc'],'progress':progress,'runtimeHashesVerified':len(source['runtimeHashes']),'allArchivedContentHashesVerified':True}
(root/'coastal-escape-evidence-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print(json.dumps(receipt,ensure_ascii=False,indent=2))
