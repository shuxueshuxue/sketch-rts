# 沿岸炮船真实转向致死与短退候选

状态：WIP，规则 2。短窗证实正常 AI 已执行可存活的操作；整场返港、再战与胜负尚在观察，不是 bootstrap_1 验收。

## 固定对照与根因

原对照运行 `summoner-coastal-final.json` 使用 `coastal-final-runtime-source.json`：4ab8411d + 5 个 coastal 策略文件及 shared/naval 真实 boarding 修复，未纳入 rider/departure 新改动。输入是原始 160800 完整 world/nextId/双方策略 memory；继承报告元数据 192000 未作为起点使用。

从其 165600 完整世界精确短重放至 166800 的 `coastal-death-fixed.json` 与长局最终世界递归比较差异 0，canonical hash 为 `9c5de170f379db6ac4f7bcccc236b0778c7876bdd7bc3c6cad9c7f8ffa88cff8`。原始 inline live-view 录制引用问题和修正归属在该文件 recordingNote 中保留，权威完整 gzip 预命令世界未被覆盖。

- 165600→165915 船基本原地交火，native pursuit 的内向纸面路线不是这段的真实前进。
- 165915 首次被岸军压倒：船 260 HP、heading -2.968，北侧安全终点触发 ordinary move avoidCombat。实际首段先向西驶近岸军。
- 165930、166065 退点又改向；安全终点没有证明宽转弯的实际逃生路线。
- 166101 ballista 乘员死亡，166159 炮船死亡；伤害为普通 p1 岸军投射物，未发现中立野怪伤害或船部件先损坏。

## 操作诊断与正常 AI 结果分开

`coastal-escape-query.json` 的真实 native 查询证明 0.4 船长约 97px 的船尾坐标可由普通 move 形成精确直线倒车；北/南长退点的实际弯曲路线穿入火力区。未注入位置、heading 或 route。

`coastal-escape-micro-*.json` 是明确人工接管本船命令的诊断，其余双方正常 AI 保留。禁止把它们称为自主候选比赛：短退 avoidCombat 和短退后长转向均在 166210 船沉；保留火力的短退发出 6 炮，在 166365 脱离警戒，166800 船存活 28 HP。

随后最小生产候选仅改 `memory.ts`、`policy/naval.ts`、`coastal-risk.ts`、`coastal-voyage.ts`，增量为 `coastal-escape-production.patch`。短退记忆 `astern` 不进入 GameCommand；终点按原生 5px move 到达释放，每次决策复核普通 native 路线、物理通行与实际火力几何。允许从既有射区向外后退，不能进入新的实际射区；保留正常 HURT 和医疗标准。

`coastal-escape-full-ai.json` 是完全正常双方 AI、无任何命令过滤或注入的 165915→166800 候选验证：

| tick | 真实行为 |
| --- | --- |
| 165915 | 满血 260 HP，首次短退 move 至 (2870.460,6740.006)，未设置 avoidCombat |
| 166170 | 距首目标 0.185px、118 HP，正常 AI 发第二段短退 |
| 166365 | 实际船位 (2942.839,6752.698) 首次通过完整警戒 prefix 检查，28 HP |
| 166425 | 距第二目标 0.185px，完成退点，转 hold |
| 166440 | 原 HURT 标准触发普通返港 move |
| 166800 | 船 (2960,6977.170)、28/260 HP，乘员 200/200 HP 均存活，仍在返港 |

船实际发 6 炮，普通船载火力和乘员控制正常；船 kills 9。乘员上限变成 200 来自实战成长，不是规则改动。没有把存活写成无伤。166448 后返港完整路线仍有警戒相交的后续部分，当前实际位置已无 outmatchingCoast，后续须按真实执行观察。

预检 `coastal-escape-full-ai-source.json` 保存固定运行源码 hash、完整输入路径、script hash、恢复前后 canonical hash。首次 raw JSON.stringify 预检只因对象键顺序失败，发生在任何 step 前；递归真实值差异为 0，world/nextId/双方 memory 全相等后才重启。world hash `837933a644dbd8922ec390470c48b500c284246f3a8a472125f3ab6b95423aa2`；双方 memory hash `475f9bcda1e69fe74038889d1b13f996cd20e0331f867d034c892412ecb295e8`。

实际 drawWorld 图 `coastal-escape-166425.png` 已目视：炮船处于海峡离岸，岸军仍在西岸；不是占位或路线调试图。

## 验证范围和后续

真实 fixture `coastal-escape-turn-trap.json.gz` 来自 165915 预决策完整世界。4 个新红测先全失败，再通过；三条家族的短退、真实 100 tick 后余距小于 70 而大于 5 的保存/继续均覆盖。原远岸敌人、空运输船避战、live fire/当前可射、近岸风险等 27 项保持通过，root 有效共 31 项。测试日志总 38 项包含误匹配到 .playtest 的 7 份旧重复，应按 31 项说明。tsc 和 diff check 通过。

独立完整续局 `summoner-coastal-escape.json` 使用启动前冻结的 `coastal-escape-runtime-source.json`（6 个增量生产文件全文及完整 1330 runtime hashes），从相同原 160800 正常运行至自然胜负/204000。`coastal-escape-pretrigger-equivalence.json` 对 162000/163200/164400 的 world、nextId、双方 memory 已逐项确认与旧对照相等。只读观察器输出 `summoner-coastal-escape-observations.json`。旧候选长局继续单列，不能挪用旧 6fb 胜局或人工微操结果。

尚未证明完成返港、重新进攻、减少整场损失或获胜；未完成三路线单敌/六配对和地图/未见种子的最终完整对局要求。原故障容器未提交修改的恢复缺口仍保留。

完整续局到 166800 的 world、nextId、双方 memory 与 165915 正常 AI 短重放全相等（`coastal-escape-micro-long-equivalence.json`，world hash `549565e81e18ede35ddc20b3cde7e9da4ea2f4b38f70a972ff0d3fac26643c2e`）。此窗敌单位 36→20、p1 unitsLost 16，p0 unitsLost 仍为 9；农场仍只是 320→104，敌 14 建筑未毁、敌岛我军仍 0。这证明局部作战结果可在独立长续局复现，不证明最终获胜。

## 路线查询成本观察

`coastal-query-profile.json` 用 Vitest 模块加载器计数/计时包裹真实函数，未改固定运行源码。在真实 160800 完整 naval 决策中，100k-budget 的 `planCoastalVoyage` 调用 1 次、35.9ms、结果 prefix；162000/163200/164400/165600 的实际完整存档决策各为 0 次，安全缓存有效。已用 160800 的真实调用确认计数器能拦截函数。

源码在 undefined 失败时删除 voyage，且没有失败记录，下一次符合条件的决策仍会重新调用；但现有这些帧没有失败案例，不能声称已证实每 15 tick 的昂贵失败循环。完整 naval 决策在各自 JSON 重建冷地图上为 747–1977ms，包含其他策略和并跑 CPU 影响，不能当实际稳定 think 成本。

真实 165915 的短倒车 native 验证另测：冷首次 61.1ms，同一世界连续 20 次总 34.24ms、中位 1.06ms、最大 10.10ms（`coastal-escape-query-cost.json`）。这是该查询成本，不是完整 AI 耗时。

## 完整 JSON 中途恢复与返港失败反证

`coastal-escape-midrestore.json` 从真实 166170 p0 预决策完整 world/nextId/双方 memory（第一短退刚到达）恢复同一固定源码，完全正常 AI 跑到 166800。最终完整 snapshot、nextId、双方 memory 全等、递归差异 0；其 world/memory hash 与上面的独立长局/微观验证相同。这补足了测试中仅恢复 memory 的范围，不混称为同一种证据。

独立长局没有返港成功。170400 时船 (5363.297,6444.703)、28 HP，乘员 200 HP，执行原 HURT ordinary move (7856,3632) avoidCombat。船在 171172 于 (5679.371,6128.629) 沉没。

`coastal-return-death-fixed.json` 从 170400 完整 world/nextId/双方 memory 正常 AI 精确短重放至 171600，与长局最终 snapshot、nextId、双方 memory 全等、递归差异 0。world hash `8ba9a491cef262936fb8262cb89a160263ec4ca00ed9afa1482d0aa68026edfa`。新死亡是中立龙营，不是 p1 岸战：

- 170835 正常 AI 主动命 ballista 向仍 idle 的 guard-1-1 施 pinningBolt；170850/65/80 又有相同普通 cast。
- 170889 乘员发出 36 伤害 bolt。额外 70 tick 的 `coastal-return-provocation.json` 使用被动 SimObserver，从真实 170880 全状态恢复，170925 的全状态与原死亡重放相等。
- 170906 observer 确认 bolt 命中仍 idle 的 guard-1-1（125→89），同 tick 三只龙营守卫全由 idle 转 attack ballista。故引营因果已由实际命中证实，不是靠近范围的猜测。
- 170925 原短退策略发现危险并开始倒车，但船只剩 28 HP。171008 redDragon 发火，171018 首中乘员 42、船关联 6，船降至 22 HP。
- 171172 whelp 17 命中乘员，关联 1.7 击沉尚存 1.5 HP 的船，乘员随沉船移除。不能声称乘员从 39 HP 被 17 点直接击杀。

因此沿岸短退仍是有价值的局部修复，但当前完整候选不能声称返港成功、整场少损或完成验收。返航安全海路与乘员引战范围的共享查询是下一项已授权工作；保持本轮固定源码继续运行并保留负证据，未关闭技能或修改船/乘员规则。
