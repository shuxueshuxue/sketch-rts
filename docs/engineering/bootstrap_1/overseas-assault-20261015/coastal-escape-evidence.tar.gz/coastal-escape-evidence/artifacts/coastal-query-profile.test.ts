import {readFileSync,writeFileSync} from 'node:fs';
import {it,expect,vi} from 'vitest';
import * as voyage from '/workspace/sketch-rts-coastal-escape-control/src/ai/policy/coastal-voyage.ts';
import {planBootstrapNaval} from '/workspace/sketch-rts-coastal-escape-control/src/ai/bootstrap_1/expedition-recovery.ts';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-coastal-escape-control/src/ai/bootstrap_1/policy.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',calls:any[]=[];
it('records voyage query calls in real saved full naval decisions without altering the fixed runtime',()=>{
 const original=voyage.planCoastalVoyage;
 const spy=vi.spyOn(voyage,'planCoastalVoyage').mockImplementation((...args)=>{const at=performance.now(),result=original(...args);calls.push({tick:args[0].tick,ship:args[1].id,goal:args[2],elapsedMs:performance.now()-at,result:result?.proof,waypoint:result?.waypoint});return result;});
 const report=JSON.parse(readFileSync(root+'/summoner-coastal-final.json','utf8'));
 const decisions=[];
 for(const tick of [160800,162000,163200,164400,165600]){
  const saved=tick===160800?JSON.parse(readFileSync(root+'/battery-160800-checkpoint.json','utf8')):report;
  const row=saved.rows.find((r:any)=>r.tick===tick),file=tick===160800?'battery-160800-checkpoint.json':'summoner-coastal-final.json',s=JSON.parse(readFileSync(root+'/'+file+'.frames/'+tick+'.json','utf8')).snapshot;
  const context=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(row.players.p0.policy),teams:s.teams});
  const at=performance.now(),before=calls.length,commands=planBootstrapNaval(s,'p0',context);
  decisions.push({tick,elapsedMs:performance.now()-at,queries:calls.length-before,batteryCommands:commands.filter(c=>'unitIds'in c&&c.unitIds.includes('unit-p0-bombardShip-26580'))});
 }
 writeFileSync(root+'/coastal-query-profile.json',JSON.stringify({classification:'Read-only full naval planner calls on actual complete saved worlds/memories; no simulation and no commands applied. Frozen escape runtime imported; measurement wrappers exist only in Vitest module loader.',decisions,calls},null,2));
 expect(calls.some(call=>call.tick===160800)).toBe(true);spy.mockRestore();
});
