import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {bootstrapGame,bootstrapMatches} from '/workspace/sketch-rts-coastal-control/src/ai/bootstrap_1/benchmark.ts';
import {createAiMemoryProvider} from '/workspace/sketch-rts-coastal-control/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/workspace/sketch-rts-coastal-control/scripts/bootstrap_1-planner.ts';
import {runAiGameLoop} from '/workspace/sketch-rts-coastal-control/src/ai/game-runner.ts';
import {restoreSnapshotIntoGame,snapshotGame} from '/workspace/sketch-rts-coastal-control/src/shared/sim.ts';
import {shipProfile} from '/workspace/sketch-rts-coastal-control/src/shared/ship-geometry.ts';
import {coastalFireDisks,coastalFireSegmentClear} from '/workspace/sketch-rts-coastal-control/src/ai/policy/coastal-voyage.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',control='/workspace/sketch-rts-coastal-control',mode=process.argv[2]??'short-avoid';
const source=JSON.parse(readFileSync(root+'/coastal-final-runtime-source.json','utf8')),trace=JSON.parse(readFileSync(root+'/coastal-death-fixed.json','utf8')),event=trace.events.find((e:any)=>e.type==='commands'&&e.owner==='p0'&&e.tick===165915),f=JSON.parse(gunzipSync(readFileSync(event.before)).toString());
if(execFileSync('git',['diff'],{cwd:control,encoding:'utf8'})!==source.trackedDiff)throw new Error('fixed source changed');
const report=JSON.parse(readFileSync(root+'/summoner-coastal-final.json','utf8')),match=bootstrapMatches(report.setup.seed,['sapphireArchipelago'],166800,false).find(m=>m.subject==='v9_summoner'&&m.side===0&&m.agents.p0!.race==='grove'&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!,game=bootstrapGame(match),memory=createAiMemoryProvider(),id='unit-p0-bombardShip-26580';
restoreSnapshotIntoGame(game,f.snapshot,f.nextId);for(const [owner,m]of Object.entries(f.memories))memory.set!(owner,m as any);
const initial=game.units.find(u=>u.id===id)!,heading=initial.sailing!.heading,profile=shipProfile(initial)!,commands:any[]=[],samples:any[]=[],shots:any[]=[],suppressed:any[]=[],shotIds=new Set<string>();let waypoint:{x:number;y:number}|undefined,legs=0,safe=false;
const planner=await createBootstrapCommandPlanner(memory);
const commandPlanner:Parameters<typeof runAiGameLoop>[0]['commandPlanner']=context=>{
 const entries=planner(context);if(context.owner!=='p0')return entries;
 const kept=entries.flatMap(entry=>{const c=entry.command;if(!('unitIds'in c)||!c.unitIds.includes(id))return [entry];suppressed.push({tick:context.snapshot.tick,command:structuredClone(c)});const ids=c.unitIds.filter(unitId=>unitId!==id);return ids.length?[{...entry,command:{...c,unitIds:ids}}]:[];});
 const ship=context.snapshot.units.find(u=>u.id===id);if(!ship)return kept;
 const arrived=waypoint&&Math.hypot(ship.x-waypoint.x,ship.y-waypoint.y)<=5;
 const disks=coastalFireDisks(context.snapshot,ship,{teams:context.teams}),pose={x:ship.x,y:ship.y,heading:ship.sailing!.heading};safe=coastalFireSegmentClear(pose,pose,disks);
 let command:any;
 if(safe){if(ship.order.type!=='hold')command={type:'holdPosition',unitIds:[id]};}
 else if(!waypoint||arrived){const length=mode==='back-then-long'&&legs>0?600:profile.length*.4;waypoint={x:ship.x-Math.cos(heading)*length,y:ship.y-Math.sin(heading)*length};legs++;command={type:'move',unitIds:[id],...waypoint,...(mode==='short-fire'?{}:{avoidCombat:true})};}
 else if(ship.order.type!=='move')command={type:'move',unitIds:[id],...waypoint,...(mode==='short-fire'?{}:{avoidCombat:true})};
 if(command){commands.push({tick:context.snapshot.tick,command,ship:{x:ship.x,y:ship.y,hp:ship.hp,heading:ship.sailing!.heading,speed:ship.sailing!.speed},safe});console.log(JSON.stringify(commands.at(-1)));kept.push({playerId:'p0',source:context.source,scriptId:'diagnostic-public-manual-helm',command});}
 return kept;
};
const result=runAiGameLoop({...match,game,commandPlanner},{onStep:({game})=>{
 for(const p of game.projectiles)if(p.attackerId===id&&!shotIds.has(p.id)){shotIds.add(p.id);shots.push({tick:game.tick,...p});}
 if(game.tick%15!==0)return;const u=game.units.find(u=>u.id===id);samples.push({tick:game.tick,ship:u&&{x:u.x,y:u.y,hp:u.hp,maxHp:u.maxHp,order:structuredClone(u.order),parts:structuredClone(u.shipParts),heading:u.sailing?.heading,speed:u.sailing?.speed,route:structuredClone(u.sailing?.route)},crew:game.units.filter(u=>u.deck?.shipId===id).map(u=>({id:u.id,hp:u.hp,order:structuredClone(u.order)}))});
}});
const final={classification:'Explicit manual micro diagnostic using public move/holdPosition only. P0 hull planner commands suppressed; every other P0 command and normal frozen V5 retained. Not an AI match outcome.',mode,start:f.snapshot.tick,end:game.tick,source:'coastal-final-runtime-source.json',scriptSha256:createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'),input:event.before,commands,suppressed,samples,shots,snapshot:result.snapshot,nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]))};writeFileSync(root+'/coastal-escape-micro-'+mode+'.json',JSON.stringify(final));const u=result.snapshot.units.find(u=>u.id===id);console.log(JSON.stringify({completed:true,mode,ship:u&&{x:u.x,y:u.y,hp:u.hp,order:u.order},safe,legs,shots:shots.length,deaths:result.snapshot.corpses.filter(c=>c.unitId===id),crew:result.snapshot.units.filter(u=>u.deck?.shipId===id).map(u=>({id:u.id,hp:u.hp}))}));
