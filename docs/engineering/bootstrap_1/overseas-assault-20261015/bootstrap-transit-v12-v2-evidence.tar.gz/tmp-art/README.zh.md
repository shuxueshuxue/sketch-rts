# v12 运输停滞研究：候选未合并

规则 2；frozen manifest SHA256 0490e7d43d109e70be3b141f76d1276a778a3402f3ea19f51a8cd37fee941774。原会话未提交工作仍未恢复。所有本轮世界沿原真实对局/明确的旧人工船只设置继续，不是普通0开局/验收。

- 已有 v12 树两运输文件与 root-v11 immutable 源相同；先记 start-source，再独立修改。源码胶囊 v1/v2 均 1589 文件，v2仅两运输文件与 root-v11 不同；全部游戏开始前封存、运行后未改。
- 根因1：89040返航纳入敌岛岸军后，船在+160预警内、真实capability外圈约72.7px，coarse reference seed展开0。全方向15tick球界又否决定向离险。v1把已包含起点的预警约束为不再深入当前覆盖，保留真实火力/中立挑衅圈，接受完整native曲线。
- 根因2：v1从89041全AI→91000虽离险，但3648,6336再次停。native对3904,6464完成搜索实际拟合3984,6416，严格到原mark<=8规则拒绝；v2把拟合末点只作为新候选，下轮从原位独立重证，绝不安装路径或把它当原目标已到。
- v2从实际hold后的89041全AI→94000：90136原15乘员全部卸到原mission.from同一岛，HP不减，空船依旧services返港。不是敌岛登陆/胜利。
- v2原正常AI88110→96000：首次取消仍89040，敌岛登陆0、敌hall900/21建筑、winner null；15人90121返原岛；3510/其14人死亡，3824最终428.172HP返港。没有解决进攻目标。
- 真实103935/1046全双方AI，v2及既有hook-disabled control均105154 p0胜。v2首hold225ticks，随后多段move恢复，终船335.8628；旧终347.3060且更前进。仅友船1064碰撞（新104239伤15.1372，旧104078伤3.6940），无neutral受击；7乘员均无伤、仍甲板。v2有无增强boat observer的最终完整世界/nextId/全部记忆完全相等。不能把额外hold宣称救船。
- 原manual92400取消：三个v9路线完整p0 owner/native1600tick均保留原returngoal，3/7人返原岛；旧hook-disabled archer也是3/7。新船376.045 vs旧405.045，额外损约29且位置落后。其他p1只保留旧native命令，此段不是双方AI完整对局。原人工历史已保留。
- 人工neutral后置边界（从真实169500构造，非历史遭遇）：原native路线已clear，v2不hold，240tick实际向前约100px且船/4弩车无伤，neutral也实际移动；旧全方向球hold断言过度。不能据此保证所有移动敌人未来安全。

组件60 tests 55 pass/5 fail：3个取消命令golden、103935额外1046 hold、人工全方向球hold；原失败日志保留，未改测试断言。tsc通过。v2仍未并入稳定树，近前缀查询应在下一独立树实现；不能用这组局部返航证据抵消额外伤害。

失败启动：ENOENT（错误88110路径）、固定29人runner拒绝1046的7人、ENOSPC mkdir；各日志保留，不列为成功运行。89040 SDK view字段值逐字段与恢复相同但顶层键顺序不同，严格JSON串检查失败，因此halted实验用89041真实native snapshot。旧runner thoughts.boats.sailing借用共享引用，其历史值不可作证；因果只用磁盘完整世界/记忆、拷贝的command和primitive坐标。增强observer driver已deep clone sailing，但不回写旧报告。
