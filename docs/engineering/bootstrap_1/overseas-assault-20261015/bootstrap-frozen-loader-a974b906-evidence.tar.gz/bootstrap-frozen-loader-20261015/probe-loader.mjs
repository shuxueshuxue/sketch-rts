import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const source = process.argv[2];
const loader = await import(pathToFileURL(join(source, 'scripts/bootstrap_1-planner.ts')).href);
const directory = loader.frozenPolicyRoot();
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const allArchived = {};
function walk(path, prefix = '') {
  for (const entry of fs.readdirSync(path, {withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))) {
    const name = prefix + entry.name;
    if (entry.isDirectory()) walk(join(path, entry.name), name + '/');
    else allArchived[name] = sha(fs.readFileSync(join(path, entry.name)));
  }
}
walk(directory);
const modulePromise = loader.frozenPolicyModules();
const concurrentPromise = loader.frozenPolicyModules();
const exported = await modulePromise;
await loader.createBootstrapCommandPlanner();
console.log(JSON.stringify({source,cwd:process.cwd(),manifest:loader.frozenPolicyManifest,
  manifestSHA256:sha(fs.readFileSync(join(source,'docs/engineering/bootstrap_1/frozen-policy.json'))),
  loaderSHA256:sha(fs.readFileSync(join(source,'scripts/bootstrap_1-planner.ts'))),
  allArchived,manifestMatches:Object.fromEntries(Object.entries(loader.frozenPolicyManifest.files).map(([name,hash])=>[name,allArchived[name]===hash])),
  exports:Object.fromEntries(Object.entries(exported).map(([name,fn])=>[name,sha(fn.toString())])),
  successfulPromiseShared:modulePromise===concurrentPromise && modulePromise===loader.frozenPolicyModules(),
  successfulModulesShared:exported===await loader.frozenPolicyModules()},null,2));
