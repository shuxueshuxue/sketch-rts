import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {bootstrapGame,bootstrapMatches} from '/workspace/sketch-rts-coastal-return-control/src/ai/bootstrap_1/benchmark.ts';
import {createAiMemoryProvider} from '/workspace/sketch-rts-coastal-return-control/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/workspace/sketch-rts-coastal-return-control/scripts/bootstrap_1-planner.ts';
import {runAiGameLoop} from '/workspace/sketch-rts-coastal-return-control/src/ai/game-runner.ts';
import {restoreSnapshotIntoGame,snapshotGame} from '/workspace/sketch-rts-coastal-return-control/src/shared/sim.ts';
import {bootstrapPolicyContext} from '/workspace/sketch-rts-coastal-return-control/src/ai/bootstrap_1/policy.ts';
import {coastalVoyagePrefixSafe,coastalFireDisks,coastalFireSegmentClear} from '/workspace/sketch-rts-coastal-return-control/src/ai/policy/coastal-voyage.ts';
import {outmatchingCoast} from '/workspace/sketch-rts-coastal-return-control/src/ai/policy/coastal-risk.ts';
import {combatCapability} from '/workspace/sketch-rts-coastal-return-control/src/shared/combat-capabilities.ts';
import {effectiveCombatRating} from '/workspace/sketch-rts-coastal-return-control/src/ai/policy/v6/strength.ts';
import {distanceToHull} from '/workspace/sketch-rts-coastal-return-control/src/shared/ship-geometry.ts';
import {canReach} from '/workspace/sketch-rts-coastal-return-control/src/shared/naval.ts';
import {unitMover} from '/workspace/sketch-rts-coastal-return-control/src/shared/catalog.ts';
import {attackMargin} from '/workspace/sketch-rts-coastal-return-control/src/ai/policy/v6/general.ts';
const root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',control='/workspace/sketch-rts-coastal-return-control';
const source=JSON.parse(readFileSync(root+'/coastal-return-v4-runtime-source.json','utf8'));
const sha=(value:string|Buffer)=>createHash('sha256').update(value).digest('hex');
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:control,encoding:'utf8'}).trim(),diff=execFileSync('git',['diff'],{cwd:control,encoding:'utf8'});
if(head!==source.baseCommit||diff!==source.trackedDiff)throw new Error('Fixed runtime differs from prelaunch source');
for(const [path,entry]of Object.entries(source.sources) as [string,any][])if(sha(readFileSync(control+'/'+path))!==entry.sha256)throw new Error('Source changed: '+path);
const report=JSON.parse(readFileSync(root+'/summoner-coastal-final.json','utf8')),start=170400,end=175200;
const continuation=JSON.parse(readFileSync(root+'/summoner-coastal-escape.json','utf8')),row=continuation.rows.find((r:any)=>r.tick===start),input=root+'/summoner-coastal-escape.json.frames/'+start+'.json',saved=JSON.parse(readFileSync(input,'utf8')),frame={...saved,memories:Object.fromEntries(Object.entries(row.players).map(([owner,p]:[string,any])=>[owner,p.policy]))};
const match=bootstrapMatches(report.setup.seed,['sapphireArchipelago'],end,false).find(m=>m.subject==='v9_summoner'&&m.side===0&&m.agents.p0!.race==='grove'&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!;
const game=bootstrapGame(match),memory=createAiMemoryProvider();restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);for(const [owner,p]of Object.entries(frame.memories))memory.set!(owner,p as any);
const ids=['unit-p0-bombardShip-26580','unit-p0-ballista-12972'],shipId=ids[0]!,events:any[]=[],timeline:any[]=[],shots:any[]=[],impacts:any[]=[],files=root+'/coastal-return-v4-full-ai.json.frames';mkdirSync(files,{recursive:true});
const mem=()=>Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,structuredClone(memory.get(owner))]));
const canonical=(value:any):string=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
const diffs:any[]=[];
function compare(actual:any,expected:any,path='$') {
 if(Object.is(actual,expected))return;
 if(!actual||!expected||typeof actual!=='object'||typeof expected!=='object'){diffs.push({path,actual,expected});return;}
 const keys=new Set([...Object.keys(actual),...Object.keys(expected)]);
 for(const key of keys)compare(actual[key],expected[key],path+'.'+key);
}
compare(snapshotGame(game),frame.snapshot,'world');compare(mem(),frame.memories,'memories');compare(game.nextId,frame.nextId,'nextId');
const sourceRecord={classification:'Independent fixed-source coastalreturnv4 diagnostic170400→175200, normal full-AI/no injected or filtered commands; baseline fullescape comparison expected to differ',start,end,input,baseCommit:head,trackedDiff:diff,originalSourceSha256:sha(readFileSync(root+'/coastal-return-v4-runtime-source.json')),sourceHashes:Object.fromEntries(Object.entries(source.sources).map(([p,s]:[string,any])=>[p,s.sha256])),scriptSha256:sha(readFileSync(new URL(import.meta.url))),restore:{worldEqual:canonical(snapshotGame(game))===canonical(frame.snapshot),nextIdEqual:game.nextId===frame.nextId,memoriesEqual:canonical(mem())===canonical(frame.memories)},rawStringify:{worldEqual:JSON.stringify(snapshotGame(game))===JSON.stringify(frame.snapshot),memoriesEqual:JSON.stringify(mem())===JSON.stringify(frame.memories)},restoreDifferences:diffs,canonicalHashes:{restoredWorld:sha(canonical(snapshotGame(game))),savedWorld:sha(canonical(frame.snapshot)),restoredMemories:sha(canonical(mem())),savedMemories:sha(canonical(frame.memories))}};
writeFileSync(root+'/coastal-return-v4-full-ai-source.json',JSON.stringify(sourceRecord,null,2));
if(Object.values(sourceRecord.restore).some(v=>!v)||diffs.length)throw new Error('Restore mismatch: '+JSON.stringify({restore:sourceRecord.restore,diffs:diffs.slice(0,20)}));
function keep(label:string,snapshot:any,nextId:number,memories:any){const path=files+'/'+label+'.json.gz';writeFileSync(path,gzipSync(JSON.stringify({snapshot,nextId,memories}),{level:6}));return path;}
function details(s:any){
 const ship=s.units.find((u:any)=>u.id===shipId),options=bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(memory.get('p0')!),teams:s.teams});
 const nearby=ship?s.units.filter((u:any)=>Math.hypot(u.x-ship.x,u.y-ship.y)<1400):[];
 const threats=ship?nearby.filter((u:any)=>u.owner!=='p0'&&unitMover(u.kind)==='land'&&combatCapability(s,u).armed).map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:u.order,range:combatCapability(s,u).range,hullGap:distanceToHull(ship,u),canReach:canReach(s.map,u,ship,s.units),rating:effectiveCombatRating(s,u)})):[];
 const disks=ship?coastalFireDisks(s,ship,options):[],risk=new Set<string>();let previous=ship&&{x:ship.x,y:ship.y,heading:ship.sailing?.heading??0};if(ship)for(const point of ship.sailing?.route?.points??[]){for(const disk of disks)if(!coastalFireSegmentClear(previous,point,[disk]))risk.add(disk.id);previous=point;}
 return {units:ids.map(id=>s.units.find((u:any)=>u.id===id)??{id,absent:true}),coastOutmatched:ship?outmatchingCoast(s,'p0',ship,ship,options).map(u=>u.id):[],margin:attackMargin(options),routeSafety:ship?.sailing?.route?.points.length?coastalVoyagePrefixSafe(s,ship,ship.sailing.route,options):undefined,routeRiskIds:[...risk],naval:structuredClone(memory.get('p0')?.naval),nearby:nearby.map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,x:u.x,y:u.y,hp:u.hp,order:u.order,deck:u.deck,cabin:u.cabin})),threats,corpses:s.corpses.filter((c:any)=>ids.includes(c.unitId))};
}
keep('initial-'+start,frame.snapshot,frame.nextId,frame.memories);
const planner=await createBootstrapCommandPlanner(memory);let beforeId=game.nextId,beforeMem=mem(),lastRisk='';
const commandPlanner:Parameters<typeof runAiGameLoop>[0]['commandPlanner']=context=>{
 const before=mem(),entries=planner(context);
 const relevant=entries.filter(entry=>{const c=entry.command;return 'unitIds'in c&&c.unitIds.some(id=>ids.includes(id))||'unitId'in c&&ids.includes(c.unitId)||'targetId'in c&&ids.includes(c.targetId);});
 if(relevant.length){const label=context.snapshot.tick+'-commands-'+context.owner,info={type:'commands',tick:context.snapshot.tick,owner:context.owner,entries:relevant,state:structuredClone(details(context.snapshot)),before:keep(label,context.snapshot,game.nextId,before)};events.push(info);console.log(JSON.stringify({type:info.type,tick:info.tick,entries:relevant.map(x=>x.command),risk:info.state.routeSafety,outmatched:info.state.coastOutmatched}));}
 return entries;
};
const result=runAiGameLoop({...match,game,commandPlanner},{beforeStep:()=>{beforeId=game.nextId;beforeMem=mem();},afterStep:({before,after,game})=>{
 const expired=before.projectiles.filter(p=>p.remaining<=1),created=after.projectiles.filter(p=>!before.projectiles.some(q=>q.id===p.id));
 for(const p of expired)impacts.push({tick:after.tick,projectile:p,attacker:before.units.find(u=>u.id===p.attackerId)??before.buildings.find(b=>b.id===p.attackerId)});
 for(const p of created)shots.push({tick:after.tick,projectile:p,attacker:after.units.find(u=>u.id===p.attackerId)??after.buildings.find(b=>b.id===p.attackerId)});
 const changes=ids.flatMap(id=>{const a=before.units.find(u=>u.id===id),b=after.units.find(u=>u.id===id);return a&&(!b||a.hp!==b.hp)?[{id,before:a.hp,after:b?.hp??0,removed:!b}]:[];});
 const ship=after.units.find(u=>u.id===shipId);const safety=ship?.sailing?.route?.points.length?coastalVoyagePrefixSafe(after,ship,ship.sailing.route,{teams:after.teams}):undefined;
 const risk=JSON.stringify([safety,ship?.order.type,ship?.order.type==='attackMove'?ship.order.targetId:undefined]);const unsafeTransition=safety===false&&risk!==lastRisk;lastRisk=risk;
 if(changes.length||unsafeTransition){const label=after.tick+(changes.length?'-hp':'-risk'),state=details(after),event={type:changes.length?'hp':'unsafe-route',tick:after.tick,changes,impacts:expired,newProjectiles:created,hitEffects:after.effects.filter(e=>e.type==='hit'&&e.unitId&&ids.includes(e.unitId)&&!before.effects.some(f=>f.id===e.id)),state,before:keep(label+'-before',before,beforeId,beforeMem),after:keep(label+'-after',after,game.nextId,mem())};events.push(event);console.log(JSON.stringify({type:event.type,tick:event.tick,changes,impacts:expired.filter(p=>ids.includes(p.targetId)).map(p=>({attackerId:p.attackerId,owner:p.owner,sourceKind:p.sourceKind,targetId:p.targetId,damage:p.damage})),order:ship?.order,risk:state.routeSafety,outmatched:state.coastOutmatched}));}
 if(after.tick%15===0||changes.some(c=>c.removed))timeline.push({tick:after.tick,units:ids.map(id=>{const u=after.units.find(x=>x.id===id);return u&&{id:u.id,x:u.x,y:u.y,hp:u.hp,order:u.order,parts:u.shipParts,heading:u.sailing?.heading,speed:u.sailing?.speed,pursuit:u.sailing?.pursuit,route:u.sailing?.route};}),routeSafety:safety,retreat:memory.get('p0')?.naval?.coastalRetreat?.[shipId]});
}});
keep('final-'+end,result.snapshot,game.nextId,mem());
const original=JSON.parse(readFileSync(root+'/summoner-coastal-escape.json.frames/'+end+'.json','utf8'));
const expectedMemory=Object.fromEntries(Object.entries(continuation.rows.find((r:any)=>r.tick===end).players).map(([owner,p]:[string,any])=>[owner,p.policy]));
compare(result.snapshot,original.snapshot,'end.world');compare(game.nextId,original.nextId,'end.nextId');compare(mem(),expectedMemory,'end.memories');
const final={source:sourceRecord,events,timeline,shots,impacts,snapshot:result.snapshot,nextId:game.nextId,memories:mem(),sameAsLongRun:{snapshot:canonical(result.snapshot)===canonical(original.snapshot),nextId:game.nextId===original.nextId,memories:canonical(mem())===canonical(expectedMemory),differences:diffs,worldHash:sha(canonical(result.snapshot)),memoryHash:sha(canonical(mem()))}};
writeFileSync(root+'/coastal-return-v4-full-ai.json',JSON.stringify(final));console.log(JSON.stringify({completed:true,tick:game.tick,sameAsLongRun:final.sameAsLongRun,deaths:result.snapshot.corpses.filter(c=>ids.includes(c.unitId)),events:events.length,shots:shots.length}));
