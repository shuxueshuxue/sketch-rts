import json,hashlib,subprocess,difflib
from pathlib import Path
root=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');control=Path('/workspace/sketch-rts-coastal-return-control')
old=json.loads((root/'coastal-return-v3-runtime-source.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=list(old['sources'])+['src/shared/sailing.ts','src/shared/ship-voyage-wind.ts']
sources={p:{'sha256':sha((control/p).read_bytes()),'text':(control/p).read_text()}for p in paths}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=control,text=True).strip()
keys=set(old['runtimeHashes'])|set(paths)
runtime={p:sha((control/p).read_bytes())for p in sorted(keys)}
record={'classification':'Independent changed-code coastal return v4: old4ab+escape6+return-v3, shared native wind mechanical extraction and wind-aware staged proofs; excludes later root932/97 nursing/portrait/counter-battery/unload changes','baseCommit':head,'worktree':str(control),'trackedDiff':subprocess.check_output(['git','diff'],cwd=control,text=True),'parentSourceSha256':sha((root/'coastal-return-v3-runtime-source.json').read_bytes()),'sources':sources,'runtimeHashes':runtime,'contract':'Normal public commands, rule2, original170400 fullworld+nextId and both frozen agents/memories. Native wind formula unchanged; no private position/heading/route injection. Not acceptance/port-completion evidence.','nativeExtractionEvidence':str(root/'transit-wind-extract-equivalence.json'),'incrementalChangesFromV3':['shared sailing mechanical wind and companion pure extraction copied from naval_review','transitLegProof checks actual native wind substitution and rejects partial suffix proof','coastal staged proof retains direct+wind paths/input key and confirms native first leg after continuation query before ordinary move']}
(root/'coastal-return-v4-runtime-source.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
patch=[]
for p in paths:
 oldtext=old['sources'].get(p,{}).get('text',old['sources'].get(p,{}).get('source'))
 if oldtext is None:
  try:oldtext=subprocess.check_output(['git','show',head+':'+p],cwd=control,text=True,stderr=subprocess.DEVNULL)
  except subprocess.CalledProcessError:oldtext=''
 patch.extend(difflib.unified_diff(oldtext.splitlines(keepends=True),sources[p]['text'].splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(root/'coastal-return-v3-to-v4.patch').write_text(''.join(patch))
print(json.dumps({'sources':len(sources),'runtimeHashes':len(runtime),'sourceSha256':sha((root/'coastal-return-v4-runtime-source.json').read_bytes())}))
