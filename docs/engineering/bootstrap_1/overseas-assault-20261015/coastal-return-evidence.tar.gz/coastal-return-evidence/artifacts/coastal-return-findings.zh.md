# 沿岸炮船返港诊断：尚未抵港

这些都是从既有规则 2 对局完整存档切换代码后的诊断续局。它们不是普通开局的新胜局、不是冻结对手最终验收，也不能把局部未再受伤写成全场少损。原始容器未提交改动无法恢复的缺口保持不变。

## 已有反证

- 原 escape 固定源在 171172 tick 返港失败：船上弩车在 170906 tick 先打到原本 idle 的雏龙，整营进入战斗；28 HP 炮船最终沉没。完整主动引营链在既有 coastal-escape-evidence 包，不能称修复已返港。
- v2 从原 170400 完整 world/nextId/双方 memory 正常 AI 到 174000。船绕开原龙营，HP 仍为 28、乘员仍为 200，但尚未回港。原生迎风 tack 会把已验证 direct leg 替换成危险路线，下一 think 被策略停止；多次停启仍是负面证据。
- v2 的 173715 tick，当前船位和安全返港 mark 均无 outmatchingCoast，但无关的全舰队假定 destinationCoast 抢占 HURT 返港而发 hold。真实 fixture 红测失败，v3 把既有 HURT 分支移到该假定 destination 前；真实当前位置受威胁的撤退仍在先。

## v3 正常 AI 的实际结果

独立 4ab8411d 基线 + 已冻结 escape 六文件 + coastal return v3；未纳入 root 后来的护理、反炮、肖像登陆等工作。源胶囊 coastal-return-v3-runtime-source.json。

173715→178800 正常完整 AI，未过滤或注入命令。最后船在 (7350.45157762275, 4463.061826427508)，28/260 HP，乘员弩车 200/200。距 shipyard 989.7585896294592 像素，无修理增长，**仍未抵港**。

174690 tick 的首次 stop 来自 navalServices 工程师跨船接驳，不能归因迎风：此刻原生实际返港路线 transitRouteClear=true。services 发 stop 炮船与 board worker-1，把工人从 warship1100 转到炮船26580，预约两船。178800 工人仍在源船甲板保留 board/rendezvous 订单，两船 idle 且被预约。

178800 只读物理查询：decksTouch、decksSupportCrossing、decksAllowCrossing、decksCanTransfer、canBoard 都为 true。实际 connectedSurfacePath 是两点且 complete=false；去除两船其它乘员后，四点路径 complete=true。clearTransferLanes 没有给这组甲板乘员发让路命令。该几何反例已交 integration_review 独占修复，未增加服务超时或绕过服务层。coastal-return-v3-service-178800.png 是该完整世界的真实 drawWorld 图。

v3 归属边界：8 个生产全文与 1331 个非变动清单文件 postflight 相同。1332 清单中的 coastal-risk.test.ts 在启动后增加了一项测试；非 AI 导入，但不能写“1332 全部未改”。其全文/前后 hash 在 source-postflight 中。

## v4 风向查询候选（运行结果另附）

真实 170670 tick：船 speed=0，旧 direct proof 接受普通 move(5952,6208) 且安全。170685 tick 原生 route.windTried=true，22 个 tack 点替代原路，实际路径 unsafe。两份完整预决策 world/nextId/双 memory 均保留，counterexample 查询不改世界。

新风向计算由 naval_review 从原生 sailing 机械抽出，3×240 tick 等价证据由该 agent 单列保存。本 owner 复用 transitLegProof，保留 direct 与 wind 两条可能路径、风/handling 输入 key。lookahead 通过后下一 think 再用当前 traffic 复核首 leg 与同一末 pose，仍每 think 最多一次 probe，不安装 private route/heading。

v4 源胶囊 10 个生产全文、1333 hash，SHA256 f744b928c04447449071baa2cfea8f7a0c9809e4b137c9141b40c16e8f0a0c72。36 项针对性回归与 tsc 通过。正常 AI 原 170400→175200 已启动时冻结源码；起点沿用原 world/nextId/双方 memory，无指令过滤或注入。此前例证不可因新候选启动而改写成成功。

所有完整 AI 结果与 terminal 结果使用独立文件名，旧 183600 inProgress seal 不变。完整比赛两份独立旧/escape 对照均到 204000 horizon，winner=null，两局 p0 buildingsDestroyed=0；敌军减员不等于敌基地被攻下。

### v4 已完成的真实窗口

170400→175200 与同源 175200→178800 两段均完成，第二段从第一段完整终态 JSON 恢复，world/nextId/双 memory 三项全相等；结束时全部 1333 hash 与 10 个生产文件不变。各段均是正常全 AI 与冻结 v5 对手，没有人工微操。

- 171375 到第一 mark(5696,6336)，实际末点差 0.5024px；172590 到第二 mark(6080,6080)，差 4.2631px；174015 到第三 mark(6929.4332,4974.5668)，差 1.4572px，均在既有实际到达范围内。各到点后停止并从真实姿态重验，没有复用私有路线。
- 旧 v2 从170430至171045反复对(5952,6208)发 move，15 tick 后 stop；v4 未再发这个误 proof 目的地，正常走过前三段。
- 174375 的 stop 再次确认来自 services stop+worker board，彼时实际返港 road clear=true。175200仍在原生接驳；继续到178800后，worker仍在 warship1100.deck local(22.6073721,-27.0424370)，保留往炮船的 board/rendezvous/deckPoint。炮船 idle(7351.5096094,4461.6768765)，距 shipyard 988.0210820px，船28HP/弩车200HP，无维修。**不是返港成功。**
- 此轮可归属的改善只有所记录跨海返港航段的重复停启消失与真实前进；未证明整场减少损失、成功维修、攻下建筑或获胜。
