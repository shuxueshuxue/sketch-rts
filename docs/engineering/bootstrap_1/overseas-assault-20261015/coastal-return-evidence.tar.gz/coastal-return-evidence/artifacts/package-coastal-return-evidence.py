import json,hashlib,tarfile,io,datetime
from pathlib import Path
r=Path('/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015');repo=Path('/workspace/sketch-rts-bootstrap-resume');control=Path('/workspace/sketch-rts-coastal-return-control')
sha=lambda b:hashlib.sha256(b).hexdigest()
final=r/'coastal-return-v4-full-ai.json'
if not final.exists()or not(r/'coastal-return-v4-continuation-full-ai.json').exists():raise SystemExit('v4/continuation still running; do not seal completed evidence')
v4=json.loads(final.read_text());v4continuation=json.loads((r/'coastal-return-v4-continuation-full-ai.json').read_text());v3=json.loads((r/'coastal-return-v3-full-ai.json').read_text());v2=json.loads((r/'coastal-return-v2-full-ai.json').read_text())
source=json.loads((r/'coastal-return-v4-runtime-source.json').read_text());mismatch=[p for p,h in source['runtimeHashes'].items()if sha((control/p).read_bytes())!=h]
if mismatch:raise SystemExit('changed fixed runtime: '+str(mismatch))
files={}
def add(path,arc):files[arc]=path.read_bytes()
for glob in ['coastal-return-v2*','coastal-return-v3*','coastal-return-v4*','coastal-return-wind-counterexample*','coastal-return-findings.zh.md','coastal-deck-fit-timeline*','coastal-return-owner-incremental.patch','coastal-return-priority-*','coastal-return-red*','coastal-return-final-red*','capture-coastal-return-v4-source.py','package-coastal-return-evidence.py']:
 for p in sorted(r.glob(glob)):
  if p.is_dir():
   for f in sorted(p.rglob('*')):
    if f.is_file():add(f,'artifacts/'+str(f.relative_to(r)))
  elif p.is_file():add(p,'artifacts/'+p.name)
for p in [control/'src/ai/bootstrap_1/coastal-return.test.ts',control/'src/ai/policy/coastal-return.ts']:
 add(p,'candidate/'+str(p.relative_to(control)))
for p in sorted((control/'src/ai/bootstrap_1/fixtures').glob('coastal-return*.json.gz')):add(p,'candidate/'+str(p.relative_to(control)))
# Shared native extraction itself is owned elsewhere; include its independently sealed evidence too.
for name in ['transit-wind-extract-equivalence.json','transit-wind-extract-equivalence.log','transit-wind-extraction.patch','transit-wind-native-regressions.log','transit-wind-query-tests.log']:
 if(r/name).exists():add(r/name,'shared-evidence/'+name)
id='unit-p0-bombardShip-26580'
def summary(run):
 s=run['snapshot'];boat=next((u for u in s['units']if u['id']==id),None);home=next(b for b in s['buildings']if b['owner']=='p0'and b['kind']=='shipyard');return{'tick':s['tick'],'winner':s.get('winner'),'ship':boat,'homeDistance':((boat['x']-home['x'])**2+(boat['y']-home['y'])**2)**.5 if boat else None,'crew':[u for u in s['units']if u.get('deck',{}).get('shipId')==id]}
index={'classification':'Diagnostic changed-code normal full-AI return windows, not ordinary-opening/complete-match victory/generalization acceptance. Old 183600 inProgress seal is untouched.','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktreeBase':source['baseCommit'],'sourceSha256':sha((r/'coastal-return-v4-runtime-source.json').read_bytes()),'runtimeAllUnchanged':not mismatch,'runtimeHashCount':len(source['runtimeHashes']),'restoration':{'v2':v2['source']['restore'],'v3':v3['source']['restore'],'v4':v4['source']['restore'],'v4Continuation':v4continuation['source']['restore']},'actualResults':{'v2':summary(v2),'v3':summary(v3),'v4':summary(v4),'v4Continuation':summary(v4continuation)},'negativeEvidence':['Original escape returned through crew-provoked dragon camp and died171172; separate sealed coastal-escape-evidence retains exact chain','v2 direct-proof unsafe native wind replacement repeatedly stopped','v2 real173715 unrelated hypothetical combat destination held safe HURT return','v3 178800 cross-deck engineer transfer reserved two hulls, passenger path incomplete with bystanders; still989.76px from port, no healing','v3 source manifest one postlaunch test-only change recorded; production8 unchanged'],'files':{p:{'sha256':sha(b),'bytes':len(b)}for p,b in sorted(files.items())}}
files['INDEX.json']=json.dumps(index,ensure_ascii=False,indent=2).encode()
out=repo/'docs/engineering/bootstrap_1/overseas-assault-20261015/coastal-return-evidence.tar.gz';prefix='coastal-return-evidence'
with tarfile.open(out,'w:gz')as tar:
 for p,b in sorted(files.items()):
  info=tarfile.TarInfo(prefix+'/'+p);info.size=len(b);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz')as tar:
 for p,b in files.items():
  if sha(tar.extractfile(prefix+'/'+p).read())!=sha(b):raise SystemExit('archive mismatch: '+p)
receipt={'path':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'fileCount':len(files),'index':prefix+'/INDEX.json','allContentHashesVerified':True,'runtimeAllUnchanged':not mismatch,'runtimeHashCount':len(source['runtimeHashes'])}
(r/'coastal-return-evidence-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
