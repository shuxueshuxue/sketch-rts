import {MOVE_ORDER_ARRIVAL_RANGE} from '../../shared/movement-rules';
import {routeClearsDisks,routePrefix} from '../../shared/route-selection';
import {shipTrafficKey} from '../../shared/ship-avoidance';
import {shipProfile,type Point} from '../../shared/ship-geometry';
import {headingDifference,type ShipPose} from '../../shared/ship-navigation';
import {segmentWalkable} from '../../shared/terrain';
import type {GameCommand,GameSnapshot,Unit} from '../../shared/types';
import {coastalFireSegmentClear,type CoastalFireDisk} from './coastal-voyage';
import {transitDepartureCandidates,transitLegProof,transitPlanningKey,transitFireDisks,transitReference,transitRouteClear,transitRoutePrefixClear} from './transit-route';
import type {AiPolicyContext} from './types';

export type CoastalReturnPlan={
 goal:Point;queryKey:string;candidates:Point[];next:number;reference:Point[];referenceComplete:boolean;mark?:Point;entry?:Point;continuation?:Point;pendingReference?:true;
 proposal?:{mark:Point;origin:ShipPose;end:ShipPose;candidates:Point[];next:number;leg:ShipPose[];direct:ShipPose[];inputKey:string;approved?:Point;pendingReference?:true};
};
export type CoastalReturnBudget={built:boolean;probed:boolean};
const gap=(a:Point,b:Point)=>Math.hypot(a.x-b.x,a.y-b.y);
function candidates(snapshot:GameSnapshot,ship:Unit,reference:readonly Point[],disks:CoastalFireDisk[]) {
 const length=shipProfile(ship)!.length;
 return routePrefix(ship,reference,length*6).slice(1).filter(point=>gap(ship,point)>length/2
  && segmentWalkable(snapshot.map,ship,point,'sea')&&routeClearsDisks([ship,point],disks)).reverse();
}
function afterMark(reference:Point[],mark:Point) {
 for(let i=0;i<reference.length;i++) {
  if(gap(reference[i]!,mark)<1e-6)return reference.slice(i+1);
  const previous=reference[i-1];
  if(previous&&Math.abs(gap(previous,mark)+gap(mark,reference[i]!)-gap(previous,reference[i]!))<1e-6)return reference.slice(i);
 }
}

/** Existing HURT return owns the ship. Check its observed native prefix, then
 * query finite ordinary legs before a camp can be provoked by its passengers.
 * A reference is geometry only; a mark and its exit need native direct proofs.
 * Neither a private route nor a heading is installed in the game. */
export function planCoastalReturn(snapshot:GameSnapshot,ship:Unit,goal:Point,options:AiPolicyContext,budget:CoastalReturnBudget):{active:boolean;command?:GameCommand} {
 const memory=(options.memory.naval??={}).coastalReturns??={},disks=transitFireDisks(snapshot,ship,options);
 const current={x:ship.x,y:ship.y,heading:ship.sailing!.heading},route=ship.sailing!.route,length=shipProfile(ship)!.length;
 let query=memory[ship.id],entry:Point|undefined;
 if(query&&gap(query.goal,goal)>1e-5){delete memory[ship.id];query=undefined;}
 const movingHome=ship.order.type==='move'&&gap(ship.order,goal)<1e-5;
 if(!query&&(!movingHome||!route?.points.length))return {active:false};
 if(!query&&route&&(transitRoutePrefixClear(ship,route.points,disks,length)
  ||route.partial===false&&transitRouteClear(ship,route.points,disks)))return {active:false};
 // Prevention has no escape proof when fire already contains the hull. The
 // earlier live coastal retreat keeps ownership of that situation.
 if(!coastalFireSegmentClear(current,current,disks)){delete memory[ship.id];return {active:false};}
 const inputKey=transitPlanningKey(snapshot,ship);
 const queryKey=disks.map(d=>`${d.id}:${Math.round(d.x/64)}:${Math.round(d.y/64)}:${Math.round(d.radius)}`).join('|')+shipTrafficKey(ship,snapshot.units)+inputKey;
 if(query?.mark&&gap(ship,query.mark)<=MOVE_ORDER_ARRIVAL_RANGE){entry=query.continuation;delete memory[ship.id];query=undefined;}
 if(query?.mark){
  if(ship.order.type==='move'&&gap(ship.order,query.mark)<1e-5&&route?.points.length&&transitRouteClear(ship,route.points,disks))return {active:true};
  delete memory[ship.id];query=undefined;
 }
 if(!query||!query.proposal&&query.next>=query.candidates.length&&query.queryKey!==queryKey){
  query={goal:{...goal},queryKey,candidates:[],next:0,reference:[],referenceComplete:false,pendingReference:true,...(entry?{entry}:{})};
  memory[ship.id]=query;
 }
 if(query.pendingReference&&!budget.built){
  budget.built=true;const reference=transitReference(snapshot,ship,goal,disks);
  query.candidates=[...(query.entry?[query.entry]:[]),...candidates(snapshot,ship,reference.points,disks),...transitDepartureCandidates(snapshot,ship,disks)];
  query.reference=reference.points;query.referenceComplete=reference.complete;delete query.pendingReference;
 }
 // A stop changes the native braking-entry geometry even at the same pose.
 // Query from the real stopped state, rather than retain a moving proof.
 if(ship.sailing!.speed>0)return {active:true,command:{type:'stop',unitIds:[ship.id]}};
 if(query){
  let accepted:Point|undefined;
  if(query.proposal&&(gap(query.proposal.origin,current)>1e-5||Math.abs(headingDifference(query.proposal.origin.heading,current.heading))>1e-5||query.proposal.inputKey!==inputKey||!transitRouteClear(ship,query.proposal.leg,disks)||!transitRouteClear(ship,query.proposal.direct,disks)))delete query.proposal;
  if(query.proposal){
   const proposal=query.proposal,arrived:Unit={...ship,...proposal.end,sailing:{...ship.sailing!,heading:proposal.end.heading,speed:0}};
   if(proposal.approved&&!budget.probed){
    // The lookahead consumed a previous think. Recheck the first ordinary
    // move against current traffic before committing its continuation.
    budget.probed=true;const fresh=transitLegProof(snapshot,ship,proposal.mark,disks),end=fresh?.points.at(-1);
    if(fresh&&end&&JSON.stringify(end)===JSON.stringify(proposal.end)){accepted=proposal.mark;query.continuation=proposal.approved;}
    delete query.proposal;
   }
   if(!budget.probed&&proposal.pendingReference&&!budget.built){
    budget.built=true;const road=transitReference(snapshot,arrived,goal,disks);
    proposal.candidates=candidates(snapshot,arrived,road.points,disks);delete proposal.pendingReference;
   }
   const next=!proposal.pendingReference&&!budget.probed?proposal.candidates[proposal.next]:undefined;
   if(next){budget.probed=true;proposal.next++;if(transitLegProof(snapshot,arrived,next,disks))proposal.approved=next;}
   if(!proposal.approved&&!proposal.pendingReference&&proposal.next>=proposal.candidates.length)delete query.proposal;
  }else if(!budget.probed&&!query.pendingReference){
   const mark=query.candidates[query.next];
   if(mark){
    budget.probed=true;query.next++;const leg=transitLegProof(snapshot,ship,mark,disks),end=leg?.points.at(-1);
    if(end){
     if(gap(mark,goal)<=MOVE_ORDER_ARRIVAL_RANGE)accepted=mark;
     else{
      const rest=afterMark(query.reference,mark),arrived:Unit={...ship,...end,sailing:{...ship.sailing!,heading:end.heading,speed:0}};
      query.proposal={mark,origin:current,end,leg:leg!.points,direct:leg!.direct,inputKey,candidates:rest?candidates(snapshot,arrived,rest,disks):[],next:0,...(!rest?{pendingReference:true as const}:{})};
      if(rest&&!query.proposal.candidates.length)delete query.proposal;
     }
    }
   }
  }
  if(accepted){query.mark=accepted;return {active:true,command:{type:'move',unitIds:[ship.id],x:accepted.x,y:accepted.y,avoidCombat:true}};}
 }
 return ship.order.type!=='idle'||route?.points.length
  ? {active:true,command:{type:'stop',unitIds:[ship.id]}}:{active:true};
}
