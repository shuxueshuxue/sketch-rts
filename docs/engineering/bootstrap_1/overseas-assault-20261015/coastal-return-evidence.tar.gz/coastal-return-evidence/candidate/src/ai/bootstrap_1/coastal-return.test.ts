import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';import {expect,it} from 'vitest';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '../../shared/sim';
import {planBootstrapNaval} from './expedition-recovery';import {bootstrapPolicyContext} from './policy';
import {transitDirectLeg,transitFireDisks,transitRouteClear,transitRoutePrefixClear} from '../policy/transit-route';
import {outmatchingCoast} from '../policy/coastal-risk';
const id='unit-p0-bombardShip-26580';
function observed(name:string){const saved=JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/'+name+'.json.gz',import.meta.url))).toString()),game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const snapshot=snapshotGame(game),ship=snapshot.units.find(u=>u.id===id)!,options=bootstrapPolicyContext(snapshot,'p0','v9_summoner',{memory:structuredClone(saved.memory),teams:game.teams});return{snapshot,ship,options};}
it('protects the actual28HP HURT return before public movement can pass the dragon camp',()=>{const {snapshot,ship,options}=observed('coastal-return-start');expect(snapshot.tick).toBe(166440);expect(ship.hp).toBe(28);const commands=planBootstrapNaval(snapshot,'p0',options).filter(c=>'unitIds'in c&&c.unitIds.includes(id));// The existing public initial turn is retained; prevention starts from its observed native prefix.
expect(commands).toContainEqual({type:'move',unitIds:[id],x:7856,y:3632,avoidCombat:true});});
it('replaces the real camp-approach unsafe native home road without disabling crew skills',()=>{const {snapshot,ship,options}=observed('coastal-return-camp-approach');expect(snapshot.tick).toBe(170400);const before=JSON.stringify(snapshot);expect(transitRouteClear(ship,ship.sailing!.route!.points,transitFireDisks(snapshot,ship,options))).toBe(false);const commands=planBootstrapNaval(snapshot,'p0',options).filter(c=>'unitIds'in c&&c.unitIds.includes(id));expect(commands.length).toBeGreaterThan(0);expect(commands.some(c=>c.type==='move'&&c.x===7856&&c.y===3632)).toBe(false);expect(JSON.stringify(snapshot)).toBe(before);});

it('retains the actual safe native departure prefix while the later home road still crosses camps',()=>{const {snapshot,ship,options}=observed('coastal-return-prefix');expect(snapshot.tick).toBe(166800);const points=ship.sailing!.route!.points,disks=transitFireDisks(snapshot,ship,options);expect(transitRouteClear(ship,points,disks)).toBe(false);expect(transitRoutePrefixClear(ship,points,disks,242.88)).toBe(true);expect(transitRoutePrefixClear(ship,[],disks,242.88)).toBe(false);expect(planBootstrapNaval(snapshot,'p0',options).filter(c=>'unitIds'in c&&c.unitIds.includes(id))).toEqual([]);});

it('keeps the real safe repair return ahead of an unrelated fleet coastal destination',()=>{const {snapshot,ship,options}=observed('coastal-return-priority');expect(snapshot.tick).toBe(173715);expect(ship.hp).toBe(28);const query=options.memory.naval!.coastalReturns![id]!;expect(ship.order).toMatchObject({type:'move',...query.mark!,avoidCombat:true});expect(outmatchingCoast(snapshot,'p0',ship,ship,options)).toEqual([]);expect(outmatchingCoast(snapshot,'p0',ship,query.goal,options)).toEqual([]);expect(transitRouteClear(ship,ship.sailing!.route!.points,transitFireDisks(snapshot,ship,options))).toBe(true);expect(planBootstrapNaval(snapshot,'p0',options).filter(c=>'unitIds'in c&&c.unitIds.includes(id))).toEqual([]);expect(options.memory.naval!.coastalReturns![id]).toEqual(query);});

it('rejects the real stopped departure whose ordinary native wind tack crossed the dragon camp',()=>{
 const {snapshot,ship,options}=observed('coastal-return-wind'),before=JSON.stringify(snapshot);
 expect(snapshot.tick).toBe(170670);expect(ship.sailing!.speed).toBe(0);
 expect(transitDirectLeg(snapshot,ship,{x:5952,y:6208},transitFireDisks(snapshot,ship,options))).toBeUndefined();
 expect(planBootstrapNaval(snapshot,'p0',options).some(c=>c.type==='move'&&c.unitIds.includes(id)&&c.x===5952&&c.y===6208)).toBe(false);
 expect(JSON.stringify(snapshot)).toBe(before);
});
