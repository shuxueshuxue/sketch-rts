from pathlib import Path
import gzip,json,hashlib,datetime,itertools
A=Path('/workspace/.playtest/bootstrap-archer-38f-firstuse-v7v8-20261016');B=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016');O=Path('/tmp/root-known-archer0-first-difference-20261016');O.mkdir(exist_ok=True)
H=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def rows(p):
 with gzip.open(p,'rt')as f:
  for line in f:
   if line.strip():yield json.loads(line)
def firstdiff(pa,pb,keys):
 count=0;tail=[]
 for a,b in itertools.zip_longest(rows(pa),rows(pb)):
  na=None if a is None else{k:a[k]for k in keys};nb=None if b is None else{k:b[k]for k in keys}
  if na!=nb:return{'matchingRecordPrefix':count,'old':a,'new':b,'precedingMatchingContext':tail,'comparisonKeys':keys}
  count+=1;tail.append(a)
  if len(tail)>6:tail.pop(0)
 return{'matchingRecordPrefix':count,'old':None,'new':None,'comparisonKeys':keys}
commands=firstdiff(A/'game-commands.jsonl.gz',B/'known-archer0-8da5-commands.jsonl.gz',['tick','owner','source','scriptId','command']);plans=firstdiff(A/'game-plans.jsonl.gz',B/'known-archer0-8da5-plans.jsonl.gz',['tick','owner','entries']);tick=min(v['tick']for v in [commands['old'],commands['new'],plans['old'],plans['new']]if v is not None)
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def firstleaves(a,b,path='$',out=None):
 if out is None:out=[]
 if a==b:return out
 if len(out)>=12:return out
 if type(a)!=type(b)or not isinstance(a,(dict,list)):
  out.append({'path':path,'old':a,'new':b});return out
 if isinstance(a,list):
  if len(a)!=len(b):out.append({'path':path+'.length','old':len(a),'new':len(b)})
  for i,(x,y)in enumerate(zip(a,b)):firstleaves(x,y,path+'['+str(i)+']',out)
 else:
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append({'path':path+'.'+k,'oldPresent':k in a,'newPresent':k in b,'old':a.get(k),'new':b.get(k)})
   else:firstleaves(a[k],b[k],path+'.'+k,out)
   if len(out)>=12:break
 return out
checkpoints=[]
for t in range(0,tick+1,600):
 pa=A/'game.frames'/f'{t}.json.gz';pb=B/'known-archer0-8da5.frames'/f'{t}.json.gz'
 if not pa.exists()or not pb.exists():checkpoints.append({'tick':t,'oldExists':pa.exists(),'newExists':pb.exists()});continue
 a=load(pa);b=load(pb);parts={k:a.get(k)==b.get(k)for k in ('snapshot','nextId','memories','setup')};checkpoints.append({'tick':t,'oldPath':str(pa),'newPath':str(pb),'oldSHA256':H(pa),'newSHA256':H(pb),'equality':parts,'allFourEqual':all(parts.values()),'firstDifferences':firstleaves({k:a.get(k)for k in parts},{k:b.get(k)for k in parts})})
near=checkpoints[-1];newpost=plans['new'].get('postMemories')if plans['new']else None
j={'classification':'Readonly actualcompleted ordinary0 rawflow comparison; no new Game/step/P0/profile and no reconstruction ofmissingoldpostmem. Newcombinedsource result cannot be assigned tosinglemedicaldelta.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oldSource':'38f5dd79ae588d578dce15b9baa2cd41f20f2a4b','oldRootByteEquivalent':'760ef777eeaf0eb13a67bef5b2221fbf777126a9','newSource':'8da5b0e4d65c0a5d355ecd9bdcbdb9c4ae23051d','oldResult':{'naturalDefeatTick':82182,'permanentOwnLosses':65},'newResult':{'naturalDefeatTick':37789,'permanentOwnLosses':69},'firstCommandDifference':commands,'firstPlanEntriesDifference':plans,'firstDifferenceTick':tick,'preceding600Checkpoints':checkpoints,'nearestAvailable600':near,'lastWholeCheckpointEqual':next((x for x in reversed(checkpoints)if x.get('allFourEqual')),None),'oldImmediatePostP0Memory':'Originaloldplanflow doesnotrecordpostMemories; remainsmissing, no borrowednewmemory or fabricatedoldquery. Onlyreal600completeframes compared.','newActualPostMemoriesAtFirstPlanDifference':newpost,'limits':['Semanticcommand comparisonretains tick/owner/source/scriptId/fullcommand values. Rawindex/traceKind retainedinactualrows but notusedtoinventcommandmismatch.','Plancomparisonuses tick/owner/fullentries onlybecauseoldpostmemwasneverrecorded; actualnewpostMemories preservedasadditionalnew-onlyevidence.','Checkpointworld/id/3mem/setup comparedwithoutdeletingfields orignoringmemorydifferences. CompressedSHA can differ despiteJSONvalue equality.','No claim identicalworldatnoncheckpoint firstdifference input unlessalreadyactualfullframeexists. No simulationusedtoreconstructit.','Readonlyflow correspondence shows firstactualpublished difference, not exclusivecausality ofeventual69lossdefeat.','Originalbrokencontaineruncommittedgap remains.']}
for name,obj in [('FIRST-DIFFERENCE.json',j),('FIRST-DIFFERENT-PLAN-RAW.json',{'old':plans['old'],'new':plans['new']}),('FIRST-DIFFERENT-COMMAND-RAW.json',{'old':commands['old'],'new':commands['new']})]:
 (O/name).write_text(json.dumps(obj,indent=2))
for label,D,prefix in [('old',A,'game'),('new',B,'known-archer0-8da5')]:
 for t in sorted({near['tick'],j['lastWholeCheckpointEqual']['tick']if j['lastWholeCheckpointEqual']else0}):
  p=D/(prefix+'.frames')/(str(t)+'.json.gz')
  if p.exists():(O/f'{label}-{t}-actual600.json.gz').write_bytes(p.read_bytes())
files=[A/'game-commands.jsonl.gz',A/'game-plans.jsonl.gz',B/'known-archer0-8da5-commands.jsonl.gz',B/'known-archer0-8da5-plans.jsonl.gz'];(O/'READSET.json').write_text(json.dumps({'files':{str(p):{'bytes':p.stat().st_size,'sha256':H(p)}for p in files}},indent=2))
print(json.dumps({'O':str(O),'firstCommand':{k:v for k,v in commands.items()if k!='precedingMatchingContext'},'firstPlanEntries':{k:(v if k not in ('old','new')else{'tick':v['tick'],'owner':v['owner'],'entries':v['entries']})for k,v in plans.items()if k!='precedingMatchingContext'},'nearest600':near,'lastWholeEqual':j['lastWholeCheckpointEqual']},indent=2))
