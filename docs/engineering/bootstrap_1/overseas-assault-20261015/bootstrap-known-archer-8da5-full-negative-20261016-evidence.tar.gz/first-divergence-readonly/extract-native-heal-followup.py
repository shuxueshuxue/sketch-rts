from pathlib import Path
import json,gzip,hashlib,math,datetime
O=Path(__file__).resolve().parent;A=Path('/workspace/.playtest/bootstrap-archer-38f-firstuse-v7v8-20261016');B=Path('/workspace/.playtest/bootstrap-next-root-known-archer0-20261016');ids={'unit-p0-footman-1070','unit-p0-lancer-1979','unit-p0-lancer-1527','unit-p0-fieldMedic-1418','unit-p0-fieldMedic-1602'}
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def rows(p):
 with gzip.open(p,'rt')as f:
  for line in f:
   if line.strip():yield json.loads(line)
f=load(A/'game.frames/8400.json.gz');units={u['id']:u for u in f['snapshot']['units']if u['id']in ids};j={'classification':'Read-only rawactual nativehealth/effects/commands followup to firstdifference. No new Game/query/P0/native steps.','atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'shared8400units':units,'doctorDistancesTo1070':{uid:math.hypot(units[uid]['x']-units['unit-p0-footman-1070']['x'],units[uid]['y']-units['unit-p0-footman-1070']['y'])for uid in ['unit-p0-fieldMedic-1418','unit-p0-fieldMedic-1602']},'variants':{}}
for label,D,pre in [('old38f',A,'game'),('new8da',B,'known-archer0-8da5')]:
 v={};readset={}
 for suffix in ['commands','health-transitions','healing-effects','native-hits','native-deaths']:
  p=D/f'{pre}-{suffix}.jsonl.gz';readset[str(p)]={'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()};out=[]
  for r in rows(p):
   if not 8400<=r['tick']<=12600:continue
   if suffix=='commands':
    if r['tick']>8760:continue
    c=r['command']; relevant=any(uid in c.get('unitIds',[])or c.get('unitId')==uid or c.get('targetId')==uid for uid in ids)
   elif suffix=='healing-effects':relevant=r['tick']<=9000
   elif suffix=='native-hits':relevant=r.get('target')in ids or r.get('attacker')in ids
   else:relevant=r.get('id')in ids
   if relevant:out.append(r)
  v[suffix]=out
 v['readset']=readset;j['variants'][label]=v
j['observedConclusions']=['At8400 doctors are farbeyond nativeheal range240: oldcast attempts notinstant healing. Both0..8460 no1070healing observed.','NativecastAbility/updateCastOrder/castError/heal catalog exactold/new equality proves nativepubliccast can legally approach anout-of-range patient; it isnot automaticallya transientnoop. Specificcommand execution stilljudgedactualstate.','Both1070 got28->83 at8760; second83->138 old8775/new8770. Cannot labelnewcase as nohealing.','Earlier sharedinitiallancer1979 diednew8504 with32->-2 fromneutralogreLord34, whereasoldremainedaliveuntil8520 received55 to87 andhadnodeaththrough12600.','Old8520/8531 healspaired1979+1527; new8520/8530 bothheal1527(25->80->130), after1979alreadydied. Thisisactualchangedtriage/position chain, notexclusiveeventualdefeatcause.','At8460 bothactualpipelines sentlowHP1979samev6GeneralattackMove(1509,1197) between campRecoverymoves. Prior/subsequentcovergoals differ~pixels afterdoctorspositionsdiverged; needactualtargetednative causalverification beforefixorwholematchattribution.']
j['remainingLimits']=['Onlyimmutablealreadyrecordedstreams inspected; nopureplanner orgeometryquery invoked.','OldimmediatepostP0memory neverrecorded andisnotfilled. Same8400fullworld/id/all3mem/setup suppliedexactbytewise.','Afterfirstdivergence laterborn IDs may correspond todifferententities; hereonlyIDs alreadysharedat8400tracked.','Positivehealthchanges/fullnativehealeffects areactualobservations, butfullcausality ofalllaterdeaths isnotproved.','Allopponents/resources/rules remainednormal, sourcechangescombined.']
(O/'NATIVE-HEAL-FOLLOWUP.json').write_text(json.dumps(j,indent=2));print('sealedfollowup',len(json.dumps(j)),{label:{k:len(v)for k,v in d.items()if isinstance(v,list)}for label,d in j['variants'].items()})
