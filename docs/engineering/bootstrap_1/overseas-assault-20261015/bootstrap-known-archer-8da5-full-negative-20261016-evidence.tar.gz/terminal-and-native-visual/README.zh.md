8da5 新普通开局原局自然在37789 tick被P1彻底消灭，P0永久损失69。本目录仅该原局证据与原37200→37789唯一589 tick冷闭合，不是额外比赛，也不能单独归因整个医疗delta。

原始600帧和14个闭合原raw/driver文件已复制并逐SHA/mtime校验。12000→12600的11损为六工人被塔、四工人被灵体、一长枪兵被cinderRunner。3张同8da5原生drawWorld图已亲看，均无Game/query/P0/step/施令。

EXACT-COLD-FINAL589-CLOSURE.json：925 commands、120每owner策略输出（每次全部三方postmem）、419 hits、44 events、10 deaths逐对象全等，另外corpse/health/healing均0且等；最终完整world/id/全部3mem/setup全等。1497源与497冻结文件/184manifest/rules2前后固定，唯一Game实际exit0且OOM未增。

最早实际分歧8400的完整共同输入/前缀证明引用failed的独立只读封包，未伪造旧源缺失的postmem。17bc两海军修复在无船无码头至8400的原始输入中不可触发，具体调用与raw births在FIRST-DIFF-17BC-NAVAL-SCOPE.json。下一关注实际1979@8504野怪死亡及医者原生走施/退路，而不是再全矩阵。

原容器未提交改动缺口未恢复。
