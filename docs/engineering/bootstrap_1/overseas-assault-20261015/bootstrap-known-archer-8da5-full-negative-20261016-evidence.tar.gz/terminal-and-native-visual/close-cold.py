from pathlib import Path
import json,gzip,hashlib,itertools
D=Path('/tmp/bootstrap-root-known-8da-loss12600-20261016');O=D/'cold37200-37789';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pre='known-archer0-8da5'
def rows(p):
 op=gzip.open if p.suffix=='.gz'else open
 with op(p,'rt')as f:
  for l in f:
   if l.strip():yield json.loads(l)
def suffix(r,stream):
 return 37200<=r['tick']<37789 if stream in ['commands','plans']else 37200<r['tick']<=37789 or r['tick']==37200 and r.get('commandIndex')is not None
out={}
for stream in ['commands','plans','native-hits','native-events','native-deaths','corpse-events','health-transitions','healing-effects']:
 p=D/'original'/f'{pre}-{stream}.jsonl.gz';q=O/f'{stream}.jsonl';a=(r for r in rows(p)if suffix(r,stream));b=rows(q);n=0;first=None;oldn=newn=0
 sentinel=object()
 for x,y in itertools.zip_longest(a,b,fillvalue=sentinel):
  if x is not sentinel:oldn+=1
  if y is not sentinel:newn+=1
  if first is None and x!=y:first={'index':n,'old':None if x is sentinel else x,'new':None if y is sentinel else y}
  n+=1
 out[stream]={'actualRows':oldn,'coldRows':newn,'allObjectsExact':first is None,'firstDifference':first,'actualGzipSHA256':H(p),'coldSHA256':H(q)}
old=json.loads(gzip.decompress((D/'captured/37789.json.gz').read_bytes()));new=json.loads(gzip.decompress((O/'final.json.gz').read_bytes()));out['final']={k:old[k]==new[k]for k in ['snapshot','nextId','memories','setup']};out['allExact']=all(v['allObjectsExact']for k,v in out.items()if k not in ['final','allExact'])and all(out['final'].values());out['classification']='One final589tick closure of original8da5 natural37789 P1win, no new match or medical attribution.'
(D/'EXACT-COLD-FINAL589-CLOSURE.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v if k in ['final','allExact']else{k2:v[k2]for k2 in ['actualRows','coldRows','allObjectsExact']}for k,v in out.items()if k!='classification'},indent=2));assert out['allExact']
