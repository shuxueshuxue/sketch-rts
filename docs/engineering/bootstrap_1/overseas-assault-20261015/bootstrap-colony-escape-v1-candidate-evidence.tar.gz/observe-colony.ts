import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';

const input='/tmp/bootstrap-neutral-miners-b0/quiet-tower-cont38400.json';
const output='/tmp/bootstrap-colony-aggro-observer/39600-40200';
const cap=JSON.parse(readFileSync('/tmp/bootstrap-neutral-miners-b0/quiet-tower-fixed-source.json','utf8'));
const source=cap.sourceRoot;
const hash=(bytes:any)=>createHash('sha256').update(bytes).digest('hex');
const verify=()=>{
  const changed=Object.entries(cap.hashes).filter(([name,digest])=>hash(readFileSync(source+'/'+name))!==digest).map(([name])=>name);
  if(changed.length)throw Error('Fixed source changed: '+changed);
  return {paths:Object.keys(cap.hashes).length,changed};
};
const preflight=verify();
const {bootstrapGame,bootstrapMatches}=await import(pathToFileURL(source+'/src/ai/bootstrap_1/benchmark.ts').href);
const {restoreSnapshotIntoGame,snapshotGame}=await import(pathToFileURL(source+'/src/shared/sim.ts').href);
const {createAiMemoryProvider}=await import(pathToFileURL(source+'/src/ai/planner-context.ts').href);
const {createBootstrapCommandPlanner}=await import(pathToFileURL(source+'/scripts/bootstrap_1-planner.ts').href);
const {runAiGameLoop}=await import(pathToFileURL(source+'/src/ai/game-runner.ts').href);
const report=JSON.parse(readFileSync(input,'utf8'));
const row=report.rows.find((r:any)=>r.tick===39600);
const expectedRow=report.rows.find((r:any)=>r.tick===40200);
const frame=JSON.parse(readFileSync(input+'.frames/39600.json','utf8'));
const expected=JSON.parse(readFileSync(input+'.frames/40200.json','utf8'));
const match=bootstrapMatches(report.setup.seed,[report.setup.map],40200,report.setup.unseen).find((m:any)=>m.subject===report.subject && m.side===report.setup.side && m.agents.p0.race===report.setup.agents.p0.race && Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8');
if(!row||!expectedRow||!match)throw Error('Actual full input missing');
const game=bootstrapGame(match);
restoreSnapshotIntoGame(game,frame.snapshot,frame.nextId);
const memories=createAiMemoryProvider();
for(const [owner,p]of Object.entries(row.players)as any[])memories.set(owner,structuredClone(p.policy));
const json=(v:any)=>JSON.parse(JSON.stringify(v));
const allMemories=()=>Object.fromEntries(Object.keys(row.players).map(owner=>[owner,json(memories.get(owner))]));
const inputMemories=Object.fromEntries(Object.entries(row.players).map(([owner,p]:any)=>[owner,p.policy]));
const restore={world:isDeepStrictEqual(json(snapshotGame(game)),frame.snapshot),nextId:game.nextId===frame.nextId,allMemories:isDeepStrictEqual(allMemories(),inputMemories)};
if(Object.values(restore).some(v=>!v))throw Error('Actual input restore mismatch');
const local=(u:any)=>Math.hypot(u.x-4750,u.y-4900)<1100;
const units=()=>game.units.filter(local).map((u:any)=>({id:u.id,owner:u.owner,kind:u.kind,hp:u.hp,x:u.x,y:u.y,deck:structuredClone(u.deck),order:structuredClone(u.order),orderQueue:structuredClone(u.orderQueue),aggro:structuredClone(u.aggro),attackCooldown:u.attackCooldown}));
const commands:any[]=[],ticks:any[]=[],frames:any[]=[];
const planner=await createBootstrapCommandPlanner(memories);
ticks.push({tick:game.tick,units:units()});
runAiGameLoop({...match,game,commandPlanner:planner},{
  onCommand:({tick,owner,scriptId,command}:any)=>commands.push({tick,owner,scriptId,command:structuredClone(command)}),
  onStep:({game}:any)=>{
    ticks.push({tick:game.tick,units:units(),effects:structuredClone(game.effects.filter(local)),projectiles:structuredClone(game.projectiles.filter(local))});
    if(game.tick%15===0)frames.push({snapshot:snapshotGame(game),nextId:game.nextId,memories:allMemories()});
  }
});
const final={snapshot:snapshotGame(game),nextId:game.nextId,memories:allMemories()};
const expectedMemories=Object.fromEntries(Object.entries(expectedRow.players).map(([owner,p]:any)=>[owner,p.policy]));
const reproduction={world:isDeepStrictEqual(json(final.snapshot),expected.snapshot),nextId:game.nextId===expected.nextId,allMemories:isDeepStrictEqual(final.memories,expectedMemories)};
writeFileSync(output+'.json',JSON.stringify({classification:'Observer-only same fixed quiet-tower source, actual full39600 world/nextId/bothmem to actual40200. No intervention or source changes. Not ordinary0 or root production.',source,preflight,restore,reproduction,postflight:verify(),commands,ticks,frames})+'\n');
writeFileSync(output+'-final.json',JSON.stringify(final)+'\n');
console.log(JSON.stringify({restore,reproduction,commands:commands.length,frames:frames.length,sourcePaths:Object.keys(cap.hashes).length}));
if(Object.values(reproduction).some(v=>!v))throw Error('Actual branch did not reproduce');
