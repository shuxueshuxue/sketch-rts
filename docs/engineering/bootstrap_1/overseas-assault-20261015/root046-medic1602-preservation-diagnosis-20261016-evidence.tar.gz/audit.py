from pathlib import Path
import json,gzip,hashlib,datetime,math

D=Path('/workspace/.playtest/root046-medic1602-preservation-diagnosis-20261016')
R=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');P=R/'known-archer0-04669148';S=Path('/workspace/sketch-rts-root-medical-04669148-fixed-control')
ID='unit-p0-fieldMedic-1602';AT='unit-p1-spirit-31294';H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(kind):
 with gzip.open(str(P)+'-'+kind+'.jsonl.gz','rt') as f:
  for l in f:
   if l.strip():yield json.loads(l)
def actor(c):return c.get('unitId')==ID or ID in c.get('unitIds',[])
out={}
for kind in ['commands','native-hits','health-transitions','healing-effects','native-deaths','corpse-events']:
 chosen=[]
 for x in rows(kind):
  if kind=='commands':yes=24000<=x['tick']<=25047 and (actor(x['command'])or x['command'].get('targetId')==ID)
  elif kind=='native-hits':yes=24000<=x['tick']<=25047 and (x.get('target')==ID or x.get('attacker')==ID or x.get('attacker')==AT)
  elif kind=='health-transitions':yes=24000<=x['tick']<=25047 and x['id']==ID
  elif kind=='healing-effects':yes=x['tick']<=25047 and x['effect'].get('sourceId')==ID
  elif kind=='native-deaths':yes=x.get('id')==ID
  else:yes=x.get('corpse',{}).get('unitId')==ID
  if yes:chosen.append(x)
 out[kind]=chosen
(D/'ACTUAL1602-RAW-EXTRACT.json').write_text(json.dumps({'classification':'Only original completed ordinary046 raw records. Public commands are attempts; native state transitions/heal effects/hits are distinct witnesses. No planner/Game/query executed.','records':out},indent=2)+'\n')
plans=[]
for x in rows('plans'):
 if 24930<=x['tick']<=25035 and x['owner']=='p0':
  plans.append({'tick':x['tick'],'owner':x['owner'],'actorEntries':[e for e in x['entries']if actor(e['command'])],'allOriginalEntries':x['entries'],'postAll3Memories':x['postMemories']})
(D/'ACTUAL24930-25035-P0-PLANS-ALL3MEM.json').write_text(json.dumps(plans,indent=2)+'\n')
frames=[]
paths=[Path(str(P)+'.frames')/n for n in ['24000.json.gz','24600.json.gz','25200.json.gz']]+[Path(str(P)+'.events')/n for n in ['24673-after-step-126.json.gz','25004-after-step-127.json.gz','25047-after-step-128.json.gz']]
fatal=next(x for x in out['native-hits']if x['target']==ID and x['positiveToNonpositive'])
for path in paths:
 f=json.loads(gzip.decompress(path.read_bytes()));w=f['snapshot'];m=next((u for u in w['units']if u['id']==ID),None);center=m or fatal['targetAtObservation'];units=[]
 for u in w['units']:
  gap=math.hypot(u['x']-center['x'],u['y']-center['y'])
  if gap<=900:units.append({'distanceToMedicAtThisFrame':gap,'unit':u})
 units.sort(key=lambda x:x['distanceToMedicAtThisFrame'])
 frames.append({'path':str(path),'sha256':H(path),'tick':w['tick'],'phase':f.get('phase','after-step before next P0 for original600frame'),'commandIndex':f.get('commandIndex'),'medic':m,'actualAttacker':next((u for u in w['units']if u['id']==AT),None),'neighborsWithin900ForExistingThreatQueryContext':units,'nearBuildings':[b for b in w['buildings']if math.hypot(b['x']-center['x'],b['y']-center['y'])<=1200],'all3memories':f['memories'],'noCommandTimeEqualityClaim':True})
(D/'ACTUAL-FRAME-NEIGHBORS.json').write_text(json.dumps(frames,indent=2)+'\n')
back=S/'src/ai/bootstrap_1/caster-screen.ts';safe=S/'src/ai/bootstrap_1/medical-task-safety.ts';med=S/'src/ai/bootstrap_1/medical-recovery.ts';native=S/'src/shared/sim.ts';sdk=S/'src/sdk/game-runner.ts'
binding={'classification':'Readonly actual medical1602 preservation diagnosis. Source/raw/oldsealed evidence unchanged. Original046 is one natural48225P0win with46permanent/9veteranlosses. No newGame/import/P0/query/step/test/compiler.','sourceHead':'0466914857bd7b185a66ec42edb0202b5a884ca5','sourceRoot':str(S),'originalRun':str(R),'inputs':{str(p):{'sha256':H(p),'bytes':p.stat().st_size}for p in paths+[back,safe,med,native,sdk,R/'ordinary0-known-archer.mts',Path(str(P)+'-runtime-source.json'),Path(str(P)+'-postflight.json'),R/'process-exit-1.json']},'originalStreams':{k:{'path':str(P)+'-'+k+'.jsonl.gz','sha256':H(Path(str(P)+'-'+k+'.jsonl.gz'))}for k in ['commands','plans','native-hits','health-transitions','healing-effects','native-deaths','corpse-events']},'specific25035BeforeP0OriginalFullSnapshotExists':False,'missing25035Reason':'Original ordinary0 saves full afterstep worlds only every600ticks and permanent terminal/owner-change events. No 25035 fullbeforeP0 file exists; perownerplan at25035 containsentries/all3postmem but not beforeP0world.','actual25047FatalFullBody':fatal,'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(D/'SOURCE-RAW-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps({'counts':{k:len(v)for k,v in out.items()},'lastCompletedHeal':out['healing-effects'][-1],'incomingHits':[{'tick':x['tick'],'attacker':x['attacker'],'damage':x['damage'],'before':x['hpBefore'],'after':x['hpAfter'],'order':x['targetAtObservation'].get('order'),'pushX':x['targetAtObservation'].get('pushX'),'pushY':x['targetAtObservation'].get('pushY')}for x in out['native-hits']if x['target']==ID],'frameBrief':[{'tick':f['tick'],'actor':{k:f['medic'].get(k)for k in ['hp','x','y','order','abilityCooldowns','pushX','pushY']}if f['medic']else None,'attacker':f['actualAttacker'],'nearestFriendlies':[{'gap':u['distanceToMedicAtThisFrame'],'id':u['unit']['id'],'kind':u['unit']['kind'],'hp':u['unit']['hp'],'order':u['unit']['order']}for u in f['neighborsWithin900ForExistingThreatQueryContext']if u['unit']['owner']=='p0'][:6]}for f in frames]},ensure_ascii=False))
