from pathlib import Path
import json,gzip,hashlib,shutil,datetime,subprocess

D=Path('/workspace/.playtest/root046-medic1602-preservation-diagnosis-20261016');C=D/'reconstruction600-prepared';C.mkdir()
R=Path('/workspace/.playtest/bootstrap-root-046-known-archer0-20261016');P=R/'known-archer0-04669148';S=Path('/workspace/sketch-rts-root-medical-04669148-fixed-control');O=C/'original';O.mkdir()
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
start=24600;end=25200;capfile=Path(str(P)+'-runtime-source.json');cap=json.loads(capfile.read_text())
assert cap['head']=='0466914857bd7b185a66ec42edb0202b5a884ca5' and len(cap['files'])==1507 and len(cap['frozenFiles'])==497
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['head']
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True)==''
assert all(H(S/f['path'])==f['sha256']for f in cap['files'])
for tick,name in [(start,'24600.json.gz'),(end,'final25200.json.gz')]:
 src=Path(str(P)+'.frames')/(str(tick)+'.json.gz');shutil.copyfile(src,O/name)
 f=json.loads(gzip.decompress(src.read_bytes()));assert f['snapshot']['tick']==tick and f['snapshot']['match']['winner']is None and set(f['memories'])=={'p0','p1','p2'}
saved=json.loads(gzip.decompress((O/'24600.json.gz').read_bytes()));alive={e['id']for e in saved['snapshot']['units']+saved['snapshot']['buildings']}
for n in ['native-ledger.ts','native-telemetry.ts']:shutil.copyfile(R/n,C/n)
(C/'package.json').write_text('{"private":true,"type":"module"}\n')
counts={};last={};commandBase=planBase=hitBase=0;phase_edges={}
for kind in ['commands','plans','native-hits','native-events','native-deaths','ship-losses','corpse-events','health-transitions','healing-effects']:
 src=Path(str(P)+'-'+kind+'.jsonl.gz');n=0;edges=[]
 with gzip.open(src,'rt')as f,(O/(kind+'.jsonl')).open('w')as out:
  for line in f:
   if not line.strip():continue
   x=json.loads(line);t=x['tick'];cmd=kind in ['commands','plans'];isNativeBoundary=not cmd and x.get('commandIndex')is None and x.get('stage')!='after-command'
   before=t<start or t==start and isNativeBoundary
   if before:
    if kind=='commands':commandBase+=1
    elif kind=='plans':planBase+=1
    elif kind=='native-hits':hitBase=x['index']+1;last[x['target']]=x
    continue
   selected=(start<=t<end) or(t==end and isNativeBoundary and x.get('stage')!='before-step')
   if selected:
    out.write(line);n+=1
    if t in [start,end]:edges.append({'tick':t,'stage':x.get('stage'),'commandIndex':x.get('commandIndex'),'type':x.get('type')})
 counts[kind]={'rows':n,'path':str(O/(kind+'.jsonl')),'sha256':H(O/(kind+'.jsonl')),'source':str(src),'sourceSHA256':H(src)};phase_edges[kind]=edges
seed={'classification':'Original pre24600 public command/ownerplan prefixes, native hit prefix through24600afterstep. Prefix indices preserved. Last-hit refs only for live entities at original24600. Local observer counters do not represent whole-match totals.','commandBase':commandBase,'planBase':planBase,'hitBase':hitBase,'lastHit':[[i,h]for i,h in last.items()if i in alive]};(C/'observer-prefix-seed.json').write_text(json.dumps(seed,indent=2)+'\n')
b={'classification':'PREPARED ONLY: one original046 normal3AI600 native reconstruction24600afterstep-beforeP0 to25200afterstep-beforeP0. No Game/Node/import/newplanner query/step yet. Extra captures are passive existing-run hooks, no added planner call or command. Original46permanent/9veteran loss ledger unchanged.','sourceCapPath':str(capfile),'sourceCapSHA256':H(capfile),'sourceHead':cap['head'],'sourceRoot':str(S),'inputSHA256':H(O/'24600.json.gz'),'originalFinalSHA256':H(O/'final25200.json.gz'),'sourceFiles':1507,'frozenFiles':497,'manifestFiles':184,'rulesVersion':2,'start':start,'end':end,'streams':counts,'phaseEdgeRecords':phase_edges,'diagnosticPurpose':'Capture true beforeP0 every15 including24990,25005,25020,25035; exact command before/after actor states, actual first incominghit25006 and native pursuit/screen from25004 throughhold25035/fatal25047. No isolated correction or new policy evaluated.','boundFiles':{str(p):H(p)for p in [capfile,Path(cap['sourceArchive']),Path(cap['frozenArchive']),Path(str(P)+'-postflight.json'),R/'process-exit-1.json',C/'native-ledger.ts',C/'native-telemetry.ts',C/'package.json',C/'observer-prefix-seed.json',O/'24600.json.gz',O/'final25200.json.gz']}|{x['path']:x['sha256']for x in counts.values()}}
(C/'SOURCE-INPUT-BINDING.json').write_text(json.dumps(b,indent=2)+'\n')
print(json.dumps({'status':'PREPARED-INPUTS','commandBase':commandBase,'planBase':planBase,'hitBase':hitBase,'counts':{k:v['rows']for k,v in counts.items()},'noGameOrNode':True}))
