from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import sys

variant = sys.argv[1]
directory = Path(__file__).parent
run = directory / f'normal-{variant}-279885-286800'
read = lambda path: json.loads(path.read_text())
saved = lambda path: json.loads(gzip.decompress(path.read_bytes()))
rows = lambda name: [json.loads(line) for line in (run / (name + '.jsonl')).open()]
report = read(run / 'REPORT.json')
initial, final = saved(run / 'initial.json.gz'), saved(run / 'final.json.gz')
events, hits, plans = rows('events'), rows('hits'), rows('p0-plans')
terminals = [event for event in events if event['type'] == 'native-unit-terminal']
actor = lambda event: event.get('atObservation') or event.get('previous')
ferry_ids = ['unit-p0-carrier-25442', 'unit-p0-transport-157929']
deck_changes = [event for event in events if event['type'] in ['observed-parent-change', 'observed-disembark']]
embarked = [event for event in deck_changes if event['after'].get('deck', {}).get('shipId') in ferry_ids]
ground_embarked = [event for event in embarked if event['after']['owner'] == 'p0' and not event.get('before', {}).get('deck')]
disembarked = [event for event in deck_changes if event.get('before', {}).get('deck', {}).get('shipId') in ferry_ids
               and event['after'].get('deck', {}).get('shipId') not in ferry_ids]
creation = []
prior_ferries = initial['memories']['p0']['naval'].get('ferries', {})
for plan in plans:
    current = plan['memories']['p0']['naval'].get('ferries', {})
    for unit_id, mission in current.items():
        if unit_id not in prior_ferries:
            creation.append({'tick': plan['tick'], 'unitId': unit_id, 'mission': mission})
    prior_ferries = current

stats = {}
for key in ['unitsLost', 'unitsKilled', 'nonBaseBuildingsDestroyed', 'goldSpent', 'neutralUnitsKilled']:
    before = initial['snapshot']['match']['stats'].get(key, {})
    after = final['snapshot']['match']['stats'].get(key, {})
    stats[key] = {owner: after.get(owner, 0) - before.get(owner, 0) for owner in ['p0', 'p1', 'p2']}
economy = {}
for owner in ['p0', 'p1', 'p2']:
    before = initial['snapshot']['players'][owner]['gold']
    after = final['snapshot']['players'][owner]['gold']
    spent = stats['goldSpent'][owner]
    economy[owner] = {'goldBefore': before, 'goldAfter': after, 'goldDelta': after - before,
                      'goldSpentDelta': spent, 'walletPlusSpent': after - before + spent}
initial_resources = {resource['id']: resource for resource in initial['snapshot']['resources']}
resource_changes = [{'id': resource['id'], 'before': initial_resources[resource['id']]['amount'], 'after': resource['amount']}
                    for resource in final['snapshot']['resources']
                    if resource['id'] in initial_resources and resource['amount'] != initial_resources[resource['id']]['amount']]
before_p0 = saved(run / '279885-before-p0.json.gz')
result = {
    'variant': variant, 'sourcePre': report['sourcePre'], 'sourcePost': report['sourcePost'],
    'frozenPre': report['frozenPre'], 'frozenPost': report['frozenPost'],
    'startTick': report['startTick'], 'endTick': report['endTick'], 'steps': report['steps'],
    'naturalComplete': report['naturalComplete'], 'focusedWindowComplete': report['focusedWindowComplete'],
    'winner': report['winner'], 'firstP0Proof': report['firstP0Proof'],
    'initialSha256': hashlib.sha256((run / 'initial.json.gz').read_bytes()).hexdigest(),
    'initialWorldId3memExactBeforeFirstNormalP0': initial == before_p0,
    'eventCounts': dict(Counter(event['type'] for event in events)),
    'permanentTerminalByOwnerKind': dict(Counter(actor(event)['owner'] + ':' + actor(event)['kind']
                                               for event in terminals if event['permanent'])),
    'expiringTerminalsAtOrAfterExpiryTick': sum(not event['permanent'] and actor(event).get('expiresTick', float('inf')) <= event['tick'] for event in terminals),
    'expiringTerminalsBeforeExpiryTick': sum(not event['permanent'] and actor(event).get('expiresTick', float('inf')) > event['tick'] for event in terminals),
    'birthsByOwnerKind': dict(Counter(event['unit']['owner'] + ':' + event['unit']['kind']
                                    for event in events if event['type'] == 'unit-birth-observed')),
    'ownerChanges': [event for event in events if event['type'] == 'owner-change'],
    'ferryMissionCreations': creation,
    'actualEmbarkEvents': embarked, 'actualDisembarkEvents': disembarked,
    'actualOwnGroundEmbarkEvents': ground_embarked,
    'actualOwnGroundEmbarkedUniqueIds': sorted({event['after']['id'] for event in ground_embarked}),
    'bornOnSelectedFerries': [event for event in events if event['type'] == 'unit-birth-observed'
                              and event['unit'].get('deck', {}).get('shipId') in ferry_ids],
    'selectedFerryTerminals': [event for event in terminals if event['id'] in ferry_ids],
    'permanentTerminals': [event for event in terminals if event['permanent']],
    'buildingTerminals': [event for event in events if event['type'] == 'native-building-terminal'],
    'hits': len(hits), 'p0HitsIntoEnemyBuildings': [hit for hit in hits if hit['attackerOwner'] == 'p0'
        and hit['targetOwner'] in ['p1', 'p2'] and hit['target'].startswith('building-')],
    'hitsByAttackerOwnerAndTarget': dict(Counter(hit['attackerOwner'] + ':' + hit['target'] for hit in hits)),
    'officialStatDeltas': stats, 'economyDelta': economy, 'resourceAmountChanges': resource_changes,
    'finalFerries': final['memories']['p0']['naval'].get('ferries', {}),
    'finalSelectedHulls': [unit for unit in final['snapshot']['units'] if unit['id'] in ferry_ids],
    'limitations': ['6915tick focused causal window, not a whole match or generalized acceptance.',
                   'Observed births/deck changes/terminals are sampled at command and native-step boundaries; within-boundary intermediate changes can be missed.',
                   'Permanent terminal grouping uses owner at terminal observation, not original ID spelling; native official unitsLost and capture events remain separate.',
                   'Wallet plus official spent is not alone mined income; repairs/refunds/items need correlation.',
                   'Unrecovered original-container uncommitted work remains a separate recovery gap.'],
}
output = directory / f'{variant.upper()}-6915-ANALYSIS.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'variant': variant, 'output': str(output), 'steps': result['steps'], 'winner': result['winner'],
                  'permanentTerminalByOwnerKind': result['permanentTerminalByOwnerKind'],
                  'embarkEvents': len(embarked), 'disembarkEvents': len(disembarked),
                  'p0EnemyBuildingHits': len(result['p0HitsIntoEnemyBuildings']), 'resourceAmountChanges': resource_changes}))
