import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual as equal } from 'node:util';
import { join } from 'node:path';

const [manifest, input, queryResult, output] = process.argv.slice(2);
const source = JSON.parse(readFileSync(manifest!, 'utf8')), out = output!;
mkdirSync(out, { recursive: true });
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
const copy = (value: any) => JSON.parse(JSON.stringify(value));
const audit = () => {
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: source.root, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: source.root, encoding: 'utf8' });
  if (head !== source.head || status) throw Error('source head/status');
  for (const [path, hash] of Object.entries(source.hashes)) {
    if (sha(readFileSync(join(source.root, path))) !== hash) throw Error('source ' + path);
  }
  return { head, status, files: Object.keys(source.hashes).length };
};
const sourcePre = audit(), raw = readFileSync(input!);
const saved = JSON.parse(gunzipSync(raw).toString()), savedHash = sha(JSON.stringify(saved));
const load = (path: string) => import(join(source.root, path));
const [{ createGame, restoreSnapshotIntoGame, snapshotGame }, { createAiMemoryProvider },
  { createBootstrapCommandPlanner, frozenPolicyRoot, frozenPolicyManifest }, { runGameLoop }, { RULES_VERSION }] = await Promise.all([
  load('src/shared/sim.ts'), load('src/ai/planner-context.ts'), load('scripts/bootstrap_1-planner.ts'),
  load('src/sdk/game-runner.ts'), load('src/shared/rules-version.ts'),
]);
if (RULES_VERSION !== 2 || frozenPolicyManifest.rulesVersion !== 2) throw Error('rules');
const game = createGame('bareDuel');
restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
const memoryProvider = createAiMemoryProvider(copy(saved.memories));
const full = () => copy({ snapshot: snapshotGame(game), nextId: game.nextId,
  memories: Object.fromEntries(Object.keys(saved.memories).map(owner => [owner, memoryProvider.get(owner)])) });
const initial = full(), restore = { persistedWorldExact: equal(initial.snapshot, saved.snapshot),
  nextIdExact: initial.nextId === saved.nextId, all3memoryExact: equal(initial.memories, saved.memories) };
writeFileSync(join(out, 'restore.json'), JSON.stringify(restore, null, 2));
if (Object.values(restore).some(value => !value)) {
  writeFileSync(join(out, 'actual-restored.json.gz'), gzipSync(JSON.stringify(initial)));
  throw Error('persisted input restore differs');
}
const agents = JSON.parse(readFileSync('/tmp/coastal-corner-priority-58e-20261016/agents.json', 'utf8'));
const normal = await createBootstrapCommandPlanner(memoryProvider), frozenRoot = frozenPolicyRoot();
const frozenCheck = () => {
  const changed = Object.entries(frozenPolicyManifest.files).filter(([path, hash]) => sha(readFileSync(join(frozenRoot, path))) !== hash).map(([path]) => path);
  const paths = execFileSync('git', ['ls-tree', '-r', '--name-only', frozenPolicyManifest.revision, '--', 'package.json', 'src/ai', 'src/sdk', 'src/shared'], { cwd: source.root, encoding: 'utf8' }).trim().split('\n');
  const fullChanged = paths.filter(path => !readFileSync(join(frozenRoot, path)).equals(execFileSync('git', ['show', `${frozenPolicyManifest.revision}:${path}`], { cwd: source.root, maxBuffer: 8 * 1024 * 1024 })));
  if (changed.length || fullChanged.length || paths.length !== 497 || Object.keys(frozenPolicyManifest.files).length !== 184) throw Error('frozen source differs');
  return { revision: frozenPolicyManifest.revision, rulesVersion: 2, manifestFiles: 184, allSourceFiles: paths.length, changed, fullChanged };
};
const frozenPre = frozenCheck();
if (!equal(full(), initial)) throw Error('planner setup mutated input');
const expectedEntries = JSON.parse(readFileSync(join(queryResult!, 'all-entries.json'), 'utf8'));
const expectedMemories = JSON.parse(gunzipSync(readFileSync(join(queryResult!, 'post-p0-all3mem.json.gz'))).toString());
const names = ['commands', 'p0-plans', 'hits', 'samples', 'events'];
for (const name of names) writeFileSync(join(out, name + '.jsonl'), '', { flag: 'wx' });
const emit = (name: string, row: any) => appendFileSync(join(out, name + '.jsonl'), JSON.stringify(row) + '\n');
const ferryIds = ['unit-p0-carrier-25442', 'unit-p0-transport-157929'];
const samples = () => copy({ tick: game.tick, ferries: memoryProvider.get('p0').naval?.ferries ?? {},
  players: game.players, winner: game.match.winner,
  hulls: game.units.filter((unit: any) => ferryIds.includes(unit.id)).map((unit: any) => ({ ...unit,
    actualDeckIds: game.units.filter((passenger: any) => passenger.deck?.shipId === unit.id).map((passenger: any) => passenger.id) })) });
const unitRecord = (unit: any) => copy({ id: unit.id, owner: unit.owner, kind: unit.kind, hp: unit.hp,
  expiresTick: unit.expiresTick, x: unit.x, y: unit.y, deck: unit.deck });
let firstP0Proof: any, normalPlannerCalls = 0, commands = 0, hits = 0;
let prior = new Map(game.units.map((unit: any) => [unit.id, unitRecord(unit)]));
const lastHits = new Map(), preStepHulls = new Map();
let stopRequest: any, observationStop: any, crossedOriginalDeathTick: any;
game.observer = { hit(attacker: any, target: any, damage: number, hpBefore: number) {
  hits++; const hit = copy({ tick: game.tick, attacker: attacker.id, attackerOwner: attacker.owner, target: target.id,
    targetOwner: target.owner, damage, hpBefore, hpAfter: target.hp });
  emit('hits', hit); lastHits.set(target.id, hit);
} };
const planner = (context: any) => {
  const before = full();
  if (context.owner === 'p0') writeFileSync(join(out, `${game.tick}-before-p0.json.gz`), gzipSync(JSON.stringify(before)));
  const entries = normal(context); normalPlannerCalls++;
  if (!equal(copy(snapshotGame(game)), before.snapshot)) throw Error('normal planner changed world');
  if (context.owner === 'p0') {
    const memories = full().memories;
    emit('p0-plans', { tick: game.tick, entries, memories });
    if (!firstP0Proof) {
      firstP0Proof = { tick: game.tick, entriesExact: equal(entries, expectedEntries), all3postMemoryExact: equal(memories, expectedMemories), normalPlannerCalls };
      writeFileSync(join(out, 'first-p0-proof.json'), JSON.stringify(firstP0Proof, null, 2));
      if (!firstP0Proof.entriesExact || !firstP0Proof.all3postMemoryExact || normalPlannerCalls !== 1) throw Error('first normal P0 differs from pure query');
    }
  }
  return entries;
};
const startTick = game.tick, initialSample = samples();
writeFileSync(join(out, 'prelaunch.json'), JSON.stringify({ scope: 'Normal three-AI changed-code continuation from actual D352 input, ordinary frozen v5+v7, all original world/resources/population/teams/memory. Continues to native result or explicit diagnosed observer stop at a natural 600-tick boundary. Passing the historical D352 loss tick is only an observation.', sourcePre, input, inputSHA256: sha(raw), agents, restore, frozenPre, startTick, driverSHA256: sha(readFileSync(import.meta.filename)) }, null, 2));
writeFileSync(join(out, 'initial.json.gz'), gzipSync(JSON.stringify(initial)));
emit('samples', initialSample);
const start = performance.now();
const runInput = { name: 'ground-evacuation-task-admission', game, agents, commandPlanner: planner,
  maxTicks: Number.MAX_SAFE_INTEGER, thinkInterval: 15 };
runGameLoop(runInput, {
  onCommand(event: any) { commands++; emit('commands', copy({ tick: event.tick, owner: event.owner, scriptId: event.scriptId, source: event.source, command: event.command })); },
  beforeStep() {
    if (!stopRequest && existsSync(join(out, 'observer-stop.json'))) stopRequest = {
      observedAtTick: game.tick, request: JSON.parse(readFileSync(join(out, 'observer-stop.json'), 'utf8')),
    };
    preStepHulls.clear();
    for (const unit of game.units) if (ferryIds.includes(unit.id)) preStepHulls.set(unit.id, copy({ ship: unit,
      passengers: game.units.filter((passenger: any) => passenger.deck?.shipId === unit.id) }));
  },
  onStep() {
    const current = new Map(game.units.map((unit: any) => [unit.id, unit]));
    for (const [id, unit] of prior) {
      if (!current.has(id)) emit('events', { tick: game.tick, type: 'native-unit-removed', previous: unit,
        expired: unit.expiresTick !== undefined && unit.expiresTick <= game.tick, lastNativeHit: lastHits.get(id), preStepHull: preStepHulls.get(id),
        limitation: 'Observed removal is recorded separately from native score/expiry/capture attribution.' });
      else if (current.get(id).owner !== unit.owner) emit('events', { tick: game.tick, type: 'owner-change', before: unit, after: unitRecord(current.get(id)) });
    }
    prior = new Map(game.units.map((unit: any) => [unit.id, unitRecord(unit)]));
    if (game.tick === 286628) {
      crossedOriginalDeathTick = { tick: game.tick, sample: samples(), scope: 'Historical D352 death tick observation; current source may diverge and survival here is not victory.' };
      writeFileSync(join(out, 'historical-death-tick-observation.json'), JSON.stringify(crossedOriginalDeathTick, null, 2));
      writeFileSync(join(out, 'historical-death-tick-full.json.gz'), gzipSync(JSON.stringify(full())));
    }
    if ((game.tick - startTick) % 15 === 0) emit('samples', samples());
    if (game.tick % 600 === 0) {
      writeFileSync(join(out, 'progress.json'), JSON.stringify({ tick: game.tick, commands, hits, winner: game.match.winner, latest: samples() }));
      console.log(JSON.stringify({ tick: game.tick, commands, hits, ferries: memoryProvider.get('p0').naval?.ferries ?? {}, winner: game.match.winner }));
      if (stopRequest && !game.match.winner) {
        observationStop = { tick: game.tick, stage: 'after-step-before-next-p0', ...stopRequest };
        runInput.maxTicks = game.tick;
      }
    }
  },
});
const final = full();
writeFileSync(join(out, 'final.json.gz'), gzipSync(JSON.stringify(final)));
const report = { sourcePre, sourcePost: audit(), frozenPre, frozenPost: frozenCheck(),
  inputUnchanged: savedHash === sha(JSON.stringify(saved)) && sha(raw) === sha(readFileSync(input!)),
  startTick, endTick: game.tick, steps: game.tick - startTick, wallMs: performance.now() - start,
  firstP0Proof, normalPlannerCalls, commands, hits, initial: initialSample, finalSample: samples(), finalFerries: memoryProvider.get('p0').naval?.ferries ?? {}, winner: game.match.winner,
  naturalComplete: !!game.match.winner, observationStop, crossedOriginalDeathTick,
  limitations: ['Changed-code saved-game continuation, not a fresh ordinary opening or generalization score.', 'Observed unit removal does not by itself prove killed/captured/expired; native hit/owner-change and expiresTick are retained separately.', 'All existing broken-container uncommitted recovery gaps remain.'] };
writeFileSync(join(out, 'REPORT.json'), JSON.stringify(report, null, 2));
if (!report.inputUnchanged) throw Error('input changed');
console.log(JSON.stringify(report));
