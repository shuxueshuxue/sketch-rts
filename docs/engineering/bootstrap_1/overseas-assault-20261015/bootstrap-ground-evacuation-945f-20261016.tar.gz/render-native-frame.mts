import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { createCanvas } from '/workspace/sketch-rts/node_modules/@napi-rs/canvas/index.js';

const [sourceManifest, framePath, outputPath, region] = process.argv.slice(2);
const source = JSON.parse(readFileSync(sourceManifest!, 'utf8'));
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
const audit = () => {
  const changed = Object.entries(source.hashes).filter(([path, hash]) => sha(readFileSync(join(source.root, path))) !== hash).map(([path]) => path);
  if (changed.length) throw Error('fixed source changed');
  return { files: Object.keys(source.hashes).length, changed };
};
const sourcePre = audit(), raw = readFileSync(framePath!), saved = JSON.parse(gunzipSync(raw).toString());
const before = sha(JSON.stringify(saved));
const [{ installHeadlessCanvas }, { drawWorld }, { UnitFacingTracker }] = await Promise.all([
  import(join(source.root, 'src/recorder/record.ts')),
  import(join(source.root, 'src/client/world-renderer.ts')),
  import(join(source.root, 'src/client/unit-facing.ts')),
]);
installHeadlessCanvas();
const view = region === 'island' ? { x: 5400, y: 7400, width: 1200, height: 1200, zoom: 1 }
  : { x: 1350, y: 4400, width: 1300, height: 1300, zoom: 1 };
const canvas = createCanvas(view.width, view.height);
drawWorld({ ctx: canvas.getContext('2d') as any, snapshot: saved.snapshot, view, now: saved.snapshot.tick * 50,
  facing: new UnitFacingTracker(), labels: { mercenaryStock: String, unitKind: String }, viewer: 'p0',
  selectedIds: new Set(['unit-p0-carrier-25442', 'unit-p0-transport-157929', 'unit-p0-warship-33582']) });
const png = canvas.toBuffer('image/png');
if (before !== sha(JSON.stringify(saved))) throw Error('renderer mutated input');
writeFileSync(outputPath!, png);
writeFileSync(outputPath! + '.json', JSON.stringify({ scope: 'Read-only native drawWorld render of an actual complete persisted Game frame; no new Game, planner, step, manual command or generated illustration.',
  tick: saved.snapshot.tick, sourceHead: source.head, sourcePre, sourcePost: audit(), input: framePath, inputSHA256: sha(raw),
  image: outputPath, imageSHA256: sha(png), view, inputUnchanged: true }, null, 2));
console.log(JSON.stringify({ tick: saved.snapshot.tick, outputPath }));
