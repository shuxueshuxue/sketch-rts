from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

label, cwd, threshold, heap, *command = sys.argv[1:]
directory = Path(__file__).parent
cgroup = Path('/sys/fs/cgroup')
preflight = {
    'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'memoryMax': int((cgroup / 'memory.max').read_text()),
    'memoryCurrent': int((cgroup / 'memory.current').read_text()),
    'memoryStat': (cgroup / 'memory.stat').read_text(),
    'memoryEvents': (cgroup / 'memory.events').read_text(),
    'memoryPressure': (cgroup / 'memory.pressure').read_text() if (cgroup / 'memory.pressure').exists() else None,
    'command': command,
    'cwd': cwd,
    'nodeOptions': f'--max-old-space-size={heap}',
    'threshold': int(threshold),
}
preflight['rawHeadroom'] = preflight['memoryMax'] - preflight['memoryCurrent']
with (directory / f'{label}-preflight.json').open('x') as target:
    json.dump(preflight, target, indent=2)
    target.write('\n')
print(json.dumps({key: value for key, value in preflight.items() if key != 'memoryStat'}), flush=True)
if preflight['rawHeadroom'] < preflight['threshold']:
    raise SystemExit(75)
environment = dict(os.environ)
environment['NODE_OPTIONS'] = preflight['nodeOptions']
with (directory / f'{label}.log').open('x') as log:
    result = subprocess.run(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT)
receipt = {
    'startedAtUTC': preflight['atUTC'],
    'finishedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': result.returncode,
    'memoryEventsAfter': (cgroup / 'memory.events').read_text(),
    'log': str(directory / f'{label}.log'),
}
with (directory / f'{label}-exit.json').open('x') as target:
    json.dump(receipt, target, indent=2)
    target.write('\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
