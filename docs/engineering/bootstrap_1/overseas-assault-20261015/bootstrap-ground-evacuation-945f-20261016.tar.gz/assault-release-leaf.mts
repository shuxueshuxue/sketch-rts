import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

const directory = '/tmp/bootstrap-ground-evacuation-945f-20261016';
const cap = JSON.parse(readFileSync(join(directory, 'fixed-source.json'), 'utf8'));
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');
const audit = () => {
  const changed = Object.entries(cap.hashes).filter(([path, hash]) => sha(readFileSync(join(cap.root, path))) !== hash).map(([path]) => path);
  if (changed.length) throw Error('source changed');
  return { head: cap.head, files: Object.keys(cap.hashes).length, changed };
};
const sourcePre = audit();
const input = join(directory, 'normal-candidate-279885-286800/281145-before-p0.json.gz');
const raw = readFileSync(input), saved = JSON.parse(gunzipSync(raw).toString());
const before = sha(JSON.stringify(saved)), snapshot = structuredClone(saved.snapshot), memories = structuredClone(saved.memories);
const [{ assaultExpedition }, { effectiveCombatRating }, { sameGround }, { unitMover }] = await Promise.all([
  import(join(cap.root, 'src/ai/policy/naval.ts')), import(join(cap.root, 'src/ai/policy/v6/strength.ts')),
  import(join(cap.root, 'src/shared/terrain.ts')), import(join(cap.root, 'src/shared/catalog.ts')),
]);
const shipId = 'unit-p0-carrier-25442', mission = memories.p0.naval.ferries[shipId];
const target = snapshot.buildings.find((building: any) => building.id === mission.targetId);
const options = { version: 'v2', requestedVersion: 'v7', memory: memories.p0, teams: snapshot.teams };
const result = assaultExpedition(snapshot, 'p0', options, target);
const cargo = snapshot.units.filter((unit: any) => unit.deck?.shipId === shipId && unit.kind !== 'worker' && !unit.expiresTick);
const landed = snapshot.units.filter((unit: any) => unit.owner === 'p0' && !unit.deck && unit.kind !== 'worker'
  && unitMover(unit.kind) === 'land' && !unit.expiresTick && sameGround(snapshot.map, unit, target));
const summarize = (units: any[]) => units.map(unit => ({ id: unit.id, kind: unit.kind, hp: unit.hp,
  maxHp: unit.maxHp, deck: unit.deck, rating: effectiveCombatRating(snapshot, unit) }));
const report = {
  scope: 'One existing exported assaultExpedition leaf on an actual native complete281145 preP0 frame. No Game, step, complete P0, road query, modified source or memory backfill. Options contain the exact bootstrap-v9_summoner fields this leaf reads: v2/requestedv7, originalnavalferries and actualteams.',
  input, inputSHA256: sha(raw), sourcePre, sourcePost: audit(), tick: snapshot.tick,
  mission, allFerryIds: Object.keys(memories.p0.naval.ferries), target,
  nativePendingBoarders: snapshot.units.filter((unit: any) => unit.owner === 'p0' && !unit.deck
    && unit.order.type === 'board' && unit.order.transportId === shipId).map((unit: any) => unit.id),
  required: result.required, readyWithAllExpeditionCandidates: result.ready,
  allExpeditionCandidates: summarize(result.crew), actualCargo: summarize(cargo), landed: summarize(landed),
  actualCargoAndLandedRating: [...cargo, ...landed].reduce((sum: number, unit: any) => sum + effectiveCombatRating(snapshot, unit), 0),
  inputUnchanged: before === sha(JSON.stringify(saved)),
  snapshotUnchanged: JSON.stringify(snapshot) === JSON.stringify(saved.snapshot),
  all3memoryUnchanged: JSON.stringify(memories) === JSON.stringify(saved.memories),
  limitation: 'These are existing planner strength indices, not proof that a fully microed real battle is physically unwinnable or permission to lower thresholds. Other coast/strength gates may also reject. At first return281160, the earlier physical-progress guard fires before these later gates.',
};
writeFileSync(join(directory, 'CANDIDATE-281145-ASSAULT-RELEASE-LEAF.json'), JSON.stringify(report, null, 2));
if (!report.inputUnchanged || !report.snapshotUnchanged || !report.all3memoryUnchanged) throw Error('leaf changed input');
console.log(JSON.stringify(report));
