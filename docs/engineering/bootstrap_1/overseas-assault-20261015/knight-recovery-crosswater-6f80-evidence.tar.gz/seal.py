from pathlib import Path
import hashlib,json,tarfile,datetime
out=Path('/workspace/.playtest/knight-recovery-crosswater-6f80')
archive=out.parent/'knight-recovery-crosswater-6f80-evidence.tar.gz'
sealpath=out.parent/'knight-recovery-crosswater-6f80-seal.json'
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
files={p.relative_to(out).as_posix():{'sha256':sha_file(p),'bytes':p.stat().st_size}for p in sorted(out.rglob('*'))if p.is_file()and not p.is_symlink()and 'node_modules'not in p.parts and p.name!='INDEX.json'}
index={'classification':'Independent rules2 crosswater recovery-waypoint boundary candidate. New source has focused real64800-to68400 equality, controlled native regression evidence only; original129158 win remains old fixed source. Original uncommitted-container recovery gap retained.','created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':'/tmp/sketch-rts-knight-recovery-crosswater-6f80-control','parentFixedSource':'/tmp/sketch-rts-knight-recovery-waypoint-6f80-control','payloadCount':len(files),'files':files,'excludedSymlinks':['node_modules'],'indexSelfHash':'External archive SHA covers INDEX; INDEX does not hash itself.'}
(out/'INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
with tarfile.open(archive,'w:gz',compresslevel=6)as t:
 for name in list(files)+['INDEX.json']:t.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as t:
 assert set(t.getnames())==set(files)|{'INDEX.json'}
 assert json.load(t.extractfile('INDEX.json'))==index
 for name,expected in files.items():
  body=t.extractfile(name).read();assert len(body)==expected['bytes']and hashlib.sha256(body).hexdigest()==expected['sha256'],name
  assert sha_file(out/name)==expected['sha256'],name
post=json.loads((out/'final-source-postflight.json').read_bytes());assert not post['candidateChanges']and not post['oldFixedChanges']and all(post['sameWindowWholeStateCommandsHits'].values())and post['native8FixturesFinalWorldIdHitsAllEqual']and post['nativeDeckCabinInitialAndFinalWorldIdHitsEqual']and post['nearMinimumRealUnitProbePositiveReproductionEqual']
seal={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha_file(archive),'verifiedPayloads':len(files),'verifiedTarEntries':len(files)+1,'indexSHA256':sha_file(out/'INDEX.json'),'sealedTime':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'New minimal boundary candidate only. No new ordinary0/fullgame result. 3601 actual ticks complete state/mem equality,104 issued commands,101 allworld hits; old129158 victory not attributed to new source. Controlled native geometry and JSON proof, original uncommitted gap and new sparse/disk incident retained.','sourceCapsuleSHA256':post['newCapsuleSHA256'],'original129158ArchiveUnchangedSHA256':post['originalArchiveSHA256']}
sealpath.write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
