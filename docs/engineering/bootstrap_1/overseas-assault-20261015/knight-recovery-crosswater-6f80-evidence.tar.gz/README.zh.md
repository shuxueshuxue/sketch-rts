# 恢复旧航点的邻海 / 隔水武器边界

这是独立候选，不改变已封的129158获胜源码或证据包。继承关系仍是6f80 + 原空船撤离复评 + typed有限恢复航点；本次只在 `expedition-recovery.ts` 改旧航点的威胁验证。没有改 `land-recovery.ts`、memory类型、原 .35 门槛、原撤离1.4门槛、医疗新cover优先级、冻结对手、生产API、规则2、兵量或思考频率。没有混入3bdb、457、queued hold、工人补工等其他候选，没有新owner或TTL。

`boundary-only.patch` 是相对于129158固定组合的单文件增量，SHA256 `645a3571205df44a0606e25234ef56228a2cf19d32c505cdb5f60d56c7f3f3c5`。父源的其他两个生产差异仍只是继承部分，不能把整个旧文件覆盖到当前生产。

## 实际武器查询

probe是 `{...patient, ...goal}`，保留真实Unit形状与order，避免把普通兵当成building-like目标而减半径。原同陆地的mountedThreatReach及17tick速度余量保持原样。跨水的陆地/甲板武器用combatCapability的真实range调用native canReach，距离风险另算；没有把扩大后的range传进canReach并称为原生可射击。防御楼用实际中心射程。

船炮按真实working fittings、炮位pivot、mountedTargetPoint、veteran range、minRange、当前硬bearing和友军船体射线查询。也保留cutter的真实intrinsic武器。裸船attackDamage为0不再掩盖一门确有工作的炮。速度*(15+2)/20只是单独的保守径向风险余量，不是字面原生射程；当前硬射界与最小射程按实测。这里不预测随后转艏、重新导航到射击站位或动态遮挡变化，不能把一次“当前不覆盖”称为永久安全。

既有医疗/新cover仍在旧waypoint检查之前取胜。claims只读；只有原naval owner正常发布命令时维护原有typed表。该候选只拒绝对危险旧目标的强保留，并沿既有流程释放claim/清理记录；没有另造逃生点、stop/hold或保证拒绝后自动重规划。护理的生产整合由父会话统一审查。

## 可复核的native反例

以下是明确构造的回归fixture，使用未修改的规则2原生step与公开hold/attack指令；不是原普通局已观察到的跨水威胁，也不是AI比赛成绩。hold允许攻击，不被当成禁止自动攻击。对原生当前query和120tick命中事实分别记录，不能以范围圆替代真实命中。

| fixture | 当前查询与真实执行 |
| --- | --- |
| 隔64px深水带的弓手，中心距96 | range319.2，canReach=true，12tick实际命中，旧航点拒绝延续 |
| 同96px中心距的近战隔水 | range48，canReach=false，120tick未命中，旧航点可保留 |
| 相同近战、相同96px但连通陆地 | canReach=true，原think风险覆盖，17tick实际命中 |
| 邻海朝岸炮船，中心距300 | 真实炮位距255.12、range312、bearing真，26tick实际命中 |
| 反向炮船、同中心距300 | 真实炮位距344.88、bearing假，120tick未命中；不推导以后永远不能转艏 |
| 迫击炮盲区 | pivot距170.4 < min180，120tick未炮击；保留旧腿 |
| 迫击炮可射区 | pivot距360.4，58tick实际命中；拒绝旧腿 |
| 坏炮 | durability0，combatCapability armed=false；不以船购买价或裸船名计攻击 |
| 甲板弓手 | 同311.8px位置、range319.2，canReach=true，38tick实际命中，拒绝旧腿 |
| 同点船舱弓手 | 同311.8px，canReach=false，120tick未命中，旧腿可保留 |

前8个fixture的冷JSON续120tick均终world、nextId和全部native hits一致。新造船刚spawn的保存负载是0，公共restore会按真实炮具质量正常化（cannon160、mortar240）；这项初始world不等明确记录在 `native-fixture-json-result.json`，没有删除字段假等。该fixture构造期差别不涉及真实普通局存档。额外甲板/船舱两例在开始前已用公共restore规范化，因此初始world/id与终world/id/hits均完全一致。

另保留首个迫击炮设点的正例：真实Unit目标的pivot距180.4，刚好在180最小射程外，29tick实际命中，新helper判危险。若只传点与radius则被当成building-like目标减去18，误算为162.4。`minimum-edge-query.json`记录纯查询和该正例冷恢复后的终world/id/全部hits一致；初始炮具负载正常化仍明确保留，未声称初始world相等。

四张PNG由真实client drawWorld绘制这些精确native120tick世界，均已本人目视。它们是事后原生渲染，非历史live capture；未编辑图像、快照或推进额外游戏。范围结论来自完整native输入和命中记录，而非只看图。

## 原真实关键窗的隔离验证

固定旧源与新边界源都从同一已封64800完整world/nextId/双方全部memory正常运行到68400。旧已封正例只保存本岛命中，因此另在独立harness只读重放旧源同一个3600tick窗口以补全全图hit；没有改旧源、旧证据或另跑普通0。

- 3601个逐tick完整world+nextId+双方memory的SHA全部一致；不是删字段后等价。
- 103个唯一时点的完整世界/全部双方memory帧一致，且两者各自都与原正例115条样本/事件帧一致。
- 双方全部104条issued commands、全图101条native hit、其中95条本岛hit全部一致。
- 终world/id/双方全部memory一致；大厅仍900，三名原防守兵HP130/37/71。
- 47个已捕获存储waypoint的原/新风险纯查询无改变、无新拒绝；这是捕获点的实测范围，不推导连续世界处处没有跨水威胁。
- 两源runtime/support及新增测试fixture的postflight变化为0。新1376源码capsule与冻结184条规则2数据都逐payload SHA复验。

40/40测试、tsc通过。40包含14个新边界/所有权用例及原26个有限航点/无药用例。初次测试的一个JSON null/undefined断言错误保留原失败log，修正测试后重跑；生产未因此改动。

这只证明边界修正没有改变原正例的该真实关键窗。129158自然获胜仍归属旧固定组合源；不能给新边界候选借用整场胜利，也不满足三路线、v5/v7/v8单对手、六配对、官方地图及未见种子的最终完整比赛与泛化验收。原容器未提交改动恢复缺口继续保留。

## 运维与观察器勘误

新worktree的首次创建错误也在包内，不能隐去：`--no-checkout`后它有per-worktree sparse=false，我错误把true写到common config，因此新tree仍按全量检出并填满/tmp，留下大量0字节与截断文件。首read-tree退出128，最初stderr未被launcher保留；满盘有父会话当时通知及实际材料清单为证。未开始复制组合源码或运行本候选模拟，没有对旧tree发稀疏命令；但common metadata写入、全局磁盘压力的影响限度保留，不能用结束源码hash相同证明其他并行任务毫无影响。

恢复前将1793个不完整payload逐Gitblob封存验证，随后只对这个新建、未运行、未有用户改动的tree用官方sparse-checkout与按pattern的read-tree恢复。结果1403文件/15MB、docs tar0、HEADclean；frozen-policy保留。原源/存档/旧包未删除。支持的git worktree move随后因Invalid cross-device link失败，原路径未动，不手工改admin metadata；源码因此保留在/tmp的15MB小树，全部本轮harness与证据在/workspace独立.playtest。Git的临时冻结对手提取由既有runner正常创建并在退出时清理。

另保留所有诊断错误：首native fixture recorder误把step后的nextId配给step前world（首次源/log/result封留后重跑捕真初值）；首迫击炮“盲区”设点实际pivot180.4、仍在180最小射程外，不能算负例，保留正例后改为170.4负例；冷恢复初始load差别如上；首关键窗driver把输入classification元数据也纳入可恢复字段比较，两源均在任何think/step前停，原driver/log/prelaunch封留，修正为严格比较world/id/双方memory三字段后才真实启动。首次prelaunch没有伪造成成功运行，修正版prelaunch也真实早于有效运行。
