import {readFileSync, writeFileSync, readdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const S='/workspace/sketch-rts-macro-choice-recovery-e566-control';
const D='/workspace/.playtest/macro-choice-recovery-e566-20261016';
const O='/workspace/.playtest/macro-choice-recovery-e566-fleet-readonly';
const input=D+'/native-193200/frames/223200-before-next-think.json.gz';
const sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const norm=(v:any)=>JSON.parse(JSON.stringify(v));
const hash=(v:any)=>sha(JSON.stringify(v));
const cap=JSON.parse(readFileSync(D+'/fixed-source.json','utf8'));
function sourceCheck(){
 const changes=Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);
 return {files:Object.keys(cap.hashes).length, changes, head:execFileSync('git',['-C',S,'rev-parse','HEAD'],{encoding:'utf8'}).trim(), status:execFileSync('git',['-C',S,'status','--porcelain'],{encoding:'utf8'}), productionPatchSHA256:sha(readFileSync(D+'/production.patch')),driverSHA256:sha(readFileSync(D+'/native-193200.ts')),observerSHA256:sha(readFileSync(D+'/observer-ledger.ts')),manifestSHA256:sha(readFileSync(D+'/fixed-source.json'))};
}
const sourceBefore=sourceCheck();if(sourceBefore.changes.length||sourceBefore.files!==1468||sourceBefore.head!==cap.head||sourceBefore.status)throw Error('Unexpected source');
const raw=readFileSync(input), f=JSON.parse(gunzipSync(raw).toString()), s=f.snapshot;
const before={frame:hash(f),world:hash(s),nextId:hash(f.nextId),all3mem:hash(f.memories)};
const load=(p:string)=>import(pathToFileURL(S+'/'+p).href);
const [planner,policy,geom,naval,terrain,capability,equipment,veteran,catalog,physical,transport,defense,alliance,ownership,mines,services,cabin,fleet,coast] = await Promise.all([
 load('src/ai/planner-context.ts'),load('src/ai/bootstrap_1/policy.ts'),load('src/shared/ship-geometry.ts'),load('src/shared/naval.ts'),load('src/shared/terrain.ts'),load('src/shared/combat-capabilities.ts'),load('src/shared/ship-equipment.ts'),load('src/shared/veteran-stats.ts'),load('src/shared/catalog.ts'),load('src/shared/physical-body.ts'),load('src/shared/transport-role.ts'),load('src/shared/ship-defense.ts'),load('src/shared/sim/command-validation.ts'),load('src/ai/policy/ownership.ts'),load('src/ai/policy/mounted-mine-plan.ts'),load('src/ai/policy/naval-services.ts'),load('src/shared/ship-cabin-quota.ts'),load('src/ai/policy/fleet-engagement.ts'),load('src/shared/shore-fire.ts')]);
terrain.setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const targetIds=['building-p2-cinderSpire-1597','satellite-guard-2-0','satellite-guard-2-1'];
const ships=s.units.filter((u:any)=>u.owner==='p0' && u.hp>0 && geom.shipProfile(u));
const own=s.units.filter((u:any)=>u.owner==='p0'&&u.hp>0);
const enemies=[...s.units,...s.buildings].filter((t:any)=>t.hp>0 && ownership.isEnemyOwner(s,'p0',t.owner,{teams:s.teams}));
const targets=[...s.units,...s.buildings].filter((t:any)=>targetIds.includes(t.id));
const ctx=policy.bootstrapPolicyContext(s,'p0','v9_summoner',{memory:structuredClone(f.memories.p0),teams:s.teams});
const minePlan=mines.mountedMinePlan(s,ctx.memory);
const service=services.navalServices(s,'p0',ctx);
const dist=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
function shots(ship:any,target:any){
 const blockers=s.units.filter((other:any)=>geom.shipProfile(other)&&other.id!==ship.id&&other.hp>0&&!alliance.areEnemyOwners(s,ship.owner,other.owner));
 return equipment.installedWeapons(s,ship).map((item:any)=>{
  const def=equipment.SHIP_WEAPONS[item.kind],pose=equipment.mountedWeaponPose(ship,item),point=equipment.mountedTargetPoint(s,ship,item,target,pose),gap=dist(pose.pivot,point),range=veteran.veteranWeaponRange(ship,def.range),minimum=def.weapon.minRange??0;
  const arc=equipment.shipGunCanAim(ship,item,point),lane=equipment.mountedFireLaneClear(ship,item,point,blockers),working=(item.durability??1)>0,ready=(item.cooldownRemaining??0)<=0&&!(item.mountId==='bow'&&ship.cooldown>0);
  return {id:item.id,kind:item.kind,mountId:item.mountId,durability:item.durability,cooldownRemaining:item.cooldownRemaining,aim:item.aim,facing:item.facing,pivot:pose.pivot,muzzle:pose.muzzle,predictedTargetPoint:point,pivotGap:gap,range,minRange:minimum,hardArc:arc,rangeOK:gap<=range,minRangeOK:gap>=minimum,friendlyFireLaneClear:lane,friendlyBlockerIds:blockers.map((u:any)=>u.id),working,cooldownReady:ready,geometryCanShootNow:working&&arc&&gap<=range&&gap>=minimum&&lane,warning:'Read-only geometry at the recorded hull pose. Aim convergence/stagger/stun are execution conditions; no native launch was run.'};
 });
}
function targetInfo(ship:any,t:any){
 const station=coast.shoreFiringStation(s,ship,t);
 return {id:t.id,owner:t.owner,kind:t.kind,hp:t.hp,maxHp:t.maxHp,x:t.x,y:t.y,centerDistance:dist(ship,t),withinLocal900:dist(ship,t)<Math.max(900,capability.combatCapability(s,ship).range+150),canReach:naval.canReach(s.map,ship,t,s.units,capability.combatCapability(s,ship).range),automaticShoreTargetReachable:coast.automaticShoreTargetReachable(s,ship,t),targetAvailable:minePlan.targetAvailable(t),currentMountedShots:shots(ship,t),shoreFiringStation:station,shoreStationDistance:station?dist(ship,station):undefined,stationMeaning:'Counterfactual hull pose returned by bounded terrain-only station query; existence is not proof of current shot or completed route.',counterfactualStationShots:station?shots({...ship,x:station.x,y:station.y,sailing:{...ship.sailing,heading:station.heading}},t):undefined};
}
const fullMemories=structuredClone(f.memories);
const began=performance.now();
const entries=planner.planAiOwnerCommandEntries(s,{playerId:'p0',source:'external-agent',version:'v9_summoner',memory:fullMemories.p0},{teams:s.teams});
const fullPlanner={elapsedMs:performance.now()-began,entries,all3MemoriesAfter:fullMemories,navalBefore:f.memories.p0.naval,navalAfter:fullMemories.p0.naval,warning:'Pure full p0 planner intent query on recorded full world/nextId/all3mem; no commands issued, game created, or native step executed.'};
const inventory=ships.map((ship:any)=>{
 const passengers=geom.shipPassengers(s.units,ship),boarders=s.units.filter((u:any)=>u.order.type==='board'&&u.order.transportId===ship.id),cap=capability.combatCapability(s,ship),mission=f.memories.p0.naval?.ferries?.[ship.id];
 return {id:ship.id,kind:ship.kind,hp:ship.hp,maxHp:ship.maxHp,x:ship.x,y:ship.y,hullPayloadCapacity:naval.carries(ship),ferryCapacity:transport.isTransportKind(ship.kind)?naval.carries(ship):0,actualPassengerMass:passengers.reduce((n:number,u:any)=>n+physical.bodyMass(u),0),holdMass:ship.holdMass,savedSailingLoad:ship.sailing?.load,passengers:passengers.map((u:any)=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,maxHp:u.maxHp,mass:physical.bodyMass(u),deck:u.deck,cabin:u.cabin,expiresTick:u.expiresTick,order:u.order})),boarders:boarders.map((u:any)=>({id:u.id,kind:u.kind,mass:physical.bodyMass(u),order:u.order})),cabinQuota:cabin.shipCabinUsage(s,ship),combatCapability:cap,combatHull:defense.combatHull(ship),serviceReserved:service.reserved.has(ship.id),ferryMission:mission,outfitBefore:f.memories.p0.naval?.outfit?.shipId===ship.id?f.memories.p0.naval.outfit:undefined,outfitAfter:fullMemories.p0.naval?.outfit?.shipId===ship.id?fullMemories.p0.naval.outfit:undefined,combatMemoryBefore:f.memories.p0.naval?.combat?.[ship.id],combatMemoryAfter:fullMemories.p0.naval?.combat?.[ship.id],order:ship.order,sailing:ship.sailing,fullPlannerEntries:entries.filter((e:any)=>e.command.unitIds?.includes(ship.id)||e.command.unitId===ship.id||e.command.transportId===ship.id)};
});
const selected=ships.filter((u:any)=>u.id.endsWith('-33582')||u.id.endsWith('-34722'));
const comparisons=selected.map((ship:any)=>{
 const local=enemies.filter((t:any)=>dist(ship,t)<Math.max(900,capability.combatCapability(s,ship).range+150)&&naval.canReach(s.map,ship,t,s.units,capability.combatCapability(s,ship).range)&&coast.automaticShoreTargetReachable(s,ship,t));
 const towers=s.buildings.filter((b:any)=>b.kind==='defenseTower'&&b.complete&&ownership.isOpponentOwner(s,'p0',b.owner,{teams:s.teams}));
 const final=local.filter((t:any)=>minePlan.targetAvailable(t)&&!towers.some((tower:any)=>dist(tower,t)<=catalog.BUILDING_DEFS.defenseTower.attackRange));
 const memory=structuredClone(f.memories.p0.naval),chosen=fleet.fleetTarget(ship,final,memory);
 const command=chosen?fleet.fleetAttackCommand(ship,chosen,memory):undefined;
 return {id:ship.id,actualTargetComparisons:targets.map(t=>targetInfo(ship,t)),allLocalBeforeTowerAvailability:local.map((t:any)=>({id:t.id,kind:t.kind,owner:t.owner,distance:dist(ship,t),hp:t.hp,targetAvailable:minePlan.targetAvailable(t),coveredByTower:towers.some((tower:any)=>dist(tower,t)<=catalog.BUILDING_DEFS.defenseTower.attackRange)})),localCandidateQueryWarning:'For these free launched warships only: ordinary local, reach, shore, targetAvailable, and tower filter; exact full planner entries/memory remain authoritative.',reconstructedLocalChosen:chosen?.id,reconstructedFleetCommand:command,nearestP1:[...s.buildings].filter((b:any)=>b.owner==='p1'&&b.hp>0).sort((a:any,b:any)=>dist(ship,a)-dist(ship,b)).slice(0,3).map((b:any)=>({id:b.id,kind:b.kind,distance:dist(ship,b)})),p1AssaultGoal:f.memories.p0.naval?.muster?.goal};
});
const history=readdirSync(D+'/native-193200/frames').filter(n=>/^\d+-before-next-think\.json\.gz$/.test(n)&&+n.split('-')[0]<=223200).sort((a,b)=>+a.split('-')[0]-+b.split('-')[0]).map(name=>{
 const h=JSON.parse(gunzipSync(readFileSync(D+'/native-193200/frames/'+name)).toString());return {tick:h.snapshot.tick,ships:h.snapshot.units.filter((u:any)=>selected.some((v:any)=>v.id===u.id)).map((u:any)=>({id:u.id,x:u.x,y:u.y,hp:u.hp,kills:u.kills,order:u.order,combatMemory:h.memories.p0.naval?.combat?.[u.id]})),cinderSpire:h.snapshot.buildings.filter((b:any)=>b.id===targetIds[0]).map((b:any)=>({hp:b.hp})),sat2:h.snapshot.units.filter((u:any)=>targetIds.includes(u.id)).map((u:any)=>({id:u.id,hp:u.hp}))};
});
const hits=readFileSync(D+'/native-193200/native-hits.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)).filter(h=>h.tick<=223200);
const commandHistory=readFileSync(D+'/native-193200/public-commands.jsonl','utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)).filter(e=>e.tick<=223200&&e.owner==='p0'&&e.command.unitIds?.some((id:string)=>selected.some((ship:any)=>ship.id===id)));
const nativeEvidence={cutoffTick:223200,sourceStreamsReadOnly:true,hits: selected.map((ship:any)=>{const ownHits=hits.filter(h=>h.attacker===ship.id);return {id:ship.id,count:ownHits.length,first:ownHits[0],last:ownHits.at(-1),cinderSpireHitCount:ownHits.filter(h=>h.target===targetIds[0]).length,last5000TickHits:ownHits.filter(h=>h.tick>218200).length};}),cinderSpireHits:hits.filter(h=>h.target===targetIds[0]),sat2Hits:hits.filter(h=>targetIds.slice(1).includes(h.target)),commandHistory,history};
const after={frame:hash(f),world:hash(s),nextId:hash(f.nextId),all3mem:hash(f.memories)};
const sourceAfter=sourceCheck();
const invariants={before,after,worldIdAll3memUnchanged:JSON.stringify(before)===JSON.stringify(after),inputFileSHA256Before:sha(raw),inputFileSHA256After:sha(readFileSync(input)),sourceBefore,sourceAfter,source1468Unchanged:JSON.stringify(sourceBefore)===JSON.stringify(sourceAfter)};
if(!invariants.worldIdAll3memUnchanged||!invariants.source1468Unchanged)throw Error('Read-only invariant failed');
writeFileSync(O+'/evidence.json',JSON.stringify({classification:'Read-only recorded223200 world/id/all3mem diagnosis. Pure full-p0 query mutates only clone memory. Counterfactual station shots are explicitly separate. No native/game/commands/source edit.',actualTime:new Date().toISOString(),source:S,input,invariants,targets:targets.map((t:any)=>({...t,goldBounty:'order' in t?catalog.unitRules(s,t).goldBounty:undefined})),inventory,services:{reserved:[...service.reserved],commands:service.commands},comparisons,fullPlanner,nativeEvidence},null,2));
console.log(JSON.stringify({invariants,inventory:inventory.map(({id,kind,hp,ferryCapacity,hullPayloadCapacity,actualPassengerMass,holdMass,passengers,boarders,serviceReserved,ferryMission,fullPlannerEntries})=>({id,kind,hp,ferryCapacity,hullPayloadCapacity,actualPassengerMass,holdMass,passengers:passengers.length,boarders:boarders.length,serviceReserved,mission:ferryMission?.purpose,fullPlannerEntries})),comparisons:comparisons.map(({id,actualTargetComparisons,reconstructedLocalChosen,reconstructedFleetCommand})=>({id,reconstructedLocalChosen,reconstructedFleetCommand,targets:actualTargetComparisons.map((t:any)=>({id:t.id,centerDistance:t.centerDistance,canReach:t.canReach,withinLocal900:t.withinLocal900,station:t.shoreFiringStation,currentShots:t.currentMountedShots.map((p:any)=>({gap:p.pivotGap,range:p.range,arc:p.hardArc,lane:p.friendlyFireLaneClear,canShoot:p.geometryCanShootNow}))}))})),nativeHits:nativeEvidence.hits,fullPlannerEntries:entries.length},null,2));
