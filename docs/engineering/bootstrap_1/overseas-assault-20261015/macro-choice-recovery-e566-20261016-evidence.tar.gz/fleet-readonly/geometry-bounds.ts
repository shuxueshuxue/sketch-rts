import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const S='/workspace/sketch-rts-macro-choice-recovery-e566-control',D='/workspace/.playtest/macro-choice-recovery-e566-20261016',O='/workspace/.playtest/macro-choice-recovery-e566-fleet-readonly';
const sha=(v:any)=>createHash('sha256').update(v).digest('hex'),hash=(v:any)=>sha(JSON.stringify(v)),load=(p:string)=>import(pathToFileURL(S+'/'+p).href);
const cap=JSON.parse(readFileSync(D+'/fixed-source.json','utf8')),sourceChanges=()=>Object.entries(cap.hashes).filter(([p,h])=>sha(readFileSync(S+'/'+p))!==h).map(([p])=>p);
const sourceBefore=sourceChanges(),input=D+'/native-193200/frames/223200-before-next-think.json.gz',raw=readFileSync(input),f=JSON.parse(gunzipSync(raw).toString()),s=f.snapshot,before=hash(f);
const [terrain,geom,naval,coast,weapon,vet,nav,pursuit,avoid,alliance,capability,physical]=await Promise.all([load('src/shared/terrain.ts'),load('src/shared/ship-geometry.ts'),load('src/shared/naval.ts'),load('src/shared/shore-fire.ts'),load('src/shared/ship-equipment.ts'),load('src/shared/veteran-stats.ts'),load('src/shared/ship-navigation.ts'),load('src/shared/ship-pursuit.ts'),load('src/shared/ship-avoidance.ts'),load('src/shared/sim/command-validation.ts'),load('src/shared/combat-capabilities.ts'),load('src/shared/physical-body.ts')]);
terrain.setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
const ships=s.units.filter((u:any)=>u.owner==='p0'&&u.hp>0&&geom.shipProfile(u));
const hunters=s.units.filter((u:any)=>u.id==='satellite-guard-2-0'||u.id==='satellite-guard-2-1');
const target=s.buildings.find((b:any)=>b.id==='building-p2-cinderSpire-1597');
const dist=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
const allHullSat2=ships.map((ship:any)=>({id:ship.id,capability:capability.combatCapability(s,ship),hunters:hunters.map((hunter:any)=>({id:hunter.id,distance:dist(ship,hunter),canReach:naval.canReach(s.map,ship,hunter,s.units,capability.combatCapability(s,ship).range),station:coast.shoreFiringStation(s,ship,hunter)}))}));
const bounds=ships.filter((u:any)=>u.id.endsWith('-33582')||u.id.endsWith('-34722')).map((original:any)=>{
 const blockers=s.units.filter((other:any)=>geom.shipProfile(other)&&other.id!==original.id&&other.hp>0&&!alliance.areEnemyOwners(s,original.owner,other.owner));
 const weapons=weapon.installedWeapons(s,original).filter((i:any)=>(i.durability??1)>0);
 const canFire=(station:any,checkTurn:boolean)=>{
  for(const margin of [Math.PI/36,0]){
   const shotClear=(item:any,point:any,heading:number)=>weapon.mountedFireLaneClear({...station,sailing:{...station.sailing,heading}},item,point,blockers);
   const heading=weapon.bestFiringHeading(s,station,target,margin,shotClear),aimed={...station,sailing:{...station.sailing,heading}};
   const start={x:station.x,y:station.y,heading:station.sailing.heading},end={...start,heading};
   if(checkTurn&&(!nav.hullPassageClear(s.map,station,start,end)||!avoid.shipTraffic(station,s.units)(start,end)))continue;
   if(weapons.some((item:any)=>{const pose=weapon.mountedWeaponPose(aimed,item),def=weapon.SHIP_WEAPONS[item.kind],point=weapon.mountedTargetPoint(s,aimed,item,target,pose),gap=dist(pose.pivot,point);return weapon.shipGunCanAim(aimed,item,point)&&gap<=vet.veteranWeaponRange(station,def.range)&&gap>=(def.weapon.minRange??0)&&weapon.mountedFireLaneClear(aimed,item,point,blockers);}))return true;
  }
  return false;
 };
 const station=coast.shoreFiringStation(s,original,target),rotationChecks=station?{hullFitsAtStation:nav.hullFits(s.map,original,station),half0:nav.hullPassageClear(s.map,original,{...station,heading:0},{...station,heading:Math.PI}),half1:nav.hullPassageClear(s.map,original,{...station,heading:Math.PI},{...station,heading:2*Math.PI}),stationCanFire:canFire({...original,x:station.x,y:station.y,sailing:{...original.sailing,heading:station.heading}},false)}:undefined;
 const cases=[true,false].map(admitted=>{
  const ship=structuredClone(original),units=s.units.map((u:any)=>u===original?ship:u);
  const bow=weapons.find((item:any)=>item.mountId==='bow'&&vet.veteranWeaponRange(ship,weapon.SHIP_WEAPONS[item.kind].range)>=ship.attackRange),pose=bow&&weapon.mountedWeaponPose(ship,bow);
  const bowReach=pose?Math.hypot(pose.pivot.x-ship.x,pose.pivot.y-ship.y):0;
  let admissionCalls=0,shoreCalls=0;
  const goal=pursuit.shipPursuitGoal(ship,target,units,ship.attackRange,0,false,()=>canFire(ship,true),s.map,undefined,bowReach,(at:any)=>canFire(at,false),()=>{admissionCalls++;return admitted;},()=>{shoreCalls++;return coast.shoreFiringStation(s,ship,target);});
  return {syntheticPlanningAdmission:admitted,admissionCalls,shoreCalls,goalReturned:goal!==undefined,goal:goal??null,clonedPursuitAfter:ship.sailing.pursuit,warning:'Counterfactual direct component query on cloned selected hull. Native FIFO admission, sailing, command application and stepping were not run.'};
 });
 return {id:original.id,currentCanFireWithTurnAndLane:canFire(original,true),shoreStation:station,rotationChecks,currentRouteTargetId:original.sailing.route?.targetId,currentRouteIntent:original.sailing.route?.intent,currentOrderTargetId:original.order.targetId,cases};
});
const after=hash(f),sourceAfter=sourceChanges();if(before!==after||sourceBefore.length||sourceAfter.length)throw Error('Input/source changed');
const result={classification:'Bounded pure component geometry checks. Synthetic admission true/false explicitly counterfactual. All real223200 world/nextId/all3mem unchanged. No native run/step/command.',inputSHA256:sha(raw),frameBefore:before,frameAfter:after,source1468BeforeChanges:sourceBefore,source1468AfterChanges:sourceAfter,allHullSat2,bounds};
writeFileSync(O+'/geometry-bounds.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
