from pathlib import Path
import difflib, hashlib, json, subprocess

W=Path('/workspace/sketch-rts-macro-choice-recovery-e566-control')
D=Path('/workspace/.playtest/macro-choice-recovery-e566-20261016')
O=Path(__file__).parent
head='e5663c338f9c544a5e65a66a6ed278d35f74a8f4'
expectedPatch='0e8073929c2f2cd6fb7e65c8bb1658e44cbd387da31fe23f9349e04a3d055451'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def load(p):return json.loads(p.read_text())
def put(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
cap=load(D/'candidate-source.json');baseCap=load(D/'baseline-source.json')
assert cap['head']==head and git('rev-parse','HEAD').decode().strip()==head
assert cap['productionPatchSHA256']==expectedPatch==sha((D/'production.patch').read_bytes())
assert len(cap['hashes'])==1461
assert set(cap['hashes'])==set(baseCap['hashes'])
bad=[p for p,h in cap['hashes'].items() if sha((W/p).read_bytes())!=h]
assert bad==[]
changed=[p for p in cap['hashes'] if cap['hashes'][p]!=baseCap['hashes'][p]]
assert set(changed)=={'src/ai/policy/naval.ts','src/ai/bootstrap_1/transport-recovery.ts'}
actualChanged=git('diff','--name-only',head,'--','src').decode().splitlines()
assert set(actualChanged)==set(changed)
def body(text,name):
    at=text.index('function '+name+'(')
    return text[at:text.index('\n}',at)+2]
nav=(W/'src/ai/policy/naval.ts').read_text();oldNav=git('show',head+':src/ai/policy/naval.ts').decode()
unchanged={name:body(nav,name)==body(oldNav,name) for name in ['assaultExpedition','ferryCommands','nearbyAssaultCrew','landingSafe','coastOnWater','cancelFerry','readyToCross']}
assert all(unchanged.values())
ret=body(nav,'retargetAssaultFerries');oldRet=body(oldNav,'retargetAssaultFerries')
marker='    const observedIsland='
tail=ret[ret.index(marker):].replace('    return commands;\n','').replace('return commands;','return;')
assert tail==oldRet[oldRet.index(marker):]
queries=[]
for tick in [112800,145800,193200]:
    a=load(D/f'baseline-{tick}.json');b=load(D/f'candidate-{tick}.json')
    assert a['inputSHA256']==b['inputSHA256']
    assert a['all3MemoriesBefore']==b['all3MemoriesBefore']
    assert a['sourceChanges']==b['sourceChanges']==[]
    assert a['worldUnchanged'] and b['worldUnchanged'] and a['nativeBuildingOverlayRegistered'] and b['nativeBuildingOverlayRegistered']
    assert all(a['all3MemoriesAfter'][p]==b['all3MemoriesAfter'][p] for p in ['p1','p2'])
    navalEntries=[e for e in b['entries'] if e['scriptId']=='naval']
    queries.append({'tick':tick,'inputSHA256':a['inputSHA256'],'baselineFile':str(D/f'baseline-{tick}.json'),
      'candidateFile':str(D/f'candidate-{tick}.json'),'baselineSHA256':sha((D/f'baseline-{tick}.json').read_bytes()),
      'candidateSHA256':sha((D/f'candidate-{tick}.json').read_bytes()),
      'baselineEntryCount':len(a['entries']),'candidateEntryCount':len(b['entries']),
      'entriesExact':a['entries']==b['entries'],'allThreeAfterMemoriesExact':a['all3MemoriesAfter']==b['all3MemoriesAfter'],
      'beforeFerries':b['all3MemoriesBefore']['p0']['naval'].get('ferries'),
      'baselineAssault':a['all3MemoriesAfter']['p0']['naval'].get('assault'),
      'candidateAssault':b['all3MemoriesAfter']['p0']['naval'].get('assault'),
      'plannedBoardPassengerIds':[u for e in navalEntries if e['command']['type']=='board' for u in e['command']['unitIds']],
      'nativeWorldUnchanged':True,'nativeBuildingOverlayRegistered':True,'otherTwoMemoriesExact':True})
assert queries[0]['entriesExact'] and queries[0]['allThreeAfterMemoriesExact']
assert len(queries[1]['plannedBoardPassengerIds'])==len(queries[2]['plannedBoardPassengerIds'])==10
repair=(W/'src/ai/bootstrap_1/transport-recovery.ts').read_text()
catalog=(W/'src/shared/catalog.ts').read_text()
assert 'export const DOCK_REPAIR = { range: 240, hpPerSecond: 3, goldPerSecond: 1 };' in catalog
assert 'goldPerSecond' not in body(repair,'transportNeedsRecovery')
assert 'boat.maxHp-boat.hp>DOCK_REPAIR.hpPerSecond' in repair
report={
 'classification':'Final independent static review of actual isolated e566+two uncommitted production files. No native game/step, planner query, tests, source/driver/root edits by reviewer. Existing pure query JSON was read only.',
 'source':{'baseCommit':head,'candidateSourceRoot':str(W),'candidateCommit':None,
   'runtimeManifestFiles':1461,'allLiveRuntimeFilesExactlyCandidateManifest':True,
   'productionChangedFiles':[{'path':p,'sha256':cap['hashes'][p]} for p in changed],
   'productionPatch':str(D/'production.patch'),'productionPatchSHA256':expectedPatch,
   'candidateSourceManifestSHA256':sha((D/'candidate-source.json').read_bytes()),
   'note':'Not an external transformed0f-only bundle or a new committed head; actual current root e566 foundation plus the exact two-file dirty worktree patch.'},
 'findings':[],
 'staticContract':[
  {'area':'Physical task versus committed army identity','verdict':'Pass after the reviewed narrowing.',
   'evidence':'Only alive own real ferry-capable assault hulls participate. Any actual cargo, any current native board to that hull (all owners/kinds), or nonloading sailing/return phase gates the NEW ready early-invalidation and ready-first ordering. These broad physical facts do not add army strength. Existing committedIsland separately requires actual own alive permanent nonworker land cargo/native board and observed targetGround. Priest/summoner are not filtered by armed status; missing targetGround does not erase an actual physical task. crewIds declarations alone do not lock an otherwise empty loading mission.'},
  {'area':'Cache and readiness','verdict':'Pass within existing macro gate.',
   'evidence':'Keeps original400tick periodic retry. Early replacement requires no physical tasks, still-live current objective not ready, and an alternative passing original target eligibility and real shipyard/shore-water filters that is ready under unchanged assaultExpedition. Per-call ready map avoids repeated full scans inside sort comparisons. No ready alternative retains nearest-not-ready fallback and original retry schedule; no persistent cache/TTL/new owner.'},
  {'area':'Empty loading mission owner synchronization','verdict':'Pass within the explicitly all-empty scope.',
   'evidence':'Only live own assault loading hulls with zero snapshot passengers and no native board can synchronize to current global target. Same observed island keeps to/approach; a new or unknown island obtains coastOnWater from this boat actual water, replaces targetGround and clears approach/rally. Original from,pickup,sinceTick,phase and measured physical progress are retained on success. No extra40seconds is manufactured.'},
  {'area':'No valid coast','verdict':'Pass by static owner path.',
   'evidence':'If cross-island coast is undefined, same retarget owner calls unchanged cancelFerry, setting return/clearing crewIds. Its returned commands feed the same naval command array; original ferryCommands return branch then stops/deletes a truly empty ship task instead of recruiting for the stale objective. Under this exact zero-passenger/no-board guard cancelFerry normally returns an empty list; actual stop is the following ordinary ferry return branch, not an immediate retarget-prefix stop promise.'},
  {'area':'Original loaded convoy target-fall behavior','verdict':'Preserved.',
   'evidence':'Loaded/boarding guard only applies to the added empty prefix. Original same-observed-island target-fall group body is byte-identical after normalizing new command-array returns, so loaded convoys can still synchronize building IDs on their committed island with approach/to retained.'},
  {'area':'Functional repair readiness','verdict':'Pass.',
   'evidence':'Only removes wealth>=goldPerSecond unconditional recovery and updates its comment. Original shipNeedsRepair prerequisite, native catalog3HP quantum, rigging/rudder comparisons remain. Actual dock native spending1gold/second and repair3HP/runtime code are unchanged, as are budget/purchase/landing/army gates. Minor functional damage may be deferred; this is not a waiver of propulsion/steering or substantial hull repair.'}
 ],
 'mechanicallyUnchangedFunctions':unchanged,
 'originalLoadedTargetFallBodyExactlyPreserved':True,
 'existingPureP0Queries':queries,
 'resolvedReviewPoints':[
  'Initial physical/global versus empty-owner predicate mismatch was resolved with parent-approved hasPhysicalTask. Worker/temp cargo/native board and empty sailing/return now gate new ranking without being counted as military strength.',
  'An earlier reviewer concern that full-p0 queries omitted building overlays was incorrect: fixed planner-context.ts43 registers setBuildingBodies at the public entry. That concern was explicitly withdrawn. Actual current query outputs also record nativeBuildingOverlayRegistered; no downgrade of original full-planner queries is retained.',
  'Earlier generic suggestion to delete progress was withdrawn because progress stores actual hull pose/phase/passenger IDs, not target/shore. Final success sync leaves it unchanged; existing cancel/return phase semantics stay native.',
  'Catalog quantum is3HP/1gold, not an invented6HP allowance. No timing/margin constant changed.'
 ],
 'limits':[
  'Readiness and the stored six pure-p0 query outputs establish candidate selection/planned commands, not executed native board, actual deck load, deployment, combat or victory. Both145800 and193200 actual inputs have no ferry; their candidate ten board IDs are plans only. The actual112800 loaded task stays completely equal.',
  'Old0f checkpoint input under actual e566 source is a different-source pure comparison, not an e566 ordinary0 or equality of whole old trajectories. This review does not borrow the earlier0f44441/a26941255 or any care-tail result.',
  'The narrow hasPhysicalTask guard deliberately leaves worker/spirit-only payloads, current native board and sailing/return tasks with existing owners. It does not solve spirit-only lifecycle or every strategic delay; those require actual later evidence.',
  'Original periodic/target-fall selection still runs as before when due; the physical-task gate specifically disables NEW ready preference and early cache invalidation. It is not a claim that every possible original global-target update is now frozen.',
  'No tests, new boundary query or native run was performed by reviewer. Author tests/boundary results still in progress when review was sealed are not listed as passing. Root integration/full-game evidence remains separate.',
  'Normal opponents, rules2/frozen184 and all three-route official/unseen full-game acceptance requirements remain; original broken-container uncommitted recovery gap remains.'
 ],
 'conclusion':'No remaining concrete static production blocker found in the exact e566 two-file candidate under the parent-approved narrow scope. Pending validation is not claimed as complete.'}
put('FINAL-MACRO-E566-STATIC-REVIEW.json',report)
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in O.iterdir() if p.is_file() and p.name!='INDEX.json'}
put('INDEX.json',{'classification':'Static read-only review, not gameplay execution or acceptance.','files':files})
print(json.dumps({'review':str(O/'FINAL-MACRO-E566-STATIC-REVIEW.json'),'sha256':sha((O/'FINAL-MACRO-E566-STATIC-REVIEW.json').read_bytes()),'indexSHA256':sha((O/'INDEX.json').read_bytes()),'all1461RuntimeFilesMatch':True,'unchangedFunctions':unchanged},indent=2))
