#!/usr/bin/env python3
"""Offline evidence audit only: no JS imports, planner calls, game, steps or tests."""
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WORK = Path('/workspace/sketch-rts-macro-choice-recovery-e566-control')
D = Path('/workspace/.playtest/macro-choice-recovery-e566-20261016')
OLD = Path('/workspace/.playtest/bootstrap-assault-worker-defense-20261015')
GATE = Path('/tmp/bootstrap-deployment-gate')
PREVIOUS = Path('/workspace/.playtest/macro-choice-recovery-e566-independent-review/FINAL-MACRO-E566-STATIC-REVIEW.json')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    p = Path(p)
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_text())

def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args], text=True).strip()

fixed = read(D / 'fixed-source.json')
assert git('rev-parse', 'HEAD') == fixed['head'] == '07802649972cee4ccde66ec735d733917d931967'
assert not git('status', '--porcelain')
changed = [p for p, digest in fixed['hashes'].items() if sha(WORK / p) != digest]
assert not changed
assert sha(D / 'production.patch') == fixed['productionPatchSHA256'] == '0e8073929c2f2cd6fb7e65c8bb1658e44cbd387da31fe23f9349e04a3d055451'
assert sha(D / 'all-changes.patch') == fixed['allChangesPatchSHA256']
assert sha(PREVIOUS) == '8b60f659d52243c383cca1e9e809e7c59f74a58fa7ad789deb0cad2054447f00'

fixture = WORK / 'src/ai/bootstrap_1/fixtures/assault-deployment-original-89625.json.gz'
prior = WORK / 'src/ai/bootstrap_1/fixtures/assault-deployment-original-89145.json.gz'
frame, earlier = read(fixture), read(prior)
origin = GATE / 'deployment-beach-v3-prelanding.frames/before-think-89625.json'
assert frame == read(origin)
s, before = frame['snapshot'], earlier['snapshot']
assert s['map'] == before['map']
units, old_units = {u['id']: u for u in s['units']}, {u['id']: u for u in before['units']}
boats = ['unit-p0-carrier-3824', 'unit-p0-carrier-3510']
cargo = {bid: [u for u in s['units'] if u.get('deck', {}).get('shipId') == bid] for bid in boats}
all_cargo = [u for bid in boats for u in cargo[bid]]
assert [len(cargo[bid]) for bid in boats] == [15, 14]
score_fields = ['owner', 'kind', 'hp', 'maxHp', 'attackDamage', 'attackRange', 'attackCooldown', 'level', 'expiresTick', 'hands', 'gearMass']
assert all(all(u.get(k) == old_units[u['id']].get(k) for k in score_fields) for u in all_cargo)
assert all(u['owner'] == 'p0' and u['hp'] > 0 and u.get('expiresTick') is None for u in all_cargo)
assert not [i for i in s['items'] if i.get('carrierId') in {u['id'] for u in all_cargo}]
assert s.get('variants') == before.get('variants') is None
p1 = [u for u in s['units'] if u['owner'] == 'p1']
p1_workers = [u for u in p1 if u['kind'] == 'worker']
assert len(p1_workers) == 1
worker = p1_workers[0]
assert worker == old_units[worker['id']]
assert not [i for i in s['items'] if i.get('carrierId') in {u['id'] for u in p1}]
assert {u['id'] for u in p1} == {u['id'] for u in before['units'] if u['owner'] == 'p1'}
assert all(all(u.get(k) == old_units[u['id']].get(k) for k in score_fields + ['deck']) for u in p1)

old_query = read(OLD / 'query-base.json')
new_query = read(OLD / 'query-candidate-v2.json')
old_row = next(r for r in old_query['rows'] if r['tick'] == 89145)
new_row = next(r for r in new_query['rows'] if r['tick'] == 89145)
exact_query = read(GATE / 'deployment-beach-v5-89625-query.json')
assert exact_query['tick'] == 89625
assert exact_query['required'] == old_row['result']['required']
assert old_row['crewPower'] == new_row['crewPower']
assert old_row['landedPower'] == new_row['landedPower'] == 0
worker_row = new_row['workers'][0]
assert worker_row['id'] == worker['id']
assert len(new_row['workers']) == 1
old_manifest = read(OLD / 'candidate-source.json')['hashes']
rating_deps = ['src/ai/policy/v6/strength.ts', 'src/shared/combat-capabilities.ts', 'src/shared/catalog.ts', 'src/shared/unit-value.ts', 'src/shared/time.ts', 'src/shared/terrain.ts', 'src/shared/equipment.ts']
assert all(old_manifest[p] == fixed['hashes'][p] for p in rating_deps)

# Scalar transcription of the unchanged rating formula on this equipment-free,
# variant-free snapshot. This is arithmetic, not a native/planner invocation.
footman_rating = math.sqrt(145 * (16 / (22 / 20)))
caster = {'summoner': .6, 'priest': .8, 'ashHexer': .9}
def rating(u):
    if u['kind'] == 'worker':
        return 0
    base = caster.get(u['kind'])
    if base is None:
        base = math.sqrt(u['maxHp'] * u['attackDamage'] * 20 / u['attackCooldown']) / footman_rating
    return base * max(.1, u['hp'] / max(1, u['maxHp']))
per_boat = {bid: sum(rating(u) for u in cargo[bid]) for bid in boats}
assert math.isclose(sum(per_boat.values()), old_row['crewPower'], abs_tol=1e-12)
main_coordinate_group = [u for u in p1 if u['x'] < 3000]
assert math.isclose(sum(map(rating, main_coordinate_group)), exact_query['required'] / 1.4, abs_tol=1e-12)
new_required = exact_query['required'] + worker_row['physicalRating'] * 1.4
assert math.isclose(new_required, new_row['result']['required'], abs_tol=1e-12)
assert old_row['crewPower'] > exact_query['required']
assert old_row['crewPower'] < new_required

baseline_log = (D / 'baseline-existing-tests-third.log').read_text()
final_log = (D / 'final-changed-tests.log').read_text()
assert '4 failed | 23 passed (27)' in baseline_log
assert '39 passed (39)' in final_log
test_patch = (D / 'test-changes.patch').read_text()
assert 'expectedGold' in test_patch and 'goldSpent.us).toBe(0)' in test_patch
assert not git('diff', fixed['base'], fixed['head'], '--', 'src/ai/bootstrap_1/assault-retarget-deployment.test.ts')
delivery = read(D / 'validation-and-source-delivery.json')
v3 = read(GATE / 'deployment-beach-v3-prelanding.json')
v3_source_path = Path(v3['source'])
v3_source = read(v3_source_path)
old_regression = Path('/tmp/retarget-v2-deployment-review/evidence/README.md')
assert old_regression.exists()

report = {
 'classification': 'Independent read-only final source/test attribution and offline 89625 contract diagnosis. No JS imports, native/planner queries, commands, steps, tests, new game, or author/root edits by this audit.',
 'source': {
   'head': fixed['head'], 'base': fixed['base'], 'clean': True,
   'allTrackedRuntimeHashesChecked': len(fixed['hashes']), 'mismatches': changed,
   'productionPatchSHA256': sha(D / 'production.patch'),
   'allChangesPatchSHA256': sha(D / 'all-changes.patch'),
   'previousSealedStaticReview': {'path': str(PREVIOUS), 'sha256': sha(PREVIOUS), 'scope': 'Prior uncommitted production review remains unchanged; this supplement attributes the same production patch to fixed078026 and reviewed changed tests.'},
 },
 'tests': {
   'newAndChanged': {'log': str(D / 'final-changed-tests.log'), 'observedLog': '39/39 pass = 18 pure + 21 recovery', 'exitCode': '0 recorded in author delivery metadata, not executed by reviewer'},
   'inheritedDeployment': {'baselineLog': str(D / 'baseline-existing-tests-third.log'), 'candidateInitialLog': str(D / 'existing-contract-tests.log'), 'result': 'Same 4 return-vs-sailing failures, plus same 2 passing boundary cases. Exacte566 repair21 all green. Deployment assertions were not changed.', 'failures': ['v9_archer counterfactual two-loaded-boat sailing', 'v9_summoner counterfactual two-loaded-boat sailing', 'v9_knight counterfactual two-loaded-boat sailing', 'live companion sailing without approach']},
   'tsc': 'Author validation metadata records third tsc exit0; reviewer did not execute tsc.',
   'fullSuiteGreen': False,
   'repairContractReview': {
      'sixMajorRepairCases': 'Still require no dispatch while transportNeedsRecovery, actual positive goldSpent, gold+spent equals initialGold and zero own loss. Functional dispatch may retain <= native3HP hull quantum; full cosmetics repair no longer mandatory.',
      'sixMinorUnfundedBountyCases': 'Keep actual sail, bounty earned, all guards eliminated, exact native catalog bounty balance, zero repair spending, zero own loss and full riderHP. Explicitly assert minor damage remains while functional; cash arrival does not revoke functional readiness.',
      'unchangedCrossingAndStructuralCases': 'Existing injured current crossing and major hull/rigging/rudder obligations remain. This is an approved contract change, not hiding the four deployment failures.'
   }
 },
 'fixture89625': {
   'path': str(fixture), 'sha256': sha(fixture), 'realOrigin': str(origin), 'originSHA256': sha(origin),
   'fullWorldNextIdBothMemoriesEqualRealOrigin': True,
   'originalProducingRun': {'report': str(GATE / 'deployment-beach-v3-prelanding.json'), 'classification': v3['classification'], 'start': v3['start'], 'end': v3['end'], 'maxTicks': v3['maxTicks'], 'completedMeaning': 'Finite runner horizon at89641, not a natural match result.', 'sourceManifest': str(v3_source_path), 'sourceCommit': v3_source['commit'], 'sourceStatus': v3_source['status'], 'sourceArchiveSHA256': v3_source['sourceArchiveSha256'], 'driverSHA256': v3['driverSha256'], 'setup': v3['setup'], 'manualHistory': v3['manualHistory']},
   'testConstruction': 'Explicit counterfactual removes the real old shipyard and assigns the companion the real live townhall on the same island. The historical full89625 world is real; this objective combination is not an observed match failure.',
   'historicalExpectedIntent': {'readme': str(old_regression), 'result': 'Historical selected integration source6f80 passed6 cases; archived one-pass retarget source failed4. Same-island target synchronization prevented splitting a 15+14 actual cargo convoy; no incomplete half landing, source-state preserved except target/ground/normal progress.'},
   'actualCargo': [{ 'boatId': bid, 'hp': units[bid]['hp'], 'position': {'x': units[bid]['x'], 'y': units[bid]['y']}, 'phase': frame['memories']['p0']['naval']['ferries'][bid]['phase'], 'count': len(cargo[bid]), 'kinds': dict(collections.Counter(u['kind'] for u in cargo[bid])), 'permanentNonWorkerRatingArithmetic': per_boat[bid], 'sameRatingInputsAs89145': True } for bid in boats],
   'all29OwnAlivePermanent': True, 'attackingWorkerRating': 0,
   'crewPowerExisting89145Trace': old_row['crewPower'],
   'landedPowerExisting89145Trace': 0,
   'landed89625Scope': 'All own nondeck land soldiers remain at the same coordinates as89145; no new own landed reinforcement is present. Existing trace says landedPower0; this audit did not call sameGround anew.',
   'geometryExisting89625Trace': {'roadBetweenBoats': exact_query['rows'][0]['roadToOther'], 'straightBetweenBoats': exact_query['rows'][0]['straightToOther'], 'cohortThreshold': 450, 'HOME_WATERS': 900},
   'wholeIslandDefense': {
     'oldRequiredExistingExact89625Trace': exact_query['required'],
     'oldDefenseFromRecordedRequired': exact_query['required']/1.4,
     'armedWorkerFromExisting89145NativeTerrainQuery': worker_row,
     'workerPositionAndAllFieldsUnchangedAt89625': True,
     'onlyP1WorkerIn89625Snapshot': worker['id'],
     'counterfactualTargetIsSameObservedIsland': 'Portable test explicitly verifies old shipyard/livehall/chosen new target sameGround; old target removal cannot remove this worker from that landmass.',
     'newRequiredSourceArithmeticNotFreshPlannerTrace': new_required,
     'newDefenderContributionTimes1_4': worker_row['physicalRating']*1.4,
     'oldCrewMargin': old_row['crewPower']-exact_query['required'],
     'newCrewDeficit': new_required-old_row['crewPower'],
     'ratingDependenciesIdenticalToArchivedWorkerDefenseCandidate': rating_deps,
     'snapshotP1Roster': dict(collections.Counter(u['kind'] for u in p1)),
     'spatialMainGroupCorroboration': {'selection': 'raw snapshot x<3000, not a new sameGround query', 'kinds': dict(collections.Counter(u['kind'] for u in main_coordinate_group)), 'oldRatingArithmetic': sum(map(rating, main_coordinate_group)), 'matchesRecordedWholeIslandDefenseExactly': True},
     'remoteRoster': 'Four of the23 sparkArchers are at approximately(4900,8800), outside the main coordinate group; no enemy sea hull or tower exists in this snapshot.'
   },
   'deploymentConditions': {
      'nearbyCohort': 'Both actual ships are sailing to synchronized same-island target, sea path294.4<=450; own29cargo includes one worker, whose invading army score remains0.',
      'support': 'No own landed land army; naval fire support is a separate landingSafe test and is not added to whole-island assault power/incomingPower. Cannot make this19.271 convoy satisfy19.629 by borrowing global cargo or naval guns.',
      'nativeExposureOldTrace': 'At89625 first3824 has a feasible15-body hypothetical landing with guards[], companion3510 individual/joint exposure undefined. These exposure.landed lists are simulated potential positions, not actual units already landed.',
      'sailingNearCoast': 'Both boats are within900 straight distance of their saved mission.to and therefore enter the nearcoast power branch even without rally. There are only these two missions; after either cancels, remaining underway strength can only decrease.',
      'returnBranchInference': 'At the unchanged nearcoast sailing branch, incomingPower19.271<required19.629 is sufficient to cancel. Exact first e56689625 branch/order is not archived; this is source+existing-score inference, not a newly observed cancellation trace.',
      'noEnemySeaHull': True,
      'newMacroPath': 'Physical loaded sailing tasks block new ready-preference/cache invalidation, and empty-loading retarget prefix skips both ships; transportReady callback is explicitly false and direct naval test does not call new transportNeedsRecovery. Same inherited failures therefore cannot be assigned to this macro patch.'
   },
   'conclusion': 'The historical unconditional sailing expectation straddles the later approved real worker-defense increase. Same-island retarget identity remains necessary, but this exact two-ship force no longer meets unchanged1.4 whole-island admission. Do not weaken worker defense, alter1.4, or silently change old expectations to manufacture green. Four inherited reds remain explicitly recorded; no fresh native match benefit or final bootstrap acceptance follows.',
   'remainingGap': 'No exact current e56689625 per-unit native membership/cancel-order trace was available or generated. All current numbers beyond archived exact89625 required are explicitly source arithmetic/cross-snapshot corroboration. A future targeted evidence task may close exact branch ordering; this does not block current macro solely because the four reds were inherited.'
 },
 'limits': ['No complete-game or generalization result belongs to this static review.', 'Author has a separately authorized078026 changed-source193200 continuation; its current/final result is outside this review.', 'No main/rules3/other source was changed.', 'Original broken-container uncommitted changes remain unavailable and unrecovered.']
}

# Check the qualitative distance statements without a path solver.
for bid in boats:
    boat, m = units[bid], frame['memories']['p0']['naval']['ferries'][bid]
    report['fixture89625']['actualCargo'][boats.index(bid)]['straightDistanceToMissionTo'] = math.hypot(boat['x']-m['to']['x'], boat['y']-m['to']['y'])

inputs = [D/'fixed-source.json', D/'production.patch', D/'all-changes.patch', D/'baseline-existing-tests-third.log', D/'existing-contract-tests.log', D/'final-changed-tests.log', D/'test-changes.patch', D/'validation-and-source-delivery.json', OLD/'query-base.json', OLD/'query-candidate-v2.json', OLD/'candidate-source.json', OLD/'query-existing-v2.ts', GATE/'deployment-beach-v5-89625-query.json', GATE/'deployment-beach-v3-prelanding.json', v3_source_path, origin, fixture, prior, PREVIOUS, old_regression]
report['inputEvidence'] = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs]
out = OUT / 'FINAL-078026-CONTRACT-REVIEW.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'report': str(out), 'sha256': sha(out), 'sourceHead': fixed['head'], 'hashCount': len(fixed['hashes']), 'crew': old_row['crewPower'], 'oldRequired': exact_query['required'], 'newRequiredSourceArithmetic': new_required, 'inheritedFailedTests': 4, 'newChangedPassedTests': 39}, indent=2))
