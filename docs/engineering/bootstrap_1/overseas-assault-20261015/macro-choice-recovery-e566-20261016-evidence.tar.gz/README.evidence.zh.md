# 078026 宏目标与功能就绪候选：真实续局负例

这是独立候选 `07802649972cee4ccde66ec735d733917d931967`（父 `e5663c338f9c544a5e65a66a6ed278d35f74a8f4`）的已停止证据。根生产仍是 e566；没有把本候选合入，也没有借根新普通开局胜绩。原容器未提交修改的恢复缺口继续保留。

生产仅两文件：沿原 1.4/原工人防御与 `assaultExpedition` 优先选现有军力 ready 的可达敌岛；所有实际载荷、任意 native board、sailing/return 实际运输任务保留原 owner，仅实空 loading 同步目标。功能性船只是否可用与财富脱钩，保留原 catalog 最后 3HP、索具/舵完整要求。没有改买价、资源、人口或敌方。`production.patch` SHA256 为 `0e8073929c2f2cd6fb7e65c8bb1658e44cbd387da31fe23f9349e04a3d055451`。

`fixed-source.json` 是提交后的 1468 个全部现有 tracked 文件；此前 baseline/candidate 清单是当时采集的 1461 项原运行清单，发生在新测试/fixture加入之前，不是伪造为最终提交的预启动清单。完整源码 capsule 每 payload SHA/bytes 已验证。新变更 39 测试和 TypeScript 通过；邻接另 39 例通过。4 个旧 89625 deployment 测试在未改 e566 基线上也失败，保留全部红项与日志，未删断言或降低工人防御/军力阈值，不称全套通过。

纯完整 p0 pipeline 查询在 112800 的命令和全部三方记忆与 e566 基线完全相同；145800 为 5→7 条，193200 为 6→6 条但目标转向 p1、产生 10 人 board 与 stop。已有正常冻结 v5+v7、规则2/184manifest不变。查询不是已执行命令。

随后唯一 native 从原0f普通局193200完整 world/nextId/三方记忆换码续局。冷恢复全等，首 p0规划与同生产纯查询的命令/全记忆全等。PID291726，2026-10-16 02:35:45.172Z 启动，238516经获准观察 stop 正常 exit0；winner=null/naturalComplete=false。这不是新普通0，也不是自然败局或最终验收。全程40,184公开命令、8次微小己方碰撞hit、4,777观察事件；0敌方相关hit、0永久terminal、所有原生战绩与初始逐值相同。1,520个临时消失为expiry观察，不能当新增战损。

行为确有改变：真实11永久军上甲板，船离开家港去殖民岛接兵；但只有一个运输用途carrier，甲板已放不进其他永久兵，实际永久战力9.5–11.1低于要求20.115569。两临时spirit占位在198000的独立几何反事实中影响可再装一名永久兵；这不是移走召唤物就能整军过海的证明。原选定整组军队在空甲板也不满足同一 packing 组合，未穷举所有组合，不能称战术不可行。最终观察到10次本岸unload及重复loading/pickup/return；全图仍动态移动/召唤，未声称世界固定或永远不会赢。

`capital-and-exits-223200.json` 使用真实完整档，只读 native public query：paid cutter training-51467 remaining0 无合法launch；只移除bombard50739的明确反事实即可出现合法pose。尚未实证移动它的公开命令可执行。native cancelTraining 原job可退款160，报价543.33；新carrier420、transport240。三个矿岛均有合法hallsite但无己方工人/厅；sat2仍有7/20HP两中立。当前383.33付不起400厅，没有实际退款、注资、购买或未付费build。

三张 `observed-*.png` 是真实已记录完整world的 native drawWorld 后渲染，输入前后hash相同，不是实时屏幕截图。第一次摄像坐标错误的图/脚本保存在 before-camera-correction，不能拿来替代修正图或几何证据。

严格末窗从真实237600周期档恢复至238516：721命令、0hit、114事件、62个完整p0前world/id/三方记忆hash逐项相同；最终world/id/三方记忆全等，source1468/frozen184前后无变。`closure-237600-238516/proof.json` 是这段支持停止负例的闭合，不是完整自然比赛验收。

raw event commandIndex 是本续局0起的公开命令行索引；冷重放按原prefix映回同索引，不能当原0f普通局全局索引。hit只有tick，无独立commandIndex。observer为原已核NativeLedger逐字复制；终生terminal IDs/lastHit等map仍增长，只有recent摘要限12，不宣称整个observer内存常数。step内完整出现又消失的变化可能未被poll看到，lastHit不能单独证明死亡原因；本窗没有永久死亡。

下一工作需要让健康舰艇运用真实挂炮能力/安全海路参与全图目标，解决码头实际任务占位与资本、可投送军力的组合瓶颈。078026原源与该续局原件保持固定；后续候选另归属，不把这些局部改善当胜利。
