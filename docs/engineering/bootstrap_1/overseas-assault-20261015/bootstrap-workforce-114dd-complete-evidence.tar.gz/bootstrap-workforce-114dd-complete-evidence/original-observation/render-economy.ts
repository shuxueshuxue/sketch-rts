import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const source='/tmp/sketch-rts-knight-6f80a-ordinary-control',directory='/tmp/bootstrap-knight-economy-independent-review-20261015';
const {createCanvas}=await import(pathToFileURL(source+'/node_modules/@napi-rs/canvas/index.js').href);
const {installHeadlessCanvas}=await import(pathToFileURL(source+'/src/recorder/record.ts').href);
const {drawWorld}=await import(pathToFileURL(source+'/src/client/world-renderer.ts').href);
const {UnitFacingTracker}=await import(pathToFileURL(source+'/src/client/unit-facing.ts').href);
installHeadlessCanvas();
const bytes=readFileSync(directory+'/input-complete-132000.json'),{snapshot}=JSON.parse(bytes.toString());
const views={mainland:{x:4750,y:5100,width:1350,height:1100,zoom:1},oldHome:{x:7800,y:3300,width:1400,height:1100,zoom:1}};
const outputs=[];
for(const [name,view]of Object.entries(views)){
  const canvas=createCanvas(view.width,view.height);
  drawWorld({ctx:canvas.getContext('2d')as any,snapshot,view,now:snapshot.tick*50,facing:new UnitFacingTracker(),labels:{mercenaryStock:String,unitKind:String}});
  const output=`${directory}/native132000-${name}.png`;writeFileSync(output,canvas.toBuffer('image/png'));outputs.push({name,view,output});
}
writeFileSync(directory+'/native-visual.json',JSON.stringify({classification:'Native drawWorld rendering of real saved132000 world, no simulation or world edits. New animation facing does not reconstruct historical motion.',source,input:directory+'/input-complete-132000.json',inputSHA256:createHash('sha256').update(bytes).digest('hex'),outputs},null,2)+'\n');
console.log(JSON.stringify(outputs));
