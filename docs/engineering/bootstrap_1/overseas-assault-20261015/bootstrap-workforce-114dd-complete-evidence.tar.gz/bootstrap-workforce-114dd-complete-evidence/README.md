# Workforce destination credit 114dd: complete changed-code evidence

Start with continuations/comparison.json. Both runs restore the same original6f80 true ordinary0 tick132000 world, nextId and both policy memories, then run fixed3bdb or114dd to natural p0 victory. These are changed-code continuations, not true0 acceptance results. Enemy12 units remain at both terminal states.

The candidate repairs actual regional workforce accounting and pays for five workers, but exposes a shared unsafe boarding mechanism and has seven permanent losses versus three. Earlier victory alone is not a net improvement; root has not merged this candidate.

The 40 new-worker deposits produce actual177.06 cash. The after-step formula estimate177.18 differs at135312 because of a same-tick death/upkeep change. Cash-inflow balance includes bounties/other inflows. Preserve this distinction.

Each run includes full source preflight hashes, full initial/every300/payment/birth/income/terminal checkpoints, actual commands and observed payments/deposits, source postflight, and exact terminal-window native replay. Worker-loss diagnostic134100→135300 closes full world,nextId,both memories,commands; observer hit fields are mid-step, not resumable complete snapshots.

Original observations include true complete inputs132000/135600/135692 and native visuals. The initial-overbroad135600 structural query is a retained negative; corrected query credits legitimate1018 incoming worker once and excludes only unrelated1008. Structural queries are not games. Source patch includes the new4 real-fixture regressions; all49 related checks pass, existing16 transported-workforce tests unchanged, strict tsc passes. Original broken-container uncommitted changes remain unrecovered.
