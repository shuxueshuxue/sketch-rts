import { readFileSync,writeFileSync,readdirSync,mkdirSync } from 'node:fs';
import { gzipSync,gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
const source='/tmp/sketch-rts-workforce-destination-v1-control',directory='/tmp/bootstrap-workforce-destination-v1-20261015/worker-loss-diagnostic';mkdirSync(directory);
const fullRun=JSON.parse(readFileSync('/tmp/bootstrap-workforce-destination-v1-20261015/candidate-v1/result.json','utf8'));
const candidateDir='/tmp/bootstrap-workforce-destination-v1-20261015/candidate-v1/';
const savedAt=(tick:number)=>JSON.parse(gunzipSync(readFileSync(candidateDir+fullRun.frames.find((frame:any)=>frame.tick===tick&&frame.label==='complete-checkpoint').path)).toString());
const initial=savedAt(134100),expected=savedAt(135300),imp=(path:string)=>import(pathToFileURL(source+'/'+path).href),norm=(value:any)=>JSON.parse(JSON.stringify(value));
const [{createGame,restoreSnapshotIntoGame,snapshotGame},{createAiMemoryProvider},{createBootstrapCommandPlanner},{runAiGameLoop}]=await Promise.all([imp('src/shared/sim.ts'),imp('src/ai/planner-context.ts'),imp('scripts/bootstrap_1-planner.ts'),imp('src/ai/game-runner.ts')]);
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,initial.snapshot,initial.nextId);const memories=createAiMemoryProvider();for(const[owner,memory]of Object.entries(initial.memories))memories.set(owner,structuredClone(memory));
const full=()=>norm({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(fullRun.setup.agents).map(owner=>[owner,memories.get(owner)]))});
const planner=await createBootstrapCommandPlanner(memories),ids=new Set(['unit-p0-worker-3','unit-p0-worker-11845','unit-p0-worker-13542']),hits:any[]=[],commands:any[]=[],observations:any[]=[],frames:any[]=[],deaths:any[]=[];
const unitState=(unit:any)=>unit&&norm({id:unit.id,kind:unit.kind,owner:unit.owner,x:unit.x,y:unit.y,hp:unit.hp,order:unit.order,orderQueue:unit.orderQueue,deck:unit.deck});
const capture=(label:string)=>{const frame=full(),path=`${game.tick}-${frames.length}-${label}.json.gz`;writeFileSync(directory+'/'+path,gzipSync(JSON.stringify(frame)));frames.push({tick:game.tick,label,path});};
let previous=new Map(game.units.filter((unit:any)=>ids.has(unit.id)).map((unit:any)=>[unit.id,unitState(unit)]));
game.observer={hit(attacker:any,target:any,damage:number,hpBefore:number){if(!ids.has(target.id))return;hits.push({tick:game.tick,damage,hpBefore,hpAfter:target.hp,attacker:unitState(attacker),target:unitState(target)});}};
capture('initial');
runAiGameLoop({name:'Same fixed candidate both-AI worker death mechanism diagnostic',game,agents:fullRun.setup.agents,maxTicks:135300,thinkInterval:15,commandPlanner:(context:any)=>{
  if(context.owner==='p0'&&(game.tick<=134210||game.tick>=134500&&game.tick<=134620||game.tick>=134950&&game.tick<=135050))capture('complete-before-think');
  return planner(context);
}},{onCommand(event:any){commands.push({tick:event.tick,owner:event.owner,scriptId:event.scriptId,command:structuredClone(event.command)});},onStep(){
  for(const[id,before]of previous)if(!game.units.some((unit:any)=>unit.id===id)){deaths.push({tick:game.tick,before,lastHit:hits.findLast(hit=>hit.target.id===id)});capture('after-native-death');}
  previous=new Map(game.units.filter((unit:any)=>ids.has(unit.id)).map((unit:any)=>[unit.id,unitState(unit)]));
  if(game.tick%15===0)observations.push({tick:game.tick,units:[...previous.values()]});
}});
const final=full();capture('terminal');
const result={classification:'Same fixed114dd source full both-AI134100→135300 reconstruction from its actual complete saved checkpoint; observer records native hits without edits. Hit callback fields are mid-step observations; only complete before-think/after-step frames are resumable.',source,commit:fullRun.commit,initialTick:134100,end:game.tick,verification:{world:isDeepStrictEqual(final.snapshot,expected.snapshot),nextId:final.nextId===expected.nextId,allMemories:isDeepStrictEqual(final.memories,expected.memories),allCommands:isDeepStrictEqual(commands,fullRun.commands.filter((entry:any)=>entry.tick>=134100&&entry.tick<135300))},hits,deaths,commands,observations,frames};
writeFileSync(directory+'/result.json',JSON.stringify(result));console.log(JSON.stringify({end:game.tick,verification:result.verification,deaths,hits}));
