import json, pathlib, subprocess, hashlib, shutil, tarfile, collections
P=pathlib.Path('/tmp/bootstrap-workforce-destination-v1-20261015')
S=pathlib.Path('/tmp/sketch-rts-workforce-destination-v1-control')
B=json.loads((P/'baseline-3bdb/result.json').read_text()); C=json.loads((P/'candidate-v1/result.json').read_text())
def report(d):
 a=d['initial']['snapshot']; z=d['final']['snapshot']; ap=a['players']['p0']; zp=z['players']['p0']; spend=z['match']['stats']['goldSpent']['p0']-a['match']['stats']['goldSpent']['p0']
 grouped=collections.defaultdict(lambda:{'deposits':0,'actualGold':0,'afterStepExpectedGold':0})
 mismatches=[]
 for x in d['deposits']:
  v=round(x['netGoldChange']+x['spendDelta'],2);g=grouped[x['id']];g['deposits']+=1;g['actualGold']=round(g['actualGold']+v,2);g['afterStepExpectedGold']=round(g['afterStepExpectedGold']+x['expectedNativeIncome'],2)
  assert len(x['allDepositorsThisTick'])==1
  if round(v-x['expectedNativeIncome'],2):mismatches.append({'tick':x['tick'],'actualCash':v,'afterStepExpected':x['expectedNativeIncome'],'difference':round(v-x['expectedNativeIncome'],2)})
 return {'commit':d['commit'],'start':d['start'],'end':d['end'],'winner':d['winner'],'completed':d['completed'],'restored':d['restored'],'sourceUnchanged':d['sourceUnchanged'],'sourceStatus':d['sourceStatus'],'lastWindowReplay':d['replay'],'goldInitial':ap['gold'],'goldFinal':zp['gold'],'goldRetainedDelta':round(zp['gold']-ap['gold'],2),'goldSpentDelta':spend,'cashInflowsIncludingBountiesAndOtherInflows':round(zp['gold']-ap['gold']+spend,2),'workerTrainingPayments':d['trainingPayments'],'workerTrainingGold':sum(x['goldPaid'] for x in d['trainingPayments']),'births':d['births'],'newWorkerDeposits':dict(grouped),'newWorkerActualCashTotal':round(sum(g['actualGold'] for g in grouped.values()),2),'afterStepFormulaMismatch':mismatches,'permanentDeaths':d['removedPermanent'],'nativeUnitsLostDelta':z['match']['stats']['unitsLost']['p0']-a['match']['stats']['unitsLost']['p0'],'neutralKillDelta':z['match']['stats']['unitsKilledByNeutral']['p0']-a['match']['stats']['unitsKilledByNeutral']['p0'],'terminalWorkers':len(d['summary']['workers']),'terminalWorkerOrders':dict(collections.Counter(x['order']['type'] for x in d['summary']['workers'])),'terminalOpponents':d['summary']['opponents'],'destroyedEnemyBuildingsDelta':z['match']['stats']['buildingsDestroyed']['p0']-a['match']['stats']['buildingsDestroyed']['p0']}
comparison={'classification':'Both full two-AI changed-code continuations of original 6f80 ordinary0 saved tick132000. Neither is a new ordinary0 or acceptance/generalization result. No root merge authorized.','setup':C['setup'],'baseline':report(B),'candidate':report(C),'interpretation':['Regional embarked-worker credit defect reproduced by real132000 and135600 fixtures. New4 tests red on3bdb,49 related tests green on114dd; existing16 transported-workforce unchanged; tsc passed.','Five actual native75-gold hires cost375;40 return deposits from three new workers produced actual177.06 gold. The first two miners produced168.83 against150 initial hire cost; later225 replacement cost yielded only8.23 by terminal.','Candidate naturally wins370 ticks earlier but loses7 permanent units versus3, including3 workers to the same dangerous native boarding shore; it is not established as a net improvement and is not merged.','Cash inflow balance includes rewards/other inflows, uses different natural terminal times and cannot be called pure mining revenue.','One same-tick death135312 changes upkeep; driver after-step expected income differs0.12 from observed cash. Actual cash177.06 is authoritative; expected177.18 retained as diagnostic.','Both games end with enemy12 live units and0 buildings, not total unit elimination.','Original inaccessible container uncommitted changes remain unrecovered.']}
(P/'comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n')
archiveRoot=pathlib.Path('/tmp/bootstrap-workforce-114dd-complete-evidence')
archiveRoot.mkdir(exist_ok=True)
for src in P.iterdir():
 if src.name=='node_modules':continue
 dest=archiveRoot/'continuations'/src.name
 dest.parent.mkdir(exist_ok=True)
 if src.is_dir():shutil.copytree(src,dest,dirs_exist_ok=True)
 else:shutil.copy2(src,dest)
E=pathlib.Path('/tmp/bootstrap-knight-economy-independent-review-20261015')
for src in E.iterdir():
 if src.name in {'node_modules','package.json'}:continue
 dest=archiveRoot/'original-observation'/src.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
(archiveRoot/'source').mkdir(exist_ok=True)
patch=subprocess.check_output(['git','-C',str(S),'format-patch','--binary','--stdout','3bdb3749bea4d3c415a8709d7a7f86b0ed1dcb71..114dd49f589be204e847d6ed76d436bbf9ef1abd'])
(archiveRoot/'source/114dd49f.patch').write_bytes(patch)
for name in subprocess.check_output(['git','-C',str(S),'diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines():
 dest=archiveRoot/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/name,dest)
audit={}
for n,d in [('baseline-3bdb',B),('candidate-v1',C)]:
 launch=json.loads((P/n/'launch.json').read_text());tree=pathlib.Path(d['source']);bad=[]
 for name,h in launch['sourceHashes'].items():
  if hashlib.sha256((tree/name).read_bytes()).hexdigest()!=h:bad.append(name)
 status=subprocess.check_output(['git','-C',str(tree),'status','--porcelain'],text=True)
 audit[n]={'commit':subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip(),'fileCount':len(launch['sourceHashes']),'changedFiles':bad,'status':status,'inputHashMatches':hashlib.sha256(pathlib.Path(launch['input']).read_bytes()).hexdigest()==launch['inputSHA256']}
 assert not bad and not status and audit[n]['inputHashMatches']
(archiveRoot/'SOURCE-FINAL-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
(archiveRoot/'README.md').write_text('''# Workforce destination credit 114dd: complete changed-code evidence\n\nStart with continuations/comparison.json. Both runs restore the same original6f80 true ordinary0 tick132000 world, nextId and both policy memories, then run fixed3bdb or114dd to natural p0 victory. These are changed-code continuations, not true0 acceptance results. Enemy12 units remain at both terminal states.\n\nThe candidate repairs actual regional workforce accounting and pays for five workers, but exposes a shared unsafe boarding mechanism and has seven permanent losses versus three. Earlier victory alone is not a net improvement; root has not merged this candidate.\n\nThe 40 new-worker deposits produce actual177.06 cash. The after-step formula estimate177.18 differs at135312 because of a same-tick death/upkeep change. Cash-inflow balance includes bounties/other inflows. Preserve this distinction.\n\nEach run includes full source preflight hashes, full initial/every300/payment/birth/income/terminal checkpoints, actual commands and observed payments/deposits, source postflight, and exact terminal-window native replay. Worker-loss diagnostic134100→135300 closes full world,nextId,both memories,commands; observer hit fields are mid-step, not resumable complete snapshots.\n\nOriginal observations include true complete inputs132000/135600/135692 and native visuals. The initial-overbroad135600 structural query is a retained negative; corrected query credits legitimate1018 incoming worker once and excludes only unrelated1008. Structural queries are not games. Source patch includes the new4 real-fixture regressions; all49 related checks pass, existing16 transported-workforce tests unchanged, strict tsc passes. Original broken-container uncommitted changes remain unrecovered.\n''')
files=[]
for src in sorted(archiveRoot.rglob('*')):
 if src.is_file() and src.name!='INDEX.json':files.append({'path':src.relative_to(archiveRoot).as_posix(),'bytes':src.stat().st_size,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
(archiveRoot/'INDEX.json').write_text(json.dumps({'payloadCount':len(files),'files':files},indent=2)+'\n')
tar=pathlib.Path('/tmp/bootstrap-workforce-114dd-complete-evidence.tar.gz')
with tarfile.open(tar,'w:gz') as t:t.add(archiveRoot,arcname=archiveRoot.name)
with tarfile.open(tar) as t:
 index=json.load(t.extractfile(archiveRoot.name+'/INDEX.json'))
 for f in index['files']:
  b=t.extractfile(archiveRoot.name+'/'+f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print(json.dumps({'archive':str(tar),'bytes':tar.stat().st_size,'sha256':hashlib.sha256(tar.read_bytes()).hexdigest(),'payloadCount':len(files),'sourceAudit':audit},indent=2))
