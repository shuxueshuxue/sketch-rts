import collections, gzip, hashlib, json, pathlib, subprocess

D=pathlib.Path('/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016')
O=pathlib.Path('/workspace/.playtest/evacuation-owner-independent-review')
S=pathlib.Path('/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control')
ids={'unit-p0-emberRavager-5447','unit-p0-emberRavager-5665'}
ship='unit-p0-carrier-5362'
write=lambda name,x:(O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

# These are bounded extracts of the original stream, never replacement game state.
streams={}
for name in ['ordinary0-public-commands.jsonl','ordinary0-native-hits.jsonl','ordinary0-native-events.jsonl']:
 rows=[]
 for line in (D/name).open():
  row=json.loads(line)
  if 21700<=row.get('tick',-1)<=22800 and any(i in line for i in ids): rows.append(row)
 streams[name]=rows
 write(name.removesuffix('.jsonl')+'-bounded-extract.json',{'original':str(D/name),'window':[21700,22800],'rows':rows})

caps=collections.defaultdict(set);effects=[];push=[];items=[];skills={};inputs=[]
for path in sorted((D/'coastal-replay-22200-22800.inputs').glob('*-p0.json.gz')):
 d=json.load(gzip.open(path));s=d['snapshot'];tick=s['tick']
 inputs.append({'tick':tick,'path':str(path),'sha256':sha(path),'nextId':d['nextId'],'memoryKeys':list(d['memories'])})
 for u in s['units']:
  if u['id'] in ids|{ship}:
   caps[u['id']].add(u['speed'])
   if u.get('effects'):effects.append({'tick':tick,'unit':u['id'],'effects':u['effects']})
   if u.get('pushX') is not None or u.get('pushY') is not None:push.append({'tick':tick,'unit':u['id'],'x':u.get('pushX'),'y':u.get('pushY')})
  if u['owner']=='p0' and u.get('veteranSkill'):skills[u['id']]=u['veteranSkill']
 for i in s['items']:
  if i.get('carrierId') in ids|{ship}:items.append({'tick':tick,'id':i['id'],'kind':i['kind'],'carrierId':i['carrierId']})

qpath=O/'geometry-owner-query.json';q=json.load(qpath.open())
for row in q['rows']:
 for p in row['patients']:
  if 'universalEarliestPossibleAlongsideTicks' in p:
   p['currentLocomotionOptimisticAlongsideLowerBoundTicks']=p.pop('universalEarliestPossibleAlongsideTicks')
q['boundaries'][1]='Current native locomotion lower bound permits both bodies to move directly at full derived speed, ignoring terrain/turn/acceleration, and subtracts full hull circumscribed radius + patient radius + native boarding gap. It does not claim a bound after future stat changes, abilities or externally forced displacement.'
write('geometry-owner-query.json',q)
write('speed-cap-audit.json',{
 'classification':'Read-only native source audit and scan of all 40 already-closed reconstructed input samples; no new simulation.',
 'samples':inputs,'derivedSpeeds':{k:sorted(v) for k,v in caps.items()},'effects':effects,'pushVelocities':push,'carriedItems':items,'p0VeteranSkills':skills,
 'nativeRules':[
  {'file':'src/shared/sim.ts','line':3557,'finding':'Unit.speed is derived from weapon/base rules, upgrade speed multiplier, equipped speedBoots, heavy-item penalty and veteran frame moveSpeedMultiplier. Snapshot values already include these.'},
  {'file':'src/shared/sim.ts','line':4531,'finding':'Normal moveToward uses statusPace <=1; walkToward multiplies derived unit.speed by status pace and CELL_GROUND pace <=1.'},
  {'file':'src/shared/ship-handling.ts','line':21,'finding':'Current empty full-rigging carrier has native limits.speed=54; loading and damage can only reduce this relative to derived unit.speed.'},
  {'file':'src/shared/ship-wind.ts','line':103,'finding':'windDrive=sqrt(min(1,wind/default)) and polar knots <=1, so wind drive cannot exceed limits.speed.'},
  {'file':'src/shared/ship-motion.ts','line':42,'finding':'advanceShip total surge + pivot-yaw path budget is capped at limits.speed/20 per tick; a heading change cannot add free travel.'}
 ],
 'limits':['The 54+76 bound is for current native ordinary locomotion and current derived stats, not a universal bound on future buffs, charge/teleport abilities or external displacement.','No effects, push velocities, carried items or p0 veteran skills were observed in these 15-tick samples. Absence in samples is not a claim of an every-frame audit.','The actual native hit stream and full input show both patients retained board without deck, charge, abilities, equipment or paid research in the decisive window.'],
 'boundFormula':'ceil(max(0, ship-patient center distance - native full hull circumscribed radius - patient radius - BOARDING_GAP)/(ship native max speed + patient derived speed)*20)'
})

replay=json.load((D/'coastal-replay-22200-22800.json').open())
term=[r for r in streams['ordinary0-native-events.jsonl'] if r['type']=='native-unit-terminal']
hits=streams['ordinary0-native-hits.jsonl']
sourcefiles=['src/shared/sim.ts','src/shared/ship-motion.ts','src/shared/ship-handling.ts','src/shared/ship-wind.ts','src/shared/terrain.ts','src/ai/policy/naval.ts','src/ai/policy/script-runner.ts','src/ai/bootstrap_1/expedition-recovery.ts','src/ai/bootstrap_1/worker-boarding.ts','src/ai/bootstrap_1/landed-combat.ts','src/ai/bootstrap_1/land-recovery.ts','src/ai/bootstrap_1/policy.ts']
write('FINAL-READONLY-AUDIT.json',{
 'classification':'Independent read-only causal audit of the ongoing root 0f5bf true ordinary0 holdout. No production source edits, tests, replay, new game, command publication or claimed full-match outcome.',
 'source':str(S),'head':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip(),
 'sourceStatusAtClose':subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True),
 'reviewedSourceFiles':{p:sha(S/p) for p in sourcefiles},
 'setup':{'p0':'Ember v9_summoner, side1 team a','p1':'Grove frozen v5 team b','p2':'Ember frozen v7 team b','eachResources':'500 gold / 3 workers / 8 supply cap','rulesVersion':2,'frozenFiles':184,'factory':'sapphireArchipelago --unseen, actual map.id=ladder','seed':'bootstrap_1-resume-holdout-summoner-v5-v7-20261016-01'},
 'existingProof':{'path':str(D/'coastal-replay-22200-22800.json'),'sha256':sha(D/'coastal-replay-22200-22800.json'),'restore':replay['restore'],'comparison':replay['comparison'],'commands':replay['expectedCommandCount'],'hits':replay['expectedHitCount'],'preflight':replay['preflight'],'postflight':replay['postflight']},
 'observed':{
  'firstPublicBoard':[{'tick':r['tick'],'owner':r['owner'],'scriptId':r.get('scriptId'),'command':r['command']} for r in streams['ordinary0-public-commands.jsonl']],
  'firstIncomingHits':{i:min(r['tick'] for r in hits if r['target']==i) for i in ids},
  'outgoingNativeHitsForThesePatientsInOriginalBoundedStream':[r for r in hits if r['attacker'] in ids],
  'permanentTerminalEvents':term,
  'missionFrom':q['rows'][0]['mission']['from'],'sharedNativeShore':q['rows'][0]['patients'][0]['order']['berth']['shore'],
  'boatMovesInsteadOfBeingStuck':{'at22335':q['rows'][0]['boat']['position'],'at22515':q['rows'][3]['boat']['position'],'speed':10.8,'causeAtThoseSamples':'native square-rig current course is in no-go: trueWindAngle 0.0705267 < 0.837758; auxiliarySpeed=10.8'},
  '22515':{'boatRemainingNativeCourse':q['rows'][3]['boat']['courseLength'],'pointSeaRoad':q['rows'][3]['boat']['seaPointRoadToBerth'],'geometricFullSpeedToExactPoseTicks':q['rows'][3]['boat']['exactPoseTravelAtFullSpeedTicks'],'notAnEarliestBoardingETA':True,'patients':[{'id':p['id'],'hp':p['hp'],'cooldown':p['cooldown'],'nativeOrder':p['order']['type'],'alongside':p['alongside'],'currentLocomotionOptimisticAlongsideLowerBoundTicks':p['currentLocomotionOptimisticAlongsideLowerBoundTicks']} for p in q['rows'][3]['patients']]},
  'visualPersonallyViewed':str(D/'ordinary0-observer-22800-colony-northwest-evacuation.png')
 },
 'causalFinding':'The evacuation planner recruits permanent land fighters at a distant native shared boarding shore and retains their native board orders while native pickup cannot arrive in the actual lethal contact window. Those orders suppress ordinary attack acquisition, autocast and retaliation; the naval owner excludes existing boarders from local combat and wounded recovery. This is a concrete loss of fighting/retreat agency, not proof a canceled board would win or save the patient.',
 'ownershipContracts':[
  {'file':'src/ai/policy/naval.ts','line':844,'finding':'evacuate/rebase recruitment bypasses troopAvailable, which only applies to assault. All soldiers still pass real packing and same-ground checks.'},
  {'file':'src/ai/policy/naval.ts','line':861,'finding':'evacuate explicitly bypasses local retained-strength requirement; crewIds are appended and public board is issued.'},
  {'file':'src/ai/policy/naval.ts','line':627,'finding':'native board or ferry crewIds is enough for naval ownership. Actual claims query for both patients returns only naval.'},
  {'file':'src/ai/policy/script-runner.ts','line':57,'finding':'Other scripts cannot move/attack units claimed elsewhere and unrelated tactics also filter actual boarders.'},
  {'file':'src/ai/bootstrap_1/expedition-recovery.ts','line':23,'finding':'Expedition recovery excludes order.board; its existing safety release loop at line40 is worker-only.'},
  {'file':'src/ai/bootstrap_1/landed-combat.ts','line':29,'finding':'Naval-owned local combat excludes existing boarders; newly published boarders are also made unavailable.'},
  {'file':'src/shared/sim.ts','line':1455,'finding':'Native shore board only advances boarding and continues out of the ordinary combat path. Native retaliatory takeUpAttacker accepts idle/attackMove/self-directed attack, not board; autocast order set also excludes board.'}
 ],
 'diagnosticAlternativeLimits':[
  'Passing actual boarders into the existing generic landRecoveryAssignments helper, bypassing only its caller filter, yields an unmedicated cover for 5447 at22455 and22515 and for5665 at22650. It was never published or simulated.',
  'Replacing just the two native board orders with idle in a cloned snapshot still produces no planLandedCombat commands for them. Therefore canceling board does not imply this combat module will immediately issue defense.',
  'Native idle/hold ordinary combat would permit reachable attacks and native retaliation; at22515 patient5447 has cooldown0 and native canReach=true, strikeGap49.354<=attackRange52 against enemy1469. No alternative outcome has been measured.',
  'Existing worker3640 safety release and avoidance commands are real in the closed input/output; they do not protect nonworker land soldiers.'
 ],
 'gaps':['21885 has an original public board command but no complete live beforeUnit or full checkpoint; nearest earlier full input21600 and later22200. No new21885 reconstruction was performed.','22335 and22515 inputs are complete reconstructed pre-p0 inputs backed by the existing exact native600-tick closure, not original live captures.','No changed-code candidate or natural match result is attributed to this audit. The original true0 continues under stable_review.','The earlier broken-container uncommitted-source recovery gap remains unchanged.']
})

write('INDEX.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.iterdir()) if p.is_file() and p.name not in {'INDEX.json'}}})
print(json.dumps({'output':str(O),'auditSHA256':sha(O/'FINAL-READONLY-AUDIT.json'),'files':len(list(O.iterdir()))}))
