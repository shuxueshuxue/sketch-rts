import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { shipProfile } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/ship-geometry.ts';
import { shipMotionLimits } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/ship-handling.ts';
import { coursePerformance } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/ship-wind.ts';
import { strikeGap } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/combat-geometry.ts';
import { alongside, canReach, BOARDING_GAP } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/naval.ts';
import { groundSteeringRoute } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/route-selection.ts';
import { sameGround, walkingDistance } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/terrain.ts';
import { unitMover } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/shared/catalog.ts';
import { landRecoveryAssignments } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/ai/bootstrap_1/land-recovery.ts';
import { expeditionRecoveryUnitIds } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/ai/bootstrap_1/expedition-recovery.ts';
import { planLandedCombat } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/ai/bootstrap_1/landed-combat.ts';
import { bootstrapScripts, bootstrapPolicyContext } from '/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control/src/ai/bootstrap_1/policy.ts';

const D='/workspace/.playtest/bootstrap-summoner-v5-v7-holdout-0f5bf-20261016';
const OUT='/workspace/.playtest/evacuation-owner-independent-review';
const sha=(value:any)=>crypto.createHash('sha256').update(typeof value==='string'?value:JSON.stringify(value)).digest('hex');
const dist=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
const pids=['unit-p0-emberRavager-5447','unit-p0-emberRavager-5665'];
const rows:any[]=[];
for(const tick of [22335,22425,22455,22515,22650]) {
 const input=`${D}/coastal-replay-22200-22800.inputs/${tick}-p0.json.gz`;
 const raw=fs.readFileSync(input),d=JSON.parse(zlib.gunzipSync(raw).toString()),s=d.snapshot;
 const original=sha(d),boat=s.units.find((u:any)=>u.id==='unit-p0-carrier-5362');
 const profile=shipProfile(boat)!,lim=shipMotionLimits(boat);
 const hullExtent=Math.max(...profile.hull.map(p=>Math.hypot(p.x,p.y)));
 const opts=()=>bootstrapPolicyContext(s,'p0','v9_summoner',{version:'v9_summoner',teams:d.plannerContext.teams,memory:structuredClone(d.memories.p0)});
 const mission=d.memories.p0.naval.ferries[boat.id];
 const home=s.buildings.find((b:any)=>b.owner==='p0'&&b.kind==='townHall');
 const land=s.units.filter((u:any)=>u.hp>0&&u.owner==='p0'&&!u.deck&&unitMover(u.kind)==='land'&&u.kind!=='worker'&&!sameGround(s.map,u,home));
 const actualRecovery=[...expeditionRecoveryUnitIds(s,'p0',opts())];
 const care=landRecoveryAssignments(s,'p0',opts(),land);
 const claims:any[]=[];
 for(const script of bootstrapScripts('v9_summoner')) {
  const ids=script.claimsUnits?.(s,'p0',opts());
  if(ids&&pids.some(id=>ids.has(id)))claims.push({script:script.id,ids:pids.filter(id=>ids.has(id))});
 }
 const actualLocal=planLandedCombat(s,'p0',opts(),new Set());
 // Diagnostic bypass only: this does not publish an order or run a simulation.
 const counter=structuredClone(s);
 for(const u of counter.units)if(pids.includes(u.id)&&u.order.type==='board')u.order={type:'idle'};
 const counterLocal=planLandedCombat(counter,'p0',opts(),new Set());
 const patients=s.units.filter((u:any)=>pids.includes(u.id)).map((u:any)=>{
  const shore=u.order.type==='board'?u.order.berth?.shore:undefined;
  const route=shore?groundSteeringRoute(s.map,u,shore):[];
  const roadLength=route.reduce((n:number,p:any,i:number)=>i?n+dist(route[i-1],p):n,0);
  return {id:u.id,hp:u.hp,maxHp:u.maxHp,cooldown:u.cooldown,order:u.order,nodeck:!u.deck,position:{x:u.x,y:u.y},alongside:alongside(u,boat),
   actualGroundRoadToSharedShore:route,roadLength,
   currentLocomotionOptimisticAlongsideLowerBoundTicks:Math.ceil(Math.max(0,dist(boat,u)-hullExtent-u.radius-BOARDING_GAP)/(lim.speed+u.speed)*20),
   earliestPossibleAlongsideIfPatientWaitsAtSharedShoreTicks:shore?Math.ceil(Math.max(0,dist(boat,shore)-hullExtent-u.radius-BOARDING_GAP)/lim.speed*20):null,
   actualRecoveryClaimed:actualRecovery.includes(u.id),
   enemies:s.units.filter((e:any)=>e.hp>0&&e.owner==='p2'&&['unit-p2-emberRavager-1469','unit-p2-cutter-2682'].includes(e.id)).map((e:any)=>({id:e.id,hp:e.hp,deck:e.deck??null,position:{x:e.x,y:e.y},order:e.order,attackRange:e.attackRange,cooldown:e.cooldown,strikeGap: strikeGap(u,e),canReach:canReach(s.map,u,e,s.units),enemyCanReach:canReach(s.map,e,u,s.units),enemyStrikeGap:strikeGap(e,u),sameLand: sameGround(s.map,u,e)}))};
 });
 const points=boat.sailing.route.points;
 let previous:any=boat,courseLength=0;
 const legs=points.map((point:any)=>{
   let length=dist(previous,point),kind='straight';
   if(point.pivot){
    const radius=dist(previous,point.pivot),a=Math.atan2(previous.y-point.pivot.y,previous.x-point.pivot.x),b=Math.atan2(point.y-point.pivot.y,point.x-point.pivot.x);
    const turn=Math.abs(((b-a+Math.PI*3)%(2*Math.PI))-Math.PI);length=radius*turn;kind='pivot-arc';
   }
   courseLength+=length;previous=point;return{kind,length,to:point};
 });
 rows.push({tick,input,inputSHA256:crypto.createHash('sha256').update(raw).digest('hex'),checkpointClassification:d.classification,effectivePolicyVersion:opts().version,requestedPolicyVersion:opts().requestedVersion,
  boat:{position:{x:boat.x,y:boat.y},order:boat.order,heading:boat.sailing.heading,speed:boat.sailing.speed,sail:boat.sailing.sail,limits:lim,hullExtent,boatRoute:boat.sailing.route,
   seaPointRoadToBerth:walkingDistance(s.map,boat,boat.sailing.route.end,'sea'),courseLegs:legs,courseLength,
   exactPoseTravelAtFullSpeedTicks:Math.ceil(courseLength/lim.speed*20),currentSpeedExtrapolationToExactPoseTicks:Math.ceil(courseLength/boat.sailing.speed*20),
   currentCoursePerformance:coursePerformance(boat,s.map),trimmedCoursePerformance:coursePerformance(boat,s.map,boat.sailing.heading,{assumeTrimmed:true})},
  mission,patients,claims,
  actualLocalCommands:actualLocal.filter(c=>'unitIds'in c&&c.unitIds.some(id=>pids.includes(id))),
  diagnosticIncludingBoardersInGenericCareOnly:{unmedicated:care.unmedicated.filter(p=>pids.includes(p.patient.id)).map(p=>({patient:p.patient.id,cover:p.cover,threats:p.threats.map(f=>f.id)})),recovering:care.recovering.filter(p=>pids.includes(p.patient.id)).map(p=>({patient:p.patient.id,healer:p.healer.id}))},
  diagnosticReplacingOnlyTheirNativeBoardOrderWithIdleWithoutIssuingCommand:counterLocal.filter(c=>'unitIds'in c&&c.unitIds.some(id=>pids.includes(id))),
  originalInputAndAllThreeMemoriesUnchanged:sha(d)===original});
}
fs.writeFileSync(`${OUT}/geometry-owner-query.json`,JSON.stringify({classification:'Pure read-only geometry and cloned-memory policy queries on already-closed reconstructed input snapshots; no createGame, step, command publication or new match. Diagnostic bypasses are explicit counterfactual module queries, not observed commands or candidate validation.',source:'/tmp/sketch-rts-summoner-v5-v7-holdout-0f5bf-control',head:'0f5bf01a05046169d4fb42322376f767b97bcc83',timeUnits:'20 ticks per second',boundaries:['Exact-pose route time is not the earliest boarding time: boarding can occur alongside before final berth.','Current native locomotion lower bound permits both bodies to move directly at full derived speed, ignoring terrain/turn/acceleration, and subtracts full hull circumscribed radius + patient radius + native boarding gap. It does not claim a bound after future stat changes, abilities or externally forced displacement.','Shared-shore waiting bound assumes the patient stays at that shore.','Observed speed extrapolation is not a promised future ETA.','Pure idle-order and care-caller bypasses do not prove a retreat/combat outcome.'],rows},null,2));
console.log(JSON.stringify({rows:rows.map(r=>({tick:r.tick,course:r.boat.courseLength,speed:r.boat.speed,fullSpeedTicks:r.boat.exactPoseTravelAtFullSpeedTicks,claims:r.claims,patients:r.patients.map((p:any)=>({id:p.id,hp:p.hp,lowerBound:p.currentLocomotionOptimisticAlongsideLowerBoundTicks,waitingBound:p.earliestPossibleAlongsideIfPatientWaitsAtSharedShoreTicks,enemies:p.enemies})),care:r.diagnosticIncludingBoardersInGenericCareOnly,actualLocal:r.actualLocalCommands,counterLocal:r.diagnosticReplacingOnlyTheirNativeBoardOrderWithIdleWithoutIssuingCommand,unchanged:r.originalInputAndAllThreeMemoriesUnchanged}))}));
