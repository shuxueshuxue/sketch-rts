import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';

const D = '/workspace/.playtest/bootstrap-knight-repair-origin-20261015';
const W = '/workspace/sketch-rts-repair-origin-control';
const O = '/tmp/sketch-rts-knight-escort-transfer-v2-control';
const sha = (file: string) => createHash('sha256').update(readFileSync(file)).digest('hex');
const candidateCap = JSON.parse(readFileSync(`${D}/origin-source.json`, 'utf8'));
const oldCap = JSON.parse(readFileSync('/tmp/bootstrap-deployment-gate/knight-escort-transfer-v2-source.json', 'utf8'));
const archive = '/workspace/.playtest/bootstrap-knight-repair-origin-v1-evidence.tar.gz';
const archiveSHA = '5cc4eb9a6600514147072429505226abd9390517ac791fdc305d2aacf19ad30a';
function sourceCheck(root: string, cap: any) {
  const mismatches = Object.entries(cap.files).filter(([file, hash]) => sha(`${root}/${file}`) !== hash).map(([file]) => file);
  assert.deepEqual(mismatches, []);
  return { files: Object.keys(cap.files).length, mismatches };
}
const preflight = { candidate: sourceCheck(W, candidateCap), oldFixedV2: sourceCheck(O, oldCap), archiveSHA256: sha(archive) };
assert.equal(preflight.archiveSHA256, archiveSHA);
const rawTrace = JSON.parse(readFileSync(`${D}/paired-native-routes.json`, 'utf8'));
const trace = rawTrace.rows.find((row: any) => row.variant === 'old' && row.tick === 68400 && row.id === 'unit-p0-cutter-1139');
assert.ok(trace);
const translation = trace.originCalls.find((call: any) => call.from.x === 9136 && call.from.y === 5296 && call.from.heading === 0 && call.to.x === 9104 && call.to.y === 5296 && call.to.heading === 0);
const rotation = trace.originCalls.find((call: any) => call.from.x === 9136 && call.from.y === 5296 && call.from.heading === Math.PI / 4 && call.to.x === 9136 && call.to.y === 5296 && call.to.heading === Math.PI / 2);
assert.ok(translation);
assert.ok(rotation);
const captured = [{ kind: 'translation', call: translation }, { kind: 'in-place rotation', call: rotation }];
for (const { call } of captured) {
  assert.equal(Object.hasOwn(call, 'padding'), false);
  assert.equal(call.accepted, true);
  assert.equal(call.live, false);
}
const fixture = `${W}/src/shared/fixtures/knight-repair-origin-68400.json.gz`;
const rows: any[] = [];
for (const [label, root] of Object.entries({ oldFixedV2: O, candidate: W })) {
  const imp = (p: string) => import(pathToFileURL(`${root}/${p}`).href);
  const [{ setBuildingBodies }, { reservationTraffic, shipTraffic }, { headingDifference }] = await Promise.all([
    imp('src/shared/terrain.ts'), imp('src/shared/ship-avoidance.ts'), imp('src/shared/ship-navigation.ts'),
  ]);
  const saved = JSON.parse(gunzipSync(readFileSync(fixture)).toString());
  const snapshot = saved.snapshot;
  setBuildingBodies(snapshot.map, [...snapshot.buildings, ...(snapshot.obstacles ?? [])]);
  const ship = snapshot.units.find((unit: any) => unit.id === trace.id);
  const origin = { x: ship.x, y: ship.y, heading: ship.sailing.heading };
  assert.deepEqual(origin, trace.start);
  const before = JSON.stringify(snapshot);
  const reserved = reservationTraffic(ship, snapshot.units);
  const live = shipTraffic(ship, snapshot.units);
  const vectors = captured.map(({ kind, call }) => {
    const { from, to } = call;
    const actual = reserved(from, to); // Preserve actual omitted padding.
    const liveResult = live(from, to);
    const originDistance = Math.hypot(from.x - origin.x, from.y - origin.y);
    const headingDelta = headingDifference(origin.heading, from.heading);
    assert.equal(liveResult, false);
    assert.equal(actual, label === 'oldFixedV2');
    assert.ok(originDistance > 0 && originDistance <= 1e-7);
    assert.ok(Math.abs(headingDelta) > 1e-7);
    return { kind, from, to, padding: 'omitted (undefined)', originDistance, yDelta: from.y - origin.y,
      exactXY: from.x === origin.x && from.y === origin.y, headingDelta,
      originalCapturedPlanned: call.accepted, originalCapturedLive: call.live,
      reservationTraffic: actual, liveTraffic: liveResult,
      exactXYGuardMutantWouldReturn: call.accepted && (!(from.x === origin.x && from.y === origin.y) || liveResult),
      sameHeadingGuardMutantWouldReturn: call.accepted && (originDistance > 1e-7 || Math.abs(headingDelta) > 1e-7 || liveResult) };
  });
  assert.equal(JSON.stringify(snapshot), before);
  rows.push({ variant: label, sourceRoot: root, origin, hasTraffic: reserved.hasTraffic, worldUnchanged: true, vectors });
}
const postflight = { candidate: sourceCheck(W, candidateCap), oldFixedV2: sourceCheck(O, oldCap), archiveSHA256: sha(archive) };
assert.equal(postflight.archiveSHA256, archiveSHA);
const result = { classification: 'Separate read-only supplement after immutable package sealing. Exact captured native planShipRoute callbacks from real 68400 full fixture, directly verified through old and candidate reservationTraffic. Not a simulation, selected route assertion, or source/test mutation.',
  fixture, fixtureSHA256: sha(fixture), rawNativeTrace: `${D}/paired-native-routes.json`, rawNativeTraceSHA256: sha(`${D}/paired-native-routes.json`),
  helper: `${D}/verify-boundary-vectors.mts`, helperSHA256: sha(`${D}/verify-boundary-vectors.mts`), tick: 68400, shipId: trace.id,
  parentRegressionAdvice: 'Call reservationTraffic on these captured from/to values with padding omitted; assert false. This pins rounded-XY and different-heading origin edges directly. Keep existing four full route/sweep tests. No claim that these are chosen final-route edges.',
  preflight, rows, postflight };
writeFileSync(`${D}/boundary-vectors-verified.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ output: `${D}/boundary-vectors-verified.json`, rows, preflight, postflight }, null, 2));
