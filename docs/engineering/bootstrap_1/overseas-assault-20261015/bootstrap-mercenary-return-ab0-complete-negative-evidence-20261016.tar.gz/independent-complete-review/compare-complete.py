#!/usr/bin/env python3
"""Offline comparison of existing JSON/gzip frames and native ledgers; never runs RTS code."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path


def read_json(path):
    with (gzip.open(path, 'rt') if str(path).endswith('.gz') else open(path)) as handle:
        return json.load(handle)


def read_jsonl(path):
    with open(path) as handle:
        return [json.loads(line) for line in handle if line.strip()]


def digest(path):
    with open(path, 'rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def path_for(prefix, suffix):
    return Path(str(prefix) + suffix)


def hit_brief(row):
    return None if row is None else {key: row.get(key) for key in (
        'tick', 'attacker', 'attackerKind', 'target', 'targetKind', 'damage', 'hpBefore', 'hpAfter')}


def death_brief(row):
    if row is None:
        return None
    unit = row['previous']
    return {'tick': row['tick'], 'id': row['id'], 'kind': unit['kind'], 'level': unit.get('level'),
            'xp': unit.get('xp'), 'kills': unit.get('kills'), 'x': unit['x'], 'y': unit['y'],
            'order': unit['order'], 'confirmation': row.get('confirmation'),
            'fatalHit': hit_brief(row.get('lastNativeHit'))}


def terminal_deaths(rows):
    # Status updates confirm a prior observation and are not additional deaths.
    return [row for row in rows if row['type'] == 'native-unit-terminal' and row.get('permanent')
            and not row.get('evidence', {}).get('expiryEligible')]


def doctor_evidence(hits, commands, doctor_ids, after_tick):
    result = {}
    for unit_id in doctor_ids:
        outgoing = [row for row in hits if row['tick'] > after_tick and row['attacker'] == unit_id]
        incoming = [row for row in hits if row['tick'] > after_tick and row['target'] == unit_id]
        recoveries = []
        for previous, following in zip(incoming, incoming[1:]):
            old_max = (previous.get('targetAtObservation') or {}).get('maxHp')
            new_max = (following.get('targetAtObservation') or {}).get('maxHp')
            if previous['hpAfter'] > 0 and old_max is not None and old_max == new_max and following['hpBefore'] > previous['hpAfter']:
                recoveries.append({'afterTick': previous['tick'], 'byTick': following['tick'],
                                   'fromHP': previous['hpAfter'], 'toHP': following['hpBefore'],
                                   'sameEndpointMaxHP': old_max, 'netHPGain': following['hpBefore'] - previous['hpAfter']})
        casts = [row for row in commands if row['tick'] > after_tick and row['command'].get('type') == 'cast'
                 and row['command'].get('unitId') == unit_id and row['command'].get('ability') == 'heal']
        result[unit_id] = {
            'outgoingHitCount': len(outgoing), 'reportedOutgoingDamage': sum(row['damage'] for row in outgoing),
            'outgoingPositiveHPRemoved': sum(min(max(row['hpBefore'], 0), row['damage']) for row in outgoing),
            'incomingHitCount': len(incoming), 'reportedIncomingDamage': sum(row['damage'] for row in incoming),
            'incomingPositiveHPRemoved': sum(min(max(row['hpBefore'], 0), row['damage']) for row in incoming),
            'firstIncomingHit': hit_brief(incoming[0]) if incoming else None,
            'lastIncomingHit': hit_brief(incoming[-1]) if incoming else None,
            'observedHPRecoveriesBetweenHits': recoveries,
            'observedNetHPGainBetweenHits': sum(row['netHPGain'] for row in recoveries),
            'acceptedHealCastCount': len(casts),
            'acceptedHealTargetCounts': dict(sorted(Counter(row['command'].get('targetId') for row in casts).items())),
            'firstAcceptedHealCast': casts[0] if casts else None,
            'limit': 'HP gains establish recipient recovery between actual hits, not its caster. Equal endpoint maxHP does not reconstruct every intervening tick. Accepted casts are not counted as healed HP; absence of HP regain after this doctor is hit says nothing about healing it gave another unit.',
        }
    return result


def player_state(snapshot, owner, deaths):
    own = [unit for unit in snapshot['units'] if unit['owner'] == owner and unit['hp'] > 0]
    permanent = [unit for unit in own if unit.get('expiresTick') is None]
    army = [unit for unit in permanent if unit['kind'] != 'worker']
    buildings = [building for building in snapshot['buildings'] if building['owner'] == owner and building['hp'] > 0]
    player = snapshot['players'][owner]
    return {
        'gold': player['gold'], 'goldSpent': snapshot['match']['stats']['goldSpent'][owner],
        'workers': sum(unit['kind'] == 'worker' for unit in permanent),
        'workerOrders': dict(sorted(Counter(unit['order']['type'] for unit in permanent if unit['kind'] == 'worker').items())),
        'supplyUsed': player['supplyUsed'], 'supplyCap': player['supplyCap'], 'upgrades': player['upgrades'],
        'completeHalls': [{'id': building['id'], 'hp': building['hp'], 'x': building['x'], 'y': building['y']}
                          for building in buildings if building['kind'] == 'townHall' and building['complete']],
        'completeBuildings': dict(sorted(Counter(building['kind'] for building in buildings if building['complete']).items())),
        'permanentArmy': dict(sorted(Counter(unit['kind'] for unit in army).items())),
        'permanentArmyCount': len(army), 'permanentArmyHP': round(sum(unit['hp'] for unit in army), 3),
        'temporaryUnitCount': len(own) - len(permanent),
        'medics': [{key: unit.get(key) for key in ('id', 'kind', 'hp', 'maxHp', 'level', 'xp', 'x', 'y', 'order')}
                   for unit in army if unit['kind'] in ('fieldMedic', 'priest')],
        'nativeUnitsLost': snapshot['match']['stats']['unitsLost'][owner],
        'permanentDeathObservations': sum(row['tick'] <= snapshot['tick'] and row['previous']['owner'] == owner for row in deaths),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-prefix', type=Path, default=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game'))
    parser.add_argument('--candidate-dir', type=Path, default=Path('/workspace/.playtest/bootstrap-mercenary-return-roads-20261016'))
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    baseline, candidate, out = args.baseline_prefix, args.candidate_dir, args.output_dir
    if out.resolve() in (baseline.parent.resolve(), candidate.resolve()):
        raise ValueError('Output must be an independent directory, never an input package.')
    out.mkdir(parents=True, exist_ok=True)
    episode, tail = candidate / 'candidate-return-episode', candidate / 'candidate-complete-tail'
    bm, em, cm = (read_json(path_for(prefix, '.json')) for prefix in (baseline, episode, tail))
    switch_tick = 13764
    checkpoint_path = Path(em['input'])
    checkpoint = read_json(checkpoint_path)
    initial = checkpoint['snapshot']
    assert initial['tick'] == switch_tick
    assert em['head'] == cm['head'] and em['result']['tick'] == 14101
    assert cm['input'] == str(path_for(episode, '-terminal.json.gz'))
    raw_bd = read_jsonl(path_for(baseline, '-native-deaths.jsonl'))
    raw_cd = read_jsonl(path_for(episode, '-native-deaths.jsonl')) + read_jsonl(path_for(tail, '-native-deaths.jsonl'))
    bd = terminal_deaths(raw_bd)
    cd = [row for row in bd if row['tick'] <= switch_tick] + terminal_deaths(raw_cd)
    assert all(row['tick'] > switch_tick for row in terminal_deaths(raw_cd))
    be = read_jsonl(path_for(baseline, '-native-events.jsonl'))
    ce = read_jsonl(path_for(episode, '-native-events.jsonl')) + read_jsonl(path_for(tail, '-native-events.jsonl'))
    all_bh = read_jsonl(path_for(baseline, '-native-hits.jsonl'))
    all_ch = [row for prefix in (episode, tail) for row in read_jsonl(path_for(prefix, '-native-hits.jsonl'))]
    bh = [row for row in all_bh if row['tick'] >= 13770]
    ch = [row for row in all_ch if row['tick'] >= 13770]
    bc = read_jsonl(path_for(baseline, '-commands.jsonl'))
    cc = [row for prefix in (episode, tail) for row in read_jsonl(path_for(prefix, '-commands.jsonl'))]
    comparison_keys = ('tick', 'attacker', 'target', 'damage', 'hpBefore', 'hpAfter')
    first_hit_difference = next(({'position': index, 'baseline': hit_brief(left), 'candidate': hit_brief(right)}
                                 for index, (left, right) in enumerate(zip(bh, ch))
                                 if any(left.get(key) != right.get(key) for key in comparison_keys)), None)
    metrics, inputs = [], [checkpoint_path]
    for tick in (14400, 16200, 17400, 18600, 24000, 30000):
        row = {'tick': tick}
        for label, prefix, deaths in (('baseline', baseline, bd), ('candidate', tail, cd)):
            path = path_for(prefix, f'.frames/{tick}.json.gz')
            snapshot = read_json(path)['snapshot']
            assert snapshot['tick'] == tick
            row[label] = {owner: player_state(snapshot, owner, deaths) for owner in ('p0', 'p1', 'p2')}
            inputs.append(path)
        metrics.append(row)
    finals = {}
    final_units = {}
    for label, prefix, manifest, deaths in (('baseline', baseline, bm, bd), ('candidate', tail, cm, cd)):
        path = path_for(prefix, f".frames/{manifest['result']['tick']}.json.gz")
        snapshot = read_json(path)['snapshot']
        final_units[label] = {unit['id']: unit for unit in snapshot['units'] if unit['hp'] > 0}
        finals[label] = {'tick': snapshot['tick'], 'winner': snapshot['match']['winner'],
                         'players': {owner: player_state(snapshot, owner, deaths) for owner in ('p0', 'p1', 'p2')}}
        inputs.append(path)
    bdeath = {row['id']: row for row in bd}
    cdeath = {row['id']: row for row in cd}
    original_own = {unit['id']: unit for unit in initial['units'] if unit['owner'] == 'p0' and unit['hp'] > 0}
    tracked = {unit_id for unit_id, unit in original_own.items()
               if unit['kind'] != 'worker' and (unit.get('xp', 0) > 0 or unit['kind'] in ('fieldMedic', 'priest'))}
    tracked_rows = []
    for unit_id in sorted(tracked):
        unit = original_own[unit_id]
        tracked_rows.append({'id': unit_id, 'at13764': {key: unit.get(key) for key in ('kind', 'hp', 'level', 'xp', 'kills')},
                             'baselineDeath': death_brief(bdeath.get(unit_id)), 'candidateDeath': death_brief(cdeath.get(unit_id)),
                             'baselineTerminalAlive': unit_id in final_units['baseline'],
                             'candidateTerminalAlive': unit_id in final_units['candidate']})
    earlier_existing_losses = [row for row in cd if row['tick'] >= 13770 and row['id'] in original_own
                               and (row['id'] not in bdeath or row['tick'] < bdeath[row['id']]['tick'])]
    earlier_existing_losses.sort(key=lambda row: row['tick'])
    bbuild = {row['previous']['id']: row for row in be if row['type'] == 'native-building-terminal'}
    own_buildings = {building['id'] for building in initial['buildings'] if building['owner'] == 'p0'}
    earlier_buildings = []
    for row in ce:
        if row['type'] != 'native-building-terminal' or row['previous']['id'] not in own_buildings:
            continue
        prior = bbuild.get(row['previous']['id'])
        if prior is None or row['tick'] < prior['tick']:
            earlier_buildings.append({'id': row['previous']['id'], 'kind': row['previous']['kind'],
                                      'candidateTick': row['tick'], 'baselineTick': None if prior is None else prior['tick'],
                                      'candidateFatalHit': hit_brief(row.get('lastNativeHit'))})
    own_bd = [row for row in bd if row['previous']['owner'] == 'p0']
    own_cd = [row for row in cd if row['previous']['owner'] == 'p0']
    first_loss_count_excess = next(({'tick': row['tick'], 'baseline': sum(item['tick'] <= row['tick'] for item in own_bd),
                                     'candidate': sum(item['tick'] <= row['tick'] for item in own_cd), 'unit': death_brief(row)}
                                    for row in sorted(own_cd, key=lambda row: row['tick']) if row['tick'] > switch_tick
                                    and sum(item['tick'] <= row['tick'] for item in own_cd) > sum(item['tick'] <= row['tick'] for item in own_bd)), None)
    provenance_paths = [path_for(prefix, suffix) for prefix in (baseline, episode, tail)
                        for suffix in ('.json', '-native-hits.jsonl', '-native-deaths.jsonl', '-native-events.jsonl', '-commands.jsonl')]
    doctor_ids = ('unit-p0-fieldMedic-2255', 'unit-p0-fieldMedic-1907', 'unit-p0-priest-3733', 'unit-p0-priest-5844')
    effect_witnesses = {'baseline': [], 'candidate': []}
    for label, prefix, suffixes in (
            ('baseline', baseline, ('.events/16141-after-step-66.json.gz', '.frames/16200.json.gz')),
            ('candidate', tail, ('.events/17092-after-step-16.json.gz', '.events/15632-after-step-4.json.gz', '.events/15896-after-step-7.json.gz'))):
        for suffix in suffixes:
            path = path_for(prefix, suffix)
            snapshot = read_json(path)['snapshot']
            inputs.append(path)
            for effect in snapshot['effects']:
                if effect['type'] == 'heal' and effect.get('sourceId') in doctor_ids:
                    effect_witnesses[label].append({'framePath': str(path), 'observedTick': snapshot['tick'], 'effect': effect})
    report = {
        'classification': 'Offline review of recorded complete games: e566 ordinary0 versus ab0 code-switched continuation from its actual13764 state. Not a candidate ordinary0 or unseen validation.',
        'provenance': {'baselineHead': bm['head'], 'candidateHead': cm['head'], 'candidateBase': cm['base'],
                       'switchTick': switch_tick, 'continuationBoundary': em['result']['tick'], 'setup': bm['setup'],
                       'episodeAllMandatoryExact': em['allMandatoryExact'], 'tailAllMandatoryExact': cm['allMandatoryExact'],
                       'inputs': [{'path': str(path), 'sha256': digest(path)} for path in dict.fromkeys(inputs + provenance_paths)]},
        'metricDefinitions': {'permanentArmy': 'Live units without expiresTick, excluding workers; ships remain included by kind.',
                              'permanentDeathObservations': 'Unique native-unit-terminal observations marked permanent, excluding expiry; status updates do not add deaths. Candidate cumulative ledger inherits baseline through13764.',
                              'gold': 'Actual recorded available gold and cumulative goldSpent; no claim that either is a mining-rate measurement.',
                              'healing': 'No accepted cast is counted as HP restored. Doctor-specific native HP/effect evidence is reviewed separately.',
                              'finalComparison': 'Terminal snapshots have different ticks and are reported separately.'},
        'commonTickMetrics': metrics, 'terminals': finals,
        'firstNativeHitDifference': first_hit_difference,
        'earlierExistingBuildingLosses': earlier_buildings,
        'candidateTownHallDeathTimeline': [{'tick': row['tick'], 'id': row['previous']['id'], 'fatalHit': hit_brief(row.get('lastNativeHit'))}
                                          for row in ce if row['type'] == 'native-building-terminal'
                                          and row['previous']['owner'] == 'p0' and row['previous']['kind'] == 'townHall'],
        'firstEarlierExistingUnitLoss': None if not earlier_existing_losses else {
            'candidate': death_brief(earlier_existing_losses[0]), 'baseline': death_brief(bdeath.get(earlier_existing_losses[0]['id']))},
        'firstCumulativeOwnPermanentLossExcess': first_loss_count_excess,
        'existingVeteransAndDoctors': tracked_rows,
        'doctorEvidenceAfter13764': {'baseline': doctor_evidence(all_bh, bc, doctor_ids, switch_tick),
                                   'candidate': doctor_evidence(all_ch, cc, doctor_ids, switch_tick)},
        'observedNativeHealEffectWitnesses': effect_witnesses,
        'limits': ['Observed branch differences do not isolate the return selector from the inherited a90 stop-ownership change.',
                   'First observed consequences are not an assertion of a single direct causal chain.',
                   'No new game, planner, native execution, tests, source mutation, or write into original evidence directories.'],
    }
    destination = out / 'comparison.json'
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    brief_metrics = []
    for row in metrics:
        entry = {'tick': row['tick']}
        for label in ('baseline', 'candidate'):
            state = row[label]['p0']
            entry[label] = {key: state[key] for key in ('gold', 'goldSpent', 'workers', 'permanentArmyCount', 'permanentDeathObservations')}
            entry[label]['completeHalls'] = len(state['completeHalls'])
            entry[label]['medics'] = len(state['medics'])
        brief_metrics.append(entry)
    doctor_summary = []
    for unit_id in doctor_ids:
        row = next(row for row in tracked_rows if row['id'] == unit_id)
        entry = {'id': unit_id}
        for label in ('baseline', 'candidate'):
            evidence = report['doctorEvidenceAfter13764'][label][unit_id]
            death = row[label + 'Death']
            entry[label] = {'deathTick': death['tick'], 'deathLevel': death['level'], 'deathXP': death['xp'],
                            **{key: evidence[key] for key in ('outgoingPositiveHPRemoved', 'incomingPositiveHPRemoved',
                                'observedNetHPGainBetweenHits', 'acceptedHealCastCount')}}
        doctor_summary.append(entry)
    review = {
        'verdict': 'Complete-match negative result: local return success and longer doctor survival did not preserve the baseline victory. This candidate continuation fails this developed-seed match.',
        'baseline': {'head': bm['head'], 'classification': 'ordinary0', 'tick': finals['baseline']['tick'],
                     'winner': finals['baseline']['winner'], 'p0PermanentDeaths': len(own_bd)},
        'candidate': {'head': cm['head'], 'base': cm['base'], 'classification': '13764 code-switched full3AI continuation, continued unchanged from14101',
                      'tick': finals['candidate']['tick'], 'winner': finals['candidate']['winner'], 'p0PermanentDeaths': len(own_cd)},
        'localGain': {'firstReturnOrderTick': em['goalHistory'][0]['tick'], 'goal': em['goalHistory'][0]['command'],
                      'releasedTick': em['actualReturnRelease']['tick'], 'actualHall': em['actualReturnRelease']['actualHomeId'],
                      'releaseCenterGap': em['actualReturnRelease']['actualCenterGap'],
                      'releaseHP': em['actualReturnRelease']['doctor']['hp'], 'medic2255ExtraSurvivalTicks': 17203 - 13964},
        'firstNativeHitDifference': first_hit_difference,
        'firstEarlierExistingBuildingLoss': earlier_buildings[0],
        'firstEarlierExistingUnitLoss': {'id': earlier_existing_losses[0]['id'], 'candidateTick': earlier_existing_losses[0]['tick'],
                                        'baselineTick': bdeath[earlier_existing_losses[0]['id']]['tick']},
        'firstCumulativeOwnPermanentLossExcess': {key: first_loss_count_excess[key] for key in ('tick', 'baseline', 'candidate')},
        'p0CommonTickSummary': brief_metrics,
        'doctorsAfter13764': doctor_summary,
        'actualHealingEvidence': {
            'recipient1907Candidate': report['doctorEvidenceAfter13764']['candidate']['unit-p0-fieldMedic-1907']['observedHPRecoveriesBetweenHits'],
            'candidate2255And3733': '17092 actual frame has source-tagged heal effects12188/12189, actionTick17070. This proves actual native casts, not how the176HP recipient recovery is divided between healers.',
            'candidate5844': 'Actual source-tagged heal effects9304@15630 and9751@15870 are present in recorded event frames.',
            'limits': 'Accepted cast counts are never counted as restored HP. No observed source1907 effect in this selected sample does not prove no healing; snapshots can miss short-lived effects. Priest maxHP103→117 is a stat increase, excluded from HP-regain sums.'},
        'notableExistingVeteranTradeoffs': [{'id': row['id'], 'at13764': row['at13764'],
                                           **{label: {key: row[label + 'Death'][key] for key in ('tick', 'level', 'xp', 'kills')}
                                              for label in ('baseline', 'candidate')}}
                                          for row in tracked_rows if row['id'] in (
            'unit-p0-archer-1107', 'unit-p0-archer-1347', 'unit-p0-archer-2042', 'unit-p0-footman-1072', 'unit-p0-footman-1190', 'unit-p0-horseArcher-4294')],
        'interpretation': [
            'At16200 the candidate has fewer losses and another completed hall, but all four existing medical units die17154–17203;17400 has no medic while baseline has replacementpriest10712.',
            'The candidate rebuilds a third hall9326 by16200 but loses it17794; by24000 its workers/army have fallen to6/7 versus baseline11/16.',
            'By30000 candidate has only2workers/6army/no medic versus baseline10workers/16army/2medics; its cumulative spending13044 is already terminal and below baseline15626.',
            'Baseline1107 dies25673 while candidate1107 dies17006,8667ticks earlier; other original veterans live longer in candidate, so this is a tradeoff rather than uniform earlier death.',
            'The comparison includes the inherited a90 stop-ownership change as well as safe ordinary-return selection. It does not isolate a single cause of the final loss.'],
        'evidence': {'comparison': str(destination), 'sha256': digest(destination), 'script': str(Path(__file__).resolve()),
                     'sourceAndRestoreManifests': 'Recorded episode/tail report source/frozen/restore exact; this review hashes selected input artifacts rather than re-running the source preflight.'},
        'limits': report['limits'] + ['Developed seed under rulesVersion2 and frozenRevisiond1ae110; not fresh holdout, three-route acceptance, or a candidate ordinary0.',
                                     'Full terminal snapshots have different ticks43714/41057; common-tick metrics are the direct state comparison.'],
    }
    review_path = out / 'review.json'
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(destination), 'sha256': digest(destination),
                      'review': str(review_path), 'reviewSHA256': digest(review_path),
                      'baseline': {'tick': finals['baseline']['tick'], 'winner': finals['baseline']['winner'], 'losses': finals['baseline']['players']['p0']['permanentDeathObservations']},
                      'candidate': {'tick': finals['candidate']['tick'], 'winner': finals['candidate']['winner'], 'losses': finals['candidate']['players']['p0']['permanentDeathObservations']}}))


if __name__ == '__main__':
    main()
