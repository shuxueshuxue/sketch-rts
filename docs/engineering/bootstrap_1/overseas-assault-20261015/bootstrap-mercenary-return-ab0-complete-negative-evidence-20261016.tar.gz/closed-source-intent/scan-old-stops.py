from pathlib import Path
import hashlib,json
out=Path(__file__).parent;raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game')
commands=Path(str(raw)+'-commands.jsonl');plans=Path(str(raw)+'-plans.jsonl')
accepted=[x for x in map(json.loads,commands.open()) if x['owner']=='p0' and x['command']['type']=='stop']
planned=[{'tick':p['tick'],'entry':e} for p in map(json.loads,plans.open()) if p['owner']=='p0' for e in p['entries'] if e['command']['type']=='stop']
selected=lambda xs:[x for x in xs if 13764<=x['tick']<=18000]
report={'classification':'Readonly oldactuale566 recordedcommand/plan scan; counts are on OLD physicaltrajectory only. Doesnot prove newcandidateworld has no changed stop decisions or compare emittedcmd counts as sourcecausality.', 'commandFile':str(commands),'commandFileSHA256':hashlib.sha256(commands.read_bytes()).hexdigest(),'planFile':str(plans),'planFileSHA256':hashlib.sha256(plans.read_bytes()).hexdigest(),'oldAcceptedStops13764Through18000':selected(accepted),'oldPlannedStops13764Through18000':selected(planned),'allOldAcceptedStopCount':len(accepted),'allOldPlannedStopCount':len(planned),'allOldAcceptedStops':accepted}
assert len(selected(accepted))==1 and selected(accepted)[0]['tick']==13875
assert selected(accepted)[0]['command']['unitIds']==['unit-p0-fieldMedic-2255']
out.joinpath('old-source-stop-command-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'oldWindowAcceptedStops':selected(accepted),'oldWholeGameCount':len(accepted)}))
