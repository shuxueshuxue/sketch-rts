import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { expect, it } from 'vitest';
import { sketchScene } from '../../sdk/scene';
import { UNIT_DEFS } from '../../shared/catalog';
import { unitControlsMercenaryCamp } from '../../shared/mercenary-camp';
import { nearestByRoute } from '../../shared/route-selection';
import { createGame, restoreSnapshotIntoGame, snapshotGame } from '../../shared/sim';
import { setBuildingBodies, snapToFootprint } from '../../shared/terrain';
import type { GameSnapshot, Unit } from '../../shared/types';
import { createAiPolicyMemory, type AiPolicyMemory } from '../memory';
import { V7_GATHERED_RANGE } from '../policy/v7/creep';
import { campVisitors, mercenaryAssignment, mercenaryControl, mercenaryControlUnitIds, returningMercenaries } from './mercenary-control';
import { bootstrapPolicyContext } from './policy';
import { armedFoes, retreatLandRoad, safeLandTravelTicks } from './safe-land-route';

const saved = JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/archer-field-medic-return-13770.json.gz', import.meta.url))).toString()) as {
  snapshot: GameSnapshot; nextId: number; memories: Record<string, AiPolicyMemory>;
};
const medicId = 'unit-p0-fieldMedic-2255', southId = 'building-p0-townHall-1639', northId = 'building-p0-townHall-4969';
const load = () => {
  const copy = structuredClone(saved), game = createGame('bareDuel');
  restoreSnapshotIntoGame(game, copy.snapshot, copy.nextId);
  return { snapshot: snapshotGame(game), memory: copy.memories.p0!, teams: game.teams };
};

it('uses the real 13770 safe south-hall road, including its native endpoint 64 from the hall', () => {
  const { snapshot, memory, teams } = load();
  expect(JSON.parse(JSON.stringify(snapshot))).toEqual(saved.snapshot);
  expect(snapshot.tick).toBe(13770);
  const unit = snapshot.units.find(unit => unit.id === medicId)!, south = snapshot.buildings.find(home => home.id === southId)!;
  const north = snapshot.buildings.find(home => home.id === northId)!, before = JSON.stringify({ snapshot, memory });
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams });
  expect(memory.mercenaryCourier).toBeUndefined();
  expect(unit.order).toEqual({ type: 'idle' });
  expect(unit.hp).toBe(unit.maxHp);
  expect(unitControlsMercenaryCamp(unit, snapshot.mercenaryCamps.find(camp => camp.id === 'merc-gen-2')!)).toBe(true);
  expect(nearestByRoute(snapshot.map, snapshot.buildings.filter(home => home.owner === 'p0' && home.kind === 'townHall' && home.complete), unit, 'land')?.id).toBe(northId);
  const foes = armedFoes(snapshot, 'p0', options), road = retreatLandRoad(snapshot, unit, south, foes)!;
  expect(retreatLandRoad(snapshot, unit, north, foes)).toBeUndefined();
  expect(road.ticks).toBe(380);
  expect(road.points.at(-1)).toEqual({ x: 1584, y: 3888 });
  const gap = Math.hypot(road.points.at(-1)!.x - south.x, road.points.at(-1)!.y - south.y);
  expect(gap).toBe(64);
  expect(gap).toBeLessThanOrEqual(V7_GATHERED_RANGE);
  expect(returningMercenaries(snapshot, 'p0', options).find(({ unit }) => unit.id === medicId)?.home?.id).toBe(southId);
  expect(mercenaryControl.run(snapshot, 'p0', options).filter(command => 'unitIds' in command && command.unitIds.includes(medicId)))
    .toEqual([{ type: 'move', unitIds: [medicId], x: south.x, y: south.y, avoidCombat: true }]);
  expect(JSON.stringify({ snapshot, memory })).toBe(before);
}, 10000);

it('keeps an ordinary recruit returning to a nonnearest own hall and releases it at the original 180 range', () => {
  const { snapshot, memory, teams } = load(), unit = snapshot.units.find(unit => unit.id === medicId)!;
  const south = snapshot.buildings.find(home => home.id === southId)!;
  unit.order = { type: 'move', x: south.x, y: south.y, avoidCombat: true };
  // Remove new purchasing opportunities so the ordinary archer is a distinct
  // negative control for return ownership, rather than a new courier candidate.
  for (const camp of snapshot.mercenaryCamps) camp.stock = 0;
  const archer: Unit = { ...structuredClone(unit), id: 'ordinary-archer', kind: 'archer' };
  snapshot.units.push(archer);
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams });
  expect(nearestByRoute(snapshot.map, snapshot.buildings.filter(home => home.owner === 'p0' && home.kind === 'townHall' && home.complete), unit, 'land')?.id).toBe(northId);
  expect(returningMercenaries(snapshot, 'p0', options).find(({ unit }) => unit.id === medicId)?.home?.id).toBe(southId);
  const claimed = mercenaryControlUnitIds(snapshot, 'p0', options);
  expect(claimed.has(medicId)).toBe(true);
  expect(claimed.has(archer.id)).toBe(false);
  expect(mercenaryControl.run(snapshot, 'p0', options).some(command => 'unitIds' in command && command.unitIds.includes(medicId))).toBe(false);
  expect(memory.mercenaryCourier).toBeUndefined();
  for (const gap of [V7_GATHERED_RANGE + 1, V7_GATHERED_RANGE]) {
    // Each boundary has a fresh frame; no query cache is asked to survive a
    // position mutation after it has already observed this snapshot.
    const boundary = load(), recruit = boundary.snapshot.units.find(unit => unit.id === medicId)!;
    const hall = boundary.snapshot.buildings.find(home => home.id === southId)!;
    recruit.x = hall.x + gap; recruit.y = hall.y;
    recruit.order = { type: 'move', x: hall.x, y: hall.y, avoidCombat: true };
    for (const camp of boundary.snapshot.mercenaryCamps) camp.stock = 0;
    const context = bootstrapPolicyContext(boundary.snapshot, 'p0', 'v9_archer', { memory: boundary.memory, teams: boundary.teams });
    const returning = gap > V7_GATHERED_RANGE;
    expect(returningMercenaries(boundary.snapshot, 'p0', context).some(({ unit }) => unit.id === medicId)).toBe(returning);
    expect(mercenaryControlUnitIds(boundary.snapshot, 'p0', context).has(medicId)).toBe(returning);
    expect(boundary.memory.mercenaryCourier).toBeUndefined();
  }
}, 10000);

it.each(['idle', 'move'] as const)('retains no-road return ownership without a new move, camp hold or purchase (%s)', orderType => {
  const { snapshot, memory, teams } = load(), unit = snapshot.units.find(unit => unit.id === medicId)!;
  const south = snapshot.buildings.find(home => home.id === southId)!;
  unit.order = orderType === 'idle' ? { type: 'idle' } : { type: 'move', x: south.x, y: south.y, avoidCombat: true };
  // This component changes only a copy of the real input. Ordinary archers
  // beside each home cover its native arrival endpoint with their real range.
  const rules = UNIT_DEFS.archer;
  for (const home of snapshot.buildings.filter(home => home.owner === 'p0' && home.kind === 'townHall' && home.complete)) {
    const x = home.x + 96, y = home.y;
    snapshot.units.push({ ...structuredClone(unit), id: `home-blocker-${home.id}`, owner: 'p1', kind: 'archer', x, y,
      hp: rules.hp, maxHp: rules.hp, speed: rules.speed, attackDamage: rules.attackDamage, attackRange: rules.attackRange,
      attackCooldown: rules.attackCooldown, order: { type: 'hold', x, y }, abilityCooldowns: {} });
  }
  const before = JSON.stringify({ snapshot, memory }), options = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory, teams });
  const returning = returningMercenaries(snapshot, 'p0', options).find(({ unit }) => unit.id === medicId);
  expect(returning).toBeDefined();
  expect(returning!.home).toBeUndefined();
  expect(mercenaryControlUnitIds(snapshot, 'p0', options).has(medicId)).toBe(true);
  if (orderType === 'idle') expect(campVisitors(snapshot, 'p0', options).some(({ unit }) => unit.id === medicId)).toBe(true);
  expect(mercenaryAssignment(snapshot, 'p0', options)).toEqual([]);
  expect(mercenaryControl.run(snapshot, 'p0', options)).toEqual([]);
  expect(memory.mercenaryCourier).toBeUndefined();
  // In particular, an already issued native move is preserved, not stopped.
  expect(JSON.stringify({ snapshot, memory })).toBe(before);
}, 10000);

function purchasingCourier() {
  const game = sketchScene('ordinary-return-does-not-change-purchasing').map('bareDuel').replaceDefaults()
    .player('us', { race: 'grove', team: 'a' }).player('foe', { race: 'ember', team: 'b' })
    .townHall('us', 500, 700).townHall('foe', 3500, 3500)
    .unit('us', 'archer', 1600, 700, { id: 'courier' })
    .unit('foe', 'archer', 1000, 700, { id: 'home-road-enemy' })
    .mercenaryCamp('buying-camp', 2200, 700, { hireKind: 'mercenary', stock: 2 }).build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: '.'.repeat(128 * 128) };
  for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
  setBuildingBodies(game.map, game.buildings);
  const snapshot = snapshotGame(game), memory = createAiPolicyMemory();
  memory.mercenaryCourier = { unitId: 'courier', campId: 'buying-camp' };
  return { snapshot, memory, teams: game.teams };
}

it('keeps an active purchasing courier and its camp goal when the original home road is unsafe', () => {
  const { snapshot, memory, teams } = purchasingCourier(), unit = snapshot.units.find(unit => unit.id === 'courier')!;
  const home = snapshot.buildings.find(home => home.owner === 'us' && home.kind === 'townHall')!, camp = snapshot.mercenaryCamps[0]!;
  const before = JSON.stringify({ snapshot, memory }), options = bootstrapPolicyContext(snapshot, 'us', 'v9_archer', { memory, teams });
  const foes = armedFoes(snapshot, 'us', options);
  expect(safeLandTravelTicks(snapshot, unit, home, foes)).toBeUndefined();
  expect(retreatLandRoad(snapshot, unit, home, foes)).toBeUndefined();
  expect(safeLandTravelTicks(snapshot, unit, camp, foes)).toBeDefined();
  expect(returningMercenaries(snapshot, 'us', options)).toEqual([]);
  expect(mercenaryAssignment(snapshot, 'us', options).map(({ unit, camp }) => [unit.id, camp.id])).toEqual([['courier', 'buying-camp']]);
  expect(mercenaryControl.run(snapshot, 'us', options)).toEqual([{ type: 'move', unitIds: ['courier'], x: camp.x, y: camp.y, avoidCombat: true }]);
  expect(JSON.stringify({ snapshot, memory })).toBe(before);
});

it.each(['idle', 'hold'] as const)('preserves an active camp visitor and purchasing memory while %s', orderType => {
  const { snapshot, memory, teams } = purchasingCourier(), unit = snapshot.units.find(unit => unit.id === 'courier')!, camp = snapshot.mercenaryCamps[0]!;
  unit.x = camp.x; unit.y = camp.y;
  unit.order = orderType === 'idle' ? { type: 'idle' } : { type: 'hold', x: camp.x, y: camp.y };
  const before = JSON.stringify({ snapshot, memory }), options = bootstrapPolicyContext(snapshot, 'us', 'v9_archer', { memory, teams });
  expect(returningMercenaries(snapshot, 'us', options)).toEqual([]);
  expect(campVisitors(snapshot, 'us', options).map(({ unit, camp }) => [unit.id, camp.id])).toEqual([['courier', 'buying-camp']]);
  expect(mercenaryControlUnitIds(snapshot, 'us', options).has(unit.id)).toBe(true);
  expect(mercenaryAssignment(snapshot, 'us', options)).toEqual([]);
  expect(mercenaryControl.run(snapshot, 'us', options)).toEqual(orderType === 'idle' ? [{ type: 'holdPosition', unitIds: ['courier'] }] : []);
  expect(JSON.stringify({ snapshot, memory })).toBe(before);
});
