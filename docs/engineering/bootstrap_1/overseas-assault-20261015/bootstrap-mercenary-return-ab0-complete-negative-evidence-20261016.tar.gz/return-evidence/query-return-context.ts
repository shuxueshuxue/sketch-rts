import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const source='/workspace/sketch-rts-stop-ownership-e566-control',out='/workspace/.playtest/bootstrap-mercenary-return-roads-20261016',old='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016';
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href),copy=(v:any)=>JSON.parse(JSON.stringify(v)),gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y),uid='unit-p0-fieldMedic-2255';
const {setBuildingBodies}=await load('src/shared/terrain.ts');
const {bootstrapPolicyContext,bootstrapScripts}=await load('src/ai/bootstrap_1/policy.ts');
const {armedFoes,safeLandTravelTicks,retreatLandRoad}=await load('src/ai/bootstrap_1/safe-land-route.ts');
const {groundSteeringRoute,routeTravelTicks,nearestByRoute}=await load('src/shared/route-selection.ts');
const {mercenaryControl,returningMercenaries,mercenaryAssignment,campVisitors}=await load('src/ai/bootstrap_1/mercenary-control.ts');
const {medicalRecovery,recoveryPatients}=await load('src/ai/bootstrap_1/medical-recovery.ts');
const {unitControlsMercenaryCamp}=await load('src/shared/mercenary-camp.ts');
const {UNIT_DEFS,ABILITY_DEFS,MERCENARY_HIRE_RANGE}=await load('src/shared/catalog.ts');
const {canReceiveHealing}=await load('src/shared/healing.ts');
const {abilityCooldown}=await load('src/shared/ability-cooldowns.ts');
const {pruneAiPolicyMemory}=await load('src/ai/policy/claims.ts');
const rows:any[]=[];
for(const tick of [13770,13800,13860,13875]){
 const input=tick===13770?out+'/baseline13764-13800-prethink-13770.json.gz':old+'/baseline13800-13964-prethink-'+tick+'.json.gz';
 const bytes=readFileSync(input),saved=JSON.parse(gunzipSync(bytes).toString()),before=JSON.stringify(saved),s=saved.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const unit=s.units.find((u:any)=>u.id===uid),context=bootstrapPolicyContext(s,'p0','v9_archer',{memory:copy(saved.memories.p0),teams:s.teams});pruneAiPolicyMemory(s,'p0',context.memory);
 const foes=armedFoes(s,'p0',context),halls=s.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall'&&b.complete),nearest=nearestByRoute(s.map,halls,unit,'land');
 const homes=halls.map((home:any)=>{
  const points=groundSteeringRoute(s.map,unit,home),retreat=retreatLandRoad(s,unit,home,foes),safe=safeLandTravelTicks(s,unit,home,foes);
  const rejection=home.id===nearest.id?foes.flatMap((foe:any)=>{const r=retreatLandRoad(s,unit,home,[foe]),q=safeLandTravelTicks(s,unit,home,[foe]);return r&&q!==undefined?[]:[{foeId:foe.id,kind:foe.kind,owner:foe.owner,x:foe.x,y:foe.y,range:foe.attackRange,speed:foe.speed??0,order:foe.order,singleFoeBlocksRetreat:r===undefined,singleFoeBlocksSafe:q===undefined}];}):[];
  return {home:{id:home.id,x:home.x,y:home.y,hp:home.hp},centerGap:gap(unit,home),terrainTicks:routeTravelTicks(s.map,unit,home,'land',unit.speed)??null,nativeSteeringLength:points.slice(1).reduce((n:number,p:any,i:number)=>n+gap(points[i],p),0),endpoint:points.at(-1),endpointCenterGap:gap(points.at(-1),home),points,safeTicks:safe??null,retreat:retreat??null,rejectedByIndividualFoes:rejection};
 });
 const claims=new Map();const working={...context,memory:copy(context.memory)};for(const script of bootstrapScripts('v9_archer'))for(const id of script.claimsUnits?.(s,'p0',working)??[])if(!claims.has(id))claims.set(id,script.id);
 const medics=s.units.filter((u:any)=>u.owner==='p0'&&!u.deck).flatMap((healer:any)=>UNIT_DEFS[healer.kind].abilities.flatMap((ability:string)=>ABILITY_DEFS[ability].behavior!=='heal'?[]:[{unit:{id:healer.id,x:healer.x,y:healer.y,hp:healer.hp,maxHp:healer.maxHp,order:healer.order,queue:healer.orderQueue},ability,cooldown:abilityCooldown(healer,ability),range:ABILITY_DEFS[ability].range,actualCenterGap:gap(unit,healer),road:groundSteeringRoute(s.map,unit,healer),roadTicks:routeTravelTicks(s.map,unit,healer,'land',unit.speed)??null,medicalRecoveryClaims:medicalRecovery.claimsUnits(s,'p0',working).has(healer.id),firstOwner:claims.get(healer.id)??null}]));
 const returns=returningMercenaries(s,'p0',{...context,memory:copy(context.memory)});
 const run=mercenaryControl.run(s,'p0',{...context,memory:copy(context.memory)});
 const row={tick,input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),doctor:unit,nearestHomeId:nearest.id,homes,medics,
  camps:s.mercenaryCamps.map((camp:any)=>({camp,centerGap:gap(unit,camp),nativeControlRange:camp.radius+unit.radius+MERCENARY_HIRE_RANGE,nativeAtCamp:unitControlsMercenaryCamp(unit,camp)})),
  actualOriginalReturning:returns.map((r:any)=>({unit:r.unit.id,home:r.home.id})),originalMercenaryRunCommands:run,firstDoctorOwner:claims.get(uid)??null,actualOriginalMercenaryClaim:mercenaryControl.claimsUnits(s,'p0',{...context,memory:copy(context.memory)}).has(uid),
  courierMemory:saved.memories.p0.mercenaryCourier??null,criticalPatients:recoveryPatients(s,'p0').map((u:any)=>({id:u.id,hp:u.hp,maxHp:u.maxHp})),canReceiveHealing:canReceiveHealing(unit,s),medicalRecoveryCommands:medicalRecovery.run(s,'p0',working),
  fullWorldIdAll3memSerializedUnchanged:JSON.stringify(saved)===before};
 if(!row.fullWorldIdAll3memSerializedUnchanged)throw Error('Query mutated original input');rows.push(row);
}
const report={classification:'Read-only actual13770 firstcurrentreturn and13800/13860/13875 completeinputs. Originala90 planner helpers only; no Game/steps/neworders. Sourcea90 differsfromoriginale566 onlystoprunner, these selectors byteidentical. Ownhealerpositions are factual candidates, not newfollow tasks or asserted healing.',source,head:'a90c0119d7166baad1c9222781baab107deedbcb',rows,limits:['Static knownthreat route qualification doesnot guarantee survival against dynamicallymoving fasterfoes.','No newgoal/owner/healththreshold/memory has been added.','Nativebody-awarehall endpoints remain64pxfromhallcenter; originalgathered180release is separate.']};
writeFileSync(out+'/return-context-query.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,doctor:{x:r.doctor.x,y:r.doctor.y,hp:r.doctor.hp,order:r.doctor.order,healCD:r.doctor.abilityCooldowns?.heal},nearest:r.nearestHomeId,firstOwner:r.firstDoctorOwner,criticalPatients:r.criticalPatients,homes:r.homes.map((g:any)=>({id:g.home.id,ticks:g.terrainTicks,safe:g.safeTicks,retreat:g.retreat?.ticks??null,blocks:g.rejectedByIndividualFoes.map((f:any)=>f.foeId)})),medics:r.medics.map((m:any)=>({id:m.unit.id,hp:m.unit.hp,cd:m.cooldown,gap:m.actualCenterGap,road:m.roadTicks,owner:m.firstOwner})),atCamp:r.camps.filter((c:any)=>c.nativeAtCamp).map((c:any)=>({id:c.camp.id,gap:c.centerGap,control:c.nativeControlRange})),unchanged:r.fullWorldIdAll3memSerializedUnchanged}))));
