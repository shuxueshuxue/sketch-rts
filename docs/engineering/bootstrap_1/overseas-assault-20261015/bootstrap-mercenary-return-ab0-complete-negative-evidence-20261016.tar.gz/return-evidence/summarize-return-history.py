import json,gzip,hashlib
from pathlib import Path
out=Path(__file__).parent
raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016')
commands=[json.loads(l) for l in (raw/'game-commands.jsonl').open()]
unit='unit-p0-fieldMedic-2255'
history=[x for x in commands if x['tick']<=13964 and unit in json.dumps(x['command'])]
owned=[x for x in history if x['owner']=='p0' and x['scriptId']=='mercenaryControl']
northBuilds=[x for x in commands if x['owner']=='p0' and x['command']['type']=='build' and x['command']['buildingKind']=='townHall' and x['command']['x']==2128 and x['command']['y']==2160]
samples=[]
for t in [10800,11400,12000,12600,13200,13800]:
    p=raw/f'game.frames/{t}.json.gz';f=json.load(gzip.open(p,'rt'));b=next((b for b in f['snapshot']['buildings'] if b['id']=='building-p0-townHall-4969'),None)
    samples.append({'tick':t,'input':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'northHall':{k:b[k] for k in ['id','hp','complete','buildProgress','buildTime']} if b else None})
report={'classification':'Only actualaccepted publiccommands plus completeordinary0 coarseframes. Northcompletion exacttick is NOT inferred from progress; observed incomplete12000 and complete12600.',
'commandSource':str(raw/'game-commands.jsonl'),'commandSourceSHA256':hashlib.sha256((raw/'game-commands.jsonl').read_bytes()).hexdigest(),
'actualDoctorReturnCommands':owned,'currentEpisodeFirstNorthReturn':next(x for x in owned if x['command']['x']==2128),'northHallBuildCommands':northBuilds,'northHallCoarsePresence':samples,
'precedingCurrentEpisodeDoctorCommand':next(x for x in history if x['owner']=='p0' and x['tick']==13755),'limits':['The doctor returned south before and was later released into combat/backline.13770 is a new returnepisode, not the firstreturn after its8610birth.','Idle at13770 lies within native camp286 control, not at literalcampcenter. Originalidlemercenaryreturn predicate can therefore retrigger for veteran hiredunits.','Nearestnorth217 vs south407 terrain ticks at13770 is a static route fact; newerhall appears after prior11130 southreturn and was completedby12600.']}
out.joinpath('return-history-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
out.joinpath('actual2255-public-command-history.json').write_text(json.dumps(history,indent=2)+'\n')
print(json.dumps({'returnCommands':[{'tick':x['tick'],'x':x['command']['x'],'y':x['command']['y']} for x in owned],'northHallBuildFirst':northBuilds[0],'northHallCoarsePresence':samples},ensure_ascii=False))
