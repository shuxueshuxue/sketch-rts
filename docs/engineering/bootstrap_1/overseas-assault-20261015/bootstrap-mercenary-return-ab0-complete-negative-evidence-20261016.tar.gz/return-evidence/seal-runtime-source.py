from pathlib import Path
import json,hashlib,tarfile,io,shutil,subprocess
out=Path(__file__).parent;root=Path('/workspace/sketch-rts-mercenary-return-roads-control');post=json.load(open(out/'candidate-complete-tail-source-postflight.json'));head=(out/'fixed-head.txt').read_text().strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
files=post['source']['inherited']+post['source']['extras'];assert len(files)==1465
archive=out/'candidate-runtime-source.tar.gz';assert not archive.exists()
index={'head':head,'files':files,'filesCount':len(files),'classification':'All1465 fixedruntime capsulefiles, currentoriginal1462paths plus3addedfixture/testpaths; everybyte matches fixedgit/sourcepostflight. No node_modules or omitted dynamic secrets.'}
with tarfile.open(archive,'w:gz') as tar:
 b=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('SOURCE-INDEX.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
 for row in files:
  p=root/row['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];tar.add(p,arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==1466
 for row in files:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016');cap=json.load(open(raw/'game-runtime-source.json'))
frozen=raw/'game-frozen-source.tar.gz'
with tarfile.open(frozen,'r:gz') as tar:
 for path,expected in cap['frozenFiles'].items():assert hashlib.sha256(tar.extractfile(path).read()).hexdigest()==expected
copied=out/'frozen184-runtime-source.tar.gz';assert not copied.exists();shutil.copyfile(frozen,copied)
inputs=out/'inputs';inputs.mkdir(exist_ok=True)
for p,name in [(raw/'game.events/13764-after-step-56.json.gz','actual-e566-13764-after-step.json.gz'),(raw/'game.frames/13800.json.gz','actual-e566-13800.json.gz'),(raw/'game-runtime-source.json','original-e566-runtime-capsule.json'),(raw/'game-frozen-source.json','original-frozen-source.json')]:shutil.copyfile(p,inputs/name)
for row in files:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
seal={'head':head,'currentSourceArchive':{'file':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'sourceFiles':1465,'readbackAllExact':True},'frozenArchive':{'file':str(copied),'bytes':copied.stat().st_size,'sha256':hashlib.sha256(copied.read_bytes()).hexdigest(),'files':len(cap['frozenFiles']),'all497CapsuleFilesExact':True},'allLiveSourceFilesUnchangedDuringSeal':True}
out.joinpath('runtime-source-seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal))
