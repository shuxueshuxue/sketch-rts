import json,gzip,hashlib
from pathlib import Path
from collections import Counter
out=Path(__file__).parent
raw=Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016')
def frame(p):return json.load(gzip.open(p,'rt'))
def lines(p):return [json.loads(l) for l in p.open() if l.strip()]
inputfile=raw/'game.events/13764-after-step-56.json.gz';initial=frame(inputfile);finalfile=out/'candidate-complete-tail-terminal.json.gz';final=frame(finalfile);s=final['snapshot'];initialcorp={c['unitId']:c for c in initial['snapshot'].get('corpses',[])};finalcorp={c['unitId']:c for c in s.get('corpses',[])}
assert len(initialcorp)==len(initial['snapshot'].get('corpses',[]));assert len(finalcorp)==len(s.get('corpses',[]))
allrows=lines(out/'candidate-return-episode-native-deaths.jsonl')+lines(out/'candidate-complete-tail-native-deaths.jsonl')
terminal={};confirm={};classes=Counter()
for row in allrows:
    uid=row['id'];classes[row.get('terminalClass','unknown')]+=1
    if row['type']=='terminal-status-update':
        assert row['status']=='native-removal-after-nonpositive';confirm[uid]=row
    else:
        assert uid not in terminal;terminal[uid]=row
        if row.get('confirmation')=='absent-at-native-boundary':confirm[uid]=row
for uid,row in terminal.items():
    assert row['permanent'] is True and uid in confirm
    assert uid in finalcorp and finalcorp[uid]['diedAtTick']==confirm[uid]['tick']
    ev=row['evidence'];assert ev.get('nativePositiveToNonpositiveHit') or ev.get('hpNonpositive') or ev.get('corpse')
    assert row['terminalClass']=='death-observed'
assert set(finalcorp)==set(initialcorp)|set(terminal)
assert set(initialcorp).isdisjoint(terminal)
actual=Counter(c['owner'] for c in finalcorp.values());native=s['match']['stats']['unitsLost'];assert all(actual[o]==n for o,n in native.items())
for prefix in ['candidate-return-episode','candidate-complete-tail']:
    r=json.load(open(out/(prefix+'.json')));assert r['allMandatoryExact'] and not r['telemetry']['pendingNativeCleanup']
counts={label:dict(Counter(x['owner'] if label!='newRows' else x['previous']['owner'] for x in values)) for label,values in [('initialCorpses',initialcorp.values()),('finalCorpses',finalcorp.values()),('newRows',terminal.values())]}
originalFinal=frame(raw/'game.frames/43714.json.gz');old=originalFinal['snapshot'];olddeaths=[x for x in lines(raw/'game-native-deaths.jsonl') if x['id']=='unit-p0-fieldMedic-2255' and x.get('terminalClass')=='death-observed'];newdoctor=terminal['unit-p0-fieldMedic-2255'];
ledger=[]
for uid,corpse in sorted(finalcorp.items(),key=lambda x:(x[1]['diedAtTick'],x[0])):
    row=terminal.get(uid);ledger.append({'id':uid,'owner':corpse['owner'],'kind':corpse['kind'],'tick':corpse['diedAtTick'],'firstTerminalObservationTick':row['tick'] if row else None,'source':'original13764input-corpse' if uid in initialcorp else 'samefixedcandidate-native-confirmed','fatalHit':row.get('lastNativeHit') if row else None,'nativeConfirmation':confirm[uid] if row else 'already-dead-in-completeinput'})
report={'classification':'Completeab0 case13764originale566 input→14101samecandidate→natural41057defeat. NOT an ordinary0. Permanentledger merges originalinputcorpses with confirmedcandidate native-removal rows, never counts provisionalhp0 as final by itself.',
'head':(out/'fixed-head.txt').read_text().strip(),'initial':{'file':str(inputfile),'sha256':hashlib.sha256(inputfile.read_bytes()).hexdigest()},'final':{'file':str(finalfile),'sha256':hashlib.sha256(finalfile.read_bytes()).hexdigest()},
'checks':{'initialAndNewIdsDisjoint':True,'finalCorpseIdsEqualInitialPlusConfirmedNativeDeaths':True,'everyNewDeathHasNativeCleanupConfirmation':True,'corpseTicksEqualConfirmedNativeRemovalTicks':True,'allOwnerCountersClosed':True,'noPendingNativeCleanup':True,'bothEpisodeAndTailRestoreSourceFrozenExact':True},
'counts':counts,'nativeUnitsLost':native,'initialCorpseCount':len(initialcorp),'newConfirmedDeathCount':len(terminal),'finalCorpseCount':len(finalcorp),'terminalRowClasses':dict(classes),
'naturalResult':{'tick':s['tick'],'winner':s['match']['winner'],'remaining':{o:{'units':sum(u['owner']==o for u in s['units']),'buildings':sum(b['owner']==o for b in s['buildings']),'gold':s['players'][o]['gold']} for o in ['p0','p1','p2']}},
'originalE566Ordinary0Result':{'tick':old['tick'],'winner':old['match']['winner'],'nativeUnitsLost':old['match']['stats']['unitsLost'],'source':'e566actualfresh0 completeindependentsealedpackage585c209b...'},
'doctor2255':{'originalActualDeathTick':olddeaths[0]['tick'],'candidateActualDeathTick':newdoctor['tick'],'extensionTicks':newdoctor['tick']-olddeaths[0]['tick'],'fatal':newdoctor['lastNativeHit'],'actualFirstReturnReleased':json.load(open(out/'candidate-return-episode.json'))['actualReturnRelease'],'survivedEnd':False},
'limits':['Saving the currentreturn and3239tick extension doesnot offset naturaldefeat62permanentlost vs originalwin56.','Candidate includes a90stopcore plus returndelta; finaloutcome cannot be assigned solelyto a homepoint change without further sameworld sourceintent/controlledablation evidence.','Initialcorpses are inherited fullstate, not observations newlygenerated by candidate. No opponentresources/population/rules were changed.'],
'ledger':ledger}
out.joinpath('complete-ledger-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['checks','counts','initialCorpseCount','newConfirmedDeathCount','finalCorpseCount','terminalRowClasses','naturalResult']},ensure_ascii=False))
