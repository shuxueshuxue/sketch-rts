# ab0 普通佣兵返程道路：完整负例

固定候选 `ab0ffd200725968a9c4887d2d7883cfeec1eaa8f` 在真实 e566 的13764完整存档换码：14100完成2255医师本次返程，但完整续局自然41057 p1胜，我方0单位0建筑、62永久死亡。原e566真正普通0为43714 p0胜、56永久死亡。候选不合入，不能用医师延寿或局部测试代替完整比赛结果。

该案例为已开发的 p0 Grove/v9_archer（physicalside1）对正常 frozenv8 Ember+Grove 两敌；factory pineshade，生成ladder4608²，seed `bootstrap_1-unseen-archer-v8-v8-20261015-01`。名字含unseen不代表新holdout。沿用规则2、冻结184/manifest0490e7、三方普通500金/3已用/8cap的原实际状态，无注资、无改敌人口/资源/思考频率/代码。13764之前沿用原局真实world/id/全3memory，此后是换代码续局，不是新普通0。原普通0已独立完整封存，SHA `585c209b4ec89e7ad80563c16ea0820723359b1397fcd6f06208615d532348ee`。

## 固定源码和最小改动

独立分支 `codex/bootstrap-mercenary-return-roads-20261016`，控制树 `/workspace/sketch-rts-mercenary-return-roads-control`。基于 `a90c0119d7166baad1c9222781baab107deedbcb`，它在e566上只给runner的stop补了claim/conflict/reservation三处处理。a90单独13800短窗使医生更早死亡的负例另包保留，不能把它看成已合production。本ab0候选因此同时包含stop协议修复与普通雇佣返程道路策略，最终败局不能单归某个home排序行。

相对a90唯一生产变化为 `mercenary-control.ts`：保留原返程触发条件，使用现有retreatLandRoad验证原生building-aware路和终点≤原180，稳定选择路时较短的本方完工大厅；原native avoidCombat move精确指向任一本方完厅即可续认返程，到该原目标180内释放。普通兵种不会因此被认作佣兵。activeCourier原采购出程、原最近home、blockedTrip与memory生命周期保持；不新增owner、记忆、TTL、血量门槛或医疗follow/hold策略。

意图与可执行目标分开：无合格道路时仍保留返程unit ID用于原claims/assignment排除/waiting排除，home可为空，不新发危险fallback move、不重新派camp/误转visitor hold。这个处理**不会取消已在途旧native move**，不能宣称已经安全处理道路后来全面失效的情况。未来敌人追击不由静态metric保证。

`mercenary-return-roads-incremental.patch` 为相对a90三文件增量；`candidate-vs-e566.patch` 包含本完整候选五文件。生产root/main/其余fixed sources未改。`candidate-runtime-source.tar.gz`含1465完整runtime capsule文件，逐git/blob/hash/回读核验；冻结源archive的497 capsule文件另逐字节核验，旧manifest/冻结策略不变。

## 原生决策与完整执行

2255出生8610，前几次已成功回南；本次是13770再次触发的返程。真实13770前，其满105HP/CD48、idle，距merc-gen-2为275.821，在原286控制范围内；没有courierMemory/critical患者，ready priest3733仅32px。原最近北厅terrain217tick，南厅407、主厅663；北厅道路穿golem2491及骑士覆盖，safe与retreat均不合格，南厅原生退路380、主厅650。北厅public build11175，12000仍179/560未完，12600已完；前次11130南返在建北厅之前。不能说它一直是“刚出生佣兵”，也不能把南返称作完成治疗。

原e566从真实13764 after-native-step完整档到13800的36tick重放已严格闭合：world/id/3mem/setup、35commands、3hits全等，源1462与冻497前后全等，捕获actual13770 prethink。

ab0从同13764严格恢复world/id/3mem：首public差异仅13770同一条mercenaryControl move由北厅改南厅。13764→13800仍35commands/3hits，native hit序列全等。完整短段止于实际14101，医生全程105HP、0受击、0治疗；14100距南厅174.365，按原180真实释放返程，v6Backline重新发move。唯一该窗死者worker1019@13773与原局相同，原局另有2255@13964阵亡。它不是仅“过旧死线还没完成任务”。

随后从同源14101完整档严格恢复，全部3方AI继续到自然41057败北，未因医生以后死亡停局。600tick fullworld/id/all3mem、全部commands/hits/重大event档保留。医生2255在17203被ravager2297杀死，延寿3239tick，仍非终局保存。原1907/5844在候选同17154死、3733在17179死，17400已无医生。实际heal effect17070/source2255与3733存在；accepted cast本身不等于治疗，不将其它医生HP回升都归2255。

## 完整代价与范围

第一既有资本提前损失是北厅14115毁，原14162；首个既有永久单位更早损失是horseArcher4294@15896（原19016）。老兵archer1107在17006死，原25673。16200候选局部仍较好：3完厅/16工/4医/10损，原2厅/14工/3医/14损；24000却已2厅/6工/7军/46损，原3厅/11工/16军/38损，不能用早期局部优势推出整体改善。

完整ledger：原13764输入已有54尸体，加本候选确认145死亡，终局199尸体，ID全等且不重计；p0=62/p1=79/p2=39/neutral=19全部与native unitsLost闭合。12次公开命令后HP≤0观察只在后续native-removal-after-nonpositive确认后入最终死亡账，尸体时间对齐真正cleanup时钟，不把provisional当永久死。

同**旧e566实际完整state**14400/15000/15600/16200/16800/17400/18000，三源e566/a90/ab0纯完整p0 planner输出均等，e566 query同时吻合原recorded；world/id/all3mem不变。这是源意图隔离的7个采样点，不能推广为新world所有时刻无stop影响。原普通0全程实际p0 stop仅13875那次2255，扫描原plans与accepted commands相符；这仍不是对变后world的完整反事实证明。后续具体15896兵损调查另在postloss目录推进，本包不含未闭合的新实验。

## 验证与更正

94现有相关佣兵契约（含三路线/种族镜像）通过。7新例首轮6过1红：fixture loader restore后没像真实owner planner一样注册building overlay，算388且终点落厅心。相同JSON显式注册后为380/真正64px厅边终点，JSON不变。已保留初次红log、旧test字节、overlay-contract query；最终test补真实planner相同准备，并去掉不必要固定380断言，7例全绿。tsc无诊断。没有为追绿更改道路/引擎或原fixture字节。

13800/60/75是**把新源码查询于旧实战输入**的反事实组件，不是本新候选离开13770后的实际world。特别是若等到旧13860受伤档才retarget，新增move会被原runner冲突机制用于挡掉同帧selfheal，已单列scope-note，未声称四个组件全都只变goal而无其它命令变化。

原ledger脚本初版误猜terminal update类型，重复ID断言停止；真实协议为terminal-status-update(status native-removal-after-nonpositive)，已保留初版生成器及更正说明，最终按真实native清理tick闭合，raw/source未改。

三路线全部单敌/六配对的完整比赛与泛化仍未完成。原容器未提交修改的恢复缺口继续保留。本完整负例不否定retreat primitive本身，也不授权放宽安全/人口/对手或继续套新home/hold小变体。
