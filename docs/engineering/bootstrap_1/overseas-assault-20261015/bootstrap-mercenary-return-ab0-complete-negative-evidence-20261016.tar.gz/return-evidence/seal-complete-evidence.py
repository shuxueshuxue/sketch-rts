from pathlib import Path
import json,hashlib,tarfile,io
out=Path(__file__).parent
roots={'return-evidence':out,'independent-complete-review':Path('/workspace/.playtest/bootstrap-mercenary-return-roads-independent-complete-review-20261016')}
files=[]
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if p.is_file():
   data=p.read_bytes();files.append({'name':prefix+'/'+str(p.relative_to(root)),'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
# This root-only query set is closed. The ongoing horse4294 investigation is a
# separate subdirectory and is deliberately not part of this alreadyclosedcase.
postloss=Path('/workspace/.playtest/bootstrap-mercenary-return-postloss-diagnostic-20261016')
for p in sorted(postloss.iterdir()):
 if p.is_file():
  data=p.read_bytes();files.append({'name':'closed-source-intent/'+p.name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
index={'classification':'Closed fullnegative ab0 code-switch13764 case, exactoriginal36tick inputwitness, actual337tick return completion, same-source26956tick naturaldefeat tail, fullsource/frozen/3mem/ledger and independentreadonly review. Notordinary0/holdout/bootstrapacceptance. Ongoinghorse4294investigation excluded.','payloadFiles':len(files),'payloadBytes':sum(f['bytes'] for f in files),'files':files}
indexbytes=(json.dumps(index,indent=2)+'\n').encode();archive=Path('/workspace/.playtest/bootstrap-mercenary-return-ab0-complete-negative-evidence-20261016.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 info=tarfile.TarInfo('INDEX.json');info.size=len(indexbytes);tar.addfile(info,io.BytesIO(indexbytes))
 for row in files:tar.add(row['source'],arcname=row['name'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert json.load(tar.extractfile('INDEX.json'))==index;assert len(tar.getmembers())==len(files)+1
 for row in files:
  data=tar.extractfile(row['name']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
for row in files:
 data=Path(row['source']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
seal={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(files),'members':len(files)+1,'payloadBytes':index['payloadBytes'],'indexSHA256':hashlib.sha256(indexbytes).hexdigest(),'readbackAllExact':True,'allOriginalPayloadFilesUnchangedDuringSeal':True,'head':out.joinpath('fixed-head.txt').read_text().strip(),'incrementalPatchSHA256':hashlib.sha256(out.joinpath('mercenary-return-roads-incremental.patch').read_bytes()).hexdigest(),'combinedPatchSHA256':hashlib.sha256(out.joinpath('candidate-vs-e566.patch').read_bytes()).hexdigest()}
Path('/workspace/.playtest/bootstrap-mercenary-return-ab0-complete-negative-index-20261016.json').write_bytes(indexbytes);Path('/workspace/.playtest/bootstrap-mercenary-return-ab0-complete-negative-seal-20261016.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal))
