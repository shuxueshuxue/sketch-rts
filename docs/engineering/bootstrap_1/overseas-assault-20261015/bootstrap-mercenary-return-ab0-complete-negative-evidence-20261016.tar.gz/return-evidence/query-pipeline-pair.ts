import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const out='/workspace/.playtest/bootstrap-mercenary-return-roads-20261016',old='/workspace/.playtest/bootstrap-e566-medical-baseline2255-20261016',roots=['/workspace/sketch-rts-stop-ownership-e566-control','/workspace/sketch-rts-mercenary-return-roads-control'],copy=(v:any)=>JSON.parse(JSON.stringify(v));
const rows:any[]=[];
for(const tick of [13770,13800,13860,13875]){
 const input=tick===13770?out+'/baseline13764-13800-prethink-13770.json.gz':old+'/baseline13800-13964-prethink-'+tick+'.json.gz',bytes=readFileSync(input),original=JSON.parse(gunzipSync(bytes).toString()),before=JSON.stringify(original);
 const planFile=tick===13770?out+'/baseline13764-13800-plans.jsonl':old+'/baseline13800-13964-plans.jsonl',actual=readFileSync(planFile,'utf8').trim().split('\n').map(t=>JSON.parse(t)).find(x=>x.tick===tick&&x.owner==='p0').entries;
 const results:any[]=[];
 for(const source of roots){
  const load=(p:string)=>import(pathToFileURL(source+'/'+p).href),{planAiOwnerCommandEntries,createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{bootstrapPolicyContext}=await load('src/ai/bootstrap_1/policy.ts'),{mercenaryControl,returningMercenaries}=await load('src/ai/bootstrap_1/mercenary-control.ts'),{setBuildingBodies}=await load('src/shared/terrain.ts'),{pruneAiPolicyMemory}=await load('src/ai/policy/claims.ts');
  const saved=copy(original),snapshot=saved.snapshot,worldBefore=JSON.stringify(snapshot),memories=createAiMemoryProvider(copy(saved.memories));setBuildingBodies(snapshot.map,[...snapshot.buildings,...(snapshot.obstacles??[])]);
  const entries=copy(planAiOwnerCommandEntries(snapshot,{playerId:'p0',version:'v9_archer',source:'external-agent'},{teams:snapshot.teams,memoryProvider:memories}));
  const querySaved=copy(original),context=bootstrapPolicyContext(querySaved.snapshot,'p0','v9_archer',{memory:copy(original.memories.p0),teams:snapshot.teams});setBuildingBodies(querySaved.snapshot.map,[...querySaved.snapshot.buildings,...(querySaved.snapshot.obstacles??[])]);pruneAiPolicyMemory(querySaved.snapshot,'p0',context.memory);
  const returns=returningMercenaries(querySaved.snapshot,'p0',context).map((r:any)=>({unit:r.unit.id,home:r.home?{id:r.home.id,x:r.home.x,y:r.home.y}:null})),claimed=[...mercenaryControl.claimsUnits(querySaved.snapshot,'p0',context)];
  results.push({source,head:execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),status:execFileSync('git',['status','--porcelain'],{cwd:source,encoding:'utf8'}),entries,returns,claimed,afterP0Memory:copy(memories.get('p0')),worldUnchanged:JSON.stringify(snapshot)===worldBefore,otherOwnersUnchanged:['p1','p2'].every(o=>isDeepStrictEqual(copy(memories.get(o)),original.memories[o]))});
 }
 const [base,candidate]=results;
 const expectedBase=tick===13875?actual.filter((e:any)=>!(e.scriptId==='v6Backline'&&e.command.type==='stop'&&e.command.unitIds.includes('unit-p0-fieldMedic-2255'))):actual;
 const normalized=(entries:any[])=>entries.map(e=>{const z=copy(e);if(z.scriptId==='mercenaryControl'&&z.command.type==='move'&&z.command.unitIds.length===1&&z.command.unitIds[0]==='unit-p0-fieldMedic-2255'){z.command.x='RETURN_HOME_X';z.command.y='RETURN_HOME_Y';}return z;});
 rows.push({tick,input,inputSHA256:createHash('sha256').update(bytes).digest('hex'),results,checks:{originalFullInputUnchanged:JSON.stringify(original)===before,sourceClean:results.every(r=>!r.status),worldUnchanged:results.every(r=>r.worldUnchanged),otherOwnersUnchanged:results.every(r=>r.otherOwnersUnchanged),a90BaseEqualsActualExceptKnownStop:isDeepStrictEqual(base.entries,expectedBase),onlyDoctorReturnGoalDiffers:isDeepStrictEqual(normalized(candidate.entries),normalized(base.entries)),doctorStillOwnedInBoth:results.every(r=>r.claimed.includes('unit-p0-fieldMedic-2255'))}});
}
const report={classification:'Read-only fullp0 pipelinepair on exact actual13770/13800/13860/13875 completeprethink copies. Candidate ordinaryreturngoal only; originalinputs untouched. These are componentcounterfactuals, not actualcandidateworlds after13770.',rows};
writeFileSync(out+'/query-pipeline-pair.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(rows.map(r=>({tick:r.tick,checks:r.checks,doctorReturn:r.results.map((s:any)=>s.returns.find((x:any)=>x.unit==='unit-p0-fieldMedic-2255')),doctorCommands:r.results.map((s:any)=>s.entries.filter((e:any)=>e.command.unitIds?.includes('unit-p0-fieldMedic-2255')))}))));
if(rows.some(r=>!r.checks.originalFullInputUnchanged||!r.checks.sourceClean||!r.checks.worldUnchanged||!r.checks.otherOwnersUnchanged||!r.checks.a90BaseEqualsActualExceptKnownStop||!r.checks.doctorStillOwnedInBoth))process.exitCode=1;
