import fs from 'node:fs';
import crypto from 'node:crypto';
import { bootstrapPolicyContext } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/policy.ts';
import { mineGuardUnitIds, uncoveredMiningRaid, planBootstrapGeneral } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/mine-defense.ts';
import { mobileCare } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/mobile-care.ts';
import { mercenaryControlUnitIds } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/mercenary-control.ts';
import { lootRecoveryUnitIds } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/loot-recovery.ts';
import { shoppingUnitIds } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/shopping.ts';
import { postRecoveryAssignments } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/front-recovery.ts';
import { summonedMiningRaids } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/summoned-raids.ts';
import { mountedFieldOwns } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/mounted-field.ts';
import { coveredDefenseTarget } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/covered-defense.ts';
import { miningJobDefenseTarget } from '/workspace/sketch-rts-knight-expansion-control/src/ai/bootstrap_1/mining-job-defense.ts';
import { readV6Intel, readIntrusion } from '/workspace/sketch-rts-knight-expansion-control/src/ai/policy/v6/intel.ts';
import { availableV6Army, waitsForTowers, V7_WOUNDED_SHARE } from '/workspace/sketch-rts-knight-expansion-control/src/ai/policy/v6/general.ts';
import { isBacklineKind } from '/workspace/sketch-rts-knight-expansion-control/src/ai/policy/v6/backline.ts';
import { strengthOf } from '/workspace/sketch-rts-knight-expansion-control/src/ai/policy/v6/strength.ts';
import { walkingDistance, setBuildingBodies, sameGround } from '/workspace/sketch-rts-knight-expansion-control/src/shared/terrain.ts';
import { routeTravelTicks, groundSteeringRoute } from '/workspace/sketch-rts-knight-expansion-control/src/shared/route-selection.ts';
import { strikeGap } from '/workspace/sketch-rts-knight-expansion-control/src/shared/combat-geometry.ts';
import { GOLD_MINE_RULES } from '/workspace/sketch-rts-knight-expansion-control/src/shared/mining.ts';

const directory = '/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015/';
const root = '/workspace/sketch-rts-knight-expansion-control/';
const ordinary = JSON.parse(fs.readFileSync(directory + 'knight-unmedicated-road-opening.json', 'utf8'));
const fine = JSON.parse(fs.readFileSync(directory + 'knight-unmedicated-road-from6000.json', 'utf8'));
const metadata = JSON.parse(fs.readFileSync(directory + 'knight-unmedicated-road-opening.metadata.json', 'utf8'));
const distance = (a: any, b: any) => Math.hypot(a.x - b.x, a.y - b.y);
const hash = (path: string) => crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
const body = (entity: any) => ({ id: entity.id, owner: entity.owner, kind: entity.kind, x: entity.x, y: entity.y,
  hp: entity.hp, maxHp: entity.maxHp, strength: 'order' in entity ? strengthOf([entity]) : undefined,
  attackRange: entity.attackRange, attackDamage: entity.attackDamage, cooldown: entity.cooldown, order: entity.order });
const load = (tick: number) => JSON.parse(fs.readFileSync(directory + `knight-unmedicated-road-from6000.json.frames/${tick}.json`, 'utf8')).snapshot;
const geometryFrames = [20400, 21000, 21600, 21900, 22200, 22800].map(tick => {
  const snapshot = load(tick); setBuildingBodies(snapshot.map, snapshot.buildings);
  const saved = fine.rows.find((row: any) => row.tick === tick).players.p0.policy;
  const options = bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory: structuredClone(saved), teams: snapshot.teams });
  const intel = readV6Intel(snapshot, 'p0', options);
  const guarded = mineGuardUnitIds(snapshot, 'p0', options);
  const exclusion = {
    mineDefense: [...guarded], mercenaryControl: [...mercenaryControlUnitIds(snapshot, 'p0', options)],
    lootRecovery: [...lootRecoveryUnitIds(snapshot, 'p0', options)], shopping: [...shoppingUnitIds(snapshot, 'p0', options)],
    mobileCare: [...mobileCare.claimsUnits!(snapshot, 'p0', options)],
    restingPost: postRecoveryAssignments(snapshot, 'p0', options).filter(pair => !pair.walk).map(pair => pair.patient.id),
    summonedRaids: summonedMiningRaids(snapshot, 'p0', options).map(pair => pair.spirit.id),
    mounted: options.memory.mounted?.flatMap(job => job.unitIds) ?? [],
  };
  const busy = new Set(Object.values(exclusion).flat());
  const army = intel.army.filter(unit => !busy.has(unit.id) && !mountedFieldOwns(snapshot, 'p0', unit.id));
  const ownHalls = snapshot.buildings.filter((building: any) => building.owner === 'p0' && building.kind === 'townHall');
  const direct = readIntrusion(snapshot.buildings.filter((building: any) => building.owner === 'p0'), intel.enemies, true);
  const mining = uncoveredMiningRaid(snapshot, 'p0', options);
  // This trace has no mine-defense detachment at queried checkpoints. Otherwise stop rather than guess its hall.
  if (guarded.size) throw new Error(`Detachment at ${tick}: reproduce its covered-intrusion filter before attributing a branch`);
  const main = { ...intel, ownHalls, army, power: strengthOf(army), intrusion: mining ?? direct,
    armyCenter: army.length ? { x: army.reduce((sum, unit) => sum + unit.x, 0) / army.length,
      y: army.reduce((sum, unit) => sum + unit.y, 0) / army.length } : undefined };
  const working = intel.ownHalls.find(hall => sameGround(snapshot.map, intel.home, hall)
    && snapshot.resources.some((mine: any) => mine.amount > 0 && distance(mine, hall) < GOLD_MINE_RULES.baseRange));
  if (working) main.home = { x: working.x, y: working.y };
  const available = availableV6Army(snapshot, options, main), front = available.filter(unit => !isBacklineKind(unit) && unit.attackDamage > 0);
  const wounded = front.filter(unit => unit.hp < unit.maxHp * V7_WOUNDED_SHARE && unit.expiresTick === undefined);
  const line = front.filter(unit => !wounded.includes(unit));
  const jobDefense = miningJobDefenseTarget(snapshot, 'p0', main, options);
  const defense = jobDefense ?? coveredDefenseTarget(snapshot, main);
  const attackers = main.intrusion?.attackers ?? [];
  const towers = main.ownTowers.map(tower => ({ ...body(tower), coversWaitingPost: !!defense && distance(tower, defense.waitingPoint) + 80 <= tower.attackRange,
    attackers: attackers.map(enemy => ({ id: enemy.id, straight: distance(tower, enemy), towerStrikeGap: strikeGap(tower, enemy),
      towerCanFireNow: strikeGap(tower, enemy) <= tower.attackRange, enemyStrikeGap: strikeGap(enemy, tower), enemyCanFireNow: strikeGap(enemy, tower) <= enemy.attackRange })) }));
  const queries = front.flatMap(unit => attackers.map(enemy => ({ unitId: unit.id, targetId: enemy.id,
    straight: distance(unit, enemy), walkingDistance: walkingDistance(snapshot.map, unit, enemy),
    routeTravelTicks: routeTravelTicks(snapshot.map, unit, enemy, 'land', unit.speed),
    nativeRoad: groundSteeringRoute(snapshot.map, unit, enemy).map(point => ({ x: point.x, y: point.y })) })));
  const commands = planBootstrapGeneral(snapshot, 'p0', bootstrapPolicyContext(snapshot, 'p0', 'v9_knight', { memory: structuredClone(saved), teams: snapshot.teams }));
  return { tick, source: 'fine300 continuation; equal ordinary snapshots checked below', rawArmy: intel.army.map(body), rawPower: intel.power,
    exclusion, mainArmy: army.map(body), available: available.map(body), availablePower: strengthOf(available), front: front.map(body), line: line.map(body),
    intrusion: main.intrusion && { building: body(main.intrusion.building), threat: main.intrusion.threat, attackers: attackers.map(body), fromMiningRaid: !!mining },
    defense, defenseSource: jobDefense ? 'miningJobDefenseTarget' : 'coveredDefenseTarget',
    waitsForTowers: !!defense && waitsForTowers(main, defense, strengthOf(available), line),
    pursuit: defense && { hallToFieldRoad: walkingDistance(snapshot.map, defense.hall, defense.field),
      hallToFieldStraight: distance(defense.hall, defense.field), leash: defense.leash,
      admitted: walkingDistance(snapshot.map, defense.hall, defense.field)! <= distance(defense.hall, defense.field) + defense.leash!,
      fieldEdgeNeed: (main.intrusion?.threat ?? 0) * 1.15, enoughAtExistingFieldEdge: strengthOf(available) >= (main.intrusion?.threat ?? 0) * 1.15 },
    waitInputs: { shooterStrength: strengthOf(attackers.filter(unit => unit.attackRange > 100)), totalAttackerStrength: strengthOf(attackers),
      lineShooterStrength: strengthOf(line.filter(unit => unit.attackRange > 100)), totalLineStrength: strengthOf(line),
      waitingCover: defense?.waitingCover, threat: defense?.threat, halfAvailableStrength: strengthOf(available) * .5 },
    actualGeneralCommandsNextThink: commands, towers, frontRoadsToIntruders: queries };
});
const fineFrames = fine.rows.filter((row: any) => row.tick >= 9600).map((row: any) => ({ row, snapshot: load(row.tick) }));
const losses = fineFrames.slice(1).flatMap(({ row, snapshot }: any, i: number) => {
  const before = fineFrames[i];
  return before.snapshot.buildings.filter((building: any) => building.owner === 'p0' && !snapshot.buildings.some((other: any) => other.id === building.id))
    .map((building: any) => ({ building: body(building), lastPresentTick: before.row.tick, firstAbsentTick: row.tick,
      lastObservedAttackers: before.snapshot.units.filter((unit: any) => (unit.owner === 'p1' || unit.owner === 'p2')
        && (unit.order.type === 'attack' || unit.order.type === 'attackMove') && unit.order.targetId === building.id).map(body) }));
});
const equality = ordinary.rows.filter((row: any) => row.tick >= 9600).map((row: any) => ({ tick: row.tick,
  byteEqual: fs.readFileSync(directory + `knight-unmedicated-road-opening.json.frames/${row.tick}.json`).equals(
    fs.readFileSync(directory + `knight-unmedicated-road-from6000.json.frames/${row.tick}.json`)),
  allPlayerPoliciesEqual: JSON.stringify(row.players) === JSON.stringify(fine.rows.find((fineRow: any) => fineRow.tick === row.tick).players) }));
const output = { provenance: { classification: metadata.classification, head: metadata.head, source: metadata.worktree,
  seed: metadata.config.seed, rulesVersion: metadata.frozenPolicyManifest.rulesVersion, ordinaryResult: ordinary.result,
  sourceHashes: Object.fromEntries(['src/ai/bootstrap_1/mobile-care.ts', 'src/ai/bootstrap_1/mine-defense.ts', 'src/ai/bootstrap_1/covered-defense.ts',
    'src/ai/policy/v6/general.ts'].map(file => [file, hash(root + file)])), simulationTicksExecuted: 0 },
  method: 'Read-only replay-frame queries. mainArmyIntel is faithfully reproduced from source with a hard stop for unhandled detachment. Native roads include building occupancy; travel estimates exclude dynamic bodies and combat. No commands are issued.',
  equality, geometryFrames, buildingLossWindows: losses, finalMatch: load(26477).match,
  completedDamagedEnemyBuildingSamples: fineFrames.flatMap(({ row, snapshot }: any) => snapshot.buildings
    .filter((building: any) => (building.owner === 'p1' || building.owner === 'p2') && building.complete && building.hp < building.maxHp)
    .map((building: any) => ({ tick: row.tick, building: body(building) }))),
  findings: [
    'This is the stable mobile-care candidate ordinary0 match ending26477, not the earlier10081 or15858 defeats. All shared ordinary/fine300 checkpoints from9600 have byte-identical full frames and identical three-player report policy/state.',
    'At21600 the only intrusion attackers are p2 catapult9831 and13290. Raw own strength8.920698 drops to available6.863711 after five mobileCare patients are excluded. Available front has5 troops, strength5.163711; the two backline units add1.7.',
    'At21600/21900/22200 waitsForTowers returns true and planV6Army returns through towerWaiting before the existing FIELD_EDGE pursuit branch. Native hall-to-field roads and the existing strength edge both admit pursuit at these checkpoints.',
    'At21600 waitingCover3.9 comes from towers2270/2794/4964 protecting the waiting post. Their480-range weapons cannot hit either current608-range catapult. The enemy guns actually target the natural hall, not merely march toward it.',
    'A bootstrap-only gate should distinguish active unanswered fire on an own entity from an ordinary ranged army still approaching. Do not simply disable tower waiting whenever a current enemy position is outside480; that changes the original anti-archer behavior.',
    'At22800 waitsForTowers is false and the next pure planner query orders an attackMove. This is a damaging wait interval, not proof of a permanent decision lock.',
    'Enemy building destructions remain0; structural damage is not0. Enemy completed tower building-p2-defenseTower-1617 is observed at160/200 from9600 onward. Frame sampling alone does not identify every hit or its source.',
    'This diagnosis executes zero simulation ticks and issues no commands. Native route reachability and time estimates do not prove a counterattack survives; a normal-command full-AI control window is still needed.'
  ] };
const path = directory + 'knight-road-siege-diagnostic.json'; fs.writeFileSync(path, JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ path, bytes: fs.statSync(path).size, equality: equality.every(frame => frame.byteEqual && frame.allPlayerPoliciesEqual),
  frames: geometryFrames.map(frame => ({ tick: frame.tick, rawPower: frame.rawPower, availablePower: frame.availablePower,
    intrudedBuilding: frame.intrusion?.building.id, attackers: frame.intrusion?.attackers.map(unit => unit.id),
    waitsForTowers: frame.waitsForTowers, inputs: frame.waitInputs, defenseSource: frame.defenseSource, defense: frame.defense,
    towerCanFire: frame.towers.flatMap(tower => tower.attackers.filter(enemy => enemy.towerCanFireNow).map(enemy => [tower.id, enemy.id])) })),
  hallsLost: losses.filter(loss => loss.building.kind === 'townHall') }, null, 2));
