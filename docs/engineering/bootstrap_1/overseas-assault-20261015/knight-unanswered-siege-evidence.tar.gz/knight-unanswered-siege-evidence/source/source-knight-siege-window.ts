import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {bootstrapGame,bootstrapMatches} from '../src/ai/bootstrap_1/benchmark';
import {createAiMemoryProvider} from '../src/ai/planner-context';
import {createBootstrapCommandPlanner,frozenPolicyManifest} from '../scripts/bootstrap_1-planner';
import {runAiGameLoop} from '../src/ai/game-runner';
import {restoreSnapshotIntoGame,snapshotGame} from '../src/shared/sim';

const dir='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015';
const [label='knight-siege-control-from21000',startArg='21000',endArg='22800']=process.argv.slice(2);
const start=Number(startArg),end=Number(endArg);
const saved=JSON.parse(readFileSync(`${dir}/knight-${start===21000?'siege-before-wait':'siege-unanswered-towers'}.json`,'utf8'));
const match=bootstrapMatches(saved.setup.seed,['greystonePass'],end,true).find(match=>match.subject==='v9_knight'
 &&match.side===1&&match.agents.p0!.race==='ember'&&Object.values(match.agents).slice(1).map(agent=>agent.version).join('+')==='v8+v8')!;
const game=bootstrapGame(match);restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memory=createAiMemoryProvider(structuredClone(saved.memories)),planner=await createBootstrapCommandPlanner(memory);
const frames=`${dir}/${label}.json.frames`;mkdirSync(frames,{recursive:true});
const snapshot=()=>JSON.parse(JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,
 memories:Object.fromEntries(Object.keys(match.agents).map(owner=>[owner,memory.get(owner)]))}));
const hash=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex');
const rows:any[]=[],entries:any[]=[],hits:any[]=[];
const metadata={classification:'Complete three-player native AI focused window from actual fixed mobile-care match; no entities or orders changed, not ordinary opening or match victory',
 startTick:start,maxTick:end,setup:saved.setup,frozenPolicyManifest,sourceHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 sourceDiff:execFileSync('git',['diff','--','src/ai/bootstrap_1/mobile-care.ts','src/ai/bootstrap_1/mine-defense.ts'],{encoding:'utf8'}),
 sourceHashes:Object.fromEntries(['src/ai/bootstrap_1/mobile-care.ts','src/ai/bootstrap_1/mine-defense.ts','src/ai/policy/v6/general.ts'].map(path=>[path,hash(path)])),source:saved.provenance};
writeFileSync(`${dir}/${label}.metadata.json`,JSON.stringify(metadata,null,2));
const save=()=>{const current=snapshot();writeFileSync(`${frames}/${game.tick}.json`,JSON.stringify(current));
 rows.push({tick:game.tick,general:current.memories.p0.v6?.general,
 hall:current.snapshot.buildings.find((b:any)=>b.id==='building-p0-townHall-1529'),
 armies:current.snapshot.units.filter((u:any)=>u.kind!=='worker').map((u:any)=>({id:u.id,owner:u.owner,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,order:u.order})),
 stats:current.snapshot.match.stats});};
game.observer={hit(source,target,amount){if(target.id==='building-p0-townHall-1529'||target.id==='unit-p2-catapult-9831'||target.id==='unit-p2-catapult-13290')
 hits.push({tick:game.tick,source:source.id,target:target.id,amount,remainingHp:target.hp});}};
save();
runAiGameLoop({...match,game,commandPlanner:context=>{const planned=planner(context);if(context.owner==='p0')entries.push({tick:context.snapshot.tick,
 general:structuredClone(memory.get('p0')?.v6?.general),entries:planned.filter(entry=>['v6General','mobileCare','medicalRecovery'].includes(entry.scriptId))});return planned;}},{
 onStep:()=>{if(game.tick%300===0)save();}});
if(rows.at(-1)?.tick!==game.tick)save();
writeFileSync(`${dir}/${label}.json`,JSON.stringify({metadata,result:game.match,rows,entries,hits},null,2));
console.log(JSON.stringify({label,tick:game.tick,winner:game.match.winner,hall:game.buildings.find(b=>b.id==='building-p0-townHall-1529')?.hp,
 catapults:game.units.filter(u=>u.id==='unit-p2-catapult-9831'||u.id==='unit-p2-catapult-13290').map(u=>({id:u.id,hp:u.hp,x:u.x,y:u.y,order:u.order})),hits:hits.length}));
