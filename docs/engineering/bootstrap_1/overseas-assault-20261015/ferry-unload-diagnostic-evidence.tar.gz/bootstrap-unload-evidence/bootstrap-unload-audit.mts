import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const wd='/workspace/sketch-rts-reinforcement-control',root='/workspace/sketch-rts-bootstrap-resume/.playtest/overseas-assault-20261015',imp=(p:string)=>import(pathToFileURL(wd+'/'+p).href);
const[{createGame,restoreSnapshotIntoGame,snapshotGame},{landingSpot,passengerLandingSpot,LANDING_REACH},{shipProfile,shipPassengers,distanceToHull,localToWorld},{isOpenGround,isWalkable,walkableGoal,sameGround},{unitMover},{detCos,detSin}]=await Promise.all([imp('src/shared/sim.ts'),imp('src/shared/naval.ts'),imp('src/shared/ship-geometry.ts'),imp('src/shared/terrain.ts'),imp('src/shared/catalog.ts'),imp('src/shared/det-math.ts')]);
const files=['first-land-unit-p0-priest-2370-90571','first-land-unit-p0-archer-2782-90586','sample-90810','sample-91110','sample-91710','terminal-92400'];
const manifest=JSON.parse(readFileSync(root+'/archer-assault-reinforcement-v3-runtime-source.json','utf8'));
const sources=Object.fromEntries(['src/shared/sim.ts','src/shared/naval.ts','src/shared/terrain.ts','src/shared/ship-geometry.ts','src/shared/catalog.ts','src/shared/det-math.ts'].map(p=>{const sha=createHash('sha256').update(readFileSync(wd+'/'+p)).digest('hex');if(sha!==manifest.files[p])throw Error('source mismatch '+p);return[p,sha]}));
const out:any={scope:'Read-only exact existing landingSpot candidate enumeration and predicates on real manual boat-only diagnostic frames. No world stepping or commands. Counterfactual order/body omission below are query-only, not outcomes.',source:'archer-assault-reinforcement-v3-runtime-source.json',sourceFiles:sources,frames:[]};
for(const name of files){const file=root+'/archer-assault-current-shore.frames/'+name+'.json',raw=readFileSync(file),saved=JSON.parse(raw.toString()),game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);const before=JSON.stringify(snapshotGame(game)),ship=game.units.find((u:any)=>u.id==='unit-p0-carrier-3510'),crew=shipPassengers(game.units,ship);
 const frame:any={file,frameSha256:createHash('sha256').update(raw).digest('hex'),tick:game.tick,ship:{x:ship.x,y:ship.y,heading:ship.sailing.heading,speed:ship.sailing.speed,order:ship.order},crewCount:crew.length,queries:[]};
 for(const queryOrder of ['actual-order','original-unload']as const){const hull=queryOrder==='actual-order'?ship:{...ship,order:{type:'unload',x:2192,y:6096,avoidCombat:true}};
  const results=[];
  for(let index=0;index<crew.length;index++){const passenger=crew[index],radius=passenger.radius??12,profile=shipProfile(hull),angle=index/Math.max(1,crew.length)*Math.PI*2,edge=localToWorld(hull,{x:detCos(angle)*((profile?.length??hull.radius*2)/2+radius+2),y:detSin(angle)*((profile?.beam??hull.radius*2)/2+radius+2)}),shore=hull.order.type==='unload'?walkableGoal(game.map,hull.order.x,hull.order.y):undefined,preferred=shore??edge,nearest=walkableGoal(game.map,preferred.x,preferred.y),span=(profile?.length??hull.radius*2)/2+LANDING_REACH,step=game.map.terrain?game.map.terrain.cell/4:Math.max(8,radius),points=[nearest];
   for(let y=Math.max(step/2,Math.floor((hull.y-span)/step)*step+step/2);y<Math.min(game.map.height,hull.y+span);y+=step)for(let x=Math.max(step/2,Math.floor((hull.x-span)/step)*step+step/2);x<Math.min(game.map.width,hull.x+span);x+=step)points.push({x,y});
   const counts:any={total:points.length,bounds:0,terrain:0,openGround:0,targetComponent:0,bodyOutsideHull:0,hullReach:0,noGroundBody:0},blockers=new Map<string,any>(),accepted=[],geometric=[];
   let minimumOpenComponentGap=Infinity;
   for(const p of points){if(p.x<0||p.y<0||p.x>game.map.width||p.y>game.map.height)continue;counts.bounds++;
    if(!isWalkable(game.map,p.x,p.y))continue;counts.terrain++;
    if(!isOpenGround(game.map,p.x,p.y))continue;counts.openGround++;
    if(shore&&!sameGround(game.map,shore,p))continue;counts.targetComponent++;
    const gap=distanceToHull(hull,p);minimumOpenComponentGap=Math.min(minimumOpenComponentGap,gap);
    if(gap<radius+1)continue;counts.bodyOutsideHull++;
    if(gap>LANDING_REACH)continue;counts.hullReach++;geometric.push({p,gap});
    const blocking=game.units.filter((u:any)=>u!==passenger&&!u.deck&&unitMover(u.kind)==='land'&&Math.hypot(p.x-u.x,p.y-u.y)<radius+u.radius+1);
    if(blocking.length){for(const u of blocking){const record=blockers.get(u.id)??{id:u.id,owner:u.owner,kind:u.kind,x:u.x,y:u.y,radius:u.radius,order:u.order,count:0};record.count++;blockers.set(u.id,record);}continue;}counts.noGroundBody++;accepted.push(p);
   }
   const spot=landingSpot(game.map,hull,index,crew.length,game.units,passenger),noBodies=landingSpot(game.map,hull,index,crew.length,game.units.filter((u:any)=>u.deck||unitMover(u.kind)!=='land'),passenger);
   if(Boolean(spot)!==Boolean(accepted.length))throw Error('enumeration mismatch '+game.tick+' '+passenger.id);
   const direct=passengerLandingSpot(game.map,hull,passenger.id,game.units);if(JSON.stringify(spot)!==JSON.stringify(direct))throw Error('helper mismatch');
   results.push({id:passenger.id,owner:passenger.owner,kind:passenger.kind,radius,order:passenger.order,cabin:passenger.cabin,counts,spot:spot??null,queryWithoutGroundUnitBodies:noBodies??null,minimumOpenComponentGap:Number.isFinite(minimumOpenComponentGap)?minimumOpenComponentGap:null,blockers:[...blockers.values()].sort((a,b)=>b.count-a.count),geometricCandidateExamples:geometric.slice(0,8),acceptedCandidateExamples:accepted.slice(0,8)});
  }
  frame.queries.push({queryOrder,passengers:results});
 }
 frame.snapshotUnchanged=JSON.stringify(snapshotGame(game))===before;out.frames.push(frame);
}
writeFileSync('/tmp/bootstrap-unload-audit.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify(out.frames.map((f:any)=>({tick:f.tick,ship:f.ship,crew:f.crewCount,queries:f.queries.map((q:any)=>({order:q.queryOrder,summary:q.passengers.map((p:any)=>({id:p.id,counts:p.counts,spot:p.spot,withoutGroundBodies:p.queryWithoutGroundUnitBodies,minGap:p.minimumOpenComponentGap,blockers:p.blockers.map((b:any)=>({id:b.id,owner:b.owner,count:b.count}))}))})),snapshotUnchanged:f.snapshotUnchanged})),null,2));
