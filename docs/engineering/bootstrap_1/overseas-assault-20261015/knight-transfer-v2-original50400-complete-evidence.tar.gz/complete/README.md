# Fixed V2: untouched original50400 to natural85866 win

This is a changed-code continuation of the original ordinary clean6f80 knight-v5 sapphire game. It is not a new ordinary0 run, old loading-only history, patched62400 history, unseen seed, or bootstrap acceptance result. Start50400 is the untouched original full world + nextId + both complete owner memories, with original frame SHA and original report memory provenance checked. Same normal frozen v5, Grove v9_knight, rules2,15tick thinking, map sapphireArchipelago and original seed. Original lost-container uncommitted changes remain unavailable. No root/main/other active source was edited.

## Source and run

Fixed source6f80a9365e591cbfba9148260806cd4f9033788e plus only loading escort station and transfer-lanes V2. Combined captured patch is provenance/knight-escort-transfer-v2-source.patch. V2 allows the existing deck yield routine to handle a legal-capacity/static-floor receiver currently blocked by another passenger; the actual board command still requires real occupied canBoard and a complete connected path. It preserves native non-ship/non-cabin passenger permissions, including legal air passengers, and changes no engine/rules/ship/repair priority. Do not use the earlier rejected V1 land-only guard.

Live PID215923 ran50400→85866 uninterrupted,535209.89ms elapsed/546629.89ms CPU. Natural p0 winner, source865 pre/post/current exact; frozen184 unchanged against d1ae110f2edd99f9c7d899ed61557891ab587639. These process timings are not a stable performance benchmark. Source archive SHA2cf46adc97108d59b77c7a0fb8e96d14a5b699223a6772409103cdc910c2a8a8.

77 full gzip frames preserve complete world/nextId/both memories: every1200 ticks, every original17 deck/life status transition, ship removal/building death, terminal. Original17 metadata, public commands, actual hit ledger and ship fatal-hit/beforeStep passenger ledger are included. The maximum horizon was not used as a stop; natural winner arrived before144000.

## First-wave failure stays visible

At51209 all original17 are aboard. Initial east approach: first automatic enemy-island landing56626; two simultaneous first at56694, initial three exposed knights all dead56902. Through58313 original17 are10 dead +7 deck, with no enemy building damage. This early two-person maximum is not the whole-wave maximum. Surviving seven later approach:60658 onward disembark one by one,60739 has6 actual enemyLand +1 deck +10 dead;60886 all off-deck,61068 all17 dead. Seven other early death-event frames retain stale sailing load/balance after passenger deaths. Firstlanding audit is scoped to the initial east approach; later whole-wave results in summary.json/final-native-analysis.json supersede any over-broad reading.

Firstlanding audit uses real public logs/native queries and no simulation.56400 two ships405.10 direct/435.2 sea;56626 they are580.63/595.2 apart.1046 has real shore support while the carrier has none. No public unload or unloadPassenger caused the initial automatic departure. Current boat cannot safely deploy its local8.271 power against21.357 required; total incoming25.49 is larger, but the joint unload gate did not pass. The mission target moved far enough that boat distance901.781 is outside the900 near-goal check at saved56626. Native automatic attack/walkConnectedSurfaces or settleDeckSupport can drop the deck relation, but no original56625 full frame exists; the precise first deletion call remains unproved. No risk threshold was weakened and no forced placement/intent repair was used.

The failed original17 still killed14 enemy units:6sparkArcher,3spirit,2summoner,1ashHexer,1priest,1empty transport. These are actual fatal hits, not inferred combat ratings. A defending outpost tower then killed7sparkArcher+1worker at67704..68514. There were no new neutral kills/losses in this continuation. Hence the enemy later faced a substantially different battle; the winning second wave is not proof that the first wave was repaired.

## Later effective landing and terminal

At84630 both carrier4595 and carrier4715 issue public unload plus13 actual unloadPassenger commands: carrier4715 holds11 old units (5lancer,2raider,1knight,1priest,1worker,1ballista); carrier4595 holds2new knights. In the independently reconstructed84630 pre-think state, both ships are within the existing450 direct-and-sea selection, combined effective power17.116932 versus required3.269804. This is native existing policy computation on a clone, not a new risk model or permission to lower thresholds. The13 public commands and all subsequent shots are recorded in the original live history.

84797 first damage to any enemy building,84863 first building destroyed. All15 buildings are destroyed by85866, including shipyard85390 and townHall900HP last at85866. Native84000 and85866 visuals were personally inspected: the later loaded fleet reaches the north coast, then the army remains on actual enemy ground and clears the base. First eastern approach images are separate.

Terminal p0:41 units,28 buildings,4 halls all900HP. p1:9 units (7sparkArcher,1worker,1transport),0 buildings/0halls. Normal match win does not mean complete extermination. Whole p0loss19 = original17 + empty1046/1101; p1loss31. One p1 sparkArcher death is friendly transport collision, so p0 unitsKilled30 and p1unitsLost31 correctly differ. All three removed ships (two p0/one p1) have empty passenger lists both before the fatal step and at fatal hit; no permanent ship passenger is unaccounted for. Native Grove witch is not a hired mercenary. There are no initial hired mercenary types or hire commands in this continuation and no mercenary contribution is claimed.

## Maintenance effects and remaining blockage

Worker1851 receives real board1139 / repairShip1139 / board1935 / repairShip1935 commands at54210/54240/54285/55020. The old transfer blockage genuinely clears in this distinct earlier-start history. Witch2089 moves out of the actual worker crossing and survives. Later repairs recur; at67200 worker starts another board1935 from cutter1139. By85866 both hulls are again occupied by this rendezvous, worker still aboard cutter and both ships at speed0. This is recorded as an unresolved later maintenance boundary, without changing service priority or claiming that all escort capacity is recovered.

## Comparisons and strict closure

Use native-reference-comparison.json for existing original ordinary0 comparison; no baseline was re-run. Starting50400 unitsLost is zero for both, so explicit50400→own-terminal increments are new19/31 vs original43/27. Original clean6f80 naturally wins135692; changed continuation85866 is49826ticks earlier on this one trajectory. Original interval has21 p0 losses to neutral and3 p0 buildings lost; this continuation has0/0. Neither comparison is a new ordinary0 score, a guarantee of generalization, or three-route acceptance. Existing original final frame+bothmem is copied as reference-original135692.json.gz, not re-simulated. Sparse saved-frame first-land observations are bounds, not claims about unrecorded ticks.

Independent same-source replay84000→85200 exactly matches world/nextId/bothmem,90public commands and119hits. It reconstructs84630/84631 JSON with an explicit derived label; these are not original live event frames. Terminal replay85200→85866 exactly matches world/nextId/bothmem,50commands,156hits and same natural winner. Replay validation is not another scored game.

All30 periodic1200 frames and terminal restore exact world/nextId/bothmem. All77 have exact nextId/bothmem; seven death-event frames fail only real cached sailing load/balance restoration. They are retained as raw event evidence and cannot serve as independently exact continuation origins. No restore/engine/rules changes were made. The initial50400 and both replay start frames are exact.

Raw report.rows historical stats/naval fields retained live object references in the observer. Do not use those old convenience rows for history. final-native-analysis.json and progress-native.json read each serialized full gzip frame and freeze those values correctly; raw report is preserved, not rewritten to hide the limitation.

## Checks and related evidence

TypeScript tsc --noEmit passed. Existing5files/32tests passed: src/ai/policy/transfer-lanes.test.ts, naval-cover.test.ts, naval-services.test.ts; src/ai/bootstrap_1/deck-transfer-snapshot.test.ts; src/shared/connected-decks.test.ts. No new test was added in the immutable V2 source. The snapshot test took65.6seconds under the concurrent replay workload; it passed.

related-sealed-evidence.json pins the already sealed26,594,423byte loading-only negative history and14,189,015byte exact-input native62400 repair-positive/counter package bySHA256. Selected counter/positive terminal states/results are included here; the complete prior histories remain in those immutable packages. Do not merge their patched62400 timeline into this original50400 run. SourceV1 guard rejection and initial restore failure evidence remain in those packages.

The transient full/tmp sandbox launch failure happened only after this live game had saved its natural terminal and source postflight. Root freed only ended duplicated tracked assets; no evidence or running source was removed. There is no remaining execution/permission blocker. Unfinished work includes native automatic early deck separation, renewed maintenance rendezvous, defeated-enemy cleanup, and all outstanding three-route fullmatch/generalization requirements. The original missing uncommitted workspace gap remains open.
