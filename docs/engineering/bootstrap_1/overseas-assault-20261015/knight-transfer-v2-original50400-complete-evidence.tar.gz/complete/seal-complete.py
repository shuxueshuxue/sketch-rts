from pathlib import Path
import json,hashlib,tarfile
D=Path('/tmp/bootstrap-knight-full-v2-original50400-20261015');G=Path('/tmp/bootstrap-deployment-gate');E=Path('/tmp/bootstrap-knight-escort-transfer-20261015');A=Path('/tmp/bootstrap-knight-firstlanding-audit-20261015')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((D/'report.json').read_text());s=json.loads((D/'summary.json').read_text());cap=json.loads((G/'knight-escort-transfer-v2-source.json').read_text())
assert r['completed']and r['winner']=='p0'and r['currentTick']==85866 and r['sourcePre']and r['sourcePost']and s['sourceNow']
assert all(r['restore'].values())and all(r['provenance']['provenanceCheck'].values())
assert s['frameRestoreAudit']['periodicAll']and all(s['terminalClosure']['checks'].values())and all(s['jointClosure']['checks'].values())
assert len(s['frameRestoreAudit']['failures'])==7
assert all(sha(Path(cap['worktree'])/p)==h for p,h in cap['files'].items())
assert all(not line.strip()or line.startswith('npm notice')for line in (D/'tsc-final.log').read_text().splitlines())
assert json.loads((D/'compiler-check.json').read_text())['exitCode']==0
assert 'Tests  32 passed (32)'in(D/'focused-existing-tests.log').read_text()
payload={}
for p in sorted(D.rglob('*')):
 if p.is_file()and p.name!='payload-index.json'and not p.name.startswith('view-'):payload['complete/'+str(p.relative_to(D))]=p
for p in sorted(A.glob('*')):
 if p.is_file():payload['first-eastern-approach-audit/'+p.name]=p
for stem in ['knight-escort-transfer-v2','knight-loading-escort-v1']:
 for suffix in ['.json','.patch','.tar.gz']:payload['provenance/'+stem+'-source'+suffix]=G/(stem+'-source'+suffix)
for filename in ['summary-v2.json','README-v2.md','transfer-v2-only.patch','transfer-only.patch','v1-readonly-postflight.json','v2-service-query.json','stage-query.json']:
 payload['prior-native-counter/'+filename]=E/filename
for variant in ['v2','counter']:
 for filename in ['result.json','after-63600.json.gz']:payload['prior-native-counter/'+variant+'/'+filename]=E/(variant+'-native62400')/filename
payload['prior-native-counter/input-counter62400.json']=E/'input-counter62400.json'
index={name:{'originalPath':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for name,p in payload.items()};(D/'payload-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=G/'knight-transfer-v2-original50400-complete-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for name,p in payload.items():t.add(p,arcname=name,recursive=False)
 t.add(D/'payload-index.json',arcname='payload-index.json')
verified=[]
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(index)+1
 for name,meta in index.items():
  data=t.extractfile(name).read();assert len(data)==meta['bytes']and hashlib.sha256(data).hexdigest()==meta['sha256'];verified.append(name)
 assert json.load(t.extractfile('payload-index.json'))==index
proof={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'payloadFiles':len(index),'readBackAllBytesAndSHA256':len(verified)==len(index),'terminal':{'start':50400,'tick':85866,'winner':'p0','classification':r['provenance']['classification']},'sourceArchiveSHA256':r['provenance']['sourceArchiveSHA256'],'sourcePrePostCurrent':True,'frozenVerified':184,'periodicFullRestoreAll':True,'terminalClosureAll':True,'jointClosureAll':True,'knownDeathEventRestoreExceptions':7,'relatedSealedEvidence':json.loads((D/'related-sealed-evidence.json').read_text())}
(G/'knight-transfer-v2-original50400-complete-archive.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
