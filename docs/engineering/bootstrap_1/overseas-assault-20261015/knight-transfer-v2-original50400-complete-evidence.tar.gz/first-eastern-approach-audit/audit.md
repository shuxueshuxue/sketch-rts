# 首次敌岛登陆只读审计

结论：首波没有发生协调的原生卸载。最初只有三名 transport 1046 的骑士先后从接岸的甲板进入敌岛，最多同时两人；其余乘客仍在甲板。它们的自动攻击与原生支持面行走/甲板归属整理机制吻合。公开命令、船速与船令排除了这次首次离船由 `unload`/`unloadPassenger` 执行的解释。缺少 56625 完整前状态，无法确定 `walkConnectedSurfaces` 与 `settleDeckSupport` 中哪一个调用实际首次删除了 knight3674 的 deck，也无法精确定位两船突破 450 距离的那一 tick。

同一完整固定 V2 真局后来在 85866 自然 p0 胜（report.completed=true、sourcePost=true）。这个末局结果不使首波成为联合登陆成功；父任务另行负责终局清算。

## 范围和证据完整性

- 只读取 `/tmp/bootstrap-knight-full-v2-original50400-20261015` 的完整 `frames/*.json.gz`、公开 commands/hits/events 以及权威冻结 `progress-native.json`。没有从活动 report.rows 的 stats/naval 引用推断历史。
- 固定源码 `/tmp/sketch-rts-knight-escort-transfer-v2-control` 的 865 文件哈希在 native 查询前后均匹配 `/tmp/bootstrap-deployment-gate/knight-escort-transfer-v2-source.json`。
- `query-native.mts` 在 23 个截至 58313 的独立 JSON 克隆上调用原生 terrain/naval/connected-decks/assault-beach 只读查询；没有导入或调用 sim、恢复世界、执行命令、step、重演、游戏或矩阵。23 帧原17分类全部与 progress-native 冻结分类一致。
- `query-power.mts` 在七个独立保存帧上调用原生 `assaultExpedition`、`effectiveCombatRating`、`walkingDistance`、`sameGround`；因 `nearbyAssaultCrew` 是私有函数，450 邻船筛选表达式逐项照源码实现，并明确标为保存帧输入查询，而非不可见 AI tick 的调用记录。

## 联合门槛与实际分离

| 保存帧 | 两船直线/原生海路 | 原17在甲板/敌岛/死亡 | 当前 450 邻船集合 |
| --- | --- | --- | --- |
| 51600 | 2236.658 / 2387.2 | 17 / 0 / 0 | 分离 |
| 52800 | 563.253 / 588.8 | 17 / 0 / 0 | 分离 |
| 55200 | 467.630 / 448 | 17 / 0 / 0 | 各自只有自己：直线仍大于450 |
| 56400 | 405.100 / 435.2 | 17 / 0 / 0 | 两船都在集合内 |
| 56626 | 580.630 / 595.2 | 16 / 1 / 0 | 各自只有自己 |
| 56694 | 566.223 / 608 | 15 / 2 / 0 | 各自只有自己 |
| 56739 | 544.583 / 576 | 14 / 2 / 1 | 各自只有自己 |
| 56902 | 395.493 / 403.2 | 14 / 0 / 3 | 两船重新都在集合内 |

在所存帧中，56400 集合恢复成立，至 56626 已再次拉散。精确离开门槛的时刻在这两帧之间，不能用记忆 progress 字段反推成完整 56625 世界。

`commands.jsonl` 行331/332，56385：两船改 `move(2512,6576,avoidCombat)`。行334/335，56400：两船再改 `move(1776,5776,avoidCombat)`。56400 是命令前保存帧，其旧 mission.to=(2448,6576)、approach=(2512,6576)。56626 帧两船 mission.to=(1776,5808)、approach=(1776,5776)，均 phase=sailing；1046 在 (2593.446,6188.776)、speed=45.686；4595 在 (3095.760,6480)、speed=21.496。给同一目标并没有使两种船保持同速/同一接岸姿态。

两层门槛必须区分：

1. `src/ai/policy/naval.ts:773`：只有 rally 存在或距 mission.to<900 才检查近450军力。56400 两船近军力26.091>=required20.726；56626 两船各自近军力（含已上岸骑士）8.271/18.826，均低于required21.357，但各自距 goal901.781/1480.997且没有rally，这个保存帧的900激活条件不成立。不能据此断言缺失的56625精确分支；随后公开56655行381/382开始共同避险rally move，56694记忆已有rally。需要的全编队军力仍存在，并不等于已经共同接岸。
2. `src/ai/bootstrap_1/assault-beach.ts:128`：先要求本船当前姿态能让全船实际身体上岸且 guards=0，之后才形成直线及海路都<=450的局部convoy；只有 `!landed && convoy.length>1` 才检查多船同时身体和停船。它不是对所有同目标船的持续硬门槛，也不拦截原生甲板追敌走岸。

56626 原生 `shipShorePoints` 给1046找到19个属于敌岛的接岸采样点，carrier为0；当前姿态的原生 `assaultBeachExposure` 假设停船卸载查询能给1046余下五人安排位置，但返回21名火力覆盖 guards，carrier查询无完整落位。两船实际 `currentBerthLandings=[]`（船令是move）。因此那一帧没有通过零暴露卸载入口，多船同时门槛也没有执行；不能把局部集合只有自己直接称作一次实际“单船卸载放行”。

## 首次离船的机制边界

50400..58313 公开日志中与这两船或原17相关的105条p0命令里，`unload`、`unloadPassenger`、`board` 均为0。首位骑士离船前，原17也没有收到任何直接p0命令。

- 56625 p0公开命令仅行371的 warship1101 move；没有1046/4595或乘客命令。
- 56626 knight3674 已无deck，(2532.410,6201.937)，原生 `isWalkable(land)` 且 `sameGround(enemy shipyard)`，HP254，order为attack enemy sparkArcher1874并带leash。这个leash与原生自动寻敌分支一致。
- `src/shared/sim.ts:1484`：非worker普通单位在空闲分支自动寻找敌人并发出带leash的attack，没有把“正在船上”排除。
- `src/shared/naval.ts:27`：甲板攻击者只要船的接岸点属于敌人地面，就可 `canReach`，没有要求船正在卸载或已经停住。
- `src/shared/sim.ts:1718`、`:4531`：攻击追击进入moveToward；该函数先尝试原生 `walkConnectedSurfaces`。
- `src/shared/connected-decks.ts:187`、`:350`：连接支持面路径可包含岸地；人身体落在陆地支持面时删除deck。`:390` 的 settleDeckSupport也可在安全陆地全身支持时删除deck。
- 普通 ferry 卸载要求实际船令unload与停船（`sim.ts:1966`）；portrait卸载必须有公开unloadPassenger命令。这两条都与首离船证据不符。

因此可以确认“非显式卸载的原生甲板/岸支持面离船，伴随自动攻击”。精确删除deck的调用点仍未证；没有人工反推缺失前状态。当前保存帧中，其他甲板攻击者可达敌岛但connectedSurfacePath多为不完整，符合个体身体与拥堵造成逐个过岸的可能性，不能据这些后帧把56625路径重建成证据。

一旦首位骑士被记录为landed，`reviseAssaultBeaches` 的“已有非worker己方land同ground”判断会跳过重新选滩；同时卸载分支的 `!landed` 条件也不再成立。这是代码作用域事实，不是本次成功进入该分支的证明。

## 为什么少量登陆仍失败

真实状态转移：56626 knight3674第一人；56694 knight2955第二人；56721 knight3674死亡；56739 knight3673第三人。最多同时两人，首次两人帧是56694，56739换成2955+3673。56902起三名已上岸骑士全部死亡，其他原17仍未组成岛上军队。

| 原17死亡tick | 单位 | 致命来源（hits.jsonl行） |
| --- | --- | --- |
| 56721 | knight3674 | sparkArcher1818（168） |
| 56854 | knight2955 | sparkArcher1099（385） |
| 56902 | knight3673 | sparkArcher1671（464） |
| 57021 | priest2356 | sparkArcher1310（545） |
| 57077 | knight2555 | sparkArcher1047（594） |
| 57084 | worker1774 | sparkArcher1285（600） |
| 57305 | ballista3254 | summoner1696（723） |
| 57468 | raider3490 | sparkArcher1099（783） |
| 57808 | knight2554 | sparkArcher1121（1071） |
| 58313 | priest2013 | sparkArcher1722（1148） |

原生实际姿态卸载暴露查询在56626/56694/56739分别返回21/25/25名guards；这只表示至少一个候选落地身体在其武器覆盖内，不表示所有人同tick开火。真实hits直接证明少量登陆骑士被多名敌人持续攻击。余下transport三名乘客直接在甲板死亡，status日志没有离船或换船过程；57105空船stop，57120返航move，57326 sparkArcher1047致命6伤害（hits行732），events明确 `passengersAtFatalHit:[]`。不是沉船淹死了这六名乘客。

58313的权威完整帧：原17为10死+7甲板+0敌岛；敌方14楼均hp=maxHp。原17在本窗口没有形成有效登陆据点。公开指令无伤员board/transfer；已有完整帧无deck跨船改变或cabin状态，因此没有证据支持“医疗/转船命令导致首次少量登陆”。后续终局胜由父任务另行分析。

## 交付物与剩余不确定性

`native-queries.json` 保留23帧真实船令、航路、mission、速度、原生海路、岸支持、暴露与甲板攻击路径查询；`power-queries.json` 保留近450军力及900激活输入；`log-evidence.json` 保留105条公开命令和致命hits的原文件行号；两份query脚本可复核。环境/tmp满曾暂时阻止默认exec启动，失败说明在environment-blocker.txt，后来恢复，未由本审计删除共享资料。

唯一关键机制缺口是56625完整前状态与逐函数运行跟踪，因此不声称证明首次删除deck的具体函数、精确自动攻击获取tick、或两船恰好越过450的tick。本审计没有通过重演填补缺口。
