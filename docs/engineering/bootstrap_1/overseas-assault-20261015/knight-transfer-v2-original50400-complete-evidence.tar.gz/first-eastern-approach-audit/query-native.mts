import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const D='/tmp/bootstrap-knight-full-v2-original50400-20261015';
const O='/tmp/bootstrap-knight-firstlanding-audit-20261015';
const W='/tmp/sketch-rts-knight-escort-transfer-v2-control';
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href);
const [{sameGround,isWalkable,isOpenGround,setBuildingBodies,walkingDistance},
  {shipShorePoints,connectedSurfacePath,decksCanTransfer},
  {currentBerthLandings,canReach,passengerLandingSpot},
  {assaultBeachExposure}, {shipPassengers,shipProfile,distanceToHull}]
 =await Promise.all([imp('src/shared/terrain.ts'),imp('src/shared/connected-decks.ts'),imp('src/shared/naval.ts'),
 imp('src/ai/bootstrap_1/assault-beach.ts'),imp('src/shared/ship-geometry.ts')]);
const clone=(x:any)=>JSON.parse(JSON.stringify(x));
const src=JSON.parse(readFileSync('/tmp/bootstrap-deployment-gate/knight-escort-transfer-v2-source.json','utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const verify=()=>Object.entries(src.files).every(([p,h])=>hash(`${W}/${p}`)===h);
const before=verify();
const wave=JSON.parse(readFileSync(`${D}/original-first-wave-17.json`,'utf8'));
const init=JSON.parse(gunzipSync(readFileSync(`${D}/input-original50400.json.gz`)).toString());
const target=init.snapshot.buildings.find((b:any)=>b.id==='building-p1-shipyard-1016');
const home=init.snapshot.buildings.find((b:any)=>b.id==='building-p0-townhall');
const ticks=readdirSync(`${D}/frames`).map(p=>Number(p.split('.')[0])).filter(t=>t<=58313).sort((a,b)=>a-b);
const frames=[];
for (const tick of ticks){
 const raw=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${tick}.json.gz`)).toString());
 const s=clone(raw.snapshot);setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const byId=new Map(s.units.map((u:any)=>[u.id,u]));
 const status=(u:any)=>!u?'absentDead':u.deck?'deck':u.cabin?'cabin':!isWalkable(s.map,u.x,u.y,'land')?'offDeckNonwalkable':sameGround(s.map,u,target)?'enemyLand':sameGround(s.map,u,home)?'homeLand':'otherLand';
 const crew=wave.crewIds.map((id:string)=>{const u:any=byId.get(id);return !u?{id,status:'absentDead'}:{id,status:status(u),kind:u.kind,hp:u.hp,x:u.x,y:u.y,deck:u.deck,cabin:u.cabin,gangway:u.gangway,order:u.order};});
 const boats=[];
 for (const id of wave.boats){
  const boat:any=byId.get(id);if(!boat){boats.push({id,absent:true});continue;}
  const mission=raw.memories.p0.naval?.ferries?.[id];
  const shore=shipShorePoints(boat,s.map);
  const passengers=shipPassengers(s.units,boat);
  const context={memory:clone(raw.memories.p0)};
  const q=clone(s);setBuildingBodies(q.map,[...q.buildings,...(q.obstacles??[])]);
  const qb=q.units.find((u:any)=>u.id===id);
  const exposure=mission && assaultBeachExposure(q,'p0',context,qb,mission.to,target,true);
  const paths=passengers.filter((u:any)=>u.order.type==='attack').map((passenger:any)=>{
    const quarry:any=byId.get(passenger.order.targetId) ?? s.buildings.find((b:any)=>b.id===passenger.order.targetId);
    if(!quarry)return {passengerId:passenger.id,targetId:passenger.order.targetId,missingTarget:true};
    const sc=clone(s);setBuildingBodies(sc.map,[...sc.buildings,...(sc.obstacles??[])]);
    const u=sc.units.find((u:any)=>u.id===passenger.id),b=sc.units.find((u:any)=>u.id===id),t=sc.units.find((u:any)=>u.id===quarry.id) ?? sc.buildings.find((u:any)=>u.id===quarry.id);
    const goal={x:t.x,y:t.y}; // For attack orders sim.deckGoal returns the input goal unchanged.
    const path=connectedSurfacePath(u,goal,sc.units,sc.map);
    return {passengerId:u.id,targetId:t.id,goal,path:path??null,canReach:canReach(sc.map,u,t,sc.units)};
  });
  const convoy=s.units.filter((other:any)=>{
   const a=raw.memories.p0.naval?.ferries?.[other.id];
   if(other.owner!=='p0'||a?.purpose!=='assault'||a.phase!=='sailing'||a.targetId!==mission?.targetId||!shipPassengers(s.units,other).length)return false;
   const road=walkingDistance(s.map,boat,other,'sea');
   return Math.hypot(boat.x-other.x,boat.y-other.y)<=450 && road!==undefined&&road<=450;
  }).map((u:any)=>u.id);
  boats.push({id,x:boat.x,y:boat.y,hp:boat.hp,order:boat.order,motion:{speed:boat.sailing.speed,velocityX:boat.sailing.velocityX,velocityY:boat.sailing.velocityY,heading:boat.sailing.heading},
   route:boat.sailing.route?{goalX:boat.sailing.route.goalX,goalY:boat.sailing.route.goalY,partial:boat.sailing.route.partial,end:boat.sailing.route.end,points:boat.sailing.route.points,blockedTicks:boat.sailing.route.blockedTicks,age:boat.sailing.route.age}:undefined,
   mission,crew:passengers.map((u:any)=>u.id),shorePoints:{count:shore.length,enemyGround:shore.filter((p:any)=>sameGround(s.map,p,target)).length,points:shore},
   currentBerthLandings:currentBerthLandings(s.map,boat,mission?.to??target,s.units),
   perPassengerLandingAtActualOrder:passengers.map((u:any)=>({id:u.id,point:passengerLandingSpot(s.map,boat,u.id,s.units)??null})),
   exposureAtCurrentPose:exposure?{landed:exposure.landed.map((u:any)=>({id:u.id,x:u.x,y:u.y})),guards:exposure.guards.map((u:any)=>({id:u.id,kind:u.kind,x:u.x,y:u.y}))}:null,
   nativeConvoyWithin450:convoy,attackConnectedSurfacePaths:paths});
 }
 const a:any=byId.get(wave.boats[0]),b:any=byId.get(wave.boats[1]);
 frames.push({tick,crew,counts:Object.fromEntries(['deck','cabin','enemyLand','homeLand','otherLand','offDeckNonwalkable','absentDead'].map(k=>[k,crew.filter((u:any)=>u.status===k).length])),boats,
  boatDistance:a&&b?{euclidean:Math.hypot(a.x-b.x,a.y-b.y),seaRoad:walkingDistance(s.map,a,b,'sea'),sameSea:sameGround(s.map,a,b,'sea'),knightCanTransfer:decksCanTransfer(a,b,s.units.find((u:any)=>u.kind==='knight'&&u.owner==='p0'))}:null,
  unloadEffects:s.effects.filter((e:any)=>e.kind==='unload'||e.type==='unload'),
  p1Buildings:s.buildings.filter((b:any)=>b.owner==='p1').map((b:any)=>({id:b.id,kind:b.kind,hp:b.hp,maxHp:b.maxHp})),stats:clone(s.match.stats)});
}
const result={classification:'Read-only native queries on independent JSON clones of saved full frames; no game restoration, planner, command execution, stepping, replay, or synthetic predecessor.',missingFrame56625:!ticks.includes(56625),sourcePre:before,sourcePost:verify(),sourceFiles:Object.keys(src.files).length,frames};
writeFileSync(`${O}/native-queries.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({sourcePre:result.sourcePre,sourcePost:result.sourcePost,frames:frames.length,rows:frames.filter(f=>f.tick>=56400).map(f=>({tick:f.tick,counts:f.counts,boatDistance:f.boatDistance,boats:f.boats.map((b:any)=>({id:b.id,absent:b.absent,speed:b.motion?.speed,order:b.order?.type,shore:b.shorePoints?.enemyGround,convoy:b.nativeConvoyWithin450,exposure:b.exposureAtCurrentPose?{landed:b.exposureAtCurrentPose.landed.length,guards:b.exposureAtCurrentPose.guards.length}:null,attackPaths:b.attackConnectedSurfacePaths?.map((p:any)=>({id:p.passengerId,canReach:p.canReach,path:p.path?{complete:p.path.complete,points:p.path.points.length}:null}))}))}))},null,2));
