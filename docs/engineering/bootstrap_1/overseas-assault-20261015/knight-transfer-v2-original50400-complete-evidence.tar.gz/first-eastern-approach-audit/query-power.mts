import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const W='/tmp/sketch-rts-knight-escort-transfer-v2-control',D='/tmp/bootstrap-knight-full-v2-original50400-20261015',O='/tmp/bootstrap-knight-firstlanding-audit-20261015';
const imp=(p:string)=>import(pathToFileURL(`${W}/${p}`).href);
const [{sameGround,walkingDistance,setBuildingBodies},{assaultExpedition},{effectiveCombatRating},{shipPassengers}]=await Promise.all([imp('src/shared/terrain.ts'),imp('src/ai/policy/naval.ts'),imp('src/ai/policy/v6/strength.ts'),imp('src/shared/ship-geometry.ts')]);
const rows=[];
for(const tick of [55200,56400,56626,56694,56721,56739,56902]){
 const f=JSON.parse(gunzipSync(readFileSync(`${D}/frames/${tick}.json.gz`)).toString()),s=f.snapshot;
 setBuildingBodies(s.map,[...s.buildings,...(s.obstacles??[])]);
 const mem=f.memories.p0,own=s.units.filter((u:any)=>u.owner==='p0'),target=s.buildings.find((u:any)=>u.id==='building-p1-shipyard-1016');
 const exp=assaultExpedition(s,'p0',{memory:mem},target);
 const landed=own.filter((u:any)=>!u.deck&&u.kind!=='worker'&&!u.expiresTick&&sameGround(s.map,u,target));
 const power=(u:any[])=>u.filter(u=>u.kind!=='worker'&&!u.expiresTick).reduce((sum,u)=>sum+effectiveCombatRating(s,u),0);
 const boats=own.filter((u:any)=>['unit-p0-transport-1046','unit-p0-carrier-4595'].includes(u.id)).map((boat:any)=>{
   const mission=mem.naval.ferries[boat.id];
   const nearby=own.filter((ship:any)=>{
    const other=mem.naval.ferries[ship.id];
    if(!other||other.purpose!=='assault'||other.phase==='return'||other.targetId!==mission?.targetId)return false;
    if(ship.id===boat.id)return true;
    if(Math.hypot(boat.x-ship.x,boat.y-ship.y)>450)return false;
    const road=walkingDistance(s.map,ship,boat,'sea');return road!==undefined&&road<=450;
   });
   const convoy=own.filter((ship:any)=>mem.naval.ferries[ship.id]?.purpose==='assault'&&mem.naval.ferries[ship.id]?.phase==='sailing'&&mem.naval.ferries[ship.id]?.targetId===mission.targetId&&sameGround(s.map,boat,ship,'sea'));
   return {id:boat.id,distanceToGoal:Math.hypot(boat.x-mission.to.x,boat.y-mission.to.y),hasRally:!!mission.rally,nearbyShips:nearby.map((u:any)=>u.id),nearbyAndLandedPower:power([...nearby.flatMap((b:any)=>shipPassengers(s.units,b)),...landed]),incomingPower:power([...convoy.flatMap((b:any)=>shipPassengers(s.units,b)),...landed]),landedPower:power(landed)};
 });
 rows.push({tick,required:exp.required,ready:exp.ready,boats});
}
writeFileSync(`${O}/power-queries.json`,JSON.stringify({classification:'Read-only independent saved-frame JSON clones. Native assaultExpedition and effectiveCombatRating; private nearbyAssaultCrew selection copied exactly from source lines1026-1035, with native walkingDistance/sameGround. These are saved-frame gate inputs, not unseen policy-tick outputs.',rows},null,2)+'\n');
console.log(JSON.stringify(rows,null,2));
