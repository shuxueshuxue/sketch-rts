import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {setBuildingBodies,groundTravelCost} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/shared/terrain.ts';
import {groundSteeringRoute} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/shared/route-selection.ts';
import {strikeGap} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/shared/combat-geometry.ts';
import {retreatThreatReach} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/ai/bootstrap_1/safe-land-route.ts';
import {SIM_TICKS_PER_SECOND} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/shared/time.ts';
import {pointSegmentDistanceSquared} from '/workspace/sketch-rts-archer-firstuse-38f-control/src/shared/navigation-math.ts';
const D='/tmp/bootstrap-archer-38f-losses-27000-33000-readonly-20261016',rows=[],sha=(b:any)=>createHash('sha256').update(b).digest('hex');
for(const spec of [
 {path:'cold29400/frames/29595-before-step.json.gz',ids:['unit-p0-archer-22563']},
 {path:'cold29400/frames/29745-before-step.json.gz',ids:['unit-p0-archer-22563']},
 {path:'cold29400/frames/29910-before-p0.json.gz',ids:['unit-p0-archer-22563']},
 {path:'cold29400/frames/29925-before-step.json.gz',ids:['unit-p0-archer-22563','unit-p0-priest-2439','unit-p0-fieldMedic-1418']},
 {path:'frames/30600.json.gz',ids:['unit-p0-priest-2439','unit-p0-priest-15352','unit-p0-fieldMedic-1602','unit-p0-fieldMedic-1418']},
 ]){
 const raw=readFileSync(D+'/'+spec.path),f=JSON.parse(gunzipSync(raw).toString()),w=f.snapshot,before=JSON.stringify(f);setBuildingBodies(w.map,[...w.buildings,...w.obstacles??[]]);
 const towers=w.buildings.filter((b:any)=>b.hp>0&&b.complete&&b.attackDamage>0&&b.owner==='p1');
 const subjects=[];
 for(const id of spec.ids){const u=w.units.find((x:any)=>x.id===id);if(!u)throw new Error('missing subject');const order=u.order;
  const target=order.targetId?[...w.units,...w.buildings].find((x:any)=>x.id===order.targetId):undefined;
  const goal=['move','attackMove'].includes(order.type)?{x:order.x,y:order.y}:order.type==='cast'||order.type==='attack'?target:undefined;
  const road=goal?groundSteeringRoute(w.map,u,goal):undefined;
  const near=w.units.filter((x:any)=>x.owner==='p0'&&['priest','fieldMedic'].includes(x.kind)).map((h:any)=>({id:h.id,direct:Math.hypot(h.x-u.x,h.y-u.y),cooldown:h.abilityCooldowns?.heal??0})).sort((a:any,b:any)=>a.direct-b.direct);
  const towerContacts=towers.filter((b:any)=>strikeGap(b,u)<=b.attackRange).map((b:any)=>({id:b.id,range:b.attackRange,gap:strikeGap(b,u),cooldown:b.cooldown}));
  const roadCoverage=road?towers.filter((tower:any)=>road.slice(1).some((point:any,i:number)=>pointSegmentDistanceSquared(tower,road[i]!,point)<=retreatThreatReach(w,tower,u,15)**2)).map((b:any)=>b.id):[];
  const cost=road?road.slice(1).reduce((sum:number,p:any,i:number)=>sum+groundTravelCost(w.map,road[i]!,p),0):0;
  subjects.push({id,hp:u.hp,maxHp:u.maxHp,position:{x:u.x,y:u.y},order,target:target?{id:target.id,hp:target.hp,x:target.x,y:target.y}:null,towerContacts,healerDistancesAndCooldowns:near,goal:goal?{x:goal.x,y:goal.y}:null,goalDirect:goal?Math.hypot(u.x-goal.x,u.y-goal.y):null,nativeSteeringRoad:road,estimatedRoadCost:cost,estimatedRoadTicks:Math.ceil(cost/u.speed*SIM_TICKS_PER_SECOND),roadTowerCoverage:roadCoverage});
 }
 if(JSON.stringify(f)!==before)throw new Error('query changed input');rows.push({...spec,tick:w.tick,inputSHA256:sha(raw),unchanged:true,subjects});
}
writeFileSync(D+'/PURE-ROADS.json',JSON.stringify({classification:'Pure original-source building-aware native steering road queries on captured actual fullstates; no Game/step/AI planner or memory changes. Road to attack/cast target center is a geometry reference: native range, crowd collision and per-step target acquisition govern actual stopping; whole road coverage is not a claim full route was physically traversed.',source:'38f5dd79ae588d578dce15b9baa2cd41f20f2a4b',driverSHA256:sha(readFileSync(D+'/pure-roads.mts')),rows},null,2)+'\n');
console.log(JSON.stringify(rows.map((r:any)=>({tick:r.tick,subjects:r.subjects.map((s:any)=>({id:s.id,hp:s.hp,order:s.order,towerContacts:s.towerContacts,direct:s.goalDirect,roadTicks:s.estimatedRoadTicks,points:s.nativeSteeringRoad?.length,roadCoverage:s.roadTowerCoverage}))}))));
