import { readFileSync,writeFileSync,appendFileSync,mkdirSync,existsSync } from 'node:fs';
import { gunzipSync,gzipSync } from 'node:zlib';
import { dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import { NativeTelemetry } from './native-telemetry';

const [source,head,prefix]=process.argv.slice(2);
if(!source||!head||!prefix)throw Error('ABS_SOURCE FULL_FIXED_HEAD ABS_NEW_PREFIX required');
const directory=dirname(prefix),sha=(b:any)=>createHash('sha256').update(b).digest('hex');
const read=(name:string)=>JSON.parse(readFileSync(directory+'/'+name,'utf8'));
const copy=(v:any)=>JSON.parse(JSON.stringify(v));
const gate=read('driver-preflight.json');
for(const [name,expected]of Object.entries(gate.files) as [string,string][])
  if(sha(readFileSync(directory+'/'+name))!==expected)throw Error('Presealed driver/input changed '+name);
const cap=read('cold-runtime-source.json');
if(cap.root!==source||cap.head!==head||!cap.archiveReadbackVerified)throw Error('Wrong presealed runtime capsule');
for(const name of ['-restore.json','-launch.json','-result.json','-final.json.gz','-commands.jsonl','-native-hits.jsonl'])
  if(existsSync(prefix+name))throw Error('Preserve prior restore attempt '+name);
const load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
function audit(){
  const actualHead=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim();
  const status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'});
  if(actualHead!==head||status)throw Error('Source changed');
  const files=cap.files.map((entry:any)=>{
    const bytes=readFileSync(source+'/'+entry.path),actual=sha(bytes);
    const blob=createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');
    if(actual!==entry.sha256||blob!==entry.expectedGitBlob)throw Error('Source byte mismatch '+entry.path);
    return{path:entry.path,sha256:actual,blob};
  });
  if(files.length!==1474)throw Error('Wrong source inventory');
  return{head:actualHead,status,files};
}
const pre=audit();
writeFileSync(prefix+'-source-preflight.json',JSON.stringify(pre,null,2)+'\n');
for(const [path,expected]of [[cap.sourceArchive,cap.sourceArchiveSHA256],[cap.frozenArchive,cap.frozenArchiveSHA256]])
  if(sha(readFileSync(path))!==expected)throw Error('Source archive mismatch');
const input=JSON.parse(gunzipSync(readFileSync(directory+'/input29400.json.gz')).toString());
const expected=JSON.parse(gunzipSync(readFileSync(directory+'/reference30000.json.gz')).toString());
const setup=input.setup,start=29400,end=30000;
if(input.snapshot.tick!==start||expected.snapshot.tick!==end||!isDeepStrictEqual(setup,expected.setup))throw Error('Wrong window');
const sim=await load('src/shared/sim.ts');
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts');
const {createAiMemoryProvider}=await load('src/ai/planner-context.ts');
const {createBootstrapCommandPlanner,frozenPolicyManifest,frozenPolicyRoot}=await load('scripts/bootstrap_1-planner.ts');
const {runGameLoop}=await load('src/sdk/game-runner.ts');
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen)
  .find((m:any)=>m.subject==='v9_archer'&&m.side===0&&m.agents.p0.race==='grove'
    &&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v7+v8');
if(!match||!isDeepStrictEqual(copy(match.agents),setup.agents)||setup.unseen!==true||setup.rulesVersion!==2)throw Error('Setup changed');
const game=bootstrapGame(match);
sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
const owners=Object.keys(match.agents),memories=createAiMemoryProvider(copy(input.memories));
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
const captureTicks=new Set([29595,29745,29820,29835,29910,29925,29940]);
const capture=(label:string)=>writeFileSync(directory+'/frames/'+game.tick+'-'+label+'.json.gz',gzipSync(JSON.stringify({...frame(),phase:label,commandIndex:telemetry?.commandIndex??null})+'\n'));
const restored=frame();
const restoreChecks={world:isDeepStrictEqual(restored.snapshot,input.snapshot),nextId:restored.nextId===input.nextId,
  all3mem:isDeepStrictEqual(restored.memories,input.memories),setup:isDeepStrictEqual(restored.setup,input.setup)};
writeFileSync(prefix+'-restored-fullstate.json.gz',gzipSync(JSON.stringify(restored)+'\n'));
writeFileSync(prefix+'-restore.json',JSON.stringify({inputSHA256:sha(readFileSync(directory+'/input29400.json.gz')),checks:restoreChecks},null,2)+'\n');
if(!Object.values(restoreChecks).every(Boolean))throw Error('Strict restore failed before any native step; preserved without normalization relaxation');
const planner=await createBootstrapCommandPlanner(memories),frozenRoot=frozenPolicyRoot();
function frozenAudit(){
  const files=Object.entries(cap.frozenFiles).map(([path,expected])=>{
    const actual=sha(readFileSync(frozenRoot+'/'+path));if(actual!==expected)throw Error('Frozen byte mismatch '+path);
    return{path,sha256:actual};
  });
  if(files.length!==497||Object.keys(frozenPolicyManifest.files).length!==184||frozenPolicyManifest.rulesVersion!==2
    ||frozenPolicyManifest.revision!==setup.frozenRevision)throw Error('Wrong frozen rules/manifest');
  for(const[path,expected]of Object.entries(frozenPolicyManifest.files))if(sha(readFileSync(frozenRoot+'/'+path))!==expected)throw Error('Frozen184 mismatch');
  return files;
}
const frozenPre=frozenAudit(),referenceCommands=read('reference-commands.json'),referenceHits=read('reference-hits.json'),referencePlans=read('reference-plans.json');
let commandCount=referenceCommands[0].index,planCount=0,steps=0;
const commands:any[]=[],hits:any[]=[],plans:any[]=[];
for(const stream of ['commands','plans','native-hits','native-events','native-deaths','ship-losses'])writeFileSync(prefix+'-'+stream+'.jsonl','',{flag:'wx'});
const telemetry=new NativeTelemetry(game,(stream,event)=>{
  appendFileSync(prefix+'-'+stream+'.jsonl',JSON.stringify(event)+'\n');if(stream==='native-hits')hits.push(copy(event));
});
telemetry.hitIndex=referenceHits[0].index;
game.observer={hit:(attacker:any,target:any,damage:number,hpBefore:number)=>telemetry.hit(attacker,target,damage,hpBefore)};
writeFileSync(prefix+'-launch.json',JSON.stringify({pid:process.pid,startedAtUtc:new Date().toISOString(),start,end,head,
  classification:'Unique600tick cold restoration of actual first-use archer assault, not another ordinary0 or additional match.',restoreChecks,sourceFiles:1474,frozenFiles:497,manifestFiles:184},null,2)+'\n');
console.log(JSON.stringify({pid:process.pid,start,end,restoreChecks}));
let result:any;
try{
  result=runGameLoop({...match,maxTicks:end,game,commandPlanner:(context:any)=>{
    telemetry.commandIndex=commandCount;if(context.owner==='p0'&&captureTicks.has(game.tick))capture('before-p0');const entries=planner(context);planCount++;
    const row={tick:game.tick,owner:context.owner,entries};plans.push(copy(row));appendFileSync(prefix+'-plans.jsonl',JSON.stringify(row)+'\n');return entries;
  }},{
    onCommand:(event:any)=>{
      telemetry.commandIndex=commandCount++;const row={index:telemetry.commandIndex,tick:game.tick,owner:event.owner,source:event.source,
        scriptId:event.scriptId,command:event.command,traceKind:'SDK public-command attempt; transient skips also call onCommand'};
      commands.push(copy(row));appendFileSync(prefix+'-commands.jsonl',JSON.stringify(row)+'\n');
      telemetry.observe('after-command');if(event.owner==='p0'&&captureTicks.has(game.tick)&&(['unit-p0-archer-22563','unit-p0-fieldMedic-1418'].some(id=>(event.command.unitIds??[]).includes(id)||event.command.unitId===id)))capture('after-command-'+telemetry.commandIndex+'-'+event.scriptId);telemetry.commandIndex=commandCount;
    },beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();if(captureTicks.has(game.tick))capture('before-step');},
    onStep:()=>{steps++;telemetry.observe('after-step');if([29828,29832,29858,29862,29918,29922,29948,29952].includes(game.tick))capture('after-step');},
  });
}catch(error){
  writeFileSync(prefix+'-interruption-fullstate.json.gz',gzipSync(JSON.stringify({...frame(),phase:'unexpected-interruption',commandIndex:telemetry.commandIndex})+'\n'));
  writeFileSync(prefix+'-interruption.json',JSON.stringify({tick:game.tick,steps,error:String(error)},null,2)+'\n');throw error;
}
const final=frame();
writeFileSync(prefix+'-final.json.gz',gzipSync(JSON.stringify(final)+'\n'));
const post=audit(),frozenPost=frozenAudit();
const firstDifference=(a:any[],b:any[])=>{
  for(let i=0;i<Math.max(a.length,b.length);i++)if(!isDeepStrictEqual(a[i],b[i]))return{position:i,actual:a[i]??null,reference:b[i]??null};return null;
};
const checks={restoreExact:Object.values(restoreChecks).every(Boolean),source1474:isDeepStrictEqual(pre,post),
  frozen497:isDeepStrictEqual(frozenPre,frozenPost),commands:isDeepStrictEqual(commands,referenceCommands),hits:isDeepStrictEqual(hits,referenceHits),plans:isDeepStrictEqual(plans,referencePlans),
  finalWorld:isDeepStrictEqual(final.snapshot,expected.snapshot),finalNextId:final.nextId===expected.nextId,
  final3mem:isDeepStrictEqual(final.memories,expected.memories),finalSetup:isDeepStrictEqual(final.setup,expected.setup),
  finalWholeSavedObject:isDeepStrictEqual(final,expected),actual600Steps:steps===600};
writeFileSync(prefix+'-source-postflight.json',JSON.stringify({source:post,frozenPre,frozenPost},null,2)+'\n');
const report={classification:'One cold normal3AI600tick replay of the actual29400→30000 first-use archer ordinary0 assault. Seed now observed, not a second ordinary0 or extra result.',head,
  inputTick:start,result:{tick:game.tick,winner:game.match.winner},checks,allExact:Object.values(checks).every(Boolean),
  counts:{steps,commands:commands.length,hits:hits.length,plans:planCount,sourceFiles:1474,frozenFiles:497,manifestFiles:184},
  firstCommandDifference:firstDifference(commands,referenceCommands),firstHitDifference:firstDifference(hits,referenceHits),
  elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,telemetry:telemetry.summary(),limits:'No source/strategy/manual command/seed change. Exact original window and input only, not generalized restore or gameplay acceptance.'};
writeFileSync(prefix+'-result.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
if(!report.allExact)process.exitCode=1;
