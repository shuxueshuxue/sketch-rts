from pathlib import Path
import json,hashlib,tarfile
D=Path('/tmp/bootstrap-knight-shore-diagnostic-20261015');G=Path('/tmp/bootstrap-deployment-gate')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((D/'prototype-v2-34800/result.json').read_text());proof=json.loads((D/'v2-result-proof.json').read_text());assert r['pre'] and r['post'] and all(r['restore'].values());assert proof['world'] and proof['nextId'] and proof['frozenP1Memory'];assert len(r['shots'])==0 and len(r['hits'])==0
sources=[]
for prefix in ['root6f80-combined','knight-shore-v2']:
 s=json.loads((G/(prefix+'-source.json')).read_text());w=Path(s['worktree']);assert all(sha(w/p)==h for p,h in s['files'].items());sources.extend(G/(prefix+suffix) for suffix in ['-source.json','-source.patch','-source.tar.gz'])
readme='''# V2 idle neutral objective filter: native negative result

This is a focused bothAI changed-source experiment, not a full new ordinary match, win or acceptance. It starts at the original unmodified true0 knight-v5 sapphire34800 checkpoint used by the v1 experiment, rules2, full world,nextId,all both-owner memories, normal frozen184 v5. Complete setup/provenance is in input-34800.json. Exact source6f80+captured V2, source pre/post and full restore checks are all true. TypeScript check passed.

V2 introduces a bootstrap-only candidate feasibility callback at the existing shared candidate-selection boundary. It only filters idle/held neutral land units whose real native firing station is rejected by the unchanged outmatchingCoast rule. No+160/margin change, speculative simulation, manual placement, resource/enemy change, or live threat/escape override. All observed land/neutral foes remain in the immediate/destination risk query. Frozen policies supply no callback; the184 source files are unchanged. The new untracked helper is in the source tar archive (git diff alone does not include it).

Native34800→36000 (1200ticks): naval combat memory clears, but0naval commands,0new observed projectiles,0hits. All ships retain the original positions/orders/HP. Full terminal world,nextId and frozenP1 memory exactly equal the original6f80 control36000; subject memory differs by released combat target. v2-result-proof.json records this. Native36000 image was personally viewed; the fleet is still offshore outside combat. Do not merge this candidate as a behavioral fix.

Why another hold remains: the unchanged existing muster strategic goal is(2282.509667991878,6005.490332008122), at the enemy shipyard. Read-only v2-fallback-query reconstructs native formation positions on a separate original JSON clone, then queries unchanged risk. The first three stalled hulls' stations are in the range+160 hull warning of21 enemy land units; actual sea-road lengths exist (warship1101=3680). This geometric reconstruction is explicitly not a gameplay placement or proof of native arrival; the native run itself proves no departure and no combat improvement. The query also includes a fourth warship, whose service/outfitting eligibility was not independently reconstructed; its row must not be described as an observed actual assignment. The first three slots preserve the existing leader and order.

A safe single-think engagement from V1 already failed natively:464→83HP for one whelp after the original astern response. That evidence is sealed separately in knight-shore-v1-negative-evidence.tar.gz (278c2c3f33376bb2ffcf3e99ce7a655947695bab79193cc8e523203d1b0b0ad1). The normal34800→36000 control and original ordinary equality proof are in that archive; this package includes the complete36000 control frame for direct comparison. V2 only clears a rejected neutral objective; it does not solve safe fleet approach/assembly at an independently executable strategic goal. No full duplicate match or high-cost matrix was run. The active ordinary match and its separately owned55200 carrier-loss investigation are untouched.

The first V2 launcher failed before AI game-loop execution because frozen git archive ran with /workspace cwd; failed-cwd log is preserved. The corrected run uses the V2 control cwd and records the verified result. This startup failure has no claimed gameplay evidence.
'''
(D/'README-v2.md').write_text(readme)
paths=[D/name for name in ['README-v2.md','seal-v2.py','input-34800.json','window-with-shot-tick.mts','prototype-v2-34800.log','prototype-v2-failed-cwd.log','prototype-v2-tsc.log','v2-fallback-query.mts','v2-fallback-query.json','v2-fallback-query.log','v2-result-proof.json','render.mts','native-v2-end-36000.png','baseline36000-ordinary-proof.json','control34860/after-36000.json']]
paths += sorted((D/'prototype-v2-34800').glob('*'))+sources
index={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths};(D/'v2-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');arc=G/'knight-shore-v2-negative-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for p in paths:t.add(p,arcname=('diagnostic/'+str(p.relative_to(D))) if p.is_relative_to(D) else 'sources/'+p.name)
 t.add(D/'v2-evidence-index.json',arcname='v2-evidence-index.json')
a={'archive':str(arc),'bytes':arc.stat().st_size,'sha256':sha(arc),'payloadFiles':len(paths),'sourceAndRestore':True,'nativeWorldEqualsOriginalControl':True,'classification':'Unsuccessful bounded candidate; no merge recommended'};(G/'knight-shore-v2-negative-archive.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
