import {readFileSync,writeFileSync,appendFileSync,mkdirSync,existsSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const source='/workspace/sketch-rts-mercenary-return-roads-control';
const head='ab0ffd200725968a9c4887d2d7883cfeec1eaa8f';
const original='/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game';
const out='/workspace/.playtest/bootstrap-mercenary-return-postloss-diagnostic-20261016/horse4294-native/baseline15780-15896';
const driver='/workspace/.playtest/prepared-combined-ordinary0-driver',uid='unit-p0-horseArcher-4294',start=15780,end=15896;
if(existsSync(out+'.json')||existsSync(out+'-commands.jsonl'))throw Error('Preserve existing episode');
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8')),lines=(p:string)=>readFileSync(p,'utf8').trim().split('\n').filter(Boolean).map(t=>JSON.parse(t)),copy=(v:any)=>JSON.parse(JSON.stringify(v)),sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const actual='/workspace/.playtest/bootstrap-mercenary-return-roads-20261016/candidate-complete-tail';
const inputFile=actual+'.events/15780-after-step-5.json.gz',input=JSON.parse(gunzipSync(readFileSync(inputFile)).toString()),setup=input.setup;
const capsule=read(original+'-runtime-source.json'),load=(p:string)=>import(pathToFileURL(source+'/'+p).href);
function audit(){
 const actual=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{cwd:source,encoding:'utf8'});if(actual!==head||status)throw Error('Fixed source changed');
 const blobs=new Map(execFileSync('git',['ls-tree','-r',head],{cwd:source,encoding:'utf8',maxBuffer:8*1024*1024}).trim().split('\n').map(line=>{const [meta,path]=line.split('\t');return [path,meta!.split(' ')[2]];}));
 const inherited=capsule.files.map((f:any)=>{const b=readFileSync(source+'/'+f.path),blob=createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(blob!==blobs.get(f.path))throw Error('Not fixedgit '+f.path);if(!['src/ai/policy/script-runner.ts','src/ai/bootstrap_1/mercenary-control.ts'].includes(f.path)&&sha(b)!==f.sha256)throw Error('Unexpected inherited delta '+f.path);return{path:f.path,sha256:sha(b),blob};});
 const extras=execFileSync('git',['diff','--name-only','--diff-filter=A','e5663c338f9c544a5e65a66a6ed278d35f74a8f4',head],{cwd:source,encoding:'utf8'}).trim().split('\n').filter(Boolean).map(path=>{const b=readFileSync(source+'/'+path),blob=createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');if(blob!==blobs.get(path))throw Error('Extra notfixed '+path);return{path,sha256:sha(b),blob};});
 return {head:actual,status,inherited,extras};
}
const pre=audit();writeFileSync(out+'-source-preflight.json',JSON.stringify(pre,null,2)+'\n');
const {bootstrapGame,bootstrapMatches}=await load('src/ai/bootstrap_1/benchmark.ts'),sim=await load('src/shared/sim.ts'),{createAiMemoryProvider}=await load('src/ai/planner-context.ts'),{createBootstrapCommandPlanner,frozenPolicyRoot,frozenPolicyManifest}=await load('scripts/bootstrap_1-planner.ts'),{runGameLoop}=await load('src/sdk/game-runner.ts');
const {NativeTelemetry}=await import(pathToFileURL(driver+'/native-telemetry.ts').href);
const match=bootstrapMatches(setup.seed,[setup.map],Number.MAX_SAFE_INTEGER,setup.unseen).find((m:any)=>m.subject==='v9_archer'&&m.side===1&&m.agents.p0.race==='grove'&&Object.values(m.agents).slice(1).map((a:any)=>a.version).join('+')==='v8+v8');if(!match||!isDeepStrictEqual(copy(match.agents),setup.agents))throw Error('Setup differs');
const game=bootstrapGame(match);sim.restoreSnapshotIntoGame(game,input.snapshot,input.nextId);
const owners=Object.keys(match.agents),memories=createAiMemoryProvider(copy(input.memories));
const frame=()=>copy({snapshot:sim.snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(owners.map(o=>[o,memories.get(o)??null])),setup});
const restored=frame(),restoreChecks={world:isDeepStrictEqual(restored.snapshot,input.snapshot),nextId:restored.nextId===input.nextId,all3mem:isDeepStrictEqual(restored.memories,input.memories),setup:isDeepStrictEqual(restored.setup,input.setup)};
writeFileSync(out+'-restore.json',JSON.stringify({input:inputFile,sha256:sha(readFileSync(inputFile)),checks:restoreChecks},null,2)+'\n');if(!Object.values(restoreChecks).every(Boolean))throw Error('Incomplete restoration');
const planner=await createBootstrapCommandPlanner(memories),frozenRoot=frozenPolicyRoot(),frozenAudit=()=>Object.entries(capsule.frozenFiles).map(([path,expected])=>{const actual=sha(readFileSync(frozenRoot+'/'+path));if(actual!==expected)throw Error('Frozen changed '+path);return{path,sha256:actual};}),frozenPre=frozenAudit();
if(frozenPolicyManifest.rulesVersion!==2||frozenPolicyManifest.revision!==setup.frozenRevision)throw Error('Frozen rules mismatch');
const rawCommands=lines(actual+'-commands.jsonl'),rawHits=lines(actual+'-native-hits.jsonl'),referenceCommands=rawCommands.filter(e=>e.tick>=start&&e.tick<=end),referenceHits=rawHits.filter(e=>(e.tick>start||e.tick===start&&e.commandIndex!==null)&&e.tick<=end);
const expected=JSON.parse(gunzipSync(readFileSync(actual+'.events/15896-after-step-7.json.gz')).toString());
let commandCount=referenceCommands[0].index,planCount=0,eventCount=0,lastGoal:any,release:any,stopReason='notstopped';
const actualCommands:any[]=[],actualHits:any[]=[],positions:any[]=[],goalHistory:any[]=[],telemetry=new NativeTelemetry(game,(stream:string,e:any)=>{appendFileSync(out+'-'+stream+'.jsonl',JSON.stringify(e)+'\n');if(stream==='native-hits')actualHits.push(copy(e));});telemetry.hitIndex=referenceHits[0].index;
for(const suffix of ['commands','plans','native-hits','native-events','native-deaths','ship-losses'])writeFileSync(out+'-'+suffix+'.jsonl','',{flag:'wx'});
mkdirSync(out+'.events');mkdirSync(out+'.frames');mkdirSync(out+'.prethink');
const save=(dir:string,name:string)=>writeFileSync(out+dir+'/'+name+'.json.gz',gzipSync(JSON.stringify(frame())+'\n'));
const eventState=(stage:string,events:any[])=>{if(events.some(e=>e.type==='native-building-terminal'||e.type==='native-unit-terminal'&&e.permanent))save('.events',game.tick+'-'+stage+'-'+(++eventCount));};
const record=()=>{const u=game.units.find((u:any)=>u.id===uid);const target=u?.order.type==='attack'?game.units.find((t:any)=>t.id===u.order.targetId):undefined;positions.push(copy({tick:game.tick,horse:u??null,target:target??null,nearUnits:u?game.units.filter((t:any)=>Math.hypot(t.x-u.x,t.y-u.y)<=400):[],unitsLost:game.match.stats.unitsLost}));return u;};record();save('.frames',String(start));
game.observer={hit:(a:any,t:any,d:number,h:number)=>telemetry.hit(a,t,d,h)};
const runInput={...match,maxTicks:end,game,commandPlanner:(context:any)=>{telemetry.commandIndex=commandCount;if(context.owner==='p0')save('.prethink',String(game.tick));const entries=planner(context);planCount++;appendFileSync(out+'-plans.jsonl',JSON.stringify({tick:game.tick,owner:context.owner,entries})+'\n');return entries;}};
const result=runGameLoop(runInput,{
 onCommand:(e:any)=>{telemetry.commandIndex=commandCount++;const row={index:telemetry.commandIndex,tick:game.tick,owner:e.owner,source:e.source,scriptId:e.scriptId,command:e.command};actualCommands.push(copy(row));appendFileSync(out+'-commands.jsonl',JSON.stringify(row)+'\n');
  if(e.owner==='p0'&&e.command.unitIds?.includes(uid)){
   if(e.scriptId==='mercenaryControl'&&e.command.type==='move'){lastGoal={x:e.command.x,y:e.command.y};goalHistory.push(copy(row));}
   else if(lastGoal&&['move','attack','attackMove','stop','holdPosition','board'].includes(e.command.type)){
    const u=game.units.find((u:any)=>u.id===uid),home=game.buildings.find((b:any)=>b.owner==='p0'&&b.complete&&b.kind==='townHall'&&b.x===lastGoal.x&&b.y===lastGoal.y);
    if(u&&home&&Math.hypot(u.x-home.x,u.y-home.y)<=180&&!release){release={tick:game.tick,acceptedCommand:copy(row),actualHomeId:home.id,actualCenterGap:Math.hypot(u.x-home.x,u.y-home.y),doctor:copy(u)};save('.events',game.tick+'-actual-return-release-after-command');}
   }
  }
  const events=telemetry.observe('after-command');eventState('after-command',events);telemetry.commandIndex=commandCount;},
 beforeStep:()=>{telemetry.commandIndex=null;telemetry.beforeStep();},
 onStep:()=>{const events=telemetry.observe('after-step');eventState('after-step',events);const u=record();if(game.tick===end||game.tick%600===0||game.match.winner)save('.frames',String(game.tick));

  if(game.tick%600===0)console.log(JSON.stringify({progress:game.tick,doctor:u?{hp:u.hp,x:u.x,y:u.y,order:u.order}:null,release:release?.tick??null}));},
});
const final=frame();save('.frames',String(game.tick));writeFileSync(out+'-terminal.json.gz',gzipSync(JSON.stringify(final)+'\n'));writeFileSync(out+'-positions.json',JSON.stringify(positions)+'\n');
const post=audit(),frozenPost=frozenAudit();
function firstSeq(a:any[],b:any[]){for(let i=0;i<Math.min(a.length,b.length);i++)if(!isDeepStrictEqual(a[i],b[i]))return{position:i,baseline:b[i],candidate:a[i]};if(a.length!==b.length)return{position:Math.min(a.length,b.length),baseline:b[a.length]??null,candidate:a[b.length]??null};return null;}
const prefixCommands=actualCommands,prefixHits=actualHits,doctor=final.snapshot.units.find((u:any)=>u.id===uid)??null;
const mandatory={restoreExact:Object.values(restoreChecks).every(Boolean),sourceExact:isDeepStrictEqual(pre,post),frozenExact:isDeepStrictEqual(frozenPre,frozenPost),terminalWorldExact:isDeepStrictEqual(final.snapshot,expected.snapshot),terminalNextIdExact:final.nextId===expected.nextId,terminalAll3memExact:isDeepStrictEqual(final.memories,expected.memories),terminalSetupExact:isDeepStrictEqual(final.setup,expected.setup),commandsExact:isDeepStrictEqual(actualCommands,referenceCommands),hitsExact:isDeepStrictEqual(actualHits,referenceHits)};
const report={classification:'116tick same-ab0 full3AI diagnostic restore15780 actualprethink→actual4294fatal15896. Completeworld/id/all3mem and allpubliccommands/nativehits must close. Passive perstep unit/aim observations and realprethink capture only; no orders/source/AI changes.',source,head,base:'a90c0119d7166baad1c9222781baab107deedbcb',originalReference:'e5663c338f9c544a5e65a66a6ed278d35f74a8f4',input:inputFile,mandatory,allMandatoryExact:Object.values(mandatory).every(Boolean),result:{tick:game.tick,winner:game.match.winner,elapsedMs:result.elapsedMs,cpuMs:result.cpuMs,stopReason},actualReturnRelease:release??null,goalHistory,doctorAtEnd:doctor,full116tickComparison:{firstCommandDifference:firstSeq(prefixCommands,referenceCommands),firstNativeHitDifference:firstSeq(prefixHits,referenceHits),candidateCommands:prefixCommands.length,referenceCommands:referenceCommands.length,candidateHits:prefixHits.length,referenceHits:referenceHits.length},counts:{commands:actualCommands.length,hits:actualHits.length,plans:planCount,sourceFiles:pre.inherited.length+pre.extras.length,frozenFiles:frozenPost.length},telemetry:telemetry.summary()};
writeFileSync(out+'-source-postflight.json',JSON.stringify({source:post,frozenPre,frozenPost},null,2)+'\n');writeFileSync(out+'.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));if(!report.allMandatoryExact)process.exitCode=1;
