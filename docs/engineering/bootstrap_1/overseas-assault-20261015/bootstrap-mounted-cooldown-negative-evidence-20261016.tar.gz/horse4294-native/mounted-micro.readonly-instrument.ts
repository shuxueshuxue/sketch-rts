import { ABILITY_DEFS, UNIT_DEFS, unitMover } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/catalog';
import { capsuleClearsBodies } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/navigation-math';
import { constrainGroundShipStep } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/ship-collisions';
import { abilityCooldown } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/ability-cooldowns';
import { aimingProfile } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/aiming';
import { detCos, detSin } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/det-math';
import { isWalkable, sameGround, segmentWalkable, steerPoint } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/terrain';
import { SIM_TICKS_PER_SECOND } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/time';
import { groundSteeringRoute, routeLeavesDisks } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/route-selection';
import { MOVE_ORDER_ARRIVAL_RANGE } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/movement-rules';
import { unitAbilities } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/unit-abilities';
import { itemsFor } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/equipment';
import { LIGHTNING_ROD, STORM_STAFF, NEUTRAL_ITEM_TARGET_RANGE, NEUTRAL_STORM_TARGET_RANGE } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/item-rules';
import type { Building, GameCommand, GameSnapshot, Unit } from '/workspace/sketch-rts-mercenary-return-roads-control/src/shared/types';
import { distance, type Point } from '/workspace/sketch-rts-mercenary-return-roads-control/src/ai/policy/spatial';
import { hostileDamageDisks } from '/workspace/sketch-rts-mercenary-return-roads-control/src/ai/bootstrap_1/damage-footprints';
import { recoveryArrivalFilter } from '/workspace/sketch-rts-mercenary-return-roads-control/src/ai/bootstrap_1/recovery-arrival';

type Threat = Unit | Building;
export const readonlyTrace: any[] = [];
export const THINK_TICKS = 15;

/** Break healing support before shooting the troops it can keep alive. */
export function mountedTargetOrder(a: Unit, b: Unit) {
  const heals = (unit: Unit) => unitAbilities(unit).some(ability => ABILITY_DEFS[ability].behavior === 'heal');
  return Number(heals(b)) - Number(heals(a)) || a.hp - b.hp;
}

function chargeMinimum(foe: Unit, rider: Pick<Unit, 'x' | 'y'>, horizon: number) {
  return unitAbilities(foe).flatMap(ability => {
    const rules = ABILITY_DEFS[ability];
    return rules.behavior === 'charge' && abilityCooldown(foe, ability) <= horizon
      && distance(rider, foe) < rules.minRange ? [rules.minRange] : [];
  });
}

function itemReach(snapshot: GameSnapshot, foe: Unit, horizon: number) {
  return itemsFor(snapshot, foe).flatMap(item => item.cooldownRemaining <= horizon
    && (item.kind === 'stormStaff' || item.kind === 'lightningRod')
    ? [foe.owner === 'neutral' ? item.kind === 'stormStaff' ? NEUTRAL_STORM_TARGET_RANGE : NEUTRAL_ITEM_TARGET_RANGE
      : item.kind === 'stormStaff' ? STORM_STAFF.range : LIGHTNING_ROD.range] : []);
}

export function mountedThreatReach(snapshot: GameSnapshot, foe: Threat, rider: Pick<Unit, 'x' | 'y' | 'radius'>, horizon: number) {
  if (!('order' in foe)) return foe.attackRange + rider.radius;
  const weaponReach = foe.attackRange <= 80 && chargeMinimum(foe, rider, horizon).length === 0 ? foe.attackRange + foe.radius + rider.radius : foe.attackRange;
  return Math.max(weaponReach, castThreatReach(snapshot, foe, rider, horizon));
}

/** Active skills and carried attacks can still execute while ordinary fire is suppressed by a move order. */
export function castThreatReach(snapshot: GameSnapshot, foe: Unit, rider: Pick<Unit, 'x' | 'y'>, horizon: number) {
  return Math.max(0, ...itemReach(snapshot, foe, horizon), ...unitAbilities(foe).flatMap(ability => {
    const rules = ABILITY_DEFS[ability];
    return ['charge', 'stomp', 'web', 'curse', 'weapon'].includes(rules.behavior)
      && abilityCooldown(foe, ability) <= horizon
      && !(rules.behavior === 'charge' && distance(rider, foe) < rules.minRange) ? [rules.range] : [];
  }));
}

/** One ordinary command per think; ranges and cooldowns come from the live combatants. */
export function mountedMicro(snapshot: GameSnapshot, rider: Unit, target: Unit, foes: readonly Threat[], goal: { kind: 'camp' } | { kind: 'raid'; station: Point } | { kind: 'field' }): GameCommand {
  if (goal.kind === 'camp') {
    const clearingTicks = foes.reduce((ticks, foe) => ticks + ('order' in foe && foe.owner === 'neutral'
      ? foe.hp * rider.attackCooldown / rider.attackDamage : 0), 0);
    if (foes.some(foe => 'order' in foe && foe.owner === 'neutral'
      && mountedThreatReach(snapshot, foe, rider, THINK_TICKS + clearingTicks) >= rider.attackRange)) {
      const home = snapshot.buildings.filter(building => building.owner === rider.owner && building.kind === 'townHall'
        && building.complete && sameGround(snapshot.map, rider, building))
        .sort((a, b) => distance(rider, a) - distance(rider, b))[0];
      if (home) return { type: 'move', unitIds: [rider.id], x: home.x, y: home.y };
    }
  }
  const aim = rider.aim ? rider.aim : rider;
  // Outside weapon range we are walking, not waiting for aim at the distant target.
  const shot = rider.cooldown > THINK_TICKS || distance(rider, target) > rider.attackRange ? 0 : rider.cooldown / SIM_TICKS_PER_SECOND + distance(aim, target) / aimingProfile(UNIT_DEFS[rider.kind])!.speed;
  const horizon = THINK_TICKS + rider.cooldown;
  const margin = (point: Point, foe: Threat) => distance(point, foe) - mountedThreatReach(snapshot, foe, rider, horizon);
  // Inside a charge minimum, the shot and next think share the same narrow firing window.
  const firingWindow = foes.some(foe => 'order' in foe && chargeMinimum(foe, rider, horizon).length > 0)
    ? Math.max(THINK_TICKS / SIM_TICKS_PER_SECOND, shot) : THINK_TICKS / SIM_TICKS_PER_SECOND + shot;
  const safeShot = foes.every(foe => margin(rider, foe) > ('order' in foe ? foe.speed : 0)
    * ('order' in foe && foe.owner === 'neutral' && foe.order.type === 'idle'
      ? THINK_TICKS / SIM_TICKS_PER_SECOND : firingWindow));
  readonlyTrace.push({phase:'shot',rider:rider.id,target:target.id,goal,shot,horizon,firingWindow,safeShot,targetGap:distance(rider,target),ownRange:rider.attackRange,threats:foes.map(foe=>({id:foe.id,kind:foe.kind,owner:foe.owner,order:'order' in foe?foe.order:null,speed:'speed' in foe?foe.speed:0,gap:distance(rider,foe),reach:mountedThreatReach(snapshot,foe,rider,horizon),margin:margin(rider,foe),needed:('order' in foe?foe.speed:0)*('order' in foe&&foe.owner==='neutral'&&foe.order.type==='idle'?THINK_TICKS/SIM_TICKS_PER_SECOND:firingWindow)}))});
  if (safeShot) {
    if (distance(rider, target) <= rider.attackRange) {
      // Explicitly hit the worker when following it until the next think stays outside cover.
      const angle = Math.atan2(target.y - rider.y, target.x - rider.x);
      const travel = Math.min(rider.speed, target.speed) * THINK_TICKS / SIM_TICKS_PER_SECOND;
      const following = { x: rider.x + detCos(angle) * travel, y: rider.y + detSin(angle) * travel, radius: rider.radius };
      const safeFollow = segmentWalkable(snapshot.map, rider, following) && foes.every(foe => distance(following, foe)
        > mountedThreatReach(snapshot, foe, following, horizon) + ('order' in foe ? foe.speed * THINK_TICKS / SIM_TICKS_PER_SECOND : 0));
      return goal.kind === 'camp' || target.order.type === 'idle' || target.order.type === 'hold'
        || target.order.type === 'attack' && target.order.targetId === rider.id || safeFollow
        ? { type: 'attack', unitIds: [rider.id], targetId: target.id }
        : { type: 'aim', unitIds: [rider.id], x: target.x, y: target.y };
    }
    if (!foes.some(foe => 'order' in foe && foe.order.type === 'attack' && foe.order.targetId === rider.id)) {
      const approach = 1 - rider.attackRange / distance(rider, target);
      const entry = { x: rider.x + (target.x - rider.x) * approach, y: rider.y + (target.y - rider.y) * approach };
      if (goal.kind !== 'raid' && foes.every(foe => distance(entry, foe) > mountedThreatReach(snapshot, foe, rider, horizon))
        && routeLeavesDisks(groundSteeringRoute(snapshot.map, rider, entry), foes.map(foe => ({ x: foe.x, y: foe.y,
          radius: mountedThreatReach(snapshot, foe, rider, horizon) })))) {
        return { type: 'attack', unitIds: [rider.id], targetId: target.id };
      }
      return mountedEscape(snapshot, rider, foes, 0, steerPoint(snapshot.map, rider, goal.kind === 'raid' ? goal.station : target), false);
    }
    // Aim while a pursuer is outside weapon range, including during the weapon's cooldown.
    const prepared = (rider.attackRange - rider.radius) / distance(rider, target);
    return { type: 'aim', unitIds: [rider.id], x: rider.x + (target.x - rider.x) * prepared,
      y: rider.y + (target.y - rider.y) * prepared };
  }
  const edge = Math.min(rider.x, rider.y, snapshot.map.width - rider.x, snapshot.map.height - rider.y);
  return mountedEscape(snapshot, rider, foes, shot, goal.kind !== 'camp' && edge < rider.attackRange
    ? { x: snapshot.map.width / 2, y: snapshot.map.height / 2 } : undefined, false);
}

export function mountedEscape(snapshot: GameSnapshot, rider: Unit, foes: readonly Threat[], shot: number, destination: Point | undefined, avoidCombat: boolean, arrivalAllows = avoidCombat ? recoveryArrivalFilter(snapshot, rider, THINK_TICKS) : undefined): GameCommand {
  const horizon = THINK_TICKS + rider.cooldown;
  const threats = foes.map(foe => ({ foe, range: mountedThreatReach(snapshot, foe, rider, horizon), speed: 'order' in foe ? foe.speed : 0 }));
  const hazards = hostileDamageDisks(snapshot, rider, foes, horizon);
  const margin = (point: Point, threat: typeof threats[number]) => distance(point, threat.foe) - threat.range;
  const danger = [...threats].sort((a, b) => margin(rider, a) - a.speed * (THINK_TICKS / SIM_TICKS_PER_SECOND + shot)
    - (margin(rider, b) - b.speed * (THINK_TICKS / SIM_TICKS_PER_SECOND + shot)))[0]!;
  const angle = destination ? Math.atan2(destination.y - rider.y, destination.x - rider.x) : Math.atan2(rider.y - danger.foe.y, rider.x - danger.foe.x);
  // Keep the original scoring radius; recovery extends the selected endpoint by the move arrival range below.
  const step = Math.max(rider.speed * THINK_TICKS,
    ...threats.map(threat => threat.speed * (THINK_TICKS + 2))) / SIM_TICKS_PER_SECOND;
  const innerWindow = avoidCombat ? [] : foes.flatMap(foe => 'order' in foe ? chargeMinimum(foe, rider, horizon).map(limit => ({ foe, limit })) : []);
  const bodies = snapshot.units.filter(unit => unit.id !== rider.id && !unit.deck
    && unitMover(unit.kind) === 'land' && !(unit.kind === 'worker' && unit.order.type === 'mine'));
  const choices = [rider, ...(destination && distance(rider, destination) <= step ? [destination] : []), ...Array.from({ length: 16 }, (_, index) => ({
    x: rider.x + detCos(angle + index * Math.PI / 8) * step,
    y: rider.y + detSin(angle + index * Math.PI / 8) * step,
  })).filter(point => point.x >= 0 && point.y >= 0 && point.x < snapshot.map.width && point.y < snapshot.map.height
    && isWalkable(snapshot.map, point.x, point.y)
    && segmentWalkable(snapshot.map, rider, point)
    && innerWindow.every(({ foe, limit }) => distance(point, foe) < limit))];
  // Leave room for the following turn rather than maximizing distance into a cliff corner.
  const exit = (point: Point) => {
    if (point === rider) return false;
    const to = { x: point.x + (point.x - rider.x), y: point.y + (point.y - rider.y) };
    return segmentWalkable(snapshot.map, point, to)
      && constrainGroundShipStep(snapshot.map, rider, point, to, snapshot.units) === to;
  };
  const endpoint = (point: Point) => {
    if (!avoidCombat || point === rider || point === destination) return point;
    const gap = distance(rider, point);
    return { x: point.x + (point.x - rider.x) * MOVE_ORDER_ARRIVAL_RANGE / gap,
      y: point.y + (point.y - rider.y) * MOVE_ORDER_ARRIVAL_RANGE / gap };
  };
  const scored = choices.map(point => {
    const margins = threats.map(threat => margin(point, threat));
    const areas = hazards.map(hazard => distance(point, hazard) - hazard.radius);
    const room = Math.min(...margins.map((gap, index) => gap - threats[index]!.speed * THINK_TICKS / SIM_TICKS_PER_SECOND), ...areas);
    return { point, goal: endpoint(point), room, geometricExit: exit(point), bodyClear: capsuleClearsBodies(rider, point, rider.radius, bodies), margin: Math.min(...margins, ...areas), exit: room > 0 && !destination && exit(point),
      distance: destination ? distance(point, destination) : 0 };
  }).filter(({ goal }) => goal.x >= 0 && goal.y >= 0 && goal.x < snapshot.map.width && goal.y < snapshot.map.height
    && isWalkable(snapshot.map, goal.x, goal.y) && segmentWalkable(snapshot.map, rider, goal)
    && (!avoidCombat || goal === rider || arrivalAllows!(goal))
    && (goal === rider || constrainGroundShipStep(snapshot.map, rider, rider, goal, snapshot.units) === goal));
  const chosen = scored.sort((a, b) => Number(b.room > 0) - Number(a.room > 0)
    || (a.room <= 0 ? Number(b.point !== rider) - Number(a.point !== rider) : 0)
    || Number(b.bodyClear) - Number(a.bodyClear)
    || (a.room > 0 ? destination ? a.distance - b.distance
      : Number(b.exit) - Number(a.exit) || b.margin - a.margin : b.room - a.room))[0]!;
  readonlyTrace.push({phase:'escape',rider:rider.id,shot,destination:destination??null,avoidCombat,step,innerWindow:innerWindow.map(x=>({id:x.foe.id,limit:x.limit})),chosen,scored,threats:threats.map(x=>({id:x.foe.id,kind:x.foe.kind,range:x.range,speed:x.speed}))});
  return innerWindow.length > 0 && chosen.point === rider ? { type: 'holdPosition', unitIds: [rider.id] }
    : { type: 'move', unitIds: [rider.id], x: chosen.goal.x, y: chosen.goal.y, ...(avoidCombat ? { avoidCombat: true } : {}) };
}
