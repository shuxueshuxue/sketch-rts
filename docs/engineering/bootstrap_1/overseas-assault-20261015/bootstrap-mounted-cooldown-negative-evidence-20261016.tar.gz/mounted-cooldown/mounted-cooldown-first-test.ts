import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { describe, expect, it } from 'vitest';
import { sketchScene } from '../../sdk/scene';
import { bootstrapGame, bootstrapMatches } from './benchmark';
import { issuePlayerCommand, restoreSnapshotIntoGame, snapshotGame, stepGame } from '../../shared/sim';
import { setBuildingBodies } from '../../shared/terrain';
import { createAiMemoryProvider, planAiOwnerCommandEntries } from '../planner-context';
import { bootstrapPolicyContext } from './policy';
import { armedFoes } from './safe-land-route';
import { mountedMicro, THINK_TICKS } from './mounted-micro';

const riderId = 'unit-p0-horseArcher-4294';
function actual(tick: 15255 | 15270) {
  const saved = JSON.parse(gunzipSync(readFileSync(new URL(`./fixtures/archer-mounted-cooldown-${tick}.json.gz`, import.meta.url))).toString());
  const match = bootstrapMatches(saved.setup.seed, [saved.setup.map], Number.MAX_SAFE_INTEGER, saved.setup.unseen)
    .find(match => match.subject === 'v9_archer' && match.side === 1 && match.agents.p0!.race === 'grove'
      && Object.values(match.agents).slice(1).map(agent => agent.version).join('+') === 'v8+v8')!;
  expect(match.agents).toEqual(saved.setup.agents);
  const game = bootstrapGame(match);
  restoreSnapshotIntoGame(game, saved.snapshot, saved.nextId);
  expect(snapshotGame(game)).toEqual(saved.snapshot);
  const snapshot = snapshotGame(game);
  setBuildingBodies(snapshot.map, [...snapshot.buildings, ...snapshot.obstacles ?? []]);
  const rider = snapshot.units.find(unit => unit.id === riderId)!;
  const context = bootstrapPolicyContext(snapshot, 'p0', 'v9_archer', { memory: structuredClone(saved.memories.p0), teams: snapshot.teams });
  const foes = armedFoes(snapshot, 'p0', context);
  const target = snapshot.units.find(unit => unit.id === 'unit-p1-cinderRunner-7819')!;
  return { saved, game, snapshot, rider, target, foes };
}

describe('mounted weapon cooldown under active pursuit', () => {
  it('keeps the ready actual 15255 shot and unfinished windup', () => {
    const { snapshot, rider, target, foes } = actual(15255);
    expect(rider.cooldown).toBe(0);
    expect(mountedMicro(snapshot, rider, target, foes, { kind: 'field' })).toEqual({ type: 'attack', unitIds: [riderId], targetId: target.id });
    rider.aim = { x: rider.x, y: rider.y, anchorX: rider.x, anchorY: rider.y, tracking: true, updatedTick: snapshot.tick - 1 };
    expect(mountedMicro(snapshot, rider, target, foes, { kind: 'field' }).type).toBe('attack');
  });

  it('uses actual post-launch 15270 cooldown to move, while preserving the launched arrow', () => {
    const { saved, game, snapshot, rider, target, foes } = actual(15270);
    expect(rider.cooldown).toBe(27);
    expect(rider.aim?.tracking).toBe(false);
    const arrow = snapshot.projectiles.find(projectile => projectile.attackerId === riderId)!;
    expect(arrow.targetId).toBe(target.id);
    expect(arrow.remaining).toBeGreaterThan(0);
    const command = mountedMicro(snapshot, rider, target, foes, { kind: 'field' });
    expect(command.type).toBe('move');
    const memoryProvider = createAiMemoryProvider(structuredClone(saved.memories));
    const entry = planAiOwnerCommandEntries(snapshot, { playerId: 'p0', version: 'v9_archer', source: 'external-agent' }, { teams: snapshot.teams, memoryProvider })
      .find(entry => 'unitIds' in entry.command && entry.command.unitIds.includes(riderId))!;
    expect(entry.scriptId).toBe('mountedField');
    expect(entry.command).toEqual(command);
    const hits: number[] = [];
    game.observer = { hit(source, hitTarget, damage) { if (source.id === riderId && hitTarget.id === target.id) hits.push(damage); } };
    issuePlayerCommand(game, 'p0', command);
    stepGame(game);
    const moved = game.units.find(unit => unit.id === riderId)!;
    expect(moved.aim).toEqual(rider.aim);
    for (let i = 1; i < THINK_TICKS; i++) stepGame(game);
    expect(hits).toEqual([12]);
    expect(game.units.find(unit => unit.id === riderId)!.hp).toBe(125);
  });

  it('does not replace an unfinished reticle during cooldown or move a resting target unnecessarily', () => {
    const { snapshot, rider, target, foes } = actual(15270);
    rider.aim!.tracking = true;
    expect(mountedMicro(snapshot, rider, target, foes, { kind: 'field' }).type).toBe('attack');
    rider.aim!.tracking = false;
    for (const foe of foes) if ('order' in foe) foe.order = { type: 'hold', x: foe.x, y: foe.y };
    expect(mountedMicro(snapshot, rider, target, foes, { kind: 'field' }).type).toBe('attack');
  });

  it('keeps a weapon that becomes ready this think eligible to shoot', () => {
    const { snapshot, rider, target, foes } = actual(15270);
    rider.cooldown = THINK_TICKS;
    expect(mountedMicro(snapshot, rider, target, foes, { kind: 'field' }).type).toBe('attack');
  });

  it('still suffers a previously launched 480-range tower arrow after moving out of range', () => {
    const game = sketchScene('cooldown-does-not-delete-inflight-arrows').replaceDefaults()
      .player('us', { team: 'a' }).player('foe', { team: 'b' })
      .townHall('us', 500, 500).townHall('foe', 3500, 3500)
      .building('foe', 'defenseTower', 2200, 2000, { id: 'tower' })
      .unit('us', 'horseArcher', 1725, 2000, { id: 'rider' }).build().createGame();
    const rider = game.units.find(unit => unit.id === 'rider')!, tower = game.buildings.find(building => building.id === 'tower')!;
    expect(tower.attackRange).toBe(480);
    expect(rider.attackRange).toBeLessThan(tower.attackRange);
    stepGame(game);
    expect(game.projectiles.some(projectile => projectile.targetId === rider.id)).toBe(true);
    issuePlayerCommand(game, 'us', { type: 'move', unitIds: [rider.id], x: 1300, y: 2000 });
    for (let i = 0; i < 40; i++) stepGame(game);
    expect(Math.hypot(rider.x - tower.x, rider.y - tower.y)).toBeGreaterThan(tower.attackRange);
    expect(rider.hp).toBeLessThan(rider.maxHp);
  });

  it('does not promise escape from a faster upgraded pursuer without a friendly screen', () => {
    const game = sketchScene('cooldown-faster-pursuer').replaceDefaults()
      .player('us', { team: 'a' }).player('foe', { race: 'ember', team: 'b' })
      .playerState('foe', { upgrades: { speedTraining: 2 } })
      .townHall('us', 500, 500).townHall('foe', 3500, 3500)
      .unit('us', 'horseArcher', 2000, 2000, { id: 'rider' })
      .unit('foe', 'cinderRunner', 2150, 2000, { id: 'pursuer', order: { type: 'attack', targetId: 'rider' } }).build().createGame();
    const rider = game.units.find(unit => unit.id === 'rider')!, foe = game.units.find(unit => unit.id === 'pursuer')!;
    expect(foe.speed).toBeGreaterThan(rider.speed);
    let damage = 0;
    game.observer = { hit(_source, target, taken) { if (target.id === rider.id) damage += taken; } };
    for (let tick = 0; tick < 600 && game.units.includes(rider); tick++) {
      if (tick % THINK_TICKS === 0) issuePlayerCommand(game, 'us', mountedMicro(snapshotGame(game), rider, foe, [foe], { kind: 'field' }));
      stepGame(game);
    }
    expect(damage).toBeGreaterThan(0);
  });
});
