import json,gzip,hashlib,math,collections
from pathlib import Path
p=Path(__file__).parent
uid='unit-p0-horseArcher-4294'
def readlines(name):return [json.loads(l) for l in (p/name).read_text().splitlines() if l.strip()]
def endpoint(name):return json.loads(gzip.decompress((p/(name+'-terminal.json.gz')).read_bytes()))
def branch(name):
    report=json.loads((p/(name+'.json')).read_text());end=endpoint(name);hits=readlines(name+'-native-hits.jsonl');launch=readlines(name+'-launches.jsonl');health=readlines(name+'-health-transitions.jsonl');heals=readlines(name+'-healing-effects.jsonl');effects=readlines(name+'-command-effects.jsonl');rows=[]
    for e in health:
        matching=[h for h in heals if h['tick']==e['tick']and h['phase']==e['phase']]
        for u in e['rows']:
            candidates=[h for h in matching if h['effect'].get('owner')==u['owner']]
            if not u['maxHPChanged']:
                assert len(candidates)==1,'Ambiguous heal balance'
                effect=candidates[0]['effect']
                assert effect['actionMode']=='cast'and effect['actionTick']==e['tick']
                before=u['before'];after=u['after']
                assert before['maxHp']==after['maxHp']
                assert abs(u['restorationIncludingGrowthAndRegeneration']-min(55,before['maxHp']-before['hp']+u['damageToPositiveHP']))<1e-8
                rows.append(dict(tick=e['tick'],target=u['id'],owner=u['owner'],effectiveHP=u['restorationIncludingGrowthAndRegeneration'],caster=effect['sourceId'],nativeEffectId=effect['id'],beforeHP=before['hp'],afterHP=after['hp'],sameStepPositiveHPDamage=u['damageToPositiveHP'],maxHP=after['maxHp']))
    rider=next(u for u in end['snapshot']['units']if u['id']==uid)
    initial=json.loads(gzip.decompress(Path(report['input']).read_bytes()));initialCorpses={x['id']for x in initial['snapshot']['corpses']};deaths=[x for x in end['snapshot']['corpses']if x['id']not in initialCorpses]
    damage=lambda owner:sum(max(0,min(h['damage'],h['hpBefore']))for h in hits if h['attackerOwner']==owner)
    return dict(reportFile=str(p/(name+'.json')),source=report['source'],head=report['head'],mandatory=report['mandatory'],restore=json.loads((p/(name+'-restore.json')).read_text()),riderAtEnd=rider,riderLaunches=[x for x in launch if x['projectile']['attackerId']==uid],riderOutgoing=[h for h in hits if h['attacker']==uid],riderIncoming=[h for h in hits if h['target']==uid],riderCommandLiveEffects=effects,effectiveDamageByOwner={o:damage(o)for o in ['p0','p1','p2','neutral']},effectiveHealing=rows,effectiveHealingByOwner={o:sum(x['effectiveHP']for x in rows if x['owner']==o)for o in ['p0','p1','p2','neutral']},excludedMaxHPChangeRestorations=[dict(tick=e['tick'],id=u['id'],gain=u['restorationIncludingGrowthAndRegeneration'])for e in health for u in e['rows']if u['maxHPChanged']],newCorpses=deaths,nativeLossBefore=initial['snapshot']['match']['stats']['unitsLost'],nativeLossAfter=end['snapshot']['match']['stats']['unitsLost'],pendingTowerArrowsAtEnd=[x for x in end['snapshot']['projectiles']if x['targetId']==uid and x['attackerId'].startswith('building')])
a=branch('base15255-15855');b=branch('v2-15255-15855')
baseCmd=readlines('base15255-15855-commands.jsonl');candCmd=readlines('v2-15255-15855-commands.jsonl')
first=next(dict(position=i,baseline=x,candidate=y)for i,(x,y)in enumerate(zip(baseCmd,candCmd))if x!=y)
assert first['baseline']['tick']==first['candidate']['tick']==15270
assert first['baseline']['command']['unitIds']==first['candidate']['command']['unitIds']==[uid]
assert a['restore']['sha256']==b['restore']['sha256']
assert all(a['mandatory'].values())and all(b['mandatory'].values())
for x in [a,b]:
    assert x['riderAtEnd']['hp']==111 and x['riderAtEnd']['maxHp']==125
    assert len(x['riderOutgoing'])==2 and len(x['effectiveHealing'])==3
    assert x['nativeLossAfter']['p0']==x['nativeLossBefore']['p0']==9
actualFirst=next(x for x in b['riderCommandLiveEffects']if x['tick']==15270)
assert actualFirst['after']['order']['type']=='move'
assert actualFirst['before']['aim']==actualFirst['after']['aim']
assert actualFirst['after']['order']['x']==first['candidate']['command']['x']
assert actualFirst['after']['order']['y']==first['candidate']['command']['y']
result=dict(classification='NEGATIVE unmerged mounted cooldown v2. Same actual15255 ab0-derived world/id/all3mem, currentproductionade baseline and standaloneade-based v2, each600ticks normal3AI. Notordinary0, notwinner or acceptance. No furtherlonggame justified by these results.',baseline=a,candidate=b,firstPublicCommandDifference=first,actualFirstDifference=actualFirst,checks=dict(sameFullInput=True,baselineMatchesPriorActualFullEndAnd828Commands71Hits=all(a['mandatory'].values()),bothFixedSourcesFrozenAndRestores=True,firstDifference15270LiveMoveAndAimPreserved=True,firstArrowAlreadyLaunchedAndHitsBoth=True),findings=['The second rider arrow launches earlier (15310 vs15474), but each branch lands only2 arrows in600ticks:24 vs25 effective HP damage.','Both riders end111/125HP; candidate first incoming14 happens15814 vs15844, and is still isolated near the northern tree edge. Neither branch has a tower arrow in flight yet at15855.','P0 deals587 vs884 effectiveHP damage across alltargets; enemy281 vs500; zero newp0corpses but candidate only2enemycorpses vsbaseline4. Lowerdamage taken is not proven durable tactical improvement.','Three native heal effects each branch correspond uniquely to actual same-step health balance, no maxHPchange: candidate155 vsbaseline146 effectiveHP. Separate maxHPgrowth excluded, no acceptedcast is counted as healing.','The paid murloc camp regression remains: oldade clears20525 with215hits, v1/v2fail30123 after387hits with5remaining. No camp exception added; v2notmerged.'],limits=['Candidate input is from ab0 negative continuation; ade was proved equivalent over these finiteactual windows, not over the entireoldab0game. No ab0stop/returncode imported.','Native observer hitdamage is capped by positive HP for effective damage. Full hit records retained.','Health balance and unique same-step source-taggedheal effects prove these6 observed heals; no promise that allHPgain everywhere is healing. MaxHPchange gains excluded.','Raw SDK emitted commands can contain transientno-op. Actualfirstdifference is independently witnessed by livebefore/after order/aim plus later movement/projectiles/hits.','No naturalterminal or zero-loss claim, no newseed/ordinary0/matrix.'])
(p/'PAIR-COMPARISON.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['classification','checks','findings']},ensure_ascii=False,indent=2))
