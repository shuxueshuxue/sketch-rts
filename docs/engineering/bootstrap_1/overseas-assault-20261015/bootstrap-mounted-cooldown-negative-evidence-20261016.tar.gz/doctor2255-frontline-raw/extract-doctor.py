#!/usr/bin/env python3
"""Read recorded ab0 doctor2255 evidence only; no game, planner or test execution."""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/.playtest/bootstrap-mercenary-return-roads-20261016')
PREFIXES = [ROOT / 'candidate-return-episode', ROOT / 'candidate-complete-tail']
UID, PATIENT = 'unit-p0-fieldMedic-2255', 'unit-p0-footman-1072'
START, END = 14100, 17203


def sha(path):
    with open(path, 'rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def load(path):
    with (gzip.open(path, 'rt') if str(path).endswith('.gz') else open(path)) as handle:
        return json.load(handle)


def rows(prefix, suffix):
    path = Path(str(prefix) + suffix)
    with path.open() as handle:
        return [{'source': str(path), 'line': index, 'record': json.loads(line)}
                for index, line in enumerate(handle, 1) if line.strip()]


def own_command(row):
    command = row['record']['command']
    return UID in command.get('unitIds', []) or command.get('unitId') == UID


def brief(unit, reference=None):
    result = {key: unit.get(key) for key in ('id', 'kind', 'x', 'y', 'hp', 'maxHp', 'level', 'xp', 'kills',
                                           'order', 'orderQueue', 'abilityCooldowns', 'attackRange', 'attackDamage')}
    if reference is not None:
        result['straightDistanceTo2255'] = math.hypot(unit['x'] - reference['x'], unit['y'] - reference['y'])
    return result


def state_view(path, commands):
    frame = load(path)
    assert set(frame['memories']) == {'p0', 'p1', 'p2'} and 'nextId' in frame and 'setup' in frame
    snapshot = frame['snapshot']
    doctor = next((unit for unit in snapshot['units'] if unit['id'] == UID), None)
    corpse = next((corpse for corpse in snapshot.get('corpses', []) if corpse['unitId'] == UID), None)
    reference = doctor or corpse
    assert reference
    own = [unit for unit in snapshot['units'] if unit['owner'] == 'p0' and unit['hp'] > 0
           and unit['kind'] != 'worker' and unit['id'] != UID and unit.get('expiresTick') is None]
    own.sort(key=lambda unit: math.hypot(unit['x'] - reference['x'], unit['y'] - reference['y']))
    other_doctors = [unit for unit in own if unit['kind'] in ('fieldMedic', 'priest')]
    troops = [unit for unit in own if unit['kind'] not in ('fieldMedic', 'priest')]
    halls = [building for building in snapshot['buildings'] if building['owner'] == 'p0'
             and building['kind'] == 'townHall' and building['complete'] and building['hp'] > 0]
    halls.sort(key=lambda building: math.hypot(building['x'] - reference['x'], building['y'] - reference['y']))
    hostile = [entity for entity in snapshot['units'] + snapshot['buildings']
               if entity['owner'] != 'p0' and entity['hp'] > 0 and entity['attackDamage'] > 0]
    hostile.sort(key=lambda entity: math.hypot(entity['x'] - reference['x'], entity['y'] - reference['y']))
    prior_commands = [row for row in commands if row['record']['tick'] < snapshot['tick']]
    memory = frame['memories']['p0']
    return {
        'tick': snapshot['tick'], 'source': str(path), 'sha256': sha(path), 'nextId': frame['nextId'],
        'memoryOwners': sorted(frame['memories']), 'isThinkBoundary': snapshot['tick'] % frame['setup']['thinkInterval'] == 0,
        'phase': 'before-p0-planner' if '.prethink/' in str(path) else 'actual after-step before next loop iteration',
        'doctor': brief(doctor) if doctor else None, 'corpse': corpse,
        'healCooldownByNativeDefault': doctor.get('abilityCooldowns', {}).get('heal', 0) if doctor else None,
        'halls': [brief(hall, reference) for hall in halls],
        'otherDoctors': [brief(unit, reference) for unit in other_doctors],
        'otherPermanentArmyComposition': dict(Counter(unit['kind'] for unit in troops)),
        'otherPermanentArmy': [brief(unit, reference) for unit in troops],
        'nearestArmedHostiles': [brief(unit, reference) for unit in hostile[:12]],
        'actualHealEffectsPresent': [effect for effect in snapshot['effects'] if effect['type'] == 'heal'],
        'lastAcceptedOwnCommandsBeforeState': prior_commands[-3:],
        'persistentMemoryBackgroundOnly': {'general': memory.get('v6', {}).get('general'),
                                         'unitClaim2255': memory.get('unitClaims', {}).get(UID)},
        'exclusiveClaimOwner': 'not recorded; persistent unitClaims is not the per-frame script claim set',
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    all_commands = [row for prefix in PREFIXES for row in rows(prefix, '-commands.jsonl')]
    commands = [row for row in all_commands if START <= row['record']['tick'] <= END and own_command(row)]
    all_hits = [row for prefix in PREFIXES for row in rows(prefix, '-native-hits.jsonl')]
    p0_plans = [row for prefix in PREFIXES for row in rows(prefix, '-plans.jsonl')
                if row['record']['owner'] == 'p0' and START <= row['record']['tick'] <= END]
    doctor_hits = [row for row in all_hits if START <= row['record']['tick'] <= END
                   and UID in (row['record']['attacker'], row['record']['target'])]
    death = next(row for row in rows(PREFIXES[1], '-native-deaths.jsonl')
                 if row['record']['type'] == 'native-unit-terminal' and row['record']['id'] == UID)
    release = load(Path(str(PREFIXES[0]) + '.json'))['actualReturnRelease']
    transitions, previous_script = [], None
    for row in commands:
        if row['record']['scriptId'] != previous_script:
            transitions.append(row)
            previous_script = row['record']['scriptId']
    first_accepted_heal = next(row for row in commands if row['record']['command']['type'] == 'cast'
                               and row['record']['command'].get('ability') == 'heal')
    # Scan all existing sampled frames, preserving source and phase. Effect
    # sampling cannot reconstruct casts whose short visual effect expired.
    observed_effects, patient_states = {}, []
    for prefix in PREFIXES:
        for folder in ('.frames', '.events', '.prethink'):
            for path in sorted(Path(str(prefix) + folder).glob('*.json.gz')):
                frame = load(path)
                snapshot = frame['snapshot']
                if not START <= snapshot['tick'] <= END:
                    continue
                for effect in snapshot['effects']:
                    if effect['type'] == 'heal' and effect.get('sourceId') == UID:
                        witness = {'source': str(path), 'sha256': sha(path), 'observedTick': snapshot['tick'], 'effect': effect}
                        if effect['id'] not in observed_effects or snapshot['tick'] < observed_effects[effect['id']]['observedTick']:
                            observed_effects[effect['id']] = witness
                if snapshot['tick'] > 15652:
                    patient = next((unit for unit in snapshot['units'] if unit['id'] == PATIENT and unit['hp'] > 0), None)
                    if patient and patient['maxHp'] == 167 and patient['hp'] > 25:
                        patient_states.append({'source': str(path), 'tick': snapshot['tick'], 'unit': brief(patient)})
    effects = sorted(observed_effects.values(), key=lambda row: (row['effect'].get('actionTick', row['observedTick']), row['observedTick']))
    injury = next(row for row in all_hits if row['record']['index'] == 716)
    assert injury['record']['target'] == PATIENT and injury['record']['tick'] == 15652 and injury['record']['hpAfter'] == 25
    patient_witness = min(patient_states, key=lambda row: row['tick'])
    assert patient_witness['tick'] == 15780 and patient_witness['unit']['hp'] == 80
    intervening_hits = [row for row in all_hits if row['record']['target'] == PATIENT
                        and 15652 < row['record']['tick'] <= patient_witness['tick']]
    assert not intervening_hits
    paths = [ROOT / name for name in (
        'candidate-return-episode.prethink/14100.json.gz', 'candidate-complete-tail.frames/14101.json.gz',
        'candidate-complete-tail.frames/14400.json.gz', 'candidate-complete-tail.events/14780-after-step-2.json.gz',
        'candidate-complete-tail.frames/15000.json.gz', 'candidate-complete-tail.prethink/15600.json.gz',
        'candidate-complete-tail.events/15780-after-step-5.json.gz', 'candidate-complete-tail.frames/16200.json.gz',
        'candidate-complete-tail.events/16656-after-step-10.json.gz', 'candidate-complete-tail.events/16802-after-step-12.json.gz',
        'candidate-complete-tail.events/16915-after-step-13.json.gz', 'candidate-complete-tail.events/17092-after-step-16.json.gz',
        'candidate-complete-tail.events/17137-after-step-17.json.gz', 'candidate-complete-tail.events/17154-after-step-18.json.gz',
        'candidate-complete-tail.events/17179-after-step-19.json.gz', 'candidate-complete-tail.events/17203-after-step-20.json.gz')]
    states = [state_view(path, commands) for path in paths]
    summary = {
        'classification': 'Only recorded ab0 continuation from13764, not ordinary0; no source changes, planner, native, game or tests.',
        'sourceHead': load(Path(str(PREFIXES[1]) + '.json'))['head'], 'window': [START, END],
        'actualReturnRelease': release,
        'firstAcceptedNonReturnCommand': commands[0],
        'frontlineTimingLimit': '14100 is the exact first accepted backline command after return release, initially near the south hall. No separate frontline-handoff or exclusive-claim event was recorded.14400 command is still near home;14780 complete state directly shows the northward march with the army.',
        'producerTransitions': transitions,
        'acceptedProducerCounts': dict(Counter(row['record']['scriptId'] for row in commands)),
        'firstAcceptedHealRequest': first_accepted_heal,
        'earliestSavedSourceTaggedHealEffects': effects,
        'actualHPRecoveryForFirstRequestedTarget': {'injury': injury, 'laterCompleteState': patient_witness,
                                                   'unchangedMaxHP': 167, 'observedNetGain': 55,
                                                   'interveningNativeHits': intervening_hits,
                                                   'casterAttribution': 'not proven by recipient HP alone'},
        'healingTimeLimit': 'First requested heal15645 is not counted as healed. Sampled recipient HP proves at least55 restored during(15652,15780], without actor attribution. The earliest saved2255 source-tagged heal effect is actionTick17070; actual first treatment may be earlier and cannot be dated from sparse frames. Cooldown199 at15780 is compatible with15739 but is not a directly observed first heal.',
        'death': death,
        'lastAcceptedDirectCommand': commands[-1],
        'lastP0PlanEntriesFor2255': [{'source': row['source'], 'line': row['line'], 'tick': row['record']['tick'],
                                    'doctorEntries': [entry for entry in row['record']['entries']
                                                      if UID in entry['command'].get('unitIds', []) or entry['command'].get('unitId') == UID]}
                                   for row in p0_plans if row['record']['tick'] >= 17145],
        'endPhaseGap': 'Last direct accepted command17145 is medicalRecovery holdPosition.17160/17175/17190 p0 plans contain no direct2255 entry; no raw claim sets are recorded, so this does not prove which script still owns2255. Actual17137/17154/17179 after-step full states exist; corresponding17145/17160/17175/17190 actual prethink frames do not.',
        'mostDiagnosticRecoverableStates': [str(ROOT / name) for name in (
            'candidate-complete-tail.events/14780-after-step-2.json.gz',
            'candidate-complete-tail.events/15780-after-step-5.json.gz',
            'candidate-complete-tail.events/16802-after-step-12.json.gz',
            'candidate-complete-tail.events/17092-after-step-16.json.gz',
            'candidate-complete-tail.events/17137-after-step-17.json.gz',
            'candidate-complete-tail.events/17154-after-step-18.json.gz',
            'candidate-complete-tail.events/17179-after-step-19.json.gz')],
        'wholeForceCoverProblemToInspect': [
            '14780 doctor is with moving troops: nearest archer1347 about32,footman1072 about164; south hall about843. This is supported northward departure rather than immediate isolated release.',
            '16656 three doctors cluster while general memory says hold back near1097,3536; this memory is objective background, not ownership. Actual nearby troops have mixed attack/aim/retreat orders.',
            '16802 doctor2255 is at1772,1420 with3733/5844 only32/35 away but nearest nonmedical troop322 away; raw troop orders are moving to the rear hold point. Three medical units subsequently target6197, who is actually dead by16915.',
            '17092 doctor2255 remains105HP with real healCD218 after its17070 cast, but nearest nonmedical troop is348 away and retreating;2255/3733 move south toward2444,1819 from their more northern position. This aims toward the force but has not yet restored cover in the observed state.',
            '17154 doctor1907 and5844 have died;2255 remains105HP next to wounded3733, nearest nonmedical troop327 and most others527+ away.2255 only starts taking the final fatal sequence later. FullHP therefore does not establish covered support positioning.',
            'Last accepted17145 medicalRecovery hold persists through the later sparse states; first incoming hit17179 precedes a fatal five-hit sequence ending17203. No subsequent direct accepted command is present. Determine per-frame claims from parent actual planner evidence rather than assigning ownership from the last scriptId.',
            'This is evidence for reconciling medical target pursuit with actual army assembly/withdrawal and front coverage. It is not a recommendation to change home selection, stop ownership, or one HP threshold.'],
        'limits': ['No exclusive per-frame claims recorded in plans/commands; accepted scriptId identifies the producer only.',
                   'Persistent memory unitClaims is not a claim certificate for the current planner frame.',
                   'Accepted casts and cast orders are not counted as HP restored.',
                   'Distances are descriptive straight-line metrics, not safe roads or movement predictions.',
                   'The medical move at17085 points south toward the army; spatial exposure does not by itself prove the command sends the doctor deeper into enemy territory. Actual routing and per-frame assignment need parent native/planner evidence.',
                   'All recommended restart frames are actual after-step or before-p0-planner fullworld/id/3mem; no mid-command state is presented as a before-think restart.',
                   'The complete branch failed at41057,p1WIN. Local medical benefit does not reverse that result or establish bootstrap acceptance.'],
        'rawInputHashes': [{'source': str(Path(str(prefix) + suffix)), 'sha256': sha(Path(str(prefix) + suffix))}
                           for prefix in PREFIXES for suffix in ('.json', '-commands.jsonl', '-plans.jsonl', '-native-hits.jsonl', '-native-deaths.jsonl')],
    }
    (OUT / 'timeline.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'state-witnesses.json').write_text(json.dumps(states, ensure_ascii=False, indent=2) + '\n')
    for name, data in (('raw-accepted-commands.jsonl', commands), ('raw-hits.jsonl', doctor_hits), ('raw-p0-plans.jsonl', p0_plans)):
        (OUT / name).write_text(''.join(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n' for row in data))
    print(json.dumps({'outputs': [{'name': name, 'sha256': sha(OUT / name)} for name in (
        'extract-doctor.py', 'timeline.json', 'state-witnesses.json', 'raw-accepted-commands.jsonl', 'raw-hits.jsonl', 'raw-p0-plans.jsonl')]}))


if __name__ == '__main__':
    main()
