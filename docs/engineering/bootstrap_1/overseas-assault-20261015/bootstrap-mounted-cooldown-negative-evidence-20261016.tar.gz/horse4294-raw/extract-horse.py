#!/usr/bin/env python3
"""Extract existing horse4294 evidence only. No game/planner/native imports or execution."""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = Path('/workspace/.playtest/bootstrap-combined-e566-archer-v8v8-ordinary0-20261016/game')
CAND = Path('/workspace/.playtest/bootstrap-mercenary-return-roads-20261016/candidate-complete-tail')
UID = 'unit-p0-horseArcher-4294'
START, END = 15600, 15896


def sha(path):
    with open(path, 'rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def load(path):
    with (gzip.open(path, 'rt') if str(path).endswith('.gz') else open(path)) as handle:
        return json.load(handle)


def ledger(prefix, suffix):
    path = Path(str(prefix) + suffix)
    with path.open() as handle:
        return [{'source': str(path), 'line': index, 'record': json.loads(line)}
                for index, line in enumerate(handle, 1) if line.strip()]


def unit_brief(unit, reference=None):
    result = {key: unit.get(key) for key in ('id', 'owner', 'kind', 'x', 'y', 'hp', 'maxHp', 'level', 'xp',
                                           'kills', 'order', 'orderQueue', 'cooldown', 'effects', 'abilityCooldowns',
                                           'speed', 'radius', 'attackDamage', 'attackRange', 'attackCooldown')}
    if reference is not None:
        result['straightDistanceToHorse'] = math.hypot(unit['x'] - reference['x'], unit['y'] - reference['y'])
    return result


def frame_state(label, prefix, suffix):
    path = Path(str(prefix) + suffix)
    frame = load(path)
    assert set(('snapshot', 'nextId', 'memories', 'setup')).issubset(frame)
    assert set(frame['memories']) == {'p0', 'p1', 'p2'}
    snapshot = frame['snapshot']
    horse = next((unit for unit in snapshot['units'] if unit['id'] == UID), None)
    corpse = next((corpse for corpse in snapshot.get('corpses', []) if corpse['unitId'] == UID), None)
    reference = horse if horse is not None else corpse
    assert reference is not None
    army = [unit for unit in snapshot['units'] if unit['owner'] == 'p0' and unit['id'] != UID
            and unit['kind'] != 'worker' and unit['hp'] > 0 and unit.get('expiresTick') is None]
    army.sort(key=lambda unit: math.hypot(unit['x'] - reference['x'], unit['y'] - reference['y']))
    doctors = [unit for unit in army if unit['kind'] in ('fieldMedic', 'priest')]
    enemy = [entity for entity in snapshot['units'] + snapshot['buildings']
             if entity['owner'] != 'p0' and entity['hp'] > 0 and entity['attackDamage'] > 0]
    enemy.sort(key=lambda unit: math.hypot(unit['x'] - reference['x'], unit['y'] - reference['y']))
    memory = frame['memories']['p0']
    return {
        'branch': label, 'tick': snapshot['tick'], 'path': str(path), 'sha256': sha(path),
        'nextId': frame['nextId'], 'memoryOwners': sorted(frame['memories']),
        'phase': 'actual p0-before-planner' if '.prethink/' in suffix else 'actual after-step; before next loop iteration',
        'isActualThinkBoundary': snapshot['tick'] % frame['setup']['thinkInterval'] == 0,
        'horse': unit_brief(horse) if horse else None, 'horseCorpse': corpse,
        'distanceReference': 'live-horse' if horse else 'post-step-corpse; differs from fatal-hit/previous-unit pose',
        'ownPermanentArmyComposition': dict(Counter(unit['kind'] for unit in army)),
        'otherOwnPermanentArmy': [unit_brief(unit, reference) for unit in army],
        'doctors': [{**unit_brief(unit, reference), 'storedHealCooldown': unit.get('abilityCooldowns', {}).get('heal'),
                     'nativeHealCooldownDefault': unit.get('abilityCooldowns', {}).get('heal', 0)} for unit in doctors],
        'nearestArmedEnemies': [unit_brief(unit, reference) for unit in enemy[:20]],
        'observedHealEffects': [effect for effect in snapshot['effects'] if effect['type'] == 'heal'],
        'persistentMemoryBackgroundOnly': {'general': memory.get('v6', {}).get('general'),
                                         'mounted': memory.get('mounted'),
                                         'unitClaim4294': memory.get('unitClaims', {}).get(UID)},
        'workers': sum(unit['owner'] == 'p0' and unit['kind'] == 'worker' and unit['hp'] > 0 for unit in snapshot['units']),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    all_raw_hits, all_raw_commands, all_births, branches = [], [], [], {}
    for label, prefix in (('baseline', BASE), ('candidate', CAND)):
        hits, commands = ledger(prefix, '-native-hits.jsonl'), ledger(prefix, '-commands.jsonl')
        relevant_hits = [row for row in hits if START <= row['record']['tick'] <= END
                         and UID in (row['record']['attacker'], row['record']['target'])]
        relevant_commands = [row for row in commands if START <= row['record']['tick'] <= END
                             and (UID in row['record']['command'].get('unitIds', [])
                                  or row['record']['command'].get('unitId') == UID
                                  or row['record']['command'].get('targetId') == UID)]
        own_commands = [row for row in commands if row['record']['owner'] == 'p0'
                        and (UID in row['record']['command'].get('unitIds', []) or row['record']['command'].get('unitId') == UID)]
        death = next(row for row in ledger(prefix, '-native-deaths.jsonl')
                     if row['record']['type'] == 'native-unit-terminal' and row['record']['id'] == UID)
        previous = [row for row in own_commands if row['record']['tick'] < START]
        hit_context = []
        for row in relevant_hits:
            before = [command for command in own_commands if command['record']['tick'] <= row['record']['tick']]
            hit_context.append({'hit': row, 'lastAcceptedOwnCommand': before[-1] if before else None})
        births = [row for row in ledger(prefix, '-native-events.jsonl') if START <= row['record']['tick'] <= END
                  and row['record']['type'] == 'unit-birth-observed' and row['record']['unit']['owner'] == 'p0']
        incoming = [row for row in relevant_hits if row['record']['target'] == UID]
        outgoing = [row for row in relevant_hits if row['record']['attacker'] == UID]
        branches[label] = {
            'death': death, 'windowIncomingCount': len(incoming), 'windowOutgoingCount': len(outgoing),
            'reportedIncomingDamage': sum(row['record']['damage'] for row in incoming),
            'incomingPositiveHPRemoved': sum(min(max(row['record']['hpBefore'], 0), row['record']['damage']) for row in incoming),
            'incomingHPSequence': [{'tick': row['record']['tick'], 'attacker': row['record']['attacker'],
                                    'before': row['record']['hpBefore'], 'after': row['record']['hpAfter']} for row in incoming],
            'commandScriptCounts': dict(Counter(row['record']['scriptId'] for row in relevant_commands if row['record']['owner'] == 'p0')),
            'lastAcceptedOwnCommandBefore15600': previous[-1] if previous else None,
            'allHitLastCommandPairs': hit_context,
            'acceptedHealCastsTargetingHorse': [row for row in relevant_commands if row['record']['command'].get('type') == 'cast'
                                               and row['record']['command'].get('ability') == 'heal'
                                               and row['record']['command'].get('targetId') == UID],
        }
        all_raw_hits.extend({'branch': label, **row} for row in relevant_hits)
        all_raw_commands.extend({'branch': label, **row} for row in relevant_commands)
        all_births.extend({'branch': label, **row} for row in births)
    frame_specs = {
        'baseline': (BASE, ('.events/15560-after-step-61.json.gz', '.frames/15600.json.gz',
                            '.events/15793-after-step-62.json.gz', '.events/15970-after-step-63.json.gz')),
        'candidate': (CAND, ('.frames/15600.json.gz', '.prethink/15600.json.gz',
                            '.events/15632-after-step-4.json.gz', '.events/15780-after-step-5.json.gz',
                            '.events/15797-after-step-6.json.gz', '.events/15896-after-step-7.json.gz')),
    }
    frames = [frame_state(label, prefix, suffix) for label, (prefix, suffixes) in frame_specs.items() for suffix in suffixes]
    for name, rows in (('raw-hits.jsonl', all_raw_hits), ('raw-accepted-commands.jsonl', all_raw_commands), ('raw-own-births.jsonl', all_births)):
        (OUT / name).write_text(''.join(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n' for row in rows))
    (OUT / 'state-witnesses.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')
    report = {
        'classification': 'Raw offline audit only: e566 ordinary0 world versus ab0 continuation switched at13764. Different worlds are not an a90-only causal test.',
        'window': [START, END], 'unitId': UID, 'branches': branches,
        'recoverableStateBoundary': {
            'candidateLatestAfterStepBeforeDeath': str(CAND) + '.events/15797-after-step-6.json.gz',
            'candidateLatestActualPrethinkBeforeDeath': str(CAND) + '.events/15780-after-step-5.json.gz',
            'candidateNamedPrethink15600': str(CAND) + '.prethink/15600.json.gz',
            'missingActualPrethinkTicks': [tick for tick in range(15615, 15886, 15) if tick != 15780],
            'missingSinceLatestActualPrethink': list(range(15795, 15886, 15)),
            'baselineBeforeDeathWindowNearestAfterStep': str(BASE) + '.events/15793-after-step-62.json.gz',
            'baselineNextAfterStep15970': '74ticks after candidate death; not a same-tick counterfactual.',
            'loopEvidence': 'sdk/game-runner.ts runGameLoop: issueDueAgentCommands at top of while, frameRuntime.tick then onStep. Thus after-step15780 precedes all15780 planning;15797 is between thinks.',
            'noSyntheticRecovery': 'Command logs do not supply missing worlds. No mid-command state is offered as a before-think restart.'},
        'reusableProblemToInvestigate': [
            'Candidate horse remains uninjured and deals no observed hit in15600–15843 while moving alone along the north edge, far from the main force and all four medics.',
            'Inspect whether mountedField objectives and escape geometry retain a viable return/assembly connection while enemies pursue across several think cycles; this requires the parent actual planner/native checks.',
            'Actual15600/15780 horse orders are attack+leash to cinderRunner7819, while the preceding accepted mountedField moves lack avoidCombat. Preserve this native-order versus accepted-command distinction when inspecting query intent.',
            'First injury15844 is followed by actual mobileCare moves15855/15870/15885 and death15896. These accepted command records do not establish safe reachability or simultaneous ownership.',
            'Source-tagged heal effects around the main force do not demonstrate support for the isolated horse. Raw cooldown0 is only a timing fact, not heal availability over2000distance.',
            'Do not infer a universal HP threshold, or blame a90 from commands on the already-divergent world.'],
        'limits': ['No planner, game, native, tests, or source edits executed.',
                   'All distances are straight-line descriptive metrics, not roads or reachable travel times.',
                   'Persistent memory is recorded as objective background, never asserted as current script ownership.',
                   'Sparse effect frames may miss short-lived effects. Accepted casts are not counted as healing.',
                   'At death, corpse pose and previous-unit/fatal-hit pose differ and are separately preserved.'],
        'sourceManifests': [{'path': str(Path(str(prefix) + '.json')), 'sha256': sha(Path(str(prefix) + '.json')),
                             'head': load(Path(str(prefix) + '.json'))['head']} for prefix in (BASE, CAND)],
        'rawInputHashes': [{'path': str(Path(str(prefix) + suffix)), 'sha256': sha(Path(str(prefix) + suffix))}
                           for prefix in (BASE, CAND) for suffix in ('-native-hits.jsonl', '-commands.jsonl', '-native-deaths.jsonl', '-native-events.jsonl')],
    }
    (OUT / 'diagnostic.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'outputs': [{'name': name, 'sha256': sha(OUT / name)} for name in (
        'extract-horse.py', 'diagnostic.json', 'state-witnesses.json', 'raw-hits.jsonl', 'raw-accepted-commands.jsonl', 'raw-own-births.jsonl')]}))


if __name__ == '__main__':
    main()
