# 原生持续武器施法的本轮订单归属

候选独立分支 codex/bootstrap-aimed-cast-owner-20261016，固定 d93f2c574bfa38451dedccbd5611671e7c669690，从未整合的1905派生，仅一个生产文件 script-runner.ts。claims与physical reserve共用短pure helper，按原生weapon路径的queued/ship/aimingProfile(unitRules)/out-of-range判据判断持续施法；真正瞬时heal/curse/summon和原远程走施、charge、显式bypass、same-script队列保原合同。没有新增commander、打分、阈值或兼容层。

最终相同25合同旧13红/12绿→新25绿，另7相关99绿，合124独立tests；单1024 tsc exit0，生产patch固定。初次新24绿1红是37455原battlefield已有claim却错误要求cast的测试，按原owner纠正，生产未改；各初稿/日志/诊断均保留。真实37410单批P0后100native-only步虽保留cast，却因移动目标/瞄准进展没有命中；这份负例不删除、不冒充normal3AI。一般构造场景证明无claim的武器cast可以跨tick真实出弹，不保证该移动目标会完成。

唯一正常三AI37200→37560候选来自原1905真实完整before-P0，世界/ID/三方memory/setup准确恢复；没有额外公令、actor过滤或改预算/敌人/规则。首差37395为已有battlefield归属阻止abilities抢pinningBolt；整个候选窗口没有该炮cast。它保住原普通攻击连续性：37461出普通bolt，37481三次原生命中39+27+19=85、击杀一敌，37515再出一弹（不记为已命中）。原同窗炮0hit。两目标塔末仍200，不能称拆塔。实际图 actual37481-normal-native-bolt.png 已用固定源码native drawWorld绘制并亲看。

首差前39plans/288公令attempt/70hits及13份15tick完整world/id/三方memory/setup等于原基线；完整初值也相等。37395-first-public-plan-difference是在planner返回后、publicbatch之前，memory已变，不能当before-P0恢复档。应使用37395-after-step-before-next-think。

窗口内永久损失0/4/6，原1/4/6；十敌逐fatal raw/corpse/removal/全owner计数严格闭合，无temporary/expiry。主将9866仅末3.85/477存活：11967击杀已受炮穿透伤害的1959后升3，37530学vigilance，之后实际减伤及更近phalanx一致；这是多actor真实轨迹，不是独立因素消融，也不保证37560以后活。局部零损与测试绿都不是完整比赛改善或最终验收。

后续已获准从这次37560完整afterstep同d93冷恢复并正常三AI继续自然终局，独立driver/cap已准备，实际执行状态以natural-tail-execution.json/输出为准。它的归属是37200换码后缀+同源继续，不是新普通0或d93共同11400完整局；旧1905的42248/24与fb88、11d8、f508各完整结果保原归属。原seed只在f508首次冻结0开局时未见，现在已观察，不因setup沿用unseen元数据而称新源未见。

1492 live逐Gitblob/完整sourcecap1989payload（含497 frozen）与184manifest、rules2严格绑定。原冻结策略不改，普通敌资源人口与地图出生不改。VALIDATION-EXECUTION.json里的noNativeCandidateRunYet是测试/源码freeze当时的阶段记录，随后真实360以NORMAL360-AUDIT.json及normal-execution.json为准，不追溯改写旧记录。原容器不可获取的未提交改动仍未恢复。


## 同源自然接续与边界

同d93从实际37560完整afterstep冷恢复，三方正常、MAX_SAFE、无人工公令/过滤，自然p0胜于40831，敌方两队units/buildings严格全部0。实际session47849/PID446578 exit0，8.747秒、RSS381420KiB、OOM不增；1492live、497frozen/184manifest/rules2及13前缀绑定pre/post完全一致。此前一次guard仅余1.32GB未spawn任何Node/Game，保insufficient记录，之后资源真实释放才启动，不算比赛失败。

37560→40831新增己损2：主将9866@37583仍死，仅较原晚23tick；新增fieldMedic34930@38348，原1905该医师活。原后段死者30019、3224、32289、27366本次均终活。完整继承账为p0=21/p1=81/p2=74/neutral17，193唯一永久死亡逐原始致死hit/尸体/移除/全owner计数exact，无temporary/expiry；整链32744 SDK attempts、3780 native hits。己损base catalog2560（旧1905为3105），veterans7/9等级/33kills（旧9/13/53），医护6（旧6）。只按同一实际37200输入的两条后缀比较，快1417tick、少3loss；不能冒充新d93普通0、共同11400完整局或三路线泛化。

炮27366在后缀实际伤害505（360窗85+tail420），终活220.75/290。37560..37590真实pinningBolt cast保留，37596技能弹rootTicks40发射，37613塔200→164伤36；后两普通29。39409第二真实技能弹，39424击毁p1主厅。26个初始敌建筑全部逐fatal raw确证移除；四塔38009/38790/39014/39153，双厅39179/39424。技能root对建筑是否实际生效未宣称。

最近完整40800→40831唯一31tick冷末窗session91451 exit0，原7cmd/9plans及每次全三方postmem/5hits/2events/31炮姿态逐对象exact，末world/id/三方mem/setup乃至gzipSHA完全相等；不是第二独立胜场。见TERMINAL31-EXACT-CLOSURE.json。

下一实际共同问题已交根与医疗作者：38160完整before-P0中34930满105HP但位于两塔480范围内，38115..38340每15持续medicalRecovery hold，38252起7次16伤终死。ACTUAL38160-MEDICAL-HOLD-DIAGNOSIS.json绑定完整原输入/三方mem/ownercommands/原hit。根将只在新组合医疗源纯P0核是否已改善，严格标为跨源诊断；本候选不热改医疗，不为每组件另跑0。


原生图已实际绘制并亲看：native37620-sustained-cast-tower164.png、native38009-first-tower-destroyed.png、native40831-terminal-overview.png。全input/source前后相等，三个512进程均exit0/OOM不增；最后overview实测RSS578844KiB/9.60s，高于先前380MB估值，按receipt保真。当前本agent无Game/test/compiler/query/render。SOURCE-DEPENDENCIES.json明确只改runner一生产文件，现有native依赖未改、无stable/medical/naval新依赖。
