"""Prepare one minimal same-source40800→40831 terminal closure, no Game execution."""
from pathlib import Path
import json,hashlib,gzip
D=Path('/tmp/bootstrap-aimed-cast-owner-1905-20261016');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
C=json.loads((D/'natural-tail-driver-cap.json').read_text());O=Path(C['output']);r=json.loads((O/'report.json').read_text());assert r['end']==40831 and r['winner']=='p0'and r['naturalComplete']
inp=D/'bound-inputs/actual-d93-40800-before-p0.json.gz';assert not inp.exists();inp.write_bytes((O/'frames/40800-after-step-before-next-think.json.gz').read_bytes());f=json.loads(gzip.decompress(inp.read_bytes()));assert f['snapshot']['tick']==40800 and f['snapshot']['match']['winner']is None
cs=[json.loads(l)for l in (O/'commands.jsonl').read_text().splitlines()];hs=[json.loads(l)for l in (O/'hits.jsonl').read_text().splitlines()];cb=30892+sum(c['tick']<40800 for c in cs);hb=3025+sum(h['tick']<=40800 for h in hs)
s=Path(C['driver']).read_text().replace('natural-tail-driver-cap.json','cold-terminal31-driver-cap.json').replace('actual-d93-37560-after-step-before-p0.json.gz','actual-d93-40800-before-p0.json.gz').replace('Exact actuald9337560 after-step before-P0','Exact actuald9340800 after-step before-P0').replace('start=37560,end=Number.MAX_SAFE_INTEGER','start=40800,end=40831')
s=s.replace('Same fixed d93 normal3AI natural continuation from actual d9337560 after-step world/id/all3mem. This is the37200 changed-code suffix plus same-source continuation, not a new ordinary0, unseen seed or a d93 common11400 fullGame. Zero human commands/filters/foe changes.','One minimal samefixed d93 terminal31 coldclosure40800→40831 from its own actualnatural fullstate. Normal3AI, no manualcommands/filters/world changes. Not another ordinary0, fullGame or independent victory sample; closure only.')
needle="if(commandBase!==30892||hitBase!==3025)throw Error('Same-source actualprefix ledger mismatch');"
extra="""for(const l of readFileSync(D+'/natural-from37560/commands.jsonl','utf8').split('\\n'))if(l){const c=JSON.parse(l);if(c.tick<40800)commandBase++;}
for(const l of readFileSync(D+'/natural-from37560/hits.jsonl','utf8').split('\\n'))if(l){const h=JSON.parse(l);if(h.tick<=40800){hitBase++;if(aliveIds.has(h.target))telemetry.lastHit.set(h.target,h);}}
if(commandBase!==CB||hitBase!==HB)throw Error('Terminal suffix actualprefix ledger mismatch');""".replace('CB',str(cb)).replace('HB',str(hb))
assert needle in s;s=s.replace(needle,needle+'\n'+extra)
driver=D/'native-cold-terminal31.ts';assert not driver.exists();driver.write_text(s)
cc={**C,'input':str(inp),'inputSHA256':H(inp),'driver':str(driver),'driverSHA256':H(driver),'output':str(D/'cold-terminal40800-40831'),'start':40800,'maxTicks':40831,'scope':'One authorized nearestcomplete31tick terminalcoldclosure of actuald93 natural suffix. All normal3AI, expected original suffixraw and finalwholeworld/id3mem/setup. Not a second independent full-game outcome.','expectedCommandBase':cb,'expectedHitBase':hb}
cc['externalInputs']={**C['externalInputs'],**{str(O/p):H(O/p)for p in ['commands.jsonl','hits.jsonl','plans.jsonl','post-plan-memories.jsonl','events.jsonl','deaths.jsonl','final.json.gz','report.json']}}
(D/'cold-terminal31-driver-cap.json').write_text(json.dumps(cc,indent=2)+'\n')
launch=(D/'launch-natural-tail.py').read_text().replace('natural-tail-driver-cap.json','cold-terminal31-driver-cap.json').replace('natural-tail-execution.json','cold-terminal31-execution.json').replace('natural-tail-insufficient-','cold-terminal31-insufficient-').replace('natural-tail-prelaunch.json','cold-terminal31-prelaunch.json').replace('natural-tail-native.log','cold-terminal31-native.log')
(D/'launch-cold-terminal31.py').write_text(launch)
print(json.dumps({'preparedOnly':True,'inputSHA256':H(inp),'sourceHead':C['sourceHead'],'driverSHA256':H(driver),'expectedCommandBase':cb,'expectedHitBase':hb,'expectedCommands':sum(c['tick']>=40800 for c in cs),'expectedHits':sum(h['tick']>40800 for h in hs),'noGameStarted':True}))
