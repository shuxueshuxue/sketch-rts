"""Prepare the authorized same-source continuation; never imports or runs Game/P0."""
from pathlib import Path
import json,hashlib,gzip
D=Path('/tmp/bootstrap-aimed-cast-owner-1905-20261016');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
C=json.loads((D/'normal-driver-cap.json').read_text());cap=json.loads(Path(C['sourceCap']).read_text())
inp=D/'bound-inputs/actual-d93-37560-after-step-before-p0.json.gz'
assert not inp.exists();inp.write_bytes((D/'normal37200-37560/final.json.gz').read_bytes())
f=json.loads(gzip.decompress(inp.read_bytes()));assert f['snapshot']['tick']==37560 and f['snapshot']['match']['winner'] is None
assert set(f['memories'])=={'p0','p1','p2'} and f['checkpointStage']=='focused-window-after-step-before-next-think'
s=(D/'native-normal37200-37560.ts').read_text()
s=s.replace('appendFileSync,existsSync','appendFileSync,existsSync,statfsSync')
s=s.replace("input=D+'/bound-inputs/original1905-37200-before-p0.json.gz'","input=D+'/bound-inputs/actual-d93-37560-after-step-before-p0.json.gz'")
s=s.replace("D+'/normal-driver-cap.json'","D+'/natural-tail-driver-cap.json'")
s=s.replace("const game=createGame('bareDuel'),memory=createAiMemoryProvider();", "const rawBeforeCreate={current:Number(readFileSync('/sys/fs/cgroup/memory.current','utf8')),max:Number(readFileSync('/sys/fs/cgroup/memory.max','utf8'))};if(rawBeforeCreate.max-rawBeforeCreate.current<2*1024**3)throw Error('Immediate pre-createGame headroom below2GiB');const game=createGame('bareDuel'),memory=createAiMemoryProvider();")
s=s.replace('Exact actual190537200 before-P0','Exact actuald9337560 after-step before-P0')
needle="// Inherit actual originalf508<=11400 thenfixed1905 until before-P037200 for ledger indices/lastHit only. This focused window does not become common11400 outcome."
extra="""for(const l of readFileSync(D+'/normal37200-37560/commands.jsonl','utf8').split('\\n'))if(l){const c=JSON.parse(l);if(c.tick<37560)commandBase++;}
for(const l of readFileSync(D+'/normal37200-37560/hits.jsonl','utf8').split('\\n'))if(l){const h=JSON.parse(l);if(h.tick<=37560){hitBase++;if(aliveIds.has(h.target))telemetry.lastHit.set(h.target,h);}}
// Exact attribution: f508 originalprefix<=11400, original1905<37200, d93 normal360<=37560. This continues the d93 changed-code37200 suffix, never an ordinary0 or a d93 common11400 Game.
if(commandBase!==30892||hitBase!==3025)throw Error('Same-source actualprefix ledger mismatch');"""
assert needle in s;s=s.replace(needle,extra)
start="const gunId='unit-p0-ballista-27366',gunProjectiles=new Set<string>(),originalPlans="
line=next(l for l in s.splitlines()if l.startswith(start))
s=s.replace(line,"const gunId='unit-p0-ballista-27366',gunProjectiles=new Set<string>(game.projectiles.filter((p:any)=>p.attackerId===gunId).map((p:any)=>p.id));let firstPublicDifference:any=null;")
s=s.replace('start=37200,end=37560','start=37560,end=Number.MAX_SAFE_INTEGER')
s=s.replace('Independent fixed aimed-weapon order ownership candidate normal3AI37200-37560 from exact original1905 wholeinput. Zero manual commands. Not an ordinary0, win or proof of full-game improvement.','Same fixed d93 normal3AI natural continuation from actual d9337560 after-step world/id/all3mem. This is the37200 changed-code suffix plus same-source continuation, not a new ordinary0, unseen seed or a d93 common11400 fullGame. Zero human commands/filters/foe changes.')
drop="const original=originalPlans.get(`${game.tick}:${ctx.owner}`);if(!firstPublicDifference&&!eq(entries,original)){firstPublicDifference={tick:game.tick,owner:ctx.owner,original,actual:entries};capture('first-public-plan-difference');}"
assert drop in s;s=s.replace(drop,'')
s=s.replace('if(game.tick%600===0||game.tick%15===0||game.match.winner)','if(game.tick%600===0||game.tick<=38160&&game.tick%15===0||game.match.winner)')
needle="if(!game.match.winner&&game.tick%600===0&&existsSync(D+'/PARENT-OBSERVATION-STOP.json'))"
guard="if(!game.match.winner&&game.tick%600===0){const fs=statfsSync(O!),freeBytes=Number(fs.bavail)*Number(fs.bsize);if(freeBytes<256*1024**2){observerStop={type:'infrastructure-disk-pause',freeBytes,requiredFreeBytes:256*1024**2,sourceHead:cap.head,observedTick:game.tick,phase:'After complete batch and native step at600, fullcheckpoint preserved; not a strategydefeat or gameplayhorizon.'};throw new ObservationStop('Temporary disk reserve below256MiB');}}"
assert needle in s;s=s.replace(needle,guard+needle)
s=s.replace('focused-window-after-step-before-next-think','natural-tail-after-step-before-next-think')
s=s.replace('restored,start,end,commandBase','restored,rawBeforeCreate,start,end,commandBase')
driver=D/'native-natural-tail37560.ts';assert not driver.exists();driver.write_text(s)
out=D/'natural-from37560'
nc={**C,'input':str(inp),'inputSHA256':H(inp),'driver':str(driver),'driverSHA256':H(driver),'output':str(out),'start':37560,'maxTicks':'Number.MAX_SAFE_INTEGER','scope':'Authorized samefixed d93 actual37560 continuation, normal3AI, no extra publiccommands/actor filters/budget or enemy changes. Zero ordinary0 claim. Actual predecessor is d93 normal37200→37560; initialsnapshot/id/all3mem/setup must match exactly. Periodic600 complete saves plus early15tick frames, eventfullstates, streamedraw/all3postmem, bounded12recent. Parentstop only explicit matchinghead; diskpause at600 reserve256MiB is infrastructure, not game result.'}
nc['externalInputs']={**C['externalInputs'],**{str(D/'normal37200-37560'/p):H(D/'normal37200-37560'/p)for p in ['final.json.gz','commands.jsonl','hits.jsonl','report.json']}}
(D/'natural-tail-driver-cap.json').write_text(json.dumps(nc,indent=2)+'\n')
launch=(D/'launch-normal.py').read_text().replace('normal-driver-cap.json','natural-tail-driver-cap.json').replace('normal-execution.json','natural-tail-execution.json').replace('normal-insufficient-','natural-tail-insufficient-').replace('normal-prelaunch.json','natural-tail-prelaunch.json').replace('normal-native.log','natural-tail-native.log')
launch=launch.replace("if mx-cur<r['requiredHeadroom']:","if mx-cur<r['requiredHeadroom'] or r['tmpFreeBytes']<256*1024**2:")
launch=launch.replace("No candidateGame spawned below2GiB","No tailGame spawned: below2GiB or256MiB disk reserve")
launcher=D/'launch-natural-tail.py';assert not launcher.exists();launcher.write_text(launch)
prepared={'classification':'Prepared-only; no Game/P0/query/step or new native process.','head':cap['head'],'input':str(inp),'inputSHA256':H(inp),'driver':str(driver),'driverSHA256':H(driver),'launcher':str(launcher),'launcherSHA256':H(launcher),'cap':str(D/'natural-tail-driver-cap.json'),'capSHA256':H(D/'natural-tail-driver-cap.json'),'exactPredecessorFinalBytes':H(inp)==H(D/'normal37200-37560/final.json.gz'),'inputStage':f['checkpointStage'],'inputTick':37560,'ownerMemories':list(f['memories']),'nextId':f['nextId'],'unitsLost':f['snapshot']['match']['stats']['unitsLost'],'prefixCommandBase':30892,'prefixHitBase':3025,'noArbitraryTickCutoff':True,'source1492Frozen497Manifest184Rules2':True}
(D/'NATURAL-TAIL-PREPARED.json').write_text(json.dumps(prepared,indent=2)+'\n');print(json.dumps(prepared))
