"""Offline evidence audit only; no production imports, planner, Game or native steps."""
from pathlib import Path
import collections, gzip, hashlib, json, math, subprocess, tarfile
D=Path('/tmp/bootstrap-aimed-cast-owner-1905-20261016')
O=D/'normal37200-37560'
B=Path('/tmp/bootstrap-siege-firing-station-1905-20261016/baseline37200-37560')
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines()]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
unit=lambda f,i:next((u for u in f['snapshot']['units']+f['snapshot']['buildings'] if u['id']==i),None)
cap=json.loads((D/'candidate-runtime-source.json').read_text()); S=Path(cap['root'])
r=json.loads((O/'report.json').read_text()); oldr=json.loads((B/'report.json').read_text())
inp=load(D/'bound-inputs/original1905-37200-before-p0.json.gz'); final=load(O/'final.json.gz'); oldf=load(B/'final.json.gz')
assert cap['head']==r['head']=='d93f2c574bfa38451dedccbd5611671e7c669690'
assert all(r['restored'].values()) and r['inputUnchanged'] and r['end']==37560 and r['winner'] is None
assert len(cap['files'])==1492 and len(cap['frozenFiles'])==497 and len(cap['frozenManifestFiles'])==184 and cap['rulesVersion']==2
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==cap['head']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True).strip()
for v in cap['files']: assert H(S/v['path'])==v['sha256'],v['path']
for f in ['sourcePre','sourcePost','frozenPre','frozenPost','externalInputPre','externalInputPost']:assert not r[f]['changed']
assert H(Path(cap['sourceArchive']))==cap['sourceArchiveSHA256']
with tarfile.open(cap['sourceArchive']) as t:
 index=json.load(t.extractfile('INDEX.json'))['files']
 assert len(index)==1989
 assert set(index)=={m.name for m in t if m.isfile() and m.name!='INDEX.json'}
 for name,h in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
 assert all(index['live/'+v['path']]==v['sha256']for v in cap['files'])
 assert all(index['frozen/'+p]==h for p,h in cap['frozenFiles'].items())
commands=rows(O/'commands.jsonl');hits=rows(O/'hits.jsonl');plans=rows(O/'plans.jsonl');deaths=rows(O/'deaths.jsonl');events=rows(O/'events.jsonl')
oldcommands=rows(B/'commands.jsonl');oldhits=rows(B/'hits.jsonl');oldplans=rows(B/'plans.jsonl');hi={h['index']:h for h in hits}
assert [x['index']for x in commands]==list(range(30393,30393+499))
assert [h['index']for h in hits]==list(range(2818,2818+207))
assert len(plans)==72 and len(commands)==r['commandCount']==499 and len(hits)==r['hitCount']==207
first=next((a,b)for a,b in zip(plans,oldplans)if a!=b)
assert first[0]['tick']==37395 and first[0]['owner']=='p0'
assert r['firstPublicDifference']['actual']==first[0]['entries'] and r['firstPublicDifference']['original']==first[1]['entries']
assert first[0]['entries']==[e for e in first[1]['entries']if not(e['scriptId']=='abilities'and e['command'].get('unitId')=='unit-p0-ballista-27366')]
prefixplans=[p for p in plans if p['tick']<37395];assert prefixplans==[p for p in oldplans if p['tick']<37395]
prefixcommands=[p for p in commands if p['tick']<37395];assert prefixcommands==[p for p in oldcommands if p['tick']<37395]
prefixhits=[p for p in hits if p['tick']<=37395];assert prefixhits==[p for p in oldhits if p['tick']<=37395]
frameproof=[]
for p in sorted((O/'frames').glob('*-after-step-before-next-think.json.gz')):
 tick=int(p.name.split('-')[0])
 if tick>37395:continue
 a=load(p);b=load(B/'frames'/p.name);same={k:a[k]==b[k]for k in ['snapshot','nextId','memories','setup']}
 assert all(same.values()),p.name
 frameproof.append({'tick':tick,'candidate':str(p),'baseline':str(B/'frames'/p.name),'sha256':H(p),'fieldsExactlyEqual':same})
initial=load(O/'frames/37200-initial-before-think.json.gz')
assert all(initial[k]==inp[k]for k in ['snapshot','nextId','memories','setup'])
postmem=rows(O/'post-plan-memories.jsonl');assert len(postmem)==len(plans)
assert [(m['tick'],m['ownerJustPlanned'])for m in postmem]==[(p['tick'],p['owner'])for p in plans]
assert all(set(m['memories'])==set(inp['memories'])for m in postmem)
confirmed=[]
for e in deaths:
 assert e['type']=='native-unit-terminal' and e['permanent']
 u=e.get('atObservation')or e['previous'];f=e['evidence']['nativePositiveToNonpositiveHit']
 assert not u.get('expiresTick') and f==hi[f['index']] and f['target']==e['id'] and f['positiveToNonpositive'] and f['hpBefore']>0 and f['hpAfter']<=0
 rm=next(x for x in events if x['type']=='unit-removal'and x['previous']['id']==e['id'])
 corpse=next(c for c in final['snapshot']['corpses']if c['unitId']==e['id'])
 assert corpse['diedAtTick']==e['tick'] and unit(final,e['id']) is None
 confirmed.append({'id':e['id'],'owner':u['owner'],'kind':u['kind'],'tick':e['tick'],'fatalIndex':f['index'],'fatalRawExact':True,'corpse':corpse,'removedTick':rm['tick'],'permanent':True})
delta={o:r['finalNativeUnitsLost'].get(o,0)-r['initialNativeUnitsLost'].get(o,0)for o in r['initialNativeUnitsLost']}
cnt=collections.Counter(x['owner']for x in confirmed)
assert len(confirmed)==len(set(x['id']for x in confirmed))==10 and all(cnt[o]==v for o,v in delta.items())
assert not [e for e in events if 'expir' in e.get('type','') or e.get('permanent') is False]
gun='unit-p0-ballista-27366';hero='unit-p0-knight-9866';tower='building-p2-defenseTower-1488'
gunhits=[h for h in hits if h['attacker']==gun];gunin=[h for h in hits if h['target']==gun];shots=rows(O/'gun-projectiles.jsonl')
assert len(shots)==2 and [s['tick']for s in shots]==[37461,37515]
assert len(gunhits)==3 and sum(h['damage']for h in gunhits)==85 and not gunin
assert [h['tick']for h in gunhits]==[37481]*3 and sum(h['positiveToNonpositive']for h in gunhits)==1
assert all(s['projectile']['attackKind']=='bolt'for s in shots)
guncommands=[c for c in commands if c['command'].get('unitId')==gun or gun in c['command'].get('unitIds',[])]
assert len(guncommands)==1 and guncommands[0]['tick']==37260 and guncommands[0]['scriptId']=='battlefield'
assert guncommands[0]['command']['type']=='attack' and not any(c['command']['type']=='cast'for c in guncommands)
assert unit(final,tower)['hp']==unit(inp,tower)['hp']==200
assert unit(final,hero)['hp']>0 and unit(oldf,hero)is None
assert not [h for h in oldhits if h['attacker']==gun]
learn=next(c for c in commands if c['command'].get('unitId')=='unit-p0-raider-11967'and c['command']['type']=='learnVeteranSkill')
assert learn['tick']==37530 and learn['command']['skill']=='veteranVigilance'
raiderkill=next(h for h in hits if h['tick']==37525 and h['attacker']=='unit-p0-raider-11967')
assert raiderkill['positiveToNonpositive']and raiderkill['target']=='unit-p2-witch-1959'
assert any(h['target']==raiderkill['target']for h in gunhits)
herohits=[h for h in hits if h['target']==hero];oldherohits=[h for h in oldhits if h['target']==hero]
assert len(herohits)==len(oldherohits)
assert [(h['tick'],h['attacker'])for h in herohits]==[(h['tick'],h['attacker'])for h in oldherohits]
damagechanges=[{'tick':a['tick'],'attacker':a['attacker'],'baselineDamage':b['damage'],'candidateDamage':a['damage']}for a,b in zip(herohits,oldherohits)if a['damage']!=b['damage']]
assert [x['tick']for x in damagechanges]==[37542,37543,37550,37560]
assert math.isclose(sum(h['damage']for h in oldherohits)-sum(h['damage']for h in herohits),8.2,abs_tol=1e-9)
assert not [c for c in commands if c['command']['type']in ['cast','useItem']and c['command'].get('targetId')==hero]
firstDiffFile=O/'frames/37395-first-public-plan-difference.json.gz'
out={'classification':'One fixed d93 normal3AI360 diagnostic from exact original1905 actual37200. No human commands, actor filtering, budgets/world/foe changes, new ordinary0, win, or full-game improvement claim.',
 'sourceHead':cap['head'],'base':'1905ab9cfac85f8176a19f52da28c22efc5bf022','sourceAndFrozen':{'live1492GitClean':True,'full497FrozenAnd184ManifestRules2Unchanged':True,'sourceArchive1989PayloadStrictReadback':True,'manifestSHA256':cap['frozenManifestSHA256'],'sourceCapsuleSHA256':H(D/'candidate-runtime-source.json')},
 'runtimeExecution':json.loads((D/'normal-execution.json').read_text()),'setupSemantics':'Original factory seed was unseen at f508 freeze/first0 only; it is now observed and this changed-code37200 continuation is not unseen/new ordinary0.',
 'counts':{'SDKAttempts':len(commands),'nativeHits':len(hits),'normalOwnerPlans':len(plans),'all3PostPlannerMemories':len(postmem),'everyNativeTickGunTrajectory':len(rows(O/'gun-trajectory.jsonl'))},
 'restore':r['restored'],'firstPublicDifference':{'tick':37395,'owner':'p0','difference':'Only original abilities pinningBolt cast is absent because actor already belongs to earlier claim. Remaining first P0 entries exactly equal.','original':first[1],'candidate':first[0],'capture':str(firstDiffFile),'captureCaution':'Mid-planner memory state; NOT a before-P0 resumable checkpoint. Whole37395 after-step-before-next-think frame is the valid before-P0 input.'},
 'commonPrefix':{'normalPlansExact':len(prefixplans),'commandAttemptsExact':len(prefixcommands),'nativeHitsExactThrough37395':len(prefixhits),'completeInitialWorldId3memSetupExact':True,'complete15tickFramesExact':frameproof,'noInventedFullEqualityAfterFirstDifference':True},
 'allOwnerLossLedger':{'counterDeltaAllKeys':delta,'confirmedPermanent':confirmed,'temporaryDeathOrExpiry':[],'allFatalRawCorpseRemovalAndCountersExactlyClosed':True,'baselineDelta':{o:oldr['finalNativeUnitsLost'].get(o,0)-oldr['initialNativeUnitsLost'].get(o,0)for o in inp['memories']}},
 'actualGun':{'initial':unit(inp,gun),'final':unit(final,gun),'publicAttempts':guncommands,'nativeProjectileFirstSightings':shots,'nativeOutgoingHits':gunhits,'outgoingDamage':85,'kills':1,'nativeIncomingHits':gunin,'baselineOutgoingHits':[],'noCastWasPublishedInCandidateWindow':True,'secondProjectileNoRecordedNativeHit':'Two actual emitted ordinary bolts, only first has the three recorded hits. Do not count second emission as damage or infer its miss cause without trajectory evidence.'},
 'tower':{'initial':unit(inp,tower),'final':unit(final,tower),'damageByGun':0,'autonomousDemolitionNotProven':True},
 'heroBoundary':{'id':hero,'candidateFinal':unit(final,hero),'baselineFinal':None,'survivalLimitedTo37560Boundary':True,'incomingHitTimesAndAttackersIdentical':True,'firstDamageDifferenceTick':37542,'actualDamageChanges':damagechanges,'totalDamageDifference':8.2,'noHealCastToHero':True,'earlierRaiderKill':raiderkill,'actualLearnSkillAttempt':learn,'limitedCausalInterpretation':'Gun pierces witch1959 at37481; raider11967 kills her37525, reaches level3 and learns vigilance37530. Saved positions and authored veteran aura rules match reduced37542/37543 damage; later phalanx coverage matches37550/37560. This is an observed multi-actor trajectory, not a separate causal factor isolation or promise of survival beyond37560.'},
 'limits':['This proves native ordinary firing continuity for the existing battlefield task, not pinningBolt completion in this autonomous360. A separate constructed native positive proves retained weapon casts can complete; the savedactual37410 single-batch100step moving-target probe remains a negative.',
 'Current-frame claims/reserve ownership does not establish safe target selection, future-frame tactical task ownership, all maps/traffic/units, tower demolition, macro improvement, or a complete game.',
 'The unintegrated1905 common11400 42248win/24loss and all fb88/11d8/f508 whole-game tradeoffs remain separately attributed.','Original unavailable container uncommitted edits remain unrecovered.'],
 'evidenceBindings':{str(p):H(p)for p in [D/'production.patch',D/'normal-driver-cap.json',O/'launch.json',O/'report.json',O/'final.json.gz',D/'VALIDATION-EXECUTION.json',D/'ACTUAL37410-NATIVE-COMPLETION-NEGATIVE.json']}}
(D/'NORMAL360-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'allAudited':True,'firstDifference':37395,'prefixPlans':len(prefixplans),'prefixCommands':len(prefixcommands),'prefixHits':len(prefixhits),'exactFrames':len(frameproof),'windowLoss':delta,'gunNativeDamage':85,'gunNativeKills':1,'heroEndHP':unit(final,hero)['hp'],'towerEndHP':unit(final,tower)['hp'],'auditSHA256':H(D/'NORMAL360-AUDIT.json')}))
