"""Offline whole attribution/terminal ledger and value audit. No imports of game code."""
from pathlib import Path
import json,gzip,hashlib,collections,subprocess
D=Path('/tmp/bootstrap-aimed-cast-owner-1905-20261016');N=D/'natural-from37560';W=D/'normal37200-37560'
P=Path('/tmp/bootstrap-completed-post-11d8-20261016');F=Path('/workspace/.playtest/bootstrap-knight-f508-v8v8-holdout-20261016')
rows=lambda p:[json.loads(l)for l in p.read_text().splitlines()]
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
final=load(N/'final.json.gz');initial=load(D/'bound-inputs/original1905-37200-before-p0.json.gz');nr=json.loads((N/'report.json').read_text())
cap=json.loads((D/'candidate-runtime-source.json').read_text());S=Path(cap['root'])
assert final['snapshot']['tick']==40831 and final['snapshot']['match']['winner']=='p0'and nr['naturalComplete']and nr['observerStop']is None
assert all(nr['restored'].values())and nr['inputUnchanged']and cap['head']==nr['head']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=S,text=True).strip()
assert all(H(S/v['path'])==v['sha256']for v in cap['files'])
assert all(not nr[n]['changed']for n in ['sourcePre','sourcePost','frozenPre','frozenPost','externalInputPre','externalInputPost'])
streams={};bindings={};provenance=[]
for name,fs,ps in [('hits','native-hits','hits'),('commands','commands','commands'),('deaths','native-deaths','deaths'),('events','native-events','events')]:
 fp=F/('native-game-'+fs+'.jsonl');pp=P/'natural-common11400'/(ps+'.jsonl');wp=W/(ps+'.jsonl');np=N/(ps+'.jsonl')
 allf=rows(fp);allp=rows(pp)
 if name=='commands':f=[r for r in allf if r['tick']<11400];p=[r for r in allp if r['tick']<37200]
 else:
  f=[r for r in allf if r['tick']<=11400]
  p=[r for r in allp if r['tick']<37200 or r['tick']==37200 and r.get('commandIndex')is None]
 a=rows(wp);b=rows(np);streams[name]=f+p+a+b
 for q in [fp,pp,wp,np]:bindings[str(q)]=H(q)
 provenance.append({'stream':name,'parts':[{'path':str(fp),'head':'f5081ad3cc012f7f4a442383f4818ed23281cc37','selection':'tick<11400 commands; tick<=11400 native','records':len(f)},{'path':str(pp),'head':'1905ab9cfac85f8176a19f52da28c22efc5bf022','selection':'tick<37200 commands; before37200 plus native-step at37200 for native','records':len(p)},{'path':str(wp),'head':cap['head'],'selection':'all actual normal37200→37560','records':len(a)},{'path':str(np),'head':cap['head'],'selection':'all actual same-source37560→40831','records':len(b)}]})
hits=streams['hits'];cmds=streams['commands'];hi={h['index']:h for h in hits};events=streams['events'];deaths=streams['deaths']
assert [h['index']for h in hits]==list(range(len(hits)))and len(hits)==3780
assert [c['index']for c in cmds]==list(range(len(cmds)))and len(cmds)==32744
assert all(d['type']=='native-unit-terminal'and d['permanent']for d in deaths)
assert len(deaths)==len(set(d['id']for d in deaths))==193
assert not [e for e in events if 'expir' in e['type'] or e.get('permanent')is False]
corpses={c['unitId']:c for c in final['snapshot']['corpses']};live={u['id']:u for u in final['snapshot']['units']}
checks=[]
for d in deaths:
 u=d.get('atObservation')or d['previous'];fatal=d['evidence']['nativePositiveToNonpositiveHit'];rm=next(e for e in events if e['type']=='unit-removal'and e['previous']['id']==d['id']);cp=corpses[d['id']]
 assert u.get('expiresTick')is None and fatal==hi[fatal['index']]and fatal['target']==d['id']and fatal['positiveToNonpositive']and fatal['hpBefore']>0>=fatal['hpAfter']
 assert d['id']not in live and cp['diedAtTick']==d['tick']and cp['owner']==u['owner']
 checks.append({'id':d['id'],'owner':u['owner'],'kind':u['kind'],'tick':d['tick'],'level':u.get('level',0),'xp':u.get('xp',0),'kills':u.get('kills',0),'fatalRawIndex':fatal['index'],'fatalRawExact':True,'removedTick':rm['tick'],'corpseId':cp['id'],'corpseTick':cp['diedAtTick'],'permanent':True,'deathSourcePart':'originalf508'if d['tick']<=11400 else'original1905'if d['tick']<37200 else'd93normal360'if d['tick']<=37560 else'd93same-source-tail'})
cnt=collections.Counter(c['owner']for c in checks);counters=final['snapshot']['match']['stats']['unitsLost'];assert all(cnt[o]==n for o,n in counters.items())
strict={o:{'units':sum(u['owner']==o for u in final['snapshot']['units']),'buildings':sum(u['owner']==o for u in final['snapshot']['buildings'])}for o in ['p1','p2']};assert all(not sum(v.values())for v in strict.values())
costsource=P/'LOSS-COST-LEVEL-COHORT-COMPARISON.json';oldcost=json.loads(costsource.read_text());cost={x['kind']:x['unitBaseGoldCost']for v in oldcost['results'].values()for x in v['details']}
cohort={u['id']for u in load(F/'native-game.frames/11400.json.gz')['snapshot']['units']if u['owner']=='p0'}
own=[c for c in checks if c['owner']=='p0'];old=oldcost['results']['1905ab9c-common11400-natural42248'];oldIds={x['id']for x in old['details']};newIds={x['id']for x in own}
for x in own:x['unitBaseGoldCost']=cost[x['kind']];x['original11400Cohort']=x['id']in cohort
medical={'priest','fieldMedic'}
valuation={'scope':'Actual inheritedprefix+changed-code37200 suffix. Base authored recruitment cost only, not actual purchase/item/upgrade/time valuation.','p0PermanentDeaths':len(own),'kinds':dict(collections.Counter(x['kind']for x in own)),'baseRecruitmentCostLost':sum(x['unitBaseGoldCost']for x in own),'veteranLost':sum(x['level']>0 for x in own),'lostLevelSum':sum(x['level']for x in own),'lostKillSum':sum(x['kills']for x in own),'original11400CohortLost':sum(x['original11400Cohort']for x in own),'original11400CohortBaseGoldLost':sum(x['unitBaseGoldCost']for x in own if x['original11400Cohort']),'medicalLost':sum(x['kind']in medical for x in own),'details':own,'old1905ActualWholeReference':{k:old[k]for k in ['permanentDeaths','baseRecruitmentCostLost','veteranLost','lostLevelSum','lostKillSum','original11400CohortLost','original11400CohortLostBaseGold']},'savedOld1905Deaths':[{'oldDeath':x,'newTerminalAlive':live[x['id']]}for x in old['details']if x['id']in oldIds-newIds],'newDeathsAbsentOld1905':[x for x in own if x['id']in newIds-oldIds]}
assert len(own)==21 and valuation['baseRecruitmentCostLost']==2560
assert oldIds-newIds=={'unit-p0-raider-30019','unit-p0-horseArcher-3224','unit-p0-priest-32289','unit-p0-ballista-27366'}and newIds-oldIds=={'unit-p0-fieldMedic-34930'}
gun='unit-p0-ballista-27366';gh=[h for h in hits if h['tick']>37200 and h['attacker']==gun];assert len(gh)==17 and sum(h['damage']for h in gh)==505
shots=rows(W/'gun-projectiles.jsonl')+rows(N/'gun-projectiles.jsonl');skillshots=[s for s in shots if s['projectile'].get('rootTicks')==40]
assert [s['tick']for s in skillshots]==[37596,39409]
gunorders=rows(W/'gun-public-orders.jsonl')+rows(N/'gun-public-orders.jsonl')
firstskill=next(h for h in gh if h['tick']==37613);secondskill=next(h for h in gh if h['tick']==39424)
assert firstskill['target']=='building-p2-defenseTower-1488'and firstskill['damage']==36 and firstskill['hpBefore']==200 and firstskill['hpAfter']==164
assert secondskill['target']=='building-p1-townhall'and secondskill['damage']==36 and secondskill['positiveToNonpositive']
buildings=[e for e in events if e['type']=='native-building-terminal'and e['tick']>37560]
assert len(buildings)==26
tailInitial=load(N/'frames/37560-initial-before-think.json.gz')
assert {e['previous']['id']for e in buildings}=={b['id']for b in tailInitial['snapshot']['buildings']if b['owner']in ['p1','p2']}
buildingchecks=[]
for e in buildings:
 u=e['previous'];fatal=e['lastNativeHit'];assert fatal==hi[fatal['index']]and fatal['target']==u['id']and fatal['positiveToNonpositive'];assert not any(b['id']==u['id']for b in final['snapshot']['buildings'])
 buildingchecks.append({'id':u['id'],'owner':u['owner'],'kind':u['kind'],'tick':e['tick'],'fatalRawIndex':fatal['index'],'fatalRawExact':True,'attacker':fatal['attacker'],'attackerKind':fatal['attackerKind'],'removedAtTerminal':True})
key=[b for b in buildingchecks if b['kind']in ['defenseTower','townHall']]
hero=next(c for c in own if c['id']=='unit-p0-knight-9866');assert hero['tick']==37583 and hero['level']==2 and hero['kills']==9
out={'classification':'Naturalp0victory40831 of one d93 changed-code37200 suffix followed by its own exact37560 same-source continuation. Fullordinary0/newunseen or d93common11400 results are NOT claimed. No sourcehotedit or extra human commands/actor filters/foe/resource/population changes.','head':cap['head'],'rulesVersion':2,'winner':'p0','terminalTick':40831,'attribution':provenance,'counts':{'SDKAttemptsIncludingInheritedPrefix':len(cmds),'nativeHitsIncludingInheritedPrefix':len(hits),'permanentDeathsAllOwners':len(checks),'changedCode37200SuffixSDKAttempts':499+nr['commandCount'],'changedCode37200SuffixNativeHits':207+nr['hitCount']},'source1492Frozen497Manifest184PrePostExact':True,'allOwnerCounters':counters,'allOwnerConfirmedPermanent':dict(cnt),'allDeathEvidenceExact':True,'temporaryOrExpiryDeaths':[],'deathChecks':checks,'terminalStrictEnemies':strict,'terminalRestorableWholeFields':['snapshot','nextId','memories.p0','memories.p1','memories.p2','setup'],'minimalTerminalColdClosure':{'path':str(D/'TERMINAL31-EXACT-CLOSURE.json'),'sha256':H(D/'TERMINAL31-EXACT-CLOSURE.json')},'valuation':valuation,'all26EnemyBuildingTerminalsExact':buildingchecks,'keyTowersAndHalls':key,'actualArtillery':{'id':gun,'final':live[gun],'outgoingNativeHits':gh,'totalActualDamage':505,'nativeProjectilesEmitted':len(shots),'actualSkillProjectiles':skillshots,'publicOrderObservations':gunorders,'firstSkillHit':firstskill,'secondSkillFatalHallHit':secondskill,'limits':'Normal360 had zero cast and ordinarybolt85/1kill; only the later same-source tail proves realautonomous pinningBolt completion, at37596/37613 and39409/39424. Skill statusroot on buildings is not claimed.'},'hero':{'actualDeath':hero,'old1905DeathTick':37560,'deathDelayedTicks':23,'preserved':False},'comparison':{'sharedActualStart':37200,'original1905FinalTick':42248,'candidateChangedCodeSuffixFinalTick':40831,'fasterTicks':1417,'old1905P0Loss':24,'newInheritedPrefixAndSuffixP0Loss':21,'lossDifference':-3,'baseCostDifference':2560-3105,'scope':'Valid same-actual37200 input suffix comparison. Candidate would potentially change the earlier11400→37200 trajectory, so do not attribute this to a d93 common11400 Game, newordinary0, allroutes, mapgeneralization or finalbootstrapacceptance.'},'unresolvedActual':'Mainknight9866 stilldies37583 under tower fire; newfieldMedic34930 dies38348 whereas old1905 it survives. Four other oldlaterdeaths avoided in this observedsuffix. Next narrow diagnosis should use actualmedical/battlefield/backline owner/road/weapon context rather than claim general screen/medical safety solved.','bindings':{**bindings,str(costsource):H(costsource),str(N/'report.json'):H(N/'report.json'),str(N/'final.json.gz'):H(N/'final.json.gz'),str(D/'candidate-runtime-source.json'):H(D/'candidate-runtime-source.json')},'originalUncommittedGap':'Unavailable originalcontainer uncommitted modifications remain unrecovered.'}
(D/'NATURAL-SUFFIX-TERMINAL-LEDGER.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'allLedgerExact':True,'allOwnerPermanent':dict(cnt),'valuation':{k:v for k,v in valuation.items()if k not in ['details','savedOld1905Deaths','newDeathsAbsentOld1905','old1905ActualWholeReference']},'keyTowersAndHalls':key,'gunDamage':505,'actualSkills':[s['tick']for s in skillshots],'heroDeath':37583,'auditSHA256':H(D/'NATURAL-SUFFIX-TERMINAL-LEDGER.json')}))
