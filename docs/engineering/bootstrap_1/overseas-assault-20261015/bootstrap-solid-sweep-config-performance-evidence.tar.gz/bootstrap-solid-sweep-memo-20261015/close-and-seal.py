import pathlib,json,hashlib,tarfile,subprocess,datetime
p=pathlib.Path(__file__).parent;negative=p.parent/'bootstrap-solid-sweep-perf-20261015';cap=json.loads((p/'candidate-source.json').read_text());src=pathlib.Path(cap['sourceRoot']);native=json.loads((p/'native-equivalence-18600-19200.json').read_text());assert all(native['restore'].values()) and all(native['same'].values())
changes=[q for q,h in cap['hashes'].items() if hashlib.sha256((src/q).read_bytes()).hexdigest()!=h];status=subprocess.check_output(['git','-C',str(src),'status','--porcelain'],text=True);assert not changes and not status
frozen=json.loads((p/'frozen-policy.json').read_text());verified=[]
with tarfile.open(p/'frozen-runtime-source.tar.gz') as tf:
 for q,h in frozen['files'].items():
  assert hashlib.sha256(tf.extractfile(q).read()).hexdigest()==h;verified.append(q)
sourceCheck={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(src),'head':subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip(),'files':len(cap['hashes']),'changes':changes,'status':status,'frozenFilesVerified':len(verified),'frozenRevision':frozen['revision'],'manifestSHA256':hashlib.sha256((p/'frozen-policy.json').read_bytes()).hexdigest()};(p/'final-source-check.json').write_text(json.dumps(sourceCheck,indent=2)+'\n')
counts=native['counts'];cpu=json.loads((p/'planner18600-alternating-cpu.json').read_text());proof=json.loads((p/'actual-configuration-proof.json').read_text());route=json.loads((p/'route-and-contact-equivalence.json').read_text());row=route['results'][0]
readme=f'''# Exact solid configuration reuse — fixed5cd pure query candidate

Final production tree: `{sourceCheck['head']}`, independent sparse control `{src}`. Base fixed63b6d49264358d8c3efeb0801ea10b314fb10758. The ancestry includes negative last-entry candidatefad617, so apply/review **final-vs63b6.patch** for the complete final delta; do not cherry-pick5cd alone without its parent. No main, rules3/4, AI strategy, native collision rule, terrain/body approximation or frozen opponent changes. No new ordinary0, CPUprofile or matrix.

## What changed and why

The parent's single existing real18600 profile locates naval→coastalBatteryWaypoint→planCoastalVoyage→native shipRouteTraffic→solid sweep→Minkowski/convex polygon work. Original saved input is the already developed summoner-v8 Archipelago generator seed (`map.id=ladder`, not fixed official/unseen evidence). A read-only count on an isolated base copy observes11456body sweeps but170distinct whole-sweep configurations in the same views. Last-entry input signatures repeat only1432/11456; its five finite CPU pairs are retained as a negative/uncertain candidate in the sibling evidence directory and this archive.

The final view keeps a per-body current full outline copy and a map of exact local swept-hull inputs. Every point/double is compared with `Object.is`; input coordinates are copied by value, not retained from mutable callers. Any changed body polygon invalidates all that body's configurations. Signed-zero-aware numeric strings are only an index; fullpoint equality gates reuse, so a key collision cannot return the wrong result. Original Minkowski exceptions propagate; no new throw or altered invalid-input result is introduced. Only pure Minkowski polygons are reused; current from/to, activeBody, nearby order, sweep steps, overlap exceptions, earliest contact, contact point/normal and final traffic callback are still evaluated normally. Cache is scoped to the existing traffic closure; no global/snapshot/TTL/final-sweep cache or heading quantization.

## Correctness evidence

*65tests pass across existing collision/course/navigation/coastal-voyage and three new mutation/heading boundaries; tsc passes. The earlier deep-water fixture failure is preserved with last-entry evidence and corrected to native shallow terrain; a soldier on deepwater is correctly ignored by the original rules.
*Unchanged frozen source manifests contain184files, revision`{frozen['revision']}`, SHA`{sourceCheck['manifestSHA256']}`. All1575candidate live/support files remain byte-identical/clean at closure.
*First unprofiled real18600 fullplanner query matches actual ordinary publiccommands, original profile afterMemory, and preserves full snapshot/bothsavedmem.
*An external esbuild instrumentation bundle (fixed production files untouched) recomputes **every reused Minkowski polygon** with the original function and Object.is-compares all output coordinates: **{proof['metrics']['hits']}hits / {proof['metrics']['misses']}misses / {proof['metrics']['bodyInvalidations']}body initializations/geometry invalidations**, no mismatches. First64 coordinate witnesses retained, allhits checked. Instrumentation CPU is not a performance measurement.
*Actual bombardShip2100→farm1377 public native route at original100000budget: complete15point route object, **{row['callbacks']}callbacks** with all original arguments/results/order, {row['callbackResultCounts']['clear']}clear/{row['callbackResultCounts']['blocked']}blocked, and65fullcontact samples all equal. The bank includes51changed-heading,4pivot,1actualcontact cases. Callback trace gz and strictcomparison retained.
*Normal bothAI **18600→19200** from original completeworld/nextId/bothmem, candidate source fixed throughout: restoreworld/id/allmem true; terminalworld/id/allmem/**{counts['commands']}commands/{counts['hits']}hits** all exact against saved63b6ordinary0. No command insertion/filtering, resource manipulation or manual movement. This short replay is pure-equivalence evidence, not a newordinary0, stitched win or tactical benefit.

## Finite CPU measurements and limits

Two prespecified alternating fullplanner pairs, with onecoldquery/source excluded from warm totals:

|pair|base CPU ms|candidate CPU ms|reduction|
|--|--:|--:|--:|
'''+''.join(f"|{r['round']}|{r['baseCpu']:.3f}|{r['candidateCpu']:.3f}|{r['cpuReductionPercent']:.2f}%|\n"for r in cpu['pairs'])+f'''
Aggregate processCPU {cpu['aggregate']['baseCpu']:.3f}→{cpu['aggregate']['candidateCpu']:.3f}ms ({cpu['aggregate']['cpuReductionPercent']:.2f}% lower) for these two exact-input pairs. Base secondpair is a high outlier and both raw pairs remain visible. This is not a whole-game or general hardware speedup claim. Route equivalence work briefly overlapped initial cold warmup; the excluded cold numbers are retained. No additional profile/CPU pairs were run. All measured source pre/post hashes and input savedworld/bothmem unchanged, commands/afterMemory exact. Full native600tick equivalence closes the source before any merge recommendation.

## Portable evidence and recovery

`candidate-live-source.tar.gz` contains all1575 live/support source paths matchingcandidate-source.json. `frozen-runtime-source.tar.gz` contains the exact184 frozen runtime files; manifestverified again at closure. `original-input-and-profile/` preserves exact18600/19200world+nextId+bothmem, actualsource63b6report/publiccommands/hits and the sole original CPUprofile/analysis. `final-vs63b6.patch` is the complete concrete production+test delta; dependency lock is in the source tar. Scripts retain original absolutepaths for provenance; relocate harness constants into a separate output directory and run with cwd at exact recovered source root because the unchanged frozen planner uses cwd-relative git archive. A clean repository with exact historical frozen commit supports native replay directly; alternatively the supplied frozen source has everyoriginalbyte for an external source-capsule harness. No dependency binaries are bundled.

Both final and last-entry experiment files, initial fixture error logs, allfive uncertain last-entry CPU pairs, finaltwo CPU pairs and full returned route/contact/configuration witnesses are archived. No ordinary0 history/source was changed. This is an engine query optimization candidate for parent review, not bootstrap_1 tactical completion or finalacceptance; three-route/fullgame/generalization requirements and original failed-container uncommitted recovery gap remain.
'''
(p/'README.md').write_text(readme.replace('\n*', '\n* '))
roots=[p,negative];files=[]
for root in roots:
 for q in sorted(root.rglob('*')):
  if q.is_file() and not q.is_symlink() and q.name!='INDEX.sha256':files.append((q,root.name+'/'+str(q.relative_to(root))))
index=''.join(hashlib.sha256(q.read_bytes()).hexdigest()+'  '+name+'\n'for q,name in files);(p/'INDEX.sha256').write_text(index);files.append((p/'INDEX.sha256',p.name+'/INDEX.sha256'))
archive=p.parent/'bootstrap-solid-sweep-config-performance-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
 for q,name in files:tf.add(q,arcname=name,recursive=False)
expected={name:hashlib.sha256(q.read_bytes()).hexdigest()for q,name in files}
with tarfile.open(archive)as tf:actual={m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest()for m in tf.getmembers()if m.isfile()}
assert expected==actual
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'allPayloadBytesVerified':True,'candidate':sourceCheck['head'],'finalPatchSHA256':hashlib.sha256((p/'final-vs63b6.patch').read_bytes()).hexdigest(),'nativeRestore':native['restore'],'nativeSame':native['same'],'nativeCounts':counts,'cpuPairs':cpu['pairs'],'cpuAggregate':cpu['aggregate'],'sourceCheck':sourceCheck};(p.parent/'bootstrap-solid-sweep-config-performance-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
