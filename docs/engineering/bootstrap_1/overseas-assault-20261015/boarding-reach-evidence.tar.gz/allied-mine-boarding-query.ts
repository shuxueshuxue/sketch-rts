import { sketchScene } from '../../src/sdk/scene';
import { SdkCommandFrameRuntime } from '../../src/sdk/commands/frame';
import { issuePlayerCommand, snapshotGame, stepGame } from '../../src/shared/sim';
import type { BootstrapAiVersion, RaceId } from '../../src/shared/types';
import { createAiPolicyMemory } from '../../src/ai/memory';
import { runAiCommandEntriesFromScripts } from '../../src/ai/policy/script-runner';
import { navalBudgetReserve, navalWant } from '../../src/ai/policy/naval';
import { bootstrapPolicyContext, bootstrapScripts } from '../../src/ai/bootstrap_1/policy';

function colonyScene(race: RaceId, mirror: boolean, claim: 'hall' | 'miner', mainland: boolean) {
  const x = (value: number) => mirror ? 4096 - value : value;
  let scene = sketchScene('respect-allied-mines').map('bareDuel').replaceDefaults()
    .player('us', { race, team: 'a' }).player('ally', { race, team: 'a' }).player('foe', { team: 'b' })
    .townHall('us', x(500), 500).goldMine('main', x(788), 500, 6000)
    .townHall('us', x(500), 3000).goldMine('natural', x(788), 3000, 6000)
    .townHall('foe', x(500), 3800).townHall('ally', x(3300), 3600)
    .goldMine('allied-island', x(3288), 800, 6000).goldMine('free-island', x(3000), 2500, 6000)
    .unit('us', 'transport', x(1000), 1800, { id: 'boat' });
  if (claim === 'hall') scene = scene.townHall('ally', x(3000), 800);
  else scene = scene.worker('ally', x(3288), 840,
    { order: { type: 'mine', resourceId: 'allied-island', phase: 'toMine', timer: 0 } })
    .worker('ally', x(3288), 870,
      { order: { type: 'mine', resourceId: 'allied-island', phase: 'toMine', timer: 0 } });
  if (mainland) {
    scene = scene.goldMine('allied-mainland', x(788), 1512, 6000);
    if (claim === 'hall') scene = scene.townHall('ally', x(500), 1512);
    else scene = scene.townHall('ally', x(500), 1000).worker('ally', x(788), 1552,
      { order: { type: 'mine', resourceId: 'allied-mainland', phase: 'toMine', timer: 0 } });
  }
  for (let index = 0; index < 5; index++) scene = scene
    .worker('us', x(550), 470 + index * 20, { order: { type: 'mine', resourceId: 'main', phase: 'toMine', timer: 0 } })
    .worker('us', x(550), 2970 + index * 20, { order: { type: 'mine', resourceId: 'natural', phase: 'toMine', timer: 0 } });
  const game = scene.build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) => {
    const col = mirror ? 127 - index % 128 : index % 128;
    return col < 25 || col >= 76 ? '.' : '~';
  }).join('') };
  stepGame(game);
  return game;
}



import { boardingBerth, BOARDING_GAP } from '../../src/shared/naval';
import { isOpenGround, isWalkable, walkDestination, walkableGoal } from '../../src/shared/terrain';
import { hullFits, nearestShipPose, planShipRoute } from '../../src/shared/ship-navigation';
import { distanceToHull, shipProfile } from '../../src/shared/ship-geometry';
import { writeFileSync } from 'node:fs';
const game=colonyScene('grove',false,'hall',false);
const boat=game.units.find(u=>u.id==='boat')!, worker=game.units.find(u=>u.owner==='us'&&u.kind==='worker')!;
const land=walkDestination(game.map,worker,walkableGoal(game.map,boat.x,boat.y));
const water=walkableGoal(game.map,land.x,land.y,'sea');
const sea=nearestShipPose(game.map,boat,water);
const acceptable=nearestShipPose(game.map,boat,water,boat,p=>distanceToHull({...boat,...p,sailing:{...boat.sailing!,heading:p.heading}},land)<=worker.radius+BOARDING_GAP);
console.log(JSON.stringify({tick:game.tick,worker,boat,terrain:{cell:game.map.terrain!.cell,chars:[...new Set(game.map.terrain!.cells)],boundaryX:800},land,water,sea,seaDistance:sea&&distanceToHull({...boat,...sea,sailing:{...boat.sailing!,heading:sea.heading}},land),berth:boardingBerth(game.map,worker,boat),acceptable,acceptableDistance:acceptable&&distanceToHull({...boat,...acceptable,sailing:{...boat.sailing!,heading:acceptable.heading}},land),profile:{length:shipProfile(boat)!.length,beam:shipProfile(boat)!.beam},allowed:worker.radius+BOARDING_GAP}));
issuePlayerCommand(game,'us',{type:'board',unitIds:[worker.id],transportId:boat.id});
if(!acceptable)throw new Error('No physical pose found');
issuePlayerCommand(game,'us',{type:'move',unitIds:[boat.id],x:acceptable.x,y:acceptable.y});
for(let i=0;i<1200;i++){
 stepGame(game);
 if(i%150===149 || worker.deck){console.log(JSON.stringify({tick:game.tick,worker:{x:worker.x,y:worker.y,deck:worker.deck,order:worker.order},boat:{x:boat.x,y:boat.y,heading:boat.sailing?.heading,order:boat.order,route:boat.sailing?.route},actualDistance:distanceToHull(boat,worker),hullFits:hullFits(game.map,boat)}));}
 if(worker.deck)break;
}
writeFileSync(new URL('./allied-mine-boarding-query-final.json',import.meta.url),JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
