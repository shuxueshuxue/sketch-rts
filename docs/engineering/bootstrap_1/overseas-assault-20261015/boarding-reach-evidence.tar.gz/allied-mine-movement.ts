import { sketchScene } from '../../src/sdk/scene';
import { SdkCommandFrameRuntime } from '../../src/sdk/commands/frame';
import { issuePlayerCommand, snapshotGame, stepGame } from '../../src/shared/sim';
import type { BootstrapAiVersion, RaceId } from '../../src/shared/types';
import { createAiPolicyMemory } from '../../src/ai/memory';
import { runAiCommandEntriesFromScripts } from '../../src/ai/policy/script-runner';
import { navalBudgetReserve, navalWant } from '../../src/ai/policy/naval';
import { bootstrapPolicyContext, bootstrapScripts } from '../../src/ai/bootstrap_1/policy';

function colonyScene(race: RaceId, mirror: boolean, claim: 'hall' | 'miner', mainland: boolean) {
  const x = (value: number) => mirror ? 4096 - value : value;
  let scene = sketchScene('respect-allied-mines').map('bareDuel').replaceDefaults()
    .player('us', { race, team: 'a' }).player('ally', { race, team: 'a' }).player('foe', { team: 'b' })
    .townHall('us', x(500), 500).goldMine('main', x(788), 500, 6000)
    .townHall('us', x(500), 3000).goldMine('natural', x(788), 3000, 6000)
    .townHall('foe', x(500), 3800).townHall('ally', x(3300), 3600)
    .goldMine('allied-island', x(3288), 800, 6000).goldMine('free-island', x(3000), 2500, 6000)
    .unit('us', 'transport', x(1000), 1800, { id: 'boat' });
  if (claim === 'hall') scene = scene.townHall('ally', x(3000), 800);
  else scene = scene.worker('ally', x(3288), 840,
    { order: { type: 'mine', resourceId: 'allied-island', phase: 'toMine', timer: 0 } })
    .worker('ally', x(3288), 870,
      { order: { type: 'mine', resourceId: 'allied-island', phase: 'toMine', timer: 0 } });
  if (mainland) {
    scene = scene.goldMine('allied-mainland', x(788), 1512, 6000);
    if (claim === 'hall') scene = scene.townHall('ally', x(500), 1512);
    else scene = scene.townHall('ally', x(500), 1000).worker('ally', x(788), 1552,
      { order: { type: 'mine', resourceId: 'allied-mainland', phase: 'toMine', timer: 0 } });
  }
  for (let index = 0; index < 5; index++) scene = scene
    .worker('us', x(550), 470 + index * 20, { order: { type: 'mine', resourceId: 'main', phase: 'toMine', timer: 0 } })
    .worker('us', x(550), 2970 + index * 20, { order: { type: 'mine', resourceId: 'natural', phase: 'toMine', timer: 0 } });
  const game = scene.build().createGame();
  game.map.terrain = { cell: 32, cols: 128, rows: 128, cells: Array.from({ length: 128 * 128 }, (_, index) => {
    const col = mirror ? 127 - index % 128 : index % 128;
    return col < 25 || col >= 76 ? '.' : '~';
  }).join('') };
  stepGame(game);
  return game;
}


const game=colonyScene('grove',false,'hall',false),memory=createAiPolicyMemory(),sdk=new SdkCommandFrameRuntime(game);
const scripts=bootstrapScripts('v9_archer').filter(script=>script.id==='naval');
const boat=game.units.find(u=>u.id==='boat')!,origin={x:boat.x,y:boat.y};
for(let i=0;i<1200;i++){
 if(i%15===0){const s=snapshotGame(game),o=bootstrapPolicyContext(s,'us','v9_archer',{memory,teams:game.teams});sdk.issue(runAiCommandEntriesFromScripts(s,'us',scripts,o).map(e=>({...e,playerId:'us'})),{},{checksum:false});}
 stepGame(game);
 if(i%150===149)console.log(JSON.stringify({tick:game.tick,boat:{x:boat.x,y:boat.y,order:boat.order},distance:Math.hypot(boat.x-origin.x,boat.y-origin.y),mission:memory.naval?.ferries?.boat,boarders:game.units.filter(u=>u.owner==='us'&&(u.deck||u.order.type==='board')).map(u=>({id:u.id,x:u.x,y:u.y,deck:u.deck,order:u.order})),winner:game.match.winner,spent:game.match.stats.goldSpent.us}));
}
