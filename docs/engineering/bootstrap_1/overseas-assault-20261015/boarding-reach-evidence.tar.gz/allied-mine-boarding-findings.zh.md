# 盟矿回归中的原生接岸缺陷

原48个排列中的失败不能只通过删除 `order.type === move` 来消除。原场景在固定旧基线上同样失败，问题先于矿产前景预测改动。完整初始场景保存在 `src/ai/bootstrap_1/fixtures/allied-mines-boarding-shore.json.gz`；没有为诊断更改原地图、单位位置、船体或登船距离。

## 因果证据

`boardingBerth` 的 fallback 把原岸点 `(784,1808)` 投影到海上，然后只问第一个 hullFits 的 pose。该 pose 为 `(880,1808,π/2)`，到岸点的 hull 距离43.2，超过原 worker半径15+BOARDING_GAP24=39；于是整个岸被直接放弃。相同原地图与船体另有合法 pose，例如 `(912,1776,7π/4)`，hull 到原岸点距离25.373。公开船 move 的手动诊断能到达另一个合法子格 pose `(864,1808,π/2)`；公开工人 move 到岸后 board 能成功。这些手动诊断只证明物理可行，不能证明自动修复。

完整原 scene 的独立红测试仅一次发公开 `board`，指定原 worker-2/4。到tick1201船仍在 `(1000,1800)`，工人走到岸边但无 berth、无 deck。修复在 `src/shared/naval.ts` 的两个 `nearestShipPose` 查询中加入原生 `distanceToHull <= passenger.radius + BOARDING_GAP` accepts，保持原岸点、范围、地形和碰撞判定。相同完整场景和相同唯一公开 board 命令，两个原工人在tick391均真实登船；全程每tick hullFits=true。未注入 order、heading、berth，未人工移动任何一方。

## 测试意义

原生接人时，船的 order保留 idle，但 sails 真的在前进。green tick301已离开起点约84像素。因此原48排列的 move枚举断言不成立。更新断言要求真实船体位移超过32且存在真实boarding berth，同时保留免费岛目标、不占盟矿、零损失、零支出和无胜者断言。新native回归要求两个真实工人都登船，并在接岸途中JSON恢复后比较完整snapshot及nextId；另有不可达岩岸拒绝案例。

本项是恢复原生登船查询与盟矿测试可信度的局部工作，不是完整bootstrap胜利/泛化证据。普通开局、换代码存档续局和最终完整比赛仍由主任务另行记录。
