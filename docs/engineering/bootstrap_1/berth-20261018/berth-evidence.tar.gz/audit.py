from pathlib import Path
import json,gzip,hashlib
r=Path('/workspace/bootstrap-1-berth-20261018')
read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
inp=Path('/workspace/bootstrap-1-assembly-20261018/input-33600.json.gz');cp=read(inp);initial=cp['snapshot'];cohort={u['id']:u for u in initial['units'] if u.get('deck',{}).get('shipId')=='unit-p0-carrier-2915'}
report={'input':str(inp),'inputSha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'initialCohort':list(cohort),'runs':{}}
for name in ['baseline33600','complete-chain33600','complete-chain-v2-33600','complete-chain-v3-33600','complete-chain-v4-33600','complete-chain-v5-33600']:
 d=r/name;q=json.loads((d/'result.json').read_text());first=read(d/'frames/33600.json.gz');final={u['id']:u for u in q['remaining']};frames=[read(p)['snapshot'] for p in sorted((d/'frames').glob('*.gz'))];events=json.loads((d/'sequence.json').read_text())if(d/'sequence.json').exists()else[];done=next((e['tick']for e in events if e.get('to')=='done'),None)
 damage=[json.loads(l)for l in(d/'hits.jsonl').read_text().splitlines() if json.loads(l)['target']['id'] in cohort]
 report['runs'][name]={'initialSnapshotEquivalent':first['snapshot']==initial,'initialNextIdEquivalent':first['nextId']==cp['nextId'],'initialMemoriesEquivalent':first['memories']==cp['memories'],'sourceChangedDuringRun':q['sourceChangedDuringRun'],'tick':q['tick'],'winner':q['winner'],'doneTick':done,'totalUnitsLost':q['stats']['unitsLost']['p0'],'gold':q['players']['p0']['gold'],'cohortDamageEvents':len(damage),'cohortRemaining':{i:final.get(i) for i in cohort},'minObservedHp':{i:min((u['hp'] for f in frames for u in f['units']if u['id']==i),default=None)for i in cohort}}
 if done:
  f=read(d/f'frames/{done}.json.gz')['snapshot'];u={u['id']:u for u in f['units']};report['runs'][name]['completion']={i:{'hp':u[i]['hp'],'initialHp':v['hp'],'deck':u[i].get('deck'),'distanceToHome':((u[i]['x']-6256)**2+(u[i]['y']-2480)**2)**.5} for i,v in cohort.items()}
for name in ['after-baseline36600','after-v5-36600']:
 if not(r/name/'result.json').exists():continue
 q=json.loads((r/name/'result.json').read_text());u={u['id']:u for u in q['remaining']};report['runs'][name]={'tick':q['tick'],'winner':q['winner'],'totalUnitsLost':q['stats']['unitsLost']['p0'],'gold':q['players']['p0']['gold'],'sourceChangedDuringRun':q['sourceChangedDuringRun'],'cohortRemaining':{i:u.get(i)for i in cohort}}
(r/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print([(k,v.get('doneTick'),v.get('totalUnitsLost'),v.get('cohortDamageEvents'))for k,v in report['runs'].items()])
