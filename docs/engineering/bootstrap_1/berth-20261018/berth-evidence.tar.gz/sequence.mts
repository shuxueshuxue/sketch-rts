import { beginShipCollisionFrame } from '/workspace/bootstrap-1-resume/src/shared/ship-collisions.ts';
import { planVoyageRoute } from '/workspace/bootstrap-1-resume/src/shared/ship-navigation.ts';
import { shipRouteTraffic } from '/workspace/bootstrap-1-resume/src/shared/ship-avoidance.ts';
import { coastalFireDisks,coastalFireSegmentClear } from '/workspace/bootstrap-1-resume/src/ai/policy/coastal-voyage.ts';
import { combatCapability } from '/workspace/bootstrap-1-resume/src/shared/combat-capabilities.ts';
import { shipProfile,distanceToHull } from '/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
import { isEnemyOwner } from '/workspace/bootstrap-1-resume/src/ai/policy/ownership.ts';
export function sequence(initial:any,report:(x:any)=>void){
 const carrierId='unit-p0-carrier-2915',cutterId='unit-p0-cutter-6047';
 const initialCarrier=initial.units.find((u:any)=>u.id===carrierId),home={x:initialCarrier.x,y:initialCarrier.y,heading:initialCarrier.sailing.heading};
 const reverse={x:home.x-160*Math.cos(home.heading),y:home.y-160*Math.sin(home.heading),heading:home.heading};
 let phase='reverse',cutterGoal:any,issued=false;
 const safeRoute=(s:any,ship:any,goal:any)=>{
  const moving={...ship,order:{type:'move',...goal,avoidCombat:true},orderQueue:[],sailing:{...ship.sailing}};delete moving.sailing.route;
  const units=s.units.map((u:any)=>u.id===ship.id?moving:u);beginShipCollisionFrame(units,s.map,[...s.buildings,...s.obstacles??[]]);
  const route=planVoyageRoute(s.map,moving,goal,shipRouteTraffic(s.map,moving,units),1024);if(route.partial||!route.points.length)return;
  const radius=Math.max(...shipProfile(ship)!.hull.map(p=>Math.hypot(p.x,p.y))),o={teams:s.teams};
  const disks=[...coastalFireDisks(s,ship,o,0),...s.units.filter((u:any)=>u.sailing&&isEnemyOwner(s,'p0',u.owner,o)&&combatCapability(s,u).armed).map((u:any)=>({id:u.id,x:u.x,y:u.y,radius:combatCapability(s,u).range+radius}))];
  let prev={x:ship.x,y:ship.y,heading:ship.sailing.heading};for(const p of route.points){if(!coastalFireSegmentClear(prev,p,disks))return;prev=p;}return route;
 };
 const distance=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
 return (s:any,entries:any[])=>{
  const carrier=s.units.find((u:any)=>u.id===carrierId),cutter=s.units.find((u:any)=>u.id===cutterId);if(!carrier||!cutter)return entries;
  const transition=(next:string)=>{report({tick:s.tick,from:phase,to:next,carrier:{x:carrier.x,y:carrier.y},cutter:{x:cutter.x,y:cutter.y}});phase=next;issued=false;};
  if(phase==='reverse'&&distance(carrier,reverse)<3)transition('clear');
  if(phase==='clear'&&!cutterGoal){
   for(const reach of [160,240,320]){for(const angle of [Math.PI/4,Math.PI/2,3*Math.PI/4,0,Math.PI]){
    const goal={x:cutter.x+reach*Math.cos(angle),y:cutter.y+reach*Math.sin(angle),heading:cutter.sailing.heading};
    if(![{x:6220,y:3100},{x:6212,y:3100}].every(p=>distanceToHull({...cutter,...goal,sailing:{...cutter.sailing,heading:goal.heading}},p)>35))continue;
    const route=safeRoute(s,cutter,goal);if(route){cutterGoal=goal;report({tick:s.tick,phase,cutterGoal,route});break;}
   }if(cutterGoal)break;}
  }
  if(phase==='clear'&&cutterGoal&&distance(cutter,cutterGoal)<3)transition('return');
  if(phase==='return'&&distance(carrier,home)<3)transition('unload');
  const cargo=s.units.filter((u:any)=>u.deck?.shipId===carrierId);
  if(phase==='unload'&&!cargo.length)transition('done');
  if(phase==='done')return entries;
  // Local diagnostic helm ownership only; ordinary policy still runs and all
  // other players, units, economy and physical contacts remain active.
  const reserved=new Set([carrierId,cutterId]);
  const kept=entries.filter((e:any)=>!('unitIds'in e.command&&e.command.unitIds.some((id:string)=>reserved.has(id)))
   &&!(e.command.type==='unloadPassenger'&&phase!=='unload'&&reserved.has(e.command.transportId)));
  if(phase==='unload')kept.push(...entries.filter((e:any)=>'unitIds'in e.command&&e.command.unitIds.includes(carrierId)&&!e.command.unitIds.includes(cutterId)));
  const push=(command:any)=>kept.push({playerId:'p0',source:'external-agent',scriptId:'diagnosticBerthSequence',command});
  if(!issued){
   const ship=phase==='clear'?cutter:carrier,goal=phase==='reverse'?reverse:phase==='clear'?cutterGoal:phase==='return'?home:undefined;
   if(goal){const route=safeRoute(s,ship,goal);if(route){push({type:'stop',unitIds:[ship.id===carrierId?cutterId:carrierId]});push({type:'move',unitIds:[ship.id],...goal,avoidCombat:true});issued=true;report({tick:s.tick,phase,goal,route});}}
   else if(phase==='unload'){push({type:'stop',unitIds:[cutterId]});issued=true;}
  }
  return kept;
 };
}
