import { sequence } from './sequence-egress-v2.mts';
import { mkdirSync, writeFileSync, openSync, writeSync, closeSync, readFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { bootstrapMatches, bootstrapGame } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/benchmark.ts';
import { runAiGameLoop } from '/workspace/bootstrap-1-resume/src/ai/game-runner.ts';
import { createAiMemoryProvider } from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import { createBootstrapCommandPlanner, frozenPolicyManifest } from '/workspace/bootstrap-1-resume/scripts/bootstrap_1-planner.ts';
import { snapshotGame, restoreSnapshotIntoGame } from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
const out=process.argv[2]!, limit=Number(process.argv[3]??60000), resume=process.argv[4];
mkdirSync(out,{recursive:false});mkdirSync(out+'/frames');
const sha=(s:Buffer|string)=>createHash('sha256').update(s).digest('hex');
const paths=execFileSync('git',['ls-files','src','scripts'],{encoding:'utf8'}).trim().split('\n').filter(p=>/\.(ts|mts|js|mjs)$/.test(p));
paths.push('/workspace/bootstrap-1-berth-20261018/observe-complete-chain-v2.mts','/workspace/bootstrap-1-berth-20261018/sequence-egress-v2.mts');
const source=Object.fromEntries(paths.map(p=>[p,sha(readFileSync(p))]));
const match={...JSON.parse(gunzipSync(readFileSync(resume!)).toString()).match,maxTicks:limit};
if(!match)throw Error('missing match');
const game=bootstrapGame(match), memories=createAiMemoryProvider();
if(resume){const cp=JSON.parse(gunzipSync(readFileSync(resume)).toString());restoreSnapshotIntoGame(game,cp.snapshot,cp.nextId);for(const [p,m]of Object.entries(cp.memories))memories.set!(p,m as any);}
const startTick=game.tick, ordinary=await createBootstrapCommandPlanner(memories);
const events:any[]=[];const intervene=sequence(snapshotGame(game),(event:any)=>{events.push(event);writeFileSync(out+'/sequence.json',JSON.stringify(events,null,2));});
let helperActive=true;
const planner=(input:any)=>{
 let entries=ordinary(input);if(process.argv[5]!=='sequence'||input.owner!=='p0')return entries;
 entries=intervene(input.snapshot,entries);const helper=input.snapshot.units.find((u:any)=>u.id==='unit-p0-lancer-1820');
 if(!helper)return entries;
 if(helperActive){entries=entries.flatMap((e:any)=>{if('unitIds'in e.command){const unitIds=e.command.unitIds.filter((id:string)=>id!==helper.id);return unitIds.length?[{...e,command:{...e.command,unitIds}}]:[];}return 'unitId'in e.command&&e.command.unitId===helper.id?[]:[e];});
  if(input.snapshot.tick===startTick){const add=(command:any)=>entries.push({playerId:'p0',source:'external-agent',scriptId:'diagnosticGroundYield',command});add({type:'move',unitIds:[helper.id],x:6074.253480495869,y:2936.2615631397907,avoidCombat:true});add({type:'move',unitIds:[helper.id],x:6256,y:2480,avoidCombat:true,queued:true});}
  else if(helper.order.type==='idle'&&!helper.orderQueue?.length){helperActive=false;events.push({tick:input.snapshot.tick,helperHome:helper.id,x:helper.x,y:helper.y});writeFileSync(out+'/sequence.json',JSON.stringify(events,null,2));}
 }
 return entries;
};
const fds=Object.fromEntries(['commands','hits','entities','samples'].map(n=>[n,openSync(out+'/'+n+'.jsonl','wx')]));
const log=(name:string,data:any)=>writeSync(fds[name]!,JSON.stringify(data)+'\n');
const compact=(u:any)=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:u.deck,expiresTick:u.expiresTick,order:u.order});
let previous=new Map([...game.units,...game.buildings].map(u=>[u.id,compact(u)]));
const frame=()=>writeFileSync(out+'/frames/'+game.tick+'.json.gz',gzipSync(JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(p=>[p,memories.get(p)])),match}),{level:3}),{flag:'wx'});
frame();
writeFileSync(out+'/source.json',JSON.stringify({head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),source,frozenPolicyManifest,match,startTick,resume:resume??null,initialPlayers:game.players},null,2));
game.observer={hit(a,t,damage,hpBefore){log('hits',{tick:game.tick,attacker:compact(a),target:compact(t),damage,hpBefore});}};
const result=runAiGameLoop({...match,game,commandPlanner:planner},{onCommand({tick,owner,scriptId,command}){log('commands',{tick,owner,scriptId,command});},onStep(){
 const current=new Map([...game.units,...game.buildings].map(u=>[u.id,compact(u)]));
 for(const[id,u]of current)if(!previous.has(id))log('entities',{tick:game.tick,event:'birth',entity:u});
 for(const[id,u]of previous)if(!current.has(id))log('entities',{tick:game.tick,event:'removal',last:u});
 previous=current;
 if(game.tick%15===0||game.match.winner){frame();const row={tick:game.tick,winner:game.match.winner,stats:game.match.stats,players:game.players,ferries:memories.get('p0')?.naval?.ferries,resources:game.resources};log('samples',row);console.log(JSON.stringify({tick:game.tick,winner:game.match.winner,gold:game.players.p0!.gold,lost:game.match.stats.unitsLost.p0,ships:game.units.filter(u=>u.owner==='p0'&&u.sailing).length}));}
}});
if(game.tick%15!==0&&!game.match.winner)frame();
for(const fd of Object.values(fds))closeSync(fd);
const changed=paths.filter(p=>sha(readFileSync(p))!==source[p]);
writeFileSync(out+'/result.json',JSON.stringify({startTick,tick:game.tick,winner:game.match.winner,naturalComplete:!!game.match.winner,stats:game.match.stats,players:game.players,remaining:game.units.map(compact),buildings:game.buildings.map(compact),elapsedMs:result.elapsedMs,sourceChangedDuringRun:changed},null,2));
if(changed.length)process.exitCode=2;
