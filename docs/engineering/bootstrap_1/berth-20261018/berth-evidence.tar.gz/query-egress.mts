import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{groundSteeringRoute}from'/workspace/bootstrap-1-resume/src/shared/route-selection.ts';
import{constrainGroundShipStep}from'/workspace/bootstrap-1-resume/src/shared/ship-collisions.ts';
import{armedFoes,safeLandTravelTicks}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';
const c=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,c.snapshot,c.nextId);const s=snapshotGame(g),hall=s.buildings.find(b=>b.owner==='p0'&&b.kind==='townHall')!,foes=armedFoes(s,'p0',{teams:s.teams});const rows=[];
for(const id of ['unit-p0-raider-6391','unit-p0-knight-6970']){const unit=s.units.find(u=>u.id===id)!;const road=groundSteeringRoute(s.map,unit,hall),blocked=road.slice(1).flatMap((p,i)=>s.units.filter(h=>h.sailing).flatMap(ship=>{const q=constrainGroundShipStep(s.map,unit,road[i]!,p,[ship,unit]);return Math.hypot(q.x-p.x,q.y-p.y)>1e-6?[{i,shipId:ship.id,p,q}]:[]}));rows.push({id,unit,road,safeTicks:safeLandTravelTicks(s,unit,hall,foes),blocked});}
writeFileSync(process.argv[3]!,JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(r=>({id:r.id,road:r.road,safeTicks:r.safeTicks,blocked:r.blocked}))));
