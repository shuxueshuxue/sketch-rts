import {readFileSync,writeFileSync} from 'node:fs';
import {bootstrapGame,bootstrapMatches} from '../../src/ai/bootstrap_1/benchmark';
import {runAiGameLoop} from '../../src/ai/game-runner';
import {createAiMemoryProvider} from '../../src/ai/planner-context';
import {createBootstrapCommandPlanner} from '../../scripts/bootstrap_1-planner';
import {restoreSnapshotIntoGame,snapshotGame} from '../../src/shared/sim';
import {shipCollisionImpactCount} from '../../src/shared/ship-collisions';
import type {AiPolicyMemory} from '../../src/ai/policy';
const [fromArg,toArg,id]=process.argv.slice(2),from=Number(fromArg),to=Number(toArg);
const reportPath='.playtest/settlement-supply/full-match.json';
const report=JSON.parse(readFileSync(reportPath,'utf8')), row=report.rows.find((row:any)=>row.tick===from);
const saved=JSON.parse(readFileSync(`${reportPath}.frames/${from}.json`,'utf8'));
const match=bootstrapMatches('bootstrap_1-development',['sapphireArchipelago'],to).find(m=>m.subject==='v9_archer'&&m.agents.p0!.race==='grove'&&m.side===0&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!;
const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
for(const [owner,p]of Object.entries(row.players))memories.set!(owner,(p as {policy:AiPolicyMemory}).policy);
const planner=await createBootstrapCommandPlanner(memories),events:unknown[]=[];
let previous=game.units.find(u=>u.id===id)!,hp=previous.hp,shots=game.projectiles.map(p=>({...p}));
const result=runAiGameLoop({...match,game,commandPlanner:context=>{
 const commands=planner(context);
 for(const entry of commands){const c=entry.command;if('unitIds'in c&&c.unitIds.includes(id!))events.push({type:'command',tick:context.snapshot.tick,script:entry.scriptId,command:c});}
 return commands;
}},{onStep:({game})=>{
 const live=game.units.find(u=>u.id===id);
 if(hp>0&&(!live||live.hp<hp)){
  const ship=live??previous;
  events.push({type:'damage',tick:game.tick,hp:live?.hp??0,loss:hp-(live?.hp??0),x:ship.x,y:ship.y,order:ship.order,impacts:shipCollisionImpactCount(game.units),projectiles:shots.filter(p=>p.targetId===id),threats:game.units.filter(u=>u.owner!==ship.owner&&u.attackDamage>0&&Math.hypot(u.x-ship.x,u.y-ship.y)<800).map(u=>({id:u.id,kind:u.kind,owner:u.owner,x:u.x,y:u.y,hp:u.hp,order:u.order}))});
  if(!live)writeFileSync(`.playtest/coastal-withdrawal/death-${id}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
 }
 hp=live?.hp??0;if(live)previous=live;
 shots=game.projectiles.map(p=>({...p}));
}});
const expected=JSON.parse(readFileSync(`${reportPath}.frames/${to}.json`,'utf8'));
const final=snapshotGame(result.game);
const matchesCheckpoint=JSON.stringify(final)===JSON.stringify(expected.snapshot);
writeFileSync(`.playtest/coastal-withdrawal/combat-${id}.json`,JSON.stringify({from,to,id,matchesCheckpoint,events},null,2));
console.log(JSON.stringify({from,to,id,matchesCheckpoint,commands:events.filter((e:any)=>e.type==='command').length,damage:events.filter((e:any)=>e.type==='damage').map((e:any)=>({tick:e.tick,hp:e.hp,order:e.order,attackers:e.projectiles.map((p:any)=>p.attackerId)}))}));
