import {readFileSync,writeFileSync} from 'node:fs';
import {bootstrapGame,bootstrapMatches} from '../../src/ai/bootstrap_1/benchmark';
import {runAiGameLoop} from '../../src/ai/game-runner';
import {createAiMemoryProvider} from '../../src/ai/planner-context';
import {createBootstrapCommandPlanner} from '../../scripts/bootstrap_1-planner';
import {restoreSnapshotIntoGame,snapshotGame,issuePlayerCommand} from '../../src/shared/sim';
import {shipCollisionImpactCount} from '../../src/shared/ship-collisions';
import type {AiPolicyMemory} from '../../src/ai/policy';

const id='unit-p0-warship-1119',from=31200,to=33600;
const reportPath='.playtest/settlement-supply/full-match.json';
const report=JSON.parse(readFileSync(reportPath,'utf8')),row=report.rows.find((row:any)=>row.tick===from);
const saved=JSON.parse(readFileSync(`${reportPath}.frames/${from}.json`,'utf8'));
const results=[];
for(const mode of ['direct','back100','back220','north']){
 const match=bootstrapMatches('bootstrap_1-development',['sapphireArchipelago'],to).find(m=>m.subject==='v9_archer'&&m.agents.p0!.race==='grove'&&m.side===0&&Object.values(m.agents).slice(1).map(a=>a.version).join('+')==='v5')!;
 const game=bootstrapGame(match),memories=createAiMemoryProvider();restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
 for(const [owner,p]of Object.entries(row.players))memories.set!(owner,structuredClone((p as {policy:AiPolicyMemory}).policy));
 const planner=await createBootstrapCommandPlanner(memories);const commands:unknown[]=[];
 const issue=(command:any)=>{issuePlayerCommand(game,'p0',command);commands.push({tick:game.tick,command});};
 runAiGameLoop({...match,game,commandPlanner:context=>planner(context).flatMap(entry=>{
  if(context.snapshot.tick<31575||!('unitIds'in entry.command)||!entry.command.unitIds.includes(id))return[entry];
  const unitIds=entry.command.unitIds.filter(unit=>unit!==id);return unitIds.length?[{...entry,command:{...entry.command,unitIds}}]:[];
 })},{onStep:({game})=>{
  const ship=game.units.find(u=>u.id===id);if(!ship)return;
  if(game.tick===31575){
   const heading=ship.sailing!.heading;
   const goal=mode==='direct'?{x:3300,y:5300}:mode==='north'?{x:ship.x,y:5100}:{x:ship.x-Math.cos(heading)*160,y:ship.y-Math.sin(heading)*160};
   issue({type:'move',unitIds:[id],...goal,avoidCombat:true});
  }
  if(mode.startsWith('back')&&game.tick===31575+Number(mode.slice(4)))issue({type:'move',unitIds:[id],x:3300,y:5300,avoidCombat:true});
 }});
 const ship=game.units.find(u=>u.id===id);results.push({mode,commands,ship:ship?{x:ship.x,y:ship.y,hp:ship.hp,order:ship.order}:null});
 writeFileSync(`.playtest/coastal-withdrawal/manual-${mode}.json`,JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId}));
}
writeFileSync('.playtest/coastal-withdrawal/manual-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results));
