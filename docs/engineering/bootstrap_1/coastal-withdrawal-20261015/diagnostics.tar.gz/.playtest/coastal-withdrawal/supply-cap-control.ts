import {readFileSync,writeFileSync} from 'node:fs';
import {createGame,restoreSnapshotIntoGame,issuePlayerCommand,stepGame,snapshotGame} from '../../src/shared/sim';
import {bootstrapPolicyContext} from '../../src/ai/bootstrap_1/policy';
import {rankBootstrapGoals,planBootstrapEconomy} from '../../src/ai/bootstrap_1/economy';
import {colonyNavalWant} from '../../src/ai/policy/naval';
import {safeBuildPointAt} from '../../src/ai/policy/build-layout';
import {isBuildPlacementClear} from '../../src/shared/build-placement';
import {routeArrivals} from '../../src/shared/route-selection';
const report=JSON.parse(readFileSync('.playtest/settlement-supply/continued-match.json','utf8'));
const saved=JSON.parse(readFileSync('.playtest/settlement-supply/continued-match.json.frames/96000.json','utf8'));
const game=createGame('bareDuel');restoreSnapshotIntoGame(game,saved.snapshot,saved.nextId);
const memory=structuredClone(report.rows.at(-1).players.p0.policy);
const observe=()=>{const snapshot=snapshotGame(game),context=bootstrapPolicyContext(snapshot,'p0','v9_archer',{memory:structuredClone(memory),teams:game.teams});return{tick:game.tick,gold:game.players.p0!.gold,cap:game.players.p0!.supplyCap,farms:game.buildings.filter(b=>b.owner==='p0'&&b.kind==='farm').length,goals:rankBootstrapGoals(snapshot,'p0',context).map(g=>({id:g.id,cost:g.cost})),naval:colonyNavalWant(snapshot,'p0',context)?.id,commands:planBootstrapEconomy(snapshot,'p0',context)};};
const before=observe(),snapshot=snapshotGame(game),workers=game.units.filter(u=>u.owner==='p0'&&u.kind==='worker'&&!u.deck&&u.carryingGold===0&&u.order.type==='idle');
const choices=game.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall'&&b.complete).flatMap(base=>{const point=safeBuildPointAt(snapshot,'p0',base,before.farms+4,'farm');if(!isBuildPlacementClear(snapshot,'farm',point))return[];return routeArrivals(game.map,workers,point,'land').map(a=>({...a,point}));}).sort((a,b)=>a.ticks-b.ticks);
const choice=choices[0]!;const command={type:'build' as const,unitId:choice.unit.id,buildingKind:'farm' as const,...choice.point};// Control keeps the saved orders without issuing the proposed farm.
for(let i=0;i<1200;i++)stepGame(game);
const result={scope:'Control: no new command; no AI reassignment during 1200 ticks; observation uses cloned 96000 policy memory',before,command,after:observe()};
writeFileSync('.playtest/coastal-withdrawal/supply-cap-control.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
