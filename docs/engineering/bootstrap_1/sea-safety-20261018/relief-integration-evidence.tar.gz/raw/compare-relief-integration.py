import json,gzip
from pathlib import Path
root=Path('/workspace/bootstrap-1-sea-safety-20261018');rows=[]
for p in sorted((root/'relief-integrated-54600/frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
 q=root/'home-relief-general-v4-54600/frames'/p.name
 if not q.exists():continue
 a=json.loads(gzip.decompress(p.read_bytes()));b=json.loads(gzip.decompress(q.read_bytes()));rows.append({'tick':a['snapshot']['tick'],'snapshot':a['snapshot']==b['snapshot'],'nextId':a['nextId']==b['nextId'],'memories':a['memories']==b['memories']})
r={'note':'Integrated native planner versus v4 overlay from the same 54600 full state; no normalization.','samples':rows,'allEqual':all(all(v for k,v in x.items() if k!='tick') for x in rows)};(root/'relief-integration-equivalence.json').write_text(json.dumps(r,indent=2)+'\n');print(len(rows),rows[-1],r['allEqual']);print('differences',[x for x in rows if not all(v for k,v in x.items() if k!='tick')][:3])
