from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['shelter-integrated-e9-30000', 'observe.mts', 'shelter-integration-equivalence.json', 'shelter-integrated-final-typecheck.log', 'shelter-integrated-tests.log', 'archive-shelter-integration.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'shelter-integration-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'shelter-integration-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
