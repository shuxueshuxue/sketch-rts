import { GOLD_MINE_RULES } from '/workspace/bootstrap-1-resume/src/shared/mining.ts';
import { unitMover } from '/workspace/bootstrap-1-resume/src/shared/catalog.ts';
import { sameGround } from '/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import type { GameSnapshot, PlayerId, Unit } from '/workspace/bootstrap-1-resume/src/shared/types.ts';
import type { AiPolicyContext } from '/workspace/bootstrap-1-resume/src/ai/policy/types.ts';
import { isOpponentOwner } from '/workspace/bootstrap-1-resume/src/ai/policy/ownership.ts';
import { armedFoes, safeLandTravelTicks } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';

/** A coast evacuation must not abandon a safe, already paid mining foundation
 * elsewhere on the same landmass. Recheck every think; nearby danger wins. */
export function keepMiningConstruction(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext, worker: Unit, boat: Unit): boolean {
  if (options.memory.naval?.ferries?.[boat.id]?.purpose !== 'evacuate'
    || worker.deck || worker.kind !== 'worker' || (worker.order.type !== 'repair' && worker.order.type !== 'mine')) return false;
  const order=worker.order;
  const hall=order.type==='repair' ? snapshot.buildings.find(b=>b.id===order.buildingId&&b.owner===owner&&b.kind==='townHall'&&!b.complete&&b.hp>0)
    : snapshot.buildings.find(b=>b.owner===owner&&b.kind==='townHall'&&b.complete&&b.hp>0&&snapshot.resources.some(m=>m.id===order.resourceId&&m.amount>0&&Math.hypot(m.x-b.x,m.y-b.y)<GOLD_MINE_RULES.baseRange));
  if (!hall || !snapshot.resources.some(mine => mine.amount > 0 && Math.hypot(hall.x - mine.x, hall.y - mine.y) < GOLD_MINE_RULES.baseRange)) return false;
  const foes = armedFoes(snapshot, owner, options);
  // Match the evacuation's local danger radius; a distant threatened miner
  // does not make this builder's separate worksite an evacuation zone.
  if (foes.some(foe => 'order' in foe && unitMover(foe.kind) === 'land'
    && isOpponentOwner(snapshot, owner, foe.owner, options) && sameGround(snapshot.map, worker, foe)
    && Math.hypot(worker.x - foe.x, worker.y - foe.y) < 700)) return false;
  return safeLandTravelTicks(snapshot, worker, hall, foes) !== undefined && (order.type!=='mine' || safeLandTravelTicks(snapshot,worker,snapshot.resources.find(m=>m.id===order.resourceId)!,foes)!==undefined);
}
