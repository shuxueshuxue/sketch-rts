import { keepMiningConstruction } from '/workspace/bootstrap-1-construction-20261018/economic-work-draft.ts';
import { reviseAssaultBeaches, orderBootstrapAssaultLanding } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/assault-beach.ts';
import { planShoreTransfers } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/shore-transfer.ts';
import { unitMover } from '/workspace/bootstrap-1-resume/src/shared/catalog.ts';
import { rebaseReceiverSafe } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/rebase-receiver.ts';
import { sameGround } from '/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import type { GameCommand, GameSnapshot, PlayerId } from '/workspace/bootstrap-1-resume/src/shared/types.ts';
import { cancelFerry, planNavalTacticsWithAssignments } from '/workspace/bootstrap-1-resume/src/ai/policy/naval.ts';
import { units } from '/workspace/bootstrap-1-resume/src/ai/policy/snapshot.ts';
import { mountedMinePlan } from '/workspace/bootstrap-1-resume/src/ai/policy/mounted-mine-plan.ts';
import type { AiPolicyContext } from '/workspace/bootstrap-1-resume/src/ai/policy/types.ts';
import { medicalRecoveryReleasedUnitIds, planMedicalRecoveryTasks } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/medical-recovery.ts';
import { planSettlerBoarding } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/ferry-preparation.ts';
import { planRiderCrossing, riderFerryCrew } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/rider-crossing.ts';
import { transportNeedsRecovery, transportRecovery } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/transport-recovery.ts';
import { postRecoveryCommands } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/front-recovery.ts';
import { expeditionDeparture } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/expedition-departure.ts';
import { landRecoveryAssignments, mainlandCareAssignments, patientRendezvousCommands } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/land-recovery.ts';
import { continuingPatientRendezvous, rememberPatientRendezvous } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/medical-rendezvous.ts';
import { planLandedCombat } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/landed-combat.ts';
import { canPauseFerryForWorker, workerBoardingSafe } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/worker-boarding.ts';
import { settlerSeaRoutes } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/settler-sea-route.ts';
import { safeFerryReturn } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-ferry-return.ts';

function recoveryAssignments(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext) {
  const home = snapshot.buildings.find(building => building.owner === owner && building.kind === 'townHall');
  const landed = snapshot.units.filter(unit => unit.owner === owner && !unit.deck && unitMover(unit.kind) === 'land'
    && unit.kind !== 'worker' && unit.order.type !== 'board' && home && !sameGround(snapshot.map, unit, home));
  const care = landRecoveryAssignments(snapshot, owner, options, landed);
  const assigned = new Set([...care.recovering.map(({ patient }) => patient.id), ...care.posts.map(({ patient }) => patient.id)]);
  return { ...care, continuing: continuingPatientRendezvous(snapshot, owner, landed, options)
    .filter(({ patient }) => !assigned.has(patient.id)) };
}

export function expeditionRecoveryUnitIds(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext) {
  const { recovering, continuing, unmedicated, posts } = recoveryAssignments(snapshot, owner, options);
  return new Set([...recovering.flatMap(({ patient, healer }) => [patient.id, healer.id]), ...unmedicated.map(({ patient }) => patient.id),
    ...continuing.map(({ patient }) => patient.id), ...posts.map(({ patient }) => patient.id), ...transportRecovery(snapshot, owner, options).ids]);
}

/** An expedition's naval ownership also owns its land recovery orders. */
export function planBootstrapNaval(snapshot: GameSnapshot, owner: PlayerId, options: AiPolicyContext): GameCommand[] {
  reviseAssaultBeaches(snapshot, owner, options);
  const crossing = planRiderCrossing(snapshot, owner, options);
  const ferries = options.memory.naval?.ferries, cancelled: GameCommand[] = [];
  const released = new Set<string>();
  for (const worker of units(snapshot, owner)) {
    if (worker.kind !== 'worker' || worker.deck || worker.order.type !== 'board') continue;
    const transportId = worker.order.transportId;
    const boat = snapshot.units.find(unit => unit.id === transportId && unit.owner === owner);
    const mission = boat && ferries?.[boat.id];
    if (!boat || !mission || workerBoardingSafe(snapshot, owner, options, worker, boat)) continue;
    released.add(worker.id);
    mission.crewIds = mission.crewIds.filter(id => id !== worker.id);
    cancelled.push({ type: 'stop', unitIds: [worker.id] });
  }
  if (ferries) for (const boat of units(snapshot, owner)) {
    const mission = ferries[boat.id];
    if (mission?.purpose === 'rebase' && mission.phase !== 'return') {
      if (!rebaseReceiverSafe(snapshot, owner, options, boat, mission.targetId, mission.to)) {
        // The ordinary ferry return owns the hull; cancellation releases its pending boarders.
        cancelled.push(...cancelFerry(snapshot, boat, mission, options).filter(command => command.type === 'stop'));
      }
    }
  }
  const mines = mountedMinePlan(snapshot, options.memory);
  const ports = transportRecovery(snapshot, owner, options);
  const { recovering, continuing, unmedicated, foes, posts } = recoveryAssignments(snapshot, owner, options);
  const pendingPatients = continuing.map(({ patient }) => patient.id);
  const medics = new Set(recovering.map(({ healer }) => healer.id));
  const departing = expeditionDeparture(snapshot, owner, options, ports.ids,
    new Set([...recovering.map(({ patient }) => patient.id), ...unmedicated.map(({ patient }) => patient.id),
      ...pendingPatients, ...posts.map(({ patient }) => patient.id), ...medics]));
  const reserved = new Set([...recovering.map(({ patient }) => patient.id), ...unmedicated.map(({ patient }) => patient.id),
    ...pendingPatients, ...posts.map(({ patient }) => patient.id), ...medics, ...ports.ids, ...departing.ids]);
  const mounted = new Set(options.memory.mounted?.flatMap(job => job.unitIds));
  const mainland = mainlandCareAssignments(snapshot, owner, options);
  // Recruitment must use the same care query as mobileCare before a new
  // boarding request can replace that patient's or necessary healer's job.
  const mainlandCare = new Set([...(mainland?.unmedicated ?? []).map(({ patient }) => patient.id),
    ...(mainland?.recovering ?? []).flatMap(({ patient, healer }) => [patient.id, healer.id])]);
  const commands = [...crossing, ...cancelled, ...planShoreTransfers(snapshot,owner,options), ...planNavalTacticsWithAssignments(snapshot, owner, options, {
    settlementEscort: 'when-defended',
    orderAssaultLanding: (boat, goal, ordinary) => orderBootstrapAssaultLanding(snapshot, owner, options, boat, goal, ordinary),
    orderCrew: (soldiers, shore, boat) => riderFerryCrew(snapshot, soldiers, shore, boat, options),
    mineEligible: mines.eligible, targetAvailable: mines.targetAvailable,
    transportReady: boat => !transportNeedsRecovery(snapshot, boat),
    troopAvailable: unit => !mounted.has(unit.id) && !reserved.has(unit.id) && !mainlandCare.has(unit.id),
    workerAvailable: (unit, boat) => !keepMiningConstruction(snapshot, owner, options, unit, boat) && !released.has(unit.id) && canPauseFerryForWorker(snapshot, owner, options, boat)
      && workerBoardingSafe(snapshot, owner, options, unit, boat),
  })];
  commands.push(...planSettlerBoarding(snapshot, owner, options, commands));

  // The same naval owner runs local combat; a new boarding/care/departure
  // assignment takes precedence over micro, including one made this think.
  const medical = medics.size ? planMedicalRecoveryTasks(snapshot, owner, recovering.map(({ patient }) => patient), options) : undefined;
  const healing = medical ? medical.commands.filter(command =>
    'unitId' in command ? medics.has(command.unitId) : 'unitIds' in command && command.unitIds.some(id => medics.has(id))) : [];
  const workingMedics = medical?.occupied ?? new Set<string>();
  const releasedMedics = new Set([...medicalRecoveryReleasedUnitIds(snapshot, owner, options),
    ...[...medics].filter(id => !workingMedics.has(id))]);
  // Keep every care/ferry/departure reservation for recruitment. Only local
  // backline execution may take over a healer without an actual medical task.
  const retreat = patientRendezvousCommands(snapshot, recovering, foes, medics);
  // A medic can also be a predicted patient; medics have no rendezvous
  // command of their own. Preserve actual patient moves, not that empty job.
  const patients = new Set([...retreat.flatMap(command => 'unitIds' in command ? command.unitIds : []), ...pendingPatients, ...unmedicated.map(({ patient }) => patient.id),
    ...posts.map(({ patient }) => patient.id), ...ports.ids, ...departing.ids]);
  const local = planLandedCombat(snapshot, owner, options, new Set([...reserved].filter(id => !releasedMedics.has(id) || patients.has(id))
    .concat([...mounted, ...commands.flatMap(command => command.type === 'board' ? command.unitIds : [])])), releasedMedics);
  const tactical = new Set(local.flatMap(command => 'unitIds' in command ? command.unitIds : []));

  const published: GameCommand[] = [...commands.flatMap((command): GameCommand[] => {
    if ('unitId' in command) return reserved.has(command.unitId) ? [] : [command];
    if (!('unitIds' in command)) return [command];
    const unitIds = command.unitIds.filter(id => !reserved.has(id) && !tactical.has(id));
    return unitIds.length ? [{ ...command, unitIds }] : [];
  }), ...local, ...postRecoveryCommands(posts), ...retreat, ...unmedicated.map(({ patient, cover }): GameCommand =>
    ({ type: 'move', unitIds: [patient.id], ...cover, avoidCombat: true })), ...healing,
    ...ports.commands.flatMap((command): GameCommand[] => {
      if (!('unitIds' in command)) return [command];
      const unitIds = command.unitIds.filter(id => !departing.ids.has(id));
      return unitIds.length ? [{ ...command, unitIds }] : [];
    }), ...departing.commands];
  rememberPatientRendezvous(options, recovering, retreat, published, continuing);
  return settlerSeaRoutes(snapshot, owner, options, safeFerryReturn(snapshot, owner, options, published).commands);
}
