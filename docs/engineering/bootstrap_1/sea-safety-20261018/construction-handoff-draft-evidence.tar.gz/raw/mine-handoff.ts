import { GOLD_MINE_RULES } from '/workspace/bootstrap-1-resume/src/shared/mining.ts';
import { safeLandTravelTicks, armedFoes } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';
import { routeTravelTicks } from '/workspace/bootstrap-1-resume/src/shared/route-selection.ts';
import type { GameSnapshot,PlayerId,GameCommand } from '/workspace/bootstrap-1-resume/src/shared/types.ts';
import type { AiPolicyContext } from '/workspace/bootstrap-1-resume/src/ai/policy/types.ts';
export function miningHandoff(s:GameSnapshot,owner:PlayerId,o:AiPolicyContext):GameCommand|undefined {
 for(const worker of s.units.filter(u=>u.owner===owner&&u.kind==='worker'&&!u.deck&&u.order.type==='idle')){
  const claim=o.memory.unitClaims[worker.id];if(claim?.kind!=='build'||claim.expiresTick<s.tick)continue;
  const hall=s.buildings.find(b=>b.owner===owner&&b.kind==='townHall'&&b.complete&&b.x===claim.x&&b.y===claim.y);if(!hall)continue;
  const foes=armedFoes(s,owner,o),mines=s.resources.filter(m=>m.amount>0&&Math.hypot(m.x-hall.x,m.y-hall.y)<=GOLD_MINE_RULES.baseRange
   &&s.units.filter(u=>u.owner===owner&&u.order.type==='mine'&&u.order.resourceId===m.id).length<GOLD_MINE_RULES.workstations
   &&safeLandTravelTicks(s,worker,m,foes)!==undefined).sort((a,b)=>routeTravelTicks(s.map,worker,a,'land',worker.speed)!-routeTravelTicks(s.map,worker,b,'land',worker.speed)!);
  if(mines[0])return {type:'mine',unitIds:[worker.id],resourceId:mines[0].id};
 }
}
