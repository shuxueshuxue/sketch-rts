import json,gzip
from pathlib import Path
root=Path('/workspace/bootstrap-1-sea-safety-20261018');rows=[]
for p in sorted((root/'loading-integrated-ordinary0/frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
 q=root/'repair-v3-ordinary0/frames'/p.name
 if not q.exists():continue
 a=json.loads(gzip.decompress(p.read_bytes()));b=json.loads(gzip.decompress(q.read_bytes()))
 for m in a['memories'].values():
  if m and m.get('naval'):m['naval'].pop('loadingApproaches',None)
 rows.append({'tick':a['snapshot']['tick'],'snapshot':a['snapshot']==b['snapshot'],'nextId':a['nextId']==b['nextId'],'memoriesExceptApproachMarks':a['memories']==b['memories']})
r={'normalization':'Only remove added loadingApproaches AI memory; no snapshot changes','samples':rows};(root/'loading-fresh-prefix-equivalence.json').write_text(json.dumps(r,indent=2)+'\n');print(rows[-1]);print('first differences',[x for x in rows if not all(v for k,v in x.items() if k!='tick')][:3])
