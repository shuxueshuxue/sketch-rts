import json,gzip
from pathlib import Path
r=Path('/workspace/bootstrap-1-construction-20261018');rows=[]
for tick in [38400,42000,48000,50400,54000,60000,66000,90000,120000]:
 for name in ['construction-normal0','continuity-normal0']:
  p=r/name/'frames'/f'{tick}.json.gz'
  if not p.exists():continue
  s=json.loads(gzip.decompress(p.read_bytes()))['snapshot'];w=[u for u in s['units'] if u['owner']=='p0' and u['kind']=='worker'];h=[b for b in s['buildings'] if b['owner']=='p0' and b['kind']=='townHall']
  rows.append(dict(run=name,tick=tick,gold=s['players']['p0']['gold'],losses=s['match']['stats']['unitsLost']['p0'],workers=len(w),miners=sum(u['order']['type']=='mine' and not u.get('deck') for u in w),halls=len(h),completeHalls=sum(b['complete'] for b in h)))
(r/'normal-economy-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
