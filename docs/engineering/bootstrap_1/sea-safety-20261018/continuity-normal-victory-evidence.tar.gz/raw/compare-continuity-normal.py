import json,gzip
from pathlib import Path
p=Path('/workspace/bootstrap-1-construction-20261018');normal=p/'continuity-normal0';old=p/'construction-normal0';rows=[]
for f in sorted((normal/'frames').glob('*.gz'),key=lambda f:int(f.name.split('.')[0])):
 q=old/'frames'/f.name
 if not q.exists():continue
 a=json.loads(gzip.decompress(f.read_bytes()));b=json.loads(gzip.decompress(q.read_bytes()));rows.append({'tick':a['snapshot']['tick'],'snapshot':a['snapshot']==b['snapshot'],'nextId':a['nextId']==b['nextId'],'memories':a['memories']==b['memories']})
(p/'continuity-normal-prefix.json').write_text(json.dumps(rows,indent=2))
with(normal/'commands.jsonl').open()as a,(old/'commands.jsonl').open()as b:
 first=next(({'index':i,'new':json.loads(x),'old':json.loads(y)}for i,(x,y)in enumerate(zip(a,b))if json.loads(x)!=json.loads(y)),None)
(p/'continuity-normal-first-divergence.json').write_text(json.dumps(first,indent=2));print({'samples':len(rows),'firstDifferentFrame':next((r for r in rows if not all(r[k]for k in['snapshot','nextId','memories'])),None),'firstCommandDifference':first})
if(normal/'result.json').exists():
 r=json.loads((normal/'result.json').read_text());s=json.loads(gzip.decompress((normal/'frames'/f"{r['tick']}.json.gz").read_bytes()))['snapshot'];deaths=[e for l in(normal/'entities.jsonl').open()if(e:=json.loads(l))['event']=='removal'and e['last']['owner']=='p0'and e['last']['id'].startswith('unit-')and e['last'].get('expiresTick')is None];summary={k:r[k]for k in['startTick','tick','winner','naturalComplete','sourceChangedDuringRun']};summary.update(permanentDeaths=len(deaths),permanentAlive=sum(u['owner']=='p0'and u.get('expiresTick')is None for u in r['remaining']),gold=r['players']['p0']['gold'],spent=r['stats']['goldSpent']['p0'],workersAlive=sum(u['owner']=='p0'and u['kind']=='worker'for u in s['units']),miners=sum(u['owner']=='p0'and u['order']['type']=='mine'for u in s['units']),halls=[b for b in s['buildings']if b['owner']=='p0'and b['kind']=='townHall'],mines=s['resources']);(p/'continuity-normal-summary.json').write_text(json.dumps(summary,indent=2));print({k:v for k,v in summary.items()if k not in['halls','mines']})
