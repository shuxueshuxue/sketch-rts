import {readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import{bootstrapScripts}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
import{preserveMercenaryTravel}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mercenary-control.ts';
import{planBootstrapCasterScreen}from'./caster-guard-draft.ts';
const f=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-construction-20261018/caster-crash93600/crash-input.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);
const scripts=bootstrapScripts('v9_archer').map(s=>s.id==='v6Backline'?{...s,run:(s:any,p:any,o:any)=>preserveMercenaryTravel(s,p,o,planBootstrapCasterScreen(s,p,o))}:s);
try{const entries=planAiOwnerCommandEntries(snapshotGame(g),{playerId:'p0',version:'v9_archer',memory:f.memories.p0,scripts},{teams:g.teams});writeFileSync('/workspace/bootstrap-1-construction-20261018/caster-guard-query.json',JSON.stringify({unexpectedSuccess:true,entries},null,2));}catch(e){const m=(e as Error).message;writeFileSync('/workspace/bootstrap-1-construction-20261018/caster-guard-query.json',JSON.stringify(m.startsWith('NO_ESCAPE ')?JSON.parse(m.slice(10)):{error:String(e)},null,2));}
