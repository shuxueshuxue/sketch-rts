import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {assaultBeachBodies} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/assault-beach.ts';
import {shipPassengers} from '/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
import {effectiveCombatRating} from '/workspace/bootstrap-1-resume/src/ai/policy/v6/strength.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),ship=s.units.find(u=>u.id==='unit-p0-warship-1119')!,hall=s.buildings.find(b=>b.id==='building-p0-townHall-5659')!;
console.log(JSON.stringify({ship,crew:shipPassengers(s.units,ship).map(u=>({id:u.id,order:u.order,expires:u.expiresTick,strength:effectiveCombatRating(s,u)})),landing:assaultBeachBodies(s,ship,ship,hall,true),enemy:s.units.filter(u=>u.owner!=='p0'&&Math.hypot(u.x-hall.x,u.y-hall.y)<700).map(u=>({id:u.id,strength:effectiveCombatRating(s,u),order:u.order})),naval:f.memories.p0.naval},null,2));
