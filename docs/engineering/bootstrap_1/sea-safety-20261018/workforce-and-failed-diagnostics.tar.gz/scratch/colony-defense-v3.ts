import { GOLD_MINE_RULES } from '../src/shared/mining';
import { combatCapability } from '../src/shared/combat-capabilities';
import { combatHull } from '../src/shared/ship-defense';
import { shipPassengers } from '../src/shared/ship-geometry';
import { sameGround } from '../src/shared/terrain';
import type { GameCommand, GameSnapshot, PlayerId } from '../src/shared/types';
import { isEnemyOwner } from '../src/ai/policy/ownership';
import { effectiveCombatRating } from '../src/ai/policy/v6/strength';
import type { AiPolicyContext } from '../src/ai/policy/types';
import { passengerLandingSpot } from '../src/shared/naval';

const gap=(a:{x:number;y:number},b:{x:number;y:number})=>Math.hypot(a.x-b.x,a.y-b.y);
export function colonyDeckDefense(snapshot:GameSnapshot,owner:PlayerId,options:AiPolicyContext,commands:GameCommand[]):GameCommand[]{
 const state=options.memory as AiPolicyContext['memory'] & {colonyGuards?:Record<string,{hallId:string}>};
 const guards=state.colonyGuards??={},defense:GameCommand[]=[];
 const own=snapshot.units.filter(unit=>unit.owner===owner&&unit.hp>0);
 const halls=snapshot.buildings.filter(b=>b.owner===owner&&b.kind==='townHall'&&b.hp>0);
 const foes=snapshot.units.filter(u=>u.hp>0&&isEnemyOwner(snapshot,owner,u.owner,options)&&combatCapability(snapshot,u).armed&&!u.deck&&!u.sailing);
 for(const ship of own.filter(combatHull)){
  if(options.memory.naval?.ferries?.[ship.id]||options.memory.naval?.outfit?.shipId===ship.id)continue;
  const crew=shipPassengers(snapshot.units,ship).filter(u=>u.kind!=='worker');
  if(!crew.length||crew.some(u=>u.owner!==owner||u.cabin||u.gangway||u.expiresTick!==undefined||u.order.type==='board'))continue;
  const hall=halls.find(hall=>gap(hall,ship)<750&&foes.some(foe=>gap(foe,hall)<600&&sameGround(snapshot.map,foe,hall)
   &&'targetId'in foe.order&&[...own,...snapshot.buildings.filter(b=>b.owner===owner)].some(u=>u.id===foe.order.targetId&&gap(u,hall)<600)));
  if(!hall)continue;
  const shadow=snapshot.units.slice(),landings=[];
  for(const unit of crew){
   const point=passengerLandingSpot(snapshot.map,ship,unit.id,shadow);
   if(!point||!sameGround(snapshot.map,point,hall))continue;
   const landed={...unit,...point,deck:undefined};landings.push(landed);shadow[shadow.indexOf(unit)]=landed;
  }
  if(landings.length!==crew.length)continue;
  const threats=foes.filter(foe=>gap(foe,hall)<450&&sameGround(snapshot.map,foe,hall));
  const landed=own.filter(u=>!u.deck&&!u.sailing&&u.kind!=='worker'&&gap(u,hall)<700&&sameGround(snapshot.map,u,hall));
  const strength=[...landings,...landed].reduce((n,u)=>n+effectiveCombatRating(snapshot,u),0);
  const danger=threats.reduce((n,u)=>n+effectiveCombatRating(snapshot,u),0);
  if(strength<danger*1.4)continue;
  for(const passenger of crew){guards[passenger.id]={hallId:hall.id};defense.push({type:'unloadPassenger',transportId:ship.id,passengerId:passenger.id});}
 }
 const protectedIds=new Set<string>(),fallback:GameCommand[]=[];
 for(const [id,task] of Object.entries(guards)){
  const unit=own.find(u=>u.id===id),hall=halls.find(h=>h.id===task.hallId);
  if(!unit||!hall||!snapshot.resources.some(m=>m.amount>0&&gap(m,hall)<=GOLD_MINE_RULES.baseRange)){delete guards[id];continue;}
  if(unit.deck)continue;
  protectedIds.add(id);
  const allowed=(order:any)=>order.type==='hold'||order.type==='holdPosition'||order.type==='cast'
   ||order.type==='move'&&order.avoidCombat
   ||order.type==='attackMove'&&gap(order,hall)<600
   ||order.type==='attack'&&snapshot.units.some(foe=>foe.id===order.targetId&&gap(foe,hall)<600);
  const requested=commands.filter(c=>'unitIds'in c&&c.unitIds.includes(id));
  if(!requested.some(allowed)&&!allowed(unit.order))fallback.push(gap(unit,hall)>250
   ?{type:'move',unitIds:[id],x:hall.x,y:hall.y,avoidCombat:true}:{type:'holdPosition',unitIds:[id]});
 }
 const retained=commands.flatMap((c):GameCommand[]=>{
  if(!('unitIds'in c))return [c];
  const unitIds=c.unitIds.filter(id=>{
   if(!protectedIds.has(id))return true;
   const hall=halls.find(h=>h.id===guards[id]!.hallId)!;
   if(c.type==='move'&&c.avoidCombat||c.type==='holdPosition')return true;
   if(c.type==='attackMove')return gap(c,hall)<600;
   if(c.type==='attack')return snapshot.units.some(foe=>foe.id===c.targetId&&gap(foe,hall)<600);
   return false;
  });return unitIds.length?[{...c,unitIds}]:[];
 });
 return [...retained,...defense,...fallback];
}
