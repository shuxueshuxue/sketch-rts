import { createUnit } from '../src/shared/map';
import { landSpawnPoint } from '../src/shared/production-spawn';
import { sameGround, walkableGoal } from '../src/shared/terrain';
import { combatCapability } from '../src/shared/combat-capabilities';
import type { GameSnapshot, PlayerId } from '../src/shared/types';
import type { AiPolicyContext } from '../src/ai/policy/types';
import { isEnemyOwner } from '../src/ai/policy/ownership';
import { safeLandTravelTicks } from '../src/ai/bootstrap_1/safe-land-route';

/** Do not refill a mining post while its workers are being evacuated, or
 * recruit a civilian directly into observed weapon coverage. */
export function unsafeWorkerHalls(snapshot:GameSnapshot,owner:PlayerId,options:Pick<AiPolicyContext,'teams'> & {memory?:AiPolicyContext['memory']}){
 const result=new Set<string>();
 const evacuations=Object.values(options.memory?.naval?.ferries??{}).filter(m=>m.purpose==='evacuate'&&m.phase!=='return');
 const foes=[...snapshot.units,...snapshot.buildings].filter(u=>u.hp>0&&isEnemyOwner(snapshot,owner,u.owner,options)&&combatCapability(snapshot,u).armed);
 for(const hall of snapshot.buildings.filter(b=>b.owner===owner&&b.kind==='townHall')){
  if(evacuations.some(m=>Math.hypot(m.from.x-hall.x,m.from.y-hall.y)<800&&sameGround(snapshot.map,walkableGoal(snapshot.map,m.from.x,m.from.y,'land'),hall))){result.add(hall.id);continue;}
  const probe=createUnit('worker-spawn-safety-probe',owner,'worker',hall.x,hall.y),spawn=landSpawnPoint(snapshot,hall,probe);
  if(!spawn){result.add(hall.id);continue;}
  Object.assign(probe,spawn);
  if(safeLandTravelTicks(snapshot,probe,probe,foes)===undefined)result.add(hall.id);
 }
 return result;
}
