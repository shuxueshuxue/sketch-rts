import { combatCapability } from '../src/shared/combat-capabilities';
import { combatHull } from '../src/shared/ship-defense';
import { shipPassengers } from '../src/shared/ship-geometry';
import { sameGround } from '../src/shared/terrain';
import type { GameCommand, GameSnapshot, PlayerId } from '../src/shared/types';
import { isEnemyOwner } from '../src/ai/policy/ownership';
import { effectiveCombatRating } from '../src/ai/policy/v6/strength';
import type { AiPolicyContext } from '../src/ai/policy/types';
import { assaultBeachBodies } from '../src/ai/bootstrap_1/assault-beach';

const gap=(a:{x:number;y:number},b:{x:number;y:number})=>Math.hypot(a.x-b.x,a.y-b.y);
export function colonyDeckDefense(snapshot:GameSnapshot,owner:PlayerId,options:AiPolicyContext,commands:GameCommand[]):GameCommand[]{
 const held=new Set<string>(),defense:GameCommand[]=[];
 const own=snapshot.units.filter(unit=>unit.owner===owner&&unit.hp>0);
 const halls=snapshot.buildings.filter(b=>b.owner===owner&&b.kind==='townHall'&&b.hp>0);
 const foes=snapshot.units.filter(u=>u.hp>0&&isEnemyOwner(snapshot,owner,u.owner,options)&&combatCapability(snapshot,u).armed&&!u.deck&&!u.sailing);
 for(const ship of own.filter(combatHull)){
  if(options.memory.naval?.ferries?.[ship.id]||options.memory.naval?.outfit?.shipId===ship.id)continue;
  const crew=shipPassengers(snapshot.units,ship);
  if(!crew.length||crew.some(u=>u.owner!==owner||u.kind==='worker'||u.cabin||u.gangway||u.expiresTick!==undefined||u.order.type==='board'))continue;
  const hall=halls.find(hall=>gap(hall,ship)<750&&foes.some(foe=>gap(foe,hall)<600&&sameGround(snapshot.map,foe,hall)
   &&'targetId'in foe.order&&[...own,...snapshot.buildings.filter(b=>b.owner===owner)].some(u=>u.id===foe.order.targetId&&gap(u,hall)<600)));
  if(!hall)continue;
  const landing=assaultBeachBodies(snapshot,ship,ship,hall,true);
  if(!landing||landing.landed.length!==crew.length)continue;
  const threats=foes.filter(foe=>gap(foe,hall)<700&&sameGround(snapshot.map,foe,hall));
  const landed=own.filter(u=>!u.deck&&!u.sailing&&u.kind!=='worker'&&gap(u,hall)<700&&sameGround(snapshot.map,u,hall));
  const strength=[...landing.landed,...landed].reduce((n,u)=>n+effectiveCombatRating(snapshot,u),0);
  const danger=threats.reduce((n,u)=>n+effectiveCombatRating(snapshot,u),0);
  if(strength<danger*1.4)continue;
  held.add(ship.id);
  if(ship.order.type!=='unload'||gap(ship.order,ship)>80)defense.push({type:'unload',unitIds:[ship.id],x:ship.x,y:ship.y});
 }
 return [...commands.flatMap((c):GameCommand[]=>{
  if(!('unitIds'in c))return [c];const unitIds=c.unitIds.filter(id=>!held.has(id));return unitIds.length?[{...c,unitIds}]:[];
 }),...defense];
}
