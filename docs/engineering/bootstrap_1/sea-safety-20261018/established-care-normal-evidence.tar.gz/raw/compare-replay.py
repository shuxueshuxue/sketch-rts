import json,gzip
from pathlib import Path
p=Path('/workspace/bootstrap-1-income-20261018');a=p/'care-normal0/frames';b=p/'care-replay39600/frames';rows=[]
for f in sorted(b.glob('*.gz'),key=lambda f:int(f.name.split('.')[0])):
 if not (a/f.name).exists():continue
 x=json.loads(gzip.decompress(f.read_bytes()));y=json.loads(gzip.decompress((a/f.name).read_bytes()));rows.append({'tick':x['snapshot']['tick'],'snapshot':x['snapshot']==y['snapshot'],'nextId':x['nextId']==y['nextId'],'memories':x['memories']==y['memories']})
(p/'normal-replay-equivalence.json').write_text(json.dumps(rows,indent=2));print({'samples':len(rows),'last':rows[-1],'allEqual':all(all(r[k] for k in ['snapshot','nextId','memories']) for r in rows)})
