import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.scratch-bootstrap-20261018/idle-worker-evasion.test.ts'],fileParallelism:false}});
