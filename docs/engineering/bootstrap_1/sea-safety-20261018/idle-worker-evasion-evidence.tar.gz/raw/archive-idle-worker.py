from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['idle-worker-evasion-54600','idle-worker-evasion-60000','loading-control-60000','idle-worker-evasion-observe.mts','observe.mts','idle-worker-evasion-source.json','idle-worker-evasion-contracts.log','idle-worker-evasion-typecheck.log','idle-worker-evasion-typecheck-initial-failure.log','idle-worker-evasion-60000-native.png','archive-idle-worker.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f
for n in ['idle-worker-evasion-probe.ts','idle-worker-evasion.test.ts','vitest-idle-worker.config.ts','tsconfig-idle-worker.json']:
 files['draft/'+n]=repo/'.scratch-bootstrap-20261018'/n
manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'idle-worker-evasion-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'idle-worker-evasion-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
