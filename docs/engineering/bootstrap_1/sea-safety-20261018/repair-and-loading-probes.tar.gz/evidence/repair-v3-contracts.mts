import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import * as q from './repair-v3-draft-planner.mjs';
import {createGame,restoreSnapshotIntoGame,snapshotGame,stepGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {issueCommandFrame} from '/workspace/bootstrap-1-resume/src/sdk/commands/frame.ts';
import {transportNeedsRecovery} from '/workspace/bootstrap-1-resume/.scratch-bootstrap-20261018/transport-recovery-probe-v3.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),boatIds=['unit-p0-transport-5237','unit-p0-carrier-6518'];
for(const version of ['v9_archer','v9_summoner','v9_knight']){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);const s=snapshotGame(game),memory=structuredClone(f.memories.p0);q.setBuildingBodies(s.map,s.buildings);
 const commands=q.planAiOwnerCommandEntries(s,{playerId:'p0',version,source:'external-agent',memory},{teams:game.teams});
 for(const id of boatIds)assert(commands.some((e:any)=>e.command.type==='board'&&e.command.transportId===id));
 const beforeGold=game.players.p0!.gold,beforeHp=boatIds.map(id=>game.units.find(u=>u.id===id)!.hp);
 issueCommandFrame(game,commands);for(let i=0;i<15;i++)stepGame(game);
 assert.equal(game.players.p0!.gold,beforeGold);assert.deepEqual(boatIds.map(id=>game.units.find(u=>u.id===id)!.hp),beforeHp);
 assert(game.units.some(u=>u.owner==='p0'&&u.order.type==='board'&&u.order.transportId===boatIds[0]));
 console.log(JSON.stringify({version,nativeTicks:15,goldUnchanged:true,shipHpUnchanged:true,boardedBoth:true}));
}
for(const scenario of ['funded','workingMine','inTransit','rudder','rigging','hull']){
 const s=structuredClone(f.snapshot);if(scenario==='funded')s.players.p0.gold=1;if(scenario==='workingMine')s.resources.find((x:any)=>x.id==='gold-seat0-main').amount=500;if(scenario==='inTransit')s.units.find((u:any)=>u.owner==='p0'&&u.kind==='worker').carryingGold=10;
 for(const id of boatIds){const boat=s.units.find((u:any)=>u.id===id);if(scenario==='rudder')boat.shipParts.rudder=0;if(scenario==='rigging')boat.shipParts.rigging=0;if(scenario==='hull')boat.hp=boat.maxHp*.2;assert(transportNeedsRecovery(s,boat));}
 console.log(JSON.stringify({scenario,recoveryRequiredForBoth:true}));
}
