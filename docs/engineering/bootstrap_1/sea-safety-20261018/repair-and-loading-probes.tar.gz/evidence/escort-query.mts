import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {combatHull} from '/workspace/bootstrap-1-resume/src/shared/ship-defense.ts';
import {isTransportKind} from '/workspace/bootstrap-1-resume/src/shared/transport-role.ts';
import {shipPassengers} from '/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
import {combatCapability} from '/workspace/bootstrap-1-resume/src/shared/combat-capabilities.ts';
import {sameGround,setBuildingBodies} from '/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import {navalServices} from '/workspace/bootstrap-1-resume/src/ai/policy/naval-services.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),s=f.snapshot,m=f.memories.p0;setBuildingBodies(s.map,s.buildings);const own=s.units.filter((u:any)=>u.owner==='p0'),reserved=navalServices(s,'p0',{memory:structuredClone(m),teams:f.match.teams}).reserved;
const convoy=own.filter((u:any)=>isTransportKind(u.kind)&&shipPassengers(s.units,u).length&&m.naval.ferries?.[u.id]?.purpose!=='creep');
const fighters=own.filter((u:any)=>combatHull(u)&&combatCapability(s,u).armed&&!reserved.has(u.id)&&u.id!==m.naval.outfit?.shipId&&!m.naval.ferries?.[u.id]&&u.kind!=='bombardShip');
const gap=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
function choose(boats:any[]){const escorts=new Map<string,any>();for(const ship of fighters){const count=(b:any)=>[...escorts.values()].filter(x=>x.id===b.id).length;const boat=boats.filter(b=>sameGround(s.map,ship,b,'sea')&&gap(ship,b)<1800&&count(b)<2).sort((a,b)=>count(a)-count(b)||gap(ship,a)-gap(ship,b))[0];if(boat)escorts.set(ship.id,boat);}return [...escorts].map(([ship,b])=>({ship,target:b.id,purpose:m.naval.ferries?.[b.id]?.purpose??null}));}
console.log(JSON.stringify({tick:s.tick,convoy:convoy.map((u:any)=>u.id),ordinary:choose(convoy),probe:choose(convoy.filter((u:any)=>m.naval.ferries?.[u.id]&&m.naval.ferries[u.id].phase!=='return'))},null,2));
