import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import * as first from './repair-draft-planner.mjs';import * as next from './repair-v2-draft-planner.mjs';
import {transportNeedsRecovery} from '/workspace/bootstrap-1-resume/.scratch-bootstrap-20261018/transport-recovery-probe-v2.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());
function planned(bundle:any){const s=structuredClone(f.snapshot),memory=structuredClone(f.memories.p0);bundle.setBuildingBodies(s.map,s.buildings);return {entries:bundle.planAiOwnerCommandEntries(s,{playerId:'p0',version:'v9_archer',source:'external-agent',memory},{teams:f.match.teams}),memory};}
const outcomes:any={sameInitialPlanner:JSON.stringify(planned(first))===JSON.stringify(planned(next)),recovery:{}};
for(const scenario of ['actual','funded','workingMine','goldInTransit','damagedRudder','damagedRigging','badHull']){
 const s=structuredClone(f.snapshot),boat=s.units.find((u:any)=>u.id==='unit-p0-transport-5237');
 if(scenario==='funded')s.players.p0.gold=5;
 if(scenario==='workingMine')s.resources.find((x:any)=>x.id==='gold-seat0-main').amount=500;
 if(scenario==='goldInTransit')s.units.find((u:any)=>u.owner==='p0'&&u.kind==='worker').carryingGold=5;
 if(scenario==='damagedRudder')boat.shipParts.rudder-=1;
 if(scenario==='damagedRigging')boat.shipParts.rigging-=1;
 if(scenario==='badHull')boat.hp=boat.maxHp*.3;
 outcomes.recovery[scenario]=transportNeedsRecovery(s,boat);
}
console.log(JSON.stringify(outcomes,null,2));
if(!outcomes.sameInitialPlanner||outcomes.recovery.actual||Object.entries(outcomes.recovery).some(([k,v])=>k!=='actual'&&!v))process.exitCode=1;
