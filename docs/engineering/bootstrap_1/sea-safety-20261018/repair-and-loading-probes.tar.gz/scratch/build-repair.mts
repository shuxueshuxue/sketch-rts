import {build} from 'esbuild';
import {resolve} from 'node:path';
const root='/workspace/bootstrap-1-resume',variant=process.argv[2]!;
await build({stdin:{contents:"export {planAiOwnerCommandEntries} from './src/ai/planner-context';export {setBuildingBodies} from './src/shared/terrain';",resolveDir:root,loader:'ts'},
 bundle:true,platform:'node',format:'esm',outfile:`/workspace/bootstrap-1-sea-safety-20261018/repair-${variant}-planner.mjs`,
 plugins:variant==='draft'?[{name:'repair-draft',setup(b){b.onResolve({filter:/(^|\/)transport-recovery$/},args=>{
  if(resolve(args.resolveDir,args.path)+'.ts'===root+'/src/ai/bootstrap_1/transport-recovery.ts')return {path:root+'/.scratch-bootstrap-20261018/transport-recovery-probe.ts'};
  return undefined;
 });}}]:[]});
