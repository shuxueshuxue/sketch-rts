import {defineConfig} from 'vitest/config';
export default defineConfig({resolve:{alias:[{find:/^.*\/transport-recovery(?:\.ts)?$/,replacement:'/workspace/bootstrap-1-resume/.scratch-bootstrap-20261018/transport-recovery-probe-v3.ts'}]},test:{maxWorkers:1,fileParallelism:false}});
