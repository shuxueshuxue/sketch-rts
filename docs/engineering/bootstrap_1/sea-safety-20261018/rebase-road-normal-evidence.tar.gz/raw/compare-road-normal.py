import gzip,json,itertools
from pathlib import Path
root=Path('/workspace/bootstrap-1-rebase-20261018');old=Path('/workspace/bootstrap-1-sea-safety-20261018/safe-return-scoped-unseen-fresh0');new=root/'road-normal0';rows=[]
for f in sorted((new/'frames').glob('*.gz'),key=lambda f:int(f.name.split('.')[0])):
 if not (old/'frames'/f.name).exists():continue
 a=json.loads(gzip.decompress(f.read_bytes()));b=json.loads(gzip.decompress((old/'frames'/f.name).read_bytes()));rows.append({'tick':a['snapshot']['tick'],'snapshot':a['snapshot']==b['snapshot'],'nextId':a['nextId']==b['nextId'],'memories':a['memories']==b['memories']})
(root/'road-normal-prefix-equivalence.json').write_text(json.dumps(rows,indent=2))
with (new/'commands.jsonl').open() as a,(old/'commands.jsonl').open() as b:
 divergence=next(({'index':i,'new':json.loads(x),'old':json.loads(y)} for i,(x,y) in enumerate(zip(a,b)) if json.loads(x)!=json.loads(y)),None)
(root/'road-normal-first-command-divergence.json').write_text(json.dumps(divergence,indent=2))
print({'samples':len(rows),'last':rows[-1],'firstDifferent':next((x for x in rows if not all(x[k] for k in ['snapshot','nextId','memories'])),None),'commandDivergence':divergence})
if (new/'result.json').exists():
 r=json.loads((new/'result.json').read_text());o=json.loads(gzip.decompress((old/'frames'/f"{r['tick']}.json.gz").read_bytes()))['snapshot'];ids=['unit-p0-worker-2','unit-p0-worker-1045','unit-p0-worker-2754','unit-p0-worker-2783','unit-p0-worker-2822','unit-p0-carrier-3009'];deaths=[e for l in (new/'entities.jsonl').open() if (e:=json.loads(l))['event']=='removal' and e['last']['owner']=='p0' and e['last']['id'].startswith('unit-') and e['last'].get('expiresTick') is None];s={k:r[k] for k in ['startTick','tick','winner','naturalComplete','sourceChangedDuringRun']};s.update(permanentDeaths=len(deaths),permanentAlive=sum(u['owner']=='p0' and u.get('expiresTick') is None for u in r['remaining']),gold=r['players']['p0']['gold'],targets=[u for u in r['remaining'] if u['id'] in ids],oldSameTickTargets=[{k:u.get(k) for k in ['id','hp','deck','order']} for u in o['units'] if u['id'] in ids],oldSameTickLosses=o['match']['stats']['unitsLost']['p0']);(root/'road-normal-summary.json').write_text(json.dumps(s,indent=2));print(s)
