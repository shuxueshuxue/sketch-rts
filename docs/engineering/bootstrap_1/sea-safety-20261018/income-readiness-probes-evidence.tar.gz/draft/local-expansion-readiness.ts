import {miningHallSite} from '../src/shared/mining-site';
import {sameGround} from '../src/shared/terrain';
import {armedFoes,safeLandTravelTicks} from '../src/ai/bootstrap_1/safe-land-route';
import type {GameSnapshot,PlayerId,ResourceNode} from '../src/shared/types';
import type {AiPolicyContext} from '../src/ai/policy/types';
/** A building on the island is not a builder that can reach its next mine. */
export function localExpansionReadiness(snapshot:GameSnapshot,owner:PlayerId,options:AiPolicyContext){
 const workers=snapshot.units.filter(u=>u.owner===owner&&u.kind==='worker'&&!u.deck&&(u.order.type==='idle'||u.order.type==='mine')&&options.memory.unitClaims[u.id]?.kind!=='build'&&options.memory.unitClaims[u.id]?.kind!=='retreat');
 const foes=armedFoes(snapshot,owner,options),cache=new Map<string,boolean>();
 return (mine:ResourceNode)=>{
  if(cache.has(mine.id))return cache.get(mine.id)!;
  const local=workers.filter(u=>sameGround(snapshot.map,u,mine));
  const site=local.length?miningHallSite(snapshot,mine):undefined;
  const ready=!!site&&local.some(u=>safeLandTravelTicks(snapshot,u,site,foes)!==undefined);cache.set(mine.id,ready);return ready;
 };
}
