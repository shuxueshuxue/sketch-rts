from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['income-reserve-v3-27600', 'income-reserve-v4-29400', 'income-reserve-v3-draft-planner.mjs', 'income-reserve-v4-draft-planner.mjs', 'income-reserve-v3-observe.mts', 'income-reserve-v4-observe.mts', 'income-v4-return-32400-native.png', 'local-expansion-readiness-tests.log', 'archive-income-readiness.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

for name in ['build-income-reserve-v3.mts','build-income-reserve-v4.mts','local-expansion-readiness.ts','local-expansion-readiness.test.ts']:
 files['draft/'+name]=repo/'.scratch-bootstrap-20261018'/name

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'income-readiness-probes-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'income-readiness-probes-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
