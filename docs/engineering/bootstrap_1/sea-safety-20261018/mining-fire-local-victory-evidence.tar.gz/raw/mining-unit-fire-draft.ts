import { miningJobSafety } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mining-job-defense.ts';
import { miningJobOrder } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mining-jobs.ts';
import { armedFoes } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';
import { mountedEscape,mountedThreatReach,THINK_TICKS } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mounted-micro.ts';
import { SIM_TICKS_PER_SECOND } from '/workspace/bootstrap-1-resume/src/shared/time.ts';
import type {GameSnapshot,PlayerId,GameCommand} from '/workspace/bootstrap-1-resume/src/shared/types.ts';
import type {AiPolicyContext,AiScript} from '/workspace/bootstrap-1-resume/src/ai/policy/types.ts';
function tasks(s:GameSnapshot,owner:PlayerId,o:AiPolicyContext){
 const foes=armedFoes(s,owner,o);
 return s.units.filter(u=>u.owner===owner&&u.kind==='worker'&&!u.deck&&u.hp>0).flatMap(worker=>{
  const job=miningJobOrder(worker);if(!job)return[];
  const nearby=foes.filter(f=>Math.hypot(f.x-worker.x,f.y-worker.y)<Math.max(600,mountedThreatReach(s,f,worker,THINK_TICKS)+100));
  if(!nearby.some(f=>Math.hypot(f.x-worker.x,f.y-worker.y)<=mountedThreatReach(s,f,worker,THINK_TICKS)+('speed'in f?f.speed:0)*THINK_TICKS/SIM_TICKS_PER_SECOND))return[];
  const escape=mountedEscape(s,worker,nearby,0,undefined,true);
  if(escape.type!=='move'||Math.hypot(escape.x-worker.x,escape.y-worker.y)<1)return[];
  return[{worker,job,escape}];
 });
}
export const miningFire:AiScript={...miningJobSafety,
 claimsUnits:(s,p,o)=>new Set([...miningJobSafety.claimsUnits!(s,p,o),...tasks(s,p,o).map(t=>t.worker.id)]),
 run(s,p,o){const wanted=tasks(s,p,o),claimed=new Set(wanted.map(t=>t.worker.id));const old=miningJobSafety.run(s,p,o) as GameCommand[];return [...old.filter(c=>!('unitIds'in c)||c.unitIds.every(id=>!claimed.has(id))),...wanted.flatMap(({worker,job,escape})=>[escape,{type:'mine' as const,unitIds:[worker.id],resourceId:job.resourceId,queued:true}])];}
};
