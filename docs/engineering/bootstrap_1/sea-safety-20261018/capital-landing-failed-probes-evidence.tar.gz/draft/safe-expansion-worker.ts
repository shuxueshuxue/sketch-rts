import {sameGround} from '../src/shared/terrain';
import {routeArrivals} from '../src/shared/route-selection';
import {armedFoes,safeLandTravelTicks} from '../src/ai/bootstrap_1/safe-land-route';
import type {GameSnapshot,PlayerId,Unit} from '../src/shared/types';
import type {AiPolicyContext} from '../src/ai/policy/types';
export function safeExpansionWorker(s:GameSnapshot,owner:PlayerId,options:AiPolicyContext){
 const workers=s.units.filter(u=>u.owner===owner&&u.kind==='worker'&&!u.deck&&(u.order.type==='idle'||u.order.type==='mine')&&options.memory.unitClaims[u.id]?.kind!=='build'&&options.memory.unitClaims[u.id]?.kind!=='retreat');
 const foes=armedFoes(s,owner,options),cache=new Map<string,Unit|undefined>();
 return (site:{x:number;y:number})=>{const key=site.x+':'+site.y;if(cache.has(key))return cache.get(key);
 const worker=routeArrivals(s.map,workers.filter(u=>sameGround(s.map,u,site)),site,'land').find(({unit})=>safeLandTravelTicks(s,unit,site,foes)!==undefined)?.unit;
 cache.set(key,worker);return worker;
 };
}
