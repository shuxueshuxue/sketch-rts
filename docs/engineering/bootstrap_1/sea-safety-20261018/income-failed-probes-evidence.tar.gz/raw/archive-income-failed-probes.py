from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['income-reserve-25800', 'income-reserve-v2-27600', 'income-reserve-base-25800', 'income-reserve-native-25800', 'income-reserve-observe.mts', 'income-reserve-v2-observe.mts', 'income-reserve-base-observe.mts', 'observe.mts', 'income-reserve-draft-planner.mjs', 'income-reserve-v2-draft-planner.mjs', 'income-reserve-base-planner.mjs', 'income-reserve-bundle-control.json', 'income-before-priest-27600', 'income-reserve-27960-query.json', 'income-reserve-27960-explanation.json', 'income-reserve-v2-query-planner.mjs', 'income-reserve-v2-explanation-planner.mjs', 'query-income-reserve.mts', 'query-income-explanation.mts', 'measure-collapse-reserve.mts', 'relief-collapse-reserve.json', 'income-ineffective-equivalence.json', 'income-reserve-25800.log', 'archive-income-failed-probes.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

for name in ['build-income-reserve-initial.mts','build-income-reserve.mts','build-income-reserve-v2.mts','build-income-reserve-query.mts','build-income-reserve-explanation.mts']:
 files['draft/'+name]=repo/'.scratch-bootstrap-20261018'/name

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'income-failed-probes-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'income-failed-probes-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
