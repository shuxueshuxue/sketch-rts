import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {navalBudgetReserve} from '/workspace/bootstrap-1-resume/src/ai/policy/naval.ts';
import {unsafeWorkerHalls} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/workforce-safety.ts';
import {bootstrapPolicyContext} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
const rows=[];
for(let tick=24000;tick<=30600;tick+=600){const f=JSON.parse(gunzipSync(readFileSync(`/workspace/bootstrap-1-sea-safety-20261018/relief-integrated-ordinary0/frames/${tick}.json.gz`)).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),o=bootstrapPolicyContext(s,'p0','v9_archer',{memory:f.memories.p0,teams:f.snapshot.teams}),unsafe=[...unsafeWorkerHalls(s,'p0',o)],reserve=navalBudgetReserve(s,'p0',o),halls=s.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall');const row={tick,gold:s.players.p0!.gold,reserve,unsafe,halls:halls.map(h=>({id:h.id,hp:h.hp,nearbyGold:s.resources.filter(m=>Math.hypot(m.x-h.x,m.y-h.y)<400).reduce((n,m)=>n+m.amount,0)}))};rows.push(row);console.log(JSON.stringify(row));}
writeFileSync('/workspace/bootstrap-1-sea-safety-20261018/relief-collapse-reserve.json',JSON.stringify(rows,null,2));
