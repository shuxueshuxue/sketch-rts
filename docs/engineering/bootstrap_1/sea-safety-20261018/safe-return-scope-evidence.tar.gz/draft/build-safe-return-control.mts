import {build} from 'esbuild';import {execFileSync} from 'node:child_process';import {resolve} from 'node:path';import {writeFileSync} from 'node:fs';
const root='/workspace/bootstrap-1-resume';
const before=execFileSync('git',['show','6fbcdc5e:src/ai/bootstrap_1/expedition-recovery.ts'],{cwd:root,encoding:'utf8'});
writeFileSync('/workspace/bootstrap-1-sea-safety-20261018/safe-return-control-expedition-recovery.ts',before);
await build({stdin:{contents:"export {planAiOwnerCommandEntries} from './src/ai/planner-context';export {setBuildingBodies} from './src/shared/terrain';",resolveDir:root,loader:'ts'},bundle:true,platform:'node',format:'esm',outfile:'/workspace/bootstrap-1-sea-safety-20261018/safe-return-control-planner.mjs',plugins:[{name:'exact-before-return',setup(b){b.onLoad({filter:/\/src\/ai\/bootstrap_1\/expedition-recovery\.ts$/},args=>({contents:before,loader:'ts',resolveDir:resolve(args.path,'..')}));}}]});
