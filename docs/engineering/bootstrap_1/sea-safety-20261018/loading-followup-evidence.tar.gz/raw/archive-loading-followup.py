from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['repair-v3-ordinary0','loading-general-49200','loading-general-v2-49200','loading-general-v2-52800','loading-v1-control-equivalence.json','repair-v3-fresh-prefix-equivalence.json','loading-general-v2-observe.mts','loading-general-observe.mts','repair-v3-draft-planner.mjs','loading-general-v2-typecheck.log','loading-general-typecheck.log','loading-route-proof.mts','loading-route-proof-51060.json','loading-route-proof-52800.json','loading-general-v2-52800-native.png','boarding-progress-query.mts','boarding-progress-fresh.jsonl','archive-loading-followup.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f
for n in ['loading-approach-probe.ts','loading-approach-probe-v2.ts','transport-recovery-probe-v3.ts','build-repair-v3.mts']:
 files['draft/'+n]=repo/'.scratch-bootstrap-20261018'/n
manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'loading-followup-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'loading-followup-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
