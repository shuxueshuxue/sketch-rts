import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.scratch-bootstrap-20261018/home-relief.test.ts'],fileParallelism:false}});
