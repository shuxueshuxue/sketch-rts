import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';import {expect,it} from 'vitest';
import {homeRelief} from './home-relief-probe-v2';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '../src/shared/sim';
function saved(tick=54600,rename=false){let raw=gunzipSync(readFileSync(`/workspace/bootstrap-1-sea-safety-20261018/${tick===54600?'loading-integrated-40800':'home-relief-general-54600'}/frames/${tick}.json.gz`)).toString();if(rename)raw=raw.replaceAll('unit-p0-warship-4662','another-hull').replaceAll('building-p0-townhall','another-home');const f=JSON.parse(raw),game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);return {s:snapshotGame(game),options:{memory:f.memories.p0,teams:f.snapshot.teams}};}
it('selects real adequate embarked defenders and a clear landing, independent of historical IDs',()=>{
 const {s,options}=saved(54600,true),r=homeRelief(s,'p0',options);expect(r.selection).toBeTruthy();expect(options.memory.homeRelief.shipId).toBe('another-hull');expect(options.memory.homeRelief.hallId).toBe('another-home');expect(r.commands.some(c=>c.type==='unload'&&c.unitIds.includes('another-hull'))).toBe(true);expect(r.claimed.size).toBe(3);
});
it.each(['local-defenders','overwhelming-raid','reserved-ships','covered-coasts'] as const)('does not launch an unjustified or unsafe relief: %s',reason=>{
 const {s,options}=saved();
 if(reason==='local-defenders'){for(const id of ['unit-p0-archer-1627','unit-p0-lancer-2239']){const u=s.units.find(u=>u.id===id)!;delete u.deck;u.x=4496;u.y=6400;}}
 if(reason==='overwhelming-raid')s.units.find(u=>u.id==='unit-p2-lancer-1263')!.attackDamage=10000;
 if(reason==='reserved-ships')for(const u of s.units.filter(u=>u.owner==='p0'&&u.sailing))options.memory.naval.ferries[u.id]={purpose:'evacuate',phase:'sailing',targetId:'other-hall',from:{x:0,y:0},to:{x:0,y:0},crewIds:[],sinceTick:s.tick};
 if(reason==='covered-coasts'){const b=s.buildings.find(b=>b.owner==='p2'&&b.kind==='defenseTower')!;b.x=4496;b.y=6512;b.attackRange=2200;}
 expect(homeRelief(s,'p0',options).selection).toBeUndefined();
});
it('keeps the actually unloaded ship in its home-water guard task',()=>{
 const {s,options}=saved(60000),job=options.memory.homeRelief,r=homeRelief(s,'p0',options);expect(job.phase).toBe('guard');expect(r.claimed.has(job.shipId)).toBe(true);expect(r.commands.some(c=>c.type==='attackMove')).toBe(false);
});
it('does not erase emergency helm or medical walking orders',()=>{
 const {s,options}=saved(60000),job=options.memory.homeRelief;options.memory.naval.coastalRetreat[job.shipId]={x:5300,y:5900};
 const r=homeRelief(s,'p0',options,[{type:'move',unitIds:[job.crewIds[0]],x:4400,y:6500,avoidCombat:true}]);
 expect(r.claimed.has(job.shipId)).toBe(false);expect(r.claimed.has(job.crewIds[0])).toBe(false);
});
