from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['home-relief-general-54600','home-relief-general-61000','home-relief-general-v2-54600','home-relief-general-observe.mts','home-relief-general-v2-observe.mts','home-relief-general-typecheck.log','home-relief-general-v2-typecheck.log','home-relief-general-tests.log','home-relief-general-v2-tests.log','home-relief-general-v2-typecheck-final.log','relief-selection-query.mts','relief-withdrawal-query.mts','relief-withdrawal-68400.jsonl','archive-general-relief.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f
for n in ['home-relief-probe.ts','home-relief-probe-v2.ts','home-relief.test.ts','vitest-home-relief.config.ts','tsconfig-home-relief.json','tsconfig-home-relief-v2.json','idle-worker-evasion-probe.ts']:
 files['draft/'+n]=repo/'.scratch-bootstrap-20261018'/n
manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'general-relief-probes-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'general-relief-probes-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
