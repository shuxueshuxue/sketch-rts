import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {coastOnWater} from '/workspace/bootstrap-1-resume/src/ai/policy/naval.ts';
import {effectiveCombatRating} from '/workspace/bootstrap-1-resume/src/ai/policy/v6/strength.ts';
import {shipPassengers} from '/workspace/bootstrap-1-resume/src/shared/ship-geometry.ts';
const f=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-sea-safety-20261018/loading-integrated-40800/frames/54600.json.gz')).toString());const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),hall=s.buildings.find(b=>b.id==='building-p0-townhall')!;
console.log('foe',s.units.filter(u=>u.id==='unit-p2-lancer-1263').map(u=>({x:u.x,y:u.y,power:effectiveCombatRating(s,u),order:u.order})));
console.log(s.units.filter(u=>u.owner==='p0'&&u.sailing).map(ship=>({id:ship.id,x:ship.x,y:ship.y,hp:ship.hp,maxHp:ship.maxHp,coast:coastOnWater(s,hall,ship),crew:shipPassengers(s.units,ship).map(u=>({id:u.id,kind:u.kind,power:effectiveCombatRating(s,u)}))})));
