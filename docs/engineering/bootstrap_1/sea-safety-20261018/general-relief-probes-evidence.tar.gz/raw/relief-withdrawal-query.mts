import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {boardingBerth} from '/workspace/bootstrap-1-resume/src/shared/naval.ts';
import {armedFoes,retreatLandTravelTicks} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';
import {mountedEscape} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mounted-micro.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),job=f.memories.p0.homeRelief,ship=s.units.find(u=>u.id===job.shipId)!,foes=armedFoes(s,'p0',{teams:g.teams});
for(const u of s.units.filter(u=>job.crewIds.includes(u.id))){const berth=boardingBerth(s.map,u,ship);console.log(JSON.stringify({tick:s.tick,id:u.id,berth,landTicks:berth?.shore?retreatLandTravelTicks(s,u,berth.shore,foes):null,escape:mountedEscape(s,u,foes.filter(f=>Math.hypot(f.x-u.x,f.y-u.y)<1000),0,undefined,true)}));}
