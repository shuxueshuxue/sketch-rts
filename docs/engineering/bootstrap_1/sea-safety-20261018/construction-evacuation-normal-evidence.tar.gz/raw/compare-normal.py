import json,gzip
from pathlib import Path
p=Path('/workspace/bootstrap-1-construction-20261018');normal=p/'construction-normal0';old=Path('/workspace/bootstrap-1-income-20261018/care-normal0');rows=[];replays=[]
for f in sorted((normal/'frames').glob('*.gz'),key=lambda f:int(f.name.split('.')[0])):
 x=json.loads(gzip.decompress(f.read_bytes()))
 for base,output in [(old,rows),(p/'construction-replay47745',replays)]:
  q=base/'frames'/f.name
  if q.exists():
   y=json.loads(gzip.decompress(q.read_bytes()));output.append({'tick':x['snapshot']['tick'],'snapshot':x['snapshot']==y['snapshot'],'nextId':x['nextId']==y['nextId'],'memories':x['memories']==y['memories']})
(p/'normal-prefix-equivalence.json').write_text(json.dumps(rows,indent=2));(p/'normal-replay-equivalence.json').write_text(json.dumps(replays,indent=2))
with (normal/'commands.jsonl').open()as a,(old/'commands.jsonl').open()as b:
 first=next(({'index':i,'new':json.loads(x),'old':json.loads(y)}for i,(x,y)in enumerate(zip(a,b))if json.loads(x)!=json.loads(y)),None)
(p/'normal-first-divergence.json').write_text(json.dumps(first,indent=2));print({'samples':len(rows),'last':rows[-1],'firstDifferentFrame':next((r for r in rows if not all(r[k] for k in ['snapshot','nextId','memories'])),None),'firstDifferentCommand':first,'replaySamples':len(replays),'replayEqual':all(all(r[k]for k in ['snapshot','nextId','memories'])for r in replays)})
if(normal/'result.json').exists():
 r=json.loads((normal/'result.json').read_text());s=json.loads(gzip.decompress((normal/'frames'/f"{r['tick']}.json.gz").read_bytes()))['snapshot'];deaths=[e for l in(normal/'entities.jsonl').open()if(e:=json.loads(l))['event']=='removal'and e['last']['owner']=='p0'and e['last']['id'].startswith('unit-')and e['last'].get('expiresTick')is None];summary={k:r[k]for k in['startTick','tick','winner','naturalComplete','sourceChangedDuringRun']};summary.update(permanentDeaths=len(deaths),permanentAlive=sum(u['owner']=='p0'and u.get('expiresTick')is None for u in r['remaining']),gold=r['players']['p0']['gold'],hall=next((b for b in s['buildings']if b['id']=='building-p0-townHall-15371'),None),builder=next((u for u in s['units']if u['id']=='unit-p0-worker-12838'),None));(p/'normal-summary.json').write_text(json.dumps(summary,indent=2));print({k:v for k,v in summary.items()if k not in['hall','builder']})
