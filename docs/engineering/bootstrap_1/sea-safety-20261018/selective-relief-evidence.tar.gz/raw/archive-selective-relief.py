from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['relief-integrated-ordinary0', 'relief-selective-26400', 'relief-selective-before-unload-26400', 'relief-selective-base-26400', 'relief-selective-native-26400', 'relief-reinforcement-64800', 'relief-reinforcement-v2-64800', 'observe.mts', 'relief-selective-observe.mts', 'relief-selective-base-observe.mts', 'relief-selective-draft-planner.mjs', 'relief-selective-base-planner.mjs', 'relief-selective-bundle-control.json', 'relief-reinforcement-observe.mts', 'relief-reinforcement-v2-observe.mts', 'selective-before-test.log', 'selective-after-test.log', 'selective-final-test.log', 'selective-typecheck.log', 'selective-final-typecheck.log', 'selective-native-25800', 'archive-selective-relief.py','reinforcement-casualty-comparison.json','selective-predecision-equivalence.json','selective-27600-native.png']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'selective-relief-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'selective-relief-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
