import {readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{createGame,restoreSnapshotIntoGame,snapshotGame}from'/workspace/bootstrap-1-resume/src/shared/sim.ts';
import{planAiOwnerCommandEntries}from'/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import{bootstrapScripts}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
import{preserveMercenaryTravel}from'/workspace/bootstrap-1-resume/src/ai/bootstrap_1/mercenary-control.ts';
import{planBootstrapCasterScreen}from'./caster-guard-draft.ts';
const report=[];
for(const version of ['v9_archer','v9_summoner','v9_knight'] as const){
 for(const guarded of [false,true]){
  const f=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-construction-20261018/caster-crash93600/crash-input.json.gz')).toString()),g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);
  const scripts=guarded?bootstrapScripts(version).map(s=>s.id==='v6Backline'?{...s,run:(s:any,p:any,o:any)=>preserveMercenaryTravel(s,p,o,planBootstrapCasterScreen(s,p,o))}:s):undefined;
  const snapshot=snapshotGame(g),before=JSON.stringify(snapshot);
  try{const entries=planAiOwnerCommandEntries(snapshot,{playerId:'p0',version,memory:f.memories.p0,scripts},{teams:g.teams});report.push({version,guarded,entries,snapshotUnchanged:JSON.stringify(snapshot)===before});}
  catch(e){report.push({version,guarded,error:String(e),snapshotUnchanged:JSON.stringify(snapshot)===before});}
 }
}
writeFileSync('/workspace/bootstrap-1-construction-20261018/caster-guard-three-routes.json',JSON.stringify(report,null,2),{flag:'wx'});
console.log(JSON.stringify(report));
