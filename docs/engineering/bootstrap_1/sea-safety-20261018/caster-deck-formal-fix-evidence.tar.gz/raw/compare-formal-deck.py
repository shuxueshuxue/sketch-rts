from pathlib import Path
import json,gzip
r=Path('/workspace/bootstrap-1-construction-20261018');a=r/'caster-guard93870';b=r/'formal-deck93870';pairs=[]
for p in sorted((a/'frames').glob('*.gz'),key=lambda p:int(p.name.split('.')[0])):
 q=b/'frames'/p.name
 if q.exists():pairs.append({'tick':int(p.name.split('.')[0]),'fullStateEqual':json.loads(gzip.decompress(p.read_bytes()))==json.loads(gzip.decompress(q.read_bytes()))})
x=[json.loads(s) for s in (a/'commands.jsonl').read_text().splitlines()];y=[json.loads(s) for s in (b/'commands.jsonl').read_text().splitlines()]
report={'frameComparisons':pairs,'commandsEqual':x==y,'commandCounts':[len(x),len(y)],'firstDifference':next(({'index':i,'draft':p,'formal':q} for i,(p,q) in enumerate(zip(x,y)) if p!=q),None)}
(r/'formal-deck-equivalence.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
