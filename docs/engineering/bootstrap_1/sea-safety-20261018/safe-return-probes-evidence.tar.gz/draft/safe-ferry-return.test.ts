import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';import {expect,it} from 'vitest';
import {createGame,restoreSnapshotIntoGame,snapshotGame,issuePlayerCommand} from '../src/shared/sim';
import {safeFerryReturn} from './safe-ferry-return-v2';
import {bootstrapPolicyContext,BOOTSTRAP_VERSIONS} from '../src/ai/bootstrap_1/policy';
const root='/workspace/bootstrap-1-sea-safety-20261018/';
function saved(arrival=false){const f=JSON.parse(gunzipSync(readFileSync(root+(arrival?'safe-return-before-landing-37200/frames/37305.json.gz':'capital-safe-landing-32400/frames/36600.json.gz'))).toString());const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);return {g,memory:f.memories.p0};}
const shipId='unit-p0-transport-5237';
it.each(BOOTSTRAP_VERSIONS)('%s sends the failed colony home through a complete native voyage',v=>{
 const {g,memory}=saved(),s=snapshotGame(g),before=JSON.stringify(s),o=bootstrapPolicyContext(s,'p0',v,{memory,teams:g.teams});
 const r=safeFerryReturn(s,'p0',o,[{type:'unload',unitIds:[shipId],x:1424,y:4016}]);
 expect(r.commands).toEqual([{type:'move',unitIds:[shipId],x:4976,y:6192,avoidCombat:true}]);expect(r.proofs[0]).toMatchObject({hallId:'building-p0-townhall',route:{partial:false}});expect(JSON.stringify(s)).toBe(before);
});
it('uses the public passenger API only when a safe native landing actually exists',()=>{const {g,memory}=saved(true),s=snapshotGame(g),gold=g.players.p0!.gold;const r=safeFerryReturn(s,'p0',{memory,teams:g.teams},[]);expect(r.commands.some(c=>c.type==='unloadPassenger')).toBe(true);for(const c of r.commands)issuePlayerCommand(g,'p0',c);const u=g.units.find(u=>u.id==='unit-p0-worker-1')!;expect(u.deck).toBeUndefined();expect(u.hp).toBe(70);expect(g.players.p0!.gold).toBe(gold);});
it('preserves an existing emergency helm move',()=>{const {g,memory}=saved();const c={type:'move' as const,unitIds:[shipId],x:3600,y:5300,avoidCombat:true};expect(safeFerryReturn(snapshotGame(g),'p0',{memory,teams:g.teams},[c]).commands).toEqual([c]);});
it('does not redirect a mission that is still sailing to its colony',()=>{const {g,memory}=saved();memory.naval.ferries[shipId].phase='sailing';const c={type:'unload' as const,unitIds:[shipId],x:4688,y:3536};expect(safeFerryReturn(snapshotGame(g),'p0',{memory,teams:g.teams},[c]).commands).toEqual([c]);});
it('does not invent a safe return when every owned hall is gone',()=>{const {g,memory}=saved();g.buildings=g.buildings.filter(b=>b.owner!=='p0'||b.kind!=='townHall');const r=safeFerryReturn(snapshotGame(g),'p0',{memory,teams:g.teams},[{type:'unload',unitIds:[shipId],x:1424,y:4016}]);expect(r.commands).toEqual([{type:'stop',unitIds:[shipId]}]);});
