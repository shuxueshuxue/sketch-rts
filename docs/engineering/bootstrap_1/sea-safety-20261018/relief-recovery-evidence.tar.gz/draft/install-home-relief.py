from pathlib import Path
import shutil
root=Path('/workspace/bootstrap-1-resume');scratch=root/'.scratch-bootstrap-20261018';src=root/'src/ai/bootstrap_1';evidence=Path('/workspace/bootstrap-1-sea-safety-20261018')
assert (evidence/'home-relief-general-v4-54600/result.json').exists()
s=(scratch/'home-relief-probe-v4.ts').read_text().replace('../src/shared/','../../shared/').replace('../src/ai/policy/','../policy/').replace('../src/ai/bootstrap_1/','./').replace('../src/ai/memory','../memory')
s=s.replace("import type { AiPolicyMemory } from '../memory';\n",'')
s='\n'.join(line for line in s.split('\n') if not line.startswith('type Job=') and not line.startswith('type Memory='))
s=s.replace('const memory=options.memory as Memory','const memory=options.memory')
s=s.replace('export function homeRelief','/** Commit one existing embarked detachment to an uncovered own hall.\n * Keep a coastal guard after relief; recover an outmatched detachment through\n * witnessed native boarding roads instead of spending it at a fixed post. */\nexport function homeRelief')
(src/'home-relief.ts').write_text(s)
s=(scratch/'idle-worker-evasion-probe.ts').read_text().replace('../src/shared/','../../shared/').replace('../src/ai/policy/','../policy/').replace('../src/ai/bootstrap_1/','./')
s=s.replace('export function idleWorkerEvasion','/** Idle civilians yield to nearby armed threats without taking over income,\n * boarding, construction, or an already accepted recovery task. */\nexport function idleWorkerEvasion')
(src/'idle-worker-evasion.ts').write_text(s)
p=root/'src/ai/memory.ts';s=p.read_text().replace('export type AiPolicyMemory = {','''export type AiPolicyMemory = {
  homeRelief?: { hallId:string; shipId:string; crewIds:string[]; landing:{x:number;y:number}; station:{x:number;y:number}; phase:'travel'|'guard'|'evacuate'|'recover'; since:number; initialThreat:number };
  homeReliefRetry?: number;''');p.write_text(s)
p=src/'policy.ts';s=p.read_text();s="import { homeRelief } from './home-relief';\nimport { idleWorkerEvasion } from './idle-worker-evasion';\n"+s
old="  return approaches.length ? [...recovered, ...approaches.map(command => ({ scriptId: AI_SCRIPT_LIBRARY.naval.id, command }))] : recovered;"
new="""  const navalEntries = approaches.length ? [...recovered, ...approaches.map(command => ({ scriptId: AI_SCRIPT_LIBRARY.naval.id, command }))] : recovered;
  const relief = homeRelief(snapshot, owner, options, navalEntries.map(entry => entry.command));
  const controlled = new Set(['move', 'attack', 'attackMove', 'board', 'unload', 'stop', 'holdPosition', 'follow']);
  const reliefEntries = navalEntries.flatMap(entry => {
    const command = entry.command;
    if (controlled.has(command.type) && 'unitIds' in command) {
      const unitIds = command.unitIds.filter(id => !relief.claimed.has(id));
      return unitIds.length ? [{ ...entry, command: { ...command, unitIds } }] : [];
    }
    return [entry];
  });
  reliefEntries.push(...relief.commands.map(command => ({ scriptId: 'homeRelief', command })));
  const evasion = idleWorkerEvasion(snapshot, owner, options, reliefEntries.map(entry => entry.command));
  return evasion.length ? [...reliefEntries, ...evasion.map(command => ({ scriptId: 'idleWorkerEvasion', command }))] : reliefEntries;"""
assert old in s;s=s.replace(old,new);p.write_text(s)
fixtures={'home-relief-54600.json.gz':'loading-integrated-40800/frames/54600.json.gz','home-relief-guard-60000.json.gz':'home-relief-general-54600/frames/60000.json.gz','home-relief-wave-68400.json.gz':'home-relief-general-v2-54600/frames/68400.json.gz','home-relief-recovered-69000.json.gz':'home-relief-general-v3-68400/frames/69000.json.gz','home-relief-trigger-68610.json.gz':'home-relief-general-v4-54600/selection-input-68610.json.gz'}
for dst,source in fixtures.items():shutil.copyfile(evidence/source,src/'fixtures'/dst)
s=(scratch/'home-relief-v4.test.ts').read_text().replace("'./home-relief-probe-v4'","'./home-relief'").replace("'../src/shared/","'../../shared/")
s=s.replace("`/workspace/bootstrap-1-sea-safety-20261018/${tick===54600?'loading-integrated-40800':'home-relief-general-54600'}/frames/${tick}.json.gz`","new URL(`./fixtures/home-relief-${tick===54600?'54600':'guard-60000'}.json.gz`,import.meta.url)")
s=s.replace("const dir=tick===68400?'home-relief-general-v2-54600':'home-relief-general-v3-68400';",'')
s=s.replace("`/workspace/bootstrap-1-sea-safety-20261018/${dir}/frames/${tick}.json.gz`","new URL(`./fixtures/home-relief-${tick===68400?'wave-68400':'recovered-69000'}.json.gz`,import.meta.url)")
s=s.replace("'/workspace/bootstrap-1-sea-safety-20261018/home-relief-general-v4-54600/selection-input-68610.json.gz'","new URL('./fixtures/home-relief-trigger-68610.json.gz',import.meta.url)")
s="import { planAiOwnerCommandEntries } from '../planner-context';\n"+s
s+="""
it.each(['v9_archer','v9_summoner','v9_knight'] as const)('%s integrates relief through the ordinary planner',version=>{
 const {s,options}=saved();const entries=planAiOwnerCommandEntries(s,{playerId:'p0',version,memory:options.memory},{teams:options.teams});
 expect(options.memory.homeRelief).toBeTruthy();expect(entries.some(e=>e.scriptId==='homeRelief'&&e.command.type==='unload'&&e.command.unitIds.includes(options.memory.homeRelief.shipId))).toBe(true);
});
"""
(src/'home-relief.test.ts').write_text(s)
s=(scratch/'idle-worker-evasion.test.ts').read_text().replace("'./idle-worker-evasion-probe'","'./idle-worker-evasion'").replace("'../src/shared/","'../../shared/").replace("'../src/ai/planner-context'","'../planner-context'").replace("'/workspace/bootstrap-1-sea-safety-20261018/loading-integrated-40800/frames/54600.json.gz'","new URL('./fixtures/home-relief-54600.json.gz',import.meta.url)")
(src/'idle-worker-evasion.test.ts').write_text(s)
