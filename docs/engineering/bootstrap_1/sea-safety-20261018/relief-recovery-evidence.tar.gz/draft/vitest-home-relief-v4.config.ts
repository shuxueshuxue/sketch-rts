import {defineConfig} from 'vitest/config';export default defineConfig({test:{include:['.scratch-bootstrap-20261018/home-relief-v4.test.ts'],fileParallelism:false}});
