from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['home-relief-general-v3-68400','home-relief-general-v4-54600','home-relief-general-v3-observe.mts','home-relief-general-v4-observe.mts','home-relief-v4-tests.log','home-relief-v4-tests-initial-failure.log','home-relief-v4-tests-final.log','home-relief-v4-typecheck.log','home-relief-v4-typecheck-final.log','home-relief-integrated-tests.log','home-relief-integrated-typecheck.log','archive-relief-recovery.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f
for n in ['home-relief-probe-v3.ts','home-relief-probe-v4.ts','home-relief-v4.test.ts','vitest-home-relief-v4.config.ts','tsconfig-home-relief-v4.json','idle-worker-evasion-probe.ts','install-home-relief.py']:
 files['draft/'+n]=repo/'.scratch-bootstrap-20261018'/n
manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'relief-recovery-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'relief-recovery-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
