from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['selective-fresh-ordinary0', 'observe.mts', 'selective-fresh-resume-equivalence.json', 'selective-34200-planner-timing.json', 'selective-34200-planner-timing.log', 'measure-planners.mts', 'evacuation-shelter-e9-30000', 'evacuation-shelter-native-observe.mts', 'shelter-input-30000.json.gz', 'shelter-input-30000-with-next-id.json.gz', 'extract-shelter-input.mts', 'shelter-integrated-tests.log', 'shelter-integrated-typecheck.log', 'archive-shelter-cross-input.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'shelter-cross-input-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'shelter-cross-input-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
