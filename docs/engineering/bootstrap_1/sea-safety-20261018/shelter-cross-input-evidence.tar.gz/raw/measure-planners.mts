import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {createAiMemoryProvider} from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import {createBootstrapCommandPlanner} from '/workspace/bootstrap-1-resume/scripts/bootstrap_1-planner.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString()),game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);
const memories=createAiMemoryProvider();for(const [p,m]of Object.entries(f.memories))memories.set!(p,m as any);
const planner=await createBootstrapCommandPlanner(memories),rows=[];
for(const owner of ['p0','p1','p2']){const t=performance.now();const entries=planner({snapshot:snapshotGame(game),owner,agent:f.match.agents[owner],teams:f.snapshot.teams,source:{kind:'ai',version:f.match.agents[owner].version}} as any);const row={owner,ms:performance.now()-t,commands:entries.length};rows.push(row);console.log(JSON.stringify(row));}
writeFileSync(process.argv[3]!,JSON.stringify({input:process.argv[2],rows},null,2));
