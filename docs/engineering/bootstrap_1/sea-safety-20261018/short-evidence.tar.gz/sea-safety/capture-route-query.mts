import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {nearestShipPose,planVoyageRoute} from '/workspace/bootstrap-1-resume/src/shared/ship-navigation.ts';
import {shipRouteTraffic} from '/workspace/bootstrap-1-resume/src/shared/ship-avoidance.ts';
import {beginShipCollisionFrame} from '/workspace/bootstrap-1-resume/src/shared/ship-collisions.ts';
import {combatCapability} from '/workspace/bootstrap-1-resume/src/shared/combat-capabilities.ts';
import {effectiveCombatRating} from '/workspace/bootstrap-1-resume/src/ai/policy/v6/strength.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);const s=snapshotGame(game);
const boat=s.units.find(u=>u.id==='unit-p0-warship-8230')!,foe=s.units.find(u=>u.id==='unit-p2-transport-1068')!;
console.log(JSON.stringify({tick:s.tick,boat,foe,near:s.units.filter(u=>u.sailing&&Math.hypot(u.x-boat.x,u.y-boat.y)<1000).map(u=>({id:u.id,hp:u.hp,distance:Math.hypot(u.x-boat.x,u.y-boat.y),gun:combatCapability(s,u),rating:effectiveCombatRating(s,u)}))}));
for(let i=0;i<1;i++){
 const angle=i*Math.PI/8,goal=i===0?{x:4781.268815341294,y:5898.7466969772095}:nearestShipPose(s.map,boat,{x:boat.x+600*Math.cos(angle),y:boat.y+600*Math.sin(angle)});
 if(!goal){console.log(JSON.stringify({i,rejected:'no pose'}));continue;}
 const hull={...boat,order:{type:'move' as const,x:goal.x,y:goal.y,avoidCombat:true},orderQueue:[],sailing:{...boat.sailing!}};delete hull.sailing.route;
 const units=s.units.map(u=>u.id===boat.id?hull:u);beginShipCollisionFrame(units,s.map,[...s.buildings,...s.obstacles??[]]);
 const route=planVoyageRoute(s.map,hull,goal,shipRouteTraffic(s.map,hull,units),1024);
 console.log(JSON.stringify({i,goal,partial:route.partial,points:route.points,minEnemyDistance:Math.min(...route.points.map(p=>Math.hypot(p.x-foe.x,p.y-foe.y)))}));
}
