import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,stepGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {issueCommandFrame} from '/workspace/bootstrap-1-resume/src/sdk/commands/frame.ts';
const f=JSON.parse(gunzipSync(readFileSync(process.argv[2]!)).toString());
for(const ids of [[],['unit-p0-lancer-3903'],['unit-p0-worker-1015','unit-p0-worker-5952'],['unit-p0-transport-2181'],['unit-p0-transport-3578']]){
 const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);
 if(ids.length)issueCommandFrame(game,[{playerId:'p0',source:'diagnostic',scriptId:'isolate-cost',command:{type:'stop',unitIds:ids}}]);
 const timing=[];for(let i=0;i<3;i++){const now=performance.now();stepGame(game);timing.push(performance.now()-now);}
 console.log(JSON.stringify({stopped:ids,tick:game.tick,units:game.units.length,buildings:game.buildings.length,timing}));
}
