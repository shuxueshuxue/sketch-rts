import * as candidate from './relief-selective-base-planner.mjs';
import {groundRevision} from '/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import { mkdirSync, writeFileSync, openSync, writeSync, closeSync, readFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { bootstrapMatches, bootstrapGame } from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/benchmark.ts';
import { runAiGameLoop } from '/workspace/bootstrap-1-resume/src/ai/game-runner.ts';
import { createAiMemoryProvider } from '/workspace/bootstrap-1-resume/src/ai/planner-context.ts';
import { createBootstrapCommandPlanner, frozenPolicyManifest } from '/workspace/bootstrap-1-resume/scripts/bootstrap_1-planner.ts';
import { snapshotGame, restoreSnapshotIntoGame } from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
const out=process.argv[2]!, limit=Number(process.argv[3]??60000), resume=process.argv[4];
mkdirSync(out,{recursive:false});mkdirSync(out+'/frames');
const sha=(s:Buffer|string)=>createHash('sha256').update(s).digest('hex');
const paths=execFileSync('git',['ls-files','src','scripts'],{encoding:'utf8'}).trim().split('\n').filter(p=>/\.(ts|mts|js|mjs)$/.test(p));
const source=Object.fromEntries(paths.map(p=>[p,sha(readFileSync(p))]));
const match=bootstrapMatches('bootstrap_1-official-brokenSea-archer-v5-v8-20261016',['brokenSea'],limit,false).find(m=>m.subject==='v9_archer'&&m.side===0&&m.agents.p0!.race==='grove'&&m.agents.p1!.version==='v5'&&m.agents.p2?.version==='v8')!;
if(!match)throw Error('missing match');
const game=bootstrapGame(match), memories=createAiMemoryProvider();
if(resume){const cp=JSON.parse(gunzipSync(readFileSync(resume)).toString());restoreSnapshotIntoGame(game,cp.snapshot,cp.nextId);for(const [p,m]of Object.entries(cp.memories))memories.set!(p,m as any);}
const startTick=game.tick, ordinaryPlanner=await createBootstrapCommandPlanner(memories);
const revisions=new WeakMap<object,number>();
const planner:typeof ordinaryPlanner=input=>{
 if(input.owner!=='p0')return ordinaryPlanner(input);
 const revision=groundRevision(input.snapshot.map);if(revisions.get(input.snapshot.map)!==revision){candidate.setBuildingBodies(input.snapshot.map,[...input.snapshot.buildings,...input.snapshot.obstacles??[]]);revisions.set(input.snapshot.map,revision);}
 const entries=candidate.planAiOwnerCommandEntries(input.snapshot,{playerId:input.owner,version:input.agent.policyVersion??input.agent.version,source:input.source},{teams:input.teams,memoryProvider:memories});
 const s=input.snapshot,commands:any[]=[],claimed=new Set<string>();
 for(const u of s.units.filter(u=>u.owner===input.owner&&u.kind==='worker'&&u.deck&&!u.cabin)){
  if(entries.some(e=>e.command.type==='unloadPassenger'&&e.command.passengerId===u.id))continue;
  const enemies=s.units.filter(e=>e.hp>0&&e.deck?.shipId===u.deck!.shipId&&e.owner!==input.owner&&(s.teams?.[e.owner]??e.owner)!==(s.teams?.[input.owner]??input.owner));
  enemies.sort((a,b)=>Math.hypot(a.x-u.x,a.y-u.y)-Math.hypot(b.x-u.x,b.y-u.y));
  const target=enemies[0];if(!target)continue;claimed.add(u.id);
  if(u.order.type!=='attack'||u.order.targetId!==target.id)commands.push({type:'attack',unitIds:[u.id],targetId:target.id});
 }
 return [...entries.filter(e=>{const c=e.command;return !('unitIds' in c&&c.unitIds.some(id=>claimed.has(id))||'unitId' in c&&claimed.has(c.unitId));}),...commands.map(command=>({playerId:input.owner,source:input.source,scriptId:'diagnosticDeckDefense',command}))];
};
const fds=Object.fromEntries(['commands','hits','entities','samples'].map(n=>[n,openSync(out+'/'+n+'.jsonl','wx')]));
const log=(name:string,data:any)=>writeSync(fds[name]!,JSON.stringify(data)+'\n');
const compact=(u:any)=>({id:u.id,kind:u.kind,owner:u.owner,hp:u.hp,maxHp:u.maxHp,x:u.x,y:u.y,deck:u.deck,expiresTick:u.expiresTick,order:u.order});
let previous=new Map([...game.units,...game.buildings].map(u=>[u.id,compact(u)]));
const frame=()=>writeFileSync(out+'/frames/'+game.tick+'.json.gz',gzipSync(JSON.stringify({snapshot:snapshotGame(game),nextId:game.nextId,memories:Object.fromEntries(Object.keys(match.agents).map(p=>[p,memories.get(p)])),match}),{level:3}),{flag:'wx'});
frame();
writeFileSync(out+'/source.json',JSON.stringify({head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),source,frozenPolicyManifest,match,startTick,resume:resume??null,initialPlayers:game.players},null,2));
game.observer={hit(a,t,damage,hpBefore){log('hits',{tick:game.tick,attacker:compact(a),target:compact(t),damage,hpBefore});}};
const result=runAiGameLoop({...match,game,commandPlanner:planner},{onCommand({tick,owner,scriptId,command}){log('commands',{tick,owner,scriptId,command});},onStep(){
 const current=new Map([...game.units,...game.buildings].map(u=>[u.id,compact(u)]));
 for(const[id,u]of current)if(!previous.has(id))log('entities',{tick:game.tick,event:'birth',entity:u});
 for(const[id,u]of previous)if(!current.has(id))log('entities',{tick:game.tick,event:'removal',last:u});
 previous=current;
 if(game.tick%600===0||game.match.winner){frame();const row={tick:game.tick,winner:game.match.winner,stats:game.match.stats,players:game.players,ferries:memories.get('p0')?.naval?.ferries,resources:game.resources};log('samples',row);console.log(JSON.stringify({tick:game.tick,winner:game.match.winner,gold:game.players.p0!.gold,lost:game.match.stats.unitsLost.p0,ships:game.units.filter(u=>u.owner==='p0'&&u.sailing).length}));}
}});
if(game.tick%600!==0&&!game.match.winner)frame();
for(const fd of Object.values(fds))closeSync(fd);
const changed=paths.filter(p=>sha(readFileSync(p))!==source[p]);
writeFileSync(out+'/result.json',JSON.stringify({startTick,tick:game.tick,winner:game.match.winner,naturalComplete:!!game.match.winner,stats:game.match.stats,players:game.players,remaining:game.units.map(compact),buildings:game.buildings.map(compact),elapsedMs:result.elapsedMs,sourceChangedDuringRun:changed},null,2));
if(changed.length)process.exitCode=2;
