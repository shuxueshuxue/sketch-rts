from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['evacuation-cabin-30000', 'evacuation-cabin-30000.log', 'evacuation-cabin-observe.mts', 'evacuation-cabin-v2-30000', 'evacuation-cabin-v2-observe.mts', 'evacuation-defense-30000', 'evacuation-defense-observe.mts', 'evacuation-shelter-30000', 'evacuation-shelter-observe.mts', 'evacuation-shelter-v2-30000', 'evacuation-shelter-v2-observe.mts', 'evacuation-shelter-before-release-30600', 'evacuation-shelter-tests.log', 'evacuation-shelter-v2-tests.log', 'evacuation-shelter-v2-final-tests.log', 'evacuation-shelter-v2-typecheck.log', 'relief-economic-collapse.json', 'relief-selective-base-planner.mjs', 'archive-evacuation-shelter.py']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f

for name in ['evacuation-shelter-probe.ts','evacuation-shelter-probe-v2.ts','evacuation-shelter-probe.test.ts','evacuation-shelter-probe-v2.test.ts','tsconfig-evacuation-shelter-v2.json']:
 files['draft/'+name]=repo/'.scratch-bootstrap-20261018'/name

manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'evacuation-shelter-probes-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'evacuation-shelter-probes-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
