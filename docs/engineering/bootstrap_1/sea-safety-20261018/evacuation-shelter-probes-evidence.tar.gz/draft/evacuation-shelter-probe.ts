import {canEnterCabin,isInCabin,cabinExitPoint} from '../src/shared/ship-cabin';
import {shipPassengers} from '../src/shared/ship-geometry';
import {landingSpot} from '../src/shared/naval';
import {sameGround} from '../src/shared/terrain';
import {combatCapability} from '../src/shared/combat-capabilities';
import {isOpponentOwner} from '../src/ai/policy/ownership';
import type {GameSnapshot,PlayerId,GameCommand} from '../src/shared/types';
import type {AiPolicyContext} from '../src/ai/policy/types';
export function evacuationShelter(s:GameSnapshot,owner:PlayerId,options:AiPolicyContext){
 const memory=options.memory as typeof options.memory&{evacuationShelters?:Record<string,string>};
 const tracked=memory.evacuationShelters??{},commands:GameCommand[]=[],claimed=new Set<string>();
 const hostile=s.units.filter(u=>isOpponentOwner(s,owner,u.owner,options)&&combatCapability(s,u).armed);
 for(const [id,shipId] of Object.entries(tracked))if(!s.units.some(u=>u.id===id&&u.owner===owner&&u.deck?.shipId===shipId))delete tracked[id];
 for(const ship of s.units.filter(u=>u.owner===owner&&u.sailing)){
  const mission=memory.naval?.ferries?.[ship.id];
  const endangered=mission?.purpose==='evacuate'&&mission.phase==='sailing'&&hostile.some(u=>Math.hypot(u.x-ship.x,u.y-ship.y)<500);
  const passengers=shipPassengers(s.units,ship);
  for(const u of passengers.filter(u=>u.owner===owner&&u.kind==='worker')){
   if(!tracked[u.id]&&(!endangered||!canEnterCabin(s,u,ship)))continue;
   const spot=landingSpot(s.map,ship,passengers.indexOf(u),passengers.length,s.units,u);
   const safe=spot&&s.buildings.some(b=>b.owner===owner&&b.kind==='townHall'&&b.complete&&sameGround(s.map,b,spot)&&Math.hypot(b.x-spot.x,b.y-spot.y)<850)
    &&!hostile.some(e=>!e.deck&&sameGround(s.map,e,spot)&&Math.hypot(e.x-spot.x,e.y-spot.y)<600);
   tracked[u.id]=ship.id;claimed.add(u.id);
   if(safe){if(isInCabin(u)){if(cabinExitPoint(s,ship,u))commands.push({type:'leaveCabin',unitIds:[u.id]});}else commands.push({type:'unloadPassenger',transportId:ship.id,passengerId:u.id});}
   else if(!isInCabin(u)&&u.order.type!=='enterCabin'&&canEnterCabin(s,u,ship))commands.push({type:'enterCabin',unitIds:[u.id]});
  }
 }
 if(Object.keys(tracked).length)memory.evacuationShelters=tracked;else delete memory.evacuationShelters;
 return {commands,claimed};
}
