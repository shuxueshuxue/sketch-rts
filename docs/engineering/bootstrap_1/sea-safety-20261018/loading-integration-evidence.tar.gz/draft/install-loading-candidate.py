from pathlib import Path
import shutil
root=Path('/workspace/bootstrap-1-resume');draft=root/'.scratch-bootstrap-20261018';src=root/'src/ai/bootstrap_1'
assert Path('/workspace/bootstrap-1-sea-safety-20261018/loading-general-v2-40800/result.json').exists(), 'Observation must finish before editing tracked code'
shutil.copyfile(draft/'transport-recovery-final.ts',src/'transport-recovery.ts')
s=(draft/'loading-approach-probe-v2.ts').read_text().replace('/workspace/bootstrap-1-resume/src/shared/','../../shared/').replace('/workspace/bootstrap-1-resume/src/ai/policy/','../policy/').replace('/workspace/bootstrap-1-resume/src/ai/memory','../memory')
s=s.replace("import type { NavalPlanMemory } from '../memory';\n",'').replace('type Mark={tick:number;bestGap:number;crew:string;goal:{x:number;y:number};shore:{x:number;y:number};checkedAt?:number};\n','').replace('options.memory.naval as (NavalPlanMemory & {loadingApproaches?:Record<string,Mark>})|undefined','options.memory.naval')
s=s.replace('export function loadingApproach','/** Reapproach an existing boarding berth only after sustained lack of closing.\n * Keep other helm orders and native collision/boarding control authoritative. */\nexport function loadingApproach')
(src/'loading-approach.ts').write_text(s)
p=root/'src/ai/memory.ts';s=p.read_text();s=s.replace('  settlerSeaMarks?:','  loadingApproaches?: Record<string, { tick:number; bestGap:number; crew:string; goal:{x:number;y:number}; shore:{x:number;y:number}; checkedAt?:number }>;\n  settlerSeaMarks?:');p.write_text(s)
p=src/'policy.ts';s=p.read_text();s="import { loadingApproach } from './loading-approach';\n"+s
old='''  if (final === planned) return entries;
  const byCommand = new Map<GameCommand, AiCommandEntry[]>();
  for (const entry of entries) byCommand.set(entry.command, [...(byCommand.get(entry.command) ?? []), entry]);
  return final.map(command => byCommand.get(command)?.shift() ?? { scriptId: AI_SCRIPT_LIBRARY.naval.id, command });'''
new='''  let recovered = entries;
  if (final !== planned) {
    const byCommand = new Map<GameCommand, AiCommandEntry[]>();
    for (const entry of entries) byCommand.set(entry.command, [...(byCommand.get(entry.command) ?? []), entry]);
    recovered = final.map(command => byCommand.get(command)?.shift() ?? { scriptId: AI_SCRIPT_LIBRARY.naval.id, command });
  }
  const approaches = loadingApproach(snapshot, owner, options, recovered.map(entry => entry.command));
  return approaches.length ? [...recovered, ...approaches.map(command => ({ scriptId: AI_SCRIPT_LIBRARY.naval.id, command }))] : recovered;'''
assert old in s;s=s.replace(old,new);p.write_text(s)
shutil.copyfile(draft/'repair-starvation.test.ts',src/'repair-starvation.test.ts')
shutil.copyfile('/workspace/bootstrap-1-sea-safety-20261018/workforce-ordinary0/frames/84000.json.gz',src/'fixtures/repair-starvation-84000.json.gz')
s=(draft/'loading-approach-contracts.test.ts').read_text().replace("'./loading-approach-probe-v2'","'./loading-approach'").replace("'../src/shared/","'../../shared/")
s=s.replace("const input='/workspace/bootstrap-1-sea-safety-20261018/loading-general-v2-49200/approach-input-51060.json.gz';","const input=new URL('./fixtures/loading-approach-51060.json.gz',import.meta.url);")
(src/'loading-approach.test.ts').write_text(s)
shutil.copyfile('/workspace/bootstrap-1-sea-safety-20261018/loading-general-v2-49200/approach-input-51060.json.gz',src/'fixtures/loading-approach-51060.json.gz')
