import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {expect,it} from 'vitest';
import {loadingApproach} from '../src/ai/bootstrap_1/loading-approach';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '../src/shared/sim';
function saved(){const f=JSON.parse(gunzipSync(readFileSync('/workspace/bootstrap-1-sea-safety-20261018/loading-general-v2-49200/approach-input-51060.json.gz')).toString());const game=createGame('bareDuel');restoreSnapshotIntoGame(game,f.snapshot,f.nextId);return {s:snapshotGame(game),options:{memory:f.memory,teams:f.teams},planned:f.planned.map((e:any)=>e.command)};}
it('refuses a coordinate approach covered by an actual tower weapon',()=>{
 const {s,options,planned}=saved();const tower=s.buildings.find(b=>b.owner==='p2'&&b.kind==='defenseTower')!;tower.x=4152;tower.y=5880;
 expect(loadingApproach(s,'p0',options,planned)).toEqual([]);
});
it('refuses a coordinate approach covered by a hostile working ship weapon',()=>{
 const {s,options,planned}=saved();const ship=s.units.find(u=>u.id==='unit-p0-warship-1119')!;ship.owner='p2';ship.x=4152;ship.y=5750;
 expect(loadingApproach(s,'p0',options,planned)).toEqual([]);
});
