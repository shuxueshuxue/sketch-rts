import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.scratch-bootstrap-20261018/loading-safety-contracts.test.ts'],fileParallelism:false}});
