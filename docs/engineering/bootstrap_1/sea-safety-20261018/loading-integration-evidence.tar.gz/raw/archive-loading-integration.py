from pathlib import Path
import hashlib,json,tarfile,io
root=Path('/workspace/bootstrap-1-sea-safety-20261018');repo=Path('/workspace/bootstrap-1-resume'); dest=repo/'docs/engineering/bootstrap_1/sea-safety-20261018'
names=['loading-general-v2-40800','loading-integrated-40800','loading-integration-equivalence.json','compare-loading-integration.py','loading-route-proof-42150.json','loading-v2-onset-48600-native.png','loading-integrated-60000-native.png','loading-v2-contracts.log','loading-safety-contracts.log','loading-integrated-tests.log','loading-integrated-typecheck.log','loading-integrated-frozen-audit.json','loading-general-v2-observe.mts','observe.mts','repair-v3-draft-planner.mjs','archive-loading-integration.py','loading-general-v2-49200/experimental-source-postrun.json','loading-general-v2-52800/experimental-source-postrun.json']
files={}
for name in names:
 p=root/name
 if not p.exists():raise Exception(str(p))
 for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
  if f.is_file(): files['raw/'+str(f.relative_to(root))]=f
for n in ['loading-approach-probe-v2.ts','transport-recovery-probe-v3.ts','build-repair-v3.mts','loading-approach-contracts.test.ts','loading-safety-contracts.test.ts','vitest-loading.config.ts','vitest-loading-safety.config.ts','install-loading-candidate.py']:
 files['draft/'+n]=repo/'.scratch-bootstrap-20261018'/n
manifest={k:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()}
archive=dest/'loading-integration-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,meta in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
report={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest}
(dest/'loading-integration-evidence.sha256.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}),'files',len(files))
