import json,gzip
from pathlib import Path
root=Path('/workspace/bootstrap-1-sea-safety-20261018');rows=[]
for p in sorted((root/'loading-integrated-40800/frames').glob('*.gz')):
 q=root/'loading-general-v2-40800/frames'/p.name
 if not q.exists():continue
 a=json.loads(gzip.decompress(p.read_bytes()));b=json.loads(gzip.decompress(q.read_bytes()))
 rows.append({'tick':a['snapshot']['tick'],'snapshot':a['snapshot']==b['snapshot'],'nextId':a['nextId']==b['nextId'],'memories':a['memories']==b['memories']})
report={'note':'Native integrated planner versus bundled repair v3 with loading v2 overlay. Full states and all three AI memories, no normalization.','samples':rows,'allEqual':all(all(r[k] for k in ['snapshot','nextId','memories']) for r in rows)}
(root/'loading-integration-equivalence.json').write_text(json.dumps(report,indent=2)+'\n');print('samples',len(rows),'through',rows[-1]['tick'],'allEqual',report['allEqual']);print([r for r in rows if not all(r[k] for k in ['snapshot','nextId','memories'])][:3])
