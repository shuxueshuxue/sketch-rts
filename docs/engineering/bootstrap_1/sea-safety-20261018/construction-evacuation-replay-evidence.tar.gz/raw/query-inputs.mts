import {readFileSync,writeFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {createGame,restoreSnapshotIntoGame,snapshotGame} from '/workspace/bootstrap-1-resume/src/shared/sim.ts';
import {bootstrapPolicyContext} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/policy.ts';
import {rankBootstrapGoals} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/economy.ts';
import {armedFoes,safeLandTravelTicks,retreatLandTravelTicks} from '/workspace/bootstrap-1-resume/src/ai/bootstrap_1/safe-land-route.ts';
import {sameGround} from '/workspace/bootstrap-1-resume/src/shared/terrain.ts';
import {routeTravelTicks} from '/workspace/bootstrap-1-resume/src/shared/route-selection.ts';
import {evacuationRoute} from './naval-query.ts';
const rows=[];for(const t of [47400,47415,47430,47550,47685,47700,47715,47730,47745,47775]){
const f=JSON.parse(gunzipSync(readFileSync(`/workspace/bootstrap-1-construction-20261018/exact47400/frames/${t}.json.gz`)).toString());const g=createGame('bareDuel');restoreSnapshotIntoGame(g,f.snapshot,f.nextId);const s=snapshotGame(g),o=bootstrapPolicyContext(s,'p0','v9_archer',{memory:structuredClone(f.memories.p0),teams:g.teams});
const site={x:3120,y:3888},foes=armedFoes(s,'p0',o),halls=s.buildings.filter(b=>b.owner==='p0'&&b.kind==='townHall'&&b.complete),boat=s.units.find(u=>u.id==='unit-p0-carrier-3009')!;
const compact=(u:any)=>({id:u.id,kind:u.kind,hp:u.hp,x:u.x,y:u.y,deck:u.deck,order:u.order,attackDamage:u.attackDamage,attackRange:u.attackRange});
rows.push({tick:t,gold:s.players.p0!.gold,spent:s.match.stats.goldSpent.p0,site,mines:s.resources.map(m=>({id:m.id,amount:m.amount,distance:Math.hypot(m.x-site.x,m.y-site.y)})),hall:s.buildings.find(b=>b.id==='building-p0-townHall-15371'),boat:compact(boat),mission:f.memories.p0.naval?.ferries?.[boat.id],evacuation:evacuationRoute(s,'p0',o,boat,halls),workers:s.units.filter(u=>u.owner==='p0'&&u.kind==='worker'&&sameGround(s.map,u,site)).map(u=>({...compact(u),road:routeTravelTicks(s.map,u,site,'land',u.speed)??null,safe:safeLandTravelTicks(s,u,site,foes)??null,retreat:retreatLandTravelTicks(s,u,site,foes)??null})),foes:foes.filter(u=>Math.hypot(u.x-site.x,u.y-site.y)<1200).map(compact),goals:rankBootstrapGoals(s,'p0',o).slice(0,8).map(goal=>({...goal,issue:goal.issue(new Set())}))});}
writeFileSync('/workspace/bootstrap-1-construction-20261018/input-query.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(r=>({tick:r.tick,gold:r.gold,spent:r.spent,hall:r.hall?.buildProgress,workers:r.workers,evacuation:r.evacuation,goals:r.goals.slice(0,2),foes:r.foes})),null,2));
