import json,pathlib
s=json.load(open('.playtest/coastal-withdrawal/full-match.json.frames/96000.json'))['snapshot'];t=s['map']['terrain'];print(t['cell'],t['cols'],t['rows']);print([(u['id'],u['x'],u['y']) for u in s['units'] if u['id'] in ['unit-p0-transport-1046','unit-p0-footman-3009','unit-p0-footman-3035']]);print('ship profile')
