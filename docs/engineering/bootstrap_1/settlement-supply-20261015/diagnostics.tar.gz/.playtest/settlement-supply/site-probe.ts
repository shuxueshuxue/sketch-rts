import {readFileSync} from 'node:fs';
import {safeBuildPointAt,safeMainBuildPoint} from '../../src/ai/policy/build-layout';
import {isBuildPlacementClear} from '../../src/shared/build-placement';
import {routeArrivals} from '../../src/shared/route-selection';
import {sameGround} from '../../src/shared/terrain';
const {snapshot:s}=JSON.parse(readFileSync('.playtest/settlement-supply/full-match.json.frames/12000.json','utf8'));
const slot=s.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='farm').length+4;
for(const base of s.buildings.filter((b:any)=>b.owner==='p0'&&b.kind==='townHall'&&b.complete)){
 const p=safeBuildPointAt(s,'p0',base,slot,'farm');console.log({p,main:safeMainBuildPoint(s,'p0',slot,'farm'),clear:isBuildPlacementClear(s,'farm',p),workers:s.units.filter((u:any)=>u.owner==='p0'&&u.kind==='worker').map((u:any)=>({id:u.id,carry:u.carryingGold,same:sameGround(s.map,u,p),arrive:routeArrivals(s.map,[u],p,'land').map(a=>a.ticks)}))});
}
