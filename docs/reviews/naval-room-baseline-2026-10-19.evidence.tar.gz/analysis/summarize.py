import json,sys,pathlib,statistics,collections
root=pathlib.Path(sys.argv[1]); records=[]
for p in root.glob('*.json'):
 if p.name in ('manifest.json','report.json'): continue
 r=json.loads(p.read_text()); records.append(r)
rows=[]
for r in records:
 for owner, s in r['result']['trackers']['naval'].items():
  a=r['setup']['players'][owner]; duration=r['result']['gameSecond']
  plans=s['plans']; long=[p for p in plans if p['completedSecond'] is None and p['lastSeenSecond']-p['startSecond']>=180]
  stuck=[p for p in s['ships'] if p['stalledSeconds']>=120]
  rows.append(dict(name=r['name'],owner=owner,version=a['aiVersion'],team=a['team'],ours=a['team']==r['naval']['subjectTeam'],subject=r['naval']['subject'],duration=duration,win=r['result']['winnerTeam']==a['team'],timeout=r['result']['timeout'],landing=s['firstLandingSecond'],military=s['firstMilitaryLandingSecond'],plans=len(plans),completed=len({p['mineId'] for p in plans if p['completedSecond'] is not None}),long=len(long),longAge=max([p['lastSeenSecond']-p['startSecond'] for p in long],default=0),lost=s['lostGold'],idle=s['idleShipSeconds'],stall=s['stalledShipSeconds'],shipSeconds=s['shipSeconds'],ships=len(s['ships']),capital=sum(p['gold'] for p in s['ships']),stuckGold=sum(p['gold'] for p in stuck),deliveries=s['deliveries'],roundTrips=s['roundTrips'],checkpoints=s['checkpoints']))
def summary(rs):
 landed=[r['landing'] for r in rs if r['landing'] is not None]
 mil=[r['military'] for r in rs if r['military'] is not None]
 result=dict(players=len(rs),landed=len(landed),medianLanding=statistics.median(landed) if landed else None,militaryLanded=len(mil),medianMilitary=statistics.median(mil) if mil else None,longPlanPlayers=sum(r['long']>0 for r in rs),plans=sum(r['plans'] for r in rs),completed=sum(r['completed'] for r in rs),ships=sum(r['ships'] for r in rs),capital=sum(r['capital'] for r in rs),stuckGold=sum(r['stuckGold'] for r in rs),lost=sum(r['lost'] for r in rs),idleMinutes=sum(r['idle'] for r in rs)/60,stallMinutes=sum(r['stall'] for r in rs)/60,shipMinutes=sum(r['shipSeconds'] for r in rs)/60,deliveries=sum(r['deliveries'] for r in rs),roundTrips=sum(r['roundTrips'] for r in rs))
 for minute in ('5','10','15','20','30','40'):
  ck=[r['checkpoints'][minute] for r in rs if minute in r['checkpoints']]
  result['island'+minute]=dict(players=len(ck),bases=sum(c['islandBases'] for c in ck),mines=sum(c['islandMines'] for c in ck))
 return result
out=dict(games=len(records),wins=sum(r['result']['winnerTeam']==r['naval']['subjectTeam'] for r in records),timeouts=sum(r['result']['timeout'] for r in records),byVersion={v:summary([r for r in rows if r['version']==v]) for v in sorted(set(r['version'] for r in rows))},bySubject={},byMap={})
for subject in sorted(set(r['subject'] for r in rows)):
 rs=[r for r in rows if r['subject']==subject]
 out['bySubject'][subject]={'ours':summary([r for r in rs if r['ours']]),'theirs':summary([r for r in rs if not r['ours']])}
for mid in sorted(set(r['name'].split()[0] for r in rows)):
 rs=[r for r in rows if r['name'].startswith(mid+' ')]
 out['byMap'][mid]={'ours':summary([r for r in rs if r['ours']]),'theirs':summary([r for r in rs if not r['ours']])}
keys=['name','owner','version','duration','win','landing','plans','completed','long','longAge','ships','capital','stuckGold','lost','deliveries','roundTrips']
out['cases']={k:[{x:r[x] for x in keys} for r in sorted([r for r in rows if r['ours']],key=key,reverse=True)[:12]] for k,key in [('longPlan',lambda r:r['longAge']),('stuckCapital',lambda r:r['stuckGold']),('losses',lambda r:r['lost'])]}
print(json.dumps(out,indent=2))
