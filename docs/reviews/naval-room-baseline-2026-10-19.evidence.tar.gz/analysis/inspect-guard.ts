import { readFileSync, writeFileSync } from 'node:fs';
import { sameGround, walkableGoal } from '../../src/shared/terrain';
import { strengthOf } from '../../src/ai/policy/v6/strength';
import { unitMover } from '../../src/shared/catalog';
import { combatCapability } from '../../src/shared/combat-capabilities';
import { boardUnit } from '../../src/shared/decks';
import { distanceToHull, shipPassengers } from '../../src/shared/ship-geometry';
import { routeArrivals } from '../../src/shared/route-selection';
const rows = [];
for (const [dir, seconds, owner, id] of [
  ['gull-spare-guard', [1230, 1245, 1260, 1275], 'player', 'unit-player-carrier-4150'],
  ['gull-mirror-spare-guard', [1291, 1300, 1320], 'enemy', 'unit-enemy-carrier-4436'],
] as const) {
  for (const second of seconds) {
    const trace = JSON.parse(readFileSync(`work/naval-analysis/replays/${dir}/${second}.json`, 'utf8'));
    const s = trace.snapshot, mission = trace.memories[owner].naval.ferries[id];
    const boat = s.units.find((u: any) => u.id === id), shore = walkableGoal(s.map, mission.from.x, mission.from.y);
    const soldiers = s.units.filter((u: any) => u.owner === owner && !u.deck && u.kind !== 'worker' && unitMover(u.kind) === 'land' && !u.expiresTick && sameGround(s.map, u, shore) && u.order.type !== 'board' && u.order.type !== 'cast');
    const rider = soldiers.find((u: any) => u.id === mission.riderId);
    const enemies = s.units.filter((u: any) => u.owner !== 'neutral' && s.teams[u.owner] !== s.teams[owner] && sameGround(s.map, u, shore) && combatCapability(s, u).armed);
    const target = s.resources.find((r: any) => r.id === mission.targetId);
    rows.push({name: trace.name, owner, second, ship: id, phase: mission.phase, rider: rider?.id,
      cargo: shipPassengers(s.units, boat).length, shoreGap: distanceToHull(boat, shore),
      ownStrength: strengthOf(soldiers), riderStrength: rider && strengthOf([rider]), enemyDemand: strengthOf(enemies) * 1.3,
      riderRouteExists: !!rider && routeArrivals(s.map, [rider], shore, 'land').length > 0,
      riderFitsDeck: !!rider && boardUnit(boat, {...rider}, [...s.units]),
      target: target && {id: target.id, x: target.x, y: target.y, gold: target.amount},
      recentNavalCommands: trace.commands.filter((c: any) => c.second >= second - 15 && c.owner === owner && (c.scriptId === 'naval' || c.command.type === 'board' || c.command.type === 'unload')),
    });
  }
}
writeFileSync('work/naval-analysis/guard-replay-facts.json', JSON.stringify(rows, null, 2));
console.log(JSON.stringify(rows));
