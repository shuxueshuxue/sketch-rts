import pathlib,json,sys,collections
baseline=pathlib.Path(sys.argv[1]);diagnostics=pathlib.Path(sys.argv[2]);bases={}
for p in baseline.glob('*.json'):
 if p.name not in ('manifest.json','report.json'):r=json.loads(p.read_text());bases[r['name']]=r
rows=[];mismatches=[]
for p in diagnostics.glob('*.json'):
 if p.name in ('manifest.json','report.json'):continue
 r=json.loads(p.read_text());b=bases[r['name']]
 changed=[k for k in ('tick','winnerTeam','timeout','players')if r['result'][k]!=b['result'][k]]
 if changed:mismatches.append({'name':r['name'],'changed':changed})
 for owner,agent in r['setup']['players'].items():
  role='ours'if agent['team']==b['naval']['subjectTeam']else'theirs'
  guard=r['result']['trackers']['navalLoadingDiagnostics'][owner];turn=r['result']['trackers']['navalTurnaroundDiagnostics'][owner]
  rows.append(dict(name=r['name'],owner=owner,version=agent['aiVersion'],subject=b['naval']['subject'],role=role,guard=guard,turn=turn))
def summary(rr):
 blocked=[r for r in rr if r['guard']['blockedSeconds']>0];sufficient=[r for r in rr if r['guard']['fullGuardSufficientSeconds']>0];quick=[r for r in rr if r['turn']['immediateReturns']];signature=[r for r in quick if any(e['emptyDestinationBlockedOrigin']for e in r['turn']['immediateReturns'])]
 boats={};suffboats={};quickboats={};signatureboats={};events=[];signatureevents=[]
 for r in rr:
  for id,s in r['guard']['ships'].items():
   boats[(r['name'],id)]=max(boats.get((r['name'],id),0),s['gold'])
   if s['fullGuardSufficientSeconds']>0:suffboats[(r['name'],id)]=max(suffboats.get((r['name'],id),0),s['gold'])
  for e in r['turn']['immediateReturns']:
   events.append(e);quickboats[(r['name'],e['shipId'])]=max(quickboats.get((r['name'],e['shipId']),0),e['shipGold'])
   if e['emptyDestinationBlockedOrigin']:
    signatureevents.append(e);signatureboats[(r['name'],e['shipId'])]=max(signatureboats.get((r['name'],e['shipId']),0),e['shipGold'])
 return dict(observedPlayerSlots=len(rr),guardGames=len(set(r['name']for r in blocked)),guardPlayers=len(blocked),guardSeconds=sum(r['guard']['blockedSeconds']for r in rr),guardShips=len(boats),guardShipGold=sum(boats.values()),sufficientGuardGames=len(set(r['name']for r in sufficient)),sufficientGuardPlayers=len(sufficient),sufficientGuardSeconds=sum(r['guard']['fullGuardSufficientSeconds']for r in rr),sufficientGuardShips=len(suffboats),sufficientGuardShipGold=sum(suffboats.values()),quickReturnGames=len(set(r['name']for r in quick)),quickReturnPlayers=len(quick),quickReturnEvents=len(events),quickReturnShips=len(quickboats),quickReturnShipGold=sum(quickboats.values()),quickReturnAssetRange=[min([e['shipGold']+e['cargoGold']for e in events],default=0),max([e['shipGold']+e['cargoGold']for e in events],default=0)],signatureGames=len(set(r['name']for r in signature)),signatureEvents=len(signatureevents),signatureShips=len(signatureboats),signatureShipGold=sum(signatureboats.values()),signatureAssetRange=[min([e['shipGold']+e['cargoGold']for e in signatureevents],default=0),max([e['shipGold']+e['cargoGold']for e in signatureevents],default=0)],guardNames=sorted(set(r['name']for r in blocked)),sufficientGuardNames=sorted(set(r['name']for r in sufficient)),quickNames=sorted(set(r['name']for r in quick)),signatureNames=sorted(set(r['name']for r in signature)))
out=dict(baselineGames=len(bases),diagnosedGames=len(set(r['name']for r in rows)),purityMismatches=mismatches,ours=summary([r for r in rows if r['role']=='ours']),theirs=summary([r for r in rows if r['role']=='theirs']),bySubject={s:{side:summary([r for r in rows if r['subject']==s and r['role']==side])for side in ('ours','theirs')}for s in sorted(set(r['subject']for r in rows))},examples=[{'name':r['name'],'owner':r['owner'],'version':r['version'],'ship':id,**s}for r in rows if r['role']=='ours'for id,s in r['guard']['ships'].items()if s['fullGuardSufficientSeconds']>0],rows=rows)
print(json.dumps(out,indent=2))
