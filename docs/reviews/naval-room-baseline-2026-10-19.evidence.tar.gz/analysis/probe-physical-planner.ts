import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { setBuildingBodies } from '../../src/shared/terrain';
import { beginShipCollisionFrame, sweepShipCollision } from '../../src/shared/ship-collisions';
import { hullPassageClear } from '../../src/shared/ship-navigation';
import { shipTraffic } from '../../src/shared/ship-avoidance';
import { SHIP_HULL_COST, installedWeapons, SHIP_WEAPONS } from '../../src/shared/ship-equipment';
import { UNIT_DEFS } from '../../src/shared/catalog';
const root='work/naval-analysis/replays', rows=[];
for(const dir of readdirSync(root,{withFileTypes:true}).filter(d=>d.isDirectory()).map(d=>d.name)){
 for(const file of readdirSync(join(root,dir)).filter(f=>/^\d+\.json$/.test(f))){
  const trace=JSON.parse(readFileSync(join(root,dir,file),'utf8')),s=trace.snapshot;
  setBuildingBodies(s.map,s.buildings);beginShipCollisionFrame(s.units,s.map,s.buildings);
  for(const boat of s.units){
   const first=boat.sailing?.route?.points[0];
   if(!first || !['unload','move'].includes(boat.order.type))continue;
   const from={x:boat.x,y:boat.y,heading:boat.sailing.heading};
   if(!hullPassageClear(s.map,boat,from,first)||!shipTraffic(boat,s.units)(from,first))continue;
   const contact=sweepShipCollision(s.map,boat,s.units,from,first);
   if(contact?.kind!=='building'||contact.fraction>1e-7)continue;
   const cargo=s.units.filter((u:any)=>u.deck?.shipId===boat.id);
   rows.push({name:trace.name,frame:`${dir}/${file}`,second:s.tick/20,owner:boat.owner,ship:boat.id,shipKind:boat.kind,x:boat.x,y:boat.y,heading:boat.sailing.heading,speed:boat.sailing.speed,order:boat.order,first,contact:{id:contact.other!.id,kind:contact.kind,fraction:contact.fraction,point:contact.point},shipGold:SHIP_HULL_COST[boat.kind as keyof typeof SHIP_HULL_COST]+installedWeapons(s,boat).reduce((n,item)=>n+SHIP_WEAPONS[item.kind as keyof typeof SHIP_WEAPONS].cost,0),cargoGold:cargo.reduce((n:number,u:any)=>n+UNIT_DEFS[u.kind as keyof typeof UNIT_DEFS].cost,0)});
  }
 }
}
writeFileSync('work/naval-analysis/physical-planner-witnesses.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify({matches:[...new Set(rows.map(r=>r.name))],witnesses:rows.length,examples:rows.slice(0,6)}));
