"""Compare the same physical seat across the two mirrored team assignments."""
import collections, json, pathlib, statistics, sys
groups=collections.defaultdict(list)
for path in pathlib.Path(sys.argv[1]).glob('*_vs-*.json'):
 report=json.loads(path.read_text());groups[' '.join(report['name'].split()[:3])].append(report)
output={}
for key in ('firstLandingSecond','firstMilitaryLandingSecond'):
 rows=[]
 for pair in groups.values():
  assert len(pair)==2
  one,two=pair
  for owner in one['setup']['players']:
   ours,rival=(one,two)if one['setup']['players'][owner]['team']==one['naval']['subjectTeam']else(two,one)
   rows.append({'owner':owner,'oursGame':ours['name'],'rivalGame':rival['name'],'ours':ours['result']['trackers']['naval'][owner][key],'rival':rival['result']['trackers']['naval'][owner][key]})
 deltas=[r['ours']-r['rival']for r in rows if r['ours']is not None and r['rival']is not None]
 output[key]={'pairs':len(rows),'bothOccurred':len(deltas),'medianRoomMinusRivalSeconds':statistics.median(deltas)if deltas else None,'roomOnly':sum(r['ours']is not None and r['rival']is None for r in rows),'rivalOnly':sum(r['ours']is None and r['rival']is not None for r in rows),'neither':sum(r['ours']is None and r['rival']is None for r in rows),'roomSlowerAtLeast60':sum(d>=60 for d in deltas),'rivalSlowerAtLeast60':sum(d<=-60 for d in deltas),'rows':rows}
print(json.dumps(output,indent=2))
