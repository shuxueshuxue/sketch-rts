import pathlib,json,sys
base=pathlib.Path(sys.argv[1]);diag=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
probes={}
for p in diag.glob('*_vs-*.json'):
 r=json.loads(p.read_text())
 if 'navalFerries'in r['result']['trackers']:probes[r['name']]=r
missing=[];changed=[];merged=0;zeros=0
for p in base.glob('*_vs-*.json'):
 r=json.loads(p.read_text());probe=probes.get(r['name']);hasShips=any(s['ships']for s in r['result']['trackers']['naval'].values())
 if probe:
  different=[k for k in ('tick','winnerTeam','timeout','players')if r['result'][k]!=probe['result'][k]]
  if different:changed.append({'name':r['name'],'fields':different});continue
  for owner,f in probe['result']['trackers']['navalFerries'].items():
   r['result']['trackers']['naval'][owner].update({k:f[k]for k in ('firstLandingSecond','firstMilitaryLandingSecond','deliveries','roundTrips','landings')})
  r['measurementRevision']={'ferrySchema':2,'source':'cf057afa','meaning':'A real crossing requires a different land component from the passenger boarding origin; a round trip also requires the hull to leave and return to the loading area.'};merged+=1
 elif hasShips:missing.append(r['name']);continue
 else:r['measurementRevision']={'ferrySchema':2,'reason':'No ships existed; ferry measures are zero/null.'};zeros+=1
 (out/p.name).write_text(json.dumps(r,separators=(',',':'))+'\n')
print(json.dumps({'merged':merged,'noShipGames':zeros,'missing':missing,'changed':changed},indent=2))
