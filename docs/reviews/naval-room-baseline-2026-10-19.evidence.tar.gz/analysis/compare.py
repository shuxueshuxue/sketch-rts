import pathlib,json,collections,statistics,sys
root=pathlib.Path(sys.argv[1]); rows=[]
for p in root.glob('*.json'):
 if p.name in ('report.json','manifest.json'):continue
 r=json.loads(p.read_text()); sides={True:[],False:[]}
 for owner,s in r['result']['trackers']['naval'].items():sides[r['setup']['players'][owner]['team']==r['naval']['subjectTeam']].append(s)
 def side(ss):
  land=[s['firstLandingSecond'] for s in ss if s['firstLandingSecond'] is not None];mil=[s['firstMilitaryLandingSecond'] for s in ss if s['firstMilitaryLandingSecond'] is not None]
  ck={m:{key:sum(s['checkpoints'][m][key]for s in ss if m in s['checkpoints'])for key in ('islandBases','islandMines','islandGold')}for m in ('5','10','15','20','30','40')if all(m in s['checkpoints']for s in ss)}
  return dict(firstLanding=min(land)if land else None,firstMilitary=min(mil)if mil else None,checkpoints=ck,lostGold=sum(s['lostGold']for s in ss),idleSeconds=sum(s['idleShipSeconds']for s in ss),stallSeconds=sum(s['stalledShipSeconds']for s in ss),shipSeconds=sum(s['shipSeconds']for s in ss),deliveries=sum(s['deliveries']for s in ss),roundTrips=sum(s['roundTrips']for s in ss),failedLongPlanPlayers=sum(any(p['completedSecond']is None and p['lastSeenSecond']-p['startSecond']>=180 for p in s['plans'])for s in ss),sameGroundUnloads=sum(not l['crossed']for s in ss for l in s['landings']),stallGold=sum(z['gold']for s in ss for z in s['ships']if z['stalledSeconds']>=120),ferries=[{**z,'owner':owner}for owner,s in r['result']['trackers']['naval'].items()if (r['setup']['players'][owner]['team']==r['naval']['subjectTeam'])==(ss is sides[True])for z in s['ships']if z['kind']in('transport','carrier')])
 a,b=side(sides[True]),side(sides[False]);rows.append(dict(name=r['name'],subject=r['naval']['subject'],rival=r['naval']['rival'],winner=r['result']['winnerTeam'],won=r['result']['winnerTeam']==r['naval']['subjectTeam'],timeout=r['result']['timeout'],duration=r['result']['gameSecond'],ours=a,theirs=b))
def total(rr):
 out={'games':len(rr),'wins':sum(r['won']for r in rr),'timeouts':sum(r['timeout']for r in rr)}
 for side in ('ours','theirs'):
  ss=[r[side]for r in rr]; out[side]={key:sum(s[key]for s in ss)for key in ('lostGold','idleSeconds','stallSeconds','shipSeconds','deliveries','roundTrips','failedLongPlanPlayers','sameGroundUnloads','stallGold')}
  for minute in ('5','10','15','20','30','40'):
   vv=[s['checkpoints'][minute]for s in ss if minute in s['checkpoints']];out[side]['at'+minute]={'games':len(vv),**{key:sum(v[key]for v in vv)for key in ('islandBases','islandMines','islandGold')}}
  for k in ('firstLanding','firstMilitary'):
   vv=[s[k]for s in ss if s[k]is not None];out[side][k]={'games':len(vv),'median':statistics.median(vv)if vv else None,'by15':sum(v<=900 for v in vv)}
 deficits=[];late=[];trade=[]
 for r in rr:
  a,b=r['ours'],r['theirs']
  if '15'in a['checkpoints']and'15'in b['checkpoints']and a['checkpoints']['15']['islandMines']<b['checkpoints']['15']['islandMines']:deficits.append(r)
  if b['firstMilitary']is not None and(a['firstMilitary']is None or a['firstMilitary']>b['firstMilitary']+60):late.append(r)
  if a['lostGold']>b['lostGold']:trade.append(r)
 out.update(resourceDeficitGames=len(deficits),resourceDeficitNames=[r['name']for r in deficits],resourceGoldGaps=[r['theirs']['checkpoints']['15']['islandGold']-r['ours']['checkpoints']['15']['islandGold']for r in deficits],militaryLateGames=len(late),militaryLateNames=[r['name']for r in late],negativeExchangeGames=len(trade),negativeExchangeNames=[r['name']for r in trade],negativeExchangeGold=[r['ours']['lostGold']-r['theirs']['lostGold']for r in trade])
 return out
print(json.dumps({'aggregate':total(rows),'bySubject':{s:total([r for r in rows if r['subject']==s])for s in sorted(set(r['subject']for r in rows))},'byMap':{m:total([r for r in rows if r['name'].startswith(m+' ')])for m in sorted(set(r['name'].split()[0]for r in rows))},'games':rows},indent=2))
