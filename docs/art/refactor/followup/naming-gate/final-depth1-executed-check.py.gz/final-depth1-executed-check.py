#!/usr/bin/env python3
"""Run the original single test once, preserving source identity and raw output."""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
from datetime import datetime, timezone

ROOT = Path('/workspace/sketch-rts-viewport')
STORE = ROOT / 'docs/art/refactor/followup/naming-gate'
PREFIX = 'final-depth1'
SOURCE = 'cc854814473bb684e4444eb69719b9978b6dbdc6'
DOCS = '4e7e5e812520e8f12cb959221e39430e3546f7e5'
TEST = 'src/sdk/package-boundaries.test.ts'
TEST_SHA = '12931b604317c88478ed560b3e577b0e9335a67c6c0d295b81b3c4ef8b2016ad'

def sha(value):
    return hashlib.sha256(value).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

def freeze():
    return {
        'head': git('rev-parse', 'HEAD'),
        'sourceCommit': SOURCE,
        'productionDocsCommit': DOCS,
        'sourceStatus': git('status', '--porcelain', '--untracked-files=all', '--', 'src', 'public'),
        'sourceDiffAgainstProduction': git('diff', SOURCE, '--', 'src', 'public'),
        'sourceDiffAgainstProductionDocs': git('diff', DOCS, '--', 'src', 'public'),
        'sourceTrees': {ref: git('rev-parse', ref + ':src') for ref in ('HEAD', SOURCE, DOCS)},
        'publicTrees': {ref: git('rev-parse', ref + ':public') for ref in ('HEAD', SOURCE, DOCS)},
        'testSourceSha256': sha((ROOT / TEST).read_bytes()),
    }

def clean(value):
    return (not value['sourceStatus'] and not value['sourceDiffAgainstProduction']
            and not value['sourceDiffAgainstProductionDocs']
            and len(set(value['sourceTrees'].values())) == 1
            and len(set(value['publicTrees'].values())) == 1
            and value['testSourceSha256'] == TEST_SHA)

def save(name, value):
    with (STORE / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

targets = [PREFIX + suffix for suffix in ('-single-test.log.gz', '-validation.json', '-source-freeze.json', '-executed-check.py.gz')]
if any((STORE / name).exists() for name in targets):
    raise RuntimeError('Exclusive outputs already exist; do not rerun or overwrite')
baseline = json.loads((STORE / 'final-replay-generation-validation.json').read_text())['remainingOriginalBaselinePaths']
if len(baseline) != 22:
    raise RuntimeError('Expected original 22-path baseline')
before = freeze()
if not clean(before):
    save(PREFIX + '-source-freeze.json', {'before': before, 'testStarted': False})
    raise RuntimeError('Source/test guard failed before any single test')
started = datetime.now(timezone.utc).isoformat()
scratch = Path(tempfile.mkdtemp(prefix='art-depth1-final-naming-'))
raw_path = scratch / 'single-test.log'
with raw_path.open('xb') as stream:
    completed = subprocess.run(['npx', 'vitest', 'run', TEST], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
after = freeze()
raw = raw_path.read_bytes()
packed = gzip.compress(raw, compresslevel=9, mtime=0)
if gzip.decompress(packed) != raw:
    raise RuntimeError('Independent raw output roundtrip failed')
with (STORE / targets[0]).open('xb') as stream:
    stream.write(packed)
executed = Path(__file__).read_bytes()
executed_packed = gzip.compress(executed, compresslevel=9, mtime=0)
if gzip.decompress(executed_packed) != executed:
    raise RuntimeError('Executed-check roundtrip failed')
with (STORE / targets[3]).open('xb') as stream:
    stream.write(executed_packed)
text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw.decode('utf8'))
actual = re.findall(r'^\+\s+"([^"]+)",?\s*$', text, re.M)
totals = re.search(r'\bTests\s+(\d+) failed\s*\|\s*(\d+) passed\s*\((\d+)\)', text)
duration = re.search(r'\bDuration\s+([\d.]+)s', text)
exact = actual == baseline
new = [name for name in actual if name not in baseline]
state_same = clean(after) and before == after
save(targets[2], {'before': before, 'after': after, 'sourceUnchanged': state_same,
                 'startedUtc': started, 'finishedUtc': datetime.now(timezone.utc).isoformat()})
report = {
    'command': 'npx vitest run ' + TEST,
    'exitCode': completed.returncode,
    'testsFailed': int(totals[1]) if totals else None,
    'testsPassed': int(totals[2]) if totals else None,
    'durationSeconds': float(duration[1]) if duration else None,
    'offenderCount': len(actual),
    'sameExactBaselineOffenderPaths': exact,
    'newEvidenceOffenderCount': len(new),
    'newEvidencePathsUtf8Base64': [base64.b64encode(p.encode()).decode() for p in new],
    'remainingOriginalBaselinePaths': [p for p in actual if p in baseline],
    'originalTestSourceSha256Unchanged': before['testSourceSha256'],
    'sourceCommit': SOURCE,
    'productionDocsCommit': DOCS,
    'sourceStatusAndDiffBeforeAndAfterTestClean': state_same,
    'rawLog': {'file': targets[0], 'originalBytes': len(raw), 'originalSha256': sha(raw),
               'gzipBytes': len(packed), 'gzipSha256': sha(packed), 'decodedBytesExactlyEqual': True},
    'sourceFreezeProof': targets[2],
    'executedCheck': {'file': targets[3], 'originalBytes': len(executed), 'originalSha256': sha(executed),
                      'gzipBytes': len(executed_packed), 'gzipSha256': sha(executed_packed),
                      'decodedBytesExactlyEqual': True},
    'meaning': 'Actual original single test after depth-one artifacts packaged; original baseline failure retained. Not an all-green or performance claim.',
}
save(targets[1], report)
raw_path.unlink()
scratch.rmdir()
print(json.dumps({key: report[key] for key in ('exitCode', 'testsPassed', 'testsFailed', 'offenderCount', 'sameExactBaselineOffenderPaths', 'newEvidenceOffenderCount', 'sourceStatusAndDiffBeforeAndAfterTestClean')}))
raise SystemExit(0 if completed.returncode == 1 and totals and int(totals[1]) == 1 and int(totals[2]) == 6 and exact and state_same else 1)
