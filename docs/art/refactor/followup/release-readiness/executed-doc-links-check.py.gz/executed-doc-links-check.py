import json,pathlib,re,urllib.parse,datetime,hashlib
root=pathlib.Path('/workspace/sketch-rts-viewport')
changed=json.load(open('/tmp/sketch-release-link-edits.json'))
docs=[entry['path'] for entry in changed]+['docs/art/refactor/followup/release-readiness/README.md']
# Verify only local destinations in prose; commands stay byte-identical.
pattern=re.compile(r'!?\[[^\]\n]*\]\((<[^>\n]+>|[^\s)]+)(?:\s+[^)\n]*)?\)')
rows=[];missing=[]
for name in docs:
 p=root/name
 if not p.exists():
  missing.append({'document':name,'reason':'document missing'});continue
 original=p.read_text();fence=None;prose=[]
 for line in original.splitlines(keepends=True):
  fence_match=re.match(r'^\s*(`{3,}|~{3,})',line)
  if fence_match:
   mark=fence_match.group(1)[0]
   fence=None if fence==mark else mark if fence is None else fence
   continue
  if fence is None:prose.append(line)
 text=''.join(prose);count=0
 for m in pattern.finditer(text):
  href=m.group(1).strip('<>'); parts=urllib.parse.urlsplit(href)
  if parts.scheme or parts.netloc or href.startswith('#'):continue
  path=urllib.parse.unquote(parts.path)
  if not path:continue
  dest=(root/path.lstrip('/')) if path.startswith('/') else p.parent/path
  count+=1
  if not dest.exists():missing.append({'document':name,'href':href,'resolved':str(dest.resolve())})
 rows.append({'document':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'localLinksChecked':count})
report={'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only local Markdown destination existence check for six adjusted maintained documents and release-readiness README only; no runtime tests, browser, source or captured evidence mutation. Fenced commands and external URLs excluded; fragment targets not validated.','documents':rows,'localLinksChecked':sum(r['localLinksChecked'] for r in rows),'missingLocalLinks':missing,'passed':not missing}
pathlib.Path('/tmp/sketch-release-links-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if not missing else 1)
