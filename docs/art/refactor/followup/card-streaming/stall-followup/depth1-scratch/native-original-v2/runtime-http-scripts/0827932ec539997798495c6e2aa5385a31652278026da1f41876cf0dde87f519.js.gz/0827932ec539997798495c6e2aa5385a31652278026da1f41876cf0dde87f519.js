import { createScratchCanvas } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/scratch-canvas.ts";
export const ART_TILE_SIZE = 128;
export const ART_ACTION_SIZE = 176;
export class RasterCache {
  constructor(budget = 12 * 1024 * 1024, limit = 1024) {
    this.budget = budget;
    this.limit = limit;
  }
  entries = /* @__PURE__ */ new Map();
  scratch = [];
  spare = [];
  retired = [];
  depth = 0;
  leased = /* @__PURE__ */ new Set();
  epoch = 0;
  pixels = 0;
  hits = 0;
  misses = 0;
  evictions = 0;
  get(key, density, paint, tileSize = ART_TILE_SIZE) {
    if (!this.depth) this.recycleRetired();
    const id = `${key}:${density}:${tileSize}`;
    const cached = this.entries.get(id);
    if (cached) {
      this.hits++;
      this.entries.delete(id);
      this.entries.set(id, cached);
      return cached;
    }
    this.misses++;
    const origin = tileSize / 2, size = tileSize * density;
    const epoch = this.epoch, source = this.take(this.scratch, size, size);
    this.leased.add(source);
    const brush = this.reset(source, true);
    brush.scale(density, density);
    brush.translate(origin, origin);
    brush.lineJoin = brush.lineCap = "round";
    this.depth++;
    try {
      paint(brush);
      const rgba = brush.getImageData(0, 0, size, size).data;
      let left = size, top = size, right = -1, bottom = -1;
      for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
        if (rgba[(y * size + x) * 4 + 3]) {
          if (x < left) left = x;
          if (x > right) right = x;
          if (y < top) top = y;
          if (y > bottom) bottom = y;
        }
      }
      if (right < left) {
        left = top = 0;
        right = bottom = 0;
      }
      left = Math.max(0, left - 2);
      top = Math.max(0, top - 2);
      right = Math.min(size - 1, right + 2);
      bottom = Math.min(size - 1, bottom + 2);
      const canvas = this.take(this.spare, right - left + 1, bottom - top + 1);
      this.reset(canvas).drawImage(source, left, top, canvas.width, canvas.height, 0, 0, canvas.width, canvas.height);
      const result = { canvas, x: left / density - origin, y: top / density - origin, density };
      const cost = canvas.width * canvas.height;
      while (epoch === this.epoch && cost <= this.budget && this.entries.size && (this.entries.size >= this.limit || this.pixels + cost > this.budget)) {
        const oldest = this.entries.keys().next().value;
        const old = this.entries.get(oldest);
        this.pixels -= old.canvas.width * old.canvas.height;
        this.entries.delete(oldest);
        this.evictions++;
        this.retired.push(old.canvas);
      }
      if (epoch === this.epoch && cost <= this.budget) {
        this.entries.set(id, result);
        this.pixels += cost;
      } else this.retired.push(canvas);
      return result;
    } finally {
      this.depth--;
      this.leased.delete(source);
      if (epoch === this.epoch) this.put(this.scratch, source, 4, 4 * 1024 * 1024);
      else this.release(source);
    }
  }
  take(pool, width, height) {
    const index = pool.findIndex((canvas) => canvas.width === width && canvas.height === height);
    return index < 0 ? createScratchCanvas(width, height) : pool.splice(index, 1)[0];
  }
  reset(canvas, read = false) {
    const ctx = canvas.getContext("2d", read ? { willReadFrequently: true } : void 0);
    if (typeof ctx.reset === "function") ctx.reset();
    else canvas.width = canvas.width;
    return ctx;
  }
  release(canvas) {
    canvas.width = 1;
    canvas.height = 1;
  }
  put(pool, canvas, limit, budget) {
    const cost = canvas.width * canvas.height;
    if (cost > budget) {
      this.release(canvas);
      return;
    }
    while (pool.length && (pool.length >= limit || pool.reduce((sum, c) => sum + c.width * c.height, 0) + cost > budget)) this.release(pool.shift());
    pool.push(canvas);
  }
  recycleRetired() {
    for (const canvas of this.retired) this.put(this.spare, canvas, 8, 1024 * 1024);
    this.retired.length = 0;
  }
  stats() {
    const pixels = (canvases) => {
      let sum = 0;
      for (const canvas of canvases) sum += canvas.width * canvas.height;
      return sum;
    };
    const scratchPixels = pixels(this.scratch), sparePixels = pixels(this.spare), retiredPixels = pixels(this.retired), leasedPixels = pixels(this.leased);
    return {
      entries: this.entries.size,
      pixels: this.pixels,
      bytes: this.pixels * 4,
      hits: this.hits,
      misses: this.misses,
      evictions: this.evictions,
      scratchCanvases: this.scratch.length,
      scratchPixels,
      scratchBytes: scratchPixels * 4,
      spareCanvases: this.spare.length,
      sparePixels,
      spareBytes: sparePixels * 4,
      retiredCanvases: this.retired.length,
      retiredPixels,
      retiredBytes: retiredPixels * 4,
      leasedCanvases: this.leased.size,
      leasedPixels,
      leasedBytes: leasedPixels * 4,
      ownedCanvasBytes: (this.pixels + scratchPixels + sparePixels + retiredPixels + leasedPixels) * 4
    };
  }
  clear() {
    this.epoch++;
    for (const canvas of [...this.entries.values()].map((value) => value.canvas).concat(this.scratch, this.spare, this.retired)) this.release(canvas);
    this.entries.clear();
    this.scratch.length = this.spare.length = this.retired.length = 0;
    this.pixels = 0;
    this.hits = this.misses = this.evictions = 0;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJhc3Rlci1jYWNoZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVTY3JhdGNoQ2FudmFzIH0gZnJvbSAnLi9zY3JhdGNoLWNhbnZhcyc7XG5cbmV4cG9ydCBjb25zdCBBUlRfVElMRV9TSVpFPTEyODtcbmV4cG9ydCBjb25zdCBBUlRfQUNUSU9OX1NJWkU9MTc2O1xuXG50eXBlIFJhc3RlciA9IHsgY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudDsgeDogbnVtYmVyOyB5OiBudW1iZXI7IGRlbnNpdHk6IG51bWJlciB9O1xuXG4vKiogS2VlcCB0aGUgYXV0aG9yZWQgcmVzb2x1dGlvbiBhbmQgYW5jaG9yLCBidXQgcmV0YWluIG9ubHkgcGFpbnRlZCBwaXhlbHMuXG4gKiBCb3VuZGVkIHdvcmstc3VyZmFjZSBhbmQgY3JvcCBwb29scyByZXVzZSBiYWNraW5nIHN0b3JlcyBhY3Jvc3MgY2FjaGUgbWlzc2VzLlxuICogUmV0dXJuZWQgcmFzdGVycyBhcmUgYm9ycm93ZWQgZm9yIGltbWVkaWF0ZSBkcmF3aW5nLCB1bnRpbCB0aGUgbmV4dCB0b3AtbGV2ZWxcbiAqIGdldCgpIG9yIGNsZWFyKCk7IG5lc3RlZCBwYWludGVycyBrZWVwIHRoZWlyIGJvcnJvd2VkIHJhc3RlcnMgdW50aWwgdGhleSByZXR1cm4uXG4gKiBUcmFuc3BhcmVudCBwYWRkaW5nIGlzIG5vdCBwYXJ0IG9mIHRoZSByZXRhaW5lZCBlbnRyeSBidWRnZXQuICovXG5leHBvcnQgY2xhc3MgUmFzdGVyQ2FjaGUge1xuICBwcml2YXRlIGVudHJpZXMgPSBuZXcgTWFwPHN0cmluZywgUmFzdGVyPigpO1xuICBwcml2YXRlIHNjcmF0Y2g6IEhUTUxDYW52YXNFbGVtZW50W10gPSBbXTtcbiAgcHJpdmF0ZSBzcGFyZTogSFRNTENhbnZhc0VsZW1lbnRbXSA9IFtdO1xuICBwcml2YXRlIHJldGlyZWQ6IEhUTUxDYW52YXNFbGVtZW50W10gPSBbXTtcbiAgcHJpdmF0ZSBkZXB0aCA9IDA7XG4gIHByaXZhdGUgbGVhc2VkID0gbmV3IFNldDxIVE1MQ2FudmFzRWxlbWVudD4oKTtcbiAgcHJpdmF0ZSBlcG9jaCA9IDA7XG4gIHByaXZhdGUgcGl4ZWxzID0gMDtcblxuICBwcml2YXRlIGhpdHMgPSAwO1xuICBwcml2YXRlIG1pc3NlcyA9IDA7XG4gIHByaXZhdGUgZXZpY3Rpb25zID0gMDtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBidWRnZXQgPSAxMiAqIDEwMjQgKiAxMDI0LCBwcml2YXRlIGxpbWl0ID0gMTAyNCkge31cblxuICBnZXQoa2V5OiBzdHJpbmcsIGRlbnNpdHk6IG51bWJlciwgcGFpbnQ6IChicnVzaDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJEKSA9PiB2b2lkLCB0aWxlU2l6ZTpudW1iZXI9QVJUX1RJTEVfU0laRSk6IFJhc3RlciB7XG4gICAgaWYoIXRoaXMuZGVwdGgpdGhpcy5yZWN5Y2xlUmV0aXJlZCgpO1xuICAgIGNvbnN0IGlkID0gYCR7a2V5fToke2RlbnNpdHl9OiR7dGlsZVNpemV9YDtcbiAgICBjb25zdCBjYWNoZWQgPSB0aGlzLmVudHJpZXMuZ2V0KGlkKTtcbiAgICBpZiAoY2FjaGVkKSB7XG4gICAgICB0aGlzLmhpdHMrKztcbiAgICAgIHRoaXMuZW50cmllcy5kZWxldGUoaWQpOyB0aGlzLmVudHJpZXMuc2V0KGlkLCBjYWNoZWQpO1xuICAgICAgcmV0dXJuIGNhY2hlZDtcbiAgICB9XG4gICAgdGhpcy5taXNzZXMrKztcbiAgICBjb25zdCBvcmlnaW49dGlsZVNpemUvMixzaXplID0gdGlsZVNpemUgKiBkZW5zaXR5O1xuICAgIGNvbnN0IGVwb2NoPXRoaXMuZXBvY2gsc291cmNlPXRoaXMudGFrZSh0aGlzLnNjcmF0Y2gsc2l6ZSxzaXplKTtcbiAgICB0aGlzLmxlYXNlZC5hZGQoc291cmNlKTtcbiAgICBjb25zdCBicnVzaD10aGlzLnJlc2V0KHNvdXJjZSx0cnVlKTtcbiAgICBicnVzaC5zY2FsZShkZW5zaXR5LGRlbnNpdHkpO2JydXNoLnRyYW5zbGF0ZShvcmlnaW4sb3JpZ2luKTtcbiAgICBicnVzaC5saW5lSm9pbj1icnVzaC5saW5lQ2FwPSdyb3VuZCc7XG4gICAgdGhpcy5kZXB0aCsrO1xuICAgIHRyeSB7XG4gICAgICBwYWludChicnVzaCk7XG4gICAgICBjb25zdCByZ2JhID0gYnJ1c2guZ2V0SW1hZ2VEYXRhKDAsIDAsIHNpemUsIHNpemUpLmRhdGE7XG4gICAgICBsZXQgbGVmdCA9IHNpemUsIHRvcCA9IHNpemUsIHJpZ2h0ID0gLTEsIGJvdHRvbSA9IC0xO1xuICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCBzaXplOyB5KyspIGZvciAobGV0IHggPSAwOyB4IDwgc2l6ZTsgeCsrKSB7XG4gICAgICAgIGlmIChyZ2JhWyh5ICogc2l6ZSArIHgpICogNCArIDNdKSB7XG4gICAgICAgICAgaWYgKHggPCBsZWZ0KSBsZWZ0ID0geDsgaWYgKHggPiByaWdodCkgcmlnaHQgPSB4O1xuICAgICAgICAgIGlmICh5IDwgdG9wKSB0b3AgPSB5OyBpZiAoeSA+IGJvdHRvbSkgYm90dG9tID0geTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHJpZ2h0IDwgbGVmdCkgeyBsZWZ0ID0gdG9wID0gMDsgcmlnaHQgPSBib3R0b20gPSAwOyB9XG4gICAgICAvLyBUd28gY2xlYXIgdGV4ZWxzIHByZXNlcnZlIGJpbGluZWFyIGZpbHRlcmluZyBhdCB0aGUgb3JpZ2luYWwgY3V0b3V0IGVkZ2UuXG4gICAgICBsZWZ0ID0gTWF0aC5tYXgoMCwgbGVmdCAtIDIpOyB0b3AgPSBNYXRoLm1heCgwLCB0b3AgLSAyKTtcbiAgICAgIHJpZ2h0ID0gTWF0aC5taW4oc2l6ZSAtIDEsIHJpZ2h0ICsgMik7IGJvdHRvbSA9IE1hdGgubWluKHNpemUgLSAxLCBib3R0b20gKyAyKTtcbiAgICAgIGNvbnN0IGNhbnZhcyA9IHRoaXMudGFrZSh0aGlzLnNwYXJlLHJpZ2h0LWxlZnQrMSxib3R0b20tdG9wKzEpO1xuICAgICAgdGhpcy5yZXNldChjYW52YXMpLmRyYXdJbWFnZShzb3VyY2UsbGVmdCx0b3AsY2FudmFzLndpZHRoLGNhbnZhcy5oZWlnaHQsMCwwLGNhbnZhcy53aWR0aCxjYW52YXMuaGVpZ2h0KTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHsgY2FudmFzLCB4OiBsZWZ0IC8gZGVuc2l0eSAtIG9yaWdpbiwgeTogdG9wIC8gZGVuc2l0eSAtIG9yaWdpbiwgZGVuc2l0eSB9O1xuICAgICAgY29uc3QgY29zdCA9IGNhbnZhcy53aWR0aCAqIGNhbnZhcy5oZWlnaHQ7XG4gICAgICB3aGlsZSAoZXBvY2g9PT10aGlzLmVwb2NoICYmIGNvc3Q8PXRoaXMuYnVkZ2V0ICYmIHRoaXMuZW50cmllcy5zaXplICYmICh0aGlzLmVudHJpZXMuc2l6ZSA+PSB0aGlzLmxpbWl0IHx8IHRoaXMucGl4ZWxzICsgY29zdCA+IHRoaXMuYnVkZ2V0KSkge1xuICAgICAgICBjb25zdCBvbGRlc3QgPSB0aGlzLmVudHJpZXMua2V5cygpLm5leHQoKS52YWx1ZSE7XG4gICAgICAgIGNvbnN0IG9sZCA9IHRoaXMuZW50cmllcy5nZXQob2xkZXN0KSE7XG4gICAgICAgIHRoaXMucGl4ZWxzIC09IG9sZC5jYW52YXMud2lkdGggKiBvbGQuY2FudmFzLmhlaWdodDtcbiAgICAgICAgdGhpcy5lbnRyaWVzLmRlbGV0ZShvbGRlc3QpOyB0aGlzLmV2aWN0aW9ucysrO3RoaXMucmV0aXJlZC5wdXNoKG9sZC5jYW52YXMpO1xuICAgICAgfVxuICAgICAgLy8gQW4gb3ZlcnNpemVkIG9uZS1vZmYgaW1hZ2UgaXMgc3RpbGwgZHJhd24sIHdpdGhvdXQgZGlzcGxhY2luZyB0aGUgYnVkZ2V0XG4gICAgICAvLyBpbmRlZmluaXRlbHkgb3IgcHJldGVuZGluZyBpdCBpcyBhIHJldGFpbmVkIGNhY2hlIGVudHJ5LlxuICAgICAgaWYgKGVwb2NoPT09dGhpcy5lcG9jaCAmJiBjb3N0IDw9IHRoaXMuYnVkZ2V0KSB7IHRoaXMuZW50cmllcy5zZXQoaWQsIHJlc3VsdCk7IHRoaXMucGl4ZWxzICs9IGNvc3Q7IH1cbiAgICAgIGVsc2UgdGhpcy5yZXRpcmVkLnB1c2goY2FudmFzKTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuZGVwdGgtLTtcbiAgICAgIHRoaXMubGVhc2VkLmRlbGV0ZShzb3VyY2UpO1xuICAgICAgaWYoZXBvY2g9PT10aGlzLmVwb2NoKXRoaXMucHV0KHRoaXMuc2NyYXRjaCxzb3VyY2UsNCw0KjEwMjQqMTAyNCk7ZWxzZSB0aGlzLnJlbGVhc2Uoc291cmNlKTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSB0YWtlKHBvb2w6SFRNTENhbnZhc0VsZW1lbnRbXSx3aWR0aDpudW1iZXIsaGVpZ2h0Om51bWJlcil7XG4gICAgY29uc3QgaW5kZXg9cG9vbC5maW5kSW5kZXgoY2FudmFzPT5jYW52YXMud2lkdGg9PT13aWR0aCYmY2FudmFzLmhlaWdodD09PWhlaWdodCk7XG4gICAgcmV0dXJuIGluZGV4PDA/Y3JlYXRlU2NyYXRjaENhbnZhcyh3aWR0aCxoZWlnaHQpOnBvb2wuc3BsaWNlKGluZGV4LDEpWzBdITtcbiAgfVxuICBwcml2YXRlIHJlc2V0KGNhbnZhczpIVE1MQ2FudmFzRWxlbWVudCxyZWFkPWZhbHNlKXtcbiAgICBjb25zdCBjdHg9Y2FudmFzLmdldENvbnRleHQoJzJkJyxyZWFkP3t3aWxsUmVhZEZyZXF1ZW50bHk6dHJ1ZX06dW5kZWZpbmVkKSE7XG4gICAgLy8gcmVzZXQgY2xlYXJzIHBpeGVscywgY2xpcHMsIHRoZSBjdXJyZW50IHBhdGggYW5kIHRoZSBlbnRpcmUgc2F2ZSBzdGFjay5cbiAgICAvLyBPbGRlciBicm93c2VyIGNvbnRleHRzIHVzZSBvbmUgZGltZW5zaW9uIGFzc2lnbm1lbnQgZm9yIHRoZSBzYW1lIHNlbWFudGljcy5cbiAgICBpZih0eXBlb2YgY3R4LnJlc2V0PT09J2Z1bmN0aW9uJyljdHgucmVzZXQoKTtlbHNlIGNhbnZhcy53aWR0aD1jYW52YXMud2lkdGg7XG4gICAgcmV0dXJuIGN0eDtcbiAgfVxuICBwcml2YXRlIHJlbGVhc2UoY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXtjYW52YXMud2lkdGg9MTtjYW52YXMuaGVpZ2h0PTE7fVxuICBwcml2YXRlIHB1dChwb29sOkhUTUxDYW52YXNFbGVtZW50W10sY2FudmFzOkhUTUxDYW52YXNFbGVtZW50LGxpbWl0Om51bWJlcixidWRnZXQ6bnVtYmVyKXtcbiAgICBjb25zdCBjb3N0PWNhbnZhcy53aWR0aCpjYW52YXMuaGVpZ2h0O1xuICAgIGlmKGNvc3Q+YnVkZ2V0KXt0aGlzLnJlbGVhc2UoY2FudmFzKTtyZXR1cm47fVxuICAgIHdoaWxlKHBvb2wubGVuZ3RoJiYocG9vbC5sZW5ndGg+PWxpbWl0fHxwb29sLnJlZHVjZSgoc3VtLGMpPT5zdW0rYy53aWR0aCpjLmhlaWdodCwwKStjb3N0PmJ1ZGdldCkpdGhpcy5yZWxlYXNlKHBvb2wuc2hpZnQoKSEpO1xuICAgIHBvb2wucHVzaChjYW52YXMpO1xuICB9XG4gIHByaXZhdGUgcmVjeWNsZVJldGlyZWQoKXtcbiAgICAvLyBBIHBhcmVudCBwYWludGVyIG1heSBzdGlsbCB1c2UgYSBuZXN0ZWQgcmVzdWx0LiBSZXRpcmUgb25seSBiZXR3ZWVuXG4gICAgLy8gdG9wLWxldmVsIHJlcXVlc3RzLCBhZnRlciB0aGUgcHJlY2VkaW5nIHJlc3VsdCBoYXMgYmVlbiBkcmF3biBieSBpdHMgY2FsbGVyLlxuICAgIGZvcihjb25zdCBjYW52YXMgb2YgdGhpcy5yZXRpcmVkKXRoaXMucHV0KHRoaXMuc3BhcmUsY2FudmFzLDgsMTAyNCoxMDI0KTtcbiAgICB0aGlzLnJldGlyZWQubGVuZ3RoPTA7XG4gIH1cbiAgc3RhdHMoKSB7XG4gICAgY29uc3QgcGl4ZWxzPShjYW52YXNlczpJdGVyYWJsZTxIVE1MQ2FudmFzRWxlbWVudD4pPT57bGV0IHN1bT0wO2Zvcihjb25zdCBjYW52YXMgb2YgY2FudmFzZXMpc3VtKz1jYW52YXMud2lkdGgqY2FudmFzLmhlaWdodDtyZXR1cm4gc3VtO307XG4gICAgY29uc3Qgc2NyYXRjaFBpeGVscz1waXhlbHModGhpcy5zY3JhdGNoKSxzcGFyZVBpeGVscz1waXhlbHModGhpcy5zcGFyZSkscmV0aXJlZFBpeGVscz1waXhlbHModGhpcy5yZXRpcmVkKSxsZWFzZWRQaXhlbHM9cGl4ZWxzKHRoaXMubGVhc2VkKTtcbiAgICByZXR1cm4ge2VudHJpZXM6dGhpcy5lbnRyaWVzLnNpemUscGl4ZWxzOnRoaXMucGl4ZWxzLGJ5dGVzOnRoaXMucGl4ZWxzKjQsaGl0czp0aGlzLmhpdHMsbWlzc2VzOnRoaXMubWlzc2VzLGV2aWN0aW9uczp0aGlzLmV2aWN0aW9ucyxcbiAgICAgIHNjcmF0Y2hDYW52YXNlczp0aGlzLnNjcmF0Y2gubGVuZ3RoLHNjcmF0Y2hQaXhlbHMsc2NyYXRjaEJ5dGVzOnNjcmF0Y2hQaXhlbHMqNCxcbiAgICAgIHNwYXJlQ2FudmFzZXM6dGhpcy5zcGFyZS5sZW5ndGgsc3BhcmVQaXhlbHMsc3BhcmVCeXRlczpzcGFyZVBpeGVscyo0LFxuICAgICAgcmV0aXJlZENhbnZhc2VzOnRoaXMucmV0aXJlZC5sZW5ndGgscmV0aXJlZFBpeGVscyxyZXRpcmVkQnl0ZXM6cmV0aXJlZFBpeGVscyo0LFxuICAgICAgbGVhc2VkQ2FudmFzZXM6dGhpcy5sZWFzZWQuc2l6ZSxsZWFzZWRQaXhlbHMsbGVhc2VkQnl0ZXM6bGVhc2VkUGl4ZWxzKjQsXG4gICAgICBvd25lZENhbnZhc0J5dGVzOih0aGlzLnBpeGVscytzY3JhdGNoUGl4ZWxzK3NwYXJlUGl4ZWxzK3JldGlyZWRQaXhlbHMrbGVhc2VkUGl4ZWxzKSo0fTtcbiAgfVxuICBjbGVhcigpIHtcbiAgICAvLyBBY3RpdmUgcGFpbnRlcnMgcmV0YWluIHRoZWlyIGxlYXNlIGFuZCBmaW5pc2ggc2FmZWx5OyBmaW5hbGx5IGRpc3Bvc2VzXG4gICAgLy8gbGVhc2VzIGZyb20gdGhlIG9sZCBlcG9jaCBpbnN0ZWFkIG9mIHJlcG9wdWxhdGluZyB0aGUgY2xlYXJlZCBwb29sLlxuICAgIHRoaXMuZXBvY2grKztcbiAgICBmb3IoY29uc3QgY2FudmFzIG9mIFsuLi50aGlzLmVudHJpZXMudmFsdWVzKCldLm1hcCh2YWx1ZT0+dmFsdWUuY2FudmFzKS5jb25jYXQodGhpcy5zY3JhdGNoLHRoaXMuc3BhcmUsdGhpcy5yZXRpcmVkKSl0aGlzLnJlbGVhc2UoY2FudmFzKTtcbiAgICB0aGlzLmVudHJpZXMuY2xlYXIoKTt0aGlzLnNjcmF0Y2gubGVuZ3RoPXRoaXMuc3BhcmUubGVuZ3RoPXRoaXMucmV0aXJlZC5sZW5ndGg9MDtcbiAgICB0aGlzLnBpeGVscz0wO3RoaXMuaGl0cz10aGlzLm1pc3Nlcz10aGlzLmV2aWN0aW9ucz0wO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsMkJBQTJCO0FBRTdCLGFBQU0sZ0JBQWM7QUFDcEIsYUFBTSxrQkFBZ0I7QUFTdEIsYUFBTSxZQUFZO0FBQUEsRUFhdkIsWUFBb0IsU0FBUyxLQUFLLE9BQU8sTUFBYyxRQUFRLE1BQU07QUFBakQ7QUFBbUM7QUFBQSxFQUFlO0FBQUEsRUFaOUQsVUFBVSxvQkFBSSxJQUFvQjtBQUFBLEVBQ2xDLFVBQStCLENBQUM7QUFBQSxFQUNoQyxRQUE2QixDQUFDO0FBQUEsRUFDOUIsVUFBK0IsQ0FBQztBQUFBLEVBQ2hDLFFBQVE7QUFBQSxFQUNSLFNBQVMsb0JBQUksSUFBdUI7QUFBQSxFQUNwQyxRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFFVCxPQUFPO0FBQUEsRUFDUCxTQUFTO0FBQUEsRUFDVCxZQUFZO0FBQUEsRUFHcEIsSUFBSSxLQUFhLFNBQWlCLE9BQWtELFdBQWdCLGVBQXVCO0FBQ3pILFFBQUcsQ0FBQyxLQUFLLE1BQU0sTUFBSyxlQUFlO0FBQ25DLFVBQU0sS0FBSyxHQUFHLEdBQUcsSUFBSSxPQUFPLElBQUksUUFBUTtBQUN4QyxVQUFNLFNBQVMsS0FBSyxRQUFRLElBQUksRUFBRTtBQUNsQyxRQUFJLFFBQVE7QUFDVixXQUFLO0FBQ0wsV0FBSyxRQUFRLE9BQU8sRUFBRTtBQUFHLFdBQUssUUFBUSxJQUFJLElBQUksTUFBTTtBQUNwRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFNBQUs7QUFDTCxVQUFNLFNBQU8sV0FBUyxHQUFFLE9BQU8sV0FBVztBQUMxQyxVQUFNLFFBQU0sS0FBSyxPQUFNLFNBQU8sS0FBSyxLQUFLLEtBQUssU0FBUSxNQUFLLElBQUk7QUFDOUQsU0FBSyxPQUFPLElBQUksTUFBTTtBQUN0QixVQUFNLFFBQU0sS0FBSyxNQUFNLFFBQU8sSUFBSTtBQUNsQyxVQUFNLE1BQU0sU0FBUSxPQUFPO0FBQUUsVUFBTSxVQUFVLFFBQU8sTUFBTTtBQUMxRCxVQUFNLFdBQVMsTUFBTSxVQUFRO0FBQzdCLFNBQUs7QUFDTCxRQUFJO0FBQ0YsWUFBTSxLQUFLO0FBQ1gsWUFBTSxPQUFPLE1BQU0sYUFBYSxHQUFHLEdBQUcsTUFBTSxJQUFJLEVBQUU7QUFDbEQsVUFBSSxPQUFPLE1BQU0sTUFBTSxNQUFNLFFBQVEsSUFBSSxTQUFTO0FBQ2xELGVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxJQUFLLFVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0FBQzVELFlBQUksTUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJLENBQUMsR0FBRztBQUNoQyxjQUFJLElBQUksS0FBTSxRQUFPO0FBQUcsY0FBSSxJQUFJLE1BQU8sU0FBUTtBQUMvQyxjQUFJLElBQUksSUFBSyxPQUFNO0FBQUcsY0FBSSxJQUFJLE9BQVEsVUFBUztBQUFBLFFBQ2pEO0FBQUEsTUFDRjtBQUNBLFVBQUksUUFBUSxNQUFNO0FBQUUsZUFBTyxNQUFNO0FBQUcsZ0JBQVEsU0FBUztBQUFBLE1BQUc7QUFFeEQsYUFBTyxLQUFLLElBQUksR0FBRyxPQUFPLENBQUM7QUFBRyxZQUFNLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQztBQUN2RCxjQUFRLEtBQUssSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDO0FBQUcsZUFBUyxLQUFLLElBQUksT0FBTyxHQUFHLFNBQVMsQ0FBQztBQUM3RSxZQUFNLFNBQVMsS0FBSyxLQUFLLEtBQUssT0FBTSxRQUFNLE9BQUssR0FBRSxTQUFPLE1BQUksQ0FBQztBQUM3RCxXQUFLLE1BQU0sTUFBTSxFQUFFLFVBQVUsUUFBTyxNQUFLLEtBQUksT0FBTyxPQUFNLE9BQU8sUUFBTyxHQUFFLEdBQUUsT0FBTyxPQUFNLE9BQU8sTUFBTTtBQUN0RyxZQUFNLFNBQVMsRUFBRSxRQUFRLEdBQUcsT0FBTyxVQUFVLFFBQVEsR0FBRyxNQUFNLFVBQVUsUUFBUSxRQUFRO0FBQ3hGLFlBQU0sT0FBTyxPQUFPLFFBQVEsT0FBTztBQUNuQyxhQUFPLFVBQVEsS0FBSyxTQUFTLFFBQU0sS0FBSyxVQUFVLEtBQUssUUFBUSxTQUFTLEtBQUssUUFBUSxRQUFRLEtBQUssU0FBUyxLQUFLLFNBQVMsT0FBTyxLQUFLLFNBQVM7QUFDNUksY0FBTSxTQUFTLEtBQUssUUFBUSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQzFDLGNBQU0sTUFBTSxLQUFLLFFBQVEsSUFBSSxNQUFNO0FBQ25DLGFBQUssVUFBVSxJQUFJLE9BQU8sUUFBUSxJQUFJLE9BQU87QUFDN0MsYUFBSyxRQUFRLE9BQU8sTUFBTTtBQUFHLGFBQUs7QUFBWSxhQUFLLFFBQVEsS0FBSyxJQUFJLE1BQU07QUFBQSxNQUM1RTtBQUdBLFVBQUksVUFBUSxLQUFLLFNBQVMsUUFBUSxLQUFLLFFBQVE7QUFBRSxhQUFLLFFBQVEsSUFBSSxJQUFJLE1BQU07QUFBRyxhQUFLLFVBQVU7QUFBQSxNQUFNLE1BQy9GLE1BQUssUUFBUSxLQUFLLE1BQU07QUFDN0IsYUFBTztBQUFBLElBQ1QsVUFBRTtBQUNBLFdBQUs7QUFDTCxXQUFLLE9BQU8sT0FBTyxNQUFNO0FBQ3pCLFVBQUcsVUFBUSxLQUFLLE1BQU0sTUFBSyxJQUFJLEtBQUssU0FBUSxRQUFPLEdBQUUsSUFBRSxPQUFLLElBQUk7QUFBQSxVQUFPLE1BQUssUUFBUSxNQUFNO0FBQUEsSUFDNUY7QUFBQSxFQUNGO0FBQUEsRUFDUSxLQUFLLE1BQXlCLE9BQWEsUUFBYztBQUMvRCxVQUFNLFFBQU0sS0FBSyxVQUFVLFlBQVEsT0FBTyxVQUFRLFNBQU8sT0FBTyxXQUFTLE1BQU07QUFDL0UsV0FBTyxRQUFNLElBQUUsb0JBQW9CLE9BQU0sTUFBTSxJQUFFLEtBQUssT0FBTyxPQUFNLENBQUMsRUFBRSxDQUFDO0FBQUEsRUFDekU7QUFBQSxFQUNRLE1BQU0sUUFBeUIsT0FBSyxPQUFNO0FBQ2hELFVBQU0sTUFBSSxPQUFPLFdBQVcsTUFBSyxPQUFLLEVBQUMsb0JBQW1CLEtBQUksSUFBRSxNQUFTO0FBR3pFLFFBQUcsT0FBTyxJQUFJLFVBQVEsV0FBVyxLQUFJLE1BQU07QUFBQSxRQUFPLFFBQU8sUUFBTSxPQUFPO0FBQ3RFLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDUSxRQUFRLFFBQXlCO0FBQUMsV0FBTyxRQUFNO0FBQUUsV0FBTyxTQUFPO0FBQUEsRUFBRTtBQUFBLEVBQ2pFLElBQUksTUFBeUIsUUFBeUIsT0FBYSxRQUFjO0FBQ3ZGLFVBQU0sT0FBSyxPQUFPLFFBQU0sT0FBTztBQUMvQixRQUFHLE9BQUssUUFBTztBQUFDLFdBQUssUUFBUSxNQUFNO0FBQUU7QUFBQSxJQUFPO0FBQzVDLFdBQU0sS0FBSyxXQUFTLEtBQUssVUFBUSxTQUFPLEtBQUssT0FBTyxDQUFDLEtBQUksTUFBSSxNQUFJLEVBQUUsUUFBTSxFQUFFLFFBQU8sQ0FBQyxJQUFFLE9BQUssUUFBUSxNQUFLLFFBQVEsS0FBSyxNQUFNLENBQUU7QUFDNUgsU0FBSyxLQUFLLE1BQU07QUFBQSxFQUNsQjtBQUFBLEVBQ1EsaUJBQWdCO0FBR3RCLGVBQVUsVUFBVSxLQUFLLFFBQVEsTUFBSyxJQUFJLEtBQUssT0FBTSxRQUFPLEdBQUUsT0FBSyxJQUFJO0FBQ3ZFLFNBQUssUUFBUSxTQUFPO0FBQUEsRUFDdEI7QUFBQSxFQUNBLFFBQVE7QUFDTixVQUFNLFNBQU8sQ0FBQyxhQUF1QztBQUFDLFVBQUksTUFBSTtBQUFFLGlCQUFVLFVBQVUsU0FBUyxRQUFLLE9BQU8sUUFBTSxPQUFPO0FBQU8sYUFBTztBQUFBLElBQUk7QUFDeEksVUFBTSxnQkFBYyxPQUFPLEtBQUssT0FBTyxHQUFFLGNBQVksT0FBTyxLQUFLLEtBQUssR0FBRSxnQkFBYyxPQUFPLEtBQUssT0FBTyxHQUFFLGVBQWEsT0FBTyxLQUFLLE1BQU07QUFDMUksV0FBTztBQUFBLE1BQUMsU0FBUSxLQUFLLFFBQVE7QUFBQSxNQUFLLFFBQU8sS0FBSztBQUFBLE1BQU8sT0FBTSxLQUFLLFNBQU87QUFBQSxNQUFFLE1BQUssS0FBSztBQUFBLE1BQUssUUFBTyxLQUFLO0FBQUEsTUFBTyxXQUFVLEtBQUs7QUFBQSxNQUN4SCxpQkFBZ0IsS0FBSyxRQUFRO0FBQUEsTUFBTztBQUFBLE1BQWMsY0FBYSxnQkFBYztBQUFBLE1BQzdFLGVBQWMsS0FBSyxNQUFNO0FBQUEsTUFBTztBQUFBLE1BQVksWUFBVyxjQUFZO0FBQUEsTUFDbkUsaUJBQWdCLEtBQUssUUFBUTtBQUFBLE1BQU87QUFBQSxNQUFjLGNBQWEsZ0JBQWM7QUFBQSxNQUM3RSxnQkFBZSxLQUFLLE9BQU87QUFBQSxNQUFLO0FBQUEsTUFBYSxhQUFZLGVBQWE7QUFBQSxNQUN0RSxtQkFBa0IsS0FBSyxTQUFPLGdCQUFjLGNBQVksZ0JBQWMsZ0JBQWM7QUFBQSxJQUFDO0FBQUEsRUFDekY7QUFBQSxFQUNBLFFBQVE7QUFHTixTQUFLO0FBQ0wsZUFBVSxVQUFVLENBQUMsR0FBRyxLQUFLLFFBQVEsT0FBTyxDQUFDLEVBQUUsSUFBSSxXQUFPLE1BQU0sTUFBTSxFQUFFLE9BQU8sS0FBSyxTQUFRLEtBQUssT0FBTSxLQUFLLE9BQU8sRUFBRSxNQUFLLFFBQVEsTUFBTTtBQUN4SSxTQUFLLFFBQVEsTUFBTTtBQUFFLFNBQUssUUFBUSxTQUFPLEtBQUssTUFBTSxTQUFPLEtBQUssUUFBUSxTQUFPO0FBQy9FLFNBQUssU0FBTztBQUFFLFNBQUssT0FBSyxLQUFLLFNBQU8sS0FBSyxZQUFVO0FBQUEsRUFDckQ7QUFDRjsiLCJuYW1lcyI6W119