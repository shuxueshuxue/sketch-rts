import * as THREE from "/.vite-cache/deps/three.js?v=906fd901";
const VERTEX = `
attribute vec4 markerData;
attribute float strokeDistance;
varying vec4 markerShape;
varying vec2 markerLocal;
varying float markerStroke;
varying vec3 markerInk;
void main() {
  markerShape=markerData;
  markerLocal=position.xz*(markerData.xy+vec2(2.0));
  markerStroke=strokeDistance;
  markerInk=instanceColor;
  gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(position,1.0);
}`;
const FRAGMENT = `
varying vec4 markerShape;
varying vec2 markerLocal;
varying float markerStroke;
varying vec3 markerInk;
void main() {
  float d;
  if(markerShape.w<0.5) d=(length(markerLocal/markerShape.xy)-1.0)*min(markerShape.x,markerShape.y);
  else if(markerShape.w<1.5) d=max(abs(markerLocal.x)-markerShape.x,abs(markerLocal.y)-markerShape.y);
  else d=markerStroke;
  float aa=max(0.15,fwidth(d));
  float alpha=1.0-smoothstep(markerShape.z*0.5-aa,markerShape.z*0.5+aa,abs(d));
  if(alpha<0.01)discard;
  gl_FragColor=vec4(markerInk,alpha*0.92);
  #include <colorspace_fragment>
}`;
export class SelectionMarkers {
  constructor(scene) {
    this.scene = scene;
    this.quad.setAttribute("strokeDistance", new THREE.Float32BufferAttribute(new Float32Array(4), 1));
  }
  material = new THREE.ShaderMaterial({
    vertexShader: VERTEX,
    fragmentShader: FRAGMENT,
    transparent: true,
    depthTest: true,
    depthWrite: false,
    toneMapped: false,
    side: THREE.DoubleSide
  });
  quad = new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2);
  hulls = /* @__PURE__ */ new Map();
  batches = /* @__PURE__ */ new Map();
  matrix = new THREE.Matrix4();
  scale = new THREE.Vector3();
  ink = new THREE.Color();
  frame = 0;
  disposed = false;
  begin() {
    if (this.disposed) return;
    this.frame++;
    for (const batch of this.batches.values()) batch.count = 0;
  }
  ellipse(matrix, rx, rz, color, selected) {
    if (this.disposed || rx <= 0 || rz <= 0) return;
    this.matrix.copy(matrix).scale(this.scale.set(rx + 2, 1, rz + 2));
    this.add("surface", this.quad, this.matrix, rx, rz, selected ? 3 : 2, 0, color);
  }
  rectangle(matrix, halfWidth, halfDepth, color, selected) {
    if (this.disposed || halfWidth <= 0 || halfDepth <= 0) return;
    this.matrix.copy(matrix).scale(this.scale.set(halfWidth + 2, 1, halfDepth + 2));
    this.add("surface", this.quad, this.matrix, halfWidth, halfDepth, selected ? 2.5 : 1.5, 1, color);
  }
  hull(key, points, scale, matrix, color, selected) {
    if (this.disposed || points.length < 3 || !(scale > 0)) return;
    let geometry = this.hulls.get(key);
    if (!geometry) {
      const vertices = [], distance = [], indices = [];
      for (let i = 0; i < points.length; i++) {
        const a = points[i], b = points[(i + 1) % points.length], dx = b.x - a.x, dz = b.y - a.y, length = Math.hypot(dx, dz);
        if (length === 0) continue;
        const nx = -dz / length * 3, nz = dx / length * 3, start = vertices.length / 3;
        for (const [point, side] of [[a, -1], [a, 1], [b, -1], [b, 1]]) {
          vertices.push(point.x / scale + nx * side, 0, point.y / scale + nz * side);
          distance.push(side * 3);
        }
        indices.push(start, start + 1, start + 2, start + 2, start + 1, start + 3);
      }
      geometry = new THREE.BufferGeometry();
      geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
      geometry.setAttribute("strokeDistance", new THREE.Float32BufferAttribute(distance, 1));
      geometry.setIndex(indices);
      this.hulls.set(key, geometry);
    }
    this.add(`hull:${key}`, geometry, matrix, 0, 0, (selected ? 3 : 2) / scale, 2, color);
  }
  add(key, template, matrix, rx, rz, width, shape, color) {
    let batch = this.batches.get(key);
    const needed = (batch?.count ?? 0) + 1;
    if (!batch || needed > batch.capacity) {
      const capacity = 2 ** Math.ceil(Math.log2(needed)), geometry = template.clone();
      const data = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage);
      geometry.setAttribute("markerData", data);
      const mesh = new THREE.InstancedMesh(geometry, this.material, capacity);
      mesh.name = key === "surface" ? "SelectionSurface" : "SelectionHull";
      mesh.frustumCulled = false;
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.renderOrder = -1;
      mesh.raycast = () => {
      };
      mesh.castShadow = mesh.receiveShadow = false;
      if (batch) {
        mesh.instanceMatrix.array.set(batch.mesh.instanceMatrix.array.subarray(0, batch.count * 16));
        if (batch.mesh.instanceColor) {
          mesh.setColorAt(0, this.ink);
          mesh.instanceColor.array.set(batch.mesh.instanceColor.array.subarray(0, batch.count * 3));
        }
        data.array.set(batch.data.array.subarray(0, batch.count * 4));
        this.release(batch);
      }
      batch = { template, mesh, data, capacity, count: needed - 1, last: this.frame };
      this.batches.set(key, batch);
      this.scene.add(mesh);
    }
    const at = batch.count++;
    batch.last = this.frame;
    batch.mesh.setMatrixAt(at, matrix);
    batch.mesh.setColorAt(at, this.ink.set(color));
    batch.data.setXYZW(at, rx, rz, width, shape);
  }
  finish() {
    if (this.disposed) return;
    for (const [key, batch] of this.batches) {
      batch.mesh.count = batch.count;
      batch.mesh.visible = batch.count > 0;
      if (batch.count) {
        batch.mesh.instanceMatrix.needsUpdate = true;
        batch.mesh.instanceColor.needsUpdate = true;
        batch.data.needsUpdate = true;
      } else if (this.frame - batch.last > 120) {
        this.release(batch);
        this.batches.delete(key);
      }
    }
  }
  clear() {
    for (const batch of this.batches.values()) {
      batch.count = 0;
      batch.mesh.count = 0;
      batch.mesh.visible = false;
    }
  }
  release(batch) {
    batch.mesh.removeFromParent();
    batch.mesh.dispose();
    batch.mesh.geometry.dispose();
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    for (const batch of this.batches.values()) this.release(batch);
    this.batches.clear();
    for (const geometry of this.hulls.values()) geometry.dispose();
    this.hulls.clear();
    this.quad.dispose();
    this.material.dispose();
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdGlvbi1tYXJrZXJzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFRIUkVFIGZyb20gJ3RocmVlJztcblxuY29uc3QgVkVSVEVYPWBcbmF0dHJpYnV0ZSB2ZWM0IG1hcmtlckRhdGE7XG5hdHRyaWJ1dGUgZmxvYXQgc3Ryb2tlRGlzdGFuY2U7XG52YXJ5aW5nIHZlYzQgbWFya2VyU2hhcGU7XG52YXJ5aW5nIHZlYzIgbWFya2VyTG9jYWw7XG52YXJ5aW5nIGZsb2F0IG1hcmtlclN0cm9rZTtcbnZhcnlpbmcgdmVjMyBtYXJrZXJJbms7XG52b2lkIG1haW4oKSB7XG4gIG1hcmtlclNoYXBlPW1hcmtlckRhdGE7XG4gIG1hcmtlckxvY2FsPXBvc2l0aW9uLnh6KihtYXJrZXJEYXRhLnh5K3ZlYzIoMi4wKSk7XG4gIG1hcmtlclN0cm9rZT1zdHJva2VEaXN0YW5jZTtcbiAgbWFya2VySW5rPWluc3RhbmNlQ29sb3I7XG4gIGdsX1Bvc2l0aW9uPXByb2plY3Rpb25NYXRyaXgqbW9kZWxWaWV3TWF0cml4Kmluc3RhbmNlTWF0cml4KnZlYzQocG9zaXRpb24sMS4wKTtcbn1gO1xuY29uc3QgRlJBR01FTlQ9YFxudmFyeWluZyB2ZWM0IG1hcmtlclNoYXBlO1xudmFyeWluZyB2ZWMyIG1hcmtlckxvY2FsO1xudmFyeWluZyBmbG9hdCBtYXJrZXJTdHJva2U7XG52YXJ5aW5nIHZlYzMgbWFya2VySW5rO1xudm9pZCBtYWluKCkge1xuICBmbG9hdCBkO1xuICBpZihtYXJrZXJTaGFwZS53PDAuNSkgZD0obGVuZ3RoKG1hcmtlckxvY2FsL21hcmtlclNoYXBlLnh5KS0xLjApKm1pbihtYXJrZXJTaGFwZS54LG1hcmtlclNoYXBlLnkpO1xuICBlbHNlIGlmKG1hcmtlclNoYXBlLnc8MS41KSBkPW1heChhYnMobWFya2VyTG9jYWwueCktbWFya2VyU2hhcGUueCxhYnMobWFya2VyTG9jYWwueSktbWFya2VyU2hhcGUueSk7XG4gIGVsc2UgZD1tYXJrZXJTdHJva2U7XG4gIGZsb2F0IGFhPW1heCgwLjE1LGZ3aWR0aChkKSk7XG4gIGZsb2F0IGFscGhhPTEuMC1zbW9vdGhzdGVwKG1hcmtlclNoYXBlLnoqMC41LWFhLG1hcmtlclNoYXBlLnoqMC41K2FhLGFicyhkKSk7XG4gIGlmKGFscGhhPDAuMDEpZGlzY2FyZDtcbiAgZ2xfRnJhZ0NvbG9yPXZlYzQobWFya2VySW5rLGFscGhhKjAuOTIpO1xuICAjaW5jbHVkZSA8Y29sb3JzcGFjZV9mcmFnbWVudD5cbn1gO1xudHlwZSBCYXRjaD17dGVtcGxhdGU6VEhSRUUuQnVmZmVyR2VvbWV0cnk7bWVzaDpUSFJFRS5JbnN0YW5jZWRNZXNoO2RhdGE6VEhSRUUuSW5zdGFuY2VkQnVmZmVyQXR0cmlidXRlO2NhcGFjaXR5Om51bWJlcjtjb3VudDpudW1iZXI7bGFzdDpudW1iZXJ9O1xudHlwZSBQb2ludD17eDpudW1iZXI7eTpudW1iZXJ9O1xuXG4vKiogRGVjb3JhdGlvbnMgYXJlIHJlYWwgZmxhdCBzdXJmYWNlcywgc28gYWN0b3JzIG9jY2x1ZGUgdGhlbSB0aHJvdWdoIHRoZVxuICogbm9ybWFsIGRlcHRoIGJ1ZmZlci4gVGhleSBzaGFyZSBvbmUgbWF0ZXJpYWwgYW5kIGdyb3cgaW5zdGFuY2UgYnVmZmVycyBvbmx5XG4gKiB3aGVuIGNhcGFjaXR5IGluY3JlYXNlcy4gVGhleSBuZXZlciBqb2luIHRoZSBlbnRpdHkgcmF5Y2FzdCBvciBzaGFkb3cgcGFzcy4gKi9cbmV4cG9ydCBjbGFzcyBTZWxlY3Rpb25NYXJrZXJzIHtcbiAgcHJpdmF0ZSBtYXRlcmlhbD1uZXcgVEhSRUUuU2hhZGVyTWF0ZXJpYWwoe3ZlcnRleFNoYWRlcjpWRVJURVgsZnJhZ21lbnRTaGFkZXI6RlJBR01FTlQsXG4gICAgdHJhbnNwYXJlbnQ6dHJ1ZSxkZXB0aFRlc3Q6dHJ1ZSxkZXB0aFdyaXRlOmZhbHNlLHRvbmVNYXBwZWQ6ZmFsc2Usc2lkZTpUSFJFRS5Eb3VibGVTaWRlfSk7XG4gIHByaXZhdGUgcXVhZD1uZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgyLDIpLnJvdGF0ZVgoLU1hdGguUEkvMik7XG4gIHByaXZhdGUgaHVsbHM9bmV3IE1hcDxzdHJpbmcsVEhSRUUuQnVmZmVyR2VvbWV0cnk+KCk7XG4gIHByaXZhdGUgYmF0Y2hlcz1uZXcgTWFwPHN0cmluZyxCYXRjaD4oKTtcbiAgcHJpdmF0ZSBtYXRyaXg9bmV3IFRIUkVFLk1hdHJpeDQoKTtcbiAgcHJpdmF0ZSBzY2FsZT1uZXcgVEhSRUUuVmVjdG9yMygpO1xuICBwcml2YXRlIGluaz1uZXcgVEhSRUUuQ29sb3IoKTtcbiAgcHJpdmF0ZSBmcmFtZT0wO1xuICBwcml2YXRlIGRpc3Bvc2VkPWZhbHNlO1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNjZW5lOlRIUkVFLlNjZW5lKSB7XG4gICAgdGhpcy5xdWFkLnNldEF0dHJpYnV0ZSgnc3Ryb2tlRGlzdGFuY2UnLG5ldyBUSFJFRS5GbG9hdDMyQnVmZmVyQXR0cmlidXRlKG5ldyBGbG9hdDMyQXJyYXkoNCksMSkpO1xuICB9XG4gIGJlZ2luKCl7aWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5mcmFtZSsrO2Zvcihjb25zdCBiYXRjaCBvZiB0aGlzLmJhdGNoZXMudmFsdWVzKCkpYmF0Y2guY291bnQ9MDt9XG4gIGVsbGlwc2UobWF0cml4OlRIUkVFLk1hdHJpeDQscng6bnVtYmVyLHJ6Om51bWJlcixjb2xvcjpzdHJpbmcsc2VsZWN0ZWQ6Ym9vbGVhbil7XG4gICAgaWYodGhpcy5kaXNwb3NlZCB8fCByeDw9MCB8fCByejw9MClyZXR1cm47XG4gICAgdGhpcy5tYXRyaXguY29weShtYXRyaXgpLnNjYWxlKHRoaXMuc2NhbGUuc2V0KHJ4KzIsMSxyeisyKSk7XG4gICAgdGhpcy5hZGQoJ3N1cmZhY2UnLHRoaXMucXVhZCx0aGlzLm1hdHJpeCxyeCxyeixzZWxlY3RlZD8zOjIsMCxjb2xvcik7XG4gIH1cbiAgcmVjdGFuZ2xlKG1hdHJpeDpUSFJFRS5NYXRyaXg0LGhhbGZXaWR0aDpudW1iZXIsaGFsZkRlcHRoOm51bWJlcixjb2xvcjpzdHJpbmcsc2VsZWN0ZWQ6Ym9vbGVhbil7XG4gICAgaWYodGhpcy5kaXNwb3NlZCB8fCBoYWxmV2lkdGg8PTAgfHwgaGFsZkRlcHRoPD0wKXJldHVybjtcbiAgICB0aGlzLm1hdHJpeC5jb3B5KG1hdHJpeCkuc2NhbGUodGhpcy5zY2FsZS5zZXQoaGFsZldpZHRoKzIsMSxoYWxmRGVwdGgrMikpO1xuICAgIHRoaXMuYWRkKCdzdXJmYWNlJyx0aGlzLnF1YWQsdGhpcy5tYXRyaXgsaGFsZldpZHRoLGhhbGZEZXB0aCxzZWxlY3RlZD8yLjU6MS41LDEsY29sb3IpO1xuICB9XG4gIGh1bGwoa2V5OnN0cmluZyxwb2ludHM6cmVhZG9ubHkgUG9pbnRbXSxzY2FsZTpudW1iZXIsbWF0cml4OlRIUkVFLk1hdHJpeDQsY29sb3I6c3RyaW5nLHNlbGVjdGVkOmJvb2xlYW4pe1xuICAgIGlmKHRoaXMuZGlzcG9zZWQgfHwgcG9pbnRzLmxlbmd0aDwzIHx8ICEoc2NhbGU+MCkpcmV0dXJuO1xuICAgIGxldCBnZW9tZXRyeT10aGlzLmh1bGxzLmdldChrZXkpO1xuICAgIGlmKCFnZW9tZXRyeSl7XG4gICAgICAvLyBQcm9maWxlcyBhbHJlYWR5IGluY2x1ZGUgc2l6ZS4gVGhlIHJldXNhYmxlIGh1bGwgaXMgbm9ybWFsaXplZCBvbmNlO1xuICAgICAgLy8gaXRzIGluc3RhbmNlIHRyYW5zZm9ybSBhcHBsaWVzIHRoZSBkaXNwbGF5ZWQgc2hpcCBzY2FsZSBleGFjdGx5IG9uY2UuXG4gICAgICBjb25zdCB2ZXJ0aWNlczpudW1iZXJbXT1bXSxkaXN0YW5jZTpudW1iZXJbXT1bXSxpbmRpY2VzOm51bWJlcltdPVtdO1xuICAgICAgZm9yKGxldCBpPTA7aTxwb2ludHMubGVuZ3RoO2krKykge1xuICAgICAgICBjb25zdCBhPXBvaW50c1tpXSEsYj1wb2ludHNbKGkrMSklcG9pbnRzLmxlbmd0aF0hLGR4PWIueC1hLngsZHo9Yi55LWEueSxsZW5ndGg9TWF0aC5oeXBvdChkeCxkeik7XG4gICAgICAgIGlmKGxlbmd0aD09PTApY29udGludWU7XG4gICAgICAgIGNvbnN0IG54PS1kei9sZW5ndGgqMyxuej1keC9sZW5ndGgqMyxzdGFydD12ZXJ0aWNlcy5sZW5ndGgvMztcbiAgICAgICAgZm9yKGNvbnN0IFtwb2ludCxzaWRlXSBvZiBbW2EsLTFdLFthLDFdLFtiLC0xXSxbYiwxXV0gYXMgY29uc3Qpe3ZlcnRpY2VzLnB1c2gocG9pbnQueC9zY2FsZStueCpzaWRlLDAscG9pbnQueS9zY2FsZStueipzaWRlKTtkaXN0YW5jZS5wdXNoKHNpZGUqMyk7fVxuICAgICAgICBpbmRpY2VzLnB1c2goc3RhcnQsc3RhcnQrMSxzdGFydCsyLHN0YXJ0KzIsc3RhcnQrMSxzdGFydCszKTtcbiAgICAgIH1cbiAgICAgIGdlb21ldHJ5PW5ldyBUSFJFRS5CdWZmZXJHZW9tZXRyeSgpO2dlb21ldHJ5LnNldEF0dHJpYnV0ZSgncG9zaXRpb24nLG5ldyBUSFJFRS5GbG9hdDMyQnVmZmVyQXR0cmlidXRlKHZlcnRpY2VzLDMpKTtcbiAgICAgIGdlb21ldHJ5LnNldEF0dHJpYnV0ZSgnc3Ryb2tlRGlzdGFuY2UnLG5ldyBUSFJFRS5GbG9hdDMyQnVmZmVyQXR0cmlidXRlKGRpc3RhbmNlLDEpKTtnZW9tZXRyeS5zZXRJbmRleChpbmRpY2VzKTtcbiAgICAgIHRoaXMuaHVsbHMuc2V0KGtleSxnZW9tZXRyeSk7XG4gICAgfVxuICAgIHRoaXMuYWRkKGBodWxsOiR7a2V5fWAsZ2VvbWV0cnksbWF0cml4LDAsMCwoc2VsZWN0ZWQ/MzoyKS9zY2FsZSwyLGNvbG9yKTtcbiAgfVxuICBwcml2YXRlIGFkZChrZXk6c3RyaW5nLHRlbXBsYXRlOlRIUkVFLkJ1ZmZlckdlb21ldHJ5LG1hdHJpeDpUSFJFRS5NYXRyaXg0LHJ4Om51bWJlcixyejpudW1iZXIsd2lkdGg6bnVtYmVyLHNoYXBlOm51bWJlcixjb2xvcjpzdHJpbmcpIHtcbiAgICBsZXQgYmF0Y2g9dGhpcy5iYXRjaGVzLmdldChrZXkpO1xuICAgIGNvbnN0IG5lZWRlZD0oYmF0Y2g/LmNvdW50Pz8wKSsxO1xuICAgIGlmKCFiYXRjaCB8fCBuZWVkZWQ+YmF0Y2guY2FwYWNpdHkpIHtcbiAgICAgIGNvbnN0IGNhcGFjaXR5PTIqKk1hdGguY2VpbChNYXRoLmxvZzIobmVlZGVkKSksZ2VvbWV0cnk9dGVtcGxhdGUuY2xvbmUoKTtcbiAgICAgIGNvbnN0IGRhdGE9bmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KjQpLDQpLnNldFVzYWdlKFRIUkVFLkR5bmFtaWNEcmF3VXNhZ2UpO1xuICAgICAgZ2VvbWV0cnkuc2V0QXR0cmlidXRlKCdtYXJrZXJEYXRhJyxkYXRhKTtcbiAgICAgIGNvbnN0IG1lc2g9bmV3IFRIUkVFLkluc3RhbmNlZE1lc2goZ2VvbWV0cnksdGhpcy5tYXRlcmlhbCxjYXBhY2l0eSk7XG4gICAgICBtZXNoLm5hbWU9a2V5PT09J3N1cmZhY2UnPydTZWxlY3Rpb25TdXJmYWNlJzonU2VsZWN0aW9uSHVsbCc7bWVzaC5mcnVzdHVtQ3VsbGVkPWZhbHNlO1xuICAgICAgbWVzaC5pbnN0YW5jZU1hdHJpeC5zZXRVc2FnZShUSFJFRS5EeW5hbWljRHJhd1VzYWdlKTttZXNoLnJlbmRlck9yZGVyPS0xO21lc2gucmF5Y2FzdD0oKT0+e307XG4gICAgICBtZXNoLmNhc3RTaGFkb3c9bWVzaC5yZWNlaXZlU2hhZG93PWZhbHNlO1xuICAgICAgaWYoYmF0Y2gpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZW50cmllcyBhbHJlYWR5IGFkZGVkIHRoaXMgZnJhbWUgd2hlbiBhIHNlbGVjdGlvbiBncm93cy5cbiAgICAgICAgbWVzaC5pbnN0YW5jZU1hdHJpeC5hcnJheS5zZXQoYmF0Y2gubWVzaC5pbnN0YW5jZU1hdHJpeC5hcnJheS5zdWJhcnJheSgwLGJhdGNoLmNvdW50KjE2KSk7XG4gICAgICAgIGlmKGJhdGNoLm1lc2guaW5zdGFuY2VDb2xvcil7bWVzaC5zZXRDb2xvckF0KDAsdGhpcy5pbmspO21lc2guaW5zdGFuY2VDb2xvciEuYXJyYXkuc2V0KGJhdGNoLm1lc2guaW5zdGFuY2VDb2xvci5hcnJheS5zdWJhcnJheSgwLGJhdGNoLmNvdW50KjMpKTt9XG4gICAgICAgIGRhdGEuYXJyYXkuc2V0KGJhdGNoLmRhdGEuYXJyYXkuc3ViYXJyYXkoMCxiYXRjaC5jb3VudCo0KSk7XG4gICAgICAgIHRoaXMucmVsZWFzZShiYXRjaCk7XG4gICAgICB9XG4gICAgICBiYXRjaD17dGVtcGxhdGUsbWVzaCxkYXRhLGNhcGFjaXR5LGNvdW50Om5lZWRlZC0xLGxhc3Q6dGhpcy5mcmFtZX07dGhpcy5iYXRjaGVzLnNldChrZXksYmF0Y2gpO3RoaXMuc2NlbmUuYWRkKG1lc2gpO1xuICAgIH1cbiAgICBjb25zdCBhdD1iYXRjaC5jb3VudCsrO2JhdGNoLmxhc3Q9dGhpcy5mcmFtZTtcbiAgICBiYXRjaC5tZXNoLnNldE1hdHJpeEF0KGF0LG1hdHJpeCk7YmF0Y2gubWVzaC5zZXRDb2xvckF0KGF0LHRoaXMuaW5rLnNldChjb2xvcikpO2JhdGNoLmRhdGEuc2V0WFlaVyhhdCxyeCxyeix3aWR0aCxzaGFwZSk7XG4gIH1cbiAgZmluaXNoKCl7XG4gICAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47XG4gICAgZm9yKGNvbnN0IFtrZXksYmF0Y2hdIG9mIHRoaXMuYmF0Y2hlcykge1xuICAgICAgYmF0Y2gubWVzaC5jb3VudD1iYXRjaC5jb3VudDtiYXRjaC5tZXNoLnZpc2libGU9YmF0Y2guY291bnQ+MDtcbiAgICAgIGlmKGJhdGNoLmNvdW50KXtiYXRjaC5tZXNoLmluc3RhbmNlTWF0cml4Lm5lZWRzVXBkYXRlPXRydWU7YmF0Y2gubWVzaC5pbnN0YW5jZUNvbG9yIS5uZWVkc1VwZGF0ZT10cnVlO2JhdGNoLmRhdGEubmVlZHNVcGRhdGU9dHJ1ZTt9XG4gICAgICBlbHNlIGlmKHRoaXMuZnJhbWUtYmF0Y2gubGFzdD4xMjApe3RoaXMucmVsZWFzZShiYXRjaCk7dGhpcy5iYXRjaGVzLmRlbGV0ZShrZXkpO31cbiAgICB9XG4gIH1cbiAgY2xlYXIoKXtmb3IoY29uc3QgYmF0Y2ggb2YgdGhpcy5iYXRjaGVzLnZhbHVlcygpKXtiYXRjaC5jb3VudD0wO2JhdGNoLm1lc2guY291bnQ9MDtiYXRjaC5tZXNoLnZpc2libGU9ZmFsc2U7fX1cbiAgcHJpdmF0ZSByZWxlYXNlKGJhdGNoOkJhdGNoKXtiYXRjaC5tZXNoLnJlbW92ZUZyb21QYXJlbnQoKTtiYXRjaC5tZXNoLmRpc3Bvc2UoKTtiYXRjaC5tZXNoLmdlb21ldHJ5LmRpc3Bvc2UoKTt9XG4gIGRpc3Bvc2UoKXtcbiAgICBpZih0aGlzLmRpc3Bvc2VkKXJldHVybjt0aGlzLmRpc3Bvc2VkPXRydWU7XG4gICAgZm9yKGNvbnN0IGJhdGNoIG9mIHRoaXMuYmF0Y2hlcy52YWx1ZXMoKSl0aGlzLnJlbGVhc2UoYmF0Y2gpO3RoaXMuYmF0Y2hlcy5jbGVhcigpO1xuICAgIGZvcihjb25zdCBnZW9tZXRyeSBvZiB0aGlzLmh1bGxzLnZhbHVlcygpKWdlb21ldHJ5LmRpc3Bvc2UoKTt0aGlzLmh1bGxzLmNsZWFyKCk7dGhpcy5xdWFkLmRpc3Bvc2UoKTt0aGlzLm1hdGVyaWFsLmRpc3Bvc2UoKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxZQUFZLFdBQVc7QUFFdkIsTUFBTSxTQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFjYixNQUFNLFdBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFzQlIsYUFBTSxpQkFBaUI7QUFBQSxFQVc1QixZQUFvQixPQUFtQjtBQUFuQjtBQUNsQixTQUFLLEtBQUssYUFBYSxrQkFBaUIsSUFBSSxNQUFNLHVCQUF1QixJQUFJLGFBQWEsQ0FBQyxHQUFFLENBQUMsQ0FBQztBQUFBLEVBQ2pHO0FBQUEsRUFaUSxXQUFTLElBQUksTUFBTSxlQUFlO0FBQUEsSUFBQyxjQUFhO0FBQUEsSUFBTyxnQkFBZTtBQUFBLElBQzVFLGFBQVk7QUFBQSxJQUFLLFdBQVU7QUFBQSxJQUFLLFlBQVc7QUFBQSxJQUFNLFlBQVc7QUFBQSxJQUFNLE1BQUssTUFBTTtBQUFBLEVBQVUsQ0FBQztBQUFBLEVBQ2xGLE9BQUssSUFBSSxNQUFNLGNBQWMsR0FBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLEtBQUssS0FBRyxDQUFDO0FBQUEsRUFDcEQsUUFBTSxvQkFBSSxJQUFpQztBQUFBLEVBQzNDLFVBQVEsb0JBQUksSUFBa0I7QUFBQSxFQUM5QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQUEsRUFDekIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQ3hCLE1BQUksSUFBSSxNQUFNLE1BQU07QUFBQSxFQUNwQixRQUFNO0FBQUEsRUFDTixXQUFTO0FBQUEsRUFJakIsUUFBTztBQUFDLFFBQUcsS0FBSyxTQUFTO0FBQU8sU0FBSztBQUFRLGVBQVUsU0FBUyxLQUFLLFFBQVEsT0FBTyxFQUFFLE9BQU0sUUFBTTtBQUFBLEVBQUU7QUFBQSxFQUNwRyxRQUFRLFFBQXFCLElBQVUsSUFBVSxPQUFhLFVBQWlCO0FBQzdFLFFBQUcsS0FBSyxZQUFZLE1BQUksS0FBSyxNQUFJLEVBQUU7QUFDbkMsU0FBSyxPQUFPLEtBQUssTUFBTSxFQUFFLE1BQU0sS0FBSyxNQUFNLElBQUksS0FBRyxHQUFFLEdBQUUsS0FBRyxDQUFDLENBQUM7QUFDMUQsU0FBSyxJQUFJLFdBQVUsS0FBSyxNQUFLLEtBQUssUUFBTyxJQUFHLElBQUcsV0FBUyxJQUFFLEdBQUUsR0FBRSxLQUFLO0FBQUEsRUFDckU7QUFBQSxFQUNBLFVBQVUsUUFBcUIsV0FBaUIsV0FBaUIsT0FBYSxVQUFpQjtBQUM3RixRQUFHLEtBQUssWUFBWSxhQUFXLEtBQUssYUFBVyxFQUFFO0FBQ2pELFNBQUssT0FBTyxLQUFLLE1BQU0sRUFBRSxNQUFNLEtBQUssTUFBTSxJQUFJLFlBQVUsR0FBRSxHQUFFLFlBQVUsQ0FBQyxDQUFDO0FBQ3hFLFNBQUssSUFBSSxXQUFVLEtBQUssTUFBSyxLQUFLLFFBQU8sV0FBVSxXQUFVLFdBQVMsTUFBSSxLQUFJLEdBQUUsS0FBSztBQUFBLEVBQ3ZGO0FBQUEsRUFDQSxLQUFLLEtBQVcsUUFBd0IsT0FBYSxRQUFxQixPQUFhLFVBQWlCO0FBQ3RHLFFBQUcsS0FBSyxZQUFZLE9BQU8sU0FBTyxLQUFLLEVBQUUsUUFBTSxHQUFHO0FBQ2xELFFBQUksV0FBUyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQy9CLFFBQUcsQ0FBQyxVQUFTO0FBR1gsWUFBTSxXQUFrQixDQUFDLEdBQUUsV0FBa0IsQ0FBQyxHQUFFLFVBQWlCLENBQUM7QUFDbEUsZUFBUSxJQUFFLEdBQUUsSUFBRSxPQUFPLFFBQU8sS0FBSztBQUMvQixjQUFNLElBQUUsT0FBTyxDQUFDLEdBQUcsSUFBRSxRQUFRLElBQUUsS0FBRyxPQUFPLE1BQU0sR0FBRyxLQUFHLEVBQUUsSUFBRSxFQUFFLEdBQUUsS0FBRyxFQUFFLElBQUUsRUFBRSxHQUFFLFNBQU8sS0FBSyxNQUFNLElBQUcsRUFBRTtBQUMvRixZQUFHLFdBQVMsRUFBRTtBQUNkLGNBQU0sS0FBRyxDQUFDLEtBQUcsU0FBTyxHQUFFLEtBQUcsS0FBRyxTQUFPLEdBQUUsUUFBTSxTQUFTLFNBQU87QUFDM0QsbUJBQVUsQ0FBQyxPQUFNLElBQUksS0FBSyxDQUFDLENBQUMsR0FBRSxFQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxDQUFDLEdBQUUsRUFBRSxHQUFFLENBQUMsR0FBRSxDQUFDLENBQUMsR0FBVztBQUFDLG1CQUFTLEtBQUssTUFBTSxJQUFFLFFBQU0sS0FBRyxNQUFLLEdBQUUsTUFBTSxJQUFFLFFBQU0sS0FBRyxJQUFJO0FBQUUsbUJBQVMsS0FBSyxPQUFLLENBQUM7QUFBQSxRQUFFO0FBQ25KLGdCQUFRLEtBQUssT0FBTSxRQUFNLEdBQUUsUUFBTSxHQUFFLFFBQU0sR0FBRSxRQUFNLEdBQUUsUUFBTSxDQUFDO0FBQUEsTUFDNUQ7QUFDQSxpQkFBUyxJQUFJLE1BQU0sZUFBZTtBQUFFLGVBQVMsYUFBYSxZQUFXLElBQUksTUFBTSx1QkFBdUIsVUFBUyxDQUFDLENBQUM7QUFDakgsZUFBUyxhQUFhLGtCQUFpQixJQUFJLE1BQU0sdUJBQXVCLFVBQVMsQ0FBQyxDQUFDO0FBQUUsZUFBUyxTQUFTLE9BQU87QUFDOUcsV0FBSyxNQUFNLElBQUksS0FBSSxRQUFRO0FBQUEsSUFDN0I7QUFDQSxTQUFLLElBQUksUUFBUSxHQUFHLElBQUcsVUFBUyxRQUFPLEdBQUUsSUFBRyxXQUFTLElBQUUsS0FBRyxPQUFNLEdBQUUsS0FBSztBQUFBLEVBQ3pFO0FBQUEsRUFDUSxJQUFJLEtBQVcsVUFBOEIsUUFBcUIsSUFBVSxJQUFVLE9BQWEsT0FBYSxPQUFjO0FBQ3BJLFFBQUksUUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQzlCLFVBQU0sVUFBUSxPQUFPLFNBQU8sS0FBRztBQUMvQixRQUFHLENBQUMsU0FBUyxTQUFPLE1BQU0sVUFBVTtBQUNsQyxZQUFNLFdBQVMsS0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFFLFdBQVMsU0FBUyxNQUFNO0FBQ3ZFLFlBQU0sT0FBSyxJQUFJLE1BQU0seUJBQXlCLElBQUksYUFBYSxXQUFTLENBQUMsR0FBRSxDQUFDLEVBQUUsU0FBUyxNQUFNLGdCQUFnQjtBQUM3RyxlQUFTLGFBQWEsY0FBYSxJQUFJO0FBQ3ZDLFlBQU0sT0FBSyxJQUFJLE1BQU0sY0FBYyxVQUFTLEtBQUssVUFBUyxRQUFRO0FBQ2xFLFdBQUssT0FBSyxRQUFNLFlBQVUscUJBQW1CO0FBQWdCLFdBQUssZ0JBQWM7QUFDaEYsV0FBSyxlQUFlLFNBQVMsTUFBTSxnQkFBZ0I7QUFBRSxXQUFLLGNBQVk7QUFBRyxXQUFLLFVBQVEsTUFBSTtBQUFBLE1BQUM7QUFDM0YsV0FBSyxhQUFXLEtBQUssZ0JBQWM7QUFDbkMsVUFBRyxPQUFPO0FBRVIsYUFBSyxlQUFlLE1BQU0sSUFBSSxNQUFNLEtBQUssZUFBZSxNQUFNLFNBQVMsR0FBRSxNQUFNLFFBQU0sRUFBRSxDQUFDO0FBQ3hGLFlBQUcsTUFBTSxLQUFLLGVBQWM7QUFBQyxlQUFLLFdBQVcsR0FBRSxLQUFLLEdBQUc7QUFBRSxlQUFLLGNBQWUsTUFBTSxJQUFJLE1BQU0sS0FBSyxjQUFjLE1BQU0sU0FBUyxHQUFFLE1BQU0sUUFBTSxDQUFDLENBQUM7QUFBQSxRQUFFO0FBQ2pKLGFBQUssTUFBTSxJQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVMsR0FBRSxNQUFNLFFBQU0sQ0FBQyxDQUFDO0FBQ3pELGFBQUssUUFBUSxLQUFLO0FBQUEsTUFDcEI7QUFDQSxjQUFNLEVBQUMsVUFBUyxNQUFLLE1BQUssVUFBUyxPQUFNLFNBQU8sR0FBRSxNQUFLLEtBQUssTUFBSztBQUFFLFdBQUssUUFBUSxJQUFJLEtBQUksS0FBSztBQUFFLFdBQUssTUFBTSxJQUFJLElBQUk7QUFBQSxJQUNwSDtBQUNBLFVBQU0sS0FBRyxNQUFNO0FBQVEsVUFBTSxPQUFLLEtBQUs7QUFDdkMsVUFBTSxLQUFLLFlBQVksSUFBRyxNQUFNO0FBQUUsVUFBTSxLQUFLLFdBQVcsSUFBRyxLQUFLLElBQUksSUFBSSxLQUFLLENBQUM7QUFBRSxVQUFNLEtBQUssUUFBUSxJQUFHLElBQUcsSUFBRyxPQUFNLEtBQUs7QUFBQSxFQUN6SDtBQUFBLEVBQ0EsU0FBUTtBQUNOLFFBQUcsS0FBSyxTQUFTO0FBQ2pCLGVBQVUsQ0FBQyxLQUFJLEtBQUssS0FBSyxLQUFLLFNBQVM7QUFDckMsWUFBTSxLQUFLLFFBQU0sTUFBTTtBQUFNLFlBQU0sS0FBSyxVQUFRLE1BQU0sUUFBTTtBQUM1RCxVQUFHLE1BQU0sT0FBTTtBQUFDLGNBQU0sS0FBSyxlQUFlLGNBQVk7QUFBSyxjQUFNLEtBQUssY0FBZSxjQUFZO0FBQUssY0FBTSxLQUFLLGNBQVk7QUFBQSxNQUFLLFdBQzFILEtBQUssUUFBTSxNQUFNLE9BQUssS0FBSTtBQUFDLGFBQUssUUFBUSxLQUFLO0FBQUUsYUFBSyxRQUFRLE9BQU8sR0FBRztBQUFBLE1BQUU7QUFBQSxJQUNsRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFFBQU87QUFBQyxlQUFVLFNBQVMsS0FBSyxRQUFRLE9BQU8sR0FBRTtBQUFDLFlBQU0sUUFBTTtBQUFFLFlBQU0sS0FBSyxRQUFNO0FBQUUsWUFBTSxLQUFLLFVBQVE7QUFBQSxJQUFNO0FBQUEsRUFBQztBQUFBLEVBQ3JHLFFBQVEsT0FBWTtBQUFDLFVBQU0sS0FBSyxpQkFBaUI7QUFBRSxVQUFNLEtBQUssUUFBUTtBQUFFLFVBQU0sS0FBSyxTQUFTLFFBQVE7QUFBQSxFQUFFO0FBQUEsRUFDOUcsVUFBUztBQUNQLFFBQUcsS0FBSyxTQUFTO0FBQU8sU0FBSyxXQUFTO0FBQ3RDLGVBQVUsU0FBUyxLQUFLLFFBQVEsT0FBTyxFQUFFLE1BQUssUUFBUSxLQUFLO0FBQUUsU0FBSyxRQUFRLE1BQU07QUFDaEYsZUFBVSxZQUFZLEtBQUssTUFBTSxPQUFPLEVBQUUsVUFBUyxRQUFRO0FBQUUsU0FBSyxNQUFNLE1BQU07QUFBRSxTQUFLLEtBQUssUUFBUTtBQUFFLFNBQUssU0FBUyxRQUFRO0FBQUEsRUFDNUg7QUFDRjsiLCJuYW1lcyI6W119