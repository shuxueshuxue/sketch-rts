import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};export class ResourceLoader {
  constructor(base, fetcher = void 0, clock = () => performance.now()) {
    this.base = base;
    this.fetcher = fetcher;
    this.clock = clock;
  }
  entries = /* @__PURE__ */ new Map();
  phase = "startup";
  assetsByPath = /* @__PURE__ */ new Map();
  sizesByUrl = /* @__PURE__ */ new Map();
  assetsByStage = /* @__PURE__ */ new Map();
  requests = /* @__PURE__ */ new Map();
  retainedBytes = /* @__PURE__ */ new Map();
  images = /* @__PURE__ */ new Map();
  decodedImages = /* @__PURE__ */ new Map();
  controllers = /* @__PURE__ */ new Set();
  generation = 0;
  listeners = /* @__PURE__ */ new Set();
  notificationQueued = false;
  progressTimer;
  active = 0;
  waiting = [];
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  changed() {
    if (this.progressTimer !== void 0) {
      clearTimeout(this.progressTimer);
      this.progressTimer = void 0;
    }
    if (this.notificationQueued || !this.listeners.size) return;
    this.notificationQueued = true;
    const generation = this.generation;
    queueMicrotask(() => {
      if (generation !== this.generation) return;
      this.notificationQueued = false;
      for (const listener of this.listeners) listener();
    });
  }
  progressChanged() {
    if (this.progressTimer !== void 0 || !this.listeners.size) return;
    this.progressTimer = setTimeout(() => {
      this.progressTimer = void 0;
      this.changed();
    }, 32);
  }
  async slot() {
    if (this.active >= 4) await new Promise((resolve) => this.waiting.push(resolve));
    else this.active++;
  }
  release() {
    const next = this.waiting.shift();
    if (next) next();
    else this.active--;
  }
  url(path) {
    const asset = this.assetsByPath.get(path);
    return `${this.base}${path}${asset?.revision && (asset.kind === "model" || asset.kind === "texture") ? `?v=${asset.revision}` : ""}`;
  }
  size(url) {
    return this.sizesByUrl.get(url);
  }
  async initialize() {
    const generation = this.generation, url = this.url("resource-manifest.json");
    const request = this.bytes(url, resourceText("资源目录", "Resource catalog"), "startup");
    try {
      const manifest = JSON.parse(new TextDecoder().decode(await request));
      if (generation !== this.generation) return;
      const byPath = /* @__PURE__ */ new Map(), byStage = /* @__PURE__ */ new Map();
      for (const asset of manifest.assets) {
        byPath.set(asset.url, asset);
        const stage = byStage.get(asset.stage) ?? [];
        stage.push(asset);
        byStage.set(asset.stage, stage);
      }
      this.assetsByPath = byPath;
      this.assetsByStage = byStage;
      this.sizesByUrl = new Map(manifest.assets.map((asset) => [this.url(asset.url), asset.bytes]));
    } catch {
    } finally {
      this.releaseBytes(url, request);
    }
  }
  async warm(stage, phase) {
    await Promise.all((this.assetsByStage.get(stage) ?? []).map((asset) => {
      const url = this.url(asset.url), browserOwned = asset.kind === "code" || asset.kind === "style" || asset.kind === "font";
      if (browserOwned && this.entries.get(url)?.state === "ready") {
        this.recordUse(url, phase);
        return;
      }
      const request = this.bytes(url, asset.url, phase);
      return browserOwned ? request.finally(() => this.releaseBytes(url, request)) : request;
    }));
  }
  /** Register reuse of a decoded resource without starting another byte request. */
  recordUse(url, phase = this.phase) {
    const entry = this.entries.get(url);
    if (entry && !entry.phases.has(phase)) {
      entry.phases.add(phase);
      this.changed();
    }
  }
  /** Decoders own their results. Releasing a completed byte cache never affects
   * callers already awaiting the same request; a later byte consumer can use HTTP cache. */
  releaseBytes(url, request) {
    if (request && this.requests.get(url) !== request) return;
    if (this.retainedBytes.delete(url)) this.requests.delete(url);
  }
  cacheStats() {
    return { requests: this.requests.size, images: this.images.size, retainedBytes: [...this.retainedBytes.values()].reduce((sum, bytes) => sum + bytes, 0), active: this.active, queued: this.waiting.length };
  }
  /** Application teardown only: renderer owners share these request/decode caches. */
  dispose() {
    this.generation++;
    for (const controller of this.controllers) controller.abort();
    if (this.progressTimer !== void 0) clearTimeout(this.progressTimer);
    this.progressTimer = void 0;
    this.notificationQueued = false;
    for (const image of this.decodedImages.values()) closeImage(image);
    this.images.clear();
    this.decodedImages.clear();
    this.requests.clear();
    this.retainedBytes.clear();
    this.entries.clear();
    this.listeners.clear();
    this.assetsByPath.clear();
    this.sizesByUrl.clear();
    this.assetsByStage.clear();
  }
  bytes(url, label = url, phase = this.phase) {
    const existing = this.entries.get(url);
    this.recordUse(url, phase);
    const known = this.requests.get(url);
    if (known) return known;
    const entry = { url, label, phases: existing?.phases ?? /* @__PURE__ */ new Set([phase]), expected: this.size(url), loaded: 0, state: "loading", elapsed: 0 };
    this.entries.set(url, entry);
    this.changed();
    const generation = this.generation, controller = new AbortController();
    let request;
    request = (async () => {
      await this.slot();
      const start = this.clock();
      try {
        if (generation !== this.generation) throw new Error("Resource loader was disposed");
        this.controllers.add(controller);
        const response = await (this.fetcher ?? fetch)(url, { cache: /\.json(?:\?|$)/.test(url) ? "no-cache" : "force-cache", signal: controller.signal });
        if (generation !== this.generation) throw new Error("Resource loader was disposed");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const length = Number(response.headers.get("content-length"));
        if (entry.expected === void 0 && !response.headers.get("content-encoding") && length > 0) entry.expected = length;
        let data;
        if (response.body) {
          const reader = response.body.getReader(), chunks = [], cancel = () => {
            void reader.cancel().catch(() => {
            });
          };
          controller.signal.addEventListener("abort", cancel, { once: true });
          try {
            while (true) {
              const result = await reader.read();
              if (result.done) break;
              chunks.push(result.value);
              entry.loaded += result.value.byteLength;
              entry.elapsed = this.clock() - start;
              this.progressChanged();
            }
          } finally {
            controller.signal.removeEventListener("abort", cancel);
            reader.releaseLock();
          }
          if (generation !== this.generation) throw new Error("Resource loader was disposed");
          const joined = new Uint8Array(entry.loaded);
          let offset = 0;
          for (const chunk of chunks) {
            joined.set(chunk, offset);
            offset += chunk.byteLength;
          }
          data = joined.buffer;
        } else {
          data = await response.arrayBuffer();
          entry.loaded = data.byteLength;
        }
        if (generation !== this.generation) throw new Error("Resource loader was disposed");
        entry.expected = data.byteLength;
        entry.state = "ready";
        this.retainedBytes.set(url, data.byteLength);
        return data;
      } catch (error) {
        entry.state = "failed";
        entry.error = error instanceof Error ? error.message : String(error);
        if (this.requests.get(url) === request) this.requests.delete(url);
        throw error;
      } finally {
        this.controllers.delete(controller);
        entry.elapsed = this.clock() - start;
        this.release();
        if (generation === this.generation) this.changed();
      }
    })();
    this.requests.set(url, request);
    return request;
  }
  image(url, label = url, phase = this.phase) {
    this.recordUse(url, phase);
    let image = this.images.get(url);
    if (!image) {
      const generation = this.generation, request = this.bytes(url, label, phase);
      image = request.then(async (buffer) => {
        const blob = new Blob([buffer]);
        let bitmap;
        if (typeof createImageBitmap === "function") bitmap = await createImageBitmap(blob);
        else {
          const address = URL.createObjectURL(blob);
          try {
            bitmap = await new Promise((resolve, reject) => {
              const bitmap2 = new Image();
              bitmap2.onload = () => resolve(bitmap2);
              bitmap2.onerror = () => reject(new Error(`无法解码 ${label}`));
              bitmap2.src = address;
            });
          } finally {
            URL.revokeObjectURL(address);
          }
        }
        if (generation !== this.generation) {
          closeImage(bitmap);
          throw new Error("Resource loader was disposed");
        }
        this.decodedImages.set(url, bitmap);
        return bitmap;
      }).catch((error) => {
        if (this.images.get(url) === image) this.images.delete(url);
        throw error;
      }).finally(() => this.releaseBytes(url, request));
      this.images.set(url, image);
    }
    return image;
  }
  summary(phase) {
    const entries = [...this.entries.values()].filter((entry) => entry.phases.has(phase));
    const loaded = entries.reduce((sum, entry) => sum + entry.loaded, 0), total = entries.reduce((sum, entry) => sum + (entry.expected ?? 0), 0);
    const unknown = entries.some((entry) => entry.expected === void 0);
    const reused = entries.filter((entry) => entry.state === "ready" && entry.phases.values().next().value !== phase).reduce((sum, entry) => sum + entry.loaded, 0);
    return { entries, loaded, total, unknown, reused, ready: entries.filter((entry) => entry.state === "ready").length, failed: entries.filter((entry) => entry.state === "failed").length };
  }
}
function closeImage(image) {
  if ("close" in image && typeof image.close === "function") image.close();
}
export function resourceSize(bytes) {
  return bytes < 1024 ? `${bytes} B` : bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)} KiB` : `${(bytes / 1024 / 1024).toFixed(2)} MiB`;
}
export const resources = new ResourceLoader(import.meta.env?.BASE_URL ?? "/");
export function resourceText(zh, en) {
  return typeof navigator !== "undefined" && [...navigator.languages.length ? navigator.languages : [navigator.language]].some((language) => language.toLowerCase().startsWith("zh")) ? zh : en;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc291cmNlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgdHlwZSBSZXNvdXJjZVBoYXNlID0gJ3N0YXJ0dXAnIHwgJ2hvbWUnIHwgJ21hdGNoJztcbmV4cG9ydCB0eXBlIFJlc291cmNlRW50cnkgPSB7IHVybDpzdHJpbmc7IGxhYmVsOnN0cmluZzsgcGhhc2VzOlNldDxSZXNvdXJjZVBoYXNlPjsgZXhwZWN0ZWQ6bnVtYmVyfHVuZGVmaW5lZDsgbG9hZGVkOm51bWJlcjsgc3RhdGU6J2xvYWRpbmcnfCdyZWFkeSd8J2ZhaWxlZCc7IGVsYXBzZWQ6bnVtYmVyOyBlcnJvcj86c3RyaW5nIH07XG5leHBvcnQgdHlwZSBSZXNvdXJjZU1hbmlmZXN0ID0geyBhc3NldHM6e3VybDpzdHJpbmc7Ynl0ZXM6bnVtYmVyO2tpbmQ6c3RyaW5nO3N0YWdlOnN0cmluZztyZXZpc2lvbj86c3RyaW5nfVtdIH07XG50eXBlIEZldGNoZXIgPSB0eXBlb2YgZmV0Y2g7XG5cbi8qKiBJbi1mbGlnaHQgYW5kIHJldGFpbmVkIGJ5dGUgcmVxdWVzdHMgYXJlIHNoYXJlZCBhY3Jvc3MgcGhhc2VzLiBDb3VudHMgYnl0ZXMgcmVhZCBmcm9tIHRoZSByZXNwb25zZSxcbiAqIG5vdCBzaW11bGF0ZWQgdGltZXIgcHJvZ3Jlc3M7IHVua25vd24gbGVuZ3RocyByZW1haW4gZXhwbGljaXRseSB1bmtub3duLiAqL1xuZXhwb3J0IGNsYXNzIFJlc291cmNlTG9hZGVyIHtcbiAgcmVhZG9ubHkgZW50cmllcz1uZXcgTWFwPHN0cmluZyxSZXNvdXJjZUVudHJ5PigpO1xuICBwaGFzZTpSZXNvdXJjZVBoYXNlPSdzdGFydHVwJztcbiAgcHJpdmF0ZSBhc3NldHNCeVBhdGg9bmV3IE1hcDxzdHJpbmcsUmVzb3VyY2VNYW5pZmVzdFsnYXNzZXRzJ11bbnVtYmVyXT4oKTtcbiAgcHJpdmF0ZSBzaXplc0J5VXJsPW5ldyBNYXA8c3RyaW5nLG51bWJlcj4oKTtcbiAgcHJpdmF0ZSBhc3NldHNCeVN0YWdlPW5ldyBNYXA8c3RyaW5nLFJlc291cmNlTWFuaWZlc3RbJ2Fzc2V0cyddPigpO1xuICBwcml2YXRlIHJlcXVlc3RzPW5ldyBNYXA8c3RyaW5nLFByb21pc2U8QXJyYXlCdWZmZXI+PigpO1xuICBwcml2YXRlIHJldGFpbmVkQnl0ZXM9bmV3IE1hcDxzdHJpbmcsbnVtYmVyPigpO1xuICBwcml2YXRlIGltYWdlcz1uZXcgTWFwPHN0cmluZyxQcm9taXNlPENhbnZhc0ltYWdlU291cmNlPj4oKTtcbiAgcHJpdmF0ZSBkZWNvZGVkSW1hZ2VzPW5ldyBNYXA8c3RyaW5nLENhbnZhc0ltYWdlU291cmNlPigpO1xuICBwcml2YXRlIGNvbnRyb2xsZXJzPW5ldyBTZXQ8QWJvcnRDb250cm9sbGVyPigpO1xuICBwcml2YXRlIGdlbmVyYXRpb249MDtcbiAgcHJpdmF0ZSBsaXN0ZW5lcnM9bmV3IFNldDwoKT0+dm9pZD4oKTtcbiAgcHJpdmF0ZSBub3RpZmljYXRpb25RdWV1ZWQ9ZmFsc2U7XG4gIHByaXZhdGUgcHJvZ3Jlc3NUaW1lcjpSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pnx1bmRlZmluZWQ7XG4gIHByaXZhdGUgYWN0aXZlPTA7XG4gIHByaXZhdGUgd2FpdGluZzooKCk9PnZvaWQpW109W107XG4gIGNvbnN0cnVjdG9yKHJlYWRvbmx5IGJhc2U6c3RyaW5nLHByaXZhdGUgZmV0Y2hlcjpGZXRjaGVyfHVuZGVmaW5lZD11bmRlZmluZWQscHJpdmF0ZSBjbG9jazooKT0+bnVtYmVyPSgpPT5wZXJmb3JtYW5jZS5ub3coKSl7fVxuICBzdWJzY3JpYmUobGlzdGVuZXI6KCk9PnZvaWQpe3RoaXMubGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7cmV0dXJuKCk9PnRoaXMubGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7fVxuICBwcml2YXRlIGNoYW5nZWQoKXtcbiAgICBpZih0aGlzLnByb2dyZXNzVGltZXIhPT11bmRlZmluZWQpe2NsZWFyVGltZW91dCh0aGlzLnByb2dyZXNzVGltZXIpO3RoaXMucHJvZ3Jlc3NUaW1lcj11bmRlZmluZWQ7fVxuICAgIGlmKHRoaXMubm90aWZpY2F0aW9uUXVldWVkIHx8ICF0aGlzLmxpc3RlbmVycy5zaXplKXJldHVybjtcbiAgICB0aGlzLm5vdGlmaWNhdGlvblF1ZXVlZD10cnVlO2NvbnN0IGdlbmVyYXRpb249dGhpcy5nZW5lcmF0aW9uO1xuICAgIHF1ZXVlTWljcm90YXNrKCgpPT57aWYoZ2VuZXJhdGlvbiE9PXRoaXMuZ2VuZXJhdGlvbilyZXR1cm47dGhpcy5ub3RpZmljYXRpb25RdWV1ZWQ9ZmFsc2U7Zm9yKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMubGlzdGVuZXJzKWxpc3RlbmVyKCk7fSk7XG4gIH1cbiAgcHJpdmF0ZSBwcm9ncmVzc0NoYW5nZWQoKXtcbiAgICBpZih0aGlzLnByb2dyZXNzVGltZXIhPT11bmRlZmluZWQgfHwgIXRoaXMubGlzdGVuZXJzLnNpemUpcmV0dXJuO1xuICAgIHRoaXMucHJvZ3Jlc3NUaW1lcj1zZXRUaW1lb3V0KCgpPT57dGhpcy5wcm9ncmVzc1RpbWVyPXVuZGVmaW5lZDt0aGlzLmNoYW5nZWQoKTt9LDMyKTtcbiAgfVxuICBwcml2YXRlIGFzeW5jIHNsb3QoKXtpZih0aGlzLmFjdGl2ZT49NClhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPihyZXNvbHZlPT50aGlzLndhaXRpbmcucHVzaChyZXNvbHZlKSk7ZWxzZSB0aGlzLmFjdGl2ZSsrO31cbiAgcHJpdmF0ZSByZWxlYXNlKCl7Y29uc3QgbmV4dD10aGlzLndhaXRpbmcuc2hpZnQoKTtpZihuZXh0KW5leHQoKTtlbHNlIHRoaXMuYWN0aXZlLS07fVxuICB1cmwocGF0aDpzdHJpbmcpe2NvbnN0IGFzc2V0PXRoaXMuYXNzZXRzQnlQYXRoLmdldChwYXRoKTtyZXR1cm4gYCR7dGhpcy5iYXNlfSR7cGF0aH0ke2Fzc2V0Py5yZXZpc2lvbiYmKGFzc2V0LmtpbmQ9PT0nbW9kZWwnfHxhc3NldC5raW5kPT09J3RleHR1cmUnKT9gP3Y9JHthc3NldC5yZXZpc2lvbn1gOicnfWA7fVxuICBzaXplKHVybDpzdHJpbmcpe3JldHVybiB0aGlzLnNpemVzQnlVcmwuZ2V0KHVybCk7fVxuICBhc3luYyBpbml0aWFsaXplKCl7XG4gICAgY29uc3QgZ2VuZXJhdGlvbj10aGlzLmdlbmVyYXRpb24sdXJsPXRoaXMudXJsKCdyZXNvdXJjZS1tYW5pZmVzdC5qc29uJyk7XG4gICAgY29uc3QgcmVxdWVzdD10aGlzLmJ5dGVzKHVybCxyZXNvdXJjZVRleHQoJ+i1hOa6kOebruW9lScsJ1Jlc291cmNlIGNhdGFsb2cnKSwnc3RhcnR1cCcpO1xuICAgIHRyeXtcbiAgICAgIGNvbnN0IG1hbmlmZXN0OlJlc291cmNlTWFuaWZlc3Q9SlNPTi5wYXJzZShuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoYXdhaXQgcmVxdWVzdCkpO1xuICAgICAgaWYoZ2VuZXJhdGlvbiE9PXRoaXMuZ2VuZXJhdGlvbilyZXR1cm47XG4gICAgICBjb25zdCBieVBhdGg9bmV3IE1hcDxzdHJpbmcsUmVzb3VyY2VNYW5pZmVzdFsnYXNzZXRzJ11bbnVtYmVyXT4oKSxieVN0YWdlPW5ldyBNYXA8c3RyaW5nLFJlc291cmNlTWFuaWZlc3RbJ2Fzc2V0cyddPigpO1xuICAgICAgZm9yKGNvbnN0IGFzc2V0IG9mIG1hbmlmZXN0LmFzc2V0cyl7YnlQYXRoLnNldChhc3NldC51cmwsYXNzZXQpO2NvbnN0IHN0YWdlPWJ5U3RhZ2UuZ2V0KGFzc2V0LnN0YWdlKT8/W107c3RhZ2UucHVzaChhc3NldCk7YnlTdGFnZS5zZXQoYXNzZXQuc3RhZ2Usc3RhZ2UpO31cbiAgICAgIHRoaXMuYXNzZXRzQnlQYXRoPWJ5UGF0aDt0aGlzLmFzc2V0c0J5U3RhZ2U9YnlTdGFnZTtcbiAgICAgIHRoaXMuc2l6ZXNCeVVybD1uZXcgTWFwKG1hbmlmZXN0LmFzc2V0cy5tYXAoYXNzZXQ9Plt0aGlzLnVybChhc3NldC51cmwpLGFzc2V0LmJ5dGVzXSkpO1xuICAgIH1jYXRjaHsvKiBEZXZlbG9wbWVudCBhbmQgb2xkZXIgaG9zdHMgY2FuIHJlcG9ydCBhY3R1YWwgYnl0ZXMgd2l0aG91dCBhIG1hbmlmZXN0LiAqL31cbiAgICBmaW5hbGx5e3RoaXMucmVsZWFzZUJ5dGVzKHVybCxyZXF1ZXN0KTt9XG4gIH1cbiAgYXN5bmMgd2FybShzdGFnZTpzdHJpbmcscGhhc2U6UmVzb3VyY2VQaGFzZSl7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoKHRoaXMuYXNzZXRzQnlTdGFnZS5nZXQoc3RhZ2UpPz9bXSkubWFwKGFzc2V0PT57XG4gICAgICBjb25zdCB1cmw9dGhpcy51cmwoYXNzZXQudXJsKSxicm93c2VyT3duZWQ9YXNzZXQua2luZD09PSdjb2RlJ3x8YXNzZXQua2luZD09PSdzdHlsZSd8fGFzc2V0LmtpbmQ9PT0nZm9udCc7XG4gICAgICAvLyBUaGVzZSByZXNvdXJjZXMgYXJlIGNvbnN1bWVkIGJ5IGltcG9ydC9DU1MsIHdoaWNoIGFscmVhZHkgb3ducyB0aGVpclxuICAgICAgLy8gZGVjb2RlZCBkYXRhLiBUaGVpciBmZXRjaCBvbmx5IHByaW1lcyBIVFRQIGNhY2hlLCBub3QgYSBzZWNvbmQgSlMgYnVmZmVyIGNhY2hlLlxuICAgICAgaWYoYnJvd3Nlck93bmVkJiZ0aGlzLmVudHJpZXMuZ2V0KHVybCk/LnN0YXRlPT09J3JlYWR5Jyl7dGhpcy5yZWNvcmRVc2UodXJsLHBoYXNlKTtyZXR1cm47fVxuICAgICAgY29uc3QgcmVxdWVzdD10aGlzLmJ5dGVzKHVybCxhc3NldC51cmwscGhhc2UpO1xuICAgICAgcmV0dXJuIGJyb3dzZXJPd25lZD9yZXF1ZXN0LmZpbmFsbHkoKCk9PnRoaXMucmVsZWFzZUJ5dGVzKHVybCxyZXF1ZXN0KSk6cmVxdWVzdDtcbiAgICB9KSk7XG4gIH1cbiAgLyoqIFJlZ2lzdGVyIHJldXNlIG9mIGEgZGVjb2RlZCByZXNvdXJjZSB3aXRob3V0IHN0YXJ0aW5nIGFub3RoZXIgYnl0ZSByZXF1ZXN0LiAqL1xuICByZWNvcmRVc2UodXJsOnN0cmluZyxwaGFzZTpSZXNvdXJjZVBoYXNlPXRoaXMucGhhc2Upe2NvbnN0IGVudHJ5PXRoaXMuZW50cmllcy5nZXQodXJsKTtpZihlbnRyeSYmIWVudHJ5LnBoYXNlcy5oYXMocGhhc2UpKXtlbnRyeS5waGFzZXMuYWRkKHBoYXNlKTt0aGlzLmNoYW5nZWQoKTt9fVxuICAvKiogRGVjb2RlcnMgb3duIHRoZWlyIHJlc3VsdHMuIFJlbGVhc2luZyBhIGNvbXBsZXRlZCBieXRlIGNhY2hlIG5ldmVyIGFmZmVjdHNcbiAgICogY2FsbGVycyBhbHJlYWR5IGF3YWl0aW5nIHRoZSBzYW1lIHJlcXVlc3Q7IGEgbGF0ZXIgYnl0ZSBjb25zdW1lciBjYW4gdXNlIEhUVFAgY2FjaGUuICovXG4gIHJlbGVhc2VCeXRlcyh1cmw6c3RyaW5nLHJlcXVlc3Q/OlByb21pc2U8QXJyYXlCdWZmZXI+KXtpZihyZXF1ZXN0JiZ0aGlzLnJlcXVlc3RzLmdldCh1cmwpIT09cmVxdWVzdClyZXR1cm47aWYodGhpcy5yZXRhaW5lZEJ5dGVzLmRlbGV0ZSh1cmwpKXRoaXMucmVxdWVzdHMuZGVsZXRlKHVybCk7fVxuICBjYWNoZVN0YXRzKCl7cmV0dXJue3JlcXVlc3RzOnRoaXMucmVxdWVzdHMuc2l6ZSxpbWFnZXM6dGhpcy5pbWFnZXMuc2l6ZSxyZXRhaW5lZEJ5dGVzOlsuLi50aGlzLnJldGFpbmVkQnl0ZXMudmFsdWVzKCldLnJlZHVjZSgoc3VtLGJ5dGVzKT0+c3VtK2J5dGVzLDApLGFjdGl2ZTp0aGlzLmFjdGl2ZSxxdWV1ZWQ6dGhpcy53YWl0aW5nLmxlbmd0aH07fVxuICAvKiogQXBwbGljYXRpb24gdGVhcmRvd24gb25seTogcmVuZGVyZXIgb3duZXJzIHNoYXJlIHRoZXNlIHJlcXVlc3QvZGVjb2RlIGNhY2hlcy4gKi9cbiAgZGlzcG9zZSgpe1xuICAgIHRoaXMuZ2VuZXJhdGlvbisrO2Zvcihjb25zdCBjb250cm9sbGVyIG9mIHRoaXMuY29udHJvbGxlcnMpY29udHJvbGxlci5hYm9ydCgpO1xuICAgIGlmKHRoaXMucHJvZ3Jlc3NUaW1lciE9PXVuZGVmaW5lZCljbGVhclRpbWVvdXQodGhpcy5wcm9ncmVzc1RpbWVyKTt0aGlzLnByb2dyZXNzVGltZXI9dW5kZWZpbmVkO3RoaXMubm90aWZpY2F0aW9uUXVldWVkPWZhbHNlO1xuICAgIGZvcihjb25zdCBpbWFnZSBvZiB0aGlzLmRlY29kZWRJbWFnZXMudmFsdWVzKCkpY2xvc2VJbWFnZShpbWFnZSk7XG4gICAgdGhpcy5pbWFnZXMuY2xlYXIoKTt0aGlzLmRlY29kZWRJbWFnZXMuY2xlYXIoKTt0aGlzLnJlcXVlc3RzLmNsZWFyKCk7dGhpcy5yZXRhaW5lZEJ5dGVzLmNsZWFyKCk7dGhpcy5lbnRyaWVzLmNsZWFyKCk7dGhpcy5saXN0ZW5lcnMuY2xlYXIoKTtcbiAgICB0aGlzLmFzc2V0c0J5UGF0aC5jbGVhcigpO3RoaXMuc2l6ZXNCeVVybC5jbGVhcigpO3RoaXMuYXNzZXRzQnlTdGFnZS5jbGVhcigpO1xuICB9XG4gIGJ5dGVzKHVybDpzdHJpbmcsbGFiZWw9dXJsLHBoYXNlOlJlc291cmNlUGhhc2U9dGhpcy5waGFzZSk6UHJvbWlzZTxBcnJheUJ1ZmZlcj57XG4gICAgY29uc3QgZXhpc3Rpbmc9dGhpcy5lbnRyaWVzLmdldCh1cmwpO3RoaXMucmVjb3JkVXNlKHVybCxwaGFzZSk7XG4gICAgY29uc3Qga25vd249dGhpcy5yZXF1ZXN0cy5nZXQodXJsKTtpZihrbm93bilyZXR1cm4ga25vd247XG4gICAgY29uc3QgZW50cnk6UmVzb3VyY2VFbnRyeT17dXJsLGxhYmVsLHBoYXNlczpleGlzdGluZz8ucGhhc2VzPz9uZXcgU2V0KFtwaGFzZV0pLGV4cGVjdGVkOnRoaXMuc2l6ZSh1cmwpLGxvYWRlZDowLHN0YXRlOidsb2FkaW5nJyxlbGFwc2VkOjB9O1xuICAgIHRoaXMuZW50cmllcy5zZXQodXJsLGVudHJ5KTt0aGlzLmNoYW5nZWQoKTtcbiAgICBjb25zdCBnZW5lcmF0aW9uPXRoaXMuZ2VuZXJhdGlvbixjb250cm9sbGVyPW5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBsZXQgcmVxdWVzdCE6UHJvbWlzZTxBcnJheUJ1ZmZlcj47cmVxdWVzdD0oYXN5bmMoKT0+e1xuICAgICAgYXdhaXQgdGhpcy5zbG90KCk7Y29uc3Qgc3RhcnQ9dGhpcy5jbG9jaygpO1xuICAgICAgdHJ5e1xuICAgICAgICBpZihnZW5lcmF0aW9uIT09dGhpcy5nZW5lcmF0aW9uKXRocm93IG5ldyBFcnJvcignUmVzb3VyY2UgbG9hZGVyIHdhcyBkaXNwb3NlZCcpO1xuICAgICAgICB0aGlzLmNvbnRyb2xsZXJzLmFkZChjb250cm9sbGVyKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2U9YXdhaXQgKHRoaXMuZmV0Y2hlcj8/ZmV0Y2gpKHVybCx7Y2FjaGU6L1xcLmpzb24oPzpcXD98JCkvLnRlc3QodXJsKT8nbm8tY2FjaGUnOidmb3JjZS1jYWNoZScsc2lnbmFsOmNvbnRyb2xsZXIuc2lnbmFsfSk7XG4gICAgICAgIGlmKGdlbmVyYXRpb24hPT10aGlzLmdlbmVyYXRpb24pdGhyb3cgbmV3IEVycm9yKCdSZXNvdXJjZSBsb2FkZXIgd2FzIGRpc3Bvc2VkJyk7XG4gICAgICAgIGlmKCFyZXNwb25zZS5vayl0aHJvdyBuZXcgRXJyb3IoYEhUVFAgJHtyZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgICAgIGNvbnN0IGxlbmd0aD1OdW1iZXIocmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtbGVuZ3RoJykpO1xuICAgICAgICBpZihlbnRyeS5leHBlY3RlZD09PXVuZGVmaW5lZCAmJiAhcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtZW5jb2RpbmcnKSAmJiBsZW5ndGg+MCllbnRyeS5leHBlY3RlZD1sZW5ndGg7XG4gICAgICAgIGxldCBkYXRhOkFycmF5QnVmZmVyO1xuICAgICAgICBpZihyZXNwb25zZS5ib2R5KXtcbiAgICAgICAgICBjb25zdCByZWFkZXI9cmVzcG9uc2UuYm9keS5nZXRSZWFkZXIoKSxjaHVua3M6VWludDhBcnJheVtdPVtdLGNhbmNlbD0oKT0+e3ZvaWQgcmVhZGVyLmNhbmNlbCgpLmNhdGNoKCgpPT57fSk7fTtcbiAgICAgICAgICBjb250cm9sbGVyLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsY2FuY2VsLHtvbmNlOnRydWV9KTtcbiAgICAgICAgICB0cnl7d2hpbGUodHJ1ZSl7Y29uc3QgcmVzdWx0PWF3YWl0IHJlYWRlci5yZWFkKCk7aWYocmVzdWx0LmRvbmUpYnJlYWs7Y2h1bmtzLnB1c2gocmVzdWx0LnZhbHVlKTtlbnRyeS5sb2FkZWQrPXJlc3VsdC52YWx1ZS5ieXRlTGVuZ3RoO2VudHJ5LmVsYXBzZWQ9dGhpcy5jbG9jaygpLXN0YXJ0O3RoaXMucHJvZ3Jlc3NDaGFuZ2VkKCk7fX1cbiAgICAgICAgICBmaW5hbGx5e2NvbnRyb2xsZXIuc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0JyxjYW5jZWwpO3JlYWRlci5yZWxlYXNlTG9jaygpO31cbiAgICAgICAgICBpZihnZW5lcmF0aW9uIT09dGhpcy5nZW5lcmF0aW9uKXRocm93IG5ldyBFcnJvcignUmVzb3VyY2UgbG9hZGVyIHdhcyBkaXNwb3NlZCcpO1xuICAgICAgICAgIGNvbnN0IGpvaW5lZD1uZXcgVWludDhBcnJheShlbnRyeS5sb2FkZWQpO2xldCBvZmZzZXQ9MDtmb3IoY29uc3QgY2h1bmsgb2YgY2h1bmtzKXtqb2luZWQuc2V0KGNodW5rLG9mZnNldCk7b2Zmc2V0Kz1jaHVuay5ieXRlTGVuZ3RoO31kYXRhPWpvaW5lZC5idWZmZXI7XG4gICAgICAgIH1lbHNle2RhdGE9YXdhaXQgcmVzcG9uc2UuYXJyYXlCdWZmZXIoKTtlbnRyeS5sb2FkZWQ9ZGF0YS5ieXRlTGVuZ3RoO31cbiAgICAgICAgaWYoZ2VuZXJhdGlvbiE9PXRoaXMuZ2VuZXJhdGlvbil0aHJvdyBuZXcgRXJyb3IoJ1Jlc291cmNlIGxvYWRlciB3YXMgZGlzcG9zZWQnKTtcbiAgICAgICAgZW50cnkuZXhwZWN0ZWQ9ZGF0YS5ieXRlTGVuZ3RoO2VudHJ5LnN0YXRlPSdyZWFkeSc7dGhpcy5yZXRhaW5lZEJ5dGVzLnNldCh1cmwsZGF0YS5ieXRlTGVuZ3RoKTtyZXR1cm4gZGF0YTtcbiAgICAgIH1jYXRjaChlcnJvcil7ZW50cnkuc3RhdGU9J2ZhaWxlZCc7ZW50cnkuZXJyb3I9ZXJyb3IgaW5zdGFuY2VvZiBFcnJvcj9lcnJvci5tZXNzYWdlOlN0cmluZyhlcnJvcik7aWYodGhpcy5yZXF1ZXN0cy5nZXQodXJsKT09PXJlcXVlc3QpdGhpcy5yZXF1ZXN0cy5kZWxldGUodXJsKTt0aHJvdyBlcnJvcjt9XG4gICAgICBmaW5hbGx5e3RoaXMuY29udHJvbGxlcnMuZGVsZXRlKGNvbnRyb2xsZXIpO2VudHJ5LmVsYXBzZWQ9dGhpcy5jbG9jaygpLXN0YXJ0O3RoaXMucmVsZWFzZSgpO2lmKGdlbmVyYXRpb249PT10aGlzLmdlbmVyYXRpb24pdGhpcy5jaGFuZ2VkKCk7fVxuICAgIH0pKCk7XG4gICAgdGhpcy5yZXF1ZXN0cy5zZXQodXJsLHJlcXVlc3QpO3JldHVybiByZXF1ZXN0O1xuICB9XG4gIGltYWdlKHVybDpzdHJpbmcsbGFiZWw9dXJsLHBoYXNlOlJlc291cmNlUGhhc2U9dGhpcy5waGFzZSl7XG4gICAgLy8gUmVnaXN0ZXIgc2hhcmVkIHVzZSBldmVuIGlmIHRoZSBkZWNvZGVkIGJpdG1hcCBhbHJlYWR5IGV4aXN0cy5cbiAgICB0aGlzLnJlY29yZFVzZSh1cmwscGhhc2UpO1xuICAgIGxldCBpbWFnZT10aGlzLmltYWdlcy5nZXQodXJsKTtpZighaW1hZ2Upe2NvbnN0IGdlbmVyYXRpb249dGhpcy5nZW5lcmF0aW9uLHJlcXVlc3Q9dGhpcy5ieXRlcyh1cmwsbGFiZWwscGhhc2UpO2ltYWdlPXJlcXVlc3QudGhlbihhc3luYyBidWZmZXI9PntcbiAgICAgIGNvbnN0IGJsb2I9bmV3IEJsb2IoW2J1ZmZlcl0pO2xldCBiaXRtYXA6Q2FudmFzSW1hZ2VTb3VyY2U7XG4gICAgICBpZih0eXBlb2YgY3JlYXRlSW1hZ2VCaXRtYXA9PT0nZnVuY3Rpb24nKWJpdG1hcD1hd2FpdCBjcmVhdGVJbWFnZUJpdG1hcChibG9iKTtcbiAgICAgIGVsc2V7Y29uc3QgYWRkcmVzcz1VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO3RyeXtiaXRtYXA9YXdhaXQgbmV3IFByb21pc2U8SFRNTEltYWdlRWxlbWVudD4oKHJlc29sdmUscmVqZWN0KT0+e2NvbnN0IGJpdG1hcD1uZXcgSW1hZ2UoKTtiaXRtYXAub25sb2FkPSgpPT5yZXNvbHZlKGJpdG1hcCk7Yml0bWFwLm9uZXJyb3I9KCk9PnJlamVjdChuZXcgRXJyb3IoYOaXoOazleino+eggSAke2xhYmVsfWApKTtiaXRtYXAuc3JjPWFkZHJlc3M7fSk7fWZpbmFsbHl7VVJMLnJldm9rZU9iamVjdFVSTChhZGRyZXNzKTt9fVxuICAgICAgaWYoZ2VuZXJhdGlvbiE9PXRoaXMuZ2VuZXJhdGlvbil7Y2xvc2VJbWFnZShiaXRtYXApO3Rocm93IG5ldyBFcnJvcignUmVzb3VyY2UgbG9hZGVyIHdhcyBkaXNwb3NlZCcpO31cbiAgICAgIHRoaXMuZGVjb2RlZEltYWdlcy5zZXQodXJsLGJpdG1hcCk7cmV0dXJuIGJpdG1hcDtcbiAgICB9KS5jYXRjaChlcnJvcj0+e2lmKHRoaXMuaW1hZ2VzLmdldCh1cmwpPT09aW1hZ2UpdGhpcy5pbWFnZXMuZGVsZXRlKHVybCk7dGhyb3cgZXJyb3I7fSkuZmluYWxseSgoKT0+dGhpcy5yZWxlYXNlQnl0ZXModXJsLHJlcXVlc3QpKTt0aGlzLmltYWdlcy5zZXQodXJsLGltYWdlKTt9cmV0dXJuIGltYWdlO1xuICB9XG4gIHN1bW1hcnkocGhhc2U6UmVzb3VyY2VQaGFzZSl7XG4gICAgY29uc3QgZW50cmllcz1bLi4udGhpcy5lbnRyaWVzLnZhbHVlcygpXS5maWx0ZXIoZW50cnk9PmVudHJ5LnBoYXNlcy5oYXMocGhhc2UpKTtcbiAgICBjb25zdCBsb2FkZWQ9ZW50cmllcy5yZWR1Y2UoKHN1bSxlbnRyeSk9PnN1bStlbnRyeS5sb2FkZWQsMCksdG90YWw9ZW50cmllcy5yZWR1Y2UoKHN1bSxlbnRyeSk9PnN1bSsoZW50cnkuZXhwZWN0ZWQ/PzApLDApO1xuICAgIGNvbnN0IHVua25vd249ZW50cmllcy5zb21lKGVudHJ5PT5lbnRyeS5leHBlY3RlZD09PXVuZGVmaW5lZCk7XG4gICAgY29uc3QgcmV1c2VkPWVudHJpZXMuZmlsdGVyKGVudHJ5PT5lbnRyeS5zdGF0ZT09PSdyZWFkeScmJmVudHJ5LnBoYXNlcy52YWx1ZXMoKS5uZXh0KCkudmFsdWUhPT1waGFzZSkucmVkdWNlKChzdW0sZW50cnkpPT5zdW0rZW50cnkubG9hZGVkLDApO1xuICAgIHJldHVybntlbnRyaWVzLGxvYWRlZCx0b3RhbCx1bmtub3duLHJldXNlZCxyZWFkeTplbnRyaWVzLmZpbHRlcihlbnRyeT0+ZW50cnkuc3RhdGU9PT0ncmVhZHknKS5sZW5ndGgsZmFpbGVkOmVudHJpZXMuZmlsdGVyKGVudHJ5PT5lbnRyeS5zdGF0ZT09PSdmYWlsZWQnKS5sZW5ndGh9O1xuICB9XG59XG5mdW5jdGlvbiBjbG9zZUltYWdlKGltYWdlOkNhbnZhc0ltYWdlU291cmNlKXtpZignY2xvc2UnIGluIGltYWdlICYmIHR5cGVvZiBpbWFnZS5jbG9zZT09PSdmdW5jdGlvbicpaW1hZ2UuY2xvc2UoKTt9XG5leHBvcnQgZnVuY3Rpb24gcmVzb3VyY2VTaXplKGJ5dGVzOm51bWJlcil7cmV0dXJuIGJ5dGVzPDEwMjQ/YCR7Ynl0ZXN9IEJgOmJ5dGVzPDEwMjQqMTAyND9gJHsoYnl0ZXMvMTAyNCkudG9GaXhlZCgxKX0gS2lCYDpgJHsoYnl0ZXMvMTAyNC8xMDI0KS50b0ZpeGVkKDIpfSBNaUJgO31cbmV4cG9ydCBjb25zdCByZXNvdXJjZXM9bmV3IFJlc291cmNlTG9hZGVyKChpbXBvcnQubWV0YSBhcyBJbXBvcnRNZXRhICYge2Vudj86e0JBU0VfVVJMPzpzdHJpbmd9fSkuZW52Py5CQVNFX1VSTD8/Jy8nKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHJlc291cmNlVGV4dCh6aDpzdHJpbmcsZW46c3RyaW5nKXtyZXR1cm4gdHlwZW9mIG5hdmlnYXRvciE9PSd1bmRlZmluZWQnICYmIFsuLi4obmF2aWdhdG9yLmxhbmd1YWdlcy5sZW5ndGg/bmF2aWdhdG9yLmxhbmd1YWdlczpbbmF2aWdhdG9yLmxhbmd1YWdlXSldLnNvbWUobGFuZ3VhZ2U9Pmxhbmd1YWdlLnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aCgnemgnKSk/emg6ZW47fVxuIl0sIm1hcHBpbmdzIjoiQUFPTyxhQUFNLGVBQWU7QUFBQSxFQWlCMUIsWUFBcUIsTUFBb0IsVUFBMEIsUUFBa0IsUUFBaUIsTUFBSSxZQUFZLElBQUksR0FBRTtBQUF2RztBQUFvQjtBQUE0QztBQUFBLEVBQXdDO0FBQUEsRUFoQnBILFVBQVEsb0JBQUksSUFBMEI7QUFBQSxFQUMvQyxRQUFvQjtBQUFBLEVBQ1osZUFBYSxvQkFBSSxJQUErQztBQUFBLEVBQ2hFLGFBQVcsb0JBQUksSUFBbUI7QUFBQSxFQUNsQyxnQkFBYyxvQkFBSSxJQUF1QztBQUFBLEVBQ3pELFdBQVMsb0JBQUksSUFBaUM7QUFBQSxFQUM5QyxnQkFBYyxvQkFBSSxJQUFtQjtBQUFBLEVBQ3JDLFNBQU8sb0JBQUksSUFBdUM7QUFBQSxFQUNsRCxnQkFBYyxvQkFBSSxJQUE4QjtBQUFBLEVBQ2hELGNBQVksb0JBQUksSUFBcUI7QUFBQSxFQUNyQyxhQUFXO0FBQUEsRUFDWCxZQUFVLG9CQUFJLElBQWM7QUFBQSxFQUM1QixxQkFBbUI7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsU0FBTztBQUFBLEVBQ1AsVUFBcUIsQ0FBQztBQUFBLEVBRTlCLFVBQVUsVUFBa0I7QUFBQyxTQUFLLFVBQVUsSUFBSSxRQUFRO0FBQUUsV0FBTSxNQUFJLEtBQUssVUFBVSxPQUFPLFFBQVE7QUFBQSxFQUFFO0FBQUEsRUFDNUYsVUFBUztBQUNmLFFBQUcsS0FBSyxrQkFBZ0IsUUFBVTtBQUFDLG1CQUFhLEtBQUssYUFBYTtBQUFFLFdBQUssZ0JBQWM7QUFBQSxJQUFVO0FBQ2pHLFFBQUcsS0FBSyxzQkFBc0IsQ0FBQyxLQUFLLFVBQVUsS0FBSztBQUNuRCxTQUFLLHFCQUFtQjtBQUFLLFVBQU0sYUFBVyxLQUFLO0FBQ25ELG1CQUFlLE1BQUk7QUFBQyxVQUFHLGVBQWEsS0FBSyxXQUFXO0FBQU8sV0FBSyxxQkFBbUI7QUFBTSxpQkFBVSxZQUFZLEtBQUssVUFBVSxVQUFTO0FBQUEsSUFBRSxDQUFDO0FBQUEsRUFDNUk7QUFBQSxFQUNRLGtCQUFpQjtBQUN2QixRQUFHLEtBQUssa0JBQWdCLFVBQWEsQ0FBQyxLQUFLLFVBQVUsS0FBSztBQUMxRCxTQUFLLGdCQUFjLFdBQVcsTUFBSTtBQUFDLFdBQUssZ0JBQWM7QUFBVSxXQUFLLFFBQVE7QUFBQSxJQUFFLEdBQUUsRUFBRTtBQUFBLEVBQ3JGO0FBQUEsRUFDQSxNQUFjLE9BQU07QUFBQyxRQUFHLEtBQUssVUFBUSxFQUFFLE9BQU0sSUFBSSxRQUFjLGFBQVMsS0FBSyxRQUFRLEtBQUssT0FBTyxDQUFDO0FBQUEsUUFBTyxNQUFLO0FBQUEsRUFBUztBQUFBLEVBQy9HLFVBQVM7QUFBQyxVQUFNLE9BQUssS0FBSyxRQUFRLE1BQU07QUFBRSxRQUFHLEtBQUssTUFBSztBQUFBLFFBQU8sTUFBSztBQUFBLEVBQVM7QUFBQSxFQUNwRixJQUFJLE1BQVk7QUFBQyxVQUFNLFFBQU0sS0FBSyxhQUFhLElBQUksSUFBSTtBQUFFLFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxhQUFXLE1BQU0sU0FBTyxXQUFTLE1BQU0sU0FBTyxhQUFXLE1BQU0sTUFBTSxRQUFRLEtBQUcsRUFBRTtBQUFBLEVBQUc7QUFBQSxFQUNsTCxLQUFLLEtBQVc7QUFBQyxXQUFPLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFBQSxFQUFFO0FBQUEsRUFDakQsTUFBTSxhQUFZO0FBQ2hCLFVBQU0sYUFBVyxLQUFLLFlBQVcsTUFBSSxLQUFLLElBQUksd0JBQXdCO0FBQ3RFLFVBQU0sVUFBUSxLQUFLLE1BQU0sS0FBSSxhQUFhLFFBQU8sa0JBQWtCLEdBQUUsU0FBUztBQUM5RSxRQUFHO0FBQ0QsWUFBTSxXQUEwQixLQUFLLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxNQUFNLE9BQU8sQ0FBQztBQUNsRixVQUFHLGVBQWEsS0FBSyxXQUFXO0FBQ2hDLFlBQU0sU0FBTyxvQkFBSSxJQUErQyxHQUFFLFVBQVEsb0JBQUksSUFBdUM7QUFDckgsaUJBQVUsU0FBUyxTQUFTLFFBQU87QUFBQyxlQUFPLElBQUksTUFBTSxLQUFJLEtBQUs7QUFBRSxjQUFNLFFBQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxLQUFHLENBQUM7QUFBRSxjQUFNLEtBQUssS0FBSztBQUFFLGdCQUFRLElBQUksTUFBTSxPQUFNLEtBQUs7QUFBQSxNQUFFO0FBQzFKLFdBQUssZUFBYTtBQUFPLFdBQUssZ0JBQWM7QUFDNUMsV0FBSyxhQUFXLElBQUksSUFBSSxTQUFTLE9BQU8sSUFBSSxXQUFPLENBQUMsS0FBSyxJQUFJLE1BQU0sR0FBRyxHQUFFLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFBQSxJQUN2RixRQUFNO0FBQUEsSUFBOEUsVUFDcEY7QUFBUSxXQUFLLGFBQWEsS0FBSSxPQUFPO0FBQUEsSUFBRTtBQUFBLEVBQ3pDO0FBQUEsRUFDQSxNQUFNLEtBQUssT0FBYSxPQUFvQjtBQUMxQyxVQUFNLFFBQVEsS0FBSyxLQUFLLGNBQWMsSUFBSSxLQUFLLEtBQUcsQ0FBQyxHQUFHLElBQUksV0FBTztBQUMvRCxZQUFNLE1BQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxHQUFFLGVBQWEsTUFBTSxTQUFPLFVBQVEsTUFBTSxTQUFPLFdBQVMsTUFBTSxTQUFPO0FBR25HLFVBQUcsZ0JBQWMsS0FBSyxRQUFRLElBQUksR0FBRyxHQUFHLFVBQVEsU0FBUTtBQUFDLGFBQUssVUFBVSxLQUFJLEtBQUs7QUFBRTtBQUFBLE1BQU87QUFDMUYsWUFBTSxVQUFRLEtBQUssTUFBTSxLQUFJLE1BQU0sS0FBSSxLQUFLO0FBQzVDLGFBQU8sZUFBYSxRQUFRLFFBQVEsTUFBSSxLQUFLLGFBQWEsS0FBSSxPQUFPLENBQUMsSUFBRTtBQUFBLElBQzFFLENBQUMsQ0FBQztBQUFBLEVBQ0o7QUFBQTtBQUFBLEVBRUEsVUFBVSxLQUFXLFFBQW9CLEtBQUssT0FBTTtBQUFDLFVBQU0sUUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQUUsUUFBRyxTQUFPLENBQUMsTUFBTSxPQUFPLElBQUksS0FBSyxHQUFFO0FBQUMsWUFBTSxPQUFPLElBQUksS0FBSztBQUFFLFdBQUssUUFBUTtBQUFBLElBQUU7QUFBQSxFQUFDO0FBQUE7QUFBQTtBQUFBLEVBR25LLGFBQWEsS0FBVyxTQUE4QjtBQUFDLFFBQUcsV0FBUyxLQUFLLFNBQVMsSUFBSSxHQUFHLE1BQUksUUFBUTtBQUFPLFFBQUcsS0FBSyxjQUFjLE9BQU8sR0FBRyxFQUFFLE1BQUssU0FBUyxPQUFPLEdBQUc7QUFBQSxFQUFFO0FBQUEsRUFDdkssYUFBWTtBQUFDLFdBQU0sRUFBQyxVQUFTLEtBQUssU0FBUyxNQUFLLFFBQU8sS0FBSyxPQUFPLE1BQUssZUFBYyxDQUFDLEdBQUcsS0FBSyxjQUFjLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFJLFVBQVEsTUFBSSxPQUFNLENBQUMsR0FBRSxRQUFPLEtBQUssUUFBTyxRQUFPLEtBQUssUUFBUSxPQUFNO0FBQUEsRUFBRTtBQUFBO0FBQUEsRUFFdk0sVUFBUztBQUNQLFNBQUs7QUFBYSxlQUFVLGNBQWMsS0FBSyxZQUFZLFlBQVcsTUFBTTtBQUM1RSxRQUFHLEtBQUssa0JBQWdCLE9BQVUsY0FBYSxLQUFLLGFBQWE7QUFBRSxTQUFLLGdCQUFjO0FBQVUsU0FBSyxxQkFBbUI7QUFDeEgsZUFBVSxTQUFTLEtBQUssY0FBYyxPQUFPLEVBQUUsWUFBVyxLQUFLO0FBQy9ELFNBQUssT0FBTyxNQUFNO0FBQUUsU0FBSyxjQUFjLE1BQU07QUFBRSxTQUFLLFNBQVMsTUFBTTtBQUFFLFNBQUssY0FBYyxNQUFNO0FBQUUsU0FBSyxRQUFRLE1BQU07QUFBRSxTQUFLLFVBQVUsTUFBTTtBQUMxSSxTQUFLLGFBQWEsTUFBTTtBQUFFLFNBQUssV0FBVyxNQUFNO0FBQUUsU0FBSyxjQUFjLE1BQU07QUFBQSxFQUM3RTtBQUFBLEVBQ0EsTUFBTSxLQUFXLFFBQU0sS0FBSSxRQUFvQixLQUFLLE9BQTJCO0FBQzdFLFVBQU0sV0FBUyxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQUUsU0FBSyxVQUFVLEtBQUksS0FBSztBQUM3RCxVQUFNLFFBQU0sS0FBSyxTQUFTLElBQUksR0FBRztBQUFFLFFBQUcsTUFBTSxRQUFPO0FBQ25ELFVBQU0sUUFBb0IsRUFBQyxLQUFJLE9BQU0sUUFBTyxVQUFVLFVBQVEsb0JBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFFLFVBQVMsS0FBSyxLQUFLLEdBQUcsR0FBRSxRQUFPLEdBQUUsT0FBTSxXQUFVLFNBQVEsRUFBQztBQUN6SSxTQUFLLFFBQVEsSUFBSSxLQUFJLEtBQUs7QUFBRSxTQUFLLFFBQVE7QUFDekMsVUFBTSxhQUFXLEtBQUssWUFBVyxhQUFXLElBQUksZ0JBQWdCO0FBQ2hFLFFBQUk7QUFBOEIsZUFBUyxZQUFTO0FBQ2xELFlBQU0sS0FBSyxLQUFLO0FBQUUsWUFBTSxRQUFNLEtBQUssTUFBTTtBQUN6QyxVQUFHO0FBQ0QsWUFBRyxlQUFhLEtBQUssV0FBVyxPQUFNLElBQUksTUFBTSw4QkFBOEI7QUFDOUUsYUFBSyxZQUFZLElBQUksVUFBVTtBQUMvQixjQUFNLFdBQVMsT0FBTyxLQUFLLFdBQVMsT0FBTyxLQUFJLEVBQUMsT0FBTSxpQkFBaUIsS0FBSyxHQUFHLElBQUUsYUFBVyxlQUFjLFFBQU8sV0FBVyxPQUFNLENBQUM7QUFDbkksWUFBRyxlQUFhLEtBQUssV0FBVyxPQUFNLElBQUksTUFBTSw4QkFBOEI7QUFDOUUsWUFBRyxDQUFDLFNBQVMsR0FBRyxPQUFNLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ3pELGNBQU0sU0FBTyxPQUFPLFNBQVMsUUFBUSxJQUFJLGdCQUFnQixDQUFDO0FBQzFELFlBQUcsTUFBTSxhQUFXLFVBQWEsQ0FBQyxTQUFTLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxTQUFPLEVBQUUsT0FBTSxXQUFTO0FBQ3RHLFlBQUk7QUFDSixZQUFHLFNBQVMsTUFBSztBQUNmLGdCQUFNLFNBQU8sU0FBUyxLQUFLLFVBQVUsR0FBRSxTQUFvQixDQUFDLEdBQUUsU0FBTyxNQUFJO0FBQUMsaUJBQUssT0FBTyxPQUFPLEVBQUUsTUFBTSxNQUFJO0FBQUEsWUFBQyxDQUFDO0FBQUEsVUFBRTtBQUM3RyxxQkFBVyxPQUFPLGlCQUFpQixTQUFRLFFBQU8sRUFBQyxNQUFLLEtBQUksQ0FBQztBQUM3RCxjQUFHO0FBQUMsbUJBQU0sTUFBSztBQUFDLG9CQUFNLFNBQU8sTUFBTSxPQUFPLEtBQUs7QUFBRSxrQkFBRyxPQUFPLEtBQUs7QUFBTSxxQkFBTyxLQUFLLE9BQU8sS0FBSztBQUFFLG9CQUFNLFVBQVEsT0FBTyxNQUFNO0FBQVcsb0JBQU0sVUFBUSxLQUFLLE1BQU0sSUFBRTtBQUFNLG1CQUFLLGdCQUFnQjtBQUFBLFlBQUU7QUFBQSxVQUFDLFVBQy9MO0FBQVEsdUJBQVcsT0FBTyxvQkFBb0IsU0FBUSxNQUFNO0FBQUUsbUJBQU8sWUFBWTtBQUFBLFVBQUU7QUFDbkYsY0FBRyxlQUFhLEtBQUssV0FBVyxPQUFNLElBQUksTUFBTSw4QkFBOEI7QUFDOUUsZ0JBQU0sU0FBTyxJQUFJLFdBQVcsTUFBTSxNQUFNO0FBQUUsY0FBSSxTQUFPO0FBQUUscUJBQVUsU0FBUyxRQUFPO0FBQUMsbUJBQU8sSUFBSSxPQUFNLE1BQU07QUFBRSxzQkFBUSxNQUFNO0FBQUEsVUFBVztBQUFDLGlCQUFLLE9BQU87QUFBQSxRQUNuSixPQUFLO0FBQUMsaUJBQUssTUFBTSxTQUFTLFlBQVk7QUFBRSxnQkFBTSxTQUFPLEtBQUs7QUFBQSxRQUFXO0FBQ3JFLFlBQUcsZUFBYSxLQUFLLFdBQVcsT0FBTSxJQUFJLE1BQU0sOEJBQThCO0FBQzlFLGNBQU0sV0FBUyxLQUFLO0FBQVcsY0FBTSxRQUFNO0FBQVEsYUFBSyxjQUFjLElBQUksS0FBSSxLQUFLLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFDeEcsU0FBTyxPQUFNO0FBQUMsY0FBTSxRQUFNO0FBQVMsY0FBTSxRQUFNLGlCQUFpQixRQUFNLE1BQU0sVUFBUSxPQUFPLEtBQUs7QUFBRSxZQUFHLEtBQUssU0FBUyxJQUFJLEdBQUcsTUFBSSxRQUFRLE1BQUssU0FBUyxPQUFPLEdBQUc7QUFBRSxjQUFNO0FBQUEsTUFBTSxVQUM1SztBQUFRLGFBQUssWUFBWSxPQUFPLFVBQVU7QUFBRSxjQUFNLFVBQVEsS0FBSyxNQUFNLElBQUU7QUFBTSxhQUFLLFFBQVE7QUFBRSxZQUFHLGVBQWEsS0FBSyxXQUFXLE1BQUssUUFBUTtBQUFBLE1BQUU7QUFBQSxJQUM3SSxHQUFHO0FBQ0gsU0FBSyxTQUFTLElBQUksS0FBSSxPQUFPO0FBQUUsV0FBTztBQUFBLEVBQ3hDO0FBQUEsRUFDQSxNQUFNLEtBQVcsUUFBTSxLQUFJLFFBQW9CLEtBQUssT0FBTTtBQUV4RCxTQUFLLFVBQVUsS0FBSSxLQUFLO0FBQ3hCLFFBQUksUUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQUUsUUFBRyxDQUFDLE9BQU07QUFBQyxZQUFNLGFBQVcsS0FBSyxZQUFXLFVBQVEsS0FBSyxNQUFNLEtBQUksT0FBTSxLQUFLO0FBQUUsY0FBTSxRQUFRLEtBQUssT0FBTSxXQUFRO0FBQzlJLGNBQU0sT0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFBRSxZQUFJO0FBQ2xDLFlBQUcsT0FBTyxzQkFBb0IsV0FBVyxVQUFPLE1BQU0sa0JBQWtCLElBQUk7QUFBQSxhQUN4RTtBQUFDLGdCQUFNLFVBQVEsSUFBSSxnQkFBZ0IsSUFBSTtBQUFFLGNBQUc7QUFBQyxxQkFBTyxNQUFNLElBQUksUUFBMEIsQ0FBQyxTQUFRLFdBQVM7QUFBQyxvQkFBTUEsVUFBTyxJQUFJLE1BQU07QUFBRSxjQUFBQSxRQUFPLFNBQU8sTUFBSSxRQUFRQSxPQUFNO0FBQUUsY0FBQUEsUUFBTyxVQUFRLE1BQUksT0FBTyxJQUFJLE1BQU0sUUFBUSxLQUFLLEVBQUUsQ0FBQztBQUFFLGNBQUFBLFFBQU8sTUFBSTtBQUFBLFlBQVEsQ0FBQztBQUFBLFVBQUUsVUFBQztBQUFRLGdCQUFJLGdCQUFnQixPQUFPO0FBQUEsVUFBRTtBQUFBLFFBQUM7QUFDN1IsWUFBRyxlQUFhLEtBQUssWUFBVztBQUFDLHFCQUFXLE1BQU07QUFBRSxnQkFBTSxJQUFJLE1BQU0sOEJBQThCO0FBQUEsUUFBRTtBQUNwRyxhQUFLLGNBQWMsSUFBSSxLQUFJLE1BQU07QUFBRSxlQUFPO0FBQUEsTUFDNUMsQ0FBQyxFQUFFLE1BQU0sV0FBTztBQUFDLFlBQUcsS0FBSyxPQUFPLElBQUksR0FBRyxNQUFJLE1BQU0sTUFBSyxPQUFPLE9BQU8sR0FBRztBQUFFLGNBQU07QUFBQSxNQUFNLENBQUMsRUFBRSxRQUFRLE1BQUksS0FBSyxhQUFhLEtBQUksT0FBTyxDQUFDO0FBQUUsV0FBSyxPQUFPLElBQUksS0FBSSxLQUFLO0FBQUEsSUFBRTtBQUFDLFdBQU87QUFBQSxFQUN6SztBQUFBLEVBQ0EsUUFBUSxPQUFvQjtBQUMxQixVQUFNLFVBQVEsQ0FBQyxHQUFHLEtBQUssUUFBUSxPQUFPLENBQUMsRUFBRSxPQUFPLFdBQU8sTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDO0FBQzlFLFVBQU0sU0FBTyxRQUFRLE9BQU8sQ0FBQyxLQUFJLFVBQVEsTUFBSSxNQUFNLFFBQU8sQ0FBQyxHQUFFLFFBQU0sUUFBUSxPQUFPLENBQUMsS0FBSSxVQUFRLE9BQUssTUFBTSxZQUFVLElBQUcsQ0FBQztBQUN4SCxVQUFNLFVBQVEsUUFBUSxLQUFLLFdBQU8sTUFBTSxhQUFXLE1BQVM7QUFDNUQsVUFBTSxTQUFPLFFBQVEsT0FBTyxXQUFPLE1BQU0sVUFBUSxXQUFTLE1BQU0sT0FBTyxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVEsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFJLFVBQVEsTUFBSSxNQUFNLFFBQU8sQ0FBQztBQUM1SSxXQUFNLEVBQUMsU0FBUSxRQUFPLE9BQU0sU0FBUSxRQUFPLE9BQU0sUUFBUSxPQUFPLFdBQU8sTUFBTSxVQUFRLE9BQU8sRUFBRSxRQUFPLFFBQU8sUUFBUSxPQUFPLFdBQU8sTUFBTSxVQUFRLFFBQVEsRUFBRSxPQUFNO0FBQUEsRUFDbEs7QUFDRjtBQUNBLFNBQVMsV0FBVyxPQUF3QjtBQUFDLE1BQUcsV0FBVyxTQUFTLE9BQU8sTUFBTSxVQUFRLFdBQVcsT0FBTSxNQUFNO0FBQUU7QUFDM0csZ0JBQVMsYUFBYSxPQUFhO0FBQUMsU0FBTyxRQUFNLE9BQUssR0FBRyxLQUFLLE9BQUssUUFBTSxPQUFLLE9BQUssSUFBSSxRQUFNLE1BQU0sUUFBUSxDQUFDLENBQUMsU0FBTyxJQUFJLFFBQU0sT0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDO0FBQU87QUFDMUosYUFBTSxZQUFVLElBQUksZUFBZ0IsWUFBdUQsS0FBSyxZQUFVLEdBQUc7QUFFN0csZ0JBQVMsYUFBYSxJQUFVLElBQVU7QUFBQyxTQUFPLE9BQU8sY0FBWSxlQUFlLENBQUMsR0FBSSxVQUFVLFVBQVUsU0FBTyxVQUFVLFlBQVUsQ0FBQyxVQUFVLFFBQVEsQ0FBRSxFQUFFLEtBQUssY0FBVSxTQUFTLFlBQVksRUFBRSxXQUFXLElBQUksQ0FBQyxJQUFFLEtBQUc7QUFBRzsiLCJuYW1lcyI6WyJiaXRtYXAiXX0=