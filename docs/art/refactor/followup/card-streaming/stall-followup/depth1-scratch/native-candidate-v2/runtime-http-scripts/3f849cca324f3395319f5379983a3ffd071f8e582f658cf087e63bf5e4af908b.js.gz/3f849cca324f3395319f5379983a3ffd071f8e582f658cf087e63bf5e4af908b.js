import { BUILDING_DEFS, UNIT_DEFS, constructionStartHp } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/catalog.ts";
import { detCos, detSin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/det-math.ts";
import { seconds } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
import { MAP_POOL } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/map-pool.ts";
import { GOLD_MINE_RULES } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/mining.ts";
import { isShipKind, SHIP_SIZE_MULTIPLIER, SHIP_SIZE_VERSION } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
export { LADDER_MAP_ID, LADDER_SLOT_IDS } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/map-ids.ts";
export const DEFAULT_MAP_ID = "verdantCrossroads";
export const STANDARD_MAP_SIZE = 4096;
export const COMBAT_ARENA_MAP_SIZE = 1600;
const AUTHOR_MAP_SIZE = 8192;
const MAP_SCALE = STANDARD_MAP_SIZE / AUTHOR_MAP_SIZE;
export const MAP_SCENARIOS = [
  { id: "ladder", name: "Ladder Map", note: "Every game draws a new War3-style ladder map: each main on a plateau with one ramp, a natural of its own, guarded contested mines, mercenary posts and a hard middle, walled by forest, rock and water.", tags: ["generated", "terrain", "expansions", "wild camps", "mercs"] },
  ...MAP_POOL.map((map) => ({ id: map.id, name: map.name.en, note: `A ${map.players}-player War3-style ladder map, ${map.layout.kind === "sides" ? "two teams facing each other across it" : "every start on one ring"}.`, tags: ["pool", `${map.players} players`, map.layout.kind, ..."idea" in map.layout ? [map.layout.idea] : []] })),
  { id: "verdantCrossroads", name: "Verdant Crossroads", note: "Compact ladder-style map with expansions, wild camps, and a mercenary crossroad.", tags: ["4096", "expansions", "wild camps", "mercs"] },
  { id: "bareDuel", name: "Bare Duel", note: "A cleaner duel layout for AI pressure tests without neutral distractions.", tags: ["4096", "few camps", "fast contact"] },
  { id: "openClaims", name: "Open Claims", note: "Expansion-focused economy map with no neutral camps blocking the mines.", tags: ["4096", "expansions", "no wild camps"] },
  { id: "campRush", name: "Camp Rush", note: "No-expansion pressure map where neutral camps and mercenaries shape the route.", tags: ["4096", "no expansions", "wild camps"] },
  { id: "combatArena", name: "Combat Arena", note: "Small benchmark arena for mixed-army micro without economy or neutral routing.", tags: ["1600", "combat", "micro"] },
  { id: "goldGrid", name: "Gold Grid", note: "V5 economy research map with sixteen open gold points for expansion stress tests.", tags: ["4096", "research", "many mines", "no wild camps"] },
  { id: "mercPocket", name: "Merc Pocket", note: "V5 economy research map with nearby unguarded mercenary camps for hire-tempo stress tests.", tags: ["4096", "research", "mercs", "no wild camps"] },
  { id: "grandThirty", name: "Grand Thirty", note: "Super-large 15v15 stress battlefield with many starts, lanes, mines, camps, and room-scale minimap proof.", tags: ["12288", "15v15", "stress", "many camps"] }
];
export function createMap(id = DEFAULT_MAP_ID) {
  const scenario = scenarioFor(id);
  const mapSize = mapSizeFor(id);
  return {
    id,
    name: scenario.name,
    width: mapSize,
    height: mapSize,
    landmarks: scenarioLandmarks(id)
  };
}
export const SAMPLE_MAP = createMap(DEFAULT_MAP_ID);
function mapSizeFor(id) {
  if (id === "grandThirty") return STANDARD_MAP_SIZE * 3;
  if (id === "combatArena") return COMBAT_ARENA_MAP_SIZE;
  return STANDARD_MAP_SIZE;
}
function scenarioLandmarks(id) {
  const landmarks = [
    { id: "road-west-1", kind: "road", x: 1180, y: 1240, size: 420, rotation: 0.3 },
    { id: "road-mid-1", kind: "road", x: 2380, y: 2440, size: 520, rotation: 0.8 },
    { id: "road-mid-2", kind: "road", x: 3980, y: 3900, size: 660, rotation: 0.7 },
    { id: "road-east-1", kind: "road", x: 6100, y: 6020, size: 520, rotation: 0.8 },
    { id: "grove-player", kind: "grove", x: 650, y: 1460, size: 340, rotation: 0.1 },
    { id: "grove-north", kind: "grove", x: 3360, y: 1040, size: 420, rotation: 1.2 },
    { id: "grove-center", kind: "grove", x: 4820, y: 3480, size: 360, rotation: 0.4 },
    { id: "grove-enemy", kind: "grove", x: 6880, y: 6520, size: 420, rotation: 0.7 },
    { id: "ridge-north", kind: "ridge", x: 4100, y: 980, size: 500, rotation: 0.2 },
    { id: "ridge-west", kind: "ridge", x: 1740, y: 3180, size: 460, rotation: 1.4 },
    { id: "ridge-south", kind: "ridge", x: 3960, y: 6640, size: 540, rotation: 0.4 },
    { id: "ruin-center-a", kind: "ruin", x: 4096, y: 4200, size: 260, rotation: 0.1 },
    { id: "ruin-center-b", kind: "ruin", x: 4416, y: 4460, size: 220, rotation: 0.6 },
    { id: "ditch-west", kind: "ditch", x: 2540, y: 4520, size: 560, rotation: 0.15 },
    { id: "ditch-east", kind: "ditch", x: 5700, y: 3320, size: 620, rotation: -0.2 },
    { id: "camp-north", kind: "campMark", x: 3980, y: 1540, size: 220, rotation: 0.2 },
    { id: "camp-center", kind: "campMark", x: 4096, y: 4200, size: 260, rotation: 0.7 },
    { id: "camp-south", kind: "campMark", x: 3700, y: 6080, size: 240, rotation: 0.5 },
    { id: "scar-player", kind: "mineScar", x: 1180, y: 920, size: 220, rotation: 0.4 },
    { id: "scar-enemy", kind: "mineScar", x: 7e3, y: 7140, size: 240, rotation: 0.4 },
    { id: "scar-center", kind: "mineScar", x: 4096, y: 4200, size: 180, rotation: 0.2 },
    { id: "stone-crossroad", kind: "bannerStone", x: 4020, y: 4020, size: 180, rotation: 0.1 },
    { id: "stone-west", kind: "bannerStone", x: 2060, y: 2200, size: 140, rotation: 0.3 },
    { id: "stone-east", kind: "bannerStone", x: 5920, y: 5900, size: 140, rotation: 0.3 }
  ];
  const scaled = landmarks.map(scaleLandmark);
  if (id === "combatArena") return [];
  if (id === "bareDuel") return scaled.filter((landmark) => landmark.kind !== "campMark").slice(0, 20);
  if (id === "openClaims") return scaled.filter((landmark) => landmark.kind !== "campMark");
  if (id === "campRush") return scaled.filter((landmark) => landmark.kind !== "mineScar" || landmark.id === "scar-player" || landmark.id === "scar-enemy");
  if (id === "grandThirty") return grandThirtyLandmarks();
  return scaled;
}
function scenarioFor(id) {
  const scenario = MAP_SCENARIOS.find((candidate) => candidate.id === id);
  if (!scenario) throw new Error(`Unknown map scenario ${id}`);
  return scenario;
}
export function createInitialResources(mapId = DEFAULT_MAP_ID, players = ["player", "enemy"], teams) {
  if (mapId === "combatArena") return [];
  if (mapId === "goldGrid") return goldGridMines();
  if (mapId === "grandThirty") {
    return [
      ...players.map((owner, index) => {
        const start = startPositionFor(owner, index, players.length, STANDARD_MAP_SIZE * 3, players, teams);
        return { id: `gold-${owner}-main`, kind: "goldMine", x: start.mineX, y: start.mineY, amount: 6e3 };
      }),
      ...grandThirtyExpansionMines()
    ];
  }
  const mainMines = players.map((owner, index) => {
    const start = startPositionFor(owner, index, players.length, STANDARD_MAP_SIZE, players, teams);
    return { id: `gold-${owner}-main`, kind: "goldMine", x: start.mineX, y: start.mineY, amount: 6e3 };
  });
  const expansionMines = [
    { id: "gold-north-ridge", kind: "goldMine", x: 4060, y: 1320, amount: 6e3 },
    { id: "gold-south-grove", kind: "goldMine", x: 3720, y: 6260, amount: 6e3 },
    { id: "gold-center-scar", kind: "goldMine", x: 4096, y: 4200, amount: 6e3 }
  ];
  if (mapId === "bareDuel" || mapId === "campRush") return mainMines;
  return [...mainMines, ...expansionMines.map(scaleResource)];
}
export function createInitialMercenaryCamps(mapId = DEFAULT_MAP_ID) {
  if (mapId === "combatArena") return [];
  if (mapId === "goldGrid") return [];
  if (mapId === "mercPocket") return mercPocketCamps();
  if (mapId === "bareDuel" || mapId === "openClaims") return [];
  if (mapId === "grandThirty") return grandThirtyMercenaryCamps();
  const camps = [
    { id: "merc-camp-crossroad", x: 6400, y: 6020, radius: 54, hireKind: "mercenary", cost: UNIT_DEFS.mercenary.cost, stock: 5, cooldown: seconds(9), cooldownRemaining: 0 },
    { id: "merc-camp-bow-post", x: 5880, y: 3880, radius: 50, hireKind: "contractArcher", cost: UNIT_DEFS.contractArcher.cost, stock: 3, cooldown: seconds(16), cooldownRemaining: 0 },
    { id: "merc-camp-field-tent", x: 2520, y: 3100, radius: 50, hireKind: "fieldMedic", cost: UNIT_DEFS.fieldMedic.cost, stock: 3, cooldown: seconds(18), cooldownRemaining: 0 }
  ];
  return camps.map(scaleMercenaryCamp);
}
export function createInitialItems(mapId = DEFAULT_MAP_ID) {
  if (mapId === "combatArena") return [];
  if (mapId === "goldGrid" || mapId === "mercPocket") return [];
  if (mapId === "bareDuel" || mapId === "openClaims") return [];
  const items = [
    { id: "treasure-center-lightning", kind: "lightningRod", x: 0, y: 0, carrierId: "wildling-center-2", cooldownRemaining: 0 },
    { id: "treasure-south-book", kind: "experienceBook", x: 0, y: 0, carrierId: "wildling-south-2", cooldownRemaining: 0 },
    { id: "treasure-north-flame", kind: "flameCloak", x: 0, y: 0, carrierId: "wildling-north-2", cooldownRemaining: 0 },
    { id: "treasure-free-yellow-scroll", kind: "guardianScroll", x: 0, y: 0, carrierId: "wildling-free-yellow-north-2", cooldownRemaining: 0 },
    { id: "treasure-free-red-storm", kind: "stormStaff", x: 0, y: 0, carrierId: "wildling-free-red-west-1", cooldownRemaining: 0 },
    { id: "treasure-free-red-breach", kind: "breachCharge", x: 0, y: 0, carrierId: "wildling-free-red-east-1", cooldownRemaining: 0 }
  ];
  if (mapId === "grandThirty") {
    return Array.from({ length: 30 }, (_, index) => ({
      id: `treasure-grand-${index + 1}`,
      kind: grandTreasureKind(index),
      x: 0,
      y: 0,
      carrierId: `wildling-grand-${index % 15 + 1}-${Math.floor(index / 15) + 1}`,
      cooldownRemaining: 0
    }));
  }
  return items;
}
function grandTreasureKind(index) {
  const cycle = ["flameCloak", "lightningRod", "stormStaff", "guardianScroll", "experienceBook", "breachCharge"];
  return cycle[index % cycle.length];
}
export function createInitialBuildings(players = ["player", "enemy"], mapId = DEFAULT_MAP_ID, teams) {
  return players.map((owner, index) => {
    const start = startPositionFor(owner, index, players.length, mapSizeFor(mapId), players, teams);
    return createBuilding(`building-${owner}-townhall`, owner, "townHall", start.baseX, start.baseY, true);
  });
}
export function createInitialUnits(mapId = DEFAULT_MAP_ID, players = ["player", "enemy"], teams) {
  const units = players.flatMap((owner, index) => {
    const start = startPositionFor(owner, index, players.length, mapSizeFor(mapId), players, teams);
    return [
      createUnit(`unit-${owner}-worker-1`, owner, "worker", start.baseX - 55, start.baseY + 10),
      createUnit(`unit-${owner}-worker-2`, owner, "worker", start.baseX - 10, start.baseY + 65),
      createUnit(`unit-${owner}-worker-3`, owner, "worker", start.baseX + 55, start.baseY + 40)
    ];
  });
  units.push(
    createUnit("wildling-north-1", "neutral", "wildling", 3920, 1560),
    createUnit("wildling-north-2", "neutral", "thornSlinger", 4010, 1510),
    createUnit("wildling-north-3", "neutral", "stonebackBrute", 3970, 1620),
    createUnit("wildling-north-4", "neutral", "gladeWitch", 4050, 1600),
    createUnit("wildling-north-5", "neutral", "barkMender", 3890, 1500),
    createUnit("wildling-center-1", "neutral", "stonebackBrute", 3996, 4070),
    createUnit("wildling-center-2", "neutral", "gladeWitch", 4176, 4310),
    createUnit("wildling-center-3", "neutral", "barkMender", 4086, 4210),
    createUnit("wildling-center-4", "neutral", "thornSlinger", 3976, 4300),
    createUnit("wildling-south-1", "neutral", "mossGnawer", 3580, 6040),
    createUnit("wildling-south-2", "neutral", "barkMender", 3810, 6110),
    createUnit("wildling-south-3", "neutral", "stonebackBrute", 3690, 6160),
    createUnit("wildling-south-4", "neutral", "gladeWitch", 3750, 6010),
    createUnit("wildling-south-5", "neutral", "thornSlinger", 3860, 6200),
    createUnit("wildling-south-6", "neutral", "thornSlinger", 3620, 6140),
    createUnit("wildling-merc-crossroad-1", "neutral", "stonebackBrute", 6320, 5980),
    createUnit("wildling-merc-crossroad-2", "neutral", "thornSlinger", 6460, 6060),
    createUnit("wildling-merc-crossroad-3", "neutral", "barkMender", 6380, 6120),
    createUnit("wildling-merc-bow-1", "neutral", "gladeWitch", 5840, 3820),
    createUnit("wildling-merc-bow-2", "neutral", "thornSlinger", 5960, 3920),
    createUnit("wildling-merc-bow-3", "neutral", "barkMender", 5880, 3980),
    createUnit("wildling-merc-field-1", "neutral", "barkMender", 2480, 3040),
    createUnit("wildling-merc-field-2", "neutral", "wildling", 2580, 3160),
    createUnit("wildling-merc-field-3", "neutral", "stonebackBrute", 2520, 3200)
  );
  if (mapId === "grandThirty") return [...units.filter((unit) => unit.owner !== "neutral"), ...grandThirtyWildlings()];
  const playerUnits = units.filter((unit) => unit.owner !== "neutral");
  const neutralUnits = units.filter((unit) => unit.owner === "neutral");
  if (mapId === "combatArena") return playerUnits;
  if (mapId === "goldGrid" || mapId === "mercPocket") return playerUnits;
  if (mapId === "bareDuel" || mapId === "openClaims") return playerUnits;
  const authoredNeutrals = [...neutralUnits.map(scaleUnit), ...freeWildlingCamps(mapId)];
  return [...playerUnits, ...keepNeutralUnitsAwayFromPlayerStarts(authoredNeutrals, mapId, players, teams)];
}
export function createBuilding(id, owner, kind, x, y, complete) {
  const def = BUILDING_DEFS[kind];
  return {
    id,
    owner,
    kind,
    x,
    y,
    hp: complete ? def.hp : constructionStartHp(def.hp),
    maxHp: def.hp,
    radius: def.radius,
    complete,
    buildProgress: complete ? buildTimeFor(kind) : 0,
    buildTime: buildTimeFor(kind),
    attackDamage: def.attackDamage,
    attackRange: def.attackRange,
    attackCooldown: def.attackCooldown,
    cooldown: 0,
    rallyX: x + 90,
    rallyY: y + 60,
    queue: [],
    researchQueue: []
  };
}
export function createUnit(id, owner, kind, x, y) {
  const stats = UNIT_DEFS[kind];
  return {
    id,
    owner,
    kind,
    x,
    y,
    homeX: x,
    homeY: y,
    hp: stats.hp,
    maxHp: stats.hp,
    speed: stats.speed,
    attackDamage: stats.attackDamage,
    attackRange: stats.attackRange,
    attackCooldown: stats.attackCooldown,
    cooldown: 0,
    radius: stats.radius * (isShipKind(kind) ? SHIP_SIZE_MULTIPLIER : 1),
    carryingGold: 0,
    kills: 0,
    xp: 0,
    level: 0,
    effects: [],
    order: { type: "idle" },
    orderQueue: [],
    variant: void 0,
    abilityCooldowns: void 0,
    autocast: void 0,
    stance: void 0,
    pushX: void 0,
    pushY: void 0,
    arrivedAt: void 0,
    aim: void 0,
    facing: void 0,
    hands: void 0,
    gearMass: void 0,
    holdMass: void 0,
    shipParts: void 0,
    fittings: void 0,
    bodyRadius: void 0,
    mineSlot: void 0,
    veteranSkill: void 0,
    veteranSkillChoices: void 0,
    expiresTick: void 0,
    shipSizeVersion: isShipKind(kind) ? SHIP_SIZE_VERSION : void 0
  };
}
export function withUnitShape(unit) {
  return Object.assign(createUnit(unit.id, unit.owner, unit.kind, unit.x, unit.y), { homeX: void 0, homeY: void 0, orderQueue: void 0, shipSizeVersion: void 0 }, unit);
}
export function buildTimeFor(kind) {
  return BUILDING_DEFS[kind].buildTime;
}
export function trainTimeFor(kind) {
  return UNIT_DEFS[kind].trainTime;
}
function scale(value) {
  return value * MAP_SCALE;
}
function keepNeutralUnitsAwayFromPlayerStarts(units, mapId, players, teams) {
  const mapSize = mapId === "grandThirty" ? STANDARD_MAP_SIZE * 3 : STANDARD_MAP_SIZE;
  const safeGap = 440 * (mapSize / STANDARD_MAP_SIZE);
  const clamp = (value) => Math.max(80, Math.min(mapSize - 80, value));
  const safetyPoints = players.flatMap((owner, index) => {
    const start = startPositionFor(owner, index, players.length, mapSize, players, teams);
    return [
      { x: start.baseX, y: start.baseY },
      { x: start.mineX, y: start.mineY }
    ];
  });
  return units.map((unit) => {
    if (unit.owner !== "neutral") return unit;
    let x = unit.x;
    let y = unit.y;
    for (let pass = 0; pass < 5; pass += 1) {
      let moved = false;
      for (const point of safetyPoints) {
        const dx = x - point.x;
        const dy = y - point.y;
        const gap = Math.hypot(dx, dy);
        if (gap >= safeGap) continue;
        const tieBreakX = x >= point.x ? 1 : -1;
        const tieBreakY = y >= point.y ? 1 : -1;
        const unitX = gap > 0 ? dx / gap : tieBreakX / Math.SQRT2;
        const unitY = gap > 0 ? dy / gap : tieBreakY / Math.SQRT2;
        const radial = { x: clamp(point.x + unitX * safeGap), y: clamp(point.y + unitY * safeGap) };
        const candidates = [radial];
        for (let angleIndex = 0; angleIndex < 16; angleIndex += 1) {
          const angle = Math.PI * 2 * angleIndex / 16;
          candidates.push({ x: clamp(point.x + detCos(angle) * safeGap), y: clamp(point.y + detSin(angle) * safeGap) });
        }
        const best = candidates.reduce((winner, candidate) => nearestSafetyGap(candidate) > nearestSafetyGap(winner) ? candidate : winner, radial);
        x = best.x;
        y = best.y;
        moved = true;
      }
      if (!moved) break;
    }
    return withUnitHome({ ...unit, x, y }, x, y);
  });
  function nearestSafetyGap(point) {
    return Math.min(...safetyPoints.map((start) => Math.hypot(point.x - start.x, point.y - start.y)));
  }
}
function goldGridMines() {
  const slots = goldGridPoints();
  return slots.map((point, index) => ({
    id: `gold-grid-${index + 1}`,
    kind: "goldMine",
    x: point.x,
    y: point.y,
    amount: 6e3
  }));
}
function goldGridPoints() {
  const lanes = [640, 1580, 2520, 3456];
  return lanes.flatMap((y) => lanes.map((x) => ({ x, y })));
}
function mercPocketCamps() {
  return [
    { id: "merc-pocket-frontline", x: 840, y: 760, radius: 50, hireKind: "mercenary", cost: UNIT_DEFS.mercenary.cost, stock: 5, cooldown: seconds(9), cooldownRemaining: 0 },
    { id: "merc-pocket-bow", x: 760, y: 1020, radius: 50, hireKind: "contractArcher", cost: UNIT_DEFS.contractArcher.cost, stock: 3, cooldown: seconds(16), cooldownRemaining: 0 },
    { id: "merc-pocket-medic", x: 1020, y: 840, radius: 50, hireKind: "fieldMedic", cost: UNIT_DEFS.fieldMedic.cost, stock: 3, cooldown: seconds(18), cooldownRemaining: 0 }
  ];
}
function scaleLandmark(landmark) {
  return { ...landmark, x: scale(landmark.x), y: scale(landmark.y), size: scale(landmark.size) };
}
function scaleResource(resource) {
  return { ...resource, x: scale(resource.x), y: scale(resource.y) };
}
function scaleMercenaryCamp(camp) {
  return { ...camp, x: scale(camp.x), y: scale(camp.y), radius: scale(camp.radius) };
}
function scaleUnit(unit) {
  const x = scale(unit.x);
  const y = scale(unit.y);
  return withUnitHome({ ...unit, x, y }, x, y);
}
function withUnitHome(unit, x, y) {
  if (unit.homeX === void 0 || unit.homeY === void 0) return unit;
  return { ...unit, homeX: x, homeY: y };
}
function startPositionFor(owner, index, total, mapSize, players = ["player", "enemy"], teams) {
  if (mapSize === STANDARD_MAP_SIZE) {
    if (players.length === 2 && owner === "player") return { baseX: scale(900), baseY: scale(900), mineX: scale(900) + GOLD_MINE_RULES.mainDistance, mineY: scale(900) };
    if (players.length === 2 && owner === "enemy") return { baseX: scale(7240), baseY: scale(7240), mineX: scale(7240) - GOLD_MINE_RULES.mainDistance, mineY: scale(7240) };
    if (owner === "enemy2") return { baseX: mapSize - 480, baseY: 480, mineX: mapSize - 480 - GOLD_MINE_RULES.mainDistance, mineY: 480 };
  }
  const sideStart = sideStartFor(owner, index, total, players, teams);
  const side = sideStart.side;
  const sideIndex = sideStart.sideIndex;
  const sideCount = sideStart.sideCount;
  const lane = (sideIndex + 1) / (sideCount + 1);
  const x = side === 0 ? mapSize * 0.12 : mapSize * 0.88;
  const y = mapSize * (0.08 + lane * 0.84);
  const mineX = side === 0 ? x + GOLD_MINE_RULES.mainDistance : x - GOLD_MINE_RULES.mainDistance;
  return { baseX: x, baseY: y, mineX, mineY: y };
}
function sideStartFor(owner, index, total, players, teams) {
  if (teams) {
    const teamOrder = [...new Set(players.map((player) => teams[player] ?? player))];
    if (teamOrder.length === 2) {
      const ownerTeam = teams[owner] ?? owner;
      const sidePlayers = players.filter((player) => (teams[player] ?? player) === ownerTeam);
      return {
        side: teamOrder.indexOf(ownerTeam) === 0 ? 0 : 1,
        sideIndex: Math.max(0, sidePlayers.indexOf(owner)),
        sideCount: sidePlayers.length
      };
    }
  }
  const side = index < Math.ceil(total / 2) ? 0 : 1;
  return {
    side,
    sideIndex: side === 0 ? index : index - Math.ceil(total / 2),
    sideCount: side === 0 ? Math.ceil(total / 2) : Math.floor(total / 2)
  };
}
function grandThirtyLandmarks() {
  const mapSize = STANDARD_MAP_SIZE * 3;
  const landmarks = [];
  for (let i = 0; i < 15; i += 1) {
    const y = mapSize * ((i + 1) / 16);
    landmarks.push(
      { id: `grand-road-${i}`, kind: "road", x: mapSize / 2, y, size: 720, rotation: i % 2 === 0 ? 0.1 : -0.1 },
      { id: `grand-grove-west-${i}`, kind: "grove", x: mapSize * 0.27, y: y + 120, size: 260, rotation: i * 0.2 },
      { id: `grand-ridge-east-${i}`, kind: "ridge", x: mapSize * 0.73, y: y - 120, size: 280, rotation: -i * 0.18 },
      { id: `grand-camp-${i}`, kind: "campMark", x: mapSize * (i % 2 === 0 ? 0.42 : 0.58), y, size: 180, rotation: i * 0.31 }
    );
  }
  for (let i = 0; i < 10; i += 1) {
    landmarks.push({ id: `grand-ruin-${i}`, kind: "ruin", x: mapSize * (0.35 + i % 5 * 0.075), y: mapSize * (0.15 + Math.floor(i / 5) * 0.7), size: 240, rotation: i * 0.21 });
  }
  return landmarks;
}
function grandThirtyExpansionMines() {
  const mapSize = STANDARD_MAP_SIZE * 3;
  return Array.from({ length: 18 }, (_, index) => {
    const lane = index % 9 + 1;
    const row = Math.floor(index / 9);
    return {
      id: `gold-grand-expansion-${index + 1}`,
      kind: "goldMine",
      x: mapSize * (row === 0 ? 0.37 : 0.63),
      y: mapSize * (lane / 10),
      amount: 6e3
    };
  });
}
function grandThirtyMercenaryCamps() {
  const mapSize = STANDARD_MAP_SIZE * 3;
  const kinds = ["mercenary", "contractArcher", "fieldMedic", "mercenary", "contractArcher", "fieldMedic"];
  return Array.from({ length: 6 }, (_, index) => {
    const hireKind = kinds[index];
    const guardedCampIndex = index * 2 + 1;
    const x = mapSize * (guardedCampIndex % 2 === 0 ? 0.44 : 0.56);
    return {
      id: `merc-grand-lane-${index + 1}`,
      x,
      y: mapSize * ((guardedCampIndex + 1) / 16),
      radius: 72,
      hireKind,
      cost: UNIT_DEFS[hireKind].cost,
      stock: index % 3 === 2 ? 3 : 4,
      cooldown: seconds(index % 3 === 2 ? 18 : 16),
      cooldownRemaining: 0
    };
  });
}
function grandThirtyWildlings() {
  const mapSize = STANDARD_MAP_SIZE * 3;
  const kinds = ["mossGnawer", "thornSlinger", "barkMender", "stonebackBrute", "gladeWitch", "ancientStag"];
  const units = [];
  for (let camp = 0; camp < 15; camp += 1) {
    const x = mapSize * (camp % 2 === 0 ? 0.44 : 0.56);
    const y = mapSize * ((camp + 1) / 16);
    for (let i = 0; i < 3; i += 1) {
      units.push(createUnit(`wildling-grand-${camp + 1}-${i + 1}`, "neutral", kinds[(camp + i) % kinds.length], x + (i - 1) * 42, y + (i % 2 === 0 ? -34 : 34)));
    }
    if (camp % 5 === 4) {
      units.push(
        createUnit(`wildling-grand-${camp + 1}-leader`, "neutral", "ancientStag", x + 72, y - 72),
        createUnit(`wildling-grand-${camp + 1}-guard`, "neutral", "stonebackBrute", x - 72, y + 72),
        createUnit(`wildling-grand-${camp + 1}-hex`, "neutral", "gladeWitch", x + 8, y + 92)
      );
    }
  }
  return units;
}
function freeWildlingCamps(mapId) {
  if (mapId !== "verdantCrossroads" && mapId !== "campRush") return [];
  return [
    ...wildlingCamp("wildling-free-green-west", 820, 2490, ["mossGnawer", "wildling"]),
    ...wildlingCamp("wildling-free-yellow-north", 2800, 850, ["stonebackBrute", "stonebackBrute", "gladeWitch", "thornSlinger"]),
    ...wildlingCamp("wildling-free-red-west", 620, 3330, ["ancientStag", "ancientStag", "stonebackBrute", "stonebackBrute", "gladeWitch", "thornSlinger"]),
    ...wildlingCamp("wildling-free-yellow-east", 3e3, 1040, ["stonebackBrute", "gladeWitch", "thornSlinger", "barkMender"]),
    ...wildlingCamp("wildling-free-red-east", 2300, 3300, ["ancientStag", "ancientStag", "stonebackBrute", "stonebackBrute", "gladeWitch", "thornSlinger"]),
    ...wildlingCamp("wildling-free-green-east", 3650, 2280, ["wildling", "thornSlinger"]),
    ...wildlingCamp("wildling-free-green-south", 1490, 3560, ["mossGnawer", "barkMender"])
  ];
}
function wildlingCamp(prefix, x, y, kinds) {
  return kinds.map((kind, index) => {
    const angle = Math.PI * 2 * index / Math.max(1, kinds.length);
    const radius = index === 0 ? 0 : 44 + index % 2 * 16;
    return createUnit(`${prefix}-${index + 1}`, "neutral", kind, x + detCos(angle) * radius, y + detSin(angle) * radius);
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1hcC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCVUlMRElOR19ERUZTLCBVTklUX0RFRlMsIGNvbnN0cnVjdGlvblN0YXJ0SHAgfSBmcm9tIFwiLi9jYXRhbG9nXCI7XG5pbXBvcnQgeyBkZXRDb3MsIGRldFNpbiB9IGZyb20gXCIuL2RldC1tYXRoXCI7XG5pbXBvcnQgeyBzZWNvbmRzIH0gZnJvbSBcIi4vdGltZVwiO1xuaW1wb3J0IHsgTUFQX1BPT0wgfSBmcm9tIFwiLi9tYXAtcG9vbFwiO1xuaW1wb3J0IHsgR09MRF9NSU5FX1JVTEVTIH0gZnJvbSBcIi4vbWluaW5nXCI7XG5pbXBvcnQgeyBpc1NoaXBLaW5kLCBTSElQX1NJWkVfTVVMVElQTElFUiwgU0hJUF9TSVpFX1ZFUlNJT04gfSBmcm9tIFwiLi9zaGlwLWdlb21ldHJ5XCI7XG5pbXBvcnQgdHlwZSB7IEJ1aWxkaW5nLCBCdWlsZGluZ0tpbmQsIEdhbWVNYXAsIE1hcElkLCBNZXJjZW5hcnlDYW1wLCBNZXJjZW5hcnlVbml0S2luZCwgT3duZXIsIFBsYXllcklkLCBSZXNvdXJjZU5vZGUsIFRyYWluYWJsZVVuaXRLaW5kLCBVbml0LCBVbml0S2luZCwgV29ybGRJdGVtIH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuZXhwb3J0IHsgTEFEREVSX01BUF9JRCwgTEFEREVSX1NMT1RfSURTIH0gZnJvbSBcIi4vbWFwLWlkc1wiO1xuXG5leHBvcnQgdHlwZSBNYXBTY2VuYXJpbyA9IHtcbiAgaWQ6IE1hcElkO1xuICBuYW1lOiBzdHJpbmc7XG4gIG5vdGU6IHN0cmluZztcbiAgdGFnczogc3RyaW5nW107XG59O1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9NQVBfSUQ6IE1hcElkID0gXCJ2ZXJkYW50Q3Jvc3Nyb2Fkc1wiO1xuZXhwb3J0IGNvbnN0IFNUQU5EQVJEX01BUF9TSVpFID0gNDA5NjtcbmV4cG9ydCBjb25zdCBDT01CQVRfQVJFTkFfTUFQX1NJWkUgPSAxNjAwO1xuY29uc3QgQVVUSE9SX01BUF9TSVpFID0gODE5MjtcbmNvbnN0IE1BUF9TQ0FMRSA9IFNUQU5EQVJEX01BUF9TSVpFIC8gQVVUSE9SX01BUF9TSVpFO1xuXG5leHBvcnQgY29uc3QgTUFQX1NDRU5BUklPUzogTWFwU2NlbmFyaW9bXSA9IFtcbiAgeyBpZDogXCJsYWRkZXJcIiwgbmFtZTogXCJMYWRkZXIgTWFwXCIsIG5vdGU6IFwiRXZlcnkgZ2FtZSBkcmF3cyBhIG5ldyBXYXIzLXN0eWxlIGxhZGRlciBtYXA6IGVhY2ggbWFpbiBvbiBhIHBsYXRlYXUgd2l0aCBvbmUgcmFtcCwgYSBuYXR1cmFsIG9mIGl0cyBvd24sIGd1YXJkZWQgY29udGVzdGVkIG1pbmVzLCBtZXJjZW5hcnkgcG9zdHMgYW5kIGEgaGFyZCBtaWRkbGUsIHdhbGxlZCBieSBmb3Jlc3QsIHJvY2sgYW5kIHdhdGVyLlwiLCB0YWdzOiBbXCJnZW5lcmF0ZWRcIiwgXCJ0ZXJyYWluXCIsIFwiZXhwYW5zaW9uc1wiLCBcIndpbGQgY2FtcHNcIiwgXCJtZXJjc1wiXSB9LFxuICAuLi5NQVBfUE9PTC5tYXAoKG1hcCkgPT4gKHsgaWQ6IG1hcC5pZCwgbmFtZTogbWFwLm5hbWUuZW4sIG5vdGU6IGBBICR7bWFwLnBsYXllcnN9LXBsYXllciBXYXIzLXN0eWxlIGxhZGRlciBtYXAsICR7bWFwLmxheW91dC5raW5kID09PSBcInNpZGVzXCIgPyBcInR3byB0ZWFtcyBmYWNpbmcgZWFjaCBvdGhlciBhY3Jvc3MgaXRcIiA6IFwiZXZlcnkgc3RhcnQgb24gb25lIHJpbmdcIn0uYCwgdGFnczogW1wicG9vbFwiLCBgJHttYXAucGxheWVyc30gcGxheWVyc2AsIG1hcC5sYXlvdXQua2luZCwgLi4uKFwiaWRlYVwiIGluIG1hcC5sYXlvdXQgPyBbbWFwLmxheW91dC5pZGVhXSA6IFtdKV0gfSkpLFxuICB7IGlkOiBcInZlcmRhbnRDcm9zc3JvYWRzXCIsIG5hbWU6IFwiVmVyZGFudCBDcm9zc3JvYWRzXCIsIG5vdGU6IFwiQ29tcGFjdCBsYWRkZXItc3R5bGUgbWFwIHdpdGggZXhwYW5zaW9ucywgd2lsZCBjYW1wcywgYW5kIGEgbWVyY2VuYXJ5IGNyb3Nzcm9hZC5cIiwgdGFnczogW1wiNDA5NlwiLCBcImV4cGFuc2lvbnNcIiwgXCJ3aWxkIGNhbXBzXCIsIFwibWVyY3NcIl0gfSxcbiAgeyBpZDogXCJiYXJlRHVlbFwiLCBuYW1lOiBcIkJhcmUgRHVlbFwiLCBub3RlOiBcIkEgY2xlYW5lciBkdWVsIGxheW91dCBmb3IgQUkgcHJlc3N1cmUgdGVzdHMgd2l0aG91dCBuZXV0cmFsIGRpc3RyYWN0aW9ucy5cIiwgdGFnczogW1wiNDA5NlwiLCBcImZldyBjYW1wc1wiLCBcImZhc3QgY29udGFjdFwiXSB9LFxuICB7IGlkOiBcIm9wZW5DbGFpbXNcIiwgbmFtZTogXCJPcGVuIENsYWltc1wiLCBub3RlOiBcIkV4cGFuc2lvbi1mb2N1c2VkIGVjb25vbXkgbWFwIHdpdGggbm8gbmV1dHJhbCBjYW1wcyBibG9ja2luZyB0aGUgbWluZXMuXCIsIHRhZ3M6IFtcIjQwOTZcIiwgXCJleHBhbnNpb25zXCIsIFwibm8gd2lsZCBjYW1wc1wiXSB9LFxuICB7IGlkOiBcImNhbXBSdXNoXCIsIG5hbWU6IFwiQ2FtcCBSdXNoXCIsIG5vdGU6IFwiTm8tZXhwYW5zaW9uIHByZXNzdXJlIG1hcCB3aGVyZSBuZXV0cmFsIGNhbXBzIGFuZCBtZXJjZW5hcmllcyBzaGFwZSB0aGUgcm91dGUuXCIsIHRhZ3M6IFtcIjQwOTZcIiwgXCJubyBleHBhbnNpb25zXCIsIFwid2lsZCBjYW1wc1wiXSB9LFxuICB7IGlkOiBcImNvbWJhdEFyZW5hXCIsIG5hbWU6IFwiQ29tYmF0IEFyZW5hXCIsIG5vdGU6IFwiU21hbGwgYmVuY2htYXJrIGFyZW5hIGZvciBtaXhlZC1hcm15IG1pY3JvIHdpdGhvdXQgZWNvbm9teSBvciBuZXV0cmFsIHJvdXRpbmcuXCIsIHRhZ3M6IFtcIjE2MDBcIiwgXCJjb21iYXRcIiwgXCJtaWNyb1wiXSB9LFxuICB7IGlkOiBcImdvbGRHcmlkXCIsIG5hbWU6IFwiR29sZCBHcmlkXCIsIG5vdGU6IFwiVjUgZWNvbm9teSByZXNlYXJjaCBtYXAgd2l0aCBzaXh0ZWVuIG9wZW4gZ29sZCBwb2ludHMgZm9yIGV4cGFuc2lvbiBzdHJlc3MgdGVzdHMuXCIsIHRhZ3M6IFtcIjQwOTZcIiwgXCJyZXNlYXJjaFwiLCBcIm1hbnkgbWluZXNcIiwgXCJubyB3aWxkIGNhbXBzXCJdIH0sXG4gIHsgaWQ6IFwibWVyY1BvY2tldFwiLCBuYW1lOiBcIk1lcmMgUG9ja2V0XCIsIG5vdGU6IFwiVjUgZWNvbm9teSByZXNlYXJjaCBtYXAgd2l0aCBuZWFyYnkgdW5ndWFyZGVkIG1lcmNlbmFyeSBjYW1wcyBmb3IgaGlyZS10ZW1wbyBzdHJlc3MgdGVzdHMuXCIsIHRhZ3M6IFtcIjQwOTZcIiwgXCJyZXNlYXJjaFwiLCBcIm1lcmNzXCIsIFwibm8gd2lsZCBjYW1wc1wiXSB9LFxuICB7IGlkOiBcImdyYW5kVGhpcnR5XCIsIG5hbWU6IFwiR3JhbmQgVGhpcnR5XCIsIG5vdGU6IFwiU3VwZXItbGFyZ2UgMTV2MTUgc3RyZXNzIGJhdHRsZWZpZWxkIHdpdGggbWFueSBzdGFydHMsIGxhbmVzLCBtaW5lcywgY2FtcHMsIGFuZCByb29tLXNjYWxlIG1pbmltYXAgcHJvb2YuXCIsIHRhZ3M6IFtcIjEyMjg4XCIsIFwiMTV2MTVcIiwgXCJzdHJlc3NcIiwgXCJtYW55IGNhbXBzXCJdIH0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTWFwKGlkOiBNYXBJZCA9IERFRkFVTFRfTUFQX0lEKTogR2FtZU1hcCB7XG4gIGNvbnN0IHNjZW5hcmlvID0gc2NlbmFyaW9Gb3IoaWQpO1xuICBjb25zdCBtYXBTaXplID0gbWFwU2l6ZUZvcihpZCk7XG4gIHJldHVybiB7XG4gICAgaWQsXG4gICAgbmFtZTogc2NlbmFyaW8ubmFtZSxcbiAgICB3aWR0aDogbWFwU2l6ZSxcbiAgICBoZWlnaHQ6IG1hcFNpemUsXG4gICAgbGFuZG1hcmtzOiBzY2VuYXJpb0xhbmRtYXJrcyhpZCksXG4gIH07XG59XG5cbmV4cG9ydCBjb25zdCBTQU1QTEVfTUFQOiBHYW1lTWFwID0gY3JlYXRlTWFwKERFRkFVTFRfTUFQX0lEKTtcblxuZnVuY3Rpb24gbWFwU2l6ZUZvcihpZDogTWFwSWQpIHtcbiAgaWYgKGlkID09PSBcImdyYW5kVGhpcnR5XCIpIHJldHVybiBTVEFOREFSRF9NQVBfU0laRSAqIDM7XG4gIGlmIChpZCA9PT0gXCJjb21iYXRBcmVuYVwiKSByZXR1cm4gQ09NQkFUX0FSRU5BX01BUF9TSVpFO1xuICByZXR1cm4gU1RBTkRBUkRfTUFQX1NJWkU7XG59XG5cbmZ1bmN0aW9uIHNjZW5hcmlvTGFuZG1hcmtzKGlkOiBNYXBJZCk6IEdhbWVNYXBbXCJsYW5kbWFya3NcIl0ge1xuICBjb25zdCBsYW5kbWFya3M6IEdhbWVNYXBbXCJsYW5kbWFya3NcIl0gPSBbXG4gICAgeyBpZDogXCJyb2FkLXdlc3QtMVwiLCBraW5kOiBcInJvYWRcIiwgeDogMTE4MCwgeTogMTI0MCwgc2l6ZTogNDIwLCByb3RhdGlvbjogMC4zIH0sXG4gICAgeyBpZDogXCJyb2FkLW1pZC0xXCIsIGtpbmQ6IFwicm9hZFwiLCB4OiAyMzgwLCB5OiAyNDQwLCBzaXplOiA1MjAsIHJvdGF0aW9uOiAwLjggfSxcbiAgICB7IGlkOiBcInJvYWQtbWlkLTJcIiwga2luZDogXCJyb2FkXCIsIHg6IDM5ODAsIHk6IDM5MDAsIHNpemU6IDY2MCwgcm90YXRpb246IDAuNyB9LFxuICAgIHsgaWQ6IFwicm9hZC1lYXN0LTFcIiwga2luZDogXCJyb2FkXCIsIHg6IDYxMDAsIHk6IDYwMjAsIHNpemU6IDUyMCwgcm90YXRpb246IDAuOCB9LFxuICAgIHsgaWQ6IFwiZ3JvdmUtcGxheWVyXCIsIGtpbmQ6IFwiZ3JvdmVcIiwgeDogNjUwLCB5OiAxNDYwLCBzaXplOiAzNDAsIHJvdGF0aW9uOiAwLjEgfSxcbiAgICB7IGlkOiBcImdyb3ZlLW5vcnRoXCIsIGtpbmQ6IFwiZ3JvdmVcIiwgeDogMzM2MCwgeTogMTA0MCwgc2l6ZTogNDIwLCByb3RhdGlvbjogMS4yIH0sXG4gICAgeyBpZDogXCJncm92ZS1jZW50ZXJcIiwga2luZDogXCJncm92ZVwiLCB4OiA0ODIwLCB5OiAzNDgwLCBzaXplOiAzNjAsIHJvdGF0aW9uOiAwLjQgfSxcbiAgICB7IGlkOiBcImdyb3ZlLWVuZW15XCIsIGtpbmQ6IFwiZ3JvdmVcIiwgeDogNjg4MCwgeTogNjUyMCwgc2l6ZTogNDIwLCByb3RhdGlvbjogMC43IH0sXG4gICAgeyBpZDogXCJyaWRnZS1ub3J0aFwiLCBraW5kOiBcInJpZGdlXCIsIHg6IDQxMDAsIHk6IDk4MCwgc2l6ZTogNTAwLCByb3RhdGlvbjogMC4yIH0sXG4gICAgeyBpZDogXCJyaWRnZS13ZXN0XCIsIGtpbmQ6IFwicmlkZ2VcIiwgeDogMTc0MCwgeTogMzE4MCwgc2l6ZTogNDYwLCByb3RhdGlvbjogMS40IH0sXG4gICAgeyBpZDogXCJyaWRnZS1zb3V0aFwiLCBraW5kOiBcInJpZGdlXCIsIHg6IDM5NjAsIHk6IDY2NDAsIHNpemU6IDU0MCwgcm90YXRpb246IDAuNCB9LFxuICAgIHsgaWQ6IFwicnVpbi1jZW50ZXItYVwiLCBraW5kOiBcInJ1aW5cIiwgeDogNDA5NiwgeTogNDIwMCwgc2l6ZTogMjYwLCByb3RhdGlvbjogMC4xIH0sXG4gICAgeyBpZDogXCJydWluLWNlbnRlci1iXCIsIGtpbmQ6IFwicnVpblwiLCB4OiA0NDE2LCB5OiA0NDYwLCBzaXplOiAyMjAsIHJvdGF0aW9uOiAwLjYgfSxcbiAgICB7IGlkOiBcImRpdGNoLXdlc3RcIiwga2luZDogXCJkaXRjaFwiLCB4OiAyNTQwLCB5OiA0NTIwLCBzaXplOiA1NjAsIHJvdGF0aW9uOiAwLjE1IH0sXG4gICAgeyBpZDogXCJkaXRjaC1lYXN0XCIsIGtpbmQ6IFwiZGl0Y2hcIiwgeDogNTcwMCwgeTogMzMyMCwgc2l6ZTogNjIwLCByb3RhdGlvbjogLTAuMiB9LFxuICAgIHsgaWQ6IFwiY2FtcC1ub3J0aFwiLCBraW5kOiBcImNhbXBNYXJrXCIsIHg6IDM5ODAsIHk6IDE1NDAsIHNpemU6IDIyMCwgcm90YXRpb246IDAuMiB9LFxuICAgIHsgaWQ6IFwiY2FtcC1jZW50ZXJcIiwga2luZDogXCJjYW1wTWFya1wiLCB4OiA0MDk2LCB5OiA0MjAwLCBzaXplOiAyNjAsIHJvdGF0aW9uOiAwLjcgfSxcbiAgICB7IGlkOiBcImNhbXAtc291dGhcIiwga2luZDogXCJjYW1wTWFya1wiLCB4OiAzNzAwLCB5OiA2MDgwLCBzaXplOiAyNDAsIHJvdGF0aW9uOiAwLjUgfSxcbiAgICB7IGlkOiBcInNjYXItcGxheWVyXCIsIGtpbmQ6IFwibWluZVNjYXJcIiwgeDogMTE4MCwgeTogOTIwLCBzaXplOiAyMjAsIHJvdGF0aW9uOiAwLjQgfSxcbiAgICB7IGlkOiBcInNjYXItZW5lbXlcIiwga2luZDogXCJtaW5lU2NhclwiLCB4OiA3MDAwLCB5OiA3MTQwLCBzaXplOiAyNDAsIHJvdGF0aW9uOiAwLjQgfSxcbiAgICB7IGlkOiBcInNjYXItY2VudGVyXCIsIGtpbmQ6IFwibWluZVNjYXJcIiwgeDogNDA5NiwgeTogNDIwMCwgc2l6ZTogMTgwLCByb3RhdGlvbjogMC4yIH0sXG4gICAgeyBpZDogXCJzdG9uZS1jcm9zc3JvYWRcIiwga2luZDogXCJiYW5uZXJTdG9uZVwiLCB4OiA0MDIwLCB5OiA0MDIwLCBzaXplOiAxODAsIHJvdGF0aW9uOiAwLjEgfSxcbiAgICB7IGlkOiBcInN0b25lLXdlc3RcIiwga2luZDogXCJiYW5uZXJTdG9uZVwiLCB4OiAyMDYwLCB5OiAyMjAwLCBzaXplOiAxNDAsIHJvdGF0aW9uOiAwLjMgfSxcbiAgICB7IGlkOiBcInN0b25lLWVhc3RcIiwga2luZDogXCJiYW5uZXJTdG9uZVwiLCB4OiA1OTIwLCB5OiA1OTAwLCBzaXplOiAxNDAsIHJvdGF0aW9uOiAwLjMgfSxcbiAgXTtcbiAgY29uc3Qgc2NhbGVkID0gbGFuZG1hcmtzLm1hcChzY2FsZUxhbmRtYXJrKTtcbiAgaWYgKGlkID09PSBcImNvbWJhdEFyZW5hXCIpIHJldHVybiBbXTtcbiAgaWYgKGlkID09PSBcImJhcmVEdWVsXCIpIHJldHVybiBzY2FsZWQuZmlsdGVyKChsYW5kbWFyaykgPT4gbGFuZG1hcmsua2luZCAhPT0gXCJjYW1wTWFya1wiKS5zbGljZSgwLCAyMCk7XG4gIGlmIChpZCA9PT0gXCJvcGVuQ2xhaW1zXCIpIHJldHVybiBzY2FsZWQuZmlsdGVyKChsYW5kbWFyaykgPT4gbGFuZG1hcmsua2luZCAhPT0gXCJjYW1wTWFya1wiKTtcbiAgaWYgKGlkID09PSBcImNhbXBSdXNoXCIpIHJldHVybiBzY2FsZWQuZmlsdGVyKChsYW5kbWFyaykgPT4gbGFuZG1hcmsua2luZCAhPT0gXCJtaW5lU2NhclwiIHx8IGxhbmRtYXJrLmlkID09PSBcInNjYXItcGxheWVyXCIgfHwgbGFuZG1hcmsuaWQgPT09IFwic2Nhci1lbmVteVwiKTtcbiAgaWYgKGlkID09PSBcImdyYW5kVGhpcnR5XCIpIHJldHVybiBncmFuZFRoaXJ0eUxhbmRtYXJrcygpO1xuICByZXR1cm4gc2NhbGVkO1xufVxuXG5mdW5jdGlvbiBzY2VuYXJpb0ZvcihpZDogTWFwSWQpIHtcbiAgY29uc3Qgc2NlbmFyaW8gPSBNQVBfU0NFTkFSSU9TLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBpZCk7XG4gIGlmICghc2NlbmFyaW8pIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBtYXAgc2NlbmFyaW8gJHtpZH1gKTtcbiAgcmV0dXJuIHNjZW5hcmlvO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFJlc291cmNlcyhtYXBJZDogTWFwSWQgPSBERUZBVUxUX01BUF9JRCwgcGxheWVyczogUGxheWVySWRbXSA9IFtcInBsYXllclwiLCBcImVuZW15XCJdLCB0ZWFtcz86IFBhcnRpYWw8UmVjb3JkPFBsYXllcklkLCBzdHJpbmc+Pik6IFJlc291cmNlTm9kZVtdIHtcbiAgaWYgKG1hcElkID09PSBcImNvbWJhdEFyZW5hXCIpIHJldHVybiBbXTtcbiAgaWYgKG1hcElkID09PSBcImdvbGRHcmlkXCIpIHJldHVybiBnb2xkR3JpZE1pbmVzKCk7XG4gIGlmIChtYXBJZCA9PT0gXCJncmFuZFRoaXJ0eVwiKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgIC4uLnBsYXllcnMubWFwKChvd25lciwgaW5kZXgpID0+IHtcbiAgICAgICAgY29uc3Qgc3RhcnQgPSBzdGFydFBvc2l0aW9uRm9yKG93bmVyLCBpbmRleCwgcGxheWVycy5sZW5ndGgsIFNUQU5EQVJEX01BUF9TSVpFICogMywgcGxheWVycywgdGVhbXMpO1xuICAgICAgICByZXR1cm4geyBpZDogYGdvbGQtJHtvd25lcn0tbWFpbmAsIGtpbmQ6IFwiZ29sZE1pbmVcIiBhcyBjb25zdCwgeDogc3RhcnQubWluZVgsIHk6IHN0YXJ0Lm1pbmVZLCBhbW91bnQ6IDZfMDAwIH07XG4gICAgICB9KSxcbiAgICAgIC4uLmdyYW5kVGhpcnR5RXhwYW5zaW9uTWluZXMoKSxcbiAgICBdO1xuICB9XG4gIGNvbnN0IG1haW5NaW5lczogUmVzb3VyY2VOb2RlW10gPSBwbGF5ZXJzLm1hcCgob3duZXIsIGluZGV4KSA9PiB7XG4gICAgY29uc3Qgc3RhcnQgPSBzdGFydFBvc2l0aW9uRm9yKG93bmVyLCBpbmRleCwgcGxheWVycy5sZW5ndGgsIFNUQU5EQVJEX01BUF9TSVpFLCBwbGF5ZXJzLCB0ZWFtcyk7XG4gICAgcmV0dXJuIHsgaWQ6IGBnb2xkLSR7b3duZXJ9LW1haW5gLCBraW5kOiBcImdvbGRNaW5lXCIgYXMgY29uc3QsIHg6IHN0YXJ0Lm1pbmVYLCB5OiBzdGFydC5taW5lWSwgYW1vdW50OiA2XzAwMCB9O1xuICB9KTtcbiAgY29uc3QgZXhwYW5zaW9uTWluZXM6IFJlc291cmNlTm9kZVtdID0gW1xuICAgIHsgaWQ6IFwiZ29sZC1ub3J0aC1yaWRnZVwiLCBraW5kOiBcImdvbGRNaW5lXCIsIHg6IDQwNjAsIHk6IDEzMjAsIGFtb3VudDogNl8wMDAgfSxcbiAgICB7IGlkOiBcImdvbGQtc291dGgtZ3JvdmVcIiwga2luZDogXCJnb2xkTWluZVwiLCB4OiAzNzIwLCB5OiA2MjYwLCBhbW91bnQ6IDZfMDAwIH0sXG4gICAgeyBpZDogXCJnb2xkLWNlbnRlci1zY2FyXCIsIGtpbmQ6IFwiZ29sZE1pbmVcIiwgeDogNDA5NiwgeTogNDIwMCwgYW1vdW50OiA2XzAwMCB9LFxuICBdO1xuICBpZiAobWFwSWQgPT09IFwiYmFyZUR1ZWxcIiB8fCBtYXBJZCA9PT0gXCJjYW1wUnVzaFwiKSByZXR1cm4gbWFpbk1pbmVzO1xuICByZXR1cm4gWy4uLm1haW5NaW5lcywgLi4uZXhwYW5zaW9uTWluZXMubWFwKHNjYWxlUmVzb3VyY2UpXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxNZXJjZW5hcnlDYW1wcyhtYXBJZDogTWFwSWQgPSBERUZBVUxUX01BUF9JRCk6IE1lcmNlbmFyeUNhbXBbXSB7XG4gIGlmIChtYXBJZCA9PT0gXCJjb21iYXRBcmVuYVwiKSByZXR1cm4gW107XG4gIGlmIChtYXBJZCA9PT0gXCJnb2xkR3JpZFwiKSByZXR1cm4gW107XG4gIGlmIChtYXBJZCA9PT0gXCJtZXJjUG9ja2V0XCIpIHJldHVybiBtZXJjUG9ja2V0Q2FtcHMoKTtcbiAgaWYgKG1hcElkID09PSBcImJhcmVEdWVsXCIgfHwgbWFwSWQgPT09IFwib3BlbkNsYWltc1wiKSByZXR1cm4gW107XG4gIGlmIChtYXBJZCA9PT0gXCJncmFuZFRoaXJ0eVwiKSByZXR1cm4gZ3JhbmRUaGlydHlNZXJjZW5hcnlDYW1wcygpO1xuICBjb25zdCBjYW1wczogTWVyY2VuYXJ5Q2FtcFtdID0gW1xuICAgIHsgaWQ6IFwibWVyYy1jYW1wLWNyb3Nzcm9hZFwiLCB4OiA2NDAwLCB5OiA2MDIwLCByYWRpdXM6IDU0LCBoaXJlS2luZDogXCJtZXJjZW5hcnlcIiwgY29zdDogVU5JVF9ERUZTLm1lcmNlbmFyeS5jb3N0LCBzdG9jazogNSwgY29vbGRvd246IHNlY29uZHMoOSksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJtZXJjLWNhbXAtYm93LXBvc3RcIiwgeDogNTg4MCwgeTogMzg4MCwgcmFkaXVzOiA1MCwgaGlyZUtpbmQ6IFwiY29udHJhY3RBcmNoZXJcIiwgY29zdDogVU5JVF9ERUZTLmNvbnRyYWN0QXJjaGVyLmNvc3QsIHN0b2NrOiAzLCBjb29sZG93bjogc2Vjb25kcygxNiksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJtZXJjLWNhbXAtZmllbGQtdGVudFwiLCB4OiAyNTIwLCB5OiAzMTAwLCByYWRpdXM6IDUwLCBoaXJlS2luZDogXCJmaWVsZE1lZGljXCIsIGNvc3Q6IFVOSVRfREVGUy5maWVsZE1lZGljLmNvc3QsIHN0b2NrOiAzLCBjb29sZG93bjogc2Vjb25kcygxOCksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gIF07XG4gIHJldHVybiBjYW1wcy5tYXAoc2NhbGVNZXJjZW5hcnlDYW1wKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxJdGVtcyhtYXBJZDogTWFwSWQgPSBERUZBVUxUX01BUF9JRCk6IFdvcmxkSXRlbVtdIHtcbiAgaWYgKG1hcElkID09PSBcImNvbWJhdEFyZW5hXCIpIHJldHVybiBbXTtcbiAgaWYgKG1hcElkID09PSBcImdvbGRHcmlkXCIgfHwgbWFwSWQgPT09IFwibWVyY1BvY2tldFwiKSByZXR1cm4gW107XG4gIGlmIChtYXBJZCA9PT0gXCJiYXJlRHVlbFwiIHx8IG1hcElkID09PSBcIm9wZW5DbGFpbXNcIikgcmV0dXJuIFtdO1xuICBjb25zdCBpdGVtczogV29ybGRJdGVtW10gPSBbXG4gICAgeyBpZDogXCJ0cmVhc3VyZS1jZW50ZXItbGlnaHRuaW5nXCIsIGtpbmQ6IFwibGlnaHRuaW5nUm9kXCIsIHg6IDAsIHk6IDAsIGNhcnJpZXJJZDogXCJ3aWxkbGluZy1jZW50ZXItMlwiLCBjb29sZG93blJlbWFpbmluZzogMCB9LFxuICAgIHsgaWQ6IFwidHJlYXN1cmUtc291dGgtYm9va1wiLCBraW5kOiBcImV4cGVyaWVuY2VCb29rXCIsIHg6IDAsIHk6IDAsIGNhcnJpZXJJZDogXCJ3aWxkbGluZy1zb3V0aC0yXCIsIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJ0cmVhc3VyZS1ub3J0aC1mbGFtZVwiLCBraW5kOiBcImZsYW1lQ2xvYWtcIiwgeDogMCwgeTogMCwgY2FycmllcklkOiBcIndpbGRsaW5nLW5vcnRoLTJcIiwgY29vbGRvd25SZW1haW5pbmc6IDAgfSxcbiAgICB7IGlkOiBcInRyZWFzdXJlLWZyZWUteWVsbG93LXNjcm9sbFwiLCBraW5kOiBcImd1YXJkaWFuU2Nyb2xsXCIsIHg6IDAsIHk6IDAsIGNhcnJpZXJJZDogXCJ3aWxkbGluZy1mcmVlLXllbGxvdy1ub3J0aC0yXCIsIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJ0cmVhc3VyZS1mcmVlLXJlZC1zdG9ybVwiLCBraW5kOiBcInN0b3JtU3RhZmZcIiwgeDogMCwgeTogMCwgY2FycmllcklkOiBcIndpbGRsaW5nLWZyZWUtcmVkLXdlc3QtMVwiLCBjb29sZG93blJlbWFpbmluZzogMCB9LFxuICAgIHsgaWQ6IFwidHJlYXN1cmUtZnJlZS1yZWQtYnJlYWNoXCIsIGtpbmQ6IFwiYnJlYWNoQ2hhcmdlXCIsIHg6IDAsIHk6IDAsIGNhcnJpZXJJZDogXCJ3aWxkbGluZy1mcmVlLXJlZC1lYXN0LTFcIiwgY29vbGRvd25SZW1haW5pbmc6IDAgfSxcbiAgXTtcbiAgaWYgKG1hcElkID09PSBcImdyYW5kVGhpcnR5XCIpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh7IGxlbmd0aDogMzAgfSwgKF8sIGluZGV4KSA9PiAoe1xuICAgICAgaWQ6IGB0cmVhc3VyZS1ncmFuZC0ke2luZGV4ICsgMX1gLFxuICAgICAga2luZDogZ3JhbmRUcmVhc3VyZUtpbmQoaW5kZXgpLFxuICAgICAgeDogMCxcbiAgICAgIHk6IDAsXG4gICAgICBjYXJyaWVySWQ6IGB3aWxkbGluZy1ncmFuZC0keyhpbmRleCAlIDE1KSArIDF9LSR7TWF0aC5mbG9vcihpbmRleCAvIDE1KSArIDF9YCxcbiAgICAgIGNvb2xkb3duUmVtYWluaW5nOiAwLFxuICAgIH0pKTtcbiAgfVxuICByZXR1cm4gaXRlbXM7XG59XG5cbmZ1bmN0aW9uIGdyYW5kVHJlYXN1cmVLaW5kKGluZGV4OiBudW1iZXIpOiBXb3JsZEl0ZW1bXCJraW5kXCJdIHtcbiAgY29uc3QgY3ljbGU6IFdvcmxkSXRlbVtcImtpbmRcIl1bXSA9IFtcImZsYW1lQ2xvYWtcIiwgXCJsaWdodG5pbmdSb2RcIiwgXCJzdG9ybVN0YWZmXCIsIFwiZ3VhcmRpYW5TY3JvbGxcIiwgXCJleHBlcmllbmNlQm9va1wiLCBcImJyZWFjaENoYXJnZVwiXTtcbiAgcmV0dXJuIGN5Y2xlW2luZGV4ICUgY3ljbGUubGVuZ3RoXSE7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVJbml0aWFsQnVpbGRpbmdzKHBsYXllcnM6IFBsYXllcklkW10gPSBbXCJwbGF5ZXJcIiwgXCJlbmVteVwiXSwgbWFwSWQ6IE1hcElkID0gREVGQVVMVF9NQVBfSUQsIHRlYW1zPzogUGFydGlhbDxSZWNvcmQ8UGxheWVySWQsIHN0cmluZz4+KTogQnVpbGRpbmdbXSB7XG4gIHJldHVybiBwbGF5ZXJzLm1hcCgob3duZXIsIGluZGV4KSA9PiB7XG4gICAgY29uc3Qgc3RhcnQgPSBzdGFydFBvc2l0aW9uRm9yKG93bmVyLCBpbmRleCwgcGxheWVycy5sZW5ndGgsIG1hcFNpemVGb3IobWFwSWQpLCBwbGF5ZXJzLCB0ZWFtcyk7XG4gICAgcmV0dXJuIGNyZWF0ZUJ1aWxkaW5nKGBidWlsZGluZy0ke293bmVyfS10b3duaGFsbGAsIG93bmVyLCBcInRvd25IYWxsXCIsIHN0YXJ0LmJhc2VYLCBzdGFydC5iYXNlWSwgdHJ1ZSk7XG4gIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFVuaXRzKG1hcElkOiBNYXBJZCA9IERFRkFVTFRfTUFQX0lELCBwbGF5ZXJzOiBQbGF5ZXJJZFtdID0gW1wicGxheWVyXCIsIFwiZW5lbXlcIl0sIHRlYW1zPzogUGFydGlhbDxSZWNvcmQ8UGxheWVySWQsIHN0cmluZz4+KTogVW5pdFtdIHtcbiAgY29uc3QgdW5pdHM6IFVuaXRbXSA9IHBsYXllcnMuZmxhdE1hcCgob3duZXIsIGluZGV4KSA9PiB7XG4gICAgY29uc3Qgc3RhcnQgPSBzdGFydFBvc2l0aW9uRm9yKG93bmVyLCBpbmRleCwgcGxheWVycy5sZW5ndGgsIG1hcFNpemVGb3IobWFwSWQpLCBwbGF5ZXJzLCB0ZWFtcyk7XG4gICAgcmV0dXJuIFtcbiAgICAgIGNyZWF0ZVVuaXQoYHVuaXQtJHtvd25lcn0td29ya2VyLTFgLCBvd25lciwgXCJ3b3JrZXJcIiwgc3RhcnQuYmFzZVggLSA1NSwgc3RhcnQuYmFzZVkgKyAxMCksXG4gICAgICBjcmVhdGVVbml0KGB1bml0LSR7b3duZXJ9LXdvcmtlci0yYCwgb3duZXIsIFwid29ya2VyXCIsIHN0YXJ0LmJhc2VYIC0gMTAsIHN0YXJ0LmJhc2VZICsgNjUpLFxuICAgIGNyZWF0ZVVuaXQoYHVuaXQtJHtvd25lcn0td29ya2VyLTNgLCBvd25lciwgXCJ3b3JrZXJcIiwgc3RhcnQuYmFzZVggKyA1NSwgc3RhcnQuYmFzZVkgKyA0MCksXG4gICAgXTtcbiAgfSk7XG4gIHVuaXRzLnB1c2goXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW5vcnRoLTFcIiwgXCJuZXV0cmFsXCIsIFwid2lsZGxpbmdcIiwgMzkyMCwgMTU2MCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW5vcnRoLTJcIiwgXCJuZXV0cmFsXCIsIFwidGhvcm5TbGluZ2VyXCIsIDQwMTAsIDE1MTApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1ub3J0aC0zXCIsIFwibmV1dHJhbFwiLCBcInN0b25lYmFja0JydXRlXCIsIDM5NzAsIDE2MjApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1ub3J0aC00XCIsIFwibmV1dHJhbFwiLCBcImdsYWRlV2l0Y2hcIiwgNDA1MCwgMTYwMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW5vcnRoLTVcIiwgXCJuZXV0cmFsXCIsIFwiYmFya01lbmRlclwiLCAzODkwLCAxNTAwKSxcbiAgICBjcmVhdGVVbml0KFwid2lsZGxpbmctY2VudGVyLTFcIiwgXCJuZXV0cmFsXCIsIFwic3RvbmViYWNrQnJ1dGVcIiwgMzk5NiwgNDA3MCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLWNlbnRlci0yXCIsIFwibmV1dHJhbFwiLCBcImdsYWRlV2l0Y2hcIiwgNDE3NiwgNDMxMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLWNlbnRlci0zXCIsIFwibmV1dHJhbFwiLCBcImJhcmtNZW5kZXJcIiwgNDA4NiwgNDIxMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLWNlbnRlci00XCIsIFwibmV1dHJhbFwiLCBcInRob3JuU2xpbmdlclwiLCAzOTc2LCA0MzAwKSxcbiAgICBjcmVhdGVVbml0KFwid2lsZGxpbmctc291dGgtMVwiLCBcIm5ldXRyYWxcIiwgXCJtb3NzR25hd2VyXCIsIDM1ODAsIDYwNDApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1zb3V0aC0yXCIsIFwibmV1dHJhbFwiLCBcImJhcmtNZW5kZXJcIiwgMzgxMCwgNjExMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLXNvdXRoLTNcIiwgXCJuZXV0cmFsXCIsIFwic3RvbmViYWNrQnJ1dGVcIiwgMzY5MCwgNjE2MCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLXNvdXRoLTRcIiwgXCJuZXV0cmFsXCIsIFwiZ2xhZGVXaXRjaFwiLCAzNzUwLCA2MDEwKSxcbiAgICBjcmVhdGVVbml0KFwid2lsZGxpbmctc291dGgtNVwiLCBcIm5ldXRyYWxcIiwgXCJ0aG9yblNsaW5nZXJcIiwgMzg2MCwgNjIwMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLXNvdXRoLTZcIiwgXCJuZXV0cmFsXCIsIFwidGhvcm5TbGluZ2VyXCIsIDM2MjAsIDYxNDApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1tZXJjLWNyb3Nzcm9hZC0xXCIsIFwibmV1dHJhbFwiLCBcInN0b25lYmFja0JydXRlXCIsIDYzMjAsIDU5ODApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1tZXJjLWNyb3Nzcm9hZC0yXCIsIFwibmV1dHJhbFwiLCBcInRob3JuU2xpbmdlclwiLCA2NDYwLCA2MDYwKSxcbiAgICBjcmVhdGVVbml0KFwid2lsZGxpbmctbWVyYy1jcm9zc3JvYWQtM1wiLCBcIm5ldXRyYWxcIiwgXCJiYXJrTWVuZGVyXCIsIDYzODAsIDYxMjApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1tZXJjLWJvdy0xXCIsIFwibmV1dHJhbFwiLCBcImdsYWRlV2l0Y2hcIiwgNTg0MCwgMzgyMCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW1lcmMtYm93LTJcIiwgXCJuZXV0cmFsXCIsIFwidGhvcm5TbGluZ2VyXCIsIDU5NjAsIDM5MjApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1tZXJjLWJvdy0zXCIsIFwibmV1dHJhbFwiLCBcImJhcmtNZW5kZXJcIiwgNTg4MCwgMzk4MCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW1lcmMtZmllbGQtMVwiLCBcIm5ldXRyYWxcIiwgXCJiYXJrTWVuZGVyXCIsIDI0ODAsIDMwNDApLFxuICAgIGNyZWF0ZVVuaXQoXCJ3aWxkbGluZy1tZXJjLWZpZWxkLTJcIiwgXCJuZXV0cmFsXCIsIFwid2lsZGxpbmdcIiwgMjU4MCwgMzE2MCksXG4gICAgY3JlYXRlVW5pdChcIndpbGRsaW5nLW1lcmMtZmllbGQtM1wiLCBcIm5ldXRyYWxcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCAyNTIwLCAzMjAwKSxcbiAgKTtcbiAgaWYgKG1hcElkID09PSBcImdyYW5kVGhpcnR5XCIpIHJldHVybiBbLi4udW5pdHMuZmlsdGVyKCh1bml0KSA9PiB1bml0Lm93bmVyICE9PSBcIm5ldXRyYWxcIiksIC4uLmdyYW5kVGhpcnR5V2lsZGxpbmdzKCldO1xuICBjb25zdCBwbGF5ZXJVbml0cyA9IHVuaXRzLmZpbHRlcigodW5pdCkgPT4gdW5pdC5vd25lciAhPT0gXCJuZXV0cmFsXCIpO1xuICBjb25zdCBuZXV0cmFsVW5pdHMgPSB1bml0cy5maWx0ZXIoKHVuaXQpID0+IHVuaXQub3duZXIgPT09IFwibmV1dHJhbFwiKTtcbiAgaWYgKG1hcElkID09PSBcImNvbWJhdEFyZW5hXCIpIHJldHVybiBwbGF5ZXJVbml0cztcbiAgaWYgKG1hcElkID09PSBcImdvbGRHcmlkXCIgfHwgbWFwSWQgPT09IFwibWVyY1BvY2tldFwiKSByZXR1cm4gcGxheWVyVW5pdHM7XG4gIGlmIChtYXBJZCA9PT0gXCJiYXJlRHVlbFwiIHx8IG1hcElkID09PSBcIm9wZW5DbGFpbXNcIikgcmV0dXJuIHBsYXllclVuaXRzO1xuICBjb25zdCBhdXRob3JlZE5ldXRyYWxzID0gWy4uLm5ldXRyYWxVbml0cy5tYXAoc2NhbGVVbml0KSwgLi4uZnJlZVdpbGRsaW5nQ2FtcHMobWFwSWQpXTtcbiAgcmV0dXJuIFsuLi5wbGF5ZXJVbml0cywgLi4ua2VlcE5ldXRyYWxVbml0c0F3YXlGcm9tUGxheWVyU3RhcnRzKGF1dGhvcmVkTmV1dHJhbHMsIG1hcElkLCBwbGF5ZXJzLCB0ZWFtcyldO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQnVpbGRpbmcoXG4gIGlkOiBzdHJpbmcsXG4gIG93bmVyOiBQbGF5ZXJJZCxcbiAga2luZDogQnVpbGRpbmdLaW5kLFxuICB4OiBudW1iZXIsXG4gIHk6IG51bWJlcixcbiAgY29tcGxldGU6IGJvb2xlYW4sXG4pOiBCdWlsZGluZyB7XG4gIGNvbnN0IGRlZiA9IEJVSUxESU5HX0RFRlNba2luZF07XG4gIHJldHVybiB7XG4gICAgaWQsXG4gICAgb3duZXIsXG4gICAga2luZCxcbiAgICB4LFxuICAgIHksXG4gICAgaHA6IGNvbXBsZXRlID8gZGVmLmhwIDogY29uc3RydWN0aW9uU3RhcnRIcChkZWYuaHApLFxuICAgIG1heEhwOiBkZWYuaHAsXG4gICAgcmFkaXVzOiBkZWYucmFkaXVzLFxuICAgIGNvbXBsZXRlLFxuICAgIGJ1aWxkUHJvZ3Jlc3M6IGNvbXBsZXRlID8gYnVpbGRUaW1lRm9yKGtpbmQpIDogMCxcbiAgICBidWlsZFRpbWU6IGJ1aWxkVGltZUZvcihraW5kKSxcbiAgICBhdHRhY2tEYW1hZ2U6IGRlZi5hdHRhY2tEYW1hZ2UsXG4gICAgYXR0YWNrUmFuZ2U6IGRlZi5hdHRhY2tSYW5nZSxcbiAgICBhdHRhY2tDb29sZG93bjogZGVmLmF0dGFja0Nvb2xkb3duLFxuICAgIGNvb2xkb3duOiAwLFxuICAgIHJhbGx5WDogeCArIDkwLFxuICAgIHJhbGx5WTogeSArIDYwLFxuICAgIHF1ZXVlOiBbXSxcbiAgICByZXNlYXJjaFF1ZXVlOiBbXSxcbiAgfTtcbn1cblxuLy8gQEBAdW5pdC1zaGFwZSAtIEEgdW5pdCBoYXMgZXZlcnkgZmllbGQgZnJvbSBiaXJ0aCwgaW4gdGhpcyBvcmRlciwgdGhlIG9uZXMgaXQgaGFzIG5vIHZhbHVlIGZvciB5ZXQgc2V0IHRvIHVuZGVmaW5lZDsgaXRcbi8vIG5ldmVyIGdhaW5zIG9yIGxvc2VzIG9uZSBsYXRlci4gVGhlIGVuZ2luZSBhbmQgdGhlIEFJcyByZWFkIHVuaXRzIGluIHRoZWlyIGhvdHRlc3QgbG9vcHMgKHNlcGFyYXRpb24sIHRhcmdldCBzZWFyY2gsXG4vLyBwbGFubmluZyksIGFuZCBWOCBtYWtlcyB0aG9zZSByZWFkcyBmYXN0IG9ubHkgd2hpbGUgdGhlIG9iamVjdHMgc2hhcmUgb25lIGhpZGRlbiBjbGFzcy4gQSBmaWVsZCBhZGRlZCB3aGVuIGEgdW5pdCBmaXJzdFxuLy8gbmVlZGVkIGl0ICh2YXJpYW50LCBhYmlsaXR5Q29vbGRvd25zLCBhdXRvY2FzdCwgZXhwaXJlc1RpY2ssIGluIHdoYXRldmVyIG9yZGVyIHRoYXQgaGFwcGVuZWQpIHNwbGl0IHVuaXRzIGludG8gc2V2ZXJhbFxuLy8gc2hhcGVzLCBhbmQgYSBkZWxldGUgZHJvcHBlZCBhIHVuaXQgaW50byBhIHNsb3cgZGljdGlvbmFyeTogc2VwYXJhdGluZyAxMjUgdW5pdHMgdG9vayAzNCB1cywgYWdhaW5zdCAxMCB1cyBmb3IgdGhlIHNhbWVcbi8vIHVuaXRzIGluIG9uZSBzaGFwZS4gSlNPTiAoc25hcHNob3RzLCBzYXZlcywgdGhlIG5ldCkgZHJvcHMgdGhlIHVuZGVmaW5lZCBmaWVsZHM7IGEgdW5pdCByZWFkIGJhY2sgZ2V0cyB0aGVtIGFnYWluIGZyb21cbi8vIHdpdGhVbml0U2hhcGUuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVW5pdChcbiAgaWQ6IHN0cmluZyxcbiAgb3duZXI6IE93bmVyLFxuICBraW5kOiBVbml0S2luZCxcbiAgeDogbnVtYmVyLFxuICB5OiBudW1iZXIsXG4pOiBVbml0IHtcbiAgY29uc3Qgc3RhdHMgPSBVTklUX0RFRlNba2luZF07XG4gIHJldHVybiB7XG4gICAgaWQsXG4gICAgb3duZXIsXG4gICAga2luZCxcbiAgICB4LFxuICAgIHksXG4gICAgaG9tZVg6IHgsXG4gICAgaG9tZVk6IHksXG4gICAgaHA6IHN0YXRzLmhwLFxuICAgIG1heEhwOiBzdGF0cy5ocCxcbiAgICBzcGVlZDogc3RhdHMuc3BlZWQsXG4gICAgYXR0YWNrRGFtYWdlOiBzdGF0cy5hdHRhY2tEYW1hZ2UsXG4gICAgYXR0YWNrUmFuZ2U6IHN0YXRzLmF0dGFja1JhbmdlLFxuICAgIGF0dGFja0Nvb2xkb3duOiBzdGF0cy5hdHRhY2tDb29sZG93bixcbiAgICBjb29sZG93bjogMCxcbiAgICByYWRpdXM6IHN0YXRzLnJhZGl1cyAqIChpc1NoaXBLaW5kKGtpbmQpID8gU0hJUF9TSVpFX01VTFRJUExJRVIgOiAxKSxcbiAgICBjYXJyeWluZ0dvbGQ6IDAsXG4gICAga2lsbHM6IDAsXG4gICAgeHA6IDAsXG4gICAgbGV2ZWw6IDAsXG4gICAgZWZmZWN0czogW10sXG4gICAgb3JkZXI6IHsgdHlwZTogXCJpZGxlXCIgfSxcbiAgICBvcmRlclF1ZXVlOiBbXSxcbiAgICB2YXJpYW50OiB1bmRlZmluZWQsXG4gICAgYWJpbGl0eUNvb2xkb3duczogdW5kZWZpbmVkLFxuICAgIGF1dG9jYXN0OiB1bmRlZmluZWQsXG4gICAgc3RhbmNlOiB1bmRlZmluZWQsXG4gICAgcHVzaFg6IHVuZGVmaW5lZCxcbiAgICBwdXNoWTogdW5kZWZpbmVkLFxuICAgIGFycml2ZWRBdDogdW5kZWZpbmVkLFxuICAgIGFpbTogdW5kZWZpbmVkLFxuICAgIGZhY2luZzogdW5kZWZpbmVkLFxuICAgIGhhbmRzOiB1bmRlZmluZWQsXG4gICAgZ2Vhck1hc3M6IHVuZGVmaW5lZCxcbiAgICBob2xkTWFzczogdW5kZWZpbmVkLFxuICAgIHNoaXBQYXJ0czogdW5kZWZpbmVkLFxuICAgIGZpdHRpbmdzOiB1bmRlZmluZWQsXG4gICAgYm9keVJhZGl1czogdW5kZWZpbmVkLFxuICAgIG1pbmVTbG90OiB1bmRlZmluZWQsXG4gICAgdmV0ZXJhblNraWxsOiB1bmRlZmluZWQsXG4gICAgdmV0ZXJhblNraWxsQ2hvaWNlczogdW5kZWZpbmVkLFxuICAgIGV4cGlyZXNUaWNrOiB1bmRlZmluZWQsXG4gICAgc2hpcFNpemVWZXJzaW9uOiBpc1NoaXBLaW5kKGtpbmQpID8gU0hJUF9TSVpFX1ZFUlNJT04gOiB1bmRlZmluZWQsXG4gIH07XG59XG5cbi8vIEEgdW5pdCByZWFkIGJhY2sgZnJvbSBKU09OLCBpbiB0aGUgb25lIHNoYXBlIG9mIGNyZWF0ZVVuaXQncyAoc2VlIEBAQHVuaXQtc2hhcGUpOiBpdHMgb3duIGZpZWxkcyBvdmVyIGEgZnJlc2ggdW5pdCdzLCB3aXRoXG4vLyB0aGUgb3B0aW9uYWwgZmllbGRzIGl0IGxhY2tzIGxlZnQgdW5kZWZpbmVkIHJhdGhlciB0aGFuIGZpbGxlZCBpbi5cbmV4cG9ydCBmdW5jdGlvbiB3aXRoVW5pdFNoYXBlKHVuaXQ6IFVuaXQpOiBVbml0IHtcbiAgcmV0dXJuIE9iamVjdC5hc3NpZ24oY3JlYXRlVW5pdCh1bml0LmlkLCB1bml0Lm93bmVyLCB1bml0LmtpbmQsIHVuaXQueCwgdW5pdC55KSwgeyBob21lWDogdW5kZWZpbmVkLCBob21lWTogdW5kZWZpbmVkLCBvcmRlclF1ZXVlOiB1bmRlZmluZWQsIHNoaXBTaXplVmVyc2lvbjogdW5kZWZpbmVkIH0sIHVuaXQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRUaW1lRm9yKGtpbmQ6IEJ1aWxkaW5nS2luZCkge1xuICByZXR1cm4gQlVJTERJTkdfREVGU1traW5kXS5idWlsZFRpbWU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0cmFpblRpbWVGb3Ioa2luZDogVHJhaW5hYmxlVW5pdEtpbmQpIHtcbiAgcmV0dXJuIFVOSVRfREVGU1traW5kXS50cmFpblRpbWU7XG59XG5cbmZ1bmN0aW9uIHNjYWxlKHZhbHVlOiBudW1iZXIpIHtcbiAgcmV0dXJuIHZhbHVlICogTUFQX1NDQUxFO1xufVxuXG5mdW5jdGlvbiBrZWVwTmV1dHJhbFVuaXRzQXdheUZyb21QbGF5ZXJTdGFydHModW5pdHM6IFVuaXRbXSwgbWFwSWQ6IE1hcElkLCBwbGF5ZXJzOiBQbGF5ZXJJZFtdLCB0ZWFtcz86IFBhcnRpYWw8UmVjb3JkPFBsYXllcklkLCBzdHJpbmc+Pikge1xuICBjb25zdCBtYXBTaXplID0gbWFwSWQgPT09IFwiZ3JhbmRUaGlydHlcIiA/IFNUQU5EQVJEX01BUF9TSVpFICogMyA6IFNUQU5EQVJEX01BUF9TSVpFO1xuICBjb25zdCBzYWZlR2FwID0gNDQwICogKG1hcFNpemUgLyBTVEFOREFSRF9NQVBfU0laRSk7XG4gIGNvbnN0IGNsYW1wID0gKHZhbHVlOiBudW1iZXIpID0+IE1hdGgubWF4KDgwLCBNYXRoLm1pbihtYXBTaXplIC0gODAsIHZhbHVlKSk7XG4gIGNvbnN0IHNhZmV0eVBvaW50cyA9IHBsYXllcnMuZmxhdE1hcCgob3duZXIsIGluZGV4KSA9PiB7XG4gICAgY29uc3Qgc3RhcnQgPSBzdGFydFBvc2l0aW9uRm9yKG93bmVyLCBpbmRleCwgcGxheWVycy5sZW5ndGgsIG1hcFNpemUsIHBsYXllcnMsIHRlYW1zKTtcbiAgICByZXR1cm4gW1xuICAgICAgeyB4OiBzdGFydC5iYXNlWCwgeTogc3RhcnQuYmFzZVkgfSxcbiAgICAgIHsgeDogc3RhcnQubWluZVgsIHk6IHN0YXJ0Lm1pbmVZIH0sXG4gICAgXTtcbiAgfSk7XG5cbiAgcmV0dXJuIHVuaXRzLm1hcCgodW5pdCkgPT4ge1xuICAgIGlmICh1bml0Lm93bmVyICE9PSBcIm5ldXRyYWxcIikgcmV0dXJuIHVuaXQ7XG4gICAgbGV0IHggPSB1bml0Lng7XG4gICAgbGV0IHkgPSB1bml0Lnk7XG4gICAgZm9yIChsZXQgcGFzcyA9IDA7IHBhc3MgPCA1OyBwYXNzICs9IDEpIHtcbiAgICAgIGxldCBtb3ZlZCA9IGZhbHNlO1xuICAgICAgZm9yIChjb25zdCBwb2ludCBvZiBzYWZldHlQb2ludHMpIHtcbiAgICAgICAgY29uc3QgZHggPSB4IC0gcG9pbnQueDtcbiAgICAgICAgY29uc3QgZHkgPSB5IC0gcG9pbnQueTtcbiAgICAgICAgY29uc3QgZ2FwID0gTWF0aC5oeXBvdChkeCwgZHkpO1xuICAgICAgICBpZiAoZ2FwID49IHNhZmVHYXApIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCB0aWVCcmVha1ggPSB4ID49IHBvaW50LnggPyAxIDogLTE7XG4gICAgICAgIGNvbnN0IHRpZUJyZWFrWSA9IHkgPj0gcG9pbnQueSA/IDEgOiAtMTtcbiAgICAgICAgY29uc3QgdW5pdFggPSBnYXAgPiAwID8gZHggLyBnYXAgOiB0aWVCcmVha1ggLyBNYXRoLlNRUlQyO1xuICAgICAgICBjb25zdCB1bml0WSA9IGdhcCA+IDAgPyBkeSAvIGdhcCA6IHRpZUJyZWFrWSAvIE1hdGguU1FSVDI7XG4gICAgICAgIGNvbnN0IHJhZGlhbCA9IHsgeDogY2xhbXAocG9pbnQueCArIHVuaXRYICogc2FmZUdhcCksIHk6IGNsYW1wKHBvaW50LnkgKyB1bml0WSAqIHNhZmVHYXApIH07XG4gICAgICAgIGNvbnN0IGNhbmRpZGF0ZXMgPSBbcmFkaWFsXTtcbiAgICAgICAgZm9yIChsZXQgYW5nbGVJbmRleCA9IDA7IGFuZ2xlSW5kZXggPCAxNjsgYW5nbGVJbmRleCArPSAxKSB7XG4gICAgICAgICAgY29uc3QgYW5nbGUgPSAoTWF0aC5QSSAqIDIgKiBhbmdsZUluZGV4KSAvIDE2O1xuICAgICAgICAgIGNhbmRpZGF0ZXMucHVzaCh7IHg6IGNsYW1wKHBvaW50LnggKyBkZXRDb3MoYW5nbGUpICogc2FmZUdhcCksIHk6IGNsYW1wKHBvaW50LnkgKyBkZXRTaW4oYW5nbGUpICogc2FmZUdhcCkgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYmVzdCA9IGNhbmRpZGF0ZXMucmVkdWNlKCh3aW5uZXIsIGNhbmRpZGF0ZSkgPT4gKG5lYXJlc3RTYWZldHlHYXAoY2FuZGlkYXRlKSA+IG5lYXJlc3RTYWZldHlHYXAod2lubmVyKSA/IGNhbmRpZGF0ZSA6IHdpbm5lciksIHJhZGlhbCk7XG4gICAgICAgIHggPSBiZXN0Lng7XG4gICAgICAgIHkgPSBiZXN0Lnk7XG4gICAgICAgIG1vdmVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghbW92ZWQpIGJyZWFrO1xuICAgIH1cbiAgICAvLyBAQEBzdGFydC1zYWZldHkgLSBNYXAtYXV0aG9yZWQgb2JqZWN0aXZlIGRlbnNpdHkgbXVzdCBub3Qgc3Bhd24gbmV1dHJhbCBhZ2dybyBpbnNpZGUgYSBwbGF5ZXIncyBvcGVuaW5nIGVjb25vbXkuXG4gICAgcmV0dXJuIHdpdGhVbml0SG9tZSh7IC4uLnVuaXQsIHgsIHkgfSwgeCwgeSk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIG5lYXJlc3RTYWZldHlHYXAocG9pbnQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSkge1xuICAgIHJldHVybiBNYXRoLm1pbiguLi5zYWZldHlQb2ludHMubWFwKChzdGFydCkgPT4gTWF0aC5oeXBvdChwb2ludC54IC0gc3RhcnQueCwgcG9pbnQueSAtIHN0YXJ0LnkpKSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZ29sZEdyaWRNaW5lcygpOiBSZXNvdXJjZU5vZGVbXSB7XG4gIGNvbnN0IHNsb3RzID0gZ29sZEdyaWRQb2ludHMoKTtcbiAgcmV0dXJuIHNsb3RzLm1hcCgocG9pbnQsIGluZGV4KSA9PiAoe1xuICAgIGlkOiBgZ29sZC1ncmlkLSR7aW5kZXggKyAxfWAsXG4gICAga2luZDogXCJnb2xkTWluZVwiIGFzIGNvbnN0LFxuICAgIHg6IHBvaW50LngsXG4gICAgeTogcG9pbnQueSxcbiAgICBhbW91bnQ6IDZfMDAwLFxuICB9KSk7XG59XG5cbmZ1bmN0aW9uIGdvbGRHcmlkUG9pbnRzKCkge1xuICBjb25zdCBsYW5lcyA9IFs2NDAsIDFfNTgwLCAyXzUyMCwgM180NTZdO1xuICByZXR1cm4gbGFuZXMuZmxhdE1hcCgoeSkgPT4gbGFuZXMubWFwKCh4KSA9PiAoeyB4LCB5IH0pKSk7XG59XG5cbmZ1bmN0aW9uIG1lcmNQb2NrZXRDYW1wcygpOiBNZXJjZW5hcnlDYW1wW10ge1xuICByZXR1cm4gW1xuICAgIHsgaWQ6IFwibWVyYy1wb2NrZXQtZnJvbnRsaW5lXCIsIHg6IDg0MCwgeTogNzYwLCByYWRpdXM6IDUwLCBoaXJlS2luZDogXCJtZXJjZW5hcnlcIiwgY29zdDogVU5JVF9ERUZTLm1lcmNlbmFyeS5jb3N0LCBzdG9jazogNSwgY29vbGRvd246IHNlY29uZHMoOSksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJtZXJjLXBvY2tldC1ib3dcIiwgeDogNzYwLCB5OiAxXzAyMCwgcmFkaXVzOiA1MCwgaGlyZUtpbmQ6IFwiY29udHJhY3RBcmNoZXJcIiwgY29zdDogVU5JVF9ERUZTLmNvbnRyYWN0QXJjaGVyLmNvc3QsIHN0b2NrOiAzLCBjb29sZG93bjogc2Vjb25kcygxNiksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gICAgeyBpZDogXCJtZXJjLXBvY2tldC1tZWRpY1wiLCB4OiAxXzAyMCwgeTogODQwLCByYWRpdXM6IDUwLCBoaXJlS2luZDogXCJmaWVsZE1lZGljXCIsIGNvc3Q6IFVOSVRfREVGUy5maWVsZE1lZGljLmNvc3QsIHN0b2NrOiAzLCBjb29sZG93bjogc2Vjb25kcygxOCksIGNvb2xkb3duUmVtYWluaW5nOiAwIH0sXG4gIF07XG59XG5cbmZ1bmN0aW9uIHNjYWxlTGFuZG1hcmsobGFuZG1hcms6IEdhbWVNYXBbXCJsYW5kbWFya3NcIl1bbnVtYmVyXSk6IEdhbWVNYXBbXCJsYW5kbWFya3NcIl1bbnVtYmVyXSB7XG4gIHJldHVybiB7IC4uLmxhbmRtYXJrLCB4OiBzY2FsZShsYW5kbWFyay54KSwgeTogc2NhbGUobGFuZG1hcmsueSksIHNpemU6IHNjYWxlKGxhbmRtYXJrLnNpemUpIH07XG59XG5cbmZ1bmN0aW9uIHNjYWxlUmVzb3VyY2UocmVzb3VyY2U6IFJlc291cmNlTm9kZSk6IFJlc291cmNlTm9kZSB7XG4gIHJldHVybiB7IC4uLnJlc291cmNlLCB4OiBzY2FsZShyZXNvdXJjZS54KSwgeTogc2NhbGUocmVzb3VyY2UueSkgfTtcbn1cblxuZnVuY3Rpb24gc2NhbGVNZXJjZW5hcnlDYW1wKGNhbXA6IE1lcmNlbmFyeUNhbXApOiBNZXJjZW5hcnlDYW1wIHtcbiAgcmV0dXJuIHsgLi4uY2FtcCwgeDogc2NhbGUoY2FtcC54KSwgeTogc2NhbGUoY2FtcC55KSwgcmFkaXVzOiBzY2FsZShjYW1wLnJhZGl1cykgfTtcbn1cblxuZnVuY3Rpb24gc2NhbGVVbml0KHVuaXQ6IFVuaXQpOiBVbml0IHtcbiAgY29uc3QgeCA9IHNjYWxlKHVuaXQueCk7XG4gIGNvbnN0IHkgPSBzY2FsZSh1bml0LnkpO1xuICByZXR1cm4gd2l0aFVuaXRIb21lKHsgLi4udW5pdCwgeCwgeSB9LCB4LCB5KTtcbn1cblxuZnVuY3Rpb24gd2l0aFVuaXRIb21lKHVuaXQ6IFVuaXQsIHg6IG51bWJlciwgeTogbnVtYmVyKTogVW5pdCB7XG4gIGlmICh1bml0LmhvbWVYID09PSB1bmRlZmluZWQgfHwgdW5pdC5ob21lWSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdW5pdDtcbiAgcmV0dXJuIHsgLi4udW5pdCwgaG9tZVg6IHgsIGhvbWVZOiB5IH07XG59XG5cbmZ1bmN0aW9uIHN0YXJ0UG9zaXRpb25Gb3IoXG4gIG93bmVyOiBQbGF5ZXJJZCxcbiAgaW5kZXg6IG51bWJlcixcbiAgdG90YWw6IG51bWJlcixcbiAgbWFwU2l6ZTogbnVtYmVyLFxuICBwbGF5ZXJzOiBQbGF5ZXJJZFtdID0gW1wicGxheWVyXCIsIFwiZW5lbXlcIl0sXG4gIHRlYW1zPzogUGFydGlhbDxSZWNvcmQ8UGxheWVySWQsIHN0cmluZz4+LFxuKSB7XG4gIGlmIChtYXBTaXplID09PSBTVEFOREFSRF9NQVBfU0laRSkge1xuICAgIGlmIChwbGF5ZXJzLmxlbmd0aCA9PT0gMiAmJiBvd25lciA9PT0gXCJwbGF5ZXJcIikgcmV0dXJuIHsgYmFzZVg6IHNjYWxlKDkwMCksIGJhc2VZOiBzY2FsZSg5MDApLCBtaW5lWDogc2NhbGUoOTAwKSArIEdPTERfTUlORV9SVUxFUy5tYWluRGlzdGFuY2UsIG1pbmVZOiBzY2FsZSg5MDApIH07XG4gICAgaWYgKHBsYXllcnMubGVuZ3RoID09PSAyICYmIG93bmVyID09PSBcImVuZW15XCIpIHJldHVybiB7IGJhc2VYOiBzY2FsZSg3MjQwKSwgYmFzZVk6IHNjYWxlKDcyNDApLCBtaW5lWDogc2NhbGUoNzI0MCkgLSBHT0xEX01JTkVfUlVMRVMubWFpbkRpc3RhbmNlLCBtaW5lWTogc2NhbGUoNzI0MCkgfTtcbiAgICBpZiAob3duZXIgPT09IFwiZW5lbXkyXCIpIHJldHVybiB7IGJhc2VYOiBtYXBTaXplIC0gNDgwLCBiYXNlWTogNDgwLCBtaW5lWDogbWFwU2l6ZSAtIDQ4MCAtIEdPTERfTUlORV9SVUxFUy5tYWluRGlzdGFuY2UsIG1pbmVZOiA0ODAgfTtcbiAgfVxuXG4gIGNvbnN0IHNpZGVTdGFydCA9IHNpZGVTdGFydEZvcihvd25lciwgaW5kZXgsIHRvdGFsLCBwbGF5ZXJzLCB0ZWFtcyk7XG4gIGNvbnN0IHNpZGUgPSBzaWRlU3RhcnQuc2lkZTtcbiAgY29uc3Qgc2lkZUluZGV4ID0gc2lkZVN0YXJ0LnNpZGVJbmRleDtcbiAgY29uc3Qgc2lkZUNvdW50ID0gc2lkZVN0YXJ0LnNpZGVDb3VudDtcbiAgY29uc3QgbGFuZSA9IChzaWRlSW5kZXggKyAxKSAvIChzaWRlQ291bnQgKyAxKTtcbiAgY29uc3QgeCA9IHNpZGUgPT09IDAgPyBtYXBTaXplICogMC4xMiA6IG1hcFNpemUgKiAwLjg4O1xuICBjb25zdCB5ID0gbWFwU2l6ZSAqICgwLjA4ICsgbGFuZSAqIDAuODQpO1xuICBjb25zdCBtaW5lWCA9IHNpZGUgPT09IDAgPyB4ICsgR09MRF9NSU5FX1JVTEVTLm1haW5EaXN0YW5jZSA6IHggLSBHT0xEX01JTkVfUlVMRVMubWFpbkRpc3RhbmNlO1xuICByZXR1cm4geyBiYXNlWDogeCwgYmFzZVk6IHksIG1pbmVYLCBtaW5lWTogeSB9O1xufVxuXG5mdW5jdGlvbiBzaWRlU3RhcnRGb3Iob3duZXI6IFBsYXllcklkLCBpbmRleDogbnVtYmVyLCB0b3RhbDogbnVtYmVyLCBwbGF5ZXJzOiBQbGF5ZXJJZFtdLCB0ZWFtcz86IFBhcnRpYWw8UmVjb3JkPFBsYXllcklkLCBzdHJpbmc+Pikge1xuICBpZiAodGVhbXMpIHtcbiAgICBjb25zdCB0ZWFtT3JkZXIgPSBbLi4ubmV3IFNldChwbGF5ZXJzLm1hcCgocGxheWVyKSA9PiB0ZWFtc1twbGF5ZXJdID8/IHBsYXllcikpXTtcbiAgICBpZiAodGVhbU9yZGVyLmxlbmd0aCA9PT0gMikge1xuICAgICAgY29uc3Qgb3duZXJUZWFtID0gdGVhbXNbb3duZXJdID8/IG93bmVyO1xuICAgICAgY29uc3Qgc2lkZVBsYXllcnMgPSBwbGF5ZXJzLmZpbHRlcigocGxheWVyKSA9PiAodGVhbXNbcGxheWVyXSA/PyBwbGF5ZXIpID09PSBvd25lclRlYW0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2lkZTogdGVhbU9yZGVyLmluZGV4T2Yob3duZXJUZWFtKSA9PT0gMCA/IDAgOiAxLFxuICAgICAgICBzaWRlSW5kZXg6IE1hdGgubWF4KDAsIHNpZGVQbGF5ZXJzLmluZGV4T2Yob3duZXIpKSxcbiAgICAgICAgc2lkZUNvdW50OiBzaWRlUGxheWVycy5sZW5ndGgsXG4gICAgICB9O1xuICAgIH1cbiAgfVxuICBjb25zdCBzaWRlID0gaW5kZXggPCBNYXRoLmNlaWwodG90YWwgLyAyKSA/IDAgOiAxO1xuICByZXR1cm4ge1xuICAgIHNpZGUsXG4gICAgc2lkZUluZGV4OiBzaWRlID09PSAwID8gaW5kZXggOiBpbmRleCAtIE1hdGguY2VpbCh0b3RhbCAvIDIpLFxuICAgIHNpZGVDb3VudDogc2lkZSA9PT0gMCA/IE1hdGguY2VpbCh0b3RhbCAvIDIpIDogTWF0aC5mbG9vcih0b3RhbCAvIDIpLFxuICB9O1xufVxuXG5mdW5jdGlvbiBncmFuZFRoaXJ0eUxhbmRtYXJrcygpOiBHYW1lTWFwW1wibGFuZG1hcmtzXCJdIHtcbiAgY29uc3QgbWFwU2l6ZSA9IFNUQU5EQVJEX01BUF9TSVpFICogMztcbiAgY29uc3QgbGFuZG1hcmtzOiBHYW1lTWFwW1wibGFuZG1hcmtzXCJdID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTU7IGkgKz0gMSkge1xuICAgIGNvbnN0IHkgPSBtYXBTaXplICogKChpICsgMSkgLyAxNik7XG4gICAgbGFuZG1hcmtzLnB1c2goXG4gICAgICB7IGlkOiBgZ3JhbmQtcm9hZC0ke2l9YCwga2luZDogXCJyb2FkXCIsIHg6IG1hcFNpemUgLyAyLCB5LCBzaXplOiA3MjAsIHJvdGF0aW9uOiBpICUgMiA9PT0gMCA/IDAuMSA6IC0wLjEgfSxcbiAgICAgIHsgaWQ6IGBncmFuZC1ncm92ZS13ZXN0LSR7aX1gLCBraW5kOiBcImdyb3ZlXCIsIHg6IG1hcFNpemUgKiAwLjI3LCB5OiB5ICsgMTIwLCBzaXplOiAyNjAsIHJvdGF0aW9uOiBpICogMC4yIH0sXG4gICAgICB7IGlkOiBgZ3JhbmQtcmlkZ2UtZWFzdC0ke2l9YCwga2luZDogXCJyaWRnZVwiLCB4OiBtYXBTaXplICogMC43MywgeTogeSAtIDEyMCwgc2l6ZTogMjgwLCByb3RhdGlvbjogLWkgKiAwLjE4IH0sXG4gICAgICB7IGlkOiBgZ3JhbmQtY2FtcC0ke2l9YCwga2luZDogXCJjYW1wTWFya1wiLCB4OiBtYXBTaXplICogKGkgJSAyID09PSAwID8gMC40MiA6IDAuNTgpLCB5LCBzaXplOiAxODAsIHJvdGF0aW9uOiBpICogMC4zMSB9LFxuICAgICk7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSArPSAxKSB7XG4gICAgbGFuZG1hcmtzLnB1c2goeyBpZDogYGdyYW5kLXJ1aW4tJHtpfWAsIGtpbmQ6IFwicnVpblwiLCB4OiBtYXBTaXplICogKDAuMzUgKyAoaSAlIDUpICogMC4wNzUpLCB5OiBtYXBTaXplICogKDAuMTUgKyBNYXRoLmZsb29yKGkgLyA1KSAqIDAuNyksIHNpemU6IDI0MCwgcm90YXRpb246IGkgKiAwLjIxIH0pO1xuICB9XG4gIHJldHVybiBsYW5kbWFya3M7XG59XG5cbmZ1bmN0aW9uIGdyYW5kVGhpcnR5RXhwYW5zaW9uTWluZXMoKTogUmVzb3VyY2VOb2RlW10ge1xuICBjb25zdCBtYXBTaXplID0gU1RBTkRBUkRfTUFQX1NJWkUgKiAzO1xuICByZXR1cm4gQXJyYXkuZnJvbSh7IGxlbmd0aDogMTggfSwgKF8sIGluZGV4KSA9PiB7XG4gICAgY29uc3QgbGFuZSA9IChpbmRleCAlIDkpICsgMTtcbiAgICBjb25zdCByb3cgPSBNYXRoLmZsb29yKGluZGV4IC8gOSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlkOiBgZ29sZC1ncmFuZC1leHBhbnNpb24tJHtpbmRleCArIDF9YCxcbiAgICAgIGtpbmQ6IFwiZ29sZE1pbmVcIiBhcyBjb25zdCxcbiAgICAgIHg6IG1hcFNpemUgKiAocm93ID09PSAwID8gMC4zNyA6IDAuNjMpLFxuICAgICAgeTogbWFwU2l6ZSAqIChsYW5lIC8gMTApLFxuICAgICAgYW1vdW50OiA2XzAwMCxcbiAgICB9O1xuICB9KTtcbn1cblxuZnVuY3Rpb24gZ3JhbmRUaGlydHlNZXJjZW5hcnlDYW1wcygpOiBNZXJjZW5hcnlDYW1wW10ge1xuICBjb25zdCBtYXBTaXplID0gU1RBTkRBUkRfTUFQX1NJWkUgKiAzO1xuICBjb25zdCBraW5kczogTWVyY2VuYXJ5VW5pdEtpbmRbXSA9IFtcIm1lcmNlbmFyeVwiLCBcImNvbnRyYWN0QXJjaGVyXCIsIFwiZmllbGRNZWRpY1wiLCBcIm1lcmNlbmFyeVwiLCBcImNvbnRyYWN0QXJjaGVyXCIsIFwiZmllbGRNZWRpY1wiXTtcbiAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IDYgfSwgKF8sIGluZGV4KSA9PiB7XG4gICAgY29uc3QgaGlyZUtpbmQgPSBraW5kc1tpbmRleF0hO1xuICAgIGNvbnN0IGd1YXJkZWRDYW1wSW5kZXggPSBpbmRleCAqIDIgKyAxO1xuICAgIGNvbnN0IHggPSBtYXBTaXplICogKGd1YXJkZWRDYW1wSW5kZXggJSAyID09PSAwID8gMC40NCA6IDAuNTYpO1xuICAgIHJldHVybiB7XG4gICAgICBpZDogYG1lcmMtZ3JhbmQtbGFuZS0ke2luZGV4ICsgMX1gLFxuICAgICAgeCxcbiAgICAgIHk6IG1hcFNpemUgKiAoKGd1YXJkZWRDYW1wSW5kZXggKyAxKSAvIDE2KSxcbiAgICAgIHJhZGl1czogNzIsXG4gICAgICBoaXJlS2luZCxcbiAgICAgIGNvc3Q6IFVOSVRfREVGU1toaXJlS2luZF0uY29zdCxcbiAgICAgIHN0b2NrOiBpbmRleCAlIDMgPT09IDIgPyAzIDogNCxcbiAgICAgIGNvb2xkb3duOiBzZWNvbmRzKGluZGV4ICUgMyA9PT0gMiA/IDE4IDogMTYpLFxuICAgICAgY29vbGRvd25SZW1haW5pbmc6IDAsXG4gICAgfTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGdyYW5kVGhpcnR5V2lsZGxpbmdzKCk6IFVuaXRbXSB7XG4gIGNvbnN0IG1hcFNpemUgPSBTVEFOREFSRF9NQVBfU0laRSAqIDM7XG4gIGNvbnN0IGtpbmRzOiBVbml0S2luZFtdID0gW1wibW9zc0duYXdlclwiLCBcInRob3JuU2xpbmdlclwiLCBcImJhcmtNZW5kZXJcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCBcImdsYWRlV2l0Y2hcIiwgXCJhbmNpZW50U3RhZ1wiXTtcbiAgY29uc3QgdW5pdHM6IFVuaXRbXSA9IFtdO1xuICBmb3IgKGxldCBjYW1wID0gMDsgY2FtcCA8IDE1OyBjYW1wICs9IDEpIHtcbiAgICBjb25zdCB4ID0gbWFwU2l6ZSAqIChjYW1wICUgMiA9PT0gMCA/IDAuNDQgOiAwLjU2KTtcbiAgICBjb25zdCB5ID0gbWFwU2l6ZSAqICgoY2FtcCArIDEpIC8gMTYpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMzsgaSArPSAxKSB7XG4gICAgICB1bml0cy5wdXNoKGNyZWF0ZVVuaXQoYHdpbGRsaW5nLWdyYW5kLSR7Y2FtcCArIDF9LSR7aSArIDF9YCwgXCJuZXV0cmFsXCIsIGtpbmRzWyhjYW1wICsgaSkgJSBraW5kcy5sZW5ndGhdISwgeCArIChpIC0gMSkgKiA0MiwgeSArIChpICUgMiA9PT0gMCA/IC0zNCA6IDM0KSkpO1xuICAgIH1cbiAgICBpZiAoY2FtcCAlIDUgPT09IDQpIHtcbiAgICAgIHVuaXRzLnB1c2goXG4gICAgICAgIGNyZWF0ZVVuaXQoYHdpbGRsaW5nLWdyYW5kLSR7Y2FtcCArIDF9LWxlYWRlcmAsIFwibmV1dHJhbFwiLCBcImFuY2llbnRTdGFnXCIsIHggKyA3MiwgeSAtIDcyKSxcbiAgICAgICAgY3JlYXRlVW5pdChgd2lsZGxpbmctZ3JhbmQtJHtjYW1wICsgMX0tZ3VhcmRgLCBcIm5ldXRyYWxcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCB4IC0gNzIsIHkgKyA3MiksXG4gICAgICAgIGNyZWF0ZVVuaXQoYHdpbGRsaW5nLWdyYW5kLSR7Y2FtcCArIDF9LWhleGAsIFwibmV1dHJhbFwiLCBcImdsYWRlV2l0Y2hcIiwgeCArIDgsIHkgKyA5MiksXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdW5pdHM7XG59XG5cbmZ1bmN0aW9uIGZyZWVXaWxkbGluZ0NhbXBzKG1hcElkOiBNYXBJZCk6IFVuaXRbXSB7XG4gIGlmIChtYXBJZCAhPT0gXCJ2ZXJkYW50Q3Jvc3Nyb2Fkc1wiICYmIG1hcElkICE9PSBcImNhbXBSdXNoXCIpIHJldHVybiBbXTtcbiAgcmV0dXJuIFtcbiAgICAuLi53aWxkbGluZ0NhbXAoXCJ3aWxkbGluZy1mcmVlLWdyZWVuLXdlc3RcIiwgODIwLCAyNDkwLCBbXCJtb3NzR25hd2VyXCIsIFwid2lsZGxpbmdcIl0pLFxuICAgIC4uLndpbGRsaW5nQ2FtcChcIndpbGRsaW5nLWZyZWUteWVsbG93LW5vcnRoXCIsIDI4MDAsIDg1MCwgW1wic3RvbmViYWNrQnJ1dGVcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCBcImdsYWRlV2l0Y2hcIiwgXCJ0aG9yblNsaW5nZXJcIl0pLFxuICAgIC4uLndpbGRsaW5nQ2FtcChcIndpbGRsaW5nLWZyZWUtcmVkLXdlc3RcIiwgNjIwLCAzMzMwLCBbXCJhbmNpZW50U3RhZ1wiLCBcImFuY2llbnRTdGFnXCIsIFwic3RvbmViYWNrQnJ1dGVcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCBcImdsYWRlV2l0Y2hcIiwgXCJ0aG9yblNsaW5nZXJcIl0pLFxuICAgIC4uLndpbGRsaW5nQ2FtcChcIndpbGRsaW5nLWZyZWUteWVsbG93LWVhc3RcIiwgMzAwMCwgMTA0MCwgW1wic3RvbmViYWNrQnJ1dGVcIiwgXCJnbGFkZVdpdGNoXCIsIFwidGhvcm5TbGluZ2VyXCIsIFwiYmFya01lbmRlclwiXSksXG4gICAgLi4ud2lsZGxpbmdDYW1wKFwid2lsZGxpbmctZnJlZS1yZWQtZWFzdFwiLCAyMzAwLCAzMzAwLCBbXCJhbmNpZW50U3RhZ1wiLCBcImFuY2llbnRTdGFnXCIsIFwic3RvbmViYWNrQnJ1dGVcIiwgXCJzdG9uZWJhY2tCcnV0ZVwiLCBcImdsYWRlV2l0Y2hcIiwgXCJ0aG9yblNsaW5nZXJcIl0pLFxuICAgIC4uLndpbGRsaW5nQ2FtcChcIndpbGRsaW5nLWZyZWUtZ3JlZW4tZWFzdFwiLCAzNjUwLCAyMjgwLCBbXCJ3aWxkbGluZ1wiLCBcInRob3JuU2xpbmdlclwiXSksXG4gICAgLi4ud2lsZGxpbmdDYW1wKFwid2lsZGxpbmctZnJlZS1ncmVlbi1zb3V0aFwiLCAxNDkwLCAzNTYwLCBbXCJtb3NzR25hd2VyXCIsIFwiYmFya01lbmRlclwiXSksXG4gIF07XG59XG5cbmZ1bmN0aW9uIHdpbGRsaW5nQ2FtcChwcmVmaXg6IHN0cmluZywgeDogbnVtYmVyLCB5OiBudW1iZXIsIGtpbmRzOiBVbml0S2luZFtdKTogVW5pdFtdIHtcbiAgcmV0dXJuIGtpbmRzLm1hcCgoa2luZCwgaW5kZXgpID0+IHtcbiAgICBjb25zdCBhbmdsZSA9IChNYXRoLlBJICogMiAqIGluZGV4KSAvIE1hdGgubWF4KDEsIGtpbmRzLmxlbmd0aCk7XG4gICAgY29uc3QgcmFkaXVzID0gaW5kZXggPT09IDAgPyAwIDogNDQgKyAoaW5kZXggJSAyKSAqIDE2O1xuICAgIHJldHVybiBjcmVhdGVVbml0KGAke3ByZWZpeH0tJHtpbmRleCArIDF9YCwgXCJuZXV0cmFsXCIsIGtpbmQsIHggKyBkZXRDb3MoYW5nbGUpICogcmFkaXVzLCB5ICsgZGV0U2luKGFuZ2xlKSAqIHJhZGl1cyk7XG4gIH0pO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGVBQWUsV0FBVywyQkFBMkI7QUFDOUQsU0FBUyxRQUFRLGNBQWM7QUFDL0IsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsWUFBWSxzQkFBc0IseUJBQXlCO0FBR3BFLFNBQVMsZUFBZSx1QkFBdUI7QUFTeEMsYUFBTSxpQkFBd0I7QUFDOUIsYUFBTSxvQkFBb0I7QUFDMUIsYUFBTSx3QkFBd0I7QUFDckMsTUFBTSxrQkFBa0I7QUFDeEIsTUFBTSxZQUFZLG9CQUFvQjtBQUUvQixhQUFNLGdCQUErQjtBQUFBLEVBQzFDLEVBQUUsSUFBSSxVQUFVLE1BQU0sY0FBYyxNQUFNLDJNQUEyTSxNQUFNLENBQUMsYUFBYSxXQUFXLGNBQWMsY0FBYyxPQUFPLEVBQUU7QUFBQSxFQUN6VCxHQUFHLFNBQVMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLE9BQU8sa0NBQWtDLElBQUksT0FBTyxTQUFTLFVBQVUsMENBQTBDLHlCQUF5QixLQUFLLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxPQUFPLFlBQVksSUFBSSxPQUFPLE1BQU0sR0FBSSxVQUFVLElBQUksU0FBUyxDQUFDLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFFLEVBQUUsRUFBRTtBQUFBLEVBQ3pVLEVBQUUsSUFBSSxxQkFBcUIsTUFBTSxzQkFBc0IsTUFBTSxvRkFBb0YsTUFBTSxDQUFDLFFBQVEsY0FBYyxjQUFjLE9BQU8sRUFBRTtBQUFBLEVBQ3JNLEVBQUUsSUFBSSxZQUFZLE1BQU0sYUFBYSxNQUFNLDZFQUE2RSxNQUFNLENBQUMsUUFBUSxhQUFhLGNBQWMsRUFBRTtBQUFBLEVBQ3BLLEVBQUUsSUFBSSxjQUFjLE1BQU0sZUFBZSxNQUFNLDJFQUEyRSxNQUFNLENBQUMsUUFBUSxjQUFjLGVBQWUsRUFBRTtBQUFBLEVBQ3hLLEVBQUUsSUFBSSxZQUFZLE1BQU0sYUFBYSxNQUFNLGtGQUFrRixNQUFNLENBQUMsUUFBUSxpQkFBaUIsWUFBWSxFQUFFO0FBQUEsRUFDM0ssRUFBRSxJQUFJLGVBQWUsTUFBTSxnQkFBZ0IsTUFBTSxrRkFBa0YsTUFBTSxDQUFDLFFBQVEsVUFBVSxPQUFPLEVBQUU7QUFBQSxFQUNySyxFQUFFLElBQUksWUFBWSxNQUFNLGFBQWEsTUFBTSxxRkFBcUYsTUFBTSxDQUFDLFFBQVEsWUFBWSxjQUFjLGVBQWUsRUFBRTtBQUFBLEVBQzFMLEVBQUUsSUFBSSxjQUFjLE1BQU0sZUFBZSxNQUFNLDhGQUE4RixNQUFNLENBQUMsUUFBUSxZQUFZLFNBQVMsZUFBZSxFQUFFO0FBQUEsRUFDbE0sRUFBRSxJQUFJLGVBQWUsTUFBTSxnQkFBZ0IsTUFBTSw2R0FBNkcsTUFBTSxDQUFDLFNBQVMsU0FBUyxVQUFVLFlBQVksRUFBRTtBQUNqTjtBQUVPLGdCQUFTLFVBQVUsS0FBWSxnQkFBeUI7QUFDN0QsUUFBTSxXQUFXLFlBQVksRUFBRTtBQUMvQixRQUFNLFVBQVUsV0FBVyxFQUFFO0FBQzdCLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFBQSxJQUNmLE9BQU87QUFBQSxJQUNQLFFBQVE7QUFBQSxJQUNSLFdBQVcsa0JBQWtCLEVBQUU7QUFBQSxFQUNqQztBQUNGO0FBRU8sYUFBTSxhQUFzQixVQUFVLGNBQWM7QUFFM0QsU0FBUyxXQUFXLElBQVc7QUFDN0IsTUFBSSxPQUFPLGNBQWUsUUFBTyxvQkFBb0I7QUFDckQsTUFBSSxPQUFPLGNBQWUsUUFBTztBQUNqQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixJQUFpQztBQUMxRCxRQUFNLFlBQWtDO0FBQUEsSUFDdEMsRUFBRSxJQUFJLGVBQWUsTUFBTSxRQUFRLEdBQUcsTUFBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQzlFLEVBQUUsSUFBSSxjQUFjLE1BQU0sUUFBUSxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUM3RSxFQUFFLElBQUksY0FBYyxNQUFNLFFBQVEsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDN0UsRUFBRSxJQUFJLGVBQWUsTUFBTSxRQUFRLEdBQUcsTUFBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQzlFLEVBQUUsSUFBSSxnQkFBZ0IsTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQy9FLEVBQUUsSUFBSSxlQUFlLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUMvRSxFQUFFLElBQUksZ0JBQWdCLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUNoRixFQUFFLElBQUksZUFBZSxNQUFNLFNBQVMsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDL0UsRUFBRSxJQUFJLGVBQWUsTUFBTSxTQUFTLEdBQUcsTUFBTSxHQUFHLEtBQUssTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQzlFLEVBQUUsSUFBSSxjQUFjLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUM5RSxFQUFFLElBQUksZUFBZSxNQUFNLFNBQVMsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDL0UsRUFBRSxJQUFJLGlCQUFpQixNQUFNLFFBQVEsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDaEYsRUFBRSxJQUFJLGlCQUFpQixNQUFNLFFBQVEsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDaEYsRUFBRSxJQUFJLGNBQWMsTUFBTSxTQUFTLEdBQUcsTUFBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSztBQUFBLElBQy9FLEVBQUUsSUFBSSxjQUFjLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLEtBQUs7QUFBQSxJQUMvRSxFQUFFLElBQUksY0FBYyxNQUFNLFlBQVksR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDakYsRUFBRSxJQUFJLGVBQWUsTUFBTSxZQUFZLEdBQUcsTUFBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQ2xGLEVBQUUsSUFBSSxjQUFjLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUNqRixFQUFFLElBQUksZUFBZSxNQUFNLFlBQVksR0FBRyxNQUFNLEdBQUcsS0FBSyxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDakYsRUFBRSxJQUFJLGNBQWMsTUFBTSxZQUFZLEdBQUcsS0FBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLElBQ2pGLEVBQUUsSUFBSSxlQUFlLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUNsRixFQUFFLElBQUksbUJBQW1CLE1BQU0sZUFBZSxHQUFHLE1BQU0sR0FBRyxNQUFNLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxJQUN6RixFQUFFLElBQUksY0FBYyxNQUFNLGVBQWUsR0FBRyxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0FBQUEsSUFDcEYsRUFBRSxJQUFJLGNBQWMsTUFBTSxlQUFlLEdBQUcsTUFBTSxHQUFHLE1BQU0sTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLEVBQ3RGO0FBQ0EsUUFBTSxTQUFTLFVBQVUsSUFBSSxhQUFhO0FBQzFDLE1BQUksT0FBTyxjQUFlLFFBQU8sQ0FBQztBQUNsQyxNQUFJLE9BQU8sV0FBWSxRQUFPLE9BQU8sT0FBTyxDQUFDLGFBQWEsU0FBUyxTQUFTLFVBQVUsRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNuRyxNQUFJLE9BQU8sYUFBYyxRQUFPLE9BQU8sT0FBTyxDQUFDLGFBQWEsU0FBUyxTQUFTLFVBQVU7QUFDeEYsTUFBSSxPQUFPLFdBQVksUUFBTyxPQUFPLE9BQU8sQ0FBQyxhQUFhLFNBQVMsU0FBUyxjQUFjLFNBQVMsT0FBTyxpQkFBaUIsU0FBUyxPQUFPLFlBQVk7QUFDdkosTUFBSSxPQUFPLGNBQWUsUUFBTyxxQkFBcUI7QUFDdEQsU0FBTztBQUNUO0FBRUEsU0FBUyxZQUFZLElBQVc7QUFDOUIsUUFBTSxXQUFXLGNBQWMsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLEVBQUU7QUFDdEUsTUFBSSxDQUFDLFNBQVUsT0FBTSxJQUFJLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtBQUMzRCxTQUFPO0FBQ1Q7QUFFTyxnQkFBUyx1QkFBdUIsUUFBZSxnQkFBZ0IsVUFBc0IsQ0FBQyxVQUFVLE9BQU8sR0FBRyxPQUEyRDtBQUMxSyxNQUFJLFVBQVUsY0FBZSxRQUFPLENBQUM7QUFDckMsTUFBSSxVQUFVLFdBQVksUUFBTyxjQUFjO0FBQy9DLE1BQUksVUFBVSxlQUFlO0FBQzNCLFdBQU87QUFBQSxNQUNMLEdBQUcsUUFBUSxJQUFJLENBQUMsT0FBTyxVQUFVO0FBQy9CLGNBQU0sUUFBUSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsUUFBUSxvQkFBb0IsR0FBRyxTQUFTLEtBQUs7QUFDbEcsZUFBTyxFQUFFLElBQUksUUFBUSxLQUFLLFNBQVMsTUFBTSxZQUFxQixHQUFHLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxRQUFRLElBQU07QUFBQSxNQUM5RyxDQUFDO0FBQUEsTUFDRCxHQUFHLDBCQUEwQjtBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBNEIsUUFBUSxJQUFJLENBQUMsT0FBTyxVQUFVO0FBQzlELFVBQU0sUUFBUSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsUUFBUSxtQkFBbUIsU0FBUyxLQUFLO0FBQzlGLFdBQU8sRUFBRSxJQUFJLFFBQVEsS0FBSyxTQUFTLE1BQU0sWUFBcUIsR0FBRyxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sUUFBUSxJQUFNO0FBQUEsRUFDOUcsQ0FBQztBQUNELFFBQU0saUJBQWlDO0FBQUEsSUFDckMsRUFBRSxJQUFJLG9CQUFvQixNQUFNLFlBQVksR0FBRyxNQUFNLEdBQUcsTUFBTSxRQUFRLElBQU07QUFBQSxJQUM1RSxFQUFFLElBQUksb0JBQW9CLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxNQUFNLFFBQVEsSUFBTTtBQUFBLElBQzVFLEVBQUUsSUFBSSxvQkFBb0IsTUFBTSxZQUFZLEdBQUcsTUFBTSxHQUFHLE1BQU0sUUFBUSxJQUFNO0FBQUEsRUFDOUU7QUFDQSxNQUFJLFVBQVUsY0FBYyxVQUFVLFdBQVksUUFBTztBQUN6RCxTQUFPLENBQUMsR0FBRyxXQUFXLEdBQUcsZUFBZSxJQUFJLGFBQWEsQ0FBQztBQUM1RDtBQUVPLGdCQUFTLDRCQUE0QixRQUFlLGdCQUFpQztBQUMxRixNQUFJLFVBQVUsY0FBZSxRQUFPLENBQUM7QUFDckMsTUFBSSxVQUFVLFdBQVksUUFBTyxDQUFDO0FBQ2xDLE1BQUksVUFBVSxhQUFjLFFBQU8sZ0JBQWdCO0FBQ25ELE1BQUksVUFBVSxjQUFjLFVBQVUsYUFBYyxRQUFPLENBQUM7QUFDNUQsTUFBSSxVQUFVLGNBQWUsUUFBTywwQkFBMEI7QUFDOUQsUUFBTSxRQUF5QjtBQUFBLElBQzdCLEVBQUUsSUFBSSx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsTUFBTSxRQUFRLElBQUksVUFBVSxhQUFhLE1BQU0sVUFBVSxVQUFVLE1BQU0sT0FBTyxHQUFHLFVBQVUsUUFBUSxDQUFDLEdBQUcsbUJBQW1CLEVBQUU7QUFBQSxJQUN2SyxFQUFFLElBQUksc0JBQXNCLEdBQUcsTUFBTSxHQUFHLE1BQU0sUUFBUSxJQUFJLFVBQVUsa0JBQWtCLE1BQU0sVUFBVSxlQUFlLE1BQU0sT0FBTyxHQUFHLFVBQVUsUUFBUSxFQUFFLEdBQUcsbUJBQW1CLEVBQUU7QUFBQSxJQUNqTCxFQUFFLElBQUksd0JBQXdCLEdBQUcsTUFBTSxHQUFHLE1BQU0sUUFBUSxJQUFJLFVBQVUsY0FBYyxNQUFNLFVBQVUsV0FBVyxNQUFNLE9BQU8sR0FBRyxVQUFVLFFBQVEsRUFBRSxHQUFHLG1CQUFtQixFQUFFO0FBQUEsRUFDN0s7QUFDQSxTQUFPLE1BQU0sSUFBSSxrQkFBa0I7QUFDckM7QUFFTyxnQkFBUyxtQkFBbUIsUUFBZSxnQkFBNkI7QUFDN0UsTUFBSSxVQUFVLGNBQWUsUUFBTyxDQUFDO0FBQ3JDLE1BQUksVUFBVSxjQUFjLFVBQVUsYUFBYyxRQUFPLENBQUM7QUFDNUQsTUFBSSxVQUFVLGNBQWMsVUFBVSxhQUFjLFFBQU8sQ0FBQztBQUM1RCxRQUFNLFFBQXFCO0FBQUEsSUFDekIsRUFBRSxJQUFJLDZCQUE2QixNQUFNLGdCQUFnQixHQUFHLEdBQUcsR0FBRyxHQUFHLFdBQVcscUJBQXFCLG1CQUFtQixFQUFFO0FBQUEsSUFDMUgsRUFBRSxJQUFJLHVCQUF1QixNQUFNLGtCQUFrQixHQUFHLEdBQUcsR0FBRyxHQUFHLFdBQVcsb0JBQW9CLG1CQUFtQixFQUFFO0FBQUEsSUFDckgsRUFBRSxJQUFJLHdCQUF3QixNQUFNLGNBQWMsR0FBRyxHQUFHLEdBQUcsR0FBRyxXQUFXLG9CQUFvQixtQkFBbUIsRUFBRTtBQUFBLElBQ2xILEVBQUUsSUFBSSwrQkFBK0IsTUFBTSxrQkFBa0IsR0FBRyxHQUFHLEdBQUcsR0FBRyxXQUFXLGdDQUFnQyxtQkFBbUIsRUFBRTtBQUFBLElBQ3pJLEVBQUUsSUFBSSwyQkFBMkIsTUFBTSxjQUFjLEdBQUcsR0FBRyxHQUFHLEdBQUcsV0FBVyw0QkFBNEIsbUJBQW1CLEVBQUU7QUFBQSxJQUM3SCxFQUFFLElBQUksNEJBQTRCLE1BQU0sZ0JBQWdCLEdBQUcsR0FBRyxHQUFHLEdBQUcsV0FBVyw0QkFBNEIsbUJBQW1CLEVBQUU7QUFBQSxFQUNsSTtBQUNBLE1BQUksVUFBVSxlQUFlO0FBQzNCLFdBQU8sTUFBTSxLQUFLLEVBQUUsUUFBUSxHQUFHLEdBQUcsQ0FBQyxHQUFHLFdBQVc7QUFBQSxNQUMvQyxJQUFJLGtCQUFrQixRQUFRLENBQUM7QUFBQSxNQUMvQixNQUFNLGtCQUFrQixLQUFLO0FBQUEsTUFDN0IsR0FBRztBQUFBLE1BQ0gsR0FBRztBQUFBLE1BQ0gsV0FBVyxrQkFBbUIsUUFBUSxLQUFNLENBQUMsSUFBSSxLQUFLLE1BQU0sUUFBUSxFQUFFLElBQUksQ0FBQztBQUFBLE1BQzNFLG1CQUFtQjtBQUFBLElBQ3JCLEVBQUU7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsT0FBa0M7QUFDM0QsUUFBTSxRQUE2QixDQUFDLGNBQWMsZ0JBQWdCLGNBQWMsa0JBQWtCLGtCQUFrQixjQUFjO0FBQ2xJLFNBQU8sTUFBTSxRQUFRLE1BQU0sTUFBTTtBQUNuQztBQUVPLGdCQUFTLHVCQUF1QixVQUFzQixDQUFDLFVBQVUsT0FBTyxHQUFHLFFBQWUsZ0JBQWdCLE9BQXVEO0FBQ3RLLFNBQU8sUUFBUSxJQUFJLENBQUMsT0FBTyxVQUFVO0FBQ25DLFVBQU0sUUFBUSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsUUFBUSxXQUFXLEtBQUssR0FBRyxTQUFTLEtBQUs7QUFDOUYsV0FBTyxlQUFlLFlBQVksS0FBSyxhQUFhLE9BQU8sWUFBWSxNQUFNLE9BQU8sTUFBTSxPQUFPLElBQUk7QUFBQSxFQUN2RyxDQUFDO0FBQ0g7QUFFTyxnQkFBUyxtQkFBbUIsUUFBZSxnQkFBZ0IsVUFBc0IsQ0FBQyxVQUFVLE9BQU8sR0FBRyxPQUFtRDtBQUM5SixRQUFNLFFBQWdCLFFBQVEsUUFBUSxDQUFDLE9BQU8sVUFBVTtBQUN0RCxVQUFNLFFBQVEsaUJBQWlCLE9BQU8sT0FBTyxRQUFRLFFBQVEsV0FBVyxLQUFLLEdBQUcsU0FBUyxLQUFLO0FBQzlGLFdBQU87QUFBQSxNQUNMLFdBQVcsUUFBUSxLQUFLLGFBQWEsT0FBTyxVQUFVLE1BQU0sUUFBUSxJQUFJLE1BQU0sUUFBUSxFQUFFO0FBQUEsTUFDeEYsV0FBVyxRQUFRLEtBQUssYUFBYSxPQUFPLFVBQVUsTUFBTSxRQUFRLElBQUksTUFBTSxRQUFRLEVBQUU7QUFBQSxNQUMxRixXQUFXLFFBQVEsS0FBSyxhQUFhLE9BQU8sVUFBVSxNQUFNLFFBQVEsSUFBSSxNQUFNLFFBQVEsRUFBRTtBQUFBLElBQ3hGO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTTtBQUFBLElBQ0osV0FBVyxvQkFBb0IsV0FBVyxZQUFZLE1BQU0sSUFBSTtBQUFBLElBQ2hFLFdBQVcsb0JBQW9CLFdBQVcsZ0JBQWdCLE1BQU0sSUFBSTtBQUFBLElBQ3BFLFdBQVcsb0JBQW9CLFdBQVcsa0JBQWtCLE1BQU0sSUFBSTtBQUFBLElBQ3RFLFdBQVcsb0JBQW9CLFdBQVcsY0FBYyxNQUFNLElBQUk7QUFBQSxJQUNsRSxXQUFXLG9CQUFvQixXQUFXLGNBQWMsTUFBTSxJQUFJO0FBQUEsSUFDbEUsV0FBVyxxQkFBcUIsV0FBVyxrQkFBa0IsTUFBTSxJQUFJO0FBQUEsSUFDdkUsV0FBVyxxQkFBcUIsV0FBVyxjQUFjLE1BQU0sSUFBSTtBQUFBLElBQ25FLFdBQVcscUJBQXFCLFdBQVcsY0FBYyxNQUFNLElBQUk7QUFBQSxJQUNuRSxXQUFXLHFCQUFxQixXQUFXLGdCQUFnQixNQUFNLElBQUk7QUFBQSxJQUNyRSxXQUFXLG9CQUFvQixXQUFXLGNBQWMsTUFBTSxJQUFJO0FBQUEsSUFDbEUsV0FBVyxvQkFBb0IsV0FBVyxjQUFjLE1BQU0sSUFBSTtBQUFBLElBQ2xFLFdBQVcsb0JBQW9CLFdBQVcsa0JBQWtCLE1BQU0sSUFBSTtBQUFBLElBQ3RFLFdBQVcsb0JBQW9CLFdBQVcsY0FBYyxNQUFNLElBQUk7QUFBQSxJQUNsRSxXQUFXLG9CQUFvQixXQUFXLGdCQUFnQixNQUFNLElBQUk7QUFBQSxJQUNwRSxXQUFXLG9CQUFvQixXQUFXLGdCQUFnQixNQUFNLElBQUk7QUFBQSxJQUNwRSxXQUFXLDZCQUE2QixXQUFXLGtCQUFrQixNQUFNLElBQUk7QUFBQSxJQUMvRSxXQUFXLDZCQUE2QixXQUFXLGdCQUFnQixNQUFNLElBQUk7QUFBQSxJQUM3RSxXQUFXLDZCQUE2QixXQUFXLGNBQWMsTUFBTSxJQUFJO0FBQUEsSUFDM0UsV0FBVyx1QkFBdUIsV0FBVyxjQUFjLE1BQU0sSUFBSTtBQUFBLElBQ3JFLFdBQVcsdUJBQXVCLFdBQVcsZ0JBQWdCLE1BQU0sSUFBSTtBQUFBLElBQ3ZFLFdBQVcsdUJBQXVCLFdBQVcsY0FBYyxNQUFNLElBQUk7QUFBQSxJQUNyRSxXQUFXLHlCQUF5QixXQUFXLGNBQWMsTUFBTSxJQUFJO0FBQUEsSUFDdkUsV0FBVyx5QkFBeUIsV0FBVyxZQUFZLE1BQU0sSUFBSTtBQUFBLElBQ3JFLFdBQVcseUJBQXlCLFdBQVcsa0JBQWtCLE1BQU0sSUFBSTtBQUFBLEVBQzdFO0FBQ0EsTUFBSSxVQUFVLGNBQWUsUUFBTyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsU0FBUyxLQUFLLFVBQVUsU0FBUyxHQUFHLEdBQUcscUJBQXFCLENBQUM7QUFDbkgsUUFBTSxjQUFjLE1BQU0sT0FBTyxDQUFDLFNBQVMsS0FBSyxVQUFVLFNBQVM7QUFDbkUsUUFBTSxlQUFlLE1BQU0sT0FBTyxDQUFDLFNBQVMsS0FBSyxVQUFVLFNBQVM7QUFDcEUsTUFBSSxVQUFVLGNBQWUsUUFBTztBQUNwQyxNQUFJLFVBQVUsY0FBYyxVQUFVLGFBQWMsUUFBTztBQUMzRCxNQUFJLFVBQVUsY0FBYyxVQUFVLGFBQWMsUUFBTztBQUMzRCxRQUFNLG1CQUFtQixDQUFDLEdBQUcsYUFBYSxJQUFJLFNBQVMsR0FBRyxHQUFHLGtCQUFrQixLQUFLLENBQUM7QUFDckYsU0FBTyxDQUFDLEdBQUcsYUFBYSxHQUFHLHFDQUFxQyxrQkFBa0IsT0FBTyxTQUFTLEtBQUssQ0FBQztBQUMxRztBQUVPLGdCQUFTLGVBQ2QsSUFDQSxPQUNBLE1BQ0EsR0FDQSxHQUNBLFVBQ1U7QUFDVixRQUFNLE1BQU0sY0FBYyxJQUFJO0FBQzlCLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsSUFBSSxXQUFXLElBQUksS0FBSyxvQkFBb0IsSUFBSSxFQUFFO0FBQUEsSUFDbEQsT0FBTyxJQUFJO0FBQUEsSUFDWCxRQUFRLElBQUk7QUFBQSxJQUNaO0FBQUEsSUFDQSxlQUFlLFdBQVcsYUFBYSxJQUFJLElBQUk7QUFBQSxJQUMvQyxXQUFXLGFBQWEsSUFBSTtBQUFBLElBQzVCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLGFBQWEsSUFBSTtBQUFBLElBQ2pCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsVUFBVTtBQUFBLElBQ1YsUUFBUSxJQUFJO0FBQUEsSUFDWixRQUFRLElBQUk7QUFBQSxJQUNaLE9BQU8sQ0FBQztBQUFBLElBQ1IsZUFBZSxDQUFDO0FBQUEsRUFDbEI7QUFDRjtBQVNPLGdCQUFTLFdBQ2QsSUFDQSxPQUNBLE1BQ0EsR0FDQSxHQUNNO0FBQ04sUUFBTSxRQUFRLFVBQVUsSUFBSTtBQUM1QixTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLElBQUksTUFBTTtBQUFBLElBQ1YsT0FBTyxNQUFNO0FBQUEsSUFDYixPQUFPLE1BQU07QUFBQSxJQUNiLGNBQWMsTUFBTTtBQUFBLElBQ3BCLGFBQWEsTUFBTTtBQUFBLElBQ25CLGdCQUFnQixNQUFNO0FBQUEsSUFDdEIsVUFBVTtBQUFBLElBQ1YsUUFBUSxNQUFNLFVBQVUsV0FBVyxJQUFJLElBQUksdUJBQXVCO0FBQUEsSUFDbEUsY0FBYztBQUFBLElBQ2QsT0FBTztBQUFBLElBQ1AsSUFBSTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1AsU0FBUyxDQUFDO0FBQUEsSUFDVixPQUFPLEVBQUUsTUFBTSxPQUFPO0FBQUEsSUFDdEIsWUFBWSxDQUFDO0FBQUEsSUFDYixTQUFTO0FBQUEsSUFDVCxrQkFBa0I7QUFBQSxJQUNsQixVQUFVO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxXQUFXO0FBQUEsSUFDWCxLQUFLO0FBQUEsSUFDTCxRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsSUFDVixXQUFXO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWixVQUFVO0FBQUEsSUFDVixjQUFjO0FBQUEsSUFDZCxxQkFBcUI7QUFBQSxJQUNyQixhQUFhO0FBQUEsSUFDYixpQkFBaUIsV0FBVyxJQUFJLElBQUksb0JBQW9CO0FBQUEsRUFDMUQ7QUFDRjtBQUlPLGdCQUFTLGNBQWMsTUFBa0I7QUFDOUMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLFFBQVcsT0FBTyxRQUFXLFlBQVksUUFBVyxpQkFBaUIsT0FBVSxHQUFHLElBQUk7QUFDbEw7QUFFTyxnQkFBUyxhQUFhLE1BQW9CO0FBQy9DLFNBQU8sY0FBYyxJQUFJLEVBQUU7QUFDN0I7QUFFTyxnQkFBUyxhQUFhLE1BQXlCO0FBQ3BELFNBQU8sVUFBVSxJQUFJLEVBQUU7QUFDekI7QUFFQSxTQUFTLE1BQU0sT0FBZTtBQUM1QixTQUFPLFFBQVE7QUFDakI7QUFFQSxTQUFTLHFDQUFxQyxPQUFlLE9BQWMsU0FBcUIsT0FBMkM7QUFDekksUUFBTSxVQUFVLFVBQVUsZ0JBQWdCLG9CQUFvQixJQUFJO0FBQ2xFLFFBQU0sVUFBVSxPQUFPLFVBQVU7QUFDakMsUUFBTSxRQUFRLENBQUMsVUFBa0IsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLFVBQVUsSUFBSSxLQUFLLENBQUM7QUFDM0UsUUFBTSxlQUFlLFFBQVEsUUFBUSxDQUFDLE9BQU8sVUFBVTtBQUNyRCxVQUFNLFFBQVEsaUJBQWlCLE9BQU8sT0FBTyxRQUFRLFFBQVEsU0FBUyxTQUFTLEtBQUs7QUFDcEYsV0FBTztBQUFBLE1BQ0wsRUFBRSxHQUFHLE1BQU0sT0FBTyxHQUFHLE1BQU0sTUFBTTtBQUFBLE1BQ2pDLEVBQUUsR0FBRyxNQUFNLE9BQU8sR0FBRyxNQUFNLE1BQU07QUFBQSxJQUNuQztBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQU8sTUFBTSxJQUFJLENBQUMsU0FBUztBQUN6QixRQUFJLEtBQUssVUFBVSxVQUFXLFFBQU87QUFDckMsUUFBSSxJQUFJLEtBQUs7QUFDYixRQUFJLElBQUksS0FBSztBQUNiLGFBQVMsT0FBTyxHQUFHLE9BQU8sR0FBRyxRQUFRLEdBQUc7QUFDdEMsVUFBSSxRQUFRO0FBQ1osaUJBQVcsU0FBUyxjQUFjO0FBQ2hDLGNBQU0sS0FBSyxJQUFJLE1BQU07QUFDckIsY0FBTSxLQUFLLElBQUksTUFBTTtBQUNyQixjQUFNLE1BQU0sS0FBSyxNQUFNLElBQUksRUFBRTtBQUM3QixZQUFJLE9BQU8sUUFBUztBQUNwQixjQUFNLFlBQVksS0FBSyxNQUFNLElBQUksSUFBSTtBQUNyQyxjQUFNLFlBQVksS0FBSyxNQUFNLElBQUksSUFBSTtBQUNyQyxjQUFNLFFBQVEsTUFBTSxJQUFJLEtBQUssTUFBTSxZQUFZLEtBQUs7QUFDcEQsY0FBTSxRQUFRLE1BQU0sSUFBSSxLQUFLLE1BQU0sWUFBWSxLQUFLO0FBQ3BELGNBQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxNQUFNLElBQUksUUFBUSxPQUFPLEdBQUcsR0FBRyxNQUFNLE1BQU0sSUFBSSxRQUFRLE9BQU8sRUFBRTtBQUMxRixjQUFNLGFBQWEsQ0FBQyxNQUFNO0FBQzFCLGlCQUFTLGFBQWEsR0FBRyxhQUFhLElBQUksY0FBYyxHQUFHO0FBQ3pELGdCQUFNLFFBQVMsS0FBSyxLQUFLLElBQUksYUFBYztBQUMzQyxxQkFBVyxLQUFLLEVBQUUsR0FBRyxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUssSUFBSSxPQUFPLEdBQUcsR0FBRyxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUssSUFBSSxPQUFPLEVBQUUsQ0FBQztBQUFBLFFBQzlHO0FBQ0EsY0FBTSxPQUFPLFdBQVcsT0FBTyxDQUFDLFFBQVEsY0FBZSxpQkFBaUIsU0FBUyxJQUFJLGlCQUFpQixNQUFNLElBQUksWUFBWSxRQUFTLE1BQU07QUFDM0ksWUFBSSxLQUFLO0FBQ1QsWUFBSSxLQUFLO0FBQ1QsZ0JBQVE7QUFBQSxNQUNWO0FBQ0EsVUFBSSxDQUFDLE1BQU87QUFBQSxJQUNkO0FBRUEsV0FBTyxhQUFhLEVBQUUsR0FBRyxNQUFNLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzdDLENBQUM7QUFFRCxXQUFTLGlCQUFpQixPQUFpQztBQUN6RCxXQUFPLEtBQUssSUFBSSxHQUFHLGFBQWEsSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLE1BQU0sSUFBSSxNQUFNLEdBQUcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFBQSxFQUNsRztBQUNGO0FBRUEsU0FBUyxnQkFBZ0M7QUFDdkMsUUFBTSxRQUFRLGVBQWU7QUFDN0IsU0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLFdBQVc7QUFBQSxJQUNsQyxJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQUEsSUFDMUIsTUFBTTtBQUFBLElBQ04sR0FBRyxNQUFNO0FBQUEsSUFDVCxHQUFHLE1BQU07QUFBQSxJQUNULFFBQVE7QUFBQSxFQUNWLEVBQUU7QUFDSjtBQUVBLFNBQVMsaUJBQWlCO0FBQ3hCLFFBQU0sUUFBUSxDQUFDLEtBQUssTUFBTyxNQUFPLElBQUs7QUFDdkMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxNQUFNLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDO0FBQzFEO0FBRUEsU0FBUyxrQkFBbUM7QUFDMUMsU0FBTztBQUFBLElBQ0wsRUFBRSxJQUFJLHlCQUF5QixHQUFHLEtBQUssR0FBRyxLQUFLLFFBQVEsSUFBSSxVQUFVLGFBQWEsTUFBTSxVQUFVLFVBQVUsTUFBTSxPQUFPLEdBQUcsVUFBVSxRQUFRLENBQUMsR0FBRyxtQkFBbUIsRUFBRTtBQUFBLElBQ3ZLLEVBQUUsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLEdBQUcsTUFBTyxRQUFRLElBQUksVUFBVSxrQkFBa0IsTUFBTSxVQUFVLGVBQWUsTUFBTSxPQUFPLEdBQUcsVUFBVSxRQUFRLEVBQUUsR0FBRyxtQkFBbUIsRUFBRTtBQUFBLElBQzlLLEVBQUUsSUFBSSxxQkFBcUIsR0FBRyxNQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksVUFBVSxjQUFjLE1BQU0sVUFBVSxXQUFXLE1BQU0sT0FBTyxHQUFHLFVBQVUsUUFBUSxFQUFFLEdBQUcsbUJBQW1CLEVBQUU7QUFBQSxFQUMxSztBQUNGO0FBRUEsU0FBUyxjQUFjLFVBQXNFO0FBQzNGLFNBQU8sRUFBRSxHQUFHLFVBQVUsR0FBRyxNQUFNLFNBQVMsQ0FBQyxHQUFHLEdBQUcsTUFBTSxTQUFTLENBQUMsR0FBRyxNQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUU7QUFDL0Y7QUFFQSxTQUFTLGNBQWMsVUFBc0M7QUFDM0QsU0FBTyxFQUFFLEdBQUcsVUFBVSxHQUFHLE1BQU0sU0FBUyxDQUFDLEdBQUcsR0FBRyxNQUFNLFNBQVMsQ0FBQyxFQUFFO0FBQ25FO0FBRUEsU0FBUyxtQkFBbUIsTUFBb0M7QUFDOUQsU0FBTyxFQUFFLEdBQUcsTUFBTSxHQUFHLE1BQU0sS0FBSyxDQUFDLEdBQUcsR0FBRyxNQUFNLEtBQUssQ0FBQyxHQUFHLFFBQVEsTUFBTSxLQUFLLE1BQU0sRUFBRTtBQUNuRjtBQUVBLFNBQVMsVUFBVSxNQUFrQjtBQUNuQyxRQUFNLElBQUksTUFBTSxLQUFLLENBQUM7QUFDdEIsUUFBTSxJQUFJLE1BQU0sS0FBSyxDQUFDO0FBQ3RCLFNBQU8sYUFBYSxFQUFFLEdBQUcsTUFBTSxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUM7QUFDN0M7QUFFQSxTQUFTLGFBQWEsTUFBWSxHQUFXLEdBQWlCO0FBQzVELE1BQUksS0FBSyxVQUFVLFVBQWEsS0FBSyxVQUFVLE9BQVcsUUFBTztBQUNqRSxTQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sR0FBRyxPQUFPLEVBQUU7QUFDdkM7QUFFQSxTQUFTLGlCQUNQLE9BQ0EsT0FDQSxPQUNBLFNBQ0EsVUFBc0IsQ0FBQyxVQUFVLE9BQU8sR0FDeEMsT0FDQTtBQUNBLE1BQUksWUFBWSxtQkFBbUI7QUFDakMsUUFBSSxRQUFRLFdBQVcsS0FBSyxVQUFVLFNBQVUsUUFBTyxFQUFFLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTyxNQUFNLEdBQUcsR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLGdCQUFnQixjQUFjLE9BQU8sTUFBTSxHQUFHLEVBQUU7QUFDbkssUUFBSSxRQUFRLFdBQVcsS0FBSyxVQUFVLFFBQVMsUUFBTyxFQUFFLE9BQU8sTUFBTSxJQUFJLEdBQUcsT0FBTyxNQUFNLElBQUksR0FBRyxPQUFPLE1BQU0sSUFBSSxJQUFJLGdCQUFnQixjQUFjLE9BQU8sTUFBTSxJQUFJLEVBQUU7QUFDdEssUUFBSSxVQUFVLFNBQVUsUUFBTyxFQUFFLE9BQU8sVUFBVSxLQUFLLE9BQU8sS0FBSyxPQUFPLFVBQVUsTUFBTSxnQkFBZ0IsY0FBYyxPQUFPLElBQUk7QUFBQSxFQUNySTtBQUVBLFFBQU0sWUFBWSxhQUFhLE9BQU8sT0FBTyxPQUFPLFNBQVMsS0FBSztBQUNsRSxRQUFNLE9BQU8sVUFBVTtBQUN2QixRQUFNLFlBQVksVUFBVTtBQUM1QixRQUFNLFlBQVksVUFBVTtBQUM1QixRQUFNLFFBQVEsWUFBWSxNQUFNLFlBQVk7QUFDNUMsUUFBTSxJQUFJLFNBQVMsSUFBSSxVQUFVLE9BQU8sVUFBVTtBQUNsRCxRQUFNLElBQUksV0FBVyxPQUFPLE9BQU87QUFDbkMsUUFBTSxRQUFRLFNBQVMsSUFBSSxJQUFJLGdCQUFnQixlQUFlLElBQUksZ0JBQWdCO0FBQ2xGLFNBQU8sRUFBRSxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU8sT0FBTyxFQUFFO0FBQy9DO0FBRUEsU0FBUyxhQUFhLE9BQWlCLE9BQWUsT0FBZSxTQUFxQixPQUEyQztBQUNuSSxNQUFJLE9BQU87QUFDVCxVQUFNLFlBQVksQ0FBQyxHQUFHLElBQUksSUFBSSxRQUFRLElBQUksQ0FBQyxXQUFXLE1BQU0sTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0FBQy9FLFFBQUksVUFBVSxXQUFXLEdBQUc7QUFDMUIsWUFBTSxZQUFZLE1BQU0sS0FBSyxLQUFLO0FBQ2xDLFlBQU0sY0FBYyxRQUFRLE9BQU8sQ0FBQyxZQUFZLE1BQU0sTUFBTSxLQUFLLFlBQVksU0FBUztBQUN0RixhQUFPO0FBQUEsUUFDTCxNQUFNLFVBQVUsUUFBUSxTQUFTLE1BQU0sSUFBSSxJQUFJO0FBQUEsUUFDL0MsV0FBVyxLQUFLLElBQUksR0FBRyxZQUFZLFFBQVEsS0FBSyxDQUFDO0FBQUEsUUFDakQsV0FBVyxZQUFZO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxRQUFRLEtBQUssS0FBSyxRQUFRLENBQUMsSUFBSSxJQUFJO0FBQ2hELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxXQUFXLFNBQVMsSUFBSSxRQUFRLFFBQVEsS0FBSyxLQUFLLFFBQVEsQ0FBQztBQUFBLElBQzNELFdBQVcsU0FBUyxJQUFJLEtBQUssS0FBSyxRQUFRLENBQUMsSUFBSSxLQUFLLE1BQU0sUUFBUSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLFNBQVMsdUJBQTZDO0FBQ3BELFFBQU0sVUFBVSxvQkFBb0I7QUFDcEMsUUFBTSxZQUFrQyxDQUFDO0FBQ3pDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDOUIsVUFBTSxJQUFJLFlBQVksSUFBSSxLQUFLO0FBQy9CLGNBQVU7QUFBQSxNQUNSLEVBQUUsSUFBSSxjQUFjLENBQUMsSUFBSSxNQUFNLFFBQVEsR0FBRyxVQUFVLEdBQUcsR0FBRyxNQUFNLEtBQUssVUFBVSxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxNQUN4RyxFQUFFLElBQUksb0JBQW9CLENBQUMsSUFBSSxNQUFNLFNBQVMsR0FBRyxVQUFVLE1BQU0sR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLLFVBQVUsSUFBSSxJQUFJO0FBQUEsTUFDMUcsRUFBRSxJQUFJLG9CQUFvQixDQUFDLElBQUksTUFBTSxTQUFTLEdBQUcsVUFBVSxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sS0FBSyxVQUFVLENBQUMsSUFBSSxLQUFLO0FBQUEsTUFDNUcsRUFBRSxJQUFJLGNBQWMsQ0FBQyxJQUFJLE1BQU0sWUFBWSxHQUFHLFdBQVcsSUFBSSxNQUFNLElBQUksT0FBTyxPQUFPLEdBQUcsTUFBTSxLQUFLLFVBQVUsSUFBSSxLQUFLO0FBQUEsSUFDeEg7QUFBQSxFQUNGO0FBQ0EsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRztBQUM5QixjQUFVLEtBQUssRUFBRSxJQUFJLGNBQWMsQ0FBQyxJQUFJLE1BQU0sUUFBUSxHQUFHLFdBQVcsT0FBUSxJQUFJLElBQUssUUFBUSxHQUFHLFdBQVcsT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLElBQUksTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJLEtBQUssQ0FBQztBQUFBLEVBQzdLO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyw0QkFBNEM7QUFDbkQsUUFBTSxVQUFVLG9CQUFvQjtBQUNwQyxTQUFPLE1BQU0sS0FBSyxFQUFFLFFBQVEsR0FBRyxHQUFHLENBQUMsR0FBRyxVQUFVO0FBQzlDLFVBQU0sT0FBUSxRQUFRLElBQUs7QUFDM0IsVUFBTSxNQUFNLEtBQUssTUFBTSxRQUFRLENBQUM7QUFDaEMsV0FBTztBQUFBLE1BQ0wsSUFBSSx3QkFBd0IsUUFBUSxDQUFDO0FBQUEsTUFDckMsTUFBTTtBQUFBLE1BQ04sR0FBRyxXQUFXLFFBQVEsSUFBSSxPQUFPO0FBQUEsTUFDakMsR0FBRyxXQUFXLE9BQU87QUFBQSxNQUNyQixRQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyw0QkFBNkM7QUFDcEQsUUFBTSxVQUFVLG9CQUFvQjtBQUNwQyxRQUFNLFFBQTZCLENBQUMsYUFBYSxrQkFBa0IsY0FBYyxhQUFhLGtCQUFrQixZQUFZO0FBQzVILFNBQU8sTUFBTSxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsQ0FBQyxHQUFHLFVBQVU7QUFDN0MsVUFBTSxXQUFXLE1BQU0sS0FBSztBQUM1QixVQUFNLG1CQUFtQixRQUFRLElBQUk7QUFDckMsVUFBTSxJQUFJLFdBQVcsbUJBQW1CLE1BQU0sSUFBSSxPQUFPO0FBQ3pELFdBQU87QUFBQSxNQUNMLElBQUksbUJBQW1CLFFBQVEsQ0FBQztBQUFBLE1BQ2hDO0FBQUEsTUFDQSxHQUFHLFlBQVksbUJBQW1CLEtBQUs7QUFBQSxNQUN2QyxRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0EsTUFBTSxVQUFVLFFBQVEsRUFBRTtBQUFBLE1BQzFCLE9BQU8sUUFBUSxNQUFNLElBQUksSUFBSTtBQUFBLE1BQzdCLFVBQVUsUUFBUSxRQUFRLE1BQU0sSUFBSSxLQUFLLEVBQUU7QUFBQSxNQUMzQyxtQkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyx1QkFBK0I7QUFDdEMsUUFBTSxVQUFVLG9CQUFvQjtBQUNwQyxRQUFNLFFBQW9CLENBQUMsY0FBYyxnQkFBZ0IsY0FBYyxrQkFBa0IsY0FBYyxhQUFhO0FBQ3BILFFBQU0sUUFBZ0IsQ0FBQztBQUN2QixXQUFTLE9BQU8sR0FBRyxPQUFPLElBQUksUUFBUSxHQUFHO0FBQ3ZDLFVBQU0sSUFBSSxXQUFXLE9BQU8sTUFBTSxJQUFJLE9BQU87QUFDN0MsVUFBTSxJQUFJLFlBQVksT0FBTyxLQUFLO0FBQ2xDLGFBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUc7QUFDN0IsWUFBTSxLQUFLLFdBQVcsa0JBQWtCLE9BQU8sQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLFdBQVcsT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLEdBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQUEsSUFDNUo7QUFDQSxRQUFJLE9BQU8sTUFBTSxHQUFHO0FBQ2xCLFlBQU07QUFBQSxRQUNKLFdBQVcsa0JBQWtCLE9BQU8sQ0FBQyxXQUFXLFdBQVcsZUFBZSxJQUFJLElBQUksSUFBSSxFQUFFO0FBQUEsUUFDeEYsV0FBVyxrQkFBa0IsT0FBTyxDQUFDLFVBQVUsV0FBVyxrQkFBa0IsSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLFFBQzFGLFdBQVcsa0JBQWtCLE9BQU8sQ0FBQyxRQUFRLFdBQVcsY0FBYyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQUEsTUFDckY7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLE9BQXNCO0FBQy9DLE1BQUksVUFBVSx1QkFBdUIsVUFBVSxXQUFZLFFBQU8sQ0FBQztBQUNuRSxTQUFPO0FBQUEsSUFDTCxHQUFHLGFBQWEsNEJBQTRCLEtBQUssTUFBTSxDQUFDLGNBQWMsVUFBVSxDQUFDO0FBQUEsSUFDakYsR0FBRyxhQUFhLDhCQUE4QixNQUFNLEtBQUssQ0FBQyxrQkFBa0Isa0JBQWtCLGNBQWMsY0FBYyxDQUFDO0FBQUEsSUFDM0gsR0FBRyxhQUFhLDBCQUEwQixLQUFLLE1BQU0sQ0FBQyxlQUFlLGVBQWUsa0JBQWtCLGtCQUFrQixjQUFjLGNBQWMsQ0FBQztBQUFBLElBQ3JKLEdBQUcsYUFBYSw2QkFBNkIsS0FBTSxNQUFNLENBQUMsa0JBQWtCLGNBQWMsZ0JBQWdCLFlBQVksQ0FBQztBQUFBLElBQ3ZILEdBQUcsYUFBYSwwQkFBMEIsTUFBTSxNQUFNLENBQUMsZUFBZSxlQUFlLGtCQUFrQixrQkFBa0IsY0FBYyxjQUFjLENBQUM7QUFBQSxJQUN0SixHQUFHLGFBQWEsNEJBQTRCLE1BQU0sTUFBTSxDQUFDLFlBQVksY0FBYyxDQUFDO0FBQUEsSUFDcEYsR0FBRyxhQUFhLDZCQUE2QixNQUFNLE1BQU0sQ0FBQyxjQUFjLFlBQVksQ0FBQztBQUFBLEVBQ3ZGO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsUUFBZ0IsR0FBVyxHQUFXLE9BQTJCO0FBQ3JGLFNBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxVQUFVO0FBQ2hDLFVBQU0sUUFBUyxLQUFLLEtBQUssSUFBSSxRQUFTLEtBQUssSUFBSSxHQUFHLE1BQU0sTUFBTTtBQUM5RCxVQUFNLFNBQVMsVUFBVSxJQUFJLElBQUksS0FBTSxRQUFRLElBQUs7QUFDcEQsV0FBTyxXQUFXLEdBQUcsTUFBTSxJQUFJLFFBQVEsQ0FBQyxJQUFJLFdBQVcsTUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLEtBQUssSUFBSSxNQUFNO0FBQUEsRUFDckgsQ0FBQztBQUNIOyIsIm5hbWVzIjpbXX0=