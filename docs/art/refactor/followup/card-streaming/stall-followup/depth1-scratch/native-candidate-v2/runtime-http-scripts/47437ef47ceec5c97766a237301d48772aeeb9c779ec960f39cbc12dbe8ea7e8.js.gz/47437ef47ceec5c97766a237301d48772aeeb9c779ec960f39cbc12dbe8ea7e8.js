export const CREEP_UNITS = {
  murlocPeon: {
    name: { en: "Murloc Peon", zh: "鱼人苦工" },
    glyph: { silhouette: "wildling-thorns", marks: ["tail", "shortSword"] },
    art: { tier: "basic", bearing: "foot", faction: "wild" }
  },
  murlocHunter: {
    name: { en: "Murloc Hunter", zh: "鱼人猎手" },
    glyph: { silhouette: "wildling-thorns", marks: ["tail", "arrow"] },
    art: { tier: "advanced", bearing: "foot", faction: "wild" }
  },
  tidePriest: {
    name: { en: "Tide Priest", zh: "潮汐祭司" },
    glyph: { silhouette: "wildling-thorns", marks: ["tail", "halo"] },
    art: { tier: "elite", bearing: "foot", faction: "wild" }
  },
  deepSnapper: {
    name: { en: "Deep Snapper", zh: "深渊巨鳌" },
    glyph: { silhouette: "wildling-thorns", marks: ["tail", "towerShield"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  },
  rubbleGolem: {
    name: { en: "Rubble Golem", zh: "碎石魔像" },
    glyph: { silhouette: "golem-block", marks: ["blockSeams", "scar"] },
    art: { tier: "elite", bearing: "construct", faction: "wild" }
  },
  rockGolem: {
    name: { en: "Rock Golem", zh: "岩石魔像" },
    glyph: { silhouette: "golem-block", marks: ["blockSeams", "rune"] },
    art: { tier: "elite", bearing: "construct", faction: "wild" }
  },
  graniteGolem: {
    name: { en: "Granite Golem", zh: "花岗岩魔像" },
    glyph: { silhouette: "golem-block", marks: ["blockSeams", "spark", "rune"] },
    art: { tier: "elite", bearing: "construct", faction: "wild" }
  },
  ogreWarrior: {
    name: { en: "Ogre Warrior", zh: "食人魔战士" },
    glyph: { silhouette: "wildling-thorns", marks: ["visor", "shortSword"] },
    art: { tier: "elite", bearing: "foot", faction: "wild" }
  },
  ogreMage: {
    name: { en: "Ogre Mage", zh: "食人魔法师" },
    glyph: { silhouette: "wildling-thorns", marks: ["visor", "crescent"] },
    art: { tier: "elite", bearing: "foot", faction: "wild" }
  },
  ogreLord: {
    name: { en: "Ogre Lord", zh: "食人魔领主" },
    glyph: { silhouette: "wildling-thorns", marks: ["visor", "flag"] },
    art: { tier: "elite", bearing: "foot", faction: "wild" }
  },
  spiderling: {
    name: { en: "Spiderling", zh: "小蜘蛛" },
    glyph: { silhouette: "wildling-thorns", marks: ["spark", "scar"] },
    art: { tier: "basic", bearing: "beast", faction: "wild" }
  },
  venomSpider: {
    name: { en: "Venom Spider", zh: "毒蛛" },
    glyph: { silhouette: "wildling-thorns", marks: ["spark", "curseSlash"] },
    art: { tier: "advanced", bearing: "beast", faction: "wild" }
  },
  spiderQueen: {
    name: { en: "Spider Queen", zh: "蛛后" },
    glyph: { silhouette: "wildling-thorns", marks: ["spark", "outerRing"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  },
  dragonWhelp: {
    name: { en: "Dragon Whelp", zh: "幼龙" },
    glyph: { silhouette: "wildling-thorns", marks: ["innerSigil", "spark"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  },
  redDragon: {
    name: { en: "Red Dragon", zh: "红龙" },
    glyph: { silhouette: "wildling-thorns", marks: ["innerSigil", "flag", "spark"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaXRzLWNyZWVwcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENyZWVwRmFtaWx5VW5pdEtpbmQgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IFVuaXRDYXJkIH0gZnJvbSBcIi4vY2FyZHNcIjtcblxuZXhwb3J0IGNvbnN0IENSRUVQX1VOSVRTOiBSZWNvcmQ8Q3JlZXBGYW1pbHlVbml0S2luZCwgVW5pdENhcmQ+ID0ge1xuICBtdXJsb2NQZW9uOiB7XG4gICAgbmFtZTogeyBlbjogXCJNdXJsb2MgUGVvblwiLCB6aDogXCLpsbzkurroi6blt6VcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwid2lsZGxpbmctdGhvcm5zXCIsIG1hcmtzOiBbXCJ0YWlsXCIsIFwic2hvcnRTd29yZFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImJhc2ljXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBtdXJsb2NIdW50ZXI6IHtcbiAgICBuYW1lOiB7IGVuOiBcIk11cmxvYyBIdW50ZXJcIiwgemg6IFwi6bG85Lq654yO5omLXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcIndpbGRsaW5nLXRob3Juc1wiLCBtYXJrczogW1widGFpbFwiLCBcImFycm93XCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIHRpZGVQcmllc3Q6IHtcbiAgICBuYW1lOiB7IGVuOiBcIlRpZGUgUHJpZXN0XCIsIHpoOiBcIua9ruaxkOelreWPuFwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRhaWxcIiwgXCJoYWxvXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiZWxpdGVcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIGRlZXBTbmFwcGVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJEZWVwIFNuYXBwZXJcIiwgemg6IFwi5rex5riK5beo6bOMXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcIndpbGRsaW5nLXRob3Juc1wiLCBtYXJrczogW1widGFpbFwiLCBcInRvd2VyU2hpZWxkXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiZWxpdGVcIiwgYmVhcmluZzogXCJiZWFzdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBydWJibGVHb2xlbToge1xuICAgIG5hbWU6IHsgZW46IFwiUnViYmxlIEdvbGVtXCIsIHpoOiBcIueijuefs+mtlOWDj1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJnb2xlbS1ibG9ja1wiLCBtYXJrczogW1wiYmxvY2tTZWFtc1wiLCBcInNjYXJcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImNvbnN0cnVjdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICByb2NrR29sZW06IHtcbiAgICBuYW1lOiB7IGVuOiBcIlJvY2sgR29sZW1cIiwgemg6IFwi5bKp55+z6a2U5YOPXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcImdvbGVtLWJsb2NrXCIsIG1hcmtzOiBbXCJibG9ja1NlYW1zXCIsIFwicnVuZVwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiY29uc3RydWN0XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIGdyYW5pdGVHb2xlbToge1xuICAgIG5hbWU6IHsgZW46IFwiR3Jhbml0ZSBHb2xlbVwiLCB6aDogXCLoirHlspflsqnprZTlg49cIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwiZ29sZW0tYmxvY2tcIiwgbWFya3M6IFtcImJsb2NrU2VhbXNcIiwgXCJzcGFya1wiLCBcInJ1bmVcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImNvbnN0cnVjdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBvZ3JlV2Fycmlvcjoge1xuICAgIG5hbWU6IHsgZW46IFwiT2dyZSBXYXJyaW9yXCIsIHpoOiBcIumjn+S6uumtlOaImOWjq1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInZpc29yXCIsIFwic2hvcnRTd29yZFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBvZ3JlTWFnZToge1xuICAgIG5hbWU6IHsgZW46IFwiT2dyZSBNYWdlXCIsIHpoOiBcIumjn+S6uumtlOazleW4iFwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInZpc29yXCIsIFwiY3Jlc2NlbnRcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJ3aWxkXCIgfSxcbiAgfSxcbiAgb2dyZUxvcmQ6IHtcbiAgICBuYW1lOiB7IGVuOiBcIk9ncmUgTG9yZFwiLCB6aDogXCLpo5/kurrprZTpoobkuLtcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwid2lsZGxpbmctdGhvcm5zXCIsIG1hcmtzOiBbXCJ2aXNvclwiLCBcImZsYWdcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJ3aWxkXCIgfSxcbiAgfSxcbiAgc3BpZGVybGluZzoge1xuICAgIG5hbWU6IHsgZW46IFwiU3BpZGVybGluZ1wiLCB6aDogXCLlsI/onJjom5tcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwid2lsZGxpbmctdGhvcm5zXCIsIG1hcmtzOiBbXCJzcGFya1wiLCBcInNjYXJcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJiYXNpY1wiLCBiZWFyaW5nOiBcImJlYXN0XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIHZlbm9tU3BpZGVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJWZW5vbSBTcGlkZXJcIiwgemg6IFwi5q+S6JubXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcIndpbGRsaW5nLXRob3Juc1wiLCBtYXJrczogW1wic3BhcmtcIiwgXCJjdXJzZVNsYXNoXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJiZWFzdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBzcGlkZXJRdWVlbjoge1xuICAgIG5hbWU6IHsgZW46IFwiU3BpZGVyIFF1ZWVuXCIsIHpoOiBcIuibm+WQjlwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInNwYXJrXCIsIFwib3V0ZXJSaW5nXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiZWxpdGVcIiwgYmVhcmluZzogXCJiZWFzdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBkcmFnb25XaGVscDoge1xuICAgIG5hbWU6IHsgZW46IFwiRHJhZ29uIFdoZWxwXCIsIHpoOiBcIuW5vOm+mVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcImlubmVyU2lnaWxcIiwgXCJzcGFya1wiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiYmVhc3RcIiwgZmFjdGlvbjogXCJ3aWxkXCIgfSxcbiAgfSxcbiAgcmVkRHJhZ29uOiB7XG4gICAgbmFtZTogeyBlbjogXCJSZWQgRHJhZ29uXCIsIHpoOiBcIue6oum+mVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcImlubmVyU2lnaWxcIiwgXCJmbGFnXCIsIFwic3BhcmtcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImJlYXN0XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG59O1xuIl0sIm1hcHBpbmdzIjoiQUFHTyxhQUFNLGNBQXFEO0FBQUEsRUFDaEUsWUFBWTtBQUFBLElBQ1YsTUFBTSxFQUFFLElBQUksZUFBZSxJQUFJLE9BQU87QUFBQSxJQUN0QyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdEUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxPQUFPO0FBQUEsRUFDekQ7QUFBQSxFQUNBLGNBQWM7QUFBQSxJQUNaLE1BQU0sRUFBRSxJQUFJLGlCQUFpQixJQUFJLE9BQU87QUFBQSxJQUN4QyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLFFBQVEsT0FBTyxFQUFFO0FBQUEsSUFDakUsS0FBSyxFQUFFLE1BQU0sWUFBWSxTQUFTLFFBQVEsU0FBUyxPQUFPO0FBQUEsRUFDNUQ7QUFBQSxFQUNBLFlBQVk7QUFBQSxJQUNWLE1BQU0sRUFBRSxJQUFJLGVBQWUsSUFBSSxPQUFPO0FBQUEsSUFDdEMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxRQUFRLE1BQU0sRUFBRTtBQUFBLElBQ2hFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxRQUFRLFNBQVMsT0FBTztBQUFBLEVBQ3pEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxPQUFPO0FBQUEsSUFDdkMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxRQUFRLGFBQWEsRUFBRTtBQUFBLElBQ3ZFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxPQUFPO0FBQUEsSUFDdkMsT0FBTyxFQUFFLFlBQVksZUFBZSxPQUFPLENBQUMsY0FBYyxNQUFNLEVBQUU7QUFBQSxJQUNsRSxLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsYUFBYSxTQUFTLE9BQU87QUFBQSxFQUM5RDtBQUFBLEVBQ0EsV0FBVztBQUFBLElBQ1QsTUFBTSxFQUFFLElBQUksY0FBYyxJQUFJLE9BQU87QUFBQSxJQUNyQyxPQUFPLEVBQUUsWUFBWSxlQUFlLE9BQU8sQ0FBQyxjQUFjLE1BQU0sRUFBRTtBQUFBLElBQ2xFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhLFNBQVMsT0FBTztBQUFBLEVBQzlEO0FBQUEsRUFDQSxjQUFjO0FBQUEsSUFDWixNQUFNLEVBQUUsSUFBSSxpQkFBaUIsSUFBSSxRQUFRO0FBQUEsSUFDekMsT0FBTyxFQUFFLFlBQVksZUFBZSxPQUFPLENBQUMsY0FBYyxTQUFTLE1BQU0sRUFBRTtBQUFBLElBQzNFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhLFNBQVMsT0FBTztBQUFBLEVBQzlEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxRQUFRO0FBQUEsSUFDeEMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxTQUFTLFlBQVksRUFBRTtBQUFBLElBQ3ZFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxRQUFRLFNBQVMsT0FBTztBQUFBLEVBQ3pEO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixNQUFNLEVBQUUsSUFBSSxhQUFhLElBQUksUUFBUTtBQUFBLElBQ3JDLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsU0FBUyxVQUFVLEVBQUU7QUFBQSxJQUNyRSxLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsUUFBUSxTQUFTLE9BQU87QUFBQSxFQUN6RDtBQUFBLEVBQ0EsVUFBVTtBQUFBLElBQ1IsTUFBTSxFQUFFLElBQUksYUFBYSxJQUFJLFFBQVE7QUFBQSxJQUNyQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLFNBQVMsTUFBTSxFQUFFO0FBQUEsSUFDakUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxPQUFPO0FBQUEsRUFDekQ7QUFBQSxFQUNBLFlBQVk7QUFBQSxJQUNWLE1BQU0sRUFBRSxJQUFJLGNBQWMsSUFBSSxNQUFNO0FBQUEsSUFDcEMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxTQUFTLE1BQU0sRUFBRTtBQUFBLElBQ2pFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxLQUFLO0FBQUEsSUFDckMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxTQUFTLFlBQVksRUFBRTtBQUFBLElBQ3ZFLEtBQUssRUFBRSxNQUFNLFlBQVksU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzdEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxLQUFLO0FBQUEsSUFDckMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxTQUFTLFdBQVcsRUFBRTtBQUFBLElBQ3RFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxLQUFLO0FBQUEsSUFDckMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxjQUFjLE9BQU8sRUFBRTtBQUFBLElBQ3ZFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQUEsRUFDQSxXQUFXO0FBQUEsSUFDVCxNQUFNLEVBQUUsSUFBSSxjQUFjLElBQUksS0FBSztBQUFBLElBQ25DLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsY0FBYyxRQUFRLE9BQU8sRUFBRTtBQUFBLElBQy9FLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQ0Y7IiwibmFtZXMiOltdfQ==