import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/tmp/sketch-queue-source-42bd/src/client/world-presentation.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/tmp/sketch-queue-source-42bd/src/client/world-presentation.css"
const __vite__css = ".world-underlay{position:absolute;inset:0;z-index:0;pointer-events:none;isolation:isolate}.world-underlay[hidden]{display:none}.world-underlay canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}.world-ground{z-index:0}.world-actors{z-index:1}.game-canvas{position:relative;z-index:0}.menu-open .world-underlay{filter:var(--scene-filter)}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))