import { seconds } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
import { arrowFrame, hasEffectVector } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/effect-presentation.ts";
export function drawChainLightningEffect(ctx, effect, from, to) {
  const life = effect.remaining / effect.duration;
  const progress = 1 - life;
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.max(1, Math.hypot(dx, dy));
  const nx = -dy / length;
  const ny = dx / length;
  const points = [];
  for (let i = 0; i <= 7; i += 1) {
    const t = i / 7;
    const wave = i === 0 || i === 7 ? 0 : Math.sin(i * 2.31 + effect.remaining * 0.58) * (10 + Math.sin(progress * Math.PI) * 7);
    points.push({ x: from.x + dx * t + nx * wave, y: from.y + dy * t + ny * wave });
  }
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.shadowColor = `rgba(108, 192, 232, ${0.48 + life * 0.34})`;
  ctx.shadowBlur = 13;
  ctx.strokeStyle = `rgba(80, 166, 218, ${0.48 + life * 0.38})`;
  ctx.lineWidth = 8;
  strokePolyline(ctx, points);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = `rgba(252, 247, 174, ${0.72 + life * 0.2})`;
  ctx.lineWidth = 3;
  strokePolyline(ctx, points);
  ctx.strokeStyle = `rgba(255, 255, 255, ${0.58 + life * 0.22})`;
  ctx.lineWidth = 1.2;
  strokePolyline(ctx, points);
  for (let i = 2; i < points.length - 1; i += 2) {
    const p = points[i];
    ctx.strokeStyle = `rgba(128, 213, 242, ${0.28 + life * 0.26})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + nx * 20 - dx / length * 9, p.y + ny * 20 - dy / length * 9);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawHealEffect(renderer, effect, point, life) {
  const { ctx, worldToScreen } = renderer;
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (hasEffectVector(effect)) {
    const from = worldToScreen({ x: effect.fromX, y: effect.fromY });
    const gradient = ctx.createLinearGradient(from.x, from.y, point.x, point.y);
    gradient.addColorStop(0, `rgba(149, 205, 114, ${0.08 + life * 0.14})`);
    gradient.addColorStop(0.62, `rgba(112, 188, 96, ${0.3 + life * 0.28})`);
    gradient.addColorStop(1, `rgba(234, 255, 205, ${0.58 + life * 0.28})`);
    ctx.shadowColor = "rgba(114, 190, 98, 0.42)";
    ctx.shadowBlur = 9;
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
  }
  const pulse = 1 - life;
  const ring = 14 + pulse * 20;
  ctx.shadowColor = "rgba(116, 188, 93, 0.48)";
  ctx.shadowBlur = 12;
  ctx.strokeStyle = `rgba(95, 157, 76, ${0.3 + life * 0.42})`;
  ctx.fillStyle = `rgba(155, 216, 123, ${0.08 + life * 0.08})`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(point.x, point.y, ring, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = `rgba(244, 255, 222, ${0.72 + life * 0.18})`;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(point.x - 12, point.y);
  ctx.lineTo(point.x + 12, point.y);
  ctx.moveTo(point.x, point.y - 12);
  ctx.lineTo(point.x, point.y + 12);
  ctx.stroke();
  ctx.restore();
}
export function drawSummonEffect(ctx, point, life) {
  const open = 1 - life;
  ctx.save();
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(96, 111, 190, 0.5)";
  ctx.shadowBlur = 12;
  ctx.fillStyle = `rgba(72, 88, 154, ${0.08 + life * 0.12})`;
  ctx.strokeStyle = `rgba(94, 92, 170, ${0.42 + life * 0.36})`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 14, 18 + open * 22, 8 + open * 7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = `rgba(226, 220, 255, ${0.48 + life * 0.3})`;
  ctx.lineWidth = 2;
  for (let i = 0; i < 6; i += 1) {
    const angle = i * (Math.PI / 3) + open * 2.2;
    const inner = 9 + open * 10;
    const outer = 24 + open * 18;
    ctx.beginPath();
    ctx.moveTo(point.x + Math.cos(angle) * inner, point.y + Math.sin(angle) * inner + 8);
    ctx.lineTo(point.x + Math.cos(angle) * outer, point.y + Math.sin(angle) * outer + 8);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawCurseEffect(ctx, point, life) {
  const spread = 1 - life;
  ctx.save();
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(122, 55, 112, 0.45)";
  ctx.shadowBlur = 10;
  ctx.strokeStyle = `rgba(116, 49, 106, ${0.45 + life * 0.38})`;
  ctx.fillStyle = `rgba(84, 37, 86, ${0.08 + life * 0.1})`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 9, 15 + spread * 24, 7 + spread * 8, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = `rgba(232, 187, 226, ${0.5 + life * 0.26})`;
  ctx.lineWidth = 2.2;
  for (let i = 0; i < 4; i += 1) {
    const offset = (i - 1.5) * 9;
    ctx.beginPath();
    ctx.moveTo(point.x + offset, point.y - 24 - spread * 8);
    ctx.quadraticCurveTo(point.x + offset + 6, point.y - 9, point.x + offset - 2, point.y + 6);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawStormEffect(ctx, effect, point, life) {
  const radius = effect.radius ?? 145;
  const churn = 1 - life;
  ctx.save();
  const gradient = ctx.createRadialGradient(point.x, point.y, 8, point.x, point.y, radius);
  gradient.addColorStop(0, `rgba(207, 236, 245, ${0.16 + life * 0.1})`);
  gradient.addColorStop(0.55, `rgba(84, 154, 194, ${0.13 + life * 0.13})`);
  gradient.addColorStop(1, "rgba(49, 95, 135, 0)");
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.shadowColor = "rgba(83, 157, 205, 0.35)";
  ctx.shadowBlur = 10;
  for (let ring = 0; ring < 3; ring += 1) {
    ctx.strokeStyle = `rgba(64, 130, 178, ${0.2 + life * 0.18 - ring * 0.04})`;
    ctx.lineWidth = 2.2 - ring * 0.3;
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius * (0.36 + ring * 0.24) + Math.sin(effect.remaining * 0.16 + ring) * 5, churn * Math.PI + ring, churn * Math.PI + ring + Math.PI * 1.35);
    ctx.stroke();
  }
  ctx.strokeStyle = `rgba(219, 244, 252, ${0.46 + life * 0.24})`;
  ctx.lineWidth = 2.4;
  for (let i = 0; i < 9; i += 1) {
    const angle = i * 1.73 + effect.remaining * 0.12;
    const lane = radius * (0.18 + i * 37 % 64 / 100);
    const x = point.x + Math.cos(angle) * lane;
    const y = point.y + Math.sin(angle) * lane;
    ctx.beginPath();
    ctx.moveTo(x - 4, y - 14);
    ctx.lineTo(x + 5, y + 12);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawGuardianFieldEffect(ctx, effect, point, life) {
  const radius = effect.radius ?? 280;
  const pulse = 1 - life;
  ctx.save();
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(216, 175, 74, 0.36)";
  ctx.shadowBlur = 12;
  ctx.fillStyle = `rgba(208, 182, 82, ${0.035 + life * 0.035})`;
  ctx.strokeStyle = `rgba(166, 137, 53, ${0.28 + life * 0.22})`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 12, radius, radius * 0.42, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = `rgba(245, 231, 157, ${0.42 + life * 0.28})`;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 12, radius * (0.72 + pulse * 0.12), radius * (0.3 + pulse * 0.05), 0, 0, Math.PI * 2);
  ctx.stroke();
  for (let i = 0; i < 6; i += 1) {
    const angle = i * (Math.PI / 3) + pulse * 0.8;
    const x = point.x + Math.cos(angle) * radius * 0.5;
    const y = point.y + Math.sin(angle) * radius * 0.2 + 12;
    ctx.beginPath();
    ctx.moveTo(x, y - 9);
    ctx.lineTo(x + 8, y - 2);
    ctx.lineTo(x + 5, y + 9);
    ctx.lineTo(x - 5, y + 9);
    ctx.lineTo(x - 8, y - 2);
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();
}
export function drawExperienceBurstEffect(ctx, point, life) {
  const burst = 1 - life;
  ctx.save();
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(219, 168, 48, 0.58)";
  ctx.shadowBlur = 14;
  ctx.strokeStyle = `rgba(213, 151, 34, ${0.38 + life * 0.34})`;
  ctx.lineWidth = 3;
  for (let i = 0; i < 10; i += 1) {
    const angle = i * (Math.PI / 5);
    const inner = 8 + burst * 8;
    const outer = 22 + burst * 36;
    ctx.beginPath();
    ctx.moveTo(point.x + Math.cos(angle) * inner, point.y + Math.sin(angle) * inner);
    ctx.lineTo(point.x + Math.cos(angle) * outer, point.y + Math.sin(angle) * outer);
    ctx.stroke();
  }
  ctx.fillStyle = `rgba(255, 244, 174, ${0.72 + life * 0.18})`;
  ctx.beginPath();
  ctx.moveTo(point.x, point.y - 18);
  ctx.lineTo(point.x + 5, point.y - 5);
  ctx.lineTo(point.x + 18, point.y);
  ctx.lineTo(point.x + 5, point.y + 5);
  ctx.lineTo(point.x, point.y + 18);
  ctx.lineTo(point.x - 5, point.y + 5);
  ctx.lineTo(point.x - 18, point.y);
  ctx.lineTo(point.x - 5, point.y - 5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
const FLAME_TONGUES = [
  { dx: -9, base: 12, height: 14, width: 7 },
  { dx: -3, base: 13, height: 22, width: 8 },
  { dx: 4, base: 12, height: 19, width: 8 },
  { dx: 10, base: 11, height: 12, width: 6 },
  { dx: 0, base: 5, height: 11, width: 5 }
];
export function drawFlameBurnEffect(ctx, point, life, tick) {
  const flare = 1 - life;
  const strength = Math.min(1, life * 1.6);
  const rise = Math.min(1, flare * 4);
  ctx.save();
  ctx.fillStyle = `rgba(74, 44, 28, ${0.16 * life})`;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 13, 15, 5.5, 0, 0, Math.PI * 2);
  ctx.fill();
  const glow = ctx.createRadialGradient(point.x, point.y + 4, 0, point.x, point.y + 4, 24);
  glow.addColorStop(0, `rgba(247, 150, 62, ${0.26 * strength})`);
  glow.addColorStop(1, "rgba(247, 150, 62, 0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(point.x, point.y + 4, 24, 0, Math.PI * 2);
  ctx.fill();
  FLAME_TONGUES.forEach((tongue, index) => {
    const flicker = 0.78 + 0.22 * Math.sin(tick * 0.9 + index * 1.7);
    drawFlameTongue(ctx, point.x + tongue.dx, point.y + tongue.base, tongue.height * rise * flicker, tongue.width, Math.sin(tick * 0.6 + index) * 2, strength * 0.85);
  });
  drawEmbers(ctx, point, flare, tick, 5, strength);
  ctx.restore();
}
export function drawScorchedUnitFlames(ctx, point, radius, now, remainingTicks) {
  const strength = Math.min(1, remainingTicks / seconds(1)) * 0.6;
  const tick = now / 50;
  const spread = radius * 0.45;
  ctx.save();
  drawFlameTongue(ctx, point.x - spread, point.y + 4, 9 + Math.sin(tick * 0.8) * 2, 5, Math.sin(tick * 0.5) * 1.5, strength);
  drawFlameTongue(ctx, point.x + spread * 0.6, point.y + 1, 12 + Math.sin(tick * 0.7 + 2) * 2.5, 6, Math.sin(tick * 0.45 + 1) * 1.5, strength);
  drawEmbers(ctx, { x: point.x, y: point.y - 6 }, tick / 40 % 1, tick, 3, strength);
  ctx.restore();
}
function drawFlameTongue(ctx, x, baseY, height, width, lean, alpha) {
  if (height < 1 || alpha <= 0) return;
  const tipX = x + lean;
  const tipY = baseY - height;
  const gradient = ctx.createLinearGradient(0, baseY, 0, tipY);
  gradient.addColorStop(0, `rgba(186, 56, 38, ${alpha})`);
  gradient.addColorStop(0.45, `rgba(236, 124, 48, ${alpha})`);
  gradient.addColorStop(1, `rgba(255, 214, 110, ${alpha * 0.85})`);
  ctx.fillStyle = gradient;
  flameTonguePath(ctx, x, baseY, tipX, tipY, width, height);
  ctx.fill();
  ctx.fillStyle = `rgba(255, 242, 196, ${alpha * 0.7})`;
  flameTonguePath(ctx, x + lean * 0.2, baseY, x + lean * 0.6, baseY - height * 0.5, width * 0.42, height * 0.5);
  ctx.fill();
}
function flameTonguePath(ctx, x, baseY, tipX, tipY, width, height) {
  ctx.beginPath();
  ctx.moveTo(x - width / 2, baseY);
  ctx.bezierCurveTo(x - width * 0.7, baseY - height * 0.45, tipX - width * 0.15, tipY + height * 0.25, tipX, tipY);
  ctx.bezierCurveTo(tipX + width * 0.2, tipY + height * 0.3, x + width * 0.7, baseY - height * 0.4, x + width / 2, baseY);
  ctx.quadraticCurveTo(x, baseY + width * 0.35, x - width / 2, baseY);
  ctx.closePath();
}
function drawEmbers(ctx, point, phase, tick, count, strength) {
  for (let index = 0; index < count; index += 1) {
    const t = (phase + index * 0.19) % 1;
    const x = point.x + Math.sin(index * 2.3 + tick * 0.25) * (5 + index * 2);
    const y = point.y + 6 - t * 34;
    ctx.fillStyle = `rgba(255, ${190 - index * 12}, 90, ${(1 - t) * 0.8 * strength})`;
    ctx.beginPath();
    ctx.arc(x, y, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }
}
function strokePolyline(ctx, points) {
  ctx.beginPath();
  points.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });
  ctx.stroke();
}
export function drawPhysicalMissile(ctx, from, to, progress, look) {
  const frame = arrowFrame(from, to, progress, look === "spear" ? 1.15 : 0.55);
  ctx.save();
  ctx.translate(frame.tip.x, frame.tip.y);
  ctx.rotate(frame.angle);
  if (look === "fire") {
    const glow = ctx.createRadialGradient(-3, 0, 1, -3, 0, 15);
    glow.addColorStop(0, "#e8b466a8");
    glow.addColorStop(1, "#b8522b00");
    ctx.fillStyle = glow;
    ctx.fillRect(-20, -16, 36, 32);
    ctx.fillStyle = "#b96539";
    ctx.beginPath();
    ctx.moveTo(6, 0);
    ctx.quadraticCurveTo(-3, -8, -18, -3);
    ctx.lineTo(-13, 0);
    ctx.lineTo(-21, 4);
    ctx.quadraticCurveTo(-2, 8, 6, 0);
    ctx.fill();
    ctx.fillStyle = "#f0d092";
    ctx.beginPath();
    ctx.ellipse(0, 0, 5, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (look === "spear") {
    ctx.strokeStyle = "#9a8767";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(-24, 0);
    ctx.lineTo(-3, 0);
    ctx.stroke();
    ctx.fillStyle = "#c0c5b7";
    ctx.strokeStyle = "#373e3d";
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(3, 0);
    ctx.lineTo(-5, -2.5);
    ctx.lineTo(-4, 2.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else {
    ctx.fillStyle = look === "stone" ? "#8b8874" : "#555b59";
    ctx.strokeStyle = "#292f30";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(0, 0, look === "stone" ? 4.5 : 3.5, 3.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#d8cdb09a";
    ctx.beginPath();
    ctx.moveTo(-2, -2);
    ctx.lineTo(1, -3);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawArrow(ctx, frame) {
  const { tip, tail, angle, length } = frame;
  const ux = Math.cos(angle);
  const uy = Math.sin(angle);
  const px = -uy;
  const py = ux;
  const headLength = length * 0.3;
  const headHalf = length * 0.14;
  const neck = { x: tip.x - ux * headLength, y: tip.y - uy * headLength };
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(60, 50, 35, 0.2)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(tail.x - ux * length * 0.7, tail.y - uy * length * 0.7);
  ctx.lineTo(tail.x, tail.y);
  ctx.stroke();
  ctx.strokeStyle = "#5b4127";
  ctx.lineWidth = Math.max(1.6, length * 0.08);
  ctx.beginPath();
  ctx.moveTo(tail.x, tail.y);
  ctx.lineTo(neck.x, neck.y);
  ctx.stroke();
  ctx.fillStyle = "#34403b";
  ctx.strokeStyle = "#1f2a24";
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(tip.x, tip.y);
  ctx.lineTo(neck.x + px * headHalf, neck.y + py * headHalf);
  ctx.lineTo(neck.x + ux * headLength * 0.25, neck.y + uy * headLength * 0.25);
  ctx.lineTo(neck.x - px * headHalf, neck.y - py * headHalf);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  const vane = length * 0.24;
  const spread = length * 0.13;
  ctx.fillStyle = "#efe6cc";
  ctx.strokeStyle = "rgba(60, 50, 35, 0.7)";
  for (const side of [1, -1]) {
    ctx.beginPath();
    ctx.moveTo(tail.x + ux * vane, tail.y + uy * vane);
    ctx.lineTo(tail.x + px * spread * side + ux * vane * 0.35, tail.y + py * spread * side + uy * vane * 0.35);
    ctx.lineTo(tail.x + px * spread * side - ux * 1.5, tail.y + py * spread * side - uy * 1.5);
    ctx.lineTo(tail.x, tail.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}
export function drawSpellOrb(ctx, from, to, progress, palette) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.max(1, Math.hypot(dx, dy));
  const ux = dx / length;
  const uy = dy / length;
  const bob = Math.sin(progress * Math.PI * 3) * 1.5;
  const head = { x: from.x + dx * progress - uy * bob, y: from.y + dy * progress + ux * bob };
  const fade = Math.min(1, progress * 6, (1 - progress) * 8 + 0.35);
  ctx.save();
  for (let index = 3; index >= 1; index -= 1) {
    ctx.fillStyle = rgba(palette.glow, (0.3 - index * 0.07) * fade);
    ctx.beginPath();
    ctx.arc(head.x - ux * index * 5, head.y - uy * index * 5, 2.2 - index * 0.4, 0, Math.PI * 2);
    ctx.fill();
  }
  const glow = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, 7);
  glow.addColorStop(0, rgba(palette.glow, 0.42 * fade));
  glow.addColorStop(1, rgba(palette.glow, 0));
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(head.x, head.y, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = rgba(palette.core, 0.85 * fade);
  ctx.strokeStyle = rgba(palette.glow, 0.6 * fade);
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.arc(head.x, head.y, 2.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
export function drawProjectileTrail(ctx, from, to, head, progress, life) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.max(1, Math.hypot(dx, dy));
  const ux = dx / length;
  const uy = dy / length;
  const trailLength = Math.min(92, Math.max(24, length * 0.42));
  const tail = {
    x: head.x - ux * trailLength,
    y: head.y - uy * trailLength
  };
  const flightGlow = Math.sin(progress * Math.PI);
  const alpha = Math.max(0.22, Math.min(0.95, 0.24 + flightGlow * 0.62 + life * 0.12));
  const cool = { r: 49, g: 95, b: 135 };
  const ember = mixRgb({ r: 190, g: 62, b: 55 }, { r: 226, g: 129, b: 52 }, progress);
  const hot = mixRgb({ r: 96, g: 139, b: 166 }, { r: 242, g: 208, b: 92 }, Math.min(1, progress * 1.18));
  const gradient = ctx.createLinearGradient(tail.x, tail.y, head.x, head.y);
  gradient.addColorStop(0, rgba(cool, 0));
  gradient.addColorStop(0.34, rgba(cool, alpha * 0.28));
  gradient.addColorStop(0.72, rgba(ember, alpha * 0.68));
  gradient.addColorStop(1, rgba(hot, alpha));
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.shadowColor = rgba(ember, alpha * 0.58);
  ctx.shadowBlur = 8;
  ctx.strokeStyle = gradient;
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(tail.x, tail.y);
  ctx.lineTo(head.x, head.y);
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = rgba({ r: 255, g: 251, b: 227 }, alpha * 0.62);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(tail.x + ux * trailLength * 0.52, tail.y + uy * trailLength * 0.52);
  ctx.lineTo(head.x, head.y);
  ctx.stroke();
  ctx.fillStyle = rgba(hot, alpha);
  ctx.strokeStyle = rgba({ r: 36, g: 49, b: 38 }, alpha * 0.55);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(head.x, head.y, 4.6, 3.2, Math.atan2(dy, dx), 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
const DUST = { r: 150, g: 122, b: 84 };
const DUST_EDGE = { r: 104, g: 80, b: 50 };
const INK = { r: 36, g: 49, b: 38 };
const SPARK_HOT = { r: 255, g: 246, b: 204 };
const SPARK = { r: 242, g: 184, b: 60 };
export function drawChargeTrail(ctx, frame) {
  ctx.save();
  for (let index = frame.puffs.length - 1; index >= 0; index--) {
    const puff = frame.puffs[index];
    ctx.fillStyle = rgba(DUST, puff.alpha * 0.55);
    ctx.strokeStyle = rgba(DUST_EDGE, puff.alpha);
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(puff.x, puff.y, puff.rx, puff.ry, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
  ctx.lineCap = "round";
  for (let index = 0; index < Math.min(1, frame.streaks.length); index++) {
    const streak = frame.streaks[index];
    const gradient = ctx.createLinearGradient(streak.from.x, streak.from.y, streak.to.x, streak.to.y);
    gradient.addColorStop(0, rgba(INK, streak.alpha * 0.2));
    gradient.addColorStop(1, rgba(INK, 0));
    ctx.strokeStyle = gradient;
    ctx.lineWidth = streak.width;
    ctx.beginPath();
    ctx.moveTo(streak.from.x, streak.from.y);
    ctx.lineTo(streak.to.x, streak.to.y);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawChargeImpact(ctx, frame) {
  const { ring } = frame;
  ctx.save();
  ctx.lineCap = "round";
  ctx.fillStyle = rgba(DUST, ring.alpha * 0.18);
  ctx.strokeStyle = rgba(DUST_EDGE, ring.alpha * 0.6);
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.ellipse(ring.x, ring.y, ring.rx, ring.ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  for (const clod of frame.clods) {
    ctx.fillStyle = rgba(DUST, clod.alpha * 0.7);
    ctx.strokeStyle = rgba(DUST_EDGE, clod.alpha);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(clod.x, clod.y, clod.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
  for (let index = 0; index < Math.min(2, frame.rays.length); index++) {
    const ray = frame.rays[index];
    ctx.strokeStyle = rgba(SPARK, ray.alpha * 0.85);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ray.from.x, ray.from.y);
    ctx.lineTo(ray.to.x, ray.to.y);
    ctx.stroke();
    ctx.strokeStyle = rgba(SPARK_HOT, ray.alpha);
    ctx.lineWidth = 0.8;
    ctx.stroke();
  }
  for (let index = 0; index < Math.min(2, frame.sparks.length); index++) {
    const spark = frame.sparks[index];
    ctx.strokeStyle = rgba(SPARK, spark.alpha);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(spark.from.x, spark.from.y);
    ctx.lineTo(spark.to.x, spark.to.y);
    ctx.stroke();
    ctx.fillStyle = rgba(SPARK_HOT, spark.alpha);
    ctx.beginPath();
    ctx.arc(spark.to.x, spark.to.y, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
function mixRgb(from, to, amount) {
  const clamped = Math.max(0, Math.min(1, amount));
  return {
    r: Math.round(from.r + (to.r - from.r) * clamped),
    g: Math.round(from.g + (to.g - from.g) * clamped),
    b: Math.round(from.b + (to.b - from.b) * clamped)
  };
}
function rgba(color, alpha) {
  return `rgba(${color.r}, ${color.g}, ${color.b}, ${Math.max(0, Math.min(1, alpha))})`;
}
export function drawGoldBountyEffect(ctx, point, life, amount) {
  const elapsed = 1 - Math.max(0, Math.min(1, life));
  ctx.save();
  ctx.globalAlpha = Math.min(1, life * 3);
  ctx.lineWidth = 1.5;
  for (let index = 0; index < 5; index++) {
    const spread = (index - 2) * 12 * elapsed;
    const lift = Math.sin(elapsed * Math.PI) * (19 + index % 2 * 9);
    ctx.beginPath();
    ctx.ellipse(point.x + spread, point.y - 8 - lift, 3.5, 4.5, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#f3cf59";
    ctx.strokeStyle = "#8c651d";
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(point.x + spread, point.y - 10 - lift);
    ctx.lineTo(point.x + spread, point.y - 6 - lift);
    ctx.stroke();
  }
  ctx.font = "bold 14px sans-serif";
  ctx.textAlign = "center";
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#382f21";
  ctx.fillStyle = "#ffe18a";
  const textY = point.y - 32 - elapsed * 25;
  ctx.strokeText(`+${amount}`, point.x, textY);
  ctx.fillText(`+${amount}`, point.x, textY);
  ctx.restore();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbnZhcy1lZmZlY3RzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlY29uZHMgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3RpbWVcIjtcbmltcG9ydCB0eXBlIHsgV29ybGRFZmZlY3QgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgeyBhcnJvd0ZyYW1lLCBoYXNFZmZlY3RWZWN0b3IsIHR5cGUgQXJyb3dGcmFtZSwgdHlwZSBTcGVsbE9yYlBhbGV0dGUsIHR5cGUgQ2hhcmdlVHJhaWxGcmFtZSwgdHlwZSBDaGFyZ2VJbXBhY3RGcmFtZSB9IGZyb20gJy4vZWZmZWN0LXByZXNlbnRhdGlvbic7XG50eXBlIFBvaW50ID0geyB4OiBudW1iZXI7IHk6IG51bWJlciB9O1xudHlwZSBFZmZlY3RSZW5kZXJDb250ZXh0ID0geyBjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRDsgd29ybGRUb1NjcmVlbjogKHBvaW50OiBQb2ludCkgPT4gUG9pbnQgfTtcblxuLy8gQEBAZWZmZWN0LWxhbmd1YWdlIC0gQWN0aXZlIHBvd2VycyBuZWVkIHJlYWRhYmxlIHdvcmxkIHN5bWJvbHMsIG5vdCBnZW5lcmljIGRlYnVnIGNpcmNsZXMuXG5leHBvcnQgZnVuY3Rpb24gZHJhd0NoYWluTGlnaHRuaW5nRWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBlZmZlY3Q6IFdvcmxkRWZmZWN0LCBmcm9tOiBQb2ludCwgdG86IFBvaW50KSB7XG4gIGNvbnN0IGxpZmUgPSBlZmZlY3QucmVtYWluaW5nIC8gZWZmZWN0LmR1cmF0aW9uO1xuICBjb25zdCBwcm9ncmVzcyA9IDEgLSBsaWZlO1xuICBjb25zdCBkeCA9IHRvLnggLSBmcm9tLng7XG4gIGNvbnN0IGR5ID0gdG8ueSAtIGZyb20ueTtcbiAgY29uc3QgbGVuZ3RoID0gTWF0aC5tYXgoMSwgTWF0aC5oeXBvdChkeCwgZHkpKTtcbiAgY29uc3QgbnggPSAtZHkgLyBsZW5ndGg7XG4gIGNvbnN0IG55ID0gZHggLyBsZW5ndGg7XG4gIGNvbnN0IHBvaW50czogUG9pbnRbXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8PSA3OyBpICs9IDEpIHtcbiAgICBjb25zdCB0ID0gaSAvIDc7XG4gICAgY29uc3Qgd2F2ZSA9IGkgPT09IDAgfHwgaSA9PT0gNyA/IDAgOiBNYXRoLnNpbihpICogMi4zMSArIGVmZmVjdC5yZW1haW5pbmcgKiAwLjU4KSAqICgxMCArIE1hdGguc2luKHByb2dyZXNzICogTWF0aC5QSSkgKiA3KTtcbiAgICBwb2ludHMucHVzaCh7IHg6IGZyb20ueCArIGR4ICogdCArIG54ICogd2F2ZSwgeTogZnJvbS55ICsgZHkgKiB0ICsgbnkgKiB3YXZlIH0pO1xuICB9XG5cbiAgY3R4LnNhdmUoKTtcbiAgY3R4LmxpbmVDYXAgPSBcInJvdW5kXCI7XG4gIGN0eC5saW5lSm9pbiA9IFwicm91bmRcIjtcbiAgY3R4LnNoYWRvd0NvbG9yID0gYHJnYmEoMTA4LCAxOTIsIDIzMiwgJHswLjQ4ICsgbGlmZSAqIDAuMzR9KWA7XG4gIGN0eC5zaGFkb3dCbHVyID0gMTM7XG4gIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDgwLCAxNjYsIDIxOCwgJHswLjQ4ICsgbGlmZSAqIDAuMzh9KWA7XG4gIGN0eC5saW5lV2lkdGggPSA4O1xuICBzdHJva2VQb2x5bGluZShjdHgsIHBvaW50cyk7XG4gIGN0eC5zaGFkb3dCbHVyID0gMDtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMjUyLCAyNDcsIDE3NCwgJHswLjcyICsgbGlmZSAqIDAuMn0pYDtcbiAgY3R4LmxpbmVXaWR0aCA9IDM7XG4gIHN0cm9rZVBvbHlsaW5lKGN0eCwgcG9pbnRzKTtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMjU1LCAyNTUsIDI1NSwgJHswLjU4ICsgbGlmZSAqIDAuMjJ9KWA7XG4gIGN0eC5saW5lV2lkdGggPSAxLjI7XG4gIHN0cm9rZVBvbHlsaW5lKGN0eCwgcG9pbnRzKTtcbiAgZm9yIChsZXQgaSA9IDI7IGkgPCBwb2ludHMubGVuZ3RoIC0gMTsgaSArPSAyKSB7XG4gICAgY29uc3QgcCA9IHBvaW50c1tpXSE7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMTI4LCAyMTMsIDI0MiwgJHswLjI4ICsgbGlmZSAqIDAuMjZ9KWA7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8ocC54LCBwLnkpO1xuICAgIGN0eC5saW5lVG8ocC54ICsgbnggKiAyMCAtIGR4IC8gbGVuZ3RoICogOSwgcC55ICsgbnkgKiAyMCAtIGR5IC8gbGVuZ3RoICogOSk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkcmF3SGVhbEVmZmVjdChyZW5kZXJlcjogRWZmZWN0UmVuZGVyQ29udGV4dCwgZWZmZWN0OiBXb3JsZEVmZmVjdCwgcG9pbnQ6IFBvaW50LCBsaWZlOiBudW1iZXIpIHtcbiAgY29uc3QgeyBjdHgsIHdvcmxkVG9TY3JlZW4gfSA9IHJlbmRlcmVyO1xuICBjdHguc2F2ZSgpO1xuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgY3R4LmxpbmVKb2luID0gXCJyb3VuZFwiO1xuICBpZiAoaGFzRWZmZWN0VmVjdG9yKGVmZmVjdCkpIHtcbiAgICBjb25zdCBmcm9tID0gd29ybGRUb1NjcmVlbih7IHg6IGVmZmVjdC5mcm9tWCwgeTogZWZmZWN0LmZyb21ZIH0pO1xuICAgIGNvbnN0IGdyYWRpZW50ID0gY3R4LmNyZWF0ZUxpbmVhckdyYWRpZW50KGZyb20ueCwgZnJvbS55LCBwb2ludC54LCBwb2ludC55KTtcbiAgICBncmFkaWVudC5hZGRDb2xvclN0b3AoMCwgYHJnYmEoMTQ5LCAyMDUsIDExNCwgJHswLjA4ICsgbGlmZSAqIDAuMTR9KWApO1xuICAgIGdyYWRpZW50LmFkZENvbG9yU3RvcCgwLjYyLCBgcmdiYSgxMTIsIDE4OCwgOTYsICR7MC4zICsgbGlmZSAqIDAuMjh9KWApO1xuICAgIGdyYWRpZW50LmFkZENvbG9yU3RvcCgxLCBgcmdiYSgyMzQsIDI1NSwgMjA1LCAkezAuNTggKyBsaWZlICogMC4yOH0pYCk7XG4gICAgY3R4LnNoYWRvd0NvbG9yID0gXCJyZ2JhKDExNCwgMTkwLCA5OCwgMC40MilcIjtcbiAgICBjdHguc2hhZG93Qmx1ciA9IDk7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gZ3JhZGllbnQ7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDc7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8oZnJvbS54LCBmcm9tLnkpO1xuICAgIGN0eC5saW5lVG8ocG9pbnQueCwgcG9pbnQueSk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG5cbiAgY29uc3QgcHVsc2UgPSAxIC0gbGlmZTtcbiAgY29uc3QgcmluZyA9IDE0ICsgcHVsc2UgKiAyMDtcbiAgY3R4LnNoYWRvd0NvbG9yID0gXCJyZ2JhKDExNiwgMTg4LCA5MywgMC40OClcIjtcbiAgY3R4LnNoYWRvd0JsdXIgPSAxMjtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoOTUsIDE1NywgNzYsICR7MC4zICsgbGlmZSAqIDAuNDJ9KWA7XG4gIGN0eC5maWxsU3R5bGUgPSBgcmdiYSgxNTUsIDIxNiwgMTIzLCAkezAuMDggKyBsaWZlICogMC4wOH0pYDtcbiAgY3R4LmxpbmVXaWR0aCA9IDM7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4LmFyYyhwb2ludC54LCBwb2ludC55LCByaW5nLCAwLCBNYXRoLlBJICogMik7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5zdHJva2UoKTtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMjQ0LCAyNTUsIDIyMiwgJHswLjcyICsgbGlmZSAqIDAuMTh9KWA7XG4gIGN0eC5saW5lV2lkdGggPSA0O1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5tb3ZlVG8ocG9pbnQueCAtIDEyLCBwb2ludC55KTtcbiAgY3R4LmxpbmVUbyhwb2ludC54ICsgMTIsIHBvaW50LnkpO1xuICBjdHgubW92ZVRvKHBvaW50LngsIHBvaW50LnkgLSAxMik7XG4gIGN0eC5saW5lVG8ocG9pbnQueCwgcG9pbnQueSArIDEyKTtcbiAgY3R4LnN0cm9rZSgpO1xuICBjdHgucmVzdG9yZSgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1N1bW1vbkVmZmVjdChjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgcG9pbnQ6IFBvaW50LCBsaWZlOiBudW1iZXIpIHtcbiAgY29uc3Qgb3BlbiA9IDEgLSBsaWZlO1xuICBjdHguc2F2ZSgpO1xuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgY3R4LnNoYWRvd0NvbG9yID0gXCJyZ2JhKDk2LCAxMTEsIDE5MCwgMC41KVwiO1xuICBjdHguc2hhZG93Qmx1ciA9IDEyO1xuICBjdHguZmlsbFN0eWxlID0gYHJnYmEoNzIsIDg4LCAxNTQsICR7MC4wOCArIGxpZmUgKiAwLjEyfSlgO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBgcmdiYSg5NCwgOTIsIDE3MCwgJHswLjQyICsgbGlmZSAqIDAuMzZ9KWA7XG4gIGN0eC5saW5lV2lkdGggPSAzO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5lbGxpcHNlKHBvaW50LngsIHBvaW50LnkgKyAxNCwgMTggKyBvcGVuICogMjIsIDggKyBvcGVuICogNywgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICBjdHguZmlsbCgpO1xuICBjdHguc3Ryb2tlKCk7XG4gIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDIyNiwgMjIwLCAyNTUsICR7MC40OCArIGxpZmUgKiAwLjN9KWA7XG4gIGN0eC5saW5lV2lkdGggPSAyO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDY7IGkgKz0gMSkge1xuICAgIGNvbnN0IGFuZ2xlID0gaSAqIChNYXRoLlBJIC8gMykgKyBvcGVuICogMi4yO1xuICAgIGNvbnN0IGlubmVyID0gOSArIG9wZW4gKiAxMDtcbiAgICBjb25zdCBvdXRlciA9IDI0ICsgb3BlbiAqIDE4O1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHBvaW50LnggKyBNYXRoLmNvcyhhbmdsZSkgKiBpbm5lciwgcG9pbnQueSArIE1hdGguc2luKGFuZ2xlKSAqIGlubmVyICsgOCk7XG4gICAgY3R4LmxpbmVUbyhwb2ludC54ICsgTWF0aC5jb3MoYW5nbGUpICogb3V0ZXIsIHBvaW50LnkgKyBNYXRoLnNpbihhbmdsZSkgKiBvdXRlciArIDgpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd0N1cnNlRWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBwb2ludDogUG9pbnQsIGxpZmU6IG51bWJlcikge1xuICBjb25zdCBzcHJlYWQgPSAxIC0gbGlmZTtcbiAgY3R4LnNhdmUoKTtcbiAgY3R4LmxpbmVDYXAgPSBcInJvdW5kXCI7XG4gIGN0eC5zaGFkb3dDb2xvciA9IFwicmdiYSgxMjIsIDU1LCAxMTIsIDAuNDUpXCI7XG4gIGN0eC5zaGFkb3dCbHVyID0gMTA7XG4gIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDExNiwgNDksIDEwNiwgJHswLjQ1ICsgbGlmZSAqIDAuMzh9KWA7XG4gIGN0eC5maWxsU3R5bGUgPSBgcmdiYSg4NCwgMzcsIDg2LCAkezAuMDggKyBsaWZlICogMC4xfSlgO1xuICBjdHgubGluZVdpZHRoID0gMztcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHguZWxsaXBzZShwb2ludC54LCBwb2ludC55ICsgOSwgMTUgKyBzcHJlYWQgKiAyNCwgNyArIHNwcmVhZCAqIDgsIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnN0cm9rZSgpO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBgcmdiYSgyMzIsIDE4NywgMjI2LCAkezAuNSArIGxpZmUgKiAwLjI2fSlgO1xuICBjdHgubGluZVdpZHRoID0gMi4yO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDQ7IGkgKz0gMSkge1xuICAgIGNvbnN0IG9mZnNldCA9IChpIC0gMS41KSAqIDk7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8ocG9pbnQueCArIG9mZnNldCwgcG9pbnQueSAtIDI0IC0gc3ByZWFkICogOCk7XG4gICAgY3R4LnF1YWRyYXRpY0N1cnZlVG8ocG9pbnQueCArIG9mZnNldCArIDYsIHBvaW50LnkgLSA5LCBwb2ludC54ICsgb2Zmc2V0IC0gMiwgcG9pbnQueSArIDYpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1N0b3JtRWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBlZmZlY3Q6IFdvcmxkRWZmZWN0LCBwb2ludDogUG9pbnQsIGxpZmU6IG51bWJlcikge1xuICBjb25zdCByYWRpdXMgPSBlZmZlY3QucmFkaXVzID8/IDE0NTtcbiAgY29uc3QgY2h1cm4gPSAxIC0gbGlmZTtcbiAgY3R4LnNhdmUoKTtcbiAgY29uc3QgZ3JhZGllbnQgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQocG9pbnQueCwgcG9pbnQueSwgOCwgcG9pbnQueCwgcG9pbnQueSwgcmFkaXVzKTtcbiAgZ3JhZGllbnQuYWRkQ29sb3JTdG9wKDAsIGByZ2JhKDIwNywgMjM2LCAyNDUsICR7MC4xNiArIGxpZmUgKiAwLjF9KWApO1xuICBncmFkaWVudC5hZGRDb2xvclN0b3AoMC41NSwgYHJnYmEoODQsIDE1NCwgMTk0LCAkezAuMTMgKyBsaWZlICogMC4xM30pYCk7XG4gIGdyYWRpZW50LmFkZENvbG9yU3RvcCgxLCBcInJnYmEoNDksIDk1LCAxMzUsIDApXCIpO1xuICBjdHguZmlsbFN0eWxlID0gZ3JhZGllbnQ7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4LmFyYyhwb2ludC54LCBwb2ludC55LCByYWRpdXMsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcblxuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgY3R4LmxpbmVKb2luID0gXCJyb3VuZFwiO1xuICBjdHguc2hhZG93Q29sb3IgPSBcInJnYmEoODMsIDE1NywgMjA1LCAwLjM1KVwiO1xuICBjdHguc2hhZG93Qmx1ciA9IDEwO1xuICBmb3IgKGxldCByaW5nID0gMDsgcmluZyA8IDM7IHJpbmcgKz0gMSkge1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDY0LCAxMzAsIDE3OCwgJHswLjIgKyBsaWZlICogMC4xOCAtIHJpbmcgKiAwLjA0fSlgO1xuICAgIGN0eC5saW5lV2lkdGggPSAyLjIgLSByaW5nICogMC4zO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHguYXJjKHBvaW50LngsIHBvaW50LnksIHJhZGl1cyAqICgwLjM2ICsgcmluZyAqIDAuMjQpICsgTWF0aC5zaW4oZWZmZWN0LnJlbWFpbmluZyAqIDAuMTYgKyByaW5nKSAqIDUsIGNodXJuICogTWF0aC5QSSArIHJpbmcsIGNodXJuICogTWF0aC5QSSArIHJpbmcgKyBNYXRoLlBJICogMS4zNSk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDIxOSwgMjQ0LCAyNTIsICR7MC40NiArIGxpZmUgKiAwLjI0fSlgO1xuICBjdHgubGluZVdpZHRoID0gMi40O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDk7IGkgKz0gMSkge1xuICAgIGNvbnN0IGFuZ2xlID0gaSAqIDEuNzMgKyBlZmZlY3QucmVtYWluaW5nICogMC4xMjtcbiAgICBjb25zdCBsYW5lID0gcmFkaXVzICogKDAuMTggKyAoKGkgKiAzNykgJSA2NCkgLyAxMDApO1xuICAgIGNvbnN0IHggPSBwb2ludC54ICsgTWF0aC5jb3MoYW5nbGUpICogbGFuZTtcbiAgICBjb25zdCB5ID0gcG9pbnQueSArIE1hdGguc2luKGFuZ2xlKSAqIGxhbmU7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8oeCAtIDQsIHkgLSAxNCk7XG4gICAgY3R4LmxpbmVUbyh4ICsgNSwgeSArIDEyKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gIH1cbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdHdWFyZGlhbkZpZWxkRWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBlZmZlY3Q6IFdvcmxkRWZmZWN0LCBwb2ludDogUG9pbnQsIGxpZmU6IG51bWJlcikge1xuICBjb25zdCByYWRpdXMgPSBlZmZlY3QucmFkaXVzID8/IDI4MDtcbiAgY29uc3QgcHVsc2UgPSAxIC0gbGlmZTtcbiAgY3R4LnNhdmUoKTtcbiAgY3R4LmxpbmVDYXAgPSBcInJvdW5kXCI7XG4gIGN0eC5zaGFkb3dDb2xvciA9IFwicmdiYSgyMTYsIDE3NSwgNzQsIDAuMzYpXCI7XG4gIGN0eC5zaGFkb3dCbHVyID0gMTI7XG4gIGN0eC5maWxsU3R5bGUgPSBgcmdiYSgyMDgsIDE4MiwgODIsICR7MC4wMzUgKyBsaWZlICogMC4wMzV9KWA7XG4gIGN0eC5zdHJva2VTdHlsZSA9IGByZ2JhKDE2NiwgMTM3LCA1MywgJHswLjI4ICsgbGlmZSAqIDAuMjJ9KWA7XG4gIGN0eC5saW5lV2lkdGggPSAzO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5lbGxpcHNlKHBvaW50LngsIHBvaW50LnkgKyAxMiwgcmFkaXVzLCByYWRpdXMgKiAwLjQyLCAwLCAwLCBNYXRoLlBJICogMik7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5zdHJva2UoKTtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMjQ1LCAyMzEsIDE1NywgJHswLjQyICsgbGlmZSAqIDAuMjh9KWA7XG4gIGN0eC5saW5lV2lkdGggPSAyO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5lbGxpcHNlKHBvaW50LngsIHBvaW50LnkgKyAxMiwgcmFkaXVzICogKDAuNzIgKyBwdWxzZSAqIDAuMTIpLCByYWRpdXMgKiAoMC4zICsgcHVsc2UgKiAwLjA1KSwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICBjdHguc3Ryb2tlKCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgNjsgaSArPSAxKSB7XG4gICAgY29uc3QgYW5nbGUgPSBpICogKE1hdGguUEkgLyAzKSArIHB1bHNlICogMC44O1xuICAgIGNvbnN0IHggPSBwb2ludC54ICsgTWF0aC5jb3MoYW5nbGUpICogcmFkaXVzICogMC41O1xuICAgIGNvbnN0IHkgPSBwb2ludC55ICsgTWF0aC5zaW4oYW5nbGUpICogcmFkaXVzICogMC4yICsgMTI7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8oeCwgeSAtIDkpO1xuICAgIGN0eC5saW5lVG8oeCArIDgsIHkgLSAyKTtcbiAgICBjdHgubGluZVRvKHggKyA1LCB5ICsgOSk7XG4gICAgY3R4LmxpbmVUbyh4IC0gNSwgeSArIDkpO1xuICAgIGN0eC5saW5lVG8oeCAtIDgsIHkgLSAyKTtcbiAgICBjdHguY2xvc2VQYXRoKCk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkcmF3RXhwZXJpZW5jZUJ1cnN0RWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBwb2ludDogUG9pbnQsIGxpZmU6IG51bWJlcikge1xuICBjb25zdCBidXJzdCA9IDEgLSBsaWZlO1xuICBjdHguc2F2ZSgpO1xuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgY3R4LnNoYWRvd0NvbG9yID0gXCJyZ2JhKDIxOSwgMTY4LCA0OCwgMC41OClcIjtcbiAgY3R4LnNoYWRvd0JsdXIgPSAxNDtcbiAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMjEzLCAxNTEsIDM0LCAkezAuMzggKyBsaWZlICogMC4zNH0pYDtcbiAgY3R4LmxpbmVXaWR0aCA9IDM7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkgKz0gMSkge1xuICAgIGNvbnN0IGFuZ2xlID0gaSAqIChNYXRoLlBJIC8gNSk7XG4gICAgY29uc3QgaW5uZXIgPSA4ICsgYnVyc3QgKiA4O1xuICAgIGNvbnN0IG91dGVyID0gMjIgKyBidXJzdCAqIDM2O1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHBvaW50LnggKyBNYXRoLmNvcyhhbmdsZSkgKiBpbm5lciwgcG9pbnQueSArIE1hdGguc2luKGFuZ2xlKSAqIGlubmVyKTtcbiAgICBjdHgubGluZVRvKHBvaW50LnggKyBNYXRoLmNvcyhhbmdsZSkgKiBvdXRlciwgcG9pbnQueSArIE1hdGguc2luKGFuZ2xlKSAqIG91dGVyKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gIH1cbiAgY3R4LmZpbGxTdHlsZSA9IGByZ2JhKDI1NSwgMjQ0LCAxNzQsICR7MC43MiArIGxpZmUgKiAwLjE4fSlgO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5tb3ZlVG8ocG9pbnQueCwgcG9pbnQueSAtIDE4KTtcbiAgY3R4LmxpbmVUbyhwb2ludC54ICsgNSwgcG9pbnQueSAtIDUpO1xuICBjdHgubGluZVRvKHBvaW50LnggKyAxOCwgcG9pbnQueSk7XG4gIGN0eC5saW5lVG8ocG9pbnQueCArIDUsIHBvaW50LnkgKyA1KTtcbiAgY3R4LmxpbmVUbyhwb2ludC54LCBwb2ludC55ICsgMTgpO1xuICBjdHgubGluZVRvKHBvaW50LnggLSA1LCBwb2ludC55ICsgNSk7XG4gIGN0eC5saW5lVG8ocG9pbnQueCAtIDE4LCBwb2ludC55KTtcbiAgY3R4LmxpbmVUbyhwb2ludC54IC0gNSwgcG9pbnQueSAtIDUpO1xuICBjdHguY2xvc2VQYXRoKCk7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbi8vIEBAQGZsYW1lLWJ1cm4gLSBBIGJ1cm4gaXMgZmlyZSBvbiB0aGUgYm9keSwgbm90IGEgYmxhc3QgcmluZzogZmxhbWUgdG9uZ3VlcyBsaWNrIHVwIGZyb20gdGhlIHRhcmdldCdzIGZlZXQsIGVtYmVyc1xuLy8gZHJpZnQgb2ZmLCBhbmQgYSBmYWludCBzY29yY2ggbWFyayBzdGF5cyBvbiB0aGUgZ3JvdW5kIHdoaWxlIGl0IGZhZGVzLlxuY29uc3QgRkxBTUVfVE9OR1VFUzogcmVhZG9ubHkgeyBkeDogbnVtYmVyOyBiYXNlOiBudW1iZXI7IGhlaWdodDogbnVtYmVyOyB3aWR0aDogbnVtYmVyIH1bXSA9IFtcbiAgeyBkeDogLTksIGJhc2U6IDEyLCBoZWlnaHQ6IDE0LCB3aWR0aDogNyB9LFxuICB7IGR4OiAtMywgYmFzZTogMTMsIGhlaWdodDogMjIsIHdpZHRoOiA4IH0sXG4gIHsgZHg6IDQsIGJhc2U6IDEyLCBoZWlnaHQ6IDE5LCB3aWR0aDogOCB9LFxuICB7IGR4OiAxMCwgYmFzZTogMTEsIGhlaWdodDogMTIsIHdpZHRoOiA2IH0sXG4gIHsgZHg6IDAsIGJhc2U6IDUsIGhlaWdodDogMTEsIHdpZHRoOiA1IH0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gZHJhd0ZsYW1lQnVybkVmZmVjdChjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgcG9pbnQ6IFBvaW50LCBsaWZlOiBudW1iZXIsIHRpY2s6IG51bWJlcikge1xuICBjb25zdCBmbGFyZSA9IDEgLSBsaWZlO1xuICBjb25zdCBzdHJlbmd0aCA9IE1hdGgubWluKDEsIGxpZmUgKiAxLjYpO1xuICBjb25zdCByaXNlID0gTWF0aC5taW4oMSwgZmxhcmUgKiA0KTtcbiAgY3R4LnNhdmUoKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGByZ2JhKDc0LCA0NCwgMjgsICR7MC4xNiAqIGxpZmV9KWA7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4LmVsbGlwc2UocG9pbnQueCwgcG9pbnQueSArIDEzLCAxNSwgNS41LCAwLCAwLCBNYXRoLlBJICogMik7XG4gIGN0eC5maWxsKCk7XG4gIGNvbnN0IGdsb3cgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQocG9pbnQueCwgcG9pbnQueSArIDQsIDAsIHBvaW50LngsIHBvaW50LnkgKyA0LCAyNCk7XG4gIGdsb3cuYWRkQ29sb3JTdG9wKDAsIGByZ2JhKDI0NywgMTUwLCA2MiwgJHswLjI2ICogc3RyZW5ndGh9KWApO1xuICBnbG93LmFkZENvbG9yU3RvcCgxLCBcInJnYmEoMjQ3LCAxNTAsIDYyLCAwKVwiKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGdsb3c7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4LmFyYyhwb2ludC54LCBwb2ludC55ICsgNCwgMjQsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcbiAgRkxBTUVfVE9OR1VFUy5mb3JFYWNoKCh0b25ndWUsIGluZGV4KSA9PiB7XG4gICAgY29uc3QgZmxpY2tlciA9IDAuNzggKyAwLjIyICogTWF0aC5zaW4odGljayAqIDAuOSArIGluZGV4ICogMS43KTtcbiAgICBkcmF3RmxhbWVUb25ndWUoY3R4LCBwb2ludC54ICsgdG9uZ3VlLmR4LCBwb2ludC55ICsgdG9uZ3VlLmJhc2UsIHRvbmd1ZS5oZWlnaHQgKiByaXNlICogZmxpY2tlciwgdG9uZ3VlLndpZHRoLCBNYXRoLnNpbih0aWNrICogMC42ICsgaW5kZXgpICogMiwgc3RyZW5ndGggKiAwLjg1KTtcbiAgfSk7XG4gIGRyYXdFbWJlcnMoY3R4LCBwb2ludCwgZmxhcmUsIHRpY2ssIDUsIHN0cmVuZ3RoKTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuLyoqIFNtYWxsIGZsYW1lcyB0aGF0IHN0YXkgb24gYSBzY29yY2hlZCB1bml0IGZvciBhcyBsb25nIGFzIHRoZSBzY29yY2ggbGFzdHMsIGZhZGluZyBvdmVyIGl0cyBsYXN0IHNlY29uZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkcmF3U2NvcmNoZWRVbml0RmxhbWVzKGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBwb2ludDogUG9pbnQsIHJhZGl1czogbnVtYmVyLCBub3c6IG51bWJlciwgcmVtYWluaW5nVGlja3M6IG51bWJlcikge1xuICBjb25zdCBzdHJlbmd0aCA9IE1hdGgubWluKDEsIHJlbWFpbmluZ1RpY2tzIC8gc2Vjb25kcygxKSkgKiAwLjY7XG4gIGNvbnN0IHRpY2sgPSBub3cgLyA1MDtcbiAgY29uc3Qgc3ByZWFkID0gcmFkaXVzICogMC40NTtcbiAgY3R4LnNhdmUoKTtcbiAgZHJhd0ZsYW1lVG9uZ3VlKGN0eCwgcG9pbnQueCAtIHNwcmVhZCwgcG9pbnQueSArIDQsIDkgKyBNYXRoLnNpbih0aWNrICogMC44KSAqIDIsIDUsIE1hdGguc2luKHRpY2sgKiAwLjUpICogMS41LCBzdHJlbmd0aCk7XG4gIGRyYXdGbGFtZVRvbmd1ZShjdHgsIHBvaW50LnggKyBzcHJlYWQgKiAwLjYsIHBvaW50LnkgKyAxLCAxMiArIE1hdGguc2luKHRpY2sgKiAwLjcgKyAyKSAqIDIuNSwgNiwgTWF0aC5zaW4odGljayAqIDAuNDUgKyAxKSAqIDEuNSwgc3RyZW5ndGgpO1xuICBkcmF3RW1iZXJzKGN0eCwgeyB4OiBwb2ludC54LCB5OiBwb2ludC55IC0gNiB9LCAodGljayAvIDQwKSAlIDEsIHRpY2ssIDMsIHN0cmVuZ3RoKTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gZHJhd0ZsYW1lVG9uZ3VlKGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCB4OiBudW1iZXIsIGJhc2VZOiBudW1iZXIsIGhlaWdodDogbnVtYmVyLCB3aWR0aDogbnVtYmVyLCBsZWFuOiBudW1iZXIsIGFscGhhOiBudW1iZXIpIHtcbiAgaWYgKGhlaWdodCA8IDEgfHwgYWxwaGEgPD0gMCkgcmV0dXJuO1xuICBjb25zdCB0aXBYID0geCArIGxlYW47XG4gIGNvbnN0IHRpcFkgPSBiYXNlWSAtIGhlaWdodDtcbiAgY29uc3QgZ3JhZGllbnQgPSBjdHguY3JlYXRlTGluZWFyR3JhZGllbnQoMCwgYmFzZVksIDAsIHRpcFkpO1xuICBncmFkaWVudC5hZGRDb2xvclN0b3AoMCwgYHJnYmEoMTg2LCA1NiwgMzgsICR7YWxwaGF9KWApO1xuICBncmFkaWVudC5hZGRDb2xvclN0b3AoMC40NSwgYHJnYmEoMjM2LCAxMjQsIDQ4LCAke2FscGhhfSlgKTtcbiAgZ3JhZGllbnQuYWRkQ29sb3JTdG9wKDEsIGByZ2JhKDI1NSwgMjE0LCAxMTAsICR7YWxwaGEgKiAwLjg1fSlgKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGdyYWRpZW50O1xuICBmbGFtZVRvbmd1ZVBhdGgoY3R4LCB4LCBiYXNlWSwgdGlwWCwgdGlwWSwgd2lkdGgsIGhlaWdodCk7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5maWxsU3R5bGUgPSBgcmdiYSgyNTUsIDI0MiwgMTk2LCAke2FscGhhICogMC43fSlgO1xuICBmbGFtZVRvbmd1ZVBhdGgoY3R4LCB4ICsgbGVhbiAqIDAuMiwgYmFzZVksIHggKyBsZWFuICogMC42LCBiYXNlWSAtIGhlaWdodCAqIDAuNSwgd2lkdGggKiAwLjQyLCBoZWlnaHQgKiAwLjUpO1xuICBjdHguZmlsbCgpO1xufVxuXG5mdW5jdGlvbiBmbGFtZVRvbmd1ZVBhdGgoY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsIHg6IG51bWJlciwgYmFzZVk6IG51bWJlciwgdGlwWDogbnVtYmVyLCB0aXBZOiBudW1iZXIsIHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyKSB7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4Lm1vdmVUbyh4IC0gd2lkdGggLyAyLCBiYXNlWSk7XG4gIGN0eC5iZXppZXJDdXJ2ZVRvKHggLSB3aWR0aCAqIDAuNywgYmFzZVkgLSBoZWlnaHQgKiAwLjQ1LCB0aXBYIC0gd2lkdGggKiAwLjE1LCB0aXBZICsgaGVpZ2h0ICogMC4yNSwgdGlwWCwgdGlwWSk7XG4gIGN0eC5iZXppZXJDdXJ2ZVRvKHRpcFggKyB3aWR0aCAqIDAuMiwgdGlwWSArIGhlaWdodCAqIDAuMywgeCArIHdpZHRoICogMC43LCBiYXNlWSAtIGhlaWdodCAqIDAuNCwgeCArIHdpZHRoIC8gMiwgYmFzZVkpO1xuICBjdHgucXVhZHJhdGljQ3VydmVUbyh4LCBiYXNlWSArIHdpZHRoICogMC4zNSwgeCAtIHdpZHRoIC8gMiwgYmFzZVkpO1xuICBjdHguY2xvc2VQYXRoKCk7XG59XG5cbmZ1bmN0aW9uIGRyYXdFbWJlcnMoY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsIHBvaW50OiBQb2ludCwgcGhhc2U6IG51bWJlciwgdGljazogbnVtYmVyLCBjb3VudDogbnVtYmVyLCBzdHJlbmd0aDogbnVtYmVyKSB7XG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBjb3VudDsgaW5kZXggKz0gMSkge1xuICAgIGNvbnN0IHQgPSAocGhhc2UgKyBpbmRleCAqIDAuMTkpICUgMTtcbiAgICBjb25zdCB4ID0gcG9pbnQueCArIE1hdGguc2luKGluZGV4ICogMi4zICsgdGljayAqIDAuMjUpICogKDUgKyBpbmRleCAqIDIpO1xuICAgIGNvbnN0IHkgPSBwb2ludC55ICsgNiAtIHQgKiAzNDtcbiAgICBjdHguZmlsbFN0eWxlID0gYHJnYmEoMjU1LCAkezE5MCAtIGluZGV4ICogMTJ9LCA5MCwgJHsoMSAtIHQpICogMC44ICogc3RyZW5ndGh9KWA7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5hcmMoeCwgeSwgMS4xLCAwLCBNYXRoLlBJICogMik7XG4gICAgY3R4LmZpbGwoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdHJva2VQb2x5bGluZShjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgcG9pbnRzOiBQb2ludFtdKSB7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgcG9pbnRzLmZvckVhY2goKHBvaW50LCBpbmRleCkgPT4ge1xuICAgIGlmIChpbmRleCA9PT0gMCkgY3R4Lm1vdmVUbyhwb2ludC54LCBwb2ludC55KTtcbiAgICBlbHNlIGN0eC5saW5lVG8ocG9pbnQueCwgcG9pbnQueSk7XG4gIH0pO1xuICBjdHguc3Ryb2tlKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkcmF3UGh5c2ljYWxNaXNzaWxlKGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBmcm9tOiBQb2ludCwgdG86IFBvaW50LCBwcm9ncmVzczogbnVtYmVyLCBsb29rOiBcImZpcmVcIiB8IFwic3BlYXJcIiB8IFwic3RvbmVcIiB8IFwic2hlbGxcIikge1xuICBjb25zdCBmcmFtZSA9IGFycm93RnJhbWUoZnJvbSwgdG8sIHByb2dyZXNzLCBsb29rID09PSBcInNwZWFyXCIgPyAxLjE1IDogMC41NSk7XG4gIGN0eC5zYXZlKCk7IGN0eC50cmFuc2xhdGUoZnJhbWUudGlwLngsIGZyYW1lLnRpcC55KTsgY3R4LnJvdGF0ZShmcmFtZS5hbmdsZSk7XG4gIGlmIChsb29rID09PSBcImZpcmVcIikge1xuICAgIGNvbnN0IGdsb3cgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQoLTMsIDAsIDEsIC0zLCAwLCAxNSk7XG4gICAgZ2xvdy5hZGRDb2xvclN0b3AoMCwgJyNlOGI0NjZhOCcpOyBnbG93LmFkZENvbG9yU3RvcCgxLCAnI2I4NTIyYjAwJyk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IGdsb3c7IGN0eC5maWxsUmVjdCgtMjAsLTE2LDM2LDMyKTtcbiAgICBjdHguZmlsbFN0eWxlID0gJyNiOTY1MzknOyBjdHguYmVnaW5QYXRoKCk7IGN0eC5tb3ZlVG8oNiwwKTsgY3R4LnF1YWRyYXRpY0N1cnZlVG8oLTMsLTgsLTE4LC0zKTsgY3R4LmxpbmVUbygtMTMsMCk7IGN0eC5saW5lVG8oLTIxLDQpOyBjdHgucXVhZHJhdGljQ3VydmVUbygtMiw4LDYsMCk7IGN0eC5maWxsKCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9ICcjZjBkMDkyJzsgY3R4LmJlZ2luUGF0aCgpOyBjdHguZWxsaXBzZSgwLDAsNSwyLjUsMCwwLE1hdGguUEkqMik7IGN0eC5maWxsKCk7XG4gIH0gZWxzZSBpZiAobG9vayA9PT0gXCJzcGVhclwiKSB7XG4gICAgY3R4LnN0cm9rZVN0eWxlPScjOWE4NzY3JzsgY3R4LmxpbmVXaWR0aD0xLjg7IGN0eC5iZWdpblBhdGgoKTsgY3R4Lm1vdmVUbygtMjQsMCk7IGN0eC5saW5lVG8oLTMsMCk7IGN0eC5zdHJva2UoKTtcbiAgICBjdHguZmlsbFN0eWxlPScjYzBjNWI3JzsgY3R4LnN0cm9rZVN0eWxlPScjMzczZTNkJzsgY3R4LmxpbmVXaWR0aD0uNzsgY3R4LmJlZ2luUGF0aCgpOyBjdHgubW92ZVRvKDMsMCk7IGN0eC5saW5lVG8oLTUsLTIuNSk7IGN0eC5saW5lVG8oLTQsMi41KTsgY3R4LmNsb3NlUGF0aCgpOyBjdHguZmlsbCgpOyBjdHguc3Ryb2tlKCk7XG4gIH0gZWxzZSB7XG4gICAgY3R4LmZpbGxTdHlsZSA9IGxvb2sgPT09IFwic3RvbmVcIiA/ICcjOGI4ODc0JyA6ICcjNTU1YjU5JzsgY3R4LnN0cm9rZVN0eWxlPScjMjkyZjMwJzsgY3R4LmxpbmVXaWR0aD0xO1xuICAgIGN0eC5iZWdpblBhdGgoKTsgY3R4LmVsbGlwc2UoMCwwLGxvb2sgPT09IFwic3RvbmVcIiA/IDQuNSA6IDMuNSwzLjUsMCwwLE1hdGguUEkqMik7IGN0eC5maWxsKCk7IGN0eC5zdHJva2UoKTtcbiAgICBjdHguc3Ryb2tlU3R5bGU9JyNkOGNkYjA5YSc7IGN0eC5iZWdpblBhdGgoKTsgY3R4Lm1vdmVUbygtMiwtMik7IGN0eC5saW5lVG8oMSwtMyk7IGN0eC5zdHJva2UoKTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd0Fycm93KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBmcmFtZTogQXJyb3dGcmFtZSkge1xuICBjb25zdCB7IHRpcCwgdGFpbCwgYW5nbGUsIGxlbmd0aCB9ID0gZnJhbWU7XG4gIGNvbnN0IHV4ID0gTWF0aC5jb3MoYW5nbGUpO1xuICBjb25zdCB1eSA9IE1hdGguc2luKGFuZ2xlKTtcbiAgY29uc3QgcHggPSAtdXk7XG4gIGNvbnN0IHB5ID0gdXg7XG4gIGNvbnN0IGhlYWRMZW5ndGggPSBsZW5ndGggKiAwLjM7XG4gIGNvbnN0IGhlYWRIYWxmID0gbGVuZ3RoICogMC4xNDtcbiAgY29uc3QgbmVjayA9IHsgeDogdGlwLnggLSB1eCAqIGhlYWRMZW5ndGgsIHk6IHRpcC55IC0gdXkgKiBoZWFkTGVuZ3RoIH07XG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5saW5lQ2FwID0gXCJyb3VuZFwiO1xuICBjdHgubGluZUpvaW4gPSBcInJvdW5kXCI7XG4gIGN0eC5zdHJva2VTdHlsZSA9IFwicmdiYSg2MCwgNTAsIDM1LCAwLjIpXCI7XG4gIGN0eC5saW5lV2lkdGggPSAyO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5tb3ZlVG8odGFpbC54IC0gdXggKiBsZW5ndGggKiAwLjcsIHRhaWwueSAtIHV5ICogbGVuZ3RoICogMC43KTtcbiAgY3R4LmxpbmVUbyh0YWlsLngsIHRhaWwueSk7XG4gIGN0eC5zdHJva2UoKTtcblxuICBjdHguc3Ryb2tlU3R5bGUgPSBcIiM1YjQxMjdcIjtcbiAgY3R4LmxpbmVXaWR0aCA9IE1hdGgubWF4KDEuNiwgbGVuZ3RoICogMC4wOCk7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4Lm1vdmVUbyh0YWlsLngsIHRhaWwueSk7XG4gIGN0eC5saW5lVG8obmVjay54LCBuZWNrLnkpO1xuICBjdHguc3Ryb2tlKCk7XG5cbiAgY3R4LmZpbGxTdHlsZSA9IFwiIzM0NDAzYlwiO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBcIiMxZjJhMjRcIjtcbiAgY3R4LmxpbmVXaWR0aCA9IDAuODtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHgubW92ZVRvKHRpcC54LCB0aXAueSk7XG4gIGN0eC5saW5lVG8obmVjay54ICsgcHggKiBoZWFkSGFsZiwgbmVjay55ICsgcHkgKiBoZWFkSGFsZik7XG4gIGN0eC5saW5lVG8obmVjay54ICsgdXggKiBoZWFkTGVuZ3RoICogMC4yNSwgbmVjay55ICsgdXkgKiBoZWFkTGVuZ3RoICogMC4yNSk7XG4gIGN0eC5saW5lVG8obmVjay54IC0gcHggKiBoZWFkSGFsZiwgbmVjay55IC0gcHkgKiBoZWFkSGFsZik7XG4gIGN0eC5jbG9zZVBhdGgoKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnN0cm9rZSgpO1xuXG4gIGNvbnN0IHZhbmUgPSBsZW5ndGggKiAwLjI0O1xuICBjb25zdCBzcHJlYWQgPSBsZW5ndGggKiAwLjEzO1xuICBjdHguZmlsbFN0eWxlID0gXCIjZWZlNmNjXCI7XG4gIGN0eC5zdHJva2VTdHlsZSA9IFwicmdiYSg2MCwgNTAsIDM1LCAwLjcpXCI7XG4gIGZvciAoY29uc3Qgc2lkZSBvZiBbMSwgLTFdKSB7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8odGFpbC54ICsgdXggKiB2YW5lLCB0YWlsLnkgKyB1eSAqIHZhbmUpO1xuICAgIGN0eC5saW5lVG8odGFpbC54ICsgcHggKiBzcHJlYWQgKiBzaWRlICsgdXggKiB2YW5lICogMC4zNSwgdGFpbC55ICsgcHkgKiBzcHJlYWQgKiBzaWRlICsgdXkgKiB2YW5lICogMC4zNSk7XG4gICAgY3R4LmxpbmVUbyh0YWlsLnggKyBweCAqIHNwcmVhZCAqIHNpZGUgLSB1eCAqIDEuNSwgdGFpbC55ICsgcHkgKiBzcHJlYWQgKiBzaWRlIC0gdXkgKiAxLjUpO1xuICAgIGN0eC5saW5lVG8odGFpbC54LCB0YWlsLnkpO1xuICAgIGN0eC5jbG9zZVBhdGgoKTtcbiAgICBjdHguZmlsbCgpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG4vLyBBIGNhc3RlcidzIHdlYXBvbiBpcyBhIHBpbnByaWNrIG5leHQgdG8gaXRzIHNwZWxsLCBzbyBpdHMgb3JiIHN0YXlzIHNtYWxsIGFuZCBmYWludDogc21hbGxlciB0aGFuIGFuIGFycm93J3MgaGVhZFxuLy8gdG8gdGFpbCwgYW5kIG5ldmVyIGJyaWdodGVyIHRoYW4gdGhlIHNwZWxsIGVmZmVjdHMgZHJhd24gYWJvdmUuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1NwZWxsT3JiKGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBmcm9tOiBQb2ludCwgdG86IFBvaW50LCBwcm9ncmVzczogbnVtYmVyLCBwYWxldHRlOiBTcGVsbE9yYlBhbGV0dGUpIHtcbiAgY29uc3QgZHggPSB0by54IC0gZnJvbS54O1xuICBjb25zdCBkeSA9IHRvLnkgLSBmcm9tLnk7XG4gIGNvbnN0IGxlbmd0aCA9IE1hdGgubWF4KDEsIE1hdGguaHlwb3QoZHgsIGR5KSk7XG4gIGNvbnN0IHV4ID0gZHggLyBsZW5ndGg7XG4gIGNvbnN0IHV5ID0gZHkgLyBsZW5ndGg7XG4gIGNvbnN0IGJvYiA9IE1hdGguc2luKHByb2dyZXNzICogTWF0aC5QSSAqIDMpICogMS41O1xuICBjb25zdCBoZWFkID0geyB4OiBmcm9tLnggKyBkeCAqIHByb2dyZXNzIC0gdXkgKiBib2IsIHk6IGZyb20ueSArIGR5ICogcHJvZ3Jlc3MgKyB1eCAqIGJvYiB9O1xuICBjb25zdCBmYWRlID0gTWF0aC5taW4oMSwgcHJvZ3Jlc3MgKiA2LCAoMSAtIHByb2dyZXNzKSAqIDggKyAwLjM1KTtcbiAgY3R4LnNhdmUoKTtcbiAgZm9yIChsZXQgaW5kZXggPSAzOyBpbmRleCA+PSAxOyBpbmRleCAtPSAxKSB7XG4gICAgY3R4LmZpbGxTdHlsZSA9IHJnYmEocGFsZXR0ZS5nbG93LCAoMC4zIC0gaW5kZXggKiAwLjA3KSAqIGZhZGUpO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHguYXJjKGhlYWQueCAtIHV4ICogaW5kZXggKiA1LCBoZWFkLnkgLSB1eSAqIGluZGV4ICogNSwgMi4yIC0gaW5kZXggKiAwLjQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHguZmlsbCgpO1xuICB9XG4gIGNvbnN0IGdsb3cgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQoaGVhZC54LCBoZWFkLnksIDAsIGhlYWQueCwgaGVhZC55LCA3KTtcbiAgZ2xvdy5hZGRDb2xvclN0b3AoMCwgcmdiYShwYWxldHRlLmdsb3csIDAuNDIgKiBmYWRlKSk7XG4gIGdsb3cuYWRkQ29sb3JTdG9wKDEsIHJnYmEocGFsZXR0ZS5nbG93LCAwKSk7XG4gIGN0eC5maWxsU3R5bGUgPSBnbG93O1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5hcmMoaGVhZC54LCBoZWFkLnksIDcsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LmZpbGxTdHlsZSA9IHJnYmEocGFsZXR0ZS5jb3JlLCAwLjg1ICogZmFkZSk7XG4gIGN0eC5zdHJva2VTdHlsZSA9IHJnYmEocGFsZXR0ZS5nbG93LCAwLjYgKiBmYWRlKTtcbiAgY3R4LmxpbmVXaWR0aCA9IDAuODtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHguYXJjKGhlYWQueCwgaGVhZC55LCAyLjQsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnN0cm9rZSgpO1xuICBjdHgucmVzdG9yZSgpO1xufVxuXG4vLyBAQEBwcm9qZWN0aWxlLXRyYWlsIC0gSXRlbSBibGFzdHMgcmVhZCBhcyBzaG9ydCBmYWRpbmcgbW90aW9uLCBub3QgYSBzb3VyY2UtdG8tdGFyZ2V0IGRlYnVnIGxpbmUuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1Byb2plY3RpbGVUcmFpbChjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgZnJvbTogUG9pbnQsIHRvOiBQb2ludCwgaGVhZDogUG9pbnQsIHByb2dyZXNzOiBudW1iZXIsIGxpZmU6IG51bWJlcikge1xuICBjb25zdCBkeCA9IHRvLnggLSBmcm9tLng7XG4gIGNvbnN0IGR5ID0gdG8ueSAtIGZyb20ueTtcbiAgY29uc3QgbGVuZ3RoID0gTWF0aC5tYXgoMSwgTWF0aC5oeXBvdChkeCwgZHkpKTtcbiAgY29uc3QgdXggPSBkeCAvIGxlbmd0aDtcbiAgY29uc3QgdXkgPSBkeSAvIGxlbmd0aDtcbiAgY29uc3QgdHJhaWxMZW5ndGggPSBNYXRoLm1pbig5MiwgTWF0aC5tYXgoMjQsIGxlbmd0aCAqIDAuNDIpKTtcbiAgY29uc3QgdGFpbCA9IHtcbiAgICB4OiBoZWFkLnggLSB1eCAqIHRyYWlsTGVuZ3RoLFxuICAgIHk6IGhlYWQueSAtIHV5ICogdHJhaWxMZW5ndGgsXG4gIH07XG4gIGNvbnN0IGZsaWdodEdsb3cgPSBNYXRoLnNpbihwcm9ncmVzcyAqIE1hdGguUEkpO1xuICBjb25zdCBhbHBoYSA9IE1hdGgubWF4KDAuMjIsIE1hdGgubWluKDAuOTUsIDAuMjQgKyBmbGlnaHRHbG93ICogMC42MiArIGxpZmUgKiAwLjEyKSk7XG4gIGNvbnN0IGNvb2wgPSB7IHI6IDQ5LCBnOiA5NSwgYjogMTM1IH07XG4gIGNvbnN0IGVtYmVyID0gbWl4UmdiKHsgcjogMTkwLCBnOiA2MiwgYjogNTUgfSwgeyByOiAyMjYsIGc6IDEyOSwgYjogNTIgfSwgcHJvZ3Jlc3MpO1xuICBjb25zdCBob3QgPSBtaXhSZ2IoeyByOiA5NiwgZzogMTM5LCBiOiAxNjYgfSwgeyByOiAyNDIsIGc6IDIwOCwgYjogOTIgfSwgTWF0aC5taW4oMSwgcHJvZ3Jlc3MgKiAxLjE4KSk7XG4gIGNvbnN0IGdyYWRpZW50ID0gY3R4LmNyZWF0ZUxpbmVhckdyYWRpZW50KHRhaWwueCwgdGFpbC55LCBoZWFkLngsIGhlYWQueSk7XG4gIGdyYWRpZW50LmFkZENvbG9yU3RvcCgwLCByZ2JhKGNvb2wsIDApKTtcbiAgZ3JhZGllbnQuYWRkQ29sb3JTdG9wKDAuMzQsIHJnYmEoY29vbCwgYWxwaGEgKiAwLjI4KSk7XG4gIGdyYWRpZW50LmFkZENvbG9yU3RvcCgwLjcyLCByZ2JhKGVtYmVyLCBhbHBoYSAqIDAuNjgpKTtcbiAgZ3JhZGllbnQuYWRkQ29sb3JTdG9wKDEsIHJnYmEoaG90LCBhbHBoYSkpO1xuXG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5saW5lQ2FwID0gXCJyb3VuZFwiO1xuICBjdHgubGluZUpvaW4gPSBcInJvdW5kXCI7XG4gIGN0eC5zaGFkb3dDb2xvciA9IHJnYmEoZW1iZXIsIGFscGhhICogMC41OCk7XG4gIGN0eC5zaGFkb3dCbHVyID0gODtcbiAgY3R4LnN0cm9rZVN0eWxlID0gZ3JhZGllbnQ7XG4gIGN0eC5saW5lV2lkdGggPSA2O1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5tb3ZlVG8odGFpbC54LCB0YWlsLnkpO1xuICBjdHgubGluZVRvKGhlYWQueCwgaGVhZC55KTtcbiAgY3R4LnN0cm9rZSgpO1xuXG4gIGN0eC5zaGFkb3dCbHVyID0gMDtcbiAgY3R4LnN0cm9rZVN0eWxlID0gcmdiYSh7IHI6IDI1NSwgZzogMjUxLCBiOiAyMjcgfSwgYWxwaGEgKiAwLjYyKTtcbiAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4Lm1vdmVUbyh0YWlsLnggKyB1eCAqIHRyYWlsTGVuZ3RoICogMC41MiwgdGFpbC55ICsgdXkgKiB0cmFpbExlbmd0aCAqIDAuNTIpO1xuICBjdHgubGluZVRvKGhlYWQueCwgaGVhZC55KTtcbiAgY3R4LnN0cm9rZSgpO1xuXG4gIGN0eC5maWxsU3R5bGUgPSByZ2JhKGhvdCwgYWxwaGEpO1xuICBjdHguc3Ryb2tlU3R5bGUgPSByZ2JhKHsgcjogMzYsIGc6IDQ5LCBiOiAzOCB9LCBhbHBoYSAqIDAuNTUpO1xuICBjdHgubGluZVdpZHRoID0gMTtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHguZWxsaXBzZShoZWFkLngsIGhlYWQueSwgNC42LCAzLjIsIE1hdGguYXRhbjIoZHksIGR4KSwgMCwgTWF0aC5QSSAqIDIpO1xuICBjdHguZmlsbCgpO1xuICBjdHguc3Ryb2tlKCk7XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmNvbnN0IERVU1QgPSB7IHI6IDE1MCwgZzogMTIyLCBiOiA4NCB9O1xuY29uc3QgRFVTVF9FREdFID0geyByOiAxMDQsIGc6IDgwLCBiOiA1MCB9O1xuY29uc3QgSU5LID0geyByOiAzNiwgZzogNDksIGI6IDM4IH07XG5jb25zdCBTUEFSS19IT1QgPSB7IHI6IDI1NSwgZzogMjQ2LCBiOiAyMDQgfTtcbmNvbnN0IFNQQVJLID0geyByOiAyNDIsIGc6IDE4NCwgYjogNjAgfTtcblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdDaGFyZ2VUcmFpbChjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgZnJhbWU6IENoYXJnZVRyYWlsRnJhbWUpIHtcbiAgY3R4LnNhdmUoKTtcbiAgLy8gT2xkZXN0IGR1c3QgZmlyc3QsIHNvIHRoZSBmcmVzaCBwdWZmcyBhdCB0aGUgaG9vdmVzIHNpdCBvbiB0b3AuXG4gIGZvciAobGV0IGluZGV4ID0gZnJhbWUucHVmZnMubGVuZ3RoIC0gMTsgaW5kZXggPj0gMDsgaW5kZXgtLSkge1xuICAgIGNvbnN0IHB1ZmYgPSBmcmFtZS5wdWZmc1tpbmRleF0hO1xuICAgIGN0eC5maWxsU3R5bGUgPSByZ2JhKERVU1QsIHB1ZmYuYWxwaGEgKiAwLjU1KTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSByZ2JhKERVU1RfRURHRSwgcHVmZi5hbHBoYSk7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDEuMjtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LmVsbGlwc2UocHVmZi54LCBwdWZmLnksIHB1ZmYucngsIHB1ZmYucnksIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHguZmlsbCgpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfVxuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IE1hdGgubWluKDEsIGZyYW1lLnN0cmVha3MubGVuZ3RoKTsgaW5kZXgrKykge1xuICAgIGNvbnN0IHN0cmVhayA9IGZyYW1lLnN0cmVha3NbaW5kZXhdITtcbiAgICBjb25zdCBncmFkaWVudCA9IGN0eC5jcmVhdGVMaW5lYXJHcmFkaWVudChzdHJlYWsuZnJvbS54LCBzdHJlYWsuZnJvbS55LCBzdHJlYWsudG8ueCwgc3RyZWFrLnRvLnkpO1xuICAgIGdyYWRpZW50LmFkZENvbG9yU3RvcCgwLCByZ2JhKElOSywgc3RyZWFrLmFscGhhICogLjIpKTtcbiAgICBncmFkaWVudC5hZGRDb2xvclN0b3AoMSwgcmdiYShJTkssIDApKTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBncmFkaWVudDtcbiAgICBjdHgubGluZVdpZHRoID0gc3RyZWFrLndpZHRoO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHN0cmVhay5mcm9tLngsIHN0cmVhay5mcm9tLnkpO1xuICAgIGN0eC5saW5lVG8oc3RyZWFrLnRvLngsIHN0cmVhay50by55KTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gIH1cbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdDaGFyZ2VJbXBhY3QoY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsIGZyYW1lOiBDaGFyZ2VJbXBhY3RGcmFtZSkge1xuICBjb25zdCB7IHJpbmcgfSA9IGZyYW1lO1xuICBjdHguc2F2ZSgpO1xuICBjdHgubGluZUNhcCA9IFwicm91bmRcIjtcbiAgY3R4LmZpbGxTdHlsZSA9IHJnYmEoRFVTVCwgcmluZy5hbHBoYSAqIDAuMTgpO1xuICBjdHguc3Ryb2tlU3R5bGUgPSByZ2JhKERVU1RfRURHRSwgcmluZy5hbHBoYSAqIDAuNik7XG4gIGN0eC5saW5lV2lkdGggPSAxLjU7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4LmVsbGlwc2UocmluZy54LCByaW5nLnksIHJpbmcucngsIHJpbmcucnksIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnN0cm9rZSgpO1xuICBmb3IgKGNvbnN0IGNsb2Qgb2YgZnJhbWUuY2xvZHMpIHtcbiAgICBjdHguZmlsbFN0eWxlID0gcmdiYShEVVNULCBjbG9kLmFscGhhICogMC43KTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSByZ2JhKERVU1RfRURHRSwgY2xvZC5hbHBoYSk7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDE7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5hcmMoY2xvZC54LCBjbG9kLnksIGNsb2QuciwgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5maWxsKCk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBNYXRoLm1pbigyLCBmcmFtZS5yYXlzLmxlbmd0aCk7IGluZGV4KyspIHtcbiAgICBjb25zdCByYXkgPSBmcmFtZS5yYXlzW2luZGV4XSE7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gcmdiYShTUEFSSywgcmF5LmFscGhhICogMC44NSk7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8ocmF5LmZyb20ueCwgcmF5LmZyb20ueSk7XG4gICAgY3R4LmxpbmVUbyhyYXkudG8ueCwgcmF5LnRvLnkpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSByZ2JhKFNQQVJLX0hPVCwgcmF5LmFscGhhKTtcbiAgICBjdHgubGluZVdpZHRoID0gMC44O1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfVxuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgTWF0aC5taW4oMiwgZnJhbWUuc3BhcmtzLmxlbmd0aCk7IGluZGV4KyspIHtcbiAgICBjb25zdCBzcGFyayA9IGZyYW1lLnNwYXJrc1tpbmRleF0hO1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IHJnYmEoU1BBUkssIHNwYXJrLmFscGhhKTtcbiAgICBjdHgubGluZVdpZHRoID0gMS41O1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHNwYXJrLmZyb20ueCwgc3BhcmsuZnJvbS55KTtcbiAgICBjdHgubGluZVRvKHNwYXJrLnRvLngsIHNwYXJrLnRvLnkpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgICBjdHguZmlsbFN0eWxlID0gcmdiYShTUEFSS19IT1QsIHNwYXJrLmFscGhhKTtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LmFyYyhzcGFyay50by54LCBzcGFyay50by55LCAxLjEsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHguZmlsbCgpO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmZ1bmN0aW9uIG1peFJnYihmcm9tOiB7IHI6IG51bWJlcjsgZzogbnVtYmVyOyBiOiBudW1iZXIgfSwgdG86IHsgcjogbnVtYmVyOyBnOiBudW1iZXI7IGI6IG51bWJlciB9LCBhbW91bnQ6IG51bWJlcikge1xuICBjb25zdCBjbGFtcGVkID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgYW1vdW50KSk7XG4gIHJldHVybiB7XG4gICAgcjogTWF0aC5yb3VuZChmcm9tLnIgKyAodG8uciAtIGZyb20ucikgKiBjbGFtcGVkKSxcbiAgICBnOiBNYXRoLnJvdW5kKGZyb20uZyArICh0by5nIC0gZnJvbS5nKSAqIGNsYW1wZWQpLFxuICAgIGI6IE1hdGgucm91bmQoZnJvbS5iICsgKHRvLmIgLSBmcm9tLmIpICogY2xhbXBlZCksXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJnYmEoY29sb3I6IHsgcjogbnVtYmVyOyBnOiBudW1iZXI7IGI6IG51bWJlciB9LCBhbHBoYTogbnVtYmVyKSB7XG4gIHJldHVybiBgcmdiYSgke2NvbG9yLnJ9LCAke2NvbG9yLmd9LCAke2NvbG9yLmJ9LCAke01hdGgubWF4KDAsIE1hdGgubWluKDEsIGFscGhhKSl9KWA7XG59XG5cbi8vIERldGVybWluaXN0aWMgY29pbiBhcmNzIGFuZCBhIHJpc2luZyByZWNlaXB0LCB0aW1lZCBieSBub3JtYWxpemVkIGxpZmV0aW1lLlxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdHb2xkQm91bnR5RWZmZWN0KGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCBwb2ludDogUG9pbnQsIGxpZmU6IG51bWJlciwgYW1vdW50OiBudW1iZXIpIHtcbiAgY29uc3QgZWxhcHNlZCA9IDEgLSBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBsaWZlKSk7XG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5nbG9iYWxBbHBoYSA9IE1hdGgubWluKDEsIGxpZmUgKiAzKTtcbiAgY3R4LmxpbmVXaWR0aCA9IDEuNTtcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IDU7IGluZGV4KyspIHtcbiAgICBjb25zdCBzcHJlYWQgPSAoaW5kZXggLSAyKSAqIDEyICogZWxhcHNlZDtcbiAgICBjb25zdCBsaWZ0ID0gTWF0aC5zaW4oZWxhcHNlZCAqIE1hdGguUEkpICogKDE5ICsgKGluZGV4ICUgMikgKiA5KTtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LmVsbGlwc2UocG9pbnQueCArIHNwcmVhZCwgcG9pbnQueSAtIDggLSBsaWZ0LCAzLjUsIDQuNSwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5maWxsU3R5bGUgPSBcIiNmM2NmNTlcIjsgY3R4LnN0cm9rZVN0eWxlID0gXCIjOGM2NTFkXCI7IGN0eC5maWxsKCk7IGN0eC5zdHJva2UoKTtcbiAgICBjdHguYmVnaW5QYXRoKCk7IGN0eC5tb3ZlVG8ocG9pbnQueCArIHNwcmVhZCwgcG9pbnQueSAtIDEwIC0gbGlmdCk7IGN0eC5saW5lVG8ocG9pbnQueCArIHNwcmVhZCwgcG9pbnQueSAtIDYgLSBsaWZ0KTsgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGN0eC5mb250ID0gXCJib2xkIDE0cHggc2Fucy1zZXJpZlwiOyBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgY3R4LmxpbmVXaWR0aCA9IDM7IGN0eC5zdHJva2VTdHlsZSA9IFwiIzM4MmYyMVwiOyBjdHguZmlsbFN0eWxlID0gXCIjZmZlMThhXCI7XG4gIGNvbnN0IHRleHRZID0gcG9pbnQueSAtIDMyIC0gZWxhcHNlZCAqIDI1O1xuICBjdHguc3Ryb2tlVGV4dChgKyR7YW1vdW50fWAsIHBvaW50LngsIHRleHRZKTsgY3R4LmZpbGxUZXh0KGArJHthbW91bnR9YCwgcG9pbnQueCwgdGV4dFkpO1xuICBjdHgucmVzdG9yZSgpO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGVBQWU7QUFFeEIsU0FBUyxZQUFZLHVCQUE2RztBQUszSCxnQkFBUyx5QkFBeUIsS0FBK0IsUUFBcUIsTUFBYSxJQUFXO0FBQ25ILFFBQU0sT0FBTyxPQUFPLFlBQVksT0FBTztBQUN2QyxRQUFNLFdBQVcsSUFBSTtBQUNyQixRQUFNLEtBQUssR0FBRyxJQUFJLEtBQUs7QUFDdkIsUUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLO0FBQ3ZCLFFBQU0sU0FBUyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSSxFQUFFLENBQUM7QUFDN0MsUUFBTSxLQUFLLENBQUMsS0FBSztBQUNqQixRQUFNLEtBQUssS0FBSztBQUNoQixRQUFNLFNBQWtCLENBQUM7QUFDekIsV0FBUyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRztBQUM5QixVQUFNLElBQUksSUFBSTtBQUNkLFVBQU0sT0FBTyxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksT0FBTyxPQUFPLFlBQVksSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLFdBQVcsS0FBSyxFQUFFLElBQUk7QUFDMUgsV0FBTyxLQUFLLEVBQUUsR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLENBQUM7QUFBQSxFQUNoRjtBQUVBLE1BQUksS0FBSztBQUNULE1BQUksVUFBVTtBQUNkLE1BQUksV0FBVztBQUNmLE1BQUksY0FBYyx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDM0QsTUFBSSxhQUFhO0FBQ2pCLE1BQUksY0FBYyxzQkFBc0IsT0FBTyxPQUFPLElBQUk7QUFDMUQsTUFBSSxZQUFZO0FBQ2hCLGlCQUFlLEtBQUssTUFBTTtBQUMxQixNQUFJLGFBQWE7QUFDakIsTUFBSSxjQUFjLHVCQUF1QixPQUFPLE9BQU8sR0FBRztBQUMxRCxNQUFJLFlBQVk7QUFDaEIsaUJBQWUsS0FBSyxNQUFNO0FBQzFCLE1BQUksY0FBYyx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDM0QsTUFBSSxZQUFZO0FBQ2hCLGlCQUFlLEtBQUssTUFBTTtBQUMxQixXQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssR0FBRztBQUM3QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksY0FBYyx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDM0QsUUFBSSxZQUFZO0FBQ2hCLFFBQUksVUFBVTtBQUNkLFFBQUksT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQ25CLFFBQUksT0FBTyxFQUFFLElBQUksS0FBSyxLQUFLLEtBQUssU0FBUyxHQUFHLEVBQUUsSUFBSSxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUM7QUFDM0UsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLE1BQUksUUFBUTtBQUNkO0FBRU8sZ0JBQVMsZUFBZSxVQUErQixRQUFxQixPQUFjLE1BQWM7QUFDN0csUUFBTSxFQUFFLEtBQUssY0FBYyxJQUFJO0FBQy9CLE1BQUksS0FBSztBQUNULE1BQUksVUFBVTtBQUNkLE1BQUksV0FBVztBQUNmLE1BQUksZ0JBQWdCLE1BQU0sR0FBRztBQUMzQixVQUFNLE9BQU8sY0FBYyxFQUFFLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxNQUFNLENBQUM7QUFDL0QsVUFBTSxXQUFXLElBQUkscUJBQXFCLEtBQUssR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQztBQUMxRSxhQUFTLGFBQWEsR0FBRyx1QkFBdUIsT0FBTyxPQUFPLElBQUksR0FBRztBQUNyRSxhQUFTLGFBQWEsTUFBTSxzQkFBc0IsTUFBTSxPQUFPLElBQUksR0FBRztBQUN0RSxhQUFTLGFBQWEsR0FBRyx1QkFBdUIsT0FBTyxPQUFPLElBQUksR0FBRztBQUNyRSxRQUFJLGNBQWM7QUFDbEIsUUFBSSxhQUFhO0FBQ2pCLFFBQUksY0FBYztBQUNsQixRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekIsUUFBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFDM0IsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUVBLFFBQU0sUUFBUSxJQUFJO0FBQ2xCLFFBQU0sT0FBTyxLQUFLLFFBQVE7QUFDMUIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksYUFBYTtBQUNqQixNQUFJLGNBQWMscUJBQXFCLE1BQU0sT0FBTyxJQUFJO0FBQ3hELE1BQUksWUFBWSx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDekQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksSUFBSSxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLEtBQUssQ0FBQztBQUM5QyxNQUFJLEtBQUs7QUFDVCxNQUFJLE9BQU87QUFDWCxNQUFJLGNBQWMsdUJBQXVCLE9BQU8sT0FBTyxJQUFJO0FBQzNELE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sTUFBTSxJQUFJLElBQUksTUFBTSxDQUFDO0FBQ2hDLE1BQUksT0FBTyxNQUFNLElBQUksSUFBSSxNQUFNLENBQUM7QUFDaEMsTUFBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUNoQyxNQUFJLE9BQU8sTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQ2hDLE1BQUksT0FBTztBQUNYLE1BQUksUUFBUTtBQUNkO0FBRU8sZ0JBQVMsaUJBQWlCLEtBQStCLE9BQWMsTUFBYztBQUMxRixRQUFNLE9BQU8sSUFBSTtBQUNqQixNQUFJLEtBQUs7QUFDVCxNQUFJLFVBQVU7QUFDZCxNQUFJLGNBQWM7QUFDbEIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksWUFBWSxxQkFBcUIsT0FBTyxPQUFPLElBQUk7QUFDdkQsTUFBSSxjQUFjLHFCQUFxQixPQUFPLE9BQU8sSUFBSTtBQUN6RCxNQUFJLFlBQVk7QUFDaEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxRQUFRLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSSxLQUFLLE9BQU8sSUFBSSxJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDbEYsTUFBSSxLQUFLO0FBQ1QsTUFBSSxPQUFPO0FBQ1gsTUFBSSxjQUFjLHVCQUF1QixPQUFPLE9BQU8sR0FBRztBQUMxRCxNQUFJLFlBQVk7QUFDaEIsV0FBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRztBQUM3QixVQUFNLFFBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxPQUFPO0FBQ3pDLFVBQU0sUUFBUSxJQUFJLE9BQU87QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxRQUFRLENBQUM7QUFDbkYsUUFBSSxPQUFPLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksUUFBUSxDQUFDO0FBQ25GLFFBQUksT0FBTztBQUFBLEVBQ2I7QUFDQSxNQUFJLFFBQVE7QUFDZDtBQUVPLGdCQUFTLGdCQUFnQixLQUErQixPQUFjLE1BQWM7QUFDekYsUUFBTSxTQUFTLElBQUk7QUFDbkIsTUFBSSxLQUFLO0FBQ1QsTUFBSSxVQUFVO0FBQ2QsTUFBSSxjQUFjO0FBQ2xCLE1BQUksYUFBYTtBQUNqQixNQUFJLGNBQWMsc0JBQXNCLE9BQU8sT0FBTyxJQUFJO0FBQzFELE1BQUksWUFBWSxvQkFBb0IsT0FBTyxPQUFPLEdBQUc7QUFDckQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLEdBQUcsS0FBSyxTQUFTLElBQUksSUFBSSxTQUFTLEdBQUcsR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQ3JGLE1BQUksS0FBSztBQUNULE1BQUksT0FBTztBQUNYLE1BQUksY0FBYyx1QkFBdUIsTUFBTSxPQUFPLElBQUk7QUFDMUQsTUFBSSxZQUFZO0FBQ2hCLFdBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUc7QUFDN0IsVUFBTSxVQUFVLElBQUksT0FBTztBQUMzQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sTUFBTSxJQUFJLFFBQVEsTUFBTSxJQUFJLEtBQUssU0FBUyxDQUFDO0FBQ3RELFFBQUksaUJBQWlCLE1BQU0sSUFBSSxTQUFTLEdBQUcsTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUN6RixRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFFTyxnQkFBUyxnQkFBZ0IsS0FBK0IsUUFBcUIsT0FBYyxNQUFjO0FBQzlHLFFBQU0sU0FBUyxPQUFPLFVBQVU7QUFDaEMsUUFBTSxRQUFRLElBQUk7QUFDbEIsTUFBSSxLQUFLO0FBQ1QsUUFBTSxXQUFXLElBQUkscUJBQXFCLE1BQU0sR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU07QUFDdkYsV0FBUyxhQUFhLEdBQUcsdUJBQXVCLE9BQU8sT0FBTyxHQUFHLEdBQUc7QUFDcEUsV0FBUyxhQUFhLE1BQU0sc0JBQXNCLE9BQU8sT0FBTyxJQUFJLEdBQUc7QUFDdkUsV0FBUyxhQUFhLEdBQUcsc0JBQXNCO0FBQy9DLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLElBQUksTUFBTSxHQUFHLE1BQU0sR0FBRyxRQUFRLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDaEQsTUFBSSxLQUFLO0FBRVQsTUFBSSxVQUFVO0FBQ2QsTUFBSSxXQUFXO0FBQ2YsTUFBSSxjQUFjO0FBQ2xCLE1BQUksYUFBYTtBQUNqQixXQUFTLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUSxHQUFHO0FBQ3RDLFFBQUksY0FBYyxzQkFBc0IsTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJO0FBQ3ZFLFFBQUksWUFBWSxNQUFNLE9BQU87QUFDN0IsUUFBSSxVQUFVO0FBQ2QsUUFBSSxJQUFJLE1BQU0sR0FBRyxNQUFNLEdBQUcsVUFBVSxPQUFPLE9BQU8sUUFBUSxLQUFLLElBQUksT0FBTyxZQUFZLE9BQU8sSUFBSSxJQUFJLEdBQUcsUUFBUSxLQUFLLEtBQUssTUFBTSxRQUFRLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxJQUFJO0FBQ3ZLLFFBQUksT0FBTztBQUFBLEVBQ2I7QUFDQSxNQUFJLGNBQWMsdUJBQXVCLE9BQU8sT0FBTyxJQUFJO0FBQzNELE1BQUksWUFBWTtBQUNoQixXQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0FBQzdCLFVBQU0sUUFBUSxJQUFJLE9BQU8sT0FBTyxZQUFZO0FBQzVDLFVBQU0sT0FBTyxVQUFVLE9BQVMsSUFBSSxLQUFNLEtBQU07QUFDaEQsVUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJO0FBQ3RDLFVBQU0sSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSTtBQUN0QyxRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksRUFBRTtBQUN4QixRQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksRUFBRTtBQUN4QixRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFFTyxnQkFBUyx3QkFBd0IsS0FBK0IsUUFBcUIsT0FBYyxNQUFjO0FBQ3RILFFBQU0sU0FBUyxPQUFPLFVBQVU7QUFDaEMsUUFBTSxRQUFRLElBQUk7QUFDbEIsTUFBSSxLQUFLO0FBQ1QsTUFBSSxVQUFVO0FBQ2QsTUFBSSxjQUFjO0FBQ2xCLE1BQUksYUFBYTtBQUNqQixNQUFJLFlBQVksc0JBQXNCLFFBQVEsT0FBTyxLQUFLO0FBQzFELE1BQUksY0FBYyxzQkFBc0IsT0FBTyxPQUFPLElBQUk7QUFDMUQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLElBQUksUUFBUSxTQUFTLE1BQU0sR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzNFLE1BQUksS0FBSztBQUNULE1BQUksT0FBTztBQUNYLE1BQUksY0FBYyx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDM0QsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLElBQUksVUFBVSxPQUFPLFFBQVEsT0FBTyxVQUFVLE1BQU0sUUFBUSxPQUFPLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUNuSCxNQUFJLE9BQU87QUFDWCxXQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0FBQzdCLFVBQU0sUUFBUSxLQUFLLEtBQUssS0FBSyxLQUFLLFFBQVE7QUFDMUMsVUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVM7QUFDL0MsVUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsTUFBTTtBQUNyRCxRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDbkIsUUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdkIsUUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdkIsUUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdkIsUUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdkIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLE1BQUksUUFBUTtBQUNkO0FBRU8sZ0JBQVMsMEJBQTBCLEtBQStCLE9BQWMsTUFBYztBQUNuRyxRQUFNLFFBQVEsSUFBSTtBQUNsQixNQUFJLEtBQUs7QUFDVCxNQUFJLFVBQVU7QUFDZCxNQUFJLGNBQWM7QUFDbEIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksY0FBYyxzQkFBc0IsT0FBTyxPQUFPLElBQUk7QUFDMUQsTUFBSSxZQUFZO0FBQ2hCLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDOUIsVUFBTSxRQUFRLEtBQUssS0FBSyxLQUFLO0FBQzdCLFVBQU0sUUFBUSxJQUFJLFFBQVE7QUFDMUIsVUFBTSxRQUFRLEtBQUssUUFBUTtBQUMzQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLO0FBQy9FLFFBQUksT0FBTyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUs7QUFDL0UsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLE1BQUksWUFBWSx1QkFBdUIsT0FBTyxPQUFPLElBQUk7QUFDekQsTUFBSSxVQUFVO0FBQ2QsTUFBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUNoQyxNQUFJLE9BQU8sTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbkMsTUFBSSxPQUFPLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQztBQUNoQyxNQUFJLE9BQU8sTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbkMsTUFBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUNoQyxNQUFJLE9BQU8sTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbkMsTUFBSSxPQUFPLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQztBQUNoQyxNQUFJLE9BQU8sTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsTUFBSSxLQUFLO0FBQ1QsTUFBSSxRQUFRO0FBQ2Q7QUFJQSxNQUFNLGdCQUF3RjtBQUFBLEVBQzVGLEVBQUUsSUFBSSxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksT0FBTyxFQUFFO0FBQUEsRUFDekMsRUFBRSxJQUFJLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxPQUFPLEVBQUU7QUFBQSxFQUN6QyxFQUFFLElBQUksR0FBRyxNQUFNLElBQUksUUFBUSxJQUFJLE9BQU8sRUFBRTtBQUFBLEVBQ3hDLEVBQUUsSUFBSSxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksT0FBTyxFQUFFO0FBQUEsRUFDekMsRUFBRSxJQUFJLEdBQUcsTUFBTSxHQUFHLFFBQVEsSUFBSSxPQUFPLEVBQUU7QUFDekM7QUFFTyxnQkFBUyxvQkFBb0IsS0FBK0IsT0FBYyxNQUFjLE1BQWM7QUFDM0csUUFBTSxRQUFRLElBQUk7QUFDbEIsUUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLE9BQU8sR0FBRztBQUN2QyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUSxDQUFDO0FBQ2xDLE1BQUksS0FBSztBQUNULE1BQUksWUFBWSxvQkFBb0IsT0FBTyxJQUFJO0FBQy9DLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLElBQUksSUFBSSxLQUFLLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUM3RCxNQUFJLEtBQUs7QUFDVCxRQUFNLE9BQU8sSUFBSSxxQkFBcUIsTUFBTSxHQUFHLE1BQU0sSUFBSSxHQUFHLEdBQUcsTUFBTSxHQUFHLE1BQU0sSUFBSSxHQUFHLEVBQUU7QUFDdkYsT0FBSyxhQUFhLEdBQUcsc0JBQXNCLE9BQU8sUUFBUSxHQUFHO0FBQzdELE9BQUssYUFBYSxHQUFHLHVCQUF1QjtBQUM1QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDaEQsTUFBSSxLQUFLO0FBQ1QsZ0JBQWMsUUFBUSxDQUFDLFFBQVEsVUFBVTtBQUN2QyxVQUFNLFVBQVUsT0FBTyxPQUFPLEtBQUssSUFBSSxPQUFPLE1BQU0sUUFBUSxHQUFHO0FBQy9ELG9CQUFnQixLQUFLLE1BQU0sSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLE9BQU8sTUFBTSxPQUFPLFNBQVMsT0FBTyxTQUFTLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTyxNQUFNLEtBQUssSUFBSSxHQUFHLFdBQVcsSUFBSTtBQUFBLEVBQ2xLLENBQUM7QUFDRCxhQUFXLEtBQUssT0FBTyxPQUFPLE1BQU0sR0FBRyxRQUFRO0FBQy9DLE1BQUksUUFBUTtBQUNkO0FBR08sZ0JBQVMsdUJBQXVCLEtBQStCLE9BQWMsUUFBZ0IsS0FBYSxnQkFBd0I7QUFDdkksUUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGlCQUFpQixRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQzVELFFBQU0sT0FBTyxNQUFNO0FBQ25CLFFBQU0sU0FBUyxTQUFTO0FBQ3hCLE1BQUksS0FBSztBQUNULGtCQUFnQixLQUFLLE1BQU0sSUFBSSxRQUFRLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLE9BQU8sR0FBRyxJQUFJLEdBQUcsR0FBRyxLQUFLLElBQUksT0FBTyxHQUFHLElBQUksS0FBSyxRQUFRO0FBQ3pILGtCQUFnQixLQUFLLE1BQU0sSUFBSSxTQUFTLEtBQUssTUFBTSxJQUFJLEdBQUcsS0FBSyxLQUFLLElBQUksT0FBTyxNQUFNLENBQUMsSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJLE9BQU8sT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRO0FBQzNJLGFBQVcsS0FBSyxFQUFFLEdBQUcsTUFBTSxHQUFHLEdBQUcsTUFBTSxJQUFJLEVBQUUsR0FBSSxPQUFPLEtBQU0sR0FBRyxNQUFNLEdBQUcsUUFBUTtBQUNsRixNQUFJLFFBQVE7QUFDZDtBQUVBLFNBQVMsZ0JBQWdCLEtBQStCLEdBQVcsT0FBZSxRQUFnQixPQUFlLE1BQWMsT0FBZTtBQUM1SSxNQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUc7QUFDOUIsUUFBTSxPQUFPLElBQUk7QUFDakIsUUFBTSxPQUFPLFFBQVE7QUFDckIsUUFBTSxXQUFXLElBQUkscUJBQXFCLEdBQUcsT0FBTyxHQUFHLElBQUk7QUFDM0QsV0FBUyxhQUFhLEdBQUcscUJBQXFCLEtBQUssR0FBRztBQUN0RCxXQUFTLGFBQWEsTUFBTSxzQkFBc0IsS0FBSyxHQUFHO0FBQzFELFdBQVMsYUFBYSxHQUFHLHVCQUF1QixRQUFRLElBQUksR0FBRztBQUMvRCxNQUFJLFlBQVk7QUFDaEIsa0JBQWdCLEtBQUssR0FBRyxPQUFPLE1BQU0sTUFBTSxPQUFPLE1BQU07QUFDeEQsTUFBSSxLQUFLO0FBQ1QsTUFBSSxZQUFZLHVCQUF1QixRQUFRLEdBQUc7QUFDbEQsa0JBQWdCLEtBQUssSUFBSSxPQUFPLEtBQUssT0FBTyxJQUFJLE9BQU8sS0FBSyxRQUFRLFNBQVMsS0FBSyxRQUFRLE1BQU0sU0FBUyxHQUFHO0FBQzVHLE1BQUksS0FBSztBQUNYO0FBRUEsU0FBUyxnQkFBZ0IsS0FBK0IsR0FBVyxPQUFlLE1BQWMsTUFBYyxPQUFlLFFBQWdCO0FBQzNJLE1BQUksVUFBVTtBQUNkLE1BQUksT0FBTyxJQUFJLFFBQVEsR0FBRyxLQUFLO0FBQy9CLE1BQUksY0FBYyxJQUFJLFFBQVEsS0FBSyxRQUFRLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLFNBQVMsTUFBTSxNQUFNLElBQUk7QUFDL0csTUFBSSxjQUFjLE9BQU8sUUFBUSxLQUFLLE9BQU8sU0FBUyxLQUFLLElBQUksUUFBUSxLQUFLLFFBQVEsU0FBUyxLQUFLLElBQUksUUFBUSxHQUFHLEtBQUs7QUFDdEgsTUFBSSxpQkFBaUIsR0FBRyxRQUFRLFFBQVEsTUFBTSxJQUFJLFFBQVEsR0FBRyxLQUFLO0FBQ2xFLE1BQUksVUFBVTtBQUNoQjtBQUVBLFNBQVMsV0FBVyxLQUErQixPQUFjLE9BQWUsTUFBYyxPQUFlLFVBQWtCO0FBQzdILFdBQVMsUUFBUSxHQUFHLFFBQVEsT0FBTyxTQUFTLEdBQUc7QUFDN0MsVUFBTSxLQUFLLFFBQVEsUUFBUSxRQUFRO0FBQ25DLFVBQU0sSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJLFFBQVEsTUFBTSxPQUFPLElBQUksS0FBSyxJQUFJLFFBQVE7QUFDdkUsVUFBTSxJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUk7QUFDNUIsUUFBSSxZQUFZLGFBQWEsTUFBTSxRQUFRLEVBQUUsVUFBVSxJQUFJLEtBQUssTUFBTSxRQUFRO0FBQzlFLFFBQUksVUFBVTtBQUNkLFFBQUksSUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQ2pDLFFBQUksS0FBSztBQUFBLEVBQ1g7QUFDRjtBQUVBLFNBQVMsZUFBZSxLQUErQixRQUFpQjtBQUN0RSxNQUFJLFVBQVU7QUFDZCxTQUFPLFFBQVEsQ0FBQyxPQUFPLFVBQVU7QUFDL0IsUUFBSSxVQUFVLEVBQUcsS0FBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFBQSxRQUN2QyxLQUFJLE9BQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQztBQUFBLEVBQ2xDLENBQUM7QUFDRCxNQUFJLE9BQU87QUFDYjtBQUVPLGdCQUFTLG9CQUFvQixLQUErQixNQUFhLElBQVcsVUFBa0IsTUFBNEM7QUFDdkosUUFBTSxRQUFRLFdBQVcsTUFBTSxJQUFJLFVBQVUsU0FBUyxVQUFVLE9BQU8sSUFBSTtBQUMzRSxNQUFJLEtBQUs7QUFBRyxNQUFJLFVBQVUsTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFBRyxNQUFJLE9BQU8sTUFBTSxLQUFLO0FBQzNFLE1BQUksU0FBUyxRQUFRO0FBQ25CLFVBQU0sT0FBTyxJQUFJLHFCQUFxQixJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTtBQUN6RCxTQUFLLGFBQWEsR0FBRyxXQUFXO0FBQUcsU0FBSyxhQUFhLEdBQUcsV0FBVztBQUNuRSxRQUFJLFlBQVk7QUFBTSxRQUFJLFNBQVMsS0FBSSxLQUFJLElBQUcsRUFBRTtBQUNoRCxRQUFJLFlBQVk7QUFBVyxRQUFJLFVBQVU7QUFBRyxRQUFJLE9BQU8sR0FBRSxDQUFDO0FBQUcsUUFBSSxpQkFBaUIsSUFBRyxJQUFHLEtBQUksRUFBRTtBQUFHLFFBQUksT0FBTyxLQUFJLENBQUM7QUFBRyxRQUFJLE9BQU8sS0FBSSxDQUFDO0FBQUcsUUFBSSxpQkFBaUIsSUFBRyxHQUFFLEdBQUUsQ0FBQztBQUFHLFFBQUksS0FBSztBQUNoTCxRQUFJLFlBQVk7QUFBVyxRQUFJLFVBQVU7QUFBRyxRQUFJLFFBQVEsR0FBRSxHQUFFLEdBQUUsS0FBSSxHQUFFLEdBQUUsS0FBSyxLQUFHLENBQUM7QUFBRyxRQUFJLEtBQUs7QUFBQSxFQUM3RixXQUFXLFNBQVMsU0FBUztBQUMzQixRQUFJLGNBQVk7QUFBVyxRQUFJLFlBQVU7QUFBSyxRQUFJLFVBQVU7QUFBRyxRQUFJLE9BQU8sS0FBSSxDQUFDO0FBQUcsUUFBSSxPQUFPLElBQUcsQ0FBQztBQUFHLFFBQUksT0FBTztBQUMvRyxRQUFJLFlBQVU7QUFBVyxRQUFJLGNBQVk7QUFBVyxRQUFJLFlBQVU7QUFBSSxRQUFJLFVBQVU7QUFBRyxRQUFJLE9BQU8sR0FBRSxDQUFDO0FBQUcsUUFBSSxPQUFPLElBQUcsSUFBSTtBQUFHLFFBQUksT0FBTyxJQUFHLEdBQUc7QUFBRyxRQUFJLFVBQVU7QUFBRyxRQUFJLEtBQUs7QUFBRyxRQUFJLE9BQU87QUFBQSxFQUMzTCxPQUFPO0FBQ0wsUUFBSSxZQUFZLFNBQVMsVUFBVSxZQUFZO0FBQVcsUUFBSSxjQUFZO0FBQVcsUUFBSSxZQUFVO0FBQ25HLFFBQUksVUFBVTtBQUFHLFFBQUksUUFBUSxHQUFFLEdBQUUsU0FBUyxVQUFVLE1BQU0sS0FBSSxLQUFJLEdBQUUsR0FBRSxLQUFLLEtBQUcsQ0FBQztBQUFHLFFBQUksS0FBSztBQUFHLFFBQUksT0FBTztBQUN6RyxRQUFJLGNBQVk7QUFBYSxRQUFJLFVBQVU7QUFBRyxRQUFJLE9BQU8sSUFBRyxFQUFFO0FBQUcsUUFBSSxPQUFPLEdBQUUsRUFBRTtBQUFHLFFBQUksT0FBTztBQUFBLEVBQ2hHO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFFTyxnQkFBUyxVQUFVLEtBQStCLE9BQW1CO0FBQzFFLFFBQU0sRUFBRSxLQUFLLE1BQU0sT0FBTyxPQUFPLElBQUk7QUFDckMsUUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLO0FBQ3pCLFFBQU0sS0FBSyxLQUFLLElBQUksS0FBSztBQUN6QixRQUFNLEtBQUssQ0FBQztBQUNaLFFBQU0sS0FBSztBQUNYLFFBQU0sYUFBYSxTQUFTO0FBQzVCLFFBQU0sV0FBVyxTQUFTO0FBQzFCLFFBQU0sT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLEtBQUssWUFBWSxHQUFHLElBQUksSUFBSSxLQUFLLFdBQVc7QUFDdEUsTUFBSSxLQUFLO0FBQ1QsTUFBSSxVQUFVO0FBQ2QsTUFBSSxXQUFXO0FBQ2YsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sS0FBSyxJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVMsR0FBRztBQUNqRSxNQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QixNQUFJLE9BQU87QUFFWCxNQUFJLGNBQWM7QUFDbEIsTUFBSSxZQUFZLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUMzQyxNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QixNQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QixNQUFJLE9BQU87QUFFWCxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksQ0FBQztBQUN2QixNQUFJLE9BQU8sS0FBSyxJQUFJLEtBQUssVUFBVSxLQUFLLElBQUksS0FBSyxRQUFRO0FBQ3pELE1BQUksT0FBTyxLQUFLLElBQUksS0FBSyxhQUFhLE1BQU0sS0FBSyxJQUFJLEtBQUssYUFBYSxJQUFJO0FBQzNFLE1BQUksT0FBTyxLQUFLLElBQUksS0FBSyxVQUFVLEtBQUssSUFBSSxLQUFLLFFBQVE7QUFDekQsTUFBSSxVQUFVO0FBQ2QsTUFBSSxLQUFLO0FBQ1QsTUFBSSxPQUFPO0FBRVgsUUFBTSxPQUFPLFNBQVM7QUFDdEIsUUFBTSxTQUFTLFNBQVM7QUFDeEIsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYztBQUNsQixhQUFXLFFBQVEsQ0FBQyxHQUFHLEVBQUUsR0FBRztBQUMxQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxJQUFJO0FBQ2pELFFBQUksT0FBTyxLQUFLLElBQUksS0FBSyxTQUFTLE9BQU8sS0FBSyxPQUFPLE1BQU0sS0FBSyxJQUFJLEtBQUssU0FBUyxPQUFPLEtBQUssT0FBTyxJQUFJO0FBQ3pHLFFBQUksT0FBTyxLQUFLLElBQUksS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLEdBQUc7QUFDekYsUUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxLQUFLO0FBQ1QsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLE1BQUksUUFBUTtBQUNkO0FBSU8sZ0JBQVMsYUFBYSxLQUErQixNQUFhLElBQVcsVUFBa0IsU0FBMEI7QUFDOUgsUUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLO0FBQ3ZCLFFBQU0sS0FBSyxHQUFHLElBQUksS0FBSztBQUN2QixRQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksRUFBRSxDQUFDO0FBQzdDLFFBQU0sS0FBSyxLQUFLO0FBQ2hCLFFBQU0sS0FBSyxLQUFLO0FBQ2hCLFFBQU0sTUFBTSxLQUFLLElBQUksV0FBVyxLQUFLLEtBQUssQ0FBQyxJQUFJO0FBQy9DLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxJQUFJLEtBQUssV0FBVyxLQUFLLEtBQUssR0FBRyxLQUFLLElBQUksS0FBSyxXQUFXLEtBQUssSUFBSTtBQUMxRixRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsV0FBVyxJQUFJLElBQUksWUFBWSxJQUFJLElBQUk7QUFDaEUsTUFBSSxLQUFLO0FBQ1QsV0FBUyxRQUFRLEdBQUcsU0FBUyxHQUFHLFNBQVMsR0FBRztBQUMxQyxRQUFJLFlBQVksS0FBSyxRQUFRLE9BQU8sTUFBTSxRQUFRLFFBQVEsSUFBSTtBQUM5RCxRQUFJLFVBQVU7QUFDZCxRQUFJLElBQUksS0FBSyxJQUFJLEtBQUssUUFBUSxHQUFHLEtBQUssSUFBSSxLQUFLLFFBQVEsR0FBRyxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzNGLFFBQUksS0FBSztBQUFBLEVBQ1g7QUFDQSxRQUFNLE9BQU8sSUFBSSxxQkFBcUIsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQztBQUMxRSxPQUFLLGFBQWEsR0FBRyxLQUFLLFFBQVEsTUFBTSxPQUFPLElBQUksQ0FBQztBQUNwRCxPQUFLLGFBQWEsR0FBRyxLQUFLLFFBQVEsTUFBTSxDQUFDLENBQUM7QUFDMUMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN6QyxNQUFJLEtBQUs7QUFDVCxNQUFJLFlBQVksS0FBSyxRQUFRLE1BQU0sT0FBTyxJQUFJO0FBQzlDLE1BQUksY0FBYyxLQUFLLFFBQVEsTUFBTSxNQUFNLElBQUk7QUFDL0MsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEtBQUssQ0FBQztBQUMzQyxNQUFJLEtBQUs7QUFDVCxNQUFJLE9BQU87QUFDWCxNQUFJLFFBQVE7QUFDZDtBQUdPLGdCQUFTLG9CQUFvQixLQUErQixNQUFhLElBQVcsTUFBYSxVQUFrQixNQUFjO0FBQ3RJLFFBQU0sS0FBSyxHQUFHLElBQUksS0FBSztBQUN2QixRQUFNLEtBQUssR0FBRyxJQUFJLEtBQUs7QUFDdkIsUUFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLEVBQUUsQ0FBQztBQUM3QyxRQUFNLEtBQUssS0FBSztBQUNoQixRQUFNLEtBQUssS0FBSztBQUNoQixRQUFNLGNBQWMsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksU0FBUyxJQUFJLENBQUM7QUFDNUQsUUFBTSxPQUFPO0FBQUEsSUFDWCxHQUFHLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDakIsR0FBRyxLQUFLLElBQUksS0FBSztBQUFBLEVBQ25CO0FBQ0EsUUFBTSxhQUFhLEtBQUssSUFBSSxXQUFXLEtBQUssRUFBRTtBQUM5QyxRQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxhQUFhLE9BQU8sT0FBTyxJQUFJLENBQUM7QUFDbkYsUUFBTSxPQUFPLEVBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUk7QUFDcEMsUUFBTSxRQUFRLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxRQUFRO0FBQ2xGLFFBQU0sTUFBTSxPQUFPLEVBQUUsR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxJQUFJLEdBQUcsV0FBVyxJQUFJLENBQUM7QUFDckcsUUFBTSxXQUFXLElBQUkscUJBQXFCLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN4RSxXQUFTLGFBQWEsR0FBRyxLQUFLLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLFdBQVMsYUFBYSxNQUFNLEtBQUssTUFBTSxRQUFRLElBQUksQ0FBQztBQUNwRCxXQUFTLGFBQWEsTUFBTSxLQUFLLE9BQU8sUUFBUSxJQUFJLENBQUM7QUFDckQsV0FBUyxhQUFhLEdBQUcsS0FBSyxLQUFLLEtBQUssQ0FBQztBQUV6QyxNQUFJLEtBQUs7QUFDVCxNQUFJLFVBQVU7QUFDZCxNQUFJLFdBQVc7QUFDZixNQUFJLGNBQWMsS0FBSyxPQUFPLFFBQVEsSUFBSTtBQUMxQyxNQUFJLGFBQWE7QUFDakIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QixNQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QixNQUFJLE9BQU87QUFFWCxNQUFJLGFBQWE7QUFDakIsTUFBSSxjQUFjLEtBQUssRUFBRSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLFFBQVEsSUFBSTtBQUMvRCxNQUFJLFlBQVk7QUFDaEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxPQUFPLEtBQUssSUFBSSxLQUFLLGNBQWMsTUFBTSxLQUFLLElBQUksS0FBSyxjQUFjLElBQUk7QUFDN0UsTUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekIsTUFBSSxPQUFPO0FBRVgsTUFBSSxZQUFZLEtBQUssS0FBSyxLQUFLO0FBQy9CLE1BQUksY0FBYyxLQUFLLEVBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxRQUFRLElBQUk7QUFDNUQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssS0FBSyxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN4RSxNQUFJLEtBQUs7QUFDVCxNQUFJLE9BQU87QUFDWCxNQUFJLFFBQVE7QUFDZDtBQUVBLE1BQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHO0FBQ3JDLE1BQU0sWUFBWSxFQUFFLEdBQUcsS0FBSyxHQUFHLElBQUksR0FBRyxHQUFHO0FBQ3pDLE1BQU0sTUFBTSxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxHQUFHO0FBQ2xDLE1BQU0sWUFBWSxFQUFFLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJO0FBQzNDLE1BQU0sUUFBUSxFQUFFLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHO0FBRS9CLGdCQUFTLGdCQUFnQixLQUErQixPQUF5QjtBQUN0RixNQUFJLEtBQUs7QUFFVCxXQUFTLFFBQVEsTUFBTSxNQUFNLFNBQVMsR0FBRyxTQUFTLEdBQUcsU0FBUztBQUM1RCxVQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUs7QUFDOUIsUUFBSSxZQUFZLEtBQUssTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUM1QyxRQUFJLGNBQWMsS0FBSyxXQUFXLEtBQUssS0FBSztBQUM1QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxRQUFRLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDL0QsUUFBSSxLQUFLO0FBQ1QsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLE1BQUksVUFBVTtBQUNkLFdBQVMsUUFBUSxHQUFHLFFBQVEsS0FBSyxJQUFJLEdBQUcsTUFBTSxRQUFRLE1BQU0sR0FBRyxTQUFTO0FBQ3RFLFVBQU0sU0FBUyxNQUFNLFFBQVEsS0FBSztBQUNsQyxVQUFNLFdBQVcsSUFBSSxxQkFBcUIsT0FBTyxLQUFLLEdBQUcsT0FBTyxLQUFLLEdBQUcsT0FBTyxHQUFHLEdBQUcsT0FBTyxHQUFHLENBQUM7QUFDaEcsYUFBUyxhQUFhLEdBQUcsS0FBSyxLQUFLLE9BQU8sUUFBUSxHQUFFLENBQUM7QUFDckQsYUFBUyxhQUFhLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFJLGNBQWM7QUFDbEIsUUFBSSxZQUFZLE9BQU87QUFDdkIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxPQUFPLE9BQU8sS0FBSyxHQUFHLE9BQU8sS0FBSyxDQUFDO0FBQ3ZDLFFBQUksT0FBTyxPQUFPLEdBQUcsR0FBRyxPQUFPLEdBQUcsQ0FBQztBQUNuQyxRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFFTyxnQkFBUyxpQkFBaUIsS0FBK0IsT0FBMEI7QUFDeEYsUUFBTSxFQUFFLEtBQUssSUFBSTtBQUNqQixNQUFJLEtBQUs7QUFDVCxNQUFJLFVBQVU7QUFDZCxNQUFJLFlBQVksS0FBSyxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQzVDLE1BQUksY0FBYyxLQUFLLFdBQVcsS0FBSyxRQUFRLEdBQUc7QUFDbEQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQy9ELE1BQUksS0FBSztBQUNULE1BQUksT0FBTztBQUNYLGFBQVcsUUFBUSxNQUFNLE9BQU87QUFDOUIsUUFBSSxZQUFZLEtBQUssTUFBTSxLQUFLLFFBQVEsR0FBRztBQUMzQyxRQUFJLGNBQWMsS0FBSyxXQUFXLEtBQUssS0FBSztBQUM1QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDOUMsUUFBSSxLQUFLO0FBQ1QsUUFBSSxPQUFPO0FBQUEsRUFDYjtBQUNBLFdBQVMsUUFBUSxHQUFHLFFBQVEsS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLE1BQU0sR0FBRyxTQUFTO0FBQ25FLFVBQU0sTUFBTSxNQUFNLEtBQUssS0FBSztBQUM1QixRQUFJLGNBQWMsS0FBSyxPQUFPLElBQUksUUFBUSxJQUFJO0FBQzlDLFFBQUksWUFBWTtBQUNoQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUM7QUFDakMsUUFBSSxPQUFPLElBQUksR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDO0FBQzdCLFFBQUksT0FBTztBQUNYLFFBQUksY0FBYyxLQUFLLFdBQVcsSUFBSSxLQUFLO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsV0FBUyxRQUFRLEdBQUcsUUFBUSxLQUFLLElBQUksR0FBRyxNQUFNLE9BQU8sTUFBTSxHQUFHLFNBQVM7QUFDckUsVUFBTSxRQUFRLE1BQU0sT0FBTyxLQUFLO0FBQ2hDLFFBQUksY0FBYyxLQUFLLE9BQU8sTUFBTSxLQUFLO0FBQ3pDLFFBQUksWUFBWTtBQUNoQixRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUcsTUFBTSxLQUFLLENBQUM7QUFDckMsUUFBSSxPQUFPLE1BQU0sR0FBRyxHQUFHLE1BQU0sR0FBRyxDQUFDO0FBQ2pDLFFBQUksT0FBTztBQUNYLFFBQUksWUFBWSxLQUFLLFdBQVcsTUFBTSxLQUFLO0FBQzNDLFFBQUksVUFBVTtBQUNkLFFBQUksSUFBSSxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDbkQsUUFBSSxLQUFLO0FBQUEsRUFDWDtBQUNBLE1BQUksUUFBUTtBQUNkO0FBRUEsU0FBUyxPQUFPLE1BQTJDLElBQXlDLFFBQWdCO0FBQ2xILFFBQU0sVUFBVSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxNQUFNLENBQUM7QUFDL0MsU0FBTztBQUFBLElBQ0wsR0FBRyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEtBQUssT0FBTztBQUFBLElBQ2hELEdBQUcsS0FBSyxNQUFNLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLLE9BQU87QUFBQSxJQUNoRCxHQUFHLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssS0FBSyxPQUFPO0FBQUEsRUFDbEQ7QUFDRjtBQUVBLFNBQVMsS0FBSyxPQUE0QyxPQUFlO0FBQ3ZFLFNBQU8sUUFBUSxNQUFNLENBQUMsS0FBSyxNQUFNLENBQUMsS0FBSyxNQUFNLENBQUMsS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNwRjtBQUdPLGdCQUFTLHFCQUFxQixLQUErQixPQUFjLE1BQWMsUUFBZ0I7QUFDOUcsUUFBTSxVQUFVLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ2pELE1BQUksS0FBSztBQUNULE1BQUksY0FBYyxLQUFLLElBQUksR0FBRyxPQUFPLENBQUM7QUFDdEMsTUFBSSxZQUFZO0FBQ2hCLFdBQVMsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTO0FBQ3RDLFVBQU0sVUFBVSxRQUFRLEtBQUssS0FBSztBQUNsQyxVQUFNLE9BQU8sS0FBSyxJQUFJLFVBQVUsS0FBSyxFQUFFLEtBQUssS0FBTSxRQUFRLElBQUs7QUFDL0QsUUFBSSxVQUFVO0FBQ2QsUUFBSSxRQUFRLE1BQU0sSUFBSSxRQUFRLE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxLQUFLLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUM3RSxRQUFJLFlBQVk7QUFBVyxRQUFJLGNBQWM7QUFBVyxRQUFJLEtBQUs7QUFBRyxRQUFJLE9BQU87QUFDL0UsUUFBSSxVQUFVO0FBQUcsUUFBSSxPQUFPLE1BQU0sSUFBSSxRQUFRLE1BQU0sSUFBSSxLQUFLLElBQUk7QUFBRyxRQUFJLE9BQU8sTUFBTSxJQUFJLFFBQVEsTUFBTSxJQUFJLElBQUksSUFBSTtBQUFHLFFBQUksT0FBTztBQUFBLEVBQ25JO0FBQ0EsTUFBSSxPQUFPO0FBQXdCLE1BQUksWUFBWTtBQUNuRCxNQUFJLFlBQVk7QUFBRyxNQUFJLGNBQWM7QUFBVyxNQUFJLFlBQVk7QUFDaEUsUUFBTSxRQUFRLE1BQU0sSUFBSSxLQUFLLFVBQVU7QUFDdkMsTUFBSSxXQUFXLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLO0FBQUcsTUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLO0FBQ3ZGLE1BQUksUUFBUTtBQUNkOyIsIm5hbWVzIjpbXX0=