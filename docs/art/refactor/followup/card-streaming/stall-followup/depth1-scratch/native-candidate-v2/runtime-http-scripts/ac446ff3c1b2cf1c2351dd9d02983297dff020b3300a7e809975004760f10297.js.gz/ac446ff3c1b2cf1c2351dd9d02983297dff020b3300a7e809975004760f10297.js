import * as THREE from "/.vite-cache/deps/three.js?v=ea283269";
import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { waterField, waterNormalPixels, WATER_NORMAL_SIZE, WATER_SHORE_FADE, WATER_DEPTH_FADE } from "/@fs/tmp/sketch-queue-source-42bd/src/client/water-field.ts";
export const WATER_VERTEX_SHADER = `
varying vec2 waterPosition;
void main() {
  vec4 world = modelMatrix * vec4(position, 1.0);
  waterPosition = world.xz;
  gl_Position = projectionMatrix * viewMatrix * world;
}`;
export const WATER_FRAGMENT_SHADER = `
uniform sampler2D shore;
uniform sampler2D normals;
uniform vec2 worldSize;
uniform float seconds;
varying vec2 waterPosition;
void main() {
  vec2 field = texture2D(shore, waterPosition / worldSize).rg;
  float coverage = smoothstep(${WATER_SHORE_FADE[0]}, ${WATER_SHORE_FADE[1]}, field.r);
  float strength = coverage * smoothstep(${WATER_DEPTH_FADE[0]}, ${WATER_DEPTH_FADE[1]}, field.g);
  if (strength < .001) discard;
  vec2 a = texture2D(normals, waterPosition / 256.0 - seconds * vec2(7.0, 3.0) / 256.0).rg;
  vec2 b = texture2D(normals, waterPosition / 384.0 + seconds * vec2(3.0, -5.0) / 384.0).rg;
  vec2 slope = (a + b - vec2(1.0)) * mix(.35, 1.0, field.g);
  vec3 normal = normalize(vec3(-slope.x, 1.0, -slope.y));
  vec3 view = vec3(0.0, ${Math.cos(SHIP_CAMERA.tilt).toFixed(7)}, ${Math.sin(SHIP_CAMERA.tilt).toFixed(7)});
  vec3 sun = normalize(vec3(-.45, .65, .25));
  float fresnel = .02 + .98 * pow(1.0 - max(0.0, dot(normal, view)), 5.0);
  float shine = pow(max(0.0, dot(normal, normalize(sun + view))), 12.0);
  // Linear RGB of the quiet, cool sky highlight; Three encodes it for display.
  gl_FragColor = vec4(.521, .694, .665, strength * (.004 + .22 * shine + .08 * fresnel));
  #include <colorspace_fragment>
}`;
export class WaterSurface {
  mesh;
  terrain;
  texture;
  normals;
  disposed = false;
  constructor(scene) {
    const material = new THREE.ShaderMaterial({
      vertexShader: WATER_VERTEX_SHADER,
      fragmentShader: WATER_FRAGMENT_SHADER,
      toneMapped: false,
      transparent: true,
      depthWrite: false,
      uniforms: { shore: { value: null }, normals: { value: null }, worldSize: { value: new THREE.Vector2() }, seconds: { value: 0 } }
    });
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), material);
    this.mesh.name = "WaterSurface";
    this.mesh.visible = false;
    this.mesh.raycast = () => {
    };
    scene.add(this.mesh);
  }
  prepare(terrain) {
    if (this.disposed) return;
    if (terrain === this.terrain) return;
    this.texture?.dispose();
    this.texture = void 0;
    this.mesh.material.uniforms.shore.value = null;
    this.terrain = terrain;
    this.mesh.visible = Boolean(terrain && waterField(terrain).hasWater);
    if (!terrain || !this.mesh.visible) return;
    if (!this.normals) {
      this.normals = new THREE.DataTexture(waterNormalPixels(), WATER_NORMAL_SIZE, WATER_NORMAL_SIZE);
      this.normals.minFilter = this.normals.magFilter = THREE.LinearFilter;
      this.normals.wrapS = this.normals.wrapT = THREE.RepeatWrapping;
      this.normals.generateMipmaps = false;
      this.normals.needsUpdate = true;
      this.mesh.material.uniforms.normals.value = this.normals;
    }
    const field = waterField(terrain), pixels = new Uint8Array(terrain.cols * terrain.rows * 4);
    for (let i = 0; i < field.wet.length; i++) {
      pixels[i * 4] = Math.round(field.coverage[i] * 255);
      pixels[i * 4 + 1] = Math.round(field.depth[i] * 255);
      pixels[i * 4 + 3] = 255;
    }
    this.texture = new THREE.DataTexture(pixels, terrain.cols, terrain.rows);
    this.texture.minFilter = this.texture.magFilter = THREE.LinearFilter;
    this.texture.generateMipmaps = false;
    this.texture.needsUpdate = true;
    const width = terrain.cols * terrain.cell, height = terrain.rows * terrain.cell;
    this.mesh.position.set(width / 2, -0.2, height / 2);
    this.mesh.scale.set(width, 1, height);
    this.mesh.material.uniforms.shore.value = this.texture;
    this.mesh.material.uniforms.worldSize.value.set(width, height);
  }
  update(now, reducedMotion = false) {
    if (!this.disposed) this.mesh.material.uniforms.seconds.value = reducedMotion ? 0 : now / 1e3;
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.normals?.dispose();
    this.texture?.dispose();
    this.normals = this.texture = void 0;
    this.terrain = void 0;
    this.mesh.material.uniforms.shore.value = this.mesh.material.uniforms.normals.value = null;
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
    this.mesh.visible = false;
    this.mesh.removeFromParent();
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFRIUkVFIGZyb20gJ3RocmVlJztcbmltcG9ydCB0eXBlIHsgVGVycmFpbiB9IGZyb20gJy4uLy4uL3NoYXJlZC90ZXJyYWluJztcbmltcG9ydCB7IFNISVBfQ0FNRVJBIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHsgd2F0ZXJGaWVsZCwgd2F0ZXJOb3JtYWxQaXhlbHMsIFdBVEVSX05PUk1BTF9TSVpFLCBXQVRFUl9TSE9SRV9GQURFLCBXQVRFUl9ERVBUSF9GQURFIH0gZnJvbSAnLi4vd2F0ZXItZmllbGQnO1xuXG5leHBvcnQgY29uc3QgV0FURVJfVkVSVEVYX1NIQURFUiA9IGBcbnZhcnlpbmcgdmVjMiB3YXRlclBvc2l0aW9uO1xudm9pZCBtYWluKCkge1xuICB2ZWM0IHdvcmxkID0gbW9kZWxNYXRyaXggKiB2ZWM0KHBvc2l0aW9uLCAxLjApO1xuICB3YXRlclBvc2l0aW9uID0gd29ybGQueHo7XG4gIGdsX1Bvc2l0aW9uID0gcHJvamVjdGlvbk1hdHJpeCAqIHZpZXdNYXRyaXggKiB3b3JsZDtcbn1gO1xuXG4vKiogVHJhbnNwYXJlbnQgc3VyZmFjZSBsaWdodCBvdmVyIHRoZSBzaGFyZWQgQ2FudmFzIHNlYWJlZC4gV2F0ZXIgY29sb3VyIGFuZFxuICogY29hc3QgY292ZXJhZ2UgaGF2ZSBvbmUgc291cmNlOyB0aGUgYWN0b3IgcGFzcyBjYW5ub3QgcGFpbnQgYSBzZWNvbmQgb2NlYW4uICovXG5leHBvcnQgY29uc3QgV0FURVJfRlJBR01FTlRfU0hBREVSID0gYFxudW5pZm9ybSBzYW1wbGVyMkQgc2hvcmU7XG51bmlmb3JtIHNhbXBsZXIyRCBub3JtYWxzO1xudW5pZm9ybSB2ZWMyIHdvcmxkU2l6ZTtcbnVuaWZvcm0gZmxvYXQgc2Vjb25kcztcbnZhcnlpbmcgdmVjMiB3YXRlclBvc2l0aW9uO1xudm9pZCBtYWluKCkge1xuICB2ZWMyIGZpZWxkID0gdGV4dHVyZTJEKHNob3JlLCB3YXRlclBvc2l0aW9uIC8gd29ybGRTaXplKS5yZztcbiAgZmxvYXQgY292ZXJhZ2UgPSBzbW9vdGhzdGVwKCR7V0FURVJfU0hPUkVfRkFERVswXX0sICR7V0FURVJfU0hPUkVfRkFERVsxXX0sIGZpZWxkLnIpO1xuICBmbG9hdCBzdHJlbmd0aCA9IGNvdmVyYWdlICogc21vb3Roc3RlcCgke1dBVEVSX0RFUFRIX0ZBREVbMF19LCAke1dBVEVSX0RFUFRIX0ZBREVbMV19LCBmaWVsZC5nKTtcbiAgaWYgKHN0cmVuZ3RoIDwgLjAwMSkgZGlzY2FyZDtcbiAgdmVjMiBhID0gdGV4dHVyZTJEKG5vcm1hbHMsIHdhdGVyUG9zaXRpb24gLyAyNTYuMCAtIHNlY29uZHMgKiB2ZWMyKDcuMCwgMy4wKSAvIDI1Ni4wKS5yZztcbiAgdmVjMiBiID0gdGV4dHVyZTJEKG5vcm1hbHMsIHdhdGVyUG9zaXRpb24gLyAzODQuMCArIHNlY29uZHMgKiB2ZWMyKDMuMCwgLTUuMCkgLyAzODQuMCkucmc7XG4gIHZlYzIgc2xvcGUgPSAoYSArIGIgLSB2ZWMyKDEuMCkpICogbWl4KC4zNSwgMS4wLCBmaWVsZC5nKTtcbiAgdmVjMyBub3JtYWwgPSBub3JtYWxpemUodmVjMygtc2xvcGUueCwgMS4wLCAtc2xvcGUueSkpO1xuICB2ZWMzIHZpZXcgPSB2ZWMzKDAuMCwgJHtNYXRoLmNvcyhTSElQX0NBTUVSQS50aWx0KS50b0ZpeGVkKDcpfSwgJHtNYXRoLnNpbihTSElQX0NBTUVSQS50aWx0KS50b0ZpeGVkKDcpfSk7XG4gIHZlYzMgc3VuID0gbm9ybWFsaXplKHZlYzMoLS40NSwgLjY1LCAuMjUpKTtcbiAgZmxvYXQgZnJlc25lbCA9IC4wMiArIC45OCAqIHBvdygxLjAgLSBtYXgoMC4wLCBkb3Qobm9ybWFsLCB2aWV3KSksIDUuMCk7XG4gIGZsb2F0IHNoaW5lID0gcG93KG1heCgwLjAsIGRvdChub3JtYWwsIG5vcm1hbGl6ZShzdW4gKyB2aWV3KSkpLCAxMi4wKTtcbiAgLy8gTGluZWFyIFJHQiBvZiB0aGUgcXVpZXQsIGNvb2wgc2t5IGhpZ2hsaWdodDsgVGhyZWUgZW5jb2RlcyBpdCBmb3IgZGlzcGxheS5cbiAgZ2xfRnJhZ0NvbG9yID0gdmVjNCguNTIxLCAuNjk0LCAuNjY1LCBzdHJlbmd0aCAqICguMDA0ICsgLjIyICogc2hpbmUgKyAuMDggKiBmcmVzbmVsKSk7XG4gICNpbmNsdWRlIDxjb2xvcnNwYWNlX2ZyYWdtZW50PlxufWA7XG5cbmV4cG9ydCBjbGFzcyBXYXRlclN1cmZhY2Uge1xuICByZWFkb25seSBtZXNoOiBUSFJFRS5NZXNoPFRIUkVFLlBsYW5lR2VvbWV0cnksIFRIUkVFLlNoYWRlck1hdGVyaWFsPjtcbiAgcHJpdmF0ZSB0ZXJyYWluOiBUZXJyYWluIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIHRleHR1cmU6IFRIUkVFLkRhdGFUZXh0dXJlIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIG5vcm1hbHM6IFRIUkVFLkRhdGFUZXh0dXJlIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIGRpc3Bvc2VkID0gZmFsc2U7XG4gIGNvbnN0cnVjdG9yKHNjZW5lOiBUSFJFRS5TY2VuZSkge1xuICAgIGNvbnN0IG1hdGVyaWFsID0gbmV3IFRIUkVFLlNoYWRlck1hdGVyaWFsKHtcbiAgICAgIHZlcnRleFNoYWRlcjogV0FURVJfVkVSVEVYX1NIQURFUiwgZnJhZ21lbnRTaGFkZXI6IFdBVEVSX0ZSQUdNRU5UX1NIQURFUiwgdG9uZU1hcHBlZDogZmFsc2UsIHRyYW5zcGFyZW50OiB0cnVlLCBkZXB0aFdyaXRlOiBmYWxzZSxcbiAgICAgIHVuaWZvcm1zOiB7IHNob3JlOiB7IHZhbHVlOiBudWxsIH0sIG5vcm1hbHM6IHsgdmFsdWU6IG51bGwgfSwgd29ybGRTaXplOiB7IHZhbHVlOiBuZXcgVEhSRUUuVmVjdG9yMigpIH0sIHNlY29uZHM6IHsgdmFsdWU6IDAgfSB9LFxuICAgIH0pO1xuICAgIHRoaXMubWVzaCA9IG5ldyBUSFJFRS5NZXNoKG5ldyBUSFJFRS5QbGFuZUdlb21ldHJ5KDEsIDEpLnJvdGF0ZVgoLU1hdGguUEkgLyAyKSwgbWF0ZXJpYWwpO1xuICAgIHRoaXMubWVzaC5uYW1lID0gJ1dhdGVyU3VyZmFjZSc7IHRoaXMubWVzaC52aXNpYmxlID0gZmFsc2U7XG4gICAgdGhpcy5tZXNoLnJheWNhc3QgPSAoKSA9PiB7fTsgLy8gUHJlc2VudGF0aW9uIHN1cmZhY2UgbXVzdCBuZXZlciBpbnRlcmNlcHQgdW5pdCBzZWxlY3Rpb24uXG4gICAgc2NlbmUuYWRkKHRoaXMubWVzaCk7XG4gIH1cbiAgcHJlcGFyZSh0ZXJyYWluOiBUZXJyYWluIHwgdW5kZWZpbmVkKSB7XG4gICAgaWYgKHRoaXMuZGlzcG9zZWQpIHJldHVybjtcbiAgICBpZiAodGVycmFpbiA9PT0gdGhpcy50ZXJyYWluKSByZXR1cm47XG4gICAgdGhpcy50ZXh0dXJlPy5kaXNwb3NlKCk7IHRoaXMudGV4dHVyZSA9IHVuZGVmaW5lZDtcbiAgICB0aGlzLm1lc2gubWF0ZXJpYWwudW5pZm9ybXMuc2hvcmUhLnZhbHVlID0gbnVsbDsgdGhpcy50ZXJyYWluID0gdGVycmFpbjtcbiAgICB0aGlzLm1lc2gudmlzaWJsZSA9IEJvb2xlYW4odGVycmFpbiAmJiB3YXRlckZpZWxkKHRlcnJhaW4pLmhhc1dhdGVyKTtcbiAgICBpZiAoIXRlcnJhaW4gfHwgIXRoaXMubWVzaC52aXNpYmxlKSByZXR1cm47XG4gICAgaWYgKCF0aGlzLm5vcm1hbHMpIHtcbiAgICAgIHRoaXMubm9ybWFscyA9IG5ldyBUSFJFRS5EYXRhVGV4dHVyZSh3YXRlck5vcm1hbFBpeGVscygpLCBXQVRFUl9OT1JNQUxfU0laRSwgV0FURVJfTk9STUFMX1NJWkUpO1xuICAgICAgdGhpcy5ub3JtYWxzLm1pbkZpbHRlciA9IHRoaXMubm9ybWFscy5tYWdGaWx0ZXIgPSBUSFJFRS5MaW5lYXJGaWx0ZXI7XG4gICAgICB0aGlzLm5vcm1hbHMud3JhcFMgPSB0aGlzLm5vcm1hbHMud3JhcFQgPSBUSFJFRS5SZXBlYXRXcmFwcGluZztcbiAgICAgIHRoaXMubm9ybWFscy5nZW5lcmF0ZU1pcG1hcHMgPSBmYWxzZTsgdGhpcy5ub3JtYWxzLm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgIHRoaXMubWVzaC5tYXRlcmlhbC51bmlmb3Jtcy5ub3JtYWxzIS52YWx1ZSA9IHRoaXMubm9ybWFscztcbiAgICB9XG4gICAgY29uc3QgZmllbGQgPSB3YXRlckZpZWxkKHRlcnJhaW4pLCBwaXhlbHMgPSBuZXcgVWludDhBcnJheSh0ZXJyYWluLmNvbHMgKiB0ZXJyYWluLnJvd3MgKiA0KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZpZWxkLndldC5sZW5ndGg7IGkrKykge1xuICAgICAgcGl4ZWxzW2kgKiA0XSA9IE1hdGgucm91bmQoZmllbGQuY292ZXJhZ2VbaV0hICogMjU1KTtcbiAgICAgIHBpeGVsc1tpICogNCArIDFdID0gTWF0aC5yb3VuZChmaWVsZC5kZXB0aFtpXSEgKiAyNTUpO1xuICAgICAgcGl4ZWxzW2kgKiA0ICsgM10gPSAyNTU7XG4gICAgfVxuICAgIHRoaXMudGV4dHVyZSA9IG5ldyBUSFJFRS5EYXRhVGV4dHVyZShwaXhlbHMsIHRlcnJhaW4uY29scywgdGVycmFpbi5yb3dzKTtcbiAgICB0aGlzLnRleHR1cmUubWluRmlsdGVyID0gdGhpcy50ZXh0dXJlLm1hZ0ZpbHRlciA9IFRIUkVFLkxpbmVhckZpbHRlcjtcbiAgICB0aGlzLnRleHR1cmUuZ2VuZXJhdGVNaXBtYXBzID0gZmFsc2U7IHRoaXMudGV4dHVyZS5uZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgY29uc3Qgd2lkdGggPSB0ZXJyYWluLmNvbHMgKiB0ZXJyYWluLmNlbGwsIGhlaWdodCA9IHRlcnJhaW4ucm93cyAqIHRlcnJhaW4uY2VsbDtcbiAgICB0aGlzLm1lc2gucG9zaXRpb24uc2V0KHdpZHRoIC8gMiwgLS4yLCBoZWlnaHQgLyAyKTsgdGhpcy5tZXNoLnNjYWxlLnNldCh3aWR0aCwgMSwgaGVpZ2h0KTtcbiAgICB0aGlzLm1lc2gubWF0ZXJpYWwudW5pZm9ybXMuc2hvcmUhLnZhbHVlID0gdGhpcy50ZXh0dXJlO1xuICAgIHRoaXMubWVzaC5tYXRlcmlhbC51bmlmb3Jtcy53b3JsZFNpemUhLnZhbHVlLnNldCh3aWR0aCwgaGVpZ2h0KTtcbiAgfVxuICB1cGRhdGUobm93OiBudW1iZXIsIHJlZHVjZWRNb3Rpb24gPSBmYWxzZSkgeyBpZiAoIXRoaXMuZGlzcG9zZWQpIHRoaXMubWVzaC5tYXRlcmlhbC51bmlmb3Jtcy5zZWNvbmRzIS52YWx1ZSA9IHJlZHVjZWRNb3Rpb24gPyAwIDogbm93IC8gMTAwMDsgfVxuICBkaXNwb3NlKCkge1xuICAgIGlmICh0aGlzLmRpc3Bvc2VkKSByZXR1cm47IHRoaXMuZGlzcG9zZWQgPSB0cnVlO1xuICAgIHRoaXMubm9ybWFscz8uZGlzcG9zZSgpOyB0aGlzLnRleHR1cmU/LmRpc3Bvc2UoKTsgdGhpcy5ub3JtYWxzID0gdGhpcy50ZXh0dXJlID0gdW5kZWZpbmVkOyB0aGlzLnRlcnJhaW4gPSB1bmRlZmluZWQ7XG4gICAgdGhpcy5tZXNoLm1hdGVyaWFsLnVuaWZvcm1zLnNob3JlIS52YWx1ZSA9IHRoaXMubWVzaC5tYXRlcmlhbC51bmlmb3Jtcy5ub3JtYWxzIS52YWx1ZSA9IG51bGw7XG4gICAgdGhpcy5tZXNoLmdlb21ldHJ5LmRpc3Bvc2UoKTsgdGhpcy5tZXNoLm1hdGVyaWFsLmRpc3Bvc2UoKTsgdGhpcy5tZXNoLnZpc2libGUgPSBmYWxzZTsgdGhpcy5tZXNoLnJlbW92ZUZyb21QYXJlbnQoKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxZQUFZLFdBQVc7QUFFdkIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxZQUFZLG1CQUFtQixtQkFBbUIsa0JBQWtCLHdCQUF3QjtBQUU5RixhQUFNLHNCQUFzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVU1QixhQUFNLHdCQUF3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUUwsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixDQUFDLENBQUM7QUFBQSwyQ0FDaEMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixDQUFDLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTTVELEtBQUssSUFBSSxZQUFZLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxZQUFZLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU2xHLGFBQU0sYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBLFdBQVc7QUFBQSxFQUNuQixZQUFZLE9BQW9CO0FBQzlCLFVBQU0sV0FBVyxJQUFJLE1BQU0sZUFBZTtBQUFBLE1BQ3hDLGNBQWM7QUFBQSxNQUFxQixnQkFBZ0I7QUFBQSxNQUF1QixZQUFZO0FBQUEsTUFBTyxhQUFhO0FBQUEsTUFBTSxZQUFZO0FBQUEsTUFDNUgsVUFBVSxFQUFFLE9BQU8sRUFBRSxPQUFPLEtBQUssR0FBRyxTQUFTLEVBQUUsT0FBTyxLQUFLLEdBQUcsV0FBVyxFQUFFLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFBRSxHQUFHLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRTtBQUFBLElBQ2pJLENBQUM7QUFDRCxTQUFLLE9BQU8sSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLGNBQWMsR0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLEtBQUssS0FBSyxDQUFDLEdBQUcsUUFBUTtBQUN4RixTQUFLLEtBQUssT0FBTztBQUFnQixTQUFLLEtBQUssVUFBVTtBQUNyRCxTQUFLLEtBQUssVUFBVSxNQUFNO0FBQUEsSUFBQztBQUMzQixVQUFNLElBQUksS0FBSyxJQUFJO0FBQUEsRUFDckI7QUFBQSxFQUNBLFFBQVEsU0FBOEI7QUFDcEMsUUFBSSxLQUFLLFNBQVU7QUFDbkIsUUFBSSxZQUFZLEtBQUssUUFBUztBQUM5QixTQUFLLFNBQVMsUUFBUTtBQUFHLFNBQUssVUFBVTtBQUN4QyxTQUFLLEtBQUssU0FBUyxTQUFTLE1BQU8sUUFBUTtBQUFNLFNBQUssVUFBVTtBQUNoRSxTQUFLLEtBQUssVUFBVSxRQUFRLFdBQVcsV0FBVyxPQUFPLEVBQUUsUUFBUTtBQUNuRSxRQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssS0FBSyxRQUFTO0FBQ3BDLFFBQUksQ0FBQyxLQUFLLFNBQVM7QUFDakIsV0FBSyxVQUFVLElBQUksTUFBTSxZQUFZLGtCQUFrQixHQUFHLG1CQUFtQixpQkFBaUI7QUFDOUYsV0FBSyxRQUFRLFlBQVksS0FBSyxRQUFRLFlBQVksTUFBTTtBQUN4RCxXQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVEsUUFBUSxNQUFNO0FBQ2hELFdBQUssUUFBUSxrQkFBa0I7QUFBTyxXQUFLLFFBQVEsY0FBYztBQUNqRSxXQUFLLEtBQUssU0FBUyxTQUFTLFFBQVMsUUFBUSxLQUFLO0FBQUEsSUFDcEQ7QUFDQSxVQUFNLFFBQVEsV0FBVyxPQUFPLEdBQUcsU0FBUyxJQUFJLFdBQVcsUUFBUSxPQUFPLFFBQVEsT0FBTyxDQUFDO0FBQzFGLGFBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxJQUFJLFFBQVEsS0FBSztBQUN6QyxhQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxNQUFNLFNBQVMsQ0FBQyxJQUFLLEdBQUc7QUFDbkQsYUFBTyxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sQ0FBQyxJQUFLLEdBQUc7QUFDcEQsYUFBTyxJQUFJLElBQUksQ0FBQyxJQUFJO0FBQUEsSUFDdEI7QUFDQSxTQUFLLFVBQVUsSUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLE1BQU0sUUFBUSxJQUFJO0FBQ3ZFLFNBQUssUUFBUSxZQUFZLEtBQUssUUFBUSxZQUFZLE1BQU07QUFDeEQsU0FBSyxRQUFRLGtCQUFrQjtBQUFPLFNBQUssUUFBUSxjQUFjO0FBQ2pFLFVBQU0sUUFBUSxRQUFRLE9BQU8sUUFBUSxNQUFNLFNBQVMsUUFBUSxPQUFPLFFBQVE7QUFDM0UsU0FBSyxLQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUcsTUFBSyxTQUFTLENBQUM7QUFBRyxTQUFLLEtBQUssTUFBTSxJQUFJLE9BQU8sR0FBRyxNQUFNO0FBQ3hGLFNBQUssS0FBSyxTQUFTLFNBQVMsTUFBTyxRQUFRLEtBQUs7QUFDaEQsU0FBSyxLQUFLLFNBQVMsU0FBUyxVQUFXLE1BQU0sSUFBSSxPQUFPLE1BQU07QUFBQSxFQUNoRTtBQUFBLEVBQ0EsT0FBTyxLQUFhLGdCQUFnQixPQUFPO0FBQUUsUUFBSSxDQUFDLEtBQUssU0FBVSxNQUFLLEtBQUssU0FBUyxTQUFTLFFBQVMsUUFBUSxnQkFBZ0IsSUFBSSxNQUFNO0FBQUEsRUFBTTtBQUFBLEVBQzlJLFVBQVU7QUFDUixRQUFJLEtBQUssU0FBVTtBQUFRLFNBQUssV0FBVztBQUMzQyxTQUFLLFNBQVMsUUFBUTtBQUFHLFNBQUssU0FBUyxRQUFRO0FBQUcsU0FBSyxVQUFVLEtBQUssVUFBVTtBQUFXLFNBQUssVUFBVTtBQUMxRyxTQUFLLEtBQUssU0FBUyxTQUFTLE1BQU8sUUFBUSxLQUFLLEtBQUssU0FBUyxTQUFTLFFBQVMsUUFBUTtBQUN4RixTQUFLLEtBQUssU0FBUyxRQUFRO0FBQUcsU0FBSyxLQUFLLFNBQVMsUUFBUTtBQUFHLFNBQUssS0FBSyxVQUFVO0FBQU8sU0FBSyxLQUFLLGlCQUFpQjtBQUFBLEVBQ3BIO0FBQ0Y7IiwibmFtZXMiOltdfQ==