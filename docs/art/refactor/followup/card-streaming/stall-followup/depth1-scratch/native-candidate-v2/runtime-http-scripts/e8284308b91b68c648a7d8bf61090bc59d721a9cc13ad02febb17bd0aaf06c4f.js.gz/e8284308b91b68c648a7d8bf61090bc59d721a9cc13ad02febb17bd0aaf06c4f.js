import { SIM_TICKS_PER_SECOND } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
import { textIn } from "/@fs/tmp/sketch-queue-source-42bd/src/story/stage.ts";
import { drawAtlasProp } from "/@fs/tmp/sketch-queue-source-42bd/src/client/atlas-art.ts";
export const SPEECH_FONT = `"Hannotate SC", "Kaiti SC", "STKaiti", "PingFang SC", "Songti SC", "Microsoft YaHei", sans-serif`;
export const TITLE_FONT = `"Kaiti SC", "STKaiti", "KaiTi", "Songti SC", "Hannotate SC", serif`;
const INK = "#3a3024";
const PAPER = "rgba(255, 250, 236, 0.95)";
const PAPER_EDGE = "#5b4a33";
const GOLD = "#c9962f";
const seconds = (ticks) => ticks / SIM_TICKS_PER_SECOND;
export function drawStoryGround(ctx, view, toScreen, near) {
  for (const marker of view.markers) {
    const at = toScreen(marker);
    if (!near(at, marker.radius + 60)) continue;
    drawMarkerGround(ctx, marker, at, seconds(view.tick - marker.start));
  }
}
function drawMarkerGround(ctx, marker, at, age) {
  ctx.save();
  ctx.lineCap = ctx.lineJoin = "round";
  if (marker.kind === "danger") {
    const pulse = 0.5 + 0.5 * Math.sin(age * 9);
    ctx.fillStyle = `rgba(190, 54, 34, ${0.1 + 0.12 * pulse})`;
    ctx.strokeStyle = "rgba(160, 40, 28, 0.85)";
    ctx.lineWidth = 2.5;
    ctx.setLineDash([10, 6]);
    ctx.beginPath();
    ctx.ellipse(at.x, at.y, marker.radius, marker.radius * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (marker.kind === "quest" || marker.kind === "rally") {
    ctx.strokeStyle = marker.kind === "quest" ? "rgba(185, 134, 27, 0.9)" : "rgba(49, 95, 135, 0.85)";
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 7]);
    ctx.lineDashOffset = -age * 20;
    ctx.beginPath();
    ctx.ellipse(at.x, at.y, marker.radius, marker.radius * 0.5, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (marker.kind === "place") {
    ctx.strokeStyle = "rgba(91, 74, 51, 0.55)";
    ctx.lineWidth = 1.4;
    ctx.setLineDash([3, 6]);
    ctx.beginPath();
    ctx.ellipse(at.x, at.y, marker.radius, marker.radius * 0.5, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (marker.kind === "snare") {
    ctx.strokeStyle = "rgba(78, 110, 52, 0.9)";
    ctx.lineWidth = 2.2;
    for (let index = 0; index < 10; index += 1) {
      const angle = index / 10 * Math.PI * 2 + age * 0.4;
      const x = at.x + Math.cos(angle) * marker.radius;
      const y = at.y + Math.sin(angle) * marker.radius * 0.5;
      ctx.beginPath();
      ctx.moveTo(x, y + 4);
      ctx.quadraticCurveTo(x - 6, y - 8, x + 2, y - 14);
      ctx.stroke();
    }
  } else if (marker.kind === "relic") {
    const glow = ctx.createRadialGradient(at.x, at.y, 2, at.x, at.y, marker.radius);
    glow.addColorStop(0, "rgba(255, 226, 140, 0.55)");
    glow.addColorStop(1, "rgba(255, 226, 140, 0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.ellipse(at.x, at.y, marker.radius, marker.radius * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.strokeStyle = "rgba(150, 45, 35, 0.8)";
    ctx.lineWidth = 2;
    const r = marker.radius;
    ctx.beginPath();
    ctx.ellipse(at.x, at.y, r, r * 0.5, 0, 0, Math.PI * 2);
    ctx.moveTo(at.x - r - 8, at.y);
    ctx.lineTo(at.x - r + 8, at.y);
    ctx.moveTo(at.x + r - 8, at.y);
    ctx.lineTo(at.x + r + 8, at.y);
    ctx.stroke();
  }
  ctx.restore();
}
export function drawStoryProps(ctx, view, toScreen, near, painter, now) {
  for (const prop of [...view.props].sort((a, b) => a.y - b.y)) {
    const at = toScreen(prop);
    if (!near(at, 140 * prop.scale)) continue;
    const paint = painter(prop.kind);
    if (!paint) continue;
    drawAtlasProp(ctx, `${prop.kind}:${prop.state ?? ""}`, (b) => paint(b, prop.state), at, prop.scale, prop.flip);
    if (prop.state === "burning") drawFlames(ctx, at, prop.scale, now + prop.id * 97);
  }
}
function drawFlames(ctx, at, scale, now) {
  ctx.save();
  ctx.lineJoin = "round";
  for (let index = 0; index < 5; index += 1) {
    const x = at.x + (index - 2) * 11 * scale;
    const height = (18 + 10 * Math.sin(now / 90 + index * 1.7)) * scale;
    const base = at.y - 6 * scale;
    ctx.fillStyle = index % 2 ? "rgba(229, 101, 47, 0.85)" : "rgba(244, 200, 110, 0.9)";
    ctx.beginPath();
    ctx.moveTo(x - 6 * scale, base);
    ctx.quadraticCurveTo(x - 4 * scale, base - height * 0.6, x + Math.sin(now / 70 + index) * 3 * scale, base - height);
    ctx.quadraticCurveTo(x + 5 * scale, base - height * 0.5, x + 6 * scale, base);
    ctx.closePath();
    ctx.fill();
  }
  ctx.fillStyle = "rgba(90, 80, 72, 0.18)";
  for (let index = 0; index < 3; index += 1) {
    const rise = (now / 30 + index * 40) % 120 * scale;
    ctx.beginPath();
    ctx.arc(at.x + Math.sin(now / 400 + index) * 12 * scale, at.y - 30 * scale - rise, (8 + rise * 0.12) * scale, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
export function drawStoryAir(painter) {
  const { ctx, view } = painter;
  ctx.save();
  for (const marker of view.markers) drawMarkerSign(painter, marker);
  drawNameplates(painter);
  drawFloaters(painter);
  drawBubbles(painter);
  ctx.restore();
}
function drawMarkerSign(painter, marker) {
  const { ctx } = painter;
  const at = painter.project(marker);
  const age = seconds(painter.view.tick - marker.start);
  if (marker.kind === "quest") {
    const bob = Math.sin(age * 3) * 4;
    const y = at.y - 58 + bob;
    if (!onScreen(painter, { x: at.x, y }, 40)) return drawEdgeArrow(painter, at, GOLD);
    ctx.save();
    ctx.fillStyle = "#f4cf62";
    ctx.strokeStyle = "#7a5512";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(at.x - 6, y - 20);
    ctx.lineTo(at.x + 6, y - 20);
    ctx.lineTo(at.x + 3, y + 2);
    ctx.lineTo(at.x - 3, y + 2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(at.x, y + 10, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  } else if (marker.kind === "relic") {
    if (!onScreen(painter, at, 30)) return;
    ctx.save();
    ctx.strokeStyle = "#b9861b";
    ctx.lineWidth = 1.6;
    for (let index = 0; index < 4; index += 1) {
      const angle = age * 1.3 + index * Math.PI / 2;
      const r = 16 + Math.sin(age * 4 + index) * 5;
      const x = at.x + Math.cos(angle) * r;
      const y = at.y - 18 + Math.sin(angle) * r * 0.5;
      ctx.beginPath();
      ctx.moveTo(x - 4, y);
      ctx.lineTo(x + 4, y);
      ctx.moveTo(x, y - 4);
      ctx.lineTo(x, y + 4);
      ctx.stroke();
    }
    ctx.restore();
  }
  if (marker.label !== void 0 && onScreen(painter, at, 60)) {
    ctx.save();
    ctx.font = `600 13px ${SPEECH_FONT}`;
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(255, 250, 236, 0.9)";
    const text = textIn(marker.label, painter.locale);
    ctx.strokeText(text, at.x, at.y + marker.radius * 0.55 * painter.zoom + 18);
    ctx.fillStyle = marker.kind === "danger" ? "#8e2a1c" : "#5b4214";
    ctx.fillText(text, at.x, at.y + marker.radius * 0.55 * painter.zoom + 18);
    ctx.restore();
  }
}
function drawEdgeArrow(painter, target, color) {
  const { ctx, width, height } = painter;
  const cx = width / 2;
  const cy = height / 2;
  const angle = Math.atan2(target.y - cy, target.x - cx);
  const margin = 34;
  const x = Math.max(margin, Math.min(width - margin, cx + Math.cos(angle) * width));
  const y = Math.max(margin + letterboxHeight(painter), Math.min(height - margin - letterboxHeight(painter), cy + Math.sin(angle) * height));
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.fillStyle = color;
  ctx.strokeStyle = "#5b4214";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(14, 0);
  ctx.lineTo(-8, -10);
  ctx.lineTo(-3, 0);
  ctx.lineTo(-8, 10);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawNameplates(painter) {
  const { ctx, view } = painter;
  for (const [unitId, plate] of Object.entries(view.nameplates)) {
    const unit = painter.unitAt(unitId);
    if (!unit) continue;
    const at = painter.project(unit);
    if (!onScreen(painter, at, 80)) continue;
    const y = at.y + unit.radius * painter.zoom + 14;
    const name = textIn(plate.name, painter.locale);
    const label = plate.level !== void 0 ? `${name}  Lv${plate.level}` : name;
    ctx.save();
    ctx.font = `600 12px ${SPEECH_FONT}`;
    ctx.textAlign = "center";
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = "rgba(255, 250, 236, 0.85)";
    ctx.strokeText(label, at.x, y);
    ctx.fillStyle = plate.color;
    ctx.fillText(label, at.x, y);
    ctx.restore();
  }
}
function drawFloaters(painter) {
  const { ctx, view } = painter;
  for (const floater of view.floaters) {
    const life = (view.tick - floater.start) / Math.max(1, floater.end - floater.start);
    const unit = floater.unitId ? painter.unitAt(floater.unitId) : void 0;
    const base = painter.project(unit ?? floater);
    const at = { x: base.x, y: base.y - 42 - life * 38 };
    if (!onScreen(painter, at, 60)) continue;
    ctx.save();
    ctx.globalAlpha = life < 0.75 ? 1 : Math.max(0, (1 - life) / 0.25);
    ctx.font = `700 ${floater.size}px ${SPEECH_FONT}`;
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(255, 250, 236, 0.92)";
    const text = textIn(floater.text, painter.locale);
    ctx.strokeText(text, at.x, at.y);
    ctx.fillStyle = floater.color;
    ctx.fillText(text, at.x, at.y);
    ctx.restore();
  }
}
function drawBubbles(painter) {
  const { ctx, view } = painter;
  const boxes = [];
  ctx.font = `17px ${SPEECH_FONT}`;
  for (const line of view.lines) {
    const unit = painter.unitAt(line.speakerId);
    if (!unit) continue;
    const head = painter.project(unit);
    const anchor = { x: head.x, y: head.y - (unit.radius * 1.9 + 14) * painter.zoom };
    const text = textIn(line.text, painter.locale);
    const lines = wrap(ctx, text, 290);
    const w = Math.max(90, Math.max(...lines.map((row) => ctx.measureText(row).width)) + 28);
    const h = lines.length * 23 + 30;
    const top = letterboxHeight(painter) + 8;
    const x = clamp(anchor.x - w / 2, 10, painter.width - w - 10);
    const y = clamp(anchor.y - h - 16, top, painter.height - h - letterboxHeight(painter) - 10);
    boxes.push({ line, anchor, x, y, w, h, lines, offscreen: !onScreen(painter, anchor, 0) });
  }
  boxes.sort((a, b) => a.line.start - b.line.start || a.x - b.x);
  for (let index = 1; index < boxes.length; index += 1) {
    const box = boxes[index];
    for (const other of boxes.slice(0, index)) {
      if (box.x < other.x + other.w && other.x < box.x + box.w && box.y < other.y + other.h && other.y < box.y + box.h) other.y = Math.max(letterboxHeight(painter) + 8, box.y - other.h - 6);
    }
  }
  for (const box of boxes) drawBubble(painter, box);
}
function drawBubble(painter, box) {
  const { ctx, view } = painter;
  const { line } = box;
  const age = seconds(view.tick - line.start);
  const left = seconds(line.end - view.tick);
  const pop = Math.min(1, age / 0.18);
  const alpha = Math.min(1, left / 0.3, 0.35 + pop);
  ctx.save();
  ctx.globalAlpha = Math.max(0, alpha);
  const scale = 0.85 + 0.15 * easeOut(pop);
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);
  ctx.translate(-cx, -cy);
  const tail = { x: clamp(box.anchor.x, box.x + 18, box.x + box.w - 18), y: box.y + box.h };
  ctx.lineJoin = ctx.lineCap = "round";
  ctx.fillStyle = line.tone === "think" ? "rgba(247, 247, 240, 0.94)" : PAPER;
  ctx.strokeStyle = PAPER_EDGE;
  ctx.lineWidth = line.tone === "shout" ? 2.6 : 1.7;
  if (line.tone === "whisper") ctx.setLineDash([5, 4]);
  ctx.shadowColor = "rgba(60, 45, 20, 0.22)";
  ctx.shadowBlur = 8;
  ctx.shadowOffsetY = 3;
  ctx.beginPath();
  if (line.tone === "shout") jaggedRect(ctx, box.x, box.y, box.w, box.h);
  else roundRect(ctx, box.x, box.y, box.w, box.h, 12);
  ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.stroke();
  ctx.setLineDash([]);
  if (!box.offscreen) {
    if (line.tone === "think") {
      for (const [share, r] of [[0.35, 5], [0.7, 3.2]]) {
        ctx.beginPath();
        ctx.arc(tail.x + (box.anchor.x - tail.x) * share, tail.y + (box.anchor.y - tail.y) * share, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(tail.x - 9, tail.y - 1);
      ctx.lineTo(box.anchor.x, Math.max(tail.y + 6, box.anchor.y));
      ctx.lineTo(tail.x + 9, tail.y - 1);
      ctx.fill();
      ctx.stroke();
      ctx.fillRect(tail.x - 8, tail.y - 3, 16, 3.5);
    }
  }
  const name = textIn(line.name, painter.locale);
  if (name) {
    ctx.font = `700 13px ${SPEECH_FONT}`;
    const nameWidth = ctx.measureText(name).width + 16;
    ctx.fillStyle = line.color;
    roundRect(ctx, box.x + 10, box.y - 11, nameWidth, 20, 6);
    ctx.fill();
    ctx.fillStyle = "#fffaf0";
    ctx.textBaseline = "middle";
    ctx.fillText(name, box.x + 18, box.y - 0.5);
  }
  ctx.textBaseline = "alphabetic";
  ctx.font = `${line.tone === "shout" ? "700 " : ""}17px ${SPEECH_FONT}`;
  ctx.fillStyle = line.tone === "whisper" || line.tone === "think" ? "#5d5446" : INK;
  const shown = Math.floor(Math.min(1, age / Math.min(1.2, 0.04 * box.lines.join("").length + 0.2)) * box.lines.join("").length + 0.999);
  let budget = shown;
  box.lines.forEach((row, index) => {
    const part = [...row].slice(0, Math.max(0, budget)).join("");
    budget -= [...row].length;
    ctx.fillText(part, box.x + 14, box.y + 28 + index * 23);
  });
  ctx.restore();
}
export function drawStoryScreen(painter) {
  const { ctx } = painter;
  ctx.save();
  drawLetterbox(painter);
  drawObjectives(painter);
  drawParty(painter);
  drawNotices(painter);
  drawFade(painter);
  drawNarration(painter);
  drawChoice(painter);
  drawTitle(painter);
  ctx.restore();
}
function letterboxHeight(painter) {
  const { letterbox, tick } = painter.view;
  const t = Math.min(1, seconds(tick - letterbox.since) / 0.6);
  const share = letterbox.on ? easeOut(t) : 1 - easeOut(t);
  return Math.round(painter.height * 0.085 * Math.max(0, share));
}
function drawLetterbox(painter) {
  const bar2 = letterboxHeight(painter);
  if (bar2 <= 0) return;
  const { ctx, width, height } = painter;
  ctx.fillStyle = "#15120e";
  ctx.fillRect(0, 0, width, bar2);
  ctx.fillRect(0, height - bar2, width, bar2);
}
function drawTitle(painter) {
  const card = painter.view.title;
  if (!card) return;
  const { ctx, width, height, view } = painter;
  const age = seconds(view.tick - card.start);
  const left = seconds(card.end - view.tick);
  const alpha = Math.max(0, Math.min(1, age / 0.8, left / 0.8));
  ctx.save();
  ctx.globalAlpha = alpha;
  const y = height * 0.42;
  const wash = ctx.createLinearGradient(0, y - 90, 0, y + 80);
  wash.addColorStop(0, "rgba(250, 244, 222, 0)");
  wash.addColorStop(0.35, "rgba(250, 244, 222, 0.88)");
  wash.addColorStop(0.7, "rgba(250, 244, 222, 0.88)");
  wash.addColorStop(1, "rgba(250, 244, 222, 0)");
  ctx.fillStyle = wash;
  ctx.fillRect(0, y - 90, width, 170);
  ctx.textAlign = "center";
  ctx.fillStyle = "#2f271c";
  ctx.font = `56px ${TITLE_FONT}`;
  ctx.fillText(textIn(card.text, painter.locale), width / 2, y);
  const span = Math.min(1, age / 1.1) * 260;
  ctx.strokeStyle = "rgba(120, 32, 24, 0.75)";
  ctx.lineWidth = 4;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(width / 2 - span, y + 20);
  ctx.quadraticCurveTo(width / 2, y + 27, width / 2 + span, y + 18);
  ctx.stroke();
  if (card.subtitle !== void 0) {
    ctx.font = `24px ${TITLE_FONT}`;
    ctx.fillStyle = "#5a4a33";
    ctx.fillText(textIn(card.subtitle, painter.locale), width / 2, y + 58);
  }
  ctx.restore();
}
function drawNarration(painter) {
  const card = painter.view.narration;
  if (!card) return;
  const { ctx, width, height, view } = painter;
  const age = seconds(view.tick - card.start);
  const left = seconds(card.end - view.tick);
  ctx.save();
  ctx.globalAlpha = Math.max(0, Math.min(1, age / 0.5, left / 0.5));
  ctx.font = `24px ${TITLE_FONT}`;
  const rows = wrap(ctx, textIn(card.text, painter.locale), width * 0.7);
  const bar2 = letterboxHeight(painter);
  const boxHeight = rows.length * 32 + 22;
  const y = bar2 > 0 ? height - bar2 - boxHeight - 10 : height - boxHeight - 36;
  const wash = ctx.createLinearGradient(width * 0.1, 0, width * 0.9, 0);
  wash.addColorStop(0, "rgba(30, 25, 18, 0)");
  wash.addColorStop(0.2, "rgba(30, 25, 18, 0.62)");
  wash.addColorStop(0.8, "rgba(30, 25, 18, 0.62)");
  wash.addColorStop(1, "rgba(30, 25, 18, 0)");
  ctx.fillStyle = wash;
  ctx.fillRect(width * 0.1, y, width * 0.8, boxHeight);
  ctx.textAlign = "center";
  ctx.fillStyle = "#f6ecd2";
  rows.forEach((row, index) => ctx.fillText(row, width / 2, y + 33 + index * 32));
  ctx.restore();
}
function drawObjectives(painter) {
  const { ctx, view } = painter;
  if (view.objectives.length === 0) return;
  const top = letterboxHeight(painter) + 14;
  const rows = view.objectives.map((objective) => {
    const mark = objective.state === "done" ? "☑" : objective.state === "failed" ? "☒" : "☐";
    const words = textIn(objective.text, painter.locale) + (objective.progress ? `  ${objective.progress}` : "");
    return { objective, text: `${mark} ${objective.optional ? painter.locale === "zh" ? "（支线）" : "(side) " : ""}${words}` };
  });
  ctx.font = `15px ${SPEECH_FONT}`;
  const w = Math.min(430, Math.max(170, ...rows.map((row) => ctx.measureText(row.text).width + 30)));
  const h = rows.length * 24 + 38;
  ctx.fillStyle = "rgba(252, 246, 226, 0.9)";
  ctx.strokeStyle = PAPER_EDGE;
  ctx.lineWidth = 1.4;
  roundRect(ctx, 14, top, w, h, 8);
  ctx.fill();
  ctx.stroke();
  ctx.font = `700 14px ${SPEECH_FONT}`;
  ctx.fillStyle = "#7a2c1e";
  ctx.fillText(painter.locale === "zh" ? "目标" : "Objectives", 26, top + 21);
  ctx.font = `15px ${SPEECH_FONT}`;
  rows.forEach((row, index) => {
    const state = row.objective.state;
    ctx.fillStyle = state === "done" ? "#4f7a45" : state === "failed" ? "#9a3a2a" : row.objective.optional ? "#6c5c44" : INK;
    ctx.fillText(row.text, 24, top + 45 + index * 24);
    if (state !== "active") {
      ctx.strokeStyle = ctx.fillStyle;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(44, top + 40 + index * 24);
      ctx.lineTo(24 + ctx.measureText(row.text).width, top + 40 + index * 24);
      ctx.stroke();
    }
  });
}
function drawNotices(painter) {
  const { ctx, view, width } = painter;
  let y = letterboxHeight(painter) + 18;
  for (const notice of view.notices) {
    const age = seconds(view.tick - notice.start);
    const left = seconds(notice.end - view.tick);
    const text = textIn(notice.text, painter.locale);
    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, age / 0.3, left / 0.6));
    ctx.font = `600 16px ${SPEECH_FONT}`;
    const w = ctx.measureText(text).width + 36;
    const x = width / 2 - w / 2;
    ctx.fillStyle = notice.tone === "warn" ? "rgba(122, 40, 28, 0.88)" : notice.tone === "gain" ? "rgba(58, 92, 48, 0.88)" : notice.tone === "quest" ? "rgba(112, 82, 24, 0.9)" : "rgba(44, 52, 60, 0.85)";
    roundRect(ctx, x, y, w, 30, 15);
    ctx.fill();
    ctx.fillStyle = "#fbf3dc";
    ctx.textAlign = "center";
    ctx.fillText(text, width / 2, y + 21);
    ctx.restore();
    y += 36;
  }
}
function drawChoice(painter) {
  const choice = painter.view.choice;
  if (!choice) return;
  const { ctx, width, height, view } = painter;
  const age = seconds(view.tick - choice.opened);
  ctx.save();
  ctx.globalAlpha = Math.min(1, age / 0.35);
  const prompt = textIn(choice.prompt, painter.locale);
  ctx.font = `20px ${TITLE_FONT}`;
  const promptRows = wrap(ctx, prompt, 560);
  const w = 620;
  const h = promptRows.length * 28 + choice.options.length * 40 + 44;
  const x = width / 2 - w / 2;
  const y = height - letterboxHeight(painter) - h - 24;
  ctx.fillStyle = "rgba(252, 246, 226, 0.96)";
  ctx.strokeStyle = PAPER_EDGE;
  ctx.lineWidth = 2;
  ctx.shadowColor = "rgba(40, 30, 10, 0.3)";
  ctx.shadowBlur = 14;
  roundRect(ctx, x, y, w, h, 10);
  ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.stroke();
  ctx.fillStyle = "#2f271c";
  promptRows.forEach((row, index) => ctx.fillText(row, x + 24, y + 34 + index * 28));
  choice.options.forEach((option, index) => {
    const oy = y + promptRows.length * 28 + 30 + index * 40;
    const picked = choice.picked === option.id;
    const faded = choice.picked !== void 0 && !picked;
    if (picked) {
      const glow = Math.min(1, seconds(view.tick - (choice.pickedAt ?? view.tick)) / 0.25);
      ctx.fillStyle = `rgba(214, 170, 72, ${0.35 + 0.25 * glow})`;
      roundRect(ctx, x + 14, oy - 2, w - 28, 34, 6);
      ctx.fill();
    }
    ctx.globalAlpha = Math.min(1, age / 0.35) * (faded ? 0.4 : 1);
    ctx.font = `600 18px ${SPEECH_FONT}`;
    ctx.fillStyle = "#7a2c1e";
    ctx.fillText(`${index + 1}.`, x + 26, oy + 22);
    ctx.fillStyle = INK;
    ctx.font = `18px ${SPEECH_FONT}`;
    ctx.fillText(textIn(option.text, painter.locale), x + 52, oy + 22);
    ctx.globalAlpha = Math.min(1, age / 0.35);
  });
  ctx.restore();
}
function drawParty(painter) {
  const party = painter.view.party;
  if (!party || party.members.length === 0 || painter.view.letterbox.on) return;
  const { ctx, height } = painter;
  const cardWidth = 196;
  const cardHeight = 70;
  const y = height - cardHeight - 12;
  party.members.forEach((member, index) => {
    const x = 12 + index * (cardWidth + 8);
    ctx.save();
    ctx.fillStyle = "rgba(252, 246, 226, 0.88)";
    ctx.strokeStyle = PAPER_EDGE;
    ctx.lineWidth = 1.2;
    roundRect(ctx, x, y, cardWidth, cardHeight, 7);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = member.color;
    ctx.fillRect(x, y + 7, 4, cardHeight - 14);
    ctx.font = `700 14px ${SPEECH_FONT}`;
    ctx.fillStyle = INK;
    ctx.fillText(textIn(member.name, painter.locale), x + 12, y + 18);
    ctx.font = `600 12px ${SPEECH_FONT}`;
    ctx.fillStyle = "#7a2c1e";
    ctx.textAlign = "right";
    ctx.fillText(`Lv ${member.level}${member.gear.length > 0 ? `  ✦${member.gear.length}` : ""}`, x + cardWidth - 10, y + 18);
    ctx.textAlign = "left";
    bar(ctx, x + 12, y + 25, cardWidth - 24, 6, member.hp / Math.max(1, member.maxHp), member.hp / member.maxHp > 0.4 ? "#7fa86f" : "#c8724f");
    const xpShare = member.xpNext !== void 0 ? (member.xp - member.xpFloor) / Math.max(1, member.xpNext - member.xpFloor) : 1;
    bar(ctx, x + 12, y + 34, cardWidth - 24, 3, xpShare, "#b18cd6");
    ctx.font = `11px ${SPEECH_FONT}`;
    let sx = x + 12;
    for (const skill of member.skills) {
      const name = textIn(skill.name, painter.locale);
      const w = ctx.measureText(name).width + 10;
      if (sx + w > x + cardWidth - 8) break;
      ctx.fillStyle = skill.ready >= 1 ? "rgba(214, 170, 72, 0.9)" : "rgba(160, 150, 130, 0.45)";
      roundRect(ctx, sx, y + 44, w, 16, 5);
      ctx.fill();
      if (skill.ready < 1) {
        ctx.fillStyle = "rgba(214, 170, 72, 0.55)";
        roundRect(ctx, sx, y + 44, Math.max(2, w * skill.ready), 16, 5);
        ctx.fill();
      }
      ctx.fillStyle = INK;
      ctx.fillText(name, sx + 5, y + 56);
      sx += w + 4;
    }
    ctx.restore();
  });
}
function drawFade(painter) {
  const { fade, tick } = painter.view;
  let alpha = fade.to;
  if (tick < fade.end) alpha = tick <= fade.start ? fade.from : fade.from + (fade.to - fade.from) * (tick - fade.start) / Math.max(1, fade.end - fade.start);
  if (alpha <= 1e-3) return;
  painter.ctx.fillStyle = `rgba(12, 10, 8, ${Math.min(1, alpha)})`;
  painter.ctx.fillRect(0, 0, painter.width, painter.height);
}
function bar(ctx, x, y, w, h, share, color) {
  ctx.fillStyle = "rgba(49, 72, 58, 0.55)";
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w * Math.max(0, Math.min(1, share)), h);
}
export function wrap(ctx, text, maxWidth) {
  const rows = [];
  for (const paragraph of text.split("\n")) {
    const tokens = paragraph.match(/[⺀-鿿豈-﫿＀-￯]|[^\s⺀-鿿豈-﫿＀-￯]+|\s+/g) ?? [];
    let row = "";
    for (const token of tokens) {
      const next = row + token;
      if (row && ctx.measureText(next).width > maxWidth && !/^[，。！？、；：」』）,.!?;:]$/.test(token)) {
        rows.push(row.trimEnd());
        row = token.trimStart();
      } else row = next;
    }
    if (row) rows.push(row.trimEnd());
  }
  return rows.length > 0 ? rows : [""];
}
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
function jaggedRect(ctx, x, y, w, h) {
  const points = [];
  const steps = Math.max(8, Math.round((w + h) / 22));
  const edge = (t) => {
    const p = t * 2 * (w + h);
    if (p < w) return { x: x + p, y };
    if (p < w + h) return { x: x + w, y: y + p - w };
    if (p < 2 * w + h) return { x: x + w - (p - w - h), y: y + h };
    return { x, y: y + h - (p - 2 * w - h) };
  };
  for (let index = 0; index < steps * 2; index += 1) {
    const at = edge(index / (steps * 2));
    const out = index % 2 === 0 ? 5 : -1;
    const cx = x + w / 2;
    const cy = y + h / 2;
    const d = Math.hypot(at.x - cx, at.y - cy) || 1;
    points.push({ x: at.x + (at.x - cx) / d * out, y: at.y + (at.y - cy) / d * out });
  }
  ctx.moveTo(points[0].x, points[0].y);
  for (const point of points.slice(1)) ctx.lineTo(point.x, point.y);
  ctx.closePath();
}
function onScreen(painter, point, pad) {
  return point.x >= -pad && point.y >= -pad && point.x <= painter.width + pad && point.y <= painter.height + pad;
}
function clamp(value, min, max) {
  return Math.min(Math.max(min, max), Math.max(min, value));
}
function easeOut(t) {
  return 1 - (1 - t) * (1 - t);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0b3J5LXJlbmRlcmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNJTV9USUNLU19QRVJfU0VDT05EIH0gZnJvbSBcIi4uL3NoYXJlZC90aW1lXCI7XG5pbXBvcnQgeyB0ZXh0SW4sIHR5cGUgTGluZVZpZXcsIHR5cGUgTWFya2VyVmlldywgdHlwZSBTdGFnZVZpZXcgfSBmcm9tIFwiLi4vc3Rvcnkvc3RhZ2VcIjtcbmltcG9ydCB7IGRyYXdBdGxhc1Byb3AgfSBmcm9tIFwiLi9hdGxhcy1hcnRcIjtcblxudHlwZSBCcnVzaCA9IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRDtcbnR5cGUgUG9pbnQgPSB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH07XG50eXBlIExvY2FsZSA9IFwiemhcIiB8IFwiZW5cIjtcblxuLy8gQEBAc3RvcnktcmVuZGVyZXIgLSBIb3cgdGhlIHN0b3J5J3Mgc3RhZ2UgKHN0b3J5L3N0YWdlKSBsb29rczogYnViYmxlcyBvdmVyIHRoZSB1bml0cyB3aG8gc3BlYWssIG5hbWVwbGF0ZXMgdW5kZXIgdGhlXG4vLyBoZXJvZXMsIG1hcmtzIG9uIHRoZSBncm91bmQsIHdvcmRzIGZsb2F0aW5nIHVwLCBhbmQgYWNyb3NzIHRoZSBzY3JlZW4gdGhlIGxldHRlcmJveCwgdGl0bGVzLCBuYXJyYXRpb24sIG9iamVjdGl2ZXMsXG4vLyBub3RpY2VzLCB0aGUgY2hvaWNlIHB1dCB0byB0aGUgcGxheWVyIGFuZCB0aGUgaGVyb2VzJyBwYW5lbC4gRHJhd24gZnJvbSBwbGFpbiBkYXRhIGJ5IHdvcmxkLXJlbmRlcmVyJ3MgZHJhd1dvcmxkLCBzbyBhXG4vLyByZWNvcmRpbmcgc2hvd3MgZXhhY3RseSB3aGF0IHRoZSBicm93c2VyIHNob3dzLiBFdmVyeXRoaW5nIHRoYXQgYW5pbWF0ZXMgaXMgdGltZWQgYnkgdGhlIHN0b3J5J3Mgb3duIGNsb2NrICh0aGVcbi8vIHNuYXBzaG90J3MgdGljayksIHNvIGEgZnJhbWUgaXMgYSBmdW5jdGlvbiBvZiB0aGUgZ2FtZSwgbm90IG9mIHdoZW4gaXQgd2FzIGRyYXduLlxuXG4vLyBIYW5kd3JpdGluZyBmb3Igd2hhdCBjaGFyYWN0ZXJzIHNheSwgYSBicnVzaCBoYW5kIGZvciB0aXRsZXM7IGVhY2ggbGlzdCBmYWxscyBiYWNrIHRvIHdoYXQgdGhlIG1hY2hpbmUgaGFzLlxuZXhwb3J0IGNvbnN0IFNQRUVDSF9GT05UID0gYFwiSGFubm90YXRlIFNDXCIsIFwiS2FpdGkgU0NcIiwgXCJTVEthaXRpXCIsIFwiUGluZ0ZhbmcgU0NcIiwgXCJTb25ndGkgU0NcIiwgXCJNaWNyb3NvZnQgWWFIZWlcIiwgc2Fucy1zZXJpZmA7XG5leHBvcnQgY29uc3QgVElUTEVfRk9OVCA9IGBcIkthaXRpIFNDXCIsIFwiU1RLYWl0aVwiLCBcIkthaVRpXCIsIFwiU29uZ3RpIFNDXCIsIFwiSGFubm90YXRlIFNDXCIsIHNlcmlmYDtcbmNvbnN0IElOSyA9IFwiIzNhMzAyNFwiO1xuY29uc3QgUEFQRVIgPSBcInJnYmEoMjU1LCAyNTAsIDIzNiwgMC45NSlcIjtcbmNvbnN0IFBBUEVSX0VER0UgPSBcIiM1YjRhMzNcIjtcbmNvbnN0IEdPTEQgPSBcIiNjOTk2MmZcIjtcblxuZXhwb3J0IHR5cGUgU3RvcnlQYWludGVyID0ge1xuICBjdHg6IEJydXNoO1xuICB2aWV3OiBTdGFnZVZpZXc7XG4gIGxvY2FsZTogTG9jYWxlO1xuICB3aWR0aDogbnVtYmVyO1xuICBoZWlnaHQ6IG51bWJlcjtcbiAgLy8gV2hlcmUgYSB3b3JsZCBwb2ludCBpcyBvbiB0aGUgc2NyZWVuLCBhbmQgd2hlcmUgYSB1bml0IGlzIGRyYXduIHRoaXMgZnJhbWUuXG4gIHByb2plY3Q6IChwb2ludDogUG9pbnQpID0+IFBvaW50O1xuICB1bml0QXQ6ICh1bml0SWQ6IHN0cmluZykgPT4gKFBvaW50ICYgeyByYWRpdXM6IG51bWJlciB9KSB8IHVuZGVmaW5lZDtcbiAgem9vbTogbnVtYmVyO1xufTtcblxuY29uc3Qgc2Vjb25kcyA9ICh0aWNrczogbnVtYmVyKSA9PiB0aWNrcyAvIFNJTV9USUNLU19QRVJfU0VDT05EO1xuXG4vLyAtLS0tIE9uIHRoZSBncm91bmQgKGRyYXduIGluIHdvcmxkIHNwYWNlLCB1bmRlciB0aGUgdW5pdHMpLlxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1N0b3J5R3JvdW5kKGN0eDogQnJ1c2gsIHZpZXc6IFN0YWdlVmlldywgdG9TY3JlZW46IChwb2ludDogUG9pbnQpID0+IFBvaW50LCBuZWFyOiAocG9pbnQ6IFBvaW50LCBwYWQ6IG51bWJlcikgPT4gYm9vbGVhbikge1xuICBmb3IgKGNvbnN0IG1hcmtlciBvZiB2aWV3Lm1hcmtlcnMpIHtcbiAgICBjb25zdCBhdCA9IHRvU2NyZWVuKG1hcmtlcik7XG4gICAgaWYgKCFuZWFyKGF0LCBtYXJrZXIucmFkaXVzICsgNjApKSBjb250aW51ZTtcbiAgICBkcmF3TWFya2VyR3JvdW5kKGN0eCwgbWFya2VyLCBhdCwgc2Vjb25kcyh2aWV3LnRpY2sgLSBtYXJrZXIuc3RhcnQpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3TWFya2VyR3JvdW5kKGN0eDogQnJ1c2gsIG1hcmtlcjogTWFya2VyVmlldywgYXQ6IFBvaW50LCBhZ2U6IG51bWJlcikge1xuICBjdHguc2F2ZSgpO1xuICBjdHgubGluZUNhcCA9IGN0eC5saW5lSm9pbiA9IFwicm91bmRcIjtcbiAgaWYgKG1hcmtlci5raW5kID09PSBcImRhbmdlclwiKSB7XG4gICAgLy8gQSB0ZWxlZ3JhcGg6IGEgcmVkIHJpbmcgdGhhdCBmaWxscyBhcyB0aGUgYmxvdyBjb21lcy5cbiAgICBjb25zdCBwdWxzZSA9IDAuNSArIDAuNSAqIE1hdGguc2luKGFnZSAqIDkpO1xuICAgIGN0eC5maWxsU3R5bGUgPSBgcmdiYSgxOTAsIDU0LCAzNCwgJHswLjEgKyAwLjEyICogcHVsc2V9KWA7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gXCJyZ2JhKDE2MCwgNDAsIDI4LCAwLjg1KVwiO1xuICAgIGN0eC5saW5lV2lkdGggPSAyLjU7XG4gICAgY3R4LnNldExpbmVEYXNoKFsxMCwgNl0pO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHguZWxsaXBzZShhdC54LCBhdC55LCBtYXJrZXIucmFkaXVzLCBtYXJrZXIucmFkaXVzICogMC41NSwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5maWxsKCk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9IGVsc2UgaWYgKG1hcmtlci5raW5kID09PSBcInF1ZXN0XCIgfHwgbWFya2VyLmtpbmQgPT09IFwicmFsbHlcIikge1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IG1hcmtlci5raW5kID09PSBcInF1ZXN0XCIgPyBcInJnYmEoMTg1LCAxMzQsIDI3LCAwLjkpXCIgOiBcInJnYmEoNDksIDk1LCAxMzUsIDAuODUpXCI7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY3R4LnNldExpbmVEYXNoKFs4LCA3XSk7XG4gICAgY3R4LmxpbmVEYXNoT2Zmc2V0ID0gLWFnZSAqIDIwO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHguZWxsaXBzZShhdC54LCBhdC55LCBtYXJrZXIucmFkaXVzLCBtYXJrZXIucmFkaXVzICogMC41LCAwLCAwLCBNYXRoLlBJICogMik7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9IGVsc2UgaWYgKG1hcmtlci5raW5kID09PSBcInBsYWNlXCIpIHtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBcInJnYmEoOTEsIDc0LCA1MSwgMC41NSlcIjtcbiAgICBjdHgubGluZVdpZHRoID0gMS40O1xuICAgIGN0eC5zZXRMaW5lRGFzaChbMywgNl0pO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHguZWxsaXBzZShhdC54LCBhdC55LCBtYXJrZXIucmFkaXVzLCBtYXJrZXIucmFkaXVzICogMC41LCAwLCAwLCBNYXRoLlBJICogMik7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9IGVsc2UgaWYgKG1hcmtlci5raW5kID09PSBcInNuYXJlXCIpIHtcbiAgICAvLyBUaG9ybnM6IGEgcmluZyBvZiBob29rZWQgc3Ryb2tlcyBjbG9zaW5nIG9uIHdob2V2ZXIgc3RhbmRzIGluc2lkZS5cbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBcInJnYmEoNzgsIDExMCwgNTIsIDAuOSlcIjtcbiAgICBjdHgubGluZVdpZHRoID0gMi4yO1xuICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCAxMDsgaW5kZXggKz0gMSkge1xuICAgICAgY29uc3QgYW5nbGUgPSAoaW5kZXggLyAxMCkgKiBNYXRoLlBJICogMiArIGFnZSAqIDAuNDtcbiAgICAgIGNvbnN0IHggPSBhdC54ICsgTWF0aC5jb3MoYW5nbGUpICogbWFya2VyLnJhZGl1cztcbiAgICAgIGNvbnN0IHkgPSBhdC55ICsgTWF0aC5zaW4oYW5nbGUpICogbWFya2VyLnJhZGl1cyAqIDAuNTtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5tb3ZlVG8oeCwgeSArIDQpO1xuICAgICAgY3R4LnF1YWRyYXRpY0N1cnZlVG8oeCAtIDYsIHkgLSA4LCB4ICsgMiwgeSAtIDE0KTtcbiAgICAgIGN0eC5zdHJva2UoKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAobWFya2VyLmtpbmQgPT09IFwicmVsaWNcIikge1xuICAgIGNvbnN0IGdsb3cgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQoYXQueCwgYXQueSwgMiwgYXQueCwgYXQueSwgbWFya2VyLnJhZGl1cyk7XG4gICAgZ2xvdy5hZGRDb2xvclN0b3AoMCwgXCJyZ2JhKDI1NSwgMjI2LCAxNDAsIDAuNTUpXCIpO1xuICAgIGdsb3cuYWRkQ29sb3JTdG9wKDEsIFwicmdiYSgyNTUsIDIyNiwgMTQwLCAwKVwiKTtcbiAgICBjdHguZmlsbFN0eWxlID0gZ2xvdztcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LmVsbGlwc2UoYXQueCwgYXQueSwgbWFya2VyLnJhZGl1cywgbWFya2VyLnJhZGl1cyAqIDAuNiwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5maWxsKCk7XG4gIH0gZWxzZSB7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gXCJyZ2JhKDE1MCwgNDUsIDM1LCAwLjgpXCI7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY29uc3QgciA9IG1hcmtlci5yYWRpdXM7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5lbGxpcHNlKGF0LngsIGF0LnksIHIsIHIgKiAwLjUsIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHgubW92ZVRvKGF0LnggLSByIC0gOCwgYXQueSk7XG4gICAgY3R4LmxpbmVUbyhhdC54IC0gciArIDgsIGF0LnkpO1xuICAgIGN0eC5tb3ZlVG8oYXQueCArIHIgLSA4LCBhdC55KTtcbiAgICBjdHgubGluZVRvKGF0LnggKyByICsgOCwgYXQueSk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbi8vIC0tLS0gU2NlbmVyeSAod29ybGQgc3BhY2UsIHdpdGggdGhlIGxhbmRtYXJrcykuXG5cbmV4cG9ydCBmdW5jdGlvbiBkcmF3U3RvcnlQcm9wcyhjdHg6IEJydXNoLCB2aWV3OiBTdGFnZVZpZXcsIHRvU2NyZWVuOiAocG9pbnQ6IFBvaW50KSA9PiBQb2ludCwgbmVhcjogKHBvaW50OiBQb2ludCwgcGFkOiBudW1iZXIpID0+IGJvb2xlYW4sIHBhaW50ZXI6IChraW5kOiBzdHJpbmcpID0+ICgoYjogQnJ1c2gsIHN0YXRlOiBzdHJpbmcgfCB1bmRlZmluZWQpID0+IHZvaWQpIHwgdW5kZWZpbmVkLCBub3c6IG51bWJlcikge1xuICBmb3IgKGNvbnN0IHByb3Agb2YgWy4uLnZpZXcucHJvcHNdLnNvcnQoKGEsIGIpID0+IGEueSAtIGIueSkpIHtcbiAgICBjb25zdCBhdCA9IHRvU2NyZWVuKHByb3ApO1xuICAgIGlmICghbmVhcihhdCwgMTQwICogcHJvcC5zY2FsZSkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHBhaW50ID0gcGFpbnRlcihwcm9wLmtpbmQpO1xuICAgIGlmICghcGFpbnQpIGNvbnRpbnVlO1xuICAgIGRyYXdBdGxhc1Byb3AoY3R4LCBgJHtwcm9wLmtpbmR9OiR7cHJvcC5zdGF0ZSA/PyBcIlwifWAsIChiKSA9PiBwYWludChiLCBwcm9wLnN0YXRlKSwgYXQsIHByb3Auc2NhbGUsIHByb3AuZmxpcCk7XG4gICAgaWYgKHByb3Auc3RhdGUgPT09IFwiYnVybmluZ1wiKSBkcmF3RmxhbWVzKGN0eCwgYXQsIHByb3Auc2NhbGUsIG5vdyArIHByb3AuaWQgKiA5Nyk7XG4gIH1cbn1cblxuLy8gRmxhbWVzIGxpY2tpbmcgdXAgZnJvbSBhIGJ1cm5pbmcgcHJvcCwgZmxpY2tlcmluZyB3aXRoIHRoZSBhbmltYXRpb24gY2xvY2suXG5mdW5jdGlvbiBkcmF3RmxhbWVzKGN0eDogQnJ1c2gsIGF0OiBQb2ludCwgc2NhbGU6IG51bWJlciwgbm93OiBudW1iZXIpIHtcbiAgY3R4LnNhdmUoKTtcbiAgY3R4LmxpbmVKb2luID0gXCJyb3VuZFwiO1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgNTsgaW5kZXggKz0gMSkge1xuICAgIGNvbnN0IHggPSBhdC54ICsgKGluZGV4IC0gMikgKiAxMSAqIHNjYWxlO1xuICAgIGNvbnN0IGhlaWdodCA9ICgxOCArIDEwICogTWF0aC5zaW4obm93IC8gOTAgKyBpbmRleCAqIDEuNykpICogc2NhbGU7XG4gICAgY29uc3QgYmFzZSA9IGF0LnkgLSA2ICogc2NhbGU7XG4gICAgY3R4LmZpbGxTdHlsZSA9IGluZGV4ICUgMiA/IFwicmdiYSgyMjksIDEwMSwgNDcsIDAuODUpXCIgOiBcInJnYmEoMjQ0LCAyMDAsIDExMCwgMC45KVwiO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHggLSA2ICogc2NhbGUsIGJhc2UpO1xuICAgIGN0eC5xdWFkcmF0aWNDdXJ2ZVRvKHggLSA0ICogc2NhbGUsIGJhc2UgLSBoZWlnaHQgKiAwLjYsIHggKyBNYXRoLnNpbihub3cgLyA3MCArIGluZGV4KSAqIDMgKiBzY2FsZSwgYmFzZSAtIGhlaWdodCk7XG4gICAgY3R4LnF1YWRyYXRpY0N1cnZlVG8oeCArIDUgKiBzY2FsZSwgYmFzZSAtIGhlaWdodCAqIDAuNSwgeCArIDYgKiBzY2FsZSwgYmFzZSk7XG4gICAgY3R4LmNsb3NlUGF0aCgpO1xuICAgIGN0eC5maWxsKCk7XG4gIH1cbiAgY3R4LmZpbGxTdHlsZSA9IFwicmdiYSg5MCwgODAsIDcyLCAwLjE4KVwiO1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgMzsgaW5kZXggKz0gMSkge1xuICAgIGNvbnN0IHJpc2UgPSAoKG5vdyAvIDMwICsgaW5kZXggKiA0MCkgJSAxMjApICogc2NhbGU7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5hcmMoYXQueCArIE1hdGguc2luKG5vdyAvIDQwMCArIGluZGV4KSAqIDEyICogc2NhbGUsIGF0LnkgLSAzMCAqIHNjYWxlIC0gcmlzZSwgKDggKyByaXNlICogMC4xMikgKiBzY2FsZSwgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5maWxsKCk7XG4gIH1cbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuLy8gLS0tLSBJbiB0aGUgYWlyIChzY3JlZW4gc3BhY2UsIG92ZXIgZXZlcnl0aGluZyBpbiB0aGUgd29ybGQpLlxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1N0b3J5QWlyKHBhaW50ZXI6IFN0b3J5UGFpbnRlcikge1xuICBjb25zdCB7IGN0eCwgdmlldyB9ID0gcGFpbnRlcjtcbiAgY3R4LnNhdmUoKTtcbiAgZm9yIChjb25zdCBtYXJrZXIgb2Ygdmlldy5tYXJrZXJzKSBkcmF3TWFya2VyU2lnbihwYWludGVyLCBtYXJrZXIpO1xuICBkcmF3TmFtZXBsYXRlcyhwYWludGVyKTtcbiAgZHJhd0Zsb2F0ZXJzKHBhaW50ZXIpO1xuICBkcmF3QnViYmxlcyhwYWludGVyKTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gZHJhd01hcmtlclNpZ24ocGFpbnRlcjogU3RvcnlQYWludGVyLCBtYXJrZXI6IE1hcmtlclZpZXcpIHtcbiAgY29uc3QgeyBjdHggfSA9IHBhaW50ZXI7XG4gIGNvbnN0IGF0ID0gcGFpbnRlci5wcm9qZWN0KG1hcmtlcik7XG4gIGNvbnN0IGFnZSA9IHNlY29uZHMocGFpbnRlci52aWV3LnRpY2sgLSBtYXJrZXIuc3RhcnQpO1xuICBpZiAobWFya2VyLmtpbmQgPT09IFwicXVlc3RcIikge1xuICAgIGNvbnN0IGJvYiA9IE1hdGguc2luKGFnZSAqIDMpICogNDtcbiAgICBjb25zdCB5ID0gYXQueSAtIDU4ICsgYm9iO1xuICAgIGlmICghb25TY3JlZW4ocGFpbnRlciwgeyB4OiBhdC54LCB5IH0sIDQwKSkgcmV0dXJuIGRyYXdFZGdlQXJyb3cocGFpbnRlciwgYXQsIEdPTEQpO1xuICAgIGN0eC5zYXZlKCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IFwiI2Y0Y2Y2MlwiO1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IFwiIzdhNTUxMlwiO1xuICAgIGN0eC5saW5lV2lkdGggPSAyO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKGF0LnggLSA2LCB5IC0gMjApO1xuICAgIGN0eC5saW5lVG8oYXQueCArIDYsIHkgLSAyMCk7XG4gICAgY3R4LmxpbmVUbyhhdC54ICsgMywgeSArIDIpO1xuICAgIGN0eC5saW5lVG8oYXQueCAtIDMsIHkgKyAyKTtcbiAgICBjdHguY2xvc2VQYXRoKCk7XG4gICAgY3R4LmZpbGwoKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5hcmMoYXQueCwgeSArIDEwLCA0LjUsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHguZmlsbCgpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICB9IGVsc2UgaWYgKG1hcmtlci5raW5kID09PSBcInJlbGljXCIpIHtcbiAgICBpZiAoIW9uU2NyZWVuKHBhaW50ZXIsIGF0LCAzMCkpIHJldHVybjtcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IFwiI2I5ODYxYlwiO1xuICAgIGN0eC5saW5lV2lkdGggPSAxLjY7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IDQ7IGluZGV4ICs9IDEpIHtcbiAgICAgIGNvbnN0IGFuZ2xlID0gYWdlICogMS4zICsgKGluZGV4ICogTWF0aC5QSSkgLyAyO1xuICAgICAgY29uc3QgciA9IDE2ICsgTWF0aC5zaW4oYWdlICogNCArIGluZGV4KSAqIDU7XG4gICAgICBjb25zdCB4ID0gYXQueCArIE1hdGguY29zKGFuZ2xlKSAqIHI7XG4gICAgICBjb25zdCB5ID0gYXQueSAtIDE4ICsgTWF0aC5zaW4oYW5nbGUpICogciAqIDAuNTtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5tb3ZlVG8oeCAtIDQsIHkpO1xuICAgICAgY3R4LmxpbmVUbyh4ICsgNCwgeSk7XG4gICAgICBjdHgubW92ZVRvKHgsIHkgLSA0KTtcbiAgICAgIGN0eC5saW5lVG8oeCwgeSArIDQpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgIH1cbiAgICBjdHgucmVzdG9yZSgpO1xuICB9XG4gIGlmIChtYXJrZXIubGFiZWwgIT09IHVuZGVmaW5lZCAmJiBvblNjcmVlbihwYWludGVyLCBhdCwgNjApKSB7XG4gICAgY3R4LnNhdmUoKTtcbiAgICBjdHguZm9udCA9IGA2MDAgMTNweCAke1NQRUVDSF9GT05UfWA7XG4gICAgY3R4LnRleHRBbGlnbiA9IFwiY2VudGVyXCI7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDQ7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gXCJyZ2JhKDI1NSwgMjUwLCAyMzYsIDAuOSlcIjtcbiAgICBjb25zdCB0ZXh0ID0gdGV4dEluKG1hcmtlci5sYWJlbCwgcGFpbnRlci5sb2NhbGUpO1xuICAgIGN0eC5zdHJva2VUZXh0KHRleHQsIGF0LngsIGF0LnkgKyBtYXJrZXIucmFkaXVzICogMC41NSAqIHBhaW50ZXIuem9vbSArIDE4KTtcbiAgICBjdHguZmlsbFN0eWxlID0gbWFya2VyLmtpbmQgPT09IFwiZGFuZ2VyXCIgPyBcIiM4ZTJhMWNcIiA6IFwiIzViNDIxNFwiO1xuICAgIGN0eC5maWxsVGV4dCh0ZXh0LCBhdC54LCBhdC55ICsgbWFya2VyLnJhZGl1cyAqIDAuNTUgKiBwYWludGVyLnpvb20gKyAxOCk7XG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3RWRnZUFycm93KHBhaW50ZXI6IFN0b3J5UGFpbnRlciwgdGFyZ2V0OiBQb2ludCwgY29sb3I6IHN0cmluZykge1xuICBjb25zdCB7IGN0eCwgd2lkdGgsIGhlaWdodCB9ID0gcGFpbnRlcjtcbiAgY29uc3QgY3ggPSB3aWR0aCAvIDI7XG4gIGNvbnN0IGN5ID0gaGVpZ2h0IC8gMjtcbiAgY29uc3QgYW5nbGUgPSBNYXRoLmF0YW4yKHRhcmdldC55IC0gY3ksIHRhcmdldC54IC0gY3gpO1xuICBjb25zdCBtYXJnaW4gPSAzNDtcbiAgY29uc3QgeCA9IE1hdGgubWF4KG1hcmdpbiwgTWF0aC5taW4od2lkdGggLSBtYXJnaW4sIGN4ICsgTWF0aC5jb3MoYW5nbGUpICogd2lkdGgpKTtcbiAgY29uc3QgeSA9IE1hdGgubWF4KG1hcmdpbiArIGxldHRlcmJveEhlaWdodChwYWludGVyKSwgTWF0aC5taW4oaGVpZ2h0IC0gbWFyZ2luIC0gbGV0dGVyYm94SGVpZ2h0KHBhaW50ZXIpLCBjeSArIE1hdGguc2luKGFuZ2xlKSAqIGhlaWdodCkpO1xuICBjdHguc2F2ZSgpO1xuICBjdHgudHJhbnNsYXRlKHgsIHkpO1xuICBjdHgucm90YXRlKGFuZ2xlKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGNvbG9yO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBcIiM1YjQyMTRcIjtcbiAgY3R4LmxpbmVXaWR0aCA9IDEuNTtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHgubW92ZVRvKDE0LCAwKTtcbiAgY3R4LmxpbmVUbygtOCwgLTEwKTtcbiAgY3R4LmxpbmVUbygtMywgMCk7XG4gIGN0eC5saW5lVG8oLTgsIDEwKTtcbiAgY3R4LmNsb3NlUGF0aCgpO1xuICBjdHguZmlsbCgpO1xuICBjdHguc3Ryb2tlKCk7XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmZ1bmN0aW9uIGRyYXdOYW1lcGxhdGVzKHBhaW50ZXI6IFN0b3J5UGFpbnRlcikge1xuICBjb25zdCB7IGN0eCwgdmlldyB9ID0gcGFpbnRlcjtcbiAgZm9yIChjb25zdCBbdW5pdElkLCBwbGF0ZV0gb2YgT2JqZWN0LmVudHJpZXModmlldy5uYW1lcGxhdGVzKSkge1xuICAgIGNvbnN0IHVuaXQgPSBwYWludGVyLnVuaXRBdCh1bml0SWQpO1xuICAgIGlmICghdW5pdCkgY29udGludWU7XG4gICAgY29uc3QgYXQgPSBwYWludGVyLnByb2plY3QodW5pdCk7XG4gICAgaWYgKCFvblNjcmVlbihwYWludGVyLCBhdCwgODApKSBjb250aW51ZTtcbiAgICBjb25zdCB5ID0gYXQueSArIHVuaXQucmFkaXVzICogcGFpbnRlci56b29tICsgMTQ7XG4gICAgY29uc3QgbmFtZSA9IHRleHRJbihwbGF0ZS5uYW1lLCBwYWludGVyLmxvY2FsZSk7XG4gICAgY29uc3QgbGFiZWwgPSBwbGF0ZS5sZXZlbCAhPT0gdW5kZWZpbmVkID8gYCR7bmFtZX0gIEx2JHtwbGF0ZS5sZXZlbH1gIDogbmFtZTtcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5mb250ID0gYDYwMCAxMnB4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgICBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgICBjdHgubGluZVdpZHRoID0gMy41O1xuICAgIGN0eC5zdHJva2VTdHlsZSA9IFwicmdiYSgyNTUsIDI1MCwgMjM2LCAwLjg1KVwiO1xuICAgIGN0eC5zdHJva2VUZXh0KGxhYmVsLCBhdC54LCB5KTtcbiAgICBjdHguZmlsbFN0eWxlID0gcGxhdGUuY29sb3I7XG4gICAgY3R4LmZpbGxUZXh0KGxhYmVsLCBhdC54LCB5KTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGRyYXdGbG9hdGVycyhwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHgsIHZpZXcgfSA9IHBhaW50ZXI7XG4gIGZvciAoY29uc3QgZmxvYXRlciBvZiB2aWV3LmZsb2F0ZXJzKSB7XG4gICAgY29uc3QgbGlmZSA9ICh2aWV3LnRpY2sgLSBmbG9hdGVyLnN0YXJ0KSAvIE1hdGgubWF4KDEsIGZsb2F0ZXIuZW5kIC0gZmxvYXRlci5zdGFydCk7XG4gICAgY29uc3QgdW5pdCA9IGZsb2F0ZXIudW5pdElkID8gcGFpbnRlci51bml0QXQoZmxvYXRlci51bml0SWQpIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IGJhc2UgPSBwYWludGVyLnByb2plY3QodW5pdCA/PyBmbG9hdGVyKTtcbiAgICBjb25zdCBhdCA9IHsgeDogYmFzZS54LCB5OiBiYXNlLnkgLSA0MiAtIGxpZmUgKiAzOCB9O1xuICAgIGlmICghb25TY3JlZW4ocGFpbnRlciwgYXQsIDYwKSkgY29udGludWU7XG4gICAgY3R4LnNhdmUoKTtcbiAgICBjdHguZ2xvYmFsQWxwaGEgPSBsaWZlIDwgMC43NSA/IDEgOiBNYXRoLm1heCgwLCAoMSAtIGxpZmUpIC8gMC4yNSk7XG4gICAgY3R4LmZvbnQgPSBgNzAwICR7ZmxvYXRlci5zaXplfXB4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgICBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgICBjdHgubGluZVdpZHRoID0gNDtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBcInJnYmEoMjU1LCAyNTAsIDIzNiwgMC45MilcIjtcbiAgICBjb25zdCB0ZXh0ID0gdGV4dEluKGZsb2F0ZXIudGV4dCwgcGFpbnRlci5sb2NhbGUpO1xuICAgIGN0eC5zdHJva2VUZXh0KHRleHQsIGF0LngsIGF0LnkpO1xuICAgIGN0eC5maWxsU3R5bGUgPSBmbG9hdGVyLmNvbG9yO1xuICAgIGN0eC5maWxsVGV4dCh0ZXh0LCBhdC54LCBhdC55KTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICB9XG59XG5cbnR5cGUgQnViYmxlQm94ID0geyBsaW5lOiBMaW5lVmlldzsgYW5jaG9yOiBQb2ludDsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyOyBsaW5lczogc3RyaW5nW107IG9mZnNjcmVlbjogYm9vbGVhbiB9O1xuXG5mdW5jdGlvbiBkcmF3QnViYmxlcyhwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHgsIHZpZXcgfSA9IHBhaW50ZXI7XG4gIGNvbnN0IGJveGVzOiBCdWJibGVCb3hbXSA9IFtdO1xuICBjdHguZm9udCA9IGAxN3B4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgZm9yIChjb25zdCBsaW5lIG9mIHZpZXcubGluZXMpIHtcbiAgICBjb25zdCB1bml0ID0gcGFpbnRlci51bml0QXQobGluZS5zcGVha2VySWQpO1xuICAgIGlmICghdW5pdCkgY29udGludWU7XG4gICAgY29uc3QgaGVhZCA9IHBhaW50ZXIucHJvamVjdCh1bml0KTtcbiAgICBjb25zdCBhbmNob3IgPSB7IHg6IGhlYWQueCwgeTogaGVhZC55IC0gKHVuaXQucmFkaXVzICogMS45ICsgMTQpICogcGFpbnRlci56b29tIH07XG4gICAgY29uc3QgdGV4dCA9IHRleHRJbihsaW5lLnRleHQsIHBhaW50ZXIubG9jYWxlKTtcbiAgICBjb25zdCBsaW5lcyA9IHdyYXAoY3R4LCB0ZXh0LCAyOTApO1xuICAgIGNvbnN0IHcgPSBNYXRoLm1heCg5MCwgTWF0aC5tYXgoLi4ubGluZXMubWFwKChyb3cpID0+IGN0eC5tZWFzdXJlVGV4dChyb3cpLndpZHRoKSkgKyAyOCk7XG4gICAgY29uc3QgaCA9IGxpbmVzLmxlbmd0aCAqIDIzICsgMzA7XG4gICAgY29uc3QgdG9wID0gbGV0dGVyYm94SGVpZ2h0KHBhaW50ZXIpICsgODtcbiAgICBjb25zdCB4ID0gY2xhbXAoYW5jaG9yLnggLSB3IC8gMiwgMTAsIHBhaW50ZXIud2lkdGggLSB3IC0gMTApO1xuICAgIGNvbnN0IHkgPSBjbGFtcChhbmNob3IueSAtIGggLSAxNiwgdG9wLCBwYWludGVyLmhlaWdodCAtIGggLSBsZXR0ZXJib3hIZWlnaHQocGFpbnRlcikgLSAxMCk7XG4gICAgYm94ZXMucHVzaCh7IGxpbmUsIGFuY2hvciwgeCwgeSwgdywgaCwgbGluZXMsIG9mZnNjcmVlbjogIW9uU2NyZWVuKHBhaW50ZXIsIGFuY2hvciwgMCkgfSk7XG4gIH1cbiAgLy8gQnViYmxlcyB0aGF0IHdvdWxkIGNvdmVyIG9uZSBhbm90aGVyIGFyZSBzdGFja2VkIHVwd2FyZCwgdGhlIG9sZGVyIGFib3ZlLlxuICBib3hlcy5zb3J0KChhLCBiKSA9PiBhLmxpbmUuc3RhcnQgLSBiLmxpbmUuc3RhcnQgfHwgYS54IC0gYi54KTtcbiAgZm9yIChsZXQgaW5kZXggPSAxOyBpbmRleCA8IGJveGVzLmxlbmd0aDsgaW5kZXggKz0gMSkge1xuICAgIGNvbnN0IGJveCA9IGJveGVzW2luZGV4XSE7XG4gICAgZm9yIChjb25zdCBvdGhlciBvZiBib3hlcy5zbGljZSgwLCBpbmRleCkpIHtcbiAgICAgIGlmIChib3gueCA8IG90aGVyLnggKyBvdGhlci53ICYmIG90aGVyLnggPCBib3gueCArIGJveC53ICYmIGJveC55IDwgb3RoZXIueSArIG90aGVyLmggJiYgb3RoZXIueSA8IGJveC55ICsgYm94LmgpIG90aGVyLnkgPSBNYXRoLm1heChsZXR0ZXJib3hIZWlnaHQocGFpbnRlcikgKyA4LCBib3gueSAtIG90aGVyLmggLSA2KTtcbiAgICB9XG4gIH1cbiAgZm9yIChjb25zdCBib3ggb2YgYm94ZXMpIGRyYXdCdWJibGUocGFpbnRlciwgYm94KTtcbn1cblxuZnVuY3Rpb24gZHJhd0J1YmJsZShwYWludGVyOiBTdG9yeVBhaW50ZXIsIGJveDogQnViYmxlQm94KSB7XG4gIGNvbnN0IHsgY3R4LCB2aWV3IH0gPSBwYWludGVyO1xuICBjb25zdCB7IGxpbmUgfSA9IGJveDtcbiAgY29uc3QgYWdlID0gc2Vjb25kcyh2aWV3LnRpY2sgLSBsaW5lLnN0YXJ0KTtcbiAgY29uc3QgbGVmdCA9IHNlY29uZHMobGluZS5lbmQgLSB2aWV3LnRpY2spO1xuICBjb25zdCBwb3AgPSBNYXRoLm1pbigxLCBhZ2UgLyAwLjE4KTtcbiAgY29uc3QgYWxwaGEgPSBNYXRoLm1pbigxLCBsZWZ0IC8gMC4zLCAwLjM1ICsgcG9wKTtcbiAgY3R4LnNhdmUoKTtcbiAgY3R4Lmdsb2JhbEFscGhhID0gTWF0aC5tYXgoMCwgYWxwaGEpO1xuICBjb25zdCBzY2FsZSA9IDAuODUgKyAwLjE1ICogZWFzZU91dChwb3ApO1xuICBjb25zdCBjeCA9IGJveC54ICsgYm94LncgLyAyO1xuICBjb25zdCBjeSA9IGJveC55ICsgYm94LmggLyAyO1xuICBjdHgudHJhbnNsYXRlKGN4LCBjeSk7XG4gIGN0eC5zY2FsZShzY2FsZSwgc2NhbGUpO1xuICBjdHgudHJhbnNsYXRlKC1jeCwgLWN5KTtcbiAgY29uc3QgdGFpbCA9IHsgeDogY2xhbXAoYm94LmFuY2hvci54LCBib3gueCArIDE4LCBib3gueCArIGJveC53IC0gMTgpLCB5OiBib3gueSArIGJveC5oIH07XG4gIGN0eC5saW5lSm9pbiA9IGN0eC5saW5lQ2FwID0gXCJyb3VuZFwiO1xuICBjdHguZmlsbFN0eWxlID0gbGluZS50b25lID09PSBcInRoaW5rXCIgPyBcInJnYmEoMjQ3LCAyNDcsIDI0MCwgMC45NClcIiA6IFBBUEVSO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBQQVBFUl9FREdFO1xuICBjdHgubGluZVdpZHRoID0gbGluZS50b25lID09PSBcInNob3V0XCIgPyAyLjYgOiAxLjc7XG4gIGlmIChsaW5lLnRvbmUgPT09IFwid2hpc3BlclwiKSBjdHguc2V0TGluZURhc2goWzUsIDRdKTtcbiAgY3R4LnNoYWRvd0NvbG9yID0gXCJyZ2JhKDYwLCA0NSwgMjAsIDAuMjIpXCI7XG4gIGN0eC5zaGFkb3dCbHVyID0gODtcbiAgY3R4LnNoYWRvd09mZnNldFkgPSAzO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGlmIChsaW5lLnRvbmUgPT09IFwic2hvdXRcIikgamFnZ2VkUmVjdChjdHgsIGJveC54LCBib3gueSwgYm94LncsIGJveC5oKTtcbiAgZWxzZSByb3VuZFJlY3QoY3R4LCBib3gueCwgYm94LnksIGJveC53LCBib3guaCwgMTIpO1xuICBjdHguZmlsbCgpO1xuICBjdHguc2hhZG93Q29sb3IgPSBcInRyYW5zcGFyZW50XCI7XG4gIGN0eC5zdHJva2UoKTtcbiAgY3R4LnNldExpbmVEYXNoKFtdKTtcbiAgLy8gVGhlIHRhaWwgcG9pbnRzIGF0IHRoZSBzcGVha2VyIChhIHRyYWlsIG9mIGJ1YmJsZXMgZm9yIGEgdGhvdWdodDsgYW4gYXJyb3cgdG8gdGhlIGVkZ2Ugd2hlbiB0aGUgc3BlYWtlciBpcyBvZmYgc2NyZWVuKS5cbiAgaWYgKCFib3gub2Zmc2NyZWVuKSB7XG4gICAgaWYgKGxpbmUudG9uZSA9PT0gXCJ0aGlua1wiKSB7XG4gICAgICBmb3IgKGNvbnN0IFtzaGFyZSwgcl0gb2YgW1swLjM1LCA1XSwgWzAuNywgMy4yXV0gYXMgY29uc3QpIHtcbiAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICBjdHguYXJjKHRhaWwueCArIChib3guYW5jaG9yLnggLSB0YWlsLngpICogc2hhcmUsIHRhaWwueSArIChib3guYW5jaG9yLnkgLSB0YWlsLnkpICogc2hhcmUsIHIsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHgubW92ZVRvKHRhaWwueCAtIDksIHRhaWwueSAtIDEpO1xuICAgICAgY3R4LmxpbmVUbyhib3guYW5jaG9yLngsIE1hdGgubWF4KHRhaWwueSArIDYsIGJveC5hbmNob3IueSkpO1xuICAgICAgY3R4LmxpbmVUbyh0YWlsLnggKyA5LCB0YWlsLnkgLSAxKTtcbiAgICAgIGN0eC5maWxsKCk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG4gICAgICBjdHguZmlsbFJlY3QodGFpbC54IC0gOCwgdGFpbC55IC0gMywgMTYsIDMuNSk7XG4gICAgfVxuICB9XG4gIGNvbnN0IG5hbWUgPSB0ZXh0SW4obGluZS5uYW1lLCBwYWludGVyLmxvY2FsZSk7XG4gIGlmIChuYW1lKSB7XG4gICAgY3R4LmZvbnQgPSBgNzAwIDEzcHggJHtTUEVFQ0hfRk9OVH1gO1xuICAgIGNvbnN0IG5hbWVXaWR0aCA9IGN0eC5tZWFzdXJlVGV4dChuYW1lKS53aWR0aCArIDE2O1xuICAgIGN0eC5maWxsU3R5bGUgPSBsaW5lLmNvbG9yO1xuICAgIHJvdW5kUmVjdChjdHgsIGJveC54ICsgMTAsIGJveC55IC0gMTEsIG5hbWVXaWR0aCwgMjAsIDYpO1xuICAgIGN0eC5maWxsKCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IFwiI2ZmZmFmMFwiO1xuICAgIGN0eC50ZXh0QmFzZWxpbmUgPSBcIm1pZGRsZVwiO1xuICAgIGN0eC5maWxsVGV4dChuYW1lLCBib3gueCArIDE4LCBib3gueSAtIDAuNSk7XG4gIH1cbiAgY3R4LnRleHRCYXNlbGluZSA9IFwiYWxwaGFiZXRpY1wiO1xuICBjdHguZm9udCA9IGAke2xpbmUudG9uZSA9PT0gXCJzaG91dFwiID8gXCI3MDAgXCIgOiBcIlwifTE3cHggJHtTUEVFQ0hfRk9OVH1gO1xuICBjdHguZmlsbFN0eWxlID0gbGluZS50b25lID09PSBcIndoaXNwZXJcIiB8fCBsaW5lLnRvbmUgPT09IFwidGhpbmtcIiA/IFwiIzVkNTQ0NlwiIDogSU5LO1xuICAvLyBXb3JkcyBhcHBlYXIgYXMgaWYgd3JpdHRlbjogdGhlIGxpbmUgZmlsbHMgaW4gb3ZlciBpdHMgZmlyc3QgbW9tZW50cy5cbiAgY29uc3Qgc2hvd24gPSBNYXRoLmZsb29yKE1hdGgubWluKDEsIGFnZSAvIE1hdGgubWluKDEuMiwgMC4wNCAqIGJveC5saW5lcy5qb2luKFwiXCIpLmxlbmd0aCArIDAuMikpICogYm94LmxpbmVzLmpvaW4oXCJcIikubGVuZ3RoICsgMC45OTkpO1xuICBsZXQgYnVkZ2V0ID0gc2hvd247XG4gIGJveC5saW5lcy5mb3JFYWNoKChyb3csIGluZGV4KSA9PiB7XG4gICAgY29uc3QgcGFydCA9IFsuLi5yb3ddLnNsaWNlKDAsIE1hdGgubWF4KDAsIGJ1ZGdldCkpLmpvaW4oXCJcIik7XG4gICAgYnVkZ2V0IC09IFsuLi5yb3ddLmxlbmd0aDtcbiAgICBjdHguZmlsbFRleHQocGFydCwgYm94LnggKyAxNCwgYm94LnkgKyAyOCArIGluZGV4ICogMjMpO1xuICB9KTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuLy8gLS0tLSBBY3Jvc3MgdGhlIHNjcmVlbi5cblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdTdG9yeVNjcmVlbihwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHggfSA9IHBhaW50ZXI7XG4gIGN0eC5zYXZlKCk7XG4gIGRyYXdMZXR0ZXJib3gocGFpbnRlcik7XG4gIGRyYXdPYmplY3RpdmVzKHBhaW50ZXIpO1xuICBkcmF3UGFydHkocGFpbnRlcik7XG4gIGRyYXdOb3RpY2VzKHBhaW50ZXIpO1xuICAvLyBOYXJyYXRpb24gYW5kIHRpdGxlcyByZWFkIG92ZXIgYSBmYWRlIHRvIGJsYWNrIChhIGNoYXB0ZXIncyBvcGVuaW5nIHdvcmRzKS5cbiAgZHJhd0ZhZGUocGFpbnRlcik7XG4gIGRyYXdOYXJyYXRpb24ocGFpbnRlcik7XG4gIGRyYXdDaG9pY2UocGFpbnRlcik7XG4gIGRyYXdUaXRsZShwYWludGVyKTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gbGV0dGVyYm94SGVpZ2h0KHBhaW50ZXI6IFBpY2s8U3RvcnlQYWludGVyLCBcInZpZXdcIiB8IFwiaGVpZ2h0XCI+KSB7XG4gIGNvbnN0IHsgbGV0dGVyYm94LCB0aWNrIH0gPSBwYWludGVyLnZpZXc7XG4gIGNvbnN0IHQgPSBNYXRoLm1pbigxLCBzZWNvbmRzKHRpY2sgLSBsZXR0ZXJib3guc2luY2UpIC8gMC42KTtcbiAgY29uc3Qgc2hhcmUgPSBsZXR0ZXJib3gub24gPyBlYXNlT3V0KHQpIDogMSAtIGVhc2VPdXQodCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKHBhaW50ZXIuaGVpZ2h0ICogMC4wODUgKiBNYXRoLm1heCgwLCBzaGFyZSkpO1xufVxuXG5mdW5jdGlvbiBkcmF3TGV0dGVyYm94KHBhaW50ZXI6IFN0b3J5UGFpbnRlcikge1xuICBjb25zdCBiYXIgPSBsZXR0ZXJib3hIZWlnaHQocGFpbnRlcik7XG4gIGlmIChiYXIgPD0gMCkgcmV0dXJuO1xuICBjb25zdCB7IGN0eCwgd2lkdGgsIGhlaWdodCB9ID0gcGFpbnRlcjtcbiAgY3R4LmZpbGxTdHlsZSA9IFwiIzE1MTIwZVwiO1xuICBjdHguZmlsbFJlY3QoMCwgMCwgd2lkdGgsIGJhcik7XG4gIGN0eC5maWxsUmVjdCgwLCBoZWlnaHQgLSBiYXIsIHdpZHRoLCBiYXIpO1xufVxuXG5mdW5jdGlvbiBkcmF3VGl0bGUocGFpbnRlcjogU3RvcnlQYWludGVyKSB7XG4gIGNvbnN0IGNhcmQgPSBwYWludGVyLnZpZXcudGl0bGU7XG4gIGlmICghY2FyZCkgcmV0dXJuO1xuICBjb25zdCB7IGN0eCwgd2lkdGgsIGhlaWdodCwgdmlldyB9ID0gcGFpbnRlcjtcbiAgY29uc3QgYWdlID0gc2Vjb25kcyh2aWV3LnRpY2sgLSBjYXJkLnN0YXJ0KTtcbiAgY29uc3QgbGVmdCA9IHNlY29uZHMoY2FyZC5lbmQgLSB2aWV3LnRpY2spO1xuICBjb25zdCBhbHBoYSA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIGFnZSAvIDAuOCwgbGVmdCAvIDAuOCkpO1xuICBjdHguc2F2ZSgpO1xuICBjdHguZ2xvYmFsQWxwaGEgPSBhbHBoYTtcbiAgY29uc3QgeSA9IGhlaWdodCAqIDAuNDI7XG4gIGNvbnN0IHdhc2ggPSBjdHguY3JlYXRlTGluZWFyR3JhZGllbnQoMCwgeSAtIDkwLCAwLCB5ICsgODApO1xuICB3YXNoLmFkZENvbG9yU3RvcCgwLCBcInJnYmEoMjUwLCAyNDQsIDIyMiwgMClcIik7XG4gIHdhc2guYWRkQ29sb3JTdG9wKDAuMzUsIFwicmdiYSgyNTAsIDI0NCwgMjIyLCAwLjg4KVwiKTtcbiAgd2FzaC5hZGRDb2xvclN0b3AoMC43LCBcInJnYmEoMjUwLCAyNDQsIDIyMiwgMC44OClcIik7XG4gIHdhc2guYWRkQ29sb3JTdG9wKDEsIFwicmdiYSgyNTAsIDI0NCwgMjIyLCAwKVwiKTtcbiAgY3R4LmZpbGxTdHlsZSA9IHdhc2g7XG4gIGN0eC5maWxsUmVjdCgwLCB5IC0gOTAsIHdpZHRoLCAxNzApO1xuICBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgY3R4LmZpbGxTdHlsZSA9IFwiIzJmMjcxY1wiO1xuICBjdHguZm9udCA9IGA1NnB4ICR7VElUTEVfRk9OVH1gO1xuICBjdHguZmlsbFRleHQodGV4dEluKGNhcmQudGV4dCwgcGFpbnRlci5sb2NhbGUpLCB3aWR0aCAvIDIsIHkpO1xuICAvLyBBIGJydXNoIHN0cm9rZSB1bmRlciB0aGUgdGl0bGUsIGRyYXduIG91dCBhcyB0aGUgY2FyZCBhcHBlYXJzLlxuICBjb25zdCBzcGFuID0gTWF0aC5taW4oMSwgYWdlIC8gMS4xKSAqIDI2MDtcbiAgY3R4LnN0cm9rZVN0eWxlID0gXCJyZ2JhKDEyMCwgMzIsIDI0LCAwLjc1KVwiO1xuICBjdHgubGluZVdpZHRoID0gNDtcbiAgY3R4LmxpbmVDYXAgPSBcInJvdW5kXCI7XG4gIGN0eC5iZWdpblBhdGgoKTtcbiAgY3R4Lm1vdmVUbyh3aWR0aCAvIDIgLSBzcGFuLCB5ICsgMjApO1xuICBjdHgucXVhZHJhdGljQ3VydmVUbyh3aWR0aCAvIDIsIHkgKyAyNywgd2lkdGggLyAyICsgc3BhbiwgeSArIDE4KTtcbiAgY3R4LnN0cm9rZSgpO1xuICBpZiAoY2FyZC5zdWJ0aXRsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY3R4LmZvbnQgPSBgMjRweCAke1RJVExFX0ZPTlR9YDtcbiAgICBjdHguZmlsbFN0eWxlID0gXCIjNWE0YTMzXCI7XG4gICAgY3R4LmZpbGxUZXh0KHRleHRJbihjYXJkLnN1YnRpdGxlLCBwYWludGVyLmxvY2FsZSksIHdpZHRoIC8gMiwgeSArIDU4KTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG5mdW5jdGlvbiBkcmF3TmFycmF0aW9uKHBhaW50ZXI6IFN0b3J5UGFpbnRlcikge1xuICBjb25zdCBjYXJkID0gcGFpbnRlci52aWV3Lm5hcnJhdGlvbjtcbiAgaWYgKCFjYXJkKSByZXR1cm47XG4gIGNvbnN0IHsgY3R4LCB3aWR0aCwgaGVpZ2h0LCB2aWV3IH0gPSBwYWludGVyO1xuICBjb25zdCBhZ2UgPSBzZWNvbmRzKHZpZXcudGljayAtIGNhcmQuc3RhcnQpO1xuICBjb25zdCBsZWZ0ID0gc2Vjb25kcyhjYXJkLmVuZCAtIHZpZXcudGljayk7XG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5nbG9iYWxBbHBoYSA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIGFnZSAvIDAuNSwgbGVmdCAvIDAuNSkpO1xuICBjdHguZm9udCA9IGAyNHB4ICR7VElUTEVfRk9OVH1gO1xuICBjb25zdCByb3dzID0gd3JhcChjdHgsIHRleHRJbihjYXJkLnRleHQsIHBhaW50ZXIubG9jYWxlKSwgd2lkdGggKiAwLjcpO1xuICBjb25zdCBiYXIgPSBsZXR0ZXJib3hIZWlnaHQocGFpbnRlcik7XG4gIGNvbnN0IGJveEhlaWdodCA9IHJvd3MubGVuZ3RoICogMzIgKyAyMjtcbiAgY29uc3QgeSA9IGJhciA+IDAgPyBoZWlnaHQgLSBiYXIgLSBib3hIZWlnaHQgLSAxMCA6IGhlaWdodCAtIGJveEhlaWdodCAtIDM2O1xuICBjb25zdCB3YXNoID0gY3R4LmNyZWF0ZUxpbmVhckdyYWRpZW50KHdpZHRoICogMC4xLCAwLCB3aWR0aCAqIDAuOSwgMCk7XG4gIHdhc2guYWRkQ29sb3JTdG9wKDAsIFwicmdiYSgzMCwgMjUsIDE4LCAwKVwiKTtcbiAgd2FzaC5hZGRDb2xvclN0b3AoMC4yLCBcInJnYmEoMzAsIDI1LCAxOCwgMC42MilcIik7XG4gIHdhc2guYWRkQ29sb3JTdG9wKDAuOCwgXCJyZ2JhKDMwLCAyNSwgMTgsIDAuNjIpXCIpO1xuICB3YXNoLmFkZENvbG9yU3RvcCgxLCBcInJnYmEoMzAsIDI1LCAxOCwgMClcIik7XG4gIGN0eC5maWxsU3R5bGUgPSB3YXNoO1xuICBjdHguZmlsbFJlY3Qod2lkdGggKiAwLjEsIHksIHdpZHRoICogMC44LCBib3hIZWlnaHQpO1xuICBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgY3R4LmZpbGxTdHlsZSA9IFwiI2Y2ZWNkMlwiO1xuICByb3dzLmZvckVhY2goKHJvdywgaW5kZXgpID0+IGN0eC5maWxsVGV4dChyb3csIHdpZHRoIC8gMiwgeSArIDMzICsgaW5kZXggKiAzMikpO1xuICBjdHgucmVzdG9yZSgpO1xufVxuXG5mdW5jdGlvbiBkcmF3T2JqZWN0aXZlcyhwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHgsIHZpZXcgfSA9IHBhaW50ZXI7XG4gIGlmICh2aWV3Lm9iamVjdGl2ZXMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGNvbnN0IHRvcCA9IGxldHRlcmJveEhlaWdodChwYWludGVyKSArIDE0O1xuICBjb25zdCByb3dzID0gdmlldy5vYmplY3RpdmVzLm1hcCgob2JqZWN0aXZlKSA9PiB7XG4gICAgY29uc3QgbWFyayA9IG9iamVjdGl2ZS5zdGF0ZSA9PT0gXCJkb25lXCIgPyBcIuKYkVwiIDogb2JqZWN0aXZlLnN0YXRlID09PSBcImZhaWxlZFwiID8gXCLimJJcIiA6IFwi4piQXCI7XG4gICAgY29uc3Qgd29yZHMgPSB0ZXh0SW4ob2JqZWN0aXZlLnRleHQsIHBhaW50ZXIubG9jYWxlKSArIChvYmplY3RpdmUucHJvZ3Jlc3MgPyBgICAke29iamVjdGl2ZS5wcm9ncmVzc31gIDogXCJcIik7XG4gICAgcmV0dXJuIHsgb2JqZWN0aXZlLCB0ZXh0OiBgJHttYXJrfSAke29iamVjdGl2ZS5vcHRpb25hbCA/IChwYWludGVyLmxvY2FsZSA9PT0gXCJ6aFwiID8gXCLvvIjmlK/nur/vvIlcIiA6IFwiKHNpZGUpIFwiKSA6IFwiXCJ9JHt3b3Jkc31gIH07XG4gIH0pO1xuICBjdHguZm9udCA9IGAxNXB4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgY29uc3QgdyA9IE1hdGgubWluKDQzMCwgTWF0aC5tYXgoMTcwLCAuLi5yb3dzLm1hcCgocm93KSA9PiBjdHgubWVhc3VyZVRleHQocm93LnRleHQpLndpZHRoICsgMzApKSk7XG4gIGNvbnN0IGggPSByb3dzLmxlbmd0aCAqIDI0ICsgMzg7XG4gIGN0eC5maWxsU3R5bGUgPSBcInJnYmEoMjUyLCAyNDYsIDIyNiwgMC45KVwiO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBQQVBFUl9FREdFO1xuICBjdHgubGluZVdpZHRoID0gMS40O1xuICByb3VuZFJlY3QoY3R4LCAxNCwgdG9wLCB3LCBoLCA4KTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnN0cm9rZSgpO1xuICBjdHguZm9udCA9IGA3MDAgMTRweCAke1NQRUVDSF9GT05UfWA7XG4gIGN0eC5maWxsU3R5bGUgPSBcIiM3YTJjMWVcIjtcbiAgY3R4LmZpbGxUZXh0KHBhaW50ZXIubG9jYWxlID09PSBcInpoXCIgPyBcIuebruagh1wiIDogXCJPYmplY3RpdmVzXCIsIDI2LCB0b3AgKyAyMSk7XG4gIGN0eC5mb250ID0gYDE1cHggJHtTUEVFQ0hfRk9OVH1gO1xuICByb3dzLmZvckVhY2goKHJvdywgaW5kZXgpID0+IHtcbiAgICBjb25zdCBzdGF0ZSA9IHJvdy5vYmplY3RpdmUuc3RhdGU7XG4gICAgY3R4LmZpbGxTdHlsZSA9IHN0YXRlID09PSBcImRvbmVcIiA/IFwiIzRmN2E0NVwiIDogc3RhdGUgPT09IFwiZmFpbGVkXCIgPyBcIiM5YTNhMmFcIiA6IHJvdy5vYmplY3RpdmUub3B0aW9uYWwgPyBcIiM2YzVjNDRcIiA6IElOSztcbiAgICBjdHguZmlsbFRleHQocm93LnRleHQsIDI0LCB0b3AgKyA0NSArIGluZGV4ICogMjQpO1xuICAgIGlmIChzdGF0ZSAhPT0gXCJhY3RpdmVcIikge1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gY3R4LmZpbGxTdHlsZTtcbiAgICAgIGN0eC5saW5lV2lkdGggPSAxLjI7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHgubW92ZVRvKDQ0LCB0b3AgKyA0MCArIGluZGV4ICogMjQpO1xuICAgICAgY3R4LmxpbmVUbygyNCArIGN0eC5tZWFzdXJlVGV4dChyb3cudGV4dCkud2lkdGgsIHRvcCArIDQwICsgaW5kZXggKiAyNCk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gZHJhd05vdGljZXMocGFpbnRlcjogU3RvcnlQYWludGVyKSB7XG4gIGNvbnN0IHsgY3R4LCB2aWV3LCB3aWR0aCB9ID0gcGFpbnRlcjtcbiAgbGV0IHkgPSBsZXR0ZXJib3hIZWlnaHQocGFpbnRlcikgKyAxODtcbiAgZm9yIChjb25zdCBub3RpY2Ugb2Ygdmlldy5ub3RpY2VzKSB7XG4gICAgY29uc3QgYWdlID0gc2Vjb25kcyh2aWV3LnRpY2sgLSBub3RpY2Uuc3RhcnQpO1xuICAgIGNvbnN0IGxlZnQgPSBzZWNvbmRzKG5vdGljZS5lbmQgLSB2aWV3LnRpY2spO1xuICAgIGNvbnN0IHRleHQgPSB0ZXh0SW4obm90aWNlLnRleHQsIHBhaW50ZXIubG9jYWxlKTtcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5nbG9iYWxBbHBoYSA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIGFnZSAvIDAuMywgbGVmdCAvIDAuNikpO1xuICAgIGN0eC5mb250ID0gYDYwMCAxNnB4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgICBjb25zdCB3ID0gY3R4Lm1lYXN1cmVUZXh0KHRleHQpLndpZHRoICsgMzY7XG4gICAgY29uc3QgeCA9IHdpZHRoIC8gMiAtIHcgLyAyO1xuICAgIGN0eC5maWxsU3R5bGUgPSBub3RpY2UudG9uZSA9PT0gXCJ3YXJuXCIgPyBcInJnYmEoMTIyLCA0MCwgMjgsIDAuODgpXCIgOiBub3RpY2UudG9uZSA9PT0gXCJnYWluXCIgPyBcInJnYmEoNTgsIDkyLCA0OCwgMC44OClcIiA6IG5vdGljZS50b25lID09PSBcInF1ZXN0XCIgPyBcInJnYmEoMTEyLCA4MiwgMjQsIDAuOSlcIiA6IFwicmdiYSg0NCwgNTIsIDYwLCAwLjg1KVwiO1xuICAgIHJvdW5kUmVjdChjdHgsIHgsIHksIHcsIDMwLCAxNSk7XG4gICAgY3R4LmZpbGwoKTtcbiAgICBjdHguZmlsbFN0eWxlID0gXCIjZmJmM2RjXCI7XG4gICAgY3R4LnRleHRBbGlnbiA9IFwiY2VudGVyXCI7XG4gICAgY3R4LmZpbGxUZXh0KHRleHQsIHdpZHRoIC8gMiwgeSArIDIxKTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICAgIHkgKz0gMzY7XG4gIH1cbn1cblxuZnVuY3Rpb24gZHJhd0Nob2ljZShwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgY2hvaWNlID0gcGFpbnRlci52aWV3LmNob2ljZTtcbiAgaWYgKCFjaG9pY2UpIHJldHVybjtcbiAgY29uc3QgeyBjdHgsIHdpZHRoLCBoZWlnaHQsIHZpZXcgfSA9IHBhaW50ZXI7XG4gIGNvbnN0IGFnZSA9IHNlY29uZHModmlldy50aWNrIC0gY2hvaWNlLm9wZW5lZCk7XG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5nbG9iYWxBbHBoYSA9IE1hdGgubWluKDEsIGFnZSAvIDAuMzUpO1xuICBjb25zdCBwcm9tcHQgPSB0ZXh0SW4oY2hvaWNlLnByb21wdCwgcGFpbnRlci5sb2NhbGUpO1xuICBjdHguZm9udCA9IGAyMHB4ICR7VElUTEVfRk9OVH1gO1xuICBjb25zdCBwcm9tcHRSb3dzID0gd3JhcChjdHgsIHByb21wdCwgNTYwKTtcbiAgY29uc3QgdyA9IDYyMDtcbiAgY29uc3QgaCA9IHByb21wdFJvd3MubGVuZ3RoICogMjggKyBjaG9pY2Uub3B0aW9ucy5sZW5ndGggKiA0MCArIDQ0O1xuICBjb25zdCB4ID0gd2lkdGggLyAyIC0gdyAvIDI7XG4gIGNvbnN0IHkgPSBoZWlnaHQgLSBsZXR0ZXJib3hIZWlnaHQocGFpbnRlcikgLSBoIC0gMjQ7XG4gIGN0eC5maWxsU3R5bGUgPSBcInJnYmEoMjUyLCAyNDYsIDIyNiwgMC45NilcIjtcbiAgY3R4LnN0cm9rZVN0eWxlID0gUEFQRVJfRURHRTtcbiAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gIGN0eC5zaGFkb3dDb2xvciA9IFwicmdiYSg0MCwgMzAsIDEwLCAwLjMpXCI7XG4gIGN0eC5zaGFkb3dCbHVyID0gMTQ7XG4gIHJvdW5kUmVjdChjdHgsIHgsIHksIHcsIGgsIDEwKTtcbiAgY3R4LmZpbGwoKTtcbiAgY3R4LnNoYWRvd0NvbG9yID0gXCJ0cmFuc3BhcmVudFwiO1xuICBjdHguc3Ryb2tlKCk7XG4gIGN0eC5maWxsU3R5bGUgPSBcIiMyZjI3MWNcIjtcbiAgcHJvbXB0Um93cy5mb3JFYWNoKChyb3csIGluZGV4KSA9PiBjdHguZmlsbFRleHQocm93LCB4ICsgMjQsIHkgKyAzNCArIGluZGV4ICogMjgpKTtcbiAgY2hvaWNlLm9wdGlvbnMuZm9yRWFjaCgob3B0aW9uLCBpbmRleCkgPT4ge1xuICAgIGNvbnN0IG95ID0geSArIHByb21wdFJvd3MubGVuZ3RoICogMjggKyAzMCArIGluZGV4ICogNDA7XG4gICAgY29uc3QgcGlja2VkID0gY2hvaWNlLnBpY2tlZCA9PT0gb3B0aW9uLmlkO1xuICAgIGNvbnN0IGZhZGVkID0gY2hvaWNlLnBpY2tlZCAhPT0gdW5kZWZpbmVkICYmICFwaWNrZWQ7XG4gICAgaWYgKHBpY2tlZCkge1xuICAgICAgY29uc3QgZ2xvdyA9IE1hdGgubWluKDEsIHNlY29uZHModmlldy50aWNrIC0gKGNob2ljZS5waWNrZWRBdCA/PyB2aWV3LnRpY2spKSAvIDAuMjUpO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9IGByZ2JhKDIxNCwgMTcwLCA3MiwgJHswLjM1ICsgMC4yNSAqIGdsb3d9KWA7XG4gICAgICByb3VuZFJlY3QoY3R4LCB4ICsgMTQsIG95IC0gMiwgdyAtIDI4LCAzNCwgNik7XG4gICAgICBjdHguZmlsbCgpO1xuICAgIH1cbiAgICBjdHguZ2xvYmFsQWxwaGEgPSBNYXRoLm1pbigxLCBhZ2UgLyAwLjM1KSAqIChmYWRlZCA/IDAuNCA6IDEpO1xuICAgIGN0eC5mb250ID0gYDYwMCAxOHB4ICR7U1BFRUNIX0ZPTlR9YDtcbiAgICBjdHguZmlsbFN0eWxlID0gXCIjN2EyYzFlXCI7XG4gICAgY3R4LmZpbGxUZXh0KGAke2luZGV4ICsgMX0uYCwgeCArIDI2LCBveSArIDIyKTtcbiAgICBjdHguZmlsbFN0eWxlID0gSU5LO1xuICAgIGN0eC5mb250ID0gYDE4cHggJHtTUEVFQ0hfRk9OVH1gO1xuICAgIGN0eC5maWxsVGV4dCh0ZXh0SW4ob3B0aW9uLnRleHQsIHBhaW50ZXIubG9jYWxlKSwgeCArIDUyLCBveSArIDIyKTtcbiAgICBjdHguZ2xvYmFsQWxwaGEgPSBNYXRoLm1pbigxLCBhZ2UgLyAwLjM1KTtcbiAgfSk7XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbi8vIFRoZSBoZXJvZXMnIHBhbmVsOiBvbmUgY2FyZCBwZXIgaGVybyBpbiBhIHN0cmlwIGFsb25nIHRoZSBib3R0b20tbGVmdCAobmFtZSwgbGV2ZWwsIGhlYWx0aCwgZXhwZXJpZW5jZSwgcG93ZXJzKS5cbmZ1bmN0aW9uIGRyYXdQYXJ0eShwYWludGVyOiBTdG9yeVBhaW50ZXIpIHtcbiAgY29uc3QgcGFydHkgPSBwYWludGVyLnZpZXcucGFydHk7XG4gIGlmICghcGFydHkgfHwgcGFydHkubWVtYmVycy5sZW5ndGggPT09IDAgfHwgcGFpbnRlci52aWV3LmxldHRlcmJveC5vbikgcmV0dXJuO1xuICBjb25zdCB7IGN0eCwgaGVpZ2h0IH0gPSBwYWludGVyO1xuICBjb25zdCBjYXJkV2lkdGggPSAxOTY7XG4gIGNvbnN0IGNhcmRIZWlnaHQgPSA3MDtcbiAgY29uc3QgeSA9IGhlaWdodCAtIGNhcmRIZWlnaHQgLSAxMjtcbiAgcGFydHkubWVtYmVycy5mb3JFYWNoKChtZW1iZXIsIGluZGV4KSA9PiB7XG4gICAgY29uc3QgeCA9IDEyICsgaW5kZXggKiAoY2FyZFdpZHRoICsgOCk7XG4gICAgY3R4LnNhdmUoKTtcbiAgICBjdHguZmlsbFN0eWxlID0gXCJyZ2JhKDI1MiwgMjQ2LCAyMjYsIDAuODgpXCI7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gUEFQRVJfRURHRTtcbiAgICBjdHgubGluZVdpZHRoID0gMS4yO1xuICAgIHJvdW5kUmVjdChjdHgsIHgsIHksIGNhcmRXaWR0aCwgY2FyZEhlaWdodCwgNyk7XG4gICAgY3R4LmZpbGwoKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IG1lbWJlci5jb2xvcjtcbiAgICBjdHguZmlsbFJlY3QoeCwgeSArIDcsIDQsIGNhcmRIZWlnaHQgLSAxNCk7XG4gICAgY3R4LmZvbnQgPSBgNzAwIDE0cHggJHtTUEVFQ0hfRk9OVH1gO1xuICAgIGN0eC5maWxsU3R5bGUgPSBJTks7XG4gICAgY3R4LmZpbGxUZXh0KHRleHRJbihtZW1iZXIubmFtZSwgcGFpbnRlci5sb2NhbGUpLCB4ICsgMTIsIHkgKyAxOCk7XG4gICAgY3R4LmZvbnQgPSBgNjAwIDEycHggJHtTUEVFQ0hfRk9OVH1gO1xuICAgIGN0eC5maWxsU3R5bGUgPSBcIiM3YTJjMWVcIjtcbiAgICBjdHgudGV4dEFsaWduID0gXCJyaWdodFwiO1xuICAgIGN0eC5maWxsVGV4dChgTHYgJHttZW1iZXIubGV2ZWx9JHttZW1iZXIuZ2Vhci5sZW5ndGggPiAwID8gYCAg4pymJHttZW1iZXIuZ2Vhci5sZW5ndGh9YCA6IFwiXCJ9YCwgeCArIGNhcmRXaWR0aCAtIDEwLCB5ICsgMTgpO1xuICAgIGN0eC50ZXh0QWxpZ24gPSBcImxlZnRcIjtcbiAgICBiYXIoY3R4LCB4ICsgMTIsIHkgKyAyNSwgY2FyZFdpZHRoIC0gMjQsIDYsIG1lbWJlci5ocCAvIE1hdGgubWF4KDEsIG1lbWJlci5tYXhIcCksIG1lbWJlci5ocCAvIG1lbWJlci5tYXhIcCA+IDAuNCA/IFwiIzdmYTg2ZlwiIDogXCIjYzg3MjRmXCIpO1xuICAgIGNvbnN0IHhwU2hhcmUgPSBtZW1iZXIueHBOZXh0ICE9PSB1bmRlZmluZWQgPyAobWVtYmVyLnhwIC0gbWVtYmVyLnhwRmxvb3IpIC8gTWF0aC5tYXgoMSwgbWVtYmVyLnhwTmV4dCAtIG1lbWJlci54cEZsb29yKSA6IDE7XG4gICAgYmFyKGN0eCwgeCArIDEyLCB5ICsgMzQsIGNhcmRXaWR0aCAtIDI0LCAzLCB4cFNoYXJlLCBcIiNiMThjZDZcIik7XG4gICAgY3R4LmZvbnQgPSBgMTFweCAke1NQRUVDSF9GT05UfWA7XG4gICAgbGV0IHN4ID0geCArIDEyO1xuICAgIGZvciAoY29uc3Qgc2tpbGwgb2YgbWVtYmVyLnNraWxscykge1xuICAgICAgY29uc3QgbmFtZSA9IHRleHRJbihza2lsbC5uYW1lLCBwYWludGVyLmxvY2FsZSk7XG4gICAgICBjb25zdCB3ID0gY3R4Lm1lYXN1cmVUZXh0KG5hbWUpLndpZHRoICsgMTA7XG4gICAgICBpZiAoc3ggKyB3ID4geCArIGNhcmRXaWR0aCAtIDgpIGJyZWFrO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9IHNraWxsLnJlYWR5ID49IDEgPyBcInJnYmEoMjE0LCAxNzAsIDcyLCAwLjkpXCIgOiBcInJnYmEoMTYwLCAxNTAsIDEzMCwgMC40NSlcIjtcbiAgICAgIHJvdW5kUmVjdChjdHgsIHN4LCB5ICsgNDQsIHcsIDE2LCA1KTtcbiAgICAgIGN0eC5maWxsKCk7XG4gICAgICBpZiAoc2tpbGwucmVhZHkgPCAxKSB7XG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSBcInJnYmEoMjE0LCAxNzAsIDcyLCAwLjU1KVwiO1xuICAgICAgICByb3VuZFJlY3QoY3R4LCBzeCwgeSArIDQ0LCBNYXRoLm1heCgyLCB3ICogc2tpbGwucmVhZHkpLCAxNiwgNSk7XG4gICAgICAgIGN0eC5maWxsKCk7XG4gICAgICB9XG4gICAgICBjdHguZmlsbFN0eWxlID0gSU5LO1xuICAgICAgY3R4LmZpbGxUZXh0KG5hbWUsIHN4ICsgNSwgeSArIDU2KTtcbiAgICAgIHN4ICs9IHcgKyA0O1xuICAgIH1cbiAgICBjdHgucmVzdG9yZSgpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gZHJhd0ZhZGUocGFpbnRlcjogU3RvcnlQYWludGVyKSB7XG4gIGNvbnN0IHsgZmFkZSwgdGljayB9ID0gcGFpbnRlci52aWV3O1xuICBsZXQgYWxwaGEgPSBmYWRlLnRvO1xuICBpZiAodGljayA8IGZhZGUuZW5kKSBhbHBoYSA9IHRpY2sgPD0gZmFkZS5zdGFydCA/IGZhZGUuZnJvbSA6IGZhZGUuZnJvbSArICgoZmFkZS50byAtIGZhZGUuZnJvbSkgKiAodGljayAtIGZhZGUuc3RhcnQpKSAvIE1hdGgubWF4KDEsIGZhZGUuZW5kIC0gZmFkZS5zdGFydCk7XG4gIGlmIChhbHBoYSA8PSAwLjAwMSkgcmV0dXJuO1xuICBwYWludGVyLmN0eC5maWxsU3R5bGUgPSBgcmdiYSgxMiwgMTAsIDgsICR7TWF0aC5taW4oMSwgYWxwaGEpfSlgO1xuICBwYWludGVyLmN0eC5maWxsUmVjdCgwLCAwLCBwYWludGVyLndpZHRoLCBwYWludGVyLmhlaWdodCk7XG59XG5cbi8vIC0tLS0gSGVscGVycy5cblxuZnVuY3Rpb24gYmFyKGN0eDogQnJ1c2gsIHg6IG51bWJlciwgeTogbnVtYmVyLCB3OiBudW1iZXIsIGg6IG51bWJlciwgc2hhcmU6IG51bWJlciwgY29sb3I6IHN0cmluZykge1xuICBjdHguZmlsbFN0eWxlID0gXCJyZ2JhKDQ5LCA3MiwgNTgsIDAuNTUpXCI7XG4gIGN0eC5maWxsUmVjdCh4LCB5LCB3LCBoKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGNvbG9yO1xuICBjdHguZmlsbFJlY3QoeCwgeSwgdyAqIE1hdGgubWF4KDAsIE1hdGgubWluKDEsIHNoYXJlKSksIGgpO1xufVxuXG4vLyBCcmVha3MgdGV4dCB0byBmaXQgYSB3aWR0aDogYmV0d2VlbiB3b3JkcyBpbiBhIHNwYWNlZCBzY3JpcHQsIGJldHdlZW4gYW55IHR3byBjaGFyYWN0ZXJzIGluIENoaW5lc2UuXG5leHBvcnQgZnVuY3Rpb24gd3JhcChjdHg6IEJydXNoLCB0ZXh0OiBzdHJpbmcsIG1heFdpZHRoOiBudW1iZXIpOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHJvd3M6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgcGFyYWdyYXBoIG9mIHRleHQuc3BsaXQoXCJcXG5cIikpIHtcbiAgICBjb25zdCB0b2tlbnMgPSBwYXJhZ3JhcGgubWF0Y2goL1viuoAt6b+/76SALe+rv++8gC3vv69dfFteXFxz4rqALem/v++kgC3vq7/vvIAt77+vXSt8XFxzKy9nKSA/PyBbXTtcbiAgICBsZXQgcm93ID0gXCJcIjtcbiAgICBmb3IgKGNvbnN0IHRva2VuIG9mIHRva2Vucykge1xuICAgICAgY29uc3QgbmV4dCA9IHJvdyArIHRva2VuO1xuICAgICAgaWYgKHJvdyAmJiBjdHgubWVhc3VyZVRleHQobmV4dCkud2lkdGggPiBtYXhXaWR0aCAmJiAhL15b77yM44CC77yB77yf44CB77yb77ya44CN44CP77yJLC4hPzs6XSQvLnRlc3QodG9rZW4pKSB7XG4gICAgICAgIHJvd3MucHVzaChyb3cudHJpbUVuZCgpKTtcbiAgICAgICAgcm93ID0gdG9rZW4udHJpbVN0YXJ0KCk7XG4gICAgICB9IGVsc2Ugcm93ID0gbmV4dDtcbiAgICB9XG4gICAgaWYgKHJvdykgcm93cy5wdXNoKHJvdy50cmltRW5kKCkpO1xuICB9XG4gIHJldHVybiByb3dzLmxlbmd0aCA+IDAgPyByb3dzIDogW1wiXCJdO1xufVxuXG5mdW5jdGlvbiByb3VuZFJlY3QoY3R4OiBCcnVzaCwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHc6IG51bWJlciwgaDogbnVtYmVyLCByOiBudW1iZXIpIHtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHgubW92ZVRvKHggKyByLCB5KTtcbiAgY3R4LmFyY1RvKHggKyB3LCB5LCB4ICsgdywgeSArIGgsIHIpO1xuICBjdHguYXJjVG8oeCArIHcsIHkgKyBoLCB4LCB5ICsgaCwgcik7XG4gIGN0eC5hcmNUbyh4LCB5ICsgaCwgeCwgeSwgcik7XG4gIGN0eC5hcmNUbyh4LCB5LCB4ICsgdywgeSwgcik7XG4gIGN0eC5jbG9zZVBhdGgoKTtcbn1cblxuZnVuY3Rpb24gamFnZ2VkUmVjdChjdHg6IEJydXNoLCB4OiBudW1iZXIsIHk6IG51bWJlciwgdzogbnVtYmVyLCBoOiBudW1iZXIpIHtcbiAgY29uc3QgcG9pbnRzOiBQb2ludFtdID0gW107XG4gIGNvbnN0IHN0ZXBzID0gTWF0aC5tYXgoOCwgTWF0aC5yb3VuZCgodyArIGgpIC8gMjIpKTtcbiAgY29uc3QgZWRnZSA9ICh0OiBudW1iZXIpOiBQb2ludCA9PiB7XG4gICAgY29uc3QgcCA9IHQgKiAyICogKHcgKyBoKTtcbiAgICBpZiAocCA8IHcpIHJldHVybiB7IHg6IHggKyBwLCB5IH07XG4gICAgaWYgKHAgPCB3ICsgaCkgcmV0dXJuIHsgeDogeCArIHcsIHk6IHkgKyBwIC0gdyB9O1xuICAgIGlmIChwIDwgMiAqIHcgKyBoKSByZXR1cm4geyB4OiB4ICsgdyAtIChwIC0gdyAtIGgpLCB5OiB5ICsgaCB9O1xuICAgIHJldHVybiB7IHgsIHk6IHkgKyBoIC0gKHAgLSAyICogdyAtIGgpIH07XG4gIH07XG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBzdGVwcyAqIDI7IGluZGV4ICs9IDEpIHtcbiAgICBjb25zdCBhdCA9IGVkZ2UoaW5kZXggLyAoc3RlcHMgKiAyKSk7XG4gICAgY29uc3Qgb3V0ID0gaW5kZXggJSAyID09PSAwID8gNSA6IC0xO1xuICAgIGNvbnN0IGN4ID0geCArIHcgLyAyO1xuICAgIGNvbnN0IGN5ID0geSArIGggLyAyO1xuICAgIGNvbnN0IGQgPSBNYXRoLmh5cG90KGF0LnggLSBjeCwgYXQueSAtIGN5KSB8fCAxO1xuICAgIHBvaW50cy5wdXNoKHsgeDogYXQueCArICgoYXQueCAtIGN4KSAvIGQpICogb3V0LCB5OiBhdC55ICsgKChhdC55IC0gY3kpIC8gZCkgKiBvdXQgfSk7XG4gIH1cbiAgY3R4Lm1vdmVUbyhwb2ludHNbMF0hLngsIHBvaW50c1swXSEueSk7XG4gIGZvciAoY29uc3QgcG9pbnQgb2YgcG9pbnRzLnNsaWNlKDEpKSBjdHgubGluZVRvKHBvaW50LngsIHBvaW50LnkpO1xuICBjdHguY2xvc2VQYXRoKCk7XG59XG5cbmZ1bmN0aW9uIG9uU2NyZWVuKHBhaW50ZXI6IFBpY2s8U3RvcnlQYWludGVyLCBcIndpZHRoXCIgfCBcImhlaWdodFwiPiwgcG9pbnQ6IFBvaW50LCBwYWQ6IG51bWJlcikge1xuICByZXR1cm4gcG9pbnQueCA+PSAtcGFkICYmIHBvaW50LnkgPj0gLXBhZCAmJiBwb2ludC54IDw9IHBhaW50ZXIud2lkdGggKyBwYWQgJiYgcG9pbnQueSA8PSBwYWludGVyLmhlaWdodCArIHBhZDtcbn1cblxuZnVuY3Rpb24gY2xhbXAodmFsdWU6IG51bWJlciwgbWluOiBudW1iZXIsIG1heDogbnVtYmVyKSB7XG4gIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChtaW4sIG1heCksIE1hdGgubWF4KG1pbiwgdmFsdWUpKTtcbn1cblxuZnVuY3Rpb24gZWFzZU91dCh0OiBudW1iZXIpIHtcbiAgcmV0dXJuIDEgLSAoMSAtIHQpICogKDEgLSB0KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyw0QkFBNEI7QUFDckMsU0FBUyxjQUE4RDtBQUN2RSxTQUFTLHFCQUFxQjtBQWF2QixhQUFNLGNBQWM7QUFDcEIsYUFBTSxhQUFhO0FBQzFCLE1BQU0sTUFBTTtBQUNaLE1BQU0sUUFBUTtBQUNkLE1BQU0sYUFBYTtBQUNuQixNQUFNLE9BQU87QUFjYixNQUFNLFVBQVUsQ0FBQyxVQUFrQixRQUFRO0FBSXBDLGdCQUFTLGdCQUFnQixLQUFZLE1BQWlCLFVBQW1DLE1BQThDO0FBQzVJLGFBQVcsVUFBVSxLQUFLLFNBQVM7QUFDakMsVUFBTSxLQUFLLFNBQVMsTUFBTTtBQUMxQixRQUFJLENBQUMsS0FBSyxJQUFJLE9BQU8sU0FBUyxFQUFFLEVBQUc7QUFDbkMscUJBQWlCLEtBQUssUUFBUSxJQUFJLFFBQVEsS0FBSyxPQUFPLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLFNBQVMsaUJBQWlCLEtBQVksUUFBb0IsSUFBVyxLQUFhO0FBQ2hGLE1BQUksS0FBSztBQUNULE1BQUksVUFBVSxJQUFJLFdBQVc7QUFDN0IsTUFBSSxPQUFPLFNBQVMsVUFBVTtBQUU1QixVQUFNLFFBQVEsTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLENBQUM7QUFDMUMsUUFBSSxZQUFZLHFCQUFxQixNQUFNLE9BQU8sS0FBSztBQUN2RCxRQUFJLGNBQWM7QUFDbEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZCLFFBQUksVUFBVTtBQUNkLFFBQUksUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sUUFBUSxPQUFPLFNBQVMsTUFBTSxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDOUUsUUFBSSxLQUFLO0FBQ1QsUUFBSSxPQUFPO0FBQUEsRUFDYixXQUFXLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxTQUFTO0FBQzdELFFBQUksY0FBYyxPQUFPLFNBQVMsVUFBVSw0QkFBNEI7QUFDeEUsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RCLFFBQUksaUJBQWlCLENBQUMsTUFBTTtBQUM1QixRQUFJLFVBQVU7QUFDZCxRQUFJLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLFFBQVEsT0FBTyxTQUFTLEtBQUssR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzdFLFFBQUksT0FBTztBQUFBLEVBQ2IsV0FBVyxPQUFPLFNBQVMsU0FBUztBQUNsQyxRQUFJLGNBQWM7QUFDbEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RCLFFBQUksVUFBVTtBQUNkLFFBQUksUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sUUFBUSxPQUFPLFNBQVMsS0FBSyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDN0UsUUFBSSxPQUFPO0FBQUEsRUFDYixXQUFXLE9BQU8sU0FBUyxTQUFTO0FBRWxDLFFBQUksY0FBYztBQUNsQixRQUFJLFlBQVk7QUFDaEIsYUFBUyxRQUFRLEdBQUcsUUFBUSxJQUFJLFNBQVMsR0FBRztBQUMxQyxZQUFNLFFBQVMsUUFBUSxLQUFNLEtBQUssS0FBSyxJQUFJLE1BQU07QUFDakQsWUFBTSxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU87QUFDMUMsWUFBTSxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUztBQUNuRCxVQUFJLFVBQVU7QUFDZCxVQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDbkIsVUFBSSxpQkFBaUIsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQ2hELFVBQUksT0FBTztBQUFBLElBQ2I7QUFBQSxFQUNGLFdBQVcsT0FBTyxTQUFTLFNBQVM7QUFDbEMsVUFBTSxPQUFPLElBQUkscUJBQXFCLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sTUFBTTtBQUM5RSxTQUFLLGFBQWEsR0FBRywyQkFBMkI7QUFDaEQsU0FBSyxhQUFhLEdBQUcsd0JBQXdCO0FBQzdDLFFBQUksWUFBWTtBQUNoQixRQUFJLFVBQVU7QUFDZCxRQUFJLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLFFBQVEsT0FBTyxTQUFTLEtBQUssR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzdFLFFBQUksS0FBSztBQUFBLEVBQ1gsT0FBTztBQUNMLFFBQUksY0FBYztBQUNsQixRQUFJLFlBQVk7QUFDaEIsVUFBTSxJQUFJLE9BQU87QUFDakIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQ3JELFFBQUksT0FBTyxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQztBQUM3QixRQUFJLE9BQU8sR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUM7QUFDN0IsUUFBSSxPQUFPLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDO0FBQzdCLFFBQUksT0FBTyxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQztBQUM3QixRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFJTyxnQkFBUyxlQUFlLEtBQVksTUFBaUIsVUFBbUMsTUFBOEMsU0FBd0YsS0FBYTtBQUNoUCxhQUFXLFFBQVEsQ0FBQyxHQUFHLEtBQUssS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFHO0FBQzVELFVBQU0sS0FBSyxTQUFTLElBQUk7QUFDeEIsUUFBSSxDQUFDLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFHO0FBQ2pDLFVBQU0sUUFBUSxRQUFRLEtBQUssSUFBSTtBQUMvQixRQUFJLENBQUMsTUFBTztBQUNaLGtCQUFjLEtBQUssR0FBRyxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxNQUFNLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJO0FBQzdHLFFBQUksS0FBSyxVQUFVLFVBQVcsWUFBVyxLQUFLLElBQUksS0FBSyxPQUFPLE1BQU0sS0FBSyxLQUFLLEVBQUU7QUFBQSxFQUNsRjtBQUNGO0FBR0EsU0FBUyxXQUFXLEtBQVksSUFBVyxPQUFlLEtBQWE7QUFDckUsTUFBSSxLQUFLO0FBQ1QsTUFBSSxXQUFXO0FBQ2YsV0FBUyxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksR0FBRyxLQUFLLFFBQVEsS0FBSyxLQUFLO0FBQ3BDLFVBQU0sVUFBVSxLQUFLLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxRQUFRLEdBQUcsS0FBSztBQUM5RCxVQUFNLE9BQU8sR0FBRyxJQUFJLElBQUk7QUFDeEIsUUFBSSxZQUFZLFFBQVEsSUFBSSw2QkFBNkI7QUFDekQsUUFBSSxVQUFVO0FBQ2QsUUFBSSxPQUFPLElBQUksSUFBSSxPQUFPLElBQUk7QUFDOUIsUUFBSSxpQkFBaUIsSUFBSSxJQUFJLE9BQU8sT0FBTyxTQUFTLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxJQUFJLE9BQU8sT0FBTyxNQUFNO0FBQ2xILFFBQUksaUJBQWlCLElBQUksSUFBSSxPQUFPLE9BQU8sU0FBUyxLQUFLLElBQUksSUFBSSxPQUFPLElBQUk7QUFDNUUsUUFBSSxVQUFVO0FBQ2QsUUFBSSxLQUFLO0FBQUEsRUFDWDtBQUNBLE1BQUksWUFBWTtBQUNoQixXQUFTLFFBQVEsR0FBRyxRQUFRLEdBQUcsU0FBUyxHQUFHO0FBQ3pDLFVBQU0sUUFBUyxNQUFNLEtBQUssUUFBUSxNQUFNLE1BQU87QUFDL0MsUUFBSSxVQUFVO0FBQ2QsUUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksTUFBTSxNQUFNLEtBQUssSUFBSSxLQUFLLE9BQU8sR0FBRyxJQUFJLEtBQUssUUFBUSxPQUFPLElBQUksT0FBTyxRQUFRLE9BQU8sR0FBRyxLQUFLLEtBQUssQ0FBQztBQUM1SCxRQUFJLEtBQUs7QUFBQSxFQUNYO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFJTyxnQkFBUyxhQUFhLFNBQXVCO0FBQ2xELFFBQU0sRUFBRSxLQUFLLEtBQUssSUFBSTtBQUN0QixNQUFJLEtBQUs7QUFDVCxhQUFXLFVBQVUsS0FBSyxRQUFTLGdCQUFlLFNBQVMsTUFBTTtBQUNqRSxpQkFBZSxPQUFPO0FBQ3RCLGVBQWEsT0FBTztBQUNwQixjQUFZLE9BQU87QUFDbkIsTUFBSSxRQUFRO0FBQ2Q7QUFFQSxTQUFTLGVBQWUsU0FBdUIsUUFBb0I7QUFDakUsUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixRQUFNLEtBQUssUUFBUSxRQUFRLE1BQU07QUFDakMsUUFBTSxNQUFNLFFBQVEsUUFBUSxLQUFLLE9BQU8sT0FBTyxLQUFLO0FBQ3BELE1BQUksT0FBTyxTQUFTLFNBQVM7QUFDM0IsVUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLENBQUMsSUFBSTtBQUNoQyxVQUFNLElBQUksR0FBRyxJQUFJLEtBQUs7QUFDdEIsUUFBSSxDQUFDLFNBQVMsU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUcsUUFBTyxjQUFjLFNBQVMsSUFBSSxJQUFJO0FBQ2xGLFFBQUksS0FBSztBQUNULFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksVUFBVTtBQUNkLFFBQUksT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDM0IsUUFBSSxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRTtBQUMzQixRQUFJLE9BQU8sR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQzFCLFFBQUksT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7QUFDMUIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxLQUFLO0FBQ1QsUUFBSSxPQUFPO0FBQ1gsUUFBSSxVQUFVO0FBQ2QsUUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQ3pDLFFBQUksS0FBSztBQUNULFFBQUksT0FBTztBQUNYLFFBQUksUUFBUTtBQUFBLEVBQ2QsV0FBVyxPQUFPLFNBQVMsU0FBUztBQUNsQyxRQUFJLENBQUMsU0FBUyxTQUFTLElBQUksRUFBRSxFQUFHO0FBQ2hDLFFBQUksS0FBSztBQUNULFFBQUksY0FBYztBQUNsQixRQUFJLFlBQVk7QUFDaEIsYUFBUyxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUN6QyxZQUFNLFFBQVEsTUFBTSxNQUFPLFFBQVEsS0FBSyxLQUFNO0FBQzlDLFlBQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJO0FBQzNDLFlBQU0sSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSTtBQUNuQyxZQUFNLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJO0FBQzVDLFVBQUksVUFBVTtBQUNkLFVBQUksT0FBTyxJQUFJLEdBQUcsQ0FBQztBQUNuQixVQUFJLE9BQU8sSUFBSSxHQUFHLENBQUM7QUFDbkIsVUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDO0FBQ25CLFVBQUksT0FBTyxHQUFHLElBQUksQ0FBQztBQUNuQixVQUFJLE9BQU87QUFBQSxJQUNiO0FBQ0EsUUFBSSxRQUFRO0FBQUEsRUFDZDtBQUNBLE1BQUksT0FBTyxVQUFVLFVBQWEsU0FBUyxTQUFTLElBQUksRUFBRSxHQUFHO0FBQzNELFFBQUksS0FBSztBQUNULFFBQUksT0FBTyxZQUFZLFdBQVc7QUFDbEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsVUFBTSxPQUFPLE9BQU8sT0FBTyxPQUFPLFFBQVEsTUFBTTtBQUNoRCxRQUFJLFdBQVcsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFO0FBQzFFLFFBQUksWUFBWSxPQUFPLFNBQVMsV0FBVyxZQUFZO0FBQ3ZELFFBQUksU0FBUyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksT0FBTyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUU7QUFDeEUsUUFBSSxRQUFRO0FBQUEsRUFDZDtBQUNGO0FBRUEsU0FBUyxjQUFjLFNBQXVCLFFBQWUsT0FBZTtBQUMxRSxRQUFNLEVBQUUsS0FBSyxPQUFPLE9BQU8sSUFBSTtBQUMvQixRQUFNLEtBQUssUUFBUTtBQUNuQixRQUFNLEtBQUssU0FBUztBQUNwQixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxFQUFFO0FBQ3JELFFBQU0sU0FBUztBQUNmLFFBQU0sSUFBSSxLQUFLLElBQUksUUFBUSxLQUFLLElBQUksUUFBUSxRQUFRLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUM7QUFDakYsUUFBTSxJQUFJLEtBQUssSUFBSSxTQUFTLGdCQUFnQixPQUFPLEdBQUcsS0FBSyxJQUFJLFNBQVMsU0FBUyxnQkFBZ0IsT0FBTyxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLENBQUM7QUFDekksTUFBSSxLQUFLO0FBQ1QsTUFBSSxVQUFVLEdBQUcsQ0FBQztBQUNsQixNQUFJLE9BQU8sS0FBSztBQUNoQixNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFDZCxNQUFJLE9BQU8sSUFBSSxDQUFDO0FBQ2hCLE1BQUksT0FBTyxJQUFJLEdBQUc7QUFDbEIsTUFBSSxPQUFPLElBQUksQ0FBQztBQUNoQixNQUFJLE9BQU8sSUFBSSxFQUFFO0FBQ2pCLE1BQUksVUFBVTtBQUNkLE1BQUksS0FBSztBQUNULE1BQUksT0FBTztBQUNYLE1BQUksUUFBUTtBQUNkO0FBRUEsU0FBUyxlQUFlLFNBQXVCO0FBQzdDLFFBQU0sRUFBRSxLQUFLLEtBQUssSUFBSTtBQUN0QixhQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLEtBQUssVUFBVSxHQUFHO0FBQzdELFVBQU0sT0FBTyxRQUFRLE9BQU8sTUFBTTtBQUNsQyxRQUFJLENBQUMsS0FBTTtBQUNYLFVBQU0sS0FBSyxRQUFRLFFBQVEsSUFBSTtBQUMvQixRQUFJLENBQUMsU0FBUyxTQUFTLElBQUksRUFBRSxFQUFHO0FBQ2hDLFVBQU0sSUFBSSxHQUFHLElBQUksS0FBSyxTQUFTLFFBQVEsT0FBTztBQUM5QyxVQUFNLE9BQU8sT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNO0FBQzlDLFVBQU0sUUFBUSxNQUFNLFVBQVUsU0FBWSxHQUFHLElBQUksT0FBTyxNQUFNLEtBQUssS0FBSztBQUN4RSxRQUFJLEtBQUs7QUFDVCxRQUFJLE9BQU8sWUFBWSxXQUFXO0FBQ2xDLFFBQUksWUFBWTtBQUNoQixRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksV0FBVyxPQUFPLEdBQUcsR0FBRyxDQUFDO0FBQzdCLFFBQUksWUFBWSxNQUFNO0FBQ3RCLFFBQUksU0FBUyxPQUFPLEdBQUcsR0FBRyxDQUFDO0FBQzNCLFFBQUksUUFBUTtBQUFBLEVBQ2Q7QUFDRjtBQUVBLFNBQVMsYUFBYSxTQUF1QjtBQUMzQyxRQUFNLEVBQUUsS0FBSyxLQUFLLElBQUk7QUFDdEIsYUFBVyxXQUFXLEtBQUssVUFBVTtBQUNuQyxVQUFNLFFBQVEsS0FBSyxPQUFPLFFBQVEsU0FBUyxLQUFLLElBQUksR0FBRyxRQUFRLE1BQU0sUUFBUSxLQUFLO0FBQ2xGLFVBQU0sT0FBTyxRQUFRLFNBQVMsUUFBUSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQy9ELFVBQU0sT0FBTyxRQUFRLFFBQVEsUUFBUSxPQUFPO0FBQzVDLFVBQU0sS0FBSyxFQUFFLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxJQUFJLEtBQUssT0FBTyxHQUFHO0FBQ25ELFFBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxFQUFFLEVBQUc7QUFDaEMsUUFBSSxLQUFLO0FBQ1QsUUFBSSxjQUFjLE9BQU8sT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksUUFBUSxJQUFJO0FBQ2pFLFFBQUksT0FBTyxPQUFPLFFBQVEsSUFBSSxNQUFNLFdBQVc7QUFDL0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsVUFBTSxPQUFPLE9BQU8sUUFBUSxNQUFNLFFBQVEsTUFBTTtBQUNoRCxRQUFJLFdBQVcsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQy9CLFFBQUksWUFBWSxRQUFRO0FBQ3hCLFFBQUksU0FBUyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDN0IsUUFBSSxRQUFRO0FBQUEsRUFDZDtBQUNGO0FBSUEsU0FBUyxZQUFZLFNBQXVCO0FBQzFDLFFBQU0sRUFBRSxLQUFLLEtBQUssSUFBSTtBQUN0QixRQUFNLFFBQXFCLENBQUM7QUFDNUIsTUFBSSxPQUFPLFFBQVEsV0FBVztBQUM5QixhQUFXLFFBQVEsS0FBSyxPQUFPO0FBQzdCLFVBQU0sT0FBTyxRQUFRLE9BQU8sS0FBSyxTQUFTO0FBQzFDLFFBQUksQ0FBQyxLQUFNO0FBQ1gsVUFBTSxPQUFPLFFBQVEsUUFBUSxJQUFJO0FBQ2pDLFVBQU0sU0FBUyxFQUFFLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxLQUFLLEtBQUssU0FBUyxNQUFNLE1BQU0sUUFBUSxLQUFLO0FBQ2hGLFVBQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxRQUFRLE1BQU07QUFDN0MsVUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLEdBQUc7QUFDakMsVUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsSUFBSSxZQUFZLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFO0FBQ3ZGLFVBQU0sSUFBSSxNQUFNLFNBQVMsS0FBSztBQUM5QixVQUFNLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtBQUN2QyxVQUFNLElBQUksTUFBTSxPQUFPLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLElBQUksRUFBRTtBQUM1RCxVQUFNLElBQUksTUFBTSxPQUFPLElBQUksSUFBSSxJQUFJLEtBQUssUUFBUSxTQUFTLElBQUksZ0JBQWdCLE9BQU8sSUFBSSxFQUFFO0FBQzFGLFVBQU0sS0FBSyxFQUFFLE1BQU0sUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sV0FBVyxDQUFDLFNBQVMsU0FBUyxRQUFRLENBQUMsRUFBRSxDQUFDO0FBQUEsRUFDMUY7QUFFQSxRQUFNLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxLQUFLLFFBQVEsRUFBRSxLQUFLLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQztBQUM3RCxXQUFTLFFBQVEsR0FBRyxRQUFRLE1BQU0sUUFBUSxTQUFTLEdBQUc7QUFDcEQsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUN2QixlQUFXLFNBQVMsTUFBTSxNQUFNLEdBQUcsS0FBSyxHQUFHO0FBQ3pDLFVBQUksSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUcsT0FBTSxJQUFJLEtBQUssSUFBSSxnQkFBZ0IsT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQUEsSUFDeEw7QUFBQSxFQUNGO0FBQ0EsYUFBVyxPQUFPLE1BQU8sWUFBVyxTQUFTLEdBQUc7QUFDbEQ7QUFFQSxTQUFTLFdBQVcsU0FBdUIsS0FBZ0I7QUFDekQsUUFBTSxFQUFFLEtBQUssS0FBSyxJQUFJO0FBQ3RCLFFBQU0sRUFBRSxLQUFLLElBQUk7QUFDakIsUUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssS0FBSztBQUMxQyxRQUFNLE9BQU8sUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLElBQUksR0FBRyxNQUFNLElBQUk7QUFDbEMsUUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDaEQsTUFBSSxLQUFLO0FBQ1QsTUFBSSxjQUFjLEtBQUssSUFBSSxHQUFHLEtBQUs7QUFDbkMsUUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLEdBQUc7QUFDdkMsUUFBTSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7QUFDM0IsUUFBTSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7QUFDM0IsTUFBSSxVQUFVLElBQUksRUFBRTtBQUNwQixNQUFJLE1BQU0sT0FBTyxLQUFLO0FBQ3RCLE1BQUksVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3RCLFFBQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxJQUFJLE9BQU8sR0FBRyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRyxHQUFHLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDeEYsTUFBSSxXQUFXLElBQUksVUFBVTtBQUM3QixNQUFJLFlBQVksS0FBSyxTQUFTLFVBQVUsOEJBQThCO0FBQ3RFLE1BQUksY0FBYztBQUNsQixNQUFJLFlBQVksS0FBSyxTQUFTLFVBQVUsTUFBTTtBQUM5QyxNQUFJLEtBQUssU0FBUyxVQUFXLEtBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25ELE1BQUksY0FBYztBQUNsQixNQUFJLGFBQWE7QUFDakIsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxLQUFLLFNBQVMsUUFBUyxZQUFXLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQUEsTUFDaEUsV0FBVSxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFO0FBQ2xELE1BQUksS0FBSztBQUNULE1BQUksY0FBYztBQUNsQixNQUFJLE9BQU87QUFDWCxNQUFJLFlBQVksQ0FBQyxDQUFDO0FBRWxCLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbEIsUUFBSSxLQUFLLFNBQVMsU0FBUztBQUN6QixpQkFBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQVk7QUFDekQsWUFBSSxVQUFVO0FBQ2QsWUFBSSxJQUFJLEtBQUssS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU8sR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzdHLFlBQUksS0FBSztBQUNULFlBQUksT0FBTztBQUFBLE1BQ2I7QUFBQSxJQUNGLE9BQU87QUFDTCxVQUFJLFVBQVU7QUFDZCxVQUFJLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLENBQUM7QUFDakMsVUFBSSxPQUFPLElBQUksT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sQ0FBQyxDQUFDO0FBQzNELFVBQUksT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksQ0FBQztBQUNqQyxVQUFJLEtBQUs7QUFDVCxVQUFJLE9BQU87QUFDWCxVQUFJLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNLFFBQVEsTUFBTTtBQUM3QyxNQUFJLE1BQU07QUFDUixRQUFJLE9BQU8sWUFBWSxXQUFXO0FBQ2xDLFVBQU0sWUFBWSxJQUFJLFlBQVksSUFBSSxFQUFFLFFBQVE7QUFDaEQsUUFBSSxZQUFZLEtBQUs7QUFDckIsY0FBVSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDO0FBQ3ZELFFBQUksS0FBSztBQUNULFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWU7QUFDbkIsUUFBSSxTQUFTLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUc7QUFBQSxFQUM1QztBQUNBLE1BQUksZUFBZTtBQUNuQixNQUFJLE9BQU8sR0FBRyxLQUFLLFNBQVMsVUFBVSxTQUFTLEVBQUUsUUFBUSxXQUFXO0FBQ3BFLE1BQUksWUFBWSxLQUFLLFNBQVMsYUFBYSxLQUFLLFNBQVMsVUFBVSxZQUFZO0FBRS9FLFFBQU0sUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLElBQUksS0FBSyxPQUFPLElBQUksTUFBTSxLQUFLLEVBQUUsRUFBRSxTQUFTLEdBQUcsQ0FBQyxJQUFJLElBQUksTUFBTSxLQUFLLEVBQUUsRUFBRSxTQUFTLEtBQUs7QUFDckksTUFBSSxTQUFTO0FBQ2IsTUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFLLFVBQVU7QUFDaEMsVUFBTSxPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLEtBQUssRUFBRTtBQUMzRCxjQUFVLENBQUMsR0FBRyxHQUFHLEVBQUU7QUFDbkIsUUFBSSxTQUFTLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFO0FBQUEsRUFDeEQsQ0FBQztBQUNELE1BQUksUUFBUTtBQUNkO0FBSU8sZ0JBQVMsZ0JBQWdCLFNBQXVCO0FBQ3JELFFBQU0sRUFBRSxJQUFJLElBQUk7QUFDaEIsTUFBSSxLQUFLO0FBQ1QsZ0JBQWMsT0FBTztBQUNyQixpQkFBZSxPQUFPO0FBQ3RCLFlBQVUsT0FBTztBQUNqQixjQUFZLE9BQU87QUFFbkIsV0FBUyxPQUFPO0FBQ2hCLGdCQUFjLE9BQU87QUFDckIsYUFBVyxPQUFPO0FBQ2xCLFlBQVUsT0FBTztBQUNqQixNQUFJLFFBQVE7QUFDZDtBQUVBLFNBQVMsZ0JBQWdCLFNBQWdEO0FBQ3ZFLFFBQU0sRUFBRSxXQUFXLEtBQUssSUFBSSxRQUFRO0FBQ3BDLFFBQU0sSUFBSSxLQUFLLElBQUksR0FBRyxRQUFRLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRztBQUMzRCxRQUFNLFFBQVEsVUFBVSxLQUFLLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDO0FBQ3ZELFNBQU8sS0FBSyxNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQztBQUMvRDtBQUVBLFNBQVMsY0FBYyxTQUF1QjtBQUM1QyxRQUFNQSxPQUFNLGdCQUFnQixPQUFPO0FBQ25DLE1BQUlBLFFBQU8sRUFBRztBQUNkLFFBQU0sRUFBRSxLQUFLLE9BQU8sT0FBTyxJQUFJO0FBQy9CLE1BQUksWUFBWTtBQUNoQixNQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU9BLElBQUc7QUFDN0IsTUFBSSxTQUFTLEdBQUcsU0FBU0EsTUFBSyxPQUFPQSxJQUFHO0FBQzFDO0FBRUEsU0FBUyxVQUFVLFNBQXVCO0FBQ3hDLFFBQU0sT0FBTyxRQUFRLEtBQUs7QUFDMUIsTUFBSSxDQUFDLEtBQU07QUFDWCxRQUFNLEVBQUUsS0FBSyxPQUFPLFFBQVEsS0FBSyxJQUFJO0FBQ3JDLFFBQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxLQUFLLEtBQUs7QUFDMUMsUUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtBQUN6QyxRQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLE9BQU8sR0FBRyxDQUFDO0FBQzVELE1BQUksS0FBSztBQUNULE1BQUksY0FBYztBQUNsQixRQUFNLElBQUksU0FBUztBQUNuQixRQUFNLE9BQU8sSUFBSSxxQkFBcUIsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDMUQsT0FBSyxhQUFhLEdBQUcsd0JBQXdCO0FBQzdDLE9BQUssYUFBYSxNQUFNLDJCQUEyQjtBQUNuRCxPQUFLLGFBQWEsS0FBSywyQkFBMkI7QUFDbEQsT0FBSyxhQUFhLEdBQUcsd0JBQXdCO0FBQzdDLE1BQUksWUFBWTtBQUNoQixNQUFJLFNBQVMsR0FBRyxJQUFJLElBQUksT0FBTyxHQUFHO0FBQ2xDLE1BQUksWUFBWTtBQUNoQixNQUFJLFlBQVk7QUFDaEIsTUFBSSxPQUFPLFFBQVEsVUFBVTtBQUM3QixNQUFJLFNBQVMsT0FBTyxLQUFLLE1BQU0sUUFBUSxNQUFNLEdBQUcsUUFBUSxHQUFHLENBQUM7QUFFNUQsUUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRyxJQUFJO0FBQ3RDLE1BQUksY0FBYztBQUNsQixNQUFJLFlBQVk7QUFDaEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxVQUFVO0FBQ2QsTUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLElBQUksRUFBRTtBQUNuQyxNQUFJLGlCQUFpQixRQUFRLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSSxNQUFNLElBQUksRUFBRTtBQUNoRSxNQUFJLE9BQU87QUFDWCxNQUFJLEtBQUssYUFBYSxRQUFXO0FBQy9CLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDN0IsUUFBSSxZQUFZO0FBQ2hCLFFBQUksU0FBUyxPQUFPLEtBQUssVUFBVSxRQUFRLE1BQU0sR0FBRyxRQUFRLEdBQUcsSUFBSSxFQUFFO0FBQUEsRUFDdkU7QUFDQSxNQUFJLFFBQVE7QUFDZDtBQUVBLFNBQVMsY0FBYyxTQUF1QjtBQUM1QyxRQUFNLE9BQU8sUUFBUSxLQUFLO0FBQzFCLE1BQUksQ0FBQyxLQUFNO0FBQ1gsUUFBTSxFQUFFLEtBQUssT0FBTyxRQUFRLEtBQUssSUFBSTtBQUNyQyxRQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxLQUFLO0FBQzFDLFFBQU0sT0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLElBQUk7QUFDekMsTUFBSSxLQUFLO0FBQ1QsTUFBSSxjQUFjLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxPQUFPLEdBQUcsQ0FBQztBQUNoRSxNQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzdCLFFBQU0sT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLE1BQU0sUUFBUSxNQUFNLEdBQUcsUUFBUSxHQUFHO0FBQ3JFLFFBQU1BLE9BQU0sZ0JBQWdCLE9BQU87QUFDbkMsUUFBTSxZQUFZLEtBQUssU0FBUyxLQUFLO0FBQ3JDLFFBQU0sSUFBSUEsT0FBTSxJQUFJLFNBQVNBLE9BQU0sWUFBWSxLQUFLLFNBQVMsWUFBWTtBQUN6RSxRQUFNLE9BQU8sSUFBSSxxQkFBcUIsUUFBUSxLQUFLLEdBQUcsUUFBUSxLQUFLLENBQUM7QUFDcEUsT0FBSyxhQUFhLEdBQUcscUJBQXFCO0FBQzFDLE9BQUssYUFBYSxLQUFLLHdCQUF3QjtBQUMvQyxPQUFLLGFBQWEsS0FBSyx3QkFBd0I7QUFDL0MsT0FBSyxhQUFhLEdBQUcscUJBQXFCO0FBQzFDLE1BQUksWUFBWTtBQUNoQixNQUFJLFNBQVMsUUFBUSxLQUFLLEdBQUcsUUFBUSxLQUFLLFNBQVM7QUFDbkQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksWUFBWTtBQUNoQixPQUFLLFFBQVEsQ0FBQyxLQUFLLFVBQVUsSUFBSSxTQUFTLEtBQUssUUFBUSxHQUFHLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztBQUM5RSxNQUFJLFFBQVE7QUFDZDtBQUVBLFNBQVMsZUFBZSxTQUF1QjtBQUM3QyxRQUFNLEVBQUUsS0FBSyxLQUFLLElBQUk7QUFDdEIsTUFBSSxLQUFLLFdBQVcsV0FBVyxFQUFHO0FBQ2xDLFFBQU0sTUFBTSxnQkFBZ0IsT0FBTyxJQUFJO0FBQ3ZDLFFBQU0sT0FBTyxLQUFLLFdBQVcsSUFBSSxDQUFDLGNBQWM7QUFDOUMsVUFBTSxPQUFPLFVBQVUsVUFBVSxTQUFTLE1BQU0sVUFBVSxVQUFVLFdBQVcsTUFBTTtBQUNyRixVQUFNLFFBQVEsT0FBTyxVQUFVLE1BQU0sUUFBUSxNQUFNLEtBQUssVUFBVSxXQUFXLEtBQUssVUFBVSxRQUFRLEtBQUs7QUFDekcsV0FBTyxFQUFFLFdBQVcsTUFBTSxHQUFHLElBQUksSUFBSSxVQUFVLFdBQVksUUFBUSxXQUFXLE9BQU8sU0FBUyxZQUFhLEVBQUUsR0FBRyxLQUFLLEdBQUc7QUFBQSxFQUMxSCxDQUFDO0FBQ0QsTUFBSSxPQUFPLFFBQVEsV0FBVztBQUM5QixRQUFNLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLElBQUksQ0FBQyxRQUFRLElBQUksWUFBWSxJQUFJLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0FBQ2pHLFFBQU0sSUFBSSxLQUFLLFNBQVMsS0FBSztBQUM3QixNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixZQUFVLEtBQUssSUFBSSxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQy9CLE1BQUksS0FBSztBQUNULE1BQUksT0FBTztBQUNYLE1BQUksT0FBTyxZQUFZLFdBQVc7QUFDbEMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksU0FBUyxRQUFRLFdBQVcsT0FBTyxPQUFPLGNBQWMsSUFBSSxNQUFNLEVBQUU7QUFDeEUsTUFBSSxPQUFPLFFBQVEsV0FBVztBQUM5QixPQUFLLFFBQVEsQ0FBQyxLQUFLLFVBQVU7QUFDM0IsVUFBTSxRQUFRLElBQUksVUFBVTtBQUM1QixRQUFJLFlBQVksVUFBVSxTQUFTLFlBQVksVUFBVSxXQUFXLFlBQVksSUFBSSxVQUFVLFdBQVcsWUFBWTtBQUNySCxRQUFJLFNBQVMsSUFBSSxNQUFNLElBQUksTUFBTSxLQUFLLFFBQVEsRUFBRTtBQUNoRCxRQUFJLFVBQVUsVUFBVTtBQUN0QixVQUFJLGNBQWMsSUFBSTtBQUN0QixVQUFJLFlBQVk7QUFDaEIsVUFBSSxVQUFVO0FBQ2QsVUFBSSxPQUFPLElBQUksTUFBTSxLQUFLLFFBQVEsRUFBRTtBQUNwQyxVQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLEVBQUUsT0FBTyxNQUFNLEtBQUssUUFBUSxFQUFFO0FBQ3RFLFVBQUksT0FBTztBQUFBLElBQ2I7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLFNBQVMsWUFBWSxTQUF1QjtBQUMxQyxRQUFNLEVBQUUsS0FBSyxNQUFNLE1BQU0sSUFBSTtBQUM3QixNQUFJLElBQUksZ0JBQWdCLE9BQU8sSUFBSTtBQUNuQyxhQUFXLFVBQVUsS0FBSyxTQUFTO0FBQ2pDLFVBQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEtBQUs7QUFDNUMsVUFBTSxPQUFPLFFBQVEsT0FBTyxNQUFNLEtBQUssSUFBSTtBQUMzQyxVQUFNLE9BQU8sT0FBTyxPQUFPLE1BQU0sUUFBUSxNQUFNO0FBQy9DLFFBQUksS0FBSztBQUNULFFBQUksY0FBYyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssT0FBTyxHQUFHLENBQUM7QUFDaEUsUUFBSSxPQUFPLFlBQVksV0FBVztBQUNsQyxVQUFNLElBQUksSUFBSSxZQUFZLElBQUksRUFBRSxRQUFRO0FBQ3hDLFVBQU0sSUFBSSxRQUFRLElBQUksSUFBSTtBQUMxQixRQUFJLFlBQVksT0FBTyxTQUFTLFNBQVMsNEJBQTRCLE9BQU8sU0FBUyxTQUFTLDJCQUEyQixPQUFPLFNBQVMsVUFBVSwyQkFBMkI7QUFDOUssY0FBVSxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRTtBQUM5QixRQUFJLEtBQUs7QUFDVCxRQUFJLFlBQVk7QUFDaEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksU0FBUyxNQUFNLFFBQVEsR0FBRyxJQUFJLEVBQUU7QUFDcEMsUUFBSSxRQUFRO0FBQ1osU0FBSztBQUFBLEVBQ1A7QUFDRjtBQUVBLFNBQVMsV0FBVyxTQUF1QjtBQUN6QyxRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxPQUFRO0FBQ2IsUUFBTSxFQUFFLEtBQUssT0FBTyxRQUFRLEtBQUssSUFBSTtBQUNyQyxRQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBQzdDLE1BQUksS0FBSztBQUNULE1BQUksY0FBYyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUk7QUFDeEMsUUFBTSxTQUFTLE9BQU8sT0FBTyxRQUFRLFFBQVEsTUFBTTtBQUNuRCxNQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzdCLFFBQU0sYUFBYSxLQUFLLEtBQUssUUFBUSxHQUFHO0FBQ3hDLFFBQU0sSUFBSTtBQUNWLFFBQU0sSUFBSSxXQUFXLFNBQVMsS0FBSyxPQUFPLFFBQVEsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sSUFBSSxRQUFRLElBQUksSUFBSTtBQUMxQixRQUFNLElBQUksU0FBUyxnQkFBZ0IsT0FBTyxJQUFJLElBQUk7QUFDbEQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYztBQUNsQixNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksYUFBYTtBQUNqQixZQUFVLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFO0FBQzdCLE1BQUksS0FBSztBQUNULE1BQUksY0FBYztBQUNsQixNQUFJLE9BQU87QUFDWCxNQUFJLFlBQVk7QUFDaEIsYUFBVyxRQUFRLENBQUMsS0FBSyxVQUFVLElBQUksU0FBUyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7QUFDakYsU0FBTyxRQUFRLFFBQVEsQ0FBQyxRQUFRLFVBQVU7QUFDeEMsVUFBTSxLQUFLLElBQUksV0FBVyxTQUFTLEtBQUssS0FBSyxRQUFRO0FBQ3JELFVBQU0sU0FBUyxPQUFPLFdBQVcsT0FBTztBQUN4QyxVQUFNLFFBQVEsT0FBTyxXQUFXLFVBQWEsQ0FBQztBQUM5QyxRQUFJLFFBQVE7QUFDVixZQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFZLEtBQUssS0FBSyxJQUFJLElBQUk7QUFDbkYsVUFBSSxZQUFZLHNCQUFzQixPQUFPLE9BQU8sSUFBSTtBQUN4RCxnQkFBVSxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLElBQUksQ0FBQztBQUM1QyxVQUFJLEtBQUs7QUFBQSxJQUNYO0FBQ0EsUUFBSSxjQUFjLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxLQUFLLFFBQVEsTUFBTTtBQUMzRCxRQUFJLE9BQU8sWUFBWSxXQUFXO0FBQ2xDLFFBQUksWUFBWTtBQUNoQixRQUFJLFNBQVMsR0FBRyxRQUFRLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFO0FBQzdDLFFBQUksWUFBWTtBQUNoQixRQUFJLE9BQU8sUUFBUSxXQUFXO0FBQzlCLFFBQUksU0FBUyxPQUFPLE9BQU8sTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLElBQUksS0FBSyxFQUFFO0FBQ2pFLFFBQUksY0FBYyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUk7QUFBQSxFQUMxQyxDQUFDO0FBQ0QsTUFBSSxRQUFRO0FBQ2Q7QUFHQSxTQUFTLFVBQVUsU0FBdUI7QUFDeEMsUUFBTSxRQUFRLFFBQVEsS0FBSztBQUMzQixNQUFJLENBQUMsU0FBUyxNQUFNLFFBQVEsV0FBVyxLQUFLLFFBQVEsS0FBSyxVQUFVLEdBQUk7QUFDdkUsUUFBTSxFQUFFLEtBQUssT0FBTyxJQUFJO0FBQ3hCLFFBQU0sWUFBWTtBQUNsQixRQUFNLGFBQWE7QUFDbkIsUUFBTSxJQUFJLFNBQVMsYUFBYTtBQUNoQyxRQUFNLFFBQVEsUUFBUSxDQUFDLFFBQVEsVUFBVTtBQUN2QyxVQUFNLElBQUksS0FBSyxTQUFTLFlBQVk7QUFDcEMsUUFBSSxLQUFLO0FBQ1QsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLFlBQVk7QUFDaEIsY0FBVSxLQUFLLEdBQUcsR0FBRyxXQUFXLFlBQVksQ0FBQztBQUM3QyxRQUFJLEtBQUs7QUFDVCxRQUFJLE9BQU87QUFDWCxRQUFJLFlBQVksT0FBTztBQUN2QixRQUFJLFNBQVMsR0FBRyxJQUFJLEdBQUcsR0FBRyxhQUFhLEVBQUU7QUFDekMsUUFBSSxPQUFPLFlBQVksV0FBVztBQUNsQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxTQUFTLE9BQU8sT0FBTyxNQUFNLFFBQVEsTUFBTSxHQUFHLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDaEUsUUFBSSxPQUFPLFlBQVksV0FBVztBQUNsQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksU0FBUyxNQUFNLE9BQU8sS0FBSyxHQUFHLE9BQU8sS0FBSyxTQUFTLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLEVBQUUsSUFBSSxJQUFJLFlBQVksSUFBSSxJQUFJLEVBQUU7QUFDeEgsUUFBSSxZQUFZO0FBQ2hCLFFBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLFlBQVksSUFBSSxHQUFHLE9BQU8sS0FBSyxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssR0FBRyxPQUFPLEtBQUssT0FBTyxRQUFRLE1BQU0sWUFBWSxTQUFTO0FBQ3pJLFVBQU0sVUFBVSxPQUFPLFdBQVcsVUFBYSxPQUFPLEtBQUssT0FBTyxXQUFXLEtBQUssSUFBSSxHQUFHLE9BQU8sU0FBUyxPQUFPLE9BQU8sSUFBSTtBQUMzSCxRQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxZQUFZLElBQUksR0FBRyxTQUFTLFNBQVM7QUFDOUQsUUFBSSxPQUFPLFFBQVEsV0FBVztBQUM5QixRQUFJLEtBQUssSUFBSTtBQUNiLGVBQVcsU0FBUyxPQUFPLFFBQVE7QUFDakMsWUFBTSxPQUFPLE9BQU8sTUFBTSxNQUFNLFFBQVEsTUFBTTtBQUM5QyxZQUFNLElBQUksSUFBSSxZQUFZLElBQUksRUFBRSxRQUFRO0FBQ3hDLFVBQUksS0FBSyxJQUFJLElBQUksWUFBWSxFQUFHO0FBQ2hDLFVBQUksWUFBWSxNQUFNLFNBQVMsSUFBSSw0QkFBNEI7QUFDL0QsZ0JBQVUsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztBQUNuQyxVQUFJLEtBQUs7QUFDVCxVQUFJLE1BQU0sUUFBUSxHQUFHO0FBQ25CLFlBQUksWUFBWTtBQUNoQixrQkFBVSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDO0FBQzlELFlBQUksS0FBSztBQUFBLE1BQ1g7QUFDQSxVQUFJLFlBQVk7QUFDaEIsVUFBSSxTQUFTLE1BQU0sS0FBSyxHQUFHLElBQUksRUFBRTtBQUNqQyxZQUFNLElBQUk7QUFBQSxJQUNaO0FBQ0EsUUFBSSxRQUFRO0FBQUEsRUFDZCxDQUFDO0FBQ0g7QUFFQSxTQUFTLFNBQVMsU0FBdUI7QUFDdkMsUUFBTSxFQUFFLE1BQU0sS0FBSyxJQUFJLFFBQVE7QUFDL0IsTUFBSSxRQUFRLEtBQUs7QUFDakIsTUFBSSxPQUFPLEtBQUssSUFBSyxTQUFRLFFBQVEsS0FBSyxRQUFRLEtBQUssT0FBTyxLQUFLLFFBQVMsS0FBSyxLQUFLLEtBQUssU0FBUyxPQUFPLEtBQUssU0FBVSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxLQUFLO0FBQzNKLE1BQUksU0FBUyxLQUFPO0FBQ3BCLFVBQVEsSUFBSSxZQUFZLG1CQUFtQixLQUFLLElBQUksR0FBRyxLQUFLLENBQUM7QUFDN0QsVUFBUSxJQUFJLFNBQVMsR0FBRyxHQUFHLFFBQVEsT0FBTyxRQUFRLE1BQU07QUFDMUQ7QUFJQSxTQUFTLElBQUksS0FBWSxHQUFXLEdBQVcsR0FBVyxHQUFXLE9BQWUsT0FBZTtBQUNqRyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDdkIsTUFBSSxZQUFZO0FBQ2hCLE1BQUksU0FBUyxHQUFHLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQzNEO0FBR08sZ0JBQVMsS0FBSyxLQUFZLE1BQWMsVUFBNEI7QUFDekUsUUFBTSxPQUFpQixDQUFDO0FBQ3hCLGFBQVcsYUFBYSxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3hDLFVBQU0sU0FBUyxVQUFVLE1BQU0sa0NBQWtDLEtBQUssQ0FBQztBQUN2RSxRQUFJLE1BQU07QUFDVixlQUFXLFNBQVMsUUFBUTtBQUMxQixZQUFNLE9BQU8sTUFBTTtBQUNuQixVQUFJLE9BQU8sSUFBSSxZQUFZLElBQUksRUFBRSxRQUFRLFlBQVksQ0FBQyx1QkFBdUIsS0FBSyxLQUFLLEdBQUc7QUFDeEYsYUFBSyxLQUFLLElBQUksUUFBUSxDQUFDO0FBQ3ZCLGNBQU0sTUFBTSxVQUFVO0FBQUEsTUFDeEIsTUFBTyxPQUFNO0FBQUEsSUFDZjtBQUNBLFFBQUksSUFBSyxNQUFLLEtBQUssSUFBSSxRQUFRLENBQUM7QUFBQSxFQUNsQztBQUNBLFNBQU8sS0FBSyxTQUFTLElBQUksT0FBTyxDQUFDLEVBQUU7QUFDckM7QUFFQSxTQUFTLFVBQVUsS0FBWSxHQUFXLEdBQVcsR0FBVyxHQUFXLEdBQVc7QUFDcEYsTUFBSSxVQUFVO0FBQ2QsTUFBSSxPQUFPLElBQUksR0FBRyxDQUFDO0FBQ25CLE1BQUksTUFBTSxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUM7QUFDbkMsTUFBSSxNQUFNLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQztBQUNuQyxNQUFJLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDM0IsTUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO0FBQzNCLE1BQUksVUFBVTtBQUNoQjtBQUVBLFNBQVMsV0FBVyxLQUFZLEdBQVcsR0FBVyxHQUFXLEdBQVc7QUFDMUUsUUFBTSxTQUFrQixDQUFDO0FBQ3pCLFFBQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNsRCxRQUFNLE9BQU8sQ0FBQyxNQUFxQjtBQUNqQyxVQUFNLElBQUksSUFBSSxLQUFLLElBQUk7QUFDdkIsUUFBSSxJQUFJLEVBQUcsUUFBTyxFQUFFLEdBQUcsSUFBSSxHQUFHLEVBQUU7QUFDaEMsUUFBSSxJQUFJLElBQUksRUFBRyxRQUFPLEVBQUUsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRTtBQUMvQyxRQUFJLElBQUksSUFBSSxJQUFJLEVBQUcsUUFBTyxFQUFFLEdBQUcsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdELFdBQU8sRUFBRSxHQUFHLEdBQUcsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUc7QUFBQSxFQUN6QztBQUNBLFdBQVMsUUFBUSxHQUFHLFFBQVEsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUNqRCxVQUFNLEtBQUssS0FBSyxTQUFTLFFBQVEsRUFBRTtBQUNuQyxVQUFNLE1BQU0sUUFBUSxNQUFNLElBQUksSUFBSTtBQUNsQyxVQUFNLEtBQUssSUFBSSxJQUFJO0FBQ25CLFVBQU0sS0FBSyxJQUFJLElBQUk7QUFDbkIsVUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxLQUFLO0FBQzlDLFdBQU8sS0FBSyxFQUFFLEdBQUcsR0FBRyxLQUFNLEdBQUcsSUFBSSxNQUFNLElBQUssS0FBSyxHQUFHLEdBQUcsS0FBTSxHQUFHLElBQUksTUFBTSxJQUFLLElBQUksQ0FBQztBQUFBLEVBQ3RGO0FBQ0EsTUFBSSxPQUFPLE9BQU8sQ0FBQyxFQUFHLEdBQUcsT0FBTyxDQUFDLEVBQUcsQ0FBQztBQUNyQyxhQUFXLFNBQVMsT0FBTyxNQUFNLENBQUMsRUFBRyxLQUFJLE9BQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQztBQUNoRSxNQUFJLFVBQVU7QUFDaEI7QUFFQSxTQUFTLFNBQVMsU0FBaUQsT0FBYyxLQUFhO0FBQzVGLFNBQU8sTUFBTSxLQUFLLENBQUMsT0FBTyxNQUFNLEtBQUssQ0FBQyxPQUFPLE1BQU0sS0FBSyxRQUFRLFFBQVEsT0FBTyxNQUFNLEtBQUssUUFBUSxTQUFTO0FBQzdHO0FBRUEsU0FBUyxNQUFNLE9BQWUsS0FBYSxLQUFhO0FBQ3RELFNBQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUcsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLENBQUM7QUFDMUQ7QUFFQSxTQUFTLFFBQVEsR0FBVztBQUMxQixTQUFPLEtBQUssSUFBSSxNQUFNLElBQUk7QUFDNUI7IiwibmFtZXMiOlsiYmFyIl19