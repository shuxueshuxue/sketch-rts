import { shipProfile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { creatureShadow } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/painted-creatures.ts";
import { unitGlyphScale } from "/@fs/tmp/sketch-queue-source-42bd/src/client/glyphs.ts";
import { engagedEntityIds } from "/@fs/tmp/sketch-queue-source-42bd/src/client/health-bars.ts";
const CELL = 256;
export class PresentationViewIndex {
  units = /* @__PURE__ */ new Map();
  entities = /* @__PURE__ */ new Map();
  hits = /* @__PURE__ */ new Map();
  crew = [];
  sailing = [];
  ships = [];
  builders = [];
  aiming = [];
  snapshot;
  tick = -1;
  unitArray;
  buildingArray;
  effectArray;
  projectileArray;
  counts = "";
  motion;
  cells = /* @__PURE__ */ new Map();
  entries = [];
  byId = /* @__PURE__ */ new Map();
  buildingIds = /* @__PURE__ */ new Set();
  special = [];
  seen = new Uint32Array(0);
  stamp = 0;
  candidateEntries = [];
  candidates = [];
  viewBounds = { left: 0, top: 0, right: 0, bottom: 0 };
  viewAreas = [this.viewBounds];
  engaged;
  builds = 0;
  update(snapshot, motion) {
    const counts = `${snapshot.units.length}:${snapshot.buildings.length}:${snapshot.effects.length}:${snapshot.projectiles.length}`;
    if (snapshot === this.snapshot && snapshot.tick === this.tick && snapshot.units === this.unitArray && snapshot.buildings === this.buildingArray && snapshot.effects === this.effectArray && snapshot.projectiles === this.projectileArray && counts === this.counts && motion === this.motion) return false;
    this.snapshot = snapshot;
    this.tick = snapshot.tick;
    this.unitArray = snapshot.units;
    this.buildingArray = snapshot.buildings;
    this.effectArray = snapshot.effects;
    this.projectileArray = snapshot.projectiles;
    this.counts = counts;
    this.motion = motion;
    this.builds++;
    this.hits.clear();
    this.entries.length = 0;
    this.special.length = 0;
    this.crew.length = 0;
    this.sailing.length = 0;
    this.ships.length = 0;
    this.builders.length = 0;
    this.aiming.length = 0;
    this.engaged = void 0;
    if (this.seen.length < snapshot.units.length) this.seen = new Uint32Array(snapshot.units.length);
    for (let order = 0; order < snapshot.units.length; order++) {
      const unit = snapshot.units[order], naval = shipProfile(unit);
      this.units.set(unit.id, unit);
      this.entities.set(unit.id, unit);
      if (unit.deck) this.crew.push(unit);
      if (unit.sailing) this.sailing.push(unit);
      if (naval) this.ships.push(unit);
      if (unit.kind === "worker" && unit.order.type === "build") this.builders.push(unit);
      if (unit.aim) this.aiming.push(unit);
      let entry = this.byId.get(unit.id);
      const pad = entry && entry.kind === unit.kind && entry.radius === unit.radius ? entry.pad : Math.max(256, unit.radius * 8, 180 + Math.abs((creatureShadow(unit.kind)?.y ?? 17) * unitGlyphScale(unit.radius)));
      const sweep = motion?.bounds(unit), from = sweep?.from ?? unit, to = sweep?.to ?? unit;
      const left = Math.min(unit.x, from.x, to.x) - pad, right = Math.max(unit.x, from.x, to.x) + pad, top = Math.min(unit.y, from.y, to.y) - pad, bottom = Math.max(unit.y, from.y, to.y) + pad;
      const firstCol = Math.floor(left / CELL), lastCol = Math.floor(right / CELL), firstRow = Math.floor(top / CELL), lastRow = Math.floor(bottom / CELL);
      const special = Boolean(unit.deck || unit.variant !== void 0 || naval || (lastCol - firstCol + 1) * (lastRow - firstRow + 1) > 64);
      const relocated = !entry || entry.special !== special || entry.firstCol !== firstCol || entry.lastCol !== lastCol || entry.firstRow !== firstRow || entry.lastRow !== lastRow;
      if (entry && relocated) this.removeCells(entry);
      if (!entry) {
        entry = { unit, order, left, right, top, bottom, pad, kind: unit.kind, radius: unit.radius, epoch: this.builds, special, firstCol, lastCol, firstRow, lastRow };
        this.byId.set(unit.id, entry);
      } else {
        entry.unit = unit;
        entry.order = order;
        entry.left = left;
        entry.right = right;
        entry.top = top;
        entry.bottom = bottom;
        entry.pad = pad;
        entry.kind = unit.kind;
        entry.radius = unit.radius;
        entry.epoch = this.builds;
        entry.special = special;
        entry.firstCol = firstCol;
        entry.lastCol = lastCol;
        entry.firstRow = firstRow;
        entry.lastRow = lastRow;
      }
      this.entries.push(entry);
      if (special) {
        this.special.push(entry);
        continue;
      }
      if (relocated) for (let row = firstRow; row <= lastRow; row++) for (let col = firstCol; col <= lastCol; col++) {
        const key = `${col}:${row}`, cell = this.cells.get(key);
        if (cell) cell.push(entry);
        else this.cells.set(key, [entry]);
      }
    }
    for (const [id, entry] of this.byId) if (entry.epoch !== this.builds) {
      this.removeCells(entry);
      this.byId.delete(id);
      this.units.delete(id);
      this.entities.delete(id);
    }
    const oldBuildings = this.buildingIds;
    this.buildingIds = /* @__PURE__ */ new Set();
    for (const building of snapshot.buildings) {
      this.entities.set(building.id, building);
      this.buildingIds.add(building.id);
      oldBuildings.delete(building.id);
    }
    for (const id of oldBuildings) if (!this.units.has(id)) this.entities.delete(id);
    for (const effect of snapshot.effects) if (effect.type === "hit" && effect.unitId && !this.hits.has(effect.unitId)) this.hits.set(effect.unitId, effect);
    return true;
  }
  removeCells(entry) {
    if (entry.special) return;
    for (let row = entry.firstRow; row <= entry.lastRow; row++) for (let col = entry.firstCol; col <= entry.lastCol; col++) {
      const key = `${col}:${row}`, cell = this.cells.get(key);
      if (!cell) continue;
      const at = cell.indexOf(entry);
      if (at >= 0) cell.splice(at, 1);
      if (!cell.length) this.cells.delete(key);
    }
  }
  query(view) {
    const zoom = view.zoom ?? 1, bounds = this.viewBounds;
    bounds.left = view.x;
    bounds.top = view.y;
    bounds.right = view.x + view.width / zoom;
    bounds.bottom = view.y + view.height / zoom;
    return this.queryBoundsUnion(this.viewAreas);
  }
  /** World contact areas are independent of the camera. Return one deduplicated
   * snapshot-ordered set so overlapping bursts share their receiver capsules.
   * This borrowed result is consumed synchronously before another query. */
  queryBoundsUnion(areas) {
    this.candidateEntries.length = 0;
    this.candidates.length = 0;
    if (++this.stamp >= 4294967295) {
      this.seen.fill(0);
      this.stamp = 1;
    }
    const add = (entry, area) => {
      if (this.seen[entry.order] === this.stamp) return;
      if (entry.right >= area.left && entry.left <= area.right && entry.bottom >= area.top && entry.top <= area.bottom) {
        this.seen[entry.order] = this.stamp;
        this.candidateEntries.push(entry);
      } else if (areas.length === 1) this.seen[entry.order] = this.stamp;
    };
    for (const area of areas) {
      const firstCol = Math.floor(area.left / CELL), lastCol = Math.floor(area.right / CELL), firstRow = Math.floor(area.top / CELL), lastRow = Math.floor(area.bottom / CELL);
      if ((lastCol - firstCol + 1) * (lastRow - firstRow + 1) > Math.max(64, this.cells.size * 2)) {
        for (const entry of this.entries) if (!entry.special) add(entry, area);
      } else for (let row = firstRow; row <= lastRow; row++) for (let col = firstCol; col <= lastCol; col++) for (const entry of this.cells.get(`${col}:${row}`) ?? []) add(entry, area);
    }
    if (areas.length) {
      for (const entry of this.special) if (this.seen[entry.order] !== this.stamp) {
        this.seen[entry.order] = this.stamp;
        this.candidateEntries.push(entry);
      }
    }
    this.candidateEntries.sort((a, b) => a.order - b.order);
    for (const entry of this.candidateEntries) this.candidates.push(entry.unit);
    return this.candidates;
  }
  engagedIds() {
    return this.engaged ??= this.snapshot ? engagedEntityIds(this.snapshot) : /* @__PURE__ */ new Set();
  }
  stats() {
    return { builds: this.builds, units: this.units.size, cells: this.cells.size, candidates: this.candidates.length, special: this.special.length };
  }
  reset() {
    this.snapshot = void 0;
    this.tick = -1;
    this.unitArray = void 0;
    this.buildingArray = void 0;
    this.effectArray = void 0;
    this.projectileArray = void 0;
    this.motion = void 0;
    this.counts = "";
    this.units.clear();
    this.entities.clear();
    this.hits.clear();
    this.cells.clear();
    this.byId.clear();
    this.buildingIds.clear();
    this.entries.length = 0;
    this.special.length = 0;
    this.crew.length = 0;
    this.sailing.length = 0;
    this.ships.length = 0;
    this.builders.length = 0;
    this.aiming.length = 0;
    this.candidates.length = 0;
    this.candidateEntries.length = 0;
    this.engaged = void 0;
    this.seen = new Uint32Array(0);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZXNlbnRhdGlvbi12aWV3LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBTbmFwc2hvdCBmYWN0cyBhcmUgaW5kZXhlZCBvbmNlOyBjYW1lcmEgcXVlcmllcyBuZXZlciBzY2FuIHRoZSB3aG9sZSBhcm15LlxuICogVGhpcyBvd25zIHByZXNlbnRhdGlvbiBjYW5kaWRhdGVzIG9ubHksIG5vdCBzaW11bGF0aW9uIG9yIGV2ZW50IGhpc3RvcnkuICovXG5pbXBvcnQgdHlwZSB7R2FtZVNuYXBzaG90LCBVbml0LCBXb3JsZEVmZmVjdH0gZnJvbSAnLi4vc2hhcmVkL3R5cGVzJztcbmltcG9ydCB7c2hpcFByb2ZpbGV9IGZyb20gJy4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5JztcbmltcG9ydCB7Y3JlYXR1cmVTaGFkb3d9IGZyb20gJy4vYXJ0L3BhaW50ZWQtY3JlYXR1cmVzJztcbmltcG9ydCB7dW5pdEdseXBoU2NhbGV9IGZyb20gJy4vZ2x5cGhzJztcbmltcG9ydCB7ZW5nYWdlZEVudGl0eUlkc30gZnJvbSAnLi9oZWFsdGgtYmFycyc7XG5pbXBvcnQgdHlwZSB7VW5pdE1vdGlvblNtb290aGVyfSBmcm9tICcuL3VuaXQtbW90aW9uJztcbmltcG9ydCB0eXBlIHtXb3JsZFZpZXd9IGZyb20gJy4vd29ybGQtcmVuZGVyZXInO1xuXG5jb25zdCBDRUxMPTI1NjtcbnR5cGUgQm91bmRzPXtsZWZ0Om51bWJlcjt0b3A6bnVtYmVyO3JpZ2h0Om51bWJlcjtib3R0b206bnVtYmVyfTtcbnR5cGUgRW50cnk9e3VuaXQ6VW5pdDtvcmRlcjpudW1iZXI7bGVmdDpudW1iZXI7cmlnaHQ6bnVtYmVyO3RvcDpudW1iZXI7Ym90dG9tOm51bWJlcjtzcGVjaWFsOmJvb2xlYW47cGFkOm51bWJlcjtraW5kOlVuaXRbJ2tpbmQnXTtyYWRpdXM6bnVtYmVyO2Vwb2NoOm51bWJlcjtmaXJzdENvbDpudW1iZXI7bGFzdENvbDpudW1iZXI7Zmlyc3RSb3c6bnVtYmVyO2xhc3RSb3c6bnVtYmVyfTtcbmV4cG9ydCBjbGFzcyBQcmVzZW50YXRpb25WaWV3SW5kZXgge1xuICByZWFkb25seSB1bml0cz1uZXcgTWFwPHN0cmluZyxVbml0PigpO1xuICByZWFkb25seSBlbnRpdGllcz1uZXcgTWFwPHN0cmluZyxVbml0fEdhbWVTbmFwc2hvdFsnYnVpbGRpbmdzJ11bbnVtYmVyXT4oKTtcbiAgcmVhZG9ubHkgaGl0cz1uZXcgTWFwPHN0cmluZyxXb3JsZEVmZmVjdD4oKTtcbiAgcmVhZG9ubHkgY3JldzpVbml0W109W107XG4gIHJlYWRvbmx5IHNhaWxpbmc6VW5pdFtdPVtdO1xuICByZWFkb25seSBzaGlwczpVbml0W109W107XG4gIHJlYWRvbmx5IGJ1aWxkZXJzOlVuaXRbXT1bXTtcbiAgcmVhZG9ubHkgYWltaW5nOlVuaXRbXT1bXTtcbiAgcHJpdmF0ZSBzbmFwc2hvdDpHYW1lU25hcHNob3R8dW5kZWZpbmVkO1xuICBwcml2YXRlIHRpY2s9LTE7XG4gIHByaXZhdGUgdW5pdEFycmF5OlVuaXRbXXx1bmRlZmluZWQ7XG4gIHByaXZhdGUgYnVpbGRpbmdBcnJheTpHYW1lU25hcHNob3RbJ2J1aWxkaW5ncyddfHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBlZmZlY3RBcnJheTpHYW1lU25hcHNob3RbJ2VmZmVjdHMnXXx1bmRlZmluZWQ7XG4gIHByaXZhdGUgcHJvamVjdGlsZUFycmF5OkdhbWVTbmFwc2hvdFsncHJvamVjdGlsZXMnXXx1bmRlZmluZWQ7XG4gIHByaXZhdGUgY291bnRzPScnO1xuICBwcml2YXRlIG1vdGlvbjpVbml0TW90aW9uU21vb3RoZXJ8dW5kZWZpbmVkO1xuICBwcml2YXRlIGNlbGxzPW5ldyBNYXA8c3RyaW5nLEVudHJ5W10+KCk7XG4gIHByaXZhdGUgZW50cmllczpFbnRyeVtdPVtdO1xuICBwcml2YXRlIGJ5SWQ9bmV3IE1hcDxzdHJpbmcsRW50cnk+KCk7XG4gIHByaXZhdGUgYnVpbGRpbmdJZHM9bmV3IFNldDxzdHJpbmc+KCk7XG4gIHByaXZhdGUgc3BlY2lhbDpFbnRyeVtdPVtdO1xuICBwcml2YXRlIHNlZW49bmV3IFVpbnQzMkFycmF5KDApO1xuICBwcml2YXRlIHN0YW1wPTA7XG4gIHByaXZhdGUgY2FuZGlkYXRlRW50cmllczpFbnRyeVtdPVtdO1xuICBwcml2YXRlIGNhbmRpZGF0ZXM6VW5pdFtdPVtdO1xuICBwcml2YXRlIHZpZXdCb3VuZHM6Qm91bmRzPXtsZWZ0OjAsdG9wOjAscmlnaHQ6MCxib3R0b206MH07XG4gIHByaXZhdGUgdmlld0FyZWFzPVt0aGlzLnZpZXdCb3VuZHNdO1xuICBwcml2YXRlIGVuZ2FnZWQ6UmVhZG9ubHlTZXQ8c3RyaW5nPnx1bmRlZmluZWQ7XG4gIHByaXZhdGUgYnVpbGRzPTA7XG5cbiAgdXBkYXRlKHNuYXBzaG90OkdhbWVTbmFwc2hvdCxtb3Rpb24/OlVuaXRNb3Rpb25TbW9vdGhlcil7XG4gICAgY29uc3QgY291bnRzPWAke3NuYXBzaG90LnVuaXRzLmxlbmd0aH06JHtzbmFwc2hvdC5idWlsZGluZ3MubGVuZ3RofToke3NuYXBzaG90LmVmZmVjdHMubGVuZ3RofToke3NuYXBzaG90LnByb2plY3RpbGVzLmxlbmd0aH1gO1xuICAgIGlmKHNuYXBzaG90PT09dGhpcy5zbmFwc2hvdCYmc25hcHNob3QudGljaz09PXRoaXMudGljayYmc25hcHNob3QudW5pdHM9PT10aGlzLnVuaXRBcnJheSYmc25hcHNob3QuYnVpbGRpbmdzPT09dGhpcy5idWlsZGluZ0FycmF5JiZzbmFwc2hvdC5lZmZlY3RzPT09dGhpcy5lZmZlY3RBcnJheSYmc25hcHNob3QucHJvamVjdGlsZXM9PT10aGlzLnByb2plY3RpbGVBcnJheSYmY291bnRzPT09dGhpcy5jb3VudHMmJm1vdGlvbj09PXRoaXMubW90aW9uKXJldHVybiBmYWxzZTtcbiAgICB0aGlzLnNuYXBzaG90PXNuYXBzaG90O3RoaXMudGljaz1zbmFwc2hvdC50aWNrO3RoaXMudW5pdEFycmF5PXNuYXBzaG90LnVuaXRzO3RoaXMuYnVpbGRpbmdBcnJheT1zbmFwc2hvdC5idWlsZGluZ3M7dGhpcy5lZmZlY3RBcnJheT1zbmFwc2hvdC5lZmZlY3RzO3RoaXMucHJvamVjdGlsZUFycmF5PXNuYXBzaG90LnByb2plY3RpbGVzO3RoaXMuY291bnRzPWNvdW50czt0aGlzLm1vdGlvbj1tb3Rpb247dGhpcy5idWlsZHMrKztcbiAgICB0aGlzLmhpdHMuY2xlYXIoKTt0aGlzLmVudHJpZXMubGVuZ3RoPTA7dGhpcy5zcGVjaWFsLmxlbmd0aD0wO3RoaXMuY3Jldy5sZW5ndGg9MDt0aGlzLnNhaWxpbmcubGVuZ3RoPTA7dGhpcy5zaGlwcy5sZW5ndGg9MDt0aGlzLmJ1aWxkZXJzLmxlbmd0aD0wO3RoaXMuYWltaW5nLmxlbmd0aD0wO3RoaXMuZW5nYWdlZD11bmRlZmluZWQ7XG4gICAgaWYodGhpcy5zZWVuLmxlbmd0aDxzbmFwc2hvdC51bml0cy5sZW5ndGgpdGhpcy5zZWVuPW5ldyBVaW50MzJBcnJheShzbmFwc2hvdC51bml0cy5sZW5ndGgpO1xuICAgIGZvcihsZXQgb3JkZXI9MDtvcmRlcjxzbmFwc2hvdC51bml0cy5sZW5ndGg7b3JkZXIrKyl7XG4gICAgICBjb25zdCB1bml0PXNuYXBzaG90LnVuaXRzW29yZGVyXSEsbmF2YWw9c2hpcFByb2ZpbGUodW5pdCk7dGhpcy51bml0cy5zZXQodW5pdC5pZCx1bml0KTt0aGlzLmVudGl0aWVzLnNldCh1bml0LmlkLHVuaXQpO1xuICAgICAgaWYodW5pdC5kZWNrKXRoaXMuY3Jldy5wdXNoKHVuaXQpO1xuICAgICAgaWYodW5pdC5zYWlsaW5nKXRoaXMuc2FpbGluZy5wdXNoKHVuaXQpO1xuICAgICAgaWYobmF2YWwpdGhpcy5zaGlwcy5wdXNoKHVuaXQpO1xuICAgICAgaWYodW5pdC5raW5kPT09J3dvcmtlcicmJnVuaXQub3JkZXIudHlwZT09PSdidWlsZCcpdGhpcy5idWlsZGVycy5wdXNoKHVuaXQpO1xuICAgICAgaWYodW5pdC5haW0pdGhpcy5haW1pbmcucHVzaCh1bml0KTtcbiAgICAgIC8vIERlY2tzIHJvdGF0ZSBhbmQgc3RvcnkgcGFpbnRlcnMgbmVlZCBub3QgaGF2ZSBib3VuZGVkIGF1dGhvcmVkIGFydC5cbiAgICAgIC8vIEtlZXAgdGhlaXIgZXhpc3RpbmcgZXhhY3QgcG9zaXRpb25pbmcgcGF0aDsgb3JkaW5hcnkgZ3JvdW5kIGFybWllc1xuICAgICAgLy8gYWNjb3VudCBmb3IgdGhlIGxhcmdlIG1ham9yaXR5IG9mIHdvcmxkIGVudGl0aWVzLlxuICAgICAgbGV0IGVudHJ5PXRoaXMuYnlJZC5nZXQodW5pdC5pZCk7XG4gICAgICBjb25zdCBwYWQ9ZW50cnkmJmVudHJ5LmtpbmQ9PT11bml0LmtpbmQmJmVudHJ5LnJhZGl1cz09PXVuaXQucmFkaXVzP2VudHJ5LnBhZDpNYXRoLm1heCgyNTYsdW5pdC5yYWRpdXMqOCwxODArTWF0aC5hYnMoKGNyZWF0dXJlU2hhZG93KHVuaXQua2luZCk/Lnk/PzE3KSp1bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cykpKTtcbiAgICAgIGNvbnN0IHN3ZWVwPW1vdGlvbj8uYm91bmRzKHVuaXQpLGZyb209c3dlZXA/LmZyb20/P3VuaXQsdG89c3dlZXA/LnRvPz91bml0O1xuICAgICAgY29uc3QgbGVmdD1NYXRoLm1pbih1bml0LngsZnJvbS54LHRvLngpLXBhZCxyaWdodD1NYXRoLm1heCh1bml0LngsZnJvbS54LHRvLngpK3BhZCx0b3A9TWF0aC5taW4odW5pdC55LGZyb20ueSx0by55KS1wYWQsYm90dG9tPU1hdGgubWF4KHVuaXQueSxmcm9tLnksdG8ueSkrcGFkO1xuICAgICAgY29uc3QgZmlyc3RDb2w9TWF0aC5mbG9vcihsZWZ0L0NFTEwpLGxhc3RDb2w9TWF0aC5mbG9vcihyaWdodC9DRUxMKSxmaXJzdFJvdz1NYXRoLmZsb29yKHRvcC9DRUxMKSxsYXN0Um93PU1hdGguZmxvb3IoYm90dG9tL0NFTEwpO1xuICAgICAgY29uc3Qgc3BlY2lhbD1Cb29sZWFuKHVuaXQuZGVja3x8dW5pdC52YXJpYW50IT09dW5kZWZpbmVkfHxuYXZhbHx8KGxhc3RDb2wtZmlyc3RDb2wrMSkqKGxhc3RSb3ctZmlyc3RSb3crMSk+NjQpO1xuICAgICAgY29uc3QgcmVsb2NhdGVkPSFlbnRyeXx8ZW50cnkuc3BlY2lhbCE9PXNwZWNpYWx8fGVudHJ5LmZpcnN0Q29sIT09Zmlyc3RDb2x8fGVudHJ5Lmxhc3RDb2whPT1sYXN0Q29sfHxlbnRyeS5maXJzdFJvdyE9PWZpcnN0Um93fHxlbnRyeS5sYXN0Um93IT09bGFzdFJvdztcbiAgICAgIGlmKGVudHJ5JiZyZWxvY2F0ZWQpdGhpcy5yZW1vdmVDZWxscyhlbnRyeSk7XG4gICAgICBpZighZW50cnkpe2VudHJ5PXt1bml0LG9yZGVyLGxlZnQscmlnaHQsdG9wLGJvdHRvbSxwYWQsa2luZDp1bml0LmtpbmQscmFkaXVzOnVuaXQucmFkaXVzLGVwb2NoOnRoaXMuYnVpbGRzLHNwZWNpYWwsZmlyc3RDb2wsbGFzdENvbCxmaXJzdFJvdyxsYXN0Um93fTt0aGlzLmJ5SWQuc2V0KHVuaXQuaWQsZW50cnkpO31cbiAgICAgIGVsc2V7ZW50cnkudW5pdD11bml0O2VudHJ5Lm9yZGVyPW9yZGVyO2VudHJ5LmxlZnQ9bGVmdDtlbnRyeS5yaWdodD1yaWdodDtlbnRyeS50b3A9dG9wO2VudHJ5LmJvdHRvbT1ib3R0b207ZW50cnkucGFkPXBhZDtlbnRyeS5raW5kPXVuaXQua2luZDtlbnRyeS5yYWRpdXM9dW5pdC5yYWRpdXM7ZW50cnkuZXBvY2g9dGhpcy5idWlsZHM7ZW50cnkuc3BlY2lhbD1zcGVjaWFsO2VudHJ5LmZpcnN0Q29sPWZpcnN0Q29sO2VudHJ5Lmxhc3RDb2w9bGFzdENvbDtlbnRyeS5maXJzdFJvdz1maXJzdFJvdztlbnRyeS5sYXN0Um93PWxhc3RSb3c7fVxuICAgICAgdGhpcy5lbnRyaWVzLnB1c2goZW50cnkpO1xuICAgICAgLy8gQW4gZXhjZXB0aW9uYWwgbG9uZyBpbnRlcnBvbGF0aW9uIGNhbm5vdCBhbGxvY2F0ZSBhbiB1bmJvdW5kZWQgZ3JpZC5cbiAgICAgIGlmKHNwZWNpYWwpe3RoaXMuc3BlY2lhbC5wdXNoKGVudHJ5KTtjb250aW51ZTt9XG4gICAgICBpZihyZWxvY2F0ZWQpZm9yKGxldCByb3c9Zmlyc3RSb3c7cm93PD1sYXN0Um93O3JvdysrKWZvcihsZXQgY29sPWZpcnN0Q29sO2NvbDw9bGFzdENvbDtjb2wrKyl7XG4gICAgICAgIGNvbnN0IGtleT1gJHtjb2x9OiR7cm93fWAsY2VsbD10aGlzLmNlbGxzLmdldChrZXkpO1xuICAgICAgICBpZihjZWxsKWNlbGwucHVzaChlbnRyeSk7ZWxzZSB0aGlzLmNlbGxzLnNldChrZXksW2VudHJ5XSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvcihjb25zdCBbaWQsZW50cnldIG9mIHRoaXMuYnlJZClpZihlbnRyeS5lcG9jaCE9PXRoaXMuYnVpbGRzKXt0aGlzLnJlbW92ZUNlbGxzKGVudHJ5KTt0aGlzLmJ5SWQuZGVsZXRlKGlkKTt0aGlzLnVuaXRzLmRlbGV0ZShpZCk7dGhpcy5lbnRpdGllcy5kZWxldGUoaWQpO31cbiAgICBjb25zdCBvbGRCdWlsZGluZ3M9dGhpcy5idWlsZGluZ0lkczt0aGlzLmJ1aWxkaW5nSWRzPW5ldyBTZXQoKTtcbiAgICBmb3IoY29uc3QgYnVpbGRpbmcgb2Ygc25hcHNob3QuYnVpbGRpbmdzKXt0aGlzLmVudGl0aWVzLnNldChidWlsZGluZy5pZCxidWlsZGluZyk7dGhpcy5idWlsZGluZ0lkcy5hZGQoYnVpbGRpbmcuaWQpO29sZEJ1aWxkaW5ncy5kZWxldGUoYnVpbGRpbmcuaWQpO31cbiAgICBmb3IoY29uc3QgaWQgb2Ygb2xkQnVpbGRpbmdzKWlmKCF0aGlzLnVuaXRzLmhhcyhpZCkpdGhpcy5lbnRpdGllcy5kZWxldGUoaWQpO1xuICAgIGZvcihjb25zdCBlZmZlY3Qgb2Ygc25hcHNob3QuZWZmZWN0cylpZihlZmZlY3QudHlwZT09PSdoaXQnJiZlZmZlY3QudW5pdElkJiYhdGhpcy5oaXRzLmhhcyhlZmZlY3QudW5pdElkKSl0aGlzLmhpdHMuc2V0KGVmZmVjdC51bml0SWQsZWZmZWN0KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBwcml2YXRlIHJlbW92ZUNlbGxzKGVudHJ5OkVudHJ5KXtcbiAgICBpZihlbnRyeS5zcGVjaWFsKXJldHVybjtcbiAgICBmb3IobGV0IHJvdz1lbnRyeS5maXJzdFJvdztyb3c8PWVudHJ5Lmxhc3RSb3c7cm93KyspZm9yKGxldCBjb2w9ZW50cnkuZmlyc3RDb2w7Y29sPD1lbnRyeS5sYXN0Q29sO2NvbCsrKXtcbiAgICAgIGNvbnN0IGtleT1gJHtjb2x9OiR7cm93fWAsY2VsbD10aGlzLmNlbGxzLmdldChrZXkpO2lmKCFjZWxsKWNvbnRpbnVlO1xuICAgICAgY29uc3QgYXQ9Y2VsbC5pbmRleE9mKGVudHJ5KTtpZihhdD49MCljZWxsLnNwbGljZShhdCwxKTtpZighY2VsbC5sZW5ndGgpdGhpcy5jZWxscy5kZWxldGUoa2V5KTtcbiAgICB9XG4gIH1cbiAgcXVlcnkodmlldzpXb3JsZFZpZXcpOnJlYWRvbmx5IFVuaXRbXXtcbiAgICBjb25zdCB6b29tPXZpZXcuem9vbT8/MSxib3VuZHM9dGhpcy52aWV3Qm91bmRzO1xuICAgIGJvdW5kcy5sZWZ0PXZpZXcueDtib3VuZHMudG9wPXZpZXcueTtib3VuZHMucmlnaHQ9dmlldy54K3ZpZXcud2lkdGgvem9vbTtib3VuZHMuYm90dG9tPXZpZXcueSt2aWV3LmhlaWdodC96b29tO1xuICAgIHJldHVybiB0aGlzLnF1ZXJ5Qm91bmRzVW5pb24odGhpcy52aWV3QXJlYXMpO1xuICB9XG4gIC8qKiBXb3JsZCBjb250YWN0IGFyZWFzIGFyZSBpbmRlcGVuZGVudCBvZiB0aGUgY2FtZXJhLiBSZXR1cm4gb25lIGRlZHVwbGljYXRlZFxuICAgKiBzbmFwc2hvdC1vcmRlcmVkIHNldCBzbyBvdmVybGFwcGluZyBidXJzdHMgc2hhcmUgdGhlaXIgcmVjZWl2ZXIgY2Fwc3VsZXMuXG4gICAqIFRoaXMgYm9ycm93ZWQgcmVzdWx0IGlzIGNvbnN1bWVkIHN5bmNocm9ub3VzbHkgYmVmb3JlIGFub3RoZXIgcXVlcnkuICovXG4gIHF1ZXJ5Qm91bmRzVW5pb24oYXJlYXM6cmVhZG9ubHkgQm91bmRzW10pOnJlYWRvbmx5IFVuaXRbXXtcbiAgICB0aGlzLmNhbmRpZGF0ZUVudHJpZXMubGVuZ3RoPTA7dGhpcy5jYW5kaWRhdGVzLmxlbmd0aD0wO1xuICAgIGlmKCsrdGhpcy5zdGFtcD49MHhmZmZmZmZmZil7dGhpcy5zZWVuLmZpbGwoMCk7dGhpcy5zdGFtcD0xO31cbiAgICBjb25zdCBhZGQ9KGVudHJ5OkVudHJ5LGFyZWE6Qm91bmRzKT0+e1xuICAgICAgaWYodGhpcy5zZWVuW2VudHJ5Lm9yZGVyXT09PXRoaXMuc3RhbXApcmV0dXJuO1xuICAgICAgaWYoZW50cnkucmlnaHQ+PWFyZWEubGVmdCYmZW50cnkubGVmdDw9YXJlYS5yaWdodCYmZW50cnkuYm90dG9tPj1hcmVhLnRvcCYmZW50cnkudG9wPD1hcmVhLmJvdHRvbSl7dGhpcy5zZWVuW2VudHJ5Lm9yZGVyXT10aGlzLnN0YW1wO3RoaXMuY2FuZGlkYXRlRW50cmllcy5wdXNoKGVudHJ5KTt9XG4gICAgICBlbHNlIGlmKGFyZWFzLmxlbmd0aD09PTEpdGhpcy5zZWVuW2VudHJ5Lm9yZGVyXT10aGlzLnN0YW1wO1xuICAgIH07XG4gICAgZm9yKGNvbnN0IGFyZWEgb2YgYXJlYXMpe1xuICAgICAgY29uc3QgZmlyc3RDb2w9TWF0aC5mbG9vcihhcmVhLmxlZnQvQ0VMTCksbGFzdENvbD1NYXRoLmZsb29yKGFyZWEucmlnaHQvQ0VMTCksZmlyc3RSb3c9TWF0aC5mbG9vcihhcmVhLnRvcC9DRUxMKSxsYXN0Um93PU1hdGguZmxvb3IoYXJlYS5ib3R0b20vQ0VMTCk7XG4gICAgICBpZigobGFzdENvbC1maXJzdENvbCsxKSoobGFzdFJvdy1maXJzdFJvdysxKT5NYXRoLm1heCg2NCx0aGlzLmNlbGxzLnNpemUqMikpe1xuICAgICAgICBmb3IoY29uc3QgZW50cnkgb2YgdGhpcy5lbnRyaWVzKWlmKCFlbnRyeS5zcGVjaWFsKWFkZChlbnRyeSxhcmVhKTtcbiAgICAgIH1lbHNlIGZvcihsZXQgcm93PWZpcnN0Um93O3Jvdzw9bGFzdFJvdztyb3crKylmb3IobGV0IGNvbD1maXJzdENvbDtjb2w8PWxhc3RDb2w7Y29sKyspZm9yKGNvbnN0IGVudHJ5IG9mIHRoaXMuY2VsbHMuZ2V0KGAke2NvbH06JHtyb3d9YCk/P1tdKWFkZChlbnRyeSxhcmVhKTtcbiAgICB9XG4gICAgLy8gRXhhY3QgZGVjay92YXJpYW50IHBvc2l0aW9ucyBhcmUgZGVsaWJlcmF0ZWx5IGNoZWNrZWQgYnkgdGhlaXIgcmVuZGVyZXIuXG4gICAgaWYoYXJlYXMubGVuZ3RoKWZvcihjb25zdCBlbnRyeSBvZiB0aGlzLnNwZWNpYWwpaWYodGhpcy5zZWVuW2VudHJ5Lm9yZGVyXSE9PXRoaXMuc3RhbXApe3RoaXMuc2VlbltlbnRyeS5vcmRlcl09dGhpcy5zdGFtcDt0aGlzLmNhbmRpZGF0ZUVudHJpZXMucHVzaChlbnRyeSk7fVxuICAgIHRoaXMuY2FuZGlkYXRlRW50cmllcy5zb3J0KChhLGIpPT5hLm9yZGVyLWIub3JkZXIpO1xuICAgIGZvcihjb25zdCBlbnRyeSBvZiB0aGlzLmNhbmRpZGF0ZUVudHJpZXMpdGhpcy5jYW5kaWRhdGVzLnB1c2goZW50cnkudW5pdCk7XG4gICAgcmV0dXJuIHRoaXMuY2FuZGlkYXRlcztcbiAgfVxuICBlbmdhZ2VkSWRzKCl7cmV0dXJuIHRoaXMuZW5nYWdlZD8/PSh0aGlzLnNuYXBzaG90P2VuZ2FnZWRFbnRpdHlJZHModGhpcy5zbmFwc2hvdCk6bmV3IFNldCgpKTt9XG4gIHN0YXRzKCl7cmV0dXJue2J1aWxkczp0aGlzLmJ1aWxkcyx1bml0czp0aGlzLnVuaXRzLnNpemUsY2VsbHM6dGhpcy5jZWxscy5zaXplLGNhbmRpZGF0ZXM6dGhpcy5jYW5kaWRhdGVzLmxlbmd0aCxzcGVjaWFsOnRoaXMuc3BlY2lhbC5sZW5ndGh9O31cbiAgcmVzZXQoKXt0aGlzLnNuYXBzaG90PXVuZGVmaW5lZDt0aGlzLnRpY2s9LTE7dGhpcy51bml0QXJyYXk9dW5kZWZpbmVkO3RoaXMuYnVpbGRpbmdBcnJheT11bmRlZmluZWQ7dGhpcy5lZmZlY3RBcnJheT11bmRlZmluZWQ7dGhpcy5wcm9qZWN0aWxlQXJyYXk9dW5kZWZpbmVkO3RoaXMubW90aW9uPXVuZGVmaW5lZDt0aGlzLmNvdW50cz0nJzt0aGlzLnVuaXRzLmNsZWFyKCk7dGhpcy5lbnRpdGllcy5jbGVhcigpO3RoaXMuaGl0cy5jbGVhcigpO3RoaXMuY2VsbHMuY2xlYXIoKTt0aGlzLmJ5SWQuY2xlYXIoKTt0aGlzLmJ1aWxkaW5nSWRzLmNsZWFyKCk7dGhpcy5lbnRyaWVzLmxlbmd0aD0wO3RoaXMuc3BlY2lhbC5sZW5ndGg9MDt0aGlzLmNyZXcubGVuZ3RoPTA7dGhpcy5zYWlsaW5nLmxlbmd0aD0wO3RoaXMuc2hpcHMubGVuZ3RoPTA7dGhpcy5idWlsZGVycy5sZW5ndGg9MDt0aGlzLmFpbWluZy5sZW5ndGg9MDt0aGlzLmNhbmRpZGF0ZXMubGVuZ3RoPTA7dGhpcy5jYW5kaWRhdGVFbnRyaWVzLmxlbmd0aD0wO3RoaXMuZW5nYWdlZD11bmRlZmluZWQ7dGhpcy5zZWVuPW5ldyBVaW50MzJBcnJheSgwKTt9XG59XG4iXSwibWFwcGluZ3MiOiJBQUdBLFNBQVEsbUJBQWtCO0FBQzFCLFNBQVEsc0JBQXFCO0FBQzdCLFNBQVEsc0JBQXFCO0FBQzdCLFNBQVEsd0JBQXVCO0FBSS9CLE1BQU0sT0FBSztBQUdKLGFBQU0sc0JBQXNCO0FBQUEsRUFDeEIsUUFBTSxvQkFBSSxJQUFpQjtBQUFBLEVBQzNCLFdBQVMsb0JBQUksSUFBbUQ7QUFBQSxFQUNoRSxPQUFLLG9CQUFJLElBQXdCO0FBQUEsRUFDakMsT0FBWSxDQUFDO0FBQUEsRUFDYixVQUFlLENBQUM7QUFBQSxFQUNoQixRQUFhLENBQUM7QUFBQSxFQUNkLFdBQWdCLENBQUM7QUFBQSxFQUNqQixTQUFjLENBQUM7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsT0FBSztBQUFBLEVBQ0w7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBLFNBQU87QUFBQSxFQUNQO0FBQUEsRUFDQSxRQUFNLG9CQUFJLElBQW9CO0FBQUEsRUFDOUIsVUFBZ0IsQ0FBQztBQUFBLEVBQ2pCLE9BQUssb0JBQUksSUFBa0I7QUFBQSxFQUMzQixjQUFZLG9CQUFJLElBQVk7QUFBQSxFQUM1QixVQUFnQixDQUFDO0FBQUEsRUFDakIsT0FBSyxJQUFJLFlBQVksQ0FBQztBQUFBLEVBQ3RCLFFBQU07QUFBQSxFQUNOLG1CQUF5QixDQUFDO0FBQUEsRUFDMUIsYUFBa0IsQ0FBQztBQUFBLEVBQ25CLGFBQWtCLEVBQUMsTUFBSyxHQUFFLEtBQUksR0FBRSxPQUFNLEdBQUUsUUFBTyxFQUFDO0FBQUEsRUFDaEQsWUFBVSxDQUFDLEtBQUssVUFBVTtBQUFBLEVBQzFCO0FBQUEsRUFDQSxTQUFPO0FBQUEsRUFFZixPQUFPLFVBQXNCLFFBQTJCO0FBQ3RELFVBQU0sU0FBTyxHQUFHLFNBQVMsTUFBTSxNQUFNLElBQUksU0FBUyxVQUFVLE1BQU0sSUFBSSxTQUFTLFFBQVEsTUFBTSxJQUFJLFNBQVMsWUFBWSxNQUFNO0FBQzVILFFBQUcsYUFBVyxLQUFLLFlBQVUsU0FBUyxTQUFPLEtBQUssUUFBTSxTQUFTLFVBQVEsS0FBSyxhQUFXLFNBQVMsY0FBWSxLQUFLLGlCQUFlLFNBQVMsWUFBVSxLQUFLLGVBQWEsU0FBUyxnQkFBYyxLQUFLLG1CQUFpQixXQUFTLEtBQUssVUFBUSxXQUFTLEtBQUssT0FBTyxRQUFPO0FBQ3RRLFNBQUssV0FBUztBQUFTLFNBQUssT0FBSyxTQUFTO0FBQUssU0FBSyxZQUFVLFNBQVM7QUFBTSxTQUFLLGdCQUFjLFNBQVM7QUFBVSxTQUFLLGNBQVksU0FBUztBQUFRLFNBQUssa0JBQWdCLFNBQVM7QUFBWSxTQUFLLFNBQU87QUFBTyxTQUFLLFNBQU87QUFBTyxTQUFLO0FBQzFPLFNBQUssS0FBSyxNQUFNO0FBQUUsU0FBSyxRQUFRLFNBQU87QUFBRSxTQUFLLFFBQVEsU0FBTztBQUFFLFNBQUssS0FBSyxTQUFPO0FBQUUsU0FBSyxRQUFRLFNBQU87QUFBRSxTQUFLLE1BQU0sU0FBTztBQUFFLFNBQUssU0FBUyxTQUFPO0FBQUUsU0FBSyxPQUFPLFNBQU87QUFBRSxTQUFLLFVBQVE7QUFDcEwsUUFBRyxLQUFLLEtBQUssU0FBTyxTQUFTLE1BQU0sT0FBTyxNQUFLLE9BQUssSUFBSSxZQUFZLFNBQVMsTUFBTSxNQUFNO0FBQ3pGLGFBQVEsUUFBTSxHQUFFLFFBQU0sU0FBUyxNQUFNLFFBQU8sU0FBUTtBQUNsRCxZQUFNLE9BQUssU0FBUyxNQUFNLEtBQUssR0FBRyxRQUFNLFlBQVksSUFBSTtBQUFFLFdBQUssTUFBTSxJQUFJLEtBQUssSUFBRyxJQUFJO0FBQUUsV0FBSyxTQUFTLElBQUksS0FBSyxJQUFHLElBQUk7QUFDckgsVUFBRyxLQUFLLEtBQUssTUFBSyxLQUFLLEtBQUssSUFBSTtBQUNoQyxVQUFHLEtBQUssUUFBUSxNQUFLLFFBQVEsS0FBSyxJQUFJO0FBQ3RDLFVBQUcsTUFBTSxNQUFLLE1BQU0sS0FBSyxJQUFJO0FBQzdCLFVBQUcsS0FBSyxTQUFPLFlBQVUsS0FBSyxNQUFNLFNBQU8sUUFBUSxNQUFLLFNBQVMsS0FBSyxJQUFJO0FBQzFFLFVBQUcsS0FBSyxJQUFJLE1BQUssT0FBTyxLQUFLLElBQUk7QUFJakMsVUFBSSxRQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssRUFBRTtBQUMvQixZQUFNLE1BQUksU0FBTyxNQUFNLFNBQU8sS0FBSyxRQUFNLE1BQU0sV0FBUyxLQUFLLFNBQU8sTUFBTSxNQUFJLEtBQUssSUFBSSxLQUFJLEtBQUssU0FBTyxHQUFFLE1BQUksS0FBSyxLQUFLLGVBQWUsS0FBSyxJQUFJLEdBQUcsS0FBRyxNQUFJLGVBQWUsS0FBSyxNQUFNLENBQUMsQ0FBQztBQUNyTCxZQUFNLFFBQU0sUUFBUSxPQUFPLElBQUksR0FBRSxPQUFLLE9BQU8sUUFBTSxNQUFLLEtBQUcsT0FBTyxNQUFJO0FBQ3RFLFlBQU0sT0FBSyxLQUFLLElBQUksS0FBSyxHQUFFLEtBQUssR0FBRSxHQUFHLENBQUMsSUFBRSxLQUFJLFFBQU0sS0FBSyxJQUFJLEtBQUssR0FBRSxLQUFLLEdBQUUsR0FBRyxDQUFDLElBQUUsS0FBSSxNQUFJLEtBQUssSUFBSSxLQUFLLEdBQUUsS0FBSyxHQUFFLEdBQUcsQ0FBQyxJQUFFLEtBQUksU0FBTyxLQUFLLElBQUksS0FBSyxHQUFFLEtBQUssR0FBRSxHQUFHLENBQUMsSUFBRTtBQUM1SixZQUFNLFdBQVMsS0FBSyxNQUFNLE9BQUssSUFBSSxHQUFFLFVBQVEsS0FBSyxNQUFNLFFBQU0sSUFBSSxHQUFFLFdBQVMsS0FBSyxNQUFNLE1BQUksSUFBSSxHQUFFLFVBQVEsS0FBSyxNQUFNLFNBQU8sSUFBSTtBQUNoSSxZQUFNLFVBQVEsUUFBUSxLQUFLLFFBQU0sS0FBSyxZQUFVLFVBQVcsVUFBUSxVQUFRLFdBQVMsTUFBSSxVQUFRLFdBQVMsS0FBRyxFQUFFO0FBQzlHLFlBQU0sWUFBVSxDQUFDLFNBQU8sTUFBTSxZQUFVLFdBQVMsTUFBTSxhQUFXLFlBQVUsTUFBTSxZQUFVLFdBQVMsTUFBTSxhQUFXLFlBQVUsTUFBTSxZQUFVO0FBQ2hKLFVBQUcsU0FBTyxVQUFVLE1BQUssWUFBWSxLQUFLO0FBQzFDLFVBQUcsQ0FBQyxPQUFNO0FBQUMsZ0JBQU0sRUFBQyxNQUFLLE9BQU0sTUFBSyxPQUFNLEtBQUksUUFBTyxLQUFJLE1BQUssS0FBSyxNQUFLLFFBQU8sS0FBSyxRQUFPLE9BQU0sS0FBSyxRQUFPLFNBQVEsVUFBUyxTQUFRLFVBQVMsUUFBTztBQUFFLGFBQUssS0FBSyxJQUFJLEtBQUssSUFBRyxLQUFLO0FBQUEsTUFBRSxPQUMvSztBQUFDLGNBQU0sT0FBSztBQUFLLGNBQU0sUUFBTTtBQUFNLGNBQU0sT0FBSztBQUFLLGNBQU0sUUFBTTtBQUFNLGNBQU0sTUFBSTtBQUFJLGNBQU0sU0FBTztBQUFPLGNBQU0sTUFBSTtBQUFJLGNBQU0sT0FBSyxLQUFLO0FBQUssY0FBTSxTQUFPLEtBQUs7QUFBTyxjQUFNLFFBQU0sS0FBSztBQUFPLGNBQU0sVUFBUTtBQUFRLGNBQU0sV0FBUztBQUFTLGNBQU0sVUFBUTtBQUFRLGNBQU0sV0FBUztBQUFTLGNBQU0sVUFBUTtBQUFBLE1BQVE7QUFDalQsV0FBSyxRQUFRLEtBQUssS0FBSztBQUV2QixVQUFHLFNBQVE7QUFBQyxhQUFLLFFBQVEsS0FBSyxLQUFLO0FBQUU7QUFBQSxNQUFTO0FBQzlDLFVBQUcsVUFBVSxVQUFRLE1BQUksVUFBUyxPQUFLLFNBQVEsTUFBTSxVQUFRLE1BQUksVUFBUyxPQUFLLFNBQVEsT0FBTTtBQUMzRixjQUFNLE1BQUksR0FBRyxHQUFHLElBQUksR0FBRyxJQUFHLE9BQUssS0FBSyxNQUFNLElBQUksR0FBRztBQUNqRCxZQUFHLEtBQUssTUFBSyxLQUFLLEtBQUs7QUFBQSxZQUFPLE1BQUssTUFBTSxJQUFJLEtBQUksQ0FBQyxLQUFLLENBQUM7QUFBQSxNQUMxRDtBQUFBLElBQ0Y7QUFDQSxlQUFVLENBQUMsSUFBRyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUcsTUFBTSxVQUFRLEtBQUssUUFBTztBQUFDLFdBQUssWUFBWSxLQUFLO0FBQUUsV0FBSyxLQUFLLE9BQU8sRUFBRTtBQUFFLFdBQUssTUFBTSxPQUFPLEVBQUU7QUFBRSxXQUFLLFNBQVMsT0FBTyxFQUFFO0FBQUEsSUFBRTtBQUM1SixVQUFNLGVBQWEsS0FBSztBQUFZLFNBQUssY0FBWSxvQkFBSSxJQUFJO0FBQzdELGVBQVUsWUFBWSxTQUFTLFdBQVU7QUFBQyxXQUFLLFNBQVMsSUFBSSxTQUFTLElBQUcsUUFBUTtBQUFFLFdBQUssWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUFFLG1CQUFhLE9BQU8sU0FBUyxFQUFFO0FBQUEsSUFBRTtBQUNySixlQUFVLE1BQU0sYUFBYSxLQUFHLENBQUMsS0FBSyxNQUFNLElBQUksRUFBRSxFQUFFLE1BQUssU0FBUyxPQUFPLEVBQUU7QUFDM0UsZUFBVSxVQUFVLFNBQVMsUUFBUSxLQUFHLE9BQU8sU0FBTyxTQUFPLE9BQU8sVUFBUSxDQUFDLEtBQUssS0FBSyxJQUFJLE9BQU8sTUFBTSxFQUFFLE1BQUssS0FBSyxJQUFJLE9BQU8sUUFBTyxNQUFNO0FBQzVJLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDUSxZQUFZLE9BQVk7QUFDOUIsUUFBRyxNQUFNLFFBQVE7QUFDakIsYUFBUSxNQUFJLE1BQU0sVUFBUyxPQUFLLE1BQU0sU0FBUSxNQUFNLFVBQVEsTUFBSSxNQUFNLFVBQVMsT0FBSyxNQUFNLFNBQVEsT0FBTTtBQUN0RyxZQUFNLE1BQUksR0FBRyxHQUFHLElBQUksR0FBRyxJQUFHLE9BQUssS0FBSyxNQUFNLElBQUksR0FBRztBQUFFLFVBQUcsQ0FBQyxLQUFLO0FBQzVELFlBQU0sS0FBRyxLQUFLLFFBQVEsS0FBSztBQUFFLFVBQUcsTUFBSSxFQUFFLE1BQUssT0FBTyxJQUFHLENBQUM7QUFBRSxVQUFHLENBQUMsS0FBSyxPQUFPLE1BQUssTUFBTSxPQUFPLEdBQUc7QUFBQSxJQUMvRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sTUFBK0I7QUFDbkMsVUFBTSxPQUFLLEtBQUssUUFBTSxHQUFFLFNBQU8sS0FBSztBQUNwQyxXQUFPLE9BQUssS0FBSztBQUFFLFdBQU8sTUFBSSxLQUFLO0FBQUUsV0FBTyxRQUFNLEtBQUssSUFBRSxLQUFLLFFBQU07QUFBSyxXQUFPLFNBQU8sS0FBSyxJQUFFLEtBQUssU0FBTztBQUMxRyxXQUFPLEtBQUssaUJBQWlCLEtBQUssU0FBUztBQUFBLEVBQzdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxpQkFBaUIsT0FBd0M7QUFDdkQsU0FBSyxpQkFBaUIsU0FBTztBQUFFLFNBQUssV0FBVyxTQUFPO0FBQ3RELFFBQUcsRUFBRSxLQUFLLFNBQU8sWUFBVztBQUFDLFdBQUssS0FBSyxLQUFLLENBQUM7QUFBRSxXQUFLLFFBQU07QUFBQSxJQUFFO0FBQzVELFVBQU0sTUFBSSxDQUFDLE9BQVksU0FBYztBQUNuQyxVQUFHLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBSSxLQUFLLE1BQU07QUFDdkMsVUFBRyxNQUFNLFNBQU8sS0FBSyxRQUFNLE1BQU0sUUFBTSxLQUFLLFNBQU8sTUFBTSxVQUFRLEtBQUssT0FBSyxNQUFNLE9BQUssS0FBSyxRQUFPO0FBQUMsYUFBSyxLQUFLLE1BQU0sS0FBSyxJQUFFLEtBQUs7QUFBTSxhQUFLLGlCQUFpQixLQUFLLEtBQUs7QUFBQSxNQUFFLFdBQy9KLE1BQU0sV0FBUyxFQUFFLE1BQUssS0FBSyxNQUFNLEtBQUssSUFBRSxLQUFLO0FBQUEsSUFDdkQ7QUFDQSxlQUFVLFFBQVEsT0FBTTtBQUN0QixZQUFNLFdBQVMsS0FBSyxNQUFNLEtBQUssT0FBSyxJQUFJLEdBQUUsVUFBUSxLQUFLLE1BQU0sS0FBSyxRQUFNLElBQUksR0FBRSxXQUFTLEtBQUssTUFBTSxLQUFLLE1BQUksSUFBSSxHQUFFLFVBQVEsS0FBSyxNQUFNLEtBQUssU0FBTyxJQUFJO0FBQ3BKLFdBQUksVUFBUSxXQUFTLE1BQUksVUFBUSxXQUFTLEtBQUcsS0FBSyxJQUFJLElBQUcsS0FBSyxNQUFNLE9BQUssQ0FBQyxHQUFFO0FBQzFFLG1CQUFVLFNBQVMsS0FBSyxRQUFRLEtBQUcsQ0FBQyxNQUFNLFFBQVEsS0FBSSxPQUFNLElBQUk7QUFBQSxNQUNsRSxNQUFNLFVBQVEsTUFBSSxVQUFTLE9BQUssU0FBUSxNQUFNLFVBQVEsTUFBSSxVQUFTLE9BQUssU0FBUSxNQUFNLFlBQVUsU0FBUyxLQUFLLE1BQU0sSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUUsS0FBRyxDQUFDLEVBQUUsS0FBSSxPQUFNLElBQUk7QUFBQSxJQUM3SjtBQUVBLFFBQUcsTUFBTTtBQUFPLGlCQUFVLFNBQVMsS0FBSyxRQUFRLEtBQUcsS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFJLEtBQUssT0FBTTtBQUFDLGFBQUssS0FBSyxNQUFNLEtBQUssSUFBRSxLQUFLO0FBQU0sYUFBSyxpQkFBaUIsS0FBSyxLQUFLO0FBQUEsTUFBRTtBQUFBO0FBQzVKLFNBQUssaUJBQWlCLEtBQUssQ0FBQyxHQUFFLE1BQUksRUFBRSxRQUFNLEVBQUUsS0FBSztBQUNqRCxlQUFVLFNBQVMsS0FBSyxpQkFBaUIsTUFBSyxXQUFXLEtBQUssTUFBTSxJQUFJO0FBQ3hFLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLGFBQVk7QUFBQyxXQUFPLEtBQUssWUFBVyxLQUFLLFdBQVMsaUJBQWlCLEtBQUssUUFBUSxJQUFFLG9CQUFJLElBQUk7QUFBQSxFQUFHO0FBQUEsRUFDN0YsUUFBTztBQUFDLFdBQU0sRUFBQyxRQUFPLEtBQUssUUFBTyxPQUFNLEtBQUssTUFBTSxNQUFLLE9BQU0sS0FBSyxNQUFNLE1BQUssWUFBVyxLQUFLLFdBQVcsUUFBTyxTQUFRLEtBQUssUUFBUSxPQUFNO0FBQUEsRUFBRTtBQUFBLEVBQzdJLFFBQU87QUFBQyxTQUFLLFdBQVM7QUFBVSxTQUFLLE9BQUs7QUFBRyxTQUFLLFlBQVU7QUFBVSxTQUFLLGdCQUFjO0FBQVUsU0FBSyxjQUFZO0FBQVUsU0FBSyxrQkFBZ0I7QUFBVSxTQUFLLFNBQU87QUFBVSxTQUFLLFNBQU87QUFBRyxTQUFLLE1BQU0sTUFBTTtBQUFFLFNBQUssU0FBUyxNQUFNO0FBQUUsU0FBSyxLQUFLLE1BQU07QUFBRSxTQUFLLE1BQU0sTUFBTTtBQUFFLFNBQUssS0FBSyxNQUFNO0FBQUUsU0FBSyxZQUFZLE1BQU07QUFBRSxTQUFLLFFBQVEsU0FBTztBQUFFLFNBQUssUUFBUSxTQUFPO0FBQUUsU0FBSyxLQUFLLFNBQU87QUFBRSxTQUFLLFFBQVEsU0FBTztBQUFFLFNBQUssTUFBTSxTQUFPO0FBQUUsU0FBSyxTQUFTLFNBQU87QUFBRSxTQUFLLE9BQU8sU0FBTztBQUFFLFNBQUssV0FBVyxTQUFPO0FBQUUsU0FBSyxpQkFBaUIsU0FBTztBQUFFLFNBQUssVUFBUTtBQUFVLFNBQUssT0FBSyxJQUFJLFlBQVksQ0FBQztBQUFBLEVBQUU7QUFDOWpCOyIsIm5hbWVzIjpbXX0=