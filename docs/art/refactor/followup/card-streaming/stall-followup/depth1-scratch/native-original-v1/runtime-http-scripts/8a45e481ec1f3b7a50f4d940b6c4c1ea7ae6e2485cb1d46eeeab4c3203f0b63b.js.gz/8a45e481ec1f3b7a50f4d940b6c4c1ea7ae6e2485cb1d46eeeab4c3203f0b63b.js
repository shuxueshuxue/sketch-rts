import { drawWorld } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world-renderer.ts";
import { resources, resourceText } from "/@fs/tmp/sketch-queue-source-42bd/src/client/resources.ts";
import { resourcePanel } from "/@fs/tmp/sketch-queue-source-42bd/src/client/resource-panel.ts";
import "/@fs/tmp/sketch-queue-source-42bd/src/client/world-presentation.css";
import { ShipWakeTracker } from "/@fs/tmp/sketch-queue-source-42bd/src/client/ship-wakes.ts";
import { PresentationViewIndex } from "/@fs/tmp/sketch-queue-source-42bd/src/client/presentation-view.ts";
export class WorldPresentation {
  constructor(canvas) {
    this.canvas = canvas;
    this.stack.className = "world-underlay";
    this.actors.className = "world-actors";
    this.ground.className = "world-ground";
    this.stack.hidden = true;
    this.stack.append(this.ground, this.actors);
    canvas.before(this.stack);
  }
  viewIndex = new PresentationViewIndex();
  wakes = new ShipWakeTracker();
  ground = document.createElement("canvas");
  actors = document.createElement("canvas");
  stack = document.createElement("div");
  layer;
  attempted = false;
  context = null;
  initializing;
  current;
  revision = 0;
  contextLost = false;
  failed = false;
  effectTypes;
  dimensions = "";
  enabled = false;
  disposed = false;
  onContextLost = (event) => {
    event.preventDefault();
    this.contextLost = true;
    this.revision++;
    this.enabled = false;
    this.stack.hidden = true;
    resourcePanel().renderer = resourceText("2D · 图形上下文丢失", "2D · graphics context lost");
    void this.fallbackCurrent();
  };
  onContextRestored = () => {
    this.contextLost = false;
    this.failed = false;
    void this.recoverCurrent();
  };
  async prepare(snapshot, phase, sites = []) {
    if (this.disposed) return;
    const revision = ++this.revision;
    this.current = { snapshot, phase, sites };
    this.enabled = false;
    this.stack.hidden = true;
    await this.initialize(phase);
    if (revision !== this.revision) return;
    if (this.layer && !this.contextLost && !this.failed) {
      await resources.warm("renderer", phase);
      if (revision !== this.revision) return;
      resourcePanel().preparing(resourceText("读取并准备三维模型", "Loading and preparing 3D models"));
      await this.layer.prepare(snapshot, phase, sites);
      if (revision !== this.revision || this.contextLost || this.failed) return;
      this.layer.reset();
      this.enabled = true;
      resourcePanel().renderer = resourceText("实时 3D · 建筑、船只与人物共享深度", "Real-time 3D · shared building, ship and troop depth");
    } else {
      await this.prepareFallback(snapshot, phase, sites);
      if (revision === this.revision && !this.contextLost && !this.failed) resourcePanel().renderer = resourceText("2D · 此设备未提供 WebGL2", "2D · WebGL2 unavailable on this device");
    }
  }
  initialize(phase) {
    if (!this.initializing) this.initializing = this.createLayer(phase).finally(() => {
      this.initializing = void 0;
    });
    return this.initializing;
  }
  async createLayer(phase) {
    if (!this.attempted) {
      this.attempted = true;
      this.context = this.actors.getContext("webgl2", { alpha: true, antialias: true });
      if (this.context) {
        this.actors.addEventListener("webglcontextlost", this.onContextLost);
        this.actors.addEventListener("webglcontextrestored", this.onContextRestored);
      }
    }
    if (!this.context || this.layer || this.contextLost || this.failed) return;
    await resources.warm("renderer", phase);
    if (this.disposed) return;
    const module = await import("/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/world-layer.ts");
    if (this.contextLost || this.disposed) return;
    try {
      this.layer = module.World3DLayer.create(this.actors, this.context);
      this.effectTypes = module.PHYSICAL_EFFECTS;
    } catch (error) {
      this.failed = true;
      console.warn("GPU renderer unavailable; using Canvas", error);
      resourcePanel().renderer = resourceText("2D · GPU 初始化失败后回退", "2D · GPU initialization fallback");
    }
  }
  async fallbackCurrent() {
    if (!this.current || this.disposed) return;
    const { snapshot, phase, sites } = this.current;
    try {
      await this.prepareFallback(snapshot, phase, sites);
    } catch (error) {
      if (!this.disposed) console.error("Canvas resources unavailable", error);
    }
  }
  async recoverCurrent() {
    if (!this.current || this.disposed) return;
    const { snapshot, phase, sites } = this.current;
    const revision = this.revision + 1;
    try {
      await this.prepare(snapshot, phase, sites);
    } catch (error) {
      if (revision !== this.revision) return;
      this.failed = true;
      this.enabled = false;
      this.stack.hidden = true;
      resourcePanel().renderer = resourceText("2D · GPU 恢复失败后回退", "2D · GPU recovery fallback");
      console.error("GPU recovery failed; using Canvas", error);
      await this.fallbackCurrent();
    }
  }
  async prepareFallback(snapshot, phase, sites = []) {
    await resources.warm("renderer", phase);
    if (this.disposed) return;
    const { worldModels, matchModelKeys, snapshotModelKeys } = await import("/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/model-library.ts");
    const { activateModelPortraits } = await import("/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/model-portraits.ts");
    if (this.disposed) return;
    await worldModels.prepare(phase === "match" ? matchModelKeys : [...snapshotModelKeys(snapshot), ...sites.map((kind) => `buildings/${kind}`)], phase);
    if (!this.disposed) activateModelPortraits();
  }
  draw(frame, phase = this.current?.phase ?? "home") {
    if (this.disposed) return;
    frame = { ...frame, wakes: this.wakes, viewIndex: this.viewIndex };
    resources.phase = phase;
    const changed = this.current?.phase !== phase;
    this.current = { snapshot: frame.snapshot, phase, sites: Object.values(frame.buildingModels ?? {}) };
    if (changed && !this.enabled) {
      this.revision++;
      void this.recoverCurrent();
    }
    const dpr = Math.min(devicePixelRatio, 2), width = frame.view.width, height = frame.view.height;
    if (!this.enabled || !this.layer) {
      this.stack.hidden = true;
      drawWorld(frame);
      return;
    }
    this.stack.hidden = false;
    const dimensions = `${width}:${height}:${dpr}`;
    if (dimensions !== this.dimensions) {
      this.ground.width = Math.round(width * dpr);
      this.ground.height = Math.round(height * dpr);
      this.dimensions = dimensions;
    }
    try {
      this.layer.draw(frame);
    } catch (error) {
      console.error("GPU presentation failed; using Canvas", error);
      this.failed = true;
      this.revision++;
      this.enabled = false;
      this.stack.hidden = true;
      resourcePanel().renderer = resourceText("2D · GPU 渲染失败后回退", "2D · GPU rendering fallback");
      void this.fallbackCurrent();
      drawWorld(frame);
      return;
    }
    const ground = this.ground.getContext("2d");
    ground.setTransform(1, 0, 0, 1, 0, 0);
    ground.clearRect(0, 0, this.ground.width, this.ground.height);
    ground.setTransform(dpr, 0, 0, dpr, 0, 0);
    const common = { actorPositions: this.layer.positions, physicalEffects: this.effectTypes, physicalCombat: true, depthSelection: true };
    drawWorld({ ...frame, ...common, ctx: ground, pass: "ground" });
    frame.ctx.save();
    frame.ctx.setTransform(1, 0, 0, 1, 0, 0);
    frame.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    frame.ctx.restore();
    drawWorld({ ...frame, ...common, pass: "overlay" });
  }
  pick(point) {
    return this.enabled ? this.layer?.pick(point) : void 0;
  }
  plane(point, height) {
    return this.enabled ? this.layer?.plane(point, height) : void 0;
  }
  position(id) {
    return this.enabled ? this.layer?.positions.get(id) : void 0;
  }
  get is3D() {
    return this.enabled;
  }
  reset() {
    this.revision++;
    this.current = void 0;
    this.layer?.reset();
    this.wakes = new ShipWakeTracker();
    this.viewIndex.reset();
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.revision++;
    this.enabled = false;
    this.current = void 0;
    this.actors.removeEventListener("webglcontextlost", this.onContextLost);
    this.actors.removeEventListener("webglcontextrestored", this.onContextRestored);
    this.layer?.dispose();
    this.layer = void 0;
    this.context = null;
    this.effectTypes = void 0;
    this.wakes = new ShipWakeTracker();
    this.viewIndex.reset();
    this.stack.hidden = true;
    this.stack.remove();
    this.ground.width = this.ground.height = this.actors.width = this.actors.height = 0;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndvcmxkLXByZXNlbnRhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkcmF3V29ybGQsdHlwZSBXb3JsZEZyYW1lIH0gZnJvbSAnLi93b3JsZC1yZW5kZXJlcic7XG5pbXBvcnQgeyByZXNvdXJjZXMscmVzb3VyY2VUZXh0LHR5cGUgUmVzb3VyY2VQaGFzZSB9IGZyb20gJy4vcmVzb3VyY2VzJztcbmltcG9ydCB7IHJlc291cmNlUGFuZWwgfSBmcm9tICcuL3Jlc291cmNlLXBhbmVsJztcbmltcG9ydCB0eXBlIHsgR2FtZVNuYXBzaG90IH0gZnJvbSAnLi4vc2hhcmVkL3R5cGVzJztcbmltcG9ydCB0eXBlIHsgV29ybGQzRExheWVyIH0gZnJvbSAnLi93b3JsZDNkL3dvcmxkLWxheWVyJztcbmltcG9ydCAnLi93b3JsZC1wcmVzZW50YXRpb24uY3NzJztcbmltcG9ydCB7IFNoaXBXYWtlVHJhY2tlciB9IGZyb20gJy4vc2hpcC13YWtlcyc7XG5pbXBvcnQge1ByZXNlbnRhdGlvblZpZXdJbmRleH0gZnJvbSAnLi9wcmVzZW50YXRpb24tdmlldyc7XG5cbnR5cGUgU2NlbmVQcmVwYXJhdGlvbj17c25hcHNob3Q6R2FtZVNuYXBzaG90O3BoYXNlOlJlc291cmNlUGhhc2U7c2l0ZXM6cmVhZG9ubHkgc3RyaW5nW119O1xuXG4vKiogQ29vcmRpbmF0ZXMgdGhlIHRocmVlIHByZXNlbnRhdGlvbiBsYXllcnMuIE1vZGVsIGNvZGUgbG9hZHMgd2l0aCB0aGUgc2NlbmUsXG4gKiBhZnRlciBib290c3RyYXA7IG5ldHdvcmtpbmcgYW5kIHNpbXVsYXRpb24gc3RheSBzZXBhcmF0ZS4gKi9cbmV4cG9ydCBjbGFzcyBXb3JsZFByZXNlbnRhdGlvbiB7XG4gIHByaXZhdGUgdmlld0luZGV4PW5ldyBQcmVzZW50YXRpb25WaWV3SW5kZXgoKTtcbiAgcHJpdmF0ZSB3YWtlcz1uZXcgU2hpcFdha2VUcmFja2VyKCk7XG4gIHByaXZhdGUgZ3JvdW5kPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICBwcml2YXRlIGFjdG9ycz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgcHJpdmF0ZSBzdGFjaz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgcHJpdmF0ZSBsYXllcjpXb3JsZDNETGF5ZXJ8dW5kZWZpbmVkO1xuICBwcml2YXRlIGF0dGVtcHRlZD1mYWxzZTtcbiAgcHJpdmF0ZSBjb250ZXh0OldlYkdMMlJlbmRlcmluZ0NvbnRleHR8bnVsbD0gbnVsbDtcbiAgcHJpdmF0ZSBpbml0aWFsaXppbmc6UHJvbWlzZTx2b2lkPnx1bmRlZmluZWQ7XG4gIHByaXZhdGUgY3VycmVudDpTY2VuZVByZXBhcmF0aW9ufHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSByZXZpc2lvbj0wO1xuICBwcml2YXRlIGNvbnRleHRMb3N0PWZhbHNlO1xuICBwcml2YXRlIGZhaWxlZD1mYWxzZTtcbiAgcHJpdmF0ZSBlZmZlY3RUeXBlczpSZWFkb25seVNldDxHYW1lU25hcHNob3RbJ2VmZmVjdHMnXVtudW1iZXJdWyd0eXBlJ10+fHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBkaW1lbnNpb25zPScnO1xuICBwcml2YXRlIGVuYWJsZWQ9ZmFsc2U7XG4gIHByaXZhdGUgZGlzcG9zZWQ9ZmFsc2U7XG4gIHByaXZhdGUgb25Db250ZXh0TG9zdD0oZXZlbnQ6RXZlbnQpPT57XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTt0aGlzLmNvbnRleHRMb3N0PXRydWU7dGhpcy5yZXZpc2lvbisrO3RoaXMuZW5hYmxlZD1mYWxzZTt0aGlzLnN0YWNrLmhpZGRlbj10cnVlO1xuICAgIHJlc291cmNlUGFuZWwoKS5yZW5kZXJlcj1yZXNvdXJjZVRleHQoJzJEIMK3IOWbvuW9ouS4iuS4i+aWh+S4ouWksScsJzJEIMK3IGdyYXBoaWNzIGNvbnRleHQgbG9zdCcpO1xuICAgIHZvaWQgdGhpcy5mYWxsYmFja0N1cnJlbnQoKTtcbiAgfTtcbiAgcHJpdmF0ZSBvbkNvbnRleHRSZXN0b3JlZD0oKT0+e3RoaXMuY29udGV4dExvc3Q9ZmFsc2U7dGhpcy5mYWlsZWQ9ZmFsc2U7dm9pZCB0aGlzLnJlY292ZXJDdXJyZW50KCk7fTtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjYW52YXM6SFRNTENhbnZhc0VsZW1lbnQpe1xuICAgIHRoaXMuc3RhY2suY2xhc3NOYW1lPSd3b3JsZC11bmRlcmxheSc7dGhpcy5hY3RvcnMuY2xhc3NOYW1lPSd3b3JsZC1hY3RvcnMnO3RoaXMuZ3JvdW5kLmNsYXNzTmFtZT0nd29ybGQtZ3JvdW5kJztcbiAgICB0aGlzLnN0YWNrLmhpZGRlbj10cnVlO3RoaXMuc3RhY2suYXBwZW5kKHRoaXMuZ3JvdW5kLHRoaXMuYWN0b3JzKTtjYW52YXMuYmVmb3JlKHRoaXMuc3RhY2spO1xuICB9XG4gIGFzeW5jIHByZXBhcmUoc25hcHNob3Q6R2FtZVNuYXBzaG90LHBoYXNlOlJlc291cmNlUGhhc2Usc2l0ZXM6cmVhZG9ubHkgc3RyaW5nW109W10pe1xuICAgIGlmKHRoaXMuZGlzcG9zZWQpcmV0dXJuO1xuICAgIGNvbnN0IHJldmlzaW9uPSsrdGhpcy5yZXZpc2lvbjtcbiAgICB0aGlzLmN1cnJlbnQ9e3NuYXBzaG90LHBoYXNlLHNpdGVzfTtcbiAgICB0aGlzLmVuYWJsZWQ9ZmFsc2U7dGhpcy5zdGFjay5oaWRkZW49dHJ1ZTtcbiAgICBhd2FpdCB0aGlzLmluaXRpYWxpemUocGhhc2UpO1xuICAgIGlmKHJldmlzaW9uIT09dGhpcy5yZXZpc2lvbilyZXR1cm47XG4gICAgaWYodGhpcy5sYXllciAmJiAhdGhpcy5jb250ZXh0TG9zdCAmJiAhdGhpcy5mYWlsZWQpe1xuICAgICAgYXdhaXQgcmVzb3VyY2VzLndhcm0oJ3JlbmRlcmVyJyxwaGFzZSk7XG4gICAgICBpZihyZXZpc2lvbiE9PXRoaXMucmV2aXNpb24pcmV0dXJuO1xuICAgICAgcmVzb3VyY2VQYW5lbCgpLnByZXBhcmluZyhyZXNvdXJjZVRleHQoJ+ivu+WPluW5tuWHhuWkh+S4iee7tOaooeWeiycsJ0xvYWRpbmcgYW5kIHByZXBhcmluZyAzRCBtb2RlbHMnKSk7XG4gICAgICBhd2FpdCB0aGlzLmxheWVyLnByZXBhcmUoc25hcHNob3QscGhhc2Usc2l0ZXMpO1xuICAgICAgaWYocmV2aXNpb24hPT10aGlzLnJldmlzaW9uIHx8IHRoaXMuY29udGV4dExvc3QgfHwgdGhpcy5mYWlsZWQpcmV0dXJuO1xuICAgICAgdGhpcy5sYXllci5yZXNldCgpO3RoaXMuZW5hYmxlZD10cnVlO1xuICAgICAgcmVzb3VyY2VQYW5lbCgpLnJlbmRlcmVyPXJlc291cmNlVGV4dCgn5a6e5pe2IDNEIMK3IOW7uuetkeOAgeiIueWPquS4juS6uueJqeWFseS6q+a3seW6picsJ1JlYWwtdGltZSAzRCDCtyBzaGFyZWQgYnVpbGRpbmcsIHNoaXAgYW5kIHRyb29wIGRlcHRoJyk7XG4gICAgfWVsc2V7XG4gICAgICBhd2FpdCB0aGlzLnByZXBhcmVGYWxsYmFjayhzbmFwc2hvdCxwaGFzZSxzaXRlcyk7XG4gICAgICBpZihyZXZpc2lvbj09PXRoaXMucmV2aXNpb24gJiYgIXRoaXMuY29udGV4dExvc3QgJiYgIXRoaXMuZmFpbGVkKXJlc291cmNlUGFuZWwoKS5yZW5kZXJlcj1yZXNvdXJjZVRleHQoJzJEIMK3IOatpOiuvuWkh+acquaPkOS+myBXZWJHTDInLCcyRCDCtyBXZWJHTDIgdW5hdmFpbGFibGUgb24gdGhpcyBkZXZpY2UnKTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBpbml0aWFsaXplKHBoYXNlOlJlc291cmNlUGhhc2Upe1xuICAgIGlmKCF0aGlzLmluaXRpYWxpemluZyl0aGlzLmluaXRpYWxpemluZz10aGlzLmNyZWF0ZUxheWVyKHBoYXNlKS5maW5hbGx5KCgpPT57dGhpcy5pbml0aWFsaXppbmc9dW5kZWZpbmVkO30pO1xuICAgIHJldHVybiB0aGlzLmluaXRpYWxpemluZztcbiAgfVxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUxheWVyKHBoYXNlOlJlc291cmNlUGhhc2Upe1xuICAgIGlmKCF0aGlzLmF0dGVtcHRlZCl7XG4gICAgICB0aGlzLmF0dGVtcHRlZD10cnVlO1xuICAgICAgdGhpcy5jb250ZXh0PXRoaXMuYWN0b3JzLmdldENvbnRleHQoJ3dlYmdsMicse2FscGhhOnRydWUsYW50aWFsaWFzOnRydWV9KTtcbiAgICAgIGlmKHRoaXMuY29udGV4dCl7XG4gICAgICAgIHRoaXMuYWN0b3JzLmFkZEV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dGxvc3QnLHRoaXMub25Db250ZXh0TG9zdCk7XG4gICAgICAgIHRoaXMuYWN0b3JzLmFkZEV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dHJlc3RvcmVkJyx0aGlzLm9uQ29udGV4dFJlc3RvcmVkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYoIXRoaXMuY29udGV4dCB8fCB0aGlzLmxheWVyIHx8IHRoaXMuY29udGV4dExvc3QgfHwgdGhpcy5mYWlsZWQpcmV0dXJuO1xuICAgIGF3YWl0IHJlc291cmNlcy53YXJtKCdyZW5kZXJlcicscGhhc2UpO1xuICAgIGlmKHRoaXMuZGlzcG9zZWQpcmV0dXJuO1xuICAgIGNvbnN0IG1vZHVsZT1hd2FpdCBpbXBvcnQoJy4vd29ybGQzZC93b3JsZC1sYXllcicpO1xuICAgIGlmKHRoaXMuY29udGV4dExvc3R8fHRoaXMuZGlzcG9zZWQpcmV0dXJuO1xuICAgIHRyeXt0aGlzLmxheWVyPW1vZHVsZS5Xb3JsZDNETGF5ZXIuY3JlYXRlKHRoaXMuYWN0b3JzLHRoaXMuY29udGV4dCk7dGhpcy5lZmZlY3RUeXBlcz1tb2R1bGUuUEhZU0lDQUxfRUZGRUNUUzt9XG4gICAgY2F0Y2goZXJyb3Ipe3RoaXMuZmFpbGVkPXRydWU7Y29uc29sZS53YXJuKCdHUFUgcmVuZGVyZXIgdW5hdmFpbGFibGU7IHVzaW5nIENhbnZhcycsZXJyb3IpO3Jlc291cmNlUGFuZWwoKS5yZW5kZXJlcj1yZXNvdXJjZVRleHQoJzJEIMK3IEdQVSDliJ3lp4vljJblpLHotKXlkI7lm57pgIAnLCcyRCDCtyBHUFUgaW5pdGlhbGl6YXRpb24gZmFsbGJhY2snKTt9XG4gIH1cbiAgcHJpdmF0ZSBhc3luYyBmYWxsYmFja0N1cnJlbnQoKXtcbiAgICBpZighdGhpcy5jdXJyZW50fHx0aGlzLmRpc3Bvc2VkKXJldHVybjtcbiAgICBjb25zdCB7c25hcHNob3QscGhhc2Usc2l0ZXN9PXRoaXMuY3VycmVudDtcbiAgICB0cnl7YXdhaXQgdGhpcy5wcmVwYXJlRmFsbGJhY2soc25hcHNob3QscGhhc2Usc2l0ZXMpO31jYXRjaChlcnJvcil7aWYoIXRoaXMuZGlzcG9zZWQpY29uc29sZS5lcnJvcignQ2FudmFzIHJlc291cmNlcyB1bmF2YWlsYWJsZScsZXJyb3IpO31cbiAgfVxuICBwcml2YXRlIGFzeW5jIHJlY292ZXJDdXJyZW50KCl7XG4gICAgaWYoIXRoaXMuY3VycmVudHx8dGhpcy5kaXNwb3NlZClyZXR1cm47XG4gICAgY29uc3Qge3NuYXBzaG90LHBoYXNlLHNpdGVzfT10aGlzLmN1cnJlbnQ7XG4gICAgY29uc3QgcmV2aXNpb249dGhpcy5yZXZpc2lvbisxO1xuICAgIHRyeXthd2FpdCB0aGlzLnByZXBhcmUoc25hcHNob3QscGhhc2Usc2l0ZXMpO31jYXRjaChlcnJvcil7XG4gICAgICBpZihyZXZpc2lvbiE9PXRoaXMucmV2aXNpb24pcmV0dXJuO1xuICAgICAgdGhpcy5mYWlsZWQ9dHJ1ZTt0aGlzLmVuYWJsZWQ9ZmFsc2U7dGhpcy5zdGFjay5oaWRkZW49dHJ1ZTtcbiAgICAgIHJlc291cmNlUGFuZWwoKS5yZW5kZXJlcj1yZXNvdXJjZVRleHQoJzJEIMK3IEdQVSDmgaLlpI3lpLHotKXlkI7lm57pgIAnLCcyRCDCtyBHUFUgcmVjb3ZlcnkgZmFsbGJhY2snKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0dQVSByZWNvdmVyeSBmYWlsZWQ7IHVzaW5nIENhbnZhcycsZXJyb3IpO2F3YWl0IHRoaXMuZmFsbGJhY2tDdXJyZW50KCk7XG4gICAgfVxuICB9XG4gIHByaXZhdGUgYXN5bmMgcHJlcGFyZUZhbGxiYWNrKHNuYXBzaG90OkdhbWVTbmFwc2hvdCxwaGFzZTpSZXNvdXJjZVBoYXNlLHNpdGVzOnJlYWRvbmx5IHN0cmluZ1tdPVtdKXtcbiAgICBhd2FpdCByZXNvdXJjZXMud2FybSgncmVuZGVyZXInLHBoYXNlKTtcbiAgICBpZih0aGlzLmRpc3Bvc2VkKXJldHVybjtcbiAgICBjb25zdCB7d29ybGRNb2RlbHMsbWF0Y2hNb2RlbEtleXMsc25hcHNob3RNb2RlbEtleXN9PWF3YWl0IGltcG9ydCgnLi93b3JsZDNkL21vZGVsLWxpYnJhcnknKTtcbiAgICBjb25zdCB7YWN0aXZhdGVNb2RlbFBvcnRyYWl0c309YXdhaXQgaW1wb3J0KCcuL3dvcmxkM2QvbW9kZWwtcG9ydHJhaXRzJyk7XG4gICAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47XG4gICAgYXdhaXQgd29ybGRNb2RlbHMucHJlcGFyZShwaGFzZT09PSdtYXRjaCc/bWF0Y2hNb2RlbEtleXM6Wy4uLnNuYXBzaG90TW9kZWxLZXlzKHNuYXBzaG90KSwuLi5zaXRlcy5tYXAoa2luZD0+YGJ1aWxkaW5ncy8ke2tpbmR9YCldLHBoYXNlKTtcbiAgICBpZighdGhpcy5kaXNwb3NlZClhY3RpdmF0ZU1vZGVsUG9ydHJhaXRzKCk7XG4gIH1cbiAgZHJhdyhmcmFtZTpXb3JsZEZyYW1lLHBoYXNlOlJlc291cmNlUGhhc2U9dGhpcy5jdXJyZW50Py5waGFzZT8/J2hvbWUnKXtcbiAgICBpZih0aGlzLmRpc3Bvc2VkKXJldHVybjtcbiAgICBmcmFtZT17Li4uZnJhbWUsd2FrZXM6dGhpcy53YWtlcyx2aWV3SW5kZXg6dGhpcy52aWV3SW5kZXh9O1xuICAgIHJlc291cmNlcy5waGFzZT1waGFzZTtcbiAgICBjb25zdCBjaGFuZ2VkPXRoaXMuY3VycmVudD8ucGhhc2UhPT1waGFzZTtcbiAgICB0aGlzLmN1cnJlbnQ9e3NuYXBzaG90OmZyYW1lLnNuYXBzaG90LHBoYXNlLHNpdGVzOk9iamVjdC52YWx1ZXMoZnJhbWUuYnVpbGRpbmdNb2RlbHM/P3t9KX07XG4gICAgaWYoY2hhbmdlZCAmJiAhdGhpcy5lbmFibGVkKXt0aGlzLnJldmlzaW9uKys7dm9pZCB0aGlzLnJlY292ZXJDdXJyZW50KCk7fVxuICAgIGNvbnN0IGRwcj1NYXRoLm1pbihkZXZpY2VQaXhlbFJhdGlvLDIpLHdpZHRoPWZyYW1lLnZpZXcud2lkdGgsaGVpZ2h0PWZyYW1lLnZpZXcuaGVpZ2h0O1xuICAgIGlmKCF0aGlzLmVuYWJsZWR8fCF0aGlzLmxheWVyKXt0aGlzLnN0YWNrLmhpZGRlbj10cnVlO2RyYXdXb3JsZChmcmFtZSk7cmV0dXJuO31cbiAgICB0aGlzLnN0YWNrLmhpZGRlbj1mYWxzZTtcbiAgICBjb25zdCBkaW1lbnNpb25zPWAke3dpZHRofToke2hlaWdodH06JHtkcHJ9YDtcbiAgICBpZihkaW1lbnNpb25zIT09dGhpcy5kaW1lbnNpb25zKXt0aGlzLmdyb3VuZC53aWR0aD1NYXRoLnJvdW5kKHdpZHRoKmRwcik7dGhpcy5ncm91bmQuaGVpZ2h0PU1hdGgucm91bmQoaGVpZ2h0KmRwcik7dGhpcy5kaW1lbnNpb25zPWRpbWVuc2lvbnM7fVxuICAgIHRyeXt0aGlzLmxheWVyLmRyYXcoZnJhbWUpO31jYXRjaChlcnJvcil7XG4gICAgICAvLyBBIGdyYXBoaWNzL2NvbnRleHQgZmFpbHVyZSBjYW5ub3Qgc3RvcCB0aGUgZ2FtZSBsb29wIG9yIGF1dGhvcml0YXRpdmVcbiAgICAgIC8vIHNpbXVsYXRpb24uIFRoZSBhdXRob3JlZCBDYW52YXMgcGF0aCByZW1haW5zIHVzYWJsZSB3aGlsZSBhc3NldHMgd2FybS5cbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0dQVSBwcmVzZW50YXRpb24gZmFpbGVkOyB1c2luZyBDYW52YXMnLGVycm9yKTt0aGlzLmZhaWxlZD10cnVlO3RoaXMucmV2aXNpb24rKzt0aGlzLmVuYWJsZWQ9ZmFsc2U7dGhpcy5zdGFjay5oaWRkZW49dHJ1ZTtcbiAgICAgIHJlc291cmNlUGFuZWwoKS5yZW5kZXJlcj1yZXNvdXJjZVRleHQoJzJEIMK3IEdQVSDmuLLmn5PlpLHotKXlkI7lm57pgIAnLCcyRCDCtyBHUFUgcmVuZGVyaW5nIGZhbGxiYWNrJyk7XG4gICAgICB2b2lkIHRoaXMuZmFsbGJhY2tDdXJyZW50KCk7ZHJhd1dvcmxkKGZyYW1lKTtyZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGdyb3VuZD10aGlzLmdyb3VuZC5nZXRDb250ZXh0KCcyZCcpITtncm91bmQuc2V0VHJhbnNmb3JtKDEsMCwwLDEsMCwwKTtncm91bmQuY2xlYXJSZWN0KDAsMCx0aGlzLmdyb3VuZC53aWR0aCx0aGlzLmdyb3VuZC5oZWlnaHQpO2dyb3VuZC5zZXRUcmFuc2Zvcm0oZHByLDAsMCxkcHIsMCwwKTtcbiAgICBjb25zdCBjb21tb249e2FjdG9yUG9zaXRpb25zOnRoaXMubGF5ZXIucG9zaXRpb25zLHBoeXNpY2FsRWZmZWN0czp0aGlzLmVmZmVjdFR5cGVzISxwaHlzaWNhbENvbWJhdDp0cnVlLGRlcHRoU2VsZWN0aW9uOnRydWV9O1xuICAgIGRyYXdXb3JsZCh7Li4uZnJhbWUsLi4uY29tbW9uLGN0eDpncm91bmQscGFzczonZ3JvdW5kJ30pO1xuICAgIGZyYW1lLmN0eC5zYXZlKCk7ZnJhbWUuY3R4LnNldFRyYW5zZm9ybSgxLDAsMCwxLDAsMCk7ZnJhbWUuY3R4LmNsZWFyUmVjdCgwLDAsdGhpcy5jYW52YXMud2lkdGgsdGhpcy5jYW52YXMuaGVpZ2h0KTtmcmFtZS5jdHgucmVzdG9yZSgpO1xuICAgIGRyYXdXb3JsZCh7Li4uZnJhbWUsLi4uY29tbW9uLHBhc3M6J292ZXJsYXknfSk7XG4gIH1cbiAgcGljayhwb2ludDp7eDpudW1iZXI7eTpudW1iZXJ9KXtyZXR1cm4gdGhpcy5lbmFibGVkP3RoaXMubGF5ZXI/LnBpY2socG9pbnQpOnVuZGVmaW5lZDt9XG4gIHBsYW5lKHBvaW50Ont4Om51bWJlcjt5Om51bWJlcn0saGVpZ2h0Om51bWJlcil7cmV0dXJuIHRoaXMuZW5hYmxlZD90aGlzLmxheWVyPy5wbGFuZShwb2ludCxoZWlnaHQpOnVuZGVmaW5lZDt9XG4gIHBvc2l0aW9uKGlkOnN0cmluZyl7cmV0dXJuIHRoaXMuZW5hYmxlZD90aGlzLmxheWVyPy5wb3NpdGlvbnMuZ2V0KGlkKTp1bmRlZmluZWQ7fVxuICBnZXQgaXMzRCgpe3JldHVybiB0aGlzLmVuYWJsZWQ7fVxuICByZXNldCgpe3RoaXMucmV2aXNpb24rKzt0aGlzLmN1cnJlbnQ9dW5kZWZpbmVkO3RoaXMubGF5ZXI/LnJlc2V0KCk7dGhpcy53YWtlcz1uZXcgU2hpcFdha2VUcmFja2VyKCk7dGhpcy52aWV3SW5kZXgucmVzZXQoKTt9XG4gIGRpc3Bvc2UoKXtcbiAgICBpZih0aGlzLmRpc3Bvc2VkKXJldHVybjt0aGlzLmRpc3Bvc2VkPXRydWU7dGhpcy5yZXZpc2lvbisrO3RoaXMuZW5hYmxlZD1mYWxzZTt0aGlzLmN1cnJlbnQ9dW5kZWZpbmVkO1xuICAgIHRoaXMuYWN0b3JzLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dGxvc3QnLHRoaXMub25Db250ZXh0TG9zdCk7dGhpcy5hY3RvcnMucmVtb3ZlRXZlbnRMaXN0ZW5lcignd2ViZ2xjb250ZXh0cmVzdG9yZWQnLHRoaXMub25Db250ZXh0UmVzdG9yZWQpO1xuICAgIHRoaXMubGF5ZXI/LmRpc3Bvc2UoKTt0aGlzLmxheWVyPXVuZGVmaW5lZDt0aGlzLmNvbnRleHQ9bnVsbDt0aGlzLmVmZmVjdFR5cGVzPXVuZGVmaW5lZDt0aGlzLndha2VzPW5ldyBTaGlwV2FrZVRyYWNrZXIoKTtcbiAgICB0aGlzLnZpZXdJbmRleC5yZXNldCgpO1xuICAgIHRoaXMuc3RhY2suaGlkZGVuPXRydWU7dGhpcy5zdGFjay5yZW1vdmUoKTt0aGlzLmdyb3VuZC53aWR0aD10aGlzLmdyb3VuZC5oZWlnaHQ9dGhpcy5hY3RvcnMud2lkdGg9dGhpcy5hY3RvcnMuaGVpZ2h0PTA7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUM7QUFDMUMsU0FBUyxXQUFVLG9CQUF1QztBQUMxRCxTQUFTLHFCQUFxQjtBQUc5QixPQUFPO0FBQ1AsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUSw2QkFBNEI7QUFNN0IsYUFBTSxrQkFBa0I7QUFBQSxFQXdCN0IsWUFBb0IsUUFBeUI7QUFBekI7QUFDbEIsU0FBSyxNQUFNLFlBQVU7QUFBaUIsU0FBSyxPQUFPLFlBQVU7QUFBZSxTQUFLLE9BQU8sWUFBVTtBQUNqRyxTQUFLLE1BQU0sU0FBTztBQUFLLFNBQUssTUFBTSxPQUFPLEtBQUssUUFBTyxLQUFLLE1BQU07QUFBRSxXQUFPLE9BQU8sS0FBSyxLQUFLO0FBQUEsRUFDNUY7QUFBQSxFQTFCUSxZQUFVLElBQUksc0JBQXNCO0FBQUEsRUFDcEMsUUFBTSxJQUFJLGdCQUFnQjtBQUFBLEVBQzFCLFNBQU8sU0FBUyxjQUFjLFFBQVE7QUFBQSxFQUN0QyxTQUFPLFNBQVMsY0FBYyxRQUFRO0FBQUEsRUFDdEMsUUFBTSxTQUFTLGNBQWMsS0FBSztBQUFBLEVBQ2xDO0FBQUEsRUFDQSxZQUFVO0FBQUEsRUFDVixVQUFxQztBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLEVBQ0EsV0FBUztBQUFBLEVBQ1QsY0FBWTtBQUFBLEVBQ1osU0FBTztBQUFBLEVBQ1A7QUFBQSxFQUNBLGFBQVc7QUFBQSxFQUNYLFVBQVE7QUFBQSxFQUNSLFdBQVM7QUFBQSxFQUNULGdCQUFjLENBQUMsVUFBYztBQUNuQyxVQUFNLGVBQWU7QUFBRSxTQUFLLGNBQVk7QUFBSyxTQUFLO0FBQVcsU0FBSyxVQUFRO0FBQU0sU0FBSyxNQUFNLFNBQU87QUFDbEcsa0JBQWMsRUFBRSxXQUFTLGFBQWEsZ0JBQWUsNEJBQTRCO0FBQ2pGLFNBQUssS0FBSyxnQkFBZ0I7QUFBQSxFQUM1QjtBQUFBLEVBQ1Esb0JBQWtCLE1BQUk7QUFBQyxTQUFLLGNBQVk7QUFBTSxTQUFLLFNBQU87QUFBTSxTQUFLLEtBQUssZUFBZTtBQUFBLEVBQUU7QUFBQSxFQUtuRyxNQUFNLFFBQVEsVUFBc0IsT0FBb0IsUUFBd0IsQ0FBQyxHQUFFO0FBQ2pGLFFBQUcsS0FBSyxTQUFTO0FBQ2pCLFVBQU0sV0FBUyxFQUFFLEtBQUs7QUFDdEIsU0FBSyxVQUFRLEVBQUMsVUFBUyxPQUFNLE1BQUs7QUFDbEMsU0FBSyxVQUFRO0FBQU0sU0FBSyxNQUFNLFNBQU87QUFDckMsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixRQUFHLGFBQVcsS0FBSyxTQUFTO0FBQzVCLFFBQUcsS0FBSyxTQUFTLENBQUMsS0FBSyxlQUFlLENBQUMsS0FBSyxRQUFPO0FBQ2pELFlBQU0sVUFBVSxLQUFLLFlBQVcsS0FBSztBQUNyQyxVQUFHLGFBQVcsS0FBSyxTQUFTO0FBQzVCLG9CQUFjLEVBQUUsVUFBVSxhQUFhLGFBQVksaUNBQWlDLENBQUM7QUFDckYsWUFBTSxLQUFLLE1BQU0sUUFBUSxVQUFTLE9BQU0sS0FBSztBQUM3QyxVQUFHLGFBQVcsS0FBSyxZQUFZLEtBQUssZUFBZSxLQUFLLE9BQU87QUFDL0QsV0FBSyxNQUFNLE1BQU07QUFBRSxXQUFLLFVBQVE7QUFDaEMsb0JBQWMsRUFBRSxXQUFTLGFBQWEsd0JBQXVCLHNEQUFzRDtBQUFBLElBQ3JILE9BQUs7QUFDSCxZQUFNLEtBQUssZ0JBQWdCLFVBQVMsT0FBTSxLQUFLO0FBQy9DLFVBQUcsYUFBVyxLQUFLLFlBQVksQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLE9BQU8sZUFBYyxFQUFFLFdBQVMsYUFBYSxzQkFBcUIsd0NBQXdDO0FBQUEsSUFDdEs7QUFBQSxFQUNGO0FBQUEsRUFDUSxXQUFXLE9BQW9CO0FBQ3JDLFFBQUcsQ0FBQyxLQUFLLGFBQWEsTUFBSyxlQUFhLEtBQUssWUFBWSxLQUFLLEVBQUUsUUFBUSxNQUFJO0FBQUMsV0FBSyxlQUFhO0FBQUEsSUFBVSxDQUFDO0FBQzFHLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLE1BQWMsWUFBWSxPQUFvQjtBQUM1QyxRQUFHLENBQUMsS0FBSyxXQUFVO0FBQ2pCLFdBQUssWUFBVTtBQUNmLFdBQUssVUFBUSxLQUFLLE9BQU8sV0FBVyxVQUFTLEVBQUMsT0FBTSxNQUFLLFdBQVUsS0FBSSxDQUFDO0FBQ3hFLFVBQUcsS0FBSyxTQUFRO0FBQ2QsYUFBSyxPQUFPLGlCQUFpQixvQkFBbUIsS0FBSyxhQUFhO0FBQ2xFLGFBQUssT0FBTyxpQkFBaUIsd0JBQXVCLEtBQUssaUJBQWlCO0FBQUEsTUFDNUU7QUFBQSxJQUNGO0FBQ0EsUUFBRyxDQUFDLEtBQUssV0FBVyxLQUFLLFNBQVMsS0FBSyxlQUFlLEtBQUssT0FBTztBQUNsRSxVQUFNLFVBQVUsS0FBSyxZQUFXLEtBQUs7QUFDckMsUUFBRyxLQUFLLFNBQVM7QUFDakIsVUFBTSxTQUFPLE1BQU0sT0FBTyx1QkFBdUI7QUFDakQsUUFBRyxLQUFLLGVBQWEsS0FBSyxTQUFTO0FBQ25DLFFBQUc7QUFBQyxXQUFLLFFBQU0sT0FBTyxhQUFhLE9BQU8sS0FBSyxRQUFPLEtBQUssT0FBTztBQUFFLFdBQUssY0FBWSxPQUFPO0FBQUEsSUFBaUIsU0FDdkcsT0FBTTtBQUFDLFdBQUssU0FBTztBQUFLLGNBQVEsS0FBSywwQ0FBeUMsS0FBSztBQUFFLG9CQUFjLEVBQUUsV0FBUyxhQUFhLHFCQUFvQixrQ0FBa0M7QUFBQSxJQUFFO0FBQUEsRUFDM0w7QUFBQSxFQUNBLE1BQWMsa0JBQWlCO0FBQzdCLFFBQUcsQ0FBQyxLQUFLLFdBQVMsS0FBSyxTQUFTO0FBQ2hDLFVBQU0sRUFBQyxVQUFTLE9BQU0sTUFBSyxJQUFFLEtBQUs7QUFDbEMsUUFBRztBQUFDLFlBQU0sS0FBSyxnQkFBZ0IsVUFBUyxPQUFNLEtBQUs7QUFBQSxJQUFFLFNBQU8sT0FBTTtBQUFDLFVBQUcsQ0FBQyxLQUFLLFNBQVMsU0FBUSxNQUFNLGdDQUErQixLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQzNJO0FBQUEsRUFDQSxNQUFjLGlCQUFnQjtBQUM1QixRQUFHLENBQUMsS0FBSyxXQUFTLEtBQUssU0FBUztBQUNoQyxVQUFNLEVBQUMsVUFBUyxPQUFNLE1BQUssSUFBRSxLQUFLO0FBQ2xDLFVBQU0sV0FBUyxLQUFLLFdBQVM7QUFDN0IsUUFBRztBQUFDLFlBQU0sS0FBSyxRQUFRLFVBQVMsT0FBTSxLQUFLO0FBQUEsSUFBRSxTQUFPLE9BQU07QUFDeEQsVUFBRyxhQUFXLEtBQUssU0FBUztBQUM1QixXQUFLLFNBQU87QUFBSyxXQUFLLFVBQVE7QUFBTSxXQUFLLE1BQU0sU0FBTztBQUN0RCxvQkFBYyxFQUFFLFdBQVMsYUFBYSxvQkFBbUIsNEJBQTRCO0FBQ3JGLGNBQVEsTUFBTSxxQ0FBb0MsS0FBSztBQUFFLFlBQU0sS0FBSyxnQkFBZ0I7QUFBQSxJQUN0RjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQWMsZ0JBQWdCLFVBQXNCLE9BQW9CLFFBQXdCLENBQUMsR0FBRTtBQUNqRyxVQUFNLFVBQVUsS0FBSyxZQUFXLEtBQUs7QUFDckMsUUFBRyxLQUFLLFNBQVM7QUFDakIsVUFBTSxFQUFDLGFBQVksZ0JBQWUsa0JBQWlCLElBQUUsTUFBTSxPQUFPLHlCQUF5QjtBQUMzRixVQUFNLEVBQUMsdUJBQXNCLElBQUUsTUFBTSxPQUFPLDJCQUEyQjtBQUN2RSxRQUFHLEtBQUssU0FBUztBQUNqQixVQUFNLFlBQVksUUFBUSxVQUFRLFVBQVEsaUJBQWUsQ0FBQyxHQUFHLGtCQUFrQixRQUFRLEdBQUUsR0FBRyxNQUFNLElBQUksVUFBTSxhQUFhLElBQUksRUFBRSxDQUFDLEdBQUUsS0FBSztBQUN2SSxRQUFHLENBQUMsS0FBSyxTQUFTLHdCQUF1QjtBQUFBLEVBQzNDO0FBQUEsRUFDQSxLQUFLLE9BQWlCLFFBQW9CLEtBQUssU0FBUyxTQUFPLFFBQU87QUFDcEUsUUFBRyxLQUFLLFNBQVM7QUFDakIsWUFBTSxFQUFDLEdBQUcsT0FBTSxPQUFNLEtBQUssT0FBTSxXQUFVLEtBQUssVUFBUztBQUN6RCxjQUFVLFFBQU07QUFDaEIsVUFBTSxVQUFRLEtBQUssU0FBUyxVQUFRO0FBQ3BDLFNBQUssVUFBUSxFQUFDLFVBQVMsTUFBTSxVQUFTLE9BQU0sT0FBTSxPQUFPLE9BQU8sTUFBTSxrQkFBZ0IsQ0FBQyxDQUFDLEVBQUM7QUFDekYsUUFBRyxXQUFXLENBQUMsS0FBSyxTQUFRO0FBQUMsV0FBSztBQUFXLFdBQUssS0FBSyxlQUFlO0FBQUEsSUFBRTtBQUN4RSxVQUFNLE1BQUksS0FBSyxJQUFJLGtCQUFpQixDQUFDLEdBQUUsUUFBTSxNQUFNLEtBQUssT0FBTSxTQUFPLE1BQU0sS0FBSztBQUNoRixRQUFHLENBQUMsS0FBSyxXQUFTLENBQUMsS0FBSyxPQUFNO0FBQUMsV0FBSyxNQUFNLFNBQU87QUFBSyxnQkFBVSxLQUFLO0FBQUU7QUFBQSxJQUFPO0FBQzlFLFNBQUssTUFBTSxTQUFPO0FBQ2xCLFVBQU0sYUFBVyxHQUFHLEtBQUssSUFBSSxNQUFNLElBQUksR0FBRztBQUMxQyxRQUFHLGVBQWEsS0FBSyxZQUFXO0FBQUMsV0FBSyxPQUFPLFFBQU0sS0FBSyxNQUFNLFFBQU0sR0FBRztBQUFFLFdBQUssT0FBTyxTQUFPLEtBQUssTUFBTSxTQUFPLEdBQUc7QUFBRSxXQUFLLGFBQVc7QUFBQSxJQUFXO0FBQzlJLFFBQUc7QUFBQyxXQUFLLE1BQU0sS0FBSyxLQUFLO0FBQUEsSUFBRSxTQUFPLE9BQU07QUFHdEMsY0FBUSxNQUFNLHlDQUF3QyxLQUFLO0FBQUUsV0FBSyxTQUFPO0FBQUssV0FBSztBQUFXLFdBQUssVUFBUTtBQUFNLFdBQUssTUFBTSxTQUFPO0FBQ25JLG9CQUFjLEVBQUUsV0FBUyxhQUFhLG9CQUFtQiw2QkFBNkI7QUFDdEYsV0FBSyxLQUFLLGdCQUFnQjtBQUFFLGdCQUFVLEtBQUs7QUFBRTtBQUFBLElBQy9DO0FBQ0EsVUFBTSxTQUFPLEtBQUssT0FBTyxXQUFXLElBQUk7QUFBRyxXQUFPLGFBQWEsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUM7QUFBRSxXQUFPLFVBQVUsR0FBRSxHQUFFLEtBQUssT0FBTyxPQUFNLEtBQUssT0FBTyxNQUFNO0FBQUUsV0FBTyxhQUFhLEtBQUksR0FBRSxHQUFFLEtBQUksR0FBRSxDQUFDO0FBQzFLLFVBQU0sU0FBTyxFQUFDLGdCQUFlLEtBQUssTUFBTSxXQUFVLGlCQUFnQixLQUFLLGFBQWEsZ0JBQWUsTUFBSyxnQkFBZSxLQUFJO0FBQzNILGNBQVUsRUFBQyxHQUFHLE9BQU0sR0FBRyxRQUFPLEtBQUksUUFBTyxNQUFLLFNBQVEsQ0FBQztBQUN2RCxVQUFNLElBQUksS0FBSztBQUFFLFVBQU0sSUFBSSxhQUFhLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDO0FBQUUsVUFBTSxJQUFJLFVBQVUsR0FBRSxHQUFFLEtBQUssT0FBTyxPQUFNLEtBQUssT0FBTyxNQUFNO0FBQUUsVUFBTSxJQUFJLFFBQVE7QUFDckksY0FBVSxFQUFDLEdBQUcsT0FBTSxHQUFHLFFBQU8sTUFBSyxVQUFTLENBQUM7QUFBQSxFQUMvQztBQUFBLEVBQ0EsS0FBSyxPQUEwQjtBQUFDLFdBQU8sS0FBSyxVQUFRLEtBQUssT0FBTyxLQUFLLEtBQUssSUFBRTtBQUFBLEVBQVU7QUFBQSxFQUN0RixNQUFNLE9BQTBCLFFBQWM7QUFBQyxXQUFPLEtBQUssVUFBUSxLQUFLLE9BQU8sTUFBTSxPQUFNLE1BQU0sSUFBRTtBQUFBLEVBQVU7QUFBQSxFQUM3RyxTQUFTLElBQVU7QUFBQyxXQUFPLEtBQUssVUFBUSxLQUFLLE9BQU8sVUFBVSxJQUFJLEVBQUUsSUFBRTtBQUFBLEVBQVU7QUFBQSxFQUNoRixJQUFJLE9BQU07QUFBQyxXQUFPLEtBQUs7QUFBQSxFQUFRO0FBQUEsRUFDL0IsUUFBTztBQUFDLFNBQUs7QUFBVyxTQUFLLFVBQVE7QUFBVSxTQUFLLE9BQU8sTUFBTTtBQUFFLFNBQUssUUFBTSxJQUFJLGdCQUFnQjtBQUFFLFNBQUssVUFBVSxNQUFNO0FBQUEsRUFBRTtBQUFBLEVBQzNILFVBQVM7QUFDUCxRQUFHLEtBQUssU0FBUztBQUFPLFNBQUssV0FBUztBQUFLLFNBQUs7QUFBVyxTQUFLLFVBQVE7QUFBTSxTQUFLLFVBQVE7QUFDM0YsU0FBSyxPQUFPLG9CQUFvQixvQkFBbUIsS0FBSyxhQUFhO0FBQUUsU0FBSyxPQUFPLG9CQUFvQix3QkFBdUIsS0FBSyxpQkFBaUI7QUFDcEosU0FBSyxPQUFPLFFBQVE7QUFBRSxTQUFLLFFBQU07QUFBVSxTQUFLLFVBQVE7QUFBSyxTQUFLLGNBQVk7QUFBVSxTQUFLLFFBQU0sSUFBSSxnQkFBZ0I7QUFDdkgsU0FBSyxVQUFVLE1BQU07QUFDckIsU0FBSyxNQUFNLFNBQU87QUFBSyxTQUFLLE1BQU0sT0FBTztBQUFFLFNBQUssT0FBTyxRQUFNLEtBQUssT0FBTyxTQUFPLEtBQUssT0FBTyxRQUFNLEtBQUssT0FBTyxTQUFPO0FBQUEsRUFDdkg7QUFDRjsiLCJuYW1lcyI6W119