import { detCos, detSin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/det-math.ts";
import { bodyMass } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/physical-body.ts";
import { shipsIn, authoredShipScale, localToWorld, shipPassengers, shipProfile, worldToLocal } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { perTick } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
import { capsuleClearsBodies, capsuleClearsCircles, diskInConvex, expandConvex } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/navigation-math.ts";
import { isInCabin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-cabin.ts";
import { gangwayBetween, gangwayCrossingPosition } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-gangway.ts";
export function deckLoad(units, ship) {
  return (ship.holdMass ?? 0) + shipPassengers(units, ship).reduce((sum, unit) => sum + bodyMass(unit), 0);
}
export function deckPointFits(ship, passenger, point, units, occupied = true) {
  const profile = shipProfile(ship);
  if (!profile || !diskInConvex(point, passenger.radius + 1, profile.deck)) return false;
  if (profile.obstacles.some((o) => Math.hypot(point.x - o.x, point.y - o.y) < o.radius + passenger.radius + 1 - 1e-6)) return false;
  return !occupied || !shipPassengers(units, ship).some((other) => other.hp > 0 && !isInCabin(other) && other.id !== passenger.id && Math.hypot(point.x - other.deck.x, point.y - other.deck.y) < passenger.radius + other.radius + 1 - 1e-6);
}
export function deckPlacement(ship, passenger, units, preferred = { x: 0, y: 0 }, occupied = true, spacing = 4) {
  const profile = shipProfile(ship);
  if (!profile) return void 0;
  if (deckPointFits(ship, passenger, preferred, units, occupied)) return preferred;
  let best, score = Infinity;
  for (let y = -profile.beam / 2; y <= profile.beam / 2; y += spacing) for (let x = -profile.length / 2; x <= profile.length / 2; x += spacing) {
    const point = { x, y }, value = (x - preferred.x) ** 2 + (y - preferred.y) ** 2;
    if (value < score && deckPointFits(ship, passenger, point, units, occupied)) {
      best = point;
      score = value;
    }
  }
  return best;
}
export function projectDeckPoint(ship, passenger, preferred, units) {
  const profile = shipProfile(ship);
  if (!profile) return void 0;
  if (deckPointFits(ship, passenger, preferred, units)) return preferred;
  if (diskInConvex(preferred, passenger.radius + 1, profile.deck)) return deckPlacement(ship, passenger, units, preferred, true, 2);
  const floor = expandConvex(profile.deck, -passenger.radius - 1 - 1e-6);
  let nearest, score = Infinity;
  for (let i = 0; i < floor.length; i++) {
    const a = floor[i], b = floor[(i + 1) % floor.length], dx = b.x - a.x, dy = b.y - a.y;
    const t = Math.max(0, Math.min(1, ((preferred.x - a.x) * dx + (preferred.y - a.y) * dy) / (dx * dx + dy * dy)));
    const point = { x: a.x + dx * t, y: a.y + dy * t }, distance = (point.x - preferred.x) ** 2 + (point.y - preferred.y) ** 2;
    if (distance < score) {
      nearest = point;
      score = distance;
    }
  }
  if (nearest && deckPointFits(ship, passenger, nearest, units)) return nearest;
  return deckPlacement(ship, passenger, units, preferred, true, 2);
}
export function canBoard(ship, passenger, units) {
  const profile = shipProfile(ship);
  if (!profile || shipProfile(passenger) || isInCabin(passenger)) return false;
  if (passenger.deck) {
    const source = units.find((unit) => unit.id === passenger.deck.shipId), sourceProfile = source && shipProfile(source);
    if (!sourceProfile || source.id === ship.id || Math.abs(profile.deckHeight - sourceProfile.deckHeight) > passenger.radius * 2 && !gangwayBetween(source, ship, passenger)) return false;
  } else if (ship.owner !== passenger.owner) return false;
  return deckLoad(units, ship) + bodyMass(passenger) <= profile.loadCapacity && !!deckPlacement(ship, passenger, units);
}
export function boardUnit(ship, passenger, units) {
  const profile = shipProfile(ship);
  if (!profile || passenger.deck || deckLoad(units, ship) + bodyMass(passenger) > profile.loadCapacity) return false;
  const point = deckPlacement(ship, passenger, units, { x: -profile.length / 2, y: -profile.beam / 2 }, true, 2);
  if (!point) return false;
  passenger.deck = { shipId: ship.id, ...point };
  passenger.aim = void 0;
  Object.assign(passenger, localToWorld(ship, point));
  return true;
}
export function syncDecks(units) {
  const vessels = shipsIn(units);
  if (!vessels.length) return;
  const ships = new Map(vessels.map((ship) => [ship.id, ship]));
  for (const ship of ships.values()) {
    const profile = shipProfile(ship), crew = shipPassengers(units, ship);
    const cabin = profile.obstacles.find((obstacle) => obstacle.type === "cabin");
    const load = (ship.holdMass ?? 0) + crew.reduce((sum, unit) => sum + bodyMass(unit), 0);
    const offset = load ? Math.hypot(crew.reduce((s, u) => s + (isInCabin(u) ? cabin?.x ?? u.deck.x : u.deck.x) * bodyMass(u), 0), crew.reduce((s, u) => s + (isInCabin(u) ? cabin?.y ?? u.deck.y : u.deck.y) * bodyMass(u), 0)) / load : 0;
    ship.sailing ??= { heading: 0, speed: 0, load: 0, balance: 0 };
    ship.sailing.load = load;
    ship.sailing.balance = offset / (profile.length / 2);
  }
  for (const unit of units) if (unit.deck) {
    const ship = ships.get(unit.deck.shipId);
    const crossing = unit.gangway && gangwayCrossingPosition(unit.gangway, units);
    if (ship) {
      if (crossing) {
        Object.assign(unit, crossing);
        Object.assign(unit.deck, worldToLocal(ship, crossing));
      } else Object.assign(unit, localToWorld(ship, unit.deck));
    }
  }
}
export function settleGangwayCrossings(units) {
  for (const passenger of units) {
    const crossing = passenger.gangway;
    if (!crossing || passenger.hp <= 0 || gangwayCrossingPosition(crossing, units)) continue;
    const parent = units.find((ship) => ship.id === passenger.deck?.shipId);
    if (!parent || parent.hp <= 0) continue;
    const endpoints = [crossing.sourceId, crossing.targetId].map((id) => units.find((ship) => ship.id === id && ship.hp > 0)).filter((ship) => !!ship);
    endpoints.sort((a, b) => Math.hypot(passenger.x - a.x, passenger.y - a.y) - Math.hypot(passenger.x - b.x, passenger.y - b.y));
    for (const ship of endpoints) {
      if (ship !== parent && deckLoad(units, ship) + bodyMass(passenger) > shipProfile(ship).loadCapacity) continue;
      const point = deckPlacement(ship, passenger, units, worldToLocal(ship, passenger));
      if (!point) continue;
      passenger.deck = { shipId: ship.id, ...point };
      delete passenger.gangway;
      Object.assign(passenger, localToWorld(ship, point));
      break;
    }
  }
}
function clearPath(ship, passenger, a, b, units, avoidCrew = false) {
  const profile = shipProfile(ship);
  return diskInConvex(a, passenger.radius + 1, profile.deck) && diskInConvex(b, passenger.radius + 1, profile.deck) && capsuleClearsCircles(a, b, passenger.radius + 1, profile.obstacles) && (!avoidCrew || capsuleClearsBodies(a, b, passenger.radius + 1, shipPassengers(units, ship).filter((other) => other.id !== passenger.id && other.hp > 0 && !isInCabin(other)).map((other) => ({ ...other.deck, radius: other.radius }))));
}
function deckWaypoint(ship, passenger, goal, units, avoidCrew = false) {
  const start = passenger.deck, profile = shipProfile(ship);
  if (clearPath(ship, passenger, start, goal, units, avoidCrew)) return goal;
  const nodes = [start, goal];
  for (const point of expandConvex(profile.deck, -passenger.radius - 1 - 1e-4))
    if (deckPointFits(ship, passenger, point, units, false)) nodes.push(point);
  const obstacles = [...profile.obstacles, ...avoidCrew ? shipPassengers(units, ship).filter((other) => other.id !== passenger.id && other.hp > 0 && !isInCabin(other)).map((other) => ({ ...other.deck, radius: other.radius })) : []];
  for (const o of obstacles) for (let i = 0; i < 12; i++) {
    const angle = i * Math.PI / 6, r = (o.radius + passenger.radius + 3) / detCos(Math.PI / 12);
    const point = { x: o.x + detCos(angle) * r, y: o.y + detSin(angle) * r };
    if (deckPointFits(ship, passenger, point, units, false)) nodes.push(point);
  }
  const cost = nodes.map(() => Infinity), previous = nodes.map(() => -1), seen = /* @__PURE__ */ new Set();
  cost[0] = 0;
  while (seen.size < nodes.length) {
    let current = -1;
    for (let i = 0; i < nodes.length; i++) if (!seen.has(i) && (current < 0 || cost[i] < cost[current])) current = i;
    if (current < 0 || !Number.isFinite(cost[current])) break;
    if (current === 1) {
      let next = 1;
      while (previous[next] > 0) next = previous[next];
      return nodes[next];
    }
    seen.add(current);
    for (let i = 0; i < nodes.length; i++) {
      const candidate = cost[current] + Math.hypot(nodes[i].x - nodes[current].x, nodes[i].y - nodes[current].y);
      if (seen.has(i) || candidate >= cost[i] || !clearPath(ship, passenger, nodes[current], nodes[i], units, avoidCrew)) continue;
      if (candidate < cost[i]) {
        cost[i] = candidate;
        previous[i] = current;
      }
    }
  }
  return start;
}
export function deckStaticPathExists(ship, passenger, goal) {
  const start = passenger.deck;
  if (start?.shipId !== ship.id || !deckPointFits(ship, passenger, goal, [], false)) return false;
  if (Math.hypot(goal.x - start.x, goal.y - start.y) < 1e-7) return true;
  const next = deckWaypoint(ship, passenger, goal, [], false);
  return Math.hypot(next.x - start.x, next.y - start.y) > 1e-7;
}
export function moveOnDeck(passenger, ship, world, units, pace = 1, avoidCrew = true) {
  if (!passenger.deck) return;
  const goal = deckPlacement(ship, passenger, units, worldToLocal(ship, world), avoidCrew);
  if (!goal) return;
  const target = deckWaypoint(ship, passenger, goal, units, avoidCrew), start = passenger.deck;
  const gap = Math.hypot(target.x - start.x, target.y - start.y), step = Math.min(gap, perTick(passenger.speed) * pace);
  if (gap === 0) return;
  const next = { x: start.x + (target.x - start.x) * step / gap, y: start.y + (target.y - start.y) * step / gap };
  if (deckPointFits(ship, passenger, next, units)) {
    Object.assign(start, next);
    Object.assign(passenger, localToWorld(ship, start));
  }
}
export function restoreCargoDecks(units) {
  const existing = new Set(units.map((u) => u.id));
  for (const ship of [...units]) {
    const cargo = ship.cargo;
    if (!cargo) continue;
    delete ship.cargo;
    for (const passenger of cargo) {
      if (existing.has(passenger.id)) continue;
      let placed = boardUnit(ship, passenger, units);
      for (let attempt = 0; !placed && attempt < 40; attempt++) {
        ship.deckScale = authoredShipScale(ship) * 1.1;
        placed = boardUnit(ship, passenger, units);
      }
      if (!placed) throw new Error(`Cannot restore passenger ${passenger.id} aboard ${ship.id}`);
      passenger.order = { type: "idle" };
      passenger.orderQueue = [];
      units.push(passenger);
      existing.add(passenger.id);
    }
  }
  syncDecks(units);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlY2tzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRldENvcywgZGV0U2luIH0gZnJvbSBcIi4vZGV0LW1hdGhcIjtcbmltcG9ydCB7IGJvZHlNYXNzIH0gZnJvbSBcIi4vcGh5c2ljYWwtYm9keVwiO1xuaW1wb3J0IHsgc2hpcHNJbiwgYXV0aG9yZWRTaGlwU2NhbGUsIGNpcmNsZUluUG9seWdvbiwgbG9jYWxUb1dvcmxkLCBzaGlwUGFzc2VuZ2Vycywgc2hpcFByb2ZpbGUsIHdvcmxkVG9Mb2NhbCwgdHlwZSBQb2ludCB9IGZyb20gXCIuL3NoaXAtZ2VvbWV0cnlcIjtcbmltcG9ydCB7IHBlclRpY2sgfSBmcm9tIFwiLi90aW1lXCI7XG5pbXBvcnQgdHlwZSB7IFVuaXQgfSBmcm9tIFwiLi90eXBlc1wiO1xuaW1wb3J0IHsgY2Fwc3VsZUNsZWFyc0JvZGllcywgY2Fwc3VsZUNsZWFyc0NpcmNsZXMsIGRpc2tJbkNvbnZleCwgZXhwYW5kQ29udmV4IH0gZnJvbSAnLi9uYXZpZ2F0aW9uLW1hdGgnO1xuaW1wb3J0IHsgaXNJbkNhYmluIH0gZnJvbSAnLi9zaGlwLWNhYmluJztcbmltcG9ydCB7IGdhbmd3YXlCZXR3ZWVuLCBnYW5nd2F5Q3Jvc3NpbmdQb3NpdGlvbiB9IGZyb20gJy4vc2hpcC1nYW5nd2F5JztcblxuZXhwb3J0IGZ1bmN0aW9uIGRlY2tMb2FkKHVuaXRzOiByZWFkb25seSBVbml0W10sIHNoaXA6IFVuaXQpIHtcbiAgcmV0dXJuIChzaGlwLmhvbGRNYXNzID8/IDApK3NoaXBQYXNzZW5nZXJzKHVuaXRzLHNoaXApLnJlZHVjZSgoc3VtLHVuaXQpPT5zdW0rYm9keU1hc3ModW5pdCksMCk7XG59XG5leHBvcnQgZnVuY3Rpb24gZGVja1BvaW50Rml0cyhzaGlwOiBVbml0LCBwYXNzZW5nZXI6IFVuaXQsIHBvaW50OiBQb2ludCwgdW5pdHM6IHJlYWRvbmx5IFVuaXRbXSwgb2NjdXBpZWQ9dHJ1ZSkge1xuICBjb25zdCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApO1xuICBpZighcHJvZmlsZSB8fCAhZGlza0luQ29udmV4KHBvaW50LHBhc3Nlbmdlci5yYWRpdXMrMSxwcm9maWxlLmRlY2spKXJldHVybiBmYWxzZTtcbiAgaWYocHJvZmlsZS5vYnN0YWNsZXMuc29tZShvPT5NYXRoLmh5cG90KHBvaW50Lngtby54LHBvaW50Lnktby55KTxvLnJhZGl1cytwYXNzZW5nZXIucmFkaXVzKzEtMWUtNikpcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gIW9jY3VwaWVkIHx8ICFzaGlwUGFzc2VuZ2Vycyh1bml0cyxzaGlwKS5zb21lKG90aGVyPT5vdGhlci5ocD4wICYmICFpc0luQ2FiaW4ob3RoZXIpICYmIG90aGVyLmlkIT09cGFzc2VuZ2VyLmlkICYmIE1hdGguaHlwb3QocG9pbnQueC1vdGhlci5kZWNrIS54LHBvaW50Lnktb3RoZXIuZGVjayEueSk8cGFzc2VuZ2VyLnJhZGl1cytvdGhlci5yYWRpdXMrMS0xZS02KTtcbn1cbi8qKiBGaW5kIGFjdHVhbCBmcmVlIGdyb3VuZCBvbiBhIGRlY2s7IG5laXRoZXIgc3VwcGx5IG5vciBhIGZpeGVkIHNsb3QgY291bnQgaXMgY29uc3VsdGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY2tQbGFjZW1lbnQoc2hpcDogVW5pdCwgcGFzc2VuZ2VyOiBVbml0LCB1bml0czogcmVhZG9ubHkgVW5pdFtdLCBwcmVmZXJyZWQ6IFBvaW50PXt4OjAseTowfSwgb2NjdXBpZWQ9dHJ1ZSwgc3BhY2luZz00KSB7XG4gIGNvbnN0IHByb2ZpbGU9c2hpcFByb2ZpbGUoc2hpcCk7XG4gIGlmKCFwcm9maWxlKXJldHVybiB1bmRlZmluZWQ7XG4gIGlmKGRlY2tQb2ludEZpdHMoc2hpcCxwYXNzZW5nZXIscHJlZmVycmVkLHVuaXRzLG9jY3VwaWVkKSlyZXR1cm4gcHJlZmVycmVkO1xuICBsZXQgYmVzdDpQb2ludHx1bmRlZmluZWQsIHNjb3JlPUluZmluaXR5O1xuICBmb3IobGV0IHk9LXByb2ZpbGUuYmVhbS8yO3k8PXByb2ZpbGUuYmVhbS8yO3krPXNwYWNpbmcpIGZvcihsZXQgeD0tcHJvZmlsZS5sZW5ndGgvMjt4PD1wcm9maWxlLmxlbmd0aC8yO3grPXNwYWNpbmcpIHtcbiAgICBjb25zdCBwb2ludD17eCx5fSwgdmFsdWU9KHgtcHJlZmVycmVkLngpKioyKyh5LXByZWZlcnJlZC55KSoqMjtcbiAgICBpZih2YWx1ZTxzY29yZSAmJiBkZWNrUG9pbnRGaXRzKHNoaXAscGFzc2VuZ2VyLHBvaW50LHVuaXRzLG9jY3VwaWVkKSl7YmVzdD1wb2ludDtzY29yZT12YWx1ZTt9XG4gIH1cbiAgcmV0dXJuIGJlc3Q7XG59XG4vKiogUHJvamVjdCBhIHBvaW50ZXIgb250byB0aGUgdXNhYmxlIGZsb29yLCBpbmNsdWRpbmcgdGhlIHBhc3NlbmdlcidzIGZvb3RwcmludC5cbiAqIERyYWdnaW5nIHBhc3QgYSByYWlsaW5nIHN0YXlzIGF0IHRoZSByYWlsaW5nOyBmaXR0aW5ncyBhbmQgY3JldyBjaG9vc2UgdGhlXG4gKiBjbG9zZXN0IHJlbWFpbmluZyBmcmVlIHBvc2l0aW9uIHJhdGhlciB0aGFuIHJlamVjdGluZyB0aGUgd2hvbGUgZ2VzdHVyZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcm9qZWN0RGVja1BvaW50KHNoaXA6IFVuaXQsIHBhc3NlbmdlcjogVW5pdCwgcHJlZmVycmVkOiBQb2ludCwgdW5pdHM6IHJlYWRvbmx5IFVuaXRbXSkge1xuICBjb25zdCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApO1xuICBpZighcHJvZmlsZSlyZXR1cm4gdW5kZWZpbmVkO1xuICBpZihkZWNrUG9pbnRGaXRzKHNoaXAscGFzc2VuZ2VyLHByZWZlcnJlZCx1bml0cykpcmV0dXJuIHByZWZlcnJlZDtcbiAgaWYoZGlza0luQ29udmV4KHByZWZlcnJlZCxwYXNzZW5nZXIucmFkaXVzKzEscHJvZmlsZS5kZWNrKSlyZXR1cm4gZGVja1BsYWNlbWVudChzaGlwLHBhc3Nlbmdlcix1bml0cyxwcmVmZXJyZWQsdHJ1ZSwyKTtcbiAgY29uc3QgZmxvb3I9ZXhwYW5kQ29udmV4KHByb2ZpbGUuZGVjaywtcGFzc2VuZ2VyLnJhZGl1cy0xLTFlLTYpO1xuICBsZXQgbmVhcmVzdDpQb2ludHx1bmRlZmluZWQsc2NvcmU9SW5maW5pdHk7XG4gIGZvcihsZXQgaT0wO2k8Zmxvb3IubGVuZ3RoO2krKykge1xuICAgIGNvbnN0IGE9Zmxvb3JbaV0hLGI9Zmxvb3JbKGkrMSklZmxvb3IubGVuZ3RoXSEsZHg9Yi54LWEueCxkeT1iLnktYS55O1xuICAgIGNvbnN0IHQ9TWF0aC5tYXgoMCxNYXRoLm1pbigxLCgocHJlZmVycmVkLngtYS54KSpkeCsocHJlZmVycmVkLnktYS55KSpkeSkvKGR4KmR4K2R5KmR5KSkpO1xuICAgIGNvbnN0IHBvaW50PXt4OmEueCtkeCp0LHk6YS55K2R5KnR9LGRpc3RhbmNlPShwb2ludC54LXByZWZlcnJlZC54KSoqMisocG9pbnQueS1wcmVmZXJyZWQueSkqKjI7XG4gICAgaWYoZGlzdGFuY2U8c2NvcmUpe25lYXJlc3Q9cG9pbnQ7c2NvcmU9ZGlzdGFuY2U7fVxuICB9XG4gIGlmKG5lYXJlc3QgJiYgZGVja1BvaW50Rml0cyhzaGlwLHBhc3NlbmdlcixuZWFyZXN0LHVuaXRzKSlyZXR1cm4gbmVhcmVzdDtcbiAgcmV0dXJuIGRlY2tQbGFjZW1lbnQoc2hpcCxwYXNzZW5nZXIsdW5pdHMscHJlZmVycmVkLHRydWUsMik7XG59XG5leHBvcnQgZnVuY3Rpb24gY2FuQm9hcmQoc2hpcDogVW5pdCwgcGFzc2VuZ2VyOiBVbml0LCB1bml0czogcmVhZG9ubHkgVW5pdFtdKSB7XG4gIGNvbnN0IHByb2ZpbGU9c2hpcFByb2ZpbGUoc2hpcCk7XG4gIGlmKCFwcm9maWxlIHx8IHNoaXBQcm9maWxlKHBhc3NlbmdlcikgfHwgaXNJbkNhYmluKHBhc3NlbmdlcikpcmV0dXJuIGZhbHNlO1xuICBpZihwYXNzZW5nZXIuZGVjayl7XG4gICAgY29uc3Qgc291cmNlPXVuaXRzLmZpbmQodW5pdD0+dW5pdC5pZD09PXBhc3Nlbmdlci5kZWNrIS5zaGlwSWQpLHNvdXJjZVByb2ZpbGU9c291cmNlICYmIHNoaXBQcm9maWxlKHNvdXJjZSk7XG4gICAgaWYoIXNvdXJjZVByb2ZpbGUgfHwgc291cmNlIS5pZD09PXNoaXAuaWQgfHwgTWF0aC5hYnMocHJvZmlsZS5kZWNrSGVpZ2h0LXNvdXJjZVByb2ZpbGUuZGVja0hlaWdodCk+cGFzc2VuZ2VyLnJhZGl1cyoyICYmICFnYW5nd2F5QmV0d2Vlbihzb3VyY2UhLHNoaXAscGFzc2VuZ2VyKSlyZXR1cm4gZmFsc2U7XG4gIH0gZWxzZSBpZihzaGlwLm93bmVyIT09cGFzc2VuZ2VyLm93bmVyKXJldHVybiBmYWxzZTtcbiAgcmV0dXJuIGRlY2tMb2FkKHVuaXRzLHNoaXApK2JvZHlNYXNzKHBhc3Nlbmdlcik8PXByb2ZpbGUubG9hZENhcGFjaXR5ICYmICEhZGVja1BsYWNlbWVudChzaGlwLHBhc3Nlbmdlcix1bml0cyk7XG59XG5leHBvcnQgZnVuY3Rpb24gYm9hcmRVbml0KHNoaXA6IFVuaXQsIHBhc3NlbmdlcjogVW5pdCwgdW5pdHM6IHJlYWRvbmx5IFVuaXRbXSkge1xuICBjb25zdCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApO1xuICBpZighcHJvZmlsZSB8fCBwYXNzZW5nZXIuZGVjayB8fCBkZWNrTG9hZCh1bml0cyxzaGlwKStib2R5TWFzcyhwYXNzZW5nZXIpPnByb2ZpbGUubG9hZENhcGFjaXR5KXJldHVybiBmYWxzZTtcbiAgLy8gRW50ZXIgYWxvbmcgdGhlIGFmdCBwb3J0IGVkZ2UsIHByZXNlcnZpbmcgdGhlIG9wZW4gY2VudGVyIGZvciBsYXRlciBwYXNzZW5nZXJzLlxuICBjb25zdCBwb2ludD1kZWNrUGxhY2VtZW50KHNoaXAscGFzc2VuZ2VyLHVuaXRzLHt4Oi1wcm9maWxlLmxlbmd0aC8yLHk6LXByb2ZpbGUuYmVhbS8yfSx0cnVlLDIpO1xuICBpZighcG9pbnQpcmV0dXJuIGZhbHNlO1xuICBwYXNzZW5nZXIuZGVjaz17c2hpcElkOnNoaXAuaWQsLi4ucG9pbnR9O1xuICBwYXNzZW5nZXIuYWltPXVuZGVmaW5lZDtcbiAgT2JqZWN0LmFzc2lnbihwYXNzZW5nZXIsbG9jYWxUb1dvcmxkKHNoaXAscG9pbnQpKTtcbiAgcmV0dXJuIHRydWU7XG59XG5leHBvcnQgZnVuY3Rpb24gc3luY0RlY2tzKHVuaXRzOiByZWFkb25seSBVbml0W10pIHtcbiAgY29uc3QgdmVzc2Vscz1zaGlwc0luKHVuaXRzKTtpZighdmVzc2Vscy5sZW5ndGgpcmV0dXJuO1xuICBjb25zdCBzaGlwcz1uZXcgTWFwKHZlc3NlbHMubWFwKHNoaXA9PltzaGlwLmlkLHNoaXBdKSk7XG4gIGZvcihjb25zdCBzaGlwIG9mIHNoaXBzLnZhbHVlcygpKSB7XG4gICAgY29uc3QgcHJvZmlsZT1zaGlwUHJvZmlsZShzaGlwKSEsIGNyZXc9c2hpcFBhc3NlbmdlcnModW5pdHMsc2hpcCk7XG4gICAgY29uc3QgY2FiaW49cHJvZmlsZS5vYnN0YWNsZXMuZmluZChvYnN0YWNsZT0+b2JzdGFjbGUudHlwZT09PSdjYWJpbicpO1xuICAgIGNvbnN0IGxvYWQ9KHNoaXAuaG9sZE1hc3MgPz8gMCkrY3Jldy5yZWR1Y2UoKHN1bSx1bml0KT0+c3VtK2JvZHlNYXNzKHVuaXQpLDApO1xuICAgIGNvbnN0IG9mZnNldD1sb2FkID8gTWF0aC5oeXBvdChjcmV3LnJlZHVjZSgocyx1KT0+cysoaXNJbkNhYmluKHUpP2NhYmluPy54Pz91LmRlY2shLng6dS5kZWNrIS54KSpib2R5TWFzcyh1KSwwKSxjcmV3LnJlZHVjZSgocyx1KT0+cysoaXNJbkNhYmluKHUpP2NhYmluPy55Pz91LmRlY2shLnk6dS5kZWNrIS55KSpib2R5TWFzcyh1KSwwKSkvbG9hZCA6IDA7XG4gICAgc2hpcC5zYWlsaW5nPz89e2hlYWRpbmc6MCxzcGVlZDowLGxvYWQ6MCxiYWxhbmNlOjB9O1xuICAgIHNoaXAuc2FpbGluZy5sb2FkPWxvYWQ7XG4gICAgc2hpcC5zYWlsaW5nLmJhbGFuY2U9b2Zmc2V0Lyhwcm9maWxlLmxlbmd0aC8yKTtcbiAgfVxuICBmb3IoY29uc3QgdW5pdCBvZiB1bml0cykgaWYodW5pdC5kZWNrKSB7XG4gICAgY29uc3Qgc2hpcD1zaGlwcy5nZXQodW5pdC5kZWNrLnNoaXBJZCk7XG4gICAgY29uc3QgY3Jvc3Npbmc9dW5pdC5nYW5nd2F5JiZnYW5nd2F5Q3Jvc3NpbmdQb3NpdGlvbih1bml0Lmdhbmd3YXksdW5pdHMpO1xuICAgIGlmKHNoaXApIHtcbiAgICAgIGlmKGNyb3NzaW5nKXtPYmplY3QuYXNzaWduKHVuaXQsY3Jvc3NpbmcpO09iamVjdC5hc3NpZ24odW5pdC5kZWNrLHdvcmxkVG9Mb2NhbChzaGlwLGNyb3NzaW5nKSk7fVxuICAgICAgZWxzZSBPYmplY3QuYXNzaWduKHVuaXQsbG9jYWxUb1dvcmxkKHNoaXAsdW5pdC5kZWNrKSk7XG4gICAgfVxuICB9XG59XG4vKiogQSBicm9rZW4gcGFzc2FnZSByZXRyZWF0cyBvbmx5IGl0cyBsaXZlIHdhbGtlcnMgdG8gYSBzdXJ2aXZpbmcgZGVjay4gQVxuICogcGFzc2VuZ2VyIHdob3NlIHBhcmVudCBodWxsIHNhbmsgcmVtYWlucyB1bmRlciBub3JtYWwgc2hpcHdyZWNrIGF1dGhvcml0eS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXR0bGVHYW5nd2F5Q3Jvc3NpbmdzKHVuaXRzOnJlYWRvbmx5IFVuaXRbXSkge1xuICBmb3IoY29uc3QgcGFzc2VuZ2VyIG9mIHVuaXRzKSB7XG4gICAgY29uc3QgY3Jvc3Npbmc9cGFzc2VuZ2VyLmdhbmd3YXk7XG4gICAgaWYoIWNyb3NzaW5nIHx8IHBhc3Nlbmdlci5ocDw9MCB8fCBnYW5nd2F5Q3Jvc3NpbmdQb3NpdGlvbihjcm9zc2luZyx1bml0cykpY29udGludWU7XG4gICAgY29uc3QgcGFyZW50PXVuaXRzLmZpbmQoc2hpcD0+c2hpcC5pZD09PXBhc3Nlbmdlci5kZWNrPy5zaGlwSWQpO1xuICAgIGlmKCFwYXJlbnQgfHwgcGFyZW50LmhwPD0wKWNvbnRpbnVlO1xuICAgIGNvbnN0IGVuZHBvaW50cz1bY3Jvc3Npbmcuc291cmNlSWQsY3Jvc3NpbmcudGFyZ2V0SWRdLm1hcChpZD0+dW5pdHMuZmluZChzaGlwPT5zaGlwLmlkPT09aWQgJiYgc2hpcC5ocD4wKSkuZmlsdGVyKChzaGlwKTpzaGlwIGlzIFVuaXQ9PiEhc2hpcCk7XG4gICAgZW5kcG9pbnRzLnNvcnQoKGEsYik9Pk1hdGguaHlwb3QocGFzc2VuZ2VyLngtYS54LHBhc3Nlbmdlci55LWEueSktTWF0aC5oeXBvdChwYXNzZW5nZXIueC1iLngscGFzc2VuZ2VyLnktYi55KSk7XG4gICAgZm9yKGNvbnN0IHNoaXAgb2YgZW5kcG9pbnRzKSB7XG4gICAgICBpZihzaGlwIT09cGFyZW50ICYmIGRlY2tMb2FkKHVuaXRzLHNoaXApK2JvZHlNYXNzKHBhc3Nlbmdlcik+c2hpcFByb2ZpbGUoc2hpcCkhLmxvYWRDYXBhY2l0eSljb250aW51ZTtcbiAgICAgIGNvbnN0IHBvaW50PWRlY2tQbGFjZW1lbnQoc2hpcCxwYXNzZW5nZXIsdW5pdHMsd29ybGRUb0xvY2FsKHNoaXAscGFzc2VuZ2VyKSk7XG4gICAgICBpZighcG9pbnQpY29udGludWU7XG4gICAgICBwYXNzZW5nZXIuZGVjaz17c2hpcElkOnNoaXAuaWQsLi4ucG9pbnR9O2RlbGV0ZSBwYXNzZW5nZXIuZ2FuZ3dheTtcbiAgICAgIE9iamVjdC5hc3NpZ24ocGFzc2VuZ2VyLGxvY2FsVG9Xb3JsZChzaGlwLHBvaW50KSk7YnJlYWs7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGNsZWFyUGF0aChzaGlwOiBVbml0LCBwYXNzZW5nZXI6IFVuaXQsIGE6UG9pbnQsIGI6UG9pbnQsIHVuaXRzOnJlYWRvbmx5IFVuaXRbXSwgYXZvaWRDcmV3PWZhbHNlKSB7XG4gIGNvbnN0IHByb2ZpbGU9c2hpcFByb2ZpbGUoc2hpcCkhO1xuICByZXR1cm4gZGlza0luQ29udmV4KGEscGFzc2VuZ2VyLnJhZGl1cysxLHByb2ZpbGUuZGVjaykgJiYgZGlza0luQ29udmV4KGIscGFzc2VuZ2VyLnJhZGl1cysxLHByb2ZpbGUuZGVjaylcbiAgICAmJiBjYXBzdWxlQ2xlYXJzQ2lyY2xlcyhhLGIscGFzc2VuZ2VyLnJhZGl1cysxLHByb2ZpbGUub2JzdGFjbGVzKVxuICAgICYmICghYXZvaWRDcmV3IHx8IGNhcHN1bGVDbGVhcnNCb2RpZXMoYSxiLHBhc3Nlbmdlci5yYWRpdXMrMSxzaGlwUGFzc2VuZ2Vycyh1bml0cyxzaGlwKS5maWx0ZXIob3RoZXI9Pm90aGVyLmlkIT09cGFzc2VuZ2VyLmlkJiZvdGhlci5ocD4wJiYhaXNJbkNhYmluKG90aGVyKSkubWFwKG90aGVyPT4oey4uLm90aGVyLmRlY2shLHJhZGl1czpvdGhlci5yYWRpdXN9KSkpKTtcbn1cbi8qKiBTbWFsbCB2aXNpYmlsaXR5IGdyYXBoIGFyb3VuZCBmaXhlZCBkZWNrIGZpdHRpbmdzOyBtb3ZpbmcgY3JldyBhcmUgcGh5c2ljYWwgYm9kaWVzLiAqL1xuZnVuY3Rpb24gZGVja1dheXBvaW50KHNoaXA6VW5pdCxwYXNzZW5nZXI6VW5pdCxnb2FsOlBvaW50LHVuaXRzOnJlYWRvbmx5IFVuaXRbXSxhdm9pZENyZXc9ZmFsc2UpIHtcbiAgY29uc3Qgc3RhcnQ9cGFzc2VuZ2VyLmRlY2shLCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApITtcbiAgaWYoY2xlYXJQYXRoKHNoaXAscGFzc2VuZ2VyLHN0YXJ0LGdvYWwsdW5pdHMsYXZvaWRDcmV3KSlyZXR1cm4gZ29hbDtcbiAgY29uc3Qgbm9kZXM6UG9pbnRbXT1bc3RhcnQsZ29hbF07XG4gIC8vIERlY2sgY29ybmVycyBjb25uZWN0IG5hcnJvdyBwYXNzYWdlcyBiZXR3ZWVuIHRoZSBjYWJpbiBhbmQgdGhlIHJhaWxpbmcuXG4gIC8vIEZpdHRpbmctcmluZyBub2RlcyBhbG9uZSBjYW4gbGVhdmUgdGhlc2Ugcm91dGVzIGRpc2Nvbm5lY3RlZCBvbiBsYXJnZSBodWxscy5cbiAgZm9yKGNvbnN0IHBvaW50IG9mIGV4cGFuZENvbnZleChwcm9maWxlLmRlY2ssLXBhc3Nlbmdlci5yYWRpdXMtMS0xZS00KSlcbiAgICBpZihkZWNrUG9pbnRGaXRzKHNoaXAscGFzc2VuZ2VyLHBvaW50LHVuaXRzLGZhbHNlKSlub2Rlcy5wdXNoKHBvaW50KTtcbiAgY29uc3Qgb2JzdGFjbGVzPVsuLi5wcm9maWxlLm9ic3RhY2xlcywuLi4oYXZvaWRDcmV3P3NoaXBQYXNzZW5nZXJzKHVuaXRzLHNoaXApLmZpbHRlcihvdGhlcj0+b3RoZXIuaWQhPT1wYXNzZW5nZXIuaWQmJm90aGVyLmhwPjAmJiFpc0luQ2FiaW4ob3RoZXIpKS5tYXAob3RoZXI9Pih7Li4ub3RoZXIuZGVjayEscmFkaXVzOm90aGVyLnJhZGl1c30pKTpbXSldO1xuICBmb3IoY29uc3QgbyBvZiBvYnN0YWNsZXMpZm9yKGxldCBpPTA7aTwxMjtpKyspIHtcbiAgICBjb25zdCBhbmdsZT1pKk1hdGguUEkvNixyPShvLnJhZGl1cytwYXNzZW5nZXIucmFkaXVzKzMpL2RldENvcyhNYXRoLlBJLzEyKTtcbiAgICBjb25zdCBwb2ludD17eDpvLngrZGV0Q29zKGFuZ2xlKSpyLHk6by55K2RldFNpbihhbmdsZSkqcn07XG4gICAgaWYoZGVja1BvaW50Rml0cyhzaGlwLHBhc3Nlbmdlcixwb2ludCx1bml0cyxmYWxzZSkpbm9kZXMucHVzaChwb2ludCk7XG4gIH1cbiAgY29uc3QgY29zdD1ub2Rlcy5tYXAoKCk9PkluZmluaXR5KSwgcHJldmlvdXM9bm9kZXMubWFwKCgpPT4tMSksIHNlZW49bmV3IFNldDxudW1iZXI+KCk7Y29zdFswXT0wO1xuICB3aGlsZShzZWVuLnNpemU8bm9kZXMubGVuZ3RoKSB7XG4gICAgbGV0IGN1cnJlbnQ9LTE7XG4gICAgZm9yKGxldCBpPTA7aTxub2Rlcy5sZW5ndGg7aSsrKWlmKCFzZWVuLmhhcyhpKSYmKGN1cnJlbnQ8MHx8Y29zdFtpXSE8Y29zdFtjdXJyZW50XSEpKWN1cnJlbnQ9aTtcbiAgICBpZihjdXJyZW50PDB8fCFOdW1iZXIuaXNGaW5pdGUoY29zdFtjdXJyZW50XSEpKWJyZWFrO1xuICAgIGlmKGN1cnJlbnQ9PT0xKXtsZXQgbmV4dD0xO3doaWxlKHByZXZpb3VzW25leHRdIT4wKW5leHQ9cHJldmlvdXNbbmV4dF0hO3JldHVybiBub2Rlc1tuZXh0XSE7fVxuICAgIHNlZW4uYWRkKGN1cnJlbnQpO1xuICAgIGZvcihsZXQgaT0wO2k8bm9kZXMubGVuZ3RoO2krKykge1xuICAgICAgY29uc3QgY2FuZGlkYXRlPWNvc3RbY3VycmVudF0hK01hdGguaHlwb3Qobm9kZXNbaV0hLngtbm9kZXNbY3VycmVudF0hLngsbm9kZXNbaV0hLnktbm9kZXNbY3VycmVudF0hLnkpO1xuICAgICAgaWYoc2Vlbi5oYXMoaSl8fGNhbmRpZGF0ZT49Y29zdFtpXSF8fCFjbGVhclBhdGgoc2hpcCxwYXNzZW5nZXIsbm9kZXNbY3VycmVudF0hLG5vZGVzW2ldISx1bml0cyxhdm9pZENyZXcpKWNvbnRpbnVlO1xuICAgICAgaWYoY2FuZGlkYXRlPGNvc3RbaV0hKXtjb3N0W2ldPWNhbmRpZGF0ZTtwcmV2aW91c1tpXT1jdXJyZW50O31cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0YXJ0O1xufVxuLyoqIEFkbWlzc2lvbiBjaGVja3MgdXNlIHRoZSBzYW1lIGZpeGVkIGRlY2sgcm91dGVzIGFzIHdhbGtpbmcuIFRlbXBvcmFyeSBjcmV3XG4gKiBjb25nZXN0aW9uIGNhbiB5aWVsZDsgYSByYWlsaW5nIG9yIGZpdHRpbmcgdGhhdCBzZWFscyB0aGUgcm91dGUgY2Fubm90LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY2tTdGF0aWNQYXRoRXhpc3RzKHNoaXA6VW5pdCxwYXNzZW5nZXI6VW5pdCxnb2FsOlBvaW50KSB7XG4gIGNvbnN0IHN0YXJ0PXBhc3Nlbmdlci5kZWNrO1xuICBpZihzdGFydD8uc2hpcElkIT09c2hpcC5pZCB8fCAhZGVja1BvaW50Rml0cyhzaGlwLHBhc3Nlbmdlcixnb2FsLFtdLGZhbHNlKSlyZXR1cm4gZmFsc2U7XG4gIGlmKE1hdGguaHlwb3QoZ29hbC54LXN0YXJ0LngsZ29hbC55LXN0YXJ0LnkpPDFlLTcpcmV0dXJuIHRydWU7XG4gIGNvbnN0IG5leHQ9ZGVja1dheXBvaW50KHNoaXAscGFzc2VuZ2VyLGdvYWwsW10sZmFsc2UpO1xuICByZXR1cm4gTWF0aC5oeXBvdChuZXh0Lngtc3RhcnQueCxuZXh0Lnktc3RhcnQueSk+MWUtNztcbn1cbmV4cG9ydCBmdW5jdGlvbiBtb3ZlT25EZWNrKHBhc3NlbmdlcjpVbml0LHNoaXA6VW5pdCx3b3JsZDpQb2ludCx1bml0czpyZWFkb25seSBVbml0W10scGFjZT0xLGF2b2lkQ3Jldz10cnVlKSB7XG4gIGlmKCFwYXNzZW5nZXIuZGVjaylyZXR1cm47XG4gIGNvbnN0IGdvYWw9ZGVja1BsYWNlbWVudChzaGlwLHBhc3Nlbmdlcix1bml0cyx3b3JsZFRvTG9jYWwoc2hpcCx3b3JsZCksYXZvaWRDcmV3KTtcbiAgaWYoIWdvYWwpcmV0dXJuO1xuICBjb25zdCB0YXJnZXQ9ZGVja1dheXBvaW50KHNoaXAscGFzc2VuZ2VyLGdvYWwsdW5pdHMsYXZvaWRDcmV3KSwgc3RhcnQ9cGFzc2VuZ2VyLmRlY2s7XG4gIGNvbnN0IGdhcD1NYXRoLmh5cG90KHRhcmdldC54LXN0YXJ0LngsdGFyZ2V0Lnktc3RhcnQueSksIHN0ZXA9TWF0aC5taW4oZ2FwLHBlclRpY2socGFzc2VuZ2VyLnNwZWVkKSpwYWNlKTtcbiAgaWYoZ2FwPT09MClyZXR1cm47XG4gIGNvbnN0IG5leHQ9e3g6c3RhcnQueCsodGFyZ2V0Lngtc3RhcnQueCkqc3RlcC9nYXAseTpzdGFydC55Kyh0YXJnZXQueS1zdGFydC55KSpzdGVwL2dhcH07XG4gIGlmKGRlY2tQb2ludEZpdHMoc2hpcCxwYXNzZW5nZXIsbmV4dCx1bml0cykpe09iamVjdC5hc3NpZ24oc3RhcnQsbmV4dCk7T2JqZWN0LmFzc2lnbihwYXNzZW5nZXIsbG9jYWxUb1dvcmxkKHNoaXAsc3RhcnQpKTt9XG59XG4vKiogT2xkIHNuYXBzaG90cyBuZXN0ZWQgcGFzc2VuZ2VyczsgbWlncmF0aW9uIGV4cG9zZXMgZWFjaCBleGFjdGx5IG9uY2Ugd2l0aG91dCBjaGFuZ2luZyBzdXBwbHkuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzdG9yZUNhcmdvRGVja3ModW5pdHM6VW5pdFtdKSB7XG4gIGNvbnN0IGV4aXN0aW5nPW5ldyBTZXQodW5pdHMubWFwKHU9PnUuaWQpKTtcbiAgZm9yKGNvbnN0IHNoaXAgb2YgWy4uLnVuaXRzXSkge1xuICAgIGNvbnN0IGNhcmdvPXNoaXAuY2FyZ287XG4gICAgaWYoIWNhcmdvKWNvbnRpbnVlO1xuICAgIGRlbGV0ZSBzaGlwLmNhcmdvO1xuICAgIGZvcihjb25zdCBwYXNzZW5nZXIgb2YgY2FyZ28pIHtcbiAgICAgIGlmKGV4aXN0aW5nLmhhcyhwYXNzZW5nZXIuaWQpKWNvbnRpbnVlO1xuICAgICAgLy8gU2F2ZWQgdHJhbnNwb3J0cyBjYW4gYmUgb3ZlcmZ1bGwgdW5kZXIgbmV3ZXIgZ2VvbWV0cnkuIEV4cGFuZCB0aGF0IG9sZC1mb3JtYXRcbiAgICAgIC8vIGh1bGwgZGV0ZXJtaW5pc3RpY2FsbHkgdW50aWwgaXRzIGV4aXN0aW5nIGNyZXcgZml0cywgd2l0aG91dCBsb3NpbmcgdW5pdHMuXG4gICAgICBsZXQgcGxhY2VkPWJvYXJkVW5pdChzaGlwLHBhc3Nlbmdlcix1bml0cyk7XG4gICAgICBmb3IobGV0IGF0dGVtcHQ9MDshcGxhY2VkICYmIGF0dGVtcHQ8NDA7YXR0ZW1wdCsrKSB7c2hpcC5kZWNrU2NhbGU9YXV0aG9yZWRTaGlwU2NhbGUoc2hpcCkqMS4xO3BsYWNlZD1ib2FyZFVuaXQoc2hpcCxwYXNzZW5nZXIsdW5pdHMpO31cbiAgICAgIGlmKCFwbGFjZWQpdGhyb3cgbmV3IEVycm9yKGBDYW5ub3QgcmVzdG9yZSBwYXNzZW5nZXIgJHtwYXNzZW5nZXIuaWR9IGFib2FyZCAke3NoaXAuaWR9YCk7XG4gICAgICBwYXNzZW5nZXIub3JkZXI9e3R5cGU6XCJpZGxlXCJ9O3Bhc3Nlbmdlci5vcmRlclF1ZXVlPVtdO1xuICAgICAgdW5pdHMucHVzaChwYXNzZW5nZXIpO2V4aXN0aW5nLmFkZChwYXNzZW5nZXIuaWQpO1xuICAgIH1cbiAgfVxuICBzeW5jRGVja3ModW5pdHMpO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFFBQVEsY0FBYztBQUMvQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLFNBQVMsbUJBQW9DLGNBQWMsZ0JBQWdCLGFBQWEsb0JBQWdDO0FBQ2pJLFNBQVMsZUFBZTtBQUV4QixTQUFTLHFCQUFxQixzQkFBc0IsY0FBYyxvQkFBb0I7QUFDdEYsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxnQkFBZ0IsK0JBQStCO0FBRWpELGdCQUFTLFNBQVMsT0FBd0IsTUFBWTtBQUMzRCxVQUFRLEtBQUssWUFBWSxLQUFHLGVBQWUsT0FBTSxJQUFJLEVBQUUsT0FBTyxDQUFDLEtBQUksU0FBTyxNQUFJLFNBQVMsSUFBSSxHQUFFLENBQUM7QUFDaEc7QUFDTyxnQkFBUyxjQUFjLE1BQVksV0FBaUIsT0FBYyxPQUF3QixXQUFTLE1BQU07QUFDOUcsUUFBTSxVQUFRLFlBQVksSUFBSTtBQUM5QixNQUFHLENBQUMsV0FBVyxDQUFDLGFBQWEsT0FBTSxVQUFVLFNBQU8sR0FBRSxRQUFRLElBQUksRUFBRSxRQUFPO0FBQzNFLE1BQUcsUUFBUSxVQUFVLEtBQUssT0FBRyxLQUFLLE1BQU0sTUFBTSxJQUFFLEVBQUUsR0FBRSxNQUFNLElBQUUsRUFBRSxDQUFDLElBQUUsRUFBRSxTQUFPLFVBQVUsU0FBTyxJQUFFLElBQUksRUFBRSxRQUFPO0FBQzFHLFNBQU8sQ0FBQyxZQUFZLENBQUMsZUFBZSxPQUFNLElBQUksRUFBRSxLQUFLLFdBQU8sTUFBTSxLQUFHLEtBQUssQ0FBQyxVQUFVLEtBQUssS0FBSyxNQUFNLE9BQUssVUFBVSxNQUFNLEtBQUssTUFBTSxNQUFNLElBQUUsTUFBTSxLQUFNLEdBQUUsTUFBTSxJQUFFLE1BQU0sS0FBTSxDQUFDLElBQUUsVUFBVSxTQUFPLE1BQU0sU0FBTyxJQUFFLElBQUk7QUFDeE47QUFFTyxnQkFBUyxjQUFjLE1BQVksV0FBaUIsT0FBd0IsWUFBaUIsRUFBQyxHQUFFLEdBQUUsR0FBRSxFQUFDLEdBQUcsV0FBUyxNQUFNLFVBQVEsR0FBRztBQUN2SSxRQUFNLFVBQVEsWUFBWSxJQUFJO0FBQzlCLE1BQUcsQ0FBQyxRQUFRLFFBQU87QUFDbkIsTUFBRyxjQUFjLE1BQUssV0FBVSxXQUFVLE9BQU0sUUFBUSxFQUFFLFFBQU87QUFDakUsTUFBSSxNQUFzQixRQUFNO0FBQ2hDLFdBQVEsSUFBRSxDQUFDLFFBQVEsT0FBSyxHQUFFLEtBQUcsUUFBUSxPQUFLLEdBQUUsS0FBRyxRQUFTLFVBQVEsSUFBRSxDQUFDLFFBQVEsU0FBTyxHQUFFLEtBQUcsUUFBUSxTQUFPLEdBQUUsS0FBRyxTQUFTO0FBQ2xILFVBQU0sUUFBTSxFQUFDLEdBQUUsRUFBQyxHQUFHLFNBQU8sSUFBRSxVQUFVLE1BQUksS0FBRyxJQUFFLFVBQVUsTUFBSTtBQUM3RCxRQUFHLFFBQU0sU0FBUyxjQUFjLE1BQUssV0FBVSxPQUFNLE9BQU0sUUFBUSxHQUFFO0FBQUMsYUFBSztBQUFNLGNBQU07QUFBQSxJQUFNO0FBQUEsRUFDL0Y7QUFDQSxTQUFPO0FBQ1Q7QUFJTyxnQkFBUyxpQkFBaUIsTUFBWSxXQUFpQixXQUFrQixPQUF3QjtBQUN0RyxRQUFNLFVBQVEsWUFBWSxJQUFJO0FBQzlCLE1BQUcsQ0FBQyxRQUFRLFFBQU87QUFDbkIsTUFBRyxjQUFjLE1BQUssV0FBVSxXQUFVLEtBQUssRUFBRSxRQUFPO0FBQ3hELE1BQUcsYUFBYSxXQUFVLFVBQVUsU0FBTyxHQUFFLFFBQVEsSUFBSSxFQUFFLFFBQU8sY0FBYyxNQUFLLFdBQVUsT0FBTSxXQUFVLE1BQUssQ0FBQztBQUNySCxRQUFNLFFBQU0sYUFBYSxRQUFRLE1BQUssQ0FBQyxVQUFVLFNBQU8sSUFBRSxJQUFJO0FBQzlELE1BQUksU0FBd0IsUUFBTTtBQUNsQyxXQUFRLElBQUUsR0FBRSxJQUFFLE1BQU0sUUFBTyxLQUFLO0FBQzlCLFVBQU0sSUFBRSxNQUFNLENBQUMsR0FBRyxJQUFFLE9BQU8sSUFBRSxLQUFHLE1BQU0sTUFBTSxHQUFHLEtBQUcsRUFBRSxJQUFFLEVBQUUsR0FBRSxLQUFHLEVBQUUsSUFBRSxFQUFFO0FBQ25FLFVBQU0sSUFBRSxLQUFLLElBQUksR0FBRSxLQUFLLElBQUksS0FBSSxVQUFVLElBQUUsRUFBRSxLQUFHLE1BQUksVUFBVSxJQUFFLEVBQUUsS0FBRyxPQUFLLEtBQUcsS0FBRyxLQUFHLEdBQUcsQ0FBQztBQUN4RixVQUFNLFFBQU0sRUFBQyxHQUFFLEVBQUUsSUFBRSxLQUFHLEdBQUUsR0FBRSxFQUFFLElBQUUsS0FBRyxFQUFDLEdBQUUsWUFBVSxNQUFNLElBQUUsVUFBVSxNQUFJLEtBQUcsTUFBTSxJQUFFLFVBQVUsTUFBSTtBQUM3RixRQUFHLFdBQVMsT0FBTTtBQUFDLGdCQUFRO0FBQU0sY0FBTTtBQUFBLElBQVM7QUFBQSxFQUNsRDtBQUNBLE1BQUcsV0FBVyxjQUFjLE1BQUssV0FBVSxTQUFRLEtBQUssRUFBRSxRQUFPO0FBQ2pFLFNBQU8sY0FBYyxNQUFLLFdBQVUsT0FBTSxXQUFVLE1BQUssQ0FBQztBQUM1RDtBQUNPLGdCQUFTLFNBQVMsTUFBWSxXQUFpQixPQUF3QjtBQUM1RSxRQUFNLFVBQVEsWUFBWSxJQUFJO0FBQzlCLE1BQUcsQ0FBQyxXQUFXLFlBQVksU0FBUyxLQUFLLFVBQVUsU0FBUyxFQUFFLFFBQU87QUFDckUsTUFBRyxVQUFVLE1BQUs7QUFDaEIsVUFBTSxTQUFPLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxVQUFVLEtBQU0sTUFBTSxHQUFFLGdCQUFjLFVBQVUsWUFBWSxNQUFNO0FBQzFHLFFBQUcsQ0FBQyxpQkFBaUIsT0FBUSxPQUFLLEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxhQUFXLGNBQWMsVUFBVSxJQUFFLFVBQVUsU0FBTyxLQUFLLENBQUMsZUFBZSxRQUFRLE1BQUssU0FBUyxFQUFFLFFBQU87QUFBQSxFQUMxSyxXQUFVLEtBQUssVUFBUSxVQUFVLE1BQU0sUUFBTztBQUM5QyxTQUFPLFNBQVMsT0FBTSxJQUFJLElBQUUsU0FBUyxTQUFTLEtBQUcsUUFBUSxnQkFBZ0IsQ0FBQyxDQUFDLGNBQWMsTUFBSyxXQUFVLEtBQUs7QUFDL0c7QUFDTyxnQkFBUyxVQUFVLE1BQVksV0FBaUIsT0FBd0I7QUFDN0UsUUFBTSxVQUFRLFlBQVksSUFBSTtBQUM5QixNQUFHLENBQUMsV0FBVyxVQUFVLFFBQVEsU0FBUyxPQUFNLElBQUksSUFBRSxTQUFTLFNBQVMsSUFBRSxRQUFRLGFBQWEsUUFBTztBQUV0RyxRQUFNLFFBQU0sY0FBYyxNQUFLLFdBQVUsT0FBTSxFQUFDLEdBQUUsQ0FBQyxRQUFRLFNBQU8sR0FBRSxHQUFFLENBQUMsUUFBUSxPQUFLLEVBQUMsR0FBRSxNQUFLLENBQUM7QUFDN0YsTUFBRyxDQUFDLE1BQU0sUUFBTztBQUNqQixZQUFVLE9BQUssRUFBQyxRQUFPLEtBQUssSUFBRyxHQUFHLE1BQUs7QUFDdkMsWUFBVSxNQUFJO0FBQ2QsU0FBTyxPQUFPLFdBQVUsYUFBYSxNQUFLLEtBQUssQ0FBQztBQUNoRCxTQUFPO0FBQ1Q7QUFDTyxnQkFBUyxVQUFVLE9BQXdCO0FBQ2hELFFBQU0sVUFBUSxRQUFRLEtBQUs7QUFBRSxNQUFHLENBQUMsUUFBUSxPQUFPO0FBQ2hELFFBQU0sUUFBTSxJQUFJLElBQUksUUFBUSxJQUFJLFVBQU0sQ0FBQyxLQUFLLElBQUcsSUFBSSxDQUFDLENBQUM7QUFDckQsYUFBVSxRQUFRLE1BQU0sT0FBTyxHQUFHO0FBQ2hDLFVBQU0sVUFBUSxZQUFZLElBQUksR0FBSSxPQUFLLGVBQWUsT0FBTSxJQUFJO0FBQ2hFLFVBQU0sUUFBTSxRQUFRLFVBQVUsS0FBSyxjQUFVLFNBQVMsU0FBTyxPQUFPO0FBQ3BFLFVBQU0sUUFBTSxLQUFLLFlBQVksS0FBRyxLQUFLLE9BQU8sQ0FBQyxLQUFJLFNBQU8sTUFBSSxTQUFTLElBQUksR0FBRSxDQUFDO0FBQzVFLFVBQU0sU0FBTyxPQUFPLEtBQUssTUFBTSxLQUFLLE9BQU8sQ0FBQyxHQUFFLE1BQUksS0FBRyxVQUFVLENBQUMsSUFBRSxPQUFPLEtBQUcsRUFBRSxLQUFNLElBQUUsRUFBRSxLQUFNLEtBQUcsU0FBUyxDQUFDLEdBQUUsQ0FBQyxHQUFFLEtBQUssT0FBTyxDQUFDLEdBQUUsTUFBSSxLQUFHLFVBQVUsQ0FBQyxJQUFFLE9BQU8sS0FBRyxFQUFFLEtBQU0sSUFBRSxFQUFFLEtBQU0sS0FBRyxTQUFTLENBQUMsR0FBRSxDQUFDLENBQUMsSUFBRSxPQUFPO0FBQ3pNLFNBQUssWUFBVSxFQUFDLFNBQVEsR0FBRSxPQUFNLEdBQUUsTUFBSyxHQUFFLFNBQVEsRUFBQztBQUNsRCxTQUFLLFFBQVEsT0FBSztBQUNsQixTQUFLLFFBQVEsVUFBUSxVQUFRLFFBQVEsU0FBTztBQUFBLEVBQzlDO0FBQ0EsYUFBVSxRQUFRLE1BQU8sS0FBRyxLQUFLLE1BQU07QUFDckMsVUFBTSxPQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTTtBQUNyQyxVQUFNLFdBQVMsS0FBSyxXQUFTLHdCQUF3QixLQUFLLFNBQVEsS0FBSztBQUN2RSxRQUFHLE1BQU07QUFDUCxVQUFHLFVBQVM7QUFBQyxlQUFPLE9BQU8sTUFBSyxRQUFRO0FBQUUsZUFBTyxPQUFPLEtBQUssTUFBSyxhQUFhLE1BQUssUUFBUSxDQUFDO0FBQUEsTUFBRSxNQUMxRixRQUFPLE9BQU8sTUFBSyxhQUFhLE1BQUssS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFDRjtBQUdPLGdCQUFTLHVCQUF1QixPQUF1QjtBQUM1RCxhQUFVLGFBQWEsT0FBTztBQUM1QixVQUFNLFdBQVMsVUFBVTtBQUN6QixRQUFHLENBQUMsWUFBWSxVQUFVLE1BQUksS0FBSyx3QkFBd0IsVUFBUyxLQUFLLEVBQUU7QUFDM0UsVUFBTSxTQUFPLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxVQUFVLE1BQU0sTUFBTTtBQUM5RCxRQUFHLENBQUMsVUFBVSxPQUFPLE1BQUksRUFBRTtBQUMzQixVQUFNLFlBQVUsQ0FBQyxTQUFTLFVBQVMsU0FBUyxRQUFRLEVBQUUsSUFBSSxRQUFJLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxNQUFNLEtBQUssS0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsU0FBb0IsQ0FBQyxDQUFDLElBQUk7QUFDN0ksY0FBVSxLQUFLLENBQUMsR0FBRSxNQUFJLEtBQUssTUFBTSxVQUFVLElBQUUsRUFBRSxHQUFFLFVBQVUsSUFBRSxFQUFFLENBQUMsSUFBRSxLQUFLLE1BQU0sVUFBVSxJQUFFLEVBQUUsR0FBRSxVQUFVLElBQUUsRUFBRSxDQUFDLENBQUM7QUFDN0csZUFBVSxRQUFRLFdBQVc7QUFDM0IsVUFBRyxTQUFPLFVBQVUsU0FBUyxPQUFNLElBQUksSUFBRSxTQUFTLFNBQVMsSUFBRSxZQUFZLElBQUksRUFBRyxhQUFhO0FBQzdGLFlBQU0sUUFBTSxjQUFjLE1BQUssV0FBVSxPQUFNLGFBQWEsTUFBSyxTQUFTLENBQUM7QUFDM0UsVUFBRyxDQUFDLE1BQU07QUFDVixnQkFBVSxPQUFLLEVBQUMsUUFBTyxLQUFLLElBQUcsR0FBRyxNQUFLO0FBQUUsYUFBTyxVQUFVO0FBQzFELGFBQU8sT0FBTyxXQUFVLGFBQWEsTUFBSyxLQUFLLENBQUM7QUFBRTtBQUFBLElBQ3BEO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxVQUFVLE1BQVksV0FBaUIsR0FBUyxHQUFTLE9BQXVCLFlBQVUsT0FBTztBQUN4RyxRQUFNLFVBQVEsWUFBWSxJQUFJO0FBQzlCLFNBQU8sYUFBYSxHQUFFLFVBQVUsU0FBTyxHQUFFLFFBQVEsSUFBSSxLQUFLLGFBQWEsR0FBRSxVQUFVLFNBQU8sR0FBRSxRQUFRLElBQUksS0FDbkcscUJBQXFCLEdBQUUsR0FBRSxVQUFVLFNBQU8sR0FBRSxRQUFRLFNBQVMsTUFDNUQsQ0FBQyxhQUFhLG9CQUFvQixHQUFFLEdBQUUsVUFBVSxTQUFPLEdBQUUsZUFBZSxPQUFNLElBQUksRUFBRSxPQUFPLFdBQU8sTUFBTSxPQUFLLFVBQVUsTUFBSSxNQUFNLEtBQUcsS0FBRyxDQUFDLFVBQVUsS0FBSyxDQUFDLEVBQUUsSUFBSSxZQUFRLEVBQUMsR0FBRyxNQUFNLE1BQU0sUUFBTyxNQUFNLE9BQU0sRUFBRSxDQUFDO0FBQ3BOO0FBRUEsU0FBUyxhQUFhLE1BQVUsV0FBZSxNQUFXLE9BQXNCLFlBQVUsT0FBTztBQUMvRixRQUFNLFFBQU0sVUFBVSxNQUFPLFVBQVEsWUFBWSxJQUFJO0FBQ3JELE1BQUcsVUFBVSxNQUFLLFdBQVUsT0FBTSxNQUFLLE9BQU0sU0FBUyxFQUFFLFFBQU87QUFDL0QsUUFBTSxRQUFjLENBQUMsT0FBTSxJQUFJO0FBRy9CLGFBQVUsU0FBUyxhQUFhLFFBQVEsTUFBSyxDQUFDLFVBQVUsU0FBTyxJQUFFLElBQUk7QUFDbkUsUUFBRyxjQUFjLE1BQUssV0FBVSxPQUFNLE9BQU0sS0FBSyxFQUFFLE9BQU0sS0FBSyxLQUFLO0FBQ3JFLFFBQU0sWUFBVSxDQUFDLEdBQUcsUUFBUSxXQUFVLEdBQUksWUFBVSxlQUFlLE9BQU0sSUFBSSxFQUFFLE9BQU8sV0FBTyxNQUFNLE9BQUssVUFBVSxNQUFJLE1BQU0sS0FBRyxLQUFHLENBQUMsVUFBVSxLQUFLLENBQUMsRUFBRSxJQUFJLFlBQVEsRUFBQyxHQUFHLE1BQU0sTUFBTSxRQUFPLE1BQU0sT0FBTSxFQUFFLElBQUUsQ0FBQyxDQUFFO0FBQzNNLGFBQVUsS0FBSyxVQUFVLFVBQVEsSUFBRSxHQUFFLElBQUUsSUFBRyxLQUFLO0FBQzdDLFVBQU0sUUFBTSxJQUFFLEtBQUssS0FBRyxHQUFFLEtBQUcsRUFBRSxTQUFPLFVBQVUsU0FBTyxLQUFHLE9BQU8sS0FBSyxLQUFHLEVBQUU7QUFDekUsVUFBTSxRQUFNLEVBQUMsR0FBRSxFQUFFLElBQUUsT0FBTyxLQUFLLElBQUUsR0FBRSxHQUFFLEVBQUUsSUFBRSxPQUFPLEtBQUssSUFBRSxFQUFDO0FBQ3hELFFBQUcsY0FBYyxNQUFLLFdBQVUsT0FBTSxPQUFNLEtBQUssRUFBRSxPQUFNLEtBQUssS0FBSztBQUFBLEVBQ3JFO0FBQ0EsUUFBTSxPQUFLLE1BQU0sSUFBSSxNQUFJLFFBQVEsR0FBRyxXQUFTLE1BQU0sSUFBSSxNQUFJLEVBQUUsR0FBRyxPQUFLLG9CQUFJLElBQVk7QUFBRSxPQUFLLENBQUMsSUFBRTtBQUMvRixTQUFNLEtBQUssT0FBSyxNQUFNLFFBQVE7QUFDNUIsUUFBSSxVQUFRO0FBQ1osYUFBUSxJQUFFLEdBQUUsSUFBRSxNQUFNLFFBQU8sSUFBSSxLQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsTUFBSSxVQUFRLEtBQUcsS0FBSyxDQUFDLElBQUcsS0FBSyxPQUFPLEdBQUksV0FBUTtBQUM3RixRQUFHLFVBQVEsS0FBRyxDQUFDLE9BQU8sU0FBUyxLQUFLLE9BQU8sQ0FBRSxFQUFFO0FBQy9DLFFBQUcsWUFBVSxHQUFFO0FBQUMsVUFBSSxPQUFLO0FBQUUsYUFBTSxTQUFTLElBQUksSUFBRyxFQUFFLFFBQUssU0FBUyxJQUFJO0FBQUcsYUFBTyxNQUFNLElBQUk7QUFBQSxJQUFHO0FBQzVGLFNBQUssSUFBSSxPQUFPO0FBQ2hCLGFBQVEsSUFBRSxHQUFFLElBQUUsTUFBTSxRQUFPLEtBQUs7QUFDOUIsWUFBTSxZQUFVLEtBQUssT0FBTyxJQUFHLEtBQUssTUFBTSxNQUFNLENBQUMsRUFBRyxJQUFFLE1BQU0sT0FBTyxFQUFHLEdBQUUsTUFBTSxDQUFDLEVBQUcsSUFBRSxNQUFNLE9BQU8sRUFBRyxDQUFDO0FBQ3JHLFVBQUcsS0FBSyxJQUFJLENBQUMsS0FBRyxhQUFXLEtBQUssQ0FBQyxLQUFJLENBQUMsVUFBVSxNQUFLLFdBQVUsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsT0FBTSxTQUFTLEVBQUU7QUFDMUcsVUFBRyxZQUFVLEtBQUssQ0FBQyxHQUFHO0FBQUMsYUFBSyxDQUFDLElBQUU7QUFBVSxpQkFBUyxDQUFDLElBQUU7QUFBQSxNQUFRO0FBQUEsSUFDL0Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBR08sZ0JBQVMscUJBQXFCLE1BQVUsV0FBZSxNQUFZO0FBQ3hFLFFBQU0sUUFBTSxVQUFVO0FBQ3RCLE1BQUcsT0FBTyxXQUFTLEtBQUssTUFBTSxDQUFDLGNBQWMsTUFBSyxXQUFVLE1BQUssQ0FBQyxHQUFFLEtBQUssRUFBRSxRQUFPO0FBQ2xGLE1BQUcsS0FBSyxNQUFNLEtBQUssSUFBRSxNQUFNLEdBQUUsS0FBSyxJQUFFLE1BQU0sQ0FBQyxJQUFFLEtBQUssUUFBTztBQUN6RCxRQUFNLE9BQUssYUFBYSxNQUFLLFdBQVUsTUFBSyxDQUFDLEdBQUUsS0FBSztBQUNwRCxTQUFPLEtBQUssTUFBTSxLQUFLLElBQUUsTUFBTSxHQUFFLEtBQUssSUFBRSxNQUFNLENBQUMsSUFBRTtBQUNuRDtBQUNPLGdCQUFTLFdBQVcsV0FBZSxNQUFVLE9BQVksT0FBc0IsT0FBSyxHQUFFLFlBQVUsTUFBTTtBQUMzRyxNQUFHLENBQUMsVUFBVSxLQUFLO0FBQ25CLFFBQU0sT0FBSyxjQUFjLE1BQUssV0FBVSxPQUFNLGFBQWEsTUFBSyxLQUFLLEdBQUUsU0FBUztBQUNoRixNQUFHLENBQUMsS0FBSztBQUNULFFBQU0sU0FBTyxhQUFhLE1BQUssV0FBVSxNQUFLLE9BQU0sU0FBUyxHQUFHLFFBQU0sVUFBVTtBQUNoRixRQUFNLE1BQUksS0FBSyxNQUFNLE9BQU8sSUFBRSxNQUFNLEdBQUUsT0FBTyxJQUFFLE1BQU0sQ0FBQyxHQUFHLE9BQUssS0FBSyxJQUFJLEtBQUksUUFBUSxVQUFVLEtBQUssSUFBRSxJQUFJO0FBQ3hHLE1BQUcsUUFBTSxFQUFFO0FBQ1gsUUFBTSxPQUFLLEVBQUMsR0FBRSxNQUFNLEtBQUcsT0FBTyxJQUFFLE1BQU0sS0FBRyxPQUFLLEtBQUksR0FBRSxNQUFNLEtBQUcsT0FBTyxJQUFFLE1BQU0sS0FBRyxPQUFLLElBQUc7QUFDdkYsTUFBRyxjQUFjLE1BQUssV0FBVSxNQUFLLEtBQUssR0FBRTtBQUFDLFdBQU8sT0FBTyxPQUFNLElBQUk7QUFBRSxXQUFPLE9BQU8sV0FBVSxhQUFhLE1BQUssS0FBSyxDQUFDO0FBQUEsRUFBRTtBQUMzSDtBQUVPLGdCQUFTLGtCQUFrQixPQUFjO0FBQzlDLFFBQU0sV0FBUyxJQUFJLElBQUksTUFBTSxJQUFJLE9BQUcsRUFBRSxFQUFFLENBQUM7QUFDekMsYUFBVSxRQUFRLENBQUMsR0FBRyxLQUFLLEdBQUc7QUFDNUIsVUFBTSxRQUFNLEtBQUs7QUFDakIsUUFBRyxDQUFDLE1BQU07QUFDVixXQUFPLEtBQUs7QUFDWixlQUFVLGFBQWEsT0FBTztBQUM1QixVQUFHLFNBQVMsSUFBSSxVQUFVLEVBQUUsRUFBRTtBQUc5QixVQUFJLFNBQU8sVUFBVSxNQUFLLFdBQVUsS0FBSztBQUN6QyxlQUFRLFVBQVEsR0FBRSxDQUFDLFVBQVUsVUFBUSxJQUFHLFdBQVc7QUFBQyxhQUFLLFlBQVUsa0JBQWtCLElBQUksSUFBRTtBQUFJLGlCQUFPLFVBQVUsTUFBSyxXQUFVLEtBQUs7QUFBQSxNQUFFO0FBQ3RJLFVBQUcsQ0FBQyxPQUFPLE9BQU0sSUFBSSxNQUFNLDRCQUE0QixVQUFVLEVBQUUsV0FBVyxLQUFLLEVBQUUsRUFBRTtBQUN2RixnQkFBVSxRQUFNLEVBQUMsTUFBSyxPQUFNO0FBQUUsZ0JBQVUsYUFBVyxDQUFDO0FBQ3BELFlBQU0sS0FBSyxTQUFTO0FBQUUsZUFBUyxJQUFJLFVBQVUsRUFBRTtBQUFBLElBQ2pEO0FBQUEsRUFDRjtBQUNBLFlBQVUsS0FBSztBQUNqQjsiLCJuYW1lcyI6W119