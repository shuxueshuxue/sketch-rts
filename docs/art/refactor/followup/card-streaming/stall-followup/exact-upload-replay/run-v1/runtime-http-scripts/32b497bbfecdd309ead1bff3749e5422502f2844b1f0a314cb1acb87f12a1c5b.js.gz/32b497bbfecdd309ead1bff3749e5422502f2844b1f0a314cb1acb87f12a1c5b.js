import * as THREE from "/.vite-cache/deps/three.js?v=a6750e53";
class MorphInstancedMesh extends THREE.InstancedMesh {
  pose;
  baseBounds;
  deltas;
  localMatrix = new THREE.Matrix4();
  localBox = new THREE.Box3();
  sphere = new THREE.Sphere();
  hits = [];
  constructor(part, capacity) {
    super(part.geometry, part.material, capacity);
    const source = part.geometry, geometry = new THREE.BufferGeometry();
    geometry.index = source.index;
    geometry.attributes = source.attributes;
    geometry.morphAttributes = source.morphAttributes;
    geometry.morphTargetsRelative = source.morphTargetsRelative;
    geometry.groups = source.groups;
    geometry.drawRange = source.drawRange;
    geometry.boundingBox = new THREE.Box3();
    geometry.boundingSphere = new THREE.Sphere();
    this.pose = new THREE.Mesh(geometry, part.material);
    const vertex = new THREE.Vector3(), base = new THREE.Vector3(), position = source.getAttribute("position");
    this.baseBounds = new THREE.Box3();
    for (let i = 0; i < position.count; i++) this.baseBounds.expandByPoint(vertex.fromBufferAttribute(position, i));
    this.deltas = (source.morphAttributes.position ?? []).map((attribute) => {
      const bounds = new THREE.Box3();
      for (let i = 0; i < attribute.count; i++) {
        vertex.fromBufferAttribute(attribute, i);
        if (!source.morphTargetsRelative) vertex.sub(base.fromBufferAttribute(position, i));
        bounds.expandByPoint(vertex);
      }
      return bounds;
    });
    this.setPoseAt(0, part.morph);
  }
  setPoseAt(index, weights) {
    const influences = this.pose.morphTargetInfluences;
    for (let i = 0; i < influences.length; i++) influences[i] = weights[i] ?? 0;
    this.setMorphAt(index, this.pose);
  }
  updatePoseBounds() {
    const bounds = this.pose.geometry.boundingBox.copy(this.baseBounds), weights = this.pose.morphTargetInfluences;
    for (let i = 0; i < this.deltas.length; i++) {
      const weight = weights[i] ?? 0, delta = this.deltas[i];
      if (weight === 0) continue;
      bounds.min.addScaledVector(weight > 0 ? delta.min : delta.max, weight);
      bounds.max.addScaledVector(weight > 0 ? delta.max : delta.min, weight);
    }
    bounds.getBoundingSphere(this.pose.geometry.boundingSphere);
  }
  computeBoundingBox() {
    this.computeBoundingSphere();
  }
  computeBoundingSphere() {
    this.boundingSphere ??= new THREE.Sphere();
    this.boundingSphere.makeEmpty();
    this.boundingBox ??= new THREE.Box3();
    this.boundingBox.makeEmpty();
    for (let i = 0; i < this.count; i++) {
      this.getMorphAt(i, this.pose);
      this.updatePoseBounds();
      this.getMatrixAt(i, this.localMatrix);
      this.sphere.copy(this.pose.geometry.boundingSphere).applyMatrix4(this.localMatrix);
      this.boundingSphere.union(this.sphere);
      this.localBox.copy(this.pose.geometry.boundingBox).applyMatrix4(this.localMatrix);
      this.boundingBox.union(this.localBox);
    }
  }
  raycast(raycaster, intersects) {
    if (!this.count) return;
    if (this.boundingSphere === null) this.computeBoundingSphere();
    this.sphere.copy(this.boundingSphere).applyMatrix4(this.matrixWorld);
    if (!raycaster.ray.intersectsSphere(this.sphere)) return;
    this.pose.material = this.material;
    for (let i = 0; i < this.count; i++) {
      this.getMatrixAt(i, this.localMatrix);
      this.pose.matrixWorld.multiplyMatrices(this.matrixWorld, this.localMatrix);
      this.getMorphAt(i, this.pose);
      this.updatePoseBounds();
      this.pose.raycast(raycaster, this.hits);
      for (const hit of this.hits) {
        hit.instanceId = i;
        hit.object = this;
        intersects.push(hit);
      }
      this.hits.length = 0;
    }
  }
}
export class ActorBatches {
  constructor(scene) {
    this.scene = scene;
  }
  batches = /* @__PURE__ */ new Map();
  geometries = /* @__PURE__ */ new Map();
  textures = /* @__PURE__ */ new Map();
  frame = 0;
  matrix = new THREE.Matrix4();
  begin() {
    this.frame++;
    for (const batch of this.batches.values()) {
      batch.matrices.length = 0;
      batch.animations.length = 0;
      batch.ids.length = 0;
    }
  }
  geometry(source, held) {
    let resource = this.geometries.get(source);
    if (!resource) {
      const view = new THREE.BufferGeometry();
      view.name = source.name;
      view.index = source.index;
      view.attributes = source.attributes;
      view.morphAttributes = source.morphAttributes;
      view.morphTargetsRelative = source.morphTargetsRelative;
      view.groups = source.groups.map((group) => ({ ...group }));
      view.drawRange = { ...source.drawRange };
      view.boundingBox = source.boundingBox?.clone() ?? null;
      view.boundingSphere = source.boundingSphere?.clone() ?? null;
      resource = { view, refs: 0 };
      this.geometries.set(source, resource);
    }
    if (!held.has(source)) {
      held.add(source);
      resource.refs++;
    }
    return resource.view;
  }
  texture(source, held) {
    let resource = this.textures.get(source);
    if (!resource) {
      const clean = Object.create(source);
      clean.userData = {};
      const view = new source.constructor().copy(clean);
      view.userData = source.userData;
      resource = { view, refs: 0 };
      this.textures.set(source, resource);
    }
    if (!held.has(source)) {
      held.add(source);
      resource.refs++;
    }
    return resource.view;
  }
  material(source, held) {
    const material = source.clone();
    for (const [key, value] of Object.entries(source)) if (value instanceof THREE.Texture) material[key] = this.texture(value, held);
    if (source instanceof THREE.ShaderMaterial && material instanceof THREE.ShaderMaterial) for (const [key, uniform] of Object.entries(source.uniforms)) {
      const value = uniform.value;
      if (value instanceof THREE.Texture) material.uniforms[key].value = this.texture(value, held);
      else if (Array.isArray(value)) material.uniforms[key].value = value.map((item) => item instanceof THREE.Texture ? this.texture(item, held) : item);
    }
    return material;
  }
  add(key, template, matrix, id, color, constructing = false, revealDeck = false, animation) {
    let batch = this.batches.get(key);
    if (!batch) {
      const parts = [], geometries = /* @__PURE__ */ new Set(), textures = /* @__PURE__ */ new Set();
      template.updateMatrixWorld(true);
      template.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        const map = (source) => {
          const material = this.material(source, textures);
          if (source.name === "TeamColor" && "color" in material) material.color.set(color ?? "#88977c");
          if (constructing) {
            material.transparent = true;
            material.opacity = 0.48;
          }
          if (revealDeck && source.name.startsWith("unbleached sail")) {
            material.transparent = true;
            material.opacity = 0.22;
            material.depthWrite = false;
          }
          return material;
        };
        const geometry = this.geometry(object.geometry, geometries), morphCount = Object.values(geometry.morphAttributes)[0]?.length ?? 0;
        parts.push({ name: object.name, geometry, material: Array.isArray(object.material) ? object.material.map(map) : map(object.material), local: object.matrixWorld.clone(), morph: Array.from({ length: morphCount }, (_, i) => object.morphTargetInfluences?.[i] ?? 0) });
      });
      batch = { parts, meshes: [], matrices: [], animations: [], ids: [], capacity: 0, last: this.frame, geometries, textures };
      this.batches.set(key, batch);
    }
    batch.matrices.push(matrix);
    batch.animations.push(animation);
    batch.ids.push(id);
    batch.last = this.frame;
  }
  finish() {
    for (const [key, batch] of this.batches) {
      if (!batch.matrices.length) {
        for (const mesh of batch.meshes) {
          mesh.count = 0;
          mesh.visible = false;
        }
        if (this.frame - batch.last > 120) this.remove(key, batch);
        continue;
      }
      if (batch.matrices.length > batch.capacity) {
        for (const mesh of batch.meshes) {
          this.scene.remove(mesh);
          mesh.dispose();
        }
        batch.capacity = 2 ** Math.ceil(Math.log2(Math.max(1, batch.matrices.length)));
        batch.meshes = batch.parts.map((part) => {
          const mesh = part.morph.length ? new MorphInstancedMesh(part, batch.capacity) : new THREE.InstancedMesh(part.geometry, part.material, batch.capacity);
          mesh.name = part.name;
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
          mesh.userData.ids = batch.ids;
          this.scene.add(mesh);
          return mesh;
        });
      }
      for (let p = 0; p < batch.meshes.length; p++) {
        const mesh = batch.meshes[p], part = batch.parts[p];
        mesh.count = batch.matrices.length;
        mesh.visible = mesh.count > 0;
        mesh.userData.ids = batch.ids;
        for (let i = 0; i < mesh.count; i++) {
          const animation = batch.animations[i]?.get(part.name);
          mesh.setMatrixAt(i, this.matrix.copy(batch.matrices[i]).multiply(animation?.matrix ?? part.local));
          if (mesh instanceof MorphInstancedMesh) mesh.setPoseAt(i, animation?.morph ?? part.morph);
        }
        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.morphTexture) mesh.morphTexture.needsUpdate = true;
        if (mesh.count) mesh.computeBoundingSphere();
      }
    }
  }
  objects() {
    return [...this.batches.values()].flatMap((batch) => batch.meshes).filter((mesh) => mesh.visible);
  }
  forget(key) {
    const batch = this.batches.get(key);
    if (batch) this.remove(key, batch);
  }
  remove(key, batch) {
    for (const mesh of batch.meshes) {
      this.scene.remove(mesh);
      mesh.dispose();
    }
    for (const part of batch.parts) for (const mat of Array.isArray(part.material) ? part.material : [part.material]) mat.dispose();
    for (const source of batch.geometries) {
      const resource = this.geometries.get(source);
      if (--resource.refs === 0) {
        resource.view.dispose();
        this.geometries.delete(source);
      }
    }
    for (const source of batch.textures) {
      const resource = this.textures.get(source);
      if (--resource.refs === 0) {
        resource.view.dispose();
        this.textures.delete(source);
      }
    }
    this.batches.delete(key);
  }
  dispose() {
    for (const [key, batch] of this.batches) this.remove(key, batch);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhdGNoZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuZXhwb3J0IHR5cGUgQmF0Y2hBbmltYXRpb249UmVhZG9ubHlNYXA8c3RyaW5nLHttYXRyaXg/OlRIUkVFLk1hdHJpeDQ7bW9ycGg/OnJlYWRvbmx5IG51bWJlcltdfT47XG50eXBlIFBhcnQ9e25hbWU6c3RyaW5nO2dlb21ldHJ5OlRIUkVFLkJ1ZmZlckdlb21ldHJ5O21hdGVyaWFsOlRIUkVFLk1hdGVyaWFsfFRIUkVFLk1hdGVyaWFsW107bG9jYWw6VEhSRUUuTWF0cml4NDttb3JwaDpyZWFkb25seSBudW1iZXJbXX07XG50eXBlIEJhdGNoPXtwYXJ0czpQYXJ0W107bWVzaGVzOlRIUkVFLkluc3RhbmNlZE1lc2hbXTttYXRyaWNlczpUSFJFRS5NYXRyaXg0W107YW5pbWF0aW9uczooQmF0Y2hBbmltYXRpb258dW5kZWZpbmVkKVtdO2lkczpzdHJpbmdbXTtjYXBhY2l0eTpudW1iZXI7bGFzdDpudW1iZXI7Z2VvbWV0cmllczpTZXQ8VEhSRUUuQnVmZmVyR2VvbWV0cnk+O3RleHR1cmVzOlNldDxUSFJFRS5UZXh0dXJlPn07XG5cbi8qKiBUaHJlZSdzIGRlZmF1bHQgaW5zdGFuY2VkIHJheWNhc3QgZG9lcyBub3QgcmVhZCB0aGUgcGVyLWluc3RhbmNlIG1vcnBoIHRleHR1cmUuXG4gKiBUaGlzIHNjcmF0Y2ggbWVzaCBzaGFyZXMgdGhlIG1vZGVsJ3MgYnVmZmVycywgYnV0IG93bnMgaXRzIGFuaW1hdGVkIGJvdW5kcy4gKi9cbmNsYXNzIE1vcnBoSW5zdGFuY2VkTWVzaCBleHRlbmRzIFRIUkVFLkluc3RhbmNlZE1lc2gge1xuICBwcml2YXRlIHBvc2U6VEhSRUUuTWVzaDtcbiAgcHJpdmF0ZSBiYXNlQm91bmRzOlRIUkVFLkJveDM7XG4gIHByaXZhdGUgZGVsdGFzOlRIUkVFLkJveDNbXTtcbiAgcHJpdmF0ZSBsb2NhbE1hdHJpeD1uZXcgVEhSRUUuTWF0cml4NCgpO1xuICBwcml2YXRlIGxvY2FsQm94PW5ldyBUSFJFRS5Cb3gzKCk7XG4gIHByaXZhdGUgc3BoZXJlPW5ldyBUSFJFRS5TcGhlcmUoKTtcbiAgcHJpdmF0ZSBoaXRzOlRIUkVFLkludGVyc2VjdGlvbltdPVtdO1xuICBjb25zdHJ1Y3RvcihwYXJ0OlBhcnQsY2FwYWNpdHk6bnVtYmVyKXtcbiAgICBzdXBlcihwYXJ0Lmdlb21ldHJ5LHBhcnQubWF0ZXJpYWwsY2FwYWNpdHkpO1xuICAgIGNvbnN0IHNvdXJjZT1wYXJ0Lmdlb21ldHJ5LGdlb21ldHJ5PW5ldyBUSFJFRS5CdWZmZXJHZW9tZXRyeSgpO1xuICAgIC8vIFRoaXMgdmlldyBuZXZlciBnb2VzIHRvIHRoZSByZW5kZXJlciBvciBkaXNwb3NlcyB0aGUgc2hhcmVkIGF0dHJpYnV0ZXMuXG4gICAgZ2VvbWV0cnkuaW5kZXg9c291cmNlLmluZGV4O2dlb21ldHJ5LmF0dHJpYnV0ZXM9c291cmNlLmF0dHJpYnV0ZXM7Z2VvbWV0cnkubW9ycGhBdHRyaWJ1dGVzPXNvdXJjZS5tb3JwaEF0dHJpYnV0ZXM7XG4gICAgZ2VvbWV0cnkubW9ycGhUYXJnZXRzUmVsYXRpdmU9c291cmNlLm1vcnBoVGFyZ2V0c1JlbGF0aXZlO2dlb21ldHJ5Lmdyb3Vwcz1zb3VyY2UuZ3JvdXBzO2dlb21ldHJ5LmRyYXdSYW5nZT1zb3VyY2UuZHJhd1JhbmdlO1xuICAgIGdlb21ldHJ5LmJvdW5kaW5nQm94PW5ldyBUSFJFRS5Cb3gzKCk7Z2VvbWV0cnkuYm91bmRpbmdTcGhlcmU9bmV3IFRIUkVFLlNwaGVyZSgpO1xuICAgIHRoaXMucG9zZT1uZXcgVEhSRUUuTWVzaChnZW9tZXRyeSxwYXJ0Lm1hdGVyaWFsKTtcbiAgICBjb25zdCB2ZXJ0ZXg9bmV3IFRIUkVFLlZlY3RvcjMoKSxiYXNlPW5ldyBUSFJFRS5WZWN0b3IzKCkscG9zaXRpb249c291cmNlLmdldEF0dHJpYnV0ZSgncG9zaXRpb24nKTtcbiAgICB0aGlzLmJhc2VCb3VuZHM9bmV3IFRIUkVFLkJveDMoKTtcbiAgICBmb3IobGV0IGk9MDtpPHBvc2l0aW9uLmNvdW50O2krKyl0aGlzLmJhc2VCb3VuZHMuZXhwYW5kQnlQb2ludCh2ZXJ0ZXguZnJvbUJ1ZmZlckF0dHJpYnV0ZShwb3NpdGlvbixpKSk7XG4gICAgdGhpcy5kZWx0YXM9KHNvdXJjZS5tb3JwaEF0dHJpYnV0ZXMucG9zaXRpb24/P1tdKS5tYXAoYXR0cmlidXRlPT57XG4gICAgICBjb25zdCBib3VuZHM9bmV3IFRIUkVFLkJveDMoKTtcbiAgICAgIGZvcihsZXQgaT0wO2k8YXR0cmlidXRlLmNvdW50O2krKyl7XG4gICAgICAgIHZlcnRleC5mcm9tQnVmZmVyQXR0cmlidXRlKGF0dHJpYnV0ZSxpKTtcbiAgICAgICAgaWYoIXNvdXJjZS5tb3JwaFRhcmdldHNSZWxhdGl2ZSl2ZXJ0ZXguc3ViKGJhc2UuZnJvbUJ1ZmZlckF0dHJpYnV0ZShwb3NpdGlvbixpKSk7XG4gICAgICAgIGJvdW5kcy5leHBhbmRCeVBvaW50KHZlcnRleCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYm91bmRzO1xuICAgIH0pO1xuICAgIC8vIHNldE1vcnBoQXQgYWxsb2NhdGVzIGl0cyB0ZXh0dXJlIHVzaW5nIGNvdW50LCBzbyBhbGxvY2F0ZSBiZWZvcmUgZmluaXNoKClcbiAgICAvLyByZWR1Y2VzIHRoZSB2aXNpYmxlIGNvdW50IGJlbG93IGNhcGFjaXR5IChsYXRlciBmcmFtZXMgY2FuIGdyb3cgYWdhaW4pLlxuICAgIHRoaXMuc2V0UG9zZUF0KDAscGFydC5tb3JwaCk7XG4gIH1cbiAgc2V0UG9zZUF0KGluZGV4Om51bWJlcix3ZWlnaHRzOnJlYWRvbmx5IG51bWJlcltdKXtcbiAgICBjb25zdCBpbmZsdWVuY2VzPXRoaXMucG9zZS5tb3JwaFRhcmdldEluZmx1ZW5jZXMhO1xuICAgIGZvcihsZXQgaT0wO2k8aW5mbHVlbmNlcy5sZW5ndGg7aSsrKWluZmx1ZW5jZXNbaV09d2VpZ2h0c1tpXT8/MDtcbiAgICB0aGlzLnNldE1vcnBoQXQoaW5kZXgsdGhpcy5wb3NlKTtcbiAgfVxuICBwcml2YXRlIHVwZGF0ZVBvc2VCb3VuZHMoKXtcbiAgICBjb25zdCBib3VuZHM9dGhpcy5wb3NlLmdlb21ldHJ5LmJvdW5kaW5nQm94IS5jb3B5KHRoaXMuYmFzZUJvdW5kcyksd2VpZ2h0cz10aGlzLnBvc2UubW9ycGhUYXJnZXRJbmZsdWVuY2VzITtcbiAgICAvLyBXZWlnaHRlZCBkZWx0YSBpbnRlcnZhbHMgYWxzbyBjb3ZlciBjb21iaW5lZCwgbmVnYXRpdmUgYW5kID4xIG1vcnBocztcbiAgICAvLyB0aGUgc291cmNlIGdlb21ldHJ5J3MgYm91bmRzIG1heSBjb3ZlciBvbmx5IHRoZSB1bmRlZm9ybWVkIHBvc2l0aW9ucy5cbiAgICBmb3IobGV0IGk9MDtpPHRoaXMuZGVsdGFzLmxlbmd0aDtpKyspe1xuICAgICAgY29uc3Qgd2VpZ2h0PXdlaWdodHNbaV0/PzAsZGVsdGE9dGhpcy5kZWx0YXNbaV0hO1xuICAgICAgaWYod2VpZ2h0PT09MCljb250aW51ZTtcbiAgICAgIGJvdW5kcy5taW4uYWRkU2NhbGVkVmVjdG9yKHdlaWdodD4wP2RlbHRhLm1pbjpkZWx0YS5tYXgsd2VpZ2h0KTtcbiAgICAgIGJvdW5kcy5tYXguYWRkU2NhbGVkVmVjdG9yKHdlaWdodD4wP2RlbHRhLm1heDpkZWx0YS5taW4sd2VpZ2h0KTtcbiAgICB9XG4gICAgYm91bmRzLmdldEJvdW5kaW5nU3BoZXJlKHRoaXMucG9zZS5nZW9tZXRyeS5ib3VuZGluZ1NwaGVyZSEpO1xuICB9XG4gIG92ZXJyaWRlIGNvbXB1dGVCb3VuZGluZ0JveCgpe3RoaXMuY29tcHV0ZUJvdW5kaW5nU3BoZXJlKCk7fVxuICBvdmVycmlkZSBjb21wdXRlQm91bmRpbmdTcGhlcmUoKXtcbiAgICB0aGlzLmJvdW5kaW5nU3BoZXJlPz89bmV3IFRIUkVFLlNwaGVyZSgpO3RoaXMuYm91bmRpbmdTcGhlcmUubWFrZUVtcHR5KCk7XG4gICAgdGhpcy5ib3VuZGluZ0JveD8/PW5ldyBUSFJFRS5Cb3gzKCk7dGhpcy5ib3VuZGluZ0JveC5tYWtlRW1wdHkoKTtcbiAgICBmb3IobGV0IGk9MDtpPHRoaXMuY291bnQ7aSsrKXtcbiAgICAgIHRoaXMuZ2V0TW9ycGhBdChpLHRoaXMucG9zZSk7dGhpcy51cGRhdGVQb3NlQm91bmRzKCk7dGhpcy5nZXRNYXRyaXhBdChpLHRoaXMubG9jYWxNYXRyaXgpO1xuICAgICAgdGhpcy5zcGhlcmUuY29weSh0aGlzLnBvc2UuZ2VvbWV0cnkuYm91bmRpbmdTcGhlcmUhKS5hcHBseU1hdHJpeDQodGhpcy5sb2NhbE1hdHJpeCk7dGhpcy5ib3VuZGluZ1NwaGVyZS51bmlvbih0aGlzLnNwaGVyZSk7XG4gICAgICB0aGlzLmxvY2FsQm94LmNvcHkodGhpcy5wb3NlLmdlb21ldHJ5LmJvdW5kaW5nQm94ISkuYXBwbHlNYXRyaXg0KHRoaXMubG9jYWxNYXRyaXgpO3RoaXMuYm91bmRpbmdCb3gudW5pb24odGhpcy5sb2NhbEJveCk7XG4gICAgfVxuICB9XG4gIG92ZXJyaWRlIHJheWNhc3QocmF5Y2FzdGVyOlRIUkVFLlJheWNhc3RlcixpbnRlcnNlY3RzOlRIUkVFLkludGVyc2VjdGlvbltdKXtcbiAgICBpZighdGhpcy5jb3VudClyZXR1cm47XG4gICAgaWYodGhpcy5ib3VuZGluZ1NwaGVyZT09PW51bGwpdGhpcy5jb21wdXRlQm91bmRpbmdTcGhlcmUoKTtcbiAgICB0aGlzLnNwaGVyZS5jb3B5KHRoaXMuYm91bmRpbmdTcGhlcmUhKS5hcHBseU1hdHJpeDQodGhpcy5tYXRyaXhXb3JsZCk7XG4gICAgaWYoIXJheWNhc3Rlci5yYXkuaW50ZXJzZWN0c1NwaGVyZSh0aGlzLnNwaGVyZSkpcmV0dXJuO1xuICAgIHRoaXMucG9zZS5tYXRlcmlhbD10aGlzLm1hdGVyaWFsO1xuICAgIGZvcihsZXQgaT0wO2k8dGhpcy5jb3VudDtpKyspe1xuICAgICAgdGhpcy5nZXRNYXRyaXhBdChpLHRoaXMubG9jYWxNYXRyaXgpO3RoaXMucG9zZS5tYXRyaXhXb3JsZC5tdWx0aXBseU1hdHJpY2VzKHRoaXMubWF0cml4V29ybGQsdGhpcy5sb2NhbE1hdHJpeCk7XG4gICAgICB0aGlzLmdldE1vcnBoQXQoaSx0aGlzLnBvc2UpO3RoaXMudXBkYXRlUG9zZUJvdW5kcygpO3RoaXMucG9zZS5yYXljYXN0KHJheWNhc3Rlcix0aGlzLmhpdHMpO1xuICAgICAgZm9yKGNvbnN0IGhpdCBvZiB0aGlzLmhpdHMpe2hpdC5pbnN0YW5jZUlkPWk7aGl0Lm9iamVjdD10aGlzO2ludGVyc2VjdHMucHVzaChoaXQpO31cbiAgICAgIHRoaXMuaGl0cy5sZW5ndGg9MDtcbiAgICB9XG4gIH1cbn1cblxuLyoqIE1vZGVsIGNvbXBvbmVudHMgYW5kIHBhaW50ZWQgdHJvb3BzIHNoYXJlIGdlb21ldHJ5L21hdGVyaWFsIGRyYXcgY2FsbHMuXG4gKiBObyBHUFUgb2JqZWN0IGlzIGNyZWF0ZWQgcGVyIHNvbGRpZXIsIGFuZCBkZWFkL29mZnNjcmVlbiBiYXRjaGVzIGFyZSByZXRpcmVkLiAqL1xuZXhwb3J0IGNsYXNzIEFjdG9yQmF0Y2hlcyB7XG4gIHByaXZhdGUgYmF0Y2hlcz1uZXcgTWFwPHN0cmluZyxCYXRjaD4oKTtcbiAgcHJpdmF0ZSBnZW9tZXRyaWVzPW5ldyBNYXA8VEhSRUUuQnVmZmVyR2VvbWV0cnkse3ZpZXc6VEhSRUUuQnVmZmVyR2VvbWV0cnk7cmVmczpudW1iZXJ9PigpO1xuICBwcml2YXRlIHRleHR1cmVzPW5ldyBNYXA8VEhSRUUuVGV4dHVyZSx7dmlldzpUSFJFRS5UZXh0dXJlO3JlZnM6bnVtYmVyfT4oKTtcbiAgcHJpdmF0ZSBmcmFtZT0wO1xuICBwcml2YXRlIG1hdHJpeD1uZXcgVEhSRUUuTWF0cml4NCgpO1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNjZW5lOlRIUkVFLlNjZW5lKXt9XG4gIGJlZ2luKCl7dGhpcy5mcmFtZSsrO2Zvcihjb25zdCBiYXRjaCBvZiB0aGlzLmJhdGNoZXMudmFsdWVzKCkpe2JhdGNoLm1hdHJpY2VzLmxlbmd0aD0wO2JhdGNoLmFuaW1hdGlvbnMubGVuZ3RoPTA7YmF0Y2guaWRzLmxlbmd0aD0wO319XG4gIHByaXZhdGUgZ2VvbWV0cnkoc291cmNlOlRIUkVFLkJ1ZmZlckdlb21ldHJ5LGhlbGQ6U2V0PFRIUkVFLkJ1ZmZlckdlb21ldHJ5Pil7XG4gICAgbGV0IHJlc291cmNlPXRoaXMuZ2VvbWV0cmllcy5nZXQoc291cmNlKTtcbiAgICBpZighcmVzb3VyY2Upe1xuICAgICAgLy8gRWFjaCByZW5kZXJlciBvd25zIGl0cyBHUFUgYWxsb2NhdGlvbnMgYW5kIGRpc3Bvc2UgbGlzdGVuZXJzLiBWaWV3c1xuICAgICAgLy8gc2hhcmUgZGVjb2RlZCB0eXBlZCBhcnJheXMgd2l0aG91dCBhdHRhY2hpbmcgYSByZW5kZXJlciB0byB0aGUgZ2xvYmFsXG4gICAgICAvLyBtb2RlbCBnZW9tZXRyeSBvciBkZXN0cm95aW5nIGFub3RoZXIgbGF5ZXIncyBidWZmZXJzIG9uIHRlYXJkb3duLlxuICAgICAgY29uc3Qgdmlldz1uZXcgVEhSRUUuQnVmZmVyR2VvbWV0cnkoKTt2aWV3Lm5hbWU9c291cmNlLm5hbWU7XG4gICAgICB2aWV3LmluZGV4PXNvdXJjZS5pbmRleDt2aWV3LmF0dHJpYnV0ZXM9c291cmNlLmF0dHJpYnV0ZXM7dmlldy5tb3JwaEF0dHJpYnV0ZXM9c291cmNlLm1vcnBoQXR0cmlidXRlcztcbiAgICAgIHZpZXcubW9ycGhUYXJnZXRzUmVsYXRpdmU9c291cmNlLm1vcnBoVGFyZ2V0c1JlbGF0aXZlO3ZpZXcuZ3JvdXBzPXNvdXJjZS5ncm91cHMubWFwKGdyb3VwPT4oey4uLmdyb3VwfSkpO3ZpZXcuZHJhd1JhbmdlPXsuLi5zb3VyY2UuZHJhd1JhbmdlfTtcbiAgICAgIHZpZXcuYm91bmRpbmdCb3g9c291cmNlLmJvdW5kaW5nQm94Py5jbG9uZSgpPz9udWxsO3ZpZXcuYm91bmRpbmdTcGhlcmU9c291cmNlLmJvdW5kaW5nU3BoZXJlPy5jbG9uZSgpPz9udWxsO1xuICAgICAgcmVzb3VyY2U9e3ZpZXcscmVmczowfTt0aGlzLmdlb21ldHJpZXMuc2V0KHNvdXJjZSxyZXNvdXJjZSk7XG4gICAgfVxuICAgIGlmKCFoZWxkLmhhcyhzb3VyY2UpKXtoZWxkLmFkZChzb3VyY2UpO3Jlc291cmNlLnJlZnMrKzt9cmV0dXJuIHJlc291cmNlLnZpZXc7XG4gIH1cbiAgcHJpdmF0ZSB0ZXh0dXJlKHNvdXJjZTpUSFJFRS5UZXh0dXJlLGhlbGQ6U2V0PFRIUkVFLlRleHR1cmU+KXtcbiAgICBsZXQgcmVzb3VyY2U9dGhpcy50ZXh0dXJlcy5nZXQoc291cmNlKTtcbiAgICBpZighcmVzb3VyY2Upe1xuICAgICAgLy8gVGV4dHVyZS5jb3B5IEpTT04tY2xvbmVzIHVzZXJEYXRhIGJ5IGRlZmF1bHQuIFBhaW50ZWQgYWxwaGEgbWFza3MgYXJlXG4gICAgICAvLyBpbW11dGFibGUgdHlwZWQgYXJyYXlzOyBwcmVzZXJ2ZSB0aGVtIHdpdGhvdXQgZXhwYW5kaW5nIGludG8gb2JqZWN0cy5cbiAgICAgIGNvbnN0IGNsZWFuPU9iamVjdC5jcmVhdGUoc291cmNlKSBhcyBUSFJFRS5UZXh0dXJlO2NsZWFuLnVzZXJEYXRhPXt9O1xuICAgICAgY29uc3Qgdmlldz1uZXcgKHNvdXJjZS5jb25zdHJ1Y3RvciBhcyBuZXcoKT0+VEhSRUUuVGV4dHVyZSkoKS5jb3B5KGNsZWFuKTt2aWV3LnVzZXJEYXRhPXNvdXJjZS51c2VyRGF0YTtcbiAgICAgIHJlc291cmNlPXt2aWV3LHJlZnM6MH07dGhpcy50ZXh0dXJlcy5zZXQoc291cmNlLHJlc291cmNlKTtcbiAgICB9XG4gICAgaWYoIWhlbGQuaGFzKHNvdXJjZSkpe2hlbGQuYWRkKHNvdXJjZSk7cmVzb3VyY2UucmVmcysrO31yZXR1cm4gcmVzb3VyY2UudmlldztcbiAgfVxuICBwcml2YXRlIG1hdGVyaWFsKHNvdXJjZTpUSFJFRS5NYXRlcmlhbCxoZWxkOlNldDxUSFJFRS5UZXh0dXJlPil7XG4gICAgY29uc3QgbWF0ZXJpYWw9c291cmNlLmNsb25lKCk7XG4gICAgZm9yKGNvbnN0IFtrZXksdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHNvdXJjZSkpaWYodmFsdWUgaW5zdGFuY2VvZiBUSFJFRS5UZXh0dXJlKShtYXRlcmlhbCBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsdW5rbm93bj4pW2tleV09dGhpcy50ZXh0dXJlKHZhbHVlLGhlbGQpO1xuICAgIGlmKHNvdXJjZSBpbnN0YW5jZW9mIFRIUkVFLlNoYWRlck1hdGVyaWFsICYmIG1hdGVyaWFsIGluc3RhbmNlb2YgVEhSRUUuU2hhZGVyTWF0ZXJpYWwpZm9yKGNvbnN0IFtrZXksdW5pZm9ybV0gb2YgT2JqZWN0LmVudHJpZXMoc291cmNlLnVuaWZvcm1zKSl7XG4gICAgICBjb25zdCB2YWx1ZT11bmlmb3JtLnZhbHVlO1xuICAgICAgaWYodmFsdWUgaW5zdGFuY2VvZiBUSFJFRS5UZXh0dXJlKW1hdGVyaWFsLnVuaWZvcm1zW2tleV0hLnZhbHVlPXRoaXMudGV4dHVyZSh2YWx1ZSxoZWxkKTtcbiAgICAgIGVsc2UgaWYoQXJyYXkuaXNBcnJheSh2YWx1ZSkpbWF0ZXJpYWwudW5pZm9ybXNba2V5XSEudmFsdWU9dmFsdWUubWFwKGl0ZW09Pml0ZW0gaW5zdGFuY2VvZiBUSFJFRS5UZXh0dXJlP3RoaXMudGV4dHVyZShpdGVtLGhlbGQpOml0ZW0pO1xuICAgIH1cbiAgICByZXR1cm4gbWF0ZXJpYWw7XG4gIH1cbiAgYWRkKGtleTpzdHJpbmcsdGVtcGxhdGU6VEhSRUUuT2JqZWN0M0QsbWF0cml4OlRIUkVFLk1hdHJpeDQsaWQ6c3RyaW5nLGNvbG9yPzpzdHJpbmcsY29uc3RydWN0aW5nPWZhbHNlLHJldmVhbERlY2s9ZmFsc2UsYW5pbWF0aW9uPzpCYXRjaEFuaW1hdGlvbil7XG4gICAgbGV0IGJhdGNoPXRoaXMuYmF0Y2hlcy5nZXQoa2V5KTtcbiAgICBpZighYmF0Y2gpe1xuICAgICAgY29uc3QgcGFydHM6UGFydFtdPVtdLGdlb21ldHJpZXM9bmV3IFNldDxUSFJFRS5CdWZmZXJHZW9tZXRyeT4oKSx0ZXh0dXJlcz1uZXcgU2V0PFRIUkVFLlRleHR1cmU+KCk7dGVtcGxhdGUudXBkYXRlTWF0cml4V29ybGQodHJ1ZSk7XG4gICAgICB0ZW1wbGF0ZS50cmF2ZXJzZShvYmplY3Q9PntpZighKG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLk1lc2gpKXJldHVybjtcbiAgICAgICAgY29uc3QgbWFwPShzb3VyY2U6VEhSRUUuTWF0ZXJpYWwpPT57XG4gICAgICAgICAgY29uc3QgbWF0ZXJpYWw9dGhpcy5tYXRlcmlhbChzb3VyY2UsdGV4dHVyZXMpO1xuICAgICAgICAgIGlmKHNvdXJjZS5uYW1lPT09J1RlYW1Db2xvcicgJiYgJ2NvbG9yJyBpbiBtYXRlcmlhbCkobWF0ZXJpYWwgYXMgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwpLmNvbG9yLnNldChjb2xvcj8/JyM4ODk3N2MnKTtcbiAgICAgICAgICBpZihjb25zdHJ1Y3Rpbmcpe21hdGVyaWFsLnRyYW5zcGFyZW50PXRydWU7bWF0ZXJpYWwub3BhY2l0eT0uNDg7fVxuICAgICAgICAgIC8vIENsb3RoIGFsb25lIGJlY29tZXMgdHJhbnNsdWNlbnQuIFRoZSBodWxsIHN0aWxsIG9jY2x1ZGVzLCBjb2xsaWRlc1xuICAgICAgICAgIC8vIGFuZCBjYXN0cyBzaGFkb3dzIG5vcm1hbGx5OyBzZWxlY3Rpb24gbmV2ZXIgbXV0YXRlcyBzaGFyZWQgYXNzZXRzLlxuICAgICAgICAgIGlmKHJldmVhbERlY2sgJiYgc291cmNlLm5hbWUuc3RhcnRzV2l0aCgndW5ibGVhY2hlZCBzYWlsJykpe21hdGVyaWFsLnRyYW5zcGFyZW50PXRydWU7bWF0ZXJpYWwub3BhY2l0eT0uMjI7bWF0ZXJpYWwuZGVwdGhXcml0ZT1mYWxzZTt9XG4gICAgICAgICAgcmV0dXJuIG1hdGVyaWFsO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBnZW9tZXRyeT10aGlzLmdlb21ldHJ5KG9iamVjdC5nZW9tZXRyeSxnZW9tZXRyaWVzKSxtb3JwaENvdW50PU9iamVjdC52YWx1ZXMoZ2VvbWV0cnkubW9ycGhBdHRyaWJ1dGVzKVswXT8ubGVuZ3RoPz8wO1xuICAgICAgICBwYXJ0cy5wdXNoKHtuYW1lOm9iamVjdC5uYW1lLGdlb21ldHJ5LG1hdGVyaWFsOkFycmF5LmlzQXJyYXkob2JqZWN0Lm1hdGVyaWFsKT9vYmplY3QubWF0ZXJpYWwubWFwKG1hcCk6bWFwKG9iamVjdC5tYXRlcmlhbCksbG9jYWw6b2JqZWN0Lm1hdHJpeFdvcmxkLmNsb25lKCksbW9ycGg6QXJyYXkuZnJvbSh7bGVuZ3RoOm1vcnBoQ291bnR9LChfLGkpPT5vYmplY3QubW9ycGhUYXJnZXRJbmZsdWVuY2VzPy5baV0/PzApfSk7XG4gICAgICB9KTtcbiAgICAgIGJhdGNoPXtwYXJ0cyxtZXNoZXM6W10sbWF0cmljZXM6W10sYW5pbWF0aW9uczpbXSxpZHM6W10sY2FwYWNpdHk6MCxsYXN0OnRoaXMuZnJhbWUsZ2VvbWV0cmllcyx0ZXh0dXJlc307dGhpcy5iYXRjaGVzLnNldChrZXksYmF0Y2gpO1xuICAgIH1cbiAgICBiYXRjaC5tYXRyaWNlcy5wdXNoKG1hdHJpeCk7YmF0Y2guYW5pbWF0aW9ucy5wdXNoKGFuaW1hdGlvbik7YmF0Y2guaWRzLnB1c2goaWQpO2JhdGNoLmxhc3Q9dGhpcy5mcmFtZTtcbiAgfVxuICBmaW5pc2goKXtcbiAgICBmb3IoY29uc3QgW2tleSxiYXRjaF0gb2YgdGhpcy5iYXRjaGVzKXtcbiAgICAgIGlmKCFiYXRjaC5tYXRyaWNlcy5sZW5ndGgpe1xuICAgICAgICBmb3IoY29uc3QgbWVzaCBvZiBiYXRjaC5tZXNoZXMpe21lc2guY291bnQ9MDttZXNoLnZpc2libGU9ZmFsc2U7fVxuICAgICAgICBpZih0aGlzLmZyYW1lLWJhdGNoLmxhc3Q+MTIwKXRoaXMucmVtb3ZlKGtleSxiYXRjaCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYoYmF0Y2gubWF0cmljZXMubGVuZ3RoPmJhdGNoLmNhcGFjaXR5KXtcbiAgICAgICAgZm9yKGNvbnN0IG1lc2ggb2YgYmF0Y2gubWVzaGVzKXt0aGlzLnNjZW5lLnJlbW92ZShtZXNoKTttZXNoLmRpc3Bvc2UoKTt9XG4gICAgICAgIGJhdGNoLmNhcGFjaXR5PTIqKk1hdGguY2VpbChNYXRoLmxvZzIoTWF0aC5tYXgoMSxiYXRjaC5tYXRyaWNlcy5sZW5ndGgpKSk7XG4gICAgICAgIGJhdGNoLm1lc2hlcz1iYXRjaC5wYXJ0cy5tYXAocGFydD0+e2NvbnN0IG1lc2g9cGFydC5tb3JwaC5sZW5ndGg/bmV3IE1vcnBoSW5zdGFuY2VkTWVzaChwYXJ0LGJhdGNoLmNhcGFjaXR5KTpuZXcgVEhSRUUuSW5zdGFuY2VkTWVzaChwYXJ0Lmdlb21ldHJ5LHBhcnQubWF0ZXJpYWwsYmF0Y2guY2FwYWNpdHkpO21lc2gubmFtZT1wYXJ0Lm5hbWU7bWVzaC5jYXN0U2hhZG93PXRydWU7bWVzaC5yZWNlaXZlU2hhZG93PXRydWU7bWVzaC5pbnN0YW5jZU1hdHJpeC5zZXRVc2FnZShUSFJFRS5EeW5hbWljRHJhd1VzYWdlKTttZXNoLnVzZXJEYXRhLmlkcz1iYXRjaC5pZHM7dGhpcy5zY2VuZS5hZGQobWVzaCk7cmV0dXJuIG1lc2g7fSk7XG4gICAgICB9XG4gICAgICBmb3IobGV0IHA9MDtwPGJhdGNoLm1lc2hlcy5sZW5ndGg7cCsrKXtcbiAgICAgICAgY29uc3QgbWVzaD1iYXRjaC5tZXNoZXNbcF0hLHBhcnQ9YmF0Y2gucGFydHNbcF0hO21lc2guY291bnQ9YmF0Y2gubWF0cmljZXMubGVuZ3RoO21lc2gudmlzaWJsZT1tZXNoLmNvdW50PjA7bWVzaC51c2VyRGF0YS5pZHM9YmF0Y2guaWRzO1xuICAgICAgICBmb3IobGV0IGk9MDtpPG1lc2guY291bnQ7aSsrKXtcbiAgICAgICAgICBjb25zdCBhbmltYXRpb249YmF0Y2guYW5pbWF0aW9uc1tpXT8uZ2V0KHBhcnQubmFtZSk7XG4gICAgICAgICAgbWVzaC5zZXRNYXRyaXhBdChpLHRoaXMubWF0cml4LmNvcHkoYmF0Y2gubWF0cmljZXNbaV0hKS5tdWx0aXBseShhbmltYXRpb24/Lm1hdHJpeD8/cGFydC5sb2NhbCkpO1xuICAgICAgICAgIGlmKG1lc2ggaW5zdGFuY2VvZiBNb3JwaEluc3RhbmNlZE1lc2gpbWVzaC5zZXRQb3NlQXQoaSxhbmltYXRpb24/Lm1vcnBoPz9wYXJ0Lm1vcnBoKTtcbiAgICAgICAgfVxuICAgICAgICBtZXNoLmluc3RhbmNlTWF0cml4Lm5lZWRzVXBkYXRlPXRydWU7aWYobWVzaC5tb3JwaFRleHR1cmUpbWVzaC5tb3JwaFRleHR1cmUubmVlZHNVcGRhdGU9dHJ1ZTtpZihtZXNoLmNvdW50KW1lc2guY29tcHV0ZUJvdW5kaW5nU3BoZXJlKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIG9iamVjdHMoKXtyZXR1cm4gWy4uLnRoaXMuYmF0Y2hlcy52YWx1ZXMoKV0uZmxhdE1hcChiYXRjaD0+YmF0Y2gubWVzaGVzKS5maWx0ZXIobWVzaD0+bWVzaC52aXNpYmxlKTt9XG4gIGZvcmdldChrZXk6c3RyaW5nKXtjb25zdCBiYXRjaD10aGlzLmJhdGNoZXMuZ2V0KGtleSk7aWYoYmF0Y2gpdGhpcy5yZW1vdmUoa2V5LGJhdGNoKTt9XG4gIHJlbW92ZShrZXk6c3RyaW5nLGJhdGNoOkJhdGNoKXtcbiAgICBmb3IoY29uc3QgbWVzaCBvZiBiYXRjaC5tZXNoZXMpe3RoaXMuc2NlbmUucmVtb3ZlKG1lc2gpO21lc2guZGlzcG9zZSgpO31cbiAgICBmb3IoY29uc3QgcGFydCBvZiBiYXRjaC5wYXJ0cylmb3IoY29uc3QgbWF0IG9mIEFycmF5LmlzQXJyYXkocGFydC5tYXRlcmlhbCk/cGFydC5tYXRlcmlhbDpbcGFydC5tYXRlcmlhbF0pbWF0LmRpc3Bvc2UoKTtcbiAgICBmb3IoY29uc3Qgc291cmNlIG9mIGJhdGNoLmdlb21ldHJpZXMpe2NvbnN0IHJlc291cmNlPXRoaXMuZ2VvbWV0cmllcy5nZXQoc291cmNlKSE7aWYoLS1yZXNvdXJjZS5yZWZzPT09MCl7cmVzb3VyY2Uudmlldy5kaXNwb3NlKCk7dGhpcy5nZW9tZXRyaWVzLmRlbGV0ZShzb3VyY2UpO319XG4gICAgZm9yKGNvbnN0IHNvdXJjZSBvZiBiYXRjaC50ZXh0dXJlcyl7Y29uc3QgcmVzb3VyY2U9dGhpcy50ZXh0dXJlcy5nZXQoc291cmNlKSE7aWYoLS1yZXNvdXJjZS5yZWZzPT09MCl7cmVzb3VyY2Uudmlldy5kaXNwb3NlKCk7dGhpcy50ZXh0dXJlcy5kZWxldGUoc291cmNlKTt9fVxuICAgIHRoaXMuYmF0Y2hlcy5kZWxldGUoa2V5KTtcbiAgfVxuICBkaXNwb3NlKCl7Zm9yKGNvbnN0IFtrZXksYmF0Y2hdIG9mIHRoaXMuYmF0Y2hlcyl0aGlzLnJlbW92ZShrZXksYmF0Y2gpO31cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBT3ZCLE1BQU0sMkJBQTJCLE1BQU0sY0FBYztBQUFBLEVBQzNDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBLGNBQVksSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUM5QixXQUFTLElBQUksTUFBTSxLQUFLO0FBQUEsRUFDeEIsU0FBTyxJQUFJLE1BQU0sT0FBTztBQUFBLEVBQ3hCLE9BQTBCLENBQUM7QUFBQSxFQUNuQyxZQUFZLE1BQVUsVUFBZ0I7QUFDcEMsVUFBTSxLQUFLLFVBQVMsS0FBSyxVQUFTLFFBQVE7QUFDMUMsVUFBTSxTQUFPLEtBQUssVUFBUyxXQUFTLElBQUksTUFBTSxlQUFlO0FBRTdELGFBQVMsUUFBTSxPQUFPO0FBQU0sYUFBUyxhQUFXLE9BQU87QUFBVyxhQUFTLGtCQUFnQixPQUFPO0FBQ2xHLGFBQVMsdUJBQXFCLE9BQU87QUFBcUIsYUFBUyxTQUFPLE9BQU87QUFBTyxhQUFTLFlBQVUsT0FBTztBQUNsSCxhQUFTLGNBQVksSUFBSSxNQUFNLEtBQUs7QUFBRSxhQUFTLGlCQUFlLElBQUksTUFBTSxPQUFPO0FBQy9FLFNBQUssT0FBSyxJQUFJLE1BQU0sS0FBSyxVQUFTLEtBQUssUUFBUTtBQUMvQyxVQUFNLFNBQU8sSUFBSSxNQUFNLFFBQVEsR0FBRSxPQUFLLElBQUksTUFBTSxRQUFRLEdBQUUsV0FBUyxPQUFPLGFBQWEsVUFBVTtBQUNqRyxTQUFLLGFBQVcsSUFBSSxNQUFNLEtBQUs7QUFDL0IsYUFBUSxJQUFFLEdBQUUsSUFBRSxTQUFTLE9BQU0sSUFBSSxNQUFLLFdBQVcsY0FBYyxPQUFPLG9CQUFvQixVQUFTLENBQUMsQ0FBQztBQUNyRyxTQUFLLFVBQVEsT0FBTyxnQkFBZ0IsWUFBVSxDQUFDLEdBQUcsSUFBSSxlQUFXO0FBQy9ELFlBQU0sU0FBTyxJQUFJLE1BQU0sS0FBSztBQUM1QixlQUFRLElBQUUsR0FBRSxJQUFFLFVBQVUsT0FBTSxLQUFJO0FBQ2hDLGVBQU8sb0JBQW9CLFdBQVUsQ0FBQztBQUN0QyxZQUFHLENBQUMsT0FBTyxxQkFBcUIsUUFBTyxJQUFJLEtBQUssb0JBQW9CLFVBQVMsQ0FBQyxDQUFDO0FBQy9FLGVBQU8sY0FBYyxNQUFNO0FBQUEsTUFDN0I7QUFDQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsU0FBSyxVQUFVLEdBQUUsS0FBSyxLQUFLO0FBQUEsRUFDN0I7QUFBQSxFQUNBLFVBQVUsT0FBYSxTQUEwQjtBQUMvQyxVQUFNLGFBQVcsS0FBSyxLQUFLO0FBQzNCLGFBQVEsSUFBRSxHQUFFLElBQUUsV0FBVyxRQUFPLElBQUksWUFBVyxDQUFDLElBQUUsUUFBUSxDQUFDLEtBQUc7QUFDOUQsU0FBSyxXQUFXLE9BQU0sS0FBSyxJQUFJO0FBQUEsRUFDakM7QUFBQSxFQUNRLG1CQUFrQjtBQUN4QixVQUFNLFNBQU8sS0FBSyxLQUFLLFNBQVMsWUFBYSxLQUFLLEtBQUssVUFBVSxHQUFFLFVBQVEsS0FBSyxLQUFLO0FBR3JGLGFBQVEsSUFBRSxHQUFFLElBQUUsS0FBSyxPQUFPLFFBQU8sS0FBSTtBQUNuQyxZQUFNLFNBQU8sUUFBUSxDQUFDLEtBQUcsR0FBRSxRQUFNLEtBQUssT0FBTyxDQUFDO0FBQzlDLFVBQUcsV0FBUyxFQUFFO0FBQ2QsYUFBTyxJQUFJLGdCQUFnQixTQUFPLElBQUUsTUFBTSxNQUFJLE1BQU0sS0FBSSxNQUFNO0FBQzlELGFBQU8sSUFBSSxnQkFBZ0IsU0FBTyxJQUFFLE1BQU0sTUFBSSxNQUFNLEtBQUksTUFBTTtBQUFBLElBQ2hFO0FBQ0EsV0FBTyxrQkFBa0IsS0FBSyxLQUFLLFNBQVMsY0FBZTtBQUFBLEVBQzdEO0FBQUEsRUFDUyxxQkFBb0I7QUFBQyxTQUFLLHNCQUFzQjtBQUFBLEVBQUU7QUFBQSxFQUNsRCx3QkFBdUI7QUFDOUIsU0FBSyxtQkFBaUIsSUFBSSxNQUFNLE9BQU87QUFBRSxTQUFLLGVBQWUsVUFBVTtBQUN2RSxTQUFLLGdCQUFjLElBQUksTUFBTSxLQUFLO0FBQUUsU0FBSyxZQUFZLFVBQVU7QUFDL0QsYUFBUSxJQUFFLEdBQUUsSUFBRSxLQUFLLE9BQU0sS0FBSTtBQUMzQixXQUFLLFdBQVcsR0FBRSxLQUFLLElBQUk7QUFBRSxXQUFLLGlCQUFpQjtBQUFFLFdBQUssWUFBWSxHQUFFLEtBQUssV0FBVztBQUN4RixXQUFLLE9BQU8sS0FBSyxLQUFLLEtBQUssU0FBUyxjQUFlLEVBQUUsYUFBYSxLQUFLLFdBQVc7QUFBRSxXQUFLLGVBQWUsTUFBTSxLQUFLLE1BQU07QUFDekgsV0FBSyxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVMsV0FBWSxFQUFFLGFBQWEsS0FBSyxXQUFXO0FBQUUsV0FBSyxZQUFZLE1BQU0sS0FBSyxRQUFRO0FBQUEsSUFDekg7QUFBQSxFQUNGO0FBQUEsRUFDUyxRQUFRLFdBQTBCLFlBQWdDO0FBQ3pFLFFBQUcsQ0FBQyxLQUFLLE1BQU07QUFDZixRQUFHLEtBQUssbUJBQWlCLEtBQUssTUFBSyxzQkFBc0I7QUFDekQsU0FBSyxPQUFPLEtBQUssS0FBSyxjQUFlLEVBQUUsYUFBYSxLQUFLLFdBQVc7QUFDcEUsUUFBRyxDQUFDLFVBQVUsSUFBSSxpQkFBaUIsS0FBSyxNQUFNLEVBQUU7QUFDaEQsU0FBSyxLQUFLLFdBQVMsS0FBSztBQUN4QixhQUFRLElBQUUsR0FBRSxJQUFFLEtBQUssT0FBTSxLQUFJO0FBQzNCLFdBQUssWUFBWSxHQUFFLEtBQUssV0FBVztBQUFFLFdBQUssS0FBSyxZQUFZLGlCQUFpQixLQUFLLGFBQVksS0FBSyxXQUFXO0FBQzdHLFdBQUssV0FBVyxHQUFFLEtBQUssSUFBSTtBQUFFLFdBQUssaUJBQWlCO0FBQUUsV0FBSyxLQUFLLFFBQVEsV0FBVSxLQUFLLElBQUk7QUFDMUYsaUJBQVUsT0FBTyxLQUFLLE1BQUs7QUFBQyxZQUFJLGFBQVc7QUFBRSxZQUFJLFNBQU87QUFBSyxtQkFBVyxLQUFLLEdBQUc7QUFBQSxNQUFFO0FBQ2xGLFdBQUssS0FBSyxTQUFPO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0Y7QUFJTyxhQUFNLGFBQWE7QUFBQSxFQU14QixZQUFvQixPQUFrQjtBQUFsQjtBQUFBLEVBQW1CO0FBQUEsRUFML0IsVUFBUSxvQkFBSSxJQUFrQjtBQUFBLEVBQzlCLGFBQVcsb0JBQUksSUFBa0U7QUFBQSxFQUNqRixXQUFTLG9CQUFJLElBQW9EO0FBQUEsRUFDakUsUUFBTTtBQUFBLEVBQ04sU0FBTyxJQUFJLE1BQU0sUUFBUTtBQUFBLEVBRWpDLFFBQU87QUFBQyxTQUFLO0FBQVEsZUFBVSxTQUFTLEtBQUssUUFBUSxPQUFPLEdBQUU7QUFBQyxZQUFNLFNBQVMsU0FBTztBQUFFLFlBQU0sV0FBVyxTQUFPO0FBQUUsWUFBTSxJQUFJLFNBQU87QUFBQSxJQUFFO0FBQUEsRUFBQztBQUFBLEVBQzdILFNBQVMsUUFBNEIsTUFBK0I7QUFDMUUsUUFBSSxXQUFTLEtBQUssV0FBVyxJQUFJLE1BQU07QUFDdkMsUUFBRyxDQUFDLFVBQVM7QUFJWCxZQUFNLE9BQUssSUFBSSxNQUFNLGVBQWU7QUFBRSxXQUFLLE9BQUssT0FBTztBQUN2RCxXQUFLLFFBQU0sT0FBTztBQUFNLFdBQUssYUFBVyxPQUFPO0FBQVcsV0FBSyxrQkFBZ0IsT0FBTztBQUN0RixXQUFLLHVCQUFxQixPQUFPO0FBQXFCLFdBQUssU0FBTyxPQUFPLE9BQU8sSUFBSSxZQUFRLEVBQUMsR0FBRyxNQUFLLEVBQUU7QUFBRSxXQUFLLFlBQVUsRUFBQyxHQUFHLE9BQU8sVUFBUztBQUM1SSxXQUFLLGNBQVksT0FBTyxhQUFhLE1BQU0sS0FBRztBQUFLLFdBQUssaUJBQWUsT0FBTyxnQkFBZ0IsTUFBTSxLQUFHO0FBQ3ZHLGlCQUFTLEVBQUMsTUFBSyxNQUFLLEVBQUM7QUFBRSxXQUFLLFdBQVcsSUFBSSxRQUFPLFFBQVE7QUFBQSxJQUM1RDtBQUNBLFFBQUcsQ0FBQyxLQUFLLElBQUksTUFBTSxHQUFFO0FBQUMsV0FBSyxJQUFJLE1BQU07QUFBRSxlQUFTO0FBQUEsSUFBTztBQUFDLFdBQU8sU0FBUztBQUFBLEVBQzFFO0FBQUEsRUFDUSxRQUFRLFFBQXFCLE1BQXdCO0FBQzNELFFBQUksV0FBUyxLQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ3JDLFFBQUcsQ0FBQyxVQUFTO0FBR1gsWUFBTSxRQUFNLE9BQU8sT0FBTyxNQUFNO0FBQW1CLFlBQU0sV0FBUyxDQUFDO0FBQ25FLFlBQU0sT0FBSyxJQUFLLE9BQU8sWUFBcUMsRUFBRSxLQUFLLEtBQUs7QUFBRSxXQUFLLFdBQVMsT0FBTztBQUMvRixpQkFBUyxFQUFDLE1BQUssTUFBSyxFQUFDO0FBQUUsV0FBSyxTQUFTLElBQUksUUFBTyxRQUFRO0FBQUEsSUFDMUQ7QUFDQSxRQUFHLENBQUMsS0FBSyxJQUFJLE1BQU0sR0FBRTtBQUFDLFdBQUssSUFBSSxNQUFNO0FBQUUsZUFBUztBQUFBLElBQU87QUFBQyxXQUFPLFNBQVM7QUFBQSxFQUMxRTtBQUFBLEVBQ1EsU0FBUyxRQUFzQixNQUF3QjtBQUM3RCxVQUFNLFdBQVMsT0FBTyxNQUFNO0FBQzVCLGVBQVUsQ0FBQyxLQUFJLEtBQUssS0FBSyxPQUFPLFFBQVEsTUFBTSxFQUFFLEtBQUcsaUJBQWlCLE1BQU0sUUFBUSxDQUFDLFNBQStDLEdBQUcsSUFBRSxLQUFLLFFBQVEsT0FBTSxJQUFJO0FBQzlKLFFBQUcsa0JBQWtCLE1BQU0sa0JBQWtCLG9CQUFvQixNQUFNLGVBQWUsWUFBVSxDQUFDLEtBQUksT0FBTyxLQUFLLE9BQU8sUUFBUSxPQUFPLFFBQVEsR0FBRTtBQUMvSSxZQUFNLFFBQU0sUUFBUTtBQUNwQixVQUFHLGlCQUFpQixNQUFNLFFBQVEsVUFBUyxTQUFTLEdBQUcsRUFBRyxRQUFNLEtBQUssUUFBUSxPQUFNLElBQUk7QUFBQSxlQUMvRSxNQUFNLFFBQVEsS0FBSyxFQUFFLFVBQVMsU0FBUyxHQUFHLEVBQUcsUUFBTSxNQUFNLElBQUksVUFBTSxnQkFBZ0IsTUFBTSxVQUFRLEtBQUssUUFBUSxNQUFLLElBQUksSUFBRSxJQUFJO0FBQUEsSUFDdkk7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsSUFBSSxLQUFXLFVBQXdCLFFBQXFCLElBQVUsT0FBYyxlQUFhLE9BQU0sYUFBVyxPQUFNLFdBQTBCO0FBQ2hKLFFBQUksUUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQzlCLFFBQUcsQ0FBQyxPQUFNO0FBQ1IsWUFBTSxRQUFhLENBQUMsR0FBRSxhQUFXLG9CQUFJLElBQTBCLEdBQUUsV0FBUyxvQkFBSSxJQUFtQjtBQUFFLGVBQVMsa0JBQWtCLElBQUk7QUFDbEksZUFBUyxTQUFTLFlBQVE7QUFBQyxZQUFHLEVBQUUsa0JBQWtCLE1BQU0sTUFBTTtBQUM1RCxjQUFNLE1BQUksQ0FBQyxXQUF3QjtBQUNqQyxnQkFBTSxXQUFTLEtBQUssU0FBUyxRQUFPLFFBQVE7QUFDNUMsY0FBRyxPQUFPLFNBQU8sZUFBZSxXQUFXLFNBQVMsQ0FBQyxTQUF3QyxNQUFNLElBQUksU0FBTyxTQUFTO0FBQ3ZILGNBQUcsY0FBYTtBQUFDLHFCQUFTLGNBQVk7QUFBSyxxQkFBUyxVQUFRO0FBQUEsVUFBSTtBQUdoRSxjQUFHLGNBQWMsT0FBTyxLQUFLLFdBQVcsaUJBQWlCLEdBQUU7QUFBQyxxQkFBUyxjQUFZO0FBQUsscUJBQVMsVUFBUTtBQUFJLHFCQUFTLGFBQVc7QUFBQSxVQUFNO0FBQ3JJLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGNBQU0sV0FBUyxLQUFLLFNBQVMsT0FBTyxVQUFTLFVBQVUsR0FBRSxhQUFXLE9BQU8sT0FBTyxTQUFTLGVBQWUsRUFBRSxDQUFDLEdBQUcsVUFBUTtBQUN4SCxjQUFNLEtBQUssRUFBQyxNQUFLLE9BQU8sTUFBSyxVQUFTLFVBQVMsTUFBTSxRQUFRLE9BQU8sUUFBUSxJQUFFLE9BQU8sU0FBUyxJQUFJLEdBQUcsSUFBRSxJQUFJLE9BQU8sUUFBUSxHQUFFLE9BQU0sT0FBTyxZQUFZLE1BQU0sR0FBRSxPQUFNLE1BQU0sS0FBSyxFQUFDLFFBQU8sV0FBVSxHQUFFLENBQUMsR0FBRSxNQUFJLE9BQU8sd0JBQXdCLENBQUMsS0FBRyxDQUFDLEVBQUMsQ0FBQztBQUFBLE1BQ2pQLENBQUM7QUFDRCxjQUFNLEVBQUMsT0FBTSxRQUFPLENBQUMsR0FBRSxVQUFTLENBQUMsR0FBRSxZQUFXLENBQUMsR0FBRSxLQUFJLENBQUMsR0FBRSxVQUFTLEdBQUUsTUFBSyxLQUFLLE9BQU0sWUFBVyxTQUFRO0FBQUUsV0FBSyxRQUFRLElBQUksS0FBSSxLQUFLO0FBQUEsSUFDcEk7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNO0FBQUUsVUFBTSxXQUFXLEtBQUssU0FBUztBQUFFLFVBQU0sSUFBSSxLQUFLLEVBQUU7QUFBRSxVQUFNLE9BQUssS0FBSztBQUFBLEVBQ2xHO0FBQUEsRUFDQSxTQUFRO0FBQ04sZUFBVSxDQUFDLEtBQUksS0FBSyxLQUFLLEtBQUssU0FBUTtBQUNwQyxVQUFHLENBQUMsTUFBTSxTQUFTLFFBQU87QUFDeEIsbUJBQVUsUUFBUSxNQUFNLFFBQU87QUFBQyxlQUFLLFFBQU07QUFBRSxlQUFLLFVBQVE7QUFBQSxRQUFNO0FBQ2hFLFlBQUcsS0FBSyxRQUFNLE1BQU0sT0FBSyxJQUFJLE1BQUssT0FBTyxLQUFJLEtBQUs7QUFDbEQ7QUFBQSxNQUNGO0FBQ0EsVUFBRyxNQUFNLFNBQVMsU0FBTyxNQUFNLFVBQVM7QUFDdEMsbUJBQVUsUUFBUSxNQUFNLFFBQU87QUFBQyxlQUFLLE1BQU0sT0FBTyxJQUFJO0FBQUUsZUFBSyxRQUFRO0FBQUEsUUFBRTtBQUN2RSxjQUFNLFdBQVMsS0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxHQUFFLE1BQU0sU0FBUyxNQUFNLENBQUMsQ0FBQztBQUN4RSxjQUFNLFNBQU8sTUFBTSxNQUFNLElBQUksVUFBTTtBQUFDLGdCQUFNLE9BQUssS0FBSyxNQUFNLFNBQU8sSUFBSSxtQkFBbUIsTUFBSyxNQUFNLFFBQVEsSUFBRSxJQUFJLE1BQU0sY0FBYyxLQUFLLFVBQVMsS0FBSyxVQUFTLE1BQU0sUUFBUTtBQUFFLGVBQUssT0FBSyxLQUFLO0FBQUssZUFBSyxhQUFXO0FBQUssZUFBSyxnQkFBYztBQUFLLGVBQUssZUFBZSxTQUFTLE1BQU0sZ0JBQWdCO0FBQUUsZUFBSyxTQUFTLE1BQUksTUFBTTtBQUFJLGVBQUssTUFBTSxJQUFJLElBQUk7QUFBRSxpQkFBTztBQUFBLFFBQUssQ0FBQztBQUFBLE1BQ3ZXO0FBQ0EsZUFBUSxJQUFFLEdBQUUsSUFBRSxNQUFNLE9BQU8sUUFBTyxLQUFJO0FBQ3BDLGNBQU0sT0FBSyxNQUFNLE9BQU8sQ0FBQyxHQUFHLE9BQUssTUFBTSxNQUFNLENBQUM7QUFBRyxhQUFLLFFBQU0sTUFBTSxTQUFTO0FBQU8sYUFBSyxVQUFRLEtBQUssUUFBTTtBQUFFLGFBQUssU0FBUyxNQUFJLE1BQU07QUFDcEksaUJBQVEsSUFBRSxHQUFFLElBQUUsS0FBSyxPQUFNLEtBQUk7QUFDM0IsZ0JBQU0sWUFBVSxNQUFNLFdBQVcsQ0FBQyxHQUFHLElBQUksS0FBSyxJQUFJO0FBQ2xELGVBQUssWUFBWSxHQUFFLEtBQUssT0FBTyxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUUsRUFBRSxTQUFTLFdBQVcsVUFBUSxLQUFLLEtBQUssQ0FBQztBQUMvRixjQUFHLGdCQUFnQixtQkFBbUIsTUFBSyxVQUFVLEdBQUUsV0FBVyxTQUFPLEtBQUssS0FBSztBQUFBLFFBQ3JGO0FBQ0EsYUFBSyxlQUFlLGNBQVk7QUFBSyxZQUFHLEtBQUssYUFBYSxNQUFLLGFBQWEsY0FBWTtBQUFLLFlBQUcsS0FBSyxNQUFNLE1BQUssc0JBQXNCO0FBQUEsTUFDeEk7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBUztBQUFDLFdBQU8sQ0FBQyxHQUFHLEtBQUssUUFBUSxPQUFPLENBQUMsRUFBRSxRQUFRLFdBQU8sTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFNLEtBQUssT0FBTztBQUFBLEVBQUU7QUFBQSxFQUNwRyxPQUFPLEtBQVc7QUFBQyxVQUFNLFFBQU0sS0FBSyxRQUFRLElBQUksR0FBRztBQUFFLFFBQUcsTUFBTSxNQUFLLE9BQU8sS0FBSSxLQUFLO0FBQUEsRUFBRTtBQUFBLEVBQ3JGLE9BQU8sS0FBVyxPQUFZO0FBQzVCLGVBQVUsUUFBUSxNQUFNLFFBQU87QUFBQyxXQUFLLE1BQU0sT0FBTyxJQUFJO0FBQUUsV0FBSyxRQUFRO0FBQUEsSUFBRTtBQUN2RSxlQUFVLFFBQVEsTUFBTSxNQUFNLFlBQVUsT0FBTyxNQUFNLFFBQVEsS0FBSyxRQUFRLElBQUUsS0FBSyxXQUFTLENBQUMsS0FBSyxRQUFRLEVBQUUsS0FBSSxRQUFRO0FBQ3RILGVBQVUsVUFBVSxNQUFNLFlBQVc7QUFBQyxZQUFNLFdBQVMsS0FBSyxXQUFXLElBQUksTUFBTTtBQUFHLFVBQUcsRUFBRSxTQUFTLFNBQU8sR0FBRTtBQUFDLGlCQUFTLEtBQUssUUFBUTtBQUFFLGFBQUssV0FBVyxPQUFPLE1BQU07QUFBQSxNQUFFO0FBQUEsSUFBQztBQUNsSyxlQUFVLFVBQVUsTUFBTSxVQUFTO0FBQUMsWUFBTSxXQUFTLEtBQUssU0FBUyxJQUFJLE1BQU07QUFBRyxVQUFHLEVBQUUsU0FBUyxTQUFPLEdBQUU7QUFBQyxpQkFBUyxLQUFLLFFBQVE7QUFBRSxhQUFLLFNBQVMsT0FBTyxNQUFNO0FBQUEsTUFBRTtBQUFBLElBQUM7QUFDNUosU0FBSyxRQUFRLE9BQU8sR0FBRztBQUFBLEVBQ3pCO0FBQUEsRUFDQSxVQUFTO0FBQUMsZUFBVSxDQUFDLEtBQUksS0FBSyxLQUFLLEtBQUssUUFBUSxNQUFLLE9BQU8sS0FBSSxLQUFLO0FBQUEsRUFBRTtBQUN6RTsiLCJuYW1lcyI6W119