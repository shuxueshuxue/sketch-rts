import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
const HEIGHT = Math.tan(SHIP_CAMERA.tilt);
export function drawCombatGround(ctx, frame, projection, elevated = false) {
  ctx.save();
  for (const stain of frame.ground) {
    if (stain.height > 0 !== elevated) continue;
    const point = projection.worldToScreen({ x: stain.x, y: stain.y - stain.height * HEIGHT });
    if (!projection.nearScreen(point, stain.radius * 3)) continue;
    ctx.globalAlpha = stain.alpha * 0.72;
    ctx.fillStyle = "#713a32";
    ctx.beginPath();
    ctx.ellipse(point.x, point.y, stain.radius, stain.radius * 0.48, stain.angle, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = stain.alpha * 0.32;
    ctx.fillStyle = "#9d5140";
    ctx.beginPath();
    ctx.ellipse(point.x + stain.radius * 0.52, point.y - stain.radius * 0.12, stain.radius * 0.37, stain.radius * 0.23, stain.angle + 0.7, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
export function drawCombatBody(ctx, marks, point, facing) {
  if (!marks.length) return;
  ctx.save();
  ctx.fillStyle = "#883e34";
  for (const mark of marks) {
    ctx.globalAlpha = mark.alpha * 0.77;
    const x = point.x + facing * mark.localX, y = point.y + mark.localY;
    ctx.beginPath();
    ctx.ellipse(x, y, mark.width ?? mark.radius * 0.65, mark.radius, mark.angle * facing, 0, Math.PI * 2);
    ctx.fill();
    if (mark.surface === "weapon") continue;
    ctx.globalAlpha = mark.alpha * 0.36;
    ctx.fillStyle = "#542f2b";
    ctx.beginPath();
    ctx.ellipse(x, y + mark.radius * 0.7, mark.radius * 0.25, mark.radius * 0.62, mark.angle * facing, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#883e34";
  }
  ctx.restore();
}
export function drawCombatAir(ctx, frame, projection, anchor, reducedMotion = false) {
  ctx.save();
  ctx.lineCap = "round";
  if (!reducedMotion) for (const line of frame.speedLines) {
    const attached = anchor?.(line.unitId, line.height, line);
    if (attached === null) continue;
    const point = attached ?? projection.worldToScreen({ x: line.x, y: line.y - line.height * HEIGHT });
    if (!projection.nearScreen(point, line.length + 24)) continue;
    const origin = projection.worldToScreen({ x: 0, y: 0 }), tip = projection.worldToScreen({ x: line.dx, y: line.dy });
    const d = Math.hypot(tip.x - origin.x, tip.y - origin.y) || 1, dx = (tip.x - origin.x) / d, dy = (tip.y - origin.y) / d;
    const nx = -dy, ny = dx;
    ctx.globalAlpha = line.alpha * 0.58;
    ctx.strokeStyle = "#514b40";
    ctx.lineWidth = line.width;
    const back = 8, length = line.length;
    ctx.beginPath();
    ctx.moveTo(point.x - dx * back, point.y - dy * back);
    ctx.quadraticCurveTo(point.x - dx * (back + length * 0.5) + nx, point.y - dy * (back + length * 0.5) + ny, point.x - dx * (back + length), point.y - dy * (back + length));
    ctx.stroke();
  }
  for (const drop of frame.droplets) {
    const point = projection.worldToScreen({ x: drop.x, y: drop.y - drop.height * HEIGHT });
    if (!projection.nearScreen(point, 12)) continue;
    const angle = Math.atan2(drop.vy - drop.vz * HEIGHT, drop.vx), speed = Math.hypot(drop.vx, drop.vy - drop.vz * HEIGHT);
    ctx.globalAlpha = drop.alpha * 0.82;
    ctx.fillStyle = "#9b4436";
    ctx.beginPath();
    ctx.ellipse(point.x, point.y, drop.radius * (reducedMotion ? 1 : 1 + Math.min(0.85, speed / 180)), drop.radius * 0.7, angle, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbWJhdC1lZmZlY3RzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBTbWFsbCB3b3JsZC1zcGFjZSBpbmsgYWNjZW50czsgbm8gdW5pdCB0ZXh0dXJlIHZhcmlhbnRzIG9yIHNpbXVsYXRpb24gd3JpdGVzLiAqL1xuaW1wb3J0IHsgU0hJUF9DQU1FUkEgfSBmcm9tICcuLi8uLi9zaGFyZWQvc2hpcC1nZW9tZXRyeSc7XG5pbXBvcnQgdHlwZSB7IENvbWJhdFByZXNlbnRhdGlvbkZyYW1lIH0gZnJvbSAnLi4vY29tYmF0LXByZXNlbnRhdGlvbic7XG5cbnR5cGUgUG9pbnQ9e3g6bnVtYmVyO3k6bnVtYmVyfTtcbnR5cGUgQnJ1c2g9Q2FudmFzUmVuZGVyaW5nQ29udGV4dDJEO1xudHlwZSBQcm9qZWN0aW9uPXt3b3JsZFRvU2NyZWVuOihwb2ludDpQb2ludCk9PlBvaW50O25lYXJTY3JlZW46KHBvaW50OlBvaW50LHBhZDpudW1iZXIpPT5ib29sZWFufTtcbmNvbnN0IEhFSUdIVD1NYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KTtcblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdDb21iYXRHcm91bmQoY3R4OkJydXNoLGZyYW1lOkNvbWJhdFByZXNlbnRhdGlvbkZyYW1lLHByb2plY3Rpb246UHJvamVjdGlvbixlbGV2YXRlZD1mYWxzZSl7XG4gIGN0eC5zYXZlKCk7XG4gIGZvcihjb25zdCBzdGFpbiBvZiBmcmFtZS5ncm91bmQpe1xuICAgIGlmKChzdGFpbi5oZWlnaHQ+MCkhPT1lbGV2YXRlZCljb250aW51ZTtcbiAgICBjb25zdCBwb2ludD1wcm9qZWN0aW9uLndvcmxkVG9TY3JlZW4oe3g6c3RhaW4ueCx5OnN0YWluLnktc3RhaW4uaGVpZ2h0KkhFSUdIVH0pO1xuICAgIGlmKCFwcm9qZWN0aW9uLm5lYXJTY3JlZW4ocG9pbnQsc3RhaW4ucmFkaXVzKjMpKWNvbnRpbnVlO1xuICAgIGN0eC5nbG9iYWxBbHBoYT1zdGFpbi5hbHBoYSouNzI7Y3R4LmZpbGxTdHlsZT0nIzcxM2EzMic7XG4gICAgY3R4LmJlZ2luUGF0aCgpO2N0eC5lbGxpcHNlKHBvaW50LngscG9pbnQueSxzdGFpbi5yYWRpdXMsc3RhaW4ucmFkaXVzKi40OCxzdGFpbi5hbmdsZSwwLE1hdGguUEkqMik7Y3R4LmZpbGwoKTtcbiAgICAvLyBVbmV2ZW4gZHJ5IGVkZ2UgZ2l2ZXMgYSBsaXR0bGUgdG9ybi1wYXBlciB0ZXh0dXJlIHdpdGhvdXQgYSBsYXJnZSBkZWNhbC5cbiAgICBjdHguZ2xvYmFsQWxwaGE9c3RhaW4uYWxwaGEqLjMyO2N0eC5maWxsU3R5bGU9JyM5ZDUxNDAnO1xuICAgIGN0eC5iZWdpblBhdGgoKTtjdHguZWxsaXBzZShwb2ludC54K3N0YWluLnJhZGl1cyouNTIscG9pbnQueS1zdGFpbi5yYWRpdXMqLjEyLHN0YWluLnJhZGl1cyouMzcsc3RhaW4ucmFkaXVzKi4yMyxzdGFpbi5hbmdsZSsuNywwLE1hdGguUEkqMik7Y3R4LmZpbGwoKTtcbiAgfVxuICBjdHgucmVzdG9yZSgpO1xufVxuXG4vKiogQ2FsbGVkIGJlc2lkZSB0aGUgdW5pdCBwYWludGVyLCBzbyBtYXJrcyBmb2xsb3cgaXRzIGFjdHVhbCBkZWNrL2JyaWRnZSBhbmNob3IuICovXG5leHBvcnQgZnVuY3Rpb24gZHJhd0NvbWJhdEJvZHkoY3R4OkJydXNoLG1hcmtzOkNvbWJhdFByZXNlbnRhdGlvbkZyYW1lWydib2R5J10scG9pbnQ6UG9pbnQsZmFjaW5nOjF8LTEpe1xuICBpZighbWFya3MubGVuZ3RoKXJldHVybjtcbiAgY3R4LnNhdmUoKTtjdHguZmlsbFN0eWxlPScjODgzZTM0JztcbiAgZm9yKGNvbnN0IG1hcmsgb2YgbWFya3Mpe1xuICAgIGN0eC5nbG9iYWxBbHBoYT1tYXJrLmFscGhhKi43NztcbiAgICBjb25zdCB4PXBvaW50LngrZmFjaW5nKm1hcmsubG9jYWxYLHk9cG9pbnQueSttYXJrLmxvY2FsWTtcbiAgICBjdHguYmVnaW5QYXRoKCk7Y3R4LmVsbGlwc2UoeCx5LG1hcmsud2lkdGg/P21hcmsucmFkaXVzKi42NSxtYXJrLnJhZGl1cyxtYXJrLmFuZ2xlKmZhY2luZywwLE1hdGguUEkqMik7Y3R4LmZpbGwoKTtcbiAgICBpZihtYXJrLnN1cmZhY2U9PT0nd2VhcG9uJyljb250aW51ZTtcbiAgICBjdHguZ2xvYmFsQWxwaGE9bWFyay5hbHBoYSouMzY7Y3R4LmZpbGxTdHlsZT0nIzU0MmYyYic7XG4gICAgY3R4LmJlZ2luUGF0aCgpO2N0eC5lbGxpcHNlKHgseSttYXJrLnJhZGl1cyouNyxtYXJrLnJhZGl1cyouMjUsbWFyay5yYWRpdXMqLjYyLG1hcmsuYW5nbGUqZmFjaW5nLDAsTWF0aC5QSSoyKTtjdHguZmlsbCgpO2N0eC5maWxsU3R5bGU9JyM4ODNlMzQnO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkcmF3Q29tYmF0QWlyKGN0eDpCcnVzaCxmcmFtZTpDb21iYXRQcmVzZW50YXRpb25GcmFtZSxwcm9qZWN0aW9uOlByb2plY3Rpb24sXG4gIGFuY2hvcj86KHVuaXRJZDpzdHJpbmcsaGVpZ2h0Om51bWJlcixwb3NpdGlvbjpQb2ludCk9PlBvaW50fG51bGx8dW5kZWZpbmVkLHJlZHVjZWRNb3Rpb249ZmFsc2Upe1xuICBjdHguc2F2ZSgpO2N0eC5saW5lQ2FwPSdyb3VuZCc7XG4gIGlmKCFyZWR1Y2VkTW90aW9uKWZvcihjb25zdCBsaW5lIG9mIGZyYW1lLnNwZWVkTGluZXMpe1xuICAgIGNvbnN0IGF0dGFjaGVkPWFuY2hvcj8uKGxpbmUudW5pdElkLGxpbmUuaGVpZ2h0LGxpbmUpO1xuICAgIGlmKGF0dGFjaGVkPT09bnVsbCljb250aW51ZTtcbiAgICBjb25zdCBwb2ludD1hdHRhY2hlZD8/cHJvamVjdGlvbi53b3JsZFRvU2NyZWVuKHt4OmxpbmUueCx5OmxpbmUueS1saW5lLmhlaWdodCpIRUlHSFR9KTtcbiAgICBpZighcHJvamVjdGlvbi5uZWFyU2NyZWVuKHBvaW50LGxpbmUubGVuZ3RoKzI0KSljb250aW51ZTtcbiAgICAvLyBQcm9qZWN0IHRoZSBhY3R1YWwgdHJhdmVsIHZlY3RvcjogZGlhZ29uYWwvdXB3YXJkIGNoYXJnZXMgbmV2ZXIgZ2V0IGEgaG9yaXpvbnRhbCBkZWNhbC5cbiAgICBjb25zdCBvcmlnaW49cHJvamVjdGlvbi53b3JsZFRvU2NyZWVuKHt4OjAseTowfSksdGlwPXByb2plY3Rpb24ud29ybGRUb1NjcmVlbih7eDpsaW5lLmR4LHk6bGluZS5keX0pO1xuICAgIGNvbnN0IGQ9TWF0aC5oeXBvdCh0aXAueC1vcmlnaW4ueCx0aXAueS1vcmlnaW4ueSl8fDEsZHg9KHRpcC54LW9yaWdpbi54KS9kLGR5PSh0aXAueS1vcmlnaW4ueSkvZDtcbiAgICBjb25zdCBueD0tZHksbnk9ZHg7XG4gICAgY3R4Lmdsb2JhbEFscGhhPWxpbmUuYWxwaGEqLjU4O2N0eC5zdHJva2VTdHlsZT0nIzUxNGI0MCc7Y3R4LmxpbmVXaWR0aD1saW5lLndpZHRoO1xuICAgIGNvbnN0IGJhY2s9OCxsZW5ndGg9bGluZS5sZW5ndGg7XG4gICAgY3R4LmJlZ2luUGF0aCgpO2N0eC5tb3ZlVG8ocG9pbnQueC1keCpiYWNrLHBvaW50LnktZHkqYmFjayk7XG4gICAgY3R4LnF1YWRyYXRpY0N1cnZlVG8ocG9pbnQueC1keCooYmFjaytsZW5ndGgqLjUpK254LHBvaW50LnktZHkqKGJhY2srbGVuZ3RoKi41KStueSxwb2ludC54LWR4KihiYWNrK2xlbmd0aCkscG9pbnQueS1keSooYmFjaytsZW5ndGgpKTtjdHguc3Ryb2tlKCk7XG4gIH1cbiAgZm9yKGNvbnN0IGRyb3Agb2YgZnJhbWUuZHJvcGxldHMpe1xuICAgIGNvbnN0IHBvaW50PXByb2plY3Rpb24ud29ybGRUb1NjcmVlbih7eDpkcm9wLngseTpkcm9wLnktZHJvcC5oZWlnaHQqSEVJR0hUfSk7XG4gICAgaWYoIXByb2plY3Rpb24ubmVhclNjcmVlbihwb2ludCwxMikpY29udGludWU7XG4gICAgY29uc3QgYW5nbGU9TWF0aC5hdGFuMihkcm9wLnZ5LWRyb3AudnoqSEVJR0hULGRyb3AudngpLHNwZWVkPU1hdGguaHlwb3QoZHJvcC52eCxkcm9wLnZ5LWRyb3AudnoqSEVJR0hUKTtcbiAgICBjdHguZ2xvYmFsQWxwaGE9ZHJvcC5hbHBoYSouODI7Y3R4LmZpbGxTdHlsZT0nIzliNDQzNic7XG4gICAgY3R4LmJlZ2luUGF0aCgpO2N0eC5lbGxpcHNlKHBvaW50LngscG9pbnQueSxkcm9wLnJhZGl1cyoocmVkdWNlZE1vdGlvbj8xOjErTWF0aC5taW4oLjg1LHNwZWVkLzE4MCkpLGRyb3AucmFkaXVzKi43LGFuZ2xlLDAsTWF0aC5QSSoyKTtjdHguZmlsbCgpO1xuICB9XG4gIGN0eC5yZXN0b3JlKCk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUNBLFNBQVMsbUJBQW1CO0FBTTVCLE1BQU0sU0FBTyxLQUFLLElBQUksWUFBWSxJQUFJO0FBRS9CLGdCQUFTLGlCQUFpQixLQUFVLE9BQThCLFlBQXNCLFdBQVMsT0FBTTtBQUM1RyxNQUFJLEtBQUs7QUFDVCxhQUFVLFNBQVMsTUFBTSxRQUFPO0FBQzlCLFFBQUksTUFBTSxTQUFPLE1BQUssU0FBUztBQUMvQixVQUFNLFFBQU0sV0FBVyxjQUFjLEVBQUMsR0FBRSxNQUFNLEdBQUUsR0FBRSxNQUFNLElBQUUsTUFBTSxTQUFPLE9BQU0sQ0FBQztBQUM5RSxRQUFHLENBQUMsV0FBVyxXQUFXLE9BQU0sTUFBTSxTQUFPLENBQUMsRUFBRTtBQUNoRCxRQUFJLGNBQVksTUFBTSxRQUFNO0FBQUksUUFBSSxZQUFVO0FBQzlDLFFBQUksVUFBVTtBQUFFLFFBQUksUUFBUSxNQUFNLEdBQUUsTUFBTSxHQUFFLE1BQU0sUUFBTyxNQUFNLFNBQU8sTUFBSSxNQUFNLE9BQU0sR0FBRSxLQUFLLEtBQUcsQ0FBQztBQUFFLFFBQUksS0FBSztBQUU1RyxRQUFJLGNBQVksTUFBTSxRQUFNO0FBQUksUUFBSSxZQUFVO0FBQzlDLFFBQUksVUFBVTtBQUFFLFFBQUksUUFBUSxNQUFNLElBQUUsTUFBTSxTQUFPLE1BQUksTUFBTSxJQUFFLE1BQU0sU0FBTyxNQUFJLE1BQU0sU0FBTyxNQUFJLE1BQU0sU0FBTyxNQUFJLE1BQU0sUUFBTSxLQUFHLEdBQUUsS0FBSyxLQUFHLENBQUM7QUFBRSxRQUFJLEtBQUs7QUFBQSxFQUN2SjtBQUNBLE1BQUksUUFBUTtBQUNkO0FBR08sZ0JBQVMsZUFBZSxLQUFVLE9BQXNDLE9BQVksUUFBWTtBQUNyRyxNQUFHLENBQUMsTUFBTSxPQUFPO0FBQ2pCLE1BQUksS0FBSztBQUFFLE1BQUksWUFBVTtBQUN6QixhQUFVLFFBQVEsT0FBTTtBQUN0QixRQUFJLGNBQVksS0FBSyxRQUFNO0FBQzNCLFVBQU0sSUFBRSxNQUFNLElBQUUsU0FBTyxLQUFLLFFBQU8sSUFBRSxNQUFNLElBQUUsS0FBSztBQUNsRCxRQUFJLFVBQVU7QUFBRSxRQUFJLFFBQVEsR0FBRSxHQUFFLEtBQUssU0FBTyxLQUFLLFNBQU8sTUFBSSxLQUFLLFFBQU8sS0FBSyxRQUFNLFFBQU8sR0FBRSxLQUFLLEtBQUcsQ0FBQztBQUFFLFFBQUksS0FBSztBQUNoSCxRQUFHLEtBQUssWUFBVSxTQUFTO0FBQzNCLFFBQUksY0FBWSxLQUFLLFFBQU07QUFBSSxRQUFJLFlBQVU7QUFDN0MsUUFBSSxVQUFVO0FBQUUsUUFBSSxRQUFRLEdBQUUsSUFBRSxLQUFLLFNBQU8sS0FBRyxLQUFLLFNBQU8sTUFBSSxLQUFLLFNBQU8sTUFBSSxLQUFLLFFBQU0sUUFBTyxHQUFFLEtBQUssS0FBRyxDQUFDO0FBQUUsUUFBSSxLQUFLO0FBQUUsUUFBSSxZQUFVO0FBQUEsRUFDekk7QUFDQSxNQUFJLFFBQVE7QUFDZDtBQUVPLGdCQUFTLGNBQWMsS0FBVSxPQUE4QixZQUNwRSxRQUEyRSxnQkFBYyxPQUFNO0FBQy9GLE1BQUksS0FBSztBQUFFLE1BQUksVUFBUTtBQUN2QixNQUFHLENBQUMsY0FBYyxZQUFVLFFBQVEsTUFBTSxZQUFXO0FBQ25ELFVBQU0sV0FBUyxTQUFTLEtBQUssUUFBTyxLQUFLLFFBQU8sSUFBSTtBQUNwRCxRQUFHLGFBQVcsS0FBSztBQUNuQixVQUFNLFFBQU0sWUFBVSxXQUFXLGNBQWMsRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssSUFBRSxLQUFLLFNBQU8sT0FBTSxDQUFDO0FBQ3JGLFFBQUcsQ0FBQyxXQUFXLFdBQVcsT0FBTSxLQUFLLFNBQU8sRUFBRSxFQUFFO0FBRWhELFVBQU0sU0FBTyxXQUFXLGNBQWMsRUFBQyxHQUFFLEdBQUUsR0FBRSxFQUFDLENBQUMsR0FBRSxNQUFJLFdBQVcsY0FBYyxFQUFDLEdBQUUsS0FBSyxJQUFHLEdBQUUsS0FBSyxHQUFFLENBQUM7QUFDbkcsVUFBTSxJQUFFLEtBQUssTUFBTSxJQUFJLElBQUUsT0FBTyxHQUFFLElBQUksSUFBRSxPQUFPLENBQUMsS0FBRyxHQUFFLE1BQUksSUFBSSxJQUFFLE9BQU8sS0FBRyxHQUFFLE1BQUksSUFBSSxJQUFFLE9BQU8sS0FBRztBQUMvRixVQUFNLEtBQUcsQ0FBQyxJQUFHLEtBQUc7QUFDaEIsUUFBSSxjQUFZLEtBQUssUUFBTTtBQUFJLFFBQUksY0FBWTtBQUFVLFFBQUksWUFBVSxLQUFLO0FBQzVFLFVBQU0sT0FBSyxHQUFFLFNBQU8sS0FBSztBQUN6QixRQUFJLFVBQVU7QUFBRSxRQUFJLE9BQU8sTUFBTSxJQUFFLEtBQUcsTUFBSyxNQUFNLElBQUUsS0FBRyxJQUFJO0FBQzFELFFBQUksaUJBQWlCLE1BQU0sSUFBRSxNQUFJLE9BQUssU0FBTyxPQUFJLElBQUcsTUFBTSxJQUFFLE1BQUksT0FBSyxTQUFPLE9BQUksSUFBRyxNQUFNLElBQUUsTUFBSSxPQUFLLFNBQVEsTUFBTSxJQUFFLE1BQUksT0FBSyxPQUFPO0FBQUUsUUFBSSxPQUFPO0FBQUEsRUFDbko7QUFDQSxhQUFVLFFBQVEsTUFBTSxVQUFTO0FBQy9CLFVBQU0sUUFBTSxXQUFXLGNBQWMsRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssSUFBRSxLQUFLLFNBQU8sT0FBTSxDQUFDO0FBQzNFLFFBQUcsQ0FBQyxXQUFXLFdBQVcsT0FBTSxFQUFFLEVBQUU7QUFDcEMsVUFBTSxRQUFNLEtBQUssTUFBTSxLQUFLLEtBQUcsS0FBSyxLQUFHLFFBQU8sS0FBSyxFQUFFLEdBQUUsUUFBTSxLQUFLLE1BQU0sS0FBSyxJQUFHLEtBQUssS0FBRyxLQUFLLEtBQUcsTUFBTTtBQUN0RyxRQUFJLGNBQVksS0FBSyxRQUFNO0FBQUksUUFBSSxZQUFVO0FBQzdDLFFBQUksVUFBVTtBQUFFLFFBQUksUUFBUSxNQUFNLEdBQUUsTUFBTSxHQUFFLEtBQUssVUFBUSxnQkFBYyxJQUFFLElBQUUsS0FBSyxJQUFJLE1BQUksUUFBTSxHQUFHLElBQUcsS0FBSyxTQUFPLEtBQUcsT0FBTSxHQUFFLEtBQUssS0FBRyxDQUFDO0FBQUUsUUFBSSxLQUFLO0FBQUEsRUFDako7QUFDQSxNQUFJLFFBQVE7QUFDZDsiLCJuYW1lcyI6W119