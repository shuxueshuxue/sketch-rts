import { CardRasterCache } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-raster-cache.ts";
import { packCardPickMask, cardMaskHit } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-pick-mask.ts";
import { CardMipUploader, createCardArray, cardTextureBytes } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-mip-uploader.ts";
import { ART_TILE_SIZE } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/raster-cache.ts";
import { configureCardMaterial, MAX_CARD_BANKS } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-bank-shader.ts";
export { patchCardBankShader as patchCardShader } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-bank-shader.ts";
import * as THREE from "/.vite-cache/deps/three.js?v=a6750e53";
import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
export const DEFAULT_CARD_BANKS = 1;
const LAYERS = 16, PIXEL_BUDGET = 12 * 1024 * 1024, TILT = Math.tan(SHIP_CAMERA.tilt);
export class PaintedCardBatches {
  constructor(scene, anisotropy, policy = {}) {
    this.scene = scene;
    this.anisotropy = anisotropy;
    this.policy = policy;
    this.maxTextureBanks = policy.maxTextureBanks ?? DEFAULT_CARD_BANKS;
    if (!Number.isInteger(this.maxTextureBanks) || this.maxTextureBanks < 1 || this.maxTextureBanks > MAX_CARD_BANKS) throw new Error("Invalid painted card bank count.");
    this.drawGroup.name = "PaintedCardDraws";
    this.mipUploader = new CardMipUploader(anisotropy);
  }
  pages = [];
  allocatedPixels = 0;
  cards = /* @__PURE__ */ new Map();
  frame = 0;
  instanceOrder = 0;
  // Reuse instance records, indexed by submission order. Warm hits and pending
  // uploads fill the same sequence, irrespective of raster completion order.
  instances = [];
  bindings = /* @__PURE__ */ new Map();
  chunks = [];
  drawGroup = new THREE.Group();
  maxTextureBanks;
  pending = [];
  rasterizations = 0;
  copiedLayers = 0;
  matrix = new THREE.Matrix4();
  offset = new THREE.Matrix4();
  rayProbe = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }));
  raySphere = new THREE.Sphere();
  rayHits = [];
  canvases = /* @__PURE__ */ new Map();
  mipUploader;
  rowScratch = new Uint8Array(0);
  emptyRgba = new Uint8Array(0);
  maskBytes = 0;
  pendingRgbaBytes = 0;
  pendingMaskBytes = 0;
  peakPendingRgbaBytes = 0;
  peakOwnedCpuBytes = 0;
  peakOwnedGpuBytes = 0;
  peakRetiredGpuBytes = 0;
  retiring = /* @__PURE__ */ new Set();
  rasterWorkWallMs = 0;
  rasterCache = new CardRasterCache();
  rasterStages = { paintMs: 0, readbackMs: 0, cacheMs: 0, pickMaskMs: 0, rowFlipMs: 0, slotMs: 0 };
  begin() {
    this.frame++;
    this.instanceOrder = 0;
    this.pending.length = 0;
    this.bindings.clear();
    for (const row of this.instances) if (row) {
      row.card = void 0;
      row.id = "";
    }
    for (const chunk of this.chunks) this.hideChunk(chunk);
  }
  createPage(width, height, layers = LAYERS) {
    const page = { texture: createCardArray(width, height, layers, this.anisotropy), mipBytes: cardTextureBytes(width, height, layers), uploaded: false, cards: new Array(layers), used: this.frame };
    this.pages.push(page);
    this.allocatedPixels += width * height * layers;
    return page;
  }
  slot(width, height, pendingLayers, empty = false) {
    let oldest;
    for (const page of this.pages) {
      if (page.texture.image.width !== width || page.texture.image.height !== height) continue;
      for (let layer = 0; layer < page.texture.image.depth; layer++) {
        const card = page.cards[layer];
        if (!card) return { page, layer };
        if (card.used !== this.frame && (!oldest || card.used < oldest.used)) oldest = card;
      }
    }
    const remainingLayers = Math.floor((PIXEL_BUDGET - this.allocatedPixels) / (width * height));
    if (oldest && remainingLayers < 1) {
      this.cards.delete(oldest.key);
      this.maskBytes -= oldest.mask.byteLength;
      oldest.page.cards[oldest.layer] = void 0;
      return { page: oldest.page, layer: oldest.layer };
    }
    const layers = empty ? remainingLayers > 0 ? Math.min(LAYERS, remainingLayers) : 1 : Math.min(LAYERS, Math.max(1, pendingLayers), remainingLayers > 0 ? remainingLayers : LAYERS);
    return { page: this.createPage(width, height, layers), layer: 0 };
  }
  add(key, density, paint, matrix, id, foot, tileSize = ART_TILE_SIZE, opacity = 1, baseMip = 0) {
    const size = tileSize * density, factor = 2 ** baseMip;
    if (!Number.isInteger(baseMip) || baseMip < 0 || baseMip > 0 && (!Number.isInteger(size) || size < 1 || size % factor !== 0)) throw new Error("Invalid painted card resident mip.");
    key = `${key}:${density}:${tileSize}`;
    const order = this.instanceOrder++, card = this.cards.get(key);
    if (card) {
      card.used = card.page.used = this.frame;
      if (card.baseMip <= baseMip) {
        this.instance(card, matrix, id, foot, opacity, order);
        return;
      }
    }
    this.pending.push({ key, density, paint, matrix, id, foot, tileSize, opacity, baseMip, order });
  }
  instance(card, matrix, id, foot, opacity, order) {
    card.used = card.page.used = this.frame;
    let row = this.instances[order];
    if (!row) {
      row = { card, matrix, id, foot, opacity: 0, order };
      this.instances[order] = row;
    } else {
      row.card = card;
      row.matrix = matrix;
      row.id = id;
      row.foot = foot;
      row.order = order;
    }
    row.opacity = Math.max(0, Math.min(1, opacity));
    let bindings = this.bindings.get(card);
    if (!bindings) {
      bindings = [];
      this.bindings.set(card, bindings);
    }
    bindings.push(row);
  }
  /** Publish a successful promotion or compaction without changing submission
   * order, source geometry, matrices or alpha-mask identity. */
  rebind(previous, current) {
    const rows = this.bindings.get(previous);
    if (!rows) return;
    let target = this.bindings.get(current);
    if (!target) {
      target = [];
      this.bindings.set(current, target);
    }
    for (const row of rows) {
      row.card = current;
      target.push(row);
    }
    this.bindings.delete(previous);
  }
  raster({ key, density, paint, matrix, id, foot, tileSize, opacity, order }, renderer, baseMip, pendingLayers) {
    let card = this.cards.get(key);
    if (!card || card.baseMip > baseMip) {
      const previous = card;
      const start = performance.now(), size = tileSize * density;
      const cacheStart = performance.now();
      let rgba = this.rasterCache.get(key);
      this.rasterStages.cacheMs += performance.now() - cacheStart;
      const fromCache = !!rgba;
      let paintMs = 0;
      if (!rgba) {
        const paintStart = performance.now();
        let canvas = this.canvases.get(size);
        if (!canvas) {
          canvas = document.createElement("canvas");
          canvas.width = canvas.height = size;
          this.canvases.set(size, canvas);
        }
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        ctx.resetTransform();
        ctx.clearRect(0, 0, size, size);
        ctx.save();
        ctx.scale(density, density);
        ctx.translate(tileSize / 2, tileSize / 2);
        try {
          paint(ctx);
        } finally {
          ctx.restore();
        }
        const paintedAt = performance.now();
        this.rasterStages.paintMs += paintedAt - paintStart;
        rgba = ctx.getImageData(0, 0, size, size).data;
        const readAt = performance.now();
        this.rasterStages.readbackMs += readAt - paintedAt;
        paintMs = readAt - paintStart;
      }
      this.pendingRgbaBytes = rgba.byteLength;
      this.recordPeaks();
      try {
        const maskStart = performance.now(), painted = hasPaint(rgba), sourceSize = painted ? size : 16, residentMip = painted ? baseMip : 0, retainedSize = sourceSize / 2 ** residentMip;
        const mask = this.policy.pickable === false ? new Uint8Array(0) : painted ? packCardPickMask(rgba, size, size, !fromCache) : new Uint8Array(16 * 16 / 8);
        this.pendingMaskBytes = mask.byteLength;
        const flipStart = performance.now();
        this.rasterStages.pickMaskMs += flipStart - maskStart;
        if (painted && !fromCache) {
          const row = size * 4;
          if (this.rowScratch.length < row) this.rowScratch = new Uint8Array(row);
          for (let y = 0; y < Math.floor(size / 2); y++) {
            const top = y * row, bottom = (size - 1 - y) * row;
            this.rowScratch.set(rgba.subarray(top, top + row));
            rgba.copyWithin(top, bottom, bottom + row);
            rgba.set(this.rowScratch.subarray(0, row), bottom);
          }
        }
        const flippedAt = performance.now();
        this.rasterStages.rowFlipMs += flippedAt - flipStart;
        if (!fromCache) this.rasterCache.put(key, rgba, size, size, paintMs);
        const slotStart = performance.now();
        this.rasterStages.cacheMs += slotStart - flippedAt;
        const { page, layer } = this.slot(retainedSize, retainedSize, pendingLayers.get(retainedSize) ?? 1, !painted);
        this.recordPeaks();
        this.rasterStages.slotMs += performance.now() - slotStart;
        this.rasterWorkWallMs += performance.now() - start;
        if (!painted && this.emptyRgba.length === 0) this.emptyRgba = new Uint8Array(16 * 16 * 4);
        this.mipUploader.uploadLayer(page, layer, painted ? rgba : this.emptyRgba, renderer, { sourceWidth: sourceSize, sourceHeight: sourceSize, baseMip: residentMip });
        this.recordPeaks();
        card = { key, page, layer, used: this.frame, tileSize, sourceSize, baseMip: residentMip, mask };
        page.cards[layer] = card;
        this.cards.set(key, card);
        this.maskBytes += mask.byteLength;
        if (previous) {
          this.rebind(previous, card);
          previous.page.cards[previous.layer] = void 0;
          this.maskBytes -= previous.mask.byteLength;
        }
        this.rasterizations++;
        const plannedSize = size / 2 ** baseMip;
        pendingLayers.set(plannedSize, Math.max(0, (pendingLayers.get(plannedSize) ?? 1) - 1));
      } finally {
        this.pendingRgbaBytes = this.pendingMaskBytes = 0;
      }
    }
    this.instance(card, matrix, id, foot, opacity, order);
  }
  compact(renderer) {
    if (this.allocatedPixels <= PIXEL_BUDGET) return;
    const sizes = new Set(this.pages.map((page) => `${page.texture.image.width}:${page.texture.image.height}`));
    for (const size of sizes) {
      const [width, height] = size.split(":").map(Number);
      const pages = this.pages.filter((page) => page.texture.image.width === width && page.texture.image.height === height);
      const active = pages.flatMap((page) => page.cards.filter((card) => Boolean(card && card.used === this.frame)));
      let capacity = 0, needed = 0;
      for (const page of [...pages].sort((a, b) => b.texture.image.depth - a.texture.image.depth)) {
        if (capacity >= active.length) break;
        capacity += page.texture.image.depth;
        needed++;
      }
      if (!needed || needed * 2 > pages.length) continue;
      const ranked = [...pages].sort((a, b) => b.cards.filter((card) => card?.used === this.frame).length - a.cards.filter((card) => card?.used === this.frame).length || b.texture.image.depth - a.texture.image.depth);
      const destinations = ranked.slice(0, needed);
      capacity = destinations.reduce((sum, page) => sum + page.texture.image.depth, 0);
      while (capacity < active.length) {
        const smallest = [...destinations].sort((a, b) => a.texture.image.depth - b.texture.image.depth)[0];
        const replacement = pages.filter((page) => !destinations.includes(page)).sort((a, b) => b.texture.image.depth - a.texture.image.depth)[0];
        capacity += replacement.texture.image.depth - smallest.texture.image.depth;
        destinations[destinations.indexOf(smallest)] = replacement;
      }
      const kept = new Set(destinations), sources = pages.filter((page) => !kept.has(page));
      const holes = [];
      for (const page of destinations) for (let layer = 0; layer < page.texture.image.depth; layer++) if (page.cards[layer]?.used !== this.frame) holes.push({ page, layer });
      const displaced = active.filter((card) => !kept.has(card.page));
      const moved = /* @__PURE__ */ new Map(), moves = [];
      for (const [i, old] of displaced.entries()) {
        const { page, layer } = holes[i], card = { ...old, page, layer, used: this.frame };
        moved.set(old, card);
        moves.push({ source: old.page, sourceLayer: old.layer, destination: page, destinationLayer: layer });
      }
      for (const source of sources) this.retiring.add(source);
      try {
        this.mipUploader.copyLayers(moves, renderer);
        this.recordPeaks();
      } catch (error) {
        for (const card of moved.values()) {
          const previous = card.page.cards[card.layer];
          if (previous && this.cards.get(previous.key) === previous) {
            this.cards.delete(previous.key);
            this.maskBytes -= previous.mask.byteLength;
          }
          card.page.cards[card.layer] = void 0;
        }
        this.recordPeaks();
        throw error;
      } finally {
        this.retiring.clear();
      }
      for (const [old, card] of moved) {
        const previous = card.page.cards[card.layer];
        if (previous && this.cards.get(previous.key) === previous) {
          this.cards.delete(previous.key);
          this.maskBytes -= previous.mask.byteLength;
        }
        card.page.cards[card.layer] = card;
        card.page.used = this.frame;
        this.cards.set(old.key, card);
      }
      for (const [old, card] of moved) this.rebind(old, card);
      for (const old of sources) this.remove(old);
      this.copiedLayers += moves.length;
    }
  }
  /** Complete the frame in one streaming pass. Callers provide the public GPU
   * transfer contract, including CPU-only tests. No render may precede finish. */
  finish(renderer) {
    const finest = /* @__PURE__ */ new Map(), pendingLayers = /* @__PURE__ */ new Map();
    for (const request of this.pending) {
      const previous = finest.get(request.key);
      if (!previous || request.baseMip < previous.baseMip) finest.set(request.key, { baseMip: request.baseMip, size: request.tileSize * request.density / 2 ** request.baseMip });
    }
    for (const [key, request] of finest) {
      const card = this.cards.get(key);
      if (card && card.baseMip <= request.baseMip) continue;
      pendingLayers.set(request.size, (pendingLayers.get(request.size) ?? 0) + 1);
    }
    try {
      for (const request of this.pending) this.raster(request, renderer, finest.get(request.key).baseMip, pendingLayers);
    } finally {
      this.pending.length = 0;
    }
    this.compact(renderer);
    for (const page of [...this.pages]) {
      if (!page.cards.some((card) => card?.used === this.frame) && (!page.cards.some(Boolean) || this.frame - page.used > 120 || this.allocatedPixels > PIXEL_BUDGET)) this.remove(page);
    }
    this.draw();
  }
  attributes(geometry, capacity) {
    if (this.policy.transparent) geometry.setAttribute("cardOpacity", new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1).setUsage(THREE.DynamicDrawUsage));
    geometry.setAttribute("cardRect", new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage));
    geometry.setAttribute("cardLayer", new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1).setUsage(THREE.DynamicDrawUsage));
    geometry.setAttribute("cardBank", new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1).setUsage(THREE.DynamicDrawUsage));
  }
  createChunk(banks, count, index) {
    const material = new THREE.MeshBasicMaterial({ map: banks[0], alphaTest: this.policy.alphaTest ?? 0.4, side: THREE.DoubleSide, toneMapped: false, transparent: this.policy.transparent ?? false, depthWrite: this.policy.depthWrite ?? true, depthTest: true });
    const depth = new THREE.MeshDepthMaterial({ map: banks[0], alphaTest: 0.4, side: THREE.DoubleSide, depthPacking: THREE.RGBADepthPacking });
    const distance = new THREE.MeshDistanceMaterial({ map: banks[0], alphaTest: 0.4, side: THREE.DoubleSide });
    const refreshMaterials = [material, depth, distance].map((item) => configureCardMaterial(item, banks, this.maxTextureBanks, this.policy.transparent ?? false));
    const geometry = new THREE.PlaneGeometry(1, 1), capacity = 2 ** Math.ceil(Math.log2(count));
    this.attributes(geometry, capacity);
    const mesh = new THREE.InstancedMesh(geometry, material, capacity);
    const chunk = { banks, pages: [], entries: [], ids: [], feet: [], orders: [], geometry, material, depth, distance, mesh, capacity, used: this.frame, refreshMaterials };
    this.configureChunkMesh(chunk, index);
    this.chunks[index] = chunk;
    return chunk;
  }
  configureChunkMesh(chunk, index) {
    const mesh = chunk.mesh;
    mesh.name = "PaintedCards";
    mesh.castShadow = this.policy.castShadow ?? true;
    mesh.renderOrder = (this.policy.renderOrder ?? 0) + 1e-4 + 9e-4 * index / (index + 1);
    mesh.receiveShadow = true;
    mesh.customDepthMaterial = chunk.depth;
    mesh.customDistanceMaterial = chunk.distance;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.raycast = (raycaster, intersections) => this.raycast(chunk, raycaster, intersections);
    mesh.userData.ids = chunk.ids;
    mesh.userData.cards = chunk.entries;
    mesh.userData.feet = chunk.feet;
    mesh.userData.orders = chunk.orders;
    mesh.userData.banks = chunk.pages;
    mesh.userData.paintedHit = (instance, uv) => this.hit(chunk, instance, uv);
    this.drawGroup.add(mesh);
  }
  resizeChunk(chunk, count, index) {
    this.drawGroup.remove(chunk.mesh);
    chunk.mesh.dispose();
    chunk.geometry.dispose();
    chunk.capacity = 2 ** Math.ceil(Math.log2(count));
    this.attributes(chunk.geometry, chunk.capacity);
    chunk.mesh = new THREE.InstancedMesh(chunk.geometry, chunk.material, chunk.capacity);
    this.configureChunkMesh(chunk, index);
  }
  hideChunk(chunk) {
    chunk.mesh.visible = false;
    chunk.mesh.count = 0;
    chunk.entries.length = chunk.ids.length = chunk.feet.length = chunk.orders.length = chunk.pages.length = chunk.banks.length = 0;
    for (const material of [chunk.material, chunk.depth, chunk.distance]) material.map = null;
    for (const refresh of chunk.refreshMaterials) refresh();
  }
  /** Greedily retain the literal submission sequence. A ninth distinct page
   * starts a new draw; pages may recur in later draws without extra textures. */
  draw() {
    let start = 0, index = 0;
    while (start < this.instanceOrder) {
      const pageBanks = /* @__PURE__ */ new Map();
      let end = start;
      while (end < this.instanceOrder) {
        const card = this.instances[end].card;
        if (!pageBanks.has(card.page)) {
          if (pageBanks.size === this.maxTextureBanks) break;
          pageBanks.set(card.page, pageBanks.size);
        }
        end++;
      }
      let chunk = this.chunks[index];
      if (!chunk) chunk = this.createChunk([...pageBanks.keys()].map((page) => page.texture), end - start, index);
      chunk.banks.length = chunk.pages.length = 0;
      for (const page of pageBanks.keys()) {
        chunk.pages.push(page);
        chunk.banks.push(page.texture);
      }
      for (const material of [chunk.material, chunk.depth, chunk.distance]) material.map = chunk.banks[0];
      for (const refresh of chunk.refreshMaterials) refresh();
      if (end - start > chunk.capacity) this.resizeChunk(chunk, end - start, index);
      const { mesh, geometry } = chunk, layers = geometry.getAttribute("cardLayer"), rects = geometry.getAttribute("cardRect"), banks = geometry.getAttribute("cardBank");
      let radius = 0;
      chunk.entries.length = chunk.ids.length = chunk.feet.length = chunk.orders.length = 0;
      chunk.used = this.frame;
      mesh.count = end - start;
      mesh.visible = true;
      for (let order = start; order < end; order++) {
        const row = this.instances[order], card = row.card, i = order - start;
        chunk.entries.push(card);
        chunk.ids.push(row.id);
        chunk.feet.push(row.foot);
        chunk.orders.push(order);
        const half = card.tileSize / 2, low = Math.fround(Math.fround(-half / TILT) + row.foot / TILT), high = Math.fround(Math.fround(half / TILT) + row.foot / TILT);
        rects.setXYZW(i, -half, low, half, high);
        radius = Math.max(radius, Math.hypot(half, low), Math.hypot(half, high));
        mesh.setMatrixAt(i, row.matrix);
        layers.setX(i, card.layer);
        banks.setX(i, pageBanks.get(card.page));
        if (this.policy.transparent) geometry.getAttribute("cardOpacity").setX(i, row.opacity);
      }
      if (this.policy.transparent) geometry.getAttribute("cardOpacity").needsUpdate = true;
      rects.needsUpdate = layers.needsUpdate = banks.needsUpdate = mesh.instanceMatrix.needsUpdate = true;
      geometry.boundingSphere ??= new THREE.Sphere();
      geometry.boundingSphere.center.set(0, 0, 0);
      geometry.boundingSphere.radius = radius;
      mesh.computeBoundingSphere();
      start = end;
      index++;
    }
    for (let i = 0; i < this.chunks.length; i++) this.drawGroup.children[i] = this.chunks[i].mesh;
    this.drawGroup.children.length = this.chunks.length;
    if (index) {
      if (this.drawGroup.parent !== this.scene) this.scene.add(this.drawGroup);
    }
    for (let i = this.chunks.length - 1; i >= index; i--) {
      const chunk = this.chunks[i];
      this.hideChunk(chunk);
      if (!this.pages.length || this.frame - chunk.used > 120) {
        this.removeChunk(chunk);
        this.chunks.splice(i, 1);
      }
    }
    if (!this.chunks.length) this.scene.remove(this.drawGroup);
  }
  removeChunk(chunk) {
    this.hideChunk(chunk);
    this.drawGroup.remove(chunk.mesh);
    chunk.mesh.dispose();
    chunk.geometry.dispose();
    chunk.material.dispose();
    chunk.depth.dispose();
    chunk.distance.dispose();
    chunk.entries.length = chunk.ids.length = chunk.feet.length = chunk.orders.length = chunk.pages.length = chunk.banks.length = 0;
  }
  /** With no retained pixels or painter closures, restoration deliberately
   * rebuilds visible cards from the next ordinary frame's current state. */
  invalidateGPU() {
    this.dispose();
  }
  raycast(chunk, raycaster, intersections) {
    if (this.policy.pickable === false) return;
    const mesh = chunk.mesh;
    if (!mesh.boundingSphere) mesh.computeBoundingSphere();
    if (!raycaster.ray.intersectsSphere(this.raySphere.copy(mesh.boundingSphere).applyMatrix4(mesh.matrixWorld))) return;
    for (let i = 0; i < mesh.count; i++) {
      const card = chunk.entries[i], half = card.tileSize / 2, foot = chunk.feet[i];
      const low = Math.fround(Math.fround(-half / TILT) + foot / TILT), high = Math.fround(Math.fround(half / TILT) + foot / TILT);
      this.offset.makeScale(card.tileSize, high - low, 1).setPosition(0, (high + low) / 2, 0);
      mesh.getMatrixAt(i, this.matrix);
      this.rayProbe.matrixWorld.copy(mesh.matrixWorld).multiply(this.matrix).multiply(this.offset);
      this.rayHits.length = 0;
      this.rayProbe.raycast(raycaster, this.rayHits);
      for (const hit of this.rayHits) {
        hit.instanceId = i;
        hit.object = mesh;
        intersections.push(hit);
      }
    }
  }
  hit(chunk, index, uv) {
    const card = chunk.entries[index];
    if (this.policy.pickable === false || !card || !uv) return false;
    return cardMaskHit(card.mask, card.sourceSize, card.sourceSize, uv);
  }
  objects() {
    return this.chunks.filter((chunk) => chunk.mesh.visible).map((chunk) => chunk.mesh);
  }
  // Owned typed-array and texture storage estimates, not total process RSS or
  // Canvas backing stores. cpuBytes excludes scratch for existing consumers.
  stats() {
    const pixels = this.allocatedPixels, transfer = this.mipUploader.stats();
    const bytes = (page) => page.mipBytes;
    const gpuBytes = Math.ceil(pixels * 4 * 4 / 3), allocatedMipBytes = this.pages.reduce((sum, page) => sum + bytes(page), 0), retiredGpuBytes = [...this.retiring].reduce((sum, page) => sum + (page.uploaded ? bytes(page) : 0), 0);
    const drawBufferBytes = this.chunks.reduce((sum, chunk) => sum + chunk.mesh.instanceMatrix.array.byteLength + Object.values(chunk.geometry.attributes).reduce((total, attribute) => total + attribute.array.byteLength, 0) + (chunk.geometry.index?.array.byteLength ?? 0), 0);
    const cpuBytes = this.maskBytes + this.pendingMaskBytes + this.pendingRgbaBytes + this.rowScratch.byteLength + this.emptyRgba.byteLength;
    return { pages: this.pages.length, cards: this.cards.size, pixels, drawChunks: this.chunks.filter((chunk) => chunk.mesh.visible).length, pooledDrawChunks: this.chunks.length, drawCapacity: this.chunks.reduce((sum, chunk) => sum + chunk.capacity, 0), drawBufferBytes, maxTextureBanks: this.maxTextureBanks, arrayCpuBytes: 0, cpuBytes, gpuBytes, allocatedMipBytes, canvasBackingBytes: [...this.canvases.values()].reduce((sum, canvas) => sum + canvas.width * canvas.height * 4, 0), maskBytes: this.maskBytes, pendingMaskBytes: this.pendingMaskBytes, pendingRgbaBytes: this.pendingRgbaBytes, rowScratchBytes: this.rowScratch.byteLength, retiredGpuBytes, rasterCache: this.rasterCache.stats(), ownedCpuBytes: cpuBytes + transfer.scratchCpuBytes + this.rasterCache.stats().ownedBytes, ownedGpuBytes: this.pages.reduce((sum, page) => sum + (page.uploaded ? bytes(page) : 0), 0) + transfer.scratchGpuBytes, peakPendingRgbaBytes: this.peakPendingRgbaBytes, peakOwnedCpuBytes: this.peakOwnedCpuBytes, peakOwnedGpuBytes: this.peakOwnedGpuBytes, peakRetiredGpuBytes: this.peakRetiredGpuBytes, rasterizations: this.rasterizations, copiedLayers: this.copiedLayers, rasterStages: { ...this.rasterStages }, rasterWorkWallMs: this.rasterWorkWallMs, ...transfer };
  }
  recordPeaks() {
    const transfer = this.mipUploader.stats(), cpuBytes = this.maskBytes + this.pendingMaskBytes + this.pendingRgbaBytes + this.rowScratch.byteLength + this.emptyRgba.byteLength;
    const ownedCpuBytes = cpuBytes + transfer.scratchCpuBytes + this.rasterCache.stats().ownedBytes;
    let ownedGpuBytes = transfer.scratchGpuBytes, retiredGpuBytes = 0;
    for (const page of this.pages) if (page.uploaded) ownedGpuBytes += page.mipBytes;
    for (const page of this.retiring) if (page.uploaded) retiredGpuBytes += page.mipBytes;
    this.peakPendingRgbaBytes = Math.max(this.peakPendingRgbaBytes, this.pendingRgbaBytes);
    this.peakOwnedCpuBytes = Math.max(this.peakOwnedCpuBytes, ownedCpuBytes);
    this.peakOwnedGpuBytes = Math.max(this.peakOwnedGpuBytes, ownedGpuBytes);
    this.peakRetiredGpuBytes = Math.max(this.peakRetiredGpuBytes, retiredGpuBytes);
  }
  remove(page) {
    const sourceSizes = new Set(page.cards.flatMap((card) => card ? [card.sourceSize] : []));
    for (const card of page.cards) if (card && this.cards.get(card.key) === card) {
      this.cards.delete(card.key);
      this.maskBytes -= card.mask.byteLength;
    }
    page.texture.dispose();
    this.pages.splice(this.pages.indexOf(page), 1);
    this.allocatedPixels -= page.texture.image.width * page.texture.image.height * page.texture.image.depth;
    for (const size of sourceSizes) if (!this.pages.some((other) => other.cards.some((card) => card?.sourceSize === size))) this.mipUploader.releaseSize(size, size);
  }
  dispose() {
    for (const chunk of this.chunks) this.removeChunk(chunk);
    this.chunks.length = 0;
    this.scene.remove(this.drawGroup);
    this.instances.length = 0;
    this.bindings.clear();
    this.rasterCache.clear();
    for (const page of [...this.pages]) this.remove(page);
    this.retiring.clear();
    for (const canvas of this.canvases.values()) canvas.width = canvas.height = 1;
    this.canvases.clear();
    this.pending.length = 0;
    this.pendingRgbaBytes = this.pendingMaskBytes = this.maskBytes = 0;
    this.rowScratch = new Uint8Array(0);
    this.emptyRgba = new Uint8Array(0);
    this.mipUploader.dispose();
    this.rayProbe.geometry.dispose();
    this.rayProbe.material.dispose();
  }
}
function hasPaint(rgba) {
  for (let i = 3; i < rgba.length; i += 4) if (rgba[i]) return true;
  return false;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhaW50ZWQtY2FyZC1iYXRjaGVzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q2FyZFJhc3RlckNhY2hlfSBmcm9tICcuL2NhcmQtcmFzdGVyLWNhY2hlJztcbmltcG9ydCB7cGFja0NhcmRQaWNrTWFzayxjYXJkTWFza0hpdH0gZnJvbSAnLi9jYXJkLXBpY2stbWFzayc7XG5pbXBvcnQge0NhcmRNaXBVcGxvYWRlcixjcmVhdGVDYXJkQXJyYXksY2FyZFRleHR1cmVCeXRlcyx0eXBlIENhcmRNaXBNb3ZlLHR5cGUgQ2FyZFRleHR1cmVSZW5kZXJlcn0gZnJvbSAnLi9jYXJkLW1pcC11cGxvYWRlcic7XG5pbXBvcnQgeyBBUlRfVElMRV9TSVpFIH0gZnJvbSAnLi4vYXJ0L3Jhc3Rlci1jYWNoZSc7XG5pbXBvcnQge2NvbmZpZ3VyZUNhcmRNYXRlcmlhbCxNQVhfQ0FSRF9CQU5LU30gZnJvbSAnLi9jYXJkLWJhbmstc2hhZGVyJztcbmV4cG9ydCB7cGF0Y2hDYXJkQmFua1NoYWRlciBhcyBwYXRjaENhcmRTaGFkZXJ9IGZyb20gJy4vY2FyZC1iYW5rLXNoYWRlcic7XG5pbXBvcnQgKiBhcyBUSFJFRSBmcm9tICd0aHJlZSc7XG5pbXBvcnQge1NISVBfQ0FNRVJBfSBmcm9tICcuLi8uLi9zaGFyZWQvc2hpcC1nZW9tZXRyeSc7XG5cbi8qKiBPcmRpbmFyeSBkcmF3cyB1c2UgaW1wbGljaXQgc2luZ2xlLWJhbmsgc2FtcGxpbmc7IHdpZGVyIGNodW5rcyBhcmUgb3B0LWluLiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfQ0FSRF9CQU5LUz0xO1xuY29uc3QgTEFZRVJTPTE2LFBJWEVMX0JVREdFVD0xMioxMDI0KjEwMjQsVElMVD1NYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KTtcbnR5cGUgUmVxdWVzdD17a2V5OnN0cmluZztkZW5zaXR5Om51bWJlcjtwYWludDooY3R4OkNhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCk9PnZvaWQ7bWF0cml4OlRIUkVFLk1hdHJpeDQ7aWQ6c3RyaW5nO2Zvb3Q6bnVtYmVyO3RpbGVTaXplOm51bWJlcjtvcGFjaXR5Om51bWJlcjtiYXNlTWlwOm51bWJlcjtvcmRlcjpudW1iZXJ9O1xudHlwZSBDYXJkPXtrZXk6c3RyaW5nO3BhZ2U6UGFnZTtsYXllcjpudW1iZXI7dXNlZDpudW1iZXI7dGlsZVNpemU6bnVtYmVyO3NvdXJjZVNpemU6bnVtYmVyO2Jhc2VNaXA6bnVtYmVyO21hc2s6VWludDhBcnJheX07XG4vKiogQ2FjaGUgYWxsb2NhdGlvbiBpcyBpbmRlcGVuZGVudCBvZiBkcmF3IG9yZGVyLiBQYWdlcyBvd24gbm8gcmVuZGVyIG9iamVjdHMuICovXG50eXBlIFBhZ2U9e3RleHR1cmU6VEhSRUUuRGF0YUFycmF5VGV4dHVyZTtyZWFkb25seSBtaXBCeXRlczpudW1iZXI7dXBsb2FkZWQ6Ym9vbGVhbjtjYXJkczooQ2FyZHx1bmRlZmluZWQpW107dXNlZDpudW1iZXJ9O1xudHlwZSBJbnN0YW5jZT17Y2FyZDpDYXJkfHVuZGVmaW5lZDttYXRyaXg6VEhSRUUuTWF0cml4NDtpZDpzdHJpbmc7Zm9vdDpudW1iZXI7b3BhY2l0eTpudW1iZXI7b3JkZXI6bnVtYmVyfTtcbnR5cGUgRHJhd0NodW5rPXtiYW5rczpUSFJFRS5EYXRhQXJyYXlUZXh0dXJlW107cGFnZXM6UGFnZVtdO2VudHJpZXM6Q2FyZFtdO2lkczpzdHJpbmdbXTtmZWV0Om51bWJlcltdO29yZGVyczpudW1iZXJbXTtnZW9tZXRyeTpUSFJFRS5QbGFuZUdlb21ldHJ5O21hdGVyaWFsOlRIUkVFLk1lc2hCYXNpY01hdGVyaWFsO2RlcHRoOlRIUkVFLk1lc2hEZXB0aE1hdGVyaWFsO2Rpc3RhbmNlOlRIUkVFLk1lc2hEaXN0YW5jZU1hdGVyaWFsO21lc2g6VEhSRUUuSW5zdGFuY2VkTWVzaDtjYXBhY2l0eTpudW1iZXI7dXNlZDpudW1iZXI7cmVmcmVzaE1hdGVyaWFsczooKCk9PnZvaWQpW119O1xuZXhwb3J0IHR5cGUgUGFpbnRlZENhcmRQb2xpY3k9e3RyYW5zcGFyZW50Pzpib29sZWFuO2RlcHRoV3JpdGU/OmJvb2xlYW47YWxwaGFUZXN0PzpudW1iZXI7Y2FzdFNoYWRvdz86Ym9vbGVhbjtwaWNrYWJsZT86Ym9vbGVhbjtyZW5kZXJPcmRlcj86bnVtYmVyO21heFRleHR1cmVCYW5rcz86bnVtYmVyfTtcblxuLyoqIFJlbmRlcmVyLW93bmVkIGNhcmQgY2FjaGUgYW5kIGJhdGNoZXMuIEFuaW1hdGlvbi9jb2xvci9mYWNpbmcgdmFyeSBwZXJcbiAqIGluc3RhbmNlLCBub3QgcGVyIGRyYXcgY2FsbC4gTm8gY2FudmFzLCBHUFUgdGV4dHVyZSBvciBtYXRlcmlhbCBwZXIgc29sZGllci4gKi9cbmV4cG9ydCBjbGFzcyBQYWludGVkQ2FyZEJhdGNoZXMge1xuICBwcml2YXRlIHBhZ2VzOlBhZ2VbXT1bXTtcbiAgcHJpdmF0ZSBhbGxvY2F0ZWRQaXhlbHM9MDtcbiAgcHJpdmF0ZSBjYXJkcz1uZXcgTWFwPHN0cmluZyxDYXJkPigpO1xuICBwcml2YXRlIGZyYW1lPTA7XG4gIHByaXZhdGUgaW5zdGFuY2VPcmRlcj0wO1xuICAvLyBSZXVzZSBpbnN0YW5jZSByZWNvcmRzLCBpbmRleGVkIGJ5IHN1Ym1pc3Npb24gb3JkZXIuIFdhcm0gaGl0cyBhbmQgcGVuZGluZ1xuICAvLyB1cGxvYWRzIGZpbGwgdGhlIHNhbWUgc2VxdWVuY2UsIGlycmVzcGVjdGl2ZSBvZiByYXN0ZXIgY29tcGxldGlvbiBvcmRlci5cbiAgcHJpdmF0ZSBpbnN0YW5jZXM6SW5zdGFuY2VbXT1bXTtcbiAgcHJpdmF0ZSBiaW5kaW5ncz1uZXcgTWFwPENhcmQsSW5zdGFuY2VbXT4oKTtcbiAgcHJpdmF0ZSBjaHVua3M6RHJhd0NodW5rW109W107XG4gIHByaXZhdGUgZHJhd0dyb3VwPW5ldyBUSFJFRS5Hcm91cCgpO1xuICBwcml2YXRlIG1heFRleHR1cmVCYW5rczpudW1iZXI7XG4gIHByaXZhdGUgcGVuZGluZzpSZXF1ZXN0W109W107XG4gIHByaXZhdGUgcmFzdGVyaXphdGlvbnM9MDtcbiAgcHJpdmF0ZSBjb3BpZWRMYXllcnM9MDtcbiAgcHJpdmF0ZSBtYXRyaXg9bmV3IFRIUkVFLk1hdHJpeDQoKTtcbiAgcHJpdmF0ZSBvZmZzZXQ9bmV3IFRIUkVFLk1hdHJpeDQoKTtcbiAgcHJpdmF0ZSByYXlQcm9iZT1uZXcgVEhSRUUuTWVzaChuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgxLDEpLG5ldyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCh7c2lkZTpUSFJFRS5Eb3VibGVTaWRlfSkpO1xuICBwcml2YXRlIHJheVNwaGVyZT1uZXcgVEhSRUUuU3BoZXJlKCk7XG4gIHByaXZhdGUgcmF5SGl0czpUSFJFRS5JbnRlcnNlY3Rpb25bXT1bXTtcbiAgcHJpdmF0ZSBjYW52YXNlcz1uZXcgTWFwPG51bWJlcixIVE1MQ2FudmFzRWxlbWVudD4oKTtcbiAgcHJpdmF0ZSBtaXBVcGxvYWRlcjpDYXJkTWlwVXBsb2FkZXI7XG4gIHByaXZhdGUgcm93U2NyYXRjaD1uZXcgVWludDhBcnJheSgwKTtcbiAgcHJpdmF0ZSBlbXB0eVJnYmE9bmV3IFVpbnQ4QXJyYXkoMCk7XG4gIHByaXZhdGUgbWFza0J5dGVzPTA7XG4gIHByaXZhdGUgcGVuZGluZ1JnYmFCeXRlcz0wO1xuICBwcml2YXRlIHBlbmRpbmdNYXNrQnl0ZXM9MDtcbiAgcHJpdmF0ZSBwZWFrUGVuZGluZ1JnYmFCeXRlcz0wO1xuICBwcml2YXRlIHBlYWtPd25lZENwdUJ5dGVzPTA7XG4gIHByaXZhdGUgcGVha093bmVkR3B1Qnl0ZXM9MDtcbiAgcHJpdmF0ZSBwZWFrUmV0aXJlZEdwdUJ5dGVzPTA7XG4gIHByaXZhdGUgcmV0aXJpbmc9bmV3IFNldDxQYWdlPigpO1xuICBwcml2YXRlIHJhc3RlcldvcmtXYWxsTXM9MDtcbiAgcHJpdmF0ZSByYXN0ZXJDYWNoZT1uZXcgQ2FyZFJhc3RlckNhY2hlKCk7XG4gIHByaXZhdGUgcmFzdGVyU3RhZ2VzPXtwYWludE1zOjAscmVhZGJhY2tNczowLGNhY2hlTXM6MCxwaWNrTWFza01zOjAscm93RmxpcE1zOjAsc2xvdE1zOjB9O1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNjZW5lOlRIUkVFLlNjZW5lLHByaXZhdGUgYW5pc290cm9weTpudW1iZXIscHJpdmF0ZSBwb2xpY3k6UGFpbnRlZENhcmRQb2xpY3k9e30pe1xuICAgIHRoaXMubWF4VGV4dHVyZUJhbmtzPXBvbGljeS5tYXhUZXh0dXJlQmFua3M/P0RFRkFVTFRfQ0FSRF9CQU5LUztcbiAgICBpZighTnVtYmVyLmlzSW50ZWdlcih0aGlzLm1heFRleHR1cmVCYW5rcyl8fHRoaXMubWF4VGV4dHVyZUJhbmtzPDF8fHRoaXMubWF4VGV4dHVyZUJhbmtzPk1BWF9DQVJEX0JBTktTKXRocm93IG5ldyBFcnJvcignSW52YWxpZCBwYWludGVkIGNhcmQgYmFuayBjb3VudC4nKTtcbiAgICB0aGlzLmRyYXdHcm91cC5uYW1lPSdQYWludGVkQ2FyZERyYXdzJztcbiAgICB0aGlzLm1pcFVwbG9hZGVyPW5ldyBDYXJkTWlwVXBsb2FkZXIoYW5pc290cm9weSk7XG4gIH1cbiAgYmVnaW4oKXtcbiAgICB0aGlzLmZyYW1lKys7dGhpcy5pbnN0YW5jZU9yZGVyPTA7dGhpcy5wZW5kaW5nLmxlbmd0aD0wO3RoaXMuYmluZGluZ3MuY2xlYXIoKTtcbiAgICBmb3IoY29uc3Qgcm93IG9mIHRoaXMuaW5zdGFuY2VzKWlmKHJvdyl7cm93LmNhcmQ9dW5kZWZpbmVkO3Jvdy5pZD0nJzt9XG4gICAgLy8gQSBmYWlsZWQgdXBsb2FkIG11c3Qgbm90IGV4cG9zZSBsYXN0IGZyYW1lJ3MgbG93ZXItcXVhbGl0eSBkcmF3IGJpbmRpbmdzLlxuICAgIGZvcihjb25zdCBjaHVuayBvZiB0aGlzLmNodW5rcyl0aGlzLmhpZGVDaHVuayhjaHVuayk7XG4gIH1cbiAgcHJpdmF0ZSBjcmVhdGVQYWdlKHdpZHRoOm51bWJlcixoZWlnaHQ6bnVtYmVyLGxheWVycz1MQVlFUlMpe1xuICAgIGNvbnN0IHBhZ2U6UGFnZT17dGV4dHVyZTpjcmVhdGVDYXJkQXJyYXkod2lkdGgsaGVpZ2h0LGxheWVycyx0aGlzLmFuaXNvdHJvcHkpLG1pcEJ5dGVzOmNhcmRUZXh0dXJlQnl0ZXMod2lkdGgsaGVpZ2h0LGxheWVycyksdXBsb2FkZWQ6ZmFsc2UsY2FyZHM6bmV3IEFycmF5KGxheWVycyksdXNlZDp0aGlzLmZyYW1lfTtcbiAgICB0aGlzLnBhZ2VzLnB1c2gocGFnZSk7dGhpcy5hbGxvY2F0ZWRQaXhlbHMrPXdpZHRoKmhlaWdodCpsYXllcnM7cmV0dXJuIHBhZ2U7XG4gIH1cbiAgcHJpdmF0ZSBzbG90KHdpZHRoOm51bWJlcixoZWlnaHQ6bnVtYmVyLHBlbmRpbmdMYXllcnM6bnVtYmVyLGVtcHR5PWZhbHNlKXtcbiAgICBsZXQgb2xkZXN0OkNhcmR8dW5kZWZpbmVkO1xuICAgIGZvcihjb25zdCBwYWdlIG9mIHRoaXMucGFnZXMpe1xuICAgICAgaWYocGFnZS50ZXh0dXJlLmltYWdlLndpZHRoIT09d2lkdGh8fHBhZ2UudGV4dHVyZS5pbWFnZS5oZWlnaHQhPT1oZWlnaHQpY29udGludWU7XG4gICAgICBmb3IobGV0IGxheWVyPTA7bGF5ZXI8cGFnZS50ZXh0dXJlLmltYWdlLmRlcHRoO2xheWVyKyspe1xuICAgICAgICBjb25zdCBjYXJkPXBhZ2UuY2FyZHNbbGF5ZXJdO2lmKCFjYXJkKXJldHVybntwYWdlLGxheWVyfTtcbiAgICAgICAgaWYoY2FyZC51c2VkIT09dGhpcy5mcmFtZSYmKCFvbGRlc3R8fGNhcmQudXNlZDxvbGRlc3QudXNlZCkpb2xkZXN0PWNhcmQ7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIEtlZXAgYSBib3VuZGVkIHdhcm0gY2FjaGUsIGJ1dCBuZXZlciBldmljdCBhIGNhcmQgcmVmZXJlbmNlZCBieSB0aGlzXG4gICAgLy8gZnJhbWUuIExhcmdlIHZpc2libGUgYXJtaWVzIG1heSBsZWdpdGltYXRlbHkgZXhjZWVkIHRoZSBzb2Z0IGJ1ZGdldC5cbiAgICBjb25zdCByZW1haW5pbmdMYXllcnM9TWF0aC5mbG9vcigoUElYRUxfQlVER0VULXRoaXMuYWxsb2NhdGVkUGl4ZWxzKS8od2lkdGgqaGVpZ2h0KSk7XG4gICAgaWYob2xkZXN0JiZyZW1haW5pbmdMYXllcnM8MSl7dGhpcy5jYXJkcy5kZWxldGUob2xkZXN0LmtleSk7dGhpcy5tYXNrQnl0ZXMtPW9sZGVzdC5tYXNrLmJ5dGVMZW5ndGg7b2xkZXN0LnBhZ2UuY2FyZHNbb2xkZXN0LmxheWVyXT11bmRlZmluZWQ7cmV0dXJue3BhZ2U6b2xkZXN0LnBhZ2UsbGF5ZXI6b2xkZXN0LmxheWVyfTt9XG4gICAgLy8gUmVzZXJ2ZSBvbmx5IHRoaXMgZnJhbWUncyByZW1haW5pbmcgdW5pcXVlIGRlbWFuZHMsIGV2ZW4gYmVsb3cgYnVkZ2V0LlxuICAgIC8vIEEgbmV3IHJlc2lkZW50LXNpemUgYmluIG1heSBuZWVkIGEgZmV3IHBvc2VzIHJhdGhlciB0aGFuIHNpeHRlZW4gd2FybVxuICAgIC8vIHNsb3RzLiBDdXJyZW50IHZpc2libGUgZGVtYW5kcyBtYXkgc3RpbGwgZXhjZWVkIHRoZSBzb2Z0IGJ1ZGdldC5cbiAgICAvLyBFbXB0eSBvdXRwdXQgaGFzIGEgY2hlYXAgc2hhcmVkIDE2cHggZG9tYWluLiBLZWVwIGl0cyBvcmRpbmFyeSBiYXRjaGluZ1xuICAgIC8vIGJlbG93IGJ1ZGdldDogbWFueSBzaW5nbGUtbGF5ZXIgdGV4dHVyZXMgc2F2ZSBubyBwaXhlbHMgb3ZlciBvbmUgc2hhcmVkXG4gICAgLy8gcGFnZS4gQWJvdmUgYnVkZ2V0IHVzZSBvbmUgbGF5ZXIgYmVjYXVzZSBmdXR1cmUgZW1wdHkgb3V0cHV0IGlzIHVua25vd24uXG4gICAgY29uc3QgbGF5ZXJzPWVtcHR5PyhyZW1haW5pbmdMYXllcnM+MD9NYXRoLm1pbihMQVlFUlMscmVtYWluaW5nTGF5ZXJzKToxKTpNYXRoLm1pbihMQVlFUlMsTWF0aC5tYXgoMSxwZW5kaW5nTGF5ZXJzKSxyZW1haW5pbmdMYXllcnM+MD9yZW1haW5pbmdMYXllcnM6TEFZRVJTKTtcbiAgICByZXR1cm57cGFnZTp0aGlzLmNyZWF0ZVBhZ2Uod2lkdGgsaGVpZ2h0LGxheWVycyksbGF5ZXI6MH07XG4gIH1cbiAgYWRkKGtleTpzdHJpbmcsZGVuc2l0eTpudW1iZXIscGFpbnQ6KGN0eDpDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQpPT52b2lkLG1hdHJpeDpUSFJFRS5NYXRyaXg0LGlkOnN0cmluZyxmb290Om51bWJlcix0aWxlU2l6ZTpudW1iZXI9QVJUX1RJTEVfU0laRSxvcGFjaXR5PTEsYmFzZU1pcD0wKXtcbiAgICBjb25zdCBzaXplPXRpbGVTaXplKmRlbnNpdHksZmFjdG9yPTIqKmJhc2VNaXA7XG4gICAgaWYoIU51bWJlci5pc0ludGVnZXIoYmFzZU1pcCl8fGJhc2VNaXA8MHx8YmFzZU1pcD4wJiYoIU51bWJlci5pc0ludGVnZXIoc2l6ZSl8fHNpemU8MXx8c2l6ZSVmYWN0b3IhPT0wKSl0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgcGFpbnRlZCBjYXJkIHJlc2lkZW50IG1pcC4nKTtcbiAgICBrZXk9YCR7a2V5fToke2RlbnNpdHl9OiR7dGlsZVNpemV9YDtcbiAgICBjb25zdCBvcmRlcj10aGlzLmluc3RhbmNlT3JkZXIrKyxjYXJkPXRoaXMuY2FyZHMuZ2V0KGtleSk7XG4gICAgLy8gUHJvdGVjdCBldmVyeSB3YXJtIHBvc2UgdXNlZCB0aGlzIGZyYW1lIGJlZm9yZSBhbGxvY2F0aW5nIGFueSBuZXcgb25lLlxuICAgIC8vIE90aGVyd2lzZSBvbmUgZWFybHkgY2FjaGUgbWlzcyBjYW4gZXZpY3QgYSBsYXRlciB2aXNpYmxlIHBvc2UsIGNhc2NhZGluZ1xuICAgIC8vIGludG8gYSBmdWxsIHJlcmFzdGVyaXphdGlvbiBvZiBhbiBhcm15IGxhcmdlciB0aGFuIHRoZSBzb2Z0IGJ1ZGdldC5cbiAgICBpZihjYXJkKXtcbiAgICAgIGNhcmQudXNlZD1jYXJkLnBhZ2UudXNlZD10aGlzLmZyYW1lO1xuICAgICAgLy8gQSBmaW5lciByZXNpZGVudCBjaGFpbiBhbHJlYWR5IGNvbnRhaW5zIGV2ZXJ5IHJlcXVlc3RlZCBsb3dlciBtaXAuXG4gICAgICAvLyBSZXNpZGVuY3kgaXMgc3RhdGUgb2YgdGhpcyBvcmlnaW5hbCByYXN0ZXIsIG5vdCBhbm90aGVyIGFzc2V0IGlkZW50aXR5LlxuICAgICAgaWYoY2FyZC5iYXNlTWlwPD1iYXNlTWlwKXt0aGlzLmluc3RhbmNlKGNhcmQsbWF0cml4LGlkLGZvb3Qsb3BhY2l0eSxvcmRlcik7cmV0dXJuO31cbiAgICB9XG4gICAgdGhpcy5wZW5kaW5nLnB1c2goe2tleSxkZW5zaXR5LHBhaW50LG1hdHJpeCxpZCxmb290LHRpbGVTaXplLG9wYWNpdHksYmFzZU1pcCxvcmRlcn0pO1xuICB9XG4gIHByaXZhdGUgaW5zdGFuY2UoY2FyZDpDYXJkLG1hdHJpeDpUSFJFRS5NYXRyaXg0LGlkOnN0cmluZyxmb290Om51bWJlcixvcGFjaXR5Om51bWJlcixvcmRlcjpudW1iZXIpe1xuICAgIGNhcmQudXNlZD1jYXJkLnBhZ2UudXNlZD10aGlzLmZyYW1lO1xuICAgIGxldCByb3c9dGhpcy5pbnN0YW5jZXNbb3JkZXJdO1xuICAgIGlmKCFyb3cpe3Jvdz17Y2FyZCxtYXRyaXgsaWQsZm9vdCxvcGFjaXR5OjAsb3JkZXJ9O3RoaXMuaW5zdGFuY2VzW29yZGVyXT1yb3c7fVxuICAgIGVsc2V7cm93LmNhcmQ9Y2FyZDtyb3cubWF0cml4PW1hdHJpeDtyb3cuaWQ9aWQ7cm93LmZvb3Q9Zm9vdDtyb3cub3JkZXI9b3JkZXI7fVxuICAgIHJvdy5vcGFjaXR5PU1hdGgubWF4KDAsTWF0aC5taW4oMSxvcGFjaXR5KSk7XG4gICAgbGV0IGJpbmRpbmdzPXRoaXMuYmluZGluZ3MuZ2V0KGNhcmQpO2lmKCFiaW5kaW5ncyl7YmluZGluZ3M9W107dGhpcy5iaW5kaW5ncy5zZXQoY2FyZCxiaW5kaW5ncyk7fWJpbmRpbmdzLnB1c2gocm93KTtcbiAgfVxuICAvKiogUHVibGlzaCBhIHN1Y2Nlc3NmdWwgcHJvbW90aW9uIG9yIGNvbXBhY3Rpb24gd2l0aG91dCBjaGFuZ2luZyBzdWJtaXNzaW9uXG4gICAqIG9yZGVyLCBzb3VyY2UgZ2VvbWV0cnksIG1hdHJpY2VzIG9yIGFscGhhLW1hc2sgaWRlbnRpdHkuICovXG4gIHByaXZhdGUgcmViaW5kKHByZXZpb3VzOkNhcmQsY3VycmVudDpDYXJkKXtcbiAgICBjb25zdCByb3dzPXRoaXMuYmluZGluZ3MuZ2V0KHByZXZpb3VzKTtpZighcm93cylyZXR1cm47XG4gICAgbGV0IHRhcmdldD10aGlzLmJpbmRpbmdzLmdldChjdXJyZW50KTtpZighdGFyZ2V0KXt0YXJnZXQ9W107dGhpcy5iaW5kaW5ncy5zZXQoY3VycmVudCx0YXJnZXQpO31cbiAgICBmb3IoY29uc3Qgcm93IG9mIHJvd3Mpe3Jvdy5jYXJkPWN1cnJlbnQ7dGFyZ2V0LnB1c2gocm93KTt9dGhpcy5iaW5kaW5ncy5kZWxldGUocHJldmlvdXMpO1xuICB9XG4gIHByaXZhdGUgcmFzdGVyKHtrZXksZGVuc2l0eSxwYWludCxtYXRyaXgsaWQsZm9vdCx0aWxlU2l6ZSxvcGFjaXR5LG9yZGVyfTpSZXF1ZXN0LHJlbmRlcmVyOkNhcmRUZXh0dXJlUmVuZGVyZXIsYmFzZU1pcDpudW1iZXIscGVuZGluZ0xheWVyczpNYXA8bnVtYmVyLG51bWJlcj4pe1xuICAgIGxldCBjYXJkPXRoaXMuY2FyZHMuZ2V0KGtleSk7XG4gICAgaWYoIWNhcmR8fGNhcmQuYmFzZU1pcD5iYXNlTWlwKXtcbiAgICAgIGNvbnN0IHByZXZpb3VzPWNhcmQ7XG4gICAgICBjb25zdCBzdGFydD1wZXJmb3JtYW5jZS5ub3coKSxzaXplPXRpbGVTaXplKmRlbnNpdHk7XG4gICAgICBjb25zdCBjYWNoZVN0YXJ0PXBlcmZvcm1hbmNlLm5vdygpO2xldCByZ2JhPXRoaXMucmFzdGVyQ2FjaGUuZ2V0KGtleSk7XG4gICAgICB0aGlzLnJhc3RlclN0YWdlcy5jYWNoZU1zKz1wZXJmb3JtYW5jZS5ub3coKS1jYWNoZVN0YXJ0O2NvbnN0IGZyb21DYWNoZT0hIXJnYmE7bGV0IHBhaW50TXM9MDtcbiAgICAgIGlmKCFyZ2JhKXtcbiAgICAgICAgY29uc3QgcGFpbnRTdGFydD1wZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgICAgbGV0IGNhbnZhcz10aGlzLmNhbnZhc2VzLmdldChzaXplKTtpZighY2FudmFzKXtjYW52YXM9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7Y2FudmFzLndpZHRoPWNhbnZhcy5oZWlnaHQ9c2l6ZTt0aGlzLmNhbnZhc2VzLnNldChzaXplLGNhbnZhcyk7fVxuICAgICAgICBjb25zdCBjdHg9Y2FudmFzLmdldENvbnRleHQoJzJkJyx7d2lsbFJlYWRGcmVxdWVudGx5OnRydWV9KSE7Y3R4LnJlc2V0VHJhbnNmb3JtKCk7Y3R4LmNsZWFyUmVjdCgwLDAsc2l6ZSxzaXplKTtjdHguc2F2ZSgpO2N0eC5zY2FsZShkZW5zaXR5LGRlbnNpdHkpO2N0eC50cmFuc2xhdGUodGlsZVNpemUvMix0aWxlU2l6ZS8yKTtcbiAgICAgICAgdHJ5e3BhaW50KGN0eCk7fWZpbmFsbHl7Y3R4LnJlc3RvcmUoKTt9XG4gICAgICAgIGNvbnN0IHBhaW50ZWRBdD1wZXJmb3JtYW5jZS5ub3coKTt0aGlzLnJhc3RlclN0YWdlcy5wYWludE1zKz1wYWludGVkQXQtcGFpbnRTdGFydDtcbiAgICAgICAgcmdiYT1jdHguZ2V0SW1hZ2VEYXRhKDAsMCxzaXplLHNpemUpLmRhdGE7Y29uc3QgcmVhZEF0PXBlcmZvcm1hbmNlLm5vdygpO3RoaXMucmFzdGVyU3RhZ2VzLnJlYWRiYWNrTXMrPXJlYWRBdC1wYWludGVkQXQ7cGFpbnRNcz1yZWFkQXQtcGFpbnRTdGFydDtcblxuICAgICAgfVxuICAgICAgdGhpcy5wZW5kaW5nUmdiYUJ5dGVzPXJnYmEuYnl0ZUxlbmd0aDt0aGlzLnJlY29yZFBlYWtzKCk7XG4gICAgICB0cnl7XG4gICAgICAgIGNvbnN0IG1hc2tTdGFydD1wZXJmb3JtYW5jZS5ub3coKSxwYWludGVkPWhhc1BhaW50KHJnYmEpLHNvdXJjZVNpemU9cGFpbnRlZD9zaXplOjE2LHJlc2lkZW50TWlwPXBhaW50ZWQ/YmFzZU1pcDowLHJldGFpbmVkU2l6ZT1zb3VyY2VTaXplLzIqKnJlc2lkZW50TWlwO1xuICAgICAgICBjb25zdCBtYXNrPXRoaXMucG9saWN5LnBpY2thYmxlPT09ZmFsc2U/bmV3IFVpbnQ4QXJyYXkoMCk6cGFpbnRlZD9wYWNrQ2FyZFBpY2tNYXNrKHJnYmEsc2l6ZSxzaXplLCFmcm9tQ2FjaGUpOm5ldyBVaW50OEFycmF5KDE2KjE2LzgpO1xuICAgICAgICB0aGlzLnBlbmRpbmdNYXNrQnl0ZXM9bWFzay5ieXRlTGVuZ3RoO1xuICAgICAgICBjb25zdCBmbGlwU3RhcnQ9cGVyZm9ybWFuY2Uubm93KCk7dGhpcy5yYXN0ZXJTdGFnZXMucGlja01hc2tNcys9ZmxpcFN0YXJ0LW1hc2tTdGFydDtcbiAgICAgICAgLy8gUmV2ZXJzZSByb3dzIGluIHBsYWNlLiBBIHNpbmdsZSByZXVzYWJsZSByb3cgcmVwbGFjZXMgYSBzZWNvbmQgZnVsbFxuICAgICAgICAvLyBSR0JBIGFsbG9jYXRpb247IHRoZSBzb3VyY2UgcmVhZGJhY2sgaXMgcmVsZWFzZWQgYWZ0ZXIgdGhpcyB1cGxvYWQuXG4gICAgICAgIGlmKHBhaW50ZWQmJiFmcm9tQ2FjaGUpe1xuICAgICAgICAgIGNvbnN0IHJvdz1zaXplKjQ7aWYodGhpcy5yb3dTY3JhdGNoLmxlbmd0aDxyb3cpdGhpcy5yb3dTY3JhdGNoPW5ldyBVaW50OEFycmF5KHJvdyk7XG4gICAgICAgICAgZm9yKGxldCB5PTA7eTxNYXRoLmZsb29yKHNpemUvMik7eSsrKXtcbiAgICAgICAgICAgIGNvbnN0IHRvcD15KnJvdyxib3R0b209KHNpemUtMS15KSpyb3c7dGhpcy5yb3dTY3JhdGNoLnNldChyZ2JhLnN1YmFycmF5KHRvcCx0b3Arcm93KSk7XG4gICAgICAgICAgICByZ2JhLmNvcHlXaXRoaW4odG9wLGJvdHRvbSxib3R0b20rcm93KTtyZ2JhLnNldCh0aGlzLnJvd1NjcmF0Y2guc3ViYXJyYXkoMCxyb3cpLGJvdHRvbSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZsaXBwZWRBdD1wZXJmb3JtYW5jZS5ub3coKTt0aGlzLnJhc3RlclN0YWdlcy5yb3dGbGlwTXMrPWZsaXBwZWRBdC1mbGlwU3RhcnQ7XG4gICAgICAgIC8vIENhY2hlZCBieXRlcyBhbHJlYWR5IGhhdmUgR1BVIHJvdyBvcmllbnRhdGlvbi4gUmVoeWRyYXRpb24gbmV2ZXJcbiAgICAgICAgLy8gcmV3cml0ZXMgdHJhbnNwYXJlbnQgcm93cyBqdXN0IHRvIGZsaXAgdGhlbSBhIHNlY29uZCB0aW1lLlxuICAgICAgICBpZighZnJvbUNhY2hlKXRoaXMucmFzdGVyQ2FjaGUucHV0KGtleSxyZ2JhLHNpemUsc2l6ZSxwYWludE1zKTtcbiAgICAgICAgY29uc3Qgc2xvdFN0YXJ0PXBlcmZvcm1hbmNlLm5vdygpO3RoaXMucmFzdGVyU3RhZ2VzLmNhY2hlTXMrPXNsb3RTdGFydC1mbGlwcGVkQXQ7XG4gICAgICAgIGNvbnN0IHtwYWdlLGxheWVyfT10aGlzLnNsb3QocmV0YWluZWRTaXplLHJldGFpbmVkU2l6ZSxwZW5kaW5nTGF5ZXJzLmdldChyZXRhaW5lZFNpemUpPz8xLCFwYWludGVkKTt0aGlzLnJlY29yZFBlYWtzKCk7XG4gICAgICAgIHRoaXMucmFzdGVyU3RhZ2VzLnNsb3RNcys9cGVyZm9ybWFuY2Uubm93KCktc2xvdFN0YXJ0O1xuICAgICAgICB0aGlzLnJhc3RlcldvcmtXYWxsTXMrPXBlcmZvcm1hbmNlLm5vdygpLXN0YXJ0O1xuICAgICAgICBpZighcGFpbnRlZCYmdGhpcy5lbXB0eVJnYmEubGVuZ3RoPT09MCl0aGlzLmVtcHR5UmdiYT1uZXcgVWludDhBcnJheSgxNioxNio0KTtcbiAgICAgICAgdGhpcy5taXBVcGxvYWRlci51cGxvYWRMYXllcihwYWdlLGxheWVyLHBhaW50ZWQ/cmdiYTp0aGlzLmVtcHR5UmdiYSxyZW5kZXJlcix7c291cmNlV2lkdGg6c291cmNlU2l6ZSxzb3VyY2VIZWlnaHQ6c291cmNlU2l6ZSxiYXNlTWlwOnJlc2lkZW50TWlwfSk7dGhpcy5yZWNvcmRQZWFrcygpO1xuICAgICAgICBjYXJkPXtrZXkscGFnZSxsYXllcix1c2VkOnRoaXMuZnJhbWUsdGlsZVNpemUsc291cmNlU2l6ZSxiYXNlTWlwOnJlc2lkZW50TWlwLG1hc2t9O3BhZ2UuY2FyZHNbbGF5ZXJdPWNhcmQ7dGhpcy5jYXJkcy5zZXQoa2V5LGNhcmQpO3RoaXMubWFza0J5dGVzKz1tYXNrLmJ5dGVMZW5ndGg7XG4gICAgICAgIGlmKHByZXZpb3VzKXt0aGlzLnJlYmluZChwcmV2aW91cyxjYXJkKTtwcmV2aW91cy5wYWdlLmNhcmRzW3ByZXZpb3VzLmxheWVyXT11bmRlZmluZWQ7dGhpcy5tYXNrQnl0ZXMtPXByZXZpb3VzLm1hc2suYnl0ZUxlbmd0aDt9XG4gICAgICAgIHRoaXMucmFzdGVyaXphdGlvbnMrKztcbiAgICAgICAgLy8gRW1wdHkgZHJhd2luZ3MgdXNlIGEgc2VwYXJhdGUgbWluaW11bSBkb21haW4uIENvbnN1bWUgdGhlIG9yaWdpbmFsXG4gICAgICAgIC8vIHBsYW5uZWQgZGVtYW5kIG9uY2UsIHJhdGhlciB0aGFuIGFub3RoZXIgcmVxdWVzdCdzIDE2cHggYmluIGNvdW50LlxuICAgICAgICBjb25zdCBwbGFubmVkU2l6ZT1zaXplLzIqKmJhc2VNaXA7XG4gICAgICAgIHBlbmRpbmdMYXllcnMuc2V0KHBsYW5uZWRTaXplLE1hdGgubWF4KDAsKHBlbmRpbmdMYXllcnMuZ2V0KHBsYW5uZWRTaXplKT8/MSktMSkpO1xuICAgICAgfWZpbmFsbHl7dGhpcy5wZW5kaW5nUmdiYUJ5dGVzPXRoaXMucGVuZGluZ01hc2tCeXRlcz0wO31cbiAgICB9XG4gICAgdGhpcy5pbnN0YW5jZShjYXJkLG1hdHJpeCxpZCxmb290LG9wYWNpdHksb3JkZXIpO1xuICB9XG4gIHByaXZhdGUgY29tcGFjdChyZW5kZXJlcjpDYXJkVGV4dHVyZVJlbmRlcmVyKXtcbiAgICBpZih0aGlzLmFsbG9jYXRlZFBpeGVsczw9UElYRUxfQlVER0VUKXJldHVybjtcbiAgICBjb25zdCBzaXplcz1uZXcgU2V0KHRoaXMucGFnZXMubWFwKHBhZ2U9PmAke3BhZ2UudGV4dHVyZS5pbWFnZS53aWR0aH06JHtwYWdlLnRleHR1cmUuaW1hZ2UuaGVpZ2h0fWApKTtcbiAgICBmb3IoY29uc3Qgc2l6ZSBvZiBzaXplcyl7XG4gICAgICBjb25zdCBbd2lkdGgsaGVpZ2h0XT1zaXplLnNwbGl0KCc6JykubWFwKE51bWJlcikgYXMgW251bWJlcixudW1iZXJdO1xuICAgICAgY29uc3QgcGFnZXM9dGhpcy5wYWdlcy5maWx0ZXIocGFnZT0+cGFnZS50ZXh0dXJlLmltYWdlLndpZHRoPT09d2lkdGgmJnBhZ2UudGV4dHVyZS5pbWFnZS5oZWlnaHQ9PT1oZWlnaHQpO1xuICAgICAgY29uc3QgYWN0aXZlPXBhZ2VzLmZsYXRNYXAocGFnZT0+cGFnZS5jYXJkcy5maWx0ZXIoKGNhcmQpOmNhcmQgaXMgQ2FyZD0+Qm9vbGVhbihjYXJkJiZjYXJkLnVzZWQ9PT10aGlzLmZyYW1lKSkpO1xuICAgICAgbGV0IGNhcGFjaXR5PTAsbmVlZGVkPTA7XG4gICAgICBmb3IoY29uc3QgcGFnZSBvZiBbLi4ucGFnZXNdLnNvcnQoKGEsYik9PmIudGV4dHVyZS5pbWFnZS5kZXB0aC1hLnRleHR1cmUuaW1hZ2UuZGVwdGgpKXtcbiAgICAgICAgaWYoY2FwYWNpdHk+PWFjdGl2ZS5sZW5ndGgpYnJlYWs7Y2FwYWNpdHkrPXBhZ2UudGV4dHVyZS5pbWFnZS5kZXB0aDtuZWVkZWQrKztcbiAgICAgIH1cbiAgICAgIC8vIE9ubHkgcmVwYWlyIHNldmVyZSBmcmFnbWVudGF0aW9uLCBlLmcuIGEgbGFyZ2UgYXJteSBsZWF2aW5nIHRlblxuICAgICAgLy8gc3Vydml2b3JzIHNwcmVhZCBhY3Jvc3MgdGVuIG9sZCBwYWdlcy4gRG8gbm90IHJlcGFjayBub3JtYWwgYW5pbWF0aW9uXG4gICAgICAvLyBjaHVybiBvciBicmllZmx5IGV4Y2VlZCB0aGUgd29ya2luZyBzZXQncyBuZWNlc3NhcnkgcGFnZSBjb3VudC5cbiAgICAgIGlmKCFuZWVkZWR8fG5lZWRlZCoyPnBhZ2VzLmxlbmd0aCljb250aW51ZTtcbiAgICAgIC8vIEtlZXAgdGhlIHBhZ2VzIGhvbGRpbmcgdGhlIG1vc3QgdmlzaWJsZSBwb3Nlcy4gUmVwYWlyIHRoZSBzZWxlY3Rpb25cbiAgICAgIC8vIHdoZW4gYSBzaG9ydCB0YWlsIHBhZ2Ugd291bGQgb3RoZXJ3aXNlIHJlcXVpcmUgYW4gZXh0cmEgZGVzdGluYXRpb24uXG4gICAgICBjb25zdCByYW5rZWQ9Wy4uLnBhZ2VzXS5zb3J0KChhLGIpPT5iLmNhcmRzLmZpbHRlcihjYXJkPT5jYXJkPy51c2VkPT09dGhpcy5mcmFtZSkubGVuZ3RoLWEuY2FyZHMuZmlsdGVyKGNhcmQ9PmNhcmQ/LnVzZWQ9PT10aGlzLmZyYW1lKS5sZW5ndGh8fGIudGV4dHVyZS5pbWFnZS5kZXB0aC1hLnRleHR1cmUuaW1hZ2UuZGVwdGgpO1xuICAgICAgY29uc3QgZGVzdGluYXRpb25zPXJhbmtlZC5zbGljZSgwLG5lZWRlZCk7Y2FwYWNpdHk9ZGVzdGluYXRpb25zLnJlZHVjZSgoc3VtLHBhZ2UpPT5zdW0rcGFnZS50ZXh0dXJlLmltYWdlLmRlcHRoLDApO1xuICAgICAgd2hpbGUoY2FwYWNpdHk8YWN0aXZlLmxlbmd0aCl7XG4gICAgICAgIGNvbnN0IHNtYWxsZXN0PVsuLi5kZXN0aW5hdGlvbnNdLnNvcnQoKGEsYik9PmEudGV4dHVyZS5pbWFnZS5kZXB0aC1iLnRleHR1cmUuaW1hZ2UuZGVwdGgpWzBdITtcbiAgICAgICAgY29uc3QgcmVwbGFjZW1lbnQ9cGFnZXMuZmlsdGVyKHBhZ2U9PiFkZXN0aW5hdGlvbnMuaW5jbHVkZXMocGFnZSkpLnNvcnQoKGEsYik9PmIudGV4dHVyZS5pbWFnZS5kZXB0aC1hLnRleHR1cmUuaW1hZ2UuZGVwdGgpWzBdITtcbiAgICAgICAgY2FwYWNpdHkrPXJlcGxhY2VtZW50LnRleHR1cmUuaW1hZ2UuZGVwdGgtc21hbGxlc3QudGV4dHVyZS5pbWFnZS5kZXB0aDtcbiAgICAgICAgZGVzdGluYXRpb25zW2Rlc3RpbmF0aW9ucy5pbmRleE9mKHNtYWxsZXN0KV09cmVwbGFjZW1lbnQ7XG4gICAgICB9XG4gICAgICBjb25zdCBrZXB0PW5ldyBTZXQoZGVzdGluYXRpb25zKSxzb3VyY2VzPXBhZ2VzLmZpbHRlcihwYWdlPT4ha2VwdC5oYXMocGFnZSkpO1xuICAgICAgY29uc3QgaG9sZXM6e3BhZ2U6UGFnZTtsYXllcjpudW1iZXJ9W109W107XG4gICAgICBmb3IoY29uc3QgcGFnZSBvZiBkZXN0aW5hdGlvbnMpZm9yKGxldCBsYXllcj0wO2xheWVyPHBhZ2UudGV4dHVyZS5pbWFnZS5kZXB0aDtsYXllcisrKWlmKHBhZ2UuY2FyZHNbbGF5ZXJdPy51c2VkIT09dGhpcy5mcmFtZSlob2xlcy5wdXNoKHtwYWdlLGxheWVyfSk7XG4gICAgICBjb25zdCBkaXNwbGFjZWQ9YWN0aXZlLmZpbHRlcihjYXJkPT4ha2VwdC5oYXMoY2FyZC5wYWdlKSk7XG4gICAgICBjb25zdCBtb3ZlZD1uZXcgTWFwPENhcmQsQ2FyZD4oKSxtb3ZlczpDYXJkTWlwTW92ZVtdPVtdO1xuICAgICAgZm9yKGNvbnN0IFtpLG9sZF0gb2YgZGlzcGxhY2VkLmVudHJpZXMoKSl7XG4gICAgICAgIGNvbnN0IHtwYWdlLGxheWVyfT1ob2xlc1tpXSEsY2FyZD17Li4ub2xkLHBhZ2UsbGF5ZXIsdXNlZDp0aGlzLmZyYW1lfTttb3ZlZC5zZXQob2xkLGNhcmQpO1xuICAgICAgICBtb3Zlcy5wdXNoKHtzb3VyY2U6b2xkLnBhZ2Usc291cmNlTGF5ZXI6b2xkLmxheWVyLGRlc3RpbmF0aW9uOnBhZ2UsZGVzdGluYXRpb25MYXllcjpsYXllcn0pO1xuICAgICAgfVxuICAgICAgZm9yKGNvbnN0IHNvdXJjZSBvZiBzb3VyY2VzKXRoaXMucmV0aXJpbmcuYWRkKHNvdXJjZSk7XG4gICAgICB0cnl7XG4gICAgICAgIC8vIERlc3RpbmF0aW9ucyBhcmUgZXhpc3RpbmcgaW5hY3RpdmUgaG9sZXMuIE5vIGFjdGl2ZSBzb3VyY2UgY2FuIGJlIGFcbiAgICAgICAgLy8gZGVzdGluYXRpb24sIHNvIGZhaWxlZCBjb3BpZXMgbGVhdmUgZXZlcnkgdmlzaWJsZSBzb3VyY2UgaW50YWN0LlxuICAgICAgICAvLyBQdWJsaXNoIG1hcHMgYW5kIGluc3RhbmNlcyBvbmx5IGFmdGVyIGFsbCBtaXAgY29waWVzIGFyZSBzdWJtaXR0ZWQuXG4gICAgICAgIHRoaXMubWlwVXBsb2FkZXIuY29weUxheWVycyhtb3ZlcyxyZW5kZXJlcik7dGhpcy5yZWNvcmRQZWFrcygpO1xuICAgICAgfWNhdGNoKGVycm9yKXtcbiAgICAgICAgLy8gQSBwYXJ0aWFsIGNvcHkgY2FuIGNvcnJ1cHQgYSB3YXJtIGRlc3RpbmF0aW9uLiBJbnZhbGlkYXRlIGFsbCBwbGFubmVkXG4gICAgICAgIC8vIGhvbGVzIGNvbnNlcnZhdGl2ZWx5OyB0aGVpciBuZXh0IHJlcXVlc3QgbXVzdCByZXBhaW50L3JlY292ZXIgdGhlbS5cbiAgICAgICAgZm9yKGNvbnN0IGNhcmQgb2YgbW92ZWQudmFsdWVzKCkpe1xuICAgICAgICAgIGNvbnN0IHByZXZpb3VzPWNhcmQucGFnZS5jYXJkc1tjYXJkLmxheWVyXTtcbiAgICAgICAgICBpZihwcmV2aW91cyYmdGhpcy5jYXJkcy5nZXQocHJldmlvdXMua2V5KT09PXByZXZpb3VzKXt0aGlzLmNhcmRzLmRlbGV0ZShwcmV2aW91cy5rZXkpO3RoaXMubWFza0J5dGVzLT1wcmV2aW91cy5tYXNrLmJ5dGVMZW5ndGg7fVxuICAgICAgICAgIGNhcmQucGFnZS5jYXJkc1tjYXJkLmxheWVyXT11bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZWNvcmRQZWFrcygpO3Rocm93IGVycm9yO1xuICAgICAgfWZpbmFsbHl7dGhpcy5yZXRpcmluZy5jbGVhcigpO31cbiAgICAgIGZvcihjb25zdCBbb2xkLGNhcmRdIG9mIG1vdmVkKXtcbiAgICAgICAgY29uc3QgcHJldmlvdXM9Y2FyZC5wYWdlLmNhcmRzW2NhcmQubGF5ZXJdO1xuICAgICAgICBpZihwcmV2aW91cyYmdGhpcy5jYXJkcy5nZXQocHJldmlvdXMua2V5KT09PXByZXZpb3VzKXt0aGlzLmNhcmRzLmRlbGV0ZShwcmV2aW91cy5rZXkpO3RoaXMubWFza0J5dGVzLT1wcmV2aW91cy5tYXNrLmJ5dGVMZW5ndGg7fVxuICAgICAgICBjYXJkLnBhZ2UuY2FyZHNbY2FyZC5sYXllcl09Y2FyZDtjYXJkLnBhZ2UudXNlZD10aGlzLmZyYW1lO3RoaXMuY2FyZHMuc2V0KG9sZC5rZXksY2FyZCk7XG4gICAgICB9XG4gICAgICBmb3IoY29uc3QgW29sZCxjYXJkXSBvZiBtb3ZlZCl0aGlzLnJlYmluZChvbGQsY2FyZCk7XG4gICAgICBmb3IoY29uc3Qgb2xkIG9mIHNvdXJjZXMpdGhpcy5yZW1vdmUob2xkKTtcbiAgICAgIHRoaXMuY29waWVkTGF5ZXJzKz1tb3Zlcy5sZW5ndGg7XG5cbiAgICB9XG4gIH1cbiAgLyoqIENvbXBsZXRlIHRoZSBmcmFtZSBpbiBvbmUgc3RyZWFtaW5nIHBhc3MuIENhbGxlcnMgcHJvdmlkZSB0aGUgcHVibGljIEdQVVxuICAgKiB0cmFuc2ZlciBjb250cmFjdCwgaW5jbHVkaW5nIENQVS1vbmx5IHRlc3RzLiBObyByZW5kZXIgbWF5IHByZWNlZGUgZmluaXNoLiAqL1xuICBmaW5pc2gocmVuZGVyZXI6Q2FyZFRleHR1cmVSZW5kZXJlcil7XG4gICAgY29uc3QgZmluZXN0PW5ldyBNYXA8c3RyaW5nLHtiYXNlTWlwOm51bWJlcjtzaXplOm51bWJlcn0+KCkscGVuZGluZ0xheWVycz1uZXcgTWFwPG51bWJlcixudW1iZXI+KCk7XG4gICAgZm9yKGNvbnN0IHJlcXVlc3Qgb2YgdGhpcy5wZW5kaW5nKXtcbiAgICAgIGNvbnN0IHByZXZpb3VzPWZpbmVzdC5nZXQocmVxdWVzdC5rZXkpO1xuICAgICAgaWYoIXByZXZpb3VzfHxyZXF1ZXN0LmJhc2VNaXA8cHJldmlvdXMuYmFzZU1pcClmaW5lc3Quc2V0KHJlcXVlc3Qua2V5LHtiYXNlTWlwOnJlcXVlc3QuYmFzZU1pcCxzaXplOnJlcXVlc3QudGlsZVNpemUqcmVxdWVzdC5kZW5zaXR5LzIqKnJlcXVlc3QuYmFzZU1pcH0pO1xuICAgIH1cbiAgICBmb3IoY29uc3QgW2tleSxyZXF1ZXN0XSBvZiBmaW5lc3Qpe1xuICAgICAgY29uc3QgY2FyZD10aGlzLmNhcmRzLmdldChrZXkpO2lmKGNhcmQmJmNhcmQuYmFzZU1pcDw9cmVxdWVzdC5iYXNlTWlwKWNvbnRpbnVlO1xuICAgICAgcGVuZGluZ0xheWVycy5zZXQocmVxdWVzdC5zaXplLChwZW5kaW5nTGF5ZXJzLmdldChyZXF1ZXN0LnNpemUpPz8wKSsxKTtcbiAgICB9XG4gICAgdHJ5e2Zvcihjb25zdCByZXF1ZXN0IG9mIHRoaXMucGVuZGluZyl0aGlzLnJhc3RlcihyZXF1ZXN0LHJlbmRlcmVyLGZpbmVzdC5nZXQocmVxdWVzdC5rZXkpIS5iYXNlTWlwLHBlbmRpbmdMYXllcnMpO31maW5hbGx5e3RoaXMucGVuZGluZy5sZW5ndGg9MDt9XG4gICAgdGhpcy5jb21wYWN0KHJlbmRlcmVyKTtcbiAgICBmb3IoY29uc3QgcGFnZSBvZiBbLi4udGhpcy5wYWdlc10pe1xuICAgICAgaWYoIXBhZ2UuY2FyZHMuc29tZShjYXJkPT5jYXJkPy51c2VkPT09dGhpcy5mcmFtZSkmJighcGFnZS5jYXJkcy5zb21lKEJvb2xlYW4pfHx0aGlzLmZyYW1lLXBhZ2UudXNlZD4xMjB8fHRoaXMuYWxsb2NhdGVkUGl4ZWxzPlBJWEVMX0JVREdFVCkpdGhpcy5yZW1vdmUocGFnZSk7XG4gICAgfVxuICAgIHRoaXMuZHJhdygpO1xuICB9XG4gIHByaXZhdGUgYXR0cmlidXRlcyhnZW9tZXRyeTpUSFJFRS5QbGFuZUdlb21ldHJ5LGNhcGFjaXR5Om51bWJlcil7XG4gICAgaWYodGhpcy5wb2xpY3kudHJhbnNwYXJlbnQpZ2VvbWV0cnkuc2V0QXR0cmlidXRlKCdjYXJkT3BhY2l0eScsbmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KSwxKS5zZXRVc2FnZShUSFJFRS5EeW5hbWljRHJhd1VzYWdlKSk7XG4gICAgZ2VvbWV0cnkuc2V0QXR0cmlidXRlKCdjYXJkUmVjdCcsbmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KjQpLDQpLnNldFVzYWdlKFRIUkVFLkR5bmFtaWNEcmF3VXNhZ2UpKTtcbiAgICBnZW9tZXRyeS5zZXRBdHRyaWJ1dGUoJ2NhcmRMYXllcicsbmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KSwxKS5zZXRVc2FnZShUSFJFRS5EeW5hbWljRHJhd1VzYWdlKSk7XG4gICAgZ2VvbWV0cnkuc2V0QXR0cmlidXRlKCdjYXJkQmFuaycsbmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KSwxKS5zZXRVc2FnZShUSFJFRS5EeW5hbWljRHJhd1VzYWdlKSk7XG4gIH1cbiAgcHJpdmF0ZSBjcmVhdGVDaHVuayhiYW5rczpUSFJFRS5EYXRhQXJyYXlUZXh0dXJlW10sY291bnQ6bnVtYmVyLGluZGV4Om51bWJlcil7XG4gICAgY29uc3QgbWF0ZXJpYWw9bmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHttYXA6YmFua3NbMF0hLGFscGhhVGVzdDp0aGlzLnBvbGljeS5hbHBoYVRlc3Q/Py40LHNpZGU6VEhSRUUuRG91YmxlU2lkZSx0b25lTWFwcGVkOmZhbHNlLHRyYW5zcGFyZW50OnRoaXMucG9saWN5LnRyYW5zcGFyZW50Pz9mYWxzZSxkZXB0aFdyaXRlOnRoaXMucG9saWN5LmRlcHRoV3JpdGU/P3RydWUsZGVwdGhUZXN0OnRydWV9KTtcbiAgICBjb25zdCBkZXB0aD1uZXcgVEhSRUUuTWVzaERlcHRoTWF0ZXJpYWwoe21hcDpiYW5rc1swXSEsYWxwaGFUZXN0Oi40LHNpZGU6VEhSRUUuRG91YmxlU2lkZSxkZXB0aFBhY2tpbmc6VEhSRUUuUkdCQURlcHRoUGFja2luZ30pO1xuICAgIGNvbnN0IGRpc3RhbmNlPW5ldyBUSFJFRS5NZXNoRGlzdGFuY2VNYXRlcmlhbCh7bWFwOmJhbmtzWzBdISxhbHBoYVRlc3Q6LjQsc2lkZTpUSFJFRS5Eb3VibGVTaWRlfSk7XG4gICAgY29uc3QgcmVmcmVzaE1hdGVyaWFscz1bbWF0ZXJpYWwsZGVwdGgsZGlzdGFuY2VdLm1hcChpdGVtPT5jb25maWd1cmVDYXJkTWF0ZXJpYWwoaXRlbSxiYW5rcyx0aGlzLm1heFRleHR1cmVCYW5rcyx0aGlzLnBvbGljeS50cmFuc3BhcmVudD8/ZmFsc2UpKTtcbiAgICBjb25zdCBnZW9tZXRyeT1uZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgxLDEpLGNhcGFjaXR5PTIqKk1hdGguY2VpbChNYXRoLmxvZzIoY291bnQpKTt0aGlzLmF0dHJpYnV0ZXMoZ2VvbWV0cnksY2FwYWNpdHkpO1xuICAgIGNvbnN0IG1lc2g9bmV3IFRIUkVFLkluc3RhbmNlZE1lc2goZ2VvbWV0cnksbWF0ZXJpYWwsY2FwYWNpdHkpO1xuICAgIGNvbnN0IGNodW5rOkRyYXdDaHVuaz17YmFua3MscGFnZXM6W10sZW50cmllczpbXSxpZHM6W10sZmVldDpbXSxvcmRlcnM6W10sZ2VvbWV0cnksbWF0ZXJpYWwsZGVwdGgsZGlzdGFuY2UsbWVzaCxjYXBhY2l0eSx1c2VkOnRoaXMuZnJhbWUscmVmcmVzaE1hdGVyaWFsc307XG4gICAgdGhpcy5jb25maWd1cmVDaHVua01lc2goY2h1bmssaW5kZXgpO3RoaXMuY2h1bmtzW2luZGV4XT1jaHVuaztyZXR1cm4gY2h1bms7XG4gIH1cbiAgcHJpdmF0ZSBjb25maWd1cmVDaHVua01lc2goY2h1bms6RHJhd0NodW5rLGluZGV4Om51bWJlcil7XG4gICAgY29uc3QgbWVzaD1jaHVuay5tZXNoO1xuICAgIC8vIEtlZXAgY2h1bmsgb3JkZXJpbmcgd2l0aGluIHRoZSBjYWxsZXIncyBwYXNzIGxldmVsLCBlLmcuIHJlbWFpbnMgLTEgYW5kXG4gICAgLy8gYm9kaWVzIDAuIEV2ZXJ5IGNodW5rIGZvbGxvd3MgbmF0aXZlIG1lc2hlcyBhdCB0aGUgc2FtZSBiYXNlIGxldmVsLFxuICAgIC8vIGlycmVzcGVjdGl2ZSBvZiBiYW5rIGNvdW50LCBjYWNoZSBzdGF0ZSBvciBtYXRlcmlhbCBjcmVhdGlvbiBvcmRlci5cbiAgICBtZXNoLm5hbWU9J1BhaW50ZWRDYXJkcyc7bWVzaC5jYXN0U2hhZG93PXRoaXMucG9saWN5LmNhc3RTaGFkb3c/P3RydWU7bWVzaC5yZW5kZXJPcmRlcj0odGhpcy5wb2xpY3kucmVuZGVyT3JkZXI/PzApKy4wMDAxKy4wMDA5KmluZGV4LyhpbmRleCsxKTttZXNoLnJlY2VpdmVTaGFkb3c9dHJ1ZTttZXNoLmN1c3RvbURlcHRoTWF0ZXJpYWw9Y2h1bmsuZGVwdGg7bWVzaC5jdXN0b21EaXN0YW5jZU1hdGVyaWFsPWNodW5rLmRpc3RhbmNlO21lc2guaW5zdGFuY2VNYXRyaXguc2V0VXNhZ2UoVEhSRUUuRHluYW1pY0RyYXdVc2FnZSk7XG4gICAgbWVzaC5yYXljYXN0PShyYXljYXN0ZXIsaW50ZXJzZWN0aW9ucyk9PnRoaXMucmF5Y2FzdChjaHVuayxyYXljYXN0ZXIsaW50ZXJzZWN0aW9ucyk7XG4gICAgbWVzaC51c2VyRGF0YS5pZHM9Y2h1bmsuaWRzO21lc2gudXNlckRhdGEuY2FyZHM9Y2h1bmsuZW50cmllczttZXNoLnVzZXJEYXRhLmZlZXQ9Y2h1bmsuZmVldDttZXNoLnVzZXJEYXRhLm9yZGVycz1jaHVuay5vcmRlcnM7bWVzaC51c2VyRGF0YS5iYW5rcz1jaHVuay5wYWdlcztcbiAgICBtZXNoLnVzZXJEYXRhLnBhaW50ZWRIaXQ9KGluc3RhbmNlOm51bWJlcix1dj86e3g6bnVtYmVyO3k6bnVtYmVyfSk9PnRoaXMuaGl0KGNodW5rLGluc3RhbmNlLHV2KTtcbiAgICB0aGlzLmRyYXdHcm91cC5hZGQobWVzaCk7XG4gIH1cbiAgcHJpdmF0ZSByZXNpemVDaHVuayhjaHVuazpEcmF3Q2h1bmssY291bnQ6bnVtYmVyLGluZGV4Om51bWJlcil7XG4gICAgdGhpcy5kcmF3R3JvdXAucmVtb3ZlKGNodW5rLm1lc2gpO2NodW5rLm1lc2guZGlzcG9zZSgpO2NodW5rLmdlb21ldHJ5LmRpc3Bvc2UoKTtcbiAgICBjaHVuay5jYXBhY2l0eT0yKipNYXRoLmNlaWwoTWF0aC5sb2cyKGNvdW50KSk7dGhpcy5hdHRyaWJ1dGVzKGNodW5rLmdlb21ldHJ5LGNodW5rLmNhcGFjaXR5KTtcbiAgICBjaHVuay5tZXNoPW5ldyBUSFJFRS5JbnN0YW5jZWRNZXNoKGNodW5rLmdlb21ldHJ5LGNodW5rLm1hdGVyaWFsLGNodW5rLmNhcGFjaXR5KTt0aGlzLmNvbmZpZ3VyZUNodW5rTWVzaChjaHVuayxpbmRleCk7XG4gIH1cbiAgcHJpdmF0ZSBoaWRlQ2h1bmsoY2h1bms6RHJhd0NodW5rKXtcbiAgICBjaHVuay5tZXNoLnZpc2libGU9ZmFsc2U7Y2h1bmsubWVzaC5jb3VudD0wO1xuICAgIGNodW5rLmVudHJpZXMubGVuZ3RoPWNodW5rLmlkcy5sZW5ndGg9Y2h1bmsuZmVldC5sZW5ndGg9Y2h1bmsub3JkZXJzLmxlbmd0aD1jaHVuay5wYWdlcy5sZW5ndGg9Y2h1bmsuYmFua3MubGVuZ3RoPTA7XG4gICAgZm9yKGNvbnN0IG1hdGVyaWFsIG9mIFtjaHVuay5tYXRlcmlhbCxjaHVuay5kZXB0aCxjaHVuay5kaXN0YW5jZV0pbWF0ZXJpYWwubWFwPW51bGw7XG4gICAgZm9yKGNvbnN0IHJlZnJlc2ggb2YgY2h1bmsucmVmcmVzaE1hdGVyaWFscylyZWZyZXNoKCk7XG4gIH1cbiAgLyoqIEdyZWVkaWx5IHJldGFpbiB0aGUgbGl0ZXJhbCBzdWJtaXNzaW9uIHNlcXVlbmNlLiBBIG5pbnRoIGRpc3RpbmN0IHBhZ2VcbiAgICogc3RhcnRzIGEgbmV3IGRyYXc7IHBhZ2VzIG1heSByZWN1ciBpbiBsYXRlciBkcmF3cyB3aXRob3V0IGV4dHJhIHRleHR1cmVzLiAqL1xuICBwcml2YXRlIGRyYXcoKXtcbiAgICBsZXQgc3RhcnQ9MCxpbmRleD0wO1xuICAgIHdoaWxlKHN0YXJ0PHRoaXMuaW5zdGFuY2VPcmRlcil7XG4gICAgICBjb25zdCBwYWdlQmFua3M9bmV3IE1hcDxQYWdlLG51bWJlcj4oKTtsZXQgZW5kPXN0YXJ0O1xuICAgICAgd2hpbGUoZW5kPHRoaXMuaW5zdGFuY2VPcmRlcil7XG4gICAgICAgIGNvbnN0IGNhcmQ9dGhpcy5pbnN0YW5jZXNbZW5kXSEuY2FyZCE7XG4gICAgICAgIGlmKCFwYWdlQmFua3MuaGFzKGNhcmQucGFnZSkpe1xuICAgICAgICAgIGlmKHBhZ2VCYW5rcy5zaXplPT09dGhpcy5tYXhUZXh0dXJlQmFua3MpYnJlYWs7XG4gICAgICAgICAgcGFnZUJhbmtzLnNldChjYXJkLnBhZ2UscGFnZUJhbmtzLnNpemUpO1xuICAgICAgICB9XG4gICAgICAgIGVuZCsrO1xuICAgICAgfVxuICAgICAgbGV0IGNodW5rPXRoaXMuY2h1bmtzW2luZGV4XTtcbiAgICAgIGlmKCFjaHVuayljaHVuaz10aGlzLmNyZWF0ZUNodW5rKFsuLi5wYWdlQmFua3Mua2V5cygpXS5tYXAocGFnZT0+cGFnZS50ZXh0dXJlKSxlbmQtc3RhcnQsaW5kZXgpO1xuICAgICAgY2h1bmsuYmFua3MubGVuZ3RoPWNodW5rLnBhZ2VzLmxlbmd0aD0wO1xuICAgICAgZm9yKGNvbnN0IHBhZ2Ugb2YgcGFnZUJhbmtzLmtleXMoKSl7Y2h1bmsucGFnZXMucHVzaChwYWdlKTtjaHVuay5iYW5rcy5wdXNoKHBhZ2UudGV4dHVyZSk7fVxuICAgICAgZm9yKGNvbnN0IG1hdGVyaWFsIG9mIFtjaHVuay5tYXRlcmlhbCxjaHVuay5kZXB0aCxjaHVuay5kaXN0YW5jZV0pbWF0ZXJpYWwubWFwPWNodW5rLmJhbmtzWzBdITtcbiAgICAgIGZvcihjb25zdCByZWZyZXNoIG9mIGNodW5rLnJlZnJlc2hNYXRlcmlhbHMpcmVmcmVzaCgpO1xuICAgICAgaWYoZW5kLXN0YXJ0PmNodW5rLmNhcGFjaXR5KXRoaXMucmVzaXplQ2h1bmsoY2h1bmssZW5kLXN0YXJ0LGluZGV4KTtcbiAgICAgIGNvbnN0IHttZXNoLGdlb21ldHJ5fT1jaHVuayxsYXllcnM9Z2VvbWV0cnkuZ2V0QXR0cmlidXRlKCdjYXJkTGF5ZXInKSxyZWN0cz1nZW9tZXRyeS5nZXRBdHRyaWJ1dGUoJ2NhcmRSZWN0JyksYmFua3M9Z2VvbWV0cnkuZ2V0QXR0cmlidXRlKCdjYXJkQmFuaycpO2xldCByYWRpdXM9MDtcbiAgICAgIGNodW5rLmVudHJpZXMubGVuZ3RoPWNodW5rLmlkcy5sZW5ndGg9Y2h1bmsuZmVldC5sZW5ndGg9Y2h1bmsub3JkZXJzLmxlbmd0aD0wO2NodW5rLnVzZWQ9dGhpcy5mcmFtZTttZXNoLmNvdW50PWVuZC1zdGFydDttZXNoLnZpc2libGU9dHJ1ZTtcbiAgICAgIGZvcihsZXQgb3JkZXI9c3RhcnQ7b3JkZXI8ZW5kO29yZGVyKyspe1xuICAgICAgICBjb25zdCByb3c9dGhpcy5pbnN0YW5jZXNbb3JkZXJdISxjYXJkPXJvdy5jYXJkISxpPW9yZGVyLXN0YXJ0O1xuICAgICAgICBjaHVuay5lbnRyaWVzLnB1c2goY2FyZCk7Y2h1bmsuaWRzLnB1c2gocm93LmlkKTtjaHVuay5mZWV0LnB1c2gocm93LmZvb3QpO2NodW5rLm9yZGVycy5wdXNoKG9yZGVyKTtcbiAgICAgICAgLy8gUHJlc2VydmUgUGxhbmVHZW9tZXRyeSguLi4pLnRyYW5zbGF0ZSguLi4pIGZsb2F0MzIgdmVydGljZXMsIGtlZXBpbmdcbiAgICAgICAgLy8gbWlwIGludGVycG9sYXRpb24gYW5kIGN1dG91dCBlZGdlcyBvbiB0aGVpciBvcmlnaW5hbCBhdXRob3JlZCBncmlkLlxuICAgICAgICBjb25zdCBoYWxmPWNhcmQudGlsZVNpemUvMixsb3c9TWF0aC5mcm91bmQoTWF0aC5mcm91bmQoLWhhbGYvVElMVCkrcm93LmZvb3QvVElMVCksaGlnaD1NYXRoLmZyb3VuZChNYXRoLmZyb3VuZChoYWxmL1RJTFQpK3Jvdy5mb290L1RJTFQpO1xuICAgICAgICByZWN0cy5zZXRYWVpXKGksLWhhbGYsbG93LGhhbGYsaGlnaCk7cmFkaXVzPU1hdGgubWF4KHJhZGl1cyxNYXRoLmh5cG90KGhhbGYsbG93KSxNYXRoLmh5cG90KGhhbGYsaGlnaCkpO1xuICAgICAgICBtZXNoLnNldE1hdHJpeEF0KGkscm93Lm1hdHJpeCk7bGF5ZXJzLnNldFgoaSxjYXJkLmxheWVyKTtiYW5rcy5zZXRYKGkscGFnZUJhbmtzLmdldChjYXJkLnBhZ2UpISk7XG4gICAgICAgIGlmKHRoaXMucG9saWN5LnRyYW5zcGFyZW50KWdlb21ldHJ5LmdldEF0dHJpYnV0ZSgnY2FyZE9wYWNpdHknKS5zZXRYKGkscm93Lm9wYWNpdHkpO1xuICAgICAgfVxuICAgICAgaWYodGhpcy5wb2xpY3kudHJhbnNwYXJlbnQpZ2VvbWV0cnkuZ2V0QXR0cmlidXRlKCdjYXJkT3BhY2l0eScpLm5lZWRzVXBkYXRlPXRydWU7XG4gICAgICByZWN0cy5uZWVkc1VwZGF0ZT1sYXllcnMubmVlZHNVcGRhdGU9YmFua3MubmVlZHNVcGRhdGU9bWVzaC5pbnN0YW5jZU1hdHJpeC5uZWVkc1VwZGF0ZT10cnVlO1xuICAgICAgZ2VvbWV0cnkuYm91bmRpbmdTcGhlcmU/Pz1uZXcgVEhSRUUuU3BoZXJlKCk7Z2VvbWV0cnkuYm91bmRpbmdTcGhlcmUuY2VudGVyLnNldCgwLDAsMCk7Z2VvbWV0cnkuYm91bmRpbmdTcGhlcmUucmFkaXVzPXJhZGl1czttZXNoLmNvbXB1dGVCb3VuZGluZ1NwaGVyZSgpO1xuICAgICAgc3RhcnQ9ZW5kO2luZGV4Kys7XG4gICAgfVxuICAgIC8vIFNoYWRvd3MgdHJhdmVyc2UgY2hpbGRyZW4gZGlyZWN0bHk7IGNvbG9yIHBhc3NlcyBzb3J0IHJlbmRlck9yZGVyLiBCb3RoXG4gICAgLy8gbXVzdCBzZWUgdGhlIGlkZW50aWNhbCBjaHVuayBvcmRlciBldmVuIHdoZW4gYSBwb29sZWQgbWVzaCBncm93cy5cbiAgICBmb3IobGV0IGk9MDtpPHRoaXMuY2h1bmtzLmxlbmd0aDtpKyspdGhpcy5kcmF3R3JvdXAuY2hpbGRyZW5baV09dGhpcy5jaHVua3NbaV0hLm1lc2g7XG4gICAgdGhpcy5kcmF3R3JvdXAuY2hpbGRyZW4ubGVuZ3RoPXRoaXMuY2h1bmtzLmxlbmd0aDtcbiAgICBpZihpbmRleCl7aWYodGhpcy5kcmF3R3JvdXAucGFyZW50IT09dGhpcy5zY2VuZSl0aGlzLnNjZW5lLmFkZCh0aGlzLmRyYXdHcm91cCk7fVxuICAgIGZvcihsZXQgaT10aGlzLmNodW5rcy5sZW5ndGgtMTtpPj1pbmRleDtpLS0pe1xuICAgICAgY29uc3QgY2h1bms9dGhpcy5jaHVua3NbaV0hO3RoaXMuaGlkZUNodW5rKGNodW5rKTtcbiAgICAgIGlmKCF0aGlzLnBhZ2VzLmxlbmd0aHx8dGhpcy5mcmFtZS1jaHVuay51c2VkPjEyMCl7dGhpcy5yZW1vdmVDaHVuayhjaHVuayk7dGhpcy5jaHVua3Muc3BsaWNlKGksMSk7fVxuICAgIH1cbiAgICBpZighdGhpcy5jaHVua3MubGVuZ3RoKXRoaXMuc2NlbmUucmVtb3ZlKHRoaXMuZHJhd0dyb3VwKTtcbiAgfVxuICBwcml2YXRlIHJlbW92ZUNodW5rKGNodW5rOkRyYXdDaHVuayl7XG4gICAgdGhpcy5oaWRlQ2h1bmsoY2h1bmspO3RoaXMuZHJhd0dyb3VwLnJlbW92ZShjaHVuay5tZXNoKTtjaHVuay5tZXNoLmRpc3Bvc2UoKTtjaHVuay5nZW9tZXRyeS5kaXNwb3NlKCk7Y2h1bmsubWF0ZXJpYWwuZGlzcG9zZSgpO2NodW5rLmRlcHRoLmRpc3Bvc2UoKTtjaHVuay5kaXN0YW5jZS5kaXNwb3NlKCk7XG4gICAgY2h1bmsuZW50cmllcy5sZW5ndGg9Y2h1bmsuaWRzLmxlbmd0aD1jaHVuay5mZWV0Lmxlbmd0aD1jaHVuay5vcmRlcnMubGVuZ3RoPWNodW5rLnBhZ2VzLmxlbmd0aD1jaHVuay5iYW5rcy5sZW5ndGg9MDtcbiAgfVxuICAvKiogV2l0aCBubyByZXRhaW5lZCBwaXhlbHMgb3IgcGFpbnRlciBjbG9zdXJlcywgcmVzdG9yYXRpb24gZGVsaWJlcmF0ZWx5XG4gICAqIHJlYnVpbGRzIHZpc2libGUgY2FyZHMgZnJvbSB0aGUgbmV4dCBvcmRpbmFyeSBmcmFtZSdzIGN1cnJlbnQgc3RhdGUuICovXG4gIGludmFsaWRhdGVHUFUoKXt0aGlzLmRpc3Bvc2UoKTt9XG4gIHByaXZhdGUgcmF5Y2FzdChjaHVuazpEcmF3Q2h1bmsscmF5Y2FzdGVyOlRIUkVFLlJheWNhc3RlcixpbnRlcnNlY3Rpb25zOlRIUkVFLkludGVyc2VjdGlvbltdKXtcbiAgICBpZih0aGlzLnBvbGljeS5waWNrYWJsZT09PWZhbHNlKXJldHVybjtcbiAgICBjb25zdCBtZXNoPWNodW5rLm1lc2g7aWYoIW1lc2guYm91bmRpbmdTcGhlcmUpbWVzaC5jb21wdXRlQm91bmRpbmdTcGhlcmUoKTtcbiAgICBpZighcmF5Y2FzdGVyLnJheS5pbnRlcnNlY3RzU3BoZXJlKHRoaXMucmF5U3BoZXJlLmNvcHkobWVzaC5ib3VuZGluZ1NwaGVyZSEpLmFwcGx5TWF0cml4NChtZXNoLm1hdHJpeFdvcmxkKSkpcmV0dXJuO1xuICAgIC8vIEdQVSBjYXJkUmVjdCBleHBhbmRzIHRoZSBjYW5vbmljYWwgdW5pdCBxdWFkLiBSYXljYXN0IHRoZSBzYW1lIGF1dGhvcmVkXG4gICAgLy8gcGxhbmUsIHRoZW4gbGV0IHBhaW50ZWRIaXQgc2FtcGxlIHRoZSBpZGVudGljYWwgc291cmNlIGFscGhhIHRleGVsLlxuICAgIGZvcihsZXQgaT0wO2k8bWVzaC5jb3VudDtpKyspe1xuICAgICAgY29uc3QgY2FyZD1jaHVuay5lbnRyaWVzW2ldISxoYWxmPWNhcmQudGlsZVNpemUvMixmb290PWNodW5rLmZlZXRbaV0hO1xuICAgICAgY29uc3QgbG93PU1hdGguZnJvdW5kKE1hdGguZnJvdW5kKC1oYWxmL1RJTFQpK2Zvb3QvVElMVCksaGlnaD1NYXRoLmZyb3VuZChNYXRoLmZyb3VuZChoYWxmL1RJTFQpK2Zvb3QvVElMVCk7XG4gICAgICB0aGlzLm9mZnNldC5tYWtlU2NhbGUoY2FyZC50aWxlU2l6ZSxoaWdoLWxvdywxKS5zZXRQb3NpdGlvbigwLChoaWdoK2xvdykvMiwwKTtcbiAgICAgIG1lc2guZ2V0TWF0cml4QXQoaSx0aGlzLm1hdHJpeCk7dGhpcy5yYXlQcm9iZS5tYXRyaXhXb3JsZC5jb3B5KG1lc2gubWF0cml4V29ybGQpLm11bHRpcGx5KHRoaXMubWF0cml4KS5tdWx0aXBseSh0aGlzLm9mZnNldCk7XG4gICAgICB0aGlzLnJheUhpdHMubGVuZ3RoPTA7dGhpcy5yYXlQcm9iZS5yYXljYXN0KHJheWNhc3Rlcix0aGlzLnJheUhpdHMpO1xuICAgICAgZm9yKGNvbnN0IGhpdCBvZiB0aGlzLnJheUhpdHMpe2hpdC5pbnN0YW5jZUlkPWk7aGl0Lm9iamVjdD1tZXNoO2ludGVyc2VjdGlvbnMucHVzaChoaXQpO31cbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBoaXQoY2h1bms6RHJhd0NodW5rLGluZGV4Om51bWJlcix1dj86e3g6bnVtYmVyO3k6bnVtYmVyfSl7XG4gICAgY29uc3QgY2FyZD1jaHVuay5lbnRyaWVzW2luZGV4XTtpZih0aGlzLnBvbGljeS5waWNrYWJsZT09PWZhbHNlfHwhY2FyZHx8IXV2KXJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gY2FyZE1hc2tIaXQoY2FyZC5tYXNrLGNhcmQuc291cmNlU2l6ZSxjYXJkLnNvdXJjZVNpemUsdXYpO1xuICB9XG4gIG9iamVjdHMoKXtyZXR1cm4gdGhpcy5jaHVua3MuZmlsdGVyKGNodW5rPT5jaHVuay5tZXNoLnZpc2libGUpLm1hcChjaHVuaz0+Y2h1bmsubWVzaCk7fVxuICAvLyBPd25lZCB0eXBlZC1hcnJheSBhbmQgdGV4dHVyZSBzdG9yYWdlIGVzdGltYXRlcywgbm90IHRvdGFsIHByb2Nlc3MgUlNTIG9yXG4gIC8vIENhbnZhcyBiYWNraW5nIHN0b3Jlcy4gY3B1Qnl0ZXMgZXhjbHVkZXMgc2NyYXRjaCBmb3IgZXhpc3RpbmcgY29uc3VtZXJzLlxuICBzdGF0cygpe1xuICAgIGNvbnN0IHBpeGVscz10aGlzLmFsbG9jYXRlZFBpeGVscyx0cmFuc2Zlcj10aGlzLm1pcFVwbG9hZGVyLnN0YXRzKCk7XG4gICAgY29uc3QgYnl0ZXM9KHBhZ2U6UGFnZSk9PnBhZ2UubWlwQnl0ZXM7XG4gICAgY29uc3QgZ3B1Qnl0ZXM9TWF0aC5jZWlsKHBpeGVscyo0KjQvMyksYWxsb2NhdGVkTWlwQnl0ZXM9dGhpcy5wYWdlcy5yZWR1Y2UoKHN1bSxwYWdlKT0+c3VtK2J5dGVzKHBhZ2UpLDApLHJldGlyZWRHcHVCeXRlcz1bLi4udGhpcy5yZXRpcmluZ10ucmVkdWNlKChzdW0scGFnZSk9PnN1bSsocGFnZS51cGxvYWRlZD9ieXRlcyhwYWdlKTowKSwwKTtcbiAgICBjb25zdCBkcmF3QnVmZmVyQnl0ZXM9dGhpcy5jaHVua3MucmVkdWNlKChzdW0sY2h1bmspPT5zdW0rY2h1bmsubWVzaC5pbnN0YW5jZU1hdHJpeC5hcnJheS5ieXRlTGVuZ3RoK09iamVjdC52YWx1ZXMoY2h1bmsuZ2VvbWV0cnkuYXR0cmlidXRlcykucmVkdWNlKCh0b3RhbCxhdHRyaWJ1dGUpPT50b3RhbCthdHRyaWJ1dGUuYXJyYXkuYnl0ZUxlbmd0aCwwKSsoY2h1bmsuZ2VvbWV0cnkuaW5kZXg/LmFycmF5LmJ5dGVMZW5ndGg/PzApLDApO1xuICAgIGNvbnN0IGNwdUJ5dGVzPXRoaXMubWFza0J5dGVzK3RoaXMucGVuZGluZ01hc2tCeXRlcyt0aGlzLnBlbmRpbmdSZ2JhQnl0ZXMrdGhpcy5yb3dTY3JhdGNoLmJ5dGVMZW5ndGgrdGhpcy5lbXB0eVJnYmEuYnl0ZUxlbmd0aDtcbiAgICByZXR1cm57cGFnZXM6dGhpcy5wYWdlcy5sZW5ndGgsY2FyZHM6dGhpcy5jYXJkcy5zaXplLHBpeGVscyxkcmF3Q2h1bmtzOnRoaXMuY2h1bmtzLmZpbHRlcihjaHVuaz0+Y2h1bmsubWVzaC52aXNpYmxlKS5sZW5ndGgscG9vbGVkRHJhd0NodW5rczp0aGlzLmNodW5rcy5sZW5ndGgsZHJhd0NhcGFjaXR5OnRoaXMuY2h1bmtzLnJlZHVjZSgoc3VtLGNodW5rKT0+c3VtK2NodW5rLmNhcGFjaXR5LDApLGRyYXdCdWZmZXJCeXRlcyxtYXhUZXh0dXJlQmFua3M6dGhpcy5tYXhUZXh0dXJlQmFua3MsYXJyYXlDcHVCeXRlczowLGNwdUJ5dGVzLGdwdUJ5dGVzLGFsbG9jYXRlZE1pcEJ5dGVzLGNhbnZhc0JhY2tpbmdCeXRlczpbLi4udGhpcy5jYW52YXNlcy52YWx1ZXMoKV0ucmVkdWNlKChzdW0sY2FudmFzKT0+c3VtK2NhbnZhcy53aWR0aCpjYW52YXMuaGVpZ2h0KjQsMCksbWFza0J5dGVzOnRoaXMubWFza0J5dGVzLHBlbmRpbmdNYXNrQnl0ZXM6dGhpcy5wZW5kaW5nTWFza0J5dGVzLHBlbmRpbmdSZ2JhQnl0ZXM6dGhpcy5wZW5kaW5nUmdiYUJ5dGVzLHJvd1NjcmF0Y2hCeXRlczp0aGlzLnJvd1NjcmF0Y2guYnl0ZUxlbmd0aCxyZXRpcmVkR3B1Qnl0ZXMscmFzdGVyQ2FjaGU6dGhpcy5yYXN0ZXJDYWNoZS5zdGF0cygpLG93bmVkQ3B1Qnl0ZXM6Y3B1Qnl0ZXMrdHJhbnNmZXIuc2NyYXRjaENwdUJ5dGVzK3RoaXMucmFzdGVyQ2FjaGUuc3RhdHMoKS5vd25lZEJ5dGVzLG93bmVkR3B1Qnl0ZXM6dGhpcy5wYWdlcy5yZWR1Y2UoKHN1bSxwYWdlKT0+c3VtKyhwYWdlLnVwbG9hZGVkP2J5dGVzKHBhZ2UpOjApLDApK3RyYW5zZmVyLnNjcmF0Y2hHcHVCeXRlcyxwZWFrUGVuZGluZ1JnYmFCeXRlczp0aGlzLnBlYWtQZW5kaW5nUmdiYUJ5dGVzLHBlYWtPd25lZENwdUJ5dGVzOnRoaXMucGVha093bmVkQ3B1Qnl0ZXMscGVha093bmVkR3B1Qnl0ZXM6dGhpcy5wZWFrT3duZWRHcHVCeXRlcyxwZWFrUmV0aXJlZEdwdUJ5dGVzOnRoaXMucGVha1JldGlyZWRHcHVCeXRlcyxyYXN0ZXJpemF0aW9uczp0aGlzLnJhc3Rlcml6YXRpb25zLGNvcGllZExheWVyczp0aGlzLmNvcGllZExheWVycyxyYXN0ZXJTdGFnZXM6ey4uLnRoaXMucmFzdGVyU3RhZ2VzfSxyYXN0ZXJXb3JrV2FsbE1zOnRoaXMucmFzdGVyV29ya1dhbGxNcywuLi50cmFuc2Zlcn07XG4gIH1cbiAgcHJpdmF0ZSByZWNvcmRQZWFrcygpe1xuICAgIC8vIFNhbXBsaW5nIG9jY3VycyBzZXZlcmFsIHRpbWVzIHBlciByYXN0ZXIuIFByZXNlcnZlIHRoZSBzYW1lIG93bmVyc2hpcCBhbmRcbiAgICAvLyBzYW1wbGUgcG9pbnRzIHdpdGhvdXQgcmVidWlsZGluZyB1bnJlbGF0ZWQgZHJhdy9DYW52YXMvcHVibGljIGNvdW50ZXJzLlxuICAgIGNvbnN0IHRyYW5zZmVyPXRoaXMubWlwVXBsb2FkZXIuc3RhdHMoKSxjcHVCeXRlcz10aGlzLm1hc2tCeXRlcyt0aGlzLnBlbmRpbmdNYXNrQnl0ZXMrdGhpcy5wZW5kaW5nUmdiYUJ5dGVzK3RoaXMucm93U2NyYXRjaC5ieXRlTGVuZ3RoK3RoaXMuZW1wdHlSZ2JhLmJ5dGVMZW5ndGg7XG4gICAgY29uc3Qgb3duZWRDcHVCeXRlcz1jcHVCeXRlcyt0cmFuc2Zlci5zY3JhdGNoQ3B1Qnl0ZXMrdGhpcy5yYXN0ZXJDYWNoZS5zdGF0cygpLm93bmVkQnl0ZXM7XG4gICAgbGV0IG93bmVkR3B1Qnl0ZXM9dHJhbnNmZXIuc2NyYXRjaEdwdUJ5dGVzLHJldGlyZWRHcHVCeXRlcz0wO1xuICAgIGZvcihjb25zdCBwYWdlIG9mIHRoaXMucGFnZXMpaWYocGFnZS51cGxvYWRlZClvd25lZEdwdUJ5dGVzKz1wYWdlLm1pcEJ5dGVzO1xuICAgIGZvcihjb25zdCBwYWdlIG9mIHRoaXMucmV0aXJpbmcpaWYocGFnZS51cGxvYWRlZClyZXRpcmVkR3B1Qnl0ZXMrPXBhZ2UubWlwQnl0ZXM7XG4gICAgdGhpcy5wZWFrUGVuZGluZ1JnYmFCeXRlcz1NYXRoLm1heCh0aGlzLnBlYWtQZW5kaW5nUmdiYUJ5dGVzLHRoaXMucGVuZGluZ1JnYmFCeXRlcyk7dGhpcy5wZWFrT3duZWRDcHVCeXRlcz1NYXRoLm1heCh0aGlzLnBlYWtPd25lZENwdUJ5dGVzLG93bmVkQ3B1Qnl0ZXMpO3RoaXMucGVha093bmVkR3B1Qnl0ZXM9TWF0aC5tYXgodGhpcy5wZWFrT3duZWRHcHVCeXRlcyxvd25lZEdwdUJ5dGVzKTt0aGlzLnBlYWtSZXRpcmVkR3B1Qnl0ZXM9TWF0aC5tYXgodGhpcy5wZWFrUmV0aXJlZEdwdUJ5dGVzLHJldGlyZWRHcHVCeXRlcyk7XG4gIH1cbiAgcHJpdmF0ZSByZW1vdmUocGFnZTpQYWdlKXtcbiAgICBjb25zdCBzb3VyY2VTaXplcz1uZXcgU2V0KHBhZ2UuY2FyZHMuZmxhdE1hcChjYXJkPT5jYXJkP1tjYXJkLnNvdXJjZVNpemVdOltdKSk7XG4gICAgZm9yKGNvbnN0IGNhcmQgb2YgcGFnZS5jYXJkcylpZihjYXJkJiZ0aGlzLmNhcmRzLmdldChjYXJkLmtleSk9PT1jYXJkKXt0aGlzLmNhcmRzLmRlbGV0ZShjYXJkLmtleSk7dGhpcy5tYXNrQnl0ZXMtPWNhcmQubWFzay5ieXRlTGVuZ3RoO31cbiAgICBwYWdlLnRleHR1cmUuZGlzcG9zZSgpO3RoaXMucGFnZXMuc3BsaWNlKHRoaXMucGFnZXMuaW5kZXhPZihwYWdlKSwxKTt0aGlzLmFsbG9jYXRlZFBpeGVscy09cGFnZS50ZXh0dXJlLmltYWdlLndpZHRoKnBhZ2UudGV4dHVyZS5pbWFnZS5oZWlnaHQqcGFnZS50ZXh0dXJlLmltYWdlLmRlcHRoO1xuICAgIC8vIFJlc2lkZW50IGFycmF5cyBjYW4gYmUgc21hbGxlciB0aGFuIHRoZWlyIGZ1bGwtcmVzb2x1dGlvbiBzY3JhdGNoLCBhbmRcbiAgICAvLyBkaWZmZXJlbnQgc291cmNlIHNpemVzIGNhbiBzaGFyZSBhbiBpZGVudGljYWxseSBzaXplZCByZXNpZGVudCBwYWdlLlxuICAgIGZvcihjb25zdCBzaXplIG9mIHNvdXJjZVNpemVzKWlmKCF0aGlzLnBhZ2VzLnNvbWUob3RoZXI9Pm90aGVyLmNhcmRzLnNvbWUoY2FyZD0+Y2FyZD8uc291cmNlU2l6ZT09PXNpemUpKSl0aGlzLm1pcFVwbG9hZGVyLnJlbGVhc2VTaXplKHNpemUsc2l6ZSk7XG4gIH1cbiAgZGlzcG9zZSgpe1xuICAgIGZvcihjb25zdCBjaHVuayBvZiB0aGlzLmNodW5rcyl0aGlzLnJlbW92ZUNodW5rKGNodW5rKTt0aGlzLmNodW5rcy5sZW5ndGg9MDt0aGlzLnNjZW5lLnJlbW92ZSh0aGlzLmRyYXdHcm91cCk7dGhpcy5pbnN0YW5jZXMubGVuZ3RoPTA7dGhpcy5iaW5kaW5ncy5jbGVhcigpO1xuICAgIHRoaXMucmFzdGVyQ2FjaGUuY2xlYXIoKTtmb3IoY29uc3QgcGFnZSBvZiBbLi4udGhpcy5wYWdlc10pdGhpcy5yZW1vdmUocGFnZSk7dGhpcy5yZXRpcmluZy5jbGVhcigpO2Zvcihjb25zdCBjYW52YXMgb2YgdGhpcy5jYW52YXNlcy52YWx1ZXMoKSljYW52YXMud2lkdGg9Y2FudmFzLmhlaWdodD0xO3RoaXMuY2FudmFzZXMuY2xlYXIoKTt0aGlzLnBlbmRpbmcubGVuZ3RoPTA7dGhpcy5wZW5kaW5nUmdiYUJ5dGVzPXRoaXMucGVuZGluZ01hc2tCeXRlcz10aGlzLm1hc2tCeXRlcz0wO3RoaXMucm93U2NyYXRjaD1uZXcgVWludDhBcnJheSgwKTt0aGlzLmVtcHR5UmdiYT1uZXcgVWludDhBcnJheSgwKTt0aGlzLm1pcFVwbG9hZGVyLmRpc3Bvc2UoKTt0aGlzLnJheVByb2JlLmdlb21ldHJ5LmRpc3Bvc2UoKTt0aGlzLnJheVByb2JlLm1hdGVyaWFsLmRpc3Bvc2UoKTt9XG5cbn1cblxuLyoqIEZ1bGwgYXV0aG9yZWQgZG9tYWlucyBwcmVzZXJ2ZSB0aGUgb3JpZ2luYWwgbWlwIGdyaWQgYW5kIHRlcm1pbmFsIG1pcFxuICogbGV2ZWxzLCBpbmNsdWRpbmcgbm9uLXBvd2VyLW9mLXR3byBhY3Rpb24gdGlsZXMuIFRyYW5zcGFyZW50IHBhZGRpbmcgaXMgbm90XG4gKiBzYWZlIHRvIHRyaW0gbWVyZWx5IGJlY2F1c2UgYmFzZSBSR0JBIHJlc3RvcmF0aW9uIGlzIGV4YWN0LiBFbXB0eSBjYXJkcyBoYXZlXG4gKiBubyB2aXNpYmxlIG1pcCBhdCBhbnkgZGlzdGFuY2UgYW5kIGNhbiBzaGFyZSB0aGUgbWluaW11bSBhbGxvY2F0aW9uLiAqL1xuZnVuY3Rpb24gaGFzUGFpbnQocmdiYTpVaW50OENsYW1wZWRBcnJheSl7XG4gIGZvcihsZXQgaT0zO2k8cmdiYS5sZW5ndGg7aSs9NClpZihyZ2JhW2ldKXJldHVybiB0cnVlO1xuICByZXR1cm4gZmFsc2U7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVEsdUJBQXNCO0FBQzlCLFNBQVEsa0JBQWlCLG1CQUFrQjtBQUMzQyxTQUFRLGlCQUFnQixpQkFBZ0Isd0JBQWlFO0FBQ3pHLFNBQVMscUJBQXFCO0FBQzlCLFNBQVEsdUJBQXNCLHNCQUFxQjtBQUNuRCxTQUFRLHVCQUF1Qix1QkFBc0I7QUFDckQsWUFBWSxXQUFXO0FBQ3ZCLFNBQVEsbUJBQWtCO0FBR25CLGFBQU0scUJBQW1CO0FBQ2hDLE1BQU0sU0FBTyxJQUFHLGVBQWEsS0FBRyxPQUFLLE1BQUssT0FBSyxLQUFLLElBQUksWUFBWSxJQUFJO0FBV2pFLGFBQU0sbUJBQW1CO0FBQUEsRUFvQzlCLFlBQW9CLE9BQTBCLFlBQTBCLFNBQXlCLENBQUMsR0FBRTtBQUFoRjtBQUEwQjtBQUEwQjtBQUN0RSxTQUFLLGtCQUFnQixPQUFPLG1CQUFpQjtBQUM3QyxRQUFHLENBQUMsT0FBTyxVQUFVLEtBQUssZUFBZSxLQUFHLEtBQUssa0JBQWdCLEtBQUcsS0FBSyxrQkFBZ0IsZUFBZSxPQUFNLElBQUksTUFBTSxrQ0FBa0M7QUFDMUosU0FBSyxVQUFVLE9BQUs7QUFDcEIsU0FBSyxjQUFZLElBQUksZ0JBQWdCLFVBQVU7QUFBQSxFQUNqRDtBQUFBLEVBeENRLFFBQWEsQ0FBQztBQUFBLEVBQ2Qsa0JBQWdCO0FBQUEsRUFDaEIsUUFBTSxvQkFBSSxJQUFpQjtBQUFBLEVBQzNCLFFBQU07QUFBQSxFQUNOLGdCQUFjO0FBQUE7QUFBQTtBQUFBLEVBR2QsWUFBcUIsQ0FBQztBQUFBLEVBQ3RCLFdBQVMsb0JBQUksSUFBcUI7QUFBQSxFQUNsQyxTQUFtQixDQUFDO0FBQUEsRUFDcEIsWUFBVSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQzFCO0FBQUEsRUFDQSxVQUFrQixDQUFDO0FBQUEsRUFDbkIsaUJBQWU7QUFBQSxFQUNmLGVBQWE7QUFBQSxFQUNiLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUN6QixTQUFPLElBQUksTUFBTSxRQUFRO0FBQUEsRUFDekIsV0FBUyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sY0FBYyxHQUFFLENBQUMsR0FBRSxJQUFJLE1BQU0sa0JBQWtCLEVBQUMsTUFBSyxNQUFNLFdBQVUsQ0FBQyxDQUFDO0FBQUEsRUFDekcsWUFBVSxJQUFJLE1BQU0sT0FBTztBQUFBLEVBQzNCLFVBQTZCLENBQUM7QUFBQSxFQUM5QixXQUFTLG9CQUFJLElBQThCO0FBQUEsRUFDM0M7QUFBQSxFQUNBLGFBQVcsSUFBSSxXQUFXLENBQUM7QUFBQSxFQUMzQixZQUFVLElBQUksV0FBVyxDQUFDO0FBQUEsRUFDMUIsWUFBVTtBQUFBLEVBQ1YsbUJBQWlCO0FBQUEsRUFDakIsbUJBQWlCO0FBQUEsRUFDakIsdUJBQXFCO0FBQUEsRUFDckIsb0JBQWtCO0FBQUEsRUFDbEIsb0JBQWtCO0FBQUEsRUFDbEIsc0JBQW9CO0FBQUEsRUFDcEIsV0FBUyxvQkFBSSxJQUFVO0FBQUEsRUFDdkIsbUJBQWlCO0FBQUEsRUFDakIsY0FBWSxJQUFJLGdCQUFnQjtBQUFBLEVBQ2hDLGVBQWEsRUFBQyxTQUFRLEdBQUUsWUFBVyxHQUFFLFNBQVEsR0FBRSxZQUFXLEdBQUUsV0FBVSxHQUFFLFFBQU8sRUFBQztBQUFBLEVBT3hGLFFBQU87QUFDTCxTQUFLO0FBQVEsU0FBSyxnQkFBYztBQUFFLFNBQUssUUFBUSxTQUFPO0FBQUUsU0FBSyxTQUFTLE1BQU07QUFDNUUsZUFBVSxPQUFPLEtBQUssVUFBVSxLQUFHLEtBQUk7QUFBQyxVQUFJLE9BQUs7QUFBVSxVQUFJLEtBQUc7QUFBQSxJQUFHO0FBRXJFLGVBQVUsU0FBUyxLQUFLLE9BQU8sTUFBSyxVQUFVLEtBQUs7QUFBQSxFQUNyRDtBQUFBLEVBQ1EsV0FBVyxPQUFhLFFBQWMsU0FBTyxRQUFPO0FBQzFELFVBQU0sT0FBVSxFQUFDLFNBQVEsZ0JBQWdCLE9BQU0sUUFBTyxRQUFPLEtBQUssVUFBVSxHQUFFLFVBQVMsaUJBQWlCLE9BQU0sUUFBTyxNQUFNLEdBQUUsVUFBUyxPQUFNLE9BQU0sSUFBSSxNQUFNLE1BQU0sR0FBRSxNQUFLLEtBQUssTUFBSztBQUNuTCxTQUFLLE1BQU0sS0FBSyxJQUFJO0FBQUUsU0FBSyxtQkFBaUIsUUFBTSxTQUFPO0FBQU8sV0FBTztBQUFBLEVBQ3pFO0FBQUEsRUFDUSxLQUFLLE9BQWEsUUFBYyxlQUFxQixRQUFNLE9BQU07QUFDdkUsUUFBSTtBQUNKLGVBQVUsUUFBUSxLQUFLLE9BQU07QUFDM0IsVUFBRyxLQUFLLFFBQVEsTUFBTSxVQUFRLFNBQU8sS0FBSyxRQUFRLE1BQU0sV0FBUyxPQUFPO0FBQ3hFLGVBQVEsUUFBTSxHQUFFLFFBQU0sS0FBSyxRQUFRLE1BQU0sT0FBTSxTQUFRO0FBQ3JELGNBQU0sT0FBSyxLQUFLLE1BQU0sS0FBSztBQUFFLFlBQUcsQ0FBQyxLQUFLLFFBQU0sRUFBQyxNQUFLLE1BQUs7QUFDdkQsWUFBRyxLQUFLLFNBQU8sS0FBSyxVQUFRLENBQUMsVUFBUSxLQUFLLE9BQUssT0FBTyxNQUFNLFVBQU87QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFHQSxVQUFNLGtCQUFnQixLQUFLLE9BQU8sZUFBYSxLQUFLLG9CQUFrQixRQUFNLE9BQU87QUFDbkYsUUFBRyxVQUFRLGtCQUFnQixHQUFFO0FBQUMsV0FBSyxNQUFNLE9BQU8sT0FBTyxHQUFHO0FBQUUsV0FBSyxhQUFXLE9BQU8sS0FBSztBQUFXLGFBQU8sS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFFO0FBQVUsYUFBTSxFQUFDLE1BQUssT0FBTyxNQUFLLE9BQU0sT0FBTyxNQUFLO0FBQUEsSUFBRTtBQU96TCxVQUFNLFNBQU8sUUFBTyxrQkFBZ0IsSUFBRSxLQUFLLElBQUksUUFBTyxlQUFlLElBQUUsSUFBRyxLQUFLLElBQUksUUFBTyxLQUFLLElBQUksR0FBRSxhQUFhLEdBQUUsa0JBQWdCLElBQUUsa0JBQWdCLE1BQU07QUFDNUosV0FBTSxFQUFDLE1BQUssS0FBSyxXQUFXLE9BQU0sUUFBTyxNQUFNLEdBQUUsT0FBTSxFQUFDO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLElBQUksS0FBVyxTQUFlLE9BQTJDLFFBQXFCLElBQVUsTUFBWSxXQUFnQixlQUFjLFVBQVEsR0FBRSxVQUFRLEdBQUU7QUFDcEssVUFBTSxPQUFLLFdBQVMsU0FBUSxTQUFPLEtBQUc7QUFDdEMsUUFBRyxDQUFDLE9BQU8sVUFBVSxPQUFPLEtBQUcsVUFBUSxLQUFHLFVBQVEsTUFBSSxDQUFDLE9BQU8sVUFBVSxJQUFJLEtBQUcsT0FBSyxLQUFHLE9BQUssV0FBUyxHQUFHLE9BQU0sSUFBSSxNQUFNLG9DQUFvQztBQUM1SixVQUFJLEdBQUcsR0FBRyxJQUFJLE9BQU8sSUFBSSxRQUFRO0FBQ2pDLFVBQU0sUUFBTSxLQUFLLGlCQUFnQixPQUFLLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFJeEQsUUFBRyxNQUFLO0FBQ04sV0FBSyxPQUFLLEtBQUssS0FBSyxPQUFLLEtBQUs7QUFHOUIsVUFBRyxLQUFLLFdBQVMsU0FBUTtBQUFDLGFBQUssU0FBUyxNQUFLLFFBQU8sSUFBRyxNQUFLLFNBQVEsS0FBSztBQUFFO0FBQUEsTUFBTztBQUFBLElBQ3BGO0FBQ0EsU0FBSyxRQUFRLEtBQUssRUFBQyxLQUFJLFNBQVEsT0FBTSxRQUFPLElBQUcsTUFBSyxVQUFTLFNBQVEsU0FBUSxNQUFLLENBQUM7QUFBQSxFQUNyRjtBQUFBLEVBQ1EsU0FBUyxNQUFVLFFBQXFCLElBQVUsTUFBWSxTQUFlLE9BQWE7QUFDaEcsU0FBSyxPQUFLLEtBQUssS0FBSyxPQUFLLEtBQUs7QUFDOUIsUUFBSSxNQUFJLEtBQUssVUFBVSxLQUFLO0FBQzVCLFFBQUcsQ0FBQyxLQUFJO0FBQUMsWUFBSSxFQUFDLE1BQUssUUFBTyxJQUFHLE1BQUssU0FBUSxHQUFFLE1BQUs7QUFBRSxXQUFLLFVBQVUsS0FBSyxJQUFFO0FBQUEsSUFBSSxPQUN6RTtBQUFDLFVBQUksT0FBSztBQUFLLFVBQUksU0FBTztBQUFPLFVBQUksS0FBRztBQUFHLFVBQUksT0FBSztBQUFLLFVBQUksUUFBTTtBQUFBLElBQU07QUFDN0UsUUFBSSxVQUFRLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxHQUFFLE9BQU8sQ0FBQztBQUMxQyxRQUFJLFdBQVMsS0FBSyxTQUFTLElBQUksSUFBSTtBQUFFLFFBQUcsQ0FBQyxVQUFTO0FBQUMsaUJBQVMsQ0FBQztBQUFFLFdBQUssU0FBUyxJQUFJLE1BQUssUUFBUTtBQUFBLElBQUU7QUFBQyxhQUFTLEtBQUssR0FBRztBQUFBLEVBQ3BIO0FBQUE7QUFBQTtBQUFBLEVBR1EsT0FBTyxVQUFjLFNBQWE7QUFDeEMsVUFBTSxPQUFLLEtBQUssU0FBUyxJQUFJLFFBQVE7QUFBRSxRQUFHLENBQUMsS0FBSztBQUNoRCxRQUFJLFNBQU8sS0FBSyxTQUFTLElBQUksT0FBTztBQUFFLFFBQUcsQ0FBQyxRQUFPO0FBQUMsZUFBTyxDQUFDO0FBQUUsV0FBSyxTQUFTLElBQUksU0FBUSxNQUFNO0FBQUEsSUFBRTtBQUM5RixlQUFVLE9BQU8sTUFBSztBQUFDLFVBQUksT0FBSztBQUFRLGFBQU8sS0FBSyxHQUFHO0FBQUEsSUFBRTtBQUFDLFNBQUssU0FBUyxPQUFPLFFBQVE7QUFBQSxFQUN6RjtBQUFBLEVBQ1EsT0FBTyxFQUFDLEtBQUksU0FBUSxPQUFNLFFBQU8sSUFBRyxNQUFLLFVBQVMsU0FBUSxNQUFLLEdBQVUsVUFBNkIsU0FBZSxlQUFpQztBQUM1SixRQUFJLE9BQUssS0FBSyxNQUFNLElBQUksR0FBRztBQUMzQixRQUFHLENBQUMsUUFBTSxLQUFLLFVBQVEsU0FBUTtBQUM3QixZQUFNLFdBQVM7QUFDZixZQUFNLFFBQU0sWUFBWSxJQUFJLEdBQUUsT0FBSyxXQUFTO0FBQzVDLFlBQU0sYUFBVyxZQUFZLElBQUk7QUFBRSxVQUFJLE9BQUssS0FBSyxZQUFZLElBQUksR0FBRztBQUNwRSxXQUFLLGFBQWEsV0FBUyxZQUFZLElBQUksSUFBRTtBQUFXLFlBQU0sWUFBVSxDQUFDLENBQUM7QUFBSyxVQUFJLFVBQVE7QUFDM0YsVUFBRyxDQUFDLE1BQUs7QUFDUCxjQUFNLGFBQVcsWUFBWSxJQUFJO0FBQ2pDLFlBQUksU0FBTyxLQUFLLFNBQVMsSUFBSSxJQUFJO0FBQUUsWUFBRyxDQUFDLFFBQU87QUFBQyxtQkFBTyxTQUFTLGNBQWMsUUFBUTtBQUFFLGlCQUFPLFFBQU0sT0FBTyxTQUFPO0FBQUssZUFBSyxTQUFTLElBQUksTUFBSyxNQUFNO0FBQUEsUUFBRTtBQUN0SixjQUFNLE1BQUksT0FBTyxXQUFXLE1BQUssRUFBQyxvQkFBbUIsS0FBSSxDQUFDO0FBQUcsWUFBSSxlQUFlO0FBQUUsWUFBSSxVQUFVLEdBQUUsR0FBRSxNQUFLLElBQUk7QUFBRSxZQUFJLEtBQUs7QUFBRSxZQUFJLE1BQU0sU0FBUSxPQUFPO0FBQUUsWUFBSSxVQUFVLFdBQVMsR0FBRSxXQUFTLENBQUM7QUFDeEwsWUFBRztBQUFDLGdCQUFNLEdBQUc7QUFBQSxRQUFFLFVBQUM7QUFBUSxjQUFJLFFBQVE7QUFBQSxRQUFFO0FBQ3RDLGNBQU0sWUFBVSxZQUFZLElBQUk7QUFBRSxhQUFLLGFBQWEsV0FBUyxZQUFVO0FBQ3ZFLGVBQUssSUFBSSxhQUFhLEdBQUUsR0FBRSxNQUFLLElBQUksRUFBRTtBQUFLLGNBQU0sU0FBTyxZQUFZLElBQUk7QUFBRSxhQUFLLGFBQWEsY0FBWSxTQUFPO0FBQVUsa0JBQVEsU0FBTztBQUFBLE1BRXpJO0FBQ0EsV0FBSyxtQkFBaUIsS0FBSztBQUFXLFdBQUssWUFBWTtBQUN2RCxVQUFHO0FBQ0QsY0FBTSxZQUFVLFlBQVksSUFBSSxHQUFFLFVBQVEsU0FBUyxJQUFJLEdBQUUsYUFBVyxVQUFRLE9BQUssSUFBRyxjQUFZLFVBQVEsVUFBUSxHQUFFLGVBQWEsYUFBVyxLQUFHO0FBQzdJLGNBQU0sT0FBSyxLQUFLLE9BQU8sYUFBVyxRQUFNLElBQUksV0FBVyxDQUFDLElBQUUsVUFBUSxpQkFBaUIsTUFBSyxNQUFLLE1BQUssQ0FBQyxTQUFTLElBQUUsSUFBSSxXQUFXLEtBQUcsS0FBRyxDQUFDO0FBQ3BJLGFBQUssbUJBQWlCLEtBQUs7QUFDM0IsY0FBTSxZQUFVLFlBQVksSUFBSTtBQUFFLGFBQUssYUFBYSxjQUFZLFlBQVU7QUFHMUUsWUFBRyxXQUFTLENBQUMsV0FBVTtBQUNyQixnQkFBTSxNQUFJLE9BQUs7QUFBRSxjQUFHLEtBQUssV0FBVyxTQUFPLElBQUksTUFBSyxhQUFXLElBQUksV0FBVyxHQUFHO0FBQ2pGLG1CQUFRLElBQUUsR0FBRSxJQUFFLEtBQUssTUFBTSxPQUFLLENBQUMsR0FBRSxLQUFJO0FBQ25DLGtCQUFNLE1BQUksSUFBRSxLQUFJLFVBQVEsT0FBSyxJQUFFLEtBQUc7QUFBSSxpQkFBSyxXQUFXLElBQUksS0FBSyxTQUFTLEtBQUksTUFBSSxHQUFHLENBQUM7QUFDcEYsaUJBQUssV0FBVyxLQUFJLFFBQU8sU0FBTyxHQUFHO0FBQUUsaUJBQUssSUFBSSxLQUFLLFdBQVcsU0FBUyxHQUFFLEdBQUcsR0FBRSxNQUFNO0FBQUEsVUFDeEY7QUFBQSxRQUNGO0FBQ0EsY0FBTSxZQUFVLFlBQVksSUFBSTtBQUFFLGFBQUssYUFBYSxhQUFXLFlBQVU7QUFHekUsWUFBRyxDQUFDLFVBQVUsTUFBSyxZQUFZLElBQUksS0FBSSxNQUFLLE1BQUssTUFBSyxPQUFPO0FBQzdELGNBQU0sWUFBVSxZQUFZLElBQUk7QUFBRSxhQUFLLGFBQWEsV0FBUyxZQUFVO0FBQ3ZFLGNBQU0sRUFBQyxNQUFLLE1BQUssSUFBRSxLQUFLLEtBQUssY0FBYSxjQUFhLGNBQWMsSUFBSSxZQUFZLEtBQUcsR0FBRSxDQUFDLE9BQU87QUFBRSxhQUFLLFlBQVk7QUFDckgsYUFBSyxhQUFhLFVBQVEsWUFBWSxJQUFJLElBQUU7QUFDNUMsYUFBSyxvQkFBa0IsWUFBWSxJQUFJLElBQUU7QUFDekMsWUFBRyxDQUFDLFdBQVMsS0FBSyxVQUFVLFdBQVMsRUFBRSxNQUFLLFlBQVUsSUFBSSxXQUFXLEtBQUcsS0FBRyxDQUFDO0FBQzVFLGFBQUssWUFBWSxZQUFZLE1BQUssT0FBTSxVQUFRLE9BQUssS0FBSyxXQUFVLFVBQVMsRUFBQyxhQUFZLFlBQVcsY0FBYSxZQUFXLFNBQVEsWUFBVyxDQUFDO0FBQUUsYUFBSyxZQUFZO0FBQ3BLLGVBQUssRUFBQyxLQUFJLE1BQUssT0FBTSxNQUFLLEtBQUssT0FBTSxVQUFTLFlBQVcsU0FBUSxhQUFZLEtBQUk7QUFBRSxhQUFLLE1BQU0sS0FBSyxJQUFFO0FBQUssYUFBSyxNQUFNLElBQUksS0FBSSxJQUFJO0FBQUUsYUFBSyxhQUFXLEtBQUs7QUFDeEosWUFBRyxVQUFTO0FBQUMsZUFBSyxPQUFPLFVBQVMsSUFBSTtBQUFFLG1CQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssSUFBRTtBQUFVLGVBQUssYUFBVyxTQUFTLEtBQUs7QUFBQSxRQUFXO0FBQy9ILGFBQUs7QUFHTCxjQUFNLGNBQVksT0FBSyxLQUFHO0FBQzFCLHNCQUFjLElBQUksYUFBWSxLQUFLLElBQUksSUFBRyxjQUFjLElBQUksV0FBVyxLQUFHLEtBQUcsQ0FBQyxDQUFDO0FBQUEsTUFDakYsVUFBQztBQUFRLGFBQUssbUJBQWlCLEtBQUssbUJBQWlCO0FBQUEsTUFBRTtBQUFBLElBQ3pEO0FBQ0EsU0FBSyxTQUFTLE1BQUssUUFBTyxJQUFHLE1BQUssU0FBUSxLQUFLO0FBQUEsRUFDakQ7QUFBQSxFQUNRLFFBQVEsVUFBNkI7QUFDM0MsUUFBRyxLQUFLLG1CQUFpQixhQUFhO0FBQ3RDLFVBQU0sUUFBTSxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksVUFBTSxHQUFHLEtBQUssUUFBUSxNQUFNLEtBQUssSUFBSSxLQUFLLFFBQVEsTUFBTSxNQUFNLEVBQUUsQ0FBQztBQUNwRyxlQUFVLFFBQVEsT0FBTTtBQUN0QixZQUFNLENBQUMsT0FBTSxNQUFNLElBQUUsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFDL0MsWUFBTSxRQUFNLEtBQUssTUFBTSxPQUFPLFVBQU0sS0FBSyxRQUFRLE1BQU0sVUFBUSxTQUFPLEtBQUssUUFBUSxNQUFNLFdBQVMsTUFBTTtBQUN4RyxZQUFNLFNBQU8sTUFBTSxRQUFRLFVBQU0sS0FBSyxNQUFNLE9BQU8sQ0FBQyxTQUFvQixRQUFRLFFBQU0sS0FBSyxTQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDOUcsVUFBSSxXQUFTLEdBQUUsU0FBTztBQUN0QixpQkFBVSxRQUFRLENBQUMsR0FBRyxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUUsTUFBSSxFQUFFLFFBQVEsTUFBTSxRQUFNLEVBQUUsUUFBUSxNQUFNLEtBQUssR0FBRTtBQUNwRixZQUFHLFlBQVUsT0FBTyxPQUFPO0FBQU0sb0JBQVUsS0FBSyxRQUFRLE1BQU07QUFBTTtBQUFBLE1BQ3RFO0FBSUEsVUFBRyxDQUFDLFVBQVEsU0FBTyxJQUFFLE1BQU0sT0FBTztBQUdsQyxZQUFNLFNBQU8sQ0FBQyxHQUFHLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRSxNQUFJLEVBQUUsTUFBTSxPQUFPLFVBQU0sTUFBTSxTQUFPLEtBQUssS0FBSyxFQUFFLFNBQU8sRUFBRSxNQUFNLE9BQU8sVUFBTSxNQUFNLFNBQU8sS0FBSyxLQUFLLEVBQUUsVUFBUSxFQUFFLFFBQVEsTUFBTSxRQUFNLEVBQUUsUUFBUSxNQUFNLEtBQUs7QUFDMUwsWUFBTSxlQUFhLE9BQU8sTUFBTSxHQUFFLE1BQU07QUFBRSxpQkFBUyxhQUFhLE9BQU8sQ0FBQyxLQUFJLFNBQU8sTUFBSSxLQUFLLFFBQVEsTUFBTSxPQUFNLENBQUM7QUFDakgsYUFBTSxXQUFTLE9BQU8sUUFBTztBQUMzQixjQUFNLFdBQVMsQ0FBQyxHQUFHLFlBQVksRUFBRSxLQUFLLENBQUMsR0FBRSxNQUFJLEVBQUUsUUFBUSxNQUFNLFFBQU0sRUFBRSxRQUFRLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFDM0YsY0FBTSxjQUFZLE1BQU0sT0FBTyxVQUFNLENBQUMsYUFBYSxTQUFTLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFFLE1BQUksRUFBRSxRQUFRLE1BQU0sUUFBTSxFQUFFLFFBQVEsTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUM3SCxvQkFBVSxZQUFZLFFBQVEsTUFBTSxRQUFNLFNBQVMsUUFBUSxNQUFNO0FBQ2pFLHFCQUFhLGFBQWEsUUFBUSxRQUFRLENBQUMsSUFBRTtBQUFBLE1BQy9DO0FBQ0EsWUFBTSxPQUFLLElBQUksSUFBSSxZQUFZLEdBQUUsVUFBUSxNQUFNLE9BQU8sVUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUM7QUFDM0UsWUFBTSxRQUFpQyxDQUFDO0FBQ3hDLGlCQUFVLFFBQVEsYUFBYSxVQUFRLFFBQU0sR0FBRSxRQUFNLEtBQUssUUFBUSxNQUFNLE9BQU0sUUFBUSxLQUFHLEtBQUssTUFBTSxLQUFLLEdBQUcsU0FBTyxLQUFLLE1BQU0sT0FBTSxLQUFLLEVBQUMsTUFBSyxNQUFLLENBQUM7QUFDckosWUFBTSxZQUFVLE9BQU8sT0FBTyxVQUFNLENBQUMsS0FBSyxJQUFJLEtBQUssSUFBSSxDQUFDO0FBQ3hELFlBQU0sUUFBTSxvQkFBSSxJQUFlLEdBQUUsUUFBb0IsQ0FBQztBQUN0RCxpQkFBVSxDQUFDLEdBQUUsR0FBRyxLQUFLLFVBQVUsUUFBUSxHQUFFO0FBQ3ZDLGNBQU0sRUFBQyxNQUFLLE1BQUssSUFBRSxNQUFNLENBQUMsR0FBRyxPQUFLLEVBQUMsR0FBRyxLQUFJLE1BQUssT0FBTSxNQUFLLEtBQUssTUFBSztBQUFFLGNBQU0sSUFBSSxLQUFJLElBQUk7QUFDeEYsY0FBTSxLQUFLLEVBQUMsUUFBTyxJQUFJLE1BQUssYUFBWSxJQUFJLE9BQU0sYUFBWSxNQUFLLGtCQUFpQixNQUFLLENBQUM7QUFBQSxNQUM1RjtBQUNBLGlCQUFVLFVBQVUsUUFBUSxNQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ3BELFVBQUc7QUFJRCxhQUFLLFlBQVksV0FBVyxPQUFNLFFBQVE7QUFBRSxhQUFLLFlBQVk7QUFBQSxNQUMvRCxTQUFPLE9BQU07QUFHWCxtQkFBVSxRQUFRLE1BQU0sT0FBTyxHQUFFO0FBQy9CLGdCQUFNLFdBQVMsS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLO0FBQ3pDLGNBQUcsWUFBVSxLQUFLLE1BQU0sSUFBSSxTQUFTLEdBQUcsTUFBSSxVQUFTO0FBQUMsaUJBQUssTUFBTSxPQUFPLFNBQVMsR0FBRztBQUFFLGlCQUFLLGFBQVcsU0FBUyxLQUFLO0FBQUEsVUFBVztBQUMvSCxlQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssSUFBRTtBQUFBLFFBQzlCO0FBQ0EsYUFBSyxZQUFZO0FBQUUsY0FBTTtBQUFBLE1BQzNCLFVBQUM7QUFBUSxhQUFLLFNBQVMsTUFBTTtBQUFBLE1BQUU7QUFDL0IsaUJBQVUsQ0FBQyxLQUFJLElBQUksS0FBSyxPQUFNO0FBQzVCLGNBQU0sV0FBUyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUs7QUFDekMsWUFBRyxZQUFVLEtBQUssTUFBTSxJQUFJLFNBQVMsR0FBRyxNQUFJLFVBQVM7QUFBQyxlQUFLLE1BQU0sT0FBTyxTQUFTLEdBQUc7QUFBRSxlQUFLLGFBQVcsU0FBUyxLQUFLO0FBQUEsUUFBVztBQUMvSCxhQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssSUFBRTtBQUFLLGFBQUssS0FBSyxPQUFLLEtBQUs7QUFBTSxhQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUksSUFBSTtBQUFBLE1BQ3hGO0FBQ0EsaUJBQVUsQ0FBQyxLQUFJLElBQUksS0FBSyxNQUFNLE1BQUssT0FBTyxLQUFJLElBQUk7QUFDbEQsaUJBQVUsT0FBTyxRQUFRLE1BQUssT0FBTyxHQUFHO0FBQ3hDLFdBQUssZ0JBQWMsTUFBTTtBQUFBLElBRTNCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQSxFQUdBLE9BQU8sVUFBNkI7QUFDbEMsVUFBTSxTQUFPLG9CQUFJLElBQXlDLEdBQUUsZ0JBQWMsb0JBQUksSUFBbUI7QUFDakcsZUFBVSxXQUFXLEtBQUssU0FBUTtBQUNoQyxZQUFNLFdBQVMsT0FBTyxJQUFJLFFBQVEsR0FBRztBQUNyQyxVQUFHLENBQUMsWUFBVSxRQUFRLFVBQVEsU0FBUyxRQUFRLFFBQU8sSUFBSSxRQUFRLEtBQUksRUFBQyxTQUFRLFFBQVEsU0FBUSxNQUFLLFFBQVEsV0FBUyxRQUFRLFVBQVEsS0FBRyxRQUFRLFFBQU8sQ0FBQztBQUFBLElBQzFKO0FBQ0EsZUFBVSxDQUFDLEtBQUksT0FBTyxLQUFLLFFBQU87QUFDaEMsWUFBTSxPQUFLLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFBRSxVQUFHLFFBQU0sS0FBSyxXQUFTLFFBQVEsUUFBUTtBQUN0RSxvQkFBYyxJQUFJLFFBQVEsT0FBTSxjQUFjLElBQUksUUFBUSxJQUFJLEtBQUcsS0FBRyxDQUFDO0FBQUEsSUFDdkU7QUFDQSxRQUFHO0FBQUMsaUJBQVUsV0FBVyxLQUFLLFFBQVEsTUFBSyxPQUFPLFNBQVEsVUFBUyxPQUFPLElBQUksUUFBUSxHQUFHLEVBQUcsU0FBUSxhQUFhO0FBQUEsSUFBRSxVQUFDO0FBQVEsV0FBSyxRQUFRLFNBQU87QUFBQSxJQUFFO0FBQ2xKLFNBQUssUUFBUSxRQUFRO0FBQ3JCLGVBQVUsUUFBUSxDQUFDLEdBQUcsS0FBSyxLQUFLLEdBQUU7QUFDaEMsVUFBRyxDQUFDLEtBQUssTUFBTSxLQUFLLFVBQU0sTUFBTSxTQUFPLEtBQUssS0FBSyxNQUFJLENBQUMsS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFHLEtBQUssUUFBTSxLQUFLLE9BQUssT0FBSyxLQUFLLGtCQUFnQixjQUFjLE1BQUssT0FBTyxJQUFJO0FBQUEsSUFDL0o7QUFDQSxTQUFLLEtBQUs7QUFBQSxFQUNaO0FBQUEsRUFDUSxXQUFXLFVBQTZCLFVBQWdCO0FBQzlELFFBQUcsS0FBSyxPQUFPLFlBQVksVUFBUyxhQUFhLGVBQWMsSUFBSSxNQUFNLHlCQUF5QixJQUFJLGFBQWEsUUFBUSxHQUFFLENBQUMsRUFBRSxTQUFTLE1BQU0sZ0JBQWdCLENBQUM7QUFDaEssYUFBUyxhQUFhLFlBQVcsSUFBSSxNQUFNLHlCQUF5QixJQUFJLGFBQWEsV0FBUyxDQUFDLEdBQUUsQ0FBQyxFQUFFLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztBQUNwSSxhQUFTLGFBQWEsYUFBWSxJQUFJLE1BQU0seUJBQXlCLElBQUksYUFBYSxRQUFRLEdBQUUsQ0FBQyxFQUFFLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztBQUNuSSxhQUFTLGFBQWEsWUFBVyxJQUFJLE1BQU0seUJBQXlCLElBQUksYUFBYSxRQUFRLEdBQUUsQ0FBQyxFQUFFLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztBQUFBLEVBQ3BJO0FBQUEsRUFDUSxZQUFZLE9BQStCLE9BQWEsT0FBYTtBQUMzRSxVQUFNLFdBQVMsSUFBSSxNQUFNLGtCQUFrQixFQUFDLEtBQUksTUFBTSxDQUFDLEdBQUcsV0FBVSxLQUFLLE9BQU8sYUFBVyxLQUFHLE1BQUssTUFBTSxZQUFXLFlBQVcsT0FBTSxhQUFZLEtBQUssT0FBTyxlQUFhLE9BQU0sWUFBVyxLQUFLLE9BQU8sY0FBWSxNQUFLLFdBQVUsS0FBSSxDQUFDO0FBQ3ZPLFVBQU0sUUFBTSxJQUFJLE1BQU0sa0JBQWtCLEVBQUMsS0FBSSxNQUFNLENBQUMsR0FBRyxXQUFVLEtBQUcsTUFBSyxNQUFNLFlBQVcsY0FBYSxNQUFNLGlCQUFnQixDQUFDO0FBQzlILFVBQU0sV0FBUyxJQUFJLE1BQU0scUJBQXFCLEVBQUMsS0FBSSxNQUFNLENBQUMsR0FBRyxXQUFVLEtBQUcsTUFBSyxNQUFNLFdBQVUsQ0FBQztBQUNoRyxVQUFNLG1CQUFpQixDQUFDLFVBQVMsT0FBTSxRQUFRLEVBQUUsSUFBSSxVQUFNLHNCQUFzQixNQUFLLE9BQU0sS0FBSyxpQkFBZ0IsS0FBSyxPQUFPLGVBQWEsS0FBSyxDQUFDO0FBQ2hKLFVBQU0sV0FBUyxJQUFJLE1BQU0sY0FBYyxHQUFFLENBQUMsR0FBRSxXQUFTLEtBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLENBQUM7QUFBRSxTQUFLLFdBQVcsVUFBUyxRQUFRO0FBQ3JILFVBQU0sT0FBSyxJQUFJLE1BQU0sY0FBYyxVQUFTLFVBQVMsUUFBUTtBQUM3RCxVQUFNLFFBQWdCLEVBQUMsT0FBTSxPQUFNLENBQUMsR0FBRSxTQUFRLENBQUMsR0FBRSxLQUFJLENBQUMsR0FBRSxNQUFLLENBQUMsR0FBRSxRQUFPLENBQUMsR0FBRSxVQUFTLFVBQVMsT0FBTSxVQUFTLE1BQUssVUFBUyxNQUFLLEtBQUssT0FBTSxpQkFBZ0I7QUFDekosU0FBSyxtQkFBbUIsT0FBTSxLQUFLO0FBQUUsU0FBSyxPQUFPLEtBQUssSUFBRTtBQUFNLFdBQU87QUFBQSxFQUN2RTtBQUFBLEVBQ1EsbUJBQW1CLE9BQWdCLE9BQWE7QUFDdEQsVUFBTSxPQUFLLE1BQU07QUFJakIsU0FBSyxPQUFLO0FBQWUsU0FBSyxhQUFXLEtBQUssT0FBTyxjQUFZO0FBQUssU0FBSyxlQUFhLEtBQUssT0FBTyxlQUFhLEtBQUcsT0FBTSxPQUFNLFNBQU8sUUFBTTtBQUFHLFNBQUssZ0JBQWM7QUFBSyxTQUFLLHNCQUFvQixNQUFNO0FBQU0sU0FBSyx5QkFBdUIsTUFBTTtBQUFTLFNBQUssZUFBZSxTQUFTLE1BQU0sZ0JBQWdCO0FBQzNTLFNBQUssVUFBUSxDQUFDLFdBQVUsa0JBQWdCLEtBQUssUUFBUSxPQUFNLFdBQVUsYUFBYTtBQUNsRixTQUFLLFNBQVMsTUFBSSxNQUFNO0FBQUksU0FBSyxTQUFTLFFBQU0sTUFBTTtBQUFRLFNBQUssU0FBUyxPQUFLLE1BQU07QUFBSyxTQUFLLFNBQVMsU0FBTyxNQUFNO0FBQU8sU0FBSyxTQUFTLFFBQU0sTUFBTTtBQUN4SixTQUFLLFNBQVMsYUFBVyxDQUFDLFVBQWdCLE9BQTBCLEtBQUssSUFBSSxPQUFNLFVBQVMsRUFBRTtBQUM5RixTQUFLLFVBQVUsSUFBSSxJQUFJO0FBQUEsRUFDekI7QUFBQSxFQUNRLFlBQVksT0FBZ0IsT0FBYSxPQUFhO0FBQzVELFNBQUssVUFBVSxPQUFPLE1BQU0sSUFBSTtBQUFFLFVBQU0sS0FBSyxRQUFRO0FBQUUsVUFBTSxTQUFTLFFBQVE7QUFDOUUsVUFBTSxXQUFTLEtBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLENBQUM7QUFBRSxTQUFLLFdBQVcsTUFBTSxVQUFTLE1BQU0sUUFBUTtBQUMzRixVQUFNLE9BQUssSUFBSSxNQUFNLGNBQWMsTUFBTSxVQUFTLE1BQU0sVUFBUyxNQUFNLFFBQVE7QUFBRSxTQUFLLG1CQUFtQixPQUFNLEtBQUs7QUFBQSxFQUN0SDtBQUFBLEVBQ1EsVUFBVSxPQUFnQjtBQUNoQyxVQUFNLEtBQUssVUFBUTtBQUFNLFVBQU0sS0FBSyxRQUFNO0FBQzFDLFVBQU0sUUFBUSxTQUFPLE1BQU0sSUFBSSxTQUFPLE1BQU0sS0FBSyxTQUFPLE1BQU0sT0FBTyxTQUFPLE1BQU0sTUFBTSxTQUFPLE1BQU0sTUFBTSxTQUFPO0FBQ2xILGVBQVUsWUFBWSxDQUFDLE1BQU0sVUFBUyxNQUFNLE9BQU0sTUFBTSxRQUFRLEVBQUUsVUFBUyxNQUFJO0FBQy9FLGVBQVUsV0FBVyxNQUFNLGlCQUFpQixTQUFRO0FBQUEsRUFDdEQ7QUFBQTtBQUFBO0FBQUEsRUFHUSxPQUFNO0FBQ1osUUFBSSxRQUFNLEdBQUUsUUFBTTtBQUNsQixXQUFNLFFBQU0sS0FBSyxlQUFjO0FBQzdCLFlBQU0sWUFBVSxvQkFBSSxJQUFpQjtBQUFFLFVBQUksTUFBSTtBQUMvQyxhQUFNLE1BQUksS0FBSyxlQUFjO0FBQzNCLGNBQU0sT0FBSyxLQUFLLFVBQVUsR0FBRyxFQUFHO0FBQ2hDLFlBQUcsQ0FBQyxVQUFVLElBQUksS0FBSyxJQUFJLEdBQUU7QUFDM0IsY0FBRyxVQUFVLFNBQU8sS0FBSyxnQkFBZ0I7QUFDekMsb0JBQVUsSUFBSSxLQUFLLE1BQUssVUFBVSxJQUFJO0FBQUEsUUFDeEM7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFFBQU0sS0FBSyxPQUFPLEtBQUs7QUFDM0IsVUFBRyxDQUFDLE1BQU0sU0FBTSxLQUFLLFlBQVksQ0FBQyxHQUFHLFVBQVUsS0FBSyxDQUFDLEVBQUUsSUFBSSxVQUFNLEtBQUssT0FBTyxHQUFFLE1BQUksT0FBTSxLQUFLO0FBQzlGLFlBQU0sTUFBTSxTQUFPLE1BQU0sTUFBTSxTQUFPO0FBQ3RDLGlCQUFVLFFBQVEsVUFBVSxLQUFLLEdBQUU7QUFBQyxjQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUUsY0FBTSxNQUFNLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFBRTtBQUMxRixpQkFBVSxZQUFZLENBQUMsTUFBTSxVQUFTLE1BQU0sT0FBTSxNQUFNLFFBQVEsRUFBRSxVQUFTLE1BQUksTUFBTSxNQUFNLENBQUM7QUFDNUYsaUJBQVUsV0FBVyxNQUFNLGlCQUFpQixTQUFRO0FBQ3BELFVBQUcsTUFBSSxRQUFNLE1BQU0sU0FBUyxNQUFLLFlBQVksT0FBTSxNQUFJLE9BQU0sS0FBSztBQUNsRSxZQUFNLEVBQUMsTUFBSyxTQUFRLElBQUUsT0FBTSxTQUFPLFNBQVMsYUFBYSxXQUFXLEdBQUUsUUFBTSxTQUFTLGFBQWEsVUFBVSxHQUFFLFFBQU0sU0FBUyxhQUFhLFVBQVU7QUFBRSxVQUFJLFNBQU87QUFDakssWUFBTSxRQUFRLFNBQU8sTUFBTSxJQUFJLFNBQU8sTUFBTSxLQUFLLFNBQU8sTUFBTSxPQUFPLFNBQU87QUFBRSxZQUFNLE9BQUssS0FBSztBQUFNLFdBQUssUUFBTSxNQUFJO0FBQU0sV0FBSyxVQUFRO0FBQ3RJLGVBQVEsUUFBTSxPQUFNLFFBQU0sS0FBSSxTQUFRO0FBQ3BDLGNBQU0sTUFBSSxLQUFLLFVBQVUsS0FBSyxHQUFHLE9BQUssSUFBSSxNQUFNLElBQUUsUUFBTTtBQUN4RCxjQUFNLFFBQVEsS0FBSyxJQUFJO0FBQUUsY0FBTSxJQUFJLEtBQUssSUFBSSxFQUFFO0FBQUUsY0FBTSxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQUUsY0FBTSxPQUFPLEtBQUssS0FBSztBQUdqRyxjQUFNLE9BQUssS0FBSyxXQUFTLEdBQUUsTUFBSSxLQUFLLE9BQU8sS0FBSyxPQUFPLENBQUMsT0FBSyxJQUFJLElBQUUsSUFBSSxPQUFLLElBQUksR0FBRSxPQUFLLEtBQUssT0FBTyxLQUFLLE9BQU8sT0FBSyxJQUFJLElBQUUsSUFBSSxPQUFLLElBQUk7QUFDdkksY0FBTSxRQUFRLEdBQUUsQ0FBQyxNQUFLLEtBQUksTUFBSyxJQUFJO0FBQUUsaUJBQU8sS0FBSyxJQUFJLFFBQU8sS0FBSyxNQUFNLE1BQUssR0FBRyxHQUFFLEtBQUssTUFBTSxNQUFLLElBQUksQ0FBQztBQUN0RyxhQUFLLFlBQVksR0FBRSxJQUFJLE1BQU07QUFBRSxlQUFPLEtBQUssR0FBRSxLQUFLLEtBQUs7QUFBRSxjQUFNLEtBQUssR0FBRSxVQUFVLElBQUksS0FBSyxJQUFJLENBQUU7QUFDL0YsWUFBRyxLQUFLLE9BQU8sWUFBWSxVQUFTLGFBQWEsYUFBYSxFQUFFLEtBQUssR0FBRSxJQUFJLE9BQU87QUFBQSxNQUNwRjtBQUNBLFVBQUcsS0FBSyxPQUFPLFlBQVksVUFBUyxhQUFhLGFBQWEsRUFBRSxjQUFZO0FBQzVFLFlBQU0sY0FBWSxPQUFPLGNBQVksTUFBTSxjQUFZLEtBQUssZUFBZSxjQUFZO0FBQ3ZGLGVBQVMsbUJBQWlCLElBQUksTUFBTSxPQUFPO0FBQUUsZUFBUyxlQUFlLE9BQU8sSUFBSSxHQUFFLEdBQUUsQ0FBQztBQUFFLGVBQVMsZUFBZSxTQUFPO0FBQU8sV0FBSyxzQkFBc0I7QUFDeEosY0FBTTtBQUFJO0FBQUEsSUFDWjtBQUdBLGFBQVEsSUFBRSxHQUFFLElBQUUsS0FBSyxPQUFPLFFBQU8sSUFBSSxNQUFLLFVBQVUsU0FBUyxDQUFDLElBQUUsS0FBSyxPQUFPLENBQUMsRUFBRztBQUNoRixTQUFLLFVBQVUsU0FBUyxTQUFPLEtBQUssT0FBTztBQUMzQyxRQUFHLE9BQU07QUFBQyxVQUFHLEtBQUssVUFBVSxXQUFTLEtBQUssTUFBTSxNQUFLLE1BQU0sSUFBSSxLQUFLLFNBQVM7QUFBQSxJQUFFO0FBQy9FLGFBQVEsSUFBRSxLQUFLLE9BQU8sU0FBTyxHQUFFLEtBQUcsT0FBTSxLQUFJO0FBQzFDLFlBQU0sUUFBTSxLQUFLLE9BQU8sQ0FBQztBQUFHLFdBQUssVUFBVSxLQUFLO0FBQ2hELFVBQUcsQ0FBQyxLQUFLLE1BQU0sVUFBUSxLQUFLLFFBQU0sTUFBTSxPQUFLLEtBQUk7QUFBQyxhQUFLLFlBQVksS0FBSztBQUFFLGFBQUssT0FBTyxPQUFPLEdBQUUsQ0FBQztBQUFBLE1BQUU7QUFBQSxJQUNwRztBQUNBLFFBQUcsQ0FBQyxLQUFLLE9BQU8sT0FBTyxNQUFLLE1BQU0sT0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN6RDtBQUFBLEVBQ1EsWUFBWSxPQUFnQjtBQUNsQyxTQUFLLFVBQVUsS0FBSztBQUFFLFNBQUssVUFBVSxPQUFPLE1BQU0sSUFBSTtBQUFFLFVBQU0sS0FBSyxRQUFRO0FBQUUsVUFBTSxTQUFTLFFBQVE7QUFBRSxVQUFNLFNBQVMsUUFBUTtBQUFFLFVBQU0sTUFBTSxRQUFRO0FBQUUsVUFBTSxTQUFTLFFBQVE7QUFDNUssVUFBTSxRQUFRLFNBQU8sTUFBTSxJQUFJLFNBQU8sTUFBTSxLQUFLLFNBQU8sTUFBTSxPQUFPLFNBQU8sTUFBTSxNQUFNLFNBQU8sTUFBTSxNQUFNLFNBQU87QUFBQSxFQUNwSDtBQUFBO0FBQUE7QUFBQSxFQUdBLGdCQUFlO0FBQUMsU0FBSyxRQUFRO0FBQUEsRUFBRTtBQUFBLEVBQ3ZCLFFBQVEsT0FBZ0IsV0FBMEIsZUFBbUM7QUFDM0YsUUFBRyxLQUFLLE9BQU8sYUFBVyxNQUFNO0FBQ2hDLFVBQU0sT0FBSyxNQUFNO0FBQUssUUFBRyxDQUFDLEtBQUssZUFBZSxNQUFLLHNCQUFzQjtBQUN6RSxRQUFHLENBQUMsVUFBVSxJQUFJLGlCQUFpQixLQUFLLFVBQVUsS0FBSyxLQUFLLGNBQWUsRUFBRSxhQUFhLEtBQUssV0FBVyxDQUFDLEVBQUU7QUFHN0csYUFBUSxJQUFFLEdBQUUsSUFBRSxLQUFLLE9BQU0sS0FBSTtBQUMzQixZQUFNLE9BQUssTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFLLEtBQUssV0FBUyxHQUFFLE9BQUssTUFBTSxLQUFLLENBQUM7QUFDbkUsWUFBTSxNQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sQ0FBQyxPQUFLLElBQUksSUFBRSxPQUFLLElBQUksR0FBRSxPQUFLLEtBQUssT0FBTyxLQUFLLE9BQU8sT0FBSyxJQUFJLElBQUUsT0FBSyxJQUFJO0FBQzFHLFdBQUssT0FBTyxVQUFVLEtBQUssVUFBUyxPQUFLLEtBQUksQ0FBQyxFQUFFLFlBQVksSUFBRyxPQUFLLE9BQUssR0FBRSxDQUFDO0FBQzVFLFdBQUssWUFBWSxHQUFFLEtBQUssTUFBTTtBQUFFLFdBQUssU0FBUyxZQUFZLEtBQUssS0FBSyxXQUFXLEVBQUUsU0FBUyxLQUFLLE1BQU0sRUFBRSxTQUFTLEtBQUssTUFBTTtBQUMzSCxXQUFLLFFBQVEsU0FBTztBQUFFLFdBQUssU0FBUyxRQUFRLFdBQVUsS0FBSyxPQUFPO0FBQ2xFLGlCQUFVLE9BQU8sS0FBSyxTQUFRO0FBQUMsWUFBSSxhQUFXO0FBQUUsWUFBSSxTQUFPO0FBQUssc0JBQWMsS0FBSyxHQUFHO0FBQUEsTUFBRTtBQUFBLElBQzFGO0FBQUEsRUFDRjtBQUFBLEVBQ1EsSUFBSSxPQUFnQixPQUFhLElBQXdCO0FBQy9ELFVBQU0sT0FBSyxNQUFNLFFBQVEsS0FBSztBQUFFLFFBQUcsS0FBSyxPQUFPLGFBQVcsU0FBTyxDQUFDLFFBQU0sQ0FBQyxHQUFHLFFBQU87QUFDbkYsV0FBTyxZQUFZLEtBQUssTUFBSyxLQUFLLFlBQVcsS0FBSyxZQUFXLEVBQUU7QUFBQSxFQUNqRTtBQUFBLEVBQ0EsVUFBUztBQUFDLFdBQU8sS0FBSyxPQUFPLE9BQU8sV0FBTyxNQUFNLEtBQUssT0FBTyxFQUFFLElBQUksV0FBTyxNQUFNLElBQUk7QUFBQSxFQUFFO0FBQUE7QUFBQTtBQUFBLEVBR3RGLFFBQU87QUFDTCxVQUFNLFNBQU8sS0FBSyxpQkFBZ0IsV0FBUyxLQUFLLFlBQVksTUFBTTtBQUNsRSxVQUFNLFFBQU0sQ0FBQyxTQUFZLEtBQUs7QUFDOUIsVUFBTSxXQUFTLEtBQUssS0FBSyxTQUFPLElBQUUsSUFBRSxDQUFDLEdBQUUsb0JBQWtCLEtBQUssTUFBTSxPQUFPLENBQUMsS0FBSSxTQUFPLE1BQUksTUFBTSxJQUFJLEdBQUUsQ0FBQyxHQUFFLGtCQUFnQixDQUFDLEdBQUcsS0FBSyxRQUFRLEVBQUUsT0FBTyxDQUFDLEtBQUksU0FBTyxPQUFLLEtBQUssV0FBUyxNQUFNLElBQUksSUFBRSxJQUFHLENBQUM7QUFDbk0sVUFBTSxrQkFBZ0IsS0FBSyxPQUFPLE9BQU8sQ0FBQyxLQUFJLFVBQVEsTUFBSSxNQUFNLEtBQUssZUFBZSxNQUFNLGFBQVcsT0FBTyxPQUFPLE1BQU0sU0FBUyxVQUFVLEVBQUUsT0FBTyxDQUFDLE9BQU0sY0FBWSxRQUFNLFVBQVUsTUFBTSxZQUFXLENBQUMsS0FBRyxNQUFNLFNBQVMsT0FBTyxNQUFNLGNBQVksSUFBRyxDQUFDO0FBQ3pQLFVBQU0sV0FBUyxLQUFLLFlBQVUsS0FBSyxtQkFBaUIsS0FBSyxtQkFBaUIsS0FBSyxXQUFXLGFBQVcsS0FBSyxVQUFVO0FBQ3BILFdBQU0sRUFBQyxPQUFNLEtBQUssTUFBTSxRQUFPLE9BQU0sS0FBSyxNQUFNLE1BQUssUUFBTyxZQUFXLEtBQUssT0FBTyxPQUFPLFdBQU8sTUFBTSxLQUFLLE9BQU8sRUFBRSxRQUFPLGtCQUFpQixLQUFLLE9BQU8sUUFBTyxjQUFhLEtBQUssT0FBTyxPQUFPLENBQUMsS0FBSSxVQUFRLE1BQUksTUFBTSxVQUFTLENBQUMsR0FBRSxpQkFBZ0IsaUJBQWdCLEtBQUssaUJBQWdCLGVBQWMsR0FBRSxVQUFTLFVBQVMsbUJBQWtCLG9CQUFtQixDQUFDLEdBQUcsS0FBSyxTQUFTLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFJLFdBQVMsTUFBSSxPQUFPLFFBQU0sT0FBTyxTQUFPLEdBQUUsQ0FBQyxHQUFFLFdBQVUsS0FBSyxXQUFVLGtCQUFpQixLQUFLLGtCQUFpQixrQkFBaUIsS0FBSyxrQkFBaUIsaUJBQWdCLEtBQUssV0FBVyxZQUFXLGlCQUFnQixhQUFZLEtBQUssWUFBWSxNQUFNLEdBQUUsZUFBYyxXQUFTLFNBQVMsa0JBQWdCLEtBQUssWUFBWSxNQUFNLEVBQUUsWUFBVyxlQUFjLEtBQUssTUFBTSxPQUFPLENBQUMsS0FBSSxTQUFPLE9BQUssS0FBSyxXQUFTLE1BQU0sSUFBSSxJQUFFLElBQUcsQ0FBQyxJQUFFLFNBQVMsaUJBQWdCLHNCQUFxQixLQUFLLHNCQUFxQixtQkFBa0IsS0FBSyxtQkFBa0IsbUJBQWtCLEtBQUssbUJBQWtCLHFCQUFvQixLQUFLLHFCQUFvQixnQkFBZSxLQUFLLGdCQUFlLGNBQWEsS0FBSyxjQUFhLGNBQWEsRUFBQyxHQUFHLEtBQUssYUFBWSxHQUFFLGtCQUFpQixLQUFLLGtCQUFpQixHQUFHLFNBQVE7QUFBQSxFQUNqb0M7QUFBQSxFQUNRLGNBQWE7QUFHbkIsVUFBTSxXQUFTLEtBQUssWUFBWSxNQUFNLEdBQUUsV0FBUyxLQUFLLFlBQVUsS0FBSyxtQkFBaUIsS0FBSyxtQkFBaUIsS0FBSyxXQUFXLGFBQVcsS0FBSyxVQUFVO0FBQ3RKLFVBQU0sZ0JBQWMsV0FBUyxTQUFTLGtCQUFnQixLQUFLLFlBQVksTUFBTSxFQUFFO0FBQy9FLFFBQUksZ0JBQWMsU0FBUyxpQkFBZ0Isa0JBQWdCO0FBQzNELGVBQVUsUUFBUSxLQUFLLE1BQU0sS0FBRyxLQUFLLFNBQVMsa0JBQWUsS0FBSztBQUNsRSxlQUFVLFFBQVEsS0FBSyxTQUFTLEtBQUcsS0FBSyxTQUFTLG9CQUFpQixLQUFLO0FBQ3ZFLFNBQUssdUJBQXFCLEtBQUssSUFBSSxLQUFLLHNCQUFxQixLQUFLLGdCQUFnQjtBQUFFLFNBQUssb0JBQWtCLEtBQUssSUFBSSxLQUFLLG1CQUFrQixhQUFhO0FBQUUsU0FBSyxvQkFBa0IsS0FBSyxJQUFJLEtBQUssbUJBQWtCLGFBQWE7QUFBRSxTQUFLLHNCQUFvQixLQUFLLElBQUksS0FBSyxxQkFBb0IsZUFBZTtBQUFBLEVBQzVTO0FBQUEsRUFDUSxPQUFPLE1BQVU7QUFDdkIsVUFBTSxjQUFZLElBQUksSUFBSSxLQUFLLE1BQU0sUUFBUSxVQUFNLE9BQUssQ0FBQyxLQUFLLFVBQVUsSUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3RSxlQUFVLFFBQVEsS0FBSyxNQUFNLEtBQUcsUUFBTSxLQUFLLE1BQU0sSUFBSSxLQUFLLEdBQUcsTUFBSSxNQUFLO0FBQUMsV0FBSyxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQUUsV0FBSyxhQUFXLEtBQUssS0FBSztBQUFBLElBQVc7QUFDeEksU0FBSyxRQUFRLFFBQVE7QUFBRSxTQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxJQUFJLEdBQUUsQ0FBQztBQUFFLFNBQUssbUJBQWlCLEtBQUssUUFBUSxNQUFNLFFBQU0sS0FBSyxRQUFRLE1BQU0sU0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqSyxlQUFVLFFBQVEsWUFBWSxLQUFHLENBQUMsS0FBSyxNQUFNLEtBQUssV0FBTyxNQUFNLE1BQU0sS0FBSyxVQUFNLE1BQU0sZUFBYSxJQUFJLENBQUMsRUFBRSxNQUFLLFlBQVksWUFBWSxNQUFLLElBQUk7QUFBQSxFQUNsSjtBQUFBLEVBQ0EsVUFBUztBQUNQLGVBQVUsU0FBUyxLQUFLLE9BQU8sTUFBSyxZQUFZLEtBQUs7QUFBRSxTQUFLLE9BQU8sU0FBTztBQUFFLFNBQUssTUFBTSxPQUFPLEtBQUssU0FBUztBQUFFLFNBQUssVUFBVSxTQUFPO0FBQUUsU0FBSyxTQUFTLE1BQU07QUFDMUosU0FBSyxZQUFZLE1BQU07QUFBRSxlQUFVLFFBQVEsQ0FBQyxHQUFHLEtBQUssS0FBSyxFQUFFLE1BQUssT0FBTyxJQUFJO0FBQUUsU0FBSyxTQUFTLE1BQU07QUFBRSxlQUFVLFVBQVUsS0FBSyxTQUFTLE9BQU8sRUFBRSxRQUFPLFFBQU0sT0FBTyxTQUFPO0FBQUUsU0FBSyxTQUFTLE1BQU07QUFBRSxTQUFLLFFBQVEsU0FBTztBQUFFLFNBQUssbUJBQWlCLEtBQUssbUJBQWlCLEtBQUssWUFBVTtBQUFFLFNBQUssYUFBVyxJQUFJLFdBQVcsQ0FBQztBQUFFLFNBQUssWUFBVSxJQUFJLFdBQVcsQ0FBQztBQUFFLFNBQUssWUFBWSxRQUFRO0FBQUUsU0FBSyxTQUFTLFNBQVMsUUFBUTtBQUFFLFNBQUssU0FBUyxTQUFTLFFBQVE7QUFBQSxFQUFFO0FBRXhiO0FBTUEsU0FBUyxTQUFTLE1BQXVCO0FBQ3ZDLFdBQVEsSUFBRSxHQUFFLElBQUUsS0FBSyxRQUFPLEtBQUcsRUFBRSxLQUFHLEtBQUssQ0FBQyxFQUFFLFFBQU87QUFDakQsU0FBTztBQUNUOyIsIm5hbWVzIjpbXX0=