import { combatCapability } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/combat-capabilities.ts";
import { sameGround } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/terrain.ts";
import { shipsIn, shipProfile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { areEnemyOwners } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/sim/command-validation.ts";
import { isTransportKind } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/transport-role.ts";
export const SHIP_GUARD_LEASH = 900;
export const SHIP_GUARD_RETURN_RADIUS = 24;
export function combatHull(ship) {
  return Boolean(shipProfile(ship)) && !isTransportKind(ship.kind);
}
export function prepareShipDefenseFrame(snapshot, nearby, held = /* @__PURE__ */ new Set()) {
  const result = /* @__PURE__ */ new Map();
  const ships = shipsIn(snapshot.units);
  if (!ships.length) return result;
  const byId = new Map(ships.map((ship) => [ship.id, ship]));
  const reserved = new Set(held);
  const claims = /* @__PURE__ */ new Map();
  for (const crew of snapshot.units) {
    if (crew.hp <= 0 || crew.order.type !== "board") continue;
    reserved.add(crew.order.transportId);
    const claimants = claims.get(crew.order.transportId);
    if (claimants) claimants.push(crew.owner);
    else claims.set(crew.order.transportId, [crew.owner]);
    if (crew.deck) reserved.add(crew.deck.shipId);
    if (crew.order.rendezvous) reserved.add(crew.order.rendezvous.sourceId);
  }
  const capabilities = new Map(ships.map((ship) => [ship.id, combatCapability(snapshot, ship)]));
  for (const ship of ships) {
    if (!ship.sailing) continue;
    const capability = capabilities.get(ship.id);
    if (ship.hp <= 0 || ship.owner === "neutral" || ship.order.type !== "idle" || ship.orderQueue?.length || !combatHull(ship) || !capability.armed || reserved.has(ship.id)) {
      if (ship.sailing.defense) {
        delete ship.sailing.defense;
        delete ship.sailing.pursuit;
        if (ship.sailing.route?.intent === "pursuit") ship.sailing.route = void 0;
      }
      continue;
    }
    const guard = ship.sailing.defense ??= { originX: ship.x, originY: ship.y };
    const origin = { x: guard.originX, y: guard.originY };
    const homeGap = Math.hypot(ship.x - origin.x, ship.y - origin.y);
    const acquisition = Math.min(700, Math.max(450, capability.range + shipProfile(ship).length * 0.4 + 100));
    const valid = (enemy) => enemy.hp > 0 && enemy.owner !== "neutral" && enemy.id !== ship.id && Boolean(shipProfile(enemy)) && capabilities.get(enemy.id)?.armed && areEnemyOwners(snapshot, ship.owner, enemy.owner) && !claims.get(enemy.id)?.some((owner) => !areEnemyOwners(snapshot, ship.owner, owner)) && Math.hypot(enemy.x - origin.x, enemy.y - origin.y) <= SHIP_GUARD_LEASH && sameGround(snapshot.map, ship, enemy, "sea");
    let target = guard.targetId ? byId.get(guard.targetId) : void 0;
    if (homeGap > SHIP_GUARD_LEASH || guard.targetId && (!target || !valid(target))) {
      target = void 0;
      delete guard.targetId;
      guard.returning = homeGap > SHIP_GUARD_RETURN_RADIUS;
      delete ship.sailing.pursuit;
      ship.sailing.route = void 0;
    }
    if (guard.returning) {
      if (homeGap > SHIP_GUARD_RETURN_RADIUS) {
        result.set(ship.id, { returnTo: origin });
        continue;
      }
      delete guard.returning;
    }
    if (!target) {
      let bestGap = Infinity, bestId = "￿";
      const best = {};
      nearby(ship, acquisition, (enemy) => {
        const gap = Math.hypot(enemy.x - ship.x, enemy.y - ship.y);
        if (gap > acquisition || !valid(enemy)) return;
        if (gap < bestGap || gap === bestGap && enemy.id < bestId) {
          best.target = enemy;
          bestGap = gap;
          bestId = enemy.id;
        }
      });
      target = best.target;
      if (target) guard.targetId = target.id;
    }
    if (target) result.set(ship.id, { target });
    else if (homeGap > SHIP_GUARD_RETURN_RADIUS) {
      guard.returning = true;
      delete ship.sailing.pursuit;
      ship.sailing.route = void 0;
      result.set(ship.id, { returnTo: origin });
    }
  }
  return result;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoaXAtZGVmZW5zZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjb21iYXRDYXBhYmlsaXR5IH0gZnJvbSAnLi9jb21iYXQtY2FwYWJpbGl0aWVzJztcbmltcG9ydCB7IHNhbWVHcm91bmQgfSBmcm9tICcuL3RlcnJhaW4nO1xuaW1wb3J0IHsgc2hpcHNJbiwgc2hpcFByb2ZpbGUgfSBmcm9tICcuL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHsgYXJlRW5lbXlPd25lcnMgfSBmcm9tICcuL3NpbS9jb21tYW5kLXZhbGlkYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBHYW1lU25hcHNob3QsIFVuaXQgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IGlzVHJhbnNwb3J0S2luZCB9IGZyb20gJy4vdHJhbnNwb3J0LXJvbGUnO1xuXG5leHBvcnQgY29uc3QgU0hJUF9HVUFSRF9MRUFTSCA9IDkwMDtcbmV4cG9ydCBjb25zdCBTSElQX0dVQVJEX1JFVFVSTl9SQURJVVMgPSAyNDtcbmV4cG9ydCB0eXBlIFNoaXBEZWZlbnNlSW50ZW50ID0geyB0YXJnZXQ/OiBVbml0OyByZXR1cm5Ubz86IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB9O1xuZXhwb3J0IHR5cGUgU2hpcERlZmVuc2VGcmFtZSA9IE1hcDxzdHJpbmcsIFNoaXBEZWZlbnNlSW50ZW50PjtcbnR5cGUgRGVmZW5zZVNuYXBzaG90ID0gUGljazxHYW1lU25hcHNob3QsICd1bml0cycgfCAnaXRlbXMnIHwgJ3ZhcmlhbnRzJyB8ICdtYXAnIHwgJ3RlYW1zJz47XG4vKiogVGhlIGNhbGxlciBzdXBwbGllcyBpdHMgZXhpc3Rpbmcgc3BhdGlhbCBxdWVyeS4gQSBmbGVldCBuZXZlciBzY2FucyB0aGVcbiAqIGVudGlyZSBhcm15IGFnYWluIGZvciBldmVyeSBpZGxlIGh1bGwuICovXG5leHBvcnQgdHlwZSBOZWFyYnlFbmVteVNoaXBzID0gKHNoaXA6IFVuaXQsIHJhbmdlOiBudW1iZXIsIHZpc2l0OiAoZW5lbXk6IFVuaXQpID0+IHZvaWQpID0+IHZvaWQ7XG5cbi8qKiBDYXJyeWluZyBzb2xkaWVycyBvciBzaGVsdGVyZWQgY3JldyBkb2VzIG5vdCB0dXJuIGEgZmVycnkgaW50byBhIGh1bnRlci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21iYXRIdWxsKHNoaXA6IFVuaXQpOiBib29sZWFuIHtcbiAgcmV0dXJuIEJvb2xlYW4oc2hpcFByb2ZpbGUoc2hpcCkpICYmICFpc1RyYW5zcG9ydEtpbmQoc2hpcC5raW5kKTtcbn1cblxuLyoqIElkbGUgZGVmZW5zZSByZXRhaW5zIGEgc2F2ZWQgaG9tZSBzdGF0aW9uIGFuZCBodWxsIHRhcmdldCB3aXRob3V0IHJlcGxhY2luZ1xuICogdGhlIHBsYXllcidzIG9yZGVyLiBIb2xkIGFuZCBldmVyeSBleHBsaWNpdCB0YXNrIHJlbWFpbiBtb3ZlbWVudCBhdXRob3JpdGllcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmVwYXJlU2hpcERlZmVuc2VGcmFtZShzbmFwc2hvdDogRGVmZW5zZVNuYXBzaG90LCBuZWFyYnk6IE5lYXJieUVuZW15U2hpcHMsIGhlbGQ6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KCkpOiBTaGlwRGVmZW5zZUZyYW1lIHtcbiAgY29uc3QgcmVzdWx0OiBTaGlwRGVmZW5zZUZyYW1lID0gbmV3IE1hcCgpO1xuICBjb25zdCBzaGlwcyA9IHNoaXBzSW4oc25hcHNob3QudW5pdHMpO1xuICBpZiAoIXNoaXBzLmxlbmd0aCkgcmV0dXJuIHJlc3VsdDtcbiAgY29uc3QgYnlJZCA9IG5ldyBNYXAoc2hpcHMubWFwKHNoaXAgPT4gW3NoaXAuaWQsIHNoaXBdKSk7XG4gIGNvbnN0IHJlc2VydmVkID0gbmV3IFNldChoZWxkKTtcbiAgY29uc3QgY2xhaW1zID0gbmV3IE1hcDxzdHJpbmcsIFVuaXRbJ293bmVyJ11bXT4oKTtcbiAgZm9yIChjb25zdCBjcmV3IG9mIHNuYXBzaG90LnVuaXRzKSB7XG4gICAgaWYgKGNyZXcuaHAgPD0gMCB8fCBjcmV3Lm9yZGVyLnR5cGUgIT09ICdib2FyZCcpIGNvbnRpbnVlO1xuICAgIHJlc2VydmVkLmFkZChjcmV3Lm9yZGVyLnRyYW5zcG9ydElkKTtcbiAgICBjb25zdCBjbGFpbWFudHMgPSBjbGFpbXMuZ2V0KGNyZXcub3JkZXIudHJhbnNwb3J0SWQpO1xuICAgIGlmIChjbGFpbWFudHMpIGNsYWltYW50cy5wdXNoKGNyZXcub3duZXIpOyBlbHNlIGNsYWltcy5zZXQoY3Jldy5vcmRlci50cmFuc3BvcnRJZCwgW2NyZXcub3duZXJdKTtcbiAgICBpZiAoY3Jldy5kZWNrKSByZXNlcnZlZC5hZGQoY3Jldy5kZWNrLnNoaXBJZCk7XG4gICAgaWYgKGNyZXcub3JkZXIucmVuZGV6dm91cykgcmVzZXJ2ZWQuYWRkKGNyZXcub3JkZXIucmVuZGV6dm91cy5zb3VyY2VJZCk7XG4gIH1cbiAgY29uc3QgY2FwYWJpbGl0aWVzID0gbmV3IE1hcChzaGlwcy5tYXAoc2hpcCA9PiBbc2hpcC5pZCwgY29tYmF0Q2FwYWJpbGl0eShzbmFwc2hvdCwgc2hpcCldKSk7XG4gIGZvciAoY29uc3Qgc2hpcCBvZiBzaGlwcykge1xuICAgIGlmICghc2hpcC5zYWlsaW5nKSBjb250aW51ZTtcbiAgICBjb25zdCBjYXBhYmlsaXR5ID0gY2FwYWJpbGl0aWVzLmdldChzaGlwLmlkKSE7XG4gICAgaWYgKHNoaXAuaHAgPD0gMCB8fCBzaGlwLm93bmVyID09PSAnbmV1dHJhbCcgfHwgc2hpcC5vcmRlci50eXBlICE9PSAnaWRsZScgfHwgc2hpcC5vcmRlclF1ZXVlPy5sZW5ndGhcbiAgICAgIHx8ICFjb21iYXRIdWxsKHNoaXApIHx8ICFjYXBhYmlsaXR5LmFybWVkIHx8IHJlc2VydmVkLmhhcyhzaGlwLmlkKSkge1xuICAgICAgaWYgKHNoaXAuc2FpbGluZy5kZWZlbnNlKSB7XG4gICAgICAgIGRlbGV0ZSBzaGlwLnNhaWxpbmcuZGVmZW5zZTtcbiAgICAgICAgZGVsZXRlIHNoaXAuc2FpbGluZy5wdXJzdWl0O1xuICAgICAgICBpZiAoc2hpcC5zYWlsaW5nLnJvdXRlPy5pbnRlbnQgPT09ICdwdXJzdWl0Jykgc2hpcC5zYWlsaW5nLnJvdXRlID0gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGd1YXJkID0gc2hpcC5zYWlsaW5nLmRlZmVuc2UgPz89IHsgb3JpZ2luWDogc2hpcC54LCBvcmlnaW5ZOiBzaGlwLnkgfTtcbiAgICBjb25zdCBvcmlnaW4gPSB7IHg6IGd1YXJkLm9yaWdpblgsIHk6IGd1YXJkLm9yaWdpblkgfTtcbiAgICBjb25zdCBob21lR2FwID0gTWF0aC5oeXBvdChzaGlwLnggLSBvcmlnaW4ueCwgc2hpcC55IC0gb3JpZ2luLnkpO1xuICAgIGNvbnN0IGFjcXVpc2l0aW9uID0gTWF0aC5taW4oNzAwLCBNYXRoLm1heCg0NTAsIGNhcGFiaWxpdHkucmFuZ2UgKyBzaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoICogLjQgKyAxMDApKTtcbiAgICBjb25zdCB2YWxpZCA9IChlbmVteTogVW5pdCkgPT4gZW5lbXkuaHAgPiAwICYmIGVuZW15Lm93bmVyICE9PSAnbmV1dHJhbCdcbiAgICAgICYmIGVuZW15LmlkICE9PSBzaGlwLmlkICYmIEJvb2xlYW4oc2hpcFByb2ZpbGUoZW5lbXkpKSAmJiBjYXBhYmlsaXRpZXMuZ2V0KGVuZW15LmlkKT8uYXJtZWRcbiAgICAgICYmIGFyZUVuZW15T3duZXJzKHNuYXBzaG90LCBzaGlwLm93bmVyLCBlbmVteS5vd25lcilcbiAgICAgICYmICFjbGFpbXMuZ2V0KGVuZW15LmlkKT8uc29tZShvd25lciA9PiAhYXJlRW5lbXlPd25lcnMoc25hcHNob3QsIHNoaXAub3duZXIsIG93bmVyKSlcbiAgICAgICYmIE1hdGguaHlwb3QoZW5lbXkueCAtIG9yaWdpbi54LCBlbmVteS55IC0gb3JpZ2luLnkpIDw9IFNISVBfR1VBUkRfTEVBU0hcbiAgICAgICYmIHNhbWVHcm91bmQoc25hcHNob3QubWFwLCBzaGlwLCBlbmVteSwgJ3NlYScpO1xuICAgIGxldCB0YXJnZXQgPSBndWFyZC50YXJnZXRJZCA/IGJ5SWQuZ2V0KGd1YXJkLnRhcmdldElkKSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoaG9tZUdhcCA+IFNISVBfR1VBUkRfTEVBU0ggfHwgZ3VhcmQudGFyZ2V0SWQgJiYgKCF0YXJnZXQgfHwgIXZhbGlkKHRhcmdldCkpKSB7XG4gICAgICB0YXJnZXQgPSB1bmRlZmluZWQ7XG4gICAgICBkZWxldGUgZ3VhcmQudGFyZ2V0SWQ7XG4gICAgICBndWFyZC5yZXR1cm5pbmcgPSBob21lR2FwID4gU0hJUF9HVUFSRF9SRVRVUk5fUkFESVVTO1xuICAgICAgZGVsZXRlIHNoaXAuc2FpbGluZy5wdXJzdWl0O1xuICAgICAgc2hpcC5zYWlsaW5nLnJvdXRlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoZ3VhcmQucmV0dXJuaW5nKSB7XG4gICAgICBpZiAoaG9tZUdhcCA+IFNISVBfR1VBUkRfUkVUVVJOX1JBRElVUykge1xuICAgICAgICByZXN1bHQuc2V0KHNoaXAuaWQsIHsgcmV0dXJuVG86IG9yaWdpbiB9KTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBkZWxldGUgZ3VhcmQucmV0dXJuaW5nO1xuICAgIH1cbiAgICBpZiAoIXRhcmdldCkge1xuICAgICAgbGV0IGJlc3RHYXAgPSBJbmZpbml0eSwgYmVzdElkID0gJ1xcdWZmZmYnO1xuICAgICAgY29uc3QgYmVzdDogeyB0YXJnZXQ/OiBVbml0IH0gPSB7fTtcbiAgICAgIG5lYXJieShzaGlwLCBhY3F1aXNpdGlvbiwgZW5lbXkgPT4ge1xuICAgICAgICBjb25zdCBnYXAgPSBNYXRoLmh5cG90KGVuZW15LnggLSBzaGlwLngsIGVuZW15LnkgLSBzaGlwLnkpO1xuICAgICAgICBpZiAoZ2FwID4gYWNxdWlzaXRpb24gfHwgIXZhbGlkKGVuZW15KSkgcmV0dXJuO1xuICAgICAgICBpZiAoZ2FwIDwgYmVzdEdhcCB8fCBnYXAgPT09IGJlc3RHYXAgJiYgZW5lbXkuaWQgPCBiZXN0SWQpIHsgYmVzdC50YXJnZXQgPSBlbmVteTsgYmVzdEdhcCA9IGdhcDsgYmVzdElkID0gZW5lbXkuaWQ7IH1cbiAgICAgIH0pO1xuICAgICAgdGFyZ2V0ID0gYmVzdC50YXJnZXQ7XG4gICAgICBpZiAodGFyZ2V0KSBndWFyZC50YXJnZXRJZCA9IHRhcmdldC5pZDtcbiAgICB9XG4gICAgaWYgKHRhcmdldCkgcmVzdWx0LnNldChzaGlwLmlkLCB7IHRhcmdldCB9KTtcbiAgICBlbHNlIGlmIChob21lR2FwID4gU0hJUF9HVUFSRF9SRVRVUk5fUkFESVVTKSB7XG4gICAgICBndWFyZC5yZXR1cm5pbmcgPSB0cnVlO1xuICAgICAgZGVsZXRlIHNoaXAuc2FpbGluZy5wdXJzdWl0O1xuICAgICAgc2hpcC5zYWlsaW5nLnJvdXRlID0gdW5kZWZpbmVkO1xuICAgICAgcmVzdWx0LnNldChzaGlwLmlkLCB7IHJldHVyblRvOiBvcmlnaW4gfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsU0FBUyxtQkFBbUI7QUFDckMsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyx1QkFBdUI7QUFFekIsYUFBTSxtQkFBbUI7QUFDekIsYUFBTSwyQkFBMkI7QUFTakMsZ0JBQVMsV0FBVyxNQUFxQjtBQUM5QyxTQUFPLFFBQVEsWUFBWSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixLQUFLLElBQUk7QUFDakU7QUFJTyxnQkFBUyx3QkFBd0IsVUFBMkIsUUFBMEIsT0FBNEIsb0JBQUksSUFBSSxHQUFxQjtBQUNwSixRQUFNLFNBQTJCLG9CQUFJLElBQUk7QUFDekMsUUFBTSxRQUFRLFFBQVEsU0FBUyxLQUFLO0FBQ3BDLE1BQUksQ0FBQyxNQUFNLE9BQVEsUUFBTztBQUMxQixRQUFNLE9BQU8sSUFBSSxJQUFJLE1BQU0sSUFBSSxVQUFRLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sV0FBVyxJQUFJLElBQUksSUFBSTtBQUM3QixRQUFNLFNBQVMsb0JBQUksSUFBNkI7QUFDaEQsYUFBVyxRQUFRLFNBQVMsT0FBTztBQUNqQyxRQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxTQUFTLFFBQVM7QUFDakQsYUFBUyxJQUFJLEtBQUssTUFBTSxXQUFXO0FBQ25DLFVBQU0sWUFBWSxPQUFPLElBQUksS0FBSyxNQUFNLFdBQVc7QUFDbkQsUUFBSSxVQUFXLFdBQVUsS0FBSyxLQUFLLEtBQUs7QUFBQSxRQUFRLFFBQU8sSUFBSSxLQUFLLE1BQU0sYUFBYSxDQUFDLEtBQUssS0FBSyxDQUFDO0FBQy9GLFFBQUksS0FBSyxLQUFNLFVBQVMsSUFBSSxLQUFLLEtBQUssTUFBTTtBQUM1QyxRQUFJLEtBQUssTUFBTSxXQUFZLFVBQVMsSUFBSSxLQUFLLE1BQU0sV0FBVyxRQUFRO0FBQUEsRUFDeEU7QUFDQSxRQUFNLGVBQWUsSUFBSSxJQUFJLE1BQU0sSUFBSSxVQUFRLENBQUMsS0FBSyxJQUFJLGlCQUFpQixVQUFVLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDM0YsYUFBVyxRQUFRLE9BQU87QUFDeEIsUUFBSSxDQUFDLEtBQUssUUFBUztBQUNuQixVQUFNLGFBQWEsYUFBYSxJQUFJLEtBQUssRUFBRTtBQUMzQyxRQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssVUFBVSxhQUFhLEtBQUssTUFBTSxTQUFTLFVBQVUsS0FBSyxZQUFZLFVBQzFGLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxXQUFXLFNBQVMsU0FBUyxJQUFJLEtBQUssRUFBRSxHQUFHO0FBQ3BFLFVBQUksS0FBSyxRQUFRLFNBQVM7QUFDeEIsZUFBTyxLQUFLLFFBQVE7QUFDcEIsZUFBTyxLQUFLLFFBQVE7QUFDcEIsWUFBSSxLQUFLLFFBQVEsT0FBTyxXQUFXLFVBQVcsTUFBSyxRQUFRLFFBQVE7QUFBQSxNQUNyRTtBQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFBUSxLQUFLLFFBQVEsWUFBWSxFQUFFLFNBQVMsS0FBSyxHQUFHLFNBQVMsS0FBSyxFQUFFO0FBQzFFLFVBQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLEdBQUcsTUFBTSxRQUFRO0FBQ3BELFVBQU0sVUFBVSxLQUFLLE1BQU0sS0FBSyxJQUFJLE9BQU8sR0FBRyxLQUFLLElBQUksT0FBTyxDQUFDO0FBQy9ELFVBQU0sY0FBYyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxXQUFXLFFBQVEsWUFBWSxJQUFJLEVBQUcsU0FBUyxNQUFLLEdBQUcsQ0FBQztBQUN4RyxVQUFNLFFBQVEsQ0FBQyxVQUFnQixNQUFNLEtBQUssS0FBSyxNQUFNLFVBQVUsYUFDMUQsTUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLFlBQVksS0FBSyxDQUFDLEtBQUssYUFBYSxJQUFJLE1BQU0sRUFBRSxHQUFHLFNBQ25GLGVBQWUsVUFBVSxLQUFLLE9BQU8sTUFBTSxLQUFLLEtBQ2hELENBQUMsT0FBTyxJQUFJLE1BQU0sRUFBRSxHQUFHLEtBQUssV0FBUyxDQUFDLGVBQWUsVUFBVSxLQUFLLE9BQU8sS0FBSyxDQUFDLEtBQ2pGLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxHQUFHLE1BQU0sSUFBSSxPQUFPLENBQUMsS0FBSyxvQkFDdEQsV0FBVyxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUs7QUFDaEQsUUFBSSxTQUFTLE1BQU0sV0FBVyxLQUFLLElBQUksTUFBTSxRQUFRLElBQUk7QUFDekQsUUFBSSxVQUFVLG9CQUFvQixNQUFNLGFBQWEsQ0FBQyxVQUFVLENBQUMsTUFBTSxNQUFNLElBQUk7QUFDL0UsZUFBUztBQUNULGFBQU8sTUFBTTtBQUNiLFlBQU0sWUFBWSxVQUFVO0FBQzVCLGFBQU8sS0FBSyxRQUFRO0FBQ3BCLFdBQUssUUFBUSxRQUFRO0FBQUEsSUFDdkI7QUFDQSxRQUFJLE1BQU0sV0FBVztBQUNuQixVQUFJLFVBQVUsMEJBQTBCO0FBQ3RDLGVBQU8sSUFBSSxLQUFLLElBQUksRUFBRSxVQUFVLE9BQU8sQ0FBQztBQUN4QztBQUFBLE1BQ0Y7QUFDQSxhQUFPLE1BQU07QUFBQSxJQUNmO0FBQ0EsUUFBSSxDQUFDLFFBQVE7QUFDWCxVQUFJLFVBQVUsVUFBVSxTQUFTO0FBQ2pDLFlBQU0sT0FBMEIsQ0FBQztBQUNqQyxhQUFPLE1BQU0sYUFBYSxXQUFTO0FBQ2pDLGNBQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxJQUFJLEtBQUssR0FBRyxNQUFNLElBQUksS0FBSyxDQUFDO0FBQ3pELFlBQUksTUFBTSxlQUFlLENBQUMsTUFBTSxLQUFLLEVBQUc7QUFDeEMsWUFBSSxNQUFNLFdBQVcsUUFBUSxXQUFXLE1BQU0sS0FBSyxRQUFRO0FBQUUsZUFBSyxTQUFTO0FBQU8sb0JBQVU7QUFBSyxtQkFBUyxNQUFNO0FBQUEsUUFBSTtBQUFBLE1BQ3RILENBQUM7QUFDRCxlQUFTLEtBQUs7QUFDZCxVQUFJLE9BQVEsT0FBTSxXQUFXLE9BQU87QUFBQSxJQUN0QztBQUNBLFFBQUksT0FBUSxRQUFPLElBQUksS0FBSyxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBQUEsYUFDakMsVUFBVSwwQkFBMEI7QUFDM0MsWUFBTSxZQUFZO0FBQ2xCLGFBQU8sS0FBSyxRQUFRO0FBQ3BCLFdBQUssUUFBUSxRQUFRO0FBQ3JCLGFBQU8sSUFBSSxLQUFLLElBQUksRUFBRSxVQUFVLE9BQU8sQ0FBQztBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDsiLCJuYW1lcyI6W119