import { polygon, line, darker } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/kit.ts";
const STONE = "#dfd3b7", CUT = "#b8b5a0", WOOD = "#8b7054", SLATE = "#71928f", IRON = "#86948f";
const project = ([x, y, z]) => [x * 0.82 - y * 0.57, x * 0.28 + y * 0.4 - z + 19];
function tint(hex, light) {
  const n = parseInt(hex.slice(1), 16);
  return `rgb(${[16, 8, 0].map((s, i) => Math.max(0, Math.min(255, Math.round((n >> s & 255) * light + (light < 0.9 ? [0, 4, 9][i] : [8, 5, 0][i]))))).join(",")})`;
}
class Construction {
  faces = [];
  face(p, color, normal, grain = 1) {
    this.faces.push({ p, color, normal, grain });
  }
  box(x, y, z, w, d, h, color, grain = 1) {
    const a = x - w / 2, aa = x + w / 2, bb = y + d / 2, q = y - d / 2, top = z + h;
    this.face([[a, bb, z], [aa, bb, z], [aa, bb, top], [a, bb, top]], color, [0, 1, 0], grain);
    this.face([[aa, q, z], [aa, bb, z], [aa, bb, top], [aa, q, top]], color, [1, 0, 0], grain);
    this.face([[a, q, top], [aa, q, top], [aa, bb, top], [a, bb, top]], color, [0, 0, 1], grain);
    this.face([[a, q, z], [a, q, top], [aa, q, top], [aa, q, z]], color, [0, -1, 0], grain);
    this.face([[a, q, z], [a, bb, z], [a, bb, top], [a, q, top]], color, [-1, 0, 0], grain);
    this.face([[a, q, z], [aa, q, z], [aa, bb, z], [a, bb, z]], color, [0, 0, -1], 0);
  }
  roof(x, y, z, w, d, h, color = SLATE) {
    const a = x - w / 2, aa = x + w / 2, q = y - d / 2, bb = y + d / 2;
    this.face([[a, q, z], [aa, q, z], [aa, y, z + h], [a, y, z + h]], color, [0, -0.75, 0.66]);
    this.face([[a, y, z + h], [aa, y, z + h], [aa, bb, z], [a, bb, z]], color, [0, 0.75, 0.66]);
    this.face([[aa, q, z], [aa, bb, z], [aa, y, z + h]], STONE, [1, 0, 0]);
    this.face([[a, q, z], [a, y, z + h], [a, bb, z]], STONE, [-1, 0, 0]);
    this.face([[a, q, z], [a, bb, z], [aa, bb, z], [aa, q, z]], color, [0, 0, -1]);
    for (let row = 1; row < 5; row++) {
      const t = row / 5, yy = y + d / 2 * t, zz = z + h * (1 - t) + 0.18;
      this.face([[a, yy, zz], [aa, yy, zz], [aa, yy + 0.35, zz - 0.15], [a, yy + 0.35, zz - 0.15]], "#9a9c8b", [0, 0.75, 0.66], 0);
      for (let k = 0; k < 5; k++) {
        const xx = a + (k + row % 2 * 0.5) * w / 5;
        this.face([[xx, yy, zz + 0.03], [xx + 0.35, yy, zz + 0.03], [xx + 0.35, yy + d / 10, zz - h / 5], [xx, yy + d / 10, zz - h / 5]], "#39494b", [0, 0.75, 0.66], 0);
      }
    }
    this.box(x, y, z + h - 0.5, w + 1, 1.2, 1.2, "#a6a18b", 0);
  }
  // Tapered polygonal masses give each building a legible roof/body silhouette.
  drum(x, y, z, r, h, color, n = 8, top = r) {
    for (let i = 0; i < n; i++) {
      const a = i * Math.PI * 2 / n, q = (i + 1) * Math.PI * 2 / n, mid = (a + q) / 2;
      this.face([[x + Math.cos(a) * r, y + Math.sin(a) * r, z], [x + Math.cos(q) * r, y + Math.sin(q) * r, z], [x + Math.cos(q) * top, y + Math.sin(q) * top, z + h], [x + Math.cos(a) * top, y + Math.sin(a) * top, z + h]], color, [Math.cos(mid), Math.sin(mid), 0]);
    }
    this.face(Array.from({ length: n }, (_, i) => [x + Math.cos(-i * 2 * Math.PI / n) * r, y + Math.sin(-i * 2 * Math.PI / n) * r, z]), color, [0, 0, -1]);
    this.face(Array.from({ length: n }, (_, i) => [x + Math.cos(i * 2 * Math.PI / n) * top, y + Math.sin(i * 2 * Math.PI / n) * top, z + h]), color, [0, 0, 1]);
  }
  cap(x, y, z, r, h, color = SLATE, n = 8) {
    for (let i = 0; i < n; i++) {
      const a = i * Math.PI * 2 / n, q = (i + 1) * Math.PI * 2 / n, mid = (a + q) / 2;
      this.face([[x + Math.cos(a) * r, y + Math.sin(a) * r, z], [x + Math.cos(q) * r, y + Math.sin(q) * r, z], [x, y, z + h]], color, [Math.cos(mid) * 0.65, Math.sin(mid) * 0.65, 0.76]);
    }
  }
  banner(x, y, z, team) {
    this.box(x, y, 0, 0.9, 0.9, z + 2, WOOD, 0);
    this.face([[x + 0.5, y, z], [x + 9, y, z - 1], [x + 7, y, z - 8], [x + 0.5, y, z - 7]], team, [0, 1, 0], 0);
  }
  door(x, y, z, w, h) {
    const p = [[x - w / 2, y, z], [x + w / 2, y, z], [x + w / 2, y, z + h * 0.7], [x + w * 0.3, y, z + h * 0.92], [x, y, z + h], [x - w * 0.3, y, z + h * 0.92], [x - w / 2, y, z + h * 0.7]];
    this.face(p, "#303831", [0, 1, 0], 0);
    this.box(x - w / 2 - 1, y, z, 1.4, 1.4, h * 0.72, CUT);
    this.box(x + w / 2 + 1, y, z, 1.4, 1.4, h * 0.72, CUT);
    this.box(x, y + 2, 0, w + 5, 5, 1.5, CUT);
  }
  fence(x, y, w) {
    for (let i = 0; i <= 4; i++) this.box(x - w / 2 + i * w / 4, y, 0, 1.3, 1.3, 8, WOOD);
    for (const z of [3, 6]) this.box(x, y, z, w, 1, 1, WOOD);
  }
}
const BASALT = "#898b7c", COPPER = "#b3825d", BRASS = "#d2b779";
function build(kind, team) {
  const m = new Construction();
  switch (kind) {
    case "citadel": {
      m.box(0, 0, 0, 67, 56, 3, CUT);
      m.box(0, 0, 3, 55, 44, 11, BASALT);
      m.box(0, -6, 14, 30, 27, 25, STONE);
      m.roof(0, -6, 39, 36, 32, 11, SLATE);
      for (const x of [-24, 24]) for (const y of [-19, 19]) {
        m.drum(x, y, 3, 9, 30, STONE, 8);
        m.drum(x, y, 31, 10, 4, CUT, 8);
        m.cap(x, y, 35, 12, 12, SLATE);
        m.door(x, y + 9, 14, 3, 7);
      }
      m.box(0, 22, 3, 25, 7, 22, STONE);
      m.door(0, 26, 3, 11, 18);
      for (const x of [-10, 0, 10]) m.box(x, 22, 25, 5, 8, 4, CUT);
      for (const x of [-9, 9]) m.door(x, 8, 24, 3, 8);
      m.banner(-19, -8, 53, team);
      m.banner(18, -8, 51, team);
      break;
    }
    case "shop": {
      m.box(0, 0, 0, 62, 44, 2, CUT);
      m.box(-5, -8, 2, 37, 25, 23, STONE);
      m.roof(-5, -8, 25, 44, 32, 14, SLATE);
      m.box(0, 14, 2, 42, 9, 12, WOOD);
      m.box(0, 14, 14, 46, 12, 2, "#a38e6a");
      for (const x of [-24, 24]) m.box(x, 22, 0, 1.8, 1.8, 27, WOOD);
      m.face([[-25, 0, 30], [25, 0, 30], [25, 24, 25], [-25, 24, 25]], "#bcad8c", [0, 0.25, 1]);
      for (const x of [-18, -6, 6, 18]) m.face([[x - 3, 0, 30.1], [x + 3, 0, 30.1], [x + 3, 24, 25.1], [x - 3, 24, 25.1]], "#776355", [0, 0.25, 1]);
      m.box(27, -7, 0, 2, 2, 34, WOOD);
      m.box(34, -7, 31, 16, 1.5, 1.5, WOOD);
      m.box(38, -7, 20, 11, 2, 9, "#a38c59");
      m.drum(38, -5.5, 23, 2, 3, BRASS, 8);
      for (const [x, color] of [[-14, "#8e7c55"], [-3, "#536965"], [9, "#a39777"]]) m.drum(x, 13, 16, 3.5, 5, color, 8, 2);
      for (const x of [23, 31]) m.box(x, -14, 0, 7, 8, 8, WOOD);
      break;
    }
    case "camp": {
      m.box(0, 0, 0, 58, 44, 1, "#80765e");
      m.face([[-24, -17, 2], [-24, 17, 2], [-24, 0, 34]], "#b4a78a", [-1, 0, 0.5]);
      m.face([[-24, 0, 34], [22, 0, 34], [27, 20, 1], [-28, 20, 1]], "#9a8a6f", [0, 0.75, 0.65]);
      m.face([[-24, -17, 2], [22, -17, 2], [22, 0, 34], [-24, 0, 34]], "#c3b494", [0, -0.75, 0.65]);
      m.face([[22, -17, 2], [27, 20, 1], [22, 0, 34]], "#75694f", [1, 0, 0.3]);
      m.face([[25, 4, 2], [25, 14, 2], [23, 4, 23]], "#353731", [1, 0, 0]);
      for (const x of [-28, 28]) for (const y of [-25, 25]) {
        m.box(x, y, 0, 1, 1, 4, WOOD);
        m.face([[x, y, 3], [x + 0.6, y, 3], [x * 0.8, y * 0.65, 26]], "#8f8164", [0, 1, 0], 0);
      }
      m.banner(-32, 15, 38, "#8b6e49");
      m.box(30, -12, 0, 8, 10, 8, WOOD);
      m.box(-22, 28, 0, 15, 4, 3, WOOD);
      m.box(-22, 28, 3, 9, 1, 12, IRON);
      break;
    }
    case "well": {
      m.drum(0, 0, 0, 16, 12, CUT, 10);
      m.drum(0, 0, 12, 13, 1, "#3e4848", 10);
      for (const x of [-17, 17]) m.box(x, 0, 0, 2, 2, 34, WOOD);
      m.roof(0, 0, 32, 43, 30, 10);
      break;
    }
    case "statue": {
      m.box(0, 0, 0, 28, 24, 5, CUT);
      m.box(0, 0, 5, 20, 17, 9, STONE);
      m.box(0, 0, 14, 24, 21, 3, CUT);
      for (const x of [-4, 4]) m.box(x, 0, 17, 5, 6, 16, CUT);
      m.drum(0, 0, 31, 9, 17, STONE, 5, 12);
      m.drum(0, 0, 48, 5, 8, STONE, 6);
      m.box(13, 0, 22, 1, 2, 43, IRON);
      m.box(13, 0, 42, 9, 2, 1, IRON);
      break;
    }
    case "beacon": {
      m.drum(0, 0, 0, 14, 6, CUT, 8);
      m.drum(0, 0, 6, 9, 35, STONE, 8, 7);
      m.drum(0, 0, 41, 13, 3, IRON, 8);
      for (const x of [-7, 7]) m.box(x, 0, 44, 1, 1, 12, IRON);
      m.cap(0, 0, 56, 15, 8, SLATE, 8);
      m.drum(0, 0, 45, 5, 9, "#c39b60", 8);
      break;
    }
    case "fort-wall": {
      m.box(0, 0, 0, 66, 22, 4, CUT);
      m.box(0, 0, 4, 62, 15, 24, STONE);
      for (let x = -27; x < 30; x += 12) m.box(x, 0, 28, 8, 18, 7, CUT);
      m.banner(-20, 0, 39, team);
      break;
    }
    case "fort-lance":
    case "fort-flame":
    case "fort-mortar":
    case "fort-ward": {
      m.box(0, 0, 0, 56, 44, 4, CUT);
      m.drum(0, 0, 4, 23, 23, STONE, 6, 21);
      m.drum(0, 0, 27, 27, 4, CUT, 6);
      m.door(0, 20, 5, 10, 16);
      if (kind === "fort-lance") {
        m.box(0, 0, 31, 7, 8, 14, WOOD);
        m.box(0, 0, 44, 51, 3, 3, IRON);
        m.box(5, 0, 44, 3, 39, 3, WOOD);
        m.box(0, 15, 43, 1, 27, 1, "#d8cdb5");
      } else if (kind === "fort-mortar") {
        m.drum(0, 0, 31, 12, 6, IRON, 8);
        m.drum(0, 0, 37, 10, 12, IRON, 8, 7);
        m.drum(0, 0, 49, 6, 1, "#242c31", 8);
        for (const x of [-21, 21]) m.box(x, 0, 31, 5, 28, 10, CUT);
      } else if (kind === "fort-flame") {
        m.drum(0, 0, 31, 15, 9, "#946d44", 8);
        m.cap(0, 0, 40, 10, 17, "#d19d5c", 6);
        for (const x of [-22, 22]) m.box(x, 0, 31, 3, 4, 17, IRON);
      } else {
        for (const x of [-16, 16]) m.box(x, 0, 31, 4, 4, 19, CUT);
        m.cap(0, 0, 50, 24, 12, SLATE, 6);
        m.drum(0, 0, 32, 10, 3, "#7ca1a4", 8);
      }
      m.banner(-28, 10, 40, team);
      break;
    }
    case "townHall": {
      m.box(0, 3, 0, 58, 45, 2.5, CUT);
      m.box(-21, -5, 2, 17, 26, 17, STONE);
      m.roof(-21, -5, 19, 22, 31, 11);
      m.drum(3, -5, 2, 21, 25, STONE);
      m.drum(3, -5, 25, 22, 2, WOOD);
      m.cap(3, -5, 27, 26, 18);
      m.drum(3, -5, 44, 4, 5, BRASS, 6);
      m.cap(3, -5, 49, 6, 7);
      m.door(3, 15, 3, 10, 16);
      for (const x of [-9, 15]) m.box(x, 23, 2, 2, 2, 16, WOOD);
      m.roof(3, 20, 18, 29, 16, 6);
      m.banner(-24, 18, 33, team);
      break;
    }
    case "barracks": {
      m.box(0, 0, 0, 55, 43, 2, CUT);
      m.box(0, -12, 2, 49, 16, 19, STONE);
      m.roof(0, -12, 21, 54, 21, 9);
      for (const x of [-23, 23]) {
        m.box(x, 13, 2, 11, 14, 24, CUT);
        m.box(x, 13, 26, 14, 17, 2, STONE);
        for (const a of [-4, 4]) for (const d of [-5, 5]) m.box(x + a, 13 + d, 28, 3.5, 4, 4, STONE);
      }
      m.box(0, 18, 2, 36, 3, 12, STONE);
      m.door(0, 19.6, 2, 12, 12);
      m.box(0, 18, 15, 36, 4, 2, WOOD);
      m.banner(-15, 20, 29, team);
      break;
    }
    case "archeryRange": {
      m.box(0, 0, 0, 54, 42, 1.5, "#968465");
      for (const x of [-24, 24]) for (const y of [-17, 2]) m.box(x, y, 0, 1.8, 1.8, 21, WOOD);
      m.roof(0, -8, 22, 56, 25, 8, "#a49776");
      for (const x of [-16, 0, 16]) {
        m.box(x, 14, 0, 1.3, 2, 13, WOOD);
        const ring = (r, z, color) => m.face(Array.from({ length: 10 }, (_, i) => [x + Math.cos(i * Math.PI / 5) * r, 15 + z, 13 + Math.sin(i * Math.PI / 5) * r]), color, [0, 1, 0], 0);
        ring(6, 0, "#c3af76");
        ring(3.8, 0.1, "#6d6853");
        ring(1.7, 0.2, team);
      }
      m.box(-25, 4, 0, 4, 10, 9, WOOD);
      break;
    }
    case "stables": {
      m.box(0, -8, 0, 54, 23, 2, CUT);
      m.box(0, -17, 2, 51, 3, 18, STONE);
      for (const x of [-25, -9, 9, 25]) m.box(x, 2, 2, 2.3, 3, 18, WOOD);
      m.box(0, 2, 18, 53, 3, 2.5, WOOD);
      m.roof(0, -8, 21, 60, 29, 10, "#737465");
      for (const x of [-16, 0, 16]) m.box(x, -4, 3, 11, 7, 7, "#494b3d");
      m.fence(0, 24, 54);
      m.box(-26, 13, 0, 1.5, 20, 6, WOOD);
      m.box(20, 14, 0, 9, 9, 7, "#b6a273");
      m.banner(-24, 4, 31, team);
      break;
    }
    case "farm": {
      m.drum(-12, -7, 0, 14, 29, STONE, 6, 9);
      m.cap(-12, -7, 29, 14, 12, "#8f7c58", 6);
      m.door(-12, 3, 0, 6, 11);
      for (let i = 0; i < 4; i++) {
        const a = Math.PI / 4 + i * Math.PI / 2, ux = Math.cos(a), uz = Math.sin(a), cx = -12, cz = 26;
        m.face([[cx + ux * 3, 6, cz + uz * 3], [cx + ux * 21, 6, cz + uz * 21], [cx + ux * 21 - uz * 4, 6, cz + uz * 21 + ux * 4], [cx + ux * 5 - uz * 2, 6, cz + uz * 5 + ux * 2]], "#b4a180", [0, 1, 0]);
      }
      m.box(14, 12, 0, 25, 28, 1, "#817354");
      for (let row = 0; row < 4; row++) m.box(14, 2 + row * 6, 1, 24, 2, 3, "#baaa79");
      m.fence(15, 28, 27);
      break;
    }
    case "workshop": {
      m.box(-8, -5, 0, 33, 32, 3, CUT);
      m.box(-8, -9, 3, 30, 20, 17, STONE);
      m.roof(-8, -9, 21, 36, 28, 12);
      for (const x2 of [-23, 8]) m.box(x2, 15, 0, 2, 2, 14, WOOD);
      m.roof(-8, 10, 14, 36, 19, 4, "#8d8064");
      m.box(-7, 12, 2, 21, 8, 6, WOOD);
      const x = 21, y = 3, z = 14;
      for (let i = 0; i < 12; i++) {
        const a = i * Math.PI / 6, q = (i + 1) * Math.PI / 6;
        m.face([[x, y + Math.cos(a) * 14, z + Math.sin(a) * 14], [x, y + Math.cos(q) * 14, z + Math.sin(q) * 14], [x, y + Math.cos(q) * 10, z + Math.sin(q) * 10], [x, y + Math.cos(a) * 10, z + Math.sin(a) * 10]], WOOD, [1, 0, 0]);
        if (i % 2 === 0) m.face([[x, y, z], [x, y + Math.cos(a) * 13, z + Math.sin(a) * 13], [x, y + Math.cos(a + 0.12) * 13, z + Math.sin(a + 0.12) * 13]], BRASS, [1, 0, 0]);
      }
      m.box(12, 0, 0, 6, 8, 15, CUT);
      break;
    }
    case "defenseTower": {
      m.drum(0, 0, 0, 14, 21, CUT, 6, 11);
      for (const x of [-9, 9]) for (const y of [-9, 9]) m.box(x, y, 20, 2, 2, 23, WOOD);
      m.box(0, 0, 29, 29, 29, 3, WOOD);
      for (const x of [-13, 13]) m.box(x, 0, 32, 1.5, 28, 5, WOOD);
      m.box(0, 13, 32, 27, 1.5, 5, WOOD);
      m.cap(0, 0, 43, 22, 12, SLATE, 4);
      m.banner(-12, 13, 34, team);
      break;
    }
    case "sanctum": {
      m.drum(0, 0, 0, 28, 3, CUT);
      m.drum(0, 0, 3, 21, 24, STONE);
      m.drum(0, 0, 27, 24, 3, BRASS);
      m.drum(0, 0, 30, 21, 10, SLATE, 10, 13);
      m.cap(0, 0, 40, 13, 8);
      for (const [x, y] of [[-21, -8], [15, -17], [14, 18]]) {
        m.drum(x, y, 0, 5, 33, CUT, 4, 3);
        m.cap(x, y, 33, 4, 7, BRASS, 4);
      }
      m.door(-4, 20, 3, 8, 17);
      m.drum(0, 0, 48, 2, 5, BRASS, 6);
      break;
    }
    case "moonWell": {
      m.drum(0, 0, 0, 29, 3, CUT, 12);
      m.drum(0, 0, 3, 24, 4, STONE, 12);
      m.drum(0, 0, 7, 20, 0.2, "#709c97", 12);
      for (let i = 0; i < 5; i++) {
        const a = Math.PI + i * Math.PI / 5, x = Math.cos(a) * 24, y = Math.sin(a) * 24;
        m.drum(x, y, 0, 3.5, 22 + Math.sin(i * Math.PI / 4) * 12, CUT, 4, 2.5);
        m.cap(x, y, 22 + Math.sin(i * Math.PI / 4) * 12, 4, 5, SLATE, 4);
      }
      m.box(0, 25, 0, 14, 10, 2, CUT);
      break;
    }
    case "shipyard": {
      m.box(0, -26, 0, 66, 17, 5, STONE);
      for (const x of [-26, 26]) {
        for (let i = 0; i < 10; i++) m.box(x, -16 + i * 5, 3, 13, 4.7, 2.5, WOOD);
        for (const y of [-16, 4, 25]) {
          m.drum(x, y, -5, 2.7, 9, WOOD, 8);
          m.drum(x, y, 4, 3.1, 1, IRON, 8);
        }
        m.box(x, 31, 3, 14, 3, 3, CUT);
      }
      m.box(-11, -27, 5, 35, 16, 20, STONE);
      m.roof(-11, -27, 25, 40, 22, 12, "#647b77");
      for (const x of [-28, 6]) m.box(x, -17, 5, 2, 2, 22, WOOD);
      m.door(-13, -18.8, 5, 8, 15);
      m.box(1, -18.7, 14, 5, 0.5, 6, "#26312b");
      m.box(17, -23, 5, 13, 15, 3, WOOD);
      m.box(17, -23, 8, 10, 10, 4, WOOD);
      for (const x of [-21, 21]) m.box(x, 4, 5, 3, 3, 32, WOOD);
      m.box(0, 4, 35, 48, 4, 4, WOOD);
      m.drum(4, 4, 28, 2.5, 6, BRASS, 8);
      m.box(4, 4, 13, 0.6, 0.6, 15, IRON);
      m.box(4, 4, 11, 4, 2, 2, IRON);
      m.box(0, 0, 5, 5, 32, 2, WOOD);
      for (let i = 0; i < 6; i++) {
        const y = -12 + i * 5, w = 5 + Math.sin(i * Math.PI / 5) * 6;
        m.face([[-w, y, 14], [-w * 0.6, y, 7], [w * 0.6, y, 7], [w, y, 14], [w - 1.5, y, 14], [w * 0.45, y, 8.5], [-w * 0.45, y, 8.5], [-w + 1.5, y, 14]], "#a18c67", [0, 1, 0]);
      }
      m.drum(24, -16, 5, 3.8, 7, WOOD, 8);
      m.drum(24, -16, 7, 4, 0.8, IRON, 8);
      m.box(-27, -8, 5, 6, 7, 6, WOOD);
      m.banner(-23, -22, 37, team);
      break;
    }
    case "emberForge": {
      m.drum(0, 0, 0, 29, 4, BASALT, 8);
      m.drum(0, 0, 4, 23, 20, BASALT, 8, 18);
      m.cap(0, 0, 24, 22, 10, COPPER, 8);
      for (const [x, y, h] of [[-14, -9, 45], [2, -13, 53], [17, -6, 39]]) {
        m.drum(x, y, 10, 4, h - 10, BASALT, 6, 3);
        m.drum(x, y, h, 5, 2, IRON, 6);
      }
      m.door(0, 21, 4, 12, 12);
      m.face([[-4, 21.1, 5], [4, 21.1, 5], [3, 21.1, 12], [-3, 21.1, 12]], "#cf9054", [0, 1, 0], 0);
      for (const x of [-18, 18]) m.box(x, 18, 0, 5, 7, 18, IRON);
      break;
    }
    case "cinderSpire": {
      m.drum(0, 0, 0, 23, 5, BASALT, 6);
      m.drum(0, 0, 5, 15, 34, BASALT, 6, 8);
      m.drum(0, 0, 39, 16, 4, IRON, 6);
      for (let i = 0; i < 3; i++) {
        const a = i * Math.PI * 2 / 3;
        m.drum(Math.cos(a) * 11, Math.sin(a) * 11, 36, 3, 22, COPPER, 4, 1);
      }
      m.drum(0, 0, 43, 4, 8, "#bc8754", 6, 7);
      m.cap(0, 0, 51, 7, 10, "#d2aa72", 6);
      break;
    }
    case "ashenHall": {
      m.box(0, 0, 0, 57, 43, 4, BASALT);
      m.box(0, -6, 4, 40, 27, 24, BASALT);
      m.roof(0, -6, 28, 46, 32, 13, COPPER);
      for (const x of [-23, 23]) {
        m.drum(x, 9, 0, 10, 34, BASALT, 4, 7);
        m.cap(x, 9, 34, 10, 10, IRON, 4);
      }
      m.box(0, 18, 3, 34, 5, 21, BASALT);
      m.door(0, 21, 3, 13, 18);
      m.box(0, 18, 25, 36, 9, 3, COPPER);
      m.banner(-18, 22, 37, team);
      break;
    }
    case "emberShrine": {
      m.drum(0, 0, 0, 28, 3, BASALT, 6);
      m.drum(0, 0, 3, 19, 7, COPPER, 6, 23);
      m.drum(0, 0, 10, 19, 1, "#513f32", 8);
      m.cap(0, 0, 11, 8, 17, "#cc9154", 5);
      for (const [x, y, h] of [[-22, -7, 31], [11, -21, 39], [18, 18, 23]]) {
        m.drum(x, y, 0, 5, h, BASALT, 4, 3);
        m.cap(x, y, h, 4, 7, COPPER, 4);
      }
      break;
    }
  }
  return m;
}
export function buildingGeometry(kind, team = "#ff00ff") {
  return build(kind, team).faces;
}
export function paintBuildingModel(b, kind, team) {
  const m = build(kind, team);
  m.faces = m.faces.filter((f) => f.normal[0] * 0.57 + f.normal[1] * 0.82 + f.normal[2] * 0.8 > -0.01);
  b.save();
  b.lineJoin = "round";
  const feet = m.faces.flatMap((f) => f.p.filter((p) => p[2] <= 3).map(([x, y]) => project([x, y, 0])));
  const hull = groundHull(feet);
  if (hull.length > 2) {
    polygon(b, hull.map(([x, y], i) => [x * 1.14 + (noise(i) - 0.5) * 2, 19 + (y - 19) * 1.2]), "#a59c7424", "transparent", 0);
    polygon(b, hull.map(([x, y]) => [x * 1.035, 19 + (y - 19) * 1.045]), "#59624b30", "transparent", 0);
  }
  b.beginPath();
  for (const f of m.faces) {
    const p = f.p.map(([x, y, z]) => project([x + z * 0.45, y + z * 0.3, 0]));
    p.forEach(([x, y], i) => i ? b.lineTo(x, y) : b.moveTo(x, y));
    b.closePath();
  }
  b.fillStyle = "#56686b20";
  b.fill();
  m.faces.sort((a, z) => {
    const gap = depth(a) - depth(z);
    return Math.abs(gap) > 1e-3 ? gap : height(a) - height(z);
  });
  for (const f of m.faces) {
    const p = f.p.map(project);
    const light = 0.66 + Math.max(0, -f.normal[0] * 0.35 + f.normal[1] * 0.45 + f.normal[2] * 0.82) * 0.39;
    const fill = tint(f.color, light);
    polygon(b, p, fill, darker(f.color, 0.18), 0.38);
    if (light > 1 && (f.color === IRON || f.color === SLATE || f.color === CUT)) {
      let edge = 0;
      for (let i = 1; i < p.length; i++) if (p[i][1] + p[(i + 1) % p.length][1] < p[edge][1] + p[(edge + 1) % p.length][1]) edge = i;
      line(b, [p[edge], p[(edge + 1) % p.length]], f.color === IRON ? "#eee3c4b0" : "#e5d7b369", 0.7);
    }
    if (f.normal[2] === 0) {
      const foot = f.p.filter((p2) => p2[2] === 0);
      if (foot.length === 2) line(b, foot.map(project), "#69705b99", 0.75);
    }
    if (f.grain) {
      b.save();
      b.clip();
      const xs = p.map((q) => q[0]), ys = p.map((q) => q[1]);
      const minX = Math.min(...xs), minY = Math.min(...ys), w = Math.max(...xs) - minX, h = Math.max(...ys) - minY;
      for (let i = 0; i < Math.min(50, w * h / 13); i++) {
        const x = minX + noise(i + f.p[0][0] * 13) * w, y = minY + noise(i * 3.7 + f.p[0][1] * 17) * h;
        line(b, [[x, y], [x + 1 + noise(i + 7) * 2, y - 0.35]], i % 3 ? "#fff4d91a" : "#5862530b", 0.55);
      }
      b.restore();
    }
  }
  b.restore();
}
function depth(f) {
  return f.p.reduce((sum, [x, y]) => sum + x * 0.6 + y * 0.8, 0) / f.p.length;
}
function height(f) {
  return f.p.reduce((sum, p) => sum + p[2], 0) / f.p.length;
}
function noise(x) {
  const v = Math.sin(x * 12.9898 + 78.233) * 43758.5453;
  return v - Math.floor(v);
}
function groundHull(points) {
  const sorted = points.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const half = (ps) => {
    const h = [];
    for (const p of ps) {
      while (h.length >= 2 && cross(h[h.length - 2], h[h.length - 1], p) <= 0) h.pop();
      h.push(p);
    }
    return h.slice(0, -1);
  };
  return [...half(sorted), ...half([...sorted].reverse())];
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJ1aWxkaW5nLW1vZGVscy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogU21hbGwgYXV0aG9yZWQgM0QgY29uc3RydWN0aW9ucywgb3J0aG9ncmFwaGljYWxseSBwcm9qZWN0ZWQgaW50byB0aGUgQ2FudmFzXG4gKiBhdGxhcy4gU2hhcmVkIGNhbWVyYSwgbWF0ZXJpYWwgbGlnaHRpbmcgYW5kIGdyb3VuZC1wbGFuZSBzaGFkb3cgcHJvamVjdGlvbi5cbiAqIEdlb21ldHJ5IGlzIGNhY2hlZCBhcyBhIHNwcml0ZSBieSBhdGxhcy1hcnQ7IG5vIG1lc2ggd29yayBpbiBzdGVhZHkgZnJhbWVzLiAqL1xuaW1wb3J0IHR5cGUgeyBCdWlsZGluZ0tpbmQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdHlwZXMnO1xuaW1wb3J0IHsgdHlwZSBCcnVzaCwgcG9seWdvbiwgbGluZSwgZGFya2VyIH0gZnJvbSAnLi9raXQnO1xudHlwZSBWID0gW251bWJlcixudW1iZXIsbnVtYmVyXTtcbnR5cGUgRmFjZSA9IHsgcDpWW107IGNvbG9yOnN0cmluZzsgbm9ybWFsOlY7IGdyYWluOm51bWJlciB9O1xuY29uc3QgU1RPTkU9JyNkZmQzYjcnLCBDVVQ9JyNiOGI1YTAnLCBXT09EPScjOGI3MDU0JywgU0xBVEU9JyM3MTkyOGYnLCBJUk9OPScjODY5NDhmJztcbmNvbnN0IHByb2plY3Q9KFt4LHksel06Vik6W251bWJlcixudW1iZXJdPT5beCouODIteSouNTcseCouMjgreSouNC16KzE5XTtcbmZ1bmN0aW9uIHRpbnQoaGV4OnN0cmluZyxsaWdodDpudW1iZXIpe1xuICBjb25zdCBuPXBhcnNlSW50KGhleC5zbGljZSgxKSwxNik7XG4gIHJldHVybiBgcmdiKCR7WzE2LDgsMF0ubWFwKChzLGkpPT5NYXRoLm1heCgwLE1hdGgubWluKDI1NSxNYXRoLnJvdW5kKCgobj4+cykmMjU1KSpsaWdodCsobGlnaHQ8LjkgPyBbMCw0LDldW2ldISA6IFs4LDUsMF1baV0hKSkpKSkuam9pbignLCcpfSlgO1xufVxuY2xhc3MgQ29uc3RydWN0aW9uIHtcbiAgZmFjZXM6RmFjZVtdPVtdO1xuICBmYWNlKHA6VltdLGNvbG9yOnN0cmluZyxub3JtYWw6VixncmFpbj0xKXt0aGlzLmZhY2VzLnB1c2goe3AsY29sb3Isbm9ybWFsLGdyYWlufSk7fVxuICBib3goeDpudW1iZXIseTpudW1iZXIsejpudW1iZXIsdzpudW1iZXIsZDpudW1iZXIsaDpudW1iZXIsY29sb3I6c3RyaW5nLGdyYWluPTEpe1xuICAgIGNvbnN0IGE9eC13LzIsYWE9eCt3LzIsYmI9eStkLzIscT15LWQvMix0b3A9eitoO1xuICAgIHRoaXMuZmFjZShbW2EsYmIsel0sW2FhLGJiLHpdLFthYSxiYix0b3BdLFthLGJiLHRvcF1dLGNvbG9yLFswLDEsMF0sZ3JhaW4pO1xuICAgIHRoaXMuZmFjZShbW2FhLHEsel0sW2FhLGJiLHpdLFthYSxiYix0b3BdLFthYSxxLHRvcF1dLGNvbG9yLFsxLDAsMF0sZ3JhaW4pO1xuICAgIHRoaXMuZmFjZShbW2EscSx0b3BdLFthYSxxLHRvcF0sW2FhLGJiLHRvcF0sW2EsYmIsdG9wXV0sY29sb3IsWzAsMCwxXSxncmFpbik7XG4gICAgdGhpcy5mYWNlKFtbYSxxLHpdLFthLHEsdG9wXSxbYWEscSx0b3BdLFthYSxxLHpdXSxjb2xvcixbMCwtMSwwXSxncmFpbik7XG4gICAgdGhpcy5mYWNlKFtbYSxxLHpdLFthLGJiLHpdLFthLGJiLHRvcF0sW2EscSx0b3BdXSxjb2xvcixbLTEsMCwwXSxncmFpbik7XG4gICAgdGhpcy5mYWNlKFtbYSxxLHpdLFthYSxxLHpdLFthYSxiYix6XSxbYSxiYix6XV0sY29sb3IsWzAsMCwtMV0sMCk7XG4gIH1cbiAgcm9vZih4Om51bWJlcix5Om51bWJlcix6Om51bWJlcix3Om51bWJlcixkOm51bWJlcixoOm51bWJlcixjb2xvcj1TTEFURSl7XG4gICAgY29uc3QgYT14LXcvMixhYT14K3cvMixxPXktZC8yLGJiPXkrZC8yO1xuICAgIHRoaXMuZmFjZShbW2EscSx6XSxbYWEscSx6XSxbYWEseSx6K2hdLFthLHkseitoXV0sY29sb3IsWzAsLS43NSwuNjZdKTtcbiAgICB0aGlzLmZhY2UoW1thLHkseitoXSxbYWEseSx6K2hdLFthYSxiYix6XSxbYSxiYix6XV0sY29sb3IsWzAsLjc1LC42Nl0pO1xuICAgIHRoaXMuZmFjZShbW2FhLHEsel0sW2FhLGJiLHpdLFthYSx5LHoraF1dLFNUT05FLFsxLDAsMF0pO1xuICAgIHRoaXMuZmFjZShbW2EscSx6XSxbYSx5LHoraF0sW2EsYmIsel1dLFNUT05FLFstMSwwLDBdKTtcbiAgICB0aGlzLmZhY2UoW1thLHEsel0sW2EsYmIsel0sW2FhLGJiLHpdLFthYSxxLHpdXSxjb2xvcixbMCwwLC0xXSk7XG4gICAgLy8gU2xhdGUgY291cnNlcyBmb2xsb3cgdGhlIGFjdHVhbCByb29mIHBsYW5lLCBub3Qgc2NyZWVuLXNwYWNlIHN0cmlwZXMuXG4gICAgZm9yKGxldCByb3c9MTtyb3c8NTtyb3crKyl7XG4gICAgICBjb25zdCB0PXJvdy81LHl5PXkrKGQvMikqdCx6ej16K2gqKDEtdCkrLjE4O1xuICAgICAgdGhpcy5mYWNlKFtbYSx5eSx6el0sW2FhLHl5LHp6XSxbYWEseXkrLjM1LHp6LS4xNV0sW2EseXkrLjM1LHp6LS4xNV1dLCcjOWE5YzhiJyxbMCwuNzUsLjY2XSwwKTtcbiAgICAgIGZvcihsZXQgaz0wO2s8NTtrKyspe1xuICAgICAgICBjb25zdCB4eD1hKyhrKyhyb3clMikqLjUpKncvNTtcbiAgICAgICAgdGhpcy5mYWNlKFtbeHgseXksenorLjAzXSxbeHgrLjM1LHl5LHp6Ky4wM10sW3h4Ky4zNSx5eStkLzEwLHp6LWgvNV0sW3h4LHl5K2QvMTAsenotaC81XV0sJyMzOTQ5NGInLFswLC43NSwuNjZdLDApO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmJveCh4LHkseitoLS41LHcrMSwxLjIsMS4yLCcjYTZhMThiJywwKTtcbiAgfVxuICAvLyBUYXBlcmVkIHBvbHlnb25hbCBtYXNzZXMgZ2l2ZSBlYWNoIGJ1aWxkaW5nIGEgbGVnaWJsZSByb29mL2JvZHkgc2lsaG91ZXR0ZS5cbiAgZHJ1bSh4Om51bWJlcix5Om51bWJlcix6Om51bWJlcixyOm51bWJlcixoOm51bWJlcixjb2xvcjpzdHJpbmcsbj04LHRvcD1yKXtcbiAgICBmb3IobGV0IGk9MDtpPG47aSsrKXtcbiAgICAgIGNvbnN0IGE9aSpNYXRoLlBJKjIvbixxPShpKzEpKk1hdGguUEkqMi9uLG1pZD0oYStxKS8yO1xuXG4gICAgICB0aGlzLmZhY2UoW1t4K01hdGguY29zKGEpKnIseStNYXRoLnNpbihhKSpyLHpdLFt4K01hdGguY29zKHEpKnIseStNYXRoLnNpbihxKSpyLHpdLFt4K01hdGguY29zKHEpKnRvcCx5K01hdGguc2luKHEpKnRvcCx6K2hdLFt4K01hdGguY29zKGEpKnRvcCx5K01hdGguc2luKGEpKnRvcCx6K2hdXSxjb2xvcixbTWF0aC5jb3MobWlkKSxNYXRoLnNpbihtaWQpLDBdKTtcbiAgICB9XG4gICAgdGhpcy5mYWNlKEFycmF5LmZyb20oe2xlbmd0aDpufSwoXyxpKT0+W3grTWF0aC5jb3MoLWkqMipNYXRoLlBJL24pKnIseStNYXRoLnNpbigtaSoyKk1hdGguUEkvbikqcix6XSBhcyBWKSxjb2xvcixbMCwwLC0xXSk7XG4gICAgdGhpcy5mYWNlKEFycmF5LmZyb20oe2xlbmd0aDpufSwoXyxpKT0+W3grTWF0aC5jb3MoaSoyKk1hdGguUEkvbikqdG9wLHkrTWF0aC5zaW4oaSoyKk1hdGguUEkvbikqdG9wLHoraF0gYXMgViksY29sb3IsWzAsMCwxXSk7XG4gIH1cbiAgY2FwKHg6bnVtYmVyLHk6bnVtYmVyLHo6bnVtYmVyLHI6bnVtYmVyLGg6bnVtYmVyLGNvbG9yPVNMQVRFLG49OCl7XG4gICAgZm9yKGxldCBpPTA7aTxuO2krKyl7XG4gICAgICBjb25zdCBhPWkqTWF0aC5QSSoyL24scT0oaSsxKSpNYXRoLlBJKjIvbixtaWQ9KGErcSkvMjtcbiAgICAgIHRoaXMuZmFjZShbW3grTWF0aC5jb3MoYSkqcix5K01hdGguc2luKGEpKnIsel0sW3grTWF0aC5jb3MocSkqcix5K01hdGguc2luKHEpKnIsel0sW3gseSx6K2hdXSxjb2xvcixbTWF0aC5jb3MobWlkKSouNjUsTWF0aC5zaW4obWlkKSouNjUsLjc2XSk7XG4gICAgfVxuICB9XG4gIGJhbm5lcih4Om51bWJlcix5Om51bWJlcix6Om51bWJlcix0ZWFtOnN0cmluZyl7XG4gICAgdGhpcy5ib3goeCx5LDAsLjksLjkseisyLFdPT0QsMCk7XG4gICAgdGhpcy5mYWNlKFtbeCsuNSx5LHpdLFt4KzkseSx6LTFdLFt4KzcseSx6LThdLFt4Ky41LHksei03XV0sdGVhbSxbMCwxLDBdLDApO1xuICB9XG4gIGRvb3IoeDpudW1iZXIseTpudW1iZXIsejpudW1iZXIsdzpudW1iZXIsaDpudW1iZXIpe1xuICAgIGNvbnN0IHA6VltdPVtbeC13LzIseSx6XSxbeCt3LzIseSx6XSxbeCt3LzIseSx6K2gqLjddLFt4K3cqLjMseSx6K2gqLjkyXSxbeCx5LHoraF0sW3gtdyouMyx5LHoraCouOTJdLFt4LXcvMix5LHoraCouN11dO1xuICAgIHRoaXMuZmFjZShwLCcjMzAzODMxJyxbMCwxLDBdLDApO1xuICAgIHRoaXMuYm94KHgtdy8yLTEseSwgeiwxLjQsMS40LGgqLjcyLENVVCk7dGhpcy5ib3goeCt3LzIrMSx5LHosMS40LDEuNCxoKi43MixDVVQpO1xuICAgIHRoaXMuYm94KHgseSsyLDAsdys1LDUsMS41LENVVCk7XG4gIH1cbiAgZmVuY2UoeDpudW1iZXIseTpudW1iZXIsdzpudW1iZXIpe1xuICAgIGZvcihsZXQgaT0wO2k8PTQ7aSsrKXRoaXMuYm94KHgtdy8yK2kqdy80LHksMCwxLjMsMS4zLDgsV09PRCk7XG4gICAgZm9yKGNvbnN0IHogb2YgWzMsNl0pdGhpcy5ib3goeCx5LHosdywxLDEsV09PRCk7XG4gIH1cbn1cbmNvbnN0IEJBU0FMVD0nIzg5OGI3YycsIENPUFBFUj0nI2IzODI1ZCcsIEJSQVNTPScjZDJiNzc5JztcbmV4cG9ydCB0eXBlIHsgU2l0ZU1vZGVsS2luZCB9IGZyb20gJy4vbW9kZWwtbWFuaWZlc3QnO1xuaW1wb3J0IHR5cGUgeyBTaXRlTW9kZWxLaW5kIH0gZnJvbSAnLi9tb2RlbC1tYW5pZmVzdCc7XG5mdW5jdGlvbiBidWlsZChraW5kOkJ1aWxkaW5nS2luZCB8IFNpdGVNb2RlbEtpbmQsdGVhbTpzdHJpbmcpOkNvbnN0cnVjdGlvbntcbiAgY29uc3QgbT1uZXcgQ29uc3RydWN0aW9uKCk7XG4gIHN3aXRjaChraW5kKXtcbiAgICBjYXNlICdjaXRhZGVsJzoge1xuICAgICAgbS5ib3goMCwwLDAsNjcsNTYsMyxDVVQpO1xuICAgICAgbS5ib3goMCwwLDMsNTUsNDQsMTEsQkFTQUxUKTtcbiAgICAgIG0uYm94KDAsLTYsMTQsMzAsMjcsMjUsU1RPTkUpO20ucm9vZigwLC02LDM5LDM2LDMyLDExLFNMQVRFKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMjQsMjRdKWZvcihjb25zdCB5IG9mIFstMTksMTldKXtcbiAgICAgICAgbS5kcnVtKHgseSwzLDksMzAsU1RPTkUsOCk7bS5kcnVtKHgseSwzMSwxMCw0LENVVCw4KTttLmNhcCh4LHksMzUsMTIsMTIsU0xBVEUpO1xuICAgICAgICBtLmRvb3IoeCx5KzksMTQsMyw3KTtcbiAgICAgIH1cbiAgICAgIG0uYm94KDAsMjIsMywyNSw3LDIyLFNUT05FKTttLmRvb3IoMCwyNiwzLDExLDE4KTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMTAsMCwxMF0pbS5ib3goeCwyMiwyNSw1LDgsNCxDVVQpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy05LDldKW0uZG9vcih4LDgsMjQsMyw4KTtcbiAgICAgIG0uYmFubmVyKC0xOSwtOCw1Myx0ZWFtKTttLmJhbm5lcigxOCwtOCw1MSx0ZWFtKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlICdzaG9wJzoge1xuICAgICAgbS5ib3goMCwwLDAsNjIsNDQsMixDVVQpO1xuICAgICAgbS5ib3goLTUsLTgsMiwzNywyNSwyMyxTVE9ORSk7IG0ucm9vZigtNSwtOCwyNSw0NCwzMiwxNCxTTEFURSk7XG4gICAgICBtLmJveCgwLDE0LDIsNDIsOSwxMixXT09EKTsgbS5ib3goMCwxNCwxNCw0NiwxMiwyLCcjYTM4ZTZhJyk7XG4gICAgICBmb3IoY29uc3QgeCBvZiBbLTI0LDI0XSkgbS5ib3goeCwyMiwwLDEuOCwxLjgsMjcsV09PRCk7XG4gICAgICBtLmZhY2UoW1stMjUsMCwzMF0sWzI1LDAsMzBdLFsyNSwyNCwyNV0sWy0yNSwyNCwyNV1dLCcjYmNhZDhjJyxbMCwuMjUsMV0pO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0xOCwtNiw2LDE4XSkgbS5mYWNlKFtbeC0zLDAsMzAuMV0sW3grMywwLDMwLjFdLFt4KzMsMjQsMjUuMV0sW3gtMywyNCwyNS4xXV0sJyM3NzYzNTUnLFswLC4yNSwxXSk7XG4gICAgICBtLmJveCgyNywtNywwLDIsMiwzNCxXT09EKTsgbS5ib3goMzQsLTcsMzEsMTYsMS41LDEuNSxXT09EKTtcbiAgICAgIG0uYm94KDM4LC03LDIwLDExLDIsOSwnI2EzOGM1OScpO20uZHJ1bSgzOCwtNS41LDIzLDIsMyxCUkFTUyw4KTtcbiAgICAgIGZvcihjb25zdCBbeCxjb2xvcl0gb2YgW1stMTQsJyM4ZTdjNTUnXSxbLTMsJyM1MzY5NjUnXSxbOSwnI2EzOTc3NyddXSBhcyBjb25zdCkgbS5kcnVtKHgsMTMsMTYsMy41LDUsY29sb3IsOCwyKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFsyMywzMV0pIG0uYm94KHgsLTE0LDAsNyw4LDgsV09PRCk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSAnY2FtcCc6IHtcbiAgICAgIG0uYm94KDAsMCwwLDU4LDQ0LDEsJyM4MDc2NWUnKTtcbiAgICAgIC8vIENhbnZhcyByaWRnZSB0ZW50LCBvcGVuIGRhcmsgZW50cmFuY2UgYW5kIGd1eSByb3BlcyBncm91bmRlZCBhdCBzdGFrZXMuXG4gICAgICBtLmZhY2UoW1stMjQsLTE3LDJdLFstMjQsMTcsMl0sWy0yNCwwLDM0XV0sJyNiNGE3OGEnLFstMSwwLC41XSk7XG4gICAgICBtLmZhY2UoW1stMjQsMCwzNF0sWzIyLDAsMzRdLFsyNywyMCwxXSxbLTI4LDIwLDFdXSwnIzlhOGE2ZicsWzAsLjc1LC42NV0pO1xuICAgICAgbS5mYWNlKFtbLTI0LC0xNywyXSxbMjIsLTE3LDJdLFsyMiwwLDM0XSxbLTI0LDAsMzRdXSwnI2MzYjQ5NCcsWzAsLS43NSwuNjVdKTtcbiAgICAgIG0uZmFjZShbWzIyLC0xNywyXSxbMjcsMjAsMV0sWzIyLDAsMzRdXSwnIzc1Njk0ZicsWzEsMCwuM10pO1xuICAgICAgbS5mYWNlKFtbMjUsNCwyXSxbMjUsMTQsMl0sWzIzLDQsMjNdXSwnIzM1MzczMScsWzEsMCwwXSk7XG4gICAgICBmb3IoY29uc3QgeCBvZiBbLTI4LDI4XSkgZm9yKGNvbnN0IHkgb2YgWy0yNSwyNV0pIHttLmJveCh4LHksMCwxLDEsNCxXT09EKTttLmZhY2UoW1t4LHksM10sW3grLjYseSwzXSxbeCouOCx5Ki42NSwyNl1dLCcjOGY4MTY0JyxbMCwxLDBdLDApO31cbiAgICAgIG0uYmFubmVyKC0zMiwxNSwzOCwnIzhiNmU0OScpOyBtLmJveCgzMCwtMTIsMCw4LDEwLDgsV09PRCk7XG4gICAgICBtLmJveCgtMjIsMjgsMCwxNSw0LDMsV09PRCk7bS5ib3goLTIyLDI4LDMsOSwxLDEyLElST04pO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ3dlbGwnOiB7IG0uZHJ1bSgwLDAsMCwxNiwxMixDVVQsMTApOyBtLmRydW0oMCwwLDEyLDEzLDEsJyMzZTQ4NDgnLDEwKTsgZm9yKGNvbnN0IHggb2YgWy0xNywxN10pbS5ib3goeCwwLDAsMiwyLDM0LFdPT0QpO20ucm9vZigwLDAsMzIsNDMsMzAsMTApO2JyZWFrOyB9XG4gICAgY2FzZSAnc3RhdHVlJzogeyBtLmJveCgwLDAsMCwyOCwyNCw1LENVVCk7bS5ib3goMCwwLDUsMjAsMTcsOSxTVE9ORSk7bS5ib3goMCwwLDE0LDI0LDIxLDMsQ1VUKTtmb3IoY29uc3QgeCBvZiBbLTQsNF0pbS5ib3goeCwwLDE3LDUsNiwxNixDVVQpO20uZHJ1bSgwLDAsMzEsOSwxNyxTVE9ORSw1LDEyKTttLmRydW0oMCwwLDQ4LDUsOCxTVE9ORSw2KTttLmJveCgxMywwLDIyLDEsMiw0MyxJUk9OKTttLmJveCgxMywwLDQyLDksMiwxLElST04pO2JyZWFrOyB9XG4gICAgY2FzZSAnYmVhY29uJzoge20uZHJ1bSgwLDAsMCwxNCw2LENVVCw4KTttLmRydW0oMCwwLDYsOSwzNSxTVE9ORSw4LDcpO20uZHJ1bSgwLDAsNDEsMTMsMyxJUk9OLDgpO2Zvcihjb25zdCB4IG9mIFstNyw3XSltLmJveCh4LDAsNDQsMSwxLDEyLElST04pO20uY2FwKDAsMCw1NiwxNSw4LFNMQVRFLDgpO20uZHJ1bSgwLDAsNDUsNSw5LCcjYzM5YjYwJyw4KTticmVhazt9XG5cbiAgICBjYXNlICdmb3J0LXdhbGwnOiB7XG4gICAgICBtLmJveCgwLDAsMCw2NiwyMiw0LENVVCk7bS5ib3goMCwwLDQsNjIsMTUsMjQsU1RPTkUpO1xuICAgICAgZm9yKGxldCB4PS0yNzt4PDMwO3grPTEyKW0uYm94KHgsMCwyOCw4LDE4LDcsQ1VUKTttLmJhbm5lcigtMjAsMCwzOSx0ZWFtKTticmVhaztcbiAgICB9XG4gICAgY2FzZSAnZm9ydC1sYW5jZSc6IGNhc2UgJ2ZvcnQtZmxhbWUnOiBjYXNlICdmb3J0LW1vcnRhcic6IGNhc2UgJ2ZvcnQtd2FyZCc6IHtcbiAgICAgIG0uYm94KDAsMCwwLDU2LDQ0LDQsQ1VUKTttLmRydW0oMCwwLDQsMjMsMjMsU1RPTkUsNiwyMSk7XG4gICAgICBtLmRydW0oMCwwLDI3LDI3LDQsQ1VULDYpO20uZG9vcigwLDIwLDUsMTAsMTYpO1xuICAgICAgaWYoa2luZD09PSdmb3J0LWxhbmNlJyl7XG4gICAgICAgIG0uYm94KDAsMCwzMSw3LDgsMTQsV09PRCk7bS5ib3goMCwwLDQ0LDUxLDMsMyxJUk9OKTttLmJveCg1LDAsNDQsMywzOSwzLFdPT0QpO20uYm94KDAsMTUsNDMsMSwyNywxLCcjZDhjZGI1Jyk7XG4gICAgICB9ZWxzZSBpZihraW5kPT09J2ZvcnQtbW9ydGFyJyl7XG4gICAgICAgIG0uZHJ1bSgwLDAsMzEsMTIsNixJUk9OLDgpO20uZHJ1bSgwLDAsMzcsMTAsMTIsSVJPTiw4LDcpO20uZHJ1bSgwLDAsNDksNiwxLCcjMjQyYzMxJyw4KTtcbiAgICAgICAgZm9yKGNvbnN0IHggb2YgWy0yMSwyMV0pbS5ib3goeCwwLDMxLDUsMjgsMTAsQ1VUKTtcbiAgICAgIH1lbHNlIGlmKGtpbmQ9PT0nZm9ydC1mbGFtZScpe1xuICAgICAgICBtLmRydW0oMCwwLDMxLDE1LDksJyM5NDZkNDQnLDgpO20uY2FwKDAsMCw0MCwxMCwxNywnI2QxOWQ1YycsNik7XG4gICAgICAgIGZvcihjb25zdCB4IG9mIFstMjIsMjJdKW0uYm94KHgsMCwzMSwzLDQsMTcsSVJPTik7XG4gICAgICB9ZWxzZXtcbiAgICAgICAgZm9yKGNvbnN0IHggb2YgWy0xNiwxNl0pbS5ib3goeCwwLDMxLDQsNCwxOSxDVVQpO1xuICAgICAgICBtLmNhcCgwLDAsNTAsMjQsMTIsU0xBVEUsNik7bS5kcnVtKDAsMCwzMiwxMCwzLCcjN2NhMWE0Jyw4KTtcbiAgICAgIH1cbiAgICAgIG0uYmFubmVyKC0yOCwxMCw0MCx0ZWFtKTticmVhaztcbiAgICB9XG4gICAgY2FzZSAndG93bkhhbGwnOiB7XG4gICAgICAvLyBDb3VuY2lsIGNvdXJ0eWFyZDogb2N0YWdvbmFsIGNpdmljIGhhbGwsIGxvdyBzaWRlIHdpbmcgYW5kIG9wZW4gcG9yY2guXG4gICAgICBtLmJveCgwLDMsMCw1OCw0NSwyLjUsQ1VUKTtcbiAgICAgIG0uYm94KC0yMSwtNSwyLDE3LDI2LDE3LFNUT05FKTttLnJvb2YoLTIxLC01LDE5LDIyLDMxLDExKTtcbiAgICAgIG0uZHJ1bSgzLC01LDIsMjEsMjUsU1RPTkUpO20uZHJ1bSgzLC01LDI1LDIyLDIsV09PRCk7XG4gICAgICBtLmNhcCgzLC01LDI3LDI2LDE4KTttLmRydW0oMywtNSw0NCw0LDUsQlJBU1MsNik7bS5jYXAoMywtNSw0OSw2LDcpO1xuICAgICAgbS5kb29yKDMsMTUsMywxMCwxNik7XG4gICAgICBmb3IoY29uc3QgeCBvZiBbLTksMTVdKW0uYm94KHgsMjMsMiwyLDIsMTYsV09PRCk7XG4gICAgICBtLnJvb2YoMywyMCwxOCwyOSwxNiw2KTttLmJhbm5lcigtMjQsMTgsMzMsdGVhbSk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSAnYmFycmFja3MnOiB7XG4gICAgICAvLyBGb3J0aWZpZWQgZHJpbGwgeWFyZCwgYnJvYWQgZ2F0ZSBhbmQgY3JlbmVsbGF0ZWQgY29ybmVyIGtlZXBzLlxuICAgICAgbS5ib3goMCwwLDAsNTUsNDMsMixDVVQpO20uYm94KDAsLTEyLDIsNDksMTYsMTksU1RPTkUpO1xuICAgICAgbS5yb29mKDAsLTEyLDIxLDU0LDIxLDkpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0yMywyM10pe1xuICAgICAgICBtLmJveCh4LDEzLDIsMTEsMTQsMjQsQ1VUKTttLmJveCh4LDEzLDI2LDE0LDE3LDIsU1RPTkUpO1xuICAgICAgICBmb3IoY29uc3QgYSBvZiBbLTQsNF0pZm9yKGNvbnN0IGQgb2YgWy01LDVdKW0uYm94KHgrYSwxMytkLDI4LDMuNSw0LDQsU1RPTkUpO1xuICAgICAgfVxuICAgICAgbS5ib3goMCwxOCwyLDM2LDMsMTIsU1RPTkUpO20uZG9vcigwLDE5LjYsMiwxMiwxMik7XG4gICAgICBtLmJveCgwLDE4LDE1LDM2LDQsMixXT09EKTttLmJhbm5lcigtMTUsMjAsMjksdGVhbSk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSAnYXJjaGVyeVJhbmdlJzoge1xuICAgICAgLy8gT3BlbiBjYW52YXMgc2hvb3RpbmcgY2Fub3B5IHdpdGggdGhyZWUgZGlzdGluY3Qgcm91bmQgc3RyYXcgdGFyZ2V0cy5cbiAgICAgIG0uYm94KDAsMCwwLDU0LDQyLDEuNSwnIzk2ODQ2NScpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0yNCwyNF0pZm9yKGNvbnN0IHkgb2YgWy0xNywyXSltLmJveCh4LHksMCwxLjgsMS44LDIxLFdPT0QpO1xuICAgICAgbS5yb29mKDAsLTgsMjIsNTYsMjUsOCwnI2E0OTc3NicpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0xNiwwLDE2XSl7XG4gICAgICAgIG0uYm94KHgsMTQsMCwxLjMsMiwxMyxXT09EKTtcbiAgICAgICAgY29uc3QgcmluZz0ocjpudW1iZXIsejpudW1iZXIsY29sb3I6c3RyaW5nKT0+bS5mYWNlKEFycmF5LmZyb20oe2xlbmd0aDoxMH0sKF8saSk9Plt4K01hdGguY29zKGkqTWF0aC5QSS81KSpyLDE1K3osMTMrTWF0aC5zaW4oaSpNYXRoLlBJLzUpKnJdIGFzIFYpLGNvbG9yLFswLDEsMF0sMCk7XG4gICAgICAgIHJpbmcoNiwwLCcjYzNhZjc2Jyk7cmluZygzLjgsLjEsJyM2ZDY4NTMnKTtyaW5nKDEuNywuMix0ZWFtKTtcbiAgICAgIH1cbiAgICAgIG0uYm94KC0yNSw0LDAsNCwxMCw5LFdPT0QpO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdzdGFibGVzJzoge1xuICAgICAgLy8gTG9uZyBsb3cgc3RhYmxlIHdpdGggb3BlbiBzdGFsbHMsIGEgaGF5IGxvZnQgYW5kIGZlbmNlZCB0dXJub3V0LlxuICAgICAgbS5ib3goMCwtOCwwLDU0LDIzLDIsQ1VUKTttLmJveCgwLC0xNywyLDUxLDMsMTgsU1RPTkUpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0yNSwtOSw5LDI1XSltLmJveCh4LDIsMiwyLjMsMywxOCxXT09EKTtcbiAgICAgIG0uYm94KDAsMiwxOCw1MywzLDIuNSxXT09EKTttLnJvb2YoMCwtOCwyMSw2MCwyOSwxMCwnIzczNzQ2NScpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0xNiwwLDE2XSltLmJveCh4LC00LDMsMTEsNyw3LCcjNDk0YjNkJyk7XG4gICAgICBtLmZlbmNlKDAsMjQsNTQpO20uYm94KC0yNiwxMywwLDEuNSwyMCw2LFdPT0QpO1xuICAgICAgbS5ib3goMjAsMTQsMCw5LDksNywnI2I2YTI3MycpO20uYmFubmVyKC0yNCw0LDMxLHRlYW0pO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdmYXJtJzoge1xuICAgICAgLy8gQSBjb21wYWN0IHdpbmRtaWxsL2dyYW5hcnksIG5vdCBhIGhvdXNlIHdpdGggYSBsYXduLlxuICAgICAgbS5kcnVtKC0xMiwtNywwLDE0LDI5LFNUT05FLDYsOSk7bS5jYXAoLTEyLC03LDI5LDE0LDEyLCcjOGY3YzU4Jyw2KTtcbiAgICAgIG0uZG9vcigtMTIsMywwLDYsMTEpO1xuICAgICAgZm9yKGxldCBpPTA7aTw0O2krKyl7XG4gICAgICAgIGNvbnN0IGE9TWF0aC5QSS80K2kqTWF0aC5QSS8yLHV4PU1hdGguY29zKGEpLHV6PU1hdGguc2luKGEpLGN4PS0xMixjej0yNjtcbiAgICAgICAgbS5mYWNlKFtbY3grdXgqMyw2LGN6K3V6KjNdLFtjeCt1eCoyMSw2LGN6K3V6KjIxXSxbY3grdXgqMjEtdXoqNCw2LGN6K3V6KjIxK3V4KjRdLFtjeCt1eCo1LXV6KjIsNixjeit1eio1K3V4KjJdXSwnI2I0YTE4MCcsWzAsMSwwXSk7XG4gICAgICB9XG4gICAgICBtLmJveCgxNCwxMiwwLDI1LDI4LDEsJyM4MTczNTQnKTtcbiAgICAgIGZvcihsZXQgcm93PTA7cm93PDQ7cm93KyspbS5ib3goMTQsMityb3cqNiwxLDI0LDIsMywnI2JhYWE3OScpO1xuICAgICAgbS5mZW5jZSgxNSwyOCwyNyk7YnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ3dvcmtzaG9wJzoge1xuICAgICAgLy8gU2F3IHdvcmtzaG9wOiBleHBvc2VkIGZyYW1lLCBsZWFuLXRvIGFuZCBhIGxhcmdlIHdvcmtpbmcgd2hlZWwuXG4gICAgICBtLmJveCgtOCwtNSwwLDMzLDMyLDMsQ1VUKTttLmJveCgtOCwtOSwzLDMwLDIwLDE3LFNUT05FKTtcbiAgICAgIG0ucm9vZigtOCwtOSwyMSwzNiwyOCwxMik7XG4gICAgICBmb3IoY29uc3QgeCBvZiBbLTIzLDhdKW0uYm94KHgsMTUsMCwyLDIsMTQsV09PRCk7XG4gICAgICBtLnJvb2YoLTgsMTAsMTQsMzYsMTksNCwnIzhkODA2NCcpO20uYm94KC03LDEyLDIsMjEsOCw2LFdPT0QpO1xuICAgICAgY29uc3QgeD0yMSx5PTMsej0xNDtcbiAgICAgIGZvcihsZXQgaT0wO2k8MTI7aSsrKXtcbiAgICAgICAgY29uc3QgYT1pKk1hdGguUEkvNixxPShpKzEpKk1hdGguUEkvNjtcbiAgICAgICAgbS5mYWNlKFtbeCx5K01hdGguY29zKGEpKjE0LHorTWF0aC5zaW4oYSkqMTRdLFt4LHkrTWF0aC5jb3MocSkqMTQseitNYXRoLnNpbihxKSoxNF0sW3gseStNYXRoLmNvcyhxKSoxMCx6K01hdGguc2luKHEpKjEwXSxbeCx5K01hdGguY29zKGEpKjEwLHorTWF0aC5zaW4oYSkqMTBdXSxXT09ELFsxLDAsMF0pO1xuICAgICAgICBpZihpJTI9PT0wKW0uZmFjZShbW3gseSx6XSxbeCx5K01hdGguY29zKGEpKjEzLHorTWF0aC5zaW4oYSkqMTNdLFt4LHkrTWF0aC5jb3MoYSsuMTIpKjEzLHorTWF0aC5zaW4oYSsuMTIpKjEzXV0sQlJBU1MsWzEsMCwwXSk7XG4gICAgICB9XG4gICAgICBtLmJveCgxMiwwLDAsNiw4LDE1LENVVCk7YnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2RlZmVuc2VUb3dlcic6IHtcbiAgICAgIG0uZHJ1bSgwLDAsMCwxNCwyMSxDVVQsNiwxMSk7XG4gICAgICBmb3IoY29uc3QgeCBvZiBbLTksOV0pZm9yKGNvbnN0IHkgb2YgWy05LDldKW0uYm94KHgseSwyMCwyLDIsMjMsV09PRCk7XG4gICAgICBtLmJveCgwLDAsMjksMjksMjksMyxXT09EKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMTMsMTNdKW0uYm94KHgsMCwzMiwxLjUsMjgsNSxXT09EKTtcbiAgICAgIG0uYm94KDAsMTMsMzIsMjcsMS41LDUsV09PRCk7bS5jYXAoMCwwLDQzLDIyLDEyLFNMQVRFLDQpO1xuICAgICAgbS5iYW5uZXIoLTEyLDEzLDM0LHRlYW0pO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdzYW5jdHVtJzoge1xuICAgICAgLy8gU3RlcHBlZCBvYnNlcnZhdG9yeSB3aXRoIGEgY29wcGVyIGRvbWUgYW5kIHRocmVlIHN0b25lIGZpbnMuXG4gICAgICBtLmRydW0oMCwwLDAsMjgsMyxDVVQpO20uZHJ1bSgwLDAsMywyMSwyNCxTVE9ORSk7XG4gICAgICBtLmRydW0oMCwwLDI3LDI0LDMsQlJBU1MpO20uZHJ1bSgwLDAsMzAsMjEsMTAsU0xBVEUsMTAsMTMpO20uY2FwKDAsMCw0MCwxMyw4KTtcbiAgICAgIGZvcihjb25zdCBbeCx5XSBvZiBbWy0yMSwtOF0sWzE1LC0xN10sWzE0LDE4XV0pe20uZHJ1bSh4ISx5ISwwLDUsMzMsQ1VULDQsMyk7bS5jYXAoeCEseSEsMzMsNCw3LEJSQVNTLDQpO31cbiAgICAgIG0uZG9vcigtNCwyMCwzLDgsMTcpO20uZHJ1bSgwLDAsNDgsMiw1LEJSQVNTLDYpO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdtb29uV2VsbCc6IHtcbiAgICAgIC8vIFN1bmtlbiB3YXRlciBjb3VydCB3aXRoIGEgY3Jlc2NlbnQtc2hhcGVkIHN0b25lIHNjcmVlbi5cbiAgICAgIG0uZHJ1bSgwLDAsMCwyOSwzLENVVCwxMik7bS5kcnVtKDAsMCwzLDI0LDQsU1RPTkUsMTIpO1xuICAgICAgbS5kcnVtKDAsMCw3LDIwLC4yLCcjNzA5Yzk3JywxMik7XG4gICAgICBmb3IobGV0IGk9MDtpPDU7aSsrKXtcbiAgICAgICAgY29uc3QgYT1NYXRoLlBJK2kqTWF0aC5QSS81LHg9TWF0aC5jb3MoYSkqMjQseT1NYXRoLnNpbihhKSoyNDtcbiAgICAgICAgbS5kcnVtKHgseSwwLDMuNSwyMitNYXRoLnNpbihpKk1hdGguUEkvNCkqMTIsQ1VULDQsMi41KTtcbiAgICAgICAgbS5jYXAoeCx5LDIyK01hdGguc2luKGkqTWF0aC5QSS80KSoxMiw0LDUsU0xBVEUsNCk7XG4gICAgICB9XG4gICAgICBtLmJveCgwLDI1LDAsMTQsMTAsMixDVVQpO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdzaGlweWFyZCc6IHtcbiAgICAgIC8vIEFuIG9wZW4gd2V0IGJlcnRoIGJldHdlZW4gdHdvIHBpZXJzLCBiYWNrZWQgYnkgYSBzdG9uZSBzaGlwd3JpZ2h0J3NcbiAgICAgIC8vIHdvcmtzaG9wLiBFdmVyeSBkYXJrIGVkZ2UgaXMgbW9kZWwgZ2VvbWV0cnksIGluY2x1ZGluZyB0aGUgcGlsZXMuXG4gICAgICBtLmJveCgwLC0yNiwwLDY2LDE3LDUsU1RPTkUpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0yNiwyNl0pe1xuICAgICAgICBmb3IobGV0IGk9MDtpPDEwO2krKyltLmJveCh4LC0xNitpKjUsMywxMyw0LjcsMi41LFdPT0QpO1xuICAgICAgICBmb3IoY29uc3QgeSBvZiBbLTE2LDQsMjVdKXttLmRydW0oeCx5LC01LDIuNyw5LFdPT0QsOCk7bS5kcnVtKHgseSw0LDMuMSwxLElST04sOCk7fVxuICAgICAgICBtLmJveCh4LDMxLDMsMTQsMywzLENVVCk7XG4gICAgICB9XG4gICAgICBtLmJveCgtMTEsLTI3LDUsMzUsMTYsMjAsU1RPTkUpO1xuICAgICAgbS5yb29mKC0xMSwtMjcsMjUsNDAsMjIsMTIsJyM2NDdiNzcnKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMjgsNl0pbS5ib3goeCwtMTcsNSwyLDIsMjIsV09PRCk7XG4gICAgICBtLmRvb3IoLTEzLC0xOC44LDUsOCwxNSk7bS5ib3goMSwtMTguNywxNCw1LC41LDYsJyMyNjMxMmInKTtcbiAgICAgIG0uYm94KDE3LC0yMyw1LDEzLDE1LDMsV09PRCk7XG4gICAgICBtLmJveCgxNywtMjMsOCwxMCwxMCw0LFdPT0QpO1xuICAgICAgZm9yKGNvbnN0IHggb2YgWy0yMSwyMV0pbS5ib3goeCw0LDUsMywzLDMyLFdPT0QpO1xuICAgICAgbS5ib3goMCw0LDM1LDQ4LDQsNCxXT09EKTtcbiAgICAgIG0uZHJ1bSg0LDQsMjgsMi41LDYsQlJBU1MsOCk7bS5ib3goNCw0LDEzLC42LC42LDE1LElST04pO1xuICAgICAgbS5ib3goNCw0LDExLDQsMiwyLElST04pO1xuICAgICAgbS5ib3goMCwwLDUsNSwzMiwyLFdPT0QpO1xuICAgICAgZm9yKGxldCBpPTA7aTw2O2krKyl7XG4gICAgICAgIGNvbnN0IHk9LTEyK2kqNSx3PTUrTWF0aC5zaW4oaSpNYXRoLlBJLzUpKjY7XG4gICAgICAgIG0uZmFjZShbWy13LHksMTRdLFstdyouNix5LDddLFt3Ki42LHksN10sW3cseSwxNF0sW3ctMS41LHksMTRdLFt3Ki40NSx5LDguNV0sWy13Ki40NSx5LDguNV0sWy13KzEuNSx5LDE0XV0sJyNhMThjNjcnLFswLDEsMF0pO1xuICAgICAgfVxuICAgICAgbS5kcnVtKDI0LC0xNiw1LDMuOCw3LFdPT0QsOCk7bS5kcnVtKDI0LC0xNiw3LDQsLjgsSVJPTiw4KTtcbiAgICAgIG0uYm94KC0yNywtOCw1LDYsNyw2LFdPT0QpO20uYmFubmVyKC0yMywtMjIsMzcsdGVhbSk7YnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2VtYmVyRm9yZ2UnOiB7XG4gICAgICBtLmRydW0oMCwwLDAsMjksNCxCQVNBTFQsOCk7bS5kcnVtKDAsMCw0LDIzLDIwLEJBU0FMVCw4LDE4KTttLmNhcCgwLDAsMjQsMjIsMTAsQ09QUEVSLDgpO1xuICAgICAgZm9yKGNvbnN0IFt4LHksaF0gb2YgW1stMTQsLTksNDVdLFsyLC0xMyw1M10sWzE3LC02LDM5XV0pe1xuICAgICAgICBtLmRydW0oeCEseSEsMTAsNCxoIS0xMCxCQVNBTFQsNiwzKTttLmRydW0oeCEseSEsaCEsNSwyLElST04sNik7XG4gICAgICB9XG4gICAgICBtLmRvb3IoMCwyMSw0LDEyLDEyKTttLmZhY2UoW1stNCwyMS4xLDVdLFs0LDIxLjEsNV0sWzMsMjEuMSwxMl0sWy0zLDIxLjEsMTJdXSwnI2NmOTA1NCcsWzAsMSwwXSwwKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMTgsMThdKW0uYm94KHgsMTgsMCw1LDcsMTgsSVJPTik7YnJlYWs7XG4gICAgfVxuICAgIGNhc2UgJ2NpbmRlclNwaXJlJzoge1xuICAgICAgbS5kcnVtKDAsMCwwLDIzLDUsQkFTQUxULDYpO20uZHJ1bSgwLDAsNSwxNSwzNCxCQVNBTFQsNiw4KTtcbiAgICAgIG0uZHJ1bSgwLDAsMzksMTYsNCxJUk9OLDYpO1xuICAgICAgZm9yKGxldCBpPTA7aTwzO2krKyl7Y29uc3QgYT1pKk1hdGguUEkqMi8zO20uZHJ1bShNYXRoLmNvcyhhKSoxMSxNYXRoLnNpbihhKSoxMSwzNiwzLDIyLENPUFBFUiw0LDEpO31cbiAgICAgIG0uZHJ1bSgwLDAsNDMsNCw4LCcjYmM4NzU0Jyw2LDcpO20uY2FwKDAsMCw1MSw3LDEwLCcjZDJhYTcyJyw2KTticmVhaztcbiAgICB9XG4gICAgY2FzZSAnYXNoZW5IYWxsJzoge1xuICAgICAgbS5ib3goMCwwLDAsNTcsNDMsNCxCQVNBTFQpO20uYm94KDAsLTYsNCw0MCwyNywyNCxCQVNBTFQpO1xuICAgICAgbS5yb29mKDAsLTYsMjgsNDYsMzIsMTMsQ09QUEVSKTtcbiAgICAgIGZvcihjb25zdCB4IG9mIFstMjMsMjNdKXttLmRydW0oeCw5LDAsMTAsMzQsQkFTQUxULDQsNyk7bS5jYXAoeCw5LDM0LDEwLDEwLElST04sNCk7fVxuICAgICAgbS5ib3goMCwxOCwzLDM0LDUsMjEsQkFTQUxUKTttLmRvb3IoMCwyMSwzLDEzLDE4KTtcbiAgICAgIG0uYm94KDAsMTgsMjUsMzYsOSwzLENPUFBFUik7bS5iYW5uZXIoLTE4LDIyLDM3LHRlYW0pO2JyZWFrO1xuICAgIH1cbiAgICBjYXNlICdlbWJlclNocmluZSc6IHtcbiAgICAgIG0uZHJ1bSgwLDAsMCwyOCwzLEJBU0FMVCw2KTttLmRydW0oMCwwLDMsMTksNyxDT1BQRVIsNiwyMyk7XG4gICAgICBtLmRydW0oMCwwLDEwLDE5LDEsJyM1MTNmMzInLDgpO20uY2FwKDAsMCwxMSw4LDE3LCcjY2M5MTU0Jyw1KTtcbiAgICAgIGZvcihjb25zdCBbeCx5LGhdIG9mIFtbLTIyLC03LDMxXSxbMTEsLTIxLDM5XSxbMTgsMTgsMjNdXSl7bS5kcnVtKHghLHkhLDAsNSxoISxCQVNBTFQsNCwzKTttLmNhcCh4ISx5ISxoISw0LDcsQ09QUEVSLDQpO31cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBidWlsZGluZ0dlb21ldHJ5KGtpbmQ6QnVpbGRpbmdLaW5kIHwgU2l0ZU1vZGVsS2luZCx0ZWFtPVwiI2ZmMDBmZlwiKXtyZXR1cm4gYnVpbGQoa2luZCx0ZWFtKS5mYWNlczt9XG5cbmV4cG9ydCBmdW5jdGlvbiBwYWludEJ1aWxkaW5nTW9kZWwoYjpCcnVzaCxraW5kOkJ1aWxkaW5nS2luZCB8IFNpdGVNb2RlbEtpbmQsdGVhbTpzdHJpbmcpe1xuICBjb25zdCBtPWJ1aWxkKGtpbmQsdGVhbSk7XG4gIG0uZmFjZXM9bS5mYWNlcy5maWx0ZXIoZj0+Zi5ub3JtYWxbMF0qLjU3K2Yubm9ybWFsWzFdKi44MitmLm5vcm1hbFsyXSouOD4tLjAxKTtcbiAgYi5zYXZlKCk7Yi5saW5lSm9pbj0ncm91bmQnO1xuICAvLyBHcm91bmQgY29udGFjdCBjb21lcyBmcm9tIHRoZSBmb290cHJpbnQsIGluZGVwZW5kZW50IG9mIHRoZSBjYXN0IHNoYWRvdy5cbiAgLy8gQW4gaXJyZWd1bGFyIHNvaWwgZWRnZSBhbmQgYSB0aWdodCBkYXJrIHJpbSBhbmNob3IgbWFzb25yeSBpbnRvIHRoZSB0ZXJyYWluLlxuICBjb25zdCBmZWV0PW0uZmFjZXMuZmxhdE1hcChmPT5mLnAuZmlsdGVyKHA9PnBbMl08PTMpLm1hcCgoW3gseV0pPT5wcm9qZWN0KFt4LHksMF0pKSk7XG4gIGNvbnN0IGh1bGw9Z3JvdW5kSHVsbChmZWV0KTtcbiAgaWYoaHVsbC5sZW5ndGg+Mil7XG4gICAgcG9seWdvbihiLGh1bGwubWFwKChbeCx5XSxpKT0+W3gqMS4xNCsobm9pc2UoaSktLjUpKjIsMTkrKHktMTkpKjEuMl0pLCcjYTU5Yzc0MjQnLCd0cmFuc3BhcmVudCcsMCk7XG4gICAgcG9seWdvbihiLGh1bGwubWFwKChbeCx5XSk9Plt4KjEuMDM1LDE5Kyh5LTE5KSoxLjA0NV0pLCcjNTk2MjRiMzAnLCd0cmFuc3BhcmVudCcsMCk7XG4gIH1cbiAgLy8gVW5pb24gc2lsaG91ZXR0ZXMgaW50byBhIHNpbmdsZSBmaWxsOiBvdmVybGFwcGluZyBmYWNlcyBkbyBub3QgZGFya2VuIHNoYWRvd3MuXG4gIGIuYmVnaW5QYXRoKCk7XG4gIGZvcihjb25zdCBmIG9mIG0uZmFjZXMpe1xuICAgIGNvbnN0IHA9Zi5wLm1hcCgoW3gseSx6XSk9PnByb2plY3QoW3greiouNDUseSt6Ki4zLDBdKSk7XG4gICAgcC5mb3JFYWNoKChbeCx5XSxpKT0+aT9iLmxpbmVUbyh4LHkpOmIubW92ZVRvKHgseSkpO2IuY2xvc2VQYXRoKCk7XG4gIH1cbiAgYi5maWxsU3R5bGU9JyM1NjY4NmIyMCc7Yi5maWxsKCk7XG4gIG0uZmFjZXMuc29ydCgoYSx6KT0+e1xuICAgIGNvbnN0IGdhcD1kZXB0aChhKS1kZXB0aCh6KTtcbiAgICByZXR1cm4gTWF0aC5hYnMoZ2FwKT4uMDAxP2dhcDpoZWlnaHQoYSktaGVpZ2h0KHopO1xuICB9KTtcbiAgZm9yKGNvbnN0IGYgb2YgbS5mYWNlcyl7XG4gICAgY29uc3QgcD1mLnAubWFwKHByb2plY3QpO1xuICAgIC8vIFNvZnQgZGF5bGlnaHQ6IHRoZSBmcm9udCBmYWNlcyByZWNlaXZlIHN1biBhbmQgdGhlIHNpZGVzIHJldGFpbiBjb29sXG4gICAgLy8gYW1iaWVudCBmaWxsLiBHZW9tZXRyeSBhbmQgdGV4dHVyZSBkZW5zaXR5IGFyZSB1bmNoYW5nZWQuXG4gICAgY29uc3QgbGlnaHQ9LjY2K01hdGgubWF4KDAsLWYubm9ybWFsWzBdKi4zNStmLm5vcm1hbFsxXSouNDUrZi5ub3JtYWxbMl0qLjgyKSouMzk7XG4gICAgY29uc3QgZmlsbD10aW50KGYuY29sb3IsbGlnaHQpO1xuICAgIHBvbHlnb24oYixwLGZpbGwsZGFya2VyKGYuY29sb3IsLjE4KSwuMzgpO1xuICAgIC8vIE5hcnJvdyBoaWdobGlnaHRzIG9uIGRyZXNzZWQgZWRnZXM7IGJyb2FkIHN0b25lL3dvb2QgZmFjZXMgcmVtYWluIG1hdHRlLlxuICAgIGlmIChsaWdodCA+IDEgJiYgKGYuY29sb3IgPT09IElST04gfHwgZi5jb2xvciA9PT0gU0xBVEUgfHwgZi5jb2xvciA9PT0gQ1VUKSkge1xuICAgICAgbGV0IGVkZ2UgPSAwO1xuICAgICAgZm9yIChsZXQgaT0xO2k8cC5sZW5ndGg7aSsrKSBpZiAocFtpXSFbMV0rcFsoaSsxKSVwLmxlbmd0aF0hWzFdIDwgcFtlZGdlXSFbMV0rcFsoZWRnZSsxKSVwLmxlbmd0aF0hWzFdKSBlZGdlPWk7XG4gICAgICBsaW5lKGIsW3BbZWRnZV0hLHBbKGVkZ2UrMSklcC5sZW5ndGhdIV0sZi5jb2xvcj09PUlST04/JyNlZWUzYzRiMCc6JyNlNWQ3YjM2OScsLjcpO1xuICAgIH1cbiAgICBpZihmLm5vcm1hbFsyXT09PTApe1xuICAgICAgY29uc3QgZm9vdD1mLnAuZmlsdGVyKHA9PnBbMl09PT0wKTtcbiAgICAgIGlmKGZvb3QubGVuZ3RoPT09MilsaW5lKGIsZm9vdC5tYXAocHJvamVjdCksJyM2OTcwNWI5OScsLjc1KTtcbiAgICB9XG4gICAgaWYoZi5ncmFpbil7XG4gICAgICBiLnNhdmUoKTtiLmNsaXAoKTtcbiAgICAgIGNvbnN0IHhzPXAubWFwKHE9PnFbMF0pLHlzPXAubWFwKHE9PnFbMV0pO1xuICAgICAgY29uc3QgbWluWD1NYXRoLm1pbiguLi54cyksbWluWT1NYXRoLm1pbiguLi55cyksdz1NYXRoLm1heCguLi54cyktbWluWCxoPU1hdGgubWF4KC4uLnlzKS1taW5ZO1xuICAgICAgLy8gU3RhYmxlIGRyeS1icnVzaCBmbGVja3MgbG9ja2VkIHRvIGVhY2ggcHJvamVjdGVkIGZhY2UsIGJha2VkIG9ubHkgb25jZS5cbiAgICAgIGZvcihsZXQgaT0wO2k8TWF0aC5taW4oNTAsdypoLzEzKTtpKyspe1xuICAgICAgICBjb25zdCB4PW1pblgrbm9pc2UoaStmLnBbMF0hWzBdKjEzKSp3LHk9bWluWStub2lzZShpKjMuNytmLnBbMF0hWzFdKjE3KSpoO1xuICAgICAgICBsaW5lKGIsW1t4LHldLFt4KzErbm9pc2UoaSs3KSoyLHktLjM1XV0saSUzPycjZmZmNGQ5MWEnOicjNTg2MjUzMGInLC41NSk7XG4gICAgICB9Yi5yZXN0b3JlKCk7XG4gICAgfVxuICB9XG4gIGIucmVzdG9yZSgpO1xufVxuZnVuY3Rpb24gZGVwdGgoZjpGYWNlKXtyZXR1cm4gZi5wLnJlZHVjZSgoc3VtLFt4LHldKT0+c3VtK3gqLjYreSouOCwwKS9mLnAubGVuZ3RoO31cbmZ1bmN0aW9uIGhlaWdodChmOkZhY2Upe3JldHVybiBmLnAucmVkdWNlKChzdW0scCk9PnN1bStwWzJdLDApL2YucC5sZW5ndGg7fVxuZnVuY3Rpb24gbm9pc2UoeDpudW1iZXIpe2NvbnN0IHY9TWF0aC5zaW4oeCoxMi45ODk4Kzc4LjIzMykqNDM3NTguNTQ1MztyZXR1cm4gdi1NYXRoLmZsb29yKHYpO31cblxuLyoqIENvbnZleCBmb290cHJpbnQgb2YgbG93IGNvbnN0cnVjdGlvbiB2ZXJ0aWNlczsgbm8gcGVyLWZyYW1lIHdvcmsuICovXG5mdW5jdGlvbiBncm91bmRIdWxsKHBvaW50czpbbnVtYmVyLG51bWJlcl1bXSk6W251bWJlcixudW1iZXJdW117XG4gIGNvbnN0IHNvcnRlZD1wb2ludHMuc29ydCgoYSxiKT0+YVswXS1iWzBdfHxhWzFdLWJbMV0pO1xuICBjb25zdCBjcm9zcz0oYTpudW1iZXJbXSxiOm51bWJlcltdLGM6bnVtYmVyW10pPT4oYlswXSEtYVswXSEpKihjWzFdIS1hWzFdISktKGJbMV0hLWFbMV0hKSooY1swXSEtYVswXSEpO1xuICBjb25zdCBoYWxmPShwczpbbnVtYmVyLG51bWJlcl1bXSk9Pntjb25zdCBoOltudW1iZXIsbnVtYmVyXVtdPVtdO2Zvcihjb25zdCBwIG9mIHBzKXt3aGlsZShoLmxlbmd0aD49MiYmY3Jvc3MoaFtoLmxlbmd0aC0yXSEsaFtoLmxlbmd0aC0xXSEscCk8PTApaC5wb3AoKTtoLnB1c2gocCk7fXJldHVybiBoLnNsaWNlKDAsLTEpO307XG4gIHJldHVybiBbLi4uaGFsZihzb3J0ZWQpLC4uLmhhbGYoWy4uLnNvcnRlZF0ucmV2ZXJzZSgpKV07XG59XG4iXSwibWFwcGluZ3MiOiJBQUlBLFNBQXFCLFNBQVMsTUFBTSxjQUFjO0FBR2xELE1BQU0sUUFBTSxXQUFXLE1BQUksV0FBVyxPQUFLLFdBQVcsUUFBTSxXQUFXLE9BQUs7QUFDNUUsTUFBTSxVQUFRLENBQUMsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxNQUFzQixDQUFDLElBQUUsT0FBSSxJQUFFLE1BQUksSUFBRSxPQUFJLElBQUUsTUFBRyxJQUFFLEVBQUU7QUFDdkUsU0FBUyxLQUFLLEtBQVcsT0FBYTtBQUNwQyxRQUFNLElBQUUsU0FBUyxJQUFJLE1BQU0sQ0FBQyxHQUFFLEVBQUU7QUFDaEMsU0FBTyxPQUFPLENBQUMsSUFBRyxHQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRSxNQUFJLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxLQUFJLEtBQUssT0FBUSxLQUFHLElBQUcsT0FBSyxTQUFPLFFBQU0sTUFBSyxDQUFDLEdBQUUsR0FBRSxDQUFDLEVBQUUsQ0FBQyxJQUFLLENBQUMsR0FBRSxHQUFFLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQztBQUM5STtBQUNBLE1BQU0sYUFBYTtBQUFBLEVBQ2pCLFFBQWEsQ0FBQztBQUFBLEVBQ2QsS0FBSyxHQUFNLE9BQWEsUUFBUyxRQUFNLEdBQUU7QUFBQyxTQUFLLE1BQU0sS0FBSyxFQUFDLEdBQUUsT0FBTSxRQUFPLE1BQUssQ0FBQztBQUFBLEVBQUU7QUFBQSxFQUNsRixJQUFJLEdBQVMsR0FBUyxHQUFTLEdBQVMsR0FBUyxHQUFTLE9BQWEsUUFBTSxHQUFFO0FBQzdFLFVBQU0sSUFBRSxJQUFFLElBQUUsR0FBRSxLQUFHLElBQUUsSUFBRSxHQUFFLEtBQUcsSUFBRSxJQUFFLEdBQUUsSUFBRSxJQUFFLElBQUUsR0FBRSxNQUFJLElBQUU7QUFDOUMsU0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLENBQUMsSUFBRyxJQUFHLENBQUMsR0FBRSxDQUFDLElBQUcsSUFBRyxHQUFHLEdBQUUsQ0FBQyxHQUFFLElBQUcsR0FBRyxDQUFDLEdBQUUsT0FBTSxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsS0FBSztBQUN6RSxTQUFLLEtBQUssQ0FBQyxDQUFDLElBQUcsR0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLElBQUcsQ0FBQyxHQUFFLENBQUMsSUFBRyxJQUFHLEdBQUcsR0FBRSxDQUFDLElBQUcsR0FBRSxHQUFHLENBQUMsR0FBRSxPQUFNLENBQUMsR0FBRSxHQUFFLENBQUMsR0FBRSxLQUFLO0FBQ3pFLFNBQUssS0FBSyxDQUFDLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRSxDQUFDLElBQUcsR0FBRSxHQUFHLEdBQUUsQ0FBQyxJQUFHLElBQUcsR0FBRyxHQUFFLENBQUMsR0FBRSxJQUFHLEdBQUcsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUs7QUFDM0UsU0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRSxDQUFDLElBQUcsR0FBRSxHQUFHLEdBQUUsQ0FBQyxJQUFHLEdBQUUsQ0FBQyxDQUFDLEdBQUUsT0FBTSxDQUFDLEdBQUUsSUFBRyxDQUFDLEdBQUUsS0FBSztBQUN0RSxTQUFLLEtBQUssQ0FBQyxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLEdBQUcsR0FBRSxDQUFDLEdBQUUsR0FBRSxHQUFHLENBQUMsR0FBRSxPQUFNLENBQUMsSUFBRyxHQUFFLENBQUMsR0FBRSxLQUFLO0FBQ3RFLFNBQUssS0FBSyxDQUFDLENBQUMsR0FBRSxHQUFFLENBQUMsR0FBRSxDQUFDLElBQUcsR0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLElBQUcsQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLENBQUMsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxHQUFFLEdBQUUsRUFBRSxHQUFFLENBQUM7QUFBQSxFQUNsRTtBQUFBLEVBQ0EsS0FBSyxHQUFTLEdBQVMsR0FBUyxHQUFTLEdBQVMsR0FBUyxRQUFNLE9BQU07QUFDckUsVUFBTSxJQUFFLElBQUUsSUFBRSxHQUFFLEtBQUcsSUFBRSxJQUFFLEdBQUUsSUFBRSxJQUFFLElBQUUsR0FBRSxLQUFHLElBQUUsSUFBRTtBQUN0QyxTQUFLLEtBQUssQ0FBQyxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRyxHQUFFLElBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxHQUFFLElBQUUsQ0FBQyxDQUFDLEdBQUUsT0FBTSxDQUFDLEdBQUUsT0FBSyxJQUFHLENBQUM7QUFDcEUsU0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLElBQUcsQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLENBQUMsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxHQUFFLE1BQUksSUFBRyxDQUFDO0FBQ3JFLFNBQUssS0FBSyxDQUFDLENBQUMsSUFBRyxHQUFFLENBQUMsR0FBRSxDQUFDLElBQUcsSUFBRyxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsSUFBRSxDQUFDLENBQUMsR0FBRSxPQUFNLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUN2RCxTQUFLLEtBQUssQ0FBQyxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxDQUFDLEdBQUUsT0FBTSxDQUFDLElBQUcsR0FBRSxDQUFDLENBQUM7QUFDckQsU0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxJQUFHLENBQUMsR0FBRSxDQUFDLElBQUcsSUFBRyxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsQ0FBQyxDQUFDLEdBQUUsT0FBTSxDQUFDLEdBQUUsR0FBRSxFQUFFLENBQUM7QUFFOUQsYUFBUSxNQUFJLEdBQUUsTUFBSSxHQUFFLE9BQU07QUFDeEIsWUFBTSxJQUFFLE1BQUksR0FBRSxLQUFHLElBQUcsSUFBRSxJQUFHLEdBQUUsS0FBRyxJQUFFLEtBQUcsSUFBRSxLQUFHO0FBQ3hDLFdBQUssS0FBSyxDQUFDLENBQUMsR0FBRSxJQUFHLEVBQUUsR0FBRSxDQUFDLElBQUcsSUFBRyxFQUFFLEdBQUUsQ0FBQyxJQUFHLEtBQUcsTUFBSSxLQUFHLElBQUcsR0FBRSxDQUFDLEdBQUUsS0FBRyxNQUFJLEtBQUcsSUFBRyxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsTUFBSSxJQUFHLEdBQUUsQ0FBQztBQUM3RixlQUFRLElBQUUsR0FBRSxJQUFFLEdBQUUsS0FBSTtBQUNsQixjQUFNLEtBQUcsS0FBRyxJQUFHLE1BQUksSUFBRyxPQUFJLElBQUU7QUFDNUIsYUFBSyxLQUFLLENBQUMsQ0FBQyxJQUFHLElBQUcsS0FBRyxJQUFHLEdBQUUsQ0FBQyxLQUFHLE1BQUksSUFBRyxLQUFHLElBQUcsR0FBRSxDQUFDLEtBQUcsTUFBSSxLQUFHLElBQUUsSUFBRyxLQUFHLElBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRyxLQUFHLElBQUUsSUFBRyxLQUFHLElBQUUsQ0FBQyxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsTUFBSSxJQUFHLEdBQUUsQ0FBQztBQUFBLE1BQ25IO0FBQUEsSUFDRjtBQUNBLFNBQUssSUFBSSxHQUFFLEdBQUUsSUFBRSxJQUFFLEtBQUcsSUFBRSxHQUFFLEtBQUksS0FBSSxXQUFVLENBQUM7QUFBQSxFQUM3QztBQUFBO0FBQUEsRUFFQSxLQUFLLEdBQVMsR0FBUyxHQUFTLEdBQVMsR0FBUyxPQUFhLElBQUUsR0FBRSxNQUFJLEdBQUU7QUFDdkUsYUFBUSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUk7QUFDbEIsWUFBTSxJQUFFLElBQUUsS0FBSyxLQUFHLElBQUUsR0FBRSxLQUFHLElBQUUsS0FBRyxLQUFLLEtBQUcsSUFBRSxHQUFFLE9BQUssSUFBRSxLQUFHO0FBRXBELFdBQUssS0FBSyxDQUFDLENBQUMsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEtBQUksSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEtBQUksSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsS0FBSSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsS0FBSSxJQUFFLENBQUMsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxLQUFLLElBQUksR0FBRyxHQUFFLEtBQUssSUFBSSxHQUFHLEdBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDL007QUFDQSxTQUFLLEtBQUssTUFBTSxLQUFLLEVBQUMsUUFBTyxFQUFDLEdBQUUsQ0FBQyxHQUFFLE1BQUksQ0FBQyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRSxLQUFLLEtBQUcsQ0FBQyxJQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLElBQUUsS0FBSyxLQUFHLENBQUMsSUFBRSxHQUFFLENBQUMsQ0FBTSxHQUFFLE9BQU0sQ0FBQyxHQUFFLEdBQUUsRUFBRSxDQUFDO0FBQ3pILFNBQUssS0FBSyxNQUFNLEtBQUssRUFBQyxRQUFPLEVBQUMsR0FBRSxDQUFDLEdBQUUsTUFBSSxDQUFDLElBQUUsS0FBSyxJQUFJLElBQUUsSUFBRSxLQUFLLEtBQUcsQ0FBQyxJQUFFLEtBQUksSUFBRSxLQUFLLElBQUksSUFBRSxJQUFFLEtBQUssS0FBRyxDQUFDLElBQUUsS0FBSSxJQUFFLENBQUMsQ0FBTSxHQUFFLE9BQU0sQ0FBQyxHQUFFLEdBQUUsQ0FBQyxDQUFDO0FBQUEsRUFDOUg7QUFBQSxFQUNBLElBQUksR0FBUyxHQUFTLEdBQVMsR0FBUyxHQUFTLFFBQU0sT0FBTSxJQUFFLEdBQUU7QUFDL0QsYUFBUSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUk7QUFDbEIsWUFBTSxJQUFFLElBQUUsS0FBSyxLQUFHLElBQUUsR0FBRSxLQUFHLElBQUUsS0FBRyxLQUFLLEtBQUcsSUFBRSxHQUFFLE9BQUssSUFBRSxLQUFHO0FBQ3BELFdBQUssS0FBSyxDQUFDLENBQUMsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxJQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxHQUFFLElBQUUsQ0FBQyxDQUFDLEdBQUUsT0FBTSxDQUFDLEtBQUssSUFBSSxHQUFHLElBQUUsTUFBSSxLQUFLLElBQUksR0FBRyxJQUFFLE1BQUksSUFBRyxDQUFDO0FBQUEsSUFDL0k7QUFBQSxFQUNGO0FBQUEsRUFDQSxPQUFPLEdBQVMsR0FBUyxHQUFTLE1BQVk7QUFDNUMsU0FBSyxJQUFJLEdBQUUsR0FBRSxHQUFFLEtBQUcsS0FBRyxJQUFFLEdBQUUsTUFBSyxDQUFDO0FBQy9CLFNBQUssS0FBSyxDQUFDLENBQUMsSUFBRSxLQUFHLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFLEdBQUUsR0FBRSxJQUFFLENBQUMsR0FBRSxDQUFDLElBQUUsS0FBRyxHQUFFLElBQUUsQ0FBQyxDQUFDLEdBQUUsTUFBSyxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQztBQUFBLEVBQzVFO0FBQUEsRUFDQSxLQUFLLEdBQVMsR0FBUyxHQUFTLEdBQVMsR0FBUztBQUNoRCxVQUFNLElBQU0sQ0FBQyxDQUFDLElBQUUsSUFBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxJQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFLElBQUUsR0FBRSxHQUFFLElBQUUsSUFBRSxHQUFFLEdBQUUsQ0FBQyxJQUFFLElBQUUsS0FBRyxHQUFFLElBQUUsSUFBRSxJQUFHLEdBQUUsQ0FBQyxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFLElBQUUsS0FBRyxHQUFFLElBQUUsSUFBRSxJQUFHLEdBQUUsQ0FBQyxJQUFFLElBQUUsR0FBRSxHQUFFLElBQUUsSUFBRSxHQUFFLENBQUM7QUFDdEgsU0FBSyxLQUFLLEdBQUUsV0FBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQztBQUMvQixTQUFLLElBQUksSUFBRSxJQUFFLElBQUUsR0FBRSxHQUFHLEdBQUUsS0FBSSxLQUFJLElBQUUsTUFBSSxHQUFHO0FBQUUsU0FBSyxJQUFJLElBQUUsSUFBRSxJQUFFLEdBQUUsR0FBRSxHQUFFLEtBQUksS0FBSSxJQUFFLE1BQUksR0FBRztBQUMvRSxTQUFLLElBQUksR0FBRSxJQUFFLEdBQUUsR0FBRSxJQUFFLEdBQUUsR0FBRSxLQUFJLEdBQUc7QUFBQSxFQUNoQztBQUFBLEVBQ0EsTUFBTSxHQUFTLEdBQVMsR0FBUztBQUMvQixhQUFRLElBQUUsR0FBRSxLQUFHLEdBQUUsSUFBSSxNQUFLLElBQUksSUFBRSxJQUFFLElBQUUsSUFBRSxJQUFFLEdBQUUsR0FBRSxHQUFFLEtBQUksS0FBSSxHQUFFLElBQUk7QUFDNUQsZUFBVSxLQUFLLENBQUMsR0FBRSxDQUFDLEVBQUUsTUFBSyxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUk7QUFBQSxFQUNoRDtBQUNGO0FBQ0EsTUFBTSxTQUFPLFdBQVcsU0FBTyxXQUFXLFFBQU07QUFHaEQsU0FBUyxNQUFNLE1BQWtDLE1BQXlCO0FBQ3hFLFFBQU0sSUFBRSxJQUFJLGFBQWE7QUFDekIsVUFBTyxNQUFLO0FBQUEsSUFDVixLQUFLLFdBQVc7QUFDZCxRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsR0FBRztBQUN2QixRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsTUFBTTtBQUMzQixRQUFFLElBQUksR0FBRSxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsS0FBSztBQUFFLFFBQUUsS0FBSyxHQUFFLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxLQUFLO0FBQzNELGlCQUFVLEtBQUssQ0FBQyxLQUFJLEVBQUUsRUFBRSxZQUFVLEtBQUssQ0FBQyxLQUFJLEVBQUUsR0FBRTtBQUM5QyxVQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLE9BQU0sQ0FBQztBQUFFLFVBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsS0FBSSxDQUFDO0FBQUUsVUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxLQUFLO0FBQzdFLFVBQUUsS0FBSyxHQUFFLElBQUUsR0FBRSxJQUFHLEdBQUUsQ0FBQztBQUFBLE1BQ3JCO0FBQ0EsUUFBRSxJQUFJLEdBQUUsSUFBRyxHQUFFLElBQUcsR0FBRSxJQUFHLEtBQUs7QUFBRSxRQUFFLEtBQUssR0FBRSxJQUFHLEdBQUUsSUFBRyxFQUFFO0FBQy9DLGlCQUFVLEtBQUssQ0FBQyxLQUFJLEdBQUUsRUFBRSxFQUFFLEdBQUUsSUFBSSxHQUFFLElBQUcsSUFBRyxHQUFFLEdBQUUsR0FBRSxHQUFHO0FBQ2pELGlCQUFVLEtBQUssQ0FBQyxJQUFHLENBQUMsRUFBRSxHQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsR0FBRSxDQUFDO0FBQ3ZDLFFBQUUsT0FBTyxLQUFJLElBQUcsSUFBRyxJQUFJO0FBQUUsUUFBRSxPQUFPLElBQUcsSUFBRyxJQUFHLElBQUk7QUFDL0M7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFFBQVE7QUFDWCxRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsR0FBRztBQUN2QixRQUFFLElBQUksSUFBRyxJQUFHLEdBQUUsSUFBRyxJQUFHLElBQUcsS0FBSztBQUFHLFFBQUUsS0FBSyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxLQUFLO0FBQzdELFFBQUUsSUFBSSxHQUFFLElBQUcsR0FBRSxJQUFHLEdBQUUsSUFBRyxJQUFJO0FBQUcsUUFBRSxJQUFJLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxHQUFFLFNBQVM7QUFDM0QsaUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxFQUFHLEdBQUUsSUFBSSxHQUFFLElBQUcsR0FBRSxLQUFJLEtBQUksSUFBRyxJQUFJO0FBQ3JELFFBQUUsS0FBSyxDQUFDLENBQUMsS0FBSSxHQUFFLEVBQUUsR0FBRSxDQUFDLElBQUcsR0FBRSxFQUFFLEdBQUUsQ0FBQyxJQUFHLElBQUcsRUFBRSxHQUFFLENBQUMsS0FBSSxJQUFHLEVBQUUsQ0FBQyxHQUFFLFdBQVUsQ0FBQyxHQUFFLE1BQUksQ0FBQyxDQUFDO0FBQ3hFLGlCQUFVLEtBQUssQ0FBQyxLQUFJLElBQUcsR0FBRSxFQUFFLEVBQUcsR0FBRSxLQUFLLENBQUMsQ0FBQyxJQUFFLEdBQUUsR0FBRSxJQUFJLEdBQUUsQ0FBQyxJQUFFLEdBQUUsR0FBRSxJQUFJLEdBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRyxJQUFJLEdBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRyxJQUFJLENBQUMsR0FBRSxXQUFVLENBQUMsR0FBRSxNQUFJLENBQUMsQ0FBQztBQUNoSCxRQUFFLElBQUksSUFBRyxJQUFHLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBSTtBQUFHLFFBQUUsSUFBSSxJQUFHLElBQUcsSUFBRyxJQUFHLEtBQUksS0FBSSxJQUFJO0FBQzFELFFBQUUsSUFBSSxJQUFHLElBQUcsSUFBRyxJQUFHLEdBQUUsR0FBRSxTQUFTO0FBQUUsUUFBRSxLQUFLLElBQUcsTUFBSyxJQUFHLEdBQUUsR0FBRSxPQUFNLENBQUM7QUFDOUQsaUJBQVUsQ0FBQyxHQUFFLEtBQUssS0FBSyxDQUFDLENBQUMsS0FBSSxTQUFTLEdBQUUsQ0FBQyxJQUFHLFNBQVMsR0FBRSxDQUFDLEdBQUUsU0FBUyxDQUFDLEVBQVksR0FBRSxLQUFLLEdBQUUsSUFBRyxJQUFHLEtBQUksR0FBRSxPQUFNLEdBQUUsQ0FBQztBQUM5RyxpQkFBVSxLQUFLLENBQUMsSUFBRyxFQUFFLEVBQUcsR0FBRSxJQUFJLEdBQUUsS0FBSSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUk7QUFDaEQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFFBQVE7QUFDWCxRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsU0FBUztBQUU3QixRQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUksS0FBSSxDQUFDLEdBQUUsQ0FBQyxLQUFJLElBQUcsQ0FBQyxHQUFFLENBQUMsS0FBSSxHQUFFLEVBQUUsQ0FBQyxHQUFFLFdBQVUsQ0FBQyxJQUFHLEdBQUUsR0FBRSxDQUFDO0FBQzlELFFBQUUsS0FBSyxDQUFDLENBQUMsS0FBSSxHQUFFLEVBQUUsR0FBRSxDQUFDLElBQUcsR0FBRSxFQUFFLEdBQUUsQ0FBQyxJQUFHLElBQUcsQ0FBQyxHQUFFLENBQUMsS0FBSSxJQUFHLENBQUMsQ0FBQyxHQUFFLFdBQVUsQ0FBQyxHQUFFLE1BQUksSUFBRyxDQUFDO0FBQ3hFLFFBQUUsS0FBSyxDQUFDLENBQUMsS0FBSSxLQUFJLENBQUMsR0FBRSxDQUFDLElBQUcsS0FBSSxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsRUFBRSxHQUFFLENBQUMsS0FBSSxHQUFFLEVBQUUsQ0FBQyxHQUFFLFdBQVUsQ0FBQyxHQUFFLE9BQUssSUFBRyxDQUFDO0FBQzNFLFFBQUUsS0FBSyxDQUFDLENBQUMsSUFBRyxLQUFJLENBQUMsR0FBRSxDQUFDLElBQUcsSUFBRyxDQUFDLEdBQUUsQ0FBQyxJQUFHLEdBQUUsRUFBRSxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsR0FBRSxHQUFFLENBQUM7QUFDMUQsUUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFHLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRyxJQUFHLENBQUMsR0FBRSxDQUFDLElBQUcsR0FBRSxFQUFFLENBQUMsR0FBRSxXQUFVLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUN2RCxpQkFBVSxLQUFLLENBQUMsS0FBSSxFQUFFLEVBQUcsWUFBVSxLQUFLLENBQUMsS0FBSSxFQUFFLEdBQUc7QUFBQyxVQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBSTtBQUFFLFVBQUUsS0FBSyxDQUFDLENBQUMsR0FBRSxHQUFFLENBQUMsR0FBRSxDQUFDLElBQUUsS0FBRyxHQUFFLENBQUMsR0FBRSxDQUFDLElBQUUsS0FBRyxJQUFFLE1BQUksRUFBRSxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQztBQUFBLE1BQUU7QUFDNUksUUFBRSxPQUFPLEtBQUksSUFBRyxJQUFHLFNBQVM7QUFBRyxRQUFFLElBQUksSUFBRyxLQUFJLEdBQUUsR0FBRSxJQUFHLEdBQUUsSUFBSTtBQUN6RCxRQUFFLElBQUksS0FBSSxJQUFHLEdBQUUsSUFBRyxHQUFFLEdBQUUsSUFBSTtBQUFFLFFBQUUsSUFBSSxLQUFJLElBQUcsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQ3REO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSyxRQUFRO0FBQUUsUUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxLQUFJLEVBQUU7QUFBRyxRQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLFdBQVUsRUFBRTtBQUFHLGlCQUFVLEtBQUssQ0FBQyxLQUFJLEVBQUUsRUFBRSxHQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBSTtBQUFFLFFBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsRUFBRTtBQUFFO0FBQUEsSUFBTztBQUFBLElBQzdKLEtBQUssVUFBVTtBQUFFLFFBQUUsSUFBSSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxHQUFHO0FBQUUsUUFBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLEtBQUs7QUFBRSxRQUFFLElBQUksR0FBRSxHQUFFLElBQUcsSUFBRyxJQUFHLEdBQUUsR0FBRztBQUFFLGlCQUFVLEtBQUssQ0FBQyxJQUFHLENBQUMsRUFBRSxHQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLElBQUcsR0FBRztBQUFFLFFBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxHQUFFLElBQUcsT0FBTSxHQUFFLEVBQUU7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLE9BQU0sQ0FBQztBQUFFLFFBQUUsSUFBSSxJQUFHLEdBQUUsSUFBRyxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQUUsUUFBRSxJQUFJLElBQUcsR0FBRSxJQUFHLEdBQUUsR0FBRSxHQUFFLElBQUk7QUFBRTtBQUFBLElBQU87QUFBQSxJQUNwUSxLQUFLLFVBQVU7QUFBQyxRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFFLEtBQUksQ0FBQztBQUFFLFFBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUcsT0FBTSxHQUFFLENBQUM7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLE1BQUssQ0FBQztBQUFFLGlCQUFVLEtBQUssQ0FBQyxJQUFHLENBQUMsRUFBRSxHQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLElBQUcsSUFBSTtBQUFFLFFBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsT0FBTSxDQUFDO0FBQUUsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLEdBQUUsR0FBRSxXQUFVLENBQUM7QUFBRTtBQUFBLElBQU07QUFBQSxJQUVqTixLQUFLLGFBQWE7QUFDaEIsUUFBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLEdBQUc7QUFBRSxRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsS0FBSztBQUNuRCxlQUFRLElBQUUsS0FBSSxJQUFFLElBQUcsS0FBRyxHQUFHLEdBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxHQUFFLElBQUcsR0FBRSxHQUFHO0FBQUUsUUFBRSxPQUFPLEtBQUksR0FBRSxJQUFHLElBQUk7QUFBRTtBQUFBLElBQzVFO0FBQUEsSUFDQSxLQUFLO0FBQUEsSUFBYyxLQUFLO0FBQUEsSUFBYyxLQUFLO0FBQUEsSUFBZSxLQUFLLGFBQWE7QUFDMUUsUUFBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLEdBQUc7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLE9BQU0sR0FBRSxFQUFFO0FBQ3RELFFBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsS0FBSSxDQUFDO0FBQUUsUUFBRSxLQUFLLEdBQUUsSUFBRyxHQUFFLElBQUcsRUFBRTtBQUM3QyxVQUFHLFNBQU8sY0FBYTtBQUNyQixVQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLElBQUcsSUFBSTtBQUFFLFVBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsR0FBRSxJQUFJO0FBQUUsVUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLElBQUk7QUFBRSxVQUFFLElBQUksR0FBRSxJQUFHLElBQUcsR0FBRSxJQUFHLEdBQUUsU0FBUztBQUFBLE1BQzlHLFdBQVMsU0FBTyxlQUFjO0FBQzVCLFVBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsTUFBSyxDQUFDO0FBQUUsVUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxNQUFLLEdBQUUsQ0FBQztBQUFFLFVBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxHQUFFLEdBQUUsV0FBVSxDQUFDO0FBQ3RGLG1CQUFVLEtBQUssQ0FBQyxLQUFJLEVBQUUsRUFBRSxHQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxJQUFHLElBQUcsR0FBRztBQUFBLE1BQ2xELFdBQVMsU0FBTyxjQUFhO0FBQzNCLFVBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsV0FBVSxDQUFDO0FBQUUsVUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxXQUFVLENBQUM7QUFDOUQsbUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxFQUFFLEdBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQUEsTUFDbEQsT0FBSztBQUNILG1CQUFVLEtBQUssQ0FBQyxLQUFJLEVBQUUsRUFBRSxHQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLElBQUcsR0FBRztBQUMvQyxVQUFFLElBQUksR0FBRSxHQUFFLElBQUcsSUFBRyxJQUFHLE9BQU0sQ0FBQztBQUFFLFVBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsV0FBVSxDQUFDO0FBQUEsTUFDNUQ7QUFDQSxRQUFFLE9BQU8sS0FBSSxJQUFHLElBQUcsSUFBSTtBQUFFO0FBQUEsSUFDM0I7QUFBQSxJQUNBLEtBQUssWUFBWTtBQUVmLFFBQUUsSUFBSSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsS0FBSSxHQUFHO0FBQ3pCLFFBQUUsSUFBSSxLQUFJLElBQUcsR0FBRSxJQUFHLElBQUcsSUFBRyxLQUFLO0FBQUUsUUFBRSxLQUFLLEtBQUksSUFBRyxJQUFHLElBQUcsSUFBRyxFQUFFO0FBQ3hELFFBQUUsS0FBSyxHQUFFLElBQUcsR0FBRSxJQUFHLElBQUcsS0FBSztBQUFFLFFBQUUsS0FBSyxHQUFFLElBQUcsSUFBRyxJQUFHLEdBQUUsSUFBSTtBQUNuRCxRQUFFLElBQUksR0FBRSxJQUFHLElBQUcsSUFBRyxFQUFFO0FBQUUsUUFBRSxLQUFLLEdBQUUsSUFBRyxJQUFHLEdBQUUsR0FBRSxPQUFNLENBQUM7QUFBRSxRQUFFLElBQUksR0FBRSxJQUFHLElBQUcsR0FBRSxDQUFDO0FBQ2xFLFFBQUUsS0FBSyxHQUFFLElBQUcsR0FBRSxJQUFHLEVBQUU7QUFDbkIsaUJBQVUsS0FBSyxDQUFDLElBQUcsRUFBRSxFQUFFLEdBQUUsSUFBSSxHQUFFLElBQUcsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQy9DLFFBQUUsS0FBSyxHQUFFLElBQUcsSUFBRyxJQUFHLElBQUcsQ0FBQztBQUFFLFFBQUUsT0FBTyxLQUFJLElBQUcsSUFBRyxJQUFJO0FBQy9DO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSyxZQUFZO0FBRWYsUUFBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxHQUFFLEdBQUc7QUFBRSxRQUFFLElBQUksR0FBRSxLQUFJLEdBQUUsSUFBRyxJQUFHLElBQUcsS0FBSztBQUNyRCxRQUFFLEtBQUssR0FBRSxLQUFJLElBQUcsSUFBRyxJQUFHLENBQUM7QUFDdkIsaUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxHQUFFO0FBQ3RCLFVBQUUsSUFBSSxHQUFFLElBQUcsR0FBRSxJQUFHLElBQUcsSUFBRyxHQUFHO0FBQUUsVUFBRSxJQUFJLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxHQUFFLEtBQUs7QUFDdEQsbUJBQVUsS0FBSyxDQUFDLElBQUcsQ0FBQyxFQUFFLFlBQVUsS0FBSyxDQUFDLElBQUcsQ0FBQyxFQUFFLEdBQUUsSUFBSSxJQUFFLEdBQUUsS0FBRyxHQUFFLElBQUcsS0FBSSxHQUFFLEdBQUUsS0FBSztBQUFBLE1BQzdFO0FBQ0EsUUFBRSxJQUFJLEdBQUUsSUFBRyxHQUFFLElBQUcsR0FBRSxJQUFHLEtBQUs7QUFBRSxRQUFFLEtBQUssR0FBRSxNQUFLLEdBQUUsSUFBRyxFQUFFO0FBQ2pELFFBQUUsSUFBSSxHQUFFLElBQUcsSUFBRyxJQUFHLEdBQUUsR0FBRSxJQUFJO0FBQUUsUUFBRSxPQUFPLEtBQUksSUFBRyxJQUFHLElBQUk7QUFDbEQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLGdCQUFnQjtBQUVuQixRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEtBQUksU0FBUztBQUMvQixpQkFBVSxLQUFLLENBQUMsS0FBSSxFQUFFLEVBQUUsWUFBVSxLQUFLLENBQUMsS0FBSSxDQUFDLEVBQUUsR0FBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLEtBQUksS0FBSSxJQUFHLElBQUk7QUFDMUUsUUFBRSxLQUFLLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxHQUFFLFNBQVM7QUFDaEMsaUJBQVUsS0FBSyxDQUFDLEtBQUksR0FBRSxFQUFFLEdBQUU7QUFDeEIsVUFBRSxJQUFJLEdBQUUsSUFBRyxHQUFFLEtBQUksR0FBRSxJQUFHLElBQUk7QUFDMUIsY0FBTSxPQUFLLENBQUMsR0FBUyxHQUFTLFVBQWUsRUFBRSxLQUFLLE1BQU0sS0FBSyxFQUFDLFFBQU8sR0FBRSxHQUFFLENBQUMsR0FBRSxNQUFJLENBQUMsSUFBRSxLQUFLLElBQUksSUFBRSxLQUFLLEtBQUcsQ0FBQyxJQUFFLEdBQUUsS0FBRyxHQUFFLEtBQUcsS0FBSyxJQUFJLElBQUUsS0FBSyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQU0sR0FBRSxPQUFNLENBQUMsR0FBRSxHQUFFLENBQUMsR0FBRSxDQUFDO0FBQ25LLGFBQUssR0FBRSxHQUFFLFNBQVM7QUFBRSxhQUFLLEtBQUksS0FBRyxTQUFTO0FBQUUsYUFBSyxLQUFJLEtBQUcsSUFBSTtBQUFBLE1BQzdEO0FBQ0EsUUFBRSxJQUFJLEtBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFFLElBQUk7QUFBRTtBQUFBLElBQzdCO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFFZCxRQUFFLElBQUksR0FBRSxJQUFHLEdBQUUsSUFBRyxJQUFHLEdBQUUsR0FBRztBQUFFLFFBQUUsSUFBSSxHQUFFLEtBQUksR0FBRSxJQUFHLEdBQUUsSUFBRyxLQUFLO0FBQ3JELGlCQUFVLEtBQUssQ0FBQyxLQUFJLElBQUcsR0FBRSxFQUFFLEVBQUUsR0FBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLEtBQUksR0FBRSxJQUFHLElBQUk7QUFDdEQsUUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxLQUFJLElBQUk7QUFBRSxRQUFFLEtBQUssR0FBRSxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsU0FBUztBQUM3RCxpQkFBVSxLQUFLLENBQUMsS0FBSSxHQUFFLEVBQUUsRUFBRSxHQUFFLElBQUksR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLEdBQUUsU0FBUztBQUN2RCxRQUFFLE1BQU0sR0FBRSxJQUFHLEVBQUU7QUFBRSxRQUFFLElBQUksS0FBSSxJQUFHLEdBQUUsS0FBSSxJQUFHLEdBQUUsSUFBSTtBQUM3QyxRQUFFLElBQUksSUFBRyxJQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsU0FBUztBQUFFLFFBQUUsT0FBTyxLQUFJLEdBQUUsSUFBRyxJQUFJO0FBQUU7QUFBQSxJQUN6RDtBQUFBLElBQ0EsS0FBSyxRQUFRO0FBRVgsUUFBRSxLQUFLLEtBQUksSUFBRyxHQUFFLElBQUcsSUFBRyxPQUFNLEdBQUUsQ0FBQztBQUFFLFFBQUUsSUFBSSxLQUFJLElBQUcsSUFBRyxJQUFHLElBQUcsV0FBVSxDQUFDO0FBQ2xFLFFBQUUsS0FBSyxLQUFJLEdBQUUsR0FBRSxHQUFFLEVBQUU7QUFDbkIsZUFBUSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUk7QUFDbEIsY0FBTSxJQUFFLEtBQUssS0FBRyxJQUFFLElBQUUsS0FBSyxLQUFHLEdBQUUsS0FBRyxLQUFLLElBQUksQ0FBQyxHQUFFLEtBQUcsS0FBSyxJQUFJLENBQUMsR0FBRSxLQUFHLEtBQUksS0FBRztBQUN0RSxVQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUcsS0FBRyxHQUFFLEdBQUUsS0FBRyxLQUFHLENBQUMsR0FBRSxDQUFDLEtBQUcsS0FBRyxJQUFHLEdBQUUsS0FBRyxLQUFHLEVBQUUsR0FBRSxDQUFDLEtBQUcsS0FBRyxLQUFHLEtBQUcsR0FBRSxHQUFFLEtBQUcsS0FBRyxLQUFHLEtBQUcsQ0FBQyxHQUFFLENBQUMsS0FBRyxLQUFHLElBQUUsS0FBRyxHQUFFLEdBQUUsS0FBRyxLQUFHLElBQUUsS0FBRyxDQUFDLENBQUMsR0FBRSxXQUFVLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUFBLE1BQ3BJO0FBQ0EsUUFBRSxJQUFJLElBQUcsSUFBRyxHQUFFLElBQUcsSUFBRyxHQUFFLFNBQVM7QUFDL0IsZUFBUSxNQUFJLEdBQUUsTUFBSSxHQUFFLE1BQU0sR0FBRSxJQUFJLElBQUcsSUFBRSxNQUFJLEdBQUUsR0FBRSxJQUFHLEdBQUUsR0FBRSxTQUFTO0FBQzdELFFBQUUsTUFBTSxJQUFHLElBQUcsRUFBRTtBQUFFO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUssWUFBWTtBQUVmLFFBQUUsSUFBSSxJQUFHLElBQUcsR0FBRSxJQUFHLElBQUcsR0FBRSxHQUFHO0FBQUUsUUFBRSxJQUFJLElBQUcsSUFBRyxHQUFFLElBQUcsSUFBRyxJQUFHLEtBQUs7QUFDdkQsUUFBRSxLQUFLLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxFQUFFO0FBQ3hCLGlCQUFVQSxNQUFLLENBQUMsS0FBSSxDQUFDLEVBQUUsR0FBRSxJQUFJQSxJQUFFLElBQUcsR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQy9DLFFBQUUsS0FBSyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsR0FBRSxTQUFTO0FBQUUsUUFBRSxJQUFJLElBQUcsSUFBRyxHQUFFLElBQUcsR0FBRSxHQUFFLElBQUk7QUFDNUQsWUFBTSxJQUFFLElBQUcsSUFBRSxHQUFFLElBQUU7QUFDakIsZUFBUSxJQUFFLEdBQUUsSUFBRSxJQUFHLEtBQUk7QUFDbkIsY0FBTSxJQUFFLElBQUUsS0FBSyxLQUFHLEdBQUUsS0FBRyxJQUFFLEtBQUcsS0FBSyxLQUFHO0FBQ3BDLFVBQUUsS0FBSyxDQUFDLENBQUMsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsRUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsRUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsRUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRyxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsRUFBRSxDQUFDLEdBQUUsTUFBSyxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFDN0ssWUFBRyxJQUFFLE1BQUksRUFBRSxHQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRSxJQUFHLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRSxFQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUUsS0FBSyxJQUFJLElBQUUsSUFBRyxJQUFFLElBQUcsSUFBRSxLQUFLLElBQUksSUFBRSxJQUFHLElBQUUsRUFBRSxDQUFDLEdBQUUsT0FBTSxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFBQSxNQUMvSDtBQUNBLFFBQUUsSUFBSSxJQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFHO0FBQUU7QUFBQSxJQUMzQjtBQUFBLElBQ0EsS0FBSyxnQkFBZ0I7QUFDbkIsUUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxLQUFJLEdBQUUsRUFBRTtBQUMzQixpQkFBVSxLQUFLLENBQUMsSUFBRyxDQUFDLEVBQUUsWUFBVSxLQUFLLENBQUMsSUFBRyxDQUFDLEVBQUUsR0FBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLEdBQUUsR0FBRSxJQUFHLElBQUk7QUFDcEUsUUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxHQUFFLElBQUk7QUFDekIsaUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxFQUFFLEdBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxLQUFJLElBQUcsR0FBRSxJQUFJO0FBQ2xELFFBQUUsSUFBSSxHQUFFLElBQUcsSUFBRyxJQUFHLEtBQUksR0FBRSxJQUFJO0FBQUUsUUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxPQUFNLENBQUM7QUFDdkQsUUFBRSxPQUFPLEtBQUksSUFBRyxJQUFHLElBQUk7QUFBRTtBQUFBLElBQzNCO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFFZCxRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFFLEdBQUc7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLEtBQUs7QUFDL0MsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxLQUFLO0FBQUUsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLElBQUcsSUFBRyxPQUFNLElBQUcsRUFBRTtBQUFFLFFBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxJQUFHLENBQUM7QUFDNUUsaUJBQVUsQ0FBQyxHQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSSxFQUFFLEdBQUUsQ0FBQyxJQUFHLEdBQUcsR0FBRSxDQUFDLElBQUcsRUFBRSxDQUFDLEdBQUU7QUFBQyxVQUFFLEtBQUssR0FBRyxHQUFHLEdBQUUsR0FBRSxJQUFHLEtBQUksR0FBRSxDQUFDO0FBQUUsVUFBRSxJQUFJLEdBQUcsR0FBRyxJQUFHLEdBQUUsR0FBRSxPQUFNLENBQUM7QUFBQSxNQUFFO0FBQ3pHLFFBQUUsS0FBSyxJQUFHLElBQUcsR0FBRSxHQUFFLEVBQUU7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLE9BQU0sQ0FBQztBQUFFO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLEtBQUssWUFBWTtBQUVmLFFBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxJQUFHLEdBQUUsS0FBSSxFQUFFO0FBQUUsUUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsR0FBRSxPQUFNLEVBQUU7QUFDcEQsUUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsS0FBRyxXQUFVLEVBQUU7QUFDL0IsZUFBUSxJQUFFLEdBQUUsSUFBRSxHQUFFLEtBQUk7QUFDbEIsY0FBTSxJQUFFLEtBQUssS0FBRyxJQUFFLEtBQUssS0FBRyxHQUFFLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRSxJQUFHLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRTtBQUMzRCxVQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsS0FBSSxLQUFHLEtBQUssSUFBSSxJQUFFLEtBQUssS0FBRyxDQUFDLElBQUUsSUFBRyxLQUFJLEdBQUUsR0FBRztBQUN0RCxVQUFFLElBQUksR0FBRSxHQUFFLEtBQUcsS0FBSyxJQUFJLElBQUUsS0FBSyxLQUFHLENBQUMsSUFBRSxJQUFHLEdBQUUsR0FBRSxPQUFNLENBQUM7QUFBQSxNQUNuRDtBQUNBLFFBQUUsSUFBSSxHQUFFLElBQUcsR0FBRSxJQUFHLElBQUcsR0FBRSxHQUFHO0FBQUU7QUFBQSxJQUM1QjtBQUFBLElBQ0EsS0FBSyxZQUFZO0FBR2YsUUFBRSxJQUFJLEdBQUUsS0FBSSxHQUFFLElBQUcsSUFBRyxHQUFFLEtBQUs7QUFDM0IsaUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxHQUFFO0FBQ3RCLGlCQUFRLElBQUUsR0FBRSxJQUFFLElBQUcsSUFBSSxHQUFFLElBQUksR0FBRSxNQUFJLElBQUUsR0FBRSxHQUFFLElBQUcsS0FBSSxLQUFJLElBQUk7QUFDdEQsbUJBQVUsS0FBSyxDQUFDLEtBQUksR0FBRSxFQUFFLEdBQUU7QUFBQyxZQUFFLEtBQUssR0FBRSxHQUFFLElBQUcsS0FBSSxHQUFFLE1BQUssQ0FBQztBQUFFLFlBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxLQUFJLEdBQUUsTUFBSyxDQUFDO0FBQUEsUUFBRTtBQUNsRixVQUFFLElBQUksR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLEdBQUUsR0FBRztBQUFBLE1BQ3pCO0FBQ0EsUUFBRSxJQUFJLEtBQUksS0FBSSxHQUFFLElBQUcsSUFBRyxJQUFHLEtBQUs7QUFDOUIsUUFBRSxLQUFLLEtBQUksS0FBSSxJQUFHLElBQUcsSUFBRyxJQUFHLFNBQVM7QUFDcEMsaUJBQVUsS0FBSyxDQUFDLEtBQUksQ0FBQyxFQUFFLEdBQUUsSUFBSSxHQUFFLEtBQUksR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFJO0FBQ2hELFFBQUUsS0FBSyxLQUFJLE9BQU0sR0FBRSxHQUFFLEVBQUU7QUFBRSxRQUFFLElBQUksR0FBRSxPQUFNLElBQUcsR0FBRSxLQUFHLEdBQUUsU0FBUztBQUMxRCxRQUFFLElBQUksSUFBRyxLQUFJLEdBQUUsSUFBRyxJQUFHLEdBQUUsSUFBSTtBQUMzQixRQUFFLElBQUksSUFBRyxLQUFJLEdBQUUsSUFBRyxJQUFHLEdBQUUsSUFBSTtBQUMzQixpQkFBVSxLQUFLLENBQUMsS0FBSSxFQUFFLEVBQUUsR0FBRSxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUk7QUFDL0MsUUFBRSxJQUFJLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxHQUFFLElBQUk7QUFDeEIsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLEtBQUksR0FBRSxPQUFNLENBQUM7QUFBRSxRQUFFLElBQUksR0FBRSxHQUFFLElBQUcsS0FBRyxLQUFHLElBQUcsSUFBSTtBQUN2RCxRQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxHQUFFLEdBQUUsSUFBSTtBQUN2QixRQUFFLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFHLEdBQUUsSUFBSTtBQUN2QixlQUFRLElBQUUsR0FBRSxJQUFFLEdBQUUsS0FBSTtBQUNsQixjQUFNLElBQUUsTUFBSSxJQUFFLEdBQUUsSUFBRSxJQUFFLEtBQUssSUFBSSxJQUFFLEtBQUssS0FBRyxDQUFDLElBQUU7QUFDMUMsVUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUUsR0FBRSxFQUFFLEdBQUUsQ0FBQyxDQUFDLElBQUUsS0FBRyxHQUFFLENBQUMsR0FBRSxDQUFDLElBQUUsS0FBRyxHQUFFLENBQUMsR0FBRSxDQUFDLEdBQUUsR0FBRSxFQUFFLEdBQUUsQ0FBQyxJQUFFLEtBQUksR0FBRSxFQUFFLEdBQUUsQ0FBQyxJQUFFLE1BQUksR0FBRSxHQUFHLEdBQUUsQ0FBQyxDQUFDLElBQUUsTUFBSSxHQUFFLEdBQUcsR0FBRSxDQUFDLENBQUMsSUFBRSxLQUFJLEdBQUUsRUFBRSxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFBQSxNQUM5SDtBQUNBLFFBQUUsS0FBSyxJQUFHLEtBQUksR0FBRSxLQUFJLEdBQUUsTUFBSyxDQUFDO0FBQUUsUUFBRSxLQUFLLElBQUcsS0FBSSxHQUFFLEdBQUUsS0FBRyxNQUFLLENBQUM7QUFDekQsUUFBRSxJQUFJLEtBQUksSUFBRyxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUk7QUFBRSxRQUFFLE9BQU8sS0FBSSxLQUFJLElBQUcsSUFBSTtBQUFFO0FBQUEsSUFDdkQ7QUFBQSxJQUNBLEtBQUssY0FBYztBQUNqQixRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFFLFFBQU8sQ0FBQztBQUFFLFFBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsUUFBTyxHQUFFLEVBQUU7QUFBRSxRQUFFLElBQUksR0FBRSxHQUFFLElBQUcsSUFBRyxJQUFHLFFBQU8sQ0FBQztBQUN2RixpQkFBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUksSUFBRyxFQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUksRUFBRSxHQUFFLENBQUMsSUFBRyxJQUFHLEVBQUUsQ0FBQyxHQUFFO0FBQ3ZELFVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBRyxHQUFFLElBQUcsSUFBRyxRQUFPLEdBQUUsQ0FBQztBQUFFLFVBQUUsS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFFLEdBQUUsTUFBSyxDQUFDO0FBQUEsTUFDaEU7QUFDQSxRQUFFLEtBQUssR0FBRSxJQUFHLEdBQUUsSUFBRyxFQUFFO0FBQUUsUUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFHLE1BQUssQ0FBQyxHQUFFLENBQUMsR0FBRSxNQUFLLENBQUMsR0FBRSxDQUFDLEdBQUUsTUFBSyxFQUFFLEdBQUUsQ0FBQyxJQUFHLE1BQUssRUFBRSxDQUFDLEdBQUUsV0FBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQztBQUNqRyxpQkFBVSxLQUFLLENBQUMsS0FBSSxFQUFFLEVBQUUsR0FBRSxJQUFJLEdBQUUsSUFBRyxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUk7QUFBRTtBQUFBLElBQ3BEO0FBQUEsSUFDQSxLQUFLLGVBQWU7QUFDbEIsUUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsR0FBRSxRQUFPLENBQUM7QUFBRSxRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxJQUFHLFFBQU8sR0FBRSxDQUFDO0FBQ3pELFFBQUUsS0FBSyxHQUFFLEdBQUUsSUFBRyxJQUFHLEdBQUUsTUFBSyxDQUFDO0FBQ3pCLGVBQVEsSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFJO0FBQUMsY0FBTSxJQUFFLElBQUUsS0FBSyxLQUFHLElBQUU7QUFBRSxVQUFFLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBRSxJQUFHLEtBQUssSUFBSSxDQUFDLElBQUUsSUFBRyxJQUFHLEdBQUUsSUFBRyxRQUFPLEdBQUUsQ0FBQztBQUFBLE1BQUU7QUFDcEcsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLEdBQUUsR0FBRSxXQUFVLEdBQUUsQ0FBQztBQUFFLFFBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxHQUFFLElBQUcsV0FBVSxDQUFDO0FBQUU7QUFBQSxJQUNsRTtBQUFBLElBQ0EsS0FBSyxhQUFhO0FBQ2hCLFFBQUUsSUFBSSxHQUFFLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxNQUFNO0FBQUUsUUFBRSxJQUFJLEdBQUUsSUFBRyxHQUFFLElBQUcsSUFBRyxJQUFHLE1BQU07QUFDeEQsUUFBRSxLQUFLLEdBQUUsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLE1BQU07QUFDOUIsaUJBQVUsS0FBSyxDQUFDLEtBQUksRUFBRSxHQUFFO0FBQUMsVUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLElBQUcsSUFBRyxRQUFPLEdBQUUsQ0FBQztBQUFFLFVBQUUsSUFBSSxHQUFFLEdBQUUsSUFBRyxJQUFHLElBQUcsTUFBSyxDQUFDO0FBQUEsTUFBRTtBQUNuRixRQUFFLElBQUksR0FBRSxJQUFHLEdBQUUsSUFBRyxHQUFFLElBQUcsTUFBTTtBQUFFLFFBQUUsS0FBSyxHQUFFLElBQUcsR0FBRSxJQUFHLEVBQUU7QUFDaEQsUUFBRSxJQUFJLEdBQUUsSUFBRyxJQUFHLElBQUcsR0FBRSxHQUFFLE1BQU07QUFBRSxRQUFFLE9BQU8sS0FBSSxJQUFHLElBQUcsSUFBSTtBQUFFO0FBQUEsSUFDeEQ7QUFBQSxJQUNBLEtBQUssZUFBZTtBQUNsQixRQUFFLEtBQUssR0FBRSxHQUFFLEdBQUUsSUFBRyxHQUFFLFFBQU8sQ0FBQztBQUFFLFFBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxJQUFHLEdBQUUsUUFBTyxHQUFFLEVBQUU7QUFDekQsUUFBRSxLQUFLLEdBQUUsR0FBRSxJQUFHLElBQUcsR0FBRSxXQUFVLENBQUM7QUFBRSxRQUFFLElBQUksR0FBRSxHQUFFLElBQUcsR0FBRSxJQUFHLFdBQVUsQ0FBQztBQUM3RCxpQkFBVSxDQUFDLEdBQUUsR0FBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUksSUFBRyxFQUFFLEdBQUUsQ0FBQyxJQUFHLEtBQUksRUFBRSxHQUFFLENBQUMsSUFBRyxJQUFHLEVBQUUsQ0FBQyxHQUFFO0FBQUMsVUFBRSxLQUFLLEdBQUcsR0FBRyxHQUFFLEdBQUUsR0FBRyxRQUFPLEdBQUUsQ0FBQztBQUFFLFVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFFLEdBQUUsUUFBTyxDQUFDO0FBQUEsTUFBRTtBQUN4SDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ08sZ0JBQVMsaUJBQWlCLE1BQWtDLE9BQUssV0FBVTtBQUFDLFNBQU8sTUFBTSxNQUFLLElBQUksRUFBRTtBQUFNO0FBRTFHLGdCQUFTLG1CQUFtQixHQUFRLE1BQWtDLE1BQVk7QUFDdkYsUUFBTSxJQUFFLE1BQU0sTUFBSyxJQUFJO0FBQ3ZCLElBQUUsUUFBTSxFQUFFLE1BQU0sT0FBTyxPQUFHLEVBQUUsT0FBTyxDQUFDLElBQUUsT0FBSSxFQUFFLE9BQU8sQ0FBQyxJQUFFLE9BQUksRUFBRSxPQUFPLENBQUMsSUFBRSxNQUFHLEtBQUk7QUFDN0UsSUFBRSxLQUFLO0FBQUUsSUFBRSxXQUFTO0FBR3BCLFFBQU0sT0FBSyxFQUFFLE1BQU0sUUFBUSxPQUFHLEVBQUUsRUFBRSxPQUFPLE9BQUcsRUFBRSxDQUFDLEtBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUUsQ0FBQyxNQUFJLFFBQVEsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRixRQUFNLE9BQUssV0FBVyxJQUFJO0FBQzFCLE1BQUcsS0FBSyxTQUFPLEdBQUU7QUFDZixZQUFRLEdBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBRSxNQUFJLENBQUMsSUFBRSxRQUFNLE1BQU0sQ0FBQyxJQUFFLE9BQUksR0FBRSxNQUFJLElBQUUsTUFBSSxHQUFHLENBQUMsR0FBRSxhQUFZLGVBQWMsQ0FBQztBQUNqRyxZQUFRLEdBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFFLENBQUMsTUFBSSxDQUFDLElBQUUsT0FBTSxNQUFJLElBQUUsTUFBSSxLQUFLLENBQUMsR0FBRSxhQUFZLGVBQWMsQ0FBQztBQUFBLEVBQ3BGO0FBRUEsSUFBRSxVQUFVO0FBQ1osYUFBVSxLQUFLLEVBQUUsT0FBTTtBQUNyQixVQUFNLElBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUUsR0FBRSxDQUFDLE1BQUksUUFBUSxDQUFDLElBQUUsSUFBRSxNQUFJLElBQUUsSUFBRSxLQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3RELE1BQUUsUUFBUSxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUUsTUFBSSxJQUFFLEVBQUUsT0FBTyxHQUFFLENBQUMsSUFBRSxFQUFFLE9BQU8sR0FBRSxDQUFDLENBQUM7QUFBRSxNQUFFLFVBQVU7QUFBQSxFQUNsRTtBQUNBLElBQUUsWUFBVTtBQUFZLElBQUUsS0FBSztBQUMvQixJQUFFLE1BQU0sS0FBSyxDQUFDLEdBQUUsTUFBSTtBQUNsQixVQUFNLE1BQUksTUFBTSxDQUFDLElBQUUsTUFBTSxDQUFDO0FBQzFCLFdBQU8sS0FBSyxJQUFJLEdBQUcsSUFBRSxPQUFLLE1BQUksT0FBTyxDQUFDLElBQUUsT0FBTyxDQUFDO0FBQUEsRUFDbEQsQ0FBQztBQUNELGFBQVUsS0FBSyxFQUFFLE9BQU07QUFDckIsVUFBTSxJQUFFLEVBQUUsRUFBRSxJQUFJLE9BQU87QUFHdkIsVUFBTSxRQUFNLE9BQUksS0FBSyxJQUFJLEdBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFFLE9BQUksRUFBRSxPQUFPLENBQUMsSUFBRSxPQUFJLEVBQUUsT0FBTyxDQUFDLElBQUUsSUFBRyxJQUFFO0FBQzdFLFVBQU0sT0FBSyxLQUFLLEVBQUUsT0FBTSxLQUFLO0FBQzdCLFlBQVEsR0FBRSxHQUFFLE1BQUssT0FBTyxFQUFFLE9BQU0sSUFBRyxHQUFFLElBQUc7QUFFeEMsUUFBSSxRQUFRLE1BQU0sRUFBRSxVQUFVLFFBQVEsRUFBRSxVQUFVLFNBQVMsRUFBRSxVQUFVLE1BQU07QUFDM0UsVUFBSSxPQUFPO0FBQ1gsZUFBUyxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBSyxLQUFJLEVBQUUsQ0FBQyxFQUFHLENBQUMsSUFBRSxHQUFHLElBQUUsS0FBRyxFQUFFLE1BQU0sRUFBRyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUcsQ0FBQyxJQUFFLEdBQUcsT0FBSyxLQUFHLEVBQUUsTUFBTSxFQUFHLENBQUMsRUFBRyxRQUFLO0FBQzdHLFdBQUssR0FBRSxDQUFDLEVBQUUsSUFBSSxHQUFHLEdBQUcsT0FBSyxLQUFHLEVBQUUsTUFBTSxDQUFFLEdBQUUsRUFBRSxVQUFRLE9BQUssY0FBWSxhQUFZLEdBQUU7QUFBQSxJQUNuRjtBQUNBLFFBQUcsRUFBRSxPQUFPLENBQUMsTUFBSSxHQUFFO0FBQ2pCLFlBQU0sT0FBSyxFQUFFLEVBQUUsT0FBTyxDQUFBQyxPQUFHQSxHQUFFLENBQUMsTUFBSSxDQUFDO0FBQ2pDLFVBQUcsS0FBSyxXQUFTLEVBQUUsTUFBSyxHQUFFLEtBQUssSUFBSSxPQUFPLEdBQUUsYUFBWSxJQUFHO0FBQUEsSUFDN0Q7QUFDQSxRQUFHLEVBQUUsT0FBTTtBQUNULFFBQUUsS0FBSztBQUFFLFFBQUUsS0FBSztBQUNoQixZQUFNLEtBQUcsRUFBRSxJQUFJLE9BQUcsRUFBRSxDQUFDLENBQUMsR0FBRSxLQUFHLEVBQUUsSUFBSSxPQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3hDLFlBQU0sT0FBSyxLQUFLLElBQUksR0FBRyxFQUFFLEdBQUUsT0FBSyxLQUFLLElBQUksR0FBRyxFQUFFLEdBQUUsSUFBRSxLQUFLLElBQUksR0FBRyxFQUFFLElBQUUsTUFBSyxJQUFFLEtBQUssSUFBSSxHQUFHLEVBQUUsSUFBRTtBQUV6RixlQUFRLElBQUUsR0FBRSxJQUFFLEtBQUssSUFBSSxJQUFHLElBQUUsSUFBRSxFQUFFLEdBQUUsS0FBSTtBQUNwQyxjQUFNLElBQUUsT0FBSyxNQUFNLElBQUUsRUFBRSxFQUFFLENBQUMsRUFBRyxDQUFDLElBQUUsRUFBRSxJQUFFLEdBQUUsSUFBRSxPQUFLLE1BQU0sSUFBRSxNQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUcsQ0FBQyxJQUFFLEVBQUUsSUFBRTtBQUN4RSxhQUFLLEdBQUUsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxJQUFFLE1BQU0sSUFBRSxDQUFDLElBQUUsR0FBRSxJQUFFLElBQUcsQ0FBQyxHQUFFLElBQUUsSUFBRSxjQUFZLGFBQVksSUFBRztBQUFBLE1BQ3pFO0FBQUMsUUFBRSxRQUFRO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDQSxJQUFFLFFBQVE7QUFDWjtBQUNBLFNBQVMsTUFBTSxHQUFPO0FBQUMsU0FBTyxFQUFFLEVBQUUsT0FBTyxDQUFDLEtBQUksQ0FBQyxHQUFFLENBQUMsTUFBSSxNQUFJLElBQUUsTUFBRyxJQUFFLEtBQUcsQ0FBQyxJQUFFLEVBQUUsRUFBRTtBQUFPO0FBQ2xGLFNBQVMsT0FBTyxHQUFPO0FBQUMsU0FBTyxFQUFFLEVBQUUsT0FBTyxDQUFDLEtBQUksTUFBSSxNQUFJLEVBQUUsQ0FBQyxHQUFFLENBQUMsSUFBRSxFQUFFLEVBQUU7QUFBTztBQUMxRSxTQUFTLE1BQU0sR0FBUztBQUFDLFFBQU0sSUFBRSxLQUFLLElBQUksSUFBRSxVQUFRLE1BQU0sSUFBRTtBQUFXLFNBQU8sSUFBRSxLQUFLLE1BQU0sQ0FBQztBQUFFO0FBRzlGLFNBQVMsV0FBVyxRQUEyQztBQUM3RCxRQUFNLFNBQU8sT0FBTyxLQUFLLENBQUMsR0FBRSxNQUFJLEVBQUUsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQ3BELFFBQU0sUUFBTSxDQUFDLEdBQVcsR0FBVyxPQUFjLEVBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxNQUFLLEVBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxNQUFLLEVBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQyxNQUFLLEVBQUUsQ0FBQyxJQUFHLEVBQUUsQ0FBQztBQUNwRyxRQUFNLE9BQUssQ0FBQyxPQUF1QjtBQUFDLFVBQU0sSUFBb0IsQ0FBQztBQUFFLGVBQVUsS0FBSyxJQUFHO0FBQUMsYUFBTSxFQUFFLFVBQVEsS0FBRyxNQUFNLEVBQUUsRUFBRSxTQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsU0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFHLEVBQUUsR0FBRSxJQUFJO0FBQUUsUUFBRSxLQUFLLENBQUM7QUFBQSxJQUFFO0FBQUMsV0FBTyxFQUFFLE1BQU0sR0FBRSxFQUFFO0FBQUEsRUFBRTtBQUN6TCxTQUFPLENBQUMsR0FBRyxLQUFLLE1BQU0sR0FBRSxHQUFHLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztBQUN4RDsiLCJuYW1lcyI6WyJ4IiwicCJdfQ==