import { addGold, roundGold } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/gold.ts";
import { unitControlsMercenaryCamp } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/mercenary-camp.ts";
import { boardingHoldShips, cancelCrewRendezvous, prepareCrewRendezvous } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/crew-rendezvous.ts";
import { prepareShipDefenseFrame, combatHull } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-defense.ts";
import { constrainGroundShipStep, drainShipCollisionImpacts, groundShipFrameEmpty, shipBodyClearAtPose } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-collisions.ts";
import { shipLaunchPose, shipLaunchPrototype } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-launch.ts";
import { landSpawnPoint, landSpawnPrototype } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/production-spawn.ts";
import { shipFireLaneClear } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-fire-control.ts";
import { beginShipBoarding, cancelShipBoarding, shipBoardingGoal, updateShipGangways, damageShipGangway, gangwayCrewEligible, bindGangwayCrewRules } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-gangway.ts";
import { assignPlayerColors } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/player-colors.ts";
import { BUILDING_WORK_REACH, buildingWorkGap, constructionWorkers } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/construction.ts";
import { GOLD_MINE_RULES, prepareMiningFrame, upkeepGoldIncome } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/mining.ts";
import { canReceiveHealing } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/healing.ts";
import { SPARK_FIRE, sparkIgnites } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/spark-fire.ts";
import { unitNeedsRepair, unitRepairHpPerGold } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-repair.ts";
import { innateMissile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/attack-presentation.ts";
import { invalidateItemIndex } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/item-index.ts";
import { settleGroundItems } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/item-surfaces.ts";
import { strikePoint, strikeGap, bodyGap } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/combat-geometry.ts";
import { purchasePlacement } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/purchase.ts";
import { SHIP_WEAPONS, PREVIOUS_SHIP_TRAIN_COST, damageShipParts, initializeShipEquipment, installedWeapons, mountedWeaponPose, mountedTargetPoint, mountedFireLaneClear, rebuildShipFittings, repairShipParts, shipPartMax, shipGunCanAim, shipMounts, bestFiringHeading } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-equipment.ts";
import { ITEM_DEFS, activeItem, canEquip, dropRefusal, freeItemSlot, itemEquipped, normalizeEquipment, removeFromHands, transferRefusal, weaponRules, wieldRefusal, itemHands, unitItemMass, shipItemMass, itemsFor } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/equipment.ts";
import { BREACH_CHARGE, FLAME_CLOAK, GUARDIAN_SCROLL, IVORY_TOWER_HP_SHARE, LIGHTNING_ROD, STORM_STAFF, NEUTRAL_ITEM_TARGET_RANGE, NEUTRAL_STORM_TARGET_RANGE } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/item-rules.ts";
import { EXPERIENCE_BOOK_XP, VETERANCY_GAIN_PER_STAR, killXpReward, xpStarThresholds } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-value.ts";
import { automaticTargetAllowed, combatTargetScore, combatVictimId, shouldSwitchCombatTarget } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/combat-target.ts";
import { crewBeforeHulls, boltIntersection, inWeaponCone, weaponDamage } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/weapons.ts";
import { aimAt, aimingProfile, invalidateMovedAim, markAimShot, RANGED_ATTACK_RANGE_THRESHOLD } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/aiming.ts";
export { RANGED_ATTACK_RANGE_THRESHOLD } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/aiming.ts";
import { ABILITY_DEFS, BUILDING_DEFS, DOCK_REPAIR, SUPPORT_BUILDING_HEAL, POISON_DAMAGE, POISON_TICKS, SLOW_PACE, SLOW_TICKS, SPLASH_RADIUS, SPLASH_SHARE, MAX_UPGRADE_LEVEL, MERCENARY_UNIT_KINDS, RACE_DEFS, UNIT_DEFS, UPGRADE_DEFS, UPGRADE_KINDS, canTrainAt, canResearchAt, constructionStartHp, hasSpell, isHealingBuildingKind, maxUpgradeLevel, requiredSupplyCap, unitMover, unitRules } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/catalog.ts";
import { abilityCooldown, tickedAbilityCooldowns, withAbilityCooldown } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ability-cooldowns.ts";
import { isStunned, unitAbilities } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-abilities.ts";
import { matchesUnitTarget, NON_MECHANICAL_TARGETS } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-targeting.ts";
import { rollVeteranSkillChoices } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/veteran-skills.ts";
import { unitClassOf } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-targeting.ts";
import { veteranWeaponRange } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/veteran-stats.ts";
import { buildVeteranFrame, castVeteranAbility, temporaryAttackSpeedMultiplier } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/veteran-runtime.ts";
import { checkCommandLegality } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/sim/command-validation.ts";
import { resolveUnitDamage, unitAttackDamageProfile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/damage.ts";
import { attackDamageProfile, weaponDamageProfile, DAMAGE_PROFILES, ITEM_DAMAGE_PROFILES } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/damage-types.ts";
import { autocastEnabled, canAutocast, withAutocast } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/autocast.ts";
import { buildingPlacementBlocker, terrainBlocksPlacement } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/build-placement.ts";
import { sameGround, footprintHalf, groundUnder, isOpenGround, isWalkable, openGroundNear, openStep, setBuildingBodies, shareBuildingBodies, snapToFootprint, steerPoint, walkableGoal, walkDestination } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/terrain.ts";
import { alongside, boardingBerth, canReach, carries, landingSpot } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/naval.ts";
import { detCos, detSin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/det-math.ts";
import { canBoard, boardUnit, deckPlacement, deckPointFits, moveOnDeck, restoreCargoDecks, syncDecks, settleGangwayCrossings } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/decks.ts";
import { bodyMass } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/physical-body.ts";
import { walkConnectedSurfaces, settleDeckSupport, decksCanTransfer } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/connected-decks.ts";
import { deckHullDamageShare, passengerDamageMultiplier } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/deck-combat.ts";
import { shipsIn, isShipKind, circleInPolygon, distanceToHull, localToWorld, shipPassengers, shipProfile, shareShipProfile, shipWeaponPose, worldToLocal, migrateShipSizes, SHIP_SIZE_MULTIPLIER } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { keepShipsOnWater, sailToward, turnShipToward } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/sailing.ts";
import { followQueuedShipCourse } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-queued-course.ts";
import { shipCanTurnForAttack, shipNavigationTarget, shipPursuitGoal } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-pursuit.ts";
import { beginShipMotionFrame } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-motion.ts";
import { beginShipPlanningFrame, tryAdmitShipPlan } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-planning-budget.ts";
import { cancelShipPlanningJob } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-planning-job.ts";
import { DEFAULT_WIND, updateAutoTrim } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-wind.ts";
import { hypot2 } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/hypot.ts";
import { MOVE_ORDER_ARRIVAL_RANGE } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/movement-rules.ts";
import { cabinGroupSelection, cabinCrewMovedThisTick, enterCabinStep, hasCabinCrewMovementFrame, isCabinProtected, isInCabin, leaveCabin, updateCabinPassengers } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-cabin.ts";
import { updateWindField } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/wind-field.ts";
import { shipTraffic } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-avoidance.ts";
import { headingDifference, hullPassageClear, nearestShipPose } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-navigation.ts";
import { BRACE_DAMAGE_SHARE, MAX_SLIDE_STEP, PUSH_FRICTION, blowStrength, canTakeStance, isStaggered, lungeStrength, pushContact, shove, slide } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/push.ts";
import {
  createBuilding,
  createInitialBuildings,
  createInitialItems,
  createInitialMercenaryCamps,
  createInitialResources,
  createInitialUnits,
  createUnit,
  createMap,
  DEFAULT_MAP_ID,
  LADDER_MAP_ID,
  trainTimeFor,
  withUnitShape
} from "/@fs/tmp/sketch-queue-source-42bd/src/shared/map.ts";
import { generateMap, TERRAIN_CELL } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/generated-map.ts";
import { BOOTS_SPEED, HEALING_SCROLL_HEAL, HEALING_SCROLL_RADIUS, IVORY_TOWER_REACH, RING_REGEN_PER_SECOND, buyRefusal, createShop, restockShops, shopBuyer } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/shop.ts";
import { poolMap } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/map-pool.ts";
import { perTick, seconds, SIM_TICKS_PER_SECOND } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
import { ownUnitLookup } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/unit-lookup.ts";
export const GAME_SNAPSHOT_RESTORE_KEYS = [
  "equipmentVersion",
  "rateUnits",
  "tick",
  "match",
  "map",
  "teams",
  "players",
  "units",
  "buildings",
  "resources",
  "mercenaryCamps",
  "shops",
  "items",
  "projectiles",
  "effects",
  "corpses",
  "variants",
  "obstacles"
];
const _snapshotRestoreKeysCoverSnapshot = true;
const MINE_RANGE = GOLD_MINE_RULES.entryRange;
const TOWN_HALL_DROP_RANGE = GOLD_MINE_RULES.dropRange;
const GOLD_PER_TRIP = GOLD_MINE_RULES.goldPerTrip;
const GATHER_DURATION = seconds(GOLD_MINE_RULES.gatherSeconds);
const GOLD_MINE_ENTRY_COOLDOWN = seconds(GOLD_MINE_RULES.entrySeconds);
const ITEM_PICKUP_RANGE = 72;
const SCORCH_DURATION = seconds(8);
const FLAME_CLOAK_VISUAL_DURATION = seconds(1.7);
const MOON_WELL_HEAL_EFFECT_DURATION = seconds(1.1);
const REPAIR_FULL_COST_FRACTION = 0.35;
const REPAIR_HP_PER_SECOND = UNIT_DEFS.footman.attackDamage / (UNIT_DEFS.footman.attackCooldown / seconds(1));
const REPAIR_HAMMER_EFFECT_DURATION = seconds(3);
export const AUTO_ACQUIRE_RANGE = 230;
const PROJECTILE_SPEED = 360;
const NEUTRAL_LEASH_RANGE = 650;
const NEUTRAL_DAMAGE_RESPONSE_RANGE = NEUTRAL_LEASH_RANGE;
const NEUTRAL_RETURN_STOP_RANGE = 8;
const NEUTRAL_ASSIST_RANGE = 360;
const HELP_CALL_RANGE = 300;
const GUARD_LEASH_RANGE = 600;
const DEFAULT_PLAYERS = ["player", "enemy"];
const DEFAULT_TEAMS = { player: "player", enemy: "enemy", enemy2: "enemy2" };
const DEFAULT_RACES = { player: "grove", enemy: "ember", enemy2: "grove" };
const RUNTIME_ID_START = 1e3;
const nativeUnitSpawners = /* @__PURE__ */ new WeakMap();
const NAVAL_FRAME = 1;
const CARGO_FRAME = 2;
const EMPTY_VETERAN_FRAME = 4;
const EMPTY_SHIP_STARTS = /* @__PURE__ */ new Map();
const EMPTY_SHIP_DEFENSES = /* @__PURE__ */ new Map();
function navalFrameFlags(game) {
  let flags = game.observer || nativeUnitSpawners.get(game) !== game.spawnUnit ? NAVAL_FRAME : EMPTY_VETERAN_FRAME;
  for (const unit of game.units) {
    if (unit.cargo) return NAVAL_FRAME | CARGO_FRAME;
    if (unit.veteranSkill !== void 0) flags &= ~EMPTY_VETERAN_FRAME;
    if (flags & NAVAL_FRAME) continue;
    const order = unit.order;
    if (unit.deck || unit.cabin || unit.gangway || unit.sailing || isShipKind(unit.kind) || order.type === "board" || order.type === "boardShip" || order.type === "unload" || order.type === "enterCabin" || order.type === "move" && (order.rendezvousFor || order.deckPoint || order.deckShipId) || order.type === "attackMove" && (order.deckPoint || order.deckShipId)) flags |= NAVAL_FRAME;
  }
  return flags | (flags & NAVAL_FRAME || shipsIn(game.units).length ? NAVAL_FRAME : 0);
}
export function createGame(mapId = DEFAULT_MAP_ID, options = {}) {
  const aiPlayers = options.aiPlayers ?? ["enemy"];
  const activePlayers = uniquePlayers(options.players ?? [...DEFAULT_PLAYERS, ...aiPlayers]);
  const teams = Object.fromEntries(activePlayers.map((owner, index) => [owner, options.teams?.[owner] ?? DEFAULT_TEAMS[owner] ?? `team-${index + 1}`]));
  const namedLayout = poolMap(mapId)?.layout;
  const layout = options.layout ?? namedLayout ?? (mapId === LADDER_MAP_ID ? { seed: "ladder" } : void 0);
  const namedShores = namedLayout?.kind === "sides" && (!options.layout || options.layout.kind === namedLayout.kind && options.layout.idea === namedLayout.idea);
  const layoutTeams = namedShores ? Object.fromEntries(activePlayers.map((id, index) => [id, `shore-${index % 2}`])) : teams;
  const generated = layout ? generateMap(layout, activePlayers, layoutTeams) : void 0;
  const shops = (generated?.sites ?? []).filter((site) => site.kind === "shop").map((site, index) => createShop(`shop-${index + 1}`, site.x, site.y));
  const game = {
    equipmentVersion: 1,
    rateUnits: "perSecond",
    tick: 0,
    match: createMatchState(activePlayers),
    map: generated ? { ...createMap(mapId), width: generated.size, height: generated.size, landmarks: generated.landmarks, ...generated.terrain ? { terrain: generated.terrain } : {} } : createMap(mapId),
    players: createPlayerStates(activePlayers, options),
    units: generated?.units ?? createInitialUnits(mapId, activePlayers, teams),
    buildings: generated?.buildings ?? createInitialBuildings(activePlayers, mapId, teams),
    resources: generated?.resources ?? createInitialResources(mapId, activePlayers, teams),
    mercenaryCamps: generated?.mercenaryCamps ?? createInitialMercenaryCamps(mapId),
    ...shops.length > 0 ? { shops } : {},
    items: generated?.items ?? createInitialItems(mapId),
    projectiles: [],
    effects: [],
    ...generated?.obstacles.length ? { obstacles: generated.obstacles } : {},
    nextId: RUNTIME_ID_START,
    activePlayers,
    teams,
    spawnUnit(owner, kind, x, y, launchPose) {
      const at = launchPose ?? walkableGoal(this.map, x, y, unitMover(kind));
      const unit = createUnit(`unit-${owner}-${kind}-${this.nextId}`, owner, kind, at.x, at.y);
      if (shipProfile(unit)) {
        const traffic = shipTraffic(unit, this.units, Infinity);
        const bodies = [...this.units, ...this.buildings, ...this.obstacles ?? []];
        const clear = (pose2) => traffic(pose2, pose2) && shipBodyClearAtPose(this.map, unit, pose2, bodies);
        const pose = launchPose ? clear(launchPose) ? launchPose : void 0 : nearestShipPose(this.map, unit, at, unit, clear);
        if (!pose) throw new Error("No clear water berth for this ship");
        Object.assign(unit, { x: pose.x, y: pose.y });
        unit.sailing = { heading: pose.heading, speed: 0, load: 0, balance: 0 };
      }
      this.nextId += 1;
      applyUnitUpgrades(this, unit);
      this.units.push(unit);
      initializeShipEquipment({ ...this, units: [unit] });
      normalizeEquipment({ ...this, units: [unit] }, true);
      refreshEquipmentMass(this, [unit]);
      return unit;
    }
  };
  game.map.wind = { ...DEFAULT_WIND };
  if (options.scenario) applyScenarioOverride(game, options.scenario);
  for (const building of game.buildings) Object.assign(building, snapToFootprint(game.map, building.radius, building));
  initializeShipEquipment(game);
  normalizeEquipment(game, true);
  refreshEquipmentMass(game);
  keepShipsOnWater(game.map, game.units);
  updateSupplyState(game);
  nativeUnitSpawners.set(game, game.spawnUnit);
  return game;
}
function uniquePlayers(players) {
  return [...new Set(players)];
}
function createMatchState(players) {
  return {
    winner: null,
    endedAtTick: null,
    stats: {
      unitsKilled: { ...zeroPlayerRecord(players), neutral: 0 },
      unitsLost: { ...zeroPlayerRecord(players), neutral: 0 },
      buildingsDestroyed: zeroPlayerRecord(players),
      nonBaseBuildingsDestroyed: zeroPlayerRecord(players),
      goldSpent: zeroPlayerRecord(players),
      mercenaryKills: zeroPlayerRecord(players),
      neutralUnitsKilled: zeroPlayerRecord(players),
      unitsKilledByNeutral: zeroPlayerRecord(players)
    }
  };
}
function createPlayerStates(activePlayers, options) {
  const players = {};
  for (const [index, owner] of [.../* @__PURE__ */ new Set([...activePlayers, "player", "enemy", "enemy2"])].entries()) {
    players[owner] = {
      race: options.races?.[owner] ?? DEFAULT_RACES[owner] ?? (index % 2 === 0 ? "grove" : "ember"),
      gold: 500,
      supplyUsed: 0,
      supplyCap: 0,
      upgrades: createEmptyUpgradeLevels()
    };
  }
  const colors = assignPlayerColors(Object.keys(players));
  for (const [owner, player] of Object.entries(players)) player.color = colors[owner];
  return players;
}
function createEmptyUpgradeLevels() {
  return Object.fromEntries(UPGRADE_KINDS.map((upgradeKind) => [upgradeKind, 0]));
}
function zeroPlayerRecord(players) {
  return Object.fromEntries([.../* @__PURE__ */ new Set([...players, "player", "enemy", "enemy2"])].map((owner) => [owner, 0]));
}
function addThirdPlayerStart(game) {
  game.buildings.push(createBuilding("building-enemy2-townhall", "enemy2", "townHall", game.map.width - 480, 480, true));
  game.units.push(
    createUnit("unit-enemy2-worker-1", "enemy2", "worker", game.map.width - 590, 460),
    createUnit("unit-enemy2-worker-2", "enemy2", "worker", game.map.width - 540, 545),
    createUnit("unit-enemy2-worker-3", "enemy2", "worker", game.map.width - 450, 520)
  );
  game.resources.push({ id: "gold-enemy2-main", kind: "goldMine", x: game.map.width - 590, y: 460, amount: 8e3 });
}
function applyScenarioOverride(game, scenario) {
  if (scenario.replaceDefaultUnits) game.units = [];
  if (scenario.replaceDefaultBuildings) game.buildings = [];
  if (scenario.replaceDefaultResources) game.resources = [];
  if (scenario.replaceDefaultMercenaryCamps) game.mercenaryCamps = [];
  if (scenario.replaceDefaultLandmarks) game.map.landmarks = [];
  const ids = /* @__PURE__ */ new Set([
    ...game.units.map((unit) => unit.id),
    ...game.buildings.map((building) => building.id),
    ...game.resources.map((resource) => resource.id),
    ...game.mercenaryCamps.map((camp) => camp.id),
    ...(game.shops ?? []).map((shop) => shop.id),
    ...game.items.map((item) => item.id),
    ...game.map.landmarks.map((landmark) => landmark.id)
  ]);
  const claimId = (id) => {
    if (ids.has(id)) throw new Error(`Duplicate scenario id ${id}`);
    ids.add(id);
  };
  for (const [owner, seed] of Object.entries(scenario.players ?? {})) {
    const player = game.players[owner];
    if (!player) throw new Error(`Unknown scenario player ${owner}`);
    if (seed.gold !== void 0) {
      if (!Number.isFinite(seed.gold) || seed.gold < 0) throw new Error(`Invalid scenario gold for ${owner}`);
      player.gold = roundGold(seed.gold);
    }
    for (const [upgradeKind, level] of Object.entries(seed.upgrades ?? {})) {
      if (!Number.isInteger(level) || level < 0) throw new Error(`Invalid scenario ${upgradeKind} level for ${owner}`);
      player.upgrades[upgradeKind] = level;
    }
  }
  for (const resource of scenario.addResources ?? []) {
    claimId(resource.id);
    game.resources.push({ ...resource });
  }
  for (const camp of scenario.addMercenaryCamps ?? []) {
    claimId(camp.id);
    game.mercenaryCamps.push({ ...camp });
  }
  for (const shop of scenario.addShops ?? []) {
    claimId(shop.id);
    (game.shops ??= []).push({ ...shop, goods: shop.goods.map((good) => ({ ...good })) });
  }
  for (const item of scenario.addItems ?? []) {
    claimId(item.id);
    game.items.push({ ...item });
  }
  for (const seed of scenario.addUnits ?? []) {
    claimId(seed.id);
    const unit = createUnit(seed.id, seed.owner, seed.kind, seed.x, seed.y);
    applyUnitUpgrades(game, unit);
    if (seed.xp !== void 0) {
      if (!Number.isFinite(seed.xp) || seed.xp < 0) throw new Error(`Invalid scenario xp for ${seed.id}`);
      unit.xp = seed.xp;
      applyXpLevel(game, unit);
    }
    if (seed.hp !== void 0) {
      if (!Number.isFinite(seed.hp) || seed.hp <= 0 || seed.hp > unit.maxHp) throw new Error(`Invalid scenario hp for ${seed.id}`);
      unit.hp = seed.hp;
    }
    if (seed.hpRatio !== void 0) {
      if (!Number.isFinite(seed.hpRatio) || seed.hpRatio <= 0 || seed.hpRatio > 1) throw new Error(`Invalid scenario hpRatio for ${seed.id}`);
      unit.hp = Math.max(1, Math.round(unit.maxHp * seed.hpRatio));
    }
    if (seed.order) unit.order = { ...seed.order };
    game.units.push(unit);
  }
  for (const seed of scenario.addBuildings ?? []) {
    claimId(seed.id);
    const building = createBuilding(seed.id, seed.owner, seed.kind, seed.x, seed.y, seed.complete ?? true);
    if (seed.maxHp !== void 0) {
      if (!Number.isFinite(seed.maxHp) || seed.maxHp <= 0) throw new Error(`Invalid scenario maxHp for ${seed.id}`);
      building.maxHp = seed.maxHp;
    }
    if (seed.hp !== void 0) {
      if (!Number.isFinite(seed.hp) || seed.hp <= 0 || seed.hp > building.maxHp) throw new Error(`Invalid scenario hp for ${seed.id}`);
      building.hp = seed.hp;
    }
    game.buildings.push(building);
  }
  for (const landmark of scenario.addLandmarks ?? []) {
    claimId(landmark.id);
    game.map.landmarks.push({ ...landmark });
  }
}
export function issueCommand(game, command) {
  issuePlayerCommand(game, "player", command);
}
export function issuePlayerCommand(game, owner, command) {
  if (!game.players[owner]) throw new Error(`Unknown player ${owner}`);
  const cabinOperands = "unitIds" in command ? [...command.unitIds] : "unitId" in command ? [command.unitId] : [];
  if ("targetId" in command && command.targetId) cabinOperands.push(command.targetId);
  if ("recipientId" in command && command.recipientId) cabinOperands.push(command.recipientId);
  if (command.type === "unloadPassenger") cabinOperands.push(command.passengerId);
  if (command.type === "transferItem") {
    const item = game.items.find((item2) => item2.id === command.itemId);
    if (item?.carrierId) cabinOperands.push(item.carrierId);
    if ("unitId" in command.destination) cabinOperands.push(command.destination.unitId);
    else if ("installerId" in command.destination && command.destination.installerId) cabinOperands.push(command.destination.installerId);
  }
  if (command.type === "enterCabin" || command.type === "leaveCabin" || game.units.some((unit) => cabinOperands.includes(unit.id) && isInCabin(unit))) {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
  }
  if (command.type === "enterCabin" || command.type === "leaveCabin") {
    const selected = unitsByIds(game, command.unitIds, owner);
    const admitted = command.type === "enterCabin" ? new Set(cabinGroupSelection(game, selected)) : void 0;
    for (const unit of selected) {
      if (command.type === "leaveCabin") leaveCabin(game, unit);
      else if (admitted.has(unit.id)) assignUnitOrder(unit, { type: "enterCabin", shipId: unit.deck.shipId });
    }
    return;
  }
  if (command.type === "boardShip") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const ships = unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship));
    if (!command.queued) cancelCrewRendezvous(game.units, new Set(ships.map((ship) => ship.id)));
    for (const ship of ships)
      assignUnitOrder(ship, { type: "boardShip", targetId: command.targetId }, command.queued);
    return;
  }
  if (command.type === "cancelBoardShip") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const ships = unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship));
    cancelCrewRendezvous(game.units, new Set(ships.map((ship) => ship.id)));
    for (const ship of ships) {
      cancelShipBoarding(ship);
      if (ship.order.type === "boardShip") assignUnitOrder(ship, { type: "idle" });
    }
    settleGangwayCrossings(game.units);
    return;
  }
  if (command.type === "learnVeteranSkill") {
    const error = checkCommandLegality(game, owner, command);
    if (error) throw new Error(error.message);
    const unit = game.units.find((unit2) => unit2.id === command.unitId);
    unit.veteranSkill = command.skill;
    refreshVeteranFrame(game);
    return;
  }
  if ("unitIds" in command && !("queued" in command && command.queued) && ["move", "attackMove", "stop", "holdPosition", "unload", "follow", "aim", "attack"].includes(command.type)) {
    const ships = new Set(unitsByIds(game, command.unitIds, owner).filter((ship) => shipProfile(ship)).map((ship) => ship.id));
    if (ships.size) cancelCrewRendezvous(game.units, ships);
  }
  if (command.type === "move") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      assignUnitOrder(unit, deckPointOrder(game, unit, { type: "move", x: command.x, y: command.y, ...command.avoidCombat ? { avoidCombat: true } : {} }), command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", command.x, command.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "attackMove") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      assignUnitOrder(unit, deckPointOrder(game, unit, { type: unit.attackDamage > 0 ? "attackMove" : "move", x: command.x, y: command.y }), command.queued);
    }
    addEffect(game, command.queued ? "queuedAttack" : "attack", command.x, command.y, command.queued ? 42 : 28, { owner });
    return;
  }
  if (command.type === "stop") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) assignUnitOrder(unit, { type: "idle" });
    return;
  }
  if (command.type === "aim") {
    if (!Number.isFinite(command.x) || !Number.isFinite(command.y)) throw new Error("Aim requires a finite point");
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (aimingProfile(weaponRules(game, unit))) assignUnitOrder(unit, { type: "aim", x: clamp(command.x, 0, game.map.width), y: clamp(command.y, 0, game.map.height) }, command.queued);
    }
    return;
  }
  if (command.type === "holdPosition") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit.kind === "worker") continue;
      assignUnitOrder(unit, { type: "hold", x: unit.x, y: unit.y }, command.queued);
    }
    return;
  }
  if (command.type === "attack") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit.attackDamage > 0) assignUnitOrder(unit, { type: "attack", targetId: command.targetId }, command.queued);
    }
    const target = findStrikeTarget(game, command.targetId);
    if (target) addEffect(game, command.queued ? "queuedAttackTarget" : "attackTarget", target.x, target.y, command.queued ? 44 : 32, { owner });
    return;
  }
  if (command.type === "follow") {
    const target = game.units.find((unit) => unit.id === command.targetId && !areEnemyOwners(game, unit.owner, owner));
    if (!target) throw new Error(`Unknown friendly unit ${command.targetId}`);
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (unit !== target) assignUnitOrder(unit, { type: "follow", targetId: target.id }, command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", target.x, target.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "mine") {
    const resource = game.resources.find((candidate) => candidate.id === command.resourceId);
    if (!resource) throw new Error(`Unknown resource ${command.resourceId}`);
    for (const unit of unitsByIds(game, command.unitIds, owner).filter((unit2) => unit2.kind === "worker")) {
      const order = !command.queued && unit.order.type === "mine" && unit.order.resourceId === resource.id ? unit.order : { type: "mine", resourceId: resource.id, phase: unit.carryingGold > 0 ? "return" : "toMine", timer: 0 };
      assignUnitOrder(unit, order, command.queued);
    }
    addEffect(game, command.queued ? "queuedMine" : "mine", resource.x, resource.y, command.queued ? 44 : 30, { owner });
    return;
  }
  if (command.type === "repair") {
    const building2 = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    if (building2.hp >= building2.maxHp) throw new Error(`${building2.kind} is already fully repaired`);
    for (const unit of unitsByIds(game, command.unitIds, owner).filter((unit2) => unit2.kind === "worker")) {
      assignUnitOrder(unit, { type: "repair", buildingId: building2.id }, command.queued);
      if (unit.order.type === "repair" && unit.order.buildingId === building2.id) unit.cooldown = 0;
    }
    addRepairHammerEffect(game, building2, command.queued);
    return;
  }
  if (command.type === "repairUnit" || command.type === "repairShip") {
    const target = game.units.find((candidate) => candidate.id === command.targetId && candidate.owner === owner && (command.type !== "repairShip" || unitMover(candidate.kind) === "sea"));
    if (!target) throw new Error(`Unknown ${owner} repair target ${command.targetId}`);
    if (!unitNeedsRepair(game, target)) throw new Error(`${target.kind} cannot be repaired or is already fully repaired`);
    for (const worker of unitsByIds(game, command.unitIds, owner).filter((unit) => unit.kind === "worker"))
      assignUnitOrder(worker, { type: "repairUnit", targetId: target.id }, command.queued);
    return;
  }
  if (command.type === "build") {
    const worker = game.units.find((unit) => unit.id === command.unitId && unit.owner === owner && unit.kind === "worker");
    if (!worker) throw new Error(`Unknown ${owner} worker ${command.unitId}`);
    if (!RACE_DEFS[playerState(game, owner).race].buildableBuildings.includes(command.buildingKind)) throw new Error(`${playerState(game, owner).race} race cannot build ${command.buildingKind}`);
    const blocker = buildingPlacementBlocker(game, command.buildingKind, command);
    if (blocker) throw new Error(`${command.buildingKind} placement is too close to ${blocker.kind}`);
    if (terrainBlocksPlacement(game.map, command.buildingKind, command)) throw new Error(`${command.buildingKind} placement is on blocked ground`);
    if (playerState(game, owner).gold < BUILDING_DEFS[command.buildingKind].cost) throw new Error("Not enough gold");
    const at = snapToFootprint(game.map, BUILDING_DEFS[command.buildingKind].radius, command);
    assignUnitOrder(worker, { type: "build", buildingKind: command.buildingKind, ...at, progressTick: game.tick, progressX: worker.x, progressY: worker.y });
    return;
  }
  if (command.type === "cancelTraining") {
    const building2 = game.buildings.find((b) => b.id === command.buildingId && b.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    const index = building2.queue.findIndex((job2) => job2.id === command.jobId);
    if (index < 0) return;
    const [job] = building2.queue.splice(index, 1);
    const refund = job.paidGold ?? UNIT_DEFS[job.unitKind].cost;
    playerState(game, owner).gold = addGold(playerState(game, owner).gold, refund);
    game.match.stats.goldSpent[owner] = Math.max(0, (game.match.stats.goldSpent[owner] ?? 0) - refund);
    updateSupplyState(game);
    return;
  }
  if (command.type === "setRally") {
    setRally(game, owner, command.buildingIds, command.x, command.y, command.target);
    return;
  }
  if (command.type === "cast") {
    const unitCount = game.units.length;
    castAbility(game, owner, command.unitId, command.ability, command.targetId, command.x, command.y, command.queued);
    if (game.units.length !== unitCount) refreshVeteranFrameAfterCommandSpawn(game);
    return;
  }
  if (command.type === "setAutocast") {
    if (!canAutocast(command.ability)) throw new Error(`${command.ability} cannot be autocast`);
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (!unitAbilities(unit).includes(command.ability)) continue;
      const autocast = withAutocast(unit, command.ability, command.enabled);
      if (autocast) unit.autocast = autocast;
      else unit.autocast = void 0;
    }
    return;
  }
  if (command.type === "setStance") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (canTakeStance(unit.kind)) unit.stance = command.stance === "pursue" ? void 0 : command.stance;
    }
    return;
  }
  if (command.type === "hire") {
    hireMercenary(game, owner, command.campId);
    refreshVeteranFrameAfterCommandSpawn(game);
    return;
  }
  if (command.type === "buy") {
    buyGood(game, owner, command.shopId, command.item, command.recipientId);
    return;
  }
  if (command.type === "board") {
    const transport = game.units.find((unit) => unit.id === command.transportId && unit.hp > 0 && carries(unit) > 0);
    if (!transport) throw new Error(`Unknown ${owner} transport ${command.transportId}`);
    const boarders = unitsByIds(game, command.unitIds, owner).filter((unit) => canBoard(transport, unit, game.units));
    const existing = game.units.find((unit) => unit.order.type === "board" && unit.order.transportId === transport.id);
    const shoreBoarder = boarders.find((unit) => !unit.deck);
    const berth = (existing?.order.type === "board" ? existing.order.berth : void 0) ?? (shoreBoarder && boardingBerth(game.map, shoreBoarder, transport));
    for (const unit of boarders) {
      assignUnitOrder(unit, { type: "board", transportId: transport.id, ...!unit.deck && berth ? { berth } : {} }, command.queued);
      const source = unit.deck && game.units.find((ship) => ship.id === unit.deck.shipId && ship.owner === owner);
      if (source && !command.queued && !source.sailing?.gangway) assignUnitOrder(source, { type: "idle" });
    }
    return;
  }
  if (command.type === "unloadPassenger") {
    const transport = unitsByIds(game, [command.transportId], owner)[0];
    if (transport) unloadCargo(game, transport, command.passengerId);
    return;
  }
  if (command.type === "unload") {
    for (const unit of unitsByIds(game, command.unitIds, owner)) {
      if (carries(unit) > 0) assignUnitOrder(unit, { type: "unload", x: command.x, y: command.y, ...command.avoidCombat ? { avoidCombat: true } : {} }, command.queued);
    }
    addEffect(game, command.queued ? "queuedMove" : "move", command.x, command.y, command.queued ? 38 : 24, { owner });
    return;
  }
  if (command.type === "research") {
    const building2 = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
    if (!building2) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
    queueResearch(game, building2, command.upgradeKind);
    return;
  }
  if (command.type === "buyShipEquipment") {
    const dock = game.buildings.find((building2) => building2.id === command.buildingId && building2.owner === owner && building2.kind === "shipyard" && building2.complete);
    if (!dock) throw new Error("A completed shipyard is required");
    const delivery = command.recipientId !== void 0 ? purchasePlacement(game, owner, dock, command.item, command.recipientId) : void 0;
    if (delivery && "refusal" in delivery) throw new Error(delivery.refusal);
    const def = SHIP_WEAPONS[command.item];
    spendGold(game, owner, def.cost);
    const at = walkableGoal(game.map, dock.x, dock.y + dock.radius + 36, "land");
    const item = { id: `ship-item-${game.nextId++}`, kind: command.item, x: at.x, y: at.y, durability: def.hp, cooldownRemaining: 0 };
    game.items.push(item);
    if (delivery && "placement" in delivery) deliverPurchase(game, item, delivery.placement);
    else addEffect(game, "summon", at.x, at.y, seconds(0.8));
    return;
  }
  if (command.type === "transferItem") {
    const refusal = transferRefusal(game, owner, command.itemId, command.destination);
    if (refusal) throw new Error(refusal);
    const item = game.items.find((item2) => item2.id === command.itemId);
    const originalShip = item.shipId;
    const source = game.units.find((unit) => unit.id === item.carrierId);
    if (source) removeFromHands(source, item.id);
    delete item.carrierId;
    delete item.slot;
    delete item.shipId;
    delete item.holdSlot;
    delete item.mountId;
    delete item.aim;
    if ("unitId" in command.destination) {
      item.carrierId = command.destination.unitId;
      item.slot = command.destination.slot;
    } else {
      item.shipId = command.destination.shipId;
      if ("mountId" in command.destination) {
        item.mountId = command.destination.mountId;
        item.durability ??= SHIP_WEAPONS[item.kind].hp;
      } else item.holdSlot = command.destination.slot;
    }
    invalidateItemIndex(game.items);
    for (const unit of game.units) {
      if (shipProfile(unit) && (unit.id === originalShip || unit.id === item.shipId)) rebuildShipFittings(game, unit);
      if (unit.id === source?.id || unit.id === item.carrierId || unit.id === originalShip || unit.id === item.shipId) applyDerivedUnitStats(game, unit);
    }
    refreshEquipmentMass(game);
    return;
  }
  if (command.type === "wieldItem") {
    const refusal = wieldRefusal(game, owner, command.unitId, command.itemId, command.hand);
    if (refusal) throw new Error(refusal);
    const unit = game.units.find((unit2) => unit2.id === command.unitId);
    unit.hands ??= {};
    if (command.itemId) {
      removeFromHands(unit, command.itemId);
      unit.hands[command.hand] = command.itemId;
      const item = game.items.find((item2) => item2.id === command.itemId);
      if (itemHands(item) === 2) delete unit.hands.left;
    } else delete unit.hands[command.hand];
    unit.aim = void 0;
    unit.cooldown = Math.max(unit.cooldown, seconds(0.35));
    applyDerivedUnitStats(game, unit);
    return;
  }
  if (command.type === "pickupItem") {
    pickupItem(game, owner, command.unitId, command.itemId, command.queued);
    return;
  }
  if (command.type === "dropItem") {
    dropItem(game, owner, command.unitId, command.itemId, command.x, command.y);
    return;
  }
  if (command.type === "useItem") {
    useItem(game, owner, command.unitId, command.itemId, command.targetId, command.x, command.y);
    return;
  }
  const building = game.buildings.find((candidate) => candidate.id === command.buildingId && candidate.owner === owner);
  if (!building) throw new Error(`Unknown ${owner} building ${command.buildingId}`);
  queueTraining(game, building, command.unitKind);
}
export function stepGame(game) {
  if (game.match.winner) return;
  const entryFlags = navalFrameFlags(game);
  const emptyVeteranFrame = !!(entryFlags & EMPTY_VETERAN_FRAME);
  let navalFrame = !!(entryFlags & NAVAL_FRAME);
  if (navalFrame) {
    bindGangwayCrewRules(game.units, game);
    if (entryFlags & CARGO_FRAME) restoreCargoDecks(game.units);
    syncDecks(game.units);
    updateCabinPassengers(game);
  }
  const entryUnits = game.units, entryCount = game.units.length;
  game.tick += 1;
  updateWindField(game.map, game.tick);
  game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  refreshVeteranFrame(game, emptyVeteranFrame);
  syncBuildingBodies(game);
  updateWorldEffects(game);
  updateProjectiles(game);
  updateUnitStatusEffects(game);
  updateConstruction(game);
  updateTraining(game);
  updateResearch(game);
  updateResources(game);
  game.miningFrame = prepareMiningFrame(game);
  updateMercenaryCamps(game);
  if (game.shops) restockShops(game.shops);
  const unitsChanged = game.units !== entryUnits || game.units.length !== entryCount;
  if (!navalFrame && unitsChanged) navalFrame = !!(navalFrameFlags(game) & NAVAL_FRAME);
  if (navalFrame || unitsChanged) game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  game.unitSpatialByTeam = createTeamSpatialIndexes(game, game.units, 230, game.unitSpatialByTeam);
  game.shipReachPadding = navalFrame ? shipReachPadding(game.units) : 0;
  if (!game.buildingSpatial || game.buildingSpatialCount !== game.buildings.length) {
    game.buildingSpatial = createSpatialIndex(game.buildings, 420);
    game.buildingSpatialByTeam = createTeamSpatialIndexes(game, game.buildings, 260);
    game.buildingSpatialCount = game.buildings.length;
  }
  game.entityById = createEntityIndex(game);
  updateItems(game);
  updateMoonWellHealing(game);
  updateRegeneration(game);
  if (navalFrame) updateDockRepairs(game);
  updateTowerAttacks(game);
  const vessels = shipsIn(game.units);
  const starts = vessels.length ? new Map(vessels.map((ship) => [ship.id, { x: ship.x, y: ship.y, heading: ship.sailing.heading }])) : EMPTY_SHIP_STARTS;
  beginShipMotionFrame(game.units, game.map, game.buildingBodiesSeen ?? game.buildings, vessels);
  let defenses;
  if (navalFrame) {
    beginShipPlanningFrame(game.units, game.tick, vessels);
    updateShipGangways(game.map, game.units, game.tick, game);
    prepareCrewRendezvous(game.map, game.units);
    game.boardingHolds = boardingHoldShips(game.units);
    defenses = prepareShipDefenseFrame(game, (ship, range, visit) => forEachNearbyEnemyUnit(game, ship.owner, ship, range, visit), game.boardingHolds);
    const shoreBoarders = /* @__PURE__ */ new Map();
    for (const unit of game.units) if (unit.hp > 0 && !unit.deck && unit.order.type === "board") {
      const waiting = shoreBoarders.get(unit.order.transportId);
      if (waiting) waiting.push(unit);
      else shoreBoarders.set(unit.order.transportId, [unit]);
    }
    for (const ship of shipsIn(game.units)) {
      const collecting = ship.order.type === "idle" && shoreBoarders.get(ship.id)?.some((unit) => unit.owner === ship.owner && !alongside(unit, ship));
      const idle = game.boardingHolds.has(ship.id) || ship.order.type === "hold" || ship.order.type === "idle" && !collecting && !defenses.has(ship.id) || !!ship.sailing?.gangway && ship.sailing.gangway.phase !== "approach";
      updateAutoTrim(ship, game.map, idle ? "idle" : ship.sailing?.sail?.mode === "idle" ? "sail" : void 0);
    }
  } else {
    if (!game.boardingHolds || game.boardingHolds.size) game.boardingHolds = /* @__PURE__ */ new Set();
    defenses = EMPTY_SHIP_DEFENSES;
  }
  const updateUnitsSource = game.units, updateUnitsCount = game.units.length;
  const ferry = updateUnits(game, defenses, navalFrame, emptyVeteranFrame);
  if (!navalFrame && (ferry || (game.units !== updateUnitsSource || game.units.length !== updateUnitsCount) && navalFrameFlags(game) & NAVAL_FRAME)) navalFrame = true;
  if (navalFrame) updateMountedWeapons(game, starts, defenses);
  if (ferry) ferryUnits(game, ferry, starts);
  if (navalFrame) {
    for (const ship of shipsIn(game.units)) {
      const start = starts.get(ship.id);
      if (start && ship.sailing && start.x === ship.x && start.y === ship.y) ship.sailing.speed = 0;
    }
    updateShipGangways(game.map, game.units, game.tick, game);
    settleGangwayCrossings(game.units);
    syncDecks(game.units);
    settleDeckSupport(game.units, game.map);
    updateCabinPassengers(game);
  }
  slideUnits(game);
  separateUnits(game, navalFrame);
  if (navalFrame) syncDecks(game.units);
  if (game.map.terrain) keepUnitsOutOfBuildings(game);
  for (const impact of drainShipCollisionImpacts(game.units)) {
    const other = impact.other;
    const source = other && !isObstacle(other) ? other : impact.ship;
    if (impact.ship.hp > 0 && impact.shipDamage > 0) {
      const taken = applyDamage(game, source, impact.ship, impact.shipDamage, 0, impact.point, 0, DAMAGE_PROFILES.EXPLOSION);
      if (taken !== void 0 && taken > 0) addHitEffect(game, impact.ship, taken);
    }
    if (other && other.hp > 0 && impact.otherDamage > 0) {
      const taken = applyDamage(game, impact.ship, other, impact.otherDamage, 0, impact.point, 0, DAMAGE_PROFILES.EXPLOSION);
      if (taken !== void 0 && taken > 0) addHitEffect(game, other, taken);
    }
  }
  if (navalFrame) for (const ship of shipsIn(game.units)) {
    const start = starts.get(ship.id);
    if (!ship.sailing) continue;
    ship.sailing.velocityX = start ? (ship.x - start.x) * SIM_TICKS_PER_SECOND : 0;
    ship.sailing.velocityY = start ? (ship.y - start.y) * SIM_TICKS_PER_SECOND : 0;
  }
  for (const unit of game.units) if (unit.aim) invalidateMovedAim(unit, weaponRules(game, unit));
  removeExpiredUnits(game);
  removeDead(game);
  if (settleGroundItems(game.items, game.units, game.map)) refreshEquipmentMass(game);
  if (navalFrame) updateShipOwnership(game);
  syncBuildingBodies(game);
  game.unitSpatial = createSpatialIndex(game.units, 320, game.unitSpatial);
  refreshVeteranFrame(game, emptyVeteranFrame);
  updateVictory(game);
}
function syncBuildingBodies(game) {
  const seen = game.buildingBodiesSeen;
  const obstacles = game.obstacles ?? [];
  const count = game.buildings.length;
  if (seen && seen.length === count + obstacles.length && game.buildings.every((building, index) => building === seen[index]) && obstacles.every((obstacle, index) => obstacle === seen[count + index])) return;
  game.buildingBodiesSeen = [...game.buildings, ...obstacles];
  setBuildingBodies(game.map, game.buildingBodiesSeen);
}
function copyUnitOrder(order) {
  const copy = { ...order };
  if ((copy.type === "move" || copy.type === "attackMove") && copy.deckPoint) copy.deckPoint = { ...copy.deckPoint };
  if (copy.type === "board") {
    if (copy.deckPoint) copy.deckPoint = { ...copy.deckPoint };
    if (copy.rendezvous) copy.rendezvous = { ...copy.rendezvous };
    if (copy.berth) copy.berth = { ...copy.berth };
  }
  return copy;
}
export function snapshotGame(game) {
  const snapshot = {
    equipmentVersion: 1,
    rateUnits: "perSecond",
    tick: game.tick,
    match: {
      winner: game.match.winner,
      endedAtTick: game.match.endedAtTick,
      stats: {
        unitsKilled: { ...game.match.stats.unitsKilled },
        unitsLost: { ...game.match.stats.unitsLost },
        buildingsDestroyed: { ...game.match.stats.buildingsDestroyed },
        nonBaseBuildingsDestroyed: { ...game.match.stats.nonBaseBuildingsDestroyed },
        goldSpent: { ...game.match.stats.goldSpent },
        mercenaryKills: { ...game.match.stats.mercenaryKills },
        neutralUnitsKilled: { ...game.match.stats.neutralUnitsKilled },
        unitsKilledByNeutral: { ...game.match.stats.unitsKilledByNeutral }
      }
    },
    map: { ...game.map, ...game.map.wind ? { wind: { ...game.map.wind } } : {} },
    teams: { ...game.teams },
    players: Object.fromEntries(Object.entries(game.players).map(([owner, player]) => [owner, { ...player, upgrades: { ...player.upgrades } }])),
    units: game.units.map((unit) => {
      const copy = { ...unit };
      copy.order = copyUnitOrder(unit.order);
      copy.orderQueue = unit.orderQueue?.map(copyUnitOrder) ?? [];
      if (unit.aim) copy.aim = { ...unit.aim };
      if (unit.deck) copy.deck = { ...unit.deck };
      if (unit.cabin) copy.cabin = { ...unit.cabin };
      if (unit.hands) copy.hands = { ...unit.hands };
      if (unit.shipParts) copy.shipParts = { ...unit.shipParts };
      if (unit.fittings) copy.fittings = unit.fittings.map((fitting) => ({ ...fitting, accepts: [...fitting.accepts] }));
      if (unit.sailing) {
        copy.sailing = { ...unit.sailing };
        if (unit.sailing.sail) copy.sailing.sail = { ...unit.sailing.sail };
        if (unit.sailing.pursuit) copy.sailing.pursuit = { ...unit.sailing.pursuit };
        if (unit.sailing.defense) copy.sailing.defense = { ...unit.sailing.defense };
        if (unit.sailing.gangway) copy.sailing.gangway = { ...unit.sailing.gangway, sourceAnchor: { ...unit.sailing.gangway.sourceAnchor }, targetAnchor: { ...unit.sailing.gangway.targetAnchor } };
        if (unit.sailing.route) copy.sailing.route = { ...unit.sailing.route, end: { ...unit.sailing.route.end }, points: unit.sailing.route.points.map((point) => ({ ...point, ...point.pivot ? { pivot: { ...point.pivot } } : {} })) };
      }
      if (unit.gangway) copy.gangway = { ...unit.gangway };
      if (unit.abilityCooldowns) copy.abilityCooldowns = { ...unit.abilityCooldowns };
      if (unit.autocast) copy.autocast = { ...unit.autocast };
      if (unit.veteranSkillChoices) copy.veteranSkillChoices = [...unit.veteranSkillChoices];
      copy.effects = unit.effects.map((effect) => ({ ...effect, ...effect.damageFilter ? {
        damageFilter: Object.fromEntries(Object.entries(effect.damageFilter).map(([key, value]) => [key, Array.isArray(value) ? [...value] : value]))
      } : {} }));
      return copy;
    }),
    buildings: game.buildings.map((building) => {
      const { rallyTarget, ...rest } = building;
      const copy = rest;
      if (rallyTarget) copy.rallyTarget = { ...rallyTarget };
      copy.queue = building.queue.map((job) => ({ ...job }));
      copy.researchQueue = building.researchQueue.map((job) => ({ ...job }));
      return copy;
    }),
    resources: game.resources.map((resource) => ({ ...resource })),
    mercenaryCamps: game.mercenaryCamps.map((camp) => ({ ...camp })),
    ...game.shops ? { shops: game.shops.map((shop) => ({ ...shop, goods: shop.goods.map((good) => ({ ...good })) })) } : {},
    items: game.items.map((item) => ({ ...item, ...item.aim ? { aim: { ...item.aim } } : {}, ...item.deck ? { deck: { ...item.deck } } : {} })),
    projectiles: game.projectiles.map((projectile) => ({
      ...projectile,
      ...projectile.damageProfile ? { damageProfile: { ...projectile.damageProfile } } : {},
      ...projectile.weapon ? { weapon: { ...projectile.weapon, ...projectile.weapon.damageProfile ? { damageProfile: { ...projectile.weapon.damageProfile } } : {} } } : {}
    })),
    effects: game.effects.map((effect) => ({ ...effect, ...effect.damageProfile ? { damageProfile: { ...effect.damageProfile } } : {} })),
    ...game.corpses ? { corpses: game.corpses.map((corpse) => ({ ...corpse, ...corpse.deck ? { deck: { ...corpse.deck } } : {} })) } : {},
    // A variant's rules are replaced whole when they change, never edited, so the snapshot may share them.
    ...game.variants ? { variants: { ...game.variants } } : {},
    ...game.obstacles ? { obstacles: game.obstacles.map((obstacle) => ({ ...obstacle, along: { ...obstacle.along } })) } : {}
  };
  bindGangwayCrewRules(snapshot.units, snapshot);
  shareBuildingBodies(game.map, snapshot.map);
  return snapshot;
}
export function restoreSnapshotIntoGame(game, snapshot, nextId) {
  game.equipmentVersion = 1;
  game.rateUnits = "perSecond";
  game.tick = snapshot.tick;
  game.match = cloneSnapshotValue(snapshot.match);
  game.map = cloneSnapshotValue(snapshot.map);
  game.teams = snapshot.teams ? definedTeams(snapshot.teams) : { ...game.teams };
  game.players = cloneSnapshotValue(snapshot.players);
  const colors = assignPlayerColors(Object.keys(game.players), Object.fromEntries(Object.entries(game.players).map(([owner, player]) => [owner, player.color])));
  for (const [owner, player] of Object.entries(game.players)) player.color = colors[owner];
  if (snapshot.teams) game.activePlayers = Object.keys(snapshot.teams).filter((owner) => snapshot.players[owner] !== void 0);
  game.units = cloneSnapshotValue(snapshot.units).map(withUnitShape);
  game.buildings = cloneSnapshotValue(snapshot.buildings);
  game.resources = cloneSnapshotValue(snapshot.resources);
  game.mercenaryCamps = cloneSnapshotValue(snapshot.mercenaryCamps);
  if (snapshot.shops) game.shops = cloneSnapshotValue(snapshot.shops);
  else delete game.shops;
  game.items = cloneSnapshotValue(snapshot.items);
  game.projectiles = cloneSnapshotValue(snapshot.projectiles);
  game.effects = cloneSnapshotValue(snapshot.effects);
  if (snapshot.corpses) game.corpses = cloneSnapshotValue(snapshot.corpses);
  else delete game.corpses;
  if (snapshot.variants) game.variants = cloneSnapshotValue(snapshot.variants);
  else delete game.variants;
  if (snapshot.obstacles) game.obstacles = cloneSnapshotValue(snapshot.obstacles);
  else delete game.obstacles;
  if (!snapshot.rateUnits) migrateSnapshotRates(game);
  for (const building of game.buildings) for (const job of building.queue) if (job.paidGold === void 0) job.paidGold = isShipKind(job.unitKind) ? PREVIOUS_SHIP_TRAIN_COST[job.unitKind] : UNIT_DEFS[job.unitKind].cost;
  migrateShipSizes(game.units);
  restoreCargoDecks(game.units);
  for (const ship of shipsIn(game.units)) if (ship.shipParts) ship.shipParts.cabin ??= shipPartMax(ship).cabin;
  const removedArmor = game.items.some((item) => item.kind === "legGuards" || item.slot === "legs");
  if (removedArmor) {
    for (const item of game.items) {
      if (item.kind === "legGuards") {
        item.kind = "leatherArmor";
        delete item.slot;
      } else if (item.slot === "legs") delete item.slot;
    }
    normalizeEquipment(game);
    refreshEquipmentMass(game);
  }
  if (game.shops) for (const shop of game.shops) shop.goods = shop.goods.filter((good) => good.kind !== "legGuards");
  if (snapshot.equipmentVersion !== 1) {
    initializeShipEquipment(game);
    normalizeEquipment(game, true);
    refreshEquipmentMass(game);
  }
  game.nextId = nextId;
  normalizeEquipment(game);
  keepShipsOnWater(game.map, game.units);
  syncDecks(game.units);
  invalidateGameRuntimeCaches(game);
  refreshVeteranFrame(game);
  bindGangwayCrewRules(game.units, game);
}
function migrateSnapshotRates(game) {
  const migrate = (unit) => {
    unit.speed *= 20;
    if (unit.pushX !== void 0) unit.pushX *= 20;
    if (unit.pushY !== void 0) unit.pushY *= 20;
    unit.cargo?.forEach(migrate);
  };
  game.units.forEach(migrate);
  for (const rules of Object.values(game.variants ?? {})) {
    rules.speed *= 20;
    if (rules.aimSpeed !== void 0) rules.aimSpeed *= 20;
  }
}
function invalidateGameRuntimeCaches(game) {
  invalidateSeparationFrame(game);
  delete game.veteranFrame;
  delete game.veteranAutocastFrame;
  delete game.boardingHolds;
  delete game.unitSpatial;
  delete game.unitSpatialByTeam;
  delete game.shipReachPadding;
  delete game.buildingSpatial;
  delete game.buildingSpatialByTeam;
  delete game.buildingSpatialCount;
  delete game.buildingBodiesSeen;
  delete game.entityById;
}
function cloneSnapshotValue(value) {
  return JSON.parse(JSON.stringify(value));
}
function definedTeams(teams) {
  return Object.fromEntries(Object.entries(teams).filter((entry) => typeof entry[1] === "string"));
}
function updateConstruction(game) {
  for (const building of game.buildings) {
    if (building.complete) continue;
    const builders = constructionWorkers(game, building);
    if (builders.length === 0) continue;
    for (const builder of builders) emitWorkerWork(game, builder, building);
    const before = building.buildProgress;
    building.buildProgress = Math.min(building.buildTime, building.buildProgress + builders.length);
    const gained = (building.buildProgress - before) / Math.max(1, building.buildTime) * (building.maxHp - constructionStartHp(building.maxHp));
    building.hp = Math.min(building.maxHp, building.hp + gained);
    if (building.buildProgress >= building.buildTime) {
      applyDerivedBuildingStats(game, building);
      building.complete = true;
      for (const builder of builders) builder.order = { type: "idle" };
      updateSupplyState(game);
    }
  }
}
function updateTraining(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.queue.length === 0) continue;
    const job = building.queue[0];
    if (!job) continue;
    job.remaining = Math.max(0, job.remaining - 1);
    if (job.remaining > 0) continue;
    const sea = unitMover(job.unitKind) === "sea";
    const launch = sea ? shipLaunchPose(game, building, shipLaunchPrototype(building, job.unitKind)) : void 0;
    const from = sea ? launch : landSpawnPoint(game, building, landSpawnPrototype(building, job.unitKind));
    if (!from) continue;
    const unit = game.spawnUnit(building.owner, job.unitKind, from.x, from.y, launch);
    building.queue.shift();
    unit.order = rallyOrderForUnit(game, building, unit);
  }
}
function updateResearch(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.researchQueue.length === 0) continue;
    const job = building.researchQueue[0];
    if (!job) continue;
    job.remaining -= 1;
    if (job.remaining > 0) continue;
    building.researchQueue.shift();
    completeResearch(game, building.owner, job.upgradeKind, job.targetLevel);
  }
}
function updateTowerAttacks(game) {
  for (const building of game.buildings) {
    if (!building.complete || building.attackDamage <= 0) continue;
    building.cooldown = Math.max(0, building.cooldown - 1);
    if (building.cooldown > 0) continue;
    const target = nearestEnemyTargetFromPoint(game, building.owner, building, building.attackRange);
    if (!target) continue;
    applyWeaponAttack(game, building, target, building.attackDamage, building.attackRange);
    building.cooldown = building.attackCooldown;
  }
}
function updateMoonWellHealing(game) {
  for (const building of game.buildings) {
    if (!building.complete || !isHealingBuildingKind(building.kind)) continue;
    building.cooldown = Math.max(0, building.cooldown - 1);
    if (building.cooldown > 0) continue;
    const target = mostWoundedSoldierNear(game, building);
    if (!target) continue;
    target.hp = Math.min(target.maxHp, target.hp + SUPPORT_BUILDING_HEAL);
    building.cooldown = building.attackCooldown;
    addEffect(game, "heal", target.x, target.y, MOON_WELL_HEAL_EFFECT_DURATION, { fromX: building.x, fromY: building.y, toX: target.x, toY: target.y });
  }
}
function mostWoundedSoldierNear(game, building) {
  let target;
  let targetScore = 0;
  forEachNearbyUnit(game, building, building.attackRange, (unit) => {
    if (!canReceiveHealing(unit, game) || unit.owner !== building.owner || unit.kind === "worker" || unit.hp >= unit.maxHp || distance(unit, building) > building.attackRange) return;
    const score = (unit.maxHp - unit.hp) * 2 + (1 - unit.hp / Math.max(1, unit.maxHp)) * 80;
    if (score <= targetScore) return;
    target = unit;
    targetScore = score;
  });
  return target;
}
function updateDockRepairs(game) {
  if (game.tick % seconds(1)) return;
  for (const ship of game.units) {
    if (!shipProfile(ship) || !unitNeedsRepair(game, ship) || !isPlayerId(ship.owner) || ship.order.type === "attack" || ship.order.type === "attackMove") continue;
    const dock = game.buildings.find((building) => building.owner === ship.owner && building.kind === "shipyard" && building.complete && distance(ship, building) < DOCK_REPAIR.range);
    if (!dock || playerState(game, ship.owner).gold < DOCK_REPAIR.goldPerSecond) continue;
    spendGold(game, ship.owner, DOCK_REPAIR.goldPerSecond);
    repairShipParts(game, ship, DOCK_REPAIR.hpPerSecond);
  }
}
function updateRegeneration(game) {
  for (const unit of game.units) {
    if (unit.hp <= 0 || unit.hp >= unit.maxHp) continue;
    const regenPerSecond = unitRegenPerSecond(game, unit);
    if (regenPerSecond <= 0) continue;
    unit.hp = Math.min(unit.maxHp, unit.hp + regenPerSecond / 20);
  }
}
export function unitRegenPerSecond(game, unit) {
  const veterans = "nextId" in game ? game.veteranFrame : buildVeteranFrame(game);
  const rules = unitRules(game, unit);
  const medicalClasses = NON_MECHANICAL_TARGETS.unitClasses;
  return !medicalClasses || medicalClasses.includes(rules.unitClass ?? UNIT_DEFS[unit.kind].unitClass) ? (rules.regenPerSecond ?? 0) + qualifiedLeadershipRegenPerSecond(game, unit) + (veterans?.get(unit.id)?.regenPerSecond ?? 0) : 0;
}
function veteranNearby(game) {
  return (x, y, radius) => {
    const units = [];
    forEachNearbyUnit(game, { x, y }, radius, (unit) => units.push(unit));
    return units;
  };
}
function refreshVeteranFrameAfterCommandSpawn(game) {
  game.unitSpatial = createSpatialIndex(game.units, 320);
  refreshVeteranFrame(game);
}
function refreshVeteranFrame(game, empty = false) {
  const previous = game.veteranFrame;
  game.veteranFrame = empty ? void 0 : buildVeteranFrame(game, veteranNearby(game));
  if (!previous?.size && !game.veteranFrame?.size) return;
  for (const unit of game.units) {
    if (unit.hp > 0 && (previous?.has(unit.id) || game.veteranFrame?.has(unit.id))) {
      const hp = unit.hp;
      applyDerivedUnitStats(game, unit);
      unit.hp = Math.min(hp, unit.maxHp);
    }
  }
}
function veteranAimSpeed(game, unit) {
  return game.veteranFrame?.get(unit.id)?.aimSpeedMultiplier ?? 1;
}
function applyVeteranAbility(game, caster, ability, automatic) {
  return castVeteranAbility(
    game,
    caster,
    ability.skill,
    automatic,
    (type, x, y, duration, options) => addEffect(game, type, x, y, duration, { ...options, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, toX: x, toY: y }),
    veteranNearby(game),
    game.veteranAutocastFrame
  );
}
export { unitRules };
export function leadershipRegenPerSecond(game, unit) {
  return canReceiveHealing(unit, game) ? qualifiedLeadershipRegenPerSecond(game, unit) : 0;
}
function qualifiedLeadershipRegenPerSecond(game, unit) {
  if (!isPlayerId(unit.owner) || unit.level <= 0) return 0;
  const upgrade = UPGRADE_DEFS.leadership;
  const ownerState = game.players[unit.owner];
  if (!ownerState) throw new Error(`Missing player state for ${unit.owner}`);
  const level = ownerState.upgrades.leadership ?? 0;
  const levelDef = upgrade.levels[level - 1];
  return levelDef?.veteranRegenByStars?.[Math.min(MAX_UPGRADE_LEVEL, unit.level) - 1] ?? 0;
}
function updateMercenaryCamps(game) {
  for (const camp of game.mercenaryCamps) {
    camp.cooldownRemaining = Math.max(0, camp.cooldownRemaining - 1);
  }
}
function aimMountedWeapon(game, ship, item, point, pose = mountedWeaponPose(ship, item)) {
  const def = SHIP_WEAPONS[item.kind];
  const mount = shipMounts(ship).find((mount2) => mount2.id === item.mountId);
  const proxy = { ...ship, x: pose.pivot.x, y: pose.pivot.y, deck: { shipId: ship.id, x: mount.x, y: mount.y }, aim: item.aim };
  const { naval: _hull, ...weaponBase } = unitRules(game, ship);
  const ready = aimAt(proxy, { ...weaponBase, attackDamage: def.damage, attackRange: def.range, aimSpeed: def.aimSpeed, weapon: def.weapon }, point, game.tick, veteranAimSpeed(game, ship));
  if (proxy.aim) item.aim = proxy.aim;
  else delete item.aim;
  if (proxy.facing !== void 0) item.facing = proxy.facing;
  return ready ? proxy : void 0;
}
function friendlyFireBlockers(game, ship) {
  return shipsIn(game.units).filter((other) => other.id !== ship.id && other.hp > 0 && !areEnemyOwners(game, ship.owner, other.owner));
}
function mountedShotClear(ship, blockers) {
  if (!blockers.length) return void 0;
  const poses = /* @__PURE__ */ new Map();
  return (item, point, heading) => {
    let aimed = poses.get(heading);
    if (!aimed) {
      aimed = { ...ship, sailing: { ...ship.sailing, heading } };
      shareShipProfile(ship, aimed);
      poses.set(heading, aimed);
    }
    return mountedFireLaneClear(aimed, item, point, blockers);
  };
}
function updateMountedWeapons(game, starts, defenses) {
  const crossing = game.boardingHolds;
  for (const ship of shipsIn(game.units)) {
    if (ship.hp <= 0 || isStaggered(ship) || isStunned(ship) || !shipProfile(ship) || "avoidCombat" in ship.order && ship.order.avoidCombat) continue;
    const order = ship.order;
    const blockers = friendlyFireBlockers(game, ship);
    const weapons = installedWeapons(game, ship), mounts = shipMounts(ship);
    const acquisitionRange = weapons.reduce((reach, item) => {
      if ((item.durability ?? 1) <= 0) return reach;
      const mount = mounts.find((mount2) => mount2.id === item.mountId);
      const def = SHIP_WEAPONS[item.kind];
      return mount ? Math.max(reach, veteranWeaponRange(ship, def.range) + Math.hypot(mount.x, mount.y)) : reach;
    }, ship.attackRange);
    const intrinsic = unitRules(game, ship).intrinsicAttack;
    const ordered = (order.type === "attack" || order.type === "attackMove") && order.targetId ? findStrikeTarget(game, order.targetId) : void 0;
    const explicit = order.type === "attack" && order.leashX === void 0;
    const requested = defenses.get(ship.id)?.target ?? (ordered && (explicit || isObstacle(ordered) || automaticTargetAllowed(game.units, ship.owner, ordered)) ? ordered : void 0);
    let facingPoint = order.type === "aim" ? order : requested ?? (["attackMove", "idle", "hold"].includes(order.type) ? nearestEnemyTarget(game, ship, acquisitionRange) : void 0);
    if (facingPoint && "owner" in facingPoint && !isObstacle(facingPoint)) facingPoint = navalCombatTarget(game, ship, facingPoint);
    const orientHull = ["idle", "hold", "aim"].includes(order.type) || (order.type === "attack" || order.type === "attackMove") && shipCanTurnForAttack(ship);
    if (!crossing.has(ship.id) && facingPoint && (shipCanTurnForAttack(ship) || strikeGap(ship, facingPoint) <= acquisitionRange) && orientHull) {
      turnShipToward(ship, bestFiringHeading(game, ship, facingPoint, 0, mountedShotClear(ship, blockers)), game.map, game.units, Math.abs(headingDifference(starts.get(ship.id).heading, ship.sailing.heading)));
    }
    for (const item of weapons) {
      if ((item.durability ?? 1) <= 0 || item.cooldownRemaining > 0 || item.mountId === "bow" && !intrinsic && ship.cooldown > 0) continue;
      const def = SHIP_WEAPONS[item.kind], pose = mountedWeaponPose(ship, item);
      const range = veteranWeaponRange(ship, def.range);
      const canShoot = (candidate) => {
        const point2 = mountedTargetPoint(game, ship, item, candidate, pose), gap = distance(pose.pivot, point2);
        return shipGunCanAim(ship, item, point2) && gap <= range && gap >= (def.weapon.minRange ?? 0) && (!blockers.length || mountedFireLaneClear(ship, item, point2, blockers));
      };
      const preferred = requested && !isObstacle(requested) ? navalCombatTarget(game, ship, requested) : requested;
      const target = preferred && areEnemyOwners(game, ship.owner, preferred.owner) && canShoot(preferred) ? preferred : nearestEnemyTargetFromPoint(game, ship.owner, pose.pivot, range, ship, (candidate) => canShoot(candidate) && (!["move", "unload", "follow"].includes(order.type) || candidate.attackDamage > 0));
      const aimTarget = order.type === "aim" && !target ? order : target;
      const point = target ? mountedTargetPoint(game, ship, item, target, pose) : aimTarget && strikePoint(pose.pivot, aimTarget);
      if (!point || !shipGunCanAim(ship, item, point) || distance(pose.pivot, point) > range || def.weapon.minRange && distance(pose.pivot, point) < def.weapon.minRange) continue;
      const proxy = aimMountedWeapon(game, ship, item, point, pose);
      if (!proxy || !target) continue;
      const launchPose = mountedWeaponPose(ship, item);
      if (blockers.length && !shipFireLaneClear(launchPose.muzzle, point, def.weapon, blockers)) continue;
      fireWeapon(game, ship, target, Math.round(def.damage * (nonStarUnitStats(game, ship).attackDamage / Math.max(1, weaponRules(game, ship).attackDamage)) * outgoingDamageMultiplier(game, ship)), def.weapon, range, {}, target.id, { item, pose: launchPose, aimPoint: point });
      markAimShot(proxy);
      item.cooldownRemaining = attackCooldownOf(game, ship, def.cooldown);
      if (item.mountId === "bow" && !intrinsic) ship.cooldown = item.cooldownRemaining;
    }
  }
}
function refreshEquipmentMass(game, units = game.units) {
  for (const unit of units) {
    unit.gearMass = unitItemMass(game, unit);
    if (shipProfile(unit)) unit.holdMass = shipItemMass(game, unit);
  }
}
function updateItems(game) {
  let ringed;
  const unitsById = game.entityById;
  for (const item of game.items) {
    if (item.cooldownRemaining > 0) item.cooldownRemaining = Math.max(0, item.cooldownRemaining - 1);
    const entity = item.carrierId ? unitsById.get(item.carrierId) : void 0;
    const carrier = entity && isUnit(entity) ? entity : void 0;
    if (item.shipId) {
      const ship = unitsById.get(item.shipId);
      if (ship) {
        item.x = ship.x;
        item.y = ship.y;
      }
      continue;
    }
    if (!carrier) continue;
    item.x = carrier.x;
    item.y = carrier.y;
    if (!isInCabin(carrier) && item.kind === "flameCloak" && itemEquipped(game, carrier, item)) applyFlameCloak(game, carrier, item);
    if (canReceiveHealing(carrier, game) && item.kind === "regenRing" && itemEquipped(game, carrier, item) && carrier.hp < carrier.maxHp && !ringed?.has(carrier.id)) {
      carrier.hp = Math.min(carrier.maxHp, carrier.hp + perTick(RING_REGEN_PER_SECOND));
      (ringed ??= /* @__PURE__ */ new Set()).add(carrier.id);
    }
    if (!isInCabin(carrier) && carrier.owner === "neutral" && itemEquipped(game, carrier, item)) activateNeutralItem(game, carrier, item);
  }
}
function updateResources(game) {
  for (const resource of game.resources) {
    resource.harvestCooldownRemaining = Math.max(0, (resource.harvestCooldownRemaining ?? 0) - 1);
  }
}
function updateUnits(game, defenses, navalFrame, emptyVeteranFrame) {
  game.veteranAutocastFrame = emptyVeteranFrame ? void 0 : {};
  const autocastFrame = game.tick % AUTOCAST_EVERY_TICKS === 0;
  const cabinMovementFrame = hasCabinCrewMovementFrame(game);
  let ferry;
  const vessels = navalFrame ? shipsIn(game.units) : void 0;
  const ordered = vessels?.length ? [...vessels, ...game.units.filter((unit) => !isShipKind(unit.kind))] : game.units;
  const count = ordered.length;
  const sourceCount = game.units.length;
  for (let i = 0; i < count; i += 1) {
    const unit = ordered[i];
    const navalUnitFrame = navalFrame || game.units.length !== sourceCount;
    if (unit.sailing?.pursuit && !["attack", "attackMove", "follow"].includes(unit.order.type) && !defenses.has(unit.id)) delete unit.sailing.pursuit;
    if (unit.aim) invalidateMovedAim(unit, weaponRules(game, unit));
    unit.cooldown = Math.max(0, unit.cooldown - 1);
    if (unit.abilityCooldowns) {
      const left = tickedAbilityCooldowns(unit.abilityCooldowns);
      if (left) unit.abilityCooldowns = left;
      else unit.abilityCooldowns = void 0;
    }
    if (navalUnitFrame && isInCabin(unit) || (navalUnitFrame || cabinMovementFrame) && cabinCrewMovedThisTick(game, unit)) continue;
    if (unit.order.type === "enterCabin") {
      if (!isStaggered(unit) && !isStunned(unit)) enterCabinStep(game, unit, statusPace(unit), (other) => isStaggered(other) || isStunned(other) ? 0 : statusPace(other));
      continue;
    }
    if (unit.order.type !== "charge") {
      if (unit.pushX !== void 0 && isStaggered(unit) || unit.effects.length !== 0 && isStunned(unit)) continue;
      if (unit.owner !== "neutral" && unit.order.type === "move") {
        advanceMoveOrder(game, unit, unit.order, navalUnitFrame);
        continue;
      }
      activateQueuedOrder(game, unit);
      if (updateNeutralLeash(game, unit)) continue;
      if (navalUnitFrame && autoRepairDeckShip(game, unit)) continue;
      if (autocastFrame) autocastStep(game, unit);
    }
    switch (unit.order.type) {
      case "charge":
        updateChargeOrder(game, unit);
        continue;
      case "move":
        advanceMoveOrder(game, unit, unit.order, navalUnitFrame);
        continue;
      case "attackMove":
        updateAttackMoveOrder(game, unit, navalUnitFrame);
        continue;
      case "hold":
        updateHoldOrder(game, unit, navalUnitFrame);
        continue;
      case "aim":
        updateAimOrder(game, unit, navalUnitFrame);
        continue;
      case "follow":
        updateFollowOrder(game, unit);
        continue;
      case "cast":
        updateCastOrder(game, unit);
        continue;
      case "attack":
        updateAttackOrder(game, unit, navalUnitFrame);
        continue;
      case "mine":
        updateMineOrder(game, unit);
        continue;
      case "build":
        updateBuildOrder(game, unit);
        continue;
      case "repair":
        updateRepairOrder(game, unit);
        continue;
      case "repairUnit":
      case "repairShip":
        updateUnitRepairOrder(game, unit);
        continue;
      case "pickupItem":
        updatePickupItemOrder(game, unit);
        continue;
      case "board":
        updateBoardOrder(game, unit);
        (ferry ??= { boarding: [], unloading: [] }).boarding.push(unit);
        continue;
      case "boardShip":
        updateBoardShipOrder(game, unit);
        continue;
      case "unload":
        moveToward(unit, unit.order.x, unit.order.y, game.map, game.units, navalUnitFrame);
        (ferry ??= { boarding: [], unloading: [] }).unloading.push(unit);
        continue;
    }
    if (unit.kind === "worker" && !unit.deck && updateAutoRepair(game, unit)) continue;
    if (navalUnitFrame && combatHull(unit) && unit.owner !== "neutral") {
      const defense = defenses.get(unit.id);
      if (defense?.target) {
        const target = navalCombatTarget(game, unit, defense.target);
        navigateShipAttack(game, unit, target);
        if (unitRules(game, unit).intrinsicAttack && unit.cooldown === 0 && targetGap(unit, target) <= unit.attackRange && aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) {
          applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
          markAimShot(unit);
          unit.cooldown = attackCooldownOf(game, unit);
        }
      } else if (defense?.returnTo) moveToward(unit, defense.returnTo.x, defense.returnTo.y, game.map, game.units);
      else updateHoldOrder(game, unit);
      continue;
    }
    if (navalUnitFrame && shipProfile(unit)) continue;
    if (unit.kind !== "worker") {
      const target = nearestEnemyTarget(game, unit, unit.owner === "neutral" ? 150 : AUTO_ACQUIRE_RANGE, navalUnitFrame);
      if (target) unit.order = { type: "attack", targetId: target.id, leashX: unit.x, leashY: unit.y };
    }
  }
  return ferry;
}
function deckPointOrder(game, unit, order) {
  if (unitMover(unit.kind) !== "land") return order;
  const ship = game.units.find((ship2) => shipProfile(ship2) && circleInPolygon(worldToLocal(ship2, order), 0, shipProfile(ship2).hull));
  return ship ? { ...order, deckPoint: worldToLocal(ship, order), deckShipId: ship.id } : order;
}
function deckGoal(unit, ship, goal, units) {
  const order = unit.order;
  if (order.type !== "move" && order.type !== "attackMove" || !order.deckPoint || order.x !== goal.x || order.y !== goal.y) return goal;
  const parent = units.find((unit2) => unit2.id === (order.deckShipId ?? ship?.id));
  return parent ? localToWorld(parent, order.deckPoint) : goal;
}
function advanceMoveOrder(game, unit, order, navalFrame) {
  if (unit.sailing && followQueuedShipCourse(unit, game.map, game.units, statusPace(unit))) return;
  moveToward(unit, order.x, order.y, game.map, game.units, navalFrame);
  if (walkEnded(game, unit, order, MOVE_ORDER_ARRIVAL_RANGE)) arrive(unit, order);
}
function updateShipOwnership(game) {
  let changed = false;
  for (const ship of shipsIn(game.units)) {
    const crew = shipPassengers(game.units, ship).filter((unit) => unit.hp > 0);
    if (!crew.length || crew.some((unit) => !areEnemyOwners(game, ship.owner, unit.owner))) continue;
    const occupants = crew.filter((unit) => isPlayerId(unit.owner)).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const owner = occupants[0]?.owner;
    if (!owner || occupants.some((unit) => areEnemyOwners(game, owner, unit.owner))) continue;
    ship.owner = owner;
    ship.order = { type: "idle" };
    ship.orderQueue = [];
    ship.aim = void 0;
    if (ship.sailing) {
      ship.sailing.speed = 0;
      ship.sailing.route = void 0;
      delete ship.sailing.pursuit;
      cancelShipPlanningJob(ship);
    }
    refreshUnitStats(game, ship);
    changed = true;
  }
  if (changed) updateSupplyState(game);
}
function assignUnitOrder(unit, order, queued = false) {
  if (queued) {
    unit.orderQueue = [...unit.orderQueue ?? [], order];
    return;
  }
  if (unit.order.type === "charge") {
    unit.orderQueue = [order];
    return;
  }
  unit.order = order;
  unit.orderQueue = [];
  if (unit.sailing?.gangway) cancelShipBoarding(unit);
  if (unit.sailing) {
    unit.sailing.route = void 0;
    delete unit.sailing.pursuit;
    cancelShipPlanningJob(unit);
    delete unit.sailing.planningRequestedAtTick;
    delete unit.sailing.planningLastRequestedAtTick;
  }
}
function activateQueuedOrder(game, unit) {
  if (unit.order.type !== "idle") return;
  const next = unit.orderQueue?.shift();
  if (!next) return;
  if (shipProfile(unit)) cancelCrewRendezvous(game.units, /* @__PURE__ */ new Set([unit.id]));
  unit.order = next;
  if (unit.sailing?.gangway) cancelShipBoarding(unit);
  if (unit.sailing) {
    unit.sailing.route = void 0;
    delete unit.sailing.pursuit;
    cancelShipPlanningJob(unit);
    delete unit.sailing.planningRequestedAtTick;
    delete unit.sailing.planningLastRequestedAtTick;
  }
}
function updateFollowOrder(game, unit) {
  if (unit.order.type !== "follow") return;
  const order = unit.order;
  const target = game.units.find((candidate) => candidate.id === order.targetId && !areEnemyOwners(game, candidate.owner, unit.owner));
  if (!target) {
    unit.order = { type: "idle" };
    return;
  }
  if (shipProfile(unit)) {
    const goal = shipPursuitGoal(unit, target, game.units, Math.max(72, shipProfile(unit).length * 0.6 + 20), 0, true);
    const pace = statusPace(unit);
    if (goal && pace > 0) sailToward(unit, goal, game.map, game.units, pace);
    return;
  }
  if (distance(unit, target) > Math.max(72, target.radius + unit.radius + 26)) {
    moveToward(unit, target.x, target.y, game.map, game.units);
  }
}
function updateNeutralLeash(game, unit) {
  if (unit.owner !== "neutral" || unit.homeX === void 0 || unit.homeY === void 0) return false;
  const home = { x: unit.homeX, y: unit.homeY };
  const responseOrigin = neutralResponseOrigin(unit) ?? home;
  const homeDistance = distance(unit, home);
  if (homeDistance <= NEUTRAL_RETURN_STOP_RANGE && unit.order.type === "move" && distance(unit.order, home) <= NEUTRAL_RETURN_STOP_RANGE) {
    unit.order = { type: "idle" };
    return false;
  }
  const target = unit.order.type === "attack" ? findTarget(game, unit.order.targetId) : void 0;
  const returning = unit.order.type === "move" && distance(unit.order, home) <= NEUTRAL_RETURN_STOP_RANGE;
  const lostQuarry = !target && (unit.order.type === "idle" || unit.order.type === "attack");
  if (homeDistance <= NEUTRAL_LEASH_RANGE && !returning && (!lostQuarry || homeDistance <= NEUTRAL_RETURN_STOP_RANGE) && (!target || distance(target, responseOrigin) <= NEUTRAL_DAMAGE_RESPONSE_RANGE)) return false;
  unit.order = { type: "move", x: home.x, y: home.y };
  moveToward(unit, home.x, home.y, game.map, game.units);
  if (distance(unit, home) <= NEUTRAL_RETURN_STOP_RANGE) unit.order = { type: "idle" };
  return true;
}
function updateHoldOrder(game, unit, navalFrame = true) {
  if (navalFrame && shipProfile(unit) && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0 || unit.attackDamage <= 0) return;
  const target = nearestEnemyTarget(game, unit, unit.attackRange, navalFrame);
  if (!target) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function updateAimOrder(game, unit, navalFrame = true) {
  if (unit.order.type !== "aim") return;
  const point = unit.order;
  if (distance(unit, point) > unit.attackRange) {
    unit.aim = void 0;
    moveToward(unit, point.x, point.y, game.map, game.units, navalFrame);
    if (distance(unit, point) > unit.attackRange && walkEnded(game, unit, point, 5)) unit.order = { type: "idle" };
    return;
  }
  if (backOutOfDeadZone(game, unit, point, navalFrame)) {
    unit.aim = void 0;
    return;
  }
  if (nearestEnemyTarget(game, unit, unit.attackRange, navalFrame)) updateHoldOrder(game, unit, navalFrame);
  else aimAt(unit, weaponRules(game, unit), point, game.tick, veteranAimSpeed(game, unit));
}
function updateAttackMoveOrder(game, unit, navalFrame = true) {
  if (unit.order.type !== "attackMove") return;
  const order = unit.order;
  if (order.targetId) {
    const target2 = findTarget(game, order.targetId);
    if (!navalFrame && target2 && isUnit(target2) && (target2.deck || target2.cabin || isShipKind(target2.kind))) navalFrame = true;
    if (target2 && target2.hp > 0 && (!navalFrame || automaticTargetAllowed(game.units, unit.owner, target2)) && projectedHpAfterPendingProjectiles(game, unit.owner, target2) > 0 && areEnemyOwners(game, unit.owner, target2.owner) && (!navalFrame && !game.map.terrain || canReach(game.map, unit, target2, game.units))) {
      const chosen = automaticCombatTarget(game, unit, target2, navalFrame);
      if (chosen.id !== order.targetId) unit.order = { ...order, targetId: chosen.id };
      attackMoveTowardTarget(game, unit, chosen, navalFrame);
      return;
    }
    const { targetId: _lost, ...destination } = order;
    unit.order = destination;
  }
  const profile = navalFrame ? shipProfile(unit) : void 0;
  const acquisition = profile ? Math.max(unit.attackRange, Math.min(700, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange + profile.length * 0.4 + 100))) : unitRules(game, unit).weapon ? Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange) : AUTO_ACQUIRE_RANGE;
  const target = nearestEnemyTarget(game, unit, acquisition, navalFrame);
  if (target) {
    unit.order = { ...order, targetId: target.id };
    attackMoveTowardTarget(game, unit, target, navalFrame);
    return;
  }
  if (unit.sailing) delete unit.sailing.pursuit;
  moveToward(unit, order.x, order.y, game.map, game.units, navalFrame);
  if (walkEnded(game, unit, order, 8)) arrive(unit, order);
}
function attackMoveTowardTarget(game, unit, target, navalFrame = true) {
  if (navalFrame) target = navalCombatTarget(game, unit, target);
  const gap = targetGap(unit, target, navalFrame);
  const ship = navalFrame && Boolean(shipProfile(unit));
  if (ship) navigateShipAttack(game, unit, target);
  else if (backOutOfDeadZone(game, unit, target, false)) return;
  if (gap > unit.attackRange) {
    if (!ship) moveToward(unit, target.x, target.y, game.map, game.units, navalFrame);
    return;
  }
  if (ship && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function updateAttackOrder(game, unit, navalFrame = true) {
  const order = unit.order;
  if (order.type !== "attack") return;
  let target = findStrikeTarget(game, order.targetId);
  if (!target) {
    unit.order = { type: "idle" };
    return;
  }
  if (!navalFrame && isUnit(target) && (target.deck || target.cabin || isShipKind(target.kind))) navalFrame = true;
  if (navalFrame && !isObstacle(target)) target = navalCombatTarget(game, unit, target);
  if (projectedHpAfterPendingProjectiles(game, unit.owner, target) <= 0 || (navalFrame || game.map.terrain) && !canReach(game.map, unit, target, game.units)) {
    const replacement = nearestEnemyTarget(game, unit, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange), navalFrame);
    if (!replacement) {
      unit.order = { type: "idle" };
      return;
    }
    unit.order = { ...order, targetId: replacement.id };
    updateAttackOrder(game, unit, navalFrame);
    return;
  }
  if (!isObstacle(target) && (unit.owner === "neutral" || order.leashX !== void 0)) {
    if (navalFrame && !automaticTargetAllowed(game.units, unit.owner, target)) {
      unit.order = { type: "idle" };
      return;
    }
    target = automaticCombatTarget(game, unit, target, navalFrame);
    if (target.id !== order.targetId) unit.order = { ...order, targetId: target.id };
  }
  const gap = targetGap(unit, target, navalFrame);
  const ship = navalFrame && Boolean(shipProfile(unit));
  if (!ship && backOutOfDeadZone(game, unit, target, false)) return;
  if (gap > unit.attackRange) {
    if (isPlayerId(unit.owner) && order.leashX !== void 0 && order.leashY !== void 0 && distance(unit, { x: order.leashX, y: order.leashY }) > GUARD_LEASH_RANGE) {
      unit.order = { type: "move", x: order.leashX, y: order.leashY };
      return;
    }
    if (ship) navigateShipAttack(game, unit, target);
    else moveToward(unit, target.x, target.y, game.map, game.units, navalFrame);
    return;
  }
  if (ship) navigateShipAttack(game, unit, target);
  if (ship && !unitRules(game, unit).intrinsicAttack) return;
  if (unit.cooldown > 0) return;
  if (!aimAt(unit, weaponRules(game, unit), strikePoint(unit, target), game.tick, veteranAimSpeed(game, unit))) return;
  applyWeaponAttack(game, unit, target, Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit))), unit.attackRange);
  markAimShot(unit);
  unit.cooldown = attackCooldownOf(game, unit);
}
function navigateShipAttack(game, ship, target) {
  if (game.boardingHolds?.has(ship.id)) return;
  const weapons = installedWeapons(game, ship).filter((item) => (item.durability ?? 1) > 0);
  const minimum = weapons.length ? Math.min(...weapons.map((item) => SHIP_WEAPONS[item.kind].weapon.minRange ?? 0)) : weaponRules(game, ship).weapon?.minRange ?? 0;
  const blockers = friendlyFireBlockers(game, ship);
  let firingHeading;
  const canFireFrom = (station, checkTurn) => {
    if (!weapons.length) return targetGap(station, target) <= station.attackRange && targetGap(station, target) >= minimum;
    shareShipProfile(ship, station);
    const start = { x: station.x, y: station.y, heading: station.sailing.heading };
    const shotClear = mountedShotClear(station, blockers);
    for (const margin of [Math.PI / 36, 0]) {
      const heading = bestFiringHeading(game, station, target, margin, shotClear), aimed = { ...station, sailing: { ...station.sailing, heading } }, end = { ...start, heading };
      shareShipProfile(ship, aimed);
      if (checkTurn && (!hullPassageClear(game.map, station, start, end) || !shipTraffic(station, game.units)(start, end))) continue;
      if (weapons.some((item) => {
        const pose = mountedWeaponPose(aimed, item), def = SHIP_WEAPONS[item.kind];
        if (!pose) return false;
        const point = mountedTargetPoint(game, aimed, item, target, pose);
        if (!shipGunCanAim(aimed, item, point)) return false;
        const gap = distance(pose.pivot, point);
        return gap <= veteranWeaponRange(station, def.range) && gap >= (def.weapon.minRange ?? 0) && (!blockers.length || mountedFireLaneClear(aimed, item, point, blockers));
      })) {
        if (checkTurn) firingHeading = heading;
        return true;
      }
    }
    return false;
  };
  const firing = canFireFrom(ship, true);
  const bow = weapons.find((item) => item.mountId === "bow" && veteranWeaponRange(ship, SHIP_WEAPONS[item.kind].range) >= ship.attackRange);
  const bowPose = bow && mountedWeaponPose(ship, bow);
  const stationBowReach = bowPose ? (bowPose.pivot.x - ship.x) * detCos(ship.sailing.heading) + (bowPose.pivot.y - ship.y) * detSin(ship.sailing.heading) : 0;
  const goal = shipPursuitGoal(ship, target, game.units, ship.attackRange, minimum, false, () => firing, game.map, firingHeading, stationBowReach, (station) => canFireFrom(station, false), () => tryAdmitShipPlan(ship));
  const pace = statusPace(ship);
  if (goal && pace > 0) sailToward(ship, goal, game.map, game.units, pace);
  else if (!goal && ship.sailing.planningRequestedAtTick !== void 0 && !ship.sailing.route) {
    ship.sailing.speed = 0;
    if (pace > 0) {
      const quarry = shipNavigationTarget(target, game.units);
      turnShipToward(ship, Math.atan2(quarry.y - ship.y, quarry.x - ship.x), game.map, game.units);
    }
  }
}
function updateMineOrder(game, unit) {
  if (unit.order.type !== "mine") return;
  const order = unit.order;
  const resource = game.miningFrame.resources.get(order.resourceId);
  if ((!resource || resource.amount <= 0) && order.phase !== "return") {
    unit.order = { type: "idle" };
    return;
  }
  if (order.phase === "toMine") {
    if (distance(unit, resource) > MINE_RANGE) {
      moveToward(unit, resource.x, resource.y, game.map, game.units);
      return;
    }
    order.timer += 1;
    if ((resource.harvestCooldownRemaining ?? 0) > 0) return;
    if (game.miningFrame.nextWorker.get(order.resourceId) !== unit.id) return;
    unit.mineSlot = order.resourceId;
    resource.harvestCooldownRemaining = GOLD_MINE_ENTRY_COOLDOWN;
    unit.order = { ...order, phase: "gather", timer: GATHER_DURATION };
    return;
  }
  if (order.phase === "gather") {
    order.timer -= 1;
    if (order.timer > 0) return;
    const mined = Math.min(GOLD_PER_TRIP, resource.amount);
    resource.amount -= mined;
    unit.carryingGold = mined;
    unit.order = { ...order, phase: "return", timer: 0 };
    return;
  }
  const townHall = nearestCompleteTownHall(game, unit.owner, unit.x, unit.y);
  if (!townHall) {
    unit.order = { type: "idle" };
    return;
  }
  if (distance(unit, townHall) > TOWN_HALL_DROP_RANGE) {
    moveToward(unit, townHall.x, townHall.y, game.map, game.units);
    return;
  }
  if (isPlayerId(unit.owner)) {
    const player = playerState(game, unit.owner);
    player.gold = addGold(player.gold, upkeepGoldIncome(unit.carryingGold, player.supplyUsed));
  }
  unit.carryingGold = 0;
  unit.order = resource && resource.amount > 0 ? { type: "mine", resourceId: resource.id, phase: "toMine", timer: 0 } : { type: "idle" };
}
function updateBoardShipOrder(game, ship) {
  if (ship.order.type !== "boardShip") return;
  const order = ship.order;
  const target = game.units.find((unit) => unit.id === order.targetId && unit.hp > 0);
  if (!target || !shipProfile(ship) || !ship.sailing) {
    cancelShipBoarding(ship);
    ship.order = { type: "idle" };
    return;
  }
  if (!ship.sailing.gangway && !beginShipBoarding(game.map, game.units, ship, target, game.tick, game)) {
    ship.order = { type: "idle" };
    return;
  }
  const state = ship.sailing.gangway;
  if (state.phase === "approach") {
    const goal = shipBoardingGoal(game.map, game.units, ship, target);
    if (goal) sailToward(ship, goal, game.map, game.units, statusPace(ship));
    return;
  }
  ship.sailing.speed = 0;
  ship.sailing.yawRate = 0;
  if (state.phase !== "ready") return;
  if (areEnemyOwners(game, ship.owner, target.owner)) for (const crew of shipPassengers(game.units, ship)) {
    const crewOrder = crew.order;
    const automaticTarget = crewOrder.type === "attack" && crewOrder.leashX !== void 0 ? game.units.find((unit) => unit.id === crewOrder.targetId) : void 0;
    const automaticAttack = crewOrder.type === "attack" && crewOrder.leashX !== void 0 && (crewOrder.targetId === target.id || automaticTarget?.deck?.shipId === target.id);
    if (crew.owner !== ship.owner || crew.kind === "worker" || !gangwayCrewEligible(crew, game) || unitRules(game, crew).attackRange > RANGED_ATTACK_RANGE_THRESHOLD || crew.attackDamage <= 0 || !["idle", "hold"].includes(crew.order.type) && !automaticAttack || crew.orderQueue?.length) continue;
    assignUnitOrder(crew, { type: "board", transportId: target.id });
  }
  ship.order = { type: "idle" };
}
function updateBoardOrder(game, unit) {
  if (unit.order.type !== "board") return;
  const transport = findTarget(game, unit.order.transportId);
  if (!transport || !isUnit(transport) || transport.hp <= 0 || !unit.deck && transport.owner !== unit.owner) {
    unit.order = { type: "idle" };
    return;
  }
  if (unit.deck) {
    const source = game.units.find((ship) => ship.id === unit.deck.shipId);
    if (!source) return;
    if (source.id !== transport.id && !decksCanTransfer(source, transport, unit)) return;
    if (unit.kind !== "worker" && areEnemyOwners(game, unit.owner, transport.owner) && unit.attackDamage > 0 && unitRules(game, unit).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD) {
      const nearby = navalCombatTarget(game, unit, transport, unit.attackRange);
      const defender = nearby !== transport ? nearby : navalCombatTarget(game, unit, transport);
      if (defender !== transport && isUnit(defender)) {
        const boardingOrder = unit.order;
        unit.order = { type: "attack", targetId: defender.id };
        try {
          updateAttackOrder(game, unit);
        } finally {
          unit.order = boardingOrder;
        }
        return;
      }
    }
    if (source.id !== transport.id && !canBoard(transport, unit, game.units)) {
      unit.order = { type: "idle" };
      addEffect(game, "boardingBlocked", unit.x, unit.y, seconds(0.4), { unitId: unit.id, owner: unit.owner, sourceKind: unit.kind });
      return;
    }
    const ahead = game.units.some((other) => other !== unit && other.hp > 0 && other.deck && other.order.type === "board" && other.order.transportId === transport.id && (other.radius > unit.radius || other.radius === unit.radius && other.id < unit.id));
    if (ahead && source.id !== transport.id) {
      const profile = shipProfile(source), entry = worldToLocal(source, transport);
      const waiting = deckPlacement(source, unit, game.units, { x: profile.length / 4, y: -Math.sign(entry.y) * profile.beam / 2 });
      if (waiting) {
        const at = localToWorld(source, waiting);
        moveToward(unit, at.x, at.y, game.map, game.units);
      }
      return;
    }
    if (unit.order.deckPoint && !deckPointFits(transport, unit, unit.order.deckPoint, game.units, true)) delete unit.order.deckPoint;
    if (!unit.order.deckPoint) {
      const reserved = game.units.map((other) => other !== unit && other.order.type === "board" && other.order.transportId === transport.id && other.order.deckPoint ? { ...other, deck: { shipId: transport.id, ...other.order.deckPoint } } : other);
      const entry = worldToLocal(transport, source), profile = shipProfile(transport);
      const reach = Math.hypot(entry.x, entry.y) || 1;
      const preferred = { x: profile.length / 2, y: -entry.y / reach * profile.beam / 2 };
      const point2 = deckPlacement(transport, unit, reserved, preferred, true);
      if (point2) unit.order.deckPoint = point2;
    }
    const point = unit.order.deckPoint;
    if (!point) return;
    const goal2 = localToWorld(transport, point);
    if (source.id === transport.id) {
      moveToward(unit, goal2.x, goal2.y, game.map, game.units);
      if (distance(unit, goal2) < 1e-6) unit.order = { type: "idle" };
    } else if (decksCanTransfer(source, transport, unit)) moveToward(unit, goal2.x, goal2.y, game.map, game.units);
    return;
  }
  if (alongside(unit, transport)) return;
  const goal = transport.order.type === "idle" ? unit.order.berth?.shore ?? unit.order.berth ?? transport : transport;
  moveToward(unit, goal.x, goal.y, game.map, game.units);
}
function ferryUnits(game, { boarding, unloading }, starts) {
  const approached = /* @__PURE__ */ new Set();
  for (const passenger of boarding) {
    if (passenger.order.type !== "board" || passenger.deck || approached.has(passenger.order.transportId)) continue;
    const boat = findTarget(game, passenger.order.transportId);
    if (!boat || !isUnit(boat) || boat.order.type !== "idle") continue;
    approached.add(boat.id);
    const berth = passenger.order.berth ?? boardingBerth(game.map, passenger, boat);
    if (berth && !alongside(passenger, boat)) sailToward(boat, berth, game.map, game.units);
  }
  for (const passenger of boarding) {
    if (passenger.order.type !== "board" || passenger.deck) continue;
    const ship = findTarget(game, passenger.order.transportId);
    if (!ship || !isUnit(ship) || !alongside(passenger, ship)) continue;
    const boarded = boardUnit(ship, passenger, game.units);
    assignUnitOrder(passenger, { type: "idle" });
    addEffect(game, boarded ? "board" : "boardingBlocked", passenger.x, passenger.y, seconds(0.4), { unitId: passenger.id, owner: passenger.owner, sourceKind: passenger.kind });
  }
  for (const ship of unloading) {
    if (ship.order.type !== "unload" || (ship.sailing?.speed ?? 0) > 0.1) continue;
    const start = starts.get(ship.id);
    if (start && (distance(ship, start) > 1e-6 || Math.abs(headingDifference(start.heading, ship.sailing.heading)) > 1e-6)) continue;
    const arrived = walkEnded(game, ship, ship.order, 8);
    const planning = ship.sailing?.planningJob !== void 0 || ship.sailing?.planningRequestedAtTick !== void 0;
    if (unloadCargo(game, ship) > 0 || arrived || !planning && shipPassengers(game.units, ship).length === 0) ship.order = { type: "idle" };
  }
}
function unloadCargo(game, ship, passengerId) {
  if (ship.cargo) restoreCargoDecks(game.units);
  const crew = shipPassengers(game.units, ship);
  let landed = 0;
  crew.forEach((passenger, index) => {
    if (isInCabin(passenger) || passenger.owner !== ship.owner || passengerId !== void 0 && passenger.id !== passengerId) return;
    const spot = landingSpot(game.map, ship, index, crew.length, game.units, passenger);
    if (!spot) return;
    passenger.deck = void 0;
    passenger.cabin = void 0;
    passenger.aim = void 0;
    Object.assign(passenger, spot);
    assignUnitOrder(passenger, { type: "idle" });
    addEffect(game, "unload", spot.x, spot.y, seconds(0.4), { unitId: passenger.id, owner: passenger.owner, sourceKind: passenger.kind });
    landed++;
  });
  syncDecks(game.units);
  updateSupplyState(game);
  return landed;
}
function cargoSupply(game, ship) {
  return (ship.cargo ?? []).reduce((sum, passenger) => sum + unitRules(game, passenger).supplyUsed, 0);
}
function updateBuildOrder(game, unit) {
  if (unit.order.type !== "build" || !isPlayerId(unit.owner)) return;
  const order = unit.order;
  const def = BUILDING_DEFS[order.buildingKind];
  const half = footprintHalf(def.radius, TERRAIN_CELL);
  const gap = Math.hypot(Math.max(0, Math.abs(unit.x - order.x) - half), Math.max(0, Math.abs(unit.y - order.y) - half));
  if (gap > BUILDING_WORK_REACH) {
    if (order.progressTick === void 0 || Math.hypot(unit.x - (order.progressX ?? unit.x), unit.y - (order.progressY ?? unit.y)) > 24) {
      order.progressTick = game.tick;
      order.progressX = unit.x;
      order.progressY = unit.y;
    } else if (game.tick - order.progressTick > seconds(20)) {
      unit.order = { type: "idle" };
      return;
    }
    moveToward(unit, order.x, order.y, game.map, game.units);
    return;
  }
  if (buildingPlacementBlocker(game, order.buildingKind, order) || terrainBlocksPlacement(game.map, order.buildingKind, order)) {
    unit.order = { type: "idle" };
    return;
  }
  if (playerState(game, unit.owner).gold < def.cost) return;
  spendGold(game, unit.owner, def.cost);
  const building = createBuilding(`building-${unit.owner}-${order.buildingKind}-${game.nextId++}`, unit.owner, order.buildingKind, order.x, order.y, false);
  applyDerivedBuildingStats(game, building);
  building.hp = constructionStartHp(building.maxHp);
  game.buildings.push(building);
  syncBuildingBodies(game);
  unit.order = { type: "repair", buildingId: building.id };
  addEffect(game, "build", building.x, building.y, 60);
}
function updateRepairOrder(game, unit) {
  if (unit.order.type !== "repair" || !isPlayerId(unit.owner)) return;
  const order = unit.order;
  const building = game.buildings.find((candidate) => candidate.id === order.buildingId && candidate.owner === unit.owner);
  if (!building || building.hp <= 0 || building.complete && building.hp >= building.maxHp) {
    unit.order = { type: "idle" };
    return;
  }
  if (buildingWorkGap(unit, building) > BUILDING_WORK_REACH) {
    moveToward(unit, building.x, building.y, game.map, game.units);
    return;
  }
  if (!building.complete || unit.cooldown > 0) return;
  if (!repairBuildingTick(game, unit, building)) unit.order = { type: "idle" };
}
function updateAutoRepair(game, unit) {
  if (unit.order.type !== "idle" || !isPlayerId(unit.owner)) return false;
  if (unit.cooldown > 0) return false;
  const building = game.buildings.find(
    (candidate) => candidate.owner === unit.owner && candidate.complete && candidate.hp > 0 && candidate.hp < candidate.maxHp && buildingWorkGap(unit, candidate) <= BUILDING_WORK_REACH
  );
  if (!building) return false;
  return repairBuildingTick(game, unit, building);
}
function updateUnitRepairOrder(game, worker) {
  if (worker.order.type !== "repairUnit" && worker.order.type !== "repairShip") return;
  if (worker.kind !== "worker" || !isPlayerId(worker.owner)) {
    worker.order = { type: "idle" };
    return;
  }
  const targetId = worker.order.targetId;
  const target = game.units.find((unit) => unit.id === targetId && unit.owner === worker.owner && (worker.order.type !== "repairShip" || unitMover(unit.kind) === "sea"));
  if (!target || !unitNeedsRepair(game, target)) {
    worker.order = { type: "idle" };
    return;
  }
  const ship = Boolean(shipProfile(target));
  const sameWorkSurface = ship ? worker.deck?.shipId === target.id : worker.deck?.shipId === target.deck?.shipId;
  const withinReach = distance(worker, target) <= worker.radius + target.radius + BUILDING_WORK_REACH;
  const canWorkHere = ship ? sameWorkSurface || !worker.deck && withinReach : sameWorkSurface && withinReach;
  if (!canWorkHere) {
    moveToward(worker, target.x, target.y, game.map, game.units);
    return;
  }
  repairUnitTick(game, worker, target);
  if (!unitNeedsRepair(game, target)) worker.order = { type: "idle" };
}
function autoRepairDeckShip(game, worker) {
  if (worker.kind !== "worker" || !worker.deck || !isPlayerId(worker.owner) || worker.orderQueue?.length || !["idle", "hold"].includes(worker.order.type)) return false;
  const ship = game.units.find((unit) => unit.id === worker.deck.shipId && unit.owner === worker.owner && unit.hp > 0);
  if (!ship || !shipProfile(ship) || !unitNeedsRepair(game, ship) || playerState(game, worker.owner).gold < 1) return false;
  repairUnitTick(game, worker, ship);
  return true;
}
function repairUnitTick(game, worker, target) {
  if (worker.kind !== "worker" || !isPlayerId(worker.owner) || target.owner !== worker.owner || !unitNeedsRepair(game, target)) return;
  if (worker.cooldown > 0) return;
  const player = playerState(game, worker.owner);
  if (player.gold < 1) return;
  emitWorkerWork(game, worker, target);
  const healed = unitRepairHpPerGold(game, target);
  spendGold(game, worker.owner, 1);
  if (shipProfile(target)) repairShipParts(game, target, healed);
  else target.hp = Math.min(target.maxHp, target.hp + healed);
  worker.cooldown = seconds(healed / REPAIR_HP_PER_SECOND);
}
function emitWorkerWork(game, worker, target) {
  if (game.effects.some((effect) => effect.type === "repair" && effect.unitId === worker.id)) return;
  game.effects.push({
    id: `work-${worker.id}-${game.tick}`,
    type: "repair",
    x: worker.x,
    y: worker.y,
    duration: seconds(0.65),
    remaining: seconds(0.65),
    unitId: worker.id,
    fromX: target.x,
    fromY: target.y
  });
}
function repairBuildingTick(game, unit, building) {
  if (!isPlayerId(unit.owner)) return false;
  const owner = unit.owner;
  const player = playerState(game, owner);
  if (player.gold < 1 || building.hp >= building.maxHp) return false;
  const fullRepairCost = Math.max(1, Math.round(BUILDING_DEFS[building.kind].cost * REPAIR_FULL_COST_FRACTION));
  const hpPerGold = Math.max(1, building.maxHp / fullRepairCost);
  spendGold(game, owner, 1);
  building.hp = Math.min(building.maxHp, building.hp + hpPerGold);
  unit.cooldown = seconds(hpPerGold / REPAIR_HP_PER_SECOND);
  emitWorkerWork(game, unit, building);
  addRepairHammerEffect(game, building);
  return true;
}
function addRepairHammerEffect(game, building, queued = false) {
  const activeType = queued ? ["repair", "queuedRepair"] : ["repair"];
  if (game.effects.some((effect) => activeType.includes(effect.type) && effect.x === building.x && effect.y === building.y)) return;
  addEffect(game, queued ? "queuedRepair" : "repair", building.x, building.y, REPAIR_HAMMER_EFFECT_DURATION, { owner: building.owner });
}
function queueTraining(game, building, unitKind) {
  if (!building.complete) throw new Error(`Cannot train from incomplete ${building.kind}`);
  if (!canTrainAt(playerState(game, building.owner).race, building.kind, unitKind)) throw new Error(`${building.kind} cannot train ${unitKind} for ${playerState(game, building.owner).race}`);
  const cap = requiredSupplyCap(unitKind);
  if (playerState(game, building.owner).supplyCap < cap) throw new Error(`Need a supply cap of ${cap} to train ${unitKind}`);
  if (projectedSupplyUsed(game, building.owner) + UNIT_DEFS[unitKind].supplyUsed > playerState(game, building.owner).supplyCap) {
    throw new Error(`Need more supply to train ${unitKind}`);
  }
  spendGold(game, building.owner, UNIT_DEFS[unitKind].cost);
  building.queue.push({ id: `training-${game.nextId++}`, unitKind, remaining: trainTimeFor(unitKind), paidGold: UNIT_DEFS[unitKind].cost });
  updateSupplyState(game);
}
function setRally(game, owner, buildingIds, x, y, target) {
  const buildings = buildingsByIds(game, buildingIds, owner);
  const normalized = normalizeRallyTarget(game, owner, x, y, target);
  for (const building of buildings) {
    if (BUILDING_DEFS[building.kind].trains.length === 0) throw new Error(`${building.kind} has no training rally point`);
    building.rallyX = normalized.x;
    building.rallyY = normalized.y;
    building.rallyTarget = normalized.target;
  }
  addEffect(game, "move", normalized.x, normalized.y, 24, { owner });
}
function normalizeRallyTarget(game, owner, x, y, target) {
  if (!target || target.type === "point") {
    return { x: clamp(x, 0, game.map.width), y: clamp(y, 0, game.map.height), target: { type: "point" } };
  }
  if (target.type === "resource") {
    const resource = game.resources.find((candidate) => candidate.id === target.resourceId);
    if (!resource) throw new Error(`Unknown rally resource ${target.resourceId}`);
    return { x: resource.x, y: resource.y, target };
  }
  const unit = game.units.find((candidate) => candidate.id === target.unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} rally unit ${target.unitId}`);
  return { x: unit.x, y: unit.y, target };
}
function rallyOrderForUnit(game, building, unit) {
  const target = building.rallyTarget;
  if (target?.type === "resource" && unit.kind === "worker" && game.resources.some((resource) => resource.id === target.resourceId && resource.amount > 0)) {
    return { type: "mine", resourceId: target.resourceId, phase: "toMine", timer: 0 };
  }
  if (target?.type === "unit" && game.units.some((candidate) => candidate.id === target.unitId && candidate.owner === unit.owner && candidate.hp > 0)) {
    return { type: "follow", targetId: target.unitId };
  }
  return { type: "move", x: building.rallyX, y: building.rallyY };
}
function queueResearch(game, building, upgradeKind) {
  if (!building.complete) throw new Error(`Cannot research from incomplete ${building.kind}`);
  const upgrade = UPGRADE_DEFS[upgradeKind];
  if (!upgrade) throw new Error(`Unknown upgrade ${upgradeKind}`);
  if (!RACE_DEFS[playerState(game, building.owner).race].upgrades.includes(upgradeKind)) throw new Error(`${playerState(game, building.owner).race} race cannot research ${upgradeKind}`);
  if (!canResearchAt(playerState(game, building.owner).race, building.kind, upgradeKind)) {
    throw new Error(`${building.kind} cannot research ${upgradeKind}`);
  }
  const player = playerState(game, building.owner);
  const currentLevel = player.upgrades[upgradeKind] ?? 0;
  if (currentLevel >= maxUpgradeLevel(upgradeKind)) throw new Error(`${upgradeKind} already at max level`);
  if (building.researchQueue.some((job) => job.upgradeKind === upgradeKind)) throw new Error(`${upgradeKind} is already queued`);
  const targetLevel = currentLevel + 1;
  const level = upgrade.levels[targetLevel - 1];
  if (!level) throw new Error(`${upgradeKind} missing level ${targetLevel}`);
  spendGold(game, building.owner, level.cost);
  building.researchQueue.push({ upgradeKind, targetLevel, remaining: level.researchTime });
}
function completeResearch(game, owner, upgradeKind, targetLevel) {
  const player = playerState(game, owner);
  const currentLevel = player.upgrades[upgradeKind] ?? 0;
  if (targetLevel <= currentLevel) return;
  if (targetLevel !== currentLevel + 1) throw new Error(`${upgradeKind} research completed out of order`);
  player.upgrades[upgradeKind] = targetLevel;
  for (const unit of game.units.filter((candidate) => candidate.owner === owner)) {
    applyUpgradeLevelToUnit(game, unit, upgradeKind, targetLevel);
  }
  for (const building of game.buildings.filter((candidate) => candidate.owner === owner)) {
    applyUpgradeLevelToBuilding(game, building, upgradeKind, targetLevel);
  }
}
function applyUnitUpgrades(game, unit) {
  if (!isPlayerId(unit.owner)) return;
  applyDerivedUnitStats(game, unit);
}
function applyUpgradeLevelToUnit(game, unit, upgradeKind, level) {
  const upgrade = UPGRADE_DEFS[upgradeKind];
  const levelDef = upgrade.levels[level - 1];
  if (!levelDef) throw new Error(`${upgradeKind} missing level ${level}`);
  if (!upgrade.affectedUnitKinds.includes(unit.kind)) return;
  applyDerivedUnitStats(game, unit);
}
function applyUpgradeLevelToBuilding(game, building, upgradeKind, level) {
  const upgrade = UPGRADE_DEFS[upgradeKind];
  const levelDef = upgrade.levels[level - 1];
  if (!levelDef) throw new Error(`${upgradeKind} missing level ${level}`);
  if (!levelDef.buildingMaxHpMultiplier) return;
  applyDerivedBuildingStats(game, building);
}
function applyDerivedBuildingStats(game, building) {
  const previousMaxHp = building.maxHp;
  const def = BUILDING_DEFS[building.kind];
  let maxHp = def.hp;
  for (const upgradeKind of UPGRADE_KINDS) {
    const upgradeLevel = playerState(game, building.owner).upgrades[upgradeKind] ?? 0;
    for (let level = 0; level < upgradeLevel; level += 1) {
      const levelDef = UPGRADE_DEFS[upgradeKind].levels[level];
      if (!levelDef?.buildingMaxHpMultiplier) continue;
      maxHp = Math.round(maxHp * levelDef.buildingMaxHpMultiplier);
    }
  }
  building.maxHp = maxHp;
  building.hp = Math.min(building.maxHp, Math.max(1, building.hp + building.maxHp - previousMaxHp));
  building.attackDamage = def.attackDamage;
  building.attackRange = def.attackRange;
  building.attackCooldown = def.attackCooldown;
}
function hireMercenary(game, owner, campId) {
  const camp = game.mercenaryCamps.find((candidate) => candidate.id === campId);
  if (!camp) throw new Error(`Unknown mercenary camp ${campId}`);
  if (camp.stock <= 0) throw new Error(`${camp.id} has no mercenary stock`);
  if (camp.cooldownRemaining > 0) throw new Error(`${camp.id} is restocking`);
  if (!hasFriendlyUnitAtMercenaryCamp(game, owner, camp)) throw new Error(`${camp.id} needs a friendly unit nearby before hiring`);
  if (!canSupply(game, owner, camp.hireKind)) throw new Error(`Need more supply to hire ${camp.hireKind}`);
  spendGold(game, owner, camp.cost);
  camp.stock -= 1;
  camp.cooldownRemaining = camp.cooldown;
  const offset = owner === "player" ? -camp.radius : camp.radius;
  const mercenary = game.spawnUnit(owner, camp.hireKind, camp.x + offset, camp.y);
  addEffect(game, "summon", camp.x, camp.y, 34);
  updateSupplyState(game);
  return mercenary;
}
function buyGood(game, owner, shopId, kind, recipientId) {
  const refusal = buyRefusal(game, owner, shopId, kind, recipientId);
  if (refusal) throw new Error(refusal.message);
  const shop = game.shops.find((candidate) => candidate.id === shopId);
  const good = shop.goods.find((candidate) => candidate.kind === kind);
  const delivery = recipientId !== void 0 ? purchasePlacement(game, owner, shop, kind, recipientId) : void 0;
  if (delivery && "refusal" in delivery) throw new Error(delivery.refusal);
  spendGold(game, owner, good.cost);
  good.stock -= 1;
  if (good.restockRemaining <= 0) good.restockRemaining = good.restock;
  const item = { id: `item-${owner}-${kind}-${game.nextId}`, kind, x: shop.x, y: shop.y + shop.radius + 16, cooldownRemaining: 0 };
  game.nextId += 1;
  game.items.push(item);
  if (delivery && "placement" in delivery) deliverPurchase(game, item, delivery.placement);
  else {
    const buyer = shopBuyer(game, owner, shop, kind);
    if (buyer) attachItemToUnit(game, item, buyer);
    addEffect(game, "summon", shop.x, shop.y, 24);
  }
  return item;
}
function deliverPurchase(game, item, placement) {
  const recipient = game.units.find((unit) => unit.id === ("unitId" in placement ? placement.unitId : placement.shipId));
  if ("unitId" in placement) {
    item.carrierId = recipient.id;
    item.slot = placement.slot;
  } else {
    item.shipId = recipient.id;
    item.holdSlot = placement.slot;
  }
  item.x = recipient.x;
  item.y = recipient.y;
  invalidateItemIndex(game.items);
  applyDerivedUnitStats(game, recipient);
  refreshEquipmentMass(game);
  addEffect(game, "itemReceived", recipient.x, recipient.y, seconds(0.8), { owner: recipient.owner });
}
function hasFriendlyUnitAtMercenaryCamp(game, owner, camp) {
  return game.units.some((unit) => unit.owner === owner && unitControlsMercenaryCamp(unit, camp));
}
function updatePickupItemOrder(game, unit) {
  if (unit.order.type !== "pickupItem") return;
  const itemId = unit.order.itemId;
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item || item.carrierId || item.shipId) {
    unit.order = { type: "idle" };
    return;
  }
  if (distance(unit, item) > ITEM_PICKUP_RANGE) {
    moveToward(unit, item.x, item.y, game.map, game.units);
    return;
  }
  if (freeItemSlot(game, unit, item.kind)) attachItemToUnit(game, item, unit);
  unit.order = { type: "idle" };
}
function pickupItem(game, owner, unitId, itemId, queued = false) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item carrier ${unitId}`);
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item) throw new Error(`Unknown item ${itemId}`);
  if (item.carrierId || item.shipId) throw new Error(`${item.id} is already carried`);
  if (unitMover(unit.kind) === "sea") throw new Error("A ship carries no items");
  if (!canEquip(unit) || !freeItemSlot(game, unit, item.kind)) throw new Error(`${unit.id} has no free equipment position`);
  if (distance(unit, item) > ITEM_PICKUP_RANGE) {
    assignUnitOrder(unit, { type: "pickupItem", itemId }, queued);
    return;
  }
  attachItemToUnit(game, item, unit);
}
function attachItemToUnit(game, item, unit) {
  const slot = freeItemSlot(game, unit, item.kind);
  if (!slot) return;
  item.slot = slot;
  item.carrierId = unit.id;
  delete item.deck;
  invalidateItemIndex(game.items);
  item.x = unit.x;
  item.y = unit.y;
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function dropItem(game, owner, unitId, itemId, x, y) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item carrier ${unitId}`);
  const refusal = dropRefusal(game, owner, unitId, itemId);
  if (refusal) throw new Error(refusal);
  const item = game.items.find((item2) => item2.id === itemId);
  const ship = game.units.find((ship2) => ship2.id === item.shipId);
  delete item.carrierId;
  delete item.slot;
  delete item.shipId;
  delete item.holdSlot;
  delete item.mountId;
  removeFromHands(unit, item.id);
  if (ship) rebuildShipFittings(game, ship);
  invalidateItemIndex(game.items);
  item.x = clamp(x, 0, game.map.width);
  item.y = clamp(y, 0, game.map.height);
  settleGroundItems(game.items, game.units, game.map);
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function useItem(game, owner, unitId, itemId, targetId, x, y) {
  const unit = game.units.find((candidate) => candidate.id === unitId && candidate.owner === owner);
  if (!unit) throw new Error(`Unknown ${owner} item user ${unitId}`);
  const item = carriedItem(game, unit, itemId);
  const previousHands = unit.hands ? { ...unit.hands } : void 0;
  if (!ITEM_DEFS[item.kind].passive && !itemEquipped(game, unit, item)) {
    unit.hands ??= {};
    removeFromHands(unit, item.id);
    unit.hands.right = item.id;
    if (itemHands(item) === 2) delete unit.hands.left;
    unit.aim = void 0;
    applyDerivedUnitStats(game, unit);
  }
  activateItem(game, unit, item, targetId, x, y);
  if (previousHands && !game.items.some((candidate) => candidate.id === item.id)) {
    unit.hands = previousHands;
    applyDerivedUnitStats(game, unit);
  }
}
function castAbility(game, owner, unitId, ability, targetId, x, y, queued = false) {
  const caster = game.units.find((unit) => unit.id === unitId && unit.owner === owner);
  if (!caster || caster.hp <= 0) throw new Error(`Unknown ${owner} caster ${unitId}`);
  if (isStunned(caster)) throw new Error(`${caster.kind} is stunned`);
  if (!unitAbilities(caster).includes(ability)) throw new Error(`${caster.kind} cannot cast ${ability}`);
  if (abilityCooldown(caster, ability) > 0) throw new Error(`${caster.kind} is on cooldown`);
  const def = ABILITY_DEFS[ability];
  if (def.behavior === "veteran") {
    if (queued) assignUnitOrder(caster, { type: "cast", ability }, true);
    else applyVeteranAbility(game, caster, def, false);
    return;
  }
  const typedTarget = targetId ? findStrikeTarget(game, targetId) : void 0;
  if (typedTarget && isUnit(typedTarget) && !matchesUnitTarget(typedTarget, def.targets, game)) {
    throw new Error(def.behavior === "heal" ? "Healing cannot restore mechanical units" : "Ability cannot target this unit class");
  }
  const later = (order, at) => {
    assignUnitOrder(caster, order, queued);
    addEffect(game, queued ? "queuedMove" : "move", at.x, at.y, queued ? 38 : 24, { owner });
  };
  if (def.behavior === "weapon") {
    const target = targetId ? findStrikeTarget(game, targetId) : void 0;
    if (def.target === "enemy" && (!target || !areEnemyOwners(game, owner, target.owner))) throw new Error("Weapon skill requires an enemy target");
    const point = target ?? (isNumber(x) && isNumber(y) ? { x, y } : void 0);
    if (!point) throw new Error("Weapon skill requires a target point");
    if (def.weapon.minRange && distance(caster, point) < def.weapon.minRange) throw new Error("Target inside weapon minimum range");
    if (queued || isShipKind(caster.kind) || aimingProfile(unitRules(game, caster)) || distance(caster, point) > def.range + (target && !isUnit(target) ? target.radius : 0)) later({ type: "cast", ability, ...target ? { targetId: target.id } : { x: point.x, y: point.y } }, point);
    else applyWeaponAbility(game, caster, ability, point, def, target?.id);
    return;
  }
  if (def.behavior === "heal") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && !areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Heal requires an allied unit target");
    if (!canReceiveHealing(target, game)) throw new Error("Healing cannot restore mechanical units");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else applyHeal(game, caster, ability, target, def);
    return;
  }
  if (def.behavior === "curse") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Curse requires an enemy unit target");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else applyCurse(game, caster, ability, target, def);
    return;
  }
  if (def.behavior === "charge") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, unit.owner, owner)) : void 0;
    if (!target) throw new Error("Charge requires an enemy unit target");
    if (distance(caster, target) < def.minRange) throw new Error(`Charge target must be at least ${def.minRange} away`);
    if (!canReach(game.map, caster, target, game.units)) throw new Error("Charge target is out of reach");
    if (queued || distance(caster, target) > def.range) later({ type: "cast", ability, targetId: target.id }, target);
    else startCharge(game, caster, ability, target, def, true);
    return;
  }
  if (def.behavior !== "summon") throw new Error(`${ability} is cast by its creep alone`);
  if (!isNumber(x) || !isNumber(y)) throw new Error("Summon requires a target point");
  if (queued || distance(caster, { x, y }) > def.range) later({ type: "cast", ability, x, y }, { x, y });
  else applySummon(game, caster, ability, x, y, def);
}
function updateCastOrder(game, unit) {
  const order = unit.order;
  if (order.type !== "cast") return;
  const def = ABILITY_DEFS[order.ability];
  const target = order.targetId === void 0 ? void 0 : findStrikeTarget(game, order.targetId);
  const end = () => {
    unit.order = { type: "idle" };
  };
  if (!def) return end();
  if (def.behavior === "veteran") {
    if (unitAbilities(unit).includes(order.ability) && abilityCooldown(unit, order.ability) <= 0) applyVeteranAbility(game, unit, def, false);
    return end();
  }
  if (order.targetId !== void 0 && (!target || target.hp <= 0 || areEnemyOwners(game, target.owner, unit.owner) !== (def.behavior !== "heal"))) return end();
  if (target && isUnit(target) && !matchesUnitTarget(target, def.targets, game)) return end();
  if (def.behavior === "heal" && target && (!isUnit(target) || !canReceiveHealing(target, game))) return end();
  const at = target ?? (isNumber(order.x) && isNumber(order.y) ? { x: order.x, y: order.y } : void 0);
  if (!at) return end();
  if (def.behavior === "weapon" && def.weapon.minRange && distance(unit, at) < def.weapon.minRange) return end();
  if (distance(unit, at) > def.range + (def.behavior === "weapon" && target && !isUnit(target) ? target.radius : 0)) {
    moveToward(unit, at.x, at.y, game.map, game.units);
    if (walkEnded(game, unit, at, 5)) end();
    return;
  }
  if (abilityCooldown(unit, order.ability) > 0) return end();
  if (def.behavior === "weapon") {
    if (order.ability === "incendiaryFlume" && unit.fittings) {
      const item = installedWeapons(game, unit).find((item2) => item2.kind === "flameProjector" && (item2.durability ?? 1) > 0);
      if (!item) return end();
      if (!shipGunCanAim(unit, item, at)) {
        const mount = shipMounts(unit).find((mount2) => mount2.id === item.mountId);
        turnShipToward(unit, Math.atan2(at.y - unit.y, at.x - unit.x) - mount.bearing, game.map, game.units);
        return;
      }
      item.facing = Math.atan2(at.y - mountedWeaponPose(unit, item).pivot.y, at.x - mountedWeaponPose(unit, item).pivot.x);
      const proxy = aimMountedWeapon(game, unit, item, at);
      if (!proxy) return;
      applyWeaponAbility(game, unit, order.ability, at, def, target?.id);
      markAimShot(proxy);
      end();
      return;
    }
    if (!aimAt(unit, weaponRules(game, unit), at, game.tick, veteranAimSpeed(game, unit))) return;
    applyWeaponAbility(game, unit, order.ability, at, def, target?.id);
    markAimShot(unit);
  } else if (def.behavior === "heal" && target && isUnit(target)) applyHeal(game, unit, order.ability, target, def);
  else if (def.behavior === "curse" && target && isUnit(target)) applyCurse(game, unit, order.ability, target, def);
  else if (def.behavior === "summon") applySummon(game, unit, order.ability, at.x, at.y, def);
  else if (def.behavior === "charge" && target && isUnit(target) && distance(unit, target) >= def.minRange && canReach(game.map, unit, target, game.units)) {
    startCharge(game, unit, order.ability, target, def, false);
    return;
  }
  end();
}
function applyHeal(game, caster, ability, target, def) {
  if (!matchesUnitTarget(target, def.targets, game) || !canReceiveHealing(target, game) || distance(caster, target) > def.range) return;
  target.hp = Math.min(target.maxHp, target.hp + def.healAmount);
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, target.x, target.y, 36, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: target.x, toY: target.y, toHeight: combatVisualHeight(game, target), unitId: caster.id, owner: caster.owner });
}
function syncSummonLoad(game, ship, probe) {
  return shipPassengers(game.units, ship).reduce((mass, unit) => mass + bodyMass(unit), bodyMass(probe)) > shipProfile(ship).loadCapacity;
}
function applySummon(game, caster, ability, x, y, def) {
  if (distance(caster, { x, y }) > def.range) return false;
  const ship = game.units.find((ship2) => {
    const profile = shipProfile(ship2);
    return profile && ship2.owner === caster.owner && circleInPolygon(worldToLocal(ship2, { x, y }), 0, profile.deck);
  });
  if (!ship && !isWalkable(game.map, x, y)) return false;
  const probe = ship && createUnit("summon-probe", caster.owner, def.summonKind, x, y);
  const point = ship && probe && deckPlacement(ship, probe, game.units, worldToLocal(ship, { x, y }));
  if (ship && (!point || syncSummonLoad(game, ship, probe))) return false;
  const spirit = game.spawnUnit(caster.owner, def.summonKind, x, y);
  if (ship && point) {
    spirit.deck = { shipId: ship.id, ...point };
    Object.assign(spirit, localToWorld(ship, point));
  }
  spirit.expiresTick = game.tick + def.summonDuration;
  spirit.order = { type: "idle" };
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, spirit.x, spirit.y, 50, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: spirit.x, toY: spirit.y, toHeight: combatVisualHeight(game, spirit), unitId: caster.id, owner: caster.owner });
  return true;
}
function applyCurse(game, caster, ability, target, def) {
  if (!matchesUnitTarget(target, def.targets, game) || distance(caster, target) > def.range) return;
  const damageMultiplier = target.effects.some((effect) => effect.type === "scorch") ? def.scorchedDamageMultiplier ?? def.damageMultiplier : def.damageMultiplier;
  target.effects = target.effects.filter((effect) => effect.type !== def.statusType);
  target.effects.push({ type: def.statusType, remaining: def.effectDuration, ...damageMultiplier !== 0.4 ? { damageMultiplier } : {} });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, def.effectType, target.x, target.y, 46, { sourceKind: caster.kind, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: target.x, toY: target.y, toHeight: combatVisualHeight(game, target), unitId: caster.id, owner: caster.owner });
  if (def.summonedDamage && target.expiresTick !== void 0) applyDamage(game, caster, target, def.summonedDamage, void 0, void 0, 0, DAMAGE_PROFILES.ARCANE);
}
function inChargeWindow(caster, target, def) {
  const gap = distance(caster, target);
  return gap >= def.minRange && gap <= def.range;
}
function startCharge(game, caster, ability, target, def, commanded) {
  if (!matchesUnitTarget(target, def.targets, game)) return;
  const current = caster.order.type === "charge" ? caster.order.resume : caster.order;
  const resume = current.type === "attackMove" ? { type: "attackMove", x: current.x, y: current.y, targetId: target.id } : current.type === "attack" && current.leashX !== void 0 && current.leashY !== void 0 ? { type: "attack", targetId: target.id, leashX: current.leashX, leashY: current.leashY } : current.type === "idle" && !commanded ? { type: "attack", targetId: target.id, leashX: caster.x, leashY: caster.y } : { type: "attack", targetId: target.id };
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  caster.order = { type: "charge", targetId: target.id, resume };
  if (commanded) caster.orderQueue = [];
  const meeting = Math.max(0, distance(caster, target) - caster.radius - target.radius);
  shove(caster, target.x - caster.x, target.y - caster.y, meeting + def.drive);
  const expected = Math.max(1, Math.ceil((distance(caster, target) - caster.attackRange) / MAX_SLIDE_STEP));
  addEffect(game, def.effectType, caster.x, caster.y, expected, { fromX: caster.x, fromY: caster.y, toX: target.x, toY: target.y, owner: caster.owner, sourceKind: caster.kind, unitId: caster.id });
}
function updateChargeOrder(game, unit) {
  const order = unit.order;
  if (order.type !== "charge") return;
  const ability = UNIT_DEFS[unit.kind].abilities.find((candidate) => ABILITY_DEFS[candidate].behavior === "charge");
  const def = ability ? ABILITY_DEFS[ability] : void 0;
  const target = findTarget(game, order.targetId);
  if (!def || def.behavior !== "charge" || !target || !isUnit(target) || target.hp <= 0) {
    endCharge(unit, order.resume);
    return;
  }
  if (distance(unit, target) <= unit.attackRange) {
    const damage = Math.max(1, Math.round(unit.attackDamage * outgoingDamageMultiplier(game, unit) * def.damageMultiplier));
    applyAttackDamage(game, unit, target, damage, unit.attackRange);
    addEffect(game, "chargeImpact", target.x, target.y, CHARGE_IMPACT_TICKS, { fromX: unit.x, fromY: unit.y, toX: target.x, toY: target.y, owner: unit.owner, sourceKind: unit.kind, unitId: unit.id, sourceId: unit.id, actionMode: "attack", fromHeight: combatVisualHeight(game, unit), toHeight: combatVisualHeight(game, target) });
    unit.cooldown = unit.attackCooldown;
    endCharge(unit, order.resume);
    return;
  }
  if (unit.pushX === void 0) endCharge(unit, order.resume);
}
function endCharge(unit, resume) {
  const next = unit.orderQueue?.shift();
  unit.order = next ?? resume;
}
const AUTOCAST_EVERY_TICKS = 2;
const AUTOCAST_ORDERS = /* @__PURE__ */ new Set(["idle", "attack", "attackMove", "hold", "aim"]);
const SUMMON_ALERT_MARGIN = 100;
const SUMMON_COMPANY_RANGE = 320;
const SUMMON_STEP = 60;
const CHARGE_IMPACT_TICKS = 12;
function autocastStep(game, unit) {
  if (!AUTOCAST_ORDERS.has(unit.order.type)) return;
  for (const ability of unitAbilities(unit)) {
    if (abilityCooldown(unit, ability) > 0 || !autocastEnabled(unit, ability)) continue;
    const def = ABILITY_DEFS[ability];
    if (def.behavior === "veteran") {
      if (applyVeteranAbility(game, unit, def, true)) return;
    } else if (def.behavior === "heal") {
      const target = autocastHealTarget(game, unit, def);
      if (target) return applyHeal(game, unit, ability, target, def);
    } else if (def.behavior === "curse") {
      const target = autocastCurseTarget(game, unit, def);
      if (target) return applyCurse(game, unit, ability, target, def);
    } else if (def.behavior === "summon") {
      const point = autocastSummonPoint(game, unit, def);
      if (point && applySummon(game, unit, ability, point.x, point.y, def)) return;
    } else if (def.behavior === "stomp") {
      if (applyStomp(game, unit, ability, def)) return;
    } else if (def.behavior === "bloodlust") {
      if (applyBloodlust(game, unit, ability, def)) return;
    } else if (def.behavior === "web") {
      if (applyWeb(game, unit, ability, def)) return;
    } else if (def.behavior === "charge" && unit.order.type !== "hold") {
      const target = autocastChargeTarget(game, unit, def);
      if (target) return startCharge(game, unit, ability, target, def, false);
    }
  }
}
function applyStomp(game, caster, ability, def) {
  const struck = [];
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (matchesUnitTarget(candidate, def.targets, game) && distance(caster, candidate) <= def.range && isAutocastFoe(game, caster, candidate)) struck.push(candidate);
  });
  if (struck.length === 0) return false;
  for (const unit of struck) setStatus(unit, { type: "stun", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "stomp", caster.x, caster.y, 24, { radius: def.range, owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, toX: caster.x, toY: caster.y });
  return true;
}
function applyBloodlust(game, caster, ability, def) {
  let best;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || distance(caster, candidate) > def.range || candidate.hp <= 0 || candidate.owner !== caster.owner || !isEngaged(candidate)) return;
    if (candidate.effects.some((effect) => effect.type === "bloodlust")) return;
    if (!best || candidate.attackDamage > best.attackDamage) best = candidate;
  });
  if (!best) return false;
  setStatus(best, { type: "bloodlust", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "bloodlust", best.x, best.y, 30, { owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: best.x, toY: best.y, toHeight: combatVisualHeight(game, best) });
  return true;
}
function applyWeb(game, caster, ability, def) {
  let best;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || distance(caster, candidate) > def.range || !isAutocastFoe(game, caster, candidate) || candidate.effects.some((effect) => effect.type === "root")) return;
    if (!best || distance(caster, candidate) < distance(caster, best)) best = candidate;
  });
  if (!best) return false;
  setStatus(best, { type: "root", remaining: def.effectDuration });
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  addEffect(game, "web", best.x, best.y, def.effectDuration, { owner: caster.owner, sourceKind: caster.kind, unitId: caster.id, sourceId: caster.id, actionMode: "cast", fromX: caster.x, fromY: caster.y, fromHeight: combatVisualHeight(game, caster), toX: best.x, toY: best.y, toHeight: combatVisualHeight(game, best) });
  return true;
}
function setStatus(unit, status) {
  unit.effects = unit.effects.filter((effect) => effect.type !== status.type);
  unit.effects.push(status);
}
function statusPace(unit) {
  if (unit.effects.length === 0) return 1;
  let pace = 1;
  for (const effect of unit.effects) {
    if (effect.type === "root" || effect.type === "stun") return 0;
    if (effect.type === "slow") pace = SLOW_PACE;
  }
  return pace;
}
function attackCooldownOf(game, unit, baseCooldown = unit.attackCooldown) {
  const speed = (game.veteranFrame?.get(unit.id)?.attackSpeedMultiplier ?? 1) * temporaryAttackSpeedMultiplier(unit);
  return speed === 1 ? baseCooldown : Math.max(1, Math.round(baseCooldown / speed));
}
function isEngaged(unit) {
  return unit.order.type === "attack" || unit.order.type === "charge" || unit.order.type === "attackMove" && unit.order.targetId !== void 0;
}
function isAutocastFoe(game, caster, candidate) {
  return candidate.hp > 0 && areEnemyOwners(game, caster.owner, candidate.owner) && (candidate.owner !== "neutral" || isEngaged(candidate));
}
function autocastHealTarget(game, caster, def) {
  let best;
  let bestMissing = def.healAmount / 2;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !canReceiveHealing(candidate, game) || candidate.hp <= 0 || areEnemyOwners(game, caster.owner, candidate.owner) || distance(caster, candidate) > def.range) return;
    const missing = candidate.maxHp - candidate.hp;
    if (missing < bestMissing || missing === bestMissing && best) return;
    best = candidate;
    bestMissing = missing;
  });
  return best;
}
function autocastCurseTarget(game, caster, def) {
  const casterFights = isEngaged(caster);
  const own = caster.order.type === "attack" || caster.order.type === "attackMove" ? caster.order.targetId : void 0;
  let best;
  let bestScore = Number.NEGATIVE_INFINITY;
  forEachNearbyUnit(game, caster, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !isAutocastFoe(game, caster, candidate) || distance(caster, candidate) > def.range) return;
    if (!casterFights && !isEngaged(candidate)) return;
    if (candidate.effects.some((effect) => effect.type === def.statusType)) return;
    const score = (def.summonedDamage && candidate.expiresTick !== void 0 ? 2e3 : 0) + (candidate.id === own ? 1e3 : 0) - distance(caster, candidate);
    if (score <= bestScore) return;
    best = candidate;
    bestScore = score;
  });
  return best;
}
function autocastSummonPoint(game, caster, def) {
  let foe;
  forEachNearbyUnit(game, caster, def.range + SUMMON_ALERT_MARGIN, (candidate) => {
    if (!isAutocastFoe(game, caster, candidate) || distance(caster, candidate) > def.range + SUMMON_ALERT_MARGIN) return;
    if (!foe || distance(caster, candidate) < distance(caster, foe)) foe = candidate;
  });
  if (!foe) return void 0;
  let company = false;
  forEachNearbyUnit(game, caster, SUMMON_COMPANY_RANGE, (candidate) => {
    if (candidate.owner === caster.owner && candidate.kind === def.summonKind && distance(caster, candidate) <= SUMMON_COMPANY_RANGE) company = true;
  });
  if (company) return void 0;
  const gap = distance(caster, foe);
  const step = Math.min(SUMMON_STEP, gap);
  return gap > 0 ? { x: caster.x + (foe.x - caster.x) / gap * step, y: caster.y + (foe.y - caster.y) / gap * step } : { x: caster.x, y: caster.y };
}
function autocastChargeTarget(game, rider, def) {
  const order = rider.order;
  const own = order.type === "attack" || order.type === "attackMove" ? order.targetId : void 0;
  if (own) {
    const target = findTarget(game, own);
    return target && isUnit(target) && matchesUnitTarget(target, def.targets, game) && isAutocastFoe(game, rider, target) && inChargeWindow(rider, target, def) && canReach(game.map, rider, target, game.units) ? target : void 0;
  }
  if (order.type !== "idle" && order.type !== "attackMove") return void 0;
  let charged;
  let free;
  let any;
  forEachNearbyUnit(game, rider, def.range, (candidate) => {
    if (!matchesUnitTarget(candidate, def.targets, game) || !isAutocastFoe(game, rider, candidate) || !inChargeWindow(rider, candidate, def) || !canReach(game.map, rider, candidate, game.units)) return;
    charged ??= new Set(game.units.flatMap((unit) => unit.owner === rider.owner && unit.order.type === "charge" ? [unit.order.targetId] : []));
    if (!any || distance(rider, candidate) < distance(rider, any)) any = candidate;
    if (!charged.has(candidate.id) && (!free || distance(rider, candidate) < distance(rider, free))) free = candidate;
  });
  return free ?? any;
}
function outgoingDamageMultiplier(game, unit) {
  const cursed = unit.effects.reduce((multiplier, effect) => Math.min(multiplier, effect.damageMultiplier ?? (effect.type === "curse" ? 0.4 : 1)), 1);
  return (unit.stance === "brace" ? cursed * BRACE_DAMAGE_SHARE : cursed) * passengerDamageMultiplier(game, unit);
}
function carriedItem(game, unit, itemId) {
  const item = game.items.find((candidate) => candidate.id === itemId);
  if (!item) throw new Error(`Unknown item ${itemId}`);
  if (item.carrierId !== unit.id) throw new Error(`${unit.id} is not carrying ${item.id}`);
  return item;
}
function carrierFor(game, item) {
  return item.carrierId ? game.units.find((unit) => unit.id === item.carrierId) : void 0;
}
function activateNeutralItem(game, carrier, item) {
  if (item.kind === "guardianScroll" || item.kind === "experienceBook" || item.kind === "breachCharge" || isShopOnlyItem(item.kind) || item.cooldownRemaining > 0) return;
  const target = nearestEnemyInRange(game, carrier, item.kind === "stormStaff" ? NEUTRAL_STORM_TARGET_RANGE : NEUTRAL_ITEM_TARGET_RANGE);
  if (!target) return;
  activateItem(game, carrier, item, target.id, target.x, target.y);
}
function activateItem(game, carrier, item, targetId, x, y) {
  if (item.cooldownRemaining > 0) return;
  if (item.kind === "lightningRod") {
    const target = targetId ? game.units.find((unit) => unit.id === targetId && areEnemyOwners(game, carrier.owner, unit.owner)) : void 0;
    if (!target || distance(carrier, target) > LIGHTNING_ROD.range) return;
    applyChainLightning(game, carrier, item, target);
    return;
  }
  if (item.kind === "stormStaff") {
    const point = targetId ? game.units.find((unit) => unit.id === targetId) : isNumber(x) && isNumber(y) ? { x, y } : void 0;
    if (!point || distance(carrier, point) > STORM_STAFF.range) return;
    applyStormStaff(game, carrier, item, point.x, point.y);
    return;
  }
  if (item.kind === "guardianScroll") {
    if (carrier.owner === "neutral") return;
    forEachNearbyUnit(game, carrier, GUARDIAN_SCROLL.radius, (unit) => {
      if (distance(unit, carrier) > GUARDIAN_SCROLL.radius || areEnemyOwners(game, carrier.owner, unit.owner)) return;
      unit.effects = unit.effects.filter((effect) => effect.type !== "guardian");
      unit.effects.push({ type: "guardian", remaining: GUARDIAN_SCROLL.duration });
    });
    addEffect(game, "guardianField", carrier.x, carrier.y, GUARDIAN_SCROLL.duration, { radius: GUARDIAN_SCROLL.radius, sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: carrier.x, toY: carrier.y });
    consumeItem(game, item);
    return;
  }
  if (item.kind === "breachCharge") {
    if (carrier.owner === "neutral") return;
    const target = targetId ? game.buildings.find((building) => building.id === targetId && areEnemyOwners(game, carrier.owner, building.owner)) : void 0;
    if (!target || distance(carrier, target) > BREACH_CHARGE.range) return;
    applyAttackDamage(game, carrier, target, BREACH_CHARGE.damage, BREACH_CHARGE.range, ITEM_DAMAGE_PROFILES.breachCharge);
    consumeItem(game, item);
    return;
  }
  if (item.kind === "experienceBook") {
    if (carrier.owner === "neutral") return;
    carrier.xp += EXPERIENCE_BOOK_XP;
    applyXpLevel(game, carrier);
    addEffect(game, "experienceBurst", carrier.x, carrier.y, 48);
    consumeItem(game, item);
    return;
  }
  if (item.kind === "healingScroll") {
    if (carrier.owner === "neutral") return;
    forEachNearbyUnit(game, carrier, HEALING_SCROLL_RADIUS, (unit) => {
      if (!canReceiveHealing(unit, game) || distance(unit, carrier) > HEALING_SCROLL_RADIUS || areEnemyOwners(game, carrier.owner, unit.owner)) return;
      unit.hp = Math.min(unit.maxHp, unit.hp + HEALING_SCROLL_HEAL);
    });
    addEffect(game, "heal", carrier.x, carrier.y, 30, { radius: HEALING_SCROLL_RADIUS, sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: carrier.x, toY: carrier.y });
    consumeItem(game, item);
    return;
  }
  if (item.kind === "ivoryTower") {
    if (!isPlayerId(carrier.owner) || !isNumber(x) || !isNumber(y)) return;
    if (Math.hypot(x - carrier.x, y - carrier.y) > IVORY_TOWER_REACH) return;
    if (terrainBlocksPlacement(game.map, "defenseTower", { x, y }) || buildingPlacementBlocker(game, "defenseTower", { x, y })) return;
    const at = snapToFootprint(game.map, BUILDING_DEFS.defenseTower.radius, { x, y });
    const tower = createBuilding(`building-${carrier.owner}-defenseTower-${game.nextId}`, carrier.owner, "defenseTower", at.x, at.y, true);
    game.nextId += 1;
    tower.hp = Math.round(tower.maxHp * IVORY_TOWER_HP_SHARE);
    game.buildings.push(tower);
    addEffect(game, "summon", at.x, at.y, 34, { sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: at.x, toY: at.y });
    consumeItem(game, item);
  }
}
function isShopOnlyItem(kind) {
  return kind === "speedBoots" || kind === "regenRing" || kind === "healingScroll" || kind === "ivoryTower";
}
function consumeItem(game, item) {
  const unit = carrierFor(game, item);
  if (unit) removeFromHands(unit, item.id);
  game.items = game.items.filter((candidate) => candidate.id !== item.id);
  if (unit) applyDerivedUnitStats(game, unit);
  refreshEquipmentMass(game);
}
function applyChainLightning(game, carrier, item, firstTarget) {
  const struck = /* @__PURE__ */ new Set();
  let current = firstTarget;
  let damage = LIGHTNING_ROD.damage;
  for (let bounce = 0; bounce < LIGHTNING_ROD.hits; bounce += 1) {
    struck.add(current.id);
    applyAttackDamage(game, carrier, current, damage * outgoingDamageMultiplier(game, carrier), 240, ITEM_DAMAGE_PROFILES.lightningRod);
    addEffect(game, "chainLightning", current.x, current.y, 28, { fromX: carrier.x, fromY: carrier.y, toX: current.x, toY: current.y });
    const next = nearestChainTarget(game, carrier, current, struck, LIGHTNING_ROD.bounceRange);
    if (!next) break;
    current = next;
    damage = Math.max(LIGHTNING_ROD.minimumDamage, Math.round(damage * LIGHTNING_ROD.decay));
  }
  item.cooldownRemaining = LIGHTNING_ROD.cooldown;
}
function nearestChainTarget(game, carrier, from, struck, range) {
  const limit = range * range;
  let best;
  let bestDistance = Number.POSITIVE_INFINITY;
  forEachNearbyUnit(game, from, range, (candidate) => {
    if (struck.has(candidate.id) || !areEnemyOwners(game, carrier.owner, candidate.owner)) return;
    const candidateDistance = distanceSquared(from, candidate);
    if (candidateDistance > limit || candidateDistance >= bestDistance) return;
    best = candidate;
    bestDistance = candidateDistance;
  });
  return best;
}
function applyStormStaff(game, carrier, item, x, y) {
  forEachNearbyUnit(game, { x, y }, STORM_STAFF.radius, (target) => {
    if (distance(target, { x, y }) > STORM_STAFF.radius || !areEnemyOwners(game, carrier.owner, target.owner)) return;
    applyAttackDamage(game, carrier, target, STORM_STAFF.impactDamage * outgoingDamageMultiplier(game, carrier), STORM_STAFF.range, ITEM_DAMAGE_PROFILES.stormStaff);
  });
  addEffect(game, "storm", x, y, STORM_STAFF.duration, { sourceId: carrier.id, actionMode: "cast", fromX: carrier.x, fromY: carrier.y, toX: x, toY: y, owner: carrier.owner, unitId: carrier.id, damage: STORM_STAFF.pulseDamage * outgoingDamageMultiplier(game, carrier), damageProfile: { ...ITEM_DAMAGE_PROFILES.stormStaff }, radius: STORM_STAFF.radius, tickEvery: STORM_STAFF.pulseEvery });
  item.cooldownRemaining = STORM_STAFF.cooldown;
}
function applyFlameCloak(game, carrier, item) {
  if (item.cooldownRemaining > 0) return;
  let burned = false;
  forEachNearbyUnit(game, carrier, FLAME_CLOAK.radius, (target) => {
    if (distance(target, carrier) > FLAME_CLOAK.radius || !areEnemyOwners(game, carrier.owner, target.owner)) return;
    applyAttackDamage(game, carrier, target, FLAME_CLOAK.damage * outgoingDamageMultiplier(game, carrier), 70, ITEM_DAMAGE_PROFILES.flameCloak);
    addEffect(game, "flameBurn", target.x, target.y, FLAME_CLOAK_VISUAL_DURATION);
    burned = true;
  });
  if (!burned) return;
  item.cooldownRemaining = FLAME_CLOAK.interval;
}
function updateWorldEffects(game) {
  if (game.effects.length === 0) return;
  let expired = false;
  for (const effect of game.effects) {
    applyWorldEffectTick(game, effect);
    effect.remaining -= 1;
    expired ||= !(effect.remaining > 0);
  }
  if (expired) game.effects = game.effects.filter((effect) => effect.remaining > 0);
}
function applyWorldEffectTick(game, effect) {
  if (effect.type === "burningGround" && effect.owner && effect.damage && effect.radius && effect.tickEvery) {
    if (effect.remaining % effect.tickEvery !== 0) return;
    const source = effect.unitId ? findTarget(game, effect.unitId) : void 0;
    const attacker = source ?? scriptSource({ id: effect.unitId ?? effect.id, owner: effect.owner, x: effect.x, y: effect.y });
    for (const target of [...game.units, ...game.buildings]) if (target.hp > 0 && areEnemyOwners(game, effect.owner, target.owner) && distance(effect, target) <= effect.radius + target.radius) {
      if (effect.sourceKind === "sparkArcher" && isUnit(target) && (target.deck || unitMover(target.kind) !== "land")) continue;
      const taken = applyDamage(game, attacker, target, effect.damage, void 0, void 0, 0, effect.damageProfile ?? DAMAGE_PROFILES.BURNING);
      if (taken !== void 0) addHitEffect(game, target, taken, source);
      if (taken !== void 0 && effect.sourceKind === "sparkArcher" && isUnit(target)) setStatus(target, { type: "scorch", remaining: SCORCH_DURATION });
    }
    return;
  }
  if (effect.type !== "storm" || !effect.owner || !effect.damage || !effect.radius || !effect.tickEvery) return;
  if (effect.remaining !== effect.duration && effect.remaining % effect.tickEvery !== 0) return;
  forEachNearbyUnit(game, effect, effect.radius, (target) => {
    if (distance(target, effect) > effect.radius || !areEnemyOwners(game, effect.owner, target.owner)) return;
    applyAttackDamage(game, scriptSource({ id: effect.unitId ?? effect.id, owner: effect.owner, x: effect.x, y: effect.y }), target, effect.damage, 260, effect.damageProfile ?? DAMAGE_PROFILES.STORM);
  });
}
function updateProjectiles(game) {
  if (game.projectiles.length === 0) return;
  const projectiles = game.projectiles;
  let pending;
  for (let index = 0; index < projectiles.length; index++) {
    const projectile = projectiles[index];
    projectile.remaining -= 1;
    if (projectile.remaining > 0) {
      pending?.push(projectile);
      continue;
    }
    pending ??= projectiles.slice(0, index);
    applyProjectileImpact(game, projectile);
  }
  if (pending) game.projectiles = pending;
}
function applyProjectileImpact(game, projectile) {
  withDeckDamageBatch(game, () => {
    if (projectile.weapon) {
      impactWeapon(game, projectile);
      return;
    }
    const target = findStrikeTarget(game, projectile.targetId);
    if (!target || target.hp <= 0 || !areEnemyOwners(game, projectile.owner, target.owner)) return;
    const liveShooter = findTarget(game, projectile.attackerId);
    const shooter = liveShooter?.owner === projectile.owner ? liveShooter : void 0;
    const attacker = shooter ?? projectileAttacker(projectile);
    const taken = applyDamage(game, attacker, target, attackDamageAgainstTarget(game, attacker, target, projectile.damage), projectile.hullDamageShare, void 0, 0, projectile.damageProfile ?? attackDamageProfile(projectile.sourceKind ?? "defenseTower"), projectile.armorAlreadyApplied);
    if (taken === void 0) return;
    applyAttackStatusEffects(game, attacker, target, projectile.sourceKind);
    addHitEffect(game, target, taken, shooter, projectile.attackKind, { x: projectile.fromX, y: projectile.fromY });
  });
}
function projectileAttacker(projectile) {
  return {
    id: projectile.attackerId,
    owner: projectile.owner,
    kind: "defenseTower",
    x: projectile.fromX,
    y: projectile.fromY,
    hp: 1,
    maxHp: 1,
    radius: 0,
    complete: true,
    buildProgress: 0,
    buildTime: 0,
    attackDamage: 0,
    attackRange: 0,
    attackCooldown: 0,
    cooldown: 0,
    rallyX: projectile.fromX,
    rallyY: projectile.fromY,
    queue: [],
    researchQueue: []
  };
}
function updateUnitStatusEffects(game) {
  for (const unit of game.units) {
    if (unit.effects.length === 0) continue;
    let expired = false;
    for (const effect of unit.effects) {
      effect.remaining -= 1;
      expired ||= !(effect.remaining > 0);
    }
    for (const effect of unit.effects) {
      if (effect.type === "poison" && effect.remaining % 20 === 0 && unit.hp > 0) {
        const source = effect.sourceId ? findTarget(game, effect.sourceId) : void 0;
        const attacker = source && source.hp > 0 ? source : scriptSource({ id: effect.sourceId ?? "poison", owner: effect.sourceOwner ?? "neutral", x: unit.x, y: unit.y });
        applyDamage(game, attacker, unit, POISON_DAMAGE, void 0, void 0, 0, DAMAGE_PROFILES.POISON, false, true);
      }
    }
    if (expired) unit.effects = unit.effects.filter((effect) => effect.remaining > 0);
  }
}
function applyWeaponAbility(game, caster, ability, at, def, targetId) {
  caster.abilityCooldowns = withAbilityCooldown(caster, ability, def.cooldown);
  const mounted = ability === "incendiaryFlume" ? installedWeapons(game, caster).find((item) => item.kind === "flameProjector" && (item.durability ?? 1) > 0 && shipGunCanAim(caster, item, at)) : void 0;
  fireWeapon(game, caster, at, def.damage * outgoingDamageMultiplier(game, caster), def.weapon, def.range, { ...def.rootTicks ? { rootTicks: def.rootTicks } : {}, ...def.burnTicks ? { burnTicks: def.burnTicks } : {} }, targetId, mounted ? { item: mounted, pose: mountedWeaponPose(caster, mounted) } : void 0, "cast");
}
function backOutOfDeadZone(game, unit, target, navalFrame = true) {
  let minimum = weaponRules(game, unit).weapon?.minRange;
  if (navalFrame && isShipKind(unit.kind)) {
    const weapons = installedWeapons(game, unit).filter((item) => (item.durability ?? 1) > 0);
    if (weapons.length) minimum = Math.min(...weapons.map((item) => SHIP_WEAPONS[item.kind].weapon.minRange ?? 0));
  }
  if (!minimum || distance(unit, target) >= minimum) return false;
  const dx = unit.x - target.x, dy = unit.y - target.y, length = Math.hypot(dx, dy) || 1;
  moveToward(unit, unit.x + (dx || 1) / length * (minimum + 32), unit.y + dy / length * (minimum + 32), game.map, game.units);
  return true;
}
function weaponOrigin(attacker) {
  const pose = isUnit(attacker) && shipWeaponPose(attacker);
  return pose ? pose.muzzle : { x: attacker.x, y: attacker.y };
}
function combatVisualHeight(game, entity) {
  const unit = "order" in entity ? entity : "kind" in entity ? void 0 : entity.id && game.units.find((unit2) => unit2.id === entity.id);
  if (!unit) return 0;
  const hull = unit.deck && game.units.find((ship) => ship.id === unit.deck.shipId);
  return hull ? (shipProfile(hull)?.deckHeight ?? 0) + 18 : shipProfile(unit)?.deckHeight ?? 0;
}
function fireWeapon(game, attacker, at, damage, weapon, range, skill = {}, targetId = at.id, mounted, actionMode = "attack") {
  const origin = mounted?.pose.muzzle ?? weaponOrigin(attacker);
  const damageProfile = weaponDamageProfile(weapon);
  const target = targetId ? findStrikeTarget(game, targetId) : void 0;
  const point = mounted?.aimPoint ?? (target ? strikePoint(origin, target) : at);
  const fromHeight = mounted?.pose.height || isUnit(attacker) && shipWeaponPose(attacker)?.height || combatVisualHeight(game, attacker);
  const attackKind = weapon.presentation ?? (weapon.delivery === "cone" ? "grapeshot" : weapon.delivery === "shell" ? "stone" : "bolt");
  const visuals = { actionMode, sourceId: attacker.id, attackKind, fromX: origin.x, fromY: origin.y, fromHeight, toX: point.x, toY: point.y, toHeight: combatVisualHeight(game, at), owner: attacker.owner, sourceKind: attacker.kind, unitId: attacker.id, ...mounted ? { itemId: mounted.item.id } : {} };
  if ((attackKind === "cannon" || attackKind === "mortar" || attackKind === "grapeshot") && (mounted || isUnit(attacker))) addEffect(game, "muzzleFlash", origin.x, origin.y, seconds(0.65), visuals);
  if (weapon.delivery === "ram") {
    const target2 = targetId ? findStrikeTarget(game, targetId) : void 0;
    if (target2 && areEnemyOwners(game, attacker.owner, target2.owner)) hitWeapon(game, attacker, target2, damage, weapon);
    addEffect(game, "siegeImpact", at.x, at.y, 18, { fromX: origin.x, fromY: origin.y, toX: point.x, toY: point.y, owner: attacker.owner, sourceKind: attacker.kind, sourceId: attacker.id, actionMode });
    return;
  }
  if (weapon.delivery === "cone") {
    const hits = [...game.units, ...game.buildings].filter((target2) => target2.hp > 0 && (!isUnit(target2) || !isInCabin(target2)) && areEnemyOwners(game, attacker.owner, target2.owner) && inWeaponCone(origin, point, target2, range, weapon.coneAngle ?? 0.6));
    withDeckDamageBatch(game, () => {
      for (const target2 of crewBeforeHulls(hits)) hitWeapon(game, attacker, target2, damage * (weapon.burst ?? 1), weapon);
    });
    addEffect(game, "grapeshot", point.x, point.y, seconds(0.7), { ...visuals, radius: range });
    return;
  }
  const flight = Math.max(seconds(0.2), Math.ceil(distance(origin, point) / perTick(weapon.delivery === "shell" ? 240 : 560)));
  const projectile = { id: `projectile-${game.nextId++}`, owner: attacker.owner, attackerId: attacker.id, targetId: targetId ?? "", fromX: origin.x, fromY: origin.y, toX: point.x, toY: point.y, damage, damageProfile: { ...damageProfile }, remaining: flight, duration: flight, attackKind, weapon: { ...weapon }, ...isUnit(attacker) ? { sourceKind: attacker.kind } : {}, ...skill };
  game.projectiles.push(projectile);
  addEffect(game, weapon.delivery === "shell" ? "shellFlight" : "siegeBolt", point.x, point.y, flight, { ...visuals, radius: weapon.radius ?? 0 });
}
function hitWeapon(game, attacker, target, damage, weapon, share = 1, rootTicks, impact = strikePoint(attacker, target), profile = weaponDamageProfile(weapon), visualOrigin) {
  const dealt = weaponDamage(weapon, damage, !isUnit(target), isUnit(target) && unitMover(target.kind) === "sea", share);
  const taken = applyDamage(game, attacker, target, dealt, deckHullDamageShare(game, attacker, weapon), impact, weapon.blastRadius ?? weapon.radius ?? 0, profile);
  if (taken === void 0) return;
  addHitEffect(game, target, taken, attacker, weapon.presentation, visualOrigin);
  if (rootTicks && isUnit(target) && target.hp > 0) setStatus(target, { type: "root", remaining: rootTicks });
}
function impactWeapon(game, projectile) {
  const weapon = projectile.weapon;
  const liveSource = findTarget(game, projectile.attackerId);
  const source = liveSource?.owner === projectile.owner ? liveSource : void 0;
  const fallback = projectileAttacker(projectile);
  const attacker = source ?? (projectile.sourceKind ? { ...fallback, kind: projectile.sourceKind, order: { type: "idle" }, effects: [], xp: 0, level: 0, kills: 0, abilityCooldown: 0, speed: 0 } : fallback);
  const from = { x: projectile.fromX, y: projectile.fromY }, to = { x: projectile.toX, y: projectile.toY };
  const flightLength = distance(from, to), impactAt = (along) => {
    const share = flightLength ? Math.max(0, Math.min(1, along / flightLength)) : 0;
    return { x: from.x + (to.x - from.x) * share, y: from.y + (to.y - from.y) * share };
  };
  const foes = [...game.units, ...game.buildings, ...game.obstacles ?? []].filter((t) => t.hp > 0 && (!isUnit(t) || !isInCabin(t)) && areEnemyOwners(game, projectile.owner, t.owner));
  if (weapon.delivery === "bolt") {
    const intersections = foes.map((target) => ({ target, along: boltIntersection(from, to, target, weapon.radius ?? 12) })).filter((h) => h.along !== void 0).sort((a, b) => a.along - b.along);
    const eligible = new Set(crewBeforeHulls(intersections.map((hit) => hit.target)));
    const hits = intersections.filter((hit) => eligible.has(hit.target)).slice(0, weapon.maxHits ?? 1);
    if (weapon.blastRadius && hits[0]) {
      const impact = impactAt(hits[0].along);
      for (const target of crewBeforeHulls(foes.filter((target2) => bodyGap(impact, target2) <= weapon.blastRadius))) {
        const share = Math.max(0.4, 1 - bodyGap(impact, target) / weapon.blastRadius * 0.6);
        hitWeapon(game, attacker, target, projectile.damage, weapon, share, projectile.rootTicks, impact, projectile.damageProfile, from);
      }
      addEffect(game, "siegeImpact", impact.x, impact.y, seconds(0.65), { radius: weapon.blastRadius, owner: projectile.owner, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
      return;
    }
    hits.forEach(({ target, along }, i) => hitWeapon(game, attacker, target, projectile.damage, weapon, (weapon.pierceShare ?? 1) ** i, projectile.rootTicks, impactAt(along), projectile.damageProfile, from));
  } else {
    for (const target of crewBeforeHulls(foes.filter((target2) => bodyGap(to, target2) <= (weapon.radius ?? 0)))) {
      const gap = bodyGap(to, target);
      const falloff = Math.max(0.35, 1 - gap / Math.max(1, weapon.radius ?? 1) * 0.65);
      hitWeapon(game, attacker, target, projectile.damage, weapon, falloff, projectile.rootTicks, to, projectile.damageProfile, from);
    }
    addEffect(game, "siegeImpact", to.x, to.y, 24, { radius: weapon.radius ?? 0, owner: projectile.owner, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
    if (projectile.burnTicks) addEffect(game, "burningGround", to.x, to.y, projectile.burnTicks, { owner: projectile.owner, unitId: projectile.attackerId, damage: 3, damageProfile: { ...DAMAGE_PROFILES.BURNING }, radius: weapon.radius ?? 0, tickEvery: 10, ...projectile.sourceKind ? { sourceKind: projectile.sourceKind } : {} });
  }
}
function applyWeaponAttack(game, attacker, target, damage, attackRange) {
  if (!isObstacle(target)) target = navalCombatTarget(game, attacker, target);
  if (isUnit(attacker) && shipProfile(attacker) && !unitRules(game, attacker).intrinsicAttack) return;
  const weapon = isUnit(attacker) ? weaponRules(game, attacker).weapon : void 0;
  if (weapon) {
    if (weapon.minRange && distance(attacker, target) < weapon.minRange) return;
    fireWeapon(game, attacker, target, damage, weapon, attackRange);
    return;
  }
  const baseRange = isUnit(attacker) ? weaponRules(game, attacker).attackRange : attackRange;
  if (baseRange > RANGED_ATTACK_RANGE_THRESHOLD) {
    launchProjectile(game, attacker, target, buildingTargetDamage(attacker, target, damage));
    return;
  }
  applyAttackDamage(game, attacker, target, damage, baseRange);
}
function launchProjectile(game, attacker, target, damage) {
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  const flight = Math.max(1, Math.ceil(Math.sqrt(dx * dx + dy * dy) / perTick(PROJECTILE_SPEED)));
  const projectile = {
    attackKind: innateMissile(attacker.kind),
    damageProfile: { ...isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind) },
    id: `projectile-${game.nextId}`,
    owner: attacker.owner,
    attackerId: attacker.id,
    targetId: target.id,
    fromX: attacker.x,
    fromY: attacker.y,
    toX: target.x,
    toY: target.y,
    damage,
    remaining: flight,
    duration: flight,
    ...isUnit(attacker) ? { sourceKind: attacker.kind } : {},
    hullDamageShare: deckHullDamageShare(game, attacker)
  };
  game.nextId += 1;
  game.projectiles.push(projectile);
  addEffect(game, "projectile", target.x, target.y, flight, {
    sourceId: attacker.id,
    owner: attacker.owner,
    actionMode: "attack",
    fromX: projectile.fromX,
    fromY: projectile.fromY,
    toX: projectile.toX,
    toY: projectile.toY,
    sourceKind: attacker.kind,
    attackKind: projectile.attackKind,
    fromHeight: combatVisualHeight(game, attacker),
    toHeight: combatVisualHeight(game, target)
  });
}
function applyAttackDamage(game, attacker, target, damage, attackRange, profile) {
  profile ??= isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind);
  const dealt = profile.origin === "spell" ? damage : attackDamageAgainstTarget(game, attacker, target, buildingTargetDamage(attacker, target, damage));
  const taken = applyDamage(game, attacker, target, dealt, void 0, void 0, 0, profile);
  if (taken === void 0) return;
  if (profile.origin !== "spell") applyAttackStatusEffects(game, attacker, target, attacker.kind);
  if (profile.delivery === "melee" && profile.origin !== "spell" && isUnit(attacker) && isUnit(target)) stanceBlow(attacker, target, dealt);
  const from = { x: attacker.x, y: attacker.y };
  const to = { x: target.x, y: target.y };
  const kind = attackRange > RANGED_ATTACK_RANGE_THRESHOLD ? "projectile" : "melee";
  addEffect(game, kind, to.x, to.y, kind === "projectile" ? 22 : 16, { fromX: from.x, fromY: from.y, toX: to.x, toY: to.y, fromHeight: combatVisualHeight(game, attacker), toHeight: combatVisualHeight(game, target), ...isUnit(attacker) ? { sourceId: attacker.id, actionMode: profile.origin === "spell" ? "cast" : "attack" } : {} });
  addHitEffect(game, target, taken, attacker);
}
function addHitEffect(game, target, taken, striker, attackKind, visualOrigin) {
  attackKind ??= striker ? isUnit(striker) && weaponRules(game, striker).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD ? "melee" : innateMissile(striker.kind) : void 0;
  const origin = visualOrigin ?? striker;
  const deck = isUnit(target) && target.deck;
  const hull = deck ? game.units.find((unit) => unit.id === deck.shipId) : void 0;
  addEffect(game, "hit", target.x, target.y, 14, { unitId: target.id, damage: taken, ...attackKind ? { attackKind } : {}, ...striker ? { sourceKind: striker.kind } : {}, ...origin ? { fromX: origin.x, fromY: origin.y } : {}, ...deck && hull ? { targetDeck: { ...deck, heading: hull.sailing?.heading ?? 0 }, toHeight: combatVisualHeight(game, target) } : {}, ...isUnit(target) ? { targetKind: target.kind, targetHpAfter: target.hp, targetMaxHp: target.maxHp, targetRadius: target.radius, targetUnitClass: unitClassOf(target, game) } : {} });
}
function buildingTargetDamage(attacker, target, damage) {
  if (isUnit(attacker) || !isUnit(target) || target.owner !== "neutral") return damage;
  return damage * (BUILDING_DEFS[attacker.kind]?.neutralDamageMultiplier ?? 1);
}
function attackDamageAgainstTarget(game, attacker, target, damage) {
  if (!isUnit(attacker) || !isUnit(target)) return damage;
  const slayer = unitRules(game, attacker).casterSlayer;
  const dealt = slayer && isCasterOrSummoned(target) ? Math.round(damage * slayer) : damage;
  if (!target.effects.some((effect) => effect.type === "scorch")) return dealt;
  if (attacker.kind === "emberRavager") return dealt + 7;
  if (attacker.kind === "cinderRunner") return dealt + 5;
  return dealt;
}
function stanceBlow(attacker, target, dealt) {
  if (!attacker.stance || target.hp <= 0) return;
  const strength = blowStrength(dealt, target);
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  shove(target, dx, dy, strength);
  if (attacker.stance === "shock") shove(attacker, dx, dy, lungeStrength(attacker, strength));
}
function isCasterOrSummoned(unit) {
  return unit.expiresTick !== void 0 || hasSpell(unit.kind);
}
function applyAttackStatusEffects(game, attacker, target, sourceKind) {
  if (sourceKind === "sparkArcher" && isUnit(target) && !target.deck && unitMover(target.kind) === "land" && sparkIgnites(attacker.id, target.id, game.tick)) {
    addEffect(game, "burningGround", target.x, target.y, SPARK_FIRE.duration, {
      owner: attacker.owner,
      unitId: attacker.id,
      sourceKind,
      damageProfile: DAMAGE_PROFILES.BURNING,
      damage: SPARK_FIRE.damage,
      radius: SPARK_FIRE.radius,
      tickEvery: SPARK_FIRE.tickEvery
    });
  }
  if (!isUnit(attacker)) return;
  const rules = unitRules(game, attacker);
  if (rules.splash) {
    const share = Math.max(1, Math.round(attacker.attackDamage * SPLASH_SHARE));
    const burned = [];
    forEachNearbyUnit(game, target, SPLASH_RADIUS, (unit) => {
      if (unit !== target && unit.hp > 0 && distance(unit, target) <= SPLASH_RADIUS && areEnemyOwners(game, attacker.owner, unit.owner)) burned.push(unit);
    });
    for (const unit of burned) applyDamage(game, attacker, unit, share, void 0, void 0, 0, unitAttackDamageProfile(game, attacker));
    addEffect(game, "flameBurn", target.x, target.y, 20);
  }
  if (!isUnit(target)) return;
  if (rules.slowOnHit) setStatus(target, { type: "slow", remaining: SLOW_TICKS });
  if (rules.poisonOnHit) setStatus(target, { type: "poison", remaining: POISON_TICKS, sourceId: attacker.id, sourceOwner: attacker.owner });
}
function applyDamage(game, attacker, target, damage, hullShare, impact, blastRadius = 0, profile = isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind), armorAlreadyApplied = false, existingStatus = false) {
  if (isUnit(attacker) && isInCabin(attacker)) return void 0;
  if (isUnit(target) && isCabinProtected(game, target) && !existingStatus) return void 0;
  if ("invulnerable" in target && target.invulnerable) return void 0;
  if (isObstacle(target)) {
    const hpBefore2 = target.hp;
    target.hp -= damage;
    game.observer?.hit(attacker, target, damage, hpBefore2);
    return damage;
  }
  const impactDamage = damage;
  const resolved = isUnit(target) ? resolveUnitDamage(game, target, damage, profile, game.veteranFrame?.get(target.id)?.reductions, { armorAlreadyApplied }) : void 0;
  if (resolved?.blocked) return void 0;
  const taken = resolved?.damage ?? damage;
  const hpBefore = target.hp;
  target.hp -= taken;
  if (isUnit(target) && shipProfile(target)) {
    damageShipGangway(target, taken);
    damageShipParts(game, target, impact ?? strikePoint(attacker, target), taken, blastRadius);
    if (target.hp > 0) {
      applyDerivedUnitStats(game, target);
      updateCabinPassengers(game);
      for (const passenger of shipPassengers(game.units, target)) if (passenger.hp > 0 && isInCabin(passenger) && !isCabinProtected(game, passenger)) applyDamage(game, attacker, passenger, taken * 0.35, 0, impact, 0, profile);
    }
  }
  if (hpBefore > 0 && isUnit(target)) {
    if (shipProfile(target) && game.deckDamageBatch) {
      const entry = game.deckDamageBatch.get(target.id) ?? { ship: target, direct: 0, collateral: 0 };
      entry.direct += impactDamage;
      game.deckDamageBatch.set(target.id, entry);
    }
    const hull = target.deck && game.units.find((ship) => ship.id === target.deck.shipId && ship.hp > 0);
    if (hull && areEnemyOwners(game, attacker.owner, hull.owner)) {
      const collateral = impactDamage * (hullShare ?? deckHullDamageShare(game, attacker));
      if (game.deckDamageBatch) {
        const entry = game.deckDamageBatch.get(hull.id) ?? { ship: hull, direct: 0, collateral: 0, source: attacker };
        if (collateral > entry.collateral) {
          entry.collateral = collateral;
          entry.source = attacker;
          entry.profile = profile;
        }
        game.deckDamageBatch.set(hull.id, { ...entry, impact: { x: target.x, y: target.y }, blastRadius });
      } else if (collateral > 0) applyDamage(game, attacker, hull, collateral, 0, target, 0, profile);
    }
  }
  game.observer?.hit(attacker, target, taken, hpBefore);
  if (hpBefore > 0 && isUnit(target) && target.owner === "neutral") triggerNeutralAssist(game, target, attacker);
  if (hpBefore > 0 && isPlayerId(target.owner)) triggerPlayerAggro(game, target, attacker);
  if (hpBefore > 0 && target.hp <= 0) {
    recordKill(game, attacker, target);
  }
  return taken;
}
function withDeckDamageBatch(game, body) {
  if (game.deckDamageBatch) {
    body();
    return;
  }
  const batch = /* @__PURE__ */ new Map();
  game.deckDamageBatch = batch;
  try {
    body();
  } finally {
    delete game.deckDamageBatch;
  }
  for (const { ship, direct, collateral, source, impact, blastRadius, profile } of batch.values()) {
    if (source && ship.hp > 0 && collateral > direct) applyDamage(game, source, ship, collateral - direct, 0, impact, blastRadius, profile);
  }
}
function navalCombatTarget(game, attacker, target, crewRange = Infinity) {
  if (!isUnit(target) || !shipProfile(target)) return target;
  const home = isUnit(attacker) && attacker.deck && unitRules(game, attacker).attackRange <= RANGED_ATTACK_RANGE_THRESHOLD ? game.units.find((ship) => ship.id === attacker.deck.shipId) : void 0;
  const passengers = home && home.id !== target.id && decksCanTransfer(home, target, attacker) ? [...shipPassengers(game.units, target), ...shipPassengers(game.units, home)] : shipPassengers(game.units, target);
  const crew = passengers.filter((unit) => unit.hp > 0 && !isInCabin(unit) && areEnemyOwners(game, attacker.owner, unit.owner) && (crewRange === Infinity || distanceSquared(attacker, unit) <= crewRange * crewRange) && (isUnit(attacker) ? canReach(game.map, attacker, unit, game.units) : distance(attacker, unit) <= attacker.attackRange));
  let best, bestScore = -Infinity;
  for (const unit of crew) {
    const score = targetPriorityScore(game, attacker.owner, unit, distanceSquared(attacker, unit), isUnit(attacker) ? attacker : void 0);
    if (score > bestScore) {
      best = unit;
      bestScore = score;
    }
  }
  return best ?? crew[0] ?? target;
}
function triggerNeutralAssist(game, damagedNeutral, attacker) {
  if (!areEnemyOwners(game, damagedNeutral.owner, attacker.owner)) return;
  const origin = neutralHomeOrCurrentPoint(damagedNeutral);
  for (const unit of game.units) {
    if (unit.owner !== "neutral" || unit.hp <= 0) continue;
    if (distance(unit, damagedNeutral) > NEUTRAL_ASSIST_RANGE) continue;
    if (!canReach(game.map, unit, attacker, game.units)) continue;
    const responseOrigin = neutralResponseOrigin(unit) ?? origin;
    if (distance(attacker, responseOrigin) > NEUTRAL_DAMAGE_RESPONSE_RANGE) continue;
    if (neutralHasValidAttackTarget(game, unit) && unit.order.type === "attack") {
      if (incomingThreatOutranks(game, unit, unit.order.targetId, attacker, damagedNeutral)) unit.order = { ...unit.order, targetId: attacker.id };
    } else unit.order = { type: "attack", targetId: attacker.id, leashX: origin.x, leashY: origin.y };
  }
}
function triggerPlayerAggro(game, victim, attacker) {
  if (!areEnemyOwners(game, victim.owner, attacker.owner) || attacker.hp <= 0 || findTarget(game, attacker.id) !== attacker) return;
  if (isUnit(victim)) takeUpAttacker(game, victim, attacker, victim);
  const reach = HELP_CALL_RANGE + (isUnit(victim) ? 0 : victim.radius);
  forEachNearbyUnit(game, victim, reach, (ally) => {
    if (ally === victim || ally.owner !== victim.owner || distance(ally, victim) > reach) return;
    takeUpAttacker(game, ally, attacker, victim);
  });
}
function takeUpAttacker(game, unit, attacker, victim) {
  if (unit.hp <= 0 || unit.kind === "worker" || unit.attackDamage <= 0 || !canReach(game.map, unit, attacker, game.units)) return;
  const order = unit.order;
  if (shipProfile(unit) && order.type === "idle") return;
  if (order.type === "idle") {
    if (!unit.orderQueue?.length) unit.order = { type: "attack", targetId: attacker.id, leashX: unit.x, leashY: unit.y };
    return;
  }
  if (order.type === "attackMove") {
    if (!order.targetId || incomingThreatOutranks(game, unit, order.targetId, attacker, victim)) unit.order = { ...order, targetId: attacker.id };
    return;
  }
  const selfDirected = order.type === "attack" && order.leashX !== void 0;
  if (selfDirected && incomingThreatOutranks(game, unit, order.targetId, attacker, victim)) unit.order = { ...order, targetId: attacker.id };
}
function incomingThreatOutranks(game, unit, targetId, attacker, victim) {
  if (targetId === attacker.id) return false;
  const current = findTarget(game, targetId);
  if (!current || current.hp <= 0 || !canReach(game.map, unit, current, game.units)) return true;
  const incoming = combatTargetScore(attacker, targetGap(unit, attacker), victim.id === unit.id ? "self" : "ally", projectedHpAfterPendingProjectiles(game, unit.owner, attacker));
  return shouldSwitchCombatTarget(targetPriorityScore(game, unit.owner, current, targetGap(unit, current) ** 2, unit), incoming);
}
function automaticCombatTarget(game, unit, current, navalFrame = true) {
  if (unit.cooldown > 0) return current;
  const next = nearestEnemyTarget(game, unit, Math.max(AUTO_ACQUIRE_RANGE, unit.attackRange), navalFrame);
  if (!next || next.id === current.id) return current;
  return shouldSwitchCombatTarget(
    targetPriorityScore(game, unit.owner, current, targetGap(unit, current, navalFrame) ** 2, unit),
    targetPriorityScore(game, unit.owner, next, targetGap(unit, next, navalFrame) ** 2, unit)
  ) ? next : current;
}
function neutralHasValidAttackTarget(game, unit) {
  if (unit.order.type !== "attack") return false;
  const target = findTarget(game, unit.order.targetId);
  if (!target || target.hp <= 0 || !areEnemyOwners(game, unit.owner, target.owner)) return false;
  const responseOrigin = neutralResponseOrigin(unit);
  if (responseOrigin && distance(target, responseOrigin) > NEUTRAL_DAMAGE_RESPONSE_RANGE) return false;
  return true;
}
function neutralResponseOrigin(unit) {
  if (unit.order.type === "attack" && unit.order.leashX !== void 0 && unit.order.leashY !== void 0) return { x: unit.order.leashX, y: unit.order.leashY };
  if (unit.homeX !== void 0 && unit.homeY !== void 0) return { x: unit.homeX, y: unit.homeY };
  return void 0;
}
function neutralHomeOrCurrentPoint(unit) {
  return unit.homeX !== void 0 && unit.homeY !== void 0 ? { x: unit.homeX, y: unit.homeY } : { x: unit.x, y: unit.y };
}
function recordKill(game, attacker, target) {
  if (isUnit(target) && shipProfile(target)) for (const passenger of shipPassengers(game.units, target)) {
    if (passenger.hp > 0) {
      passenger.hp = 0;
      recordKill(game, attacker, passenger);
    }
  }
  if (!areEnemyOwners(game, attacker.owner, target.owner)) return;
  const attackerOwner = attacker.owner;
  if (isPlayerId(attackerOwner) || attackerOwner === "neutral") {
    incrementStat(game.match.stats.unitsKilled, attackerOwner, isUnit(target) ? 1 : 0);
  }
  if (isUnit(attacker) && isUnit(target)) {
    attacker.kills += 1;
    awardKillXp(game, attacker, target);
    if (attacker.owner === "neutral" && isPlayerId(target.owner)) {
      incrementStat(game.match.stats.unitsKilledByNeutral, target.owner, 1);
    }
    if (isPlayerId(attacker.owner) && isMercenaryUnitKind(attacker.kind) && areEnemyOwners(game, attacker.owner, target.owner)) {
      incrementStat(game.match.stats.mercenaryKills, attacker.owner, 1);
    }
  }
  if (isUnit(target) && target.owner === "neutral" && isPlayerId(attackerOwner)) {
    incrementStat(game.match.stats.neutralUnitsKilled, attackerOwner, 1);
    awardNeutralGoldBounty(game, attackerOwner, target);
  }
  if (!isUnit(target) && isPlayerId(attackerOwner)) {
    incrementStat(game.match.stats.buildingsDestroyed, attackerOwner, 1);
    if (target.kind !== "townHall") incrementStat(game.match.stats.nonBaseBuildingsDestroyed, attackerOwner, 1);
  }
}
function addEffect(game, type, x, y, remaining, vectors) {
  game.effects.push({ id: `effect-${game.nextId}`, type, x, y, remaining, duration: remaining, ...vectors, ...vectors?.actionMode ? { actionTick: game.tick } : {} });
  game.nextId += 1;
}
function isUnit(entity) {
  return "order" in entity;
}
function isObstacle(entity) {
  return "along" in entity;
}
function awardKillXp(game, attacker, target) {
  if (attacker.owner === "neutral" || !areEnemyOwners(game, attacker.owner, target.owner)) return;
  attacker.xp += killXpReward(unitRules(game, target), target.level);
  applyXpLevel(game, attacker);
}
function awardNeutralGoldBounty(game, owner, target) {
  const bounty = unitRules(game, target).goldBounty ?? 0;
  if (bounty <= 0) return;
  playerState(game, owner).gold = addGold(playerState(game, owner).gold, bounty);
  addEffect(game, "goldBounty", target.x, target.y, seconds(1.2), { owner, amount: bounty });
}
function applyXpLevel(game, unit) {
  if (unit.variant !== void 0 && game.variants?.[unit.variant]?.heroic) return;
  const nextLevel = xpStarThresholds(unitRules(game, unit)).filter((threshold) => unit.xp >= threshold).length;
  if (nextLevel <= unit.level) return;
  unit.level = Math.min(MAX_UPGRADE_LEVEL, nextLevel);
  if (unit.level === 3 && unit.owner !== "neutral" && unit.expiresTick === void 0 && !unit.veteranSkillChoices) {
    unit.veteranSkillChoices = rollVeteranSkillChoices(unit.kind, unit.id, `${game.map.terrain?.ecology?.seed ?? game.map.id}:${game.tick}`, unitClassOf(unit, game));
  }
  applyDerivedUnitStats(game, unit);
}
function applyDerivedUnitStats(game, unit) {
  const previousMaxHp = unit.maxHp;
  const base = nonStarUnitStats(game, unit);
  const multiplier = 1 + Math.min(MAX_UPGRADE_LEVEL, Math.max(0, unit.level)) * VETERANCY_GAIN_PER_STAR;
  const heavy = itemsFor(game, unit).some((item) => ITEM_DEFS[item.kind].span === 4);
  unit.bodyRadius = unitRules(game, unit).radius * (isShipKind(unit.kind) ? SHIP_SIZE_MULTIPLIER : 1);
  unit.radius = unit.bodyRadius;
  const veterans = game.veteranFrame?.get(unit.id);
  unit.attackDamage = Math.round(base.attackDamage);
  unit.maxHp = Math.round(base.maxHp * multiplier);
  unit.speed = base.speed * (heavy ? 0.45 : 1) * (veterans?.moveSpeedMultiplier ?? 1);
  unit.attackRange = base.attackRange * (veterans?.attackRangeMultiplier ?? 1);
  unit.hp = Math.min(unit.maxHp, Math.max(1, unit.hp + unit.maxHp - previousMaxHp));
}
function nonStarUnitStats(game, unit) {
  const stats = weaponRules(game, unit);
  unit.attackCooldown = stats.attackCooldown;
  let attackDamage = stats.attackDamage;
  let maxHp = stats.hp;
  let speed = stats.speed;
  let attackRange = stats.attackRange;
  if (!isPlayerId(unit.owner)) return { attackDamage, maxHp, speed, attackRange };
  const upgrades = playerState(game, unit.owner).upgrades;
  for (const upgradeKind of UPGRADE_KINDS) {
    const upgrade = UPGRADE_DEFS[upgradeKind];
    if (!upgrade.affectedUnitKinds.includes(unit.kind)) continue;
    for (let level = 0; level < (upgrades[upgradeKind] ?? 0); level += 1) {
      const levelDef = upgrade.levels[level];
      if (!levelDef) throw new Error(`${upgradeKind} missing level ${level + 1}`);
      if (levelDef.attackMultiplier) attackDamage = stats.attackDamage * levelDef.attackMultiplier;
      if (levelDef.maxHpMultiplier) maxHp = stats.hp * levelDef.maxHpMultiplier;
      if (levelDef.speedMultiplier) speed = roundUnitScalar(stats.speed * levelDef.speedMultiplier);
      if (levelDef.attackRangeMultiplier) attackRange = Math.round(stats.attackRange * levelDef.attackRangeMultiplier);
    }
  }
  if (itemsFor(game, unit).some((item) => item.kind === "speedBoots" && itemEquipped(game, unit, item))) speed = roundUnitScalar(speed * BOOTS_SPEED);
  return { attackDamage, maxHp, speed, attackRange };
}
function roundUnitScalar(value) {
  return Math.round(value * 100) / 100;
}
function updateSupplyState(game) {
  for (const owner of game.activePlayers) {
    const player = playerState(game, owner);
    player.supplyCap = game.buildings.filter((building) => building.owner === owner && building.complete).reduce((total, building) => total + BUILDING_DEFS[building.kind].supplyProvided, 0);
    player.supplyUsed = projectedSupplyUsed(game, owner);
  }
}
function projectedSupplyUsed(game, owner) {
  const unitSupply = game.units.filter((unit) => unit.owner === owner).reduce((total, unit) => total + unitRules(game, unit).supplyUsed + (unit.cargo ? cargoSupply(game, unit) : 0), 0);
  const queuedSupply = game.buildings.filter((building) => building.owner === owner).flatMap((building) => building.queue).reduce((total, job) => total + UNIT_DEFS[job.unitKind].supplyUsed, 0);
  return unitSupply + queuedSupply;
}
function unitsByIds(game, unitIds, owner) {
  const unit = ownUnitLookup(game.units, owner, unitIds.length);
  const units = unitIds.map((id) => unit(id));
  const missing = units.findIndex((unit2) => !unit2);
  if (missing >= 0) throw new Error(`Unknown ${owner} unit ${unitIds[missing]}`);
  return units;
}
function buildingsByIds(game, buildingIds, owner) {
  const buildings = buildingIds.map((id) => game.buildings.find((building) => building.id === id && building.owner === owner));
  const missing = buildings.findIndex((building) => !building);
  if (missing >= 0) throw new Error(`Unknown ${owner} building ${buildingIds[missing]}`);
  return buildings;
}
function spendGold(game, owner, amount) {
  spend(playerState(game, owner), amount);
  incrementStat(game.match.stats.goldSpent, owner, amount);
}
function spend(player, amount) {
  if (player.gold < amount) throw new Error(`Need ${amount} gold`);
  player.gold = addGold(player.gold, -amount);
}
function playerState(game, owner) {
  const player = game.players[owner];
  if (!player) throw new Error(`Unknown player ${owner}`);
  return player;
}
function incrementStat(record, owner, amount) {
  record[owner] = (record[owner] ?? 0) + amount;
}
function canSupply(game, owner, unitKind) {
  return projectedSupplyUsed(game, owner) + UNIT_DEFS[unitKind].supplyUsed <= playerState(game, owner).supplyCap;
}
function isMercenaryUnitKind(kind) {
  return MERCENARY_UNIT_KINDS.includes(kind);
}
function combatUnits(game, owner) {
  return game.units.filter((unit) => unit.owner === owner && unit.kind !== "worker");
}
function completeBuildings(game, owner, kind) {
  return game.buildings.filter((building) => building.owner === owner && building.kind === kind && building.complete);
}
function nearestCompleteTownHall(game, owner, x, y) {
  if (!isPlayerId(owner)) return void 0;
  return (game.miningFrame?.townHalls.get(owner) ?? completeBuildings(game, owner, "townHall")).filter((building) => sameGround(game.map, { x, y }, building)).reduce((best, building) => {
    if (!best) return building;
    return distance({ x, y }, building) < distance({ x, y }, best) ? building : best;
  }, void 0);
}
function nearestEnemyInRange(game, unit, range) {
  const limit = range * range;
  return firstNearbyUnit(game, unit, range, (candidate) => areEnemyOwners(game, unit.owner, candidate.owner) && distanceSquared(unit, candidate) <= limit);
}
function nearestEnemyUnit(game, owner, x, y, range) {
  const point = { x, y };
  const limit = range * range;
  let best;
  let bestScore = Number.NEGATIVE_INFINITY;
  forEachNearbyEnemyUnit(game, owner, point, range, (unit) => {
    if (isInCabin(unit)) return;
    const candidateDistance = distanceSquared(unit, point);
    if (candidateDistance > limit) return;
    const score = targetPriorityScore(game, owner, unit, candidateDistance);
    if (score <= bestScore) return;
    best = unit;
    bestScore = score;
  });
  return best;
}
function nearestEnemyTarget(game, unit, range, navalFrame = true) {
  if (unit.attackDamage <= 0) return void 0;
  return nearestEnemyTargetFromPoint(game, unit.owner, unit, range, unit, void 0, navalFrame);
}
function targetGap(from, target, navalFrame = true) {
  if (!navalFrame && isUnit(target)) return hypot2(target.x - from.x, target.y - from.y);
  return strikeGap(from, target);
}
function nearestEnemyTargetFromPoint(game, owner, point, range, attacker, accepts, navalFrame = true) {
  const limit = range * range;
  let best;
  let bestScore = Number.NEGATIVE_INFINITY;
  forEachNearbyEnemyUnit(game, owner, point, range + (navalFrame ? game.shipReachPadding ?? shipReachPadding(game.units) : 0), (candidate) => {
    if (navalFrame && isInCabin(candidate)) return;
    if (navalFrame && !automaticTargetAllowed(game.units, owner, candidate)) return;
    if (navalFrame && shipProfile(candidate) && shipPassengers(game.units, candidate).some((unit) => unit.hp > 0 && !isInCabin(unit) && (!attacker || canReach(game.map, attacker, unit, game.units)))) return;
    if (accepts && !accepts(candidate)) return;
    const candidateDistance = navalFrame && isShipKind(candidate.kind) ? distanceToHull(candidate, point) ** 2 : distanceSquared(point, candidate);
    if (candidateDistance > limit) return;
    if (attacker && !automaticCandidateReachable(game, attacker, candidate, navalFrame)) return;
    const score = targetPriorityScore(game, owner, candidate, candidateDistance, attacker);
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  });
  forEachNearbyEnemyBuilding(game, owner, point, range + MAX_BUILDING_RADIUS, (building) => {
    if (accepts && !accepts(building)) return;
    const gap = targetGap(point, building);
    if (gap > range) return;
    if (attacker && !automaticCandidateReachable(game, attacker, building, navalFrame)) return;
    const score = targetPriorityScore(game, owner, building, gap * gap, attacker);
    if (score > bestScore) {
      best = building;
      bestScore = score;
    }
  });
  return best;
}
function shipReachPadding(units) {
  let padding = 0;
  for (const unit of shipsIn(units)) {
    const profile = shipProfile(unit);
    if (profile) padding = Math.max(padding, ...profile.hull.map((p) => Math.hypot(p.x, p.y)));
  }
  return padding;
}
function automaticCandidateReachable(game, unit, candidate, navalFrame = true) {
  if ((navalFrame || game.map.terrain) && !canReach(game.map, unit, candidate, game.units)) return false;
  if (unit.owner !== "neutral") return true;
  const origin = neutralResponseOrigin(unit);
  return !origin || distance(candidate, origin) <= NEUTRAL_DAMAGE_RESPONSE_RANGE;
}
function targetPriorityScore(game, owner, target, distanceSq, attacker) {
  const victimId = combatVictimId(target);
  const victim = victimId ? findTarget(game, victimId) : void 0;
  const threat = victim && !areEnemyOwners(game, owner, victim.owner) ? victim === attacker ? "self" : "ally" : "none";
  return combatTargetScore(target, Math.sqrt(distanceSq), threat, projectedHpAfterPendingProjectiles(game, owner, target));
}
function projectedHpAfterPendingProjectiles(game, attackerOwner, target) {
  let pendingDamage = 0;
  for (const projectile of projectilesAt(game, target.id)) if (projectile.owner === attackerOwner && !projectile.weapon) pendingDamage += projectile.damage;
  return target.hp - pendingDamage;
}
const projectilesByTarget = /* @__PURE__ */ new WeakMap();
const NO_PROJECTILES = [];
function projectilesAt(game, targetId) {
  const projectiles = game.projectiles;
  let index = projectilesByTarget.get(projectiles);
  if (!index || index.indexed > projectiles.length) projectilesByTarget.set(projectiles, index = { indexed: 0, byTarget: /* @__PURE__ */ new Map() });
  for (; index.indexed < projectiles.length; index.indexed += 1) {
    const projectile = projectiles[index.indexed];
    const atTarget = index.byTarget.get(projectile.targetId);
    if (atTarget) atTarget.push(projectile);
    else index.byTarget.set(projectile.targetId, [projectile]);
  }
  return index.byTarget.get(targetId) ?? NO_PROJECTILES;
}
function findTarget(game, targetId) {
  const target = game.entityById?.get(targetId) ?? game.units.find((unit) => unit.id === targetId) ?? game.buildings.find((building) => building.id === targetId);
  return target && isUnit(target) && isInCabin(target) ? void 0 : target;
}
function findStrikeTarget(game, targetId) {
  return findTarget(game, targetId) ?? game.obstacles?.find((obstacle) => obstacle.id === targetId);
}
function removeExpiredUnits(game) {
  if (!game.units.some((unit) => unit.expiresTick !== void 0 && unit.expiresTick <= game.tick)) return;
  const expiredUnits = game.units.filter((unit) => unit.expiresTick !== void 0 && unit.expiresTick <= game.tick);
  dropItemsFromDeadUnits(game, expiredUnits);
  const expiredIds = new Set(expiredUnits.map((unit) => unit.id));
  game.units = game.units.filter((unit) => !expiredIds.has(unit.id));
  invalidateSeparationFrame(game);
  updateSupplyState(game);
}
function removeDead(game) {
  if (!game.units.some((unit) => unit.hp <= 0) && !game.buildings.some((building) => building.hp <= 0)) {
    if (game.obstacles?.some((obstacle) => obstacle.hp <= 0)) game.obstacles = game.obstacles.filter((obstacle) => obstacle.hp > 0);
    return;
  }
  const deadUnits = game.units.filter((unit) => unit.hp <= 0);
  const wrecks = new Set(deadUnits.filter((unit) => shipProfile(unit)).map((unit) => unit.id));
  if (wrecks.size) {
    for (const passenger of game.units) if (passenger.deck && wrecks.has(passenger.deck.shipId) && passenger.hp > 0) {
      passenger.hp = 0;
      deadUnits.push(passenger);
    }
  }
  const deadBuildings = game.buildings.filter((building) => building.hp <= 0);
  for (const unit of deadUnits) incrementStat(game.match.stats.unitsLost, unit.owner, 1);
  const deathAppearance = new Map(deadUnits.map((unit) => {
    const right = activeItem(game, unit, "right"), left = activeItem(game, unit, "left");
    return [unit.id, {
      equipmentCaptured: true,
      ...unit.deck ? { deck: { ...unit.deck } } : {},
      ...right?.kind === "greatSword" ? { rightItemKind: "greatSword" } : right?.kind === "issuedWeapon" ? { rightItemKind: "issuedWeapon", ...right.weaponKind ? { weaponKind: right.weaponKind } : {} } : {},
      ...left?.kind === "roundShield" ? { leftItemKind: "roundShield" } : {},
      ...game.players[unit.owner]?.race ? { ownerRace: game.players[unit.owner].race } : {}
    }];
  }));
  dropItemsFromDeadUnits(game, deadUnits);
  for (const unit of deadUnits) if (!(unit.deck && wrecks.has(unit.deck.shipId))) {
    (game.corpses ??= []).push({
      id: `corpse-${unit.id}-${game.tick}`,
      unitId: unit.id,
      kind: unit.kind,
      owner: unit.owner,
      x: unit.x,
      y: unit.y,
      radius: unit.radius,
      diedAtTick: game.tick,
      ...unit.variant ? { variant: unit.variant } : {},
      ...deathAppearance.get(unit.id)
    });
  }
  if (deadUnits.length) {
    game.units = game.units.filter((unit) => unit.hp > 0);
    invalidateSeparationFrame(game);
  }
  if (deadBuildings.length) game.buildings = game.buildings.filter((building) => building.hp > 0);
  if (game.obstacles?.some((obstacle) => obstacle.hp <= 0)) game.obstacles = game.obstacles.filter((obstacle) => obstacle.hp > 0);
  if (deadUnits.length > 0 || deadBuildings.length > 0) updateSupplyState(game);
}
function dropItemsFromDeadUnits(game, deadUnits) {
  if (deadUnits.length === 0) return;
  invalidateItemIndex(game.items);
  const deadById = new Map(deadUnits.map((unit) => [unit.id, unit]));
  for (const item of game.items) {
    if (!item.carrierId && !item.shipId) continue;
    const dead = deadById.get(item.carrierId ?? item.shipId);
    if (!dead) continue;
    delete item.carrierId;
    delete item.slot;
    delete item.shipId;
    delete item.holdSlot;
    delete item.mountId;
    delete item.aim;
    item.x = dead.x;
    item.y = dead.y;
  }
}
function updateVictory(game) {
  if (game.match.winner || game.scriptedVictory) return;
  const activeTeams = /* @__PURE__ */ new Set();
  for (const owner of game.activePlayers) activeTeams.add(teamKey(game, owner));
  let winnerTeam;
  let winner = null;
  for (const building of game.buildings) {
    const team = teamKey(game, building.owner);
    if (!activeTeams.has(team)) continue;
    if (winnerTeam !== void 0 && team !== winnerTeam) return;
    if (winnerTeam === void 0) {
      winnerTeam = team;
      winner = building.owner;
    }
  }
  game.match.winner = winner;
  game.match.endedAtTick = game.tick;
}
export function spawnVariantUnit(game, owner, variant, x, y, id) {
  const rules = game.variants?.[variant];
  if (!rules) throw new Error(`Unknown unit variant ${variant}`);
  const unitId = id ?? `unit-${owner}-${variant}-${game.nextId}`;
  if (id === void 0) game.nextId += 1;
  else if (game.units.some((unit2) => unit2.id === id) || game.buildings.some((building) => building.id === id)) throw new Error(`Duplicate unit id ${id}`);
  const unit = createUnit(unitId, owner, rules.base, x, y);
  unit.variant = variant;
  unit.hp = rules.hp;
  takeVariantFrame(unit, rules);
  applyUnitUpgrades(game, unit);
  game.units.push(unit);
  updateSupplyState(game);
  return unit;
}
export function refreshUnitStats(game, unit) {
  const rules = unitRules(game, unit);
  const share = unit.hp / Math.max(1, unit.maxHp);
  if (unit.variant !== void 0) takeVariantFrame(unit, rules);
  if (isPlayerId(unit.owner)) applyDerivedUnitStats(game, unit);
  unit.hp = Math.max(1, Math.min(unit.maxHp, Math.round(unit.maxHp * share)));
}
function takeVariantFrame(unit, rules) {
  unit.maxHp = rules.hp;
  unit.hp = Math.min(unit.hp, rules.hp);
  unit.speed = rules.speed;
  unit.radius = rules.radius * (isShipKind(unit.kind) ? SHIP_SIZE_MULTIPLIER : 1);
  unit.bodyRadius = unit.radius;
  unit.attackDamage = rules.attackDamage;
  unit.attackRange = rules.attackRange;
  unit.attackCooldown = rules.attackCooldown;
}
export function strikeUnit(game, source, target, damage, style) {
  const attacker = "hp" in source ? source : findTarget(game, source.id) ?? scriptSource(source);
  const dealt = Math.max(1, Math.round(damage));
  if (style === "spell") {
    const taken = applyDamage(game, attacker, target, dealt, void 0, void 0, 0, DAMAGE_PROFILES.ARCANE);
    if (taken !== void 0) addHitEffect(game, target, taken);
    return;
  }
  const baseProfile = isUnit(attacker) ? unitAttackDamageProfile(game, attacker) : attackDamageProfile(attacker.kind);
  applyAttackDamage(game, attacker, target, dealt, style === "ranged" ? RANGED_ATTACK_RANGE_THRESHOLD + 1 : 0, { ...baseProfile, delivery: style });
}
function scriptSource(source) {
  const stand = projectileAttacker({ id: source.id, owner: source.owner, attackerId: source.id, targetId: source.id, fromX: source.x, fromY: source.y, toX: source.x, toY: source.y, damage: 0, remaining: 0, duration: 0 });
  return { ...stand, kind: "farm" };
}
export function addWorldEffect(game, type, x, y, ticks, vectors) {
  addEffect(game, type, x, y, ticks, vectors);
}
export function removeUnit(game, unitId) {
  const unit = game.units.find((candidate) => candidate.id === unitId);
  if (!unit) return;
  dropItemsFromDeadUnits(game, [unit]);
  game.units = game.units.filter((candidate) => candidate.id !== unitId);
  invalidateSeparationFrame(game);
  game.entityById?.delete(unitId);
  if (unit.veteranSkill) {
    game.unitSpatial = createSpatialIndex(game.units, 320);
    refreshVeteranFrame(game);
  }
  updateSupplyState(game);
}
function isPlayerId(owner) {
  return owner !== "neutral";
}
function areEnemyOwners(game, a, b) {
  if (a === b) return false;
  if (a === "neutral" || b === "neutral") return a !== "neutral" || b !== "neutral";
  return game.teams[a] !== game.teams[b];
}
function teamKey(game, owner) {
  return owner === "neutral" ? "neutral" : game.teams[owner] ?? owner;
}
const MAX_BUILDING_RADIUS = Math.max(...Object.values(BUILDING_DEFS).map((def) => def.radius));
const MAX_UNIT_RADIUS = Math.max(...Object.values(UNIT_DEFS).map((def) => def.radius));
function walkEnded(game, unit, goal, within) {
  const map = game.map;
  const travel = unit.order;
  if ((travel.type === "move" || travel.type === "attackMove") && travel.deckShipId && travel.deckShipId !== unit.deck?.shipId && game.units.some((ship) => ship.id === travel.deckShipId && ship.hp > 0)) return false;
  if (unit.deck && (travel.type === "move" || travel.type === "attackMove") && !travel.deckShipId && isOpenGround(map, goal.x, goal.y, "land")) return false;
  if (unit.deck) {
    const ship = game.units.find((ship2) => ship2.id === unit.deck.shipId);
    if (!ship) return true;
    const order = unit.order;
    if ((order.type === "move" || order.type === "attackMove") && order.deckShipId && order.deckShipId !== ship.id && game.units.some((target) => target.id === order.deckShipId && target.hp > 0)) return false;
    const local = deckPlacement(ship, unit, game.units, worldToLocal(ship, deckGoal(unit, ship, goal, game.units)), false);
    return !local || distance(unit, localToWorld(ship, local)) < within || restsAgainstArrivedFriend(game, unit, goal, localToWorld(ship, local));
  }
  if (shipProfile(unit)) {
    if (travel.type === "move" && travel.heading !== void 0 && Math.abs(headingDifference(unit.sailing.heading, travel.heading)) > 1e-6) return false;
    const route = unit.sailing?.route;
    if (map.terrain && route && route.goalX === goal.x && route.goalY === goal.y) return !route.partial && route.points.length === 0 && distance(unit, route.end) < within;
    const end2 = nearestShipPose(map, unit, goal);
    return !end2 || distance(unit, end2) < within;
  }
  if (!map.terrain) return distance(unit, goal) < within || restsAgainstArrivedFriend(game, unit, goal, goal);
  const mover = unitMover(unit.kind);
  const point = isWalkable(map, goal.x, goal.y, mover) ? goal : walkableGoal(map, goal.x, goal.y, mover);
  const end = walkDestination(map, unit, point, mover);
  return distance(unit, end) < within || restsAgainstGoalBody(game, unit, point, within) || restsAgainstArrivedFriend(game, unit, goal, end);
}
function arrive(unit, goal) {
  unit.order = { type: "idle" };
  unit.arrivedAt = { x: goal.x, y: goal.y };
}
function restsAgainstGoalBody(game, unit, goal, within) {
  if (distance(unit, goal) > 2 * (MAX_BUILDING_RADIUS + MAX_UNIT_RADIUS) + within + 2) return false;
  let resting = false;
  forEachNearbyBuilding(game, goal, MAX_BUILDING_RADIUS + unit.radius + within, (building) => {
    const reach = building.radius + unit.radius;
    if (!resting && distance(goal, building) < reach + within && distance(unit, building) <= reach + 2) resting = true;
  });
  return resting;
}
const CROWD_REACH = 100;
function restsAgainstArrivedFriend(game, unit, goal, end) {
  const gap = distance(unit, end);
  if (gap > CROWD_REACH) return false;
  const friend = firstNearbyUnit(game, unit, unit.radius + MAX_UNIT_RADIUS + 2, (other) => {
    if (other === unit || other.owner !== unit.owner || distance(other, unit) > other.radius + unit.radius + 2) return false;
    const there = other.order.type === "idle" && other.arrivedAt?.x === goal.x && other.arrivedAt.y === goal.y;
    const huddled = gap <= 2 * (unit.radius + other.radius) && (other.order.type === "move" || other.order.type === "attackMove") && other.order.x === goal.x && other.order.y === goal.y;
    return there || huddled;
  });
  return friend !== void 0;
}
function keepUnitsOutOfBuildings(game) {
  const map = game.map;
  for (const unit of game.units) {
    if (unit.deck) continue;
    if (unitMover(unit.kind) !== "land" || isOpenGround(map, unit.x, unit.y) || !isWalkable(map, unit.x, unit.y)) continue;
    const out = openGroundNear(map, unit);
    if (!out) continue;
    unit.x = out.x;
    unit.y = out.y;
  }
}
function slideUnits(game) {
  for (const unit of game.units) if (!isInCabin(unit) && unit.pushX !== void 0) {
    if (!unit.deck) {
      const from = { x: unit.x, y: unit.y };
      slide(unit, game.map, game.units);
      const at2 = constrainGroundShipStep(game.map, unit, from, unit, game.units);
      if (at2.x !== unit.x || at2.y !== unit.y) {
        unit.x = at2.x;
        unit.y = at2.y;
        unit.pushX = void 0;
        unit.pushY = void 0;
      }
      continue;
    }
    const point = { x: unit.x + perTick(unit.pushX), y: unit.y + perTick(unit.pushY ?? 0) };
    const at = deckSeparationPoint(game, unit, point);
    Object.assign(unit, { x: at.x, y: at.y });
    const speed = Math.hypot(unit.pushX, unit.pushY ?? 0), next = Math.max(0, speed - perTick(PUSH_FRICTION));
    if (next === 0 || at === unit) {
      unit.pushX = void 0;
      unit.pushY = void 0;
    } else {
      unit.pushX *= next / speed;
      unit.pushY = (unit.pushY ?? 0) * next / speed;
    }
  }
}
const separationFrames = /* @__PURE__ */ new WeakMap();
function clearSeparationBuckets(frame) {
  for (const bucket of frame.buckets) {
    for (let i = 0; i < bucket.count; i += 1) bucket.units[i] = void 0;
    bucket.count = 0;
    frame.lookup[bucket.slot] = void 0;
  }
  frame.buckets.length = 0;
  frame.pairs.length = 0;
  frame.valid = false;
}
function clearSeparationMembership(frame) {
  clearSeparationBuckets(frame);
  frame.members.length = frame.cellX.length = frame.cellY.length = frame.x.length = frame.y.length = 0;
}
function invalidateSeparationFrame(game) {
  const frame = separationFrames.get(game);
  if (frame) clearSeparationMembership(frame);
}
function separationBucketSlot(frame, key) {
  let slot = Math.imul(key, 2654435761) >>> frame.shift;
  let bucket;
  while (bucket = frame.lookup[slot]) {
    if (bucket.key === key || bucket.key !== bucket.key && key !== key) return slot;
    slot = slot + 1 & frame.mask;
  }
  return slot;
}
function separationMembershipMatches(game, frame, cellSize, navalFrame) {
  frame.unchangedSource = frame.unchangedMembers = 0;
  if (!frame.valid) return false;
  let member = 0;
  for (let i = 0; i < game.units.length; i += 1) {
    const unit = game.units[i];
    if (navalFrame && (isInCabin(unit) || isShipKind(unit.kind)) || minerGhost(unit)) continue;
    if (frame.members[member] !== unit || !Object.is(frame.x[member], unit.x) && !Object.is(frame.cellX[member], Math.floor(unit.x / cellSize)) || !Object.is(frame.y[member], unit.y) && !Object.is(frame.cellY[member], Math.floor(unit.y / cellSize))) {
      frame.unchangedSource = i;
      frame.unchangedMembers = member;
      return false;
    }
    frame.x[member] = unit.x;
    frame.y[member] = unit.y;
    member += 1;
  }
  frame.unchangedSource = game.units.length;
  frame.unchangedMembers = member;
  return member === frame.members.length;
}
function separateUnits(game, navalFrame) {
  const cellSize = 80;
  let frame = separationFrames.get(game);
  if (!frame) {
    frame = { buckets: [], lookup: new Array(16), mask: 15, shift: 28, pool: [], members: [], cellX: [], cellY: [], x: [], y: [], pairs: [], valid: false, unchangedSource: 0, unchangedMembers: 0 };
    separationFrames.set(game, frame);
  }
  const buckets = frame.buckets;
  const aPoint = { x: 0, y: 0 }, bPoint = { x: 0, y: 0 };
  const openGround = !game.map.terrain && groundShipFrameEmpty(game.units);
  if (!separationMembershipMatches(game, frame, cellSize, navalFrame)) {
    const prefix = frame.unchangedMembers, sourceStart = frame.unchangedSource;
    clearSeparationBuckets(frame);
    let capacity = frame.mask + 1, shift = frame.shift;
    while (capacity < game.units.length * 2) {
      capacity *= 2;
      shift -= 1;
    }
    if (capacity !== frame.mask + 1) {
      frame.lookup = new Array(capacity);
      frame.mask = capacity - 1;
      frame.shift = shift;
    }
    let used = 0, member = 0;
    const insert = (unit, x, y) => {
      const key = numericBucketKey(x, y);
      const slot = separationBucketSlot(frame, key);
      let bucket = frame.lookup[slot];
      if (!bucket) {
        bucket = frame.pool[used++];
        if (bucket) {
          bucket.key = key;
          bucket.slot = slot;
          bucket.x = x;
          bucket.y = y;
          bucket.count = 0;
        } else {
          bucket = { key, slot, x, y, units: [], count: 0 };
          frame.pool.push(bucket);
        }
        frame.lookup[slot] = bucket;
        buckets.push(bucket);
      }
      frame.members[member] = unit;
      frame.x[member] = unit.x;
      frame.y[member] = unit.y;
      frame.cellX[member] = x;
      frame.cellY[member++] = y;
      bucket.units[bucket.count++] = unit;
    };
    for (let i = 0; i < prefix; i += 1) insert(frame.members[i], frame.cellX[i], frame.cellY[i]);
    for (let i = sourceStart; i < game.units.length; i += 1) {
      const unit = game.units[i];
      if (navalFrame && (isInCabin(unit) || isShipKind(unit.kind)) || minerGhost(unit)) continue;
      insert(unit, Math.floor(unit.x / cellSize), Math.floor(unit.y / cellSize));
    }
    frame.members.length = frame.cellX.length = frame.cellY.length = frame.x.length = frame.y.length = member;
    for (const bucket of buckets) {
      frame.pairs.push(bucket, bucket);
      for (const [ox, oy] of SEPARATION_NEIGHBORS) {
        const neighbor = frame.lookup[separationBucketSlot(frame, numericBucketKey(bucket.x + ox, bucket.y + oy))];
        if (neighbor) frame.pairs.push(bucket, neighbor);
      }
    }
    frame.valid = true;
  }
  for (let i = 0; i < frame.pairs.length; i += 2) {
    separateUnitBuckets(game, frame.pairs[i], frame.pairs[i + 1], aPoint, bPoint, openGround, navalFrame);
  }
}
const SEPARATION_NEIGHBORS = [
  [1, -1],
  [1, 0],
  [1, 1],
  [0, 1]
];
function separateUnitBuckets(game, aBucket, bBucket, aPoint, bPoint, openGround, navalFrame) {
  const aUnits = aBucket.units, bUnits = bBucket.units;
  const sameBucket = aBucket === bBucket;
  for (let i = 0; i < aBucket.count; i += 1) {
    const start = sameBucket ? i + 1 : 0;
    const a = aUnits[i];
    for (let j = start; j < bBucket.count; j += 1) {
      const b = bUnits[j];
      const minDistance = a.radius + b.radius;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const distanceSq = dx * dx + dy * dy;
      if (distanceSq >= minDistance * minDistance) continue;
      separateUnitPair(game, a, b, minDistance, dx, dy, aPoint, bPoint, openGround, navalFrame);
    }
  }
}
function minerGhost(unit) {
  return unit.kind === "worker" && unit.order.type === "mine";
}
function separateUnitPair(game, a, b, minDistance, dx, dy, aPoint, bPoint, openGround, navalFrame) {
  let aMover = "land", bMover = "land";
  if (navalFrame) {
    if (a.deck || b.deck) {
      if (!a.deck || !b.deck || a.deck.shipId !== b.deck.shipId) return;
    }
    aMover = unitMover(a.kind);
    bMover = unitMover(b.kind);
    if (aMover !== bMover) return;
  }
  const length = hypot2(dx, dy);
  const nx = length === 0 ? 1 : dx / length;
  const ny = length === 0 ? 0 : dy / length;
  if (a.pushX !== void 0 || b.pushX !== void 0) pushContact(a, b, nx, ny);
  const push = (minDistance - length) / 2;
  const ax = clamp(a.x - nx * push, 0, game.map.width);
  const ay = clamp(a.y - ny * push, 0, game.map.height);
  const bx = clamp(b.x + nx * push, 0, game.map.width);
  const by = clamp(b.y + ny * push, 0, game.map.height);
  if (openGround && !a.deck && !b.deck) {
    a.x = ax;
    a.y = ay;
    b.x = bx;
    b.y = by;
    return;
  }
  aPoint.x = ax;
  aPoint.y = ay;
  const aAt = !navalFrame ? openStep(game.map, a, aPoint, "land") : a.deck ? deckSeparationPoint(game, a, aPoint) : constrainGroundShipStep(game.map, a, a, openStep(game.map, a, aPoint, aMover), game.units);
  bPoint.x = bx;
  bPoint.y = by;
  const bAt = !navalFrame ? openStep(game.map, b, bPoint, "land") : b.deck ? deckSeparationPoint(game, b, bPoint) : constrainGroundShipStep(game.map, b, b, openStep(game.map, b, bPoint, bMover), game.units);
  a.x = aAt.x;
  a.y = aAt.y;
  b.x = bAt.x;
  b.y = bAt.y;
}
function deckSeparationPoint(game, unit, point) {
  const ship = game.units.find((ship2) => ship2.id === unit.deck.shipId);
  if (!ship) return unit;
  const local = worldToLocal(ship, point);
  if (!deckPointFits(ship, unit, local, game.units, false)) return unit;
  Object.assign(unit.deck, local);
  return point;
}
function numericBucketKey(x, y) {
  return x * 1e3 + y;
}
function spatialBucketKey(entity, cellSize) {
  return numericBucketKey(Math.floor(entity.x / cellSize), Math.floor(entity.y / cellSize));
}
const spatialMembership = /* @__PURE__ */ new WeakMap();
function createSpatialIndex(entities, cellSize, previous) {
  const cached = previous && Object.is(previous.cellSize, cellSize) ? spatialMembership.get(previous) : void 0;
  let prefix = 0;
  if (cached && cached.members.length === entities.length) {
    let unchanged = true;
    for (let i = 0; i < entities.length; i += 1) {
      const entity = entities[i];
      if (cached.members[i] !== entity || !Object.is(cached.x[i], entity.x) && !Object.is(cached.cellX[i], Math.floor(entity.x / cellSize)) || !Object.is(cached.y[i], entity.y) && !Object.is(cached.cellY[i], Math.floor(entity.y / cellSize))) {
        unchanged = false;
        break;
      }
      cached.x[i] = entity.x;
      cached.y[i] = entity.y;
      prefix = i + 1;
    }
    if (unchanged) return previous;
  }
  const buckets = /* @__PURE__ */ new Map();
  if (cached) spatialMembership.delete(previous);
  const members = cached?.members ?? [];
  const cellX = cached?.cellX ?? [], cellY = cached?.cellY ?? [];
  const positionsX = cached ? cached.x : [], positionsY = cached ? cached.y : [];
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (let i = 0; i < entities.length; i += 1) {
    const entity = entities[i];
    const x = i < prefix ? cellX[i] : Math.floor(entity.x / cellSize);
    const y = i < prefix ? cellY[i] : Math.floor(entity.y / cellSize);
    members[i] = entity;
    positionsX[i] = entity.x;
    positionsY[i] = entity.y;
    cellX[i] = x;
    cellY[i] = y;
    left = Math.min(left, x);
    right = Math.max(right, x);
    top = Math.min(top, y);
    bottom = Math.max(bottom, y);
    const key = numericBucketKey(x, y);
    const bucket = buckets.get(key);
    if (bucket) bucket.push(entity);
    else buckets.set(key, [entity]);
  }
  members.length = cellX.length = cellY.length = positionsX.length = positionsY.length = entities.length;
  const index = { team: void 0, cellSize, buckets, left, right, top, bottom };
  spatialMembership.set(index, { members, cellX, cellY, x: positionsX, y: positionsY });
  return index;
}
const teamSpatialMembership = /* @__PURE__ */ new WeakMap();
function createTeamSpatialIndexes(game, entities, cellSize, previous) {
  const cached = previous ? teamSpatialMembership.get(previous) : void 0;
  let prefix = 0;
  if (cached && Object.is(cached.cellSize, cellSize) && cached.members.length === entities.length) {
    let unchanged = true;
    for (let i = 0; i < entities.length; i += 1) {
      const entity = entities[i];
      if (cached.members[i] !== entity || !Object.is(cached.x[i], entity.x) && !Object.is(cached.cellX[i], Math.floor(entity.x / cellSize)) || !Object.is(cached.y[i], entity.y) && !Object.is(cached.cellY[i], Math.floor(entity.y / cellSize)) || cached.teams[i] !== teamKey(game, entity.owner)) {
        unchanged = false;
        break;
      }
      cached.x[i] = entity.x;
      cached.y[i] = entity.y;
      prefix = i + 1;
    }
    if (unchanged) return previous;
  }
  const indexes = /* @__PURE__ */ new Map();
  const reusable = cached && Object.is(cached.cellSize, cellSize) ? cached : void 0;
  if (reusable) teamSpatialMembership.delete(previous);
  const members = reusable?.members ?? [];
  const cellX = reusable?.cellX ?? [], cellY = reusable?.cellY ?? [], teams = reusable?.teams ?? [];
  const positionsX = reusable ? reusable.x : [], positionsY = reusable ? reusable.y : [];
  for (let i = 0; i < entities.length; i += 1) {
    const entity = entities[i];
    const team = i < prefix ? teams[i] : teamKey(game, entity.owner);
    members[i] = entity;
    positionsX[i] = entity.x;
    positionsY[i] = entity.y;
    teams[i] = team;
    let index = indexes.get(team);
    if (!index) indexes.set(team, index = { team, cellSize, buckets: /* @__PURE__ */ new Map(), left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity });
    const x = i < prefix ? cellX[i] : Math.floor(entity.x / cellSize);
    const y = i < prefix ? cellY[i] : Math.floor(entity.y / cellSize);
    cellX[i] = x;
    cellY[i] = y;
    index.left = Math.min(index.left, x);
    index.right = Math.max(index.right, x);
    index.top = Math.min(index.top, y);
    index.bottom = Math.max(index.bottom, y);
    const key = numericBucketKey(x, y), bucket = index.buckets.get(key);
    if (bucket) bucket.push(entity);
    else index.buckets.set(key, [entity]);
  }
  members.length = cellX.length = cellY.length = teams.length = positionsX.length = positionsY.length = entities.length;
  teamSpatialMembership.set(indexes, { cellSize, members, cellX, cellY, teams, x: positionsX, y: positionsY });
  return indexes;
}
const entityIndexes = /* @__PURE__ */ new WeakMap();
function createEntityIndex(game) {
  const cached = entityIndexes.get(game.units);
  if (cached && cached.units === game.units.length && cached.buildings === game.buildings && cached.buildingCount === game.buildings.length) return cached.index;
  const index = /* @__PURE__ */ new Map();
  for (const unit of game.units) index.set(unit.id, unit);
  for (const building of game.buildings) index.set(building.id, building);
  entityIndexes.set(game.units, { units: game.units.length, buildings: game.buildings, buildingCount: game.buildings.length, index });
  return index;
}
function forEachNearbyUnit(game, point, range, visit) {
  forEachNearbyEntity(game.unitSpatial, game.units, point, range, (unit) => {
    if (!isInCabin(unit)) visit(unit);
  });
}
function firstNearbyUnit(game, point, range, test) {
  const index = game.unitSpatial;
  if (!index) return game.units.find((unit) => !isInCabin(unit) && test(unit));
  const size = index.cellSize;
  const right = Math.min(index.right, Math.floor((point.x + range) / size));
  const bottom = Math.min(index.bottom, Math.floor((point.y + range) / size));
  const top = Math.max(index.top, Math.floor((point.y - range) / size));
  for (let x = Math.max(index.left, Math.floor((point.x - range) / size)); x <= right; x += 1) {
    for (let y = top; y <= bottom; y += 1) {
      const bucket = index.buckets.get(numericBucketKey(x, y));
      if (!bucket) continue;
      for (const unit of bucket) if (!isInCabin(unit) && test(unit)) return unit;
    }
  }
  return void 0;
}
function forEachNearbyBuilding(game, point, range, visit) {
  forEachNearbyEntity(game.buildingSpatial, game.buildings, point, range, visit);
}
function forEachNearbyEnemyUnit(game, owner, point, range, visit) {
  const indexes = game.unitSpatialByTeam;
  if (!indexes) {
    forEachNearbyUnit(game, point, range, (unit) => {
      if (areEnemyOwners(game, owner, unit.owner)) visit(unit);
    });
    return;
  }
  const ownTeam = teamKey(game, owner);
  for (const index of indexes.values()) if (index.team !== ownTeam) forEachNearbyEntity(index, game.units, point, range, visit);
}
function forEachNearbyEnemyBuilding(game, owner, point, range, visit) {
  const indexes = game.buildingSpatialByTeam;
  if (!indexes) {
    forEachNearbyBuilding(game, point, range, (building) => {
      if (areEnemyOwners(game, owner, building.owner)) visit(building);
    });
    return;
  }
  const ownTeam = teamKey(game, owner);
  for (const index of indexes.values()) if (index.team !== ownTeam) forEachNearbyEntity(index, game.buildings, point, range, visit);
}
function forEachNearbyEntity(index, unindexedEntities, point, range, visit) {
  if (!index) {
    for (const entity of unindexedEntities) visit(entity);
    return;
  }
  const size = index.cellSize;
  const right = Math.min(index.right, Math.floor((point.x + range) / size));
  const bottom = Math.min(index.bottom, Math.floor((point.y + range) / size));
  const top = Math.max(index.top, Math.floor((point.y - range) / size));
  for (let x = Math.max(index.left, Math.floor((point.x - range) / size)); x <= right; x += 1) {
    for (let y = top; y <= bottom; y += 1) {
      const bucket = index.buckets.get(numericBucketKey(x, y));
      if (!bucket) continue;
      for (const entity of bucket) visit(entity);
    }
  }
}
function moveToward(unit, x, y, map, units = [], navalFrame = true) {
  const pace = statusPace(unit);
  if (pace === 0) return;
  if (navalFrame && shipProfile(unit)) {
    sailToward(unit, { x, y, ...unit.order.type === "move" && unit.order.heading !== void 0 ? { heading: unit.order.heading } : {} }, map, units, pace);
    return;
  }
  const knownEmpty = !navalFrame || groundShipFrameEmpty(units);
  if (!knownEmpty || unit.deck) {
    const ship = unit.deck && units.find((ship2) => ship2.id === unit.deck.shipId);
    const goal = deckGoal(unit, ship || void 0, { x, y }, units);
    if (walkConnectedSurfaces(unit, goal, units, map, pace)) return;
    if (unit.deck) {
      if (ship) moveOnDeck(unit, ship, goal, units, pace);
      return;
    }
  }
  const from = knownEmpty ? void 0 : { x: unit.x, y: unit.y };
  if (map.terrain) {
    walkToward(unit, x, y, map, pace);
    if (from) {
      const at = constrainGroundShipStep(map, unit, from, unit, units);
      if (at !== unit) {
        unit.x = at.x;
        unit.y = at.y;
      }
    }
    return;
  }
  const speed = perTick(unit.speed) * pace;
  const dx = x - unit.x;
  const dy = y - unit.y;
  const length = hypot2(dx, dy);
  if (length <= speed || length === 0) {
    unit.x = clamp(x, 0, map.width);
    unit.y = clamp(y, 0, map.height);
    if (from) {
      const at = constrainGroundShipStep(map, unit, from, unit, units);
      if (at !== unit) {
        unit.x = at.x;
        unit.y = at.y;
      }
    }
    return;
  }
  unit.x = clamp(unit.x + dx / length * speed, 0, map.width);
  unit.y = clamp(unit.y + dy / length * speed, 0, map.height);
  if (from) {
    const at = constrainGroundShipStep(map, unit, from, unit, units);
    if (at !== unit) {
      unit.x = at.x;
      unit.y = at.y;
    }
  }
}
function walkToward(unit, x, y, map, pace = 1) {
  const mover = unitMover(unit.kind);
  const goal = x >= 0 && y >= 0 && x <= map.width && y <= map.height && isWalkable(map, x, y, mover) ? { x, y } : walkableGoal(map, x, y, mover);
  const aim = steerPoint(map, unit, goal, mover);
  const dx = aim.x - unit.x;
  const dy = aim.y - unit.y;
  const length = Math.sqrt(dx * dx + dy * dy);
  if (length === 0) return;
  const speed = perTick(unit.speed) * pace * groundUnder(map, unit.x, unit.y, mover).pace;
  const nextX = clamp(length <= speed ? aim.x : unit.x + dx / length * speed, 0, map.width);
  const nextY = clamp(length <= speed ? aim.y : unit.y + dy / length * speed, 0, map.height);
  const step = openStep(map, unit, { x: nextX, y: nextY }, mover);
  unit.x = step.x;
  unit.y = step.y;
}
function distance(a, b) {
  return hypot2(a.x - b.x, a.y - b.y);
}
function distanceSquared(a, b) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return dx * dx + dy * dy;
}
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function isNumber(value) {
  return typeof value === "number" && Number.isFinite(value);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpbS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhZGRHb2xkLCByb3VuZEdvbGQgfSBmcm9tIFwiLi9nb2xkXCI7XG5pbXBvcnQgeyB1bml0Q29udHJvbHNNZXJjZW5hcnlDYW1wIH0gZnJvbSAnLi9tZXJjZW5hcnktY2FtcCc7XG5pbXBvcnQgeyBib2FyZGluZ0hvbGRTaGlwcywgY2FuY2VsQ3Jld1JlbmRlenZvdXMsIHByZXBhcmVDcmV3UmVuZGV6dm91cyB9IGZyb20gJy4vY3Jldy1yZW5kZXp2b3VzJztcbmltcG9ydCB7IHByZXBhcmVTaGlwRGVmZW5zZUZyYW1lLCBjb21iYXRIdWxsLCB0eXBlIFNoaXBEZWZlbnNlRnJhbWUgfSBmcm9tICcuL3NoaXAtZGVmZW5zZSc7XG5pbXBvcnQgeyBjb25zdHJhaW5Hcm91bmRTaGlwU3RlcCwgZHJhaW5TaGlwQ29sbGlzaW9uSW1wYWN0cywgZ3JvdW5kU2hpcEZyYW1lRW1wdHksIHNoaXBCb2R5Q2xlYXJBdFBvc2UgfSBmcm9tICcuL3NoaXAtY29sbGlzaW9ucyc7XG5pbXBvcnQgeyBzaGlwTGF1bmNoUG9zZSwgc2hpcExhdW5jaFByb3RvdHlwZSB9IGZyb20gJy4vc2hpcC1sYXVuY2gnO1xuaW1wb3J0IHsgbGFuZFNwYXduUG9pbnQsIGxhbmRTcGF3blByb3RvdHlwZSB9IGZyb20gJy4vcHJvZHVjdGlvbi1zcGF3bic7XG5pbXBvcnQgeyBzaGlwRmlyZUxhbmVDbGVhciB9IGZyb20gJy4vc2hpcC1maXJlLWNvbnRyb2wnO1xuaW1wb3J0IHsgYmVnaW5TaGlwQm9hcmRpbmcsIGNhbmNlbFNoaXBCb2FyZGluZywgc2hpcEJvYXJkaW5nR29hbCwgdXBkYXRlU2hpcEdhbmd3YXlzLCBkYW1hZ2VTaGlwR2FuZ3dheSwgZ2FuZ3dheUNyZXdFbGlnaWJsZSwgYmluZEdhbmd3YXlDcmV3UnVsZXMgfSBmcm9tICcuL3NoaXAtZ2FuZ3dheSc7XG5pbXBvcnQgeyBhc3NpZ25QbGF5ZXJDb2xvcnMgfSBmcm9tICcuL3BsYXllci1jb2xvcnMnO1xuaW1wb3J0IHsgQlVJTERJTkdfV09SS19SRUFDSCwgYnVpbGRpbmdXb3JrR2FwLCBjb25zdHJ1Y3Rpb25Xb3JrZXJzIH0gZnJvbSAnLi9jb25zdHJ1Y3Rpb24nO1xuaW1wb3J0IHsgR09MRF9NSU5FX1JVTEVTLCBwcmVwYXJlTWluaW5nRnJhbWUsIHVwa2VlcEdvbGRJbmNvbWUsIHR5cGUgTWluaW5nRnJhbWUgfSBmcm9tIFwiLi9taW5pbmdcIjtcbmltcG9ydCB7IGNhblJlY2VpdmVIZWFsaW5nIH0gZnJvbSAnLi9oZWFsaW5nJztcbmltcG9ydCB7IFNQQVJLX0ZJUkUsIHNwYXJrSWduaXRlcyB9IGZyb20gJy4vc3BhcmstZmlyZSc7XG5pbXBvcnQgeyB1bml0TmVlZHNSZXBhaXIsIHVuaXRSZXBhaXJIcFBlckdvbGQgfSBmcm9tICcuL3VuaXQtcmVwYWlyJztcbmltcG9ydCB7IGlubmF0ZU1pc3NpbGUsIHR5cGUgQXR0YWNrS2luZCB9IGZyb20gXCIuL2F0dGFjay1wcmVzZW50YXRpb25cIjtcbmltcG9ydCB7IGludmFsaWRhdGVJdGVtSW5kZXggfSBmcm9tIFwiLi9pdGVtLWluZGV4XCI7XG5pbXBvcnQgeyBzZXR0bGVHcm91bmRJdGVtcyB9IGZyb20gJy4vaXRlbS1zdXJmYWNlcyc7XG5pbXBvcnQgeyBzdHJpa2VQb2ludCwgc3RyaWtlR2FwLCBib2R5R2FwIH0gZnJvbSBcIi4vY29tYmF0LWdlb21ldHJ5XCI7XG5pbXBvcnQgeyBwdXJjaGFzZVBsYWNlbWVudCwgdHlwZSBQdXJjaGFzZVBsYWNlbWVudCB9IGZyb20gXCIuL3B1cmNoYXNlXCI7XG5pbXBvcnQgeyBTSElQX1dFQVBPTlMsIFBSRVZJT1VTX1NISVBfVFJBSU5fQ09TVCwgZGFtYWdlU2hpcFBhcnRzLCBpbml0aWFsaXplU2hpcEVxdWlwbWVudCwgaW5zdGFsbGVkV2VhcG9ucywgaXNTaGlwRXF1aXBtZW50LCBtb3VudGVkV2VhcG9uUG9zZSwgbW91bnRlZFRhcmdldFBvaW50LCBtb3VudGVkRmlyZUxhbmVDbGVhciwgcmVidWlsZFNoaXBGaXR0aW5ncywgcmVwYWlyU2hpcFBhcnRzLCBzaGlwUGFydE1heCwgc2hpcEd1bkNhbkFpbSwgc2hpcE1vdW50cywgYmVzdEZpcmluZ0hlYWRpbmcsIHR5cGUgTW91bnRlZFNob3RDbGVhciB9IGZyb20gXCIuL3NoaXAtZXF1aXBtZW50XCI7XG5pbXBvcnQgeyBJVEVNX0RFRlMsIGFjdGl2ZUl0ZW0sIGNhbkVxdWlwLCBkcm9wUmVmdXNhbCwgZnJlZUl0ZW1TbG90LCBpdGVtRXF1aXBwZWQsIG5vcm1hbGl6ZUVxdWlwbWVudCwgcmVtb3ZlRnJvbUhhbmRzLCB0cmFuc2ZlclJlZnVzYWwsIHdlYXBvblJ1bGVzLCB3aWVsZFJlZnVzYWwsIGl0ZW1IYW5kcywgdW5pdEl0ZW1NYXNzLCBzaGlwSXRlbU1hc3MsIGl0ZW1zRm9yIH0gZnJvbSBcIi4vZXF1aXBtZW50XCI7XG5pbXBvcnQgeyBCUkVBQ0hfQ0hBUkdFLCBGTEFNRV9DTE9BSywgR1VBUkRJQU5fU0NST0xMLCBJVk9SWV9UT1dFUl9IUF9TSEFSRSwgTElHSFROSU5HX1JPRCwgU1RPUk1fU1RBRkYsIE5FVVRSQUxfSVRFTV9UQVJHRVRfUkFOR0UsIE5FVVRSQUxfU1RPUk1fVEFSR0VUX1JBTkdFIH0gZnJvbSBcIi4vaXRlbS1ydWxlc1wiO1xuaW1wb3J0IHsgRVhQRVJJRU5DRV9CT09LX1hQLCBWRVRFUkFOQ1lfR0FJTl9QRVJfU1RBUiwga2lsbFhwUmV3YXJkLCB4cFN0YXJUaHJlc2hvbGRzIH0gZnJvbSBcIi4vdW5pdC12YWx1ZVwiO1xuaW1wb3J0IHsgYXV0b21hdGljVGFyZ2V0QWxsb3dlZCwgY29tYmF0VGFyZ2V0U2NvcmUsIGNvbWJhdFZpY3RpbUlkLCBzaG91bGRTd2l0Y2hDb21iYXRUYXJnZXQsIHR5cGUgVGFyZ2V0VGhyZWF0IH0gZnJvbSBcIi4vY29tYmF0LXRhcmdldFwiO1xuaW1wb3J0IHsgY3Jld0JlZm9yZUh1bGxzLCBib2x0SW50ZXJzZWN0aW9uLCBpbldlYXBvbkNvbmUsIHdlYXBvbkRhbWFnZSB9IGZyb20gXCIuL3dlYXBvbnNcIjtcbmltcG9ydCB7IGFpbUF0LCBhaW1pbmdQcm9maWxlLCBpbnZhbGlkYXRlTW92ZWRBaW0sIG1hcmtBaW1TaG90LCBSQU5HRURfQVRUQUNLX1JBTkdFX1RIUkVTSE9MRCB9IGZyb20gXCIuL2FpbWluZ1wiO1xuZXhwb3J0IHsgUkFOR0VEX0FUVEFDS19SQU5HRV9USFJFU0hPTEQgfSBmcm9tIFwiLi9haW1pbmdcIjtcbmltcG9ydCB0eXBlIHsgV2VhcG9uRGVmIH0gZnJvbSBcIi4vY2F0YWxvZ1wiO1xuaW1wb3J0IHsgQUJJTElUWV9ERUZTLCBCVUlMRElOR19ERUZTLCBET0NLX1JFUEFJUiwgU1VQUE9SVF9CVUlMRElOR19IRUFMLCBQT0lTT05fREFNQUdFLCBQT0lTT05fVElDS1MsIFNMT1dfUEFDRSwgU0xPV19USUNLUywgU1BMQVNIX1JBRElVUywgU1BMQVNIX1NIQVJFLCBNQVhfVVBHUkFERV9MRVZFTCwgTUVSQ0VOQVJZX1VOSVRfS0lORFMsIFJBQ0VfREVGUywgVU5JVF9ERUZTLCBVUEdSQURFX0RFRlMsIFVQR1JBREVfS0lORFMsIGNhblRyYWluQXQsIGNhblJlc2VhcmNoQXQsIGNvbnN0cnVjdGlvblN0YXJ0SHAsIGhhc1NwZWxsLCBpc0hlYWxpbmdCdWlsZGluZ0tpbmQsIG1heFVwZ3JhZGVMZXZlbCwgcmVxdWlyZWRTdXBwbHlDYXAsIHVuaXRNb3ZlciwgdW5pdFJ1bGVzLCB0eXBlIFVuaXREZWYgfSBmcm9tIFwiLi9jYXRhbG9nXCI7XG5pbXBvcnQgeyBhYmlsaXR5Q29vbGRvd24sIHRpY2tlZEFiaWxpdHlDb29sZG93bnMsIHdpdGhBYmlsaXR5Q29vbGRvd24gfSBmcm9tIFwiLi9hYmlsaXR5LWNvb2xkb3duc1wiO1xuaW1wb3J0IHsgaXNTdHVubmVkLCB1bml0QWJpbGl0aWVzIH0gZnJvbSBcIi4vdW5pdC1hYmlsaXRpZXNcIjtcbmltcG9ydCB7IG1hdGNoZXNVbml0VGFyZ2V0LCBOT05fTUVDSEFOSUNBTF9UQVJHRVRTLCB0eXBlIFVuaXRDbGFzcyB9IGZyb20gXCIuL3VuaXQtdGFyZ2V0aW5nXCI7XG5pbXBvcnQgeyByb2xsVmV0ZXJhblNraWxsQ2hvaWNlcyB9IGZyb20gXCIuL3ZldGVyYW4tc2tpbGxzXCI7XG5pbXBvcnQgeyB1bml0Q2xhc3NPZiB9IGZyb20gXCIuL3VuaXQtdGFyZ2V0aW5nXCI7XG5pbXBvcnQgeyB2ZXRlcmFuV2VhcG9uUmFuZ2UgfSBmcm9tIFwiLi92ZXRlcmFuLXN0YXRzXCI7XG5pbXBvcnQgeyBidWlsZFZldGVyYW5GcmFtZSwgY2FzdFZldGVyYW5BYmlsaXR5LCB0ZW1wb3JhcnlBdHRhY2tTcGVlZE11bHRpcGxpZXIsIHR5cGUgVmV0ZXJhbkF1dG9jYXN0RnJhbWUsIHR5cGUgVmV0ZXJhblVuaXRNb2RpZmllcnMgfSBmcm9tIFwiLi92ZXRlcmFuLXJ1bnRpbWVcIjtcbmltcG9ydCB7IGNoZWNrQ29tbWFuZExlZ2FsaXR5IH0gZnJvbSBcIi4vc2ltL2NvbW1hbmQtdmFsaWRhdGlvblwiO1xuaW1wb3J0IHsgcmVzb2x2ZVVuaXREYW1hZ2UsIHVuaXRBdHRhY2tEYW1hZ2VQcm9maWxlIH0gZnJvbSBcIi4vZGFtYWdlXCI7XG5pbXBvcnQgeyBhdHRhY2tEYW1hZ2VQcm9maWxlLCB3ZWFwb25EYW1hZ2VQcm9maWxlLCBEQU1BR0VfUFJPRklMRVMsIElURU1fREFNQUdFX1BST0ZJTEVTLCB0eXBlIERhbWFnZVByb2ZpbGUgfSBmcm9tIFwiLi9kYW1hZ2UtdHlwZXNcIjtcbmltcG9ydCB7IGF1dG9jYXN0RW5hYmxlZCwgY2FuQXV0b2Nhc3QsIHdpdGhBdXRvY2FzdCB9IGZyb20gXCIuL2F1dG9jYXN0XCI7XG5pbXBvcnQgeyBidWlsZGluZ1BsYWNlbWVudEJsb2NrZXIsIHRlcnJhaW5CbG9ja3NQbGFjZW1lbnQgfSBmcm9tIFwiLi9idWlsZC1wbGFjZW1lbnRcIjtcbmltcG9ydCB7IHNhbWVHcm91bmQsIGZvb3RwcmludEhhbGYsIGdyb3VuZFVuZGVyLCBpc09wZW5Hcm91bmQsIGlzV2Fsa2FibGUsIG9wZW5Hcm91bmROZWFyLCBvcGVuU3RlcCwgc2V0QnVpbGRpbmdCb2RpZXMsIHNoYXJlQnVpbGRpbmdCb2RpZXMsIHNuYXBUb0Zvb3RwcmludCwgc3RlZXJQb2ludCwgd2Fsa2FibGVHb2FsLCB3YWxrRGVzdGluYXRpb24gfSBmcm9tIFwiLi90ZXJyYWluXCI7XG5pbXBvcnQgeyBhbG9uZ3NpZGUsIGJvYXJkaW5nQmVydGgsIGNhblJlYWNoLCBjYXJyaWVzLCBsYW5kaW5nU3BvdCB9IGZyb20gXCIuL25hdmFsXCI7XG5pbXBvcnQgeyBkZXRDb3MsIGRldFNpbiB9IGZyb20gXCIuL2RldC1tYXRoXCI7XG5pbXBvcnQgeyBjYW5Cb2FyZCwgYm9hcmRVbml0LCBkZWNrUGxhY2VtZW50LCBkZWNrUG9pbnRGaXRzLCBtb3ZlT25EZWNrLCByZXN0b3JlQ2FyZ29EZWNrcywgc3luY0RlY2tzLCBzZXR0bGVHYW5nd2F5Q3Jvc3NpbmdzIH0gZnJvbSBcIi4vZGVja3NcIjtcbmltcG9ydCB7IGJvZHlNYXNzIH0gZnJvbSBcIi4vcGh5c2ljYWwtYm9keVwiO1xuaW1wb3J0IHsgd2Fsa0Nvbm5lY3RlZFN1cmZhY2VzLCBzZXR0bGVEZWNrU3VwcG9ydCwgZGVja3NDYW5UcmFuc2ZlciB9IGZyb20gXCIuL2Nvbm5lY3RlZC1kZWNrc1wiO1xuaW1wb3J0IHsgZGVja0h1bGxEYW1hZ2VTaGFyZSwgcGFzc2VuZ2VyRGFtYWdlTXVsdGlwbGllciB9IGZyb20gXCIuL2RlY2stY29tYmF0XCI7XG5pbXBvcnQgeyBzaGlwc0luLCBpc1NoaXBLaW5kLCBjaXJjbGVJblBvbHlnb24sIGRpc3RhbmNlVG9IdWxsLCBsb2NhbFRvV29ybGQsIHNoaXBQYXNzZW5nZXJzLCBzaGlwUHJvZmlsZSwgc2hhcmVTaGlwUHJvZmlsZSwgc2hpcFdlYXBvblBvc2UsIHdvcmxkVG9Mb2NhbCwgbWlncmF0ZVNoaXBTaXplcywgU0hJUF9TSVpFX01VTFRJUExJRVIgfSBmcm9tIFwiLi9zaGlwLWdlb21ldHJ5XCI7XG5pbXBvcnQgeyBrZWVwU2hpcHNPbldhdGVyLCBzYWlsVG93YXJkLCB0dXJuU2hpcFRvd2FyZCB9IGZyb20gXCIuL3NhaWxpbmdcIjtcbmltcG9ydCB7IGZvbGxvd1F1ZXVlZFNoaXBDb3Vyc2UgfSBmcm9tICcuL3NoaXAtcXVldWVkLWNvdXJzZSc7XG5pbXBvcnQgeyBzaGlwQ2FuVHVybkZvckF0dGFjaywgc2hpcE5hdmlnYXRpb25UYXJnZXQsIHNoaXBQdXJzdWl0R29hbCB9IGZyb20gJy4vc2hpcC1wdXJzdWl0JztcbmltcG9ydCB7IGJlZ2luU2hpcE1vdGlvbkZyYW1lIH0gZnJvbSAnLi9zaGlwLW1vdGlvbic7XG5pbXBvcnQgeyBiZWdpblNoaXBQbGFubmluZ0ZyYW1lLCB0cnlBZG1pdFNoaXBQbGFuIH0gZnJvbSAnLi9zaGlwLXBsYW5uaW5nLWJ1ZGdldCc7XG5pbXBvcnQgeyBjYW5jZWxTaGlwUGxhbm5pbmdKb2IgfSBmcm9tICcuL3NoaXAtcGxhbm5pbmctam9iJztcbmltcG9ydCB7IERFRkFVTFRfV0lORCwgdXBkYXRlQXV0b1RyaW0gfSBmcm9tICcuL3NoaXAtd2luZCc7XG5pbXBvcnQgeyBoeXBvdDIgfSBmcm9tIFwiLi9oeXBvdFwiO1xuaW1wb3J0IHsgTU9WRV9PUkRFUl9BUlJJVkFMX1JBTkdFIH0gZnJvbSAnLi9tb3ZlbWVudC1ydWxlcyc7XG5pbXBvcnQgeyBjYWJpbkdyb3VwU2VsZWN0aW9uLCBjYWJpbkNyZXdNb3ZlZFRoaXNUaWNrLCBlbnRlckNhYmluU3RlcCwgaGFzQ2FiaW5DcmV3TW92ZW1lbnRGcmFtZSwgaXNDYWJpblByb3RlY3RlZCwgaXNJbkNhYmluLCBsZWF2ZUNhYmluLCB1cGRhdGVDYWJpblBhc3NlbmdlcnMgfSBmcm9tICcuL3NoaXAtY2FiaW4nO1xuaW1wb3J0IHsgdXBkYXRlV2luZEZpZWxkIH0gZnJvbSAnLi93aW5kLWZpZWxkJztcbmltcG9ydCB7IHNoaXBUcmFmZmljIH0gZnJvbSAnLi9zaGlwLWF2b2lkYW5jZSc7XG5pbXBvcnQgeyBoZWFkaW5nRGlmZmVyZW5jZSwgaHVsbFBhc3NhZ2VDbGVhciwgbmVhcmVzdFNoaXBQb3NlLCB0eXBlIFNoaXBQb3NlIH0gZnJvbSBcIi4vc2hpcC1uYXZpZ2F0aW9uXCI7XG5pbXBvcnQgeyBCUkFDRV9EQU1BR0VfU0hBUkUsIE1BWF9TTElERV9TVEVQLCBQVVNIX0ZSSUNUSU9OLCBibG93U3RyZW5ndGgsIGNhblRha2VTdGFuY2UsIGlzU3RhZ2dlcmVkLCBsdW5nZVN0cmVuZ3RoLCBwdXNoQ29udGFjdCwgc2hvdmUsIHNsaWRlIH0gZnJvbSBcIi4vcHVzaFwiO1xuaW1wb3J0IHtcbiAgY3JlYXRlQnVpbGRpbmcsXG4gIGNyZWF0ZUluaXRpYWxCdWlsZGluZ3MsXG4gIGNyZWF0ZUluaXRpYWxJdGVtcyxcbiAgY3JlYXRlSW5pdGlhbE1lcmNlbmFyeUNhbXBzLFxuICBjcmVhdGVJbml0aWFsUmVzb3VyY2VzLFxuICBjcmVhdGVJbml0aWFsVW5pdHMsXG4gIGNyZWF0ZVVuaXQsXG4gIGNyZWF0ZU1hcCxcbiAgREVGQVVMVF9NQVBfSUQsXG4gIExBRERFUl9NQVBfSUQsXG4gIHRyYWluVGltZUZvcixcbiAgd2l0aFVuaXRTaGFwZSxcbn0gZnJvbSBcIi4vbWFwXCI7XG5pbXBvcnQgeyBnZW5lcmF0ZU1hcCwgVEVSUkFJTl9DRUxMIH0gZnJvbSBcIi4vZ2VuZXJhdGVkLW1hcFwiO1xuaW1wb3J0IHsgQk9PVFNfU1BFRUQsIEhFQUxJTkdfU0NST0xMX0hFQUwsIEhFQUxJTkdfU0NST0xMX1JBRElVUywgSVZPUllfVE9XRVJfUkVBQ0gsIE1BWF9DQVJSSUVEX0lURU1TLCBSSU5HX1JFR0VOX1BFUl9TRUNPTkQsIGJ1eVJlZnVzYWwsIGNhcnJpZWRJdGVtQ291bnQsIGNyZWF0ZVNob3AsIHJlc3RvY2tTaG9wcywgc2hvcEJ1eWVyIH0gZnJvbSBcIi4vc2hvcFwiO1xuaW1wb3J0IHsgcG9vbE1hcCB9IGZyb20gXCIuL21hcC1wb29sXCI7XG5pbXBvcnQgeyBwZXJUaWNrLCBzZWNvbmRzLCBTSU1fVElDS1NfUEVSX1NFQ09ORCB9IGZyb20gXCIuL3RpbWVcIjtcbmltcG9ydCB7IG93blVuaXRMb29rdXAgfSBmcm9tIFwiLi91bml0LWxvb2t1cFwiO1xuaW1wb3J0IHR5cGUgeyBBYmlsaXR5S2luZCwgQnVpbGRpbmcsIEdhbWVDb21tYW5kLCBHYW1lTWFwLCBHYW1lU2V0dXBPcHRpb25zLCBHYW1lU25hcHNob3QsIE1hcElkLCBNYXRjaFN0YXRlLCBPYnN0YWNsZSwgT3duZXIsIFBsYXllcklkLCBQbGF5ZXJOdW1iZXJNYXAsIFBsYXllclN0YXRlLCBQbGF5ZXJTdGF0ZU1hcCwgUHJvamVjdGlsZSwgUmFsbHlUYXJnZXQsIFNjZW5hcmlvT3ZlcnJpZGUsIFNjZW5hcmlvUGxheWVyU2VlZCwgU2V0dGxlZFVuaXRPcmRlciwgVHJhaW5hYmxlVW5pdEtpbmQsIFVuaXQsIFVuaXRLaW5kLCBVbml0T3JkZXIsIFVuaXRTdGF0dXNFZmZlY3QsIFVwZ3JhZGVLaW5kLCBXb3JsZEVmZmVjdCwgV29ybGRJdGVtIH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuZXhwb3J0IHR5cGUgQ3JlYXRlR2FtZU9wdGlvbnMgPSBHYW1lU2V0dXBPcHRpb25zO1xuXG5leHBvcnQgdHlwZSBHYW1lID0gR2FtZVNuYXBzaG90ICYge1xuICAvKiogRGVyaXZlZCBhdCB0aWNrIGJvdW5kYXJpZXM7IG5ldmVyIHNlcmlhbGl6ZWQgb3IgdXNlZCBhcyBhIHNvdXJjZSBvZiBwZXJtYW5lbnQgc3RhdHMuICovXG4gIHZldGVyYW5GcmFtZT86IE1hcDxzdHJpbmcsIFZldGVyYW5Vbml0TW9kaWZpZXJzPiB8IHVuZGVmaW5lZDtcbiAgdmV0ZXJhbkF1dG9jYXN0RnJhbWU/OiBWZXRlcmFuQXV0b2Nhc3RGcmFtZSB8IHVuZGVmaW5lZDtcbiAgbWluaW5nRnJhbWU/OiBNaW5pbmdGcmFtZTtcbiAgYm9hcmRpbmdIb2xkcz86IFJlYWRvbmx5U2V0PHN0cmluZz47XG4gIGRlY2tEYW1hZ2VCYXRjaD86IE1hcDxzdHJpbmcsIHsgc2hpcDogVW5pdDsgZGlyZWN0OiBudW1iZXI7IGNvbGxhdGVyYWw6IG51bWJlcjsgc291cmNlPzogVW5pdCB8IEJ1aWxkaW5nOyBpbXBhY3Q/Ont4Om51bWJlcjt5Om51bWJlcn07IGJsYXN0UmFkaXVzPzpudW1iZXI7IHByb2ZpbGU/OkRhbWFnZVByb2ZpbGUgfT47XG4gIG5leHRJZDogbnVtYmVyO1xuICBhY3RpdmVQbGF5ZXJzOiBQbGF5ZXJJZFtdO1xuICB0ZWFtczogUmVjb3JkPFBsYXllcklkLCBzdHJpbmc+O1xuICB1bml0U3BhdGlhbD86IFNwYXRpYWxJbmRleDxVbml0PjtcbiAgdW5pdFNwYXRpYWxCeVRlYW0/OiBNYXA8c3RyaW5nLCBTcGF0aWFsSW5kZXg8VW5pdD4+O1xuICBzaGlwUmVhY2hQYWRkaW5nPzogbnVtYmVyO1xuICBidWlsZGluZ1NwYXRpYWw/OiBTcGF0aWFsSW5kZXg8QnVpbGRpbmc+O1xuICBidWlsZGluZ1NwYXRpYWxCeVRlYW0/OiBNYXA8c3RyaW5nLCBTcGF0aWFsSW5kZXg8QnVpbGRpbmc+PjtcbiAgYnVpbGRpbmdTcGF0aWFsQ291bnQ/OiBudW1iZXI7XG4gIC8vIFRoZSBidWlsZGluZ3MgYW5kIG9ic3RhY2xlcyB0aGUgbWFwJ3Mgcm91dGluZyBsYXN0IHRvb2sgaW4gKHNlZSBAQEBidWlsZGluZy1wYXRoaW5nKS5cbiAgYnVpbGRpbmdCb2RpZXNTZWVuPzogKEJ1aWxkaW5nIHwgT2JzdGFjbGUpW107XG4gIGVudGl0eUJ5SWQ/OiBNYXA8c3RyaW5nLCBVbml0IHwgQnVpbGRpbmc+O1xuICBzcGF3blVuaXQob3duZXI6IFVuaXRbXCJvd25lclwiXSwga2luZDogVW5pdEtpbmQsIHg6IG51bWJlciwgeTogbnVtYmVyLCBwb3NlPzogU2hpcFBvc2UpOiBVbml0O1xuICAvLyBDYW1wYWlnbiBnYW1lcyBvbmx5IChzZWUgc3RvcnkvKTsgYSBzdGFuZGFyZCBtYXRjaCBoYXMgbmVpdGhlciAobm9yIGB2YXJpYW50c2ApIGFuZCB0YWtlcyBub25lIG9mIHRoZWlyIHBhdGhzLlxuICAvLyBUb2xkIG9mIGV2ZXJ5IGhpdCBhcyBpdCBsYW5kcywgc28gYSBzY3JpcHQgY2FuIHRlbGwgd2hvIHN0cnVjayB3aG9tLiBJdCB3YXRjaGVzOyBpdCBuZXZlciBjaGFuZ2VzIHRoZSBnYW1lLlxuICBvYnNlcnZlcj86IFNpbU9ic2VydmVyO1xuICAvLyBUaGUgc2NyaXB0IGRlY2lkZXMgd2hvIHdpbnM6IHRoZSBsYXN0IHRlYW0gc3RhbmRpbmcgd2l0aCBidWlsZGluZ3MgZG9lcyBub3QgZW5kIHRoZSBtYXRjaC5cbiAgc2NyaXB0ZWRWaWN0b3J5PzogYm9vbGVhbjtcbn07XG5cbmV4cG9ydCB0eXBlIFNpbU9ic2VydmVyID0ge1xuICBoaXQoYXR0YWNrZXI6IFVuaXQgfCBCdWlsZGluZywgdGFyZ2V0OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSwgZGFtYWdlOiBudW1iZXIsIGhwQmVmb3JlOiBudW1iZXIpOiB2b2lkO1xufTtcblxuZXhwb3J0IGNvbnN0IEdBTUVfU05BUFNIT1RfUkVTVE9SRV9LRVlTID0gW1xuICBcImVxdWlwbWVudFZlcnNpb25cIixcbiAgXCJyYXRlVW5pdHNcIixcbiAgXCJ0aWNrXCIsXG4gIFwibWF0Y2hcIixcbiAgXCJtYXBcIixcbiAgXCJ0ZWFtc1wiLFxuICBcInBsYXllcnNcIixcbiAgXCJ1bml0c1wiLFxuICBcImJ1aWxkaW5nc1wiLFxuICBcInJlc291cmNlc1wiLFxuICBcIm1lcmNlbmFyeUNhbXBzXCIsXG4gIFwic2hvcHNcIixcbiAgXCJpdGVtc1wiLFxuICBcInByb2plY3RpbGVzXCIsXG4gIFwiZWZmZWN0c1wiLFxuICBcImNvcnBzZXNcIixcbiAgXCJ2YXJpYW50c1wiLFxuICBcIm9ic3RhY2xlc1wiLFxuXSBhcyBjb25zdCBzYXRpc2ZpZXMgcmVhZG9ubHkgKGtleW9mIEdhbWVTbmFwc2hvdClbXTtcblxudHlwZSBSZXN0b3JlZFNuYXBzaG90S2V5ID0gKHR5cGVvZiBHQU1FX1NOQVBTSE9UX1JFU1RPUkVfS0VZUylbbnVtYmVyXTtcbmNvbnN0IF9zbmFwc2hvdFJlc3RvcmVLZXlzQ292ZXJTbmFwc2hvdDogRXhjbHVkZTxrZXlvZiBHYW1lU25hcHNob3QsIFJlc3RvcmVkU25hcHNob3RLZXk+IGV4dGVuZHMgbmV2ZXIgPyB0cnVlIDogbmV2ZXIgPSB0cnVlO1xuXG50eXBlIFNwYXRpYWxFbnRpdHkgPSB7XG4gIHg6IG51bWJlcjtcbiAgeTogbnVtYmVyO1xufTtcblxudHlwZSBTcGF0aWFsSW5kZXg8VCBleHRlbmRzIFNwYXRpYWxFbnRpdHk+ID0ge1xuICB0ZWFtPzogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBjZWxsU2l6ZTogbnVtYmVyO1xuICBidWNrZXRzOiBNYXA8bnVtYmVyLCBUW10+O1xuICBsZWZ0OiBudW1iZXI7XG4gIHJpZ2h0OiBudW1iZXI7XG4gIHRvcDogbnVtYmVyO1xuICBib3R0b206IG51bWJlcjtcbn07XG5cbmNvbnN0IE1JTkVfUkFOR0UgPSBHT0xEX01JTkVfUlVMRVMuZW50cnlSYW5nZTtcbmNvbnN0IFRPV05fSEFMTF9EUk9QX1JBTkdFID0gR09MRF9NSU5FX1JVTEVTLmRyb3BSYW5nZTtcbmNvbnN0IEdPTERfUEVSX1RSSVAgPSBHT0xEX01JTkVfUlVMRVMuZ29sZFBlclRyaXA7XG5jb25zdCBHQVRIRVJfRFVSQVRJT04gPSBzZWNvbmRzKEdPTERfTUlORV9SVUxFUy5nYXRoZXJTZWNvbmRzKTtcbmNvbnN0IEdPTERfTUlORV9FTlRSWV9DT09MRE9XTiA9IHNlY29uZHMoR09MRF9NSU5FX1JVTEVTLmVudHJ5U2Vjb25kcyk7XG5cbmNvbnN0IElURU1fUElDS1VQX1JBTkdFID0gNzI7XG5jb25zdCBTQ09SQ0hfRFVSQVRJT04gPSBzZWNvbmRzKDgpO1xuY29uc3QgRkxBTUVfQ0xPQUtfVklTVUFMX0RVUkFUSU9OID0gc2Vjb25kcygxLjcpO1xuY29uc3QgTU9PTl9XRUxMX0hFQUxfRUZGRUNUX0RVUkFUSU9OID0gc2Vjb25kcygxLjEpO1xuLy8gQEBAcmVwYWlyIC0gQSB3b3JrZXIgcmVwYWlycyBhIGJ1aWxkaW5nIGFzIGZhc3QgYXMgYSBmb290bWFuIHN0cmlrZXMgb25lICh0aGUgb3duZXIncyB3b3JkLCAxMC0wMjogYSB0b3dlciBoZWxkIGJ5IGl0c1xuLy8gd29ya2VycyBob2xkcyksIGF0IHRoZSBwcmljZSBpdCBhbHdheXMgaGFkOiAxIGdvbGQgZm9yIGVhY2ggUkVQQUlSX0ZVTExfQ09TVF9GUkFDVElPTi10aCBvZiB0aGUgYnVpbGRpbmcncyBwcmljZSB3b3J0aFxuLy8gb2YgaXRzIGhlYWx0aCwgcGFpZCBhcyBvZnRlbiBhcyB0aGF0IHJhdGUgYXNrcyAoYSB0b3dlciBldmVyeSA2IHRpY2tzLCBhIGhhbGwgZXZlcnkgOSkuXG5jb25zdCBSRVBBSVJfRlVMTF9DT1NUX0ZSQUNUSU9OID0gMC4zNTtcbmNvbnN0IFJFUEFJUl9IUF9QRVJfU0VDT05EID0gVU5JVF9ERUZTLmZvb3RtYW4uYXR0YWNrRGFtYWdlIC8gKFVOSVRfREVGUy5mb290bWFuLmF0dGFja0Nvb2xkb3duL3NlY29uZHMoMSkpO1xuY29uc3QgUkVQQUlSX0hBTU1FUl9FRkZFQ1RfRFVSQVRJT04gPSBzZWNvbmRzKDMpO1xuZXhwb3J0IGNvbnN0IEFVVE9fQUNRVUlSRV9SQU5HRSA9IDIzMDtcbi8vIFByb2plY3RpbGUgcmF0ZXMgYXJlIGRpc3RhbmNlIHBlciBzZWNvbmQ7IG9ubHkgZmxpZ2h0IGR1cmF0aW9uIGlzIHF1YW50aXplZCB0byBzaW11bGF0aW9uIHRpY2tzLlxuY29uc3QgUFJPSkVDVElMRV9TUEVFRCA9IDM2MDsgLy8gRGlzdGFuY2UgcGVyIHNlY29uZC5cbmNvbnN0IE5FVVRSQUxfTEVBU0hfUkFOR0UgPSA2NTA7XG4vLyBAQEBuZXV0cmFsLWRhbWFnZS1yZXNwb25zZSAtIERhbWFnZSByZXNwb25zZSBtdXN0IGNvdmVyIGFueSBsZWdhbCByYW5nZWQgaGl0IGJlZm9yZSBsZWFzaCBjbGVhbnVwIGNhbiBlcmFzZSB0aGUgYWdncm8uXG4vLyBBIG5ldyBsb25nLXJhbmdlIHNpZWdlIHdlYXBvbiBtdXN0IG5vdCBleHBhbmQgZXZlcnkgY3JlZXAncyBwdXJzdWl0IHJhZGl1cy5cbmNvbnN0IE5FVVRSQUxfREFNQUdFX1JFU1BPTlNFX1JBTkdFID0gTkVVVFJBTF9MRUFTSF9SQU5HRTtcbmNvbnN0IE5FVVRSQUxfUkVUVVJOX1NUT1BfUkFOR0UgPSA4O1xuY29uc3QgTkVVVFJBTF9BU1NJU1RfUkFOR0UgPSAzNjA7XG4vLyBAQEBwbGF5ZXItYWdncm8gLSBQbGF5ZXIgdW5pdHMgYW5zd2VyIGRhbWFnZSB0aGUgd2F5IG5ldXRyYWwgY2FtcHMgZG86IHRoZSBoaXQgdW5pdCB0dXJucyBvbiBpdHMgYXR0YWNrZXIgYW5kIGlkbGVcbi8vIHNvbGRpZXJzIG9mIHRoZSBzYW1lIG93bmVyIG5lYXJieSBjb21lIHRvIGhlbHAsIHNvIGEgc2hvb3RlciBwYXJrZWQgb3V0c2lkZSBhY3F1aXNpdGlvbiByYW5nZSBpcyBubyBsb25nZXIgZnJlZSBkYW1hZ2UuXG4vLyBPbmx5IHNlbGYtZGlyZWN0ZWQgYmVoYXZpb3VyIGFuc3dlcnMuIEEgbW92ZSwgYW4gZXhwbGljaXQgYXR0YWNrIG9yIGEgd29ya2VyIGpvYiBpcyBhIGNvbW1hbmQgYW5kIGlzIG5ldmVyIG92ZXJyaWRkZW4sXG4vLyB3aGljaCBrZWVwcyByZXRyZWF0cywgZm9jdXMgZmlyZSBhbmQga2l0aW5nIGluIHRoZSBwbGF5ZXJzJyBoYW5kcy5cbmNvbnN0IEhFTFBfQ0FMTF9SQU5HRSA9IDMwMDtcbi8vIFNlbGYtZGlyZWN0ZWQgY2hhc2VzIChpZGxlIGFjcXVpc2l0aW9uLCByZXRhbGlhdGlvbiwgYW5zd2VyaW5nIGEgY2FsbCkgZ2l2ZSB1cCB0aGlzIGZhciBmcm9tIHdoZXJlIHRoZSB1bml0IHN0b29kLCBzbyBvbmVcbi8vIHJhaWRlciBjYW5ub3QgZHJhZyBhIGJhc2UncyBkZWZlbmRlcnMgYWNyb3NzIHRoZSBtYXAuIENvbW1hbmRlZCBhdHRhY2tzIGFuZCBhdHRhY2stbW92ZXMgYXJlIG5vdCBsZWFzaGVkLlxuY29uc3QgR1VBUkRfTEVBU0hfUkFOR0UgPSA2MDA7XG4vLyBUaHJlYXQ6IGFuIGVuZW15IHRoYXQgaXMgYXR0YWNraW5nIG91ciBzaWRlIG91dHJhbmtzIGEgYnlzdGFuZGVyIGFib3V0IDEwMHB4IG5lYXJlci5cbmNvbnN0IERFRkFVTFRfUExBWUVSUzogUGxheWVySWRbXSA9IFtcInBsYXllclwiLCBcImVuZW15XCJdO1xuY29uc3QgREVGQVVMVF9URUFNUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHsgcGxheWVyOiBcInBsYXllclwiLCBlbmVteTogXCJlbmVteVwiLCBlbmVteTI6IFwiZW5lbXkyXCIgfTtcbmNvbnN0IERFRkFVTFRfUkFDRVM6IFJlY29yZDxzdHJpbmcsIFBsYXllclN0YXRlW1wicmFjZVwiXT4gPSB7IHBsYXllcjogXCJncm92ZVwiLCBlbmVteTogXCJlbWJlclwiLCBlbmVteTI6IFwiZ3JvdmVcIiB9O1xuLy8gQEBAcnVudGltZS1pZC1iYW5kIC0gTWFwLWF1dGhvcmVkIGlkcyBzdGF5IGh1bWFuLXJlYWRhYmxlOyBydW50aW1lIGlkcyBsaXZlIGFib3ZlIHRoaXMgYmFuZC5cbmNvbnN0IFJVTlRJTUVfSURfU1RBUlQgPSAxMDAwO1xuXG4vLyBPbmx5IHRoZSBuYXRpdmUgZmFjdG9yeSBwcm9taXNlcyB0aGF0IGJpcnRocyBhcHBlbmQgd2l0aG91dCBjaGFuZ2luZyBleGlzdGluZ1xuLy8gcGFzc2VuZ2Vycy4gQ3VzdG9tIGZhY3RvcmllcyBhbmQgaGl0IG9ic2VydmVycyBrZWVwIHRoZSBjb21wbGV0ZSBuYXZhbCBwYXNzLlxuY29uc3QgbmF0aXZlVW5pdFNwYXduZXJzID0gbmV3IFdlYWtNYXA8R2FtZSwgR2FtZVtcInNwYXduVW5pdFwiXT4oKTtcbmNvbnN0IE5BVkFMX0ZSQU1FID0gMTtcbmNvbnN0IENBUkdPX0ZSQU1FID0gMjtcbmNvbnN0IEVNUFRZX1ZFVEVSQU5fRlJBTUUgPSA0O1xuLy8gVGhlc2UgcHJpdmF0ZSBlbXB0eSB0YXNrIHZpZXdzIGFyZSBvbmx5IHJlYWQgYnkgdGhlIHNpbXVsYXRpb24ncyBzaGlwIHBhc3Nlcy5cbmNvbnN0IEVNUFRZX1NISVBfU1RBUlRTID0gbmV3IE1hcDxzdHJpbmcsIHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IGhlYWRpbmc6IG51bWJlciB9PigpO1xuY29uc3QgRU1QVFlfU0hJUF9ERUZFTlNFUzogU2hpcERlZmVuc2VGcmFtZSA9IG5ldyBNYXAoKTtcblxuZnVuY3Rpb24gbmF2YWxGcmFtZUZsYWdzKGdhbWU6IEdhbWUpOiBudW1iZXIge1xuICAvLyBOYXRpdmUgYmlydGhzIGFuZCBhdXRvbWF0aWMgc3RhciBnYWlucyBuZXZlciBhc3NpZ24gYSBsZWFybmVkIHNraWxsLlxuICAvLyBDYWxsYmFja3MgY2FuIGNoYW5nZSBvbmUgbWlkLXRpY2ssIHNvIG9ubHkgdGhlIG5hdGl2ZSBmcmFtZSBtYXkgY2VydGlmeSBlbXB0aW5lc3MuXG4gIGxldCBmbGFncyA9IGdhbWUub2JzZXJ2ZXIgfHwgbmF0aXZlVW5pdFNwYXduZXJzLmdldChnYW1lKSAhPT0gZ2FtZS5zcGF3blVuaXQgPyBOQVZBTF9GUkFNRSA6IEVNUFRZX1ZFVEVSQU5fRlJBTUU7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSB7XG4gICAgLy8gQW4gZW1wdHkgb2xkLWZvcm1hdCBjYXJnbyBhcnJheSBzdGlsbCBuZWVkcyB0byBiZSByZW1vdmVkIGJ5IG1pZ3JhdGlvbi5cbiAgICAvLyBDYXJnbyBtaWdyYXRpb24gbWF5IHJldmVhbCBza2lsbGVkIHBhc3NlbmdlcnMgbm90IHZpc2l0ZWQgYnkgdGhpcyBzY2FuLlxuICAgIGlmICh1bml0LmNhcmdvKSByZXR1cm4gTkFWQUxfRlJBTUUgfCBDQVJHT19GUkFNRTtcbiAgICBpZiAodW5pdC52ZXRlcmFuU2tpbGwgIT09IHVuZGVmaW5lZCkgZmxhZ3MgJj0gfkVNUFRZX1ZFVEVSQU5fRlJBTUU7XG4gICAgaWYgKGZsYWdzICYgTkFWQUxfRlJBTUUpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG9yZGVyID0gdW5pdC5vcmRlcjtcbiAgICBpZiAodW5pdC5kZWNrIHx8IHVuaXQuY2FiaW4gfHwgdW5pdC5nYW5nd2F5IHx8IHVuaXQuc2FpbGluZyB8fCBpc1NoaXBLaW5kKHVuaXQua2luZClcbiAgICAgIHx8IG9yZGVyLnR5cGUgPT09IFwiYm9hcmRcIiB8fCBvcmRlci50eXBlID09PSBcImJvYXJkU2hpcFwiIHx8IG9yZGVyLnR5cGUgPT09IFwidW5sb2FkXCIgfHwgb3JkZXIudHlwZSA9PT0gXCJlbnRlckNhYmluXCJcbiAgICAgIHx8IG9yZGVyLnR5cGUgPT09IFwibW92ZVwiICYmIChvcmRlci5yZW5kZXp2b3VzRm9yIHx8IG9yZGVyLmRlY2tQb2ludCB8fCBvcmRlci5kZWNrU2hpcElkKVxuICAgICAgfHwgb3JkZXIudHlwZSA9PT0gXCJhdHRhY2tNb3ZlXCIgJiYgKG9yZGVyLmRlY2tQb2ludCB8fCBvcmRlci5kZWNrU2hpcElkKSkgZmxhZ3MgfD0gTkFWQUxfRlJBTUU7XG4gIH1cbiAgLy8gUHJlc2VydmUgdGhlIGV4aXN0aW5nIHZlc3NlbCB2aWV3IGV2ZW4gYWZ0ZXIgZGlyZWN0IGVxdWFsLWxlbmd0aCBhcnJheVxuICAvLyByZXBsYWNlbWVudC4gVGhpcyBzaG9ydGN1dCBtdXN0IG5vdCBjaGFuZ2UgdGhhdCBwdWJsaWMgbXV0YXRpb24gYmVoYXZpb3IuXG4gIHJldHVybiBmbGFncyB8IChmbGFncyAmIE5BVkFMX0ZSQU1FIHx8IHNoaXBzSW4oZ2FtZS51bml0cykubGVuZ3RoID8gTkFWQUxfRlJBTUUgOiAwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUdhbWUobWFwSWQ6IE1hcElkID0gREVGQVVMVF9NQVBfSUQsIG9wdGlvbnM6IENyZWF0ZUdhbWVPcHRpb25zID0ge30pOiBHYW1lIHtcbiAgY29uc3QgYWlQbGF5ZXJzID0gb3B0aW9ucy5haVBsYXllcnMgPz8gW1wiZW5lbXlcIl07XG4gIGNvbnN0IGFjdGl2ZVBsYXllcnMgPSB1bmlxdWVQbGF5ZXJzKG9wdGlvbnMucGxheWVycyA/PyBbLi4uREVGQVVMVF9QTEFZRVJTLCAuLi5haVBsYXllcnNdKTtcbiAgY29uc3QgdGVhbXMgPSBPYmplY3QuZnJvbUVudHJpZXMoYWN0aXZlUGxheWVycy5tYXAoKG93bmVyLCBpbmRleCkgPT4gW293bmVyLCBvcHRpb25zLnRlYW1zPy5bb3duZXJdID8/IERFRkFVTFRfVEVBTVNbb3duZXJdID8/IGB0ZWFtLSR7aW5kZXggKyAxfWBdKSk7XG4gIC8vIEEgZ2VuZXJhdGVkIGxheW91dCByZXBsYWNlcyB0aGUgbWFwIGlkJ3Mgb3duIHN0YXJ0cywgbWluZXMsIGNhbXBzIGFuZCBzY2VuZXJ5IChzZWUgQEBAZ2VuZXJhdGVkLW1hcCk7IHRoZSBpZCBuYW1lcyBpdC5cbiAgLy8gQSBwb29sIG1hcCBpcyBpdHMgb3duIGxheW91dCAoc2VlIEBAQG1hcC1wb29sKTsgdGhlIGxhZGRlciBtYXAgaGFzIG5vbmUgb2YgaXRzIG93bjogYSBnYW1lIG9uIGl0IHdpdGhvdXQgYSBsYXlvdXQgaXNcbiAgLy8gZHJhd24gZnJvbSB0aGUgc2VlZCBcImxhZGRlclwiLlxuICBjb25zdCBuYW1lZExheW91dCA9IHBvb2xNYXAobWFwSWQpPy5sYXlvdXQ7XG4gIGNvbnN0IGxheW91dCA9IG9wdGlvbnMubGF5b3V0ID8/IG5hbWVkTGF5b3V0ID8/IChtYXBJZCA9PT0gTEFEREVSX01BUF9JRCA/IHsgc2VlZDogXCJsYWRkZXJcIiB9IDogdW5kZWZpbmVkKTtcbiAgLy8gTmFtZWQgdHdvLXNob3JlIG1hcHMgcmV0YWluIHRoZWlyIGdlb21ldHJ5IHdoZW4gcGxheWVycyBjaGFuZ2UgYWxsaWFuY2VzLlxuICAvLyBPbmx5IHRoZSBsYXlvdXQgdXNlcyB0aGVzZSBwaHlzaWNhbCBzaWRlczsgZ2FtZSBkaXBsb21hY3kgdXNlcyBgdGVhbXNgLlxuICBjb25zdCBuYW1lZFNob3JlcyA9IG5hbWVkTGF5b3V0Py5raW5kID09PSBcInNpZGVzXCJcbiAgICAmJiAoIW9wdGlvbnMubGF5b3V0IHx8IG9wdGlvbnMubGF5b3V0LmtpbmQgPT09IG5hbWVkTGF5b3V0LmtpbmQgJiYgb3B0aW9ucy5sYXlvdXQuaWRlYSA9PT0gbmFtZWRMYXlvdXQuaWRlYSk7XG4gIGNvbnN0IGxheW91dFRlYW1zID0gbmFtZWRTaG9yZXNcbiAgICA/IE9iamVjdC5mcm9tRW50cmllcyhhY3RpdmVQbGF5ZXJzLm1hcCgoaWQsIGluZGV4KSA9PiBbaWQsIGBzaG9yZS0ke2luZGV4ICUgMn1gXSkpIDogdGVhbXM7XG4gIGNvbnN0IGdlbmVyYXRlZCA9IGxheW91dCA/IGdlbmVyYXRlTWFwKGxheW91dCwgYWN0aXZlUGxheWVycywgbGF5b3V0VGVhbXMpIDogdW5kZWZpbmVkO1xuICBjb25zdCBzaG9wcyA9IChnZW5lcmF0ZWQ/LnNpdGVzID8/IFtdKS5maWx0ZXIoKHNpdGUpID0+IHNpdGUua2luZCA9PT0gXCJzaG9wXCIpLm1hcCgoc2l0ZSwgaW5kZXgpID0+IGNyZWF0ZVNob3AoYHNob3AtJHtpbmRleCArIDF9YCwgc2l0ZS54LCBzaXRlLnkpKTtcbiAgY29uc3QgZ2FtZSA9IHtcbiAgICBlcXVpcG1lbnRWZXJzaW9uOiAxLFxuICAgIHJhdGVVbml0czogXCJwZXJTZWNvbmRcIixcbiAgICB0aWNrOiAwLFxuICAgIG1hdGNoOiBjcmVhdGVNYXRjaFN0YXRlKGFjdGl2ZVBsYXllcnMpLFxuICAgIG1hcDogZ2VuZXJhdGVkID8geyAuLi5jcmVhdGVNYXAobWFwSWQpLCB3aWR0aDogZ2VuZXJhdGVkLnNpemUsIGhlaWdodDogZ2VuZXJhdGVkLnNpemUsIGxhbmRtYXJrczogZ2VuZXJhdGVkLmxhbmRtYXJrcywgLi4uKGdlbmVyYXRlZC50ZXJyYWluID8geyB0ZXJyYWluOiBnZW5lcmF0ZWQudGVycmFpbiB9IDoge30pIH0gOiBjcmVhdGVNYXAobWFwSWQpLFxuICAgIHBsYXllcnM6IGNyZWF0ZVBsYXllclN0YXRlcyhhY3RpdmVQbGF5ZXJzLCBvcHRpb25zKSxcbiAgICB1bml0czogZ2VuZXJhdGVkPy51bml0cyA/PyBjcmVhdGVJbml0aWFsVW5pdHMobWFwSWQsIGFjdGl2ZVBsYXllcnMsIHRlYW1zKSxcbiAgICBidWlsZGluZ3M6IGdlbmVyYXRlZD8uYnVpbGRpbmdzID8/IGNyZWF0ZUluaXRpYWxCdWlsZGluZ3MoYWN0aXZlUGxheWVycywgbWFwSWQsIHRlYW1zKSxcbiAgICByZXNvdXJjZXM6IGdlbmVyYXRlZD8ucmVzb3VyY2VzID8/IGNyZWF0ZUluaXRpYWxSZXNvdXJjZXMobWFwSWQsIGFjdGl2ZVBsYXllcnMsIHRlYW1zKSxcbiAgICBtZXJjZW5hcnlDYW1wczogZ2VuZXJhdGVkPy5tZXJjZW5hcnlDYW1wcyA/PyBjcmVhdGVJbml0aWFsTWVyY2VuYXJ5Q2FtcHMobWFwSWQpLFxuICAgIC4uLihzaG9wcy5sZW5ndGggPiAwID8geyBzaG9wcyB9IDoge30pLFxuICAgIGl0ZW1zOiBnZW5lcmF0ZWQ/Lml0ZW1zID8/IGNyZWF0ZUluaXRpYWxJdGVtcyhtYXBJZCksXG4gICAgcHJvamVjdGlsZXM6IFtdLFxuICAgIGVmZmVjdHM6IFtdLFxuICAgIC4uLihnZW5lcmF0ZWQ/Lm9ic3RhY2xlcy5sZW5ndGggPyB7IG9ic3RhY2xlczogZ2VuZXJhdGVkLm9ic3RhY2xlcyB9IDoge30pLFxuICAgIG5leHRJZDogUlVOVElNRV9JRF9TVEFSVCxcbiAgICBhY3RpdmVQbGF5ZXJzLFxuICAgIHRlYW1zLFxuICAgIHNwYXduVW5pdChvd25lcjogVW5pdFtcIm93bmVyXCJdLCBraW5kOiBVbml0S2luZCwgeDogbnVtYmVyLCB5OiBudW1iZXIsIGxhdW5jaFBvc2U/OiBTaGlwUG9zZSkge1xuICAgICAgLy8gQSB1bml0IGNvbWVzIG91dCBvbiB3YWxrYWJsZSBncm91bmQgKHNlZSBAQEB0ZXJyYWluKTogYmVzaWRlIGEgaGFsbCBiYWNrZWQgb250byBhIGZvcmVzdCwgYXQgaXRzIG5lYXJlc3QgZWRnZTsgYSBzaGlwXG4gICAgICAvLyBvbiB0aGUgbmVhcmVzdCB3YXRlci5cbiAgICAgIGNvbnN0IGF0ID0gbGF1bmNoUG9zZSA/PyB3YWxrYWJsZUdvYWwodGhpcy5tYXAsIHgsIHksIHVuaXRNb3ZlcihraW5kKSk7XG4gICAgICBjb25zdCB1bml0ID0gY3JlYXRlVW5pdChgdW5pdC0ke293bmVyfS0ke2tpbmR9LSR7dGhpcy5uZXh0SWR9YCwgb3duZXIsIGtpbmQsIGF0LngsIGF0LnkpO1xuICAgICAgaWYoc2hpcFByb2ZpbGUodW5pdCkpIHtcbiAgICAgICAgY29uc3QgdHJhZmZpYz1zaGlwVHJhZmZpYyh1bml0LHRoaXMudW5pdHMsSW5maW5pdHkpO1xuICAgICAgICBjb25zdCBib2RpZXM9Wy4uLnRoaXMudW5pdHMsLi4udGhpcy5idWlsZGluZ3MsLi4uKHRoaXMub2JzdGFjbGVzID8/IFtdKV07XG4gICAgICAgIGNvbnN0IGNsZWFyPShwb3NlOlNoaXBQb3NlKT0+dHJhZmZpYyhwb3NlLHBvc2UpICYmIHNoaXBCb2R5Q2xlYXJBdFBvc2UodGhpcy5tYXAsdW5pdCxwb3NlLGJvZGllcyk7XG4gICAgICAgIGNvbnN0IHBvc2U9bGF1bmNoUG9zZSA/IGNsZWFyKGxhdW5jaFBvc2UpID8gbGF1bmNoUG9zZSA6IHVuZGVmaW5lZCA6IG5lYXJlc3RTaGlwUG9zZSh0aGlzLm1hcCx1bml0LGF0LHVuaXQsY2xlYXIpO1xuICAgICAgICBpZighcG9zZSl0aHJvdyBuZXcgRXJyb3IoJ05vIGNsZWFyIHdhdGVyIGJlcnRoIGZvciB0aGlzIHNoaXAnKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbih1bml0LHt4OnBvc2UueCx5OnBvc2UueX0pO3VuaXQuc2FpbGluZz17aGVhZGluZzpwb3NlLmhlYWRpbmcsc3BlZWQ6MCxsb2FkOjAsYmFsYW5jZTowfTtcbiAgICAgIH1cbiAgICAgIHRoaXMubmV4dElkICs9IDE7XG4gICAgICBhcHBseVVuaXRVcGdyYWRlcyh0aGlzLCB1bml0KTtcbiAgICAgIHRoaXMudW5pdHMucHVzaCh1bml0KTtcbiAgICAgIGluaXRpYWxpemVTaGlwRXF1aXBtZW50KHsuLi50aGlzLHVuaXRzOlt1bml0XX0pO1xuICAgICAgbm9ybWFsaXplRXF1aXBtZW50KHsuLi50aGlzLHVuaXRzOlt1bml0XX0sdHJ1ZSk7XG4gICAgICByZWZyZXNoRXF1aXBtZW50TWFzcyh0aGlzLFt1bml0XSk7XG4gICAgICByZXR1cm4gdW5pdDtcbiAgICB9LFxuICB9IHNhdGlzZmllcyBHYW1lO1xuXG4gIGdhbWUubWFwLndpbmQgPSB7IC4uLkRFRkFVTFRfV0lORCB9O1xuICBpZiAob3B0aW9ucy5zY2VuYXJpbykgYXBwbHlTY2VuYXJpb092ZXJyaWRlKGdhbWUsIG9wdGlvbnMuc2NlbmFyaW8pO1xuICAvLyBFdmVyeSBidWlsZGluZyBzdGFuZHMgb24gd2hvbGUgY2VsbHMgKHNlZSBAQEBidWlsZGluZy1mb290cHJpbnQpLCBhIGhhbGwgdGhlIG1hcCBsYXlzIG9yIGEgc2NlbmFyaW8gc2VlZHMgYXMgb25lIGFcbiAgLy8gd29ya2VyIGxheXM6IGxhaWQgMTAgb2ZmIGl0cyBjZWxscycgbWlkZGxlLCBhIHN0YXJ0IGhhbGwgaGFkIHRoZSBjZWxscyBiZXNpZGUgb25lIG9mIGl0cyBzaWRlcyA3NyBmcm9tIGl0LCBwYXN0IHdoZXJlXG4gIC8vIGl0cyB3b3JrZXJzIGRyb3AgdGhlaXIgZ29sZC5cbiAgZm9yIChjb25zdCBidWlsZGluZyBvZiBnYW1lLmJ1aWxkaW5ncykgT2JqZWN0LmFzc2lnbihidWlsZGluZywgc25hcFRvRm9vdHByaW50KGdhbWUubWFwLCBidWlsZGluZy5yYWRpdXMsIGJ1aWxkaW5nKSk7XG4gIGluaXRpYWxpemVTaGlwRXF1aXBtZW50KGdhbWUpO1xuICBub3JtYWxpemVFcXVpcG1lbnQoZ2FtZSx0cnVlKTtcbiAgcmVmcmVzaEVxdWlwbWVudE1hc3MoZ2FtZSk7XG4gIGtlZXBTaGlwc09uV2F0ZXIoZ2FtZS5tYXAsZ2FtZS51bml0cyk7XG4gIHVwZGF0ZVN1cHBseVN0YXRlKGdhbWUpO1xuICBuYXRpdmVVbml0U3Bhd25lcnMuc2V0KGdhbWUsIGdhbWUuc3Bhd25Vbml0KTtcbiAgcmV0dXJuIGdhbWU7XG59XG5cbmZ1bmN0aW9uIHVuaXF1ZVBsYXllcnMocGxheWVyczogUGxheWVySWRbXSkge1xuICByZXR1cm4gWy4uLm5ldyBTZXQocGxheWVycyldO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVNYXRjaFN0YXRlKHBsYXllcnM6IFBsYXllcklkW10pOiBNYXRjaFN0YXRlIHtcbiAgcmV0dXJuIHtcbiAgICB3aW5uZXI6IG51bGwsXG4gICAgZW5kZWRBdFRpY2s6IG51bGwsXG4gICAgc3RhdHM6IHtcbiAgICAgIHVuaXRzS2lsbGVkOiB7IC4uLnplcm9QbGF5ZXJSZWNvcmQocGxheWVycyksIG5ldXRyYWw6IDAgfSxcbiAgICAgIHVuaXRzTG9zdDogeyAuLi56ZXJvUGxheWVyUmVjb3JkKHBsYXllcnMpLCBuZXV0cmFsOiAwIH0sXG4gICAgICBidWlsZGluZ3NEZXN0cm95ZWQ6IHplcm9QbGF5ZXJSZWNvcmQocGxheWVycyksXG4gICAgICBub25CYXNlQnVpbGRpbmdzRGVzdHJveWVkOiB6ZXJvUGxheWVyUmVjb3JkKHBsYXllcnMpLFxuICAgICAgZ29sZFNwZW50OiB6ZXJvUGxheWVyUmVjb3JkKHBsYXllcnMpLFxuICAgICAgbWVyY2VuYXJ5S2lsbHM6IHplcm9QbGF5ZXJSZWNvcmQocGxheWVycyksXG4gICAgICBuZXV0cmFsVW5pdHNLaWxsZWQ6IHplcm9QbGF5ZXJSZWNvcmQocGxheWVycyksXG4gICAgICB1bml0c0tpbGxlZEJ5TmV1dHJhbDogemVyb1BsYXllclJlY29yZChwbGF5ZXJzKSxcbiAgICB9LFxuICB9O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVQbGF5ZXJTdGF0ZXMoYWN0aXZlUGxheWVyczogUGxheWVySWRbXSwgb3B0aW9uczogQ3JlYXRlR2FtZU9wdGlvbnMpOiBQbGF5ZXJTdGF0ZU1hcCB7XG4gIGNvbnN0IHBsYXllcnMgPSB7fSBhcyBQbGF5ZXJTdGF0ZU1hcDtcbiAgZm9yIChjb25zdCBbaW5kZXgsIG93bmVyXSBvZiBbLi4ubmV3IFNldChbLi4uYWN0aXZlUGxheWVycywgXCJwbGF5ZXJcIiwgXCJlbmVteVwiLCBcImVuZW15MlwiXSldLmVudHJpZXMoKSkge1xuICAgIHBsYXllcnNbb3duZXJdID0ge1xuICAgICAgcmFjZTogb3B0aW9ucy5yYWNlcz8uW293bmVyXSA/PyBERUZBVUxUX1JBQ0VTW293bmVyXSA/PyAoaW5kZXggJSAyID09PSAwID8gXCJncm92ZVwiIDogXCJlbWJlclwiKSxcbiAgICAgIGdvbGQ6IDUwMCxcbiAgICAgIHN1cHBseVVzZWQ6IDAsXG4gICAgICBzdXBwbHlDYXA6IDAsXG4gICAgICB1cGdyYWRlczogY3JlYXRlRW1wdHlVcGdyYWRlTGV2ZWxzKCksXG4gICAgfTtcbiAgfVxuICBjb25zdCBjb2xvcnM9YXNzaWduUGxheWVyQ29sb3JzKE9iamVjdC5rZXlzKHBsYXllcnMpKTtcbiAgZm9yKGNvbnN0IFtvd25lcixwbGF5ZXJdIG9mIE9iamVjdC5lbnRyaWVzKHBsYXllcnMpKXBsYXllci5jb2xvcj1jb2xvcnNbb3duZXJdITtcbiAgcmV0dXJuIHBsYXllcnM7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZUVtcHR5VXBncmFkZUxldmVscygpIHtcbiAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhVUEdSQURFX0tJTkRTLm1hcCgodXBncmFkZUtpbmQpID0+IFt1cGdyYWRlS2luZCwgMF0pKSBhcyBQbGF5ZXJTdGF0ZVtcInVwZ3JhZGVzXCJdO1xufVxuXG5mdW5jdGlvbiB6ZXJvUGxheWVyUmVjb3JkKHBsYXllcnM6IFBsYXllcklkW10pIHtcbiAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhbLi4ubmV3IFNldChbLi4ucGxheWVycywgXCJwbGF5ZXJcIiwgXCJlbmVteVwiLCBcImVuZW15MlwiXSldLm1hcCgob3duZXIpID0+IFtvd25lciwgMF0pKSBhcyBQbGF5ZXJOdW1iZXJNYXA7XG59XG5cbmZ1bmN0aW9uIGFkZFRoaXJkUGxheWVyU3RhcnQoZ2FtZTogR2FtZSkge1xuICBnYW1lLmJ1aWxkaW5ncy5wdXNoKGNyZWF0ZUJ1aWxkaW5nKFwiYnVpbGRpbmctZW5lbXkyLXRvd25oYWxsXCIsIFwiZW5lbXkyXCIsIFwidG93bkhhbGxcIiwgZ2FtZS5tYXAud2lkdGggLSA0ODAsIDQ4MCwgdHJ1ZSkpO1xuICBnYW1lLnVuaXRzLnB1c2goXG4gICAgY3JlYXRlVW5pdChcInVuaXQtZW5lbXkyLXdvcmtlci0xXCIsIFwiZW5lbXkyXCIsIFwid29ya2VyXCIsIGdhbWUubWFwLndpZHRoIC0gNTkwLCA0NjApLFxuICAgIGNyZWF0ZVVuaXQoXCJ1bml0LWVuZW15Mi13b3JrZXItMlwiLCBcImVuZW15MlwiLCBcIndvcmtlclwiLCBnYW1lLm1hcC53aWR0aCAtIDU0MCwgNTQ1KSxcbiAgICBjcmVhdGVVbml0KFwidW5pdC1lbmVteTItd29ya2VyLTNcIiwgXCJlbmVteTJcIiwgXCJ3b3JrZXJcIiwgZ2FtZS5tYXAud2lkdGggLSA0NTAsIDUyMCksXG4gICk7XG4gIGdhbWUucmVzb3VyY2VzLnB1c2goeyBpZDogXCJnb2xkLWVuZW15Mi1tYWluXCIsIGtpbmQ6IFwiZ29sZE1pbmVcIiwgeDogZ2FtZS5tYXAud2lkdGggLSA1OTAsIHk6IDQ2MCwgYW1vdW50OiA4MDAwIH0pO1xufVxuXG5mdW5jdGlvbiBhcHBseVNjZW5hcmlvT3ZlcnJpZGUoZ2FtZTogR2FtZSwgc2NlbmFyaW86IFNjZW5hcmlvT3ZlcnJpZGUpIHtcbiAgaWYgKHNjZW5hcmlvLnJlcGxhY2VEZWZhdWx0VW5pdHMpIGdhbWUudW5pdHMgPSBbXTtcbiAgaWYgKHNjZW5hcmlvLnJlcGxhY2VEZWZhdWx0QnVpbGRpbmdzKSBnYW1lLmJ1aWxkaW5ncyA9IFtdO1xuICBpZiAoc2NlbmFyaW8ucmVwbGFjZURlZmF1bHRSZXNvdXJjZXMpIGdhbWUucmVzb3VyY2VzID0gW107XG4gIGlmIChzY2VuYXJpby5yZXBsYWNlRGVmYXVsdE1lcmNlbmFyeUNhbXBzKSBnYW1lLm1lcmNlbmFyeUNhbXBzID0gW107XG4gIGlmIChzY2VuYXJpby5yZXBsYWNlRGVmYXVsdExhbmRtYXJrcykgZ2FtZS5tYXAubGFuZG1hcmtzID0gW107XG4gIGNvbnN0IGlkcyA9IG5ldyBTZXQoW1xuICAgIC4uLmdhbWUudW5pdHMubWFwKCh1bml0KSA9PiB1bml0LmlkKSxcbiAgICAuLi5nYW1lLmJ1aWxkaW5ncy5tYXAoKGJ1aWxkaW5nKSA9PiBidWlsZGluZy5pZCksXG4gICAgLi4uZ2FtZS5yZXNvdXJjZXMubWFwKChyZXNvdXJjZSkgPT4gcmVzb3VyY2UuaWQpLFxuICAgIC4uLmdhbWUubWVyY2VuYXJ5Q2FtcHMubWFwKChjYW1wKSA9PiBjYW1wLmlkKSxcbiAgICAuLi4oZ2FtZS5zaG9wcyA/PyBbXSkubWFwKChzaG9wKSA9PiBzaG9wLmlkKSxcbiAgICAuLi5nYW1lLml0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5pZCksXG4gICAgLi4uZ2FtZS5tYXAubGFuZG1hcmtzLm1hcCgobGFuZG1hcmspID0+IGxhbmRtYXJrLmlkKSxcbiAgXSk7XG4gIGNvbnN0IGNsYWltSWQgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGlmIChpZHMuaGFzKGlkKSkgdGhyb3cgbmV3IEVycm9yKGBEdXBsaWNhdGUgc2NlbmFyaW8gaWQgJHtpZH1gKTtcbiAgICBpZHMuYWRkKGlkKTtcbiAgfTtcblxuICBmb3IgKGNvbnN0IFtvd25lciwgc2VlZF0gb2YgT2JqZWN0LmVudHJpZXMoc2NlbmFyaW8ucGxheWVycyA/PyB7fSkgYXMgW1BsYXllcklkLCBTY2VuYXJpb1BsYXllclNlZWRdW10pIHtcbiAgICBjb25zdCBwbGF5ZXIgPSBnYW1lLnBsYXllcnNbb3duZXJdO1xuICAgIGlmICghcGxheWVyKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gc2NlbmFyaW8gcGxheWVyICR7b3duZXJ9YCk7XG4gICAgaWYgKHNlZWQuZ29sZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzZWVkLmdvbGQpIHx8IHNlZWQuZ29sZCA8IDApIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBzY2VuYXJpbyBnb2xkIGZvciAke293bmVyfWApO1xuICAgICAgcGxheWVyLmdvbGQgPSByb3VuZEdvbGQoc2VlZC5nb2xkKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBbdXBncmFkZUtpbmQsIGxldmVsXSBvZiBPYmplY3QuZW50cmllcyhzZWVkLnVwZ3JhZGVzID8/IHt9KSBhcyBbVXBncmFkZUtpbmQsIG51bWJlcl1bXSkge1xuICAgICAgaWYgKCFOdW1iZXIuaXNJbnRlZ2VyKGxldmVsKSB8fCBsZXZlbCA8IDApIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBzY2VuYXJpbyAke3VwZ3JhZGVLaW5kfSBsZXZlbCBmb3IgJHtvd25lcn1gKTtcbiAgICAgIHBsYXllci51cGdyYWRlc1t1cGdyYWRlS2luZF0gPSBsZXZlbDtcbiAgICB9XG4gIH1cblxuICBmb3IgKGNvbnN0IHJlc291cmNlIG9mIHNjZW5hcmlvLmFkZFJlc291cmNlcyA/PyBbXSkge1xuICAgIGNsYWltSWQocmVzb3VyY2UuaWQpO1xuICAgIGdhbWUucmVzb3VyY2VzLnB1c2goeyAuLi5yZXNvdXJjZSB9KTtcbiAgfVxuICBmb3IgKGNvbnN0IGNhbXAgb2Ygc2NlbmFyaW8uYWRkTWVyY2VuYXJ5Q2FtcHMgPz8gW10pIHtcbiAgICBjbGFpbUlkKGNhbXAuaWQpO1xuICAgIGdhbWUubWVyY2VuYXJ5Q2FtcHMucHVzaCh7IC4uLmNhbXAgfSk7XG4gIH1cbiAgZm9yIChjb25zdCBzaG9wIG9mIHNjZW5hcmlvLmFkZFNob3BzID8/IFtdKSB7XG4gICAgY2xhaW1JZChzaG9wLmlkKTtcbiAgICAoZ2FtZS5zaG9wcyA/Pz0gW10pLnB1c2goeyAuLi5zaG9wLCBnb29kczogc2hvcC5nb29kcy5tYXAoKGdvb2QpID0+ICh7IC4uLmdvb2QgfSkpIH0pO1xuICB9XG4gIGZvciAoY29uc3QgaXRlbSBvZiBzY2VuYXJpby5hZGRJdGVtcyA/PyBbXSkge1xuICAgIGNsYWltSWQoaXRlbS5pZCk7XG4gICAgZ2FtZS5pdGVtcy5wdXNoKHsgLi4uaXRlbSB9KTtcbiAgfVxuICBmb3IgKGNvbnN0IHNlZWQgb2Ygc2NlbmFyaW8uYWRkVW5pdHMgPz8gW10pIHtcbiAgICBjbGFpbUlkKHNlZWQuaWQpO1xuICAgIGNvbnN0IHVuaXQgPSBjcmVhdGVVbml0KHNlZWQuaWQsIHNlZWQub3duZXIsIHNlZWQua2luZCwgc2VlZC54LCBzZWVkLnkpO1xuICAgIGFwcGx5VW5pdFVwZ3JhZGVzKGdhbWUsIHVuaXQpO1xuICAgIGlmIChzZWVkLnhwICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICghTnVtYmVyLmlzRmluaXRlKHNlZWQueHApIHx8IHNlZWQueHAgPCAwKSB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgc2NlbmFyaW8geHAgZm9yICR7c2VlZC5pZH1gKTtcbiAgICAgIHVuaXQueHAgPSBzZWVkLnhwO1xuICAgICAgYXBwbHlYcExldmVsKGdhbWUsIHVuaXQpO1xuICAgIH1cbiAgICBpZiAoc2VlZC5ocCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzZWVkLmhwKSB8fCBzZWVkLmhwIDw9IDAgfHwgc2VlZC5ocCA+IHVuaXQubWF4SHApIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBzY2VuYXJpbyBocCBmb3IgJHtzZWVkLmlkfWApO1xuICAgICAgdW5pdC5ocCA9IHNlZWQuaHA7XG4gICAgfVxuICAgIGlmIChzZWVkLmhwUmF0aW8gIT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoc2VlZC5ocFJhdGlvKSB8fCBzZWVkLmhwUmF0aW8gPD0gMCB8fCBzZWVkLmhwUmF0aW8gPiAxKSB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgc2NlbmFyaW8gaHBSYXRpbyBmb3IgJHtzZWVkLmlkfWApO1xuICAgICAgdW5pdC5ocCA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQodW5pdC5tYXhIcCAqIHNlZWQuaHBSYXRpbykpO1xuICAgIH1cbiAgICBpZiAoc2VlZC5vcmRlcikgdW5pdC5vcmRlciA9IHsgLi4uc2VlZC5vcmRlciB9O1xuICAgIGdhbWUudW5pdHMucHVzaCh1bml0KTtcbiAgfVxuICBmb3IgKGNvbnN0IHNlZWQgb2Ygc2NlbmFyaW8uYWRkQnVpbGRpbmdzID8/IFtdKSB7XG4gICAgY2xhaW1JZChzZWVkLmlkKTtcbiAgICBjb25zdCBidWlsZGluZyA9IGNyZWF0ZUJ1aWxkaW5nKHNlZWQuaWQsIHNlZWQub3duZXIsIHNlZWQua2luZCwgc2VlZC54LCBzZWVkLnksIHNlZWQuY29tcGxldGUgPz8gdHJ1ZSk7XG4gICAgaWYgKHNlZWQubWF4SHAgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoc2VlZC5tYXhIcCkgfHwgc2VlZC5tYXhIcCA8PSAwKSB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgc2NlbmFyaW8gbWF4SHAgZm9yICR7c2VlZC5pZH1gKTtcbiAgICAgIGJ1aWxkaW5nLm1heEhwID0gc2VlZC5tYXhIcDtcbiAgICB9XG4gICAgaWYgKHNlZWQuaHAgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoc2VlZC5ocCkgfHwgc2VlZC5ocCA8PSAwIHx8IHNlZWQuaHAgPiBidWlsZGluZy5tYXhIcCkgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIHNjZW5hcmlvIGhwIGZvciAke3NlZWQuaWR9YCk7XG4gICAgICBidWlsZGluZy5ocCA9IHNlZWQuaHA7XG4gICAgfVxuICAgIGdhbWUuYnVpbGRpbmdzLnB1c2goYnVpbGRpbmcpO1xuICB9XG4gIGZvciAoY29uc3QgbGFuZG1hcmsgb2Ygc2NlbmFyaW8uYWRkTGFuZG1hcmtzID8/IFtdKSB7XG4gICAgY2xhaW1JZChsYW5kbWFyay5pZCk7XG4gICAgZ2FtZS5tYXAubGFuZG1hcmtzLnB1c2goeyAuLi5sYW5kbWFyayB9KTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNzdWVDb21tYW5kKGdhbWU6IEdhbWUsIGNvbW1hbmQ6IEdhbWVDb21tYW5kKSB7XG4gIGlzc3VlUGxheWVyQ29tbWFuZChnYW1lLCBcInBsYXllclwiLCBjb21tYW5kKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzc3VlUGxheWVyQ29tbWFuZChnYW1lOiBHYW1lLCBvd25lcjogUGxheWVySWQsIGNvbW1hbmQ6IEdhbWVDb21tYW5kKSB7XG4gIGlmICghZ2FtZS5wbGF5ZXJzW293bmVyXSkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIHBsYXllciAke293bmVyfWApO1xuICBjb25zdCBjYWJpbk9wZXJhbmRzID0gJ3VuaXRJZHMnIGluIGNvbW1hbmQgPyBbLi4uY29tbWFuZC51bml0SWRzXSA6ICd1bml0SWQnIGluIGNvbW1hbmQgPyBbY29tbWFuZC51bml0SWRdIDogW107XG4gIGlmICgndGFyZ2V0SWQnIGluIGNvbW1hbmQgJiYgY29tbWFuZC50YXJnZXRJZCkgY2FiaW5PcGVyYW5kcy5wdXNoKGNvbW1hbmQudGFyZ2V0SWQpO1xuICBpZiAoJ3JlY2lwaWVudElkJyBpbiBjb21tYW5kICYmIGNvbW1hbmQucmVjaXBpZW50SWQpIGNhYmluT3BlcmFuZHMucHVzaChjb21tYW5kLnJlY2lwaWVudElkKTtcbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ3VubG9hZFBhc3NlbmdlcicpIGNhYmluT3BlcmFuZHMucHVzaChjb21tYW5kLnBhc3NlbmdlcklkKTtcbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ3RyYW5zZmVySXRlbScpIHtcbiAgICBjb25zdCBpdGVtID0gZ2FtZS5pdGVtcy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gY29tbWFuZC5pdGVtSWQpO1xuICAgIGlmIChpdGVtPy5jYXJyaWVySWQpIGNhYmluT3BlcmFuZHMucHVzaChpdGVtLmNhcnJpZXJJZCk7XG4gICAgaWYgKCd1bml0SWQnIGluIGNvbW1hbmQuZGVzdGluYXRpb24pIGNhYmluT3BlcmFuZHMucHVzaChjb21tYW5kLmRlc3RpbmF0aW9uLnVuaXRJZCk7XG4gICAgZWxzZSBpZiAoJ2luc3RhbGxlcklkJyBpbiBjb21tYW5kLmRlc3RpbmF0aW9uICYmIGNvbW1hbmQuZGVzdGluYXRpb24uaW5zdGFsbGVySWQpIGNhYmluT3BlcmFuZHMucHVzaChjb21tYW5kLmRlc3RpbmF0aW9uLmluc3RhbGxlcklkKTtcbiAgfVxuICBpZiAoY29tbWFuZC50eXBlID09PSAnZW50ZXJDYWJpbicgfHwgY29tbWFuZC50eXBlID09PSAnbGVhdmVDYWJpbicgfHwgZ2FtZS51bml0cy5zb21lKHVuaXQgPT4gY2FiaW5PcGVyYW5kcy5pbmNsdWRlcyh1bml0LmlkKSAmJiBpc0luQ2FiaW4odW5pdCkpKSB7XG4gICAgY29uc3QgZXJyb3IgPSBjaGVja0NvbW1hbmRMZWdhbGl0eShnYW1lLCBvd25lciwgY29tbWFuZCk7XG4gICAgaWYgKGVycm9yKSB0aHJvdyBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gIH1cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gJ2VudGVyQ2FiaW4nIHx8IGNvbW1hbmQudHlwZSA9PT0gJ2xlYXZlQ2FiaW4nKSB7XG4gICAgY29uc3Qgc2VsZWN0ZWQ9dW5pdHNCeUlkcyhnYW1lLGNvbW1hbmQudW5pdElkcyxvd25lcik7XG4gICAgY29uc3QgYWRtaXR0ZWQ9Y29tbWFuZC50eXBlPT09J2VudGVyQ2FiaW4nID8gbmV3IFNldChjYWJpbkdyb3VwU2VsZWN0aW9uKGdhbWUsc2VsZWN0ZWQpKSA6IHVuZGVmaW5lZDtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2Ygc2VsZWN0ZWQpIHtcbiAgICAgIGlmIChjb21tYW5kLnR5cGUgPT09ICdsZWF2ZUNhYmluJykgbGVhdmVDYWJpbihnYW1lLHVuaXQpO1xuICAgICAgZWxzZSBpZiAoYWRtaXR0ZWQhLmhhcyh1bml0LmlkKSkgYXNzaWduVW5pdE9yZGVyKHVuaXQse3R5cGU6J2VudGVyQ2FiaW4nLHNoaXBJZDp1bml0LmRlY2shLnNoaXBJZH0pO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgaWYoY29tbWFuZC50eXBlPT09J2JvYXJkU2hpcCcpIHtcbiAgICBjb25zdCBlcnJvcj1jaGVja0NvbW1hbmRMZWdhbGl0eShnYW1lLG93bmVyLGNvbW1hbmQpO1xuICAgIGlmKGVycm9yKXRocm93IG5ldyBFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICBjb25zdCBzaGlwcz11bml0c0J5SWRzKGdhbWUsY29tbWFuZC51bml0SWRzLG93bmVyKS5maWx0ZXIoc2hpcD0+c2hpcFByb2ZpbGUoc2hpcCkpO1xuICAgIGlmKCFjb21tYW5kLnF1ZXVlZCljYW5jZWxDcmV3UmVuZGV6dm91cyhnYW1lLnVuaXRzLG5ldyBTZXQoc2hpcHMubWFwKHNoaXA9PnNoaXAuaWQpKSk7XG4gICAgZm9yKGNvbnN0IHNoaXAgb2Ygc2hpcHMpXG4gICAgICBhc3NpZ25Vbml0T3JkZXIoc2hpcCx7dHlwZTonYm9hcmRTaGlwJyx0YXJnZXRJZDpjb21tYW5kLnRhcmdldElkfSxjb21tYW5kLnF1ZXVlZCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmKGNvbW1hbmQudHlwZT09PSdjYW5jZWxCb2FyZFNoaXAnKSB7XG4gICAgY29uc3QgZXJyb3I9Y2hlY2tDb21tYW5kTGVnYWxpdHkoZ2FtZSxvd25lcixjb21tYW5kKTtcbiAgICBpZihlcnJvcil0aHJvdyBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgY29uc3Qgc2hpcHM9dW5pdHNCeUlkcyhnYW1lLGNvbW1hbmQudW5pdElkcyxvd25lcikuZmlsdGVyKHNoaXA9PnNoaXBQcm9maWxlKHNoaXApKTtcbiAgICBjYW5jZWxDcmV3UmVuZGV6dm91cyhnYW1lLnVuaXRzLG5ldyBTZXQoc2hpcHMubWFwKHNoaXA9PnNoaXAuaWQpKSk7XG4gICAgZm9yKGNvbnN0IHNoaXAgb2Ygc2hpcHMpIHtcbiAgICAgIGNhbmNlbFNoaXBCb2FyZGluZyhzaGlwKTtcbiAgICAgIGlmKHNoaXAub3JkZXIudHlwZT09PSdib2FyZFNoaXAnKWFzc2lnblVuaXRPcmRlcihzaGlwLHt0eXBlOidpZGxlJ30pO1xuICAgIH1cbiAgICBzZXR0bGVHYW5nd2F5Q3Jvc3NpbmdzKGdhbWUudW5pdHMpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoY29tbWFuZC50eXBlID09PSBcImxlYXJuVmV0ZXJhblNraWxsXCIpIHtcbiAgICBjb25zdCBlcnJvciA9IGNoZWNrQ29tbWFuZExlZ2FsaXR5KGdhbWUsIG93bmVyLCBjb21tYW5kKTtcbiAgICBpZiAoZXJyb3IpIHRocm93IG5ldyBFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICBjb25zdCB1bml0ID0gZ2FtZS51bml0cy5maW5kKHVuaXQgPT4gdW5pdC5pZCA9PT0gY29tbWFuZC51bml0SWQpITtcbiAgICB1bml0LnZldGVyYW5Ta2lsbCA9IGNvbW1hbmQuc2tpbGw7XG4gICAgcmVmcmVzaFZldGVyYW5GcmFtZShnYW1lKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYoXCJ1bml0SWRzXCIgaW4gY29tbWFuZCAmJiAhKFwicXVldWVkXCIgaW4gY29tbWFuZCAmJiBjb21tYW5kLnF1ZXVlZCkgJiYgW1wibW92ZVwiLFwiYXR0YWNrTW92ZVwiLFwic3RvcFwiLFwiaG9sZFBvc2l0aW9uXCIsXCJ1bmxvYWRcIixcImZvbGxvd1wiLFwiYWltXCIsXCJhdHRhY2tcIl0uaW5jbHVkZXMoY29tbWFuZC50eXBlKSl7XG4gICAgY29uc3Qgc2hpcHM9bmV3IFNldCh1bml0c0J5SWRzKGdhbWUsY29tbWFuZC51bml0SWRzLG93bmVyKS5maWx0ZXIoc2hpcD0+c2hpcFByb2ZpbGUoc2hpcCkpLm1hcChzaGlwPT5zaGlwLmlkKSk7XG4gICAgaWYoc2hpcHMuc2l6ZSljYW5jZWxDcmV3UmVuZGV6dm91cyhnYW1lLnVuaXRzLHNoaXBzKTtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwibW92ZVwiKSB7XG4gICAgZm9yIChjb25zdCB1bml0IG9mIHVuaXRzQnlJZHMoZ2FtZSwgY29tbWFuZC51bml0SWRzLCBvd25lcikpIHtcbiAgICAgIGFzc2lnblVuaXRPcmRlcih1bml0LCBkZWNrUG9pbnRPcmRlcihnYW1lLCB1bml0LCB7IHR5cGU6IFwibW92ZVwiLCB4OiBjb21tYW5kLngsIHk6IGNvbW1hbmQueSwgLi4uKGNvbW1hbmQuYXZvaWRDb21iYXQgPyB7YXZvaWRDb21iYXQ6dHJ1ZX0gOiB7fSkgfSksIGNvbW1hbmQucXVldWVkKTtcbiAgICB9XG4gICAgYWRkRWZmZWN0KGdhbWUsIGNvbW1hbmQucXVldWVkID8gXCJxdWV1ZWRNb3ZlXCIgOiBcIm1vdmVcIiwgY29tbWFuZC54LCBjb21tYW5kLnksIGNvbW1hbmQucXVldWVkID8gMzggOiAyNCwgeyBvd25lciB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcImF0dGFja01vdmVcIikge1xuICAgIGZvciAoY29uc3QgdW5pdCBvZiB1bml0c0J5SWRzKGdhbWUsIGNvbW1hbmQudW5pdElkcywgb3duZXIpKSB7XG4gICAgICBhc3NpZ25Vbml0T3JkZXIodW5pdCwgZGVja1BvaW50T3JkZXIoZ2FtZSwgdW5pdCwgeyB0eXBlOiB1bml0LmF0dGFja0RhbWFnZSA+IDAgPyBcImF0dGFja01vdmVcIiA6IFwibW92ZVwiLCB4OiBjb21tYW5kLngsIHk6IGNvbW1hbmQueSB9KSwgY29tbWFuZC5xdWV1ZWQpO1xuICAgIH1cbiAgICBhZGRFZmZlY3QoZ2FtZSwgY29tbWFuZC5xdWV1ZWQgPyBcInF1ZXVlZEF0dGFja1wiIDogXCJhdHRhY2tcIiwgY29tbWFuZC54LCBjb21tYW5kLnksIGNvbW1hbmQucXVldWVkID8gNDIgOiAyOCwgeyBvd25lciB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcInN0b3BcIikge1xuICAgIGZvciAoY29uc3QgdW5pdCBvZiB1bml0c0J5SWRzKGdhbWUsIGNvbW1hbmQudW5pdElkcywgb3duZXIpKSBhc3NpZ25Vbml0T3JkZXIodW5pdCwgeyB0eXBlOiBcImlkbGVcIiB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcImFpbVwiKSB7XG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoY29tbWFuZC54KSB8fCAhTnVtYmVyLmlzRmluaXRlKGNvbW1hbmQueSkpIHRocm93IG5ldyBFcnJvcihcIkFpbSByZXF1aXJlcyBhIGZpbml0ZSBwb2ludFwiKTtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgdW5pdHNCeUlkcyhnYW1lLCBjb21tYW5kLnVuaXRJZHMsIG93bmVyKSkge1xuICAgICAgaWYgKGFpbWluZ1Byb2ZpbGUod2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCkpKSBhc3NpZ25Vbml0T3JkZXIodW5pdCwgeyB0eXBlOiBcImFpbVwiLCB4OiBjbGFtcChjb21tYW5kLngsIDAsIGdhbWUubWFwLndpZHRoKSwgeTogY2xhbXAoY29tbWFuZC55LCAwLCBnYW1lLm1hcC5oZWlnaHQpIH0sIGNvbW1hbmQucXVldWVkKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gQEBAaG9sZC1wb3NpdGlvbiAtIEEgdW5pdCB0b2xkIHRvIGhvbGQgaXRzIGdyb3VuZCBzdGF5cyB3aGVyZSBpdCBzdGFuZHM6IGl0IHN0cmlrZXMgd2hhdGV2ZXIgY29tZXMgd2l0aGluIGl0cyBvd24gcmVhY2hcbiAgLy8gYW5kIG5vdGhpbmcgZnVydGhlciwgZG9lcyBub3QgdHVybiBvbiBhbiBhdHRhY2tlciBvdXQgb2YgcmVhY2gsIGFuZCBkb2VzIG5vdCBkYXNoLiBBbiBpZGxlIG9yIGF0dGFjay1tb3ZpbmcgdW5pdFxuICAvLyBjaGFzZXMgd2hvZXZlciBzaG9vdHMgaXQgKHNlZSBwbGF5ZXItYWdncm8pLCB3aGljaCBsZXRzIGEgc2hvb3RlciBkcmF3IGEgd2hvbGUgYXJteSBvdXQgYWZ0ZXIgaXQuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwiaG9sZFBvc2l0aW9uXCIpIHtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgdW5pdHNCeUlkcyhnYW1lLCBjb21tYW5kLnVuaXRJZHMsIG93bmVyKSkge1xuICAgICAgaWYgKHVuaXQua2luZCA9PT0gXCJ3b3JrZXJcIikgY29udGludWU7XG4gICAgICBhc3NpZ25Vbml0T3JkZXIodW5pdCwgeyB0eXBlOiBcImhvbGRcIiwgeDogdW5pdC54LCB5OiB1bml0LnkgfSwgY29tbWFuZC5xdWV1ZWQpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcImF0dGFja1wiKSB7XG4gICAgLy8gQSB1bml0IHdpdGhvdXQgYSB3ZWFwb24gKGEgdHJhbnNwb3J0KSBoYXMgbm90aGluZyB0byBhdHRhY2sgd2l0aC5cbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgdW5pdHNCeUlkcyhnYW1lLCBjb21tYW5kLnVuaXRJZHMsIG93bmVyKSkge1xuICAgICAgaWYgKHVuaXQuYXR0YWNrRGFtYWdlID4gMCkgYXNzaWduVW5pdE9yZGVyKHVuaXQsIHsgdHlwZTogXCJhdHRhY2tcIiwgdGFyZ2V0SWQ6IGNvbW1hbmQudGFyZ2V0SWQgfSwgY29tbWFuZC5xdWV1ZWQpO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXQgPSBmaW5kU3RyaWtlVGFyZ2V0KGdhbWUsIGNvbW1hbmQudGFyZ2V0SWQpO1xuICAgIGlmICh0YXJnZXQpIGFkZEVmZmVjdChnYW1lLCBjb21tYW5kLnF1ZXVlZCA/IFwicXVldWVkQXR0YWNrVGFyZ2V0XCIgOiBcImF0dGFja1RhcmdldFwiLCB0YXJnZXQueCwgdGFyZ2V0LnksIGNvbW1hbmQucXVldWVkID8gNDQgOiAzMiwgeyBvd25lciB9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBAQEBmb2xsb3cgLSBVbml0cyB0b2xkIHRvIGZvbGxvdyBhbiBvd24gdW5pdCBvciBhbiBhbGx5J3Mgd2FsayBhZnRlciBpdCBhbmQga2VlcCBuZWFyIGl0IHVudGlsIGl0IGRpZXMgb3IgdGhleSBhcmVcbiAgLy8gdG9sZCBvdGhlcndpc2UsIGFzIGluIFdhcmNyYWZ0IElJSTsgYSByaWdodC1jbGljayBvbiBhbiBhbGx5J3MgdW5pdCBnaXZlcyBpdCAoYSByYWxseSBwb2ludCBvbnRvIGFuIG93biB1bml0IHRvbykuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwiZm9sbG93XCIpIHtcbiAgICBjb25zdCB0YXJnZXQgPSBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IGNvbW1hbmQudGFyZ2V0SWQgJiYgIWFyZUVuZW15T3duZXJzKGdhbWUsIHVuaXQub3duZXIsIG93bmVyKSk7XG4gICAgaWYgKCF0YXJnZXQpIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBmcmllbmRseSB1bml0ICR7Y29tbWFuZC50YXJnZXRJZH1gKTtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgdW5pdHNCeUlkcyhnYW1lLCBjb21tYW5kLnVuaXRJZHMsIG93bmVyKSkge1xuICAgICAgaWYgKHVuaXQgIT09IHRhcmdldCkgYXNzaWduVW5pdE9yZGVyKHVuaXQsIHsgdHlwZTogXCJmb2xsb3dcIiwgdGFyZ2V0SWQ6IHRhcmdldC5pZCB9LCBjb21tYW5kLnF1ZXVlZCk7XG4gICAgfVxuICAgIGFkZEVmZmVjdChnYW1lLCBjb21tYW5kLnF1ZXVlZCA/IFwicXVldWVkTW92ZVwiIDogXCJtb3ZlXCIsIHRhcmdldC54LCB0YXJnZXQueSwgY29tbWFuZC5xdWV1ZWQgPyAzOCA6IDI0LCB7IG93bmVyIH0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwibWluZVwiKSB7XG4gICAgY29uc3QgcmVzb3VyY2UgPSBnYW1lLnJlc291cmNlcy5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gY29tbWFuZC5yZXNvdXJjZUlkKTtcbiAgICBpZiAoIXJlc291cmNlKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gcmVzb3VyY2UgJHtjb21tYW5kLnJlc291cmNlSWR9YCk7XG4gICAgZm9yIChjb25zdCB1bml0IG9mIHVuaXRzQnlJZHMoZ2FtZSwgY29tbWFuZC51bml0SWRzLCBvd25lcikuZmlsdGVyKCh1bml0KSA9PiB1bml0LmtpbmQgPT09IFwid29ya2VyXCIpKSB7XG4gICAgICAvLyBSZWFmZmlybWluZyB0aGUgc2FtZSBtaW5lIGtlZXBzIHRoZSBjdXJyZW50IGhhdWwgYW5kIHF1ZXVlIHBvc2l0aW9uLlxuICAgICAgLy8gUmVzZXR0aW5nIGdhdGhlciBoZXJlIGRpc2NhcmRlZCBjb21wbGV0ZWQgd29yayBvbiBldmVyeSByaWdodC1jbGljay5cbiAgICAgIGNvbnN0IG9yZGVyOiBVbml0T3JkZXIgPSAhY29tbWFuZC5xdWV1ZWQgJiYgdW5pdC5vcmRlci50eXBlID09PSBcIm1pbmVcIiAmJiB1bml0Lm9yZGVyLnJlc291cmNlSWQgPT09IHJlc291cmNlLmlkXG4gICAgICAgID8gdW5pdC5vcmRlclxuICAgICAgICA6IHsgdHlwZTogXCJtaW5lXCIsIHJlc291cmNlSWQ6IHJlc291cmNlLmlkLCBwaGFzZTogdW5pdC5jYXJyeWluZ0dvbGQgPiAwID8gXCJyZXR1cm5cIiA6IFwidG9NaW5lXCIsIHRpbWVyOiAwIH07XG4gICAgICBhc3NpZ25Vbml0T3JkZXIodW5pdCwgb3JkZXIsIGNvbW1hbmQucXVldWVkKTtcbiAgICB9XG4gICAgYWRkRWZmZWN0KGdhbWUsIGNvbW1hbmQucXVldWVkID8gXCJxdWV1ZWRNaW5lXCIgOiBcIm1pbmVcIiwgcmVzb3VyY2UueCwgcmVzb3VyY2UueSwgY29tbWFuZC5xdWV1ZWQgPyA0NCA6IDMwLCB7IG93bmVyIH0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwicmVwYWlyXCIpIHtcbiAgICBjb25zdCBidWlsZGluZyA9IGdhbWUuYnVpbGRpbmdzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBjb21tYW5kLmJ1aWxkaW5nSWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSBvd25lcik7XG4gICAgaWYgKCFidWlsZGluZykgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IGJ1aWxkaW5nICR7Y29tbWFuZC5idWlsZGluZ0lkfWApO1xuICAgIGlmIChidWlsZGluZy5ocCA+PSBidWlsZGluZy5tYXhIcCkgdGhyb3cgbmV3IEVycm9yKGAke2J1aWxkaW5nLmtpbmR9IGlzIGFscmVhZHkgZnVsbHkgcmVwYWlyZWRgKTtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgdW5pdHNCeUlkcyhnYW1lLCBjb21tYW5kLnVuaXRJZHMsIG93bmVyKS5maWx0ZXIoKHVuaXQpID0+IHVuaXQua2luZCA9PT0gXCJ3b3JrZXJcIikpIHtcbiAgICAgIGFzc2lnblVuaXRPcmRlcih1bml0LCB7IHR5cGU6IFwicmVwYWlyXCIsIGJ1aWxkaW5nSWQ6IGJ1aWxkaW5nLmlkIH0sIGNvbW1hbmQucXVldWVkKTtcbiAgICAgIGlmICh1bml0Lm9yZGVyLnR5cGUgPT09IFwicmVwYWlyXCIgJiYgdW5pdC5vcmRlci5idWlsZGluZ0lkID09PSBidWlsZGluZy5pZCkgdW5pdC5jb29sZG93biA9IDA7XG4gICAgfVxuICAgIGFkZFJlcGFpckhhbW1lckVmZmVjdChnYW1lLCBidWlsZGluZywgY29tbWFuZC5xdWV1ZWQpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoY29tbWFuZC50eXBlID09PSBcInJlcGFpclVuaXRcIiB8fCBjb21tYW5kLnR5cGUgPT09IFwicmVwYWlyU2hpcFwiKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gZ2FtZS51bml0cy5maW5kKGNhbmRpZGF0ZSA9PiBjYW5kaWRhdGUuaWQgPT09IGNvbW1hbmQudGFyZ2V0SWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSBvd25lclxuICAgICAgJiYgKGNvbW1hbmQudHlwZSAhPT0gXCJyZXBhaXJTaGlwXCIgfHwgdW5pdE1vdmVyKGNhbmRpZGF0ZS5raW5kKSA9PT0gXCJzZWFcIikpO1xuICAgIGlmICghdGFyZ2V0KSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gJHtvd25lcn0gcmVwYWlyIHRhcmdldCAke2NvbW1hbmQudGFyZ2V0SWR9YCk7XG4gICAgaWYgKCF1bml0TmVlZHNSZXBhaXIoZ2FtZSwgdGFyZ2V0KSkgdGhyb3cgbmV3IEVycm9yKGAke3RhcmdldC5raW5kfSBjYW5ub3QgYmUgcmVwYWlyZWQgb3IgaXMgYWxyZWFkeSBmdWxseSByZXBhaXJlZGApO1xuICAgIGZvciAoY29uc3Qgd29ya2VyIG9mIHVuaXRzQnlJZHMoZ2FtZSwgY29tbWFuZC51bml0SWRzLCBvd25lcikuZmlsdGVyKHVuaXQgPT4gdW5pdC5raW5kID09PSBcIndvcmtlclwiKSlcbiAgICAgIGFzc2lnblVuaXRPcmRlcih3b3JrZXIsIHsgdHlwZTogXCJyZXBhaXJVbml0XCIsIHRhcmdldElkOiB0YXJnZXQuaWQgfSwgY29tbWFuZC5xdWV1ZWQpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwiYnVpbGRcIikge1xuICAgIGNvbnN0IHdvcmtlciA9IGdhbWUudW5pdHMuZmluZCgodW5pdCkgPT4gdW5pdC5pZCA9PT0gY29tbWFuZC51bml0SWQgJiYgdW5pdC5vd25lciA9PT0gb3duZXIgJiYgdW5pdC5raW5kID09PSBcIndvcmtlclwiKTtcbiAgICBpZiAoIXdvcmtlcikgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IHdvcmtlciAke2NvbW1hbmQudW5pdElkfWApO1xuICAgIGlmICghUkFDRV9ERUZTW3BsYXllclN0YXRlKGdhbWUsIG93bmVyKS5yYWNlXS5idWlsZGFibGVCdWlsZGluZ3MuaW5jbHVkZXMoY29tbWFuZC5idWlsZGluZ0tpbmQpKSB0aHJvdyBuZXcgRXJyb3IoYCR7cGxheWVyU3RhdGUoZ2FtZSwgb3duZXIpLnJhY2V9IHJhY2UgY2Fubm90IGJ1aWxkICR7Y29tbWFuZC5idWlsZGluZ0tpbmR9YCk7XG4gICAgY29uc3QgYmxvY2tlciA9IGJ1aWxkaW5nUGxhY2VtZW50QmxvY2tlcihnYW1lLCBjb21tYW5kLmJ1aWxkaW5nS2luZCwgY29tbWFuZCk7XG4gICAgaWYgKGJsb2NrZXIpIHRocm93IG5ldyBFcnJvcihgJHtjb21tYW5kLmJ1aWxkaW5nS2luZH0gcGxhY2VtZW50IGlzIHRvbyBjbG9zZSB0byAke2Jsb2NrZXIua2luZH1gKTtcbiAgICBpZiAodGVycmFpbkJsb2Nrc1BsYWNlbWVudChnYW1lLm1hcCwgY29tbWFuZC5idWlsZGluZ0tpbmQsIGNvbW1hbmQpKSB0aHJvdyBuZXcgRXJyb3IoYCR7Y29tbWFuZC5idWlsZGluZ0tpbmR9IHBsYWNlbWVudCBpcyBvbiBibG9ja2VkIGdyb3VuZGApO1xuICAgIGlmIChwbGF5ZXJTdGF0ZShnYW1lLCBvd25lcikuZ29sZCA8IEJVSUxESU5HX0RFRlNbY29tbWFuZC5idWlsZGluZ0tpbmRdLmNvc3QpIHRocm93IG5ldyBFcnJvcihcIk5vdCBlbm91Z2ggZ29sZFwiKTtcbiAgICBjb25zdCBhdCA9IHNuYXBUb0Zvb3RwcmludChnYW1lLm1hcCwgQlVJTERJTkdfREVGU1tjb21tYW5kLmJ1aWxkaW5nS2luZF0ucmFkaXVzLCBjb21tYW5kKTtcbiAgICAvLyBBIHBsYW4gaXMgYW4gb3JkZXIsIG5vdCBhbiBlbnRpdHk6IG5vIHJlbW90ZSBIUCwgdmlzaW9uLCBjb2xsaXNpb24gb3IgYXR0YWNrIHRhcmdldC5cbiAgICBhc3NpZ25Vbml0T3JkZXIod29ya2VyLCB7IHR5cGU6IFwiYnVpbGRcIiwgYnVpbGRpbmdLaW5kOiBjb21tYW5kLmJ1aWxkaW5nS2luZCwgLi4uYXQsIHByb2dyZXNzVGljazogZ2FtZS50aWNrLCBwcm9ncmVzc1g6IHdvcmtlci54LCBwcm9ncmVzc1k6IHdvcmtlci55IH0pO1xuXG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJjYW5jZWxUcmFpbmluZ1wiKSB7XG4gICAgY29uc3QgYnVpbGRpbmcgPSBnYW1lLmJ1aWxkaW5ncy5maW5kKGIgPT4gYi5pZCA9PT0gY29tbWFuZC5idWlsZGluZ0lkICYmIGIub3duZXIgPT09IG93bmVyKTtcbiAgICBpZiAoIWJ1aWxkaW5nKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gJHtvd25lcn0gYnVpbGRpbmcgJHtjb21tYW5kLmJ1aWxkaW5nSWR9YCk7XG4gICAgY29uc3QgaW5kZXggPSBidWlsZGluZy5xdWV1ZS5maW5kSW5kZXgoam9iID0+IGpvYi5pZCA9PT0gY29tbWFuZC5qb2JJZCk7XG4gICAgLy8gQSBkZWxheWVkL2R1cGxpY2F0ZSBjbGljayBtdXN0IG5ldmVyIGNhbmNlbCB0aGUgZm9sbG93aW5nIHNvbGRpZXIuXG4gICAgaWYgKGluZGV4IDwgMCkgcmV0dXJuO1xuICAgIGNvbnN0IFtqb2JdID0gYnVpbGRpbmcucXVldWUuc3BsaWNlKGluZGV4LCAxKTtcbiAgICBjb25zdCByZWZ1bmQ9am9iIS5wYWlkR29sZCA/PyBVTklUX0RFRlNbam9iIS51bml0S2luZF0uY29zdDtcbiAgICBwbGF5ZXJTdGF0ZShnYW1lLCBvd25lcikuZ29sZCA9IGFkZEdvbGQocGxheWVyU3RhdGUoZ2FtZSwgb3duZXIpLmdvbGQsIHJlZnVuZCk7XG4gICAgZ2FtZS5tYXRjaC5zdGF0cy5nb2xkU3BlbnRbb3duZXJdID0gTWF0aC5tYXgoMCwgKGdhbWUubWF0Y2guc3RhdHMuZ29sZFNwZW50W293bmVyXSA/PyAwKSAtIHJlZnVuZCk7XG4gICAgdXBkYXRlU3VwcGx5U3RhdGUoZ2FtZSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJzZXRSYWxseVwiKSB7XG4gICAgc2V0UmFsbHkoZ2FtZSwgb3duZXIsIGNvbW1hbmQuYnVpbGRpbmdJZHMsIGNvbW1hbmQueCwgY29tbWFuZC55LCBjb21tYW5kLnRhcmdldCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJjYXN0XCIpIHtcbiAgICBjb25zdCB1bml0Q291bnQgPSBnYW1lLnVuaXRzLmxlbmd0aDtcbiAgICBjYXN0QWJpbGl0eShnYW1lLCBvd25lciwgY29tbWFuZC51bml0SWQsIGNvbW1hbmQuYWJpbGl0eSwgY29tbWFuZC50YXJnZXRJZCwgY29tbWFuZC54LCBjb21tYW5kLnksIGNvbW1hbmQucXVldWVkKTtcbiAgICBpZiAoZ2FtZS51bml0cy5sZW5ndGggIT09IHVuaXRDb3VudCkgcmVmcmVzaFZldGVyYW5GcmFtZUFmdGVyQ29tbWFuZFNwYXduKGdhbWUpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwic2V0QXV0b2Nhc3RcIikge1xuICAgIGlmICghY2FuQXV0b2Nhc3QoY29tbWFuZC5hYmlsaXR5KSkgdGhyb3cgbmV3IEVycm9yKGAke2NvbW1hbmQuYWJpbGl0eX0gY2Fubm90IGJlIGF1dG9jYXN0YCk7XG4gICAgZm9yIChjb25zdCB1bml0IG9mIHVuaXRzQnlJZHMoZ2FtZSwgY29tbWFuZC51bml0SWRzLCBvd25lcikpIHtcbiAgICAgIGlmICghdW5pdEFiaWxpdGllcyh1bml0KS5pbmNsdWRlcyhjb21tYW5kLmFiaWxpdHkpKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGF1dG9jYXN0ID0gd2l0aEF1dG9jYXN0KHVuaXQsIGNvbW1hbmQuYWJpbGl0eSwgY29tbWFuZC5lbmFibGVkKTtcbiAgICAgIGlmIChhdXRvY2FzdCkgdW5pdC5hdXRvY2FzdCA9IGF1dG9jYXN0O1xuICAgICAgZWxzZSB1bml0LmF1dG9jYXN0ID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcInNldFN0YW5jZVwiKSB7XG4gICAgZm9yIChjb25zdCB1bml0IG9mIHVuaXRzQnlJZHMoZ2FtZSwgY29tbWFuZC51bml0SWRzLCBvd25lcikpIHtcbiAgICAgIGlmIChjYW5UYWtlU3RhbmNlKHVuaXQua2luZCkpIHVuaXQuc3RhbmNlID0gY29tbWFuZC5zdGFuY2UgPT09IFwicHVyc3VlXCIgPyB1bmRlZmluZWQgOiBjb21tYW5kLnN0YW5jZTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJoaXJlXCIpIHtcbiAgICBoaXJlTWVyY2VuYXJ5KGdhbWUsIG93bmVyLCBjb21tYW5kLmNhbXBJZCk7XG4gICAgcmVmcmVzaFZldGVyYW5GcmFtZUFmdGVyQ29tbWFuZFNwYXduKGdhbWUpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwiYnV5XCIpIHtcbiAgICBidXlHb29kKGdhbWUsIG93bmVyLCBjb21tYW5kLnNob3BJZCwgY29tbWFuZC5pdGVtLCBjb21tYW5kLnJlY2lwaWVudElkKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBUb2xkIHRvIGJvYXJkLCBzb2xkaWVycyB3YWxrIHRvIHRoZSB0cmFuc3BvcnQsIGFuZCBhbiBpZGxlIHRyYW5zcG9ydCBzYWlscyBpbiB0byBtZWV0IHRoZW0gKHNlZSBAQEB0cmFuc3BvcnQpLlxuICBpZiAoY29tbWFuZC50eXBlID09PSBcImJvYXJkXCIpIHtcbiAgICBjb25zdCB0cmFuc3BvcnQgPSBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IGNvbW1hbmQudHJhbnNwb3J0SWQgJiYgdW5pdC5ocD4wICYmIGNhcnJpZXModW5pdCkgPiAwKTtcbiAgICBpZiAoIXRyYW5zcG9ydCkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IHRyYW5zcG9ydCAke2NvbW1hbmQudHJhbnNwb3J0SWR9YCk7XG4gICAgY29uc3QgYm9hcmRlcnMgPSB1bml0c0J5SWRzKGdhbWUsIGNvbW1hbmQudW5pdElkcywgb3duZXIpLmZpbHRlcigodW5pdCkgPT4gY2FuQm9hcmQodHJhbnNwb3J0LHVuaXQsZ2FtZS51bml0cykpO1xuICAgIGNvbnN0IGV4aXN0aW5nID0gZ2FtZS51bml0cy5maW5kKHVuaXQgPT4gdW5pdC5vcmRlci50eXBlID09PSBcImJvYXJkXCIgJiYgdW5pdC5vcmRlci50cmFuc3BvcnRJZCA9PT0gdHJhbnNwb3J0LmlkKTtcbiAgICBjb25zdCBzaG9yZUJvYXJkZXI9Ym9hcmRlcnMuZmluZCh1bml0PT4hdW5pdC5kZWNrKTtcbiAgICBjb25zdCBiZXJ0aCA9IChleGlzdGluZz8ub3JkZXIudHlwZSA9PT0gXCJib2FyZFwiID8gZXhpc3Rpbmcub3JkZXIuYmVydGggOiB1bmRlZmluZWQpID8/IChzaG9yZUJvYXJkZXIgJiYgYm9hcmRpbmdCZXJ0aChnYW1lLm1hcCwgc2hvcmVCb2FyZGVyLCB0cmFuc3BvcnQpKTtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgYm9hcmRlcnMpIHtcbiAgICAgIGFzc2lnblVuaXRPcmRlcih1bml0LCB7IHR5cGU6IFwiYm9hcmRcIiwgdHJhbnNwb3J0SWQ6IHRyYW5zcG9ydC5pZCwgLi4uKCF1bml0LmRlY2sgJiYgYmVydGggPyB7IGJlcnRoIH0gOiB7fSkgfSwgY29tbWFuZC5xdWV1ZWQpO1xuICAgICAgY29uc3Qgc291cmNlPXVuaXQuZGVjayAmJiBnYW1lLnVuaXRzLmZpbmQoc2hpcD0+c2hpcC5pZD09PXVuaXQuZGVjayEuc2hpcElkICYmIHNoaXAub3duZXI9PT1vd25lcik7XG4gICAgICBpZihzb3VyY2UgJiYgIWNvbW1hbmQucXVldWVkICYmICFzb3VyY2Uuc2FpbGluZz8uZ2FuZ3dheSlhc3NpZ25Vbml0T3JkZXIoc291cmNlLHt0eXBlOlwiaWRsZVwifSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwidW5sb2FkUGFzc2VuZ2VyXCIpIHtcbiAgICBjb25zdCB0cmFuc3BvcnQgPSB1bml0c0J5SWRzKGdhbWUsIFtjb21tYW5kLnRyYW5zcG9ydElkXSwgb3duZXIpWzBdO1xuICAgIGlmICh0cmFuc3BvcnQpIHVubG9hZENhcmdvKGdhbWUsIHRyYW5zcG9ydCwgY29tbWFuZC5wYXNzZW5nZXJJZCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJ1bmxvYWRcIikge1xuICAgIGZvciAoY29uc3QgdW5pdCBvZiB1bml0c0J5SWRzKGdhbWUsIGNvbW1hbmQudW5pdElkcywgb3duZXIpKSB7XG4gICAgICBpZiAoY2Fycmllcyh1bml0KSA+IDApIGFzc2lnblVuaXRPcmRlcih1bml0LCB7IHR5cGU6IFwidW5sb2FkXCIsIHg6IGNvbW1hbmQueCwgeTogY29tbWFuZC55LCAuLi4oY29tbWFuZC5hdm9pZENvbWJhdCA/IHthdm9pZENvbWJhdDp0cnVlfSA6IHt9KSB9LCBjb21tYW5kLnF1ZXVlZCk7XG4gICAgfVxuICAgIGFkZEVmZmVjdChnYW1lLCBjb21tYW5kLnF1ZXVlZCA/IFwicXVldWVkTW92ZVwiIDogXCJtb3ZlXCIsIGNvbW1hbmQueCwgY29tbWFuZC55LCBjb21tYW5kLnF1ZXVlZCA/IDM4IDogMjQsIHsgb3duZXIgfSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJyZXNlYXJjaFwiKSB7XG4gICAgY29uc3QgYnVpbGRpbmcgPSBnYW1lLmJ1aWxkaW5ncy5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gY29tbWFuZC5idWlsZGluZ0lkICYmIGNhbmRpZGF0ZS5vd25lciA9PT0gb3duZXIpO1xuICAgIGlmICghYnVpbGRpbmcpIHRocm93IG5ldyBFcnJvcihgVW5rbm93biAke293bmVyfSBidWlsZGluZyAke2NvbW1hbmQuYnVpbGRpbmdJZH1gKTtcbiAgICBxdWV1ZVJlc2VhcmNoKGdhbWUsIGJ1aWxkaW5nLCBjb21tYW5kLnVwZ3JhZGVLaW5kKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZihjb21tYW5kLnR5cGU9PT1cImJ1eVNoaXBFcXVpcG1lbnRcIil7XG4gICAgY29uc3QgZG9jaz1nYW1lLmJ1aWxkaW5ncy5maW5kKGJ1aWxkaW5nPT5idWlsZGluZy5pZD09PWNvbW1hbmQuYnVpbGRpbmdJZCAmJiBidWlsZGluZy5vd25lcj09PW93bmVyICYmIGJ1aWxkaW5nLmtpbmQ9PT1cInNoaXB5YXJkXCIgJiYgYnVpbGRpbmcuY29tcGxldGUpO2lmKCFkb2NrKXRocm93IG5ldyBFcnJvcihcIkEgY29tcGxldGVkIHNoaXB5YXJkIGlzIHJlcXVpcmVkXCIpO1xuICAgIGNvbnN0IGRlbGl2ZXJ5PWNvbW1hbmQucmVjaXBpZW50SWQhPT11bmRlZmluZWQgPyBwdXJjaGFzZVBsYWNlbWVudChnYW1lLG93bmVyLGRvY2ssY29tbWFuZC5pdGVtLGNvbW1hbmQucmVjaXBpZW50SWQpIDogdW5kZWZpbmVkO1xuICAgIGlmKGRlbGl2ZXJ5ICYmIFwicmVmdXNhbFwiIGluIGRlbGl2ZXJ5KXRocm93IG5ldyBFcnJvcihkZWxpdmVyeS5yZWZ1c2FsKTtcbiAgICBjb25zdCBkZWY9U0hJUF9XRUFQT05TW2NvbW1hbmQuaXRlbV07c3BlbmRHb2xkKGdhbWUsb3duZXIsZGVmLmNvc3QpO2NvbnN0IGF0PXdhbGthYmxlR29hbChnYW1lLm1hcCxkb2NrLngsZG9jay55K2RvY2sucmFkaXVzKzM2LFwibGFuZFwiKTtcbiAgICBjb25zdCBpdGVtOldvcmxkSXRlbT17aWQ6YHNoaXAtaXRlbS0ke2dhbWUubmV4dElkKyt9YCxraW5kOmNvbW1hbmQuaXRlbSx4OmF0LngseTphdC55LGR1cmFiaWxpdHk6ZGVmLmhwLGNvb2xkb3duUmVtYWluaW5nOjB9O2dhbWUuaXRlbXMucHVzaChpdGVtKTtcbiAgICBpZihkZWxpdmVyeSAmJiBcInBsYWNlbWVudFwiIGluIGRlbGl2ZXJ5KWRlbGl2ZXJQdXJjaGFzZShnYW1lLGl0ZW0sZGVsaXZlcnkucGxhY2VtZW50KTtlbHNlIGFkZEVmZmVjdChnYW1lLFwic3VtbW9uXCIsYXQueCxhdC55LHNlY29uZHMoLjgpKTtyZXR1cm47XG4gIH1cbiAgaWYgKGNvbW1hbmQudHlwZSA9PT0gXCJ0cmFuc2Zlckl0ZW1cIikge1xuICAgIGNvbnN0IHJlZnVzYWw9dHJhbnNmZXJSZWZ1c2FsKGdhbWUsb3duZXIsY29tbWFuZC5pdGVtSWQsY29tbWFuZC5kZXN0aW5hdGlvbik7aWYocmVmdXNhbCl0aHJvdyBuZXcgRXJyb3IocmVmdXNhbCk7XG4gICAgY29uc3QgaXRlbT1nYW1lLml0ZW1zLmZpbmQoaXRlbT0+aXRlbS5pZD09PWNvbW1hbmQuaXRlbUlkKSE7Y29uc3Qgb3JpZ2luYWxTaGlwPWl0ZW0uc2hpcElkO2NvbnN0IHNvdXJjZT1nYW1lLnVuaXRzLmZpbmQodW5pdD0+dW5pdC5pZD09PWl0ZW0uY2FycmllcklkKTtpZihzb3VyY2UpcmVtb3ZlRnJvbUhhbmRzKHNvdXJjZSxpdGVtLmlkKTtcbiAgICBkZWxldGUgaXRlbS5jYXJyaWVySWQ7ZGVsZXRlIGl0ZW0uc2xvdDtkZWxldGUgaXRlbS5zaGlwSWQ7ZGVsZXRlIGl0ZW0uaG9sZFNsb3Q7ZGVsZXRlIGl0ZW0ubW91bnRJZDtkZWxldGUgaXRlbS5haW07XG4gICAgaWYoXCJ1bml0SWRcIiBpbiBjb21tYW5kLmRlc3RpbmF0aW9uKXtpdGVtLmNhcnJpZXJJZD1jb21tYW5kLmRlc3RpbmF0aW9uLnVuaXRJZDtpdGVtLnNsb3Q9Y29tbWFuZC5kZXN0aW5hdGlvbi5zbG90O31lbHNle2l0ZW0uc2hpcElkPWNvbW1hbmQuZGVzdGluYXRpb24uc2hpcElkO2lmKFwibW91bnRJZFwiIGluIGNvbW1hbmQuZGVzdGluYXRpb24pe2l0ZW0ubW91bnRJZD1jb21tYW5kLmRlc3RpbmF0aW9uLm1vdW50SWQ7aXRlbS5kdXJhYmlsaXR5Pz89U0hJUF9XRUFQT05TW2l0ZW0ua2luZCBhcyBrZXlvZiB0eXBlb2YgU0hJUF9XRUFQT05TXS5ocDt9ZWxzZSBpdGVtLmhvbGRTbG90PWNvbW1hbmQuZGVzdGluYXRpb24uc2xvdDt9XG4gICAgaW52YWxpZGF0ZUl0ZW1JbmRleChnYW1lLml0ZW1zKTtcbiAgICBmb3IoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKXtpZihzaGlwUHJvZmlsZSh1bml0KSAmJiAodW5pdC5pZD09PW9yaWdpbmFsU2hpcCB8fCB1bml0LmlkPT09aXRlbS5zaGlwSWQpKXJlYnVpbGRTaGlwRml0dGluZ3MoZ2FtZSx1bml0KTtpZih1bml0LmlkPT09c291cmNlPy5pZCB8fCB1bml0LmlkPT09aXRlbS5jYXJyaWVySWQgfHwgdW5pdC5pZD09PW9yaWdpbmFsU2hpcCB8fCB1bml0LmlkPT09aXRlbS5zaGlwSWQpYXBwbHlEZXJpdmVkVW5pdFN0YXRzKGdhbWUsdW5pdCk7fXJlZnJlc2hFcXVpcG1lbnRNYXNzKGdhbWUpO3JldHVybjtcbiAgfVxuICBpZihjb21tYW5kLnR5cGUgPT09IFwid2llbGRJdGVtXCIpe1xuICAgIGNvbnN0IHJlZnVzYWw9d2llbGRSZWZ1c2FsKGdhbWUsb3duZXIsY29tbWFuZC51bml0SWQsY29tbWFuZC5pdGVtSWQsY29tbWFuZC5oYW5kKTtpZihyZWZ1c2FsKXRocm93IG5ldyBFcnJvcihyZWZ1c2FsKTtcbiAgICBjb25zdCB1bml0PWdhbWUudW5pdHMuZmluZCh1bml0PT51bml0LmlkPT09Y29tbWFuZC51bml0SWQpITt1bml0LmhhbmRzPz89e307XG4gICAgaWYoY29tbWFuZC5pdGVtSWQpe3JlbW92ZUZyb21IYW5kcyh1bml0LGNvbW1hbmQuaXRlbUlkKTt1bml0LmhhbmRzW2NvbW1hbmQuaGFuZF09Y29tbWFuZC5pdGVtSWQ7Y29uc3QgaXRlbT1nYW1lLml0ZW1zLmZpbmQoaXRlbT0+aXRlbS5pZD09PWNvbW1hbmQuaXRlbUlkKSE7aWYoaXRlbUhhbmRzKGl0ZW0pPT09MilkZWxldGUgdW5pdC5oYW5kcy5sZWZ0O31lbHNlIGRlbGV0ZSB1bml0LmhhbmRzW2NvbW1hbmQuaGFuZF07XG4gICAgdW5pdC5haW09dW5kZWZpbmVkO3VuaXQuY29vbGRvd249TWF0aC5tYXgodW5pdC5jb29sZG93bixzZWNvbmRzKC4zNSkpO2FwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLHVuaXQpO3JldHVybjtcbiAgfVxuICBpZiAoY29tbWFuZC50eXBlID09PSBcInBpY2t1cEl0ZW1cIikge1xuICAgIHBpY2t1cEl0ZW0oZ2FtZSwgb3duZXIsIGNvbW1hbmQudW5pdElkLCBjb21tYW5kLml0ZW1JZCwgY29tbWFuZC5xdWV1ZWQpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChjb21tYW5kLnR5cGUgPT09IFwiZHJvcEl0ZW1cIikge1xuICAgIGRyb3BJdGVtKGdhbWUsIG93bmVyLCBjb21tYW5kLnVuaXRJZCwgY29tbWFuZC5pdGVtSWQsIGNvbW1hbmQueCwgY29tbWFuZC55KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoY29tbWFuZC50eXBlID09PSBcInVzZUl0ZW1cIikge1xuICAgIHVzZUl0ZW0oZ2FtZSwgb3duZXIsIGNvbW1hbmQudW5pdElkLCBjb21tYW5kLml0ZW1JZCwgY29tbWFuZC50YXJnZXRJZCwgY29tbWFuZC54LCBjb21tYW5kLnkpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGJ1aWxkaW5nID0gZ2FtZS5idWlsZGluZ3MuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IGNvbW1hbmQuYnVpbGRpbmdJZCAmJiBjYW5kaWRhdGUub3duZXIgPT09IG93bmVyKTtcbiAgaWYgKCFidWlsZGluZykgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IGJ1aWxkaW5nICR7Y29tbWFuZC5idWlsZGluZ0lkfWApO1xuICBxdWV1ZVRyYWluaW5nKGdhbWUsIGJ1aWxkaW5nLCBjb21tYW5kLnVuaXRLaW5kKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0ZXBHYW1lKGdhbWU6IEdhbWUpIHtcbiAgaWYgKGdhbWUubWF0Y2gud2lubmVyKSByZXR1cm47XG4gIGNvbnN0IGVudHJ5RmxhZ3MgPSBuYXZhbEZyYW1lRmxhZ3MoZ2FtZSk7XG4gIGNvbnN0IGVtcHR5VmV0ZXJhbkZyYW1lID0gISEoZW50cnlGbGFncyAmIEVNUFRZX1ZFVEVSQU5fRlJBTUUpO1xuICBsZXQgbmF2YWxGcmFtZSA9ICEhKGVudHJ5RmxhZ3MgJiBOQVZBTF9GUkFNRSk7XG4gIGlmIChuYXZhbEZyYW1lKSB7XG4gICAgYmluZEdhbmd3YXlDcmV3UnVsZXMoZ2FtZS51bml0cyxnYW1lKTtcbiAgICBpZiAoZW50cnlGbGFncyAmIENBUkdPX0ZSQU1FKSByZXN0b3JlQ2FyZ29EZWNrcyhnYW1lLnVuaXRzKTtcbiAgICBzeW5jRGVja3MoZ2FtZS51bml0cyk7XG4gICAgdXBkYXRlQ2FiaW5QYXNzZW5nZXJzKGdhbWUpO1xuICB9XG4gIGNvbnN0IGVudHJ5VW5pdHMgPSBnYW1lLnVuaXRzLCBlbnRyeUNvdW50ID0gZ2FtZS51bml0cy5sZW5ndGg7XG4gIGdhbWUudGljayArPSAxO1xuICB1cGRhdGVXaW5kRmllbGQoZ2FtZS5tYXAsIGdhbWUudGljayk7XG4gIC8vIEF1cmFzIGFuZCB0aGVpciBzcGF0aWFsIHF1ZXJ5IHN0YXJ0IGZyb20gdGhpcyB0aWNrJ3MgYWN0dWFsIHBvc2l0aW9ucywgaW5jbHVkaW5nIGFmdGVyIHJlc3RvcmUuXG4gIGdhbWUudW5pdFNwYXRpYWwgPSBjcmVhdGVTcGF0aWFsSW5kZXgoZ2FtZS51bml0cywgMzIwLCBnYW1lLnVuaXRTcGF0aWFsKTtcbiAgcmVmcmVzaFZldGVyYW5GcmFtZShnYW1lLCBlbXB0eVZldGVyYW5GcmFtZSk7XG4gIHN5bmNCdWlsZGluZ0JvZGllcyhnYW1lKTtcbiAgdXBkYXRlV29ybGRFZmZlY3RzKGdhbWUpO1xuICB1cGRhdGVQcm9qZWN0aWxlcyhnYW1lKTtcbiAgdXBkYXRlVW5pdFN0YXR1c0VmZmVjdHMoZ2FtZSk7XG4gIHVwZGF0ZUNvbnN0cnVjdGlvbihnYW1lKTtcbiAgdXBkYXRlVHJhaW5pbmcoZ2FtZSk7XG4gIHVwZGF0ZVJlc2VhcmNoKGdhbWUpO1xuICB1cGRhdGVSZXNvdXJjZXMoZ2FtZSk7XG4gIGdhbWUubWluaW5nRnJhbWUgPSBwcmVwYXJlTWluaW5nRnJhbWUoZ2FtZSk7XG4gIHVwZGF0ZU1lcmNlbmFyeUNhbXBzKGdhbWUpO1xuICBpZiAoZ2FtZS5zaG9wcykgcmVzdG9ja1Nob3BzKGdhbWUuc2hvcHMpO1xuICAvLyBUcmFpbmluZyBjYW4gbGF1bmNoIHRoZSBmaXJzdCBodWxsIGludG8gdGhlIHNhbWUgYXJyYXkgb24gYW4gZW1wdHkgdGljay5cbiAgLy8gQSBuYXRpdmUgZmFjdG9yeSBvbmx5IGFwcGVuZHM7IG9ic2VydmVycy9jdXN0b20gZmFjdG9yaWVzIG5ldmVyIHRha2UgdGhpcyBwYXRoLlxuICBjb25zdCB1bml0c0NoYW5nZWQgPSBnYW1lLnVuaXRzICE9PSBlbnRyeVVuaXRzIHx8IGdhbWUudW5pdHMubGVuZ3RoICE9PSBlbnRyeUNvdW50O1xuICBpZiAoIW5hdmFsRnJhbWUgJiYgdW5pdHNDaGFuZ2VkKSBuYXZhbEZyYW1lID0gISEobmF2YWxGcmFtZUZsYWdzKGdhbWUpICYgTkFWQUxfRlJBTUUpO1xuICAvLyBOYXRpdmUgZ3JvdW5kZWQgcHJlbHVkZSB3b3JrIGNoYW5nZXMgaGVhbHRoLCBvcmRlcnMgYW5kIHB1c2ggdmVsb2NpdGllcyxcbiAgLy8gYnV0IG5vIGV4aXN0aW5nIGNvb3JkaW5hdGVzLiBUaGUgZW50cnkgaW5kZXggcmVtYWlucyBjdXJyZW50IHVudGlsIGJpcnRoLlxuICBpZiAobmF2YWxGcmFtZSB8fCB1bml0c0NoYW5nZWQpIGdhbWUudW5pdFNwYXRpYWwgPSBjcmVhdGVTcGF0aWFsSW5kZXgoZ2FtZS51bml0cywgMzIwLCBnYW1lLnVuaXRTcGF0aWFsKTtcbiAgZ2FtZS51bml0U3BhdGlhbEJ5VGVhbSA9IGNyZWF0ZVRlYW1TcGF0aWFsSW5kZXhlcyhnYW1lLCBnYW1lLnVuaXRzLCAyMzAsIGdhbWUudW5pdFNwYXRpYWxCeVRlYW0pO1xuICBnYW1lLnNoaXBSZWFjaFBhZGRpbmcgPSBuYXZhbEZyYW1lID8gc2hpcFJlYWNoUGFkZGluZyhnYW1lLnVuaXRzKSA6IDA7XG4gIGlmICghZ2FtZS5idWlsZGluZ1NwYXRpYWwgfHwgZ2FtZS5idWlsZGluZ1NwYXRpYWxDb3VudCAhPT0gZ2FtZS5idWlsZGluZ3MubGVuZ3RoKSB7XG4gICAgZ2FtZS5idWlsZGluZ1NwYXRpYWwgPSBjcmVhdGVTcGF0aWFsSW5kZXgoZ2FtZS5idWlsZGluZ3MsIDQyMCk7XG4gICAgZ2FtZS5idWlsZGluZ1NwYXRpYWxCeVRlYW0gPSBjcmVhdGVUZWFtU3BhdGlhbEluZGV4ZXMoZ2FtZSwgZ2FtZS5idWlsZGluZ3MsIDI2MCk7XG4gICAgZ2FtZS5idWlsZGluZ1NwYXRpYWxDb3VudCA9IGdhbWUuYnVpbGRpbmdzLmxlbmd0aDtcbiAgfVxuICBnYW1lLmVudGl0eUJ5SWQgPSBjcmVhdGVFbnRpdHlJbmRleChnYW1lKTtcbiAgdXBkYXRlSXRlbXMoZ2FtZSk7XG4gIHVwZGF0ZU1vb25XZWxsSGVhbGluZyhnYW1lKTtcbiAgdXBkYXRlUmVnZW5lcmF0aW9uKGdhbWUpO1xuICBpZiAobmF2YWxGcmFtZSkgdXBkYXRlRG9ja1JlcGFpcnMoZ2FtZSk7XG4gIHVwZGF0ZVRvd2VyQXR0YWNrcyhnYW1lKTtcbiAgY29uc3QgdmVzc2VscyA9IHNoaXBzSW4oZ2FtZS51bml0cyk7XG4gIGNvbnN0IHN0YXJ0cyA9IHZlc3NlbHMubGVuZ3RoID8gbmV3IE1hcCh2ZXNzZWxzLm1hcChzaGlwID0+IFtzaGlwLmlkLCB7IHg6IHNoaXAueCwgeTogc2hpcC55LCBoZWFkaW5nOiBzaGlwLnNhaWxpbmchLmhlYWRpbmcgfV0pKSA6IEVNUFRZX1NISVBfU1RBUlRTO1xuICAvLyBUaGUgZW1wdHkgY29sbGlzaW9uIGZyYW1lIHN0aWxsIGNsZWFycyBwcmlvciBodWxsIGltcGFjdHMgYW5kIGJpbmRzIGdyb3VuZFxuICAvLyBtb3ZlbWVudCB0byB0aGlzIHRpY2sncyBuby1odWxsIGdlb21ldHJ5LlxuICBiZWdpblNoaXBNb3Rpb25GcmFtZShnYW1lLnVuaXRzLGdhbWUubWFwLGdhbWUuYnVpbGRpbmdCb2RpZXNTZWVuID8/IGdhbWUuYnVpbGRpbmdzLHZlc3NlbHMpO1xuICBsZXQgZGVmZW5zZXM6IFNoaXBEZWZlbnNlRnJhbWU7XG4gIGlmIChuYXZhbEZyYW1lKSB7XG4gICAgYmVnaW5TaGlwUGxhbm5pbmdGcmFtZShnYW1lLnVuaXRzLGdhbWUudGljayx2ZXNzZWxzKTtcbiAgICB1cGRhdGVTaGlwR2FuZ3dheXMoZ2FtZS5tYXAsZ2FtZS51bml0cyxnYW1lLnRpY2ssZ2FtZSk7XG4gICAgcHJlcGFyZUNyZXdSZW5kZXp2b3VzKGdhbWUubWFwLGdhbWUudW5pdHMpO1xuICAgIGdhbWUuYm9hcmRpbmdIb2xkcz1ib2FyZGluZ0hvbGRTaGlwcyhnYW1lLnVuaXRzKTtcbiAgICBkZWZlbnNlcz1wcmVwYXJlU2hpcERlZmVuc2VGcmFtZShnYW1lLChzaGlwLHJhbmdlLHZpc2l0KT0+Zm9yRWFjaE5lYXJieUVuZW15VW5pdChnYW1lLHNoaXAub3duZXIsc2hpcCxyYW5nZSx2aXNpdCksZ2FtZS5ib2FyZGluZ0hvbGRzKTtcbiAgICBjb25zdCBzaG9yZUJvYXJkZXJzID0gbmV3IE1hcDxzdHJpbmcsIFVuaXRbXT4oKTtcbiAgICBmb3IgKGNvbnN0IHVuaXQgb2YgZ2FtZS51bml0cykgaWYgKHVuaXQuaHAgPiAwICYmICF1bml0LmRlY2sgJiYgdW5pdC5vcmRlci50eXBlID09PSAnYm9hcmQnKSB7XG4gICAgICBjb25zdCB3YWl0aW5nID0gc2hvcmVCb2FyZGVycy5nZXQodW5pdC5vcmRlci50cmFuc3BvcnRJZCk7XG4gICAgICBpZiAod2FpdGluZykgd2FpdGluZy5wdXNoKHVuaXQpOyBlbHNlIHNob3JlQm9hcmRlcnMuc2V0KHVuaXQub3JkZXIudHJhbnNwb3J0SWQsIFt1bml0XSk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qgc2hpcCBvZiBzaGlwc0luKGdhbWUudW5pdHMpKSB7XG4gICAgICAvLyBTaG9yZSBib2FyZGluZyBnaXZlcyBhbiBpZGxlIGJvYXQgYSBmZXJyeSB2b3lhZ2Ugd2l0aG91dCByZXBsYWNpbmcgaXRzXG4gICAgICAvLyBvcmRlci4gSXRzIHNhaWxzIG11c3Qgc3RheSBhdmFpbGFibGUgd2hpbGUgaXQgYXBwcm9hY2hlcyB0aGUgcGFzc2VuZ2VyLlxuICAgICAgY29uc3QgY29sbGVjdGluZyA9IHNoaXAub3JkZXIudHlwZSA9PT0gJ2lkbGUnICYmIHNob3JlQm9hcmRlcnMuZ2V0KHNoaXAuaWQpPy5zb21lKHVuaXQgPT4gdW5pdC5vd25lciA9PT0gc2hpcC5vd25lciAmJiAhYWxvbmdzaWRlKHVuaXQsIHNoaXApKTtcbiAgICAgIGNvbnN0IGlkbGUgPSBnYW1lLmJvYXJkaW5nSG9sZHMuaGFzKHNoaXAuaWQpIHx8IHNoaXAub3JkZXIudHlwZSA9PT0gJ2hvbGQnIHx8IHNoaXAub3JkZXIudHlwZSA9PT0gJ2lkbGUnICYmICFjb2xsZWN0aW5nICYmICFkZWZlbnNlcy5oYXMoc2hpcC5pZClcbiAgICAgICAgfHwgISFzaGlwLnNhaWxpbmc/Lmdhbmd3YXkgJiYgc2hpcC5zYWlsaW5nLmdhbmd3YXkucGhhc2UhPT0nYXBwcm9hY2gnO1xuICAgICAgdXBkYXRlQXV0b1RyaW0oc2hpcCwgZ2FtZS5tYXAsIGlkbGUgPyAnaWRsZScgOiBzaGlwLnNhaWxpbmc/LnNhaWw/Lm1vZGUgPT09ICdpZGxlJyA/ICdzYWlsJyA6IHVuZGVmaW5lZCk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmICghZ2FtZS5ib2FyZGluZ0hvbGRzIHx8IGdhbWUuYm9hcmRpbmdIb2xkcy5zaXplKSBnYW1lLmJvYXJkaW5nSG9sZHMgPSBuZXcgU2V0KCk7XG4gICAgZGVmZW5zZXMgPSBFTVBUWV9TSElQX0RFRkVOU0VTO1xuICB9XG4gIGNvbnN0IHVwZGF0ZVVuaXRzU291cmNlID0gZ2FtZS51bml0cywgdXBkYXRlVW5pdHNDb3VudCA9IGdhbWUudW5pdHMubGVuZ3RoO1xuICBjb25zdCBmZXJyeSA9IHVwZGF0ZVVuaXRzKGdhbWUsZGVmZW5zZXMsbmF2YWxGcmFtZSxlbXB0eVZldGVyYW5GcmFtZSk7XG4gIC8vIFN1bW1vbnMgYWN0IG5leHQgdGljaywgYnV0IHRoZWlyIGJvZGllcyBwYXJ0aWNpcGF0ZSBpbiB0aGlzIHRpY2sncyB0YWlsLlxuICAvLyBBIHF1ZXVlZCBib2FyZGluZy91bmxvYWQgb3JkZXIgY2FuIGFsc28gYWN0aXZhdGUgZHVyaW5nIHRoZSB1bml0IHBhc3MuXG4gIGlmICghbmF2YWxGcmFtZSAmJiAoZmVycnkgfHwgKGdhbWUudW5pdHMgIT09IHVwZGF0ZVVuaXRzU291cmNlIHx8IGdhbWUudW5pdHMubGVuZ3RoICE9PSB1cGRhdGVVbml0c0NvdW50KSAmJiAobmF2YWxGcmFtZUZsYWdzKGdhbWUpICYgTkFWQUxfRlJBTUUpKSkgbmF2YWxGcmFtZSA9IHRydWU7XG4gIGlmIChuYXZhbEZyYW1lKSB1cGRhdGVNb3VudGVkV2VhcG9ucyhnYW1lLHN0YXJ0cyxkZWZlbnNlcyk7XG4gIGlmIChmZXJyeSkgZmVycnlVbml0cyhnYW1lLCBmZXJyeSwgc3RhcnRzKTtcbiAgaWYgKG5hdmFsRnJhbWUpIHtcbiAgICBmb3IgKGNvbnN0IHNoaXAgb2Ygc2hpcHNJbihnYW1lLnVuaXRzKSkgeyBjb25zdCBzdGFydCA9IHN0YXJ0cy5nZXQoc2hpcC5pZCk7IGlmIChzdGFydCAmJiBzaGlwLnNhaWxpbmcgJiYgc3RhcnQueCA9PT0gc2hpcC54ICYmIHN0YXJ0LnkgPT09IHNoaXAueSkgc2hpcC5zYWlsaW5nLnNwZWVkID0gMDsgfVxuICAgIHVwZGF0ZVNoaXBHYW5nd2F5cyhnYW1lLm1hcCxnYW1lLnVuaXRzLGdhbWUudGljayxnYW1lKTtcbiAgICBzZXR0bGVHYW5nd2F5Q3Jvc3NpbmdzKGdhbWUudW5pdHMpO1xuICAgIHN5bmNEZWNrcyhnYW1lLnVuaXRzKTtcbiAgICBzZXR0bGVEZWNrU3VwcG9ydChnYW1lLnVuaXRzLGdhbWUubWFwKTtcbiAgICB1cGRhdGVDYWJpblBhc3NlbmdlcnMoZ2FtZSk7XG4gIH1cbiAgc2xpZGVVbml0cyhnYW1lKTtcbiAgc2VwYXJhdGVVbml0cyhnYW1lLCBuYXZhbEZyYW1lKTtcbiAgaWYgKG5hdmFsRnJhbWUpIHN5bmNEZWNrcyhnYW1lLnVuaXRzKTtcbiAgaWYgKGdhbWUubWFwLnRlcnJhaW4pIGtlZXBVbml0c091dE9mQnVpbGRpbmdzKGdhbWUpO1xuICBmb3IoY29uc3QgaW1wYWN0IG9mIGRyYWluU2hpcENvbGxpc2lvbkltcGFjdHMoZ2FtZS51bml0cykpIHtcbiAgICBjb25zdCBvdGhlcj1pbXBhY3Qub3RoZXI7XG4gICAgY29uc3Qgc291cmNlPW90aGVyICYmICFpc09ic3RhY2xlKG90aGVyKSA/IG90aGVyIDogaW1wYWN0LnNoaXA7XG4gICAgaWYoaW1wYWN0LnNoaXAuaHA+MCAmJiBpbXBhY3Quc2hpcERhbWFnZT4wKXtcbiAgICAgIGNvbnN0IHRha2VuPWFwcGx5RGFtYWdlKGdhbWUsc291cmNlLGltcGFjdC5zaGlwLGltcGFjdC5zaGlwRGFtYWdlLDAsaW1wYWN0LnBvaW50LDAsREFNQUdFX1BST0ZJTEVTLkVYUExPU0lPTik7XG4gICAgICBpZih0YWtlbiE9PXVuZGVmaW5lZCAmJiB0YWtlbj4wKWFkZEhpdEVmZmVjdChnYW1lLGltcGFjdC5zaGlwLHRha2VuKTtcbiAgICB9XG4gICAgaWYob3RoZXIgJiYgb3RoZXIuaHA+MCAmJiBpbXBhY3Qub3RoZXJEYW1hZ2U+MCl7XG4gICAgICBjb25zdCB0YWtlbj1hcHBseURhbWFnZShnYW1lLGltcGFjdC5zaGlwLG90aGVyLGltcGFjdC5vdGhlckRhbWFnZSwwLGltcGFjdC5wb2ludCwwLERBTUFHRV9QUk9GSUxFUy5FWFBMT1NJT04pO1xuICAgICAgaWYodGFrZW4hPT11bmRlZmluZWQgJiYgdGFrZW4+MClhZGRIaXRFZmZlY3QoZ2FtZSxvdGhlcix0YWtlbik7XG4gICAgfVxuICB9XG4gIGlmIChuYXZhbEZyYW1lKSBmb3IgKGNvbnN0IHNoaXAgb2Ygc2hpcHNJbihnYW1lLnVuaXRzKSkge1xuICAgIGNvbnN0IHN0YXJ0ID0gc3RhcnRzLmdldChzaGlwLmlkKTtcbiAgICBpZiAoIXNoaXAuc2FpbGluZykgY29udGludWU7XG4gICAgc2hpcC5zYWlsaW5nLnZlbG9jaXR5WCA9IHN0YXJ0ID8gKHNoaXAueCAtIHN0YXJ0LngpICogU0lNX1RJQ0tTX1BFUl9TRUNPTkQgOiAwO1xuICAgIHNoaXAuc2FpbGluZy52ZWxvY2l0eVkgPSBzdGFydCA/IChzaGlwLnkgLSBzdGFydC55KSAqIFNJTV9USUNLU19QRVJfU0VDT05EIDogMDtcbiAgfVxuICBmb3IgKGNvbnN0IHVuaXQgb2YgZ2FtZS51bml0cykgaWYodW5pdC5haW0paW52YWxpZGF0ZU1vdmVkQWltKHVuaXQsIHdlYXBvblJ1bGVzKGdhbWUsIHVuaXQpKTtcbiAgcmVtb3ZlRXhwaXJlZFVuaXRzKGdhbWUpO1xuICByZW1vdmVEZWFkKGdhbWUpO1xuICBpZihzZXR0bGVHcm91bmRJdGVtcyhnYW1lLml0ZW1zLGdhbWUudW5pdHMsZ2FtZS5tYXApKXJlZnJlc2hFcXVpcG1lbnRNYXNzKGdhbWUpO1xuICBpZiAobmF2YWxGcmFtZSkgdXBkYXRlU2hpcE93bmVyc2hpcChnYW1lKTtcbiAgc3luY0J1aWxkaW5nQm9kaWVzKGdhbWUpO1xuICAvLyBTbmFwc2hvdHMgYW5kIHJlc3RvcmVkIGdhbWVzIG9ic2VydmUgdGhlIHNhbWUgYXVyYSBib3VuZGFyeSBhZnRlciBtb3ZlbWVudCwgZGVhdGhzIGFuZCBjYXB0dXJlcy5cbiAgZ2FtZS51bml0U3BhdGlhbCA9IGNyZWF0ZVNwYXRpYWxJbmRleChnYW1lLnVuaXRzLCAzMjAsIGdhbWUudW5pdFNwYXRpYWwpO1xuICByZWZyZXNoVmV0ZXJhbkZyYW1lKGdhbWUsIGVtcHR5VmV0ZXJhbkZyYW1lKTtcbiAgdXBkYXRlVmljdG9yeShnYW1lKTtcbn1cblxuLy8gSGFuZHMgdGhlIG1hcCdzIHJvdXRpbmcgdGhlIGJ1aWxkaW5ncyBzdGFuZGluZyBub3csIGFuZCB0aGUgcm9ja3MgYW5kIGdhdGVzIChzZWUgQEBAb2JzdGFjbGUpLCB3aGVuZXZlciBvbmUgd2FzIGxhaWRcbi8vIGRvd24gb3IgZmVsbCAoc2VlIEBAQGJ1aWxkaW5nLXBhdGhpbmcpOiBhdCB0aGUgc3RlcCdzIHN0YXJ0LCBmb3IgdGhlIHNpdGVzIGxhaWQgYnkgdGhlIGNvbW1hbmRzIGJlZm9yZSBpdCwgYW5kIGFmdGVyIHRoZVxuLy8gZGVhZCBhcmUgZ29uZSwgc28gd2hhdCBhIHBsYW5uZXIgcmVhZHMgYmV0d2VlbiBzdGVwcyBpcyBjdXJyZW50LlxuZnVuY3Rpb24gc3luY0J1aWxkaW5nQm9kaWVzKGdhbWU6IEdhbWUpIHtcbiAgY29uc3Qgc2VlbiA9IGdhbWUuYnVpbGRpbmdCb2RpZXNTZWVuO1xuICBjb25zdCBvYnN0YWNsZXMgPSBnYW1lLm9ic3RhY2xlcyA/PyBbXTtcbiAgY29uc3QgY291bnQgPSBnYW1lLmJ1aWxkaW5ncy5sZW5ndGg7XG4gIGlmIChzZWVuICYmIHNlZW4ubGVuZ3RoID09PSBjb3VudCArIG9ic3RhY2xlcy5sZW5ndGggJiYgZ2FtZS5idWlsZGluZ3MuZXZlcnkoKGJ1aWxkaW5nLCBpbmRleCkgPT4gYnVpbGRpbmcgPT09IHNlZW5baW5kZXhdKSAmJiBvYnN0YWNsZXMuZXZlcnkoKG9ic3RhY2xlLCBpbmRleCkgPT4gb2JzdGFjbGUgPT09IHNlZW5bY291bnQgKyBpbmRleF0pKSByZXR1cm47XG4gIGdhbWUuYnVpbGRpbmdCb2RpZXNTZWVuID0gWy4uLmdhbWUuYnVpbGRpbmdzLCAuLi5vYnN0YWNsZXNdO1xuICBzZXRCdWlsZGluZ0JvZGllcyhnYW1lLm1hcCwgZ2FtZS5idWlsZGluZ0JvZGllc1NlZW4pO1xufVxuXG5mdW5jdGlvbiBjb3B5VW5pdE9yZGVyKG9yZGVyOlVuaXRPcmRlcik6VW5pdE9yZGVyIHtcbiAgY29uc3QgY29weT17Li4ub3JkZXJ9O1xuICBpZigoY29weS50eXBlPT09J21vdmUnfHxjb3B5LnR5cGU9PT0nYXR0YWNrTW92ZScpICYmIGNvcHkuZGVja1BvaW50KWNvcHkuZGVja1BvaW50PXsuLi5jb3B5LmRlY2tQb2ludH07XG4gIGlmKGNvcHkudHlwZT09PSdib2FyZCcpe1xuICAgIGlmKGNvcHkuZGVja1BvaW50KWNvcHkuZGVja1BvaW50PXsuLi5jb3B5LmRlY2tQb2ludH07XG4gICAgaWYoY29weS5yZW5kZXp2b3VzKWNvcHkucmVuZGV6dm91cz17Li4uY29weS5yZW5kZXp2b3VzfTtcbiAgICBpZihjb3B5LmJlcnRoKWNvcHkuYmVydGg9ey4uLmNvcHkuYmVydGh9O1xuICB9XG4gIHJldHVybiBjb3B5O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNuYXBzaG90R2FtZShnYW1lOiBHYW1lKTogR2FtZVNuYXBzaG90IHtcbiAgY29uc3Qgc25hcHNob3Q6R2FtZVNuYXBzaG90ID0ge1xuICAgIGVxdWlwbWVudFZlcnNpb246IDEsXG4gICAgcmF0ZVVuaXRzOiBcInBlclNlY29uZFwiLFxuICAgIHRpY2s6IGdhbWUudGljayxcbiAgICBtYXRjaDoge1xuICAgICAgd2lubmVyOiBnYW1lLm1hdGNoLndpbm5lcixcbiAgICAgIGVuZGVkQXRUaWNrOiBnYW1lLm1hdGNoLmVuZGVkQXRUaWNrLFxuICAgICAgc3RhdHM6IHtcbiAgICAgICAgdW5pdHNLaWxsZWQ6IHsgLi4uZ2FtZS5tYXRjaC5zdGF0cy51bml0c0tpbGxlZCB9LFxuICAgICAgICB1bml0c0xvc3Q6IHsgLi4uZ2FtZS5tYXRjaC5zdGF0cy51bml0c0xvc3QgfSxcbiAgICAgICAgYnVpbGRpbmdzRGVzdHJveWVkOiB7IC4uLmdhbWUubWF0Y2guc3RhdHMuYnVpbGRpbmdzRGVzdHJveWVkIH0sXG4gICAgICAgIG5vbkJhc2VCdWlsZGluZ3NEZXN0cm95ZWQ6IHsgLi4uZ2FtZS5tYXRjaC5zdGF0cy5ub25CYXNlQnVpbGRpbmdzRGVzdHJveWVkIH0sXG4gICAgICAgIGdvbGRTcGVudDogeyAuLi5nYW1lLm1hdGNoLnN0YXRzLmdvbGRTcGVudCB9LFxuICAgICAgICBtZXJjZW5hcnlLaWxsczogeyAuLi5nYW1lLm1hdGNoLnN0YXRzLm1lcmNlbmFyeUtpbGxzIH0sXG4gICAgICAgIG5ldXRyYWxVbml0c0tpbGxlZDogeyAuLi5nYW1lLm1hdGNoLnN0YXRzLm5ldXRyYWxVbml0c0tpbGxlZCB9LFxuICAgICAgICB1bml0c0tpbGxlZEJ5TmV1dHJhbDogeyAuLi5nYW1lLm1hdGNoLnN0YXRzLnVuaXRzS2lsbGVkQnlOZXV0cmFsIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgbWFwOiB7IC4uLmdhbWUubWFwLCAuLi4oZ2FtZS5tYXAud2luZCA/IHsgd2luZDogeyAuLi5nYW1lLm1hcC53aW5kIH0gfSA6IHt9KSB9LFxuICAgIHRlYW1zOiB7IC4uLmdhbWUudGVhbXMgfSxcbiAgICBwbGF5ZXJzOiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoZ2FtZS5wbGF5ZXJzKS5tYXAoKFtvd25lciwgcGxheWVyXSkgPT4gW293bmVyLCB7IC4uLnBsYXllciwgdXBncmFkZXM6IHsgLi4ucGxheWVyLnVwZ3JhZGVzIH0gfV0pKSBhcyBQbGF5ZXJTdGF0ZU1hcCxcbiAgICB1bml0czogZ2FtZS51bml0cy5tYXAoKHVuaXQpID0+IHtcbiAgICAgIC8vIE1vc3QgdW5pdHMgaGF2ZSBubyBkZWNrIG9yIGd1biBzdGF0ZS4gQ29weSBvbmx5IHRoZSBuZXN0ZWQgc3RhdGUgcHJlc2VudCxcbiAgICAgIC8vIHJhdGhlciB0aGFuIGFsbG9jYXRpbmcgZW1wdHkgaW50ZXJtZWRpYXRlIG9iamVjdHMgZm9yIGV2ZXJ5IG9wdGlvbmFsIGZpZWxkLlxuICAgICAgY29uc3QgY29weSA9IHsgLi4udW5pdCB9O1xuICAgICAgY29weS5vcmRlciA9IGNvcHlVbml0T3JkZXIodW5pdC5vcmRlcik7XG4gICAgICBjb3B5Lm9yZGVyUXVldWUgPSB1bml0Lm9yZGVyUXVldWU/Lm1hcChjb3B5VW5pdE9yZGVyKSA/PyBbXTtcbiAgICAgIGlmICh1bml0LmFpbSkgY29weS5haW0gPSB7IC4uLnVuaXQuYWltIH07XG4gICAgICBpZiAodW5pdC5kZWNrKSBjb3B5LmRlY2sgPSB7IC4uLnVuaXQuZGVjayB9O1xuICAgICAgaWYgKHVuaXQuY2FiaW4pIGNvcHkuY2FiaW4gPSB7IC4uLnVuaXQuY2FiaW4gfTtcbiAgICAgIGlmICh1bml0LmhhbmRzKSBjb3B5LmhhbmRzID0geyAuLi51bml0LmhhbmRzIH07XG4gICAgICBpZiAodW5pdC5zaGlwUGFydHMpIGNvcHkuc2hpcFBhcnRzID0geyAuLi51bml0LnNoaXBQYXJ0cyB9O1xuICAgICAgaWYgKHVuaXQuZml0dGluZ3MpIGNvcHkuZml0dGluZ3MgPSB1bml0LmZpdHRpbmdzLm1hcChmaXR0aW5nID0+ICh7IC4uLmZpdHRpbmcsIGFjY2VwdHM6IFsuLi5maXR0aW5nLmFjY2VwdHNdIH0pKTtcbiAgICAgIGlmICh1bml0LnNhaWxpbmcpIHtcbiAgICAgICAgY29weS5zYWlsaW5nID0geyAuLi51bml0LnNhaWxpbmcgfTtcbiAgICAgICAgaWYgKHVuaXQuc2FpbGluZy5zYWlsKSBjb3B5LnNhaWxpbmcuc2FpbCA9IHsgLi4udW5pdC5zYWlsaW5nLnNhaWwgfTtcbiAgICAgICAgaWYgKHVuaXQuc2FpbGluZy5wdXJzdWl0KSBjb3B5LnNhaWxpbmcucHVyc3VpdCA9IHsgLi4udW5pdC5zYWlsaW5nLnB1cnN1aXQgfTtcbiAgICAgICAgaWYgKHVuaXQuc2FpbGluZy5kZWZlbnNlKSBjb3B5LnNhaWxpbmcuZGVmZW5zZSA9IHsgLi4udW5pdC5zYWlsaW5nLmRlZmVuc2UgfTtcbiAgICAgICAgaWYodW5pdC5zYWlsaW5nLmdhbmd3YXkpY29weS5zYWlsaW5nLmdhbmd3YXk9ey4uLnVuaXQuc2FpbGluZy5nYW5nd2F5LHNvdXJjZUFuY2hvcjp7Li4udW5pdC5zYWlsaW5nLmdhbmd3YXkuc291cmNlQW5jaG9yfSx0YXJnZXRBbmNob3I6ey4uLnVuaXQuc2FpbGluZy5nYW5nd2F5LnRhcmdldEFuY2hvcn19O1xuICAgICAgICBpZiAodW5pdC5zYWlsaW5nLnJvdXRlKSBjb3B5LnNhaWxpbmcucm91dGUgPSB7IC4uLnVuaXQuc2FpbGluZy5yb3V0ZSwgZW5kOiB7IC4uLnVuaXQuc2FpbGluZy5yb3V0ZS5lbmQgfSwgcG9pbnRzOiB1bml0LnNhaWxpbmcucm91dGUucG9pbnRzLm1hcChwb2ludCA9PiAoeyAuLi5wb2ludCwuLi4ocG9pbnQucGl2b3Q/e3Bpdm90OnsuLi5wb2ludC5waXZvdH19Ont9KSB9KSkgfTtcbiAgICAgIH1cbiAgICAgIGlmKHVuaXQuZ2FuZ3dheSljb3B5Lmdhbmd3YXk9ey4uLnVuaXQuZ2FuZ3dheX07XG4gICAgICBpZiAodW5pdC5hYmlsaXR5Q29vbGRvd25zKSBjb3B5LmFiaWxpdHlDb29sZG93bnMgPSB7IC4uLnVuaXQuYWJpbGl0eUNvb2xkb3ducyB9O1xuICAgICAgaWYgKHVuaXQuYXV0b2Nhc3QpIGNvcHkuYXV0b2Nhc3QgPSB7IC4uLnVuaXQuYXV0b2Nhc3QgfTtcbiAgICAgIGlmICh1bml0LnZldGVyYW5Ta2lsbENob2ljZXMpIGNvcHkudmV0ZXJhblNraWxsQ2hvaWNlcyA9IFsuLi51bml0LnZldGVyYW5Ta2lsbENob2ljZXNdO1xuICAgICAgY29weS5lZmZlY3RzID0gdW5pdC5lZmZlY3RzLm1hcChlZmZlY3QgPT4gKHsgLi4uZWZmZWN0LCAuLi4oZWZmZWN0LmRhbWFnZUZpbHRlciA/IHtcbiAgICAgICAgZGFtYWdlRmlsdGVyOiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoZWZmZWN0LmRhbWFnZUZpbHRlcikubWFwKChba2V5LCB2YWx1ZV0pID0+IFtrZXksIEFycmF5LmlzQXJyYXkodmFsdWUpID8gWy4uLnZhbHVlXSA6IHZhbHVlXSkpLFxuICAgICAgfSA6IHt9KSB9KSk7XG4gICAgICByZXR1cm4gY29weTtcbiAgICB9KSxcbiAgICBidWlsZGluZ3M6IGdhbWUuYnVpbGRpbmdzLm1hcCgoYnVpbGRpbmcpID0+IHtcbiAgICAgIGNvbnN0IHsgcmFsbHlUYXJnZXQsIC4uLnJlc3QgfSA9IGJ1aWxkaW5nO1xuICAgICAgY29uc3QgY29weTogQnVpbGRpbmcgPSByZXN0O1xuICAgICAgaWYgKHJhbGx5VGFyZ2V0KSBjb3B5LnJhbGx5VGFyZ2V0ID0geyAuLi5yYWxseVRhcmdldCB9O1xuICAgICAgY29weS5xdWV1ZSA9IGJ1aWxkaW5nLnF1ZXVlLm1hcCgoam9iKSA9PiAoeyAuLi5qb2IgfSkpO1xuICAgICAgY29weS5yZXNlYXJjaFF1ZXVlID0gYnVpbGRpbmcucmVzZWFyY2hRdWV1ZS5tYXAoKGpvYikgPT4gKHsgLi4uam9iIH0pKTtcbiAgICAgIHJldHVybiBjb3B5O1xuICAgIH0pLFxuICAgIHJlc291cmNlczogZ2FtZS5yZXNvdXJjZXMubWFwKChyZXNvdXJjZSkgPT4gKHsgLi4ucmVzb3VyY2UgfSkpLFxuICAgIG1lcmNlbmFyeUNhbXBzOiBnYW1lLm1lcmNlbmFyeUNhbXBzLm1hcCgoY2FtcCkgPT4gKHsgLi4uY2FtcCB9KSksXG4gICAgLi4uKGdhbWUuc2hvcHMgPyB7IHNob3BzOiBnYW1lLnNob3BzLm1hcCgoc2hvcCkgPT4gKHsgLi4uc2hvcCwgZ29vZHM6IHNob3AuZ29vZHMubWFwKChnb29kKSA9PiAoeyAuLi5nb29kIH0pKSB9KSkgfSA6IHt9KSxcbiAgICBpdGVtczogZ2FtZS5pdGVtcy5tYXAoaXRlbSA9PiAoey4uLml0ZW0sLi4uKGl0ZW0uYWltP3thaW06ey4uLml0ZW0uYWltfX06e30pLC4uLihpdGVtLmRlY2s/e2RlY2s6ey4uLml0ZW0uZGVja319Ont9KX0pKSxcbiAgICBwcm9qZWN0aWxlczogZ2FtZS5wcm9qZWN0aWxlcy5tYXAocHJvamVjdGlsZSA9PiAoeyAuLi5wcm9qZWN0aWxlLFxuICAgICAgLi4uKHByb2plY3RpbGUuZGFtYWdlUHJvZmlsZSA/IHsgZGFtYWdlUHJvZmlsZTogeyAuLi5wcm9qZWN0aWxlLmRhbWFnZVByb2ZpbGUgfSB9IDoge30pLFxuICAgICAgLi4uKHByb2plY3RpbGUud2VhcG9uID8geyB3ZWFwb246IHsgLi4ucHJvamVjdGlsZS53ZWFwb24sIC4uLihwcm9qZWN0aWxlLndlYXBvbi5kYW1hZ2VQcm9maWxlID8geyBkYW1hZ2VQcm9maWxlOiB7IC4uLnByb2plY3RpbGUud2VhcG9uLmRhbWFnZVByb2ZpbGUgfSB9IDoge30pIH0gfSA6IHt9KSxcbiAgICB9KSksXG4gICAgZWZmZWN0czogZ2FtZS5lZmZlY3RzLm1hcChlZmZlY3QgPT4gKHsgLi4uZWZmZWN0LCAuLi4oZWZmZWN0LmRhbWFnZVByb2ZpbGUgPyB7IGRhbWFnZVByb2ZpbGU6IHsgLi4uZWZmZWN0LmRhbWFnZVByb2ZpbGUgfSB9IDoge30pIH0pKSxcbiAgICAuLi4oZ2FtZS5jb3Jwc2VzID8geyBjb3Jwc2VzOiBnYW1lLmNvcnBzZXMubWFwKGNvcnBzZSA9PiAoeyAuLi5jb3Jwc2UsIC4uLihjb3Jwc2UuZGVjaz97ZGVjazp7Li4uY29ycHNlLmRlY2t9fTp7fSkgfSkpIH0gOiB7fSksXG4gICAgLy8gQSB2YXJpYW50J3MgcnVsZXMgYXJlIHJlcGxhY2VkIHdob2xlIHdoZW4gdGhleSBjaGFuZ2UsIG5ldmVyIGVkaXRlZCwgc28gdGhlIHNuYXBzaG90IG1heSBzaGFyZSB0aGVtLlxuICAgIC4uLihnYW1lLnZhcmlhbnRzID8geyB2YXJpYW50czogeyAuLi5nYW1lLnZhcmlhbnRzIH0gfSA6IHt9KSxcbiAgICAuLi4oZ2FtZS5vYnN0YWNsZXMgPyB7IG9ic3RhY2xlczogZ2FtZS5vYnN0YWNsZXMubWFwKChvYnN0YWNsZSkgPT4gKHsgLi4ub2JzdGFjbGUsIGFsb25nOiB7IC4uLm9ic3RhY2xlLmFsb25nIH0gfSkpIH0gOiB7fSksXG4gIH07XG4gIGJpbmRHYW5nd2F5Q3Jld1J1bGVzKHNuYXBzaG90LnVuaXRzLHNuYXBzaG90KTtcbiAgc2hhcmVCdWlsZGluZ0JvZGllcyhnYW1lLm1hcCwgc25hcHNob3QubWFwKTtcbiAgcmV0dXJuIHNuYXBzaG90O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVzdG9yZVNuYXBzaG90SW50b0dhbWUoZ2FtZTogR2FtZSwgc25hcHNob3Q6IEdhbWVTbmFwc2hvdCwgbmV4dElkOiBudW1iZXIpOiB2b2lkIHtcbiAgZ2FtZS5lcXVpcG1lbnRWZXJzaW9uID0gMTtcbiAgZ2FtZS5yYXRlVW5pdHMgPSBcInBlclNlY29uZFwiO1xuICBnYW1lLnRpY2sgPSBzbmFwc2hvdC50aWNrO1xuICBnYW1lLm1hdGNoID0gY2xvbmVTbmFwc2hvdFZhbHVlKHNuYXBzaG90Lm1hdGNoKTtcbiAgZ2FtZS5tYXAgPSBjbG9uZVNuYXBzaG90VmFsdWUoc25hcHNob3QubWFwKTtcbiAgZ2FtZS50ZWFtcyA9IHNuYXBzaG90LnRlYW1zID8gZGVmaW5lZFRlYW1zKHNuYXBzaG90LnRlYW1zKSA6IHsgLi4uZ2FtZS50ZWFtcyB9O1xuICBnYW1lLnBsYXllcnMgPSBjbG9uZVNuYXBzaG90VmFsdWUoc25hcHNob3QucGxheWVycyk7XG4gIGNvbnN0IGNvbG9ycz1hc3NpZ25QbGF5ZXJDb2xvcnMoT2JqZWN0LmtleXMoZ2FtZS5wbGF5ZXJzKSxPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoZ2FtZS5wbGF5ZXJzKS5tYXAoKFtvd25lcixwbGF5ZXJdKT0+W293bmVyLHBsYXllci5jb2xvcl0pKSk7XG4gIGZvcihjb25zdCBbb3duZXIscGxheWVyXSBvZiBPYmplY3QuZW50cmllcyhnYW1lLnBsYXllcnMpKXBsYXllci5jb2xvcj1jb2xvcnNbb3duZXJdITtcbiAgaWYgKHNuYXBzaG90LnRlYW1zKSBnYW1lLmFjdGl2ZVBsYXllcnMgPSBPYmplY3Qua2V5cyhzbmFwc2hvdC50ZWFtcykuZmlsdGVyKG93bmVyID0+IHNuYXBzaG90LnBsYXllcnNbb3duZXJdICE9PSB1bmRlZmluZWQpO1xuICBnYW1lLnVuaXRzID0gY2xvbmVTbmFwc2hvdFZhbHVlKHNuYXBzaG90LnVuaXRzKS5tYXAod2l0aFVuaXRTaGFwZSk7XG4gIGdhbWUuYnVpbGRpbmdzID0gY2xvbmVTbmFwc2hvdFZhbHVlKHNuYXBzaG90LmJ1aWxkaW5ncyk7XG4gIGdhbWUucmVzb3VyY2VzID0gY2xvbmVTbmFwc2hvdFZhbHVlKHNuYXBzaG90LnJlc291cmNlcyk7XG4gIGdhbWUubWVyY2VuYXJ5Q2FtcHMgPSBjbG9uZVNuYXBzaG90VmFsdWUoc25hcHNob3QubWVyY2VuYXJ5Q2FtcHMpO1xuICBpZiAoc25hcHNob3Quc2hvcHMpIGdhbWUuc2hvcHMgPSBjbG9uZVNuYXBzaG90VmFsdWUoc25hcHNob3Quc2hvcHMpO1xuICBlbHNlIGRlbGV0ZSBnYW1lLnNob3BzO1xuICBnYW1lLml0ZW1zID0gY2xvbmVTbmFwc2hvdFZhbHVlKHNuYXBzaG90Lml0ZW1zKTtcbiAgZ2FtZS5wcm9qZWN0aWxlcyA9IGNsb25lU25hcHNob3RWYWx1ZShzbmFwc2hvdC5wcm9qZWN0aWxlcyk7XG4gIGdhbWUuZWZmZWN0cyA9IGNsb25lU25hcHNob3RWYWx1ZShzbmFwc2hvdC5lZmZlY3RzKTtcbiAgaWYgKHNuYXBzaG90LmNvcnBzZXMpIGdhbWUuY29ycHNlcyA9IGNsb25lU25hcHNob3RWYWx1ZShzbmFwc2hvdC5jb3Jwc2VzKTtcbiAgZWxzZSBkZWxldGUgZ2FtZS5jb3Jwc2VzO1xuICBpZiAoc25hcHNob3QudmFyaWFudHMpIGdhbWUudmFyaWFudHMgPSBjbG9uZVNuYXBzaG90VmFsdWUoc25hcHNob3QudmFyaWFudHMpO1xuICBlbHNlIGRlbGV0ZSBnYW1lLnZhcmlhbnRzO1xuICBpZiAoc25hcHNob3Qub2JzdGFjbGVzKSBnYW1lLm9ic3RhY2xlcyA9IGNsb25lU25hcHNob3RWYWx1ZShzbmFwc2hvdC5vYnN0YWNsZXMpO1xuICBlbHNlIGRlbGV0ZSBnYW1lLm9ic3RhY2xlcztcbiAgaWYgKCFzbmFwc2hvdC5yYXRlVW5pdHMpIG1pZ3JhdGVTbmFwc2hvdFJhdGVzKGdhbWUpO1xuICBmb3IoY29uc3QgYnVpbGRpbmcgb2YgZ2FtZS5idWlsZGluZ3MpZm9yKGNvbnN0IGpvYiBvZiBidWlsZGluZy5xdWV1ZSlpZihqb2IucGFpZEdvbGQ9PT11bmRlZmluZWQpam9iLnBhaWRHb2xkPWlzU2hpcEtpbmQoam9iLnVuaXRLaW5kKSA/IFBSRVZJT1VTX1NISVBfVFJBSU5fQ09TVFtqb2IudW5pdEtpbmQgYXMga2V5b2YgdHlwZW9mIFBSRVZJT1VTX1NISVBfVFJBSU5fQ09TVF0gOiBVTklUX0RFRlNbam9iLnVuaXRLaW5kXS5jb3N0O1xuICBtaWdyYXRlU2hpcFNpemVzKGdhbWUudW5pdHMpO1xuICByZXN0b3JlQ2FyZ29EZWNrcyhnYW1lLnVuaXRzKTtcbiAgZm9yIChjb25zdCBzaGlwIG9mIHNoaXBzSW4oZ2FtZS51bml0cykpIGlmIChzaGlwLnNoaXBQYXJ0cykgc2hpcC5zaGlwUGFydHMuY2FiaW4gPz89IHNoaXBQYXJ0TWF4KHNoaXApLmNhYmluO1xuICAvLyBFYXJseSBuYXZhbCBwcmV2aWV3cyBoYWQgYSBzZXBhcmF0ZSBsZWcgcGllY2UuIEZvbGQgdGhvc2Ugc2F2ZWQgaXRlbXMgaW50b1xuICAvLyBib2R5IGFybW9yIGFuZCByZWFzc2lnbiB0aGVpciBwb3NpdGlvbnMgd2l0aG91dCBkaXNjYXJkaW5nIGVxdWlwbWVudC5cbiAgY29uc3QgcmVtb3ZlZEFybW9yID0gZ2FtZS5pdGVtcy5zb21lKGl0ZW0gPT4gKGl0ZW0ua2luZCBhcyBzdHJpbmcpID09PSAnbGVnR3VhcmRzJyB8fCAoaXRlbS5zbG90IGFzIHN0cmluZykgPT09ICdsZWdzJyk7XG4gIGlmIChyZW1vdmVkQXJtb3IpIHtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgZ2FtZS5pdGVtcykge1xuICAgICAgaWYgKChpdGVtLmtpbmQgYXMgc3RyaW5nKSA9PT0gJ2xlZ0d1YXJkcycpIHsgaXRlbS5raW5kID0gJ2xlYXRoZXJBcm1vcic7IGRlbGV0ZSBpdGVtLnNsb3Q7IH1cbiAgICAgIGVsc2UgaWYgKChpdGVtLnNsb3QgYXMgc3RyaW5nKSA9PT0gJ2xlZ3MnKSBkZWxldGUgaXRlbS5zbG90O1xuICAgIH1cbiAgICBub3JtYWxpemVFcXVpcG1lbnQoZ2FtZSk7XG4gICAgcmVmcmVzaEVxdWlwbWVudE1hc3MoZ2FtZSk7XG4gIH1cbiAgaWYgKGdhbWUuc2hvcHMpIGZvciAoY29uc3Qgc2hvcCBvZiBnYW1lLnNob3BzKSBzaG9wLmdvb2RzID0gc2hvcC5nb29kcy5maWx0ZXIoZ29vZCA9PiAoZ29vZC5raW5kIGFzIHN0cmluZykgIT09ICdsZWdHdWFyZHMnKTtcbiAgaWYgKHNuYXBzaG90LmVxdWlwbWVudFZlcnNpb24gIT09IDEpIHtcbiAgICBpbml0aWFsaXplU2hpcEVxdWlwbWVudChnYW1lKTtcbiAgICBub3JtYWxpemVFcXVpcG1lbnQoZ2FtZSx0cnVlKTtcbiAgICByZWZyZXNoRXF1aXBtZW50TWFzcyhnYW1lKTtcbiAgfVxuICBnYW1lLm5leHRJZCA9IG5leHRJZDtcbiAgbm9ybWFsaXplRXF1aXBtZW50KGdhbWUpO1xuICBrZWVwU2hpcHNPbldhdGVyKGdhbWUubWFwLGdhbWUudW5pdHMpO1xuICBzeW5jRGVja3MoZ2FtZS51bml0cyk7XG4gIGludmFsaWRhdGVHYW1lUnVudGltZUNhY2hlcyhnYW1lKTtcbiAgcmVmcmVzaFZldGVyYW5GcmFtZShnYW1lKTtcbiAgYmluZEdhbmd3YXlDcmV3UnVsZXMoZ2FtZS51bml0cyxnYW1lKTtcbn1cblxuLyoqIE9sZCBzYXZlcyB1c2VkIDIwIEh6IHJhdGVzLCBpbmNsdWRpbmcgcGFzc2VuZ2VycyBhbmQgY2FtcGFpZ24gcnVsZSBvdmVycmlkZXMuICovXG5mdW5jdGlvbiBtaWdyYXRlU25hcHNob3RSYXRlcyhnYW1lOiBHYW1lKTogdm9pZCB7XG4gIGNvbnN0IG1pZ3JhdGUgPSAodW5pdDogVW5pdCkgPT4ge1xuICAgIHVuaXQuc3BlZWQgKj0gMjA7XG4gICAgaWYgKHVuaXQucHVzaFggIT09IHVuZGVmaW5lZCkgdW5pdC5wdXNoWCAqPSAyMDtcbiAgICBpZiAodW5pdC5wdXNoWSAhPT0gdW5kZWZpbmVkKSB1bml0LnB1c2hZICo9IDIwO1xuICAgIHVuaXQuY2FyZ28/LmZvckVhY2gobWlncmF0ZSk7XG4gIH07XG4gIGdhbWUudW5pdHMuZm9yRWFjaChtaWdyYXRlKTtcbiAgZm9yIChjb25zdCBydWxlcyBvZiBPYmplY3QudmFsdWVzKGdhbWUudmFyaWFudHMgPz8ge30pKSB7XG4gICAgcnVsZXMuc3BlZWQgKj0gMjA7XG4gICAgaWYgKHJ1bGVzLmFpbVNwZWVkICE9PSB1bmRlZmluZWQpIHJ1bGVzLmFpbVNwZWVkICo9IDIwO1xuICB9XG59XG5cbmZ1bmN0aW9uIGludmFsaWRhdGVHYW1lUnVudGltZUNhY2hlcyhnYW1lOiBHYW1lKTogdm9pZCB7XG4gIGludmFsaWRhdGVTZXBhcmF0aW9uRnJhbWUoZ2FtZSk7XG4gIGRlbGV0ZSBnYW1lLnZldGVyYW5GcmFtZTtcbiAgZGVsZXRlIGdhbWUudmV0ZXJhbkF1dG9jYXN0RnJhbWU7XG4gIGRlbGV0ZSBnYW1lLmJvYXJkaW5nSG9sZHM7XG4gIGRlbGV0ZSBnYW1lLnVuaXRTcGF0aWFsO1xuICBkZWxldGUgZ2FtZS51bml0U3BhdGlhbEJ5VGVhbTtcbiAgZGVsZXRlIGdhbWUuc2hpcFJlYWNoUGFkZGluZztcbiAgZGVsZXRlIGdhbWUuYnVpbGRpbmdTcGF0aWFsO1xuICBkZWxldGUgZ2FtZS5idWlsZGluZ1NwYXRpYWxCeVRlYW07XG4gIGRlbGV0ZSBnYW1lLmJ1aWxkaW5nU3BhdGlhbENvdW50O1xuICBkZWxldGUgZ2FtZS5idWlsZGluZ0JvZGllc1NlZW47XG4gIGRlbGV0ZSBnYW1lLmVudGl0eUJ5SWQ7XG59XG5cbmZ1bmN0aW9uIGNsb25lU25hcHNob3RWYWx1ZTxUPih2YWx1ZTogVCk6IFQge1xuICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh2YWx1ZSkpIGFzIFQ7XG59XG5cbmZ1bmN0aW9uIGRlZmluZWRUZWFtcyh0ZWFtczogUGFydGlhbDxSZWNvcmQ8UGxheWVySWQsIHN0cmluZz4+KTogUmVjb3JkPFBsYXllcklkLCBzdHJpbmc+IHtcbiAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyh0ZWFtcykuZmlsdGVyKChlbnRyeSk6IGVudHJ5IGlzIFtQbGF5ZXJJZCwgc3RyaW5nXSA9PiB0eXBlb2YgZW50cnlbMV0gPT09IFwic3RyaW5nXCIpKTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlQ29uc3RydWN0aW9uKGdhbWU6IEdhbWUpIHtcbiAgZm9yIChjb25zdCBidWlsZGluZyBvZiBnYW1lLmJ1aWxkaW5ncykge1xuICAgIGlmIChidWlsZGluZy5jb21wbGV0ZSkgY29udGludWU7XG4gICAgLy8gQSBzaXRlIGdvZXMgdXAgd2l0aCB0aGUgd29yayBvZiB0aGUgd29ya2VycyBzZW50IHRvIGl0LCBhdCBpdCAoc2VlIEBAQGJ1aWxkaW5nLXdvcmspOiB0aGUgYnVpbGRlcidzIG9yZGVyIGlzIHRvIHJlcGFpclxuICAgIC8vIGl0LCBhbmQgYSB3b3JrZXIgc2VudCB0byBoZWxwIHJlcGFpcnMgaXQgdG9vLCBhcyBhIHBlYXNhbnQgZG9lcyBpbiBXYXJjcmFmdCBJSUkuIENvdW50ZWQgYnkgd2hvIHN0b29kIG5lYXIgaXQsIG9uZVxuICAgIC8vIHdvcmtlciBhbW9uZyB0aHJlZSBzaXRlcyByYWlzZWQgYWxsIHRocmVlIGF0IG9uY2UsIGFuZCBhIG1pbmVyIHBhc3NpbmcgYSBzaXRlIHdhcyBzZXQgaWRsZSB3aGVuIGl0IHdhcyBkb25lICh0aGVcbiAgICAvLyBvd25lciwgMTAtMDIpLlxuICAgIGNvbnN0IGJ1aWxkZXJzID0gY29uc3RydWN0aW9uV29ya2VycyhnYW1lLCBidWlsZGluZyk7XG4gICAgaWYgKGJ1aWxkZXJzLmxlbmd0aCA9PT0gMCkgY29udGludWU7XG4gICAgZm9yIChjb25zdCBidWlsZGVyIG9mIGJ1aWxkZXJzKSBlbWl0V29ya2VyV29yayhnYW1lLCBidWlsZGVyLCBidWlsZGluZyk7XG4gICAgLy8gVGhlIHNpdGUgZ2FpbnMgaGVhbHRoIHdpdGggdGhlIHdvcmsgZG9uZSAoc2VlIGNvbnN0cnVjdGlvbi1ocCk6IGVhY2ggYnVpbGRlcidzIHNoYXJlIG9mIHRoZSBidWlsZCB0aW1lIGJyaW5ncyB0aGVcbiAgICAvLyBzYW1lIHNoYXJlIG9mIHRoZSBoZWFsdGggaXQgc3RhcnRlZCB3aXRob3V0LlxuICAgIGNvbnN0IGJlZm9yZSA9IGJ1aWxkaW5nLmJ1aWxkUHJvZ3Jlc3M7XG4gICAgYnVpbGRpbmcuYnVpbGRQcm9ncmVzcyA9IE1hdGgubWluKGJ1aWxkaW5nLmJ1aWxkVGltZSwgYnVpbGRpbmcuYnVpbGRQcm9ncmVzcyArIGJ1aWxkZXJzLmxlbmd0aCk7XG4gICAgY29uc3QgZ2FpbmVkID0gKChidWlsZGluZy5idWlsZFByb2dyZXNzIC0gYmVmb3JlKSAvIE1hdGgubWF4KDEsIGJ1aWxkaW5nLmJ1aWxkVGltZSkpICogKGJ1aWxkaW5nLm1heEhwIC0gY29uc3RydWN0aW9uU3RhcnRIcChidWlsZGluZy5tYXhIcCkpO1xuICAgIGJ1aWxkaW5nLmhwID0gTWF0aC5taW4oYnVpbGRpbmcubWF4SHAsIGJ1aWxkaW5nLmhwICsgZ2FpbmVkKTtcbiAgICBpZiAoYnVpbGRpbmcuYnVpbGRQcm9ncmVzcyA+PSBidWlsZGluZy5idWlsZFRpbWUpIHtcbiAgICAgIGFwcGx5RGVyaXZlZEJ1aWxkaW5nU3RhdHMoZ2FtZSwgYnVpbGRpbmcpO1xuICAgICAgYnVpbGRpbmcuY29tcGxldGUgPSB0cnVlO1xuICAgICAgZm9yIChjb25zdCBidWlsZGVyIG9mIGJ1aWxkZXJzKSBidWlsZGVyLm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgICAgdXBkYXRlU3VwcGx5U3RhdGUoZ2FtZSk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVRyYWluaW5nKGdhbWU6IEdhbWUpIHtcbiAgZm9yIChjb25zdCBidWlsZGluZyBvZiBnYW1lLmJ1aWxkaW5ncykge1xuICAgIGlmICghYnVpbGRpbmcuY29tcGxldGUgfHwgYnVpbGRpbmcucXVldWUubGVuZ3RoID09PSAwKSBjb250aW51ZTtcbiAgICBjb25zdCBqb2IgPSBidWlsZGluZy5xdWV1ZVswXTtcbiAgICBpZiAoIWpvYikgY29udGludWU7XG4gICAgam9iLnJlbWFpbmluZyA9IE1hdGgubWF4KDAsam9iLnJlbWFpbmluZy0xKTtcbiAgICBpZiAoam9iLnJlbWFpbmluZyA+IDApIGNvbnRpbnVlO1xuICAgIGNvbnN0IHNlYT11bml0TW92ZXIoam9iLnVuaXRLaW5kKT09PVwic2VhXCI7XG4gICAgY29uc3QgbGF1bmNoPXNlYSA/IHNoaXBMYXVuY2hQb3NlKGdhbWUsYnVpbGRpbmcsc2hpcExhdW5jaFByb3RvdHlwZShidWlsZGluZyxqb2IudW5pdEtpbmQpKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBmcm9tPXNlYSA/IGxhdW5jaCA6IGxhbmRTcGF3blBvaW50KGdhbWUsYnVpbGRpbmcsbGFuZFNwYXduUHJvdG90eXBlKGJ1aWxkaW5nLGpvYi51bml0S2luZCkpO1xuICAgIC8vIEEgcGFpZCBqb2Igd2FpdHMgZm9yIGEgbGVnYWwgbG9jYWwgZXhpdC4gUmFsbHkgZGlyZWN0aW9uIGNob29zZXMgYW1vbmdcbiAgICAvLyB0aG9zZSBleGl0cyByYXRoZXIgdGhhbiBwbGFjaW5nIHRoZSBuZXcgdW5pdCBpbnNpZGUgYSBib2R5IG9yIGJleW9uZCBpdC5cbiAgICBpZighZnJvbSljb250aW51ZTtcbiAgICBjb25zdCB1bml0ID0gZ2FtZS5zcGF3blVuaXQoYnVpbGRpbmcub3duZXIsIGpvYi51bml0S2luZCwgZnJvbS54LCBmcm9tLnksbGF1bmNoKTtcbiAgICBidWlsZGluZy5xdWV1ZS5zaGlmdCgpO1xuICAgIHVuaXQub3JkZXIgPSByYWxseU9yZGVyRm9yVW5pdChnYW1lLCBidWlsZGluZywgdW5pdCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gdXBkYXRlUmVzZWFyY2goZ2FtZTogR2FtZSkge1xuICBmb3IgKGNvbnN0IGJ1aWxkaW5nIG9mIGdhbWUuYnVpbGRpbmdzKSB7XG4gICAgaWYgKCFidWlsZGluZy5jb21wbGV0ZSB8fCBidWlsZGluZy5yZXNlYXJjaFF1ZXVlLmxlbmd0aCA9PT0gMCkgY29udGludWU7XG4gICAgY29uc3Qgam9iID0gYnVpbGRpbmcucmVzZWFyY2hRdWV1ZVswXTtcbiAgICBpZiAoIWpvYikgY29udGludWU7XG4gICAgam9iLnJlbWFpbmluZyAtPSAxO1xuICAgIGlmIChqb2IucmVtYWluaW5nID4gMCkgY29udGludWU7XG4gICAgYnVpbGRpbmcucmVzZWFyY2hRdWV1ZS5zaGlmdCgpO1xuICAgIGNvbXBsZXRlUmVzZWFyY2goZ2FtZSwgYnVpbGRpbmcub3duZXIsIGpvYi51cGdyYWRlS2luZCwgam9iLnRhcmdldExldmVsKTtcbiAgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVUb3dlckF0dGFja3MoZ2FtZTogR2FtZSkge1xuICBmb3IgKGNvbnN0IGJ1aWxkaW5nIG9mIGdhbWUuYnVpbGRpbmdzKSB7XG4gICAgaWYgKCFidWlsZGluZy5jb21wbGV0ZSB8fCBidWlsZGluZy5hdHRhY2tEYW1hZ2UgPD0gMCkgY29udGludWU7XG4gICAgYnVpbGRpbmcuY29vbGRvd24gPSBNYXRoLm1heCgwLCBidWlsZGluZy5jb29sZG93biAtIDEpO1xuICAgIGlmIChidWlsZGluZy5jb29sZG93biA+IDApIGNvbnRpbnVlO1xuICAgIGNvbnN0IHRhcmdldCA9IG5lYXJlc3RFbmVteVRhcmdldEZyb21Qb2ludChnYW1lLCBidWlsZGluZy5vd25lciwgYnVpbGRpbmcsIGJ1aWxkaW5nLmF0dGFja1JhbmdlKTtcbiAgICBpZiAoIXRhcmdldCkgY29udGludWU7XG4gICAgYXBwbHlXZWFwb25BdHRhY2soZ2FtZSwgYnVpbGRpbmcsIHRhcmdldCwgYnVpbGRpbmcuYXR0YWNrRGFtYWdlLCBidWlsZGluZy5hdHRhY2tSYW5nZSk7XG4gICAgYnVpbGRpbmcuY29vbGRvd24gPSBidWlsZGluZy5hdHRhY2tDb29sZG93bjtcbiAgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVNb29uV2VsbEhlYWxpbmcoZ2FtZTogR2FtZSkge1xuICBmb3IgKGNvbnN0IGJ1aWxkaW5nIG9mIGdhbWUuYnVpbGRpbmdzKSB7XG4gICAgaWYgKCFidWlsZGluZy5jb21wbGV0ZSB8fCAhaXNIZWFsaW5nQnVpbGRpbmdLaW5kKGJ1aWxkaW5nLmtpbmQpKSBjb250aW51ZTtcbiAgICBidWlsZGluZy5jb29sZG93biA9IE1hdGgubWF4KDAsIGJ1aWxkaW5nLmNvb2xkb3duIC0gMSk7XG4gICAgaWYgKGJ1aWxkaW5nLmNvb2xkb3duID4gMCkgY29udGludWU7XG4gICAgY29uc3QgdGFyZ2V0ID0gbW9zdFdvdW5kZWRTb2xkaWVyTmVhcihnYW1lLCBidWlsZGluZyk7XG4gICAgaWYgKCF0YXJnZXQpIGNvbnRpbnVlO1xuICAgIHRhcmdldC5ocCA9IE1hdGgubWluKHRhcmdldC5tYXhIcCwgdGFyZ2V0LmhwICsgU1VQUE9SVF9CVUlMRElOR19IRUFMKTtcbiAgICBidWlsZGluZy5jb29sZG93biA9IGJ1aWxkaW5nLmF0dGFja0Nvb2xkb3duO1xuICAgIGFkZEVmZmVjdChnYW1lLCBcImhlYWxcIiwgdGFyZ2V0LngsIHRhcmdldC55LCBNT09OX1dFTExfSEVBTF9FRkZFQ1RfRFVSQVRJT04sIHsgZnJvbVg6IGJ1aWxkaW5nLngsIGZyb21ZOiBidWlsZGluZy55LCB0b1g6IHRhcmdldC54LCB0b1k6IHRhcmdldC55IH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIG1vc3RXb3VuZGVkU29sZGllck5lYXIoZ2FtZTogR2FtZSwgYnVpbGRpbmc6IEJ1aWxkaW5nKSB7XG4gIGxldCB0YXJnZXQ6IFVuaXQgfCB1bmRlZmluZWQ7XG4gIGxldCB0YXJnZXRTY29yZSA9IDA7XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIGJ1aWxkaW5nLCBidWlsZGluZy5hdHRhY2tSYW5nZSwgKHVuaXQpID0+IHtcbiAgICBpZiAoIWNhblJlY2VpdmVIZWFsaW5nKHVuaXQsIGdhbWUpIHx8IHVuaXQub3duZXIgIT09IGJ1aWxkaW5nLm93bmVyIHx8IHVuaXQua2luZCA9PT0gXCJ3b3JrZXJcIiB8fCB1bml0LmhwID49IHVuaXQubWF4SHAgfHwgZGlzdGFuY2UodW5pdCwgYnVpbGRpbmcpID4gYnVpbGRpbmcuYXR0YWNrUmFuZ2UpIHJldHVybjtcbiAgICBjb25zdCBzY29yZSA9ICh1bml0Lm1heEhwIC0gdW5pdC5ocCkgKiAyICsgKDEgLSB1bml0LmhwIC8gTWF0aC5tYXgoMSwgdW5pdC5tYXhIcCkpICogODA7XG4gICAgaWYgKHNjb3JlIDw9IHRhcmdldFNjb3JlKSByZXR1cm47XG4gICAgdGFyZ2V0ID0gdW5pdDtcbiAgICB0YXJnZXRTY29yZSA9IHNjb3JlO1xuICB9KTtcbiAgcmV0dXJuIHRhcmdldDtcbn1cblxuZnVuY3Rpb24gdXBkYXRlRG9ja1JlcGFpcnMoZ2FtZTogR2FtZSkge1xuICBpZiAoZ2FtZS50aWNrICUgc2Vjb25kcygxKSkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IHNoaXAgb2YgZ2FtZS51bml0cykge1xuICAgIGlmICghc2hpcFByb2ZpbGUoc2hpcCkgfHwgIXVuaXROZWVkc1JlcGFpcihnYW1lLHNoaXApIHx8ICFpc1BsYXllcklkKHNoaXAub3duZXIpIHx8IHNoaXAub3JkZXIudHlwZT09PVwiYXR0YWNrXCIgfHwgc2hpcC5vcmRlci50eXBlPT09XCJhdHRhY2tNb3ZlXCIpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGRvY2s9Z2FtZS5idWlsZGluZ3MuZmluZChidWlsZGluZz0+YnVpbGRpbmcub3duZXI9PT1zaGlwLm93bmVyICYmIGJ1aWxkaW5nLmtpbmQ9PT1cInNoaXB5YXJkXCIgJiYgYnVpbGRpbmcuY29tcGxldGUgJiYgZGlzdGFuY2Uoc2hpcCxidWlsZGluZyk8RE9DS19SRVBBSVIucmFuZ2UpO1xuICAgIGlmICghZG9jayB8fCBwbGF5ZXJTdGF0ZShnYW1lLHNoaXAub3duZXIpLmdvbGQ8RE9DS19SRVBBSVIuZ29sZFBlclNlY29uZCljb250aW51ZTtcbiAgICBzcGVuZEdvbGQoZ2FtZSxzaGlwLm93bmVyLERPQ0tfUkVQQUlSLmdvbGRQZXJTZWNvbmQpO3JlcGFpclNoaXBQYXJ0cyhnYW1lLHNoaXAsRE9DS19SRVBBSVIuaHBQZXJTZWNvbmQpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVJlZ2VuZXJhdGlvbihnYW1lOiBHYW1lKSB7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSB7XG4gICAgaWYgKHVuaXQuaHAgPD0gMCB8fCB1bml0LmhwID49IHVuaXQubWF4SHApIGNvbnRpbnVlO1xuICAgIGNvbnN0IHJlZ2VuUGVyU2Vjb25kID0gdW5pdFJlZ2VuUGVyU2Vjb25kKGdhbWUsIHVuaXQpO1xuICAgIGlmIChyZWdlblBlclNlY29uZCA8PSAwKSBjb250aW51ZTtcbiAgICB1bml0LmhwID0gTWF0aC5taW4odW5pdC5tYXhIcCwgdW5pdC5ocCArIHJlZ2VuUGVyU2Vjb25kIC8gMjApO1xuICB9XG59XG5cbi8vIEEgdW5pdCdzIG93biByZWdlbmVyYXRpb24gKHRoZSBjaW5kZXIgcmV2ZW5hbnQncykgcGx1cyB3aGF0IGxlYWRlcnNoaXAgZ2l2ZXMgaXRzIHZldGVyYW5zLlxuZXhwb3J0IGZ1bmN0aW9uIHVuaXRSZWdlblBlclNlY29uZChnYW1lOiBHYW1lU25hcHNob3QsIHVuaXQ6IFVuaXQpIHtcbiAgY29uc3QgdmV0ZXJhbnMgPSBcIm5leHRJZFwiIGluIGdhbWUgPyAoZ2FtZSBhcyBHYW1lKS52ZXRlcmFuRnJhbWUgOiBidWlsZFZldGVyYW5GcmFtZShnYW1lKTtcbiAgY29uc3QgcnVsZXMgPSB1bml0UnVsZXMoZ2FtZSwgdW5pdCk7XG4gIGNvbnN0IG1lZGljYWxDbGFzc2VzOiByZWFkb25seSBVbml0Q2xhc3NbXSA9IE5PTl9NRUNIQU5JQ0FMX1RBUkdFVFMudW5pdENsYXNzZXM7XG4gIHJldHVybiAoIW1lZGljYWxDbGFzc2VzIHx8IG1lZGljYWxDbGFzc2VzLmluY2x1ZGVzKHJ1bGVzLnVuaXRDbGFzcyA/PyBVTklUX0RFRlNbdW5pdC5raW5kXS51bml0Q2xhc3MpKVxuICAgID8gKHJ1bGVzLnJlZ2VuUGVyU2Vjb25kID8/IDApICsgcXVhbGlmaWVkTGVhZGVyc2hpcFJlZ2VuUGVyU2Vjb25kKGdhbWUsIHVuaXQpICsgKHZldGVyYW5zPy5nZXQodW5pdC5pZCk/LnJlZ2VuUGVyU2Vjb25kID8/IDApIDogMDtcbn1cblxuZnVuY3Rpb24gdmV0ZXJhbk5lYXJieShnYW1lOiBHYW1lKSB7XG4gIHJldHVybiAoeDogbnVtYmVyLCB5OiBudW1iZXIsIHJhZGl1czogbnVtYmVyKSA9PiB7XG4gICAgY29uc3QgdW5pdHM6IFVuaXRbXSA9IFtdO1xuICAgIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIHsgeCwgeSB9LCByYWRpdXMsIHVuaXQgPT4gdW5pdHMucHVzaCh1bml0KSk7XG4gICAgcmV0dXJuIHVuaXRzO1xuICB9O1xufVxuZnVuY3Rpb24gcmVmcmVzaFZldGVyYW5GcmFtZUFmdGVyQ29tbWFuZFNwYXduKGdhbWU6IEdhbWUpIHtcbiAgLy8gU0RLIGNvbW1hbmRzIG1heSBiZSBzYXZlZCBiZWZvcmUgdGhlIG5leHQgdGljay4gSW5jbHVkZSBuZXcgdW5pdHMgYXQgdGhlaXIgZmluYWwgc3Bhd24gcG9zaXRpb25zLlxuICBnYW1lLnVuaXRTcGF0aWFsID0gY3JlYXRlU3BhdGlhbEluZGV4KGdhbWUudW5pdHMsIDMyMCk7XG4gIHJlZnJlc2hWZXRlcmFuRnJhbWUoZ2FtZSk7XG59XG5mdW5jdGlvbiByZWZyZXNoVmV0ZXJhbkZyYW1lKGdhbWU6IEdhbWUsIGVtcHR5ID0gZmFsc2UpIHtcbiAgY29uc3QgcHJldmlvdXMgPSBnYW1lLnZldGVyYW5GcmFtZTtcbiAgZ2FtZS52ZXRlcmFuRnJhbWUgPSBlbXB0eSA/IHVuZGVmaW5lZCA6IGJ1aWxkVmV0ZXJhbkZyYW1lKGdhbWUsIHZldGVyYW5OZWFyYnkoZ2FtZSkpO1xuICAvLyBObyBjdXJyZW50IG9yIGRlcGFydGVkIHByb2plY3Rpb24gY2FuIGNoYW5nZSBhbnkgdW5pdCdzIGRlcml2ZWQgc3RhdHMuXG4gIGlmICghcHJldmlvdXM/LnNpemUgJiYgIWdhbWUudmV0ZXJhbkZyYW1lPy5zaXplKSByZXR1cm47XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSB7XG4gICAgaWYgKHVuaXQuaHAgPiAwICYmIChwcmV2aW91cz8uaGFzKHVuaXQuaWQpIHx8IGdhbWUudmV0ZXJhbkZyYW1lPy5oYXModW5pdC5pZCkpKSB7XG4gICAgICBjb25zdCBocCA9IHVuaXQuaHA7XG4gICAgICBhcHBseURlcml2ZWRVbml0U3RhdHMoZ2FtZSwgdW5pdCk7XG4gICAgICAvLyBBdXJhIHByb2plY3Rpb24gY2hhbmdlcyBkZXJpdmVkIGNvbWJhdCBzdGF0cywgbmV2ZXIgaGVhbHRoIChpbmNsdWRpbmcgZnJhY3Rpb25zIGJlbG93IG9uZSkuXG4gICAgICB1bml0LmhwID0gTWF0aC5taW4oaHAsIHVuaXQubWF4SHApO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gdmV0ZXJhbkFpbVNwZWVkKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgcmV0dXJuIGdhbWUudmV0ZXJhbkZyYW1lPy5nZXQodW5pdC5pZCk/LmFpbVNwZWVkTXVsdGlwbGllciA/PyAxO1xufVxuZnVuY3Rpb24gYXBwbHlWZXRlcmFuQWJpbGl0eShnYW1lOiBHYW1lLCBjYXN0ZXI6IFVuaXQsIGFiaWxpdHk6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJ2ZXRlcmFuXCIgfT4sIGF1dG9tYXRpYzogYm9vbGVhbikge1xuICByZXR1cm4gY2FzdFZldGVyYW5BYmlsaXR5KGdhbWUsIGNhc3RlciwgYWJpbGl0eS5za2lsbCwgYXV0b21hdGljLFxuICAgICh0eXBlLCB4LCB5LCBkdXJhdGlvbiwgb3B0aW9ucykgPT4gYWRkRWZmZWN0KGdhbWUsIHR5cGUsIHgsIHksIGR1cmF0aW9uLCB7Li4ub3B0aW9ucyxzb3VyY2VJZDpjYXN0ZXIuaWQsYWN0aW9uTW9kZTpcImNhc3RcIixmcm9tWDpjYXN0ZXIueCxmcm9tWTpjYXN0ZXIueSx0b1g6eCx0b1k6eX0pLCB2ZXRlcmFuTmVhcmJ5KGdhbWUpLCBnYW1lLnZldGVyYW5BdXRvY2FzdEZyYW1lKTtcbn1cblxuZXhwb3J0IHsgdW5pdFJ1bGVzIH07XG5cbmV4cG9ydCBmdW5jdGlvbiBsZWFkZXJzaGlwUmVnZW5QZXJTZWNvbmQoZ2FtZTogR2FtZVNuYXBzaG90LCB1bml0OiBVbml0KSB7XG4gIHJldHVybiBjYW5SZWNlaXZlSGVhbGluZyh1bml0LCBnYW1lKSA/IHF1YWxpZmllZExlYWRlcnNoaXBSZWdlblBlclNlY29uZChnYW1lLCB1bml0KSA6IDA7XG59XG5cbi8vIFRoZSBjYWxsZXIgaGFzIGFscmVhZHkgYXBwbGllZCB0aGUgbWVkaWNhbCB0YXJnZXQgZmlsdGVyLiBLZWVwIG93bmVyIGFuZFxuLy8gdXBncmFkZSBsb29rdXAgbGl2ZSwgYW5kIGxlYXZlIHRoZSBwdWJsaWMgZW50cnkncyBlbGlnaWJpbGl0eSBjaGVjayBpbnRhY3QuXG5mdW5jdGlvbiBxdWFsaWZpZWRMZWFkZXJzaGlwUmVnZW5QZXJTZWNvbmQoZ2FtZTogR2FtZVNuYXBzaG90LCB1bml0OiBVbml0KSB7XG4gIGlmICghaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSB8fCB1bml0LmxldmVsIDw9IDApIHJldHVybiAwO1xuICBjb25zdCB1cGdyYWRlID0gVVBHUkFERV9ERUZTLmxlYWRlcnNoaXA7XG4gIGNvbnN0IG93bmVyU3RhdGUgPSBnYW1lLnBsYXllcnNbdW5pdC5vd25lcl07XG4gIGlmICghb3duZXJTdGF0ZSkgdGhyb3cgbmV3IEVycm9yKGBNaXNzaW5nIHBsYXllciBzdGF0ZSBmb3IgJHt1bml0Lm93bmVyfWApO1xuICBjb25zdCBsZXZlbCA9IG93bmVyU3RhdGUudXBncmFkZXMubGVhZGVyc2hpcCA/PyAwO1xuICBjb25zdCBsZXZlbERlZiA9IHVwZ3JhZGUubGV2ZWxzW2xldmVsIC0gMV07XG4gIHJldHVybiBsZXZlbERlZj8udmV0ZXJhblJlZ2VuQnlTdGFycz8uW01hdGgubWluKE1BWF9VUEdSQURFX0xFVkVMLCB1bml0LmxldmVsKSAtIDFdID8/IDA7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZU1lcmNlbmFyeUNhbXBzKGdhbWU6IEdhbWUpIHtcbiAgZm9yIChjb25zdCBjYW1wIG9mIGdhbWUubWVyY2VuYXJ5Q2FtcHMpIHtcbiAgICBjYW1wLmNvb2xkb3duUmVtYWluaW5nID0gTWF0aC5tYXgoMCwgY2FtcC5jb29sZG93blJlbWFpbmluZyAtIDEpO1xuICB9XG59XG5cbi8qKiBCb3RoIG9yZGluYXJ5IHNob3RzIGFuZCB3ZWFwb24gc2tpbGxzIHVzZSB0aGUgZml0dGluZydzIG93biByZXRpY2xlLiAqL1xuZnVuY3Rpb24gYWltTW91bnRlZFdlYXBvbihnYW1lOkdhbWUsc2hpcDpVbml0LGl0ZW06V29ybGRJdGVtLHBvaW50Ont4Om51bWJlcjt5Om51bWJlcn0scG9zZT1tb3VudGVkV2VhcG9uUG9zZShzaGlwLGl0ZW0pISkge1xuICBjb25zdCBkZWY9U0hJUF9XRUFQT05TW2l0ZW0ua2luZCBhcyBrZXlvZiB0eXBlb2YgU0hJUF9XRUFQT05TXTtcbiAgY29uc3QgbW91bnQ9c2hpcE1vdW50cyhzaGlwKS5maW5kKG1vdW50PT5tb3VudC5pZD09PWl0ZW0ubW91bnRJZCkhO1xuICAvLyBBIGZpeGVkIGZpdHRpbmcgdHJhdmVscyB3aXRoIGl0cyBkZWNrLiBXb3JsZCBkaXNwbGFjZW1lbnQgbXVzdCBub3QgcmVzZXRcbiAgLy8gaXRzIHJldGljbGUgZXZlcnkgZmV3IHRpY2tzIHdoaWxlIHRoZSBjYXJyeWluZyBodWxsIGlzIG1ha2luZyB3YXkuXG4gIGNvbnN0IHByb3h5PXsuLi5zaGlwLHg6cG9zZS5waXZvdC54LHk6cG9zZS5waXZvdC55LGRlY2s6e3NoaXBJZDpzaGlwLmlkLHg6bW91bnQueCx5Om1vdW50Lnl9LGFpbTppdGVtLmFpbX07XG4gIGNvbnN0IHtuYXZhbDpfaHVsbCwuLi53ZWFwb25CYXNlfT11bml0UnVsZXMoZ2FtZSxzaGlwKTtcbiAgY29uc3QgcmVhZHk9YWltQXQocHJveHksey4uLndlYXBvbkJhc2UsYXR0YWNrRGFtYWdlOmRlZi5kYW1hZ2UsYXR0YWNrUmFuZ2U6ZGVmLnJhbmdlLGFpbVNwZWVkOmRlZi5haW1TcGVlZCx3ZWFwb246ZGVmLndlYXBvbn0scG9pbnQsZ2FtZS50aWNrLHZldGVyYW5BaW1TcGVlZChnYW1lLHNoaXApKTtcbiAgaWYocHJveHkuYWltKWl0ZW0uYWltPXByb3h5LmFpbTtlbHNlIGRlbGV0ZSBpdGVtLmFpbTtcbiAgaWYocHJveHkuZmFjaW5nIT09dW5kZWZpbmVkKWl0ZW0uZmFjaW5nPXByb3h5LmZhY2luZztcbiAgcmV0dXJuIHJlYWR5P3Byb3h5OnVuZGVmaW5lZDtcbn1cbmZ1bmN0aW9uIGZyaWVuZGx5RmlyZUJsb2NrZXJzKGdhbWU6R2FtZSxzaGlwOlVuaXQpe1xuICByZXR1cm4gc2hpcHNJbihnYW1lLnVuaXRzKS5maWx0ZXIob3RoZXI9Pm90aGVyLmlkIT09c2hpcC5pZCAmJiBvdGhlci5ocD4wICYmICFhcmVFbmVteU93bmVycyhnYW1lLHNoaXAub3duZXIsb3RoZXIub3duZXIpKTtcbn1cbmZ1bmN0aW9uIG1vdW50ZWRTaG90Q2xlYXIoc2hpcDpVbml0LGJsb2NrZXJzOnJlYWRvbmx5IFVuaXRbXSk6TW91bnRlZFNob3RDbGVhcnx1bmRlZmluZWR7XG4gIGlmKCFibG9ja2Vycy5sZW5ndGgpcmV0dXJuIHVuZGVmaW5lZDtcbiAgY29uc3QgcG9zZXM9bmV3IE1hcDxudW1iZXIsVW5pdD4oKTtcbiAgcmV0dXJuKGl0ZW0scG9pbnQsaGVhZGluZyk9PntcbiAgICBsZXQgYWltZWQ9cG9zZXMuZ2V0KGhlYWRpbmcpO1xuICAgIGlmKCFhaW1lZCl7YWltZWQ9ey4uLnNoaXAsc2FpbGluZzp7Li4uc2hpcC5zYWlsaW5nISxoZWFkaW5nfX07c2hhcmVTaGlwUHJvZmlsZShzaGlwLGFpbWVkKTtwb3Nlcy5zZXQoaGVhZGluZyxhaW1lZCk7fVxuICAgIHJldHVybiBtb3VudGVkRmlyZUxhbmVDbGVhcihhaW1lZCxpdGVtLHBvaW50LGJsb2NrZXJzKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZU1vdW50ZWRXZWFwb25zKGdhbWU6R2FtZSxzdGFydHM6TWFwPHN0cmluZyx7eDpudW1iZXI7eTpudW1iZXI7aGVhZGluZzpudW1iZXJ9PixkZWZlbnNlczpTaGlwRGVmZW5zZUZyYW1lKXtcbiAgY29uc3QgY3Jvc3Npbmc9Z2FtZS5ib2FyZGluZ0hvbGRzITtcbiAgZm9yKGNvbnN0IHNoaXAgb2Ygc2hpcHNJbihnYW1lLnVuaXRzKSl7XG4gICAgaWYoc2hpcC5ocDw9MCB8fCBpc1N0YWdnZXJlZChzaGlwKSB8fCBpc1N0dW5uZWQoc2hpcCkgfHwgIXNoaXBQcm9maWxlKHNoaXApIHx8IFwiYXZvaWRDb21iYXRcIiBpbiBzaGlwLm9yZGVyICYmIHNoaXAub3JkZXIuYXZvaWRDb21iYXQpY29udGludWU7XG4gICAgY29uc3Qgb3JkZXI9c2hpcC5vcmRlcjtcbiAgICBjb25zdCBibG9ja2Vycz1mcmllbmRseUZpcmVCbG9ja2VycyhnYW1lLHNoaXApO1xuICAgIGNvbnN0IHdlYXBvbnM9aW5zdGFsbGVkV2VhcG9ucyhnYW1lLHNoaXApLG1vdW50cz1zaGlwTW91bnRzKHNoaXApO1xuICAgIGNvbnN0IGFjcXVpc2l0aW9uUmFuZ2U9d2VhcG9ucy5yZWR1Y2UoKHJlYWNoLGl0ZW0pPT57XG4gICAgICBpZigoaXRlbS5kdXJhYmlsaXR5ID8/IDEpPD0wKXJldHVybiByZWFjaDtcbiAgICAgIGNvbnN0IG1vdW50PW1vdW50cy5maW5kKG1vdW50PT5tb3VudC5pZD09PWl0ZW0ubW91bnRJZCk7XG4gICAgICBjb25zdCBkZWY9U0hJUF9XRUFQT05TW2l0ZW0ua2luZCBhcyBrZXlvZiB0eXBlb2YgU0hJUF9XRUFQT05TXTtcbiAgICAgIHJldHVybiBtb3VudCA/IE1hdGgubWF4KHJlYWNoLHZldGVyYW5XZWFwb25SYW5nZShzaGlwLGRlZi5yYW5nZSkrTWF0aC5oeXBvdChtb3VudC54LG1vdW50LnkpKSA6IHJlYWNoO1xuICAgIH0sc2hpcC5hdHRhY2tSYW5nZSk7XG4gICAgY29uc3QgaW50cmluc2ljPXVuaXRSdWxlcyhnYW1lLHNoaXApLmludHJpbnNpY0F0dGFjaztcbiAgICBjb25zdCBvcmRlcmVkPShvcmRlci50eXBlPT09XCJhdHRhY2tcIiB8fCBvcmRlci50eXBlPT09XCJhdHRhY2tNb3ZlXCIpICYmIG9yZGVyLnRhcmdldElkID8gZmluZFN0cmlrZVRhcmdldChnYW1lLG9yZGVyLnRhcmdldElkKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBleHBsaWNpdD1vcmRlci50eXBlPT09J2F0dGFjaycgJiYgb3JkZXIubGVhc2hYPT09dW5kZWZpbmVkO1xuICAgIGNvbnN0IHJlcXVlc3RlZD1kZWZlbnNlcy5nZXQoc2hpcC5pZCk/LnRhcmdldCA/PyAob3JkZXJlZCAmJiAoZXhwbGljaXQgfHwgaXNPYnN0YWNsZShvcmRlcmVkKSB8fCBhdXRvbWF0aWNUYXJnZXRBbGxvd2VkKGdhbWUudW5pdHMsc2hpcC5vd25lcixvcmRlcmVkKSkgPyBvcmRlcmVkIDogdW5kZWZpbmVkKTtcbiAgICAvLyBBY3F1aXJlIGZhciBlbm91Z2ggdG8gaW5jbHVkZSB0aGUgb2Zmc2V0IGJhdHRlcnksIG5vdCBqdXN0IHRoZSBodWxsXG4gICAgLy8gY2VudGVyLiBBY3R1YWwgaGVhZGluZyBhbmQgZmlyaW5nIHN0aWxsIHVzZSBlYWNoIHBpdm90J3Mgb3duIHJhbmdlLlxuICAgIGxldCBmYWNpbmdQb2ludD1vcmRlci50eXBlPT09XCJhaW1cIiA/IG9yZGVyIDogcmVxdWVzdGVkID8/IChbXCJhdHRhY2tNb3ZlXCIsXCJpZGxlXCIsXCJob2xkXCJdLmluY2x1ZGVzKG9yZGVyLnR5cGUpID8gbmVhcmVzdEVuZW15VGFyZ2V0KGdhbWUsc2hpcCxhY3F1aXNpdGlvblJhbmdlKSA6IHVuZGVmaW5lZCk7XG4gICAgaWYoZmFjaW5nUG9pbnQgJiYgXCJvd25lclwiIGluIGZhY2luZ1BvaW50ICYmICFpc09ic3RhY2xlKGZhY2luZ1BvaW50KSlmYWNpbmdQb2ludD1uYXZhbENvbWJhdFRhcmdldChnYW1lLHNoaXAsZmFjaW5nUG9pbnQpO1xuICAgIGNvbnN0IG9yaWVudEh1bGwgPSBbJ2lkbGUnLCAnaG9sZCcsICdhaW0nXS5pbmNsdWRlcyhvcmRlci50eXBlKVxuICAgICAgfHwgKG9yZGVyLnR5cGUgPT09ICdhdHRhY2snIHx8IG9yZGVyLnR5cGUgPT09ICdhdHRhY2tNb3ZlJykgJiYgc2hpcENhblR1cm5Gb3JBdHRhY2soc2hpcCk7XG4gICAgaWYoIWNyb3NzaW5nLmhhcyhzaGlwLmlkKSAmJiBmYWNpbmdQb2ludCAmJiAoc2hpcENhblR1cm5Gb3JBdHRhY2soc2hpcCkgfHwgc3RyaWtlR2FwKHNoaXAsZmFjaW5nUG9pbnQpPD1hY3F1aXNpdGlvblJhbmdlKSAmJiBvcmllbnRIdWxsKSB7XG4gICAgICB0dXJuU2hpcFRvd2FyZChzaGlwLGJlc3RGaXJpbmdIZWFkaW5nKGdhbWUsc2hpcCxmYWNpbmdQb2ludCwwLG1vdW50ZWRTaG90Q2xlYXIoc2hpcCxibG9ja2VycykpLGdhbWUubWFwLGdhbWUudW5pdHMsTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2Uoc3RhcnRzLmdldChzaGlwLmlkKSEuaGVhZGluZyxzaGlwLnNhaWxpbmchLmhlYWRpbmcpKSk7XG4gICAgfVxuICAgIGZvcihjb25zdCBpdGVtIG9mIHdlYXBvbnMpe1xuICAgICAgaWYoKGl0ZW0uZHVyYWJpbGl0eSA/PyAxKTw9MCB8fCBpdGVtLmNvb2xkb3duUmVtYWluaW5nPjAgfHwgaXRlbS5tb3VudElkPT09XCJib3dcIiAmJiAhaW50cmluc2ljICYmIHNoaXAuY29vbGRvd24+MCljb250aW51ZTtcbiAgICAgIGNvbnN0IGRlZj1TSElQX1dFQVBPTlNbaXRlbS5raW5kIGFzIGtleW9mIHR5cGVvZiBTSElQX1dFQVBPTlNdLHBvc2U9bW91bnRlZFdlYXBvblBvc2Uoc2hpcCxpdGVtKSE7XG4gICAgICBjb25zdCByYW5nZT12ZXRlcmFuV2VhcG9uUmFuZ2Uoc2hpcCxkZWYucmFuZ2UpO1xuICAgICAgY29uc3QgY2FuU2hvb3Q9KGNhbmRpZGF0ZTpVbml0fEJ1aWxkaW5nfE9ic3RhY2xlKT0+e1xuICAgICAgICBjb25zdCBwb2ludD1tb3VudGVkVGFyZ2V0UG9pbnQoZ2FtZSxzaGlwLGl0ZW0sY2FuZGlkYXRlLHBvc2UpLGdhcD1kaXN0YW5jZShwb3NlLnBpdm90LHBvaW50KTtcbiAgICAgICAgcmV0dXJuIHNoaXBHdW5DYW5BaW0oc2hpcCxpdGVtLHBvaW50KSAmJiBnYXA8PXJhbmdlICYmIGdhcD49KGRlZi53ZWFwb24ubWluUmFuZ2U/PzApXG4gICAgICAgICAgJiYgKCFibG9ja2Vycy5sZW5ndGggfHwgbW91bnRlZEZpcmVMYW5lQ2xlYXIoc2hpcCxpdGVtLHBvaW50LGJsb2NrZXJzKSk7XG4gICAgICB9O1xuICAgICAgY29uc3QgcHJlZmVycmVkPXJlcXVlc3RlZCAmJiAhaXNPYnN0YWNsZShyZXF1ZXN0ZWQpID8gbmF2YWxDb21iYXRUYXJnZXQoZ2FtZSxzaGlwLHJlcXVlc3RlZCkgOiByZXF1ZXN0ZWQ7XG4gICAgICAvLyBUaGUgb3JkZXJlZCBlbmVteSByZW1haW5zIHRoZSBuYXZpZ2F0b3IncyBvYmplY3RpdmUuIEEgZ3VuIHdoaWNoXG4gICAgICAvLyBjYW5ub3QgYmVhciBvbiBpdCBtYXkgc3RpbGwgZGVmZW5kIGFnYWluc3QgYW5vdGhlciByZWFjaGFibGUgZW5lbXkuXG4gICAgICBjb25zdCB0YXJnZXQ9cHJlZmVycmVkICYmIGFyZUVuZW15T3duZXJzKGdhbWUsc2hpcC5vd25lcixwcmVmZXJyZWQub3duZXIpICYmIGNhblNob290KHByZWZlcnJlZCkgPyBwcmVmZXJyZWRcbiAgICAgICAgOiBuZWFyZXN0RW5lbXlUYXJnZXRGcm9tUG9pbnQoZ2FtZSxzaGlwLm93bmVyLHBvc2UucGl2b3QscmFuZ2Usc2hpcCxjYW5kaWRhdGU9PmNhblNob290KGNhbmRpZGF0ZSkgJiYgKCFbXCJtb3ZlXCIsXCJ1bmxvYWRcIixcImZvbGxvd1wiXS5pbmNsdWRlcyhvcmRlci50eXBlKSB8fCBjYW5kaWRhdGUuYXR0YWNrRGFtYWdlPjApKTtcbiAgICAgIGNvbnN0IGFpbVRhcmdldD1vcmRlci50eXBlPT09XCJhaW1cIiAmJiAhdGFyZ2V0ID8gb3JkZXIgOiB0YXJnZXQ7XG4gICAgICBjb25zdCBwb2ludD10YXJnZXQgPyBtb3VudGVkVGFyZ2V0UG9pbnQoZ2FtZSxzaGlwLGl0ZW0sdGFyZ2V0LHBvc2UpIDogYWltVGFyZ2V0ICYmIHN0cmlrZVBvaW50KHBvc2UucGl2b3QsYWltVGFyZ2V0KTtcbiAgICAgIGlmKCFwb2ludCB8fCAhc2hpcEd1bkNhbkFpbShzaGlwLGl0ZW0scG9pbnQpIHx8IGRpc3RhbmNlKHBvc2UucGl2b3QscG9pbnQpPnJhbmdlIHx8IGRlZi53ZWFwb24ubWluUmFuZ2UgJiYgZGlzdGFuY2UocG9zZS5waXZvdCxwb2ludCk8ZGVmLndlYXBvbi5taW5SYW5nZSljb250aW51ZTtcbiAgICAgIGNvbnN0IHByb3h5PWFpbU1vdW50ZWRXZWFwb24oZ2FtZSxzaGlwLGl0ZW0scG9pbnQscG9zZSk7XG4gICAgICBpZighcHJveHkgfHwgIXRhcmdldCljb250aW51ZTtcbiAgICAgIGNvbnN0IGxhdW5jaFBvc2U9bW91bnRlZFdlYXBvblBvc2Uoc2hpcCxpdGVtKSE7XG4gICAgICBpZihibG9ja2Vycy5sZW5ndGggJiYgIXNoaXBGaXJlTGFuZUNsZWFyKGxhdW5jaFBvc2UubXV6emxlLHBvaW50LGRlZi53ZWFwb24sYmxvY2tlcnMpKWNvbnRpbnVlO1xuICAgICAgZmlyZVdlYXBvbihnYW1lLHNoaXAsdGFyZ2V0LE1hdGgucm91bmQoZGVmLmRhbWFnZSoobm9uU3RhclVuaXRTdGF0cyhnYW1lLHNoaXApLmF0dGFja0RhbWFnZS9NYXRoLm1heCgxLHdlYXBvblJ1bGVzKGdhbWUsc2hpcCkuYXR0YWNrRGFtYWdlKSkqb3V0Z29pbmdEYW1hZ2VNdWx0aXBsaWVyKGdhbWUsc2hpcCkpLGRlZi53ZWFwb24scmFuZ2Use30sdGFyZ2V0LmlkLHtpdGVtLHBvc2U6bGF1bmNoUG9zZSxhaW1Qb2ludDpwb2ludH0pO1xuICAgICAgbWFya0FpbVNob3QocHJveHkpO2l0ZW0uY29vbGRvd25SZW1haW5pbmc9YXR0YWNrQ29vbGRvd25PZihnYW1lLHNoaXAsZGVmLmNvb2xkb3duKTtpZihpdGVtLm1vdW50SWQ9PT1cImJvd1wiICYmICFpbnRyaW5zaWMpc2hpcC5jb29sZG93bj1pdGVtLmNvb2xkb3duUmVtYWluaW5nO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiByZWZyZXNoRXF1aXBtZW50TWFzcyhnYW1lOkdhbWUsdW5pdHM6cmVhZG9ubHkgVW5pdFtdPWdhbWUudW5pdHMpe2Zvcihjb25zdCB1bml0IG9mIHVuaXRzKXt1bml0LmdlYXJNYXNzPXVuaXRJdGVtTWFzcyhnYW1lLHVuaXQpO2lmKHNoaXBQcm9maWxlKHVuaXQpKXVuaXQuaG9sZE1hc3M9c2hpcEl0ZW1NYXNzKGdhbWUsdW5pdCk7fX1cblxuZnVuY3Rpb24gdXBkYXRlSXRlbXMoZ2FtZTogR2FtZSkge1xuICAvLyBUaGUgY2FycmllcnMgYSByaW5nIGhhcyBoZWFsZWQgdGhpcyB0aWNrOiBhIHNlY29uZCByaW5nIGhlYWxzIG5vIG1vcmUgKHNlZSBAQEBzaG9wLWdvb2RzKS5cbiAgbGV0IHJpbmdlZDogU2V0PHN0cmluZz4gfCB1bmRlZmluZWQ7XG4gIGNvbnN0IHVuaXRzQnlJZCA9IGdhbWUuZW50aXR5QnlJZCE7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBnYW1lLml0ZW1zKSB7XG4gICAgaWYoaXRlbS5jb29sZG93blJlbWFpbmluZz4wKWl0ZW0uY29vbGRvd25SZW1haW5pbmcgPSBNYXRoLm1heCgwLCBpdGVtLmNvb2xkb3duUmVtYWluaW5nIC0gMSk7XG4gICAgY29uc3QgZW50aXR5ID0gaXRlbS5jYXJyaWVySWQgPyB1bml0c0J5SWQuZ2V0KGl0ZW0uY2FycmllcklkKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBjYXJyaWVyPWVudGl0eSAmJiBpc1VuaXQoZW50aXR5KSA/IGVudGl0eSA6IHVuZGVmaW5lZDtcbiAgICBpZihpdGVtLnNoaXBJZCl7Y29uc3Qgc2hpcD11bml0c0J5SWQuZ2V0KGl0ZW0uc2hpcElkKTtpZihzaGlwKXtpdGVtLng9c2hpcC54O2l0ZW0ueT1zaGlwLnk7fWNvbnRpbnVlO31cbiAgICBpZiAoIWNhcnJpZXIpIGNvbnRpbnVlO1xuICAgIGl0ZW0ueCA9IGNhcnJpZXIueDtcbiAgICBpdGVtLnkgPSBjYXJyaWVyLnk7XG4gICAgaWYgKCFpc0luQ2FiaW4oY2FycmllcikgJiYgaXRlbS5raW5kID09PSBcImZsYW1lQ2xvYWtcIiAmJiBpdGVtRXF1aXBwZWQoZ2FtZSxjYXJyaWVyLGl0ZW0pKSBhcHBseUZsYW1lQ2xvYWsoZ2FtZSwgY2FycmllciwgaXRlbSk7XG4gICAgaWYgKGNhblJlY2VpdmVIZWFsaW5nKGNhcnJpZXIsIGdhbWUpICYmIGl0ZW0ua2luZCA9PT0gXCJyZWdlblJpbmdcIiAmJiBpdGVtRXF1aXBwZWQoZ2FtZSxjYXJyaWVyLGl0ZW0pICYmIGNhcnJpZXIuaHAgPCBjYXJyaWVyLm1heEhwICYmICFyaW5nZWQ/LmhhcyhjYXJyaWVyLmlkKSkge1xuICAgICAgY2Fycmllci5ocCA9IE1hdGgubWluKGNhcnJpZXIubWF4SHAsIGNhcnJpZXIuaHAgKyBwZXJUaWNrKFJJTkdfUkVHRU5fUEVSX1NFQ09ORCkpO1xuICAgICAgKHJpbmdlZCA/Pz0gbmV3IFNldCgpKS5hZGQoY2Fycmllci5pZCk7XG4gICAgfVxuICAgIGlmICghaXNJbkNhYmluKGNhcnJpZXIpICYmIGNhcnJpZXIub3duZXIgPT09IFwibmV1dHJhbFwiICYmIGl0ZW1FcXVpcHBlZChnYW1lLGNhcnJpZXIsaXRlbSkpIGFjdGl2YXRlTmV1dHJhbEl0ZW0oZ2FtZSwgY2FycmllciwgaXRlbSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gdXBkYXRlUmVzb3VyY2VzKGdhbWU6IEdhbWUpIHtcbiAgZm9yIChjb25zdCByZXNvdXJjZSBvZiBnYW1lLnJlc291cmNlcykge1xuICAgIHJlc291cmNlLmhhcnZlc3RDb29sZG93blJlbWFpbmluZyA9IE1hdGgubWF4KDAsIChyZXNvdXJjZS5oYXJ2ZXN0Q29vbGRvd25SZW1haW5pbmcgPz8gMCkgLSAxKTtcbiAgfVxufVxuXG4vLyBUaGUgdW5pdHMgdW5kZXIgd2F5IHRvIGJvYXJkIGEgdHJhbnNwb3J0LCBhbmQgdGhlIHRyYW5zcG9ydHMgdW5kZXIgd2F5IHRvIHVubG9hZCwgYXMgdXBkYXRlVW5pdHMgZm91bmQgdGhlbTogd2hhdFxuLy8gZmVycnlVbml0cyBoYXMgdG8gbG9vayBhdCAoc2VlIEBAQHRyYW5zcG9ydCksIHNvIHRoYXQgbm8gb3RoZXIgcGFzcyBsb29rcyBvdmVyIGV2ZXJ5IHVuaXQgZm9yIHRoZW0uXG50eXBlIEZlcnJ5ID0geyBib2FyZGluZzogVW5pdFtdOyB1bmxvYWRpbmc6IFVuaXRbXSB9O1xuXG5mdW5jdGlvbiB1cGRhdGVVbml0cyhnYW1lOiBHYW1lLCBkZWZlbnNlczogU2hpcERlZmVuc2VGcmFtZSwgbmF2YWxGcmFtZTogYm9vbGVhbiwgZW1wdHlWZXRlcmFuRnJhbWU6IGJvb2xlYW4pOiBGZXJyeSB8IHVuZGVmaW5lZCB7XG4gIGdhbWUudmV0ZXJhbkF1dG9jYXN0RnJhbWUgPSBlbXB0eVZldGVyYW5GcmFtZSA/IHVuZGVmaW5lZCA6IHt9O1xuICBjb25zdCBhdXRvY2FzdEZyYW1lID0gZ2FtZS50aWNrICUgQVVUT0NBU1RfRVZFUllfVElDS1MgPT09IDA7XG4gIGNvbnN0IGNhYmluTW92ZW1lbnRGcmFtZSA9IGhhc0NhYmluQ3Jld01vdmVtZW50RnJhbWUoZ2FtZSk7XG4gIGxldCBmZXJyeTogRmVycnkgfCB1bmRlZmluZWQ7XG4gIGNvbnN0IHZlc3NlbHM9bmF2YWxGcmFtZSA/IHNoaXBzSW4oZ2FtZS51bml0cykgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IG9yZGVyZWQ9dmVzc2Vscz8ubGVuZ3RoID8gWy4uLnZlc3NlbHMsLi4uZ2FtZS51bml0cy5maWx0ZXIodW5pdD0+IWlzU2hpcEtpbmQodW5pdC5raW5kKSldIDogZ2FtZS51bml0cztcbiAgLy8gU3VtbW9uaW5nIG9ubHkgYXBwZW5kcyBkdXJpbmcgdW5pdCB1cGRhdGVzLiBDYXB0dXJlIHRoZSBpbml0aWFsIGxlbmd0aCBzb1xuICAvLyBuZXdseSBib3JuIGJvZGllcyBmaXJzdCBhY3QgbmV4dCB0aWNrLCBhcyB3aXRoIHRoZSBzaGlwcy1maXJzdCBzbmFwc2hvdC5cbiAgY29uc3QgY291bnQgPSBvcmRlcmVkLmxlbmd0aDtcbiAgY29uc3Qgc291cmNlQ291bnQgPSBnYW1lLnVuaXRzLmxlbmd0aDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudDsgaSArPSAxKSB7XG4gICAgY29uc3QgdW5pdCA9IG9yZGVyZWRbaV0hO1xuICAgIGNvbnN0IG5hdmFsVW5pdEZyYW1lID0gbmF2YWxGcmFtZSB8fCBnYW1lLnVuaXRzLmxlbmd0aCAhPT0gc291cmNlQ291bnQ7XG4gICAgaWYgKHVuaXQuc2FpbGluZz8ucHVyc3VpdCAmJiAhWydhdHRhY2snLCAnYXR0YWNrTW92ZScsICdmb2xsb3cnXS5pbmNsdWRlcyh1bml0Lm9yZGVyLnR5cGUpICYmICFkZWZlbnNlcy5oYXModW5pdC5pZCkpIGRlbGV0ZSB1bml0LnNhaWxpbmcucHVyc3VpdDtcbiAgICBpZih1bml0LmFpbSlpbnZhbGlkYXRlTW92ZWRBaW0odW5pdCwgd2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCkpO1xuICAgIHVuaXQuY29vbGRvd24gPSBNYXRoLm1heCgwLCB1bml0LmNvb2xkb3duIC0gMSk7XG4gICAgaWYgKHVuaXQuYWJpbGl0eUNvb2xkb3ducykge1xuICAgICAgY29uc3QgbGVmdCA9IHRpY2tlZEFiaWxpdHlDb29sZG93bnModW5pdC5hYmlsaXR5Q29vbGRvd25zKTtcbiAgICAgIGlmIChsZWZ0KSB1bml0LmFiaWxpdHlDb29sZG93bnMgPSBsZWZ0O1xuICAgICAgZWxzZSB1bml0LmFiaWxpdHlDb29sZG93bnMgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChuYXZhbFVuaXRGcmFtZSAmJiBpc0luQ2FiaW4odW5pdClcbiAgICAgIHx8IChuYXZhbFVuaXRGcmFtZSB8fCBjYWJpbk1vdmVtZW50RnJhbWUpICYmIGNhYmluQ3Jld01vdmVkVGhpc1RpY2soZ2FtZSx1bml0KSkgY29udGludWU7XG4gICAgaWYgKHVuaXQub3JkZXIudHlwZSA9PT0gJ2VudGVyQ2FiaW4nKSB7XG4gICAgICBpZiAoIWlzU3RhZ2dlcmVkKHVuaXQpICYmICFpc1N0dW5uZWQodW5pdCkpIGVudGVyQ2FiaW5TdGVwKGdhbWUsdW5pdCxzdGF0dXNQYWNlKHVuaXQpLG90aGVyPT5pc1N0YWdnZXJlZChvdGhlcil8fGlzU3R1bm5lZChvdGhlcik/MDpzdGF0dXNQYWNlKG90aGVyKSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgLy8gQSBjaGFyZ2luZyByaWRlciByaWRlcyBpdHMgb3duIHNsaWRlIChzZWUgQEBAY2hhcmdlKTsgYW55IG90aGVyIHVuaXQgb2ZmIGl0cyBmZWV0IChzZWUgQEBAcHVzaCkgbmVpdGhlciB3YWxrcyxcbiAgICAvLyBzdHJpa2VzIG5vciBjYXN0cywgYW5kIGl0cyBvcmRlciB3YWl0cyBmb3IgaXQuXG4gICAgaWYgKHVuaXQub3JkZXIudHlwZSAhPT0gXCJjaGFyZ2VcIikge1xuICAgICAgaWYgKCh1bml0LnB1c2hYICE9PSB1bmRlZmluZWQgJiYgaXNTdGFnZ2VyZWQodW5pdCkpIHx8ICh1bml0LmVmZmVjdHMubGVuZ3RoICE9PSAwICYmIGlzU3R1bm5lZCh1bml0KSkpIGNvbnRpbnVlO1xuICAgICAgLy8gQSBjb21tYW5kZWQgbW92ZSBjYW5ub3QgYWN0aXZhdGUgYSBxdWV1ZSwgbGVhc2ggYSBwbGF5ZXIgdW5pdCwgcmVwYWlyXG4gICAgICAvLyBhIGRlY2sgb3IgYXV0b2Nhc3QuIFJ1biBpdHMgZXhpc3RpbmcgbW92ZW1lbnQgYWZ0ZXIgdGhlIGNvbW1vbiBjbG9ja3NcbiAgICAgIC8vIGFuZCBjb250cm9sIGVmZmVjdHMsIGluY2x1ZGluZyBleGFjdCBhcnJpdmFsIGFuZCBxdWV1ZWQgaGVsbSBjb3Vyc2VzLlxuICAgICAgaWYgKHVuaXQub3duZXIgIT09IFwibmV1dHJhbFwiICYmIHVuaXQub3JkZXIudHlwZSA9PT0gXCJtb3ZlXCIpIHtcbiAgICAgICAgYWR2YW5jZU1vdmVPcmRlcihnYW1lLCB1bml0LCB1bml0Lm9yZGVyLCBuYXZhbFVuaXRGcmFtZSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgYWN0aXZhdGVRdWV1ZWRPcmRlcihnYW1lLHVuaXQpO1xuICAgICAgaWYgKHVwZGF0ZU5ldXRyYWxMZWFzaChnYW1lLCB1bml0KSkgY29udGludWU7XG4gICAgICBpZiAobmF2YWxVbml0RnJhbWUgJiYgYXV0b1JlcGFpckRlY2tTaGlwKGdhbWUsIHVuaXQpKSBjb250aW51ZTtcbiAgICAgIGlmIChhdXRvY2FzdEZyYW1lKSBhdXRvY2FzdFN0ZXAoZ2FtZSwgdW5pdCk7XG4gICAgfVxuICAgIHN3aXRjaCAodW5pdC5vcmRlci50eXBlKSB7XG4gICAgICBjYXNlIFwiY2hhcmdlXCI6XG4gICAgICAgIHVwZGF0ZUNoYXJnZU9yZGVyKGdhbWUsIHVuaXQpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgXCJtb3ZlXCI6XG4gICAgICAgIGFkdmFuY2VNb3ZlT3JkZXIoZ2FtZSwgdW5pdCwgdW5pdC5vcmRlciwgbmF2YWxVbml0RnJhbWUpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgXCJhdHRhY2tNb3ZlXCI6XG4gICAgICAgIHVwZGF0ZUF0dGFja01vdmVPcmRlcihnYW1lLCB1bml0LCBuYXZhbFVuaXRGcmFtZSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSBcImhvbGRcIjpcbiAgICAgICAgdXBkYXRlSG9sZE9yZGVyKGdhbWUsIHVuaXQsIG5hdmFsVW5pdEZyYW1lKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwiYWltXCI6XG4gICAgICAgIHVwZGF0ZUFpbU9yZGVyKGdhbWUsIHVuaXQsIG5hdmFsVW5pdEZyYW1lKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwiZm9sbG93XCI6XG4gICAgICAgIHVwZGF0ZUZvbGxvd09yZGVyKGdhbWUsIHVuaXQpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgXCJjYXN0XCI6XG4gICAgICAgIHVwZGF0ZUNhc3RPcmRlcihnYW1lLCB1bml0KTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwiYXR0YWNrXCI6XG4gICAgICAgIHVwZGF0ZUF0dGFja09yZGVyKGdhbWUsIHVuaXQsIG5hdmFsVW5pdEZyYW1lKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwibWluZVwiOlxuICAgICAgICB1cGRhdGVNaW5lT3JkZXIoZ2FtZSwgdW5pdCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSBcImJ1aWxkXCI6XG4gICAgICAgIHVwZGF0ZUJ1aWxkT3JkZXIoZ2FtZSwgdW5pdCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSBcInJlcGFpclwiOlxuICAgICAgICB1cGRhdGVSZXBhaXJPcmRlcihnYW1lLCB1bml0KTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwicmVwYWlyVW5pdFwiOiBjYXNlIFwicmVwYWlyU2hpcFwiOlxuICAgICAgICB1cGRhdGVVbml0UmVwYWlyT3JkZXIoZ2FtZSwgdW5pdCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSBcInBpY2t1cEl0ZW1cIjpcbiAgICAgICAgdXBkYXRlUGlja3VwSXRlbU9yZGVyKGdhbWUsIHVuaXQpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgXCJib2FyZFwiOlxuICAgICAgICB1cGRhdGVCb2FyZE9yZGVyKGdhbWUsIHVuaXQpO1xuICAgICAgICAoZmVycnkgPz89IHsgYm9hcmRpbmc6IFtdLCB1bmxvYWRpbmc6IFtdIH0pLmJvYXJkaW5nLnB1c2godW5pdCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSBcImJvYXJkU2hpcFwiOlxuICAgICAgICB1cGRhdGVCb2FyZFNoaXBPcmRlcihnYW1lLCB1bml0KTtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIFwidW5sb2FkXCI6XG4gICAgICAgIG1vdmVUb3dhcmQodW5pdCwgdW5pdC5vcmRlci54LCB1bml0Lm9yZGVyLnksIGdhbWUubWFwLCBnYW1lLnVuaXRzLCBuYXZhbFVuaXRGcmFtZSk7XG4gICAgICAgIChmZXJyeSA/Pz0geyBib2FyZGluZzogW10sIHVubG9hZGluZzogW10gfSkudW5sb2FkaW5nLnB1c2godW5pdCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAodW5pdC5raW5kID09PSBcIndvcmtlclwiICYmICF1bml0LmRlY2sgJiYgdXBkYXRlQXV0b1JlcGFpcihnYW1lLCB1bml0KSkgY29udGludWU7XG4gICAgaWYobmF2YWxVbml0RnJhbWUgJiYgY29tYmF0SHVsbCh1bml0KSAmJiB1bml0Lm93bmVyIT09J25ldXRyYWwnKSB7XG4gICAgICBjb25zdCBkZWZlbnNlPWRlZmVuc2VzLmdldCh1bml0LmlkKTtcbiAgICAgIGlmKGRlZmVuc2U/LnRhcmdldCl7XG4gICAgICAgIGNvbnN0IHRhcmdldD1uYXZhbENvbWJhdFRhcmdldChnYW1lLHVuaXQsZGVmZW5zZS50YXJnZXQpO1xuICAgICAgICBuYXZpZ2F0ZVNoaXBBdHRhY2soZ2FtZSx1bml0LHRhcmdldCk7XG4gICAgICAgIGlmKHVuaXRSdWxlcyhnYW1lLHVuaXQpLmludHJpbnNpY0F0dGFjayAmJiB1bml0LmNvb2xkb3duPT09MCAmJiB0YXJnZXRHYXAodW5pdCx0YXJnZXQpPD11bml0LmF0dGFja1JhbmdlXG4gICAgICAgICAgJiYgYWltQXQodW5pdCx3ZWFwb25SdWxlcyhnYW1lLHVuaXQpLHN0cmlrZVBvaW50KHVuaXQsdGFyZ2V0KSxnYW1lLnRpY2ssdmV0ZXJhbkFpbVNwZWVkKGdhbWUsdW5pdCkpKXtcbiAgICAgICAgICBhcHBseVdlYXBvbkF0dGFjayhnYW1lLHVuaXQsdGFyZ2V0LE1hdGgubWF4KDEsTWF0aC5yb3VuZCh1bml0LmF0dGFja0RhbWFnZSpvdXRnb2luZ0RhbWFnZU11bHRpcGxpZXIoZ2FtZSx1bml0KSkpLHVuaXQuYXR0YWNrUmFuZ2UpO1xuICAgICAgICAgIG1hcmtBaW1TaG90KHVuaXQpO3VuaXQuY29vbGRvd249YXR0YWNrQ29vbGRvd25PZihnYW1lLHVuaXQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBlbHNlIGlmKGRlZmVuc2U/LnJldHVyblRvKW1vdmVUb3dhcmQodW5pdCxkZWZlbnNlLnJldHVyblRvLngsZGVmZW5zZS5yZXR1cm5Uby55LGdhbWUubWFwLGdhbWUudW5pdHMpO1xuICAgICAgZWxzZSB1cGRhdGVIb2xkT3JkZXIoZ2FtZSx1bml0KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZihuYXZhbFVuaXRGcmFtZSAmJiBzaGlwUHJvZmlsZSh1bml0KSljb250aW51ZTtcbiAgICBpZiAodW5pdC5raW5kICE9PSBcIndvcmtlclwiKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBuZWFyZXN0RW5lbXlUYXJnZXQoZ2FtZSwgdW5pdCwgdW5pdC5vd25lciA9PT0gXCJuZXV0cmFsXCIgPyAxNTAgOiBBVVRPX0FDUVVJUkVfUkFOR0UsIG5hdmFsVW5pdEZyYW1lKTtcbiAgICAgIGlmICh0YXJnZXQpIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiYXR0YWNrXCIsIHRhcmdldElkOiB0YXJnZXQuaWQsIGxlYXNoWDogdW5pdC54LCBsZWFzaFk6IHVuaXQueSB9O1xuICAgIH1cblxuICB9XG4gIHJldHVybiBmZXJyeTtcbn1cblxuZnVuY3Rpb24gZGVja1BvaW50T3JkZXIoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgb3JkZXI6IEV4dHJhY3Q8VW5pdE9yZGVyLCB7IHR5cGU6IFwibW92ZVwiIHwgXCJhdHRhY2tNb3ZlXCIgfT4pOiBVbml0T3JkZXIge1xuICAvLyBBIHdhdGVyIGRlc3RpbmF0aW9uIHVuZGVyIGFub3RoZXIgaHVsbCBpcyBzdGlsbCB3YXRlciBmb3IgYSBzaGlwLiBPbmx5XG4gIC8vIHdhbGtpbmcgYm9kaWVzIGNhbiBlbnRlciBhIGRlY2sgb3IgZm9sbG93IGl0cyBtb3ZpbmcgbG9jYWwgY29vcmRpbmF0ZXMuXG4gIGlmICh1bml0TW92ZXIodW5pdC5raW5kKSAhPT0gXCJsYW5kXCIpIHJldHVybiBvcmRlcjtcbiAgY29uc3Qgc2hpcD1nYW1lLnVuaXRzLmZpbmQoc2hpcD0+c2hpcFByb2ZpbGUoc2hpcCkgJiYgY2lyY2xlSW5Qb2x5Z29uKHdvcmxkVG9Mb2NhbChzaGlwLG9yZGVyKSwwLHNoaXBQcm9maWxlKHNoaXApIS5odWxsKSlcbjtcbiAgcmV0dXJuIHNoaXAgPyB7Li4ub3JkZXIsZGVja1BvaW50OndvcmxkVG9Mb2NhbChzaGlwLG9yZGVyKSxkZWNrU2hpcElkOnNoaXAuaWR9IDogb3JkZXI7XG59XG5cbi8qKiBBIGRlc3RpbmF0aW9uIG9uIGFueSBkZWNrIGZvbGxvd3MgdGhhdCBodWxsOyBhIHNob3JlIGRlc3RpbmF0aW9uIHN0YXlzIGluIHdvcmxkIHNwYWNlLiAqL1xuZnVuY3Rpb24gZGVja0dvYWwodW5pdDogVW5pdCwgc2hpcDogVW5pdCB8IHVuZGVmaW5lZCwgZ29hbDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCB1bml0czogcmVhZG9ubHkgVW5pdFtdKSB7XG4gIGNvbnN0IG9yZGVyPXVuaXQub3JkZXI7XG4gIGlmKChvcmRlci50eXBlIT09XCJtb3ZlXCIgJiYgb3JkZXIudHlwZSE9PVwiYXR0YWNrTW92ZVwiKSB8fCAhb3JkZXIuZGVja1BvaW50IHx8IG9yZGVyLnghPT1nb2FsLnggfHwgb3JkZXIueSE9PWdvYWwueSlyZXR1cm4gZ29hbDtcbiAgY29uc3QgcGFyZW50PXVuaXRzLmZpbmQodW5pdD0+dW5pdC5pZD09PShvcmRlci5kZWNrU2hpcElkID8/IHNoaXA/LmlkKSk7XG4gIHJldHVybiBwYXJlbnQgPyBsb2NhbFRvV29ybGQocGFyZW50LG9yZGVyLmRlY2tQb2ludCkgOiBnb2FsO1xufVxuXG5mdW5jdGlvbiBhZHZhbmNlTW92ZU9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIG9yZGVyOiBFeHRyYWN0PFVuaXRPcmRlciwgeyB0eXBlOiBcIm1vdmVcIiB9PiwgbmF2YWxGcmFtZTogYm9vbGVhbikge1xuICBpZiAodW5pdC5zYWlsaW5nICYmIGZvbGxvd1F1ZXVlZFNoaXBDb3Vyc2UodW5pdCwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIHN0YXR1c1BhY2UodW5pdCkpKSByZXR1cm47XG4gIG1vdmVUb3dhcmQodW5pdCwgb3JkZXIueCwgb3JkZXIueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIG5hdmFsRnJhbWUpO1xuICBpZiAod2Fsa0VuZGVkKGdhbWUsIHVuaXQsIG9yZGVyLCBNT1ZFX09SREVSX0FSUklWQUxfUkFOR0UpKSBhcnJpdmUodW5pdCwgb3JkZXIpO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVTaGlwT3duZXJzaGlwKGdhbWU6R2FtZSkge1xuICBsZXQgY2hhbmdlZD1mYWxzZTtcbiAgZm9yKGNvbnN0IHNoaXAgb2Ygc2hpcHNJbihnYW1lLnVuaXRzKSl7XG4gICAgY29uc3QgY3Jldz1zaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLHNoaXApLmZpbHRlcih1bml0PT51bml0LmhwPjApO1xuICAgIGlmKCFjcmV3Lmxlbmd0aCB8fCBjcmV3LnNvbWUodW5pdD0+IWFyZUVuZW15T3duZXJzKGdhbWUsc2hpcC5vd25lcix1bml0Lm93bmVyKSkpY29udGludWU7XG4gICAgY29uc3Qgb2NjdXBhbnRzPWNyZXcuZmlsdGVyKHVuaXQ9PmlzUGxheWVySWQodW5pdC5vd25lcikpLnNvcnQoKGEsYik9PmEuaWQ8Yi5pZD8tMTphLmlkPmIuaWQ/MTowKTtcbiAgICBjb25zdCBvd25lcj1vY2N1cGFudHNbMF0/Lm93bmVyO1xuICAgIGlmKCFvd25lciB8fCBvY2N1cGFudHMuc29tZSh1bml0PT5hcmVFbmVteU93bmVycyhnYW1lLG93bmVyLHVuaXQub3duZXIpKSljb250aW51ZTtcbiAgICBzaGlwLm93bmVyPW93bmVyO3NoaXAub3JkZXI9e3R5cGU6XCJpZGxlXCJ9O3NoaXAub3JkZXJRdWV1ZT1bXTtzaGlwLmFpbT11bmRlZmluZWQ7XG4gICAgaWYoc2hpcC5zYWlsaW5nKXtzaGlwLnNhaWxpbmcuc3BlZWQ9MDtzaGlwLnNhaWxpbmcucm91dGU9dW5kZWZpbmVkO2RlbGV0ZSBzaGlwLnNhaWxpbmcucHVyc3VpdDtjYW5jZWxTaGlwUGxhbm5pbmdKb2Ioc2hpcCk7fVxuICAgIHJlZnJlc2hVbml0U3RhdHMoZ2FtZSxzaGlwKTtjaGFuZ2VkPXRydWU7XG4gIH1cbiAgaWYoY2hhbmdlZCl1cGRhdGVTdXBwbHlTdGF0ZShnYW1lKTtcbn1cblxuZnVuY3Rpb24gYXNzaWduVW5pdE9yZGVyKHVuaXQ6IFVuaXQsIG9yZGVyOiBVbml0T3JkZXIsIHF1ZXVlZCA9IGZhbHNlKSB7XG4gIC8vIEBAQGNvbW1hbmQtcXVldWUgLSBRdWV1ZWQgb3JkZXJzIGxpdmUgaW4gc2ltdWxhdGlvbiBzdGF0ZSBzbyBsb2NhbCwgbG9ja3N0ZXAsIHJlcGxheSwgYW5kIFNESyBwYXRocyBzaGFyZSBvbmUgYmVoYXZpb3IuXG4gIGlmIChxdWV1ZWQpIHtcbiAgICB1bml0Lm9yZGVyUXVldWUgPSBbLi4uKHVuaXQub3JkZXJRdWV1ZSA/PyBbXSksIG9yZGVyXTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gQSBjaGFyZ2UgcnVucyBpdHMgY291cnNlIChoYWxmIGEgc2Vjb25kIG9yIHNvKTogYW4gb3JkZXIgZ2l2ZW4gZHVyaW5nIHRoZSBkYXNoIHdhaXRzIGZvciBpdCAoc2VlIGNoYXJnZSkuXG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgPT09IFwiY2hhcmdlXCIpIHtcbiAgICB1bml0Lm9yZGVyUXVldWUgPSBbb3JkZXJdO1xuICAgIHJldHVybjtcbiAgfVxuICB1bml0Lm9yZGVyID0gb3JkZXI7XG4gIHVuaXQub3JkZXJRdWV1ZSA9IFtdO1xuICBpZih1bml0LnNhaWxpbmc/Lmdhbmd3YXkpY2FuY2VsU2hpcEJvYXJkaW5nKHVuaXQpO1xuICBpZiAodW5pdC5zYWlsaW5nKSB7IHVuaXQuc2FpbGluZy5yb3V0ZSA9IHVuZGVmaW5lZDsgZGVsZXRlIHVuaXQuc2FpbGluZy5wdXJzdWl0O1xuICAgIGNhbmNlbFNoaXBQbGFubmluZ0pvYih1bml0KTtcbiAgICBkZWxldGUgdW5pdC5zYWlsaW5nLnBsYW5uaW5nUmVxdWVzdGVkQXRUaWNrOyBkZWxldGUgdW5pdC5zYWlsaW5nLnBsYW5uaW5nTGFzdFJlcXVlc3RlZEF0VGljazsgfVxufVxuXG5mdW5jdGlvbiBhY3RpdmF0ZVF1ZXVlZE9yZGVyKGdhbWU6R2FtZSx1bml0OiBVbml0KSB7XG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgIT09IFwiaWRsZVwiKSByZXR1cm47XG4gIGNvbnN0IG5leHQgPSB1bml0Lm9yZGVyUXVldWU/LnNoaWZ0KCk7XG4gIGlmICghbmV4dCkgcmV0dXJuO1xuICAvLyBBIHF1ZXVlZCBoZWxtIGNvbW1hbmQgaGFzIHRoZSBzYW1lIHByaW9yaXR5IGFzIGFuIGltbWVkaWF0ZSBvbmUuIExlYXZpbmdcbiAgLy8gcGVuZGluZyBjcmV3IG9yZGVycyBiZWhpbmQgd291bGQgc2VuZCBhbiBpZGxlIHNoaXAgYmFjayB0byBpdHMgb2xkIGJlcnRoLlxuICBpZihzaGlwUHJvZmlsZSh1bml0KSljYW5jZWxDcmV3UmVuZGV6dm91cyhnYW1lLnVuaXRzLG5ldyBTZXQoW3VuaXQuaWRdKSk7XG4gIHVuaXQub3JkZXIgPSBuZXh0O1xuICBpZih1bml0LnNhaWxpbmc/Lmdhbmd3YXkpY2FuY2VsU2hpcEJvYXJkaW5nKHVuaXQpO1xuICBpZiAodW5pdC5zYWlsaW5nKSB7IHVuaXQuc2FpbGluZy5yb3V0ZSA9IHVuZGVmaW5lZDsgZGVsZXRlIHVuaXQuc2FpbGluZy5wdXJzdWl0O1xuICAgIGNhbmNlbFNoaXBQbGFubmluZ0pvYih1bml0KTtcbiAgICBkZWxldGUgdW5pdC5zYWlsaW5nLnBsYW5uaW5nUmVxdWVzdGVkQXRUaWNrOyBkZWxldGUgdW5pdC5zYWlsaW5nLnBsYW5uaW5nTGFzdFJlcXVlc3RlZEF0VGljazsgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVGb2xsb3dPcmRlcihnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgIT09IFwiZm9sbG93XCIpIHJldHVybjtcbiAgY29uc3Qgb3JkZXIgPSB1bml0Lm9yZGVyO1xuICBjb25zdCB0YXJnZXQgPSBnYW1lLnVuaXRzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBvcmRlci50YXJnZXRJZCAmJiAhYXJlRW5lbXlPd25lcnMoZ2FtZSwgY2FuZGlkYXRlLm93bmVyLCB1bml0Lm93bmVyKSk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgdW5pdC5vcmRlciA9IHsgdHlwZTogXCJpZGxlXCIgfTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHNoaXBQcm9maWxlKHVuaXQpKSB7XG4gICAgY29uc3QgZ29hbCA9IHNoaXBQdXJzdWl0R29hbCh1bml0LCB0YXJnZXQsIGdhbWUudW5pdHMsIE1hdGgubWF4KDcyLCBzaGlwUHJvZmlsZSh1bml0KSEubGVuZ3RoICogLjYgKyAyMCksIDAsIHRydWUpO1xuICAgIGNvbnN0IHBhY2UgPSBzdGF0dXNQYWNlKHVuaXQpO1xuICAgIGlmIChnb2FsICYmIHBhY2UgPiAwKSBzYWlsVG93YXJkKHVuaXQsIGdvYWwsIGdhbWUubWFwLCBnYW1lLnVuaXRzLCBwYWNlKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGRpc3RhbmNlKHVuaXQsIHRhcmdldCkgPiBNYXRoLm1heCg3MiwgdGFyZ2V0LnJhZGl1cyArIHVuaXQucmFkaXVzICsgMjYpKSB7XG4gICAgbW92ZVRvd2FyZCh1bml0LCB0YXJnZXQueCwgdGFyZ2V0LnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVOZXV0cmFsTGVhc2goZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5vd25lciAhPT0gXCJuZXV0cmFsXCIgfHwgdW5pdC5ob21lWCA9PT0gdW5kZWZpbmVkIHx8IHVuaXQuaG9tZVkgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBob21lID0geyB4OiB1bml0LmhvbWVYLCB5OiB1bml0LmhvbWVZIH07XG4gIGNvbnN0IHJlc3BvbnNlT3JpZ2luID0gbmV1dHJhbFJlc3BvbnNlT3JpZ2luKHVuaXQpID8/IGhvbWU7XG4gIGNvbnN0IGhvbWVEaXN0YW5jZSA9IGRpc3RhbmNlKHVuaXQsIGhvbWUpO1xuICBpZiAoaG9tZURpc3RhbmNlIDw9IE5FVVRSQUxfUkVUVVJOX1NUT1BfUkFOR0UgJiYgdW5pdC5vcmRlci50eXBlID09PSBcIm1vdmVcIiAmJiBkaXN0YW5jZSh1bml0Lm9yZGVyLCBob21lKSA8PSBORVVUUkFMX1JFVFVSTl9TVE9QX1JBTkdFKSB7XG4gICAgdW5pdC5vcmRlciA9IHsgdHlwZTogXCJpZGxlXCIgfTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdGFyZ2V0ID0gdW5pdC5vcmRlci50eXBlID09PSBcImF0dGFja1wiID8gZmluZFRhcmdldChnYW1lLCB1bml0Lm9yZGVyLnRhcmdldElkKSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgcmV0dXJuaW5nID0gdW5pdC5vcmRlci50eXBlID09PSBcIm1vdmVcIiAmJiBkaXN0YW5jZSh1bml0Lm9yZGVyLCBob21lKSA8PSBORVVUUkFMX1JFVFVSTl9TVE9QX1JBTkdFO1xuICBjb25zdCBsb3N0UXVhcnJ5ID0gIXRhcmdldCAmJiAodW5pdC5vcmRlci50eXBlID09PSBcImlkbGVcIiB8fCB1bml0Lm9yZGVyLnR5cGUgPT09IFwiYXR0YWNrXCIpO1xuICBpZiAoaG9tZURpc3RhbmNlIDw9IE5FVVRSQUxfTEVBU0hfUkFOR0UgJiYgIXJldHVybmluZyAmJiAoIWxvc3RRdWFycnkgfHwgaG9tZURpc3RhbmNlIDw9IE5FVVRSQUxfUkVUVVJOX1NUT1BfUkFOR0UpXG4gICAgJiYgKCF0YXJnZXQgfHwgZGlzdGFuY2UodGFyZ2V0LCByZXNwb25zZU9yaWdpbikgPD0gTkVVVFJBTF9EQU1BR0VfUkVTUE9OU0VfUkFOR0UpKSByZXR1cm4gZmFsc2U7XG5cbiAgLy8gQEBAbmV1dHJhbC1sZWFzaCAtIENyZWVwcyByZXNldCB0byB0aGVpciBhdXRob3JlZCBjYW1wIGluc3RlYWQgb2YgZHJhZ2dpbmcgZmlnaHRzIGludG8gd29ya2VyIGxpbmVzIGZvcmV2ZXIuXG4gIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwibW92ZVwiLCB4OiBob21lLngsIHk6IGhvbWUueSB9O1xuICBtb3ZlVG93YXJkKHVuaXQsIGhvbWUueCwgaG9tZS55LCBnYW1lLm1hcCwgZ2FtZS51bml0cyk7XG4gIGlmIChkaXN0YW5jZSh1bml0LCBob21lKSA8PSBORVVUUkFMX1JFVFVSTl9TVE9QX1JBTkdFKSB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICByZXR1cm4gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlSG9sZE9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIG5hdmFsRnJhbWUgPSB0cnVlKSB7XG4gIGlmKG5hdmFsRnJhbWUgJiYgc2hpcFByb2ZpbGUodW5pdCkgJiYgIXVuaXRSdWxlcyhnYW1lLHVuaXQpLmludHJpbnNpY0F0dGFjaylyZXR1cm47XG4gIGlmICh1bml0LmNvb2xkb3duID4gMCB8fCB1bml0LmF0dGFja0RhbWFnZSA8PSAwKSByZXR1cm47XG4gIGNvbnN0IHRhcmdldCA9IG5lYXJlc3RFbmVteVRhcmdldChnYW1lLCB1bml0LCB1bml0LmF0dGFja1JhbmdlLCBuYXZhbEZyYW1lKTtcbiAgaWYgKCF0YXJnZXQpIHJldHVybjtcbiAgaWYgKCFhaW1BdCh1bml0LCB3ZWFwb25SdWxlcyhnYW1lLCB1bml0KSwgc3RyaWtlUG9pbnQodW5pdCx0YXJnZXQpLCBnYW1lLnRpY2ssIHZldGVyYW5BaW1TcGVlZChnYW1lLCB1bml0KSkpIHJldHVybjtcbiAgYXBwbHlXZWFwb25BdHRhY2soZ2FtZSwgdW5pdCwgdGFyZ2V0LCBNYXRoLm1heCgxLCBNYXRoLnJvdW5kKHVuaXQuYXR0YWNrRGFtYWdlICogb3V0Z29pbmdEYW1hZ2VNdWx0aXBsaWVyKGdhbWUsIHVuaXQpKSksIHVuaXQuYXR0YWNrUmFuZ2UpO1xuICBtYXJrQWltU2hvdCh1bml0KTtcbiAgdW5pdC5jb29sZG93biA9IGF0dGFja0Nvb2xkb3duT2YoZ2FtZSwgdW5pdCk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUFpbU9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIG5hdmFsRnJhbWUgPSB0cnVlKSB7XG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgIT09IFwiYWltXCIpIHJldHVybjtcbiAgY29uc3QgcG9pbnQgPSB1bml0Lm9yZGVyO1xuICBpZiAoZGlzdGFuY2UodW5pdCwgcG9pbnQpID4gdW5pdC5hdHRhY2tSYW5nZSkge1xuICAgIHVuaXQuYWltID0gdW5kZWZpbmVkO1xuICAgIG1vdmVUb3dhcmQodW5pdCwgcG9pbnQueCwgcG9pbnQueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIG5hdmFsRnJhbWUpO1xuICAgIGlmIChkaXN0YW5jZSh1bml0LCBwb2ludCkgPiB1bml0LmF0dGFja1JhbmdlICYmIHdhbGtFbmRlZChnYW1lLCB1bml0LCBwb2ludCwgNSkpIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChiYWNrT3V0T2ZEZWFkWm9uZShnYW1lLCB1bml0LCBwb2ludCwgbmF2YWxGcmFtZSkpIHsgdW5pdC5haW0gPSB1bmRlZmluZWQ7IHJldHVybjsgfVxuICBpZiAobmVhcmVzdEVuZW15VGFyZ2V0KGdhbWUsIHVuaXQsIHVuaXQuYXR0YWNrUmFuZ2UsIG5hdmFsRnJhbWUpKSB1cGRhdGVIb2xkT3JkZXIoZ2FtZSwgdW5pdCwgbmF2YWxGcmFtZSk7XG4gIGVsc2UgYWltQXQodW5pdCwgd2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCksIHBvaW50LCBnYW1lLnRpY2ssIHZldGVyYW5BaW1TcGVlZChnYW1lLCB1bml0KSk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUF0dGFja01vdmVPcmRlcihnYW1lOiBHYW1lLCB1bml0OiBVbml0LCBuYXZhbEZyYW1lID0gdHJ1ZSkge1xuICBpZiAodW5pdC5vcmRlci50eXBlICE9PSBcImF0dGFja01vdmVcIikgcmV0dXJuO1xuICBjb25zdCBvcmRlciA9IHVuaXQub3JkZXI7XG4gIGlmIChvcmRlci50YXJnZXRJZCkge1xuICAgIGNvbnN0IHRhcmdldCA9IGZpbmRUYXJnZXQoZ2FtZSwgb3JkZXIudGFyZ2V0SWQpO1xuICAgIC8vIFRoZSBwdWJsaWMgZW50aXR5IGxvb2t1cCBjYW4gcmV0YWluIGFuIG9sZCBib2R5IGFmdGVyIGVxdWFsLWxlbmd0aFxuICAgIC8vIGRpcmVjdCBhcnJheSByZXBsYWNlbWVudC4gQSBzdGFsZSBodWxsIG9yIHBhc3NlbmdlciBzdGlsbCB1c2VzIGl0c1xuICAgIC8vIG9yaWdpbmFsIGdlb21ldHJ5IGV2ZW4gd2hlbiB0aGlzIGZyYW1lJ3MgY3VycmVudCBib2RpZXMgYXJlIGdyb3VuZGVkLlxuICAgIGlmICghbmF2YWxGcmFtZSAmJiB0YXJnZXQgJiYgaXNVbml0KHRhcmdldCkgJiYgKHRhcmdldC5kZWNrIHx8IHRhcmdldC5jYWJpbiB8fCBpc1NoaXBLaW5kKHRhcmdldC5raW5kKSkpIG5hdmFsRnJhbWUgPSB0cnVlO1xuICAgIGlmICh0YXJnZXQgJiYgdGFyZ2V0LmhwID4gMCAmJiAoIW5hdmFsRnJhbWUgfHwgYXV0b21hdGljVGFyZ2V0QWxsb3dlZChnYW1lLnVuaXRzLHVuaXQub3duZXIsdGFyZ2V0KSkgJiYgcHJvamVjdGVkSHBBZnRlclBlbmRpbmdQcm9qZWN0aWxlcyhnYW1lLCB1bml0Lm93bmVyLCB0YXJnZXQpID4gMCAmJiBhcmVFbmVteU93bmVycyhnYW1lLCB1bml0Lm93bmVyLCB0YXJnZXQub3duZXIpICYmICghbmF2YWxGcmFtZSAmJiAhZ2FtZS5tYXAudGVycmFpbiB8fCBjYW5SZWFjaChnYW1lLm1hcCwgdW5pdCwgdGFyZ2V0LCBnYW1lLnVuaXRzKSkpIHtcbiAgICAgIGNvbnN0IGNob3NlbiA9IGF1dG9tYXRpY0NvbWJhdFRhcmdldChnYW1lLCB1bml0LCB0YXJnZXQsIG5hdmFsRnJhbWUpO1xuICAgICAgaWYgKGNob3Nlbi5pZCAhPT0gb3JkZXIudGFyZ2V0SWQpIHVuaXQub3JkZXIgPSB7IC4uLm9yZGVyLCB0YXJnZXRJZDogY2hvc2VuLmlkIH07XG4gICAgICBhdHRhY2tNb3ZlVG93YXJkVGFyZ2V0KGdhbWUsIHVuaXQsIGNob3NlbiwgbmF2YWxGcmFtZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHsgdGFyZ2V0SWQ6IF9sb3N0LCAuLi5kZXN0aW5hdGlvbiB9ID0gb3JkZXI7XG4gICAgdW5pdC5vcmRlciA9IGRlc3RpbmF0aW9uO1xuICB9XG5cbiAgY29uc3QgcHJvZmlsZT1uYXZhbEZyYW1lID8gc2hpcFByb2ZpbGUodW5pdCkgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IGFjcXVpc2l0aW9uPXByb2ZpbGUgPyBNYXRoLm1heCh1bml0LmF0dGFja1JhbmdlLE1hdGgubWluKDcwMCxNYXRoLm1heChBVVRPX0FDUVVJUkVfUkFOR0UsdW5pdC5hdHRhY2tSYW5nZStwcm9maWxlLmxlbmd0aCouNCsxMDApKSlcbiAgICA6IHVuaXRSdWxlcyhnYW1lLHVuaXQpLndlYXBvbiA/IE1hdGgubWF4KEFVVE9fQUNRVUlSRV9SQU5HRSx1bml0LmF0dGFja1JhbmdlKSA6IEFVVE9fQUNRVUlSRV9SQU5HRTtcbiAgY29uc3QgdGFyZ2V0ID0gbmVhcmVzdEVuZW15VGFyZ2V0KGdhbWUsIHVuaXQsIGFjcXVpc2l0aW9uLCBuYXZhbEZyYW1lKTtcbiAgaWYgKHRhcmdldCkge1xuICAgIHVuaXQub3JkZXIgPSB7IC4uLm9yZGVyLCB0YXJnZXRJZDogdGFyZ2V0LmlkIH07XG4gICAgYXR0YWNrTW92ZVRvd2FyZFRhcmdldChnYW1lLCB1bml0LCB0YXJnZXQsIG5hdmFsRnJhbWUpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodW5pdC5zYWlsaW5nKSBkZWxldGUgdW5pdC5zYWlsaW5nLnB1cnN1aXQ7XG4gIG1vdmVUb3dhcmQodW5pdCwgb3JkZXIueCwgb3JkZXIueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIG5hdmFsRnJhbWUpO1xuICBpZiAod2Fsa0VuZGVkKGdhbWUsIHVuaXQsIG9yZGVyLCA4KSkgYXJyaXZlKHVuaXQsIG9yZGVyKTtcbn1cblxuZnVuY3Rpb24gYXR0YWNrTW92ZVRvd2FyZFRhcmdldChnYW1lOiBHYW1lLCB1bml0OiBVbml0LCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZywgbmF2YWxGcmFtZSA9IHRydWUpIHtcbiAgaWYgKG5hdmFsRnJhbWUpIHRhcmdldCA9IG5hdmFsQ29tYmF0VGFyZ2V0KGdhbWUsIHVuaXQsIHRhcmdldCk7XG4gIGNvbnN0IGdhcCA9IHRhcmdldEdhcCh1bml0LCB0YXJnZXQsIG5hdmFsRnJhbWUpO1xuICBjb25zdCBzaGlwID0gbmF2YWxGcmFtZSAmJiBCb29sZWFuKHNoaXBQcm9maWxlKHVuaXQpKTtcbiAgaWYgKHNoaXApIG5hdmlnYXRlU2hpcEF0dGFjayhnYW1lLCB1bml0LCB0YXJnZXQpO1xuICBlbHNlIGlmIChiYWNrT3V0T2ZEZWFkWm9uZShnYW1lLCB1bml0LCB0YXJnZXQsIGZhbHNlKSkgcmV0dXJuO1xuICBpZiAoZ2FwID4gdW5pdC5hdHRhY2tSYW5nZSkge1xuICAgIGlmICghc2hpcCkgbW92ZVRvd2FyZCh1bml0LCB0YXJnZXQueCwgdGFyZ2V0LnksIGdhbWUubWFwLCBnYW1lLnVuaXRzLCBuYXZhbEZyYW1lKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYoc2hpcCAmJiAhdW5pdFJ1bGVzKGdhbWUsdW5pdCkuaW50cmluc2ljQXR0YWNrKXJldHVybjtcbiAgaWYgKHVuaXQuY29vbGRvd24gPiAwKSByZXR1cm47XG4gIGlmICghYWltQXQodW5pdCwgd2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCksIHN0cmlrZVBvaW50KHVuaXQsdGFyZ2V0KSwgZ2FtZS50aWNrLCB2ZXRlcmFuQWltU3BlZWQoZ2FtZSwgdW5pdCkpKSByZXR1cm47XG4gIGFwcGx5V2VhcG9uQXR0YWNrKGdhbWUsIHVuaXQsIHRhcmdldCwgTWF0aC5tYXgoMSwgTWF0aC5yb3VuZCh1bml0LmF0dGFja0RhbWFnZSAqIG91dGdvaW5nRGFtYWdlTXVsdGlwbGllcihnYW1lLCB1bml0KSkpLCB1bml0LmF0dGFja1JhbmdlKTtcbiAgbWFya0FpbVNob3QodW5pdCk7XG4gIHVuaXQuY29vbGRvd24gPSBhdHRhY2tDb29sZG93bk9mKGdhbWUsIHVuaXQpO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVBdHRhY2tPcmRlcihnYW1lOiBHYW1lLCB1bml0OiBVbml0LCBuYXZhbEZyYW1lID0gdHJ1ZSkge1xuICBjb25zdCBvcmRlciA9IHVuaXQub3JkZXI7XG4gIGlmIChvcmRlci50eXBlICE9PSBcImF0dGFja1wiKSByZXR1cm47XG4gIGxldCB0YXJnZXQgPSBmaW5kU3RyaWtlVGFyZ2V0KGdhbWUsIG9yZGVyLnRhcmdldElkKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIW5hdmFsRnJhbWUgJiYgaXNVbml0KHRhcmdldCkgJiYgKHRhcmdldC5kZWNrIHx8IHRhcmdldC5jYWJpbiB8fCBpc1NoaXBLaW5kKHRhcmdldC5raW5kKSkpIG5hdmFsRnJhbWUgPSB0cnVlO1xuICBpZiAobmF2YWxGcmFtZSAmJiAhaXNPYnN0YWNsZSh0YXJnZXQpKSB0YXJnZXQgPSBuYXZhbENvbWJhdFRhcmdldChnYW1lLCB1bml0LCB0YXJnZXQpO1xuICAvLyBBIHRhcmdldCB0aGF0IGlzIGFzIGdvb2QgYXMgZGVhZCwgb3Igb3V0IG9mIHJlYWNoIGZyb20gdGhlIGF0dGFja2VyJ3MgZ3JvdW5kIChzZWUgQEBAcmVhY2gpLCBnaXZlcyB3YXkgdG8gdGhlIG5leHQuXG4gIGlmIChwcm9qZWN0ZWRIcEFmdGVyUGVuZGluZ1Byb2plY3RpbGVzKGdhbWUsIHVuaXQub3duZXIsIHRhcmdldCkgPD0gMCB8fCAobmF2YWxGcmFtZSB8fCBnYW1lLm1hcC50ZXJyYWluKSAmJiAhY2FuUmVhY2goZ2FtZS5tYXAsIHVuaXQsIHRhcmdldCwgZ2FtZS51bml0cykpIHtcbiAgICBjb25zdCByZXBsYWNlbWVudCA9IG5lYXJlc3RFbmVteVRhcmdldChnYW1lLCB1bml0LCBNYXRoLm1heChBVVRPX0FDUVVJUkVfUkFOR0UsIHVuaXQuYXR0YWNrUmFuZ2UpLCBuYXZhbEZyYW1lKTtcbiAgICBpZiAoIXJlcGxhY2VtZW50KSB7XG4gICAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1bml0Lm9yZGVyID0geyAuLi5vcmRlciwgdGFyZ2V0SWQ6IHJlcGxhY2VtZW50LmlkIH07XG4gICAgdXBkYXRlQXR0YWNrT3JkZXIoZ2FtZSwgdW5pdCwgbmF2YWxGcmFtZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIE9ubHkgYXV0b21hdGljIG9yZGVycyByZWNvbnNpZGVyIGxpdmluZyB0YXJnZXRzIGhlcmUuIEV4cGxpY2l0IHBsYXllciBhdHRhY2tzIGtlZXAgdGhlaXIgdGFyZ2V0LlxuICBpZiAoIWlzT2JzdGFjbGUodGFyZ2V0KSAmJiAodW5pdC5vd25lciA9PT0gXCJuZXV0cmFsXCIgfHwgb3JkZXIubGVhc2hYICE9PSB1bmRlZmluZWQpKSB7XG4gICAgaWYobmF2YWxGcmFtZSAmJiAhYXV0b21hdGljVGFyZ2V0QWxsb3dlZChnYW1lLnVuaXRzLHVuaXQub3duZXIsdGFyZ2V0KSl7dW5pdC5vcmRlcj17dHlwZTonaWRsZSd9O3JldHVybjt9XG4gICAgdGFyZ2V0ID0gYXV0b21hdGljQ29tYmF0VGFyZ2V0KGdhbWUsIHVuaXQsIHRhcmdldCwgbmF2YWxGcmFtZSk7XG4gICAgaWYgKHRhcmdldC5pZCAhPT0gb3JkZXIudGFyZ2V0SWQpIHVuaXQub3JkZXIgPSB7IC4uLm9yZGVyLCB0YXJnZXRJZDogdGFyZ2V0LmlkIH07XG4gIH1cbiAgY29uc3QgZ2FwID0gdGFyZ2V0R2FwKHVuaXQsIHRhcmdldCwgbmF2YWxGcmFtZSk7XG4gIGNvbnN0IHNoaXAgPSBuYXZhbEZyYW1lICYmIEJvb2xlYW4oc2hpcFByb2ZpbGUodW5pdCkpO1xuICBpZiAoIXNoaXAgJiYgYmFja091dE9mRGVhZFpvbmUoZ2FtZSwgdW5pdCwgdGFyZ2V0LCBmYWxzZSkpIHJldHVybjtcbiAgaWYgKGdhcCA+IHVuaXQuYXR0YWNrUmFuZ2UpIHtcbiAgICBpZiAoaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSAmJiBvcmRlci5sZWFzaFggIT09IHVuZGVmaW5lZCAmJiBvcmRlci5sZWFzaFkgIT09IHVuZGVmaW5lZCAmJiBkaXN0YW5jZSh1bml0LCB7IHg6IG9yZGVyLmxlYXNoWCwgeTogb3JkZXIubGVhc2hZIH0pID4gR1VBUkRfTEVBU0hfUkFOR0UpIHtcbiAgICAgIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwibW92ZVwiLCB4OiBvcmRlci5sZWFzaFgsIHk6IG9yZGVyLmxlYXNoWSB9O1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc2hpcCkgbmF2aWdhdGVTaGlwQXR0YWNrKGdhbWUsIHVuaXQsIHRhcmdldCk7XG4gICAgZWxzZSBtb3ZlVG93YXJkKHVuaXQsIHRhcmdldC54LCB0YXJnZXQueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIG5hdmFsRnJhbWUpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc2hpcCkgbmF2aWdhdGVTaGlwQXR0YWNrKGdhbWUsIHVuaXQsIHRhcmdldCk7XG4gIGlmKHNoaXAgJiYgIXVuaXRSdWxlcyhnYW1lLHVuaXQpLmludHJpbnNpY0F0dGFjaylyZXR1cm47XG4gIGlmICh1bml0LmNvb2xkb3duID4gMCkgcmV0dXJuO1xuICBpZiAoIWFpbUF0KHVuaXQsIHdlYXBvblJ1bGVzKGdhbWUsIHVuaXQpLCBzdHJpa2VQb2ludCh1bml0LHRhcmdldCksIGdhbWUudGljaywgdmV0ZXJhbkFpbVNwZWVkKGdhbWUsIHVuaXQpKSkgcmV0dXJuO1xuICBhcHBseVdlYXBvbkF0dGFjayhnYW1lLCB1bml0LCB0YXJnZXQsIE1hdGgubWF4KDEsIE1hdGgucm91bmQodW5pdC5hdHRhY2tEYW1hZ2UgKiBvdXRnb2luZ0RhbWFnZU11bHRpcGxpZXIoZ2FtZSwgdW5pdCkpKSwgdW5pdC5hdHRhY2tSYW5nZSk7XG4gIG1hcmtBaW1TaG90KHVuaXQpO1xuICB1bml0LmNvb2xkb3duID0gYXR0YWNrQ29vbGRvd25PZihnYW1lLCB1bml0KTtcbn1cblxuZnVuY3Rpb24gbmF2aWdhdGVTaGlwQXR0YWNrKGdhbWU6IEdhbWUsIHNoaXA6IFVuaXQsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nIHwgT2JzdGFjbGUpIHtcbiAgaWYoZ2FtZS5ib2FyZGluZ0hvbGRzPy5oYXMoc2hpcC5pZCkpcmV0dXJuO1xuICBjb25zdCB3ZWFwb25zID0gaW5zdGFsbGVkV2VhcG9ucyhnYW1lLCBzaGlwKS5maWx0ZXIoaXRlbSA9PiAoaXRlbS5kdXJhYmlsaXR5ID8/IDEpID4gMCk7XG4gIGNvbnN0IG1pbmltdW0gPSB3ZWFwb25zLmxlbmd0aCA/IE1hdGgubWluKC4uLndlYXBvbnMubWFwKGl0ZW0gPT4gU0hJUF9XRUFQT05TW2l0ZW0ua2luZCBhcyBrZXlvZiB0eXBlb2YgU0hJUF9XRUFQT05TXS53ZWFwb24ubWluUmFuZ2UgPz8gMCkpXG4gICAgOiB3ZWFwb25SdWxlcyhnYW1lLCBzaGlwKS53ZWFwb24/Lm1pblJhbmdlID8/IDA7XG4gIGNvbnN0IGJsb2NrZXJzPWZyaWVuZGx5RmlyZUJsb2NrZXJzKGdhbWUsc2hpcCk7XG4gIGxldCBmaXJpbmdIZWFkaW5nOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gIGNvbnN0IGNhbkZpcmVGcm9tID0gKHN0YXRpb246VW5pdCxjaGVja1R1cm46Ym9vbGVhbikgPT4ge1xuICAgIGlmICghd2VhcG9ucy5sZW5ndGgpIHJldHVybiB0YXJnZXRHYXAoc3RhdGlvbiwgdGFyZ2V0KSA8PSBzdGF0aW9uLmF0dGFja1JhbmdlICYmIHRhcmdldEdhcChzdGF0aW9uLCB0YXJnZXQpID49IG1pbmltdW07XG4gICAgc2hhcmVTaGlwUHJvZmlsZShzaGlwLHN0YXRpb24pO1xuICAgIGNvbnN0IHN0YXJ0ID0geyB4OiBzdGF0aW9uLngsIHk6IHN0YXRpb24ueSwgaGVhZGluZzogc3RhdGlvbi5zYWlsaW5nIS5oZWFkaW5nIH07XG4gICAgY29uc3Qgc2hvdENsZWFyPW1vdW50ZWRTaG90Q2xlYXIoc3RhdGlvbixibG9ja2Vycyk7XG4gICAgZm9yIChjb25zdCBtYXJnaW4gb2YgW01hdGguUEkgLyAzNiwgMF0pIHtcbiAgICAgIGNvbnN0IGhlYWRpbmcgPSBiZXN0RmlyaW5nSGVhZGluZyhnYW1lLCBzdGF0aW9uLCB0YXJnZXQsIG1hcmdpbixzaG90Q2xlYXIpLCBhaW1lZCA9IHsgLi4uc3RhdGlvbiwgc2FpbGluZzogeyAuLi5zdGF0aW9uLnNhaWxpbmchLCBoZWFkaW5nIH0gfSwgZW5kID0geyAuLi5zdGFydCwgaGVhZGluZyB9O1xuICAgICAgc2hhcmVTaGlwUHJvZmlsZShzaGlwLGFpbWVkKTtcbiAgICAgIGlmIChjaGVja1R1cm4gJiYgKCFodWxsUGFzc2FnZUNsZWFyKGdhbWUubWFwLCBzdGF0aW9uLCBzdGFydCwgZW5kKSB8fCAhc2hpcFRyYWZmaWMoc3RhdGlvbiwgZ2FtZS51bml0cykoc3RhcnQsIGVuZCkpKSBjb250aW51ZTtcbiAgICAgIGlmICh3ZWFwb25zLnNvbWUoaXRlbSA9PiB7XG4gICAgICAgIGNvbnN0IHBvc2UgPSBtb3VudGVkV2VhcG9uUG9zZShhaW1lZCwgaXRlbSksIGRlZiA9IFNISVBfV0VBUE9OU1tpdGVtLmtpbmQgYXMga2V5b2YgdHlwZW9mIFNISVBfV0VBUE9OU107XG4gICAgICAgIGlmICghcG9zZSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBjb25zdCBwb2ludCA9IG1vdW50ZWRUYXJnZXRQb2ludChnYW1lLGFpbWVkLGl0ZW0sdGFyZ2V0LHBvc2UpO1xuICAgICAgICBpZiAoIXNoaXBHdW5DYW5BaW0oYWltZWQsIGl0ZW0sIHBvaW50KSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBjb25zdCBnYXAgPSBkaXN0YW5jZShwb3NlLnBpdm90LCBwb2ludCk7XG4gICAgICAgIHJldHVybiBnYXAgPD0gdmV0ZXJhbldlYXBvblJhbmdlKHN0YXRpb24sIGRlZi5yYW5nZSkgJiYgZ2FwID49IChkZWYud2VhcG9uLm1pblJhbmdlID8/IDApXG4gICAgICAgICAgJiYgKCFibG9ja2Vycy5sZW5ndGggfHwgbW91bnRlZEZpcmVMYW5lQ2xlYXIoYWltZWQsaXRlbSxwb2ludCxibG9ja2VycykpO1xuICAgICAgfSkpIHsgaWYoY2hlY2tUdXJuKWZpcmluZ0hlYWRpbmcgPSBoZWFkaW5nOyByZXR1cm4gdHJ1ZTsgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH07XG4gIGNvbnN0IGZpcmluZyA9IGNhbkZpcmVGcm9tKHNoaXAsdHJ1ZSk7XG4gIGNvbnN0IGJvdz13ZWFwb25zLmZpbmQoaXRlbT0+aXRlbS5tb3VudElkPT09J2JvdycgJiYgdmV0ZXJhbldlYXBvblJhbmdlKHNoaXAsU0hJUF9XRUFQT05TW2l0ZW0ua2luZCBhcyBrZXlvZiB0eXBlb2YgU0hJUF9XRUFQT05TXS5yYW5nZSk+PXNoaXAuYXR0YWNrUmFuZ2UpO1xuICBjb25zdCBib3dQb3NlPWJvdyAmJiBtb3VudGVkV2VhcG9uUG9zZShzaGlwLGJvdyk7XG4gIGNvbnN0IHN0YXRpb25Cb3dSZWFjaD1ib3dQb3NlID8gKGJvd1Bvc2UucGl2b3QueC1zaGlwLngpKmRldENvcyhzaGlwLnNhaWxpbmchLmhlYWRpbmcpKyhib3dQb3NlLnBpdm90Lnktc2hpcC55KSpkZXRTaW4oc2hpcC5zYWlsaW5nIS5oZWFkaW5nKSA6IDA7XG4gIGNvbnN0IGdvYWwgPSBzaGlwUHVyc3VpdEdvYWwoc2hpcCwgdGFyZ2V0LCBnYW1lLnVuaXRzLCBzaGlwLmF0dGFja1JhbmdlLCBtaW5pbXVtLCBmYWxzZSwgKCkgPT4gZmlyaW5nLCBnYW1lLm1hcCwgZmlyaW5nSGVhZGluZyxzdGF0aW9uQm93UmVhY2gsc3RhdGlvbj0+Y2FuRmlyZUZyb20oc3RhdGlvbixmYWxzZSksKCk9PnRyeUFkbWl0U2hpcFBsYW4oc2hpcCkpO1xuICBjb25zdCBwYWNlID0gc3RhdHVzUGFjZShzaGlwKTtcbiAgaWYgKGdvYWwgJiYgcGFjZSA+IDApIHNhaWxUb3dhcmQoc2hpcCwgZ29hbCwgZ2FtZS5tYXAsIGdhbWUudW5pdHMsIHBhY2UpO1xuICBlbHNlIGlmICghZ29hbCAmJiBzaGlwLnNhaWxpbmchLnBsYW5uaW5nUmVxdWVzdGVkQXRUaWNrICE9PSB1bmRlZmluZWQgJiYgIXNoaXAuc2FpbGluZyEucm91dGUpIHtcbiAgICAvLyBBIG5ldyBhdHRhY2sgYXdhaXRpbmcgaXRzIGZpcnN0IGFkbWl0dGVkIHN0YXRpb24gaGFzIG5vIG1vdGlvblxuICAgIC8vIGF1dGhvcml0eS4gSXQgbWF5IHVzZSB0aGlzIGZyYW1lJ3MgYm91bmRlZCwgc3dlcHQgeWF3IHRvIGZhY2UgdGhlXG4gICAgLy8gY2FycnlpbmcgaHVsbCwgYnV0IGNhbm5vdCBzdXJnZSB0b3dhcmQgYW4gdW50ZXN0ZWQgZmlyaW5nIHN0YXRpb24uXG4gICAgc2hpcC5zYWlsaW5nIS5zcGVlZCA9IDA7XG4gICAgaWYgKHBhY2UgPiAwKSB7XG4gICAgICBjb25zdCBxdWFycnkgPSBzaGlwTmF2aWdhdGlvblRhcmdldCh0YXJnZXQsIGdhbWUudW5pdHMpO1xuICAgICAgdHVyblNoaXBUb3dhcmQoc2hpcCwgTWF0aC5hdGFuMihxdWFycnkueSAtIHNoaXAueSwgcXVhcnJ5LnggLSBzaGlwLngpLCBnYW1lLm1hcCwgZ2FtZS51bml0cyk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZU1pbmVPcmRlcihnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgIT09IFwibWluZVwiKSByZXR1cm47XG4gIGNvbnN0IG9yZGVyID0gdW5pdC5vcmRlcjtcbiAgY29uc3QgcmVzb3VyY2UgPSBnYW1lLm1pbmluZ0ZyYW1lIS5yZXNvdXJjZXMuZ2V0KG9yZGVyLnJlc291cmNlSWQpO1xuICBpZiAoKCFyZXNvdXJjZSB8fCByZXNvdXJjZS5hbW91bnQgPD0gMCkgJiYgb3JkZXIucGhhc2UgIT09IFwicmV0dXJuXCIpIHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChvcmRlci5waGFzZSA9PT0gXCJ0b01pbmVcIikge1xuICAgIGlmIChkaXN0YW5jZSh1bml0LCByZXNvdXJjZSEpID4gTUlORV9SQU5HRSkge1xuICAgICAgbW92ZVRvd2FyZCh1bml0LCByZXNvdXJjZSEueCwgcmVzb3VyY2UhLnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgb3JkZXIudGltZXIgKz0gMTtcbiAgICBpZiAoKHJlc291cmNlIS5oYXJ2ZXN0Q29vbGRvd25SZW1haW5pbmcgPz8gMCkgPiAwKSByZXR1cm47XG4gICAgaWYgKGdhbWUubWluaW5nRnJhbWUhLm5leHRXb3JrZXIuZ2V0KG9yZGVyLnJlc291cmNlSWQpICE9PSB1bml0LmlkKSByZXR1cm47XG4gICAgdW5pdC5taW5lU2xvdCA9IG9yZGVyLnJlc291cmNlSWQ7XG4gICAgcmVzb3VyY2UhLmhhcnZlc3RDb29sZG93blJlbWFpbmluZyA9IEdPTERfTUlORV9FTlRSWV9DT09MRE9XTjtcbiAgICB1bml0Lm9yZGVyID0geyAuLi5vcmRlciwgcGhhc2U6IFwiZ2F0aGVyXCIsIHRpbWVyOiBHQVRIRVJfRFVSQVRJT04gfTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAob3JkZXIucGhhc2UgPT09IFwiZ2F0aGVyXCIpIHtcbiAgICBvcmRlci50aW1lciAtPSAxO1xuICAgIGlmIChvcmRlci50aW1lciA+IDApIHJldHVybjtcbiAgICBjb25zdCBtaW5lZCA9IE1hdGgubWluKEdPTERfUEVSX1RSSVAsIHJlc291cmNlIS5hbW91bnQpO1xuICAgIHJlc291cmNlIS5hbW91bnQgLT0gbWluZWQ7XG4gICAgdW5pdC5jYXJyeWluZ0dvbGQgPSBtaW5lZDtcbiAgICB1bml0Lm9yZGVyID0geyAuLi5vcmRlciwgcGhhc2U6IFwicmV0dXJuXCIsIHRpbWVyOiAwIH07XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgdG93bkhhbGwgPSBuZWFyZXN0Q29tcGxldGVUb3duSGFsbChnYW1lLCB1bml0Lm93bmVyLCB1bml0LngsIHVuaXQueSk7XG4gIGlmICghdG93bkhhbGwpIHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoZGlzdGFuY2UodW5pdCwgdG93bkhhbGwpID4gVE9XTl9IQUxMX0RST1BfUkFOR0UpIHtcbiAgICBtb3ZlVG93YXJkKHVuaXQsIHRvd25IYWxsLngsIHRvd25IYWxsLnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGlzUGxheWVySWQodW5pdC5vd25lcikpIHtcbiAgICBjb25zdCBwbGF5ZXIgPSBwbGF5ZXJTdGF0ZShnYW1lLCB1bml0Lm93bmVyKTtcbiAgICBwbGF5ZXIuZ29sZCA9IGFkZEdvbGQocGxheWVyLmdvbGQsIHVwa2VlcEdvbGRJbmNvbWUodW5pdC5jYXJyeWluZ0dvbGQsIHBsYXllci5zdXBwbHlVc2VkKSk7XG4gIH1cbiAgdW5pdC5jYXJyeWluZ0dvbGQgPSAwO1xuICB1bml0Lm9yZGVyID0gcmVzb3VyY2UgJiYgcmVzb3VyY2UuYW1vdW50ID4gMCA/IHsgdHlwZTogXCJtaW5lXCIsIHJlc291cmNlSWQ6IHJlc291cmNlLmlkLCBwaGFzZTogXCJ0b01pbmVcIiwgdGltZXI6IDAgfSA6IHsgdHlwZTogXCJpZGxlXCIgfTtcbn1cblxuLy8gQSBzb2xkaWVyIHRvbGQgdG8gYm9hcmQgd2Fsa3MgdG8gaXRzIHRyYW5zcG9ydCAoc2VlIEBAQHRyYW5zcG9ydCk7IGl0IGdvZXMgYWJvYXJkIGluIGZlcnJ5VW5pdHMuIEFuIGlkbGUgdHJhbnNwb3J0XG4vLyBzYWlscyBpbiB0byB0aGUgd2F0ZXIgbmVhcmVzdCBpdCwgc28gdGhlIHR3byBtZWV0IGF0IHRoZSBzaG9yZSB3aGVyZXZlciBlYWNoIHN0b3BwZWQuXG5mdW5jdGlvbiB1cGRhdGVCb2FyZFNoaXBPcmRlcihnYW1lOkdhbWUsc2hpcDpVbml0KSB7XG4gIGlmKHNoaXAub3JkZXIudHlwZSE9PSdib2FyZFNoaXAnKXJldHVybjtcbiAgY29uc3Qgb3JkZXI9c2hpcC5vcmRlcjtcbiAgY29uc3QgdGFyZ2V0PWdhbWUudW5pdHMuZmluZCh1bml0PT51bml0LmlkPT09b3JkZXIudGFyZ2V0SWQgJiYgdW5pdC5ocD4wKTtcbiAgaWYoIXRhcmdldCB8fCAhc2hpcFByb2ZpbGUoc2hpcCkgfHwgIXNoaXAuc2FpbGluZykge1xuICAgIGNhbmNlbFNoaXBCb2FyZGluZyhzaGlwKTtzaGlwLm9yZGVyPXt0eXBlOidpZGxlJ307cmV0dXJuO1xuICB9XG4gIGlmKCFzaGlwLnNhaWxpbmcuZ2FuZ3dheSAmJiAhYmVnaW5TaGlwQm9hcmRpbmcoZ2FtZS5tYXAsZ2FtZS51bml0cyxzaGlwLHRhcmdldCxnYW1lLnRpY2ssZ2FtZSkpIHtcbiAgICBzaGlwLm9yZGVyPXt0eXBlOidpZGxlJ307cmV0dXJuO1xuICB9XG4gIGNvbnN0IHN0YXRlPXNoaXAuc2FpbGluZy5nYW5nd2F5ITtcbiAgaWYoc3RhdGUucGhhc2U9PT0nYXBwcm9hY2gnKSB7XG4gICAgY29uc3QgZ29hbD1zaGlwQm9hcmRpbmdHb2FsKGdhbWUubWFwLGdhbWUudW5pdHMsc2hpcCx0YXJnZXQpO1xuICAgIGlmKGdvYWwpc2FpbFRvd2FyZChzaGlwLGdvYWwsZ2FtZS5tYXAsZ2FtZS51bml0cyxzdGF0dXNQYWNlKHNoaXApKTtcbiAgICByZXR1cm47XG4gIH1cbiAgc2hpcC5zYWlsaW5nLnNwZWVkPTA7c2hpcC5zYWlsaW5nLnlhd1JhdGU9MDtcbiAgaWYoc3RhdGUucGhhc2UhPT0ncmVhZHknKXJldHVybjtcbiAgaWYoYXJlRW5lbXlPd25lcnMoZ2FtZSxzaGlwLm93bmVyLHRhcmdldC5vd25lcikpZm9yKGNvbnN0IGNyZXcgb2Ygc2hpcFBhc3NlbmdlcnMoZ2FtZS51bml0cyxzaGlwKSkge1xuICAgIGNvbnN0IGNyZXdPcmRlcj1jcmV3Lm9yZGVyO1xuICAgIGNvbnN0IGF1dG9tYXRpY1RhcmdldD1jcmV3T3JkZXIudHlwZT09PSdhdHRhY2snICYmIGNyZXdPcmRlci5sZWFzaFghPT11bmRlZmluZWRcbiAgICAgID8gZ2FtZS51bml0cy5maW5kKHVuaXQ9PnVuaXQuaWQ9PT1jcmV3T3JkZXIudGFyZ2V0SWQpIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IGF1dG9tYXRpY0F0dGFjaz1jcmV3T3JkZXIudHlwZT09PSdhdHRhY2snICYmIGNyZXdPcmRlci5sZWFzaFghPT11bmRlZmluZWRcbiAgICAgICYmIChjcmV3T3JkZXIudGFyZ2V0SWQ9PT10YXJnZXQuaWQgfHwgYXV0b21hdGljVGFyZ2V0Py5kZWNrPy5zaGlwSWQ9PT10YXJnZXQuaWQpO1xuICAgIGlmKGNyZXcub3duZXIhPT1zaGlwLm93bmVyIHx8IGNyZXcua2luZD09PSd3b3JrZXInIHx8ICFnYW5nd2F5Q3Jld0VsaWdpYmxlKGNyZXcsZ2FtZSlcbiAgICAgIHx8IHVuaXRSdWxlcyhnYW1lLGNyZXcpLmF0dGFja1JhbmdlPlJBTkdFRF9BVFRBQ0tfUkFOR0VfVEhSRVNIT0xEIHx8IGNyZXcuYXR0YWNrRGFtYWdlPD0wXG4gICAgICB8fCAhWydpZGxlJywnaG9sZCddLmluY2x1ZGVzKGNyZXcub3JkZXIudHlwZSkgJiYgIWF1dG9tYXRpY0F0dGFjayB8fCBjcmV3Lm9yZGVyUXVldWU/Lmxlbmd0aCljb250aW51ZTtcbiAgICBhc3NpZ25Vbml0T3JkZXIoY3Jldyx7dHlwZTonYm9hcmQnLHRyYW5zcG9ydElkOnRhcmdldC5pZH0pO1xuICB9XG4gIC8vIERlcGxveWluZyBjb21wbGV0ZXMgdGhlIGNvbW1hbmQuIFRoZSBzYXZlZCBjb25uZWN0aW9uIGNvbnRpbnVlcyB0byBob2xkXG4gIC8vIGl0cyBzb3VyY2Ugc3RhdGlvbiB1bnRpbCBjYW5jZWxsZWQsIGRhbWFnZWQsIG9yIGEgbmV3IGhlbG0gb3JkZXIgZGVwYXJ0cy5cbiAgc2hpcC5vcmRlcj17dHlwZTonaWRsZSd9O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVCb2FyZE9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgaWYgKHVuaXQub3JkZXIudHlwZSAhPT0gXCJib2FyZFwiKSByZXR1cm47XG4gIGNvbnN0IHRyYW5zcG9ydCA9IGZpbmRUYXJnZXQoZ2FtZSwgdW5pdC5vcmRlci50cmFuc3BvcnRJZCk7XG4gIGlmICghdHJhbnNwb3J0IHx8ICFpc1VuaXQodHJhbnNwb3J0KSB8fCB0cmFuc3BvcnQuaHA8PTAgfHwgIXVuaXQuZGVjayAmJiB0cmFuc3BvcnQub3duZXIgIT09IHVuaXQub3duZXIpIHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgIHJldHVybjtcbiAgfVxuICBpZih1bml0LmRlY2spe1xuICAgIGNvbnN0IHNvdXJjZT1nYW1lLnVuaXRzLmZpbmQoc2hpcD0+c2hpcC5pZD09PXVuaXQuZGVjayEuc2hpcElkKTtcbiAgICBpZighc291cmNlKXJldHVybjtcbiAgICBpZihzb3VyY2UuaWQhPT10cmFuc3BvcnQuaWQgJiYgIWRlY2tzQ2FuVHJhbnNmZXIoc291cmNlLHRyYW5zcG9ydCx1bml0KSlyZXR1cm47XG4gICAgLy8gQSBkZWZlbmRlZCBlbnRyeSBpcyBhIGZpZ2h0LCBub3QgYW4gdW5yZWFjaGFibGUgZmVycnkgZGVzdGluYXRpb24uXG4gICAgLy8gUmV0YWluIHRoZSBib2FyZGluZyBvcmRlciBzbyBjbGVhcmluZyB0aGUgbGFuZSByZXN1bWVzIHRoZSBjcm9zc2luZy5cbiAgICBpZih1bml0LmtpbmQhPT0nd29ya2VyJyAmJiBhcmVFbmVteU93bmVycyhnYW1lLHVuaXQub3duZXIsdHJhbnNwb3J0Lm93bmVyKSAmJiB1bml0LmF0dGFja0RhbWFnZT4wXG4gICAgICAmJiB1bml0UnVsZXMoZ2FtZSx1bml0KS5hdHRhY2tSYW5nZTw9UkFOR0VEX0FUVEFDS19SQU5HRV9USFJFU0hPTEQpIHtcbiAgICAgIC8vIEFuc3dlciB0aGUgcmVhY2hhYmxlIGZyb250IHJhbmsgYmVmb3JlIHB1cnN1aW5nIGEgaGlnaGVyLXByaW9yaXR5XG4gICAgICAvLyBzaG9vdGVyIHdob3NlIHJvdXRlIGlzIHNlYWxlZCBieSB0aGF0IGRlZmVuZGVyJ3MgYm9keS5cbiAgICAgIGNvbnN0IG5lYXJieT1uYXZhbENvbWJhdFRhcmdldChnYW1lLHVuaXQsdHJhbnNwb3J0LHVuaXQuYXR0YWNrUmFuZ2UpO1xuICAgICAgY29uc3QgZGVmZW5kZXI9bmVhcmJ5IT09dHJhbnNwb3J0ID8gbmVhcmJ5IDogbmF2YWxDb21iYXRUYXJnZXQoZ2FtZSx1bml0LHRyYW5zcG9ydCk7XG4gICAgICBpZihkZWZlbmRlciE9PXRyYW5zcG9ydCAmJiBpc1VuaXQoZGVmZW5kZXIpKSB7XG4gICAgICAgIGNvbnN0IGJvYXJkaW5nT3JkZXI9dW5pdC5vcmRlcjtcbiAgICAgICAgdW5pdC5vcmRlcj17dHlwZTonYXR0YWNrJyx0YXJnZXRJZDpkZWZlbmRlci5pZH07XG4gICAgICAgIHRyeSB7IHVwZGF0ZUF0dGFja09yZGVyKGdhbWUsdW5pdCk7IH1cbiAgICAgICAgZmluYWxseSB7IHVuaXQub3JkZXI9Ym9hcmRpbmdPcmRlcjsgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmKHNvdXJjZS5pZCE9PXRyYW5zcG9ydC5pZCAmJiAhY2FuQm9hcmQodHJhbnNwb3J0LHVuaXQsZ2FtZS51bml0cykpe1xuICAgICAgdW5pdC5vcmRlcj17dHlwZTpcImlkbGVcIn07XG4gICAgICBhZGRFZmZlY3QoZ2FtZSxcImJvYXJkaW5nQmxvY2tlZFwiLHVuaXQueCx1bml0Lnksc2Vjb25kcyguNCkse3VuaXRJZDp1bml0LmlkLG93bmVyOnVuaXQub3duZXIsc291cmNlS2luZDp1bml0LmtpbmR9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gT25lIHNoYXJlZCBlbnRyeSBhZG1pdHMgbGFyZ2UgYm9kaWVzIGZpcnN0LiBXYWl0aW5nIGNyZXcgY2xlYXIgdGhlIGFmdFxuICAgIC8vIHBhc3NhZ2Ugb24gdGhlaXIgb3duIGRlY2sgcmF0aGVyIHRoYW4gcmFjaW5nIGFoZWFkIGFuZCBzZWFsaW5nIHRoZSBleGl0LlxuICAgIGNvbnN0IGFoZWFkPWdhbWUudW5pdHMuc29tZShvdGhlcj0+b3RoZXIhPT11bml0ICYmIG90aGVyLmhwPjAgJiYgb3RoZXIuZGVjayAmJiBvdGhlci5vcmRlci50eXBlPT09XCJib2FyZFwiICYmIG90aGVyLm9yZGVyLnRyYW5zcG9ydElkPT09dHJhbnNwb3J0LmlkXG4gICAgICAmJiAob3RoZXIucmFkaXVzPnVuaXQucmFkaXVzIHx8IG90aGVyLnJhZGl1cz09PXVuaXQucmFkaXVzICYmIG90aGVyLmlkPHVuaXQuaWQpKTtcbiAgICBpZihhaGVhZCAmJiBzb3VyY2UuaWQhPT10cmFuc3BvcnQuaWQpe1xuICAgICAgY29uc3QgcHJvZmlsZT1zaGlwUHJvZmlsZShzb3VyY2UpISxlbnRyeT13b3JsZFRvTG9jYWwoc291cmNlLHRyYW5zcG9ydCk7XG4gICAgICBjb25zdCB3YWl0aW5nPWRlY2tQbGFjZW1lbnQoc291cmNlLHVuaXQsZ2FtZS51bml0cyx7eDpwcm9maWxlLmxlbmd0aC80LHk6LU1hdGguc2lnbihlbnRyeS55KSpwcm9maWxlLmJlYW0vMn0pO1xuICAgICAgaWYod2FpdGluZyl7Y29uc3QgYXQ9bG9jYWxUb1dvcmxkKHNvdXJjZSx3YWl0aW5nKTttb3ZlVG93YXJkKHVuaXQsYXQueCxhdC55LGdhbWUubWFwLGdhbWUudW5pdHMpO31cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYodW5pdC5vcmRlci5kZWNrUG9pbnQgJiYgIWRlY2tQb2ludEZpdHModHJhbnNwb3J0LHVuaXQsdW5pdC5vcmRlci5kZWNrUG9pbnQsZ2FtZS51bml0cyx0cnVlKSlkZWxldGUgdW5pdC5vcmRlci5kZWNrUG9pbnQ7XG4gICAgaWYoIXVuaXQub3JkZXIuZGVja1BvaW50KXtcbiAgICAgIGNvbnN0IHJlc2VydmVkPWdhbWUudW5pdHMubWFwKG90aGVyPT5vdGhlciE9PXVuaXQgJiYgb3RoZXIub3JkZXIudHlwZT09PVwiYm9hcmRcIiAmJiBvdGhlci5vcmRlci50cmFuc3BvcnRJZD09PXRyYW5zcG9ydC5pZCAmJiBvdGhlci5vcmRlci5kZWNrUG9pbnRcbiAgICAgICAgPyB7Li4ub3RoZXIsZGVjazp7c2hpcElkOnRyYW5zcG9ydC5pZCwuLi5vdGhlci5vcmRlci5kZWNrUG9pbnR9fSA6IG90aGVyKTtcbiAgICAgIGNvbnN0IGVudHJ5PXdvcmxkVG9Mb2NhbCh0cmFuc3BvcnQsc291cmNlKSxwcm9maWxlPXNoaXBQcm9maWxlKHRyYW5zcG9ydCkhO1xuICAgICAgLy8gV2FsayBiZXlvbmQgdGhlIGVudHJ5IHNlYW0gc28gZWFybHkgYXJyaXZhbHMgbGVhdmUgcm9vbSBmb3IgbGFyZ2VyIGNyZXcuXG4gICAgICBjb25zdCByZWFjaD1NYXRoLmh5cG90KGVudHJ5LngsZW50cnkueSl8fDE7XG4gICAgICBjb25zdCBwcmVmZXJyZWQ9e3g6cHJvZmlsZS5sZW5ndGgvMix5Oi1lbnRyeS55L3JlYWNoKnByb2ZpbGUuYmVhbS8yfTtcbiAgICAgIGNvbnN0IHBvaW50PWRlY2tQbGFjZW1lbnQodHJhbnNwb3J0LHVuaXQscmVzZXJ2ZWQscHJlZmVycmVkLHRydWUpO1xuICAgICAgaWYocG9pbnQpdW5pdC5vcmRlci5kZWNrUG9pbnQ9cG9pbnQ7XG4gICAgfVxuICAgIGNvbnN0IHBvaW50PXVuaXQub3JkZXIuZGVja1BvaW50O2lmKCFwb2ludClyZXR1cm47XG4gICAgY29uc3QgZ29hbD1sb2NhbFRvV29ybGQodHJhbnNwb3J0LHBvaW50KTtcbiAgICBpZihzb3VyY2UuaWQ9PT10cmFuc3BvcnQuaWQpe1xuICAgICAgbW92ZVRvd2FyZCh1bml0LGdvYWwueCxnb2FsLnksZ2FtZS5tYXAsZ2FtZS51bml0cyk7XG4gICAgICBpZihkaXN0YW5jZSh1bml0LGdvYWwpPDFlLTYpdW5pdC5vcmRlcj17dHlwZTpcImlkbGVcIn07XG4gICAgfSBlbHNlIGlmKGRlY2tzQ2FuVHJhbnNmZXIoc291cmNlLHRyYW5zcG9ydCx1bml0KSltb3ZlVG93YXJkKHVuaXQsZ29hbC54LGdvYWwueSxnYW1lLm1hcCxnYW1lLnVuaXRzKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGFsb25nc2lkZSh1bml0LCB0cmFuc3BvcnQpKSByZXR1cm47XG4gIGNvbnN0IGdvYWwgPSB0cmFuc3BvcnQub3JkZXIudHlwZSA9PT0gXCJpZGxlXCIgPyB1bml0Lm9yZGVyLmJlcnRoPy5zaG9yZSA/PyB1bml0Lm9yZGVyLmJlcnRoID8/IHRyYW5zcG9ydCA6IHRyYW5zcG9ydDtcbiAgbW92ZVRvd2FyZCh1bml0LCBnb2FsLngsIGdvYWwueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMpO1xufVxuXG4vLyBBZnRlciBldmVyeSB1bml0IGhhcyBtb3ZlZDogc29sZGllcnMgYWxvbmdzaWRlIHRoZSB0cmFuc3BvcnQgdGhleSB3ZXJlIHRvbGQgdG8gYm9hcmQgZ28gYWJvYXJkIHdoaWxlIHRoZWlyIHN1cHBseSBmaXRzXG4vLyAodGhlIHJlc3Qgc3RvcCksIGFuZCBhIHN0b3BwZWQgdHJhbnNwb3J0IHdpdGhpbiByZWFjaCBvZiBpdHMgcmVxdWVzdGVkIHNob3JlIHNldHMgaXRzIHBhc3NlbmdlcnMgYXNob3JlIChhbnlcbi8vIHRoYXQgZmluZCBubyBsYW5kIG5lYXIgZW5vdWdoIHN0YXkgYWJvYXJkKSBhbmQgc3RvcHMgKHNlZSBAQEB0cmFuc3BvcnQpLlxuZnVuY3Rpb24gZmVycnlVbml0cyhnYW1lOiBHYW1lLCB7IGJvYXJkaW5nLCB1bmxvYWRpbmcgfTogRmVycnksIHN0YXJ0czogUmVhZG9ubHlNYXA8c3RyaW5nLCB7eDpudW1iZXI7eTpudW1iZXI7aGVhZGluZzpudW1iZXJ9Pikge1xuICBjb25zdCBhcHByb2FjaGVkPW5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IoY29uc3QgcGFzc2VuZ2VyIG9mIGJvYXJkaW5nKSB7XG4gICAgaWYocGFzc2VuZ2VyLm9yZGVyLnR5cGUhPT1cImJvYXJkXCIgfHwgcGFzc2VuZ2VyLmRlY2sgfHwgYXBwcm9hY2hlZC5oYXMocGFzc2VuZ2VyLm9yZGVyLnRyYW5zcG9ydElkKSljb250aW51ZTtcbiAgICBjb25zdCBib2F0PWZpbmRUYXJnZXQoZ2FtZSxwYXNzZW5nZXIub3JkZXIudHJhbnNwb3J0SWQpO1xuICAgIGlmKCFib2F0IHx8ICFpc1VuaXQoYm9hdCkgfHwgYm9hdC5vcmRlci50eXBlIT09XCJpZGxlXCIpY29udGludWU7XG4gICAgYXBwcm9hY2hlZC5hZGQoYm9hdC5pZCk7XG4gICAgY29uc3QgYmVydGg9cGFzc2VuZ2VyLm9yZGVyLmJlcnRoID8/IGJvYXJkaW5nQmVydGgoZ2FtZS5tYXAscGFzc2VuZ2VyLGJvYXQpO1xuICAgIC8vIFRoZSBiZXJ0aCBpcyBhIGh1bGwgcG9zZSwgbm90IGp1c3QgYSBjZW50ZXIuIERpc2NhcmRpbmcgaXRzIGhlYWRpbmcgY2FuXG4gICAgLy8gbGVhdmUgdGhlIGJvdyBvZmZzaG9yZSBldmVuIGFmdGVyIHRoZSBib2F0IHJlYWNoZXMgdGhlIGNvcnJlY3QgcG9pbnQuXG4gICAgaWYoYmVydGggJiYgIWFsb25nc2lkZShwYXNzZW5nZXIsYm9hdCkpc2FpbFRvd2FyZChib2F0LGJlcnRoLGdhbWUubWFwLGdhbWUudW5pdHMpO1xuICB9XG4gIGZvcihjb25zdCBwYXNzZW5nZXIgb2YgYm9hcmRpbmcpIHtcbiAgICBpZihwYXNzZW5nZXIub3JkZXIudHlwZSE9PVwiYm9hcmRcIiB8fCBwYXNzZW5nZXIuZGVjayljb250aW51ZTtcbiAgICBjb25zdCBzaGlwPWZpbmRUYXJnZXQoZ2FtZSxwYXNzZW5nZXIub3JkZXIudHJhbnNwb3J0SWQpO1xuICAgIGlmKCFzaGlwIHx8ICFpc1VuaXQoc2hpcCkgfHwgIWFsb25nc2lkZShwYXNzZW5nZXIsc2hpcCkpY29udGludWU7XG4gICAgY29uc3QgYm9hcmRlZD1ib2FyZFVuaXQoc2hpcCxwYXNzZW5nZXIsZ2FtZS51bml0cyk7XG4gICAgYXNzaWduVW5pdE9yZGVyKHBhc3Nlbmdlcix7dHlwZTpcImlkbGVcIn0pO1xuICAgIGFkZEVmZmVjdChnYW1lLGJvYXJkZWQgPyBcImJvYXJkXCIgOiBcImJvYXJkaW5nQmxvY2tlZFwiLHBhc3Nlbmdlci54LHBhc3Nlbmdlci55LHNlY29uZHMoLjQpLHt1bml0SWQ6cGFzc2VuZ2VyLmlkLG93bmVyOnBhc3Nlbmdlci5vd25lcixzb3VyY2VLaW5kOnBhc3Nlbmdlci5raW5kfSk7XG4gIH1cbiAgZm9yKGNvbnN0IHNoaXAgb2YgdW5sb2FkaW5nKSB7XG4gICAgaWYoc2hpcC5vcmRlci50eXBlIT09XCJ1bmxvYWRcIiB8fCAoc2hpcC5zYWlsaW5nPy5zcGVlZD8/MCk+LjEpY29udGludWU7XG4gICAgY29uc3Qgc3RhcnQ9c3RhcnRzLmdldChzaGlwLmlkKTtcbiAgICBpZihzdGFydCAmJiAoZGlzdGFuY2Uoc2hpcCxzdGFydCk+MWUtNiB8fCBNYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShzdGFydC5oZWFkaW5nLHNoaXAuc2FpbGluZyEuaGVhZGluZykpPjFlLTYpKWNvbnRpbnVlO1xuICAgIC8vIEFub3RoZXIgaHVsbCBjYW4gb2NjdXB5IHRoZSBjaG9zZW4gYmVydGggd2hpbGUgYSBuZWFyYnkgc3RvcCBzdGlsbFxuICAgIC8vIHJlYWNoZXMgdGhlIHNhbWUgaXNsYW5kLiBsYW5kaW5nU3BvdCBjaGVja3MgdGhlIGFjdHVhbCBodWxsIHJlYWNoIGFuZFxuICAgIC8vIHRoZSByZXF1ZXN0ZWQgc2hvcmUncyBncm91bmQgY29tcG9uZW50IGJlZm9yZSBwdXR0aW5nIGFueW9uZSBhc2hvcmUuXG4gICAgY29uc3QgYXJyaXZlZD13YWxrRW5kZWQoZ2FtZSxzaGlwLHNoaXAub3JkZXIsOCk7XG4gICAgLy8gQSBkZWZlcnJlZCByb3V0ZSBjYW4gaG9sZCB0aGUgZGVwYXJ0dXJlIHBvc2Ugd2l0aG91dCByZWFjaGluZyB0aGVcbiAgICAvLyBzaG9yZS4gS2VlcCBldmVuIGFuIGVtcHR5IHNoaXAncyB1bmxvYWQgb3JkZXIgYWN0aXZlIGR1cmluZyB0aGF0IHdhaXQuXG4gICAgY29uc3QgcGxhbm5pbmc9c2hpcC5zYWlsaW5nPy5wbGFubmluZ0pvYiE9PXVuZGVmaW5lZCB8fCBzaGlwLnNhaWxpbmc/LnBsYW5uaW5nUmVxdWVzdGVkQXRUaWNrIT09dW5kZWZpbmVkO1xuICAgIGlmKHVubG9hZENhcmdvKGdhbWUsc2hpcCk+MCB8fCBhcnJpdmVkIHx8ICFwbGFubmluZyAmJiBzaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLHNoaXApLmxlbmd0aD09PTApc2hpcC5vcmRlcj17dHlwZTpcImlkbGVcIn07XG4gIH1cbn1cblxuLy8gQSBwb3J0cmFpdCBjbGljayBsYW5kcyBvbmUgY3JldyBtZW1iZXIsIHdpdGhvdXQgcmVwbGFjaW5nIHRoZSBzaGlwJ3Mgb3JkZXIuXG5mdW5jdGlvbiB1bmxvYWRDYXJnbyhnYW1lOiBHYW1lLCBzaGlwOiBVbml0LCBwYXNzZW5nZXJJZD86IHN0cmluZykge1xuICBpZihzaGlwLmNhcmdvKXJlc3RvcmVDYXJnb0RlY2tzKGdhbWUudW5pdHMpO1xuICBjb25zdCBjcmV3PXNoaXBQYXNzZW5nZXJzKGdhbWUudW5pdHMsc2hpcCk7XG4gIGxldCBsYW5kZWQ9MDtcbiAgY3Jldy5mb3JFYWNoKChwYXNzZW5nZXIsaW5kZXgpPT57XG4gICAgaWYoaXNJbkNhYmluKHBhc3NlbmdlcikgfHwgcGFzc2VuZ2VyLm93bmVyIT09c2hpcC5vd25lciB8fCBwYXNzZW5nZXJJZCE9PXVuZGVmaW5lZCAmJiBwYXNzZW5nZXIuaWQhPT1wYXNzZW5nZXJJZClyZXR1cm47XG4gICAgY29uc3Qgc3BvdD1sYW5kaW5nU3BvdChnYW1lLm1hcCxzaGlwLGluZGV4LGNyZXcubGVuZ3RoLGdhbWUudW5pdHMscGFzc2VuZ2VyKTtcbiAgICBpZighc3BvdClyZXR1cm47XG4gICAgcGFzc2VuZ2VyLmRlY2s9dW5kZWZpbmVkO1xuICAgIHBhc3Nlbmdlci5jYWJpbj11bmRlZmluZWQ7XG4gICAgcGFzc2VuZ2VyLmFpbT11bmRlZmluZWQ7XG4gICAgT2JqZWN0LmFzc2lnbihwYXNzZW5nZXIsc3BvdCk7XG4gICAgYXNzaWduVW5pdE9yZGVyKHBhc3Nlbmdlcix7dHlwZTpcImlkbGVcIn0pO1xuICAgIGFkZEVmZmVjdChnYW1lLFwidW5sb2FkXCIsc3BvdC54LHNwb3QueSxzZWNvbmRzKC40KSx7dW5pdElkOnBhc3Nlbmdlci5pZCxvd25lcjpwYXNzZW5nZXIub3duZXIsc291cmNlS2luZDpwYXNzZW5nZXIua2luZH0pO1xuICAgIGxhbmRlZCsrO1xuICB9KTtcbiAgc3luY0RlY2tzKGdhbWUudW5pdHMpO1xuICB1cGRhdGVTdXBwbHlTdGF0ZShnYW1lKTtcbiAgcmV0dXJuIGxhbmRlZDtcbn1cblxuZnVuY3Rpb24gY2FyZ29TdXBwbHkoZ2FtZTogR2FtZSwgc2hpcDogVW5pdCkge1xuICByZXR1cm4gKHNoaXAuY2FyZ28gPz8gW10pLnJlZHVjZSgoc3VtLHBhc3Nlbmdlcik9PnN1bSt1bml0UnVsZXMoZ2FtZSxwYXNzZW5nZXIpLnN1cHBseVVzZWQsMCk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUJ1aWxkT3JkZXIoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5vcmRlci50eXBlICE9PSBcImJ1aWxkXCIgfHwgIWlzUGxheWVySWQodW5pdC5vd25lcikpIHJldHVybjtcbiAgY29uc3Qgb3JkZXIgPSB1bml0Lm9yZGVyO1xuICBjb25zdCBkZWYgPSBCVUlMRElOR19ERUZTW29yZGVyLmJ1aWxkaW5nS2luZF07XG4gIGNvbnN0IGhhbGYgPSBmb290cHJpbnRIYWxmKGRlZi5yYWRpdXMsIFRFUlJBSU5fQ0VMTCk7XG4gIGNvbnN0IGdhcCA9IE1hdGguaHlwb3QoTWF0aC5tYXgoMCwgTWF0aC5hYnModW5pdC54LW9yZGVyLngpLWhhbGYpLCBNYXRoLm1heCgwLCBNYXRoLmFicyh1bml0Lnktb3JkZXIueSktaGFsZikpO1xuICBpZiAoZ2FwID4gQlVJTERJTkdfV09SS19SRUFDSCkge1xuICAgIC8vIFRyYWNrIG1vdmVtZW50IHJhdGhlciB0aGFuIGEgZml4ZWQgam91cm5leSBsaW1pdDogbG9uZyB3YWxrcyBhcmUgdmFsaWQsIGJsb2NrZWQgcGxhbnMgbXVzdCByZWxlYXNlIHRoZWlyIHdvcmtlci5cbiAgICBpZiAob3JkZXIucHJvZ3Jlc3NUaWNrID09PSB1bmRlZmluZWQgfHwgTWF0aC5oeXBvdCh1bml0LnggLSAob3JkZXIucHJvZ3Jlc3NYID8/IHVuaXQueCksIHVuaXQueSAtIChvcmRlci5wcm9ncmVzc1kgPz8gdW5pdC55KSkgPiAyNCkge1xuICAgICAgb3JkZXIucHJvZ3Jlc3NUaWNrID0gZ2FtZS50aWNrOyBvcmRlci5wcm9ncmVzc1ggPSB1bml0Lng7IG9yZGVyLnByb2dyZXNzWSA9IHVuaXQueTtcbiAgICB9IGVsc2UgaWYgKGdhbWUudGljayAtIG9yZGVyLnByb2dyZXNzVGljayA+IHNlY29uZHMoMjApKSB7XG4gICAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9OyByZXR1cm47XG4gICAgfVxuICAgIG1vdmVUb3dhcmQodW5pdCwgb3JkZXIueCwgb3JkZXIueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMpOyByZXR1cm47XG4gIH1cbiAgLy8gUmV2YWxpZGF0ZSBhdCBhcnJpdmFsOiB0d28gYnVpbGRlcnMgY2Fubm90IGNsYWltIHRoZSBzYW1lIHNpdGUsIGFuZCBtb25leSBpcyBwYWlkIG9ubHkgb24gYnJlYWtpbmcgZ3JvdW5kLlxuICBpZiAoYnVpbGRpbmdQbGFjZW1lbnRCbG9ja2VyKGdhbWUsIG9yZGVyLmJ1aWxkaW5nS2luZCwgb3JkZXIpIHx8IHRlcnJhaW5CbG9ja3NQbGFjZW1lbnQoZ2FtZS5tYXAsIG9yZGVyLmJ1aWxkaW5nS2luZCwgb3JkZXIpKSB7XG4gICAgdW5pdC5vcmRlciA9IHsgdHlwZTogXCJpZGxlXCIgfTsgcmV0dXJuO1xuICB9XG4gIGlmIChwbGF5ZXJTdGF0ZShnYW1lLCB1bml0Lm93bmVyKS5nb2xkIDwgZGVmLmNvc3QpIHJldHVybjsgLy8gV2FpdCBmb3IgZnVuZHMsIHJldGFpbmluZyB0aGUgdmlzaWJsZSBwbGFuLlxuICBzcGVuZEdvbGQoZ2FtZSwgdW5pdC5vd25lciwgZGVmLmNvc3QpO1xuICBjb25zdCBidWlsZGluZyA9IGNyZWF0ZUJ1aWxkaW5nKGBidWlsZGluZy0ke3VuaXQub3duZXJ9LSR7b3JkZXIuYnVpbGRpbmdLaW5kfS0ke2dhbWUubmV4dElkKyt9YCwgdW5pdC5vd25lciwgb3JkZXIuYnVpbGRpbmdLaW5kLCBvcmRlci54LCBvcmRlci55LCBmYWxzZSk7XG4gIGFwcGx5RGVyaXZlZEJ1aWxkaW5nU3RhdHMoZ2FtZSwgYnVpbGRpbmcpO1xuICBidWlsZGluZy5ocCA9IGNvbnN0cnVjdGlvblN0YXJ0SHAoYnVpbGRpbmcubWF4SHApO1xuICBnYW1lLmJ1aWxkaW5ncy5wdXNoKGJ1aWxkaW5nKTtcbiAgc3luY0J1aWxkaW5nQm9kaWVzKGdhbWUpO1xuICB1bml0Lm9yZGVyID0geyB0eXBlOiBcInJlcGFpclwiLCBidWlsZGluZ0lkOiBidWlsZGluZy5pZCB9O1xuICBhZGRFZmZlY3QoZ2FtZSwgXCJidWlsZFwiLCBidWlsZGluZy54LCBidWlsZGluZy55LCA2MCk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVJlcGFpck9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgaWYgKHVuaXQub3JkZXIudHlwZSAhPT0gXCJyZXBhaXJcIiB8fCAhaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSkgcmV0dXJuO1xuICBjb25zdCBvcmRlciA9IHVuaXQub3JkZXI7XG4gIGNvbnN0IGJ1aWxkaW5nID0gZ2FtZS5idWlsZGluZ3MuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IG9yZGVyLmJ1aWxkaW5nSWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSB1bml0Lm93bmVyKTtcbiAgaWYgKCFidWlsZGluZyB8fCBidWlsZGluZy5ocCA8PSAwIHx8IChidWlsZGluZy5jb21wbGV0ZSAmJiBidWlsZGluZy5ocCA+PSBidWlsZGluZy5tYXhIcCkpIHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoYnVpbGRpbmdXb3JrR2FwKHVuaXQsIGJ1aWxkaW5nKSA+IEJVSUxESU5HX1dPUktfUkVBQ0gpIHtcbiAgICBtb3ZlVG93YXJkKHVuaXQsIGJ1aWxkaW5nLngsIGJ1aWxkaW5nLnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gQSBzaXRlIGdvZXMgdXAgd2l0aCBpdHMgYnVpbGRlcnMnIHdvcmsgKHNlZSB1cGRhdGVDb25zdHJ1Y3Rpb24pOyBhIHN0YW5kaW5nIGJ1aWxkaW5nIGlzIG1lbmRlZC5cbiAgaWYgKCFidWlsZGluZy5jb21wbGV0ZSB8fCB1bml0LmNvb2xkb3duID4gMCkgcmV0dXJuO1xuICBpZiAoIXJlcGFpckJ1aWxkaW5nVGljayhnYW1lLCB1bml0LCBidWlsZGluZykpIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUF1dG9SZXBhaXIoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5vcmRlci50eXBlICE9PSBcImlkbGVcIiB8fCAhaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSkgcmV0dXJuIGZhbHNlO1xuICBpZiAodW5pdC5jb29sZG93biA+IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3QgYnVpbGRpbmcgPSBnYW1lLmJ1aWxkaW5ncy5maW5kKFxuICAgIChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5vd25lciA9PT0gdW5pdC5vd25lciAmJiBjYW5kaWRhdGUuY29tcGxldGUgJiYgY2FuZGlkYXRlLmhwID4gMCAmJiBjYW5kaWRhdGUuaHAgPCBjYW5kaWRhdGUubWF4SHAgJiYgYnVpbGRpbmdXb3JrR2FwKHVuaXQsIGNhbmRpZGF0ZSkgPD0gQlVJTERJTkdfV09SS19SRUFDSCxcbiAgKTtcbiAgaWYgKCFidWlsZGluZykgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gcmVwYWlyQnVpbGRpbmdUaWNrKGdhbWUsIHVuaXQsIGJ1aWxkaW5nKTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlVW5pdFJlcGFpck9yZGVyKGdhbWU6IEdhbWUsIHdvcmtlcjogVW5pdCkge1xuICBpZiAod29ya2VyLm9yZGVyLnR5cGUgIT09IFwicmVwYWlyVW5pdFwiICYmIHdvcmtlci5vcmRlci50eXBlICE9PSBcInJlcGFpclNoaXBcIikgcmV0dXJuO1xuICBpZiAod29ya2VyLmtpbmQgIT09IFwid29ya2VyXCIgfHwgIWlzUGxheWVySWQod29ya2VyLm93bmVyKSkgeyB3b3JrZXIub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07IHJldHVybjsgfVxuICBjb25zdCB0YXJnZXRJZCA9IHdvcmtlci5vcmRlci50YXJnZXRJZDtcbiAgY29uc3QgdGFyZ2V0ID0gZ2FtZS51bml0cy5maW5kKHVuaXQgPT4gdW5pdC5pZCA9PT0gdGFyZ2V0SWQgJiYgdW5pdC5vd25lciA9PT0gd29ya2VyLm93bmVyXG4gICAgJiYgKHdvcmtlci5vcmRlci50eXBlICE9PSBcInJlcGFpclNoaXBcIiB8fCB1bml0TW92ZXIodW5pdC5raW5kKSA9PT0gXCJzZWFcIikpO1xuICBpZiAoIXRhcmdldCB8fCAhdW5pdE5lZWRzUmVwYWlyKGdhbWUsIHRhcmdldCkpIHsgd29ya2VyLm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9OyByZXR1cm47IH1cbiAgY29uc3Qgc2hpcCA9IEJvb2xlYW4oc2hpcFByb2ZpbGUodGFyZ2V0KSk7XG4gIGNvbnN0IHNhbWVXb3JrU3VyZmFjZSA9IHNoaXAgPyB3b3JrZXIuZGVjaz8uc2hpcElkID09PSB0YXJnZXQuaWQgOiB3b3JrZXIuZGVjaz8uc2hpcElkID09PSB0YXJnZXQuZGVjaz8uc2hpcElkO1xuICBjb25zdCB3aXRoaW5SZWFjaCA9IGRpc3RhbmNlKHdvcmtlciwgdGFyZ2V0KSA8PSB3b3JrZXIucmFkaXVzICsgdGFyZ2V0LnJhZGl1cyArIEJVSUxESU5HX1dPUktfUkVBQ0g7XG4gIC8vIENyZXcgY2FuIHdvcmsgYW55d2hlcmUgb24gdGhlaXIgb3duIGh1bGw7IHNlcGFyYXRlIGdyb3VuZC9kZWNrIHVuaXRzIG11c3RcbiAgLy8gc2hhcmUgYSBzdXJmYWNlIGFuZCBzdGFuZCB3aXRoaW4gd29ya2luZyByZWFjaC5cbiAgY29uc3QgY2FuV29ya0hlcmUgPSBzaGlwID8gc2FtZVdvcmtTdXJmYWNlIHx8ICF3b3JrZXIuZGVjayAmJiB3aXRoaW5SZWFjaCA6IHNhbWVXb3JrU3VyZmFjZSAmJiB3aXRoaW5SZWFjaDtcbiAgaWYgKCFjYW5Xb3JrSGVyZSkge1xuICAgIG1vdmVUb3dhcmQod29ya2VyLCB0YXJnZXQueCwgdGFyZ2V0LnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgICByZXR1cm47XG4gIH1cbiAgcmVwYWlyVW5pdFRpY2soZ2FtZSwgd29ya2VyLCB0YXJnZXQpO1xuICBpZiAoIXVuaXROZWVkc1JlcGFpcihnYW1lLCB0YXJnZXQpKSB3b3JrZXIub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG59XG5cbmZ1bmN0aW9uIGF1dG9SZXBhaXJEZWNrU2hpcChnYW1lOiBHYW1lLCB3b3JrZXI6IFVuaXQpIHtcbiAgaWYgKHdvcmtlci5raW5kICE9PSBcIndvcmtlclwiIHx8ICF3b3JrZXIuZGVjayB8fCAhaXNQbGF5ZXJJZCh3b3JrZXIub3duZXIpIHx8IHdvcmtlci5vcmRlclF1ZXVlPy5sZW5ndGggfHwgIVtcImlkbGVcIiwgXCJob2xkXCJdLmluY2x1ZGVzKHdvcmtlci5vcmRlci50eXBlKSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBzaGlwPWdhbWUudW5pdHMuZmluZCh1bml0PT51bml0LmlkPT09d29ya2VyLmRlY2shLnNoaXBJZCAmJiB1bml0Lm93bmVyPT09d29ya2VyLm93bmVyICYmIHVuaXQuaHA+MCk7XG4gIGlmICghc2hpcCB8fCAhc2hpcFByb2ZpbGUoc2hpcCkgfHwgIXVuaXROZWVkc1JlcGFpcihnYW1lLHNoaXApIHx8IHBsYXllclN0YXRlKGdhbWUsd29ya2VyLm93bmVyKS5nb2xkPDEpIHJldHVybiBmYWxzZTtcbiAgcmVwYWlyVW5pdFRpY2soZ2FtZSx3b3JrZXIsc2hpcCk7XG4gIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiByZXBhaXJVbml0VGljayhnYW1lOiBHYW1lLCB3b3JrZXI6IFVuaXQsIHRhcmdldDogVW5pdCkge1xuICBpZiAod29ya2VyLmtpbmQgIT09IFwid29ya2VyXCIgfHwgIWlzUGxheWVySWQod29ya2VyLm93bmVyKSB8fCB0YXJnZXQub3duZXIgIT09IHdvcmtlci5vd25lciB8fCAhdW5pdE5lZWRzUmVwYWlyKGdhbWUsIHRhcmdldCkpIHJldHVybjtcbiAgaWYgKHdvcmtlci5jb29sZG93biA+IDApIHJldHVybjtcbiAgY29uc3QgcGxheWVyID0gcGxheWVyU3RhdGUoZ2FtZSwgd29ya2VyLm93bmVyKTtcbiAgaWYgKHBsYXllci5nb2xkIDwgMSkgcmV0dXJuO1xuICBlbWl0V29ya2VyV29yayhnYW1lLCB3b3JrZXIsIHRhcmdldCk7XG4gIGNvbnN0IGhlYWxlZCA9IHVuaXRSZXBhaXJIcFBlckdvbGQoZ2FtZSwgdGFyZ2V0KTtcbiAgc3BlbmRHb2xkKGdhbWUsIHdvcmtlci5vd25lciwgMSk7XG4gIGlmIChzaGlwUHJvZmlsZSh0YXJnZXQpKSByZXBhaXJTaGlwUGFydHMoZ2FtZSx0YXJnZXQsaGVhbGVkKTtcbiAgZWxzZSB0YXJnZXQuaHAgPSBNYXRoLm1pbih0YXJnZXQubWF4SHAsIHRhcmdldC5ocCArIGhlYWxlZCk7XG4gIHdvcmtlci5jb29sZG93biA9IHNlY29uZHMoaGVhbGVkIC8gUkVQQUlSX0hQX1BFUl9TRUNPTkQpO1xufVxuXG5mdW5jdGlvbiBlbWl0V29ya2VyV29yayhnYW1lOiBHYW1lLCB3b3JrZXI6IFVuaXQsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nKSB7XG4gIGlmIChnYW1lLmVmZmVjdHMuc29tZShlZmZlY3QgPT4gZWZmZWN0LnR5cGUgPT09IFwicmVwYWlyXCIgJiYgZWZmZWN0LnVuaXRJZCA9PT0gd29ya2VyLmlkKSkgcmV0dXJuO1xuICAvLyBBY3R1YWwgd29yayBkcml2ZXMgdW5pdCBwb3NlcyBhbmQgc291bmQsIG5ldmVyIGEgZmxvYXRpbmcgdG9vbCBpY29uLlxuICAvLyBQcmVzZW50YXRpb24gSURzIG11c3Qgbm90IGFkdmFuY2UgdGhlIGVudGl0eSBjb3VudGVyIG9yIGNoYW5nZSBhcm15IG9yZGVyaW5nLlxuICBnYW1lLmVmZmVjdHMucHVzaCh7IGlkOiBgd29yay0ke3dvcmtlci5pZH0tJHtnYW1lLnRpY2t9YCwgdHlwZTogXCJyZXBhaXJcIiwgeDp3b3JrZXIueCwgeTp3b3JrZXIueSxcbiAgICBkdXJhdGlvbjpzZWNvbmRzKDAuNjUpLCByZW1haW5pbmc6c2Vjb25kcygwLjY1KSwgdW5pdElkOndvcmtlci5pZCwgZnJvbVg6dGFyZ2V0LngsIGZyb21ZOnRhcmdldC55IH0pO1xufVxuXG5mdW5jdGlvbiByZXBhaXJCdWlsZGluZ1RpY2soZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgYnVpbGRpbmc6IEJ1aWxkaW5nKSB7XG4gIGlmICghaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBvd25lciA9IHVuaXQub3duZXI7XG4gIGNvbnN0IHBsYXllciA9IHBsYXllclN0YXRlKGdhbWUsIG93bmVyKTtcbiAgaWYgKHBsYXllci5nb2xkIDwgMSB8fCBidWlsZGluZy5ocCA+PSBidWlsZGluZy5tYXhIcCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBmdWxsUmVwYWlyQ29zdCA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQoQlVJTERJTkdfREVGU1tidWlsZGluZy5raW5kXS5jb3N0ICogUkVQQUlSX0ZVTExfQ09TVF9GUkFDVElPTikpO1xuICBjb25zdCBocFBlckdvbGQgPSBNYXRoLm1heCgxLCBidWlsZGluZy5tYXhIcCAvIGZ1bGxSZXBhaXJDb3N0KTtcbiAgc3BlbmRHb2xkKGdhbWUsIG93bmVyLCAxKTtcbiAgYnVpbGRpbmcuaHAgPSBNYXRoLm1pbihidWlsZGluZy5tYXhIcCwgYnVpbGRpbmcuaHAgKyBocFBlckdvbGQpO1xuICB1bml0LmNvb2xkb3duID0gc2Vjb25kcyhocFBlckdvbGQgLyBSRVBBSVJfSFBfUEVSX1NFQ09ORCk7XG4gIGVtaXRXb3JrZXJXb3JrKGdhbWUsIHVuaXQsIGJ1aWxkaW5nKTtcbiAgYWRkUmVwYWlySGFtbWVyRWZmZWN0KGdhbWUsIGJ1aWxkaW5nKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbmZ1bmN0aW9uIGFkZFJlcGFpckhhbW1lckVmZmVjdChnYW1lOiBHYW1lLCBidWlsZGluZzogQnVpbGRpbmcsIHF1ZXVlZCA9IGZhbHNlKSB7XG4gIGNvbnN0IGFjdGl2ZVR5cGUgPSBxdWV1ZWQgPyBbXCJyZXBhaXJcIiwgXCJxdWV1ZWRSZXBhaXJcIl0gOiBbXCJyZXBhaXJcIl07XG4gIGlmIChnYW1lLmVmZmVjdHMuc29tZSgoZWZmZWN0KSA9PiBhY3RpdmVUeXBlLmluY2x1ZGVzKGVmZmVjdC50eXBlKSAmJiBlZmZlY3QueCA9PT0gYnVpbGRpbmcueCAmJiBlZmZlY3QueSA9PT0gYnVpbGRpbmcueSkpIHJldHVybjtcbiAgYWRkRWZmZWN0KGdhbWUsIHF1ZXVlZCA/IFwicXVldWVkUmVwYWlyXCIgOiBcInJlcGFpclwiLCBidWlsZGluZy54LCBidWlsZGluZy55LCBSRVBBSVJfSEFNTUVSX0VGRkVDVF9EVVJBVElPTiwgeyBvd25lcjogYnVpbGRpbmcub3duZXIgfSk7XG59XG5cbmZ1bmN0aW9uIHF1ZXVlVHJhaW5pbmcoZ2FtZTogR2FtZSwgYnVpbGRpbmc6IEJ1aWxkaW5nLCB1bml0S2luZDogVHJhaW5hYmxlVW5pdEtpbmQpIHtcbiAgaWYgKCFidWlsZGluZy5jb21wbGV0ZSkgdGhyb3cgbmV3IEVycm9yKGBDYW5ub3QgdHJhaW4gZnJvbSBpbmNvbXBsZXRlICR7YnVpbGRpbmcua2luZH1gKTtcbiAgaWYgKCFjYW5UcmFpbkF0KHBsYXllclN0YXRlKGdhbWUsIGJ1aWxkaW5nLm93bmVyKS5yYWNlLCBidWlsZGluZy5raW5kLCB1bml0S2luZCkpIHRocm93IG5ldyBFcnJvcihgJHtidWlsZGluZy5raW5kfSBjYW5ub3QgdHJhaW4gJHt1bml0S2luZH0gZm9yICR7cGxheWVyU3RhdGUoZ2FtZSwgYnVpbGRpbmcub3duZXIpLnJhY2V9YCk7XG4gIGNvbnN0IGNhcCA9IHJlcXVpcmVkU3VwcGx5Q2FwKHVuaXRLaW5kKTtcbiAgaWYgKHBsYXllclN0YXRlKGdhbWUsIGJ1aWxkaW5nLm93bmVyKS5zdXBwbHlDYXAgPCBjYXApIHRocm93IG5ldyBFcnJvcihgTmVlZCBhIHN1cHBseSBjYXAgb2YgJHtjYXB9IHRvIHRyYWluICR7dW5pdEtpbmR9YCk7XG4gIGlmIChwcm9qZWN0ZWRTdXBwbHlVc2VkKGdhbWUsIGJ1aWxkaW5nLm93bmVyKSArIFVOSVRfREVGU1t1bml0S2luZF0uc3VwcGx5VXNlZCA+IHBsYXllclN0YXRlKGdhbWUsIGJ1aWxkaW5nLm93bmVyKS5zdXBwbHlDYXApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYE5lZWQgbW9yZSBzdXBwbHkgdG8gdHJhaW4gJHt1bml0S2luZH1gKTtcbiAgfVxuICBzcGVuZEdvbGQoZ2FtZSwgYnVpbGRpbmcub3duZXIsIFVOSVRfREVGU1t1bml0S2luZF0uY29zdCk7XG4gIGJ1aWxkaW5nLnF1ZXVlLnB1c2goeyBpZDogYHRyYWluaW5nLSR7Z2FtZS5uZXh0SWQrK31gLCB1bml0S2luZCwgcmVtYWluaW5nOiB0cmFpblRpbWVGb3IodW5pdEtpbmQpLCBwYWlkR29sZDpVTklUX0RFRlNbdW5pdEtpbmRdLmNvc3QgfSk7XG4gIHVwZGF0ZVN1cHBseVN0YXRlKGdhbWUpO1xufVxuXG5mdW5jdGlvbiBzZXRSYWxseShnYW1lOiBHYW1lLCBvd25lcjogUGxheWVySWQsIGJ1aWxkaW5nSWRzOiBzdHJpbmdbXSwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHRhcmdldDogUmFsbHlUYXJnZXQgfCB1bmRlZmluZWQpIHtcbiAgY29uc3QgYnVpbGRpbmdzID0gYnVpbGRpbmdzQnlJZHMoZ2FtZSwgYnVpbGRpbmdJZHMsIG93bmVyKTtcbiAgY29uc3Qgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZVJhbGx5VGFyZ2V0KGdhbWUsIG93bmVyLCB4LCB5LCB0YXJnZXQpO1xuICBmb3IgKGNvbnN0IGJ1aWxkaW5nIG9mIGJ1aWxkaW5ncykge1xuICAgIGlmIChCVUlMRElOR19ERUZTW2J1aWxkaW5nLmtpbmRdLnRyYWlucy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcihgJHtidWlsZGluZy5raW5kfSBoYXMgbm8gdHJhaW5pbmcgcmFsbHkgcG9pbnRgKTtcbiAgICBidWlsZGluZy5yYWxseVggPSBub3JtYWxpemVkLng7XG4gICAgYnVpbGRpbmcucmFsbHlZID0gbm9ybWFsaXplZC55O1xuICAgIGJ1aWxkaW5nLnJhbGx5VGFyZ2V0ID0gbm9ybWFsaXplZC50YXJnZXQ7XG4gIH1cbiAgYWRkRWZmZWN0KGdhbWUsIFwibW92ZVwiLCBub3JtYWxpemVkLngsIG5vcm1hbGl6ZWQueSwgMjQsIHsgb3duZXIgfSk7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJhbGx5VGFyZ2V0KGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHRhcmdldDogUmFsbHlUYXJnZXQgfCB1bmRlZmluZWQpIHtcbiAgaWYgKCF0YXJnZXQgfHwgdGFyZ2V0LnR5cGUgPT09IFwicG9pbnRcIikge1xuICAgIHJldHVybiB7IHg6IGNsYW1wKHgsIDAsIGdhbWUubWFwLndpZHRoKSwgeTogY2xhbXAoeSwgMCwgZ2FtZS5tYXAuaGVpZ2h0KSwgdGFyZ2V0OiB7IHR5cGU6IFwicG9pbnRcIiB9IGFzIFJhbGx5VGFyZ2V0IH07XG4gIH1cbiAgaWYgKHRhcmdldC50eXBlID09PSBcInJlc291cmNlXCIpIHtcbiAgICBjb25zdCByZXNvdXJjZSA9IGdhbWUucmVzb3VyY2VzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSB0YXJnZXQucmVzb3VyY2VJZCk7XG4gICAgaWYgKCFyZXNvdXJjZSkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIHJhbGx5IHJlc291cmNlICR7dGFyZ2V0LnJlc291cmNlSWR9YCk7XG4gICAgcmV0dXJuIHsgeDogcmVzb3VyY2UueCwgeTogcmVzb3VyY2UueSwgdGFyZ2V0IH07XG4gIH1cbiAgY29uc3QgdW5pdCA9IGdhbWUudW5pdHMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IHRhcmdldC51bml0SWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSBvd25lcik7XG4gIGlmICghdW5pdCkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IHJhbGx5IHVuaXQgJHt0YXJnZXQudW5pdElkfWApO1xuICByZXR1cm4geyB4OiB1bml0LngsIHk6IHVuaXQueSwgdGFyZ2V0IH07XG59XG5cbmZ1bmN0aW9uIHJhbGx5T3JkZXJGb3JVbml0KGdhbWU6IEdhbWUsIGJ1aWxkaW5nOiBCdWlsZGluZywgdW5pdDogVW5pdCk6IFVuaXRbXCJvcmRlclwiXSB7XG4gIGNvbnN0IHRhcmdldCA9IGJ1aWxkaW5nLnJhbGx5VGFyZ2V0O1xuICBpZiAodGFyZ2V0Py50eXBlID09PSBcInJlc291cmNlXCIgJiYgdW5pdC5raW5kID09PSBcIndvcmtlclwiICYmIGdhbWUucmVzb3VyY2VzLnNvbWUoKHJlc291cmNlKSA9PiByZXNvdXJjZS5pZCA9PT0gdGFyZ2V0LnJlc291cmNlSWQgJiYgcmVzb3VyY2UuYW1vdW50ID4gMCkpIHtcbiAgICByZXR1cm4geyB0eXBlOiBcIm1pbmVcIiwgcmVzb3VyY2VJZDogdGFyZ2V0LnJlc291cmNlSWQsIHBoYXNlOiBcInRvTWluZVwiLCB0aW1lcjogMCB9O1xuICB9XG4gIGlmICh0YXJnZXQ/LnR5cGUgPT09IFwidW5pdFwiICYmIGdhbWUudW5pdHMuc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IHRhcmdldC51bml0SWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSB1bml0Lm93bmVyICYmIGNhbmRpZGF0ZS5ocCA+IDApKSB7XG4gICAgcmV0dXJuIHsgdHlwZTogXCJmb2xsb3dcIiwgdGFyZ2V0SWQ6IHRhcmdldC51bml0SWQgfTtcbiAgfVxuICByZXR1cm4geyB0eXBlOiBcIm1vdmVcIiwgeDogYnVpbGRpbmcucmFsbHlYLCB5OiBidWlsZGluZy5yYWxseVkgfTtcbn1cblxuZnVuY3Rpb24gcXVldWVSZXNlYXJjaChnYW1lOiBHYW1lLCBidWlsZGluZzogQnVpbGRpbmcsIHVwZ3JhZGVLaW5kOiBVcGdyYWRlS2luZCkge1xuICBpZiAoIWJ1aWxkaW5nLmNvbXBsZXRlKSB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCByZXNlYXJjaCBmcm9tIGluY29tcGxldGUgJHtidWlsZGluZy5raW5kfWApO1xuICBjb25zdCB1cGdyYWRlID0gVVBHUkFERV9ERUZTW3VwZ3JhZGVLaW5kXTtcbiAgaWYgKCF1cGdyYWRlKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gdXBncmFkZSAke3VwZ3JhZGVLaW5kfWApO1xuICBpZiAoIVJBQ0VfREVGU1twbGF5ZXJTdGF0ZShnYW1lLCBidWlsZGluZy5vd25lcikucmFjZV0udXBncmFkZXMuaW5jbHVkZXModXBncmFkZUtpbmQpKSB0aHJvdyBuZXcgRXJyb3IoYCR7cGxheWVyU3RhdGUoZ2FtZSwgYnVpbGRpbmcub3duZXIpLnJhY2V9IHJhY2UgY2Fubm90IHJlc2VhcmNoICR7dXBncmFkZUtpbmR9YCk7XG4gIGlmICghY2FuUmVzZWFyY2hBdChwbGF5ZXJTdGF0ZShnYW1lLCBidWlsZGluZy5vd25lcikucmFjZSwgYnVpbGRpbmcua2luZCwgdXBncmFkZUtpbmQpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGAke2J1aWxkaW5nLmtpbmR9IGNhbm5vdCByZXNlYXJjaCAke3VwZ3JhZGVLaW5kfWApO1xuICB9XG4gIGNvbnN0IHBsYXllciA9IHBsYXllclN0YXRlKGdhbWUsIGJ1aWxkaW5nLm93bmVyKTtcbiAgY29uc3QgY3VycmVudExldmVsID0gcGxheWVyLnVwZ3JhZGVzW3VwZ3JhZGVLaW5kXSA/PyAwO1xuICBpZiAoY3VycmVudExldmVsID49IG1heFVwZ3JhZGVMZXZlbCh1cGdyYWRlS2luZCkpIHRocm93IG5ldyBFcnJvcihgJHt1cGdyYWRlS2luZH0gYWxyZWFkeSBhdCBtYXggbGV2ZWxgKTtcbiAgaWYgKGJ1aWxkaW5nLnJlc2VhcmNoUXVldWUuc29tZSgoam9iKSA9PiBqb2IudXBncmFkZUtpbmQgPT09IHVwZ3JhZGVLaW5kKSkgdGhyb3cgbmV3IEVycm9yKGAke3VwZ3JhZGVLaW5kfSBpcyBhbHJlYWR5IHF1ZXVlZGApO1xuICBjb25zdCB0YXJnZXRMZXZlbCA9IGN1cnJlbnRMZXZlbCArIDE7XG4gIGNvbnN0IGxldmVsID0gdXBncmFkZS5sZXZlbHNbdGFyZ2V0TGV2ZWwgLSAxXTtcbiAgaWYgKCFsZXZlbCkgdGhyb3cgbmV3IEVycm9yKGAke3VwZ3JhZGVLaW5kfSBtaXNzaW5nIGxldmVsICR7dGFyZ2V0TGV2ZWx9YCk7XG4gIHNwZW5kR29sZChnYW1lLCBidWlsZGluZy5vd25lciwgbGV2ZWwuY29zdCk7XG4gIGJ1aWxkaW5nLnJlc2VhcmNoUXVldWUucHVzaCh7IHVwZ3JhZGVLaW5kLCB0YXJnZXRMZXZlbCwgcmVtYWluaW5nOiBsZXZlbC5yZXNlYXJjaFRpbWUgfSk7XG59XG5cbmZ1bmN0aW9uIGNvbXBsZXRlUmVzZWFyY2goZ2FtZTogR2FtZSwgb3duZXI6IFBsYXllcklkLCB1cGdyYWRlS2luZDogVXBncmFkZUtpbmQsIHRhcmdldExldmVsOiBudW1iZXIpIHtcbiAgY29uc3QgcGxheWVyID0gcGxheWVyU3RhdGUoZ2FtZSwgb3duZXIpO1xuICBjb25zdCBjdXJyZW50TGV2ZWwgPSBwbGF5ZXIudXBncmFkZXNbdXBncmFkZUtpbmRdID8/IDA7XG4gIGlmICh0YXJnZXRMZXZlbCA8PSBjdXJyZW50TGV2ZWwpIHJldHVybjtcbiAgaWYgKHRhcmdldExldmVsICE9PSBjdXJyZW50TGV2ZWwgKyAxKSB0aHJvdyBuZXcgRXJyb3IoYCR7dXBncmFkZUtpbmR9IHJlc2VhcmNoIGNvbXBsZXRlZCBvdXQgb2Ygb3JkZXJgKTtcbiAgcGxheWVyLnVwZ3JhZGVzW3VwZ3JhZGVLaW5kXSA9IHRhcmdldExldmVsO1xuICBmb3IgKGNvbnN0IHVuaXQgb2YgZ2FtZS51bml0cy5maWx0ZXIoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLm93bmVyID09PSBvd25lcikpIHtcbiAgICBhcHBseVVwZ3JhZGVMZXZlbFRvVW5pdChnYW1lLCB1bml0LCB1cGdyYWRlS2luZCwgdGFyZ2V0TGV2ZWwpO1xuICB9XG4gIGZvciAoY29uc3QgYnVpbGRpbmcgb2YgZ2FtZS5idWlsZGluZ3MuZmlsdGVyKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5vd25lciA9PT0gb3duZXIpKSB7XG4gICAgYXBwbHlVcGdyYWRlTGV2ZWxUb0J1aWxkaW5nKGdhbWUsIGJ1aWxkaW5nLCB1cGdyYWRlS2luZCwgdGFyZ2V0TGV2ZWwpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFwcGx5VW5pdFVwZ3JhZGVzKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgaWYgKCFpc1BsYXllcklkKHVuaXQub3duZXIpKSByZXR1cm47XG4gIGFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLCB1bml0KTtcbn1cblxuZnVuY3Rpb24gYXBwbHlVcGdyYWRlTGV2ZWxUb1VuaXQoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgdXBncmFkZUtpbmQ6IFVwZ3JhZGVLaW5kLCBsZXZlbDogbnVtYmVyKSB7XG4gIGNvbnN0IHVwZ3JhZGUgPSBVUEdSQURFX0RFRlNbdXBncmFkZUtpbmRdO1xuICBjb25zdCBsZXZlbERlZiA9IHVwZ3JhZGUubGV2ZWxzW2xldmVsIC0gMV07XG4gIGlmICghbGV2ZWxEZWYpIHRocm93IG5ldyBFcnJvcihgJHt1cGdyYWRlS2luZH0gbWlzc2luZyBsZXZlbCAke2xldmVsfWApO1xuICBpZiAoIXVwZ3JhZGUuYWZmZWN0ZWRVbml0S2luZHMuaW5jbHVkZXModW5pdC5raW5kIGFzIFRyYWluYWJsZVVuaXRLaW5kKSkgcmV0dXJuO1xuICBhcHBseURlcml2ZWRVbml0U3RhdHMoZ2FtZSwgdW5pdCk7XG59XG5cbmZ1bmN0aW9uIGFwcGx5VXBncmFkZUxldmVsVG9CdWlsZGluZyhnYW1lOiBHYW1lLCBidWlsZGluZzogQnVpbGRpbmcsIHVwZ3JhZGVLaW5kOiBVcGdyYWRlS2luZCwgbGV2ZWw6IG51bWJlcikge1xuICBjb25zdCB1cGdyYWRlID0gVVBHUkFERV9ERUZTW3VwZ3JhZGVLaW5kXTtcbiAgY29uc3QgbGV2ZWxEZWYgPSB1cGdyYWRlLmxldmVsc1tsZXZlbCAtIDFdO1xuICBpZiAoIWxldmVsRGVmKSB0aHJvdyBuZXcgRXJyb3IoYCR7dXBncmFkZUtpbmR9IG1pc3NpbmcgbGV2ZWwgJHtsZXZlbH1gKTtcbiAgaWYgKCFsZXZlbERlZi5idWlsZGluZ01heEhwTXVsdGlwbGllcikgcmV0dXJuO1xuICBhcHBseURlcml2ZWRCdWlsZGluZ1N0YXRzKGdhbWUsIGJ1aWxkaW5nKTtcbn1cblxuZnVuY3Rpb24gYXBwbHlEZXJpdmVkQnVpbGRpbmdTdGF0cyhnYW1lOiBHYW1lLCBidWlsZGluZzogQnVpbGRpbmcpIHtcbiAgY29uc3QgcHJldmlvdXNNYXhIcCA9IGJ1aWxkaW5nLm1heEhwO1xuICBjb25zdCBkZWYgPSBCVUlMRElOR19ERUZTW2J1aWxkaW5nLmtpbmRdO1xuICBsZXQgbWF4SHAgPSBkZWYuaHA7XG4gIGZvciAoY29uc3QgdXBncmFkZUtpbmQgb2YgVVBHUkFERV9LSU5EUykge1xuICAgIGNvbnN0IHVwZ3JhZGVMZXZlbCA9IHBsYXllclN0YXRlKGdhbWUsIGJ1aWxkaW5nLm93bmVyKS51cGdyYWRlc1t1cGdyYWRlS2luZF0gPz8gMDtcbiAgICBmb3IgKGxldCBsZXZlbCA9IDA7IGxldmVsIDwgdXBncmFkZUxldmVsOyBsZXZlbCArPSAxKSB7XG4gICAgICBjb25zdCBsZXZlbERlZiA9IFVQR1JBREVfREVGU1t1cGdyYWRlS2luZF0ubGV2ZWxzW2xldmVsXTtcbiAgICAgIGlmICghbGV2ZWxEZWY/LmJ1aWxkaW5nTWF4SHBNdWx0aXBsaWVyKSBjb250aW51ZTtcbiAgICAgIG1heEhwID0gTWF0aC5yb3VuZChtYXhIcCAqIGxldmVsRGVmLmJ1aWxkaW5nTWF4SHBNdWx0aXBsaWVyKTtcbiAgICB9XG4gIH1cbiAgYnVpbGRpbmcubWF4SHAgPSBtYXhIcDtcbiAgYnVpbGRpbmcuaHAgPSBNYXRoLm1pbihidWlsZGluZy5tYXhIcCwgTWF0aC5tYXgoMSwgYnVpbGRpbmcuaHAgKyBidWlsZGluZy5tYXhIcCAtIHByZXZpb3VzTWF4SHApKTtcbiAgYnVpbGRpbmcuYXR0YWNrRGFtYWdlID0gZGVmLmF0dGFja0RhbWFnZTtcbiAgYnVpbGRpbmcuYXR0YWNrUmFuZ2UgPSBkZWYuYXR0YWNrUmFuZ2U7XG4gIGJ1aWxkaW5nLmF0dGFja0Nvb2xkb3duID0gZGVmLmF0dGFja0Nvb2xkb3duO1xufVxuXG5mdW5jdGlvbiBoaXJlTWVyY2VuYXJ5KGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgY2FtcElkOiBzdHJpbmcpIHtcbiAgY29uc3QgY2FtcCA9IGdhbWUubWVyY2VuYXJ5Q2FtcHMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IGNhbXBJZCk7XG4gIGlmICghY2FtcCkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIG1lcmNlbmFyeSBjYW1wICR7Y2FtcElkfWApO1xuICBpZiAoY2FtcC5zdG9jayA8PSAwKSB0aHJvdyBuZXcgRXJyb3IoYCR7Y2FtcC5pZH0gaGFzIG5vIG1lcmNlbmFyeSBzdG9ja2ApO1xuICBpZiAoY2FtcC5jb29sZG93blJlbWFpbmluZyA+IDApIHRocm93IG5ldyBFcnJvcihgJHtjYW1wLmlkfSBpcyByZXN0b2NraW5nYCk7XG4gIGlmICghaGFzRnJpZW5kbHlVbml0QXRNZXJjZW5hcnlDYW1wKGdhbWUsIG93bmVyLCBjYW1wKSkgdGhyb3cgbmV3IEVycm9yKGAke2NhbXAuaWR9IG5lZWRzIGEgZnJpZW5kbHkgdW5pdCBuZWFyYnkgYmVmb3JlIGhpcmluZ2ApO1xuICBpZiAoIWNhblN1cHBseShnYW1lLCBvd25lciwgY2FtcC5oaXJlS2luZCkpIHRocm93IG5ldyBFcnJvcihgTmVlZCBtb3JlIHN1cHBseSB0byBoaXJlICR7Y2FtcC5oaXJlS2luZH1gKTtcbiAgc3BlbmRHb2xkKGdhbWUsIG93bmVyLCBjYW1wLmNvc3QpO1xuICBjYW1wLnN0b2NrIC09IDE7XG4gIGNhbXAuY29vbGRvd25SZW1haW5pbmcgPSBjYW1wLmNvb2xkb3duO1xuICBjb25zdCBvZmZzZXQgPSBvd25lciA9PT0gXCJwbGF5ZXJcIiA/IC1jYW1wLnJhZGl1cyA6IGNhbXAucmFkaXVzO1xuICBjb25zdCBtZXJjZW5hcnkgPSBnYW1lLnNwYXduVW5pdChvd25lciwgY2FtcC5oaXJlS2luZCwgY2FtcC54ICsgb2Zmc2V0LCBjYW1wLnkpO1xuICBhZGRFZmZlY3QoZ2FtZSwgXCJzdW1tb25cIiwgY2FtcC54LCBjYW1wLnksIDM0KTtcbiAgdXBkYXRlU3VwcGx5U3RhdGUoZ2FtZSk7XG4gIHJldHVybiBtZXJjZW5hcnk7XG59XG5cbi8vIFRoZSBnb29kIGNvbWVzIGZyb20gdGhlIHNob3AncyBzdG9jayB0byB0aGUgb3duZXIncyB1bml0IHN0YW5kaW5nIGJ5IGl0IG5lYXJlc3QgaXQgd2l0aCByb29tIChzZWUgQEBAY2FycmllZC1pdGVtcyksIG9yXG4vLyB0byB0aGUgZ3JvdW5kIGF0IHRoZSBzaG9wJ3MgZG9vciB3aGVuIG5vbmUgaGFzIHJvb20uXG5mdW5jdGlvbiBidXlHb29kKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgc2hvcElkOiBzdHJpbmcsIGtpbmQ6IFdvcmxkSXRlbVtcImtpbmRcIl0sIHJlY2lwaWVudElkPzpzdHJpbmcpIHtcbiAgY29uc3QgcmVmdXNhbCA9IGJ1eVJlZnVzYWwoZ2FtZSwgb3duZXIsIHNob3BJZCwga2luZCwgcmVjaXBpZW50SWQpO1xuICBpZiAocmVmdXNhbCkgdGhyb3cgbmV3IEVycm9yKHJlZnVzYWwubWVzc2FnZSk7XG4gIGNvbnN0IHNob3AgPSBnYW1lLnNob3BzIS5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gc2hvcElkKSE7XG4gIGNvbnN0IGdvb2QgPSBzaG9wLmdvb2RzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmtpbmQgPT09IGtpbmQpITtcbiAgY29uc3QgZGVsaXZlcnk9cmVjaXBpZW50SWQhPT11bmRlZmluZWQgPyBwdXJjaGFzZVBsYWNlbWVudChnYW1lLG93bmVyLHNob3Asa2luZCxyZWNpcGllbnRJZCkgOiB1bmRlZmluZWQ7XG4gIGlmKGRlbGl2ZXJ5ICYmIFwicmVmdXNhbFwiIGluIGRlbGl2ZXJ5KXRocm93IG5ldyBFcnJvcihkZWxpdmVyeS5yZWZ1c2FsKTtcbiAgc3BlbmRHb2xkKGdhbWUsIG93bmVyLCBnb29kLmNvc3QpO1xuICBnb29kLnN0b2NrIC09IDE7XG4gIGlmIChnb29kLnJlc3RvY2tSZW1haW5pbmcgPD0gMCkgZ29vZC5yZXN0b2NrUmVtYWluaW5nID0gZ29vZC5yZXN0b2NrO1xuICBjb25zdCBpdGVtOiBXb3JsZEl0ZW0gPSB7IGlkOiBgaXRlbS0ke293bmVyfS0ke2tpbmR9LSR7Z2FtZS5uZXh0SWR9YCwga2luZCwgeDogc2hvcC54LCB5OiBzaG9wLnkgKyBzaG9wLnJhZGl1cyArIDE2LCBjb29sZG93blJlbWFpbmluZzogMCB9O1xuICBnYW1lLm5leHRJZCArPSAxO1xuICBnYW1lLml0ZW1zLnB1c2goaXRlbSk7XG4gIGlmKGRlbGl2ZXJ5ICYmIFwicGxhY2VtZW50XCIgaW4gZGVsaXZlcnkpZGVsaXZlclB1cmNoYXNlKGdhbWUsaXRlbSxkZWxpdmVyeS5wbGFjZW1lbnQpO1xuICBlbHNlIHtcbiAgICAvLyBSZXBsYXkgY29tcGF0aWJpbGl0eSBmb3IgY29tbWFuZHMgcmVjb3JkZWQgYmVmb3JlIGV4cGxpY2l0IHJlY2lwaWVudHMuXG4gICAgY29uc3QgYnV5ZXIgPSBzaG9wQnV5ZXIoZ2FtZSwgb3duZXIsIHNob3Asa2luZCk7XG4gICAgaWYgKGJ1eWVyKSBhdHRhY2hJdGVtVG9Vbml0KGdhbWUsIGl0ZW0sIGJ1eWVyKTtcbiAgICBhZGRFZmZlY3QoZ2FtZSwgXCJzdW1tb25cIiwgc2hvcC54LCBzaG9wLnksIDI0KTtcbiAgfVxuICByZXR1cm4gaXRlbTtcbn1cblxuZnVuY3Rpb24gZGVsaXZlclB1cmNoYXNlKGdhbWU6R2FtZSxpdGVtOldvcmxkSXRlbSxwbGFjZW1lbnQ6UHVyY2hhc2VQbGFjZW1lbnQpe1xuICBjb25zdCByZWNpcGllbnQ9Z2FtZS51bml0cy5maW5kKHVuaXQ9PnVuaXQuaWQ9PT0oXCJ1bml0SWRcIiBpbiBwbGFjZW1lbnQgPyBwbGFjZW1lbnQudW5pdElkIDogcGxhY2VtZW50LnNoaXBJZCkpITtcbiAgaWYoXCJ1bml0SWRcIiBpbiBwbGFjZW1lbnQpe2l0ZW0uY2FycmllcklkPXJlY2lwaWVudC5pZDtpdGVtLnNsb3Q9cGxhY2VtZW50LnNsb3Q7fVxuICBlbHNlIHtpdGVtLnNoaXBJZD1yZWNpcGllbnQuaWQ7aXRlbS5ob2xkU2xvdD1wbGFjZW1lbnQuc2xvdDt9XG4gIGl0ZW0ueD1yZWNpcGllbnQueDtpdGVtLnk9cmVjaXBpZW50Lnk7XG4gIGludmFsaWRhdGVJdGVtSW5kZXgoZ2FtZS5pdGVtcyk7XG4gIGFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLHJlY2lwaWVudCk7cmVmcmVzaEVxdWlwbWVudE1hc3MoZ2FtZSk7XG4gIGFkZEVmZmVjdChnYW1lLFwiaXRlbVJlY2VpdmVkXCIscmVjaXBpZW50LngscmVjaXBpZW50Lnksc2Vjb25kcyguOCkse293bmVyOnJlY2lwaWVudC5vd25lcn0pO1xufVxuXG5mdW5jdGlvbiBoYXNGcmllbmRseVVuaXRBdE1lcmNlbmFyeUNhbXAoZ2FtZTogR2FtZSwgb3duZXI6IFBsYXllcklkLCBjYW1wOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyOyByYWRpdXM6IG51bWJlciB9KSB7XG4gIHJldHVybiBnYW1lLnVuaXRzLnNvbWUoKHVuaXQpID0+IHVuaXQub3duZXIgPT09IG93bmVyICYmIHVuaXRDb250cm9sc01lcmNlbmFyeUNhbXAodW5pdCwgY2FtcCkpO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVQaWNrdXBJdGVtT3JkZXIoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5vcmRlci50eXBlICE9PSBcInBpY2t1cEl0ZW1cIikgcmV0dXJuO1xuICBjb25zdCBpdGVtSWQgPSB1bml0Lm9yZGVyLml0ZW1JZDtcbiAgY29uc3QgaXRlbSA9IGdhbWUuaXRlbXMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IGl0ZW1JZCk7XG4gIGlmICghaXRlbSB8fCBpdGVtLmNhcnJpZXJJZCB8fCBpdGVtLnNoaXBJZCkge1xuICAgIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChkaXN0YW5jZSh1bml0LCBpdGVtKSA+IElURU1fUElDS1VQX1JBTkdFKSB7XG4gICAgbW92ZVRvd2FyZCh1bml0LCBpdGVtLngsIGl0ZW0ueSwgZ2FtZS5tYXAsIGdhbWUudW5pdHMpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoZnJlZUl0ZW1TbG90KGdhbWUsdW5pdCxpdGVtLmtpbmQpKSBhdHRhY2hJdGVtVG9Vbml0KGdhbWUsIGl0ZW0sIHVuaXQpO1xuICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xufVxuXG5mdW5jdGlvbiBwaWNrdXBJdGVtKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgdW5pdElkOiBzdHJpbmcsIGl0ZW1JZDogc3RyaW5nLCBxdWV1ZWQgPSBmYWxzZSkge1xuICBjb25zdCB1bml0ID0gZ2FtZS51bml0cy5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gdW5pdElkICYmIGNhbmRpZGF0ZS5vd25lciA9PT0gb3duZXIpO1xuICBpZiAoIXVuaXQpIHRocm93IG5ldyBFcnJvcihgVW5rbm93biAke293bmVyfSBpdGVtIGNhcnJpZXIgJHt1bml0SWR9YCk7XG4gIGNvbnN0IGl0ZW0gPSBnYW1lLml0ZW1zLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBpdGVtSWQpO1xuICBpZiAoIWl0ZW0pIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBpdGVtICR7aXRlbUlkfWApO1xuICBpZiAoaXRlbS5jYXJyaWVySWQgfHwgaXRlbS5zaGlwSWQpIHRocm93IG5ldyBFcnJvcihgJHtpdGVtLmlkfSBpcyBhbHJlYWR5IGNhcnJpZWRgKTtcbiAgaWYgKHVuaXRNb3Zlcih1bml0LmtpbmQpID09PSBcInNlYVwiKSB0aHJvdyBuZXcgRXJyb3IoXCJBIHNoaXAgY2FycmllcyBubyBpdGVtc1wiKTtcbiAgaWYgKCFjYW5FcXVpcCh1bml0KSB8fCAhZnJlZUl0ZW1TbG90KGdhbWUsdW5pdCxpdGVtLmtpbmQpKSB0aHJvdyBuZXcgRXJyb3IoYCR7dW5pdC5pZH0gaGFzIG5vIGZyZWUgZXF1aXBtZW50IHBvc2l0aW9uYCk7XG4gIGlmIChkaXN0YW5jZSh1bml0LCBpdGVtKSA+IElURU1fUElDS1VQX1JBTkdFKSB7XG4gICAgYXNzaWduVW5pdE9yZGVyKHVuaXQsIHsgdHlwZTogXCJwaWNrdXBJdGVtXCIsIGl0ZW1JZCB9LCBxdWV1ZWQpO1xuICAgIHJldHVybjtcbiAgfVxuICBhdHRhY2hJdGVtVG9Vbml0KGdhbWUsIGl0ZW0sIHVuaXQpO1xufVxuXG5mdW5jdGlvbiBhdHRhY2hJdGVtVG9Vbml0KGdhbWU6IEdhbWUsIGl0ZW06IFdvcmxkSXRlbSwgdW5pdDogVW5pdCkge1xuICBjb25zdCBzbG90PWZyZWVJdGVtU2xvdChnYW1lLHVuaXQsaXRlbS5raW5kKTtpZighc2xvdClyZXR1cm47XG4gIGl0ZW0uc2xvdD1zbG90O1xuICBpdGVtLmNhcnJpZXJJZCA9IHVuaXQuaWQ7XG4gIGRlbGV0ZSBpdGVtLmRlY2s7XG4gIGludmFsaWRhdGVJdGVtSW5kZXgoZ2FtZS5pdGVtcyk7XG4gIGl0ZW0ueCA9IHVuaXQueDtcbiAgaXRlbS55ID0gdW5pdC55O1xuICAvLyBCb290cyBjaGFuZ2UgdGhlaXIgY2FycmllcidzIHBhY2UgKHNlZSBAQEBzaG9wLWdvb2RzKS5cbiAgaWYgKGlzUGxheWVySWQodW5pdC5vd25lcikpIGFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLCB1bml0KTtcbiAgcmVmcmVzaEVxdWlwbWVudE1hc3MoZ2FtZSk7XG59XG5cbmZ1bmN0aW9uIGRyb3BJdGVtKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgdW5pdElkOiBzdHJpbmcsIGl0ZW1JZDogc3RyaW5nLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICBjb25zdCB1bml0ID0gZ2FtZS51bml0cy5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gdW5pdElkICYmIGNhbmRpZGF0ZS5vd25lciA9PT0gb3duZXIpO1xuICBpZiAoIXVuaXQpIHRocm93IG5ldyBFcnJvcihgVW5rbm93biAke293bmVyfSBpdGVtIGNhcnJpZXIgJHt1bml0SWR9YCk7XG4gIGNvbnN0IHJlZnVzYWwgPSBkcm9wUmVmdXNhbChnYW1lLCBvd25lciwgdW5pdElkLCBpdGVtSWQpO1xuICBpZiAocmVmdXNhbCkgdGhyb3cgbmV3IEVycm9yKHJlZnVzYWwpO1xuICBjb25zdCBpdGVtID0gZ2FtZS5pdGVtcy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gaXRlbUlkKSE7XG4gIGNvbnN0IHNoaXAgPSBnYW1lLnVuaXRzLmZpbmQoc2hpcCA9PiBzaGlwLmlkID09PSBpdGVtLnNoaXBJZCk7XG4gIGRlbGV0ZSBpdGVtLmNhcnJpZXJJZDtkZWxldGUgaXRlbS5zbG90O2RlbGV0ZSBpdGVtLnNoaXBJZDtkZWxldGUgaXRlbS5ob2xkU2xvdDtkZWxldGUgaXRlbS5tb3VudElkO3JlbW92ZUZyb21IYW5kcyh1bml0LGl0ZW0uaWQpO1xuICBpZiAoc2hpcCkgcmVidWlsZFNoaXBGaXR0aW5ncyhnYW1lLCBzaGlwKTtcbiAgaW52YWxpZGF0ZUl0ZW1JbmRleChnYW1lLml0ZW1zKTtcbiAgaXRlbS54ID0gY2xhbXAoeCwgMCwgZ2FtZS5tYXAud2lkdGgpO1xuICBpdGVtLnkgPSBjbGFtcCh5LCAwLCBnYW1lLm1hcC5oZWlnaHQpO1xuICBzZXR0bGVHcm91bmRJdGVtcyhnYW1lLml0ZW1zLGdhbWUudW5pdHMsZ2FtZS5tYXApO1xuICBpZiAoaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSkgYXBwbHlEZXJpdmVkVW5pdFN0YXRzKGdhbWUsIHVuaXQpO1xuICByZWZyZXNoRXF1aXBtZW50TWFzcyhnYW1lKTtcbn1cblxuZnVuY3Rpb24gdXNlSXRlbShcbiAgZ2FtZTogR2FtZSxcbiAgb3duZXI6IFBsYXllcklkLFxuICB1bml0SWQ6IHN0cmluZyxcbiAgaXRlbUlkOiBzdHJpbmcsXG4gIHRhcmdldElkOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHg6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgeTogbnVtYmVyIHwgdW5kZWZpbmVkLFxuKSB7XG4gIGNvbnN0IHVuaXQgPSBnYW1lLnVuaXRzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSB1bml0SWQgJiYgY2FuZGlkYXRlLm93bmVyID09PSBvd25lcik7XG4gIGlmICghdW5pdCkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duICR7b3duZXJ9IGl0ZW0gdXNlciAke3VuaXRJZH1gKTtcbiAgY29uc3QgaXRlbSA9IGNhcnJpZWRJdGVtKGdhbWUsIHVuaXQsIGl0ZW1JZCk7XG4gIGNvbnN0IHByZXZpb3VzSGFuZHM9dW5pdC5oYW5kcyA/IHsuLi51bml0LmhhbmRzfSA6IHVuZGVmaW5lZDtcbiAgaWYoIUlURU1fREVGU1tpdGVtLmtpbmRdLnBhc3NpdmUgJiYgIWl0ZW1FcXVpcHBlZChnYW1lLHVuaXQsaXRlbSkpe3VuaXQuaGFuZHM/Pz17fTtyZW1vdmVGcm9tSGFuZHModW5pdCxpdGVtLmlkKTt1bml0LmhhbmRzLnJpZ2h0PWl0ZW0uaWQ7aWYoaXRlbUhhbmRzKGl0ZW0pPT09MilkZWxldGUgdW5pdC5oYW5kcy5sZWZ0O3VuaXQuYWltPXVuZGVmaW5lZDthcHBseURlcml2ZWRVbml0U3RhdHMoZ2FtZSx1bml0KTt9XG4gIGFjdGl2YXRlSXRlbShnYW1lLCB1bml0LCBpdGVtLCB0YXJnZXRJZCwgeCwgeSk7XG4gIGlmKHByZXZpb3VzSGFuZHMgJiYgIWdhbWUuaXRlbXMuc29tZShjYW5kaWRhdGU9PmNhbmRpZGF0ZS5pZD09PWl0ZW0uaWQpKXt1bml0LmhhbmRzPXByZXZpb3VzSGFuZHM7YXBwbHlEZXJpdmVkVW5pdFN0YXRzKGdhbWUsdW5pdCk7fVxufVxuXG5mdW5jdGlvbiBjYXN0QWJpbGl0eShcbiAgZ2FtZTogR2FtZSxcbiAgb3duZXI6IFBsYXllcklkLFxuICB1bml0SWQ6IHN0cmluZyxcbiAgYWJpbGl0eTogQWJpbGl0eUtpbmQsXG4gIHRhcmdldElkOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHg6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgeTogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICBxdWV1ZWQgPSBmYWxzZSxcbikge1xuICBjb25zdCBjYXN0ZXIgPSBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IHVuaXRJZCAmJiB1bml0Lm93bmVyID09PSBvd25lcik7XG4gIGlmICghY2FzdGVyIHx8IGNhc3Rlci5ocCA8PSAwKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gJHtvd25lcn0gY2FzdGVyICR7dW5pdElkfWApO1xuICBpZiAoaXNTdHVubmVkKGNhc3RlcikpIHRocm93IG5ldyBFcnJvcihgJHtjYXN0ZXIua2luZH0gaXMgc3R1bm5lZGApO1xuICBpZiAoIXVuaXRBYmlsaXRpZXMoY2FzdGVyKS5pbmNsdWRlcyhhYmlsaXR5KSkgdGhyb3cgbmV3IEVycm9yKGAke2Nhc3Rlci5raW5kfSBjYW5ub3QgY2FzdCAke2FiaWxpdHl9YCk7XG4gIGlmIChhYmlsaXR5Q29vbGRvd24oY2FzdGVyLCBhYmlsaXR5KSA+IDApIHRocm93IG5ldyBFcnJvcihgJHtjYXN0ZXIua2luZH0gaXMgb24gY29vbGRvd25gKTtcbiAgY29uc3QgZGVmID0gQUJJTElUWV9ERUZTW2FiaWxpdHldO1xuICBpZiAoZGVmLmJlaGF2aW9yID09PSBcInZldGVyYW5cIikge1xuICAgIGlmIChxdWV1ZWQpIGFzc2lnblVuaXRPcmRlcihjYXN0ZXIsIHsgdHlwZTogXCJjYXN0XCIsIGFiaWxpdHkgfSwgdHJ1ZSk7XG4gICAgZWxzZSBhcHBseVZldGVyYW5BYmlsaXR5KGdhbWUsIGNhc3RlciwgZGVmLCBmYWxzZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHR5cGVkVGFyZ2V0ID0gdGFyZ2V0SWQgPyBmaW5kU3RyaWtlVGFyZ2V0KGdhbWUsIHRhcmdldElkKSA6IHVuZGVmaW5lZDtcbiAgaWYgKHR5cGVkVGFyZ2V0ICYmIGlzVW5pdCh0eXBlZFRhcmdldCkgJiYgIW1hdGNoZXNVbml0VGFyZ2V0KHR5cGVkVGFyZ2V0LCBkZWYudGFyZ2V0cywgZ2FtZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoZGVmLmJlaGF2aW9yID09PSBcImhlYWxcIiA/IFwiSGVhbGluZyBjYW5ub3QgcmVzdG9yZSBtZWNoYW5pY2FsIHVuaXRzXCIgOiBcIkFiaWxpdHkgY2Fubm90IHRhcmdldCB0aGlzIHVuaXQgY2xhc3NcIik7XG4gIH1cbiAgLy8gT3V0IG9mIHJlYWNoLCBvciBhZnRlciB0aGUgb3JkZXJzIGJlZm9yZSBpdCAoc2hpZnQpLCB0aGUgY2FzdGVyIHdhbGtzIHRvIGNhc3QgKHNlZSBAQEBjYXN0LW9yZGVyKS5cbiAgY29uc3QgbGF0ZXIgPSAob3JkZXI6IEV4dHJhY3Q8VW5pdE9yZGVyLCB7IHR5cGU6IFwiY2FzdFwiIH0+LCBhdDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9KSA9PiB7XG4gICAgYXNzaWduVW5pdE9yZGVyKGNhc3Rlciwgb3JkZXIsIHF1ZXVlZCk7XG4gICAgYWRkRWZmZWN0KGdhbWUsIHF1ZXVlZCA/IFwicXVldWVkTW92ZVwiIDogXCJtb3ZlXCIsIGF0LngsIGF0LnksIHF1ZXVlZCA/IDM4IDogMjQsIHsgb3duZXIgfSk7XG4gIH07XG5cbiAgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJ3ZWFwb25cIikge1xuICAgIGNvbnN0IHRhcmdldCA9IHRhcmdldElkID8gZmluZFN0cmlrZVRhcmdldChnYW1lLCB0YXJnZXRJZCkgOiB1bmRlZmluZWQ7XG4gICAgaWYgKGRlZi50YXJnZXQgPT09IFwiZW5lbXlcIiAmJiAoIXRhcmdldCB8fCAhYXJlRW5lbXlPd25lcnMoZ2FtZSwgb3duZXIsIHRhcmdldC5vd25lcikpKSB0aHJvdyBuZXcgRXJyb3IoXCJXZWFwb24gc2tpbGwgcmVxdWlyZXMgYW4gZW5lbXkgdGFyZ2V0XCIpO1xuICAgIGNvbnN0IHBvaW50ID0gdGFyZ2V0ID8/IChpc051bWJlcih4KSAmJiBpc051bWJlcih5KSA/IHsgeCwgeSB9IDogdW5kZWZpbmVkKTtcbiAgICBpZiAoIXBvaW50KSB0aHJvdyBuZXcgRXJyb3IoXCJXZWFwb24gc2tpbGwgcmVxdWlyZXMgYSB0YXJnZXQgcG9pbnRcIik7XG4gICAgaWYgKGRlZi53ZWFwb24ubWluUmFuZ2UgJiYgZGlzdGFuY2UoY2FzdGVyLCBwb2ludCkgPCBkZWYud2VhcG9uLm1pblJhbmdlKSB0aHJvdyBuZXcgRXJyb3IoXCJUYXJnZXQgaW5zaWRlIHdlYXBvbiBtaW5pbXVtIHJhbmdlXCIpO1xuICAgIGlmIChxdWV1ZWQgfHwgaXNTaGlwS2luZChjYXN0ZXIua2luZCkgfHwgYWltaW5nUHJvZmlsZSh1bml0UnVsZXMoZ2FtZSwgY2FzdGVyKSkgfHwgZGlzdGFuY2UoY2FzdGVyLCBwb2ludCkgPiBkZWYucmFuZ2UgKyAodGFyZ2V0ICYmICFpc1VuaXQodGFyZ2V0KSA/IHRhcmdldC5yYWRpdXMgOiAwKSkgbGF0ZXIoe3R5cGU6XCJjYXN0XCIsYWJpbGl0eSwuLi4odGFyZ2V0ID8ge3RhcmdldElkOnRhcmdldC5pZH0gOiB7eDpwb2ludC54LHk6cG9pbnQueX0pfSxwb2ludCk7XG4gICAgZWxzZSBhcHBseVdlYXBvbkFiaWxpdHkoZ2FtZSxjYXN0ZXIsYWJpbGl0eSxwb2ludCxkZWYsdGFyZ2V0Py5pZCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiaGVhbFwiKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gdGFyZ2V0SWQgPyBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IHRhcmdldElkICYmICFhcmVFbmVteU93bmVycyhnYW1lLCB1bml0Lm93bmVyLCBvd25lcikpIDogdW5kZWZpbmVkO1xuICAgIGlmICghdGFyZ2V0KSB0aHJvdyBuZXcgRXJyb3IoXCJIZWFsIHJlcXVpcmVzIGFuIGFsbGllZCB1bml0IHRhcmdldFwiKTtcbiAgICBpZiAoIWNhblJlY2VpdmVIZWFsaW5nKHRhcmdldCwgZ2FtZSkpIHRocm93IG5ldyBFcnJvcihcIkhlYWxpbmcgY2Fubm90IHJlc3RvcmUgbWVjaGFuaWNhbCB1bml0c1wiKTtcbiAgICBpZiAocXVldWVkIHx8IGRpc3RhbmNlKGNhc3RlciwgdGFyZ2V0KSA+IGRlZi5yYW5nZSkgbGF0ZXIoeyB0eXBlOiBcImNhc3RcIiwgYWJpbGl0eSwgdGFyZ2V0SWQ6IHRhcmdldC5pZCB9LCB0YXJnZXQpO1xuICAgIGVsc2UgYXBwbHlIZWFsKGdhbWUsIGNhc3RlciwgYWJpbGl0eSwgdGFyZ2V0LCBkZWYpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoZGVmLmJlaGF2aW9yID09PSBcImN1cnNlXCIpIHtcbiAgICBjb25zdCB0YXJnZXQgPSB0YXJnZXRJZCA/IGdhbWUudW5pdHMuZmluZCgodW5pdCkgPT4gdW5pdC5pZCA9PT0gdGFyZ2V0SWQgJiYgYXJlRW5lbXlPd25lcnMoZ2FtZSwgdW5pdC5vd25lciwgb3duZXIpKSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoIXRhcmdldCkgdGhyb3cgbmV3IEVycm9yKFwiQ3Vyc2UgcmVxdWlyZXMgYW4gZW5lbXkgdW5pdCB0YXJnZXRcIik7XG4gICAgaWYgKHF1ZXVlZCB8fCBkaXN0YW5jZShjYXN0ZXIsIHRhcmdldCkgPiBkZWYucmFuZ2UpIGxhdGVyKHsgdHlwZTogXCJjYXN0XCIsIGFiaWxpdHksIHRhcmdldElkOiB0YXJnZXQuaWQgfSwgdGFyZ2V0KTtcbiAgICBlbHNlIGFwcGx5Q3Vyc2UoZ2FtZSwgY2FzdGVyLCBhYmlsaXR5LCB0YXJnZXQsIGRlZik7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiY2hhcmdlXCIpIHtcbiAgICBjb25zdCB0YXJnZXQgPSB0YXJnZXRJZCA/IGdhbWUudW5pdHMuZmluZCgodW5pdCkgPT4gdW5pdC5pZCA9PT0gdGFyZ2V0SWQgJiYgYXJlRW5lbXlPd25lcnMoZ2FtZSwgdW5pdC5vd25lciwgb3duZXIpKSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoIXRhcmdldCkgdGhyb3cgbmV3IEVycm9yKFwiQ2hhcmdlIHJlcXVpcmVzIGFuIGVuZW15IHVuaXQgdGFyZ2V0XCIpO1xuICAgIGlmIChkaXN0YW5jZShjYXN0ZXIsIHRhcmdldCkgPCBkZWYubWluUmFuZ2UpIHRocm93IG5ldyBFcnJvcihgQ2hhcmdlIHRhcmdldCBtdXN0IGJlIGF0IGxlYXN0ICR7ZGVmLm1pblJhbmdlfSBhd2F5YCk7XG4gICAgaWYgKCFjYW5SZWFjaChnYW1lLm1hcCwgY2FzdGVyLCB0YXJnZXQsIGdhbWUudW5pdHMpKSB0aHJvdyBuZXcgRXJyb3IoXCJDaGFyZ2UgdGFyZ2V0IGlzIG91dCBvZiByZWFjaFwiKTtcbiAgICBpZiAocXVldWVkIHx8IGRpc3RhbmNlKGNhc3RlciwgdGFyZ2V0KSA+IGRlZi5yYW5nZSkgbGF0ZXIoeyB0eXBlOiBcImNhc3RcIiwgYWJpbGl0eSwgdGFyZ2V0SWQ6IHRhcmdldC5pZCB9LCB0YXJnZXQpO1xuICAgIGVsc2Ugc3RhcnRDaGFyZ2UoZ2FtZSwgY2FzdGVyLCBhYmlsaXR5LCB0YXJnZXQsIGRlZiwgdHJ1ZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChkZWYuYmVoYXZpb3IgIT09IFwic3VtbW9uXCIpIHRocm93IG5ldyBFcnJvcihgJHthYmlsaXR5fSBpcyBjYXN0IGJ5IGl0cyBjcmVlcCBhbG9uZWApO1xuICBpZiAoIWlzTnVtYmVyKHgpIHx8ICFpc051bWJlcih5KSkgdGhyb3cgbmV3IEVycm9yKFwiU3VtbW9uIHJlcXVpcmVzIGEgdGFyZ2V0IHBvaW50XCIpO1xuICBpZiAocXVldWVkIHx8IGRpc3RhbmNlKGNhc3RlciwgeyB4LCB5IH0pID4gZGVmLnJhbmdlKSBsYXRlcih7IHR5cGU6IFwiY2FzdFwiLCBhYmlsaXR5LCB4LCB5IH0sIHsgeCwgeSB9KTtcbiAgZWxzZSBhcHBseVN1bW1vbihnYW1lLCBjYXN0ZXIsIGFiaWxpdHksIHgsIHksIGRlZik7XG59XG5cbi8vIEBAQGNhc3Qtb3JkZXIgLSBBIHNwZWxsIGNhc3Qgb3V0IG9mIHJlYWNoIGlzIHdhbGtlZCB0bywgYXMgV2FyY3JhZnQgSUlJJ3MgYXJlOiB0aGUgY2FzdGVyIGhlYWRzIGZvciB0aGUgc3BlbGwncyBwb2ludCBvclxuLy8gZm9sbG93cyBpdHMgdW5pdCwgYW5kIGNhc3RzIG9uY2Ugd2l0aGluIHRoZSBzcGVsbCdzIHJhbmdlIChhIGNoYXJnZTogd2l0aGluIGl0cyB3aW5kb3csIGZyb20gd2hpY2ggaXQgY2hhcmdlcykgd2l0aFxuLy8gdGhlIHNwZWxsIHJlYWR5LiBBIHRhcmdldCBnb25lLCBkZWFkIG9yIHR1cm5lZCwgb25lIGl0IGNhbiBjb21lIG5vIG5lYXJlciB0bywgYSBjaGFyZ2UncyB0YXJnZXQgY29tZSB0b28gY2xvc2Ugb3Igb3V0XG4vLyBvZiByZWFjaCwgb3IgdGhlIHNwZWxsIG5vdCByZWFkeSBvbiBhcnJpdmFsLCBhbmQgdGhlIG9yZGVyIGVuZHM6IHRoZSBjYXN0ZXIgdGFrZXMgdXAgaXRzIG5leHQgcXVldWVkIG9yZGVyLCBlbHNlIGlkbGVzLlxuZnVuY3Rpb24gdXBkYXRlQ2FzdE9yZGVyKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgY29uc3Qgb3JkZXIgPSB1bml0Lm9yZGVyO1xuICBpZiAob3JkZXIudHlwZSAhPT0gXCJjYXN0XCIpIHJldHVybjtcbiAgY29uc3QgZGVmID0gQUJJTElUWV9ERUZTW29yZGVyLmFiaWxpdHldO1xuICBjb25zdCB0YXJnZXQgPSBvcmRlci50YXJnZXRJZCA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogZmluZFN0cmlrZVRhcmdldChnYW1lLCBvcmRlci50YXJnZXRJZCk7XG4gIGNvbnN0IGVuZCA9ICgpID0+IHtcbiAgICB1bml0Lm9yZGVyID0geyB0eXBlOiBcImlkbGVcIiB9O1xuICB9O1xuICAvLyBTYXZlcyBjYW4gY29udGFpbiBhIGNhc3QgZm9yIGFuIGFiaWxpdHkgcmVtb3ZlZCBmcm9tIHRoZSBjYXRhbG9nLlxuICBpZiAoIWRlZikgcmV0dXJuIGVuZCgpO1xuICBpZiAoZGVmLmJlaGF2aW9yID09PSBcInZldGVyYW5cIikge1xuICAgIGlmICh1bml0QWJpbGl0aWVzKHVuaXQpLmluY2x1ZGVzKG9yZGVyLmFiaWxpdHkpICYmIGFiaWxpdHlDb29sZG93bih1bml0LCBvcmRlci5hYmlsaXR5KSA8PSAwKSBhcHBseVZldGVyYW5BYmlsaXR5KGdhbWUsIHVuaXQsIGRlZiwgZmFsc2UpO1xuICAgIHJldHVybiBlbmQoKTtcbiAgfVxuICBpZiAob3JkZXIudGFyZ2V0SWQgIT09IHVuZGVmaW5lZCAmJiAoIXRhcmdldCB8fCB0YXJnZXQuaHAgPD0gMCB8fCBhcmVFbmVteU93bmVycyhnYW1lLCB0YXJnZXQub3duZXIsIHVuaXQub3duZXIpICE9PSAoZGVmLmJlaGF2aW9yICE9PSBcImhlYWxcIikpKSByZXR1cm4gZW5kKCk7XG4gIGlmICh0YXJnZXQgJiYgaXNVbml0KHRhcmdldCkgJiYgIW1hdGNoZXNVbml0VGFyZ2V0KHRhcmdldCwgZGVmLnRhcmdldHMsIGdhbWUpKSByZXR1cm4gZW5kKCk7XG4gIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiaGVhbFwiICYmIHRhcmdldCAmJiAoIWlzVW5pdCh0YXJnZXQpIHx8ICFjYW5SZWNlaXZlSGVhbGluZyh0YXJnZXQsIGdhbWUpKSkgcmV0dXJuIGVuZCgpO1xuICBjb25zdCBhdCA9IHRhcmdldCA/PyAoaXNOdW1iZXIob3JkZXIueCkgJiYgaXNOdW1iZXIob3JkZXIueSkgPyB7IHg6IG9yZGVyLngsIHk6IG9yZGVyLnkgfSA6IHVuZGVmaW5lZCk7XG4gIGlmICghYXQpIHJldHVybiBlbmQoKTtcbiAgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJ3ZWFwb25cIiAmJiBkZWYud2VhcG9uLm1pblJhbmdlICYmIGRpc3RhbmNlKHVuaXQsIGF0KTxkZWYud2VhcG9uLm1pblJhbmdlKSByZXR1cm4gZW5kKCk7XG4gIGlmIChkaXN0YW5jZSh1bml0LCBhdCkgPiBkZWYucmFuZ2UgKyAoZGVmLmJlaGF2aW9yID09PSBcIndlYXBvblwiICYmIHRhcmdldCAmJiAhaXNVbml0KHRhcmdldCkgPyB0YXJnZXQucmFkaXVzIDogMCkpIHtcbiAgICBtb3ZlVG93YXJkKHVuaXQsIGF0LngsIGF0LnksIGdhbWUubWFwLCBnYW1lLnVuaXRzKTtcbiAgICAvLyBBcyBuZWFyIGFzIGl0IGNhbiBjb21lIChpdHMgcG9pbnQgb3IgdW5pdCBiZXlvbmQgaXRzIGdyb3VuZCwgc2VlIEBAQHJlYWNoKSBhbmQgc3RpbGwgb3V0IG9mIHJhbmdlOiBubyBjYXN0LlxuICAgIGlmICh3YWxrRW5kZWQoZ2FtZSwgdW5pdCwgYXQsIDUpKSBlbmQoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGFiaWxpdHlDb29sZG93bih1bml0LCBvcmRlci5hYmlsaXR5KSA+IDApIHJldHVybiBlbmQoKTtcbiAgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJ3ZWFwb25cIikge1xuICAgIGlmKG9yZGVyLmFiaWxpdHk9PT0naW5jZW5kaWFyeUZsdW1lJyAmJiB1bml0LmZpdHRpbmdzKXtcbiAgICAgIGNvbnN0IGl0ZW09aW5zdGFsbGVkV2VhcG9ucyhnYW1lLHVuaXQpLmZpbmQoaXRlbT0+aXRlbS5raW5kPT09J2ZsYW1lUHJvamVjdG9yJyAmJiAoaXRlbS5kdXJhYmlsaXR5ID8/IDEpPjApO1xuICAgICAgaWYoIWl0ZW0pcmV0dXJuIGVuZCgpO1xuICAgICAgaWYoIXNoaXBHdW5DYW5BaW0odW5pdCxpdGVtLGF0KSl7Y29uc3QgbW91bnQ9c2hpcE1vdW50cyh1bml0KS5maW5kKG1vdW50PT5tb3VudC5pZD09PWl0ZW0ubW91bnRJZCkhO3R1cm5TaGlwVG93YXJkKHVuaXQsTWF0aC5hdGFuMihhdC55LXVuaXQueSxhdC54LXVuaXQueCktbW91bnQuYmVhcmluZyxnYW1lLm1hcCxnYW1lLnVuaXRzKTtyZXR1cm47fVxuICAgICAgaXRlbS5mYWNpbmc9TWF0aC5hdGFuMihhdC55LW1vdW50ZWRXZWFwb25Qb3NlKHVuaXQsaXRlbSkhLnBpdm90LnksYXQueC1tb3VudGVkV2VhcG9uUG9zZSh1bml0LGl0ZW0pIS5waXZvdC54KTtcbiAgICAgIGNvbnN0IHByb3h5PWFpbU1vdW50ZWRXZWFwb24oZ2FtZSx1bml0LGl0ZW0sYXQpO2lmKCFwcm94eSlyZXR1cm47XG4gICAgICBhcHBseVdlYXBvbkFiaWxpdHkoZ2FtZSx1bml0LG9yZGVyLmFiaWxpdHksYXQsZGVmLHRhcmdldD8uaWQpO21hcmtBaW1TaG90KHByb3h5KTtlbmQoKTtyZXR1cm47XG4gICAgfVxuICAgIGlmICghYWltQXQodW5pdCwgd2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCksIGF0LCBnYW1lLnRpY2ssIHZldGVyYW5BaW1TcGVlZChnYW1lLCB1bml0KSkpIHJldHVybjtcbiAgICBhcHBseVdlYXBvbkFiaWxpdHkoZ2FtZSx1bml0LG9yZGVyLmFiaWxpdHksYXQsZGVmLHRhcmdldD8uaWQpO1xuICAgIG1hcmtBaW1TaG90KHVuaXQpO1xuICB9XG4gIGVsc2UgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJoZWFsXCIgJiYgdGFyZ2V0ICYmIGlzVW5pdCh0YXJnZXQpKSBhcHBseUhlYWwoZ2FtZSwgdW5pdCwgb3JkZXIuYWJpbGl0eSwgdGFyZ2V0LCBkZWYpO1xuICBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiY3Vyc2VcIiAmJiB0YXJnZXQgJiYgaXNVbml0KHRhcmdldCkpIGFwcGx5Q3Vyc2UoZ2FtZSwgdW5pdCwgb3JkZXIuYWJpbGl0eSwgdGFyZ2V0LCBkZWYpO1xuICBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwic3VtbW9uXCIpIGFwcGx5U3VtbW9uKGdhbWUsIHVuaXQsIG9yZGVyLmFiaWxpdHksIGF0LngsIGF0LnksIGRlZik7XG4gIGVsc2UgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJjaGFyZ2VcIiAmJiB0YXJnZXQgJiYgaXNVbml0KHRhcmdldCkgJiYgZGlzdGFuY2UodW5pdCwgdGFyZ2V0KSA+PSBkZWYubWluUmFuZ2UgJiYgY2FuUmVhY2goZ2FtZS5tYXAsIHVuaXQsIHRhcmdldCwgZ2FtZS51bml0cykpIHtcbiAgICAvLyBUaGUgY2hhcmdlJ3Mgb3duIHJ1bGUgc2VlcyB0byB3aGF0IGZvbGxvd3MgaXQgKHNlZSBlbmRDaGFyZ2UpOiB0aGUgbmV4dCBxdWV1ZWQgb3JkZXIsIGVsc2UgYXR0YWNraW5nIGl0cyB1bml0LlxuICAgIHN0YXJ0Q2hhcmdlKGdhbWUsIHVuaXQsIG9yZGVyLmFiaWxpdHksIHRhcmdldCwgZGVmLCBmYWxzZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGVuZCgpO1xufVxuXG5mdW5jdGlvbiBhcHBseUhlYWwoZ2FtZTogR2FtZSwgY2FzdGVyOiBVbml0LCBhYmlsaXR5OiBBYmlsaXR5S2luZCwgdGFyZ2V0OiBVbml0LCBkZWY6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJoZWFsXCIgfT4pIHtcbiAgaWYgKCFtYXRjaGVzVW5pdFRhcmdldCh0YXJnZXQsIGRlZi50YXJnZXRzLCBnYW1lKSB8fCAhY2FuUmVjZWl2ZUhlYWxpbmcodGFyZ2V0LCBnYW1lKSB8fCBkaXN0YW5jZShjYXN0ZXIsIHRhcmdldCkgPiBkZWYucmFuZ2UpIHJldHVybjtcbiAgdGFyZ2V0LmhwID0gTWF0aC5taW4odGFyZ2V0Lm1heEhwLCB0YXJnZXQuaHAgKyBkZWYuaGVhbEFtb3VudCk7XG4gIGNhc3Rlci5hYmlsaXR5Q29vbGRvd25zID0gd2l0aEFiaWxpdHlDb29sZG93bihjYXN0ZXIsIGFiaWxpdHksIGRlZi5jb29sZG93bik7XG4gIGFkZEVmZmVjdChnYW1lLCBkZWYuZWZmZWN0VHlwZSwgdGFyZ2V0LngsIHRhcmdldC55LCAzNiwgeyBzb3VyY2VLaW5kOiBjYXN0ZXIua2luZCwgc291cmNlSWQ6IGNhc3Rlci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXN0ZXIueCwgZnJvbVk6IGNhc3Rlci55LCBmcm9tSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxjYXN0ZXIpLCB0b1g6IHRhcmdldC54LCB0b1k6IHRhcmdldC55LCB0b0hlaWdodDogY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsdGFyZ2V0KSwgdW5pdElkOiBjYXN0ZXIuaWQsIG93bmVyOiBjYXN0ZXIub3duZXIgfSk7XG59XG5cbmZ1bmN0aW9uIHN5bmNTdW1tb25Mb2FkKGdhbWU6IEdhbWUsIHNoaXA6IFVuaXQsIHByb2JlOiBVbml0KSB7XG4gIHJldHVybiBzaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLCBzaGlwKS5yZWR1Y2UoKG1hc3MsIHVuaXQpID0+IG1hc3MgKyBib2R5TWFzcyh1bml0KSwgYm9keU1hc3MocHJvYmUpKSA+IHNoaXBQcm9maWxlKHNoaXApIS5sb2FkQ2FwYWNpdHk7XG59XG5cbmZ1bmN0aW9uIGFwcGx5U3VtbW9uKGdhbWU6IEdhbWUsIGNhc3RlcjogVW5pdCwgYWJpbGl0eTogQWJpbGl0eUtpbmQsIHg6IG51bWJlciwgeTogbnVtYmVyLCBkZWY6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJzdW1tb25cIiB9Pikge1xuICBpZiAoZGlzdGFuY2UoY2FzdGVyLCB7IHgsIHkgfSkgPiBkZWYucmFuZ2UpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc2hpcCA9IGdhbWUudW5pdHMuZmluZChzaGlwID0+IHtcbiAgICBjb25zdCBwcm9maWxlID0gc2hpcFByb2ZpbGUoc2hpcCk7XG4gICAgcmV0dXJuIHByb2ZpbGUgJiYgc2hpcC5vd25lciA9PT0gY2FzdGVyLm93bmVyICYmIGNpcmNsZUluUG9seWdvbih3b3JsZFRvTG9jYWwoc2hpcCwgeyB4LCB5IH0pLCAwLCBwcm9maWxlLmRlY2spO1xuICB9KTtcbiAgaWYgKCFzaGlwICYmICFpc1dhbGthYmxlKGdhbWUubWFwLCB4LCB5KSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBwcm9iZSA9IHNoaXAgJiYgY3JlYXRlVW5pdChcInN1bW1vbi1wcm9iZVwiLCBjYXN0ZXIub3duZXIsIGRlZi5zdW1tb25LaW5kLCB4LCB5KTtcbiAgY29uc3QgcG9pbnQgPSBzaGlwICYmIHByb2JlICYmIGRlY2tQbGFjZW1lbnQoc2hpcCwgcHJvYmUsIGdhbWUudW5pdHMsIHdvcmxkVG9Mb2NhbChzaGlwLCB7IHgsIHkgfSkpO1xuICBpZiAoc2hpcCAmJiAoIXBvaW50IHx8IHN5bmNTdW1tb25Mb2FkKGdhbWUsIHNoaXAsIHByb2JlISkpKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHNwaXJpdCA9IGdhbWUuc3Bhd25Vbml0KGNhc3Rlci5vd25lciwgZGVmLnN1bW1vbktpbmQsIHgsIHkpO1xuICBpZiAoc2hpcCAmJiBwb2ludCkgeyBzcGlyaXQuZGVjayA9IHsgc2hpcElkOiBzaGlwLmlkLCAuLi5wb2ludCB9OyBPYmplY3QuYXNzaWduKHNwaXJpdCwgbG9jYWxUb1dvcmxkKHNoaXAsIHBvaW50KSk7IH1cbiAgc3Bpcml0LmV4cGlyZXNUaWNrID0gZ2FtZS50aWNrICsgZGVmLnN1bW1vbkR1cmF0aW9uO1xuICBzcGlyaXQub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG4gIGNhc3Rlci5hYmlsaXR5Q29vbGRvd25zID0gd2l0aEFiaWxpdHlDb29sZG93bihjYXN0ZXIsIGFiaWxpdHksIGRlZi5jb29sZG93bik7XG4gIGFkZEVmZmVjdChnYW1lLCBkZWYuZWZmZWN0VHlwZSwgc3Bpcml0LngsIHNwaXJpdC55LCA1MCwgeyBzb3VyY2VLaW5kOiBjYXN0ZXIua2luZCwgc291cmNlSWQ6IGNhc3Rlci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXN0ZXIueCwgZnJvbVk6IGNhc3Rlci55LCBmcm9tSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxjYXN0ZXIpLCB0b1g6IHNwaXJpdC54LCB0b1k6IHNwaXJpdC55LCB0b0hlaWdodDogY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsc3Bpcml0KSwgdW5pdElkOiBjYXN0ZXIuaWQsIG93bmVyOiBjYXN0ZXIub3duZXIgfSk7XG4gIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiBhcHBseUN1cnNlKGdhbWU6IEdhbWUsIGNhc3RlcjogVW5pdCwgYWJpbGl0eTogQWJpbGl0eUtpbmQsIHRhcmdldDogVW5pdCwgZGVmOiBFeHRyYWN0PCh0eXBlb2YgQUJJTElUWV9ERUZTKVtBYmlsaXR5S2luZF0sIHsgYmVoYXZpb3I6IFwiY3Vyc2VcIiB9Pikge1xuICBpZiAoIW1hdGNoZXNVbml0VGFyZ2V0KHRhcmdldCwgZGVmLnRhcmdldHMsIGdhbWUpIHx8IGRpc3RhbmNlKGNhc3RlciwgdGFyZ2V0KSA+IGRlZi5yYW5nZSkgcmV0dXJuO1xuICBjb25zdCBkYW1hZ2VNdWx0aXBsaWVyID0gdGFyZ2V0LmVmZmVjdHMuc29tZSgoZWZmZWN0KSA9PiBlZmZlY3QudHlwZSA9PT0gXCJzY29yY2hcIilcbiAgICA/IChkZWYuc2NvcmNoZWREYW1hZ2VNdWx0aXBsaWVyID8/IGRlZi5kYW1hZ2VNdWx0aXBsaWVyKVxuICAgIDogZGVmLmRhbWFnZU11bHRpcGxpZXI7XG4gIHRhcmdldC5lZmZlY3RzID0gdGFyZ2V0LmVmZmVjdHMuZmlsdGVyKChlZmZlY3QpID0+IGVmZmVjdC50eXBlICE9PSBkZWYuc3RhdHVzVHlwZSk7XG4gIHRhcmdldC5lZmZlY3RzLnB1c2goeyB0eXBlOiBkZWYuc3RhdHVzVHlwZSwgcmVtYWluaW5nOiBkZWYuZWZmZWN0RHVyYXRpb24sIC4uLihkYW1hZ2VNdWx0aXBsaWVyICE9PSAwLjQgPyB7IGRhbWFnZU11bHRpcGxpZXIgfSA6IHt9KSB9KTtcbiAgY2FzdGVyLmFiaWxpdHlDb29sZG93bnMgPSB3aXRoQWJpbGl0eUNvb2xkb3duKGNhc3RlciwgYWJpbGl0eSwgZGVmLmNvb2xkb3duKTtcbiAgYWRkRWZmZWN0KGdhbWUsIGRlZi5lZmZlY3RUeXBlLCB0YXJnZXQueCwgdGFyZ2V0LnksIDQ2LCB7IHNvdXJjZUtpbmQ6IGNhc3Rlci5raW5kLCBzb3VyY2VJZDogY2FzdGVyLmlkLCBhY3Rpb25Nb2RlOiBcImNhc3RcIiwgZnJvbVg6IGNhc3Rlci54LCBmcm9tWTogY2FzdGVyLnksIGZyb21IZWlnaHQ6IGNvbWJhdFZpc3VhbEhlaWdodChnYW1lLGNhc3RlciksIHRvWDogdGFyZ2V0LngsIHRvWTogdGFyZ2V0LnksIHRvSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSx0YXJnZXQpLCB1bml0SWQ6IGNhc3Rlci5pZCwgb3duZXI6IGNhc3Rlci5vd25lciB9KTtcbiAgaWYgKGRlZi5zdW1tb25lZERhbWFnZSAmJiB0YXJnZXQuZXhwaXJlc1RpY2sgIT09IHVuZGVmaW5lZCkgYXBwbHlEYW1hZ2UoZ2FtZSwgY2FzdGVyLCB0YXJnZXQsIGRlZi5zdW1tb25lZERhbWFnZSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIDAsIERBTUFHRV9QUk9GSUxFUy5BUkNBTkUpO1xufVxuXG50eXBlIENoYXJnZURlZiA9IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJjaGFyZ2VcIiB9PjtcblxuLy8gQEBAY2hhcmdlIC0gVGhlIGNhdmFscnkncyBjaGFyZ2UgcmlkZXMgdGhlIHB1c2ggcGh5c2ljcyAoc2VlIEBAQHB1c2gpOiBhdCBhbiBlbmVteSB1bml0IGJldHdlZW4gbWluUmFuZ2UgYW5kIHJhbmdlIGF3YXlcbi8vIHRoZSByaWRlciBzaG92ZXMgaXRzZWxmIGF0IHdoZXJlIHRoZSB1bml0IHN0YW5kcywgaGFyZCBlbm91Z2ggdG8gc2xpZGUgb24gYGRyaXZlYCBwYXN0IHRoZSBwb2ludCBvZiBtZWV0aW5nIGl0LCBzbyBpdFxuLy8gYXJyaXZlcyBhdCBhIGdhbGxvcCAoMjQgYSB0aWNrIGF0IHRoZSBtb3N0LCBhYm91dCBzaXggdGltZXMgaXRzIHdhbGspLiBPbmNlIHRoZSB1bml0IGlzIHdpdGhpbiBpdHMgcmVhY2ggaXQgc3RyaWtlcyBvbmNlXG4vLyBmb3IgZGFtYWdlTXVsdGlwbGllciB0aW1lcyBpdHMgd2VhcG9uJ3MgYmxvdywgYXMgYW55IG1lbGVlIGJsb3cgbGFuZHMgKGN1cnNlLCBhcm1vciBhbmQgaXRzIHN0YW5jZSBjb3VudCBhcyBldmVyKSwgYW5kXG4vLyB3aGF0IGlzIGxlZnQgb2YgaXRzIHNsaWRlIGNhcnJpZXMgaXQgaW50byB0aGUgdW5pdDogdGhlIHR3byBtZWV0IGFzIGFueSB0d28gYm9kaWVzIGRvLCBzbyBhIGtuaWdodCB0aHJvd3MgYSBmb290bWFuXG4vLyBiYWNrIGFuZCBoYXJkbHkgbW92ZXMgYSBnb2xlbS4gQSB1bml0IHRoYXQgd2Fsa3Mgb3V0IG9mIHRoZSBsaW5lIG1heSBiZSBtaXNzZWQ6IGEgc2xpZGUgdGhhdCBydW5zIG91dCB3aXRoIHRoZSB1bml0XG4vLyBvdXQgb2YgcmVhY2ggc3RyaWtlcyBub3RoaW5nLiBUaGUgY2hhcmdlIHJ1bnMgaXRzIGNvdXJzZTogYW4gb3JkZXIgZ2l2ZW4gbWVhbndoaWxlIHdhaXRzIGZvciBpdCAoc2VlXG4vLyBhc3NpZ25Vbml0T3JkZXIpLiBUaGUgcmlkZXIgdGhlbiB0YWtlcyB1cCBgcmVzdW1lYDogd2hhdCBpdCB3YXMgZG9pbmcsIG5vdyBhaW1lZCBhdCB0aGUgdW5pdCBpdCBjaGFyZ2VkLiBJdCB1c2VkIHRvXG4vLyBkYXNoIGF0IDMwIGEgdGljaywgc3RlZXJpbmcgYWZ0ZXIgdGhlIHVuaXQsIGFuZCBzdG9wIGRlYWQgYXQgc3RyaWtpbmcgZGlzdGFuY2UuXG5mdW5jdGlvbiBpbkNoYXJnZVdpbmRvdyhjYXN0ZXI6IFVuaXQsIHRhcmdldDogVW5pdCwgZGVmOiBDaGFyZ2VEZWYpIHtcbiAgY29uc3QgZ2FwID0gZGlzdGFuY2UoY2FzdGVyLCB0YXJnZXQpO1xuICByZXR1cm4gZ2FwID49IGRlZi5taW5SYW5nZSAmJiBnYXAgPD0gZGVmLnJhbmdlO1xufVxuXG5mdW5jdGlvbiBzdGFydENoYXJnZShnYW1lOiBHYW1lLCBjYXN0ZXI6IFVuaXQsIGFiaWxpdHk6IEFiaWxpdHlLaW5kLCB0YXJnZXQ6IFVuaXQsIGRlZjogQ2hhcmdlRGVmLCBjb21tYW5kZWQ6IGJvb2xlYW4pIHtcbiAgaWYgKCFtYXRjaGVzVW5pdFRhcmdldCh0YXJnZXQsIGRlZi50YXJnZXRzLCBnYW1lKSkgcmV0dXJuO1xuICBjb25zdCBjdXJyZW50ID0gY2FzdGVyLm9yZGVyLnR5cGUgPT09IFwiY2hhcmdlXCIgPyBjYXN0ZXIub3JkZXIucmVzdW1lIDogY2FzdGVyLm9yZGVyO1xuICAvLyBDaGFyZ2VkIGZyb20gYSBzdGFuZHN0aWxsIG9uIGl0cyBvd24sIHRoZSByaWRlciBrZWVwcyBhbiBpZGxlIHVuaXQncyBsZWFzaCBiYWNrIHRvIHdoZXJlIGl0IHN0b29kLlxuICBjb25zdCByZXN1bWU6IFNldHRsZWRVbml0T3JkZXIgPVxuICAgIGN1cnJlbnQudHlwZSA9PT0gXCJhdHRhY2tNb3ZlXCJcbiAgICAgID8geyB0eXBlOiBcImF0dGFja01vdmVcIiwgeDogY3VycmVudC54LCB5OiBjdXJyZW50LnksIHRhcmdldElkOiB0YXJnZXQuaWQgfVxuICAgICAgOiBjdXJyZW50LnR5cGUgPT09IFwiYXR0YWNrXCIgJiYgY3VycmVudC5sZWFzaFggIT09IHVuZGVmaW5lZCAmJiBjdXJyZW50LmxlYXNoWSAhPT0gdW5kZWZpbmVkXG4gICAgICAgID8geyB0eXBlOiBcImF0dGFja1wiLCB0YXJnZXRJZDogdGFyZ2V0LmlkLCBsZWFzaFg6IGN1cnJlbnQubGVhc2hYLCBsZWFzaFk6IGN1cnJlbnQubGVhc2hZIH1cbiAgICAgICAgOiBjdXJyZW50LnR5cGUgPT09IFwiaWRsZVwiICYmICFjb21tYW5kZWRcbiAgICAgICAgICA/IHsgdHlwZTogXCJhdHRhY2tcIiwgdGFyZ2V0SWQ6IHRhcmdldC5pZCwgbGVhc2hYOiBjYXN0ZXIueCwgbGVhc2hZOiBjYXN0ZXIueSB9XG4gICAgICAgICAgOiB7IHR5cGU6IFwiYXR0YWNrXCIsIHRhcmdldElkOiB0YXJnZXQuaWQgfTtcbiAgY2FzdGVyLmFiaWxpdHlDb29sZG93bnMgPSB3aXRoQWJpbGl0eUNvb2xkb3duKGNhc3RlciwgYWJpbGl0eSwgZGVmLmNvb2xkb3duKTtcbiAgY2FzdGVyLm9yZGVyID0geyB0eXBlOiBcImNoYXJnZVwiLCB0YXJnZXRJZDogdGFyZ2V0LmlkLCByZXN1bWUgfTtcbiAgaWYgKGNvbW1hbmRlZCkgY2FzdGVyLm9yZGVyUXVldWUgPSBbXTtcbiAgY29uc3QgbWVldGluZyA9IE1hdGgubWF4KDAsIGRpc3RhbmNlKGNhc3RlciwgdGFyZ2V0KSAtIGNhc3Rlci5yYWRpdXMgLSB0YXJnZXQucmFkaXVzKTtcbiAgc2hvdmUoY2FzdGVyLCB0YXJnZXQueCAtIGNhc3Rlci54LCB0YXJnZXQueSAtIGNhc3Rlci55LCBtZWV0aW5nICsgZGVmLmRyaXZlKTtcbiAgY29uc3QgZXhwZWN0ZWQgPSBNYXRoLm1heCgxLCBNYXRoLmNlaWwoKGRpc3RhbmNlKGNhc3RlciwgdGFyZ2V0KSAtIGNhc3Rlci5hdHRhY2tSYW5nZSkgLyBNQVhfU0xJREVfU1RFUCkpO1xuICBhZGRFZmZlY3QoZ2FtZSwgZGVmLmVmZmVjdFR5cGUsIGNhc3Rlci54LCBjYXN0ZXIueSwgZXhwZWN0ZWQsIHsgZnJvbVg6IGNhc3Rlci54LCBmcm9tWTogY2FzdGVyLnksIHRvWDogdGFyZ2V0LngsIHRvWTogdGFyZ2V0LnksIG93bmVyOiBjYXN0ZXIub3duZXIsIHNvdXJjZUtpbmQ6IGNhc3Rlci5raW5kLCB1bml0SWQ6IGNhc3Rlci5pZCB9KTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlQ2hhcmdlT3JkZXIoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBjb25zdCBvcmRlciA9IHVuaXQub3JkZXI7XG4gIGlmIChvcmRlci50eXBlICE9PSBcImNoYXJnZVwiKSByZXR1cm47XG4gIGNvbnN0IGFiaWxpdHkgPSBVTklUX0RFRlNbdW5pdC5raW5kXS5hYmlsaXRpZXMuZmluZCgoY2FuZGlkYXRlKSA9PiBBQklMSVRZX0RFRlNbY2FuZGlkYXRlXS5iZWhhdmlvciA9PT0gXCJjaGFyZ2VcIik7XG4gIGNvbnN0IGRlZiA9IGFiaWxpdHkgPyBBQklMSVRZX0RFRlNbYWJpbGl0eV0gOiB1bmRlZmluZWQ7XG4gIGNvbnN0IHRhcmdldCA9IGZpbmRUYXJnZXQoZ2FtZSwgb3JkZXIudGFyZ2V0SWQpO1xuICBpZiAoIWRlZiB8fCBkZWYuYmVoYXZpb3IgIT09IFwiY2hhcmdlXCIgfHwgIXRhcmdldCB8fCAhaXNVbml0KHRhcmdldCkgfHwgdGFyZ2V0LmhwIDw9IDApIHtcbiAgICBlbmRDaGFyZ2UodW5pdCwgb3JkZXIucmVzdW1lKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGRpc3RhbmNlKHVuaXQsIHRhcmdldCkgPD0gdW5pdC5hdHRhY2tSYW5nZSkge1xuICAgIGNvbnN0IGRhbWFnZSA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQodW5pdC5hdHRhY2tEYW1hZ2UgKiBvdXRnb2luZ0RhbWFnZU11bHRpcGxpZXIoZ2FtZSwgdW5pdCkgKiBkZWYuZGFtYWdlTXVsdGlwbGllcikpO1xuICAgIGFwcGx5QXR0YWNrRGFtYWdlKGdhbWUsIHVuaXQsIHRhcmdldCwgZGFtYWdlLCB1bml0LmF0dGFja1JhbmdlKTtcbiAgICBhZGRFZmZlY3QoZ2FtZSwgXCJjaGFyZ2VJbXBhY3RcIiwgdGFyZ2V0LngsIHRhcmdldC55LCBDSEFSR0VfSU1QQUNUX1RJQ0tTLCB7IGZyb21YOiB1bml0LngsIGZyb21ZOiB1bml0LnksIHRvWDogdGFyZ2V0LngsIHRvWTogdGFyZ2V0LnksIG93bmVyOiB1bml0Lm93bmVyLCBzb3VyY2VLaW5kOiB1bml0LmtpbmQsIHVuaXRJZDogdW5pdC5pZCwgc291cmNlSWQ6IHVuaXQuaWQsIGFjdGlvbk1vZGU6IFwiYXR0YWNrXCIsIGZyb21IZWlnaHQ6Y29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsdW5pdCksdG9IZWlnaHQ6Y29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsdGFyZ2V0KSB9KTtcbiAgICB1bml0LmNvb2xkb3duID0gdW5pdC5hdHRhY2tDb29sZG93bjtcbiAgICBlbmRDaGFyZ2UodW5pdCwgb3JkZXIucmVzdW1lKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHVuaXQucHVzaFggPT09IHVuZGVmaW5lZCkgZW5kQ2hhcmdlKHVuaXQsIG9yZGVyLnJlc3VtZSk7XG59XG5cbmZ1bmN0aW9uIGVuZENoYXJnZSh1bml0OiBVbml0LCByZXN1bWU6IFNldHRsZWRVbml0T3JkZXIpIHtcbiAgY29uc3QgbmV4dCA9IHVuaXQub3JkZXJRdWV1ZT8uc2hpZnQoKTtcbiAgdW5pdC5vcmRlciA9IG5leHQgPz8gcmVzdW1lO1xufVxuXG4vLyBAQEBhdXRvY2FzdC1zdGVwIC0gRWFjaCByZWFkeSBhYmlsaXR5IGEgdW5pdCBoYXMgc3dpdGNoZWQgb24gKHNlZSBhdXRvY2FzdCkgbG9va3MgZm9yIGl0cyBtb21lbnQsIGFzIFdhcmNyYWZ0IElJSSB1bml0c1xuLy8gZG86IG9ubHkgd2hpbGUgdGhlIHVuaXQgaXMgaWRsZSwgYXR0YWNraW5nIG9yIGF0dGFjay1tb3ZpbmcsIG5ldmVyIHVuZGVyIGEgbW92ZSB0aGUgcGxheWVyIGdhdmUuIEEgY3JlZXAgbWluZGluZyBpdHNcbi8vIGNhbXAgaXMgbm9ib2R5J3MgdGFyZ2V0IHVudGlsIGl0IGZpZ2h0czogYSByaWRlciBwYXNzaW5nIGEgY2FtcCBkb2VzIG5vdCBjaGFyZ2UgaXQsIGEgd2l0Y2ggZG9lcyBub3QgY3Vyc2UgaXQuXG4vLyAtIGhlYWw6IHRoZSBhbGx5IGluIHJlYWNoIG1pc3NpbmcgdGhlIG1vc3QgaGVhbHRoLCBpZiBpdCBtaXNzZXMgYXQgbGVhc3QgaGFsZiBhIGhlYWw7XG4vLyAtIGN1cnNlOiBhbiBlbmVteSBpbiByZWFjaCB0aGF0IGlzIGZpZ2h0aW5nIChvciBhbnksIHdoaWxlIHRoZSBjYXN0ZXIgZmlnaHRzKSwgbm90IGFscmVhZHkgY3Vyc2VkOyBhIHN1bW1vbmVkIHVuaXQgZmlyc3Rcbi8vICAgd2hlbiB0aGUgY3Vyc2Uga2lsbHMgdGhvc2UsIHRoZW4gdGhlIGNhc3RlcidzIG93biB0YXJnZXQsIHRoZW4gdGhlIG5lYXJlc3Q7XG4vLyAtIHN1bW1vbjogd2hlbiBhbiBlbmVteSB0aGF0IGlzIGZpZ2h0aW5nLCBvciBhbnkgZW5lbXkgcGxheWVyJ3MgdW5pdCwgY29tZXMgbmVhciBhbmQgbm9uZSBvZiB0aGUgY2FzdGVyJ3Mgc3VtbW9ucyBzdGFuZHNcbi8vICAgYmVzaWRlIGl0O1xuLy8gLSBjaGFyZ2U6IHRoZSByaWRlcidzIG93biB0YXJnZXQgd2hlbiBpdCBpcyBhIHVuaXQgaW5zaWRlIHRoZSB3aW5kb3csIG9yLCBpZGxlIG9yIGF0dGFjay1tb3ZpbmcsIHRoZSBuZWFyZXN0IGVuZW15IHVuaXRcbi8vICAgaW5zaWRlIGl0IHRoYXQgbm8gcmlkZXIgb2YgaXRzIHNpZGUgaXMgYWxyZWFkeSBjaGFyZ2luZyAodGhlIG5lYXJlc3Qgb2YgYWxsIG9ubHkgd2hlbiBldmVyeSBvbmUgaXMgdGFrZW4pOiBwaWNraW5nXG4vLyAgIHRoZSBuZWFyZXN0IGFsb25lLCBhIGxpbmUgb2YgdHdlbHZlIHJpZGVycyBhbGwgY2hhcmdlZCB0aGUgc2FtZSByYXZhZ2VyLCB0aGUgbGFzdCBmb3VyIGxhbmRlZCBvbiBhIGNvcnBzZSwgYW5kIHRoZVxuLy8gICB3aW5nLCBidW5jaGVkIG9uIG9uZSBzcG90LCB3YXMgY3V0IGRvd24uXG5jb25zdCBBVVRPQ0FTVF9FVkVSWV9USUNLUyA9IDI7XG5jb25zdCBBVVRPQ0FTVF9PUkRFUlMgPSBuZXcgU2V0PFVuaXRPcmRlcltcInR5cGVcIl0+KFtcImlkbGVcIiwgXCJhdHRhY2tcIiwgXCJhdHRhY2tNb3ZlXCIsIFwiaG9sZFwiLCBcImFpbVwiXSk7XG5jb25zdCBTVU1NT05fQUxFUlRfTUFSR0lOID0gMTAwO1xuY29uc3QgU1VNTU9OX0NPTVBBTllfUkFOR0UgPSAzMjA7XG5jb25zdCBTVU1NT05fU1RFUCA9IDYwO1xuY29uc3QgQ0hBUkdFX0lNUEFDVF9USUNLUyA9IDEyO1xuXG5mdW5jdGlvbiBhdXRvY2FzdFN0ZXAoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAoIUFVVE9DQVNUX09SREVSUy5oYXModW5pdC5vcmRlci50eXBlKSkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IGFiaWxpdHkgb2YgdW5pdEFiaWxpdGllcyh1bml0KSkge1xuICAgIGlmIChhYmlsaXR5Q29vbGRvd24odW5pdCwgYWJpbGl0eSkgPiAwIHx8ICFhdXRvY2FzdEVuYWJsZWQodW5pdCwgYWJpbGl0eSkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGRlZiA9IEFCSUxJVFlfREVGU1thYmlsaXR5XTtcbiAgICBpZiAoZGVmLmJlaGF2aW9yID09PSBcInZldGVyYW5cIikge1xuICAgICAgaWYgKGFwcGx5VmV0ZXJhbkFiaWxpdHkoZ2FtZSwgdW5pdCwgZGVmLCB0cnVlKSkgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAoZGVmLmJlaGF2aW9yID09PSBcImhlYWxcIikge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gYXV0b2Nhc3RIZWFsVGFyZ2V0KGdhbWUsIHVuaXQsIGRlZik7XG4gICAgICBpZiAodGFyZ2V0KSByZXR1cm4gYXBwbHlIZWFsKGdhbWUsIHVuaXQsIGFiaWxpdHksIHRhcmdldCwgZGVmKTtcbiAgICB9IGVsc2UgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJjdXJzZVwiKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBhdXRvY2FzdEN1cnNlVGFyZ2V0KGdhbWUsIHVuaXQsIGRlZik7XG4gICAgICBpZiAodGFyZ2V0KSByZXR1cm4gYXBwbHlDdXJzZShnYW1lLCB1bml0LCBhYmlsaXR5LCB0YXJnZXQsIGRlZik7XG4gICAgfSBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwic3VtbW9uXCIpIHtcbiAgICAgIGNvbnN0IHBvaW50ID0gYXV0b2Nhc3RTdW1tb25Qb2ludChnYW1lLCB1bml0LCBkZWYpO1xuICAgICAgaWYgKHBvaW50ICYmIGFwcGx5U3VtbW9uKGdhbWUsIHVuaXQsIGFiaWxpdHksIHBvaW50LngsIHBvaW50LnksIGRlZikpIHJldHVybjtcbiAgICB9IGVsc2UgaWYgKGRlZi5iZWhhdmlvciA9PT0gXCJzdG9tcFwiKSB7XG4gICAgICBpZiAoYXBwbHlTdG9tcChnYW1lLCB1bml0LCBhYmlsaXR5LCBkZWYpKSByZXR1cm47XG4gICAgfSBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiYmxvb2RsdXN0XCIpIHtcbiAgICAgIGlmIChhcHBseUJsb29kbHVzdChnYW1lLCB1bml0LCBhYmlsaXR5LCBkZWYpKSByZXR1cm47XG4gICAgfSBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwid2ViXCIpIHtcbiAgICAgIGlmIChhcHBseVdlYihnYW1lLCB1bml0LCBhYmlsaXR5LCBkZWYpKSByZXR1cm47XG4gICAgfSBlbHNlIGlmIChkZWYuYmVoYXZpb3IgPT09IFwiY2hhcmdlXCIgJiYgdW5pdC5vcmRlci50eXBlICE9PSBcImhvbGRcIikge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gYXV0b2Nhc3RDaGFyZ2VUYXJnZXQoZ2FtZSwgdW5pdCwgZGVmKTtcbiAgICAgIGlmICh0YXJnZXQpIHJldHVybiBzdGFydENoYXJnZShnYW1lLCB1bml0LCBhYmlsaXR5LCB0YXJnZXQsIGRlZiwgZmFsc2UpO1xuICAgIH1cbiAgfVxufVxuXG4vLyBAQEBjcmVlcC1hYmlsaXRpZXMgaW4gcGxheTogZWFjaCBvbmx5IHdoZW4gYSBmb2UgaXMgYWJvdXQgKHNlZSBpc0F1dG9jYXN0Rm9lKSwgc28gYW4gaWRsZSBjYW1wIGtlZXBzIGl0cyBwb3dlcnMuXG5mdW5jdGlvbiBhcHBseVN0b21wKGdhbWU6IEdhbWUsIGNhc3RlcjogVW5pdCwgYWJpbGl0eTogQWJpbGl0eUtpbmQsIGRlZjogRXh0cmFjdDwodHlwZW9mIEFCSUxJVFlfREVGUylbQWJpbGl0eUtpbmRdLCB7IGJlaGF2aW9yOiBcInN0b21wXCIgfT4pIHtcbiAgY29uc3Qgc3RydWNrOiBVbml0W10gPSBbXTtcbiAgZm9yRWFjaE5lYXJieVVuaXQoZ2FtZSwgY2FzdGVyLCBkZWYucmFuZ2UsIChjYW5kaWRhdGUpID0+IHtcbiAgICBpZiAobWF0Y2hlc1VuaXRUYXJnZXQoY2FuZGlkYXRlLCBkZWYudGFyZ2V0cywgZ2FtZSkgJiYgZGlzdGFuY2UoY2FzdGVyLCBjYW5kaWRhdGUpIDw9IGRlZi5yYW5nZSAmJiBpc0F1dG9jYXN0Rm9lKGdhbWUsIGNhc3RlciwgY2FuZGlkYXRlKSkgc3RydWNrLnB1c2goY2FuZGlkYXRlKTtcbiAgfSk7XG4gIGlmIChzdHJ1Y2subGVuZ3RoID09PSAwKSByZXR1cm4gZmFsc2U7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBzdHJ1Y2spIHNldFN0YXR1cyh1bml0LCB7IHR5cGU6IFwic3R1blwiLCByZW1haW5pbmc6IGRlZi5lZmZlY3REdXJhdGlvbiB9KTtcbiAgY2FzdGVyLmFiaWxpdHlDb29sZG93bnMgPSB3aXRoQWJpbGl0eUNvb2xkb3duKGNhc3RlciwgYWJpbGl0eSwgZGVmLmNvb2xkb3duKTtcbiAgYWRkRWZmZWN0KGdhbWUsIFwic3RvbXBcIiwgY2FzdGVyLngsIGNhc3Rlci55LCAyNCwgeyByYWRpdXM6IGRlZi5yYW5nZSwgb3duZXI6IGNhc3Rlci5vd25lciwgc291cmNlS2luZDogY2FzdGVyLmtpbmQsIHVuaXRJZDogY2FzdGVyLmlkLCBzb3VyY2VJZDogY2FzdGVyLmlkLCBhY3Rpb25Nb2RlOiBcImNhc3RcIiwgZnJvbVg6IGNhc3Rlci54LCBmcm9tWTogY2FzdGVyLnksIHRvWDogY2FzdGVyLngsIHRvWTogY2FzdGVyLnkgfSk7XG4gIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiBhcHBseUJsb29kbHVzdChnYW1lOiBHYW1lLCBjYXN0ZXI6IFVuaXQsIGFiaWxpdHk6IEFiaWxpdHlLaW5kLCBkZWY6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJibG9vZGx1c3RcIiB9Pikge1xuICBsZXQgYmVzdDogVW5pdCB8IHVuZGVmaW5lZDtcbiAgZm9yRWFjaE5lYXJieVVuaXQoZ2FtZSwgY2FzdGVyLCBkZWYucmFuZ2UsIChjYW5kaWRhdGUpID0+IHtcbiAgICBpZiAoIW1hdGNoZXNVbml0VGFyZ2V0KGNhbmRpZGF0ZSwgZGVmLnRhcmdldHMsIGdhbWUpIHx8IGRpc3RhbmNlKGNhc3RlciwgY2FuZGlkYXRlKSA+IGRlZi5yYW5nZSB8fCBjYW5kaWRhdGUuaHAgPD0gMCB8fCBjYW5kaWRhdGUub3duZXIgIT09IGNhc3Rlci5vd25lciB8fCAhaXNFbmdhZ2VkKGNhbmRpZGF0ZSkpIHJldHVybjtcbiAgICBpZiAoY2FuZGlkYXRlLmVmZmVjdHMuc29tZSgoZWZmZWN0KSA9PiBlZmZlY3QudHlwZSA9PT0gXCJibG9vZGx1c3RcIikpIHJldHVybjtcbiAgICBpZiAoIWJlc3QgfHwgY2FuZGlkYXRlLmF0dGFja0RhbWFnZSA+IGJlc3QuYXR0YWNrRGFtYWdlKSBiZXN0ID0gY2FuZGlkYXRlO1xuICB9KTtcbiAgaWYgKCFiZXN0KSByZXR1cm4gZmFsc2U7XG4gIHNldFN0YXR1cyhiZXN0LCB7IHR5cGU6IFwiYmxvb2RsdXN0XCIsIHJlbWFpbmluZzogZGVmLmVmZmVjdER1cmF0aW9uIH0pO1xuICBjYXN0ZXIuYWJpbGl0eUNvb2xkb3ducyA9IHdpdGhBYmlsaXR5Q29vbGRvd24oY2FzdGVyLCBhYmlsaXR5LCBkZWYuY29vbGRvd24pO1xuICBhZGRFZmZlY3QoZ2FtZSwgXCJibG9vZGx1c3RcIiwgYmVzdC54LCBiZXN0LnksIDMwLCB7IG93bmVyOiBjYXN0ZXIub3duZXIsIHNvdXJjZUtpbmQ6IGNhc3Rlci5raW5kLCB1bml0SWQ6IGNhc3Rlci5pZCwgc291cmNlSWQ6IGNhc3Rlci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXN0ZXIueCwgZnJvbVk6IGNhc3Rlci55LCBmcm9tSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxjYXN0ZXIpLCB0b1g6IGJlc3QueCwgdG9ZOiBiZXN0LnksIHRvSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxiZXN0KSB9KTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbmZ1bmN0aW9uIGFwcGx5V2ViKGdhbWU6IEdhbWUsIGNhc3RlcjogVW5pdCwgYWJpbGl0eTogQWJpbGl0eUtpbmQsIGRlZjogRXh0cmFjdDwodHlwZW9mIEFCSUxJVFlfREVGUylbQWJpbGl0eUtpbmRdLCB7IGJlaGF2aW9yOiBcIndlYlwiIH0+KSB7XG4gIGxldCBiZXN0OiBVbml0IHwgdW5kZWZpbmVkO1xuICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCBjYXN0ZXIsIGRlZi5yYW5nZSwgKGNhbmRpZGF0ZSkgPT4ge1xuICAgIGlmICghbWF0Y2hlc1VuaXRUYXJnZXQoY2FuZGlkYXRlLCBkZWYudGFyZ2V0cywgZ2FtZSkgfHwgZGlzdGFuY2UoY2FzdGVyLCBjYW5kaWRhdGUpID4gZGVmLnJhbmdlIHx8ICFpc0F1dG9jYXN0Rm9lKGdhbWUsIGNhc3RlciwgY2FuZGlkYXRlKSB8fCBjYW5kaWRhdGUuZWZmZWN0cy5zb21lKChlZmZlY3QpID0+IGVmZmVjdC50eXBlID09PSBcInJvb3RcIikpIHJldHVybjtcbiAgICBpZiAoIWJlc3QgfHwgZGlzdGFuY2UoY2FzdGVyLCBjYW5kaWRhdGUpIDwgZGlzdGFuY2UoY2FzdGVyLCBiZXN0KSkgYmVzdCA9IGNhbmRpZGF0ZTtcbiAgfSk7XG4gIGlmICghYmVzdCkgcmV0dXJuIGZhbHNlO1xuICBzZXRTdGF0dXMoYmVzdCwgeyB0eXBlOiBcInJvb3RcIiwgcmVtYWluaW5nOiBkZWYuZWZmZWN0RHVyYXRpb24gfSk7XG4gIGNhc3Rlci5hYmlsaXR5Q29vbGRvd25zID0gd2l0aEFiaWxpdHlDb29sZG93bihjYXN0ZXIsIGFiaWxpdHksIGRlZi5jb29sZG93bik7XG4gIGFkZEVmZmVjdChnYW1lLCBcIndlYlwiLCBiZXN0LngsIGJlc3QueSwgZGVmLmVmZmVjdER1cmF0aW9uLCB7IG93bmVyOiBjYXN0ZXIub3duZXIsIHNvdXJjZUtpbmQ6IGNhc3Rlci5raW5kLCB1bml0SWQ6IGNhc3Rlci5pZCwgc291cmNlSWQ6IGNhc3Rlci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXN0ZXIueCwgZnJvbVk6IGNhc3Rlci55LCBmcm9tSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxjYXN0ZXIpLCB0b1g6IGJlc3QueCwgdG9ZOiBiZXN0LnksIHRvSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSxiZXN0KSB9KTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIEEgc3RhdHVzIHB1dCBvbiBhbmV3OiBvbmUgb2YgaXRzIGtpbmQgYXQgYSB0aW1lLCB0aGUgbGF0ZXIgcmVwbGFjaW5nIHRoZSBlYXJsaWVyLlxuZnVuY3Rpb24gc2V0U3RhdHVzKHVuaXQ6IFVuaXQsIHN0YXR1czogVW5pdFN0YXR1c0VmZmVjdCkge1xuICB1bml0LmVmZmVjdHMgPSB1bml0LmVmZmVjdHMuZmlsdGVyKChlZmZlY3QpID0+IGVmZmVjdC50eXBlICE9PSBzdGF0dXMudHlwZSk7XG4gIHVuaXQuZWZmZWN0cy5wdXNoKHN0YXR1cyk7XG59XG5cbi8vIFRoZSBzaGFyZSBvZiBpdHMgcGFjZSBhIHVuaXQga2VlcHMgdW5kZXIgaXRzIHN0YXR1c2VzOiBub25lIHJvb3RlZCBvciBzdHVubmVkLCBhIG5ldCdzIHNoYXJlIHNsb3dlZC5cbmZ1bmN0aW9uIHN0YXR1c1BhY2UodW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5lZmZlY3RzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDE7XG4gIGxldCBwYWNlID0gMTtcbiAgZm9yIChjb25zdCBlZmZlY3Qgb2YgdW5pdC5lZmZlY3RzKSB7XG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcInJvb3RcIiB8fCBlZmZlY3QudHlwZSA9PT0gXCJzdHVuXCIpIHJldHVybiAwO1xuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJzbG93XCIpIHBhY2UgPSBTTE9XX1BBQ0U7XG4gIH1cbiAgcmV0dXJuIHBhY2U7XG59XG5cbi8vIFRoZSB0aWNrcyBiZXR3ZWVuIGEgdW5pdCdzIGJsb3dzOiBibG9vZGx1c3QncyBxdWlja2VyLlxuZnVuY3Rpb24gYXR0YWNrQ29vbGRvd25PZihnYW1lOiBHYW1lLCB1bml0OiBVbml0LCBiYXNlQ29vbGRvd24gPSB1bml0LmF0dGFja0Nvb2xkb3duKSB7XG4gIGNvbnN0IHNwZWVkID0gKGdhbWUudmV0ZXJhbkZyYW1lPy5nZXQodW5pdC5pZCk/LmF0dGFja1NwZWVkTXVsdGlwbGllciA/PyAxKSAqIHRlbXBvcmFyeUF0dGFja1NwZWVkTXVsdGlwbGllcih1bml0KTtcbiAgcmV0dXJuIHNwZWVkID09PSAxID8gYmFzZUNvb2xkb3duIDogTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChiYXNlQ29vbGRvd24gLyBzcGVlZCkpO1xufVxuXG4vLyBGaWdodGluZzogYXR0YWNraW5nLCBjaGFyZ2luZywgb3IgYXR0YWNrLW1vdmluZyBvbnRvIGEgdGFyZ2V0LlxuZnVuY3Rpb24gaXNFbmdhZ2VkKHVuaXQ6IFVuaXQpIHtcbiAgcmV0dXJuIHVuaXQub3JkZXIudHlwZSA9PT0gXCJhdHRhY2tcIiB8fCB1bml0Lm9yZGVyLnR5cGUgPT09IFwiY2hhcmdlXCIgfHwgKHVuaXQub3JkZXIudHlwZSA9PT0gXCJhdHRhY2tNb3ZlXCIgJiYgdW5pdC5vcmRlci50YXJnZXRJZCAhPT0gdW5kZWZpbmVkKTtcbn1cblxuLy8gQW4gZW5lbXkgdGhlIHVuaXQncyBvd24gc3BlbGxzIGFuZCBjaGFyZ2VzIG1heSBwaWNrOiBhIHBsYXllcidzIHVuaXQsIG9yIGEgY3JlZXAgdGhhdCBpcyBhbHJlYWR5IGZpZ2h0aW5nLlxuZnVuY3Rpb24gaXNBdXRvY2FzdEZvZShnYW1lOiBHYW1lLCBjYXN0ZXI6IFVuaXQsIGNhbmRpZGF0ZTogVW5pdCkge1xuICByZXR1cm4gY2FuZGlkYXRlLmhwID4gMCAmJiBhcmVFbmVteU93bmVycyhnYW1lLCBjYXN0ZXIub3duZXIsIGNhbmRpZGF0ZS5vd25lcikgJiYgKGNhbmRpZGF0ZS5vd25lciAhPT0gXCJuZXV0cmFsXCIgfHwgaXNFbmdhZ2VkKGNhbmRpZGF0ZSkpO1xufVxuXG5mdW5jdGlvbiBhdXRvY2FzdEhlYWxUYXJnZXQoZ2FtZTogR2FtZSwgY2FzdGVyOiBVbml0LCBkZWY6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJoZWFsXCIgfT4pIHtcbiAgbGV0IGJlc3Q6IFVuaXQgfCB1bmRlZmluZWQ7XG4gIGxldCBiZXN0TWlzc2luZyA9IGRlZi5oZWFsQW1vdW50IC8gMjtcbiAgZm9yRWFjaE5lYXJieVVuaXQoZ2FtZSwgY2FzdGVyLCBkZWYucmFuZ2UsIChjYW5kaWRhdGUpID0+IHtcbiAgICBpZiAoIW1hdGNoZXNVbml0VGFyZ2V0KGNhbmRpZGF0ZSwgZGVmLnRhcmdldHMsIGdhbWUpIHx8ICFjYW5SZWNlaXZlSGVhbGluZyhjYW5kaWRhdGUsIGdhbWUpIHx8IGNhbmRpZGF0ZS5ocCA8PSAwIHx8IGFyZUVuZW15T3duZXJzKGdhbWUsIGNhc3Rlci5vd25lciwgY2FuZGlkYXRlLm93bmVyKSB8fCBkaXN0YW5jZShjYXN0ZXIsIGNhbmRpZGF0ZSkgPiBkZWYucmFuZ2UpIHJldHVybjtcbiAgICBjb25zdCBtaXNzaW5nID0gY2FuZGlkYXRlLm1heEhwIC0gY2FuZGlkYXRlLmhwO1xuICAgIGlmIChtaXNzaW5nIDwgYmVzdE1pc3NpbmcgfHwgKG1pc3NpbmcgPT09IGJlc3RNaXNzaW5nICYmIGJlc3QpKSByZXR1cm47XG4gICAgYmVzdCA9IGNhbmRpZGF0ZTtcbiAgICBiZXN0TWlzc2luZyA9IG1pc3Npbmc7XG4gIH0pO1xuICByZXR1cm4gYmVzdDtcbn1cblxuZnVuY3Rpb24gYXV0b2Nhc3RDdXJzZVRhcmdldChnYW1lOiBHYW1lLCBjYXN0ZXI6IFVuaXQsIGRlZjogRXh0cmFjdDwodHlwZW9mIEFCSUxJVFlfREVGUylbQWJpbGl0eUtpbmRdLCB7IGJlaGF2aW9yOiBcImN1cnNlXCIgfT4pIHtcbiAgY29uc3QgY2FzdGVyRmlnaHRzID0gaXNFbmdhZ2VkKGNhc3Rlcik7XG4gIGNvbnN0IG93biA9IGNhc3Rlci5vcmRlci50eXBlID09PSBcImF0dGFja1wiIHx8IGNhc3Rlci5vcmRlci50eXBlID09PSBcImF0dGFja01vdmVcIiA/IGNhc3Rlci5vcmRlci50YXJnZXRJZCA6IHVuZGVmaW5lZDtcbiAgbGV0IGJlc3Q6IFVuaXQgfCB1bmRlZmluZWQ7XG4gIGxldCBiZXN0U2NvcmUgPSBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFk7XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIGNhc3RlciwgZGVmLnJhbmdlLCAoY2FuZGlkYXRlKSA9PiB7XG4gICAgaWYgKCFtYXRjaGVzVW5pdFRhcmdldChjYW5kaWRhdGUsIGRlZi50YXJnZXRzLCBnYW1lKSB8fCAhaXNBdXRvY2FzdEZvZShnYW1lLCBjYXN0ZXIsIGNhbmRpZGF0ZSkgfHwgZGlzdGFuY2UoY2FzdGVyLCBjYW5kaWRhdGUpID4gZGVmLnJhbmdlKSByZXR1cm47XG4gICAgaWYgKCFjYXN0ZXJGaWdodHMgJiYgIWlzRW5nYWdlZChjYW5kaWRhdGUpKSByZXR1cm47XG4gICAgaWYgKGNhbmRpZGF0ZS5lZmZlY3RzLnNvbWUoKGVmZmVjdCkgPT4gZWZmZWN0LnR5cGUgPT09IGRlZi5zdGF0dXNUeXBlKSkgcmV0dXJuO1xuICAgIGNvbnN0IHNjb3JlID0gKGRlZi5zdW1tb25lZERhbWFnZSAmJiBjYW5kaWRhdGUuZXhwaXJlc1RpY2sgIT09IHVuZGVmaW5lZCA/IDJfMDAwIDogMCkgKyAoY2FuZGlkYXRlLmlkID09PSBvd24gPyAxXzAwMCA6IDApIC0gZGlzdGFuY2UoY2FzdGVyLCBjYW5kaWRhdGUpO1xuICAgIGlmIChzY29yZSA8PSBiZXN0U2NvcmUpIHJldHVybjtcbiAgICBiZXN0ID0gY2FuZGlkYXRlO1xuICAgIGJlc3RTY29yZSA9IHNjb3JlO1xuICB9KTtcbiAgcmV0dXJuIGJlc3Q7XG59XG5cbmZ1bmN0aW9uIGF1dG9jYXN0U3VtbW9uUG9pbnQoZ2FtZTogR2FtZSwgY2FzdGVyOiBVbml0LCBkZWY6IEV4dHJhY3Q8KHR5cGVvZiBBQklMSVRZX0RFRlMpW0FiaWxpdHlLaW5kXSwgeyBiZWhhdmlvcjogXCJzdW1tb25cIiB9Pikge1xuICBsZXQgZm9lOiBVbml0IHwgdW5kZWZpbmVkO1xuICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCBjYXN0ZXIsIGRlZi5yYW5nZSArIFNVTU1PTl9BTEVSVF9NQVJHSU4sIChjYW5kaWRhdGUpID0+IHtcbiAgICBpZiAoIWlzQXV0b2Nhc3RGb2UoZ2FtZSwgY2FzdGVyLCBjYW5kaWRhdGUpIHx8IGRpc3RhbmNlKGNhc3RlciwgY2FuZGlkYXRlKSA+IGRlZi5yYW5nZSArIFNVTU1PTl9BTEVSVF9NQVJHSU4pIHJldHVybjtcbiAgICBpZiAoIWZvZSB8fCBkaXN0YW5jZShjYXN0ZXIsIGNhbmRpZGF0ZSkgPCBkaXN0YW5jZShjYXN0ZXIsIGZvZSkpIGZvZSA9IGNhbmRpZGF0ZTtcbiAgfSk7XG4gIGlmICghZm9lKSByZXR1cm4gdW5kZWZpbmVkO1xuICBsZXQgY29tcGFueSA9IGZhbHNlO1xuICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCBjYXN0ZXIsIFNVTU1PTl9DT01QQU5ZX1JBTkdFLCAoY2FuZGlkYXRlKSA9PiB7XG4gICAgaWYgKGNhbmRpZGF0ZS5vd25lciA9PT0gY2FzdGVyLm93bmVyICYmIGNhbmRpZGF0ZS5raW5kID09PSBkZWYuc3VtbW9uS2luZCAmJiBkaXN0YW5jZShjYXN0ZXIsIGNhbmRpZGF0ZSkgPD0gU1VNTU9OX0NPTVBBTllfUkFOR0UpIGNvbXBhbnkgPSB0cnVlO1xuICB9KTtcbiAgaWYgKGNvbXBhbnkpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IGdhcCA9IGRpc3RhbmNlKGNhc3RlciwgZm9lKTtcbiAgY29uc3Qgc3RlcCA9IE1hdGgubWluKFNVTU1PTl9TVEVQLCBnYXApO1xuICByZXR1cm4gZ2FwID4gMCA/IHsgeDogY2FzdGVyLnggKyAoKGZvZS54IC0gY2FzdGVyLngpIC8gZ2FwKSAqIHN0ZXAsIHk6IGNhc3Rlci55ICsgKChmb2UueSAtIGNhc3Rlci55KSAvIGdhcCkgKiBzdGVwIH0gOiB7IHg6IGNhc3Rlci54LCB5OiBjYXN0ZXIueSB9O1xufVxuXG5mdW5jdGlvbiBhdXRvY2FzdENoYXJnZVRhcmdldChnYW1lOiBHYW1lLCByaWRlcjogVW5pdCwgZGVmOiBDaGFyZ2VEZWYpIHtcbiAgY29uc3Qgb3JkZXIgPSByaWRlci5vcmRlcjtcbiAgY29uc3Qgb3duID0gb3JkZXIudHlwZSA9PT0gXCJhdHRhY2tcIiB8fCBvcmRlci50eXBlID09PSBcImF0dGFja01vdmVcIiA/IG9yZGVyLnRhcmdldElkIDogdW5kZWZpbmVkO1xuICBpZiAob3duKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gZmluZFRhcmdldChnYW1lLCBvd24pO1xuICAgIHJldHVybiB0YXJnZXQgJiYgaXNVbml0KHRhcmdldCkgJiYgbWF0Y2hlc1VuaXRUYXJnZXQodGFyZ2V0LCBkZWYudGFyZ2V0cywgZ2FtZSkgJiYgaXNBdXRvY2FzdEZvZShnYW1lLCByaWRlciwgdGFyZ2V0KSAmJiBpbkNoYXJnZVdpbmRvdyhyaWRlciwgdGFyZ2V0LCBkZWYpICYmIGNhblJlYWNoKGdhbWUubWFwLCByaWRlciwgdGFyZ2V0LCBnYW1lLnVuaXRzKSA/IHRhcmdldCA6IHVuZGVmaW5lZDtcbiAgfVxuICBpZiAob3JkZXIudHlwZSAhPT0gXCJpZGxlXCIgJiYgb3JkZXIudHlwZSAhPT0gXCJhdHRhY2tNb3ZlXCIpIHJldHVybiB1bmRlZmluZWQ7XG4gIGxldCBjaGFyZ2VkOiBTZXQ8c3RyaW5nPiB8IHVuZGVmaW5lZDtcbiAgbGV0IGZyZWU6IFVuaXQgfCB1bmRlZmluZWQ7XG4gIGxldCBhbnk6IFVuaXQgfCB1bmRlZmluZWQ7XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIHJpZGVyLCBkZWYucmFuZ2UsIChjYW5kaWRhdGUpID0+IHtcbiAgICBpZiAoIW1hdGNoZXNVbml0VGFyZ2V0KGNhbmRpZGF0ZSwgZGVmLnRhcmdldHMsIGdhbWUpIHx8ICFpc0F1dG9jYXN0Rm9lKGdhbWUsIHJpZGVyLCBjYW5kaWRhdGUpIHx8ICFpbkNoYXJnZVdpbmRvdyhyaWRlciwgY2FuZGlkYXRlLCBkZWYpIHx8ICFjYW5SZWFjaChnYW1lLm1hcCwgcmlkZXIsIGNhbmRpZGF0ZSwgZ2FtZS51bml0cykpIHJldHVybjtcbiAgICAvLyBNb3N0IHJpZGVycyBhcmUgb3V0IG9mIGNoYXJnZSByYW5nZTogb25seSBzY2FuIGV4aXN0aW5nIGNoYXJnZXMgd2hlbiBhIGNhbmRpZGF0ZSBleGlzdHMuXG4gICAgY2hhcmdlZCA/Pz0gbmV3IFNldChnYW1lLnVuaXRzLmZsYXRNYXAoKHVuaXQpID0+ICh1bml0Lm93bmVyID09PSByaWRlci5vd25lciAmJiB1bml0Lm9yZGVyLnR5cGUgPT09IFwiY2hhcmdlXCIgPyBbdW5pdC5vcmRlci50YXJnZXRJZF0gOiBbXSkpKTtcbiAgICBpZiAoIWFueSB8fCBkaXN0YW5jZShyaWRlciwgY2FuZGlkYXRlKSA8IGRpc3RhbmNlKHJpZGVyLCBhbnkpKSBhbnkgPSBjYW5kaWRhdGU7XG4gICAgaWYgKCFjaGFyZ2VkLmhhcyhjYW5kaWRhdGUuaWQpICYmICghZnJlZSB8fCBkaXN0YW5jZShyaWRlciwgY2FuZGlkYXRlKSA8IGRpc3RhbmNlKHJpZGVyLCBmcmVlKSkpIGZyZWUgPSBjYW5kaWRhdGU7XG4gIH0pO1xuICByZXR1cm4gZnJlZSA/PyBhbnk7XG59XG5cbmZ1bmN0aW9uIG91dGdvaW5nRGFtYWdlTXVsdGlwbGllcihnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGNvbnN0IGN1cnNlZCA9IHVuaXQuZWZmZWN0cy5yZWR1Y2UoKG11bHRpcGxpZXIsIGVmZmVjdCkgPT4gTWF0aC5taW4obXVsdGlwbGllciwgZWZmZWN0LmRhbWFnZU11bHRpcGxpZXIgPz8gKGVmZmVjdC50eXBlID09PSBcImN1cnNlXCIgPyAwLjQgOiAxKSksIDEpO1xuICByZXR1cm4gKHVuaXQuc3RhbmNlID09PSBcImJyYWNlXCIgPyBjdXJzZWQgKiBCUkFDRV9EQU1BR0VfU0hBUkUgOiBjdXJzZWQpICogcGFzc2VuZ2VyRGFtYWdlTXVsdGlwbGllcihnYW1lLCB1bml0KTtcbn1cblxuZnVuY3Rpb24gY2FycmllZEl0ZW0oZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgaXRlbUlkOiBzdHJpbmcpIHtcbiAgY29uc3QgaXRlbSA9IGdhbWUuaXRlbXMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IGl0ZW1JZCk7XG4gIGlmICghaXRlbSkgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGl0ZW0gJHtpdGVtSWR9YCk7XG4gIGlmIChpdGVtLmNhcnJpZXJJZCAhPT0gdW5pdC5pZCkgdGhyb3cgbmV3IEVycm9yKGAke3VuaXQuaWR9IGlzIG5vdCBjYXJyeWluZyAke2l0ZW0uaWR9YCk7XG4gIHJldHVybiBpdGVtO1xufVxuXG5mdW5jdGlvbiBjYXJyaWVyRm9yKGdhbWU6IEdhbWUsIGl0ZW06IFdvcmxkSXRlbSkge1xuICByZXR1cm4gaXRlbS5jYXJyaWVySWQgPyBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IGl0ZW0uY2FycmllcklkKSA6IHVuZGVmaW5lZDtcbn1cblxuZnVuY3Rpb24gYWN0aXZhdGVOZXV0cmFsSXRlbShnYW1lOiBHYW1lLCBjYXJyaWVyOiBVbml0LCBpdGVtOiBXb3JsZEl0ZW0pIHtcbiAgLy8gQEBAbmV1dHJhbC10cmVhc3VyZS1ydWxlIC0gQ2FtcHMgY2FuIHdlYXBvbml6ZSBjYXJyaWVkIHRyZWFzdXJlLCBleGNlcHQgc2Nyb2xscyB0aGF0IGFyZSBleHBsaWNpdGx5IGluZXJ0IG9uIG1vbnN0ZXJzXG4gIC8vIGFuZCB3aGF0IGEgc2hvcCBzZWxscyAod2hpY2ggbm8gY2FtcCBjYXJyaWVzKS5cbiAgaWYgKGl0ZW0ua2luZCA9PT0gXCJndWFyZGlhblNjcm9sbFwiIHx8IGl0ZW0ua2luZCA9PT0gXCJleHBlcmllbmNlQm9va1wiIHx8IGl0ZW0ua2luZCA9PT0gXCJicmVhY2hDaGFyZ2VcIiB8fCBpc1Nob3BPbmx5SXRlbShpdGVtLmtpbmQpIHx8IGl0ZW0uY29vbGRvd25SZW1haW5pbmcgPiAwKSByZXR1cm47XG4gIGNvbnN0IHRhcmdldCA9IG5lYXJlc3RFbmVteUluUmFuZ2UoZ2FtZSwgY2FycmllciwgaXRlbS5raW5kID09PSBcInN0b3JtU3RhZmZcIiA/IE5FVVRSQUxfU1RPUk1fVEFSR0VUX1JBTkdFIDogTkVVVFJBTF9JVEVNX1RBUkdFVF9SQU5HRSk7XG4gIGlmICghdGFyZ2V0KSByZXR1cm47XG4gIGFjdGl2YXRlSXRlbShnYW1lLCBjYXJyaWVyLCBpdGVtLCB0YXJnZXQuaWQsIHRhcmdldC54LCB0YXJnZXQueSk7XG59XG5cbmZ1bmN0aW9uIGFjdGl2YXRlSXRlbShcbiAgZ2FtZTogR2FtZSxcbiAgY2FycmllcjogVW5pdCxcbiAgaXRlbTogV29ybGRJdGVtLFxuICB0YXJnZXRJZDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICB4OiBudW1iZXIgfCB1bmRlZmluZWQsXG4gIHk6IG51bWJlciB8IHVuZGVmaW5lZCxcbikge1xuICBpZiAoaXRlbS5jb29sZG93blJlbWFpbmluZyA+IDApIHJldHVybjtcbiAgaWYgKGl0ZW0ua2luZCA9PT0gXCJsaWdodG5pbmdSb2RcIikge1xuICAgIGNvbnN0IHRhcmdldCA9IHRhcmdldElkID8gZ2FtZS51bml0cy5maW5kKCh1bml0KSA9PiB1bml0LmlkID09PSB0YXJnZXRJZCAmJiBhcmVFbmVteU93bmVycyhnYW1lLCBjYXJyaWVyLm93bmVyLCB1bml0Lm93bmVyKSkgOiB1bmRlZmluZWQ7XG4gICAgaWYgKCF0YXJnZXQgfHwgZGlzdGFuY2UoY2FycmllciwgdGFyZ2V0KSA+IExJR0hUTklOR19ST0QucmFuZ2UpIHJldHVybjtcbiAgICBhcHBseUNoYWluTGlnaHRuaW5nKGdhbWUsIGNhcnJpZXIsIGl0ZW0sIHRhcmdldCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChpdGVtLmtpbmQgPT09IFwic3Rvcm1TdGFmZlwiKSB7XG4gICAgY29uc3QgcG9pbnQgPSB0YXJnZXRJZCA/IGdhbWUudW5pdHMuZmluZCgodW5pdCkgPT4gdW5pdC5pZCA9PT0gdGFyZ2V0SWQpIDogaXNOdW1iZXIoeCkgJiYgaXNOdW1iZXIoeSkgPyB7IHgsIHkgfSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoIXBvaW50IHx8IGRpc3RhbmNlKGNhcnJpZXIsIHBvaW50KSA+IFNUT1JNX1NUQUZGLnJhbmdlKSByZXR1cm47XG4gICAgYXBwbHlTdG9ybVN0YWZmKGdhbWUsIGNhcnJpZXIsIGl0ZW0sIHBvaW50LngsIHBvaW50LnkpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoaXRlbS5raW5kID09PSBcImd1YXJkaWFuU2Nyb2xsXCIpIHtcbiAgICBpZiAoY2Fycmllci5vd25lciA9PT0gXCJuZXV0cmFsXCIpIHJldHVybjtcbiAgICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCBjYXJyaWVyLCBHVUFSRElBTl9TQ1JPTEwucmFkaXVzLCAodW5pdCkgPT4ge1xuICAgICAgaWYgKGRpc3RhbmNlKHVuaXQsIGNhcnJpZXIpID4gR1VBUkRJQU5fU0NST0xMLnJhZGl1cyB8fCBhcmVFbmVteU93bmVycyhnYW1lLCBjYXJyaWVyLm93bmVyLCB1bml0Lm93bmVyKSkgcmV0dXJuO1xuICAgICAgdW5pdC5lZmZlY3RzID0gdW5pdC5lZmZlY3RzLmZpbHRlcigoZWZmZWN0KSA9PiBlZmZlY3QudHlwZSAhPT0gXCJndWFyZGlhblwiKTtcbiAgICAgIHVuaXQuZWZmZWN0cy5wdXNoKHsgdHlwZTogXCJndWFyZGlhblwiLCByZW1haW5pbmc6IEdVQVJESUFOX1NDUk9MTC5kdXJhdGlvbiB9KTtcbiAgICB9KTtcbiAgICBhZGRFZmZlY3QoZ2FtZSwgXCJndWFyZGlhbkZpZWxkXCIsIGNhcnJpZXIueCwgY2Fycmllci55LCBHVUFSRElBTl9TQ1JPTEwuZHVyYXRpb24sIHsgcmFkaXVzOiBHVUFSRElBTl9TQ1JPTEwucmFkaXVzLCBzb3VyY2VJZDogY2Fycmllci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXJyaWVyLngsIGZyb21ZOiBjYXJyaWVyLnksIHRvWDogY2Fycmllci54LCB0b1k6IGNhcnJpZXIueSB9KTtcbiAgICBjb25zdW1lSXRlbShnYW1lLCBpdGVtKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGl0ZW0ua2luZCA9PT0gXCJicmVhY2hDaGFyZ2VcIikge1xuICAgIGlmIChjYXJyaWVyLm93bmVyID09PSBcIm5ldXRyYWxcIikgcmV0dXJuO1xuICAgIGNvbnN0IHRhcmdldCA9IHRhcmdldElkID8gZ2FtZS5idWlsZGluZ3MuZmluZCgoYnVpbGRpbmcpID0+IGJ1aWxkaW5nLmlkID09PSB0YXJnZXRJZCAmJiBhcmVFbmVteU93bmVycyhnYW1lLCBjYXJyaWVyLm93bmVyLCBidWlsZGluZy5vd25lcikpIDogdW5kZWZpbmVkO1xuICAgIGlmICghdGFyZ2V0IHx8IGRpc3RhbmNlKGNhcnJpZXIsIHRhcmdldCkgPiBCUkVBQ0hfQ0hBUkdFLnJhbmdlKSByZXR1cm47XG4gICAgYXBwbHlBdHRhY2tEYW1hZ2UoZ2FtZSwgY2FycmllciwgdGFyZ2V0LCBCUkVBQ0hfQ0hBUkdFLmRhbWFnZSwgQlJFQUNIX0NIQVJHRS5yYW5nZSwgSVRFTV9EQU1BR0VfUFJPRklMRVMuYnJlYWNoQ2hhcmdlKTtcbiAgICBjb25zdW1lSXRlbShnYW1lLCBpdGVtKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGl0ZW0ua2luZCA9PT0gXCJleHBlcmllbmNlQm9va1wiKSB7XG4gICAgaWYgKGNhcnJpZXIub3duZXIgPT09IFwibmV1dHJhbFwiKSByZXR1cm47XG4gICAgY2Fycmllci54cCArPSBFWFBFUklFTkNFX0JPT0tfWFA7XG4gICAgYXBwbHlYcExldmVsKGdhbWUsIGNhcnJpZXIpO1xuICAgIGFkZEVmZmVjdChnYW1lLCBcImV4cGVyaWVuY2VCdXJzdFwiLCBjYXJyaWVyLngsIGNhcnJpZXIueSwgNDgpO1xuICAgIGNvbnN1bWVJdGVtKGdhbWUsIGl0ZW0pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoaXRlbS5raW5kID09PSBcImhlYWxpbmdTY3JvbGxcIikge1xuICAgIGlmIChjYXJyaWVyLm93bmVyID09PSBcIm5ldXRyYWxcIikgcmV0dXJuO1xuICAgIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIGNhcnJpZXIsIEhFQUxJTkdfU0NST0xMX1JBRElVUywgKHVuaXQpID0+IHtcbiAgICAgIGlmICghY2FuUmVjZWl2ZUhlYWxpbmcodW5pdCwgZ2FtZSkgfHwgZGlzdGFuY2UodW5pdCwgY2FycmllcikgPiBIRUFMSU5HX1NDUk9MTF9SQURJVVMgfHwgYXJlRW5lbXlPd25lcnMoZ2FtZSwgY2Fycmllci5vd25lciwgdW5pdC5vd25lcikpIHJldHVybjtcbiAgICAgIHVuaXQuaHAgPSBNYXRoLm1pbih1bml0Lm1heEhwLCB1bml0LmhwICsgSEVBTElOR19TQ1JPTExfSEVBTCk7XG4gICAgfSk7XG4gICAgYWRkRWZmZWN0KGdhbWUsIFwiaGVhbFwiLCBjYXJyaWVyLngsIGNhcnJpZXIueSwgMzAsIHsgcmFkaXVzOiBIRUFMSU5HX1NDUk9MTF9SQURJVVMsIHNvdXJjZUlkOiBjYXJyaWVyLmlkLCBhY3Rpb25Nb2RlOiBcImNhc3RcIiwgZnJvbVg6IGNhcnJpZXIueCwgZnJvbVk6IGNhcnJpZXIueSwgdG9YOiBjYXJyaWVyLngsIHRvWTogY2Fycmllci55IH0pO1xuICAgIGNvbnN1bWVJdGVtKGdhbWUsIGl0ZW0pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoaXRlbS5raW5kID09PSBcIml2b3J5VG93ZXJcIikge1xuICAgIGlmICghaXNQbGF5ZXJJZChjYXJyaWVyLm93bmVyKSB8fCAhaXNOdW1iZXIoeCkgfHwgIWlzTnVtYmVyKHkpKSByZXR1cm47XG4gICAgaWYgKE1hdGguaHlwb3QoeCAtIGNhcnJpZXIueCwgeSAtIGNhcnJpZXIueSkgPiBJVk9SWV9UT1dFUl9SRUFDSCkgcmV0dXJuO1xuICAgIGlmICh0ZXJyYWluQmxvY2tzUGxhY2VtZW50KGdhbWUubWFwLCBcImRlZmVuc2VUb3dlclwiLCB7IHgsIHkgfSkgfHwgYnVpbGRpbmdQbGFjZW1lbnRCbG9ja2VyKGdhbWUsIFwiZGVmZW5zZVRvd2VyXCIsIHsgeCwgeSB9KSkgcmV0dXJuO1xuICAgIGNvbnN0IGF0ID0gc25hcFRvRm9vdHByaW50KGdhbWUubWFwLCBCVUlMRElOR19ERUZTLmRlZmVuc2VUb3dlci5yYWRpdXMsIHsgeCwgeSB9KTtcbiAgICBjb25zdCB0b3dlciA9IGNyZWF0ZUJ1aWxkaW5nKGBidWlsZGluZy0ke2NhcnJpZXIub3duZXJ9LWRlZmVuc2VUb3dlci0ke2dhbWUubmV4dElkfWAsIGNhcnJpZXIub3duZXIsIFwiZGVmZW5zZVRvd2VyXCIsIGF0LngsIGF0LnksIHRydWUpO1xuICAgIGdhbWUubmV4dElkICs9IDE7XG4gICAgdG93ZXIuaHAgPSBNYXRoLnJvdW5kKHRvd2VyLm1heEhwICogSVZPUllfVE9XRVJfSFBfU0hBUkUpO1xuICAgIGdhbWUuYnVpbGRpbmdzLnB1c2godG93ZXIpO1xuICAgIGFkZEVmZmVjdChnYW1lLCBcInN1bW1vblwiLCBhdC54LCBhdC55LCAzNCwge3NvdXJjZUlkOmNhcnJpZXIuaWQsYWN0aW9uTW9kZTpcImNhc3RcIixmcm9tWDpjYXJyaWVyLngsZnJvbVk6Y2Fycmllci55LHRvWDphdC54LHRvWTphdC55fSk7XG4gICAgY29uc3VtZUl0ZW0oZ2FtZSwgaXRlbSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gaXNTaG9wT25seUl0ZW0oa2luZDogV29ybGRJdGVtW1wia2luZFwiXSkge1xuICByZXR1cm4ga2luZCA9PT0gXCJzcGVlZEJvb3RzXCIgfHwga2luZCA9PT0gXCJyZWdlblJpbmdcIiB8fCBraW5kID09PSBcImhlYWxpbmdTY3JvbGxcIiB8fCBraW5kID09PSBcIml2b3J5VG93ZXJcIjtcbn1cblxuZnVuY3Rpb24gY29uc3VtZUl0ZW0oZ2FtZTogR2FtZSwgaXRlbTogV29ybGRJdGVtKSB7XG4gIGNvbnN0IHVuaXQ9Y2FycmllckZvcihnYW1lLGl0ZW0pO2lmKHVuaXQpcmVtb3ZlRnJvbUhhbmRzKHVuaXQsaXRlbS5pZCk7XG4gIGdhbWUuaXRlbXMgPSBnYW1lLml0ZW1zLmZpbHRlcigoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgIT09IGl0ZW0uaWQpO1xuICBpZih1bml0KWFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLHVuaXQpO3JlZnJlc2hFcXVpcG1lbnRNYXNzKGdhbWUpO1xufVxuXG5mdW5jdGlvbiBhcHBseUNoYWluTGlnaHRuaW5nKGdhbWU6IEdhbWUsIGNhcnJpZXI6IFVuaXQsIGl0ZW06IFdvcmxkSXRlbSwgZmlyc3RUYXJnZXQ6IFVuaXQpIHtcbiAgY29uc3Qgc3RydWNrID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGxldCBjdXJyZW50ID0gZmlyc3RUYXJnZXQ7XG4gIGxldCBkYW1hZ2UgPSBMSUdIVE5JTkdfUk9ELmRhbWFnZTtcbiAgZm9yIChsZXQgYm91bmNlID0gMDsgYm91bmNlIDwgTElHSFROSU5HX1JPRC5oaXRzOyBib3VuY2UgKz0gMSkge1xuICAgIHN0cnVjay5hZGQoY3VycmVudC5pZCk7XG4gICAgYXBwbHlBdHRhY2tEYW1hZ2UoZ2FtZSwgY2FycmllciwgY3VycmVudCwgZGFtYWdlKm91dGdvaW5nRGFtYWdlTXVsdGlwbGllcihnYW1lLGNhcnJpZXIpLCAyNDAsIElURU1fREFNQUdFX1BST0ZJTEVTLmxpZ2h0bmluZ1JvZCk7XG4gICAgYWRkRWZmZWN0KGdhbWUsIFwiY2hhaW5MaWdodG5pbmdcIiwgY3VycmVudC54LCBjdXJyZW50LnksIDI4LCB7IGZyb21YOiBjYXJyaWVyLngsIGZyb21ZOiBjYXJyaWVyLnksIHRvWDogY3VycmVudC54LCB0b1k6IGN1cnJlbnQueSB9KTtcbiAgICBjb25zdCBuZXh0ID0gbmVhcmVzdENoYWluVGFyZ2V0KGdhbWUsIGNhcnJpZXIsIGN1cnJlbnQsIHN0cnVjaywgTElHSFROSU5HX1JPRC5ib3VuY2VSYW5nZSk7XG4gICAgaWYgKCFuZXh0KSBicmVhaztcbiAgICBjdXJyZW50ID0gbmV4dDtcbiAgICBkYW1hZ2UgPSBNYXRoLm1heChMSUdIVE5JTkdfUk9ELm1pbmltdW1EYW1hZ2UsIE1hdGgucm91bmQoZGFtYWdlICogTElHSFROSU5HX1JPRC5kZWNheSkpO1xuICB9XG4gIGl0ZW0uY29vbGRvd25SZW1haW5pbmcgPSBMSUdIVE5JTkdfUk9ELmNvb2xkb3duO1xufVxuXG5mdW5jdGlvbiBuZWFyZXN0Q2hhaW5UYXJnZXQoZ2FtZTogR2FtZSwgY2FycmllcjogVW5pdCwgZnJvbTogVW5pdCwgc3RydWNrOiBTZXQ8c3RyaW5nPiwgcmFuZ2U6IG51bWJlcikge1xuICBjb25zdCBsaW1pdCA9IHJhbmdlICogcmFuZ2U7XG4gIGxldCBiZXN0OiBVbml0IHwgdW5kZWZpbmVkO1xuICBsZXQgYmVzdERpc3RhbmNlID0gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZO1xuICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCBmcm9tLCByYW5nZSwgKGNhbmRpZGF0ZSkgPT4ge1xuICAgIGlmIChzdHJ1Y2suaGFzKGNhbmRpZGF0ZS5pZCkgfHwgIWFyZUVuZW15T3duZXJzKGdhbWUsIGNhcnJpZXIub3duZXIsIGNhbmRpZGF0ZS5vd25lcikpIHJldHVybjtcbiAgICBjb25zdCBjYW5kaWRhdGVEaXN0YW5jZSA9IGRpc3RhbmNlU3F1YXJlZChmcm9tLCBjYW5kaWRhdGUpO1xuICAgIGlmIChjYW5kaWRhdGVEaXN0YW5jZSA+IGxpbWl0IHx8IGNhbmRpZGF0ZURpc3RhbmNlID49IGJlc3REaXN0YW5jZSkgcmV0dXJuO1xuICAgIGJlc3QgPSBjYW5kaWRhdGU7XG4gICAgYmVzdERpc3RhbmNlID0gY2FuZGlkYXRlRGlzdGFuY2U7XG4gIH0pO1xuICByZXR1cm4gYmVzdDtcbn1cblxuZnVuY3Rpb24gYXBwbHlTdG9ybVN0YWZmKGdhbWU6IEdhbWUsIGNhcnJpZXI6IFVuaXQsIGl0ZW06IFdvcmxkSXRlbSwgeDogbnVtYmVyLCB5OiBudW1iZXIpIHtcbiAgZm9yRWFjaE5lYXJieVVuaXQoZ2FtZSwgeyB4LCB5IH0sIFNUT1JNX1NUQUZGLnJhZGl1cywgKHRhcmdldCkgPT4ge1xuICAgIGlmIChkaXN0YW5jZSh0YXJnZXQsIHsgeCwgeSB9KSA+IFNUT1JNX1NUQUZGLnJhZGl1cyB8fCAhYXJlRW5lbXlPd25lcnMoZ2FtZSwgY2Fycmllci5vd25lciwgdGFyZ2V0Lm93bmVyKSkgcmV0dXJuO1xuICAgIGFwcGx5QXR0YWNrRGFtYWdlKGdhbWUsIGNhcnJpZXIsIHRhcmdldCwgU1RPUk1fU1RBRkYuaW1wYWN0RGFtYWdlKm91dGdvaW5nRGFtYWdlTXVsdGlwbGllcihnYW1lLGNhcnJpZXIpLCBTVE9STV9TVEFGRi5yYW5nZSwgSVRFTV9EQU1BR0VfUFJPRklMRVMuc3Rvcm1TdGFmZik7XG4gIH0pO1xuICBhZGRFZmZlY3QoZ2FtZSwgXCJzdG9ybVwiLCB4LCB5LCBTVE9STV9TVEFGRi5kdXJhdGlvbiwgeyBzb3VyY2VJZDogY2Fycmllci5pZCwgYWN0aW9uTW9kZTogXCJjYXN0XCIsIGZyb21YOiBjYXJyaWVyLngsIGZyb21ZOiBjYXJyaWVyLnksIHRvWDogeCwgdG9ZOiB5LCBvd25lcjogY2Fycmllci5vd25lciwgdW5pdElkOiBjYXJyaWVyLmlkLCBkYW1hZ2U6IFNUT1JNX1NUQUZGLnB1bHNlRGFtYWdlKm91dGdvaW5nRGFtYWdlTXVsdGlwbGllcihnYW1lLGNhcnJpZXIpLCBkYW1hZ2VQcm9maWxlOiB7IC4uLklURU1fREFNQUdFX1BST0ZJTEVTLnN0b3JtU3RhZmYgfSwgcmFkaXVzOiBTVE9STV9TVEFGRi5yYWRpdXMsIHRpY2tFdmVyeTogU1RPUk1fU1RBRkYucHVsc2VFdmVyeSB9KTtcbiAgaXRlbS5jb29sZG93blJlbWFpbmluZyA9IFNUT1JNX1NUQUZGLmNvb2xkb3duO1xufVxuXG5mdW5jdGlvbiBhcHBseUZsYW1lQ2xvYWsoZ2FtZTogR2FtZSwgY2FycmllcjogVW5pdCwgaXRlbTogV29ybGRJdGVtKSB7XG4gIGlmIChpdGVtLmNvb2xkb3duUmVtYWluaW5nID4gMCkgcmV0dXJuO1xuICBsZXQgYnVybmVkID0gZmFsc2U7XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIGNhcnJpZXIsIEZMQU1FX0NMT0FLLnJhZGl1cywgKHRhcmdldCkgPT4ge1xuICAgIGlmIChkaXN0YW5jZSh0YXJnZXQsIGNhcnJpZXIpID4gRkxBTUVfQ0xPQUsucmFkaXVzIHx8ICFhcmVFbmVteU93bmVycyhnYW1lLCBjYXJyaWVyLm93bmVyLCB0YXJnZXQub3duZXIpKSByZXR1cm47XG4gICAgYXBwbHlBdHRhY2tEYW1hZ2UoZ2FtZSwgY2FycmllciwgdGFyZ2V0LCBGTEFNRV9DTE9BSy5kYW1hZ2Uqb3V0Z29pbmdEYW1hZ2VNdWx0aXBsaWVyKGdhbWUsY2FycmllciksIDcwLCBJVEVNX0RBTUFHRV9QUk9GSUxFUy5mbGFtZUNsb2FrKTtcbiAgICBhZGRFZmZlY3QoZ2FtZSwgXCJmbGFtZUJ1cm5cIiwgdGFyZ2V0LngsIHRhcmdldC55LCBGTEFNRV9DTE9BS19WSVNVQUxfRFVSQVRJT04pO1xuICAgIGJ1cm5lZCA9IHRydWU7XG4gIH0pO1xuICBpZiAoIWJ1cm5lZCkgcmV0dXJuO1xuICBpdGVtLmNvb2xkb3duUmVtYWluaW5nID0gRkxBTUVfQ0xPQUsuaW50ZXJ2YWw7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVdvcmxkRWZmZWN0cyhnYW1lOiBHYW1lKSB7XG4gIGlmIChnYW1lLmVmZmVjdHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGxldCBleHBpcmVkID0gZmFsc2U7XG4gIGZvciAoY29uc3QgZWZmZWN0IG9mIGdhbWUuZWZmZWN0cykge1xuICAgIGFwcGx5V29ybGRFZmZlY3RUaWNrKGdhbWUsIGVmZmVjdCk7XG4gICAgZWZmZWN0LnJlbWFpbmluZyAtPSAxO1xuICAgIGV4cGlyZWQgfHw9ICEoZWZmZWN0LnJlbWFpbmluZyA+IDApO1xuICB9XG4gIGlmIChleHBpcmVkKSBnYW1lLmVmZmVjdHMgPSBnYW1lLmVmZmVjdHMuZmlsdGVyKChlZmZlY3QpID0+IGVmZmVjdC5yZW1haW5pbmcgPiAwKTtcbn1cblxuZnVuY3Rpb24gYXBwbHlXb3JsZEVmZmVjdFRpY2soZ2FtZTogR2FtZSwgZWZmZWN0OiBXb3JsZEVmZmVjdCkge1xuICBpZiAoZWZmZWN0LnR5cGUgPT09IFwiYnVybmluZ0dyb3VuZFwiICYmIGVmZmVjdC5vd25lciAmJiBlZmZlY3QuZGFtYWdlICYmIGVmZmVjdC5yYWRpdXMgJiYgZWZmZWN0LnRpY2tFdmVyeSkge1xuICAgIGlmIChlZmZlY3QucmVtYWluaW5nICUgZWZmZWN0LnRpY2tFdmVyeSAhPT0gMCkgcmV0dXJuO1xuICAgIGNvbnN0IHNvdXJjZSA9IGVmZmVjdC51bml0SWQgPyBmaW5kVGFyZ2V0KGdhbWUsZWZmZWN0LnVuaXRJZCkgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgYXR0YWNrZXIgPSBzb3VyY2UgPz8gc2NyaXB0U291cmNlKHtpZDplZmZlY3QudW5pdElkID8/IGVmZmVjdC5pZCxvd25lcjplZmZlY3Qub3duZXIseDplZmZlY3QueCx5OmVmZmVjdC55fSk7XG4gICAgZm9yIChjb25zdCB0YXJnZXQgb2YgWy4uLmdhbWUudW5pdHMsLi4uZ2FtZS5idWlsZGluZ3NdKSBpZiAodGFyZ2V0LmhwPjAgJiYgYXJlRW5lbXlPd25lcnMoZ2FtZSxlZmZlY3Qub3duZXIsdGFyZ2V0Lm93bmVyKSAmJiBkaXN0YW5jZShlZmZlY3QsdGFyZ2V0KTw9ZWZmZWN0LnJhZGl1cyt0YXJnZXQucmFkaXVzKSB7XG4gICAgICBpZiAoZWZmZWN0LnNvdXJjZUtpbmQgPT09ICdzcGFya0FyY2hlcicgJiYgaXNVbml0KHRhcmdldCkgJiYgKHRhcmdldC5kZWNrIHx8IHVuaXRNb3Zlcih0YXJnZXQua2luZCkgIT09ICdsYW5kJykpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgdGFrZW49YXBwbHlEYW1hZ2UoZ2FtZSxhdHRhY2tlcix0YXJnZXQsZWZmZWN0LmRhbWFnZSx1bmRlZmluZWQsdW5kZWZpbmVkLDAsZWZmZWN0LmRhbWFnZVByb2ZpbGUgPz8gREFNQUdFX1BST0ZJTEVTLkJVUk5JTkcpO2lmKHRha2VuIT09dW5kZWZpbmVkKWFkZEhpdEVmZmVjdChnYW1lLHRhcmdldCx0YWtlbixzb3VyY2UpO1xuICAgICAgaWYgKHRha2VuICE9PSB1bmRlZmluZWQgJiYgZWZmZWN0LnNvdXJjZUtpbmQgPT09ICdzcGFya0FyY2hlcicgJiYgaXNVbml0KHRhcmdldCkpIHNldFN0YXR1cyh0YXJnZXQsIHsgdHlwZTogJ3Njb3JjaCcsIHJlbWFpbmluZzogU0NPUkNIX0RVUkFUSU9OIH0pO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGVmZmVjdC50eXBlICE9PSBcInN0b3JtXCIgfHwgIWVmZmVjdC5vd25lciB8fCAhZWZmZWN0LmRhbWFnZSB8fCAhZWZmZWN0LnJhZGl1cyB8fCAhZWZmZWN0LnRpY2tFdmVyeSkgcmV0dXJuO1xuICBpZiAoZWZmZWN0LnJlbWFpbmluZyAhPT0gZWZmZWN0LmR1cmF0aW9uICYmIGVmZmVjdC5yZW1haW5pbmcgJSBlZmZlY3QudGlja0V2ZXJ5ICE9PSAwKSByZXR1cm47XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIGVmZmVjdCwgZWZmZWN0LnJhZGl1cywgKHRhcmdldCkgPT4ge1xuICAgIGlmIChkaXN0YW5jZSh0YXJnZXQsIGVmZmVjdCkgPiBlZmZlY3QucmFkaXVzISB8fCAhYXJlRW5lbXlPd25lcnMoZ2FtZSwgZWZmZWN0Lm93bmVyISwgdGFyZ2V0Lm93bmVyKSkgcmV0dXJuO1xuICAgIGFwcGx5QXR0YWNrRGFtYWdlKGdhbWUsIHNjcmlwdFNvdXJjZSh7IGlkOiBlZmZlY3QudW5pdElkID8/IGVmZmVjdC5pZCwgb3duZXI6IGVmZmVjdC5vd25lciEsIHg6IGVmZmVjdC54LCB5OiBlZmZlY3QueSB9KSwgdGFyZ2V0LCBlZmZlY3QuZGFtYWdlISwgMjYwLCBlZmZlY3QuZGFtYWdlUHJvZmlsZSA/PyBEQU1BR0VfUFJPRklMRVMuU1RPUk0pO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlUHJvamVjdGlsZXMoZ2FtZTogR2FtZSkge1xuICBpZiAoZ2FtZS5wcm9qZWN0aWxlcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcHJvamVjdGlsZXMgPSBnYW1lLnByb2plY3RpbGVzO1xuICBsZXQgcGVuZGluZzogUHJvamVjdGlsZVtdIHwgdW5kZWZpbmVkO1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgcHJvamVjdGlsZXMubGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgY29uc3QgcHJvamVjdGlsZSA9IHByb2plY3RpbGVzW2luZGV4XSE7XG4gICAgcHJvamVjdGlsZS5yZW1haW5pbmcgLT0gMTtcbiAgICBpZiAocHJvamVjdGlsZS5yZW1haW5pbmcgPiAwKSB7XG4gICAgICBwZW5kaW5nPy5wdXNoKHByb2plY3RpbGUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIHBlbmRpbmcgPz89IHByb2plY3RpbGVzLnNsaWNlKDAsIGluZGV4KTtcbiAgICBhcHBseVByb2plY3RpbGVJbXBhY3QoZ2FtZSwgcHJvamVjdGlsZSk7XG4gIH1cbiAgLy8gVW50aWwgdGhlIGZpcnN0IGltcGFjdCwgYm90aCBtZW1iZXJzaGlwIGFuZCB0YXJnZXQgaW5kZXhlcyByZW1haW4gY3VycmVudC5cbiAgaWYgKHBlbmRpbmcpIGdhbWUucHJvamVjdGlsZXMgPSBwZW5kaW5nO1xufVxuXG5mdW5jdGlvbiBhcHBseVByb2plY3RpbGVJbXBhY3QoZ2FtZTogR2FtZSwgcHJvamVjdGlsZTogUHJvamVjdGlsZSkge1xuICB3aXRoRGVja0RhbWFnZUJhdGNoKGdhbWUsICgpID0+IHtcbiAgaWYgKHByb2plY3RpbGUud2VhcG9uKSB7IGltcGFjdFdlYXBvbihnYW1lLCBwcm9qZWN0aWxlKTsgcmV0dXJuOyB9XG4gIGNvbnN0IHRhcmdldCA9IGZpbmRTdHJpa2VUYXJnZXQoZ2FtZSwgcHJvamVjdGlsZS50YXJnZXRJZCk7XG4gIGlmICghdGFyZ2V0IHx8IHRhcmdldC5ocCA8PSAwIHx8ICFhcmVFbmVteU93bmVycyhnYW1lLCBwcm9qZWN0aWxlLm93bmVyLCB0YXJnZXQub3duZXIpKSByZXR1cm47XG4gIGNvbnN0IGxpdmVTaG9vdGVyID0gZmluZFRhcmdldChnYW1lLCBwcm9qZWN0aWxlLmF0dGFja2VySWQpO1xuICBjb25zdCBzaG9vdGVyID0gbGl2ZVNob290ZXI/Lm93bmVyPT09cHJvamVjdGlsZS5vd25lciA/IGxpdmVTaG9vdGVyIDogdW5kZWZpbmVkO1xuICBjb25zdCBhdHRhY2tlciA9IHNob290ZXIgPz8gcHJvamVjdGlsZUF0dGFja2VyKHByb2plY3RpbGUpO1xuICBjb25zdCB0YWtlbiA9IGFwcGx5RGFtYWdlKGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGF0dGFja0RhbWFnZUFnYWluc3RUYXJnZXQoZ2FtZSwgYXR0YWNrZXIsIHRhcmdldCwgcHJvamVjdGlsZS5kYW1hZ2UpLCBwcm9qZWN0aWxlLmh1bGxEYW1hZ2VTaGFyZSwgdW5kZWZpbmVkLCAwLCBwcm9qZWN0aWxlLmRhbWFnZVByb2ZpbGUgPz8gYXR0YWNrRGFtYWdlUHJvZmlsZShwcm9qZWN0aWxlLnNvdXJjZUtpbmQgPz8gXCJkZWZlbnNlVG93ZXJcIiksIHByb2plY3RpbGUuYXJtb3JBbHJlYWR5QXBwbGllZCk7XG4gIGlmICh0YWtlbiA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gIGFwcGx5QXR0YWNrU3RhdHVzRWZmZWN0cyhnYW1lLCBhdHRhY2tlciwgdGFyZ2V0LCBwcm9qZWN0aWxlLnNvdXJjZUtpbmQpO1xuICBhZGRIaXRFZmZlY3QoZ2FtZSwgdGFyZ2V0LCB0YWtlbiwgc2hvb3RlciwgcHJvamVjdGlsZS5hdHRhY2tLaW5kLCB7IHg6IHByb2plY3RpbGUuZnJvbVgsIHk6IHByb2plY3RpbGUuZnJvbVkgfSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBwcm9qZWN0aWxlQXR0YWNrZXIocHJvamVjdGlsZTogUHJvamVjdGlsZSk6IEJ1aWxkaW5nIHtcbiAgcmV0dXJuIHtcbiAgICBpZDogcHJvamVjdGlsZS5hdHRhY2tlcklkLFxuICAgIG93bmVyOiBwcm9qZWN0aWxlLm93bmVyIGFzIEV4Y2x1ZGU8T3duZXIsIFwibmV1dHJhbFwiPixcbiAgICBraW5kOiBcImRlZmVuc2VUb3dlclwiLFxuICAgIHg6IHByb2plY3RpbGUuZnJvbVgsXG4gICAgeTogcHJvamVjdGlsZS5mcm9tWSxcbiAgICBocDogMSxcbiAgICBtYXhIcDogMSxcbiAgICByYWRpdXM6IDAsXG4gICAgY29tcGxldGU6IHRydWUsXG4gICAgYnVpbGRQcm9ncmVzczogMCxcbiAgICBidWlsZFRpbWU6IDAsXG4gICAgYXR0YWNrRGFtYWdlOiAwLFxuICAgIGF0dGFja1JhbmdlOiAwLFxuICAgIGF0dGFja0Nvb2xkb3duOiAwLFxuICAgIGNvb2xkb3duOiAwLFxuICAgIHJhbGx5WDogcHJvamVjdGlsZS5mcm9tWCxcbiAgICByYWxseVk6IHByb2plY3RpbGUuZnJvbVksXG4gICAgcXVldWU6IFtdLFxuICAgIHJlc2VhcmNoUXVldWU6IFtdLFxuICB9O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVVbml0U3RhdHVzRWZmZWN0cyhnYW1lOiBHYW1lKSB7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSB7XG4gICAgaWYgKHVuaXQuZWZmZWN0cy5sZW5ndGggPT09IDApIGNvbnRpbnVlO1xuICAgIC8vIEV2ZXJ5IHN0YXR1cyBvYnNlcnZlcyB0aGUgc2FtZSBpbnN0YW50LiBBIHBvaXNvbiB0aWNrIG11c3Qgbm90IHNlZSBhXG4gICAgLy8gb25lLXRpY2sgd2FyZCBkaWZmZXJlbnRseSBqdXN0IGJlY2F1c2UgdGhhdCB3YXJkIHdhcyBpbnNlcnRlZCBsYXRlci5cbiAgICBsZXQgZXhwaXJlZCA9IGZhbHNlO1xuICAgIGZvciAoY29uc3QgZWZmZWN0IG9mIHVuaXQuZWZmZWN0cykge1xuICAgICAgZWZmZWN0LnJlbWFpbmluZyAtPSAxO1xuICAgICAgZXhwaXJlZCB8fD0gIShlZmZlY3QucmVtYWluaW5nID4gMCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgZWZmZWN0IG9mIHVuaXQuZWZmZWN0cykge1xuICAgICAgLy8gUG9pc29uIGJpdGVzIG9uY2UgYSBzZWNvbmQgKHNlZSBAQEBjcmVlcC10cmFpdC1udW1iZXJzKSwgZm9yIGl0cyBiaXRlciB3aGlsZSBpdCBsaXZlcy5cbiAgICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJwb2lzb25cIiAmJiBlZmZlY3QucmVtYWluaW5nICUgMjAgPT09IDAgJiYgdW5pdC5ocCA+IDApIHtcbiAgICAgICAgY29uc3Qgc291cmNlID0gZWZmZWN0LnNvdXJjZUlkID8gZmluZFRhcmdldChnYW1lLCBlZmZlY3Quc291cmNlSWQpIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBhdHRhY2tlciA9IHNvdXJjZSAmJiBzb3VyY2UuaHAgPiAwID8gc291cmNlIDogc2NyaXB0U291cmNlKHsgaWQ6IGVmZmVjdC5zb3VyY2VJZCA/PyBcInBvaXNvblwiLCBvd25lcjogZWZmZWN0LnNvdXJjZU93bmVyID8/IFwibmV1dHJhbFwiLCB4OiB1bml0LngsIHk6IHVuaXQueSB9KTtcbiAgICAgICAgYXBwbHlEYW1hZ2UoZ2FtZSwgYXR0YWNrZXIsIHVuaXQsIFBPSVNPTl9EQU1BR0UsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCAwLCBEQU1BR0VfUFJPRklMRVMuUE9JU09OLCBmYWxzZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChleHBpcmVkKSB1bml0LmVmZmVjdHMgPSB1bml0LmVmZmVjdHMuZmlsdGVyKChlZmZlY3QpID0+IGVmZmVjdC5yZW1haW5pbmcgPiAwKTtcbiAgfVxufVxuXG50eXBlIFdlYXBvbkFiaWxpdHkgPSBFeHRyYWN0PCh0eXBlb2YgQUJJTElUWV9ERUZTKVtBYmlsaXR5S2luZF0se2JlaGF2aW9yOlwid2VhcG9uXCJ9PjtcbmZ1bmN0aW9uIGFwcGx5V2VhcG9uQWJpbGl0eShnYW1lOkdhbWUsY2FzdGVyOlVuaXQsYWJpbGl0eTpBYmlsaXR5S2luZCxhdDp7eDpudW1iZXI7eTpudW1iZXJ9LGRlZjpXZWFwb25BYmlsaXR5LHRhcmdldElkPzpzdHJpbmcpe1xuICBjYXN0ZXIuYWJpbGl0eUNvb2xkb3ducz13aXRoQWJpbGl0eUNvb2xkb3duKGNhc3RlcixhYmlsaXR5LGRlZi5jb29sZG93bik7XG4gIGNvbnN0IG1vdW50ZWQ9YWJpbGl0eT09PSdpbmNlbmRpYXJ5Rmx1bWUnID8gaW5zdGFsbGVkV2VhcG9ucyhnYW1lLGNhc3RlcikuZmluZChpdGVtPT5pdGVtLmtpbmQ9PT0nZmxhbWVQcm9qZWN0b3InICYmIChpdGVtLmR1cmFiaWxpdHkgPz8gMSk+MCAmJiBzaGlwR3VuQ2FuQWltKGNhc3RlcixpdGVtLGF0KSkgOiB1bmRlZmluZWQ7XG4gIGZpcmVXZWFwb24oZ2FtZSxjYXN0ZXIsYXQsZGVmLmRhbWFnZSpvdXRnb2luZ0RhbWFnZU11bHRpcGxpZXIoZ2FtZSwgY2FzdGVyKSxkZWYud2VhcG9uLGRlZi5yYW5nZSx7Li4uKGRlZi5yb290VGlja3MgPyB7cm9vdFRpY2tzOmRlZi5yb290VGlja3N9Ont9KSwuLi4oZGVmLmJ1cm5UaWNrcyA/IHtidXJuVGlja3M6ZGVmLmJ1cm5UaWNrc306e30pfSx0YXJnZXRJZCxtb3VudGVkP3tpdGVtOm1vdW50ZWQscG9zZTptb3VudGVkV2VhcG9uUG9zZShjYXN0ZXIsbW91bnRlZCkhfTp1bmRlZmluZWQsXCJjYXN0XCIpO1xufVxuZnVuY3Rpb24gYmFja091dE9mRGVhZFpvbmUoZ2FtZTpHYW1lLHVuaXQ6VW5pdCx0YXJnZXQ6e3g6bnVtYmVyO3k6bnVtYmVyfSxuYXZhbEZyYW1lPXRydWUpe1xuICBsZXQgbWluaW11bT13ZWFwb25SdWxlcyhnYW1lLHVuaXQpLndlYXBvbj8ubWluUmFuZ2U7XG4gIGlmKG5hdmFsRnJhbWUgJiYgaXNTaGlwS2luZCh1bml0LmtpbmQpKXtcbiAgICBjb25zdCB3ZWFwb25zPWluc3RhbGxlZFdlYXBvbnMoZ2FtZSx1bml0KS5maWx0ZXIoaXRlbT0+KGl0ZW0uZHVyYWJpbGl0eSA/PyAxKT4wKTtcbiAgICBpZih3ZWFwb25zLmxlbmd0aCltaW5pbXVtPU1hdGgubWluKC4uLndlYXBvbnMubWFwKGl0ZW09PlNISVBfV0VBUE9OU1tpdGVtLmtpbmQgYXMga2V5b2YgdHlwZW9mIFNISVBfV0VBUE9OU10ud2VhcG9uLm1pblJhbmdlID8/IDApKTtcbiAgfVxuICBpZighbWluaW11bXx8ZGlzdGFuY2UodW5pdCx0YXJnZXQpPj1taW5pbXVtKXJldHVybiBmYWxzZTtcbiAgY29uc3QgZHg9dW5pdC54LXRhcmdldC54LGR5PXVuaXQueS10YXJnZXQueSxsZW5ndGg9TWF0aC5oeXBvdChkeCxkeSl8fDE7XG4gIG1vdmVUb3dhcmQodW5pdCx1bml0LngrKGR4fHwxKS9sZW5ndGgqKG1pbmltdW0rMzIpLHVuaXQueStkeS9sZW5ndGgqKG1pbmltdW0rMzIpLGdhbWUubWFwLGdhbWUudW5pdHMpO3JldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gd2VhcG9uT3JpZ2luKGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcpIHtcbiAgY29uc3QgcG9zZSA9IGlzVW5pdChhdHRhY2tlcikgJiYgc2hpcFdlYXBvblBvc2UoYXR0YWNrZXIpO1xuICByZXR1cm4gcG9zZSA/IHBvc2UubXV6emxlIDogeyB4OiBhdHRhY2tlci54LCB5OiBhdHRhY2tlci55IH07XG59XG5mdW5jdGlvbiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZTogR2FtZSwgZW50aXR5OiB7aWQ/OnN0cmluZ30pIHtcbiAgY29uc3QgdW5pdD1cIm9yZGVyXCIgaW4gZW50aXR5ID8gZW50aXR5IGFzIFVuaXQgOiBcImtpbmRcIiBpbiBlbnRpdHkgPyB1bmRlZmluZWQgOiBlbnRpdHkuaWQgJiYgZ2FtZS51bml0cy5maW5kKHVuaXQ9PnVuaXQuaWQ9PT1lbnRpdHkuaWQpO1xuICBpZiAoIXVuaXQpIHJldHVybiAwO1xuICBjb25zdCBodWxsPXVuaXQuZGVjayAmJiBnYW1lLnVuaXRzLmZpbmQoc2hpcD0+c2hpcC5pZD09PXVuaXQuZGVjayEuc2hpcElkKTtcbiAgcmV0dXJuIGh1bGwgPyAoc2hpcFByb2ZpbGUoaHVsbCk/LmRlY2tIZWlnaHQgPz8gMCkrMTggOiBzaGlwUHJvZmlsZSh1bml0KT8uZGVja0hlaWdodCA/PyAwO1xufVxuXG5mdW5jdGlvbiBmaXJlV2VhcG9uKGdhbWU6R2FtZSxhdHRhY2tlcjpVbml0fEJ1aWxkaW5nLGF0Ont4Om51bWJlcjt5Om51bWJlcjtpZD86c3RyaW5nfSxkYW1hZ2U6bnVtYmVyLHdlYXBvbjpXZWFwb25EZWYscmFuZ2U6bnVtYmVyLHNraWxsOntyb290VGlja3M/Om51bWJlcjtidXJuVGlja3M/Om51bWJlcn09e30sdGFyZ2V0SWQ9YXQuaWQsIG1vdW50ZWQ/OntpdGVtOldvcmxkSXRlbTtwb3NlOk5vbk51bGxhYmxlPFJldHVyblR5cGU8dHlwZW9mIG1vdW50ZWRXZWFwb25Qb3NlPj47YWltUG9pbnQ/Ont4Om51bWJlcjt5Om51bWJlcn19LGFjdGlvbk1vZGU6XCJhdHRhY2tcInxcImNhc3RcIj1cImF0dGFja1wiKXtcbiAgY29uc3Qgb3JpZ2luID0gbW91bnRlZD8ucG9zZS5tdXp6bGUgPz8gd2VhcG9uT3JpZ2luKGF0dGFja2VyKTtcbiAgY29uc3QgZGFtYWdlUHJvZmlsZSA9IHdlYXBvbkRhbWFnZVByb2ZpbGUod2VhcG9uKTtcbiAgY29uc3QgdGFyZ2V0ID0gdGFyZ2V0SWQgPyBmaW5kU3RyaWtlVGFyZ2V0KGdhbWUsdGFyZ2V0SWQpIDogdW5kZWZpbmVkO1xuICBjb25zdCBwb2ludCA9IG1vdW50ZWQ/LmFpbVBvaW50ID8/ICh0YXJnZXQgPyBzdHJpa2VQb2ludChvcmlnaW4sdGFyZ2V0KSA6IGF0KTtcbiAgY29uc3QgZnJvbUhlaWdodD1tb3VudGVkPy5wb3NlLmhlaWdodCB8fCAoaXNVbml0KGF0dGFja2VyKSAmJiBzaGlwV2VhcG9uUG9zZShhdHRhY2tlcik/LmhlaWdodCkgfHwgY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsYXR0YWNrZXIpO1xuICBjb25zdCBhdHRhY2tLaW5kPXdlYXBvbi5wcmVzZW50YXRpb24gPz8gKHdlYXBvbi5kZWxpdmVyeT09PVwiY29uZVwiID8gXCJncmFwZXNob3RcIiA6IHdlYXBvbi5kZWxpdmVyeT09PVwic2hlbGxcIiA/IFwic3RvbmVcIiA6IFwiYm9sdFwiKTtcbiAgY29uc3QgdmlzdWFscz17YWN0aW9uTW9kZSxzb3VyY2VJZDphdHRhY2tlci5pZCxhdHRhY2tLaW5kLGZyb21YOm9yaWdpbi54LGZyb21ZOm9yaWdpbi55LGZyb21IZWlnaHQsdG9YOnBvaW50LngsdG9ZOnBvaW50LnksdG9IZWlnaHQ6Y29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsYXQpLG93bmVyOmF0dGFja2VyLm93bmVyLHNvdXJjZUtpbmQ6YXR0YWNrZXIua2luZCx1bml0SWQ6YXR0YWNrZXIuaWQsLi4uKG1vdW50ZWQ/e2l0ZW1JZDptb3VudGVkLml0ZW0uaWR9Ont9KX07XG4gIGlmKChhdHRhY2tLaW5kPT09XCJjYW5ub25cIiB8fCBhdHRhY2tLaW5kPT09XCJtb3J0YXJcIiB8fCBhdHRhY2tLaW5kPT09XCJncmFwZXNob3RcIikgJiYgKG1vdW50ZWQgfHwgaXNVbml0KGF0dGFja2VyKSkpYWRkRWZmZWN0KGdhbWUsXCJtdXp6bGVGbGFzaFwiLG9yaWdpbi54LG9yaWdpbi55LHNlY29uZHMoLjY1KSx2aXN1YWxzKTtcbiAgaWYod2VhcG9uLmRlbGl2ZXJ5PT09XCJyYW1cIil7XG4gICAgY29uc3QgdGFyZ2V0PXRhcmdldElkP2ZpbmRTdHJpa2VUYXJnZXQoZ2FtZSx0YXJnZXRJZCk6dW5kZWZpbmVkO1xuICAgIGlmKHRhcmdldCYmYXJlRW5lbXlPd25lcnMoZ2FtZSxhdHRhY2tlci5vd25lcix0YXJnZXQub3duZXIpKWhpdFdlYXBvbihnYW1lLGF0dGFja2VyLHRhcmdldCxkYW1hZ2Usd2VhcG9uKTtcbiAgICBhZGRFZmZlY3QoZ2FtZSxcInNpZWdlSW1wYWN0XCIsYXQueCxhdC55LDE4LHtmcm9tWDpvcmlnaW4ueCxmcm9tWTpvcmlnaW4ueSx0b1g6cG9pbnQueCx0b1k6cG9pbnQueSxvd25lcjphdHRhY2tlci5vd25lcixzb3VyY2VLaW5kOmF0dGFja2VyLmtpbmQsc291cmNlSWQ6YXR0YWNrZXIuaWQsYWN0aW9uTW9kZX0pO3JldHVybjtcbiAgfVxuICBpZih3ZWFwb24uZGVsaXZlcnk9PT1cImNvbmVcIil7XG4gICAgY29uc3QgaGl0cz1bLi4uZ2FtZS51bml0cywuLi5nYW1lLmJ1aWxkaW5nc10uZmlsdGVyKHRhcmdldD0+dGFyZ2V0LmhwPjAmJighaXNVbml0KHRhcmdldCl8fCFpc0luQ2FiaW4odGFyZ2V0KSkmJmFyZUVuZW15T3duZXJzKGdhbWUsYXR0YWNrZXIub3duZXIsdGFyZ2V0Lm93bmVyKSYmaW5XZWFwb25Db25lKG9yaWdpbixwb2ludCx0YXJnZXQscmFuZ2Usd2VhcG9uLmNvbmVBbmdsZT8/LjYpKTtcbiAgICB3aXRoRGVja0RhbWFnZUJhdGNoKGdhbWUsKCk9Pntmb3IoY29uc3QgdGFyZ2V0IG9mIGNyZXdCZWZvcmVIdWxscyhoaXRzKSloaXRXZWFwb24oZ2FtZSxhdHRhY2tlcix0YXJnZXQsZGFtYWdlKih3ZWFwb24uYnVyc3Q/PzEpLHdlYXBvbik7fSk7XG4gICAgYWRkRWZmZWN0KGdhbWUsXCJncmFwZXNob3RcIixwb2ludC54LHBvaW50Lnksc2Vjb25kcyguNyksey4uLnZpc3VhbHMscmFkaXVzOnJhbmdlfSk7cmV0dXJuO1xuICB9XG4gIGNvbnN0IGZsaWdodD1NYXRoLm1heChzZWNvbmRzKDAuMiksTWF0aC5jZWlsKGRpc3RhbmNlKG9yaWdpbixwb2ludCkvcGVyVGljayh3ZWFwb24uZGVsaXZlcnk9PT1cInNoZWxsXCI/MjQwOjU2MCkpKTtcbiAgY29uc3QgcHJvamVjdGlsZTpQcm9qZWN0aWxlPXtpZDpgcHJvamVjdGlsZS0ke2dhbWUubmV4dElkKyt9YCxvd25lcjphdHRhY2tlci5vd25lcixhdHRhY2tlcklkOmF0dGFja2VyLmlkLHRhcmdldElkOnRhcmdldElkPz9cIlwiLGZyb21YOm9yaWdpbi54LGZyb21ZOm9yaWdpbi55LHRvWDpwb2ludC54LHRvWTpwb2ludC55LGRhbWFnZSxkYW1hZ2VQcm9maWxlOnsuLi5kYW1hZ2VQcm9maWxlfSxyZW1haW5pbmc6ZmxpZ2h0LGR1cmF0aW9uOmZsaWdodCxhdHRhY2tLaW5kLHdlYXBvbjp7Li4ud2VhcG9ufSwuLi4oaXNVbml0KGF0dGFja2VyKT97c291cmNlS2luZDphdHRhY2tlci5raW5kfTp7fSksLi4uc2tpbGx9O1xuICBnYW1lLnByb2plY3RpbGVzLnB1c2gocHJvamVjdGlsZSk7XG4gIGFkZEVmZmVjdChnYW1lLHdlYXBvbi5kZWxpdmVyeT09PVwic2hlbGxcIj9cInNoZWxsRmxpZ2h0XCI6XCJzaWVnZUJvbHRcIixwb2ludC54LHBvaW50LnksZmxpZ2h0LHsuLi52aXN1YWxzLHJhZGl1czp3ZWFwb24ucmFkaXVzPz8wfSk7XG59XG5mdW5jdGlvbiBoaXRXZWFwb24oZ2FtZTpHYW1lLGF0dGFja2VyOlVuaXR8QnVpbGRpbmcsdGFyZ2V0OlVuaXR8QnVpbGRpbmd8T2JzdGFjbGUsZGFtYWdlOm51bWJlcix3ZWFwb246V2VhcG9uRGVmLHNoYXJlPTEscm9vdFRpY2tzPzpudW1iZXIsaW1wYWN0PXN0cmlrZVBvaW50KGF0dGFja2VyLHRhcmdldCkscHJvZmlsZTpEYW1hZ2VQcm9maWxlPXdlYXBvbkRhbWFnZVByb2ZpbGUod2VhcG9uKSx2aXN1YWxPcmlnaW4/Ont4Om51bWJlcjt5Om51bWJlcn0pe1xuICBjb25zdCBkZWFsdD13ZWFwb25EYW1hZ2Uod2VhcG9uLGRhbWFnZSwhaXNVbml0KHRhcmdldCksaXNVbml0KHRhcmdldCkmJnVuaXRNb3Zlcih0YXJnZXQua2luZCk9PT1cInNlYVwiLHNoYXJlKTtcbiAgY29uc3QgdGFrZW49YXBwbHlEYW1hZ2UoZ2FtZSxhdHRhY2tlcix0YXJnZXQsZGVhbHQsZGVja0h1bGxEYW1hZ2VTaGFyZShnYW1lLGF0dGFja2VyLHdlYXBvbiksaW1wYWN0LHdlYXBvbi5ibGFzdFJhZGl1cyA/PyB3ZWFwb24ucmFkaXVzID8/IDAscHJvZmlsZSk7aWYodGFrZW49PT11bmRlZmluZWQpcmV0dXJuO1xuICBhZGRIaXRFZmZlY3QoZ2FtZSx0YXJnZXQsdGFrZW4sYXR0YWNrZXIsd2VhcG9uLnByZXNlbnRhdGlvbix2aXN1YWxPcmlnaW4pO1xuICBpZihyb290VGlja3MmJmlzVW5pdCh0YXJnZXQpJiZ0YXJnZXQuaHA+MClzZXRTdGF0dXModGFyZ2V0LHt0eXBlOlwicm9vdFwiLHJlbWFpbmluZzpyb290VGlja3N9KTtcbn1cbmZ1bmN0aW9uIGltcGFjdFdlYXBvbihnYW1lOkdhbWUscHJvamVjdGlsZTpQcm9qZWN0aWxlKXtcbiAgY29uc3Qgd2VhcG9uPXByb2plY3RpbGUud2VhcG9uITtcbiAgLy8gUmVtZW1iZXIgdGhlIHNob290ZXIncyBraW5kIGlmIGl0IGRpZWQgZHVyaW5nIGZsaWdodDogYXJtb3IgYW5kIGF0dHJpYnV0aW9uIHJlbWFpbiBjb25zaXN0ZW50LlxuICBjb25zdCBsaXZlU291cmNlPWZpbmRUYXJnZXQoZ2FtZSxwcm9qZWN0aWxlLmF0dGFja2VySWQpO1xuICBjb25zdCBzb3VyY2U9bGl2ZVNvdXJjZT8ub3duZXI9PT1wcm9qZWN0aWxlLm93bmVyID8gbGl2ZVNvdXJjZSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgZmFsbGJhY2s9cHJvamVjdGlsZUF0dGFja2VyKHByb2plY3RpbGUpO1xuICBjb25zdCBhdHRhY2tlcj1zb3VyY2U/Pyhwcm9qZWN0aWxlLnNvdXJjZUtpbmQ/ey4uLmZhbGxiYWNrLGtpbmQ6cHJvamVjdGlsZS5zb3VyY2VLaW5kLG9yZGVyOnt0eXBlOlwiaWRsZVwifSxlZmZlY3RzOltdLHhwOjAsbGV2ZWw6MCxraWxsczowLGFiaWxpdHlDb29sZG93bjowLHNwZWVkOjB9IGFzIHVua25vd24gYXMgVW5pdDpmYWxsYmFjayk7XG4gIGNvbnN0IGZyb209e3g6cHJvamVjdGlsZS5mcm9tWCx5OnByb2plY3RpbGUuZnJvbVl9LHRvPXt4OnByb2plY3RpbGUudG9YLHk6cHJvamVjdGlsZS50b1l9O1xuICBjb25zdCBmbGlnaHRMZW5ndGg9ZGlzdGFuY2UoZnJvbSx0byksaW1wYWN0QXQ9KGFsb25nOm51bWJlcik9Pntjb25zdCBzaGFyZT1mbGlnaHRMZW5ndGg/TWF0aC5tYXgoMCxNYXRoLm1pbigxLGFsb25nL2ZsaWdodExlbmd0aCkpOjA7cmV0dXJue3g6ZnJvbS54Kyh0by54LWZyb20ueCkqc2hhcmUseTpmcm9tLnkrKHRvLnktZnJvbS55KSpzaGFyZX07fTtcbiAgY29uc3QgZm9lcz1bLi4uZ2FtZS51bml0cywuLi5nYW1lLmJ1aWxkaW5ncywuLi4oZ2FtZS5vYnN0YWNsZXM/P1tdKV0uZmlsdGVyKHQ9PnQuaHA+MCYmKCFpc1VuaXQodCl8fCFpc0luQ2FiaW4odCkpJiZhcmVFbmVteU93bmVycyhnYW1lLHByb2plY3RpbGUub3duZXIsdC5vd25lcikpO1xuICBpZih3ZWFwb24uZGVsaXZlcnk9PT1cImJvbHRcIil7XG4gICAgY29uc3QgaW50ZXJzZWN0aW9ucz1mb2VzLm1hcCh0YXJnZXQ9Pih7dGFyZ2V0LGFsb25nOmJvbHRJbnRlcnNlY3Rpb24oZnJvbSx0byx0YXJnZXQsd2VhcG9uLnJhZGl1cz8/MTIpfSkpLmZpbHRlcihoPT5oLmFsb25nIT09dW5kZWZpbmVkKS5zb3J0KChhLGIpPT5hLmFsb25nIS1iLmFsb25nISk7XG4gICAgY29uc3QgZWxpZ2libGU9bmV3IFNldChjcmV3QmVmb3JlSHVsbHMoaW50ZXJzZWN0aW9ucy5tYXAoaGl0PT5oaXQudGFyZ2V0KSkpO1xuICAgIGNvbnN0IGhpdHM9aW50ZXJzZWN0aW9ucy5maWx0ZXIoaGl0PT5lbGlnaWJsZS5oYXMoaGl0LnRhcmdldCkpLnNsaWNlKDAsd2VhcG9uLm1heEhpdHM/PzEpO1xuICAgIGlmKHdlYXBvbi5ibGFzdFJhZGl1cyAmJiBoaXRzWzBdKXtcbiAgICAgIGNvbnN0IGltcGFjdD1pbXBhY3RBdChoaXRzWzBdLmFsb25nISk7XG4gICAgICBmb3IoY29uc3QgdGFyZ2V0IG9mIGNyZXdCZWZvcmVIdWxscyhmb2VzLmZpbHRlcih0YXJnZXQ9PmJvZHlHYXAoaW1wYWN0LHRhcmdldCk8PXdlYXBvbi5ibGFzdFJhZGl1cyEpKSkge1xuICAgICAgICBjb25zdCBzaGFyZT1NYXRoLm1heCguNCwxLWJvZHlHYXAoaW1wYWN0LHRhcmdldCkvd2VhcG9uLmJsYXN0UmFkaXVzKi42KTtcbiAgICAgICAgaGl0V2VhcG9uKGdhbWUsYXR0YWNrZXIsdGFyZ2V0LHByb2plY3RpbGUuZGFtYWdlLHdlYXBvbixzaGFyZSxwcm9qZWN0aWxlLnJvb3RUaWNrcyxpbXBhY3QscHJvamVjdGlsZS5kYW1hZ2VQcm9maWxlLGZyb20pO1xuICAgICAgfVxuICAgICAgYWRkRWZmZWN0KGdhbWUsXCJzaWVnZUltcGFjdFwiLGltcGFjdC54LGltcGFjdC55LHNlY29uZHMoLjY1KSx7cmFkaXVzOndlYXBvbi5ibGFzdFJhZGl1cyxvd25lcjpwcm9qZWN0aWxlLm93bmVyLC4uLihwcm9qZWN0aWxlLnNvdXJjZUtpbmQ/e3NvdXJjZUtpbmQ6cHJvamVjdGlsZS5zb3VyY2VLaW5kfTp7fSl9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaGl0cy5mb3JFYWNoKCh7dGFyZ2V0LGFsb25nfSxpKT0+aGl0V2VhcG9uKGdhbWUsYXR0YWNrZXIsdGFyZ2V0LHByb2plY3RpbGUuZGFtYWdlLHdlYXBvbiwod2VhcG9uLnBpZXJjZVNoYXJlPz8xKSoqaSxwcm9qZWN0aWxlLnJvb3RUaWNrcyxpbXBhY3RBdChhbG9uZyEpLHByb2plY3RpbGUuZGFtYWdlUHJvZmlsZSxmcm9tKSk7XG4gIH1lbHNle1xuICAgIGZvcihjb25zdCB0YXJnZXQgb2YgY3Jld0JlZm9yZUh1bGxzKGZvZXMuZmlsdGVyKHRhcmdldD0+Ym9keUdhcCh0byx0YXJnZXQpPD0od2VhcG9uLnJhZGl1cz8/MCkpKSl7Y29uc3QgZ2FwPWJvZHlHYXAodG8sdGFyZ2V0KTtcbiAgICAgIGNvbnN0IGZhbGxvZmY9TWF0aC5tYXgoLjM1LDEtZ2FwL01hdGgubWF4KDEsd2VhcG9uLnJhZGl1cz8/MSkqLjY1KTtoaXRXZWFwb24oZ2FtZSxhdHRhY2tlcix0YXJnZXQscHJvamVjdGlsZS5kYW1hZ2Usd2VhcG9uLGZhbGxvZmYscHJvamVjdGlsZS5yb290VGlja3MsdG8scHJvamVjdGlsZS5kYW1hZ2VQcm9maWxlLGZyb20pO1xuICAgIH1cbiAgICBhZGRFZmZlY3QoZ2FtZSxcInNpZWdlSW1wYWN0XCIsdG8ueCx0by55LDI0LHtyYWRpdXM6d2VhcG9uLnJhZGl1cz8/MCxvd25lcjpwcm9qZWN0aWxlLm93bmVyLC4uLihwcm9qZWN0aWxlLnNvdXJjZUtpbmQ/e3NvdXJjZUtpbmQ6cHJvamVjdGlsZS5zb3VyY2VLaW5kfTp7fSl9KTtcbiAgICBpZihwcm9qZWN0aWxlLmJ1cm5UaWNrcylhZGRFZmZlY3QoZ2FtZSxcImJ1cm5pbmdHcm91bmRcIix0by54LHRvLnkscHJvamVjdGlsZS5idXJuVGlja3Mse293bmVyOnByb2plY3RpbGUub3duZXIsdW5pdElkOnByb2plY3RpbGUuYXR0YWNrZXJJZCxkYW1hZ2U6MyxkYW1hZ2VQcm9maWxlOnsuLi5EQU1BR0VfUFJPRklMRVMuQlVSTklOR30scmFkaXVzOndlYXBvbi5yYWRpdXM/PzAsdGlja0V2ZXJ5OjEwLC4uLihwcm9qZWN0aWxlLnNvdXJjZUtpbmQ/e3NvdXJjZUtpbmQ6cHJvamVjdGlsZS5zb3VyY2VLaW5kfTp7fSl9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBhcHBseVdlYXBvbkF0dGFjayhnYW1lOiBHYW1lLCBhdHRhY2tlcjogVW5pdCB8IEJ1aWxkaW5nLCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlLCBkYW1hZ2U6IG51bWJlciwgYXR0YWNrUmFuZ2U6IG51bWJlcikge1xuICBpZiAoIWlzT2JzdGFjbGUodGFyZ2V0KSkgdGFyZ2V0PW5hdmFsQ29tYmF0VGFyZ2V0KGdhbWUsYXR0YWNrZXIsdGFyZ2V0KTtcbiAgaWYoaXNVbml0KGF0dGFja2VyKSAmJiBzaGlwUHJvZmlsZShhdHRhY2tlcikgJiYgIXVuaXRSdWxlcyhnYW1lLGF0dGFja2VyKS5pbnRyaW5zaWNBdHRhY2spcmV0dXJuO1xuICBjb25zdCB3ZWFwb24gPSBpc1VuaXQoYXR0YWNrZXIpID8gd2VhcG9uUnVsZXMoZ2FtZSwgYXR0YWNrZXIpLndlYXBvbiA6IHVuZGVmaW5lZDtcbiAgaWYgKHdlYXBvbikge1xuICAgIGlmICh3ZWFwb24ubWluUmFuZ2UgJiYgZGlzdGFuY2UoYXR0YWNrZXIsIHRhcmdldCkgPCB3ZWFwb24ubWluUmFuZ2UpIHJldHVybjtcbiAgICBmaXJlV2VhcG9uKGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGRhbWFnZSwgd2VhcG9uLCBhdHRhY2tSYW5nZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGJhc2VSYW5nZSA9IGlzVW5pdChhdHRhY2tlcikgPyB3ZWFwb25SdWxlcyhnYW1lLCBhdHRhY2tlcikuYXR0YWNrUmFuZ2UgOiBhdHRhY2tSYW5nZTtcbiAgaWYgKGJhc2VSYW5nZSA+IFJBTkdFRF9BVFRBQ0tfUkFOR0VfVEhSRVNIT0xEKSB7XG4gICAgbGF1bmNoUHJvamVjdGlsZShnYW1lLCBhdHRhY2tlciwgdGFyZ2V0LCBidWlsZGluZ1RhcmdldERhbWFnZShhdHRhY2tlciwgdGFyZ2V0LCBkYW1hZ2UpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gUmFuZ2UgdXBncmFkZXMgZXh0ZW5kIGEgbWVsZWUgd2VhcG9uOyB0aGV5IGRvIG5vdCB0dXJuIGl0IGludG8gYSBwcm9qZWN0aWxlIG9yIGNoYW5nZSBpdHMgYXJtb3IgaW50ZXJhY3Rpb24uXG4gIGFwcGx5QXR0YWNrRGFtYWdlKGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGRhbWFnZSwgYmFzZVJhbmdlKTtcbn1cblxuZnVuY3Rpb24gbGF1bmNoUHJvamVjdGlsZShnYW1lOiBHYW1lLCBhdHRhY2tlcjogVW5pdCB8IEJ1aWxkaW5nLCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlLCBkYW1hZ2U6IG51bWJlcikge1xuICBjb25zdCBkeCA9IHRhcmdldC54IC0gYXR0YWNrZXIueDtcbiAgY29uc3QgZHkgPSB0YXJnZXQueSAtIGF0dGFja2VyLnk7XG4gIGNvbnN0IGZsaWdodCA9IE1hdGgubWF4KDEsIE1hdGguY2VpbChNYXRoLnNxcnQoZHggKiBkeCArIGR5ICogZHkpIC8gcGVyVGljayhQUk9KRUNUSUxFX1NQRUVEKSkpO1xuICBjb25zdCBwcm9qZWN0aWxlID0ge1xuICAgIGF0dGFja0tpbmQ6IGlubmF0ZU1pc3NpbGUoYXR0YWNrZXIua2luZCksXG4gICAgZGFtYWdlUHJvZmlsZTogeyAuLi4oaXNVbml0KGF0dGFja2VyKSA/IHVuaXRBdHRhY2tEYW1hZ2VQcm9maWxlKGdhbWUsIGF0dGFja2VyKSA6IGF0dGFja0RhbWFnZVByb2ZpbGUoYXR0YWNrZXIua2luZCkpIH0sXG4gICAgaWQ6IGBwcm9qZWN0aWxlLSR7Z2FtZS5uZXh0SWR9YCxcbiAgICBvd25lcjogYXR0YWNrZXIub3duZXIsXG4gICAgYXR0YWNrZXJJZDogYXR0YWNrZXIuaWQsXG4gICAgdGFyZ2V0SWQ6IHRhcmdldC5pZCxcbiAgICBmcm9tWDogYXR0YWNrZXIueCxcbiAgICBmcm9tWTogYXR0YWNrZXIueSxcbiAgICB0b1g6IHRhcmdldC54LFxuICAgIHRvWTogdGFyZ2V0LnksXG4gICAgZGFtYWdlLFxuICAgIHJlbWFpbmluZzogZmxpZ2h0LFxuICAgIGR1cmF0aW9uOiBmbGlnaHQsXG4gICAgLi4uKGlzVW5pdChhdHRhY2tlcikgPyB7IHNvdXJjZUtpbmQ6IGF0dGFja2VyLmtpbmQgfSA6IHt9KSxcbiAgICBodWxsRGFtYWdlU2hhcmU6IGRlY2tIdWxsRGFtYWdlU2hhcmUoZ2FtZSxhdHRhY2tlciksXG4gIH0gc2F0aXNmaWVzIFByb2plY3RpbGU7XG4gIGdhbWUubmV4dElkICs9IDE7XG4gIGdhbWUucHJvamVjdGlsZXMucHVzaChwcm9qZWN0aWxlKTtcbiAgYWRkRWZmZWN0KGdhbWUsIFwicHJvamVjdGlsZVwiLCB0YXJnZXQueCwgdGFyZ2V0LnksIGZsaWdodCwge1xuICAgIHNvdXJjZUlkOiBhdHRhY2tlci5pZCxcbiAgICBvd25lcjogYXR0YWNrZXIub3duZXIsXG4gICAgYWN0aW9uTW9kZTogXCJhdHRhY2tcIixcbiAgICBmcm9tWDogcHJvamVjdGlsZS5mcm9tWCxcbiAgICBmcm9tWTogcHJvamVjdGlsZS5mcm9tWSxcbiAgICB0b1g6IHByb2plY3RpbGUudG9YLFxuICAgIHRvWTogcHJvamVjdGlsZS50b1ksXG4gICAgc291cmNlS2luZDogYXR0YWNrZXIua2luZCxcbiAgICBhdHRhY2tLaW5kOiBwcm9qZWN0aWxlLmF0dGFja0tpbmQsXG4gICAgZnJvbUhlaWdodDogY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsYXR0YWNrZXIpLFxuICAgIHRvSGVpZ2h0OiBjb21iYXRWaXN1YWxIZWlnaHQoZ2FtZSx0YXJnZXQpLFxuICB9KTtcbn1cblxuZnVuY3Rpb24gYXBwbHlBdHRhY2tEYW1hZ2UoZ2FtZTogR2FtZSwgYXR0YWNrZXI6IFVuaXQgfCBCdWlsZGluZywgdGFyZ2V0OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSwgZGFtYWdlOiBudW1iZXIsIGF0dGFja1JhbmdlOiBudW1iZXIsIHByb2ZpbGU/OiBEYW1hZ2VQcm9maWxlKSB7XG4gIHByb2ZpbGUgPz89IGlzVW5pdChhdHRhY2tlcikgPyB1bml0QXR0YWNrRGFtYWdlUHJvZmlsZShnYW1lLCBhdHRhY2tlcikgOiBhdHRhY2tEYW1hZ2VQcm9maWxlKGF0dGFja2VyLmtpbmQpO1xuICBjb25zdCBkZWFsdCA9IHByb2ZpbGUub3JpZ2luID09PSBcInNwZWxsXCIgPyBkYW1hZ2UgOiBhdHRhY2tEYW1hZ2VBZ2FpbnN0VGFyZ2V0KGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGJ1aWxkaW5nVGFyZ2V0RGFtYWdlKGF0dGFja2VyLCB0YXJnZXQsIGRhbWFnZSkpO1xuICBjb25zdCB0YWtlbiA9IGFwcGx5RGFtYWdlKGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGRlYWx0LCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgMCwgcHJvZmlsZSk7XG4gIGlmICh0YWtlbiA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gIGlmIChwcm9maWxlLm9yaWdpbiAhPT0gXCJzcGVsbFwiKSBhcHBseUF0dGFja1N0YXR1c0VmZmVjdHMoZ2FtZSwgYXR0YWNrZXIsIHRhcmdldCwgYXR0YWNrZXIua2luZCk7XG4gIGlmIChwcm9maWxlLmRlbGl2ZXJ5ID09PSBcIm1lbGVlXCIgJiYgcHJvZmlsZS5vcmlnaW4gIT09IFwic3BlbGxcIiAmJiBpc1VuaXQoYXR0YWNrZXIpICYmIGlzVW5pdCh0YXJnZXQpKSBzdGFuY2VCbG93KGF0dGFja2VyLCB0YXJnZXQsIGRlYWx0KTtcbiAgY29uc3QgZnJvbSA9IHsgeDogYXR0YWNrZXIueCwgeTogYXR0YWNrZXIueSB9O1xuICBjb25zdCB0byA9IHsgeDogdGFyZ2V0LngsIHk6IHRhcmdldC55IH07XG4gIGNvbnN0IGtpbmQ6IFdvcmxkRWZmZWN0W1widHlwZVwiXSA9IGF0dGFja1JhbmdlID4gUkFOR0VEX0FUVEFDS19SQU5HRV9USFJFU0hPTEQgPyBcInByb2plY3RpbGVcIiA6IFwibWVsZWVcIjtcbiAgYWRkRWZmZWN0KGdhbWUsIGtpbmQsIHRvLngsIHRvLnksIGtpbmQgPT09IFwicHJvamVjdGlsZVwiID8gMjIgOiAxNiwgeyBmcm9tWDogZnJvbS54LCBmcm9tWTogZnJvbS55LCB0b1g6IHRvLngsIHRvWTogdG8ueSwgZnJvbUhlaWdodDogY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsYXR0YWNrZXIpLCB0b0hlaWdodDogY29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsdGFyZ2V0KSwgLi4uKGlzVW5pdChhdHRhY2tlcik/e3NvdXJjZUlkOiBhdHRhY2tlci5pZCwgYWN0aW9uTW9kZTogcHJvZmlsZS5vcmlnaW4gPT09IFwic3BlbGxcIiA/IFwiY2FzdFwiIGFzIGNvbnN0IDogXCJhdHRhY2tcIiBhcyBjb25zdH06e30pIH0pO1xuICBhZGRIaXRFZmZlY3QoZ2FtZSwgdGFyZ2V0LCB0YWtlbiwgYXR0YWNrZXIpO1xufVxuXG4vLyBUaGUgZmxpbmNoIG9mIHdoYXRldmVyIHdhcyBzdHJ1Y2ssIGNhcnJ5aW5nIHdobyBpdCB3YXMgYW5kIHdoYXQgaXQgdG9vaywgc28gdGhlIGNsaWVudCBzaGFrZXMgaXQgYnkgdGhlIHNoYXJlIG9mIGl0c1xuLy8gZnVsbCBoZWFsdGggdGhlIGJsb3cgdG9vaywgYW5kIHRoZSBraW5kIG9mIHdobyBzdHJ1Y2sgaXQgKGEgd2VhcG9uJ3MgYmxvdzsgYSBzcGVsbCdzIG9yIGEgZ29uZSBzaG9vdGVyJ3MgaGFzIG5vbmUpIHNvXG4vLyB0aGUgY2xpZW50IGNhbiBzb3VuZCB0aGUgYmxvdy5cbmZ1bmN0aW9uIGFkZEhpdEVmZmVjdChnYW1lOiBHYW1lLCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlLCB0YWtlbjogbnVtYmVyLCBzdHJpa2VyPzogVW5pdCB8IEJ1aWxkaW5nLCBhdHRhY2tLaW5kPzogQXR0YWNrS2luZCwgdmlzdWFsT3JpZ2luPzoge3g6bnVtYmVyO3k6bnVtYmVyfSkge1xuICBhdHRhY2tLaW5kID8/PSBzdHJpa2VyID8gaXNVbml0KHN0cmlrZXIpICYmIHdlYXBvblJ1bGVzKGdhbWUsc3RyaWtlcikuYXR0YWNrUmFuZ2U8PVJBTkdFRF9BVFRBQ0tfUkFOR0VfVEhSRVNIT0xEID8gXCJtZWxlZVwiIDogaW5uYXRlTWlzc2lsZShzdHJpa2VyLmtpbmQpIDogdW5kZWZpbmVkO1xuICBjb25zdCBvcmlnaW49dmlzdWFsT3JpZ2luPz9zdHJpa2VyO1xuICBjb25zdCBkZWNrPWlzVW5pdCh0YXJnZXQpJiZ0YXJnZXQuZGVjaztcbiAgY29uc3QgaHVsbD1kZWNrID8gZ2FtZS51bml0cy5maW5kKHVuaXQ9PnVuaXQuaWQ9PT1kZWNrLnNoaXBJZCkgOiB1bmRlZmluZWQ7XG4gIGFkZEVmZmVjdChnYW1lLCBcImhpdFwiLCB0YXJnZXQueCwgdGFyZ2V0LnksIDE0LCB7IHVuaXRJZDogdGFyZ2V0LmlkLCBkYW1hZ2U6IHRha2VuLCAuLi4oYXR0YWNrS2luZCA/IHthdHRhY2tLaW5kfSA6IHt9KSwgLi4uKHN0cmlrZXIgPyB7IHNvdXJjZUtpbmQ6IHN0cmlrZXIua2luZCB9IDoge30pLCAuLi4ob3JpZ2luP3tmcm9tWDpvcmlnaW4ueCxmcm9tWTpvcmlnaW4ueX06e30pLCAuLi4oZGVjayYmaHVsbD97dGFyZ2V0RGVjazp7Li4uZGVjayxoZWFkaW5nOmh1bGwuc2FpbGluZz8uaGVhZGluZz8/MH0sdG9IZWlnaHQ6Y29tYmF0VmlzdWFsSGVpZ2h0KGdhbWUsdGFyZ2V0KX06e30pLCAuLi4oaXNVbml0KHRhcmdldCkgPyB7IHRhcmdldEtpbmQ6IHRhcmdldC5raW5kLCB0YXJnZXRIcEFmdGVyOiB0YXJnZXQuaHAsIHRhcmdldE1heEhwOiB0YXJnZXQubWF4SHAsIHRhcmdldFJhZGl1czogdGFyZ2V0LnJhZGl1cywgdGFyZ2V0VW5pdENsYXNzOiB1bml0Q2xhc3NPZih0YXJnZXQsIGdhbWUpIH0gOiB7fSkgfSk7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkaW5nVGFyZ2V0RGFtYWdlKGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nIHwgT2JzdGFjbGUsIGRhbWFnZTogbnVtYmVyKSB7XG4gIGlmIChpc1VuaXQoYXR0YWNrZXIpIHx8ICFpc1VuaXQodGFyZ2V0KSB8fCB0YXJnZXQub3duZXIgIT09IFwibmV1dHJhbFwiKSByZXR1cm4gZGFtYWdlO1xuICByZXR1cm4gZGFtYWdlICogKEJVSUxESU5HX0RFRlNbYXR0YWNrZXIua2luZF0/Lm5ldXRyYWxEYW1hZ2VNdWx0aXBsaWVyID8/IDEpO1xufVxuXG5mdW5jdGlvbiBhdHRhY2tEYW1hZ2VBZ2FpbnN0VGFyZ2V0KGdhbWU6IEdhbWUsIGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nIHwgT2JzdGFjbGUsIGRhbWFnZTogbnVtYmVyKSB7XG4gIGlmICghaXNVbml0KGF0dGFja2VyKSB8fCAhaXNVbml0KHRhcmdldCkpIHJldHVybiBkYW1hZ2U7XG4gIGNvbnN0IHNsYXllciA9IHVuaXRSdWxlcyhnYW1lLCBhdHRhY2tlcikuY2FzdGVyU2xheWVyO1xuICBjb25zdCBkZWFsdCA9IHNsYXllciAmJiBpc0Nhc3Rlck9yU3VtbW9uZWQodGFyZ2V0KSA/IE1hdGgucm91bmQoZGFtYWdlICogc2xheWVyKSA6IGRhbWFnZTtcbiAgaWYgKCF0YXJnZXQuZWZmZWN0cy5zb21lKChlZmZlY3QpID0+IGVmZmVjdC50eXBlID09PSBcInNjb3JjaFwiKSkgcmV0dXJuIGRlYWx0O1xuICBpZiAoYXR0YWNrZXIua2luZCA9PT0gXCJlbWJlclJhdmFnZXJcIikgcmV0dXJuIGRlYWx0ICsgNztcbiAgaWYgKGF0dGFja2VyLmtpbmQgPT09IFwiY2luZGVyUnVubmVyXCIpIHJldHVybiBkZWFsdCArIDU7XG4gIHJldHVybiBkZWFsdDtcbn1cblxuLy8gQSBtZWxlZSBibG93IGluIGJyYWNlIG9yIHNob2NrIHNob3ZlcyBpdHMgdGFyZ2V0LCBhbmQgaW4gc2hvY2sgdGhlIHN0cmlrZXIgYWZ0ZXIgaXQgKHNlZSBAQEBtZWxlZS1zdGFuY2VzKS5cbmZ1bmN0aW9uIHN0YW5jZUJsb3coYXR0YWNrZXI6IFVuaXQsIHRhcmdldDogVW5pdCwgZGVhbHQ6IG51bWJlcikge1xuICBpZiAoIWF0dGFja2VyLnN0YW5jZSB8fCB0YXJnZXQuaHAgPD0gMCkgcmV0dXJuO1xuICBjb25zdCBzdHJlbmd0aCA9IGJsb3dTdHJlbmd0aChkZWFsdCwgdGFyZ2V0KTtcbiAgY29uc3QgZHggPSB0YXJnZXQueCAtIGF0dGFja2VyLng7XG4gIGNvbnN0IGR5ID0gdGFyZ2V0LnkgLSBhdHRhY2tlci55O1xuICBzaG92ZSh0YXJnZXQsIGR4LCBkeSwgc3RyZW5ndGgpO1xuICBpZiAoYXR0YWNrZXIuc3RhbmNlID09PSBcInNob2NrXCIpIHNob3ZlKGF0dGFja2VyLCBkeCwgZHksIGx1bmdlU3RyZW5ndGgoYXR0YWNrZXIsIHN0cmVuZ3RoKSk7XG59XG5cbi8vIFdoYXQgdGhlIGFzaCBjaGllZnRhaW4gaHVudHM6IGFueXRoaW5nIHN1bW1vbmVkLCBhbmQgYW55IHVuaXQgd2l0aCBhIHNwZWxsLlxuZnVuY3Rpb24gaXNDYXN0ZXJPclN1bW1vbmVkKHVuaXQ6IFVuaXQpIHtcbiAgcmV0dXJuIHVuaXQuZXhwaXJlc1RpY2sgIT09IHVuZGVmaW5lZCB8fCBoYXNTcGVsbCh1bml0LmtpbmQpO1xufVxuXG5mdW5jdGlvbiBhcHBseUF0dGFja1N0YXR1c0VmZmVjdHMoZ2FtZTogR2FtZSwgYXR0YWNrZXI6IFVuaXQgfCBCdWlsZGluZywgdGFyZ2V0OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSwgc291cmNlS2luZDogKFVuaXQgfCBCdWlsZGluZylbJ2tpbmQnXSB8IHVuZGVmaW5lZCkge1xuICBpZiAoc291cmNlS2luZCA9PT0gJ3NwYXJrQXJjaGVyJyAmJiBpc1VuaXQodGFyZ2V0KSAmJiAhdGFyZ2V0LmRlY2sgJiYgdW5pdE1vdmVyKHRhcmdldC5raW5kKSA9PT0gJ2xhbmQnXG4gICAgJiYgc3BhcmtJZ25pdGVzKGF0dGFja2VyLmlkLCB0YXJnZXQuaWQsIGdhbWUudGljaykpIHtcbiAgICBhZGRFZmZlY3QoZ2FtZSwgJ2J1cm5pbmdHcm91bmQnLCB0YXJnZXQueCwgdGFyZ2V0LnksIFNQQVJLX0ZJUkUuZHVyYXRpb24sIHtcbiAgICAgIG93bmVyOiBhdHRhY2tlci5vd25lciwgdW5pdElkOiBhdHRhY2tlci5pZCwgc291cmNlS2luZCwgZGFtYWdlUHJvZmlsZTogREFNQUdFX1BST0ZJTEVTLkJVUk5JTkcsXG4gICAgICBkYW1hZ2U6IFNQQVJLX0ZJUkUuZGFtYWdlLCByYWRpdXM6IFNQQVJLX0ZJUkUucmFkaXVzLCB0aWNrRXZlcnk6IFNQQVJLX0ZJUkUudGlja0V2ZXJ5LFxuICAgIH0pO1xuICB9XG4gIGlmICghaXNVbml0KGF0dGFja2VyKSkgcmV0dXJuO1xuICBjb25zdCBydWxlcyA9IHVuaXRSdWxlcyhnYW1lLCBhdHRhY2tlcik7XG4gIC8vIEEgcmVkIGRyYWdvbidzIGZpcmUgKHNlZSBAQEBjcmVlcC10cmFpdHMpIGZhbGxzIG9uIGJ1aWxkaW5ncycgbmVpZ2hib3VycyB0b28uXG4gIGlmIChydWxlcy5zcGxhc2gpIHtcbiAgICBjb25zdCBzaGFyZSA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQoYXR0YWNrZXIuYXR0YWNrRGFtYWdlICogU1BMQVNIX1NIQVJFKSk7XG4gICAgY29uc3QgYnVybmVkOiBVbml0W10gPSBbXTtcbiAgICBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lLCB0YXJnZXQsIFNQTEFTSF9SQURJVVMsICh1bml0KSA9PiB7XG4gICAgICBpZiAodW5pdCAhPT0gdGFyZ2V0ICYmIHVuaXQuaHAgPiAwICYmIGRpc3RhbmNlKHVuaXQsIHRhcmdldCkgPD0gU1BMQVNIX1JBRElVUyAmJiBhcmVFbmVteU93bmVycyhnYW1lLCBhdHRhY2tlci5vd25lciwgdW5pdC5vd25lcikpIGJ1cm5lZC5wdXNoKHVuaXQpO1xuICAgIH0pO1xuICAgIGZvciAoY29uc3QgdW5pdCBvZiBidXJuZWQpIGFwcGx5RGFtYWdlKGdhbWUsIGF0dGFja2VyLCB1bml0LCBzaGFyZSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIDAsIHVuaXRBdHRhY2tEYW1hZ2VQcm9maWxlKGdhbWUsIGF0dGFja2VyKSk7XG4gICAgYWRkRWZmZWN0KGdhbWUsIFwiZmxhbWVCdXJuXCIsIHRhcmdldC54LCB0YXJnZXQueSwgMjApO1xuICB9XG4gIGlmICghaXNVbml0KHRhcmdldCkpIHJldHVybjtcbiAgaWYgKHJ1bGVzLnNsb3dPbkhpdCkgc2V0U3RhdHVzKHRhcmdldCwgeyB0eXBlOiBcInNsb3dcIiwgcmVtYWluaW5nOiBTTE9XX1RJQ0tTIH0pO1xuICBpZiAocnVsZXMucG9pc29uT25IaXQpIHNldFN0YXR1cyh0YXJnZXQsIHsgdHlwZTogXCJwb2lzb25cIiwgcmVtYWluaW5nOiBQT0lTT05fVElDS1MsIHNvdXJjZUlkOiBhdHRhY2tlci5pZCwgc291cmNlT3duZXI6IGF0dGFja2VyLm93bmVyIH0pO1xufVxuXG4vLyBUaGUgZGFtYWdlIHRoZSB0YXJnZXQgdG9vaywgb3IgdW5kZWZpbmVkIHdoZW4gYSBndWFyZGlhbiBmaWVsZCB0dXJuZWQgdGhlIGJsb3cgYXNpZGUuXG5mdW5jdGlvbiBhcHBseURhbWFnZShnYW1lOiBHYW1lLCBhdHRhY2tlcjogVW5pdCB8IEJ1aWxkaW5nLCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlLCBkYW1hZ2U6IG51bWJlciwgaHVsbFNoYXJlPzogbnVtYmVyLGltcGFjdD86e3g6bnVtYmVyO3k6bnVtYmVyfSxibGFzdFJhZGl1cz0wLCBwcm9maWxlOiBEYW1hZ2VQcm9maWxlID0gaXNVbml0KGF0dGFja2VyKSA/IHVuaXRBdHRhY2tEYW1hZ2VQcm9maWxlKGdhbWUsIGF0dGFja2VyKSA6IGF0dGFja0RhbWFnZVByb2ZpbGUoYXR0YWNrZXIua2luZCksIGFybW9yQWxyZWFkeUFwcGxpZWQgPSBmYWxzZSwgZXhpc3RpbmdTdGF0dXMgPSBmYWxzZSk6IG51bWJlciB8IHVuZGVmaW5lZCB7XG4gIGlmIChpc1VuaXQoYXR0YWNrZXIpICYmIGlzSW5DYWJpbihhdHRhY2tlcikpIHJldHVybiB1bmRlZmluZWQ7XG4gIC8vIEV4aXN0aW5nIHBvaXNvbiBwZXJzaXN0cyBpbmRvb3JzOyBzaGVsdGVyIGJsb2NrcyBpbmNvbWluZyBhdHRhY2tzIHJhdGhlciB0aGFuIGNsZWFuc2luZyBzdGF0dXNlcy5cbiAgaWYgKGlzVW5pdCh0YXJnZXQpICYmIGlzQ2FiaW5Qcm90ZWN0ZWQoZ2FtZSx0YXJnZXQpICYmICFleGlzdGluZ1N0YXR1cykgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKCdpbnZ1bG5lcmFibGUnIGluIHRhcmdldCAmJiB0YXJnZXQuaW52dWxuZXJhYmxlKSByZXR1cm4gdW5kZWZpbmVkO1xuICBpZiAoaXNPYnN0YWNsZSh0YXJnZXQpKSB7XG4gICAgLy8gQSByb2NrIHBpbGUgb3IgZ2F0ZSB3YWtlcyBub2JvZHkgYW5kIHBheXMgbm90aGluZyB3aGVuIGl0IGZhbGxzIChzZWUgQEBAb2JzdGFjbGUpLlxuICAgIGNvbnN0IGhwQmVmb3JlID0gdGFyZ2V0LmhwO1xuICAgIHRhcmdldC5ocCAtPSBkYW1hZ2U7XG4gICAgZ2FtZS5vYnNlcnZlcj8uaGl0KGF0dGFja2VyLCB0YXJnZXQsIGRhbWFnZSwgaHBCZWZvcmUpO1xuICAgIHJldHVybiBkYW1hZ2U7XG4gIH1cbiAgY29uc3QgaW1wYWN0RGFtYWdlID0gZGFtYWdlO1xuICBjb25zdCByZXNvbHZlZCA9IGlzVW5pdCh0YXJnZXQpID8gcmVzb2x2ZVVuaXREYW1hZ2UoZ2FtZSwgdGFyZ2V0LCBkYW1hZ2UsIHByb2ZpbGUsIGdhbWUudmV0ZXJhbkZyYW1lPy5nZXQodGFyZ2V0LmlkKT8ucmVkdWN0aW9ucywgeyBhcm1vckFscmVhZHlBcHBsaWVkIH0pIDogdW5kZWZpbmVkO1xuICBpZiAocmVzb2x2ZWQ/LmJsb2NrZWQpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IHRha2VuID0gcmVzb2x2ZWQ/LmRhbWFnZSA/PyBkYW1hZ2U7XG4gIGNvbnN0IGhwQmVmb3JlID0gdGFyZ2V0LmhwO1xuICB0YXJnZXQuaHAgLT0gdGFrZW47XG4gIGlmKGlzVW5pdCh0YXJnZXQpICYmIHNoaXBQcm9maWxlKHRhcmdldCkpe1xuICAgIGRhbWFnZVNoaXBHYW5nd2F5KHRhcmdldCx0YWtlbik7XG4gICAgZGFtYWdlU2hpcFBhcnRzKGdhbWUsdGFyZ2V0LGltcGFjdCA/PyBzdHJpa2VQb2ludChhdHRhY2tlcix0YXJnZXQpLHRha2VuLGJsYXN0UmFkaXVzKTtcbiAgICBpZih0YXJnZXQuaHA+MCkge1xuICAgICAgYXBwbHlEZXJpdmVkVW5pdFN0YXRzKGdhbWUsdGFyZ2V0KTtcbiAgICAgIHVwZGF0ZUNhYmluUGFzc2VuZ2VycyhnYW1lKTtcbiAgICAgIC8vIFRyYXBwZWQgb2NjdXBhbnRzIG9mIGEgYnJva2VuIGNvbXBhcnRtZW50IHJlbWFpbiBzZWxlY3RhYmxlIGluIHRoZSBjcmV3IGxpc3QsIG5vdCBhcyBpbnZpc2libGUgdGFyZ2V0cy5cbiAgICAgIC8vIEluY29taW5nIGh1bGwgaGl0cyByZWFjaCB0aGVtIHVudGlsIGEgcmVhbCwgY2xlYXIgZGVjayBleGl0IG9wZW5zLlxuICAgICAgZm9yIChjb25zdCBwYXNzZW5nZXIgb2Ygc2hpcFBhc3NlbmdlcnMoZ2FtZS51bml0cyx0YXJnZXQpKSBpZiAocGFzc2VuZ2VyLmhwPjAgJiYgaXNJbkNhYmluKHBhc3NlbmdlcikgJiYgIWlzQ2FiaW5Qcm90ZWN0ZWQoZ2FtZSxwYXNzZW5nZXIpKSBhcHBseURhbWFnZShnYW1lLGF0dGFja2VyLHBhc3Nlbmdlcix0YWtlbiouMzUsMCxpbXBhY3QsMCxwcm9maWxlKTtcbiAgICB9XG4gIH1cbiAgaWYgKGhwQmVmb3JlID4gMCAmJiBpc1VuaXQodGFyZ2V0KSkge1xuICAgIGlmIChzaGlwUHJvZmlsZSh0YXJnZXQpICYmIGdhbWUuZGVja0RhbWFnZUJhdGNoKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IGdhbWUuZGVja0RhbWFnZUJhdGNoLmdldCh0YXJnZXQuaWQpID8/IHsgc2hpcDogdGFyZ2V0LCBkaXJlY3Q6IDAsIGNvbGxhdGVyYWw6IDAgfTtcbiAgICAgIGVudHJ5LmRpcmVjdCArPSBpbXBhY3REYW1hZ2U7XG4gICAgICBnYW1lLmRlY2tEYW1hZ2VCYXRjaC5zZXQodGFyZ2V0LmlkLCBlbnRyeSk7XG4gICAgfVxuICAgIGNvbnN0IGh1bGwgPSB0YXJnZXQuZGVjayAmJiBnYW1lLnVuaXRzLmZpbmQoc2hpcCA9PiBzaGlwLmlkID09PSB0YXJnZXQuZGVjayEuc2hpcElkICYmIHNoaXAuaHAgPiAwKTtcbiAgICBpZiAoaHVsbCAmJiBhcmVFbmVteU93bmVycyhnYW1lLCBhdHRhY2tlci5vd25lciwgaHVsbC5vd25lcikpIHtcbiAgICAgIGNvbnN0IGNvbGxhdGVyYWwgPSBpbXBhY3REYW1hZ2UgKiAoaHVsbFNoYXJlID8/IGRlY2tIdWxsRGFtYWdlU2hhcmUoZ2FtZSxhdHRhY2tlcikpO1xuICAgICAgaWYgKGdhbWUuZGVja0RhbWFnZUJhdGNoKSB7XG4gICAgICAgIGNvbnN0IGVudHJ5ID0gZ2FtZS5kZWNrRGFtYWdlQmF0Y2guZ2V0KGh1bGwuaWQpID8/IHsgc2hpcDogaHVsbCwgZGlyZWN0OiAwLCBjb2xsYXRlcmFsOiAwLCBzb3VyY2U6IGF0dGFja2VyIH07XG4gICAgICAgIGlmIChjb2xsYXRlcmFsID4gZW50cnkuY29sbGF0ZXJhbCkgeyBlbnRyeS5jb2xsYXRlcmFsID0gY29sbGF0ZXJhbDsgZW50cnkuc291cmNlID0gYXR0YWNrZXI7IGVudHJ5LnByb2ZpbGUgPSBwcm9maWxlOyB9XG4gICAgICAgIGdhbWUuZGVja0RhbWFnZUJhdGNoLnNldChodWxsLmlkLHsuLi5lbnRyeSxpbXBhY3Q6e3g6dGFyZ2V0LngseTp0YXJnZXQueX0sYmxhc3RSYWRpdXN9KTtcbiAgICAgIH0gZWxzZSBpZiAoY29sbGF0ZXJhbCA+IDApIGFwcGx5RGFtYWdlKGdhbWUsIGF0dGFja2VyLCBodWxsLCBjb2xsYXRlcmFsLCAwLHRhcmdldCwwLHByb2ZpbGUpO1xuICAgIH1cbiAgfVxuICBnYW1lLm9ic2VydmVyPy5oaXQoYXR0YWNrZXIsIHRhcmdldCwgdGFrZW4sIGhwQmVmb3JlKTtcbiAgaWYgKGhwQmVmb3JlID4gMCAmJiBpc1VuaXQodGFyZ2V0KSAmJiB0YXJnZXQub3duZXIgPT09IFwibmV1dHJhbFwiKSB0cmlnZ2VyTmV1dHJhbEFzc2lzdChnYW1lLCB0YXJnZXQsIGF0dGFja2VyKTtcbiAgaWYgKGhwQmVmb3JlID4gMCAmJiBpc1BsYXllcklkKHRhcmdldC5vd25lcikpIHRyaWdnZXJQbGF5ZXJBZ2dybyhnYW1lLCB0YXJnZXQsIGF0dGFja2VyKTtcbiAgaWYgKGhwQmVmb3JlID4gMCAmJiB0YXJnZXQuaHAgPD0gMCkge1xuICAgIHJlY29yZEtpbGwoZ2FtZSwgYXR0YWNrZXIsIHRhcmdldCk7XG4gIH1cbiAgcmV0dXJuIHRha2VuO1xufVxuXG5mdW5jdGlvbiB3aXRoRGVja0RhbWFnZUJhdGNoKGdhbWU6IEdhbWUsIGJvZHk6ICgpID0+IHZvaWQpIHtcbiAgaWYgKGdhbWUuZGVja0RhbWFnZUJhdGNoKSB7IGJvZHkoKTsgcmV0dXJuOyB9XG4gIGNvbnN0IGJhdGNoOiBOb25OdWxsYWJsZTxHYW1lW1wiZGVja0RhbWFnZUJhdGNoXCJdPiA9IG5ldyBNYXAoKTtcbiAgZ2FtZS5kZWNrRGFtYWdlQmF0Y2ggPSBiYXRjaDtcbiAgdHJ5IHsgYm9keSgpOyB9IGZpbmFsbHkgeyBkZWxldGUgZ2FtZS5kZWNrRGFtYWdlQmF0Y2g7IH1cbiAgZm9yIChjb25zdCB7IHNoaXAsIGRpcmVjdCwgY29sbGF0ZXJhbCwgc291cmNlLGltcGFjdCxibGFzdFJhZGl1cyxwcm9maWxlIH0gb2YgYmF0Y2gudmFsdWVzKCkpIHtcbiAgICBpZiAoc291cmNlICYmIHNoaXAuaHAgPiAwICYmIGNvbGxhdGVyYWwgPiBkaXJlY3QpIGFwcGx5RGFtYWdlKGdhbWUsIHNvdXJjZSwgc2hpcCwgY29sbGF0ZXJhbCAtIGRpcmVjdCwgMCxpbXBhY3QsYmxhc3RSYWRpdXMscHJvZmlsZSk7XG4gIH1cbn1cblxuLyoqIFNoaXAgb3JkZXJzIGFkZHJlc3MgdGhlIGZpZ2h0aW5nIGRlY2sgYW5kIHJlbWFpbiBvbiB0aGUgaHVsbCBhZnRlciBpdHMgbGFzdCBwYXNzZW5nZXIgZGllcy4gKi9cbmZ1bmN0aW9uIG5hdmFsQ29tYmF0VGFyZ2V0KGdhbWU6IEdhbWUsIGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nLCBjcmV3UmFuZ2U9SW5maW5pdHkpOiBVbml0IHwgQnVpbGRpbmcge1xuICBpZiAoIWlzVW5pdCh0YXJnZXQpIHx8ICFzaGlwUHJvZmlsZSh0YXJnZXQpKSByZXR1cm4gdGFyZ2V0O1xuICBjb25zdCBob21lPWlzVW5pdChhdHRhY2tlcikgJiYgYXR0YWNrZXIuZGVjayAmJiB1bml0UnVsZXMoZ2FtZSxhdHRhY2tlcikuYXR0YWNrUmFuZ2U8PVJBTkdFRF9BVFRBQ0tfUkFOR0VfVEhSRVNIT0xEXG4gICAgPyBnYW1lLnVuaXRzLmZpbmQoc2hpcD0+c2hpcC5pZD09PWF0dGFja2VyLmRlY2shLnNoaXBJZCkgOiB1bmRlZmluZWQ7XG4gIC8vIEJvYXJkZXJzIHJlbWFpbiBjb21iYXRhbnRzIHdoZW4gdGhleSBjcm9zcyB0aGUgc2VhbSBvbnRvIG91ciBvd24gZGVjay5cbiAgLy8gQSBodWxsLXRhcmdldGVkIG1lbGVlIG9yZGVyIG11c3QgYW5zd2VyIHRoZW0gYmVmb3JlIHN0cmlraW5nIGFuIGVtcHR5IGh1bGwuXG4gIGNvbnN0IHBhc3NlbmdlcnM9aG9tZSAmJiBob21lLmlkIT09dGFyZ2V0LmlkICYmIGRlY2tzQ2FuVHJhbnNmZXIoaG9tZSx0YXJnZXQsYXR0YWNrZXIgYXMgVW5pdClcbiAgICA/IFsuLi5zaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLHRhcmdldCksLi4uc2hpcFBhc3NlbmdlcnMoZ2FtZS51bml0cyxob21lKV0gOiBzaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLHRhcmdldCk7XG4gIGNvbnN0IGNyZXcgPSBwYXNzZW5nZXJzLmZpbHRlcih1bml0ID0+IHVuaXQuaHAgPiAwICYmICFpc0luQ2FiaW4odW5pdCkgJiYgYXJlRW5lbXlPd25lcnMoZ2FtZSwgYXR0YWNrZXIub3duZXIsIHVuaXQub3duZXIpICYmIChjcmV3UmFuZ2U9PT1JbmZpbml0eSB8fCBkaXN0YW5jZVNxdWFyZWQoYXR0YWNrZXIsdW5pdCk8PWNyZXdSYW5nZSpjcmV3UmFuZ2UpXG4gICAgJiYgKGlzVW5pdChhdHRhY2tlcikgPyBjYW5SZWFjaChnYW1lLm1hcCwgYXR0YWNrZXIsIHVuaXQsIGdhbWUudW5pdHMpIDogZGlzdGFuY2UoYXR0YWNrZXIsdW5pdCk8PWF0dGFja2VyLmF0dGFja1JhbmdlKSk7XG4gIGxldCBiZXN0OiBVbml0IHwgdW5kZWZpbmVkLCBiZXN0U2NvcmUgPSAtSW5maW5pdHk7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBjcmV3KSB7XG4gICAgY29uc3Qgc2NvcmUgPSB0YXJnZXRQcmlvcml0eVNjb3JlKGdhbWUsIGF0dGFja2VyLm93bmVyLCB1bml0LCBkaXN0YW5jZVNxdWFyZWQoYXR0YWNrZXIsIHVuaXQpLCBpc1VuaXQoYXR0YWNrZXIpID8gYXR0YWNrZXIgOiB1bmRlZmluZWQpO1xuICAgIGlmIChzY29yZSA+IGJlc3RTY29yZSkgeyBiZXN0ID0gdW5pdDsgYmVzdFNjb3JlID0gc2NvcmU7IH1cbiAgfVxuICByZXR1cm4gYmVzdCA/PyBjcmV3WzBdID8/IHRhcmdldDtcbn1cblxuZnVuY3Rpb24gdHJpZ2dlck5ldXRyYWxBc3Npc3QoZ2FtZTogR2FtZSwgZGFtYWdlZE5ldXRyYWw6IFVuaXQsIGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcpIHtcbiAgaWYgKCFhcmVFbmVteU93bmVycyhnYW1lLCBkYW1hZ2VkTmV1dHJhbC5vd25lciwgYXR0YWNrZXIub3duZXIpKSByZXR1cm47XG4gIGNvbnN0IG9yaWdpbiA9IG5ldXRyYWxIb21lT3JDdXJyZW50UG9pbnQoZGFtYWdlZE5ldXRyYWwpO1xuICAvLyBAQEBuZXV0cmFsLWFzc2lzdCAtIERhbWFnZSB3YWtlcyB0aGUgY2FtcDsgYW4gb25nb2luZyBmaWdodCBjaGFuZ2VzIHRhcmdldCBvbmx5IGZvciBhIHN1YnN0YW50aWFsbHkgZ3JlYXRlciB0aHJlYXQuXG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSB7XG4gICAgaWYgKHVuaXQub3duZXIgIT09IFwibmV1dHJhbFwiIHx8IHVuaXQuaHAgPD0gMCkgY29udGludWU7XG4gICAgaWYgKGRpc3RhbmNlKHVuaXQsIGRhbWFnZWROZXV0cmFsKSA+IE5FVVRSQUxfQVNTSVNUX1JBTkdFKSBjb250aW51ZTtcbiAgICBpZiAoIWNhblJlYWNoKGdhbWUubWFwLCB1bml0LCBhdHRhY2tlciwgZ2FtZS51bml0cykpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHJlc3BvbnNlT3JpZ2luID0gbmV1dHJhbFJlc3BvbnNlT3JpZ2luKHVuaXQpID8/IG9yaWdpbjtcbiAgICBpZiAoZGlzdGFuY2UoYXR0YWNrZXIsIHJlc3BvbnNlT3JpZ2luKSA+IE5FVVRSQUxfREFNQUdFX1JFU1BPTlNFX1JBTkdFKSBjb250aW51ZTtcbiAgICBpZiAobmV1dHJhbEhhc1ZhbGlkQXR0YWNrVGFyZ2V0KGdhbWUsIHVuaXQpICYmIHVuaXQub3JkZXIudHlwZSA9PT0gXCJhdHRhY2tcIikge1xuICAgICAgaWYgKGluY29taW5nVGhyZWF0T3V0cmFua3MoZ2FtZSwgdW5pdCwgdW5pdC5vcmRlci50YXJnZXRJZCwgYXR0YWNrZXIsIGRhbWFnZWROZXV0cmFsKSkgdW5pdC5vcmRlciA9IHsgLi4udW5pdC5vcmRlciwgdGFyZ2V0SWQ6IGF0dGFja2VyLmlkIH07XG4gICAgfSBlbHNlIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiYXR0YWNrXCIsIHRhcmdldElkOiBhdHRhY2tlci5pZCwgbGVhc2hYOiBvcmlnaW4ueCwgbGVhc2hZOiBvcmlnaW4ueSB9O1xuICB9XG59XG5cbi8vIEEgaGl0IHdha2VzIHRoZSB2aWN0aW0gYW5kIGV2ZXJ5IHNvbGRpZXIgb2YgaXRzIG93bmVyIHdpdGhpbiBjYWxsIHJhbmdlLCBldmVuIHdoZW4gdGhlIHZpY3RpbSBpcyBhIHdvcmtlciBvciBhXG4vLyBidWlsZGluZyBvciBkaWQgbm90IHN1cnZpdmUgdGhlIGhpdC4gQXR0YWNrZXJzIHRoYXQgYXJlIGFscmVhZHkgZ29uZSAoYSB0b3dlcidzIGFycm93IHN0aWxsIGZseWluZywgYSBzdG9ybSkgYXJlIG5vYm9keVxuLy8gdG8gdHVybiBvbi5cbmZ1bmN0aW9uIHRyaWdnZXJQbGF5ZXJBZ2dybyhnYW1lOiBHYW1lLCB2aWN0aW06IFVuaXQgfCBCdWlsZGluZywgYXR0YWNrZXI6IFVuaXQgfCBCdWlsZGluZykge1xuICBpZiAoIWFyZUVuZW15T3duZXJzKGdhbWUsIHZpY3RpbS5vd25lciwgYXR0YWNrZXIub3duZXIpIHx8IGF0dGFja2VyLmhwIDw9IDAgfHwgZmluZFRhcmdldChnYW1lLCBhdHRhY2tlci5pZCkgIT09IGF0dGFja2VyKSByZXR1cm47XG4gIGlmIChpc1VuaXQodmljdGltKSkgdGFrZVVwQXR0YWNrZXIoZ2FtZSwgdmljdGltLCBhdHRhY2tlciwgdmljdGltKTtcbiAgY29uc3QgcmVhY2ggPSBIRUxQX0NBTExfUkFOR0UgKyAoaXNVbml0KHZpY3RpbSkgPyAwIDogdmljdGltLnJhZGl1cyk7XG4gIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIHZpY3RpbSwgcmVhY2gsIChhbGx5KSA9PiB7XG4gICAgaWYgKGFsbHkgPT09IHZpY3RpbSB8fCBhbGx5Lm93bmVyICE9PSB2aWN0aW0ub3duZXIgfHwgZGlzdGFuY2UoYWxseSwgdmljdGltKSA+IHJlYWNoKSByZXR1cm47XG4gICAgdGFrZVVwQXR0YWNrZXIoZ2FtZSwgYWxseSwgYXR0YWNrZXIsIHZpY3RpbSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiB0YWtlVXBBdHRhY2tlcihnYW1lOiBHYW1lLCB1bml0OiBVbml0LCBhdHRhY2tlcjogVW5pdCB8IEJ1aWxkaW5nLCB2aWN0aW06IFVuaXQgfCBCdWlsZGluZykge1xuICBpZiAodW5pdC5ocCA8PSAwIHx8IHVuaXQua2luZCA9PT0gXCJ3b3JrZXJcIiB8fCB1bml0LmF0dGFja0RhbWFnZSA8PSAwIHx8ICFjYW5SZWFjaChnYW1lLm1hcCwgdW5pdCwgYXR0YWNrZXIsIGdhbWUudW5pdHMpKSByZXR1cm47XG4gIGNvbnN0IG9yZGVyID0gdW5pdC5vcmRlcjtcbiAgaWYoc2hpcFByb2ZpbGUodW5pdCkgJiYgb3JkZXIudHlwZT09PSdpZGxlJylyZXR1cm47XG4gIGlmIChvcmRlci50eXBlID09PSBcImlkbGVcIikge1xuICAgIGlmICghdW5pdC5vcmRlclF1ZXVlPy5sZW5ndGgpIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiYXR0YWNrXCIsIHRhcmdldElkOiBhdHRhY2tlci5pZCwgbGVhc2hYOiB1bml0LngsIGxlYXNoWTogdW5pdC55IH07XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChvcmRlci50eXBlID09PSBcImF0dGFja01vdmVcIikge1xuICAgIGlmICghb3JkZXIudGFyZ2V0SWQgfHwgaW5jb21pbmdUaHJlYXRPdXRyYW5rcyhnYW1lLCB1bml0LCBvcmRlci50YXJnZXRJZCwgYXR0YWNrZXIsIHZpY3RpbSkpIHVuaXQub3JkZXIgPSB7IC4uLm9yZGVyLCB0YXJnZXRJZDogYXR0YWNrZXIuaWQgfTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgc2VsZkRpcmVjdGVkID0gb3JkZXIudHlwZSA9PT0gXCJhdHRhY2tcIiAmJiBvcmRlci5sZWFzaFggIT09IHVuZGVmaW5lZDtcbiAgaWYgKHNlbGZEaXJlY3RlZCAmJiBpbmNvbWluZ1RocmVhdE91dHJhbmtzKGdhbWUsIHVuaXQsIG9yZGVyLnRhcmdldElkLCBhdHRhY2tlciwgdmljdGltKSkgdW5pdC5vcmRlciA9IHsgLi4ub3JkZXIsIHRhcmdldElkOiBhdHRhY2tlci5pZCB9O1xufVxuXG4vLyBUaGUgc2FtZSBzY29yZSBhbmQgaHlzdGVyZXNpcyBhcHBseSB0byBkYW1hZ2UgcmVzcG9uc2VzIGFuZCBvcmRpbmFyeSBhY3F1aXNpdGlvbiwgZXZlbiBkdXJpbmcgYSBzdHJpa2UuXG5mdW5jdGlvbiBpbmNvbWluZ1RocmVhdE91dHJhbmtzKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIHRhcmdldElkOiBzdHJpbmcsIGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcsIHZpY3RpbTogVW5pdCB8IEJ1aWxkaW5nKSB7XG4gIGlmICh0YXJnZXRJZCA9PT0gYXR0YWNrZXIuaWQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgY3VycmVudCA9IGZpbmRUYXJnZXQoZ2FtZSwgdGFyZ2V0SWQpO1xuICBpZiAoIWN1cnJlbnQgfHwgY3VycmVudC5ocCA8PSAwIHx8ICFjYW5SZWFjaChnYW1lLm1hcCwgdW5pdCwgY3VycmVudCwgZ2FtZS51bml0cykpIHJldHVybiB0cnVlO1xuICBjb25zdCBpbmNvbWluZyA9IGNvbWJhdFRhcmdldFNjb3JlKGF0dGFja2VyLCB0YXJnZXRHYXAodW5pdCwgYXR0YWNrZXIpLCB2aWN0aW0uaWQgPT09IHVuaXQuaWQgPyBcInNlbGZcIiA6IFwiYWxseVwiLCBwcm9qZWN0ZWRIcEFmdGVyUGVuZGluZ1Byb2plY3RpbGVzKGdhbWUsIHVuaXQub3duZXIsIGF0dGFja2VyKSk7XG4gIHJldHVybiBzaG91bGRTd2l0Y2hDb21iYXRUYXJnZXQodGFyZ2V0UHJpb3JpdHlTY29yZShnYW1lLCB1bml0Lm93bmVyLCBjdXJyZW50LCB0YXJnZXRHYXAodW5pdCwgY3VycmVudCkgKiogMiwgdW5pdCksIGluY29taW5nKTtcbn1cblxuZnVuY3Rpb24gYXV0b21hdGljQ29tYmF0VGFyZ2V0KGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIGN1cnJlbnQ6IFVuaXQgfCBCdWlsZGluZywgbmF2YWxGcmFtZSA9IHRydWUpOiBVbml0IHwgQnVpbGRpbmcge1xuICAvLyBJbmNvbWluZyBkYW1hZ2UgcmVhY3RzIGltbWVkaWF0ZWx5OyBvcmRpbmFyeSByZWNvbnNpZGVyYXRpb24gaGFwcGVucyBhcyB0aGUgbmV4dCBzaG90IGJlY29tZXMgYXZhaWxhYmxlLlxuICBpZiAodW5pdC5jb29sZG93biA+IDApIHJldHVybiBjdXJyZW50O1xuICBjb25zdCBuZXh0ID0gbmVhcmVzdEVuZW15VGFyZ2V0KGdhbWUsIHVuaXQsIE1hdGgubWF4KEFVVE9fQUNRVUlSRV9SQU5HRSwgdW5pdC5hdHRhY2tSYW5nZSksIG5hdmFsRnJhbWUpO1xuICBpZiAoIW5leHQgfHwgbmV4dC5pZCA9PT0gY3VycmVudC5pZCkgcmV0dXJuIGN1cnJlbnQ7XG4gIHJldHVybiBzaG91bGRTd2l0Y2hDb21iYXRUYXJnZXQodGFyZ2V0UHJpb3JpdHlTY29yZShnYW1lLCB1bml0Lm93bmVyLCBjdXJyZW50LCB0YXJnZXRHYXAodW5pdCwgY3VycmVudCwgbmF2YWxGcmFtZSkgKiogMiwgdW5pdCksXG4gICAgdGFyZ2V0UHJpb3JpdHlTY29yZShnYW1lLCB1bml0Lm93bmVyLCBuZXh0LCB0YXJnZXRHYXAodW5pdCwgbmV4dCwgbmF2YWxGcmFtZSkgKiogMiwgdW5pdCkpID8gbmV4dCA6IGN1cnJlbnQ7XG59XG5cbmZ1bmN0aW9uIG5ldXRyYWxIYXNWYWxpZEF0dGFja1RhcmdldChnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGlmICh1bml0Lm9yZGVyLnR5cGUgIT09IFwiYXR0YWNrXCIpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgdGFyZ2V0ID0gZmluZFRhcmdldChnYW1lLCB1bml0Lm9yZGVyLnRhcmdldElkKTtcbiAgaWYgKCF0YXJnZXQgfHwgdGFyZ2V0LmhwIDw9IDAgfHwgIWFyZUVuZW15T3duZXJzKGdhbWUsIHVuaXQub3duZXIsIHRhcmdldC5vd25lcikpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgcmVzcG9uc2VPcmlnaW4gPSBuZXV0cmFsUmVzcG9uc2VPcmlnaW4odW5pdCk7XG4gIGlmIChyZXNwb25zZU9yaWdpbiAmJiBkaXN0YW5jZSh0YXJnZXQsIHJlc3BvbnNlT3JpZ2luKSA+IE5FVVRSQUxfREFNQUdFX1JFU1BPTlNFX1JBTkdFKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiBuZXV0cmFsUmVzcG9uc2VPcmlnaW4odW5pdDogVW5pdCkge1xuICBpZiAodW5pdC5vcmRlci50eXBlID09PSBcImF0dGFja1wiICYmIHVuaXQub3JkZXIubGVhc2hYICE9PSB1bmRlZmluZWQgJiYgdW5pdC5vcmRlci5sZWFzaFkgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHsgeDogdW5pdC5vcmRlci5sZWFzaFgsIHk6IHVuaXQub3JkZXIubGVhc2hZIH07XG4gIGlmICh1bml0LmhvbWVYICE9PSB1bmRlZmluZWQgJiYgdW5pdC5ob21lWSAhPT0gdW5kZWZpbmVkKSByZXR1cm4geyB4OiB1bml0LmhvbWVYLCB5OiB1bml0LmhvbWVZIH07XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIG5ldXRyYWxIb21lT3JDdXJyZW50UG9pbnQodW5pdDogVW5pdCkge1xuICByZXR1cm4gdW5pdC5ob21lWCAhPT0gdW5kZWZpbmVkICYmIHVuaXQuaG9tZVkgIT09IHVuZGVmaW5lZCA/IHsgeDogdW5pdC5ob21lWCwgeTogdW5pdC5ob21lWSB9IDogeyB4OiB1bml0LngsIHk6IHVuaXQueSB9O1xufVxuXG5mdW5jdGlvbiByZWNvcmRLaWxsKGdhbWU6IEdhbWUsIGF0dGFja2VyOiBVbml0IHwgQnVpbGRpbmcsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nKSB7XG4gIC8vIFRob3NlIGFib2FyZCBhIHN1bmsgdHJhbnNwb3J0IGRyb3duIHdpdGggaXQsIGF0IHRoZSBoYW5kIHRoYXQgc2FuayBpdCAoc2VlIEBAQHRyYW5zcG9ydCkuXG4gIGlmKGlzVW5pdCh0YXJnZXQpICYmIHNoaXBQcm9maWxlKHRhcmdldCkpZm9yKGNvbnN0IHBhc3NlbmdlciBvZiBzaGlwUGFzc2VuZ2VycyhnYW1lLnVuaXRzLHRhcmdldCkpe2lmKHBhc3Nlbmdlci5ocD4wKXtwYXNzZW5nZXIuaHA9MDtyZWNvcmRLaWxsKGdhbWUsYXR0YWNrZXIscGFzc2VuZ2VyKTt9fVxuICAvLyBBIHdyZWNrIG9yIGZyaWVuZGx5IGltcGFjdCBjYXVzZXMgbG9zc2VzLCBidXQgbmV2ZXIgZ3JhbnRzIGl0cyBvd24gY3Jld1xuICAvLyBraWxscywgZXhwZXJpZW5jZSBvciBhIGJvdW50eSBmb3IgY3Jhc2hpbmcuXG4gIGlmKCFhcmVFbmVteU93bmVycyhnYW1lLGF0dGFja2VyLm93bmVyLHRhcmdldC5vd25lcikpcmV0dXJuO1xuICBjb25zdCBhdHRhY2tlck93bmVyID0gYXR0YWNrZXIub3duZXI7XG4gIGlmIChpc1BsYXllcklkKGF0dGFja2VyT3duZXIpIHx8IGF0dGFja2VyT3duZXIgPT09IFwibmV1dHJhbFwiKSB7XG4gICAgaW5jcmVtZW50U3RhdChnYW1lLm1hdGNoLnN0YXRzLnVuaXRzS2lsbGVkLCBhdHRhY2tlck93bmVyLCBpc1VuaXQodGFyZ2V0KSA/IDEgOiAwKTtcbiAgfVxuICBpZiAoaXNVbml0KGF0dGFja2VyKSAmJiBpc1VuaXQodGFyZ2V0KSkge1xuICAgIGF0dGFja2VyLmtpbGxzICs9IDE7XG4gICAgYXdhcmRLaWxsWHAoZ2FtZSwgYXR0YWNrZXIsIHRhcmdldCk7XG4gICAgaWYgKGF0dGFja2VyLm93bmVyID09PSBcIm5ldXRyYWxcIiAmJiBpc1BsYXllcklkKHRhcmdldC5vd25lcikpIHtcbiAgICAgIGluY3JlbWVudFN0YXQoZ2FtZS5tYXRjaC5zdGF0cy51bml0c0tpbGxlZEJ5TmV1dHJhbCwgdGFyZ2V0Lm93bmVyLCAxKTtcbiAgICB9XG4gICAgaWYgKGlzUGxheWVySWQoYXR0YWNrZXIub3duZXIpICYmIGlzTWVyY2VuYXJ5VW5pdEtpbmQoYXR0YWNrZXIua2luZCkgJiYgYXJlRW5lbXlPd25lcnMoZ2FtZSwgYXR0YWNrZXIub3duZXIsIHRhcmdldC5vd25lcikpIHtcbiAgICAgIGluY3JlbWVudFN0YXQoZ2FtZS5tYXRjaC5zdGF0cy5tZXJjZW5hcnlLaWxscywgYXR0YWNrZXIub3duZXIsIDEpO1xuICAgIH1cbiAgfVxuICBpZiAoaXNVbml0KHRhcmdldCkgJiYgdGFyZ2V0Lm93bmVyID09PSBcIm5ldXRyYWxcIiAmJiBpc1BsYXllcklkKGF0dGFja2VyT3duZXIpKSB7XG4gICAgaW5jcmVtZW50U3RhdChnYW1lLm1hdGNoLnN0YXRzLm5ldXRyYWxVbml0c0tpbGxlZCwgYXR0YWNrZXJPd25lciwgMSk7XG4gICAgYXdhcmROZXV0cmFsR29sZEJvdW50eShnYW1lLCBhdHRhY2tlck93bmVyLCB0YXJnZXQpO1xuICB9XG4gIGlmICghaXNVbml0KHRhcmdldCkgJiYgaXNQbGF5ZXJJZChhdHRhY2tlck93bmVyKSkge1xuICAgIGluY3JlbWVudFN0YXQoZ2FtZS5tYXRjaC5zdGF0cy5idWlsZGluZ3NEZXN0cm95ZWQsIGF0dGFja2VyT3duZXIsIDEpO1xuICAgIGlmICh0YXJnZXQua2luZCAhPT0gXCJ0b3duSGFsbFwiKSBpbmNyZW1lbnRTdGF0KGdhbWUubWF0Y2guc3RhdHMubm9uQmFzZUJ1aWxkaW5nc0Rlc3Ryb3llZCwgYXR0YWNrZXJPd25lciwgMSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gYWRkRWZmZWN0KFxuICBnYW1lOiBHYW1lLFxuICB0eXBlOiBXb3JsZEVmZmVjdFtcInR5cGVcIl0sXG4gIHg6IG51bWJlcixcbiAgeTogbnVtYmVyLFxuICByZW1haW5pbmc6IG51bWJlcixcbiAgdmVjdG9ycz86IFBhcnRpYWw8UGljazxXb3JsZEVmZmVjdCwgXCJmcm9tWFwiIHwgXCJmcm9tWVwiIHwgXCJmcm9tSGVpZ2h0XCIgfCBcInRvWFwiIHwgXCJ0b1lcIiB8IFwidG9IZWlnaHRcIiB8IFwib3duZXJcIiB8IFwiZGFtYWdlXCIgfCBcImRhbWFnZVByb2ZpbGVcIiB8IFwicmFkaXVzXCIgfCBcInRpY2tFdmVyeVwiIHwgXCJzb3VyY2VLaW5kXCIgfCBcInVuaXRJZFwiIHwgXCJpdGVtSWRcIiB8IFwiYW1vdW50XCIgfCBcImF0dGFja0tpbmRcIiB8IFwidGFyZ2V0S2luZFwiIHwgXCJ0YXJnZXRIcEFmdGVyXCIgfCBcInRhcmdldE1heEhwXCIgfCBcInRhcmdldFJhZGl1c1wiIHwgXCJ0YXJnZXRVbml0Q2xhc3NcIiB8IFwidGFyZ2V0RGVja1wiIHwgXCJzb3VyY2VJZFwiIHwgXCJhY3Rpb25Nb2RlXCIgfCBcImFjdGlvblRvWFwiIHwgXCJhY3Rpb25Ub1lcIj4+LFxuKSB7XG4gIGdhbWUuZWZmZWN0cy5wdXNoKHsgaWQ6IGBlZmZlY3QtJHtnYW1lLm5leHRJZH1gLCB0eXBlLCB4LCB5LCByZW1haW5pbmcsIGR1cmF0aW9uOiByZW1haW5pbmcsIC4uLnZlY3RvcnMsIC4uLih2ZWN0b3JzPy5hY3Rpb25Nb2RlP3thY3Rpb25UaWNrOmdhbWUudGlja306e30pIH0pO1xuICBnYW1lLm5leHRJZCArPSAxO1xufVxuXG5mdW5jdGlvbiBpc1VuaXQoZW50aXR5OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSk6IGVudGl0eSBpcyBVbml0IHtcbiAgcmV0dXJuIFwib3JkZXJcIiBpbiBlbnRpdHk7XG59XG5cbmZ1bmN0aW9uIGlzT2JzdGFjbGUoZW50aXR5OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSk6IGVudGl0eSBpcyBPYnN0YWNsZSB7XG4gIHJldHVybiBcImFsb25nXCIgaW4gZW50aXR5O1xufVxuXG5mdW5jdGlvbiBhd2FyZEtpbGxYcChnYW1lOiBHYW1lLCBhdHRhY2tlcjogVW5pdCwgdGFyZ2V0OiBVbml0KSB7XG4gIGlmIChhdHRhY2tlci5vd25lciA9PT0gXCJuZXV0cmFsXCIgfHwgIWFyZUVuZW15T3duZXJzKGdhbWUsIGF0dGFja2VyLm93bmVyLCB0YXJnZXQub3duZXIpKSByZXR1cm47XG4gIGF0dGFja2VyLnhwICs9IGtpbGxYcFJld2FyZCh1bml0UnVsZXMoZ2FtZSwgdGFyZ2V0KSwgdGFyZ2V0LmxldmVsKTtcbiAgYXBwbHlYcExldmVsKGdhbWUsIGF0dGFja2VyKTtcbn1cblxuZnVuY3Rpb24gYXdhcmROZXV0cmFsR29sZEJvdW50eShnYW1lOiBHYW1lLCBvd25lcjogUGxheWVySWQsIHRhcmdldDogVW5pdCkge1xuICBjb25zdCBib3VudHkgPSB1bml0UnVsZXMoZ2FtZSwgdGFyZ2V0KS5nb2xkQm91bnR5ID8/IDA7XG4gIGlmIChib3VudHkgPD0gMCkgcmV0dXJuO1xuICBwbGF5ZXJTdGF0ZShnYW1lLCBvd25lcikuZ29sZCA9IGFkZEdvbGQocGxheWVyU3RhdGUoZ2FtZSwgb3duZXIpLmdvbGQsIGJvdW50eSk7XG4gIGFkZEVmZmVjdChnYW1lLCBcImdvbGRCb3VudHlcIiwgdGFyZ2V0LngsIHRhcmdldC55LCBzZWNvbmRzKDEuMiksIHsgb3duZXIsIGFtb3VudDogYm91bnR5IH0pO1xufVxuXG5mdW5jdGlvbiBhcHBseVhwTGV2ZWwoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCkge1xuICBpZiAodW5pdC52YXJpYW50ICE9PSB1bmRlZmluZWQgJiYgZ2FtZS52YXJpYW50cz8uW3VuaXQudmFyaWFudF0/Lmhlcm9pYykgcmV0dXJuO1xuICBjb25zdCBuZXh0TGV2ZWwgPSB4cFN0YXJUaHJlc2hvbGRzKHVuaXRSdWxlcyhnYW1lLCB1bml0KSkuZmlsdGVyKHRocmVzaG9sZCA9PiB1bml0LnhwID49IHRocmVzaG9sZCkubGVuZ3RoO1xuICBpZiAobmV4dExldmVsIDw9IHVuaXQubGV2ZWwpIHJldHVybjtcbiAgdW5pdC5sZXZlbCA9IE1hdGgubWluKE1BWF9VUEdSQURFX0xFVkVMLCBuZXh0TGV2ZWwpO1xuICBpZiAodW5pdC5sZXZlbCA9PT0gMyAmJiB1bml0Lm93bmVyICE9PSBcIm5ldXRyYWxcIiAmJiB1bml0LmV4cGlyZXNUaWNrID09PSB1bmRlZmluZWQgJiYgIXVuaXQudmV0ZXJhblNraWxsQ2hvaWNlcykge1xuICAgIHVuaXQudmV0ZXJhblNraWxsQ2hvaWNlcyA9IHJvbGxWZXRlcmFuU2tpbGxDaG9pY2VzKHVuaXQua2luZCwgdW5pdC5pZCwgYCR7Z2FtZS5tYXAudGVycmFpbj8uZWNvbG9neT8uc2VlZCA/PyBnYW1lLm1hcC5pZH06JHtnYW1lLnRpY2t9YCwgdW5pdENsYXNzT2YodW5pdCwgZ2FtZSkpO1xuICB9XG4gIGFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLCB1bml0KTtcbn1cblxuZnVuY3Rpb24gYXBwbHlEZXJpdmVkVW5pdFN0YXRzKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQpIHtcbiAgY29uc3QgcHJldmlvdXNNYXhIcCA9IHVuaXQubWF4SHA7XG4gIGNvbnN0IGJhc2UgPSBub25TdGFyVW5pdFN0YXRzKGdhbWUsIHVuaXQpO1xuICBjb25zdCBtdWx0aXBsaWVyID0gMSArIE1hdGgubWluKE1BWF9VUEdSQURFX0xFVkVMLCBNYXRoLm1heCgwLCB1bml0LmxldmVsKSkgKiBWRVRFUkFOQ1lfR0FJTl9QRVJfU1RBUjtcbiAgY29uc3QgaGVhdnk9aXRlbXNGb3IoZ2FtZSx1bml0KS5zb21lKGl0ZW09PklURU1fREVGU1tpdGVtLmtpbmRdLnNwYW49PT00KTtcbiAgdW5pdC5ib2R5UmFkaXVzPXVuaXRSdWxlcyhnYW1lLHVuaXQpLnJhZGl1cyooaXNTaGlwS2luZCh1bml0LmtpbmQpP1NISVBfU0laRV9NVUxUSVBMSUVSOjEpO3VuaXQucmFkaXVzPXVuaXQuYm9keVJhZGl1cztcbiAgY29uc3QgdmV0ZXJhbnMgPSBnYW1lLnZldGVyYW5GcmFtZT8uZ2V0KHVuaXQuaWQpO1xuICB1bml0LmF0dGFja0RhbWFnZSA9IE1hdGgucm91bmQoYmFzZS5hdHRhY2tEYW1hZ2UpO1xuICB1bml0Lm1heEhwID0gTWF0aC5yb3VuZChiYXNlLm1heEhwICogbXVsdGlwbGllcik7XG4gIHVuaXQuc3BlZWQgPSBiYXNlLnNwZWVkICogKGhlYXZ5ID8gLjQ1IDogMSkgKiAodmV0ZXJhbnM/Lm1vdmVTcGVlZE11bHRpcGxpZXIgPz8gMSk7XG4gIHVuaXQuYXR0YWNrUmFuZ2UgPSBiYXNlLmF0dGFja1JhbmdlICogKHZldGVyYW5zPy5hdHRhY2tSYW5nZU11bHRpcGxpZXIgPz8gMSk7XG4gIHVuaXQuaHAgPSBNYXRoLm1pbih1bml0Lm1heEhwLCBNYXRoLm1heCgxLCB1bml0LmhwICsgdW5pdC5tYXhIcCAtIHByZXZpb3VzTWF4SHApKTtcbn1cblxuZnVuY3Rpb24gbm9uU3RhclVuaXRTdGF0cyhnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGNvbnN0IHN0YXRzID0gd2VhcG9uUnVsZXMoZ2FtZSwgdW5pdCk7XG4gIHVuaXQuYXR0YWNrQ29vbGRvd249c3RhdHMuYXR0YWNrQ29vbGRvd247XG4gIGxldCBhdHRhY2tEYW1hZ2UgPSBzdGF0cy5hdHRhY2tEYW1hZ2U7XG4gIGxldCBtYXhIcCA9IHN0YXRzLmhwO1xuICBsZXQgc3BlZWQgPSBzdGF0cy5zcGVlZDtcbiAgbGV0IGF0dGFja1JhbmdlID0gc3RhdHMuYXR0YWNrUmFuZ2U7XG4gIGlmICghaXNQbGF5ZXJJZCh1bml0Lm93bmVyKSkgcmV0dXJuIHsgYXR0YWNrRGFtYWdlLCBtYXhIcCwgc3BlZWQsIGF0dGFja1JhbmdlIH07XG4gIGNvbnN0IHVwZ3JhZGVzID0gcGxheWVyU3RhdGUoZ2FtZSwgdW5pdC5vd25lcikudXBncmFkZXM7XG4gIGZvciAoY29uc3QgdXBncmFkZUtpbmQgb2YgVVBHUkFERV9LSU5EUykge1xuICAgIGNvbnN0IHVwZ3JhZGUgPSBVUEdSQURFX0RFRlNbdXBncmFkZUtpbmRdO1xuICAgIGlmICghdXBncmFkZS5hZmZlY3RlZFVuaXRLaW5kcy5pbmNsdWRlcyh1bml0LmtpbmQgYXMgVHJhaW5hYmxlVW5pdEtpbmQpKSBjb250aW51ZTtcbiAgICBmb3IgKGxldCBsZXZlbCA9IDA7IGxldmVsIDwgKHVwZ3JhZGVzW3VwZ3JhZGVLaW5kXSA/PyAwKTsgbGV2ZWwgKz0gMSkge1xuICAgICAgY29uc3QgbGV2ZWxEZWYgPSB1cGdyYWRlLmxldmVsc1tsZXZlbF07XG4gICAgICBpZiAoIWxldmVsRGVmKSB0aHJvdyBuZXcgRXJyb3IoYCR7dXBncmFkZUtpbmR9IG1pc3NpbmcgbGV2ZWwgJHtsZXZlbCArIDF9YCk7XG4gICAgICBpZiAobGV2ZWxEZWYuYXR0YWNrTXVsdGlwbGllcikgYXR0YWNrRGFtYWdlID0gc3RhdHMuYXR0YWNrRGFtYWdlICogbGV2ZWxEZWYuYXR0YWNrTXVsdGlwbGllcjtcbiAgICAgIGlmIChsZXZlbERlZi5tYXhIcE11bHRpcGxpZXIpIG1heEhwID0gc3RhdHMuaHAgKiBsZXZlbERlZi5tYXhIcE11bHRpcGxpZXI7XG4gICAgICBpZiAobGV2ZWxEZWYuc3BlZWRNdWx0aXBsaWVyKSBzcGVlZCA9IHJvdW5kVW5pdFNjYWxhcihzdGF0cy5zcGVlZCAqIGxldmVsRGVmLnNwZWVkTXVsdGlwbGllcik7XG4gICAgICBpZiAobGV2ZWxEZWYuYXR0YWNrUmFuZ2VNdWx0aXBsaWVyKSBhdHRhY2tSYW5nZSA9IE1hdGgucm91bmQoc3RhdHMuYXR0YWNrUmFuZ2UgKiBsZXZlbERlZi5hdHRhY2tSYW5nZU11bHRpcGxpZXIpO1xuICAgIH1cbiAgfVxuICBpZiAoaXRlbXNGb3IoZ2FtZSx1bml0KS5zb21lKChpdGVtKSA9PiBpdGVtLmtpbmQgPT09IFwic3BlZWRCb290c1wiICYmIGl0ZW1FcXVpcHBlZChnYW1lLHVuaXQsaXRlbSkpKSBzcGVlZCA9IHJvdW5kVW5pdFNjYWxhcihzcGVlZCAqIEJPT1RTX1NQRUVEKTtcbiAgcmV0dXJuIHsgYXR0YWNrRGFtYWdlLCBtYXhIcCwgc3BlZWQsIGF0dGFja1JhbmdlIH07XG59XG5cbmZ1bmN0aW9uIHJvdW5kVW5pdFNjYWxhcih2YWx1ZTogbnVtYmVyKSB7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogMTAwKSAvIDEwMDtcbn1cblxuZnVuY3Rpb24gdXBkYXRlU3VwcGx5U3RhdGUoZ2FtZTogR2FtZSkge1xuICBmb3IgKGNvbnN0IG93bmVyIG9mIGdhbWUuYWN0aXZlUGxheWVycykge1xuICAgIGNvbnN0IHBsYXllciA9IHBsYXllclN0YXRlKGdhbWUsIG93bmVyKTtcbiAgICBwbGF5ZXIuc3VwcGx5Q2FwID0gZ2FtZS5idWlsZGluZ3NcbiAgICAgIC5maWx0ZXIoKGJ1aWxkaW5nKSA9PiBidWlsZGluZy5vd25lciA9PT0gb3duZXIgJiYgYnVpbGRpbmcuY29tcGxldGUpXG4gICAgICAucmVkdWNlKCh0b3RhbCwgYnVpbGRpbmcpID0+IHRvdGFsICsgQlVJTERJTkdfREVGU1tidWlsZGluZy5raW5kXS5zdXBwbHlQcm92aWRlZCwgMCk7XG4gICAgcGxheWVyLnN1cHBseVVzZWQgPSBwcm9qZWN0ZWRTdXBwbHlVc2VkKGdhbWUsIG93bmVyKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBwcm9qZWN0ZWRTdXBwbHlVc2VkKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCkge1xuICBjb25zdCB1bml0U3VwcGx5ID0gZ2FtZS51bml0c1xuICAgIC5maWx0ZXIoKHVuaXQpID0+IHVuaXQub3duZXIgPT09IG93bmVyKVxuICAgIC5yZWR1Y2UoKHRvdGFsLCB1bml0KSA9PiB0b3RhbCArIHVuaXRSdWxlcyhnYW1lLCB1bml0KS5zdXBwbHlVc2VkICsgKHVuaXQuY2FyZ28gPyBjYXJnb1N1cHBseShnYW1lLCB1bml0KSA6IDApLCAwKTtcbiAgY29uc3QgcXVldWVkU3VwcGx5ID0gZ2FtZS5idWlsZGluZ3NcbiAgICAuZmlsdGVyKChidWlsZGluZykgPT4gYnVpbGRpbmcub3duZXIgPT09IG93bmVyKVxuICAgIC5mbGF0TWFwKChidWlsZGluZykgPT4gYnVpbGRpbmcucXVldWUpXG4gICAgLnJlZHVjZSgodG90YWwsIGpvYikgPT4gdG90YWwgKyBVTklUX0RFRlNbam9iLnVuaXRLaW5kXS5zdXBwbHlVc2VkLCAwKTtcbiAgcmV0dXJuIHVuaXRTdXBwbHkgKyBxdWV1ZWRTdXBwbHk7XG59XG5cbmZ1bmN0aW9uIHVuaXRzQnlJZHMoZ2FtZTogR2FtZSwgdW5pdElkczogc3RyaW5nW10sIG93bmVyOiBQbGF5ZXJJZCkge1xuICBjb25zdCB1bml0ID0gb3duVW5pdExvb2t1cChnYW1lLnVuaXRzLCBvd25lciwgdW5pdElkcy5sZW5ndGgpO1xuICBjb25zdCB1bml0cyA9IHVuaXRJZHMubWFwKChpZCkgPT4gdW5pdChpZCkpO1xuICBjb25zdCBtaXNzaW5nID0gdW5pdHMuZmluZEluZGV4KCh1bml0KSA9PiAhdW5pdCk7XG4gIGlmIChtaXNzaW5nID49IDApIHRocm93IG5ldyBFcnJvcihgVW5rbm93biAke293bmVyfSB1bml0ICR7dW5pdElkc1ttaXNzaW5nXX1gKTtcbiAgcmV0dXJuIHVuaXRzIGFzIFVuaXRbXTtcbn1cblxuZnVuY3Rpb24gYnVpbGRpbmdzQnlJZHMoZ2FtZTogR2FtZSwgYnVpbGRpbmdJZHM6IHN0cmluZ1tdLCBvd25lcjogUGxheWVySWQpIHtcbiAgY29uc3QgYnVpbGRpbmdzID0gYnVpbGRpbmdJZHMubWFwKChpZCkgPT4gZ2FtZS5idWlsZGluZ3MuZmluZCgoYnVpbGRpbmcpID0+IGJ1aWxkaW5nLmlkID09PSBpZCAmJiBidWlsZGluZy5vd25lciA9PT0gb3duZXIpKTtcbiAgY29uc3QgbWlzc2luZyA9IGJ1aWxkaW5ncy5maW5kSW5kZXgoKGJ1aWxkaW5nKSA9PiAhYnVpbGRpbmcpO1xuICBpZiAobWlzc2luZyA+PSAwKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gJHtvd25lcn0gYnVpbGRpbmcgJHtidWlsZGluZ0lkc1ttaXNzaW5nXX1gKTtcbiAgcmV0dXJuIGJ1aWxkaW5ncyBhcyBCdWlsZGluZ1tdO1xufVxuXG5mdW5jdGlvbiBzcGVuZEdvbGQoZ2FtZTogR2FtZSwgb3duZXI6IFBsYXllcklkLCBhbW91bnQ6IG51bWJlcikge1xuICBzcGVuZChwbGF5ZXJTdGF0ZShnYW1lLCBvd25lciksIGFtb3VudCk7XG4gIGluY3JlbWVudFN0YXQoZ2FtZS5tYXRjaC5zdGF0cy5nb2xkU3BlbnQsIG93bmVyLCBhbW91bnQpO1xufVxuXG5mdW5jdGlvbiBzcGVuZChwbGF5ZXI6IFBsYXllclN0YXRlLCBhbW91bnQ6IG51bWJlcikge1xuICBpZiAocGxheWVyLmdvbGQgPCBhbW91bnQpIHRocm93IG5ldyBFcnJvcihgTmVlZCAke2Ftb3VudH0gZ29sZGApO1xuICBwbGF5ZXIuZ29sZCA9IGFkZEdvbGQocGxheWVyLmdvbGQsIC1hbW91bnQpO1xufVxuXG5mdW5jdGlvbiBwbGF5ZXJTdGF0ZShnYW1lOiBHYW1lLCBvd25lcjogUGxheWVySWQpIHtcbiAgY29uc3QgcGxheWVyID0gZ2FtZS5wbGF5ZXJzW293bmVyXTtcbiAgaWYgKCFwbGF5ZXIpIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBwbGF5ZXIgJHtvd25lcn1gKTtcbiAgcmV0dXJuIHBsYXllcjtcbn1cblxuZnVuY3Rpb24gaW5jcmVtZW50U3RhdChyZWNvcmQ6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4sIG93bmVyOiBPd25lciwgYW1vdW50OiBudW1iZXIpIHtcbiAgcmVjb3JkW293bmVyXSA9IChyZWNvcmRbb3duZXJdID8/IDApICsgYW1vdW50O1xufVxuXG5mdW5jdGlvbiBjYW5TdXBwbHkoZ2FtZTogR2FtZSwgb3duZXI6IFBsYXllcklkLCB1bml0S2luZDogVW5pdEtpbmQpIHtcbiAgcmV0dXJuIHByb2plY3RlZFN1cHBseVVzZWQoZ2FtZSwgb3duZXIpICsgVU5JVF9ERUZTW3VuaXRLaW5kXS5zdXBwbHlVc2VkIDw9IHBsYXllclN0YXRlKGdhbWUsIG93bmVyKS5zdXBwbHlDYXA7XG59XG5cbmZ1bmN0aW9uIGlzTWVyY2VuYXJ5VW5pdEtpbmQoa2luZDogVW5pdFtcImtpbmRcIl0pIHtcbiAgcmV0dXJuIChNRVJDRU5BUllfVU5JVF9LSU5EUyBhcyByZWFkb25seSBzdHJpbmdbXSkuaW5jbHVkZXMoa2luZCk7XG59XG5cbmZ1bmN0aW9uIGNvbWJhdFVuaXRzKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCkge1xuICByZXR1cm4gZ2FtZS51bml0cy5maWx0ZXIoKHVuaXQpID0+IHVuaXQub3duZXIgPT09IG93bmVyICYmIHVuaXQua2luZCAhPT0gXCJ3b3JrZXJcIik7XG59XG5cbmZ1bmN0aW9uIGNvbXBsZXRlQnVpbGRpbmdzKGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwga2luZDogQnVpbGRpbmdbXCJraW5kXCJdKSB7XG4gIHJldHVybiBnYW1lLmJ1aWxkaW5ncy5maWx0ZXIoKGJ1aWxkaW5nKSA9PiBidWlsZGluZy5vd25lciA9PT0gb3duZXIgJiYgYnVpbGRpbmcua2luZCA9PT0ga2luZCAmJiBidWlsZGluZy5jb21wbGV0ZSk7XG59XG5cbmZ1bmN0aW9uIG5lYXJlc3RDb21wbGV0ZVRvd25IYWxsKGdhbWU6IEdhbWUsIG93bmVyOiBVbml0W1wib3duZXJcIl0sIHg6IG51bWJlciwgeTogbnVtYmVyKSB7XG4gIGlmICghaXNQbGF5ZXJJZChvd25lcikpIHJldHVybiB1bmRlZmluZWQ7XG4gIHJldHVybiAoZ2FtZS5taW5pbmdGcmFtZT8udG93bkhhbGxzLmdldChvd25lcikgPz8gY29tcGxldGVCdWlsZGluZ3MoZ2FtZSwgb3duZXIsIFwidG93bkhhbGxcIikpLmZpbHRlcihidWlsZGluZyA9PiBzYW1lR3JvdW5kKGdhbWUubWFwLCB7IHgsIHkgfSwgYnVpbGRpbmcpKS5yZWR1Y2U8QnVpbGRpbmcgfCB1bmRlZmluZWQ+KChiZXN0LCBidWlsZGluZykgPT4ge1xuICAgIGlmICghYmVzdCkgcmV0dXJuIGJ1aWxkaW5nO1xuICAgIHJldHVybiBkaXN0YW5jZSh7IHgsIHkgfSwgYnVpbGRpbmcpIDwgZGlzdGFuY2UoeyB4LCB5IH0sIGJlc3QpID8gYnVpbGRpbmcgOiBiZXN0O1xuICB9LCB1bmRlZmluZWQpO1xufVxuXG4vLyBUaGUgZmlyc3QgZW5lbXkgaW4gcmFuZ2UgaW4gdGhlIHNwYXRpYWwgaW5kZXgncyBvcmRlciAobm90IHRoZSBuZWFyZXN0LCBkZXNwaXRlIHRoZSBuYW1lKS5cbmZ1bmN0aW9uIG5lYXJlc3RFbmVteUluUmFuZ2UoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgcmFuZ2U6IG51bWJlcikge1xuICBjb25zdCBsaW1pdCA9IHJhbmdlICogcmFuZ2U7XG4gIHJldHVybiBmaXJzdE5lYXJieVVuaXQoZ2FtZSwgdW5pdCwgcmFuZ2UsIChjYW5kaWRhdGUpID0+IGFyZUVuZW15T3duZXJzKGdhbWUsIHVuaXQub3duZXIsIGNhbmRpZGF0ZS5vd25lcikgJiYgZGlzdGFuY2VTcXVhcmVkKHVuaXQsIGNhbmRpZGF0ZSkgPD0gbGltaXQpO1xufVxuXG5mdW5jdGlvbiBuZWFyZXN0RW5lbXlVbml0KGdhbWU6IEdhbWUsIG93bmVyOiBQbGF5ZXJJZCwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHJhbmdlOiBudW1iZXIpIHtcbiAgY29uc3QgcG9pbnQgPSB7IHgsIHkgfTtcbiAgY29uc3QgbGltaXQgPSByYW5nZSAqIHJhbmdlO1xuICBsZXQgYmVzdDogVW5pdCB8IHVuZGVmaW5lZDtcbiAgbGV0IGJlc3RTY29yZSA9IE51bWJlci5ORUdBVElWRV9JTkZJTklUWTtcbiAgZm9yRWFjaE5lYXJieUVuZW15VW5pdChnYW1lLCBvd25lciwgcG9pbnQsIHJhbmdlLCAodW5pdCkgPT4ge1xuICAgIGlmIChpc0luQ2FiaW4odW5pdCkpIHJldHVybjtcbiAgICBjb25zdCBjYW5kaWRhdGVEaXN0YW5jZSA9IGRpc3RhbmNlU3F1YXJlZCh1bml0LCBwb2ludCk7XG4gICAgaWYgKGNhbmRpZGF0ZURpc3RhbmNlID4gbGltaXQpIHJldHVybjtcbiAgICBjb25zdCBzY29yZSA9IHRhcmdldFByaW9yaXR5U2NvcmUoZ2FtZSwgb3duZXIsIHVuaXQsIGNhbmRpZGF0ZURpc3RhbmNlKTtcbiAgICBpZiAoc2NvcmUgPD0gYmVzdFNjb3JlKSByZXR1cm47XG4gICAgYmVzdCA9IHVuaXQ7XG4gICAgYmVzdFNjb3JlID0gc2NvcmU7XG4gIH0pO1xuICByZXR1cm4gYmVzdDtcbn1cblxuLy8gVGhlIGJlc3QgZW5lbXkgZm9yIGEgdW5pdCB0byBzdHJpa2Ugd2l0aGluIHRoZSByYW5nZTogbm9uZSBmb3IgYSB1bml0IHdpdGhvdXQgYSB3ZWFwb24sIGFuZCBvbmx5IHdoYXQgaXQgY2FuIHJlYWNoXG4vLyAoc2VlIEBAQHJlYWNoKS5cbmZ1bmN0aW9uIG5lYXJlc3RFbmVteVRhcmdldChnYW1lOiBHYW1lLCB1bml0OiBVbml0LCByYW5nZTogbnVtYmVyLCBuYXZhbEZyYW1lID0gdHJ1ZSk6IFVuaXQgfCBCdWlsZGluZyB8IHVuZGVmaW5lZCB7XG4gIGlmICh1bml0LmF0dGFja0RhbWFnZSA8PSAwKSByZXR1cm4gdW5kZWZpbmVkO1xuICByZXR1cm4gbmVhcmVzdEVuZW15VGFyZ2V0RnJvbVBvaW50KGdhbWUsIHVuaXQub3duZXIsIHVuaXQsIHJhbmdlLCB1bml0LCB1bmRlZmluZWQsIG5hdmFsRnJhbWUpO1xufVxuXG4vLyBAQEBidWlsZGluZy1yZWFjaCAtIEJ1aWxkaW5ncyBhbmQgc2hpcHMgYXJlIHJlYWNoZWQgYXQgdGhlaXIgZWRnZXMsIG90aGVyIHVuaXRzIGF0IHRoZWlyIGNlbnRlcnM6IGEgZm9vdG1hbidzIDQ4IHJlYWNoZXMgYVxuLy8gdG93biBoYWxsJ3Mgd2FsbCwgNDggZnJvbSBhIGNlbnRlciA2NiBhd2F5LiBXaGlsZSB1bml0cyBjb3VsZCB3YWxrIGludG8gYSBidWlsZGluZyB0aGV5IHN0cnVjayBpdCBmcm9tIGluc2lkZS5cbmZ1bmN0aW9uIHRhcmdldEdhcChmcm9tOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0sIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nIHwgT2JzdGFjbGUsIG5hdmFsRnJhbWUgPSB0cnVlKSB7XG4gIGlmICghbmF2YWxGcmFtZSAmJiBpc1VuaXQodGFyZ2V0KSkgcmV0dXJuIGh5cG90Mih0YXJnZXQueCAtIGZyb20ueCwgdGFyZ2V0LnkgLSBmcm9tLnkpO1xuICByZXR1cm4gc3RyaWtlR2FwKGZyb20sdGFyZ2V0KTtcbn1cblxuZnVuY3Rpb24gbmVhcmVzdEVuZW15VGFyZ2V0RnJvbVBvaW50KGdhbWU6IEdhbWUsIG93bmVyOiBPd25lciwgcG9pbnQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSwgcmFuZ2U6IG51bWJlciwgYXR0YWNrZXI/OiBVbml0LCBhY2NlcHRzPzogKHRhcmdldDpVbml0fEJ1aWxkaW5nKT0+Ym9vbGVhbiwgbmF2YWxGcmFtZSA9IHRydWUpOiBVbml0IHwgQnVpbGRpbmcgfCB1bmRlZmluZWQge1xuICBjb25zdCBsaW1pdCA9IHJhbmdlICogcmFuZ2U7XG4gIGxldCBiZXN0OiBVbml0IHwgQnVpbGRpbmcgfCB1bmRlZmluZWQ7XG4gIGxldCBiZXN0U2NvcmUgPSBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFk7XG4gIC8vIE9ubHkgdGhlIG5hdGl2ZSBmcmFtZSBjZXJ0aWZpY2F0ZSBzdXBwbGllcyBmYWxzZS4gQmlydGhzLCBjYWJpbnMsIGh1bGxzLFxuICAvLyBvYnNlcnZlcnMgYW5kIGN1c3RvbSBmYWN0b3JpZXMgcmV0YWluIHRoZSBjb21wbGV0ZSB0YXJnZXQgcnVsZXMuXG4gIGZvckVhY2hOZWFyYnlFbmVteVVuaXQoZ2FtZSwgb3duZXIsIHBvaW50LCByYW5nZSArIChuYXZhbEZyYW1lID8gZ2FtZS5zaGlwUmVhY2hQYWRkaW5nID8/IHNoaXBSZWFjaFBhZGRpbmcoZ2FtZS51bml0cykgOiAwKSwgKGNhbmRpZGF0ZSkgPT4ge1xuICAgIGlmIChuYXZhbEZyYW1lICYmIGlzSW5DYWJpbihjYW5kaWRhdGUpKSByZXR1cm47XG4gICAgaWYobmF2YWxGcmFtZSAmJiAhYXV0b21hdGljVGFyZ2V0QWxsb3dlZChnYW1lLnVuaXRzLG93bmVyLGNhbmRpZGF0ZSkpcmV0dXJuO1xuICAgIGlmIChuYXZhbEZyYW1lICYmIHNoaXBQcm9maWxlKGNhbmRpZGF0ZSkgJiYgc2hpcFBhc3NlbmdlcnMoZ2FtZS51bml0cywgY2FuZGlkYXRlKS5zb21lKHVuaXQgPT4gdW5pdC5ocCA+IDAgJiYgIWlzSW5DYWJpbih1bml0KSAmJiAoIWF0dGFja2VyIHx8IGNhblJlYWNoKGdhbWUubWFwLCBhdHRhY2tlciwgdW5pdCwgZ2FtZS51bml0cykpKSkgcmV0dXJuO1xuICAgIGlmKGFjY2VwdHMgJiYgIWFjY2VwdHMoY2FuZGlkYXRlKSlyZXR1cm47XG4gICAgY29uc3QgY2FuZGlkYXRlRGlzdGFuY2UgPSBuYXZhbEZyYW1lICYmIGlzU2hpcEtpbmQoY2FuZGlkYXRlLmtpbmQpID8gZGlzdGFuY2VUb0h1bGwoY2FuZGlkYXRlLCBwb2ludCkgKiogMiA6IGRpc3RhbmNlU3F1YXJlZChwb2ludCwgY2FuZGlkYXRlKTtcbiAgICBpZiAoY2FuZGlkYXRlRGlzdGFuY2UgPiBsaW1pdCkgcmV0dXJuO1xuICAgIGlmIChhdHRhY2tlciAmJiAhYXV0b21hdGljQ2FuZGlkYXRlUmVhY2hhYmxlKGdhbWUsIGF0dGFja2VyLCBjYW5kaWRhdGUsIG5hdmFsRnJhbWUpKSByZXR1cm47XG4gICAgY29uc3Qgc2NvcmUgPSB0YXJnZXRQcmlvcml0eVNjb3JlKGdhbWUsIG93bmVyLCBjYW5kaWRhdGUsIGNhbmRpZGF0ZURpc3RhbmNlLCBhdHRhY2tlcik7XG4gICAgaWYgKHNjb3JlID4gYmVzdFNjb3JlKSB7XG4gICAgICBiZXN0ID0gY2FuZGlkYXRlO1xuICAgICAgYmVzdFNjb3JlID0gc2NvcmU7XG4gICAgfVxuICB9KTtcbiAgZm9yRWFjaE5lYXJieUVuZW15QnVpbGRpbmcoZ2FtZSwgb3duZXIsIHBvaW50LCByYW5nZSArIE1BWF9CVUlMRElOR19SQURJVVMsIChidWlsZGluZykgPT4ge1xuICAgIGlmKGFjY2VwdHMgJiYgIWFjY2VwdHMoYnVpbGRpbmcpKXJldHVybjtcbiAgICBjb25zdCBnYXAgPSB0YXJnZXRHYXAocG9pbnQsIGJ1aWxkaW5nKTtcbiAgICBpZiAoZ2FwID4gcmFuZ2UpIHJldHVybjtcbiAgICBpZiAoYXR0YWNrZXIgJiYgIWF1dG9tYXRpY0NhbmRpZGF0ZVJlYWNoYWJsZShnYW1lLCBhdHRhY2tlciwgYnVpbGRpbmcsIG5hdmFsRnJhbWUpKSByZXR1cm47XG4gICAgY29uc3Qgc2NvcmUgPSB0YXJnZXRQcmlvcml0eVNjb3JlKGdhbWUsIG93bmVyLCBidWlsZGluZywgZ2FwICogZ2FwLCBhdHRhY2tlcik7XG4gICAgaWYgKHNjb3JlID4gYmVzdFNjb3JlKSB7XG4gICAgICBiZXN0ID0gYnVpbGRpbmc7XG4gICAgICBiZXN0U2NvcmUgPSBzY29yZTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gYmVzdDtcbn1cblxuZnVuY3Rpb24gc2hpcFJlYWNoUGFkZGluZyh1bml0czogcmVhZG9ubHkgVW5pdFtdKSB7XG4gIGxldCBwYWRkaW5nID0gMDtcbiAgZm9yIChjb25zdCB1bml0IG9mIHNoaXBzSW4odW5pdHMpKSB7XG4gICAgY29uc3QgcHJvZmlsZSA9IHNoaXBQcm9maWxlKHVuaXQpO1xuICAgIGlmIChwcm9maWxlKSBwYWRkaW5nID0gTWF0aC5tYXgocGFkZGluZywgLi4ucHJvZmlsZS5odWxsLm1hcChwID0+IE1hdGguaHlwb3QocC54LCBwLnkpKSk7XG4gIH1cbiAgcmV0dXJuIHBhZGRpbmc7XG59XG5cbmZ1bmN0aW9uIGF1dG9tYXRpY0NhbmRpZGF0ZVJlYWNoYWJsZShnYW1lOiBHYW1lLCB1bml0OiBVbml0LCBjYW5kaWRhdGU6IFVuaXQgfCBCdWlsZGluZywgbmF2YWxGcmFtZSA9IHRydWUpOiBib29sZWFuIHtcbiAgaWYgKChuYXZhbEZyYW1lIHx8IGdhbWUubWFwLnRlcnJhaW4pICYmICFjYW5SZWFjaChnYW1lLm1hcCwgdW5pdCwgY2FuZGlkYXRlLCBnYW1lLnVuaXRzKSkgcmV0dXJuIGZhbHNlO1xuICBpZiAodW5pdC5vd25lciAhPT0gXCJuZXV0cmFsXCIpIHJldHVybiB0cnVlO1xuICBjb25zdCBvcmlnaW4gPSBuZXV0cmFsUmVzcG9uc2VPcmlnaW4odW5pdCk7XG4gIHJldHVybiAhb3JpZ2luIHx8IGRpc3RhbmNlKGNhbmRpZGF0ZSwgb3JpZ2luKSA8PSBORVVUUkFMX0RBTUFHRV9SRVNQT05TRV9SQU5HRTtcbn1cblxuZnVuY3Rpb24gdGFyZ2V0UHJpb3JpdHlTY29yZShnYW1lOiBHYW1lLCBvd25lcjogT3duZXIsIHRhcmdldDogVW5pdCB8IEJ1aWxkaW5nLCBkaXN0YW5jZVNxOiBudW1iZXIsIGF0dGFja2VyPzogVW5pdCkge1xuICBjb25zdCB2aWN0aW1JZCA9IGNvbWJhdFZpY3RpbUlkKHRhcmdldCk7XG4gIGNvbnN0IHZpY3RpbSA9IHZpY3RpbUlkID8gZmluZFRhcmdldChnYW1lLCB2aWN0aW1JZCkgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IHRocmVhdDogVGFyZ2V0VGhyZWF0ID0gdmljdGltICYmICFhcmVFbmVteU93bmVycyhnYW1lLCBvd25lciwgdmljdGltLm93bmVyKSA/IHZpY3RpbSA9PT0gYXR0YWNrZXIgPyBcInNlbGZcIiA6IFwiYWxseVwiIDogXCJub25lXCI7XG4gIHJldHVybiBjb21iYXRUYXJnZXRTY29yZSh0YXJnZXQsIE1hdGguc3FydChkaXN0YW5jZVNxKSwgdGhyZWF0LCBwcm9qZWN0ZWRIcEFmdGVyUGVuZGluZ1Byb2plY3RpbGVzKGdhbWUsIG93bmVyLCB0YXJnZXQpKTtcbn1cblxuZnVuY3Rpb24gcHJvamVjdGVkSHBBZnRlclBlbmRpbmdQcm9qZWN0aWxlcyhnYW1lOiBHYW1lLCBhdHRhY2tlck93bmVyOiBPd25lciwgdGFyZ2V0OiBVbml0IHwgQnVpbGRpbmcgfCBPYnN0YWNsZSkge1xuICBsZXQgcGVuZGluZ0RhbWFnZSA9IDA7XG4gIC8vIFBoeXNpY2FsIGJvbHRzIGFuZCBzaGVsbHMgY2FuIG1pc3Mgb3IgaGl0IGludGVydmVuaW5nIGNyZXcuIE9ubHkgdHJhY2tpbmcgc2hvdHMgZ3VhcmFudGVlIHRoZWlyIHRhcmdldCdzIGRhbWFnZS5cbiAgZm9yIChjb25zdCBwcm9qZWN0aWxlIG9mIHByb2plY3RpbGVzQXQoZ2FtZSwgdGFyZ2V0LmlkKSkgaWYgKHByb2plY3RpbGUub3duZXIgPT09IGF0dGFja2VyT3duZXIgJiYgIXByb2plY3RpbGUud2VhcG9uKSBwZW5kaW5nRGFtYWdlICs9IHByb2plY3RpbGUuZGFtYWdlO1xuICByZXR1cm4gdGFyZ2V0LmhwIC0gcGVuZGluZ0RhbWFnZTtcbn1cblxuLy8gQEBAcHJvamVjdGlsZXMtYnktdGFyZ2V0IC0gVGhlIHNob3RzIGluIGZsaWdodCBhdCBhIHRhcmdldCwgaW4gdGhlIG9yZGVyIGdhbWUucHJvamVjdGlsZXMgaG9sZHMgdGhlbS4gVGFyZ2V0IGNob2ljZSBhc2tzXG4vLyBmb3IgZXZlcnkgY2FuZGlkYXRlIG9mIGV2ZXJ5IHVuaXQsIGFuZCBmaWx0ZXJpbmcgYWxsIHByb2plY3RpbGVzIGVhY2ggdGltZSBtYWRlIGEgYmlnIGZpZ2h0J3Mgc3RlcCBncm93IHdpdGggdW5pdHMgeFxuLy8gc2hvdHMgaW4gdGhlIGFpci4gVGhlIGVuZ2luZSBvbmx5IGV2ZXIgcmVwbGFjZXMgdGhlIGFycmF5ICh0aGUgc2hvdHMgdGhhdCBsYW5kZWQsIGEgcmVzdG9yZSkgb3IgcHVzaGVzIGEgbmV3IHNob3Qgb250b1xuLy8gaXQsIHNvIGFuIGluZGV4IGtlcHQgZm9yIG9uZSBhcnJheSBzdGF5cyByaWdodCBieSB0YWtpbmcgaW4gdGhlIHNob3RzIHB1c2hlZCBzaW5jZTsgYSByZXBsYWNlZCBhcnJheSBnZXRzIGl0cyBvd24uIFRoZVxuLy8gc3VtcyBhYm92ZSBhZGQgdGhlIHNhbWUgc2hvdHMgaW4gdGhlIHNhbWUgb3JkZXIgYXMgYSBmaWx0ZXIgd291bGQuXG5jb25zdCBwcm9qZWN0aWxlc0J5VGFyZ2V0ID0gbmV3IFdlYWtNYXA8UHJvamVjdGlsZVtdLCB7IGluZGV4ZWQ6IG51bWJlcjsgYnlUYXJnZXQ6IE1hcDxzdHJpbmcsIFByb2plY3RpbGVbXT4gfT4oKTtcbmNvbnN0IE5PX1BST0pFQ1RJTEVTOiBQcm9qZWN0aWxlW10gPSBbXTtcblxuZnVuY3Rpb24gcHJvamVjdGlsZXNBdChnYW1lOiBHYW1lLCB0YXJnZXRJZDogc3RyaW5nKTogUHJvamVjdGlsZVtdIHtcbiAgY29uc3QgcHJvamVjdGlsZXMgPSBnYW1lLnByb2plY3RpbGVzO1xuICBsZXQgaW5kZXggPSBwcm9qZWN0aWxlc0J5VGFyZ2V0LmdldChwcm9qZWN0aWxlcyk7XG4gIGlmICghaW5kZXggfHwgaW5kZXguaW5kZXhlZCA+IHByb2plY3RpbGVzLmxlbmd0aCkgcHJvamVjdGlsZXNCeVRhcmdldC5zZXQocHJvamVjdGlsZXMsIChpbmRleCA9IHsgaW5kZXhlZDogMCwgYnlUYXJnZXQ6IG5ldyBNYXAoKSB9KSk7XG4gIGZvciAoOyBpbmRleC5pbmRleGVkIDwgcHJvamVjdGlsZXMubGVuZ3RoOyBpbmRleC5pbmRleGVkICs9IDEpIHtcbiAgICBjb25zdCBwcm9qZWN0aWxlID0gcHJvamVjdGlsZXNbaW5kZXguaW5kZXhlZF0hO1xuICAgIGNvbnN0IGF0VGFyZ2V0ID0gaW5kZXguYnlUYXJnZXQuZ2V0KHByb2plY3RpbGUudGFyZ2V0SWQpO1xuICAgIGlmIChhdFRhcmdldCkgYXRUYXJnZXQucHVzaChwcm9qZWN0aWxlKTtcbiAgICBlbHNlIGluZGV4LmJ5VGFyZ2V0LnNldChwcm9qZWN0aWxlLnRhcmdldElkLCBbcHJvamVjdGlsZV0pO1xuICB9XG4gIHJldHVybiBpbmRleC5ieVRhcmdldC5nZXQodGFyZ2V0SWQpID8/IE5PX1BST0pFQ1RJTEVTO1xufVxuXG5cbmZ1bmN0aW9uIGZpbmRUYXJnZXQoZ2FtZTogR2FtZSwgdGFyZ2V0SWQ6IHN0cmluZyk6IFVuaXQgfCBCdWlsZGluZyB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IHRhcmdldCA9IGdhbWUuZW50aXR5QnlJZD8uZ2V0KHRhcmdldElkKSA/PyBnYW1lLnVuaXRzLmZpbmQoKHVuaXQpID0+IHVuaXQuaWQgPT09IHRhcmdldElkKSA/PyBnYW1lLmJ1aWxkaW5ncy5maW5kKChidWlsZGluZykgPT4gYnVpbGRpbmcuaWQgPT09IHRhcmdldElkKTtcbiAgcmV0dXJuIHRhcmdldCAmJiBpc1VuaXQodGFyZ2V0KSAmJiBpc0luQ2FiaW4odGFyZ2V0KSA/IHVuZGVmaW5lZCA6IHRhcmdldDtcbn1cblxuLy8gV2hhdCBhbiBhdHRhY2sgb3JkZXIgb3IgYSBzaG90IG1heSBzdHJpa2U6IGEgdW5pdCwgYSBidWlsZGluZywgb3Igcm9ja3Mgb3IgYSBnYXRlIChzZWUgQEBAb2JzdGFjbGUpLCB3aGljaCBub3RoaW5nIGVsc2Vcbi8vIGxvb2tzIGZvci5cbmZ1bmN0aW9uIGZpbmRTdHJpa2VUYXJnZXQoZ2FtZTogR2FtZSwgdGFyZ2V0SWQ6IHN0cmluZyk6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIGZpbmRUYXJnZXQoZ2FtZSwgdGFyZ2V0SWQpID8/IGdhbWUub2JzdGFjbGVzPy5maW5kKChvYnN0YWNsZSkgPT4gb2JzdGFjbGUuaWQgPT09IHRhcmdldElkKTtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlRXhwaXJlZFVuaXRzKGdhbWU6IEdhbWUpIHtcbiAgaWYgKCFnYW1lLnVuaXRzLnNvbWUodW5pdCA9PiB1bml0LmV4cGlyZXNUaWNrICE9PSB1bmRlZmluZWQgJiYgdW5pdC5leHBpcmVzVGljayA8PSBnYW1lLnRpY2spKSByZXR1cm47XG4gIGNvbnN0IGV4cGlyZWRVbml0cyA9IGdhbWUudW5pdHMuZmlsdGVyKCh1bml0KSA9PiB1bml0LmV4cGlyZXNUaWNrICE9PSB1bmRlZmluZWQgJiYgdW5pdC5leHBpcmVzVGljayA8PSBnYW1lLnRpY2spO1xuICBkcm9wSXRlbXNGcm9tRGVhZFVuaXRzKGdhbWUsIGV4cGlyZWRVbml0cyk7XG4gIGNvbnN0IGV4cGlyZWRJZHMgPSBuZXcgU2V0KGV4cGlyZWRVbml0cy5tYXAoKHVuaXQpID0+IHVuaXQuaWQpKTtcbiAgZ2FtZS51bml0cyA9IGdhbWUudW5pdHMuZmlsdGVyKCh1bml0KSA9PiAhZXhwaXJlZElkcy5oYXModW5pdC5pZCkpO1xuICBpbnZhbGlkYXRlU2VwYXJhdGlvbkZyYW1lKGdhbWUpO1xuICB1cGRhdGVTdXBwbHlTdGF0ZShnYW1lKTtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlRGVhZChnYW1lOiBHYW1lKSB7XG4gIC8vIEVtcHR5IGNsZWFudXAgZnJhbWVzIHN0aWxsIGNoZWNrIGV2ZXJ5IGJvZHkuIEF2b2lkIGNvbnN0cnVjdGluZyBkZWF0aFxuICAvLyBsaXN0cyBhbmQgd3JlY2sgc2V0cyB1bnRpbCBhIHVuaXQgb3IgYnVpbGRpbmcgYWN0dWFsbHkgbmVlZHMgcmVtb3ZhbC5cbiAgaWYgKCFnYW1lLnVuaXRzLnNvbWUodW5pdCA9PiB1bml0LmhwIDw9IDApICYmICFnYW1lLmJ1aWxkaW5ncy5zb21lKGJ1aWxkaW5nID0+IGJ1aWxkaW5nLmhwIDw9IDApKSB7XG4gICAgaWYgKGdhbWUub2JzdGFjbGVzPy5zb21lKG9ic3RhY2xlID0+IG9ic3RhY2xlLmhwIDw9IDApKSBnYW1lLm9ic3RhY2xlcyA9IGdhbWUub2JzdGFjbGVzLmZpbHRlcihvYnN0YWNsZSA9PiBvYnN0YWNsZS5ocCA+IDApO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBkZWFkVW5pdHMgPSBnYW1lLnVuaXRzLmZpbHRlcigodW5pdCkgPT4gdW5pdC5ocCA8PSAwKTtcbiAgY29uc3Qgd3JlY2tzPW5ldyBTZXQoZGVhZFVuaXRzLmZpbHRlcih1bml0PT5zaGlwUHJvZmlsZSh1bml0KSkubWFwKHVuaXQ9PnVuaXQuaWQpKTtcbiAgaWYod3JlY2tzLnNpemUpZm9yKGNvbnN0IHBhc3NlbmdlciBvZiBnYW1lLnVuaXRzKWlmKHBhc3Nlbmdlci5kZWNrICYmIHdyZWNrcy5oYXMocGFzc2VuZ2VyLmRlY2suc2hpcElkKSAmJiBwYXNzZW5nZXIuaHA+MCl7cGFzc2VuZ2VyLmhwPTA7ZGVhZFVuaXRzLnB1c2gocGFzc2VuZ2VyKTt9XG4gIGNvbnN0IGRlYWRCdWlsZGluZ3MgPSBnYW1lLmJ1aWxkaW5ncy5maWx0ZXIoKGJ1aWxkaW5nKSA9PiBidWlsZGluZy5ocCA8PSAwKTtcbiAgZm9yIChjb25zdCB1bml0IG9mIGRlYWRVbml0cykgaW5jcmVtZW50U3RhdChnYW1lLm1hdGNoLnN0YXRzLnVuaXRzTG9zdCwgdW5pdC5vd25lciwgMSk7XG4gIC8vIENhcHR1cmUgb25seSBwcmltaXRpdmUgcHJlc2VudGF0aW9uIGZhY3RzIGJlZm9yZSB0aGUgb3JpZ2luYWwgZHJvcCBwYXRoXG4gIC8vIGNsZWFycyBjYXJyaWVySWQuIFRoZXNlIHJlY29yZHMgbmV2ZXIgZmVlZCBjb21iYXQgb3IgaW52ZW50b3J5IGRlY2lzaW9ucy5cbiAgY29uc3QgZGVhdGhBcHBlYXJhbmNlID0gbmV3IE1hcChkZWFkVW5pdHMubWFwKHVuaXQgPT4ge1xuICAgIGNvbnN0IHJpZ2h0PWFjdGl2ZUl0ZW0oZ2FtZSx1bml0LCdyaWdodCcpLGxlZnQ9YWN0aXZlSXRlbShnYW1lLHVuaXQsJ2xlZnQnKTtcbiAgICByZXR1cm4gW3VuaXQuaWQsIHtcbiAgICAgIGVxdWlwbWVudENhcHR1cmVkOnRydWUgYXMgY29uc3QsXG4gICAgICAuLi4odW5pdC5kZWNrP3tkZWNrOnsuLi51bml0LmRlY2t9fTp7fSksXG4gICAgICAuLi4ocmlnaHQ/LmtpbmQ9PT0nZ3JlYXRTd29yZCc/e3JpZ2h0SXRlbUtpbmQ6J2dyZWF0U3dvcmQnIGFzIGNvbnN0fTpyaWdodD8ua2luZD09PSdpc3N1ZWRXZWFwb24nP3tyaWdodEl0ZW1LaW5kOidpc3N1ZWRXZWFwb24nIGFzIGNvbnN0LC4uLihyaWdodC53ZWFwb25LaW5kP3t3ZWFwb25LaW5kOnJpZ2h0LndlYXBvbktpbmR9Ont9KX06e30pLFxuICAgICAgLi4uKGxlZnQ/LmtpbmQ9PT0ncm91bmRTaGllbGQnP3tsZWZ0SXRlbUtpbmQ6J3JvdW5kU2hpZWxkJyBhcyBjb25zdH06e30pLFxuICAgICAgLi4uKGdhbWUucGxheWVyc1t1bml0Lm93bmVyXT8ucmFjZT97b3duZXJSYWNlOmdhbWUucGxheWVyc1t1bml0Lm93bmVyXSEucmFjZX06e30pLFxuICAgIH1dIGFzIGNvbnN0O1xuICB9KSk7XG4gIGRyb3BJdGVtc0Zyb21EZWFkVW5pdHMoZ2FtZSwgZGVhZFVuaXRzKTtcbiAgLy8gT25seSBhY3R1YWwgZmllbGQgZGVhdGhzIGNyZWF0ZSByZW1haW5zLiBCb2FyZGluZywgc2NyaXB0ZWQgZXhpdHMgYW5kXG4gIC8vIHN1bW1vbiBleHBpcnkgZG8gbm90OyBwYXNzZW5nZXJzIHN0YXkgYWJvYXJkIHRoZSB3cmVjay4gSURzIGRvIG5vdCBjb25zdW1lXG4gIC8vIHRoZSBsaXZlLWVudGl0eSBjb3VudGVyLCBhbmQgcmVtYWlucyBuZXZlciBqb2luIHRhcmdldGluZyBvciBwYXRoaW5nIGluZGV4ZXMuXG4gIGZvciAoY29uc3QgdW5pdCBvZiBkZWFkVW5pdHMpIGlmICghKHVuaXQuZGVjayAmJiB3cmVja3MuaGFzKHVuaXQuZGVjay5zaGlwSWQpKSkge1xuICAgIChnYW1lLmNvcnBzZXMgPz89IFtdKS5wdXNoKHsgaWQ6IGBjb3Jwc2UtJHt1bml0LmlkfS0ke2dhbWUudGlja31gLCB1bml0SWQ6IHVuaXQuaWQsXG4gICAgICBraW5kOiB1bml0LmtpbmQsIG93bmVyOiB1bml0Lm93bmVyLCB4OiB1bml0LngsIHk6IHVuaXQueSwgcmFkaXVzOiB1bml0LnJhZGl1cyxcbiAgICAgIGRpZWRBdFRpY2s6IGdhbWUudGljaywgLi4uKHVuaXQudmFyaWFudCA/IHsgdmFyaWFudDogdW5pdC52YXJpYW50IH0gOiB7fSksIC4uLmRlYXRoQXBwZWFyYW5jZS5nZXQodW5pdC5pZCkgfSk7XG4gIH1cbiAgaWYoZGVhZFVuaXRzLmxlbmd0aCkge1xuICAgIGdhbWUudW5pdHMgPSBnYW1lLnVuaXRzLmZpbHRlcigodW5pdCkgPT4gdW5pdC5ocCA+IDApO1xuICAgIGludmFsaWRhdGVTZXBhcmF0aW9uRnJhbWUoZ2FtZSk7XG4gIH1cbiAgaWYoZGVhZEJ1aWxkaW5ncy5sZW5ndGgpZ2FtZS5idWlsZGluZ3MgPSBnYW1lLmJ1aWxkaW5ncy5maWx0ZXIoKGJ1aWxkaW5nKSA9PiBidWlsZGluZy5ocCA+IDApO1xuICAvLyBBIHJvY2sgcGlsZSBvciBnYXRlIGJyb2tlbiBpcyBnb25lLCBhbmQgaXRzIHdheSBvcGVuIChzZWUgQEBAb2JzdGFjbGUpLlxuICBpZiAoZ2FtZS5vYnN0YWNsZXM/LnNvbWUoKG9ic3RhY2xlKSA9PiBvYnN0YWNsZS5ocCA8PSAwKSkgZ2FtZS5vYnN0YWNsZXMgPSBnYW1lLm9ic3RhY2xlcy5maWx0ZXIoKG9ic3RhY2xlKSA9PiBvYnN0YWNsZS5ocCA+IDApO1xuICBpZiAoZGVhZFVuaXRzLmxlbmd0aCA+IDAgfHwgZGVhZEJ1aWxkaW5ncy5sZW5ndGggPiAwKSB1cGRhdGVTdXBwbHlTdGF0ZShnYW1lKTtcbn1cblxuZnVuY3Rpb24gZHJvcEl0ZW1zRnJvbURlYWRVbml0cyhnYW1lOiBHYW1lLCBkZWFkVW5pdHM6IFVuaXRbXSkge1xuICBpZiAoZGVhZFVuaXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBpbnZhbGlkYXRlSXRlbUluZGV4KGdhbWUuaXRlbXMpO1xuICBjb25zdCBkZWFkQnlJZCA9IG5ldyBNYXAoZGVhZFVuaXRzLm1hcCgodW5pdCkgPT4gW3VuaXQuaWQsIHVuaXRdKSk7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBnYW1lLml0ZW1zKSB7XG4gICAgaWYgKCFpdGVtLmNhcnJpZXJJZCAmJiAhaXRlbS5zaGlwSWQpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGRlYWQgPSBkZWFkQnlJZC5nZXQoaXRlbS5jYXJyaWVySWQgPz8gaXRlbS5zaGlwSWQhKTtcbiAgICBpZiAoIWRlYWQpIGNvbnRpbnVlO1xuICAgIGRlbGV0ZSBpdGVtLmNhcnJpZXJJZDtkZWxldGUgaXRlbS5zbG90O2RlbGV0ZSBpdGVtLnNoaXBJZDtkZWxldGUgaXRlbS5ob2xkU2xvdDtkZWxldGUgaXRlbS5tb3VudElkO2RlbGV0ZSBpdGVtLmFpbTtcbiAgICBpdGVtLnggPSBkZWFkLng7XG4gICAgaXRlbS55ID0gZGVhZC55O1xuICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVZpY3RvcnkoZ2FtZTogR2FtZSkge1xuICBpZiAoZ2FtZS5tYXRjaC53aW5uZXIgfHwgZ2FtZS5zY3JpcHRlZFZpY3RvcnkpIHJldHVybjtcbiAgY29uc3QgYWN0aXZlVGVhbXMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCBvd25lciBvZiBnYW1lLmFjdGl2ZVBsYXllcnMpIGFjdGl2ZVRlYW1zLmFkZCh0ZWFtS2V5KGdhbWUsIG93bmVyKSk7XG4gIGxldCB3aW5uZXJUZWFtOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGxldCB3aW5uZXI6IFBsYXllcklkIHwgbnVsbCA9IG51bGw7XG4gIGZvciAoY29uc3QgYnVpbGRpbmcgb2YgZ2FtZS5idWlsZGluZ3MpIHtcbiAgICBjb25zdCB0ZWFtID0gdGVhbUtleShnYW1lLCBidWlsZGluZy5vd25lcik7XG4gICAgaWYgKCFhY3RpdmVUZWFtcy5oYXModGVhbSkpIGNvbnRpbnVlO1xuICAgIGlmICh3aW5uZXJUZWFtICE9PSB1bmRlZmluZWQgJiYgdGVhbSAhPT0gd2lubmVyVGVhbSkgcmV0dXJuO1xuICAgIGlmICh3aW5uZXJUZWFtID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHdpbm5lclRlYW0gPSB0ZWFtO1xuICAgICAgd2lubmVyID0gYnVpbGRpbmcub3duZXI7XG4gICAgfVxuICB9XG4gIGdhbWUubWF0Y2gud2lubmVyID0gd2lubmVyO1xuICBnYW1lLm1hdGNoLmVuZGVkQXRUaWNrID0gZ2FtZS50aWNrO1xufVxuXG4vLyBAQEBzdG9yeS1ob29rcyAtIFdoYXQgYSBjYW1wYWlnbiBzY3JpcHQgbWF5IGRvIHRvIGl0cyBnYW1lIGJlc2lkZXMgZ2l2aW5nIG9yZGVycyAoc2VlIHN0b3J5L3dvcmxkKTogYnJpbmcgb24gYSB1bml0IG9mXG4vLyBpdHMgb3duLCByZS1kZXJpdmUgYSB1bml0IHdob3NlIHZhcmlhbnQgaXQgcmV3cm90ZSAoYSBoZXJvIHRoYXQgbGV2ZWxsZWQgb3IgdG9vayB1cCBhIHJlbGljKSwgc3RyaWtlIHdpdGggYSBwb3dlciBvZiBpdHNcbi8vIG93biwgcGFpbnQgYW4gZWZmZWN0LCBhbmQgdGFrZSBhIHVuaXQgb2ZmIHRoZSBzdGFnZS4gQSBzdGFuZGFyZCBtYXRjaCBuZXZlciBjYWxscyB0aGVtLlxuXG5leHBvcnQgZnVuY3Rpb24gc3Bhd25WYXJpYW50VW5pdChnYW1lOiBHYW1lLCBvd25lcjogT3duZXIsIHZhcmlhbnQ6IHN0cmluZywgeDogbnVtYmVyLCB5OiBudW1iZXIsIGlkPzogc3RyaW5nKTogVW5pdCB7XG4gIGNvbnN0IHJ1bGVzID0gZ2FtZS52YXJpYW50cz8uW3ZhcmlhbnRdO1xuICBpZiAoIXJ1bGVzKSB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gdW5pdCB2YXJpYW50ICR7dmFyaWFudH1gKTtcbiAgY29uc3QgdW5pdElkID0gaWQgPz8gYHVuaXQtJHtvd25lcn0tJHt2YXJpYW50fS0ke2dhbWUubmV4dElkfWA7XG4gIGlmIChpZCA9PT0gdW5kZWZpbmVkKSBnYW1lLm5leHRJZCArPSAxO1xuICBlbHNlIGlmIChnYW1lLnVuaXRzLnNvbWUoKHVuaXQpID0+IHVuaXQuaWQgPT09IGlkKSB8fCBnYW1lLmJ1aWxkaW5ncy5zb21lKChidWlsZGluZykgPT4gYnVpbGRpbmcuaWQgPT09IGlkKSkgdGhyb3cgbmV3IEVycm9yKGBEdXBsaWNhdGUgdW5pdCBpZCAke2lkfWApO1xuICBjb25zdCB1bml0ID0gY3JlYXRlVW5pdCh1bml0SWQsIG93bmVyLCBydWxlcy5iYXNlLCB4LCB5KTtcbiAgdW5pdC52YXJpYW50ID0gdmFyaWFudDtcbiAgdW5pdC5ocCA9IHJ1bGVzLmhwO1xuICB0YWtlVmFyaWFudEZyYW1lKHVuaXQsIHJ1bGVzKTtcbiAgYXBwbHlVbml0VXBncmFkZXMoZ2FtZSwgdW5pdCk7XG4gIGdhbWUudW5pdHMucHVzaCh1bml0KTtcbiAgdXBkYXRlU3VwcGx5U3RhdGUoZ2FtZSk7XG4gIHJldHVybiB1bml0O1xufVxuXG4vLyBBZnRlciB0aGUgdW5pdCdzIHZhcmlhbnQgcnVsZXMgY2hhbmdlZDogaXRzIG51bWJlcnMgYWdhaW4sIGtlZXBpbmcgdGhlIHNoYXJlIG9mIGhlYWx0aCBpdCBoYWQuXG5leHBvcnQgZnVuY3Rpb24gcmVmcmVzaFVuaXRTdGF0cyhnYW1lOiBHYW1lLCB1bml0OiBVbml0KSB7XG4gIGNvbnN0IHJ1bGVzID0gdW5pdFJ1bGVzKGdhbWUsIHVuaXQpO1xuICBjb25zdCBzaGFyZSA9IHVuaXQuaHAgLyBNYXRoLm1heCgxLCB1bml0Lm1heEhwKTtcbiAgaWYgKHVuaXQudmFyaWFudCAhPT0gdW5kZWZpbmVkKSB0YWtlVmFyaWFudEZyYW1lKHVuaXQsIHJ1bGVzKTtcbiAgaWYgKGlzUGxheWVySWQodW5pdC5vd25lcikpIGFwcGx5RGVyaXZlZFVuaXRTdGF0cyhnYW1lLCB1bml0KTtcbiAgdW5pdC5ocCA9IE1hdGgubWF4KDEsIE1hdGgubWluKHVuaXQubWF4SHAsIE1hdGgucm91bmQodW5pdC5tYXhIcCAqIHNoYXJlKSkpO1xufVxuXG4vLyBBIHZhcmlhbnQncyBib2R5IGFuZCB3ZWFwb24sIHdoaWNoIHVwZ3JhZGVzIGFuZCBzdGFycyBkbyBub3QgdG91Y2g7IGhpdCBwb2ludHMsIGRhbWFnZSwgc3BlZWQgYW5kIHJhbmdlIGFyZSB0aGVuXG4vLyBkZXJpdmVkIGFzIGFueSB1bml0J3MgYXJlLlxuZnVuY3Rpb24gdGFrZVZhcmlhbnRGcmFtZSh1bml0OiBVbml0LCBydWxlczogVW5pdERlZikge1xuICB1bml0Lm1heEhwID0gcnVsZXMuaHA7XG4gIHVuaXQuaHAgPSBNYXRoLm1pbih1bml0LmhwLCBydWxlcy5ocCk7XG4gIHVuaXQuc3BlZWQgPSBydWxlcy5zcGVlZDtcbiAgdW5pdC5yYWRpdXMgPSBydWxlcy5yYWRpdXMqKGlzU2hpcEtpbmQodW5pdC5raW5kKT9TSElQX1NJWkVfTVVMVElQTElFUjoxKTtcbiAgdW5pdC5ib2R5UmFkaXVzID0gdW5pdC5yYWRpdXM7XG4gIHVuaXQuYXR0YWNrRGFtYWdlID0gcnVsZXMuYXR0YWNrRGFtYWdlO1xuICB1bml0LmF0dGFja1JhbmdlID0gcnVsZXMuYXR0YWNrUmFuZ2U7XG4gIHVuaXQuYXR0YWNrQ29vbGRvd24gPSBydWxlcy5hdHRhY2tDb29sZG93bjtcbn1cblxuLy8gQSBibG93IGZyb20gYSBzY3JpcHQncyBwb3dlcjogYG1lbGVlYCBhbmQgYHJhbmdlZGAgbGFuZCBhcyBhIHdlYXBvbidzIHdvdWxkICh0aGUgc3dpcGUgb3IgdGhlIGJvbHQgaXMgZHJhd24pLCBgc3BlbGxgXG4vLyBvbmx5IGFzIGEgaGl0LiBJdCBjb3VudHMgYXMgdGhlIHNvdXJjZSdzIGJsb3cgZm9yIGtpbGxzLCBleHBlcmllbmNlLCBib3VudHkgYW5kIHRoZSB2aWN0aW0ncyBjYWxsIGZvciBoZWxwLCBhbmQgYXJtb3Jcbi8vIGFuZCBjdXJzZXMgY291bnQgYXMgZXZlci4gVGhlIHNvdXJjZSBtYXkgYmUgYSB1bml0IHRoYXQgaGFzIHNpbmNlIGRpZWQsIG9yIGEgcG9pbnQgb2YgdGhlIHNvdXJjZSdzIHNpZGUuXG5leHBvcnQgZnVuY3Rpb24gc3RyaWtlVW5pdChnYW1lOiBHYW1lLCBzb3VyY2U6IFVuaXQgfCBCdWlsZGluZyB8IHsgaWQ6IHN0cmluZzsgb3duZXI6IFBsYXllcklkOyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCB0YXJnZXQ6IFVuaXQgfCBCdWlsZGluZywgZGFtYWdlOiBudW1iZXIsIHN0eWxlOiBcIm1lbGVlXCIgfCBcInJhbmdlZFwiIHwgXCJzcGVsbFwiKSB7XG4gIGNvbnN0IGF0dGFja2VyID0gXCJocFwiIGluIHNvdXJjZSA/IHNvdXJjZSA6IChmaW5kVGFyZ2V0KGdhbWUsIHNvdXJjZS5pZCkgPz8gc2NyaXB0U291cmNlKHNvdXJjZSkpO1xuICBjb25zdCBkZWFsdCA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQoZGFtYWdlKSk7XG4gIGlmIChzdHlsZSA9PT0gXCJzcGVsbFwiKSB7XG4gICAgY29uc3QgdGFrZW4gPSBhcHBseURhbWFnZShnYW1lLCBhdHRhY2tlciwgdGFyZ2V0LCBkZWFsdCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIDAsIERBTUFHRV9QUk9GSUxFUy5BUkNBTkUpO1xuICAgIGlmICh0YWtlbiAhPT0gdW5kZWZpbmVkKSBhZGRIaXRFZmZlY3QoZ2FtZSwgdGFyZ2V0LCB0YWtlbik7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGJhc2VQcm9maWxlID0gaXNVbml0KGF0dGFja2VyKSA/IHVuaXRBdHRhY2tEYW1hZ2VQcm9maWxlKGdhbWUsIGF0dGFja2VyKSA6IGF0dGFja0RhbWFnZVByb2ZpbGUoYXR0YWNrZXIua2luZCk7XG4gIGFwcGx5QXR0YWNrRGFtYWdlKGdhbWUsIGF0dGFja2VyLCB0YXJnZXQsIGRlYWx0LCBzdHlsZSA9PT0gXCJyYW5nZWRcIiA/IFJBTkdFRF9BVFRBQ0tfUkFOR0VfVEhSRVNIT0xEICsgMSA6IDAsIHsgLi4uYmFzZVByb2ZpbGUsIGRlbGl2ZXJ5OiBzdHlsZSB9KTtcbn1cblxuLy8gQSBzb3VyY2Ugbm8gbG9uZ2VyIG9uIHRoZSBmaWVsZCAoYSBjYXN0ZXIgZGVhZCBiZWZvcmUgaXRzIGZpcmUgZmVsbCkgc3RyaWtlcyBhcyBpdHMgc2lkZSwgZnJvbSB3aGVyZSBpdCBzdG9vZDogYW5cbi8vIHVuYXJtZWQgYnVpbGRpbmcgb2YgdGhhdCBzaWRlLCBzbyBubyB0b3dlcidzIGFybW9yIHJ1bGUgYW5kIG5vIGNhbGwgZm9yIGhlbHAgYXBwbGllcyB0byBpdC5cbmZ1bmN0aW9uIHNjcmlwdFNvdXJjZShzb3VyY2U6IHsgaWQ6IHN0cmluZzsgb3duZXI6IFBsYXllcklkOyB4OiBudW1iZXI7IHk6IG51bWJlciB9KTogQnVpbGRpbmcge1xuICBjb25zdCBzdGFuZCA9IHByb2plY3RpbGVBdHRhY2tlcih7IGlkOiBzb3VyY2UuaWQsIG93bmVyOiBzb3VyY2Uub3duZXIsIGF0dGFja2VySWQ6IHNvdXJjZS5pZCwgdGFyZ2V0SWQ6IHNvdXJjZS5pZCwgZnJvbVg6IHNvdXJjZS54LCBmcm9tWTogc291cmNlLnksIHRvWDogc291cmNlLngsIHRvWTogc291cmNlLnksIGRhbWFnZTogMCwgcmVtYWluaW5nOiAwLCBkdXJhdGlvbjogMCB9KTtcbiAgcmV0dXJuIHsgLi4uc3RhbmQsIGtpbmQ6IFwiZmFybVwiIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRXb3JsZEVmZmVjdChnYW1lOiBHYW1lLCB0eXBlOiBXb3JsZEVmZmVjdFtcInR5cGVcIl0sIHg6IG51bWJlciwgeTogbnVtYmVyLCB0aWNrczogbnVtYmVyLCB2ZWN0b3JzPzogUGFyYW1ldGVyczx0eXBlb2YgYWRkRWZmZWN0Pls1XSkge1xuICBhZGRFZmZlY3QoZ2FtZSwgdHlwZSwgeCwgeSwgdGlja3MsIHZlY3RvcnMpO1xufVxuXG4vLyBUYWtlcyB0aGUgdW5pdCBvZmYgdGhlIHN0YWdlIHdpdGhvdXQgYSBkZWF0aCAobm8ga2lsbCwgbm8gbG9zcyk6IGEgc2NlbmUncyBleHRyYXMgbGVhdmluZywgYSBoZXJvIHN0ZXBwaW5nIG91dC5cbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVVbml0KGdhbWU6IEdhbWUsIHVuaXRJZDogc3RyaW5nKSB7XG4gIGNvbnN0IHVuaXQgPSBnYW1lLnVuaXRzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSB1bml0SWQpO1xuICBpZiAoIXVuaXQpIHJldHVybjtcbiAgZHJvcEl0ZW1zRnJvbURlYWRVbml0cyhnYW1lLCBbdW5pdF0pO1xuICBnYW1lLnVuaXRzID0gZ2FtZS51bml0cy5maWx0ZXIoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkICE9PSB1bml0SWQpO1xuICBpbnZhbGlkYXRlU2VwYXJhdGlvbkZyYW1lKGdhbWUpO1xuICBnYW1lLmVudGl0eUJ5SWQ/LmRlbGV0ZSh1bml0SWQpO1xuICBpZiAodW5pdC52ZXRlcmFuU2tpbGwpIHtcbiAgICBnYW1lLnVuaXRTcGF0aWFsID0gY3JlYXRlU3BhdGlhbEluZGV4KGdhbWUudW5pdHMsIDMyMCk7XG4gICAgcmVmcmVzaFZldGVyYW5GcmFtZShnYW1lKTtcbiAgfVxuICB1cGRhdGVTdXBwbHlTdGF0ZShnYW1lKTtcbn1cblxuZnVuY3Rpb24gaXNQbGF5ZXJJZChvd25lcjogVW5pdFtcIm93bmVyXCJdKTogb3duZXIgaXMgUGxheWVySWQge1xuICByZXR1cm4gb3duZXIgIT09IFwibmV1dHJhbFwiO1xufVxuXG5mdW5jdGlvbiBhcmVFbmVteU93bmVycyhnYW1lOiBHYW1lLCBhOiBPd25lciwgYjogT3duZXIpIHtcbiAgaWYgKGEgPT09IGIpIHJldHVybiBmYWxzZTtcbiAgaWYgKGEgPT09IFwibmV1dHJhbFwiIHx8IGIgPT09IFwibmV1dHJhbFwiKSByZXR1cm4gYSAhPT0gXCJuZXV0cmFsXCIgfHwgYiAhPT0gXCJuZXV0cmFsXCI7XG4gIHJldHVybiBnYW1lLnRlYW1zW2FdICE9PSBnYW1lLnRlYW1zW2JdO1xufVxuXG5mdW5jdGlvbiB0ZWFtS2V5KGdhbWU6IEdhbWUsIG93bmVyOiBPd25lcikge1xuICByZXR1cm4gb3duZXIgPT09IFwibmV1dHJhbFwiID8gXCJuZXV0cmFsXCIgOiBnYW1lLnRlYW1zW293bmVyXSA/PyBvd25lcjtcbn1cblxuXG4vLyBAQEBidWlsZGluZy1ib2R5IC0gQSBidWlsZGluZyBpcyBhIGJvZHkgbm8gdW5pdCBlbnRlcnMsIGFzIGEgZm9yZXN0IGlzIChzZWUgQEBAdGVycmFpbik6IGl0cyBmb290cHJpbnQncyBjZWxscyAoc2VlXG4vLyBAQEBidWlsZGluZy1mb290cHJpbnQpIGFyZSBncm91bmQgbm8gbGFuZCB1bml0J3MgY2VudGVyIHN0YW5kcyBvbiwgc28gYSBzdGVwIG9yIGEgc2xpZGUgKHNlZSBAQEBwdXNoKSBpbnRvIHRoZW0gc3RvcHNcbi8vIGFzIGF0IGEgd2FsbCwgYW5kIHVuaXRzIHBhcnRpbmcgZnJvbSBlYWNoIG90aGVyIGFyZSBuZXZlciBwdXNoZWQgb250byB0aGVtLiBBIGZvdW5kYXRpb24gaXMgYXMgc29saWQgYXMgYSBmaW5pc2hlZFxuLy8gYnVpbGRpbmc6IGEgc2l0ZSBsYWlkIHdoZXJlIHVuaXRzIHN0YW5kIG1vdmVzIHRoZW0gYXNpZGUgKHNlZSBrZWVwVW5pdHNPdXRPZkJ1aWxkaW5ncykuIFVuaXRzIHVzZWQgdG8gd2FsayB0aHJvdWdoXG4vLyBidWlsZGluZ3MsIGFuZCBhIG1lbGVlIGZpZ2h0ZXIgc3RydWNrIGEgdG93biBoYWxsIGZyb20gaW5zaWRlIGl0LiBUaGF0IGhvbGRzIG9uIGEgbWFwIHdpdGggdGVycmFpbiwgd2hvc2Vcbi8vIHJvdXRpbmcgdGFrZXMgYSB1bml0IHJvdW5kIGJ1aWxkaW5ncyAoc2VlIEBAQGJ1aWxkaW5nLXBhdGhpbmcpOyBhIG1hcCB3aXRob3V0IHRlcnJhaW4gaXMgb3BlbiBldmVyeXdoZXJlIGFuZCBwbGF5cyBhc1xuLy8gaXQgZGlkIChzZWUgQEBAdGVycmFpbik6IGl0cyB3YWxrcyBhcmUgc3RyYWlnaHQgbGluZXMsIGFuZCBhIGJ1aWxkaW5nIGluIHRoZWlyIHdheSB3b3VsZCBzdG9wIHRoZW0gZm9yIGdvb2QgKGEgVjJcbi8vIGVjb25vbXkgb24gdmVyZGFudENyb3Nzcm9hZHMgbmV2ZXIgcmVhY2hlZCBpdHMgZXhwYW5zaW9uIHdpdGggaXRzIG93biBmYXJtcyBpbiBpdHMgd29ya2Vycycgd2F5KS5cbmNvbnN0IE1BWF9CVUlMRElOR19SQURJVVMgPSBNYXRoLm1heCguLi5PYmplY3QudmFsdWVzKEJVSUxESU5HX0RFRlMpLm1hcCgoZGVmKSA9PiBkZWYucmFkaXVzKSk7XG5jb25zdCBNQVhfVU5JVF9SQURJVVMgPSBNYXRoLm1heCguLi5PYmplY3QudmFsdWVzKFVOSVRfREVGUykubWFwKChkZWYpID0+IGRlZi5yYWRpdXMpKTtcblxuLy8gV2hldGhlciBhIHdhbGsgKGEgbW92ZSBvciBhbiBhdHRhY2stbW92ZSkgdG8gYGdvYWxgIGlzIG92ZXI6IHRoZSB1bml0IHN0YW5kcyB3aXRoaW4gYHdpdGhpbmAgb2Ygd2hlcmUgaXQgZW5kcyAodGhlXG4vLyB3YWxrYWJsZSBwb2ludCBuZWFyZXN0IHRoZSBnb2FsLCBvciBhcyBuZWFyIGFzIGl0cyBncm91bmQgY29tZXMgd2hlbiBpdCBjYW5ub3QgcmVhY2ggaXQ6IHNlZSB3YWxrRGVzdGluYXRpb24pLCBvciBhc1xuLy8gbmVhciBhcyBhIGJ1aWxkaW5nIGxldHMgaXQgY29tZSAoc2VlIHJlc3RzQWdhaW5zdEdvYWxCb2R5KSwgb3IgYWdhaW5zdCBhIGZyaWVuZCBhbHJlYWR5IHRoZXJlIChzZWUgQEBAZ3JvdXAtYXJyaXZhbCkuXG4vLyBNZWFzdXJlZCB0byBhbiB1bnJlYWNoYWJsZSBwb2ludCBpdHNlbGYsIHRoZSBvcmRlciBuZXZlciBlbmRlZCBhbmQgdGhlIHVuaXQgc3Rvb2QgYXQgdGhlIHNob3JlIGZvciBnb29kLlxuZnVuY3Rpb24gd2Fsa0VuZGVkKGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIGdvYWw6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSwgd2l0aGluOiBudW1iZXIpIHtcbiAgY29uc3QgbWFwID0gZ2FtZS5tYXA7XG4gIGNvbnN0IHRyYXZlbD11bml0Lm9yZGVyO1xuICBpZigodHJhdmVsLnR5cGU9PT1cIm1vdmVcInx8dHJhdmVsLnR5cGU9PT1cImF0dGFja01vdmVcIikgJiYgdHJhdmVsLmRlY2tTaGlwSWQgJiYgdHJhdmVsLmRlY2tTaGlwSWQhPT11bml0LmRlY2s/LnNoaXBJZCAmJiBnYW1lLnVuaXRzLnNvbWUoc2hpcD0+c2hpcC5pZD09PXRyYXZlbC5kZWNrU2hpcElkICYmIHNoaXAuaHA+MCkpcmV0dXJuIGZhbHNlO1xuICBpZih1bml0LmRlY2sgJiYgKHRyYXZlbC50eXBlPT09XCJtb3ZlXCJ8fHRyYXZlbC50eXBlPT09XCJhdHRhY2tNb3ZlXCIpICYmICF0cmF2ZWwuZGVja1NoaXBJZCAmJiBpc09wZW5Hcm91bmQobWFwLGdvYWwueCxnb2FsLnksXCJsYW5kXCIpKXJldHVybiBmYWxzZTtcbiAgaWYodW5pdC5kZWNrKXtjb25zdCBzaGlwPWdhbWUudW5pdHMuZmluZChzaGlwPT5zaGlwLmlkPT09dW5pdC5kZWNrIS5zaGlwSWQpO2lmKCFzaGlwKXJldHVybiB0cnVlO2NvbnN0IG9yZGVyPXVuaXQub3JkZXI7aWYoKG9yZGVyLnR5cGU9PT1cIm1vdmVcInx8b3JkZXIudHlwZT09PVwiYXR0YWNrTW92ZVwiKSYmb3JkZXIuZGVja1NoaXBJZCAmJiBvcmRlci5kZWNrU2hpcElkIT09c2hpcC5pZCAmJiBnYW1lLnVuaXRzLnNvbWUodGFyZ2V0PT50YXJnZXQuaWQ9PT1vcmRlci5kZWNrU2hpcElkICYmIHRhcmdldC5ocD4wKSlyZXR1cm4gZmFsc2U7Y29uc3QgbG9jYWw9ZGVja1BsYWNlbWVudChzaGlwLHVuaXQsZ2FtZS51bml0cyx3b3JsZFRvTG9jYWwoc2hpcCxkZWNrR29hbCh1bml0LHNoaXAsZ29hbCxnYW1lLnVuaXRzKSksZmFsc2UpO3JldHVybiAhbG9jYWwgfHwgZGlzdGFuY2UodW5pdCxsb2NhbFRvV29ybGQoc2hpcCxsb2NhbCkpPHdpdGhpbiB8fCByZXN0c0FnYWluc3RBcnJpdmVkRnJpZW5kKGdhbWUsdW5pdCxnb2FsLGxvY2FsVG9Xb3JsZChzaGlwLGxvY2FsKSk7fVxuICBpZihzaGlwUHJvZmlsZSh1bml0KSkge1xuICAgIGlmKHRyYXZlbC50eXBlPT09XCJtb3ZlXCIgJiYgdHJhdmVsLmhlYWRpbmchPT11bmRlZmluZWQgJiYgTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UodW5pdC5zYWlsaW5nIS5oZWFkaW5nLHRyYXZlbC5oZWFkaW5nKSk+MWUtNilyZXR1cm4gZmFsc2U7XG4gICAgY29uc3Qgcm91dGU9dW5pdC5zYWlsaW5nPy5yb3V0ZTtcbiAgICBpZihtYXAudGVycmFpbiAmJiByb3V0ZSAmJiByb3V0ZS5nb2FsWD09PWdvYWwueCAmJiByb3V0ZS5nb2FsWT09PWdvYWwueSlyZXR1cm4gIXJvdXRlLnBhcnRpYWwgJiYgcm91dGUucG9pbnRzLmxlbmd0aD09PTAgJiYgZGlzdGFuY2UodW5pdCxyb3V0ZS5lbmQpPHdpdGhpbjtcbiAgICBjb25zdCBlbmQ9bmVhcmVzdFNoaXBQb3NlKG1hcCx1bml0LGdvYWwpO1xuICAgIHJldHVybiAhZW5kIHx8IGRpc3RhbmNlKHVuaXQsZW5kKTx3aXRoaW47XG4gIH1cbiAgaWYgKCFtYXAudGVycmFpbikgcmV0dXJuIGRpc3RhbmNlKHVuaXQsIGdvYWwpIDwgd2l0aGluIHx8IHJlc3RzQWdhaW5zdEFycml2ZWRGcmllbmQoZ2FtZSwgdW5pdCwgZ29hbCwgZ29hbCk7XG4gIGNvbnN0IG1vdmVyID0gdW5pdE1vdmVyKHVuaXQua2luZCk7XG4gIGNvbnN0IHBvaW50ID0gaXNXYWxrYWJsZShtYXAsIGdvYWwueCwgZ29hbC55LCBtb3ZlcikgPyBnb2FsIDogd2Fsa2FibGVHb2FsKG1hcCwgZ29hbC54LCBnb2FsLnksIG1vdmVyKTtcbiAgY29uc3QgZW5kID0gd2Fsa0Rlc3RpbmF0aW9uKG1hcCwgdW5pdCwgcG9pbnQsIG1vdmVyKTtcbiAgcmV0dXJuIGRpc3RhbmNlKHVuaXQsIGVuZCkgPCB3aXRoaW4gfHwgcmVzdHNBZ2FpbnN0R29hbEJvZHkoZ2FtZSwgdW5pdCwgcG9pbnQsIHdpdGhpbikgfHwgcmVzdHNBZ2FpbnN0QXJyaXZlZEZyaWVuZChnYW1lLCB1bml0LCBnb2FsLCBlbmQpO1xufVxuXG5mdW5jdGlvbiBhcnJpdmUodW5pdDogVW5pdCwgZ29hbDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9KSB7XG4gIHVuaXQub3JkZXIgPSB7IHR5cGU6IFwiaWRsZVwiIH07XG4gIHVuaXQuYXJyaXZlZEF0ID0geyB4OiBnb2FsLngsIHk6IGdvYWwueSB9O1xufVxuXG4vLyBBIHdhbGsgd2hvc2UgZ29hbCBsaWVzIHdpdGhpbiBhIGJ1aWxkaW5nJ3MgcmVhY2gsIG9yIGB3aXRoaW5gIG9mIGl0LCBlbmRzIHdoZXJlIHRoZSB1bml0IHN0YW5kcyBwcmVzc2VkIGFnYWluc3QgdGhhdFxuLy8gYnVpbGRpbmc6IGl0IGNhbiBjb21lIG5vIG5lYXJlci4gQSBnb2FsIGp1c3QgcGFzdCB0aGUgcmVhY2ggKGEgcmFsbHkgcG9pbnQgYmVzaWRlIGEgc2FuY3R1bSkga2VwdCBmb3VyIGxhbmNlcnMgcHJlc3NlZFxuLy8gYXQgMTUgZnJvbSBpdCBmb3IgZ29vZC5cbmZ1bmN0aW9uIHJlc3RzQWdhaW5zdEdvYWxCb2R5KGdhbWU6IEdhbWUsIHVuaXQ6IFVuaXQsIGdvYWw6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSwgd2l0aGluOiBudW1iZXIpIHtcbiAgLy8gT25seSBhIHVuaXQgd2l0aGluIGEgYnVpbGRpbmcncyByZWFjaCBvZiBpdHMgZ29hbCBjYW4gYmUgcHJlc3NlZCBhZ2FpbnN0IG9uZSB0aGF0IGNvdmVycyBpdC5cbiAgaWYgKGRpc3RhbmNlKHVuaXQsIGdvYWwpID4gMiAqIChNQVhfQlVJTERJTkdfUkFESVVTICsgTUFYX1VOSVRfUkFESVVTKSArIHdpdGhpbiArIDIpIHJldHVybiBmYWxzZTtcbiAgbGV0IHJlc3RpbmcgPSBmYWxzZTtcbiAgZm9yRWFjaE5lYXJieUJ1aWxkaW5nKGdhbWUsIGdvYWwsIE1BWF9CVUlMRElOR19SQURJVVMgKyB1bml0LnJhZGl1cyArIHdpdGhpbiwgKGJ1aWxkaW5nKSA9PiB7XG4gICAgY29uc3QgcmVhY2ggPSBidWlsZGluZy5yYWRpdXMgKyB1bml0LnJhZGl1cztcbiAgICBpZiAoIXJlc3RpbmcgJiYgZGlzdGFuY2UoZ29hbCwgYnVpbGRpbmcpIDwgcmVhY2ggKyB3aXRoaW4gJiYgZGlzdGFuY2UodW5pdCwgYnVpbGRpbmcpIDw9IHJlYWNoICsgMikgcmVzdGluZyA9IHRydWU7XG4gIH0pO1xuICByZXR1cm4gcmVzdGluZztcbn1cblxuLy8gQEBAZ3JvdXAtYXJyaXZhbCAtIEEgZ3JvdXAgc2VudCB0byBvbmUgcG9pbnQgZ2F0aGVycyByb3VuZCBpdCwgYXMgaW4gU3RhckNyYWZ0IElJOiBhIHVuaXQncyB3YWxrIGVuZHMgd2hlcmUgaXQgc3RhbmRzXG4vLyBhZ2FpbnN0IGEgZnJpZW5kIHRoYXQgaGFzIGFscmVhZHkgZW5kZWQgaXRzIHdhbGsgdG8gdGhlIHNhbWUgcG9pbnQgKGFuZCBpcyBzdGlsbCBzdGFuZGluZyB0aGVyZSksIHdpdGhpbiBDUk9XRF9SRUFDSFxuLy8gb2YgaXQuIE9ubHkgb25lIHVuaXQgY2FuIHN0YW5kIG9uIHRoZSBwb2ludDsgdGhlIHJlc3QgcHJlc3NlZCByb3VuZCB0aGUgZmlyc3QgdG8gY29tZSBmb3IgZ29vZCwgaG9sZGluZyB0aGVpciBvcmRlcnNcbi8vIChzZXZlbiBsYW5jZXJzIG9uIHRoZSBzaG9yZSBhY3Jvc3MgZnJvbSBhbiBpc2xhbmQpLiBBbnkgb3RoZXIgZnJpZW5kIHN0YW5kaW5nIGFib3V0IGlzIG5vIHJlYXNvbiB0byBzdG9wOiBhIGJhbmRcbi8vIHdhbGtpbmcgdGhyb3VnaCBpdHMgb3duIGNhbXAgc3RvcHBlZCBhdCB0aGUgZmlyc3QgaWRsZSBzb2xkaWVyIHRoZXJlIGFuZCBuZXZlciByZWFjaGVkIHRoZSBlbmVteS5cbmNvbnN0IENST1dEX1JFQUNIID0gMTAwO1xuXG4vLyBgZ29hbGAgaXMgdGhlIG9yZGVyJ3MgcG9pbnQgKHdob3NlIHdhbGsgYSBmcmllbmQgc2hhcmVzKSwgYGVuZGAgd2hlcmUgdGhhdCB3YWxrIGVuZHMgZm9yIHRoaXMgdW5pdCAoc2VlIHdhbGtFbmRlZCk6IGFcbi8vIGdyb3VwIHNlbnQgdG8gYW4gaXNsYW5kIHN0YW5kcyByb3VuZCB0aGUgc2hvcmUgYWNyb3NzIGZyb20gaXQsIG5ldmVyIHdpdGhpbiB0d28gYm9kaWVzIG9mIHRoZSBpc2xhbmQncyBwb2ludC5cbmZ1bmN0aW9uIHJlc3RzQWdhaW5zdEFycml2ZWRGcmllbmQoZ2FtZTogR2FtZSwgdW5pdDogVW5pdCwgZ29hbDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCBlbmQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSkge1xuICBjb25zdCBnYXAgPSBkaXN0YW5jZSh1bml0LCBlbmQpO1xuICBpZiAoZ2FwID4gQ1JPV0RfUkVBQ0gpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgZnJpZW5kID0gZmlyc3ROZWFyYnlVbml0KGdhbWUsIHVuaXQsIHVuaXQucmFkaXVzICsgTUFYX1VOSVRfUkFESVVTICsgMiwgKG90aGVyKSA9PiB7XG4gICAgaWYgKG90aGVyID09PSB1bml0IHx8IG90aGVyLm93bmVyICE9PSB1bml0Lm93bmVyIHx8IGRpc3RhbmNlKG90aGVyLCB1bml0KSA+IG90aGVyLnJhZGl1cyArIHVuaXQucmFkaXVzICsgMikgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IHRoZXJlID0gb3RoZXIub3JkZXIudHlwZSA9PT0gXCJpZGxlXCIgJiYgb3RoZXIuYXJyaXZlZEF0Py54ID09PSBnb2FsLnggJiYgb3RoZXIuYXJyaXZlZEF0LnkgPT09IGdvYWwueTtcbiAgICAvLyBSb3VuZCB0aGUgcG9pbnQgaXRzZWxmICh3aXRoaW4gdHdvIGJvZGllcyBvZiBpdCkgYSBmcmllbmQgc3RpbGwgd2Fsa2luZyB0aGVyZSBjb3VudHMgdG9vOiB0aHJlZSBhcmNoZXJzIHByZXNzaW5nXG4gICAgLy8gcm91bmQgYSBwb2ludCwgbm9uZSBvZiB0aGVtIHdpdGhpbiByZWFjaCBvZiBpdCwgY2lyY2xlZCBpdCBmb3IgZ29vZCB3aXRoIG5vYm9keSB0aGVyZSB5ZXQgdG8gc3RvcCBhZ2FpbnN0LlxuICAgIGNvbnN0IGh1ZGRsZWQgPSBnYXAgPD0gMiAqICh1bml0LnJhZGl1cyArIG90aGVyLnJhZGl1cykgJiYgKG90aGVyLm9yZGVyLnR5cGUgPT09IFwibW92ZVwiIHx8IG90aGVyLm9yZGVyLnR5cGUgPT09IFwiYXR0YWNrTW92ZVwiKSAmJiBvdGhlci5vcmRlci54ID09PSBnb2FsLnggJiYgb3RoZXIub3JkZXIueSA9PT0gZ29hbC55O1xuICAgIHJldHVybiB0aGVyZSB8fCBodWRkbGVkO1xuICB9KTtcbiAgcmV0dXJuIGZyaWVuZCAhPT0gdW5kZWZpbmVkO1xufVxuXG4vLyBBIGxhbmQgdW5pdCBhIGZvb3RwcmludCBoYXMgY29tZSBkb3duIG9uIChhIHNpdGUgbGFpZCB3aGVyZSBpdCBzdG9vZCwgYSB1bml0IHNldCBkb3duIGJ5IGEgYnVpbGRpbmcpIHN0ZXBzIG91dCB0byB0aGVcbi8vIGNlbnRlciBvZiB0aGUgb3BlbiBjZWxsIG5lYXJlc3QgaXQgKHNlZSBpc09wZW5Hcm91bmQpOyBvbmUgb24gZ3JvdW5kIG5vdGhpbmcgd2Fsa3MgKG9ubHkgYSBzZWVkZWQgc2NlbmFyaW8gcHV0cyBpdFxuLy8gdGhlcmUpIHdhbGtzIG91dCAoc2VlIEBAQHRlcnJhaW4td2FsaykuXG5mdW5jdGlvbiBrZWVwVW5pdHNPdXRPZkJ1aWxkaW5ncyhnYW1lOiBHYW1lKSB7XG4gIGNvbnN0IG1hcCA9IGdhbWUubWFwO1xuICBmb3IgKGNvbnN0IHVuaXQgb2YgZ2FtZS51bml0cykge1xuICAgIGlmKHVuaXQuZGVjayljb250aW51ZTtcbiAgICBpZiAodW5pdE1vdmVyKHVuaXQua2luZCkgIT09IFwibGFuZFwiIHx8IGlzT3Blbkdyb3VuZChtYXAsIHVuaXQueCwgdW5pdC55KSB8fCAhaXNXYWxrYWJsZShtYXAsIHVuaXQueCwgdW5pdC55KSkgY29udGludWU7XG4gICAgY29uc3Qgb3V0ID0gb3Blbkdyb3VuZE5lYXIobWFwLCB1bml0KTtcbiAgICBpZiAoIW91dCkgY29udGludWU7XG4gICAgdW5pdC54ID0gb3V0Lng7XG4gICAgdW5pdC55ID0gb3V0Lnk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2xpZGVVbml0cyhnYW1lOiBHYW1lKSB7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSBpZiAoIWlzSW5DYWJpbih1bml0KSAmJiB1bml0LnB1c2hYICE9PSB1bmRlZmluZWQpIHtcbiAgICBpZighdW5pdC5kZWNrKXtcbiAgICAgIGNvbnN0IGZyb209e3g6dW5pdC54LHk6dW5pdC55fTtzbGlkZSh1bml0LGdhbWUubWFwLGdhbWUudW5pdHMpO1xuICAgICAgY29uc3QgYXQ9Y29uc3RyYWluR3JvdW5kU2hpcFN0ZXAoZ2FtZS5tYXAsdW5pdCxmcm9tLHVuaXQsZ2FtZS51bml0cyk7XG4gICAgICBpZihhdC54IT09dW5pdC54IHx8IGF0LnkhPT11bml0Lnkpe3VuaXQueD1hdC54O3VuaXQueT1hdC55O3VuaXQucHVzaFg9dW5kZWZpbmVkO3VuaXQucHVzaFk9dW5kZWZpbmVkO31cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBwb2ludD17eDp1bml0LngrcGVyVGljayh1bml0LnB1c2hYKSx5OnVuaXQueStwZXJUaWNrKHVuaXQucHVzaFk/PzApfTtcbiAgICBjb25zdCBhdD1kZWNrU2VwYXJhdGlvblBvaW50KGdhbWUsdW5pdCxwb2ludCk7XG4gICAgT2JqZWN0LmFzc2lnbih1bml0LHt4OmF0LngseTphdC55fSk7XG4gICAgY29uc3Qgc3BlZWQ9TWF0aC5oeXBvdCh1bml0LnB1c2hYLHVuaXQucHVzaFk/PzApLG5leHQ9TWF0aC5tYXgoMCxzcGVlZC1wZXJUaWNrKFBVU0hfRlJJQ1RJT04pKTtcbiAgICBpZihuZXh0PT09MCB8fCBhdD09PXVuaXQpe3VuaXQucHVzaFg9dW5kZWZpbmVkO3VuaXQucHVzaFk9dW5kZWZpbmVkO31lbHNle3VuaXQucHVzaFgqPW5leHQvc3BlZWQ7dW5pdC5wdXNoWT0odW5pdC5wdXNoWT8/MCkqbmV4dC9zcGVlZDt9XG4gIH1cbn1cblxudHlwZSBTZXBhcmF0aW9uQnVja2V0ID0geyBrZXk6IG51bWJlcjsgc2xvdDogbnVtYmVyOyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdW5pdHM6IChVbml0IHwgdW5kZWZpbmVkKVtdOyBjb3VudDogbnVtYmVyIH07XG50eXBlIFNlcGFyYXRpb25GcmFtZSA9IHtcbiAgYnVja2V0czogU2VwYXJhdGlvbkJ1Y2tldFtdO1xuICBsb29rdXA6IChTZXBhcmF0aW9uQnVja2V0IHwgdW5kZWZpbmVkKVtdO1xuICBtYXNrOiBudW1iZXI7XG4gIHNoaWZ0OiBudW1iZXI7XG4gIHBvb2w6IFNlcGFyYXRpb25CdWNrZXRbXTtcbiAgbWVtYmVyczogVW5pdFtdO1xuICBjZWxsWDogbnVtYmVyW107XG4gIGNlbGxZOiBudW1iZXJbXTtcbiAgeDogbnVtYmVyW107XG4gIHk6IG51bWJlcltdO1xuICAvLyBGbGF0dGVuZWQgYnVja2V0IHBhaXJzIHByZXNlcnZlIHRoZSBvcmlnaW5hbCBtYXAgYW5kIG5laWdoYm9yIHRyYXZlcnNhbC5cbiAgcGFpcnM6IFNlcGFyYXRpb25CdWNrZXRbXTtcbiAgdmFsaWQ6IGJvb2xlYW47XG4gIHVuY2hhbmdlZFNvdXJjZTogbnVtYmVyO1xuICB1bmNoYW5nZWRNZW1iZXJzOiBudW1iZXI7XG59O1xuY29uc3Qgc2VwYXJhdGlvbkZyYW1lcyA9IG5ldyBXZWFrTWFwPEdhbWUsIFNlcGFyYXRpb25GcmFtZT4oKTtcblxuZnVuY3Rpb24gY2xlYXJTZXBhcmF0aW9uQnVja2V0cyhmcmFtZTogU2VwYXJhdGlvbkZyYW1lKSB7XG4gIGZvciAoY29uc3QgYnVja2V0IG9mIGZyYW1lLmJ1Y2tldHMpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJ1Y2tldC5jb3VudDsgaSArPSAxKSBidWNrZXQudW5pdHNbaV0gPSB1bmRlZmluZWQ7XG4gICAgYnVja2V0LmNvdW50ID0gMDtcbiAgICBmcmFtZS5sb29rdXBbYnVja2V0LnNsb3RdID0gdW5kZWZpbmVkO1xuICB9XG4gIGZyYW1lLmJ1Y2tldHMubGVuZ3RoID0gMDtcbiAgZnJhbWUucGFpcnMubGVuZ3RoID0gMDtcbiAgZnJhbWUudmFsaWQgPSBmYWxzZTtcbn1cblxuZnVuY3Rpb24gY2xlYXJTZXBhcmF0aW9uTWVtYmVyc2hpcChmcmFtZTogU2VwYXJhdGlvbkZyYW1lKSB7XG4gIGNsZWFyU2VwYXJhdGlvbkJ1Y2tldHMoZnJhbWUpO1xuICBmcmFtZS5tZW1iZXJzLmxlbmd0aCA9IGZyYW1lLmNlbGxYLmxlbmd0aCA9IGZyYW1lLmNlbGxZLmxlbmd0aCA9IGZyYW1lLngubGVuZ3RoID0gZnJhbWUueS5sZW5ndGggPSAwO1xufVxuXG5mdW5jdGlvbiBpbnZhbGlkYXRlU2VwYXJhdGlvbkZyYW1lKGdhbWU6IEdhbWUpIHtcbiAgY29uc3QgZnJhbWUgPSBzZXBhcmF0aW9uRnJhbWVzLmdldChnYW1lKTtcbiAgaWYgKGZyYW1lKSBjbGVhclNlcGFyYXRpb25NZW1iZXJzaGlwKGZyYW1lKTtcbn1cblxuLy8gS2VlcCBhIGJvdW5kZWQgcmV1c2FibGUgbG9va3VwIHNlcGFyYXRlIGZyb20gZmlyc3QtZW5jb3VudGVyIHRyYXZlcnNhbC5cbi8vIEV4YWN0IG51bWVyaWMga2V5cyByZXRhaW4gTWFwJ3MgU2FtZVZhbHVlWmVybyBiZWhhdmlvciwgaW5jbHVkaW5nIE5hTiBhbmRcbi8vIHNpZ25lZCB6ZXJvOyBoYXNoaW5nIG9ubHkgc2VsZWN0cyBhIHByb2JlIHN0YXJ0LCBuZXZlciBjaGFuZ2VzIGtleSBlcXVhbGl0eS5cbmZ1bmN0aW9uIHNlcGFyYXRpb25CdWNrZXRTbG90KGZyYW1lOiBTZXBhcmF0aW9uRnJhbWUsIGtleTogbnVtYmVyKTogbnVtYmVyIHtcbiAgbGV0IHNsb3QgPSBNYXRoLmltdWwoa2V5LCAweDllMzc3OWIxKSA+Pj4gZnJhbWUuc2hpZnQ7XG4gIGxldCBidWNrZXQ6IFNlcGFyYXRpb25CdWNrZXQgfCB1bmRlZmluZWQ7XG4gIHdoaWxlICgoYnVja2V0ID0gZnJhbWUubG9va3VwW3Nsb3RdKSkge1xuICAgIGlmIChidWNrZXQua2V5ID09PSBrZXkgfHwgYnVja2V0LmtleSAhPT0gYnVja2V0LmtleSAmJiBrZXkgIT09IGtleSkgcmV0dXJuIHNsb3Q7XG4gICAgc2xvdCA9IChzbG90ICsgMSkgJiBmcmFtZS5tYXNrO1xuICB9XG4gIHJldHVybiBzbG90O1xufVxuXG5mdW5jdGlvbiBzZXBhcmF0aW9uTWVtYmVyc2hpcE1hdGNoZXMoZ2FtZTogR2FtZSwgZnJhbWU6IFNlcGFyYXRpb25GcmFtZSwgY2VsbFNpemU6IG51bWJlciwgbmF2YWxGcmFtZTogYm9vbGVhbik6IGJvb2xlYW4ge1xuICBmcmFtZS51bmNoYW5nZWRTb3VyY2UgPSBmcmFtZS51bmNoYW5nZWRNZW1iZXJzID0gMDtcbiAgaWYgKCFmcmFtZS52YWxpZCkgcmV0dXJuIGZhbHNlO1xuICBsZXQgbWVtYmVyID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBnYW1lLnVuaXRzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgY29uc3QgdW5pdCA9IGdhbWUudW5pdHNbaV0hO1xuICAgIC8vIE9yZGVycywgY2FiaW4gc3RhdGUgYW5kIHVuaXQga2luZCBjYW4gY2hhbmdlIHdpdGhvdXQgcmVwbGFjaW5nIHRoZSBhcnJheS5cbiAgICAvLyBUaGUgbmF0aXZlIGdyb3VuZGVkIGZyYW1lIGFscmVhZHkgY2hlY2tlZCBldmVyeSBib2R5LCBpbmNsdWRpbmcgYmlydGhzLlxuICAgIGlmIChuYXZhbEZyYW1lICYmIChpc0luQ2FiaW4odW5pdCkgfHwgaXNTaGlwS2luZCh1bml0LmtpbmQpKSB8fCBtaW5lckdob3N0KHVuaXQpKSBjb250aW51ZTtcbiAgICBpZiAoZnJhbWUubWVtYmVyc1ttZW1iZXJdICE9PSB1bml0XG4gICAgICB8fCAhT2JqZWN0LmlzKGZyYW1lLnhbbWVtYmVyXSwgdW5pdC54KSAmJiAhT2JqZWN0LmlzKGZyYW1lLmNlbGxYW21lbWJlcl0sIE1hdGguZmxvb3IodW5pdC54IC8gY2VsbFNpemUpKVxuICAgICAgfHwgIU9iamVjdC5pcyhmcmFtZS55W21lbWJlcl0sIHVuaXQueSkgJiYgIU9iamVjdC5pcyhmcmFtZS5jZWxsWVttZW1iZXJdLCBNYXRoLmZsb29yKHVuaXQueSAvIGNlbGxTaXplKSkpIHtcbiAgICAgIGZyYW1lLnVuY2hhbmdlZFNvdXJjZSA9IGk7IGZyYW1lLnVuY2hhbmdlZE1lbWJlcnMgPSBtZW1iZXI7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIC8vIFJlY29yZCB2ZXJpZmllZCB3aXRoaW4tY2VsbCBtb3ZlbWVudDsgY29udGFjdHMgc3RpbGwgcmVhZCBsaXZlIGdlb21ldHJ5LlxuICAgIGZyYW1lLnhbbWVtYmVyXSA9IHVuaXQueDsgZnJhbWUueVttZW1iZXJdID0gdW5pdC55O1xuICAgIG1lbWJlciArPSAxO1xuICB9XG4gIGZyYW1lLnVuY2hhbmdlZFNvdXJjZSA9IGdhbWUudW5pdHMubGVuZ3RoOyBmcmFtZS51bmNoYW5nZWRNZW1iZXJzID0gbWVtYmVyO1xuICByZXR1cm4gbWVtYmVyID09PSBmcmFtZS5tZW1iZXJzLmxlbmd0aDtcbn1cblxuZnVuY3Rpb24gc2VwYXJhdGVVbml0cyhnYW1lOiBHYW1lLCBuYXZhbEZyYW1lOiBib29sZWFuKSB7XG4gIGNvbnN0IGNlbGxTaXplID0gODA7XG4gIGxldCBmcmFtZSA9IHNlcGFyYXRpb25GcmFtZXMuZ2V0KGdhbWUpO1xuICBpZiAoIWZyYW1lKSB7XG4gICAgZnJhbWUgPSB7IGJ1Y2tldHM6IFtdLCBsb29rdXA6IG5ldyBBcnJheSgxNiksIG1hc2s6IDE1LCBzaGlmdDogMjgsIHBvb2w6IFtdLCBtZW1iZXJzOiBbXSwgY2VsbFg6IFtdLCBjZWxsWTogW10sIHg6IFtdLCB5OiBbXSwgcGFpcnM6IFtdLCB2YWxpZDogZmFsc2UsIHVuY2hhbmdlZFNvdXJjZTogMCwgdW5jaGFuZ2VkTWVtYmVyczogMCB9O1xuICAgIHNlcGFyYXRpb25GcmFtZXMuc2V0KGdhbWUsIGZyYW1lKTtcbiAgfVxuICBjb25zdCBidWNrZXRzID0gZnJhbWUuYnVja2V0cztcbiAgY29uc3QgYVBvaW50ID0geyB4OiAwLCB5OiAwIH0sIGJQb2ludCA9IHsgeDogMCwgeTogMCB9O1xuICBjb25zdCBvcGVuR3JvdW5kID0gIWdhbWUubWFwLnRlcnJhaW4gJiYgZ3JvdW5kU2hpcEZyYW1lRW1wdHkoZ2FtZS51bml0cyk7XG4gIGlmICghc2VwYXJhdGlvbk1lbWJlcnNoaXBNYXRjaGVzKGdhbWUsIGZyYW1lLCBjZWxsU2l6ZSwgbmF2YWxGcmFtZSkpIHtcbiAgICAvLyBUaGUgdmVyaWZpZWQgcHJlZml4IGFscmVhZHkgaGFzIHRoaXMgZnJhbWUncyBleGFjdCBjZWxscyBhbmQgc291cmNlXG4gICAgLy8gb3JkZXIuIFJldGFpbiBpdHMgcHJpdmF0ZSBtZXRhZGF0YSB3aGlsZSByZWJ1aWxkaW5nIGJ1Y2tldCBzdG9yYWdlO1xuICAgIC8vIGNsYXNzaWZ5IG9ubHkgdGhlIHN1ZmZpeCBzdGFydGluZyBhdCB0aGUgZmlyc3QgYWN0dWFsIG1pc21hdGNoLlxuICAgIGNvbnN0IHByZWZpeCA9IGZyYW1lLnVuY2hhbmdlZE1lbWJlcnMsIHNvdXJjZVN0YXJ0ID0gZnJhbWUudW5jaGFuZ2VkU291cmNlO1xuICAgIGNsZWFyU2VwYXJhdGlvbkJ1Y2tldHMoZnJhbWUpO1xuICAgIC8vIEF0IG1vc3Qgb25lIGJ1Y2tldCBwZXIgc291cmNlIHVuaXQsIHdpdGggbG9hZCBubyBncmVhdGVyIHRoYW4gb25lIGhhbGYuXG4gICAgbGV0IGNhcGFjaXR5ID0gZnJhbWUubWFzayArIDEsIHNoaWZ0ID0gZnJhbWUuc2hpZnQ7XG4gICAgd2hpbGUgKGNhcGFjaXR5IDwgZ2FtZS51bml0cy5sZW5ndGggKiAyKSB7IGNhcGFjaXR5ICo9IDI7IHNoaWZ0IC09IDE7IH1cbiAgICBpZiAoY2FwYWNpdHkgIT09IGZyYW1lLm1hc2sgKyAxKSB7XG4gICAgICBmcmFtZS5sb29rdXAgPSBuZXcgQXJyYXkoY2FwYWNpdHkpOyBmcmFtZS5tYXNrID0gY2FwYWNpdHkgLSAxOyBmcmFtZS5zaGlmdCA9IHNoaWZ0O1xuICAgIH1cbiAgICBsZXQgdXNlZCA9IDAsIG1lbWJlciA9IDA7XG4gICAgLy8gUHJlZml4IG1ldGFkYXRhIGlzIG92ZXJ3cml0dGVuIG9ubHkgYnkgaXRzIGlkZW50aWNhbCB2ZXJpZmllZCBtZW1iZXIuXG4gICAgLy8gT25jZSBjb25zdW1lZCwgc3VmZml4IHNsb3RzIGNhbiByZXBsYWNlIG9sZCBsaXZlIHJlZmVyZW5jZXMgc2FmZWx5LlxuICAgIGNvbnN0IGluc2VydCA9ICh1bml0OiBVbml0LCB4OiBudW1iZXIsIHk6IG51bWJlcikgPT4ge1xuICAgICAgY29uc3Qga2V5ID0gbnVtZXJpY0J1Y2tldEtleSh4LCB5KTtcbiAgICAgIGNvbnN0IHNsb3QgPSBzZXBhcmF0aW9uQnVja2V0U2xvdChmcmFtZSwga2V5KTtcbiAgICAgIGxldCBidWNrZXQgPSBmcmFtZS5sb29rdXBbc2xvdF07XG4gICAgICBpZiAoIWJ1Y2tldCkge1xuICAgICAgICBidWNrZXQgPSBmcmFtZS5wb29sW3VzZWQrK107XG4gICAgICAgIGlmIChidWNrZXQpIHtcbiAgICAgICAgICBidWNrZXQua2V5ID0ga2V5OyBidWNrZXQuc2xvdCA9IHNsb3Q7IGJ1Y2tldC54ID0geDsgYnVja2V0LnkgPSB5OyBidWNrZXQuY291bnQgPSAwO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJ1Y2tldCA9IHsga2V5LCBzbG90LCB4LCB5LCB1bml0czogW10sIGNvdW50OiAwIH07XG4gICAgICAgICAgZnJhbWUucG9vbC5wdXNoKGJ1Y2tldCk7XG4gICAgICAgIH1cbiAgICAgICAgZnJhbWUubG9va3VwW3Nsb3RdID0gYnVja2V0O1xuICAgICAgICBidWNrZXRzLnB1c2goYnVja2V0KTtcbiAgICAgIH1cbiAgICAgIGZyYW1lLm1lbWJlcnNbbWVtYmVyXSA9IHVuaXQ7XG4gICAgICBmcmFtZS54W21lbWJlcl0gPSB1bml0Lng7IGZyYW1lLnlbbWVtYmVyXSA9IHVuaXQueTtcbiAgICAgIGZyYW1lLmNlbGxYW21lbWJlcl0gPSB4OyBmcmFtZS5jZWxsWVttZW1iZXIrK10gPSB5O1xuICAgICAgYnVja2V0LnVuaXRzW2J1Y2tldC5jb3VudCsrXSA9IHVuaXQ7XG4gICAgfTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByZWZpeDsgaSArPSAxKSBpbnNlcnQoZnJhbWUubWVtYmVyc1tpXSEsIGZyYW1lLmNlbGxYW2ldISwgZnJhbWUuY2VsbFlbaV0hKTtcbiAgICBmb3IgKGxldCBpID0gc291cmNlU3RhcnQ7IGkgPCBnYW1lLnVuaXRzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICBjb25zdCB1bml0ID0gZ2FtZS51bml0c1tpXSE7XG4gICAgICAvLyBIdWxscyB1c2Ugc3dlcHQgbmF2aWdhdGlvbiBjb250YWN0OyBtaW5pbmcgd29ya2VycyBwYXNzIHRocm91Z2ggYm9kaWVzLlxuICAgICAgaWYgKG5hdmFsRnJhbWUgJiYgKGlzSW5DYWJpbih1bml0KSB8fCBpc1NoaXBLaW5kKHVuaXQua2luZCkpIHx8IG1pbmVyR2hvc3QodW5pdCkpIGNvbnRpbnVlO1xuICAgICAgaW5zZXJ0KHVuaXQsIE1hdGguZmxvb3IodW5pdC54IC8gY2VsbFNpemUpLCBNYXRoLmZsb29yKHVuaXQueSAvIGNlbGxTaXplKSk7XG4gICAgfVxuICAgIGZyYW1lLm1lbWJlcnMubGVuZ3RoID0gZnJhbWUuY2VsbFgubGVuZ3RoID0gZnJhbWUuY2VsbFkubGVuZ3RoID0gZnJhbWUueC5sZW5ndGggPSBmcmFtZS55Lmxlbmd0aCA9IG1lbWJlcjtcbiAgICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBidWNrZXRzKSB7XG4gICAgICBmcmFtZS5wYWlycy5wdXNoKGJ1Y2tldCwgYnVja2V0KTtcbiAgICAgIGZvciAoY29uc3QgW294LCBveV0gb2YgU0VQQVJBVElPTl9ORUlHSEJPUlMpIHtcbiAgICAgICAgY29uc3QgbmVpZ2hib3IgPSBmcmFtZS5sb29rdXBbc2VwYXJhdGlvbkJ1Y2tldFNsb3QoZnJhbWUsIG51bWVyaWNCdWNrZXRLZXkoYnVja2V0LnggKyBveCwgYnVja2V0LnkgKyBveSkpXTtcbiAgICAgICAgaWYgKG5laWdoYm9yKSBmcmFtZS5wYWlycy5wdXNoKGJ1Y2tldCwgbmVpZ2hib3IpO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBDYXB0dXJlZCBjZWxscyBkZXNjcmliZSBwb3NpdGlvbnMgYmVmb3JlIGNvbGxpc2lvbiBwYWlycyBtb3ZlIGJvZGllcy5cbiAgICBmcmFtZS52YWxpZCA9IHRydWU7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBmcmFtZS5wYWlycy5sZW5ndGg7IGkgKz0gMikge1xuICAgIHNlcGFyYXRlVW5pdEJ1Y2tldHMoZ2FtZSwgZnJhbWUucGFpcnNbaV0hLCBmcmFtZS5wYWlyc1tpICsgMV0hLCBhUG9pbnQsIGJQb2ludCwgb3Blbkdyb3VuZCwgbmF2YWxGcmFtZSk7XG4gIH1cbiAgLy8gQnVja2V0cyBhbmQgbWV0YWRhdGEgcmV0YWluIHRoZSBzYW1lIGJvdW5kZWQgbGl2ZSBtZW1iZXJzaGlwLiBSZW1vdmFsLFxuICAvLyByZXN0b3JlIGFuZCBhbnkgbWVtYmVyc2hpcCBjaGFuZ2UgY2xlYXIgYm90aCBiZWZvcmUgc3RvcmFnZSBpcyByZXVzZWQuXG59XG5cbmNvbnN0IFNFUEFSQVRJT05fTkVJR0hCT1JTID0gW1xuICBbMSwgLTFdLFxuICBbMSwgMF0sXG4gIFsxLCAxXSxcbiAgWzAsIDFdLFxuXSBhcyBjb25zdDtcblxuZnVuY3Rpb24gc2VwYXJhdGVVbml0QnVja2V0cyhnYW1lOiBHYW1lLCBhQnVja2V0OiBTZXBhcmF0aW9uQnVja2V0LCBiQnVja2V0OiBTZXBhcmF0aW9uQnVja2V0LCBhUG9pbnQ6IFNwYXRpYWxFbnRpdHksIGJQb2ludDogU3BhdGlhbEVudGl0eSwgb3Blbkdyb3VuZDogYm9vbGVhbiwgbmF2YWxGcmFtZTogYm9vbGVhbikge1xuICBjb25zdCBhVW5pdHMgPSBhQnVja2V0LnVuaXRzLCBiVW5pdHMgPSBiQnVja2V0LnVuaXRzO1xuICBjb25zdCBzYW1lQnVja2V0ID0gYUJ1Y2tldCA9PT0gYkJ1Y2tldDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhQnVja2V0LmNvdW50OyBpICs9IDEpIHtcbiAgICBjb25zdCBzdGFydCA9IHNhbWVCdWNrZXQgPyBpICsgMSA6IDA7XG4gICAgY29uc3QgYSA9IGFVbml0c1tpXSE7XG4gICAgZm9yIChsZXQgaiA9IHN0YXJ0OyBqIDwgYkJ1Y2tldC5jb3VudDsgaiArPSAxKSB7XG4gICAgICBjb25zdCBiID0gYlVuaXRzW2pdITtcbiAgICAgIGNvbnN0IG1pbkRpc3RhbmNlID0gYS5yYWRpdXMgKyBiLnJhZGl1cztcbiAgICAgIGNvbnN0IGR4ID0gYi54IC0gYS54O1xuICAgICAgY29uc3QgZHkgPSBiLnkgLSBhLnk7XG4gICAgICBjb25zdCBkaXN0YW5jZVNxID0gZHggKiBkeCArIGR5ICogZHk7XG4gICAgICBpZiAoZGlzdGFuY2VTcSA+PSBtaW5EaXN0YW5jZSAqIG1pbkRpc3RhbmNlKSBjb250aW51ZTtcbiAgICAgIHNlcGFyYXRlVW5pdFBhaXIoZ2FtZSwgYSwgYiwgbWluRGlzdGFuY2UsIGR4LCBkeSwgYVBvaW50LCBiUG9pbnQsIG9wZW5Hcm91bmQsIG5hdmFsRnJhbWUpO1xuICAgIH1cbiAgfVxufVxuXG4vLyBAQEBtaW5lci1naG9zdCAtIEEgd29ya2VyIG9uIGEgbWluaW5nIHJ1biBwYXNzZXMgdGhyb3VnaCBvdGhlciB1bml0cywgYXMgaW4gV2FyY3JhZnQgSUlJIGFuZCBTdGFyQ3JhZnQ6XG4vLyB3aXRoIGEgdG93ZXIgb3IgYSBmYXJtIGJ5IHRoZSBsYW5lLCB0ZW4gd29ya2VycyBnb2luZyB0byBhbmQgZnJvIGphbW1lZCBpblxuLy8gdGhlIGdhcCBhbmQgc3Rvb2QgdGhlcmUgZm9yIG1pbnV0ZXMuIEl0IHN0aWxsIHdhbGtzIHJvdW5kIGJ1aWxkaW5ncy5cbmZ1bmN0aW9uIG1pbmVyR2hvc3QodW5pdDogVW5pdCkge1xuICByZXR1cm4gdW5pdC5raW5kID09PSBcIndvcmtlclwiICYmIHVuaXQub3JkZXIudHlwZSA9PT0gXCJtaW5lXCI7XG59XG5cbi8vIEh1bGxzIGFyZSBjb25zdHJhaW5lZCBieSBzd2VwdCBtb3Rpb24uIEdyb3VuZCBzZXBhcmF0aW9uIGNhbm5vdCBwdXNoIGEgYm9keVxuLy8gdW5kZXJuZWF0aCBhIHJlYWNoYWJsZSBodWxsOyBwYXNzZW5nZXJzIHVzZSB0aGUgZGVjaydzIGxvY2FsIGZsb29yIGluc3RlYWQuXG5mdW5jdGlvbiBzZXBhcmF0ZVVuaXRQYWlyKGdhbWU6IEdhbWUsIGE6IFVuaXQsIGI6IFVuaXQsIG1pbkRpc3RhbmNlOiBudW1iZXIsIGR4OiBudW1iZXIsIGR5OiBudW1iZXIsIGFQb2ludDogU3BhdGlhbEVudGl0eSwgYlBvaW50OiBTcGF0aWFsRW50aXR5LCBvcGVuR3JvdW5kOiBib29sZWFuLCBuYXZhbEZyYW1lOiBib29sZWFuKSB7XG4gIGxldCBhTW92ZXI6IFJldHVyblR5cGU8dHlwZW9mIHVuaXRNb3Zlcj4gPSAnbGFuZCcsIGJNb3ZlcjogUmV0dXJuVHlwZTx0eXBlb2YgdW5pdE1vdmVyPiA9ICdsYW5kJztcbiAgaWYgKG5hdmFsRnJhbWUpIHtcbiAgICBpZihhLmRlY2sgfHwgYi5kZWNrKXtpZighYS5kZWNrIHx8ICFiLmRlY2sgfHwgYS5kZWNrLnNoaXBJZCE9PWIuZGVjay5zaGlwSWQpcmV0dXJuO31cbiAgICBhTW92ZXIgPSB1bml0TW92ZXIoYS5raW5kKTsgYk1vdmVyID0gdW5pdE1vdmVyKGIua2luZCk7XG4gICAgaWYgKGFNb3ZlciAhPT0gYk1vdmVyKSByZXR1cm47XG4gIH1cbiAgY29uc3QgbGVuZ3RoID0gaHlwb3QyKGR4LCBkeSk7XG4gIGNvbnN0IG54ID0gbGVuZ3RoID09PSAwID8gMSA6IGR4IC8gbGVuZ3RoO1xuICBjb25zdCBueSA9IGxlbmd0aCA9PT0gMCA/IDAgOiBkeSAvIGxlbmd0aDtcbiAgaWYgKGEucHVzaFggIT09IHVuZGVmaW5lZCB8fCBiLnB1c2hYICE9PSB1bmRlZmluZWQpIHB1c2hDb250YWN0KGEsIGIsIG54LCBueSk7XG4gIGNvbnN0IHB1c2ggPSAobWluRGlzdGFuY2UgLSBsZW5ndGgpIC8gMjtcbiAgY29uc3QgYXggPSBjbGFtcChhLnggLSBueCAqIHB1c2gsIDAsIGdhbWUubWFwLndpZHRoKTtcbiAgY29uc3QgYXkgPSBjbGFtcChhLnkgLSBueSAqIHB1c2gsIDAsIGdhbWUubWFwLmhlaWdodCk7XG4gIGNvbnN0IGJ4ID0gY2xhbXAoYi54ICsgbnggKiBwdXNoLCAwLCBnYW1lLm1hcC53aWR0aCk7XG4gIGNvbnN0IGJ5ID0gY2xhbXAoYi55ICsgbnkgKiBwdXNoLCAwLCBnYW1lLm1hcC5oZWlnaHQpO1xuICBpZiAob3Blbkdyb3VuZCAmJiAhYS5kZWNrICYmICFiLmRlY2spIHtcbiAgICAvLyBPcGVuIHRlcnJhaW4gYW5kIGFuIGluaXRpYWxpemVkIGVtcHR5IGh1bGwgZnJhbWUgcmV0dXJuIHRoZXNlIGV4YWN0XG4gICAgLy8gZW5kcG9pbnRzOyByZXRhaW4gdGhlIGNvbnN0cmFpbmVkIHBhdGggZm9yIGV2ZXJ5IGRlY2sgb3IgaHVsbCBjb250YWN0LlxuICAgIGEueCA9IGF4OyBhLnkgPSBheTsgYi54ID0gYng7IGIueSA9IGJ5O1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBOZWl0aGVyIGlzIHB1c2hlZCBvbnRvIGdyb3VuZCBpdCBjYW5ub3Qgc3RhbmQgb24gKHNlZSBAQEB0ZXJyYWluKTogb25lIGJ5IGEgd2FsbCBzbGlkZXMgYWxvbmcgaXQgKHNlZSBvcGVuU3RlcCkuXG4gIGFQb2ludC54ID0gYXg7IGFQb2ludC55ID0gYXk7XG4gIGNvbnN0IGFBdCA9ICFuYXZhbEZyYW1lID8gb3BlblN0ZXAoZ2FtZS5tYXAsIGEsIGFQb2ludCwgJ2xhbmQnKVxuICAgIDogYS5kZWNrID8gZGVja1NlcGFyYXRpb25Qb2ludChnYW1lLGEsYVBvaW50KSA6IGNvbnN0cmFpbkdyb3VuZFNoaXBTdGVwKGdhbWUubWFwLGEsYSxvcGVuU3RlcChnYW1lLm1hcCwgYSwgYVBvaW50LCBhTW92ZXIpLGdhbWUudW5pdHMpO1xuICBiUG9pbnQueCA9IGJ4OyBiUG9pbnQueSA9IGJ5O1xuICBjb25zdCBiQXQgPSAhbmF2YWxGcmFtZSA/IG9wZW5TdGVwKGdhbWUubWFwLCBiLCBiUG9pbnQsICdsYW5kJylcbiAgICA6IGIuZGVjayA/IGRlY2tTZXBhcmF0aW9uUG9pbnQoZ2FtZSxiLGJQb2ludCkgOiBjb25zdHJhaW5Hcm91bmRTaGlwU3RlcChnYW1lLm1hcCxiLGIsb3BlblN0ZXAoZ2FtZS5tYXAsIGIsIGJQb2ludCwgYk1vdmVyKSxnYW1lLnVuaXRzKTtcbiAgYS54ID0gYUF0Lng7XG4gIGEueSA9IGFBdC55O1xuICBiLnggPSBiQXQueDtcbiAgYi55ID0gYkF0Lnk7XG59XG5cbmZ1bmN0aW9uIGRlY2tTZXBhcmF0aW9uUG9pbnQoZ2FtZTpHYW1lLHVuaXQ6VW5pdCxwb2ludDp7eDpudW1iZXI7eTpudW1iZXJ9KSB7XG4gIGNvbnN0IHNoaXA9Z2FtZS51bml0cy5maW5kKHNoaXA9PnNoaXAuaWQ9PT11bml0LmRlY2shLnNoaXBJZCk7XG4gIGlmKCFzaGlwKXJldHVybiB1bml0O1xuICBjb25zdCBsb2NhbD13b3JsZFRvTG9jYWwoc2hpcCxwb2ludCk7XG4gIGlmKCFkZWNrUG9pbnRGaXRzKHNoaXAsdW5pdCxsb2NhbCxnYW1lLnVuaXRzLGZhbHNlKSlyZXR1cm4gdW5pdDtcbiAgT2JqZWN0LmFzc2lnbih1bml0LmRlY2shLGxvY2FsKTtyZXR1cm4gcG9pbnQ7XG59XG5cbmZ1bmN0aW9uIG51bWVyaWNCdWNrZXRLZXkoeDogbnVtYmVyLCB5OiBudW1iZXIpIHtcbiAgcmV0dXJuIHggKiAxMDAwICsgeTtcbn1cblxuZnVuY3Rpb24gc3BhdGlhbEJ1Y2tldEtleShlbnRpdHk6IFNwYXRpYWxFbnRpdHksIGNlbGxTaXplOiBudW1iZXIpIHtcbiAgcmV0dXJuIG51bWVyaWNCdWNrZXRLZXkoTWF0aC5mbG9vcihlbnRpdHkueCAvIGNlbGxTaXplKSwgTWF0aC5mbG9vcihlbnRpdHkueSAvIGNlbGxTaXplKSk7XG59XG5cbmNvbnN0IHNwYXRpYWxNZW1iZXJzaGlwID0gbmV3IFdlYWtNYXA8b2JqZWN0LCB7IG1lbWJlcnM6IFNwYXRpYWxFbnRpdHlbXTsgY2VsbFg6IG51bWJlcltdOyBjZWxsWTogbnVtYmVyW107IHg6IG51bWJlcltdOyB5OiBudW1iZXJbXSB9PigpO1xuXG4vLyBVbmNoYW5nZWQgY29vcmRpbmF0ZXMgc3RpbGwgb2NjdXB5IHRoZWlyIHJlY29yZGVkIGNlbGw7IGNoYW5nZWQgYXhlcyBhcmUgY2xhc3NpZmllZCBub3JtYWxseS5cbmZ1bmN0aW9uIGNyZWF0ZVNwYXRpYWxJbmRleDxUIGV4dGVuZHMgU3BhdGlhbEVudGl0eT4oZW50aXRpZXM6IFRbXSwgY2VsbFNpemU6IG51bWJlciwgcHJldmlvdXM/OiBTcGF0aWFsSW5kZXg8VD4pOiBTcGF0aWFsSW5kZXg8VD4ge1xuICBjb25zdCBjYWNoZWQgPSBwcmV2aW91cyAmJiBPYmplY3QuaXMocHJldmlvdXMuY2VsbFNpemUsIGNlbGxTaXplKSA/IHNwYXRpYWxNZW1iZXJzaGlwLmdldChwcmV2aW91cykgOiB1bmRlZmluZWQ7XG4gIGxldCBwcmVmaXggPSAwO1xuICBpZiAoY2FjaGVkICYmIGNhY2hlZC5tZW1iZXJzLmxlbmd0aCA9PT0gZW50aXRpZXMubGVuZ3RoKSB7XG4gICAgbGV0IHVuY2hhbmdlZCA9IHRydWU7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlbnRpdGllcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgY29uc3QgZW50aXR5ID0gZW50aXRpZXNbaV0hO1xuICAgICAgaWYgKGNhY2hlZC5tZW1iZXJzW2ldICE9PSBlbnRpdHlcbiAgICAgICAgfHwgIU9iamVjdC5pcyhjYWNoZWQueFtpXSwgZW50aXR5LngpICYmICFPYmplY3QuaXMoY2FjaGVkLmNlbGxYW2ldLCBNYXRoLmZsb29yKGVudGl0eS54IC8gY2VsbFNpemUpKVxuICAgICAgICB8fCAhT2JqZWN0LmlzKGNhY2hlZC55W2ldLCBlbnRpdHkueSkgJiYgIU9iamVjdC5pcyhjYWNoZWQuY2VsbFlbaV0sIE1hdGguZmxvb3IoZW50aXR5LnkgLyBjZWxsU2l6ZSkpKSB7XG4gICAgICAgIHVuY2hhbmdlZCA9IGZhbHNlO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhY2hlZC54W2ldID0gZW50aXR5Lng7IGNhY2hlZC55W2ldID0gZW50aXR5Lnk7XG4gICAgICBwcmVmaXggPSBpICsgMTtcbiAgICB9XG4gICAgLy8gQnVja2V0cyBob2xkIGxpdmUgZW50aXR5IHJlZmVyZW5jZXMuIFdpdGhpbiBhIGNlbGwsIG5hcnJvdy1waGFzZSByYW5nZVxuICAgIC8vIGNoZWNrcyBzdGlsbCByZWFkIGN1cnJlbnQgY29vcmRpbmF0ZXM7IG1lbWJlcnNoaXAgYW5kIHZpc2l0IG9yZGVyIG1hdGNoLlxuICAgIGlmICh1bmNoYW5nZWQpIHJldHVybiBwcmV2aW91cyE7XG4gIH1cbiAgY29uc3QgYnVja2V0cyA9IG5ldyBNYXA8bnVtYmVyLCBUW10+KCk7XG4gIC8vIE1lbWJlcnNoaXAgbWV0YWRhdGEgaXMgcHJpdmF0ZS4gVHJhbnNmZXIgaXRzIHN0b3JhZ2UgdG8gdGhlIG5ldyBpbmRleCxcbiAgLy8gbGVhdmluZyB0aGUgcHJldmlvdXMgaW5kZXgncyBwdWJsaWMgYnVja2V0cyB1bnRvdWNoZWQgZm9yIGFjdGl2ZSB2aXNpdG9ycy5cbiAgLy8gQW4gb2xkIGluZGV4IHJlc3RvcmVkIGJ5IGEgY2FsbGVyIG11c3QgcmVidWlsZCwgbmV2ZXIgY29uc3VsdCByZXVzZWQgZGF0YS5cbiAgaWYgKGNhY2hlZCkgc3BhdGlhbE1lbWJlcnNoaXAuZGVsZXRlKHByZXZpb3VzISk7XG4gIGNvbnN0IG1lbWJlcnMgPSBjYWNoZWQ/Lm1lbWJlcnMgPz8gW107XG4gIGNvbnN0IGNlbGxYID0gY2FjaGVkPy5jZWxsWCA/PyBbXSwgY2VsbFkgPSBjYWNoZWQ/LmNlbGxZID8/IFtdO1xuICBjb25zdCBwb3NpdGlvbnNYID0gY2FjaGVkID8gY2FjaGVkLnggOiBbXSwgcG9zaXRpb25zWSA9IGNhY2hlZCA/IGNhY2hlZC55IDogW107XG4gIGxldCBsZWZ0ID0gSW5maW5pdHksIHJpZ2h0ID0gLUluZmluaXR5LCB0b3AgPSBJbmZpbml0eSwgYm90dG9tID0gLUluZmluaXR5O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGVudGl0aWVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgY29uc3QgZW50aXR5ID0gZW50aXRpZXNbaV0hO1xuICAgIGNvbnN0IHggPSBpIDwgcHJlZml4ID8gY2VsbFhbaV0hIDogTWF0aC5mbG9vcihlbnRpdHkueCAvIGNlbGxTaXplKTtcbiAgICBjb25zdCB5ID0gaSA8IHByZWZpeCA/IGNlbGxZW2ldISA6IE1hdGguZmxvb3IoZW50aXR5LnkgLyBjZWxsU2l6ZSk7XG4gICAgbWVtYmVyc1tpXSA9IGVudGl0eTsgcG9zaXRpb25zWFtpXSA9IGVudGl0eS54OyBwb3NpdGlvbnNZW2ldID0gZW50aXR5Lnk7XG4gICAgY2VsbFhbaV0gPSB4OyBjZWxsWVtpXSA9IHk7XG4gICAgbGVmdCA9IE1hdGgubWluKGxlZnQsIHgpOyByaWdodCA9IE1hdGgubWF4KHJpZ2h0LCB4KTtcbiAgICB0b3AgPSBNYXRoLm1pbih0b3AsIHkpOyBib3R0b20gPSBNYXRoLm1heChib3R0b20sIHkpO1xuICAgIGNvbnN0IGtleSA9IG51bWVyaWNCdWNrZXRLZXkoeCwgeSk7XG4gICAgY29uc3QgYnVja2V0ID0gYnVja2V0cy5nZXQoa2V5KTtcbiAgICBpZiAoYnVja2V0KSBidWNrZXQucHVzaChlbnRpdHkpO1xuICAgIGVsc2UgYnVja2V0cy5zZXQoa2V5LCBbZW50aXR5XSk7XG4gIH1cbiAgbWVtYmVycy5sZW5ndGggPSBjZWxsWC5sZW5ndGggPSBjZWxsWS5sZW5ndGggPSBwb3NpdGlvbnNYLmxlbmd0aCA9IHBvc2l0aW9uc1kubGVuZ3RoID0gZW50aXRpZXMubGVuZ3RoO1xuICBjb25zdCBpbmRleCA9IHsgdGVhbTogdW5kZWZpbmVkLCBjZWxsU2l6ZSwgYnVja2V0cywgbGVmdCwgcmlnaHQsIHRvcCwgYm90dG9tIH07XG4gIC8vIENvcHkgbWVtYmVyc2hpcCBzZXBhcmF0ZWx5OiBjYWxsZXJzIGFwcGVuZCwgcmVwbGFjZSBhbmQgcmVvcmRlciBnYW1lLnVuaXRzLlxuICBzcGF0aWFsTWVtYmVyc2hpcC5zZXQoaW5kZXgsIHsgbWVtYmVycywgY2VsbFgsIGNlbGxZLCB4OiBwb3NpdGlvbnNYLCB5OiBwb3NpdGlvbnNZIH0pO1xuICByZXR1cm4gaW5kZXg7XG59XG5cbmNvbnN0IHRlYW1TcGF0aWFsTWVtYmVyc2hpcCA9IG5ldyBXZWFrTWFwPG9iamVjdCwge1xuICBjZWxsU2l6ZTogbnVtYmVyO1xuICBtZW1iZXJzOiAoU3BhdGlhbEVudGl0eSAmIHsgb3duZXI6IE93bmVyIH0pW107XG4gIGNlbGxYOiBudW1iZXJbXTtcbiAgY2VsbFk6IG51bWJlcltdO1xuICB0ZWFtczogc3RyaW5nW107XG4gIHg6IG51bWJlcltdO1xuICB5OiBudW1iZXJbXTtcbn0+KCk7XG5cbmZ1bmN0aW9uIGNyZWF0ZVRlYW1TcGF0aWFsSW5kZXhlczxUIGV4dGVuZHMgU3BhdGlhbEVudGl0eSAmIHsgb3duZXI6IE93bmVyIH0+KGdhbWU6IEdhbWUsIGVudGl0aWVzOiBUW10sIGNlbGxTaXplOiBudW1iZXIsIHByZXZpb3VzPzogTWFwPHN0cmluZywgU3BhdGlhbEluZGV4PFQ+Pik6IE1hcDxzdHJpbmcsIFNwYXRpYWxJbmRleDxUPj4ge1xuICBjb25zdCBjYWNoZWQgPSBwcmV2aW91cyA/IHRlYW1TcGF0aWFsTWVtYmVyc2hpcC5nZXQocHJldmlvdXMpIDogdW5kZWZpbmVkO1xuICBsZXQgcHJlZml4ID0gMDtcbiAgaWYgKGNhY2hlZCAmJiBPYmplY3QuaXMoY2FjaGVkLmNlbGxTaXplLCBjZWxsU2l6ZSkgJiYgY2FjaGVkLm1lbWJlcnMubGVuZ3RoID09PSBlbnRpdGllcy5sZW5ndGgpIHtcbiAgICBsZXQgdW5jaGFuZ2VkID0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGVudGl0aWVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICBjb25zdCBlbnRpdHkgPSBlbnRpdGllc1tpXSE7XG4gICAgICBpZiAoY2FjaGVkLm1lbWJlcnNbaV0gIT09IGVudGl0eVxuICAgICAgICB8fCAhT2JqZWN0LmlzKGNhY2hlZC54W2ldLCBlbnRpdHkueCkgJiYgIU9iamVjdC5pcyhjYWNoZWQuY2VsbFhbaV0sIE1hdGguZmxvb3IoZW50aXR5LnggLyBjZWxsU2l6ZSkpXG4gICAgICAgIHx8ICFPYmplY3QuaXMoY2FjaGVkLnlbaV0sIGVudGl0eS55KSAmJiAhT2JqZWN0LmlzKGNhY2hlZC5jZWxsWVtpXSwgTWF0aC5mbG9vcihlbnRpdHkueSAvIGNlbGxTaXplKSlcbiAgICAgICAgfHwgY2FjaGVkLnRlYW1zW2ldICE9PSB0ZWFtS2V5KGdhbWUsIGVudGl0eS5vd25lcikpIHtcbiAgICAgICAgdW5jaGFuZ2VkID0gZmFsc2U7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FjaGVkLnhbaV0gPSBlbnRpdHkueDsgY2FjaGVkLnlbaV0gPSBlbnRpdHkueTtcbiAgICAgIHByZWZpeCA9IGkgKyAxO1xuICAgIH1cbiAgICAvLyBJbnRlcm5hbCBpbmRleGVzIHJldGFpbiBsaXZlIGJvZGllcy4gVGVhbSBtZW1iZXJzaGlwIGFuZCB2aXNpdCBvcmRlclxuICAgIC8vIG11c3QgbWF0Y2ggaW5kZXBlbmRlbnRseSBvZiBjb29yZGluYXRlLWtleSBhbGlhc2VzIGFuZCBtdXRhYmxlIG93bmVycy5cbiAgICBpZiAodW5jaGFuZ2VkKSByZXR1cm4gcHJldmlvdXMhO1xuICB9XG4gIGNvbnN0IGluZGV4ZXMgPSBuZXcgTWFwPHN0cmluZywgU3BhdGlhbEluZGV4PFQ+PigpO1xuICBjb25zdCByZXVzYWJsZSA9IGNhY2hlZCAmJiBPYmplY3QuaXMoY2FjaGVkLmNlbGxTaXplLCBjZWxsU2l6ZSkgPyBjYWNoZWQgOiB1bmRlZmluZWQ7XG4gIGlmIChyZXVzYWJsZSkgdGVhbVNwYXRpYWxNZW1iZXJzaGlwLmRlbGV0ZShwcmV2aW91cyEpO1xuICBjb25zdCBtZW1iZXJzID0gcmV1c2FibGU/Lm1lbWJlcnMgPz8gW107XG4gIGNvbnN0IGNlbGxYID0gcmV1c2FibGU/LmNlbGxYID8/IFtdLCBjZWxsWSA9IHJldXNhYmxlPy5jZWxsWSA/PyBbXSwgdGVhbXMgPSByZXVzYWJsZT8udGVhbXMgPz8gW107XG4gIGNvbnN0IHBvc2l0aW9uc1ggPSByZXVzYWJsZSA/IHJldXNhYmxlLnggOiBbXSwgcG9zaXRpb25zWSA9IHJldXNhYmxlID8gcmV1c2FibGUueSA6IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGVudGl0aWVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgY29uc3QgZW50aXR5ID0gZW50aXRpZXNbaV0hO1xuICAgIGNvbnN0IHRlYW0gPSBpIDwgcHJlZml4ID8gdGVhbXNbaV0hIDogdGVhbUtleShnYW1lLCBlbnRpdHkub3duZXIpO1xuICAgIG1lbWJlcnNbaV0gPSBlbnRpdHk7IHBvc2l0aW9uc1hbaV0gPSBlbnRpdHkueDsgcG9zaXRpb25zWVtpXSA9IGVudGl0eS55O1xuICAgIHRlYW1zW2ldID0gdGVhbTtcbiAgICBsZXQgaW5kZXggPSBpbmRleGVzLmdldCh0ZWFtKTtcbiAgICBpZiAoIWluZGV4KSBpbmRleGVzLnNldCh0ZWFtLCBpbmRleCA9IHsgdGVhbSwgY2VsbFNpemUsIGJ1Y2tldHM6IG5ldyBNYXAoKSwgbGVmdDogSW5maW5pdHksIHJpZ2h0OiAtSW5maW5pdHksIHRvcDogSW5maW5pdHksIGJvdHRvbTogLUluZmluaXR5IH0pO1xuICAgIGNvbnN0IHggPSBpIDwgcHJlZml4ID8gY2VsbFhbaV0hIDogTWF0aC5mbG9vcihlbnRpdHkueCAvIGNlbGxTaXplKTtcbiAgICBjb25zdCB5ID0gaSA8IHByZWZpeCA/IGNlbGxZW2ldISA6IE1hdGguZmxvb3IoZW50aXR5LnkgLyBjZWxsU2l6ZSk7XG4gICAgY2VsbFhbaV0gPSB4OyBjZWxsWVtpXSA9IHk7XG4gICAgaW5kZXgubGVmdCA9IE1hdGgubWluKGluZGV4LmxlZnQsIHgpOyBpbmRleC5yaWdodCA9IE1hdGgubWF4KGluZGV4LnJpZ2h0LCB4KTtcbiAgICBpbmRleC50b3AgPSBNYXRoLm1pbihpbmRleC50b3AsIHkpOyBpbmRleC5ib3R0b20gPSBNYXRoLm1heChpbmRleC5ib3R0b20sIHkpO1xuICAgIGNvbnN0IGtleSA9IG51bWVyaWNCdWNrZXRLZXkoeCwgeSksIGJ1Y2tldCA9IGluZGV4LmJ1Y2tldHMuZ2V0KGtleSk7XG4gICAgaWYgKGJ1Y2tldCkgYnVja2V0LnB1c2goZW50aXR5KTtcbiAgICBlbHNlIGluZGV4LmJ1Y2tldHMuc2V0KGtleSwgW2VudGl0eV0pO1xuICB9XG4gIG1lbWJlcnMubGVuZ3RoID0gY2VsbFgubGVuZ3RoID0gY2VsbFkubGVuZ3RoID0gdGVhbXMubGVuZ3RoID0gcG9zaXRpb25zWC5sZW5ndGggPSBwb3NpdGlvbnNZLmxlbmd0aCA9IGVudGl0aWVzLmxlbmd0aDtcbiAgdGVhbVNwYXRpYWxNZW1iZXJzaGlwLnNldChpbmRleGVzLCB7IGNlbGxTaXplLCBtZW1iZXJzLCBjZWxsWCwgY2VsbFksIHRlYW1zLCB4OiBwb3NpdGlvbnNYLCB5OiBwb3NpdGlvbnNZIH0pO1xuICByZXR1cm4gaW5kZXhlcztcbn1cblxuY29uc3QgZW50aXR5SW5kZXhlcyA9IG5ldyBXZWFrTWFwPFVuaXRbXSwgeyB1bml0czogbnVtYmVyOyBidWlsZGluZ3M6IEJ1aWxkaW5nW107IGJ1aWxkaW5nQ291bnQ6IG51bWJlcjsgaW5kZXg6IE1hcDxzdHJpbmcsIFVuaXQgfCBCdWlsZGluZz4gfT4oKTtcbmZ1bmN0aW9uIGNyZWF0ZUVudGl0eUluZGV4KGdhbWU6IEdhbWUpIHtcbiAgY29uc3QgY2FjaGVkID0gZW50aXR5SW5kZXhlcy5nZXQoZ2FtZS51bml0cyk7XG4gIGlmIChjYWNoZWQgJiYgY2FjaGVkLnVuaXRzID09PSBnYW1lLnVuaXRzLmxlbmd0aCAmJiBjYWNoZWQuYnVpbGRpbmdzID09PSBnYW1lLmJ1aWxkaW5ncyAmJiBjYWNoZWQuYnVpbGRpbmdDb3VudCA9PT0gZ2FtZS5idWlsZGluZ3MubGVuZ3RoKSByZXR1cm4gY2FjaGVkLmluZGV4O1xuICBjb25zdCBpbmRleCA9IG5ldyBNYXA8c3RyaW5nLCBVbml0IHwgQnVpbGRpbmc+KCk7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBnYW1lLnVuaXRzKSBpbmRleC5zZXQodW5pdC5pZCwgdW5pdCk7XG4gIGZvciAoY29uc3QgYnVpbGRpbmcgb2YgZ2FtZS5idWlsZGluZ3MpIGluZGV4LnNldChidWlsZGluZy5pZCwgYnVpbGRpbmcpO1xuICBlbnRpdHlJbmRleGVzLnNldChnYW1lLnVuaXRzLCB7IHVuaXRzOiBnYW1lLnVuaXRzLmxlbmd0aCwgYnVpbGRpbmdzOiBnYW1lLmJ1aWxkaW5ncywgYnVpbGRpbmdDb3VudDogZ2FtZS5idWlsZGluZ3MubGVuZ3RoLCBpbmRleCB9KTtcbiAgcmV0dXJuIGluZGV4O1xufVxuXG5mdW5jdGlvbiBmb3JFYWNoTmVhcmJ5VW5pdChnYW1lOiBHYW1lLCBwb2ludDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCByYW5nZTogbnVtYmVyLCB2aXNpdDogKHVuaXQ6IFVuaXQpID0+IHZvaWQpIHtcbiAgZm9yRWFjaE5lYXJieUVudGl0eShnYW1lLnVuaXRTcGF0aWFsLCBnYW1lLnVuaXRzLCBwb2ludCwgcmFuZ2UsIHVuaXQgPT4geyBpZiAoIWlzSW5DYWJpbih1bml0KSkgdmlzaXQodW5pdCk7IH0pO1xufVxuXG4vLyBUaGUgZmlyc3QgdW5pdCBuZWFyIHRoZSBwb2ludCB0aGF0IHBhc3NlcyB0aGUgdGVzdCwgdmlzaXRpbmcgaW4gZm9yRWFjaE5lYXJieVVuaXQncyBvcmRlciBhbmQgc3RvcHBpbmcgdGhlcmUuXG5mdW5jdGlvbiBmaXJzdE5lYXJieVVuaXQoZ2FtZTogR2FtZSwgcG9pbnQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSwgcmFuZ2U6IG51bWJlciwgdGVzdDogKHVuaXQ6IFVuaXQpID0+IGJvb2xlYW4pOiBVbml0IHwgdW5kZWZpbmVkIHtcbiAgY29uc3QgaW5kZXggPSBnYW1lLnVuaXRTcGF0aWFsO1xuICBpZiAoIWluZGV4KSByZXR1cm4gZ2FtZS51bml0cy5maW5kKHVuaXQgPT4gIWlzSW5DYWJpbih1bml0KSAmJiB0ZXN0KHVuaXQpKTtcbiAgLy8gQm90aCBjYWxsZXJzIHJlamVjdCBib2RpZXMgb3V0c2lkZSB0aGVpciBwaHlzaWNhbCByYW5nZS4gS2VlcCB0aGUgc2FtZVxuICAvLyB4LXRoZW4teSB2aXNpdCBvcmRlciwgYnV0IG9taXQgY2VsbHMgdGhlIHJhbmdlIGNhbm5vdCByZWFjaCBhbmQgZW1wdHkgZXh0ZW50cy5cbiAgY29uc3Qgc2l6ZSA9IGluZGV4LmNlbGxTaXplO1xuICBjb25zdCByaWdodCA9IE1hdGgubWluKGluZGV4LnJpZ2h0LCBNYXRoLmZsb29yKChwb2ludC54ICsgcmFuZ2UpIC8gc2l6ZSkpO1xuICBjb25zdCBib3R0b20gPSBNYXRoLm1pbihpbmRleC5ib3R0b20sIE1hdGguZmxvb3IoKHBvaW50LnkgKyByYW5nZSkgLyBzaXplKSk7XG4gIGNvbnN0IHRvcCA9IE1hdGgubWF4KGluZGV4LnRvcCwgTWF0aC5mbG9vcigocG9pbnQueSAtIHJhbmdlKSAvIHNpemUpKTtcbiAgZm9yIChsZXQgeCA9IE1hdGgubWF4KGluZGV4LmxlZnQsIE1hdGguZmxvb3IoKHBvaW50LnggLSByYW5nZSkgLyBzaXplKSk7IHggPD0gcmlnaHQ7IHggKz0gMSkge1xuICAgIGZvciAobGV0IHkgPSB0b3A7IHkgPD0gYm90dG9tOyB5ICs9IDEpIHtcbiAgICAgIGNvbnN0IGJ1Y2tldCA9IGluZGV4LmJ1Y2tldHMuZ2V0KG51bWVyaWNCdWNrZXRLZXkoeCwgeSkpO1xuICAgICAgaWYgKCFidWNrZXQpIGNvbnRpbnVlO1xuICAgICAgZm9yIChjb25zdCB1bml0IG9mIGJ1Y2tldCkgaWYgKCFpc0luQ2FiaW4odW5pdCkgJiYgdGVzdCh1bml0KSkgcmV0dXJuIHVuaXQ7XG4gICAgfVxuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIGZvckVhY2hOZWFyYnlCdWlsZGluZyhnYW1lOiBHYW1lLCBwb2ludDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCByYW5nZTogbnVtYmVyLCB2aXNpdDogKGJ1aWxkaW5nOiBCdWlsZGluZykgPT4gdm9pZCkge1xuICBmb3JFYWNoTmVhcmJ5RW50aXR5KGdhbWUuYnVpbGRpbmdTcGF0aWFsLCBnYW1lLmJ1aWxkaW5ncywgcG9pbnQsIHJhbmdlLCB2aXNpdCk7XG59XG5cbmZ1bmN0aW9uIGZvckVhY2hOZWFyYnlFbmVteVVuaXQoZ2FtZTogR2FtZSwgb3duZXI6IE93bmVyLCBwb2ludDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCByYW5nZTogbnVtYmVyLCB2aXNpdDogKHVuaXQ6IFVuaXQpID0+IHZvaWQpIHtcbiAgY29uc3QgaW5kZXhlcyA9IGdhbWUudW5pdFNwYXRpYWxCeVRlYW07XG4gIGlmICghaW5kZXhlcykge1xuICAgIGZvckVhY2hOZWFyYnlVbml0KGdhbWUsIHBvaW50LCByYW5nZSwgKHVuaXQpID0+IHtcbiAgICAgIGlmIChhcmVFbmVteU93bmVycyhnYW1lLCBvd25lciwgdW5pdC5vd25lcikpIHZpc2l0KHVuaXQpO1xuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBvd25UZWFtID0gdGVhbUtleShnYW1lLCBvd25lcik7XG4gIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhlcy52YWx1ZXMoKSkgaWYgKGluZGV4LnRlYW0gIT09IG93blRlYW0pIGZvckVhY2hOZWFyYnlFbnRpdHkoaW5kZXgsIGdhbWUudW5pdHMsIHBvaW50LCByYW5nZSwgdmlzaXQpO1xufVxuXG5mdW5jdGlvbiBmb3JFYWNoTmVhcmJ5RW5lbXlCdWlsZGluZyhnYW1lOiBHYW1lLCBvd25lcjogT3duZXIsIHBvaW50OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0sIHJhbmdlOiBudW1iZXIsIHZpc2l0OiAoYnVpbGRpbmc6IEJ1aWxkaW5nKSA9PiB2b2lkKSB7XG4gIGNvbnN0IGluZGV4ZXMgPSBnYW1lLmJ1aWxkaW5nU3BhdGlhbEJ5VGVhbTtcbiAgaWYgKCFpbmRleGVzKSB7XG4gICAgZm9yRWFjaE5lYXJieUJ1aWxkaW5nKGdhbWUsIHBvaW50LCByYW5nZSwgKGJ1aWxkaW5nKSA9PiB7XG4gICAgICBpZiAoYXJlRW5lbXlPd25lcnMoZ2FtZSwgb3duZXIsIGJ1aWxkaW5nLm93bmVyKSkgdmlzaXQoYnVpbGRpbmcpO1xuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBvd25UZWFtID0gdGVhbUtleShnYW1lLCBvd25lcik7XG4gIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhlcy52YWx1ZXMoKSkgaWYgKGluZGV4LnRlYW0gIT09IG93blRlYW0pIGZvckVhY2hOZWFyYnlFbnRpdHkoaW5kZXgsIGdhbWUuYnVpbGRpbmdzLCBwb2ludCwgcmFuZ2UsIHZpc2l0KTtcbn1cblxuZnVuY3Rpb24gZm9yRWFjaE5lYXJieUVudGl0eTxUIGV4dGVuZHMgU3BhdGlhbEVudGl0eT4oXG4gIGluZGV4OiBTcGF0aWFsSW5kZXg8VD4gfCB1bmRlZmluZWQsXG4gIHVuaW5kZXhlZEVudGl0aWVzOiBUW10sXG4gIHBvaW50OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0sXG4gIHJhbmdlOiBudW1iZXIsXG4gIHZpc2l0OiAoZW50aXR5OiBUKSA9PiB2b2lkLFxuKSB7XG4gIGlmICghaW5kZXgpIHtcbiAgICBmb3IgKGNvbnN0IGVudGl0eSBvZiB1bmluZGV4ZWRFbnRpdGllcykgdmlzaXQoZW50aXR5KTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gT25seSB0aGUgc3F1YXJlcyB0aGUgcmFuZ2UgcmVhY2hlcyAodGhlIHZpc2l0b3JzIGRyb3Agd2hvZXZlciBzdGFuZHMgYmV5b25kIGl0KTogYSBzZWFyY2ggYSBsaXR0bGUgd2lkZXIgdGhhbiBhIHNxdWFyZVxuICAvLyAoYSBidWlsZGluZydzLCBieSBpdHMgcmFkaXVzKSBsb29rZWQgYXQgMjUgc3F1YXJlcyByb3VuZCB0aGUgcG9pbnQncywgd2hlcmUgOSBob2xkIGFsbCBpdCBjYW4gZmluZC5cbiAgY29uc3Qgc2l6ZSA9IGluZGV4LmNlbGxTaXplO1xuICAvLyBTa2lwIGVtcHR5IHNwYWNlIG91dHNpZGUgdGhpcyBpbmRleCdzIG9jY3VwaWVkIGV4dGVudC4gVGhlIG9yZGVyIG9mIGV2ZXJ5XG4gIC8vIG9jY3VwaWVkIGJ1Y2tldCBzdGF5cyB1bmNoYW5nZWQsIGluY2x1ZGluZyBkZXRlcm1pbmlzdGljIHRhcmdldCB0aWUgYnJlYWtzLlxuICBjb25zdCByaWdodCA9IE1hdGgubWluKGluZGV4LnJpZ2h0LCBNYXRoLmZsb29yKChwb2ludC54ICsgcmFuZ2UpIC8gc2l6ZSkpO1xuICBjb25zdCBib3R0b20gPSBNYXRoLm1pbihpbmRleC5ib3R0b20sIE1hdGguZmxvb3IoKHBvaW50LnkgKyByYW5nZSkgLyBzaXplKSk7XG4gIGNvbnN0IHRvcCA9IE1hdGgubWF4KGluZGV4LnRvcCwgTWF0aC5mbG9vcigocG9pbnQueSAtIHJhbmdlKSAvIHNpemUpKTtcbiAgZm9yIChsZXQgeCA9IE1hdGgubWF4KGluZGV4LmxlZnQsIE1hdGguZmxvb3IoKHBvaW50LnggLSByYW5nZSkgLyBzaXplKSk7IHggPD0gcmlnaHQ7IHggKz0gMSkge1xuICAgIGZvciAobGV0IHkgPSB0b3A7IHkgPD0gYm90dG9tOyB5ICs9IDEpIHtcbiAgICAgIGNvbnN0IGJ1Y2tldCA9IGluZGV4LmJ1Y2tldHMuZ2V0KG51bWVyaWNCdWNrZXRLZXkoeCwgeSkpO1xuICAgICAgaWYgKCFidWNrZXQpIGNvbnRpbnVlO1xuICAgICAgZm9yIChjb25zdCBlbnRpdHkgb2YgYnVja2V0KSB2aXNpdChlbnRpdHkpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBtb3ZlVG93YXJkKHVuaXQ6IFVuaXQsIHg6IG51bWJlciwgeTogbnVtYmVyLCBtYXA6IEdhbWVNYXAsIHVuaXRzOiByZWFkb25seSBVbml0W10gPSBbXSwgbmF2YWxGcmFtZSA9IHRydWUpIHtcbiAgLy8gQSByb290ZWQgb3Igc3R1bm5lZCB1bml0IHN0YW5kcywgYSBuZXR0ZWQgb25lIHdhbGtzIHNsb3dlciAoc2VlIEBAQGNyZWVwLXN0YXR1cykuXG4gIGNvbnN0IHBhY2UgPSBzdGF0dXNQYWNlKHVuaXQpO1xuICBpZiAocGFjZSA9PT0gMCkgcmV0dXJuO1xuICBpZihuYXZhbEZyYW1lICYmIHNoaXBQcm9maWxlKHVuaXQpKXtzYWlsVG93YXJkKHVuaXQse3gseSwuLi4odW5pdC5vcmRlci50eXBlPT09XCJtb3ZlXCIgJiYgdW5pdC5vcmRlci5oZWFkaW5nIT09dW5kZWZpbmVkP3toZWFkaW5nOnVuaXQub3JkZXIuaGVhZGluZ306e30pfSxtYXAsdW5pdHMscGFjZSk7cmV0dXJuO31cbiAgLy8gTmF0aXZlIGdyb3VuZGVkIGNhbGxlcnMgaGF2ZSBhbHJlYWR5IGNlcnRpZmllZCB0aGUgc2FtZSB1bml0IGxpc3QuIE90aGVyXG4gIC8vIGNhbGxlcnMgY29udGludWUgY29uc3VsdGluZyB0aGUgaW5pdGlhbGl6ZWQgaHVsbCBjb2xsaXNpb24gZnJhbWUuXG4gIGNvbnN0IGtub3duRW1wdHkgPSAhbmF2YWxGcmFtZSB8fCBncm91bmRTaGlwRnJhbWVFbXB0eSh1bml0cyk7XG4gIGlmICgha25vd25FbXB0eSB8fCB1bml0LmRlY2spIHtcbiAgICBjb25zdCBzaGlwPXVuaXQuZGVjayAmJiB1bml0cy5maW5kKHNoaXA9PnNoaXAuaWQ9PT11bml0LmRlY2shLnNoaXBJZCk7XG4gICAgY29uc3QgZ29hbD1kZWNrR29hbCh1bml0LHNoaXAgfHwgdW5kZWZpbmVkLHt4LHl9LHVuaXRzKTtcbiAgICBpZih3YWxrQ29ubmVjdGVkU3VyZmFjZXModW5pdCxnb2FsLHVuaXRzLG1hcCxwYWNlKSlyZXR1cm47XG4gICAgaWYodW5pdC5kZWNrKXtpZihzaGlwKW1vdmVPbkRlY2sodW5pdCxzaGlwLGdvYWwsdW5pdHMscGFjZSk7cmV0dXJuO31cbiAgfVxuICBjb25zdCBmcm9tPWtub3duRW1wdHkgPyB1bmRlZmluZWQgOiB7eDp1bml0LngseTp1bml0Lnl9O1xuICBpZiAobWFwLnRlcnJhaW4pIHtcbiAgICB3YWxrVG93YXJkKHVuaXQsIHgsIHksIG1hcCwgcGFjZSk7XG4gICAgaWYgKGZyb20pIHtcbiAgICAgIGNvbnN0IGF0PWNvbnN0cmFpbkdyb3VuZFNoaXBTdGVwKG1hcCx1bml0LGZyb20sdW5pdCx1bml0cyk7XG4gICAgICBpZihhdCE9PXVuaXQpe3VuaXQueD1hdC54O3VuaXQueT1hdC55O31cbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNwZWVkID0gcGVyVGljayh1bml0LnNwZWVkKSAqIHBhY2U7XG4gIGNvbnN0IGR4ID0geCAtIHVuaXQueDtcbiAgY29uc3QgZHkgPSB5IC0gdW5pdC55O1xuICBjb25zdCBsZW5ndGggPSBoeXBvdDIoZHgsIGR5KTtcbiAgaWYgKGxlbmd0aCA8PSBzcGVlZCB8fCBsZW5ndGggPT09IDApIHtcbiAgICB1bml0LnggPSBjbGFtcCh4LCAwLCBtYXAud2lkdGgpO1xuICAgIHVuaXQueSA9IGNsYW1wKHksIDAsIG1hcC5oZWlnaHQpO1xuICAgIGlmIChmcm9tKSB7XG4gICAgICBjb25zdCBhdD1jb25zdHJhaW5Hcm91bmRTaGlwU3RlcChtYXAsdW5pdCxmcm9tLHVuaXQsdW5pdHMpO1xuICAgICAgaWYoYXQhPT11bml0KXt1bml0Lng9YXQueDt1bml0Lnk9YXQueTt9XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuICB1bml0LnggPSBjbGFtcCh1bml0LnggKyAoZHggLyBsZW5ndGgpICogc3BlZWQsIDAsIG1hcC53aWR0aCk7XG4gIHVuaXQueSA9IGNsYW1wKHVuaXQueSArIChkeSAvIGxlbmd0aCkgKiBzcGVlZCwgMCwgbWFwLmhlaWdodCk7XG4gIGlmIChmcm9tKSB7XG4gICAgY29uc3QgYXQ9Y29uc3RyYWluR3JvdW5kU2hpcFN0ZXAobWFwLHVuaXQsZnJvbSx1bml0LHVuaXRzKTtcbiAgICBpZihhdCE9PXVuaXQpe3VuaXQueD1hdC54O3VuaXQueT1hdC55O31cbiAgfVxufVxuXG4vLyBAQEB0ZXJyYWluLXdhbGsgLSBPbiBhIG1hcCB3aXRoIHRlcnJhaW4gYSB1bml0IHdhbGtzIHJvdW5kIHdoYXQgYmxvY2tzIGl0OiBpdCBoZWFkcyBmb3IgdGhlIGdvYWwgd2hlbiBpdCBzZWVzIGl0LCBlbHNlXG4vLyBmb3IgdGhlIGZhcnRoZXN0IGNlbGwgaXQgc2VlcyBvbiB0aGUgd2F5IChzZWUgdGVycmFpbiBzdGVlclBvaW50KSwgYW5kIGEgZ29hbCBpbiBhIGZvcmVzdCBvciBvbiByb2NrIGlzIGl0cyBuZWFyZXN0XG4vLyB3YWxrYWJsZSBjZWxsLiBBIHN0ZXAgdGhhdCB3b3VsZCBlbmQgb24gYmxvY2tlZCBncm91bmQgc2xpZGVzIGFsb25nIGl0IG9uIG9uZSBheGlzLCBvciB3YWl0czsgYSB1bml0IHRoYXQgc3RhbmRzIG9uXG4vLyBibG9ja2VkIGdyb3VuZCAob25seSBhIHNlZWRlZCBzY2VuYXJpbyBwdXRzIG9uZSB0aGVyZSkgd2Fsa3Mgb3V0LiBBIHNoaXAgc2FpbHMgdGhlIHNhbWUgd2F5IG92ZXIgdGhlIHdhdGVyIChzZWUgQEBAbmF2YWwpLlxuZnVuY3Rpb24gd2Fsa1Rvd2FyZCh1bml0OiBVbml0LCB4OiBudW1iZXIsIHk6IG51bWJlciwgbWFwOiBHYW1lTWFwLCBwYWNlID0gMSkge1xuICBjb25zdCBtb3ZlciA9IHVuaXRNb3Zlcih1bml0LmtpbmQpO1xuICBjb25zdCBnb2FsID0geCA+PSAwICYmIHkgPj0gMCAmJiB4IDw9IG1hcC53aWR0aCAmJiB5IDw9IG1hcC5oZWlnaHQgJiYgaXNXYWxrYWJsZShtYXAsIHgsIHksIG1vdmVyKSA/IHsgeCwgeSB9IDogd2Fsa2FibGVHb2FsKG1hcCwgeCwgeSwgbW92ZXIpO1xuICBjb25zdCBhaW0gPSBzdGVlclBvaW50KG1hcCwgdW5pdCwgZ29hbCwgbW92ZXIpO1xuICBjb25zdCBkeCA9IGFpbS54IC0gdW5pdC54O1xuICBjb25zdCBkeSA9IGFpbS55IC0gdW5pdC55O1xuICBjb25zdCBsZW5ndGggPSBNYXRoLnNxcnQoZHggKiBkeCArIGR5ICogZHkpO1xuICBpZiAobGVuZ3RoID09PSAwKSByZXR1cm47XG4gIC8vIEEgc2hhbGxvdyBvciBhIGJvZyBzbG93cyBhIGxhbmQgdW5pdCB0byBpdHMgZ3JvdW5kJ3MgcGFjZSAoc2VlIGdyb3VuZFVuZGVyKS5cbiAgY29uc3Qgc3BlZWQgPSBwZXJUaWNrKHVuaXQuc3BlZWQpICogcGFjZSAqIGdyb3VuZFVuZGVyKG1hcCwgdW5pdC54LCB1bml0LnksIG1vdmVyKS5wYWNlO1xuICBjb25zdCBuZXh0WCA9IGNsYW1wKGxlbmd0aCA8PSBzcGVlZCA/IGFpbS54IDogdW5pdC54ICsgKGR4IC8gbGVuZ3RoKSAqIHNwZWVkLCAwLCBtYXAud2lkdGgpO1xuICBjb25zdCBuZXh0WSA9IGNsYW1wKGxlbmd0aCA8PSBzcGVlZCA/IGFpbS55IDogdW5pdC55ICsgKGR5IC8gbGVuZ3RoKSAqIHNwZWVkLCAwLCBtYXAuaGVpZ2h0KTtcbiAgY29uc3Qgc3RlcCA9IG9wZW5TdGVwKG1hcCwgdW5pdCwgeyB4OiBuZXh0WCwgeTogbmV4dFkgfSwgbW92ZXIpO1xuICB1bml0LnggPSBzdGVwLng7XG4gIHVuaXQueSA9IHN0ZXAueTtcbn1cblxuZnVuY3Rpb24gZGlzdGFuY2UoYTogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9LCBiOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0pIHtcbiAgcmV0dXJuIGh5cG90MihhLnggLSBiLngsIGEueSAtIGIueSk7XG59XG5cbmZ1bmN0aW9uIGRpc3RhbmNlU3F1YXJlZChhOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0sIGI6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSkge1xuICBjb25zdCBkeCA9IGEueCAtIGIueDtcbiAgY29uc3QgZHkgPSBhLnkgLSBiLnk7XG4gIHJldHVybiBkeCAqIGR4ICsgZHkgKiBkeTtcbn1cblxuZnVuY3Rpb24gY2xhbXAodmFsdWU6IG51bWJlciwgbWluOiBudW1iZXIsIG1heDogbnVtYmVyKSB7XG4gIHJldHVybiBNYXRoLm1pbihtYXgsIE1hdGgubWF4KG1pbiwgdmFsdWUpKTtcbn1cblxuZnVuY3Rpb24gaXNOdW1iZXIodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBudW1iZXIge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiICYmIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsU0FBUyxpQkFBaUI7QUFDbkMsU0FBUyxpQ0FBaUM7QUFDMUMsU0FBUyxtQkFBbUIsc0JBQXNCLDZCQUE2QjtBQUMvRSxTQUFTLHlCQUF5QixrQkFBeUM7QUFDM0UsU0FBUyx5QkFBeUIsMkJBQTJCLHNCQUFzQiwyQkFBMkI7QUFDOUcsU0FBUyxnQkFBZ0IsMkJBQTJCO0FBQ3BELFNBQVMsZ0JBQWdCLDBCQUEwQjtBQUNuRCxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLG1CQUFtQixvQkFBb0Isa0JBQWtCLG9CQUFvQixtQkFBbUIscUJBQXFCLDRCQUE0QjtBQUMxSixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHFCQUFxQixpQkFBaUIsMkJBQTJCO0FBQzFFLFNBQVMsaUJBQWlCLG9CQUFvQix3QkFBMEM7QUFDeEYsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxZQUFZLG9CQUFvQjtBQUN6QyxTQUFTLGlCQUFpQiwyQkFBMkI7QUFDckQsU0FBUyxxQkFBc0M7QUFDL0MsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxhQUFhLFdBQVcsZUFBZTtBQUNoRCxTQUFTLHlCQUFpRDtBQUMxRCxTQUFTLGNBQWMsMEJBQTBCLGlCQUFpQix5QkFBeUIsa0JBQW1DLG1CQUFtQixvQkFBb0Isc0JBQXNCLHFCQUFxQixpQkFBaUIsYUFBYSxlQUFlLFlBQVkseUJBQWdEO0FBQ3pULFNBQVMsV0FBVyxZQUFZLFVBQVUsYUFBYSxjQUFjLGNBQWMsb0JBQW9CLGlCQUFpQixpQkFBaUIsYUFBYSxjQUFjLFdBQVcsY0FBYyxjQUFjLGdCQUFnQjtBQUMzTixTQUFTLGVBQWUsYUFBYSxpQkFBaUIsc0JBQXNCLGVBQWUsYUFBYSwyQkFBMkIsa0NBQWtDO0FBQ3JLLFNBQVMsb0JBQW9CLHlCQUF5QixjQUFjLHdCQUF3QjtBQUM1RixTQUFTLHdCQUF3QixtQkFBbUIsZ0JBQWdCLGdDQUFtRDtBQUN2SCxTQUFTLGlCQUFpQixrQkFBa0IsY0FBYyxvQkFBb0I7QUFDOUUsU0FBUyxPQUFPLGVBQWUsb0JBQW9CLGFBQWEscUNBQXFDO0FBQ3JHLFNBQVMscUNBQXFDO0FBRTlDLFNBQVMsY0FBYyxlQUFlLGFBQWEsdUJBQXVCLGVBQWUsY0FBYyxXQUFXLFlBQVksZUFBZSxjQUFjLG1CQUFtQixzQkFBc0IsV0FBVyxXQUFXLGNBQWMsZUFBZSxZQUFZLGVBQWUscUJBQXFCLFVBQVUsdUJBQXVCLGlCQUFpQixtQkFBbUIsV0FBVyxpQkFBK0I7QUFDdFosU0FBUyxpQkFBaUIsd0JBQXdCLDJCQUEyQjtBQUM3RSxTQUFTLFdBQVcscUJBQXFCO0FBQ3pDLFNBQVMsbUJBQW1CLDhCQUE4QztBQUMxRSxTQUFTLCtCQUErQjtBQUN4QyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLG1CQUFtQixvQkFBb0Isc0NBQTRGO0FBQzVJLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsbUJBQW1CLCtCQUErQjtBQUMzRCxTQUFTLHFCQUFxQixxQkFBcUIsaUJBQWlCLDRCQUFnRDtBQUNwSCxTQUFTLGlCQUFpQixhQUFhLG9CQUFvQjtBQUMzRCxTQUFTLDBCQUEwQiw4QkFBOEI7QUFDakUsU0FBUyxZQUFZLGVBQWUsYUFBYSxjQUFjLFlBQVksZ0JBQWdCLFVBQVUsbUJBQW1CLHFCQUFxQixpQkFBaUIsWUFBWSxjQUFjLHVCQUF1QjtBQUMvTSxTQUFTLFdBQVcsZUFBZSxVQUFVLFNBQVMsbUJBQW1CO0FBQ3pFLFNBQVMsUUFBUSxjQUFjO0FBQy9CLFNBQVMsVUFBVSxXQUFXLGVBQWUsZUFBZSxZQUFZLG1CQUFtQixXQUFXLDhCQUE4QjtBQUNwSSxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLHVCQUF1QixtQkFBbUIsd0JBQXdCO0FBQzNFLFNBQVMscUJBQXFCLGlDQUFpQztBQUMvRCxTQUFTLFNBQVMsWUFBWSxpQkFBaUIsZ0JBQWdCLGNBQWMsZ0JBQWdCLGFBQWEsa0JBQWtCLGdCQUFnQixjQUFjLGtCQUFrQiw0QkFBNEI7QUFDeE0sU0FBUyxrQkFBa0IsWUFBWSxzQkFBc0I7QUFDN0QsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyxzQkFBc0Isc0JBQXNCLHVCQUF1QjtBQUM1RSxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLHdCQUF3Qix3QkFBd0I7QUFDekQsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyxjQUFjLHNCQUFzQjtBQUM3QyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxnQ0FBZ0M7QUFDekMsU0FBUyxxQkFBcUIsd0JBQXdCLGdCQUFnQiwyQkFBMkIsa0JBQWtCLFdBQVcsWUFBWSw2QkFBNkI7QUFDdkssU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUIsa0JBQWtCLHVCQUFzQztBQUNwRixTQUFTLG9CQUFvQixnQkFBZ0IsZUFBZSxjQUFjLGVBQWUsYUFBYSxlQUFlLGFBQWEsT0FBTyxhQUFhO0FBQ3RKO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMsYUFBYSxvQkFBb0I7QUFDMUMsU0FBUyxhQUFhLHFCQUFxQix1QkFBdUIsbUJBQXNDLHVCQUF1QixZQUE4QixZQUFZLGNBQWMsaUJBQWlCO0FBQ3hNLFNBQVMsZUFBZTtBQUN4QixTQUFTLFNBQVMsU0FBUyw0QkFBNEI7QUFDdkQsU0FBUyxxQkFBcUI7QUFvQ3ZCLGFBQU0sNkJBQTZCO0FBQUEsRUFDeEM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBR0EsTUFBTSxvQ0FBbUg7QUFpQnpILE1BQU0sYUFBYSxnQkFBZ0I7QUFDbkMsTUFBTSx1QkFBdUIsZ0JBQWdCO0FBQzdDLE1BQU0sZ0JBQWdCLGdCQUFnQjtBQUN0QyxNQUFNLGtCQUFrQixRQUFRLGdCQUFnQixhQUFhO0FBQzdELE1BQU0sMkJBQTJCLFFBQVEsZ0JBQWdCLFlBQVk7QUFFckUsTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSxrQkFBa0IsUUFBUSxDQUFDO0FBQ2pDLE1BQU0sOEJBQThCLFFBQVEsR0FBRztBQUMvQyxNQUFNLGlDQUFpQyxRQUFRLEdBQUc7QUFJbEQsTUFBTSw0QkFBNEI7QUFDbEMsTUFBTSx1QkFBdUIsVUFBVSxRQUFRLGdCQUFnQixVQUFVLFFBQVEsaUJBQWUsUUFBUSxDQUFDO0FBQ3pHLE1BQU0sZ0NBQWdDLFFBQVEsQ0FBQztBQUN4QyxhQUFNLHFCQUFxQjtBQUVsQyxNQUFNLG1CQUFtQjtBQUN6QixNQUFNLHNCQUFzQjtBQUc1QixNQUFNLGdDQUFnQztBQUN0QyxNQUFNLDRCQUE0QjtBQUNsQyxNQUFNLHVCQUF1QjtBQUs3QixNQUFNLGtCQUFrQjtBQUd4QixNQUFNLG9CQUFvQjtBQUUxQixNQUFNLGtCQUE4QixDQUFDLFVBQVUsT0FBTztBQUN0RCxNQUFNLGdCQUF3QyxFQUFFLFFBQVEsVUFBVSxPQUFPLFNBQVMsUUFBUSxTQUFTO0FBQ25HLE1BQU0sZ0JBQXFELEVBQUUsUUFBUSxTQUFTLE9BQU8sU0FBUyxRQUFRLFFBQVE7QUFFOUcsTUFBTSxtQkFBbUI7QUFJekIsTUFBTSxxQkFBcUIsb0JBQUksUUFBaUM7QUFDaEUsTUFBTSxjQUFjO0FBQ3BCLE1BQU0sY0FBYztBQUNwQixNQUFNLHNCQUFzQjtBQUU1QixNQUFNLG9CQUFvQixvQkFBSSxJQUF1RDtBQUNyRixNQUFNLHNCQUF3QyxvQkFBSSxJQUFJO0FBRXRELFNBQVMsZ0JBQWdCLE1BQW9CO0FBRzNDLE1BQUksUUFBUSxLQUFLLFlBQVksbUJBQW1CLElBQUksSUFBSSxNQUFNLEtBQUssWUFBWSxjQUFjO0FBQzdGLGFBQVcsUUFBUSxLQUFLLE9BQU87QUFHN0IsUUFBSSxLQUFLLE1BQU8sUUFBTyxjQUFjO0FBQ3JDLFFBQUksS0FBSyxpQkFBaUIsT0FBVyxVQUFTLENBQUM7QUFDL0MsUUFBSSxRQUFRLFlBQWE7QUFDekIsVUFBTSxRQUFRLEtBQUs7QUFDbkIsUUFBSSxLQUFLLFFBQVEsS0FBSyxTQUFTLEtBQUssV0FBVyxLQUFLLFdBQVcsV0FBVyxLQUFLLElBQUksS0FDOUUsTUFBTSxTQUFTLFdBQVcsTUFBTSxTQUFTLGVBQWUsTUFBTSxTQUFTLFlBQVksTUFBTSxTQUFTLGdCQUNsRyxNQUFNLFNBQVMsV0FBVyxNQUFNLGlCQUFpQixNQUFNLGFBQWEsTUFBTSxlQUMxRSxNQUFNLFNBQVMsaUJBQWlCLE1BQU0sYUFBYSxNQUFNLFlBQWEsVUFBUztBQUFBLEVBQ3RGO0FBR0EsU0FBTyxTQUFTLFFBQVEsZUFBZSxRQUFRLEtBQUssS0FBSyxFQUFFLFNBQVMsY0FBYztBQUNwRjtBQUVPLGdCQUFTLFdBQVcsUUFBZSxnQkFBZ0IsVUFBNkIsQ0FBQyxHQUFTO0FBQy9GLFFBQU0sWUFBWSxRQUFRLGFBQWEsQ0FBQyxPQUFPO0FBQy9DLFFBQU0sZ0JBQWdCLGNBQWMsUUFBUSxXQUFXLENBQUMsR0FBRyxpQkFBaUIsR0FBRyxTQUFTLENBQUM7QUFDekYsUUFBTSxRQUFRLE9BQU8sWUFBWSxjQUFjLElBQUksQ0FBQyxPQUFPLFVBQVUsQ0FBQyxPQUFPLFFBQVEsUUFBUSxLQUFLLEtBQUssY0FBYyxLQUFLLEtBQUssUUFBUSxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7QUFJcEosUUFBTSxjQUFjLFFBQVEsS0FBSyxHQUFHO0FBQ3BDLFFBQU0sU0FBUyxRQUFRLFVBQVUsZ0JBQWdCLFVBQVUsZ0JBQWdCLEVBQUUsTUFBTSxTQUFTLElBQUk7QUFHaEcsUUFBTSxjQUFjLGFBQWEsU0FBUyxZQUNwQyxDQUFDLFFBQVEsVUFBVSxRQUFRLE9BQU8sU0FBUyxZQUFZLFFBQVEsUUFBUSxPQUFPLFNBQVMsWUFBWTtBQUN6RyxRQUFNLGNBQWMsY0FDaEIsT0FBTyxZQUFZLGNBQWMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLElBQUksU0FBUyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSTtBQUN2RixRQUFNLFlBQVksU0FBUyxZQUFZLFFBQVEsZUFBZSxXQUFXLElBQUk7QUFDN0UsUUFBTSxTQUFTLFdBQVcsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxVQUFVLFdBQVcsUUFBUSxRQUFRLENBQUMsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDbEosUUFBTSxPQUFPO0FBQUEsSUFDWCxrQkFBa0I7QUFBQSxJQUNsQixXQUFXO0FBQUEsSUFDWCxNQUFNO0FBQUEsSUFDTixPQUFPLGlCQUFpQixhQUFhO0FBQUEsSUFDckMsS0FBSyxZQUFZLEVBQUUsR0FBRyxVQUFVLEtBQUssR0FBRyxPQUFPLFVBQVUsTUFBTSxRQUFRLFVBQVUsTUFBTSxXQUFXLFVBQVUsV0FBVyxHQUFJLFVBQVUsVUFBVSxFQUFFLFNBQVMsVUFBVSxRQUFRLElBQUksQ0FBQyxFQUFHLElBQUksVUFBVSxLQUFLO0FBQUEsSUFDdk0sU0FBUyxtQkFBbUIsZUFBZSxPQUFPO0FBQUEsSUFDbEQsT0FBTyxXQUFXLFNBQVMsbUJBQW1CLE9BQU8sZUFBZSxLQUFLO0FBQUEsSUFDekUsV0FBVyxXQUFXLGFBQWEsdUJBQXVCLGVBQWUsT0FBTyxLQUFLO0FBQUEsSUFDckYsV0FBVyxXQUFXLGFBQWEsdUJBQXVCLE9BQU8sZUFBZSxLQUFLO0FBQUEsSUFDckYsZ0JBQWdCLFdBQVcsa0JBQWtCLDRCQUE0QixLQUFLO0FBQUEsSUFDOUUsR0FBSSxNQUFNLFNBQVMsSUFBSSxFQUFFLE1BQU0sSUFBSSxDQUFDO0FBQUEsSUFDcEMsT0FBTyxXQUFXLFNBQVMsbUJBQW1CLEtBQUs7QUFBQSxJQUNuRCxhQUFhLENBQUM7QUFBQSxJQUNkLFNBQVMsQ0FBQztBQUFBLElBQ1YsR0FBSSxXQUFXLFVBQVUsU0FBUyxFQUFFLFdBQVcsVUFBVSxVQUFVLElBQUksQ0FBQztBQUFBLElBQ3hFLFFBQVE7QUFBQSxJQUNSO0FBQUEsSUFDQTtBQUFBLElBQ0EsVUFBVSxPQUFzQixNQUFnQixHQUFXLEdBQVcsWUFBdUI7QUFHM0YsWUFBTSxLQUFLLGNBQWMsYUFBYSxLQUFLLEtBQUssR0FBRyxHQUFHLFVBQVUsSUFBSSxDQUFDO0FBQ3JFLFlBQU0sT0FBTyxXQUFXLFFBQVEsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLE1BQU0sSUFBSSxPQUFPLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUN2RixVQUFHLFlBQVksSUFBSSxHQUFHO0FBQ3BCLGNBQU0sVUFBUSxZQUFZLE1BQUssS0FBSyxPQUFNLFFBQVE7QUFDbEQsY0FBTSxTQUFPLENBQUMsR0FBRyxLQUFLLE9BQU0sR0FBRyxLQUFLLFdBQVUsR0FBSSxLQUFLLGFBQWEsQ0FBQyxDQUFFO0FBQ3ZFLGNBQU0sUUFBTSxDQUFDQSxVQUFnQixRQUFRQSxPQUFLQSxLQUFJLEtBQUssb0JBQW9CLEtBQUssS0FBSSxNQUFLQSxPQUFLLE1BQU07QUFDaEcsY0FBTSxPQUFLLGFBQWEsTUFBTSxVQUFVLElBQUksYUFBYSxTQUFZLGdCQUFnQixLQUFLLEtBQUksTUFBSyxJQUFHLE1BQUssS0FBSztBQUNoSCxZQUFHLENBQUMsS0FBSyxPQUFNLElBQUksTUFBTSxvQ0FBb0M7QUFDN0QsZUFBTyxPQUFPLE1BQUssRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssRUFBQyxDQUFDO0FBQUUsYUFBSyxVQUFRLEVBQUMsU0FBUSxLQUFLLFNBQVEsT0FBTSxHQUFFLE1BQUssR0FBRSxTQUFRLEVBQUM7QUFBQSxNQUNyRztBQUNBLFdBQUssVUFBVTtBQUNmLHdCQUFrQixNQUFNLElBQUk7QUFDNUIsV0FBSyxNQUFNLEtBQUssSUFBSTtBQUNwQiw4QkFBd0IsRUFBQyxHQUFHLE1BQUssT0FBTSxDQUFDLElBQUksRUFBQyxDQUFDO0FBQzlDLHlCQUFtQixFQUFDLEdBQUcsTUFBSyxPQUFNLENBQUMsSUFBSSxFQUFDLEdBQUUsSUFBSTtBQUM5QywyQkFBcUIsTUFBSyxDQUFDLElBQUksQ0FBQztBQUNoQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxPQUFLLElBQUksT0FBTyxFQUFFLEdBQUcsYUFBYTtBQUNsQyxNQUFJLFFBQVEsU0FBVSx1QkFBc0IsTUFBTSxRQUFRLFFBQVE7QUFJbEUsYUFBVyxZQUFZLEtBQUssVUFBVyxRQUFPLE9BQU8sVUFBVSxnQkFBZ0IsS0FBSyxLQUFLLFNBQVMsUUFBUSxRQUFRLENBQUM7QUFDbkgsMEJBQXdCLElBQUk7QUFDNUIscUJBQW1CLE1BQUssSUFBSTtBQUM1Qix1QkFBcUIsSUFBSTtBQUN6QixtQkFBaUIsS0FBSyxLQUFJLEtBQUssS0FBSztBQUNwQyxvQkFBa0IsSUFBSTtBQUN0QixxQkFBbUIsSUFBSSxNQUFNLEtBQUssU0FBUztBQUMzQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGNBQWMsU0FBcUI7QUFDMUMsU0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE9BQU8sQ0FBQztBQUM3QjtBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQU87QUFBQSxJQUNMLFFBQVE7QUFBQSxJQUNSLGFBQWE7QUFBQSxJQUNiLE9BQU87QUFBQSxNQUNMLGFBQWEsRUFBRSxHQUFHLGlCQUFpQixPQUFPLEdBQUcsU0FBUyxFQUFFO0FBQUEsTUFDeEQsV0FBVyxFQUFFLEdBQUcsaUJBQWlCLE9BQU8sR0FBRyxTQUFTLEVBQUU7QUFBQSxNQUN0RCxvQkFBb0IsaUJBQWlCLE9BQU87QUFBQSxNQUM1QywyQkFBMkIsaUJBQWlCLE9BQU87QUFBQSxNQUNuRCxXQUFXLGlCQUFpQixPQUFPO0FBQUEsTUFDbkMsZ0JBQWdCLGlCQUFpQixPQUFPO0FBQUEsTUFDeEMsb0JBQW9CLGlCQUFpQixPQUFPO0FBQUEsTUFDNUMsc0JBQXNCLGlCQUFpQixPQUFPO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixlQUEyQixTQUE0QztBQUNqRyxRQUFNLFVBQVUsQ0FBQztBQUNqQixhQUFXLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxHQUFHLG9CQUFJLElBQUksQ0FBQyxHQUFHLGVBQWUsVUFBVSxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsUUFBUSxHQUFHO0FBQ3BHLFlBQVEsS0FBSyxJQUFJO0FBQUEsTUFDZixNQUFNLFFBQVEsUUFBUSxLQUFLLEtBQUssY0FBYyxLQUFLLE1BQU0sUUFBUSxNQUFNLElBQUksVUFBVTtBQUFBLE1BQ3JGLE1BQU07QUFBQSxNQUNOLFlBQVk7QUFBQSxNQUNaLFdBQVc7QUFBQSxNQUNYLFVBQVUseUJBQXlCO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFPLG1CQUFtQixPQUFPLEtBQUssT0FBTyxDQUFDO0FBQ3BELGFBQVUsQ0FBQyxPQUFNLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxFQUFFLFFBQU8sUUFBTSxPQUFPLEtBQUs7QUFDN0UsU0FBTztBQUNUO0FBRUEsU0FBUywyQkFBMkI7QUFDbEMsU0FBTyxPQUFPLFlBQVksY0FBYyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUNoRjtBQUVBLFNBQVMsaUJBQWlCLFNBQXFCO0FBQzdDLFNBQU8sT0FBTyxZQUFZLENBQUMsR0FBRyxvQkFBSSxJQUFJLENBQUMsR0FBRyxTQUFTLFVBQVUsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUM5RztBQUVBLFNBQVMsb0JBQW9CLE1BQVk7QUFDdkMsT0FBSyxVQUFVLEtBQUssZUFBZSw0QkFBNEIsVUFBVSxZQUFZLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLENBQUM7QUFDckgsT0FBSyxNQUFNO0FBQUEsSUFDVCxXQUFXLHdCQUF3QixVQUFVLFVBQVUsS0FBSyxJQUFJLFFBQVEsS0FBSyxHQUFHO0FBQUEsSUFDaEYsV0FBVyx3QkFBd0IsVUFBVSxVQUFVLEtBQUssSUFBSSxRQUFRLEtBQUssR0FBRztBQUFBLElBQ2hGLFdBQVcsd0JBQXdCLFVBQVUsVUFBVSxLQUFLLElBQUksUUFBUSxLQUFLLEdBQUc7QUFBQSxFQUNsRjtBQUNBLE9BQUssVUFBVSxLQUFLLEVBQUUsSUFBSSxvQkFBb0IsTUFBTSxZQUFZLEdBQUcsS0FBSyxJQUFJLFFBQVEsS0FBSyxHQUFHLEtBQUssUUFBUSxJQUFLLENBQUM7QUFDakg7QUFFQSxTQUFTLHNCQUFzQixNQUFZLFVBQTRCO0FBQ3JFLE1BQUksU0FBUyxvQkFBcUIsTUFBSyxRQUFRLENBQUM7QUFDaEQsTUFBSSxTQUFTLHdCQUF5QixNQUFLLFlBQVksQ0FBQztBQUN4RCxNQUFJLFNBQVMsd0JBQXlCLE1BQUssWUFBWSxDQUFDO0FBQ3hELE1BQUksU0FBUyw2QkFBOEIsTUFBSyxpQkFBaUIsQ0FBQztBQUNsRSxNQUFJLFNBQVMsd0JBQXlCLE1BQUssSUFBSSxZQUFZLENBQUM7QUFDNUQsUUFBTSxNQUFNLG9CQUFJLElBQUk7QUFBQSxJQUNsQixHQUFHLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUU7QUFBQSxJQUNuQyxHQUFHLEtBQUssVUFBVSxJQUFJLENBQUMsYUFBYSxTQUFTLEVBQUU7QUFBQSxJQUMvQyxHQUFHLEtBQUssVUFBVSxJQUFJLENBQUMsYUFBYSxTQUFTLEVBQUU7QUFBQSxJQUMvQyxHQUFHLEtBQUssZUFBZSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUU7QUFBQSxJQUM1QyxJQUFJLEtBQUssU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsS0FBSyxFQUFFO0FBQUEsSUFDM0MsR0FBRyxLQUFLLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxFQUFFO0FBQUEsSUFDbkMsR0FBRyxLQUFLLElBQUksVUFBVSxJQUFJLENBQUMsYUFBYSxTQUFTLEVBQUU7QUFBQSxFQUNyRCxDQUFDO0FBQ0QsUUFBTSxVQUFVLENBQUMsT0FBZTtBQUM5QixRQUFJLElBQUksSUFBSSxFQUFFLEVBQUcsT0FBTSxJQUFJLE1BQU0seUJBQXlCLEVBQUUsRUFBRTtBQUM5RCxRQUFJLElBQUksRUFBRTtBQUFBLEVBQ1o7QUFFQSxhQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssT0FBTyxRQUFRLFNBQVMsV0FBVyxDQUFDLENBQUMsR0FBdUM7QUFDdEcsVUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLO0FBQ2pDLFFBQUksQ0FBQyxPQUFRLE9BQU0sSUFBSSxNQUFNLDJCQUEyQixLQUFLLEVBQUU7QUFDL0QsUUFBSSxLQUFLLFNBQVMsUUFBVztBQUMzQixVQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFHLE9BQU0sSUFBSSxNQUFNLDZCQUE2QixLQUFLLEVBQUU7QUFDdEcsYUFBTyxPQUFPLFVBQVUsS0FBSyxJQUFJO0FBQUEsSUFDbkM7QUFDQSxlQUFXLENBQUMsYUFBYSxLQUFLLEtBQUssT0FBTyxRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsR0FBOEI7QUFDakcsVUFBSSxDQUFDLE9BQU8sVUFBVSxLQUFLLEtBQUssUUFBUSxFQUFHLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixXQUFXLGNBQWMsS0FBSyxFQUFFO0FBQy9HLGFBQU8sU0FBUyxXQUFXLElBQUk7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFFQSxhQUFXLFlBQVksU0FBUyxnQkFBZ0IsQ0FBQyxHQUFHO0FBQ2xELFlBQVEsU0FBUyxFQUFFO0FBQ25CLFNBQUssVUFBVSxLQUFLLEVBQUUsR0FBRyxTQUFTLENBQUM7QUFBQSxFQUNyQztBQUNBLGFBQVcsUUFBUSxTQUFTLHFCQUFxQixDQUFDLEdBQUc7QUFDbkQsWUFBUSxLQUFLLEVBQUU7QUFDZixTQUFLLGVBQWUsS0FBSyxFQUFFLEdBQUcsS0FBSyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxhQUFXLFFBQVEsU0FBUyxZQUFZLENBQUMsR0FBRztBQUMxQyxZQUFRLEtBQUssRUFBRTtBQUNmLEtBQUMsS0FBSyxVQUFVLENBQUMsR0FBRyxLQUFLLEVBQUUsR0FBRyxNQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxVQUFVLEVBQUUsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDO0FBQUEsRUFDdEY7QUFDQSxhQUFXLFFBQVEsU0FBUyxZQUFZLENBQUMsR0FBRztBQUMxQyxZQUFRLEtBQUssRUFBRTtBQUNmLFNBQUssTUFBTSxLQUFLLEVBQUUsR0FBRyxLQUFLLENBQUM7QUFBQSxFQUM3QjtBQUNBLGFBQVcsUUFBUSxTQUFTLFlBQVksQ0FBQyxHQUFHO0FBQzFDLFlBQVEsS0FBSyxFQUFFO0FBQ2YsVUFBTSxPQUFPLFdBQVcsS0FBSyxJQUFJLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN0RSxzQkFBa0IsTUFBTSxJQUFJO0FBQzVCLFFBQUksS0FBSyxPQUFPLFFBQVc7QUFDekIsVUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEVBQUUsS0FBSyxLQUFLLEtBQUssRUFBRyxPQUFNLElBQUksTUFBTSwyQkFBMkIsS0FBSyxFQUFFLEVBQUU7QUFDbEcsV0FBSyxLQUFLLEtBQUs7QUFDZixtQkFBYSxNQUFNLElBQUk7QUFBQSxJQUN6QjtBQUNBLFFBQUksS0FBSyxPQUFPLFFBQVc7QUFDekIsVUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEVBQUUsS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFPLE9BQU0sSUFBSSxNQUFNLDJCQUEyQixLQUFLLEVBQUUsRUFBRTtBQUMzSCxXQUFLLEtBQUssS0FBSztBQUFBLElBQ2pCO0FBQ0EsUUFBSSxLQUFLLFlBQVksUUFBVztBQUM5QixVQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssT0FBTyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssVUFBVSxFQUFHLE9BQU0sSUFBSSxNQUFNLGdDQUFnQyxLQUFLLEVBQUUsRUFBRTtBQUN0SSxXQUFLLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLEtBQUssUUFBUSxLQUFLLE9BQU8sQ0FBQztBQUFBLElBQzdEO0FBQ0EsUUFBSSxLQUFLLE1BQU8sTUFBSyxRQUFRLEVBQUUsR0FBRyxLQUFLLE1BQU07QUFDN0MsU0FBSyxNQUFNLEtBQUssSUFBSTtBQUFBLEVBQ3RCO0FBQ0EsYUFBVyxRQUFRLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztBQUM5QyxZQUFRLEtBQUssRUFBRTtBQUNmLFVBQU0sV0FBVyxlQUFlLEtBQUssSUFBSSxLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxZQUFZLElBQUk7QUFDckcsUUFBSSxLQUFLLFVBQVUsUUFBVztBQUM1QixVQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssS0FBSyxLQUFLLEtBQUssU0FBUyxFQUFHLE9BQU0sSUFBSSxNQUFNLDhCQUE4QixLQUFLLEVBQUUsRUFBRTtBQUM1RyxlQUFTLFFBQVEsS0FBSztBQUFBLElBQ3hCO0FBQ0EsUUFBSSxLQUFLLE9BQU8sUUFBVztBQUN6QixVQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssRUFBRSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssS0FBSyxTQUFTLE1BQU8sT0FBTSxJQUFJLE1BQU0sMkJBQTJCLEtBQUssRUFBRSxFQUFFO0FBQy9ILGVBQVMsS0FBSyxLQUFLO0FBQUEsSUFDckI7QUFDQSxTQUFLLFVBQVUsS0FBSyxRQUFRO0FBQUEsRUFDOUI7QUFDQSxhQUFXLFlBQVksU0FBUyxnQkFBZ0IsQ0FBQyxHQUFHO0FBQ2xELFlBQVEsU0FBUyxFQUFFO0FBQ25CLFNBQUssSUFBSSxVQUFVLEtBQUssRUFBRSxHQUFHLFNBQVMsQ0FBQztBQUFBLEVBQ3pDO0FBQ0Y7QUFFTyxnQkFBUyxhQUFhLE1BQVksU0FBc0I7QUFDN0QscUJBQW1CLE1BQU0sVUFBVSxPQUFPO0FBQzVDO0FBRU8sZ0JBQVMsbUJBQW1CLE1BQVksT0FBaUIsU0FBc0I7QUFDcEYsTUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLEVBQUcsT0FBTSxJQUFJLE1BQU0sa0JBQWtCLEtBQUssRUFBRTtBQUNuRSxRQUFNLGdCQUFnQixhQUFhLFVBQVUsQ0FBQyxHQUFHLFFBQVEsT0FBTyxJQUFJLFlBQVksVUFBVSxDQUFDLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFDOUcsTUFBSSxjQUFjLFdBQVcsUUFBUSxTQUFVLGVBQWMsS0FBSyxRQUFRLFFBQVE7QUFDbEYsTUFBSSxpQkFBaUIsV0FBVyxRQUFRLFlBQWEsZUFBYyxLQUFLLFFBQVEsV0FBVztBQUMzRixNQUFJLFFBQVEsU0FBUyxrQkFBbUIsZUFBYyxLQUFLLFFBQVEsV0FBVztBQUM5RSxNQUFJLFFBQVEsU0FBUyxnQkFBZ0I7QUFDbkMsVUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUFDLFVBQVFBLE1BQUssT0FBTyxRQUFRLE1BQU07QUFDL0QsUUFBSSxNQUFNLFVBQVcsZUFBYyxLQUFLLEtBQUssU0FBUztBQUN0RCxRQUFJLFlBQVksUUFBUSxZQUFhLGVBQWMsS0FBSyxRQUFRLFlBQVksTUFBTTtBQUFBLGFBQ3pFLGlCQUFpQixRQUFRLGVBQWUsUUFBUSxZQUFZLFlBQWEsZUFBYyxLQUFLLFFBQVEsWUFBWSxXQUFXO0FBQUEsRUFDdEk7QUFDQSxNQUFJLFFBQVEsU0FBUyxnQkFBZ0IsUUFBUSxTQUFTLGdCQUFnQixLQUFLLE1BQU0sS0FBSyxVQUFRLGNBQWMsU0FBUyxLQUFLLEVBQUUsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFHO0FBQ2pKLFVBQU0sUUFBUSxxQkFBcUIsTUFBTSxPQUFPLE9BQU87QUFDdkQsUUFBSSxNQUFPLE9BQU0sSUFBSSxNQUFNLE1BQU0sT0FBTztBQUFBLEVBQzFDO0FBQ0EsTUFBSSxRQUFRLFNBQVMsZ0JBQWdCLFFBQVEsU0FBUyxjQUFjO0FBQ2xFLFVBQU0sV0FBUyxXQUFXLE1BQUssUUFBUSxTQUFRLEtBQUs7QUFDcEQsVUFBTSxXQUFTLFFBQVEsU0FBTyxlQUFlLElBQUksSUFBSSxvQkFBb0IsTUFBSyxRQUFRLENBQUMsSUFBSTtBQUMzRixlQUFXLFFBQVEsVUFBVTtBQUMzQixVQUFJLFFBQVEsU0FBUyxhQUFjLFlBQVcsTUFBSyxJQUFJO0FBQUEsZUFDOUMsU0FBVSxJQUFJLEtBQUssRUFBRSxFQUFHLGlCQUFnQixNQUFLLEVBQUMsTUFBSyxjQUFhLFFBQU8sS0FBSyxLQUFNLE9BQU0sQ0FBQztBQUFBLElBQ3BHO0FBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBRyxRQUFRLFNBQU8sYUFBYTtBQUM3QixVQUFNLFFBQU0scUJBQXFCLE1BQUssT0FBTSxPQUFPO0FBQ25ELFFBQUcsTUFBTSxPQUFNLElBQUksTUFBTSxNQUFNLE9BQU87QUFDdEMsVUFBTSxRQUFNLFdBQVcsTUFBSyxRQUFRLFNBQVEsS0FBSyxFQUFFLE9BQU8sVUFBTSxZQUFZLElBQUksQ0FBQztBQUNqRixRQUFHLENBQUMsUUFBUSxPQUFPLHNCQUFxQixLQUFLLE9BQU0sSUFBSSxJQUFJLE1BQU0sSUFBSSxVQUFNLEtBQUssRUFBRSxDQUFDLENBQUM7QUFDcEYsZUFBVSxRQUFRO0FBQ2hCLHNCQUFnQixNQUFLLEVBQUMsTUFBSyxhQUFZLFVBQVMsUUFBUSxTQUFRLEdBQUUsUUFBUSxNQUFNO0FBQ2xGO0FBQUEsRUFDRjtBQUNBLE1BQUcsUUFBUSxTQUFPLG1CQUFtQjtBQUNuQyxVQUFNLFFBQU0scUJBQXFCLE1BQUssT0FBTSxPQUFPO0FBQ25ELFFBQUcsTUFBTSxPQUFNLElBQUksTUFBTSxNQUFNLE9BQU87QUFDdEMsVUFBTSxRQUFNLFdBQVcsTUFBSyxRQUFRLFNBQVEsS0FBSyxFQUFFLE9BQU8sVUFBTSxZQUFZLElBQUksQ0FBQztBQUNqRix5QkFBcUIsS0FBSyxPQUFNLElBQUksSUFBSSxNQUFNLElBQUksVUFBTSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0FBQ2pFLGVBQVUsUUFBUSxPQUFPO0FBQ3ZCLHlCQUFtQixJQUFJO0FBQ3ZCLFVBQUcsS0FBSyxNQUFNLFNBQU8sWUFBWSxpQkFBZ0IsTUFBSyxFQUFDLE1BQUssT0FBTSxDQUFDO0FBQUEsSUFDckU7QUFDQSwyQkFBdUIsS0FBSyxLQUFLO0FBQ2pDO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUSxTQUFTLHFCQUFxQjtBQUN4QyxVQUFNLFFBQVEscUJBQXFCLE1BQU0sT0FBTyxPQUFPO0FBQ3ZELFFBQUksTUFBTyxPQUFNLElBQUksTUFBTSxNQUFNLE9BQU87QUFDeEMsVUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUFDLFVBQVFBLE1BQUssT0FBTyxRQUFRLE1BQU07QUFDL0QsU0FBSyxlQUFlLFFBQVE7QUFDNUIsd0JBQW9CLElBQUk7QUFDeEI7QUFBQSxFQUNGO0FBQ0EsTUFBRyxhQUFhLFdBQVcsRUFBRSxZQUFZLFdBQVcsUUFBUSxXQUFXLENBQUMsUUFBTyxjQUFhLFFBQU8sZ0JBQWUsVUFBUyxVQUFTLE9BQU0sUUFBUSxFQUFFLFNBQVMsUUFBUSxJQUFJLEdBQUU7QUFDekssVUFBTSxRQUFNLElBQUksSUFBSSxXQUFXLE1BQUssUUFBUSxTQUFRLEtBQUssRUFBRSxPQUFPLFVBQU0sWUFBWSxJQUFJLENBQUMsRUFBRSxJQUFJLFVBQU0sS0FBSyxFQUFFLENBQUM7QUFDN0csUUFBRyxNQUFNLEtBQUssc0JBQXFCLEtBQUssT0FBTSxLQUFLO0FBQUEsRUFDckQ7QUFFQSxNQUFJLFFBQVEsU0FBUyxRQUFRO0FBQzNCLGVBQVcsUUFBUSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssR0FBRztBQUMzRCxzQkFBZ0IsTUFBTSxlQUFlLE1BQU0sTUFBTSxFQUFFLE1BQU0sUUFBUSxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFJLFFBQVEsY0FBYyxFQUFDLGFBQVksS0FBSSxJQUFJLENBQUMsRUFBRyxDQUFDLEdBQUcsUUFBUSxNQUFNO0FBQUEsSUFDcEs7QUFDQSxjQUFVLE1BQU0sUUFBUSxTQUFTLGVBQWUsUUFBUSxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsU0FBUyxLQUFLLElBQUksRUFBRSxNQUFNLENBQUM7QUFDakg7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsY0FBYztBQUNqQyxlQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDM0Qsc0JBQWdCLE1BQU0sZUFBZSxNQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssZUFBZSxJQUFJLGVBQWUsUUFBUSxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVEsRUFBRSxDQUFDLEdBQUcsUUFBUSxNQUFNO0FBQUEsSUFDdko7QUFDQSxjQUFVLE1BQU0sUUFBUSxTQUFTLGlCQUFpQixVQUFVLFFBQVEsR0FBRyxRQUFRLEdBQUcsUUFBUSxTQUFTLEtBQUssSUFBSSxFQUFFLE1BQU0sQ0FBQztBQUNySDtBQUFBLEVBQ0Y7QUFFQSxNQUFJLFFBQVEsU0FBUyxRQUFRO0FBQzNCLGVBQVcsUUFBUSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssRUFBRyxpQkFBZ0IsTUFBTSxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBQ25HO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLE9BQU87QUFDMUIsUUFBSSxDQUFDLE9BQU8sU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sU0FBUyxRQUFRLENBQUMsRUFBRyxPQUFNLElBQUksTUFBTSw2QkFBNkI7QUFDN0csZUFBVyxRQUFRLFdBQVcsTUFBTSxRQUFRLFNBQVMsS0FBSyxHQUFHO0FBQzNELFVBQUksY0FBYyxZQUFZLE1BQU0sSUFBSSxDQUFDLEVBQUcsaUJBQWdCLE1BQU0sRUFBRSxNQUFNLE9BQU8sR0FBRyxNQUFNLFFBQVEsR0FBRyxHQUFHLEtBQUssSUFBSSxLQUFLLEdBQUcsR0FBRyxNQUFNLFFBQVEsR0FBRyxHQUFHLEtBQUssSUFBSSxNQUFNLEVBQUUsR0FBRyxRQUFRLE1BQU07QUFBQSxJQUNwTDtBQUNBO0FBQUEsRUFDRjtBQUtBLE1BQUksUUFBUSxTQUFTLGdCQUFnQjtBQUNuQyxlQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDM0QsVUFBSSxLQUFLLFNBQVMsU0FBVTtBQUM1QixzQkFBZ0IsTUFBTSxFQUFFLE1BQU0sUUFBUSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssRUFBRSxHQUFHLFFBQVEsTUFBTTtBQUFBLElBQzlFO0FBQ0E7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsVUFBVTtBQUU3QixlQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDM0QsVUFBSSxLQUFLLGVBQWUsRUFBRyxpQkFBZ0IsTUFBTSxFQUFFLE1BQU0sVUFBVSxVQUFVLFFBQVEsU0FBUyxHQUFHLFFBQVEsTUFBTTtBQUFBLElBQ2pIO0FBQ0EsVUFBTSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsUUFBUTtBQUN0RCxRQUFJLE9BQVEsV0FBVSxNQUFNLFFBQVEsU0FBUyx1QkFBdUIsZ0JBQWdCLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUSxTQUFTLEtBQUssSUFBSSxFQUFFLE1BQU0sQ0FBQztBQUMzSTtBQUFBLEVBQ0Y7QUFJQSxNQUFJLFFBQVEsU0FBUyxVQUFVO0FBQzdCLFVBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLFFBQVEsWUFBWSxDQUFDLGVBQWUsTUFBTSxLQUFLLE9BQU8sS0FBSyxDQUFDO0FBQ2pILFFBQUksQ0FBQyxPQUFRLE9BQU0sSUFBSSxNQUFNLHlCQUF5QixRQUFRLFFBQVEsRUFBRTtBQUN4RSxlQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDM0QsVUFBSSxTQUFTLE9BQVEsaUJBQWdCLE1BQU0sRUFBRSxNQUFNLFVBQVUsVUFBVSxPQUFPLEdBQUcsR0FBRyxRQUFRLE1BQU07QUFBQSxJQUNwRztBQUNBLGNBQVUsTUFBTSxRQUFRLFNBQVMsZUFBZSxRQUFRLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUSxTQUFTLEtBQUssSUFBSSxFQUFFLE1BQU0sQ0FBQztBQUMvRztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFFBQVEsU0FBUyxRQUFRO0FBQzNCLFVBQU0sV0FBVyxLQUFLLFVBQVUsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLFFBQVEsVUFBVTtBQUN2RixRQUFJLENBQUMsU0FBVSxPQUFNLElBQUksTUFBTSxvQkFBb0IsUUFBUSxVQUFVLEVBQUU7QUFDdkUsZUFBVyxRQUFRLFdBQVcsTUFBTSxRQUFRLFNBQVMsS0FBSyxFQUFFLE9BQU8sQ0FBQ0EsVUFBU0EsTUFBSyxTQUFTLFFBQVEsR0FBRztBQUdwRyxZQUFNLFFBQW1CLENBQUMsUUFBUSxVQUFVLEtBQUssTUFBTSxTQUFTLFVBQVUsS0FBSyxNQUFNLGVBQWUsU0FBUyxLQUN6RyxLQUFLLFFBQ0wsRUFBRSxNQUFNLFFBQVEsWUFBWSxTQUFTLElBQUksT0FBTyxLQUFLLGVBQWUsSUFBSSxXQUFXLFVBQVUsT0FBTyxFQUFFO0FBQzFHLHNCQUFnQixNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsSUFDN0M7QUFDQSxjQUFVLE1BQU0sUUFBUSxTQUFTLGVBQWUsUUFBUSxTQUFTLEdBQUcsU0FBUyxHQUFHLFFBQVEsU0FBUyxLQUFLLElBQUksRUFBRSxNQUFNLENBQUM7QUFDbkg7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsVUFBVTtBQUM3QixVQUFNQyxZQUFXLEtBQUssVUFBVSxLQUFLLENBQUMsY0FBYyxVQUFVLE9BQU8sUUFBUSxjQUFjLFVBQVUsVUFBVSxLQUFLO0FBQ3BILFFBQUksQ0FBQ0EsVUFBVSxPQUFNLElBQUksTUFBTSxXQUFXLEtBQUssYUFBYSxRQUFRLFVBQVUsRUFBRTtBQUNoRixRQUFJQSxVQUFTLE1BQU1BLFVBQVMsTUFBTyxPQUFNLElBQUksTUFBTSxHQUFHQSxVQUFTLElBQUksNEJBQTRCO0FBQy9GLGVBQVcsUUFBUSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssRUFBRSxPQUFPLENBQUNELFVBQVNBLE1BQUssU0FBUyxRQUFRLEdBQUc7QUFDcEcsc0JBQWdCLE1BQU0sRUFBRSxNQUFNLFVBQVUsWUFBWUMsVUFBUyxHQUFHLEdBQUcsUUFBUSxNQUFNO0FBQ2pGLFVBQUksS0FBSyxNQUFNLFNBQVMsWUFBWSxLQUFLLE1BQU0sZUFBZUEsVUFBUyxHQUFJLE1BQUssV0FBVztBQUFBLElBQzdGO0FBQ0EsMEJBQXNCLE1BQU1BLFdBQVUsUUFBUSxNQUFNO0FBQ3BEO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUSxTQUFTLGdCQUFnQixRQUFRLFNBQVMsY0FBYztBQUNsRSxVQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssZUFBYSxVQUFVLE9BQU8sUUFBUSxZQUFZLFVBQVUsVUFBVSxVQUMvRixRQUFRLFNBQVMsZ0JBQWdCLFVBQVUsVUFBVSxJQUFJLE1BQU0sTUFBTTtBQUMzRSxRQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSxXQUFXLEtBQUssa0JBQWtCLFFBQVEsUUFBUSxFQUFFO0FBQ2pGLFFBQUksQ0FBQyxnQkFBZ0IsTUFBTSxNQUFNLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxPQUFPLElBQUksa0RBQWtEO0FBQ3BILGVBQVcsVUFBVSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssRUFBRSxPQUFPLFVBQVEsS0FBSyxTQUFTLFFBQVE7QUFDakcsc0JBQWdCLFFBQVEsRUFBRSxNQUFNLGNBQWMsVUFBVSxPQUFPLEdBQUcsR0FBRyxRQUFRLE1BQU07QUFDckY7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsU0FBUztBQUM1QixVQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssT0FBTyxRQUFRLFVBQVUsS0FBSyxVQUFVLFNBQVMsS0FBSyxTQUFTLFFBQVE7QUFDckgsUUFBSSxDQUFDLE9BQVEsT0FBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLFdBQVcsUUFBUSxNQUFNLEVBQUU7QUFDeEUsUUFBSSxDQUFDLFVBQVUsWUFBWSxNQUFNLEtBQUssRUFBRSxJQUFJLEVBQUUsbUJBQW1CLFNBQVMsUUFBUSxZQUFZLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxZQUFZLE1BQU0sS0FBSyxFQUFFLElBQUksc0JBQXNCLFFBQVEsWUFBWSxFQUFFO0FBQzdMLFVBQU0sVUFBVSx5QkFBeUIsTUFBTSxRQUFRLGNBQWMsT0FBTztBQUM1RSxRQUFJLFFBQVMsT0FBTSxJQUFJLE1BQU0sR0FBRyxRQUFRLFlBQVksOEJBQThCLFFBQVEsSUFBSSxFQUFFO0FBQ2hHLFFBQUksdUJBQXVCLEtBQUssS0FBSyxRQUFRLGNBQWMsT0FBTyxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsUUFBUSxZQUFZLGlDQUFpQztBQUM3SSxRQUFJLFlBQVksTUFBTSxLQUFLLEVBQUUsT0FBTyxjQUFjLFFBQVEsWUFBWSxFQUFFLEtBQU0sT0FBTSxJQUFJLE1BQU0saUJBQWlCO0FBQy9HLFVBQU0sS0FBSyxnQkFBZ0IsS0FBSyxLQUFLLGNBQWMsUUFBUSxZQUFZLEVBQUUsUUFBUSxPQUFPO0FBRXhGLG9CQUFnQixRQUFRLEVBQUUsTUFBTSxTQUFTLGNBQWMsUUFBUSxjQUFjLEdBQUcsSUFBSSxjQUFjLEtBQUssTUFBTSxXQUFXLE9BQU8sR0FBRyxXQUFXLE9BQU8sRUFBRSxDQUFDO0FBRXZKO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLGtCQUFrQjtBQUNyQyxVQUFNQSxZQUFXLEtBQUssVUFBVSxLQUFLLE9BQUssRUFBRSxPQUFPLFFBQVEsY0FBYyxFQUFFLFVBQVUsS0FBSztBQUMxRixRQUFJLENBQUNBLFVBQVUsT0FBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLGFBQWEsUUFBUSxVQUFVLEVBQUU7QUFDaEYsVUFBTSxRQUFRQSxVQUFTLE1BQU0sVUFBVSxDQUFBQyxTQUFPQSxLQUFJLE9BQU8sUUFBUSxLQUFLO0FBRXRFLFFBQUksUUFBUSxFQUFHO0FBQ2YsVUFBTSxDQUFDLEdBQUcsSUFBSUQsVUFBUyxNQUFNLE9BQU8sT0FBTyxDQUFDO0FBQzVDLFVBQU0sU0FBTyxJQUFLLFlBQVksVUFBVSxJQUFLLFFBQVEsRUFBRTtBQUN2RCxnQkFBWSxNQUFNLEtBQUssRUFBRSxPQUFPLFFBQVEsWUFBWSxNQUFNLEtBQUssRUFBRSxNQUFNLE1BQU07QUFDN0UsU0FBSyxNQUFNLE1BQU0sVUFBVSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLE1BQU0sVUFBVSxLQUFLLEtBQUssS0FBSyxNQUFNO0FBQ2pHLHNCQUFrQixJQUFJO0FBQ3RCO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLFlBQVk7QUFDL0IsYUFBUyxNQUFNLE9BQU8sUUFBUSxhQUFhLFFBQVEsR0FBRyxRQUFRLEdBQUcsUUFBUSxNQUFNO0FBQy9FO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLFFBQVE7QUFDM0IsVUFBTSxZQUFZLEtBQUssTUFBTTtBQUM3QixnQkFBWSxNQUFNLE9BQU8sUUFBUSxRQUFRLFFBQVEsU0FBUyxRQUFRLFVBQVUsUUFBUSxHQUFHLFFBQVEsR0FBRyxRQUFRLE1BQU07QUFDaEgsUUFBSSxLQUFLLE1BQU0sV0FBVyxVQUFXLHNDQUFxQyxJQUFJO0FBQzlFO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLGVBQWU7QUFDbEMsUUFBSSxDQUFDLFlBQVksUUFBUSxPQUFPLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxRQUFRLE9BQU8scUJBQXFCO0FBQzFGLGVBQVcsUUFBUSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssR0FBRztBQUMzRCxVQUFJLENBQUMsY0FBYyxJQUFJLEVBQUUsU0FBUyxRQUFRLE9BQU8sRUFBRztBQUNwRCxZQUFNLFdBQVcsYUFBYSxNQUFNLFFBQVEsU0FBUyxRQUFRLE9BQU87QUFDcEUsVUFBSSxTQUFVLE1BQUssV0FBVztBQUFBLFVBQ3pCLE1BQUssV0FBVztBQUFBLElBQ3ZCO0FBQ0E7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsYUFBYTtBQUNoQyxlQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDM0QsVUFBSSxjQUFjLEtBQUssSUFBSSxFQUFHLE1BQUssU0FBUyxRQUFRLFdBQVcsV0FBVyxTQUFZLFFBQVE7QUFBQSxJQUNoRztBQUNBO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLFFBQVE7QUFDM0Isa0JBQWMsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUN6Qyx5Q0FBcUMsSUFBSTtBQUN6QztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFFBQVEsU0FBUyxPQUFPO0FBQzFCLFlBQVEsTUFBTSxPQUFPLFFBQVEsUUFBUSxRQUFRLE1BQU0sUUFBUSxXQUFXO0FBQ3RFO0FBQUEsRUFDRjtBQUdBLE1BQUksUUFBUSxTQUFTLFNBQVM7QUFDNUIsVUFBTSxZQUFZLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sUUFBUSxlQUFlLEtBQUssS0FBRyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUM7QUFDN0csUUFBSSxDQUFDLFVBQVcsT0FBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLGNBQWMsUUFBUSxXQUFXLEVBQUU7QUFDbkYsVUFBTSxXQUFXLFdBQVcsTUFBTSxRQUFRLFNBQVMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTLFNBQVMsV0FBVSxNQUFLLEtBQUssS0FBSyxDQUFDO0FBQzlHLFVBQU0sV0FBVyxLQUFLLE1BQU0sS0FBSyxVQUFRLEtBQUssTUFBTSxTQUFTLFdBQVcsS0FBSyxNQUFNLGdCQUFnQixVQUFVLEVBQUU7QUFDL0csVUFBTSxlQUFhLFNBQVMsS0FBSyxVQUFNLENBQUMsS0FBSyxJQUFJO0FBQ2pELFVBQU0sU0FBUyxVQUFVLE1BQU0sU0FBUyxVQUFVLFNBQVMsTUFBTSxRQUFRLFlBQWUsZ0JBQWdCLGNBQWMsS0FBSyxLQUFLLGNBQWMsU0FBUztBQUN2SixlQUFXLFFBQVEsVUFBVTtBQUMzQixzQkFBZ0IsTUFBTSxFQUFFLE1BQU0sU0FBUyxhQUFhLFVBQVUsSUFBSSxHQUFJLENBQUMsS0FBSyxRQUFRLFFBQVEsRUFBRSxNQUFNLElBQUksQ0FBQyxFQUFHLEdBQUcsUUFBUSxNQUFNO0FBQzdILFlBQU0sU0FBTyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssVUFBTSxLQUFLLE9BQUssS0FBSyxLQUFNLFVBQVUsS0FBSyxVQUFRLEtBQUs7QUFDakcsVUFBRyxVQUFVLENBQUMsUUFBUSxVQUFVLENBQUMsT0FBTyxTQUFTLFFBQVEsaUJBQWdCLFFBQU8sRUFBQyxNQUFLLE9BQU0sQ0FBQztBQUFBLElBQy9GO0FBQ0E7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsbUJBQW1CO0FBQ3RDLFVBQU0sWUFBWSxXQUFXLE1BQU0sQ0FBQyxRQUFRLFdBQVcsR0FBRyxLQUFLLEVBQUUsQ0FBQztBQUNsRSxRQUFJLFVBQVcsYUFBWSxNQUFNLFdBQVcsUUFBUSxXQUFXO0FBQy9EO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLFVBQVU7QUFDN0IsZUFBVyxRQUFRLFdBQVcsTUFBTSxRQUFRLFNBQVMsS0FBSyxHQUFHO0FBQzNELFVBQUksUUFBUSxJQUFJLElBQUksRUFBRyxpQkFBZ0IsTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFJLFFBQVEsY0FBYyxFQUFDLGFBQVksS0FBSSxJQUFJLENBQUMsRUFBRyxHQUFHLFFBQVEsTUFBTTtBQUFBLElBQ2pLO0FBQ0EsY0FBVSxNQUFNLFFBQVEsU0FBUyxlQUFlLFFBQVEsUUFBUSxHQUFHLFFBQVEsR0FBRyxRQUFRLFNBQVMsS0FBSyxJQUFJLEVBQUUsTUFBTSxDQUFDO0FBQ2pIO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxTQUFTLFlBQVk7QUFDL0IsVUFBTUEsWUFBVyxLQUFLLFVBQVUsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLFFBQVEsY0FBYyxVQUFVLFVBQVUsS0FBSztBQUNwSCxRQUFJLENBQUNBLFVBQVUsT0FBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLGFBQWEsUUFBUSxVQUFVLEVBQUU7QUFDaEYsa0JBQWMsTUFBTUEsV0FBVSxRQUFRLFdBQVc7QUFDakQ7QUFBQSxFQUNGO0FBRUEsTUFBRyxRQUFRLFNBQU8sb0JBQW1CO0FBQ25DLFVBQU0sT0FBSyxLQUFLLFVBQVUsS0FBSyxDQUFBQSxjQUFVQSxVQUFTLE9BQUssUUFBUSxjQUFjQSxVQUFTLFVBQVEsU0FBU0EsVUFBUyxTQUFPLGNBQWNBLFVBQVMsUUFBUTtBQUFFLFFBQUcsQ0FBQyxLQUFLLE9BQU0sSUFBSSxNQUFNLGtDQUFrQztBQUNuTixVQUFNLFdBQVMsUUFBUSxnQkFBYyxTQUFZLGtCQUFrQixNQUFLLE9BQU0sTUFBSyxRQUFRLE1BQUssUUFBUSxXQUFXLElBQUk7QUFDdkgsUUFBRyxZQUFZLGFBQWEsU0FBUyxPQUFNLElBQUksTUFBTSxTQUFTLE9BQU87QUFDckUsVUFBTSxNQUFJLGFBQWEsUUFBUSxJQUFJO0FBQUUsY0FBVSxNQUFLLE9BQU0sSUFBSSxJQUFJO0FBQUUsVUFBTSxLQUFHLGFBQWEsS0FBSyxLQUFJLEtBQUssR0FBRSxLQUFLLElBQUUsS0FBSyxTQUFPLElBQUcsTUFBTTtBQUN0SSxVQUFNLE9BQWUsRUFBQyxJQUFHLGFBQWEsS0FBSyxRQUFRLElBQUcsTUFBSyxRQUFRLE1BQUssR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLEdBQUUsWUFBVyxJQUFJLElBQUcsbUJBQWtCLEVBQUM7QUFBRSxTQUFLLE1BQU0sS0FBSyxJQUFJO0FBQ2pKLFFBQUcsWUFBWSxlQUFlLFNBQVMsaUJBQWdCLE1BQUssTUFBSyxTQUFTLFNBQVM7QUFBQSxRQUFPLFdBQVUsTUFBSyxVQUFTLEdBQUcsR0FBRSxHQUFHLEdBQUUsUUFBUSxHQUFFLENBQUM7QUFBRTtBQUFBLEVBQzNJO0FBQ0EsTUFBSSxRQUFRLFNBQVMsZ0JBQWdCO0FBQ25DLFVBQU0sVUFBUSxnQkFBZ0IsTUFBSyxPQUFNLFFBQVEsUUFBTyxRQUFRLFdBQVc7QUFBRSxRQUFHLFFBQVEsT0FBTSxJQUFJLE1BQU0sT0FBTztBQUMvRyxVQUFNLE9BQUssS0FBSyxNQUFNLEtBQUssQ0FBQUYsVUFBTUEsTUFBSyxPQUFLLFFBQVEsTUFBTTtBQUFHLFVBQU0sZUFBYSxLQUFLO0FBQU8sVUFBTSxTQUFPLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLEtBQUssU0FBUztBQUFFLFFBQUcsT0FBTyxpQkFBZ0IsUUFBTyxLQUFLLEVBQUU7QUFDaE0sV0FBTyxLQUFLO0FBQVUsV0FBTyxLQUFLO0FBQUssV0FBTyxLQUFLO0FBQU8sV0FBTyxLQUFLO0FBQVMsV0FBTyxLQUFLO0FBQVEsV0FBTyxLQUFLO0FBQy9HLFFBQUcsWUFBWSxRQUFRLGFBQVk7QUFBQyxXQUFLLFlBQVUsUUFBUSxZQUFZO0FBQU8sV0FBSyxPQUFLLFFBQVEsWUFBWTtBQUFBLElBQUssT0FBSztBQUFDLFdBQUssU0FBTyxRQUFRLFlBQVk7QUFBTyxVQUFHLGFBQWEsUUFBUSxhQUFZO0FBQUMsYUFBSyxVQUFRLFFBQVEsWUFBWTtBQUFRLGFBQUssZUFBYSxhQUFhLEtBQUssSUFBaUMsRUFBRTtBQUFBLE1BQUcsTUFBTSxNQUFLLFdBQVMsUUFBUSxZQUFZO0FBQUEsSUFBSztBQUNuVyx3QkFBb0IsS0FBSyxLQUFLO0FBQzlCLGVBQVUsUUFBUSxLQUFLLE9BQU07QUFBQyxVQUFHLFlBQVksSUFBSSxNQUFNLEtBQUssT0FBSyxnQkFBZ0IsS0FBSyxPQUFLLEtBQUssUUFBUSxxQkFBb0IsTUFBSyxJQUFJO0FBQUUsVUFBRyxLQUFLLE9BQUssUUFBUSxNQUFNLEtBQUssT0FBSyxLQUFLLGFBQWEsS0FBSyxPQUFLLGdCQUFnQixLQUFLLE9BQUssS0FBSyxPQUFPLHVCQUFzQixNQUFLLElBQUk7QUFBQSxJQUFFO0FBQUMseUJBQXFCLElBQUk7QUFBRTtBQUFBLEVBQzdTO0FBQ0EsTUFBRyxRQUFRLFNBQVMsYUFBWTtBQUM5QixVQUFNLFVBQVEsYUFBYSxNQUFLLE9BQU0sUUFBUSxRQUFPLFFBQVEsUUFBTyxRQUFRLElBQUk7QUFBRSxRQUFHLFFBQVEsT0FBTSxJQUFJLE1BQU0sT0FBTztBQUNwSCxVQUFNLE9BQUssS0FBSyxNQUFNLEtBQUssQ0FBQUMsVUFBTUEsTUFBSyxPQUFLLFFBQVEsTUFBTTtBQUFHLFNBQUssVUFBUSxDQUFDO0FBQzFFLFFBQUcsUUFBUSxRQUFPO0FBQUMsc0JBQWdCLE1BQUssUUFBUSxNQUFNO0FBQUUsV0FBSyxNQUFNLFFBQVEsSUFBSSxJQUFFLFFBQVE7QUFBTyxZQUFNLE9BQUssS0FBSyxNQUFNLEtBQUssQ0FBQUQsVUFBTUEsTUFBSyxPQUFLLFFBQVEsTUFBTTtBQUFHLFVBQUcsVUFBVSxJQUFJLE1BQUksRUFBRSxRQUFPLEtBQUssTUFBTTtBQUFBLElBQUssTUFBTSxRQUFPLEtBQUssTUFBTSxRQUFRLElBQUk7QUFDOU8sU0FBSyxNQUFJO0FBQVUsU0FBSyxXQUFTLEtBQUssSUFBSSxLQUFLLFVBQVMsUUFBUSxJQUFHLENBQUM7QUFBRSwwQkFBc0IsTUFBSyxJQUFJO0FBQUU7QUFBQSxFQUN6RztBQUNBLE1BQUksUUFBUSxTQUFTLGNBQWM7QUFDakMsZUFBVyxNQUFNLE9BQU8sUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLE1BQU07QUFDdEU7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsWUFBWTtBQUMvQixhQUFTLE1BQU0sT0FBTyxRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDMUU7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFNBQVMsV0FBVztBQUM5QixZQUFRLE1BQU0sT0FBTyxRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsVUFBVSxRQUFRLEdBQUcsUUFBUSxDQUFDO0FBQzNGO0FBQUEsRUFDRjtBQUVBLFFBQU0sV0FBVyxLQUFLLFVBQVUsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLFFBQVEsY0FBYyxVQUFVLFVBQVUsS0FBSztBQUNwSCxNQUFJLENBQUMsU0FBVSxPQUFNLElBQUksTUFBTSxXQUFXLEtBQUssYUFBYSxRQUFRLFVBQVUsRUFBRTtBQUNoRixnQkFBYyxNQUFNLFVBQVUsUUFBUSxRQUFRO0FBQ2hEO0FBRU8sZ0JBQVMsU0FBUyxNQUFZO0FBQ25DLE1BQUksS0FBSyxNQUFNLE9BQVE7QUFDdkIsUUFBTSxhQUFhLGdCQUFnQixJQUFJO0FBQ3ZDLFFBQU0sb0JBQW9CLENBQUMsRUFBRSxhQUFhO0FBQzFDLE1BQUksYUFBYSxDQUFDLEVBQUUsYUFBYTtBQUNqQyxNQUFJLFlBQVk7QUFDZCx5QkFBcUIsS0FBSyxPQUFNLElBQUk7QUFDcEMsUUFBSSxhQUFhLFlBQWEsbUJBQWtCLEtBQUssS0FBSztBQUMxRCxjQUFVLEtBQUssS0FBSztBQUNwQiwwQkFBc0IsSUFBSTtBQUFBLEVBQzVCO0FBQ0EsUUFBTSxhQUFhLEtBQUssT0FBTyxhQUFhLEtBQUssTUFBTTtBQUN2RCxPQUFLLFFBQVE7QUFDYixrQkFBZ0IsS0FBSyxLQUFLLEtBQUssSUFBSTtBQUVuQyxPQUFLLGNBQWMsbUJBQW1CLEtBQUssT0FBTyxLQUFLLEtBQUssV0FBVztBQUN2RSxzQkFBb0IsTUFBTSxpQkFBaUI7QUFDM0MscUJBQW1CLElBQUk7QUFDdkIscUJBQW1CLElBQUk7QUFDdkIsb0JBQWtCLElBQUk7QUFDdEIsMEJBQXdCLElBQUk7QUFDNUIscUJBQW1CLElBQUk7QUFDdkIsaUJBQWUsSUFBSTtBQUNuQixpQkFBZSxJQUFJO0FBQ25CLGtCQUFnQixJQUFJO0FBQ3BCLE9BQUssY0FBYyxtQkFBbUIsSUFBSTtBQUMxQyx1QkFBcUIsSUFBSTtBQUN6QixNQUFJLEtBQUssTUFBTyxjQUFhLEtBQUssS0FBSztBQUd2QyxRQUFNLGVBQWUsS0FBSyxVQUFVLGNBQWMsS0FBSyxNQUFNLFdBQVc7QUFDeEUsTUFBSSxDQUFDLGNBQWMsYUFBYyxjQUFhLENBQUMsRUFBRSxnQkFBZ0IsSUFBSSxJQUFJO0FBR3pFLE1BQUksY0FBYyxhQUFjLE1BQUssY0FBYyxtQkFBbUIsS0FBSyxPQUFPLEtBQUssS0FBSyxXQUFXO0FBQ3ZHLE9BQUssb0JBQW9CLHlCQUF5QixNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssaUJBQWlCO0FBQy9GLE9BQUssbUJBQW1CLGFBQWEsaUJBQWlCLEtBQUssS0FBSyxJQUFJO0FBQ3BFLE1BQUksQ0FBQyxLQUFLLG1CQUFtQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsUUFBUTtBQUNoRixTQUFLLGtCQUFrQixtQkFBbUIsS0FBSyxXQUFXLEdBQUc7QUFDN0QsU0FBSyx3QkFBd0IseUJBQXlCLE1BQU0sS0FBSyxXQUFXLEdBQUc7QUFDL0UsU0FBSyx1QkFBdUIsS0FBSyxVQUFVO0FBQUEsRUFDN0M7QUFDQSxPQUFLLGFBQWEsa0JBQWtCLElBQUk7QUFDeEMsY0FBWSxJQUFJO0FBQ2hCLHdCQUFzQixJQUFJO0FBQzFCLHFCQUFtQixJQUFJO0FBQ3ZCLE1BQUksV0FBWSxtQkFBa0IsSUFBSTtBQUN0QyxxQkFBbUIsSUFBSTtBQUN2QixRQUFNLFVBQVUsUUFBUSxLQUFLLEtBQUs7QUFDbEMsUUFBTSxTQUFTLFFBQVEsU0FBUyxJQUFJLElBQUksUUFBUSxJQUFJLFVBQVEsQ0FBQyxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxTQUFTLEtBQUssUUFBUyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFHcEksdUJBQXFCLEtBQUssT0FBTSxLQUFLLEtBQUksS0FBSyxzQkFBc0IsS0FBSyxXQUFVLE9BQU87QUFDMUYsTUFBSTtBQUNKLE1BQUksWUFBWTtBQUNkLDJCQUF1QixLQUFLLE9BQU0sS0FBSyxNQUFLLE9BQU87QUFDbkQsdUJBQW1CLEtBQUssS0FBSSxLQUFLLE9BQU0sS0FBSyxNQUFLLElBQUk7QUFDckQsMEJBQXNCLEtBQUssS0FBSSxLQUFLLEtBQUs7QUFDekMsU0FBSyxnQkFBYyxrQkFBa0IsS0FBSyxLQUFLO0FBQy9DLGVBQVMsd0JBQXdCLE1BQUssQ0FBQyxNQUFLLE9BQU0sVUFBUSx1QkFBdUIsTUFBSyxLQUFLLE9BQU0sTUFBSyxPQUFNLEtBQUssR0FBRSxLQUFLLGFBQWE7QUFDckksVUFBTSxnQkFBZ0Isb0JBQUksSUFBb0I7QUFDOUMsZUFBVyxRQUFRLEtBQUssTUFBTyxLQUFJLEtBQUssS0FBSyxLQUFLLENBQUMsS0FBSyxRQUFRLEtBQUssTUFBTSxTQUFTLFNBQVM7QUFDM0YsWUFBTSxVQUFVLGNBQWMsSUFBSSxLQUFLLE1BQU0sV0FBVztBQUN4RCxVQUFJLFFBQVMsU0FBUSxLQUFLLElBQUk7QUFBQSxVQUFRLGVBQWMsSUFBSSxLQUFLLE1BQU0sYUFBYSxDQUFDLElBQUksQ0FBQztBQUFBLElBQ3hGO0FBQ0EsZUFBVyxRQUFRLFFBQVEsS0FBSyxLQUFLLEdBQUc7QUFHdEMsWUFBTSxhQUFhLEtBQUssTUFBTSxTQUFTLFVBQVUsY0FBYyxJQUFJLEtBQUssRUFBRSxHQUFHLEtBQUssVUFBUSxLQUFLLFVBQVUsS0FBSyxTQUFTLENBQUMsVUFBVSxNQUFNLElBQUksQ0FBQztBQUM3SSxZQUFNLE9BQU8sS0FBSyxjQUFjLElBQUksS0FBSyxFQUFFLEtBQUssS0FBSyxNQUFNLFNBQVMsVUFBVSxLQUFLLE1BQU0sU0FBUyxVQUFVLENBQUMsY0FBYyxDQUFDLFNBQVMsSUFBSSxLQUFLLEVBQUUsS0FDM0ksQ0FBQyxDQUFDLEtBQUssU0FBUyxXQUFXLEtBQUssUUFBUSxRQUFRLFVBQVE7QUFDN0QscUJBQWUsTUFBTSxLQUFLLEtBQUssT0FBTyxTQUFTLEtBQUssU0FBUyxNQUFNLFNBQVMsU0FBUyxTQUFTLE1BQVM7QUFBQSxJQUN6RztBQUFBLEVBQ0YsT0FBTztBQUNMLFFBQUksQ0FBQyxLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBTSxNQUFLLGdCQUFnQixvQkFBSSxJQUFJO0FBQ2pGLGVBQVc7QUFBQSxFQUNiO0FBQ0EsUUFBTSxvQkFBb0IsS0FBSyxPQUFPLG1CQUFtQixLQUFLLE1BQU07QUFDcEUsUUFBTSxRQUFRLFlBQVksTUFBSyxVQUFTLFlBQVcsaUJBQWlCO0FBR3BFLE1BQUksQ0FBQyxlQUFlLFVBQVUsS0FBSyxVQUFVLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxxQkFBc0IsZ0JBQWdCLElBQUksSUFBSSxhQUFlLGNBQWE7QUFDbEssTUFBSSxXQUFZLHNCQUFxQixNQUFLLFFBQU8sUUFBUTtBQUN6RCxNQUFJLE1BQU8sWUFBVyxNQUFNLE9BQU8sTUFBTTtBQUN6QyxNQUFJLFlBQVk7QUFDZCxlQUFXLFFBQVEsUUFBUSxLQUFLLEtBQUssR0FBRztBQUFFLFlBQU0sUUFBUSxPQUFPLElBQUksS0FBSyxFQUFFO0FBQUcsVUFBSSxTQUFTLEtBQUssV0FBVyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEVBQUcsTUFBSyxRQUFRLFFBQVE7QUFBQSxJQUFHO0FBQzVLLHVCQUFtQixLQUFLLEtBQUksS0FBSyxPQUFNLEtBQUssTUFBSyxJQUFJO0FBQ3JELDJCQUF1QixLQUFLLEtBQUs7QUFDakMsY0FBVSxLQUFLLEtBQUs7QUFDcEIsc0JBQWtCLEtBQUssT0FBTSxLQUFLLEdBQUc7QUFDckMsMEJBQXNCLElBQUk7QUFBQSxFQUM1QjtBQUNBLGFBQVcsSUFBSTtBQUNmLGdCQUFjLE1BQU0sVUFBVTtBQUM5QixNQUFJLFdBQVksV0FBVSxLQUFLLEtBQUs7QUFDcEMsTUFBSSxLQUFLLElBQUksUUFBUyx5QkFBd0IsSUFBSTtBQUNsRCxhQUFVLFVBQVUsMEJBQTBCLEtBQUssS0FBSyxHQUFHO0FBQ3pELFVBQU0sUUFBTSxPQUFPO0FBQ25CLFVBQU0sU0FBTyxTQUFTLENBQUMsV0FBVyxLQUFLLElBQUksUUFBUSxPQUFPO0FBQzFELFFBQUcsT0FBTyxLQUFLLEtBQUcsS0FBSyxPQUFPLGFBQVcsR0FBRTtBQUN6QyxZQUFNLFFBQU0sWUFBWSxNQUFLLFFBQU8sT0FBTyxNQUFLLE9BQU8sWUFBVyxHQUFFLE9BQU8sT0FBTSxHQUFFLGdCQUFnQixTQUFTO0FBQzVHLFVBQUcsVUFBUSxVQUFhLFFBQU0sRUFBRSxjQUFhLE1BQUssT0FBTyxNQUFLLEtBQUs7QUFBQSxJQUNyRTtBQUNBLFFBQUcsU0FBUyxNQUFNLEtBQUcsS0FBSyxPQUFPLGNBQVksR0FBRTtBQUM3QyxZQUFNLFFBQU0sWUFBWSxNQUFLLE9BQU8sTUFBSyxPQUFNLE9BQU8sYUFBWSxHQUFFLE9BQU8sT0FBTSxHQUFFLGdCQUFnQixTQUFTO0FBQzVHLFVBQUcsVUFBUSxVQUFhLFFBQU0sRUFBRSxjQUFhLE1BQUssT0FBTSxLQUFLO0FBQUEsSUFDL0Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFZLFlBQVcsUUFBUSxRQUFRLEtBQUssS0FBSyxHQUFHO0FBQ3RELFVBQU0sUUFBUSxPQUFPLElBQUksS0FBSyxFQUFFO0FBQ2hDLFFBQUksQ0FBQyxLQUFLLFFBQVM7QUFDbkIsU0FBSyxRQUFRLFlBQVksU0FBUyxLQUFLLElBQUksTUFBTSxLQUFLLHVCQUF1QjtBQUM3RSxTQUFLLFFBQVEsWUFBWSxTQUFTLEtBQUssSUFBSSxNQUFNLEtBQUssdUJBQXVCO0FBQUEsRUFDL0U7QUFDQSxhQUFXLFFBQVEsS0FBSyxNQUFPLEtBQUcsS0FBSyxJQUFJLG9CQUFtQixNQUFNLFlBQVksTUFBTSxJQUFJLENBQUM7QUFDM0YscUJBQW1CLElBQUk7QUFDdkIsYUFBVyxJQUFJO0FBQ2YsTUFBRyxrQkFBa0IsS0FBSyxPQUFNLEtBQUssT0FBTSxLQUFLLEdBQUcsRUFBRSxzQkFBcUIsSUFBSTtBQUM5RSxNQUFJLFdBQVkscUJBQW9CLElBQUk7QUFDeEMscUJBQW1CLElBQUk7QUFFdkIsT0FBSyxjQUFjLG1CQUFtQixLQUFLLE9BQU8sS0FBSyxLQUFLLFdBQVc7QUFDdkUsc0JBQW9CLE1BQU0saUJBQWlCO0FBQzNDLGdCQUFjLElBQUk7QUFDcEI7QUFLQSxTQUFTLG1CQUFtQixNQUFZO0FBQ3RDLFFBQU0sT0FBTyxLQUFLO0FBQ2xCLFFBQU0sWUFBWSxLQUFLLGFBQWEsQ0FBQztBQUNyQyxRQUFNLFFBQVEsS0FBSyxVQUFVO0FBQzdCLE1BQUksUUFBUSxLQUFLLFdBQVcsUUFBUSxVQUFVLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQyxVQUFVLFVBQVUsYUFBYSxLQUFLLEtBQUssQ0FBQyxLQUFLLFVBQVUsTUFBTSxDQUFDLFVBQVUsVUFBVSxhQUFhLEtBQUssUUFBUSxLQUFLLENBQUMsRUFBRztBQUN2TSxPQUFLLHFCQUFxQixDQUFDLEdBQUcsS0FBSyxXQUFXLEdBQUcsU0FBUztBQUMxRCxvQkFBa0IsS0FBSyxLQUFLLEtBQUssa0JBQWtCO0FBQ3JEO0FBRUEsU0FBUyxjQUFjLE9BQTJCO0FBQ2hELFFBQU0sT0FBSyxFQUFDLEdBQUcsTUFBSztBQUNwQixPQUFJLEtBQUssU0FBTyxVQUFRLEtBQUssU0FBTyxpQkFBaUIsS0FBSyxVQUFVLE1BQUssWUFBVSxFQUFDLEdBQUcsS0FBSyxVQUFTO0FBQ3JHLE1BQUcsS0FBSyxTQUFPLFNBQVE7QUFDckIsUUFBRyxLQUFLLFVBQVUsTUFBSyxZQUFVLEVBQUMsR0FBRyxLQUFLLFVBQVM7QUFDbkQsUUFBRyxLQUFLLFdBQVcsTUFBSyxhQUFXLEVBQUMsR0FBRyxLQUFLLFdBQVU7QUFDdEQsUUFBRyxLQUFLLE1BQU0sTUFBSyxRQUFNLEVBQUMsR0FBRyxLQUFLLE1BQUs7QUFBQSxFQUN6QztBQUNBLFNBQU87QUFDVDtBQUNPLGdCQUFTLGFBQWEsTUFBMEI7QUFDckQsUUFBTSxXQUF3QjtBQUFBLElBQzVCLGtCQUFrQjtBQUFBLElBQ2xCLFdBQVc7QUFBQSxJQUNYLE1BQU0sS0FBSztBQUFBLElBQ1gsT0FBTztBQUFBLE1BQ0wsUUFBUSxLQUFLLE1BQU07QUFBQSxNQUNuQixhQUFhLEtBQUssTUFBTTtBQUFBLE1BQ3hCLE9BQU87QUFBQSxRQUNMLGFBQWEsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFNLFlBQVk7QUFBQSxRQUMvQyxXQUFXLEVBQUUsR0FBRyxLQUFLLE1BQU0sTUFBTSxVQUFVO0FBQUEsUUFDM0Msb0JBQW9CLEVBQUUsR0FBRyxLQUFLLE1BQU0sTUFBTSxtQkFBbUI7QUFBQSxRQUM3RCwyQkFBMkIsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFNLDBCQUEwQjtBQUFBLFFBQzNFLFdBQVcsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFNLFVBQVU7QUFBQSxRQUMzQyxnQkFBZ0IsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFNLGVBQWU7QUFBQSxRQUNyRCxvQkFBb0IsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFNLG1CQUFtQjtBQUFBLFFBQzdELHNCQUFzQixFQUFFLEdBQUcsS0FBSyxNQUFNLE1BQU0scUJBQXFCO0FBQUEsTUFDbkU7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLEVBQUUsR0FBRyxLQUFLLEtBQUssR0FBSSxLQUFLLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUc7QUFBQSxJQUM3RSxPQUFPLEVBQUUsR0FBRyxLQUFLLE1BQU07QUFBQSxJQUN2QixTQUFTLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTyxNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsR0FBRyxRQUFRLFVBQVUsRUFBRSxHQUFHLE9BQU8sU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDM0ksT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFNBQVM7QUFHOUIsWUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLO0FBQ3ZCLFdBQUssUUFBUSxjQUFjLEtBQUssS0FBSztBQUNyQyxXQUFLLGFBQWEsS0FBSyxZQUFZLElBQUksYUFBYSxLQUFLLENBQUM7QUFDMUQsVUFBSSxLQUFLLElBQUssTUFBSyxNQUFNLEVBQUUsR0FBRyxLQUFLLElBQUk7QUFDdkMsVUFBSSxLQUFLLEtBQU0sTUFBSyxPQUFPLEVBQUUsR0FBRyxLQUFLLEtBQUs7QUFDMUMsVUFBSSxLQUFLLE1BQU8sTUFBSyxRQUFRLEVBQUUsR0FBRyxLQUFLLE1BQU07QUFDN0MsVUFBSSxLQUFLLE1BQU8sTUFBSyxRQUFRLEVBQUUsR0FBRyxLQUFLLE1BQU07QUFDN0MsVUFBSSxLQUFLLFVBQVcsTUFBSyxZQUFZLEVBQUUsR0FBRyxLQUFLLFVBQVU7QUFDekQsVUFBSSxLQUFLLFNBQVUsTUFBSyxXQUFXLEtBQUssU0FBUyxJQUFJLGNBQVksRUFBRSxHQUFHLFNBQVMsU0FBUyxDQUFDLEdBQUcsUUFBUSxPQUFPLEVBQUUsRUFBRTtBQUMvRyxVQUFJLEtBQUssU0FBUztBQUNoQixhQUFLLFVBQVUsRUFBRSxHQUFHLEtBQUssUUFBUTtBQUNqQyxZQUFJLEtBQUssUUFBUSxLQUFNLE1BQUssUUFBUSxPQUFPLEVBQUUsR0FBRyxLQUFLLFFBQVEsS0FBSztBQUNsRSxZQUFJLEtBQUssUUFBUSxRQUFTLE1BQUssUUFBUSxVQUFVLEVBQUUsR0FBRyxLQUFLLFFBQVEsUUFBUTtBQUMzRSxZQUFJLEtBQUssUUFBUSxRQUFTLE1BQUssUUFBUSxVQUFVLEVBQUUsR0FBRyxLQUFLLFFBQVEsUUFBUTtBQUMzRSxZQUFHLEtBQUssUUFBUSxRQUFRLE1BQUssUUFBUSxVQUFRLEVBQUMsR0FBRyxLQUFLLFFBQVEsU0FBUSxjQUFhLEVBQUMsR0FBRyxLQUFLLFFBQVEsUUFBUSxhQUFZLEdBQUUsY0FBYSxFQUFDLEdBQUcsS0FBSyxRQUFRLFFBQVEsYUFBWSxFQUFDO0FBQzdLLFlBQUksS0FBSyxRQUFRLE1BQU8sTUFBSyxRQUFRLFFBQVEsRUFBRSxHQUFHLEtBQUssUUFBUSxPQUFPLEtBQUssRUFBRSxHQUFHLEtBQUssUUFBUSxNQUFNLElBQUksR0FBRyxRQUFRLEtBQUssUUFBUSxNQUFNLE9BQU8sSUFBSSxZQUFVLEVBQUUsR0FBRyxPQUFNLEdBQUksTUFBTSxRQUFNLEVBQUMsT0FBTSxFQUFDLEdBQUcsTUFBTSxNQUFLLEVBQUMsSUFBRSxDQUFDLEVBQUcsRUFBRSxFQUFFO0FBQUEsTUFDeE47QUFDQSxVQUFHLEtBQUssUUFBUSxNQUFLLFVBQVEsRUFBQyxHQUFHLEtBQUssUUFBTztBQUM3QyxVQUFJLEtBQUssaUJBQWtCLE1BQUssbUJBQW1CLEVBQUUsR0FBRyxLQUFLLGlCQUFpQjtBQUM5RSxVQUFJLEtBQUssU0FBVSxNQUFLLFdBQVcsRUFBRSxHQUFHLEtBQUssU0FBUztBQUN0RCxVQUFJLEtBQUssb0JBQXFCLE1BQUssc0JBQXNCLENBQUMsR0FBRyxLQUFLLG1CQUFtQjtBQUNyRixXQUFLLFVBQVUsS0FBSyxRQUFRLElBQUksYUFBVyxFQUFFLEdBQUcsUUFBUSxHQUFJLE9BQU8sZUFBZTtBQUFBLFFBQ2hGLGNBQWMsT0FBTyxZQUFZLE9BQU8sUUFBUSxPQUFPLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLEtBQUssTUFBTSxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQyxDQUFDO0FBQUEsTUFDOUksSUFBSSxDQUFDLEVBQUcsRUFBRTtBQUNWLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxJQUNELFdBQVcsS0FBSyxVQUFVLElBQUksQ0FBQyxhQUFhO0FBQzFDLFlBQU0sRUFBRSxhQUFhLEdBQUcsS0FBSyxJQUFJO0FBQ2pDLFlBQU0sT0FBaUI7QUFDdkIsVUFBSSxZQUFhLE1BQUssY0FBYyxFQUFFLEdBQUcsWUFBWTtBQUNyRCxXQUFLLFFBQVEsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLEVBQUU7QUFDckQsV0FBSyxnQkFBZ0IsU0FBUyxjQUFjLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLEVBQUU7QUFDckUsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLElBQ0QsV0FBVyxLQUFLLFVBQVUsSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLFNBQVMsRUFBRTtBQUFBLElBQzdELGdCQUFnQixLQUFLLGVBQWUsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLEtBQUssRUFBRTtBQUFBLElBQy9ELEdBQUksS0FBSyxRQUFRLEVBQUUsT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLEtBQUssRUFBRSxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUM7QUFBQSxJQUN2SCxPQUFPLEtBQUssTUFBTSxJQUFJLFdBQVMsRUFBQyxHQUFHLE1BQUssR0FBSSxLQUFLLE1BQUksRUFBQyxLQUFJLEVBQUMsR0FBRyxLQUFLLElBQUcsRUFBQyxJQUFFLENBQUMsR0FBRyxHQUFJLEtBQUssT0FBSyxFQUFDLE1BQUssRUFBQyxHQUFHLEtBQUssS0FBSSxFQUFDLElBQUUsQ0FBQyxFQUFFLEVBQUU7QUFBQSxJQUN0SCxhQUFhLEtBQUssWUFBWSxJQUFJLGlCQUFlO0FBQUEsTUFBRSxHQUFHO0FBQUEsTUFDcEQsR0FBSSxXQUFXLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxHQUFHLFdBQVcsY0FBYyxFQUFFLElBQUksQ0FBQztBQUFBLE1BQ3JGLEdBQUksV0FBVyxTQUFTLEVBQUUsUUFBUSxFQUFFLEdBQUcsV0FBVyxRQUFRLEdBQUksV0FBVyxPQUFPLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxHQUFHLFdBQVcsT0FBTyxjQUFjLEVBQUUsSUFBSSxDQUFDLEVBQUcsRUFBRSxJQUFJLENBQUM7QUFBQSxJQUN6SyxFQUFFO0FBQUEsSUFDRixTQUFTLEtBQUssUUFBUSxJQUFJLGFBQVcsRUFBRSxHQUFHLFFBQVEsR0FBSSxPQUFPLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxHQUFHLE9BQU8sY0FBYyxFQUFFLElBQUksQ0FBQyxFQUFHLEVBQUU7QUFBQSxJQUNwSSxHQUFJLEtBQUssVUFBVSxFQUFFLFNBQVMsS0FBSyxRQUFRLElBQUksYUFBVyxFQUFFLEdBQUcsUUFBUSxHQUFJLE9BQU8sT0FBSyxFQUFDLE1BQUssRUFBQyxHQUFHLE9BQU8sS0FBSSxFQUFDLElBQUUsQ0FBQyxFQUFHLEVBQUUsRUFBRSxJQUFJLENBQUM7QUFBQTtBQUFBLElBRTVILEdBQUksS0FBSyxXQUFXLEVBQUUsVUFBVSxFQUFFLEdBQUcsS0FBSyxTQUFTLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUQsR0FBSSxLQUFLLFlBQVksRUFBRSxXQUFXLEtBQUssVUFBVSxJQUFJLENBQUMsY0FBYyxFQUFFLEdBQUcsVUFBVSxPQUFPLEVBQUUsR0FBRyxTQUFTLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDO0FBQUEsRUFDM0g7QUFDQSx1QkFBcUIsU0FBUyxPQUFNLFFBQVE7QUFDNUMsc0JBQW9CLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDMUMsU0FBTztBQUNUO0FBRU8sZ0JBQVMsd0JBQXdCLE1BQVksVUFBd0IsUUFBc0I7QUFDaEcsT0FBSyxtQkFBbUI7QUFDeEIsT0FBSyxZQUFZO0FBQ2pCLE9BQUssT0FBTyxTQUFTO0FBQ3JCLE9BQUssUUFBUSxtQkFBbUIsU0FBUyxLQUFLO0FBQzlDLE9BQUssTUFBTSxtQkFBbUIsU0FBUyxHQUFHO0FBQzFDLE9BQUssUUFBUSxTQUFTLFFBQVEsYUFBYSxTQUFTLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxNQUFNO0FBQzdFLE9BQUssVUFBVSxtQkFBbUIsU0FBUyxPQUFPO0FBQ2xELFFBQU0sU0FBTyxtQkFBbUIsT0FBTyxLQUFLLEtBQUssT0FBTyxHQUFFLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTSxNQUFNLE1BQUksQ0FBQyxPQUFNLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN0SixhQUFVLENBQUMsT0FBTSxNQUFNLEtBQUssT0FBTyxRQUFRLEtBQUssT0FBTyxFQUFFLFFBQU8sUUFBTSxPQUFPLEtBQUs7QUFDbEYsTUFBSSxTQUFTLE1BQU8sTUFBSyxnQkFBZ0IsT0FBTyxLQUFLLFNBQVMsS0FBSyxFQUFFLE9BQU8sV0FBUyxTQUFTLFFBQVEsS0FBSyxNQUFNLE1BQVM7QUFDMUgsT0FBSyxRQUFRLG1CQUFtQixTQUFTLEtBQUssRUFBRSxJQUFJLGFBQWE7QUFDakUsT0FBSyxZQUFZLG1CQUFtQixTQUFTLFNBQVM7QUFDdEQsT0FBSyxZQUFZLG1CQUFtQixTQUFTLFNBQVM7QUFDdEQsT0FBSyxpQkFBaUIsbUJBQW1CLFNBQVMsY0FBYztBQUNoRSxNQUFJLFNBQVMsTUFBTyxNQUFLLFFBQVEsbUJBQW1CLFNBQVMsS0FBSztBQUFBLE1BQzdELFFBQU8sS0FBSztBQUNqQixPQUFLLFFBQVEsbUJBQW1CLFNBQVMsS0FBSztBQUM5QyxPQUFLLGNBQWMsbUJBQW1CLFNBQVMsV0FBVztBQUMxRCxPQUFLLFVBQVUsbUJBQW1CLFNBQVMsT0FBTztBQUNsRCxNQUFJLFNBQVMsUUFBUyxNQUFLLFVBQVUsbUJBQW1CLFNBQVMsT0FBTztBQUFBLE1BQ25FLFFBQU8sS0FBSztBQUNqQixNQUFJLFNBQVMsU0FBVSxNQUFLLFdBQVcsbUJBQW1CLFNBQVMsUUFBUTtBQUFBLE1BQ3RFLFFBQU8sS0FBSztBQUNqQixNQUFJLFNBQVMsVUFBVyxNQUFLLFlBQVksbUJBQW1CLFNBQVMsU0FBUztBQUFBLE1BQ3pFLFFBQU8sS0FBSztBQUNqQixNQUFJLENBQUMsU0FBUyxVQUFXLHNCQUFxQixJQUFJO0FBQ2xELGFBQVUsWUFBWSxLQUFLLFVBQVUsWUFBVSxPQUFPLFNBQVMsTUFBTSxLQUFHLElBQUksYUFBVyxPQUFVLEtBQUksV0FBUyxXQUFXLElBQUksUUFBUSxJQUFJLHlCQUF5QixJQUFJLFFBQWlELElBQUksVUFBVSxJQUFJLFFBQVEsRUFBRTtBQUNuUCxtQkFBaUIsS0FBSyxLQUFLO0FBQzNCLG9CQUFrQixLQUFLLEtBQUs7QUFDNUIsYUFBVyxRQUFRLFFBQVEsS0FBSyxLQUFLLEVBQUcsS0FBSSxLQUFLLFVBQVcsTUFBSyxVQUFVLFVBQVUsWUFBWSxJQUFJLEVBQUU7QUFHdkcsUUFBTSxlQUFlLEtBQUssTUFBTSxLQUFLLFVBQVMsS0FBSyxTQUFvQixlQUFnQixLQUFLLFNBQW9CLE1BQU07QUFDdEgsTUFBSSxjQUFjO0FBQ2hCLGVBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsVUFBSyxLQUFLLFNBQW9CLGFBQWE7QUFBRSxhQUFLLE9BQU87QUFBZ0IsZUFBTyxLQUFLO0FBQUEsTUFBTSxXQUNqRixLQUFLLFNBQW9CLE9BQVEsUUFBTyxLQUFLO0FBQUEsSUFDekQ7QUFDQSx1QkFBbUIsSUFBSTtBQUN2Qix5QkFBcUIsSUFBSTtBQUFBLEVBQzNCO0FBQ0EsTUFBSSxLQUFLLE1BQU8sWUFBVyxRQUFRLEtBQUssTUFBTyxNQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sVUFBUyxLQUFLLFNBQW9CLFdBQVc7QUFDM0gsTUFBSSxTQUFTLHFCQUFxQixHQUFHO0FBQ25DLDRCQUF3QixJQUFJO0FBQzVCLHVCQUFtQixNQUFLLElBQUk7QUFDNUIseUJBQXFCLElBQUk7QUFBQSxFQUMzQjtBQUNBLE9BQUssU0FBUztBQUNkLHFCQUFtQixJQUFJO0FBQ3ZCLG1CQUFpQixLQUFLLEtBQUksS0FBSyxLQUFLO0FBQ3BDLFlBQVUsS0FBSyxLQUFLO0FBQ3BCLDhCQUE0QixJQUFJO0FBQ2hDLHNCQUFvQixJQUFJO0FBQ3hCLHVCQUFxQixLQUFLLE9BQU0sSUFBSTtBQUN0QztBQUdBLFNBQVMscUJBQXFCLE1BQWtCO0FBQzlDLFFBQU0sVUFBVSxDQUFDLFNBQWU7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxLQUFLLFVBQVUsT0FBVyxNQUFLLFNBQVM7QUFDNUMsUUFBSSxLQUFLLFVBQVUsT0FBVyxNQUFLLFNBQVM7QUFDNUMsU0FBSyxPQUFPLFFBQVEsT0FBTztBQUFBLEVBQzdCO0FBQ0EsT0FBSyxNQUFNLFFBQVEsT0FBTztBQUMxQixhQUFXLFNBQVMsT0FBTyxPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsR0FBRztBQUN0RCxVQUFNLFNBQVM7QUFDZixRQUFJLE1BQU0sYUFBYSxPQUFXLE9BQU0sWUFBWTtBQUFBLEVBQ3REO0FBQ0Y7QUFFQSxTQUFTLDRCQUE0QixNQUFrQjtBQUNyRCw0QkFBMEIsSUFBSTtBQUM5QixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDWixTQUFPLEtBQUs7QUFDZDtBQUVBLFNBQVMsbUJBQXNCLE9BQWE7QUFDMUMsU0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLEtBQUssQ0FBQztBQUN6QztBQUVBLFNBQVMsYUFBYSxPQUFvRTtBQUN4RixTQUFPLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxFQUFFLE9BQU8sQ0FBQyxVQUF1QyxPQUFPLE1BQU0sQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUM5SDtBQUVBLFNBQVMsbUJBQW1CLE1BQVk7QUFDdEMsYUFBVyxZQUFZLEtBQUssV0FBVztBQUNyQyxRQUFJLFNBQVMsU0FBVTtBQUt2QixVQUFNLFdBQVcsb0JBQW9CLE1BQU0sUUFBUTtBQUNuRCxRQUFJLFNBQVMsV0FBVyxFQUFHO0FBQzNCLGVBQVcsV0FBVyxTQUFVLGdCQUFlLE1BQU0sU0FBUyxRQUFRO0FBR3RFLFVBQU0sU0FBUyxTQUFTO0FBQ3hCLGFBQVMsZ0JBQWdCLEtBQUssSUFBSSxTQUFTLFdBQVcsU0FBUyxnQkFBZ0IsU0FBUyxNQUFNO0FBQzlGLFVBQU0sVUFBVyxTQUFTLGdCQUFnQixVQUFVLEtBQUssSUFBSSxHQUFHLFNBQVMsU0FBUyxLQUFNLFNBQVMsUUFBUSxvQkFBb0IsU0FBUyxLQUFLO0FBQzNJLGFBQVMsS0FBSyxLQUFLLElBQUksU0FBUyxPQUFPLFNBQVMsS0FBSyxNQUFNO0FBQzNELFFBQUksU0FBUyxpQkFBaUIsU0FBUyxXQUFXO0FBQ2hELGdDQUEwQixNQUFNLFFBQVE7QUFDeEMsZUFBUyxXQUFXO0FBQ3BCLGlCQUFXLFdBQVcsU0FBVSxTQUFRLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDL0Qsd0JBQWtCLElBQUk7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxNQUFZO0FBQ2xDLGFBQVcsWUFBWSxLQUFLLFdBQVc7QUFDckMsUUFBSSxDQUFDLFNBQVMsWUFBWSxTQUFTLE1BQU0sV0FBVyxFQUFHO0FBQ3ZELFVBQU0sTUFBTSxTQUFTLE1BQU0sQ0FBQztBQUM1QixRQUFJLENBQUMsSUFBSztBQUNWLFFBQUksWUFBWSxLQUFLLElBQUksR0FBRSxJQUFJLFlBQVUsQ0FBQztBQUMxQyxRQUFJLElBQUksWUFBWSxFQUFHO0FBQ3ZCLFVBQU0sTUFBSSxVQUFVLElBQUksUUFBUSxNQUFJO0FBQ3BDLFVBQU0sU0FBTyxNQUFNLGVBQWUsTUFBSyxVQUFTLG9CQUFvQixVQUFTLElBQUksUUFBUSxDQUFDLElBQUk7QUFDOUYsVUFBTSxPQUFLLE1BQU0sU0FBUyxlQUFlLE1BQUssVUFBUyxtQkFBbUIsVUFBUyxJQUFJLFFBQVEsQ0FBQztBQUdoRyxRQUFHLENBQUMsS0FBSztBQUNULFVBQU0sT0FBTyxLQUFLLFVBQVUsU0FBUyxPQUFPLElBQUksVUFBVSxLQUFLLEdBQUcsS0FBSyxHQUFFLE1BQU07QUFDL0UsYUFBUyxNQUFNLE1BQU07QUFDckIsU0FBSyxRQUFRLGtCQUFrQixNQUFNLFVBQVUsSUFBSTtBQUFBLEVBQ3JEO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsTUFBWTtBQUNsQyxhQUFXLFlBQVksS0FBSyxXQUFXO0FBQ3JDLFFBQUksQ0FBQyxTQUFTLFlBQVksU0FBUyxjQUFjLFdBQVcsRUFBRztBQUMvRCxVQUFNLE1BQU0sU0FBUyxjQUFjLENBQUM7QUFDcEMsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLGFBQWE7QUFDakIsUUFBSSxJQUFJLFlBQVksRUFBRztBQUN2QixhQUFTLGNBQWMsTUFBTTtBQUM3QixxQkFBaUIsTUFBTSxTQUFTLE9BQU8sSUFBSSxhQUFhLElBQUksV0FBVztBQUFBLEVBQ3pFO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixNQUFZO0FBQ3RDLGFBQVcsWUFBWSxLQUFLLFdBQVc7QUFDckMsUUFBSSxDQUFDLFNBQVMsWUFBWSxTQUFTLGdCQUFnQixFQUFHO0FBQ3RELGFBQVMsV0FBVyxLQUFLLElBQUksR0FBRyxTQUFTLFdBQVcsQ0FBQztBQUNyRCxRQUFJLFNBQVMsV0FBVyxFQUFHO0FBQzNCLFVBQU0sU0FBUyw0QkFBNEIsTUFBTSxTQUFTLE9BQU8sVUFBVSxTQUFTLFdBQVc7QUFDL0YsUUFBSSxDQUFDLE9BQVE7QUFDYixzQkFBa0IsTUFBTSxVQUFVLFFBQVEsU0FBUyxjQUFjLFNBQVMsV0FBVztBQUNyRixhQUFTLFdBQVcsU0FBUztBQUFBLEVBQy9CO0FBQ0Y7QUFFQSxTQUFTLHNCQUFzQixNQUFZO0FBQ3pDLGFBQVcsWUFBWSxLQUFLLFdBQVc7QUFDckMsUUFBSSxDQUFDLFNBQVMsWUFBWSxDQUFDLHNCQUFzQixTQUFTLElBQUksRUFBRztBQUNqRSxhQUFTLFdBQVcsS0FBSyxJQUFJLEdBQUcsU0FBUyxXQUFXLENBQUM7QUFDckQsUUFBSSxTQUFTLFdBQVcsRUFBRztBQUMzQixVQUFNLFNBQVMsdUJBQXVCLE1BQU0sUUFBUTtBQUNwRCxRQUFJLENBQUMsT0FBUTtBQUNiLFdBQU8sS0FBSyxLQUFLLElBQUksT0FBTyxPQUFPLE9BQU8sS0FBSyxxQkFBcUI7QUFDcEUsYUFBUyxXQUFXLFNBQVM7QUFDN0IsY0FBVSxNQUFNLFFBQVEsT0FBTyxHQUFHLE9BQU8sR0FBRyxnQ0FBZ0MsRUFBRSxPQUFPLFNBQVMsR0FBRyxPQUFPLFNBQVMsR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sRUFBRSxDQUFDO0FBQUEsRUFDcEo7QUFDRjtBQUVBLFNBQVMsdUJBQXVCLE1BQVksVUFBb0I7QUFDOUQsTUFBSTtBQUNKLE1BQUksY0FBYztBQUNsQixvQkFBa0IsTUFBTSxVQUFVLFNBQVMsYUFBYSxDQUFDLFNBQVM7QUFDaEUsUUFBSSxDQUFDLGtCQUFrQixNQUFNLElBQUksS0FBSyxLQUFLLFVBQVUsU0FBUyxTQUFTLEtBQUssU0FBUyxZQUFZLEtBQUssTUFBTSxLQUFLLFNBQVMsU0FBUyxNQUFNLFFBQVEsSUFBSSxTQUFTLFlBQWE7QUFDM0ssVUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSztBQUNyRixRQUFJLFNBQVMsWUFBYTtBQUMxQixhQUFTO0FBQ1Qsa0JBQWM7QUFBQSxFQUNoQixDQUFDO0FBQ0QsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsTUFBWTtBQUNyQyxNQUFJLEtBQUssT0FBTyxRQUFRLENBQUMsRUFBRztBQUM1QixhQUFXLFFBQVEsS0FBSyxPQUFPO0FBQzdCLFFBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxDQUFDLGdCQUFnQixNQUFLLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLFNBQU8sWUFBWSxLQUFLLE1BQU0sU0FBTyxhQUFjO0FBQ2xKLFVBQU0sT0FBSyxLQUFLLFVBQVUsS0FBSyxjQUFVLFNBQVMsVUFBUSxLQUFLLFNBQVMsU0FBUyxTQUFPLGNBQWMsU0FBUyxZQUFZLFNBQVMsTUFBSyxRQUFRLElBQUUsWUFBWSxLQUFLO0FBQ3BLLFFBQUksQ0FBQyxRQUFRLFlBQVksTUFBSyxLQUFLLEtBQUssRUFBRSxPQUFLLFlBQVksY0FBYztBQUN6RSxjQUFVLE1BQUssS0FBSyxPQUFNLFlBQVksYUFBYTtBQUFFLG9CQUFnQixNQUFLLE1BQUssWUFBWSxXQUFXO0FBQUEsRUFDeEc7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLE1BQVk7QUFDdEMsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU87QUFDM0MsVUFBTSxpQkFBaUIsbUJBQW1CLE1BQU0sSUFBSTtBQUNwRCxRQUFJLGtCQUFrQixFQUFHO0FBQ3pCLFNBQUssS0FBSyxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxpQkFBaUIsRUFBRTtBQUFBLEVBQzlEO0FBQ0Y7QUFHTyxnQkFBUyxtQkFBbUIsTUFBb0IsTUFBWTtBQUNqRSxRQUFNLFdBQVcsWUFBWSxPQUFRLEtBQWMsZUFBZSxrQkFBa0IsSUFBSTtBQUN4RixRQUFNLFFBQVEsVUFBVSxNQUFNLElBQUk7QUFDbEMsUUFBTSxpQkFBdUMsdUJBQXVCO0FBQ3BFLFNBQVEsQ0FBQyxrQkFBa0IsZUFBZSxTQUFTLE1BQU0sYUFBYSxVQUFVLEtBQUssSUFBSSxFQUFFLFNBQVMsS0FDL0YsTUFBTSxrQkFBa0IsS0FBSyxrQ0FBa0MsTUFBTSxJQUFJLEtBQUssVUFBVSxJQUFJLEtBQUssRUFBRSxHQUFHLGtCQUFrQixLQUFLO0FBQ3BJO0FBRUEsU0FBUyxjQUFjLE1BQVk7QUFDakMsU0FBTyxDQUFDLEdBQVcsR0FBVyxXQUFtQjtBQUMvQyxVQUFNLFFBQWdCLENBQUM7QUFDdkIsc0JBQWtCLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxRQUFRLFVBQVEsTUFBTSxLQUFLLElBQUksQ0FBQztBQUNsRSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxxQ0FBcUMsTUFBWTtBQUV4RCxPQUFLLGNBQWMsbUJBQW1CLEtBQUssT0FBTyxHQUFHO0FBQ3JELHNCQUFvQixJQUFJO0FBQzFCO0FBQ0EsU0FBUyxvQkFBb0IsTUFBWSxRQUFRLE9BQU87QUFDdEQsUUFBTSxXQUFXLEtBQUs7QUFDdEIsT0FBSyxlQUFlLFFBQVEsU0FBWSxrQkFBa0IsTUFBTSxjQUFjLElBQUksQ0FBQztBQUVuRixNQUFJLENBQUMsVUFBVSxRQUFRLENBQUMsS0FBSyxjQUFjLEtBQU07QUFDakQsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFJLEtBQUssS0FBSyxNQUFNLFVBQVUsSUFBSSxLQUFLLEVBQUUsS0FBSyxLQUFLLGNBQWMsSUFBSSxLQUFLLEVBQUUsSUFBSTtBQUM5RSxZQUFNLEtBQUssS0FBSztBQUNoQiw0QkFBc0IsTUFBTSxJQUFJO0FBRWhDLFdBQUssS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUs7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLE1BQVksTUFBWTtBQUMvQyxTQUFPLEtBQUssY0FBYyxJQUFJLEtBQUssRUFBRSxHQUFHLHNCQUFzQjtBQUNoRTtBQUNBLFNBQVMsb0JBQW9CLE1BQVksUUFBYyxTQUErRSxXQUFvQjtBQUN4SixTQUFPO0FBQUEsSUFBbUI7QUFBQSxJQUFNO0FBQUEsSUFBUSxRQUFRO0FBQUEsSUFBTztBQUFBLElBQ3JELENBQUMsTUFBTSxHQUFHLEdBQUcsVUFBVSxZQUFZLFVBQVUsTUFBTSxNQUFNLEdBQUcsR0FBRyxVQUFVLEVBQUMsR0FBRyxTQUFRLFVBQVMsT0FBTyxJQUFHLFlBQVcsUUFBTyxPQUFNLE9BQU8sR0FBRSxPQUFNLE9BQU8sR0FBRSxLQUFJLEdBQUUsS0FBSSxFQUFDLENBQUM7QUFBQSxJQUFHLGNBQWMsSUFBSTtBQUFBLElBQUcsS0FBSztBQUFBLEVBQW9CO0FBQ3pOO0FBRUEsU0FBUztBQUVGLGdCQUFTLHlCQUF5QixNQUFvQixNQUFZO0FBQ3ZFLFNBQU8sa0JBQWtCLE1BQU0sSUFBSSxJQUFJLGtDQUFrQyxNQUFNLElBQUksSUFBSTtBQUN6RjtBQUlBLFNBQVMsa0NBQWtDLE1BQW9CLE1BQVk7QUFDekUsTUFBSSxDQUFDLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxTQUFTLEVBQUcsUUFBTztBQUN2RCxRQUFNLFVBQVUsYUFBYTtBQUM3QixRQUFNLGFBQWEsS0FBSyxRQUFRLEtBQUssS0FBSztBQUMxQyxNQUFJLENBQUMsV0FBWSxPQUFNLElBQUksTUFBTSw0QkFBNEIsS0FBSyxLQUFLLEVBQUU7QUFDekUsUUFBTSxRQUFRLFdBQVcsU0FBUyxjQUFjO0FBQ2hELFFBQU0sV0FBVyxRQUFRLE9BQU8sUUFBUSxDQUFDO0FBQ3pDLFNBQU8sVUFBVSxzQkFBc0IsS0FBSyxJQUFJLG1CQUFtQixLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUs7QUFDekY7QUFFQSxTQUFTLHFCQUFxQixNQUFZO0FBQ3hDLGFBQVcsUUFBUSxLQUFLLGdCQUFnQjtBQUN0QyxTQUFLLG9CQUFvQixLQUFLLElBQUksR0FBRyxLQUFLLG9CQUFvQixDQUFDO0FBQUEsRUFDakU7QUFDRjtBQUdBLFNBQVMsaUJBQWlCLE1BQVUsTUFBVSxNQUFlLE9BQTBCLE9BQUssa0JBQWtCLE1BQUssSUFBSSxHQUFJO0FBQ3pILFFBQU0sTUFBSSxhQUFhLEtBQUssSUFBaUM7QUFDN0QsUUFBTSxRQUFNLFdBQVcsSUFBSSxFQUFFLEtBQUssQ0FBQUksV0FBT0EsT0FBTSxPQUFLLEtBQUssT0FBTztBQUdoRSxRQUFNLFFBQU0sRUFBQyxHQUFHLE1BQUssR0FBRSxLQUFLLE1BQU0sR0FBRSxHQUFFLEtBQUssTUFBTSxHQUFFLE1BQUssRUFBQyxRQUFPLEtBQUssSUFBRyxHQUFFLE1BQU0sR0FBRSxHQUFFLE1BQU0sRUFBQyxHQUFFLEtBQUksS0FBSyxJQUFHO0FBQ3pHLFFBQU0sRUFBQyxPQUFNLE9BQU0sR0FBRyxXQUFVLElBQUUsVUFBVSxNQUFLLElBQUk7QUFDckQsUUFBTSxRQUFNLE1BQU0sT0FBTSxFQUFDLEdBQUcsWUFBVyxjQUFhLElBQUksUUFBTyxhQUFZLElBQUksT0FBTSxVQUFTLElBQUksVUFBUyxRQUFPLElBQUksT0FBTSxHQUFFLE9BQU0sS0FBSyxNQUFLLGdCQUFnQixNQUFLLElBQUksQ0FBQztBQUN4SyxNQUFHLE1BQU0sSUFBSSxNQUFLLE1BQUksTUFBTTtBQUFBLE1BQVMsUUFBTyxLQUFLO0FBQ2pELE1BQUcsTUFBTSxXQUFTLE9BQVUsTUFBSyxTQUFPLE1BQU07QUFDOUMsU0FBTyxRQUFNLFFBQU07QUFDckI7QUFDQSxTQUFTLHFCQUFxQixNQUFVLE1BQVU7QUFDaEQsU0FBTyxRQUFRLEtBQUssS0FBSyxFQUFFLE9BQU8sV0FBTyxNQUFNLE9BQUssS0FBSyxNQUFNLE1BQU0sS0FBRyxLQUFLLENBQUMsZUFBZSxNQUFLLEtBQUssT0FBTSxNQUFNLEtBQUssQ0FBQztBQUMzSDtBQUNBLFNBQVMsaUJBQWlCLE1BQVUsVUFBb0Q7QUFDdEYsTUFBRyxDQUFDLFNBQVMsT0FBTyxRQUFPO0FBQzNCLFFBQU0sUUFBTSxvQkFBSSxJQUFpQjtBQUNqQyxTQUFNLENBQUMsTUFBSyxPQUFNLFlBQVU7QUFDMUIsUUFBSSxRQUFNLE1BQU0sSUFBSSxPQUFPO0FBQzNCLFFBQUcsQ0FBQyxPQUFNO0FBQUMsY0FBTSxFQUFDLEdBQUcsTUFBSyxTQUFRLEVBQUMsR0FBRyxLQUFLLFNBQVMsUUFBTyxFQUFDO0FBQUUsdUJBQWlCLE1BQUssS0FBSztBQUFFLFlBQU0sSUFBSSxTQUFRLEtBQUs7QUFBQSxJQUFFO0FBQ3BILFdBQU8scUJBQXFCLE9BQU0sTUFBSyxPQUFNLFFBQVE7QUFBQSxFQUN2RDtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsTUFBVSxRQUFzRCxVQUEwQjtBQUN0SCxRQUFNLFdBQVMsS0FBSztBQUNwQixhQUFVLFFBQVEsUUFBUSxLQUFLLEtBQUssR0FBRTtBQUNwQyxRQUFHLEtBQUssTUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsWUFBWSxJQUFJLEtBQUssaUJBQWlCLEtBQUssU0FBUyxLQUFLLE1BQU0sWUFBWTtBQUNySSxVQUFNLFFBQU0sS0FBSztBQUNqQixVQUFNLFdBQVMscUJBQXFCLE1BQUssSUFBSTtBQUM3QyxVQUFNLFVBQVEsaUJBQWlCLE1BQUssSUFBSSxHQUFFLFNBQU8sV0FBVyxJQUFJO0FBQ2hFLFVBQU0sbUJBQWlCLFFBQVEsT0FBTyxDQUFDLE9BQU0sU0FBTztBQUNsRCxXQUFJLEtBQUssY0FBYyxNQUFJLEVBQUUsUUFBTztBQUNwQyxZQUFNLFFBQU0sT0FBTyxLQUFLLENBQUFBLFdBQU9BLE9BQU0sT0FBSyxLQUFLLE9BQU87QUFDdEQsWUFBTSxNQUFJLGFBQWEsS0FBSyxJQUFpQztBQUM3RCxhQUFPLFFBQVEsS0FBSyxJQUFJLE9BQU0sbUJBQW1CLE1BQUssSUFBSSxLQUFLLElBQUUsS0FBSyxNQUFNLE1BQU0sR0FBRSxNQUFNLENBQUMsQ0FBQyxJQUFJO0FBQUEsSUFDbEcsR0FBRSxLQUFLLFdBQVc7QUFDbEIsVUFBTSxZQUFVLFVBQVUsTUFBSyxJQUFJLEVBQUU7QUFDckMsVUFBTSxXQUFTLE1BQU0sU0FBTyxZQUFZLE1BQU0sU0FBTyxpQkFBaUIsTUFBTSxXQUFXLGlCQUFpQixNQUFLLE1BQU0sUUFBUSxJQUFJO0FBQy9ILFVBQU0sV0FBUyxNQUFNLFNBQU8sWUFBWSxNQUFNLFdBQVM7QUFDdkQsVUFBTSxZQUFVLFNBQVMsSUFBSSxLQUFLLEVBQUUsR0FBRyxXQUFXLFlBQVksWUFBWSxXQUFXLE9BQU8sS0FBSyx1QkFBdUIsS0FBSyxPQUFNLEtBQUssT0FBTSxPQUFPLEtBQUssVUFBVTtBQUdwSyxRQUFJLGNBQVksTUFBTSxTQUFPLFFBQVEsUUFBUSxjQUFjLENBQUMsY0FBYSxRQUFPLE1BQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxJQUFJLG1CQUFtQixNQUFLLE1BQUssZ0JBQWdCLElBQUk7QUFDaEssUUFBRyxlQUFlLFdBQVcsZUFBZSxDQUFDLFdBQVcsV0FBVyxFQUFFLGVBQVksa0JBQWtCLE1BQUssTUFBSyxXQUFXO0FBQ3hILFVBQU0sYUFBYSxDQUFDLFFBQVEsUUFBUSxLQUFLLEVBQUUsU0FBUyxNQUFNLElBQUksTUFDeEQsTUFBTSxTQUFTLFlBQVksTUFBTSxTQUFTLGlCQUFpQixxQkFBcUIsSUFBSTtBQUMxRixRQUFHLENBQUMsU0FBUyxJQUFJLEtBQUssRUFBRSxLQUFLLGdCQUFnQixxQkFBcUIsSUFBSSxLQUFLLFVBQVUsTUFBSyxXQUFXLEtBQUcscUJBQXFCLFlBQVk7QUFDdkkscUJBQWUsTUFBSyxrQkFBa0IsTUFBSyxNQUFLLGFBQVksR0FBRSxpQkFBaUIsTUFBSyxRQUFRLENBQUMsR0FBRSxLQUFLLEtBQUksS0FBSyxPQUFNLEtBQUssSUFBSSxrQkFBa0IsT0FBTyxJQUFJLEtBQUssRUFBRSxFQUFHLFNBQVEsS0FBSyxRQUFTLE9BQU8sQ0FBQyxDQUFDO0FBQUEsSUFDcE07QUFDQSxlQUFVLFFBQVEsU0FBUTtBQUN4QixXQUFJLEtBQUssY0FBYyxNQUFJLEtBQUssS0FBSyxvQkFBa0IsS0FBSyxLQUFLLFlBQVUsU0FBUyxDQUFDLGFBQWEsS0FBSyxXQUFTLEVBQUU7QUFDbEgsWUFBTSxNQUFJLGFBQWEsS0FBSyxJQUFpQyxHQUFFLE9BQUssa0JBQWtCLE1BQUssSUFBSTtBQUMvRixZQUFNLFFBQU0sbUJBQW1CLE1BQUssSUFBSSxLQUFLO0FBQzdDLFlBQU0sV0FBUyxDQUFDLGNBQW1DO0FBQ2pELGNBQU1DLFNBQU0sbUJBQW1CLE1BQUssTUFBSyxNQUFLLFdBQVUsSUFBSSxHQUFFLE1BQUksU0FBUyxLQUFLLE9BQU1BLE1BQUs7QUFDM0YsZUFBTyxjQUFjLE1BQUssTUFBS0EsTUFBSyxLQUFLLE9BQUssU0FBUyxRQUFNLElBQUksT0FBTyxZQUFVLE9BQzVFLENBQUMsU0FBUyxVQUFVLHFCQUFxQixNQUFLLE1BQUtBLFFBQU0sUUFBUTtBQUFBLE1BQ3pFO0FBQ0EsWUFBTSxZQUFVLGFBQWEsQ0FBQyxXQUFXLFNBQVMsSUFBSSxrQkFBa0IsTUFBSyxNQUFLLFNBQVMsSUFBSTtBQUcvRixZQUFNLFNBQU8sYUFBYSxlQUFlLE1BQUssS0FBSyxPQUFNLFVBQVUsS0FBSyxLQUFLLFNBQVMsU0FBUyxJQUFJLFlBQy9GLDRCQUE0QixNQUFLLEtBQUssT0FBTSxLQUFLLE9BQU0sT0FBTSxNQUFLLGVBQVcsU0FBUyxTQUFTLE1BQU0sQ0FBQyxDQUFDLFFBQU8sVUFBUyxRQUFRLEVBQUUsU0FBUyxNQUFNLElBQUksS0FBSyxVQUFVLGVBQWEsRUFBRTtBQUN0TCxZQUFNLFlBQVUsTUFBTSxTQUFPLFNBQVMsQ0FBQyxTQUFTLFFBQVE7QUFDeEQsWUFBTSxRQUFNLFNBQVMsbUJBQW1CLE1BQUssTUFBSyxNQUFLLFFBQU8sSUFBSSxJQUFJLGFBQWEsWUFBWSxLQUFLLE9BQU0sU0FBUztBQUNuSCxVQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsTUFBSyxNQUFLLEtBQUssS0FBSyxTQUFTLEtBQUssT0FBTSxLQUFLLElBQUUsU0FBUyxJQUFJLE9BQU8sWUFBWSxTQUFTLEtBQUssT0FBTSxLQUFLLElBQUUsSUFBSSxPQUFPLFNBQVM7QUFDMUosWUFBTSxRQUFNLGlCQUFpQixNQUFLLE1BQUssTUFBSyxPQUFNLElBQUk7QUFDdEQsVUFBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPO0FBQ3JCLFlBQU0sYUFBVyxrQkFBa0IsTUFBSyxJQUFJO0FBQzVDLFVBQUcsU0FBUyxVQUFVLENBQUMsa0JBQWtCLFdBQVcsUUFBTyxPQUFNLElBQUksUUFBTyxRQUFRLEVBQUU7QUFDdEYsaUJBQVcsTUFBSyxNQUFLLFFBQU8sS0FBSyxNQUFNLElBQUksVUFBUSxpQkFBaUIsTUFBSyxJQUFJLEVBQUUsZUFBYSxLQUFLLElBQUksR0FBRSxZQUFZLE1BQUssSUFBSSxFQUFFLFlBQVksS0FBRyx5QkFBeUIsTUFBSyxJQUFJLENBQUMsR0FBRSxJQUFJLFFBQU8sT0FBTSxDQUFDLEdBQUUsT0FBTyxJQUFHLEVBQUMsTUFBSyxNQUFLLFlBQVcsVUFBUyxNQUFLLENBQUM7QUFDclAsa0JBQVksS0FBSztBQUFFLFdBQUssb0JBQWtCLGlCQUFpQixNQUFLLE1BQUssSUFBSSxRQUFRO0FBQUUsVUFBRyxLQUFLLFlBQVUsU0FBUyxDQUFDLFVBQVUsTUFBSyxXQUFTLEtBQUs7QUFBQSxJQUM5STtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMscUJBQXFCLE1BQVUsUUFBc0IsS0FBSyxPQUFNO0FBQUMsYUFBVSxRQUFRLE9BQU07QUFBQyxTQUFLLFdBQVMsYUFBYSxNQUFLLElBQUk7QUFBRSxRQUFHLFlBQVksSUFBSSxFQUFFLE1BQUssV0FBUyxhQUFhLE1BQUssSUFBSTtBQUFBLEVBQUU7QUFBQztBQUVyTSxTQUFTLFlBQVksTUFBWTtBQUUvQixNQUFJO0FBQ0osUUFBTSxZQUFZLEtBQUs7QUFDdkIsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFHLEtBQUssb0JBQWtCLEVBQUUsTUFBSyxvQkFBb0IsS0FBSyxJQUFJLEdBQUcsS0FBSyxvQkFBb0IsQ0FBQztBQUMzRixVQUFNLFNBQVMsS0FBSyxZQUFZLFVBQVUsSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUNoRSxVQUFNLFVBQVEsVUFBVSxPQUFPLE1BQU0sSUFBSSxTQUFTO0FBQ2xELFFBQUcsS0FBSyxRQUFPO0FBQUMsWUFBTSxPQUFLLFVBQVUsSUFBSSxLQUFLLE1BQU07QUFBRSxVQUFHLE1BQUs7QUFBQyxhQUFLLElBQUUsS0FBSztBQUFFLGFBQUssSUFBRSxLQUFLO0FBQUEsTUFBRTtBQUFDO0FBQUEsSUFBUztBQUNyRyxRQUFJLENBQUMsUUFBUztBQUNkLFNBQUssSUFBSSxRQUFRO0FBQ2pCLFNBQUssSUFBSSxRQUFRO0FBQ2pCLFFBQUksQ0FBQyxVQUFVLE9BQU8sS0FBSyxLQUFLLFNBQVMsZ0JBQWdCLGFBQWEsTUFBSyxTQUFRLElBQUksRUFBRyxpQkFBZ0IsTUFBTSxTQUFTLElBQUk7QUFDN0gsUUFBSSxrQkFBa0IsU0FBUyxJQUFJLEtBQUssS0FBSyxTQUFTLGVBQWUsYUFBYSxNQUFLLFNBQVEsSUFBSSxLQUFLLFFBQVEsS0FBSyxRQUFRLFNBQVMsQ0FBQyxRQUFRLElBQUksUUFBUSxFQUFFLEdBQUc7QUFDOUosY0FBUSxLQUFLLEtBQUssSUFBSSxRQUFRLE9BQU8sUUFBUSxLQUFLLFFBQVEscUJBQXFCLENBQUM7QUFDaEYsT0FBQyxXQUFXLG9CQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsRUFBRTtBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxDQUFDLFVBQVUsT0FBTyxLQUFLLFFBQVEsVUFBVSxhQUFhLGFBQWEsTUFBSyxTQUFRLElBQUksRUFBRyxxQkFBb0IsTUFBTSxTQUFTLElBQUk7QUFBQSxFQUNwSTtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsTUFBWTtBQUNuQyxhQUFXLFlBQVksS0FBSyxXQUFXO0FBQ3JDLGFBQVMsMkJBQTJCLEtBQUssSUFBSSxJQUFJLFNBQVMsNEJBQTRCLEtBQUssQ0FBQztBQUFBLEVBQzlGO0FBQ0Y7QUFNQSxTQUFTLFlBQVksTUFBWSxVQUE0QixZQUFxQixtQkFBK0M7QUFDL0gsT0FBSyx1QkFBdUIsb0JBQW9CLFNBQVksQ0FBQztBQUM3RCxRQUFNLGdCQUFnQixLQUFLLE9BQU8seUJBQXlCO0FBQzNELFFBQU0scUJBQXFCLDBCQUEwQixJQUFJO0FBQ3pELE1BQUk7QUFDSixRQUFNLFVBQVEsYUFBYSxRQUFRLEtBQUssS0FBSyxJQUFJO0FBQ2pELFFBQU0sVUFBUSxTQUFTLFNBQVMsQ0FBQyxHQUFHLFNBQVEsR0FBRyxLQUFLLE1BQU0sT0FBTyxVQUFNLENBQUMsV0FBVyxLQUFLLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSztBQUd2RyxRQUFNLFFBQVEsUUFBUTtBQUN0QixRQUFNLGNBQWMsS0FBSyxNQUFNO0FBQy9CLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLLEdBQUc7QUFDakMsVUFBTSxPQUFPLFFBQVEsQ0FBQztBQUN0QixVQUFNLGlCQUFpQixjQUFjLEtBQUssTUFBTSxXQUFXO0FBQzNELFFBQUksS0FBSyxTQUFTLFdBQVcsQ0FBQyxDQUFDLFVBQVUsY0FBYyxRQUFRLEVBQUUsU0FBUyxLQUFLLE1BQU0sSUFBSSxLQUFLLENBQUMsU0FBUyxJQUFJLEtBQUssRUFBRSxFQUFHLFFBQU8sS0FBSyxRQUFRO0FBQzFJLFFBQUcsS0FBSyxJQUFJLG9CQUFtQixNQUFNLFlBQVksTUFBTSxJQUFJLENBQUM7QUFDNUQsU0FBSyxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxDQUFDO0FBQzdDLFFBQUksS0FBSyxrQkFBa0I7QUFDekIsWUFBTSxPQUFPLHVCQUF1QixLQUFLLGdCQUFnQjtBQUN6RCxVQUFJLEtBQU0sTUFBSyxtQkFBbUI7QUFBQSxVQUM3QixNQUFLLG1CQUFtQjtBQUFBLElBQy9CO0FBQ0EsUUFBSSxrQkFBa0IsVUFBVSxJQUFJLE1BQzlCLGtCQUFrQix1QkFBdUIsdUJBQXVCLE1BQUssSUFBSSxFQUFHO0FBQ2xGLFFBQUksS0FBSyxNQUFNLFNBQVMsY0FBYztBQUNwQyxVQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssQ0FBQyxVQUFVLElBQUksRUFBRyxnQkFBZSxNQUFLLE1BQUssV0FBVyxJQUFJLEdBQUUsV0FBTyxZQUFZLEtBQUssS0FBRyxVQUFVLEtBQUssSUFBRSxJQUFFLFdBQVcsS0FBSyxDQUFDO0FBQ3JKO0FBQUEsSUFDRjtBQUdBLFFBQUksS0FBSyxNQUFNLFNBQVMsVUFBVTtBQUNoQyxVQUFLLEtBQUssVUFBVSxVQUFhLFlBQVksSUFBSSxLQUFPLEtBQUssUUFBUSxXQUFXLEtBQUssVUFBVSxJQUFJLEVBQUk7QUFJdkcsVUFBSSxLQUFLLFVBQVUsYUFBYSxLQUFLLE1BQU0sU0FBUyxRQUFRO0FBQzFELHlCQUFpQixNQUFNLE1BQU0sS0FBSyxPQUFPLGNBQWM7QUFDdkQ7QUFBQSxNQUNGO0FBQ0EsMEJBQW9CLE1BQUssSUFBSTtBQUM3QixVQUFJLG1CQUFtQixNQUFNLElBQUksRUFBRztBQUNwQyxVQUFJLGtCQUFrQixtQkFBbUIsTUFBTSxJQUFJLEVBQUc7QUFDdEQsVUFBSSxjQUFlLGNBQWEsTUFBTSxJQUFJO0FBQUEsSUFDNUM7QUFDQSxZQUFRLEtBQUssTUFBTSxNQUFNO0FBQUEsTUFDdkIsS0FBSztBQUNILDBCQUFrQixNQUFNLElBQUk7QUFDNUI7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUIsTUFBTSxNQUFNLEtBQUssT0FBTyxjQUFjO0FBQ3ZEO0FBQUEsTUFDRixLQUFLO0FBQ0gsOEJBQXNCLE1BQU0sTUFBTSxjQUFjO0FBQ2hEO0FBQUEsTUFDRixLQUFLO0FBQ0gsd0JBQWdCLE1BQU0sTUFBTSxjQUFjO0FBQzFDO0FBQUEsTUFDRixLQUFLO0FBQ0gsdUJBQWUsTUFBTSxNQUFNLGNBQWM7QUFDekM7QUFBQSxNQUNGLEtBQUs7QUFDSCwwQkFBa0IsTUFBTSxJQUFJO0FBQzVCO0FBQUEsTUFDRixLQUFLO0FBQ0gsd0JBQWdCLE1BQU0sSUFBSTtBQUMxQjtBQUFBLE1BQ0YsS0FBSztBQUNILDBCQUFrQixNQUFNLE1BQU0sY0FBYztBQUM1QztBQUFBLE1BQ0YsS0FBSztBQUNILHdCQUFnQixNQUFNLElBQUk7QUFDMUI7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUIsTUFBTSxJQUFJO0FBQzNCO0FBQUEsTUFDRixLQUFLO0FBQ0gsMEJBQWtCLE1BQU0sSUFBSTtBQUM1QjtBQUFBLE1BQ0YsS0FBSztBQUFBLE1BQWMsS0FBSztBQUN0Qiw4QkFBc0IsTUFBTSxJQUFJO0FBQ2hDO0FBQUEsTUFDRixLQUFLO0FBQ0gsOEJBQXNCLE1BQU0sSUFBSTtBQUNoQztBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQixNQUFNLElBQUk7QUFDM0IsU0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxTQUFTLEtBQUssSUFBSTtBQUM5RDtBQUFBLE1BQ0YsS0FBSztBQUNILDZCQUFxQixNQUFNLElBQUk7QUFDL0I7QUFBQSxNQUNGLEtBQUs7QUFDSCxtQkFBVyxNQUFNLEtBQUssTUFBTSxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssS0FBSyxLQUFLLE9BQU8sY0FBYztBQUNqRixTQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsR0FBRyxXQUFXLENBQUMsRUFBRSxHQUFHLFVBQVUsS0FBSyxJQUFJO0FBQy9EO0FBQUEsSUFDSjtBQUNBLFFBQUksS0FBSyxTQUFTLFlBQVksQ0FBQyxLQUFLLFFBQVEsaUJBQWlCLE1BQU0sSUFBSSxFQUFHO0FBQzFFLFFBQUcsa0JBQWtCLFdBQVcsSUFBSSxLQUFLLEtBQUssVUFBUSxXQUFXO0FBQy9ELFlBQU0sVUFBUSxTQUFTLElBQUksS0FBSyxFQUFFO0FBQ2xDLFVBQUcsU0FBUyxRQUFPO0FBQ2pCLGNBQU0sU0FBTyxrQkFBa0IsTUFBSyxNQUFLLFFBQVEsTUFBTTtBQUN2RCwyQkFBbUIsTUFBSyxNQUFLLE1BQU07QUFDbkMsWUFBRyxVQUFVLE1BQUssSUFBSSxFQUFFLG1CQUFtQixLQUFLLGFBQVcsS0FBSyxVQUFVLE1BQUssTUFBTSxLQUFHLEtBQUssZUFDeEYsTUFBTSxNQUFLLFlBQVksTUFBSyxJQUFJLEdBQUUsWUFBWSxNQUFLLE1BQU0sR0FBRSxLQUFLLE1BQUssZ0JBQWdCLE1BQUssSUFBSSxDQUFDLEdBQUU7QUFDcEcsNEJBQWtCLE1BQUssTUFBSyxRQUFPLEtBQUssSUFBSSxHQUFFLEtBQUssTUFBTSxLQUFLLGVBQWEseUJBQXlCLE1BQUssSUFBSSxDQUFDLENBQUMsR0FBRSxLQUFLLFdBQVc7QUFDakksc0JBQVksSUFBSTtBQUFFLGVBQUssV0FBUyxpQkFBaUIsTUFBSyxJQUFJO0FBQUEsUUFDNUQ7QUFBQSxNQUNGLFdBQ1EsU0FBUyxTQUFTLFlBQVcsTUFBSyxRQUFRLFNBQVMsR0FBRSxRQUFRLFNBQVMsR0FBRSxLQUFLLEtBQUksS0FBSyxLQUFLO0FBQUEsVUFDOUYsaUJBQWdCLE1BQUssSUFBSTtBQUM5QjtBQUFBLElBQ0Y7QUFDQSxRQUFHLGtCQUFrQixZQUFZLElBQUksRUFBRTtBQUN2QyxRQUFJLEtBQUssU0FBUyxVQUFVO0FBQzFCLFlBQU0sU0FBUyxtQkFBbUIsTUFBTSxNQUFNLEtBQUssVUFBVSxZQUFZLE1BQU0sb0JBQW9CLGNBQWM7QUFDakgsVUFBSSxPQUFRLE1BQUssUUFBUSxFQUFFLE1BQU0sVUFBVSxVQUFVLE9BQU8sSUFBSSxRQUFRLEtBQUssR0FBRyxRQUFRLEtBQUssRUFBRTtBQUFBLElBQ2pHO0FBQUEsRUFFRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFZLE1BQVksT0FBdUU7QUFHckgsTUFBSSxVQUFVLEtBQUssSUFBSSxNQUFNLE9BQVEsUUFBTztBQUM1QyxRQUFNLE9BQUssS0FBSyxNQUFNLEtBQUssQ0FBQUMsVUFBTSxZQUFZQSxLQUFJLEtBQUssZ0JBQWdCLGFBQWFBLE9BQUssS0FBSyxHQUFFLEdBQUUsWUFBWUEsS0FBSSxFQUFHLElBQUksQ0FBQztBQUV6SCxTQUFPLE9BQU8sRUFBQyxHQUFHLE9BQU0sV0FBVSxhQUFhLE1BQUssS0FBSyxHQUFFLFlBQVcsS0FBSyxHQUFFLElBQUk7QUFDbkY7QUFHQSxTQUFTLFNBQVMsTUFBWSxNQUF3QixNQUFnQyxPQUF3QjtBQUM1RyxRQUFNLFFBQU0sS0FBSztBQUNqQixNQUFJLE1BQU0sU0FBTyxVQUFVLE1BQU0sU0FBTyxnQkFBaUIsQ0FBQyxNQUFNLGFBQWEsTUFBTSxNQUFJLEtBQUssS0FBSyxNQUFNLE1BQUksS0FBSyxFQUFFLFFBQU87QUFDekgsUUFBTSxTQUFPLE1BQU0sS0FBSyxDQUFBTCxVQUFNQSxNQUFLLFFBQU0sTUFBTSxjQUFjLE1BQU0sR0FBRztBQUN0RSxTQUFPLFNBQVMsYUFBYSxRQUFPLE1BQU0sU0FBUyxJQUFJO0FBQ3pEO0FBRUEsU0FBUyxpQkFBaUIsTUFBWSxNQUFZLE9BQTZDLFlBQXFCO0FBQ2xILE1BQUksS0FBSyxXQUFXLHVCQUF1QixNQUFNLEtBQUssS0FBSyxLQUFLLE9BQU8sV0FBVyxJQUFJLENBQUMsRUFBRztBQUMxRixhQUFXLE1BQU0sTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLEtBQUssS0FBSyxPQUFPLFVBQVU7QUFDbkUsTUFBSSxVQUFVLE1BQU0sTUFBTSxPQUFPLHdCQUF3QixFQUFHLFFBQU8sTUFBTSxLQUFLO0FBQ2hGO0FBRUEsU0FBUyxvQkFBb0IsTUFBVztBQUN0QyxNQUFJLFVBQVE7QUFDWixhQUFVLFFBQVEsUUFBUSxLQUFLLEtBQUssR0FBRTtBQUNwQyxVQUFNLE9BQUssZUFBZSxLQUFLLE9BQU0sSUFBSSxFQUFFLE9BQU8sVUFBTSxLQUFLLEtBQUcsQ0FBQztBQUNqRSxRQUFHLENBQUMsS0FBSyxVQUFVLEtBQUssS0FBSyxVQUFNLENBQUMsZUFBZSxNQUFLLEtBQUssT0FBTSxLQUFLLEtBQUssQ0FBQyxFQUFFO0FBQ2hGLFVBQU0sWUFBVSxLQUFLLE9BQU8sVUFBTSxXQUFXLEtBQUssS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUUsTUFBSSxFQUFFLEtBQUcsRUFBRSxLQUFHLEtBQUcsRUFBRSxLQUFHLEVBQUUsS0FBRyxJQUFFLENBQUM7QUFDaEcsVUFBTSxRQUFNLFVBQVUsQ0FBQyxHQUFHO0FBQzFCLFFBQUcsQ0FBQyxTQUFTLFVBQVUsS0FBSyxVQUFNLGVBQWUsTUFBSyxPQUFNLEtBQUssS0FBSyxDQUFDLEVBQUU7QUFDekUsU0FBSyxRQUFNO0FBQU0sU0FBSyxRQUFNLEVBQUMsTUFBSyxPQUFNO0FBQUUsU0FBSyxhQUFXLENBQUM7QUFBRSxTQUFLLE1BQUk7QUFDdEUsUUFBRyxLQUFLLFNBQVE7QUFBQyxXQUFLLFFBQVEsUUFBTTtBQUFFLFdBQUssUUFBUSxRQUFNO0FBQVUsYUFBTyxLQUFLLFFBQVE7QUFBUSw0QkFBc0IsSUFBSTtBQUFBLElBQUU7QUFDM0gscUJBQWlCLE1BQUssSUFBSTtBQUFFLGNBQVE7QUFBQSxFQUN0QztBQUNBLE1BQUcsUUFBUSxtQkFBa0IsSUFBSTtBQUNuQztBQUVBLFNBQVMsZ0JBQWdCLE1BQVksT0FBa0IsU0FBUyxPQUFPO0FBRXJFLE1BQUksUUFBUTtBQUNWLFNBQUssYUFBYSxDQUFDLEdBQUksS0FBSyxjQUFjLENBQUMsR0FBSSxLQUFLO0FBQ3BEO0FBQUEsRUFDRjtBQUVBLE1BQUksS0FBSyxNQUFNLFNBQVMsVUFBVTtBQUNoQyxTQUFLLGFBQWEsQ0FBQyxLQUFLO0FBQ3hCO0FBQUEsRUFDRjtBQUNBLE9BQUssUUFBUTtBQUNiLE9BQUssYUFBYSxDQUFDO0FBQ25CLE1BQUcsS0FBSyxTQUFTLFFBQVEsb0JBQW1CLElBQUk7QUFDaEQsTUFBSSxLQUFLLFNBQVM7QUFBRSxTQUFLLFFBQVEsUUFBUTtBQUFXLFdBQU8sS0FBSyxRQUFRO0FBQ3RFLDBCQUFzQixJQUFJO0FBQzFCLFdBQU8sS0FBSyxRQUFRO0FBQXlCLFdBQU8sS0FBSyxRQUFRO0FBQUEsRUFBNkI7QUFDbEc7QUFFQSxTQUFTLG9CQUFvQixNQUFVLE1BQVk7QUFDakQsTUFBSSxLQUFLLE1BQU0sU0FBUyxPQUFRO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLFlBQVksTUFBTTtBQUNwQyxNQUFJLENBQUMsS0FBTTtBQUdYLE1BQUcsWUFBWSxJQUFJLEVBQUUsc0JBQXFCLEtBQUssT0FBTSxvQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztBQUN2RSxPQUFLLFFBQVE7QUFDYixNQUFHLEtBQUssU0FBUyxRQUFRLG9CQUFtQixJQUFJO0FBQ2hELE1BQUksS0FBSyxTQUFTO0FBQUUsU0FBSyxRQUFRLFFBQVE7QUFBVyxXQUFPLEtBQUssUUFBUTtBQUN0RSwwQkFBc0IsSUFBSTtBQUMxQixXQUFPLEtBQUssUUFBUTtBQUF5QixXQUFPLEtBQUssUUFBUTtBQUFBLEVBQTZCO0FBQ2xHO0FBRUEsU0FBUyxrQkFBa0IsTUFBWSxNQUFZO0FBQ2pELE1BQUksS0FBSyxNQUFNLFNBQVMsU0FBVTtBQUNsQyxRQUFNLFFBQVEsS0FBSztBQUNuQixRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFNLFlBQVksQ0FBQyxlQUFlLE1BQU0sVUFBVSxPQUFPLEtBQUssS0FBSyxDQUFDO0FBQ25JLE1BQUksQ0FBQyxRQUFRO0FBQ1gsU0FBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQzVCO0FBQUEsRUFDRjtBQUNBLE1BQUksWUFBWSxJQUFJLEdBQUc7QUFDckIsVUFBTSxPQUFPLGdCQUFnQixNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLFlBQVksSUFBSSxFQUFHLFNBQVMsTUFBSyxFQUFFLEdBQUcsR0FBRyxJQUFJO0FBQ2pILFVBQU0sT0FBTyxXQUFXLElBQUk7QUFDNUIsUUFBSSxRQUFRLE9BQU8sRUFBRyxZQUFXLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSyxPQUFPLElBQUk7QUFDdkU7QUFBQSxFQUNGO0FBQ0EsTUFBSSxTQUFTLE1BQU0sTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU8sU0FBUyxLQUFLLFNBQVMsRUFBRSxHQUFHO0FBQzNFLGVBQVcsTUFBTSxPQUFPLEdBQUcsT0FBTyxHQUFHLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFBQSxFQUMzRDtBQUNGO0FBRUEsU0FBUyxtQkFBbUIsTUFBWSxNQUFZO0FBQ2xELE1BQUksS0FBSyxVQUFVLGFBQWEsS0FBSyxVQUFVLFVBQWEsS0FBSyxVQUFVLE9BQVcsUUFBTztBQUM3RixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssTUFBTTtBQUM1QyxRQUFNLGlCQUFpQixzQkFBc0IsSUFBSSxLQUFLO0FBQ3RELFFBQU0sZUFBZSxTQUFTLE1BQU0sSUFBSTtBQUN4QyxNQUFJLGdCQUFnQiw2QkFBNkIsS0FBSyxNQUFNLFNBQVMsVUFBVSxTQUFTLEtBQUssT0FBTyxJQUFJLEtBQUssMkJBQTJCO0FBQ3RJLFNBQUssUUFBUSxFQUFFLE1BQU0sT0FBTztBQUM1QixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FBUyxLQUFLLE1BQU0sU0FBUyxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sUUFBUSxJQUFJO0FBQ3RGLFFBQU0sWUFBWSxLQUFLLE1BQU0sU0FBUyxVQUFVLFNBQVMsS0FBSyxPQUFPLElBQUksS0FBSztBQUM5RSxRQUFNLGFBQWEsQ0FBQyxXQUFXLEtBQUssTUFBTSxTQUFTLFVBQVUsS0FBSyxNQUFNLFNBQVM7QUFDakYsTUFBSSxnQkFBZ0IsdUJBQXVCLENBQUMsY0FBYyxDQUFDLGNBQWMsZ0JBQWdCLCtCQUNuRixDQUFDLFVBQVUsU0FBUyxRQUFRLGNBQWMsS0FBSywrQkFBZ0MsUUFBTztBQUc1RixPQUFLLFFBQVEsRUFBRSxNQUFNLFFBQVEsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUU7QUFDbEQsYUFBVyxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSztBQUNyRCxNQUFJLFNBQVMsTUFBTSxJQUFJLEtBQUssMEJBQTJCLE1BQUssUUFBUSxFQUFFLE1BQU0sT0FBTztBQUNuRixTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixNQUFZLE1BQVksYUFBYSxNQUFNO0FBQ2xFLE1BQUcsY0FBYyxZQUFZLElBQUksS0FBSyxDQUFDLFVBQVUsTUFBSyxJQUFJLEVBQUUsZ0JBQWdCO0FBQzVFLE1BQUksS0FBSyxXQUFXLEtBQUssS0FBSyxnQkFBZ0IsRUFBRztBQUNqRCxRQUFNLFNBQVMsbUJBQW1CLE1BQU0sTUFBTSxLQUFLLGFBQWEsVUFBVTtBQUMxRSxNQUFJLENBQUMsT0FBUTtBQUNiLE1BQUksQ0FBQyxNQUFNLE1BQU0sWUFBWSxNQUFNLElBQUksR0FBRyxZQUFZLE1BQUssTUFBTSxHQUFHLEtBQUssTUFBTSxnQkFBZ0IsTUFBTSxJQUFJLENBQUMsRUFBRztBQUM3RyxvQkFBa0IsTUFBTSxNQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLEtBQUssZUFBZSx5QkFBeUIsTUFBTSxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssV0FBVztBQUN6SSxjQUFZLElBQUk7QUFDaEIsT0FBSyxXQUFXLGlCQUFpQixNQUFNLElBQUk7QUFDN0M7QUFFQSxTQUFTLGVBQWUsTUFBWSxNQUFZLGFBQWEsTUFBTTtBQUNqRSxNQUFJLEtBQUssTUFBTSxTQUFTLE1BQU87QUFDL0IsUUFBTSxRQUFRLEtBQUs7QUFDbkIsTUFBSSxTQUFTLE1BQU0sS0FBSyxJQUFJLEtBQUssYUFBYTtBQUM1QyxTQUFLLE1BQU07QUFDWCxlQUFXLE1BQU0sTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLEtBQUssS0FBSyxPQUFPLFVBQVU7QUFDbkUsUUFBSSxTQUFTLE1BQU0sS0FBSyxJQUFJLEtBQUssZUFBZSxVQUFVLE1BQU0sTUFBTSxPQUFPLENBQUMsRUFBRyxNQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDN0c7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0IsTUFBTSxNQUFNLE9BQU8sVUFBVSxHQUFHO0FBQUUsU0FBSyxNQUFNO0FBQVc7QUFBQSxFQUFRO0FBQ3RGLE1BQUksbUJBQW1CLE1BQU0sTUFBTSxLQUFLLGFBQWEsVUFBVSxFQUFHLGlCQUFnQixNQUFNLE1BQU0sVUFBVTtBQUFBLE1BQ25HLE9BQU0sTUFBTSxZQUFZLE1BQU0sSUFBSSxHQUFHLE9BQU8sS0FBSyxNQUFNLGdCQUFnQixNQUFNLElBQUksQ0FBQztBQUN6RjtBQUVBLFNBQVMsc0JBQXNCLE1BQVksTUFBWSxhQUFhLE1BQU07QUFDeEUsTUFBSSxLQUFLLE1BQU0sU0FBUyxhQUFjO0FBQ3RDLFFBQU0sUUFBUSxLQUFLO0FBQ25CLE1BQUksTUFBTSxVQUFVO0FBQ2xCLFVBQU1NLFVBQVMsV0FBVyxNQUFNLE1BQU0sUUFBUTtBQUk5QyxRQUFJLENBQUMsY0FBY0EsV0FBVSxPQUFPQSxPQUFNLE1BQU1BLFFBQU8sUUFBUUEsUUFBTyxTQUFTLFdBQVdBLFFBQU8sSUFBSSxHQUFJLGNBQWE7QUFDdEgsUUFBSUEsV0FBVUEsUUFBTyxLQUFLLE1BQU0sQ0FBQyxjQUFjLHVCQUF1QixLQUFLLE9BQU0sS0FBSyxPQUFNQSxPQUFNLE1BQU0sbUNBQW1DLE1BQU0sS0FBSyxPQUFPQSxPQUFNLElBQUksS0FBSyxlQUFlLE1BQU0sS0FBSyxPQUFPQSxRQUFPLEtBQUssTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLElBQUksV0FBVyxTQUFTLEtBQUssS0FBSyxNQUFNQSxTQUFRLEtBQUssS0FBSyxJQUFJO0FBQ2hULFlBQU0sU0FBUyxzQkFBc0IsTUFBTSxNQUFNQSxTQUFRLFVBQVU7QUFDbkUsVUFBSSxPQUFPLE9BQU8sTUFBTSxTQUFVLE1BQUssUUFBUSxFQUFFLEdBQUcsT0FBTyxVQUFVLE9BQU8sR0FBRztBQUMvRSw2QkFBdUIsTUFBTSxNQUFNLFFBQVEsVUFBVTtBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLEVBQUUsVUFBVSxPQUFPLEdBQUcsWUFBWSxJQUFJO0FBQzVDLFNBQUssUUFBUTtBQUFBLEVBQ2Y7QUFFQSxRQUFNLFVBQVEsYUFBYSxZQUFZLElBQUksSUFBSTtBQUMvQyxRQUFNLGNBQVksVUFBVSxLQUFLLElBQUksS0FBSyxhQUFZLEtBQUssSUFBSSxLQUFJLEtBQUssSUFBSSxvQkFBbUIsS0FBSyxjQUFZLFFBQVEsU0FBTyxNQUFHLEdBQUcsQ0FBQyxDQUFDLElBQ25JLFVBQVUsTUFBSyxJQUFJLEVBQUUsU0FBUyxLQUFLLElBQUksb0JBQW1CLEtBQUssV0FBVyxJQUFJO0FBQ2xGLFFBQU0sU0FBUyxtQkFBbUIsTUFBTSxNQUFNLGFBQWEsVUFBVTtBQUNyRSxNQUFJLFFBQVE7QUFDVixTQUFLLFFBQVEsRUFBRSxHQUFHLE9BQU8sVUFBVSxPQUFPLEdBQUc7QUFDN0MsMkJBQXVCLE1BQU0sTUFBTSxRQUFRLFVBQVU7QUFDckQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFFBQVMsUUFBTyxLQUFLLFFBQVE7QUFDdEMsYUFBVyxNQUFNLE1BQU0sR0FBRyxNQUFNLEdBQUcsS0FBSyxLQUFLLEtBQUssT0FBTyxVQUFVO0FBQ25FLE1BQUksVUFBVSxNQUFNLE1BQU0sT0FBTyxDQUFDLEVBQUcsUUFBTyxNQUFNLEtBQUs7QUFDekQ7QUFFQSxTQUFTLHVCQUF1QixNQUFZLE1BQVksUUFBeUIsYUFBYSxNQUFNO0FBQ2xHLE1BQUksV0FBWSxVQUFTLGtCQUFrQixNQUFNLE1BQU0sTUFBTTtBQUM3RCxRQUFNLE1BQU0sVUFBVSxNQUFNLFFBQVEsVUFBVTtBQUM5QyxRQUFNLE9BQU8sY0FBYyxRQUFRLFlBQVksSUFBSSxDQUFDO0FBQ3BELE1BQUksS0FBTSxvQkFBbUIsTUFBTSxNQUFNLE1BQU07QUFBQSxXQUN0QyxrQkFBa0IsTUFBTSxNQUFNLFFBQVEsS0FBSyxFQUFHO0FBQ3ZELE1BQUksTUFBTSxLQUFLLGFBQWE7QUFDMUIsUUFBSSxDQUFDLEtBQU0sWUFBVyxNQUFNLE9BQU8sR0FBRyxPQUFPLEdBQUcsS0FBSyxLQUFLLEtBQUssT0FBTyxVQUFVO0FBQ2hGO0FBQUEsRUFDRjtBQUNBLE1BQUcsUUFBUSxDQUFDLFVBQVUsTUFBSyxJQUFJLEVBQUUsZ0JBQWdCO0FBQ2pELE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxDQUFDLE1BQU0sTUFBTSxZQUFZLE1BQU0sSUFBSSxHQUFHLFlBQVksTUFBSyxNQUFNLEdBQUcsS0FBSyxNQUFNLGdCQUFnQixNQUFNLElBQUksQ0FBQyxFQUFHO0FBQzdHLG9CQUFrQixNQUFNLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxlQUFlLHlCQUF5QixNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxXQUFXO0FBQ3pJLGNBQVksSUFBSTtBQUNoQixPQUFLLFdBQVcsaUJBQWlCLE1BQU0sSUFBSTtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE1BQVksTUFBWSxhQUFhLE1BQU07QUFDcEUsUUFBTSxRQUFRLEtBQUs7QUFDbkIsTUFBSSxNQUFNLFNBQVMsU0FBVTtBQUM3QixNQUFJLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxRQUFRO0FBQ2xELE1BQUksQ0FBQyxRQUFRO0FBQ1gsU0FBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQzVCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxjQUFjLE9BQU8sTUFBTSxNQUFNLE9BQU8sUUFBUSxPQUFPLFNBQVMsV0FBVyxPQUFPLElBQUksR0FBSSxjQUFhO0FBQzVHLE1BQUksY0FBYyxDQUFDLFdBQVcsTUFBTSxFQUFHLFVBQVMsa0JBQWtCLE1BQU0sTUFBTSxNQUFNO0FBRXBGLE1BQUksbUNBQW1DLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxNQUFNLGNBQWMsS0FBSyxJQUFJLFlBQVksQ0FBQyxTQUFTLEtBQUssS0FBSyxNQUFNLFFBQVEsS0FBSyxLQUFLLEdBQUc7QUFDMUosVUFBTSxjQUFjLG1CQUFtQixNQUFNLE1BQU0sS0FBSyxJQUFJLG9CQUFvQixLQUFLLFdBQVcsR0FBRyxVQUFVO0FBQzdHLFFBQUksQ0FBQyxhQUFhO0FBQ2hCLFdBQUssUUFBUSxFQUFFLE1BQU0sT0FBTztBQUM1QjtBQUFBLElBQ0Y7QUFDQSxTQUFLLFFBQVEsRUFBRSxHQUFHLE9BQU8sVUFBVSxZQUFZLEdBQUc7QUFDbEQsc0JBQWtCLE1BQU0sTUFBTSxVQUFVO0FBQ3hDO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQyxXQUFXLE1BQU0sTUFBTSxLQUFLLFVBQVUsYUFBYSxNQUFNLFdBQVcsU0FBWTtBQUNuRixRQUFHLGNBQWMsQ0FBQyx1QkFBdUIsS0FBSyxPQUFNLEtBQUssT0FBTSxNQUFNLEdBQUU7QUFBQyxXQUFLLFFBQU0sRUFBQyxNQUFLLE9BQU07QUFBRTtBQUFBLElBQU87QUFDeEcsYUFBUyxzQkFBc0IsTUFBTSxNQUFNLFFBQVEsVUFBVTtBQUM3RCxRQUFJLE9BQU8sT0FBTyxNQUFNLFNBQVUsTUFBSyxRQUFRLEVBQUUsR0FBRyxPQUFPLFVBQVUsT0FBTyxHQUFHO0FBQUEsRUFDakY7QUFDQSxRQUFNLE1BQU0sVUFBVSxNQUFNLFFBQVEsVUFBVTtBQUM5QyxRQUFNLE9BQU8sY0FBYyxRQUFRLFlBQVksSUFBSSxDQUFDO0FBQ3BELE1BQUksQ0FBQyxRQUFRLGtCQUFrQixNQUFNLE1BQU0sUUFBUSxLQUFLLEVBQUc7QUFDM0QsTUFBSSxNQUFNLEtBQUssYUFBYTtBQUMxQixRQUFJLFdBQVcsS0FBSyxLQUFLLEtBQUssTUFBTSxXQUFXLFVBQWEsTUFBTSxXQUFXLFVBQWEsU0FBUyxNQUFNLEVBQUUsR0FBRyxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxJQUFJLG1CQUFtQjtBQUNsSyxXQUFLLFFBQVEsRUFBRSxNQUFNLFFBQVEsR0FBRyxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU87QUFDOUQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxLQUFNLG9CQUFtQixNQUFNLE1BQU0sTUFBTTtBQUFBLFFBQzFDLFlBQVcsTUFBTSxPQUFPLEdBQUcsT0FBTyxHQUFHLEtBQUssS0FBSyxLQUFLLE9BQU8sVUFBVTtBQUMxRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQU0sb0JBQW1CLE1BQU0sTUFBTSxNQUFNO0FBQy9DLE1BQUcsUUFBUSxDQUFDLFVBQVUsTUFBSyxJQUFJLEVBQUUsZ0JBQWdCO0FBQ2pELE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxDQUFDLE1BQU0sTUFBTSxZQUFZLE1BQU0sSUFBSSxHQUFHLFlBQVksTUFBSyxNQUFNLEdBQUcsS0FBSyxNQUFNLGdCQUFnQixNQUFNLElBQUksQ0FBQyxFQUFHO0FBQzdHLG9CQUFrQixNQUFNLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxlQUFlLHlCQUF5QixNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxXQUFXO0FBQ3pJLGNBQVksSUFBSTtBQUNoQixPQUFLLFdBQVcsaUJBQWlCLE1BQU0sSUFBSTtBQUM3QztBQUVBLFNBQVMsbUJBQW1CLE1BQVksTUFBWSxRQUFvQztBQUN0RixNQUFHLEtBQUssZUFBZSxJQUFJLEtBQUssRUFBRSxFQUFFO0FBQ3BDLFFBQU0sVUFBVSxpQkFBaUIsTUFBTSxJQUFJLEVBQUUsT0FBTyxXQUFTLEtBQUssY0FBYyxLQUFLLENBQUM7QUFDdEYsUUFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLElBQUksR0FBRyxRQUFRLElBQUksVUFBUSxhQUFhLEtBQUssSUFBaUMsRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDLElBQ3ZJLFlBQVksTUFBTSxJQUFJLEVBQUUsUUFBUSxZQUFZO0FBQ2hELFFBQU0sV0FBUyxxQkFBcUIsTUFBSyxJQUFJO0FBQzdDLE1BQUk7QUFDSixRQUFNLGNBQWMsQ0FBQyxTQUFhLGNBQXNCO0FBQ3RELFFBQUksQ0FBQyxRQUFRLE9BQVEsUUFBTyxVQUFVLFNBQVMsTUFBTSxLQUFLLFFBQVEsZUFBZSxVQUFVLFNBQVMsTUFBTSxLQUFLO0FBQy9HLHFCQUFpQixNQUFLLE9BQU87QUFDN0IsVUFBTSxRQUFRLEVBQUUsR0FBRyxRQUFRLEdBQUcsR0FBRyxRQUFRLEdBQUcsU0FBUyxRQUFRLFFBQVMsUUFBUTtBQUM5RSxVQUFNLFlBQVUsaUJBQWlCLFNBQVEsUUFBUTtBQUNqRCxlQUFXLFVBQVUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFDdEMsWUFBTSxVQUFVLGtCQUFrQixNQUFNLFNBQVMsUUFBUSxRQUFPLFNBQVMsR0FBRyxRQUFRLEVBQUUsR0FBRyxTQUFTLFNBQVMsRUFBRSxHQUFHLFFBQVEsU0FBVSxRQUFRLEVBQUUsR0FBRyxNQUFNLEVBQUUsR0FBRyxPQUFPLFFBQVE7QUFDekssdUJBQWlCLE1BQUssS0FBSztBQUMzQixVQUFJLGNBQWMsQ0FBQyxpQkFBaUIsS0FBSyxLQUFLLFNBQVMsT0FBTyxHQUFHLEtBQUssQ0FBQyxZQUFZLFNBQVMsS0FBSyxLQUFLLEVBQUUsT0FBTyxHQUFHLEdBQUk7QUFDdEgsVUFBSSxRQUFRLEtBQUssVUFBUTtBQUN2QixjQUFNLE9BQU8sa0JBQWtCLE9BQU8sSUFBSSxHQUFHLE1BQU0sYUFBYSxLQUFLLElBQWlDO0FBQ3RHLFlBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsY0FBTSxRQUFRLG1CQUFtQixNQUFLLE9BQU0sTUFBSyxRQUFPLElBQUk7QUFDNUQsWUFBSSxDQUFDLGNBQWMsT0FBTyxNQUFNLEtBQUssRUFBRyxRQUFPO0FBQy9DLGNBQU0sTUFBTSxTQUFTLEtBQUssT0FBTyxLQUFLO0FBQ3RDLGVBQU8sT0FBTyxtQkFBbUIsU0FBUyxJQUFJLEtBQUssS0FBSyxRQUFRLElBQUksT0FBTyxZQUFZLE9BQ2pGLENBQUMsU0FBUyxVQUFVLHFCQUFxQixPQUFNLE1BQUssT0FBTSxRQUFRO0FBQUEsTUFDMUUsQ0FBQyxHQUFHO0FBQUUsWUFBRyxVQUFVLGlCQUFnQjtBQUFTLGVBQU87QUFBQSxNQUFNO0FBQUEsSUFDM0Q7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FBUyxZQUFZLE1BQUssSUFBSTtBQUNwQyxRQUFNLE1BQUksUUFBUSxLQUFLLFVBQU0sS0FBSyxZQUFVLFNBQVMsbUJBQW1CLE1BQUssYUFBYSxLQUFLLElBQWlDLEVBQUUsS0FBSyxLQUFHLEtBQUssV0FBVztBQUMxSixRQUFNLFVBQVEsT0FBTyxrQkFBa0IsTUFBSyxHQUFHO0FBQy9DLFFBQU0sa0JBQWdCLFdBQVcsUUFBUSxNQUFNLElBQUUsS0FBSyxLQUFHLE9BQU8sS0FBSyxRQUFTLE9BQU8sS0FBRyxRQUFRLE1BQU0sSUFBRSxLQUFLLEtBQUcsT0FBTyxLQUFLLFFBQVMsT0FBTyxJQUFJO0FBQ2hKLFFBQU0sT0FBTyxnQkFBZ0IsTUFBTSxRQUFRLEtBQUssT0FBTyxLQUFLLGFBQWEsU0FBUyxPQUFPLE1BQU0sUUFBUSxLQUFLLEtBQUssZUFBYyxpQkFBZ0IsYUFBUyxZQUFZLFNBQVEsS0FBSyxHQUFFLE1BQUksaUJBQWlCLElBQUksQ0FBQztBQUM3TSxRQUFNLE9BQU8sV0FBVyxJQUFJO0FBQzVCLE1BQUksUUFBUSxPQUFPLEVBQUcsWUFBVyxNQUFNLE1BQU0sS0FBSyxLQUFLLEtBQUssT0FBTyxJQUFJO0FBQUEsV0FDOUQsQ0FBQyxRQUFRLEtBQUssUUFBUyw0QkFBNEIsVUFBYSxDQUFDLEtBQUssUUFBUyxPQUFPO0FBSTdGLFNBQUssUUFBUyxRQUFRO0FBQ3RCLFFBQUksT0FBTyxHQUFHO0FBQ1osWUFBTSxTQUFTLHFCQUFxQixRQUFRLEtBQUssS0FBSztBQUN0RCxxQkFBZSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUksS0FBSyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLO0FBQUEsSUFDN0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixNQUFZLE1BQVk7QUFDL0MsTUFBSSxLQUFLLE1BQU0sU0FBUyxPQUFRO0FBQ2hDLFFBQU0sUUFBUSxLQUFLO0FBQ25CLFFBQU0sV0FBVyxLQUFLLFlBQWEsVUFBVSxJQUFJLE1BQU0sVUFBVTtBQUNqRSxPQUFLLENBQUMsWUFBWSxTQUFTLFVBQVUsTUFBTSxNQUFNLFVBQVUsVUFBVTtBQUNuRSxTQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDNUI7QUFBQSxFQUNGO0FBRUEsTUFBSSxNQUFNLFVBQVUsVUFBVTtBQUM1QixRQUFJLFNBQVMsTUFBTSxRQUFTLElBQUksWUFBWTtBQUMxQyxpQkFBVyxNQUFNLFNBQVUsR0FBRyxTQUFVLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSztBQUMvRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFNBQVM7QUFDZixTQUFLLFNBQVUsNEJBQTRCLEtBQUssRUFBRztBQUNuRCxRQUFJLEtBQUssWUFBYSxXQUFXLElBQUksTUFBTSxVQUFVLE1BQU0sS0FBSyxHQUFJO0FBQ3BFLFNBQUssV0FBVyxNQUFNO0FBQ3RCLGFBQVUsMkJBQTJCO0FBQ3JDLFNBQUssUUFBUSxFQUFFLEdBQUcsT0FBTyxPQUFPLFVBQVUsT0FBTyxnQkFBZ0I7QUFDakU7QUFBQSxFQUNGO0FBRUEsTUFBSSxNQUFNLFVBQVUsVUFBVTtBQUM1QixVQUFNLFNBQVM7QUFDZixRQUFJLE1BQU0sUUFBUSxFQUFHO0FBQ3JCLFVBQU0sUUFBUSxLQUFLLElBQUksZUFBZSxTQUFVLE1BQU07QUFDdEQsYUFBVSxVQUFVO0FBQ3BCLFNBQUssZUFBZTtBQUNwQixTQUFLLFFBQVEsRUFBRSxHQUFHLE9BQU8sT0FBTyxVQUFVLE9BQU8sRUFBRTtBQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFdBQVcsd0JBQXdCLE1BQU0sS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekUsTUFBSSxDQUFDLFVBQVU7QUFDYixTQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDNUI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxTQUFTLE1BQU0sUUFBUSxJQUFJLHNCQUFzQjtBQUNuRCxlQUFXLE1BQU0sU0FBUyxHQUFHLFNBQVMsR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLO0FBQzdEO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxLQUFLLEtBQUssR0FBRztBQUMxQixVQUFNLFNBQVMsWUFBWSxNQUFNLEtBQUssS0FBSztBQUMzQyxXQUFPLE9BQU8sUUFBUSxPQUFPLE1BQU0saUJBQWlCLEtBQUssY0FBYyxPQUFPLFVBQVUsQ0FBQztBQUFBLEVBQzNGO0FBQ0EsT0FBSyxlQUFlO0FBQ3BCLE9BQUssUUFBUSxZQUFZLFNBQVMsU0FBUyxJQUFJLEVBQUUsTUFBTSxRQUFRLFlBQVksU0FBUyxJQUFJLE9BQU8sVUFBVSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sT0FBTztBQUN2STtBQUlBLFNBQVMscUJBQXFCLE1BQVUsTUFBVztBQUNqRCxNQUFHLEtBQUssTUFBTSxTQUFPLFlBQVk7QUFDakMsUUFBTSxRQUFNLEtBQUs7QUFDakIsUUFBTSxTQUFPLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLE1BQU0sWUFBWSxLQUFLLEtBQUcsQ0FBQztBQUN4RSxNQUFHLENBQUMsVUFBVSxDQUFDLFlBQVksSUFBSSxLQUFLLENBQUMsS0FBSyxTQUFTO0FBQ2pELHVCQUFtQixJQUFJO0FBQUUsU0FBSyxRQUFNLEVBQUMsTUFBSyxPQUFNO0FBQUU7QUFBQSxFQUNwRDtBQUNBLE1BQUcsQ0FBQyxLQUFLLFFBQVEsV0FBVyxDQUFDLGtCQUFrQixLQUFLLEtBQUksS0FBSyxPQUFNLE1BQUssUUFBTyxLQUFLLE1BQUssSUFBSSxHQUFHO0FBQzlGLFNBQUssUUFBTSxFQUFDLE1BQUssT0FBTTtBQUFFO0FBQUEsRUFDM0I7QUFDQSxRQUFNLFFBQU0sS0FBSyxRQUFRO0FBQ3pCLE1BQUcsTUFBTSxVQUFRLFlBQVk7QUFDM0IsVUFBTSxPQUFLLGlCQUFpQixLQUFLLEtBQUksS0FBSyxPQUFNLE1BQUssTUFBTTtBQUMzRCxRQUFHLEtBQUssWUFBVyxNQUFLLE1BQUssS0FBSyxLQUFJLEtBQUssT0FBTSxXQUFXLElBQUksQ0FBQztBQUNqRTtBQUFBLEVBQ0Y7QUFDQSxPQUFLLFFBQVEsUUFBTTtBQUFFLE9BQUssUUFBUSxVQUFRO0FBQzFDLE1BQUcsTUFBTSxVQUFRLFFBQVE7QUFDekIsTUFBRyxlQUFlLE1BQUssS0FBSyxPQUFNLE9BQU8sS0FBSyxFQUFFLFlBQVUsUUFBUSxlQUFlLEtBQUssT0FBTSxJQUFJLEdBQUc7QUFDakcsVUFBTSxZQUFVLEtBQUs7QUFDckIsVUFBTSxrQkFBZ0IsVUFBVSxTQUFPLFlBQVksVUFBVSxXQUFTLFNBQ2xFLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLFVBQVUsUUFBUSxJQUFJO0FBQzFELFVBQU0sa0JBQWdCLFVBQVUsU0FBTyxZQUFZLFVBQVUsV0FBUyxXQUNoRSxVQUFVLGFBQVcsT0FBTyxNQUFNLGlCQUFpQixNQUFNLFdBQVMsT0FBTztBQUMvRSxRQUFHLEtBQUssVUFBUSxLQUFLLFNBQVMsS0FBSyxTQUFPLFlBQVksQ0FBQyxvQkFBb0IsTUFBSyxJQUFJLEtBQy9FLFVBQVUsTUFBSyxJQUFJLEVBQUUsY0FBWSxpQ0FBaUMsS0FBSyxnQkFBYyxLQUNyRixDQUFDLENBQUMsUUFBTyxNQUFNLEVBQUUsU0FBUyxLQUFLLE1BQU0sSUFBSSxLQUFLLENBQUMsbUJBQW1CLEtBQUssWUFBWSxPQUFPO0FBQy9GLG9CQUFnQixNQUFLLEVBQUMsTUFBSyxTQUFRLGFBQVksT0FBTyxHQUFFLENBQUM7QUFBQSxFQUMzRDtBQUdBLE9BQUssUUFBTSxFQUFDLE1BQUssT0FBTTtBQUN6QjtBQUVBLFNBQVMsaUJBQWlCLE1BQVksTUFBWTtBQUNoRCxNQUFJLEtBQUssTUFBTSxTQUFTLFFBQVM7QUFDakMsUUFBTSxZQUFZLFdBQVcsTUFBTSxLQUFLLE1BQU0sV0FBVztBQUN6RCxNQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sU0FBUyxLQUFLLFVBQVUsTUFBSSxLQUFLLENBQUMsS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFLLE9BQU87QUFDdkcsU0FBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQzVCO0FBQUEsRUFDRjtBQUNBLE1BQUcsS0FBSyxNQUFLO0FBQ1gsVUFBTSxTQUFPLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLEtBQUssS0FBTSxNQUFNO0FBQzlELFFBQUcsQ0FBQyxPQUFPO0FBQ1gsUUFBRyxPQUFPLE9BQUssVUFBVSxNQUFNLENBQUMsaUJBQWlCLFFBQU8sV0FBVSxJQUFJLEVBQUU7QUFHeEUsUUFBRyxLQUFLLFNBQU8sWUFBWSxlQUFlLE1BQUssS0FBSyxPQUFNLFVBQVUsS0FBSyxLQUFLLEtBQUssZUFBYSxLQUMzRixVQUFVLE1BQUssSUFBSSxFQUFFLGVBQWEsK0JBQStCO0FBR3BFLFlBQU0sU0FBTyxrQkFBa0IsTUFBSyxNQUFLLFdBQVUsS0FBSyxXQUFXO0FBQ25FLFlBQU0sV0FBUyxXQUFTLFlBQVksU0FBUyxrQkFBa0IsTUFBSyxNQUFLLFNBQVM7QUFDbEYsVUFBRyxhQUFXLGFBQWEsT0FBTyxRQUFRLEdBQUc7QUFDM0MsY0FBTSxnQkFBYyxLQUFLO0FBQ3pCLGFBQUssUUFBTSxFQUFDLE1BQUssVUFBUyxVQUFTLFNBQVMsR0FBRTtBQUM5QyxZQUFJO0FBQUUsNEJBQWtCLE1BQUssSUFBSTtBQUFBLFFBQUcsVUFDcEM7QUFBVSxlQUFLLFFBQU07QUFBQSxRQUFlO0FBQ3BDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFHLE9BQU8sT0FBSyxVQUFVLE1BQU0sQ0FBQyxTQUFTLFdBQVUsTUFBSyxLQUFLLEtBQUssR0FBRTtBQUNsRSxXQUFLLFFBQU0sRUFBQyxNQUFLLE9BQU07QUFDdkIsZ0JBQVUsTUFBSyxtQkFBa0IsS0FBSyxHQUFFLEtBQUssR0FBRSxRQUFRLEdBQUUsR0FBRSxFQUFDLFFBQU8sS0FBSyxJQUFHLE9BQU0sS0FBSyxPQUFNLFlBQVcsS0FBSyxLQUFJLENBQUM7QUFDakg7QUFBQSxJQUNGO0FBR0EsVUFBTSxRQUFNLEtBQUssTUFBTSxLQUFLLFdBQU8sVUFBUSxRQUFRLE1BQU0sS0FBRyxLQUFLLE1BQU0sUUFBUSxNQUFNLE1BQU0sU0FBTyxXQUFXLE1BQU0sTUFBTSxnQkFBYyxVQUFVLE9BQzNJLE1BQU0sU0FBTyxLQUFLLFVBQVUsTUFBTSxXQUFTLEtBQUssVUFBVSxNQUFNLEtBQUcsS0FBSyxHQUFHO0FBQ2pGLFFBQUcsU0FBUyxPQUFPLE9BQUssVUFBVSxJQUFHO0FBQ25DLFlBQU0sVUFBUSxZQUFZLE1BQU0sR0FBRyxRQUFNLGFBQWEsUUFBTyxTQUFTO0FBQ3RFLFlBQU0sVUFBUSxjQUFjLFFBQU8sTUFBSyxLQUFLLE9BQU0sRUFBQyxHQUFFLFFBQVEsU0FBTyxHQUFFLEdBQUUsQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLElBQUUsUUFBUSxPQUFLLEVBQUMsQ0FBQztBQUM1RyxVQUFHLFNBQVE7QUFBQyxjQUFNLEtBQUcsYUFBYSxRQUFPLE9BQU87QUFBRSxtQkFBVyxNQUFLLEdBQUcsR0FBRSxHQUFHLEdBQUUsS0FBSyxLQUFJLEtBQUssS0FBSztBQUFBLE1BQUU7QUFDakc7QUFBQSxJQUNGO0FBQ0EsUUFBRyxLQUFLLE1BQU0sYUFBYSxDQUFDLGNBQWMsV0FBVSxNQUFLLEtBQUssTUFBTSxXQUFVLEtBQUssT0FBTSxJQUFJLEVBQUUsUUFBTyxLQUFLLE1BQU07QUFDakgsUUFBRyxDQUFDLEtBQUssTUFBTSxXQUFVO0FBQ3ZCLFlBQU0sV0FBUyxLQUFLLE1BQU0sSUFBSSxXQUFPLFVBQVEsUUFBUSxNQUFNLE1BQU0sU0FBTyxXQUFXLE1BQU0sTUFBTSxnQkFBYyxVQUFVLE1BQU0sTUFBTSxNQUFNLFlBQ3JJLEVBQUMsR0FBRyxPQUFNLE1BQUssRUFBQyxRQUFPLFVBQVUsSUFBRyxHQUFHLE1BQU0sTUFBTSxVQUFTLEVBQUMsSUFBSSxLQUFLO0FBQzFFLFlBQU0sUUFBTSxhQUFhLFdBQVUsTUFBTSxHQUFFLFVBQVEsWUFBWSxTQUFTO0FBRXhFLFlBQU0sUUFBTSxLQUFLLE1BQU0sTUFBTSxHQUFFLE1BQU0sQ0FBQyxLQUFHO0FBQ3pDLFlBQU0sWUFBVSxFQUFDLEdBQUUsUUFBUSxTQUFPLEdBQUUsR0FBRSxDQUFDLE1BQU0sSUFBRSxRQUFNLFFBQVEsT0FBSyxFQUFDO0FBQ25FLFlBQU1GLFNBQU0sY0FBYyxXQUFVLE1BQUssVUFBUyxXQUFVLElBQUk7QUFDaEUsVUFBR0EsT0FBTSxNQUFLLE1BQU0sWUFBVUE7QUFBQSxJQUNoQztBQUNBLFVBQU0sUUFBTSxLQUFLLE1BQU07QUFBVSxRQUFHLENBQUMsTUFBTTtBQUMzQyxVQUFNRyxRQUFLLGFBQWEsV0FBVSxLQUFLO0FBQ3ZDLFFBQUcsT0FBTyxPQUFLLFVBQVUsSUFBRztBQUMxQixpQkFBVyxNQUFLQSxNQUFLLEdBQUVBLE1BQUssR0FBRSxLQUFLLEtBQUksS0FBSyxLQUFLO0FBQ2pELFVBQUcsU0FBUyxNQUFLQSxLQUFJLElBQUUsS0FBSyxNQUFLLFFBQU0sRUFBQyxNQUFLLE9BQU07QUFBQSxJQUNyRCxXQUFVLGlCQUFpQixRQUFPLFdBQVUsSUFBSSxFQUFFLFlBQVcsTUFBS0EsTUFBSyxHQUFFQSxNQUFLLEdBQUUsS0FBSyxLQUFJLEtBQUssS0FBSztBQUNuRztBQUFBLEVBQ0Y7QUFDQSxNQUFJLFVBQVUsTUFBTSxTQUFTLEVBQUc7QUFDaEMsUUFBTSxPQUFPLFVBQVUsTUFBTSxTQUFTLFNBQVMsS0FBSyxNQUFNLE9BQU8sU0FBUyxLQUFLLE1BQU0sU0FBUyxZQUFZO0FBQzFHLGFBQVcsTUFBTSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFDdkQ7QUFLQSxTQUFTLFdBQVcsTUFBWSxFQUFFLFVBQVUsVUFBVSxHQUFVLFFBQWlFO0FBQy9ILFFBQU0sYUFBVyxvQkFBSSxJQUFZO0FBQ2pDLGFBQVUsYUFBYSxVQUFVO0FBQy9CLFFBQUcsVUFBVSxNQUFNLFNBQU8sV0FBVyxVQUFVLFFBQVEsV0FBVyxJQUFJLFVBQVUsTUFBTSxXQUFXLEVBQUU7QUFDbkcsVUFBTSxPQUFLLFdBQVcsTUFBSyxVQUFVLE1BQU0sV0FBVztBQUN0RCxRQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssTUFBTSxTQUFPLE9BQU87QUFDdEQsZUFBVyxJQUFJLEtBQUssRUFBRTtBQUN0QixVQUFNLFFBQU0sVUFBVSxNQUFNLFNBQVMsY0FBYyxLQUFLLEtBQUksV0FBVSxJQUFJO0FBRzFFLFFBQUcsU0FBUyxDQUFDLFVBQVUsV0FBVSxJQUFJLEVBQUUsWUFBVyxNQUFLLE9BQU0sS0FBSyxLQUFJLEtBQUssS0FBSztBQUFBLEVBQ2xGO0FBQ0EsYUFBVSxhQUFhLFVBQVU7QUFDL0IsUUFBRyxVQUFVLE1BQU0sU0FBTyxXQUFXLFVBQVUsS0FBSztBQUNwRCxVQUFNLE9BQUssV0FBVyxNQUFLLFVBQVUsTUFBTSxXQUFXO0FBQ3RELFFBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxVQUFVLFdBQVUsSUFBSSxFQUFFO0FBQ3hELFVBQU0sVUFBUSxVQUFVLE1BQUssV0FBVSxLQUFLLEtBQUs7QUFDakQsb0JBQWdCLFdBQVUsRUFBQyxNQUFLLE9BQU0sQ0FBQztBQUN2QyxjQUFVLE1BQUssVUFBVSxVQUFVLG1CQUFrQixVQUFVLEdBQUUsVUFBVSxHQUFFLFFBQVEsR0FBRSxHQUFFLEVBQUMsUUFBTyxVQUFVLElBQUcsT0FBTSxVQUFVLE9BQU0sWUFBVyxVQUFVLEtBQUksQ0FBQztBQUFBLEVBQ2hLO0FBQ0EsYUFBVSxRQUFRLFdBQVc7QUFDM0IsUUFBRyxLQUFLLE1BQU0sU0FBTyxhQUFhLEtBQUssU0FBUyxTQUFPLEtBQUcsSUFBRztBQUM3RCxVQUFNLFFBQU0sT0FBTyxJQUFJLEtBQUssRUFBRTtBQUM5QixRQUFHLFVBQVUsU0FBUyxNQUFLLEtBQUssSUFBRSxRQUFRLEtBQUssSUFBSSxrQkFBa0IsTUFBTSxTQUFRLEtBQUssUUFBUyxPQUFPLENBQUMsSUFBRSxNQUFNO0FBSWpILFVBQU0sVUFBUSxVQUFVLE1BQUssTUFBSyxLQUFLLE9BQU0sQ0FBQztBQUc5QyxVQUFNLFdBQVMsS0FBSyxTQUFTLGdCQUFjLFVBQWEsS0FBSyxTQUFTLDRCQUEwQjtBQUNoRyxRQUFHLFlBQVksTUFBSyxJQUFJLElBQUUsS0FBSyxXQUFXLENBQUMsWUFBWSxlQUFlLEtBQUssT0FBTSxJQUFJLEVBQUUsV0FBUyxFQUFFLE1BQUssUUFBTSxFQUFDLE1BQUssT0FBTTtBQUFBLEVBQzNIO0FBQ0Y7QUFHQSxTQUFTLFlBQVksTUFBWSxNQUFZLGFBQXNCO0FBQ2pFLE1BQUcsS0FBSyxNQUFNLG1CQUFrQixLQUFLLEtBQUs7QUFDMUMsUUFBTSxPQUFLLGVBQWUsS0FBSyxPQUFNLElBQUk7QUFDekMsTUFBSSxTQUFPO0FBQ1gsT0FBSyxRQUFRLENBQUMsV0FBVSxVQUFRO0FBQzlCLFFBQUcsVUFBVSxTQUFTLEtBQUssVUFBVSxVQUFRLEtBQUssU0FBUyxnQkFBYyxVQUFhLFVBQVUsT0FBSyxZQUFZO0FBQ2pILFVBQU0sT0FBSyxZQUFZLEtBQUssS0FBSSxNQUFLLE9BQU0sS0FBSyxRQUFPLEtBQUssT0FBTSxTQUFTO0FBQzNFLFFBQUcsQ0FBQyxLQUFLO0FBQ1QsY0FBVSxPQUFLO0FBQ2YsY0FBVSxRQUFNO0FBQ2hCLGNBQVUsTUFBSTtBQUNkLFdBQU8sT0FBTyxXQUFVLElBQUk7QUFDNUIsb0JBQWdCLFdBQVUsRUFBQyxNQUFLLE9BQU0sQ0FBQztBQUN2QyxjQUFVLE1BQUssVUFBUyxLQUFLLEdBQUUsS0FBSyxHQUFFLFFBQVEsR0FBRSxHQUFFLEVBQUMsUUFBTyxVQUFVLElBQUcsT0FBTSxVQUFVLE9BQU0sWUFBVyxVQUFVLEtBQUksQ0FBQztBQUN2SDtBQUFBLEVBQ0YsQ0FBQztBQUNELFlBQVUsS0FBSyxLQUFLO0FBQ3BCLG9CQUFrQixJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxNQUFZLE1BQVk7QUFDM0MsVUFBUSxLQUFLLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFJLGNBQVksTUFBSSxVQUFVLE1BQUssU0FBUyxFQUFFLFlBQVcsQ0FBQztBQUM5RjtBQUVBLFNBQVMsaUJBQWlCLE1BQVksTUFBWTtBQUNoRCxNQUFJLEtBQUssTUFBTSxTQUFTLFdBQVcsQ0FBQyxXQUFXLEtBQUssS0FBSyxFQUFHO0FBQzVELFFBQU0sUUFBUSxLQUFLO0FBQ25CLFFBQU0sTUFBTSxjQUFjLE1BQU0sWUFBWTtBQUM1QyxRQUFNLE9BQU8sY0FBYyxJQUFJLFFBQVEsWUFBWTtBQUNuRCxRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUUsTUFBTSxDQUFDLElBQUUsSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUUsTUFBTSxDQUFDLElBQUUsSUFBSSxDQUFDO0FBQzdHLE1BQUksTUFBTSxxQkFBcUI7QUFFN0IsUUFBSSxNQUFNLGlCQUFpQixVQUFhLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxhQUFhLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxhQUFhLEtBQUssRUFBRSxJQUFJLElBQUk7QUFDbkksWUFBTSxlQUFlLEtBQUs7QUFBTSxZQUFNLFlBQVksS0FBSztBQUFHLFlBQU0sWUFBWSxLQUFLO0FBQUEsSUFDbkYsV0FBVyxLQUFLLE9BQU8sTUFBTSxlQUFlLFFBQVEsRUFBRSxHQUFHO0FBQ3ZELFdBQUssUUFBUSxFQUFFLE1BQU0sT0FBTztBQUFHO0FBQUEsSUFDakM7QUFDQSxlQUFXLE1BQU0sTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLO0FBQUc7QUFBQSxFQUM1RDtBQUVBLE1BQUkseUJBQXlCLE1BQU0sTUFBTSxjQUFjLEtBQUssS0FBSyx1QkFBdUIsS0FBSyxLQUFLLE1BQU0sY0FBYyxLQUFLLEdBQUc7QUFDNUgsU0FBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQUc7QUFBQSxFQUNqQztBQUNBLE1BQUksWUFBWSxNQUFNLEtBQUssS0FBSyxFQUFFLE9BQU8sSUFBSSxLQUFNO0FBQ25ELFlBQVUsTUFBTSxLQUFLLE9BQU8sSUFBSSxJQUFJO0FBQ3BDLFFBQU0sV0FBVyxlQUFlLFlBQVksS0FBSyxLQUFLLElBQUksTUFBTSxZQUFZLElBQUksS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPLE1BQU0sY0FBYyxNQUFNLEdBQUcsTUFBTSxHQUFHLEtBQUs7QUFDeEosNEJBQTBCLE1BQU0sUUFBUTtBQUN4QyxXQUFTLEtBQUssb0JBQW9CLFNBQVMsS0FBSztBQUNoRCxPQUFLLFVBQVUsS0FBSyxRQUFRO0FBQzVCLHFCQUFtQixJQUFJO0FBQ3ZCLE9BQUssUUFBUSxFQUFFLE1BQU0sVUFBVSxZQUFZLFNBQVMsR0FBRztBQUN2RCxZQUFVLE1BQU0sU0FBUyxTQUFTLEdBQUcsU0FBUyxHQUFHLEVBQUU7QUFDckQ7QUFFQSxTQUFTLGtCQUFrQixNQUFZLE1BQVk7QUFDakQsTUFBSSxLQUFLLE1BQU0sU0FBUyxZQUFZLENBQUMsV0FBVyxLQUFLLEtBQUssRUFBRztBQUM3RCxRQUFNLFFBQVEsS0FBSztBQUNuQixRQUFNLFdBQVcsS0FBSyxVQUFVLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFNLGNBQWMsVUFBVSxVQUFVLEtBQUssS0FBSztBQUN2SCxNQUFJLENBQUMsWUFBWSxTQUFTLE1BQU0sS0FBTSxTQUFTLFlBQVksU0FBUyxNQUFNLFNBQVMsT0FBUTtBQUN6RixTQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDNUI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxnQkFBZ0IsTUFBTSxRQUFRLElBQUkscUJBQXFCO0FBQ3pELGVBQVcsTUFBTSxTQUFTLEdBQUcsU0FBUyxHQUFHLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFDN0Q7QUFBQSxFQUNGO0FBRUEsTUFBSSxDQUFDLFNBQVMsWUFBWSxLQUFLLFdBQVcsRUFBRztBQUM3QyxNQUFJLENBQUMsbUJBQW1CLE1BQU0sTUFBTSxRQUFRLEVBQUcsTUFBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQzdFO0FBRUEsU0FBUyxpQkFBaUIsTUFBWSxNQUFZO0FBQ2hELE1BQUksS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDLFdBQVcsS0FBSyxLQUFLLEVBQUcsUUFBTztBQUNsRSxNQUFJLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDOUIsUUFBTSxXQUFXLEtBQUssVUFBVTtBQUFBLElBQzlCLENBQUMsY0FBYyxVQUFVLFVBQVUsS0FBSyxTQUFTLFVBQVUsWUFBWSxVQUFVLEtBQUssS0FBSyxVQUFVLEtBQUssVUFBVSxTQUFTLGdCQUFnQixNQUFNLFNBQVMsS0FBSztBQUFBLEVBQ25LO0FBQ0EsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixTQUFPLG1CQUFtQixNQUFNLE1BQU0sUUFBUTtBQUNoRDtBQUVBLFNBQVMsc0JBQXNCLE1BQVksUUFBYztBQUN2RCxNQUFJLE9BQU8sTUFBTSxTQUFTLGdCQUFnQixPQUFPLE1BQU0sU0FBUyxhQUFjO0FBQzlFLE1BQUksT0FBTyxTQUFTLFlBQVksQ0FBQyxXQUFXLE9BQU8sS0FBSyxHQUFHO0FBQUUsV0FBTyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQUc7QUFBQSxFQUFRO0FBQ3RHLFFBQU0sV0FBVyxPQUFPLE1BQU07QUFDOUIsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLFVBQVEsS0FBSyxPQUFPLFlBQVksS0FBSyxVQUFVLE9BQU8sVUFDL0UsT0FBTyxNQUFNLFNBQVMsZ0JBQWdCLFVBQVUsS0FBSyxJQUFJLE1BQU0sTUFBTTtBQUMzRSxNQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixNQUFNLE1BQU0sR0FBRztBQUFFLFdBQU8sUUFBUSxFQUFFLE1BQU0sT0FBTztBQUFHO0FBQUEsRUFBUTtBQUMxRixRQUFNLE9BQU8sUUFBUSxZQUFZLE1BQU0sQ0FBQztBQUN4QyxRQUFNLGtCQUFrQixPQUFPLE9BQU8sTUFBTSxXQUFXLE9BQU8sS0FBSyxPQUFPLE1BQU0sV0FBVyxPQUFPLE1BQU07QUFDeEcsUUFBTSxjQUFjLFNBQVMsUUFBUSxNQUFNLEtBQUssT0FBTyxTQUFTLE9BQU8sU0FBUztBQUdoRixRQUFNLGNBQWMsT0FBTyxtQkFBbUIsQ0FBQyxPQUFPLFFBQVEsY0FBYyxtQkFBbUI7QUFDL0YsTUFBSSxDQUFDLGFBQWE7QUFDaEIsZUFBVyxRQUFRLE9BQU8sR0FBRyxPQUFPLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSztBQUMzRDtBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxNQUFNLFFBQVEsTUFBTTtBQUNuQyxNQUFJLENBQUMsZ0JBQWdCLE1BQU0sTUFBTSxFQUFHLFFBQU8sUUFBUSxFQUFFLE1BQU0sT0FBTztBQUNwRTtBQUVBLFNBQVMsbUJBQW1CLE1BQVksUUFBYztBQUNwRCxNQUFJLE9BQU8sU0FBUyxZQUFZLENBQUMsT0FBTyxRQUFRLENBQUMsV0FBVyxPQUFPLEtBQUssS0FBSyxPQUFPLFlBQVksVUFBVSxDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUUsU0FBUyxPQUFPLE1BQU0sSUFBSSxFQUFHLFFBQU87QUFDaEssUUFBTSxPQUFLLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLE9BQU8sS0FBTSxVQUFVLEtBQUssVUFBUSxPQUFPLFNBQVMsS0FBSyxLQUFHLENBQUM7QUFDeEcsTUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLElBQUksS0FBSyxDQUFDLGdCQUFnQixNQUFLLElBQUksS0FBSyxZQUFZLE1BQUssT0FBTyxLQUFLLEVBQUUsT0FBSyxFQUFHLFFBQU87QUFDaEgsaUJBQWUsTUFBSyxRQUFPLElBQUk7QUFDL0IsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQVksUUFBYyxRQUFjO0FBQzlELE1BQUksT0FBTyxTQUFTLFlBQVksQ0FBQyxXQUFXLE9BQU8sS0FBSyxLQUFLLE9BQU8sVUFBVSxPQUFPLFNBQVMsQ0FBQyxnQkFBZ0IsTUFBTSxNQUFNLEVBQUc7QUFDOUgsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLFNBQVMsWUFBWSxNQUFNLE9BQU8sS0FBSztBQUM3QyxNQUFJLE9BQU8sT0FBTyxFQUFHO0FBQ3JCLGlCQUFlLE1BQU0sUUFBUSxNQUFNO0FBQ25DLFFBQU0sU0FBUyxvQkFBb0IsTUFBTSxNQUFNO0FBQy9DLFlBQVUsTUFBTSxPQUFPLE9BQU8sQ0FBQztBQUMvQixNQUFJLFlBQVksTUFBTSxFQUFHLGlCQUFnQixNQUFLLFFBQU8sTUFBTTtBQUFBLE1BQ3RELFFBQU8sS0FBSyxLQUFLLElBQUksT0FBTyxPQUFPLE9BQU8sS0FBSyxNQUFNO0FBQzFELFNBQU8sV0FBVyxRQUFRLFNBQVMsb0JBQW9CO0FBQ3pEO0FBRUEsU0FBUyxlQUFlLE1BQVksUUFBYyxRQUF5QjtBQUN6RSxNQUFJLEtBQUssUUFBUSxLQUFLLFlBQVUsT0FBTyxTQUFTLFlBQVksT0FBTyxXQUFXLE9BQU8sRUFBRSxFQUFHO0FBRzFGLE9BQUssUUFBUSxLQUFLO0FBQUEsSUFBRSxJQUFJLFFBQVEsT0FBTyxFQUFFLElBQUksS0FBSyxJQUFJO0FBQUEsSUFBSSxNQUFNO0FBQUEsSUFBVSxHQUFFLE9BQU87QUFBQSxJQUFHLEdBQUUsT0FBTztBQUFBLElBQzdGLFVBQVMsUUFBUSxJQUFJO0FBQUEsSUFBRyxXQUFVLFFBQVEsSUFBSTtBQUFBLElBQUcsUUFBTyxPQUFPO0FBQUEsSUFBSSxPQUFNLE9BQU87QUFBQSxJQUFHLE9BQU0sT0FBTztBQUFBLEVBQUUsQ0FBQztBQUN2RztBQUVBLFNBQVMsbUJBQW1CLE1BQVksTUFBWSxVQUFvQjtBQUN0RSxNQUFJLENBQUMsV0FBVyxLQUFLLEtBQUssRUFBRyxRQUFPO0FBQ3BDLFFBQU0sUUFBUSxLQUFLO0FBQ25CLFFBQU0sU0FBUyxZQUFZLE1BQU0sS0FBSztBQUN0QyxNQUFJLE9BQU8sT0FBTyxLQUFLLFNBQVMsTUFBTSxTQUFTLE1BQU8sUUFBTztBQUM3RCxRQUFNLGlCQUFpQixLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sY0FBYyxTQUFTLElBQUksRUFBRSxPQUFPLHlCQUF5QixDQUFDO0FBQzVHLFFBQU0sWUFBWSxLQUFLLElBQUksR0FBRyxTQUFTLFFBQVEsY0FBYztBQUM3RCxZQUFVLE1BQU0sT0FBTyxDQUFDO0FBQ3hCLFdBQVMsS0FBSyxLQUFLLElBQUksU0FBUyxPQUFPLFNBQVMsS0FBSyxTQUFTO0FBQzlELE9BQUssV0FBVyxRQUFRLFlBQVksb0JBQW9CO0FBQ3hELGlCQUFlLE1BQU0sTUFBTSxRQUFRO0FBQ25DLHdCQUFzQixNQUFNLFFBQVE7QUFDcEMsU0FBTztBQUNUO0FBRUEsU0FBUyxzQkFBc0IsTUFBWSxVQUFvQixTQUFTLE9BQU87QUFDN0UsUUFBTSxhQUFhLFNBQVMsQ0FBQyxVQUFVLGNBQWMsSUFBSSxDQUFDLFFBQVE7QUFDbEUsTUFBSSxLQUFLLFFBQVEsS0FBSyxDQUFDLFdBQVcsV0FBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxNQUFNLFNBQVMsQ0FBQyxFQUFHO0FBQzNILFlBQVUsTUFBTSxTQUFTLGlCQUFpQixVQUFVLFNBQVMsR0FBRyxTQUFTLEdBQUcsK0JBQStCLEVBQUUsT0FBTyxTQUFTLE1BQU0sQ0FBQztBQUN0STtBQUVBLFNBQVMsY0FBYyxNQUFZLFVBQW9CLFVBQTZCO0FBQ2xGLE1BQUksQ0FBQyxTQUFTLFNBQVUsT0FBTSxJQUFJLE1BQU0sZ0NBQWdDLFNBQVMsSUFBSSxFQUFFO0FBQ3ZGLE1BQUksQ0FBQyxXQUFXLFlBQVksTUFBTSxTQUFTLEtBQUssRUFBRSxNQUFNLFNBQVMsTUFBTSxRQUFRLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxTQUFTLElBQUksaUJBQWlCLFFBQVEsUUFBUSxZQUFZLE1BQU0sU0FBUyxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQzNMLFFBQU0sTUFBTSxrQkFBa0IsUUFBUTtBQUN0QyxNQUFJLFlBQVksTUFBTSxTQUFTLEtBQUssRUFBRSxZQUFZLElBQUssT0FBTSxJQUFJLE1BQU0sd0JBQXdCLEdBQUcsYUFBYSxRQUFRLEVBQUU7QUFDekgsTUFBSSxvQkFBb0IsTUFBTSxTQUFTLEtBQUssSUFBSSxVQUFVLFFBQVEsRUFBRSxhQUFhLFlBQVksTUFBTSxTQUFTLEtBQUssRUFBRSxXQUFXO0FBQzVILFVBQU0sSUFBSSxNQUFNLDZCQUE2QixRQUFRLEVBQUU7QUFBQSxFQUN6RDtBQUNBLFlBQVUsTUFBTSxTQUFTLE9BQU8sVUFBVSxRQUFRLEVBQUUsSUFBSTtBQUN4RCxXQUFTLE1BQU0sS0FBSyxFQUFFLElBQUksWUFBWSxLQUFLLFFBQVEsSUFBSSxVQUFVLFdBQVcsYUFBYSxRQUFRLEdBQUcsVUFBUyxVQUFVLFFBQVEsRUFBRSxLQUFLLENBQUM7QUFDdkksb0JBQWtCLElBQUk7QUFDeEI7QUFFQSxTQUFTLFNBQVMsTUFBWSxPQUFpQixhQUF1QixHQUFXLEdBQVcsUUFBaUM7QUFDM0gsUUFBTSxZQUFZLGVBQWUsTUFBTSxhQUFhLEtBQUs7QUFDekQsUUFBTSxhQUFhLHFCQUFxQixNQUFNLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFDakUsYUFBVyxZQUFZLFdBQVc7QUFDaEMsUUFBSSxjQUFjLFNBQVMsSUFBSSxFQUFFLE9BQU8sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsU0FBUyxJQUFJLDhCQUE4QjtBQUNwSCxhQUFTLFNBQVMsV0FBVztBQUM3QixhQUFTLFNBQVMsV0FBVztBQUM3QixhQUFTLGNBQWMsV0FBVztBQUFBLEVBQ3BDO0FBQ0EsWUFBVSxNQUFNLFFBQVEsV0FBVyxHQUFHLFdBQVcsR0FBRyxJQUFJLEVBQUUsTUFBTSxDQUFDO0FBQ25FO0FBRUEsU0FBUyxxQkFBcUIsTUFBWSxPQUFpQixHQUFXLEdBQVcsUUFBaUM7QUFDaEgsTUFBSSxDQUFDLFVBQVUsT0FBTyxTQUFTLFNBQVM7QUFDdEMsV0FBTyxFQUFFLEdBQUcsTUFBTSxHQUFHLEdBQUcsS0FBSyxJQUFJLEtBQUssR0FBRyxHQUFHLE1BQU0sR0FBRyxHQUFHLEtBQUssSUFBSSxNQUFNLEdBQUcsUUFBUSxFQUFFLE1BQU0sUUFBUSxFQUFpQjtBQUFBLEVBQ3JIO0FBQ0EsTUFBSSxPQUFPLFNBQVMsWUFBWTtBQUM5QixVQUFNLFdBQVcsS0FBSyxVQUFVLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxPQUFPLFVBQVU7QUFDdEYsUUFBSSxDQUFDLFNBQVUsT0FBTSxJQUFJLE1BQU0sMEJBQTBCLE9BQU8sVUFBVSxFQUFFO0FBQzVFLFdBQU8sRUFBRSxHQUFHLFNBQVMsR0FBRyxHQUFHLFNBQVMsR0FBRyxPQUFPO0FBQUEsRUFDaEQ7QUFDQSxRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxPQUFPLFVBQVUsVUFBVSxVQUFVLEtBQUs7QUFDdkcsTUFBSSxDQUFDLEtBQU0sT0FBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLGVBQWUsT0FBTyxNQUFNLEVBQUU7QUFDekUsU0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLE9BQU87QUFDeEM7QUFFQSxTQUFTLGtCQUFrQixNQUFZLFVBQW9CLE1BQTJCO0FBQ3BGLFFBQU0sU0FBUyxTQUFTO0FBQ3hCLE1BQUksUUFBUSxTQUFTLGNBQWMsS0FBSyxTQUFTLFlBQVksS0FBSyxVQUFVLEtBQUssQ0FBQyxhQUFhLFNBQVMsT0FBTyxPQUFPLGNBQWMsU0FBUyxTQUFTLENBQUMsR0FBRztBQUN4SixXQUFPLEVBQUUsTUFBTSxRQUFRLFlBQVksT0FBTyxZQUFZLE9BQU8sVUFBVSxPQUFPLEVBQUU7QUFBQSxFQUNsRjtBQUNBLE1BQUksUUFBUSxTQUFTLFVBQVUsS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxPQUFPLFVBQVUsVUFBVSxVQUFVLEtBQUssU0FBUyxVQUFVLEtBQUssQ0FBQyxHQUFHO0FBQ25KLFdBQU8sRUFBRSxNQUFNLFVBQVUsVUFBVSxPQUFPLE9BQU87QUFBQSxFQUNuRDtBQUNBLFNBQU8sRUFBRSxNQUFNLFFBQVEsR0FBRyxTQUFTLFFBQVEsR0FBRyxTQUFTLE9BQU87QUFDaEU7QUFFQSxTQUFTLGNBQWMsTUFBWSxVQUFvQixhQUEwQjtBQUMvRSxNQUFJLENBQUMsU0FBUyxTQUFVLE9BQU0sSUFBSSxNQUFNLG1DQUFtQyxTQUFTLElBQUksRUFBRTtBQUMxRixRQUFNLFVBQVUsYUFBYSxXQUFXO0FBQ3hDLE1BQUksQ0FBQyxRQUFTLE9BQU0sSUFBSSxNQUFNLG1CQUFtQixXQUFXLEVBQUU7QUFDOUQsTUFBSSxDQUFDLFVBQVUsWUFBWSxNQUFNLFNBQVMsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLFNBQVMsV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsWUFBWSxNQUFNLFNBQVMsS0FBSyxFQUFFLElBQUkseUJBQXlCLFdBQVcsRUFBRTtBQUN0TCxNQUFJLENBQUMsY0FBYyxZQUFZLE1BQU0sU0FBUyxLQUFLLEVBQUUsTUFBTSxTQUFTLE1BQU0sV0FBVyxHQUFHO0FBQ3RGLFVBQU0sSUFBSSxNQUFNLEdBQUcsU0FBUyxJQUFJLG9CQUFvQixXQUFXLEVBQUU7QUFBQSxFQUNuRTtBQUNBLFFBQU0sU0FBUyxZQUFZLE1BQU0sU0FBUyxLQUFLO0FBQy9DLFFBQU0sZUFBZSxPQUFPLFNBQVMsV0FBVyxLQUFLO0FBQ3JELE1BQUksZ0JBQWdCLGdCQUFnQixXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxXQUFXLHVCQUF1QjtBQUN2RyxNQUFJLFNBQVMsY0FBYyxLQUFLLENBQUMsUUFBUSxJQUFJLGdCQUFnQixXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxXQUFXLG9CQUFvQjtBQUM3SCxRQUFNLGNBQWMsZUFBZTtBQUNuQyxRQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWMsQ0FBQztBQUM1QyxNQUFJLENBQUMsTUFBTyxPQUFNLElBQUksTUFBTSxHQUFHLFdBQVcsa0JBQWtCLFdBQVcsRUFBRTtBQUN6RSxZQUFVLE1BQU0sU0FBUyxPQUFPLE1BQU0sSUFBSTtBQUMxQyxXQUFTLGNBQWMsS0FBSyxFQUFFLGFBQWEsYUFBYSxXQUFXLE1BQU0sYUFBYSxDQUFDO0FBQ3pGO0FBRUEsU0FBUyxpQkFBaUIsTUFBWSxPQUFpQixhQUEwQixhQUFxQjtBQUNwRyxRQUFNLFNBQVMsWUFBWSxNQUFNLEtBQUs7QUFDdEMsUUFBTSxlQUFlLE9BQU8sU0FBUyxXQUFXLEtBQUs7QUFDckQsTUFBSSxlQUFlLGFBQWM7QUFDakMsTUFBSSxnQkFBZ0IsZUFBZSxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsV0FBVyxrQ0FBa0M7QUFDdEcsU0FBTyxTQUFTLFdBQVcsSUFBSTtBQUMvQixhQUFXLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxjQUFjLFVBQVUsVUFBVSxLQUFLLEdBQUc7QUFDOUUsNEJBQXdCLE1BQU0sTUFBTSxhQUFhLFdBQVc7QUFBQSxFQUM5RDtBQUNBLGFBQVcsWUFBWSxLQUFLLFVBQVUsT0FBTyxDQUFDLGNBQWMsVUFBVSxVQUFVLEtBQUssR0FBRztBQUN0RixnQ0FBNEIsTUFBTSxVQUFVLGFBQWEsV0FBVztBQUFBLEVBQ3RFO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUFZLE1BQVk7QUFDakQsTUFBSSxDQUFDLFdBQVcsS0FBSyxLQUFLLEVBQUc7QUFDN0Isd0JBQXNCLE1BQU0sSUFBSTtBQUNsQztBQUVBLFNBQVMsd0JBQXdCLE1BQVksTUFBWSxhQUEwQixPQUFlO0FBQ2hHLFFBQU0sVUFBVSxhQUFhLFdBQVc7QUFDeEMsUUFBTSxXQUFXLFFBQVEsT0FBTyxRQUFRLENBQUM7QUFDekMsTUFBSSxDQUFDLFNBQVUsT0FBTSxJQUFJLE1BQU0sR0FBRyxXQUFXLGtCQUFrQixLQUFLLEVBQUU7QUFDdEUsTUFBSSxDQUFDLFFBQVEsa0JBQWtCLFNBQVMsS0FBSyxJQUF5QixFQUFHO0FBQ3pFLHdCQUFzQixNQUFNLElBQUk7QUFDbEM7QUFFQSxTQUFTLDRCQUE0QixNQUFZLFVBQW9CLGFBQTBCLE9BQWU7QUFDNUcsUUFBTSxVQUFVLGFBQWEsV0FBVztBQUN4QyxRQUFNLFdBQVcsUUFBUSxPQUFPLFFBQVEsQ0FBQztBQUN6QyxNQUFJLENBQUMsU0FBVSxPQUFNLElBQUksTUFBTSxHQUFHLFdBQVcsa0JBQWtCLEtBQUssRUFBRTtBQUN0RSxNQUFJLENBQUMsU0FBUyx3QkFBeUI7QUFDdkMsNEJBQTBCLE1BQU0sUUFBUTtBQUMxQztBQUVBLFNBQVMsMEJBQTBCLE1BQVksVUFBb0I7QUFDakUsUUFBTSxnQkFBZ0IsU0FBUztBQUMvQixRQUFNLE1BQU0sY0FBYyxTQUFTLElBQUk7QUFDdkMsTUFBSSxRQUFRLElBQUk7QUFDaEIsYUFBVyxlQUFlLGVBQWU7QUFDdkMsVUFBTSxlQUFlLFlBQVksTUFBTSxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsS0FBSztBQUNoRixhQUFTLFFBQVEsR0FBRyxRQUFRLGNBQWMsU0FBUyxHQUFHO0FBQ3BELFlBQU0sV0FBVyxhQUFhLFdBQVcsRUFBRSxPQUFPLEtBQUs7QUFDdkQsVUFBSSxDQUFDLFVBQVUsd0JBQXlCO0FBQ3hDLGNBQVEsS0FBSyxNQUFNLFFBQVEsU0FBUyx1QkFBdUI7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDQSxXQUFTLFFBQVE7QUFDakIsV0FBUyxLQUFLLEtBQUssSUFBSSxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUyxLQUFLLFNBQVMsUUFBUSxhQUFhLENBQUM7QUFDaEcsV0FBUyxlQUFlLElBQUk7QUFDNUIsV0FBUyxjQUFjLElBQUk7QUFDM0IsV0FBUyxpQkFBaUIsSUFBSTtBQUNoQztBQUVBLFNBQVMsY0FBYyxNQUFZLE9BQWlCLFFBQWdCO0FBQ2xFLFFBQU0sT0FBTyxLQUFLLGVBQWUsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE1BQU07QUFDNUUsTUFBSSxDQUFDLEtBQU0sT0FBTSxJQUFJLE1BQU0sMEJBQTBCLE1BQU0sRUFBRTtBQUM3RCxNQUFJLEtBQUssU0FBUyxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxFQUFFLHlCQUF5QjtBQUN4RSxNQUFJLEtBQUssb0JBQW9CLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLEVBQUUsZ0JBQWdCO0FBQzFFLE1BQUksQ0FBQywrQkFBK0IsTUFBTSxPQUFPLElBQUksRUFBRyxPQUFNLElBQUksTUFBTSxHQUFHLEtBQUssRUFBRSw2Q0FBNkM7QUFDL0gsTUFBSSxDQUFDLFVBQVUsTUFBTSxPQUFPLEtBQUssUUFBUSxFQUFHLE9BQU0sSUFBSSxNQUFNLDRCQUE0QixLQUFLLFFBQVEsRUFBRTtBQUN2RyxZQUFVLE1BQU0sT0FBTyxLQUFLLElBQUk7QUFDaEMsT0FBSyxTQUFTO0FBQ2QsT0FBSyxvQkFBb0IsS0FBSztBQUM5QixRQUFNLFNBQVMsVUFBVSxXQUFXLENBQUMsS0FBSyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxZQUFZLEtBQUssVUFBVSxPQUFPLEtBQUssVUFBVSxLQUFLLElBQUksUUFBUSxLQUFLLENBQUM7QUFDOUUsWUFBVSxNQUFNLFVBQVUsS0FBSyxHQUFHLEtBQUssR0FBRyxFQUFFO0FBQzVDLG9CQUFrQixJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLFNBQVMsUUFBUSxNQUFZLE9BQWlCLFFBQWdCLE1BQXlCLGFBQXFCO0FBQzFHLFFBQU0sVUFBVSxXQUFXLE1BQU0sT0FBTyxRQUFRLE1BQU0sV0FBVztBQUNqRSxNQUFJLFFBQVMsT0FBTSxJQUFJLE1BQU0sUUFBUSxPQUFPO0FBQzVDLFFBQU0sT0FBTyxLQUFLLE1BQU8sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE1BQU07QUFDcEUsUUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsY0FBYyxVQUFVLFNBQVMsSUFBSTtBQUNuRSxRQUFNLFdBQVMsZ0JBQWMsU0FBWSxrQkFBa0IsTUFBSyxPQUFNLE1BQUssTUFBSyxXQUFXLElBQUk7QUFDL0YsTUFBRyxZQUFZLGFBQWEsU0FBUyxPQUFNLElBQUksTUFBTSxTQUFTLE9BQU87QUFDckUsWUFBVSxNQUFNLE9BQU8sS0FBSyxJQUFJO0FBQ2hDLE9BQUssU0FBUztBQUNkLE1BQUksS0FBSyxvQkFBb0IsRUFBRyxNQUFLLG1CQUFtQixLQUFLO0FBQzdELFFBQU0sT0FBa0IsRUFBRSxJQUFJLFFBQVEsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixFQUFFO0FBQzFJLE9BQUssVUFBVTtBQUNmLE9BQUssTUFBTSxLQUFLLElBQUk7QUFDcEIsTUFBRyxZQUFZLGVBQWUsU0FBUyxpQkFBZ0IsTUFBSyxNQUFLLFNBQVMsU0FBUztBQUFBLE9BQzlFO0FBRUgsVUFBTSxRQUFRLFVBQVUsTUFBTSxPQUFPLE1BQUssSUFBSTtBQUM5QyxRQUFJLE1BQU8sa0JBQWlCLE1BQU0sTUFBTSxLQUFLO0FBQzdDLGNBQVUsTUFBTSxVQUFVLEtBQUssR0FBRyxLQUFLLEdBQUcsRUFBRTtBQUFBLEVBQzlDO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsTUFBVSxNQUFlLFdBQTRCO0FBQzVFLFFBQU0sWUFBVSxLQUFLLE1BQU0sS0FBSyxVQUFNLEtBQUssUUFBTSxZQUFZLFlBQVksVUFBVSxTQUFTLFVBQVUsT0FBTztBQUM3RyxNQUFHLFlBQVksV0FBVTtBQUFDLFNBQUssWUFBVSxVQUFVO0FBQUcsU0FBSyxPQUFLLFVBQVU7QUFBQSxFQUFLLE9BQzFFO0FBQUMsU0FBSyxTQUFPLFVBQVU7QUFBRyxTQUFLLFdBQVMsVUFBVTtBQUFBLEVBQUs7QUFDNUQsT0FBSyxJQUFFLFVBQVU7QUFBRSxPQUFLLElBQUUsVUFBVTtBQUNwQyxzQkFBb0IsS0FBSyxLQUFLO0FBQzlCLHdCQUFzQixNQUFLLFNBQVM7QUFBRSx1QkFBcUIsSUFBSTtBQUMvRCxZQUFVLE1BQUssZ0JBQWUsVUFBVSxHQUFFLFVBQVUsR0FBRSxRQUFRLEdBQUUsR0FBRSxFQUFDLE9BQU0sVUFBVSxNQUFLLENBQUM7QUFDM0Y7QUFFQSxTQUFTLCtCQUErQixNQUFZLE9BQWlCLE1BQWdEO0FBQ25ILFNBQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssVUFBVSxTQUFTLDBCQUEwQixNQUFNLElBQUksQ0FBQztBQUNoRztBQUVBLFNBQVMsc0JBQXNCLE1BQVksTUFBWTtBQUNyRCxNQUFJLEtBQUssTUFBTSxTQUFTLGFBQWM7QUFDdEMsUUFBTSxTQUFTLEtBQUssTUFBTTtBQUMxQixRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFNO0FBQ25FLE1BQUksQ0FBQyxRQUFRLEtBQUssYUFBYSxLQUFLLFFBQVE7QUFDMUMsU0FBSyxRQUFRLEVBQUUsTUFBTSxPQUFPO0FBQzVCO0FBQUEsRUFDRjtBQUNBLE1BQUksU0FBUyxNQUFNLElBQUksSUFBSSxtQkFBbUI7QUFDNUMsZUFBVyxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSztBQUNyRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGFBQWEsTUFBSyxNQUFLLEtBQUssSUFBSSxFQUFHLGtCQUFpQixNQUFNLE1BQU0sSUFBSTtBQUN4RSxPQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDOUI7QUFFQSxTQUFTLFdBQVcsTUFBWSxPQUFpQixRQUFnQixRQUFnQixTQUFTLE9BQU87QUFDL0YsUUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsY0FBYyxVQUFVLE9BQU8sVUFBVSxVQUFVLFVBQVUsS0FBSztBQUNoRyxNQUFJLENBQUMsS0FBTSxPQUFNLElBQUksTUFBTSxXQUFXLEtBQUssaUJBQWlCLE1BQU0sRUFBRTtBQUNwRSxRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFNO0FBQ25FLE1BQUksQ0FBQyxLQUFNLE9BQU0sSUFBSSxNQUFNLGdCQUFnQixNQUFNLEVBQUU7QUFDbkQsTUFBSSxLQUFLLGFBQWEsS0FBSyxPQUFRLE9BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxFQUFFLHFCQUFxQjtBQUNsRixNQUFJLFVBQVUsS0FBSyxJQUFJLE1BQU0sTUFBTyxPQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0UsTUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsYUFBYSxNQUFLLE1BQUssS0FBSyxJQUFJLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLEVBQUUsaUNBQWlDO0FBQ3RILE1BQUksU0FBUyxNQUFNLElBQUksSUFBSSxtQkFBbUI7QUFDNUMsb0JBQWdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsT0FBTyxHQUFHLE1BQU07QUFDNUQ7QUFBQSxFQUNGO0FBQ0EsbUJBQWlCLE1BQU0sTUFBTSxJQUFJO0FBQ25DO0FBRUEsU0FBUyxpQkFBaUIsTUFBWSxNQUFpQixNQUFZO0FBQ2pFLFFBQU0sT0FBSyxhQUFhLE1BQUssTUFBSyxLQUFLLElBQUk7QUFBRSxNQUFHLENBQUMsS0FBSztBQUN0RCxPQUFLLE9BQUs7QUFDVixPQUFLLFlBQVksS0FBSztBQUN0QixTQUFPLEtBQUs7QUFDWixzQkFBb0IsS0FBSyxLQUFLO0FBQzlCLE9BQUssSUFBSSxLQUFLO0FBQ2QsT0FBSyxJQUFJLEtBQUs7QUFFZCxNQUFJLFdBQVcsS0FBSyxLQUFLLEVBQUcsdUJBQXNCLE1BQU0sSUFBSTtBQUM1RCx1QkFBcUIsSUFBSTtBQUMzQjtBQUVBLFNBQVMsU0FBUyxNQUFZLE9BQWlCLFFBQWdCLFFBQWdCLEdBQVcsR0FBVztBQUNuRyxRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxVQUFVLFVBQVUsVUFBVSxLQUFLO0FBQ2hHLE1BQUksQ0FBQyxLQUFNLE9BQU0sSUFBSSxNQUFNLFdBQVcsS0FBSyxpQkFBaUIsTUFBTSxFQUFFO0FBQ3BFLFFBQU0sVUFBVSxZQUFZLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFDdkQsTUFBSSxRQUFTLE9BQU0sSUFBSSxNQUFNLE9BQU87QUFDcEMsUUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUFSLFVBQVFBLE1BQUssT0FBTyxNQUFNO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFBTSxVQUFRQSxNQUFLLE9BQU8sS0FBSyxNQUFNO0FBQzVELFNBQU8sS0FBSztBQUFVLFNBQU8sS0FBSztBQUFLLFNBQU8sS0FBSztBQUFPLFNBQU8sS0FBSztBQUFTLFNBQU8sS0FBSztBQUFRLGtCQUFnQixNQUFLLEtBQUssRUFBRTtBQUMvSCxNQUFJLEtBQU0scUJBQW9CLE1BQU0sSUFBSTtBQUN4QyxzQkFBb0IsS0FBSyxLQUFLO0FBQzlCLE9BQUssSUFBSSxNQUFNLEdBQUcsR0FBRyxLQUFLLElBQUksS0FBSztBQUNuQyxPQUFLLElBQUksTUFBTSxHQUFHLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDcEMsb0JBQWtCLEtBQUssT0FBTSxLQUFLLE9BQU0sS0FBSyxHQUFHO0FBQ2hELE1BQUksV0FBVyxLQUFLLEtBQUssRUFBRyx1QkFBc0IsTUFBTSxJQUFJO0FBQzVELHVCQUFxQixJQUFJO0FBQzNCO0FBRUEsU0FBUyxRQUNQLE1BQ0EsT0FDQSxRQUNBLFFBQ0EsVUFDQSxHQUNBLEdBQ0E7QUFDQSxRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxVQUFVLFVBQVUsVUFBVSxLQUFLO0FBQ2hHLE1BQUksQ0FBQyxLQUFNLE9BQU0sSUFBSSxNQUFNLFdBQVcsS0FBSyxjQUFjLE1BQU0sRUFBRTtBQUNqRSxRQUFNLE9BQU8sWUFBWSxNQUFNLE1BQU0sTUFBTTtBQUMzQyxRQUFNLGdCQUFjLEtBQUssUUFBUSxFQUFDLEdBQUcsS0FBSyxNQUFLLElBQUk7QUFDbkQsTUFBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLEVBQUUsV0FBVyxDQUFDLGFBQWEsTUFBSyxNQUFLLElBQUksR0FBRTtBQUFDLFNBQUssVUFBUSxDQUFDO0FBQUUsb0JBQWdCLE1BQUssS0FBSyxFQUFFO0FBQUUsU0FBSyxNQUFNLFFBQU0sS0FBSztBQUFHLFFBQUcsVUFBVSxJQUFJLE1BQUksRUFBRSxRQUFPLEtBQUssTUFBTTtBQUFLLFNBQUssTUFBSTtBQUFVLDBCQUFzQixNQUFLLElBQUk7QUFBQSxFQUFFO0FBQzVPLGVBQWEsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLENBQUM7QUFDN0MsTUFBRyxpQkFBaUIsQ0FBQyxLQUFLLE1BQU0sS0FBSyxlQUFXLFVBQVUsT0FBSyxLQUFLLEVBQUUsR0FBRTtBQUFDLFNBQUssUUFBTTtBQUFjLDBCQUFzQixNQUFLLElBQUk7QUFBQSxFQUFFO0FBQ3JJO0FBRUEsU0FBUyxZQUNQLE1BQ0EsT0FDQSxRQUNBLFNBQ0EsVUFDQSxHQUNBLEdBQ0EsU0FBUyxPQUNUO0FBQ0EsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sVUFBVSxLQUFLLFVBQVUsS0FBSztBQUNuRixNQUFJLENBQUMsVUFBVSxPQUFPLE1BQU0sRUFBRyxPQUFNLElBQUksTUFBTSxXQUFXLEtBQUssV0FBVyxNQUFNLEVBQUU7QUFDbEYsTUFBSSxVQUFVLE1BQU0sRUFBRyxPQUFNLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxhQUFhO0FBQ2xFLE1BQUksQ0FBQyxjQUFjLE1BQU0sRUFBRSxTQUFTLE9BQU8sRUFBRyxPQUFNLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxFQUFFO0FBQ3JHLE1BQUksZ0JBQWdCLFFBQVEsT0FBTyxJQUFJLEVBQUcsT0FBTSxJQUFJLE1BQU0sR0FBRyxPQUFPLElBQUksaUJBQWlCO0FBQ3pGLFFBQU0sTUFBTSxhQUFhLE9BQU87QUFDaEMsTUFBSSxJQUFJLGFBQWEsV0FBVztBQUM5QixRQUFJLE9BQVEsaUJBQWdCLFFBQVEsRUFBRSxNQUFNLFFBQVEsUUFBUSxHQUFHLElBQUk7QUFBQSxRQUM5RCxxQkFBb0IsTUFBTSxRQUFRLEtBQUssS0FBSztBQUNqRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGNBQWMsV0FBVyxpQkFBaUIsTUFBTSxRQUFRLElBQUk7QUFDbEUsTUFBSSxlQUFlLE9BQU8sV0FBVyxLQUFLLENBQUMsa0JBQWtCLGFBQWEsSUFBSSxTQUFTLElBQUksR0FBRztBQUM1RixVQUFNLElBQUksTUFBTSxJQUFJLGFBQWEsU0FBUyw0Q0FBNEMsdUNBQXVDO0FBQUEsRUFDL0g7QUFFQSxRQUFNLFFBQVEsQ0FBQyxPQUE2QyxPQUFpQztBQUMzRixvQkFBZ0IsUUFBUSxPQUFPLE1BQU07QUFDckMsY0FBVSxNQUFNLFNBQVMsZUFBZSxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsU0FBUyxLQUFLLElBQUksRUFBRSxNQUFNLENBQUM7QUFBQSxFQUN6RjtBQUVBLE1BQUksSUFBSSxhQUFhLFVBQVU7QUFDN0IsVUFBTSxTQUFTLFdBQVcsaUJBQWlCLE1BQU0sUUFBUSxJQUFJO0FBQzdELFFBQUksSUFBSSxXQUFXLFlBQVksQ0FBQyxVQUFVLENBQUMsZUFBZSxNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUksT0FBTSxJQUFJLE1BQU0sdUNBQXVDO0FBQzlJLFVBQU0sUUFBUSxXQUFXLFNBQVMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUk7QUFDakUsUUFBSSxDQUFDLE1BQU8sT0FBTSxJQUFJLE1BQU0sc0NBQXNDO0FBQ2xFLFFBQUksSUFBSSxPQUFPLFlBQVksU0FBUyxRQUFRLEtBQUssSUFBSSxJQUFJLE9BQU8sU0FBVSxPQUFNLElBQUksTUFBTSxvQ0FBb0M7QUFDOUgsUUFBSSxVQUFVLFdBQVcsT0FBTyxJQUFJLEtBQUssY0FBYyxVQUFVLE1BQU0sTUFBTSxDQUFDLEtBQUssU0FBUyxRQUFRLEtBQUssSUFBSSxJQUFJLFNBQVMsVUFBVSxDQUFDLE9BQU8sTUFBTSxJQUFJLE9BQU8sU0FBUyxHQUFJLE9BQU0sRUFBQyxNQUFLLFFBQU8sU0FBUSxHQUFJLFNBQVMsRUFBQyxVQUFTLE9BQU8sR0FBRSxJQUFJLEVBQUMsR0FBRSxNQUFNLEdBQUUsR0FBRSxNQUFNLEVBQUMsRUFBRSxHQUFFLEtBQUs7QUFBQSxRQUNqUSxvQkFBbUIsTUFBSyxRQUFPLFNBQVEsT0FBTSxLQUFJLFFBQVEsRUFBRTtBQUNoRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLElBQUksYUFBYSxRQUFRO0FBQzNCLFVBQU0sU0FBUyxXQUFXLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sWUFBWSxDQUFDLGVBQWUsTUFBTSxLQUFLLE9BQU8sS0FBSyxDQUFDLElBQUk7QUFDeEgsUUFBSSxDQUFDLE9BQVEsT0FBTSxJQUFJLE1BQU0scUNBQXFDO0FBQ2xFLFFBQUksQ0FBQyxrQkFBa0IsUUFBUSxJQUFJLEVBQUcsT0FBTSxJQUFJLE1BQU0seUNBQXlDO0FBQy9GLFFBQUksVUFBVSxTQUFTLFFBQVEsTUFBTSxJQUFJLElBQUksTUFBTyxPQUFNLEVBQUUsTUFBTSxRQUFRLFNBQVMsVUFBVSxPQUFPLEdBQUcsR0FBRyxNQUFNO0FBQUEsUUFDM0csV0FBVSxNQUFNLFFBQVEsU0FBUyxRQUFRLEdBQUc7QUFDakQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxJQUFJLGFBQWEsU0FBUztBQUM1QixVQUFNLFNBQVMsV0FBVyxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLFlBQVksZUFBZSxNQUFNLEtBQUssT0FBTyxLQUFLLENBQUMsSUFBSTtBQUN2SCxRQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSxxQ0FBcUM7QUFDbEUsUUFBSSxVQUFVLFNBQVMsUUFBUSxNQUFNLElBQUksSUFBSSxNQUFPLE9BQU0sRUFBRSxNQUFNLFFBQVEsU0FBUyxVQUFVLE9BQU8sR0FBRyxHQUFHLE1BQU07QUFBQSxRQUMzRyxZQUFXLE1BQU0sUUFBUSxTQUFTLFFBQVEsR0FBRztBQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLElBQUksYUFBYSxVQUFVO0FBQzdCLFVBQU0sU0FBUyxXQUFXLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sWUFBWSxlQUFlLE1BQU0sS0FBSyxPQUFPLEtBQUssQ0FBQyxJQUFJO0FBQ3ZILFFBQUksQ0FBQyxPQUFRLE9BQU0sSUFBSSxNQUFNLHNDQUFzQztBQUNuRSxRQUFJLFNBQVMsUUFBUSxNQUFNLElBQUksSUFBSSxTQUFVLE9BQU0sSUFBSSxNQUFNLGtDQUFrQyxJQUFJLFFBQVEsT0FBTztBQUNsSCxRQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssUUFBUSxRQUFRLEtBQUssS0FBSyxFQUFHLE9BQU0sSUFBSSxNQUFNLCtCQUErQjtBQUNwRyxRQUFJLFVBQVUsU0FBUyxRQUFRLE1BQU0sSUFBSSxJQUFJLE1BQU8sT0FBTSxFQUFFLE1BQU0sUUFBUSxTQUFTLFVBQVUsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUFBLFFBQzNHLGFBQVksTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLLElBQUk7QUFDekQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxJQUFJLGFBQWEsU0FBVSxPQUFNLElBQUksTUFBTSxHQUFHLE9BQU8sNkJBQTZCO0FBQ3RGLE1BQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFHLE9BQU0sSUFBSSxNQUFNLGdDQUFnQztBQUNsRixNQUFJLFVBQVUsU0FBUyxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxJQUFJLE1BQU8sT0FBTSxFQUFFLE1BQU0sUUFBUSxTQUFTLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNoRyxhQUFZLE1BQU0sUUFBUSxTQUFTLEdBQUcsR0FBRyxHQUFHO0FBQ25EO0FBTUEsU0FBUyxnQkFBZ0IsTUFBWSxNQUFZO0FBQy9DLFFBQU0sUUFBUSxLQUFLO0FBQ25CLE1BQUksTUFBTSxTQUFTLE9BQVE7QUFDM0IsUUFBTSxNQUFNLGFBQWEsTUFBTSxPQUFPO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLGFBQWEsU0FBWSxTQUFZLGlCQUFpQixNQUFNLE1BQU0sUUFBUTtBQUMvRixRQUFNLE1BQU0sTUFBTTtBQUNoQixTQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFBQSxFQUM5QjtBQUVBLE1BQUksQ0FBQyxJQUFLLFFBQU8sSUFBSTtBQUNyQixNQUFJLElBQUksYUFBYSxXQUFXO0FBQzlCLFFBQUksY0FBYyxJQUFJLEVBQUUsU0FBUyxNQUFNLE9BQU8sS0FBSyxnQkFBZ0IsTUFBTSxNQUFNLE9BQU8sS0FBSyxFQUFHLHFCQUFvQixNQUFNLE1BQU0sS0FBSyxLQUFLO0FBQ3hJLFdBQU8sSUFBSTtBQUFBLEVBQ2I7QUFDQSxNQUFJLE1BQU0sYUFBYSxXQUFjLENBQUMsVUFBVSxPQUFPLE1BQU0sS0FBSyxlQUFlLE1BQU0sT0FBTyxPQUFPLEtBQUssS0FBSyxPQUFPLElBQUksYUFBYSxTQUFVLFFBQU8sSUFBSTtBQUM1SixNQUFJLFVBQVUsT0FBTyxNQUFNLEtBQUssQ0FBQyxrQkFBa0IsUUFBUSxJQUFJLFNBQVMsSUFBSSxFQUFHLFFBQU8sSUFBSTtBQUMxRixNQUFJLElBQUksYUFBYSxVQUFVLFdBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxDQUFDLGtCQUFrQixRQUFRLElBQUksR0FBSSxRQUFPLElBQUk7QUFDM0csUUFBTSxLQUFLLFdBQVcsU0FBUyxNQUFNLENBQUMsS0FBSyxTQUFTLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLEVBQUUsSUFBSTtBQUM1RixNQUFJLENBQUMsR0FBSSxRQUFPLElBQUk7QUFDcEIsTUFBSSxJQUFJLGFBQWEsWUFBWSxJQUFJLE9BQU8sWUFBWSxTQUFTLE1BQU0sRUFBRSxJQUFFLElBQUksT0FBTyxTQUFVLFFBQU8sSUFBSTtBQUMzRyxNQUFJLFNBQVMsTUFBTSxFQUFFLElBQUksSUFBSSxTQUFTLElBQUksYUFBYSxZQUFZLFVBQVUsQ0FBQyxPQUFPLE1BQU0sSUFBSSxPQUFPLFNBQVMsSUFBSTtBQUNqSCxlQUFXLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLO0FBRWpELFFBQUksVUFBVSxNQUFNLE1BQU0sSUFBSSxDQUFDLEVBQUcsS0FBSTtBQUN0QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxJQUFJLEVBQUcsUUFBTyxJQUFJO0FBQ3pELE1BQUksSUFBSSxhQUFhLFVBQVU7QUFDN0IsUUFBRyxNQUFNLFlBQVUscUJBQXFCLEtBQUssVUFBUztBQUNwRCxZQUFNLE9BQUssaUJBQWlCLE1BQUssSUFBSSxFQUFFLEtBQUssQ0FBQU4sVUFBTUEsTUFBSyxTQUFPLHFCQUFxQkEsTUFBSyxjQUFjLEtBQUcsQ0FBQztBQUMxRyxVQUFHLENBQUMsS0FBSyxRQUFPLElBQUk7QUFDcEIsVUFBRyxDQUFDLGNBQWMsTUFBSyxNQUFLLEVBQUUsR0FBRTtBQUFDLGNBQU0sUUFBTSxXQUFXLElBQUksRUFBRSxLQUFLLENBQUFJLFdBQU9BLE9BQU0sT0FBSyxLQUFLLE9BQU87QUFBRyx1QkFBZSxNQUFLLEtBQUssTUFBTSxHQUFHLElBQUUsS0FBSyxHQUFFLEdBQUcsSUFBRSxLQUFLLENBQUMsSUFBRSxNQUFNLFNBQVEsS0FBSyxLQUFJLEtBQUssS0FBSztBQUFFO0FBQUEsTUFBTztBQUN0TSxXQUFLLFNBQU8sS0FBSyxNQUFNLEdBQUcsSUFBRSxrQkFBa0IsTUFBSyxJQUFJLEVBQUcsTUFBTSxHQUFFLEdBQUcsSUFBRSxrQkFBa0IsTUFBSyxJQUFJLEVBQUcsTUFBTSxDQUFDO0FBQzVHLFlBQU0sUUFBTSxpQkFBaUIsTUFBSyxNQUFLLE1BQUssRUFBRTtBQUFFLFVBQUcsQ0FBQyxNQUFNO0FBQzFELHlCQUFtQixNQUFLLE1BQUssTUFBTSxTQUFRLElBQUcsS0FBSSxRQUFRLEVBQUU7QUFBRSxrQkFBWSxLQUFLO0FBQUUsVUFBSTtBQUFFO0FBQUEsSUFDekY7QUFDQSxRQUFJLENBQUMsTUFBTSxNQUFNLFlBQVksTUFBTSxJQUFJLEdBQUcsSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLE1BQU0sSUFBSSxDQUFDLEVBQUc7QUFDdkYsdUJBQW1CLE1BQUssTUFBSyxNQUFNLFNBQVEsSUFBRyxLQUFJLFFBQVEsRUFBRTtBQUM1RCxnQkFBWSxJQUFJO0FBQUEsRUFDbEIsV0FDUyxJQUFJLGFBQWEsVUFBVSxVQUFVLE9BQU8sTUFBTSxFQUFHLFdBQVUsTUFBTSxNQUFNLE1BQU0sU0FBUyxRQUFRLEdBQUc7QUFBQSxXQUNyRyxJQUFJLGFBQWEsV0FBVyxVQUFVLE9BQU8sTUFBTSxFQUFHLFlBQVcsTUFBTSxNQUFNLE1BQU0sU0FBUyxRQUFRLEdBQUc7QUFBQSxXQUN2RyxJQUFJLGFBQWEsU0FBVSxhQUFZLE1BQU0sTUFBTSxNQUFNLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0FBQUEsV0FDakYsSUFBSSxhQUFhLFlBQVksVUFBVSxPQUFPLE1BQU0sS0FBSyxTQUFTLE1BQU0sTUFBTSxLQUFLLElBQUksWUFBWSxTQUFTLEtBQUssS0FBSyxNQUFNLFFBQVEsS0FBSyxLQUFLLEdBQUc7QUFFeEosZ0JBQVksTUFBTSxNQUFNLE1BQU0sU0FBUyxRQUFRLEtBQUssS0FBSztBQUN6RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ047QUFFQSxTQUFTLFVBQVUsTUFBWSxRQUFjLFNBQXNCLFFBQWMsS0FBd0U7QUFDdkosTUFBSSxDQUFDLGtCQUFrQixRQUFRLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsUUFBUSxJQUFJLEtBQUssU0FBUyxRQUFRLE1BQU0sSUFBSSxJQUFJLE1BQU87QUFDL0gsU0FBTyxLQUFLLEtBQUssSUFBSSxPQUFPLE9BQU8sT0FBTyxLQUFLLElBQUksVUFBVTtBQUM3RCxTQUFPLG1CQUFtQixvQkFBb0IsUUFBUSxTQUFTLElBQUksUUFBUTtBQUMzRSxZQUFVLE1BQU0sSUFBSSxZQUFZLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxFQUFFLFlBQVksT0FBTyxNQUFNLFVBQVUsT0FBTyxJQUFJLFlBQVksUUFBUSxPQUFPLE9BQU8sR0FBRyxPQUFPLE9BQU8sR0FBRyxZQUFZLG1CQUFtQixNQUFLLE1BQU0sR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sR0FBRyxVQUFVLG1CQUFtQixNQUFLLE1BQU0sR0FBRyxRQUFRLE9BQU8sSUFBSSxPQUFPLE9BQU8sTUFBTSxDQUFDO0FBQzlUO0FBRUEsU0FBUyxlQUFlLE1BQVksTUFBWSxPQUFhO0FBQzNELFNBQU8sZUFBZSxLQUFLLE9BQU8sSUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLFNBQVMsT0FBTyxTQUFTLElBQUksR0FBRyxTQUFTLEtBQUssQ0FBQyxJQUFJLFlBQVksSUFBSSxFQUFHO0FBQzlIO0FBRUEsU0FBUyxZQUFZLE1BQVksUUFBYyxTQUFzQixHQUFXLEdBQVcsS0FBMEU7QUFDbkssTUFBSSxTQUFTLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLElBQUksTUFBTyxRQUFPO0FBQ25ELFFBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFBRSxVQUFRO0FBQ25DLFVBQU0sVUFBVSxZQUFZQSxLQUFJO0FBQ2hDLFdBQU8sV0FBV0EsTUFBSyxVQUFVLE9BQU8sU0FBUyxnQkFBZ0IsYUFBYUEsT0FBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsR0FBRyxRQUFRLElBQUk7QUFBQSxFQUNoSCxDQUFDO0FBQ0QsTUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEtBQUssS0FBSyxHQUFHLENBQUMsRUFBRyxRQUFPO0FBQ2pELFFBQU0sUUFBUSxRQUFRLFdBQVcsZ0JBQWdCLE9BQU8sT0FBTyxJQUFJLFlBQVksR0FBRyxDQUFDO0FBQ25GLFFBQU0sUUFBUSxRQUFRLFNBQVMsY0FBYyxNQUFNLE9BQU8sS0FBSyxPQUFPLGFBQWEsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDbEcsTUFBSSxTQUFTLENBQUMsU0FBUyxlQUFlLE1BQU0sTUFBTSxLQUFNLEdBQUksUUFBTztBQUNuRSxRQUFNLFNBQVMsS0FBSyxVQUFVLE9BQU8sT0FBTyxJQUFJLFlBQVksR0FBRyxDQUFDO0FBQ2hFLE1BQUksUUFBUSxPQUFPO0FBQUUsV0FBTyxPQUFPLEVBQUUsUUFBUSxLQUFLLElBQUksR0FBRyxNQUFNO0FBQUcsV0FBTyxPQUFPLFFBQVEsYUFBYSxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQUc7QUFDcEgsU0FBTyxjQUFjLEtBQUssT0FBTyxJQUFJO0FBQ3JDLFNBQU8sUUFBUSxFQUFFLE1BQU0sT0FBTztBQUM5QixTQUFPLG1CQUFtQixvQkFBb0IsUUFBUSxTQUFTLElBQUksUUFBUTtBQUMzRSxZQUFVLE1BQU0sSUFBSSxZQUFZLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxFQUFFLFlBQVksT0FBTyxNQUFNLFVBQVUsT0FBTyxJQUFJLFlBQVksUUFBUSxPQUFPLE9BQU8sR0FBRyxPQUFPLE9BQU8sR0FBRyxZQUFZLG1CQUFtQixNQUFLLE1BQU0sR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sR0FBRyxVQUFVLG1CQUFtQixNQUFLLE1BQU0sR0FBRyxRQUFRLE9BQU8sSUFBSSxPQUFPLE9BQU8sTUFBTSxDQUFDO0FBQzVULFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFZLFFBQWMsU0FBc0IsUUFBYyxLQUF5RTtBQUN6SixNQUFJLENBQUMsa0JBQWtCLFFBQVEsSUFBSSxTQUFTLElBQUksS0FBSyxTQUFTLFFBQVEsTUFBTSxJQUFJLElBQUksTUFBTztBQUMzRixRQUFNLG1CQUFtQixPQUFPLFFBQVEsS0FBSyxDQUFDLFdBQVcsT0FBTyxTQUFTLFFBQVEsSUFDNUUsSUFBSSw0QkFBNEIsSUFBSSxtQkFDckMsSUFBSTtBQUNSLFNBQU8sVUFBVSxPQUFPLFFBQVEsT0FBTyxDQUFDLFdBQVcsT0FBTyxTQUFTLElBQUksVUFBVTtBQUNqRixTQUFPLFFBQVEsS0FBSyxFQUFFLE1BQU0sSUFBSSxZQUFZLFdBQVcsSUFBSSxnQkFBZ0IsR0FBSSxxQkFBcUIsTUFBTSxFQUFFLGlCQUFpQixJQUFJLENBQUMsRUFBRyxDQUFDO0FBQ3RJLFNBQU8sbUJBQW1CLG9CQUFvQixRQUFRLFNBQVMsSUFBSSxRQUFRO0FBQzNFLFlBQVUsTUFBTSxJQUFJLFlBQVksT0FBTyxHQUFHLE9BQU8sR0FBRyxJQUFJLEVBQUUsWUFBWSxPQUFPLE1BQU0sVUFBVSxPQUFPLElBQUksWUFBWSxRQUFRLE9BQU8sT0FBTyxHQUFHLE9BQU8sT0FBTyxHQUFHLFlBQVksbUJBQW1CLE1BQUssTUFBTSxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxHQUFHLFVBQVUsbUJBQW1CLE1BQUssTUFBTSxHQUFHLFFBQVEsT0FBTyxJQUFJLE9BQU8sT0FBTyxNQUFNLENBQUM7QUFDNVQsTUFBSSxJQUFJLGtCQUFrQixPQUFPLGdCQUFnQixPQUFXLGFBQVksTUFBTSxRQUFRLFFBQVEsSUFBSSxnQkFBZ0IsUUFBVyxRQUFXLEdBQUcsZ0JBQWdCLE1BQU07QUFDbks7QUFhQSxTQUFTLGVBQWUsUUFBYyxRQUFjLEtBQWdCO0FBQ2xFLFFBQU0sTUFBTSxTQUFTLFFBQVEsTUFBTTtBQUNuQyxTQUFPLE9BQU8sSUFBSSxZQUFZLE9BQU8sSUFBSTtBQUMzQztBQUVBLFNBQVMsWUFBWSxNQUFZLFFBQWMsU0FBc0IsUUFBYyxLQUFnQixXQUFvQjtBQUNySCxNQUFJLENBQUMsa0JBQWtCLFFBQVEsSUFBSSxTQUFTLElBQUksRUFBRztBQUNuRCxRQUFNLFVBQVUsT0FBTyxNQUFNLFNBQVMsV0FBVyxPQUFPLE1BQU0sU0FBUyxPQUFPO0FBRTlFLFFBQU0sU0FDSixRQUFRLFNBQVMsZUFDYixFQUFFLE1BQU0sY0FBYyxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVEsR0FBRyxVQUFVLE9BQU8sR0FBRyxJQUN0RSxRQUFRLFNBQVMsWUFBWSxRQUFRLFdBQVcsVUFBYSxRQUFRLFdBQVcsU0FDOUUsRUFBRSxNQUFNLFVBQVUsVUFBVSxPQUFPLElBQUksUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLE9BQU8sSUFDdEYsUUFBUSxTQUFTLFVBQVUsQ0FBQyxZQUMxQixFQUFFLE1BQU0sVUFBVSxVQUFVLE9BQU8sSUFBSSxRQUFRLE9BQU8sR0FBRyxRQUFRLE9BQU8sRUFBRSxJQUMxRSxFQUFFLE1BQU0sVUFBVSxVQUFVLE9BQU8sR0FBRztBQUNoRCxTQUFPLG1CQUFtQixvQkFBb0IsUUFBUSxTQUFTLElBQUksUUFBUTtBQUMzRSxTQUFPLFFBQVEsRUFBRSxNQUFNLFVBQVUsVUFBVSxPQUFPLElBQUksT0FBTztBQUM3RCxNQUFJLFVBQVcsUUFBTyxhQUFhLENBQUM7QUFDcEMsUUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHLFNBQVMsUUFBUSxNQUFNLElBQUksT0FBTyxTQUFTLE9BQU8sTUFBTTtBQUNwRixRQUFNLFFBQVEsT0FBTyxJQUFJLE9BQU8sR0FBRyxPQUFPLElBQUksT0FBTyxHQUFHLFVBQVUsSUFBSSxLQUFLO0FBQzNFLFFBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sU0FBUyxRQUFRLE1BQU0sSUFBSSxPQUFPLGVBQWUsY0FBYyxDQUFDO0FBQ3hHLFlBQVUsTUFBTSxJQUFJLFlBQVksT0FBTyxHQUFHLE9BQU8sR0FBRyxVQUFVLEVBQUUsT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsT0FBTyxPQUFPLE9BQU8sWUFBWSxPQUFPLE1BQU0sUUFBUSxPQUFPLEdBQUcsQ0FBQztBQUNuTTtBQUVBLFNBQVMsa0JBQWtCLE1BQVksTUFBWTtBQUNqRCxRQUFNLFFBQVEsS0FBSztBQUNuQixNQUFJLE1BQU0sU0FBUyxTQUFVO0FBQzdCLFFBQU0sVUFBVSxVQUFVLEtBQUssSUFBSSxFQUFFLFVBQVUsS0FBSyxDQUFDLGNBQWMsYUFBYSxTQUFTLEVBQUUsYUFBYSxRQUFRO0FBQ2hILFFBQU0sTUFBTSxVQUFVLGFBQWEsT0FBTyxJQUFJO0FBQzlDLFFBQU0sU0FBUyxXQUFXLE1BQU0sTUFBTSxRQUFRO0FBQzlDLE1BQUksQ0FBQyxPQUFPLElBQUksYUFBYSxZQUFZLENBQUMsVUFBVSxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sTUFBTSxHQUFHO0FBQ3JGLGNBQVUsTUFBTSxNQUFNLE1BQU07QUFDNUI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxTQUFTLE1BQU0sTUFBTSxLQUFLLEtBQUssYUFBYTtBQUM5QyxVQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLEtBQUssZUFBZSx5QkFBeUIsTUFBTSxJQUFJLElBQUksSUFBSSxnQkFBZ0IsQ0FBQztBQUN0SCxzQkFBa0IsTUFBTSxNQUFNLFFBQVEsUUFBUSxLQUFLLFdBQVc7QUFDOUQsY0FBVSxNQUFNLGdCQUFnQixPQUFPLEdBQUcsT0FBTyxHQUFHLHFCQUFxQixFQUFFLE9BQU8sS0FBSyxHQUFHLE9BQU8sS0FBSyxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxHQUFHLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyxNQUFNLFFBQVEsS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJLFlBQVksVUFBVSxZQUFXLG1CQUFtQixNQUFLLElBQUksR0FBRSxVQUFTLG1CQUFtQixNQUFLLE1BQU0sRUFBRSxDQUFDO0FBQzlULFNBQUssV0FBVyxLQUFLO0FBQ3JCLGNBQVUsTUFBTSxNQUFNLE1BQU07QUFDNUI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFVBQVUsT0FBVyxXQUFVLE1BQU0sTUFBTSxNQUFNO0FBQzVEO0FBRUEsU0FBUyxVQUFVLE1BQVksUUFBMEI7QUFDdkQsUUFBTSxPQUFPLEtBQUssWUFBWSxNQUFNO0FBQ3BDLE9BQUssUUFBUSxRQUFRO0FBQ3ZCO0FBY0EsTUFBTSx1QkFBdUI7QUFDN0IsTUFBTSxrQkFBa0Isb0JBQUksSUFBdUIsQ0FBQyxRQUFRLFVBQVUsY0FBYyxRQUFRLEtBQUssQ0FBQztBQUNsRyxNQUFNLHNCQUFzQjtBQUM1QixNQUFNLHVCQUF1QjtBQUM3QixNQUFNLGNBQWM7QUFDcEIsTUFBTSxzQkFBc0I7QUFFNUIsU0FBUyxhQUFhLE1BQVksTUFBWTtBQUM1QyxNQUFJLENBQUMsZ0JBQWdCLElBQUksS0FBSyxNQUFNLElBQUksRUFBRztBQUMzQyxhQUFXLFdBQVcsY0FBYyxJQUFJLEdBQUc7QUFDekMsUUFBSSxnQkFBZ0IsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLGdCQUFnQixNQUFNLE9BQU8sRUFBRztBQUMzRSxVQUFNLE1BQU0sYUFBYSxPQUFPO0FBQ2hDLFFBQUksSUFBSSxhQUFhLFdBQVc7QUFDOUIsVUFBSSxvQkFBb0IsTUFBTSxNQUFNLEtBQUssSUFBSSxFQUFHO0FBQUEsSUFDbEQsV0FBVyxJQUFJLGFBQWEsUUFBUTtBQUNsQyxZQUFNLFNBQVMsbUJBQW1CLE1BQU0sTUFBTSxHQUFHO0FBQ2pELFVBQUksT0FBUSxRQUFPLFVBQVUsTUFBTSxNQUFNLFNBQVMsUUFBUSxHQUFHO0FBQUEsSUFDL0QsV0FBVyxJQUFJLGFBQWEsU0FBUztBQUNuQyxZQUFNLFNBQVMsb0JBQW9CLE1BQU0sTUFBTSxHQUFHO0FBQ2xELFVBQUksT0FBUSxRQUFPLFdBQVcsTUFBTSxNQUFNLFNBQVMsUUFBUSxHQUFHO0FBQUEsSUFDaEUsV0FBVyxJQUFJLGFBQWEsVUFBVTtBQUNwQyxZQUFNLFFBQVEsb0JBQW9CLE1BQU0sTUFBTSxHQUFHO0FBQ2pELFVBQUksU0FBUyxZQUFZLE1BQU0sTUFBTSxTQUFTLE1BQU0sR0FBRyxNQUFNLEdBQUcsR0FBRyxFQUFHO0FBQUEsSUFDeEUsV0FBVyxJQUFJLGFBQWEsU0FBUztBQUNuQyxVQUFJLFdBQVcsTUFBTSxNQUFNLFNBQVMsR0FBRyxFQUFHO0FBQUEsSUFDNUMsV0FBVyxJQUFJLGFBQWEsYUFBYTtBQUN2QyxVQUFJLGVBQWUsTUFBTSxNQUFNLFNBQVMsR0FBRyxFQUFHO0FBQUEsSUFDaEQsV0FBVyxJQUFJLGFBQWEsT0FBTztBQUNqQyxVQUFJLFNBQVMsTUFBTSxNQUFNLFNBQVMsR0FBRyxFQUFHO0FBQUEsSUFDMUMsV0FBVyxJQUFJLGFBQWEsWUFBWSxLQUFLLE1BQU0sU0FBUyxRQUFRO0FBQ2xFLFlBQU0sU0FBUyxxQkFBcUIsTUFBTSxNQUFNLEdBQUc7QUFDbkQsVUFBSSxPQUFRLFFBQU8sWUFBWSxNQUFNLE1BQU0sU0FBUyxRQUFRLEtBQUssS0FBSztBQUFBLElBQ3hFO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxXQUFXLE1BQVksUUFBYyxTQUFzQixLQUF5RTtBQUMzSSxRQUFNLFNBQWlCLENBQUM7QUFDeEIsb0JBQWtCLE1BQU0sUUFBUSxJQUFJLE9BQU8sQ0FBQyxjQUFjO0FBQ3hELFFBQUksa0JBQWtCLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxTQUFTLFFBQVEsU0FBUyxLQUFLLElBQUksU0FBUyxjQUFjLE1BQU0sUUFBUSxTQUFTLEVBQUcsUUFBTyxLQUFLLFNBQVM7QUFBQSxFQUNsSyxDQUFDO0FBQ0QsTUFBSSxPQUFPLFdBQVcsRUFBRyxRQUFPO0FBQ2hDLGFBQVcsUUFBUSxPQUFRLFdBQVUsTUFBTSxFQUFFLE1BQU0sUUFBUSxXQUFXLElBQUksZUFBZSxDQUFDO0FBQzFGLFNBQU8sbUJBQW1CLG9CQUFvQixRQUFRLFNBQVMsSUFBSSxRQUFRO0FBQzNFLFlBQVUsTUFBTSxTQUFTLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxFQUFFLFFBQVEsSUFBSSxPQUFPLE9BQU8sT0FBTyxPQUFPLFlBQVksT0FBTyxNQUFNLFFBQVEsT0FBTyxJQUFJLFVBQVUsT0FBTyxJQUFJLFlBQVksUUFBUSxPQUFPLE9BQU8sR0FBRyxPQUFPLE9BQU8sR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sRUFBRSxDQUFDO0FBQ2hQLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFZLFFBQWMsU0FBc0IsS0FBNkU7QUFDbkosTUFBSTtBQUNKLG9CQUFrQixNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsY0FBYztBQUN4RCxRQUFJLENBQUMsa0JBQWtCLFdBQVcsSUFBSSxTQUFTLElBQUksS0FBSyxTQUFTLFFBQVEsU0FBUyxJQUFJLElBQUksU0FBUyxVQUFVLE1BQU0sS0FBSyxVQUFVLFVBQVUsT0FBTyxTQUFTLENBQUMsVUFBVSxTQUFTLEVBQUc7QUFDbkwsUUFBSSxVQUFVLFFBQVEsS0FBSyxDQUFDLFdBQVcsT0FBTyxTQUFTLFdBQVcsRUFBRztBQUNyRSxRQUFJLENBQUMsUUFBUSxVQUFVLGVBQWUsS0FBSyxhQUFjLFFBQU87QUFBQSxFQUNsRSxDQUFDO0FBQ0QsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixZQUFVLE1BQU0sRUFBRSxNQUFNLGFBQWEsV0FBVyxJQUFJLGVBQWUsQ0FBQztBQUNwRSxTQUFPLG1CQUFtQixvQkFBb0IsUUFBUSxTQUFTLElBQUksUUFBUTtBQUMzRSxZQUFVLE1BQU0sYUFBYSxLQUFLLEdBQUcsS0FBSyxHQUFHLElBQUksRUFBRSxPQUFPLE9BQU8sT0FBTyxZQUFZLE9BQU8sTUFBTSxRQUFRLE9BQU8sSUFBSSxVQUFVLE9BQU8sSUFBSSxZQUFZLFFBQVEsT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLEdBQUcsWUFBWSxtQkFBbUIsTUFBSyxNQUFNLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsVUFBVSxtQkFBbUIsTUFBSyxJQUFJLEVBQUUsQ0FBQztBQUMvUyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFNBQVMsTUFBWSxRQUFjLFNBQXNCLEtBQXVFO0FBQ3ZJLE1BQUk7QUFDSixvQkFBa0IsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLGNBQWM7QUFDeEQsUUFBSSxDQUFDLGtCQUFrQixXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssU0FBUyxRQUFRLFNBQVMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxjQUFjLE1BQU0sUUFBUSxTQUFTLEtBQUssVUFBVSxRQUFRLEtBQUssQ0FBQyxXQUFXLE9BQU8sU0FBUyxNQUFNLEVBQUc7QUFDMU0sUUFBSSxDQUFDLFFBQVEsU0FBUyxRQUFRLFNBQVMsSUFBSSxTQUFTLFFBQVEsSUFBSSxFQUFHLFFBQU87QUFBQSxFQUM1RSxDQUFDO0FBQ0QsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixZQUFVLE1BQU0sRUFBRSxNQUFNLFFBQVEsV0FBVyxJQUFJLGVBQWUsQ0FBQztBQUMvRCxTQUFPLG1CQUFtQixvQkFBb0IsUUFBUSxTQUFTLElBQUksUUFBUTtBQUMzRSxZQUFVLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxHQUFHLElBQUksZ0JBQWdCLEVBQUUsT0FBTyxPQUFPLE9BQU8sWUFBWSxPQUFPLE1BQU0sUUFBUSxPQUFPLElBQUksVUFBVSxPQUFPLElBQUksWUFBWSxRQUFRLE9BQU8sT0FBTyxHQUFHLE9BQU8sT0FBTyxHQUFHLFlBQVksbUJBQW1CLE1BQUssTUFBTSxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLFVBQVUsbUJBQW1CLE1BQUssSUFBSSxFQUFFLENBQUM7QUFDelQsU0FBTztBQUNUO0FBR0EsU0FBUyxVQUFVLE1BQVksUUFBMEI7QUFDdkQsT0FBSyxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUMsV0FBVyxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBQzFFLE9BQUssUUFBUSxLQUFLLE1BQU07QUFDMUI7QUFHQSxTQUFTLFdBQVcsTUFBWTtBQUM5QixNQUFJLEtBQUssUUFBUSxXQUFXLEVBQUcsUUFBTztBQUN0QyxNQUFJLE9BQU87QUFDWCxhQUFXLFVBQVUsS0FBSyxTQUFTO0FBQ2pDLFFBQUksT0FBTyxTQUFTLFVBQVUsT0FBTyxTQUFTLE9BQVEsUUFBTztBQUM3RCxRQUFJLE9BQU8sU0FBUyxPQUFRLFFBQU87QUFBQSxFQUNyQztBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsaUJBQWlCLE1BQVksTUFBWSxlQUFlLEtBQUssZ0JBQWdCO0FBQ3BGLFFBQU0sU0FBUyxLQUFLLGNBQWMsSUFBSSxLQUFLLEVBQUUsR0FBRyx5QkFBeUIsS0FBSywrQkFBK0IsSUFBSTtBQUNqSCxTQUFPLFVBQVUsSUFBSSxlQUFlLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxlQUFlLEtBQUssQ0FBQztBQUNsRjtBQUdBLFNBQVMsVUFBVSxNQUFZO0FBQzdCLFNBQU8sS0FBSyxNQUFNLFNBQVMsWUFBWSxLQUFLLE1BQU0sU0FBUyxZQUFhLEtBQUssTUFBTSxTQUFTLGdCQUFnQixLQUFLLE1BQU0sYUFBYTtBQUN0STtBQUdBLFNBQVMsY0FBYyxNQUFZLFFBQWMsV0FBaUI7QUFDaEUsU0FBTyxVQUFVLEtBQUssS0FBSyxlQUFlLE1BQU0sT0FBTyxPQUFPLFVBQVUsS0FBSyxNQUFNLFVBQVUsVUFBVSxhQUFhLFVBQVUsU0FBUztBQUN6STtBQUVBLFNBQVMsbUJBQW1CLE1BQVksUUFBYyxLQUF3RTtBQUM1SCxNQUFJO0FBQ0osTUFBSSxjQUFjLElBQUksYUFBYTtBQUNuQyxvQkFBa0IsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLGNBQWM7QUFDeEQsUUFBSSxDQUFDLGtCQUFrQixXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsV0FBVyxJQUFJLEtBQUssVUFBVSxNQUFNLEtBQUssZUFBZSxNQUFNLE9BQU8sT0FBTyxVQUFVLEtBQUssS0FBSyxTQUFTLFFBQVEsU0FBUyxJQUFJLElBQUksTUFBTztBQUNwTixVQUFNLFVBQVUsVUFBVSxRQUFRLFVBQVU7QUFDNUMsUUFBSSxVQUFVLGVBQWdCLFlBQVksZUFBZSxLQUFPO0FBQ2hFLFdBQU87QUFDUCxrQkFBYztBQUFBLEVBQ2hCLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQixNQUFZLFFBQWMsS0FBeUU7QUFDOUgsUUFBTSxlQUFlLFVBQVUsTUFBTTtBQUNyQyxRQUFNLE1BQU0sT0FBTyxNQUFNLFNBQVMsWUFBWSxPQUFPLE1BQU0sU0FBUyxlQUFlLE9BQU8sTUFBTSxXQUFXO0FBQzNHLE1BQUk7QUFDSixNQUFJLFlBQVksT0FBTztBQUN2QixvQkFBa0IsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLGNBQWM7QUFDeEQsUUFBSSxDQUFDLGtCQUFrQixXQUFXLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxjQUFjLE1BQU0sUUFBUSxTQUFTLEtBQUssU0FBUyxRQUFRLFNBQVMsSUFBSSxJQUFJLE1BQU87QUFDNUksUUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsU0FBUyxFQUFHO0FBQzVDLFFBQUksVUFBVSxRQUFRLEtBQUssQ0FBQyxXQUFXLE9BQU8sU0FBUyxJQUFJLFVBQVUsRUFBRztBQUN4RSxVQUFNLFNBQVMsSUFBSSxrQkFBa0IsVUFBVSxnQkFBZ0IsU0FBWSxNQUFRLE1BQU0sVUFBVSxPQUFPLE1BQU0sTUFBUSxLQUFLLFNBQVMsUUFBUSxTQUFTO0FBQ3ZKLFFBQUksU0FBUyxVQUFXO0FBQ3hCLFdBQU87QUFDUCxnQkFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFNBQU87QUFDVDtBQUVBLFNBQVMsb0JBQW9CLE1BQVksUUFBYyxLQUEwRTtBQUMvSCxNQUFJO0FBQ0osb0JBQWtCLE1BQU0sUUFBUSxJQUFJLFFBQVEscUJBQXFCLENBQUMsY0FBYztBQUM5RSxRQUFJLENBQUMsY0FBYyxNQUFNLFFBQVEsU0FBUyxLQUFLLFNBQVMsUUFBUSxTQUFTLElBQUksSUFBSSxRQUFRLG9CQUFxQjtBQUM5RyxRQUFJLENBQUMsT0FBTyxTQUFTLFFBQVEsU0FBUyxJQUFJLFNBQVMsUUFBUSxHQUFHLEVBQUcsT0FBTTtBQUFBLEVBQ3pFLENBQUM7QUFDRCxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLE1BQUksVUFBVTtBQUNkLG9CQUFrQixNQUFNLFFBQVEsc0JBQXNCLENBQUMsY0FBYztBQUNuRSxRQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVMsVUFBVSxTQUFTLElBQUksY0FBYyxTQUFTLFFBQVEsU0FBUyxLQUFLLHFCQUFzQixXQUFVO0FBQUEsRUFDOUksQ0FBQztBQUNELE1BQUksUUFBUyxRQUFPO0FBQ3BCLFFBQU0sTUFBTSxTQUFTLFFBQVEsR0FBRztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLGFBQWEsR0FBRztBQUN0QyxTQUFPLE1BQU0sSUFBSSxFQUFFLEdBQUcsT0FBTyxLQUFNLElBQUksSUFBSSxPQUFPLEtBQUssTUFBTyxNQUFNLEdBQUcsT0FBTyxLQUFNLElBQUksSUFBSSxPQUFPLEtBQUssTUFBTyxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU8sR0FBRyxHQUFHLE9BQU8sRUFBRTtBQUNySjtBQUVBLFNBQVMscUJBQXFCLE1BQVksT0FBYSxLQUFnQjtBQUNyRSxRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sTUFBTSxTQUFTLFlBQVksTUFBTSxTQUFTLGVBQWUsTUFBTSxXQUFXO0FBQ3RGLE1BQUksS0FBSztBQUNQLFVBQU0sU0FBUyxXQUFXLE1BQU0sR0FBRztBQUNuQyxXQUFPLFVBQVUsT0FBTyxNQUFNLEtBQUssa0JBQWtCLFFBQVEsSUFBSSxTQUFTLElBQUksS0FBSyxjQUFjLE1BQU0sT0FBTyxNQUFNLEtBQUssZUFBZSxPQUFPLFFBQVEsR0FBRyxLQUFLLFNBQVMsS0FBSyxLQUFLLE9BQU8sUUFBUSxLQUFLLEtBQUssSUFBSSxTQUFTO0FBQUEsRUFDMU47QUFDQSxNQUFJLE1BQU0sU0FBUyxVQUFVLE1BQU0sU0FBUyxhQUFjLFFBQU87QUFDakUsTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJO0FBQ0osb0JBQWtCLE1BQU0sT0FBTyxJQUFJLE9BQU8sQ0FBQyxjQUFjO0FBQ3ZELFFBQUksQ0FBQyxrQkFBa0IsV0FBVyxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsY0FBYyxNQUFNLE9BQU8sU0FBUyxLQUFLLENBQUMsZUFBZSxPQUFPLFdBQVcsR0FBRyxLQUFLLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxXQUFXLEtBQUssS0FBSyxFQUFHO0FBRS9MLGdCQUFZLElBQUksSUFBSSxLQUFLLE1BQU0sUUFBUSxDQUFDLFNBQVUsS0FBSyxVQUFVLE1BQU0sU0FBUyxLQUFLLE1BQU0sU0FBUyxXQUFXLENBQUMsS0FBSyxNQUFNLFFBQVEsSUFBSSxDQUFDLENBQUUsQ0FBQztBQUMzSSxRQUFJLENBQUMsT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFJLFNBQVMsT0FBTyxHQUFHLEVBQUcsT0FBTTtBQUNyRSxRQUFJLENBQUMsUUFBUSxJQUFJLFVBQVUsRUFBRSxNQUFNLENBQUMsUUFBUSxTQUFTLE9BQU8sU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLEdBQUksUUFBTztBQUFBLEVBQzFHLENBQUM7QUFDRCxTQUFPLFFBQVE7QUFDakI7QUFFQSxTQUFTLHlCQUF5QixNQUFZLE1BQVk7QUFDeEQsUUFBTSxTQUFTLEtBQUssUUFBUSxPQUFPLENBQUMsWUFBWSxXQUFXLEtBQUssSUFBSSxZQUFZLE9BQU8scUJBQXFCLE9BQU8sU0FBUyxVQUFVLE1BQU0sRUFBRSxHQUFHLENBQUM7QUFDbEosVUFBUSxLQUFLLFdBQVcsVUFBVSxTQUFTLHFCQUFxQixVQUFVLDBCQUEwQixNQUFNLElBQUk7QUFDaEg7QUFFQSxTQUFTLFlBQVksTUFBWSxNQUFZLFFBQWdCO0FBQzNELFFBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE1BQU07QUFDbkUsTUFBSSxDQUFDLEtBQU0sT0FBTSxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRTtBQUNuRCxNQUFJLEtBQUssY0FBYyxLQUFLLEdBQUksT0FBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLEVBQUUsb0JBQW9CLEtBQUssRUFBRSxFQUFFO0FBQ3ZGLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFZLE1BQWlCO0FBQy9DLFNBQU8sS0FBSyxZQUFZLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sS0FBSyxTQUFTLElBQUk7QUFDbEY7QUFFQSxTQUFTLG9CQUFvQixNQUFZLFNBQWUsTUFBaUI7QUFHdkUsTUFBSSxLQUFLLFNBQVMsb0JBQW9CLEtBQUssU0FBUyxvQkFBb0IsS0FBSyxTQUFTLGtCQUFrQixlQUFlLEtBQUssSUFBSSxLQUFLLEtBQUssb0JBQW9CLEVBQUc7QUFDakssUUFBTSxTQUFTLG9CQUFvQixNQUFNLFNBQVMsS0FBSyxTQUFTLGVBQWUsNkJBQTZCLHlCQUF5QjtBQUNySSxNQUFJLENBQUMsT0FBUTtBQUNiLGVBQWEsTUFBTSxTQUFTLE1BQU0sT0FBTyxJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUM7QUFDakU7QUFFQSxTQUFTLGFBQ1AsTUFDQSxTQUNBLE1BQ0EsVUFDQSxHQUNBLEdBQ0E7QUFDQSxNQUFJLEtBQUssb0JBQW9CLEVBQUc7QUFDaEMsTUFBSSxLQUFLLFNBQVMsZ0JBQWdCO0FBQ2hDLFVBQU0sU0FBUyxXQUFXLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sWUFBWSxlQUFlLE1BQU0sUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7QUFDL0gsUUFBSSxDQUFDLFVBQVUsU0FBUyxTQUFTLE1BQU0sSUFBSSxjQUFjLE1BQU87QUFDaEUsd0JBQW9CLE1BQU0sU0FBUyxNQUFNLE1BQU07QUFDL0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFNBQVMsY0FBYztBQUM5QixVQUFNLFFBQVEsV0FBVyxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLFFBQVEsSUFBSSxTQUFTLENBQUMsS0FBSyxTQUFTLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJO0FBQ25ILFFBQUksQ0FBQyxTQUFTLFNBQVMsU0FBUyxLQUFLLElBQUksWUFBWSxNQUFPO0FBQzVELG9CQUFnQixNQUFNLFNBQVMsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDO0FBQ3JEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxTQUFTLGtCQUFrQjtBQUNsQyxRQUFJLFFBQVEsVUFBVSxVQUFXO0FBQ2pDLHNCQUFrQixNQUFNLFNBQVMsZ0JBQWdCLFFBQVEsQ0FBQyxTQUFTO0FBQ2pFLFVBQUksU0FBUyxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsVUFBVSxlQUFlLE1BQU0sUUFBUSxPQUFPLEtBQUssS0FBSyxFQUFHO0FBQ3pHLFdBQUssVUFBVSxLQUFLLFFBQVEsT0FBTyxDQUFDLFdBQVcsT0FBTyxTQUFTLFVBQVU7QUFDekUsV0FBSyxRQUFRLEtBQUssRUFBRSxNQUFNLFlBQVksV0FBVyxnQkFBZ0IsU0FBUyxDQUFDO0FBQUEsSUFDN0UsQ0FBQztBQUNELGNBQVUsTUFBTSxpQkFBaUIsUUFBUSxHQUFHLFFBQVEsR0FBRyxnQkFBZ0IsVUFBVSxFQUFFLFFBQVEsZ0JBQWdCLFFBQVEsVUFBVSxRQUFRLElBQUksWUFBWSxRQUFRLE9BQU8sUUFBUSxHQUFHLE9BQU8sUUFBUSxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUssUUFBUSxFQUFFLENBQUM7QUFDak8sZ0JBQVksTUFBTSxJQUFJO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxTQUFTLGdCQUFnQjtBQUNoQyxRQUFJLFFBQVEsVUFBVSxVQUFXO0FBQ2pDLFVBQU0sU0FBUyxXQUFXLEtBQUssVUFBVSxLQUFLLENBQUMsYUFBYSxTQUFTLE9BQU8sWUFBWSxlQUFlLE1BQU0sUUFBUSxPQUFPLFNBQVMsS0FBSyxDQUFDLElBQUk7QUFDL0ksUUFBSSxDQUFDLFVBQVUsU0FBUyxTQUFTLE1BQU0sSUFBSSxjQUFjLE1BQU87QUFDaEUsc0JBQWtCLE1BQU0sU0FBUyxRQUFRLGNBQWMsUUFBUSxjQUFjLE9BQU8scUJBQXFCLFlBQVk7QUFDckgsZ0JBQVksTUFBTSxJQUFJO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxTQUFTLGtCQUFrQjtBQUNsQyxRQUFJLFFBQVEsVUFBVSxVQUFXO0FBQ2pDLFlBQVEsTUFBTTtBQUNkLGlCQUFhLE1BQU0sT0FBTztBQUMxQixjQUFVLE1BQU0sbUJBQW1CLFFBQVEsR0FBRyxRQUFRLEdBQUcsRUFBRTtBQUMzRCxnQkFBWSxNQUFNLElBQUk7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFNBQVMsaUJBQWlCO0FBQ2pDLFFBQUksUUFBUSxVQUFVLFVBQVc7QUFDakMsc0JBQWtCLE1BQU0sU0FBUyx1QkFBdUIsQ0FBQyxTQUFTO0FBQ2hFLFVBQUksQ0FBQyxrQkFBa0IsTUFBTSxJQUFJLEtBQUssU0FBUyxNQUFNLE9BQU8sSUFBSSx5QkFBeUIsZUFBZSxNQUFNLFFBQVEsT0FBTyxLQUFLLEtBQUssRUFBRztBQUMxSSxXQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssbUJBQW1CO0FBQUEsSUFDOUQsQ0FBQztBQUNELGNBQVUsTUFBTSxRQUFRLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxFQUFFLFFBQVEsdUJBQXVCLFVBQVUsUUFBUSxJQUFJLFlBQVksUUFBUSxPQUFPLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRyxLQUFLLFFBQVEsR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO0FBQ2pNLGdCQUFZLE1BQU0sSUFBSTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssU0FBUyxjQUFjO0FBQzlCLFFBQUksQ0FBQyxXQUFXLFFBQVEsS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRztBQUNoRSxRQUFJLEtBQUssTUFBTSxJQUFJLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLGtCQUFtQjtBQUNsRSxRQUFJLHVCQUF1QixLQUFLLEtBQUssZ0JBQWdCLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyx5QkFBeUIsTUFBTSxnQkFBZ0IsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFHO0FBQzVILFVBQU0sS0FBSyxnQkFBZ0IsS0FBSyxLQUFLLGNBQWMsYUFBYSxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDaEYsVUFBTSxRQUFRLGVBQWUsWUFBWSxRQUFRLEtBQUssaUJBQWlCLEtBQUssTUFBTSxJQUFJLFFBQVEsT0FBTyxnQkFBZ0IsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJO0FBQ3JJLFNBQUssVUFBVTtBQUNmLFVBQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxRQUFRLG9CQUFvQjtBQUN4RCxTQUFLLFVBQVUsS0FBSyxLQUFLO0FBQ3pCLGNBQVUsTUFBTSxVQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxFQUFDLFVBQVMsUUFBUSxJQUFHLFlBQVcsUUFBTyxPQUFNLFFBQVEsR0FBRSxPQUFNLFFBQVEsR0FBRSxLQUFJLEdBQUcsR0FBRSxLQUFJLEdBQUcsRUFBQyxDQUFDO0FBQ25JLGdCQUFZLE1BQU0sSUFBSTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsTUFBeUI7QUFDL0MsU0FBTyxTQUFTLGdCQUFnQixTQUFTLGVBQWUsU0FBUyxtQkFBbUIsU0FBUztBQUMvRjtBQUVBLFNBQVMsWUFBWSxNQUFZLE1BQWlCO0FBQ2hELFFBQU0sT0FBSyxXQUFXLE1BQUssSUFBSTtBQUFFLE1BQUcsS0FBSyxpQkFBZ0IsTUFBSyxLQUFLLEVBQUU7QUFDckUsT0FBSyxRQUFRLEtBQUssTUFBTSxPQUFPLENBQUMsY0FBYyxVQUFVLE9BQU8sS0FBSyxFQUFFO0FBQ3RFLE1BQUcsS0FBSyx1QkFBc0IsTUFBSyxJQUFJO0FBQUUsdUJBQXFCLElBQUk7QUFDcEU7QUFFQSxTQUFTLG9CQUFvQixNQUFZLFNBQWUsTUFBaUIsYUFBbUI7QUFDMUYsUUFBTSxTQUFTLG9CQUFJLElBQVk7QUFDL0IsTUFBSSxVQUFVO0FBQ2QsTUFBSSxTQUFTLGNBQWM7QUFDM0IsV0FBUyxTQUFTLEdBQUcsU0FBUyxjQUFjLE1BQU0sVUFBVSxHQUFHO0FBQzdELFdBQU8sSUFBSSxRQUFRLEVBQUU7QUFDckIsc0JBQWtCLE1BQU0sU0FBUyxTQUFTLFNBQU8seUJBQXlCLE1BQUssT0FBTyxHQUFHLEtBQUsscUJBQXFCLFlBQVk7QUFDL0gsY0FBVSxNQUFNLGtCQUFrQixRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUksRUFBRSxPQUFPLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRyxLQUFLLFFBQVEsR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO0FBQ2xJLFVBQU0sT0FBTyxtQkFBbUIsTUFBTSxTQUFTLFNBQVMsUUFBUSxjQUFjLFdBQVc7QUFDekYsUUFBSSxDQUFDLEtBQU07QUFDWCxjQUFVO0FBQ1YsYUFBUyxLQUFLLElBQUksY0FBYyxlQUFlLEtBQUssTUFBTSxTQUFTLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDekY7QUFDQSxPQUFLLG9CQUFvQixjQUFjO0FBQ3pDO0FBRUEsU0FBUyxtQkFBbUIsTUFBWSxTQUFlLE1BQVksUUFBcUIsT0FBZTtBQUNyRyxRQUFNLFFBQVEsUUFBUTtBQUN0QixNQUFJO0FBQ0osTUFBSSxlQUFlLE9BQU87QUFDMUIsb0JBQWtCLE1BQU0sTUFBTSxPQUFPLENBQUMsY0FBYztBQUNsRCxRQUFJLE9BQU8sSUFBSSxVQUFVLEVBQUUsS0FBSyxDQUFDLGVBQWUsTUFBTSxRQUFRLE9BQU8sVUFBVSxLQUFLLEVBQUc7QUFDdkYsVUFBTSxvQkFBb0IsZ0JBQWdCLE1BQU0sU0FBUztBQUN6RCxRQUFJLG9CQUFvQixTQUFTLHFCQUFxQixhQUFjO0FBQ3BFLFdBQU87QUFDUCxtQkFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixNQUFZLFNBQWUsTUFBaUIsR0FBVyxHQUFXO0FBQ3pGLG9CQUFrQixNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsWUFBWSxRQUFRLENBQUMsV0FBVztBQUNoRSxRQUFJLFNBQVMsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksWUFBWSxVQUFVLENBQUMsZUFBZSxNQUFNLFFBQVEsT0FBTyxPQUFPLEtBQUssRUFBRztBQUMzRyxzQkFBa0IsTUFBTSxTQUFTLFFBQVEsWUFBWSxlQUFhLHlCQUF5QixNQUFLLE9BQU8sR0FBRyxZQUFZLE9BQU8scUJBQXFCLFVBQVU7QUFBQSxFQUM5SixDQUFDO0FBQ0QsWUFBVSxNQUFNLFNBQVMsR0FBRyxHQUFHLFlBQVksVUFBVSxFQUFFLFVBQVUsUUFBUSxJQUFJLFlBQVksUUFBUSxPQUFPLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLE9BQU8sUUFBUSxPQUFPLFFBQVEsUUFBUSxJQUFJLFFBQVEsWUFBWSxjQUFZLHlCQUF5QixNQUFLLE9BQU8sR0FBRyxlQUFlLEVBQUUsR0FBRyxxQkFBcUIsV0FBVyxHQUFHLFFBQVEsWUFBWSxRQUFRLFdBQVcsWUFBWSxXQUFXLENBQUM7QUFDN1gsT0FBSyxvQkFBb0IsWUFBWTtBQUN2QztBQUVBLFNBQVMsZ0JBQWdCLE1BQVksU0FBZSxNQUFpQjtBQUNuRSxNQUFJLEtBQUssb0JBQW9CLEVBQUc7QUFDaEMsTUFBSSxTQUFTO0FBQ2Isb0JBQWtCLE1BQU0sU0FBUyxZQUFZLFFBQVEsQ0FBQyxXQUFXO0FBQy9ELFFBQUksU0FBUyxRQUFRLE9BQU8sSUFBSSxZQUFZLFVBQVUsQ0FBQyxlQUFlLE1BQU0sUUFBUSxPQUFPLE9BQU8sS0FBSyxFQUFHO0FBQzFHLHNCQUFrQixNQUFNLFNBQVMsUUFBUSxZQUFZLFNBQU8seUJBQXlCLE1BQUssT0FBTyxHQUFHLElBQUkscUJBQXFCLFVBQVU7QUFDdkksY0FBVSxNQUFNLGFBQWEsT0FBTyxHQUFHLE9BQU8sR0FBRywyQkFBMkI7QUFDNUUsYUFBUztBQUFBLEVBQ1gsQ0FBQztBQUNELE1BQUksQ0FBQyxPQUFRO0FBQ2IsT0FBSyxvQkFBb0IsWUFBWTtBQUN2QztBQUVBLFNBQVMsbUJBQW1CLE1BQVk7QUFDdEMsTUFBSSxLQUFLLFFBQVEsV0FBVyxFQUFHO0FBQy9CLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxLQUFLLFNBQVM7QUFDakMseUJBQXFCLE1BQU0sTUFBTTtBQUNqQyxXQUFPLGFBQWE7QUFDcEIsZ0JBQVksRUFBRSxPQUFPLFlBQVk7QUFBQSxFQUNuQztBQUNBLE1BQUksUUFBUyxNQUFLLFVBQVUsS0FBSyxRQUFRLE9BQU8sQ0FBQyxXQUFXLE9BQU8sWUFBWSxDQUFDO0FBQ2xGO0FBRUEsU0FBUyxxQkFBcUIsTUFBWSxRQUFxQjtBQUM3RCxNQUFJLE9BQU8sU0FBUyxtQkFBbUIsT0FBTyxTQUFTLE9BQU8sVUFBVSxPQUFPLFVBQVUsT0FBTyxXQUFXO0FBQ3pHLFFBQUksT0FBTyxZQUFZLE9BQU8sY0FBYyxFQUFHO0FBQy9DLFVBQU0sU0FBUyxPQUFPLFNBQVMsV0FBVyxNQUFLLE9BQU8sTUFBTSxJQUFJO0FBQ2hFLFVBQU0sV0FBVyxVQUFVLGFBQWEsRUFBQyxJQUFHLE9BQU8sVUFBVSxPQUFPLElBQUcsT0FBTSxPQUFPLE9BQU0sR0FBRSxPQUFPLEdBQUUsR0FBRSxPQUFPLEVBQUMsQ0FBQztBQUNoSCxlQUFXLFVBQVUsQ0FBQyxHQUFHLEtBQUssT0FBTSxHQUFHLEtBQUssU0FBUyxFQUFHLEtBQUksT0FBTyxLQUFHLEtBQUssZUFBZSxNQUFLLE9BQU8sT0FBTSxPQUFPLEtBQUssS0FBSyxTQUFTLFFBQU8sTUFBTSxLQUFHLE9BQU8sU0FBTyxPQUFPLFFBQVE7QUFDakwsVUFBSSxPQUFPLGVBQWUsaUJBQWlCLE9BQU8sTUFBTSxNQUFNLE9BQU8sUUFBUSxVQUFVLE9BQU8sSUFBSSxNQUFNLFFBQVM7QUFDakgsWUFBTSxRQUFNLFlBQVksTUFBSyxVQUFTLFFBQU8sT0FBTyxRQUFPLFFBQVUsUUFBVSxHQUFFLE9BQU8saUJBQWlCLGdCQUFnQixPQUFPO0FBQUUsVUFBRyxVQUFRLE9BQVUsY0FBYSxNQUFLLFFBQU8sT0FBTSxNQUFNO0FBQzVMLFVBQUksVUFBVSxVQUFhLE9BQU8sZUFBZSxpQkFBaUIsT0FBTyxNQUFNLEVBQUcsV0FBVSxRQUFRLEVBQUUsTUFBTSxVQUFVLFdBQVcsZ0JBQWdCLENBQUM7QUFBQSxJQUNwSjtBQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksT0FBTyxTQUFTLFdBQVcsQ0FBQyxPQUFPLFNBQVMsQ0FBQyxPQUFPLFVBQVUsQ0FBQyxPQUFPLFVBQVUsQ0FBQyxPQUFPLFVBQVc7QUFDdkcsTUFBSSxPQUFPLGNBQWMsT0FBTyxZQUFZLE9BQU8sWUFBWSxPQUFPLGNBQWMsRUFBRztBQUN2RixvQkFBa0IsTUFBTSxRQUFRLE9BQU8sUUFBUSxDQUFDLFdBQVc7QUFDekQsUUFBSSxTQUFTLFFBQVEsTUFBTSxJQUFJLE9BQU8sVUFBVyxDQUFDLGVBQWUsTUFBTSxPQUFPLE9BQVEsT0FBTyxLQUFLLEVBQUc7QUFDckcsc0JBQWtCLE1BQU0sYUFBYSxFQUFFLElBQUksT0FBTyxVQUFVLE9BQU8sSUFBSSxPQUFPLE9BQU8sT0FBUSxHQUFHLE9BQU8sR0FBRyxHQUFHLE9BQU8sRUFBRSxDQUFDLEdBQUcsUUFBUSxPQUFPLFFBQVMsS0FBSyxPQUFPLGlCQUFpQixnQkFBZ0IsS0FBSztBQUFBLEVBQ3RNLENBQUM7QUFDSDtBQUVBLFNBQVMsa0JBQWtCLE1BQVk7QUFDckMsTUFBSSxLQUFLLFlBQVksV0FBVyxFQUFHO0FBQ25DLFFBQU0sY0FBYyxLQUFLO0FBQ3pCLE1BQUk7QUFDSixXQUFTLFFBQVEsR0FBRyxRQUFRLFlBQVksUUFBUSxTQUFTO0FBQ3ZELFVBQU0sYUFBYSxZQUFZLEtBQUs7QUFDcEMsZUFBVyxhQUFhO0FBQ3hCLFFBQUksV0FBVyxZQUFZLEdBQUc7QUFDNUIsZUFBUyxLQUFLLFVBQVU7QUFDeEI7QUFBQSxJQUNGO0FBQ0EsZ0JBQVksWUFBWSxNQUFNLEdBQUcsS0FBSztBQUN0QywwQkFBc0IsTUFBTSxVQUFVO0FBQUEsRUFDeEM7QUFFQSxNQUFJLFFBQVMsTUFBSyxjQUFjO0FBQ2xDO0FBRUEsU0FBUyxzQkFBc0IsTUFBWSxZQUF3QjtBQUNqRSxzQkFBb0IsTUFBTSxNQUFNO0FBQ2hDLFFBQUksV0FBVyxRQUFRO0FBQUUsbUJBQWEsTUFBTSxVQUFVO0FBQUc7QUFBQSxJQUFRO0FBQ2pFLFVBQU0sU0FBUyxpQkFBaUIsTUFBTSxXQUFXLFFBQVE7QUFDekQsUUFBSSxDQUFDLFVBQVUsT0FBTyxNQUFNLEtBQUssQ0FBQyxlQUFlLE1BQU0sV0FBVyxPQUFPLE9BQU8sS0FBSyxFQUFHO0FBQ3hGLFVBQU0sY0FBYyxXQUFXLE1BQU0sV0FBVyxVQUFVO0FBQzFELFVBQU0sVUFBVSxhQUFhLFVBQVEsV0FBVyxRQUFRLGNBQWM7QUFDdEUsVUFBTSxXQUFXLFdBQVcsbUJBQW1CLFVBQVU7QUFDekQsVUFBTSxRQUFRLFlBQVksTUFBTSxVQUFVLFFBQVEsMEJBQTBCLE1BQU0sVUFBVSxRQUFRLFdBQVcsTUFBTSxHQUFHLFdBQVcsaUJBQWlCLFFBQVcsR0FBRyxXQUFXLGlCQUFpQixvQkFBb0IsV0FBVyxjQUFjLGNBQWMsR0FBRyxXQUFXLG1CQUFtQjtBQUMxUixRQUFJLFVBQVUsT0FBVztBQUN6Qiw2QkFBeUIsTUFBTSxVQUFVLFFBQVEsV0FBVyxVQUFVO0FBQ3RFLGlCQUFhLE1BQU0sUUFBUSxPQUFPLFNBQVMsV0FBVyxZQUFZLEVBQUUsR0FBRyxXQUFXLE9BQU8sR0FBRyxXQUFXLE1BQU0sQ0FBQztBQUFBLEVBQzlHLENBQUM7QUFDSDtBQUVBLFNBQVMsbUJBQW1CLFlBQWtDO0FBQzVELFNBQU87QUFBQSxJQUNMLElBQUksV0FBVztBQUFBLElBQ2YsT0FBTyxXQUFXO0FBQUEsSUFDbEIsTUFBTTtBQUFBLElBQ04sR0FBRyxXQUFXO0FBQUEsSUFDZCxHQUFHLFdBQVc7QUFBQSxJQUNkLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLFFBQVE7QUFBQSxJQUNSLFVBQVU7QUFBQSxJQUNWLGVBQWU7QUFBQSxJQUNmLFdBQVc7QUFBQSxJQUNYLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLGdCQUFnQjtBQUFBLElBQ2hCLFVBQVU7QUFBQSxJQUNWLFFBQVEsV0FBVztBQUFBLElBQ25CLFFBQVEsV0FBVztBQUFBLElBQ25CLE9BQU8sQ0FBQztBQUFBLElBQ1IsZUFBZSxDQUFDO0FBQUEsRUFDbEI7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLE1BQVk7QUFDM0MsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFJLEtBQUssUUFBUSxXQUFXLEVBQUc7QUFHL0IsUUFBSSxVQUFVO0FBQ2QsZUFBVyxVQUFVLEtBQUssU0FBUztBQUNqQyxhQUFPLGFBQWE7QUFDcEIsa0JBQVksRUFBRSxPQUFPLFlBQVk7QUFBQSxJQUNuQztBQUNBLGVBQVcsVUFBVSxLQUFLLFNBQVM7QUFFakMsVUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLFlBQVksT0FBTyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQzFFLGNBQU0sU0FBUyxPQUFPLFdBQVcsV0FBVyxNQUFNLE9BQU8sUUFBUSxJQUFJO0FBQ3JFLGNBQU0sV0FBVyxVQUFVLE9BQU8sS0FBSyxJQUFJLFNBQVMsYUFBYSxFQUFFLElBQUksT0FBTyxZQUFZLFVBQVUsT0FBTyxPQUFPLGVBQWUsV0FBVyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssRUFBRSxDQUFDO0FBQ2xLLG9CQUFZLE1BQU0sVUFBVSxNQUFNLGVBQWUsUUFBVyxRQUFXLEdBQUcsZ0JBQWdCLFFBQVEsT0FBTyxJQUFJO0FBQUEsTUFDL0c7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFTLE1BQUssVUFBVSxLQUFLLFFBQVEsT0FBTyxDQUFDLFdBQVcsT0FBTyxZQUFZLENBQUM7QUFBQSxFQUNsRjtBQUNGO0FBR0EsU0FBUyxtQkFBbUIsTUFBVSxRQUFZLFNBQW9CLElBQXVCLEtBQWtCLFVBQWlCO0FBQzlILFNBQU8sbUJBQWlCLG9CQUFvQixRQUFPLFNBQVEsSUFBSSxRQUFRO0FBQ3ZFLFFBQU0sVUFBUSxZQUFVLG9CQUFvQixpQkFBaUIsTUFBSyxNQUFNLEVBQUUsS0FBSyxVQUFNLEtBQUssU0FBTyxxQkFBcUIsS0FBSyxjQUFjLEtBQUcsS0FBSyxjQUFjLFFBQU8sTUFBSyxFQUFFLENBQUMsSUFBSTtBQUNsTCxhQUFXLE1BQUssUUFBTyxJQUFHLElBQUksU0FBTyx5QkFBeUIsTUFBTSxNQUFNLEdBQUUsSUFBSSxRQUFPLElBQUksT0FBTSxFQUFDLEdBQUksSUFBSSxZQUFZLEVBQUMsV0FBVSxJQUFJLFVBQVMsSUFBRSxDQUFDLEdBQUcsR0FBSSxJQUFJLFlBQVksRUFBQyxXQUFVLElBQUksVUFBUyxJQUFFLENBQUMsRUFBRSxHQUFFLFVBQVMsVUFBUSxFQUFDLE1BQUssU0FBUSxNQUFLLGtCQUFrQixRQUFPLE9BQU8sRUFBRSxJQUFFLFFBQVUsTUFBTTtBQUNqUztBQUNBLFNBQVMsa0JBQWtCLE1BQVUsTUFBVSxRQUEyQixhQUFXLE1BQUs7QUFDeEYsTUFBSSxVQUFRLFlBQVksTUFBSyxJQUFJLEVBQUUsUUFBUTtBQUMzQyxNQUFHLGNBQWMsV0FBVyxLQUFLLElBQUksR0FBRTtBQUNyQyxVQUFNLFVBQVEsaUJBQWlCLE1BQUssSUFBSSxFQUFFLE9BQU8sV0FBTyxLQUFLLGNBQWMsS0FBRyxDQUFDO0FBQy9FLFFBQUcsUUFBUSxPQUFPLFdBQVEsS0FBSyxJQUFJLEdBQUcsUUFBUSxJQUFJLFVBQU0sYUFBYSxLQUFLLElBQWlDLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUFBLEVBQ3BJO0FBQ0EsTUFBRyxDQUFDLFdBQVMsU0FBUyxNQUFLLE1BQU0sS0FBRyxRQUFRLFFBQU87QUFDbkQsUUFBTSxLQUFHLEtBQUssSUFBRSxPQUFPLEdBQUUsS0FBRyxLQUFLLElBQUUsT0FBTyxHQUFFLFNBQU8sS0FBSyxNQUFNLElBQUcsRUFBRSxLQUFHO0FBQ3RFLGFBQVcsTUFBSyxLQUFLLEtBQUcsTUFBSSxLQUFHLFVBQVEsVUFBUSxLQUFJLEtBQUssSUFBRSxLQUFHLFVBQVEsVUFBUSxLQUFJLEtBQUssS0FBSSxLQUFLLEtBQUs7QUFBRSxTQUFPO0FBQy9HO0FBQ0EsU0FBUyxhQUFhLFVBQTJCO0FBQy9DLFFBQU0sT0FBTyxPQUFPLFFBQVEsS0FBSyxlQUFlLFFBQVE7QUFDeEQsU0FBTyxPQUFPLEtBQUssU0FBUyxFQUFFLEdBQUcsU0FBUyxHQUFHLEdBQUcsU0FBUyxFQUFFO0FBQzdEO0FBQ0EsU0FBUyxtQkFBbUIsTUFBWSxRQUFzQjtBQUM1RCxRQUFNLE9BQUssV0FBVyxTQUFTLFNBQWlCLFVBQVUsU0FBUyxTQUFZLE9BQU8sTUFBTSxLQUFLLE1BQU0sS0FBSyxDQUFBTCxVQUFNQSxNQUFLLE9BQUssT0FBTyxFQUFFO0FBQ3JJLE1BQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBTSxPQUFLLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxLQUFLLEtBQU0sTUFBTTtBQUN6RSxTQUFPLFFBQVEsWUFBWSxJQUFJLEdBQUcsY0FBYyxLQUFHLEtBQUssWUFBWSxJQUFJLEdBQUcsY0FBYztBQUMzRjtBQUVBLFNBQVMsV0FBVyxNQUFVLFVBQXVCLElBQWtDLFFBQWMsUUFBaUIsT0FBYSxRQUE0QyxDQUFDLEdBQUUsV0FBUyxHQUFHLElBQUksU0FBK0csYUFBMkIsVUFBUztBQUNuVixRQUFNLFNBQVMsU0FBUyxLQUFLLFVBQVUsYUFBYSxRQUFRO0FBQzVELFFBQU0sZ0JBQWdCLG9CQUFvQixNQUFNO0FBQ2hELFFBQU0sU0FBUyxXQUFXLGlCQUFpQixNQUFLLFFBQVEsSUFBSTtBQUM1RCxRQUFNLFFBQVEsU0FBUyxhQUFhLFNBQVMsWUFBWSxRQUFPLE1BQU0sSUFBSTtBQUMxRSxRQUFNLGFBQVcsU0FBUyxLQUFLLFVBQVcsT0FBTyxRQUFRLEtBQUssZUFBZSxRQUFRLEdBQUcsVUFBVyxtQkFBbUIsTUFBSyxRQUFRO0FBQ25JLFFBQU0sYUFBVyxPQUFPLGlCQUFpQixPQUFPLGFBQVcsU0FBUyxjQUFjLE9BQU8sYUFBVyxVQUFVLFVBQVU7QUFDeEgsUUFBTSxVQUFRLEVBQUMsWUFBVyxVQUFTLFNBQVMsSUFBRyxZQUFXLE9BQU0sT0FBTyxHQUFFLE9BQU0sT0FBTyxHQUFFLFlBQVcsS0FBSSxNQUFNLEdBQUUsS0FBSSxNQUFNLEdBQUUsVUFBUyxtQkFBbUIsTUFBSyxFQUFFLEdBQUUsT0FBTSxTQUFTLE9BQU0sWUFBVyxTQUFTLE1BQUssUUFBTyxTQUFTLElBQUcsR0FBSSxVQUFRLEVBQUMsUUFBTyxRQUFRLEtBQUssR0FBRSxJQUFFLENBQUMsRUFBRTtBQUN6USxPQUFJLGVBQWEsWUFBWSxlQUFhLFlBQVksZUFBYSxpQkFBaUIsV0FBVyxPQUFPLFFBQVEsR0FBRyxXQUFVLE1BQUssZUFBYyxPQUFPLEdBQUUsT0FBTyxHQUFFLFFBQVEsSUFBRyxHQUFFLE9BQU87QUFDcEwsTUFBRyxPQUFPLGFBQVcsT0FBTTtBQUN6QixVQUFNTSxVQUFPLFdBQVMsaUJBQWlCLE1BQUssUUFBUSxJQUFFO0FBQ3RELFFBQUdBLFdBQVEsZUFBZSxNQUFLLFNBQVMsT0FBTUEsUUFBTyxLQUFLLEVBQUUsV0FBVSxNQUFLLFVBQVNBLFNBQU8sUUFBTyxNQUFNO0FBQ3hHLGNBQVUsTUFBSyxlQUFjLEdBQUcsR0FBRSxHQUFHLEdBQUUsSUFBRyxFQUFDLE9BQU0sT0FBTyxHQUFFLE9BQU0sT0FBTyxHQUFFLEtBQUksTUFBTSxHQUFFLEtBQUksTUFBTSxHQUFFLE9BQU0sU0FBUyxPQUFNLFlBQVcsU0FBUyxNQUFLLFVBQVMsU0FBUyxJQUFHLFdBQVUsQ0FBQztBQUFFO0FBQUEsRUFDbkw7QUFDQSxNQUFHLE9BQU8sYUFBVyxRQUFPO0FBQzFCLFVBQU0sT0FBSyxDQUFDLEdBQUcsS0FBSyxPQUFNLEdBQUcsS0FBSyxTQUFTLEVBQUUsT0FBTyxDQUFBQSxZQUFRQSxRQUFPLEtBQUcsTUFBSSxDQUFDLE9BQU9BLE9BQU0sS0FBRyxDQUFDLFVBQVVBLE9BQU0sTUFBSSxlQUFlLE1BQUssU0FBUyxPQUFNQSxRQUFPLEtBQUssS0FBRyxhQUFhLFFBQU8sT0FBTUEsU0FBTyxPQUFNLE9BQU8sYUFBVyxHQUFFLENBQUM7QUFDOU4sd0JBQW9CLE1BQUssTUFBSTtBQUFDLGlCQUFVQSxXQUFVLGdCQUFnQixJQUFJLEVBQUUsV0FBVSxNQUFLLFVBQVNBLFNBQU8sVUFBUSxPQUFPLFNBQU8sSUFBRyxNQUFNO0FBQUEsSUFBRSxDQUFDO0FBQ3pJLGNBQVUsTUFBSyxhQUFZLE1BQU0sR0FBRSxNQUFNLEdBQUUsUUFBUSxHQUFFLEdBQUUsRUFBQyxHQUFHLFNBQVEsUUFBTyxNQUFLLENBQUM7QUFBRTtBQUFBLEVBQ3BGO0FBQ0EsUUFBTSxTQUFPLEtBQUssSUFBSSxRQUFRLEdBQUcsR0FBRSxLQUFLLEtBQUssU0FBUyxRQUFPLEtBQUssSUFBRSxRQUFRLE9BQU8sYUFBVyxVQUFRLE1BQUksR0FBRyxDQUFDLENBQUM7QUFDL0csUUFBTSxhQUFzQixFQUFDLElBQUcsY0FBYyxLQUFLLFFBQVEsSUFBRyxPQUFNLFNBQVMsT0FBTSxZQUFXLFNBQVMsSUFBRyxVQUFTLFlBQVUsSUFBRyxPQUFNLE9BQU8sR0FBRSxPQUFNLE9BQU8sR0FBRSxLQUFJLE1BQU0sR0FBRSxLQUFJLE1BQU0sR0FBRSxRQUFPLGVBQWMsRUFBQyxHQUFHLGNBQWEsR0FBRSxXQUFVLFFBQU8sVUFBUyxRQUFPLFlBQVcsUUFBTyxFQUFDLEdBQUcsT0FBTSxHQUFFLEdBQUksT0FBTyxRQUFRLElBQUUsRUFBQyxZQUFXLFNBQVMsS0FBSSxJQUFFLENBQUMsR0FBRyxHQUFHLE1BQUs7QUFDelYsT0FBSyxZQUFZLEtBQUssVUFBVTtBQUNoQyxZQUFVLE1BQUssT0FBTyxhQUFXLFVBQVEsZ0JBQWMsYUFBWSxNQUFNLEdBQUUsTUFBTSxHQUFFLFFBQU8sRUFBQyxHQUFHLFNBQVEsUUFBTyxPQUFPLFVBQVEsRUFBQyxDQUFDO0FBQ2hJO0FBQ0EsU0FBUyxVQUFVLE1BQVUsVUFBdUIsUUFBOEIsUUFBYyxRQUFpQixRQUFNLEdBQUUsV0FBa0IsU0FBTyxZQUFZLFVBQVMsTUFBTSxHQUFFLFVBQXNCLG9CQUFvQixNQUFNLEdBQUUsY0FBa0M7QUFDalEsUUFBTSxRQUFNLGFBQWEsUUFBTyxRQUFPLENBQUMsT0FBTyxNQUFNLEdBQUUsT0FBTyxNQUFNLEtBQUcsVUFBVSxPQUFPLElBQUksTUFBSSxPQUFNLEtBQUs7QUFDM0csUUFBTSxRQUFNLFlBQVksTUFBSyxVQUFTLFFBQU8sT0FBTSxvQkFBb0IsTUFBSyxVQUFTLE1BQU0sR0FBRSxRQUFPLE9BQU8sZUFBZSxPQUFPLFVBQVUsR0FBRSxPQUFPO0FBQUUsTUFBRyxVQUFRLE9BQVU7QUFDM0ssZUFBYSxNQUFLLFFBQU8sT0FBTSxVQUFTLE9BQU8sY0FBYSxZQUFZO0FBQ3hFLE1BQUcsYUFBVyxPQUFPLE1BQU0sS0FBRyxPQUFPLEtBQUcsRUFBRSxXQUFVLFFBQU8sRUFBQyxNQUFLLFFBQU8sV0FBVSxVQUFTLENBQUM7QUFDOUY7QUFDQSxTQUFTLGFBQWEsTUFBVSxZQUFzQjtBQUNwRCxRQUFNLFNBQU8sV0FBVztBQUV4QixRQUFNLGFBQVcsV0FBVyxNQUFLLFdBQVcsVUFBVTtBQUN0RCxRQUFNLFNBQU8sWUFBWSxVQUFRLFdBQVcsUUFBUSxhQUFhO0FBQ2pFLFFBQU0sV0FBUyxtQkFBbUIsVUFBVTtBQUM1QyxRQUFNLFdBQVMsV0FBUyxXQUFXLGFBQVcsRUFBQyxHQUFHLFVBQVMsTUFBSyxXQUFXLFlBQVcsT0FBTSxFQUFDLE1BQUssT0FBTSxHQUFFLFNBQVEsQ0FBQyxHQUFFLElBQUcsR0FBRSxPQUFNLEdBQUUsT0FBTSxHQUFFLGlCQUFnQixHQUFFLE9BQU0sRUFBQyxJQUFxQjtBQUN4TCxRQUFNLE9BQUssRUFBQyxHQUFFLFdBQVcsT0FBTSxHQUFFLFdBQVcsTUFBSyxHQUFFLEtBQUcsRUFBQyxHQUFFLFdBQVcsS0FBSSxHQUFFLFdBQVcsSUFBRztBQUN4RixRQUFNLGVBQWEsU0FBUyxNQUFLLEVBQUUsR0FBRSxXQUFTLENBQUMsVUFBZTtBQUFDLFVBQU0sUUFBTSxlQUFhLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxHQUFFLFFBQU0sWUFBWSxDQUFDLElBQUU7QUFBRSxXQUFNLEVBQUMsR0FBRSxLQUFLLEtBQUcsR0FBRyxJQUFFLEtBQUssS0FBRyxPQUFNLEdBQUUsS0FBSyxLQUFHLEdBQUcsSUFBRSxLQUFLLEtBQUcsTUFBSztBQUFBLEVBQUU7QUFDdk0sUUFBTSxPQUFLLENBQUMsR0FBRyxLQUFLLE9BQU0sR0FBRyxLQUFLLFdBQVUsR0FBSSxLQUFLLGFBQVcsQ0FBQyxDQUFFLEVBQUUsT0FBTyxPQUFHLEVBQUUsS0FBRyxNQUFJLENBQUMsT0FBTyxDQUFDLEtBQUcsQ0FBQyxVQUFVLENBQUMsTUFBSSxlQUFlLE1BQUssV0FBVyxPQUFNLEVBQUUsS0FBSyxDQUFDO0FBQ2pLLE1BQUcsT0FBTyxhQUFXLFFBQU87QUFDMUIsVUFBTSxnQkFBYyxLQUFLLElBQUksYUFBUyxFQUFDLFFBQU8sT0FBTSxpQkFBaUIsTUFBSyxJQUFHLFFBQU8sT0FBTyxVQUFRLEVBQUUsRUFBQyxFQUFFLEVBQUUsT0FBTyxPQUFHLEVBQUUsVUFBUSxNQUFTLEVBQUUsS0FBSyxDQUFDLEdBQUUsTUFBSSxFQUFFLFFBQU8sRUFBRSxLQUFNO0FBQ3RLLFVBQU0sV0FBUyxJQUFJLElBQUksZ0JBQWdCLGNBQWMsSUFBSSxTQUFLLElBQUksTUFBTSxDQUFDLENBQUM7QUFDMUUsVUFBTSxPQUFLLGNBQWMsT0FBTyxTQUFLLFNBQVMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxFQUFFLE1BQU0sR0FBRSxPQUFPLFdBQVMsQ0FBQztBQUN4RixRQUFHLE9BQU8sZUFBZSxLQUFLLENBQUMsR0FBRTtBQUMvQixZQUFNLFNBQU8sU0FBUyxLQUFLLENBQUMsRUFBRSxLQUFNO0FBQ3BDLGlCQUFVLFVBQVUsZ0JBQWdCLEtBQUssT0FBTyxDQUFBQSxZQUFRLFFBQVEsUUFBT0EsT0FBTSxLQUFHLE9BQU8sV0FBWSxDQUFDLEdBQUc7QUFDckcsY0FBTSxRQUFNLEtBQUssSUFBSSxLQUFHLElBQUUsUUFBUSxRQUFPLE1BQU0sSUFBRSxPQUFPLGNBQVksR0FBRTtBQUN0RSxrQkFBVSxNQUFLLFVBQVMsUUFBTyxXQUFXLFFBQU8sUUFBTyxPQUFNLFdBQVcsV0FBVSxRQUFPLFdBQVcsZUFBYyxJQUFJO0FBQUEsTUFDekg7QUFDQSxnQkFBVSxNQUFLLGVBQWMsT0FBTyxHQUFFLE9BQU8sR0FBRSxRQUFRLElBQUcsR0FBRSxFQUFDLFFBQU8sT0FBTyxhQUFZLE9BQU0sV0FBVyxPQUFNLEdBQUksV0FBVyxhQUFXLEVBQUMsWUFBVyxXQUFXLFdBQVUsSUFBRSxDQUFDLEVBQUUsQ0FBQztBQUMvSztBQUFBLElBQ0Y7QUFDQSxTQUFLLFFBQVEsQ0FBQyxFQUFDLFFBQU8sTUFBSyxHQUFFLE1BQUksVUFBVSxNQUFLLFVBQVMsUUFBTyxXQUFXLFFBQU8sU0FBUSxPQUFPLGVBQWEsTUFBSSxHQUFFLFdBQVcsV0FBVSxTQUFTLEtBQU0sR0FBRSxXQUFXLGVBQWMsSUFBSSxDQUFDO0FBQUEsRUFDMUwsT0FBSztBQUNILGVBQVUsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLENBQUFBLFlBQVEsUUFBUSxJQUFHQSxPQUFNLE1BQUksT0FBTyxVQUFRLEVBQUUsQ0FBQyxHQUFFO0FBQUMsWUFBTSxNQUFJLFFBQVEsSUFBRyxNQUFNO0FBQzNILFlBQU0sVUFBUSxLQUFLLElBQUksTUFBSSxJQUFFLE1BQUksS0FBSyxJQUFJLEdBQUUsT0FBTyxVQUFRLENBQUMsSUFBRSxJQUFHO0FBQUUsZ0JBQVUsTUFBSyxVQUFTLFFBQU8sV0FBVyxRQUFPLFFBQU8sU0FBUSxXQUFXLFdBQVUsSUFBRyxXQUFXLGVBQWMsSUFBSTtBQUFBLElBQzFMO0FBQ0EsY0FBVSxNQUFLLGVBQWMsR0FBRyxHQUFFLEdBQUcsR0FBRSxJQUFHLEVBQUMsUUFBTyxPQUFPLFVBQVEsR0FBRSxPQUFNLFdBQVcsT0FBTSxHQUFJLFdBQVcsYUFBVyxFQUFDLFlBQVcsV0FBVyxXQUFVLElBQUUsQ0FBQyxFQUFFLENBQUM7QUFDM0osUUFBRyxXQUFXLFVBQVUsV0FBVSxNQUFLLGlCQUFnQixHQUFHLEdBQUUsR0FBRyxHQUFFLFdBQVcsV0FBVSxFQUFDLE9BQU0sV0FBVyxPQUFNLFFBQU8sV0FBVyxZQUFXLFFBQU8sR0FBRSxlQUFjLEVBQUMsR0FBRyxnQkFBZ0IsUUFBTyxHQUFFLFFBQU8sT0FBTyxVQUFRLEdBQUUsV0FBVSxJQUFHLEdBQUksV0FBVyxhQUFXLEVBQUMsWUFBVyxXQUFXLFdBQVUsSUFBRSxDQUFDLEVBQUUsQ0FBQztBQUFBLEVBQ3ZTO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUFZLFVBQTJCLFFBQW9DLFFBQWdCLGFBQXFCO0FBQ3pJLE1BQUksQ0FBQyxXQUFXLE1BQU0sRUFBRyxVQUFPLGtCQUFrQixNQUFLLFVBQVMsTUFBTTtBQUN0RSxNQUFHLE9BQU8sUUFBUSxLQUFLLFlBQVksUUFBUSxLQUFLLENBQUMsVUFBVSxNQUFLLFFBQVEsRUFBRSxnQkFBZ0I7QUFDMUYsUUFBTSxTQUFTLE9BQU8sUUFBUSxJQUFJLFlBQVksTUFBTSxRQUFRLEVBQUUsU0FBUztBQUN2RSxNQUFJLFFBQVE7QUFDVixRQUFJLE9BQU8sWUFBWSxTQUFTLFVBQVUsTUFBTSxJQUFJLE9BQU8sU0FBVTtBQUNyRSxlQUFXLE1BQU0sVUFBVSxRQUFRLFFBQVEsUUFBUSxXQUFXO0FBQzlEO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBWSxPQUFPLFFBQVEsSUFBSSxZQUFZLE1BQU0sUUFBUSxFQUFFLGNBQWM7QUFDL0UsTUFBSSxZQUFZLCtCQUErQjtBQUM3QyxxQkFBaUIsTUFBTSxVQUFVLFFBQVEscUJBQXFCLFVBQVUsUUFBUSxNQUFNLENBQUM7QUFDdkY7QUFBQSxFQUNGO0FBRUEsb0JBQWtCLE1BQU0sVUFBVSxRQUFRLFFBQVEsU0FBUztBQUM3RDtBQUVBLFNBQVMsaUJBQWlCLE1BQVksVUFBMkIsUUFBb0MsUUFBZ0I7QUFDbkgsUUFBTSxLQUFLLE9BQU8sSUFBSSxTQUFTO0FBQy9CLFFBQU0sS0FBSyxPQUFPLElBQUksU0FBUztBQUMvQixRQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxFQUFFLElBQUksUUFBUSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzlGLFFBQU0sYUFBYTtBQUFBLElBQ2pCLFlBQVksY0FBYyxTQUFTLElBQUk7QUFBQSxJQUN2QyxlQUFlLEVBQUUsR0FBSSxPQUFPLFFBQVEsSUFBSSx3QkFBd0IsTUFBTSxRQUFRLElBQUksb0JBQW9CLFNBQVMsSUFBSSxFQUFHO0FBQUEsSUFDdEgsSUFBSSxjQUFjLEtBQUssTUFBTTtBQUFBLElBQzdCLE9BQU8sU0FBUztBQUFBLElBQ2hCLFlBQVksU0FBUztBQUFBLElBQ3JCLFVBQVUsT0FBTztBQUFBLElBQ2pCLE9BQU8sU0FBUztBQUFBLElBQ2hCLE9BQU8sU0FBUztBQUFBLElBQ2hCLEtBQUssT0FBTztBQUFBLElBQ1osS0FBSyxPQUFPO0FBQUEsSUFDWjtBQUFBLElBQ0EsV0FBVztBQUFBLElBQ1gsVUFBVTtBQUFBLElBQ1YsR0FBSSxPQUFPLFFBQVEsSUFBSSxFQUFFLFlBQVksU0FBUyxLQUFLLElBQUksQ0FBQztBQUFBLElBQ3hELGlCQUFpQixvQkFBb0IsTUFBSyxRQUFRO0FBQUEsRUFDcEQ7QUFDQSxPQUFLLFVBQVU7QUFDZixPQUFLLFlBQVksS0FBSyxVQUFVO0FBQ2hDLFlBQVUsTUFBTSxjQUFjLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUTtBQUFBLElBQ3hELFVBQVUsU0FBUztBQUFBLElBQ25CLE9BQU8sU0FBUztBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLE9BQU8sV0FBVztBQUFBLElBQ2xCLE9BQU8sV0FBVztBQUFBLElBQ2xCLEtBQUssV0FBVztBQUFBLElBQ2hCLEtBQUssV0FBVztBQUFBLElBQ2hCLFlBQVksU0FBUztBQUFBLElBQ3JCLFlBQVksV0FBVztBQUFBLElBQ3ZCLFlBQVksbUJBQW1CLE1BQUssUUFBUTtBQUFBLElBQzVDLFVBQVUsbUJBQW1CLE1BQUssTUFBTTtBQUFBLEVBQzFDLENBQUM7QUFDSDtBQUVBLFNBQVMsa0JBQWtCLE1BQVksVUFBMkIsUUFBb0MsUUFBZ0IsYUFBcUIsU0FBeUI7QUFDbEssY0FBWSxPQUFPLFFBQVEsSUFBSSx3QkFBd0IsTUFBTSxRQUFRLElBQUksb0JBQW9CLFNBQVMsSUFBSTtBQUMxRyxRQUFNLFFBQVEsUUFBUSxXQUFXLFVBQVUsU0FBUywwQkFBMEIsTUFBTSxVQUFVLFFBQVEscUJBQXFCLFVBQVUsUUFBUSxNQUFNLENBQUM7QUFDcEosUUFBTSxRQUFRLFlBQVksTUFBTSxVQUFVLFFBQVEsT0FBTyxRQUFXLFFBQVcsR0FBRyxPQUFPO0FBQ3pGLE1BQUksVUFBVSxPQUFXO0FBQ3pCLE1BQUksUUFBUSxXQUFXLFFBQVMsMEJBQXlCLE1BQU0sVUFBVSxRQUFRLFNBQVMsSUFBSTtBQUM5RixNQUFJLFFBQVEsYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLE9BQU8sUUFBUSxLQUFLLE9BQU8sTUFBTSxFQUFHLFlBQVcsVUFBVSxRQUFRLEtBQUs7QUFDeEksUUFBTSxPQUFPLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxTQUFTLEVBQUU7QUFDNUMsUUFBTSxLQUFLLEVBQUUsR0FBRyxPQUFPLEdBQUcsR0FBRyxPQUFPLEVBQUU7QUFDdEMsUUFBTSxPQUE0QixjQUFjLGdDQUFnQyxlQUFlO0FBQy9GLFlBQVUsTUFBTSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsU0FBUyxlQUFlLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSyxHQUFHLE9BQU8sS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLFlBQVksbUJBQW1CLE1BQUssUUFBUSxHQUFHLFVBQVUsbUJBQW1CLE1BQUssTUFBTSxHQUFHLEdBQUksT0FBTyxRQUFRLElBQUUsRUFBQyxVQUFVLFNBQVMsSUFBSSxZQUFZLFFBQVEsV0FBVyxVQUFVLFNBQWtCLFNBQWlCLElBQUUsQ0FBQyxFQUFHLENBQUM7QUFDblYsZUFBYSxNQUFNLFFBQVEsT0FBTyxRQUFRO0FBQzVDO0FBS0EsU0FBUyxhQUFhLE1BQVksUUFBb0MsT0FBZSxTQUEyQixZQUF5QixjQUFvQztBQUMzSyxpQkFBZSxVQUFVLE9BQU8sT0FBTyxLQUFLLFlBQVksTUFBSyxPQUFPLEVBQUUsZUFBYSxnQ0FBZ0MsVUFBVSxjQUFjLFFBQVEsSUFBSSxJQUFJO0FBQzNKLFFBQU0sU0FBTyxnQkFBYztBQUMzQixRQUFNLE9BQUssT0FBTyxNQUFNLEtBQUcsT0FBTztBQUNsQyxRQUFNLE9BQUssT0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxLQUFLLE1BQU0sSUFBSTtBQUNqRSxZQUFVLE1BQU0sT0FBTyxPQUFPLEdBQUcsT0FBTyxHQUFHLElBQUksRUFBRSxRQUFRLE9BQU8sSUFBSSxRQUFRLE9BQU8sR0FBSSxhQUFhLEVBQUMsV0FBVSxJQUFJLENBQUMsR0FBSSxHQUFJLFVBQVUsRUFBRSxZQUFZLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBSSxHQUFJLFNBQU8sRUFBQyxPQUFNLE9BQU8sR0FBRSxPQUFNLE9BQU8sRUFBQyxJQUFFLENBQUMsR0FBSSxHQUFJLFFBQU0sT0FBSyxFQUFDLFlBQVcsRUFBQyxHQUFHLE1BQUssU0FBUSxLQUFLLFNBQVMsV0FBUyxFQUFDLEdBQUUsVUFBUyxtQkFBbUIsTUFBSyxNQUFNLEVBQUMsSUFBRSxDQUFDLEdBQUksR0FBSSxPQUFPLE1BQU0sSUFBSSxFQUFFLFlBQVksT0FBTyxNQUFNLGVBQWUsT0FBTyxJQUFJLGFBQWEsT0FBTyxPQUFPLGNBQWMsT0FBTyxRQUFRLGlCQUFpQixZQUFZLFFBQVEsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFHLENBQUM7QUFDdmdCO0FBRUEsU0FBUyxxQkFBcUIsVUFBMkIsUUFBb0MsUUFBZ0I7QUFDM0csTUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sVUFBVSxVQUFXLFFBQU87QUFDOUUsU0FBTyxVQUFVLGNBQWMsU0FBUyxJQUFJLEdBQUcsMkJBQTJCO0FBQzVFO0FBRUEsU0FBUywwQkFBMEIsTUFBWSxVQUEyQixRQUFvQyxRQUFnQjtBQUM1SCxNQUFJLENBQUMsT0FBTyxRQUFRLEtBQUssQ0FBQyxPQUFPLE1BQU0sRUFBRyxRQUFPO0FBQ2pELFFBQU0sU0FBUyxVQUFVLE1BQU0sUUFBUSxFQUFFO0FBQ3pDLFFBQU0sUUFBUSxVQUFVLG1CQUFtQixNQUFNLElBQUksS0FBSyxNQUFNLFNBQVMsTUFBTSxJQUFJO0FBQ25GLE1BQUksQ0FBQyxPQUFPLFFBQVEsS0FBSyxDQUFDLFdBQVcsT0FBTyxTQUFTLFFBQVEsRUFBRyxRQUFPO0FBQ3ZFLE1BQUksU0FBUyxTQUFTLGVBQWdCLFFBQU8sUUFBUTtBQUNyRCxNQUFJLFNBQVMsU0FBUyxlQUFnQixRQUFPLFFBQVE7QUFDckQsU0FBTztBQUNUO0FBR0EsU0FBUyxXQUFXLFVBQWdCLFFBQWMsT0FBZTtBQUMvRCxNQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sTUFBTSxFQUFHO0FBQ3hDLFFBQU0sV0FBVyxhQUFhLE9BQU8sTUFBTTtBQUMzQyxRQUFNLEtBQUssT0FBTyxJQUFJLFNBQVM7QUFDL0IsUUFBTSxLQUFLLE9BQU8sSUFBSSxTQUFTO0FBQy9CLFFBQU0sUUFBUSxJQUFJLElBQUksUUFBUTtBQUM5QixNQUFJLFNBQVMsV0FBVyxRQUFTLE9BQU0sVUFBVSxJQUFJLElBQUksY0FBYyxVQUFVLFFBQVEsQ0FBQztBQUM1RjtBQUdBLFNBQVMsbUJBQW1CLE1BQVk7QUFDdEMsU0FBTyxLQUFLLGdCQUFnQixVQUFhLFNBQVMsS0FBSyxJQUFJO0FBQzdEO0FBRUEsU0FBUyx5QkFBeUIsTUFBWSxVQUEyQixRQUFvQyxZQUFtRDtBQUM5SixNQUFJLGVBQWUsaUJBQWlCLE9BQU8sTUFBTSxLQUFLLENBQUMsT0FBTyxRQUFRLFVBQVUsT0FBTyxJQUFJLE1BQU0sVUFDNUYsYUFBYSxTQUFTLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxHQUFHO0FBQ3BELGNBQVUsTUFBTSxpQkFBaUIsT0FBTyxHQUFHLE9BQU8sR0FBRyxXQUFXLFVBQVU7QUFBQSxNQUN4RSxPQUFPLFNBQVM7QUFBQSxNQUFPLFFBQVEsU0FBUztBQUFBLE1BQUk7QUFBQSxNQUFZLGVBQWUsZ0JBQWdCO0FBQUEsTUFDdkYsUUFBUSxXQUFXO0FBQUEsTUFBUSxRQUFRLFdBQVc7QUFBQSxNQUFRLFdBQVcsV0FBVztBQUFBLElBQzlFLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxDQUFDLE9BQU8sUUFBUSxFQUFHO0FBQ3ZCLFFBQU0sUUFBUSxVQUFVLE1BQU0sUUFBUTtBQUV0QyxNQUFJLE1BQU0sUUFBUTtBQUNoQixVQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLFNBQVMsZUFBZSxZQUFZLENBQUM7QUFDMUUsVUFBTSxTQUFpQixDQUFDO0FBQ3hCLHNCQUFrQixNQUFNLFFBQVEsZUFBZSxDQUFDLFNBQVM7QUFDdkQsVUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLLEtBQUssU0FBUyxNQUFNLE1BQU0sS0FBSyxpQkFBaUIsZUFBZSxNQUFNLFNBQVMsT0FBTyxLQUFLLEtBQUssRUFBRyxRQUFPLEtBQUssSUFBSTtBQUFBLElBQ3JKLENBQUM7QUFDRCxlQUFXLFFBQVEsT0FBUSxhQUFZLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBVyxRQUFXLEdBQUcsd0JBQXdCLE1BQU0sUUFBUSxDQUFDO0FBQ3BJLGNBQVUsTUFBTSxhQUFhLE9BQU8sR0FBRyxPQUFPLEdBQUcsRUFBRTtBQUFBLEVBQ3JEO0FBQ0EsTUFBSSxDQUFDLE9BQU8sTUFBTSxFQUFHO0FBQ3JCLE1BQUksTUFBTSxVQUFXLFdBQVUsUUFBUSxFQUFFLE1BQU0sUUFBUSxXQUFXLFdBQVcsQ0FBQztBQUM5RSxNQUFJLE1BQU0sWUFBYSxXQUFVLFFBQVEsRUFBRSxNQUFNLFVBQVUsV0FBVyxjQUFjLFVBQVUsU0FBUyxJQUFJLGFBQWEsU0FBUyxNQUFNLENBQUM7QUFDMUk7QUFHQSxTQUFTLFlBQVksTUFBWSxVQUEyQixRQUFvQyxRQUFnQixXQUFtQixRQUE0QixjQUFZLEdBQUcsVUFBeUIsT0FBTyxRQUFRLElBQUksd0JBQXdCLE1BQU0sUUFBUSxJQUFJLG9CQUFvQixTQUFTLElBQUksR0FBRyxzQkFBc0IsT0FBTyxpQkFBaUIsT0FBMkI7QUFDL1csTUFBSSxPQUFPLFFBQVEsS0FBSyxVQUFVLFFBQVEsRUFBRyxRQUFPO0FBRXBELE1BQUksT0FBTyxNQUFNLEtBQUssaUJBQWlCLE1BQUssTUFBTSxLQUFLLENBQUMsZUFBZ0IsUUFBTztBQUMvRSxNQUFJLGtCQUFrQixVQUFVLE9BQU8sYUFBYyxRQUFPO0FBQzVELE1BQUksV0FBVyxNQUFNLEdBQUc7QUFFdEIsVUFBTUUsWUFBVyxPQUFPO0FBQ3hCLFdBQU8sTUFBTTtBQUNiLFNBQUssVUFBVSxJQUFJLFVBQVUsUUFBUSxRQUFRQSxTQUFRO0FBQ3JELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxlQUFlO0FBQ3JCLFFBQU0sV0FBVyxPQUFPLE1BQU0sSUFBSSxrQkFBa0IsTUFBTSxRQUFRLFFBQVEsU0FBUyxLQUFLLGNBQWMsSUFBSSxPQUFPLEVBQUUsR0FBRyxZQUFZLEVBQUUsb0JBQW9CLENBQUMsSUFBSTtBQUM3SixNQUFJLFVBQVUsUUFBUyxRQUFPO0FBQzlCLFFBQU0sUUFBUSxVQUFVLFVBQVU7QUFDbEMsUUFBTSxXQUFXLE9BQU87QUFDeEIsU0FBTyxNQUFNO0FBQ2IsTUFBRyxPQUFPLE1BQU0sS0FBSyxZQUFZLE1BQU0sR0FBRTtBQUN2QyxzQkFBa0IsUUFBTyxLQUFLO0FBQzlCLG9CQUFnQixNQUFLLFFBQU8sVUFBVSxZQUFZLFVBQVMsTUFBTSxHQUFFLE9BQU0sV0FBVztBQUNwRixRQUFHLE9BQU8sS0FBRyxHQUFHO0FBQ2QsNEJBQXNCLE1BQUssTUFBTTtBQUNqQyw0QkFBc0IsSUFBSTtBQUcxQixpQkFBVyxhQUFhLGVBQWUsS0FBSyxPQUFNLE1BQU0sRUFBRyxLQUFJLFVBQVUsS0FBRyxLQUFLLFVBQVUsU0FBUyxLQUFLLENBQUMsaUJBQWlCLE1BQUssU0FBUyxFQUFHLGFBQVksTUFBSyxVQUFTLFdBQVUsUUFBTSxNQUFJLEdBQUUsUUFBTyxHQUFFLE9BQU87QUFBQSxJQUM5TTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsS0FBSyxPQUFPLE1BQU0sR0FBRztBQUNsQyxRQUFJLFlBQVksTUFBTSxLQUFLLEtBQUssaUJBQWlCO0FBQy9DLFlBQU0sUUFBUSxLQUFLLGdCQUFnQixJQUFJLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxRQUFRLFFBQVEsR0FBRyxZQUFZLEVBQUU7QUFDOUYsWUFBTSxVQUFVO0FBQ2hCLFdBQUssZ0JBQWdCLElBQUksT0FBTyxJQUFJLEtBQUs7QUFBQSxJQUMzQztBQUNBLFVBQU0sT0FBTyxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssVUFBUSxLQUFLLE9BQU8sT0FBTyxLQUFNLFVBQVUsS0FBSyxLQUFLLENBQUM7QUFDbEcsUUFBSSxRQUFRLGVBQWUsTUFBTSxTQUFTLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDNUQsWUFBTSxhQUFhLGdCQUFnQixhQUFhLG9CQUFvQixNQUFLLFFBQVE7QUFDakYsVUFBSSxLQUFLLGlCQUFpQjtBQUN4QixjQUFNLFFBQVEsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxRQUFRLEdBQUcsWUFBWSxHQUFHLFFBQVEsU0FBUztBQUM1RyxZQUFJLGFBQWEsTUFBTSxZQUFZO0FBQUUsZ0JBQU0sYUFBYTtBQUFZLGdCQUFNLFNBQVM7QUFBVSxnQkFBTSxVQUFVO0FBQUEsUUFBUztBQUN0SCxhQUFLLGdCQUFnQixJQUFJLEtBQUssSUFBRyxFQUFDLEdBQUcsT0FBTSxRQUFPLEVBQUMsR0FBRSxPQUFPLEdBQUUsR0FBRSxPQUFPLEVBQUMsR0FBRSxZQUFXLENBQUM7QUFBQSxNQUN4RixXQUFXLGFBQWEsRUFBRyxhQUFZLE1BQU0sVUFBVSxNQUFNLFlBQVksR0FBRSxRQUFPLEdBQUUsT0FBTztBQUFBLElBQzdGO0FBQUEsRUFDRjtBQUNBLE9BQUssVUFBVSxJQUFJLFVBQVUsUUFBUSxPQUFPLFFBQVE7QUFDcEQsTUFBSSxXQUFXLEtBQUssT0FBTyxNQUFNLEtBQUssT0FBTyxVQUFVLFVBQVcsc0JBQXFCLE1BQU0sUUFBUSxRQUFRO0FBQzdHLE1BQUksV0FBVyxLQUFLLFdBQVcsT0FBTyxLQUFLLEVBQUcsb0JBQW1CLE1BQU0sUUFBUSxRQUFRO0FBQ3ZGLE1BQUksV0FBVyxLQUFLLE9BQU8sTUFBTSxHQUFHO0FBQ2xDLGVBQVcsTUFBTSxVQUFVLE1BQU07QUFBQSxFQUNuQztBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsb0JBQW9CLE1BQVksTUFBa0I7QUFDekQsTUFBSSxLQUFLLGlCQUFpQjtBQUFFLFNBQUs7QUFBRztBQUFBLEVBQVE7QUFDNUMsUUFBTSxRQUE4QyxvQkFBSSxJQUFJO0FBQzVELE9BQUssa0JBQWtCO0FBQ3ZCLE1BQUk7QUFBRSxTQUFLO0FBQUEsRUFBRyxVQUFFO0FBQVUsV0FBTyxLQUFLO0FBQUEsRUFBaUI7QUFDdkQsYUFBVyxFQUFFLE1BQU0sUUFBUSxZQUFZLFFBQU8sUUFBTyxhQUFZLFFBQVEsS0FBSyxNQUFNLE9BQU8sR0FBRztBQUM1RixRQUFJLFVBQVUsS0FBSyxLQUFLLEtBQUssYUFBYSxPQUFRLGFBQVksTUFBTSxRQUFRLE1BQU0sYUFBYSxRQUFRLEdBQUUsUUFBTyxhQUFZLE9BQU87QUFBQSxFQUNySTtBQUNGO0FBR0EsU0FBUyxrQkFBa0IsTUFBWSxVQUEyQixRQUF5QixZQUFVLFVBQTJCO0FBQzlILE1BQUksQ0FBQyxPQUFPLE1BQU0sS0FBSyxDQUFDLFlBQVksTUFBTSxFQUFHLFFBQU87QUFDcEQsUUFBTSxPQUFLLE9BQU8sUUFBUSxLQUFLLFNBQVMsUUFBUSxVQUFVLE1BQUssUUFBUSxFQUFFLGVBQWEsZ0NBQ2xGLEtBQUssTUFBTSxLQUFLLFVBQU0sS0FBSyxPQUFLLFNBQVMsS0FBTSxNQUFNLElBQUk7QUFHN0QsUUFBTSxhQUFXLFFBQVEsS0FBSyxPQUFLLE9BQU8sTUFBTSxpQkFBaUIsTUFBSyxRQUFPLFFBQWdCLElBQ3pGLENBQUMsR0FBRyxlQUFlLEtBQUssT0FBTSxNQUFNLEdBQUUsR0FBRyxlQUFlLEtBQUssT0FBTSxJQUFJLENBQUMsSUFBSSxlQUFlLEtBQUssT0FBTSxNQUFNO0FBQ2hILFFBQU0sT0FBTyxXQUFXLE9BQU8sVUFBUSxLQUFLLEtBQUssS0FBSyxDQUFDLFVBQVUsSUFBSSxLQUFLLGVBQWUsTUFBTSxTQUFTLE9BQU8sS0FBSyxLQUFLLE1BQU0sY0FBWSxZQUFZLGdCQUFnQixVQUFTLElBQUksS0FBRyxZQUFVLGVBQzNMLE9BQU8sUUFBUSxJQUFJLFNBQVMsS0FBSyxLQUFLLFVBQVUsTUFBTSxLQUFLLEtBQUssSUFBSSxTQUFTLFVBQVMsSUFBSSxLQUFHLFNBQVMsWUFBWTtBQUN4SCxNQUFJLE1BQXdCLFlBQVk7QUFDeEMsYUFBVyxRQUFRLE1BQU07QUFDdkIsVUFBTSxRQUFRLG9CQUFvQixNQUFNLFNBQVMsT0FBTyxNQUFNLGdCQUFnQixVQUFVLElBQUksR0FBRyxPQUFPLFFBQVEsSUFBSSxXQUFXLE1BQVM7QUFDdEksUUFBSSxRQUFRLFdBQVc7QUFBRSxhQUFPO0FBQU0sa0JBQVk7QUFBQSxJQUFPO0FBQUEsRUFDM0Q7QUFDQSxTQUFPLFFBQVEsS0FBSyxDQUFDLEtBQUs7QUFDNUI7QUFFQSxTQUFTLHFCQUFxQixNQUFZLGdCQUFzQixVQUEyQjtBQUN6RixNQUFJLENBQUMsZUFBZSxNQUFNLGVBQWUsT0FBTyxTQUFTLEtBQUssRUFBRztBQUNqRSxRQUFNLFNBQVMsMEJBQTBCLGNBQWM7QUFFdkQsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFJLEtBQUssVUFBVSxhQUFhLEtBQUssTUFBTSxFQUFHO0FBQzlDLFFBQUksU0FBUyxNQUFNLGNBQWMsSUFBSSxxQkFBc0I7QUFDM0QsUUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLE1BQU0sVUFBVSxLQUFLLEtBQUssRUFBRztBQUNyRCxVQUFNLGlCQUFpQixzQkFBc0IsSUFBSSxLQUFLO0FBQ3RELFFBQUksU0FBUyxVQUFVLGNBQWMsSUFBSSw4QkFBK0I7QUFDeEUsUUFBSSw0QkFBNEIsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNLFNBQVMsVUFBVTtBQUMzRSxVQUFJLHVCQUF1QixNQUFNLE1BQU0sS0FBSyxNQUFNLFVBQVUsVUFBVSxjQUFjLEVBQUcsTUFBSyxRQUFRLEVBQUUsR0FBRyxLQUFLLE9BQU8sVUFBVSxTQUFTLEdBQUc7QUFBQSxJQUM3SSxNQUFPLE1BQUssUUFBUSxFQUFFLE1BQU0sVUFBVSxVQUFVLFNBQVMsSUFBSSxRQUFRLE9BQU8sR0FBRyxRQUFRLE9BQU8sRUFBRTtBQUFBLEVBQ2xHO0FBQ0Y7QUFLQSxTQUFTLG1CQUFtQixNQUFZLFFBQXlCLFVBQTJCO0FBQzFGLE1BQUksQ0FBQyxlQUFlLE1BQU0sT0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsTUFBTSxLQUFLLFdBQVcsTUFBTSxTQUFTLEVBQUUsTUFBTSxTQUFVO0FBQzNILE1BQUksT0FBTyxNQUFNLEVBQUcsZ0JBQWUsTUFBTSxRQUFRLFVBQVUsTUFBTTtBQUNqRSxRQUFNLFFBQVEsbUJBQW1CLE9BQU8sTUFBTSxJQUFJLElBQUksT0FBTztBQUM3RCxvQkFBa0IsTUFBTSxRQUFRLE9BQU8sQ0FBQyxTQUFTO0FBQy9DLFFBQUksU0FBUyxVQUFVLEtBQUssVUFBVSxPQUFPLFNBQVMsU0FBUyxNQUFNLE1BQU0sSUFBSSxNQUFPO0FBQ3RGLG1CQUFlLE1BQU0sTUFBTSxVQUFVLE1BQU07QUFBQSxFQUM3QyxDQUFDO0FBQ0g7QUFFQSxTQUFTLGVBQWUsTUFBWSxNQUFZLFVBQTJCLFFBQXlCO0FBQ2xHLE1BQUksS0FBSyxNQUFNLEtBQUssS0FBSyxTQUFTLFlBQVksS0FBSyxnQkFBZ0IsS0FBSyxDQUFDLFNBQVMsS0FBSyxLQUFLLE1BQU0sVUFBVSxLQUFLLEtBQUssRUFBRztBQUN6SCxRQUFNLFFBQVEsS0FBSztBQUNuQixNQUFHLFlBQVksSUFBSSxLQUFLLE1BQU0sU0FBTyxPQUFPO0FBQzVDLE1BQUksTUFBTSxTQUFTLFFBQVE7QUFDekIsUUFBSSxDQUFDLEtBQUssWUFBWSxPQUFRLE1BQUssUUFBUSxFQUFFLE1BQU0sVUFBVSxVQUFVLFNBQVMsSUFBSSxRQUFRLEtBQUssR0FBRyxRQUFRLEtBQUssRUFBRTtBQUNuSDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLE1BQU0sU0FBUyxjQUFjO0FBQy9CLFFBQUksQ0FBQyxNQUFNLFlBQVksdUJBQXVCLE1BQU0sTUFBTSxNQUFNLFVBQVUsVUFBVSxNQUFNLEVBQUcsTUFBSyxRQUFRLEVBQUUsR0FBRyxPQUFPLFVBQVUsU0FBUyxHQUFHO0FBQzVJO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZSxNQUFNLFNBQVMsWUFBWSxNQUFNLFdBQVc7QUFDakUsTUFBSSxnQkFBZ0IsdUJBQXVCLE1BQU0sTUFBTSxNQUFNLFVBQVUsVUFBVSxNQUFNLEVBQUcsTUFBSyxRQUFRLEVBQUUsR0FBRyxPQUFPLFVBQVUsU0FBUyxHQUFHO0FBQzNJO0FBR0EsU0FBUyx1QkFBdUIsTUFBWSxNQUFZLFVBQWtCLFVBQTJCLFFBQXlCO0FBQzVILE1BQUksYUFBYSxTQUFTLEdBQUksUUFBTztBQUNyQyxRQUFNLFVBQVUsV0FBVyxNQUFNLFFBQVE7QUFDekMsTUFBSSxDQUFDLFdBQVcsUUFBUSxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUcsUUFBTztBQUMxRixRQUFNLFdBQVcsa0JBQWtCLFVBQVUsVUFBVSxNQUFNLFFBQVEsR0FBRyxPQUFPLE9BQU8sS0FBSyxLQUFLLFNBQVMsUUFBUSxtQ0FBbUMsTUFBTSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQy9LLFNBQU8seUJBQXlCLG9CQUFvQixNQUFNLEtBQUssT0FBTyxTQUFTLFVBQVUsTUFBTSxPQUFPLEtBQUssR0FBRyxJQUFJLEdBQUcsUUFBUTtBQUMvSDtBQUVBLFNBQVMsc0JBQXNCLE1BQVksTUFBWSxTQUEwQixhQUFhLE1BQXVCO0FBRW5ILE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixRQUFNLE9BQU8sbUJBQW1CLE1BQU0sTUFBTSxLQUFLLElBQUksb0JBQW9CLEtBQUssV0FBVyxHQUFHLFVBQVU7QUFDdEcsTUFBSSxDQUFDLFFBQVEsS0FBSyxPQUFPLFFBQVEsR0FBSSxRQUFPO0FBQzVDLFNBQU87QUFBQSxJQUF5QixvQkFBb0IsTUFBTSxLQUFLLE9BQU8sU0FBUyxVQUFVLE1BQU0sU0FBUyxVQUFVLEtBQUssR0FBRyxJQUFJO0FBQUEsSUFDNUgsb0JBQW9CLE1BQU0sS0FBSyxPQUFPLE1BQU0sVUFBVSxNQUFNLE1BQU0sVUFBVSxLQUFLLEdBQUcsSUFBSTtBQUFBLEVBQUMsSUFBSSxPQUFPO0FBQ3hHO0FBRUEsU0FBUyw0QkFBNEIsTUFBWSxNQUFZO0FBQzNELE1BQUksS0FBSyxNQUFNLFNBQVMsU0FBVSxRQUFPO0FBQ3pDLFFBQU0sU0FBUyxXQUFXLE1BQU0sS0FBSyxNQUFNLFFBQVE7QUFDbkQsTUFBSSxDQUFDLFVBQVUsT0FBTyxNQUFNLEtBQUssQ0FBQyxlQUFlLE1BQU0sS0FBSyxPQUFPLE9BQU8sS0FBSyxFQUFHLFFBQU87QUFDekYsUUFBTSxpQkFBaUIsc0JBQXNCLElBQUk7QUFDakQsTUFBSSxrQkFBa0IsU0FBUyxRQUFRLGNBQWMsSUFBSSw4QkFBK0IsUUFBTztBQUMvRixTQUFPO0FBQ1Q7QUFFQSxTQUFTLHNCQUFzQixNQUFZO0FBQ3pDLE1BQUksS0FBSyxNQUFNLFNBQVMsWUFBWSxLQUFLLE1BQU0sV0FBVyxVQUFhLEtBQUssTUFBTSxXQUFXLE9BQVcsUUFBTyxFQUFFLEdBQUcsS0FBSyxNQUFNLFFBQVEsR0FBRyxLQUFLLE1BQU0sT0FBTztBQUM1SixNQUFJLEtBQUssVUFBVSxVQUFhLEtBQUssVUFBVSxPQUFXLFFBQU8sRUFBRSxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssTUFBTTtBQUNoRyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLDBCQUEwQixNQUFZO0FBQzdDLFNBQU8sS0FBSyxVQUFVLFVBQWEsS0FBSyxVQUFVLFNBQVksRUFBRSxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssTUFBTSxJQUFJLEVBQUUsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUU7QUFDMUg7QUFFQSxTQUFTLFdBQVcsTUFBWSxVQUEyQixRQUF5QjtBQUVsRixNQUFHLE9BQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxFQUFFLFlBQVUsYUFBYSxlQUFlLEtBQUssT0FBTSxNQUFNLEdBQUU7QUFBQyxRQUFHLFVBQVUsS0FBRyxHQUFFO0FBQUMsZ0JBQVUsS0FBRztBQUFFLGlCQUFXLE1BQUssVUFBUyxTQUFTO0FBQUEsSUFBRTtBQUFBLEVBQUM7QUFHMUssTUFBRyxDQUFDLGVBQWUsTUFBSyxTQUFTLE9BQU0sT0FBTyxLQUFLLEVBQUU7QUFDckQsUUFBTSxnQkFBZ0IsU0FBUztBQUMvQixNQUFJLFdBQVcsYUFBYSxLQUFLLGtCQUFrQixXQUFXO0FBQzVELGtCQUFjLEtBQUssTUFBTSxNQUFNLGFBQWEsZUFBZSxPQUFPLE1BQU0sSUFBSSxJQUFJLENBQUM7QUFBQSxFQUNuRjtBQUNBLE1BQUksT0FBTyxRQUFRLEtBQUssT0FBTyxNQUFNLEdBQUc7QUFDdEMsYUFBUyxTQUFTO0FBQ2xCLGdCQUFZLE1BQU0sVUFBVSxNQUFNO0FBQ2xDLFFBQUksU0FBUyxVQUFVLGFBQWEsV0FBVyxPQUFPLEtBQUssR0FBRztBQUM1RCxvQkFBYyxLQUFLLE1BQU0sTUFBTSxzQkFBc0IsT0FBTyxPQUFPLENBQUM7QUFBQSxJQUN0RTtBQUNBLFFBQUksV0FBVyxTQUFTLEtBQUssS0FBSyxvQkFBb0IsU0FBUyxJQUFJLEtBQUssZUFBZSxNQUFNLFNBQVMsT0FBTyxPQUFPLEtBQUssR0FBRztBQUMxSCxvQkFBYyxLQUFLLE1BQU0sTUFBTSxnQkFBZ0IsU0FBUyxPQUFPLENBQUM7QUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLE9BQU8sTUFBTSxLQUFLLE9BQU8sVUFBVSxhQUFhLFdBQVcsYUFBYSxHQUFHO0FBQzdFLGtCQUFjLEtBQUssTUFBTSxNQUFNLG9CQUFvQixlQUFlLENBQUM7QUFDbkUsMkJBQXVCLE1BQU0sZUFBZSxNQUFNO0FBQUEsRUFDcEQ7QUFDQSxNQUFJLENBQUMsT0FBTyxNQUFNLEtBQUssV0FBVyxhQUFhLEdBQUc7QUFDaEQsa0JBQWMsS0FBSyxNQUFNLE1BQU0sb0JBQW9CLGVBQWUsQ0FBQztBQUNuRSxRQUFJLE9BQU8sU0FBUyxXQUFZLGVBQWMsS0FBSyxNQUFNLE1BQU0sMkJBQTJCLGVBQWUsQ0FBQztBQUFBLEVBQzVHO0FBQ0Y7QUFFQSxTQUFTLFVBQ1AsTUFDQSxNQUNBLEdBQ0EsR0FDQSxXQUNBLFNBQ0E7QUFDQSxPQUFLLFFBQVEsS0FBSyxFQUFFLElBQUksVUFBVSxLQUFLLE1BQU0sSUFBSSxNQUFNLEdBQUcsR0FBRyxXQUFXLFVBQVUsV0FBVyxHQUFHLFNBQVMsR0FBSSxTQUFTLGFBQVcsRUFBQyxZQUFXLEtBQUssS0FBSSxJQUFFLENBQUMsRUFBRyxDQUFDO0FBQzdKLE9BQUssVUFBVTtBQUNqQjtBQUVBLFNBQVMsT0FBTyxRQUFvRDtBQUNsRSxTQUFPLFdBQVc7QUFDcEI7QUFFQSxTQUFTLFdBQVcsUUFBd0Q7QUFDMUUsU0FBTyxXQUFXO0FBQ3BCO0FBRUEsU0FBUyxZQUFZLE1BQVksVUFBZ0IsUUFBYztBQUM3RCxNQUFJLFNBQVMsVUFBVSxhQUFhLENBQUMsZUFBZSxNQUFNLFNBQVMsT0FBTyxPQUFPLEtBQUssRUFBRztBQUN6RixXQUFTLE1BQU0sYUFBYSxVQUFVLE1BQU0sTUFBTSxHQUFHLE9BQU8sS0FBSztBQUNqRSxlQUFhLE1BQU0sUUFBUTtBQUM3QjtBQUVBLFNBQVMsdUJBQXVCLE1BQVksT0FBaUIsUUFBYztBQUN6RSxRQUFNLFNBQVMsVUFBVSxNQUFNLE1BQU0sRUFBRSxjQUFjO0FBQ3JELE1BQUksVUFBVSxFQUFHO0FBQ2pCLGNBQVksTUFBTSxLQUFLLEVBQUUsT0FBTyxRQUFRLFlBQVksTUFBTSxLQUFLLEVBQUUsTUFBTSxNQUFNO0FBQzdFLFlBQVUsTUFBTSxjQUFjLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUSxHQUFHLEdBQUcsRUFBRSxPQUFPLFFBQVEsT0FBTyxDQUFDO0FBQzNGO0FBRUEsU0FBUyxhQUFhLE1BQVksTUFBWTtBQUM1QyxNQUFJLEtBQUssWUFBWSxVQUFhLEtBQUssV0FBVyxLQUFLLE9BQU8sR0FBRyxPQUFRO0FBQ3pFLFFBQU0sWUFBWSxpQkFBaUIsVUFBVSxNQUFNLElBQUksQ0FBQyxFQUFFLE9BQU8sZUFBYSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBQ3BHLE1BQUksYUFBYSxLQUFLLE1BQU87QUFDN0IsT0FBSyxRQUFRLEtBQUssSUFBSSxtQkFBbUIsU0FBUztBQUNsRCxNQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssVUFBVSxhQUFhLEtBQUssZ0JBQWdCLFVBQWEsQ0FBQyxLQUFLLHFCQUFxQjtBQUMvRyxTQUFLLHNCQUFzQix3QkFBd0IsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxTQUFTLFNBQVMsUUFBUSxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssSUFBSSxJQUFJLFlBQVksTUFBTSxJQUFJLENBQUM7QUFBQSxFQUNsSztBQUNBLHdCQUFzQixNQUFNLElBQUk7QUFDbEM7QUFFQSxTQUFTLHNCQUFzQixNQUFZLE1BQVk7QUFDckQsUUFBTSxnQkFBZ0IsS0FBSztBQUMzQixRQUFNLE9BQU8saUJBQWlCLE1BQU0sSUFBSTtBQUN4QyxRQUFNLGFBQWEsSUFBSSxLQUFLLElBQUksbUJBQW1CLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxDQUFDLElBQUk7QUFDOUUsUUFBTSxRQUFNLFNBQVMsTUFBSyxJQUFJLEVBQUUsS0FBSyxVQUFNLFVBQVUsS0FBSyxJQUFJLEVBQUUsU0FBTyxDQUFDO0FBQ3hFLE9BQUssYUFBVyxVQUFVLE1BQUssSUFBSSxFQUFFLFVBQVEsV0FBVyxLQUFLLElBQUksSUFBRSx1QkFBcUI7QUFBRyxPQUFLLFNBQU8sS0FBSztBQUM1RyxRQUFNLFdBQVcsS0FBSyxjQUFjLElBQUksS0FBSyxFQUFFO0FBQy9DLE9BQUssZUFBZSxLQUFLLE1BQU0sS0FBSyxZQUFZO0FBQ2hELE9BQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxRQUFRLFVBQVU7QUFDL0MsT0FBSyxRQUFRLEtBQUssU0FBUyxRQUFRLE9BQU0sTUFBTSxVQUFVLHVCQUF1QjtBQUNoRixPQUFLLGNBQWMsS0FBSyxlQUFlLFVBQVUseUJBQXlCO0FBQzFFLE9BQUssS0FBSyxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLFFBQVEsYUFBYSxDQUFDO0FBQ2xGO0FBRUEsU0FBUyxpQkFBaUIsTUFBWSxNQUFZO0FBQ2hELFFBQU0sUUFBUSxZQUFZLE1BQU0sSUFBSTtBQUNwQyxPQUFLLGlCQUFlLE1BQU07QUFDMUIsTUFBSSxlQUFlLE1BQU07QUFDekIsTUFBSSxRQUFRLE1BQU07QUFDbEIsTUFBSSxRQUFRLE1BQU07QUFDbEIsTUFBSSxjQUFjLE1BQU07QUFDeEIsTUFBSSxDQUFDLFdBQVcsS0FBSyxLQUFLLEVBQUcsUUFBTyxFQUFFLGNBQWMsT0FBTyxPQUFPLFlBQVk7QUFDOUUsUUFBTSxXQUFXLFlBQVksTUFBTSxLQUFLLEtBQUssRUFBRTtBQUMvQyxhQUFXLGVBQWUsZUFBZTtBQUN2QyxVQUFNLFVBQVUsYUFBYSxXQUFXO0FBQ3hDLFFBQUksQ0FBQyxRQUFRLGtCQUFrQixTQUFTLEtBQUssSUFBeUIsRUFBRztBQUN6RSxhQUFTLFFBQVEsR0FBRyxTQUFTLFNBQVMsV0FBVyxLQUFLLElBQUksU0FBUyxHQUFHO0FBQ3BFLFlBQU0sV0FBVyxRQUFRLE9BQU8sS0FBSztBQUNyQyxVQUFJLENBQUMsU0FBVSxPQUFNLElBQUksTUFBTSxHQUFHLFdBQVcsa0JBQWtCLFFBQVEsQ0FBQyxFQUFFO0FBQzFFLFVBQUksU0FBUyxpQkFBa0IsZ0JBQWUsTUFBTSxlQUFlLFNBQVM7QUFDNUUsVUFBSSxTQUFTLGdCQUFpQixTQUFRLE1BQU0sS0FBSyxTQUFTO0FBQzFELFVBQUksU0FBUyxnQkFBaUIsU0FBUSxnQkFBZ0IsTUFBTSxRQUFRLFNBQVMsZUFBZTtBQUM1RixVQUFJLFNBQVMsc0JBQXVCLGVBQWMsS0FBSyxNQUFNLE1BQU0sY0FBYyxTQUFTLHFCQUFxQjtBQUFBLElBQ2pIO0FBQUEsRUFDRjtBQUNBLE1BQUksU0FBUyxNQUFLLElBQUksRUFBRSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsZ0JBQWdCLGFBQWEsTUFBSyxNQUFLLElBQUksQ0FBQyxFQUFHLFNBQVEsZ0JBQWdCLFFBQVEsV0FBVztBQUMvSSxTQUFPLEVBQUUsY0FBYyxPQUFPLE9BQU8sWUFBWTtBQUNuRDtBQUVBLFNBQVMsZ0JBQWdCLE9BQWU7QUFDdEMsU0FBTyxLQUFLLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDbkM7QUFFQSxTQUFTLGtCQUFrQixNQUFZO0FBQ3JDLGFBQVcsU0FBUyxLQUFLLGVBQWU7QUFDdEMsVUFBTSxTQUFTLFlBQVksTUFBTSxLQUFLO0FBQ3RDLFdBQU8sWUFBWSxLQUFLLFVBQ3JCLE9BQU8sQ0FBQyxhQUFhLFNBQVMsVUFBVSxTQUFTLFNBQVMsUUFBUSxFQUNsRSxPQUFPLENBQUMsT0FBTyxhQUFhLFFBQVEsY0FBYyxTQUFTLElBQUksRUFBRSxnQkFBZ0IsQ0FBQztBQUNyRixXQUFPLGFBQWEsb0JBQW9CLE1BQU0sS0FBSztBQUFBLEVBQ3JEO0FBQ0Y7QUFFQSxTQUFTLG9CQUFvQixNQUFZLE9BQWlCO0FBQ3hELFFBQU0sYUFBYSxLQUFLLE1BQ3JCLE9BQU8sQ0FBQyxTQUFTLEtBQUssVUFBVSxLQUFLLEVBQ3JDLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxVQUFVLE1BQU0sSUFBSSxFQUFFLGNBQWMsS0FBSyxRQUFRLFlBQVksTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDO0FBQ25ILFFBQU0sZUFBZSxLQUFLLFVBQ3ZCLE9BQU8sQ0FBQyxhQUFhLFNBQVMsVUFBVSxLQUFLLEVBQzdDLFFBQVEsQ0FBQyxhQUFhLFNBQVMsS0FBSyxFQUNwQyxPQUFPLENBQUMsT0FBTyxRQUFRLFFBQVEsVUFBVSxJQUFJLFFBQVEsRUFBRSxZQUFZLENBQUM7QUFDdkUsU0FBTyxhQUFhO0FBQ3RCO0FBRUEsU0FBUyxXQUFXLE1BQVksU0FBbUIsT0FBaUI7QUFDbEUsUUFBTSxPQUFPLGNBQWMsS0FBSyxPQUFPLE9BQU8sUUFBUSxNQUFNO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksQ0FBQyxPQUFPLEtBQUssRUFBRSxDQUFDO0FBQzFDLFFBQU0sVUFBVSxNQUFNLFVBQVUsQ0FBQ1IsVUFBUyxDQUFDQSxLQUFJO0FBQy9DLE1BQUksV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLFdBQVcsS0FBSyxTQUFTLFFBQVEsT0FBTyxDQUFDLEVBQUU7QUFDN0UsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQVksYUFBdUIsT0FBaUI7QUFDMUUsUUFBTSxZQUFZLFlBQVksSUFBSSxDQUFDLE9BQU8sS0FBSyxVQUFVLEtBQUssQ0FBQyxhQUFhLFNBQVMsT0FBTyxNQUFNLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0gsUUFBTSxVQUFVLFVBQVUsVUFBVSxDQUFDLGFBQWEsQ0FBQyxRQUFRO0FBQzNELE1BQUksV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLFdBQVcsS0FBSyxhQUFhLFlBQVksT0FBTyxDQUFDLEVBQUU7QUFDckYsU0FBTztBQUNUO0FBRUEsU0FBUyxVQUFVLE1BQVksT0FBaUIsUUFBZ0I7QUFDOUQsUUFBTSxZQUFZLE1BQU0sS0FBSyxHQUFHLE1BQU07QUFDdEMsZ0JBQWMsS0FBSyxNQUFNLE1BQU0sV0FBVyxPQUFPLE1BQU07QUFDekQ7QUFFQSxTQUFTLE1BQU0sUUFBcUIsUUFBZ0I7QUFDbEQsTUFBSSxPQUFPLE9BQU8sT0FBUSxPQUFNLElBQUksTUFBTSxRQUFRLE1BQU0sT0FBTztBQUMvRCxTQUFPLE9BQU8sUUFBUSxPQUFPLE1BQU0sQ0FBQyxNQUFNO0FBQzVDO0FBRUEsU0FBUyxZQUFZLE1BQVksT0FBaUI7QUFDaEQsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLO0FBQ2pDLE1BQUksQ0FBQyxPQUFRLE9BQU0sSUFBSSxNQUFNLGtCQUFrQixLQUFLLEVBQUU7QUFDdEQsU0FBTztBQUNUO0FBRUEsU0FBUyxjQUFjLFFBQWdDLE9BQWMsUUFBZ0I7QUFDbkYsU0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSztBQUN6QztBQUVBLFNBQVMsVUFBVSxNQUFZLE9BQWlCLFVBQW9CO0FBQ2xFLFNBQU8sb0JBQW9CLE1BQU0sS0FBSyxJQUFJLFVBQVUsUUFBUSxFQUFFLGNBQWMsWUFBWSxNQUFNLEtBQUssRUFBRTtBQUN2RztBQUVBLFNBQVMsb0JBQW9CLE1BQW9CO0FBQy9DLFNBQVEscUJBQTJDLFNBQVMsSUFBSTtBQUNsRTtBQUVBLFNBQVMsWUFBWSxNQUFZLE9BQWlCO0FBQ2hELFNBQU8sS0FBSyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssVUFBVSxTQUFTLEtBQUssU0FBUyxRQUFRO0FBQ25GO0FBRUEsU0FBUyxrQkFBa0IsTUFBWSxPQUFpQixNQUF3QjtBQUM5RSxTQUFPLEtBQUssVUFBVSxPQUFPLENBQUMsYUFBYSxTQUFTLFVBQVUsU0FBUyxTQUFTLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFDcEg7QUFFQSxTQUFTLHdCQUF3QixNQUFZLE9BQXNCLEdBQVcsR0FBVztBQUN2RixNQUFJLENBQUMsV0FBVyxLQUFLLEVBQUcsUUFBTztBQUMvQixVQUFRLEtBQUssYUFBYSxVQUFVLElBQUksS0FBSyxLQUFLLGtCQUFrQixNQUFNLE9BQU8sVUFBVSxHQUFHLE9BQU8sY0FBWSxXQUFXLEtBQUssS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLFFBQVEsQ0FBQyxFQUFFLE9BQTZCLENBQUMsTUFBTSxhQUFhO0FBQzFNLFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsV0FBTyxTQUFTLEVBQUUsR0FBRyxFQUFFLEdBQUcsUUFBUSxJQUFJLFNBQVMsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLElBQUksV0FBVztBQUFBLEVBQzlFLEdBQUcsTUFBUztBQUNkO0FBR0EsU0FBUyxvQkFBb0IsTUFBWSxNQUFZLE9BQWU7QUFDbEUsUUFBTSxRQUFRLFFBQVE7QUFDdEIsU0FBTyxnQkFBZ0IsTUFBTSxNQUFNLE9BQU8sQ0FBQyxjQUFjLGVBQWUsTUFBTSxLQUFLLE9BQU8sVUFBVSxLQUFLLEtBQUssZ0JBQWdCLE1BQU0sU0FBUyxLQUFLLEtBQUs7QUFDeko7QUFFQSxTQUFTLGlCQUFpQixNQUFZLE9BQWlCLEdBQVcsR0FBVyxPQUFlO0FBQzFGLFFBQU0sUUFBUSxFQUFFLEdBQUcsRUFBRTtBQUNyQixRQUFNLFFBQVEsUUFBUTtBQUN0QixNQUFJO0FBQ0osTUFBSSxZQUFZLE9BQU87QUFDdkIseUJBQXVCLE1BQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQyxTQUFTO0FBQzFELFFBQUksVUFBVSxJQUFJLEVBQUc7QUFDckIsVUFBTSxvQkFBb0IsZ0JBQWdCLE1BQU0sS0FBSztBQUNyRCxRQUFJLG9CQUFvQixNQUFPO0FBQy9CLFVBQU0sUUFBUSxvQkFBb0IsTUFBTSxPQUFPLE1BQU0saUJBQWlCO0FBQ3RFLFFBQUksU0FBUyxVQUFXO0FBQ3hCLFdBQU87QUFDUCxnQkFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLFNBQVMsbUJBQW1CLE1BQVksTUFBWSxPQUFlLGFBQWEsTUFBbUM7QUFDakgsTUFBSSxLQUFLLGdCQUFnQixFQUFHLFFBQU87QUFDbkMsU0FBTyw0QkFBNEIsTUFBTSxLQUFLLE9BQU8sTUFBTSxPQUFPLE1BQU0sUUFBVyxVQUFVO0FBQy9GO0FBSUEsU0FBUyxVQUFVLE1BQWdDLFFBQW9DLGFBQWEsTUFBTTtBQUN4RyxNQUFJLENBQUMsY0FBYyxPQUFPLE1BQU0sRUFBRyxRQUFPLE9BQU8sT0FBTyxJQUFJLEtBQUssR0FBRyxPQUFPLElBQUksS0FBSyxDQUFDO0FBQ3JGLFNBQU8sVUFBVSxNQUFLLE1BQU07QUFDOUI7QUFFQSxTQUFTLDRCQUE0QixNQUFZLE9BQWMsT0FBaUMsT0FBZSxVQUFpQixTQUEyQyxhQUFhLE1BQW1DO0FBQ3pOLFFBQU0sUUFBUSxRQUFRO0FBQ3RCLE1BQUk7QUFDSixNQUFJLFlBQVksT0FBTztBQUd2Qix5QkFBdUIsTUFBTSxPQUFPLE9BQU8sU0FBUyxhQUFhLEtBQUssb0JBQW9CLGlCQUFpQixLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsY0FBYztBQUMxSSxRQUFJLGNBQWMsVUFBVSxTQUFTLEVBQUc7QUFDeEMsUUFBRyxjQUFjLENBQUMsdUJBQXVCLEtBQUssT0FBTSxPQUFNLFNBQVMsRUFBRTtBQUNyRSxRQUFJLGNBQWMsWUFBWSxTQUFTLEtBQUssZUFBZSxLQUFLLE9BQU8sU0FBUyxFQUFFLEtBQUssVUFBUSxLQUFLLEtBQUssS0FBSyxDQUFDLFVBQVUsSUFBSSxNQUFNLENBQUMsWUFBWSxTQUFTLEtBQUssS0FBSyxVQUFVLE1BQU0sS0FBSyxLQUFLLEVBQUUsRUFBRztBQUNsTSxRQUFHLFdBQVcsQ0FBQyxRQUFRLFNBQVMsRUFBRTtBQUNsQyxVQUFNLG9CQUFvQixjQUFjLFdBQVcsVUFBVSxJQUFJLElBQUksZUFBZSxXQUFXLEtBQUssS0FBSyxJQUFJLGdCQUFnQixPQUFPLFNBQVM7QUFDN0ksUUFBSSxvQkFBb0IsTUFBTztBQUMvQixRQUFJLFlBQVksQ0FBQyw0QkFBNEIsTUFBTSxVQUFVLFdBQVcsVUFBVSxFQUFHO0FBQ3JGLFVBQU0sUUFBUSxvQkFBb0IsTUFBTSxPQUFPLFdBQVcsbUJBQW1CLFFBQVE7QUFDckYsUUFBSSxRQUFRLFdBQVc7QUFDckIsYUFBTztBQUNQLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0YsQ0FBQztBQUNELDZCQUEyQixNQUFNLE9BQU8sT0FBTyxRQUFRLHFCQUFxQixDQUFDLGFBQWE7QUFDeEYsUUFBRyxXQUFXLENBQUMsUUFBUSxRQUFRLEVBQUU7QUFDakMsVUFBTSxNQUFNLFVBQVUsT0FBTyxRQUFRO0FBQ3JDLFFBQUksTUFBTSxNQUFPO0FBQ2pCLFFBQUksWUFBWSxDQUFDLDRCQUE0QixNQUFNLFVBQVUsVUFBVSxVQUFVLEVBQUc7QUFDcEYsVUFBTSxRQUFRLG9CQUFvQixNQUFNLE9BQU8sVUFBVSxNQUFNLEtBQUssUUFBUTtBQUM1RSxRQUFJLFFBQVEsV0FBVztBQUNyQixhQUFPO0FBQ1Asa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixDQUFDO0FBQ0QsU0FBTztBQUNUO0FBRUEsU0FBUyxpQkFBaUIsT0FBd0I7QUFDaEQsTUFBSSxVQUFVO0FBQ2QsYUFBVyxRQUFRLFFBQVEsS0FBSyxHQUFHO0FBQ2pDLFVBQU0sVUFBVSxZQUFZLElBQUk7QUFDaEMsUUFBSSxRQUFTLFdBQVUsS0FBSyxJQUFJLFNBQVMsR0FBRyxRQUFRLEtBQUssSUFBSSxPQUFLLEtBQUssTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ3pGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyw0QkFBNEIsTUFBWSxNQUFZLFdBQTRCLGFBQWEsTUFBZTtBQUNuSCxPQUFLLGNBQWMsS0FBSyxJQUFJLFlBQVksQ0FBQyxTQUFTLEtBQUssS0FBSyxNQUFNLFdBQVcsS0FBSyxLQUFLLEVBQUcsUUFBTztBQUNqRyxNQUFJLEtBQUssVUFBVSxVQUFXLFFBQU87QUFDckMsUUFBTSxTQUFTLHNCQUFzQixJQUFJO0FBQ3pDLFNBQU8sQ0FBQyxVQUFVLFNBQVMsV0FBVyxNQUFNLEtBQUs7QUFDbkQ7QUFFQSxTQUFTLG9CQUFvQixNQUFZLE9BQWMsUUFBeUIsWUFBb0IsVUFBaUI7QUFDbkgsUUFBTSxXQUFXLGVBQWUsTUFBTTtBQUN0QyxRQUFNLFNBQVMsV0FBVyxXQUFXLE1BQU0sUUFBUSxJQUFJO0FBQ3ZELFFBQU0sU0FBdUIsVUFBVSxDQUFDLGVBQWUsTUFBTSxPQUFPLE9BQU8sS0FBSyxJQUFJLFdBQVcsV0FBVyxTQUFTLFNBQVM7QUFDNUgsU0FBTyxrQkFBa0IsUUFBUSxLQUFLLEtBQUssVUFBVSxHQUFHLFFBQVEsbUNBQW1DLE1BQU0sT0FBTyxNQUFNLENBQUM7QUFDekg7QUFFQSxTQUFTLG1DQUFtQyxNQUFZLGVBQXNCLFFBQW9DO0FBQ2hILE1BQUksZ0JBQWdCO0FBRXBCLGFBQVcsY0FBYyxjQUFjLE1BQU0sT0FBTyxFQUFFLEVBQUcsS0FBSSxXQUFXLFVBQVUsaUJBQWlCLENBQUMsV0FBVyxPQUFRLGtCQUFpQixXQUFXO0FBQ25KLFNBQU8sT0FBTyxLQUFLO0FBQ3JCO0FBT0EsTUFBTSxzQkFBc0Isb0JBQUksUUFBZ0Y7QUFDaEgsTUFBTSxpQkFBK0IsQ0FBQztBQUV0QyxTQUFTLGNBQWMsTUFBWSxVQUFnQztBQUNqRSxRQUFNLGNBQWMsS0FBSztBQUN6QixNQUFJLFFBQVEsb0JBQW9CLElBQUksV0FBVztBQUMvQyxNQUFJLENBQUMsU0FBUyxNQUFNLFVBQVUsWUFBWSxPQUFRLHFCQUFvQixJQUFJLGFBQWMsUUFBUSxFQUFFLFNBQVMsR0FBRyxVQUFVLG9CQUFJLElBQUksRUFBRSxDQUFFO0FBQ3BJLFNBQU8sTUFBTSxVQUFVLFlBQVksUUFBUSxNQUFNLFdBQVcsR0FBRztBQUM3RCxVQUFNLGFBQWEsWUFBWSxNQUFNLE9BQU87QUFDNUMsVUFBTSxXQUFXLE1BQU0sU0FBUyxJQUFJLFdBQVcsUUFBUTtBQUN2RCxRQUFJLFNBQVUsVUFBUyxLQUFLLFVBQVU7QUFBQSxRQUNqQyxPQUFNLFNBQVMsSUFBSSxXQUFXLFVBQVUsQ0FBQyxVQUFVLENBQUM7QUFBQSxFQUMzRDtBQUNBLFNBQU8sTUFBTSxTQUFTLElBQUksUUFBUSxLQUFLO0FBQ3pDO0FBR0EsU0FBUyxXQUFXLE1BQVksVUFBK0M7QUFDN0UsUUFBTSxTQUFTLEtBQUssWUFBWSxJQUFJLFFBQVEsS0FBSyxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLFFBQVEsS0FBSyxLQUFLLFVBQVUsS0FBSyxDQUFDLGFBQWEsU0FBUyxPQUFPLFFBQVE7QUFDOUosU0FBTyxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsTUFBTSxJQUFJLFNBQVk7QUFDckU7QUFJQSxTQUFTLGlCQUFpQixNQUFZLFVBQTBEO0FBQzlGLFNBQU8sV0FBVyxNQUFNLFFBQVEsS0FBSyxLQUFLLFdBQVcsS0FBSyxDQUFDLGFBQWEsU0FBUyxPQUFPLFFBQVE7QUFDbEc7QUFFQSxTQUFTLG1CQUFtQixNQUFZO0FBQ3RDLE1BQUksQ0FBQyxLQUFLLE1BQU0sS0FBSyxVQUFRLEtBQUssZ0JBQWdCLFVBQWEsS0FBSyxlQUFlLEtBQUssSUFBSSxFQUFHO0FBQy9GLFFBQU0sZUFBZSxLQUFLLE1BQU0sT0FBTyxDQUFDLFNBQVMsS0FBSyxnQkFBZ0IsVUFBYSxLQUFLLGVBQWUsS0FBSyxJQUFJO0FBQ2hILHlCQUF1QixNQUFNLFlBQVk7QUFDekMsUUFBTSxhQUFhLElBQUksSUFBSSxhQUFhLElBQUksQ0FBQyxTQUFTLEtBQUssRUFBRSxDQUFDO0FBQzlELE9BQUssUUFBUSxLQUFLLE1BQU0sT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksS0FBSyxFQUFFLENBQUM7QUFDakUsNEJBQTBCLElBQUk7QUFDOUIsb0JBQWtCLElBQUk7QUFDeEI7QUFFQSxTQUFTLFdBQVcsTUFBWTtBQUc5QixNQUFJLENBQUMsS0FBSyxNQUFNLEtBQUssVUFBUSxLQUFLLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxVQUFVLEtBQUssY0FBWSxTQUFTLE1BQU0sQ0FBQyxHQUFHO0FBQ2hHLFFBQUksS0FBSyxXQUFXLEtBQUssY0FBWSxTQUFTLE1BQU0sQ0FBQyxFQUFHLE1BQUssWUFBWSxLQUFLLFVBQVUsT0FBTyxjQUFZLFNBQVMsS0FBSyxDQUFDO0FBQzFIO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBWSxLQUFLLE1BQU0sT0FBTyxDQUFDLFNBQVMsS0FBSyxNQUFNLENBQUM7QUFDMUQsUUFBTSxTQUFPLElBQUksSUFBSSxVQUFVLE9BQU8sVUFBTSxZQUFZLElBQUksQ0FBQyxFQUFFLElBQUksVUFBTSxLQUFLLEVBQUUsQ0FBQztBQUNqRixNQUFHLE9BQU87QUFBSyxlQUFVLGFBQWEsS0FBSyxNQUFNLEtBQUcsVUFBVSxRQUFRLE9BQU8sSUFBSSxVQUFVLEtBQUssTUFBTSxLQUFLLFVBQVUsS0FBRyxHQUFFO0FBQUMsZ0JBQVUsS0FBRztBQUFFLGdCQUFVLEtBQUssU0FBUztBQUFBLElBQUU7QUFBQTtBQUNwSyxRQUFNLGdCQUFnQixLQUFLLFVBQVUsT0FBTyxDQUFDLGFBQWEsU0FBUyxNQUFNLENBQUM7QUFDMUUsYUFBVyxRQUFRLFVBQVcsZUFBYyxLQUFLLE1BQU0sTUFBTSxXQUFXLEtBQUssT0FBTyxDQUFDO0FBR3JGLFFBQU0sa0JBQWtCLElBQUksSUFBSSxVQUFVLElBQUksVUFBUTtBQUNwRCxVQUFNLFFBQU0sV0FBVyxNQUFLLE1BQUssT0FBTyxHQUFFLE9BQUssV0FBVyxNQUFLLE1BQUssTUFBTTtBQUMxRSxXQUFPLENBQUMsS0FBSyxJQUFJO0FBQUEsTUFDZixtQkFBa0I7QUFBQSxNQUNsQixHQUFJLEtBQUssT0FBSyxFQUFDLE1BQUssRUFBQyxHQUFHLEtBQUssS0FBSSxFQUFDLElBQUUsQ0FBQztBQUFBLE1BQ3JDLEdBQUksT0FBTyxTQUFPLGVBQWEsRUFBQyxlQUFjLGFBQXFCLElBQUUsT0FBTyxTQUFPLGlCQUFlLEVBQUMsZUFBYyxnQkFBd0IsR0FBSSxNQUFNLGFBQVcsRUFBQyxZQUFXLE1BQU0sV0FBVSxJQUFFLENBQUMsRUFBRSxJQUFFLENBQUM7QUFBQSxNQUNsTSxHQUFJLE1BQU0sU0FBTyxnQkFBYyxFQUFDLGNBQWEsY0FBc0IsSUFBRSxDQUFDO0FBQUEsTUFDdEUsR0FBSSxLQUFLLFFBQVEsS0FBSyxLQUFLLEdBQUcsT0FBSyxFQUFDLFdBQVUsS0FBSyxRQUFRLEtBQUssS0FBSyxFQUFHLEtBQUksSUFBRSxDQUFDO0FBQUEsSUFDakYsQ0FBQztBQUFBLEVBQ0gsQ0FBQyxDQUFDO0FBQ0YseUJBQXVCLE1BQU0sU0FBUztBQUl0QyxhQUFXLFFBQVEsVUFBVyxLQUFJLEVBQUUsS0FBSyxRQUFRLE9BQU8sSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJO0FBQzlFLEtBQUMsS0FBSyxZQUFZLENBQUMsR0FBRyxLQUFLO0FBQUEsTUFBRSxJQUFJLFVBQVUsS0FBSyxFQUFFLElBQUksS0FBSyxJQUFJO0FBQUEsTUFBSSxRQUFRLEtBQUs7QUFBQSxNQUM5RSxNQUFNLEtBQUs7QUFBQSxNQUFNLE9BQU8sS0FBSztBQUFBLE1BQU8sR0FBRyxLQUFLO0FBQUEsTUFBRyxHQUFHLEtBQUs7QUFBQSxNQUFHLFFBQVEsS0FBSztBQUFBLE1BQ3ZFLFlBQVksS0FBSztBQUFBLE1BQU0sR0FBSSxLQUFLLFVBQVUsRUFBRSxTQUFTLEtBQUssUUFBUSxJQUFJLENBQUM7QUFBQSxNQUFJLEdBQUcsZ0JBQWdCLElBQUksS0FBSyxFQUFFO0FBQUEsSUFBRSxDQUFDO0FBQUEsRUFDaEg7QUFDQSxNQUFHLFVBQVUsUUFBUTtBQUNuQixTQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDO0FBQ3BELDhCQUEwQixJQUFJO0FBQUEsRUFDaEM7QUFDQSxNQUFHLGNBQWMsT0FBTyxNQUFLLFlBQVksS0FBSyxVQUFVLE9BQU8sQ0FBQyxhQUFhLFNBQVMsS0FBSyxDQUFDO0FBRTVGLE1BQUksS0FBSyxXQUFXLEtBQUssQ0FBQyxhQUFhLFNBQVMsTUFBTSxDQUFDLEVBQUcsTUFBSyxZQUFZLEtBQUssVUFBVSxPQUFPLENBQUMsYUFBYSxTQUFTLEtBQUssQ0FBQztBQUM5SCxNQUFJLFVBQVUsU0FBUyxLQUFLLGNBQWMsU0FBUyxFQUFHLG1CQUFrQixJQUFJO0FBQzlFO0FBRUEsU0FBUyx1QkFBdUIsTUFBWSxXQUFtQjtBQUM3RCxNQUFJLFVBQVUsV0FBVyxFQUFHO0FBQzVCLHNCQUFvQixLQUFLLEtBQUs7QUFDOUIsUUFBTSxXQUFXLElBQUksSUFBSSxVQUFVLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2pFLGFBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsUUFBSSxDQUFDLEtBQUssYUFBYSxDQUFDLEtBQUssT0FBUTtBQUNyQyxVQUFNLE9BQU8sU0FBUyxJQUFJLEtBQUssYUFBYSxLQUFLLE1BQU87QUFDeEQsUUFBSSxDQUFDLEtBQU07QUFDWCxXQUFPLEtBQUs7QUFBVSxXQUFPLEtBQUs7QUFBSyxXQUFPLEtBQUs7QUFBTyxXQUFPLEtBQUs7QUFBUyxXQUFPLEtBQUs7QUFBUSxXQUFPLEtBQUs7QUFDL0csU0FBSyxJQUFJLEtBQUs7QUFDZCxTQUFLLElBQUksS0FBSztBQUFBLEVBQ2hCO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsTUFBWTtBQUNqQyxNQUFJLEtBQUssTUFBTSxVQUFVLEtBQUssZ0JBQWlCO0FBQy9DLFFBQU0sY0FBYyxvQkFBSSxJQUFZO0FBQ3BDLGFBQVcsU0FBUyxLQUFLLGNBQWUsYUFBWSxJQUFJLFFBQVEsTUFBTSxLQUFLLENBQUM7QUFDNUUsTUFBSTtBQUNKLE1BQUksU0FBMEI7QUFDOUIsYUFBVyxZQUFZLEtBQUssV0FBVztBQUNyQyxVQUFNLE9BQU8sUUFBUSxNQUFNLFNBQVMsS0FBSztBQUN6QyxRQUFJLENBQUMsWUFBWSxJQUFJLElBQUksRUFBRztBQUM1QixRQUFJLGVBQWUsVUFBYSxTQUFTLFdBQVk7QUFDckQsUUFBSSxlQUFlLFFBQVc7QUFDNUIsbUJBQWE7QUFDYixlQUFTLFNBQVM7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxPQUFLLE1BQU0sU0FBUztBQUNwQixPQUFLLE1BQU0sY0FBYyxLQUFLO0FBQ2hDO0FBTU8sZ0JBQVMsaUJBQWlCLE1BQVksT0FBYyxTQUFpQixHQUFXLEdBQVcsSUFBbUI7QUFDbkgsUUFBTSxRQUFRLEtBQUssV0FBVyxPQUFPO0FBQ3JDLE1BQUksQ0FBQyxNQUFPLE9BQU0sSUFBSSxNQUFNLHdCQUF3QixPQUFPLEVBQUU7QUFDN0QsUUFBTSxTQUFTLE1BQU0sUUFBUSxLQUFLLElBQUksT0FBTyxJQUFJLEtBQUssTUFBTTtBQUM1RCxNQUFJLE9BQU8sT0FBVyxNQUFLLFVBQVU7QUFBQSxXQUM1QixLQUFLLE1BQU0sS0FBSyxDQUFDQSxVQUFTQSxNQUFLLE9BQU8sRUFBRSxLQUFLLEtBQUssVUFBVSxLQUFLLENBQUMsYUFBYSxTQUFTLE9BQU8sRUFBRSxFQUFHLE9BQU0sSUFBSSxNQUFNLHFCQUFxQixFQUFFLEVBQUU7QUFDdEosUUFBTSxPQUFPLFdBQVcsUUFBUSxPQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7QUFDdkQsT0FBSyxVQUFVO0FBQ2YsT0FBSyxLQUFLLE1BQU07QUFDaEIsbUJBQWlCLE1BQU0sS0FBSztBQUM1QixvQkFBa0IsTUFBTSxJQUFJO0FBQzVCLE9BQUssTUFBTSxLQUFLLElBQUk7QUFDcEIsb0JBQWtCLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBR08sZ0JBQVMsaUJBQWlCLE1BQVksTUFBWTtBQUN2RCxRQUFNLFFBQVEsVUFBVSxNQUFNLElBQUk7QUFDbEMsUUFBTSxRQUFRLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUs7QUFDOUMsTUFBSSxLQUFLLFlBQVksT0FBVyxrQkFBaUIsTUFBTSxLQUFLO0FBQzVELE1BQUksV0FBVyxLQUFLLEtBQUssRUFBRyx1QkFBc0IsTUFBTSxJQUFJO0FBQzVELE9BQUssS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLLFFBQVEsS0FBSyxDQUFDLENBQUM7QUFDNUU7QUFJQSxTQUFTLGlCQUFpQixNQUFZLE9BQWdCO0FBQ3BELE9BQUssUUFBUSxNQUFNO0FBQ25CLE9BQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sRUFBRTtBQUNwQyxPQUFLLFFBQVEsTUFBTTtBQUNuQixPQUFLLFNBQVMsTUFBTSxVQUFRLFdBQVcsS0FBSyxJQUFJLElBQUUsdUJBQXFCO0FBQ3ZFLE9BQUssYUFBYSxLQUFLO0FBQ3ZCLE9BQUssZUFBZSxNQUFNO0FBQzFCLE9BQUssY0FBYyxNQUFNO0FBQ3pCLE9BQUssaUJBQWlCLE1BQU07QUFDOUI7QUFLTyxnQkFBUyxXQUFXLE1BQVksUUFBaUYsUUFBeUIsUUFBZ0IsT0FBcUM7QUFDcE0sUUFBTSxXQUFXLFFBQVEsU0FBUyxTQUFVLFdBQVcsTUFBTSxPQUFPLEVBQUUsS0FBSyxhQUFhLE1BQU07QUFDOUYsUUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxNQUFNLENBQUM7QUFDNUMsTUFBSSxVQUFVLFNBQVM7QUFDckIsVUFBTSxRQUFRLFlBQVksTUFBTSxVQUFVLFFBQVEsT0FBTyxRQUFXLFFBQVcsR0FBRyxnQkFBZ0IsTUFBTTtBQUN4RyxRQUFJLFVBQVUsT0FBVyxjQUFhLE1BQU0sUUFBUSxLQUFLO0FBQ3pEO0FBQUEsRUFDRjtBQUNBLFFBQU0sY0FBYyxPQUFPLFFBQVEsSUFBSSx3QkFBd0IsTUFBTSxRQUFRLElBQUksb0JBQW9CLFNBQVMsSUFBSTtBQUNsSCxvQkFBa0IsTUFBTSxVQUFVLFFBQVEsT0FBTyxVQUFVLFdBQVcsZ0NBQWdDLElBQUksR0FBRyxFQUFFLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUNsSjtBQUlBLFNBQVMsYUFBYSxRQUF5RTtBQUM3RixRQUFNLFFBQVEsbUJBQW1CLEVBQUUsSUFBSSxPQUFPLElBQUksT0FBTyxPQUFPLE9BQU8sWUFBWSxPQUFPLElBQUksVUFBVSxPQUFPLElBQUksT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsUUFBUSxHQUFHLFdBQVcsR0FBRyxVQUFVLEVBQUUsQ0FBQztBQUN6TixTQUFPLEVBQUUsR0FBRyxPQUFPLE1BQU0sT0FBTztBQUNsQztBQUVPLGdCQUFTLGVBQWUsTUFBWSxNQUEyQixHQUFXLEdBQVcsT0FBZSxTQUEyQztBQUNwSixZQUFVLE1BQU0sTUFBTSxHQUFHLEdBQUcsT0FBTyxPQUFPO0FBQzVDO0FBR08sZ0JBQVMsV0FBVyxNQUFZLFFBQWdCO0FBQ3JELFFBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE1BQU07QUFDbkUsTUFBSSxDQUFDLEtBQU07QUFDWCx5QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQztBQUNuQyxPQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFNO0FBQ3JFLDRCQUEwQixJQUFJO0FBQzlCLE9BQUssWUFBWSxPQUFPLE1BQU07QUFDOUIsTUFBSSxLQUFLLGNBQWM7QUFDckIsU0FBSyxjQUFjLG1CQUFtQixLQUFLLE9BQU8sR0FBRztBQUNyRCx3QkFBb0IsSUFBSTtBQUFBLEVBQzFCO0FBQ0Esb0JBQWtCLElBQUk7QUFDeEI7QUFFQSxTQUFTLFdBQVcsT0FBeUM7QUFDM0QsU0FBTyxVQUFVO0FBQ25CO0FBRUEsU0FBUyxlQUFlLE1BQVksR0FBVSxHQUFVO0FBQ3RELE1BQUksTUFBTSxFQUFHLFFBQU87QUFDcEIsTUFBSSxNQUFNLGFBQWEsTUFBTSxVQUFXLFFBQU8sTUFBTSxhQUFhLE1BQU07QUFDeEUsU0FBTyxLQUFLLE1BQU0sQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDO0FBQ3ZDO0FBRUEsU0FBUyxRQUFRLE1BQVksT0FBYztBQUN6QyxTQUFPLFVBQVUsWUFBWSxZQUFZLEtBQUssTUFBTSxLQUFLLEtBQUs7QUFDaEU7QUFXQSxNQUFNLHNCQUFzQixLQUFLLElBQUksR0FBRyxPQUFPLE9BQU8sYUFBYSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDO0FBQzdGLE1BQU0sa0JBQWtCLEtBQUssSUFBSSxHQUFHLE9BQU8sT0FBTyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsSUFBSSxNQUFNLENBQUM7QUFNckYsU0FBUyxVQUFVLE1BQVksTUFBWSxNQUFnQyxRQUFnQjtBQUN6RixRQUFNLE1BQU0sS0FBSztBQUNqQixRQUFNLFNBQU8sS0FBSztBQUNsQixPQUFJLE9BQU8sU0FBTyxVQUFRLE9BQU8sU0FBTyxpQkFBaUIsT0FBTyxjQUFjLE9BQU8sZUFBYSxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxPQUFPLGNBQWMsS0FBSyxLQUFHLENBQUMsRUFBRSxRQUFPO0FBQzlMLE1BQUcsS0FBSyxTQUFTLE9BQU8sU0FBTyxVQUFRLE9BQU8sU0FBTyxpQkFBaUIsQ0FBQyxPQUFPLGNBQWMsYUFBYSxLQUFJLEtBQUssR0FBRSxLQUFLLEdBQUUsTUFBTSxFQUFFLFFBQU87QUFDMUksTUFBRyxLQUFLLE1BQUs7QUFBQyxVQUFNLE9BQUssS0FBSyxNQUFNLEtBQUssQ0FBQUssVUFBTUEsTUFBSyxPQUFLLEtBQUssS0FBTSxNQUFNO0FBQUUsUUFBRyxDQUFDLEtBQUssUUFBTztBQUFLLFVBQU0sUUFBTSxLQUFLO0FBQU0sU0FBSSxNQUFNLFNBQU8sVUFBUSxNQUFNLFNBQU8saUJBQWUsTUFBTSxjQUFjLE1BQU0sZUFBYSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBUSxPQUFPLE9BQUssTUFBTSxjQUFjLE9BQU8sS0FBRyxDQUFDLEVBQUUsUUFBTztBQUFNLFVBQU0sUUFBTSxjQUFjLE1BQUssTUFBSyxLQUFLLE9BQU0sYUFBYSxNQUFLLFNBQVMsTUFBSyxNQUFLLE1BQUssS0FBSyxLQUFLLENBQUMsR0FBRSxLQUFLO0FBQUUsV0FBTyxDQUFDLFNBQVMsU0FBUyxNQUFLLGFBQWEsTUFBSyxLQUFLLENBQUMsSUFBRSxVQUFVLDBCQUEwQixNQUFLLE1BQUssTUFBSyxhQUFhLE1BQUssS0FBSyxDQUFDO0FBQUEsRUFBRTtBQUNwaUIsTUFBRyxZQUFZLElBQUksR0FBRztBQUNwQixRQUFHLE9BQU8sU0FBTyxVQUFVLE9BQU8sWUFBVSxVQUFhLEtBQUssSUFBSSxrQkFBa0IsS0FBSyxRQUFTLFNBQVEsT0FBTyxPQUFPLENBQUMsSUFBRSxLQUFLLFFBQU87QUFDdkksVUFBTSxRQUFNLEtBQUssU0FBUztBQUMxQixRQUFHLElBQUksV0FBVyxTQUFTLE1BQU0sVUFBUSxLQUFLLEtBQUssTUFBTSxVQUFRLEtBQUssRUFBRSxRQUFPLENBQUMsTUFBTSxXQUFXLE1BQU0sT0FBTyxXQUFTLEtBQUssU0FBUyxNQUFLLE1BQU0sR0FBRyxJQUFFO0FBQ3JKLFVBQU1JLE9BQUksZ0JBQWdCLEtBQUksTUFBSyxJQUFJO0FBQ3ZDLFdBQU8sQ0FBQ0EsUUFBTyxTQUFTLE1BQUtBLElBQUcsSUFBRTtBQUFBLEVBQ3BDO0FBQ0EsTUFBSSxDQUFDLElBQUksUUFBUyxRQUFPLFNBQVMsTUFBTSxJQUFJLElBQUksVUFBVSwwQkFBMEIsTUFBTSxNQUFNLE1BQU0sSUFBSTtBQUMxRyxRQUFNLFFBQVEsVUFBVSxLQUFLLElBQUk7QUFDakMsUUFBTSxRQUFRLFdBQVcsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxPQUFPLGFBQWEsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDckcsUUFBTSxNQUFNLGdCQUFnQixLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQ25ELFNBQU8sU0FBUyxNQUFNLEdBQUcsSUFBSSxVQUFVLHFCQUFxQixNQUFNLE1BQU0sT0FBTyxNQUFNLEtBQUssMEJBQTBCLE1BQU0sTUFBTSxNQUFNLEdBQUc7QUFDM0k7QUFFQSxTQUFTLE9BQU8sTUFBWSxNQUFnQztBQUMxRCxPQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU87QUFDNUIsT0FBSyxZQUFZLEVBQUUsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUU7QUFDMUM7QUFLQSxTQUFTLHFCQUFxQixNQUFZLE1BQVksTUFBZ0MsUUFBZ0I7QUFFcEcsTUFBSSxTQUFTLE1BQU0sSUFBSSxJQUFJLEtBQUssc0JBQXNCLG1CQUFtQixTQUFTLEVBQUcsUUFBTztBQUM1RixNQUFJLFVBQVU7QUFDZCx3QkFBc0IsTUFBTSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsUUFBUSxDQUFDLGFBQWE7QUFDMUYsVUFBTSxRQUFRLFNBQVMsU0FBUyxLQUFLO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLFNBQVMsTUFBTSxRQUFRLElBQUksUUFBUSxVQUFVLFNBQVMsTUFBTSxRQUFRLEtBQUssUUFBUSxFQUFHLFdBQVU7QUFBQSxFQUNoSCxDQUFDO0FBQ0QsU0FBTztBQUNUO0FBT0EsTUFBTSxjQUFjO0FBSXBCLFNBQVMsMEJBQTBCLE1BQVksTUFBWSxNQUFnQyxLQUErQjtBQUN4SCxRQUFNLE1BQU0sU0FBUyxNQUFNLEdBQUc7QUFDOUIsTUFBSSxNQUFNLFlBQWEsUUFBTztBQUM5QixRQUFNLFNBQVMsZ0JBQWdCLE1BQU0sTUFBTSxLQUFLLFNBQVMsa0JBQWtCLEdBQUcsQ0FBQyxVQUFVO0FBQ3ZGLFFBQUksVUFBVSxRQUFRLE1BQU0sVUFBVSxLQUFLLFNBQVMsU0FBUyxPQUFPLElBQUksSUFBSSxNQUFNLFNBQVMsS0FBSyxTQUFTLEVBQUcsUUFBTztBQUNuSCxVQUFNLFFBQVEsTUFBTSxNQUFNLFNBQVMsVUFBVSxNQUFNLFdBQVcsTUFBTSxLQUFLLEtBQUssTUFBTSxVQUFVLE1BQU0sS0FBSztBQUd6RyxVQUFNLFVBQVUsT0FBTyxLQUFLLEtBQUssU0FBUyxNQUFNLFlBQVksTUFBTSxNQUFNLFNBQVMsVUFBVSxNQUFNLE1BQU0sU0FBUyxpQkFBaUIsTUFBTSxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFDcEwsV0FBTyxTQUFTO0FBQUEsRUFDbEIsQ0FBQztBQUNELFNBQU8sV0FBVztBQUNwQjtBQUtBLFNBQVMsd0JBQXdCLE1BQVk7QUFDM0MsUUFBTSxNQUFNLEtBQUs7QUFDakIsYUFBVyxRQUFRLEtBQUssT0FBTztBQUM3QixRQUFHLEtBQUssS0FBSztBQUNiLFFBQUksVUFBVSxLQUFLLElBQUksTUFBTSxVQUFVLGFBQWEsS0FBSyxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEtBQUssS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFHO0FBQzlHLFVBQU0sTUFBTSxlQUFlLEtBQUssSUFBSTtBQUNwQyxRQUFJLENBQUMsSUFBSztBQUNWLFNBQUssSUFBSSxJQUFJO0FBQ2IsU0FBSyxJQUFJLElBQUk7QUFBQSxFQUNmO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsTUFBWTtBQUM5QixhQUFXLFFBQVEsS0FBSyxNQUFPLEtBQUksQ0FBQyxVQUFVLElBQUksS0FBSyxLQUFLLFVBQVUsUUFBVztBQUMvRSxRQUFHLENBQUMsS0FBSyxNQUFLO0FBQ1osWUFBTSxPQUFLLEVBQUMsR0FBRSxLQUFLLEdBQUUsR0FBRSxLQUFLLEVBQUM7QUFBRSxZQUFNLE1BQUssS0FBSyxLQUFJLEtBQUssS0FBSztBQUM3RCxZQUFNQyxNQUFHLHdCQUF3QixLQUFLLEtBQUksTUFBSyxNQUFLLE1BQUssS0FBSyxLQUFLO0FBQ25FLFVBQUdBLElBQUcsTUFBSSxLQUFLLEtBQUtBLElBQUcsTUFBSSxLQUFLLEdBQUU7QUFBQyxhQUFLLElBQUVBLElBQUc7QUFBRSxhQUFLLElBQUVBLElBQUc7QUFBRSxhQUFLLFFBQU07QUFBVSxhQUFLLFFBQU07QUFBQSxNQUFVO0FBQ3JHO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFBTSxFQUFDLEdBQUUsS0FBSyxJQUFFLFFBQVEsS0FBSyxLQUFLLEdBQUUsR0FBRSxLQUFLLElBQUUsUUFBUSxLQUFLLFNBQU8sQ0FBQyxFQUFDO0FBQ3pFLFVBQU0sS0FBRyxvQkFBb0IsTUFBSyxNQUFLLEtBQUs7QUFDNUMsV0FBTyxPQUFPLE1BQUssRUFBQyxHQUFFLEdBQUcsR0FBRSxHQUFFLEdBQUcsRUFBQyxDQUFDO0FBQ2xDLFVBQU0sUUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLEtBQUssU0FBTyxDQUFDLEdBQUUsT0FBSyxLQUFLLElBQUksR0FBRSxRQUFNLFFBQVEsYUFBYSxDQUFDO0FBQzdGLFFBQUcsU0FBTyxLQUFLLE9BQUssTUFBSztBQUFDLFdBQUssUUFBTTtBQUFVLFdBQUssUUFBTTtBQUFBLElBQVUsT0FBSztBQUFDLFdBQUssU0FBTyxPQUFLO0FBQU0sV0FBSyxTQUFPLEtBQUssU0FBTyxLQUFHLE9BQUs7QUFBQSxJQUFNO0FBQUEsRUFDekk7QUFDRjtBQW9CQSxNQUFNLG1CQUFtQixvQkFBSSxRQUErQjtBQUU1RCxTQUFTLHVCQUF1QixPQUF3QjtBQUN0RCxhQUFXLFVBQVUsTUFBTSxTQUFTO0FBQ2xDLGFBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxPQUFPLEtBQUssRUFBRyxRQUFPLE1BQU0sQ0FBQyxJQUFJO0FBQzVELFdBQU8sUUFBUTtBQUNmLFVBQU0sT0FBTyxPQUFPLElBQUksSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxRQUFRLFNBQVM7QUFDdkIsUUFBTSxNQUFNLFNBQVM7QUFDckIsUUFBTSxRQUFRO0FBQ2hCO0FBRUEsU0FBUywwQkFBMEIsT0FBd0I7QUFDekQseUJBQXVCLEtBQUs7QUFDNUIsUUFBTSxRQUFRLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxFQUFFLFNBQVMsTUFBTSxFQUFFLFNBQVM7QUFDckc7QUFFQSxTQUFTLDBCQUEwQixNQUFZO0FBQzdDLFFBQU0sUUFBUSxpQkFBaUIsSUFBSSxJQUFJO0FBQ3ZDLE1BQUksTUFBTywyQkFBMEIsS0FBSztBQUM1QztBQUtBLFNBQVMscUJBQXFCLE9BQXdCLEtBQXFCO0FBQ3pFLE1BQUksT0FBTyxLQUFLLEtBQUssS0FBSyxVQUFVLE1BQU0sTUFBTTtBQUNoRCxNQUFJO0FBQ0osU0FBUSxTQUFTLE1BQU0sT0FBTyxJQUFJLEdBQUk7QUFDcEMsUUFBSSxPQUFPLFFBQVEsT0FBTyxPQUFPLFFBQVEsT0FBTyxPQUFPLFFBQVEsSUFBSyxRQUFPO0FBQzNFLFdBQVEsT0FBTyxJQUFLLE1BQU07QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsNEJBQTRCLE1BQVksT0FBd0IsVUFBa0IsWUFBOEI7QUFDdkgsUUFBTSxrQkFBa0IsTUFBTSxtQkFBbUI7QUFDakQsTUFBSSxDQUFDLE1BQU0sTUFBTyxRQUFPO0FBQ3pCLE1BQUksU0FBUztBQUNiLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQzdDLFVBQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQztBQUd6QixRQUFJLGVBQWUsVUFBVSxJQUFJLEtBQUssV0FBVyxLQUFLLElBQUksTUFBTSxXQUFXLElBQUksRUFBRztBQUNsRixRQUFJLE1BQU0sUUFBUSxNQUFNLE1BQU0sUUFDekIsQ0FBQyxPQUFPLEdBQUcsTUFBTSxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLE1BQU0sTUFBTSxHQUFHLEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxDQUFDLEtBQ3BHLENBQUMsT0FBTyxHQUFHLE1BQU0sRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxNQUFNLE1BQU0sR0FBRyxLQUFLLE1BQU0sS0FBSyxJQUFJLFFBQVEsQ0FBQyxHQUFHO0FBQzFHLFlBQU0sa0JBQWtCO0FBQUcsWUFBTSxtQkFBbUI7QUFDcEQsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNLEVBQUUsTUFBTSxJQUFJLEtBQUs7QUFBRyxVQUFNLEVBQUUsTUFBTSxJQUFJLEtBQUs7QUFDakQsY0FBVTtBQUFBLEVBQ1o7QUFDQSxRQUFNLGtCQUFrQixLQUFLLE1BQU07QUFBUSxRQUFNLG1CQUFtQjtBQUNwRSxTQUFPLFdBQVcsTUFBTSxRQUFRO0FBQ2xDO0FBRUEsU0FBUyxjQUFjLE1BQVksWUFBcUI7QUFDdEQsUUFBTSxXQUFXO0FBQ2pCLE1BQUksUUFBUSxpQkFBaUIsSUFBSSxJQUFJO0FBQ3JDLE1BQUksQ0FBQyxPQUFPO0FBQ1YsWUFBUSxFQUFFLFNBQVMsQ0FBQyxHQUFHLFFBQVEsSUFBSSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUksT0FBTyxJQUFJLE1BQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLE9BQU8sT0FBTyxpQkFBaUIsR0FBRyxrQkFBa0IsRUFBRTtBQUMvTCxxQkFBaUIsSUFBSSxNQUFNLEtBQUs7QUFBQSxFQUNsQztBQUNBLFFBQU0sVUFBVSxNQUFNO0FBQ3RCLFFBQU0sU0FBUyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxTQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUcsRUFBRTtBQUNyRCxRQUFNLGFBQWEsQ0FBQyxLQUFLLElBQUksV0FBVyxxQkFBcUIsS0FBSyxLQUFLO0FBQ3ZFLE1BQUksQ0FBQyw0QkFBNEIsTUFBTSxPQUFPLFVBQVUsVUFBVSxHQUFHO0FBSW5FLFVBQU0sU0FBUyxNQUFNLGtCQUFrQixjQUFjLE1BQU07QUFDM0QsMkJBQXVCLEtBQUs7QUFFNUIsUUFBSSxXQUFXLE1BQU0sT0FBTyxHQUFHLFFBQVEsTUFBTTtBQUM3QyxXQUFPLFdBQVcsS0FBSyxNQUFNLFNBQVMsR0FBRztBQUFFLGtCQUFZO0FBQUcsZUFBUztBQUFBLElBQUc7QUFDdEUsUUFBSSxhQUFhLE1BQU0sT0FBTyxHQUFHO0FBQy9CLFlBQU0sU0FBUyxJQUFJLE1BQU0sUUFBUTtBQUFHLFlBQU0sT0FBTyxXQUFXO0FBQUcsWUFBTSxRQUFRO0FBQUEsSUFDL0U7QUFDQSxRQUFJLE9BQU8sR0FBRyxTQUFTO0FBR3ZCLFVBQU0sU0FBUyxDQUFDLE1BQVksR0FBVyxNQUFjO0FBQ25ELFlBQU0sTUFBTSxpQkFBaUIsR0FBRyxDQUFDO0FBQ2pDLFlBQU0sT0FBTyxxQkFBcUIsT0FBTyxHQUFHO0FBQzVDLFVBQUksU0FBUyxNQUFNLE9BQU8sSUFBSTtBQUM5QixVQUFJLENBQUMsUUFBUTtBQUNYLGlCQUFTLE1BQU0sS0FBSyxNQUFNO0FBQzFCLFlBQUksUUFBUTtBQUNWLGlCQUFPLE1BQU07QUFBSyxpQkFBTyxPQUFPO0FBQU0saUJBQU8sSUFBSTtBQUFHLGlCQUFPLElBQUk7QUFBRyxpQkFBTyxRQUFRO0FBQUEsUUFDbkYsT0FBTztBQUNMLG1CQUFTLEVBQUUsS0FBSyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxPQUFPLEVBQUU7QUFDaEQsZ0JBQU0sS0FBSyxLQUFLLE1BQU07QUFBQSxRQUN4QjtBQUNBLGNBQU0sT0FBTyxJQUFJLElBQUk7QUFDckIsZ0JBQVEsS0FBSyxNQUFNO0FBQUEsTUFDckI7QUFDQSxZQUFNLFFBQVEsTUFBTSxJQUFJO0FBQ3hCLFlBQU0sRUFBRSxNQUFNLElBQUksS0FBSztBQUFHLFlBQU0sRUFBRSxNQUFNLElBQUksS0FBSztBQUNqRCxZQUFNLE1BQU0sTUFBTSxJQUFJO0FBQUcsWUFBTSxNQUFNLFFBQVEsSUFBSTtBQUNqRCxhQUFPLE1BQU0sT0FBTyxPQUFPLElBQUk7QUFBQSxJQUNqQztBQUNBLGFBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLEVBQUcsUUFBTyxNQUFNLFFBQVEsQ0FBQyxHQUFJLE1BQU0sTUFBTSxDQUFDLEdBQUksTUFBTSxNQUFNLENBQUMsQ0FBRTtBQUM5RixhQUFTLElBQUksYUFBYSxJQUFJLEtBQUssTUFBTSxRQUFRLEtBQUssR0FBRztBQUN2RCxZQUFNLE9BQU8sS0FBSyxNQUFNLENBQUM7QUFFekIsVUFBSSxlQUFlLFVBQVUsSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLE1BQU0sV0FBVyxJQUFJLEVBQUc7QUFDbEYsYUFBTyxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxHQUFHLEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxDQUFDO0FBQUEsSUFDM0U7QUFDQSxVQUFNLFFBQVEsU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLEVBQUUsU0FBUyxNQUFNLEVBQUUsU0FBUztBQUNuRyxlQUFXLFVBQVUsU0FBUztBQUM1QixZQUFNLE1BQU0sS0FBSyxRQUFRLE1BQU07QUFDL0IsaUJBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxzQkFBc0I7QUFDM0MsY0FBTSxXQUFXLE1BQU0sT0FBTyxxQkFBcUIsT0FBTyxpQkFBaUIsT0FBTyxJQUFJLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQ3pHLFlBQUksU0FBVSxPQUFNLE1BQU0sS0FBSyxRQUFRLFFBQVE7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFFQSxVQUFNLFFBQVE7QUFBQSxFQUNoQjtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQzlDLHdCQUFvQixNQUFNLE1BQU0sTUFBTSxDQUFDLEdBQUksTUFBTSxNQUFNLElBQUksQ0FBQyxHQUFJLFFBQVEsUUFBUSxZQUFZLFVBQVU7QUFBQSxFQUN4RztBQUdGO0FBRUEsTUFBTSx1QkFBdUI7QUFBQSxFQUMzQixDQUFDLEdBQUcsRUFBRTtBQUFBLEVBQ04sQ0FBQyxHQUFHLENBQUM7QUFBQSxFQUNMLENBQUMsR0FBRyxDQUFDO0FBQUEsRUFDTCxDQUFDLEdBQUcsQ0FBQztBQUNQO0FBRUEsU0FBUyxvQkFBb0IsTUFBWSxTQUEyQixTQUEyQixRQUF1QixRQUF1QixZQUFxQixZQUFxQjtBQUNyTCxRQUFNLFNBQVMsUUFBUSxPQUFPLFNBQVMsUUFBUTtBQUMvQyxRQUFNLGFBQWEsWUFBWTtBQUMvQixXQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsT0FBTyxLQUFLLEdBQUc7QUFDekMsVUFBTSxRQUFRLGFBQWEsSUFBSSxJQUFJO0FBQ25DLFVBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsYUFBUyxJQUFJLE9BQU8sSUFBSSxRQUFRLE9BQU8sS0FBSyxHQUFHO0FBQzdDLFlBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsWUFBTSxjQUFjLEVBQUUsU0FBUyxFQUFFO0FBQ2pDLFlBQU0sS0FBSyxFQUFFLElBQUksRUFBRTtBQUNuQixZQUFNLEtBQUssRUFBRSxJQUFJLEVBQUU7QUFDbkIsWUFBTSxhQUFhLEtBQUssS0FBSyxLQUFLO0FBQ2xDLFVBQUksY0FBYyxjQUFjLFlBQWE7QUFDN0MsdUJBQWlCLE1BQU0sR0FBRyxHQUFHLGFBQWEsSUFBSSxJQUFJLFFBQVEsUUFBUSxZQUFZLFVBQVU7QUFBQSxJQUMxRjtBQUFBLEVBQ0Y7QUFDRjtBQUtBLFNBQVMsV0FBVyxNQUFZO0FBQzlCLFNBQU8sS0FBSyxTQUFTLFlBQVksS0FBSyxNQUFNLFNBQVM7QUFDdkQ7QUFJQSxTQUFTLGlCQUFpQixNQUFZLEdBQVMsR0FBUyxhQUFxQixJQUFZLElBQVksUUFBdUIsUUFBdUIsWUFBcUIsWUFBcUI7QUFDM0wsTUFBSSxTQUF1QyxRQUFRLFNBQXVDO0FBQzFGLE1BQUksWUFBWTtBQUNkLFFBQUcsRUFBRSxRQUFRLEVBQUUsTUFBSztBQUFDLFVBQUcsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxLQUFLLFdBQVMsRUFBRSxLQUFLLE9BQU87QUFBQSxJQUFPO0FBQ25GLGFBQVMsVUFBVSxFQUFFLElBQUk7QUFBRyxhQUFTLFVBQVUsRUFBRSxJQUFJO0FBQ3JELFFBQUksV0FBVyxPQUFRO0FBQUEsRUFDekI7QUFDQSxRQUFNLFNBQVMsT0FBTyxJQUFJLEVBQUU7QUFDNUIsUUFBTSxLQUFLLFdBQVcsSUFBSSxJQUFJLEtBQUs7QUFDbkMsUUFBTSxLQUFLLFdBQVcsSUFBSSxJQUFJLEtBQUs7QUFDbkMsTUFBSSxFQUFFLFVBQVUsVUFBYSxFQUFFLFVBQVUsT0FBVyxhQUFZLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDNUUsUUFBTSxRQUFRLGNBQWMsVUFBVTtBQUN0QyxRQUFNLEtBQUssTUFBTSxFQUFFLElBQUksS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUs7QUFDbkQsUUFBTSxLQUFLLE1BQU0sRUFBRSxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssSUFBSSxNQUFNO0FBQ3BELFFBQU0sS0FBSyxNQUFNLEVBQUUsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSztBQUNuRCxRQUFNLEtBQUssTUFBTSxFQUFFLElBQUksS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDcEQsTUFBSSxjQUFjLENBQUMsRUFBRSxRQUFRLENBQUMsRUFBRSxNQUFNO0FBR3BDLE1BQUUsSUFBSTtBQUFJLE1BQUUsSUFBSTtBQUFJLE1BQUUsSUFBSTtBQUFJLE1BQUUsSUFBSTtBQUNwQztBQUFBLEVBQ0Y7QUFFQSxTQUFPLElBQUk7QUFBSSxTQUFPLElBQUk7QUFDMUIsUUFBTSxNQUFNLENBQUMsYUFBYSxTQUFTLEtBQUssS0FBSyxHQUFHLFFBQVEsTUFBTSxJQUMxRCxFQUFFLE9BQU8sb0JBQW9CLE1BQUssR0FBRSxNQUFNLElBQUksd0JBQXdCLEtBQUssS0FBSSxHQUFFLEdBQUUsU0FBUyxLQUFLLEtBQUssR0FBRyxRQUFRLE1BQU0sR0FBRSxLQUFLLEtBQUs7QUFDdkksU0FBTyxJQUFJO0FBQUksU0FBTyxJQUFJO0FBQzFCLFFBQU0sTUFBTSxDQUFDLGFBQWEsU0FBUyxLQUFLLEtBQUssR0FBRyxRQUFRLE1BQU0sSUFDMUQsRUFBRSxPQUFPLG9CQUFvQixNQUFLLEdBQUUsTUFBTSxJQUFJLHdCQUF3QixLQUFLLEtBQUksR0FBRSxHQUFFLFNBQVMsS0FBSyxLQUFLLEdBQUcsUUFBUSxNQUFNLEdBQUUsS0FBSyxLQUFLO0FBQ3ZJLElBQUUsSUFBSSxJQUFJO0FBQ1YsSUFBRSxJQUFJLElBQUk7QUFDVixJQUFFLElBQUksSUFBSTtBQUNWLElBQUUsSUFBSSxJQUFJO0FBQ1o7QUFFQSxTQUFTLG9CQUFvQixNQUFVLE1BQVUsT0FBMkI7QUFDMUUsUUFBTSxPQUFLLEtBQUssTUFBTSxLQUFLLENBQUFMLFVBQU1BLE1BQUssT0FBSyxLQUFLLEtBQU0sTUFBTTtBQUM1RCxNQUFHLENBQUMsS0FBSyxRQUFPO0FBQ2hCLFFBQU0sUUFBTSxhQUFhLE1BQUssS0FBSztBQUNuQyxNQUFHLENBQUMsY0FBYyxNQUFLLE1BQUssT0FBTSxLQUFLLE9BQU0sS0FBSyxFQUFFLFFBQU87QUFDM0QsU0FBTyxPQUFPLEtBQUssTUFBTSxLQUFLO0FBQUUsU0FBTztBQUN6QztBQUVBLFNBQVMsaUJBQWlCLEdBQVcsR0FBVztBQUM5QyxTQUFPLElBQUksTUFBTztBQUNwQjtBQUVBLFNBQVMsaUJBQWlCLFFBQXVCLFVBQWtCO0FBQ2pFLFNBQU8saUJBQWlCLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxHQUFHLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxDQUFDO0FBQzFGO0FBRUEsTUFBTSxvQkFBb0Isb0JBQUksUUFBMEc7QUFHeEksU0FBUyxtQkFBNEMsVUFBZSxVQUFrQixVQUE2QztBQUNqSSxRQUFNLFNBQVMsWUFBWSxPQUFPLEdBQUcsU0FBUyxVQUFVLFFBQVEsSUFBSSxrQkFBa0IsSUFBSSxRQUFRLElBQUk7QUFDdEcsTUFBSSxTQUFTO0FBQ2IsTUFBSSxVQUFVLE9BQU8sUUFBUSxXQUFXLFNBQVMsUUFBUTtBQUN2RCxRQUFJLFlBQVk7QUFDaEIsYUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSyxHQUFHO0FBQzNDLFlBQU0sU0FBUyxTQUFTLENBQUM7QUFDekIsVUFBSSxPQUFPLFFBQVEsQ0FBQyxNQUFNLFVBQ3JCLENBQUMsT0FBTyxHQUFHLE9BQU8sRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxNQUFNLENBQUMsR0FBRyxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVEsQ0FBQyxLQUNoRyxDQUFDLE9BQU8sR0FBRyxPQUFPLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sTUFBTSxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxRQUFRLENBQUMsR0FBRztBQUN0RyxvQkFBWTtBQUNaO0FBQUEsTUFDRjtBQUNBLGFBQU8sRUFBRSxDQUFDLElBQUksT0FBTztBQUFHLGFBQU8sRUFBRSxDQUFDLElBQUksT0FBTztBQUM3QyxlQUFTLElBQUk7QUFBQSxJQUNmO0FBR0EsUUFBSSxVQUFXLFFBQU87QUFBQSxFQUN4QjtBQUNBLFFBQU0sVUFBVSxvQkFBSSxJQUFpQjtBQUlyQyxNQUFJLE9BQVEsbUJBQWtCLE9BQU8sUUFBUztBQUM5QyxRQUFNLFVBQVUsUUFBUSxXQUFXLENBQUM7QUFDcEMsUUFBTSxRQUFRLFFBQVEsU0FBUyxDQUFDLEdBQUcsUUFBUSxRQUFRLFNBQVMsQ0FBQztBQUM3RCxRQUFNLGFBQWEsU0FBUyxPQUFPLElBQUksQ0FBQyxHQUFHLGFBQWEsU0FBUyxPQUFPLElBQUksQ0FBQztBQUM3RSxNQUFJLE9BQU8sVUFBVSxRQUFRLFdBQVcsTUFBTSxVQUFVLFNBQVM7QUFDakUsV0FBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSyxHQUFHO0FBQzNDLFVBQU0sU0FBUyxTQUFTLENBQUM7QUFDekIsVUFBTSxJQUFJLElBQUksU0FBUyxNQUFNLENBQUMsSUFBSyxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVE7QUFDakUsVUFBTSxJQUFJLElBQUksU0FBUyxNQUFNLENBQUMsSUFBSyxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVE7QUFDakUsWUFBUSxDQUFDLElBQUk7QUFBUSxlQUFXLENBQUMsSUFBSSxPQUFPO0FBQUcsZUFBVyxDQUFDLElBQUksT0FBTztBQUN0RSxVQUFNLENBQUMsSUFBSTtBQUFHLFVBQU0sQ0FBQyxJQUFJO0FBQ3pCLFdBQU8sS0FBSyxJQUFJLE1BQU0sQ0FBQztBQUFHLFlBQVEsS0FBSyxJQUFJLE9BQU8sQ0FBQztBQUNuRCxVQUFNLEtBQUssSUFBSSxLQUFLLENBQUM7QUFBRyxhQUFTLEtBQUssSUFBSSxRQUFRLENBQUM7QUFDbkQsVUFBTSxNQUFNLGlCQUFpQixHQUFHLENBQUM7QUFDakMsVUFBTSxTQUFTLFFBQVEsSUFBSSxHQUFHO0FBQzlCLFFBQUksT0FBUSxRQUFPLEtBQUssTUFBTTtBQUFBLFFBQ3pCLFNBQVEsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQUEsRUFDaEM7QUFDQSxVQUFRLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxXQUFXLFNBQVMsV0FBVyxTQUFTLFNBQVM7QUFDaEcsUUFBTSxRQUFRLEVBQUUsTUFBTSxRQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSyxPQUFPO0FBRTdFLG9CQUFrQixJQUFJLE9BQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxHQUFHLFlBQVksR0FBRyxXQUFXLENBQUM7QUFDcEYsU0FBTztBQUNUO0FBRUEsTUFBTSx3QkFBd0Isb0JBQUksUUFRL0I7QUFFSCxTQUFTLHlCQUFxRSxNQUFZLFVBQWUsVUFBa0IsVUFBdUU7QUFDaE0sUUFBTSxTQUFTLFdBQVcsc0JBQXNCLElBQUksUUFBUSxJQUFJO0FBQ2hFLE1BQUksU0FBUztBQUNiLE1BQUksVUFBVSxPQUFPLEdBQUcsT0FBTyxVQUFVLFFBQVEsS0FBSyxPQUFPLFFBQVEsV0FBVyxTQUFTLFFBQVE7QUFDL0YsUUFBSSxZQUFZO0FBQ2hCLGFBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssR0FBRztBQUMzQyxZQUFNLFNBQVMsU0FBUyxDQUFDO0FBQ3pCLFVBQUksT0FBTyxRQUFRLENBQUMsTUFBTSxVQUNyQixDQUFDLE9BQU8sR0FBRyxPQUFPLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sTUFBTSxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxRQUFRLENBQUMsS0FDaEcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLE1BQU0sQ0FBQyxHQUFHLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxDQUFDLEtBQ2hHLE9BQU8sTUFBTSxDQUFDLE1BQU0sUUFBUSxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQ3BELG9CQUFZO0FBQ1o7QUFBQSxNQUNGO0FBQ0EsYUFBTyxFQUFFLENBQUMsSUFBSSxPQUFPO0FBQUcsYUFBTyxFQUFFLENBQUMsSUFBSSxPQUFPO0FBQzdDLGVBQVMsSUFBSTtBQUFBLElBQ2Y7QUFHQSxRQUFJLFVBQVcsUUFBTztBQUFBLEVBQ3hCO0FBQ0EsUUFBTSxVQUFVLG9CQUFJLElBQTZCO0FBQ2pELFFBQU0sV0FBVyxVQUFVLE9BQU8sR0FBRyxPQUFPLFVBQVUsUUFBUSxJQUFJLFNBQVM7QUFDM0UsTUFBSSxTQUFVLHVCQUFzQixPQUFPLFFBQVM7QUFDcEQsUUFBTSxVQUFVLFVBQVUsV0FBVyxDQUFDO0FBQ3RDLFFBQU0sUUFBUSxVQUFVLFNBQVMsQ0FBQyxHQUFHLFFBQVEsVUFBVSxTQUFTLENBQUMsR0FBRyxRQUFRLFVBQVUsU0FBUyxDQUFDO0FBQ2hHLFFBQU0sYUFBYSxXQUFXLFNBQVMsSUFBSSxDQUFDLEdBQUcsYUFBYSxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQ3JGLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssR0FBRztBQUMzQyxVQUFNLFNBQVMsU0FBUyxDQUFDO0FBQ3pCLFVBQU0sT0FBTyxJQUFJLFNBQVMsTUFBTSxDQUFDLElBQUssUUFBUSxNQUFNLE9BQU8sS0FBSztBQUNoRSxZQUFRLENBQUMsSUFBSTtBQUFRLGVBQVcsQ0FBQyxJQUFJLE9BQU87QUFBRyxlQUFXLENBQUMsSUFBSSxPQUFPO0FBQ3RFLFVBQU0sQ0FBQyxJQUFJO0FBQ1gsUUFBSSxRQUFRLFFBQVEsSUFBSSxJQUFJO0FBQzVCLFFBQUksQ0FBQyxNQUFPLFNBQVEsSUFBSSxNQUFNLFFBQVEsRUFBRSxNQUFNLFVBQVUsU0FBUyxvQkFBSSxJQUFJLEdBQUcsTUFBTSxVQUFVLE9BQU8sV0FBVyxLQUFLLFVBQVUsUUFBUSxVQUFVLENBQUM7QUFDaEosVUFBTSxJQUFJLElBQUksU0FBUyxNQUFNLENBQUMsSUFBSyxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVE7QUFDakUsVUFBTSxJQUFJLElBQUksU0FBUyxNQUFNLENBQUMsSUFBSyxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVE7QUFDakUsVUFBTSxDQUFDLElBQUk7QUFBRyxVQUFNLENBQUMsSUFBSTtBQUN6QixVQUFNLE9BQU8sS0FBSyxJQUFJLE1BQU0sTUFBTSxDQUFDO0FBQUcsVUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLE9BQU8sQ0FBQztBQUMzRSxVQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxDQUFDO0FBQUcsVUFBTSxTQUFTLEtBQUssSUFBSSxNQUFNLFFBQVEsQ0FBQztBQUMzRSxVQUFNLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxHQUFHLFNBQVMsTUFBTSxRQUFRLElBQUksR0FBRztBQUNsRSxRQUFJLE9BQVEsUUFBTyxLQUFLLE1BQU07QUFBQSxRQUN6QixPQUFNLFFBQVEsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQUEsRUFDdEM7QUFDQSxVQUFRLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxNQUFNLFNBQVMsV0FBVyxTQUFTLFdBQVcsU0FBUyxTQUFTO0FBQy9HLHdCQUFzQixJQUFJLFNBQVMsRUFBRSxVQUFVLFNBQVMsT0FBTyxPQUFPLE9BQU8sR0FBRyxZQUFZLEdBQUcsV0FBVyxDQUFDO0FBQzNHLFNBQU87QUFDVDtBQUVBLE1BQU0sZ0JBQWdCLG9CQUFJLFFBQXNIO0FBQ2hKLFNBQVMsa0JBQWtCLE1BQVk7QUFDckMsUUFBTSxTQUFTLGNBQWMsSUFBSSxLQUFLLEtBQUs7QUFDM0MsTUFBSSxVQUFVLE9BQU8sVUFBVSxLQUFLLE1BQU0sVUFBVSxPQUFPLGNBQWMsS0FBSyxhQUFhLE9BQU8sa0JBQWtCLEtBQUssVUFBVSxPQUFRLFFBQU8sT0FBTztBQUN6SixRQUFNLFFBQVEsb0JBQUksSUFBNkI7QUFDL0MsYUFBVyxRQUFRLEtBQUssTUFBTyxPQUFNLElBQUksS0FBSyxJQUFJLElBQUk7QUFDdEQsYUFBVyxZQUFZLEtBQUssVUFBVyxPQUFNLElBQUksU0FBUyxJQUFJLFFBQVE7QUFDdEUsZ0JBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxPQUFPLEtBQUssTUFBTSxRQUFRLFdBQVcsS0FBSyxXQUFXLGVBQWUsS0FBSyxVQUFVLFFBQVEsTUFBTSxDQUFDO0FBQ2xJLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLE1BQVksT0FBaUMsT0FBZSxPQUE2QjtBQUNsSCxzQkFBb0IsS0FBSyxhQUFhLEtBQUssT0FBTyxPQUFPLE9BQU8sVUFBUTtBQUFFLFFBQUksQ0FBQyxVQUFVLElBQUksRUFBRyxPQUFNLElBQUk7QUFBQSxFQUFHLENBQUM7QUFDaEg7QUFHQSxTQUFTLGdCQUFnQixNQUFZLE9BQWlDLE9BQWUsTUFBaUQ7QUFDcEksUUFBTSxRQUFRLEtBQUs7QUFDbkIsTUFBSSxDQUFDLE1BQU8sUUFBTyxLQUFLLE1BQU0sS0FBSyxVQUFRLENBQUMsVUFBVSxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUM7QUFHekUsUUFBTSxPQUFPLE1BQU07QUFDbkIsUUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxPQUFPLE1BQU0sSUFBSSxTQUFTLElBQUksQ0FBQztBQUN4RSxRQUFNLFNBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLE9BQU8sTUFBTSxJQUFJLFNBQVMsSUFBSSxDQUFDO0FBQzFFLFFBQU0sTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLElBQUksU0FBUyxJQUFJLENBQUM7QUFDcEUsV0FBUyxJQUFJLEtBQUssSUFBSSxNQUFNLE1BQU0sS0FBSyxPQUFPLE1BQU0sSUFBSSxTQUFTLElBQUksQ0FBQyxHQUFHLEtBQUssT0FBTyxLQUFLLEdBQUc7QUFDM0YsYUFBUyxJQUFJLEtBQUssS0FBSyxRQUFRLEtBQUssR0FBRztBQUNyQyxZQUFNLFNBQVMsTUFBTSxRQUFRLElBQUksaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZELFVBQUksQ0FBQyxPQUFRO0FBQ2IsaUJBQVcsUUFBUSxPQUFRLEtBQUksQ0FBQyxVQUFVLElBQUksS0FBSyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQUEsSUFDeEU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxzQkFBc0IsTUFBWSxPQUFpQyxPQUFlLE9BQXFDO0FBQzlILHNCQUFvQixLQUFLLGlCQUFpQixLQUFLLFdBQVcsT0FBTyxPQUFPLEtBQUs7QUFDL0U7QUFFQSxTQUFTLHVCQUF1QixNQUFZLE9BQWMsT0FBaUMsT0FBZSxPQUE2QjtBQUNySSxRQUFNLFVBQVUsS0FBSztBQUNyQixNQUFJLENBQUMsU0FBUztBQUNaLHNCQUFrQixNQUFNLE9BQU8sT0FBTyxDQUFDLFNBQVM7QUFDOUMsVUFBSSxlQUFlLE1BQU0sT0FBTyxLQUFLLEtBQUssRUFBRyxPQUFNLElBQUk7QUFBQSxJQUN6RCxDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxVQUFVLFFBQVEsTUFBTSxLQUFLO0FBQ25DLGFBQVcsU0FBUyxRQUFRLE9BQU8sRUFBRyxLQUFJLE1BQU0sU0FBUyxRQUFTLHFCQUFvQixPQUFPLEtBQUssT0FBTyxPQUFPLE9BQU8sS0FBSztBQUM5SDtBQUVBLFNBQVMsMkJBQTJCLE1BQVksT0FBYyxPQUFpQyxPQUFlLE9BQXFDO0FBQ2pKLFFBQU0sVUFBVSxLQUFLO0FBQ3JCLE1BQUksQ0FBQyxTQUFTO0FBQ1osMEJBQXNCLE1BQU0sT0FBTyxPQUFPLENBQUMsYUFBYTtBQUN0RCxVQUFJLGVBQWUsTUFBTSxPQUFPLFNBQVMsS0FBSyxFQUFHLE9BQU0sUUFBUTtBQUFBLElBQ2pFLENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFVBQVUsUUFBUSxNQUFNLEtBQUs7QUFDbkMsYUFBVyxTQUFTLFFBQVEsT0FBTyxFQUFHLEtBQUksTUFBTSxTQUFTLFFBQVMscUJBQW9CLE9BQU8sS0FBSyxXQUFXLE9BQU8sT0FBTyxLQUFLO0FBQ2xJO0FBRUEsU0FBUyxvQkFDUCxPQUNBLG1CQUNBLE9BQ0EsT0FDQSxPQUNBO0FBQ0EsTUFBSSxDQUFDLE9BQU87QUFDVixlQUFXLFVBQVUsa0JBQW1CLE9BQU0sTUFBTTtBQUNwRDtBQUFBLEVBQ0Y7QUFHQSxRQUFNLE9BQU8sTUFBTTtBQUduQixRQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sTUFBTSxJQUFJLFNBQVMsSUFBSSxDQUFDO0FBQ3hFLFFBQU0sU0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLEtBQUssT0FBTyxNQUFNLElBQUksU0FBUyxJQUFJLENBQUM7QUFDMUUsUUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sSUFBSSxTQUFTLElBQUksQ0FBQztBQUNwRSxXQUFTLElBQUksS0FBSyxJQUFJLE1BQU0sTUFBTSxLQUFLLE9BQU8sTUFBTSxJQUFJLFNBQVMsSUFBSSxDQUFDLEdBQUcsS0FBSyxPQUFPLEtBQUssR0FBRztBQUMzRixhQUFTLElBQUksS0FBSyxLQUFLLFFBQVEsS0FBSyxHQUFHO0FBQ3JDLFlBQU0sU0FBUyxNQUFNLFFBQVEsSUFBSSxpQkFBaUIsR0FBRyxDQUFDLENBQUM7QUFDdkQsVUFBSSxDQUFDLE9BQVE7QUFDYixpQkFBVyxVQUFVLE9BQVEsT0FBTSxNQUFNO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsTUFBWSxHQUFXLEdBQVcsS0FBYyxRQUF5QixDQUFDLEdBQUcsYUFBYSxNQUFNO0FBRWxILFFBQU0sT0FBTyxXQUFXLElBQUk7QUFDNUIsTUFBSSxTQUFTLEVBQUc7QUFDaEIsTUFBRyxjQUFjLFlBQVksSUFBSSxHQUFFO0FBQUMsZUFBVyxNQUFLLEVBQUMsR0FBRSxHQUFFLEdBQUksS0FBSyxNQUFNLFNBQU8sVUFBVSxLQUFLLE1BQU0sWUFBVSxTQUFVLEVBQUMsU0FBUSxLQUFLLE1BQU0sUUFBTyxJQUFFLENBQUMsRUFBRSxHQUFFLEtBQUksT0FBTSxJQUFJO0FBQUU7QUFBQSxFQUFPO0FBR2pMLFFBQU0sYUFBYSxDQUFDLGNBQWMscUJBQXFCLEtBQUs7QUFDNUQsTUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNO0FBQzVCLFVBQU0sT0FBSyxLQUFLLFFBQVEsTUFBTSxLQUFLLENBQUFBLFVBQU1BLE1BQUssT0FBSyxLQUFLLEtBQU0sTUFBTTtBQUNwRSxVQUFNLE9BQUssU0FBUyxNQUFLLFFBQVEsUUFBVSxFQUFDLEdBQUUsRUFBQyxHQUFFLEtBQUs7QUFDdEQsUUFBRyxzQkFBc0IsTUFBSyxNQUFLLE9BQU0sS0FBSSxJQUFJLEVBQUU7QUFDbkQsUUFBRyxLQUFLLE1BQUs7QUFBQyxVQUFHLEtBQUssWUFBVyxNQUFLLE1BQUssTUFBSyxPQUFNLElBQUk7QUFBRTtBQUFBLElBQU87QUFBQSxFQUNyRTtBQUNBLFFBQU0sT0FBSyxhQUFhLFNBQVksRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssRUFBQztBQUN0RCxNQUFJLElBQUksU0FBUztBQUNmLGVBQVcsTUFBTSxHQUFHLEdBQUcsS0FBSyxJQUFJO0FBQ2hDLFFBQUksTUFBTTtBQUNSLFlBQU0sS0FBRyx3QkFBd0IsS0FBSSxNQUFLLE1BQUssTUFBSyxLQUFLO0FBQ3pELFVBQUcsT0FBSyxNQUFLO0FBQUMsYUFBSyxJQUFFLEdBQUc7QUFBRSxhQUFLLElBQUUsR0FBRztBQUFBLE1BQUU7QUFBQSxJQUN4QztBQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sUUFBUSxRQUFRLEtBQUssS0FBSyxJQUFJO0FBQ3BDLFFBQU0sS0FBSyxJQUFJLEtBQUs7QUFDcEIsUUFBTSxLQUFLLElBQUksS0FBSztBQUNwQixRQUFNLFNBQVMsT0FBTyxJQUFJLEVBQUU7QUFDNUIsTUFBSSxVQUFVLFNBQVMsV0FBVyxHQUFHO0FBQ25DLFNBQUssSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLEtBQUs7QUFDOUIsU0FBSyxJQUFJLE1BQU0sR0FBRyxHQUFHLElBQUksTUFBTTtBQUMvQixRQUFJLE1BQU07QUFDUixZQUFNLEtBQUcsd0JBQXdCLEtBQUksTUFBSyxNQUFLLE1BQUssS0FBSztBQUN6RCxVQUFHLE9BQUssTUFBSztBQUFDLGFBQUssSUFBRSxHQUFHO0FBQUUsYUFBSyxJQUFFLEdBQUc7QUFBQSxNQUFFO0FBQUEsSUFDeEM7QUFDQTtBQUFBLEVBQ0Y7QUFDQSxPQUFLLElBQUksTUFBTSxLQUFLLElBQUssS0FBSyxTQUFVLE9BQU8sR0FBRyxJQUFJLEtBQUs7QUFDM0QsT0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFLLEtBQUssU0FBVSxPQUFPLEdBQUcsSUFBSSxNQUFNO0FBQzVELE1BQUksTUFBTTtBQUNSLFVBQU0sS0FBRyx3QkFBd0IsS0FBSSxNQUFLLE1BQUssTUFBSyxLQUFLO0FBQ3pELFFBQUcsT0FBSyxNQUFLO0FBQUMsV0FBSyxJQUFFLEdBQUc7QUFBRSxXQUFLLElBQUUsR0FBRztBQUFBLElBQUU7QUFBQSxFQUN4QztBQUNGO0FBTUEsU0FBUyxXQUFXLE1BQVksR0FBVyxHQUFXLEtBQWMsT0FBTyxHQUFHO0FBQzVFLFFBQU0sUUFBUSxVQUFVLEtBQUssSUFBSTtBQUNqQyxRQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLElBQUksVUFBVSxXQUFXLEtBQUssR0FBRyxHQUFHLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLGFBQWEsS0FBSyxHQUFHLEdBQUcsS0FBSztBQUM3SSxRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sTUFBTSxLQUFLO0FBQzdDLFFBQU0sS0FBSyxJQUFJLElBQUksS0FBSztBQUN4QixRQUFNLEtBQUssSUFBSSxJQUFJLEtBQUs7QUFDeEIsUUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxFQUFFO0FBQzFDLE1BQUksV0FBVyxFQUFHO0FBRWxCLFFBQU0sUUFBUSxRQUFRLEtBQUssS0FBSyxJQUFJLE9BQU8sWUFBWSxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxFQUFFO0FBQ25GLFFBQU0sUUFBUSxNQUFNLFVBQVUsUUFBUSxJQUFJLElBQUksS0FBSyxJQUFLLEtBQUssU0FBVSxPQUFPLEdBQUcsSUFBSSxLQUFLO0FBQzFGLFFBQU0sUUFBUSxNQUFNLFVBQVUsUUFBUSxJQUFJLElBQUksS0FBSyxJQUFLLEtBQUssU0FBVSxPQUFPLEdBQUcsSUFBSSxNQUFNO0FBQzNGLFFBQU0sT0FBTyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsT0FBTyxHQUFHLE1BQU0sR0FBRyxLQUFLO0FBQzlELE9BQUssSUFBSSxLQUFLO0FBQ2QsT0FBSyxJQUFJLEtBQUs7QUFDaEI7QUFFQSxTQUFTLFNBQVMsR0FBNkIsR0FBNkI7QUFDMUUsU0FBTyxPQUFPLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQztBQUNwQztBQUVBLFNBQVMsZ0JBQWdCLEdBQTZCLEdBQTZCO0FBQ2pGLFFBQU0sS0FBSyxFQUFFLElBQUksRUFBRTtBQUNuQixRQUFNLEtBQUssRUFBRSxJQUFJLEVBQUU7QUFDbkIsU0FBTyxLQUFLLEtBQUssS0FBSztBQUN4QjtBQUVBLFNBQVMsTUFBTSxPQUFlLEtBQWEsS0FBYTtBQUN0RCxTQUFPLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssQ0FBQztBQUMzQztBQUVBLFNBQVMsU0FBUyxPQUFpQztBQUNqRCxTQUFPLE9BQU8sVUFBVSxZQUFZLE9BQU8sU0FBUyxLQUFLO0FBQzNEOyIsIm5hbWVzIjpbInBvc2UiLCJpdGVtIiwidW5pdCIsImJ1aWxkaW5nIiwiam9iIiwibW91bnQiLCJwb2ludCIsInNoaXAiLCJ0YXJnZXQiLCJnb2FsIiwiaHBCZWZvcmUiLCJlbmQiLCJhdCJdfQ==