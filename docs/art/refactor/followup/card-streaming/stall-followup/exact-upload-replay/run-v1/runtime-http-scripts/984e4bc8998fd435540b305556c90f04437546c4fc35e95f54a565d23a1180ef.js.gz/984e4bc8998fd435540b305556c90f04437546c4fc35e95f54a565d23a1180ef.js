export function updateCardPixels(previous, next, width, height) {
  if (width < 1 || height < 1 || !Number.isInteger(width) || !Number.isInteger(height) || previous.byteLength !== width * height * 4 || next.byteLength !== previous.byteLength) throw new Error("Invalid card raster dimensions.");
  let left = width, top = height, right = 0, bottom = 0;
  if (previous.byteOffset % 4 === 0 && next.byteOffset % 4 === 0) {
    const a = new Uint32Array(previous.buffer, previous.byteOffset, width * height), b = new Uint32Array(next.buffer, next.byteOffset, width * height);
    for (let y = 0; y < height; y++) {
      const start2 = y * width;
      let first = 0;
      while (first < width && a[start2 + first] === b[start2 + first]) first++;
      if (first === width) continue;
      let last = width - 1;
      while (last > first && a[start2 + last] === b[start2 + last]) last--;
      left = Math.min(left, first);
      right = Math.max(right, last + 1);
      top = Math.min(top, y);
      bottom = y + 1;
    }
  } else {
    const same = (pixel) => {
      const offset = pixel * 4;
      return previous[offset] === next[offset] && previous[offset + 1] === next[offset + 1] && previous[offset + 2] === next[offset + 2] && previous[offset + 3] === next[offset + 3];
    };
    for (let y = 0; y < height; y++) {
      const start2 = y * width;
      let first = 0;
      while (first < width && same(start2 + first)) first++;
      if (first === width) continue;
      let last = width - 1;
      while (last > first && same(start2 + last)) last--;
      left = Math.min(left, first);
      right = Math.max(right, last + 1);
      top = Math.min(top, y);
      bottom = y + 1;
    }
  }
  if (top === height) return null;
  const start = top * width * 4;
  previous.set(next.subarray(start, bottom * width * 4), start);
  return { left, top, right, bottom };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcmQtdXBsb2FkLXJlZ2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogUGl4ZWwgYm91bmRzIG9mIGNoYW5nZWQgUkdCQSBjb21wb25lbnRzLCB3aXRoIGFuIGV4Y2x1c2l2ZSByaWdodC9ib3R0b20gZWRnZS5cbiAqIFRyYW5zcGFyZW50IHBpeGVscyBzdGlsbCBjYXJyeSBSR0I6IGFscGhhLW9ubHkgYm91bmRzIGFyZSBub3QgbG9zc2xlc3MuICovXG5leHBvcnQgdHlwZSBDYXJkVXBsb2FkUmVnaW9uPXtsZWZ0Om51bWJlcjt0b3A6bnVtYmVyO3JpZ2h0Om51bWJlcjtib3R0b206bnVtYmVyfTtcblxuLyoqIFVwZGF0ZSB0aGUgZXhpc3RpbmcgZnVsbC1kb21haW4gcmFzdGVyIGFuZCByZXR1cm4gdGhlIHNtYWxsZXN0IHJlY3RhbmdsZSB0aGF0XG4gKiByZXN0b3JlcyBpdHMgR1BVIGNvcHkuIE9sZCBtYXJrcyBkaXNhcHBlYXJpbmcgdG8gemVybyBhcmUgY2hhbmdlcyB0b28uICovXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2FyZFBpeGVscyhwcmV2aW91czpVaW50OEFycmF5LG5leHQ6VWludDhBcnJheXxVaW50OENsYW1wZWRBcnJheSx3aWR0aDpudW1iZXIsaGVpZ2h0Om51bWJlcik6Q2FyZFVwbG9hZFJlZ2lvbnxudWxsIHtcbiBpZih3aWR0aDwxfHxoZWlnaHQ8MXx8IU51bWJlci5pc0ludGVnZXIod2lkdGgpfHwhTnVtYmVyLmlzSW50ZWdlcihoZWlnaHQpfHxwcmV2aW91cy5ieXRlTGVuZ3RoIT09d2lkdGgqaGVpZ2h0KjR8fG5leHQuYnl0ZUxlbmd0aCE9PXByZXZpb3VzLmJ5dGVMZW5ndGgpdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGNhcmQgcmFzdGVyIGRpbWVuc2lvbnMuJyk7XG4gbGV0IGxlZnQ9d2lkdGgsdG9wPWhlaWdodCxyaWdodD0wLGJvdHRvbT0wO1xuIC8vIFJhc3RlciBidWZmZXJzIG5vcm1hbGx5IGhhdmUgYWxpZ25lZCBvZmZzZXRzLiBUaGUgYnl0ZSBwYXRoIGFsc28gc3VwcG9ydHMgYVxuIC8vIGNhbGxlcidzIHN1YmFycmF5IHdpdGhvdXQgY3JlYXRpbmcgYW4gYWRkaXRpb25hbCBmdWxsLXNpemUgcGl4ZWwgY29weS5cbiBpZihwcmV2aW91cy5ieXRlT2Zmc2V0JTQ9PT0wJiZuZXh0LmJ5dGVPZmZzZXQlND09PTApe1xuICBjb25zdCBhPW5ldyBVaW50MzJBcnJheShwcmV2aW91cy5idWZmZXIscHJldmlvdXMuYnl0ZU9mZnNldCx3aWR0aCpoZWlnaHQpLGI9bmV3IFVpbnQzMkFycmF5KG5leHQuYnVmZmVyLG5leHQuYnl0ZU9mZnNldCx3aWR0aCpoZWlnaHQpO1xuICBmb3IobGV0IHk9MDt5PGhlaWdodDt5Kyspe1xuICAgY29uc3Qgc3RhcnQ9eSp3aWR0aDtsZXQgZmlyc3Q9MDtcbiAgIHdoaWxlKGZpcnN0PHdpZHRoJiZhW3N0YXJ0K2ZpcnN0XT09PWJbc3RhcnQrZmlyc3RdKWZpcnN0Kys7XG4gICBpZihmaXJzdD09PXdpZHRoKWNvbnRpbnVlO1xuICAgbGV0IGxhc3Q9d2lkdGgtMTt3aGlsZShsYXN0PmZpcnN0JiZhW3N0YXJ0K2xhc3RdPT09YltzdGFydCtsYXN0XSlsYXN0LS07XG4gICBsZWZ0PU1hdGgubWluKGxlZnQsZmlyc3QpO3JpZ2h0PU1hdGgubWF4KHJpZ2h0LGxhc3QrMSk7dG9wPU1hdGgubWluKHRvcCx5KTtib3R0b209eSsxO1xuICB9XG4gfWVsc2V7XG4gIGNvbnN0IHNhbWU9KHBpeGVsOm51bWJlcik9Pntjb25zdCBvZmZzZXQ9cGl4ZWwqNDtyZXR1cm4gcHJldmlvdXNbb2Zmc2V0XT09PW5leHRbb2Zmc2V0XSYmcHJldmlvdXNbb2Zmc2V0KzFdPT09bmV4dFtvZmZzZXQrMV0mJnByZXZpb3VzW29mZnNldCsyXT09PW5leHRbb2Zmc2V0KzJdJiZwcmV2aW91c1tvZmZzZXQrM109PT1uZXh0W29mZnNldCszXTt9O1xuICBmb3IobGV0IHk9MDt5PGhlaWdodDt5Kyspe1xuICAgY29uc3Qgc3RhcnQ9eSp3aWR0aDtsZXQgZmlyc3Q9MDt3aGlsZShmaXJzdDx3aWR0aCYmc2FtZShzdGFydCtmaXJzdCkpZmlyc3QrKztcbiAgIGlmKGZpcnN0PT09d2lkdGgpY29udGludWU7XG4gICBsZXQgbGFzdD13aWR0aC0xO3doaWxlKGxhc3Q+Zmlyc3QmJnNhbWUoc3RhcnQrbGFzdCkpbGFzdC0tO1xuICAgbGVmdD1NYXRoLm1pbihsZWZ0LGZpcnN0KTtyaWdodD1NYXRoLm1heChyaWdodCxsYXN0KzEpO3RvcD1NYXRoLm1pbih0b3AseSk7Ym90dG9tPXkrMTtcbiAgfVxuIH1cbiBpZih0b3A9PT1oZWlnaHQpcmV0dXJuIG51bGw7XG4gLy8gQ29weSBvbmUgY29udGlndW91cyBiYW5kLCByYXRoZXIgdGhhbiBhbGxvY2F0aW5nIGEgc3ViYXJyYXkgZm9yIGV2ZXJ5IHJvdy5cbiAvLyBDb21wb25lbnRzIG91dHNpZGUgdGhlIHJlY3RhbmdsZSBhbHJlYWR5IG1hdGNoLCBzbyB0aGlzIHByZXNlcnZlcyB0aGUgc2FtZVxuIC8vIGZ1bGwgcmFzdGVyIHdoaWxlIHRoZSBHUFUgdXBsb2FkIGNhbiBzdGlsbCB1c2UgdGhlIHRpZ2h0ZXIgcGl4ZWwgYm91bmRzLlxuIGNvbnN0IHN0YXJ0PXRvcCp3aWR0aCo0O3ByZXZpb3VzLnNldChuZXh0LnN1YmFycmF5KHN0YXJ0LGJvdHRvbSp3aWR0aCo0KSxzdGFydCk7XG4gcmV0dXJue2xlZnQsdG9wLHJpZ2h0LGJvdHRvbX07XG59XG4iXSwibWFwcGluZ3MiOiJBQU1PLGdCQUFTLGlCQUFpQixVQUFvQixNQUFrQyxPQUFhLFFBQXFDO0FBQ3hJLE1BQUcsUUFBTSxLQUFHLFNBQU8sS0FBRyxDQUFDLE9BQU8sVUFBVSxLQUFLLEtBQUcsQ0FBQyxPQUFPLFVBQVUsTUFBTSxLQUFHLFNBQVMsZUFBYSxRQUFNLFNBQU8sS0FBRyxLQUFLLGVBQWEsU0FBUyxXQUFXLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUN4TSxNQUFJLE9BQUssT0FBTSxNQUFJLFFBQU8sUUFBTSxHQUFFLFNBQU87QUFHekMsTUFBRyxTQUFTLGFBQVcsTUFBSSxLQUFHLEtBQUssYUFBVyxNQUFJLEdBQUU7QUFDbkQsVUFBTSxJQUFFLElBQUksWUFBWSxTQUFTLFFBQU8sU0FBUyxZQUFXLFFBQU0sTUFBTSxHQUFFLElBQUUsSUFBSSxZQUFZLEtBQUssUUFBTyxLQUFLLFlBQVcsUUFBTSxNQUFNO0FBQ3BJLGFBQVEsSUFBRSxHQUFFLElBQUUsUUFBTyxLQUFJO0FBQ3hCLFlBQU1BLFNBQU0sSUFBRTtBQUFNLFVBQUksUUFBTTtBQUM5QixhQUFNLFFBQU0sU0FBTyxFQUFFQSxTQUFNLEtBQUssTUFBSSxFQUFFQSxTQUFNLEtBQUssRUFBRTtBQUNuRCxVQUFHLFVBQVEsTUFBTTtBQUNqQixVQUFJLE9BQUssUUFBTTtBQUFFLGFBQU0sT0FBSyxTQUFPLEVBQUVBLFNBQU0sSUFBSSxNQUFJLEVBQUVBLFNBQU0sSUFBSSxFQUFFO0FBQ2pFLGFBQUssS0FBSyxJQUFJLE1BQUssS0FBSztBQUFFLGNBQU0sS0FBSyxJQUFJLE9BQU0sT0FBSyxDQUFDO0FBQUUsWUFBSSxLQUFLLElBQUksS0FBSSxDQUFDO0FBQUUsZUFBTyxJQUFFO0FBQUEsSUFDckY7QUFBQSxFQUNELE9BQUs7QUFDSixVQUFNLE9BQUssQ0FBQyxVQUFlO0FBQUMsWUFBTSxTQUFPLFFBQU07QUFBRSxhQUFPLFNBQVMsTUFBTSxNQUFJLEtBQUssTUFBTSxLQUFHLFNBQVMsU0FBTyxDQUFDLE1BQUksS0FBSyxTQUFPLENBQUMsS0FBRyxTQUFTLFNBQU8sQ0FBQyxNQUFJLEtBQUssU0FBTyxDQUFDLEtBQUcsU0FBUyxTQUFPLENBQUMsTUFBSSxLQUFLLFNBQU8sQ0FBQztBQUFBLElBQUU7QUFDdk0sYUFBUSxJQUFFLEdBQUUsSUFBRSxRQUFPLEtBQUk7QUFDeEIsWUFBTUEsU0FBTSxJQUFFO0FBQU0sVUFBSSxRQUFNO0FBQUUsYUFBTSxRQUFNLFNBQU8sS0FBS0EsU0FBTSxLQUFLLEVBQUU7QUFDckUsVUFBRyxVQUFRLE1BQU07QUFDakIsVUFBSSxPQUFLLFFBQU07QUFBRSxhQUFNLE9BQUssU0FBTyxLQUFLQSxTQUFNLElBQUksRUFBRTtBQUNwRCxhQUFLLEtBQUssSUFBSSxNQUFLLEtBQUs7QUFBRSxjQUFNLEtBQUssSUFBSSxPQUFNLE9BQUssQ0FBQztBQUFFLFlBQUksS0FBSyxJQUFJLEtBQUksQ0FBQztBQUFFLGVBQU8sSUFBRTtBQUFBLElBQ3JGO0FBQUEsRUFDRDtBQUNBLE1BQUcsUUFBTSxPQUFPLFFBQU87QUFJdkIsUUFBTSxRQUFNLE1BQUksUUFBTTtBQUFFLFdBQVMsSUFBSSxLQUFLLFNBQVMsT0FBTSxTQUFPLFFBQU0sQ0FBQyxHQUFFLEtBQUs7QUFDOUUsU0FBTSxFQUFDLE1BQUssS0FBSSxPQUFNLE9BQU07QUFDN0I7IiwibmFtZXMiOlsic3RhcnQiXX0=