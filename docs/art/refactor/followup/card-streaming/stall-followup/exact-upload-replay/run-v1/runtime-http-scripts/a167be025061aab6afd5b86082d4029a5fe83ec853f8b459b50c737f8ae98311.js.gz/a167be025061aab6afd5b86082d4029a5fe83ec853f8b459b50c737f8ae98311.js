import { shipProfile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { ensure, suspend } from "/@fs/tmp/sketch-queue-source-42bd/src/story/kernel.ts";
import { later, seconds, ticks } from "/@fs/tmp/sketch-queue-source-42bd/src/story/time.ts";
export function textIn(text, locale) {
  if (typeof text === "string") return text;
  return locale === "en" ? text.en ?? text.zh : text.zh;
}
export function readingTime(text) {
  const words = typeof text === "string" ? text : text.zh;
  const chars = [...words].length;
  return seconds(Math.min(8, Math.max(2.2, 1.5 + chars * 0.17)));
}
const CHOICE_LINGER = seconds(1.2);
const OBJECTIVE_LINGER = seconds(5);
const NOTICE_SPAN = seconds(4);
export class Stage {
  constructor(game, clock) {
    this.game = game;
    this.clock = clock;
  }
  seq = 1;
  unitActions = /* @__PURE__ */ new Map();
  speaking = /* @__PURE__ */ new Map();
  queues = /* @__PURE__ */ new Map();
  cards = /* @__PURE__ */ new Map();
  narration;
  titleCard;
  objectives = [];
  choice;
  letterbox = { on: false, since: 0 };
  fade = { from: 0, to: 0, start: 0, end: 0 };
  markers = /* @__PURE__ */ new Map();
  props = /* @__PURE__ */ new Map();
  chapter;
  holds = [];
  floaters = [];
  notices = [];
  camera = { mode: "auto" };
  shake;
  focusId;
  partyView;
  levels;
  /** Call at a real release/hit, after any windup. At most one recent cue per
   * living unit is retained; the next second removes even inactive casters. */
  unitAction(unit, mode, target) {
    const unitId = idOf(unit);
    const source = typeof unit === "string" ? this.game.units.find((actor) => actor.id === unitId) : unit;
    const victim = target?.id ? this.game.units.find((actor) => actor.id === target.id) : void 0;
    const height = (actor) => {
      const hull = actor.deck && this.game.units.find((unit2) => unit2.id === actor.deck.shipId);
      return hull ? (shipProfile(hull)?.deckHeight ?? 0) + 18 : shipProfile(actor)?.deckHeight ?? 0;
    };
    if (this.alive(unitId)) this.unitActions.set(unitId, { unitId, mode, tick: this.clock(), ...source && target ? { fromX: source.x, fromY: source.y, toX: target.x, toY: target.y, ...victim ? { fromHeight: height(source), toHeight: height(victim) } : {} } : {} });
  }
  // ---- Who speaks.
  // Gives a unit its name (on its bubbles and its nameplate).
  cast(unit, card) {
    this.cards.set(idOf(unit), card);
  }
  card(unit) {
    return this.cards.get(idOf(unit));
  }
  // ---- Speech.
  // The unit says the line; returns when it has been read (at once if the unit is gone).
  *say(speaker, text, options = {}) {
    const speakerId = idOf(speaker);
    if (!this.alive(speakerId)) return;
    yield* suspend((wake) => {
      const pending = { line: this.lineFor(speakerId, text, options.tone ?? "say"), span: options.span ?? readingTime(text), done: () => wake.resume(void 0) };
      this.queueOf(speakerId).push(pending);
      this.startNext(speakerId);
      return () => this.withdraw(speakerId, pending);
    });
  }
  // A line said in passing: queued like any other, but nobody waits for it.
  bark(speaker, text, options = {}) {
    const speakerId = idOf(speaker);
    if (!this.alive(speakerId)) return;
    this.queueOf(speakerId).push({ line: this.lineFor(speakerId, text, options.tone ?? "say"), span: options.span ?? readingTime(text), done: () => void 0 });
    this.startNext(speakerId);
  }
  // Words from no one on the field, across the bottom of the screen.
  *narrate(text, span = readingTime(text)) {
    const start = this.clock();
    const card = { text, start, end: later(start, span) };
    this.narration = card;
    try {
      yield* this.hold(span);
    } finally {
      if (this.narration === card) delete this.narration;
    }
  }
  // A chapter's title across the middle of the screen.
  *title(text, subtitle, span = seconds(4.5)) {
    const start = this.clock();
    const card = { text, ...subtitle !== void 0 ? { subtitle } : {}, start, end: later(start, span) };
    this.titleCard = card;
    try {
      yield* this.hold(span);
    } finally {
      if (this.titleCard === card) delete this.titleCard;
    }
  }
  // ---- Objectives.
  // `key` names an objective that a later chapter settles (see settle).
  objective(text, options = {}) {
    const view = { id: this.seq++, ...options.key !== void 0 ? { key: options.key } : {}, text, state: "active", optional: options.optional ?? false, since: this.clock() };
    this.objectives.push(view);
    this.notice(options.optional ? { zh: `支线：${plain(text)}`, en: `Side quest: ${plainEn(text)}` } : { zh: `新目标：${plain(text)}`, en: `New objective: ${plainEn(text)}` }, "quest");
    const settle = (state) => {
      if (view.state !== "active") return;
      view.state = state;
      view.since = this.clock();
      this.notice(state === "done" ? { zh: `完成：${plain(view.text)}`, en: `Done: ${plainEn(view.text)}` } : { zh: `失败：${plain(view.text)}`, en: `Failed: ${plainEn(view.text)}` }, state === "done" ? "gain" : "warn");
    };
    return {
      id: view.id,
      done: () => settle("done"),
      fail: () => settle("failed"),
      progress: (text2) => {
        if (text2 === void 0) delete view.progress;
        else view.progress = text2;
      },
      rename: (text2) => {
        view.text = text2;
      },
      get state() {
        return view.state;
      }
    };
  }
  // Settles an objective set earlier under a key (by a chapter that has no handle to it).
  settle(key, state) {
    const view = this.objectives.find((objective) => objective.key === key && objective.state === "active");
    if (!view) return;
    view.state = state;
    view.since = this.clock();
    this.notice(state === "done" ? { zh: `完成：${plain(view.text)}`, en: `Done: ${plainEn(view.text)}` } : { zh: `失败：${plain(view.text)}`, en: `Failed: ${plainEn(view.text)}` }, state === "done" ? "gain" : "warn");
  }
  // An objective that lasts as long as the current task: failed if the task ends before it is done.
  *goal(text, options = {}) {
    const handle = this.objective(text, options);
    yield* ensure(() => {
      if (handle.state === "active") handle.fail();
    });
    return handle;
  }
  // ---- Choices.
  // Puts a choice to the player and waits for the answer (the option's id).
  *choose(prompt, options, extra = {}) {
    if (this.choice) throw new Error("Only one choice can be open at a time");
    const id = extra.id ?? `choice-${this.seq++}`;
    const opened = this.clock();
    const answer = yield* suspend((wake) => {
      this.choice = { id, prompt, options: options.map((option) => ({ id: option.id, text: option.text })), opened, ...extra.speaker !== void 0 ? { speakerId: idOf(extra.speaker) } : {}, wake: (option) => wake.resume(option) };
      return () => {
        if (this.choice?.id === id) delete this.choice;
      };
    });
    return answer;
  }
  // The player's answer to the open choice (an input: see director). The choice stays up a moment with the answer lit.
  answer(choiceId, option) {
    const choice = this.choice;
    if (!choice || choice.id !== choiceId) throw new Error(`No open choice ${choiceId}`);
    if (!choice.options.some((candidate) => candidate.id === option)) throw new Error(`Choice ${choiceId} has no option ${option}`);
    if (choice.picked) throw new Error(`Choice ${choiceId} was already answered`);
    choice.picked = option;
    choice.pickedAt = this.clock();
  }
  get openChoice() {
    return this.choice ? stripWake(this.choice) : void 0;
  }
  // ---- The ground, the air and the corner of the screen.
  mark(kind, at, options = {}) {
    const start = this.clock();
    const view = {
      id: this.seq++,
      kind,
      x: at.x,
      y: at.y,
      ..."order" in at ? { unitId: at.id } : {},
      radius: options.radius ?? 60,
      ...options.label !== void 0 ? { label: options.label } : {},
      start,
      ...options.span !== void 0 ? { end: later(start, options.span) } : {}
    };
    this.markers.set(view.id, view);
    return { id: view.id, remove: () => void this.markers.delete(view.id), move: (to) => Object.assign(view, { x: to.x, y: to.y }) };
  }
  // A marker for as long as the current task runs.
  *marker(kind, at, options = {}) {
    const handle = this.mark(kind, at, options);
    yield* ensure(handle.remove);
    return handle;
  }
  // Sets a piece of scenery on the map; it stays until removed.
  prop(kind, at, options = {}) {
    const view = { id: this.seq++, kind, x: at.x, y: at.y, scale: options.scale ?? 1, flip: options.flip ?? false, ...options.state !== void 0 ? { state: options.state } : {}, since: this.clock() };
    this.props.set(view.id, view);
    const props = this.props;
    const clock = this.clock;
    return {
      id: view.id,
      remove: () => void props.delete(view.id),
      move: (to) => {
        view.x = to.x;
        view.y = to.y;
      },
      set state(state) {
        if (state === view.state) return;
        if (state === void 0) delete view.state;
        else view.state = state;
        view.since = clock();
      },
      get state() {
        return view.state;
      }
    };
  }
  // Takes every prop of these kinds off the map (a chapter clearing the previous one's scenery).
  clearProps(kinds) {
    for (const [id, prop] of this.props) if (!kinds || kinds.includes(prop.kind)) this.props.delete(id);
  }
  float(text, at, options = {}) {
    const start = this.clock();
    this.floaters.push({ id: this.seq++, text, color: options.color ?? "#6b4a1f", x: at.x, y: at.y, ..."order" in at ? { unitId: at.id } : {}, start, end: later(start, options.span ?? seconds(1.8)), size: options.size ?? 16 });
  }
  notice(text, tone = "info") {
    const start = this.clock();
    this.notices.push({ id: this.seq++, text, tone, start, end: later(start, NOTICE_SPAN) });
  }
  // ---- Framing.
  look(camera) {
    this.camera = camera;
  }
  // Looks as asked for as long as the current task runs, then as before.
  *framing(camera) {
    const before = this.camera;
    this.camera = camera;
    yield* ensure(() => {
      if (this.camera === camera) this.camera = before;
    });
  }
  quake(amount, span) {
    const start = this.clock();
    this.shake = { amount, start, end: later(start, span) };
  }
  setLetterbox(on) {
    if (this.letterbox.on === on) return;
    this.letterbox = { on, since: this.clock() };
    if (!on) delete this.focusId;
  }
  // Letterbox for as long as the current task runs.
  *cinematic() {
    this.setLetterbox(true);
    yield* ensure(() => this.setLetterbox(false));
  }
  *fadeTo(alpha, span) {
    const start = this.clock();
    this.fade = { from: this.fadeAlpha(start), to: alpha, start, end: later(start, span) };
    if (span > 0) yield* this.hold(span);
  }
  get cinematicOn() {
    return this.letterbox.on;
  }
  // ---- The Director's side.
  // Nobody is speaking or waiting to, no choice is open and nothing holds the story: a checkpoint can be taken.
  get quiet() {
    return this.speaking.size === 0 && this.queues.size === 0 && !this.choice && this.holds.length === 0;
  }
  memory() {
    return { unitActions: [...this.unitActions.values()].map((cue) => ({ ...cue })), cards: [...this.cards], props: [...this.props.values()].map((prop) => ({ ...prop })), ...this.chapter !== void 0 ? { chapter: this.chapter } : {}, letterbox: { ...this.letterbox }, fade: { ...this.fade }, camera: this.camera };
  }
  restore(memory) {
    this.unitActions.clear();
    for (const cue of memory.unitActions ?? []) this.unitActions.set(cue.unitId, { ...cue });
    this.cards.clear();
    for (const [unitId, card] of memory.cards) this.cards.set(unitId, card);
    this.props.clear();
    for (const prop of memory.props) this.props.set(prop.id, { ...prop });
    this.seq = Math.max(this.seq, ...memory.props.map((prop) => prop.id + 1));
    if (memory.chapter !== void 0) this.chapter = memory.chapter;
    this.letterbox = { ...memory.letterbox };
    this.fade = { ...memory.fade };
    this.camera = memory.camera;
  }
  // Once a tick: lines end and the next begin, the answered choice closes, the old words fade from the lists.
  tick() {
    const now = this.clock();
    for (const [unitId, cue] of this.unitActions) if (now - cue.tick > seconds(1) || !this.alive(unitId)) this.unitActions.delete(unitId);
    for (const [speakerId, active] of [...this.speaking]) {
      if (active.view.end > now && this.alive(speakerId)) continue;
      this.speaking.delete(speakerId);
      active.done();
      this.startNext(speakerId);
    }
    for (const speakerId of [...this.queues.keys()]) this.startNext(speakerId);
    if (this.choice?.pickedAt !== void 0 && now - this.choice.pickedAt >= CHOICE_LINGER) {
      const { wake, picked } = this.choice;
      delete this.choice;
      wake?.(picked);
    }
    for (let index = this.objectives.length - 1; index >= 0; index -= 1) {
      const objective = this.objectives[index];
      if (objective.state !== "active" && now - objective.since >= OBJECTIVE_LINGER) this.objectives.splice(index, 1);
    }
    for (const [id, marker] of this.markers) if (marker.end !== void 0 && marker.end <= now) this.markers.delete(id);
    this.floaters = this.floaters.filter((floater) => floater.end > now);
    this.notices = this.notices.filter((notice) => notice.end > now);
    if (this.shake && this.shake.end <= now) delete this.shake;
  }
  view() {
    const tick = this.clock();
    const nameplates = {};
    for (const [unitId, card] of this.cards) {
      const level = this.levels?.(unitId);
      nameplates[unitId] = { name: card.name, color: card.color, ...level !== void 0 ? { level } : {} };
    }
    const party = this.partyView?.();
    return {
      tick,
      ...this.unitActions.size ? { unitActions: [...this.unitActions.values()].map((cue) => ({ ...cue })) } : {},
      lines: [...this.speaking.values()].map((active) => ({ ...active.view })),
      ...this.narration ? { narration: { ...this.narration } } : {},
      ...this.titleCard ? { title: { ...this.titleCard } } : {},
      objectives: this.objectives.map((objective) => ({ ...objective })),
      ...this.choice ? { choice: stripWake(this.choice) } : {},
      letterbox: { ...this.letterbox },
      fade: { ...this.fade },
      markers: [...this.markers.values()].map((marker) => this.placed(marker)),
      props: [...this.props.values()].map((prop) => ({ ...prop })),
      floaters: this.floaters.map((floater) => this.placed(floater)),
      notices: this.notices.map((notice) => ({ ...notice })),
      nameplates,
      ...party ? { party } : {},
      camera: this.camera,
      ...this.shake ? { shake: { ...this.shake } } : {},
      ...this.focusId ? { focusId: this.focusId } : {},
      ...this.chapter !== void 0 ? { chapter: this.chapter } : {}
    };
  }
  fadeAlpha(at) {
    const { from, to, start, end } = this.fade;
    if (at >= end) return to;
    if (at <= start) return from;
    return from + (to - from) * (at - start) / Math.max(1, end - start);
  }
  // A marker or floater that follows a unit stands where the unit stands (or stood last).
  placed(item) {
    if (!item.unitId) return { ...item };
    const unit = this.game.units.find((candidate) => candidate.id === item.unitId);
    if (unit) {
      item.x = unit.x;
      item.y = unit.y;
    }
    return { ...item };
  }
  *hold(span) {
    const due = later(this.clock(), span);
    yield* suspend((wake) => {
      const line = { done: () => wake.resume(void 0), due };
      this.holds.push(line);
      return () => {
        const index = this.holds.indexOf(line);
        if (index >= 0) this.holds.splice(index, 1);
      };
    });
  }
  // Wakes whatever holds for a span (titles, narration, fades) whose span is over. Called by the Director's tick.
  releaseHolds() {
    const now = this.clock();
    for (const hold of this.holds.filter((candidate) => candidate.due <= now)) hold.done();
  }
  lineFor(speakerId, text, tone) {
    const card = this.cards.get(speakerId);
    return { id: this.seq++, speakerId, name: card?.name ?? "", color: card?.color ?? "#5c4a32", text, tone };
  }
  queueOf(speakerId) {
    let queue = this.queues.get(speakerId);
    if (!queue) {
      queue = [];
      this.queues.set(speakerId, queue);
    }
    return queue;
  }
  startNext(speakerId) {
    if (this.speaking.has(speakerId)) return;
    const queue = this.queues.get(speakerId);
    if (!queue) return;
    if (!this.alive(speakerId)) {
      this.queues.delete(speakerId);
      for (const pending of queue) pending.done();
      return;
    }
    const next = queue.shift();
    if (queue.length === 0) this.queues.delete(speakerId);
    if (!next) return;
    const start = this.clock();
    this.speaking.set(speakerId, { view: { ...next.line, start, end: later(start, ticks(Math.max(1, next.span))) }, done: next.done });
    if (this.letterbox.on) this.focusId = speakerId;
  }
  // The task that said the line was halted: the line goes, whether it was waiting or showing.
  withdraw(speakerId, pending) {
    const queue = this.queues.get(speakerId);
    const index = queue?.indexOf(pending) ?? -1;
    if (queue && index >= 0) {
      queue.splice(index, 1);
      return;
    }
    const active = this.speaking.get(speakerId);
    if (active && active.view.id === pending.line.id) {
      this.speaking.delete(speakerId);
      this.startNext(speakerId);
    }
  }
  alive(unitId) {
    return this.game.units.some((unit) => unit.id === unitId && unit.hp > 0);
  }
}
function idOf(unit) {
  return typeof unit === "string" ? unit : unit.id;
}
function plain(text) {
  return typeof text === "string" ? text : text.zh;
}
function plainEn(text) {
  return typeof text === "string" ? text : text.en ?? text.zh;
}
function stripWake(choice) {
  const { wake: _wake, ...view } = choice;
  return { ...view, options: view.options.map((option) => ({ ...option })) };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YWdlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNoaXBQcm9maWxlIH0gZnJvbSAnLi4vc2hhcmVkL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHR5cGUgeyBHYW1lIH0gZnJvbSBcIi4uL3NoYXJlZC9zaW1cIjtcbmltcG9ydCB0eXBlIHsgVW5pdCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IGVuc3VyZSwgc3VzcGVuZCwgdHlwZSBPcGVyYXRpb24gfSBmcm9tIFwiLi9rZXJuZWxcIjtcbmltcG9ydCB7IGxhdGVyLCBzZWNvbmRzLCB0aWNrcywgdHlwZSBEdXJhdGlvbiwgdHlwZSBJbnN0YW50IH0gZnJvbSBcIi4vdGltZVwiO1xuXG4vLyBAQEBzdG9yeS1zdGFnZSAtIEV2ZXJ5dGhpbmcgdGhlIHN0b3J5IHNob3dzIHRoYXQgaXMgbm90IHRoZSBiYXR0bGUgaXRzZWxmOiBzcGVlY2ggYnViYmxlcyBvdmVyIHRoZSB1bml0cyB3aG8gc3BlYWssXG4vLyBuYXJyYXRpb24sIGNoYXB0ZXIgdGl0bGVzLCB0aGUgb2JqZWN0aXZlcyBsaXN0LCBhIGNob2ljZSBwdXQgdG8gdGhlIHBsYXllciwgbWFya2VycyBvbiB0aGUgZ3JvdW5kLCBmbG9hdGluZyB3b3Jkcyxcbi8vIHRoZSBoZXJvZXMnIHBhbmVsLCBsZXR0ZXJib3ggYW5kIGZhZGVzLCBhbmQgd2hlcmUgdGhlIGNhbWVyYSBzaG91bGQgbG9vay4gVGhlIHN0YWdlIGlzIHBsYWluIGRhdGEgdGhhdCB0aGUgcmVuZGVyZXJcbi8vIGRyYXdzIChzZWUgY2xpZW50L3N0b3J5LXJlbmRlcmVyKSB0aGUgc2FtZSB3YXkgaW4gdGhlIGJyb3dzZXIgYW5kIGluIGEgcmVjb3JkaW5nOyBzY3JpcHRzIGNoYW5nZSBpdCB0aHJvdWdoXG4vLyBvcGVyYXRpb25zIHRoYXQgd2FpdCBhcyBsb25nIGFzIHdoYXQgdGhleSBzaG93IGxhc3RzIChgeWllbGQqIHNheSguLi4pYCByZXR1cm5zIHdoZW4gdGhlIGxpbmUgaGFzIGJlZW4gcmVhZCkuXG4vL1xuLy8gU3BlZWNoIGlzIHF1ZXVlZCBwZXIgc3BlYWtlcjogYSB1bml0IHNheXMgb25lIGxpbmUgYXQgYSB0aW1lIGFuZCB0aGUgbmV4dCB3YWl0cyBpdHMgdHVybiwgc28gdHdvIHNjZW5lcyB0YWxraW5nIG92ZXJcbi8vIGVhY2ggb3RoZXIgbmV2ZXIgc3RhY2sgb25lIHVuaXQncyBidWJibGVzLiBBIGxpbmUgYmVsb25ncyB0byB0aGUgdGFzayB0aGF0IHNhaWQgaXQ6IGhhbHQgdGhlIHNjZW5lIGFuZCBpdHMgYnViYmxlIGdvZXMuXG4vLyBBIHNwZWFrZXIgd2hvIGRpZXMgbWlkLXF1ZXVlIHNheXMgbm90aGluZyBtb3JlLlxuXG5leHBvcnQgdHlwZSBUZXh0ID0gc3RyaW5nIHwgeyB6aDogc3RyaW5nOyBlbj86IHN0cmluZyB9O1xuZXhwb3J0IHR5cGUgVG9uZSA9IFwic2F5XCIgfCBcInNob3V0XCIgfCBcIndoaXNwZXJcIiB8IFwidGhpbmtcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHRleHRJbih0ZXh0OiBUZXh0LCBsb2NhbGU6IFwiemhcIiB8IFwiZW5cIik6IHN0cmluZyB7XG4gIGlmICh0eXBlb2YgdGV4dCA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHRleHQ7XG4gIHJldHVybiBsb2NhbGUgPT09IFwiZW5cIiA/ICh0ZXh0LmVuID8/IHRleHQuemgpIDogdGV4dC56aDtcbn1cblxuZXhwb3J0IHR5cGUgU3BlYWtlckNhcmQgPSB7IG5hbWU6IFRleHQ7IGNvbG9yOiBzdHJpbmc7IHRpdGxlPzogVGV4dCB9O1xuXG5leHBvcnQgdHlwZSBMaW5lVmlldyA9IHsgaWQ6IG51bWJlcjsgc3BlYWtlcklkOiBzdHJpbmc7IG5hbWU6IFRleHQ7IGNvbG9yOiBzdHJpbmc7IHRleHQ6IFRleHQ7IHRvbmU6IFRvbmU7IHN0YXJ0OiBudW1iZXI7IGVuZDogbnVtYmVyIH07XG5leHBvcnQgdHlwZSBUaW1lZFRleHQgPSB7IHRleHQ6IFRleHQ7IHN1YnRpdGxlPzogVGV4dDsgc3RhcnQ6IG51bWJlcjsgZW5kOiBudW1iZXIgfTtcbmV4cG9ydCB0eXBlIE9iamVjdGl2ZVZpZXcgPSB7IGlkOiBudW1iZXI7IGtleT86IHN0cmluZzsgdGV4dDogVGV4dDsgc3RhdGU6IFwiYWN0aXZlXCIgfCBcImRvbmVcIiB8IFwiZmFpbGVkXCI7IG9wdGlvbmFsOiBib29sZWFuOyBwcm9ncmVzcz86IHN0cmluZzsgc2luY2U6IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgQ2hvaWNlVmlldyA9IHsgaWQ6IHN0cmluZzsgcHJvbXB0OiBUZXh0OyBzcGVha2VySWQ/OiBzdHJpbmc7IG9wdGlvbnM6IHsgaWQ6IHN0cmluZzsgdGV4dDogVGV4dCB9W107IG9wZW5lZDogbnVtYmVyOyBwaWNrZWQ/OiBzdHJpbmc7IHBpY2tlZEF0PzogbnVtYmVyIH07XG4vLyBxdWVzdDogZ28gaGVyZTsgcmFsbHk6IGhvbGQgaGVyZTsgdGFyZ2V0OiBzdHJpa2UgdGhpczsgZGFuZ2VyOiBhIGJsb3cgaXMgYWJvdXQgdG8gZmFsbCBoZXJlOyByZWxpYzogc29tZXRoaW5nIHRvIHRha2U7XG4vLyBzbmFyZTogYSB1bml0IGhlbGQgZmFzdDsgcGxhY2U6IGEgbmFtZSBvbiB0aGUgbWFwLCBhc2tpbmcgbm90aGluZy5cbmV4cG9ydCB0eXBlIE1hcmtlcktpbmQgPSBcInF1ZXN0XCIgfCBcImRhbmdlclwiIHwgXCJyZWxpY1wiIHwgXCJyYWxseVwiIHwgXCJ0YXJnZXRcIiB8IFwic25hcmVcIiB8IFwicGxhY2VcIjtcbmV4cG9ydCB0eXBlIE1hcmtlclZpZXcgPSB7IGlkOiBudW1iZXI7IGtpbmQ6IE1hcmtlcktpbmQ7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB1bml0SWQ/OiBzdHJpbmc7IHJhZGl1czogbnVtYmVyOyBsYWJlbD86IFRleHQ7IHN0YXJ0OiBudW1iZXI7IGVuZD86IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgRmxvYXRlclZpZXcgPSB7IGlkOiBudW1iZXI7IHRleHQ6IFRleHQ7IGNvbG9yOiBzdHJpbmc7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB1bml0SWQ/OiBzdHJpbmc7IHN0YXJ0OiBudW1iZXI7IGVuZDogbnVtYmVyOyBzaXplOiBudW1iZXIgfTtcbi8vIFNjZW5lcnkgYSBzdG9yeSBzZXRzIG9uIHRoZSBtYXAgKGEgaHV0LCBhIGJvYXQsIGEgY2FtcGZpcmUpLCBkcmF3biBieSB0aGUgY2FtcGFpZ24ncyBvd24gcGFpbnRlcnM7IGBzdGF0ZWAgbGV0cyBhXG4vLyBwYWludGVyIHNob3cgaXQgb3RoZXJ3aXNlIChcImJ1cm5pbmdcIiwgXCJydWluZWRcIiksIGFuZCBgc2luY2VgIGlzIHdoZW4gdGhhdCBzdGF0ZSBiZWdhbi5cbmV4cG9ydCB0eXBlIFByb3BWaWV3ID0geyBpZDogbnVtYmVyOyBraW5kOiBzdHJpbmc7IHg6IG51bWJlcjsgeTogbnVtYmVyOyBzY2FsZTogbnVtYmVyOyBmbGlwOiBib29sZWFuOyBzdGF0ZT86IHN0cmluZzsgc2luY2U6IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgTm90aWNlVmlldyA9IHsgaWQ6IG51bWJlcjsgdGV4dDogVGV4dDsgdG9uZTogXCJnYWluXCIgfCBcInF1ZXN0XCIgfCBcIndhcm5cIiB8IFwiaW5mb1wiOyBzdGFydDogbnVtYmVyOyBlbmQ6IG51bWJlciB9O1xuZXhwb3J0IHR5cGUgQ2FtZXJhVmlldyA9XG4gIHwgeyBtb2RlOiBcImF1dG9cIjsgem9vbT86IG51bWJlciB9XG4gIHwgeyBtb2RlOiBcImZvbGxvd1wiOyB1bml0SWRzOiBzdHJpbmdbXTsgem9vbT86IG51bWJlciB9XG4gIHwgeyBtb2RlOiBcInBvaW50XCI7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB6b29tPzogbnVtYmVyIH07XG5leHBvcnQgdHlwZSBQYXJ0eU1lbWJlciA9IHtcbiAgdW5pdElkOiBzdHJpbmc7XG4gIG5hbWU6IFRleHQ7XG4gIGNvbG9yOiBzdHJpbmc7XG4gIGxldmVsOiBudW1iZXI7XG4gIHhwOiBudW1iZXI7XG4gIHhwRmxvb3I6IG51bWJlcjtcbiAgeHBOZXh0PzogbnVtYmVyO1xuICBocDogbnVtYmVyO1xuICBtYXhIcDogbnVtYmVyO1xuICBza2lsbHM6IHsgbmFtZTogVGV4dDsgcmVhZHk6IG51bWJlciB9W107XG4gIGdlYXI6IFRleHRbXTtcbn07XG5leHBvcnQgdHlwZSBQYXJ0eVZpZXcgPSB7IG1lbWJlcnM6IFBhcnR5TWVtYmVyW107IGdvbGQ/OiBudW1iZXIgfTtcblxuLyoqIEV4cGxpY2l0IHByZXNlbnRhdGlvbiByZWxlYXNlLCBhdXRob3JlZCB3aGVyZSBhIFBvd2VyJ3MgZWZmZWN0IGhhcHBlbnMuXG4gKiBJdCBuZXZlciBhbHRlcnMgY29vbGRvd25zLCBvcmRlcnMsIGRhbWFnZSBvciB0aGUgZ2FtZSBjaGVja3N1bS4gKi9cbmV4cG9ydCB0eXBlIFVuaXRBY3Rpb25DdWUgPSB7IHVuaXRJZDogc3RyaW5nOyBtb2RlOiBcImF0dGFja1wiIHwgXCJjYXN0XCI7IHRpY2s6IG51bWJlcjsgZnJvbVg/OiBudW1iZXI7IGZyb21ZPzogbnVtYmVyOyB0b1g/OiBudW1iZXI7IHRvWT86IG51bWJlcjsgZnJvbUhlaWdodD86IG51bWJlcjsgdG9IZWlnaHQ/OiBudW1iZXIgfTtcblxuZXhwb3J0IHR5cGUgU3RhZ2VWaWV3ID0ge1xuICB1bml0QWN0aW9ucz86IHJlYWRvbmx5IFVuaXRBY3Rpb25DdWVbXTtcbiAgdGljazogbnVtYmVyO1xuICBsaW5lczogTGluZVZpZXdbXTtcbiAgbmFycmF0aW9uPzogVGltZWRUZXh0O1xuICB0aXRsZT86IFRpbWVkVGV4dDtcbiAgb2JqZWN0aXZlczogT2JqZWN0aXZlVmlld1tdO1xuICBjaG9pY2U/OiBDaG9pY2VWaWV3O1xuICBsZXR0ZXJib3g6IHsgb246IGJvb2xlYW47IHNpbmNlOiBudW1iZXIgfTtcbiAgZmFkZTogeyBmcm9tOiBudW1iZXI7IHRvOiBudW1iZXI7IHN0YXJ0OiBudW1iZXI7IGVuZDogbnVtYmVyIH07XG4gIG1hcmtlcnM6IE1hcmtlclZpZXdbXTtcbiAgcHJvcHM6IFByb3BWaWV3W107XG4gIGZsb2F0ZXJzOiBGbG9hdGVyVmlld1tdO1xuICBub3RpY2VzOiBOb3RpY2VWaWV3W107XG4gIG5hbWVwbGF0ZXM6IFJlY29yZDxzdHJpbmcsIHsgbmFtZTogVGV4dDsgY29sb3I6IHN0cmluZzsgbGV2ZWw/OiBudW1iZXIgfT47XG4gIHBhcnR5PzogUGFydHlWaWV3O1xuICBjYW1lcmE6IENhbWVyYVZpZXc7XG4gIHNoYWtlPzogeyBhbW91bnQ6IG51bWJlcjsgc3RhcnQ6IG51bWJlcjsgZW5kOiBudW1iZXIgfTtcbiAgY2hhcHRlcj86IHN0cmluZztcbiAgLy8gVGhlIHVuaXQgd2hvc2UgbGluZSB0aGUgY2FtZXJhIHNob3VsZCBmYXZvdXIgKHRoZSBsYXN0IHRvIHNwZWFrIHdoaWxlIHRoZSBsZXR0ZXJib3ggaXMgZG93bikuXG4gIGZvY3VzSWQ/OiBzdHJpbmc7XG59O1xuXG4vLyBXaGF0IG9mIHRoZSBzdGFnZSBvdXRsaXZlcyBhIGNoYXB0ZXIgYW5kIGlzIGtlcHQgd2l0aCBhIGNoZWNrcG9pbnQ6IHdobyBpcyB3aG8sIGFuZCBob3cgdGhlIHNjcmVlbiBpcyBmcmFtZWQuXG5leHBvcnQgdHlwZSBTdGFnZU1lbW9yeSA9IHtcbiAgdW5pdEFjdGlvbnM/OiBVbml0QWN0aW9uQ3VlW107XG4gIGNhcmRzOiBbc3RyaW5nLCBTcGVha2VyQ2FyZF1bXTtcbiAgcHJvcHM6IFByb3BWaWV3W107XG4gIGNoYXB0ZXI/OiBzdHJpbmc7XG4gIGxldHRlcmJveDogeyBvbjogYm9vbGVhbjsgc2luY2U6IG51bWJlciB9O1xuICBmYWRlOiB7IGZyb206IG51bWJlcjsgdG86IG51bWJlcjsgc3RhcnQ6IG51bWJlcjsgZW5kOiBudW1iZXIgfTtcbiAgY2FtZXJhOiBDYW1lcmFWaWV3O1xufTtcblxudHlwZSBQZW5kaW5nID0geyBsaW5lOiBPbWl0PExpbmVWaWV3LCBcInN0YXJ0XCIgfCBcImVuZFwiPjsgc3BhbjogRHVyYXRpb247IGRvbmU6ICgpID0+IHZvaWQgfTtcbnR5cGUgQWN0aXZlID0geyB2aWV3OiBMaW5lVmlldzsgZG9uZTogKCkgPT4gdm9pZCB9O1xuXG4vLyBIb3cgbG9uZyBhIGxpbmUgc3RheXMgdXA6IGxvbmcgZW5vdWdoIHRvIHJlYWQgYXQgYW4gdW5odXJyaWVkIHBhY2UuXG5leHBvcnQgZnVuY3Rpb24gcmVhZGluZ1RpbWUodGV4dDogVGV4dCk6IER1cmF0aW9uIHtcbiAgY29uc3Qgd29yZHMgPSB0eXBlb2YgdGV4dCA9PT0gXCJzdHJpbmdcIiA/IHRleHQgOiB0ZXh0LnpoO1xuICBjb25zdCBjaGFycyA9IFsuLi53b3Jkc10ubGVuZ3RoO1xuICByZXR1cm4gc2Vjb25kcyhNYXRoLm1pbig4LCBNYXRoLm1heCgyLjIsIDEuNSArIGNoYXJzICogMC4xNykpKTtcbn1cblxuY29uc3QgQ0hPSUNFX0xJTkdFUiA9IHNlY29uZHMoMS4yKTtcbmNvbnN0IE9CSkVDVElWRV9MSU5HRVIgPSBzZWNvbmRzKDUpO1xuY29uc3QgTk9USUNFX1NQQU4gPSBzZWNvbmRzKDQpO1xuXG5leHBvcnQgY2xhc3MgU3RhZ2Uge1xuICBwcml2YXRlIHNlcSA9IDE7XG4gIHByaXZhdGUgcmVhZG9ubHkgdW5pdEFjdGlvbnMgPSBuZXcgTWFwPHN0cmluZywgVW5pdEFjdGlvbkN1ZT4oKTtcbiAgcHJpdmF0ZSByZWFkb25seSBzcGVha2luZyA9IG5ldyBNYXA8c3RyaW5nLCBBY3RpdmU+KCk7XG4gIHByaXZhdGUgcmVhZG9ubHkgcXVldWVzID0gbmV3IE1hcDxzdHJpbmcsIFBlbmRpbmdbXT4oKTtcbiAgcHJpdmF0ZSByZWFkb25seSBjYXJkcyA9IG5ldyBNYXA8c3RyaW5nLCBTcGVha2VyQ2FyZD4oKTtcbiAgcHJpdmF0ZSBuYXJyYXRpb24/OiBUaW1lZFRleHQ7XG4gIHByaXZhdGUgdGl0bGVDYXJkPzogVGltZWRUZXh0O1xuICBwcml2YXRlIHJlYWRvbmx5IG9iamVjdGl2ZXM6IE9iamVjdGl2ZVZpZXdbXSA9IFtdO1xuICBwcml2YXRlIGNob2ljZT86IENob2ljZVZpZXcgJiB7IHdha2U/OiAob3B0aW9uOiBzdHJpbmcpID0+IHZvaWQgfTtcbiAgcHJpdmF0ZSBsZXR0ZXJib3ggPSB7IG9uOiBmYWxzZSwgc2luY2U6IDAgfTtcbiAgcHJpdmF0ZSBmYWRlID0geyBmcm9tOiAwLCB0bzogMCwgc3RhcnQ6IDAsIGVuZDogMCB9O1xuICBwcml2YXRlIHJlYWRvbmx5IG1hcmtlcnMgPSBuZXcgTWFwPG51bWJlciwgTWFya2VyVmlldz4oKTtcbiAgcHJpdmF0ZSByZWFkb25seSBwcm9wcyA9IG5ldyBNYXA8bnVtYmVyLCBQcm9wVmlldz4oKTtcbiAgY2hhcHRlcj86IHN0cmluZztcbiAgcHJpdmF0ZSByZWFkb25seSBob2xkczogeyBkb25lOiAoKSA9PiB2b2lkOyBkdWU6IEluc3RhbnQgfVtdID0gW107XG4gIHByaXZhdGUgZmxvYXRlcnM6IEZsb2F0ZXJWaWV3W10gPSBbXTtcbiAgcHJpdmF0ZSBub3RpY2VzOiBOb3RpY2VWaWV3W10gPSBbXTtcbiAgcHJpdmF0ZSBjYW1lcmE6IENhbWVyYVZpZXcgPSB7IG1vZGU6IFwiYXV0b1wiIH07XG4gIHByaXZhdGUgc2hha2U/OiB7IGFtb3VudDogbnVtYmVyOyBzdGFydDogbnVtYmVyOyBlbmQ6IG51bWJlciB9O1xuICBwcml2YXRlIGZvY3VzSWQ/OiBzdHJpbmc7XG4gIHBhcnR5Vmlldz86ICgpID0+IFBhcnR5VmlldyB8IHVuZGVmaW5lZDtcbiAgbGV2ZWxzPzogKHVuaXRJZDogc3RyaW5nKSA9PiBudW1iZXIgfCB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBnYW1lOiBHYW1lLCBwcml2YXRlIHJlYWRvbmx5IGNsb2NrOiAoKSA9PiBJbnN0YW50KSB7fVxuXG4gIC8qKiBDYWxsIGF0IGEgcmVhbCByZWxlYXNlL2hpdCwgYWZ0ZXIgYW55IHdpbmR1cC4gQXQgbW9zdCBvbmUgcmVjZW50IGN1ZSBwZXJcbiAgICogbGl2aW5nIHVuaXQgaXMgcmV0YWluZWQ7IHRoZSBuZXh0IHNlY29uZCByZW1vdmVzIGV2ZW4gaW5hY3RpdmUgY2FzdGVycy4gKi9cbiAgdW5pdEFjdGlvbih1bml0OiBVbml0IHwgc3RyaW5nLCBtb2RlOiBVbml0QWN0aW9uQ3VlWydtb2RlJ10sIHRhcmdldD86IHt4Om51bWJlcjt5Om51bWJlcjtpZD86c3RyaW5nfSkge1xuICAgIGNvbnN0IHVuaXRJZCA9IGlkT2YodW5pdCk7XG4gICAgY29uc3Qgc291cmNlPXR5cGVvZiB1bml0ID09PSBcInN0cmluZ1wiID8gdGhpcy5nYW1lLnVuaXRzLmZpbmQoYWN0b3I9PmFjdG9yLmlkPT09dW5pdElkKSA6IHVuaXQ7XG4gICAgY29uc3QgdmljdGltPXRhcmdldD8uaWQ/dGhpcy5nYW1lLnVuaXRzLmZpbmQoYWN0b3I9PmFjdG9yLmlkPT09dGFyZ2V0LmlkKTp1bmRlZmluZWQ7XG4gICAgY29uc3QgaGVpZ2h0PShhY3RvcjpVbml0KT0+e2NvbnN0IGh1bGw9YWN0b3IuZGVjayYmdGhpcy5nYW1lLnVuaXRzLmZpbmQodW5pdD0+dW5pdC5pZD09PWFjdG9yLmRlY2shLnNoaXBJZCk7cmV0dXJuIGh1bGw/KHNoaXBQcm9maWxlKGh1bGwpPy5kZWNrSGVpZ2h0Pz8wKSsxODpzaGlwUHJvZmlsZShhY3Rvcik/LmRlY2tIZWlnaHQ/PzA7fTtcbiAgICBpZiAodGhpcy5hbGl2ZSh1bml0SWQpKSB0aGlzLnVuaXRBY3Rpb25zLnNldCh1bml0SWQsIHsgdW5pdElkLCBtb2RlLCB0aWNrOiB0aGlzLmNsb2NrKCksIC4uLihzb3VyY2UmJnRhcmdldD97ZnJvbVg6c291cmNlLngsZnJvbVk6c291cmNlLnksdG9YOnRhcmdldC54LHRvWTp0YXJnZXQueSwuLi4odmljdGltP3tmcm9tSGVpZ2h0OmhlaWdodChzb3VyY2UpLHRvSGVpZ2h0OmhlaWdodCh2aWN0aW0pfTp7fSl9Ont9KSB9KTtcbiAgfVxuXG4gIC8vIC0tLS0gV2hvIHNwZWFrcy5cblxuICAvLyBHaXZlcyBhIHVuaXQgaXRzIG5hbWUgKG9uIGl0cyBidWJibGVzIGFuZCBpdHMgbmFtZXBsYXRlKS5cbiAgY2FzdCh1bml0OiBVbml0IHwgc3RyaW5nLCBjYXJkOiBTcGVha2VyQ2FyZCkge1xuICAgIHRoaXMuY2FyZHMuc2V0KGlkT2YodW5pdCksIGNhcmQpO1xuICB9XG5cbiAgY2FyZCh1bml0OiBVbml0IHwgc3RyaW5nKTogU3BlYWtlckNhcmQgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLmNhcmRzLmdldChpZE9mKHVuaXQpKTtcbiAgfVxuXG4gIC8vIC0tLS0gU3BlZWNoLlxuXG4gIC8vIFRoZSB1bml0IHNheXMgdGhlIGxpbmU7IHJldHVybnMgd2hlbiBpdCBoYXMgYmVlbiByZWFkIChhdCBvbmNlIGlmIHRoZSB1bml0IGlzIGdvbmUpLlxuICAqc2F5KHNwZWFrZXI6IFVuaXQgfCBzdHJpbmcsIHRleHQ6IFRleHQsIG9wdGlvbnM6IHsgdG9uZT86IFRvbmU7IHNwYW4/OiBEdXJhdGlvbiB9ID0ge30pOiBPcGVyYXRpb248dm9pZD4ge1xuICAgIGNvbnN0IHNwZWFrZXJJZCA9IGlkT2Yoc3BlYWtlcik7XG4gICAgaWYgKCF0aGlzLmFsaXZlKHNwZWFrZXJJZCkpIHJldHVybjtcbiAgICB5aWVsZCogc3VzcGVuZDx2b2lkPigod2FrZSkgPT4ge1xuICAgICAgY29uc3QgcGVuZGluZzogUGVuZGluZyA9IHsgbGluZTogdGhpcy5saW5lRm9yKHNwZWFrZXJJZCwgdGV4dCwgb3B0aW9ucy50b25lID8/IFwic2F5XCIpLCBzcGFuOiBvcHRpb25zLnNwYW4gPz8gcmVhZGluZ1RpbWUodGV4dCksIGRvbmU6ICgpID0+IHdha2UucmVzdW1lKHVuZGVmaW5lZCkgfTtcbiAgICAgIHRoaXMucXVldWVPZihzcGVha2VySWQpLnB1c2gocGVuZGluZyk7XG4gICAgICB0aGlzLnN0YXJ0TmV4dChzcGVha2VySWQpO1xuICAgICAgcmV0dXJuICgpID0+IHRoaXMud2l0aGRyYXcoc3BlYWtlcklkLCBwZW5kaW5nKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIEEgbGluZSBzYWlkIGluIHBhc3Npbmc6IHF1ZXVlZCBsaWtlIGFueSBvdGhlciwgYnV0IG5vYm9keSB3YWl0cyBmb3IgaXQuXG4gIGJhcmsoc3BlYWtlcjogVW5pdCB8IHN0cmluZywgdGV4dDogVGV4dCwgb3B0aW9uczogeyB0b25lPzogVG9uZTsgc3Bhbj86IER1cmF0aW9uIH0gPSB7fSkge1xuICAgIGNvbnN0IHNwZWFrZXJJZCA9IGlkT2Yoc3BlYWtlcik7XG4gICAgaWYgKCF0aGlzLmFsaXZlKHNwZWFrZXJJZCkpIHJldHVybjtcbiAgICB0aGlzLnF1ZXVlT2Yoc3BlYWtlcklkKS5wdXNoKHsgbGluZTogdGhpcy5saW5lRm9yKHNwZWFrZXJJZCwgdGV4dCwgb3B0aW9ucy50b25lID8/IFwic2F5XCIpLCBzcGFuOiBvcHRpb25zLnNwYW4gPz8gcmVhZGluZ1RpbWUodGV4dCksIGRvbmU6ICgpID0+IHVuZGVmaW5lZCB9KTtcbiAgICB0aGlzLnN0YXJ0TmV4dChzcGVha2VySWQpO1xuICB9XG5cbiAgLy8gV29yZHMgZnJvbSBubyBvbmUgb24gdGhlIGZpZWxkLCBhY3Jvc3MgdGhlIGJvdHRvbSBvZiB0aGUgc2NyZWVuLlxuICAqbmFycmF0ZSh0ZXh0OiBUZXh0LCBzcGFuOiBEdXJhdGlvbiA9IHJlYWRpbmdUaW1lKHRleHQpKTogT3BlcmF0aW9uPHZvaWQ+IHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuY2xvY2soKTtcbiAgICBjb25zdCBjYXJkOiBUaW1lZFRleHQgPSB7IHRleHQsIHN0YXJ0LCBlbmQ6IGxhdGVyKHN0YXJ0LCBzcGFuKSB9O1xuICAgIHRoaXMubmFycmF0aW9uID0gY2FyZDtcbiAgICB0cnkge1xuICAgICAgeWllbGQqIHRoaXMuaG9sZChzcGFuKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKHRoaXMubmFycmF0aW9uID09PSBjYXJkKSBkZWxldGUgdGhpcy5uYXJyYXRpb247XG4gICAgfVxuICB9XG5cbiAgLy8gQSBjaGFwdGVyJ3MgdGl0bGUgYWNyb3NzIHRoZSBtaWRkbGUgb2YgdGhlIHNjcmVlbi5cbiAgKnRpdGxlKHRleHQ6IFRleHQsIHN1YnRpdGxlPzogVGV4dCwgc3BhbjogRHVyYXRpb24gPSBzZWNvbmRzKDQuNSkpOiBPcGVyYXRpb248dm9pZD4ge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5jbG9jaygpO1xuICAgIGNvbnN0IGNhcmQ6IFRpbWVkVGV4dCA9IHsgdGV4dCwgLi4uKHN1YnRpdGxlICE9PSB1bmRlZmluZWQgPyB7IHN1YnRpdGxlIH0gOiB7fSksIHN0YXJ0LCBlbmQ6IGxhdGVyKHN0YXJ0LCBzcGFuKSB9O1xuICAgIHRoaXMudGl0bGVDYXJkID0gY2FyZDtcbiAgICB0cnkge1xuICAgICAgeWllbGQqIHRoaXMuaG9sZChzcGFuKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKHRoaXMudGl0bGVDYXJkID09PSBjYXJkKSBkZWxldGUgdGhpcy50aXRsZUNhcmQ7XG4gICAgfVxuICB9XG5cbiAgLy8gLS0tLSBPYmplY3RpdmVzLlxuXG4gIC8vIGBrZXlgIG5hbWVzIGFuIG9iamVjdGl2ZSB0aGF0IGEgbGF0ZXIgY2hhcHRlciBzZXR0bGVzIChzZWUgc2V0dGxlKS5cbiAgb2JqZWN0aXZlKHRleHQ6IFRleHQsIG9wdGlvbnM6IHsgb3B0aW9uYWw/OiBib29sZWFuOyBrZXk/OiBzdHJpbmcgfSA9IHt9KTogT2JqZWN0aXZlIHtcbiAgICBjb25zdCB2aWV3OiBPYmplY3RpdmVWaWV3ID0geyBpZDogdGhpcy5zZXErKywgLi4uKG9wdGlvbnMua2V5ICE9PSB1bmRlZmluZWQgPyB7IGtleTogb3B0aW9ucy5rZXkgfSA6IHt9KSwgdGV4dCwgc3RhdGU6IFwiYWN0aXZlXCIsIG9wdGlvbmFsOiBvcHRpb25zLm9wdGlvbmFsID8/IGZhbHNlLCBzaW5jZTogdGhpcy5jbG9jaygpIH07XG4gICAgdGhpcy5vYmplY3RpdmVzLnB1c2godmlldyk7XG4gICAgdGhpcy5ub3RpY2Uob3B0aW9ucy5vcHRpb25hbCA/IHsgemg6IGDmlK/nur/vvJoke3BsYWluKHRleHQpfWAsIGVuOiBgU2lkZSBxdWVzdDogJHtwbGFpbkVuKHRleHQpfWAgfSA6IHsgemg6IGDmlrDnm67moIfvvJoke3BsYWluKHRleHQpfWAsIGVuOiBgTmV3IG9iamVjdGl2ZTogJHtwbGFpbkVuKHRleHQpfWAgfSwgXCJxdWVzdFwiKTtcbiAgICBjb25zdCBzZXR0bGUgPSAoc3RhdGU6IFwiZG9uZVwiIHwgXCJmYWlsZWRcIikgPT4ge1xuICAgICAgaWYgKHZpZXcuc3RhdGUgIT09IFwiYWN0aXZlXCIpIHJldHVybjtcbiAgICAgIHZpZXcuc3RhdGUgPSBzdGF0ZTtcbiAgICAgIHZpZXcuc2luY2UgPSB0aGlzLmNsb2NrKCk7XG4gICAgICB0aGlzLm5vdGljZShzdGF0ZSA9PT0gXCJkb25lXCIgPyB7IHpoOiBg5a6M5oiQ77yaJHtwbGFpbih2aWV3LnRleHQpfWAsIGVuOiBgRG9uZTogJHtwbGFpbkVuKHZpZXcudGV4dCl9YCB9IDogeyB6aDogYOWksei0pe+8miR7cGxhaW4odmlldy50ZXh0KX1gLCBlbjogYEZhaWxlZDogJHtwbGFpbkVuKHZpZXcudGV4dCl9YCB9LCBzdGF0ZSA9PT0gXCJkb25lXCIgPyBcImdhaW5cIiA6IFwid2FyblwiKTtcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICBpZDogdmlldy5pZCxcbiAgICAgIGRvbmU6ICgpID0+IHNldHRsZShcImRvbmVcIiksXG4gICAgICBmYWlsOiAoKSA9PiBzZXR0bGUoXCJmYWlsZWRcIiksXG4gICAgICBwcm9ncmVzczogKHRleHQpID0+IHtcbiAgICAgICAgaWYgKHRleHQgPT09IHVuZGVmaW5lZCkgZGVsZXRlIHZpZXcucHJvZ3Jlc3M7XG4gICAgICAgIGVsc2Ugdmlldy5wcm9ncmVzcyA9IHRleHQ7XG4gICAgICB9LFxuICAgICAgcmVuYW1lOiAodGV4dCkgPT4ge1xuICAgICAgICB2aWV3LnRleHQgPSB0ZXh0O1xuICAgICAgfSxcbiAgICAgIGdldCBzdGF0ZSgpIHtcbiAgICAgICAgcmV0dXJuIHZpZXcuc3RhdGU7XG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICAvLyBTZXR0bGVzIGFuIG9iamVjdGl2ZSBzZXQgZWFybGllciB1bmRlciBhIGtleSAoYnkgYSBjaGFwdGVyIHRoYXQgaGFzIG5vIGhhbmRsZSB0byBpdCkuXG4gIHNldHRsZShrZXk6IHN0cmluZywgc3RhdGU6IFwiZG9uZVwiIHwgXCJmYWlsZWRcIikge1xuICAgIGNvbnN0IHZpZXcgPSB0aGlzLm9iamVjdGl2ZXMuZmluZCgob2JqZWN0aXZlKSA9PiBvYmplY3RpdmUua2V5ID09PSBrZXkgJiYgb2JqZWN0aXZlLnN0YXRlID09PSBcImFjdGl2ZVwiKTtcbiAgICBpZiAoIXZpZXcpIHJldHVybjtcbiAgICB2aWV3LnN0YXRlID0gc3RhdGU7XG4gICAgdmlldy5zaW5jZSA9IHRoaXMuY2xvY2soKTtcbiAgICB0aGlzLm5vdGljZShzdGF0ZSA9PT0gXCJkb25lXCIgPyB7IHpoOiBg5a6M5oiQ77yaJHtwbGFpbih2aWV3LnRleHQpfWAsIGVuOiBgRG9uZTogJHtwbGFpbkVuKHZpZXcudGV4dCl9YCB9IDogeyB6aDogYOWksei0pe+8miR7cGxhaW4odmlldy50ZXh0KX1gLCBlbjogYEZhaWxlZDogJHtwbGFpbkVuKHZpZXcudGV4dCl9YCB9LCBzdGF0ZSA9PT0gXCJkb25lXCIgPyBcImdhaW5cIiA6IFwid2FyblwiKTtcbiAgfVxuXG4gIC8vIEFuIG9iamVjdGl2ZSB0aGF0IGxhc3RzIGFzIGxvbmcgYXMgdGhlIGN1cnJlbnQgdGFzazogZmFpbGVkIGlmIHRoZSB0YXNrIGVuZHMgYmVmb3JlIGl0IGlzIGRvbmUuXG4gICpnb2FsKHRleHQ6IFRleHQsIG9wdGlvbnM6IHsgb3B0aW9uYWw/OiBib29sZWFuIH0gPSB7fSk6IE9wZXJhdGlvbjxPYmplY3RpdmU+IHtcbiAgICBjb25zdCBoYW5kbGUgPSB0aGlzLm9iamVjdGl2ZSh0ZXh0LCBvcHRpb25zKTtcbiAgICB5aWVsZCogZW5zdXJlKCgpID0+IHtcbiAgICAgIGlmIChoYW5kbGUuc3RhdGUgPT09IFwiYWN0aXZlXCIpIGhhbmRsZS5mYWlsKCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGhhbmRsZTtcbiAgfVxuXG4gIC8vIC0tLS0gQ2hvaWNlcy5cblxuICAvLyBQdXRzIGEgY2hvaWNlIHRvIHRoZSBwbGF5ZXIgYW5kIHdhaXRzIGZvciB0aGUgYW5zd2VyICh0aGUgb3B0aW9uJ3MgaWQpLlxuICAqY2hvb3NlPGNvbnN0IE8gZXh0ZW5kcyBzdHJpbmc+KHByb21wdDogVGV4dCwgb3B0aW9uczogcmVhZG9ubHkgeyBpZDogTzsgdGV4dDogVGV4dCB9W10sIGV4dHJhOiB7IGlkPzogc3RyaW5nOyBzcGVha2VyPzogVW5pdCB8IHN0cmluZyB9ID0ge30pOiBPcGVyYXRpb248Tz4ge1xuICAgIGlmICh0aGlzLmNob2ljZSkgdGhyb3cgbmV3IEVycm9yKFwiT25seSBvbmUgY2hvaWNlIGNhbiBiZSBvcGVuIGF0IGEgdGltZVwiKTtcbiAgICBjb25zdCBpZCA9IGV4dHJhLmlkID8/IGBjaG9pY2UtJHt0aGlzLnNlcSsrfWA7XG4gICAgY29uc3Qgb3BlbmVkID0gdGhpcy5jbG9jaygpO1xuICAgIGNvbnN0IGFuc3dlciA9IHlpZWxkKiBzdXNwZW5kPE8+KCh3YWtlKSA9PiB7XG4gICAgICB0aGlzLmNob2ljZSA9IHsgaWQsIHByb21wdCwgb3B0aW9uczogb3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKHsgaWQ6IG9wdGlvbi5pZCwgdGV4dDogb3B0aW9uLnRleHQgfSkpLCBvcGVuZWQsIC4uLihleHRyYS5zcGVha2VyICE9PSB1bmRlZmluZWQgPyB7IHNwZWFrZXJJZDogaWRPZihleHRyYS5zcGVha2VyKSB9IDoge30pLCB3YWtlOiAob3B0aW9uKSA9PiB3YWtlLnJlc3VtZShvcHRpb24pIH07XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jaG9pY2U/LmlkID09PSBpZCkgZGVsZXRlIHRoaXMuY2hvaWNlO1xuICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gYW5zd2VyO1xuICB9XG5cbiAgLy8gVGhlIHBsYXllcidzIGFuc3dlciB0byB0aGUgb3BlbiBjaG9pY2UgKGFuIGlucHV0OiBzZWUgZGlyZWN0b3IpLiBUaGUgY2hvaWNlIHN0YXlzIHVwIGEgbW9tZW50IHdpdGggdGhlIGFuc3dlciBsaXQuXG4gIGFuc3dlcihjaG9pY2VJZDogc3RyaW5nLCBvcHRpb246IHN0cmluZykge1xuICAgIGNvbnN0IGNob2ljZSA9IHRoaXMuY2hvaWNlO1xuICAgIGlmICghY2hvaWNlIHx8IGNob2ljZS5pZCAhPT0gY2hvaWNlSWQpIHRocm93IG5ldyBFcnJvcihgTm8gb3BlbiBjaG9pY2UgJHtjaG9pY2VJZH1gKTtcbiAgICBpZiAoIWNob2ljZS5vcHRpb25zLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBvcHRpb24pKSB0aHJvdyBuZXcgRXJyb3IoYENob2ljZSAke2Nob2ljZUlkfSBoYXMgbm8gb3B0aW9uICR7b3B0aW9ufWApO1xuICAgIGlmIChjaG9pY2UucGlja2VkKSB0aHJvdyBuZXcgRXJyb3IoYENob2ljZSAke2Nob2ljZUlkfSB3YXMgYWxyZWFkeSBhbnN3ZXJlZGApO1xuICAgIGNob2ljZS5waWNrZWQgPSBvcHRpb247XG4gICAgY2hvaWNlLnBpY2tlZEF0ID0gdGhpcy5jbG9jaygpO1xuICB9XG5cbiAgZ2V0IG9wZW5DaG9pY2UoKTogQ2hvaWNlVmlldyB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMuY2hvaWNlID8gc3RyaXBXYWtlKHRoaXMuY2hvaWNlKSA6IHVuZGVmaW5lZDtcbiAgfVxuXG4gIC8vIC0tLS0gVGhlIGdyb3VuZCwgdGhlIGFpciBhbmQgdGhlIGNvcm5lciBvZiB0aGUgc2NyZWVuLlxuXG4gIG1hcmsoa2luZDogTWFya2VyS2luZCwgYXQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IFVuaXQsIG9wdGlvbnM6IHsgcmFkaXVzPzogbnVtYmVyOyBsYWJlbD86IFRleHQ7IHNwYW4/OiBEdXJhdGlvbiB9ID0ge30pOiBNYXJrZXIge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5jbG9jaygpO1xuICAgIGNvbnN0IHZpZXc6IE1hcmtlclZpZXcgPSB7XG4gICAgICBpZDogdGhpcy5zZXErKyxcbiAgICAgIGtpbmQsXG4gICAgICB4OiBhdC54LFxuICAgICAgeTogYXQueSxcbiAgICAgIC4uLihcIm9yZGVyXCIgaW4gYXQgPyB7IHVuaXRJZDogYXQuaWQgfSA6IHt9KSxcbiAgICAgIHJhZGl1czogb3B0aW9ucy5yYWRpdXMgPz8gNjAsXG4gICAgICAuLi4ob3B0aW9ucy5sYWJlbCAhPT0gdW5kZWZpbmVkID8geyBsYWJlbDogb3B0aW9ucy5sYWJlbCB9IDoge30pLFxuICAgICAgc3RhcnQsXG4gICAgICAuLi4ob3B0aW9ucy5zcGFuICE9PSB1bmRlZmluZWQgPyB7IGVuZDogbGF0ZXIoc3RhcnQsIG9wdGlvbnMuc3BhbikgfSA6IHt9KSxcbiAgICB9O1xuICAgIHRoaXMubWFya2Vycy5zZXQodmlldy5pZCwgdmlldyk7XG4gICAgcmV0dXJuIHsgaWQ6IHZpZXcuaWQsIHJlbW92ZTogKCkgPT4gdm9pZCB0aGlzLm1hcmtlcnMuZGVsZXRlKHZpZXcuaWQpLCBtb3ZlOiAodG8pID0+IE9iamVjdC5hc3NpZ24odmlldywgeyB4OiB0by54LCB5OiB0by55IH0pIH07XG4gIH1cblxuICAvLyBBIG1hcmtlciBmb3IgYXMgbG9uZyBhcyB0aGUgY3VycmVudCB0YXNrIHJ1bnMuXG4gICptYXJrZXIoa2luZDogTWFya2VyS2luZCwgYXQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IFVuaXQsIG9wdGlvbnM6IHsgcmFkaXVzPzogbnVtYmVyOyBsYWJlbD86IFRleHQgfSA9IHt9KTogT3BlcmF0aW9uPE1hcmtlcj4ge1xuICAgIGNvbnN0IGhhbmRsZSA9IHRoaXMubWFyayhraW5kLCBhdCwgb3B0aW9ucyk7XG4gICAgeWllbGQqIGVuc3VyZShoYW5kbGUucmVtb3ZlKTtcbiAgICByZXR1cm4gaGFuZGxlO1xuICB9XG5cbiAgLy8gU2V0cyBhIHBpZWNlIG9mIHNjZW5lcnkgb24gdGhlIG1hcDsgaXQgc3RheXMgdW50aWwgcmVtb3ZlZC5cbiAgcHJvcChraW5kOiBzdHJpbmcsIGF0OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0sIG9wdGlvbnM6IHsgc2NhbGU/OiBudW1iZXI7IGZsaXA/OiBib29sZWFuOyBzdGF0ZT86IHN0cmluZyB9ID0ge30pOiBQcm9wIHtcbiAgICBjb25zdCB2aWV3OiBQcm9wVmlldyA9IHsgaWQ6IHRoaXMuc2VxKyssIGtpbmQsIHg6IGF0LngsIHk6IGF0LnksIHNjYWxlOiBvcHRpb25zLnNjYWxlID8/IDEsIGZsaXA6IG9wdGlvbnMuZmxpcCA/PyBmYWxzZSwgLi4uKG9wdGlvbnMuc3RhdGUgIT09IHVuZGVmaW5lZCA/IHsgc3RhdGU6IG9wdGlvbnMuc3RhdGUgfSA6IHt9KSwgc2luY2U6IHRoaXMuY2xvY2soKSB9O1xuICAgIHRoaXMucHJvcHMuc2V0KHZpZXcuaWQsIHZpZXcpO1xuICAgIGNvbnN0IHByb3BzID0gdGhpcy5wcm9wcztcbiAgICBjb25zdCBjbG9jayA9IHRoaXMuY2xvY2s7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlkOiB2aWV3LmlkLFxuICAgICAgcmVtb3ZlOiAoKSA9PiB2b2lkIHByb3BzLmRlbGV0ZSh2aWV3LmlkKSxcbiAgICAgIG1vdmU6ICh0bykgPT4ge1xuICAgICAgICB2aWV3LnggPSB0by54O1xuICAgICAgICB2aWV3LnkgPSB0by55O1xuICAgICAgfSxcbiAgICAgIHNldCBzdGF0ZShzdGF0ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChzdGF0ZSA9PT0gdmlldy5zdGF0ZSkgcmV0dXJuO1xuICAgICAgICBpZiAoc3RhdGUgPT09IHVuZGVmaW5lZCkgZGVsZXRlIHZpZXcuc3RhdGU7XG4gICAgICAgIGVsc2Ugdmlldy5zdGF0ZSA9IHN0YXRlO1xuICAgICAgICB2aWV3LnNpbmNlID0gY2xvY2soKTtcbiAgICAgIH0sXG4gICAgICBnZXQgc3RhdGUoKSB7XG4gICAgICAgIHJldHVybiB2aWV3LnN0YXRlO1xuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgLy8gVGFrZXMgZXZlcnkgcHJvcCBvZiB0aGVzZSBraW5kcyBvZmYgdGhlIG1hcCAoYSBjaGFwdGVyIGNsZWFyaW5nIHRoZSBwcmV2aW91cyBvbmUncyBzY2VuZXJ5KS5cbiAgY2xlYXJQcm9wcyhraW5kcz86IHJlYWRvbmx5IHN0cmluZ1tdKSB7XG4gICAgZm9yIChjb25zdCBbaWQsIHByb3BdIG9mIHRoaXMucHJvcHMpIGlmICgha2luZHMgfHwga2luZHMuaW5jbHVkZXMocHJvcC5raW5kKSkgdGhpcy5wcm9wcy5kZWxldGUoaWQpO1xuICB9XG5cbiAgZmxvYXQodGV4dDogVGV4dCwgYXQ6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IFVuaXQsIG9wdGlvbnM6IHsgY29sb3I/OiBzdHJpbmc7IHNwYW4/OiBEdXJhdGlvbjsgc2l6ZT86IG51bWJlciB9ID0ge30pIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuY2xvY2soKTtcbiAgICB0aGlzLmZsb2F0ZXJzLnB1c2goeyBpZDogdGhpcy5zZXErKywgdGV4dCwgY29sb3I6IG9wdGlvbnMuY29sb3IgPz8gXCIjNmI0YTFmXCIsIHg6IGF0LngsIHk6IGF0LnksIC4uLihcIm9yZGVyXCIgaW4gYXQgPyB7IHVuaXRJZDogYXQuaWQgfSA6IHt9KSwgc3RhcnQsIGVuZDogbGF0ZXIoc3RhcnQsIG9wdGlvbnMuc3BhbiA/PyBzZWNvbmRzKDEuOCkpLCBzaXplOiBvcHRpb25zLnNpemUgPz8gMTYgfSk7XG4gIH1cblxuICBub3RpY2UodGV4dDogVGV4dCwgdG9uZTogTm90aWNlVmlld1tcInRvbmVcIl0gPSBcImluZm9cIikge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5jbG9jaygpO1xuICAgIHRoaXMubm90aWNlcy5wdXNoKHsgaWQ6IHRoaXMuc2VxKyssIHRleHQsIHRvbmUsIHN0YXJ0LCBlbmQ6IGxhdGVyKHN0YXJ0LCBOT1RJQ0VfU1BBTikgfSk7XG4gIH1cblxuICAvLyAtLS0tIEZyYW1pbmcuXG5cbiAgbG9vayhjYW1lcmE6IENhbWVyYVZpZXcpIHtcbiAgICB0aGlzLmNhbWVyYSA9IGNhbWVyYTtcbiAgfVxuXG4gIC8vIExvb2tzIGFzIGFza2VkIGZvciBhcyBsb25nIGFzIHRoZSBjdXJyZW50IHRhc2sgcnVucywgdGhlbiBhcyBiZWZvcmUuXG4gICpmcmFtaW5nKGNhbWVyYTogQ2FtZXJhVmlldyk6IE9wZXJhdGlvbjx2b2lkPiB7XG4gICAgY29uc3QgYmVmb3JlID0gdGhpcy5jYW1lcmE7XG4gICAgdGhpcy5jYW1lcmEgPSBjYW1lcmE7XG4gICAgeWllbGQqIGVuc3VyZSgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5jYW1lcmEgPT09IGNhbWVyYSkgdGhpcy5jYW1lcmEgPSBiZWZvcmU7XG4gICAgfSk7XG4gIH1cblxuICBxdWFrZShhbW91bnQ6IG51bWJlciwgc3BhbjogRHVyYXRpb24pIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuY2xvY2soKTtcbiAgICB0aGlzLnNoYWtlID0geyBhbW91bnQsIHN0YXJ0LCBlbmQ6IGxhdGVyKHN0YXJ0LCBzcGFuKSB9O1xuICB9XG5cbiAgc2V0TGV0dGVyYm94KG9uOiBib29sZWFuKSB7XG4gICAgaWYgKHRoaXMubGV0dGVyYm94Lm9uID09PSBvbikgcmV0dXJuO1xuICAgIHRoaXMubGV0dGVyYm94ID0geyBvbiwgc2luY2U6IHRoaXMuY2xvY2soKSB9O1xuICAgIGlmICghb24pIGRlbGV0ZSB0aGlzLmZvY3VzSWQ7XG4gIH1cblxuICAvLyBMZXR0ZXJib3ggZm9yIGFzIGxvbmcgYXMgdGhlIGN1cnJlbnQgdGFzayBydW5zLlxuICAqY2luZW1hdGljKCk6IE9wZXJhdGlvbjx2b2lkPiB7XG4gICAgdGhpcy5zZXRMZXR0ZXJib3godHJ1ZSk7XG4gICAgeWllbGQqIGVuc3VyZSgoKSA9PiB0aGlzLnNldExldHRlcmJveChmYWxzZSkpO1xuICB9XG5cbiAgKmZhZGVUbyhhbHBoYTogbnVtYmVyLCBzcGFuOiBEdXJhdGlvbik6IE9wZXJhdGlvbjx2b2lkPiB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLmNsb2NrKCk7XG4gICAgdGhpcy5mYWRlID0geyBmcm9tOiB0aGlzLmZhZGVBbHBoYShzdGFydCksIHRvOiBhbHBoYSwgc3RhcnQsIGVuZDogbGF0ZXIoc3RhcnQsIHNwYW4pIH07XG4gICAgaWYgKHNwYW4gPiAwKSB5aWVsZCogdGhpcy5ob2xkKHNwYW4pO1xuICB9XG5cbiAgZ2V0IGNpbmVtYXRpY09uKCkge1xuICAgIHJldHVybiB0aGlzLmxldHRlcmJveC5vbjtcbiAgfVxuXG4gIC8vIC0tLS0gVGhlIERpcmVjdG9yJ3Mgc2lkZS5cblxuICAvLyBOb2JvZHkgaXMgc3BlYWtpbmcgb3Igd2FpdGluZyB0bywgbm8gY2hvaWNlIGlzIG9wZW4gYW5kIG5vdGhpbmcgaG9sZHMgdGhlIHN0b3J5OiBhIGNoZWNrcG9pbnQgY2FuIGJlIHRha2VuLlxuICBnZXQgcXVpZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3BlYWtpbmcuc2l6ZSA9PT0gMCAmJiB0aGlzLnF1ZXVlcy5zaXplID09PSAwICYmICF0aGlzLmNob2ljZSAmJiB0aGlzLmhvbGRzLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIG1lbW9yeSgpOiBTdGFnZU1lbW9yeSB7XG4gICAgcmV0dXJuIHsgdW5pdEFjdGlvbnM6IFsuLi50aGlzLnVuaXRBY3Rpb25zLnZhbHVlcygpXS5tYXAoY3VlID0+ICh7IC4uLmN1ZSB9KSksIGNhcmRzOiBbLi4udGhpcy5jYXJkc10sIHByb3BzOiBbLi4udGhpcy5wcm9wcy52YWx1ZXMoKV0ubWFwKChwcm9wKSA9PiAoeyAuLi5wcm9wIH0pKSwgLi4uKHRoaXMuY2hhcHRlciAhPT0gdW5kZWZpbmVkID8geyBjaGFwdGVyOiB0aGlzLmNoYXB0ZXIgfSA6IHt9KSwgbGV0dGVyYm94OiB7IC4uLnRoaXMubGV0dGVyYm94IH0sIGZhZGU6IHsgLi4udGhpcy5mYWRlIH0sIGNhbWVyYTogdGhpcy5jYW1lcmEgfTtcbiAgfVxuXG4gIHJlc3RvcmUobWVtb3J5OiBTdGFnZU1lbW9yeSkge1xuICAgIHRoaXMudW5pdEFjdGlvbnMuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IGN1ZSBvZiBtZW1vcnkudW5pdEFjdGlvbnMgPz8gW10pIHRoaXMudW5pdEFjdGlvbnMuc2V0KGN1ZS51bml0SWQsIHsgLi4uY3VlIH0pO1xuICAgIHRoaXMuY2FyZHMuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IFt1bml0SWQsIGNhcmRdIG9mIG1lbW9yeS5jYXJkcykgdGhpcy5jYXJkcy5zZXQodW5pdElkLCBjYXJkKTtcbiAgICB0aGlzLnByb3BzLmNsZWFyKCk7XG4gICAgZm9yIChjb25zdCBwcm9wIG9mIG1lbW9yeS5wcm9wcykgdGhpcy5wcm9wcy5zZXQocHJvcC5pZCwgeyAuLi5wcm9wIH0pO1xuICAgIHRoaXMuc2VxID0gTWF0aC5tYXgodGhpcy5zZXEsIC4uLm1lbW9yeS5wcm9wcy5tYXAoKHByb3ApID0+IHByb3AuaWQgKyAxKSk7XG4gICAgaWYgKG1lbW9yeS5jaGFwdGVyICE9PSB1bmRlZmluZWQpIHRoaXMuY2hhcHRlciA9IG1lbW9yeS5jaGFwdGVyO1xuICAgIHRoaXMubGV0dGVyYm94ID0geyAuLi5tZW1vcnkubGV0dGVyYm94IH07XG4gICAgdGhpcy5mYWRlID0geyAuLi5tZW1vcnkuZmFkZSB9O1xuICAgIHRoaXMuY2FtZXJhID0gbWVtb3J5LmNhbWVyYTtcbiAgfVxuXG4gIC8vIE9uY2UgYSB0aWNrOiBsaW5lcyBlbmQgYW5kIHRoZSBuZXh0IGJlZ2luLCB0aGUgYW5zd2VyZWQgY2hvaWNlIGNsb3NlcywgdGhlIG9sZCB3b3JkcyBmYWRlIGZyb20gdGhlIGxpc3RzLlxuICB0aWNrKCkge1xuICAgIGNvbnN0IG5vdyA9IHRoaXMuY2xvY2soKTtcbiAgICBmb3IgKGNvbnN0IFt1bml0SWQsIGN1ZV0gb2YgdGhpcy51bml0QWN0aW9ucykgaWYgKG5vdyAtIGN1ZS50aWNrID4gc2Vjb25kcygxKSB8fCAhdGhpcy5hbGl2ZSh1bml0SWQpKSB0aGlzLnVuaXRBY3Rpb25zLmRlbGV0ZSh1bml0SWQpO1xuICAgIGZvciAoY29uc3QgW3NwZWFrZXJJZCwgYWN0aXZlXSBvZiBbLi4udGhpcy5zcGVha2luZ10pIHtcbiAgICAgIGlmIChhY3RpdmUudmlldy5lbmQgPiBub3cgJiYgdGhpcy5hbGl2ZShzcGVha2VySWQpKSBjb250aW51ZTtcbiAgICAgIHRoaXMuc3BlYWtpbmcuZGVsZXRlKHNwZWFrZXJJZCk7XG4gICAgICBhY3RpdmUuZG9uZSgpO1xuICAgICAgdGhpcy5zdGFydE5leHQoc3BlYWtlcklkKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBzcGVha2VySWQgb2YgWy4uLnRoaXMucXVldWVzLmtleXMoKV0pIHRoaXMuc3RhcnROZXh0KHNwZWFrZXJJZCk7XG4gICAgaWYgKHRoaXMuY2hvaWNlPy5waWNrZWRBdCAhPT0gdW5kZWZpbmVkICYmIG5vdyAtIHRoaXMuY2hvaWNlLnBpY2tlZEF0ID49IENIT0lDRV9MSU5HRVIpIHtcbiAgICAgIGNvbnN0IHsgd2FrZSwgcGlja2VkIH0gPSB0aGlzLmNob2ljZTtcbiAgICAgIGRlbGV0ZSB0aGlzLmNob2ljZTtcbiAgICAgIHdha2U/LihwaWNrZWQhKTtcbiAgICB9XG4gICAgZm9yIChsZXQgaW5kZXggPSB0aGlzLm9iamVjdGl2ZXMubGVuZ3RoIC0gMTsgaW5kZXggPj0gMDsgaW5kZXggLT0gMSkge1xuICAgICAgY29uc3Qgb2JqZWN0aXZlID0gdGhpcy5vYmplY3RpdmVzW2luZGV4XSE7XG4gICAgICBpZiAob2JqZWN0aXZlLnN0YXRlICE9PSBcImFjdGl2ZVwiICYmIG5vdyAtIG9iamVjdGl2ZS5zaW5jZSA+PSBPQkpFQ1RJVkVfTElOR0VSKSB0aGlzLm9iamVjdGl2ZXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBbaWQsIG1hcmtlcl0gb2YgdGhpcy5tYXJrZXJzKSBpZiAobWFya2VyLmVuZCAhPT0gdW5kZWZpbmVkICYmIG1hcmtlci5lbmQgPD0gbm93KSB0aGlzLm1hcmtlcnMuZGVsZXRlKGlkKTtcbiAgICB0aGlzLmZsb2F0ZXJzID0gdGhpcy5mbG9hdGVycy5maWx0ZXIoKGZsb2F0ZXIpID0+IGZsb2F0ZXIuZW5kID4gbm93KTtcbiAgICB0aGlzLm5vdGljZXMgPSB0aGlzLm5vdGljZXMuZmlsdGVyKChub3RpY2UpID0+IG5vdGljZS5lbmQgPiBub3cpO1xuICAgIGlmICh0aGlzLnNoYWtlICYmIHRoaXMuc2hha2UuZW5kIDw9IG5vdykgZGVsZXRlIHRoaXMuc2hha2U7XG4gIH1cblxuICB2aWV3KCk6IFN0YWdlVmlldyB7XG4gICAgY29uc3QgdGljayA9IHRoaXMuY2xvY2soKTtcbiAgICBjb25zdCBuYW1lcGxhdGVzOiBTdGFnZVZpZXdbXCJuYW1lcGxhdGVzXCJdID0ge307XG4gICAgZm9yIChjb25zdCBbdW5pdElkLCBjYXJkXSBvZiB0aGlzLmNhcmRzKSB7XG4gICAgICBjb25zdCBsZXZlbCA9IHRoaXMubGV2ZWxzPy4odW5pdElkKTtcbiAgICAgIG5hbWVwbGF0ZXNbdW5pdElkXSA9IHsgbmFtZTogY2FyZC5uYW1lLCBjb2xvcjogY2FyZC5jb2xvciwgLi4uKGxldmVsICE9PSB1bmRlZmluZWQgPyB7IGxldmVsIH0gOiB7fSkgfTtcbiAgICB9XG4gICAgY29uc3QgcGFydHkgPSB0aGlzLnBhcnR5Vmlldz8uKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRpY2ssXG4gICAgICAuLi4odGhpcy51bml0QWN0aW9ucy5zaXplID8geyB1bml0QWN0aW9uczogWy4uLnRoaXMudW5pdEFjdGlvbnMudmFsdWVzKCldLm1hcChjdWUgPT4gKHsgLi4uY3VlIH0pKSB9IDoge30pLFxuICAgICAgbGluZXM6IFsuLi50aGlzLnNwZWFraW5nLnZhbHVlcygpXS5tYXAoKGFjdGl2ZSkgPT4gKHsgLi4uYWN0aXZlLnZpZXcgfSkpLFxuICAgICAgLi4uKHRoaXMubmFycmF0aW9uID8geyBuYXJyYXRpb246IHsgLi4udGhpcy5uYXJyYXRpb24gfSB9IDoge30pLFxuICAgICAgLi4uKHRoaXMudGl0bGVDYXJkID8geyB0aXRsZTogeyAuLi50aGlzLnRpdGxlQ2FyZCB9IH0gOiB7fSksXG4gICAgICBvYmplY3RpdmVzOiB0aGlzLm9iamVjdGl2ZXMubWFwKChvYmplY3RpdmUpID0+ICh7IC4uLm9iamVjdGl2ZSB9KSksXG4gICAgICAuLi4odGhpcy5jaG9pY2UgPyB7IGNob2ljZTogc3RyaXBXYWtlKHRoaXMuY2hvaWNlKSB9IDoge30pLFxuICAgICAgbGV0dGVyYm94OiB7IC4uLnRoaXMubGV0dGVyYm94IH0sXG4gICAgICBmYWRlOiB7IC4uLnRoaXMuZmFkZSB9LFxuICAgICAgbWFya2VyczogWy4uLnRoaXMubWFya2Vycy52YWx1ZXMoKV0ubWFwKChtYXJrZXIpID0+IHRoaXMucGxhY2VkKG1hcmtlcikpLFxuICAgICAgcHJvcHM6IFsuLi50aGlzLnByb3BzLnZhbHVlcygpXS5tYXAoKHByb3ApID0+ICh7IC4uLnByb3AgfSkpLFxuICAgICAgZmxvYXRlcnM6IHRoaXMuZmxvYXRlcnMubWFwKChmbG9hdGVyKSA9PiB0aGlzLnBsYWNlZChmbG9hdGVyKSksXG4gICAgICBub3RpY2VzOiB0aGlzLm5vdGljZXMubWFwKChub3RpY2UpID0+ICh7IC4uLm5vdGljZSB9KSksXG4gICAgICBuYW1lcGxhdGVzLFxuICAgICAgLi4uKHBhcnR5ID8geyBwYXJ0eSB9IDoge30pLFxuICAgICAgY2FtZXJhOiB0aGlzLmNhbWVyYSxcbiAgICAgIC4uLih0aGlzLnNoYWtlID8geyBzaGFrZTogeyAuLi50aGlzLnNoYWtlIH0gfSA6IHt9KSxcbiAgICAgIC4uLih0aGlzLmZvY3VzSWQgPyB7IGZvY3VzSWQ6IHRoaXMuZm9jdXNJZCB9IDoge30pLFxuICAgICAgLi4uKHRoaXMuY2hhcHRlciAhPT0gdW5kZWZpbmVkID8geyBjaGFwdGVyOiB0aGlzLmNoYXB0ZXIgfSA6IHt9KSxcbiAgICB9O1xuICB9XG5cbiAgZmFkZUFscGhhKGF0OiBudW1iZXIpIHtcbiAgICBjb25zdCB7IGZyb20sIHRvLCBzdGFydCwgZW5kIH0gPSB0aGlzLmZhZGU7XG4gICAgaWYgKGF0ID49IGVuZCkgcmV0dXJuIHRvO1xuICAgIGlmIChhdCA8PSBzdGFydCkgcmV0dXJuIGZyb207XG4gICAgcmV0dXJuIGZyb20gKyAoKHRvIC0gZnJvbSkgKiAoYXQgLSBzdGFydCkpIC8gTWF0aC5tYXgoMSwgZW5kIC0gc3RhcnQpO1xuICB9XG5cbiAgLy8gQSBtYXJrZXIgb3IgZmxvYXRlciB0aGF0IGZvbGxvd3MgYSB1bml0IHN0YW5kcyB3aGVyZSB0aGUgdW5pdCBzdGFuZHMgKG9yIHN0b29kIGxhc3QpLlxuICBwcml2YXRlIHBsYWNlZDxUIGV4dGVuZHMgeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdW5pdElkPzogc3RyaW5nIH0+KGl0ZW06IFQpOiBUIHtcbiAgICBpZiAoIWl0ZW0udW5pdElkKSByZXR1cm4geyAuLi5pdGVtIH07XG4gICAgY29uc3QgdW5pdCA9IHRoaXMuZ2FtZS51bml0cy5maW5kKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gaXRlbS51bml0SWQpO1xuICAgIGlmICh1bml0KSB7XG4gICAgICBpdGVtLnggPSB1bml0Lng7XG4gICAgICBpdGVtLnkgPSB1bml0Lnk7XG4gICAgfVxuICAgIHJldHVybiB7IC4uLml0ZW0gfTtcbiAgfVxuXG4gIHByaXZhdGUgKmhvbGQoc3BhbjogRHVyYXRpb24pOiBPcGVyYXRpb248dm9pZD4ge1xuICAgIGNvbnN0IGR1ZSA9IGxhdGVyKHRoaXMuY2xvY2soKSwgc3Bhbik7XG4gICAgeWllbGQqIHN1c3BlbmQ8dm9pZD4oKHdha2UpID0+IHtcbiAgICAgIGNvbnN0IGxpbmUgPSB7IGRvbmU6ICgpID0+IHdha2UucmVzdW1lKHVuZGVmaW5lZCksIGR1ZSB9O1xuICAgICAgdGhpcy5ob2xkcy5wdXNoKGxpbmUpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgaW5kZXggPSB0aGlzLmhvbGRzLmluZGV4T2YobGluZSk7XG4gICAgICAgIGlmIChpbmRleCA+PSAwKSB0aGlzLmhvbGRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICB9O1xuICAgIH0pO1xuICB9XG5cbiAgLy8gV2FrZXMgd2hhdGV2ZXIgaG9sZHMgZm9yIGEgc3BhbiAodGl0bGVzLCBuYXJyYXRpb24sIGZhZGVzKSB3aG9zZSBzcGFuIGlzIG92ZXIuIENhbGxlZCBieSB0aGUgRGlyZWN0b3IncyB0aWNrLlxuICByZWxlYXNlSG9sZHMoKSB7XG4gICAgY29uc3Qgbm93ID0gdGhpcy5jbG9jaygpO1xuICAgIGZvciAoY29uc3QgaG9sZCBvZiB0aGlzLmhvbGRzLmZpbHRlcigoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuZHVlIDw9IG5vdykpIGhvbGQuZG9uZSgpO1xuICB9XG5cbiAgcHJpdmF0ZSBsaW5lRm9yKHNwZWFrZXJJZDogc3RyaW5nLCB0ZXh0OiBUZXh0LCB0b25lOiBUb25lKTogT21pdDxMaW5lVmlldywgXCJzdGFydFwiIHwgXCJlbmRcIj4ge1xuICAgIGNvbnN0IGNhcmQgPSB0aGlzLmNhcmRzLmdldChzcGVha2VySWQpO1xuICAgIHJldHVybiB7IGlkOiB0aGlzLnNlcSsrLCBzcGVha2VySWQsIG5hbWU6IGNhcmQ/Lm5hbWUgPz8gXCJcIiwgY29sb3I6IGNhcmQ/LmNvbG9yID8/IFwiIzVjNGEzMlwiLCB0ZXh0LCB0b25lIH07XG4gIH1cblxuICBwcml2YXRlIHF1ZXVlT2Yoc3BlYWtlcklkOiBzdHJpbmcpIHtcbiAgICBsZXQgcXVldWUgPSB0aGlzLnF1ZXVlcy5nZXQoc3BlYWtlcklkKTtcbiAgICBpZiAoIXF1ZXVlKSB7XG4gICAgICBxdWV1ZSA9IFtdO1xuICAgICAgdGhpcy5xdWV1ZXMuc2V0KHNwZWFrZXJJZCwgcXVldWUpO1xuICAgIH1cbiAgICByZXR1cm4gcXVldWU7XG4gIH1cblxuICBwcml2YXRlIHN0YXJ0TmV4dChzcGVha2VySWQ6IHN0cmluZykge1xuICAgIGlmICh0aGlzLnNwZWFraW5nLmhhcyhzcGVha2VySWQpKSByZXR1cm47XG4gICAgY29uc3QgcXVldWUgPSB0aGlzLnF1ZXVlcy5nZXQoc3BlYWtlcklkKTtcbiAgICBpZiAoIXF1ZXVlKSByZXR1cm47XG4gICAgaWYgKCF0aGlzLmFsaXZlKHNwZWFrZXJJZCkpIHtcbiAgICAgIHRoaXMucXVldWVzLmRlbGV0ZShzcGVha2VySWQpO1xuICAgICAgZm9yIChjb25zdCBwZW5kaW5nIG9mIHF1ZXVlKSBwZW5kaW5nLmRvbmUoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbmV4dCA9IHF1ZXVlLnNoaWZ0KCk7XG4gICAgaWYgKHF1ZXVlLmxlbmd0aCA9PT0gMCkgdGhpcy5xdWV1ZXMuZGVsZXRlKHNwZWFrZXJJZCk7XG4gICAgaWYgKCFuZXh0KSByZXR1cm47XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLmNsb2NrKCk7XG4gICAgdGhpcy5zcGVha2luZy5zZXQoc3BlYWtlcklkLCB7IHZpZXc6IHsgLi4ubmV4dC5saW5lLCBzdGFydCwgZW5kOiBsYXRlcihzdGFydCwgdGlja3MoTWF0aC5tYXgoMSwgbmV4dC5zcGFuKSkpIH0sIGRvbmU6IG5leHQuZG9uZSB9KTtcbiAgICBpZiAodGhpcy5sZXR0ZXJib3gub24pIHRoaXMuZm9jdXNJZCA9IHNwZWFrZXJJZDtcbiAgfVxuXG4gIC8vIFRoZSB0YXNrIHRoYXQgc2FpZCB0aGUgbGluZSB3YXMgaGFsdGVkOiB0aGUgbGluZSBnb2VzLCB3aGV0aGVyIGl0IHdhcyB3YWl0aW5nIG9yIHNob3dpbmcuXG4gIHByaXZhdGUgd2l0aGRyYXcoc3BlYWtlcklkOiBzdHJpbmcsIHBlbmRpbmc6IFBlbmRpbmcpIHtcbiAgICBjb25zdCBxdWV1ZSA9IHRoaXMucXVldWVzLmdldChzcGVha2VySWQpO1xuICAgIGNvbnN0IGluZGV4ID0gcXVldWU/LmluZGV4T2YocGVuZGluZykgPz8gLTE7XG4gICAgaWYgKHF1ZXVlICYmIGluZGV4ID49IDApIHtcbiAgICAgIHF1ZXVlLnNwbGljZShpbmRleCwgMSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZSA9IHRoaXMuc3BlYWtpbmcuZ2V0KHNwZWFrZXJJZCk7XG4gICAgaWYgKGFjdGl2ZSAmJiBhY3RpdmUudmlldy5pZCA9PT0gcGVuZGluZy5saW5lLmlkKSB7XG4gICAgICB0aGlzLnNwZWFraW5nLmRlbGV0ZShzcGVha2VySWQpO1xuICAgICAgdGhpcy5zdGFydE5leHQoc3BlYWtlcklkKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFsaXZlKHVuaXRJZDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2FtZS51bml0cy5zb21lKCh1bml0KSA9PiB1bml0LmlkID09PSB1bml0SWQgJiYgdW5pdC5ocCA+IDApO1xuICB9XG59XG5cbmV4cG9ydCB0eXBlIE9iamVjdGl2ZSA9IHtcbiAgcmVhZG9ubHkgaWQ6IG51bWJlcjtcbiAgZG9uZSgpOiB2b2lkO1xuICBmYWlsKCk6IHZvaWQ7XG4gIHByb2dyZXNzKHRleHQ6IHN0cmluZyB8IHVuZGVmaW5lZCk6IHZvaWQ7XG4gIHJlbmFtZSh0ZXh0OiBUZXh0KTogdm9pZDtcbiAgcmVhZG9ubHkgc3RhdGU6IFwiYWN0aXZlXCIgfCBcImRvbmVcIiB8IFwiZmFpbGVkXCI7XG59O1xuXG5leHBvcnQgdHlwZSBNYXJrZXIgPSB7IHJlYWRvbmx5IGlkOiBudW1iZXI7IHJlbW92ZSgpOiB2b2lkOyBtb3ZlKHRvOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0pOiB2b2lkIH07XG5cbmV4cG9ydCB0eXBlIFByb3AgPSB7IHJlYWRvbmx5IGlkOiBudW1iZXI7IHJlbW92ZSgpOiB2b2lkOyBtb3ZlKHRvOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0pOiB2b2lkOyBzdGF0ZTogc3RyaW5nIHwgdW5kZWZpbmVkIH07XG5cbmZ1bmN0aW9uIGlkT2YodW5pdDogVW5pdCB8IHN0cmluZykge1xuICByZXR1cm4gdHlwZW9mIHVuaXQgPT09IFwic3RyaW5nXCIgPyB1bml0IDogdW5pdC5pZDtcbn1cblxuZnVuY3Rpb24gcGxhaW4odGV4dDogVGV4dCkge1xuICByZXR1cm4gdHlwZW9mIHRleHQgPT09IFwic3RyaW5nXCIgPyB0ZXh0IDogdGV4dC56aDtcbn1cblxuZnVuY3Rpb24gcGxhaW5Fbih0ZXh0OiBUZXh0KSB7XG4gIHJldHVybiB0eXBlb2YgdGV4dCA9PT0gXCJzdHJpbmdcIiA/IHRleHQgOiAodGV4dC5lbiA/PyB0ZXh0LnpoKTtcbn1cblxuZnVuY3Rpb24gc3RyaXBXYWtlKGNob2ljZTogQ2hvaWNlVmlldyAmIHsgd2FrZT86IHVua25vd24gfSk6IENob2ljZVZpZXcge1xuICBjb25zdCB7IHdha2U6IF93YWtlLCAuLi52aWV3IH0gPSBjaG9pY2U7XG4gIHJldHVybiB7IC4uLnZpZXcsIG9wdGlvbnM6IHZpZXcub3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKHsgLi4ub3B0aW9uIH0pKSB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLG1CQUFtQjtBQUc1QixTQUFTLFFBQVEsZUFBK0I7QUFDaEQsU0FBUyxPQUFPLFNBQVMsYUFBMEM7QUFlNUQsZ0JBQVMsT0FBTyxNQUFZLFFBQTZCO0FBQzlELE1BQUksT0FBTyxTQUFTLFNBQVUsUUFBTztBQUNyQyxTQUFPLFdBQVcsT0FBUSxLQUFLLE1BQU0sS0FBSyxLQUFNLEtBQUs7QUFDdkQ7QUE4RU8sZ0JBQVMsWUFBWSxNQUFzQjtBQUNoRCxRQUFNLFFBQVEsT0FBTyxTQUFTLFdBQVcsT0FBTyxLQUFLO0FBQ3JELFFBQU0sUUFBUSxDQUFDLEdBQUcsS0FBSyxFQUFFO0FBQ3pCLFNBQU8sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSSxDQUFDLENBQUM7QUFDL0Q7QUFFQSxNQUFNLGdCQUFnQixRQUFRLEdBQUc7QUFDakMsTUFBTSxtQkFBbUIsUUFBUSxDQUFDO0FBQ2xDLE1BQU0sY0FBYyxRQUFRLENBQUM7QUFFdEIsYUFBTSxNQUFNO0FBQUEsRUF3QmpCLFlBQTZCLE1BQTZCLE9BQXNCO0FBQW5EO0FBQTZCO0FBQUEsRUFBdUI7QUFBQSxFQXZCekUsTUFBTTtBQUFBLEVBQ0csY0FBYyxvQkFBSSxJQUEyQjtBQUFBLEVBQzdDLFdBQVcsb0JBQUksSUFBb0I7QUFBQSxFQUNuQyxTQUFTLG9CQUFJLElBQXVCO0FBQUEsRUFDcEMsUUFBUSxvQkFBSSxJQUF5QjtBQUFBLEVBQzlDO0FBQUEsRUFDQTtBQUFBLEVBQ1MsYUFBOEIsQ0FBQztBQUFBLEVBQ3hDO0FBQUEsRUFDQSxZQUFZLEVBQUUsSUFBSSxPQUFPLE9BQU8sRUFBRTtBQUFBLEVBQ2xDLE9BQU8sRUFBRSxNQUFNLEdBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLLEVBQUU7QUFBQSxFQUNqQyxVQUFVLG9CQUFJLElBQXdCO0FBQUEsRUFDdEMsUUFBUSxvQkFBSSxJQUFzQjtBQUFBLEVBQ25EO0FBQUEsRUFDaUIsUUFBOEMsQ0FBQztBQUFBLEVBQ3hELFdBQTBCLENBQUM7QUFBQSxFQUMzQixVQUF3QixDQUFDO0FBQUEsRUFDekIsU0FBcUIsRUFBRSxNQUFNLE9BQU87QUFBQSxFQUNwQztBQUFBLEVBQ0E7QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQSxFQU1BLFdBQVcsTUFBcUIsTUFBNkIsUUFBeUM7QUFDcEcsVUFBTSxTQUFTLEtBQUssSUFBSTtBQUN4QixVQUFNLFNBQU8sT0FBTyxTQUFTLFdBQVcsS0FBSyxLQUFLLE1BQU0sS0FBSyxXQUFPLE1BQU0sT0FBSyxNQUFNLElBQUk7QUFDekYsVUFBTSxTQUFPLFFBQVEsS0FBRyxLQUFLLEtBQUssTUFBTSxLQUFLLFdBQU8sTUFBTSxPQUFLLE9BQU8sRUFBRSxJQUFFO0FBQzFFLFVBQU0sU0FBTyxDQUFDLFVBQWE7QUFBQyxZQUFNLE9BQUssTUFBTSxRQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssQ0FBQUEsVUFBTUEsTUFBSyxPQUFLLE1BQU0sS0FBTSxNQUFNO0FBQUUsYUFBTyxRQUFNLFlBQVksSUFBSSxHQUFHLGNBQVksS0FBRyxLQUFHLFlBQVksS0FBSyxHQUFHLGNBQVk7QUFBQSxJQUFFO0FBQ2hNLFFBQUksS0FBSyxNQUFNLE1BQU0sRUFBRyxNQUFLLFlBQVksSUFBSSxRQUFRLEVBQUUsUUFBUSxNQUFNLE1BQU0sS0FBSyxNQUFNLEdBQUcsR0FBSSxVQUFRLFNBQU8sRUFBQyxPQUFNLE9BQU8sR0FBRSxPQUFNLE9BQU8sR0FBRSxLQUFJLE9BQU8sR0FBRSxLQUFJLE9BQU8sR0FBRSxHQUFJLFNBQU8sRUFBQyxZQUFXLE9BQU8sTUFBTSxHQUFFLFVBQVMsT0FBTyxNQUFNLEVBQUMsSUFBRSxDQUFDLEVBQUUsSUFBRSxDQUFDLEVBQUcsQ0FBQztBQUFBLEVBQ2hQO0FBQUE7QUFBQTtBQUFBLEVBS0EsS0FBSyxNQUFxQixNQUFtQjtBQUMzQyxTQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDakM7QUFBQSxFQUVBLEtBQUssTUFBOEM7QUFDakQsV0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksQ0FBQztBQUFBLEVBQ2xDO0FBQUE7QUFBQTtBQUFBLEVBS0EsQ0FBQyxJQUFJLFNBQXdCLE1BQVksVUFBNEMsQ0FBQyxHQUFvQjtBQUN4RyxVQUFNLFlBQVksS0FBSyxPQUFPO0FBQzlCLFFBQUksQ0FBQyxLQUFLLE1BQU0sU0FBUyxFQUFHO0FBQzVCLFdBQU8sUUFBYyxDQUFDLFNBQVM7QUFDN0IsWUFBTSxVQUFtQixFQUFFLE1BQU0sS0FBSyxRQUFRLFdBQVcsTUFBTSxRQUFRLFFBQVEsS0FBSyxHQUFHLE1BQU0sUUFBUSxRQUFRLFlBQVksSUFBSSxHQUFHLE1BQU0sTUFBTSxLQUFLLE9BQU8sTUFBUyxFQUFFO0FBQ25LLFdBQUssUUFBUSxTQUFTLEVBQUUsS0FBSyxPQUFPO0FBQ3BDLFdBQUssVUFBVSxTQUFTO0FBQ3hCLGFBQU8sTUFBTSxLQUFLLFNBQVMsV0FBVyxPQUFPO0FBQUEsSUFDL0MsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBLEVBR0EsS0FBSyxTQUF3QixNQUFZLFVBQTRDLENBQUMsR0FBRztBQUN2RixVQUFNLFlBQVksS0FBSyxPQUFPO0FBQzlCLFFBQUksQ0FBQyxLQUFLLE1BQU0sU0FBUyxFQUFHO0FBQzVCLFNBQUssUUFBUSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sS0FBSyxRQUFRLFdBQVcsTUFBTSxRQUFRLFFBQVEsS0FBSyxHQUFHLE1BQU0sUUFBUSxRQUFRLFlBQVksSUFBSSxHQUFHLE1BQU0sTUFBTSxPQUFVLENBQUM7QUFDM0osU0FBSyxVQUFVLFNBQVM7QUFBQSxFQUMxQjtBQUFBO0FBQUEsRUFHQSxDQUFDLFFBQVEsTUFBWSxPQUFpQixZQUFZLElBQUksR0FBb0I7QUFDeEUsVUFBTSxRQUFRLEtBQUssTUFBTTtBQUN6QixVQUFNLE9BQWtCLEVBQUUsTUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtBQUMvRCxTQUFLLFlBQVk7QUFDakIsUUFBSTtBQUNGLGFBQU8sS0FBSyxLQUFLLElBQUk7QUFBQSxJQUN2QixVQUFFO0FBQ0EsVUFBSSxLQUFLLGNBQWMsS0FBTSxRQUFPLEtBQUs7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsQ0FBQyxNQUFNLE1BQVksVUFBaUIsT0FBaUIsUUFBUSxHQUFHLEdBQW9CO0FBQ2xGLFVBQU0sUUFBUSxLQUFLLE1BQU07QUFDekIsVUFBTSxPQUFrQixFQUFFLE1BQU0sR0FBSSxhQUFhLFNBQVksRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFJLE9BQU8sS0FBSyxNQUFNLE9BQU8sSUFBSSxFQUFFO0FBQ2hILFNBQUssWUFBWTtBQUNqQixRQUFJO0FBQ0YsYUFBTyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQ3ZCLFVBQUU7QUFDQSxVQUFJLEtBQUssY0FBYyxLQUFNLFFBQU8sS0FBSztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQSxFQUtBLFVBQVUsTUFBWSxVQUFnRCxDQUFDLEdBQWM7QUFDbkYsVUFBTSxPQUFzQixFQUFFLElBQUksS0FBSyxPQUFPLEdBQUksUUFBUSxRQUFRLFNBQVksRUFBRSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsR0FBSSxNQUFNLE9BQU8sVUFBVSxVQUFVLFFBQVEsWUFBWSxPQUFPLE9BQU8sS0FBSyxNQUFNLEVBQUU7QUFDMUwsU0FBSyxXQUFXLEtBQUssSUFBSTtBQUN6QixTQUFLLE9BQU8sUUFBUSxXQUFXLEVBQUUsSUFBSSxNQUFNLE1BQU0sSUFBSSxDQUFDLElBQUksSUFBSSxlQUFlLFFBQVEsSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFLElBQUksT0FBTyxNQUFNLElBQUksQ0FBQyxJQUFJLElBQUksa0JBQWtCLFFBQVEsSUFBSSxDQUFDLEdBQUcsR0FBRyxPQUFPO0FBQzdLLFVBQU0sU0FBUyxDQUFDLFVBQTZCO0FBQzNDLFVBQUksS0FBSyxVQUFVLFNBQVU7QUFDN0IsV0FBSyxRQUFRO0FBQ2IsV0FBSyxRQUFRLEtBQUssTUFBTTtBQUN4QixXQUFLLE9BQU8sVUFBVSxTQUFTLEVBQUUsSUFBSSxNQUFNLE1BQU0sS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLFNBQVMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLE1BQU0sTUFBTSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxVQUFVLFNBQVMsU0FBUyxNQUFNO0FBQUEsSUFDaE47QUFDQSxXQUFPO0FBQUEsTUFDTCxJQUFJLEtBQUs7QUFBQSxNQUNULE1BQU0sTUFBTSxPQUFPLE1BQU07QUFBQSxNQUN6QixNQUFNLE1BQU0sT0FBTyxRQUFRO0FBQUEsTUFDM0IsVUFBVSxDQUFDQyxVQUFTO0FBQ2xCLFlBQUlBLFVBQVMsT0FBVyxRQUFPLEtBQUs7QUFBQSxZQUMvQixNQUFLLFdBQVdBO0FBQUEsTUFDdkI7QUFBQSxNQUNBLFFBQVEsQ0FBQ0EsVUFBUztBQUNoQixhQUFLLE9BQU9BO0FBQUEsTUFDZDtBQUFBLE1BQ0EsSUFBSSxRQUFRO0FBQ1YsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE9BQU8sS0FBYSxPQUEwQjtBQUM1QyxVQUFNLE9BQU8sS0FBSyxXQUFXLEtBQUssQ0FBQyxjQUFjLFVBQVUsUUFBUSxPQUFPLFVBQVUsVUFBVSxRQUFRO0FBQ3RHLFFBQUksQ0FBQyxLQUFNO0FBQ1gsU0FBSyxRQUFRO0FBQ2IsU0FBSyxRQUFRLEtBQUssTUFBTTtBQUN4QixTQUFLLE9BQU8sVUFBVSxTQUFTLEVBQUUsSUFBSSxNQUFNLE1BQU0sS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLFNBQVMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLE1BQU0sTUFBTSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsR0FBRyxVQUFVLFNBQVMsU0FBUyxNQUFNO0FBQUEsRUFDaE47QUFBQTtBQUFBLEVBR0EsQ0FBQyxLQUFLLE1BQVksVUFBa0MsQ0FBQyxHQUF5QjtBQUM1RSxVQUFNLFNBQVMsS0FBSyxVQUFVLE1BQU0sT0FBTztBQUMzQyxXQUFPLE9BQU8sTUFBTTtBQUNsQixVQUFJLE9BQU8sVUFBVSxTQUFVLFFBQU8sS0FBSztBQUFBLElBQzdDLENBQUM7QUFDRCxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQSxFQUtBLENBQUMsT0FBK0IsUUFBYyxTQUEyQyxRQUFrRCxDQUFDLEdBQWlCO0FBQzNKLFFBQUksS0FBSyxPQUFRLE9BQU0sSUFBSSxNQUFNLHVDQUF1QztBQUN4RSxVQUFNLEtBQUssTUFBTSxNQUFNLFVBQVUsS0FBSyxLQUFLO0FBQzNDLFVBQU0sU0FBUyxLQUFLLE1BQU07QUFDMUIsVUFBTSxTQUFTLE9BQU8sUUFBVyxDQUFDLFNBQVM7QUFDekMsV0FBSyxTQUFTLEVBQUUsSUFBSSxRQUFRLFNBQVMsUUFBUSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksT0FBTyxJQUFJLE1BQU0sT0FBTyxLQUFLLEVBQUUsR0FBRyxRQUFRLEdBQUksTUFBTSxZQUFZLFNBQVksRUFBRSxXQUFXLEtBQUssTUFBTSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUNoTyxhQUFPLE1BQU07QUFDWCxZQUFJLEtBQUssUUFBUSxPQUFPLEdBQUksUUFBTyxLQUFLO0FBQUEsTUFDMUM7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUEsRUFHQSxPQUFPLFVBQWtCLFFBQWdCO0FBQ3ZDLFVBQU0sU0FBUyxLQUFLO0FBQ3BCLFFBQUksQ0FBQyxVQUFVLE9BQU8sT0FBTyxTQUFVLE9BQU0sSUFBSSxNQUFNLGtCQUFrQixRQUFRLEVBQUU7QUFDbkYsUUFBSSxDQUFDLE9BQU8sUUFBUSxLQUFLLENBQUMsY0FBYyxVQUFVLE9BQU8sTUFBTSxFQUFHLE9BQU0sSUFBSSxNQUFNLFVBQVUsUUFBUSxrQkFBa0IsTUFBTSxFQUFFO0FBQzlILFFBQUksT0FBTyxPQUFRLE9BQU0sSUFBSSxNQUFNLFVBQVUsUUFBUSx1QkFBdUI7QUFDNUUsV0FBTyxTQUFTO0FBQ2hCLFdBQU8sV0FBVyxLQUFLLE1BQU07QUFBQSxFQUMvQjtBQUFBLEVBRUEsSUFBSSxhQUFxQztBQUN2QyxXQUFPLEtBQUssU0FBUyxVQUFVLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFDaEQ7QUFBQTtBQUFBLEVBSUEsS0FBSyxNQUFrQixJQUFxQyxVQUE4RCxDQUFDLEdBQVc7QUFDcEksVUFBTSxRQUFRLEtBQUssTUFBTTtBQUN6QixVQUFNLE9BQW1CO0FBQUEsTUFDdkIsSUFBSSxLQUFLO0FBQUEsTUFDVDtBQUFBLE1BQ0EsR0FBRyxHQUFHO0FBQUEsTUFDTixHQUFHLEdBQUc7QUFBQSxNQUNOLEdBQUksV0FBVyxLQUFLLEVBQUUsUUFBUSxHQUFHLEdBQUcsSUFBSSxDQUFDO0FBQUEsTUFDekMsUUFBUSxRQUFRLFVBQVU7QUFBQSxNQUMxQixHQUFJLFFBQVEsVUFBVSxTQUFZLEVBQUUsT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsTUFDOUQ7QUFBQSxNQUNBLEdBQUksUUFBUSxTQUFTLFNBQVksRUFBRSxLQUFLLE1BQU0sT0FBTyxRQUFRLElBQUksRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxRTtBQUNBLFNBQUssUUFBUSxJQUFJLEtBQUssSUFBSSxJQUFJO0FBQzlCLFdBQU8sRUFBRSxJQUFJLEtBQUssSUFBSSxRQUFRLE1BQU0sS0FBSyxLQUFLLFFBQVEsT0FBTyxLQUFLLEVBQUUsR0FBRyxNQUFNLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRTtBQUFBLEVBQ2pJO0FBQUE7QUFBQSxFQUdBLENBQUMsT0FBTyxNQUFrQixJQUFxQyxVQUE2QyxDQUFDLEdBQXNCO0FBQ2pJLFVBQU0sU0FBUyxLQUFLLEtBQUssTUFBTSxJQUFJLE9BQU87QUFDMUMsV0FBTyxPQUFPLE9BQU8sTUFBTTtBQUMzQixXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUEsRUFHQSxLQUFLLE1BQWMsSUFBOEIsVUFBOEQsQ0FBQyxHQUFTO0FBQ3ZILFVBQU0sT0FBaUIsRUFBRSxJQUFJLEtBQUssT0FBTyxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sUUFBUSxTQUFTLEdBQUcsTUFBTSxRQUFRLFFBQVEsT0FBTyxHQUFJLFFBQVEsVUFBVSxTQUFZLEVBQUUsT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLEdBQUksT0FBTyxLQUFLLE1BQU0sRUFBRTtBQUMvTSxTQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSTtBQUM1QixVQUFNLFFBQVEsS0FBSztBQUNuQixVQUFNLFFBQVEsS0FBSztBQUNuQixXQUFPO0FBQUEsTUFDTCxJQUFJLEtBQUs7QUFBQSxNQUNULFFBQVEsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLLEVBQUU7QUFBQSxNQUN2QyxNQUFNLENBQUMsT0FBTztBQUNaLGFBQUssSUFBSSxHQUFHO0FBQ1osYUFBSyxJQUFJLEdBQUc7QUFBQSxNQUNkO0FBQUEsTUFDQSxJQUFJLE1BQU0sT0FBMkI7QUFDbkMsWUFBSSxVQUFVLEtBQUssTUFBTztBQUMxQixZQUFJLFVBQVUsT0FBVyxRQUFPLEtBQUs7QUFBQSxZQUNoQyxNQUFLLFFBQVE7QUFDbEIsYUFBSyxRQUFRLE1BQU07QUFBQSxNQUNyQjtBQUFBLE1BQ0EsSUFBSSxRQUFRO0FBQ1YsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLFdBQVcsT0FBMkI7QUFDcEMsZUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTyxLQUFJLENBQUMsU0FBUyxNQUFNLFNBQVMsS0FBSyxJQUFJLEVBQUcsTUFBSyxNQUFNLE9BQU8sRUFBRTtBQUFBLEVBQ3BHO0FBQUEsRUFFQSxNQUFNLE1BQVksSUFBcUMsVUFBOEQsQ0FBQyxHQUFHO0FBQ3ZILFVBQU0sUUFBUSxLQUFLLE1BQU07QUFDekIsU0FBSyxTQUFTLEtBQUssRUFBRSxJQUFJLEtBQUssT0FBTyxNQUFNLE9BQU8sUUFBUSxTQUFTLFdBQVcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBSSxXQUFXLEtBQUssRUFBRSxRQUFRLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBSSxPQUFPLEtBQUssTUFBTSxPQUFPLFFBQVEsUUFBUSxRQUFRLEdBQUcsQ0FBQyxHQUFHLE1BQU0sUUFBUSxRQUFRLEdBQUcsQ0FBQztBQUFBLEVBQ2pPO0FBQUEsRUFFQSxPQUFPLE1BQVksT0FBMkIsUUFBUTtBQUNwRCxVQUFNLFFBQVEsS0FBSyxNQUFNO0FBQ3pCLFNBQUssUUFBUSxLQUFLLEVBQUUsSUFBSSxLQUFLLE9BQU8sTUFBTSxNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sV0FBVyxFQUFFLENBQUM7QUFBQSxFQUN6RjtBQUFBO0FBQUEsRUFJQSxLQUFLLFFBQW9CO0FBQ3ZCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUE7QUFBQSxFQUdBLENBQUMsUUFBUSxRQUFxQztBQUM1QyxVQUFNLFNBQVMsS0FBSztBQUNwQixTQUFLLFNBQVM7QUFDZCxXQUFPLE9BQU8sTUFBTTtBQUNsQixVQUFJLEtBQUssV0FBVyxPQUFRLE1BQUssU0FBUztBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLFFBQWdCLE1BQWdCO0FBQ3BDLFVBQU0sUUFBUSxLQUFLLE1BQU07QUFDekIsU0FBSyxRQUFRLEVBQUUsUUFBUSxPQUFPLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtBQUFBLEVBQ3hEO0FBQUEsRUFFQSxhQUFhLElBQWE7QUFDeEIsUUFBSSxLQUFLLFVBQVUsT0FBTyxHQUFJO0FBQzlCLFNBQUssWUFBWSxFQUFFLElBQUksT0FBTyxLQUFLLE1BQU0sRUFBRTtBQUMzQyxRQUFJLENBQUMsR0FBSSxRQUFPLEtBQUs7QUFBQSxFQUN2QjtBQUFBO0FBQUEsRUFHQSxDQUFDLFlBQTZCO0FBQzVCLFNBQUssYUFBYSxJQUFJO0FBQ3RCLFdBQU8sT0FBTyxNQUFNLEtBQUssYUFBYSxLQUFLLENBQUM7QUFBQSxFQUM5QztBQUFBLEVBRUEsQ0FBQyxPQUFPLE9BQWUsTUFBaUM7QUFDdEQsVUFBTSxRQUFRLEtBQUssTUFBTTtBQUN6QixTQUFLLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxLQUFLLEdBQUcsSUFBSSxPQUFPLE9BQU8sS0FBSyxNQUFNLE9BQU8sSUFBSSxFQUFFO0FBQ3JGLFFBQUksT0FBTyxFQUFHLFFBQU8sS0FBSyxLQUFLLElBQUk7QUFBQSxFQUNyQztBQUFBLEVBRUEsSUFBSSxjQUFjO0FBQ2hCLFdBQU8sS0FBSyxVQUFVO0FBQUEsRUFDeEI7QUFBQTtBQUFBO0FBQUEsRUFLQSxJQUFJLFFBQVE7QUFDVixXQUFPLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEtBQUssVUFBVSxLQUFLLE1BQU0sV0FBVztBQUFBLEVBQ3JHO0FBQUEsRUFFQSxTQUFzQjtBQUNwQixXQUFPLEVBQUUsYUFBYSxDQUFDLEdBQUcsS0FBSyxZQUFZLE9BQU8sQ0FBQyxFQUFFLElBQUksVUFBUSxFQUFFLEdBQUcsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLEdBQUcsS0FBSyxLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxHQUFJLEtBQUssWUFBWSxTQUFZLEVBQUUsU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDLEdBQUksV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEdBQUcsTUFBTSxFQUFFLEdBQUcsS0FBSyxLQUFLLEdBQUcsUUFBUSxLQUFLLE9BQU87QUFBQSxFQUN2VDtBQUFBLEVBRUEsUUFBUSxRQUFxQjtBQUMzQixTQUFLLFlBQVksTUFBTTtBQUN2QixlQUFXLE9BQU8sT0FBTyxlQUFlLENBQUMsRUFBRyxNQUFLLFlBQVksSUFBSSxJQUFJLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztBQUN2RixTQUFLLE1BQU0sTUFBTTtBQUNqQixlQUFXLENBQUMsUUFBUSxJQUFJLEtBQUssT0FBTyxNQUFPLE1BQUssTUFBTSxJQUFJLFFBQVEsSUFBSTtBQUN0RSxTQUFLLE1BQU0sTUFBTTtBQUNqQixlQUFXLFFBQVEsT0FBTyxNQUFPLE1BQUssTUFBTSxJQUFJLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDO0FBQ3BFLFNBQUssTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLEdBQUcsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDeEUsUUFBSSxPQUFPLFlBQVksT0FBVyxNQUFLLFVBQVUsT0FBTztBQUN4RCxTQUFLLFlBQVksRUFBRSxHQUFHLE9BQU8sVUFBVTtBQUN2QyxTQUFLLE9BQU8sRUFBRSxHQUFHLE9BQU8sS0FBSztBQUM3QixTQUFLLFNBQVMsT0FBTztBQUFBLEVBQ3ZCO0FBQUE7QUFBQSxFQUdBLE9BQU87QUFDTCxVQUFNLE1BQU0sS0FBSyxNQUFNO0FBQ3ZCLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxLQUFLLFlBQWEsS0FBSSxNQUFNLElBQUksT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssTUFBTSxNQUFNLEVBQUcsTUFBSyxZQUFZLE9BQU8sTUFBTTtBQUNwSSxlQUFXLENBQUMsV0FBVyxNQUFNLEtBQUssQ0FBQyxHQUFHLEtBQUssUUFBUSxHQUFHO0FBQ3BELFVBQUksT0FBTyxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFHO0FBQ3BELFdBQUssU0FBUyxPQUFPLFNBQVM7QUFDOUIsYUFBTyxLQUFLO0FBQ1osV0FBSyxVQUFVLFNBQVM7QUFBQSxJQUMxQjtBQUNBLGVBQVcsYUFBYSxDQUFDLEdBQUcsS0FBSyxPQUFPLEtBQUssQ0FBQyxFQUFHLE1BQUssVUFBVSxTQUFTO0FBQ3pFLFFBQUksS0FBSyxRQUFRLGFBQWEsVUFBYSxNQUFNLEtBQUssT0FBTyxZQUFZLGVBQWU7QUFDdEYsWUFBTSxFQUFFLE1BQU0sT0FBTyxJQUFJLEtBQUs7QUFDOUIsYUFBTyxLQUFLO0FBQ1osYUFBTyxNQUFPO0FBQUEsSUFDaEI7QUFDQSxhQUFTLFFBQVEsS0FBSyxXQUFXLFNBQVMsR0FBRyxTQUFTLEdBQUcsU0FBUyxHQUFHO0FBQ25FLFlBQU0sWUFBWSxLQUFLLFdBQVcsS0FBSztBQUN2QyxVQUFJLFVBQVUsVUFBVSxZQUFZLE1BQU0sVUFBVSxTQUFTLGlCQUFrQixNQUFLLFdBQVcsT0FBTyxPQUFPLENBQUM7QUFBQSxJQUNoSDtBQUNBLGVBQVcsQ0FBQyxJQUFJLE1BQU0sS0FBSyxLQUFLLFFBQVMsS0FBSSxPQUFPLFFBQVEsVUFBYSxPQUFPLE9BQU8sSUFBSyxNQUFLLFFBQVEsT0FBTyxFQUFFO0FBQ2xILFNBQUssV0FBVyxLQUFLLFNBQVMsT0FBTyxDQUFDLFlBQVksUUFBUSxNQUFNLEdBQUc7QUFDbkUsU0FBSyxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUMsV0FBVyxPQUFPLE1BQU0sR0FBRztBQUMvRCxRQUFJLEtBQUssU0FBUyxLQUFLLE1BQU0sT0FBTyxJQUFLLFFBQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQUEsRUFFQSxPQUFrQjtBQUNoQixVQUFNLE9BQU8sS0FBSyxNQUFNO0FBQ3hCLFVBQU0sYUFBc0MsQ0FBQztBQUM3QyxlQUFXLENBQUMsUUFBUSxJQUFJLEtBQUssS0FBSyxPQUFPO0FBQ3ZDLFlBQU0sUUFBUSxLQUFLLFNBQVMsTUFBTTtBQUNsQyxpQkFBVyxNQUFNLElBQUksRUFBRSxNQUFNLEtBQUssTUFBTSxPQUFPLEtBQUssT0FBTyxHQUFJLFVBQVUsU0FBWSxFQUFFLE1BQU0sSUFBSSxDQUFDLEVBQUc7QUFBQSxJQUN2RztBQUNBLFVBQU0sUUFBUSxLQUFLLFlBQVk7QUFDL0IsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLEdBQUksS0FBSyxZQUFZLE9BQU8sRUFBRSxhQUFhLENBQUMsR0FBRyxLQUFLLFlBQVksT0FBTyxDQUFDLEVBQUUsSUFBSSxVQUFRLEVBQUUsR0FBRyxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUM7QUFBQSxNQUN4RyxPQUFPLENBQUMsR0FBRyxLQUFLLFNBQVMsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxHQUFHLE9BQU8sS0FBSyxFQUFFO0FBQUEsTUFDdkUsR0FBSSxLQUFLLFlBQVksRUFBRSxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVUsRUFBRSxJQUFJLENBQUM7QUFBQSxNQUM3RCxHQUFJLEtBQUssWUFBWSxFQUFFLE9BQU8sRUFBRSxHQUFHLEtBQUssVUFBVSxFQUFFLElBQUksQ0FBQztBQUFBLE1BQ3pELFlBQVksS0FBSyxXQUFXLElBQUksQ0FBQyxlQUFlLEVBQUUsR0FBRyxVQUFVLEVBQUU7QUFBQSxNQUNqRSxHQUFJLEtBQUssU0FBUyxFQUFFLFFBQVEsVUFBVSxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUM7QUFBQSxNQUN4RCxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVU7QUFBQSxNQUMvQixNQUFNLEVBQUUsR0FBRyxLQUFLLEtBQUs7QUFBQSxNQUNyQixTQUFTLENBQUMsR0FBRyxLQUFLLFFBQVEsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsS0FBSyxPQUFPLE1BQU0sQ0FBQztBQUFBLE1BQ3ZFLE9BQU8sQ0FBQyxHQUFHLEtBQUssTUFBTSxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLEdBQUcsS0FBSyxFQUFFO0FBQUEsTUFDM0QsVUFBVSxLQUFLLFNBQVMsSUFBSSxDQUFDLFlBQVksS0FBSyxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQzdELFNBQVMsS0FBSyxRQUFRLElBQUksQ0FBQyxZQUFZLEVBQUUsR0FBRyxPQUFPLEVBQUU7QUFBQSxNQUNyRDtBQUFBLE1BQ0EsR0FBSSxRQUFRLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFBQSxNQUN6QixRQUFRLEtBQUs7QUFBQSxNQUNiLEdBQUksS0FBSyxRQUFRLEVBQUUsT0FBTyxFQUFFLEdBQUcsS0FBSyxNQUFNLEVBQUUsSUFBSSxDQUFDO0FBQUEsTUFDakQsR0FBSSxLQUFLLFVBQVUsRUFBRSxTQUFTLEtBQUssUUFBUSxJQUFJLENBQUM7QUFBQSxNQUNoRCxHQUFJLEtBQUssWUFBWSxTQUFZLEVBQUUsU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDO0FBQUEsSUFDaEU7QUFBQSxFQUNGO0FBQUEsRUFFQSxVQUFVLElBQVk7QUFDcEIsVUFBTSxFQUFFLE1BQU0sSUFBSSxPQUFPLElBQUksSUFBSSxLQUFLO0FBQ3RDLFFBQUksTUFBTSxJQUFLLFFBQU87QUFDdEIsUUFBSSxNQUFNLE1BQU8sUUFBTztBQUN4QixXQUFPLFFBQVMsS0FBSyxTQUFTLEtBQUssU0FBVSxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUs7QUFBQSxFQUN0RTtBQUFBO0FBQUEsRUFHUSxPQUE0RCxNQUFZO0FBQzlFLFFBQUksQ0FBQyxLQUFLLE9BQVEsUUFBTyxFQUFFLEdBQUcsS0FBSztBQUNuQyxVQUFNLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLEtBQUssTUFBTTtBQUM3RSxRQUFJLE1BQU07QUFDUixXQUFLLElBQUksS0FBSztBQUNkLFdBQUssSUFBSSxLQUFLO0FBQUEsSUFDaEI7QUFDQSxXQUFPLEVBQUUsR0FBRyxLQUFLO0FBQUEsRUFDbkI7QUFBQSxFQUVBLENBQVMsS0FBSyxNQUFpQztBQUM3QyxVQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sR0FBRyxJQUFJO0FBQ3BDLFdBQU8sUUFBYyxDQUFDLFNBQVM7QUFDN0IsWUFBTSxPQUFPLEVBQUUsTUFBTSxNQUFNLEtBQUssT0FBTyxNQUFTLEdBQUcsSUFBSTtBQUN2RCxXQUFLLE1BQU0sS0FBSyxJQUFJO0FBQ3BCLGFBQU8sTUFBTTtBQUNYLGNBQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxJQUFJO0FBQ3JDLFlBQUksU0FBUyxFQUFHLE1BQUssTUFBTSxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQzVDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUEsRUFHQSxlQUFlO0FBQ2IsVUFBTSxNQUFNLEtBQUssTUFBTTtBQUN2QixlQUFXLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxjQUFjLFVBQVUsT0FBTyxHQUFHLEVBQUcsTUFBSyxLQUFLO0FBQUEsRUFDdkY7QUFBQSxFQUVRLFFBQVEsV0FBbUIsTUFBWSxNQUE2QztBQUMxRixVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksU0FBUztBQUNyQyxXQUFPLEVBQUUsSUFBSSxLQUFLLE9BQU8sV0FBVyxNQUFNLE1BQU0sUUFBUSxJQUFJLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxLQUFLO0FBQUEsRUFDMUc7QUFBQSxFQUVRLFFBQVEsV0FBbUI7QUFDakMsUUFBSSxRQUFRLEtBQUssT0FBTyxJQUFJLFNBQVM7QUFDckMsUUFBSSxDQUFDLE9BQU87QUFDVixjQUFRLENBQUM7QUFDVCxXQUFLLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFBQSxJQUNsQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxVQUFVLFdBQW1CO0FBQ25DLFFBQUksS0FBSyxTQUFTLElBQUksU0FBUyxFQUFHO0FBQ2xDLFVBQU0sUUFBUSxLQUFLLE9BQU8sSUFBSSxTQUFTO0FBQ3ZDLFFBQUksQ0FBQyxNQUFPO0FBQ1osUUFBSSxDQUFDLEtBQUssTUFBTSxTQUFTLEdBQUc7QUFDMUIsV0FBSyxPQUFPLE9BQU8sU0FBUztBQUM1QixpQkFBVyxXQUFXLE1BQU8sU0FBUSxLQUFLO0FBQzFDO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxNQUFNLE1BQU07QUFDekIsUUFBSSxNQUFNLFdBQVcsRUFBRyxNQUFLLE9BQU8sT0FBTyxTQUFTO0FBQ3BELFFBQUksQ0FBQyxLQUFNO0FBQ1gsVUFBTSxRQUFRLEtBQUssTUFBTTtBQUN6QixTQUFLLFNBQVMsSUFBSSxXQUFXLEVBQUUsTUFBTSxFQUFFLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBRyxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQ2pJLFFBQUksS0FBSyxVQUFVLEdBQUksTUFBSyxVQUFVO0FBQUEsRUFDeEM7QUFBQTtBQUFBLEVBR1EsU0FBUyxXQUFtQixTQUFrQjtBQUNwRCxVQUFNLFFBQVEsS0FBSyxPQUFPLElBQUksU0FBUztBQUN2QyxVQUFNLFFBQVEsT0FBTyxRQUFRLE9BQU8sS0FBSztBQUN6QyxRQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLFlBQU0sT0FBTyxPQUFPLENBQUM7QUFDckI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLEtBQUssU0FBUyxJQUFJLFNBQVM7QUFDMUMsUUFBSSxVQUFVLE9BQU8sS0FBSyxPQUFPLFFBQVEsS0FBSyxJQUFJO0FBQ2hELFdBQUssU0FBUyxPQUFPLFNBQVM7QUFDOUIsV0FBSyxVQUFVLFNBQVM7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUVRLE1BQU0sUUFBZ0I7QUFDNUIsV0FBTyxLQUFLLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sVUFBVSxLQUFLLEtBQUssQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFlQSxTQUFTLEtBQUssTUFBcUI7QUFDakMsU0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLEtBQUs7QUFDaEQ7QUFFQSxTQUFTLE1BQU0sTUFBWTtBQUN6QixTQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sS0FBSztBQUNoRDtBQUVBLFNBQVMsUUFBUSxNQUFZO0FBQzNCLFNBQU8sT0FBTyxTQUFTLFdBQVcsT0FBUSxLQUFLLE1BQU0sS0FBSztBQUM1RDtBQUVBLFNBQVMsVUFBVSxRQUFxRDtBQUN0RSxRQUFNLEVBQUUsTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJO0FBQ2pDLFNBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDLFlBQVksRUFBRSxHQUFHLE9BQU8sRUFBRSxFQUFFO0FBQzNFOyIsIm5hbWVzIjpbInVuaXQiLCJ0ZXh0Il19