export const CELL_GROUND = {
  ".": { land: true, sea: false, pace: 1, drag: 1 },
  ",": { land: true, sea: true, pace: 0.75, drag: 1.6 },
  m: { land: true, sea: false, pace: 0.6, drag: 2 },
  "=": { land: true, sea: false, pace: 1, drag: 1 },
  T: { land: false, sea: false, pace: 0, drag: 1 },
  "#": { land: false, sea: false, pace: 0, drag: 1 },
  "~": { land: false, sea: true, pace: 0, drag: 1 }
};
const PASSABLE = {
  land: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].land)),
  sea: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].sea))
};
const UNREACHED = 1073741823;
const UNKNOWN = -2;
const STRAIGHT = 5;
const DIAGONAL = 7;
const LOOKAHEAD = 16;
const SHORT_LOOK = 3;
const FIELD_CACHE = 128;
const GOAL_FIELD_CACHE = 8192;
const SECTOR = 10;
const MAX_REGIONS = 64;
const GROUND_WEIGHT = 4;
const BUCKETS = 64;
const GOAL_REACH = 3;
export function terrainCellKind(char) {
  if (char === ",") return "shallow";
  if (char === "m") return "mud";
  if (char === "=") return "bridge";
  if (char === "T") return "forest";
  if (char === "#") return "rock";
  if (char === "~") return "water";
  return "ground";
}
export function isWalkableChar(char) {
  return char !== void 0 && PASSABLE.land.has(char);
}
export function isWalkable(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
export function isOpenGround(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = routing(map, terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
export function openStep(map, from, to, mover = "land") {
  if (isOpenGround(map, to.x, to.y, mover) || !isOpenGround(map, from.x, from.y, mover)) return to;
  if (isOpenGround(map, to.x, from.y, mover)) return { x: to.x, y: from.y };
  if (isOpenGround(map, from.x, to.y, mover)) return { x: from.x, y: to.y };
  return { x: from.x, y: from.y };
}
export function openGroundNear(map, point, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return void 0;
  const state = routing(map, terrain, mover);
  const at = padAt(state, point.x, point.y);
  const near = at < 0 ? -1 : nearestWalkable(state, at);
  return near < 0 ? void 0 : centerOf(state, near);
}
const BARE_GROUND = { pace: 1, drag: 1 };
export function groundUnder(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain || mover === "sea") return BARE_GROUND;
  const index = cellIndexAt(terrain, x, y);
  const ground = index < 0 ? void 0 : CELL_GROUND[terrain.cells[index]];
  return ground && ground.land ? ground : BARE_GROUND;
}
export function cellIndexAt(terrain, x, y) {
  const col = Math.floor(x / terrain.cell);
  const row = Math.floor(y / terrain.cell);
  if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return -1;
  return row * terrain.cols + col;
}
export function cellCenter(terrain, index) {
  const col = index % terrain.cols;
  const row = (index - col) / terrain.cols;
  return { x: (col + 0.5) * terrain.cell, y: (row + 0.5) * terrain.cell };
}
export function isFootprintBuildable(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, "land");
  return everyFootprintCell(terrain, x, y, radius, (at, cell) => state.walk[at] === 1 && terrain.cells[cell] !== "," && terrain.levels?.[cell] !== "2");
}
export function isShoreFootprint(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return false;
  const land = runtime(terrain, "land");
  const sea = runtime(terrain, "sea");
  const { labels, deep } = wholesOf(sea);
  let dry = false;
  let wet = false;
  const fits = everyFootprintCell(terrain, x, y, radius, (at, cell) => {
    if (land.walk[at] === 1) dry = true;
    if (sea.walk[at] === 1 && deep[labels[at]] >= OPEN_WATER) wet = true;
    return (sea.walk[at] === 1 || land.walk[at] === 1) && terrain.levels?.[cell] !== "2";
  });
  return fits && dry && wet;
}
export const OPEN_WATER = 64;
export function shoreSpots(map, radius) {
  const terrain = map.terrain;
  if (!terrain) return [];
  const sea = runtime(terrain, "sea");
  const known = (sea.shores ??= /* @__PURE__ */ new Map()).get(radius);
  if (known) return known;
  const spots = [];
  const { labels, deep } = wholesOf(sea);
  if (deep.some((cells) => cells >= OPEN_WATER)) {
    const land = runtime(terrain, "land"), width = terrain.cols + 1;
    const dry = new Uint32Array(width * (terrain.rows + 1));
    const wet = new Uint32Array(dry.length), blocked = new Uint32Array(dry.length);
    for (let row = 0; row < terrain.rows; row++) {
      let d = 0, w = 0, b = 0;
      for (let col = 0; col < terrain.cols; col++) {
        const cell = row * terrain.cols + col, at = (row + 1) * (terrain.cols + 2) + col + 1;
        d += land.walk[at] === 1 ? 1 : 0;
        w += sea.walk[at] === 1 && deep[labels[at]] >= OPEN_WATER ? 1 : 0;
        b += land.walk[at] !== 1 && sea.walk[at] !== 1 || terrain.levels?.[cell] === "2" ? 1 : 0;
        const out = (row + 1) * width + col + 1;
        dry[out] = dry[out - width] + d;
        wet[out] = wet[out - width] + w;
        blocked[out] = blocked[out - width] + b;
      }
    }
    const half = footprintHalf(radius, terrain.cell);
    const first = Math.ceil((terrain.cell / 2 - half) / terrain.cell - 0.5);
    const last = Math.ceil((terrain.cell / 2 + half) / terrain.cell - 0.5) - 1;
    const total = (field, left, top, right, bottom) => field[bottom * width + right] - field[top * width + right] - field[bottom * width + left] + field[top * width + left];
    for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
      const col = index % terrain.cols, row = Math.floor(index / terrain.cols);
      const left = col + first, top = row + first, right = col + last + 1, bottom = row + last + 1;
      if (left < 0 || top < 0 || right > terrain.cols || bottom > terrain.rows) continue;
      if (!total(blocked, left, top, right, bottom) && total(dry, left, top, right, bottom) && total(wet, left, top, right, bottom))
        spots.push(cellCenter(terrain, index));
    }
  }
  sea.shores.set(radius, spots);
  return spots;
}
export function footprintHalf(radius, cell) {
  return Math.ceil(2 * radius / cell) * cell / 2;
}
export function snapToFootprint(map, radius, point) {
  const terrain = map.terrain;
  if (!terrain) return { x: point.x, y: point.y };
  const cell = terrain.cell;
  const offset = Math.ceil(2 * radius / cell) % 2 === 1 ? cell / 2 : 0;
  return { x: Math.round((point.x - offset) / cell) * cell + offset, y: Math.round((point.y - offset) / cell) * cell + offset };
}
export function footprintCells(cell, x, y, radius) {
  const half = footprintHalf(radius, cell);
  const first = (from) => Math.ceil(from / cell - 0.5);
  return { left: first(x - half), right: first(x + half) - 1, top: first(y - half), bottom: first(y + half) - 1 };
}
function everyFootprintCell(terrain, x, y, radius, passes) {
  const size = terrain.cell;
  const width = terrain.cols + 2;
  const { left, right, top, bottom } = footprintCells(size, x, y, radius);
  for (let row = top; row <= bottom; row += 1) {
    for (let col = left; col <= right; col += 1) {
      if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return false;
      if (!passes((row + 1) * width + col + 1, row * terrain.cols + col)) return false;
    }
  }
  return true;
}
export function walkableGoal(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return { x, y };
  const state = runtime(terrain, mover);
  const cx = Math.min(Math.max(x, 0), map.width);
  const cy = Math.min(Math.max(y, 0), map.height);
  const at = padAt(state, Math.min(cx, terrain.cols * terrain.cell - 1e-3), Math.min(cy, terrain.rows * terrain.cell - 1e-3));
  if (state.walk[at] === 1) return { x: cx, y: cy };
  const nearest = nearestWalkable(state, at);
  return nearest < 0 ? { x: cx, y: cy } : centerOf(state, nearest);
}
export function segmentWalkable(map, a, b, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  return clearSegment(routing(map, terrain, mover), a.x, a.y, b.x, b.y);
}
export function steerPoint(map, from, goal, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return goal;
  const ground = runtime(terrain, mover);
  const state = routing(map, terrain, mover);
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (start < 0 || target < 0 || ground.walk[target] !== 1) return goal;
  if (clearSegment(state, from.x, from.y, goal.x, goal.y)) return goal;
  const near = nearestWalkable(state, start);
  if (near < 0) return goal;
  if (near !== start && ground.walk[start] !== 1) return centerOf(state, near);
  const tiles = tilesOf(state);
  const aim = reachableTarget(state, ground, tiles, near, target);
  return walkAhead(state, ground, tiles, from, near, aim, aim === target ? goal : centerOf(state, aim));
}
export function walkDestination(map, from, goal, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return goal;
  const ground = runtime(terrain, mover);
  const state = routing(map, terrain, mover);
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (start < 0 || target < 0 || ground.walk[target] !== 1) return goal;
  const near = nearestWalkable(state, start);
  if (near < 0) return goal;
  const tiles = tilesOf(state);
  const aim = reachableTarget(state, ground, tiles, near, target);
  if (state.walk[aim] === 1) return aim === target ? goal : centerOf(state, aim);
  const field = goalFieldOf(state, ground, tiles, aim).field;
  const index = local(field.box, near, state.width);
  if (index < 0 || field.dist[index] >= UNREACHED) return goal;
  let at = near;
  for (let next = downhill(state, field, at); next >= 0; next = downhill(state, field, at)) at = next;
  return centerOf(state, at);
}
function walkAhead(state, ground, tiles, from, near, target, goal) {
  let at = near;
  let short = -1;
  let way = wayAt(state, ground, tiles, at, target);
  for (let step = 1; step <= LOOKAHEAD && way; step += 1) {
    let next = downhill(state, way.field, at);
    if (next < 0) {
      if (!way.exit) break;
      const nearer = wayAt(state, ground, tiles, at, target);
      if (nearer && !nearer.exit) {
        way = nearer;
        next = downhill(state, way.field, at);
        if (next < 0) break;
      } else {
        next = at + way.exit.across;
        if (state.walk[next] !== 1) break;
        way = wayAt(state, ground, tiles, next, target);
      }
    }
    at = next;
    if (step === SHORT_LOOK) short = at;
    if (way && !way.exit && way.field.dist[local(way.field.box, at, state.width)] === 0) break;
  }
  if (at === near) return near === target ? goal : centerOf(state, near);
  const far = at === target ? goal : centerOf(state, at);
  if (short < 0 || clearSegment(state, from.x, from.y, far.x, far.y)) return far;
  return short === target ? goal : centerOf(state, short);
}
function wayAt(state, ground, tiles, at, target) {
  const goal = goalFieldOf(state, ground, tiles, target);
  const index = local(goal.field.box, at, state.width);
  if (index >= 0 && goal.field.dist[index] < UNREACHED) return { field: goal.field };
  const exit = exitFor(state, tiles, tiles.region[at], target, goal.field);
  if (!exit || exit.field.dist[local(exit.field.box, at, state.width)] >= UNREACHED) return void 0;
  return { field: exit.field, exit };
}
function tilesOf(state) {
  if (state.tiles) return state.tiles;
  const { terrain } = state;
  const columns = Math.ceil(terrain.cols / SECTOR);
  const rows = Math.ceil(terrain.rows / SECTOR);
  const tiles = {
    columns,
    rows,
    nodes: /* @__PURE__ */ new Map(),
    borders: /* @__PURE__ */ new Map(),
    region: new Int32Array(state.walk.length).fill(-1),
    island: new Int32Array(state.walk.length).fill(-1),
    goals: /* @__PURE__ */ new Map(),
    exits: /* @__PURE__ */ new Map(),
    nearest: /* @__PURE__ */ new Map()
  };
  state.tiles = tiles;
  const all = Array.from({ length: columns * rows }, (_, sector) => sector);
  for (const sector of all) labelRegions(state, tiles, sector);
  for (const sector of all) for (const lower of [0, 1]) layWindows(state, tiles, sector * 2 + lower);
  for (const sector of all) linkSector(state, tiles, sector);
  labelIslands(state, tiles);
  return tiles;
}
function redoTiles(state, tiles, dirty) {
  const sectors = [...dirty].sort((a, b) => a - b);
  const touched = /* @__PURE__ */ new Set();
  const borders = /* @__PURE__ */ new Set();
  for (const sector of sectors) {
    labelRegions(state, tiles, sector);
    const col = sector % tiles.columns;
    const row = Math.floor(sector / tiles.columns);
    touched.add(sector);
    for (const lower of [0, 1]) borders.add(sector * 2 + lower);
    if (col > 0) {
      borders.add((sector - 1) * 2);
      touched.add(sector - 1);
    }
    if (row > 0) {
      borders.add((sector - tiles.columns) * 2 + 1);
      touched.add(sector - tiles.columns);
    }
    if (col + 1 < tiles.columns) touched.add(sector + 1);
    if (row + 1 < tiles.rows) touched.add(sector + tiles.columns);
  }
  for (const border of [...borders].sort((a, b) => a - b)) {
    for (const key of tiles.borders.get(border) ?? []) {
      tiles.nodes.delete(key);
      tiles.nodes.delete(key ^ 1);
    }
    layWindows(state, tiles, border);
  }
  for (const sector of [...touched].sort((a, b) => a - b)) linkSector(state, tiles, sector);
  labelIslands(state, tiles);
  for (const target of [...tiles.goals.keys()]) {
    const sector = sectorOf(state, tiles, target);
    const near = sectors.some((dirty2) => Math.abs(dirty2 % tiles.columns - sector % tiles.columns) <= 2 && Math.abs(Math.floor(dirty2 / tiles.columns) - Math.floor(sector / tiles.columns)) <= 2);
    if (near) tiles.goals.delete(target);
  }
  tiles.exits.clear();
  tiles.nearest.clear();
}
function sectorBox(state, tiles, sector) {
  const col = sector % tiles.columns * SECTOR;
  const row = Math.floor(sector / tiles.columns) * SECTOR;
  return { left: col + 1, top: row + 1, width: Math.min(SECTOR, state.terrain.cols - col), height: Math.min(SECTOR, state.terrain.rows - row) };
}
function sectorOf(state, tiles, at) {
  const col = at % state.width - 1;
  const row = Math.floor(at / state.width) - 1;
  return Math.floor(row / SECTOR) * tiles.columns + Math.floor(col / SECTOR);
}
function local(box, at, width) {
  const col = at % width;
  const row = (at - col) / width;
  if (col < box.left || row < box.top || col >= box.left + box.width || row >= box.top + box.height) return -1;
  return (row - box.top) * box.width + (col - box.left);
}
function labelRegions(state, tiles, sector) {
  const { walk, offsets, width } = state;
  const box = sectorBox(state, tiles, sector);
  for (let row = box.top; row < box.top + box.height; row += 1) for (let col = box.left; col < box.left + box.width; col += 1) tiles.region[row * width + col] = -1;
  let count = 0;
  for (let row = box.top; row < box.top + box.height; row += 1) {
    for (let col = box.left; col < box.left + box.width; col += 1) {
      const seed = row * width + col;
      if (walk[seed] !== 1 || tiles.region[seed] !== -1) continue;
      const label = sector * MAX_REGIONS + Math.min(count, MAX_REGIONS - 1);
      count += 1;
      tiles.region[seed] = label;
      for (let index = 0, queue = [seed]; index < queue.length; index += 1) {
        const at = queue[index];
        for (let direction = 0; direction < 8; direction += 1) {
          const next = at + offsets[direction];
          if (walk[next] !== 1 || tiles.region[next] !== -1 || local(box, next, width) < 0 || !stepAllowed(state, at, direction)) continue;
          tiles.region[next] = label;
          queue.push(next);
        }
      }
    }
  }
}
function labelIslands(state, tiles) {
  const { walk, offsets } = state;
  tiles.island.fill(-1);
  const queue = new Int32Array(walk.length);
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || tiles.island[seed] !== -1) continue;
    tiles.island[seed] = seed;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at + offsets[direction];
        if (walk[next] !== 1 || tiles.island[next] !== -1 || !stepAllowed(state, at, direction)) continue;
        tiles.island[next] = seed;
        queue[tail++] = next;
      }
    }
  }
}
function layWindows(state, tiles, border) {
  const sector = border >> 1;
  const lower = border & 1;
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [];
  tiles.borders.set(border, keys);
  if (lower ? row + 1 >= tiles.rows : col + 1 >= tiles.columns) return;
  const { walk, width } = state;
  const box = sectorBox(state, tiles, sector);
  const across = lower ? width : 1;
  const span = lower ? box.width : box.height;
  const first = lower ? (box.top + box.height - 1) * width + box.left : box.top * width + box.left + box.width - 1;
  const along = lower ? 1 : width;
  let run = [];
  const close = () => {
    if (run.length === 0) return;
    const key = run[0] * 4 + lower * 2;
    keys.push(key);
    const blank = () => ({ box, dist: new Int32Array(0), next: new Int32Array(0) });
    tiles.nodes.set(key, { key, sector, cells: run, across, field: blank(), edges: [] });
    const other = lower ? sector + tiles.columns : sector + 1;
    tiles.nodes.set(key + 1, { key: key + 1, sector: other, cells: run.map((cell) => cell + across), across: -across, field: blank(), edges: [] });
    run = [];
  };
  for (let step = 0; step < span; step += 1) {
    const at = first + step * along;
    if (walk[at] === 1 && walk[at + across] === 1) run.push(at);
    else close();
  }
  close();
}
function sectorNodes(tiles, sector) {
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [...tiles.borders.get(sector * 2) ?? [], ...tiles.borders.get(sector * 2 + 1) ?? []];
  if (col > 0) keys.push(...(tiles.borders.get((sector - 1) * 2) ?? []).map((key) => key + 1));
  if (row > 0) keys.push(...(tiles.borders.get((sector - tiles.columns) * 2 + 1) ?? []).map((key) => key + 1));
  return keys.sort((a, b) => a - b).map((key) => tiles.nodes.get(key));
}
function linkSector(state, tiles, sector) {
  const box = sectorBox(state, tiles, sector);
  const nodes = sectorNodes(tiles, sector);
  for (const node of nodes) node.field = growBox(state, box, node.cells);
  for (const from of nodes) {
    from.edges = [];
    for (const to of nodes) {
      if (to === from) continue;
      let cost = UNREACHED;
      for (const cell of from.cells) cost = Math.min(cost, to.field.dist[local(box, cell, state.width)]);
      if (cost < UNREACHED) from.edges.push({ to: to.key, cost });
    }
  }
}
const STEP_COLS = [1, 0, -1, 0, 1, -1, -1, 1];
const STEP_ROWS = [0, 1, 0, -1, 1, 1, -1, -1];
function growBox(state, box, seeds, costs) {
  const size = box.width * box.height;
  return growBoxInto(state, box, seeds, costs, { dist: new Int32Array(size), next: new Int32Array(size) });
}
function growBoxInto(state, box, seeds, costs, arrays) {
  const { walk, offsets, width, weight } = state;
  const columns = box.width;
  const rows = box.height;
  const origin = box.top * width + box.left;
  const { dist, next } = arrays;
  dist.fill(UNREACHED);
  next.fill(UNKNOWN);
  const buckets = state.boxBuckets;
  const order = seeds.map((_, index) => index);
  if (costs) order.sort((a, b) => costs[a] - costs[b] || a - b);
  const costOf = (index) => costs ? costs[order[index]] : 0;
  let seeded = 0;
  let pending = 0;
  for (let cost = order.length > 0 ? costOf(0) : 0; pending > 0 || seeded < order.length; cost += 1) {
    if (pending === 0) cost = costOf(seeded);
    for (; seeded < order.length && costOf(seeded) === cost; seeded += 1) {
      const index = local(box, seeds[order[seeded]], width);
      if (index < 0 || cost >= dist[index]) continue;
      dist[index] = cost;
      buckets[cost % BUCKETS].push(index);
      pending += 1;
    }
    const bucket = buckets[cost % BUCKETS];
    while (bucket.length > 0) {
      const index = bucket.pop();
      pending -= 1;
      if (dist[index] !== cost) continue;
      const col = index % columns;
      const row = (index - col) / columns;
      const at = origin + row * width + col;
      for (let direction = 0; direction < 8; direction += 1) {
        const stepCol = col + STEP_COLS[direction];
        const stepRow = row + STEP_ROWS[direction];
        if (stepCol < 0 || stepRow < 0 || stepCol >= columns || stepRow >= rows) continue;
        const step = at + offsets[direction];
        if (walk[step] !== 1) continue;
        const there = stepRow * columns + stepCol;
        const reached = cost + (direction < 4 ? STRAIGHT : DIAGONAL) * weight[step];
        if (reached >= dist[there] || !stepAllowed(state, at, direction)) continue;
        dist[there] = reached;
        buckets[reached % BUCKETS].push(there);
        pending += 1;
      }
    }
  }
  return { box, dist, next };
}
function downhill(state, field, at) {
  const { walk, offsets, width } = state;
  const { box } = field;
  const index = local(box, at, width);
  if (index < 0) return -1;
  const known = field.next[index];
  if (known !== UNKNOWN) return known;
  const col = index % box.width;
  const row = (index - col) / box.width;
  let best = -1;
  let bestCost = field.dist[index];
  for (let direction = 0; direction < 8; direction += 1) {
    const stepCol = col + STEP_COLS[direction];
    const stepRow = row + STEP_ROWS[direction];
    if (stepCol < 0 || stepRow < 0 || stepCol >= box.width || stepRow >= box.height) continue;
    const step = at + offsets[direction];
    const there = stepRow * box.width + stepCol;
    if (walk[step] !== 1 || field.dist[there] >= bestCost || !stepAllowed(state, at, direction)) continue;
    bestCost = field.dist[there];
    best = step;
  }
  field.next[index] = best;
  return best;
}
function goalFieldOf(state, ground, tiles, target) {
  const known = tiles.goals.get(target);
  if (known) {
    tiles.goals.delete(target);
    tiles.goals.set(target, known);
    return known;
  }
  const sector = sectorOf(state, tiles, target);
  const col = sector % tiles.columns * SECTOR;
  const row = Math.floor(sector / tiles.columns) * SECTOR;
  const left = Math.max(0, col - SECTOR);
  const top = Math.max(0, row - SECTOR);
  const box = { left: left + 1, top: top + 1, width: Math.min(state.terrain.cols, col + 2 * SECTOR) - left, height: Math.min(state.terrain.rows, row + 2 * SECTOR) - top };
  const { seeds, costs } = goalSeeds(state, ground, target, box);
  const goal = { field: growBox(state, box, seeds, costs), seeds };
  if (tiles.goals.size >= GOAL_FIELD_CACHE) tiles.goals.delete(tiles.goals.keys().next().value);
  tiles.goals.set(target, goal);
  return goal;
}
function goalSeeds(state, ground, target, box) {
  if (state.walk[target] === 1) return { seeds: [target], costs: [0] };
  const { width, offsets } = state;
  const targetCol = target % width;
  const targetRow = Math.floor(target / width);
  const square = { left: targetCol - GOAL_REACH, top: targetRow - GOAL_REACH, width: 2 * GOAL_REACH + 1, height: 2 * GOAL_REACH + 1 };
  const seeds = [];
  const costs = [];
  const joined = /* @__PURE__ */ new Set([target]);
  for (let index = 0, queue = [target]; index < queue.length; index += 1) {
    const at = queue[index];
    if (state.walk[at] === 1) {
      if (local(box, at, width) >= 0) {
        seeds.push(at);
        costs.push(Math.round(STRAIGHT * GROUND_WEIGHT * Math.sqrt((at % width - targetCol) ** 2 + (Math.floor(at / width) - targetRow) ** 2)));
      }
      continue;
    }
    for (let direction = 0; direction < 8; direction += 1) {
      const next = at + offsets[direction];
      if (joined.has(next) || ground.walk[next] !== 1 || !stepAllowed(ground, at, direction) || local(square, next, width) < 0) continue;
      joined.add(next);
      queue.push(next);
    }
  }
  return { seeds, costs };
}
function reachableTarget(state, ground, tiles, near, target) {
  const island = tiles.island[near];
  if (state.walk[target] === 1 && tiles.island[target] === island) return target;
  if (goalFieldOf(state, ground, tiles, target).seeds.some((seed) => tiles.island[seed] === island)) return target;
  const key = target * state.walk.length + island;
  const known = tiles.nearest.get(key);
  if (known !== void 0) return known;
  const { terrain, width } = state;
  const col = target % width - 1;
  const row = Math.floor(target / width) - 1;
  let best = near;
  let bestDistance = Infinity;
  for (let ring = 1; ring <= Math.max(terrain.cols, terrain.rows) && ring * ring <= bestDistance; ring += 1) {
    for (let r = row - ring; r <= row + ring; r += 1) {
      for (let c = col - ring; c <= col + ring; c += 1) {
        if (Math.max(Math.abs(c - col), Math.abs(r - row)) !== ring || c < 0 || r < 0 || c >= terrain.cols || r >= terrain.rows) continue;
        const at = pad(state, c, r);
        if (tiles.island[at] !== island) continue;
        const gap = (c - col) ** 2 + (r - row) ** 2;
        if (gap < bestDistance || gap === bestDistance && at < best) {
          bestDistance = gap;
          best = at;
        }
      }
    }
  }
  if (tiles.nearest.size > 4096) tiles.nearest.clear();
  tiles.nearest.set(key, best);
  return best;
}
function exitFor(state, tiles, region, target, goal) {
  const key = target * tiles.columns * tiles.rows * MAX_REGIONS + region;
  let exit = tiles.exits.get(key);
  if (exit === void 0) {
    exit = searchExit(state, tiles, region, target, goal);
    if (tiles.exits.size > 65536) tiles.exits.clear();
    tiles.exits.set(key, exit);
  }
  return exit < 0 ? void 0 : tiles.nodes.get(exit);
}
function searchExit(state, tiles, region, target, goal) {
  const width = state.width;
  const targetCol = target % width;
  const targetRow = Math.floor(target / width);
  const estimate = (node) => {
    let least = UNREACHED;
    for (const cell of node.cells) {
      const dx = Math.abs(cell % width - targetCol);
      const dy = Math.abs(Math.floor(cell / width) - targetRow);
      least = Math.min(least, (DIAGONAL * Math.min(dx, dy) + STRAIGHT * (Math.max(dx, dy) - Math.min(dx, dy))) * GROUND_WEIGHT);
    }
    return least;
  };
  const sector = Math.floor(region / MAX_REGIONS);
  const cost = /* @__PURE__ */ new Map();
  const parent = /* @__PURE__ */ new Map();
  const heap = new Frontier();
  for (const node of sectorNodes(tiles, sector)) {
    if (tiles.region[node.cells[0]] !== region) continue;
    cost.set(node.key, 0);
    parent.set(node.key, -1);
    heap.push(estimate(node), node.key);
  }
  let finish = -1;
  let finishCost = UNREACHED;
  const relax = (from, to, through) => {
    const node = tiles.nodes.get(to);
    if (!node || through >= (cost.get(to) ?? UNREACHED)) return;
    cost.set(to, through);
    parent.set(to, from);
    heap.push(through + estimate(node), to);
  };
  for (; ; ) {
    const key = heap.pop();
    if (key === void 0) return -1;
    if (key === -1) break;
    const node = tiles.nodes.get(key);
    const here = cost.get(key);
    let end = UNREACHED;
    for (const cell of node.cells) {
      const index = local(goal.box, cell, width);
      if (index >= 0) end = Math.min(end, goal.dist[index]);
    }
    if (end < UNREACHED && here + end < finishCost) {
      finishCost = here + end;
      finish = key;
      heap.push(finishCost, -1);
    }
    const pair = tiles.nodes.get(key ^ 1);
    if (pair) relax(key, key ^ 1, here + STRAIGHT * GROUND_WEIGHT);
    for (const edge of node.edges) relax(key, edge.to, here + edge.cost);
  }
  const path = [];
  for (let at = finish; at !== -1; at = parent.get(at)) path.push(at);
  path.reverse();
  for (let index = 0; index + 1 < path.length; index += 1) if (path[index + 1] === (path[index] ^ 1)) return path[index];
  return path[path.length - 1];
}
class Frontier {
  items = [];
  push(priority, key) {
    const items = this.items;
    items.push([priority, key]);
    for (let at = items.length - 1; at > 0; ) {
      const up = at - 1 >> 1;
      if (!before(items[at], items[up])) break;
      [items[at], items[up]] = [items[up], items[at]];
      at = up;
    }
  }
  pop() {
    const items = this.items;
    if (items.length === 0) return void 0;
    const top = items[0][1];
    const last = items.pop();
    if (items.length > 0) {
      items[0] = last;
      for (let at = 0; ; ) {
        const left = 2 * at + 1;
        const right = left + 1;
        let least = at;
        if (left < items.length && before(items[left], items[least])) least = left;
        if (right < items.length && before(items[right], items[least])) least = right;
        if (least === at) break;
        [items[at], items[least]] = [items[least], items[at]];
        at = least;
      }
    }
    return top;
  }
}
function before(a, b) {
  return a[0] < b[0] || a[0] === b[0] && a[1] < b[1];
}
export function walkingDistance(map, from, goal, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return Math.sqrt((from.x - goal.x) ** 2 + (from.y - goal.y) ** 2);
  const state = runtime(terrain, mover);
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (state.walk[start] !== 1 || state.walk[target] !== 1) return void 0;
  const cost = exactField(state, target).dist[start];
  return cost >= UNREACHED ? void 0 : cost * terrain.cell / STRAIGHT;
}
export function groundSegmentTravelCost(map, from, goal) {
  return groundSegmentProgress(map, from, goal, Infinity).cost;
}
export function groundSegmentAdvance(map, from, goal, budget) {
  const { fraction } = groundSegmentProgress(map, from, goal, budget);
  return fraction === 1 ? goal : { x: from.x + (goal.x - from.x) * fraction, y: from.y + (goal.y - from.y) * fraction };
}
function groundSegmentProgress(map, from, goal, budget) {
  const dx = goal.x - from.x, dy = goal.y - from.y, length = Math.hypot(dx, dy), terrain = map.terrain;
  if (!terrain || length === 0) return { cost: Math.min(length, budget), fraction: length === 0 ? 1 : Math.min(1, budget / length) };
  const cell = terrain.cell, stepX = Math.sign(dx), stepY = Math.sign(dy);
  let col = Math.floor(from.x / cell), row = Math.floor(from.y / cell);
  if (dx < 0 && from.x === col * cell) col--;
  if (dy < 0 && from.y === row * cell) row--;
  let nextX = dx === 0 ? Infinity : ((col + Number(dx > 0)) * cell - from.x) / dx;
  let nextY = dy === 0 ? Infinity : ((row + Number(dy > 0)) * cell - from.y) / dy;
  const spanX = cell / Math.abs(dx), spanY = cell / Math.abs(dy);
  let at = 0, cost = 0;
  while (at < 1) {
    const end = Math.min(1, nextX, nextY);
    const pace = CELL_GROUND[terrain.cells[row * terrain.cols + col]].pace;
    const next = cost + (end - at) * length / pace;
    if (next >= budget) return { cost: budget, fraction: at + (budget - cost) * pace / length };
    cost = next;
    if (end === nextX) {
      col += stepX;
      nextX += spanX;
    }
    if (end === nextY) {
      row += stepY;
      nextY += spanY;
    }
    at = end;
  }
  return { cost, fraction: 1 };
}
export function groundTravelCost(map, from, goal) {
  const terrain = map.terrain;
  if (!terrain) return Math.hypot(from.x - goal.x, from.y - goal.y);
  const state = runtime(terrain, "land"), start = padAt(state, from.x, from.y), target = padAt(state, goal.x, goal.y);
  if (state.walk[start] !== 1 || state.walk[target] !== 1) return void 0;
  if (clearSegment(state, from.x, from.y, goal.x, goal.y)) return groundSegmentTravelCost(map, from, goal);
  const field = cached(state, -target - 1, () => {
    const arrays = state.spare.pop() ?? { dist: new Int32Array(state.walk.length), next: new Int32Array(state.walk.length), used: 0 };
    const box = { left: 0, top: 0, width: state.width, height: state.walk.length / state.width };
    growBoxInto(state, box, [target], void 0, arrays);
    return arrays;
  });
  const cost = field.dist[start];
  return cost >= UNREACHED ? void 0 : cost * terrain.cell / (STRAIGHT * GROUND_WEIGHT);
}
export function sameGround(map, a, b, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  const { labels } = wholesOf(state);
  const from = padAt(state, a.x, a.y);
  const to = padAt(state, b.x, b.y);
  return from >= 0 && to >= 0 && labels[from] !== 0 && labels[from] === labels[to];
}
export function groundWholes(map, mover = "land") {
  return map.terrain ? wholesOf(runtime(map.terrain, mover)).count : 1;
}
function wholesOf(state) {
  if (state.wholes) return state.wholes;
  const { walk, offsets, terrain, width } = state;
  const labels = new Int32Array(walk.length);
  const queue = new Int32Array(walk.length);
  let count = 0;
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || labels[seed] !== 0) continue;
    count += 1;
    labels[seed] = count;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at + offsets[direction];
        if (walk[next] !== 1 || labels[next] !== 0 || !stepAllowed(state, at, direction)) continue;
        labels[next] = count;
        queue[tail++] = next;
      }
    }
  }
  const deep = new Int32Array(count + 1);
  for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
    if (terrain.cells[index] !== "~") continue;
    const col = index % terrain.cols;
    deep[labels[((index - col) / terrain.cols + 1) * width + col + 1]] += 1;
  }
  deep[0] = 0;
  state.wholes = { labels, count, deep };
  return state.wholes;
}
export function walkRoute(map, from, goal, every = 2) {
  const terrain = map.terrain;
  if (!terrain) return [goal];
  const state = runtime(terrain, "land");
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (state.walk[start] !== 1 || state.walk[target] !== 1) return void 0;
  const field = exactField(state, target);
  if (field.dist[start] >= UNREACHED) return void 0;
  const route = [];
  let at = start;
  for (let step = 1; at !== target && step < state.walk.length; step += 1) {
    at = nextStep(state, field, at);
    if (at < 0) return void 0;
    if (step % every === 0) route.push(centerOf(state, at));
  }
  route.push(goal);
  return route;
}
const overlays = /* @__PURE__ */ new WeakMap();
let nextGroundRevision = 1;
export function groundRevision(map) {
  return overlays.get(map)?.revision ?? 0;
}
export function shareBuildingBodies(source, target) {
  const overlay = overlays.get(source);
  if (overlay) {
    overlay.shared = true;
    overlays.set(target, overlay);
  }
}
export function setBuildingBodies(map, bodies) {
  const terrain = map.terrain;
  if (!terrain) return;
  if (bodies.length === 0) {
    overlays.delete(map);
    return;
  }
  const current = overlays.get(map);
  if (current?.terrain === terrain && current.bodies.length === bodies.length && bodies.every((body, index) => body.x === current.bodies[index].x && body.y === current.bodies[index].y && body.radius === current.bodies[index].radius)) return;
  const ground = runtime(terrain, "land");
  let overlay = current;
  if (!overlay || overlay.terrain !== terrain || overlay.shared) {
    const fresh = createRuntime(terrain, "land");
    overlay = { terrain, state: fresh, previous: new Uint8Array(fresh.walk.length), revision: nextGroundRevision++, bodies: [], shared: false };
    overlays.set(map, overlay);
  }
  overlay.bodies = bodies.map(({ x, y, radius }) => ({ x, y, radius }));
  const state = overlay.state;
  overlay.previous.set(state.walk);
  state.walk.set(ground.walk);
  const size = terrain.cell;
  for (const body of bodies) {
    const { left, right, top, bottom } = footprintCells(size, body.x, body.y, body.radius);
    for (let row = Math.max(0, top); row <= Math.min(terrain.rows - 1, bottom); row += 1) {
      for (let col = Math.max(0, left); col <= Math.min(terrain.cols - 1, right); col += 1) state.walk[pad(state, col, row)] = 0;
    }
  }
  const dirty = /* @__PURE__ */ new Set();
  for (let at = 0; at < state.walk.length; at += 1) {
    if (state.walk[at] === overlay.previous[at]) continue;
    const col = at % state.width - 1;
    const row = Math.floor(at / state.width) - 1;
    dirty.add(Math.floor(row / SECTOR) * Math.ceil(terrain.cols / SECTOR) + Math.floor(col / SECTOR));
  }
  if (dirty.size === 0) return;
  overlay.revision = nextGroundRevision++;
  if (state.clearance) {
    state.clearance.fill(0);
    fillClearance(state);
  }
  state.nearest.clear();
  if (state.tiles) redoTiles(state, state.tiles, dirty);
}
function routing(map, terrain, mover) {
  if (mover === "land") {
    const overlay = overlays.get(map);
    if (overlay && overlay.terrain === terrain) return overlay.state;
  }
  return runtime(terrain, mover);
}
const runtimes = /* @__PURE__ */ new WeakMap();
let lastTerrain;
let lastRuntimes = {};
function runtime(terrain, mover) {
  if (terrain !== lastTerrain) {
    lastTerrain = terrain;
    lastRuntimes = runtimes.get(terrain) ?? {};
    runtimes.set(terrain, lastRuntimes);
  }
  return mover === "land" ? lastRuntimes.land ??= createRuntime(terrain, "land") : lastRuntimes.sea ??= createRuntime(terrain, "sea");
}
function createRuntime(terrain, mover) {
  const width = terrain.cols + 2;
  const count = width * (terrain.rows + 2);
  const walk = new Uint8Array(count);
  const weight = new Uint8Array(count);
  const passable = PASSABLE[mover];
  for (let row = 0; row < terrain.rows; row += 1) {
    for (let col = 0; col < terrain.cols; col += 1) {
      const char = terrain.cells[row * terrain.cols + col];
      if (!passable.has(char)) continue;
      const at = (row + 1) * width + col + 1;
      walk[at] = 1;
      weight[at] = mover === "sea" ? GROUND_WEIGHT : Math.round(GROUND_WEIGHT / (CELL_GROUND[char]?.pace ?? 1));
    }
  }
  const offsets = Int32Array.from([1, width, -1, -width, width + 1, width - 1, -width - 1, -width + 1]);
  const state = {
    terrain,
    width,
    walk,
    weight,
    fields: /* @__PURE__ */ new Map(),
    clock: 0,
    spare: [],
    nearest: /* @__PURE__ */ new Map(),
    tops: new Int32Array(8),
    boxBuckets: Array.from({ length: BUCKETS }, () => []),
    offsets
  };
  return state;
}
function pad(state, col, row) {
  return (row + 1) * state.width + col + 1;
}
function padAt(state, x, y) {
  const { terrain } = state;
  const col = Math.floor(x / terrain.cell);
  const row = Math.floor(y / terrain.cell);
  if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return -1;
  return (row + 1) * state.width + col + 1;
}
function centerOf(state, at) {
  const col = at % state.width - 1;
  const row = Math.floor(at / state.width) - 1;
  return { x: (col + 0.5) * state.terrain.cell, y: (row + 0.5) * state.terrain.cell };
}
function stepAllowed(state, at, direction) {
  if (direction < 4) return true;
  const { walk, width } = state;
  const dx = direction === 4 || direction === 7 ? 1 : -1;
  const dy = direction === 4 || direction === 5 ? width : -width;
  return walk[at + dx] === 1 && walk[at + dy] === 1;
}
function fillClearance(state) {
  const { walk, offsets } = state;
  const clearance = state.clearance ??= new Uint16Array(walk.length);
  const queue = new Int32Array(walk.length);
  let tail = 0;
  for (let at = 0; at < walk.length; at += 1) {
    if (walk[at] !== 1) continue;
    for (let direction = 0; direction < 8; direction += 1) {
      if (walk[at + offsets[direction]] === 1) continue;
      clearance[at] = 1;
      queue[tail++] = at;
      break;
    }
  }
  for (let head = 0; head < tail; head += 1) {
    const at = queue[head];
    const value = clearance[at] + 1;
    for (let direction = 0; direction < 8; direction += 1) {
      const next = at + offsets[direction];
      if (walk[next] !== 1 || clearance[next] !== 0) continue;
      clearance[next] = value;
      queue[tail++] = next;
    }
  }
}
function clearSegment(state, ax, ay, bx, by) {
  const { terrain, walk, width } = state;
  const size = terrain.cell;
  let at = padAt(state, ax, ay);
  const end = padAt(state, bx, by);
  if (at < 0 || end < 0 || walk[at] !== 1 || walk[end] !== 1) return false;
  if (at === end) return true;
  if (!state.clearance) fillClearance(state);
  const clearance = state.clearance;
  const dx = bx - ax;
  const dy = by - ay;
  const length = Math.sqrt(dx * dx + dy * dy);
  const ux = dx / length;
  const uy = dy / length;
  let t = 0;
  for (let guard = 0; guard < 2 * (terrain.cols + terrain.rows) + 8; guard += 1) {
    const col = at % width - 1;
    const row = Math.floor(at / width) - 1;
    const reach = clearance[at] - 1;
    const left = (col - reach) * size;
    const right = (col + reach + 1) * size;
    const top = (row - reach) * size;
    const bottom = (row + reach + 1) * size;
    const px = ax + ux * t;
    const py = ay + uy * t;
    const exitX = ux > 0 ? (right - px) / ux : ux < 0 ? (left - px) / ux : Infinity;
    const exitY = uy > 0 ? (bottom - py) / uy : uy < 0 ? (top - py) / uy : Infinity;
    const exit = Math.min(exitX, exitY);
    if (t + exit >= length) return true;
    const leaveX = exitX <= exitY;
    const leaveY = exitY <= exitX;
    t += exit;
    let nextCol = Math.floor((ax + ux * t) / size);
    let nextRow = Math.floor((ay + uy * t) / size);
    if (leaveX) nextCol = ux > 0 ? Math.max(nextCol, col + reach + 1) : Math.min(nextCol, col - reach - 1);
    if (leaveY) nextRow = uy > 0 ? Math.max(nextRow, row + reach + 1) : Math.min(nextRow, row - reach - 1);
    if (nextCol < 0 || nextRow < 0 || nextCol >= terrain.cols || nextRow >= terrain.rows) return false;
    if (leaveX && leaveY && (walk[pad(state, ux > 0 ? col + reach : col - reach, nextRow)] !== 1 || walk[pad(state, nextCol, uy > 0 ? row + reach : row - reach)] !== 1)) return false;
    at = pad(state, nextCol, nextRow);
    if (walk[at] !== 1) return false;
    if (at === end) return true;
  }
  return false;
}
function nextStep(state, field, at) {
  const known = field.next[at];
  if (known !== UNKNOWN) return known;
  const { walk, offsets } = state;
  const dist = field.dist;
  let best = -1;
  let bestCost = dist[at];
  for (let direction = 0; direction < 8; direction += 1) {
    const next = at + offsets[direction];
    if (walk[next] !== 1 || dist[next] >= bestCost || !stepAllowed(state, at, direction)) continue;
    bestCost = dist[next];
    best = next;
  }
  field.next[at] = best;
  return best;
}
function exactField(state, target) {
  return cached(state, target, () => grow(state, [target]));
}
function cached(state, key, build) {
  state.clock += 1;
  const known = state.fields.get(key);
  if (known) {
    known.used = state.clock;
    return known;
  }
  if (state.fields.size >= FIELD_CACHE) {
    let oldest;
    let oldestUse = Infinity;
    for (const [candidate, field2] of state.fields) {
      if (field2.used < oldestUse) {
        oldestUse = field2.used;
        oldest = candidate;
      }
    }
    state.spare.push(state.fields.get(oldest));
    state.fields.delete(oldest);
  }
  const field = build();
  field.used = state.clock;
  state.fields.set(key, field);
  return field;
}
function grow(state, sources) {
  const { walk, offsets, tops } = state;
  const buckets = state.buckets ??= Array.from({ length: 8 }, () => new Int32Array(walk.length));
  const field = state.spare.pop() ?? { dist: new Int32Array(walk.length), next: new Int32Array(walk.length), used: 0 };
  const dist = field.dist;
  dist.fill(UNREACHED);
  field.next.fill(UNKNOWN);
  tops.fill(0);
  let pending = 0;
  for (const source of sources) {
    dist[source] = 0;
    buckets[0][tops[0]++] = source;
    pending += 1;
  }
  for (let cost = 0; pending > 0; cost += 1) {
    const slot = cost & 7;
    const bucket = buckets[slot];
    while (tops[slot] > 0) {
      const at = bucket[--tops[slot]];
      pending -= 1;
      if (dist[at] !== cost) continue;
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at + offsets[direction];
        if (walk[next] !== 1) continue;
        const reached = cost + (direction < 4 ? STRAIGHT : DIAGONAL);
        if (reached >= dist[next] || !stepAllowed(state, at, direction)) continue;
        dist[next] = reached;
        const into = reached & 7;
        buckets[into][tops[into]++] = next;
        pending += 1;
      }
    }
  }
  return field;
}
function nearestWalkable(state, at) {
  if (at >= 0 && state.walk[at] === 1) return at;
  const known = state.nearest.get(at);
  if (known !== void 0) return known;
  const { terrain, width } = state;
  const col = at < 0 ? 0 : at % width - 1;
  const row = at < 0 ? 0 : Math.floor(at / width) - 1;
  let best = -1;
  let bestDistance = Infinity;
  const limit = Math.max(terrain.cols, terrain.rows);
  for (let ring = 1; ring <= limit; ring += 1) {
    if (ring * ring > bestDistance) break;
    for (let r = row - ring; r <= row + ring; r += 1) {
      for (let c = col - ring; c <= col + ring; c += 1) {
        if (Math.max(Math.abs(c - col), Math.abs(r - row)) !== ring) continue;
        if (c < 0 || r < 0 || c >= terrain.cols || r >= terrain.rows) continue;
        const index = pad(state, c, r);
        if (state.walk[index] !== 1) continue;
        const gap = (c - col) * (c - col) + (r - row) * (r - row);
        if (gap < bestDistance || gap === bestDistance && index < best) {
          bestDistance = gap;
          best = index;
        }
      }
    }
  }
  if (state.nearest.size > 4096) state.nearest.clear();
  state.nearest.set(at, best);
  return best;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlcnJhaW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBHYW1lTWFwIH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuLy8gQEBAdGVycmFpbiAtIEdyb3VuZCB0aGF0IGEgdW5pdCBjYW5ub3QgY3Jvc3MsIG9yIGNyb3NzZXMgc2xvd2x5LCBhcyBvbiBhIFdhcmNyYWZ0IElJSSBtYXA6IGZvcmVzdCwgcm9jayAoY2xpZmZzIGFuZFxuLy8gb3V0Y3JvcHMpIGFuZCBkZWVwIHdhdGVyLCBzaGFsbG93cyBhbmQgbXVkLCBvbiBhIGdyaWQgb2Ygc3F1YXJlIGNlbGxzIGxhaWQgb3ZlciB0aGUgbWFwLiBBIHVuaXQgaXMgYSBwb2ludCB0byB0aGVcbi8vIHRlcnJhaW46IGl0IHN0YW5kcyBvbiBhIHdhbGthYmxlIGNlbGwsIHdhbGtzIHJvdW5kIHdoYXQgYmxvY2tzIGl0LCBhbmQgaXMgbmV2ZXIgcHVzaGVkIGludG8gaXQgKHNlZSBzaW0gbW92ZVRvd2FyZCkuIEFcbi8vIG1hcCB3aXRob3V0IHRlcnJhaW4gaXMgb3BlbiBldmVyeXdoZXJlLCBhcyBldmVyeSBtYXAgd2FzIGJlZm9yZSwgYW5kIHBsYXlzIGV4YWN0bHkgYXMgaXQgZGlkLlxuLy8gLSBjZWxsczogb25lIGNoYXJhY3RlciBhIGNlbGwsIHJvdyBieSByb3cgZnJvbSB0aGUgdG9wLWxlZnQgKHdoYXQgZWFjaCBpcyB0byB3aG9ldmVyIGNyb3NzZXMgaXQ6IHNlZSBDRUxMX0dST1VORCk6XG4vLyAgIFwiLlwiIGdyb3VuZDsgXCIsXCIgc2hhbGxvdyB3YXRlciAoYSBmb3JkLCBhIGJlYWNoLCBhIGZsb29kZWQgdmFsbGV5IGZsb29yKTsgXCJtXCIgbXVkIChhIGJvZywgYSBtYXJzaCwgYSBzbm93ZHJpZnQ6IGhvdyBpdFxuLy8gICBsb29rcyBpcyB0aGUgbWFwJ3MgdGhlbWUncyk7IFwiPVwiIGEgYnJpZGdlLCBncm91bmQgbGFpZCBvdmVyIHdhdGVyOyBcIlRcIiBmb3Jlc3Q7IFwiI1wiIHJvY2s7IFwiflwiIGRlZXAgd2F0ZXIuXG4vLyAtIGxldmVsczogZXZlcnkgY2VsbCdzIGdyb3VuZDogXCIwXCIgbG93IGdyb3VuZCwgXCIxXCIgYSBwbGF0ZWF1IChhIG1haW4gYWJvdmUgaXRzIG5hdHVyYWwsIGEgdGVtcGxlJ3Mgb3IgYSBoaWxsJ3MgdG9wLCBhXG4vLyAgIGNsaWZmIGF0IGl0cyByaW0pLCBcIjJcIiBhIHJhbXAgdXAgdG8gaXQuIERyYXduIGZvciB0aGUgZXllOyBhbmQgbm8gYnVpbGRpbmcgc3RhbmRzIG9uIGEgcmFtcCAoc2VlIGlzRm9vdHByaW50QnVpbGRhYmxlKS5cbmV4cG9ydCB0eXBlIFRlcnJhaW4gPSB7XG4gIGNlbGw6IG51bWJlcjtcbiAgY29sczogbnVtYmVyO1xuICByb3dzOiBudW1iZXI7XG4gIGNlbGxzOiBzdHJpbmc7XG4gIGxldmVscz86IHN0cmluZztcbiAgLyoqIGcgZ3Jhc3MsIGQgZWFydGgsIHMgc2FuZCwgciBncmF2ZWw7IHZpc3VhbCBjb3ZlciBvbmx5LiAqL1xuICBzdXJmYWNlcz86IHN0cmluZztcbiAgcGFsZXR0ZT86ICdjb2FzdGFsJztcbiAgLyoqIFJlcHJvZHVjaWJsZSBlbnZpcm9ubWVudCByZWNpcGUuIFJ1bnRpbWUgZmxvYXQgZmllbGRzIHN0YXkgb3V0IG9mIHNhdmVnYW1lcy9uZXR3b3JrIHNuYXBzaG90cy4gKi9cbiAgZWNvbG9neT86IHsgdmVyc2lvbjogMTsgc2VlZDogc3RyaW5nOyBzZWFPdXRsZXQ/OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0gfTtcbn07XG5cbmV4cG9ydCB0eXBlIFRlcnJhaW5DZWxsS2luZCA9IFwiZ3JvdW5kXCIgfCBcInNoYWxsb3dcIiB8IFwibXVkXCIgfCBcImJyaWRnZVwiIHwgXCJmb3Jlc3RcIiB8IFwicm9ja1wiIHwgXCJ3YXRlclwiO1xuXG4vLyBAQEB0ZXJyYWluLWdyb3VuZCAtIFdoYXQgYSBjZWxsIGlzIHRvIHdob2V2ZXIgY3Jvc3NlcyBpdDogd2hldGhlciBhIGxhbmQgdW5pdCB3YWxrcyBpdCBhbmQgYSBzaGlwIHNhaWxzIGl0IChzZWVcbi8vIEBAQHRlcnJhaW4tbW92ZXJzKSwgdGhlIHNoYXJlIG9mIGl0cyBmdWxsIHBhY2UgYSBsYW5kIHVuaXQga2VlcHMgb24gaXQgKGEgc2hpcCBzYWlscyBhdCBpdHMgZnVsbCBwYWNlIHdoZXJldmVyIGl0XG4vLyBzYWlscyksIGFuZCBob3cgbWFueSB0aW1lcyBiYXJlIGdyb3VuZCdzIFBVU0hfRlJJQ1RJT04gYnJha2VzIGEgc2xpZGUgb24gaXQgKGEgc2hvdmUsIGEgY2hhcmdlLCBhIGx1bmdlOiBzZWUgQEBAcHVzaCkuXG4vLyBXYXRlciBkcmFncyBhbmQgbXVkIGRyYWdzIGhhcmRlciwgc28gYSBjaGFyZ2UgdGhyb3VnaCBhIGZvcmQgb3IgYSBib2cgc3RvcHMgc2hvcnQ7IGEgYnJpZGdlIGlzIGdyb3VuZCBhIHNoaXAgY2Fubm90IHBhc3Ncbi8vIHVuZGVyLiBBIGNoYXJhY3RlciBub3QgbGlzdGVkIGlzIGdyb3VuZC5cbmV4cG9ydCBjb25zdCBDRUxMX0dST1VORDogUmVhZG9ubHk8UmVjb3JkPHN0cmluZywgeyBsYW5kOiBib29sZWFuOyBzZWE6IGJvb2xlYW47IHBhY2U6IG51bWJlcjsgZHJhZzogbnVtYmVyIH0+PiA9IHtcbiAgXCIuXCI6IHsgbGFuZDogdHJ1ZSwgc2VhOiBmYWxzZSwgcGFjZTogMSwgZHJhZzogMSB9LFxuICBcIixcIjogeyBsYW5kOiB0cnVlLCBzZWE6IHRydWUsIHBhY2U6IDAuNzUsIGRyYWc6IDEuNiB9LFxuICBtOiB7IGxhbmQ6IHRydWUsIHNlYTogZmFsc2UsIHBhY2U6IDAuNiwgZHJhZzogMiB9LFxuICBcIj1cIjogeyBsYW5kOiB0cnVlLCBzZWE6IGZhbHNlLCBwYWNlOiAxLCBkcmFnOiAxIH0sXG4gIFQ6IHsgbGFuZDogZmFsc2UsIHNlYTogZmFsc2UsIHBhY2U6IDAsIGRyYWc6IDEgfSxcbiAgXCIjXCI6IHsgbGFuZDogZmFsc2UsIHNlYTogZmFsc2UsIHBhY2U6IDAsIGRyYWc6IDEgfSxcbiAgXCJ+XCI6IHsgbGFuZDogZmFsc2UsIHNlYTogdHJ1ZSwgcGFjZTogMCwgZHJhZzogMSB9LFxufTtcblxuLy8gQEBAdGVycmFpbi1tb3ZlcnMgLSBXaG8gY3Jvc3NlcyBhIGNlbGw6IGEgbGFuZCB1bml0IHdhbGtzIGdyb3VuZCBhbmQgc2hhbGxvdyB3YXRlciwgYSBzaGlwIHNhaWxzIGRlZXAgYW5kIHNoYWxsb3cgd2F0ZXJcbi8vIChzZWUgQEBAbmF2YWwpLiBUaGUgc2hhbGxvd3MgYXJlIGJvdGgncywgYXMgb24gYSBXYXJjcmFmdCBJSUkgY29hc3Q6IGEgc2hpcCB0aGF0IGNvbWVzIGluIHRvIHRoZSBiZWFjaCBpcyBpbiB0aGUgcmVhY2ggb2Zcbi8vIHNvbGRpZXJzIHdobyB3YWRlIG91dCB0byBpdCwgYW5kIG91dCBvbiBkZWVwIHdhdGVyIGl0IGlzIG5vdC4gRXZlcnkgcXVlcnkgYmVsb3cgdGFrZXMgdGhlIG1vdmVyIChsYW5kIHdoZW4gbm90IHNhaWQpIGFuZFxuLy8gd29ya3Mgb24gdGhhdCBtb3ZlcidzIG93biBydW50aW1lOiB0aGUgc2VhJ3MgaXMgYnVpbHQgdGhlIGZpcnN0IHRpbWUgYSBzaGlwIGFza3MsIHNvIGEgZ2FtZSB3aXRob3V0IHNoaXBzIG5ldmVyIGJ1aWxkc1xuLy8gaXQuXG5leHBvcnQgdHlwZSBNb3ZlciA9IFwibGFuZFwiIHwgXCJzZWFcIjtcblxudHlwZSBQb2ludCA9IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfTtcblxuY29uc3QgUEFTU0FCTEU6IFJlY29yZDxNb3ZlciwgUmVhZG9ubHlTZXQ8c3RyaW5nPj4gPSB7XG4gIGxhbmQ6IG5ldyBTZXQoT2JqZWN0LmtleXMoQ0VMTF9HUk9VTkQpLmZpbHRlcigoY2hhcikgPT4gQ0VMTF9HUk9VTkRbY2hhcl0hLmxhbmQpKSxcbiAgc2VhOiBuZXcgU2V0KE9iamVjdC5rZXlzKENFTExfR1JPVU5EKS5maWx0ZXIoKGNoYXIpID0+IENFTExfR1JPVU5EW2NoYXJdIS5zZWEpKSxcbn07XG5jb25zdCBVTlJFQUNIRUQgPSAweDNmZmZmZmZmO1xuY29uc3QgVU5LTk9XTiA9IC0yO1xuLy8gT3J0aG9nb25hbCBhbmQgZGlhZ29uYWwgc3RlcHMgb2YgdGhlIGZsb3cgZmllbGRzLCBpbiBmaWZ0aHMgb2YgYSBjZWxsICg3LzUgZm9yIHRoZSBzcXVhcmUgcm9vdCBvZiB0d28pLlxuY29uc3QgU1RSQUlHSFQgPSA1O1xuY29uc3QgRElBR09OQUwgPSA3O1xuLy8gQEBAdGVycmFpbi1zdGVlcmluZyAtIEEgd2FsayB0aGF0IGNhbm5vdCBzZWUgaXRzIGdvYWwgZm9sbG93cyBhIGZsb3cgZmllbGQgZG93biB0byBpdDogaXQgbG9va3MgdGhpcyBtYW55IGNlbGxzIGFsb25nXG4vLyB0aGUgZmxvdyBhbmQgaGVhZHMgZm9yIHRoYXQgY2VsbCBpZiBpdCBzZWVzIGl0IChvbmUgc2lnaHQgbGluZSwgbm90IG9uZSBhIGNlbGwpLCBlbHNlIGZvciB0aGUgY2VsbCBhIGZldyBzdGVwcyBhbG9uZy5cbmNvbnN0IExPT0tBSEVBRCA9IDE2O1xuY29uc3QgU0hPUlRfTE9PSyA9IDM7XG4vLyBGaWVsZHMga2VwdCBwZXIgdGVycmFpbiBmb3IgdGhlIEFJcycgd2Fsa2luZyBkaXN0YW5jZXMgYW5kIHJvdXRlczsgdGhlIGxlYXN0IHJlY2VudGx5IHVzZWQgZ29lcyBmaXJzdCBhbmQgaXRzIGFycmF5c1xuLy8gc2VydmUgdGhlIG5leHQgb25lLlxuY29uc3QgRklFTERfQ0FDSEUgPSAxMjg7XG4vLyA4SyBsb2NhbCAzMHgzMCBmaWVsZHMgY2FwIHRoZWlyIHR5cGVkIGFycmF5cyBhdCBhYm91dCA1NiBNaUIgcGVyIHJvdXRpbmcgbGF5ZXIuXG4vLyBFdmljdCBvbmUgb2xkIGdvYWwsIG5ldmVyIGZsdXNoIGV2ZXJ5IHNvbGRpZXIncyByb3V0ZSBhdCBvbmNlLlxuY29uc3QgR09BTF9GSUVMRF9DQUNIRSA9IDgxOTI7XG4vLyBUaGUgZmxvdyB0aWxlcycgc3F1YXJlcyAoc2VlIEBAQGZsb3ctdGlsZXMpLCBhbmQgdGhlIHJlZ2lvbnMgb25lIHNxdWFyZSBtYXkgaG9sZCAoYSBzcXVhcmUgc3BsaXQgYnkgYSBjbGlmZiBvciBhIHdhbGwpLlxuY29uc3QgU0VDVE9SID0gMTA7XG5jb25zdCBNQVhfUkVHSU9OUyA9IDY0O1xuLy8gQSBjZWxsJ3MgY29zdCB0byBjcm9zcyBpbiBxdWFydGVycyBvZiBiYXJlIGdyb3VuZCdzIChyb3VuZCg0IC8gcGFjZSk6IGEgc2hhbGxvdyA1LCBtdWQgNyksIGFuZCB0aGUgYnVja2V0cyBvZiB0aGUgdGlsZXMnXG4vLyBncm93aW5nLCBtb3JlIHRoYW4gdGhlIGRlYXJlc3Qgc3RlcCAoYSBkaWFnb25hbCBpbnRvIG11ZCwgNyDDlyA3KS5cbmNvbnN0IEdST1VORF9XRUlHSFQgPSA0O1xuY29uc3QgQlVDS0VUUyA9IDY0O1xuLy8gQ2VsbHMgcm91bmQgYSBnb2FsIGEgYnVpbGRpbmcgY292ZXJzIHRoYXQgYSB3YWxrIHRvIGl0IG1heSBlbmQgb24gKHNlZSBnb2FsU2VlZHMpLlxuY29uc3QgR09BTF9SRUFDSCA9IDM7XG5cbmV4cG9ydCBmdW5jdGlvbiB0ZXJyYWluQ2VsbEtpbmQoY2hhcjogc3RyaW5nIHwgdW5kZWZpbmVkKTogVGVycmFpbkNlbGxLaW5kIHtcbiAgaWYgKGNoYXIgPT09IFwiLFwiKSByZXR1cm4gXCJzaGFsbG93XCI7XG4gIGlmIChjaGFyID09PSBcIm1cIikgcmV0dXJuIFwibXVkXCI7XG4gIGlmIChjaGFyID09PSBcIj1cIikgcmV0dXJuIFwiYnJpZGdlXCI7XG4gIGlmIChjaGFyID09PSBcIlRcIikgcmV0dXJuIFwiZm9yZXN0XCI7XG4gIGlmIChjaGFyID09PSBcIiNcIikgcmV0dXJuIFwicm9ja1wiO1xuICBpZiAoY2hhciA9PT0gXCJ+XCIpIHJldHVybiBcIndhdGVyXCI7XG4gIHJldHVybiBcImdyb3VuZFwiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNXYWxrYWJsZUNoYXIoY2hhcjogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gIHJldHVybiBjaGFyICE9PSB1bmRlZmluZWQgJiYgUEFTU0FCTEUubGFuZC5oYXMoY2hhcik7XG59XG5cbi8vIFdoZXRoZXIgYSB1bml0IG1heSBzdGFuZCBhdCB0aGUgcG9pbnQ6IGFsd2F5cyBvbiBhIG1hcCB3aXRob3V0IHRlcnJhaW47IG9uIG9uZSB3aXRoIHRlcnJhaW4sIG9uIGEgY2VsbCBvZiBpdHMgbW92ZXInc1xuLy8gaW5zaWRlIHRoZSBtYXAuXG5leHBvcnQgZnVuY3Rpb24gaXNXYWxrYWJsZShtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCB4OiBudW1iZXIsIHk6IG51bWJlciwgbW92ZXI6IE1vdmVyID0gXCJsYW5kXCIpIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB0cnVlO1xuICBjb25zdCBzdGF0ZSA9IHJ1bnRpbWUodGVycmFpbiwgbW92ZXIpO1xuICByZXR1cm4gc3RhdGUud2Fsa1twYWRBdChzdGF0ZSwgeCwgeSldID09PSAxO1xufVxuXG4vLyBXaGV0aGVyIGEgdW5pdCdzIGNlbnRlciBtYXkgYmUgYXQgdGhlIHBvaW50OiBvbiBpdHMgbW92ZXIncyBncm91bmQgYW5kLCBmb3IgYSBsYW5kIHVuaXQsIG9uIG5vIGJ1aWxkaW5nJ3MgZm9vdHByaW50XG4vLyAoc2VlIEBAQGJ1aWxkaW5nLWZvb3RwcmludCkuIFRoZSBzaW0ga2VlcHMgZXZlcnkgdW5pdCBvbiBvcGVuIGdyb3VuZCBhcyBpdCBrZWVwcyBpdCBvdXQgb2YgYSB3b29kLlxuZXhwb3J0IGZ1bmN0aW9uIGlzT3Blbkdyb3VuZChtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCB4OiBudW1iZXIsIHk6IG51bWJlciwgbW92ZXI6IE1vdmVyID0gXCJsYW5kXCIpIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB0cnVlO1xuICBjb25zdCBzdGF0ZSA9IHJvdXRpbmcobWFwLCB0ZXJyYWluLCBtb3Zlcik7XG4gIHJldHVybiBzdGF0ZS53YWxrW3BhZEF0KHN0YXRlLCB4LCB5KV0gPT09IDE7XG59XG5cbi8vIFdoZXJlIGEgdW5pdCdzIHN0ZXAgZnJvbSBgZnJvbWAgdG93YXJkIGB0b2AgZW5kczogdGhlcmUgd2hlbiBpdCBpcyBvcGVuIGdyb3VuZCAoc2VlIGlzT3Blbkdyb3VuZCksIGVsc2UgYXMgZmFyIGFsb25nIG9uZVxuLy8gYXhpcyBhcyBpcywgc2xpZGluZyBhbG9uZyB0aGUgd2FsbCwgZWxzZSB3aGVyZSBpdCBzdGFuZHM7IGEgdW5pdCBzdGFuZGluZyB3aGVyZSBub3RoaW5nIGlzIG9wZW4gc3RlcHMgYW55d2hlcmUgKGl0IGlzXG4vLyB3YWxraW5nIG91dCkuIFdhbGtpbmcsIHBhcnRpbmcgYW5kIHNsaWRlcyBhbGwgc3RlcCBzbzogcGFydGVkIGFsbCBhdCBvbmNlIG9yIG5vdCBhdCBhbGwsIGEgdW5pdCBieSBhIHdhbGwgbmV2ZXIgZ2F2ZVxuLy8gd2F5IHRvIGEgZnJpZW5kIHdhbGtpbmcgZG93biBhIHBhc3NhZ2Ugb25lIGNlbGwgd2lkZSwgYW5kIHRoZSBmcmllbmQgc3Rvb2QgYmVoaW5kIGl0IGZvciBnb29kLlxuZXhwb3J0IGZ1bmN0aW9uIG9wZW5TdGVwKG1hcDogUGljazxHYW1lTWFwLCBcInRlcnJhaW5cIj4sIGZyb206IFBvaW50LCB0bzogUG9pbnQsIG1vdmVyOiBNb3ZlciA9IFwibGFuZFwiKTogUG9pbnQge1xuICBpZiAoaXNPcGVuR3JvdW5kKG1hcCwgdG8ueCwgdG8ueSwgbW92ZXIpIHx8ICFpc09wZW5Hcm91bmQobWFwLCBmcm9tLngsIGZyb20ueSwgbW92ZXIpKSByZXR1cm4gdG87XG4gIGlmIChpc09wZW5Hcm91bmQobWFwLCB0by54LCBmcm9tLnksIG1vdmVyKSkgcmV0dXJuIHsgeDogdG8ueCwgeTogZnJvbS55IH07XG4gIGlmIChpc09wZW5Hcm91bmQobWFwLCBmcm9tLngsIHRvLnksIG1vdmVyKSkgcmV0dXJuIHsgeDogZnJvbS54LCB5OiB0by55IH07XG4gIHJldHVybiB7IHg6IGZyb20ueCwgeTogZnJvbS55IH07XG59XG5cbi8vIFRoZSBjZW50ZXIgb2YgdGhlIG9wZW4gY2VsbCBuZWFyZXN0IHRoZSBwb2ludCdzLCBmb3IgYSB1bml0IGEgZm9vdHByaW50IGhhcyBjb21lIGRvd24gb247IHVuZGVmaW5lZCBvbiBhIG1hcCB3aXRob3V0XG4vLyB0ZXJyYWluIG9yIHdpdGggbm8gb3BlbiBjZWxsLlxuZXhwb3J0IGZ1bmN0aW9uIG9wZW5Hcm91bmROZWFyKG1hcDogUGljazxHYW1lTWFwLCBcInRlcnJhaW5cIj4sIHBvaW50OiBQb2ludCwgbW92ZXI6IE1vdmVyID0gXCJsYW5kXCIpOiBQb2ludCB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IHRlcnJhaW4gPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0ZXJyYWluKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBzdGF0ZSA9IHJvdXRpbmcobWFwLCB0ZXJyYWluLCBtb3Zlcik7XG4gIGNvbnN0IGF0ID0gcGFkQXQoc3RhdGUsIHBvaW50LngsIHBvaW50LnkpO1xuICBjb25zdCBuZWFyID0gYXQgPCAwID8gLTEgOiBuZWFyZXN0V2Fsa2FibGUoc3RhdGUsIGF0KTtcbiAgcmV0dXJuIG5lYXIgPCAwID8gdW5kZWZpbmVkIDogY2VudGVyT2Yoc3RhdGUsIG5lYXIpO1xufVxuXG4vLyBUaGUgZ3JvdW5kIHVuZGVyIGEgcG9pbnQgYXMgaXQgc2xvd3Mgd2hvZXZlciBjcm9zc2VzIGl0IChzZWUgQEBAdGVycmFpbi1ncm91bmQpOiBhIGxhbmQgdW5pdCBrZWVwcyBgcGFjZWAgb2YgaXRzIHNwZWVkXG4vLyB0aGVyZSBhbmQgYSBzbGlkZSBicmFrZXMgYGRyYWdgIHRpbWVzIGFzIGhhcmQ7IGEgc2hpcCBzYWlscyBhbmQgc2xpZGVzIGF0IGZ1bGwgcGFjZSBldmVyeXdoZXJlLCBhbmQgYSBtYXAgd2l0aG91dFxuLy8gdGVycmFpbiBpcyBiYXJlIGdyb3VuZC5cbmNvbnN0IEJBUkVfR1JPVU5EID0geyBwYWNlOiAxLCBkcmFnOiAxIH07XG5cbmV4cG9ydCBmdW5jdGlvbiBncm91bmRVbmRlcihtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCB4OiBudW1iZXIsIHk6IG51bWJlciwgbW92ZXI6IE1vdmVyID0gXCJsYW5kXCIpOiB7IHBhY2U6IG51bWJlcjsgZHJhZzogbnVtYmVyIH0ge1xuICBjb25zdCB0ZXJyYWluID0gbWFwLnRlcnJhaW47XG4gIGlmICghdGVycmFpbiB8fCBtb3ZlciA9PT0gXCJzZWFcIikgcmV0dXJuIEJBUkVfR1JPVU5EO1xuICBjb25zdCBpbmRleCA9IGNlbGxJbmRleEF0KHRlcnJhaW4sIHgsIHkpO1xuICBjb25zdCBncm91bmQgPSBpbmRleCA8IDAgPyB1bmRlZmluZWQgOiBDRUxMX0dST1VORFt0ZXJyYWluLmNlbGxzW2luZGV4XSFdO1xuICByZXR1cm4gZ3JvdW5kICYmIGdyb3VuZC5sYW5kID8gZ3JvdW5kIDogQkFSRV9HUk9VTkQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjZWxsSW5kZXhBdCh0ZXJyYWluOiBUZXJyYWluLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICBjb25zdCBjb2wgPSBNYXRoLmZsb29yKHggLyB0ZXJyYWluLmNlbGwpO1xuICBjb25zdCByb3cgPSBNYXRoLmZsb29yKHkgLyB0ZXJyYWluLmNlbGwpO1xuICBpZiAoY29sIDwgMCB8fCByb3cgPCAwIHx8IGNvbCA+PSB0ZXJyYWluLmNvbHMgfHwgcm93ID49IHRlcnJhaW4ucm93cykgcmV0dXJuIC0xO1xuICByZXR1cm4gcm93ICogdGVycmFpbi5jb2xzICsgY29sO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2VsbENlbnRlcih0ZXJyYWluOiBUZXJyYWluLCBpbmRleDogbnVtYmVyKTogUG9pbnQge1xuICBjb25zdCBjb2wgPSBpbmRleCAlIHRlcnJhaW4uY29scztcbiAgY29uc3Qgcm93ID0gKGluZGV4IC0gY29sKSAvIHRlcnJhaW4uY29scztcbiAgcmV0dXJuIHsgeDogKGNvbCArIDAuNSkgKiB0ZXJyYWluLmNlbGwsIHk6IChyb3cgKyAwLjUpICogdGVycmFpbi5jZWxsIH07XG59XG5cbi8vIFdoZXRoZXIgYW4gb3JkaW5hcnkgZm91bmRhdGlvbiBtYXkgc3RhbmQgaGVyZTogZXZlcnkgZm9vdHByaW50IGNlbGwgaXMgZHJ5LCB3YWxrYWJsZSBhbmQgbm9uZSBpc1xuLy8gYSByYW1wIChhIG1hcCB3aXRob3V0IHRlcnJhaW4gaGFzIG5vdGhpbmcgdG8gcmVmdXNlKS4gQEBAcmFtcC11bmJ1aWxkYWJsZSAtIEEgcmFtcCBpcyBhIG1haW4ncyBvbmUgd2F5IG91dCwgYXMgb24gYVxuLy8gV2FyY3JhZnQgSUlJIG1hcCwgd2hlcmUgcmFtcHMgdGFrZSBubyBidWlsZGluZzogb25jZSBidWlsZGluZ3MgYXJlIGJvZGllcyAoc2VlIEBAQGJ1aWxkaW5nLWJvZHkpIGEgdG93ZXIgb3IgYSBmYXJtIG9uXG4vLyBpdCB3b3VsZCBzaHV0IGl0cyBvd25lciBpbi5cbmV4cG9ydCBmdW5jdGlvbiBpc0Zvb3RwcmludEJ1aWxkYWJsZShtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCB4OiBudW1iZXIsIHk6IG51bWJlciwgcmFkaXVzOiBudW1iZXIpIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB0cnVlO1xuICBjb25zdCBzdGF0ZSA9IHJ1bnRpbWUodGVycmFpbiwgXCJsYW5kXCIpO1xuICByZXR1cm4gZXZlcnlGb290cHJpbnRDZWxsKHRlcnJhaW4sIHgsIHksIHJhZGl1cywgKGF0LCBjZWxsKSA9PiBzdGF0ZS53YWxrW2F0XSA9PT0gMSAmJiB0ZXJyYWluLmNlbGxzW2NlbGxdICE9PSBcIixcIiAmJiB0ZXJyYWluLmxldmVscz8uW2NlbGxdICE9PSBcIjJcIik7XG59XG5cbi8vIEBAQHNob3JlLWZvb3RwcmludCAtIFdoZXRoZXIgYSBzaGlweWFyZCBvZiB0aGUgZ2l2ZW4gcmFkaXVzIG1heSBzdGFuZCBhdCB0aGUgcG9pbnQsIG9uIHRoZSBzaG9yZTogYXQgbGVhc3Qgb25lIGNlbGwgb2Zcbi8vIGl0cyBmb290cHJpbnQgd2hlcmUgYSB3b3JrZXIgd2Fsa3MgKGdyb3VuZCBvciBzaGFsbG93cyksIHNvIGl0IGJ1aWxkcyBhbmQgcmVwYWlycyBpdCBmcm9tIHRoZXJlIGFuZCBhIHNvbGRpZXIgY2FuIHN0cmlrZVxuLy8gaXQ7IGF0IGxlYXN0IG9uZSBjZWxsIG9wZW4gd2F0ZXIgKHNlZSBAQEBvcGVuLXdhdGVyKSwgZm9yIGl0cyBzaGlwcyB0byBwdXQgb3V0IGZyb207IGFuZCBubyBwYXJ0IG9mIGl0IGluIGEgZm9yZXN0LCBvblxuLy8gcm9jaywgb24gYSByYW1wIChzZWUgQEBAcmFtcC11bmJ1aWxkYWJsZSkgb3Igb2ZmIHRoZSBtYXAuIEl0cyBjZW50ZXIgbWF5IHN0YW5kIGFueXdoZXJlIGluIGl0LCBhcyBpbiBXYXJjcmFmdCBJSUk6IGluXG4vLyB0aGUgc2hhbGxvd3MnIG1pZGRsZSBvciBvdmVyIGRlZXAgd2F0ZXIgYnkgdGhlbS4gV2hlcmV2ZXIgdGhlIHdhdGVyIGlzIChhIHNlYSwgYSBsYWtlLCBhIHJpdmVyKSwgdGhpcyBpcyB0aGUgd2hvbGVcbi8vIHJ1bGU6IG5vIG1hcCBpcyB0b2xkIGl0IGhhcyB3YXRlci4gQSBtYXAgd2l0aG91dCB0ZXJyYWluIGhhcyBub25lLlxuZXhwb3J0IGZ1bmN0aW9uIGlzU2hvcmVGb290cHJpbnQobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHJhZGl1czogbnVtYmVyKSB7XG4gIGNvbnN0IHRlcnJhaW4gPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0ZXJyYWluKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGxhbmQgPSBydW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKTtcbiAgY29uc3Qgc2VhID0gcnVudGltZSh0ZXJyYWluLCBcInNlYVwiKTtcbiAgY29uc3QgeyBsYWJlbHMsIGRlZXAgfSA9IHdob2xlc09mKHNlYSk7XG4gIGxldCBkcnkgPSBmYWxzZTtcbiAgbGV0IHdldCA9IGZhbHNlO1xuICBjb25zdCBmaXRzID0gZXZlcnlGb290cHJpbnRDZWxsKHRlcnJhaW4sIHgsIHksIHJhZGl1cywgKGF0LCBjZWxsKSA9PiB7XG4gICAgaWYgKGxhbmQud2Fsa1thdF0gPT09IDEpIGRyeSA9IHRydWU7XG4gICAgaWYgKHNlYS53YWxrW2F0XSA9PT0gMSAmJiBkZWVwW2xhYmVsc1thdF0hXSEgPj0gT1BFTl9XQVRFUikgd2V0ID0gdHJ1ZTtcbiAgICByZXR1cm4gKHNlYS53YWxrW2F0XSA9PT0gMSB8fCBsYW5kLndhbGtbYXRdID09PSAxKSAmJiB0ZXJyYWluLmxldmVscz8uW2NlbGxdICE9PSBcIjJcIjtcbiAgfSk7XG4gIHJldHVybiBmaXRzICYmIGRyeSAmJiB3ZXQ7XG59XG5cbi8vIEBAQG9wZW4td2F0ZXIgLSBUaGUgd2F0ZXIgYSBzaGlwIGhhcyByb29tIG9uOiBhIHdob2xlIG9mIHRoZSBzZWEncyAoc2VlIEBAQGdyb3VuZC13aG9sZXMpIHdpdGggYXQgbGVhc3QgT1BFTl9XQVRFUiBjZWxsc1xuLy8gb2YgZGVlcCB3YXRlciBpbiBpdCwgYSBsYWtlJ3MsIGEgc2VhJ3MsIG9yIGEgcml2ZXIncyB0aHJlZSBjZWxscyB3aWRlIGFuZCB0aGlydHkgbG9uZywgYW5kIG5vdCBhIHBvbmQgb3IgYSBmb3JkJ3Ncbi8vIHNoYWxsb3dzLiBPbmx5IG9uIGl0IGRvZXMgYSBzaGlweWFyZCBzdGFuZC5cbmV4cG9ydCBjb25zdCBPUEVOX1dBVEVSID0gNjQ7XG5cbi8vIEV2ZXJ5IHBvaW50IGEgc2hpcHlhcmQgb2YgdGhlIGdpdmVuIHJhZGl1cyBtYXkgc3RhbmQgYXQgYnkgdGhlIHRlcnJhaW4gYWxvbmUgKHNlZSBAQEBzaG9yZS1mb290cHJpbnQpLCBvbmUgYSBjZWxsIGF0IHRoZVxuLy8gY2VsbCdzIGNlbnRlciwgcm93IGJ5IHJvdzogd29ya2VkIG91dCBvbmNlIHBlciB0ZXJyYWluIGFuZCByYWRpdXMuIFdoZXRoZXIgYSBidWlsZGluZyBzdGFuZHMgdGhlcmUgYWxyZWFkeSBpcyB0aGVcbi8vIGFza2VyJ3MgdG8gc2VlLlxuZXhwb3J0IGZ1bmN0aW9uIHNob3JlU3BvdHMobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgcmFkaXVzOiBudW1iZXIpOiByZWFkb25seSBQb2ludFtdIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiBbXTtcbiAgY29uc3Qgc2VhID0gcnVudGltZSh0ZXJyYWluLCBcInNlYVwiKTtcbiAgY29uc3Qga25vd24gPSAoc2VhLnNob3JlcyA/Pz0gbmV3IE1hcCgpKS5nZXQocmFkaXVzKTtcbiAgaWYgKGtub3duKSByZXR1cm4ga25vd247XG4gIGNvbnN0IHNwb3RzOiBQb2ludFtdID0gW107XG4gIGNvbnN0IHsgbGFiZWxzLCBkZWVwIH0gPSB3aG9sZXNPZihzZWEpO1xuICBpZiAoZGVlcC5zb21lKChjZWxscykgPT4gY2VsbHMgPj0gT1BFTl9XQVRFUikpIHtcbiAgICAvLyBBIHNoaXB5YXJkIGZvb3RwcmludCBpcyBhIHJlY3Rhbmd1bGFyIGdyaWQgcXVlcnkuIFRocmVlIHN1bW1lZC1hcmVhXG4gICAgLy8gZmllbGRzIHJlcGxhY2UgYSBuZXN0ZWQgZm9vdHByaW50IHNjYW4gYXQgZXZlcnkgY2VsbCBpbiB0aGUgd2hvbGUgbWFwLlxuICAgIGNvbnN0IGxhbmQgPSBydW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKSwgd2lkdGggPSB0ZXJyYWluLmNvbHMgKyAxO1xuICAgIGNvbnN0IGRyeSA9IG5ldyBVaW50MzJBcnJheSh3aWR0aCAqICh0ZXJyYWluLnJvd3MgKyAxKSk7XG4gICAgY29uc3Qgd2V0ID0gbmV3IFVpbnQzMkFycmF5KGRyeS5sZW5ndGgpLCBibG9ja2VkID0gbmV3IFVpbnQzMkFycmF5KGRyeS5sZW5ndGgpO1xuICAgIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8IHRlcnJhaW4ucm93czsgcm93KyspIHtcbiAgICAgIGxldCBkID0gMCwgdyA9IDAsIGIgPSAwO1xuICAgICAgZm9yIChsZXQgY29sID0gMDsgY29sIDwgdGVycmFpbi5jb2xzOyBjb2wrKykge1xuICAgICAgICBjb25zdCBjZWxsID0gcm93ICogdGVycmFpbi5jb2xzICsgY29sLCBhdCA9IChyb3cgKyAxKSAqICh0ZXJyYWluLmNvbHMgKyAyKSArIGNvbCArIDE7XG4gICAgICAgIGQgKz0gbGFuZC53YWxrW2F0XSA9PT0gMSA/IDEgOiAwO1xuICAgICAgICB3ICs9IHNlYS53YWxrW2F0XSA9PT0gMSAmJiBkZWVwW2xhYmVsc1thdF0hXSEgPj0gT1BFTl9XQVRFUiA/IDEgOiAwO1xuICAgICAgICBiICs9IChsYW5kLndhbGtbYXRdICE9PSAxICYmIHNlYS53YWxrW2F0XSAhPT0gMSkgfHwgdGVycmFpbi5sZXZlbHM/LltjZWxsXSA9PT0gXCIyXCIgPyAxIDogMDtcbiAgICAgICAgY29uc3Qgb3V0ID0gKHJvdyArIDEpICogd2lkdGggKyBjb2wgKyAxO1xuICAgICAgICBkcnlbb3V0XSA9IGRyeVtvdXQgLSB3aWR0aF0hICsgZDtcbiAgICAgICAgd2V0W291dF0gPSB3ZXRbb3V0IC0gd2lkdGhdISArIHc7XG4gICAgICAgIGJsb2NrZWRbb3V0XSA9IGJsb2NrZWRbb3V0IC0gd2lkdGhdISArIGI7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGhhbGYgPSBmb290cHJpbnRIYWxmKHJhZGl1cywgdGVycmFpbi5jZWxsKTtcbiAgICBjb25zdCBmaXJzdCA9IE1hdGguY2VpbCgodGVycmFpbi5jZWxsIC8gMiAtIGhhbGYpIC8gdGVycmFpbi5jZWxsIC0gLjUpO1xuICAgIGNvbnN0IGxhc3QgPSBNYXRoLmNlaWwoKHRlcnJhaW4uY2VsbCAvIDIgKyBoYWxmKSAvIHRlcnJhaW4uY2VsbCAtIC41KSAtIDE7XG4gICAgY29uc3QgdG90YWwgPSAoZmllbGQ6IFVpbnQzMkFycmF5LCBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyLCByaWdodDogbnVtYmVyLCBib3R0b206IG51bWJlcikgPT5cbiAgICAgIGZpZWxkW2JvdHRvbSAqIHdpZHRoICsgcmlnaHRdISAtIGZpZWxkW3RvcCAqIHdpZHRoICsgcmlnaHRdISAtIGZpZWxkW2JvdHRvbSAqIHdpZHRoICsgbGVmdF0hICsgZmllbGRbdG9wICogd2lkdGggKyBsZWZ0XSE7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHRlcnJhaW4uY29scyAqIHRlcnJhaW4ucm93czsgaW5kZXggKz0gMSkge1xuICAgICAgY29uc3QgY29sID0gaW5kZXggJSB0ZXJyYWluLmNvbHMsIHJvdyA9IE1hdGguZmxvb3IoaW5kZXggLyB0ZXJyYWluLmNvbHMpO1xuICAgICAgY29uc3QgbGVmdCA9IGNvbCArIGZpcnN0LCB0b3AgPSByb3cgKyBmaXJzdCwgcmlnaHQgPSBjb2wgKyBsYXN0ICsgMSwgYm90dG9tID0gcm93ICsgbGFzdCArIDE7XG4gICAgICBpZiAobGVmdCA8IDAgfHwgdG9wIDwgMCB8fCByaWdodCA+IHRlcnJhaW4uY29scyB8fCBib3R0b20gPiB0ZXJyYWluLnJvd3MpIGNvbnRpbnVlO1xuICAgICAgaWYgKCF0b3RhbChibG9ja2VkLCBsZWZ0LCB0b3AsIHJpZ2h0LCBib3R0b20pICYmIHRvdGFsKGRyeSwgbGVmdCwgdG9wLCByaWdodCwgYm90dG9tKSAmJiB0b3RhbCh3ZXQsIGxlZnQsIHRvcCwgcmlnaHQsIGJvdHRvbSkpXG4gICAgICAgIHNwb3RzLnB1c2goY2VsbENlbnRlcih0ZXJyYWluLCBpbmRleCkpO1xuICAgIH1cbiAgfVxuICBzZWEuc2hvcmVzLnNldChyYWRpdXMsIHNwb3RzKTtcbiAgcmV0dXJuIHNwb3RzO1xufVxuXG4vLyBAQEBidWlsZGluZy1mb290cHJpbnQgLSBBIGJ1aWxkaW5nLCBhIHJvY2sgcGlsZSBvciBhIGdhdGUgdGFrZXMgdGhlIGNlbGxzIG9mIGl0cyBmb290cHJpbnQsIGFzIGluIFdhcmNyYWZ0IElJSTogYSBzcXVhcmVcbi8vIG9mIHdob2xlIGNlbGxzLCB0aGUgZmV3ZXN0IGFjcm9zcyB0aGF0IGhvbGQgaXRzIHJvdW5kIGJvZHkgKHR3byBmb3IgYSBmYXJtIG9yIGEgdG93ZXIsIHRocmVlIGZvciBhIGhhbGwgb3IgYSBiYXJyYWNrcyxcbi8vIGZvdXIgZm9yIGEgZ2F0ZSksIHRoZSBjZWxscyB3aG9zZSBjZW50ZXJzIGZhbGwgd2l0aGluIGl0LiBSb3V0aW5nIGFuZCB3YWxraW5nIHJlYWQgdGhlIHNhbWUgY2VsbHMgKHNlZVxuLy8gQEBAYnVpbGRpbmctcGF0aGluZywgaXNPcGVuR3JvdW5kKTogYSB1bml0IHdhbGtzIHJvdW5kIGEgZm9vdHByaW50IGFuZCBzdGFuZHMgb3V0c2lkZSBpdCBhcyBpdCBkb2VzIGEgd29vZCwgYW5kIGEgZ2FwXG4vLyBiZXR3ZWVuIHR3byBmb290cHJpbnRzIGlzIG9wZW4gZXhhY3RseSB3aGVuIGEgY2VsbCBsaWVzIGJldHdlZW4gdGhlbS4gQSBidWlsZGluZyBpcyBsYWlkIG9uIHdob2xlIGNlbGxzIChzZWVcbi8vIHNuYXBUb0Zvb3RwcmludCk7IGEgYm9keSBsYWlkIGVsc2V3aGVyZSAoYSBnZW5lcmF0ZWQgcm9jayBwaWxlKSBzdGlsbCB0YWtlcyBhIHNxdWFyZSBvZiB0aGF0IG1hbnkgY2VsbHMuXG5leHBvcnQgZnVuY3Rpb24gZm9vdHByaW50SGFsZihyYWRpdXM6IG51bWJlciwgY2VsbDogbnVtYmVyKSB7XG4gIHJldHVybiAoTWF0aC5jZWlsKCgyICogcmFkaXVzKSAvIGNlbGwpICogY2VsbCkgLyAyO1xufVxuXG4vLyBXaGVyZSBhIGJvZHkgb2YgdGhpcyByYWRpdXMgc3RhbmRzIG9uIHRoZSBncmlkOiBpdHMgY2VudGVyIG9uIGEgY2VsbCdzIGNvcm5lciB3aGVuIGl0cyBmb290cHJpbnQgaXMgYW4gZXZlbiBudW1iZXIgb2Zcbi8vIGNlbGxzIGFjcm9zcywgb24gYSBjZWxsJ3MgY2VudGVyIHdoZW4gYW4gb2RkIG9uZS4gQSBtYXAgd2l0aG91dCB0ZXJyYWluIHRha2VzIHRoZSBwb2ludCBhcyBpdCBpcy5cbmV4cG9ydCBmdW5jdGlvbiBzbmFwVG9Gb290cHJpbnQobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgcmFkaXVzOiBudW1iZXIsIHBvaW50OiBQb2ludCk6IFBvaW50IHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB7IHg6IHBvaW50LngsIHk6IHBvaW50LnkgfTtcbiAgY29uc3QgY2VsbCA9IHRlcnJhaW4uY2VsbDtcbiAgY29uc3Qgb2Zmc2V0ID0gTWF0aC5jZWlsKCgyICogcmFkaXVzKSAvIGNlbGwpICUgMiA9PT0gMSA/IGNlbGwgLyAyIDogMDtcbiAgcmV0dXJuIHsgeDogTWF0aC5yb3VuZCgocG9pbnQueCAtIG9mZnNldCkgLyBjZWxsKSAqIGNlbGwgKyBvZmZzZXQsIHk6IE1hdGgucm91bmQoKHBvaW50LnkgLSBvZmZzZXQpIC8gY2VsbCkgKiBjZWxsICsgb2Zmc2V0IH07XG59XG5cbi8vIFRoZSBjb2x1bW5zIGFuZCByb3dzIG9mIHRoZSBjZWxscyBhIGZvb3RwcmludCBvZiB0aGlzIHJhZGl1cyByb3VuZCB0aGUgcG9pbnQgdGFrZXM6IHRob3NlIHdob3NlIGNlbnRlcnMgZmFsbCB3aXRoaW4gaXQuXG5leHBvcnQgZnVuY3Rpb24gZm9vdHByaW50Q2VsbHMoY2VsbDogbnVtYmVyLCB4OiBudW1iZXIsIHk6IG51bWJlciwgcmFkaXVzOiBudW1iZXIpIHtcbiAgY29uc3QgaGFsZiA9IGZvb3RwcmludEhhbGYocmFkaXVzLCBjZWxsKTtcbiAgY29uc3QgZmlyc3QgPSAoZnJvbTogbnVtYmVyKSA9PiBNYXRoLmNlaWwoZnJvbSAvIGNlbGwgLSAwLjUpO1xuICByZXR1cm4geyBsZWZ0OiBmaXJzdCh4IC0gaGFsZiksIHJpZ2h0OiBmaXJzdCh4ICsgaGFsZikgLSAxLCB0b3A6IGZpcnN0KHkgLSBoYWxmKSwgYm90dG9tOiBmaXJzdCh5ICsgaGFsZikgLSAxIH07XG59XG5cbi8vIFdoZXRoZXIgZXZlcnkgY2VsbCBvZiBhIGZvb3RwcmludCBwYXNzZXMgdGhlIHRlc3QgKGJ5IGl0cyBwYWRkZWQgaW5kZXggYW5kIGl0cyBpbmRleCBpbiB0aGUgdGVycmFpbik7IGEgY2VsbCBvZmYgdGhlIG1hcFxuLy8gbmV2ZXIgZG9lcy5cbmZ1bmN0aW9uIGV2ZXJ5Rm9vdHByaW50Q2VsbCh0ZXJyYWluOiBUZXJyYWluLCB4OiBudW1iZXIsIHk6IG51bWJlciwgcmFkaXVzOiBudW1iZXIsIHBhc3NlczogKGF0OiBudW1iZXIsIGNlbGw6IG51bWJlcikgPT4gYm9vbGVhbikge1xuICBjb25zdCBzaXplID0gdGVycmFpbi5jZWxsO1xuICBjb25zdCB3aWR0aCA9IHRlcnJhaW4uY29scyArIDI7XG4gIGNvbnN0IHsgbGVmdCwgcmlnaHQsIHRvcCwgYm90dG9tIH0gPSBmb290cHJpbnRDZWxscyhzaXplLCB4LCB5LCByYWRpdXMpO1xuICBmb3IgKGxldCByb3cgPSB0b3A7IHJvdyA8PSBib3R0b207IHJvdyArPSAxKSB7XG4gICAgZm9yIChsZXQgY29sID0gbGVmdDsgY29sIDw9IHJpZ2h0OyBjb2wgKz0gMSkge1xuICAgICAgaWYgKGNvbCA8IDAgfHwgcm93IDwgMCB8fCBjb2wgPj0gdGVycmFpbi5jb2xzIHx8IHJvdyA+PSB0ZXJyYWluLnJvd3MpIHJldHVybiBmYWxzZTtcbiAgICAgIGlmICghcGFzc2VzKChyb3cgKyAxKSAqIHdpZHRoICsgY29sICsgMSwgcm93ICogdGVycmFpbi5jb2xzICsgY29sKSkgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gVGhlIHBvaW50IGEgdW5pdCBoZWFkaW5nIGZvciAoeCwgeSkgc2hvdWxkIHN0b3AgYXQ6IHRoZSBwb2ludCBpdHNlbGYgd2hlbiBpdCBpcyB3YWxrYWJsZSwgb3RoZXJ3aXNlIHRoZSBjZW50ZXIgb2YgdGhlXG4vLyB3YWxrYWJsZSBjZWxsIG5lYXJlc3QgdGhlIHBvaW50J3MgY2VsbCAoYSBtb3ZlIGludG8gYSBmb3Jlc3QgZW5kcyBhdCBpdHMgZWRnZSwgYXMgb24gYW55IFdhcmNyYWZ0IElJSSBtYXA7IGEgc2hpcCBzZW50XG4vLyBpbmxhbmQgc3RvcHMgYXQgdGhlIHNob3JlKS5cbmV4cG9ydCBmdW5jdGlvbiB3YWxrYWJsZUdvYWwobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiIHwgXCJ3aWR0aFwiIHwgXCJoZWlnaHRcIj4sIHg6IG51bWJlciwgeTogbnVtYmVyLCBtb3ZlcjogTW92ZXIgPSBcImxhbmRcIik6IFBvaW50IHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB7IHgsIHkgfTtcbiAgY29uc3Qgc3RhdGUgPSBydW50aW1lKHRlcnJhaW4sIG1vdmVyKTtcbiAgY29uc3QgY3ggPSBNYXRoLm1pbihNYXRoLm1heCh4LCAwKSwgbWFwLndpZHRoKTtcbiAgY29uc3QgY3kgPSBNYXRoLm1pbihNYXRoLm1heCh5LCAwKSwgbWFwLmhlaWdodCk7XG4gIGNvbnN0IGF0ID0gcGFkQXQoc3RhdGUsIE1hdGgubWluKGN4LCB0ZXJyYWluLmNvbHMgKiB0ZXJyYWluLmNlbGwgLSAwLjAwMSksIE1hdGgubWluKGN5LCB0ZXJyYWluLnJvd3MgKiB0ZXJyYWluLmNlbGwgLSAwLjAwMSkpO1xuICBpZiAoc3RhdGUud2Fsa1thdF0gPT09IDEpIHJldHVybiB7IHg6IGN4LCB5OiBjeSB9O1xuICBjb25zdCBuZWFyZXN0ID0gbmVhcmVzdFdhbGthYmxlKHN0YXRlLCBhdCk7XG4gIHJldHVybiBuZWFyZXN0IDwgMCA/IHsgeDogY3gsIHk6IGN5IH0gOiBjZW50ZXJPZihzdGF0ZSwgbmVhcmVzdCk7XG59XG5cbi8vIFdoZXRoZXIgYSB1bml0IGNvdWxkIHdhbGsgdGhlIHN0cmFpZ2h0IHNlZ21lbnQgZnJvbSBhIHRvIGIgd2l0aG91dCB0b3VjaGluZyBhIGJsb2NrZWQgY2VsbCAoYSBidWlsZGluZydzIGFtb25nIHRoZW0pLlxuZXhwb3J0IGZ1bmN0aW9uIHNlZ21lbnRXYWxrYWJsZShtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCBhOiBQb2ludCwgYjogUG9pbnQsIG1vdmVyOiBNb3ZlciA9IFwibGFuZFwiKSB7XG4gIGNvbnN0IHRlcnJhaW4gPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0ZXJyYWluKSByZXR1cm4gdHJ1ZTtcbiAgcmV0dXJuIGNsZWFyU2VnbWVudChyb3V0aW5nKG1hcCwgdGVycmFpbiwgbW92ZXIpLCBhLngsIGEueSwgYi54LCBiLnkpO1xufVxuXG4vLyBXaGVyZSBhIHVuaXQgYXQgYGZyb21gIHdhbGtpbmcgdG8gYGdvYWxgIHNob3VsZCBoZWFkIHRoaXMgdGljazogdGhlIGdvYWwgaXRzZWxmIHdoZW4gaXQgc2VlcyBpdCwgb3RoZXJ3aXNlIGEgY2VsbCBkb3duXG4vLyB0aGUgZmxvdyB0aWxlcyB0b3dhcmQgaXQgKHNlZSBAQEBmbG93LXRpbGVzLCBAQEB0ZXJyYWluLXN0ZWVyaW5nKS4gYGdvYWxgIHNob3VsZCBiZSB3YWxrYWJsZSAoc2VlIHdhbGthYmxlR29hbCk7IGEgZ29hbFxuLy8gdGhlIHVuaXQncyBncm91bmQgZG9lcyBub3QgcmVhY2ggaXMgd2Fsa2VkIHRvIGFzIG5lYXIgYXMgdGhhdCBncm91bmQgY29tZXMgKHNlZSByZWFjaGFibGVUYXJnZXQpLlxuZXhwb3J0IGZ1bmN0aW9uIHN0ZWVyUG9pbnQobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgZnJvbTogUG9pbnQsIGdvYWw6IFBvaW50LCBtb3ZlcjogTW92ZXIgPSBcImxhbmRcIik6IFBvaW50IHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiBnb2FsO1xuICBjb25zdCBncm91bmQgPSBydW50aW1lKHRlcnJhaW4sIG1vdmVyKTtcbiAgY29uc3Qgc3RhdGUgPSByb3V0aW5nKG1hcCwgdGVycmFpbiwgbW92ZXIpO1xuICBjb25zdCBzdGFydCA9IHBhZEF0KHN0YXRlLCBmcm9tLngsIGZyb20ueSk7XG4gIGNvbnN0IHRhcmdldCA9IHBhZEF0KHN0YXRlLCBnb2FsLngsIGdvYWwueSk7XG4gIGlmIChzdGFydCA8IDAgfHwgdGFyZ2V0IDwgMCB8fCBncm91bmQud2Fsa1t0YXJnZXRdICE9PSAxKSByZXR1cm4gZ29hbDtcbiAgaWYgKGNsZWFyU2VnbWVudChzdGF0ZSwgZnJvbS54LCBmcm9tLnksIGdvYWwueCwgZ29hbC55KSkgcmV0dXJuIGdvYWw7XG4gIC8vIEEgdW5pdCBzdGFuZHMgb24gb3BlbiBncm91bmQgKHNlZSBpc09wZW5Hcm91bmQpOyBvbmUgc3RhbmRpbmcgd2hlcmUgbm90aGluZyB3YWxrcyAob25seSBhIHNlZWRlZCBzY2VuYXJpbyBwdXRzIGl0IHRoZXJlKVxuICAvLyBoZWFkcyBvdXQgdG8gdGhlIHdhbGthYmxlIGNlbGwgbmVhcmVzdCBpdC5cbiAgY29uc3QgbmVhciA9IG5lYXJlc3RXYWxrYWJsZShzdGF0ZSwgc3RhcnQpO1xuICBpZiAobmVhciA8IDApIHJldHVybiBnb2FsO1xuICBpZiAobmVhciAhPT0gc3RhcnQgJiYgZ3JvdW5kLndhbGtbc3RhcnRdICE9PSAxKSByZXR1cm4gY2VudGVyT2Yoc3RhdGUsIG5lYXIpO1xuICBjb25zdCB0aWxlcyA9IHRpbGVzT2Yoc3RhdGUpO1xuICBjb25zdCBhaW0gPSByZWFjaGFibGVUYXJnZXQoc3RhdGUsIGdyb3VuZCwgdGlsZXMsIG5lYXIsIHRhcmdldCk7XG4gIHJldHVybiB3YWxrQWhlYWQoc3RhdGUsIGdyb3VuZCwgdGlsZXMsIGZyb20sIG5lYXIsIGFpbSwgYWltID09PSB0YXJnZXQgPyBnb2FsIDogY2VudGVyT2Yoc3RhdGUsIGFpbSkpO1xufVxuXG4vLyBXaGVyZSBhIHdhbGsgZnJvbSBgZnJvbWAgdG8gYGdvYWxgIGVuZHM6IHRoZSBnb2FsIHdoZW4gdGhlIHdhbGtlcidzIGdyb3VuZCAoYW5kIHRoZSBidWlsZGluZ3MgaW4gaXRzIHdheSkgbGV0IGl0IHJlYWNoXG4vLyBpdCwgZWxzZSB0aGUgcG9pbnQgbmVhcmVzdCBpdCB0aGF0IHRoZXkgZG8gKHNlZSByZWFjaGFibGVUYXJnZXQpOyBmb3IgYSBnb2FsIGluIGEgYnVpbGRpbmcncyBjZWxscywgdGhlIGJvdHRvbSBvZiB0aGVcbi8vIGdvYWwncyBmaWVsZCB0aGUgd2Fsa2VyIGNvbWVzIGRvd24gdG8sIGJ5IHRoZSBidWlsZGluZyAoc2VlIGdvYWxTZWVkcykuIGBnb2FsYCBzaG91bGQgYmUgd2Fsa2FibGUgKHNlZSB3YWxrYWJsZUdvYWwpLlxuZXhwb3J0IGZ1bmN0aW9uIHdhbGtEZXN0aW5hdGlvbihtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCBmcm9tOiBQb2ludCwgZ29hbDogUG9pbnQsIG1vdmVyOiBNb3ZlciA9IFwibGFuZFwiKTogUG9pbnQge1xuICBjb25zdCB0ZXJyYWluID0gbWFwLnRlcnJhaW47XG4gIGlmICghdGVycmFpbikgcmV0dXJuIGdvYWw7XG4gIGNvbnN0IGdyb3VuZCA9IHJ1bnRpbWUodGVycmFpbiwgbW92ZXIpO1xuICBjb25zdCBzdGF0ZSA9IHJvdXRpbmcobWFwLCB0ZXJyYWluLCBtb3Zlcik7XG4gIGNvbnN0IHN0YXJ0ID0gcGFkQXQoc3RhdGUsIGZyb20ueCwgZnJvbS55KTtcbiAgY29uc3QgdGFyZ2V0ID0gcGFkQXQoc3RhdGUsIGdvYWwueCwgZ29hbC55KTtcbiAgaWYgKHN0YXJ0IDwgMCB8fCB0YXJnZXQgPCAwIHx8IGdyb3VuZC53YWxrW3RhcmdldF0gIT09IDEpIHJldHVybiBnb2FsO1xuICBjb25zdCBuZWFyID0gbmVhcmVzdFdhbGthYmxlKHN0YXRlLCBzdGFydCk7XG4gIGlmIChuZWFyIDwgMCkgcmV0dXJuIGdvYWw7XG4gIGNvbnN0IHRpbGVzID0gdGlsZXNPZihzdGF0ZSk7XG4gIGNvbnN0IGFpbSA9IHJlYWNoYWJsZVRhcmdldChzdGF0ZSwgZ3JvdW5kLCB0aWxlcywgbmVhciwgdGFyZ2V0KTtcbiAgaWYgKHN0YXRlLndhbGtbYWltXSA9PT0gMSkgcmV0dXJuIGFpbSA9PT0gdGFyZ2V0ID8gZ29hbCA6IGNlbnRlck9mKHN0YXRlLCBhaW0pO1xuICBjb25zdCBmaWVsZCA9IGdvYWxGaWVsZE9mKHN0YXRlLCBncm91bmQsIHRpbGVzLCBhaW0pLmZpZWxkO1xuICBjb25zdCBpbmRleCA9IGxvY2FsKGZpZWxkLmJveCwgbmVhciwgc3RhdGUud2lkdGgpO1xuICBpZiAoaW5kZXggPCAwIHx8IGZpZWxkLmRpc3RbaW5kZXhdISA+PSBVTlJFQUNIRUQpIHJldHVybiBnb2FsO1xuICBsZXQgYXQgPSBuZWFyO1xuICBmb3IgKGxldCBuZXh0ID0gZG93bmhpbGwoc3RhdGUsIGZpZWxkLCBhdCk7IG5leHQgPj0gMDsgbmV4dCA9IGRvd25oaWxsKHN0YXRlLCBmaWVsZCwgYXQpKSBhdCA9IG5leHQ7XG4gIHJldHVybiBjZW50ZXJPZihzdGF0ZSwgYXQpO1xufVxuXG4vLyBAQEB0ZXJyYWluLXN0ZWVyaW5nIC0gV2hlcmUgYSB1bml0IGF0IGBmcm9tYCwgaW4gY2VsbCBgbmVhcmAsIGhlYWRzIGRvd24gdGhlIHRpbGVzIHRvIGB0YXJnZXRgLCB0aGUgY2VsbCBvZiBgZ29hbGA6IHRoZVxuLy8gY2VsbCBMT09LQUhFQUQgc3RlcHMgb24gd2hlbiBpdCBzZWVzIGl0LCBlbHNlIHRoZSBvbmUgU0hPUlRfTE9PSyBvbi4gVGhlIHN0ZXBzIGdvIGRvd24gaXRzIHNxdWFyZSdzIGZpZWxkIHRvIHRoZSB3aW5kb3dcbi8vIGl0IGxlYXZlcyBieSwgYWNyb3NzIGludG8gdGhlIG5leHQgc3F1YXJlIGFuZCBvbiBkb3duIHRoYXQgc3F1YXJlJ3MsIG9yIGRvd24gdGhlIGdvYWwncyBmaWVsZCBuZWFyIHRoZSBnb2FsLlxuZnVuY3Rpb24gd2Fsa0FoZWFkKHN0YXRlOiBUZXJyYWluUnVudGltZSwgZ3JvdW5kOiBUZXJyYWluUnVudGltZSwgdGlsZXM6IFRpbGVzLCBmcm9tOiBQb2ludCwgbmVhcjogbnVtYmVyLCB0YXJnZXQ6IG51bWJlciwgZ29hbDogUG9pbnQpOiBQb2ludCB7XG4gIGxldCBhdCA9IG5lYXI7XG4gIGxldCBzaG9ydCA9IC0xO1xuICBsZXQgd2F5ID0gd2F5QXQoc3RhdGUsIGdyb3VuZCwgdGlsZXMsIGF0LCB0YXJnZXQpO1xuICBmb3IgKGxldCBzdGVwID0gMTsgc3RlcCA8PSBMT09LQUhFQUQgJiYgd2F5OyBzdGVwICs9IDEpIHtcbiAgICBsZXQgbmV4dCA9IGRvd25oaWxsKHN0YXRlLCB3YXkuZmllbGQsIGF0KTtcbiAgICBpZiAobmV4dCA8IDApIHtcbiAgICAgIC8vIEF0IHRoZSBib3R0b20gb2YgYSBzcXVhcmUncyBmaWVsZDogdGhlIHdpbmRvdyBpdCBsZWFkcyB0bzsgdGhlIGdvYWwncyBmaWVsZCB0YWtlcyBvdmVyIHRoZXJlIHdoZW4gaXQgcmVhY2hlcyB0aGVcbiAgICAgIC8vIGNlbGwsIGVsc2UgdGhlIHdhbGsgY3Jvc3NlcyBpbnRvIHRoZSBuZXh0IHNxdWFyZS5cbiAgICAgIGlmICghd2F5LmV4aXQpIGJyZWFrO1xuICAgICAgY29uc3QgbmVhcmVyID0gd2F5QXQoc3RhdGUsIGdyb3VuZCwgdGlsZXMsIGF0LCB0YXJnZXQpO1xuICAgICAgaWYgKG5lYXJlciAmJiAhbmVhcmVyLmV4aXQpIHtcbiAgICAgICAgd2F5ID0gbmVhcmVyO1xuICAgICAgICBuZXh0ID0gZG93bmhpbGwoc3RhdGUsIHdheS5maWVsZCwgYXQpO1xuICAgICAgICBpZiAobmV4dCA8IDApIGJyZWFrO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV4dCA9IGF0ICsgd2F5LmV4aXQuYWNyb3NzO1xuICAgICAgICBpZiAoc3RhdGUud2Fsa1tuZXh0XSAhPT0gMSkgYnJlYWs7XG4gICAgICAgIHdheSA9IHdheUF0KHN0YXRlLCBncm91bmQsIHRpbGVzLCBuZXh0LCB0YXJnZXQpO1xuICAgICAgfVxuICAgIH1cbiAgICBhdCA9IG5leHQ7XG4gICAgaWYgKHN0ZXAgPT09IFNIT1JUX0xPT0spIHNob3J0ID0gYXQ7XG4gICAgaWYgKHdheSAmJiAhd2F5LmV4aXQgJiYgd2F5LmZpZWxkLmRpc3RbbG9jYWwod2F5LmZpZWxkLmJveCwgYXQsIHN0YXRlLndpZHRoKV0gPT09IDApIGJyZWFrO1xuICB9XG4gIC8vIE5vd2hlcmUgZnVydGhlciBkb3duOiBhdCB0aGUgZ29hbCwgb3IgYXQgdGhlIGJvdHRvbSBvZiBhIGZpZWxkIHRoYXQgZW5kcyBieSBhIGJ1aWxkaW5nIG9yIGEgd29vZCwgYSBjZWxsIGJlc2lkZSBpdCxcbiAgLy8gd2hlcmUgdGhlIHdhbGsgZW5kcyAoYSB3b3JrZXIgYnkgaXRzIGhhbGwgZHJvcHMgaXRzIGdvbGQgdGhlcmUpLiBIZWFkaW5nIG9uIHN0cmFpZ2h0IGF0IGEgZ29hbCBiZWhpbmQgaXQsIHRocmVlIGNhc3RlcnNcbiAgLy8gc3Rvb2QgcHJlc3NlZCBhZ2FpbnN0IHRoZSB0cmVlcyBmb3IgbWludXRlcywgYW5kIGEgYnVpbGRlciB3aG9zZSBzaXRlJ3MgbWlkZGxlIGxheSBvbiBhIGNlbGwncyBlZGdlIHN0ZXBwZWQgYWNyb3NzIGl0XG4gIC8vIGFuZCBiYWNrIGV2ZXJ5IHRpY2suXG4gIGlmIChhdCA9PT0gbmVhcikgcmV0dXJuIG5lYXIgPT09IHRhcmdldCA/IGdvYWwgOiBjZW50ZXJPZihzdGF0ZSwgbmVhcik7XG4gIGNvbnN0IGZhciA9IGF0ID09PSB0YXJnZXQgPyBnb2FsIDogY2VudGVyT2Yoc3RhdGUsIGF0KTtcbiAgaWYgKHNob3J0IDwgMCB8fCBjbGVhclNlZ21lbnQoc3RhdGUsIGZyb20ueCwgZnJvbS55LCBmYXIueCwgZmFyLnkpKSByZXR1cm4gZmFyO1xuICByZXR1cm4gc2hvcnQgPT09IHRhcmdldCA/IGdvYWwgOiBjZW50ZXJPZihzdGF0ZSwgc2hvcnQpO1xufVxuXG4vLyBUaGUgZmllbGQgYSB3YWxrIHRvIGB0YXJnZXRgIGZvbGxvd3MgZnJvbSBjZWxsIGBhdGA6IHRoZSBnb2FsJ3Mgd2hlbiBpdCByZWFjaGVzIHRoZSBjZWxsLCBlbHNlIHRoZSBmaWVsZCBvZiB0aGUgd2luZG93XG4vLyB0aGUgY2VsbCdzIHJlZ2lvbiBsZWF2ZXMgaXRzIHNxdWFyZSBieSAoc2VlIGV4aXRGb3IpOyB1bmRlZmluZWQgd2hlbiB0aGUgdGlsZXMgam9pbiBuZWl0aGVyLlxuZnVuY3Rpb24gd2F5QXQoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCBncm91bmQ6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMsIGF0OiBudW1iZXIsIHRhcmdldDogbnVtYmVyKTogeyBmaWVsZDogQm94RmllbGQ7IGV4aXQ/OiBUaWxlTm9kZSB9IHwgdW5kZWZpbmVkIHtcbiAgY29uc3QgZ29hbCA9IGdvYWxGaWVsZE9mKHN0YXRlLCBncm91bmQsIHRpbGVzLCB0YXJnZXQpO1xuICBjb25zdCBpbmRleCA9IGxvY2FsKGdvYWwuZmllbGQuYm94LCBhdCwgc3RhdGUud2lkdGgpO1xuICBpZiAoaW5kZXggPj0gMCAmJiBnb2FsLmZpZWxkLmRpc3RbaW5kZXhdISA8IFVOUkVBQ0hFRCkgcmV0dXJuIHsgZmllbGQ6IGdvYWwuZmllbGQgfTtcbiAgY29uc3QgZXhpdCA9IGV4aXRGb3Ioc3RhdGUsIHRpbGVzLCB0aWxlcy5yZWdpb25bYXRdISwgdGFyZ2V0LCBnb2FsLmZpZWxkKTtcbiAgLy8gQSBzcXVhcmUgd2l0aCBtb3JlIHJlZ2lvbnMgdGhhbiBNQVhfUkVHSU9OUyBzaGFyZXMgdGhlIGxhc3QgbGFiZWwgYW1vbmcgdGhlbTogaXRzIGV4aXQgbWF5IG5vdCBiZSB0aGlzIGNlbGwncy5cbiAgaWYgKCFleGl0IHx8IGV4aXQuZmllbGQuZGlzdFtsb2NhbChleGl0LmZpZWxkLmJveCwgYXQsIHN0YXRlLndpZHRoKV0hID49IFVOUkVBQ0hFRCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIHsgZmllbGQ6IGV4aXQuZmllbGQsIGV4aXQgfTtcbn1cblxuLy8gLS0tLSBAQEBmbG93LXRpbGVzIC0gUm91dGluZyBhcyBTdXByZW1lIENvbW1hbmRlciAyIGRvZXMgaXQ6IEVsaWphaCBFbWVyc29uLCBcIkNyb3dkIFBhdGhmaW5kaW5nIGFuZCBTdGVlcmluZyBVc2luZyBGbG93XG4vLyBGaWVsZCBUaWxlc1wiIChHYW1lIEFJIFBybywgMjAxMywgY2hhcHRlciAyMykuIFRoZSBtYXAgaXMgY3V0IGludG8gU0VDVE9SLWNlbGwgc3F1YXJlcy4gV2hlcmUgYSBzcXVhcmUncyBlZGdlIGNhbiBiZVxuLy8gY3Jvc3NlZCwgZWFjaCBydW4gb2Ygb3BlbiBjZWxscyBiZXNpZGUgaXQgaXMgYSB3aW5kb3csIGEgbm9kZSBmb3IgZWFjaCBvZiBpdHMgdHdvIHNpZGVzOyBlYWNoIHNpZGUgaGFzIGEgZmllbGQgb3ZlciBpdHNcbi8vIHNxdWFyZSAodGhlIGNvc3QgZnJvbSBldmVyeSBjZWxsIG9mIHRoZSBzcXVhcmUgdG8gdGhhdCBzaWRlJ3MgY2VsbHMpLCB3aGljaCBib3RoIHByaWNlcyB0aGUgZ3JhcGgncyBlZGdlcyAoZnJvbSBvbmVcbi8vIHdpbmRvdyBvZiBhIHNxdWFyZSB0byBhbm90aGVyKSBhbmQgaXMgdGhlIHdheSBhIHVuaXQgd2Fsa3MgdG8gdGhhdCB3aW5kb3cuIEEgd2FsayBhc2tzIHRoZSBncmFwaCAoQSosIGZyb20gZXZlcnkgd2luZG93XG4vLyBvZiBpdHMgc3F1YXJlJ3MgcmVnaW9uLCB0aGUgcmVnaW9uJ3MgYW5zd2VyIGtlcHQgdW50aWwgdGhlIGNvcHkgY2hhbmdlcykgd2hpY2ggd2luZG93IHRvIGxlYXZlIGl0cyBzcXVhcmUgYnkgYW5kXG4vLyBmb2xsb3dzIHRoYXQgd2luZG93J3MgZmllbGQgYWNyb3NzOyB3aXRoaW4gYSBzcXVhcmUgb2YgaXRzIGdvYWwncyBpdCBmb2xsb3dzIHRoZSBnb2FsJ3Mgb3duIGZpZWxkLiBBIGJ1aWxkaW5nIGxhaWQgb3Jcbi8vIGZlbGxlZCByZWRvZXMgdGhlIHdpbmRvd3MgYW5kIGZpZWxkcyBvZiB0aGUgc3F1YXJlcyB3aG9zZSBjZWxscyBjaGFuZ2VkIGFuZCBvZiB0aGUgc3F1YXJlcyBiZXNpZGUgdGhlbSAoRW1lcnNvbidzIGRpcnR5XG4vLyBzZWN0b3JzKSwgbmV2ZXIgdGhlIG1hcCdzLCBhbmQgZXZlcnkgYW5zd2VyIGlzIGEgZnVuY3Rpb24gb2YgdGhlIGNlbGxzIGFsb25lOiBhIGNsaWVudCB0aGF0IHJlYnVpbGRzIHRoZSB0aWxlcyBhZnRlciBhXG4vLyBjaGVja3BvaW50IHdhbGtzIGV4YWN0bHkgYXMgdGhlIHNlcnZlci4gR3JvdW5kIHByaWNlcyBhIHN0ZXAgYnkgaXRzIHBhY2UgKHNlZSBDRUxMX0dST1VORCk6IGEgd2FsayBnb2VzIHJvdW5kIGEgYm9nXG4vLyB3aGVuIHJvdW5kIGlzIHF1aWNrZXIsIGFuZCBhIGZpZWxkIGlzIGFsbCBkb3duaGlsbCwgc28gYSB1bml0IG5ldmVyIHR1cm5zIGJhY2sgb24gaXRzIHdheS5cbnR5cGUgQm94ID0geyBsZWZ0OiBudW1iZXI7IHRvcDogbnVtYmVyOyB3aWR0aDogbnVtYmVyOyBoZWlnaHQ6IG51bWJlciB9O1xuLy8gYG5leHRgOiBlYWNoIGNlbGwncyBuZXh0IGNlbGwgZG93biB0aGUgZmllbGQsIHdvcmtlZCBvdXQgd2hlbiBmaXJzdCBhc2tlZCAoc2VlIGRvd25oaWxsKS5cbnR5cGUgQm94RmllbGQgPSB7IGJveDogQm94OyBkaXN0OiBJbnQzMkFycmF5OyBuZXh0OiBJbnQzMkFycmF5IH07XG4vLyBBIHdpbmRvdydzIHNpZGU6IGl0cyBjZWxscyBpbiBpdHMgc3F1YXJlLCB0aGUgcGFkZGVkIG9mZnNldCBhY3Jvc3MgdG8gdGhlIG90aGVyIHNpZGUncywgYW5kIGl0cyBmaWVsZCBvdmVyIHRoZSBzcXVhcmUuXG4vLyBJdHMga2V5IGlzIGl0cyB3aW5kb3cncyBmaXJzdCBjZWxsIG9uIHRoZSBsZWZ0IG9yIHVwcGVyIHNpZGUgw5cgNCwgKyAyIGZvciBhIHdpbmRvdyBvbiBhIHNxdWFyZSdzIGxvd2VyIGVkZ2UsICsgMSBmb3Jcbi8vIHRoZSByaWdodCBvciBsb3dlciBzaWRlIChrZXkgXiAxIGlzIHRoZSBvdGhlciBzaWRlKTogdGhlIHNhbWUgd2hhdGV2ZXIgb3JkZXIgdGhlIHRpbGVzIHdlcmUgYnVpbHQgaW4uXG50eXBlIFRpbGVOb2RlID0geyBrZXk6IG51bWJlcjsgc2VjdG9yOiBudW1iZXI7IGNlbGxzOiBudW1iZXJbXTsgYWNyb3NzOiBudW1iZXI7IGZpZWxkOiBCb3hGaWVsZDsgZWRnZXM6IHsgdG86IG51bWJlcjsgY29zdDogbnVtYmVyIH1bXSB9O1xudHlwZSBUaWxlcyA9IHtcbiAgY29sdW1uczogbnVtYmVyO1xuICByb3dzOiBudW1iZXI7XG4gIG5vZGVzOiBNYXA8bnVtYmVyLCBUaWxlTm9kZT47XG4gIC8vIFBlciBzcXVhcmUgZWRnZSAodGhlIGxlZnQgb3IgdXBwZXIgc3F1YXJlIMOXIDIsICsgMSBmb3IgaXRzIGxvd2VyIGVkZ2UpOiBpdHMgd2luZG93cycgbGVmdCBvciB1cHBlciBzaWRlIGtleXMuXG4gIGJvcmRlcnM6IE1hcDxudW1iZXIsIG51bWJlcltdPjtcbiAgLy8gUGVyIGNlbGw6IGl0cyBzcXVhcmUncyByZWdpb24gKHNxdWFyZSDDlyBNQVhfUkVHSU9OUyArIGl0cyBudW1iZXIgaW4gdGhlIHNxdWFyZSkgYW5kIGl0cyBpc2xhbmQsIHRoZSBhcmVhIG9mIHRoZSB3aG9sZVxuICAvLyBjb3B5IGl0IHdhbGtzIGluOyAtMSBvbiBhIGJsb2NrZWQgY2VsbC5cbiAgcmVnaW9uOiBJbnQzMkFycmF5O1xuICBpc2xhbmQ6IEludDMyQXJyYXk7XG4gIGdvYWxzOiBNYXA8bnVtYmVyLCB7IGZpZWxkOiBCb3hGaWVsZDsgc2VlZHM6IG51bWJlcltdIH0+O1xuICBleGl0czogTWFwPG51bWJlciwgbnVtYmVyPjtcbiAgbmVhcmVzdDogTWFwPG51bWJlciwgbnVtYmVyPjtcbn07XG5cbmZ1bmN0aW9uIHRpbGVzT2Yoc3RhdGU6IFRlcnJhaW5SdW50aW1lKTogVGlsZXMge1xuICBpZiAoc3RhdGUudGlsZXMpIHJldHVybiBzdGF0ZS50aWxlcztcbiAgY29uc3QgeyB0ZXJyYWluIH0gPSBzdGF0ZTtcbiAgY29uc3QgY29sdW1ucyA9IE1hdGguY2VpbCh0ZXJyYWluLmNvbHMgLyBTRUNUT1IpO1xuICBjb25zdCByb3dzID0gTWF0aC5jZWlsKHRlcnJhaW4ucm93cyAvIFNFQ1RPUik7XG4gIGNvbnN0IHRpbGVzOiBUaWxlcyA9IHtcbiAgICBjb2x1bW5zLFxuICAgIHJvd3MsXG4gICAgbm9kZXM6IG5ldyBNYXAoKSxcbiAgICBib3JkZXJzOiBuZXcgTWFwKCksXG4gICAgcmVnaW9uOiBuZXcgSW50MzJBcnJheShzdGF0ZS53YWxrLmxlbmd0aCkuZmlsbCgtMSksXG4gICAgaXNsYW5kOiBuZXcgSW50MzJBcnJheShzdGF0ZS53YWxrLmxlbmd0aCkuZmlsbCgtMSksXG4gICAgZ29hbHM6IG5ldyBNYXAoKSxcbiAgICBleGl0czogbmV3IE1hcCgpLFxuICAgIG5lYXJlc3Q6IG5ldyBNYXAoKSxcbiAgfTtcbiAgc3RhdGUudGlsZXMgPSB0aWxlcztcbiAgY29uc3QgYWxsID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogY29sdW1ucyAqIHJvd3MgfSwgKF8sIHNlY3RvcikgPT4gc2VjdG9yKTtcbiAgZm9yIChjb25zdCBzZWN0b3Igb2YgYWxsKSBsYWJlbFJlZ2lvbnMoc3RhdGUsIHRpbGVzLCBzZWN0b3IpO1xuICBmb3IgKGNvbnN0IHNlY3RvciBvZiBhbGwpIGZvciAoY29uc3QgbG93ZXIgb2YgWzAsIDFdKSBsYXlXaW5kb3dzKHN0YXRlLCB0aWxlcywgc2VjdG9yICogMiArIGxvd2VyKTtcbiAgZm9yIChjb25zdCBzZWN0b3Igb2YgYWxsKSBsaW5rU2VjdG9yKHN0YXRlLCB0aWxlcywgc2VjdG9yKTtcbiAgbGFiZWxJc2xhbmRzKHN0YXRlLCB0aWxlcyk7XG4gIHJldHVybiB0aWxlcztcbn1cblxuLy8gQWZ0ZXIgdGhlIGNvcHkncyBjZWxscyBjaGFuZ2VkIGluIGBkaXJ0eWAgc3F1YXJlczogdGhlaXIgcmVnaW9ucywgdGhlIHdpbmRvd3Mgb24gdGhlaXIgZWRnZXMsIGFuZCB0aGUgZmllbGRzIGFuZCBlZGdlcyBvZlxuLy8gZXZlcnkgc3F1YXJlIGJlc2lkZSB0aGVtLCBhcyBhIGZyZXNoIGJ1aWxkIHdvdWxkIG1ha2UgdGhlbS5cbmZ1bmN0aW9uIHJlZG9UaWxlcyhzdGF0ZTogVGVycmFpblJ1bnRpbWUsIHRpbGVzOiBUaWxlcywgZGlydHk6IFNldDxudW1iZXI+KSB7XG4gIGNvbnN0IHNlY3RvcnMgPSBbLi4uZGlydHldLnNvcnQoKGEsIGIpID0+IGEgLSBiKTtcbiAgY29uc3QgdG91Y2hlZCA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBjb25zdCBib3JkZXJzID0gbmV3IFNldDxudW1iZXI+KCk7XG4gIGZvciAoY29uc3Qgc2VjdG9yIG9mIHNlY3RvcnMpIHtcbiAgICBsYWJlbFJlZ2lvbnMoc3RhdGUsIHRpbGVzLCBzZWN0b3IpO1xuICAgIGNvbnN0IGNvbCA9IHNlY3RvciAlIHRpbGVzLmNvbHVtbnM7XG4gICAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihzZWN0b3IgLyB0aWxlcy5jb2x1bW5zKTtcbiAgICB0b3VjaGVkLmFkZChzZWN0b3IpO1xuICAgIGZvciAoY29uc3QgbG93ZXIgb2YgWzAsIDFdKSBib3JkZXJzLmFkZChzZWN0b3IgKiAyICsgbG93ZXIpO1xuICAgIGlmIChjb2wgPiAwKSB7XG4gICAgICBib3JkZXJzLmFkZCgoc2VjdG9yIC0gMSkgKiAyKTtcbiAgICAgIHRvdWNoZWQuYWRkKHNlY3RvciAtIDEpO1xuICAgIH1cbiAgICBpZiAocm93ID4gMCkge1xuICAgICAgYm9yZGVycy5hZGQoKHNlY3RvciAtIHRpbGVzLmNvbHVtbnMpICogMiArIDEpO1xuICAgICAgdG91Y2hlZC5hZGQoc2VjdG9yIC0gdGlsZXMuY29sdW1ucyk7XG4gICAgfVxuICAgIGlmIChjb2wgKyAxIDwgdGlsZXMuY29sdW1ucykgdG91Y2hlZC5hZGQoc2VjdG9yICsgMSk7XG4gICAgaWYgKHJvdyArIDEgPCB0aWxlcy5yb3dzKSB0b3VjaGVkLmFkZChzZWN0b3IgKyB0aWxlcy5jb2x1bW5zKTtcbiAgfVxuICBmb3IgKGNvbnN0IGJvcmRlciBvZiBbLi4uYm9yZGVyc10uc29ydCgoYSwgYikgPT4gYSAtIGIpKSB7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgdGlsZXMuYm9yZGVycy5nZXQoYm9yZGVyKSA/PyBbXSkge1xuICAgICAgdGlsZXMubm9kZXMuZGVsZXRlKGtleSk7XG4gICAgICB0aWxlcy5ub2Rlcy5kZWxldGUoa2V5IF4gMSk7XG4gICAgfVxuICAgIGxheVdpbmRvd3Moc3RhdGUsIHRpbGVzLCBib3JkZXIpO1xuICB9XG4gIGZvciAoY29uc3Qgc2VjdG9yIG9mIFsuLi50b3VjaGVkXS5zb3J0KChhLCBiKSA9PiBhIC0gYikpIGxpbmtTZWN0b3Ioc3RhdGUsIHRpbGVzLCBzZWN0b3IpO1xuICBsYWJlbElzbGFuZHMoc3RhdGUsIHRpbGVzKTtcbiAgLy8gQSBnb2FsJ3MgZmllbGQgcmVhZHMgdGhlIGNlbGxzIG9mIGl0cyBzcXVhcmUgYW5kIHRob3NlIHJvdW5kIGl0IChhbmQgb25lIGNlbGwgYmV5b25kKTogb25seSB0aGUgZ29hbHMgd2l0aGluIHR3b1xuICAvLyBzcXVhcmVzIG9mIGEgY2hhbmdlZCBvbmUgYXJlIGdyb3duIGFnYWluLlxuICBmb3IgKGNvbnN0IHRhcmdldCBvZiBbLi4udGlsZXMuZ29hbHMua2V5cygpXSkge1xuICAgIGNvbnN0IHNlY3RvciA9IHNlY3Rvck9mKHN0YXRlLCB0aWxlcywgdGFyZ2V0KTtcbiAgICBjb25zdCBuZWFyID0gc2VjdG9ycy5zb21lKChkaXJ0eSkgPT4gTWF0aC5hYnMoKGRpcnR5ICUgdGlsZXMuY29sdW1ucykgLSAoc2VjdG9yICUgdGlsZXMuY29sdW1ucykpIDw9IDIgJiYgTWF0aC5hYnMoTWF0aC5mbG9vcihkaXJ0eSAvIHRpbGVzLmNvbHVtbnMpIC0gTWF0aC5mbG9vcihzZWN0b3IgLyB0aWxlcy5jb2x1bW5zKSkgPD0gMik7XG4gICAgaWYgKG5lYXIpIHRpbGVzLmdvYWxzLmRlbGV0ZSh0YXJnZXQpO1xuICB9XG4gIHRpbGVzLmV4aXRzLmNsZWFyKCk7XG4gIHRpbGVzLm5lYXJlc3QuY2xlYXIoKTtcbn1cblxuZnVuY3Rpb24gc2VjdG9yQm94KHN0YXRlOiBUZXJyYWluUnVudGltZSwgdGlsZXM6IFRpbGVzLCBzZWN0b3I6IG51bWJlcik6IEJveCB7XG4gIGNvbnN0IGNvbCA9IChzZWN0b3IgJSB0aWxlcy5jb2x1bW5zKSAqIFNFQ1RPUjtcbiAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihzZWN0b3IgLyB0aWxlcy5jb2x1bW5zKSAqIFNFQ1RPUjtcbiAgcmV0dXJuIHsgbGVmdDogY29sICsgMSwgdG9wOiByb3cgKyAxLCB3aWR0aDogTWF0aC5taW4oU0VDVE9SLCBzdGF0ZS50ZXJyYWluLmNvbHMgLSBjb2wpLCBoZWlnaHQ6IE1hdGgubWluKFNFQ1RPUiwgc3RhdGUudGVycmFpbi5yb3dzIC0gcm93KSB9O1xufVxuXG5mdW5jdGlvbiBzZWN0b3JPZihzdGF0ZTogVGVycmFpblJ1bnRpbWUsIHRpbGVzOiBUaWxlcywgYXQ6IG51bWJlcikge1xuICBjb25zdCBjb2wgPSAoYXQgJSBzdGF0ZS53aWR0aCkgLSAxO1xuICBjb25zdCByb3cgPSBNYXRoLmZsb29yKGF0IC8gc3RhdGUud2lkdGgpIC0gMTtcbiAgcmV0dXJuIE1hdGguZmxvb3Iocm93IC8gU0VDVE9SKSAqIHRpbGVzLmNvbHVtbnMgKyBNYXRoLmZsb29yKGNvbCAvIFNFQ1RPUik7XG59XG5cbi8vIFRoZSBpbmRleCBvZiBhIHBhZGRlZCBjZWxsIGluIGEgYm94J3MgZmllbGQsIG9yIC0xIG91dHNpZGUgaXQuXG5mdW5jdGlvbiBsb2NhbChib3g6IEJveCwgYXQ6IG51bWJlciwgd2lkdGg6IG51bWJlcikge1xuICBjb25zdCBjb2wgPSBhdCAlIHdpZHRoO1xuICBjb25zdCByb3cgPSAoYXQgLSBjb2wpIC8gd2lkdGg7XG4gIGlmIChjb2wgPCBib3gubGVmdCB8fCByb3cgPCBib3gudG9wIHx8IGNvbCA+PSBib3gubGVmdCArIGJveC53aWR0aCB8fCByb3cgPj0gYm94LnRvcCArIGJveC5oZWlnaHQpIHJldHVybiAtMTtcbiAgcmV0dXJuIChyb3cgLSBib3gudG9wKSAqIGJveC53aWR0aCArIChjb2wgLSBib3gubGVmdCk7XG59XG5cbi8vIEEgc3F1YXJlJ3MgcmVnaW9uczogdGhlIHBhcnRzIG9mIGl0IGEgd2FsayBqb2lucyB3aXRob3V0IGxlYXZpbmcgaXQsIG51bWJlcmVkIGluIGNlbGwgb3JkZXIuXG5mdW5jdGlvbiBsYWJlbFJlZ2lvbnMoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMsIHNlY3RvcjogbnVtYmVyKSB7XG4gIGNvbnN0IHsgd2Fsaywgb2Zmc2V0cywgd2lkdGggfSA9IHN0YXRlO1xuICBjb25zdCBib3ggPSBzZWN0b3JCb3goc3RhdGUsIHRpbGVzLCBzZWN0b3IpO1xuICBmb3IgKGxldCByb3cgPSBib3gudG9wOyByb3cgPCBib3gudG9wICsgYm94LmhlaWdodDsgcm93ICs9IDEpIGZvciAobGV0IGNvbCA9IGJveC5sZWZ0OyBjb2wgPCBib3gubGVmdCArIGJveC53aWR0aDsgY29sICs9IDEpIHRpbGVzLnJlZ2lvbltyb3cgKiB3aWR0aCArIGNvbF0gPSAtMTtcbiAgbGV0IGNvdW50ID0gMDtcbiAgZm9yIChsZXQgcm93ID0gYm94LnRvcDsgcm93IDwgYm94LnRvcCArIGJveC5oZWlnaHQ7IHJvdyArPSAxKSB7XG4gICAgZm9yIChsZXQgY29sID0gYm94LmxlZnQ7IGNvbCA8IGJveC5sZWZ0ICsgYm94LndpZHRoOyBjb2wgKz0gMSkge1xuICAgICAgY29uc3Qgc2VlZCA9IHJvdyAqIHdpZHRoICsgY29sO1xuICAgICAgaWYgKHdhbGtbc2VlZF0gIT09IDEgfHwgdGlsZXMucmVnaW9uW3NlZWRdICE9PSAtMSkgY29udGludWU7XG4gICAgICBjb25zdCBsYWJlbCA9IHNlY3RvciAqIE1BWF9SRUdJT05TICsgTWF0aC5taW4oY291bnQsIE1BWF9SRUdJT05TIC0gMSk7XG4gICAgICBjb3VudCArPSAxO1xuICAgICAgdGlsZXMucmVnaW9uW3NlZWRdID0gbGFiZWw7XG4gICAgICBmb3IgKGxldCBpbmRleCA9IDAsIHF1ZXVlID0gW3NlZWRdOyBpbmRleCA8IHF1ZXVlLmxlbmd0aDsgaW5kZXggKz0gMSkge1xuICAgICAgICBjb25zdCBhdCA9IHF1ZXVlW2luZGV4XSE7XG4gICAgICAgIGZvciAobGV0IGRpcmVjdGlvbiA9IDA7IGRpcmVjdGlvbiA8IDg7IGRpcmVjdGlvbiArPSAxKSB7XG4gICAgICAgICAgY29uc3QgbmV4dCA9IGF0ICsgb2Zmc2V0c1tkaXJlY3Rpb25dITtcbiAgICAgICAgICBpZiAod2Fsa1tuZXh0XSAhPT0gMSB8fCB0aWxlcy5yZWdpb25bbmV4dF0gIT09IC0xIHx8IGxvY2FsKGJveCwgbmV4dCwgd2lkdGgpIDwgMCB8fCAhc3RlcEFsbG93ZWQoc3RhdGUsIGF0LCBkaXJlY3Rpb24pKSBjb250aW51ZTtcbiAgICAgICAgICB0aWxlcy5yZWdpb25bbmV4dF0gPSBsYWJlbDtcbiAgICAgICAgICBxdWV1ZS5wdXNoKG5leHQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIFRoZSBjb3B5J3MgaXNsYW5kczogdGhlIGFyZWFzIGEgd2FsayBqb2lucyBhdCBhbGwsIG51bWJlcmVkIGluIGNlbGwgb3JkZXIuXG5mdW5jdGlvbiBsYWJlbElzbGFuZHMoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMpIHtcbiAgY29uc3QgeyB3YWxrLCBvZmZzZXRzIH0gPSBzdGF0ZTtcbiAgdGlsZXMuaXNsYW5kLmZpbGwoLTEpO1xuICBjb25zdCBxdWV1ZSA9IG5ldyBJbnQzMkFycmF5KHdhbGsubGVuZ3RoKTtcbiAgZm9yIChsZXQgc2VlZCA9IDA7IHNlZWQgPCB3YWxrLmxlbmd0aDsgc2VlZCArPSAxKSB7XG4gICAgaWYgKHdhbGtbc2VlZF0gIT09IDEgfHwgdGlsZXMuaXNsYW5kW3NlZWRdICE9PSAtMSkgY29udGludWU7XG4gICAgdGlsZXMuaXNsYW5kW3NlZWRdID0gc2VlZDtcbiAgICBsZXQgdGFpbCA9IDA7XG4gICAgcXVldWVbdGFpbCsrXSA9IHNlZWQ7XG4gICAgZm9yIChsZXQgaGVhZCA9IDA7IGhlYWQgPCB0YWlsOyBoZWFkICs9IDEpIHtcbiAgICAgIGNvbnN0IGF0ID0gcXVldWVbaGVhZF0hO1xuICAgICAgZm9yIChsZXQgZGlyZWN0aW9uID0gMDsgZGlyZWN0aW9uIDwgODsgZGlyZWN0aW9uICs9IDEpIHtcbiAgICAgICAgY29uc3QgbmV4dCA9IGF0ICsgb2Zmc2V0c1tkaXJlY3Rpb25dITtcbiAgICAgICAgaWYgKHdhbGtbbmV4dF0gIT09IDEgfHwgdGlsZXMuaXNsYW5kW25leHRdICE9PSAtMSB8fCAhc3RlcEFsbG93ZWQoc3RhdGUsIGF0LCBkaXJlY3Rpb24pKSBjb250aW51ZTtcbiAgICAgICAgdGlsZXMuaXNsYW5kW25leHRdID0gc2VlZDtcbiAgICAgICAgcXVldWVbdGFpbCsrXSA9IG5leHQ7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIFRoZSB3aW5kb3dzIG9uIG9uZSBzcXVhcmUgZWRnZTogZXZlcnkgcnVuIG9mIGNlbGxzIG9wZW4gb24gYm90aCBzaWRlcyBvZiBpdCwgd2l0aCBpdHMgdHdvIHNpZGVzJyBub2RlcyAodGhlaXIgZmllbGRzXG4vLyBhbmQgZWRnZXMgY29tZSB3aXRoIHRoZWlyIHNxdWFyZXMsIHNlZSBsaW5rU2VjdG9yKS5cbmZ1bmN0aW9uIGxheVdpbmRvd3Moc3RhdGU6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMsIGJvcmRlcjogbnVtYmVyKSB7XG4gIGNvbnN0IHNlY3RvciA9IGJvcmRlciA+PiAxO1xuICBjb25zdCBsb3dlciA9IGJvcmRlciAmIDE7XG4gIGNvbnN0IGNvbCA9IHNlY3RvciAlIHRpbGVzLmNvbHVtbnM7XG4gIGNvbnN0IHJvdyA9IE1hdGguZmxvb3Ioc2VjdG9yIC8gdGlsZXMuY29sdW1ucyk7XG4gIGNvbnN0IGtleXM6IG51bWJlcltdID0gW107XG4gIHRpbGVzLmJvcmRlcnMuc2V0KGJvcmRlciwga2V5cyk7XG4gIGlmIChsb3dlciA/IHJvdyArIDEgPj0gdGlsZXMucm93cyA6IGNvbCArIDEgPj0gdGlsZXMuY29sdW1ucykgcmV0dXJuO1xuICBjb25zdCB7IHdhbGssIHdpZHRoIH0gPSBzdGF0ZTtcbiAgY29uc3QgYm94ID0gc2VjdG9yQm94KHN0YXRlLCB0aWxlcywgc2VjdG9yKTtcbiAgY29uc3QgYWNyb3NzID0gbG93ZXIgPyB3aWR0aCA6IDE7XG4gIGNvbnN0IHNwYW4gPSBsb3dlciA/IGJveC53aWR0aCA6IGJveC5oZWlnaHQ7XG4gIGNvbnN0IGZpcnN0ID0gbG93ZXIgPyAoYm94LnRvcCArIGJveC5oZWlnaHQgLSAxKSAqIHdpZHRoICsgYm94LmxlZnQgOiBib3gudG9wICogd2lkdGggKyBib3gubGVmdCArIGJveC53aWR0aCAtIDE7XG4gIGNvbnN0IGFsb25nID0gbG93ZXIgPyAxIDogd2lkdGg7XG4gIGxldCBydW46IG51bWJlcltdID0gW107XG4gIGNvbnN0IGNsb3NlID0gKCkgPT4ge1xuICAgIGlmIChydW4ubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgY29uc3Qga2V5ID0gcnVuWzBdISAqIDQgKyBsb3dlciAqIDI7XG4gICAga2V5cy5wdXNoKGtleSk7XG4gICAgY29uc3QgYmxhbmsgPSAoKTogQm94RmllbGQgPT4gKHsgYm94LCBkaXN0OiBuZXcgSW50MzJBcnJheSgwKSwgbmV4dDogbmV3IEludDMyQXJyYXkoMCkgfSk7XG4gICAgdGlsZXMubm9kZXMuc2V0KGtleSwgeyBrZXksIHNlY3RvciwgY2VsbHM6IHJ1biwgYWNyb3NzLCBmaWVsZDogYmxhbmsoKSwgZWRnZXM6IFtdIH0pO1xuICAgIGNvbnN0IG90aGVyID0gbG93ZXIgPyBzZWN0b3IgKyB0aWxlcy5jb2x1bW5zIDogc2VjdG9yICsgMTtcbiAgICB0aWxlcy5ub2Rlcy5zZXQoa2V5ICsgMSwgeyBrZXk6IGtleSArIDEsIHNlY3Rvcjogb3RoZXIsIGNlbGxzOiBydW4ubWFwKChjZWxsKSA9PiBjZWxsICsgYWNyb3NzKSwgYWNyb3NzOiAtYWNyb3NzLCBmaWVsZDogYmxhbmsoKSwgZWRnZXM6IFtdIH0pO1xuICAgIHJ1biA9IFtdO1xuICB9O1xuICBmb3IgKGxldCBzdGVwID0gMDsgc3RlcCA8IHNwYW47IHN0ZXAgKz0gMSkge1xuICAgIGNvbnN0IGF0ID0gZmlyc3QgKyBzdGVwICogYWxvbmc7XG4gICAgaWYgKHdhbGtbYXRdID09PSAxICYmIHdhbGtbYXQgKyBhY3Jvc3NdID09PSAxKSBydW4ucHVzaChhdCk7XG4gICAgZWxzZSBjbG9zZSgpO1xuICB9XG4gIGNsb3NlKCk7XG59XG5cbi8vIEEgc3F1YXJlJ3Mgd2luZG93IHNpZGVzLCBpbiBrZXkgb3JkZXI6IHRob3NlIG9uIGl0cyByaWdodCBhbmQgbG93ZXIgZWRnZXMgYW5kIHRob3NlIG9mIHRoZSBzcXVhcmVzIGxlZnQgb2YgYW5kIGFib3ZlIGl0LlxuZnVuY3Rpb24gc2VjdG9yTm9kZXModGlsZXM6IFRpbGVzLCBzZWN0b3I6IG51bWJlcik6IFRpbGVOb2RlW10ge1xuICBjb25zdCBjb2wgPSBzZWN0b3IgJSB0aWxlcy5jb2x1bW5zO1xuICBjb25zdCByb3cgPSBNYXRoLmZsb29yKHNlY3RvciAvIHRpbGVzLmNvbHVtbnMpO1xuICBjb25zdCBrZXlzID0gWy4uLih0aWxlcy5ib3JkZXJzLmdldChzZWN0b3IgKiAyKSA/PyBbXSksIC4uLih0aWxlcy5ib3JkZXJzLmdldChzZWN0b3IgKiAyICsgMSkgPz8gW10pXTtcbiAgaWYgKGNvbCA+IDApIGtleXMucHVzaCguLi4odGlsZXMuYm9yZGVycy5nZXQoKHNlY3RvciAtIDEpICogMikgPz8gW10pLm1hcCgoa2V5KSA9PiBrZXkgKyAxKSk7XG4gIGlmIChyb3cgPiAwKSBrZXlzLnB1c2goLi4uKHRpbGVzLmJvcmRlcnMuZ2V0KChzZWN0b3IgLSB0aWxlcy5jb2x1bW5zKSAqIDIgKyAxKSA/PyBbXSkubWFwKChrZXkpID0+IGtleSArIDEpKTtcbiAgcmV0dXJuIGtleXMuc29ydCgoYSwgYikgPT4gYSAtIGIpLm1hcCgoa2V5KSA9PiB0aWxlcy5ub2Rlcy5nZXQoa2V5KSEpO1xufVxuXG4vLyBFdmVyeSB3aW5kb3cgc2lkZSBvZiBhIHNxdWFyZTogaXRzIGZpZWxkIG92ZXIgdGhlIHNxdWFyZSwgYW5kIGl0cyBlZGdlcyB0byB0aGUgc3F1YXJlJ3Mgb3RoZXIgc2lkZXMgKHRoZSBjaGVhcGVzdCB3YXlcbi8vIGZyb20gdGhhdCBzaWRlJ3MgY2VsbHMgdG8gaXRzIG93bikuXG5mdW5jdGlvbiBsaW5rU2VjdG9yKHN0YXRlOiBUZXJyYWluUnVudGltZSwgdGlsZXM6IFRpbGVzLCBzZWN0b3I6IG51bWJlcikge1xuICBjb25zdCBib3ggPSBzZWN0b3JCb3goc3RhdGUsIHRpbGVzLCBzZWN0b3IpO1xuICBjb25zdCBub2RlcyA9IHNlY3Rvck5vZGVzKHRpbGVzLCBzZWN0b3IpO1xuICBmb3IgKGNvbnN0IG5vZGUgb2Ygbm9kZXMpIG5vZGUuZmllbGQgPSBncm93Qm94KHN0YXRlLCBib3gsIG5vZGUuY2VsbHMpO1xuICBmb3IgKGNvbnN0IGZyb20gb2Ygbm9kZXMpIHtcbiAgICBmcm9tLmVkZ2VzID0gW107XG4gICAgZm9yIChjb25zdCB0byBvZiBub2Rlcykge1xuICAgICAgaWYgKHRvID09PSBmcm9tKSBjb250aW51ZTtcbiAgICAgIGxldCBjb3N0ID0gVU5SRUFDSEVEO1xuICAgICAgZm9yIChjb25zdCBjZWxsIG9mIGZyb20uY2VsbHMpIGNvc3QgPSBNYXRoLm1pbihjb3N0LCB0by5maWVsZC5kaXN0W2xvY2FsKGJveCwgY2VsbCwgc3RhdGUud2lkdGgpXSEpO1xuICAgICAgaWYgKGNvc3QgPCBVTlJFQUNIRUQpIGZyb20uZWRnZXMucHVzaCh7IHRvOiB0by5rZXksIGNvc3QgfSk7XG4gICAgfVxuICB9XG59XG5cbi8vIEBAQHRlcnJhaW4tZmxvdyAtIFRoZSBjb3N0IGZyb20gZXZlcnkgY2VsbCBvZiBhIGJveCB0byB0aGUgbmVhcmVzdCBzZWVkLCBlYWNoIHNlZWQgc3RhcnRpbmcgYXQgaXRzIGNvc3QgKG5vbmU6IDApLCBieVxuLy8gRGlhbCdzIGFsZ29yaXRobSBvdmVyIGVpZ2h0IG5laWdoYm91cnMgd2l0aCBubyBjb3JuZXIgY3V0LCBhIHN0ZXAgcHJpY2VkIGJ5IHRoZSBncm91bmQgaXQgZW50ZXJzIChzZWUgR1JPVU5EX1dFSUdIVCkuXG4vLyBFYWNoIGRpcmVjdGlvbidzIHN0ZXAgaW4gY29sdW1ucyBhbmQgcm93cywgaW4gdGhlIG9yZGVyIG9mIGEgcnVudGltZSdzIG9mZnNldHMuXG5jb25zdCBTVEVQX0NPTFMgPSBbMSwgMCwgLTEsIDAsIDEsIC0xLCAtMSwgMV07XG5jb25zdCBTVEVQX1JPV1MgPSBbMCwgMSwgMCwgLTEsIDEsIDEsIC0xLCAtMV07XG5cbmZ1bmN0aW9uIGdyb3dCb3goc3RhdGU6IFRlcnJhaW5SdW50aW1lLCBib3g6IEJveCwgc2VlZHM6IG51bWJlcltdLCBjb3N0cz86IG51bWJlcltdKTogQm94RmllbGQge1xuICBjb25zdCBzaXplID0gYm94LndpZHRoICogYm94LmhlaWdodDtcbiAgcmV0dXJuIGdyb3dCb3hJbnRvKHN0YXRlLCBib3gsIHNlZWRzLCBjb3N0cywgeyBkaXN0OiBuZXcgSW50MzJBcnJheShzaXplKSwgbmV4dDogbmV3IEludDMyQXJyYXkoc2l6ZSkgfSk7XG59XG5cbmZ1bmN0aW9uIGdyb3dCb3hJbnRvKHN0YXRlOiBUZXJyYWluUnVudGltZSwgYm94OiBCb3gsIHNlZWRzOiBudW1iZXJbXSwgY29zdHM6IG51bWJlcltdIHwgdW5kZWZpbmVkLCBhcnJheXM6IFBpY2s8RmllbGQsICdkaXN0JyB8ICduZXh0Jz4pOiBCb3hGaWVsZCB7XG4gIGNvbnN0IHsgd2Fsaywgb2Zmc2V0cywgd2lkdGgsIHdlaWdodCB9ID0gc3RhdGU7XG4gIGNvbnN0IGNvbHVtbnMgPSBib3gud2lkdGg7XG4gIGNvbnN0IHJvd3MgPSBib3guaGVpZ2h0O1xuICBjb25zdCBvcmlnaW4gPSBib3gudG9wICogd2lkdGggKyBib3gubGVmdDtcbiAgY29uc3QgeyBkaXN0LCBuZXh0IH0gPSBhcnJheXM7XG4gIGRpc3QuZmlsbChVTlJFQUNIRUQpO1xuICBuZXh0LmZpbGwoVU5LTk9XTik7XG4gIGNvbnN0IGJ1Y2tldHMgPSBzdGF0ZS5ib3hCdWNrZXRzO1xuICBjb25zdCBvcmRlciA9IHNlZWRzLm1hcCgoXywgaW5kZXgpID0+IGluZGV4KTtcbiAgaWYgKGNvc3RzKSBvcmRlci5zb3J0KChhLCBiKSA9PiBjb3N0c1thXSEgLSBjb3N0c1tiXSEgfHwgYSAtIGIpO1xuICBjb25zdCBjb3N0T2YgPSAoaW5kZXg6IG51bWJlcikgPT4gKGNvc3RzID8gY29zdHNbb3JkZXJbaW5kZXhdIV0hIDogMCk7XG4gIGxldCBzZWVkZWQgPSAwO1xuICBsZXQgcGVuZGluZyA9IDA7XG4gIGZvciAobGV0IGNvc3QgPSBvcmRlci5sZW5ndGggPiAwID8gY29zdE9mKDApIDogMDsgcGVuZGluZyA+IDAgfHwgc2VlZGVkIDwgb3JkZXIubGVuZ3RoOyBjb3N0ICs9IDEpIHtcbiAgICBpZiAocGVuZGluZyA9PT0gMCkgY29zdCA9IGNvc3RPZihzZWVkZWQpO1xuICAgIGZvciAoOyBzZWVkZWQgPCBvcmRlci5sZW5ndGggJiYgY29zdE9mKHNlZWRlZCkgPT09IGNvc3Q7IHNlZWRlZCArPSAxKSB7XG4gICAgICBjb25zdCBpbmRleCA9IGxvY2FsKGJveCwgc2VlZHNbb3JkZXJbc2VlZGVkXSFdISwgd2lkdGgpO1xuICAgICAgaWYgKGluZGV4IDwgMCB8fCBjb3N0ID49IGRpc3RbaW5kZXhdISkgY29udGludWU7XG4gICAgICBkaXN0W2luZGV4XSA9IGNvc3Q7XG4gICAgICBidWNrZXRzW2Nvc3QgJSBCVUNLRVRTXSEucHVzaChpbmRleCk7XG4gICAgICBwZW5kaW5nICs9IDE7XG4gICAgfVxuICAgIGNvbnN0IGJ1Y2tldCA9IGJ1Y2tldHNbY29zdCAlIEJVQ0tFVFNdITtcbiAgICB3aGlsZSAoYnVja2V0Lmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGluZGV4ID0gYnVja2V0LnBvcCgpITtcbiAgICAgIHBlbmRpbmcgLT0gMTtcbiAgICAgIGlmIChkaXN0W2luZGV4XSAhPT0gY29zdCkgY29udGludWU7XG4gICAgICBjb25zdCBjb2wgPSBpbmRleCAlIGNvbHVtbnM7XG4gICAgICBjb25zdCByb3cgPSAoaW5kZXggLSBjb2wpIC8gY29sdW1ucztcbiAgICAgIGNvbnN0IGF0ID0gb3JpZ2luICsgcm93ICogd2lkdGggKyBjb2w7XG4gICAgICBmb3IgKGxldCBkaXJlY3Rpb24gPSAwOyBkaXJlY3Rpb24gPCA4OyBkaXJlY3Rpb24gKz0gMSkge1xuICAgICAgICBjb25zdCBzdGVwQ29sID0gY29sICsgU1RFUF9DT0xTW2RpcmVjdGlvbl0hO1xuICAgICAgICBjb25zdCBzdGVwUm93ID0gcm93ICsgU1RFUF9ST1dTW2RpcmVjdGlvbl0hO1xuICAgICAgICBpZiAoc3RlcENvbCA8IDAgfHwgc3RlcFJvdyA8IDAgfHwgc3RlcENvbCA+PSBjb2x1bW5zIHx8IHN0ZXBSb3cgPj0gcm93cykgY29udGludWU7XG4gICAgICAgIGNvbnN0IHN0ZXAgPSBhdCArIG9mZnNldHNbZGlyZWN0aW9uXSE7XG4gICAgICAgIGlmICh3YWxrW3N0ZXBdICE9PSAxKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgdGhlcmUgPSBzdGVwUm93ICogY29sdW1ucyArIHN0ZXBDb2w7XG4gICAgICAgIGNvbnN0IHJlYWNoZWQgPSBjb3N0ICsgKGRpcmVjdGlvbiA8IDQgPyBTVFJBSUdIVCA6IERJQUdPTkFMKSAqIHdlaWdodFtzdGVwXSE7XG4gICAgICAgIGlmIChyZWFjaGVkID49IGRpc3RbdGhlcmVdISB8fCAhc3RlcEFsbG93ZWQoc3RhdGUsIGF0LCBkaXJlY3Rpb24pKSBjb250aW51ZTtcbiAgICAgICAgZGlzdFt0aGVyZV0gPSByZWFjaGVkO1xuICAgICAgICBidWNrZXRzW3JlYWNoZWQgJSBCVUNLRVRTXSEucHVzaCh0aGVyZSk7XG4gICAgICAgIHBlbmRpbmcgKz0gMTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHsgYm94LCBkaXN0LCBuZXh0IH07XG59XG5cbi8vIFRoZSBuZWlnaGJvdXIgb25lIHN0ZXAgZG93biBhIGJveCBmaWVsZCAodGhlIGZpeGVkIG9yZGVyIG9mIGRpcmVjdGlvbnMgYnJlYWtzIHRpZXMpLCBvciAtMSBhdCBpdHMgYm90dG9tOyByZW1lbWJlcmVkLlxuZnVuY3Rpb24gZG93bmhpbGwoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCBmaWVsZDogQm94RmllbGQsIGF0OiBudW1iZXIpIHtcbiAgY29uc3QgeyB3YWxrLCBvZmZzZXRzLCB3aWR0aCB9ID0gc3RhdGU7XG4gIGNvbnN0IHsgYm94IH0gPSBmaWVsZDtcbiAgY29uc3QgaW5kZXggPSBsb2NhbChib3gsIGF0LCB3aWR0aCk7XG4gIGlmIChpbmRleCA8IDApIHJldHVybiAtMTtcbiAgY29uc3Qga25vd24gPSBmaWVsZC5uZXh0W2luZGV4XSE7XG4gIGlmIChrbm93biAhPT0gVU5LTk9XTikgcmV0dXJuIGtub3duO1xuICBjb25zdCBjb2wgPSBpbmRleCAlIGJveC53aWR0aDtcbiAgY29uc3Qgcm93ID0gKGluZGV4IC0gY29sKSAvIGJveC53aWR0aDtcbiAgbGV0IGJlc3QgPSAtMTtcbiAgbGV0IGJlc3RDb3N0ID0gZmllbGQuZGlzdFtpbmRleF0hO1xuICBmb3IgKGxldCBkaXJlY3Rpb24gPSAwOyBkaXJlY3Rpb24gPCA4OyBkaXJlY3Rpb24gKz0gMSkge1xuICAgIGNvbnN0IHN0ZXBDb2wgPSBjb2wgKyBTVEVQX0NPTFNbZGlyZWN0aW9uXSE7XG4gICAgY29uc3Qgc3RlcFJvdyA9IHJvdyArIFNURVBfUk9XU1tkaXJlY3Rpb25dITtcbiAgICBpZiAoc3RlcENvbCA8IDAgfHwgc3RlcFJvdyA8IDAgfHwgc3RlcENvbCA+PSBib3gud2lkdGggfHwgc3RlcFJvdyA+PSBib3guaGVpZ2h0KSBjb250aW51ZTtcbiAgICBjb25zdCBzdGVwID0gYXQgKyBvZmZzZXRzW2RpcmVjdGlvbl0hO1xuICAgIGNvbnN0IHRoZXJlID0gc3RlcFJvdyAqIGJveC53aWR0aCArIHN0ZXBDb2w7XG4gICAgaWYgKHdhbGtbc3RlcF0gIT09IDEgfHwgZmllbGQuZGlzdFt0aGVyZV0hID49IGJlc3RDb3N0IHx8ICFzdGVwQWxsb3dlZChzdGF0ZSwgYXQsIGRpcmVjdGlvbikpIGNvbnRpbnVlO1xuICAgIGJlc3RDb3N0ID0gZmllbGQuZGlzdFt0aGVyZV0hO1xuICAgIGJlc3QgPSBzdGVwO1xuICB9XG4gIGZpZWxkLm5leHRbaW5kZXhdID0gYmVzdDtcbiAgcmV0dXJuIGJlc3Q7XG59XG5cbi8vIFRoZSBnb2FsJ3Mgb3duIGZpZWxkLCBvdmVyIGl0cyBzcXVhcmUgYW5kIHRoZSBzcXVhcmVzIHJvdW5kIGl0LCBmcm9tIGl0cyBzZWVkcyAoc2VlIGdvYWxTZWVkcykuXG5mdW5jdGlvbiBnb2FsRmllbGRPZihzdGF0ZTogVGVycmFpblJ1bnRpbWUsIGdyb3VuZDogVGVycmFpblJ1bnRpbWUsIHRpbGVzOiBUaWxlcywgdGFyZ2V0OiBudW1iZXIpIHtcbiAgY29uc3Qga25vd24gPSB0aWxlcy5nb2Fscy5nZXQodGFyZ2V0KTtcbiAgaWYgKGtub3duKSB7XG4gICAgdGlsZXMuZ29hbHMuZGVsZXRlKHRhcmdldCk7XG4gICAgdGlsZXMuZ29hbHMuc2V0KHRhcmdldCwga25vd24pO1xuICAgIHJldHVybiBrbm93bjtcbiAgfVxuICBjb25zdCBzZWN0b3IgPSBzZWN0b3JPZihzdGF0ZSwgdGlsZXMsIHRhcmdldCk7XG4gIGNvbnN0IGNvbCA9IChzZWN0b3IgJSB0aWxlcy5jb2x1bW5zKSAqIFNFQ1RPUjtcbiAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihzZWN0b3IgLyB0aWxlcy5jb2x1bW5zKSAqIFNFQ1RPUjtcbiAgY29uc3QgbGVmdCA9IE1hdGgubWF4KDAsIGNvbCAtIFNFQ1RPUik7XG4gIGNvbnN0IHRvcCA9IE1hdGgubWF4KDAsIHJvdyAtIFNFQ1RPUik7XG4gIGNvbnN0IGJveCA9IHsgbGVmdDogbGVmdCArIDEsIHRvcDogdG9wICsgMSwgd2lkdGg6IE1hdGgubWluKHN0YXRlLnRlcnJhaW4uY29scywgY29sICsgMiAqIFNFQ1RPUikgLSBsZWZ0LCBoZWlnaHQ6IE1hdGgubWluKHN0YXRlLnRlcnJhaW4ucm93cywgcm93ICsgMiAqIFNFQ1RPUikgLSB0b3AgfTtcbiAgY29uc3QgeyBzZWVkcywgY29zdHMgfSA9IGdvYWxTZWVkcyhzdGF0ZSwgZ3JvdW5kLCB0YXJnZXQsIGJveCk7XG4gIGNvbnN0IGdvYWwgPSB7IGZpZWxkOiBncm93Qm94KHN0YXRlLCBib3gsIHNlZWRzLCBjb3N0cyksIHNlZWRzIH07XG4gIGlmICh0aWxlcy5nb2Fscy5zaXplID49IEdPQUxfRklFTERfQ0FDSEUpIHRpbGVzLmdvYWxzLmRlbGV0ZSh0aWxlcy5nb2Fscy5rZXlzKCkubmV4dCgpLnZhbHVlISk7XG4gIHRpbGVzLmdvYWxzLnNldCh0YXJnZXQsIGdvYWwpO1xuICByZXR1cm4gZ29hbDtcbn1cblxuLy8gVGhlIG9wZW4gY2VsbHMgb2YgdGhlIGNvcHkgYSB3YWxrIHRvIGB0YXJnZXRgIG1heSBlbmQgYXQsIGVhY2ggd2l0aCBpdHMgc3RyYWlnaHQgY29zdCB0byBpdCwgd2l0aGluIGBib3hgOiB0aGUgdGFyZ2V0XG4vLyBpdHNlbGYgd2hlbiBpdCBpcyBvcGVuOyB3aGVyZSBhIGJ1aWxkaW5nIGNvdmVycyBpdCAoYSBzaXRlIHRvIGJ1aWxkLCBhIGhhbGwgdG8gYnJpbmcgZ29sZCB0bywgb25lIHRvIHN0cmlrZSksIHRoZSBvcGVuXG4vLyBjZWxscyBiZXNpZGUgdGhhdCBidWlsZGluZyAob3IgdGhlIGJ1aWxkaW5ncyBpdCBzdGFuZHMgYWdhaW5zdCkgd2l0aGluIEdPQUxfUkVBQ0ggdGhhdCB0aGUgbGFuZCBqb2lucyB0byB0aGUgdGFyZ2V0XG4vLyB3aXRob3V0IHRoZSBidWlsZGluZ3MsIHNvIHRoZSB3YWxrIGVuZHMgYXQgdGhlIHdhbGwgb24gdGhlIHdhbGtlcidzIHNpZGUuIFRha2VuIGJ5IGRpc3RhbmNlIGFsb25lLCB0aGUgY2VsbHMgb24gYVxuLy8gcGxhdGVhdSBhYm92ZSBhIGZhcm0gYnVpbHQgdW5kZXIgaXRzIGNsaWZmIHdlcmUgdGhlIGZhcm0nczogYSB3b3JrZXIgdXAgdGhlcmUgc3Rvb2QgYXQgaXRzIHdhbGsncyBlbmQgYW5kIHdhbGtlZFxuLy8gc3RyYWlnaHQgYXQgdGhlIGNsaWZmIChWOCdzIG9uIHRoZSBvcGVuIGxhZGRlcikuIEV2ZXJ5IG9wZW4gY2VsbCB3aXRoaW4gR09BTF9SRUFDSCB3YXMgb25lOiBhIHdvcmtlciBzZW50IHRvIGEgZmFybSB0d29cbi8vIGNlbGxzIGJleW9uZCB0aGUgY29ybmVyIG9mIGl0cyBoYWxsIHN0b29kIGF0IHRoZSBoYWxsJ3MgZm9vdCBmb3IgZ29vZCwgYSBjZWxsIHRoZXJlIGl0cyB3YWxrJ3MgZW5kIGFuZCBub3doZXJlIG5lYXIgdGhlXG4vLyBmYXJtIChwb29sLXBpbmVzaGFkZS0xMCkuXG5mdW5jdGlvbiBnb2FsU2VlZHMoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCBncm91bmQ6IFRlcnJhaW5SdW50aW1lLCB0YXJnZXQ6IG51bWJlciwgYm94OiBCb3gpIHtcbiAgaWYgKHN0YXRlLndhbGtbdGFyZ2V0XSA9PT0gMSkgcmV0dXJuIHsgc2VlZHM6IFt0YXJnZXRdLCBjb3N0czogWzBdIH07XG4gIGNvbnN0IHsgd2lkdGgsIG9mZnNldHMgfSA9IHN0YXRlO1xuICBjb25zdCB0YXJnZXRDb2wgPSB0YXJnZXQgJSB3aWR0aDtcbiAgY29uc3QgdGFyZ2V0Um93ID0gTWF0aC5mbG9vcih0YXJnZXQgLyB3aWR0aCk7XG4gIGNvbnN0IHNxdWFyZSA9IHsgbGVmdDogdGFyZ2V0Q29sIC0gR09BTF9SRUFDSCwgdG9wOiB0YXJnZXRSb3cgLSBHT0FMX1JFQUNILCB3aWR0aDogMiAqIEdPQUxfUkVBQ0ggKyAxLCBoZWlnaHQ6IDIgKiBHT0FMX1JFQUNIICsgMSB9O1xuICBjb25zdCBzZWVkczogbnVtYmVyW10gPSBbXTtcbiAgY29uc3QgY29zdHM6IG51bWJlcltdID0gW107XG4gIGNvbnN0IGpvaW5lZCA9IG5ldyBTZXQoW3RhcmdldF0pO1xuICBmb3IgKGxldCBpbmRleCA9IDAsIHF1ZXVlID0gW3RhcmdldF07IGluZGV4IDwgcXVldWUubGVuZ3RoOyBpbmRleCArPSAxKSB7XG4gICAgY29uc3QgYXQgPSBxdWV1ZVtpbmRleF0hO1xuICAgIGlmIChzdGF0ZS53YWxrW2F0XSA9PT0gMSkge1xuICAgICAgaWYgKGxvY2FsKGJveCwgYXQsIHdpZHRoKSA+PSAwKSB7XG4gICAgICAgIHNlZWRzLnB1c2goYXQpO1xuICAgICAgICBjb3N0cy5wdXNoKE1hdGgucm91bmQoU1RSQUlHSFQgKiBHUk9VTkRfV0VJR0hUICogTWF0aC5zcXJ0KCgoYXQgJSB3aWR0aCkgLSB0YXJnZXRDb2wpICoqIDIgKyAoTWF0aC5mbG9vcihhdCAvIHdpZHRoKSAtIHRhcmdldFJvdykgKiogMikpKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBmb3IgKGxldCBkaXJlY3Rpb24gPSAwOyBkaXJlY3Rpb24gPCA4OyBkaXJlY3Rpb24gKz0gMSkge1xuICAgICAgY29uc3QgbmV4dCA9IGF0ICsgb2Zmc2V0c1tkaXJlY3Rpb25dITtcbiAgICAgIGlmIChqb2luZWQuaGFzKG5leHQpIHx8IGdyb3VuZC53YWxrW25leHRdICE9PSAxIHx8ICFzdGVwQWxsb3dlZChncm91bmQsIGF0LCBkaXJlY3Rpb24pIHx8IGxvY2FsKHNxdWFyZSwgbmV4dCwgd2lkdGgpIDwgMCkgY29udGludWU7XG4gICAgICBqb2luZWQuYWRkKG5leHQpO1xuICAgICAgcXVldWUucHVzaChuZXh0KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHsgc2VlZHMsIGNvc3RzIH07XG59XG5cbi8vIFRoZSBjZWxsIGEgd2FsayBmcm9tIGBuZWFyYCB0byBgdGFyZ2V0YCBoZWFkcyBmb3I6IHRoZSB0YXJnZXQgd2hlbiB0aGUgdW5pdCdzIGlzbGFuZCByZWFjaGVzIGl0IChvbmUgb2YgaXRzIHNlZWRzIGlzIG9uXG4vLyB0aGUgaXNsYW5kKSwgZWxzZSB0aGUgaXNsYW5kJ3MgY2VsbCBuZWFyZXN0IGl0LCBzbyBhIHdhbGsgdG8gYSBwb2ludCBpdCBjYW5ub3QgcmVhY2ggKGFjcm9zcyBhIGNsaWZmLCBpbnNpZGUgYSB3YWxsIG9mXG4vLyBidWlsZGluZ3MpIGdvZXMgYXMgbmVhciBhcyBpdCBjYW4gYW5kIHN0YW5kcyB0aGVyZSBpbnN0ZWFkIG9mIHByZXNzaW5nIGFnYWluc3Qgd2hhdCBpcyBpbiBpdHMgd2F5LlxuZnVuY3Rpb24gcmVhY2hhYmxlVGFyZ2V0KHN0YXRlOiBUZXJyYWluUnVudGltZSwgZ3JvdW5kOiBUZXJyYWluUnVudGltZSwgdGlsZXM6IFRpbGVzLCBuZWFyOiBudW1iZXIsIHRhcmdldDogbnVtYmVyKSB7XG4gIGNvbnN0IGlzbGFuZCA9IHRpbGVzLmlzbGFuZFtuZWFyXSE7XG4gIC8vIEFuIG9wZW4gdGFyZ2V0IGlzIGl0cyBvd24gc29sZSBzZWVkOyBjb25uZWN0aXZpdHkgYWxvbmUgYW5zd2VycyB0aGlzIHF1ZXJ5LlxuICBpZiAoc3RhdGUud2Fsa1t0YXJnZXRdID09PSAxICYmIHRpbGVzLmlzbGFuZFt0YXJnZXRdID09PSBpc2xhbmQpIHJldHVybiB0YXJnZXQ7XG4gIGlmIChnb2FsRmllbGRPZihzdGF0ZSwgZ3JvdW5kLCB0aWxlcywgdGFyZ2V0KS5zZWVkcy5zb21lKChzZWVkKSA9PiB0aWxlcy5pc2xhbmRbc2VlZF0gPT09IGlzbGFuZCkpIHJldHVybiB0YXJnZXQ7XG4gIGNvbnN0IGtleSA9IHRhcmdldCAqIHN0YXRlLndhbGsubGVuZ3RoICsgaXNsYW5kO1xuICBjb25zdCBrbm93biA9IHRpbGVzLm5lYXJlc3QuZ2V0KGtleSk7XG4gIGlmIChrbm93biAhPT0gdW5kZWZpbmVkKSByZXR1cm4ga25vd247XG4gIGNvbnN0IHsgdGVycmFpbiwgd2lkdGggfSA9IHN0YXRlO1xuICBjb25zdCBjb2wgPSAodGFyZ2V0ICUgd2lkdGgpIC0gMTtcbiAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcih0YXJnZXQgLyB3aWR0aCkgLSAxO1xuICBsZXQgYmVzdCA9IG5lYXI7XG4gIGxldCBiZXN0RGlzdGFuY2UgPSBJbmZpbml0eTtcbiAgZm9yIChsZXQgcmluZyA9IDE7IHJpbmcgPD0gTWF0aC5tYXgodGVycmFpbi5jb2xzLCB0ZXJyYWluLnJvd3MpICYmIHJpbmcgKiByaW5nIDw9IGJlc3REaXN0YW5jZTsgcmluZyArPSAxKSB7XG4gICAgZm9yIChsZXQgciA9IHJvdyAtIHJpbmc7IHIgPD0gcm93ICsgcmluZzsgciArPSAxKSB7XG4gICAgICBmb3IgKGxldCBjID0gY29sIC0gcmluZzsgYyA8PSBjb2wgKyByaW5nOyBjICs9IDEpIHtcbiAgICAgICAgaWYgKE1hdGgubWF4KE1hdGguYWJzKGMgLSBjb2wpLCBNYXRoLmFicyhyIC0gcm93KSkgIT09IHJpbmcgfHwgYyA8IDAgfHwgciA8IDAgfHwgYyA+PSB0ZXJyYWluLmNvbHMgfHwgciA+PSB0ZXJyYWluLnJvd3MpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBhdCA9IHBhZChzdGF0ZSwgYywgcik7XG4gICAgICAgIGlmICh0aWxlcy5pc2xhbmRbYXRdICE9PSBpc2xhbmQpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBnYXAgPSAoYyAtIGNvbCkgKiogMiArIChyIC0gcm93KSAqKiAyO1xuICAgICAgICBpZiAoZ2FwIDwgYmVzdERpc3RhbmNlIHx8IChnYXAgPT09IGJlc3REaXN0YW5jZSAmJiBhdCA8IGJlc3QpKSB7XG4gICAgICAgICAgYmVzdERpc3RhbmNlID0gZ2FwO1xuICAgICAgICAgIGJlc3QgPSBhdDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAodGlsZXMubmVhcmVzdC5zaXplID4gNF8wOTYpIHRpbGVzLm5lYXJlc3QuY2xlYXIoKTtcbiAgdGlsZXMubmVhcmVzdC5zZXQoa2V5LCBiZXN0KTtcbiAgcmV0dXJuIGJlc3Q7XG59XG5cbi8vIFRoZSB3aW5kb3cgc2lkZSB0aGUgcmVnaW9uJ3Mgd2FsayB0byBgdGFyZ2V0YCBsZWF2ZXMgaXRzIHNxdWFyZSBieTogQSogb3ZlciB0aGUgd2luZG93cyBmcm9tIGV2ZXJ5IHNpZGUgb2YgdGhlIHJlZ2lvblxuLy8gKG9uZSBhbnN3ZXIgZm9yIHRoZSB3aG9sZSByZWdpb24sIGtlcHQpLCB0byB0aGUgZ29hbCdzIGZpZWxkIHdoZXJldmVyIGEgc2lkZSdzIGNlbGxzIGxpZSBpbiBpdC5cbmZ1bmN0aW9uIGV4aXRGb3Ioc3RhdGU6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMsIHJlZ2lvbjogbnVtYmVyLCB0YXJnZXQ6IG51bWJlciwgZ29hbDogQm94RmllbGQpOiBUaWxlTm9kZSB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGtleSA9IHRhcmdldCAqIHRpbGVzLmNvbHVtbnMgKiB0aWxlcy5yb3dzICogTUFYX1JFR0lPTlMgKyByZWdpb247XG4gIGxldCBleGl0ID0gdGlsZXMuZXhpdHMuZ2V0KGtleSk7XG4gIGlmIChleGl0ID09PSB1bmRlZmluZWQpIHtcbiAgICBleGl0ID0gc2VhcmNoRXhpdChzdGF0ZSwgdGlsZXMsIHJlZ2lvbiwgdGFyZ2V0LCBnb2FsKTtcbiAgICBpZiAodGlsZXMuZXhpdHMuc2l6ZSA+IDY1XzUzNikgdGlsZXMuZXhpdHMuY2xlYXIoKTtcbiAgICB0aWxlcy5leGl0cy5zZXQoa2V5LCBleGl0KTtcbiAgfVxuICByZXR1cm4gZXhpdCA8IDAgPyB1bmRlZmluZWQgOiB0aWxlcy5ub2Rlcy5nZXQoZXhpdCk7XG59XG5cbmZ1bmN0aW9uIHNlYXJjaEV4aXQoc3RhdGU6IFRlcnJhaW5SdW50aW1lLCB0aWxlczogVGlsZXMsIHJlZ2lvbjogbnVtYmVyLCB0YXJnZXQ6IG51bWJlciwgZ29hbDogQm94RmllbGQpOiBudW1iZXIge1xuICBjb25zdCB3aWR0aCA9IHN0YXRlLndpZHRoO1xuICBjb25zdCB0YXJnZXRDb2wgPSB0YXJnZXQgJSB3aWR0aDtcbiAgY29uc3QgdGFyZ2V0Um93ID0gTWF0aC5mbG9vcih0YXJnZXQgLyB3aWR0aCk7XG4gIC8vIE9jdGlsZSBjZWxscyB0byB0aGUgdGFyZ2V0IGF0IGJhcmUgZ3JvdW5kJ3MgcHJpY2UgZnJvbSB0aGUgd2luZG93J3MgY2VsbCBuZWFyZXN0IGl0OiBubyB3YWxrIGlzIGNoZWFwZXIuIFRha2VuIGZyb21cbiAgLy8gdGhlIHdpbmRvdydzIGZpcnN0IGNlbGwsIGl0IHByaWNlZCBhIGxvbmcgd2luZG93IHVwIHRvIG5pbmUgY2VsbHMgdG9vIGRlYXIsIHRoZSBzZWFyY2ggY2FtZSBvdXQgdGhlIHdyb25nIHdheSwgYW5kIHRoZVxuICAvLyB0d28gc2lkZXMgb2YgYSBzdHJpcCBvbiBhIHNxdWFyZXMnIGJvcmRlciBlYWNoIHNlbnQgdGhlIHdhbGsgYWNyb3NzIHRvIHRoZSBvdGhlcjogdW5pdHMgc3Rvb2Qgb24gaXQgZm9yIGdvb2QsIHRoZVxuICAvLyB3YWxrIGNyb3NzaW5nIGFuZCBjcm9zc2luZyBiYWNrIHdpdGhpbiBvbmUgbG9vayBhaGVhZCAocG9vbC1zdGlsbHdhdGVyLTIsIGEgc3RyaXAgYXQgeCAzODQwLCBlaWdodCBzb2xkaWVycyBpbiBhIHJvdykuXG4gIC8vIEEgd2luZG93IHJlYWNoZWQgYWdhaW4gbW9yZSBjaGVhcGx5IGlzIHNlYXJjaGVkIG9uIGZyb20gdGhlcmUgYWdhaW4uXG4gIGNvbnN0IGVzdGltYXRlID0gKG5vZGU6IFRpbGVOb2RlKSA9PiB7XG4gICAgbGV0IGxlYXN0ID0gVU5SRUFDSEVEO1xuICAgIGZvciAoY29uc3QgY2VsbCBvZiBub2RlLmNlbGxzKSB7XG4gICAgICBjb25zdCBkeCA9IE1hdGguYWJzKChjZWxsICUgd2lkdGgpIC0gdGFyZ2V0Q29sKTtcbiAgICAgIGNvbnN0IGR5ID0gTWF0aC5hYnMoTWF0aC5mbG9vcihjZWxsIC8gd2lkdGgpIC0gdGFyZ2V0Um93KTtcbiAgICAgIGxlYXN0ID0gTWF0aC5taW4obGVhc3QsIChESUFHT05BTCAqIE1hdGgubWluKGR4LCBkeSkgKyBTVFJBSUdIVCAqIChNYXRoLm1heChkeCwgZHkpIC0gTWF0aC5taW4oZHgsIGR5KSkpICogR1JPVU5EX1dFSUdIVCk7XG4gICAgfVxuICAgIHJldHVybiBsZWFzdDtcbiAgfTtcbiAgY29uc3Qgc2VjdG9yID0gTWF0aC5mbG9vcihyZWdpb24gLyBNQVhfUkVHSU9OUyk7XG4gIGNvbnN0IGNvc3QgPSBuZXcgTWFwPG51bWJlciwgbnVtYmVyPigpO1xuICBjb25zdCBwYXJlbnQgPSBuZXcgTWFwPG51bWJlciwgbnVtYmVyPigpO1xuICBjb25zdCBoZWFwID0gbmV3IEZyb250aWVyKCk7XG4gIGZvciAoY29uc3Qgbm9kZSBvZiBzZWN0b3JOb2Rlcyh0aWxlcywgc2VjdG9yKSkge1xuICAgIGlmICh0aWxlcy5yZWdpb25bbm9kZS5jZWxsc1swXSFdICE9PSByZWdpb24pIGNvbnRpbnVlO1xuICAgIGNvc3Quc2V0KG5vZGUua2V5LCAwKTtcbiAgICBwYXJlbnQuc2V0KG5vZGUua2V5LCAtMSk7XG4gICAgaGVhcC5wdXNoKGVzdGltYXRlKG5vZGUpLCBub2RlLmtleSk7XG4gIH1cbiAgbGV0IGZpbmlzaCA9IC0xO1xuICBsZXQgZmluaXNoQ29zdCA9IFVOUkVBQ0hFRDtcbiAgY29uc3QgcmVsYXggPSAoZnJvbTogbnVtYmVyLCB0bzogbnVtYmVyLCB0aHJvdWdoOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBub2RlID0gdGlsZXMubm9kZXMuZ2V0KHRvKTtcbiAgICBpZiAoIW5vZGUgfHwgdGhyb3VnaCA+PSAoY29zdC5nZXQodG8pID8/IFVOUkVBQ0hFRCkpIHJldHVybjtcbiAgICBjb3N0LnNldCh0bywgdGhyb3VnaCk7XG4gICAgcGFyZW50LnNldCh0bywgZnJvbSk7XG4gICAgaGVhcC5wdXNoKHRocm91Z2ggKyBlc3RpbWF0ZShub2RlKSwgdG8pO1xuICB9O1xuICBmb3IgKDs7KSB7XG4gICAgY29uc3Qga2V5ID0gaGVhcC5wb3AoKTtcbiAgICBpZiAoa2V5ID09PSB1bmRlZmluZWQpIHJldHVybiAtMTtcbiAgICBpZiAoa2V5ID09PSAtMSkgYnJlYWs7XG4gICAgY29uc3Qgbm9kZSA9IHRpbGVzLm5vZGVzLmdldChrZXkpITtcbiAgICBjb25zdCBoZXJlID0gY29zdC5nZXQoa2V5KSE7XG4gICAgbGV0IGVuZCA9IFVOUkVBQ0hFRDtcbiAgICBmb3IgKGNvbnN0IGNlbGwgb2Ygbm9kZS5jZWxscykge1xuICAgICAgY29uc3QgaW5kZXggPSBsb2NhbChnb2FsLmJveCwgY2VsbCwgd2lkdGgpO1xuICAgICAgaWYgKGluZGV4ID49IDApIGVuZCA9IE1hdGgubWluKGVuZCwgZ29hbC5kaXN0W2luZGV4XSEpO1xuICAgIH1cbiAgICBpZiAoZW5kIDwgVU5SRUFDSEVEICYmIGhlcmUgKyBlbmQgPCBmaW5pc2hDb3N0KSB7XG4gICAgICBmaW5pc2hDb3N0ID0gaGVyZSArIGVuZDtcbiAgICAgIGZpbmlzaCA9IGtleTtcbiAgICAgIGhlYXAucHVzaChmaW5pc2hDb3N0LCAtMSk7XG4gICAgfVxuICAgIGNvbnN0IHBhaXIgPSB0aWxlcy5ub2Rlcy5nZXQoa2V5IF4gMSk7XG4gICAgaWYgKHBhaXIpIHJlbGF4KGtleSwga2V5IF4gMSwgaGVyZSArIFNUUkFJR0hUICogR1JPVU5EX1dFSUdIVCk7XG4gICAgZm9yIChjb25zdCBlZGdlIG9mIG5vZGUuZWRnZXMpIHJlbGF4KGtleSwgZWRnZS50bywgaGVyZSArIGVkZ2UuY29zdCk7XG4gIH1cbiAgLy8gVGhlIHNpZGUgdGhlIHdheSBsZWF2ZXMgdGhlIHJlZ2lvbidzIHNxdWFyZSBieTogdGhlIGxhc3Qgb2YgdGhlIHNxdWFyZSdzIGJlZm9yZSB0aGUgZmlyc3QgY3Jvc3NpbmcuXG4gIGNvbnN0IHBhdGg6IG51bWJlcltdID0gW107XG4gIGZvciAobGV0IGF0ID0gZmluaXNoOyBhdCAhPT0gLTE7IGF0ID0gcGFyZW50LmdldChhdCkhKSBwYXRoLnB1c2goYXQpO1xuICBwYXRoLnJldmVyc2UoKTtcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCArIDEgPCBwYXRoLmxlbmd0aDsgaW5kZXggKz0gMSkgaWYgKHBhdGhbaW5kZXggKyAxXSA9PT0gKHBhdGhbaW5kZXhdISBeIDEpKSByZXR1cm4gcGF0aFtpbmRleF0hO1xuICByZXR1cm4gcGF0aFtwYXRoLmxlbmd0aCAtIDFdITtcbn1cblxuLy8gQSBiaW5hcnkgaGVhcCBvZiAocHJpb3JpdHksIGtleSksIHRoZSBsb3dlciBrZXkgZmlyc3QgYW1vbmcgZXF1YWwgcHJpb3JpdGllcywgc28gYSBzZWFyY2ggZ29lcyB0aGUgc2FtZSB3YXkgZXZlcnkgdGltZS5cbmNsYXNzIEZyb250aWVyIHtcbiAgcHJpdmF0ZSBpdGVtczogW251bWJlciwgbnVtYmVyXVtdID0gW107XG4gIHB1c2gocHJpb3JpdHk6IG51bWJlciwga2V5OiBudW1iZXIpIHtcbiAgICBjb25zdCBpdGVtcyA9IHRoaXMuaXRlbXM7XG4gICAgaXRlbXMucHVzaChbcHJpb3JpdHksIGtleV0pO1xuICAgIGZvciAobGV0IGF0ID0gaXRlbXMubGVuZ3RoIC0gMTsgYXQgPiAwOyApIHtcbiAgICAgIGNvbnN0IHVwID0gKGF0IC0gMSkgPj4gMTtcbiAgICAgIGlmICghYmVmb3JlKGl0ZW1zW2F0XSEsIGl0ZW1zW3VwXSEpKSBicmVhaztcbiAgICAgIFtpdGVtc1thdF0sIGl0ZW1zW3VwXV0gPSBbaXRlbXNbdXBdISwgaXRlbXNbYXRdIV07XG4gICAgICBhdCA9IHVwO1xuICAgIH1cbiAgfVxuICBwb3AoKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgICBjb25zdCBpdGVtcyA9IHRoaXMuaXRlbXM7XG4gICAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjb25zdCB0b3AgPSBpdGVtc1swXSFbMV07XG4gICAgY29uc3QgbGFzdCA9IGl0ZW1zLnBvcCgpITtcbiAgICBpZiAoaXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgaXRlbXNbMF0gPSBsYXN0O1xuICAgICAgZm9yIChsZXQgYXQgPSAwOyA7ICkge1xuICAgICAgICBjb25zdCBsZWZ0ID0gMiAqIGF0ICsgMTtcbiAgICAgICAgY29uc3QgcmlnaHQgPSBsZWZ0ICsgMTtcbiAgICAgICAgbGV0IGxlYXN0ID0gYXQ7XG4gICAgICAgIGlmIChsZWZ0IDwgaXRlbXMubGVuZ3RoICYmIGJlZm9yZShpdGVtc1tsZWZ0XSEsIGl0ZW1zW2xlYXN0XSEpKSBsZWFzdCA9IGxlZnQ7XG4gICAgICAgIGlmIChyaWdodCA8IGl0ZW1zLmxlbmd0aCAmJiBiZWZvcmUoaXRlbXNbcmlnaHRdISwgaXRlbXNbbGVhc3RdISkpIGxlYXN0ID0gcmlnaHQ7XG4gICAgICAgIGlmIChsZWFzdCA9PT0gYXQpIGJyZWFrO1xuICAgICAgICBbaXRlbXNbYXRdLCBpdGVtc1tsZWFzdF1dID0gW2l0ZW1zW2xlYXN0XSEsIGl0ZW1zW2F0XSFdO1xuICAgICAgICBhdCA9IGxlYXN0O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdG9wO1xuICB9XG59XG5cbmZ1bmN0aW9uIGJlZm9yZShhOiBbbnVtYmVyLCBudW1iZXJdLCBiOiBbbnVtYmVyLCBudW1iZXJdKSB7XG4gIHJldHVybiBhWzBdIDwgYlswXSB8fCAoYVswXSA9PT0gYlswXSAmJiBhWzFdIDwgYlsxXSk7XG59XG5cbi8vIFRoZSB3YWxraW5nIGRpc3RhbmNlIChpbiB3b3JsZCB1bml0cywgYWxvbmcgdGhlIGZsb3cpIGZyb20gYSBwb2ludCB0byBhIGdvYWwsIG9yIHVuZGVmaW5lZCB3aGVuIG5vIHdhbGsgam9pbnMgdGhlbS4gQVxuLy8gbWFwIHdpdGhvdXQgdGVycmFpbiBtZWFzdXJlcyB0aGUgc3RyYWlnaHQgbGluZS4gSXQgcmVhZHMgdGhlIHRlcnJhaW4gYWxvbmUgKHNlZSBAQEBidWlsZGluZy1wYXRoaW5nKS5cbmV4cG9ydCBmdW5jdGlvbiB3YWxraW5nRGlzdGFuY2UobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgZnJvbTogUG9pbnQsIGdvYWw6IFBvaW50LCBtb3ZlcjogTW92ZXIgPSBcImxhbmRcIik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IHRlcnJhaW4gPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0ZXJyYWluKSByZXR1cm4gTWF0aC5zcXJ0KChmcm9tLnggLSBnb2FsLngpICoqIDIgKyAoZnJvbS55IC0gZ29hbC55KSAqKiAyKTtcbiAgY29uc3Qgc3RhdGUgPSBydW50aW1lKHRlcnJhaW4sIG1vdmVyKTtcbiAgY29uc3Qgc3RhcnQgPSBwYWRBdChzdGF0ZSwgZnJvbS54LCBmcm9tLnkpO1xuICBjb25zdCB0YXJnZXQgPSBwYWRBdChzdGF0ZSwgZ29hbC54LCBnb2FsLnkpO1xuICBpZiAoc3RhdGUud2Fsa1tzdGFydF0gIT09IDEgfHwgc3RhdGUud2Fsa1t0YXJnZXRdICE9PSAxKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBjb3N0ID0gZXhhY3RGaWVsZChzdGF0ZSwgdGFyZ2V0KS5kaXN0W3N0YXJ0XSE7XG4gIHJldHVybiBjb3N0ID49IFVOUkVBQ0hFRCA/IHVuZGVmaW5lZCA6IChjb3N0ICogdGVycmFpbi5jZWxsKSAvIFNUUkFJR0hUO1xufVxuXG4vKiogQ29udGludW91cyB0cmF2ZWwgY29zdCBvZiBhIGNsZWFyIGxhbmQgc2VnbWVudCwgaW4gZXF1aXZhbGVudCBiYXJlLWdyb3VuZCB1bml0cy5cbiAqIFRoZSBjYWxsZXIgc3VwcGxpZXMgd2Fsa2FibGUgdGVycmFpbjsgc3RhdHVzLCBhcnJpdmFsIHRvbGVyYW5jZSBhbmQgcGVyLXRpY2tcbiAqIGJvdW5kYXJ5IHJvdW5kaW5nIGJlbG9uZyB0byBhY3R1YWwgbW92ZW1lbnQuICovXG5leHBvcnQgZnVuY3Rpb24gZ3JvdW5kU2VnbWVudFRyYXZlbENvc3QobWFwOiBQaWNrPEdhbWVNYXAsICd0ZXJyYWluJz4sIGZyb206IFBvaW50LCBnb2FsOiBQb2ludCk6IG51bWJlciB7XG4gIHJldHVybiBncm91bmRTZWdtZW50UHJvZ3Jlc3MobWFwLCBmcm9tLCBnb2FsLCBJbmZpbml0eSkuY29zdDtcbn1cblxuLyoqIENvbnRpbnVvdXMgcG9zaXRpb24gb24gYSBjbGVhciBzZWdtZW50IGFmdGVyIHNwZW5kaW5nIGVxdWl2YWxlbnQgYmFyZS1ncm91bmQgZGlzdGFuY2UuICovXG5leHBvcnQgZnVuY3Rpb24gZ3JvdW5kU2VnbWVudEFkdmFuY2UobWFwOiBQaWNrPEdhbWVNYXAsICd0ZXJyYWluJz4sIGZyb206IFBvaW50LCBnb2FsOiBQb2ludCwgYnVkZ2V0OiBudW1iZXIpOiBQb2ludCB7XG4gIGNvbnN0IHsgZnJhY3Rpb24gfSA9IGdyb3VuZFNlZ21lbnRQcm9ncmVzcyhtYXAsIGZyb20sIGdvYWwsIGJ1ZGdldCk7XG4gIHJldHVybiBmcmFjdGlvbiA9PT0gMSA/IGdvYWwgOiB7IHg6IGZyb20ueCArIChnb2FsLnggLSBmcm9tLngpICogZnJhY3Rpb24sIHk6IGZyb20ueSArIChnb2FsLnkgLSBmcm9tLnkpICogZnJhY3Rpb24gfTtcbn1cblxuZnVuY3Rpb24gZ3JvdW5kU2VnbWVudFByb2dyZXNzKG1hcDogUGljazxHYW1lTWFwLCAndGVycmFpbic+LCBmcm9tOiBQb2ludCwgZ29hbDogUG9pbnQsIGJ1ZGdldDogbnVtYmVyKSB7XG4gIGNvbnN0IGR4ID0gZ29hbC54IC0gZnJvbS54LCBkeSA9IGdvYWwueSAtIGZyb20ueSwgbGVuZ3RoID0gTWF0aC5oeXBvdChkeCwgZHkpLCB0ZXJyYWluID0gbWFwLnRlcnJhaW47XG4gIGlmICghdGVycmFpbiB8fCBsZW5ndGggPT09IDApIHJldHVybiB7IGNvc3Q6IE1hdGgubWluKGxlbmd0aCwgYnVkZ2V0KSwgZnJhY3Rpb246IGxlbmd0aCA9PT0gMCA/IDEgOiBNYXRoLm1pbigxLCBidWRnZXQgLyBsZW5ndGgpIH07XG4gIGNvbnN0IGNlbGwgPSB0ZXJyYWluLmNlbGwsIHN0ZXBYID0gTWF0aC5zaWduKGR4KSwgc3RlcFkgPSBNYXRoLnNpZ24oZHkpO1xuICBsZXQgY29sID0gTWF0aC5mbG9vcihmcm9tLnggLyBjZWxsKSwgcm93ID0gTWF0aC5mbG9vcihmcm9tLnkgLyBjZWxsKTtcbiAgaWYgKGR4IDwgMCAmJiBmcm9tLnggPT09IGNvbCAqIGNlbGwpIGNvbC0tO1xuICBpZiAoZHkgPCAwICYmIGZyb20ueSA9PT0gcm93ICogY2VsbCkgcm93LS07XG4gIGxldCBuZXh0WCA9IGR4ID09PSAwID8gSW5maW5pdHkgOiAoKGNvbCArIE51bWJlcihkeCA+IDApKSAqIGNlbGwgLSBmcm9tLngpIC8gZHg7XG4gIGxldCBuZXh0WSA9IGR5ID09PSAwID8gSW5maW5pdHkgOiAoKHJvdyArIE51bWJlcihkeSA+IDApKSAqIGNlbGwgLSBmcm9tLnkpIC8gZHk7XG4gIGNvbnN0IHNwYW5YID0gY2VsbCAvIE1hdGguYWJzKGR4KSwgc3BhblkgPSBjZWxsIC8gTWF0aC5hYnMoZHkpO1xuICBsZXQgYXQgPSAwLCBjb3N0ID0gMDtcbiAgd2hpbGUgKGF0IDwgMSkge1xuICAgIGNvbnN0IGVuZCA9IE1hdGgubWluKDEsIG5leHRYLCBuZXh0WSk7XG4gICAgY29uc3QgcGFjZSA9IENFTExfR1JPVU5EW3RlcnJhaW4uY2VsbHNbcm93ICogdGVycmFpbi5jb2xzICsgY29sXSFdIS5wYWNlO1xuICAgIGNvbnN0IG5leHQgPSBjb3N0ICsgKGVuZCAtIGF0KSAqIGxlbmd0aCAvIHBhY2U7XG4gICAgaWYgKG5leHQgPj0gYnVkZ2V0KSByZXR1cm4geyBjb3N0OiBidWRnZXQsIGZyYWN0aW9uOiBhdCArIChidWRnZXQgLSBjb3N0KSAqIHBhY2UgLyBsZW5ndGggfTtcbiAgICBjb3N0ID0gbmV4dDtcbiAgICBpZiAoZW5kID09PSBuZXh0WCkgeyBjb2wgKz0gc3RlcFg7IG5leHRYICs9IHNwYW5YOyB9XG4gICAgaWYgKGVuZCA9PT0gbmV4dFkpIHsgcm93ICs9IHN0ZXBZOyBuZXh0WSArPSBzcGFuWTsgfVxuICAgIGF0ID0gZW5kO1xuICB9XG4gIHJldHVybiB7IGNvc3QsIGZyYWN0aW9uOiAxIH07XG59XG5cbi8qKiBHcm91bmQgdHJhdmVsIGNvc3QgaW4gZXF1aXZhbGVudCBiYXJlLWdyb3VuZCB1bml0cy4gQSBjbGVhciBzdHJhaWdodCBzZWdtZW50XG4gKiB1c2VzIGFjdHVhbCB0ZXJyYWluIHBhY2U7IGEgZGV0b3VyIHVzZXMgdGhlIHN0ZWVyaW5nIGdyaWQncyBxdWFudGl6ZWQgd2VpZ2h0cy5cbiAqIEV4Y2x1ZGVzIGJvZHkgZGV0b3VycyBhbmQgc3RhdHVzIGVmZmVjdHMuICovXG5leHBvcnQgZnVuY3Rpb24gZ3JvdW5kVHJhdmVsQ29zdChtYXA6IFBpY2s8R2FtZU1hcCwgJ3RlcnJhaW4nPiwgZnJvbTogUG9pbnQsIGdvYWw6IFBvaW50KTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiBNYXRoLmh5cG90KGZyb20ueCAtIGdvYWwueCwgZnJvbS55IC0gZ29hbC55KTtcbiAgY29uc3Qgc3RhdGUgPSBydW50aW1lKHRlcnJhaW4sICdsYW5kJyksIHN0YXJ0ID0gcGFkQXQoc3RhdGUsIGZyb20ueCwgZnJvbS55KSwgdGFyZ2V0ID0gcGFkQXQoc3RhdGUsIGdvYWwueCwgZ29hbC55KTtcbiAgaWYgKHN0YXRlLndhbGtbc3RhcnRdICE9PSAxIHx8IHN0YXRlLndhbGtbdGFyZ2V0XSAhPT0gMSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKGNsZWFyU2VnbWVudChzdGF0ZSwgZnJvbS54LCBmcm9tLnksIGdvYWwueCwgZ29hbC55KSkgcmV0dXJuIGdyb3VuZFNlZ21lbnRUcmF2ZWxDb3N0KG1hcCwgZnJvbSwgZ29hbCk7XG4gIGNvbnN0IGZpZWxkID0gY2FjaGVkKHN0YXRlLCAtdGFyZ2V0IC0gMSwgKCkgPT4ge1xuICAgIGNvbnN0IGFycmF5cyA9IHN0YXRlLnNwYXJlLnBvcCgpID8/IHsgZGlzdDogbmV3IEludDMyQXJyYXkoc3RhdGUud2Fsay5sZW5ndGgpLCBuZXh0OiBuZXcgSW50MzJBcnJheShzdGF0ZS53YWxrLmxlbmd0aCksIHVzZWQ6IDAgfTtcbiAgICBjb25zdCBib3ggPSB7IGxlZnQ6IDAsIHRvcDogMCwgd2lkdGg6IHN0YXRlLndpZHRoLCBoZWlnaHQ6IHN0YXRlLndhbGsubGVuZ3RoIC8gc3RhdGUud2lkdGggfTtcbiAgICBncm93Qm94SW50byhzdGF0ZSwgYm94LCBbdGFyZ2V0XSwgdW5kZWZpbmVkLCBhcnJheXMpO1xuICAgIHJldHVybiBhcnJheXM7XG4gIH0pO1xuICBjb25zdCBjb3N0ID0gZmllbGQuZGlzdFtzdGFydF0hO1xuICByZXR1cm4gY29zdCA+PSBVTlJFQUNIRUQgPyB1bmRlZmluZWQgOiBjb3N0ICogdGVycmFpbi5jZWxsIC8gKFNUUkFJR0hUICogR1JPVU5EX1dFSUdIVCk7XG59XG5cbi8vIEBAQGdyb3VuZC13aG9sZXMgLSBBIG1vdmVyJ3MgY2VsbHMgZmFsbCBpbnRvIHdob2xlcywgZWFjaCBqb2luZWQgYnkgaXRzIHdhbGtzIGFuZCBjdXQgb2ZmIGZyb20gZXZlcnkgb3RoZXI6IGFuIGlzbGFuZCdzXG4vLyBsYW5kIGlzIGEgd2hvbGUgb2YgaXRzIG93biwgYW5kIHNvIGlzIGEgbGFrZSdzIHdhdGVyLiBXaGV0aGVyIHR3byBwb2ludHMgc3RhbmQgaW4gb25lIHdob2xlIGlzIHNhbWVHcm91bmQ7IGhvdyBtYW55XG4vLyB3aG9sZXMgdGhlcmUgYXJlLCBncm91bmRXaG9sZXMgKGEgbGFkZGVyIG1hcCdzIGxhbmQgaXMgb25lOiB0aGUgZ2VuZXJhdG9yIGtlZXBzIG5vIG9wZW4gZ3JvdW5kIGEgc3RhcnQgY2Fubm90IHJlYWNoKS5cbi8vIFRlcnJhaW4gb25seTogYSBidWlsZGluZyBpbiB0aGUgd2F5IGN1dHMgbm8gd2hvbGUgKHNlZSBAQEBidWlsZGluZy1wYXRoaW5nKS4gQSBtYXAgd2l0aG91dCB0ZXJyYWluIGlzIG9uZSB3aG9sZS5cbmV4cG9ydCBmdW5jdGlvbiBzYW1lR3JvdW5kKG1hcDogUGljazxHYW1lTWFwLCBcInRlcnJhaW5cIj4sIGE6IFBvaW50LCBiOiBQb2ludCwgbW92ZXI6IE1vdmVyID0gXCJsYW5kXCIpIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybiB0cnVlO1xuICBjb25zdCBzdGF0ZSA9IHJ1bnRpbWUodGVycmFpbiwgbW92ZXIpO1xuICBjb25zdCB7IGxhYmVscyB9ID0gd2hvbGVzT2Yoc3RhdGUpO1xuICBjb25zdCBmcm9tID0gcGFkQXQoc3RhdGUsIGEueCwgYS55KTtcbiAgY29uc3QgdG8gPSBwYWRBdChzdGF0ZSwgYi54LCBiLnkpO1xuICByZXR1cm4gZnJvbSA+PSAwICYmIHRvID49IDAgJiYgbGFiZWxzW2Zyb21dICE9PSAwICYmIGxhYmVsc1tmcm9tXSA9PT0gbGFiZWxzW3RvXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdyb3VuZFdob2xlcyhtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCBtb3ZlcjogTW92ZXIgPSBcImxhbmRcIikge1xuICByZXR1cm4gbWFwLnRlcnJhaW4gPyB3aG9sZXNPZihydW50aW1lKG1hcC50ZXJyYWluLCBtb3ZlcikpLmNvdW50IDogMTtcbn1cblxuZnVuY3Rpb24gd2hvbGVzT2Yoc3RhdGU6IFRlcnJhaW5SdW50aW1lKSB7XG4gIGlmIChzdGF0ZS53aG9sZXMpIHJldHVybiBzdGF0ZS53aG9sZXM7XG4gIGNvbnN0IHsgd2Fsaywgb2Zmc2V0cywgdGVycmFpbiwgd2lkdGggfSA9IHN0YXRlO1xuICBjb25zdCBsYWJlbHMgPSBuZXcgSW50MzJBcnJheSh3YWxrLmxlbmd0aCk7XG4gIGNvbnN0IHF1ZXVlID0gbmV3IEludDMyQXJyYXkod2Fsay5sZW5ndGgpO1xuICBsZXQgY291bnQgPSAwO1xuICBmb3IgKGxldCBzZWVkID0gMDsgc2VlZCA8IHdhbGsubGVuZ3RoOyBzZWVkICs9IDEpIHtcbiAgICBpZiAod2Fsa1tzZWVkXSAhPT0gMSB8fCBsYWJlbHNbc2VlZF0gIT09IDApIGNvbnRpbnVlO1xuICAgIGNvdW50ICs9IDE7XG4gICAgbGFiZWxzW3NlZWRdID0gY291bnQ7XG4gICAgbGV0IHRhaWwgPSAwO1xuICAgIHF1ZXVlW3RhaWwrK10gPSBzZWVkO1xuICAgIGZvciAobGV0IGhlYWQgPSAwOyBoZWFkIDwgdGFpbDsgaGVhZCArPSAxKSB7XG4gICAgICBjb25zdCBhdCA9IHF1ZXVlW2hlYWRdITtcbiAgICAgIGZvciAobGV0IGRpcmVjdGlvbiA9IDA7IGRpcmVjdGlvbiA8IDg7IGRpcmVjdGlvbiArPSAxKSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBhdCArIG9mZnNldHNbZGlyZWN0aW9uXSE7XG4gICAgICAgIGlmICh3YWxrW25leHRdICE9PSAxIHx8IGxhYmVsc1tuZXh0XSAhPT0gMCB8fCAhc3RlcEFsbG93ZWQoc3RhdGUsIGF0LCBkaXJlY3Rpb24pKSBjb250aW51ZTtcbiAgICAgICAgbGFiZWxzW25leHRdID0gY291bnQ7XG4gICAgICAgIHF1ZXVlW3RhaWwrK10gPSBuZXh0O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvLyBFYWNoIHdob2xlJ3MgZGVlcCB3YXRlciAoc2VlIEBAQG9wZW4td2F0ZXIpLCBieSBpdHMgbGFiZWwuXG4gIGNvbnN0IGRlZXAgPSBuZXcgSW50MzJBcnJheShjb3VudCArIDEpO1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdGVycmFpbi5jb2xzICogdGVycmFpbi5yb3dzOyBpbmRleCArPSAxKSB7XG4gICAgaWYgKHRlcnJhaW4uY2VsbHNbaW5kZXhdICE9PSBcIn5cIikgY29udGludWU7XG4gICAgY29uc3QgY29sID0gaW5kZXggJSB0ZXJyYWluLmNvbHM7XG4gICAgZGVlcFtsYWJlbHNbKChpbmRleCAtIGNvbCkgLyB0ZXJyYWluLmNvbHMgKyAxKSAqIHdpZHRoICsgY29sICsgMV0hXSEgKz0gMTtcbiAgfVxuICBkZWVwWzBdID0gMDtcbiAgc3RhdGUud2hvbGVzID0geyBsYWJlbHMsIGNvdW50LCBkZWVwIH07XG4gIHJldHVybiBzdGF0ZS53aG9sZXM7XG59XG5cbi8vIFRoZSBjZWxscyBhIHdhbGsgZnJvbSBgZnJvbWAgdG8gYGdvYWxgIHBhc3NlcywgZG93biB0aGUgd2hvbGUgbWFwJ3MgZmllbGQgdG93YXJkIHRoZSBnb2FsIChldmVyeSBgZXZlcnlgLXRoIGNlbGwnc1xuLy8gY2VudGVyLCB0aGUgZ29hbCBsYXN0KSwgb3IgdW5kZWZpbmVkIHdoZW4gbm8gd2FsayBqb2lucyB0aGVtLiBBIG1hcCB3aXRob3V0IHRlcnJhaW4gd2Fsa3MgdGhlIHN0cmFpZ2h0IGxpbmUuIEl0IHJlYWRzXG4vLyB0aGUgdGVycmFpbiBhbG9uZSAoc2VlIEBAQGJ1aWxkaW5nLXBhdGhpbmcpLlxuZXhwb3J0IGZ1bmN0aW9uIHdhbGtSb3V0ZShtYXA6IFBpY2s8R2FtZU1hcCwgXCJ0ZXJyYWluXCI+LCBmcm9tOiBQb2ludCwgZ29hbDogUG9pbnQsIGV2ZXJ5ID0gMik6IFBvaW50W10gfCB1bmRlZmluZWQge1xuICBjb25zdCB0ZXJyYWluID0gbWFwLnRlcnJhaW47XG4gIGlmICghdGVycmFpbikgcmV0dXJuIFtnb2FsXTtcbiAgY29uc3Qgc3RhdGUgPSBydW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKTtcbiAgY29uc3Qgc3RhcnQgPSBwYWRBdChzdGF0ZSwgZnJvbS54LCBmcm9tLnkpO1xuICBjb25zdCB0YXJnZXQgPSBwYWRBdChzdGF0ZSwgZ29hbC54LCBnb2FsLnkpO1xuICBpZiAoc3RhdGUud2Fsa1tzdGFydF0gIT09IDEgfHwgc3RhdGUud2Fsa1t0YXJnZXRdICE9PSAxKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBmaWVsZCA9IGV4YWN0RmllbGQoc3RhdGUsIHRhcmdldCk7XG4gIGlmIChmaWVsZC5kaXN0W3N0YXJ0XSEgPj0gVU5SRUFDSEVEKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCByb3V0ZTogUG9pbnRbXSA9IFtdO1xuICBsZXQgYXQgPSBzdGFydDtcbiAgZm9yIChsZXQgc3RlcCA9IDE7IGF0ICE9PSB0YXJnZXQgJiYgc3RlcCA8IHN0YXRlLndhbGsubGVuZ3RoOyBzdGVwICs9IDEpIHtcbiAgICBhdCA9IG5leHRTdGVwKHN0YXRlLCBmaWVsZCwgYXQpO1xuICAgIGlmIChhdCA8IDApIHJldHVybiB1bmRlZmluZWQ7XG4gICAgaWYgKHN0ZXAgJSBldmVyeSA9PT0gMCkgcm91dGUucHVzaChjZW50ZXJPZihzdGF0ZSwgYXQpKTtcbiAgfVxuICByb3V0ZS5wdXNoKGdvYWwpO1xuICByZXR1cm4gcm91dGU7XG59XG5cbi8vIEBAQGJ1aWxkaW5nLXBhdGhpbmcgLSBCdWlsZGluZ3Mgc3RhbmQgaW4gdGhlIGxhbmQncyB3YXkgYXMgZm9yZXN0IGRvZXMsIGJ1dCB0aGV5IGFyZSBlYWNoIGdhbWUncyBvd24gYW5kIHRoZXkgY29tZSBhbmRcbi8vIGdvOiB0aGUgc2ltIGhhbmRzIHRoZSBtYXAgaXRzIGJ1aWxkaW5ncyB3aGVuZXZlciB0aGV5IGNoYW5nZSAoc2VlIHNldEJ1aWxkaW5nQm9kaWVzKSwgYW5kIHRoZXkgYXJlIGtlcHQgb24gYSBjb3B5IG9mIHRoZVxuLy8gbGFuZCdzIGNlbGxzIHdpdGggZXZlcnkgY2VsbCBvZiB0aGVpciBmb290cHJpbnRzIGJsb2NrZWQgKHNlZSBAQEBidWlsZGluZy1mb290cHJpbnQpLCB3aXRoIGl0cyBvd24gY2xlYXJhbmNlLCBmbG93IHRpbGVzXG4vLyBhbmQgbmVhcmVzdCBjZWxscy4gQSBidWlsZGluZyBsYWlkIG9yIGZlbGxlZCByZWRvZXMgdGhlIHRpbGVzIG9mIHRoZSBzcXVhcmVzIGl0IGNoYW5nZWQgYW5kIG9mIHRob3NlIGJlc2lkZSB0aGVtIChzZWVcbi8vIEBAQGZsb3ctdGlsZXMpLiBUaGUgQUlzJyB3YWxraW5nIGRpc3RhbmNlcyBhbmQgcm91dGVzIHJlYWQgdGhlIHRlcnJhaW4gYWxvbmU6IHdoYXQgYSBidWlsZGluZyBhZGRzIHRvIGEgd2FsayBpcyBhIGZld1xuLy8gc3RlcHMgcm91bmQgaXQuXG4vL1xuLy8gUm91dGluZyBhbmQgd2Fsa2luZyByZWFkIHRoZSBjb3B5IGFsaWtlIChzZWUgaXNPcGVuR3JvdW5kKTogYSB1bml0J3MgY2VudGVyIG5ldmVyIHN0YW5kcyBvbiBhIGZvb3RwcmludCwgc28gYSB3YWxrXG4vLyBzdGFydHMgZnJvbSB0aGUgY2VsbCB1bmRlciBpdCBhbmQgZXZlcnkgZ2FwIHJvdXRpbmcgdGFrZXMgaXMgb25lIGEgdW5pdCB3YWxrcy4gV2hldGhlciBhIGJ1aWxkaW5nIG1heSBiZSBsYWlkXG4vLyAoaXNGb290cHJpbnRCdWlsZGFibGUpIGFuZCB3aGVyZSBhIGdvYWwgbWF5IGxpZSAod2Fsa2FibGVHb2FsKSBzdGF5IHRoZSB0ZXJyYWluJ3MgYWxvbmU6IGEgZ29hbCBvbiBhIGZvb3RwcmludCBpcyB3YWxrZWRcbi8vIHRvIHRoZSBlZGdlIG9mIGl0LlxuLy9cbi8vIFRoZSBjb3B5IGhhbmdzIG9uIHRoZSBnYW1lJ3MgbWFwIG9iamVjdCAoYSBzbmFwc2hvdCBzaGFyZXMgaXQpLCBuZXZlciBvbiB0aGUgdGVycmFpbiwgd2hpY2ggZ2FtZXMgbWF5IHNoYXJlLiBBIG1hcFxuLy8gd2l0aG91dCB0ZXJyYWluIGhhcyBubyByb3V0aW5nIHRvIHRha2UgYSB1bml0IHJvdW5kIGFueXRoaW5nLCBhbmQgaXRzIGJ1aWxkaW5ncyBzdGFuZCBpbiBub2JvZHkncyB3YXkgYnV0IGJ5IHRoZWlyXG4vLyByb3VuZCBib2RpZXMgKHNlZSBAQEBidWlsZGluZy1ib2R5KS4gU2hpcHMga2VlcCB0aGUgc2VhJ3Mgb3duIHJvdXRpbmc6IG5vIGJ1aWxkaW5nIHN0YW5kcyBpbiBkZWVwIHdhdGVyLlxudHlwZSBCb2R5ID0geyB4OiBudW1iZXI7IHk6IG51bWJlcjsgcmFkaXVzOiBudW1iZXIgfTtcbi8vIGBwcmV2aW91c2A6IHRoZSBjZWxscyBhcyB0aGV5IHdlcmUgYmVmb3JlIHRoZSBsYXN0IGNoYW5nZSwga2VwdCB0byB0ZWxsIHdoaWNoIHNxdWFyZXMgdGhhdCBjaGFuZ2UgcmVhY2hlZC5cbnR5cGUgT3ZlcmxheSA9IHsgdGVycmFpbjogVGVycmFpbjsgc3RhdGU6IFRlcnJhaW5SdW50aW1lOyBwcmV2aW91czogVWludDhBcnJheTsgcmV2aXNpb246bnVtYmVyOyBib2RpZXM6IEJvZHlbXTsgc2hhcmVkOiBib29sZWFuIH07XG5jb25zdCBvdmVybGF5cyA9IG5ldyBXZWFrTWFwPG9iamVjdCwgT3ZlcmxheT4oKTtcbmxldCBuZXh0R3JvdW5kUmV2aXNpb249MTtcbi8qKiBJZGVudGl0eSBvZiB0aGUgY3VycmVudCBidWlsZGluZyBvYnN0cnVjdGlvbiBmaWVsZCwgZm9yIGdlb21ldHJ5LW9ubHkgY2FjaGVzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdyb3VuZFJldmlzaW9uKG1hcDpvYmplY3Qpe3JldHVybiBvdmVybGF5cy5nZXQobWFwKT8ucmV2aXNpb24gPz8gMDt9XG5cbi8qKiBBIHNuYXBzaG90IHJlYWRzIHRoaXMgZ2VvbWV0cnk7IGxhdGVyIGNvbnN0cnVjdGlvbiBtdXN0IGxlYXZlIHRoYXQgc25hcHNob3QncyBmaWVsZCBpbnRhY3QuICovXG5leHBvcnQgZnVuY3Rpb24gc2hhcmVCdWlsZGluZ0JvZGllcyhzb3VyY2U6IG9iamVjdCwgdGFyZ2V0OiBvYmplY3QpIHtcbiAgY29uc3Qgb3ZlcmxheSA9IG92ZXJsYXlzLmdldChzb3VyY2UpO1xuICBpZiAob3ZlcmxheSkge1xuICAgIG92ZXJsYXkuc2hhcmVkID0gdHJ1ZTtcbiAgICBvdmVybGF5cy5zZXQodGFyZ2V0LCBvdmVybGF5KTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0QnVpbGRpbmdCb2RpZXMobWFwOiBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiPiwgYm9kaWVzOiByZWFkb25seSBCb2R5W10pIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluO1xuICBpZiAoIXRlcnJhaW4pIHJldHVybjtcbiAgaWYgKGJvZGllcy5sZW5ndGggPT09IDApIHtcbiAgICBvdmVybGF5cy5kZWxldGUobWFwKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY3VycmVudCA9IG92ZXJsYXlzLmdldChtYXApO1xuICBpZiAoY3VycmVudD8udGVycmFpbiA9PT0gdGVycmFpbiAmJiBjdXJyZW50LmJvZGllcy5sZW5ndGggPT09IGJvZGllcy5sZW5ndGhcbiAgICAmJiBib2RpZXMuZXZlcnkoKGJvZHksIGluZGV4KSA9PiBib2R5LnggPT09IGN1cnJlbnQuYm9kaWVzW2luZGV4XSEueFxuICAgICAgJiYgYm9keS55ID09PSBjdXJyZW50LmJvZGllc1tpbmRleF0hLnkgJiYgYm9keS5yYWRpdXMgPT09IGN1cnJlbnQuYm9kaWVzW2luZGV4XSEucmFkaXVzKSkgcmV0dXJuO1xuICBjb25zdCBncm91bmQgPSBydW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKTtcbiAgbGV0IG92ZXJsYXkgPSBjdXJyZW50O1xuICBpZiAoIW92ZXJsYXkgfHwgb3ZlcmxheS50ZXJyYWluICE9PSB0ZXJyYWluIHx8IG92ZXJsYXkuc2hhcmVkKSB7XG4gICAgY29uc3QgZnJlc2ggPSBjcmVhdGVSdW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKTtcbiAgICBvdmVybGF5ID0geyB0ZXJyYWluLCBzdGF0ZTogZnJlc2gsIHByZXZpb3VzOiBuZXcgVWludDhBcnJheShmcmVzaC53YWxrLmxlbmd0aCksIHJldmlzaW9uOm5leHRHcm91bmRSZXZpc2lvbisrLCBib2RpZXM6IFtdLCBzaGFyZWQ6IGZhbHNlIH07XG4gICAgb3ZlcmxheXMuc2V0KG1hcCwgb3ZlcmxheSk7XG4gIH1cbiAgb3ZlcmxheS5ib2RpZXMgPSBib2RpZXMubWFwKCh7IHgsIHksIHJhZGl1cyB9KSA9PiAoeyB4LCB5LCByYWRpdXMgfSkpO1xuICBjb25zdCBzdGF0ZSA9IG92ZXJsYXkuc3RhdGU7XG4gIG92ZXJsYXkucHJldmlvdXMuc2V0KHN0YXRlLndhbGspO1xuICBzdGF0ZS53YWxrLnNldChncm91bmQud2Fsayk7XG4gIGNvbnN0IHNpemUgPSB0ZXJyYWluLmNlbGw7XG4gIGZvciAoY29uc3QgYm9keSBvZiBib2RpZXMpIHtcbiAgICBjb25zdCB7IGxlZnQsIHJpZ2h0LCB0b3AsIGJvdHRvbSB9ID0gZm9vdHByaW50Q2VsbHMoc2l6ZSwgYm9keS54LCBib2R5LnksIGJvZHkucmFkaXVzKTtcbiAgICBmb3IgKGxldCByb3cgPSBNYXRoLm1heCgwLCB0b3ApOyByb3cgPD0gTWF0aC5taW4odGVycmFpbi5yb3dzIC0gMSwgYm90dG9tKTsgcm93ICs9IDEpIHtcbiAgICAgIGZvciAobGV0IGNvbCA9IE1hdGgubWF4KDAsIGxlZnQpOyBjb2wgPD0gTWF0aC5taW4odGVycmFpbi5jb2xzIC0gMSwgcmlnaHQpOyBjb2wgKz0gMSkgc3RhdGUud2Fsa1twYWQoc3RhdGUsIGNvbCwgcm93KV0gPSAwO1xuICAgIH1cbiAgfVxuICBjb25zdCBkaXJ0eSA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBmb3IgKGxldCBhdCA9IDA7IGF0IDwgc3RhdGUud2Fsay5sZW5ndGg7IGF0ICs9IDEpIHtcbiAgICBpZiAoc3RhdGUud2Fsa1thdF0gPT09IG92ZXJsYXkucHJldmlvdXNbYXRdKSBjb250aW51ZTtcbiAgICBjb25zdCBjb2wgPSAoYXQgJSBzdGF0ZS53aWR0aCkgLSAxO1xuICAgIGNvbnN0IHJvdyA9IE1hdGguZmxvb3IoYXQgLyBzdGF0ZS53aWR0aCkgLSAxO1xuICAgIGRpcnR5LmFkZChNYXRoLmZsb29yKHJvdyAvIFNFQ1RPUikgKiBNYXRoLmNlaWwodGVycmFpbi5jb2xzIC8gU0VDVE9SKSArIE1hdGguZmxvb3IoY29sIC8gU0VDVE9SKSk7XG4gIH1cbiAgaWYgKGRpcnR5LnNpemUgPT09IDApIHJldHVybjtcbiAgb3ZlcmxheS5yZXZpc2lvbj1uZXh0R3JvdW5kUmV2aXNpb24rKztcbiAgLy8gQSBjb25uZWN0aXZpdHktb25seSBydW50aW1lIGhhcyBub3QgbmVlZGVkIGNsZWFyYW5jZSB5ZXQuIEl0cyBmaXJzdFxuICAvLyBzZWdtZW50IHF1ZXJ5IHdpbGwgYnVpbGQgaXQgZnJvbSB0aGUgY3VycmVudCwgdXBkYXRlZCB3YWxrYWJsZSBjZWxscy5cbiAgaWYgKHN0YXRlLmNsZWFyYW5jZSkgeyBzdGF0ZS5jbGVhcmFuY2UuZmlsbCgwKTsgZmlsbENsZWFyYW5jZShzdGF0ZSk7IH1cbiAgc3RhdGUubmVhcmVzdC5jbGVhcigpO1xuICBpZiAoc3RhdGUudGlsZXMpIHJlZG9UaWxlcyhzdGF0ZSwgc3RhdGUudGlsZXMsIGRpcnR5KTtcbn1cblxuLy8gVGhlIHJ1bnRpbWUgYSBtb3ZlcidzIHJvdXRpbmcgcnVucyBvbjogdGhlIGxhbmQncyB3aXRoIHRoaXMgZ2FtZSdzIGJ1aWxkaW5ncyB3aGVuIGl0IGhhcyBhbnkuXG5mdW5jdGlvbiByb3V0aW5nKG1hcDogb2JqZWN0LCB0ZXJyYWluOiBUZXJyYWluLCBtb3ZlcjogTW92ZXIpOiBUZXJyYWluUnVudGltZSB7XG4gIGlmIChtb3ZlciA9PT0gXCJsYW5kXCIpIHtcbiAgICBjb25zdCBvdmVybGF5ID0gb3ZlcmxheXMuZ2V0KG1hcCk7XG4gICAgaWYgKG92ZXJsYXkgJiYgb3ZlcmxheS50ZXJyYWluID09PSB0ZXJyYWluKSByZXR1cm4gb3ZlcmxheS5zdGF0ZTtcbiAgfVxuICByZXR1cm4gcnVudGltZSh0ZXJyYWluLCBtb3Zlcik7XG59XG5cbi8vIGB1c2VkYDogd2hlbiB0aGUgZmllbGQgd2FzIGxhc3QgYXNrZWQgZm9yLCBieSB0aGUgcnVudGltZSdzIGNsb2NrICh0aGUgbGVhc3QgcmVjZW50bHkgdXNlZCBnb2VzIGZpcnN0KS5cbnR5cGUgRmllbGQgPSB7IGRpc3Q6IEludDMyQXJyYXk7IG5leHQ6IEludDMyQXJyYXk7IHVzZWQ6IG51bWJlciB9O1xuXG50eXBlIFRlcnJhaW5SdW50aW1lID0ge1xuICB0ZXJyYWluOiBUZXJyYWluO1xuICAvLyBUaGUgZ3JpZCB3aXRoIGEgYmxvY2tlZCBib3JkZXIgY2VsbCBhbGwgcm91bmQgKGNvbHMgKyAyIHdpZGUpLCBzbyBubyBzdGVwIGV2ZXIgbmVlZHMgYSBib3VuZHMgY2hlY2suXG4gIHdpZHRoOiBudW1iZXI7XG4gIC8vIDEgb24gYSBjZWxsIHRoZSBydW50aW1lJ3MgbW92ZXIgbWF5IGNyb3NzIChzZWUgQEBAdGVycmFpbi1tb3ZlcnMpLlxuICB3YWxrOiBVaW50OEFycmF5O1xuICAvLyBXaGF0IGEgc3RlcCBvbnRvIHRoZSBjZWxsIGNvc3RzLCBpbiBxdWFydGVycyBvZiBiYXJlIGdyb3VuZCdzIChzZWUgR1JPVU5EX1dFSUdIVCk6IGl0cyBncm91bmQncyBmb3IgYSBsYW5kIHVuaXQsIGJhcmVcbiAgLy8gZ3JvdW5kJ3MgZXZlcnl3aGVyZSBmb3IgYSBzaGlwLlxuICB3ZWlnaHQ6IFVpbnQ4QXJyYXk7XG4gIC8vIENoZWJ5c2hldiBkaXN0YW5jZSBpbiBjZWxscyB0byB0aGUgbmVhcmVzdCBibG9ja2VkIGNlbGwgKG9yIHRoZSBtYXAncyBlZGdlKTogMCBvbiBhIGJsb2NrZWQgY2VsbC5cbiAgY2xlYXJhbmNlPzogVWludDE2QXJyYXk7XG4gIGZpZWxkczogTWFwPG51bWJlciwgRmllbGQ+O1xuICBzcGFyZTogRmllbGRbXTtcbiAgY2xvY2s6IG51bWJlcjtcbiAgbmVhcmVzdDogTWFwPG51bWJlciwgbnVtYmVyPjtcbiAgLy8gRGlhbCdzIGJ1Y2tldHMsIGtlcHQgYmV0d2VlbiBmaWVsZHM6IHRoZSB3aG9sZSBtYXAncyAoc2VlIGdyb3cpIGFuZCB0aGUgYm94ZXMnIChzZWUgZ3Jvd0JveCkuXG4gIGJ1Y2tldHM/OiBJbnQzMkFycmF5W107XG4gIHRvcHM6IEludDMyQXJyYXk7XG4gIGJveEJ1Y2tldHM6IG51bWJlcltdW107XG4gIG9mZnNldHM6IEludDMyQXJyYXk7XG4gIC8vIFRoZSByb3V0aW5nIG9mIHdhbGtzIChzZWUgQEBAZmxvdy10aWxlcyksIGJ1aWx0IHdoZW4gZmlyc3QgYXNrZWQgZm9yLlxuICB0aWxlcz86IFRpbGVzIHwgdW5kZWZpbmVkO1xuICAvLyBXaGljaCB3aG9sZSBvZiB0aGUgbW92ZXIncyBncm91bmQgZXZlcnkgY2VsbCBiZWxvbmdzIHRvIChzZWUgQEBAZ3JvdW5kLXdob2xlcyksIHdvcmtlZCBvdXQgdGhlIGZpcnN0IHRpbWUgaXQgaXMgYXNrZWQuXG4gIHdob2xlcz86IHsgbGFiZWxzOiBJbnQzMkFycmF5OyBjb3VudDogbnVtYmVyOyBkZWVwOiBJbnQzMkFycmF5IH07XG4gIC8vIFRoZSBzZWEncyBzaG9yZSBzcG90cyBieSBhIHNoaXB5YXJkJ3MgcmFkaXVzIChzZWUgc2hvcmVTcG90cyksIHdvcmtlZCBvdXQgdGhlIGZpcnN0IHRpbWUgZWFjaCBpcyBhc2tlZC5cbiAgc2hvcmVzPzogTWFwPG51bWJlciwgUG9pbnRbXT47XG59O1xuXG4vLyBAQEB0ZXJyYWluLXJ1bnRpbWUgLSBXaGF0IHRoZSB0ZXJyYWluJ3MgcXVlcmllcyBuZWVkLCBidWlsdCBvbmNlIHBlciB0ZXJyYWluIGFuZCBtb3ZlciBhbmQga2VwdCBiZXNpZGUgdGhlIHRlcnJhaW4gKG5ldmVyXG4vLyBpbiB0aGUgZ2FtZSdzIHN0YXRlKTogdGhlIGNlbGxzIHRoZSBtb3ZlciBtYXkgY3Jvc3MsIHRoZWlyIGNsZWFyYW5jZSwgYW5kIHRoZSBmbG93IGZpZWxkcyBhbmQgbmVhcmVzdCBjZWxscyBhc2tlZCBmb3Igc29cbi8vIGZhci4gRXZlcnkgb25lIGlzIGEgcHVyZSBmdW5jdGlvbiBvZiB0aGUgdGVycmFpbiwgc28gd2hldGhlciBpdCB3YXMgY2FjaGVkIGNoYW5nZXMgbm90aGluZyBhIHVuaXQgZG9lcy5cbnR5cGUgUnVudGltZXMgPSB7IGxhbmQ/OiBUZXJyYWluUnVudGltZTsgc2VhPzogVGVycmFpblJ1bnRpbWUgfTtcbmNvbnN0IHJ1bnRpbWVzID0gbmV3IFdlYWtNYXA8VGVycmFpbiwgUnVudGltZXM+KCk7XG5sZXQgbGFzdFRlcnJhaW46IFRlcnJhaW4gfCB1bmRlZmluZWQ7XG5sZXQgbGFzdFJ1bnRpbWVzOiBSdW50aW1lcyA9IHt9O1xuXG5mdW5jdGlvbiBydW50aW1lKHRlcnJhaW46IFRlcnJhaW4sIG1vdmVyOiBNb3Zlcik6IFRlcnJhaW5SdW50aW1lIHtcbiAgaWYgKHRlcnJhaW4gIT09IGxhc3RUZXJyYWluKSB7XG4gICAgbGFzdFRlcnJhaW4gPSB0ZXJyYWluO1xuICAgIGxhc3RSdW50aW1lcyA9IHJ1bnRpbWVzLmdldCh0ZXJyYWluKSA/PyB7fTtcbiAgICBydW50aW1lcy5zZXQodGVycmFpbiwgbGFzdFJ1bnRpbWVzKTtcbiAgfVxuICByZXR1cm4gbW92ZXIgPT09IFwibGFuZFwiID8gKGxhc3RSdW50aW1lcy5sYW5kID8/PSBjcmVhdGVSdW50aW1lKHRlcnJhaW4sIFwibGFuZFwiKSkgOiAobGFzdFJ1bnRpbWVzLnNlYSA/Pz0gY3JlYXRlUnVudGltZSh0ZXJyYWluLCBcInNlYVwiKSk7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVJ1bnRpbWUodGVycmFpbjogVGVycmFpbiwgbW92ZXI6IE1vdmVyKTogVGVycmFpblJ1bnRpbWUge1xuICBjb25zdCB3aWR0aCA9IHRlcnJhaW4uY29scyArIDI7XG4gIGNvbnN0IGNvdW50ID0gd2lkdGggKiAodGVycmFpbi5yb3dzICsgMik7XG4gIGNvbnN0IHdhbGsgPSBuZXcgVWludDhBcnJheShjb3VudCk7XG4gIGNvbnN0IHdlaWdodCA9IG5ldyBVaW50OEFycmF5KGNvdW50KTtcbiAgY29uc3QgcGFzc2FibGUgPSBQQVNTQUJMRVttb3Zlcl07XG4gIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8IHRlcnJhaW4ucm93czsgcm93ICs9IDEpIHtcbiAgICBmb3IgKGxldCBjb2wgPSAwOyBjb2wgPCB0ZXJyYWluLmNvbHM7IGNvbCArPSAxKSB7XG4gICAgICBjb25zdCBjaGFyID0gdGVycmFpbi5jZWxsc1tyb3cgKiB0ZXJyYWluLmNvbHMgKyBjb2xdITtcbiAgICAgIGlmICghcGFzc2FibGUuaGFzKGNoYXIpKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGF0ID0gKHJvdyArIDEpICogd2lkdGggKyBjb2wgKyAxO1xuICAgICAgd2Fsa1thdF0gPSAxO1xuICAgICAgd2VpZ2h0W2F0XSA9IG1vdmVyID09PSBcInNlYVwiID8gR1JPVU5EX1dFSUdIVCA6IE1hdGgucm91bmQoR1JPVU5EX1dFSUdIVCAvIChDRUxMX0dST1VORFtjaGFyXT8ucGFjZSA/PyAxKSk7XG4gICAgfVxuICB9XG4gIGNvbnN0IG9mZnNldHMgPSBJbnQzMkFycmF5LmZyb20oWzEsIHdpZHRoLCAtMSwgLXdpZHRoLCB3aWR0aCArIDEsIHdpZHRoIC0gMSwgLXdpZHRoIC0gMSwgLXdpZHRoICsgMV0pO1xuICBjb25zdCBzdGF0ZTogVGVycmFpblJ1bnRpbWUgPSB7XG4gICAgdGVycmFpbixcbiAgICB3aWR0aCxcbiAgICB3YWxrLFxuICAgIHdlaWdodCxcbiAgICBmaWVsZHM6IG5ldyBNYXAoKSxcbiAgICBjbG9jazogMCxcbiAgICBzcGFyZTogW10sXG4gICAgbmVhcmVzdDogbmV3IE1hcCgpLFxuICAgIHRvcHM6IG5ldyBJbnQzMkFycmF5KDgpLFxuICAgIGJveEJ1Y2tldHM6IEFycmF5LmZyb20oeyBsZW5ndGg6IEJVQ0tFVFMgfSwgKCkgPT4gW10pLFxuICAgIG9mZnNldHMsXG4gIH07XG4gIHJldHVybiBzdGF0ZTtcbn1cblxuZnVuY3Rpb24gcGFkKHN0YXRlOiBUZXJyYWluUnVudGltZSwgY29sOiBudW1iZXIsIHJvdzogbnVtYmVyKSB7XG4gIHJldHVybiAocm93ICsgMSkgKiBzdGF0ZS53aWR0aCArIGNvbCArIDE7XG59XG5cbi8vIFRoZSBwYWRkZWQgaW5kZXggb2YgdGhlIGNlbGwgdW5kZXIgYSBwb2ludCwgb3IgLTEgb2ZmIHRoZSBtYXAuXG5mdW5jdGlvbiBwYWRBdChzdGF0ZTogVGVycmFpblJ1bnRpbWUsIHg6IG51bWJlciwgeTogbnVtYmVyKSB7XG4gIGNvbnN0IHsgdGVycmFpbiB9ID0gc3RhdGU7XG4gIGNvbnN0IGNvbCA9IE1hdGguZmxvb3IoeCAvIHRlcnJhaW4uY2VsbCk7XG4gIGNvbnN0IHJvdyA9IE1hdGguZmxvb3IoeSAvIHRlcnJhaW4uY2VsbCk7XG4gIGlmIChjb2wgPCAwIHx8IHJvdyA8IDAgfHwgY29sID49IHRlcnJhaW4uY29scyB8fCByb3cgPj0gdGVycmFpbi5yb3dzKSByZXR1cm4gLTE7XG4gIHJldHVybiAocm93ICsgMSkgKiBzdGF0ZS53aWR0aCArIGNvbCArIDE7XG59XG5cbmZ1bmN0aW9uIGNlbnRlck9mKHN0YXRlOiBUZXJyYWluUnVudGltZSwgYXQ6IG51bWJlcik6IFBvaW50IHtcbiAgY29uc3QgY29sID0gKGF0ICUgc3RhdGUud2lkdGgpIC0gMTtcbiAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihhdCAvIHN0YXRlLndpZHRoKSAtIDE7XG4gIHJldHVybiB7IHg6IChjb2wgKyAwLjUpICogc3RhdGUudGVycmFpbi5jZWxsLCB5OiAocm93ICsgMC41KSAqIHN0YXRlLnRlcnJhaW4uY2VsbCB9O1xufVxuXG4vLyBEaWFnb25hbCBzdGVwcyAob2Zmc2V0cyA0IHRvIDcpIG5ldmVyIGN1dCBhIGNvcm5lcjogYm90aCBjZWxscyBiZXNpZGUgdGhlIHN0ZXAgbXVzdCBiZSB3YWxrYWJsZS5cbmZ1bmN0aW9uIHN0ZXBBbGxvd2VkKHN0YXRlOiBUZXJyYWluUnVudGltZSwgYXQ6IG51bWJlciwgZGlyZWN0aW9uOiBudW1iZXIpIHtcbiAgaWYgKGRpcmVjdGlvbiA8IDQpIHJldHVybiB0cnVlO1xuICBjb25zdCB7IHdhbGssIHdpZHRoIH0gPSBzdGF0ZTtcbiAgY29uc3QgZHggPSBkaXJlY3Rpb24gPT09IDQgfHwgZGlyZWN0aW9uID09PSA3ID8gMSA6IC0xO1xuICBjb25zdCBkeSA9IGRpcmVjdGlvbiA9PT0gNCB8fCBkaXJlY3Rpb24gPT09IDUgPyB3aWR0aCA6IC13aWR0aDtcbiAgcmV0dXJuIHdhbGtbYXQgKyBkeF0gPT09IDEgJiYgd2Fsa1thdCArIGR5XSA9PT0gMTtcbn1cblxuZnVuY3Rpb24gZmlsbENsZWFyYW5jZShzdGF0ZTogVGVycmFpblJ1bnRpbWUpIHtcbiAgY29uc3QgeyB3YWxrLCBvZmZzZXRzIH0gPSBzdGF0ZTtcbiAgY29uc3QgY2xlYXJhbmNlID0gc3RhdGUuY2xlYXJhbmNlID8/PSBuZXcgVWludDE2QXJyYXkod2Fsay5sZW5ndGgpO1xuICBjb25zdCBxdWV1ZSA9IG5ldyBJbnQzMkFycmF5KHdhbGsubGVuZ3RoKTtcbiAgbGV0IHRhaWwgPSAwO1xuICAvLyBCbG9ja2VkIGNlbGxzICh0aGUgYm9yZGVyIGFtb25nIHRoZW0pIHNlZWQgdGhlaXIgd2Fsa2FibGUgbmVpZ2hib3VycyBhdCAxLlxuICBmb3IgKGxldCBhdCA9IDA7IGF0IDwgd2Fsay5sZW5ndGg7IGF0ICs9IDEpIHtcbiAgICBpZiAod2Fsa1thdF0gIT09IDEpIGNvbnRpbnVlO1xuICAgIGZvciAobGV0IGRpcmVjdGlvbiA9IDA7IGRpcmVjdGlvbiA8IDg7IGRpcmVjdGlvbiArPSAxKSB7XG4gICAgICBpZiAod2Fsa1thdCArIG9mZnNldHNbZGlyZWN0aW9uXSFdID09PSAxKSBjb250aW51ZTtcbiAgICAgIGNsZWFyYW5jZVthdF0gPSAxO1xuICAgICAgcXVldWVbdGFpbCsrXSA9IGF0O1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIGZvciAobGV0IGhlYWQgPSAwOyBoZWFkIDwgdGFpbDsgaGVhZCArPSAxKSB7XG4gICAgY29uc3QgYXQgPSBxdWV1ZVtoZWFkXSE7XG4gICAgY29uc3QgdmFsdWUgPSBjbGVhcmFuY2VbYXRdISArIDE7XG4gICAgZm9yIChsZXQgZGlyZWN0aW9uID0gMDsgZGlyZWN0aW9uIDwgODsgZGlyZWN0aW9uICs9IDEpIHtcbiAgICAgIGNvbnN0IG5leHQgPSBhdCArIG9mZnNldHNbZGlyZWN0aW9uXSE7XG4gICAgICBpZiAod2Fsa1tuZXh0XSAhPT0gMSB8fCBjbGVhcmFuY2VbbmV4dF0gIT09IDApIGNvbnRpbnVlO1xuICAgICAgY2xlYXJhbmNlW25leHRdID0gdmFsdWU7XG4gICAgICBxdWV1ZVt0YWlsKytdID0gbmV4dDtcbiAgICB9XG4gIH1cbn1cblxuLy8gV2hldGhlciB0aGUgc2VnbWVudCBjcm9zc2VzIG9ubHkgd2Fsa2FibGUgY2VsbHMuIEl0IHN0ZXBzIGZyb20gY2VsbCB0byBjZWxsLCBidXQgYWNyb3NzIG9wZW4gZ3JvdW5kIGl0IGxlYXBzOiBhIGNlbGxcbi8vIHdob3NlIGNsZWFyYW5jZSBpcyBrIGhhcyBldmVyeSBjZWxsIHdpdGhpbiBrIC0gMSBvZiBpdCB3YWxrYWJsZSwgc28gdGhlIHdhbGsganVtcHMgdG8gdGhlIGVkZ2Ugb2YgdGhhdCBzcXVhcmUuXG5cbmZ1bmN0aW9uIGNsZWFyU2VnbWVudChzdGF0ZTogVGVycmFpblJ1bnRpbWUsIGF4OiBudW1iZXIsIGF5OiBudW1iZXIsIGJ4OiBudW1iZXIsIGJ5OiBudW1iZXIpIHtcbiAgY29uc3QgeyB0ZXJyYWluLCB3YWxrLCB3aWR0aCB9ID0gc3RhdGU7XG4gIGNvbnN0IHNpemUgPSB0ZXJyYWluLmNlbGw7XG4gIGxldCBhdCA9IHBhZEF0KHN0YXRlLCBheCwgYXkpO1xuICBjb25zdCBlbmQgPSBwYWRBdChzdGF0ZSwgYngsIGJ5KTtcbiAgaWYgKGF0IDwgMCB8fCBlbmQgPCAwIHx8IHdhbGtbYXRdICE9PSAxIHx8IHdhbGtbZW5kXSAhPT0gMSkgcmV0dXJuIGZhbHNlO1xuICBpZiAoYXQgPT09IGVuZCkgcmV0dXJuIHRydWU7XG4gIGlmICghc3RhdGUuY2xlYXJhbmNlKSBmaWxsQ2xlYXJhbmNlKHN0YXRlKTtcbiAgY29uc3QgY2xlYXJhbmNlID0gc3RhdGUuY2xlYXJhbmNlITtcbiAgY29uc3QgZHggPSBieCAtIGF4O1xuICBjb25zdCBkeSA9IGJ5IC0gYXk7XG4gIGNvbnN0IGxlbmd0aCA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gIGNvbnN0IHV4ID0gZHggLyBsZW5ndGg7XG4gIGNvbnN0IHV5ID0gZHkgLyBsZW5ndGg7XG4gIGxldCB0ID0gMDtcbiAgZm9yIChsZXQgZ3VhcmQgPSAwOyBndWFyZCA8IDIgKiAodGVycmFpbi5jb2xzICsgdGVycmFpbi5yb3dzKSArIDg7IGd1YXJkICs9IDEpIHtcbiAgICBjb25zdCBjb2wgPSAoYXQgJSB3aWR0aCkgLSAxO1xuICAgIGNvbnN0IHJvdyA9IE1hdGguZmxvb3IoYXQgLyB3aWR0aCkgLSAxO1xuICAgIGNvbnN0IHJlYWNoID0gY2xlYXJhbmNlW2F0XSEgLSAxO1xuICAgIC8vIFRoZSB3YWxrYWJsZSBzcXVhcmUgYXJvdW5kIHRoZSBjZWxsLCBhbmQgd2hlcmUgdGhlIHNlZ21lbnQgbGVhdmVzIGl0LlxuICAgIGNvbnN0IGxlZnQgPSAoY29sIC0gcmVhY2gpICogc2l6ZTtcbiAgICBjb25zdCByaWdodCA9IChjb2wgKyByZWFjaCArIDEpICogc2l6ZTtcbiAgICBjb25zdCB0b3AgPSAocm93IC0gcmVhY2gpICogc2l6ZTtcbiAgICBjb25zdCBib3R0b20gPSAocm93ICsgcmVhY2ggKyAxKSAqIHNpemU7XG4gICAgY29uc3QgcHggPSBheCArIHV4ICogdDtcbiAgICBjb25zdCBweSA9IGF5ICsgdXkgKiB0O1xuICAgIGNvbnN0IGV4aXRYID0gdXggPiAwID8gKHJpZ2h0IC0gcHgpIC8gdXggOiB1eCA8IDAgPyAobGVmdCAtIHB4KSAvIHV4IDogSW5maW5pdHk7XG4gICAgY29uc3QgZXhpdFkgPSB1eSA+IDAgPyAoYm90dG9tIC0gcHkpIC8gdXkgOiB1eSA8IDAgPyAodG9wIC0gcHkpIC8gdXkgOiBJbmZpbml0eTtcbiAgICBjb25zdCBleGl0ID0gTWF0aC5taW4oZXhpdFgsIGV4aXRZKTtcbiAgICBpZiAodCArIGV4aXQgPj0gbGVuZ3RoKSByZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCBsZWF2ZVggPSBleGl0WCA8PSBleGl0WTtcbiAgICBjb25zdCBsZWF2ZVkgPSBleGl0WSA8PSBleGl0WDtcbiAgICB0ICs9IGV4aXQ7XG4gICAgLy8gVGhlIGNlbGwgdGhlIHNlZ21lbnQgZW50ZXJzIGFzIGl0IGxlYXZlcyB0aGUgc3F1YXJlIChhY3Jvc3MgYSBjb3JuZXIgaXQgcGFzc2VzIGV4YWN0bHksIHRoZSBkaWFnb25hbCBvbmUpLlxuICAgIGxldCBuZXh0Q29sID0gTWF0aC5mbG9vcigoYXggKyB1eCAqIHQpIC8gc2l6ZSk7XG4gICAgbGV0IG5leHRSb3cgPSBNYXRoLmZsb29yKChheSArIHV5ICogdCkgLyBzaXplKTtcbiAgICBpZiAobGVhdmVYKSBuZXh0Q29sID0gdXggPiAwID8gTWF0aC5tYXgobmV4dENvbCwgY29sICsgcmVhY2ggKyAxKSA6IE1hdGgubWluKG5leHRDb2wsIGNvbCAtIHJlYWNoIC0gMSk7XG4gICAgaWYgKGxlYXZlWSkgbmV4dFJvdyA9IHV5ID4gMCA/IE1hdGgubWF4KG5leHRSb3csIHJvdyArIHJlYWNoICsgMSkgOiBNYXRoLm1pbihuZXh0Um93LCByb3cgLSByZWFjaCAtIDEpO1xuICAgIGlmIChuZXh0Q29sIDwgMCB8fCBuZXh0Um93IDwgMCB8fCBuZXh0Q29sID49IHRlcnJhaW4uY29scyB8fCBuZXh0Um93ID49IHRlcnJhaW4ucm93cykgcmV0dXJuIGZhbHNlO1xuICAgIC8vIFRocm91Z2ggYSBjb3JuZXIgZXhhY3RseTogYm90aCBjZWxscyBiZXNpZGUgaXQgbXVzdCBiZSBvcGVuLCBvciB0aGUgd2FsayB3b3VsZCBzcXVlZXplIGJldHdlZW4gdHdvIGJsb2Nrcy5cbiAgICBpZiAobGVhdmVYICYmIGxlYXZlWSAmJiAod2Fsa1twYWQoc3RhdGUsIHV4ID4gMCA/IGNvbCArIHJlYWNoIDogY29sIC0gcmVhY2gsIG5leHRSb3cpXSAhPT0gMSB8fCB3YWxrW3BhZChzdGF0ZSwgbmV4dENvbCwgdXkgPiAwID8gcm93ICsgcmVhY2ggOiByb3cgLSByZWFjaCldICE9PSAxKSkgcmV0dXJuIGZhbHNlO1xuICAgIGF0ID0gcGFkKHN0YXRlLCBuZXh0Q29sLCBuZXh0Um93KTtcbiAgICBpZiAod2Fsa1thdF0gIT09IDEpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoYXQgPT09IGVuZCkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBUaGUgbmVpZ2hib3VyIG9uZSBzdGVwIGRvd24gdGhlIGZpZWxkICh0aGUgZml4ZWQgb3JkZXIgb2YgZGlyZWN0aW9ucyBicmVha3MgdGllcyksIG9yIC0xIGF0IHRoZSBib3R0b207IHJlbWVtYmVyZWQgaW5cbi8vIHRoZSBmaWVsZCwgc28gYSBjZWxsIGlzIHdvcmtlZCBvdXQgb25jZS5cbmZ1bmN0aW9uIG5leHRTdGVwKHN0YXRlOiBUZXJyYWluUnVudGltZSwgZmllbGQ6IEZpZWxkLCBhdDogbnVtYmVyKSB7XG4gIGNvbnN0IGtub3duID0gZmllbGQubmV4dFthdF0hO1xuICBpZiAoa25vd24gIT09IFVOS05PV04pIHJldHVybiBrbm93bjtcbiAgY29uc3QgeyB3YWxrLCBvZmZzZXRzIH0gPSBzdGF0ZTtcbiAgY29uc3QgZGlzdCA9IGZpZWxkLmRpc3Q7XG4gIGxldCBiZXN0ID0gLTE7XG4gIGxldCBiZXN0Q29zdCA9IGRpc3RbYXRdITtcbiAgZm9yIChsZXQgZGlyZWN0aW9uID0gMDsgZGlyZWN0aW9uIDwgODsgZGlyZWN0aW9uICs9IDEpIHtcbiAgICBjb25zdCBuZXh0ID0gYXQgKyBvZmZzZXRzW2RpcmVjdGlvbl0hO1xuICAgIGlmICh3YWxrW25leHRdICE9PSAxIHx8IGRpc3RbbmV4dF0hID49IGJlc3RDb3N0IHx8ICFzdGVwQWxsb3dlZChzdGF0ZSwgYXQsIGRpcmVjdGlvbikpIGNvbnRpbnVlO1xuICAgIGJlc3RDb3N0ID0gZGlzdFtuZXh0XSE7XG4gICAgYmVzdCA9IG5leHQ7XG4gIH1cbiAgZmllbGQubmV4dFthdF0gPSBiZXN0O1xuICByZXR1cm4gYmVzdDtcbn1cblxuZnVuY3Rpb24gZXhhY3RGaWVsZChzdGF0ZTogVGVycmFpblJ1bnRpbWUsIHRhcmdldDogbnVtYmVyKTogRmllbGQge1xuICByZXR1cm4gY2FjaGVkKHN0YXRlLCB0YXJnZXQsICgpID0+IGdyb3coc3RhdGUsIFt0YXJnZXRdKSk7XG59XG5cbmZ1bmN0aW9uIGNhY2hlZChzdGF0ZTogVGVycmFpblJ1bnRpbWUsIGtleTogbnVtYmVyLCBidWlsZDogKCkgPT4gRmllbGQpOiBGaWVsZCB7XG4gIHN0YXRlLmNsb2NrICs9IDE7XG4gIGNvbnN0IGtub3duID0gc3RhdGUuZmllbGRzLmdldChrZXkpO1xuICBpZiAoa25vd24pIHtcbiAgICBrbm93bi51c2VkID0gc3RhdGUuY2xvY2s7XG4gICAgcmV0dXJuIGtub3duO1xuICB9XG4gIC8vIE9ubHkgYSBuZXcgZmllbGQgbG9va3MgZm9yIHRoZSBvbmUgdG8gZHJvcCAoYSBoaXQgaXMgb25lIHdyaXRlLCBub3QgYSByZW9yZGVyIG9mIHRoZSBtYXApLlxuICBpZiAoc3RhdGUuZmllbGRzLnNpemUgPj0gRklFTERfQ0FDSEUpIHtcbiAgICBsZXQgb2xkZXN0OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgbGV0IG9sZGVzdFVzZSA9IEluZmluaXR5O1xuICAgIGZvciAoY29uc3QgW2NhbmRpZGF0ZSwgZmllbGRdIG9mIHN0YXRlLmZpZWxkcykge1xuICAgICAgaWYgKGZpZWxkLnVzZWQgPCBvbGRlc3RVc2UpIHtcbiAgICAgICAgb2xkZXN0VXNlID0gZmllbGQudXNlZDtcbiAgICAgICAgb2xkZXN0ID0gY2FuZGlkYXRlO1xuICAgICAgfVxuICAgIH1cbiAgICBzdGF0ZS5zcGFyZS5wdXNoKHN0YXRlLmZpZWxkcy5nZXQob2xkZXN0ISkhKTtcbiAgICBzdGF0ZS5maWVsZHMuZGVsZXRlKG9sZGVzdCEpO1xuICB9XG4gIGNvbnN0IGZpZWxkID0gYnVpbGQoKTtcbiAgZmllbGQudXNlZCA9IHN0YXRlLmNsb2NrO1xuICBzdGF0ZS5maWVsZHMuc2V0KGtleSwgZmllbGQpO1xuICByZXR1cm4gZmllbGQ7XG59XG5cbi8vIFRoZSB3YWxraW5nIGNvc3Qgb3ZlciB0aGUgd2hvbGUgbWFwIGZyb20gZXZlcnkgY2VsbCB0byB0aGUgbmVhcmVzdCBzb3VyY2UsIG9uIHRoZSB0ZXJyYWluIGFsb25lIChEaWFsJ3MgYWxnb3JpdGhtIG92ZXJcbi8vIGVpZ2h0IG5laWdoYm91cnMsIG5vIGNvcm5lciBjdXQpOiB0aGUgQUlzJyB3YWxraW5nIGRpc3RhbmNlcyBhbmQgcm91dGVzIChzZWUgd2Fsa2luZ0Rpc3RhbmNlLCB3YWxrUm91dGUpLlxuZnVuY3Rpb24gZ3JvdyhzdGF0ZTogVGVycmFpblJ1bnRpbWUsIHNvdXJjZXM6IG51bWJlcltdKTogRmllbGQge1xuICBjb25zdCB7IHdhbGssIG9mZnNldHMsIHRvcHMgfSA9IHN0YXRlO1xuICBjb25zdCBidWNrZXRzID0gc3RhdGUuYnVja2V0cyA/Pz0gQXJyYXkuZnJvbSh7IGxlbmd0aDogOCB9LCAoKSA9PiBuZXcgSW50MzJBcnJheSh3YWxrLmxlbmd0aCkpO1xuICBjb25zdCBmaWVsZCA9IHN0YXRlLnNwYXJlLnBvcCgpID8/IHsgZGlzdDogbmV3IEludDMyQXJyYXkod2Fsay5sZW5ndGgpLCBuZXh0OiBuZXcgSW50MzJBcnJheSh3YWxrLmxlbmd0aCksIHVzZWQ6IDAgfTtcbiAgY29uc3QgZGlzdCA9IGZpZWxkLmRpc3Q7XG4gIGRpc3QuZmlsbChVTlJFQUNIRUQpO1xuICBmaWVsZC5uZXh0LmZpbGwoVU5LTk9XTik7XG4gIHRvcHMuZmlsbCgwKTtcbiAgbGV0IHBlbmRpbmcgPSAwO1xuICBmb3IgKGNvbnN0IHNvdXJjZSBvZiBzb3VyY2VzKSB7XG4gICAgZGlzdFtzb3VyY2VdID0gMDtcbiAgICBidWNrZXRzWzBdIVt0b3BzWzBdISsrXSA9IHNvdXJjZTtcbiAgICBwZW5kaW5nICs9IDE7XG4gIH1cbiAgZm9yIChsZXQgY29zdCA9IDA7IHBlbmRpbmcgPiAwOyBjb3N0ICs9IDEpIHtcbiAgICBjb25zdCBzbG90ID0gY29zdCAmIDc7XG4gICAgY29uc3QgYnVja2V0ID0gYnVja2V0c1tzbG90XSE7XG4gICAgd2hpbGUgKHRvcHNbc2xvdF0hID4gMCkge1xuICAgICAgY29uc3QgYXQgPSBidWNrZXRbLS10b3BzW3Nsb3RdIV0hO1xuICAgICAgcGVuZGluZyAtPSAxO1xuICAgICAgaWYgKGRpc3RbYXRdICE9PSBjb3N0KSBjb250aW51ZTtcbiAgICAgIGZvciAobGV0IGRpcmVjdGlvbiA9IDA7IGRpcmVjdGlvbiA8IDg7IGRpcmVjdGlvbiArPSAxKSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBhdCArIG9mZnNldHNbZGlyZWN0aW9uXSE7XG4gICAgICAgIGlmICh3YWxrW25leHRdICE9PSAxKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgcmVhY2hlZCA9IGNvc3QgKyAoZGlyZWN0aW9uIDwgNCA/IFNUUkFJR0hUIDogRElBR09OQUwpO1xuICAgICAgICBpZiAocmVhY2hlZCA+PSBkaXN0W25leHRdISB8fCAhc3RlcEFsbG93ZWQoc3RhdGUsIGF0LCBkaXJlY3Rpb24pKSBjb250aW51ZTtcbiAgICAgICAgZGlzdFtuZXh0XSA9IHJlYWNoZWQ7XG4gICAgICAgIGNvbnN0IGludG8gPSByZWFjaGVkICYgNztcbiAgICAgICAgYnVja2V0c1tpbnRvXSFbdG9wc1tpbnRvXSErK10gPSBuZXh0O1xuICAgICAgICBwZW5kaW5nICs9IDE7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBmaWVsZDtcbn1cblxuLy8gVGhlIHdhbGthYmxlIGNlbGwgd2hvc2UgY2VudGVyIGlzIG5lYXJlc3QgdGhlIGdpdmVuIGNlbGwncyBjZW50ZXIgKHRoZSBsb3dlc3QgaW5kZXggYW1vbmcgZXF1YWxzKSwgb3IgLTEgd2hlbiBub25lIGlzLlxuZnVuY3Rpb24gbmVhcmVzdFdhbGthYmxlKHN0YXRlOiBUZXJyYWluUnVudGltZSwgYXQ6IG51bWJlcik6IG51bWJlciB7XG4gIGlmIChhdCA+PSAwICYmIHN0YXRlLndhbGtbYXRdID09PSAxKSByZXR1cm4gYXQ7XG4gIGNvbnN0IGtub3duID0gc3RhdGUubmVhcmVzdC5nZXQoYXQpO1xuICBpZiAoa25vd24gIT09IHVuZGVmaW5lZCkgcmV0dXJuIGtub3duO1xuICBjb25zdCB7IHRlcnJhaW4sIHdpZHRoIH0gPSBzdGF0ZTtcbiAgY29uc3QgY29sID0gYXQgPCAwID8gMCA6IChhdCAlIHdpZHRoKSAtIDE7XG4gIGNvbnN0IHJvdyA9IGF0IDwgMCA/IDAgOiBNYXRoLmZsb29yKGF0IC8gd2lkdGgpIC0gMTtcbiAgbGV0IGJlc3QgPSAtMTtcbiAgbGV0IGJlc3REaXN0YW5jZSA9IEluZmluaXR5O1xuICBjb25zdCBsaW1pdCA9IE1hdGgubWF4KHRlcnJhaW4uY29scywgdGVycmFpbi5yb3dzKTtcbiAgZm9yIChsZXQgcmluZyA9IDE7IHJpbmcgPD0gbGltaXQ7IHJpbmcgKz0gMSkge1xuICAgIC8vIEEgY2VsbCBvbiB0aGlzIHJpbmcgaXMgYXQgbGVhc3QgYHJpbmdgIGNlbGxzIGF3YXk7IHN0b3Agb25jZSBub25lIGNhbiBiZWF0IHRoZSBiZXN0LlxuICAgIGlmIChyaW5nICogcmluZyA+IGJlc3REaXN0YW5jZSkgYnJlYWs7XG4gICAgZm9yIChsZXQgciA9IHJvdyAtIHJpbmc7IHIgPD0gcm93ICsgcmluZzsgciArPSAxKSB7XG4gICAgICBmb3IgKGxldCBjID0gY29sIC0gcmluZzsgYyA8PSBjb2wgKyByaW5nOyBjICs9IDEpIHtcbiAgICAgICAgaWYgKE1hdGgubWF4KE1hdGguYWJzKGMgLSBjb2wpLCBNYXRoLmFicyhyIC0gcm93KSkgIT09IHJpbmcpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoYyA8IDAgfHwgciA8IDAgfHwgYyA+PSB0ZXJyYWluLmNvbHMgfHwgciA+PSB0ZXJyYWluLnJvd3MpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBpbmRleCA9IHBhZChzdGF0ZSwgYywgcik7XG4gICAgICAgIGlmIChzdGF0ZS53YWxrW2luZGV4XSAhPT0gMSkgY29udGludWU7XG4gICAgICAgIGNvbnN0IGdhcCA9IChjIC0gY29sKSAqIChjIC0gY29sKSArIChyIC0gcm93KSAqIChyIC0gcm93KTtcbiAgICAgICAgaWYgKGdhcCA8IGJlc3REaXN0YW5jZSB8fCAoZ2FwID09PSBiZXN0RGlzdGFuY2UgJiYgaW5kZXggPCBiZXN0KSkge1xuICAgICAgICAgIGJlc3REaXN0YW5jZSA9IGdhcDtcbiAgICAgICAgICBiZXN0ID0gaW5kZXg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKHN0YXRlLm5lYXJlc3Quc2l6ZSA+IDRfMDk2KSBzdGF0ZS5uZWFyZXN0LmNsZWFyKCk7XG4gIHN0YXRlLm5lYXJlc3Quc2V0KGF0LCBiZXN0KTtcbiAgcmV0dXJuIGJlc3Q7XG59XG4iXSwibWFwcGluZ3MiOiJBQStCTyxhQUFNLGNBQXFHO0FBQUEsRUFDaEgsS0FBSyxFQUFFLE1BQU0sTUFBTSxLQUFLLE9BQU8sTUFBTSxHQUFHLE1BQU0sRUFBRTtBQUFBLEVBQ2hELEtBQUssRUFBRSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLElBQUk7QUFBQSxFQUNwRCxHQUFHLEVBQUUsTUFBTSxNQUFNLEtBQUssT0FBTyxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQUEsRUFDaEQsS0FBSyxFQUFFLE1BQU0sTUFBTSxLQUFLLE9BQU8sTUFBTSxHQUFHLE1BQU0sRUFBRTtBQUFBLEVBQ2hELEdBQUcsRUFBRSxNQUFNLE9BQU8sS0FBSyxPQUFPLE1BQU0sR0FBRyxNQUFNLEVBQUU7QUFBQSxFQUMvQyxLQUFLLEVBQUUsTUFBTSxPQUFPLEtBQUssT0FBTyxNQUFNLEdBQUcsTUFBTSxFQUFFO0FBQUEsRUFDakQsS0FBSyxFQUFFLE1BQU0sT0FBTyxLQUFLLE1BQU0sTUFBTSxHQUFHLE1BQU0sRUFBRTtBQUNsRDtBQVdBLE1BQU0sV0FBK0M7QUFBQSxFQUNuRCxNQUFNLElBQUksSUFBSSxPQUFPLEtBQUssV0FBVyxFQUFFLE9BQU8sQ0FBQyxTQUFTLFlBQVksSUFBSSxFQUFHLElBQUksQ0FBQztBQUFBLEVBQ2hGLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxXQUFXLEVBQUUsT0FBTyxDQUFDLFNBQVMsWUFBWSxJQUFJLEVBQUcsR0FBRyxDQUFDO0FBQ2hGO0FBQ0EsTUFBTSxZQUFZO0FBQ2xCLE1BQU0sVUFBVTtBQUVoQixNQUFNLFdBQVc7QUFDakIsTUFBTSxXQUFXO0FBR2pCLE1BQU0sWUFBWTtBQUNsQixNQUFNLGFBQWE7QUFHbkIsTUFBTSxjQUFjO0FBR3BCLE1BQU0sbUJBQW1CO0FBRXpCLE1BQU0sU0FBUztBQUNmLE1BQU0sY0FBYztBQUdwQixNQUFNLGdCQUFnQjtBQUN0QixNQUFNLFVBQVU7QUFFaEIsTUFBTSxhQUFhO0FBRVosZ0JBQVMsZ0JBQWdCLE1BQTJDO0FBQ3pFLE1BQUksU0FBUyxJQUFLLFFBQU87QUFDekIsTUFBSSxTQUFTLElBQUssUUFBTztBQUN6QixNQUFJLFNBQVMsSUFBSyxRQUFPO0FBQ3pCLE1BQUksU0FBUyxJQUFLLFFBQU87QUFDekIsTUFBSSxTQUFTLElBQUssUUFBTztBQUN6QixNQUFJLFNBQVMsSUFBSyxRQUFPO0FBQ3pCLFNBQU87QUFDVDtBQUVPLGdCQUFTLGVBQWUsTUFBMEI7QUFDdkQsU0FBTyxTQUFTLFVBQWEsU0FBUyxLQUFLLElBQUksSUFBSTtBQUNyRDtBQUlPLGdCQUFTLFdBQVcsS0FBK0IsR0FBVyxHQUFXLFFBQWUsUUFBUTtBQUNyRyxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFFBQU0sUUFBUSxRQUFRLFNBQVMsS0FBSztBQUNwQyxTQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsTUFBTTtBQUM1QztBQUlPLGdCQUFTLGFBQWEsS0FBK0IsR0FBVyxHQUFXLFFBQWUsUUFBUTtBQUN2RyxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFFBQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxLQUFLO0FBQ3pDLFNBQU8sTUFBTSxLQUFLLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxNQUFNO0FBQzVDO0FBTU8sZ0JBQVMsU0FBUyxLQUErQixNQUFhLElBQVcsUUFBZSxRQUFlO0FBQzVHLE1BQUksYUFBYSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUMsYUFBYSxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxFQUFHLFFBQU87QUFDOUYsTUFBSSxhQUFhLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLLEVBQUcsUUFBTyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxFQUFFO0FBQ3hFLE1BQUksYUFBYSxLQUFLLEtBQUssR0FBRyxHQUFHLEdBQUcsS0FBSyxFQUFHLFFBQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEdBQUcsRUFBRTtBQUN4RSxTQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUU7QUFDaEM7QUFJTyxnQkFBUyxlQUFlLEtBQStCLE9BQWMsUUFBZSxRQUEyQjtBQUNwSCxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFFBQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxLQUFLO0FBQ3pDLFFBQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQztBQUN4QyxRQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUssZ0JBQWdCLE9BQU8sRUFBRTtBQUNwRCxTQUFPLE9BQU8sSUFBSSxTQUFZLFNBQVMsT0FBTyxJQUFJO0FBQ3BEO0FBS0EsTUFBTSxjQUFjLEVBQUUsTUFBTSxHQUFHLE1BQU0sRUFBRTtBQUVoQyxnQkFBUyxZQUFZLEtBQStCLEdBQVcsR0FBVyxRQUFlLFFBQXdDO0FBQ3RJLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLE1BQUksQ0FBQyxXQUFXLFVBQVUsTUFBTyxRQUFPO0FBQ3hDLFFBQU0sUUFBUSxZQUFZLFNBQVMsR0FBRyxDQUFDO0FBQ3ZDLFFBQU0sU0FBUyxRQUFRLElBQUksU0FBWSxZQUFZLFFBQVEsTUFBTSxLQUFLLENBQUU7QUFDeEUsU0FBTyxVQUFVLE9BQU8sT0FBTyxTQUFTO0FBQzFDO0FBRU8sZ0JBQVMsWUFBWSxTQUFrQixHQUFXLEdBQVc7QUFDbEUsUUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLFFBQVEsSUFBSTtBQUN2QyxRQUFNLE1BQU0sS0FBSyxNQUFNLElBQUksUUFBUSxJQUFJO0FBQ3ZDLE1BQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsUUFBUSxPQUFPLFFBQVEsS0FBTSxRQUFPO0FBQzdFLFNBQU8sTUFBTSxRQUFRLE9BQU87QUFDOUI7QUFFTyxnQkFBUyxXQUFXLFNBQWtCLE9BQXNCO0FBQ2pFLFFBQU0sTUFBTSxRQUFRLFFBQVE7QUFDNUIsUUFBTSxPQUFPLFFBQVEsT0FBTyxRQUFRO0FBQ3BDLFNBQU8sRUFBRSxJQUFJLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sUUFBUSxLQUFLO0FBQ3hFO0FBTU8sZ0JBQVMscUJBQXFCLEtBQStCLEdBQVcsR0FBVyxRQUFnQjtBQUN4RyxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFFBQU0sUUFBUSxRQUFRLFNBQVMsTUFBTTtBQUNyQyxTQUFPLG1CQUFtQixTQUFTLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxTQUFTLE1BQU0sS0FBSyxFQUFFLE1BQU0sS0FBSyxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sUUFBUSxTQUFTLElBQUksTUFBTSxHQUFHO0FBQ3RKO0FBUU8sZ0JBQVMsaUJBQWlCLEtBQStCLEdBQVcsR0FBVyxRQUFnQjtBQUNwRyxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFFBQU0sT0FBTyxRQUFRLFNBQVMsTUFBTTtBQUNwQyxRQUFNLE1BQU0sUUFBUSxTQUFTLEtBQUs7QUFDbEMsUUFBTSxFQUFFLFFBQVEsS0FBSyxJQUFJLFNBQVMsR0FBRztBQUNyQyxNQUFJLE1BQU07QUFDVixNQUFJLE1BQU07QUFDVixRQUFNLE9BQU8sbUJBQW1CLFNBQVMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLFNBQVM7QUFDbkUsUUFBSSxLQUFLLEtBQUssRUFBRSxNQUFNLEVBQUcsT0FBTTtBQUMvQixRQUFJLElBQUksS0FBSyxFQUFFLE1BQU0sS0FBSyxLQUFLLE9BQU8sRUFBRSxDQUFFLEtBQU0sV0FBWSxPQUFNO0FBQ2xFLFlBQVEsSUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFLLEtBQUssS0FBSyxFQUFFLE1BQU0sTUFBTSxRQUFRLFNBQVMsSUFBSSxNQUFNO0FBQUEsRUFDbkYsQ0FBQztBQUNELFNBQU8sUUFBUSxPQUFPO0FBQ3hCO0FBS08sYUFBTSxhQUFhO0FBS25CLGdCQUFTLFdBQVcsS0FBK0IsUUFBa0M7QUFDMUYsUUFBTSxVQUFVLElBQUk7QUFDcEIsTUFBSSxDQUFDLFFBQVMsUUFBTyxDQUFDO0FBQ3RCLFFBQU0sTUFBTSxRQUFRLFNBQVMsS0FBSztBQUNsQyxRQUFNLFNBQVMsSUFBSSxXQUFXLG9CQUFJLElBQUksR0FBRyxJQUFJLE1BQU07QUFDbkQsTUFBSSxNQUFPLFFBQU87QUFDbEIsUUFBTSxRQUFpQixDQUFDO0FBQ3hCLFFBQU0sRUFBRSxRQUFRLEtBQUssSUFBSSxTQUFTLEdBQUc7QUFDckMsTUFBSSxLQUFLLEtBQUssQ0FBQyxVQUFVLFNBQVMsVUFBVSxHQUFHO0FBRzdDLFVBQU0sT0FBTyxRQUFRLFNBQVMsTUFBTSxHQUFHLFFBQVEsUUFBUSxPQUFPO0FBQzlELFVBQU0sTUFBTSxJQUFJLFlBQVksU0FBUyxRQUFRLE9BQU8sRUFBRTtBQUN0RCxVQUFNLE1BQU0sSUFBSSxZQUFZLElBQUksTUFBTSxHQUFHLFVBQVUsSUFBSSxZQUFZLElBQUksTUFBTTtBQUM3RSxhQUFTLE1BQU0sR0FBRyxNQUFNLFFBQVEsTUFBTSxPQUFPO0FBQzNDLFVBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJO0FBQ3RCLGVBQVMsTUFBTSxHQUFHLE1BQU0sUUFBUSxNQUFNLE9BQU87QUFDM0MsY0FBTSxPQUFPLE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTTtBQUNuRixhQUFLLEtBQUssS0FBSyxFQUFFLE1BQU0sSUFBSSxJQUFJO0FBQy9CLGFBQUssSUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFLLEtBQUssT0FBTyxFQUFFLENBQUUsS0FBTSxhQUFhLElBQUk7QUFDbEUsYUFBTSxLQUFLLEtBQUssRUFBRSxNQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFNLFFBQVEsU0FBUyxJQUFJLE1BQU0sTUFBTSxJQUFJO0FBQ3pGLGNBQU0sT0FBTyxNQUFNLEtBQUssUUFBUSxNQUFNO0FBQ3RDLFlBQUksR0FBRyxJQUFJLElBQUksTUFBTSxLQUFLLElBQUs7QUFDL0IsWUFBSSxHQUFHLElBQUksSUFBSSxNQUFNLEtBQUssSUFBSztBQUMvQixnQkFBUSxHQUFHLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSztBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxjQUFjLFFBQVEsUUFBUSxJQUFJO0FBQy9DLFVBQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLElBQUksUUFBUSxRQUFRLE9BQU8sR0FBRTtBQUNyRSxVQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsT0FBTyxJQUFJLFFBQVEsUUFBUSxPQUFPLEdBQUUsSUFBSTtBQUN4RSxVQUFNLFFBQVEsQ0FBQyxPQUFvQixNQUFjLEtBQWEsT0FBZSxXQUMzRSxNQUFNLFNBQVMsUUFBUSxLQUFLLElBQUssTUFBTSxNQUFNLFFBQVEsS0FBSyxJQUFLLE1BQU0sU0FBUyxRQUFRLElBQUksSUFBSyxNQUFNLE1BQU0sUUFBUSxJQUFJO0FBQ3pILGFBQVMsUUFBUSxHQUFHLFFBQVEsUUFBUSxPQUFPLFFBQVEsTUFBTSxTQUFTLEdBQUc7QUFDbkUsWUFBTSxNQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU0sS0FBSyxNQUFNLFFBQVEsUUFBUSxJQUFJO0FBQ3ZFLFlBQU0sT0FBTyxNQUFNLE9BQU8sTUFBTSxNQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sR0FBRyxTQUFTLE1BQU0sT0FBTztBQUMzRixVQUFJLE9BQU8sS0FBSyxNQUFNLEtBQUssUUFBUSxRQUFRLFFBQVEsU0FBUyxRQUFRLEtBQU07QUFDMUUsVUFBSSxDQUFDLE1BQU0sU0FBUyxNQUFNLEtBQUssT0FBTyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU8sTUFBTTtBQUMxSCxjQUFNLEtBQUssV0FBVyxTQUFTLEtBQUssQ0FBQztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNBLE1BQUksT0FBTyxJQUFJLFFBQVEsS0FBSztBQUM1QixTQUFPO0FBQ1Q7QUFRTyxnQkFBUyxjQUFjLFFBQWdCLE1BQWM7QUFDMUQsU0FBUSxLQUFLLEtBQU0sSUFBSSxTQUFVLElBQUksSUFBSSxPQUFRO0FBQ25EO0FBSU8sZ0JBQVMsZ0JBQWdCLEtBQStCLFFBQWdCLE9BQXFCO0FBQ2xHLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLE1BQUksQ0FBQyxRQUFTLFFBQU8sRUFBRSxHQUFHLE1BQU0sR0FBRyxHQUFHLE1BQU0sRUFBRTtBQUM5QyxRQUFNLE9BQU8sUUFBUTtBQUNyQixRQUFNLFNBQVMsS0FBSyxLQUFNLElBQUksU0FBVSxJQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sSUFBSTtBQUNyRSxTQUFPLEVBQUUsR0FBRyxLQUFLLE9BQU8sTUFBTSxJQUFJLFVBQVUsSUFBSSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUssT0FBTyxNQUFNLElBQUksVUFBVSxJQUFJLElBQUksT0FBTyxPQUFPO0FBQzlIO0FBR08sZ0JBQVMsZUFBZSxNQUFjLEdBQVcsR0FBVyxRQUFnQjtBQUNqRixRQUFNLE9BQU8sY0FBYyxRQUFRLElBQUk7QUFDdkMsUUFBTSxRQUFRLENBQUMsU0FBaUIsS0FBSyxLQUFLLE9BQU8sT0FBTyxHQUFHO0FBQzNELFNBQU8sRUFBRSxNQUFNLE1BQU0sSUFBSSxJQUFJLEdBQUcsT0FBTyxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksSUFBSSxHQUFHLFFBQVEsTUFBTSxJQUFJLElBQUksSUFBSSxFQUFFO0FBQ2hIO0FBSUEsU0FBUyxtQkFBbUIsU0FBa0IsR0FBVyxHQUFXLFFBQWdCLFFBQStDO0FBQ2pJLFFBQU0sT0FBTyxRQUFRO0FBQ3JCLFFBQU0sUUFBUSxRQUFRLE9BQU87QUFDN0IsUUFBTSxFQUFFLE1BQU0sT0FBTyxLQUFLLE9BQU8sSUFBSSxlQUFlLE1BQU0sR0FBRyxHQUFHLE1BQU07QUFDdEUsV0FBUyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUMzQyxhQUFTLE1BQU0sTUFBTSxPQUFPLE9BQU8sT0FBTyxHQUFHO0FBQzNDLFVBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsUUFBUSxPQUFPLFFBQVEsS0FBTSxRQUFPO0FBQzdFLFVBQUksQ0FBQyxRQUFRLE1BQU0sS0FBSyxRQUFRLE1BQU0sR0FBRyxNQUFNLFFBQVEsT0FBTyxHQUFHLEVBQUcsUUFBTztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUtPLGdCQUFTLGFBQWEsS0FBb0QsR0FBVyxHQUFXLFFBQWUsUUFBZTtBQUNuSSxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPLEVBQUUsR0FBRyxFQUFFO0FBQzVCLFFBQU0sUUFBUSxRQUFRLFNBQVMsS0FBSztBQUNwQyxRQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLEtBQUs7QUFDN0MsUUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxNQUFNO0FBQzlDLFFBQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLElBQUksUUFBUSxPQUFPLFFBQVEsT0FBTyxJQUFLLEdBQUcsS0FBSyxJQUFJLElBQUksUUFBUSxPQUFPLFFBQVEsT0FBTyxJQUFLLENBQUM7QUFDNUgsTUFBSSxNQUFNLEtBQUssRUFBRSxNQUFNLEVBQUcsUUFBTyxFQUFFLEdBQUcsSUFBSSxHQUFHLEdBQUc7QUFDaEQsUUFBTSxVQUFVLGdCQUFnQixPQUFPLEVBQUU7QUFDekMsU0FBTyxVQUFVLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxHQUFHLElBQUksU0FBUyxPQUFPLE9BQU87QUFDakU7QUFHTyxnQkFBUyxnQkFBZ0IsS0FBK0IsR0FBVSxHQUFVLFFBQWUsUUFBUTtBQUN4RyxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFNBQU8sYUFBYSxRQUFRLEtBQUssU0FBUyxLQUFLLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQ3RFO0FBS08sZ0JBQVMsV0FBVyxLQUErQixNQUFhLE1BQWEsUUFBZSxRQUFlO0FBQ2hILFFBQU0sVUFBVSxJQUFJO0FBQ3BCLE1BQUksQ0FBQyxRQUFTLFFBQU87QUFDckIsUUFBTSxTQUFTLFFBQVEsU0FBUyxLQUFLO0FBQ3JDLFFBQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxLQUFLO0FBQ3pDLFFBQU0sUUFBUSxNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUN6QyxRQUFNLFNBQVMsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDMUMsTUFBSSxRQUFRLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxNQUFNLE1BQU0sRUFBRyxRQUFPO0FBQ2pFLE1BQUksYUFBYSxPQUFPLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFHLFFBQU87QUFHaEUsUUFBTSxPQUFPLGdCQUFnQixPQUFPLEtBQUs7QUFDekMsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLFNBQVMsU0FBUyxPQUFPLEtBQUssS0FBSyxNQUFNLEVBQUcsUUFBTyxTQUFTLE9BQU8sSUFBSTtBQUMzRSxRQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLFFBQU0sTUFBTSxnQkFBZ0IsT0FBTyxRQUFRLE9BQU8sTUFBTSxNQUFNO0FBQzlELFNBQU8sVUFBVSxPQUFPLFFBQVEsT0FBTyxNQUFNLE1BQU0sS0FBSyxRQUFRLFNBQVMsT0FBTyxTQUFTLE9BQU8sR0FBRyxDQUFDO0FBQ3RHO0FBS08sZ0JBQVMsZ0JBQWdCLEtBQStCLE1BQWEsTUFBYSxRQUFlLFFBQWU7QUFDckgsUUFBTSxVQUFVLElBQUk7QUFDcEIsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixRQUFNLFNBQVMsUUFBUSxTQUFTLEtBQUs7QUFDckMsUUFBTSxRQUFRLFFBQVEsS0FBSyxTQUFTLEtBQUs7QUFDekMsUUFBTSxRQUFRLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLFFBQU0sU0FBUyxNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssQ0FBQztBQUMxQyxNQUFJLFFBQVEsS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLE1BQU0sTUFBTSxFQUFHLFFBQU87QUFDakUsUUFBTSxPQUFPLGdCQUFnQixPQUFPLEtBQUs7QUFDekMsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixRQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLFFBQU0sTUFBTSxnQkFBZ0IsT0FBTyxRQUFRLE9BQU8sTUFBTSxNQUFNO0FBQzlELE1BQUksTUFBTSxLQUFLLEdBQUcsTUFBTSxFQUFHLFFBQU8sUUFBUSxTQUFTLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDN0UsUUFBTSxRQUFRLFlBQVksT0FBTyxRQUFRLE9BQU8sR0FBRyxFQUFFO0FBQ3JELFFBQU0sUUFBUSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSztBQUNoRCxNQUFJLFFBQVEsS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFNLFVBQVcsUUFBTztBQUN6RCxNQUFJLEtBQUs7QUFDVCxXQUFTLE9BQU8sU0FBUyxPQUFPLE9BQU8sRUFBRSxHQUFHLFFBQVEsR0FBRyxPQUFPLFNBQVMsT0FBTyxPQUFPLEVBQUUsRUFBRyxNQUFLO0FBQy9GLFNBQU8sU0FBUyxPQUFPLEVBQUU7QUFDM0I7QUFLQSxTQUFTLFVBQVUsT0FBdUIsUUFBd0IsT0FBYyxNQUFhLE1BQWMsUUFBZ0IsTUFBb0I7QUFDN0ksTUFBSSxLQUFLO0FBQ1QsTUFBSSxRQUFRO0FBQ1osTUFBSSxNQUFNLE1BQU0sT0FBTyxRQUFRLE9BQU8sSUFBSSxNQUFNO0FBQ2hELFdBQVMsT0FBTyxHQUFHLFFBQVEsYUFBYSxLQUFLLFFBQVEsR0FBRztBQUN0RCxRQUFJLE9BQU8sU0FBUyxPQUFPLElBQUksT0FBTyxFQUFFO0FBQ3hDLFFBQUksT0FBTyxHQUFHO0FBR1osVUFBSSxDQUFDLElBQUksS0FBTTtBQUNmLFlBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxPQUFPLElBQUksTUFBTTtBQUNyRCxVQUFJLFVBQVUsQ0FBQyxPQUFPLE1BQU07QUFDMUIsY0FBTTtBQUNOLGVBQU8sU0FBUyxPQUFPLElBQUksT0FBTyxFQUFFO0FBQ3BDLFlBQUksT0FBTyxFQUFHO0FBQUEsTUFDaEIsT0FBTztBQUNMLGVBQU8sS0FBSyxJQUFJLEtBQUs7QUFDckIsWUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUc7QUFDNUIsY0FBTSxNQUFNLE9BQU8sUUFBUSxPQUFPLE1BQU0sTUFBTTtBQUFBLE1BQ2hEO0FBQUEsSUFDRjtBQUNBLFNBQUs7QUFDTCxRQUFJLFNBQVMsV0FBWSxTQUFRO0FBQ2pDLFFBQUksT0FBTyxDQUFDLElBQUksUUFBUSxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFHO0FBQUEsRUFDdkY7QUFLQSxNQUFJLE9BQU8sS0FBTSxRQUFPLFNBQVMsU0FBUyxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBQ3JFLFFBQU0sTUFBTSxPQUFPLFNBQVMsT0FBTyxTQUFTLE9BQU8sRUFBRTtBQUNyRCxNQUFJLFFBQVEsS0FBSyxhQUFhLE9BQU8sS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEVBQUcsUUFBTztBQUMzRSxTQUFPLFVBQVUsU0FBUyxPQUFPLFNBQVMsT0FBTyxLQUFLO0FBQ3hEO0FBSUEsU0FBUyxNQUFNLE9BQXVCLFFBQXdCLE9BQWMsSUFBWSxRQUFrRTtBQUN4SixRQUFNLE9BQU8sWUFBWSxPQUFPLFFBQVEsT0FBTyxNQUFNO0FBQ3JELFFBQU0sUUFBUSxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLO0FBQ25ELE1BQUksU0FBUyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssSUFBSyxVQUFXLFFBQU8sRUFBRSxPQUFPLEtBQUssTUFBTTtBQUNsRixRQUFNLE9BQU8sUUFBUSxPQUFPLE9BQU8sTUFBTSxPQUFPLEVBQUUsR0FBSSxRQUFRLEtBQUssS0FBSztBQUV4RSxNQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLENBQUMsS0FBTSxVQUFXLFFBQU87QUFDM0YsU0FBTyxFQUFFLE9BQU8sS0FBSyxPQUFPLEtBQUs7QUFDbkM7QUFtQ0EsU0FBUyxRQUFRLE9BQThCO0FBQzdDLE1BQUksTUFBTSxNQUFPLFFBQU8sTUFBTTtBQUM5QixRQUFNLEVBQUUsUUFBUSxJQUFJO0FBQ3BCLFFBQU0sVUFBVSxLQUFLLEtBQUssUUFBUSxPQUFPLE1BQU07QUFDL0MsUUFBTSxPQUFPLEtBQUssS0FBSyxRQUFRLE9BQU8sTUFBTTtBQUM1QyxRQUFNLFFBQWU7QUFBQSxJQUNuQjtBQUFBLElBQ0E7QUFBQSxJQUNBLE9BQU8sb0JBQUksSUFBSTtBQUFBLElBQ2YsU0FBUyxvQkFBSSxJQUFJO0FBQUEsSUFDakIsUUFBUSxJQUFJLFdBQVcsTUFBTSxLQUFLLE1BQU0sRUFBRSxLQUFLLEVBQUU7QUFBQSxJQUNqRCxRQUFRLElBQUksV0FBVyxNQUFNLEtBQUssTUFBTSxFQUFFLEtBQUssRUFBRTtBQUFBLElBQ2pELE9BQU8sb0JBQUksSUFBSTtBQUFBLElBQ2YsT0FBTyxvQkFBSSxJQUFJO0FBQUEsSUFDZixTQUFTLG9CQUFJLElBQUk7QUFBQSxFQUNuQjtBQUNBLFFBQU0sUUFBUTtBQUNkLFFBQU0sTUFBTSxNQUFNLEtBQUssRUFBRSxRQUFRLFVBQVUsS0FBSyxHQUFHLENBQUMsR0FBRyxXQUFXLE1BQU07QUFDeEUsYUFBVyxVQUFVLElBQUssY0FBYSxPQUFPLE9BQU8sTUFBTTtBQUMzRCxhQUFXLFVBQVUsSUFBSyxZQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRyxZQUFXLE9BQU8sT0FBTyxTQUFTLElBQUksS0FBSztBQUNqRyxhQUFXLFVBQVUsSUFBSyxZQUFXLE9BQU8sT0FBTyxNQUFNO0FBQ3pELGVBQWEsT0FBTyxLQUFLO0FBQ3pCLFNBQU87QUFDVDtBQUlBLFNBQVMsVUFBVSxPQUF1QixPQUFjLE9BQW9CO0FBQzFFLFFBQU0sVUFBVSxDQUFDLEdBQUcsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQy9DLFFBQU0sVUFBVSxvQkFBSSxJQUFZO0FBQ2hDLFFBQU0sVUFBVSxvQkFBSSxJQUFZO0FBQ2hDLGFBQVcsVUFBVSxTQUFTO0FBQzVCLGlCQUFhLE9BQU8sT0FBTyxNQUFNO0FBQ2pDLFVBQU0sTUFBTSxTQUFTLE1BQU07QUFDM0IsVUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTztBQUM3QyxZQUFRLElBQUksTUFBTTtBQUNsQixlQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRyxTQUFRLElBQUksU0FBUyxJQUFJLEtBQUs7QUFDMUQsUUFBSSxNQUFNLEdBQUc7QUFDWCxjQUFRLEtBQUssU0FBUyxLQUFLLENBQUM7QUFDNUIsY0FBUSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3hCO0FBQ0EsUUFBSSxNQUFNLEdBQUc7QUFDWCxjQUFRLEtBQUssU0FBUyxNQUFNLFdBQVcsSUFBSSxDQUFDO0FBQzVDLGNBQVEsSUFBSSxTQUFTLE1BQU0sT0FBTztBQUFBLElBQ3BDO0FBQ0EsUUFBSSxNQUFNLElBQUksTUFBTSxRQUFTLFNBQVEsSUFBSSxTQUFTLENBQUM7QUFDbkQsUUFBSSxNQUFNLElBQUksTUFBTSxLQUFNLFNBQVEsSUFBSSxTQUFTLE1BQU0sT0FBTztBQUFBLEVBQzlEO0FBQ0EsYUFBVyxVQUFVLENBQUMsR0FBRyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRztBQUN2RCxlQUFXLE9BQU8sTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLENBQUMsR0FBRztBQUNqRCxZQUFNLE1BQU0sT0FBTyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxPQUFPLE1BQU0sQ0FBQztBQUFBLElBQzVCO0FBQ0EsZUFBVyxPQUFPLE9BQU8sTUFBTTtBQUFBLEVBQ2pDO0FBQ0EsYUFBVyxVQUFVLENBQUMsR0FBRyxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsRUFBRyxZQUFXLE9BQU8sT0FBTyxNQUFNO0FBQ3hGLGVBQWEsT0FBTyxLQUFLO0FBR3pCLGFBQVcsVUFBVSxDQUFDLEdBQUcsTUFBTSxNQUFNLEtBQUssQ0FBQyxHQUFHO0FBQzVDLFVBQU0sU0FBUyxTQUFTLE9BQU8sT0FBTyxNQUFNO0FBQzVDLFVBQU0sT0FBTyxRQUFRLEtBQUssQ0FBQ0EsV0FBVSxLQUFLLElBQUtBLFNBQVEsTUFBTSxVQUFZLFNBQVMsTUFBTSxPQUFRLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxNQUFNQSxTQUFRLE1BQU0sT0FBTyxJQUFJLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTyxDQUFDLEtBQUssQ0FBQztBQUMvTCxRQUFJLEtBQU0sT0FBTSxNQUFNLE9BQU8sTUFBTTtBQUFBLEVBQ3JDO0FBQ0EsUUFBTSxNQUFNLE1BQU07QUFDbEIsUUFBTSxRQUFRLE1BQU07QUFDdEI7QUFFQSxTQUFTLFVBQVUsT0FBdUIsT0FBYyxRQUFxQjtBQUMzRSxRQUFNLE1BQU8sU0FBUyxNQUFNLFVBQVc7QUFDdkMsUUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTyxJQUFJO0FBQ2pELFNBQU8sRUFBRSxNQUFNLE1BQU0sR0FBRyxLQUFLLE1BQU0sR0FBRyxPQUFPLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxPQUFPLEdBQUcsR0FBRyxRQUFRLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxPQUFPLEdBQUcsRUFBRTtBQUM5STtBQUVBLFNBQVMsU0FBUyxPQUF1QixPQUFjLElBQVk7QUFDakUsUUFBTSxNQUFPLEtBQUssTUFBTSxRQUFTO0FBQ2pDLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSTtBQUMzQyxTQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSSxNQUFNLFVBQVUsS0FBSyxNQUFNLE1BQU0sTUFBTTtBQUMzRTtBQUdBLFNBQVMsTUFBTSxLQUFVLElBQVksT0FBZTtBQUNsRCxRQUFNLE1BQU0sS0FBSztBQUNqQixRQUFNLE9BQU8sS0FBSyxPQUFPO0FBQ3pCLE1BQUksTUFBTSxJQUFJLFFBQVEsTUFBTSxJQUFJLE9BQU8sT0FBTyxJQUFJLE9BQU8sSUFBSSxTQUFTLE9BQU8sSUFBSSxNQUFNLElBQUksT0FBUSxRQUFPO0FBQzFHLFVBQVEsTUFBTSxJQUFJLE9BQU8sSUFBSSxTQUFTLE1BQU0sSUFBSTtBQUNsRDtBQUdBLFNBQVMsYUFBYSxPQUF1QixPQUFjLFFBQWdCO0FBQ3pFLFFBQU0sRUFBRSxNQUFNLFNBQVMsTUFBTSxJQUFJO0FBQ2pDLFFBQU0sTUFBTSxVQUFVLE9BQU8sT0FBTyxNQUFNO0FBQzFDLFdBQVMsTUFBTSxJQUFJLEtBQUssTUFBTSxJQUFJLE1BQU0sSUFBSSxRQUFRLE9BQU8sRUFBRyxVQUFTLE1BQU0sSUFBSSxNQUFNLE1BQU0sSUFBSSxPQUFPLElBQUksT0FBTyxPQUFPLEVBQUcsT0FBTSxPQUFPLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDL0osTUFBSSxRQUFRO0FBQ1osV0FBUyxNQUFNLElBQUksS0FBSyxNQUFNLElBQUksTUFBTSxJQUFJLFFBQVEsT0FBTyxHQUFHO0FBQzVELGFBQVMsTUFBTSxJQUFJLE1BQU0sTUFBTSxJQUFJLE9BQU8sSUFBSSxPQUFPLE9BQU8sR0FBRztBQUM3RCxZQUFNLE9BQU8sTUFBTSxRQUFRO0FBQzNCLFVBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUk7QUFDbkQsWUFBTSxRQUFRLFNBQVMsY0FBYyxLQUFLLElBQUksT0FBTyxjQUFjLENBQUM7QUFDcEUsZUFBUztBQUNULFlBQU0sT0FBTyxJQUFJLElBQUk7QUFDckIsZUFBUyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksR0FBRyxRQUFRLE1BQU0sUUFBUSxTQUFTLEdBQUc7QUFDcEUsY0FBTSxLQUFLLE1BQU0sS0FBSztBQUN0QixpQkFBUyxZQUFZLEdBQUcsWUFBWSxHQUFHLGFBQWEsR0FBRztBQUNyRCxnQkFBTSxPQUFPLEtBQUssUUFBUSxTQUFTO0FBQ25DLGNBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssQ0FBQyxZQUFZLE9BQU8sSUFBSSxTQUFTLEVBQUc7QUFDeEgsZ0JBQU0sT0FBTyxJQUFJLElBQUk7QUFDckIsZ0JBQU0sS0FBSyxJQUFJO0FBQUEsUUFDakI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsYUFBYSxPQUF1QixPQUFjO0FBQ3pELFFBQU0sRUFBRSxNQUFNLFFBQVEsSUFBSTtBQUMxQixRQUFNLE9BQU8sS0FBSyxFQUFFO0FBQ3BCLFFBQU0sUUFBUSxJQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3hDLFdBQVMsT0FBTyxHQUFHLE9BQU8sS0FBSyxRQUFRLFFBQVEsR0FBRztBQUNoRCxRQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxHQUFJO0FBQ25ELFVBQU0sT0FBTyxJQUFJLElBQUk7QUFDckIsUUFBSSxPQUFPO0FBQ1gsVUFBTSxNQUFNLElBQUk7QUFDaEIsYUFBUyxPQUFPLEdBQUcsT0FBTyxNQUFNLFFBQVEsR0FBRztBQUN6QyxZQUFNLEtBQUssTUFBTSxJQUFJO0FBQ3JCLGVBQVMsWUFBWSxHQUFHLFlBQVksR0FBRyxhQUFhLEdBQUc7QUFDckQsY0FBTSxPQUFPLEtBQUssUUFBUSxTQUFTO0FBQ25DLFlBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU0sQ0FBQyxZQUFZLE9BQU8sSUFBSSxTQUFTLEVBQUc7QUFDekYsY0FBTSxPQUFPLElBQUksSUFBSTtBQUNyQixjQUFNLE1BQU0sSUFBSTtBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUlBLFNBQVMsV0FBVyxPQUF1QixPQUFjLFFBQWdCO0FBQ3ZFLFFBQU0sU0FBUyxVQUFVO0FBQ3pCLFFBQU0sUUFBUSxTQUFTO0FBQ3ZCLFFBQU0sTUFBTSxTQUFTLE1BQU07QUFDM0IsUUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTztBQUM3QyxRQUFNLE9BQWlCLENBQUM7QUFDeEIsUUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0FBQzlCLE1BQUksUUFBUSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxNQUFNLFFBQVM7QUFDOUQsUUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBQ3hCLFFBQU0sTUFBTSxVQUFVLE9BQU8sT0FBTyxNQUFNO0FBQzFDLFFBQU0sU0FBUyxRQUFRLFFBQVE7QUFDL0IsUUFBTSxPQUFPLFFBQVEsSUFBSSxRQUFRLElBQUk7QUFDckMsUUFBTSxRQUFRLFNBQVMsSUFBSSxNQUFNLElBQUksU0FBUyxLQUFLLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxRQUFRLElBQUksT0FBTyxJQUFJLFFBQVE7QUFDL0csUUFBTSxRQUFRLFFBQVEsSUFBSTtBQUMxQixNQUFJLE1BQWdCLENBQUM7QUFDckIsUUFBTSxRQUFRLE1BQU07QUFDbEIsUUFBSSxJQUFJLFdBQVcsRUFBRztBQUN0QixVQUFNLE1BQU0sSUFBSSxDQUFDLElBQUssSUFBSSxRQUFRO0FBQ2xDLFNBQUssS0FBSyxHQUFHO0FBQ2IsVUFBTSxRQUFRLE9BQWlCLEVBQUUsS0FBSyxNQUFNLElBQUksV0FBVyxDQUFDLEdBQUcsTUFBTSxJQUFJLFdBQVcsQ0FBQyxFQUFFO0FBQ3ZGLFVBQU0sTUFBTSxJQUFJLEtBQUssRUFBRSxLQUFLLFFBQVEsT0FBTyxLQUFLLFFBQVEsT0FBTyxNQUFNLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUNuRixVQUFNLFFBQVEsUUFBUSxTQUFTLE1BQU0sVUFBVSxTQUFTO0FBQ3hELFVBQU0sTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLEtBQUssTUFBTSxHQUFHLFFBQVEsT0FBTyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsT0FBTyxNQUFNLEdBQUcsUUFBUSxDQUFDLFFBQVEsT0FBTyxNQUFNLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM3SSxVQUFNLENBQUM7QUFBQSxFQUNUO0FBQ0EsV0FBUyxPQUFPLEdBQUcsT0FBTyxNQUFNLFFBQVEsR0FBRztBQUN6QyxVQUFNLEtBQUssUUFBUSxPQUFPO0FBQzFCLFFBQUksS0FBSyxFQUFFLE1BQU0sS0FBSyxLQUFLLEtBQUssTUFBTSxNQUFNLEVBQUcsS0FBSSxLQUFLLEVBQUU7QUFBQSxRQUNyRCxPQUFNO0FBQUEsRUFDYjtBQUNBLFFBQU07QUFDUjtBQUdBLFNBQVMsWUFBWSxPQUFjLFFBQTRCO0FBQzdELFFBQU0sTUFBTSxTQUFTLE1BQU07QUFDM0IsUUFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTztBQUM3QyxRQUFNLE9BQU8sQ0FBQyxHQUFJLE1BQU0sUUFBUSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBSSxHQUFJLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFFO0FBQ3BHLE1BQUksTUFBTSxFQUFHLE1BQUssS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLE1BQU0sQ0FBQyxDQUFDO0FBQzNGLE1BQUksTUFBTSxFQUFHLE1BQUssS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLFNBQVMsTUFBTSxXQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxNQUFNLENBQUMsQ0FBQztBQUMzRyxTQUFPLEtBQUssS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsUUFBUSxNQUFNLE1BQU0sSUFBSSxHQUFHLENBQUU7QUFDdEU7QUFJQSxTQUFTLFdBQVcsT0FBdUIsT0FBYyxRQUFnQjtBQUN2RSxRQUFNLE1BQU0sVUFBVSxPQUFPLE9BQU8sTUFBTTtBQUMxQyxRQUFNLFFBQVEsWUFBWSxPQUFPLE1BQU07QUFDdkMsYUFBVyxRQUFRLE1BQU8sTUFBSyxRQUFRLFFBQVEsT0FBTyxLQUFLLEtBQUssS0FBSztBQUNyRSxhQUFXLFFBQVEsT0FBTztBQUN4QixTQUFLLFFBQVEsQ0FBQztBQUNkLGVBQVcsTUFBTSxPQUFPO0FBQ3RCLFVBQUksT0FBTyxLQUFNO0FBQ2pCLFVBQUksT0FBTztBQUNYLGlCQUFXLFFBQVEsS0FBSyxNQUFPLFFBQU8sS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLENBQUMsQ0FBRTtBQUNsRyxVQUFJLE9BQU8sVUFBVyxNQUFLLE1BQU0sS0FBSyxFQUFFLElBQUksR0FBRyxLQUFLLEtBQUssQ0FBQztBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUNGO0FBS0EsTUFBTSxZQUFZLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLElBQUksSUFBSSxDQUFDO0FBQzVDLE1BQU0sWUFBWSxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLElBQUksRUFBRTtBQUU1QyxTQUFTLFFBQVEsT0FBdUIsS0FBVSxPQUFpQixPQUE0QjtBQUM3RixRQUFNLE9BQU8sSUFBSSxRQUFRLElBQUk7QUFDN0IsU0FBTyxZQUFZLE9BQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxNQUFNLElBQUksV0FBVyxJQUFJLEdBQUcsTUFBTSxJQUFJLFdBQVcsSUFBSSxFQUFFLENBQUM7QUFDekc7QUFFQSxTQUFTLFlBQVksT0FBdUIsS0FBVSxPQUFpQixPQUE2QixRQUFnRDtBQUNsSixRQUFNLEVBQUUsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0FBQ3pDLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLFFBQU0sT0FBTyxJQUFJO0FBQ2pCLFFBQU0sU0FBUyxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQ3JDLFFBQU0sRUFBRSxNQUFNLEtBQUssSUFBSTtBQUN2QixPQUFLLEtBQUssU0FBUztBQUNuQixPQUFLLEtBQUssT0FBTztBQUNqQixRQUFNLFVBQVUsTUFBTTtBQUN0QixRQUFNLFFBQVEsTUFBTSxJQUFJLENBQUMsR0FBRyxVQUFVLEtBQUs7QUFDM0MsTUFBSSxNQUFPLE9BQU0sS0FBSyxDQUFDLEdBQUcsTUFBTSxNQUFNLENBQUMsSUFBSyxNQUFNLENBQUMsS0FBTSxJQUFJLENBQUM7QUFDOUQsUUFBTSxTQUFTLENBQUMsVUFBbUIsUUFBUSxNQUFNLE1BQU0sS0FBSyxDQUFFLElBQUs7QUFDbkUsTUFBSSxTQUFTO0FBQ2IsTUFBSSxVQUFVO0FBQ2QsV0FBUyxPQUFPLE1BQU0sU0FBUyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEdBQUcsVUFBVSxLQUFLLFNBQVMsTUFBTSxRQUFRLFFBQVEsR0FBRztBQUNqRyxRQUFJLFlBQVksRUFBRyxRQUFPLE9BQU8sTUFBTTtBQUN2QyxXQUFPLFNBQVMsTUFBTSxVQUFVLE9BQU8sTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHO0FBQ3BFLFlBQU0sUUFBUSxNQUFNLEtBQUssTUFBTSxNQUFNLE1BQU0sQ0FBRSxHQUFJLEtBQUs7QUFDdEQsVUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLLEtBQUssRUFBSTtBQUN2QyxXQUFLLEtBQUssSUFBSTtBQUNkLGNBQVEsT0FBTyxPQUFPLEVBQUcsS0FBSyxLQUFLO0FBQ25DLGlCQUFXO0FBQUEsSUFDYjtBQUNBLFVBQU0sU0FBUyxRQUFRLE9BQU8sT0FBTztBQUNyQyxXQUFPLE9BQU8sU0FBUyxHQUFHO0FBQ3hCLFlBQU0sUUFBUSxPQUFPLElBQUk7QUFDekIsaUJBQVc7QUFDWCxVQUFJLEtBQUssS0FBSyxNQUFNLEtBQU07QUFDMUIsWUFBTSxNQUFNLFFBQVE7QUFDcEIsWUFBTSxPQUFPLFFBQVEsT0FBTztBQUM1QixZQUFNLEtBQUssU0FBUyxNQUFNLFFBQVE7QUFDbEMsZUFBUyxZQUFZLEdBQUcsWUFBWSxHQUFHLGFBQWEsR0FBRztBQUNyRCxjQUFNLFVBQVUsTUFBTSxVQUFVLFNBQVM7QUFDekMsY0FBTSxVQUFVLE1BQU0sVUFBVSxTQUFTO0FBQ3pDLFlBQUksVUFBVSxLQUFLLFVBQVUsS0FBSyxXQUFXLFdBQVcsV0FBVyxLQUFNO0FBQ3pFLGNBQU0sT0FBTyxLQUFLLFFBQVEsU0FBUztBQUNuQyxZQUFJLEtBQUssSUFBSSxNQUFNLEVBQUc7QUFDdEIsY0FBTSxRQUFRLFVBQVUsVUFBVTtBQUNsQyxjQUFNLFVBQVUsUUFBUSxZQUFZLElBQUksV0FBVyxZQUFZLE9BQU8sSUFBSTtBQUMxRSxZQUFJLFdBQVcsS0FBSyxLQUFLLEtBQU0sQ0FBQyxZQUFZLE9BQU8sSUFBSSxTQUFTLEVBQUc7QUFDbkUsYUFBSyxLQUFLLElBQUk7QUFDZCxnQkFBUSxVQUFVLE9BQU8sRUFBRyxLQUFLLEtBQUs7QUFDdEMsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDM0I7QUFHQSxTQUFTLFNBQVMsT0FBdUIsT0FBaUIsSUFBWTtBQUNwRSxRQUFNLEVBQUUsTUFBTSxTQUFTLE1BQU0sSUFBSTtBQUNqQyxRQUFNLEVBQUUsSUFBSSxJQUFJO0FBQ2hCLFFBQU0sUUFBUSxNQUFNLEtBQUssSUFBSSxLQUFLO0FBQ2xDLE1BQUksUUFBUSxFQUFHLFFBQU87QUFDdEIsUUFBTSxRQUFRLE1BQU0sS0FBSyxLQUFLO0FBQzlCLE1BQUksVUFBVSxRQUFTLFFBQU87QUFDOUIsUUFBTSxNQUFNLFFBQVEsSUFBSTtBQUN4QixRQUFNLE9BQU8sUUFBUSxPQUFPLElBQUk7QUFDaEMsTUFBSSxPQUFPO0FBQ1gsTUFBSSxXQUFXLE1BQU0sS0FBSyxLQUFLO0FBQy9CLFdBQVMsWUFBWSxHQUFHLFlBQVksR0FBRyxhQUFhLEdBQUc7QUFDckQsVUFBTSxVQUFVLE1BQU0sVUFBVSxTQUFTO0FBQ3pDLFVBQU0sVUFBVSxNQUFNLFVBQVUsU0FBUztBQUN6QyxRQUFJLFVBQVUsS0FBSyxVQUFVLEtBQUssV0FBVyxJQUFJLFNBQVMsV0FBVyxJQUFJLE9BQVE7QUFDakYsVUFBTSxPQUFPLEtBQUssUUFBUSxTQUFTO0FBQ25DLFVBQU0sUUFBUSxVQUFVLElBQUksUUFBUTtBQUNwQyxRQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxLQUFLLEtBQUssS0FBTSxZQUFZLENBQUMsWUFBWSxPQUFPLElBQUksU0FBUyxFQUFHO0FBQzlGLGVBQVcsTUFBTSxLQUFLLEtBQUs7QUFDM0IsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLFNBQU87QUFDVDtBQUdBLFNBQVMsWUFBWSxPQUF1QixRQUF3QixPQUFjLFFBQWdCO0FBQ2hHLFFBQU0sUUFBUSxNQUFNLE1BQU0sSUFBSSxNQUFNO0FBQ3BDLE1BQUksT0FBTztBQUNULFVBQU0sTUFBTSxPQUFPLE1BQU07QUFDekIsVUFBTSxNQUFNLElBQUksUUFBUSxLQUFLO0FBQzdCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxTQUFTLFNBQVMsT0FBTyxPQUFPLE1BQU07QUFDNUMsUUFBTSxNQUFPLFNBQVMsTUFBTSxVQUFXO0FBQ3ZDLFFBQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLE9BQU8sSUFBSTtBQUNqRCxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsTUFBTSxNQUFNO0FBQ3JDLFFBQU0sTUFBTSxLQUFLLElBQUksR0FBRyxNQUFNLE1BQU07QUFDcEMsUUFBTSxNQUFNLEVBQUUsTUFBTSxPQUFPLEdBQUcsS0FBSyxNQUFNLEdBQUcsT0FBTyxLQUFLLElBQUksTUFBTSxRQUFRLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sUUFBUSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksSUFBSTtBQUN2SyxRQUFNLEVBQUUsT0FBTyxNQUFNLElBQUksVUFBVSxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQzdELFFBQU0sT0FBTyxFQUFFLE9BQU8sUUFBUSxPQUFPLEtBQUssT0FBTyxLQUFLLEdBQUcsTUFBTTtBQUMvRCxNQUFJLE1BQU0sTUFBTSxRQUFRLGlCQUFrQixPQUFNLE1BQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFNO0FBQzdGLFFBQU0sTUFBTSxJQUFJLFFBQVEsSUFBSTtBQUM1QixTQUFPO0FBQ1Q7QUFVQSxTQUFTLFVBQVUsT0FBdUIsUUFBd0IsUUFBZ0IsS0FBVTtBQUMxRixNQUFJLE1BQU0sS0FBSyxNQUFNLE1BQU0sRUFBRyxRQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFO0FBQ25FLFFBQU0sRUFBRSxPQUFPLFFBQVEsSUFBSTtBQUMzQixRQUFNLFlBQVksU0FBUztBQUMzQixRQUFNLFlBQVksS0FBSyxNQUFNLFNBQVMsS0FBSztBQUMzQyxRQUFNLFNBQVMsRUFBRSxNQUFNLFlBQVksWUFBWSxLQUFLLFlBQVksWUFBWSxPQUFPLElBQUksYUFBYSxHQUFHLFFBQVEsSUFBSSxhQUFhLEVBQUU7QUFDbEksUUFBTSxRQUFrQixDQUFDO0FBQ3pCLFFBQU0sUUFBa0IsQ0FBQztBQUN6QixRQUFNLFNBQVMsb0JBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMvQixXQUFTLFFBQVEsR0FBRyxRQUFRLENBQUMsTUFBTSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQVMsR0FBRztBQUN0RSxVQUFNLEtBQUssTUFBTSxLQUFLO0FBQ3RCLFFBQUksTUFBTSxLQUFLLEVBQUUsTUFBTSxHQUFHO0FBQ3hCLFVBQUksTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLEdBQUc7QUFDOUIsY0FBTSxLQUFLLEVBQUU7QUFDYixjQUFNLEtBQUssS0FBSyxNQUFNLFdBQVcsZ0JBQWdCLEtBQUssTUFBTyxLQUFLLFFBQVMsY0FBYyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDMUk7QUFDQTtBQUFBLElBQ0Y7QUFDQSxhQUFTLFlBQVksR0FBRyxZQUFZLEdBQUcsYUFBYSxHQUFHO0FBQ3JELFlBQU0sT0FBTyxLQUFLLFFBQVEsU0FBUztBQUNuQyxVQUFJLE9BQU8sSUFBSSxJQUFJLEtBQUssT0FBTyxLQUFLLElBQUksTUFBTSxLQUFLLENBQUMsWUFBWSxRQUFRLElBQUksU0FBUyxLQUFLLE1BQU0sUUFBUSxNQUFNLEtBQUssSUFBSSxFQUFHO0FBQzFILGFBQU8sSUFBSSxJQUFJO0FBQ2YsWUFBTSxLQUFLLElBQUk7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLEVBQUUsT0FBTyxNQUFNO0FBQ3hCO0FBS0EsU0FBUyxnQkFBZ0IsT0FBdUIsUUFBd0IsT0FBYyxNQUFjLFFBQWdCO0FBQ2xILFFBQU0sU0FBUyxNQUFNLE9BQU8sSUFBSTtBQUVoQyxNQUFJLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxNQUFNLE9BQVEsUUFBTztBQUN4RSxNQUFJLFlBQVksT0FBTyxRQUFRLE9BQU8sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLFNBQVMsTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNLEVBQUcsUUFBTztBQUMxRyxRQUFNLE1BQU0sU0FBUyxNQUFNLEtBQUssU0FBUztBQUN6QyxRQUFNLFFBQVEsTUFBTSxRQUFRLElBQUksR0FBRztBQUNuQyxNQUFJLFVBQVUsT0FBVyxRQUFPO0FBQ2hDLFFBQU0sRUFBRSxTQUFTLE1BQU0sSUFBSTtBQUMzQixRQUFNLE1BQU8sU0FBUyxRQUFTO0FBQy9CLFFBQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxLQUFLLElBQUk7QUFDekMsTUFBSSxPQUFPO0FBQ1gsTUFBSSxlQUFlO0FBQ25CLFdBQVMsT0FBTyxHQUFHLFFBQVEsS0FBSyxJQUFJLFFBQVEsTUFBTSxRQUFRLElBQUksS0FBSyxPQUFPLFFBQVEsY0FBYyxRQUFRLEdBQUc7QUFDekcsYUFBUyxJQUFJLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLEdBQUc7QUFDaEQsZUFBUyxJQUFJLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLEdBQUc7QUFDaEQsWUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVEsS0FBTTtBQUN6SCxjQUFNLEtBQUssSUFBSSxPQUFPLEdBQUcsQ0FBQztBQUMxQixZQUFJLE1BQU0sT0FBTyxFQUFFLE1BQU0sT0FBUTtBQUNqQyxjQUFNLE9BQU8sSUFBSSxRQUFRLEtBQUssSUFBSSxRQUFRO0FBQzFDLFlBQUksTUFBTSxnQkFBaUIsUUFBUSxnQkFBZ0IsS0FBSyxNQUFPO0FBQzdELHlCQUFlO0FBQ2YsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxNQUFNLFFBQVEsT0FBTyxLQUFPLE9BQU0sUUFBUSxNQUFNO0FBQ3BELFFBQU0sUUFBUSxJQUFJLEtBQUssSUFBSTtBQUMzQixTQUFPO0FBQ1Q7QUFJQSxTQUFTLFFBQVEsT0FBdUIsT0FBYyxRQUFnQixRQUFnQixNQUFzQztBQUMxSCxRQUFNLE1BQU0sU0FBUyxNQUFNLFVBQVUsTUFBTSxPQUFPLGNBQWM7QUFDaEUsTUFBSSxPQUFPLE1BQU0sTUFBTSxJQUFJLEdBQUc7QUFDOUIsTUFBSSxTQUFTLFFBQVc7QUFDdEIsV0FBTyxXQUFXLE9BQU8sT0FBTyxRQUFRLFFBQVEsSUFBSTtBQUNwRCxRQUFJLE1BQU0sTUFBTSxPQUFPLE1BQVEsT0FBTSxNQUFNLE1BQU07QUFDakQsVUFBTSxNQUFNLElBQUksS0FBSyxJQUFJO0FBQUEsRUFDM0I7QUFDQSxTQUFPLE9BQU8sSUFBSSxTQUFZLE1BQU0sTUFBTSxJQUFJLElBQUk7QUFDcEQ7QUFFQSxTQUFTLFdBQVcsT0FBdUIsT0FBYyxRQUFnQixRQUFnQixNQUF3QjtBQUMvRyxRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLFlBQVksU0FBUztBQUMzQixRQUFNLFlBQVksS0FBSyxNQUFNLFNBQVMsS0FBSztBQU0zQyxRQUFNLFdBQVcsQ0FBQyxTQUFtQjtBQUNuQyxRQUFJLFFBQVE7QUFDWixlQUFXLFFBQVEsS0FBSyxPQUFPO0FBQzdCLFlBQU0sS0FBSyxLQUFLLElBQUssT0FBTyxRQUFTLFNBQVM7QUFDOUMsWUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksU0FBUztBQUN4RCxjQUFRLEtBQUssSUFBSSxRQUFRLFdBQVcsS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLFlBQVksS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsTUFBTSxhQUFhO0FBQUEsSUFDMUg7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FBUyxLQUFLLE1BQU0sU0FBUyxXQUFXO0FBQzlDLFFBQU0sT0FBTyxvQkFBSSxJQUFvQjtBQUNyQyxRQUFNLFNBQVMsb0JBQUksSUFBb0I7QUFDdkMsUUFBTSxPQUFPLElBQUksU0FBUztBQUMxQixhQUFXLFFBQVEsWUFBWSxPQUFPLE1BQU0sR0FBRztBQUM3QyxRQUFJLE1BQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFFLE1BQU0sT0FBUTtBQUM3QyxTQUFLLElBQUksS0FBSyxLQUFLLENBQUM7QUFDcEIsV0FBTyxJQUFJLEtBQUssS0FBSyxFQUFFO0FBQ3ZCLFNBQUssS0FBSyxTQUFTLElBQUksR0FBRyxLQUFLLEdBQUc7QUFBQSxFQUNwQztBQUNBLE1BQUksU0FBUztBQUNiLE1BQUksYUFBYTtBQUNqQixRQUFNLFFBQVEsQ0FBQyxNQUFjLElBQVksWUFBb0I7QUFDM0QsVUFBTSxPQUFPLE1BQU0sTUFBTSxJQUFJLEVBQUU7QUFDL0IsUUFBSSxDQUFDLFFBQVEsWUFBWSxLQUFLLElBQUksRUFBRSxLQUFLLFdBQVk7QUFDckQsU0FBSyxJQUFJLElBQUksT0FBTztBQUNwQixXQUFPLElBQUksSUFBSSxJQUFJO0FBQ25CLFNBQUssS0FBSyxVQUFVLFNBQVMsSUFBSSxHQUFHLEVBQUU7QUFBQSxFQUN4QztBQUNBLGFBQVM7QUFDUCxVQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsUUFBSSxRQUFRLEdBQUk7QUFDaEIsVUFBTSxPQUFPLE1BQU0sTUFBTSxJQUFJLEdBQUc7QUFDaEMsVUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHO0FBQ3pCLFFBQUksTUFBTTtBQUNWLGVBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsWUFBTSxRQUFRLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSztBQUN6QyxVQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLENBQUU7QUFBQSxJQUN2RDtBQUNBLFFBQUksTUFBTSxhQUFhLE9BQU8sTUFBTSxZQUFZO0FBQzlDLG1CQUFhLE9BQU87QUFDcEIsZUFBUztBQUNULFdBQUssS0FBSyxZQUFZLEVBQUU7QUFBQSxJQUMxQjtBQUNBLFVBQU0sT0FBTyxNQUFNLE1BQU0sSUFBSSxNQUFNLENBQUM7QUFDcEMsUUFBSSxLQUFNLE9BQU0sS0FBSyxNQUFNLEdBQUcsT0FBTyxXQUFXLGFBQWE7QUFDN0QsZUFBVyxRQUFRLEtBQUssTUFBTyxPQUFNLEtBQUssS0FBSyxJQUFJLE9BQU8sS0FBSyxJQUFJO0FBQUEsRUFDckU7QUFFQSxRQUFNLE9BQWlCLENBQUM7QUFDeEIsV0FBUyxLQUFLLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsRUFBSSxNQUFLLEtBQUssRUFBRTtBQUNuRSxPQUFLLFFBQVE7QUFDYixXQUFTLFFBQVEsR0FBRyxRQUFRLElBQUksS0FBSyxRQUFRLFNBQVMsRUFBRyxLQUFJLEtBQUssUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFLLElBQUssR0FBSSxRQUFPLEtBQUssS0FBSztBQUN0SCxTQUFPLEtBQUssS0FBSyxTQUFTLENBQUM7QUFDN0I7QUFHQSxNQUFNLFNBQVM7QUFBQSxFQUNMLFFBQTRCLENBQUM7QUFBQSxFQUNyQyxLQUFLLFVBQWtCLEtBQWE7QUFDbEMsVUFBTSxRQUFRLEtBQUs7QUFDbkIsVUFBTSxLQUFLLENBQUMsVUFBVSxHQUFHLENBQUM7QUFDMUIsYUFBUyxLQUFLLE1BQU0sU0FBUyxHQUFHLEtBQUssS0FBSztBQUN4QyxZQUFNLEtBQU0sS0FBSyxLQUFNO0FBQ3ZCLFVBQUksQ0FBQyxPQUFPLE1BQU0sRUFBRSxHQUFJLE1BQU0sRUFBRSxDQUFFLEVBQUc7QUFDckMsT0FBQyxNQUFNLEVBQUUsR0FBRyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUksTUFBTSxFQUFFLENBQUU7QUFDaEQsV0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUEwQjtBQUN4QixVQUFNLFFBQVEsS0FBSztBQUNuQixRQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsVUFBTSxNQUFNLE1BQU0sQ0FBQyxFQUFHLENBQUM7QUFDdkIsVUFBTSxPQUFPLE1BQU0sSUFBSTtBQUN2QixRQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3BCLFlBQU0sQ0FBQyxJQUFJO0FBQ1gsZUFBUyxLQUFLLE9BQU87QUFDbkIsY0FBTSxPQUFPLElBQUksS0FBSztBQUN0QixjQUFNLFFBQVEsT0FBTztBQUNyQixZQUFJLFFBQVE7QUFDWixZQUFJLE9BQU8sTUFBTSxVQUFVLE9BQU8sTUFBTSxJQUFJLEdBQUksTUFBTSxLQUFLLENBQUUsRUFBRyxTQUFRO0FBQ3hFLFlBQUksUUFBUSxNQUFNLFVBQVUsT0FBTyxNQUFNLEtBQUssR0FBSSxNQUFNLEtBQUssQ0FBRSxFQUFHLFNBQVE7QUFDMUUsWUFBSSxVQUFVLEdBQUk7QUFDbEIsU0FBQyxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLEdBQUksTUFBTSxFQUFFLENBQUU7QUFDdEQsYUFBSztBQUFBLE1BQ1A7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsT0FBTyxHQUFxQixHQUFxQjtBQUN4RCxTQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUNwRDtBQUlPLGdCQUFTLGdCQUFnQixLQUErQixNQUFhLE1BQWEsUUFBZSxRQUE0QjtBQUNsSSxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUMsUUFBUyxRQUFPLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssTUFBTSxDQUFDO0FBQzlFLFFBQU0sUUFBUSxRQUFRLFNBQVMsS0FBSztBQUNwQyxRQUFNLFFBQVEsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekMsUUFBTSxTQUFTLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQzFDLE1BQUksTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLE1BQU0sRUFBRyxRQUFPO0FBQ2hFLFFBQU0sT0FBTyxXQUFXLE9BQU8sTUFBTSxFQUFFLEtBQUssS0FBSztBQUNqRCxTQUFPLFFBQVEsWUFBWSxTQUFhLE9BQU8sUUFBUSxPQUFRO0FBQ2pFO0FBS08sZ0JBQVMsd0JBQXdCLEtBQStCLE1BQWEsTUFBcUI7QUFDdkcsU0FBTyxzQkFBc0IsS0FBSyxNQUFNLE1BQU0sUUFBUSxFQUFFO0FBQzFEO0FBR08sZ0JBQVMscUJBQXFCLEtBQStCLE1BQWEsTUFBYSxRQUF1QjtBQUNuSCxRQUFNLEVBQUUsU0FBUyxJQUFJLHNCQUFzQixLQUFLLE1BQU0sTUFBTSxNQUFNO0FBQ2xFLFNBQU8sYUFBYSxJQUFJLE9BQU8sRUFBRSxHQUFHLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLFVBQVUsR0FBRyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxTQUFTO0FBQ3RIO0FBRUEsU0FBUyxzQkFBc0IsS0FBK0IsTUFBYSxNQUFhLFFBQWdCO0FBQ3RHLFFBQU0sS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxTQUFTLEtBQUssTUFBTSxJQUFJLEVBQUUsR0FBRyxVQUFVLElBQUk7QUFDN0YsTUFBSSxDQUFDLFdBQVcsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNLEtBQUssSUFBSSxRQUFRLE1BQU0sR0FBRyxVQUFVLFdBQVcsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVMsTUFBTSxFQUFFO0FBQ2pJLFFBQU0sT0FBTyxRQUFRLE1BQU0sUUFBUSxLQUFLLEtBQUssRUFBRSxHQUFHLFFBQVEsS0FBSyxLQUFLLEVBQUU7QUFDdEUsTUFBSSxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJO0FBQ25FLE1BQUksS0FBSyxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQU07QUFDckMsTUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBTTtBQUNyQyxNQUFJLFFBQVEsT0FBTyxJQUFJLGFBQWEsTUFBTSxPQUFPLEtBQUssQ0FBQyxLQUFLLE9BQU8sS0FBSyxLQUFLO0FBQzdFLE1BQUksUUFBUSxPQUFPLElBQUksYUFBYSxNQUFNLE9BQU8sS0FBSyxDQUFDLEtBQUssT0FBTyxLQUFLLEtBQUs7QUFDN0UsUUFBTSxRQUFRLE9BQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxRQUFRLE9BQU8sS0FBSyxJQUFJLEVBQUU7QUFDN0QsTUFBSSxLQUFLLEdBQUcsT0FBTztBQUNuQixTQUFPLEtBQUssR0FBRztBQUNiLFVBQU0sTUFBTSxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUs7QUFDcEMsVUFBTSxPQUFPLFlBQVksUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPLEdBQUcsQ0FBRSxFQUFHO0FBQ3BFLFVBQU0sT0FBTyxRQUFRLE1BQU0sTUFBTSxTQUFTO0FBQzFDLFFBQUksUUFBUSxPQUFRLFFBQU8sRUFBRSxNQUFNLFFBQVEsVUFBVSxNQUFNLFNBQVMsUUFBUSxPQUFPLE9BQU87QUFDMUYsV0FBTztBQUNQLFFBQUksUUFBUSxPQUFPO0FBQUUsYUFBTztBQUFPLGVBQVM7QUFBQSxJQUFPO0FBQ25ELFFBQUksUUFBUSxPQUFPO0FBQUUsYUFBTztBQUFPLGVBQVM7QUFBQSxJQUFPO0FBQ25ELFNBQUs7QUFBQSxFQUNQO0FBQ0EsU0FBTyxFQUFFLE1BQU0sVUFBVSxFQUFFO0FBQzdCO0FBS08sZ0JBQVMsaUJBQWlCLEtBQStCLE1BQWEsTUFBaUM7QUFDNUcsUUFBTSxVQUFVLElBQUk7QUFDcEIsTUFBSSxDQUFDLFFBQVMsUUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDO0FBQ2hFLFFBQU0sUUFBUSxRQUFRLFNBQVMsTUFBTSxHQUFHLFFBQVEsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUMsR0FBRyxTQUFTLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ2xILE1BQUksTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLE1BQU0sRUFBRyxRQUFPO0FBQ2hFLE1BQUksYUFBYSxPQUFPLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFHLFFBQU8sd0JBQXdCLEtBQUssTUFBTSxJQUFJO0FBQ3ZHLFFBQU0sUUFBUSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEdBQUcsTUFBTTtBQUM3QyxVQUFNLFNBQVMsTUFBTSxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sSUFBSSxXQUFXLE1BQU0sS0FBSyxNQUFNLEdBQUcsTUFBTSxJQUFJLFdBQVcsTUFBTSxLQUFLLE1BQU0sR0FBRyxNQUFNLEVBQUU7QUFDaEksVUFBTSxNQUFNLEVBQUUsTUFBTSxHQUFHLEtBQUssR0FBRyxPQUFPLE1BQU0sT0FBTyxRQUFRLE1BQU0sS0FBSyxTQUFTLE1BQU0sTUFBTTtBQUMzRixnQkFBWSxPQUFPLEtBQUssQ0FBQyxNQUFNLEdBQUcsUUFBVyxNQUFNO0FBQ25ELFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxRQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7QUFDN0IsU0FBTyxRQUFRLFlBQVksU0FBWSxPQUFPLFFBQVEsUUFBUSxXQUFXO0FBQzNFO0FBTU8sZ0JBQVMsV0FBVyxLQUErQixHQUFVLEdBQVUsUUFBZSxRQUFRO0FBQ25HLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLE1BQUksQ0FBQyxRQUFTLFFBQU87QUFDckIsUUFBTSxRQUFRLFFBQVEsU0FBUyxLQUFLO0FBQ3BDLFFBQU0sRUFBRSxPQUFPLElBQUksU0FBUyxLQUFLO0FBQ2pDLFFBQU0sT0FBTyxNQUFNLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQztBQUNsQyxRQUFNLEtBQUssTUFBTSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDaEMsU0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU0sT0FBTyxFQUFFO0FBQ2pGO0FBRU8sZ0JBQVMsYUFBYSxLQUErQixRQUFlLFFBQVE7QUFDakYsU0FBTyxJQUFJLFVBQVUsU0FBUyxRQUFRLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRSxRQUFRO0FBQ3JFO0FBRUEsU0FBUyxTQUFTLE9BQXVCO0FBQ3ZDLE1BQUksTUFBTSxPQUFRLFFBQU8sTUFBTTtBQUMvQixRQUFNLEVBQUUsTUFBTSxTQUFTLFNBQVMsTUFBTSxJQUFJO0FBQzFDLFFBQU0sU0FBUyxJQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3pDLFFBQU0sUUFBUSxJQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3hDLE1BQUksUUFBUTtBQUNaLFdBQVMsT0FBTyxHQUFHLE9BQU8sS0FBSyxRQUFRLFFBQVEsR0FBRztBQUNoRCxRQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU0sRUFBRztBQUM1QyxhQUFTO0FBQ1QsV0FBTyxJQUFJLElBQUk7QUFDZixRQUFJLE9BQU87QUFDWCxVQUFNLE1BQU0sSUFBSTtBQUNoQixhQUFTLE9BQU8sR0FBRyxPQUFPLE1BQU0sUUFBUSxHQUFHO0FBQ3pDLFlBQU0sS0FBSyxNQUFNLElBQUk7QUFDckIsZUFBUyxZQUFZLEdBQUcsWUFBWSxHQUFHLGFBQWEsR0FBRztBQUNyRCxjQUFNLE9BQU8sS0FBSyxRQUFRLFNBQVM7QUFDbkMsWUFBSSxLQUFLLElBQUksTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFNLEtBQUssQ0FBQyxZQUFZLE9BQU8sSUFBSSxTQUFTLEVBQUc7QUFDbEYsZUFBTyxJQUFJLElBQUk7QUFDZixjQUFNLE1BQU0sSUFBSTtBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE9BQU8sSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNyQyxXQUFTLFFBQVEsR0FBRyxRQUFRLFFBQVEsT0FBTyxRQUFRLE1BQU0sU0FBUyxHQUFHO0FBQ25FLFFBQUksUUFBUSxNQUFNLEtBQUssTUFBTSxJQUFLO0FBQ2xDLFVBQU0sTUFBTSxRQUFRLFFBQVE7QUFDNUIsU0FBSyxTQUFTLFFBQVEsT0FBTyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU0sQ0FBQyxDQUFFLEtBQU07QUFBQSxFQUMxRTtBQUNBLE9BQUssQ0FBQyxJQUFJO0FBQ1YsUUFBTSxTQUFTLEVBQUUsUUFBUSxPQUFPLEtBQUs7QUFDckMsU0FBTyxNQUFNO0FBQ2Y7QUFLTyxnQkFBUyxVQUFVLEtBQStCLE1BQWEsTUFBYSxRQUFRLEdBQXdCO0FBQ2pILFFBQU0sVUFBVSxJQUFJO0FBQ3BCLE1BQUksQ0FBQyxRQUFTLFFBQU8sQ0FBQyxJQUFJO0FBQzFCLFFBQU0sUUFBUSxRQUFRLFNBQVMsTUFBTTtBQUNyQyxRQUFNLFFBQVEsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDekMsUUFBTSxTQUFTLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQzFDLE1BQUksTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLE1BQU0sRUFBRyxRQUFPO0FBQ2hFLFFBQU0sUUFBUSxXQUFXLE9BQU8sTUFBTTtBQUN0QyxNQUFJLE1BQU0sS0FBSyxLQUFLLEtBQU0sVUFBVyxRQUFPO0FBQzVDLFFBQU0sUUFBaUIsQ0FBQztBQUN4QixNQUFJLEtBQUs7QUFDVCxXQUFTLE9BQU8sR0FBRyxPQUFPLFVBQVUsT0FBTyxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQUc7QUFDdkUsU0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBQzlCLFFBQUksS0FBSyxFQUFHLFFBQU87QUFDbkIsUUFBSSxPQUFPLFVBQVUsRUFBRyxPQUFNLEtBQUssU0FBUyxPQUFPLEVBQUUsQ0FBQztBQUFBLEVBQ3hEO0FBQ0EsUUFBTSxLQUFLLElBQUk7QUFDZixTQUFPO0FBQ1Q7QUFvQkEsTUFBTSxXQUFXLG9CQUFJLFFBQXlCO0FBQzlDLElBQUkscUJBQW1CO0FBRWhCLGdCQUFTLGVBQWUsS0FBVztBQUFDLFNBQU8sU0FBUyxJQUFJLEdBQUcsR0FBRyxZQUFZO0FBQUU7QUFHNUUsZ0JBQVMsb0JBQW9CLFFBQWdCLFFBQWdCO0FBQ2xFLFFBQU0sVUFBVSxTQUFTLElBQUksTUFBTTtBQUNuQyxNQUFJLFNBQVM7QUFDWCxZQUFRLFNBQVM7QUFDakIsYUFBUyxJQUFJLFFBQVEsT0FBTztBQUFBLEVBQzlCO0FBQ0Y7QUFFTyxnQkFBUyxrQkFBa0IsS0FBK0IsUUFBeUI7QUFDeEYsUUFBTSxVQUFVLElBQUk7QUFDcEIsTUFBSSxDQUFDLFFBQVM7QUFDZCxNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLGFBQVMsT0FBTyxHQUFHO0FBQ25CO0FBQUEsRUFDRjtBQUNBLFFBQU0sVUFBVSxTQUFTLElBQUksR0FBRztBQUNoQyxNQUFJLFNBQVMsWUFBWSxXQUFXLFFBQVEsT0FBTyxXQUFXLE9BQU8sVUFDaEUsT0FBTyxNQUFNLENBQUMsTUFBTSxVQUFVLEtBQUssTUFBTSxRQUFRLE9BQU8sS0FBSyxFQUFHLEtBQzlELEtBQUssTUFBTSxRQUFRLE9BQU8sS0FBSyxFQUFHLEtBQUssS0FBSyxXQUFXLFFBQVEsT0FBTyxLQUFLLEVBQUcsTUFBTSxFQUFHO0FBQzlGLFFBQU0sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUN0QyxNQUFJLFVBQVU7QUFDZCxNQUFJLENBQUMsV0FBVyxRQUFRLFlBQVksV0FBVyxRQUFRLFFBQVE7QUFDN0QsVUFBTSxRQUFRLGNBQWMsU0FBUyxNQUFNO0FBQzNDLGNBQVUsRUFBRSxTQUFTLE9BQU8sT0FBTyxVQUFVLElBQUksV0FBVyxNQUFNLEtBQUssTUFBTSxHQUFHLFVBQVMsc0JBQXNCLFFBQVEsQ0FBQyxHQUFHLFFBQVEsTUFBTTtBQUN6SSxhQUFTLElBQUksS0FBSyxPQUFPO0FBQUEsRUFDM0I7QUFDQSxVQUFRLFNBQVMsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLEdBQUcsT0FBTyxPQUFPLEVBQUUsR0FBRyxHQUFHLE9BQU8sRUFBRTtBQUNwRSxRQUFNLFFBQVEsUUFBUTtBQUN0QixVQUFRLFNBQVMsSUFBSSxNQUFNLElBQUk7QUFDL0IsUUFBTSxLQUFLLElBQUksT0FBTyxJQUFJO0FBQzFCLFFBQU0sT0FBTyxRQUFRO0FBQ3JCLGFBQVcsUUFBUSxRQUFRO0FBQ3pCLFVBQU0sRUFBRSxNQUFNLE9BQU8sS0FBSyxPQUFPLElBQUksZUFBZSxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxNQUFNO0FBQ3JGLGFBQVMsTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsT0FBTyxLQUFLLElBQUksUUFBUSxPQUFPLEdBQUcsTUFBTSxHQUFHLE9BQU8sR0FBRztBQUNwRixlQUFTLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLE9BQU8sS0FBSyxJQUFJLFFBQVEsT0FBTyxHQUFHLEtBQUssR0FBRyxPQUFPLEVBQUcsT0FBTSxLQUFLLElBQUksT0FBTyxLQUFLLEdBQUcsQ0FBQyxJQUFJO0FBQUEsSUFDM0g7QUFBQSxFQUNGO0FBQ0EsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsV0FBUyxLQUFLLEdBQUcsS0FBSyxNQUFNLEtBQUssUUFBUSxNQUFNLEdBQUc7QUFDaEQsUUFBSSxNQUFNLEtBQUssRUFBRSxNQUFNLFFBQVEsU0FBUyxFQUFFLEVBQUc7QUFDN0MsVUFBTSxNQUFPLEtBQUssTUFBTSxRQUFTO0FBQ2pDLFVBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSTtBQUMzQyxVQUFNLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxJQUFJLEtBQUssS0FBSyxRQUFRLE9BQU8sTUFBTSxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sQ0FBQztBQUFBLEVBQ2xHO0FBQ0EsTUFBSSxNQUFNLFNBQVMsRUFBRztBQUN0QixVQUFRLFdBQVM7QUFHakIsTUFBSSxNQUFNLFdBQVc7QUFBRSxVQUFNLFVBQVUsS0FBSyxDQUFDO0FBQUcsa0JBQWMsS0FBSztBQUFBLEVBQUc7QUFDdEUsUUFBTSxRQUFRLE1BQU07QUFDcEIsTUFBSSxNQUFNLE1BQU8sV0FBVSxPQUFPLE1BQU0sT0FBTyxLQUFLO0FBQ3REO0FBR0EsU0FBUyxRQUFRLEtBQWEsU0FBa0IsT0FBOEI7QUFDNUUsTUFBSSxVQUFVLFFBQVE7QUFDcEIsVUFBTSxVQUFVLFNBQVMsSUFBSSxHQUFHO0FBQ2hDLFFBQUksV0FBVyxRQUFRLFlBQVksUUFBUyxRQUFPLFFBQVE7QUFBQSxFQUM3RDtBQUNBLFNBQU8sUUFBUSxTQUFTLEtBQUs7QUFDL0I7QUFxQ0EsTUFBTSxXQUFXLG9CQUFJLFFBQTJCO0FBQ2hELElBQUk7QUFDSixJQUFJLGVBQXlCLENBQUM7QUFFOUIsU0FBUyxRQUFRLFNBQWtCLE9BQThCO0FBQy9ELE1BQUksWUFBWSxhQUFhO0FBQzNCLGtCQUFjO0FBQ2QsbUJBQWUsU0FBUyxJQUFJLE9BQU8sS0FBSyxDQUFDO0FBQ3pDLGFBQVMsSUFBSSxTQUFTLFlBQVk7QUFBQSxFQUNwQztBQUNBLFNBQU8sVUFBVSxTQUFVLGFBQWEsU0FBUyxjQUFjLFNBQVMsTUFBTSxJQUFNLGFBQWEsUUFBUSxjQUFjLFNBQVMsS0FBSztBQUN2STtBQUVBLFNBQVMsY0FBYyxTQUFrQixPQUE4QjtBQUNyRSxRQUFNLFFBQVEsUUFBUSxPQUFPO0FBQzdCLFFBQU0sUUFBUSxTQUFTLFFBQVEsT0FBTztBQUN0QyxRQUFNLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFDakMsUUFBTSxTQUFTLElBQUksV0FBVyxLQUFLO0FBQ25DLFFBQU0sV0FBVyxTQUFTLEtBQUs7QUFDL0IsV0FBUyxNQUFNLEdBQUcsTUFBTSxRQUFRLE1BQU0sT0FBTyxHQUFHO0FBQzlDLGFBQVMsTUFBTSxHQUFHLE1BQU0sUUFBUSxNQUFNLE9BQU8sR0FBRztBQUM5QyxZQUFNLE9BQU8sUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPLEdBQUc7QUFDbkQsVUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUc7QUFDekIsWUFBTSxNQUFNLE1BQU0sS0FBSyxRQUFRLE1BQU07QUFDckMsV0FBSyxFQUFFLElBQUk7QUFDWCxhQUFPLEVBQUUsSUFBSSxVQUFVLFFBQVEsZ0JBQWdCLEtBQUssTUFBTSxpQkFBaUIsWUFBWSxJQUFJLEdBQUcsUUFBUSxFQUFFO0FBQUEsSUFDMUc7QUFBQSxFQUNGO0FBQ0EsUUFBTSxVQUFVLFdBQVcsS0FBSyxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxRQUFRLEdBQUcsUUFBUSxHQUFHLENBQUMsUUFBUSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDcEcsUUFBTSxRQUF3QjtBQUFBLElBQzVCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxRQUFRLG9CQUFJLElBQUk7QUFBQSxJQUNoQixPQUFPO0FBQUEsSUFDUCxPQUFPLENBQUM7QUFBQSxJQUNSLFNBQVMsb0JBQUksSUFBSTtBQUFBLElBQ2pCLE1BQU0sSUFBSSxXQUFXLENBQUM7QUFBQSxJQUN0QixZQUFZLE1BQU0sS0FBSyxFQUFFLFFBQVEsUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxJQUFJLE9BQXVCLEtBQWEsS0FBYTtBQUM1RCxVQUFRLE1BQU0sS0FBSyxNQUFNLFFBQVEsTUFBTTtBQUN6QztBQUdBLFNBQVMsTUFBTSxPQUF1QixHQUFXLEdBQVc7QUFDMUQsUUFBTSxFQUFFLFFBQVEsSUFBSTtBQUNwQixRQUFNLE1BQU0sS0FBSyxNQUFNLElBQUksUUFBUSxJQUFJO0FBQ3ZDLFFBQU0sTUFBTSxLQUFLLE1BQU0sSUFBSSxRQUFRLElBQUk7QUFDdkMsTUFBSSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU8sUUFBUSxRQUFRLE9BQU8sUUFBUSxLQUFNLFFBQU87QUFDN0UsVUFBUSxNQUFNLEtBQUssTUFBTSxRQUFRLE1BQU07QUFDekM7QUFFQSxTQUFTLFNBQVMsT0FBdUIsSUFBbUI7QUFDMUQsUUFBTSxNQUFPLEtBQUssTUFBTSxRQUFTO0FBQ2pDLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSTtBQUMzQyxTQUFPLEVBQUUsSUFBSSxNQUFNLE9BQU8sTUFBTSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUs7QUFDcEY7QUFHQSxTQUFTLFlBQVksT0FBdUIsSUFBWSxXQUFtQjtBQUN6RSxNQUFJLFlBQVksRUFBRyxRQUFPO0FBQzFCLFFBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSTtBQUN4QixRQUFNLEtBQUssY0FBYyxLQUFLLGNBQWMsSUFBSSxJQUFJO0FBQ3BELFFBQU0sS0FBSyxjQUFjLEtBQUssY0FBYyxJQUFJLFFBQVEsQ0FBQztBQUN6RCxTQUFPLEtBQUssS0FBSyxFQUFFLE1BQU0sS0FBSyxLQUFLLEtBQUssRUFBRSxNQUFNO0FBQ2xEO0FBRUEsU0FBUyxjQUFjLE9BQXVCO0FBQzVDLFFBQU0sRUFBRSxNQUFNLFFBQVEsSUFBSTtBQUMxQixRQUFNLFlBQVksTUFBTSxjQUFjLElBQUksWUFBWSxLQUFLLE1BQU07QUFDakUsUUFBTSxRQUFRLElBQUksV0FBVyxLQUFLLE1BQU07QUFDeEMsTUFBSSxPQUFPO0FBRVgsV0FBUyxLQUFLLEdBQUcsS0FBSyxLQUFLLFFBQVEsTUFBTSxHQUFHO0FBQzFDLFFBQUksS0FBSyxFQUFFLE1BQU0sRUFBRztBQUNwQixhQUFTLFlBQVksR0FBRyxZQUFZLEdBQUcsYUFBYSxHQUFHO0FBQ3JELFVBQUksS0FBSyxLQUFLLFFBQVEsU0FBUyxDQUFFLE1BQU0sRUFBRztBQUMxQyxnQkFBVSxFQUFFLElBQUk7QUFDaEIsWUFBTSxNQUFNLElBQUk7QUFDaEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFdBQVMsT0FBTyxHQUFHLE9BQU8sTUFBTSxRQUFRLEdBQUc7QUFDekMsVUFBTSxLQUFLLE1BQU0sSUFBSTtBQUNyQixVQUFNLFFBQVEsVUFBVSxFQUFFLElBQUs7QUFDL0IsYUFBUyxZQUFZLEdBQUcsWUFBWSxHQUFHLGFBQWEsR0FBRztBQUNyRCxZQUFNLE9BQU8sS0FBSyxRQUFRLFNBQVM7QUFDbkMsVUFBSSxLQUFLLElBQUksTUFBTSxLQUFLLFVBQVUsSUFBSSxNQUFNLEVBQUc7QUFDL0MsZ0JBQVUsSUFBSSxJQUFJO0FBQ2xCLFlBQU0sTUFBTSxJQUFJO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBQ0Y7QUFLQSxTQUFTLGFBQWEsT0FBdUIsSUFBWSxJQUFZLElBQVksSUFBWTtBQUMzRixRQUFNLEVBQUUsU0FBUyxNQUFNLE1BQU0sSUFBSTtBQUNqQyxRQUFNLE9BQU8sUUFBUTtBQUNyQixNQUFJLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtBQUM1QixRQUFNLE1BQU0sTUFBTSxPQUFPLElBQUksRUFBRTtBQUMvQixNQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxFQUFFLE1BQU0sS0FBSyxLQUFLLEdBQUcsTUFBTSxFQUFHLFFBQU87QUFDbkUsTUFBSSxPQUFPLElBQUssUUFBTztBQUN2QixNQUFJLENBQUMsTUFBTSxVQUFXLGVBQWMsS0FBSztBQUN6QyxRQUFNLFlBQVksTUFBTTtBQUN4QixRQUFNLEtBQUssS0FBSztBQUNoQixRQUFNLEtBQUssS0FBSztBQUNoQixRQUFNLFNBQVMsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7QUFDMUMsUUFBTSxLQUFLLEtBQUs7QUFDaEIsUUFBTSxLQUFLLEtBQUs7QUFDaEIsTUFBSSxJQUFJO0FBQ1IsV0FBUyxRQUFRLEdBQUcsUUFBUSxLQUFLLFFBQVEsT0FBTyxRQUFRLFFBQVEsR0FBRyxTQUFTLEdBQUc7QUFDN0UsVUFBTSxNQUFPLEtBQUssUUFBUztBQUMzQixVQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3JDLFVBQU0sUUFBUSxVQUFVLEVBQUUsSUFBSztBQUUvQixVQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFVBQU0sU0FBUyxNQUFNLFFBQVEsS0FBSztBQUNsQyxVQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLFVBQU0sVUFBVSxNQUFNLFFBQVEsS0FBSztBQUNuQyxVQUFNLEtBQUssS0FBSyxLQUFLO0FBQ3JCLFVBQU0sS0FBSyxLQUFLLEtBQUs7QUFDckIsVUFBTSxRQUFRLEtBQUssS0FBSyxRQUFRLE1BQU0sS0FBSyxLQUFLLEtBQUssT0FBTyxNQUFNLEtBQUs7QUFDdkUsVUFBTSxRQUFRLEtBQUssS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUs7QUFDdkUsVUFBTSxPQUFPLEtBQUssSUFBSSxPQUFPLEtBQUs7QUFDbEMsUUFBSSxJQUFJLFFBQVEsT0FBUSxRQUFPO0FBQy9CLFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFNBQUs7QUFFTCxRQUFJLFVBQVUsS0FBSyxPQUFPLEtBQUssS0FBSyxLQUFLLElBQUk7QUFDN0MsUUFBSSxVQUFVLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJO0FBQzdDLFFBQUksT0FBUSxXQUFVLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEtBQUssSUFBSSxTQUFTLE1BQU0sUUFBUSxDQUFDO0FBQ3JHLFFBQUksT0FBUSxXQUFVLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEtBQUssSUFBSSxTQUFTLE1BQU0sUUFBUSxDQUFDO0FBQ3JHLFFBQUksVUFBVSxLQUFLLFVBQVUsS0FBSyxXQUFXLFFBQVEsUUFBUSxXQUFXLFFBQVEsS0FBTSxRQUFPO0FBRTdGLFFBQUksVUFBVSxXQUFXLEtBQUssSUFBSSxPQUFPLEtBQUssSUFBSSxNQUFNLFFBQVEsTUFBTSxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssS0FBSyxJQUFJLE9BQU8sU0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxDQUFDLE1BQU0sR0FBSSxRQUFPO0FBQzdLLFNBQUssSUFBSSxPQUFPLFNBQVMsT0FBTztBQUNoQyxRQUFJLEtBQUssRUFBRSxNQUFNLEVBQUcsUUFBTztBQUMzQixRQUFJLE9BQU8sSUFBSyxRQUFPO0FBQUEsRUFDekI7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxTQUFTLFNBQVMsT0FBdUIsT0FBYyxJQUFZO0FBQ2pFLFFBQU0sUUFBUSxNQUFNLEtBQUssRUFBRTtBQUMzQixNQUFJLFVBQVUsUUFBUyxRQUFPO0FBQzlCLFFBQU0sRUFBRSxNQUFNLFFBQVEsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTTtBQUNuQixNQUFJLE9BQU87QUFDWCxNQUFJLFdBQVcsS0FBSyxFQUFFO0FBQ3RCLFdBQVMsWUFBWSxHQUFHLFlBQVksR0FBRyxhQUFhLEdBQUc7QUFDckQsVUFBTSxPQUFPLEtBQUssUUFBUSxTQUFTO0FBQ25DLFFBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBTSxZQUFZLENBQUMsWUFBWSxPQUFPLElBQUksU0FBUyxFQUFHO0FBQ3ZGLGVBQVcsS0FBSyxJQUFJO0FBQ3BCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxLQUFLLEVBQUUsSUFBSTtBQUNqQixTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsT0FBdUIsUUFBdUI7QUFDaEUsU0FBTyxPQUFPLE9BQU8sUUFBUSxNQUFNLEtBQUssT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzFEO0FBRUEsU0FBUyxPQUFPLE9BQXVCLEtBQWEsT0FBMkI7QUFDN0UsUUFBTSxTQUFTO0FBQ2YsUUFBTSxRQUFRLE1BQU0sT0FBTyxJQUFJLEdBQUc7QUFDbEMsTUFBSSxPQUFPO0FBQ1QsVUFBTSxPQUFPLE1BQU07QUFDbkIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxNQUFJLE1BQU0sT0FBTyxRQUFRLGFBQWE7QUFDcEMsUUFBSTtBQUNKLFFBQUksWUFBWTtBQUNoQixlQUFXLENBQUMsV0FBV0MsTUFBSyxLQUFLLE1BQU0sUUFBUTtBQUM3QyxVQUFJQSxPQUFNLE9BQU8sV0FBVztBQUMxQixvQkFBWUEsT0FBTTtBQUNsQixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsVUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUksTUFBTyxDQUFFO0FBQzNDLFVBQU0sT0FBTyxPQUFPLE1BQU87QUFBQSxFQUM3QjtBQUNBLFFBQU0sUUFBUSxNQUFNO0FBQ3BCLFFBQU0sT0FBTyxNQUFNO0FBQ25CLFFBQU0sT0FBTyxJQUFJLEtBQUssS0FBSztBQUMzQixTQUFPO0FBQ1Q7QUFJQSxTQUFTLEtBQUssT0FBdUIsU0FBMEI7QUFDN0QsUUFBTSxFQUFFLE1BQU0sU0FBUyxLQUFLLElBQUk7QUFDaEMsUUFBTSxVQUFVLE1BQU0sWUFBWSxNQUFNLEtBQUssRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUksV0FBVyxLQUFLLE1BQU0sQ0FBQztBQUM3RixRQUFNLFFBQVEsTUFBTSxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sSUFBSSxXQUFXLEtBQUssTUFBTSxHQUFHLE1BQU0sSUFBSSxXQUFXLEtBQUssTUFBTSxHQUFHLE1BQU0sRUFBRTtBQUNuSCxRQUFNLE9BQU8sTUFBTTtBQUNuQixPQUFLLEtBQUssU0FBUztBQUNuQixRQUFNLEtBQUssS0FBSyxPQUFPO0FBQ3ZCLE9BQUssS0FBSyxDQUFDO0FBQ1gsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLFNBQVM7QUFDNUIsU0FBSyxNQUFNLElBQUk7QUFDZixZQUFRLENBQUMsRUFBRyxLQUFLLENBQUMsR0FBSSxJQUFJO0FBQzFCLGVBQVc7QUFBQSxFQUNiO0FBQ0EsV0FBUyxPQUFPLEdBQUcsVUFBVSxHQUFHLFFBQVEsR0FBRztBQUN6QyxVQUFNLE9BQU8sT0FBTztBQUNwQixVQUFNLFNBQVMsUUFBUSxJQUFJO0FBQzNCLFdBQU8sS0FBSyxJQUFJLElBQUssR0FBRztBQUN0QixZQUFNLEtBQUssT0FBTyxFQUFFLEtBQUssSUFBSSxDQUFFO0FBQy9CLGlCQUFXO0FBQ1gsVUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFNO0FBQ3ZCLGVBQVMsWUFBWSxHQUFHLFlBQVksR0FBRyxhQUFhLEdBQUc7QUFDckQsY0FBTSxPQUFPLEtBQUssUUFBUSxTQUFTO0FBQ25DLFlBQUksS0FBSyxJQUFJLE1BQU0sRUFBRztBQUN0QixjQUFNLFVBQVUsUUFBUSxZQUFZLElBQUksV0FBVztBQUNuRCxZQUFJLFdBQVcsS0FBSyxJQUFJLEtBQU0sQ0FBQyxZQUFZLE9BQU8sSUFBSSxTQUFTLEVBQUc7QUFDbEUsYUFBSyxJQUFJLElBQUk7QUFDYixjQUFNLE9BQU8sVUFBVTtBQUN2QixnQkFBUSxJQUFJLEVBQUcsS0FBSyxJQUFJLEdBQUksSUFBSTtBQUNoQyxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsZ0JBQWdCLE9BQXVCLElBQW9CO0FBQ2xFLE1BQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLE1BQU0sRUFBRyxRQUFPO0FBQzVDLFFBQU0sUUFBUSxNQUFNLFFBQVEsSUFBSSxFQUFFO0FBQ2xDLE1BQUksVUFBVSxPQUFXLFFBQU87QUFDaEMsUUFBTSxFQUFFLFNBQVMsTUFBTSxJQUFJO0FBQzNCLFFBQU0sTUFBTSxLQUFLLElBQUksSUFBSyxLQUFLLFFBQVM7QUFDeEMsUUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssSUFBSTtBQUNsRCxNQUFJLE9BQU87QUFDWCxNQUFJLGVBQWU7QUFDbkIsUUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxJQUFJO0FBQ2pELFdBQVMsT0FBTyxHQUFHLFFBQVEsT0FBTyxRQUFRLEdBQUc7QUFFM0MsUUFBSSxPQUFPLE9BQU8sYUFBYztBQUNoQyxhQUFTLElBQUksTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssR0FBRztBQUNoRCxlQUFTLElBQUksTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssR0FBRztBQUNoRCxZQUFJLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBTTtBQUM3RCxZQUFJLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSyxRQUFRLEtBQU07QUFDOUQsY0FBTSxRQUFRLElBQUksT0FBTyxHQUFHLENBQUM7QUFDN0IsWUFBSSxNQUFNLEtBQUssS0FBSyxNQUFNLEVBQUc7QUFDN0IsY0FBTSxPQUFPLElBQUksUUFBUSxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUk7QUFDckQsWUFBSSxNQUFNLGdCQUFpQixRQUFRLGdCQUFnQixRQUFRLE1BQU87QUFDaEUseUJBQWU7QUFDZixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLE1BQU0sUUFBUSxPQUFPLEtBQU8sT0FBTSxRQUFRLE1BQU07QUFDcEQsUUFBTSxRQUFRLElBQUksSUFBSSxJQUFJO0FBQzFCLFNBQU87QUFDVDsiLCJuYW1lcyI6WyJkaXJ0eSIsImZpZWxkIl19