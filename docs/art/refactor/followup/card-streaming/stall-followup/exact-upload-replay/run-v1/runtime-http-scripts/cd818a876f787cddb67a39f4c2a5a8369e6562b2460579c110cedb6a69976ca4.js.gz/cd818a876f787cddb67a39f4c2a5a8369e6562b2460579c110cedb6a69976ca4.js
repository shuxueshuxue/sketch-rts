export const EMBER_UNITS = {
  ashWarden: {
    name: { en: "Ash Warden", zh: "灰烬守卫" },
    description: { en: "Durable ember infantry that holds the line better than basic soldiers.", zh: "耐久的灰烬步兵，比基础士兵更适合顶线。" },
    command: { icon: "◭", hotkey: "g" },
    glyph: { silhouette: "shield-triangle", marks: ["shieldBar", "halo", "longSpear"] },
    art: { tier: "basic", bearing: "foot", faction: "ember" }
  },
  emberRavager: {
    name: { en: "Ember Ravager", zh: "余烬劫掠者" },
    description: { en: "Aggressive ember infantry with strong close-range damage.", zh: "进攻性的余烬步兵，近距离伤害很强。" },
    command: { icon: "◆", hotkey: "v" },
    glyph: { silhouette: "ember-bruiser", marks: ["shortSword", "spark", "scar"] },
    art: { tier: "basic", bearing: "foot", faction: "ember" }
  },
  cinderRunner: {
    name: { en: "Cinder Runner", zh: "余火奔袭者" },
    description: { en: "Fast ember melee unit for chasing weak targets and forcing fights.", zh: "高速余烬近战单位，用于追击弱目标并强行开战。" },
    command: { icon: "◇", hotkey: "r" },
    glyph: { silhouette: "cinder-skirmisher", marks: ["tail", "spark", "shortSword"] },
    art: { tier: "basic", bearing: "foot", faction: "ember" }
  },
  sparkArcher: {
    name: { en: "Spark Archer", zh: "火花弓手" },
    description: { en: "Arrows have a 15% chance to ignite a small patch of ground for 6 seconds. Burns clustered enemies and scorches them for allied melee attacks.", zh: "箭矢有 15% 概率点燃一小块地面，持续 6 秒。克制密集站位，灼烧状态可配合友军近战攻击。" },
    command: { icon: "⋊", hotkey: "a" },
    glyph: { silhouette: "bow-crest", marks: ["bow", "arrow", "spark"] },
    art: { tier: "basic", bearing: "foot", faction: "ember" }
  },
  ashHexer: {
    name: { en: "Ash Hexer", zh: "灰烬巫师" },
    description: { en: "Ember debuff caster that weakens enemy damage through curse.", zh: "余烬减益施法者，通过诅咒削弱敌方伤害。" },
    command: { icon: "☾", hotkey: "x" },
    glyph: { silhouette: "witch-crescent", marks: ["crescent", "curseSlash", "rune"] },
    art: { tier: "advanced", bearing: "foot", faction: "ember" }
  },
  ashChieftain: {
    name: { en: "Ash Chieftain", zh: "灰烬酋长" },
    description: { en: "Ember war leader who hunts casters: deals extra damage to summoned units and casters.", zh: "猎杀法师的余烬首领：对召唤生物和法师造成额外伤害。" },
    command: { icon: "♛", hotkey: "h" },
    glyph: { silhouette: "ember-bruiser", marks: ["visor", "spark", "curseSlash"] },
    art: { tier: "elite", bearing: "foot", faction: "ember" }
  },
  cinderRevenant: {
    name: { en: "Cinder Revenant", zh: "余烬复生者" },
    description: { en: "Ember elite with modest health that burns its wounds away.", zh: "生命值不高的余烬精英，伤口在余烬中迅速愈合。" },
    command: { icon: "✺", hotkey: "n" },
    glyph: { silhouette: "ember-bruiser", marks: ["spark", "halo", "scar"] },
    art: { tier: "elite", bearing: "foot", faction: "ember" }
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaXRzLWVtYmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgVHJhaW5hYmxlVW5pdEtpbmQgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IFRyYWluZWRVbml0Q2FyZCB9IGZyb20gXCIuL2NhcmRzXCI7XG5cbmV4cG9ydCBjb25zdCBFTUJFUl9VTklUUyA9IHtcbiAgYXNoV2FyZGVuOiB7XG4gICAgbmFtZTogeyBlbjogXCJBc2ggV2FyZGVuXCIsIHpoOiBcIueBsOeDrOWuiOWNq1wiIH0sXG4gICAgZGVzY3JpcHRpb246IHsgZW46IFwiRHVyYWJsZSBlbWJlciBpbmZhbnRyeSB0aGF0IGhvbGRzIHRoZSBsaW5lIGJldHRlciB0aGFuIGJhc2ljIHNvbGRpZXJzLlwiLCB6aDogXCLogJDkuYXnmoTngbDng6zmraXlhbXvvIzmr5Tln7rnoYDlo6vlhbXmm7TpgILlkIjpobbnur/jgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLil61cIiwgaG90a2V5OiBcImdcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwic2hpZWxkLXRyaWFuZ2xlXCIsIG1hcmtzOiBbXCJzaGllbGRCYXJcIiwgXCJoYWxvXCIsIFwibG9uZ1NwZWFyXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYmFzaWNcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwiZW1iZXJcIiB9LFxuICB9LFxuXG4gIGVtYmVyUmF2YWdlcjoge1xuICAgIG5hbWU6IHsgZW46IFwiRW1iZXIgUmF2YWdlclwiLCB6aDogXCLkvZnng6zliqvmjqDogIVcIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIkFnZ3Jlc3NpdmUgZW1iZXIgaW5mYW50cnkgd2l0aCBzdHJvbmcgY2xvc2UtcmFuZ2UgZGFtYWdlLlwiLCB6aDogXCLov5vmlLvmgKfnmoTkvZnng6zmraXlhbXvvIzov5Hot53nprvkvKTlrrPlvojlvLrjgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLil4ZcIiwgaG90a2V5OiBcInZcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwiZW1iZXItYnJ1aXNlclwiLCBtYXJrczogW1wic2hvcnRTd29yZFwiLCBcInNwYXJrXCIsIFwic2NhclwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImJhc2ljXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcImVtYmVyXCIgfSxcbiAgfSxcbiAgY2luZGVyUnVubmVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJDaW5kZXIgUnVubmVyXCIsIHpoOiBcIuS9meeBq+WllOiireiAhVwiIH0sXG4gICAgZGVzY3JpcHRpb246IHsgZW46IFwiRmFzdCBlbWJlciBtZWxlZSB1bml0IGZvciBjaGFzaW5nIHdlYWsgdGFyZ2V0cyBhbmQgZm9yY2luZyBmaWdodHMuXCIsIHpoOiBcIumrmOmAn+S9meeDrOi/keaImOWNleS9je+8jOeUqOS6jui/veWHu+W8seebruagh+W5tuW8uuihjOW8gOaImOOAglwiIH0sXG4gICAgY29tbWFuZDogeyBpY29uOiBcIuKXh1wiLCBob3RrZXk6IFwiclwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJjaW5kZXItc2tpcm1pc2hlclwiLCBtYXJrczogW1widGFpbFwiLCBcInNwYXJrXCIsIFwic2hvcnRTd29yZFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImJhc2ljXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcImVtYmVyXCIgfSxcbiAgfSxcbiAgc3BhcmtBcmNoZXI6IHtcbiAgICBuYW1lOiB7IGVuOiBcIlNwYXJrIEFyY2hlclwiLCB6aDogXCLngavoirHlvJPmiYtcIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIkFycm93cyBoYXZlIGEgMTUlIGNoYW5jZSB0byBpZ25pdGUgYSBzbWFsbCBwYXRjaCBvZiBncm91bmQgZm9yIDYgc2Vjb25kcy4gQnVybnMgY2x1c3RlcmVkIGVuZW1pZXMgYW5kIHNjb3JjaGVzIHRoZW0gZm9yIGFsbGllZCBtZWxlZSBhdHRhY2tzLlwiLCB6aDogXCLnrq3nn6LmnIkgMTUlIOamgueOh+eCueeHg+S4gOWwj+Wdl+WcsOmdou+8jOaMgee7rSA2IOenkuOAguWFi+WItuWvhumbhuermeS9je+8jOeBvOeDp+eKtuaAgeWPr+mFjeWQiOWPi+WGm+i/keaImOaUu+WHu+OAglwiIH0sXG4gICAgY29tbWFuZDogeyBpY29uOiBcIuKLilwiLCBob3RrZXk6IFwiYVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJib3ctY3Jlc3RcIiwgbWFya3M6IFtcImJvd1wiLCBcImFycm93XCIsIFwic3BhcmtcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJiYXNpY1wiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJlbWJlclwiIH0sXG4gIH0sXG4gIGFzaEhleGVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJBc2ggSGV4ZXJcIiwgemg6IFwi54Gw54Os5ber5biIXCIgfSxcbiAgICBkZXNjcmlwdGlvbjogeyBlbjogXCJFbWJlciBkZWJ1ZmYgY2FzdGVyIHRoYXQgd2Vha2VucyBlbmVteSBkYW1hZ2UgdGhyb3VnaCBjdXJzZS5cIiwgemg6IFwi5L2Z54Os5YeP55uK5pa95rOV6ICF77yM6YCa6L+H6K+F5ZKS5YmK5byx5pWM5pa55Lyk5a6z44CCXCIgfSxcbiAgICBjb21tYW5kOiB7IGljb246IFwi4pi+XCIsIGhvdGtleTogXCJ4XCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcIndpdGNoLWNyZXNjZW50XCIsIG1hcmtzOiBbXCJjcmVzY2VudFwiLCBcImN1cnNlU2xhc2hcIiwgXCJydW5lXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwiZW1iZXJcIiB9LFxuICB9LFxuICBhc2hDaGllZnRhaW46IHtcbiAgICBuYW1lOiB7IGVuOiBcIkFzaCBDaGllZnRhaW5cIiwgemg6IFwi54Gw54Os6YWL6ZW/XCIgfSxcbiAgICBkZXNjcmlwdGlvbjogeyBlbjogXCJFbWJlciB3YXIgbGVhZGVyIHdobyBodW50cyBjYXN0ZXJzOiBkZWFscyBleHRyYSBkYW1hZ2UgdG8gc3VtbW9uZWQgdW5pdHMgYW5kIGNhc3RlcnMuXCIsIHpoOiBcIueMjuadgOazleW4iOeahOS9meeDrOmmlumihu+8muWvueWPrOWUpOeUn+eJqeWSjOazleW4iOmAoOaIkOmineWkluS8pOWus+OAglwiIH0sXG4gICAgY29tbWFuZDogeyBpY29uOiBcIuKZm1wiLCBob3RrZXk6IFwiaFwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJlbWJlci1icnVpc2VyXCIsIG1hcmtzOiBbXCJ2aXNvclwiLCBcInNwYXJrXCIsIFwiY3Vyc2VTbGFzaFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcImVtYmVyXCIgfSxcbiAgfSxcbiAgY2luZGVyUmV2ZW5hbnQ6IHtcbiAgICBuYW1lOiB7IGVuOiBcIkNpbmRlciBSZXZlbmFudFwiLCB6aDogXCLkvZnng6zlpI3nlJ/ogIVcIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIkVtYmVyIGVsaXRlIHdpdGggbW9kZXN0IGhlYWx0aCB0aGF0IGJ1cm5zIGl0cyB3b3VuZHMgYXdheS5cIiwgemg6IFwi55Sf5ZG95YC85LiN6auY55qE5L2Z54Os57K+6Iux77yM5Lyk5Y+j5Zyo5L2Z54Os5Lit6L+F6YCf5oSI5ZCI44CCXCIgfSxcbiAgICBjb21tYW5kOiB7IGljb246IFwi4py6XCIsIGhvdGtleTogXCJuXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcImVtYmVyLWJydWlzZXJcIiwgbWFya3M6IFtcInNwYXJrXCIsIFwiaGFsb1wiLCBcInNjYXJcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJlbWJlclwiIH0sXG4gIH0sXG59IHNhdGlzZmllcyBQYXJ0aWFsPFJlY29yZDxUcmFpbmFibGVVbml0S2luZCwgVHJhaW5lZFVuaXRDYXJkPj47XG4iXSwibWFwcGluZ3MiOiJBQUdPLGFBQU0sY0FBYztBQUFBLEVBQ3pCLFdBQVc7QUFBQSxJQUNULE1BQU0sRUFBRSxJQUFJLGNBQWMsSUFBSSxPQUFPO0FBQUEsSUFDckMsYUFBYSxFQUFFLElBQUksMEVBQTBFLElBQUksc0JBQXNCO0FBQUEsSUFDdkgsU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUNsQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsUUFBUSxXQUFXLEVBQUU7QUFBQSxJQUNsRixLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFBQSxFQUMxRDtBQUFBLEVBRUEsY0FBYztBQUFBLElBQ1osTUFBTSxFQUFFLElBQUksaUJBQWlCLElBQUksUUFBUTtBQUFBLElBQ3pDLGFBQWEsRUFBRSxJQUFJLDZEQUE2RCxJQUFJLG9CQUFvQjtBQUFBLElBQ3hHLFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksaUJBQWlCLE9BQU8sQ0FBQyxjQUFjLFNBQVMsTUFBTSxFQUFFO0FBQUEsSUFDN0UsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLGNBQWM7QUFBQSxJQUNaLE1BQU0sRUFBRSxJQUFJLGlCQUFpQixJQUFJLFFBQVE7QUFBQSxJQUN6QyxhQUFhLEVBQUUsSUFBSSxzRUFBc0UsSUFBSSx5QkFBeUI7QUFBQSxJQUN0SCxTQUFTLEVBQUUsTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUFBLElBQ2xDLE9BQU8sRUFBRSxZQUFZLHFCQUFxQixPQUFPLENBQUMsUUFBUSxTQUFTLFlBQVksRUFBRTtBQUFBLElBQ2pGLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUFBLEVBQzFEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSSxPQUFPO0FBQUEsSUFDdkMsYUFBYSxFQUFFLElBQUksaUpBQWlKLElBQUksaURBQWlEO0FBQUEsSUFDek4sU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUNsQyxPQUFPLEVBQUUsWUFBWSxhQUFhLE9BQU8sQ0FBQyxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQUEsSUFDbkUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxJQUNSLE1BQU0sRUFBRSxJQUFJLGFBQWEsSUFBSSxPQUFPO0FBQUEsSUFDcEMsYUFBYSxFQUFFLElBQUksZ0VBQWdFLElBQUksc0JBQXNCO0FBQUEsSUFDN0csU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUNsQyxPQUFPLEVBQUUsWUFBWSxrQkFBa0IsT0FBTyxDQUFDLFlBQVksY0FBYyxNQUFNLEVBQUU7QUFBQSxJQUNqRixLQUFLLEVBQUUsTUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFBQSxFQUM3RDtBQUFBLEVBQ0EsY0FBYztBQUFBLElBQ1osTUFBTSxFQUFFLElBQUksaUJBQWlCLElBQUksT0FBTztBQUFBLElBQ3hDLGFBQWEsRUFBRSxJQUFJLHlGQUF5RixJQUFJLDRCQUE0QjtBQUFBLElBQzVJLFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksaUJBQWlCLE9BQU8sQ0FBQyxTQUFTLFNBQVMsWUFBWSxFQUFFO0FBQUEsSUFDOUUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLGdCQUFnQjtBQUFBLElBQ2QsTUFBTSxFQUFFLElBQUksbUJBQW1CLElBQUksUUFBUTtBQUFBLElBQzNDLGFBQWEsRUFBRSxJQUFJLDhEQUE4RCxJQUFJLHlCQUF5QjtBQUFBLElBQzlHLFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksaUJBQWlCLE9BQU8sQ0FBQyxTQUFTLFFBQVEsTUFBTSxFQUFFO0FBQUEsSUFDdkUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFDRjsiLCJuYW1lcyI6W119