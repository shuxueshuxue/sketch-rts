import { resources, resourceSize, resourceText } from "/@fs/tmp/sketch-queue-source-42bd/src/client/resources.ts";
import "/@fs/tmp/sketch-queue-source-42bd/src/client/resource-panel.css";
const names = { startup: resourceText("启动界面", "Interface"), home: resourceText("首页场景", "Home scene"), match: resourceText("遭遇战", "Skirmish") };
export class ResourcePanel {
  root = document.createElement("section");
  title = document.createElement("h2");
  progress = document.createElement("progress");
  summary = document.createElement("p");
  stage = document.createElement("p");
  details = document.createElement("details");
  rows = document.createElement("div");
  tabs = document.createElement("nav");
  close = document.createElement("button");
  retry = document.createElement("button");
  selected = "startup";
  pending = false;
  queued = false;
  frame;
  unsubscribe;
  disposed = false;
  runs = /* @__PURE__ */ new Set();
  again;
  renderer = "";
  constructor() {
    this.root.className = "resource-screen";
    this.root.hidden = true;
    this.root.setAttribute("role", "dialog");
    this.root.setAttribute("aria-label", resourceText("资源载入", "Resource loading"));
    const card = document.createElement("div");
    card.className = "resource-card";
    this.root.append(card);
    this.close.textContent = resourceText("关闭", "Close");
    this.close.className = "resource-close";
    this.close.onclick = () => {
      if (!this.pending) this.root.hidden = true;
    };
    this.progress.max = 1;
    this.progress.setAttribute("aria-label", resourceText("资源读取进度", "Bytes loaded"));
    this.summary.className = "resource-summary";
    this.summary.setAttribute("aria-live", "polite");
    this.stage.className = "resource-stage";
    for (const phase of ["startup", "home", "match"]) {
      const button = document.createElement("button");
      button.textContent = names[phase];
      button.onclick = () => {
        this.selected = phase;
        this.update();
      };
      button.dataset.phase = phase;
      this.tabs.append(button);
    }
    const label = document.createElement("summary");
    label.textContent = resourceText("查看资源大小与耗时", "Resource sizes and timings");
    this.details.append(label, this.rows);
    this.rows.className = "resource-rows";
    this.details.ontoggle = () => this.update();
    this.retry.textContent = resourceText("重试", "Retry");
    this.retry.hidden = true;
    this.retry.onclick = () => this.again?.();
    card.append(this.close, this.title, this.tabs, this.progress, this.summary, this.stage, this.details, this.retry);
    document.body.append(this.root);
    this.unsubscribe = resources.subscribe(() => {
      if (this.queued || this.disposed) return;
      this.queued = true;
      this.frame = requestAnimationFrame(() => {
        this.frame = void 0;
        this.queued = false;
        this.update();
      });
    });
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.unsubscribe();
    if (this.frame !== void 0) cancelAnimationFrame(this.frame);
    this.frame = void 0;
    this.again = void 0;
    this.pending = false;
    for (const finish of this.runs) finish();
    this.root.remove();
  }
  open() {
    if (this.pending) return;
    this.root.hidden = false;
    this.close.hidden = false;
    this.tabs.hidden = false;
    this.details.open = true;
    this.update();
  }
  async run(phase, title, task) {
    await new Promise((resolve, reject) => {
      const cancel = () => {
        this.runs.delete(cancel);
        reject(new DOMException("Resource panel was disposed", "AbortError"));
      };
      const finish = () => {
        this.runs.delete(cancel);
        resolve();
      };
      this.runs.add(cancel);
      const attempt = async () => {
        if (this.disposed) {
          cancel();
          return;
        }
        resources.phase = phase;
        this.selected = phase;
        this.pending = true;
        this.root.hidden = false;
        this.close.hidden = true;
        this.tabs.hidden = true;
        this.retry.hidden = true;
        this.details.open = false;
        this.stage.textContent = title;
        this.update();
        this.again = void 0;
        try {
          await task();
          this.pending = false;
          this.root.hidden = true;
          finish();
        } catch (error) {
          if (this.disposed) {
            cancel();
            return;
          }
          this.stage.textContent = `${resourceText("载入失败：", "Loading failed: ")}${error instanceof Error ? error.message : String(error)}`;
          this.retry.hidden = false;
          this.again = () => void attempt();
        }
      };
      void attempt();
    });
  }
  preparing(text) {
    this.stage.textContent = text;
  }
  update() {
    if (this.disposed || this.root.hidden) return;
    const state = resources.summary(this.selected);
    this.title.textContent = this.pending ? `${resourceText("载入", "Loading ")}${names[this.selected]}` : resourceText("资源记录", "Resource report");
    if (state.unknown || state.total === 0 && state.entries.length > 0) this.progress.removeAttribute("value");
    else this.progress.value = state.total ? Math.min(1, state.loaded / state.total) : 0;
    this.summary.textContent = state.entries.length ? `${resourceSize(state.loaded)} / ${state.unknown ? resourceText("总大小待确认", "total pending") : resourceSize(state.total)} · ${state.ready}/${state.entries.length} ${resourceText("项", "files")}${state.reused ? ` · ${resourceText("复用", "reused")} ${resourceSize(state.reused)}` : ""}${state.failed ? ` · ${state.failed} ${resourceText("项失败", "failed")}` : ""}` : resourceText("尚未进入此载入阶段", "This phase has not started");
    if (!this.pending) this.stage.textContent = `${names[this.selected]}${this.renderer ? ` · ${this.renderer}` : ""} · ${resourceText("读取大小包含浏览器缓存；网络压缩大小可能不同", "Read size includes browser cache; compressed network size may differ")}`;
    for (const button of this.tabs.querySelectorAll("button")) button.setAttribute("aria-pressed", String(button.dataset.phase === this.selected));
    if (!this.details.open) {
      this.rows.replaceChildren();
      return;
    }
    const fragment = document.createDocumentFragment();
    for (const entry of [...state.entries].sort((a, b) => (b.expected ?? b.loaded) - (a.expected ?? a.loaded))) {
      const row = document.createElement("div");
      row.className = "resource-row";
      const label = document.createElement("span");
      label.textContent = entry.label;
      label.title = entry.url;
      const size = document.createElement("span");
      size.textContent = entry.expected === void 0 ? `${resourceSize(entry.loaded)} / ?` : resourceSize(entry.expected);
      const status = document.createElement("span");
      status.textContent = entry.state === "ready" ? `${(entry.elapsed / 1e3).toFixed(2)} s` : entry.state === "failed" ? entry.error ?? resourceText("失败", "Failed") : `${resourceText("读取", "Reading")} ${resourceSize(entry.loaded)}`;
      row.append(label, size, status);
      fragment.append(row);
    }
    this.rows.replaceChildren(fragment);
  }
}
let panel;
export function resourcePanel() {
  return panel ??= new ResourcePanel();
}
export function disposeResourcePanel() {
  panel?.dispose();
  panel = void 0;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc291cmNlLXBhbmVsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHJlc291cmNlcyxyZXNvdXJjZVNpemUscmVzb3VyY2VUZXh0LHR5cGUgUmVzb3VyY2VQaGFzZSB9IGZyb20gJy4vcmVzb3VyY2VzJztcbmltcG9ydCAnLi9yZXNvdXJjZS1wYW5lbC5jc3MnO1xuXG5jb25zdCBuYW1lcz17c3RhcnR1cDpyZXNvdXJjZVRleHQoJ+WQr+WKqOeVjOmdoicsJ0ludGVyZmFjZScpLGhvbWU6cmVzb3VyY2VUZXh0KCfpppbpobXlnLrmma8nLCdIb21lIHNjZW5lJyksbWF0Y2g6cmVzb3VyY2VUZXh0KCfpga3pgYfmiJgnLCdTa2lybWlzaCcpfTtcbmV4cG9ydCBjbGFzcyBSZXNvdXJjZVBhbmVsIHtcbiAgcHJpdmF0ZSByb290PWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NlY3Rpb24nKTtcbiAgcHJpdmF0ZSB0aXRsZT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoMicpO1xuICBwcml2YXRlIHByb2dyZXNzPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Byb2dyZXNzJyk7XG4gIHByaXZhdGUgc3VtbWFyeT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XG4gIHByaXZhdGUgc3RhZ2U9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xuICBwcml2YXRlIGRldGFpbHM9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGV0YWlscycpO1xuICBwcml2YXRlIHJvd3M9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIHByaXZhdGUgdGFicz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCduYXYnKTtcbiAgcHJpdmF0ZSBjbG9zZT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgcHJpdmF0ZSByZXRyeT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgcHJpdmF0ZSBzZWxlY3RlZDpSZXNvdXJjZVBoYXNlPSdzdGFydHVwJztcbiAgcHJpdmF0ZSBwZW5kaW5nPWZhbHNlO1xuICBwcml2YXRlIHF1ZXVlZD1mYWxzZTtcbiAgcHJpdmF0ZSBmcmFtZTpudW1iZXJ8dW5kZWZpbmVkO1xuICBwcml2YXRlIHVuc3Vic2NyaWJlOigpPT52b2lkO1xuICBwcml2YXRlIGRpc3Bvc2VkPWZhbHNlO1xuICBwcml2YXRlIHJ1bnM9bmV3IFNldDwoKT0+dm9pZD4oKTtcbiAgcHJpdmF0ZSBhZ2FpbjooKCk9PnZvaWQpfHVuZGVmaW5lZDtcbiAgcmVuZGVyZXI9Jyc7XG4gIGNvbnN0cnVjdG9yKCl7XG4gICAgdGhpcy5yb290LmNsYXNzTmFtZT0ncmVzb3VyY2Utc2NyZWVuJzt0aGlzLnJvb3QuaGlkZGVuPXRydWU7dGhpcy5yb290LnNldEF0dHJpYnV0ZSgncm9sZScsJ2RpYWxvZycpO3RoaXMucm9vdC5zZXRBdHRyaWJ1dGUoJ2FyaWEtbGFiZWwnLHJlc291cmNlVGV4dCgn6LWE5rqQ6L295YWlJywnUmVzb3VyY2UgbG9hZGluZycpKTtcbiAgICBjb25zdCBjYXJkPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO2NhcmQuY2xhc3NOYW1lPSdyZXNvdXJjZS1jYXJkJzt0aGlzLnJvb3QuYXBwZW5kKGNhcmQpO1xuICAgIHRoaXMuY2xvc2UudGV4dENvbnRlbnQ9cmVzb3VyY2VUZXh0KCflhbPpl60nLCdDbG9zZScpO3RoaXMuY2xvc2UuY2xhc3NOYW1lPSdyZXNvdXJjZS1jbG9zZSc7dGhpcy5jbG9zZS5vbmNsaWNrPSgpPT57aWYoIXRoaXMucGVuZGluZyl0aGlzLnJvb3QuaGlkZGVuPXRydWU7fTtcbiAgICB0aGlzLnByb2dyZXNzLm1heD0xO3RoaXMucHJvZ3Jlc3Muc2V0QXR0cmlidXRlKCdhcmlhLWxhYmVsJyxyZXNvdXJjZVRleHQoJ+i1hOa6kOivu+WPlui/m+W6picsJ0J5dGVzIGxvYWRlZCcpKTtcbiAgICB0aGlzLnN1bW1hcnkuY2xhc3NOYW1lPSdyZXNvdXJjZS1zdW1tYXJ5Jzt0aGlzLnN1bW1hcnkuc2V0QXR0cmlidXRlKCdhcmlhLWxpdmUnLCdwb2xpdGUnKTt0aGlzLnN0YWdlLmNsYXNzTmFtZT0ncmVzb3VyY2Utc3RhZ2UnO1xuICAgIGZvcihjb25zdCBwaGFzZSBvZiBbJ3N0YXJ0dXAnLCdob21lJywnbWF0Y2gnXSBhcyBjb25zdCl7Y29uc3QgYnV0dG9uPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO2J1dHRvbi50ZXh0Q29udGVudD1uYW1lc1twaGFzZV07YnV0dG9uLm9uY2xpY2s9KCk9Pnt0aGlzLnNlbGVjdGVkPXBoYXNlO3RoaXMudXBkYXRlKCk7fTtidXR0b24uZGF0YXNldC5waGFzZT1waGFzZTt0aGlzLnRhYnMuYXBwZW5kKGJ1dHRvbik7fVxuICAgIGNvbnN0IGxhYmVsPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N1bW1hcnknKTtsYWJlbC50ZXh0Q29udGVudD1yZXNvdXJjZVRleHQoJ+afpeeci+i1hOa6kOWkp+Wwj+S4juiAl+aXticsJ1Jlc291cmNlIHNpemVzIGFuZCB0aW1pbmdzJyk7dGhpcy5kZXRhaWxzLmFwcGVuZChsYWJlbCx0aGlzLnJvd3MpO3RoaXMucm93cy5jbGFzc05hbWU9J3Jlc291cmNlLXJvd3MnO3RoaXMuZGV0YWlscy5vbnRvZ2dsZT0oKT0+dGhpcy51cGRhdGUoKTtcbiAgICB0aGlzLnJldHJ5LnRleHRDb250ZW50PXJlc291cmNlVGV4dCgn6YeN6K+VJywnUmV0cnknKTt0aGlzLnJldHJ5LmhpZGRlbj10cnVlO3RoaXMucmV0cnkub25jbGljaz0oKT0+dGhpcy5hZ2Fpbj8uKCk7XG4gICAgY2FyZC5hcHBlbmQodGhpcy5jbG9zZSx0aGlzLnRpdGxlLHRoaXMudGFicyx0aGlzLnByb2dyZXNzLHRoaXMuc3VtbWFyeSx0aGlzLnN0YWdlLHRoaXMuZGV0YWlscyx0aGlzLnJldHJ5KTtkb2N1bWVudC5ib2R5LmFwcGVuZCh0aGlzLnJvb3QpO1xuICAgIHRoaXMudW5zdWJzY3JpYmU9cmVzb3VyY2VzLnN1YnNjcmliZSgoKT0+e2lmKHRoaXMucXVldWVkfHx0aGlzLmRpc3Bvc2VkKXJldHVybjt0aGlzLnF1ZXVlZD10cnVlO3RoaXMuZnJhbWU9cmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpPT57dGhpcy5mcmFtZT11bmRlZmluZWQ7dGhpcy5xdWV1ZWQ9ZmFsc2U7dGhpcy51cGRhdGUoKTt9KTt9KTtcbiAgfVxuICBkaXNwb3NlKCl7aWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5kaXNwb3NlZD10cnVlO3RoaXMudW5zdWJzY3JpYmUoKTtpZih0aGlzLmZyYW1lIT09dW5kZWZpbmVkKWNhbmNlbEFuaW1hdGlvbkZyYW1lKHRoaXMuZnJhbWUpO3RoaXMuZnJhbWU9dW5kZWZpbmVkO3RoaXMuYWdhaW49dW5kZWZpbmVkO3RoaXMucGVuZGluZz1mYWxzZTtmb3IoY29uc3QgZmluaXNoIG9mIHRoaXMucnVucylmaW5pc2goKTt0aGlzLnJvb3QucmVtb3ZlKCk7fVxuICBvcGVuKCl7aWYodGhpcy5wZW5kaW5nKXJldHVybjt0aGlzLnJvb3QuaGlkZGVuPWZhbHNlO3RoaXMuY2xvc2UuaGlkZGVuPWZhbHNlO3RoaXMudGFicy5oaWRkZW49ZmFsc2U7dGhpcy5kZXRhaWxzLm9wZW49dHJ1ZTt0aGlzLnVwZGF0ZSgpO31cbiAgYXN5bmMgcnVuKHBoYXNlOlJlc291cmNlUGhhc2UsdGl0bGU6c3RyaW5nLHRhc2s6KCk9PlByb21pc2U8dm9pZD4pe1xuICAgIC8vIEtlZXAgdGhlIG9yaWdpbmFsIGNhbGxlciBzdXNwZW5kZWQgYWNyb3NzIHJldHJpZXMsIHNvIHN0YXJ0dXAgYW5kIG1hdGNoXG4gICAgLy8gY3JlYXRpb24gcmVzdW1lIG9ubHkgYWZ0ZXIgdGhlIHNhbWUgcHJlcGFyYXRpb24gaGFzIGFjdHVhbGx5IHN1Y2NlZWRlZC5cbiAgICBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSxyZWplY3QpPT57XG4gICAgICBjb25zdCBjYW5jZWw9KCk9Pnt0aGlzLnJ1bnMuZGVsZXRlKGNhbmNlbCk7cmVqZWN0KG5ldyBET01FeGNlcHRpb24oJ1Jlc291cmNlIHBhbmVsIHdhcyBkaXNwb3NlZCcsJ0Fib3J0RXJyb3InKSk7fTtcbiAgICAgIGNvbnN0IGZpbmlzaD0oKT0+e3RoaXMucnVucy5kZWxldGUoY2FuY2VsKTtyZXNvbHZlKCk7fTt0aGlzLnJ1bnMuYWRkKGNhbmNlbCk7XG4gICAgICBjb25zdCBhdHRlbXB0PWFzeW5jKCk9PntcbiAgICAgICAgaWYodGhpcy5kaXNwb3NlZCl7Y2FuY2VsKCk7cmV0dXJuO31cbiAgICAgICAgcmVzb3VyY2VzLnBoYXNlPXBoYXNlO3RoaXMuc2VsZWN0ZWQ9cGhhc2U7dGhpcy5wZW5kaW5nPXRydWU7dGhpcy5yb290LmhpZGRlbj1mYWxzZTt0aGlzLmNsb3NlLmhpZGRlbj10cnVlO3RoaXMudGFicy5oaWRkZW49dHJ1ZTt0aGlzLnJldHJ5LmhpZGRlbj10cnVlO3RoaXMuZGV0YWlscy5vcGVuPWZhbHNlO3RoaXMuc3RhZ2UudGV4dENvbnRlbnQ9dGl0bGU7dGhpcy51cGRhdGUoKTt0aGlzLmFnYWluPXVuZGVmaW5lZDtcbiAgICAgICAgdHJ5e2F3YWl0IHRhc2soKTt0aGlzLnBlbmRpbmc9ZmFsc2U7dGhpcy5yb290LmhpZGRlbj10cnVlO2ZpbmlzaCgpO31cbiAgICAgICAgY2F0Y2goZXJyb3Ipe2lmKHRoaXMuZGlzcG9zZWQpe2NhbmNlbCgpO3JldHVybjt9dGhpcy5zdGFnZS50ZXh0Q29udGVudD1gJHtyZXNvdXJjZVRleHQoJ+i9veWFpeWksei0pe+8micsJ0xvYWRpbmcgZmFpbGVkOiAnKX0ke2Vycm9yIGluc3RhbmNlb2YgRXJyb3I/ZXJyb3IubWVzc2FnZTpTdHJpbmcoZXJyb3IpfWA7dGhpcy5yZXRyeS5oaWRkZW49ZmFsc2U7dGhpcy5hZ2Fpbj0oKT0+dm9pZCBhdHRlbXB0KCk7fVxuICAgICAgfTtcbiAgICAgIHZvaWQgYXR0ZW1wdCgpO1xuICAgIH0pO1xuICB9XG4gIHByZXBhcmluZyh0ZXh0OnN0cmluZyl7dGhpcy5zdGFnZS50ZXh0Q29udGVudD10ZXh0O31cbiAgcHJpdmF0ZSB1cGRhdGUoKXtcbiAgICBpZih0aGlzLmRpc3Bvc2VkfHx0aGlzLnJvb3QuaGlkZGVuKXJldHVybjtcbiAgICBjb25zdCBzdGF0ZT1yZXNvdXJjZXMuc3VtbWFyeSh0aGlzLnNlbGVjdGVkKTt0aGlzLnRpdGxlLnRleHRDb250ZW50PXRoaXMucGVuZGluZz9gJHtyZXNvdXJjZVRleHQoJ+i9veWFpScsJ0xvYWRpbmcgJyl9JHtuYW1lc1t0aGlzLnNlbGVjdGVkXX1gOnJlc291cmNlVGV4dCgn6LWE5rqQ6K6w5b2VJywnUmVzb3VyY2UgcmVwb3J0Jyk7XG4gICAgaWYoc3RhdGUudW5rbm93biB8fCBzdGF0ZS50b3RhbD09PTAmJnN0YXRlLmVudHJpZXMubGVuZ3RoPjApdGhpcy5wcm9ncmVzcy5yZW1vdmVBdHRyaWJ1dGUoJ3ZhbHVlJyk7ZWxzZSB0aGlzLnByb2dyZXNzLnZhbHVlPXN0YXRlLnRvdGFsP01hdGgubWluKDEsc3RhdGUubG9hZGVkL3N0YXRlLnRvdGFsKTowO1xuICAgIHRoaXMuc3VtbWFyeS50ZXh0Q29udGVudD1zdGF0ZS5lbnRyaWVzLmxlbmd0aD9gJHtyZXNvdXJjZVNpemUoc3RhdGUubG9hZGVkKX0gLyAke3N0YXRlLnVua25vd24/cmVzb3VyY2VUZXh0KCfmgLvlpKflsI/lvoXnoa7orqQnLCd0b3RhbCBwZW5kaW5nJyk6cmVzb3VyY2VTaXplKHN0YXRlLnRvdGFsKX0gwrcgJHtzdGF0ZS5yZWFkeX0vJHtzdGF0ZS5lbnRyaWVzLmxlbmd0aH0gJHtyZXNvdXJjZVRleHQoJ+mhuScsJ2ZpbGVzJyl9JHtzdGF0ZS5yZXVzZWQ/YCDCtyAke3Jlc291cmNlVGV4dCgn5aSN55SoJywncmV1c2VkJyl9ICR7cmVzb3VyY2VTaXplKHN0YXRlLnJldXNlZCl9YDonJ30ke3N0YXRlLmZhaWxlZD9gIMK3ICR7c3RhdGUuZmFpbGVkfSAke3Jlc291cmNlVGV4dCgn6aG55aSx6LSlJywnZmFpbGVkJyl9YDonJ31gOnJlc291cmNlVGV4dCgn5bCa5pyq6L+b5YWl5q2k6L295YWl6Zi25q61JywnVGhpcyBwaGFzZSBoYXMgbm90IHN0YXJ0ZWQnKTtcbiAgICBpZighdGhpcy5wZW5kaW5nKXRoaXMuc3RhZ2UudGV4dENvbnRlbnQ9YCR7bmFtZXNbdGhpcy5zZWxlY3RlZF19JHt0aGlzLnJlbmRlcmVyP2AgwrcgJHt0aGlzLnJlbmRlcmVyfWA6Jyd9IMK3ICR7cmVzb3VyY2VUZXh0KCfor7vlj5blpKflsI/ljIXlkKvmtY/op4jlmajnvJPlrZjvvJvnvZHnu5zljovnvKnlpKflsI/lj6/og73kuI3lkIwnLCdSZWFkIHNpemUgaW5jbHVkZXMgYnJvd3NlciBjYWNoZTsgY29tcHJlc3NlZCBuZXR3b3JrIHNpemUgbWF5IGRpZmZlcicpfWA7XG4gICAgZm9yKGNvbnN0IGJ1dHRvbiBvZiB0aGlzLnRhYnMucXVlcnlTZWxlY3RvckFsbCgnYnV0dG9uJykpYnV0dG9uLnNldEF0dHJpYnV0ZSgnYXJpYS1wcmVzc2VkJyxTdHJpbmcoYnV0dG9uLmRhdGFzZXQucGhhc2U9PT10aGlzLnNlbGVjdGVkKSk7XG4gICAgaWYoIXRoaXMuZGV0YWlscy5vcGVuKXt0aGlzLnJvd3MucmVwbGFjZUNoaWxkcmVuKCk7cmV0dXJuO31cbiAgICBjb25zdCBmcmFnbWVudD1kb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgZm9yKGNvbnN0IGVudHJ5IG9mIFsuLi5zdGF0ZS5lbnRyaWVzXS5zb3J0KChhLGIpPT4oYi5leHBlY3RlZD8/Yi5sb2FkZWQpLShhLmV4cGVjdGVkPz9hLmxvYWRlZCkpKXtcbiAgICAgIGNvbnN0IHJvdz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtyb3cuY2xhc3NOYW1lPSdyZXNvdXJjZS1yb3cnO1xuICAgICAgY29uc3QgbGFiZWw9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO2xhYmVsLnRleHRDb250ZW50PWVudHJ5LmxhYmVsO2xhYmVsLnRpdGxlPWVudHJ5LnVybDtcbiAgICAgIGNvbnN0IHNpemU9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO3NpemUudGV4dENvbnRlbnQ9ZW50cnkuZXhwZWN0ZWQ9PT11bmRlZmluZWQ/YCR7cmVzb3VyY2VTaXplKGVudHJ5LmxvYWRlZCl9IC8gP2A6cmVzb3VyY2VTaXplKGVudHJ5LmV4cGVjdGVkKTtcbiAgICAgIGNvbnN0IHN0YXR1cz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7c3RhdHVzLnRleHRDb250ZW50PWVudHJ5LnN0YXRlPT09J3JlYWR5Jz9gJHsoZW50cnkuZWxhcHNlZC8xMDAwKS50b0ZpeGVkKDIpfSBzYDplbnRyeS5zdGF0ZT09PSdmYWlsZWQnP2VudHJ5LmVycm9yPz9yZXNvdXJjZVRleHQoJ+Wksei0pScsJ0ZhaWxlZCcpOmAke3Jlc291cmNlVGV4dCgn6K+75Y+WJywnUmVhZGluZycpfSAke3Jlc291cmNlU2l6ZShlbnRyeS5sb2FkZWQpfWA7XG4gICAgICByb3cuYXBwZW5kKGxhYmVsLHNpemUsc3RhdHVzKTtmcmFnbWVudC5hcHBlbmQocm93KTtcbiAgICB9XG4gICAgdGhpcy5yb3dzLnJlcGxhY2VDaGlsZHJlbihmcmFnbWVudCk7XG4gIH1cbn1cbmxldCBwYW5lbDpSZXNvdXJjZVBhbmVsfHVuZGVmaW5lZDtcbmV4cG9ydCBmdW5jdGlvbiByZXNvdXJjZVBhbmVsKCl7cmV0dXJuIHBhbmVsPz89bmV3IFJlc291cmNlUGFuZWwoKTt9XG5leHBvcnQgZnVuY3Rpb24gZGlzcG9zZVJlc291cmNlUGFuZWwoKXtwYW5lbD8uZGlzcG9zZSgpO3BhbmVsPXVuZGVmaW5lZDt9XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsV0FBVSxjQUFhLG9CQUF1QztBQUN2RSxPQUFPO0FBRVAsTUFBTSxRQUFNLEVBQUMsU0FBUSxhQUFhLFFBQU8sV0FBVyxHQUFFLE1BQUssYUFBYSxRQUFPLFlBQVksR0FBRSxPQUFNLGFBQWEsT0FBTSxVQUFVLEVBQUM7QUFDMUgsYUFBTSxjQUFjO0FBQUEsRUFDakIsT0FBSyxTQUFTLGNBQWMsU0FBUztBQUFBLEVBQ3JDLFFBQU0sU0FBUyxjQUFjLElBQUk7QUFBQSxFQUNqQyxXQUFTLFNBQVMsY0FBYyxVQUFVO0FBQUEsRUFDMUMsVUFBUSxTQUFTLGNBQWMsR0FBRztBQUFBLEVBQ2xDLFFBQU0sU0FBUyxjQUFjLEdBQUc7QUFBQSxFQUNoQyxVQUFRLFNBQVMsY0FBYyxTQUFTO0FBQUEsRUFDeEMsT0FBSyxTQUFTLGNBQWMsS0FBSztBQUFBLEVBQ2pDLE9BQUssU0FBUyxjQUFjLEtBQUs7QUFBQSxFQUNqQyxRQUFNLFNBQVMsY0FBYyxRQUFRO0FBQUEsRUFDckMsUUFBTSxTQUFTLGNBQWMsUUFBUTtBQUFBLEVBQ3JDLFdBQXVCO0FBQUEsRUFDdkIsVUFBUTtBQUFBLEVBQ1IsU0FBTztBQUFBLEVBQ1A7QUFBQSxFQUNBO0FBQUEsRUFDQSxXQUFTO0FBQUEsRUFDVCxPQUFLLG9CQUFJLElBQWM7QUFBQSxFQUN2QjtBQUFBLEVBQ1IsV0FBUztBQUFBLEVBQ1QsY0FBYTtBQUNYLFNBQUssS0FBSyxZQUFVO0FBQWtCLFNBQUssS0FBSyxTQUFPO0FBQUssU0FBSyxLQUFLLGFBQWEsUUFBTyxRQUFRO0FBQUUsU0FBSyxLQUFLLGFBQWEsY0FBYSxhQUFhLFFBQU8sa0JBQWtCLENBQUM7QUFDL0ssVUFBTSxPQUFLLFNBQVMsY0FBYyxLQUFLO0FBQUUsU0FBSyxZQUFVO0FBQWdCLFNBQUssS0FBSyxPQUFPLElBQUk7QUFDN0YsU0FBSyxNQUFNLGNBQVksYUFBYSxNQUFLLE9BQU87QUFBRSxTQUFLLE1BQU0sWUFBVTtBQUFpQixTQUFLLE1BQU0sVUFBUSxNQUFJO0FBQUMsVUFBRyxDQUFDLEtBQUssUUFBUSxNQUFLLEtBQUssU0FBTztBQUFBLElBQUs7QUFDdkosU0FBSyxTQUFTLE1BQUk7QUFBRSxTQUFLLFNBQVMsYUFBYSxjQUFhLGFBQWEsVUFBUyxjQUFjLENBQUM7QUFDakcsU0FBSyxRQUFRLFlBQVU7QUFBbUIsU0FBSyxRQUFRLGFBQWEsYUFBWSxRQUFRO0FBQUUsU0FBSyxNQUFNLFlBQVU7QUFDL0csZUFBVSxTQUFTLENBQUMsV0FBVSxRQUFPLE9BQU8sR0FBVztBQUFDLFlBQU0sU0FBTyxTQUFTLGNBQWMsUUFBUTtBQUFFLGFBQU8sY0FBWSxNQUFNLEtBQUs7QUFBRSxhQUFPLFVBQVEsTUFBSTtBQUFDLGFBQUssV0FBUztBQUFNLGFBQUssT0FBTztBQUFBLE1BQUU7QUFBRSxhQUFPLFFBQVEsUUFBTTtBQUFNLFdBQUssS0FBSyxPQUFPLE1BQU07QUFBQSxJQUFFO0FBQ2xQLFVBQU0sUUFBTSxTQUFTLGNBQWMsU0FBUztBQUFFLFVBQU0sY0FBWSxhQUFhLGFBQVksNEJBQTRCO0FBQUUsU0FBSyxRQUFRLE9BQU8sT0FBTSxLQUFLLElBQUk7QUFBRSxTQUFLLEtBQUssWUFBVTtBQUFnQixTQUFLLFFBQVEsV0FBUyxNQUFJLEtBQUssT0FBTztBQUN0TyxTQUFLLE1BQU0sY0FBWSxhQUFhLE1BQUssT0FBTztBQUFFLFNBQUssTUFBTSxTQUFPO0FBQUssU0FBSyxNQUFNLFVBQVEsTUFBSSxLQUFLLFFBQVE7QUFDN0csU0FBSyxPQUFPLEtBQUssT0FBTSxLQUFLLE9BQU0sS0FBSyxNQUFLLEtBQUssVUFBUyxLQUFLLFNBQVEsS0FBSyxPQUFNLEtBQUssU0FBUSxLQUFLLEtBQUs7QUFBRSxhQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7QUFDekksU0FBSyxjQUFZLFVBQVUsVUFBVSxNQUFJO0FBQUMsVUFBRyxLQUFLLFVBQVEsS0FBSyxTQUFTO0FBQU8sV0FBSyxTQUFPO0FBQUssV0FBSyxRQUFNLHNCQUFzQixNQUFJO0FBQUMsYUFBSyxRQUFNO0FBQVUsYUFBSyxTQUFPO0FBQU0sYUFBSyxPQUFPO0FBQUEsTUFBRSxDQUFDO0FBQUEsSUFBRSxDQUFDO0FBQUEsRUFDak07QUFBQSxFQUNBLFVBQVM7QUFBQyxRQUFHLEtBQUssU0FBUztBQUFPLFNBQUssV0FBUztBQUFLLFNBQUssWUFBWTtBQUFFLFFBQUcsS0FBSyxVQUFRLE9BQVUsc0JBQXFCLEtBQUssS0FBSztBQUFFLFNBQUssUUFBTTtBQUFVLFNBQUssUUFBTTtBQUFVLFNBQUssVUFBUTtBQUFNLGVBQVUsVUFBVSxLQUFLLEtBQUssUUFBTztBQUFFLFNBQUssS0FBSyxPQUFPO0FBQUEsRUFBRTtBQUFBLEVBQzFQLE9BQU07QUFBQyxRQUFHLEtBQUssUUFBUTtBQUFPLFNBQUssS0FBSyxTQUFPO0FBQU0sU0FBSyxNQUFNLFNBQU87QUFBTSxTQUFLLEtBQUssU0FBTztBQUFNLFNBQUssUUFBUSxPQUFLO0FBQUssU0FBSyxPQUFPO0FBQUEsRUFBRTtBQUFBLEVBQ3pJLE1BQU0sSUFBSSxPQUFvQixPQUFhLE1BQXVCO0FBR2hFLFVBQU0sSUFBSSxRQUFjLENBQUMsU0FBUSxXQUFTO0FBQ3hDLFlBQU0sU0FBTyxNQUFJO0FBQUMsYUFBSyxLQUFLLE9BQU8sTUFBTTtBQUFFLGVBQU8sSUFBSSxhQUFhLCtCQUE4QixZQUFZLENBQUM7QUFBQSxNQUFFO0FBQ2hILFlBQU0sU0FBTyxNQUFJO0FBQUMsYUFBSyxLQUFLLE9BQU8sTUFBTTtBQUFFLGdCQUFRO0FBQUEsTUFBRTtBQUFFLFdBQUssS0FBSyxJQUFJLE1BQU07QUFDM0UsWUFBTSxVQUFRLFlBQVM7QUFDckIsWUFBRyxLQUFLLFVBQVM7QUFBQyxpQkFBTztBQUFFO0FBQUEsUUFBTztBQUNsQyxrQkFBVSxRQUFNO0FBQU0sYUFBSyxXQUFTO0FBQU0sYUFBSyxVQUFRO0FBQUssYUFBSyxLQUFLLFNBQU87QUFBTSxhQUFLLE1BQU0sU0FBTztBQUFLLGFBQUssS0FBSyxTQUFPO0FBQUssYUFBSyxNQUFNLFNBQU87QUFBSyxhQUFLLFFBQVEsT0FBSztBQUFNLGFBQUssTUFBTSxjQUFZO0FBQU0sYUFBSyxPQUFPO0FBQUUsYUFBSyxRQUFNO0FBQ3JPLFlBQUc7QUFBQyxnQkFBTSxLQUFLO0FBQUUsZUFBSyxVQUFRO0FBQU0sZUFBSyxLQUFLLFNBQU87QUFBSyxpQkFBTztBQUFBLFFBQUUsU0FDN0QsT0FBTTtBQUFDLGNBQUcsS0FBSyxVQUFTO0FBQUMsbUJBQU87QUFBRTtBQUFBLFVBQU87QUFBQyxlQUFLLE1BQU0sY0FBWSxHQUFHLGFBQWEsU0FBUSxrQkFBa0IsQ0FBQyxHQUFHLGlCQUFpQixRQUFNLE1BQU0sVUFBUSxPQUFPLEtBQUssQ0FBQztBQUFHLGVBQUssTUFBTSxTQUFPO0FBQU0sZUFBSyxRQUFNLE1BQUksS0FBSyxRQUFRO0FBQUEsUUFBRTtBQUFBLE1BQ2xPO0FBQ0EsV0FBSyxRQUFRO0FBQUEsSUFDZixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBQ0EsVUFBVSxNQUFZO0FBQUMsU0FBSyxNQUFNLGNBQVk7QUFBQSxFQUFLO0FBQUEsRUFDM0MsU0FBUTtBQUNkLFFBQUcsS0FBSyxZQUFVLEtBQUssS0FBSyxPQUFPO0FBQ25DLFVBQU0sUUFBTSxVQUFVLFFBQVEsS0FBSyxRQUFRO0FBQUUsU0FBSyxNQUFNLGNBQVksS0FBSyxVQUFRLEdBQUcsYUFBYSxNQUFLLFVBQVUsQ0FBQyxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsS0FBRyxhQUFhLFFBQU8saUJBQWlCO0FBQ2hMLFFBQUcsTUFBTSxXQUFXLE1BQU0sVUFBUSxLQUFHLE1BQU0sUUFBUSxTQUFPLEVBQUUsTUFBSyxTQUFTLGdCQUFnQixPQUFPO0FBQUEsUUFBTyxNQUFLLFNBQVMsUUFBTSxNQUFNLFFBQU0sS0FBSyxJQUFJLEdBQUUsTUFBTSxTQUFPLE1BQU0sS0FBSyxJQUFFO0FBQzdLLFNBQUssUUFBUSxjQUFZLE1BQU0sUUFBUSxTQUFPLEdBQUcsYUFBYSxNQUFNLE1BQU0sQ0FBQyxNQUFNLE1BQU0sVUFBUSxhQUFhLFVBQVMsZUFBZSxJQUFFLGFBQWEsTUFBTSxLQUFLLENBQUMsTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLFFBQVEsTUFBTSxJQUFJLGFBQWEsS0FBSSxPQUFPLENBQUMsR0FBRyxNQUFNLFNBQU8sTUFBTSxhQUFhLE1BQUssUUFBUSxDQUFDLElBQUksYUFBYSxNQUFNLE1BQU0sQ0FBQyxLQUFHLEVBQUUsR0FBRyxNQUFNLFNBQU8sTUFBTSxNQUFNLE1BQU0sSUFBSSxhQUFhLE9BQU0sUUFBUSxDQUFDLEtBQUcsRUFBRSxLQUFHLGFBQWEsYUFBWSw0QkFBNEI7QUFDeGIsUUFBRyxDQUFDLEtBQUssUUFBUSxNQUFLLE1BQU0sY0FBWSxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsR0FBRyxLQUFLLFdBQVMsTUFBTSxLQUFLLFFBQVEsS0FBRyxFQUFFLE1BQU0sYUFBYSwwQkFBeUIsc0VBQXNFLENBQUM7QUFDM04sZUFBVSxVQUFVLEtBQUssS0FBSyxpQkFBaUIsUUFBUSxFQUFFLFFBQU8sYUFBYSxnQkFBZSxPQUFPLE9BQU8sUUFBUSxVQUFRLEtBQUssUUFBUSxDQUFDO0FBQ3hJLFFBQUcsQ0FBQyxLQUFLLFFBQVEsTUFBSztBQUFDLFdBQUssS0FBSyxnQkFBZ0I7QUFBRTtBQUFBLElBQU87QUFDMUQsVUFBTSxXQUFTLFNBQVMsdUJBQXVCO0FBQy9DLGVBQVUsU0FBUyxDQUFDLEdBQUcsTUFBTSxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUUsT0FBSyxFQUFFLFlBQVUsRUFBRSxXQUFTLEVBQUUsWUFBVSxFQUFFLE9BQU8sR0FBRTtBQUMvRixZQUFNLE1BQUksU0FBUyxjQUFjLEtBQUs7QUFBRSxVQUFJLFlBQVU7QUFDdEQsWUFBTSxRQUFNLFNBQVMsY0FBYyxNQUFNO0FBQUUsWUFBTSxjQUFZLE1BQU07QUFBTSxZQUFNLFFBQU0sTUFBTTtBQUMzRixZQUFNLE9BQUssU0FBUyxjQUFjLE1BQU07QUFBRSxXQUFLLGNBQVksTUFBTSxhQUFXLFNBQVUsR0FBRyxhQUFhLE1BQU0sTUFBTSxDQUFDLFNBQU8sYUFBYSxNQUFNLFFBQVE7QUFDckosWUFBTSxTQUFPLFNBQVMsY0FBYyxNQUFNO0FBQUUsYUFBTyxjQUFZLE1BQU0sVUFBUSxVQUFRLElBQUksTUFBTSxVQUFRLEtBQU0sUUFBUSxDQUFDLENBQUMsT0FBSyxNQUFNLFVBQVEsV0FBUyxNQUFNLFNBQU8sYUFBYSxNQUFLLFFBQVEsSUFBRSxHQUFHLGFBQWEsTUFBSyxTQUFTLENBQUMsSUFBSSxhQUFhLE1BQU0sTUFBTSxDQUFDO0FBQ3pQLFVBQUksT0FBTyxPQUFNLE1BQUssTUFBTTtBQUFFLGVBQVMsT0FBTyxHQUFHO0FBQUEsSUFDbkQ7QUFDQSxTQUFLLEtBQUssZ0JBQWdCLFFBQVE7QUFBQSxFQUNwQztBQUNGO0FBQ0EsSUFBSTtBQUNHLGdCQUFTLGdCQUFlO0FBQUMsU0FBTyxVQUFRLElBQUksY0FBYztBQUFFO0FBQzVELGdCQUFTLHVCQUFzQjtBQUFDLFNBQU8sUUFBUTtBQUFFLFVBQU07QUFBVTsiLCJuYW1lcyI6W119