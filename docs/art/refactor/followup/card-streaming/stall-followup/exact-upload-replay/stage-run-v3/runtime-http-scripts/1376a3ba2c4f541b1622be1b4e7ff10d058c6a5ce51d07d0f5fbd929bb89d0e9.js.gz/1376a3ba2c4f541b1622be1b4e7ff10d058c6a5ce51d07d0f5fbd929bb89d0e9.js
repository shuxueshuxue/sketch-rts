import { shipMotionLimits } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-handling.ts";
import { coursePerformance } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-wind.ts";
import { windAt } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/wind-field.ts";
import { detCos, detSin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/det-math.ts";
import { shipProfile } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { CELL_GROUND, isWalkable, sameGround, walkableGoal } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/terrain.ts";
import { convexHull, expandConvex, polygonPlanes, polygonRadius, polygonTouchesCell } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/navigation-math.ts";
import preparedMasks from "/@fs/tmp/sketch-queue-source-42bd/src/shared/generated/ship-navigation-masks.json?import";
import preparedMasks64 from "/@fs/tmp/sketch-queue-source-42bd/src/shared/generated/ship-navigation-masks-64.json?import";
import { buildNavigationMasks } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/navigation-masks.ts";
import { shipScale, DEFAULT_SHIP_SCALE } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { buildSeaPotential, seaPotentialAt } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-navigation-potential.ts";
function curvedSegment(from, to) {
  const curvature = to.curvature ?? 0;
  if (Math.abs(curvature) < 1e-9) return 0;
  const x = from.x + (detSin(to.heading) - detSin(from.heading)) / curvature;
  const y = from.y - (detCos(to.heading) - detCos(from.heading)) / curvature;
  return Math.hypot(x - to.x, y - to.y) < 1e-5 ? curvature : 0;
}
export function shipPoseAt(from, to, fraction) {
  const heading = from.heading + headingDifference(from.heading, to.heading) * fraction;
  if (to.pivot) {
    const lever = (from.x - to.pivot.x) * detCos(from.heading) + (from.y - to.pivot.y) * detSin(from.heading);
    return { x: to.pivot.x + lever * detCos(heading), y: to.pivot.y + lever * detSin(heading), heading };
  }
  const curvature = curvedSegment(from, to);
  if (curvature) return { x: from.x + (detSin(heading) - detSin(from.heading)) / curvature, y: from.y - (detCos(heading) - detCos(from.heading)) / curvature, heading };
  return { x: from.x + (to.x - from.x) * fraction, y: from.y + (to.y - from.y) * fraction, heading };
}
const waterFields = /* @__PURE__ */ new WeakMap();
function openWaterBox(map, left, top, right, bottom) {
  if (left < 0 || top < 0 || right > map.width || bottom > map.height)
    return false;
  const t = map.terrain;
  if (!t)
    return true;
  let field = waterFields.get(t);
  if (!field || field.cells !== t.cells || field.cols !== t.cols || field.rows !== t.rows) {
    const w2 = t.cols + 1, sums = new Uint32Array(w2 * (t.rows + 1));
    for (let y = 0; y < t.rows; y++) {
      let row = 0;
      for (let x = 0; x < t.cols; x++) {
        row += CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea ? 0 : 1;
        sums[(y + 1) * w2 + x + 1] = sums[y * w2 + x + 1] + row;
      }
    }
    field = { cells: t.cells, cols: t.cols, rows: t.rows, sums };
    waterFields.set(t, field);
  }
  const x0 = Math.max(0, Math.floor(left / t.cell)), y0 = Math.max(0, Math.floor(top / t.cell));
  const x1 = Math.min(t.cols, Math.ceil(right / t.cell)), y1 = Math.min(t.rows, Math.ceil(bottom / t.cell)), w = t.cols + 1, s = field.sums;
  return s[y1 * w + x1] - s[y0 * w + x1] - s[y1 * w + x0] + s[y0 * w + x0] === 0;
}
const DIRECTIONS = 8;
const ANGLE = Math.PI / 4;
const STEPS = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
export function headingDifference(from, to) {
  return ((to - from + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
}
function outline(hull, pose) {
  const c = detCos(pose.heading), s = detSin(pose.heading);
  return hull.map((p) => ({ x: pose.x + p.x * c - p.y * s, y: pose.y + p.x * s + p.y * c }));
}
function clearOutline(map, polygon) {
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (const point of polygon) {
    left = Math.min(left, point.x);
    right = Math.max(right, point.x);
    top = Math.min(top, point.y);
    bottom = Math.max(bottom, point.y);
  }
  if (left < -1e-7 || top < -1e-7 || right > map.width + 1e-7 || bottom > map.height + 1e-7)
    return false;
  const terrain = map.terrain;
  if (!terrain)
    return true;
  if (openWaterBox(map, left, top, right, bottom))
    return true;
  const cell = terrain.cell;
  let axes;
  for (let row = Math.floor(top / cell); row <= Math.floor((bottom - 1e-7) / cell); row++)
    for (let col = Math.floor(left / cell); col <= Math.floor((right - 1e-7) / cell); col++) {
      const char = col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows ? void 0 : terrain.cells[row * terrain.cols + col];
      if (!CELL_GROUND[char ?? "."]?.sea && polygonTouchesCell(axes ??= polygonPlanes(polygon), col * cell, row * cell, cell))
        return false;
    }
  return true;
}
export function hullFits(map, ship, pose = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }) {
  const profile = shipProfile(ship);
  return Boolean(profile && clearOutline(map, outline(profile.hull, pose)));
}
export function hullPassageClear(map, ship, from, to) {
  const hull = shipProfile(ship).hull;
  const turn = headingDifference(from.heading, to.heading);
  const curvature = curvedSegment(from, to);
  const hullRadius = polygonRadius(hull);
  const lever = to.pivot ? Math.hypot(from.x - to.pivot.x, from.y - to.pivot.y) : curvature ? 1 / Math.abs(curvature) : 0;
  const radius = hullRadius + lever;
  const pivotArc = !to.pivot || [0, 1].every((fraction) => {
    const at = shipPoseAt(from, to, fraction), endpoint = fraction ? to : from;
    return Math.hypot(at.x - endpoint.x, at.y - endpoint.y) < 1e-5;
  });
  const corridorRadius = pivotArc ? hullRadius + lever * turn * turn / 8 + (lever ? 1e-5 : 0) : radius;
  if (openWaterBox(map, Math.min(from.x, to.x) - corridorRadius, Math.min(from.y, to.y) - corridorRadius, Math.max(from.x, to.x) + corridorRadius, Math.max(from.y, to.y) + corridorRadius))
    return true;
  if (turn && (!hullFits(map, ship, from) || !hullFits(map, ship, to))) return false;
  const steps = Math.max(1, Math.ceil(Math.abs(turn) * Math.sqrt(radius / (8 * 0.025))));
  const error = turn ? radius * (turn / steps) ** 2 / 8 + 1e-7 : 0;
  for (let i = 0; i < steps; i++) {
    const a = shipPoseAt(from, to, i / steps);
    const b = shipPoseAt(from, to, (i + 1) / steps);
    const envelope = convexHull([...outline(hull, a), ...outline(hull, b)]);
    if (!clearOutline(map, error ? expandConvex(envelope, error) : envelope))
      return false;
  }
  return true;
}
export function hullStep(map, ship, point) {
  const from = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }, to = { ...point, heading: from.heading };
  if (hullPassageClear(map, ship, from, to))
    return point;
  let low = 0, high = 1;
  for (let i = 0; i < 12; i++) {
    const mid = (low + high) / 2;
    const at = { x: from.x + (to.x - from.x) * mid, y: from.y + (to.y - from.y) * mid, heading: from.heading };
    if (hullPassageClear(map, ship, from, at))
      low = mid;
    else
      high = mid;
  }
  return { x: from.x + (to.x - from.x) * low, y: from.y + (to.y - from.y) * low };
}
export function nearestShipPose(map, ship, point, seaOrigin = ship, accepts = () => true) {
  const preferred = ship.sailing?.heading ?? 0;
  const seaStart = isWalkable(map, seaOrigin.x, seaOrigin.y, "sea") ? seaOrigin : walkableGoal(map, seaOrigin.x, seaOrigin.y, "sea");
  const headings = [preferred, ...Array.from({ length: DIRECTIONS }, (_, i) => i * ANGLE)];
  if (!map.terrain) {
    const hull = outline(shipProfile(ship).hull, { x: 0, y: 0, heading: preferred });
    const x = Math.max(-Math.min(...hull.map((p) => p.x)), Math.min(map.width - Math.max(...hull.map((p) => p.x)), point.x));
    const y = Math.max(-Math.min(...hull.map((p) => p.y)), Math.min(map.height - Math.max(...hull.map((p) => p.y)), point.y));
    if (hullFits(map, ship, { x, y, heading: preferred }) && accepts({ x, y, heading: preferred })) return { x, y, heading: preferred };
    for (let distance = 16; distance <= shipProfile(ship).length * 4; distance += 16) for (let i = 0; i < 16; i++) {
      const angle = i * Math.PI / 8, at = { x: x + distance * detCos(angle), y: y + distance * detSin(angle), heading: preferred };
      if (hullFits(map, ship, at) && accepts(at)) return at;
    }
    return void 0;
  }
  for (const heading of headings)
    if (hullFits(map, ship, { ...point, heading }) && accepts({ ...point, heading }) && sameGround(map, seaStart, point, "sea"))
      return { ...point, heading };
  const t = map.terrain, col = Math.max(0, Math.min(t.cols - 1, Math.floor(point.x / t.cell))), row = Math.max(0, Math.min(t.rows - 1, Math.floor(point.y / t.cell)));
  for (let ring = 0; ring <= Math.max(t.cols, t.rows); ring++) {
    let best, score = Infinity;
    for (let y = Math.max(0, row - ring); y <= Math.min(t.rows - 1, row + ring); y++)
      for (let x = Math.max(0, col - ring); x <= Math.min(t.cols - 1, col + ring); x++) {
        if (ring && Math.max(Math.abs(x - col), Math.abs(y - row)) !== ring)
          continue;
        const at = { x: (x + 0.5) * t.cell, y: (y + 0.5) * t.cell };
        if (!CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea || !sameGround(map, seaStart, at, "sea"))
          continue;
        for (const heading of headings) {
          const value = Math.hypot(at.x - point.x, at.y - point.y) + Math.abs(headingDifference(preferred, heading)) * 1e-3;
          if (value < score && hullFits(map, ship, { ...at, heading }) && accepts({ ...at, heading })) {
            best = { ...at, heading };
            score = value;
          }
        }
      }
    if (best)
      return best;
  }
  return void 0;
}
const grids = /* @__PURE__ */ new WeakMap();
function createSearchWorkspace(size) {
  return {
    costs: new Float64Array(size),
    parents: new Int32Array(size),
    stamps: new Uint32Array(size),
    trafficFits: new Int32Array(size),
    basePotentials: new Float64Array(size / DIRECTIONS),
    baseStamps: new Uint32Array(size / DIRECTIONS),
    generation: 0
  };
}
let search = createSearchWorkspace(0);
function searchWorkspace(size, nested = false) {
  if (nested) {
    const workspace = createSearchWorkspace(size);
    workspace.generation = 1;
    return workspace;
  }
  if (search.costs.length < size)
    search = createSearchWorkspace(size);
  if (++search.generation === 2147483647) {
    search.stamps.fill(0);
    search.trafficFits.fill(0);
    search.baseStamps.fill(0);
    search.generation = 1;
  }
  return search;
}
const geometryMasks = /* @__PURE__ */ new Map();
function masksFor(ship, cell) {
  const profile = shipProfile(ship), key = `${ship.kind}:${profile.length}:${profile.beam}:${cell}`;
  const cached = geometryMasks.get(key);
  if (cached) return cached;
  const prepared = cell === 32 ? preparedMasks : cell === 64 ? preparedMasks64 : void 0;
  const masks = prepared && shipScale(ship) === DEFAULT_SHIP_SCALE ? prepared[ship.kind] : buildNavigationMasks(profile.hull, cell);
  if (geometryMasks.size >= 64) geometryMasks.delete(geometryMasks.keys().next().value);
  geometryMasks.set(key, masks);
  return masks;
}
function gridFor(map, ship) {
  const t = map.terrain, key = `${ship.kind}:${shipProfile(ship).length}:${map.width}:${map.height}:${t.cell}:${t.cols}:${t.rows}`;
  let group = grids.get(t);
  if (!group) {
    group = /* @__PURE__ */ new Map();
    grids.set(t, group);
  }
  let grid = group.get(key);
  if (!grid || grid.cells !== t.cells) {
    const cell = t.cell, cols = Math.ceil(map.width / cell), rows = Math.ceil(map.height / cell);
    const size = cols * rows * DIRECTIONS;
    const masks = masksFor(ship, t.cell);
    const water = new Uint8Array(cols * rows);
    for (let y = 0; y < Math.min(rows, t.rows) && (y + 0.5) * cell < map.height; y++)
      for (let x = 0; x < Math.min(cols, t.cols) && (x + 0.5) * cell < map.width; x++)
        water[y * cols + x] = CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea ? 1 : 0;
    grid = { cells: t.cells, cell, cols, rows, water, masks, fits: new Int8Array(size), turns: new Int8Array(size * 2), moves: new Int8Array(size * 4) };
    if (group.size >= 32)
      group.delete(group.keys().next().value);
    group.set(key, grid);
  }
  return grid;
}
function maskFits(map, grid, id, mask) {
  const tile = Math.floor(id / DIRECTIONS), col = tile % grid.cols, row = Math.floor(tile / grid.cols), x = col * grid.cell, y = row * grid.cell;
  const [left, top, right, bottom] = mask.bounds;
  if (x + left < -1e-7 || y + top < -1e-7 || x + right > map.width + 1e-7 || y + bottom > map.height + 1e-7)
    return false;
  if (openWaterBox(map, x + left, y + top, x + right, y + bottom))
    return true;
  const t = map.terrain;
  for (let i = 0; i < mask.cells.length; i += 2) {
    const xx = col + mask.cells[i], yy = row + mask.cells[i + 1];
    if (xx < 0 || yy < 0 || xx >= t.cols || yy >= t.rows || !CELL_GROUND[t.cells[yy * t.cols + xx] ?? "."]?.sea)
      return false;
  }
  return true;
}
class Frontier {
  length = 0;
  poppedCost = 0;
  ids = new Int32Array(1024);
  costs = new Float64Array(1024);
  scores = new Float64Array(1024);
  reset() {
    this.length = 0;
    if (this.ids.length > 65536) {
      this.ids = new Int32Array(65536);
      this.costs = new Float64Array(65536);
      this.scores = new Float64Array(65536);
    }
    return this;
  }
  save() {
    return Array.from({ length: this.length }, (_, i) => ({ id: this.ids[i], cost: this.costs[i], score: this.scores[i] }));
  }
  restore(slots) {
    this.reset();
    const capacity = Math.max(1024, 2 ** Math.ceil(Math.log2(Math.max(1, slots.length))));
    if (this.ids.length < capacity) {
      this.ids = new Int32Array(capacity);
      this.costs = new Float64Array(capacity);
      this.scores = new Float64Array(capacity);
    }
    this.length = slots.length;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      this.ids[i] = slot.id;
      this.costs[i] = slot.cost;
      this.scores[i] = slot.score;
    }
    return this;
  }
  push(id, cost, score) {
    if (this.length === this.ids.length) {
      const ids = new Int32Array(this.length * 2), costs = new Float64Array(this.length * 2), scores = new Float64Array(this.length * 2);
      ids.set(this.ids);
      costs.set(this.costs);
      scores.set(this.scores);
      this.ids = ids;
      this.costs = costs;
      this.scores = scores;
    }
    let i = this.length++;
    while (i) {
      const parent = i - 1 >>> 2;
      if (!this.less(score, id, this.scores[parent], this.ids[parent]))
        break;
      this.copy(parent, i);
      i = parent;
    }
    this.ids[i] = id;
    this.costs[i] = cost;
    this.scores[i] = score;
  }
  copy(from, to) {
    this.ids[to] = this.ids[from];
    this.costs[to] = this.costs[from];
    this.scores[to] = this.scores[from];
  }
  less(aScore, aId, bScore, bId) {
    return aScore < bScore || aScore === bScore && aId < bId;
  }
  pop() {
    const result = this.ids[0], last = --this.length;
    this.poppedCost = this.costs[0];
    const id = this.ids[last], cost = this.costs[last], score = this.scores[last];
    if (last) {
      let i = 0;
      while (i * 4 + 1 < last) {
        let child = i * 4 + 1;
        const end = Math.min(last, child + 4);
        for (let next = child + 1; next < end; next++)
          if (this.less(this.scores[next], this.ids[next], this.scores[child], this.ids[child]))
            child = next;
        if (!this.less(this.scores[child], this.ids[child], score, id))
          break;
        this.copy(child, i);
        i = child;
      }
      this.ids[i] = id;
      this.costs[i] = cost;
      this.scores[i] = score;
    }
    return result;
  }
}
const routeFrontier = new Frontier(), distanceFrontier = new Frontier();
const emptyTraffic = () => true;
const seaDistances = /* @__PURE__ */ new WeakMap();
function terrainDistances(map, grid, start, target, directionCosts) {
  const terrain = map.terrain, span = 16, blockX = Math.floor(target.x / (grid.cell * span)), blockY = Math.floor(target.y / (grid.cell * span));
  const fromX = Math.floor(start.x / (grid.cell * span)), fromY = Math.floor(start.y / (grid.cell * span));
  const key = `${map.width}:${map.height}:${grid.cell}:${grid.cols}:${grid.rows}:${fromX}:${fromY}:${blockX}:${blockY}:${directionCosts.join(":")}`;
  let group = seaDistances.get(terrain);
  if (!group) {
    group = /* @__PURE__ */ new Map();
    seaDistances.set(terrain, group);
  }
  const cached = group.get(key);
  if (cached?.cells === terrain.cells) return cached.field;
  const open = (x, y) => x >= 0 && y >= 0 && x < grid.cols && y < grid.rows && grid.water[y * grid.cols + x] === 1;
  const centerX = (blockX + 0.5) * span, centerY = (blockY + 0.5) * span;
  let seed = -1, seedGap = Infinity;
  for (let y = Math.max(0, blockY * span - 2); y < Math.min(grid.rows, (blockY + 1) * span + 2); y++)
    for (let x = Math.max(0, blockX * span - 2); x < Math.min(grid.cols, (blockX + 1) * span + 2); x++) {
      if (!open(x, y)) continue;
      const id = y * grid.cols + x, gap = (x + 0.5 - centerX) ** 2 + (y + 0.5 - centerY) ** 2;
      if (gap < seedGap) {
        seed = id;
        seedGap = gap;
      }
    }
  if (seed < 0) return void 0;
  const bounds = {
    left: Math.max(0, (Math.min(fromX, blockX) - 2) * span),
    top: Math.max(0, (Math.min(fromY, blockY) - 2) * span),
    right: Math.min(grid.cols, (Math.max(fromX, blockX) + 3) * span),
    bottom: Math.min(grid.rows, (Math.max(fromY, blockY) + 3) * span)
  };
  const field = buildSeaPotential(
    grid.water,
    grid.cols,
    grid.rows,
    grid.cell,
    bounds,
    { x: seed % grid.cols, y: Math.floor(seed / grid.cols) },
    directionCosts,
    distanceFrontier
  );
  if (group.size >= 8 && !group.has(key)) group.delete(group.keys().next().value);
  group.set(key, { cells: terrain.cells, field });
  return field;
}
function routeTime(map, ship, from, points) {
  const limits = shipMotionLimits(ship);
  let time = 0, previous = from;
  for (const point of points) {
    const yaw = Math.abs(headingDifference(previous.heading, point.heading));
    const dx = point.x - previous.x, dy = point.y - previous.y;
    const performance = coursePerformance(ship, map, point.heading, { assumeTrimmed: true });
    const speed = dx * detCos(point.heading) + dy * detSin(point.heading) < -1e-7 ? Math.min(limits.reverseSpeed, performance.auxiliarySpeed) : Math.max(performance.targetSpeed, performance.auxiliarySpeed);
    time += yaw / Math.max(1e-6, limits.turnRate) + Math.hypot(dx, dy) / Math.max(1e-6, speed);
    previous = point;
  }
  return time;
}
function keelCandidates(ship, from, goal) {
  const gap = Math.hypot(goal.x - from.x, goal.y - from.y);
  if (gap < 1e-7) return [goal.heading === void 0 || Math.abs(headingDifference(from.heading, goal.heading)) < 1e-7 ? [] : [{ ...goal, heading: goal.heading }]];
  const direction = Math.atan2(goal.y - from.y, goal.x - from.x);
  const length = shipProfile(ship).length;
  const headings = gap <= (goal.heading !== void 0 ? length : length / 2) ? [direction, direction + Math.PI] : [direction];
  return headings.map((heading) => {
    const turned = { x: from.x, y: from.y, heading }, end = { x: goal.x, y: goal.y, heading };
    const points = Math.abs(headingDifference(from.heading, heading)) < 1e-7 ? [end] : [turned, end];
    if (goal.heading !== void 0 && Math.abs(headingDifference(heading, goal.heading)) > 1e-7) points.push({ ...end, heading: goal.heading });
    return points;
  });
}
function connectorClear(map, ship, from, points, traffic) {
  return points.every((point, i) => {
    const previous = points[i - 1] ?? from;
    return hullPassageClear(map, ship, previous, point) && traffic(previous, point);
  });
}
function keelConnector(map, ship, from, goal, traffic) {
  return keelCandidates(ship, from, goal).sort((a, b) => routeTime(map, ship, from, a) - routeTime(map, ship, from, b)).find((points) => connectorClear(map, ship, from, points, traffic));
}
export function shipTackRoute(map, ship, goal, traffic, preferredHeading) {
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  const dx = goal.x - start.x, dy = goal.y - start.y, gap = Math.hypot(dx, dy), length = shipProfile(ship).length;
  const performance = coursePerformance(ship, map, Math.atan2(dy, dx), { assumeTrimmed: true });
  if (gap < length || performance.calm || performance.trueWindAngle >= performance.beatAngle || !performance.noGo && performance.targetSpeed >= performance.auxiliarySpeed || performance.maxForwardSpeed <= 0) return;
  const wind = windAt(map, ship), angles = [wind.from + performance.beatAngle, wind.from - performance.beatAngle];
  const directions = angles.map((heading) => ({ x: detCos(heading), y: detSin(heading) }));
  const cross = (a, b) => a.x * b.y - a.y * b.x;
  const preferred = preferredHeading ?? start.heading;
  const sides = [0, 1].sort((a, b) => Math.abs(headingDifference(preferred, angles[a])) - Math.abs(headingDifference(preferred, angles[b])));
  const distances = [gap];
  for (let distance = gap / 2; distance >= length; distance /= 2) distances.push(distance);
  if (distances.at(-1) > length + 1e-7) distances.push(length);
  const choices = preferredHeading === void 0 ? distances.flatMap((distance) => sides.map((side) => ({ distance, side }))) : sides.flatMap((side) => distances.map((distance) => ({ distance, side })));
  if (shipMotionLimits(ship).turnRate <= 1e-7) return;
  for (const { distance, side } of choices) {
    const end = { x: start.x + dx * distance / gap, y: start.y + dy * distance / gap };
    const other = 1 - side, a = directions[side], b = directions[other], det = cross(a, b);
    let best, bestCost = Infinity;
    const startingTurn = Math.abs(headingDifference(start.heading, angles[side])) > 1e-7;
    for (const startupRadius of startingTurn ? departureRadii(map, ship) : [voyageTurnRadius(ship)]) for (const radius of voyageRadii(ship)) {
      const speedLimit = curveSpeedLimit(ship, radius), startupSpeed = curveSpeedLimit(ship, startupRadius);
      const lead = startingTurn ? brakingEntry(ship, start, startupSpeed) : [];
      const startup = circleArc(lead.at(-1) ?? start, angles[side], startupRadius, startupSpeed);
      const sailed = startup.at(-1) ?? lead.at(-1) ?? start;
      const delta = { x: end.x - sailed.x, y: end.y - sailed.y };
      const first = cross(delta, b) / det, second = cross(a, delta) / det;
      const turn = headingDifference(angles[side], angles[other]);
      const setback = radius * Math.tan(Math.abs(turn) / 2);
      if (first <= setback + 1 || second <= setback + 1) continue;
      const entry = { x: sailed.x + a.x * (first - setback), y: sailed.y + a.y * (first - setback), heading: angles[side], curvature: 0, speedLimit };
      const tack = circleArc(entry, angles[other], radius, speedLimit);
      const finish = { ...end, heading: angles[other], curvature: 0 };
      const points = [...lead, ...startup, entry, ...tack, finish].map((point) => ({ ...point, tack: true }));
      const cost = voyageTime(map, ship, start, points);
      if (cost >= bestCost || !voyageCorridorClear(map, ship, start, points, traffic)) continue;
      best = points;
      bestCost = cost;
    }
    if (best) return best;
  }
}
export function planBeatDeparture(map, ship, goal, traffic, preferredHeading) {
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  const bearing = Math.atan2(goal.y - start.y, goal.x - start.x), performance = coursePerformance(ship, map, bearing, { assumeTrimmed: true });
  if (performance.calm || performance.trueWindAngle >= performance.beatAngle || shipMotionLimits(ship).turnRate <= 1e-7 || performance.maxForwardSpeed <= 0) return;
  const wind = windAt(map, ship), angles = [wind.from + performance.beatAngle, wind.from - performance.beatAngle];
  const useful = angles.filter((heading) => {
    const drive = coursePerformance(ship, map, heading, { assumeTrimmed: true }).targetSpeed;
    return drive * detCos(headingDifference(heading, bearing)) > Math.max(performance.targetSpeed, performance.auxiliarySpeed) * 1.1;
  });
  const preferred = preferredHeading ?? start.heading;
  useful.sort((a, b) => Math.abs(headingDifference(preferred, a)) - Math.abs(headingDifference(preferred, b)));
  const length = shipProfile(ship).length * 2;
  for (const heading of useful) {
    let best, bestCost = Infinity;
    for (const radius of departureRadii(map, ship)) {
      const speedLimit = curveSpeedLimit(ship, radius), lead = Math.abs(headingDifference(start.heading, heading)) > 1e-7 ? brakingEntry(ship, start, speedLimit) : [];
      const arc = circleArc(lead.at(-1) ?? start, heading, radius, speedLimit), entry = arc.at(-1) ?? lead.at(-1) ?? start;
      const finish = { x: entry.x + length * detCos(heading), y: entry.y + length * detSin(heading), heading, curvature: 0 };
      const points = [...lead, ...arc, finish].map((point) => ({ ...point, tack: true })), cost = voyageTime(map, ship, start, points);
      if (cost >= bestCost || !voyageCorridorClear(map, ship, start, points, traffic)) continue;
      best = points;
      bestCost = cost;
    }
    if (best) return best;
  }
}
function departureRoute(map, ship, goal, traffic, latticeEscape = false) {
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }, length = shipProfile(ship).length;
  const desired = Math.atan2(goal.y - start.y, goal.x - start.x);
  const differences = [headingDifference(start.heading, desired), headingDifference(start.heading, desired + Math.PI)];
  for (const difference of differences) for (const lever of [length / 2, -length / 2]) {
    if (Math.abs(difference) < 1e-7) continue;
    const angle = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, difference));
    const pivot = { x: start.x - lever * detCos(start.heading), y: start.y - lever * detSin(start.heading) };
    const heading = start.heading + angle, end = { x: pivot.x + lever * detCos(heading), y: pivot.y + lever * detSin(heading), heading, pivot };
    if (hullPassageClear(map, ship, start, end) && traffic(start, end)) return [end];
  }
  let escape;
  for (const direction of [1, -1]) for (let distance = map.terrain.cell; distance <= length * 4; distance += map.terrain.cell) {
    const end = { x: start.x + direction * distance * detCos(start.heading), y: start.y + direction * distance * detSin(start.heading), heading: start.heading };
    if (!hullPassageClear(map, ship, start, end) || !traffic(start, end)) break;
    if (keelConnector(map, ship, end, goal, traffic)) return [end];
    if (latticeEscape && !escape) {
      const cell = map.terrain.cell, col = Math.floor(end.x / cell), row = Math.floor(end.y / cell);
      for (let y = row - 1; y <= row + 1 && !escape; y++) for (let x = col - 1; x <= col + 1 && !escape; x++) for (let h = 0; h < DIRECTIONS; h++) {
        const entrance = { x: (x + 0.5) * cell, y: (y + 0.5) * cell, heading: h * ANGLE };
        if (hullFits(map, ship, entrance) && keelConnector(map, ship, end, entrance, traffic)) {
          escape = end;
          break;
        }
      }
    }
  }
  if (escape) return [{ ...escape, exact: true }];
}
function arrivalConnectorFor(map, ship, goal, traffic) {
  const length = shipProfile(ship).length;
  const arcs = [];
  for (const angle of [Math.PI / 4, -Math.PI / 4, Math.PI / 2, -Math.PI / 2]) for (const lever of [length / 2, -length / 2]) {
    const pivot = { x: goal.x - lever * detCos(goal.heading), y: goal.y - lever * detSin(goal.heading) }, heading = goal.heading - angle;
    const stage = { x: pivot.x + lever * detCos(heading), y: pivot.y + lever * detSin(heading), heading }, end = { ...goal, pivot };
    if (!hullFits(map, ship, stage) || !traffic(stage, stage)) continue;
    if (!hullPassageClear(map, ship, stage, end) || !traffic(stage, end)) continue;
    arcs.push({ stage, end, angle });
  }
  return (from) => {
    let best, bestCost = Infinity;
    for (const { stage, end, angle } of arcs) {
      const connection = keelConnector(map, ship, from, stage, traffic);
      if (!connection) continue;
      const last = connection.at(-1) ?? from;
      if (!hullPassageClear(map, ship, last, stage) || !traffic(last, stage)) continue;
      const cost = routeTime(map, ship, from, [...connection, ...Math.abs(headingDifference(last.heading, stage.heading)) > 1e-7 ? [stage] : [], end]);
      if (cost >= bestCost) continue;
      bestCost = cost;
      best = [...connection, ...Math.abs(headingDifference(last.heading, stage.heading)) > 1e-7 ? [stage] : [], end];
    }
    return best;
  };
}
export function shipRoute(map, ship, goal, trafficClear = emptyTraffic) {
  return planShipRoute(map, ship, goal, trafficClear).points;
}
export function voyageTurnRadius(ship) {
  const limits = shipMotionLimits(ship), length = shipProfile(ship).length;
  return Math.max(length * 0.65, limits.turnRate > 1e-7 ? limits.speed / limits.turnRate : 0);
}
function voyageRadii(ship) {
  const minimum = shipProfile(ship).length * 0.65, nominal = voyageTurnRadius(ship);
  return [.../* @__PURE__ */ new Set([nominal, Math.max(minimum, nominal * 0.7), minimum])];
}
function queuedVoyageRadii(ship) {
  const length = shipProfile(ship).length;
  return [.../* @__PURE__ */ new Set([...voyageRadii(ship).map((radius) => Math.max(length, radius)), length * 0.45])];
}
function departureRadii(map, ship) {
  const limits = shipMotionLimits(ship), auxiliary = coursePerformance(ship, map).auxiliarySpeed;
  const assisted = Math.max(shipProfile(ship).length * 0.2, auxiliary / Math.max(1e-7, limits.turnRate));
  return [.../* @__PURE__ */ new Set([...voyageRadii(ship), assisted])];
}
function curveSpeedLimit(ship, radius) {
  return Math.min(shipMotionLimits(ship).speed, radius * shipMotionLimits(ship).turnRate * 0.85);
}
function circleArc(from, heading, radius, speedLimit) {
  const turn = headingDifference(from.heading, heading);
  return signedCircleArc(from, turn, radius, speedLimit);
}
function signedCircleArc(from, turn, radius, speedLimit) {
  if (Math.abs(turn) < 1e-7) return [];
  const curvature = Math.sign(turn) / radius, count = Math.max(1, Math.ceil(Math.abs(turn) / (Math.PI / 36)));
  const points = [];
  for (let i = 1; i <= count; i++) {
    const heading = from.heading + turn * i / count;
    points.push({
      x: from.x + (detSin(heading) - detSin(from.heading)) / curvature,
      y: from.y - (detCos(heading) - detCos(from.heading)) / curvature,
      heading,
      curvature,
      speedLimit
    });
  }
  return points;
}
function brakingEntry(ship, from, speedLimit) {
  const speed = Math.max(0, ship.sailing?.speed ?? 0), acceleration = shipMotionLimits(ship).acceleration;
  const distance = Math.max(0, (speed * speed - speedLimit * speedLimit) / (2 * Math.max(1e-6, acceleration)));
  return distance < 1e-7 ? [] : [{ x: from.x + distance * detCos(from.heading), y: from.y + distance * detSin(from.heading), heading: from.heading, curvature: 0, speedLimit }];
}
function voyageTime(map, ship, from, points) {
  const acceleration = Math.max(1e-6, shipMotionLimits(ship).acceleration);
  let time = 0, speed = Math.max(0, ship.sailing?.speed ?? 0), previous = from;
  for (const point of points) {
    const yaw = Math.abs(headingDifference(previous.heading, point.heading));
    const distance = point.curvature ? yaw / Math.abs(point.curvature) : Math.hypot(point.x - previous.x, point.y - previous.y);
    const performance = coursePerformance(ship, map, previous.heading + headingDifference(previous.heading, point.heading) / 2, { assumeTrimmed: true });
    const cap = Math.min(Math.max(performance.targetSpeed, performance.auxiliarySpeed), point.speedLimit ?? Infinity);
    const changingDistance = Math.abs(cap * cap - speed * speed) / (2 * acceleration);
    if (distance <= changingDistance) {
      const endSpeed = Math.sqrt(Math.max(0, speed * speed + Math.sign(cap - speed) * 2 * acceleration * distance));
      time += Math.abs(endSpeed - speed) / acceleration;
      speed = endSpeed;
    } else {
      time += Math.abs(cap - speed) / acceleration + (distance - changingDistance) / Math.max(1e-6, cap);
      speed = cap;
    }
    previous = point;
  }
  return time;
}
const positiveAngle = (angle) => (angle % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
function voyageLength(from, points) {
  let distance = 0, previous = from;
  for (const point of points) {
    distance += Math.hypot(point.x - previous.x, point.y - previous.y);
    previous = point;
  }
  return distance;
}
function voyageCorridorClear(map, ship, from, points, traffic) {
  if (!connectorClear(map, ship, from, points, traffic)) return false;
  const margin = shipProfile(ship).length * 0.1;
  for (const side of [-1, 1]) {
    const offset = (point) => ({
      ...point,
      x: point.x - side * margin * detSin(point.heading),
      y: point.y + side * margin * detCos(point.heading),
      ...point.curvature ? { curvature: point.curvature / (1 - side * margin * point.curvature) } : {}
    });
    if (!connectorClear(map, ship, offset(from), points.map(offset), traffic)) return false;
  }
  return true;
}
export function roundVoyageCorner(map, ship, from, corner, next, traffic = () => true) {
  const incoming = Math.atan2(corner.y - from.y, corner.x - from.x), outgoing = Math.atan2(next.y - corner.y, next.x - corner.x);
  const turn = headingDifference(incoming, outgoing), before = Math.hypot(corner.x - from.x, corner.y - from.y), after = Math.hypot(next.x - corner.x, next.y - corner.y);
  if (Math.abs(headingDifference(from.heading, incoming)) > 0.01 || Math.abs(turn) < 0.01 || Math.abs(turn) > Math.PI - 0.1 || shipMotionLimits(ship).turnRate <= 1e-7) return;
  let best, bestCost = Infinity;
  for (const radius of queuedVoyageRadii(ship)) {
    if (best && radius < shipProfile(ship).length * 0.65) continue;
    const setback = radius * Math.tan(Math.abs(turn) / 2), speedLimit = curveSpeedLimit(ship, radius);
    const braking = brakingEntry(ship, from, speedLimit), brakingLength = braking.length ? Math.hypot(braking[0].x - from.x, braking[0].y - from.y) : 0;
    if (setback + brakingLength + 1 >= before || setback + 1 >= after) continue;
    const entry = { x: corner.x - setback * detCos(incoming), y: corner.y - setback * detSin(incoming), heading: incoming, curvature: 0, speedLimit };
    const points = [entry, ...circleArc(entry, outgoing, radius, speedLimit), { ...next, heading: outgoing, curvature: 0 }];
    const cost = voyageTime(map, ship, from, points);
    if (cost >= bestCost || !voyageCorridorClear(map, ship, from, points, traffic)) continue;
    best = points;
    bestCost = cost;
  }
  return best;
}
function forwardConnector(map, ship, from, goal, traffic, next, lengthLimit) {
  const dx = goal.x - from.x, dy = goal.y - from.y, gap = Math.hypot(dx, dy);
  if (gap < 1e-7) return [];
  const direction = Math.atan2(dy, dx), error = headingDifference(from.heading, direction);
  if (Math.abs(error) < 1e-7) {
    const direct = [{ ...goal, heading: from.heading }];
    return connectorClear(map, ship, from, direct, traffic) ? direct : void 0;
  }
  if (shipMotionLimits(ship).turnRate <= 1e-7) return;
  let best, bestCost = Infinity, bestCanRound = false;
  for (const radius of next ? queuedVoyageRadii(ship) : voyageRadii(ship)) {
    if (bestCanRound && radius < shipProfile(ship).length * 0.65) continue;
    const speedLimit = curveSpeedLimit(ship, radius), lead = brakingEntry(ship, from, speedLimit), entry = lead.at(-1) ?? from;
    for (const side of [error < 0 ? -1 : 1, error < 0 ? 1 : -1]) {
      const center = { x: entry.x - side * radius * detSin(entry.heading), y: entry.y + side * radius * detCos(entry.heading) };
      const gx = goal.x - center.x, gy = goal.y - center.y, distance = Math.hypot(gx, gy);
      if (distance < radius + 1e-7) continue;
      const radial = Math.atan2(gy, gx) - side * Math.acos(Math.min(1, radius / distance));
      const heading = radial + side * Math.PI / 2, turn = positiveAngle(side * headingDifference(from.heading, heading));
      if (turn > Math.PI * 1.5) continue;
      const points = [...lead, ...signedCircleArc(entry, side * turn, radius, speedLimit)];
      const tangent = points.at(-1);
      const canRound = !next || !!roundVoyageCorner(map, { ...ship, sailing: { ...ship.sailing, speed: speedLimit } }, tangent, goal, next, traffic);
      if (Math.hypot(goal.x - tangent.x, goal.y - tangent.y) > 1e-7) points.push({ ...goal, heading: tangent.heading, curvature: 0 });
      if (lengthLimit !== void 0 && voyageLength(from, points) > lengthLimit) continue;
      const cost = voyageTime(map, ship, from, points);
      if (bestCanRound && !canRound || bestCanRound === canRound && cost >= bestCost - 1e-7 || !voyageCorridorClear(map, ship, from, points, traffic)) continue;
      best = points;
      bestCost = cost;
      bestCanRound = canRound;
    }
  }
  return best;
}
export function beginVoyageRefinement(from, points) {
  const result = [];
  for (; ; ) {
    let previous = from, maneuver = -1;
    for (let i = 0; i < points.length; i++) {
      const point = points[i];
      if (point.pivot || (point.x - previous.x) * detCos(point.heading) + (point.y - previous.y) * detSin(point.heading) < -1e-5) {
        maneuver = i;
        break;
      }
      previous = point;
    }
    if (maneuver >= 0) {
      while (maneuver + 1 < points.length) {
        const point = points[maneuver + 1], prior = points[maneuver];
        if (!point.pivot && Math.hypot(point.x - prior.x, point.y - prior.y) > 1e-7 && (point.x - prior.x) * detCos(point.heading) + (point.y - prior.y) * detSin(point.heading) >= -1e-5) break;
        maneuver++;
      }
      const prefix = points.slice(0, maneuver + 1).map((point) => ({ ...point, exact: true }));
      result.push(...prefix);
      from = points[maneuver];
      points = points.slice(maneuver + 1);
      continue;
    }
    const corners = points.filter((point, i) => {
      const a = points[i - 1] ?? from, b = points[i + 1];
      return !b || Math.abs(headingDifference(a.heading, point.heading)) > 1e-7 || Math.abs(headingDifference(point.heading, b.heading)) > 1e-7 || Math.hypot(point.x - a.x, point.y - a.y) < 1e-7 || Math.hypot(b.x - point.x, b.y - point.y) < 1e-7;
    });
    return { cursor: from, corners, result, index: 0, candidate: corners.length - 1 };
  }
}
export function advanceVoyageRefinement(map, ship, state, traffic, attempts = Infinity) {
  let tried = 0;
  while (state.index < state.corners.length) {
    if (state.candidate < state.index) {
      state.cursor = state.corners[state.index++];
      state.result.push({ ...state.cursor, exact: true });
      state.candidate = state.corners.length - 1;
      continue;
    }
    const goal = state.corners[state.candidate];
    if (Math.hypot(goal.x - state.cursor.x, goal.y - state.cursor.y) < shipProfile(ship).length * 0.5) {
      state.candidate--;
      continue;
    }
    if (tried++ >= attempts) return false;
    const lengthLimit = voyageLength(state.cursor, state.corners.slice(state.index, state.candidate + 1)) * 1.1;
    const candidate = forwardConnector(map, ship, state.cursor, goal, traffic, void 0, lengthLimit);
    const following = state.corners[state.candidate + 1];
    if (!candidate || voyageLength(state.cursor, candidate) > lengthLimit || following && !connectorClear(map, ship, candidate.at(-1), [following], traffic)) {
      state.candidate--;
      continue;
    }
    state.result.push(...candidate);
    state.cursor = candidate.at(-1);
    state.index = state.candidate + 1;
    state.candidate = state.corners.length - 1;
  }
  return true;
}
function simplifyVoyageReference(map, ship, from, points, traffic) {
  const state = beginVoyageRefinement(from, points);
  advanceVoyageRefinement(map, ship, state, traffic);
  return state.result;
}
export function planVoyageRoute(map, ship, goal, trafficClear = emptyTraffic, budget = Infinity) {
  const from = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  if (goal.heading !== void 0 || Math.hypot(goal.x - from.x, goal.y - from.y) <= shipProfile(ship).length * 0.5)
    return planShipRoute(map, ship, goal, trafficClear, budget);
  const direct = planDirectVoyage(map, ship, goal, trafficClear);
  if (direct) return { points: direct, partial: false };
  const reference = planShipRoute(map, ship, goal, trafficClear, budget, true);
  return { points: simplifyVoyageReference(map, ship, from, reference.points, trafficClear), partial: reference.partial };
}
export function planDirectVoyage(map, ship, goal, traffic) {
  const from = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  const queued = ship.orderQueue?.[0], current = ship.order;
  const next = current.type === "move" && current.heading === void 0 && current.rendezvousFor === void 0 && current.deckPoint === void 0 && current.deckShipId === void 0 && current.x === goal.x && current.y === goal.y && queued?.type === "move" && queued.heading === void 0 && queued.rendezvousFor === void 0 && queued.deckPoint === void 0 && queued.deckShipId === void 0 && !!queued.avoidCombat === !!current.avoidCombat && !coursePerformance(ship, map, Math.atan2(queued.y - goal.y, queued.x - goal.x), { assumeTrimmed: true }).noGo ? queued : void 0;
  return forwardConnector(map, ship, from, goal, traffic, next);
}
let routeSearchDepth = 0;
export function planShipRoute(map, ship, goal, trafficClear = emptyTraffic, budget = Infinity, voyage = false) {
  routeSearchDepth++;
  try {
    return planShipRouteImpl(map, ship, goal, trafficClear, budget, voyage, routeSearchDepth > 1);
  } finally {
    routeSearchDepth--;
  }
}
export function advanceShipRouteSearch(map, ship, goal, trafficClear, budget, voyage, state) {
  if (state.phase === "done") return state.result;
  if (state.phase === "fallback") {
    const unobstructed = advanceShipRouteSearch(map, ship, goal, emptyTraffic, Infinity, voyage, state.fallback);
    if (!unobstructed) return;
    const end = state.path.at(-1) ?? ship, possible = unobstructed.points.at(-1) ?? ship;
    state.result = { points: state.path, partial: !!state.deferred || unobstructed.partial || Math.hypot(end.x - possible.x, end.y - possible.y) > 1e-7 };
    state.phase = "done";
    return state.result;
  }
  routeSearchDepth++;
  try {
    const result = planShipRouteImpl(map, ship, goal, trafficClear, budget, voyage, routeSearchDepth > 1, state);
    if (result) {
      state.result = result;
      state.phase = "done";
    }
    return result;
  } finally {
    routeSearchDepth--;
  }
}
function planShipRouteImpl(map, ship, goal, trafficClear, budget, voyage, nested, state) {
  const noTraffic = trafficClear === emptyTraffic || trafficClear.hasTraffic === false;
  const originalTraffic = trafficClear;
  let trafficBlocked = state?.trafficBlocked ?? false;
  trafficClear = noTraffic ? emptyTraffic : (from, to) => {
    const clear = originalTraffic(from, to);
    trafficBlocked ||= !clear;
    return clear;
  };
  const t = map.terrain;
  if (!t)
    return { points: [{ ...goal, heading: Math.round(Math.atan2(goal.y - ship.y, goal.x - ship.x) * 1e9) / 1e9 }], partial: false };
  const grid = gridFor(map, ship), size = grid.fits.length;
  const limits = shipMotionLimits(ship), cruise = Math.max(1e-6, coursePerformance(ship, map, 0, { assumeTrimmed: true }).maxForwardSpeed), turnSpeed = Math.max(1e-6, limits.turnRate);
  const courseSpeeds = Array.from({ length: DIRECTIONS }, (_, h) => {
    const performance = coursePerformance(ship, map, h * ANGLE, { assumeTrimmed: true });
    return { forward: Math.max(performance.targetSpeed, performance.auxiliarySpeed), reverse: Math.min(limits.reverseSpeed, performance.auxiliarySpeed) };
  });
  const edgeWeights = courseSpeeds.map((performance, h) => {
    const [dx, dy] = STEPS[h], distance = grid.cell * (dx && dy ? Math.SQRT2 : 1);
    return { forward: distance / Math.max(1e-6, performance.forward), reverse: distance / Math.max(1e-6, performance.reverse) };
  });
  const lattice = grid;
  const pose = (id) => {
    const cell = Math.floor(id / DIRECTIONS);
    return { x: (cell % lattice.cols + 0.5) * lattice.cell, y: (Math.floor(cell / lattice.cols) + 0.5) * lattice.cell, heading: id % DIRECTIONS * ANGLE };
  };
  const savedTraffic = new Map(state?.trafficFits?.map((entry) => [entry.id, entry.clear]));
  const fits = (id) => {
    if (!grid.fits[id])
      grid.fits[id] = maskFits(map, grid, id, grid.masks[id % DIRECTIONS][0]) ? 1 : -1;
    if (grid.fits[id] !== 1) return false;
    if (noTraffic) return true;
    if (trafficFits[id] !== generation && trafficFits[id] !== -generation) {
      const at = pose(id);
      const clear = trafficClear(at, at);
      trafficFits[id] = clear ? generation : -generation;
      if (state) savedTraffic.set(id, clear);
    }
    return trafficFits[id] === generation;
  };
  const requested = goal.heading === void 0 ? void 0 : { x: goal.x, y: goal.y, heading: goal.heading };
  let preparedTarget = state?.target, deferred = state?.deferred ?? false;
  const length = shipProfile(ship).length;
  const start = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 };
  if (!preparedTarget) {
    const terrainTarget = requested && hullFits(map, ship, requested) ? requested : nearestShipPose(map, ship, goal);
    preparedTarget = terrainTarget && trafficClear(terrainTarget, terrainTarget) ? terrainTarget : nearestShipPose(map, ship, goal, ship, (pose2) => trafficClear(pose2, pose2));
    const target2 = preparedTarget;
    deferred = !!terrainTarget && (!target2 || Math.hypot(target2.x - terrainTarget.x, target2.y - terrainTarget.y) > 1e-7 || goal.heading !== void 0 && Math.abs(headingDifference(target2.heading, terrainTarget.heading)) > 1e-7);
    if (!target2) return { points: [], partial: deferred };
    const destination2 = requested ? target2 : { x: target2.x, y: target2.y };
    const direct = keelConnector(map, ship, start, destination2, trafficClear);
    if (direct) return { points: direct.filter((point, i) => i !== 0 || Math.hypot(point.x - start.x, point.y - start.y) > 1e-7 || Math.abs(headingDifference(start.heading, point.heading)) > 1e-7 || direct.length === 1), partial: deferred };
    const arrival = arrivalConnectorFor(map, ship, target2, trafficClear)(start);
    if (arrival) return { points: arrival, partial: deferred };
    const direction = Math.atan2(target2.y - start.y, target2.x - start.x);
    if ([direction, direction + Math.PI].every((heading) => !hullPassageClear(map, ship, start, { ...start, heading }) || !trafficClear(start, { ...start, heading }))) {
      const departure = departureRoute(map, ship, target2, trafficClear);
      if (departure) return { points: departure, partial: true };
    }
    if (state) {
      state.target = target2;
      state.deferred = deferred;
      state.trafficBlocked = trafficBlocked;
      state.phase = "entrance";
      return;
    }
  }
  const target = preparedTarget;
  const destination = requested ? target : { x: target.x, y: target.y };
  const arrive = arrivalConnectorFor(map, ship, target, trafficClear);
  const workspace = searchWorkspace(size, nested), {
    costs,
    parents: previous,
    stamps,
    trafficFits,
    basePotentials,
    baseStamps,
    generation
  } = workspace, frontier = nested ? new Frontier() : routeFrontier.reset();
  const useDistances = voyage && !Number.isFinite(budget) && lattice.cols * lattice.rows <= 262144 && Math.hypot(target.x - start.x, target.y - start.y) > lattice.cell * 24 && !openWaterBox(
    map,
    Math.min(start.x, target.x) - lattice.cell / 2,
    Math.min(start.y, target.y) - lattice.cell / 2,
    Math.max(start.x, target.x) + lattice.cell / 2,
    Math.max(start.y, target.y) + lattice.cell / 2
  );
  const directionCosts = courseSpeeds.map((performance, h) => cruise / Math.max(1e-6, performance.forward, courseSpeeds[(h + 4) % DIRECTIONS].reverse));
  const distances = useDistances ? terrainDistances(map, grid, start, target, directionCosts) : void 0;
  const targetCol = Math.floor(target.x / lattice.cell), targetRow = Math.floor(target.y / lattice.cell);
  let terminalPotential = 0;
  if (distances) {
    for (let y = Math.max(0, targetRow - 2); y <= Math.min(lattice.rows - 1, targetRow + 2); y++)
      for (let x = Math.max(0, targetCol - 2); x <= Math.min(lattice.cols - 1, targetCol + 2); x++)
        if (grid.water[y * grid.cols + x] === 1 && Math.hypot((x + 0.5) * lattice.cell - target.x, (y + 0.5) * lattice.cell - target.y) <= lattice.cell * 1.5)
          terminalPotential = Math.max(terminalPotential, seaPotentialAt(distances, x, y));
  }
  const basePotential = (tile, x, y) => {
    if (baseStamps[tile] === generation) return basePotentials[tile];
    const distance = distances ? seaPotentialAt(distances, tile % lattice.cols, Math.floor(tile / lattice.cols)) : 0;
    const lowerBound = distance - terminalPotential;
    baseStamps[tile] = generation;
    return basePotentials[tile] = Math.max(Math.hypot(x - target.x, y - target.y), Number.isFinite(lowerBound) ? lowerBound : 0) / cruise;
  };
  const heuristic = (id, x, y) => basePotential(Math.floor(id / DIRECTIONS), x, y);
  const cost = (id) => stamps[id] === generation ? costs[id] : Infinity;
  const reached = new Map(state?.nodes?.map((entry) => [entry.id, entry]));
  for (const entry of reached.values()) {
    stamps[entry.id] = generation;
    costs[entry.id] = entry.cost;
    previous[entry.id] = entry.parent;
  }
  for (const [id, clear] of savedTraffic) trafficFits[id] = clear ? generation : -generation;
  if (state?.heap) frontier.restore(state.heap);
  const setCost = (id, value, parent) => {
    stamps[id] = generation;
    costs[id] = value;
    previous[id] = parent;
    if (state) reached.set(id, { id, cost: value, parent });
  };
  const prefixes = new Map(state?.prefixes?.map((entry) => [entry.id, entry.points])), entrances = new Map(state?.entrances?.map((entry) => [entry.cell, entry.points]));
  const pause = () => {
    state.nodes = Array.from(reached.values());
    state.trafficFits = Array.from(savedTraffic, ([id, clear]) => ({ id, clear }));
    state.heap = frontier.save();
    state.prefixes = Array.from(prefixes, ([id, points]) => ({ id, points }));
    state.entrances = Array.from(entrances, ([cell, points]) => ({ cell, points }));
    state.trafficBlocked = trafficBlocked;
  };
  const col = Math.floor(ship.x / lattice.cell), row = Math.floor(ship.y / lattice.cell);
  let entranceCursor = 0, entranceWork = 0;
  if (!state || state.phase === "entrance") for (let y = Math.max(0, row - 1); y <= Math.min(lattice.rows - 1, row + 1); y++)
    for (let x = Math.max(0, col - 1); x <= Math.min(lattice.cols - 1, col + 1); x++)
      for (let h = 0; h < DIRECTIONS; h++) {
        if (state && entranceCursor++ < (state.entranceCursor ?? 0)) continue;
        if (state && entranceWork++ >= 16) {
          state.entranceCursor = entranceCursor - 1;
          pause();
          return;
        }
        const id = (y * lattice.cols + x) * DIRECTIONS + h, p = pose(id);
        if (!fits(id))
          continue;
        const cell = y * lattice.cols + x;
        if (!entrances.has(cell)) entrances.set(cell, keelCandidates(ship, start, { x: p.x, y: p.y }).filter((points) => connectorClear(map, ship, start, points, trafficClear)));
        let prefix2, g = Infinity;
        for (const entrance of entrances.get(cell)) {
          const end = entrance.at(-1) ?? start;
          if (!hullPassageClear(map, ship, end, p) || !trafficClear(end, p)) continue;
          const points = [...entrance, ...Math.abs(headingDifference(end.heading, p.heading)) > 1e-7 ? [p] : []], time = routeTime(map, ship, start, points);
          if (time < g) {
            g = time;
            prefix2 = points;
          }
        }
        if (!prefix2) continue;
        setCost(id, g, -1);
        prefixes.set(id, prefix2);
        frontier.push(id, g, g + heuristic(id, p.x, p.y));
      }
  if (state && state.phase === "entrance") {
    state.phase = "search";
    pause();
    return;
  }
  if (!frontier.length) {
    const departure = departureRoute(map, ship, target, trafficClear, true);
    return { points: departure ?? [], partial: !!departure || deferred || trafficBlocked };
  }
  let best = state?.best ?? -1, bestGap = state?.bestGap ?? Infinity, visited = state?.visited ?? 0, partial = false, terminal, expanded = 0;
  const visit = (id, nodeCost, p, to, weight, slot, index, mask) => {
    const value = nodeCost + weight;
    if (value >= cost(to) || !fits(to))
      return;
    if (!slot[index])
      slot[index] = maskFits(map, grid, id, mask) ? 1 : -1;
    if (slot[index] !== 1)
      return;
    const tile = Math.floor(to / DIRECTIONS), px = (tile % lattice.cols + 0.5) * lattice.cell, py = (Math.floor(tile / lattice.cols) + 0.5) * lattice.cell;
    if (!noTraffic && !trafficClear(p, { x: px, y: py, heading: to % DIRECTIONS * ANGLE }))
      return;
    setCost(to, value, id);
    frontier.push(to, value, value + heuristic(to, px, py));
  };
  while (frontier.length) {
    if (state && expanded >= (noTraffic ? 4096 : 128)) {
      state.best = best;
      if (Number.isFinite(bestGap)) state.bestGap = bestGap;
      state.visited = visited;
      pause();
      return;
    }
    const id = frontier.pop();
    const nodeCost = cost(id);
    if (frontier.poppedCost !== nodeCost)
      continue;
    const h = id % DIRECTIONS, cell = Math.floor(id / DIRECTIONS), x = cell % lattice.cols, y = Math.floor(cell / lattice.cols);
    const px = (x + 0.5) * lattice.cell, py = (y + 0.5) * lattice.cell;
    const p = noTraffic ? void 0 : { x: px, y: py, heading: h * ANGLE };
    expanded++;
    if (++visited > budget) {
      best = id;
      partial = true;
      break;
    }
    const gap = Math.hypot(px - target.x, py - target.y);
    if (gap < bestGap || gap === bestGap && cost(id) < (best < 0 ? Infinity : cost(best))) {
      best = id;
      bestGap = gap;
    }
    if (gap <= lattice.cell * 1.5) {
      const at = p ?? { x: px, y: py, heading: h * ANGLE };
      const connection = keelConnector(map, ship, at, destination, trafficClear) ?? arrive(at);
      if (connection) {
        best = id;
        terminal = connection;
        break;
      }
    }
    visit(id, nodeCost, p, cell * DIRECTIONS + (h + 1) % DIRECTIONS, ANGLE / turnSpeed, grid.turns, id * 2, grid.masks[h][1]);
    visit(id, nodeCost, p, cell * DIRECTIONS + (h + DIRECTIONS - 1) % DIRECTIONS, ANGLE / turnSpeed, grid.turns, id * 2 + 1, grid.masks[h][2]);
    for (const maneuver of [0, 2]) {
      const [dx, dy] = STEPS[(h + maneuver * 2) % DIRECTIONS], nx = x + dx, ny = y + dy;
      if (voyage && maneuver === 2) {
        const ax = (nx + 0.5) * lattice.cell - start.x, ay = (ny + 0.5) * lattice.cell - start.y;
        if (Math.abs(ax) > length || Math.abs(ay) > length || Math.hypot(ax, ay) > length) continue;
      }
      if (nx >= 0 && ny >= 0 && nx < lattice.cols && ny < lattice.rows)
        visit(id, nodeCost, p, (ny * lattice.cols + nx) * DIRECTIONS + h, maneuver === 2 ? edgeWeights[h].reverse : edgeWeights[h].forward, grid.moves, id * 4 + maneuver, grid.masks[h][maneuver + 3]);
    }
  }
  if (state) state.visited = visited;
  if (best < 0)
    return { points: [], partial: false };
  const path = [];
  for (let at = best; at >= 0; at = previous[at])
    path.push(pose(at));
  path.reverse();
  const root = path[0];
  const rootId = (Math.floor(root.y / lattice.cell) * lattice.cols + Math.floor(root.x / lattice.cell)) * DIRECTIONS + Math.round(root.heading / ANGLE) % DIRECTIONS;
  const prefix = prefixes.get(rootId) ?? [root];
  path.splice(0, 1, ...prefix);
  if (terminal) path.push(...terminal);
  if (!terminal && trafficBlocked && !partial) {
    if (state) {
      state.phase = "fallback";
      state.path = path;
      state.fallback = { phase: "prepare" };
      state.deferred = deferred;
      delete state.nodes;
      delete state.trafficFits;
      delete state.heap;
      delete state.prefixes;
      delete state.entrances;
      delete state.best;
      delete state.bestGap;
      delete state.visited;
      delete state.entranceCursor;
      return;
    }
    const unobstructed = planShipRoute(map, ship, goal, void 0, Infinity, voyage), end = path.at(-1) ?? start, possible = unobstructed.points.at(-1) ?? start;
    partial = unobstructed.partial || Math.hypot(end.x - possible.x, end.y - possible.y) > 1e-7;
  }
  return { points: path, partial: partial || deferred };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoaXAtbmF2aWdhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzaGlwTW90aW9uTGltaXRzIH0gZnJvbSAnLi9zaGlwLWhhbmRsaW5nJztcbmltcG9ydCB7IGNvdXJzZVBlcmZvcm1hbmNlIH0gZnJvbSAnLi9zaGlwLXdpbmQnO1xuaW1wb3J0IHsgd2luZEF0IH0gZnJvbSAnLi93aW5kLWZpZWxkJztcbmltcG9ydCB7IGRldENvcywgZGV0U2luIH0gZnJvbSBcIi4vZGV0LW1hdGhcIjtcbmltcG9ydCB7IHNoaXBQcm9maWxlLCB0eXBlIFBvaW50IH0gZnJvbSBcIi4vc2hpcC1nZW9tZXRyeVwiO1xuaW1wb3J0IHsgQ0VMTF9HUk9VTkQsIGlzV2Fsa2FibGUsIHNhbWVHcm91bmQsIHdhbGthYmxlR29hbCB9IGZyb20gXCIuL3RlcnJhaW5cIjtcbmltcG9ydCB0eXBlIHsgR2FtZU1hcCwgVW5pdCB9IGZyb20gXCIuL3R5cGVzXCI7XG5pbXBvcnQgeyBjb252ZXhIdWxsLCBleHBhbmRDb252ZXgsIHBvbHlnb25QbGFuZXMsIHBvbHlnb25SYWRpdXMsIHBvbHlnb25Ub3VjaGVzQ2VsbCB9IGZyb20gJy4vbmF2aWdhdGlvbi1tYXRoJztcbmltcG9ydCBwcmVwYXJlZE1hc2tzIGZyb20gJy4vZ2VuZXJhdGVkL3NoaXAtbmF2aWdhdGlvbi1tYXNrcy5qc29uJztcbmltcG9ydCBwcmVwYXJlZE1hc2tzNjQgZnJvbSAnLi9nZW5lcmF0ZWQvc2hpcC1uYXZpZ2F0aW9uLW1hc2tzLTY0Lmpzb24nO1xuaW1wb3J0IHsgYnVpbGROYXZpZ2F0aW9uTWFza3MsIHR5cGUgT2NjdXBhbmN5TWFzayB9IGZyb20gJy4vbmF2aWdhdGlvbi1tYXNrcyc7XG5pbXBvcnQgeyBzaGlwU2NhbGUsIERFRkFVTFRfU0hJUF9TQ0FMRSB9IGZyb20gJy4vc2hpcC1nZW9tZXRyeSc7XG5pbXBvcnQgeyBidWlsZFNlYVBvdGVudGlhbCwgc2VhUG90ZW50aWFsQXQsIHR5cGUgU2VhUG90ZW50aWFsIH0gZnJvbSAnLi9zaGlwLW5hdmlnYXRpb24tcG90ZW50aWFsJztcbmV4cG9ydCB0eXBlIFNoaXBQb3NlID0gUG9pbnQgJiB7XG4gIGhlYWRpbmc6IG51bWJlcjtcbiAgcGl2b3Q/OiBQb2ludDtcbiAgdGFjaz86IGJvb2xlYW47XG4gIGV4YWN0PzogYm9vbGVhbjtcbiAgLyoqIFNpZ25lZCBjdXJ2YXR1cmUgb2YgdGhlIGluY29taW5nIHNlZ21lbnQ7IGhlYWRpbmcgaXMgaXRzIGVuZCB0YW5nZW50LiAqL1xuICBjdXJ2YXR1cmU/OiBudW1iZXI7XG4gIC8qKiBBIHBoeXNpY2FsIHNwZWVkIGNlaWxpbmcsIGFsc28gcGxhY2VkIGF0IHRoZSBlbnRyeSB0byBhbiB1cGNvbWluZyBiZW5kLiAqL1xuICBzcGVlZExpbWl0PzogbnVtYmVyO1xufTtcbmZ1bmN0aW9uIGN1cnZlZFNlZ21lbnQoZnJvbTpTaGlwUG9zZSx0bzpTaGlwUG9zZSk6bnVtYmVyIHtcbiAgY29uc3QgY3VydmF0dXJlPXRvLmN1cnZhdHVyZSA/PyAwO1xuICBpZihNYXRoLmFicyhjdXJ2YXR1cmUpPDFlLTkpcmV0dXJuIDA7XG4gIGNvbnN0IHg9ZnJvbS54KyhkZXRTaW4odG8uaGVhZGluZyktZGV0U2luKGZyb20uaGVhZGluZykpL2N1cnZhdHVyZTtcbiAgY29uc3QgeT1mcm9tLnktKGRldENvcyh0by5oZWFkaW5nKS1kZXRDb3MoZnJvbS5oZWFkaW5nKSkvY3VydmF0dXJlO1xuICAvLyBSdW50aW1lIGh1bGwgc3dlZXBzIGFuZCBleGFjdCBtYW5ldXZlcnMgbWF5IGNvcHkgd2F5cG9pbnQgbWV0YWRhdGEuIE9ubHlcbiAgLy8gdGhlIGFjdHVhbCByZWZlcmVuY2UgY2lyY2xlIHJlY2VpdmVzIGN1cnZlZCBpbnRlcnBvbGF0aW9uLlxuICByZXR1cm4gTWF0aC5oeXBvdCh4LXRvLngseS10by55KTwxZS01P2N1cnZhdHVyZTowO1xufVxuLyoqIFJvdGF0aW9uIGFyb3VuZCBhIGZpeGVkIGJvdy9zdGVybiBjb250YWN0IHBvaW50LCB1c2VkIGZvciBhIHJlYWwgZGVwYXJ0dXJlXG4gKiBtYW5ldXZlciByYXRoZXIgdGhhbiB0cmFuc2xhdGluZyBhIGh1bGwgc2lkZXdheXMgd2l0aG91dCB0dXJuaW5nIGl0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNoaXBQb3NlQXQoZnJvbTogU2hpcFBvc2UsIHRvOiBTaGlwUG9zZSwgZnJhY3Rpb246IG51bWJlcik6IFNoaXBQb3NlIHtcbiAgY29uc3QgaGVhZGluZz1mcm9tLmhlYWRpbmcraGVhZGluZ0RpZmZlcmVuY2UoZnJvbS5oZWFkaW5nLHRvLmhlYWRpbmcpKmZyYWN0aW9uO1xuICBpZih0by5waXZvdCl7Y29uc3QgbGV2ZXI9KGZyb20ueC10by5waXZvdC54KSpkZXRDb3MoZnJvbS5oZWFkaW5nKSsoZnJvbS55LXRvLnBpdm90LnkpKmRldFNpbihmcm9tLmhlYWRpbmcpO3JldHVybnt4OnRvLnBpdm90LngrbGV2ZXIqZGV0Q29zKGhlYWRpbmcpLHk6dG8ucGl2b3QueStsZXZlcipkZXRTaW4oaGVhZGluZyksaGVhZGluZ307fVxuICBjb25zdCBjdXJ2YXR1cmU9Y3VydmVkU2VnbWVudChmcm9tLHRvKTtcbiAgaWYoY3VydmF0dXJlKXJldHVybnt4OmZyb20ueCsoZGV0U2luKGhlYWRpbmcpLWRldFNpbihmcm9tLmhlYWRpbmcpKS9jdXJ2YXR1cmUseTpmcm9tLnktKGRldENvcyhoZWFkaW5nKS1kZXRDb3MoZnJvbS5oZWFkaW5nKSkvY3VydmF0dXJlLGhlYWRpbmd9O1xuICByZXR1cm57eDpmcm9tLngrKHRvLngtZnJvbS54KSpmcmFjdGlvbix5OmZyb20ueSsodG8ueS1mcm9tLnkpKmZyYWN0aW9uLGhlYWRpbmd9O1xufVxudHlwZSBTZWFNYXAgPSBQaWNrPEdhbWVNYXAsIFwidGVycmFpblwiIHwgXCJ3aWR0aFwiIHwgXCJoZWlnaHRcIiB8IFwid2luZFwiPjtcbmNvbnN0IHdhdGVyRmllbGRzID0gbmV3IFdlYWtNYXA8b2JqZWN0LCB7XG4gIGNlbGxzOiBzdHJpbmc7XG4gIGNvbHM6IG51bWJlcjtcbiAgcm93czogbnVtYmVyO1xuICBzdW1zOiBVaW50MzJBcnJheTtcbn0+KCk7XG4vKiogSW50ZWdyYWwgb2NjdXBhbmN5IGZpZWxkOiBhIGNvbnNlcnZhdGl2ZSBzd2VwdCBib3VuZGluZyBib3ggcHJvdmVzIG9wZW4gd2F0ZXIgaW4gTygxKS4gKi9cbmZ1bmN0aW9uIG9wZW5XYXRlckJveChtYXA6IFNlYU1hcCwgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciwgcmlnaHQ6IG51bWJlciwgYm90dG9tOiBudW1iZXIpIHtcbiAgaWYgKGxlZnQgPCAwIHx8IHRvcCA8IDAgfHwgcmlnaHQgPiBtYXAud2lkdGggfHwgYm90dG9tID4gbWFwLmhlaWdodClcbiAgICByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHQgPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0KVxuICAgIHJldHVybiB0cnVlO1xuICBsZXQgZmllbGQgPSB3YXRlckZpZWxkcy5nZXQodCk7XG4gIGlmICghZmllbGQgfHwgZmllbGQuY2VsbHMgIT09IHQuY2VsbHMgfHwgZmllbGQuY29scyAhPT0gdC5jb2xzIHx8IGZpZWxkLnJvd3MgIT09IHQucm93cykge1xuICAgIGNvbnN0IHcgPSB0LmNvbHMgKyAxLCBzdW1zID0gbmV3IFVpbnQzMkFycmF5KHcgKiAodC5yb3dzICsgMSkpO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdC5yb3dzOyB5KyspIHtcbiAgICAgIGxldCByb3cgPSAwO1xuICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0LmNvbHM7IHgrKykge1xuICAgICAgICByb3cgKz0gQ0VMTF9HUk9VTkRbdC5jZWxsc1t5ICogdC5jb2xzICsgeF0gPz8gJy4nXT8uc2VhID8gMCA6IDE7XG4gICAgICAgIHN1bXNbKHkgKyAxKSAqIHcgKyB4ICsgMV0gPSBzdW1zW3kgKiB3ICsgeCArIDFdISArIHJvdztcbiAgICAgIH1cbiAgICB9XG4gICAgZmllbGQgPSB7IGNlbGxzOiB0LmNlbGxzLCBjb2xzOiB0LmNvbHMsIHJvd3M6IHQucm93cywgc3VtcyB9O1xuICAgIHdhdGVyRmllbGRzLnNldCh0LCBmaWVsZCk7XG4gIH1cbiAgY29uc3QgeDAgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKGxlZnQgLyB0LmNlbGwpKSwgeTAgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKHRvcCAvIHQuY2VsbCkpO1xuICBjb25zdCB4MSA9IE1hdGgubWluKHQuY29scywgTWF0aC5jZWlsKHJpZ2h0IC8gdC5jZWxsKSksIHkxID0gTWF0aC5taW4odC5yb3dzLCBNYXRoLmNlaWwoYm90dG9tIC8gdC5jZWxsKSksIHcgPSB0LmNvbHMgKyAxLCBzID0gZmllbGQuc3VtcztcbiAgcmV0dXJuIHNbeTEgKiB3ICsgeDFdISAtIHNbeTAgKiB3ICsgeDFdISAtIHNbeTEgKiB3ICsgeDBdISArIHNbeTAgKiB3ICsgeDBdISA9PT0gMDtcbn1cbmNvbnN0IERJUkVDVElPTlMgPSA4O1xuY29uc3QgQU5HTEUgPSBNYXRoLlBJIC8gNDtcbmNvbnN0IFNURVBTID0gW1sxLCAwXSwgWzEsIDFdLCBbMCwgMV0sIFstMSwgMV0sIFstMSwgMF0sIFstMSwgLTFdLCBbMCwgLTFdLCBbMSwgLTFdXSBhcyBjb25zdDtcbmV4cG9ydCBmdW5jdGlvbiBoZWFkaW5nRGlmZmVyZW5jZShmcm9tOiBudW1iZXIsIHRvOiBudW1iZXIpIHtcbiAgcmV0dXJuICgodG8gLSBmcm9tICsgTWF0aC5QSSkgJSAoMiAqIE1hdGguUEkpICsgMiAqIE1hdGguUEkpICUgKDIgKiBNYXRoLlBJKSAtIE1hdGguUEk7XG59XG5mdW5jdGlvbiBvdXRsaW5lKGh1bGw6IHJlYWRvbmx5IFBvaW50W10sIHBvc2U6IFNoaXBQb3NlKSB7XG4gIGNvbnN0IGMgPSBkZXRDb3MocG9zZS5oZWFkaW5nKSwgcyA9IGRldFNpbihwb3NlLmhlYWRpbmcpO1xuICByZXR1cm4gaHVsbC5tYXAocCA9PiAoeyB4OiBwb3NlLnggKyBwLnggKiBjIC0gcC55ICogcywgeTogcG9zZS55ICsgcC54ICogcyArIHAueSAqIGMgfSkpO1xufVxuLyoqIEV4YWN0IGNvbnZleCBwb2x5Z29uIC8gY2VsbCBpbnRlcnNlY3Rpb24sIGluY2x1ZGluZyBlZGdlcyBjcm9zc2luZyBhIGNlbGwgd2l0aG91dCBhIHZlcnRleCBpbnNpZGUgaXQuICovXG5mdW5jdGlvbiBjbGVhck91dGxpbmUobWFwOiBTZWFNYXAsIHBvbHlnb246IHJlYWRvbmx5IFBvaW50W10pIHtcbiAgbGV0IGxlZnQgPSBJbmZpbml0eSwgcmlnaHQgPSAtSW5maW5pdHksIHRvcCA9IEluZmluaXR5LCBib3R0b20gPSAtSW5maW5pdHk7XG4gIGZvciAoY29uc3QgcG9pbnQgb2YgcG9seWdvbikge1xuICAgIGxlZnQgPSBNYXRoLm1pbihsZWZ0LCBwb2ludC54KTsgcmlnaHQgPSBNYXRoLm1heChyaWdodCwgcG9pbnQueCk7XG4gICAgdG9wID0gTWF0aC5taW4odG9wLCBwb2ludC55KTsgYm90dG9tID0gTWF0aC5tYXgoYm90dG9tLCBwb2ludC55KTtcbiAgfVxuICBpZiAobGVmdCA8IC0xZS03IHx8IHRvcCA8IC0xZS03IHx8IHJpZ2h0ID4gbWFwLndpZHRoICsgMWUtNyB8fCBib3R0b20gPiBtYXAuaGVpZ2h0ICsgMWUtNylcbiAgICByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHRlcnJhaW4gPSBtYXAudGVycmFpbjtcbiAgaWYgKCF0ZXJyYWluKVxuICAgIHJldHVybiB0cnVlO1xuICBpZiAob3BlbldhdGVyQm94KG1hcCwgbGVmdCwgdG9wLCByaWdodCwgYm90dG9tKSlcbiAgICByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgY2VsbCA9IHRlcnJhaW4uY2VsbDtcbiAgbGV0IGF4ZXM6IFJldHVyblR5cGU8dHlwZW9mIHBvbHlnb25QbGFuZXM+IHwgdW5kZWZpbmVkO1xuICBmb3IgKGxldCByb3cgPSBNYXRoLmZsb29yKHRvcCAvIGNlbGwpOyByb3cgPD0gTWF0aC5mbG9vcigoYm90dG9tIC0gMWUtNykgLyBjZWxsKTsgcm93KyspXG4gICAgZm9yIChsZXQgY29sID0gTWF0aC5mbG9vcihsZWZ0IC8gY2VsbCk7IGNvbCA8PSBNYXRoLmZsb29yKChyaWdodCAtIDFlLTcpIC8gY2VsbCk7IGNvbCsrKSB7XG4gICAgICBjb25zdCBjaGFyID0gY29sIDwgMCB8fCByb3cgPCAwIHx8IGNvbCA+PSB0ZXJyYWluLmNvbHMgfHwgcm93ID49IHRlcnJhaW4ucm93cyA/IHVuZGVmaW5lZCA6IHRlcnJhaW4uY2VsbHNbcm93ICogdGVycmFpbi5jb2xzICsgY29sXTtcbiAgICAgIGlmICghQ0VMTF9HUk9VTkRbY2hhciA/PyBcIi5cIl0/LnNlYSAmJiBwb2x5Z29uVG91Y2hlc0NlbGwoYXhlcyA/Pz0gcG9seWdvblBsYW5lcyhwb2x5Z29uKSwgY29sICogY2VsbCwgcm93ICogY2VsbCwgY2VsbCkpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIHJldHVybiB0cnVlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGh1bGxGaXRzKG1hcDogU2VhTWFwLCBzaGlwOiBVbml0LCBwb3NlOiBTaGlwUG9zZSA9IHsgeDogc2hpcC54LCB5OiBzaGlwLnksIGhlYWRpbmc6IHNoaXAuc2FpbGluZz8uaGVhZGluZyA/PyAwIH0pIHtcbiAgY29uc3QgcHJvZmlsZSA9IHNoaXBQcm9maWxlKHNoaXApO1xuICByZXR1cm4gQm9vbGVhbihwcm9maWxlICYmIGNsZWFyT3V0bGluZShtYXAsIG91dGxpbmUocHJvZmlsZS5odWxsLCBwb3NlKSkpO1xufVxuLyoqIENvbnRpbnVvdXMgc3dlZXA6IGJvdW5kZWQgcm90YXRpb25hbCBjdXJ2YXR1cmUgZXhwYW5kcyBlYWNoIGVuZHBvaW50IGVudmVsb3BlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGh1bGxQYXNzYWdlQ2xlYXIobWFwOiBTZWFNYXAsIHNoaXA6IFVuaXQsIGZyb206IFNoaXBQb3NlLCB0bzogU2hpcFBvc2UpIHtcbiAgY29uc3QgaHVsbCA9IHNoaXBQcm9maWxlKHNoaXApIS5odWxsO1xuICBjb25zdCB0dXJuID0gaGVhZGluZ0RpZmZlcmVuY2UoZnJvbS5oZWFkaW5nLCB0by5oZWFkaW5nKTtcbiAgY29uc3QgY3VydmF0dXJlPWN1cnZlZFNlZ21lbnQoZnJvbSx0byk7XG4gIGNvbnN0IGh1bGxSYWRpdXMgPSBwb2x5Z29uUmFkaXVzKGh1bGwpO1xuICBjb25zdCBsZXZlciA9IHRvLnBpdm90ID8gTWF0aC5oeXBvdChmcm9tLngtdG8ucGl2b3QueCxmcm9tLnktdG8ucGl2b3QueSkgOiBjdXJ2YXR1cmUgPyAxL01hdGguYWJzKGN1cnZhdHVyZSkgOiAwO1xuICBjb25zdCByYWRpdXMgPSBodWxsUmFkaXVzICsgbGV2ZXI7XG4gIC8vIFRoZSBjZW50ZXIncyBjaXJjdWxhciBhcmMgbGllcyB3aXRoaW4gUiDOlM64wrIgLyA4IG9mIGl0cyBlbmRwb2ludCBjaG9yZC5cbiAgLy8gQSBjcnVpc2UgdHVybiBuZWVkcyB0aGlzIHNob3J0IGNvcnJpZG9yLCByYXRoZXIgdGhhbiBhIHdob2xlIHR1cm4gY2lyY2xlLlxuICAvLyBJbmNvbnNpc3RlbnQgY29waWVkIHBpdm90IG1ldGFkYXRhIHJldGFpbnMgdGhlIGNvbnNlcnZhdGl2ZSBmYWxsYmFjay5cbiAgY29uc3QgcGl2b3RBcmMgPSAhdG8ucGl2b3QgfHwgWzAsMV0uZXZlcnkoZnJhY3Rpb24gPT4ge1xuICAgIGNvbnN0IGF0ID0gc2hpcFBvc2VBdChmcm9tLHRvLGZyYWN0aW9uKSwgZW5kcG9pbnQgPSBmcmFjdGlvbiA/IHRvIDogZnJvbTtcbiAgICByZXR1cm4gTWF0aC5oeXBvdChhdC54LWVuZHBvaW50LngsYXQueS1lbmRwb2ludC55KTwxZS01O1xuICB9KTtcbiAgY29uc3QgY29ycmlkb3JSYWRpdXMgPSBwaXZvdEFyYyA/IGh1bGxSYWRpdXMgKyBsZXZlcip0dXJuKnR1cm4vOCArIChsZXZlciA/IDFlLTUgOiAwKSA6IHJhZGl1cztcbiAgaWYgKG9wZW5XYXRlckJveChtYXAsIE1hdGgubWluKGZyb20ueCwgdG8ueCkgLSBjb3JyaWRvclJhZGl1cywgTWF0aC5taW4oZnJvbS55LCB0by55KSAtIGNvcnJpZG9yUmFkaXVzLCBNYXRoLm1heChmcm9tLngsIHRvLngpICsgY29ycmlkb3JSYWRpdXMsIE1hdGgubWF4KGZyb20ueSwgdG8ueSkgKyBjb3JyaWRvclJhZGl1cykpXG4gICAgcmV0dXJuIHRydWU7XG4gIGlmKHR1cm4gJiYgKCFodWxsRml0cyhtYXAsc2hpcCxmcm9tKSB8fCAhaHVsbEZpdHMobWFwLHNoaXAsdG8pKSlyZXR1cm4gZmFsc2U7XG4gIC8vIFN1YmRpdmlkZSBieSBhIGdlb21ldHJpYyBlcnJvciBib3VuZCwgcmF0aGVyIHRoYW4gdmVydGV4IHRyYXZlbC4gRXZlcnlcbiAgLy8gZW52ZWxvcGUgc3RpbGwgY29udGFpbnMgdGhlIHdob2xlIGFyYywgd2l0aCBhdCBtb3N0IDAuMDI1IHVuaXRzIHBhZGRpbmcuXG4gIGNvbnN0IHN0ZXBzID0gTWF0aC5tYXgoMSwgTWF0aC5jZWlsKE1hdGguYWJzKHR1cm4pICogTWF0aC5zcXJ0KHJhZGl1cyAvICg4ICogLjAyNSkpKSk7XG4gIC8vIExpbmVhciBpbnRlcnBvbGF0aW9uIGVycm9yIG9mIGEgcm90YXRpbmcgdmVydGV4IGlzIGF0IG1vc3QgUiDOlM64wrIgLyA4LlxuICAvLyBUaGUgZXhwYW5kZWQgY29udmV4IGVudmVsb3BlIGNvbnRhaW5zIHRoZSBlbnRpcmUgaW50ZXJtZWRpYXRlIGh1bGwuXG4gIGNvbnN0IGVycm9yID0gdHVybiA/IHJhZGl1cyAqICh0dXJuIC8gc3RlcHMpICoqIDIgLyA4ICsgMWUtNyA6IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RlcHM7IGkrKykge1xuICAgIGNvbnN0IGEgPSBzaGlwUG9zZUF0KGZyb20sdG8saS9zdGVwcyk7XG4gICAgY29uc3QgYiA9IHNoaXBQb3NlQXQoZnJvbSx0bywoaSsxKS9zdGVwcyk7XG4gICAgY29uc3QgZW52ZWxvcGUgPSBjb252ZXhIdWxsKFsuLi5vdXRsaW5lKGh1bGwsIGEpLCAuLi5vdXRsaW5lKGh1bGwsIGIpXSk7XG4gICAgaWYgKCFjbGVhck91dGxpbmUobWFwLCBlcnJvciA/IGV4cGFuZENvbnZleChlbnZlbG9wZSwgZXJyb3IpIDogZW52ZWxvcGUpKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuLyoqIFBoeXNpY2FsIHNlcGFyYXRpb24gYW5kIHNob3ZlIG1vdmVtZW50IHN0b3AgYXQgdGhlIGNvYXN0IGluc3RlYWQgb2Ygc2xpZGluZyBhIHNoaXAgc2lkZXdheXMgdGhyb3VnaCBsYW5kLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGh1bGxTdGVwKG1hcDogU2VhTWFwLCBzaGlwOiBVbml0LCBwb2ludDogUG9pbnQpOiBQb2ludCB7XG4gIGNvbnN0IGZyb20gPSB7IHg6IHNoaXAueCwgeTogc2hpcC55LCBoZWFkaW5nOiBzaGlwLnNhaWxpbmc/LmhlYWRpbmcgPz8gMCB9LCB0byA9IHsgLi4ucG9pbnQsIGhlYWRpbmc6IGZyb20uaGVhZGluZyB9O1xuICBpZiAoaHVsbFBhc3NhZ2VDbGVhcihtYXAsIHNoaXAsIGZyb20sIHRvKSlcbiAgICByZXR1cm4gcG9pbnQ7XG4gIGxldCBsb3cgPSAwLCBoaWdoID0gMTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMjsgaSsrKSB7XG4gICAgY29uc3QgbWlkID0gKGxvdyArIGhpZ2gpIC8gMjtcbiAgICBjb25zdCBhdCA9IHsgeDogZnJvbS54ICsgKHRvLnggLSBmcm9tLngpICogbWlkLCB5OiBmcm9tLnkgKyAodG8ueSAtIGZyb20ueSkgKiBtaWQsIGhlYWRpbmc6IGZyb20uaGVhZGluZyB9O1xuICAgIGlmIChodWxsUGFzc2FnZUNsZWFyKG1hcCwgc2hpcCwgZnJvbSwgYXQpKVxuICAgICAgbG93ID0gbWlkO1xuICAgIGVsc2VcbiAgICAgIGhpZ2ggPSBtaWQ7XG4gIH1cbiAgcmV0dXJuIHsgeDogZnJvbS54ICsgKHRvLnggLSBmcm9tLngpICogbG93LCB5OiBmcm9tLnkgKyAodG8ueSAtIGZyb20ueSkgKiBsb3cgfTtcbn1cbi8qKiBPbmx5IGNyZWF0aW9uIC8gb2xkIGF1dGhvcmVkIHBsYWNlbWVudHMgcmVsb2NhdGU6IG5vcm1hbCBzYWlsaW5nIGFsd2F5cyBmb2xsb3dzIGEgc3dlcHQsIGNvbnRpbnVvdXMgcGFzc2FnZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuZWFyZXN0U2hpcFBvc2UobWFwOiBTZWFNYXAsIHNoaXA6IFVuaXQsIHBvaW50OiBQb2ludCwgc2VhT3JpZ2luOiBQb2ludCA9IHNoaXAsIGFjY2VwdHM6KHBvc2U6U2hpcFBvc2UpPT5ib29sZWFuPSgpPT50cnVlKTogU2hpcFBvc2UgfCB1bmRlZmluZWQge1xuICBjb25zdCBwcmVmZXJyZWQgPSBzaGlwLnNhaWxpbmc/LmhlYWRpbmcgPz8gMDtcbiAgY29uc3Qgc2VhU3RhcnQgPSBpc1dhbGthYmxlKG1hcCwgc2VhT3JpZ2luLngsIHNlYU9yaWdpbi55LCBcInNlYVwiKSA/IHNlYU9yaWdpbiA6IHdhbGthYmxlR29hbChtYXAsIHNlYU9yaWdpbi54LCBzZWFPcmlnaW4ueSwgXCJzZWFcIik7XG4gIGNvbnN0IGhlYWRpbmdzID0gW3ByZWZlcnJlZCwgLi4uQXJyYXkuZnJvbSh7IGxlbmd0aDogRElSRUNUSU9OUyB9LCAoXywgaSkgPT4gaSAqIEFOR0xFKV07XG4gIGlmICghbWFwLnRlcnJhaW4pIHtcbiAgICBjb25zdCBodWxsID0gb3V0bGluZShzaGlwUHJvZmlsZShzaGlwKSEuaHVsbCwgeyB4OiAwLCB5OiAwLCBoZWFkaW5nOiBwcmVmZXJyZWQgfSk7XG4gICAgY29uc3QgeCA9IE1hdGgubWF4KC1NYXRoLm1pbiguLi5odWxsLm1hcChwID0+IHAueCkpLCBNYXRoLm1pbihtYXAud2lkdGggLSBNYXRoLm1heCguLi5odWxsLm1hcChwID0+IHAueCkpLCBwb2ludC54KSk7XG4gICAgY29uc3QgeSA9IE1hdGgubWF4KC1NYXRoLm1pbiguLi5odWxsLm1hcChwID0+IHAueSkpLCBNYXRoLm1pbihtYXAuaGVpZ2h0IC0gTWF0aC5tYXgoLi4uaHVsbC5tYXAocCA9PiBwLnkpKSwgcG9pbnQueSkpO1xuICAgIGlmKGh1bGxGaXRzKG1hcCwgc2hpcCwgeyB4LCB5LCBoZWFkaW5nOiBwcmVmZXJyZWQgfSkgJiYgYWNjZXB0cyh7eCx5LGhlYWRpbmc6cHJlZmVycmVkfSkpcmV0dXJue3gseSxoZWFkaW5nOnByZWZlcnJlZH07XG4gICAgZm9yKGxldCBkaXN0YW5jZT0xNjtkaXN0YW5jZTw9c2hpcFByb2ZpbGUoc2hpcCkhLmxlbmd0aCo0O2Rpc3RhbmNlKz0xNilmb3IobGV0IGk9MDtpPDE2O2krKyl7XG4gICAgICBjb25zdCBhbmdsZT1pKk1hdGguUEkvOCxhdD17eDp4K2Rpc3RhbmNlKmRldENvcyhhbmdsZSkseTp5K2Rpc3RhbmNlKmRldFNpbihhbmdsZSksaGVhZGluZzpwcmVmZXJyZWR9O1xuICAgICAgaWYoaHVsbEZpdHMobWFwLHNoaXAsYXQpICYmIGFjY2VwdHMoYXQpKXJldHVybiBhdDtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBmb3IgKGNvbnN0IGhlYWRpbmcgb2YgaGVhZGluZ3MpXG4gICAgaWYgKGh1bGxGaXRzKG1hcCwgc2hpcCwgeyAuLi5wb2ludCwgaGVhZGluZyB9KSAmJiBhY2NlcHRzKHsuLi5wb2ludCxoZWFkaW5nfSkgJiYgc2FtZUdyb3VuZChtYXAsIHNlYVN0YXJ0LCBwb2ludCwgXCJzZWFcIikpXG4gICAgICByZXR1cm4geyAuLi5wb2ludCwgaGVhZGluZyB9O1xuICBjb25zdCB0ID0gbWFwLnRlcnJhaW4sIGNvbCA9IE1hdGgubWF4KDAsIE1hdGgubWluKHQuY29scyAtIDEsIE1hdGguZmxvb3IocG9pbnQueCAvIHQuY2VsbCkpKSwgcm93ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4odC5yb3dzIC0gMSwgTWF0aC5mbG9vcihwb2ludC55IC8gdC5jZWxsKSkpO1xuICBmb3IgKGxldCByaW5nID0gMDsgcmluZyA8PSBNYXRoLm1heCh0LmNvbHMsIHQucm93cyk7IHJpbmcrKykge1xuICAgIGxldCBiZXN0OiBTaGlwUG9zZSB8IHVuZGVmaW5lZCwgc2NvcmUgPSBJbmZpbml0eTtcbiAgICBmb3IgKGxldCB5ID0gTWF0aC5tYXgoMCwgcm93IC0gcmluZyk7IHkgPD0gTWF0aC5taW4odC5yb3dzIC0gMSwgcm93ICsgcmluZyk7IHkrKylcbiAgICAgIGZvciAobGV0IHggPSBNYXRoLm1heCgwLCBjb2wgLSByaW5nKTsgeCA8PSBNYXRoLm1pbih0LmNvbHMgLSAxLCBjb2wgKyByaW5nKTsgeCsrKSB7XG4gICAgICAgIGlmIChyaW5nICYmIE1hdGgubWF4KE1hdGguYWJzKHggLSBjb2wpLCBNYXRoLmFicyh5IC0gcm93KSkgIT09IHJpbmcpXG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIGNvbnN0IGF0ID0geyB4OiAoeCArIC41KSAqIHQuY2VsbCwgeTogKHkgKyAuNSkgKiB0LmNlbGwgfTtcbiAgICAgICAgaWYgKCFDRUxMX0dST1VORFt0LmNlbGxzW3kgKiB0LmNvbHMgKyB4XSA/PyBcIi5cIl0/LnNlYSB8fCAhc2FtZUdyb3VuZChtYXAsIHNlYVN0YXJ0LCBhdCwgXCJzZWFcIikpXG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIGZvciAoY29uc3QgaGVhZGluZyBvZiBoZWFkaW5ncykge1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gTWF0aC5oeXBvdChhdC54IC0gcG9pbnQueCwgYXQueSAtIHBvaW50LnkpICsgTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UocHJlZmVycmVkLCBoZWFkaW5nKSkgKiAuMDAxO1xuICAgICAgICAgIGlmICh2YWx1ZSA8IHNjb3JlICYmIGh1bGxGaXRzKG1hcCwgc2hpcCwgeyAuLi5hdCwgaGVhZGluZyB9KSAmJiBhY2NlcHRzKHsuLi5hdCxoZWFkaW5nfSkpIHtcbiAgICAgICAgICAgIGJlc3QgPSB7IC4uLmF0LCBoZWFkaW5nIH07XG4gICAgICAgICAgICBzY29yZSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIGlmIChiZXN0KVxuICAgICAgcmV0dXJuIGJlc3Q7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cbi8vIEFsbCBjYWNoZXMgYXJlIGdlb21ldHJ5LW9ubHkgYW5kIHJlY29tcHV0YWJsZS4gVGhlIGFjdGl2ZSByb3V0ZSBpcyBzZXJpYWxpemVkIHdpdGggdGhlIHNoaXAsIHByZXNlcnZpbmcgcmVwbGF5IG9yZGVyLlxudHlwZSBOYXZHcmlkID0ge1xuICBjZWxsczogc3RyaW5nO1xuICBjZWxsOiBudW1iZXI7XG4gIGNvbHM6IG51bWJlcjtcbiAgcm93czogbnVtYmVyO1xuICB3YXRlcjogVWludDhBcnJheTtcbiAgZml0czogSW50OEFycmF5O1xuICB0dXJuczogSW50OEFycmF5O1xuICBtb3ZlczogSW50OEFycmF5O1xuICBtYXNrczogT2NjdXBhbmN5TWFza1tdW107XG59O1xuY29uc3QgZ3JpZHMgPSBuZXcgV2Vha01hcDxvYmplY3QsIE1hcDxzdHJpbmcsIE5hdkdyaWQ+PigpO1xuLy8gQSBnZW5lcmF0aW9uIHN0YW1wIGdpdmVzIHVudG91Y2hlZCBzdGF0ZXMgYW5cbi8vIGluZmluaXRlIGNvc3Qgd2l0aG91dCBhbGxvY2F0aW5nIGFuZCBjbGVhcmluZyBhIG1hcC1zaXplZCBhcnJheSBwZXIgb3JkZXIuXG5mdW5jdGlvbiBjcmVhdGVTZWFyY2hXb3Jrc3BhY2Uoc2l6ZTogbnVtYmVyKSB7XG4gIHJldHVybiB7IGNvc3RzOiBuZXcgRmxvYXQ2NEFycmF5KHNpemUpLCBwYXJlbnRzOiBuZXcgSW50MzJBcnJheShzaXplKSwgc3RhbXBzOiBuZXcgVWludDMyQXJyYXkoc2l6ZSksIHRyYWZmaWNGaXRzOiBuZXcgSW50MzJBcnJheShzaXplKSxcbiAgICBiYXNlUG90ZW50aWFsczpuZXcgRmxvYXQ2NEFycmF5KHNpemUvRElSRUNUSU9OUyksYmFzZVN0YW1wczpuZXcgVWludDMyQXJyYXkoc2l6ZS9ESVJFQ1RJT05TKSxnZW5lcmF0aW9uOiAwIH07XG59XG5sZXQgc2VhcmNoID0gY3JlYXRlU2VhcmNoV29ya3NwYWNlKDApO1xuZnVuY3Rpb24gc2VhcmNoV29ya3NwYWNlKHNpemU6IG51bWJlciwgbmVzdGVkID0gZmFsc2UpIHtcbiAgLy8gUHVibGljIHRyYWZmaWMgY2FsbGJhY2tzIG1heSBzeW5jaHJvbm91c2x5IGFzayBmb3IgYW5vdGhlciByb3V0ZS4gVGhhdFxuICAvLyBzZWFyY2ggbXVzdCBub3Qgc3RhbXAgb3ZlciB0aGUgYWN0aXZlIGNhbGxlcidzIGNvc3RzIG9yIHBhcmVudCBjaGFpbi5cbiAgaWYgKG5lc3RlZCkgeyBjb25zdCB3b3Jrc3BhY2UgPSBjcmVhdGVTZWFyY2hXb3Jrc3BhY2Uoc2l6ZSk7IHdvcmtzcGFjZS5nZW5lcmF0aW9uID0gMTsgcmV0dXJuIHdvcmtzcGFjZTsgfVxuICBpZiAoc2VhcmNoLmNvc3RzLmxlbmd0aCA8IHNpemUpXG4gICAgc2VhcmNoID0gY3JlYXRlU2VhcmNoV29ya3NwYWNlKHNpemUpO1xuICBpZiAoKytzZWFyY2guZ2VuZXJhdGlvbiA9PT0gMHg3ZmZmZmZmZikge1xuICAgIHNlYXJjaC5zdGFtcHMuZmlsbCgwKTtcbiAgICBzZWFyY2gudHJhZmZpY0ZpdHMuZmlsbCgwKTtcbiAgICBzZWFyY2guYmFzZVN0YW1wcy5maWxsKDApO1xuICAgIHNlYXJjaC5nZW5lcmF0aW9uID0gMTtcbiAgfVxuICByZXR1cm4gc2VhcmNoO1xufVxuY29uc3QgZ2VvbWV0cnlNYXNrcyA9IG5ldyBNYXA8c3RyaW5nLCBPY2N1cGFuY3lNYXNrW11bXT4oKTtcbmZ1bmN0aW9uIG1hc2tzRm9yKHNoaXA6VW5pdCxjZWxsOm51bWJlcik6T2NjdXBhbmN5TWFza1tdW10ge1xuICBjb25zdCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApISxrZXk9YCR7c2hpcC5raW5kfToke3Byb2ZpbGUubGVuZ3RofToke3Byb2ZpbGUuYmVhbX06JHtjZWxsfWA7XG4gIGNvbnN0IGNhY2hlZD1nZW9tZXRyeU1hc2tzLmdldChrZXkpO2lmKGNhY2hlZClyZXR1cm4gY2FjaGVkO1xuICBjb25zdCBwcmVwYXJlZD1jZWxsPT09MzIgPyBwcmVwYXJlZE1hc2tzIDogY2VsbD09PTY0ID8gcHJlcGFyZWRNYXNrczY0IDogdW5kZWZpbmVkO1xuICBjb25zdCBtYXNrcz1wcmVwYXJlZCAmJiBzaGlwU2NhbGUoc2hpcCk9PT1ERUZBVUxUX1NISVBfU0NBTEUgPyBwcmVwYXJlZFtzaGlwLmtpbmQgYXMga2V5b2YgdHlwZW9mIHByZXBhcmVkTWFza3NdIGFzIE9jY3VwYW5jeU1hc2tbXVtdXG4gICAgOiBidWlsZE5hdmlnYXRpb25NYXNrcyhwcm9maWxlLmh1bGwsY2VsbCk7XG4gIC8vIEpTT04tcmVzdG9yZWQgbWFwcyB1c2UgaWRlbnRpY2FsIGxvY2FsIGdlb21ldHJ5LiBIb2xkIGEgYm91bmRlZCBzZXQgb2ZcbiAgLy8gbnVtZXJpYyBzdGVuY2lscywgd2l0aG91dCBtYXAsIHNoaXAgb3Igb3JkZXIga2V5cy5cbiAgaWYoZ2VvbWV0cnlNYXNrcy5zaXplPj02NClnZW9tZXRyeU1hc2tzLmRlbGV0ZShnZW9tZXRyeU1hc2tzLmtleXMoKS5uZXh0KCkudmFsdWUhKTtcbiAgZ2VvbWV0cnlNYXNrcy5zZXQoa2V5LG1hc2tzKTtyZXR1cm4gbWFza3M7XG59XG5mdW5jdGlvbiBncmlkRm9yKG1hcDogU2VhTWFwLCBzaGlwOiBVbml0KSB7XG4gIGNvbnN0IHQgPSBtYXAudGVycmFpbiEsIGtleSA9IGAke3NoaXAua2luZH06JHtzaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RofToke21hcC53aWR0aH06JHttYXAuaGVpZ2h0fToke3QuY2VsbH06JHt0LmNvbHN9OiR7dC5yb3dzfWA7XG4gIGxldCBncm91cCA9IGdyaWRzLmdldCh0KTtcbiAgaWYgKCFncm91cCkge1xuICAgIGdyb3VwID0gbmV3IE1hcCgpO1xuICAgIGdyaWRzLnNldCh0LCBncm91cCk7XG4gIH1cbiAgbGV0IGdyaWQgPSBncm91cC5nZXQoa2V5KTtcbiAgaWYgKCFncmlkIHx8IGdyaWQuY2VsbHMgIT09IHQuY2VsbHMpIHtcbiAgICAvLyBGdWxsIHRlcnJhaW4gcmVzb2x1dGlvbjogdGhlIHZlc3NlbCdzIHN3ZXB0IGZvb3RwcmludHMgYXJlIGluZGVwZW5kZW50XG4gICAgLy8gb2YgbWFwIHBvc2l0aW9uIGFuZCBjYW4gYmUgcmV1c2VkIGFzIGV4YWN0IG9jY3VwYW5jeSBzdGVuY2lscy5cbiAgICBjb25zdCBjZWxsID0gdC5jZWxsLCBjb2xzID0gTWF0aC5jZWlsKG1hcC53aWR0aCAvIGNlbGwpLCByb3dzID0gTWF0aC5jZWlsKG1hcC5oZWlnaHQgLyBjZWxsKTtcbiAgICBjb25zdCBzaXplID0gY29scyAqIHJvd3MgKiBESVJFQ1RJT05TO1xuICAgIGNvbnN0IG1hc2tzPW1hc2tzRm9yKHNoaXAsdC5jZWxsKTtcbiAgICBjb25zdCB3YXRlciA9IG5ldyBVaW50OEFycmF5KGNvbHMgKiByb3dzKTtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IE1hdGgubWluKHJvd3MsdC5yb3dzKSAmJiAoeSsuNSkqY2VsbCA8IG1hcC5oZWlnaHQ7IHkrKylcbiAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgTWF0aC5taW4oY29scyx0LmNvbHMpICYmICh4Ky41KSpjZWxsIDwgbWFwLndpZHRoOyB4KyspXG4gICAgICAgIHdhdGVyW3kqY29scyt4XSA9IENFTExfR1JPVU5EW3QuY2VsbHNbeSp0LmNvbHMreF0gPz8gJy4nXT8uc2VhID8gMSA6IDA7XG4gICAgZ3JpZCA9IHsgY2VsbHM6IHQuY2VsbHMsIGNlbGwsIGNvbHMsIHJvd3MsIHdhdGVyLCBtYXNrcywgZml0czogbmV3IEludDhBcnJheShzaXplKSwgdHVybnM6IG5ldyBJbnQ4QXJyYXkoc2l6ZSAqIDIpLCBtb3ZlczogbmV3IEludDhBcnJheShzaXplICogNCkgfTtcbiAgICBpZiAoZ3JvdXAuc2l6ZSA+PSAzMilcbiAgICAgIGdyb3VwLmRlbGV0ZShncm91cC5rZXlzKCkubmV4dCgpLnZhbHVlISk7XG4gICAgZ3JvdXAuc2V0KGtleSwgZ3JpZCk7XG4gIH1cbiAgcmV0dXJuIGdyaWQ7XG59XG5mdW5jdGlvbiBtYXNrRml0cyhtYXA6IFNlYU1hcCwgZ3JpZDogTmF2R3JpZCwgaWQ6IG51bWJlciwgbWFzazogT2NjdXBhbmN5TWFzaykge1xuICBjb25zdCB0aWxlID0gTWF0aC5mbG9vcihpZCAvIERJUkVDVElPTlMpLCBjb2wgPSB0aWxlICUgZ3JpZC5jb2xzLCByb3cgPSBNYXRoLmZsb29yKHRpbGUgLyBncmlkLmNvbHMpLCB4ID0gY29sICogZ3JpZC5jZWxsLCB5ID0gcm93ICogZ3JpZC5jZWxsO1xuICBjb25zdCBbbGVmdCwgdG9wLCByaWdodCwgYm90dG9tXSA9IG1hc2suYm91bmRzO1xuICBpZiAoeCArIGxlZnQgPCAtMWUtNyB8fCB5ICsgdG9wIDwgLTFlLTcgfHwgeCArIHJpZ2h0ID4gbWFwLndpZHRoICsgMWUtNyB8fCB5ICsgYm90dG9tID4gbWFwLmhlaWdodCArIDFlLTcpXG4gICAgcmV0dXJuIGZhbHNlO1xuICAvLyBNb3N0IGxhdHRpY2Ugc3RhdGVzIGFyZSBvZmZzaG9yZS4gVGhlIGludGVncmFsIGZpZWxkIHByb3ZlcyB0aGUgZW50aXJlXG4gIC8vIHN0ZW5jaWwncyBib3VuZHMgY2xlYXIgYmVmb3JlIHdlIGluc3BlY3QgaXRzIGluZGl2aWR1YWwgY292ZXJlZCBjZWxscy5cbiAgaWYgKG9wZW5XYXRlckJveChtYXAsIHggKyBsZWZ0LCB5ICsgdG9wLCB4ICsgcmlnaHQsIHkgKyBib3R0b20pKVxuICAgIHJldHVybiB0cnVlO1xuICBjb25zdCB0ID0gbWFwLnRlcnJhaW4hO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1hc2suY2VsbHMubGVuZ3RoOyBpICs9IDIpIHtcbiAgICBjb25zdCB4eCA9IGNvbCArIG1hc2suY2VsbHNbaV0hLCB5eSA9IHJvdyArIG1hc2suY2VsbHNbaSArIDFdITtcbiAgICBpZiAoeHggPCAwIHx8IHl5IDwgMCB8fCB4eCA+PSB0LmNvbHMgfHwgeXkgPj0gdC5yb3dzIHx8ICFDRUxMX0dST1VORFt0LmNlbGxzW3l5ICogdC5jb2xzICsgeHhdID8/ICcuJ10/LnNlYSlcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmNsYXNzIEZyb250aWVyIHtcbiAgbGVuZ3RoID0gMDtcbiAgcG9wcGVkQ29zdCA9IDA7XG4gIHByaXZhdGUgaWRzID0gbmV3IEludDMyQXJyYXkoMTAyNCk7XG4gIHByaXZhdGUgY29zdHMgPSBuZXcgRmxvYXQ2NEFycmF5KDEwMjQpO1xuICBwcml2YXRlIHNjb3JlcyA9IG5ldyBGbG9hdDY0QXJyYXkoMTAyNCk7XG4gIHJlc2V0KCkge1xuICAgIHRoaXMubGVuZ3RoID0gMDtcbiAgICAvLyBTY3JhdGNoIGNvbnRhaW5zIG9ubHkgbnVtZXJpYyBnZW9tZXRyeSwgbmV2ZXIgdW5pdHMgb3Igb3JkZXJzLiBLZWVwXG4gICAgLy8gb3JkaW5hcnkgc2VhcmNoZXMgYWxsb2NhdGlvbi1mcmVlIHdoaWxlIGJvdW5kaW5nIHVudXN1YWxseSBsYXJnZSBoZWFwcy5cbiAgICBpZiAodGhpcy5pZHMubGVuZ3RoID4gNjU1MzYpIHtcbiAgICAgIHRoaXMuaWRzID0gbmV3IEludDMyQXJyYXkoNjU1MzYpO1xuICAgICAgdGhpcy5jb3N0cyA9IG5ldyBGbG9hdDY0QXJyYXkoNjU1MzYpO1xuICAgICAgdGhpcy5zY29yZXMgPSBuZXcgRmxvYXQ2NEFycmF5KDY1NTM2KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgc2F2ZSgpOiB7aWQ6bnVtYmVyO2Nvc3Q6bnVtYmVyO3Njb3JlOm51bWJlcn1bXSB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20oe2xlbmd0aDp0aGlzLmxlbmd0aH0sKF8saSk9Pih7aWQ6dGhpcy5pZHNbaV0hLGNvc3Q6dGhpcy5jb3N0c1tpXSEsc2NvcmU6dGhpcy5zY29yZXNbaV0hfSkpO1xuICB9XG4gIHJlc3RvcmUoc2xvdHM6cmVhZG9ubHkge2lkOm51bWJlcjtjb3N0Om51bWJlcjtzY29yZTpudW1iZXJ9W10pIHtcbiAgICB0aGlzLnJlc2V0KCk7XG4gICAgY29uc3QgY2FwYWNpdHk9TWF0aC5tYXgoMTAyNCwyKipNYXRoLmNlaWwoTWF0aC5sb2cyKE1hdGgubWF4KDEsc2xvdHMubGVuZ3RoKSkpKTtcbiAgICBpZih0aGlzLmlkcy5sZW5ndGg8Y2FwYWNpdHkpe3RoaXMuaWRzPW5ldyBJbnQzMkFycmF5KGNhcGFjaXR5KTt0aGlzLmNvc3RzPW5ldyBGbG9hdDY0QXJyYXkoY2FwYWNpdHkpO3RoaXMuc2NvcmVzPW5ldyBGbG9hdDY0QXJyYXkoY2FwYWNpdHkpO31cbiAgICAvLyBFeGFjdCBoZWFwIHNsb3RzIGluY2x1ZGUgZHVwbGljYXRlcyBhbmQgc3RhbGUgZW50cmllcy4gUmUtcHVzaGluZyB0aGVtXG4gICAgLy8gY291bGQgY2hhbmdlIGVxdWFsLXNjb3JlIG9yZGVyaW5nIGFmdGVyIGEgc25hcHNob3QgcmVzdG9yZS5cbiAgICB0aGlzLmxlbmd0aD1zbG90cy5sZW5ndGg7XG4gICAgZm9yKGxldCBpPTA7aTxzbG90cy5sZW5ndGg7aSsrKXtjb25zdCBzbG90PXNsb3RzW2ldITt0aGlzLmlkc1tpXT1zbG90LmlkO3RoaXMuY29zdHNbaV09c2xvdC5jb3N0O3RoaXMuc2NvcmVzW2ldPXNsb3Quc2NvcmU7fVxuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHB1c2goaWQ6IG51bWJlciwgY29zdDogbnVtYmVyLCBzY29yZTogbnVtYmVyKSB7XG4gICAgaWYgKHRoaXMubGVuZ3RoID09PSB0aGlzLmlkcy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGlkcyA9IG5ldyBJbnQzMkFycmF5KHRoaXMubGVuZ3RoICogMiksIGNvc3RzID0gbmV3IEZsb2F0NjRBcnJheSh0aGlzLmxlbmd0aCAqIDIpLCBzY29yZXMgPSBuZXcgRmxvYXQ2NEFycmF5KHRoaXMubGVuZ3RoICogMik7XG4gICAgICBpZHMuc2V0KHRoaXMuaWRzKTsgY29zdHMuc2V0KHRoaXMuY29zdHMpOyBzY29yZXMuc2V0KHRoaXMuc2NvcmVzKTtcbiAgICAgIHRoaXMuaWRzID0gaWRzOyB0aGlzLmNvc3RzID0gY29zdHM7IHRoaXMuc2NvcmVzID0gc2NvcmVzO1xuICAgIH1cbiAgICBsZXQgaSA9IHRoaXMubGVuZ3RoKys7XG4gICAgd2hpbGUgKGkpIHtcbiAgICAgIGNvbnN0IHBhcmVudCA9IChpIC0gMSkgPj4+IDI7XG4gICAgICBpZiAoIXRoaXMubGVzcyhzY29yZSwgaWQsIHRoaXMuc2NvcmVzW3BhcmVudF0hLCB0aGlzLmlkc1twYXJlbnRdISkpXG4gICAgICAgIGJyZWFrO1xuICAgICAgdGhpcy5jb3B5KHBhcmVudCwgaSk7XG4gICAgICBpID0gcGFyZW50O1xuICAgIH1cbiAgICB0aGlzLmlkc1tpXSA9IGlkOyB0aGlzLmNvc3RzW2ldID0gY29zdDsgdGhpcy5zY29yZXNbaV0gPSBzY29yZTtcbiAgfVxuICBwcml2YXRlIGNvcHkoZnJvbTogbnVtYmVyLCB0bzogbnVtYmVyKSB7IHRoaXMuaWRzW3RvXSA9IHRoaXMuaWRzW2Zyb21dITsgdGhpcy5jb3N0c1t0b10gPSB0aGlzLmNvc3RzW2Zyb21dITsgdGhpcy5zY29yZXNbdG9dID0gdGhpcy5zY29yZXNbZnJvbV0hOyB9XG4gIHByaXZhdGUgbGVzcyhhU2NvcmU6IG51bWJlciwgYUlkOiBudW1iZXIsIGJTY29yZTogbnVtYmVyLCBiSWQ6IG51bWJlcikgeyByZXR1cm4gYVNjb3JlIDwgYlNjb3JlIHx8IChhU2NvcmUgPT09IGJTY29yZSAmJiBhSWQgPCBiSWQpOyB9XG4gIHBvcCgpIHtcbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLmlkc1swXSEsIGxhc3QgPSAtLXRoaXMubGVuZ3RoO1xuICAgIHRoaXMucG9wcGVkQ29zdCA9IHRoaXMuY29zdHNbMF0hO1xuICAgIGNvbnN0IGlkID0gdGhpcy5pZHNbbGFzdF0hLCBjb3N0ID0gdGhpcy5jb3N0c1tsYXN0XSEsIHNjb3JlID0gdGhpcy5zY29yZXNbbGFzdF0hO1xuICAgIGlmIChsYXN0KSB7XG4gICAgICBsZXQgaSA9IDA7XG4gICAgICB3aGlsZSAoaSAqIDQgKyAxIDwgbGFzdCkge1xuICAgICAgICBsZXQgY2hpbGQgPSBpICogNCArIDE7XG4gICAgICAgIGNvbnN0IGVuZCA9IE1hdGgubWluKGxhc3QsIGNoaWxkICsgNCk7XG4gICAgICAgIGZvciAobGV0IG5leHQgPSBjaGlsZCArIDE7IG5leHQgPCBlbmQ7IG5leHQrKylcbiAgICAgICAgICBpZiAodGhpcy5sZXNzKHRoaXMuc2NvcmVzW25leHRdISwgdGhpcy5pZHNbbmV4dF0hLCB0aGlzLnNjb3Jlc1tjaGlsZF0hLCB0aGlzLmlkc1tjaGlsZF0hKSlcbiAgICAgICAgICAgIGNoaWxkID0gbmV4dDtcbiAgICAgICAgaWYgKCF0aGlzLmxlc3ModGhpcy5zY29yZXNbY2hpbGRdISwgdGhpcy5pZHNbY2hpbGRdISwgc2NvcmUsIGlkKSlcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgdGhpcy5jb3B5KGNoaWxkLCBpKTtcbiAgICAgICAgaSA9IGNoaWxkO1xuICAgICAgfVxuICAgICAgdGhpcy5pZHNbaV0gPSBpZDsgdGhpcy5jb3N0c1tpXSA9IGNvc3Q7IHRoaXMuc2NvcmVzW2ldID0gc2NvcmU7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbn1cbmNvbnN0IHJvdXRlRnJvbnRpZXIgPSBuZXcgRnJvbnRpZXIoKSwgZGlzdGFuY2VGcm9udGllciA9IG5ldyBGcm9udGllcigpO1xuY29uc3QgZW1wdHlUcmFmZmljID0gKCkgPT4gdHJ1ZTtcbnR5cGUgU2VhRGlzdGFuY2VzID0geyBjZWxsczogc3RyaW5nOyBmaWVsZDogU2VhUG90ZW50aWFsIH07XG5jb25zdCBzZWFEaXN0YW5jZXMgPSBuZXcgV2Vha01hcDxvYmplY3QsIE1hcDxzdHJpbmcsIFNlYURpc3RhbmNlcz4+KCk7XG4vKiogT3B0aW1pc3RpYyBwb2ludC12ZXNzZWwgZGlzdGFuY2VzIHRvIG9uZSBsYW5kbWFyayBuZWFyIHRoZSBnb2FsLiBOZWFyYnlcbiAqIGZsZWV0IGRlc3RpbmF0aW9ucyBzaGFyZSBpdDsgZWFjaCBzZWFyY2ggc3VidHJhY3RzIGl0cyBvd24gdGVybWluYWwtcmVnaW9uXG4gKiBwb3RlbnRpYWwuIEh1bGwgY2xlYXJhbmNlIGFuZCBydWRkZXIgY29zdHMgY2FuIG9ubHkgbWFrZSB0aGUgYWN0dWFsIHJvdXRlXG4gKiBsb25nZXIuIFRoaXMgZmllbGQgbmV2ZXIgYXBwcm92ZXMgYW4gZWRnZS5cbiAqL1xuZnVuY3Rpb24gdGVycmFpbkRpc3RhbmNlcyhtYXA6IFNlYU1hcCwgZ3JpZDogTmF2R3JpZCwgc3RhcnQ6UG9pbnQsdGFyZ2V0OiBQb2ludCwgZGlyZWN0aW9uQ29zdHM6IHJlYWRvbmx5IG51bWJlcltdKTogU2VhUG90ZW50aWFsIHwgdW5kZWZpbmVkIHtcbiAgY29uc3QgdGVycmFpbiA9IG1hcC50ZXJyYWluISwgc3BhbiA9IDE2LCBibG9ja1ggPSBNYXRoLmZsb29yKHRhcmdldC54IC8gKGdyaWQuY2VsbCAqIHNwYW4pKSwgYmxvY2tZID0gTWF0aC5mbG9vcih0YXJnZXQueSAvIChncmlkLmNlbGwgKiBzcGFuKSk7XG4gIGNvbnN0IGZyb21YPU1hdGguZmxvb3Ioc3RhcnQueC8oZ3JpZC5jZWxsKnNwYW4pKSxmcm9tWT1NYXRoLmZsb29yKHN0YXJ0LnkvKGdyaWQuY2VsbCpzcGFuKSk7XG4gIGNvbnN0IGtleSA9IGAke21hcC53aWR0aH06JHttYXAuaGVpZ2h0fToke2dyaWQuY2VsbH06JHtncmlkLmNvbHN9OiR7Z3JpZC5yb3dzfToke2Zyb21YfToke2Zyb21ZfToke2Jsb2NrWH06JHtibG9ja1l9OiR7ZGlyZWN0aW9uQ29zdHMuam9pbignOicpfWA7XG4gIGxldCBncm91cCA9IHNlYURpc3RhbmNlcy5nZXQodGVycmFpbik7XG4gIGlmICghZ3JvdXApIHsgZ3JvdXAgPSBuZXcgTWFwKCk7IHNlYURpc3RhbmNlcy5zZXQodGVycmFpbiwgZ3JvdXApOyB9XG4gIGNvbnN0IGNhY2hlZCA9IGdyb3VwLmdldChrZXkpO1xuICBpZiAoY2FjaGVkPy5jZWxscyA9PT0gdGVycmFpbi5jZWxscykgcmV0dXJuIGNhY2hlZC5maWVsZDtcbiAgY29uc3Qgb3BlbiA9ICh4OiBudW1iZXIsIHk6IG51bWJlcikgPT4geCA+PSAwICYmIHkgPj0gMCAmJiB4IDwgZ3JpZC5jb2xzICYmIHkgPCBncmlkLnJvd3MgJiYgZ3JpZC53YXRlclt5KmdyaWQuY29scyt4XSA9PT0gMTtcbiAgLy8gQ2hvb3NlIHRoZSBzYW1lIG5lYXJieSB3YXRlciBsYW5kbWFyayBmb3IgYWxsIGdvYWxzIGluIHRoaXMgYmxvY2suXG4gIC8vIEluY2x1ZGluZyB0d28gZXh0cmEgY2VsbHMgYWxzbyBjb3ZlcnMgYSBnb2FsIG9uIGEgY29hc3RhbCBibG9jayBlZGdlLlxuICBjb25zdCBjZW50ZXJYID0gKGJsb2NrWCArIC41KSAqIHNwYW4sIGNlbnRlclkgPSAoYmxvY2tZICsgLjUpICogc3BhbjtcbiAgbGV0IHNlZWQgPSAtMSwgc2VlZEdhcCA9IEluZmluaXR5O1xuICBmb3IgKGxldCB5ID0gTWF0aC5tYXgoMCwgYmxvY2tZICogc3BhbiAtIDIpOyB5IDwgTWF0aC5taW4oZ3JpZC5yb3dzLCAoYmxvY2tZICsgMSkgKiBzcGFuICsgMik7IHkrKylcbiAgICBmb3IgKGxldCB4ID0gTWF0aC5tYXgoMCwgYmxvY2tYICogc3BhbiAtIDIpOyB4IDwgTWF0aC5taW4oZ3JpZC5jb2xzLCAoYmxvY2tYICsgMSkgKiBzcGFuICsgMik7IHgrKykge1xuICAgICAgaWYgKCFvcGVuKHgsIHkpKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGlkID0geSAqIGdyaWQuY29scyArIHgsIGdhcCA9ICh4ICsgLjUgLSBjZW50ZXJYKSAqKiAyICsgKHkgKyAuNSAtIGNlbnRlclkpICoqIDI7XG4gICAgICBpZiAoZ2FwIDwgc2VlZEdhcCkgeyBzZWVkID0gaWQ7IHNlZWRHYXAgPSBnYXA7IH1cbiAgICB9XG4gIGlmKHNlZWQ8MClyZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBib3VuZHM9e2xlZnQ6TWF0aC5tYXgoMCwoTWF0aC5taW4oZnJvbVgsYmxvY2tYKS0yKSpzcGFuKSx0b3A6TWF0aC5tYXgoMCwoTWF0aC5taW4oZnJvbVksYmxvY2tZKS0yKSpzcGFuKSxcbiAgICByaWdodDpNYXRoLm1pbihncmlkLmNvbHMsKE1hdGgubWF4KGZyb21YLGJsb2NrWCkrMykqc3BhbiksYm90dG9tOk1hdGgubWluKGdyaWQucm93cywoTWF0aC5tYXgoZnJvbVksYmxvY2tZKSszKSpzcGFuKX07XG4gIGNvbnN0IGZpZWxkPWJ1aWxkU2VhUG90ZW50aWFsKGdyaWQud2F0ZXIsZ3JpZC5jb2xzLGdyaWQucm93cyxncmlkLmNlbGwsYm91bmRzLFxuICAgIHt4OnNlZWQlZ3JpZC5jb2xzLHk6TWF0aC5mbG9vcihzZWVkL2dyaWQuY29scyl9LGRpcmVjdGlvbkNvc3RzLGRpc3RhbmNlRnJvbnRpZXIpO1xuICAvLyBUZXJyYWluIG9iamVjdHMgYXJlIHdlYWtseSBoZWxkLCBhbmQgbW92aW5nIHRhcmdldHMgcmV0YWluIG9ubHkgYSBzbWFsbFxuICAvLyBib3VuZGVkIHNldCBvZiBkZXN0aW5hdGlvbiByZWdpb25zLiBFbnRyaWVzIGNvbnRhaW4gbm8gdW5pdHMgb3Igb3JkZXJzLlxuICBpZiAoZ3JvdXAuc2l6ZSA+PSA4ICYmICFncm91cC5oYXMoa2V5KSkgZ3JvdXAuZGVsZXRlKGdyb3VwLmtleXMoKS5uZXh0KCkudmFsdWUhKTtcbiAgZ3JvdXAuc2V0KGtleSwgeyBjZWxsczogdGVycmFpbi5jZWxscywgZmllbGQgfSk7XG4gIHJldHVybiBmaWVsZDtcbn1cbi8qKiBTdHJhaWdodCB0cmF2ZWwgaXMgZm9yd2FyZCBvciBhc3Rlcm4gYWxvbmcgdGhlIGtlZWwuIEFsbCBjb25uZWN0b3JzIG9iZXlcbiAqIHRoZSBzYW1lIGNvbnN0cmFpbnQgYXMgcm91dGUgZWRnZXM7IGdyaWQgYWxpZ25tZW50IGlzIG5ldmVyIGEgc2lkZS1zbGlwLiAqL1xuZnVuY3Rpb24gcm91dGVUaW1lKG1hcDpTZWFNYXAsc2hpcDpVbml0LGZyb206U2hpcFBvc2UscG9pbnRzOnJlYWRvbmx5IFNoaXBQb3NlW10pIHtcbiAgY29uc3QgbGltaXRzPXNoaXBNb3Rpb25MaW1pdHMoc2hpcCk7bGV0IHRpbWU9MCxwcmV2aW91cz1mcm9tO1xuICBmb3IoY29uc3QgcG9pbnQgb2YgcG9pbnRzKXtcbiAgICBjb25zdCB5YXc9TWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UocHJldmlvdXMuaGVhZGluZyxwb2ludC5oZWFkaW5nKSk7XG4gICAgY29uc3QgZHg9cG9pbnQueC1wcmV2aW91cy54LGR5PXBvaW50LnktcHJldmlvdXMueTtcbiAgICBjb25zdCBwZXJmb3JtYW5jZT1jb3Vyc2VQZXJmb3JtYW5jZShzaGlwLG1hcCxwb2ludC5oZWFkaW5nLHthc3N1bWVUcmltbWVkOnRydWV9KTtcbiAgICBjb25zdCBzcGVlZD1keCpkZXRDb3MocG9pbnQuaGVhZGluZykrZHkqZGV0U2luKHBvaW50LmhlYWRpbmcpPC0xZS03P01hdGgubWluKGxpbWl0cy5yZXZlcnNlU3BlZWQscGVyZm9ybWFuY2UuYXV4aWxpYXJ5U3BlZWQpOk1hdGgubWF4KHBlcmZvcm1hbmNlLnRhcmdldFNwZWVkLHBlcmZvcm1hbmNlLmF1eGlsaWFyeVNwZWVkKTtcbiAgICB0aW1lKz15YXcvTWF0aC5tYXgoMWUtNixsaW1pdHMudHVyblJhdGUpK01hdGguaHlwb3QoZHgsZHkpL01hdGgubWF4KDFlLTYsc3BlZWQpO1xuICAgIHByZXZpb3VzPXBvaW50O1xuICB9XG4gIHJldHVybiB0aW1lO1xufVxuZnVuY3Rpb24ga2VlbENhbmRpZGF0ZXMoc2hpcDpVbml0LGZyb206U2hpcFBvc2UsZ29hbDpQb2ludCAmIHtoZWFkaW5nPzpudW1iZXJ9KTpTaGlwUG9zZVtdW10ge1xuICBjb25zdCBnYXA9TWF0aC5oeXBvdChnb2FsLngtZnJvbS54LGdvYWwueS1mcm9tLnkpO1xuICBpZihnYXA8MWUtNylyZXR1cm4gW2dvYWwuaGVhZGluZz09PXVuZGVmaW5lZCB8fCBNYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShmcm9tLmhlYWRpbmcsZ29hbC5oZWFkaW5nKSk8MWUtNz9bXTpbey4uLmdvYWwsaGVhZGluZzpnb2FsLmhlYWRpbmd9XV07XG4gIGNvbnN0IGRpcmVjdGlvbj1NYXRoLmF0YW4yKGdvYWwueS1mcm9tLnksZ29hbC54LWZyb20ueCk7XG4gIC8vIEFzdGVybiBpcyBhIHNob3J0IG1hbmV1dmVyLCBub3QgYW4gYWx0ZXJuYXRpdmUgY3J1aXNlIGRpcmVjdGlvbi5cbiAgY29uc3QgbGVuZ3RoPXNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGg7XG4gIC8vIEEgcHJlY2lzZSBiZXJ0aCBvciBpdHMgYXBwcm9hY2ggcG9zZSBtYXkgbmVlZCBhIHNob3J0IGFzdGVybiBsZWcgYmVmb3JlXG4gIC8vIHN3aW5naW5nIHRoZSBodWxsIGFsb25nc2lkZS4gUmVxdWlyaW5nIHRoYXQgcG9zZSB0byBzaGFyZSB0aGUgY3VycmVudFxuICAvLyBoZWFkaW5nIHJ1bGVkIG91dCB0aGUgdXNlZnVsIHJldHJlYXQgYW5kIGZvcmNlZCBhIG5lYXItaGFsZi1jaXJjbGUgdHVybi5cbiAgY29uc3QgaGVhZGluZ3M9Z2FwPD0oZ29hbC5oZWFkaW5nIT09dW5kZWZpbmVkP2xlbmd0aDpsZW5ndGgvMik/W2RpcmVjdGlvbixkaXJlY3Rpb24rTWF0aC5QSV06W2RpcmVjdGlvbl07XG4gIHJldHVybiBoZWFkaW5ncy5tYXAoaGVhZGluZz0+e1xuICAgIGNvbnN0IHR1cm5lZD17eDpmcm9tLngseTpmcm9tLnksaGVhZGluZ30sZW5kPXt4OmdvYWwueCx5OmdvYWwueSxoZWFkaW5nfTtcbiAgICBjb25zdCBwb2ludHM9TWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UoZnJvbS5oZWFkaW5nLGhlYWRpbmcpKTwxZS03P1tlbmRdOlt0dXJuZWQsZW5kXTtcbiAgICBpZihnb2FsLmhlYWRpbmchPT11bmRlZmluZWQgJiYgTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UoaGVhZGluZyxnb2FsLmhlYWRpbmcpKT4xZS03KXBvaW50cy5wdXNoKHsuLi5lbmQsaGVhZGluZzpnb2FsLmhlYWRpbmd9KTtcbiAgICByZXR1cm4gcG9pbnRzO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGNvbm5lY3RvckNsZWFyKG1hcDpTZWFNYXAsc2hpcDpVbml0LGZyb206U2hpcFBvc2UscG9pbnRzOlNoaXBQb3NlW10sdHJhZmZpYzooYTpTaGlwUG9zZSxiOlNoaXBQb3NlKT0+Ym9vbGVhbikge1xuICByZXR1cm4gcG9pbnRzLmV2ZXJ5KChwb2ludCxpKT0+e1xuICAgIGNvbnN0IHByZXZpb3VzPXBvaW50c1tpLTFdID8/IGZyb207XG4gICAgcmV0dXJuIGh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAscHJldmlvdXMscG9pbnQpICYmIHRyYWZmaWMocHJldmlvdXMscG9pbnQpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGtlZWxDb25uZWN0b3IobWFwOlNlYU1hcCxzaGlwOlVuaXQsZnJvbTpTaGlwUG9zZSxnb2FsOlBvaW50ICYge2hlYWRpbmc/Om51bWJlcn0sdHJhZmZpYzooYTpTaGlwUG9zZSxiOlNoaXBQb3NlKT0+Ym9vbGVhbik6U2hpcFBvc2VbXXx1bmRlZmluZWQge1xuICByZXR1cm4ga2VlbENhbmRpZGF0ZXMoc2hpcCxmcm9tLGdvYWwpLnNvcnQoKGEsYik9PnJvdXRlVGltZShtYXAsc2hpcCxmcm9tLGEpLXJvdXRlVGltZShtYXAsc2hpcCxmcm9tLGIpKVxuICAgIC5maW5kKHBvaW50cz0+Y29ubmVjdG9yQ2xlYXIobWFwLHNoaXAsZnJvbSxwb2ludHMsdHJhZmZpYykpO1xufVxuLyoqIEEgcGFzc2FnZSBwbGFuIGJlYXRzIHRvIHRoZSBkZXN0aW5hdGlvbidzIGxheWxpbmUsIG5vdCBiYWNrIHRvIHRoZSBkaXJlY3RcbiAqIHRyYWNrIGV2ZXJ5IGZldyBodWxsIGxlbmd0aHMuIFNob3J0ZXIgcGFpcnMgYXJlIG9ubHkgY29hc3RhbCBmYWxsYmFja3MuICovXG5leHBvcnQgZnVuY3Rpb24gc2hpcFRhY2tSb3V0ZShtYXA6U2VhTWFwLHNoaXA6VW5pdCxnb2FsOlNoaXBQb3NlLHRyYWZmaWM6KGE6U2hpcFBvc2UsYjpTaGlwUG9zZSk9PmJvb2xlYW4scHJlZmVycmVkSGVhZGluZz86bnVtYmVyKTpTaGlwUG9zZVtdfHVuZGVmaW5lZCB7XG4gIGNvbnN0IHN0YXJ0PXt4OnNoaXAueCx5OnNoaXAueSxoZWFkaW5nOnNoaXAuc2FpbGluZz8uaGVhZGluZyA/PyAwfTtcbiAgY29uc3QgZHg9Z29hbC54LXN0YXJ0LngsZHk9Z29hbC55LXN0YXJ0LnksZ2FwPU1hdGguaHlwb3QoZHgsZHkpLGxlbmd0aD1zaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoO1xuICBjb25zdCBwZXJmb3JtYW5jZT1jb3Vyc2VQZXJmb3JtYW5jZShzaGlwLG1hcCxNYXRoLmF0YW4yKGR5LGR4KSx7YXNzdW1lVHJpbW1lZDp0cnVlfSk7XG4gIGlmKGdhcDxsZW5ndGggfHwgcGVyZm9ybWFuY2UuY2FsbSB8fCBwZXJmb3JtYW5jZS50cnVlV2luZEFuZ2xlPj1wZXJmb3JtYW5jZS5iZWF0QW5nbGVcbiAgICB8fCAhcGVyZm9ybWFuY2Uubm9HbyAmJiBwZXJmb3JtYW5jZS50YXJnZXRTcGVlZD49cGVyZm9ybWFuY2UuYXV4aWxpYXJ5U3BlZWQgfHwgcGVyZm9ybWFuY2UubWF4Rm9yd2FyZFNwZWVkPD0wKXJldHVybjtcbiAgY29uc3Qgd2luZD13aW5kQXQobWFwLHNoaXApLGFuZ2xlcz1bd2luZC5mcm9tK3BlcmZvcm1hbmNlLmJlYXRBbmdsZSx3aW5kLmZyb20tcGVyZm9ybWFuY2UuYmVhdEFuZ2xlXTtcbiAgY29uc3QgZGlyZWN0aW9ucz1hbmdsZXMubWFwKGhlYWRpbmc9Pih7eDpkZXRDb3MoaGVhZGluZykseTpkZXRTaW4oaGVhZGluZyl9KSk7XG4gIGNvbnN0IGNyb3NzPShhOlBvaW50LGI6UG9pbnQpPT5hLngqYi55LWEueSpiLng7XG4gIC8vIEhvbGQgdGhlIHRhY2sgYWxyZWFkeSBjbG9zZXN0IHRvIHRoZSBib3cgd2hlbiBib3RoIHNpZGVzIGhhdmUgc2VhIHJvb20uXG4gIC8vIFRyaW0vc3VyZ2UgZmx1Y3R1YXRpb25zIG11c3Qgbm90IHJlcGVhdGVkbHkgY2hhbmdlIHRoaXMgc3RyYXRlZ2ljIGNob2ljZS5cbiAgY29uc3QgcHJlZmVycmVkPXByZWZlcnJlZEhlYWRpbmcgPz8gc3RhcnQuaGVhZGluZztcbiAgY29uc3Qgc2lkZXM9WzAsMV0uc29ydCgoYSxiKT0+TWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UocHJlZmVycmVkLGFuZ2xlc1thXSEpKS1NYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShwcmVmZXJyZWQsYW5nbGVzW2JdISkpKTtcbiAgY29uc3QgZGlzdGFuY2VzPVtnYXBdO1xuICBmb3IobGV0IGRpc3RhbmNlPWdhcC8yO2Rpc3RhbmNlPj1sZW5ndGg7ZGlzdGFuY2UvPTIpZGlzdGFuY2VzLnB1c2goZGlzdGFuY2UpO1xuICBpZihkaXN0YW5jZXMuYXQoLTEpIT5sZW5ndGgrMWUtNylkaXN0YW5jZXMucHVzaChsZW5ndGgpO1xuICAvLyBBIG5ld2x5IHBsb3R0ZWQgdm95YWdlIHByZWZlcnMgYSBjb21wbGV0ZSBwYWlyLiBBIG1vdmluZy10YXJnZXQgdXBkYXRlXG4gIC8vIGtlZXBzIHRoZSBjb21taXR0ZWQgdGFjaywgc2hvcnRlbmluZyBpdCBuZWFyIGEgY29hc3QgYmVmb3JlIGNoYW5naW5nIHNpZGUuXG4gIGNvbnN0IGNob2ljZXM9cHJlZmVycmVkSGVhZGluZz09PXVuZGVmaW5lZFxuICAgID8gZGlzdGFuY2VzLmZsYXRNYXAoZGlzdGFuY2U9PnNpZGVzLm1hcChzaWRlPT4oe2Rpc3RhbmNlLHNpZGV9KSkpXG4gICAgOiBzaWRlcy5mbGF0TWFwKHNpZGU9PmRpc3RhbmNlcy5tYXAoZGlzdGFuY2U9Pih7ZGlzdGFuY2Usc2lkZX0pKSk7XG4gIGlmKHNoaXBNb3Rpb25MaW1pdHMoc2hpcCkudHVyblJhdGU8PTFlLTcpcmV0dXJuO1xuICBmb3IoY29uc3Qge2Rpc3RhbmNlLHNpZGV9IG9mIGNob2ljZXMpe1xuICAgIGNvbnN0IGVuZD17eDpzdGFydC54K2R4KmRpc3RhbmNlL2dhcCx5OnN0YXJ0LnkrZHkqZGlzdGFuY2UvZ2FwfTtcbiAgICBjb25zdCBvdGhlcj0xLXNpZGUsYT1kaXJlY3Rpb25zW3NpZGVdISxiPWRpcmVjdGlvbnNbb3RoZXJdISxkZXQ9Y3Jvc3MoYSxiKTtcbiAgICBsZXQgYmVzdDpTaGlwUG9zZVtdfHVuZGVmaW5lZCxiZXN0Q29zdD1JbmZpbml0eTtcbiAgICBjb25zdCBzdGFydGluZ1R1cm49TWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2Uoc3RhcnQuaGVhZGluZyxhbmdsZXNbc2lkZV0hKSk+MWUtNztcbiAgICBmb3IoY29uc3Qgc3RhcnR1cFJhZGl1cyBvZiBzdGFydGluZ1R1cm4/ZGVwYXJ0dXJlUmFkaWkobWFwLHNoaXApOlt2b3lhZ2VUdXJuUmFkaXVzKHNoaXApXSlmb3IoY29uc3QgcmFkaXVzIG9mIHZveWFnZVJhZGlpKHNoaXApKXtcbiAgICAgIGNvbnN0IHNwZWVkTGltaXQ9Y3VydmVTcGVlZExpbWl0KHNoaXAscmFkaXVzKSxzdGFydHVwU3BlZWQ9Y3VydmVTcGVlZExpbWl0KHNoaXAsc3RhcnR1cFJhZGl1cyk7XG4gICAgICBjb25zdCBsZWFkPXN0YXJ0aW5nVHVybj9icmFraW5nRW50cnkoc2hpcCxzdGFydCxzdGFydHVwU3BlZWQpOltdO1xuICAgICAgY29uc3Qgc3RhcnR1cD1jaXJjbGVBcmMobGVhZC5hdCgtMSkgPz8gc3RhcnQsYW5nbGVzW3NpZGVdISxzdGFydHVwUmFkaXVzLHN0YXJ0dXBTcGVlZCk7XG4gICAgICBjb25zdCBzYWlsZWQ9c3RhcnR1cC5hdCgtMSkgPz8gbGVhZC5hdCgtMSkgPz8gc3RhcnQ7XG4gICAgICBjb25zdCBkZWx0YT17eDplbmQueC1zYWlsZWQueCx5OmVuZC55LXNhaWxlZC55fTtcbiAgICAgIGNvbnN0IGZpcnN0PWNyb3NzKGRlbHRhLGIpL2RldCxzZWNvbmQ9Y3Jvc3MoYSxkZWx0YSkvZGV0O1xuICAgICAgY29uc3QgdHVybj1oZWFkaW5nRGlmZmVyZW5jZShhbmdsZXNbc2lkZV0hLGFuZ2xlc1tvdGhlcl0hKTtcbiAgICAgIC8vIEEgY2lyY3VsYXIgdGFjayBzdGFydHMgYmVmb3JlIHRoZSBsYXlsaW5lIGludGVyc2VjdGlvbi4gUGFzc2luZyB0aGVcbiAgICAgIC8vIHNoYXJwIGludGVyc2VjdGlvbiBmaXJzdCB3b3VsZCByZXF1aXJlIGFuIGltcG9zc2libGUgaW5zdGFudCBoZWxtLlxuICAgICAgY29uc3Qgc2V0YmFjaz1yYWRpdXMqTWF0aC50YW4oTWF0aC5hYnModHVybikvMik7XG4gICAgICBpZihmaXJzdDw9c2V0YmFjaysxIHx8IHNlY29uZDw9c2V0YmFjaysxKWNvbnRpbnVlO1xuICAgICAgY29uc3QgZW50cnk6U2hpcFBvc2U9e3g6c2FpbGVkLngrYS54KihmaXJzdC1zZXRiYWNrKSx5OnNhaWxlZC55K2EueSooZmlyc3Qtc2V0YmFjayksaGVhZGluZzphbmdsZXNbc2lkZV0hLGN1cnZhdHVyZTowLHNwZWVkTGltaXR9O1xuICAgICAgY29uc3QgdGFjaz1jaXJjbGVBcmMoZW50cnksYW5nbGVzW290aGVyXSEscmFkaXVzLHNwZWVkTGltaXQpO1xuICAgICAgY29uc3QgZmluaXNoOlNoaXBQb3NlPXsuLi5lbmQsaGVhZGluZzphbmdsZXNbb3RoZXJdISxjdXJ2YXR1cmU6MH07XG4gICAgICBjb25zdCBwb2ludHM9Wy4uLmxlYWQsLi4uc3RhcnR1cCxlbnRyeSwuLi50YWNrLGZpbmlzaF0ubWFwKHBvaW50PT4oey4uLnBvaW50LHRhY2s6dHJ1ZX0pKTtcbiAgICAgIGNvbnN0IGNvc3Q9dm95YWdlVGltZShtYXAsc2hpcCxzdGFydCxwb2ludHMpO1xuICAgICAgaWYoY29zdD49YmVzdENvc3QgfHwgIXZveWFnZUNvcnJpZG9yQ2xlYXIobWFwLHNoaXAsc3RhcnQscG9pbnRzLHRyYWZmaWMpKWNvbnRpbnVlO1xuICAgICAgYmVzdD1wb2ludHM7YmVzdENvc3Q9Y29zdDtcbiAgICB9XG4gICAgaWYoYmVzdClyZXR1cm4gYmVzdDtcbiAgfVxufVxuLyoqIEEgbW92aW5nIGludGVyY2VwdGlvbiBwb2ludCBpcyBub3QgYSBiZXJ0aC4gV2hlbiBhIGNvbXBsZXRlIHJvdW5kZWQgdGFja1xuICogY2Fubm90IGZpdCBiZWZvcmUgdGhhdCBuZWFyIHBvaW50LCBlc3RhYmxpc2ggdXNlZnVsIGNsb3NlLWhhdWxlZCBoZWFkd2F5IG9uXG4gKiBvbmUgY29tbWl0dGVkIGxlZzsgdGhlIHB1cnN1aXQgbmF2aWdhdG9yIHdpbGwgdXBkYXRlIGl0cyBpbnRlcmNlcHRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gcGxhbkJlYXREZXBhcnR1cmUobWFwOlNlYU1hcCxzaGlwOlVuaXQsZ29hbDpTaGlwUG9zZSx0cmFmZmljOihhOlNoaXBQb3NlLGI6U2hpcFBvc2UpPT5ib29sZWFuLHByZWZlcnJlZEhlYWRpbmc/Om51bWJlcik6U2hpcFBvc2VbXXx1bmRlZmluZWQge1xuICBjb25zdCBzdGFydDpTaGlwUG9zZT17eDpzaGlwLngseTpzaGlwLnksaGVhZGluZzpzaGlwLnNhaWxpbmc/LmhlYWRpbmcgPz8gMH07XG4gIGNvbnN0IGJlYXJpbmc9TWF0aC5hdGFuMihnb2FsLnktc3RhcnQueSxnb2FsLngtc3RhcnQueCkscGVyZm9ybWFuY2U9Y291cnNlUGVyZm9ybWFuY2Uoc2hpcCxtYXAsYmVhcmluZyx7YXNzdW1lVHJpbW1lZDp0cnVlfSk7XG4gIGlmKHBlcmZvcm1hbmNlLmNhbG0gfHwgcGVyZm9ybWFuY2UudHJ1ZVdpbmRBbmdsZT49cGVyZm9ybWFuY2UuYmVhdEFuZ2xlIHx8IHNoaXBNb3Rpb25MaW1pdHMoc2hpcCkudHVyblJhdGU8PTFlLTcgfHwgcGVyZm9ybWFuY2UubWF4Rm9yd2FyZFNwZWVkPD0wKXJldHVybjtcbiAgY29uc3Qgd2luZD13aW5kQXQobWFwLHNoaXApLGFuZ2xlcz1bd2luZC5mcm9tK3BlcmZvcm1hbmNlLmJlYXRBbmdsZSx3aW5kLmZyb20tcGVyZm9ybWFuY2UuYmVhdEFuZ2xlXTtcbiAgY29uc3QgdXNlZnVsPWFuZ2xlcy5maWx0ZXIoaGVhZGluZz0+e1xuICAgIGNvbnN0IGRyaXZlPWNvdXJzZVBlcmZvcm1hbmNlKHNoaXAsbWFwLGhlYWRpbmcse2Fzc3VtZVRyaW1tZWQ6dHJ1ZX0pLnRhcmdldFNwZWVkO1xuICAgIHJldHVybiBkcml2ZSpkZXRDb3MoaGVhZGluZ0RpZmZlcmVuY2UoaGVhZGluZyxiZWFyaW5nKSk+TWF0aC5tYXgocGVyZm9ybWFuY2UudGFyZ2V0U3BlZWQscGVyZm9ybWFuY2UuYXV4aWxpYXJ5U3BlZWQpKjEuMTtcbiAgfSk7XG4gIGNvbnN0IHByZWZlcnJlZD1wcmVmZXJyZWRIZWFkaW5nID8/IHN0YXJ0LmhlYWRpbmc7XG4gIHVzZWZ1bC5zb3J0KChhLGIpPT5NYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShwcmVmZXJyZWQsYSkpLU1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKHByZWZlcnJlZCxiKSkpO1xuICBjb25zdCBsZW5ndGg9c2hpcFByb2ZpbGUoc2hpcCkhLmxlbmd0aCoyO1xuICBmb3IoY29uc3QgaGVhZGluZyBvZiB1c2VmdWwpe1xuICAgIGxldCBiZXN0OlNoaXBQb3NlW118dW5kZWZpbmVkLGJlc3RDb3N0PUluZmluaXR5O1xuICAgIGZvcihjb25zdCByYWRpdXMgb2YgZGVwYXJ0dXJlUmFkaWkobWFwLHNoaXApKXtcbiAgICAgIGNvbnN0IHNwZWVkTGltaXQ9Y3VydmVTcGVlZExpbWl0KHNoaXAscmFkaXVzKSxsZWFkPU1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKHN0YXJ0LmhlYWRpbmcsaGVhZGluZykpPjFlLTc/YnJha2luZ0VudHJ5KHNoaXAsc3RhcnQsc3BlZWRMaW1pdCk6W107XG4gICAgICBjb25zdCBhcmM9Y2lyY2xlQXJjKGxlYWQuYXQoLTEpID8/IHN0YXJ0LGhlYWRpbmcscmFkaXVzLHNwZWVkTGltaXQpLGVudHJ5PWFyYy5hdCgtMSkgPz8gbGVhZC5hdCgtMSkgPz8gc3RhcnQ7XG4gICAgICBjb25zdCBmaW5pc2g6U2hpcFBvc2U9e3g6ZW50cnkueCtsZW5ndGgqZGV0Q29zKGhlYWRpbmcpLHk6ZW50cnkueStsZW5ndGgqZGV0U2luKGhlYWRpbmcpLGhlYWRpbmcsY3VydmF0dXJlOjB9O1xuICAgICAgY29uc3QgcG9pbnRzPVsuLi5sZWFkLC4uLmFyYyxmaW5pc2hdLm1hcChwb2ludD0+KHsuLi5wb2ludCx0YWNrOnRydWV9KSksY29zdD12b3lhZ2VUaW1lKG1hcCxzaGlwLHN0YXJ0LHBvaW50cyk7XG4gICAgICBpZihjb3N0Pj1iZXN0Q29zdCB8fCAhdm95YWdlQ29ycmlkb3JDbGVhcihtYXAsc2hpcCxzdGFydCxwb2ludHMsdHJhZmZpYykpY29udGludWU7XG4gICAgICBiZXN0PXBvaW50cztiZXN0Q29zdD1jb3N0O1xuICAgIH1cbiAgICBpZihiZXN0KXJldHVybiBiZXN0O1xuICB9XG59XG5mdW5jdGlvbiBkZXBhcnR1cmVSb3V0ZShtYXA6U2VhTWFwLHNoaXA6VW5pdCxnb2FsOlBvaW50LHRyYWZmaWM6KGE6U2hpcFBvc2UsYjpTaGlwUG9zZSk9PmJvb2xlYW4sbGF0dGljZUVzY2FwZT1mYWxzZSk6U2hpcFBvc2VbXXx1bmRlZmluZWQge1xuICBjb25zdCBzdGFydD17eDpzaGlwLngseTpzaGlwLnksaGVhZGluZzpzaGlwLnNhaWxpbmc/LmhlYWRpbmcgPz8gMH0sbGVuZ3RoPXNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGg7XG4gIGNvbnN0IGRlc2lyZWQ9TWF0aC5hdGFuMihnb2FsLnktc3RhcnQueSxnb2FsLngtc3RhcnQueCk7XG4gIGNvbnN0IGRpZmZlcmVuY2VzPVtoZWFkaW5nRGlmZmVyZW5jZShzdGFydC5oZWFkaW5nLGRlc2lyZWQpLGhlYWRpbmdEaWZmZXJlbmNlKHN0YXJ0LmhlYWRpbmcsZGVzaXJlZCtNYXRoLlBJKV07XG4gIGZvcihjb25zdCBkaWZmZXJlbmNlIG9mIGRpZmZlcmVuY2VzKWZvcihjb25zdCBsZXZlciBvZiBbbGVuZ3RoLzIsLWxlbmd0aC8yXSl7XG4gICAgaWYoTWF0aC5hYnMoZGlmZmVyZW5jZSk8MWUtNyljb250aW51ZTtcbiAgICBjb25zdCBhbmdsZT1NYXRoLm1heCgtTWF0aC5QSS8yLE1hdGgubWluKE1hdGguUEkvMixkaWZmZXJlbmNlKSk7XG4gICAgY29uc3QgcGl2b3Q9e3g6c3RhcnQueC1sZXZlcipkZXRDb3Moc3RhcnQuaGVhZGluZykseTpzdGFydC55LWxldmVyKmRldFNpbihzdGFydC5oZWFkaW5nKX07XG4gICAgY29uc3QgaGVhZGluZz1zdGFydC5oZWFkaW5nK2FuZ2xlLGVuZD17eDpwaXZvdC54K2xldmVyKmRldENvcyhoZWFkaW5nKSx5OnBpdm90LnkrbGV2ZXIqZGV0U2luKGhlYWRpbmcpLGhlYWRpbmcscGl2b3R9O1xuICAgIGlmKGh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAsc3RhcnQsZW5kKSAmJiB0cmFmZmljKHN0YXJ0LGVuZCkpcmV0dXJuW2VuZF07XG4gIH1cbiAgLy8gSW4gYSBjaGFubmVsIHRvbyBuYXJyb3cgdG8gdHVybiwgdHJhdmVsIGFsb25nIHRoZSBjdXJyZW50IGtlZWwgdG8gYW5cbiAgLy8gb3BlbmluZy4gQmFja2luZyBvdXQgcmVtYWlucyBwb3NzaWJsZSB3aXRob3V0IGludmVudGluZyBsYXRlcmFsIHRocnVzdC5cbiAgbGV0IGVzY2FwZTpTaGlwUG9zZXx1bmRlZmluZWQ7XG4gIGZvcihjb25zdCBkaXJlY3Rpb24gb2YgWzEsLTFdKWZvcihsZXQgZGlzdGFuY2U9bWFwLnRlcnJhaW4hLmNlbGw7ZGlzdGFuY2U8PWxlbmd0aCo0O2Rpc3RhbmNlKz1tYXAudGVycmFpbiEuY2VsbCl7XG4gICAgY29uc3QgZW5kPXt4OnN0YXJ0LngrZGlyZWN0aW9uKmRpc3RhbmNlKmRldENvcyhzdGFydC5oZWFkaW5nKSx5OnN0YXJ0LnkrZGlyZWN0aW9uKmRpc3RhbmNlKmRldFNpbihzdGFydC5oZWFkaW5nKSxoZWFkaW5nOnN0YXJ0LmhlYWRpbmd9O1xuICAgIGlmKCFodWxsUGFzc2FnZUNsZWFyKG1hcCxzaGlwLHN0YXJ0LGVuZCkgfHwgIXRyYWZmaWMoc3RhcnQsZW5kKSlicmVhaztcbiAgICBpZihrZWVsQ29ubmVjdG9yKG1hcCxzaGlwLGVuZCxnb2FsLHRyYWZmaWMpKXJldHVybltlbmRdO1xuICAgIGlmKGxhdHRpY2VFc2NhcGUgJiYgIWVzY2FwZSl7XG4gICAgICBjb25zdCBjZWxsPW1hcC50ZXJyYWluIS5jZWxsLGNvbD1NYXRoLmZsb29yKGVuZC54L2NlbGwpLHJvdz1NYXRoLmZsb29yKGVuZC55L2NlbGwpO1xuICAgICAgZm9yKGxldCB5PXJvdy0xO3k8PXJvdysxICYmICFlc2NhcGU7eSsrKWZvcihsZXQgeD1jb2wtMTt4PD1jb2wrMSAmJiAhZXNjYXBlO3grKylmb3IobGV0IGg9MDtoPERJUkVDVElPTlM7aCsrKXtcbiAgICAgICAgY29uc3QgZW50cmFuY2U9e3g6KHgrLjUpKmNlbGwseTooeSsuNSkqY2VsbCxoZWFkaW5nOmgqQU5HTEV9O1xuICAgICAgICBpZihodWxsRml0cyhtYXAsc2hpcCxlbnRyYW5jZSkgJiYga2VlbENvbm5lY3RvcihtYXAsc2hpcCxlbmQsZW50cmFuY2UsdHJhZmZpYykpe2VzY2FwZT1lbmQ7YnJlYWs7fVxuICAgICAgfVxuICAgIH1cbiAgfVxuICAvLyBCYWNraW5nIGF3YXkgZnJvbSBhIGNyb3NzaW5nIGh1bGwgbmVlZCBvbmx5IHJlY292ZXIgYSB2YWxpZCBsYXR0aWNlXG4gIC8vIGVudHJhbmNlLiBUaGUgY29hc3QgbWF5IHN0aWxsIHJlcXVpcmUgYSBkZXRvdXIgYWZ0ZXIgdGhhdCBlbnRyYW5jZTtcbiAgLy8gaW5zaXN0aW5nIG9uIGEgZGlyZWN0IGdvYWwgY29ubmVjdG9yIHdvdWxkIGxlYXZlIGEgcmV2ZXJzaWJsZSBqYW0gc3R1Y2suXG4gIGlmKGVzY2FwZSlyZXR1cm5bey4uLmVzY2FwZSxleGFjdDp0cnVlfV07XG59XG4vKiogQSBiZXJ0aCBjYW4gYmUgcmVhY2hlZCB3aXRoIGEgdHVybmluZyBhcmMgZXZlbiB3aGVuIGEgc3RyYWlnaHQgZmluYWwgbGVnXG4gKiB3b3VsZCBwb2ludCBpdHMgYm93IHRocm91Z2ggdGhlIGNvYXN0LiBTdGFnZSBpbiBvcGVuIHdhdGVyLCB0aGVuIHN3aW5nIHRoZVxuICogYm93L3N0ZXJuIGFyb3VuZCBhIGZpeGVkIHBvaW50IG9uIHRoZSBrZWVsLiBObyBzaWRld2F5cyBkb2NraW5nIHNob3J0Y3V0LiAqL1xuZnVuY3Rpb24gYXJyaXZhbENvbm5lY3RvckZvcihtYXA6U2VhTWFwLHNoaXA6VW5pdCxnb2FsOlNoaXBQb3NlLHRyYWZmaWM6KGE6U2hpcFBvc2UsYjpTaGlwUG9zZSk9PmJvb2xlYW4pIHtcbiAgY29uc3QgbGVuZ3RoPXNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGg7XG4gIGNvbnN0IGFyY3M6e3N0YWdlOlNoaXBQb3NlO2VuZDpTaGlwUG9zZTthbmdsZTpudW1iZXJ9W109W107XG4gIGZvcihjb25zdCBhbmdsZSBvZiBbTWF0aC5QSS80LC1NYXRoLlBJLzQsTWF0aC5QSS8yLC1NYXRoLlBJLzJdKWZvcihjb25zdCBsZXZlciBvZiBbbGVuZ3RoLzIsLWxlbmd0aC8yXSl7XG4gICAgY29uc3QgcGl2b3Q9e3g6Z29hbC54LWxldmVyKmRldENvcyhnb2FsLmhlYWRpbmcpLHk6Z29hbC55LWxldmVyKmRldFNpbihnb2FsLmhlYWRpbmcpfSxoZWFkaW5nPWdvYWwuaGVhZGluZy1hbmdsZTtcbiAgICBjb25zdCBzdGFnZT17eDpwaXZvdC54K2xldmVyKmRldENvcyhoZWFkaW5nKSx5OnBpdm90LnkrbGV2ZXIqZGV0U2luKGhlYWRpbmcpLGhlYWRpbmd9LGVuZD17Li4uZ29hbCxwaXZvdH07XG4gICAgaWYoIWh1bGxGaXRzKG1hcCxzaGlwLHN0YWdlKSB8fCAhdHJhZmZpYyhzdGFnZSxzdGFnZSkpY29udGludWU7XG4gICAgaWYoIWh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAsc3RhZ2UsZW5kKSB8fCAhdHJhZmZpYyhzdGFnZSxlbmQpKWNvbnRpbnVlO1xuICAgIGFyY3MucHVzaCh7c3RhZ2UsZW5kLGFuZ2xlfSk7XG4gIH1cbiAgLy8gVGhlc2Ugc3dlcHQgYXJyaXZhbCBhcmNzIGRlcGVuZCBvbmx5IG9uIHRoZSBiZXJ0aC4gVmFsaWRhdGUgdGhlbSBvbmNlXG4gIC8vIHBlciBzZWFyY2gsIHRoZW4gcmV1c2UgdGhlbSBhdCBldmVyeSBuZWFyYnkgbGF0dGljZSBzdGF0ZS5cbiAgcmV0dXJuIChmcm9tOlNoaXBQb3NlKTpTaGlwUG9zZVtdfHVuZGVmaW5lZD0+e1xuICAgIGxldCBiZXN0OlNoaXBQb3NlW118dW5kZWZpbmVkLGJlc3RDb3N0PUluZmluaXR5O1xuICAgIGZvcihjb25zdCB7c3RhZ2UsZW5kLGFuZ2xlfSBvZiBhcmNzKXtcbiAgICAgIGNvbnN0IGNvbm5lY3Rpb249a2VlbENvbm5lY3RvcihtYXAsc2hpcCxmcm9tLHN0YWdlLHRyYWZmaWMpO2lmKCFjb25uZWN0aW9uKWNvbnRpbnVlO1xuICAgICAgY29uc3QgbGFzdD1jb25uZWN0aW9uLmF0KC0xKSA/PyBmcm9tO1xuICAgICAgaWYoIWh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAsbGFzdCxzdGFnZSkgfHwgIXRyYWZmaWMobGFzdCxzdGFnZSkpY29udGludWU7XG4gICAgICBjb25zdCBjb3N0PXJvdXRlVGltZShtYXAsc2hpcCxmcm9tLFsuLi5jb25uZWN0aW9uLC4uLihNYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShsYXN0LmhlYWRpbmcsc3RhZ2UuaGVhZGluZykpPjFlLTc/W3N0YWdlXTpbXSksZW5kXSk7XG4gICAgICBpZihjb3N0Pj1iZXN0Q29zdCljb250aW51ZTtcbiAgICAgIGJlc3RDb3N0PWNvc3Q7YmVzdD1bLi4uY29ubmVjdGlvbiwuLi4oTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UobGFzdC5oZWFkaW5nLHN0YWdlLmhlYWRpbmcpKT4xZS03P1tzdGFnZV06W10pLGVuZF07XG4gICAgfVxuICAgIHJldHVybiBiZXN0O1xuICB9XG59XG4vKiogSGVhZGluZy1hd2FyZSB3YXRlciByb3V0aW5nLiBBIGxvbmcsIG5hcnJvdyBodWxsIGNhbiBwYXNzIGEgY2hhbm5lbCB0aGF0IGl0IGNhbm5vdCB0dXJuIGluc2lkZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzaGlwUm91dGUobWFwOiBTZWFNYXAsIHNoaXA6IFVuaXQsIGdvYWw6IFBvaW50LCB0cmFmZmljQ2xlYXI6IChmcm9tOlNoaXBQb3NlLHRvOlNoaXBQb3NlKT0+Ym9vbGVhbiA9IGVtcHR5VHJhZmZpYyk6IFNoaXBQb3NlW10ge1xuICByZXR1cm4gcGxhblNoaXBSb3V0ZShtYXAsc2hpcCxnb2FsLHRyYWZmaWNDbGVhcikucG9pbnRzO1xufVxuLyoqIE5vbWluYWwgY3J1aXNpbmcgcmFkaXVzLiBBIHNob3J0ZXIsIGxvdy1zcGVlZCBhcmMgbWF5IHVzZSB0aGUgaHVsbC1sZW5ndGhcbiAqIGZsb29yOyB0aGUgY29udHJvbGxlciBzdGlsbCByZXNwZWN0cyB0aGUgZXhpc3Rpbmcgc3BlZWQgYW5kIHJ1ZGRlciBsaW1pdHMuICovXG5leHBvcnQgZnVuY3Rpb24gdm95YWdlVHVyblJhZGl1cyhzaGlwOlVuaXQpOm51bWJlciB7XG4gIGNvbnN0IGxpbWl0cz1zaGlwTW90aW9uTGltaXRzKHNoaXApLGxlbmd0aD1zaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoO1xuICByZXR1cm4gTWF0aC5tYXgobGVuZ3RoKi42NSxsaW1pdHMudHVyblJhdGU+MWUtNz9saW1pdHMuc3BlZWQvbGltaXRzLnR1cm5SYXRlOjApO1xufVxuZnVuY3Rpb24gdm95YWdlUmFkaWkoc2hpcDpVbml0KTpudW1iZXJbXSB7XG4gIGNvbnN0IG1pbmltdW09c2hpcFByb2ZpbGUoc2hpcCkhLmxlbmd0aCouNjUsbm9taW5hbD12b3lhZ2VUdXJuUmFkaXVzKHNoaXApO1xuICByZXR1cm4gWy4uLm5ldyBTZXQoW25vbWluYWwsTWF0aC5tYXgobWluaW11bSxub21pbmFsKi43KSxtaW5pbXVtXSldO1xufVxuZnVuY3Rpb24gcXVldWVkVm95YWdlUmFkaWkoc2hpcDpVbml0KTpudW1iZXJbXSB7XG4gIC8vIENsb3NlbHkgc3BhY2VkIG1hcmtzIG1heSBuZWVkIGEgc2xvd2VyLCB0aWdodGVyIGJlbmQgYWZ0ZXIgYW4gb2JsaXF1ZVxuICAvLyBkZXBhcnR1cmUuIFRoZSBjdXJ2ZSBzcGVlZCBzdGlsbCBmb2xsb3dzIHRoZSBzYW1lIHBoeXNpY2FsIHJ1ZGRlciBsaW1pdC5cbiAgY29uc3QgbGVuZ3RoPXNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGg7XG4gIHJldHVybiBbLi4ubmV3IFNldChbLi4udm95YWdlUmFkaWkoc2hpcCkubWFwKHJhZGl1cz0+TWF0aC5tYXgobGVuZ3RoLHJhZGl1cykpLGxlbmd0aCouNDVdKV07XG59XG5mdW5jdGlvbiBkZXBhcnR1cmVSYWRpaShtYXA6U2VhTWFwLHNoaXA6VW5pdCk6bnVtYmVyW10ge1xuICBjb25zdCBsaW1pdHM9c2hpcE1vdGlvbkxpbWl0cyhzaGlwKSxhdXhpbGlhcnk9Y291cnNlUGVyZm9ybWFuY2Uoc2hpcCxtYXApLmF1eGlsaWFyeVNwZWVkO1xuICAvLyBHZXR0aW5nIG91dCBvZiB0aGUgd2luZCBleWUgaXMgYSBsb3ctc3BlZWQgbWFuZXV2ZXIuIEl0cyBwaHlzaWNhbCB5YXdcbiAgLy8gbGltaXQgYWxsb3dzIGEgbXVjaCB0aWdodGVyIHN3ZXB0IHR1cm4gdGhhbiBhIGNydWlzZSBvciBtaWQtdm95YWdlIHRhY2s7XG4gIC8vIHJldGFpbmluZyB0aGUgY3J1aXNpbmcgZmxvb3IgaGVyZSBtYWtlcyBoZWF2eSBzaGlwcyBjcmF3bCBmb3IgdGVuIHNlY29uZHMuXG4gIGNvbnN0IGFzc2lzdGVkPU1hdGgubWF4KHNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGgqLjIsYXV4aWxpYXJ5L01hdGgubWF4KDFlLTcsbGltaXRzLnR1cm5SYXRlKSk7XG4gIHJldHVybiBbLi4ubmV3IFNldChbLi4udm95YWdlUmFkaWkoc2hpcCksYXNzaXN0ZWRdKV07XG59XG5mdW5jdGlvbiBjdXJ2ZVNwZWVkTGltaXQoc2hpcDpVbml0LHJhZGl1czpudW1iZXIpOm51bWJlciB7XG4gIC8vIExlYXZlIHN0ZWVyaW5nIGF1dGhvcml0eSBmb3IgdHJhY2tpbmcgZXJyb3JzIGFzIHdlbGwgYXMgdGhlIHBsYW5uZWQgeWF3LlxuICByZXR1cm4gTWF0aC5taW4oc2hpcE1vdGlvbkxpbWl0cyhzaGlwKS5zcGVlZCxyYWRpdXMqc2hpcE1vdGlvbkxpbWl0cyhzaGlwKS50dXJuUmF0ZSouODUpO1xufVxuZnVuY3Rpb24gY2lyY2xlQXJjKGZyb206U2hpcFBvc2UsaGVhZGluZzpudW1iZXIscmFkaXVzOm51bWJlcixzcGVlZExpbWl0Om51bWJlcik6U2hpcFBvc2VbXSB7XG4gIGNvbnN0IHR1cm49aGVhZGluZ0RpZmZlcmVuY2UoZnJvbS5oZWFkaW5nLGhlYWRpbmcpO1xuICByZXR1cm4gc2lnbmVkQ2lyY2xlQXJjKGZyb20sdHVybixyYWRpdXMsc3BlZWRMaW1pdCk7XG59XG5mdW5jdGlvbiBzaWduZWRDaXJjbGVBcmMoZnJvbTpTaGlwUG9zZSx0dXJuOm51bWJlcixyYWRpdXM6bnVtYmVyLHNwZWVkTGltaXQ6bnVtYmVyKTpTaGlwUG9zZVtdIHtcbiAgaWYoTWF0aC5hYnModHVybik8MWUtNylyZXR1cm4gW107XG4gIGNvbnN0IGN1cnZhdHVyZT1NYXRoLnNpZ24odHVybikvcmFkaXVzLGNvdW50PU1hdGgubWF4KDEsTWF0aC5jZWlsKE1hdGguYWJzKHR1cm4pLyhNYXRoLlBJLzM2KSkpO1xuICBjb25zdCBwb2ludHM6U2hpcFBvc2VbXT1bXTtcbiAgZm9yKGxldCBpPTE7aTw9Y291bnQ7aSsrKXtcbiAgICBjb25zdCBoZWFkaW5nPWZyb20uaGVhZGluZyt0dXJuKmkvY291bnQ7XG4gICAgcG9pbnRzLnB1c2goe3g6ZnJvbS54KyhkZXRTaW4oaGVhZGluZyktZGV0U2luKGZyb20uaGVhZGluZykpL2N1cnZhdHVyZSxcbiAgICAgIHk6ZnJvbS55LShkZXRDb3MoaGVhZGluZyktZGV0Q29zKGZyb20uaGVhZGluZykpL2N1cnZhdHVyZSxoZWFkaW5nLGN1cnZhdHVyZSxzcGVlZExpbWl0fSk7XG4gIH1cbiAgcmV0dXJuIHBvaW50cztcbn1cbmZ1bmN0aW9uIGJyYWtpbmdFbnRyeShzaGlwOlVuaXQsZnJvbTpTaGlwUG9zZSxzcGVlZExpbWl0Om51bWJlcik6U2hpcFBvc2VbXSB7XG4gIGNvbnN0IHNwZWVkPU1hdGgubWF4KDAsc2hpcC5zYWlsaW5nPy5zcGVlZCA/PyAwKSxhY2NlbGVyYXRpb249c2hpcE1vdGlvbkxpbWl0cyhzaGlwKS5hY2NlbGVyYXRpb247XG4gIGNvbnN0IGRpc3RhbmNlPU1hdGgubWF4KDAsKHNwZWVkKnNwZWVkLXNwZWVkTGltaXQqc3BlZWRMaW1pdCkvKDIqTWF0aC5tYXgoMWUtNixhY2NlbGVyYXRpb24pKSk7XG4gIHJldHVybiBkaXN0YW5jZTwxZS03P1tdOlt7eDpmcm9tLngrZGlzdGFuY2UqZGV0Q29zKGZyb20uaGVhZGluZykseTpmcm9tLnkrZGlzdGFuY2UqZGV0U2luKGZyb20uaGVhZGluZyksaGVhZGluZzpmcm9tLmhlYWRpbmcsY3VydmF0dXJlOjAsc3BlZWRMaW1pdH1dO1xufVxuLyoqIEZvcndhcmQgdHJhdmVsIHR1cm5zIHdoaWxlIGFkdmFuY2luZy4gQ29tcGFyZSBmZWFzaWJsZSBiZW5kIHNwZWVkcyBhbmRcbiAqIGFjY2VsZXJhdGlvbiBmcm9tIHRoZSBhY3R1YWwgaGVhZHdheSByYXRoZXIgdGhhbiBhbHdheXMgY2hvb3NpbmcgZnVsbCBSLiAqL1xuZnVuY3Rpb24gdm95YWdlVGltZShtYXA6U2VhTWFwLHNoaXA6VW5pdCxmcm9tOlNoaXBQb3NlLHBvaW50czpyZWFkb25seSBTaGlwUG9zZVtdKTpudW1iZXIge1xuICBjb25zdCBhY2NlbGVyYXRpb249TWF0aC5tYXgoMWUtNixzaGlwTW90aW9uTGltaXRzKHNoaXApLmFjY2VsZXJhdGlvbik7XG4gIGxldCB0aW1lPTAsc3BlZWQ9TWF0aC5tYXgoMCxzaGlwLnNhaWxpbmc/LnNwZWVkID8/IDApLHByZXZpb3VzPWZyb207XG4gIGZvcihjb25zdCBwb2ludCBvZiBwb2ludHMpe1xuICAgIGNvbnN0IHlhdz1NYXRoLmFicyhoZWFkaW5nRGlmZmVyZW5jZShwcmV2aW91cy5oZWFkaW5nLHBvaW50LmhlYWRpbmcpKTtcbiAgICBjb25zdCBkaXN0YW5jZT1wb2ludC5jdXJ2YXR1cmU/eWF3L01hdGguYWJzKHBvaW50LmN1cnZhdHVyZSk6TWF0aC5oeXBvdChwb2ludC54LXByZXZpb3VzLngscG9pbnQueS1wcmV2aW91cy55KTtcbiAgICBjb25zdCBwZXJmb3JtYW5jZT1jb3Vyc2VQZXJmb3JtYW5jZShzaGlwLG1hcCxwcmV2aW91cy5oZWFkaW5nK2hlYWRpbmdEaWZmZXJlbmNlKHByZXZpb3VzLmhlYWRpbmcscG9pbnQuaGVhZGluZykvMix7YXNzdW1lVHJpbW1lZDp0cnVlfSk7XG4gICAgY29uc3QgY2FwPU1hdGgubWluKE1hdGgubWF4KHBlcmZvcm1hbmNlLnRhcmdldFNwZWVkLHBlcmZvcm1hbmNlLmF1eGlsaWFyeVNwZWVkKSxwb2ludC5zcGVlZExpbWl0ID8/IEluZmluaXR5KTtcbiAgICBjb25zdCBjaGFuZ2luZ0Rpc3RhbmNlPU1hdGguYWJzKGNhcCpjYXAtc3BlZWQqc3BlZWQpLygyKmFjY2VsZXJhdGlvbik7XG4gICAgaWYoZGlzdGFuY2U8PWNoYW5naW5nRGlzdGFuY2Upe1xuICAgICAgY29uc3QgZW5kU3BlZWQ9TWF0aC5zcXJ0KE1hdGgubWF4KDAsc3BlZWQqc3BlZWQrTWF0aC5zaWduKGNhcC1zcGVlZCkqMiphY2NlbGVyYXRpb24qZGlzdGFuY2UpKTtcbiAgICAgIHRpbWUrPU1hdGguYWJzKGVuZFNwZWVkLXNwZWVkKS9hY2NlbGVyYXRpb247c3BlZWQ9ZW5kU3BlZWQ7XG4gICAgfWVsc2Uge1xuICAgICAgLy8gT25jZSBhY2NlbGVyYXRpb24gaGFzIHJlYWNoZWQgdGhlIGNhcCwgdGhlIHJlbWFpbmluZyBsZWcgY3J1aXNlcyBhdFxuICAgICAgLy8gdGhhdCBzcGVlZC4gVXNpbmcgb25lIG1lYW4gc3BlZWQgZm9yIGEgbG9uZyBsZWcgdW5mYWlybHkgcmV3YXJkcyBhXG4gICAgICAvLyBodWdlIGRlcGFydHVyZSBhcmMgc2ltcGx5IGJlY2F1c2UgaXQgc3RhcnRzIHRoYXQgbGVnIGEgbGl0dGxlIGZhc3Rlci5cbiAgICAgIHRpbWUrPU1hdGguYWJzKGNhcC1zcGVlZCkvYWNjZWxlcmF0aW9uKyhkaXN0YW5jZS1jaGFuZ2luZ0Rpc3RhbmNlKS9NYXRoLm1heCgxZS02LGNhcCk7XG4gICAgICBzcGVlZD1jYXA7XG4gICAgfVxuICAgIHByZXZpb3VzPXBvaW50O1xuICB9XG4gIHJldHVybiB0aW1lO1xufVxuY29uc3QgcG9zaXRpdmVBbmdsZT0oYW5nbGU6bnVtYmVyKT0+KChhbmdsZSUoMipNYXRoLlBJKSkrMipNYXRoLlBJKSUoMipNYXRoLlBJKTtcbmZ1bmN0aW9uIHZveWFnZUxlbmd0aChmcm9tOlBvaW50LHBvaW50czpyZWFkb25seSBQb2ludFtdKTpudW1iZXIge1xuICBsZXQgZGlzdGFuY2U9MCxwcmV2aW91cz1mcm9tO1xuICBmb3IoY29uc3QgcG9pbnQgb2YgcG9pbnRzKXtkaXN0YW5jZSs9TWF0aC5oeXBvdChwb2ludC54LXByZXZpb3VzLngscG9pbnQueS1wcmV2aW91cy55KTtwcmV2aW91cz1wb2ludDt9XG4gIHJldHVybiBkaXN0YW5jZTtcbn1cbmZ1bmN0aW9uIHZveWFnZUNvcnJpZG9yQ2xlYXIobWFwOlNlYU1hcCxzaGlwOlVuaXQsZnJvbTpTaGlwUG9zZSxwb2ludHM6U2hpcFBvc2VbXSx0cmFmZmljOihhOlNoaXBQb3NlLGI6U2hpcFBvc2UpPT5ib29sZWFuKTpib29sZWFuIHtcbiAgaWYoIWNvbm5lY3RvckNsZWFyKG1hcCxzaGlwLGZyb20scG9pbnRzLHRyYWZmaWMpKXJldHVybiBmYWxzZTtcbiAgLy8gQSByZWZlcmVuY2UgY3VydmUgbmVlZHMgc2VhIHJvb20gZm9yIGEgdHJhY2tpbmcgY29udHJvbGxlciB0byBlYXNlIHRoZVxuICAvLyBoZWxtIGJlZm9yZSBlYWNoIHNhbXBsZS4gQSB6ZXJvLW1hcmdpbiBhcmMgZ3JhemluZyBhIGNvYXN0IGJlbG9uZ3MgdG8gdGhlXG4gIC8vIGV4YWN0IG1hbmV1dmVyIGV4ZWN1dG9yIGV2ZW4gd2hlbiBpdHMgY2VudGVybGluZSBzd2VlcCBhbG9uZSB3b3VsZCBmaXQuXG4gIGNvbnN0IG1hcmdpbj1zaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoKi4xO1xuICBmb3IoY29uc3Qgc2lkZSBvZiBbLTEsMV0pe1xuICAgIGNvbnN0IG9mZnNldD0ocG9pbnQ6U2hpcFBvc2UpOlNoaXBQb3NlPT4oey4uLnBvaW50LHg6cG9pbnQueC1zaWRlKm1hcmdpbipkZXRTaW4ocG9pbnQuaGVhZGluZykseTpwb2ludC55K3NpZGUqbWFyZ2luKmRldENvcyhwb2ludC5oZWFkaW5nKSxcbiAgICAgIC4uLihwb2ludC5jdXJ2YXR1cmU/e2N1cnZhdHVyZTpwb2ludC5jdXJ2YXR1cmUvKDEtc2lkZSptYXJnaW4qcG9pbnQuY3VydmF0dXJlKX06e30pfSk7XG4gICAgaWYoIWNvbm5lY3RvckNsZWFyKG1hcCxzaGlwLG9mZnNldChmcm9tKSxwb2ludHMubWFwKG9mZnNldCksdHJhZmZpYykpcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuLyoqIFJvdW5kIGEgcXVldWVkIGNvdXJzZSBjaGFuZ2UgYmVmb3JlIGl0cyBpbnRlcnNlY3Rpb24uIFRoZSBjdXJyZW50IGxlZ1xuICogbXVzdCBhbHJlYWR5IGJlIGFsaWduZWQ7IG90aGVyd2lzZSB0aGUgb3JkaW5hcnkgdm95YWdlIGNvbm5lY3RvciBvd25zIHRoZVxuICogYXBwcm9hY2guIEFsbCByZW1haW5pbmcgbGVncyBhbmQgdGhlIGNvbXBsZXRlIHR1cm4gaGF2ZSB0cmFja2luZyByb29tLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJvdW5kVm95YWdlQ29ybmVyKG1hcDpTZWFNYXAsc2hpcDpVbml0LGZyb206U2hpcFBvc2UsY29ybmVyOlBvaW50LG5leHQ6UG9pbnQsdHJhZmZpYzooYTpTaGlwUG9zZSxiOlNoaXBQb3NlKT0+Ym9vbGVhbj0oKT0+dHJ1ZSk6U2hpcFBvc2VbXXx1bmRlZmluZWQge1xuICBjb25zdCBpbmNvbWluZz1NYXRoLmF0YW4yKGNvcm5lci55LWZyb20ueSxjb3JuZXIueC1mcm9tLngpLG91dGdvaW5nPU1hdGguYXRhbjIobmV4dC55LWNvcm5lci55LG5leHQueC1jb3JuZXIueCk7XG4gIGNvbnN0IHR1cm49aGVhZGluZ0RpZmZlcmVuY2UoaW5jb21pbmcsb3V0Z29pbmcpLGJlZm9yZT1NYXRoLmh5cG90KGNvcm5lci54LWZyb20ueCxjb3JuZXIueS1mcm9tLnkpLGFmdGVyPU1hdGguaHlwb3QobmV4dC54LWNvcm5lci54LG5leHQueS1jb3JuZXIueSk7XG4gIGlmKE1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKGZyb20uaGVhZGluZyxpbmNvbWluZykpPi4wMSB8fCBNYXRoLmFicyh0dXJuKTwuMDEgfHwgTWF0aC5hYnModHVybik+TWF0aC5QSS0uMSB8fCBzaGlwTW90aW9uTGltaXRzKHNoaXApLnR1cm5SYXRlPD0xZS03KXJldHVybjtcbiAgbGV0IGJlc3Q6U2hpcFBvc2VbXXx1bmRlZmluZWQsYmVzdENvc3Q9SW5maW5pdHk7XG4gIGZvcihjb25zdCByYWRpdXMgb2YgcXVldWVkVm95YWdlUmFkaWkoc2hpcCkpe1xuICAgIGlmKGJlc3QgJiYgcmFkaXVzPHNoaXBQcm9maWxlKHNoaXApIS5sZW5ndGgqLjY1KWNvbnRpbnVlO1xuICAgIGNvbnN0IHNldGJhY2s9cmFkaXVzKk1hdGgudGFuKE1hdGguYWJzKHR1cm4pLzIpLHNwZWVkTGltaXQ9Y3VydmVTcGVlZExpbWl0KHNoaXAscmFkaXVzKTtcbiAgICBjb25zdCBicmFraW5nPWJyYWtpbmdFbnRyeShzaGlwLGZyb20sc3BlZWRMaW1pdCksYnJha2luZ0xlbmd0aD1icmFraW5nLmxlbmd0aD9NYXRoLmh5cG90KGJyYWtpbmdbMF0hLngtZnJvbS54LGJyYWtpbmdbMF0hLnktZnJvbS55KTowO1xuICAgIGlmKHNldGJhY2srYnJha2luZ0xlbmd0aCsxPj1iZWZvcmUgfHwgc2V0YmFjaysxPj1hZnRlciljb250aW51ZTtcbiAgICBjb25zdCBlbnRyeTpTaGlwUG9zZT17eDpjb3JuZXIueC1zZXRiYWNrKmRldENvcyhpbmNvbWluZykseTpjb3JuZXIueS1zZXRiYWNrKmRldFNpbihpbmNvbWluZyksaGVhZGluZzppbmNvbWluZyxjdXJ2YXR1cmU6MCxzcGVlZExpbWl0fTtcbiAgICBjb25zdCBwb2ludHM9W2VudHJ5LC4uLmNpcmNsZUFyYyhlbnRyeSxvdXRnb2luZyxyYWRpdXMsc3BlZWRMaW1pdCksey4uLm5leHQsaGVhZGluZzpvdXRnb2luZyxjdXJ2YXR1cmU6MH1dO1xuICAgIGNvbnN0IGNvc3Q9dm95YWdlVGltZShtYXAsc2hpcCxmcm9tLHBvaW50cyk7XG4gICAgaWYoY29zdD49YmVzdENvc3QgfHwgIXZveWFnZUNvcnJpZG9yQ2xlYXIobWFwLHNoaXAsZnJvbSxwb2ludHMsdHJhZmZpYykpY29udGludWU7XG4gICAgYmVzdD1wb2ludHM7YmVzdENvc3Q9Y29zdDtcbiAgfVxuICByZXR1cm4gYmVzdDtcbn1cbi8qKiBGb3J3YXJkIGNpcmNsZSBmb2xsb3dlZCBieSBpdHMgdGFuZ2VudCB0byBhIGZyZWUtaGVhZGluZyBkZXN0aW5hdGlvbi5cbiAqIEVhY2ggc21hbGwgcmVmZXJlbmNlIHNlZ21lbnQgaXMgc3dlcHQgd2l0aCBpdHMgY2hhbmdpbmcgaHVsbCBvcmllbnRhdGlvbjtcbiAqIG5vIHplcm8tZGlzdGFuY2Ugcm90YXRpb24gaXMgaGlkZGVuIGluIGFuIG9wZW4td2F0ZXIgdm95YWdlLiAqL1xuZnVuY3Rpb24gZm9yd2FyZENvbm5lY3RvcihtYXA6U2VhTWFwLHNoaXA6VW5pdCxmcm9tOlNoaXBQb3NlLGdvYWw6UG9pbnQsdHJhZmZpYzooYTpTaGlwUG9zZSxiOlNoaXBQb3NlKT0+Ym9vbGVhbixuZXh0PzpQb2ludCxsZW5ndGhMaW1pdD86bnVtYmVyKTpTaGlwUG9zZVtdfHVuZGVmaW5lZCB7XG4gIGNvbnN0IGR4PWdvYWwueC1mcm9tLngsZHk9Z29hbC55LWZyb20ueSxnYXA9TWF0aC5oeXBvdChkeCxkeSk7XG4gIGlmKGdhcDwxZS03KXJldHVybiBbXTtcbiAgY29uc3QgZGlyZWN0aW9uPU1hdGguYXRhbjIoZHksZHgpLGVycm9yPWhlYWRpbmdEaWZmZXJlbmNlKGZyb20uaGVhZGluZyxkaXJlY3Rpb24pO1xuICBpZihNYXRoLmFicyhlcnJvcik8MWUtNyl7Y29uc3QgZGlyZWN0PVt7Li4uZ29hbCxoZWFkaW5nOmZyb20uaGVhZGluZ31dO3JldHVybiBjb25uZWN0b3JDbGVhcihtYXAsc2hpcCxmcm9tLGRpcmVjdCx0cmFmZmljKT9kaXJlY3Q6dW5kZWZpbmVkO31cbiAgaWYoc2hpcE1vdGlvbkxpbWl0cyhzaGlwKS50dXJuUmF0ZTw9MWUtNylyZXR1cm47XG4gIGxldCBiZXN0OlNoaXBQb3NlW118dW5kZWZpbmVkLGJlc3RDb3N0PUluZmluaXR5LGJlc3RDYW5Sb3VuZD1mYWxzZTtcbiAgZm9yKGNvbnN0IHJhZGl1cyBvZiBuZXh0ID8gcXVldWVkVm95YWdlUmFkaWkoc2hpcCkgOiB2b3lhZ2VSYWRpaShzaGlwKSl7XG4gICAgaWYoYmVzdENhblJvdW5kICYmIHJhZGl1czxzaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoKi42NSljb250aW51ZTtcbiAgICBjb25zdCBzcGVlZExpbWl0PWN1cnZlU3BlZWRMaW1pdChzaGlwLHJhZGl1cyksbGVhZD1icmFraW5nRW50cnkoc2hpcCxmcm9tLHNwZWVkTGltaXQpLGVudHJ5PWxlYWQuYXQoLTEpID8/IGZyb207XG4gICAgZm9yKGNvbnN0IHNpZGUgb2YgW2Vycm9yPDA/LTE6MSxlcnJvcjwwPzE6LTFdKXtcbiAgICAgIGNvbnN0IGNlbnRlcj17eDplbnRyeS54LXNpZGUqcmFkaXVzKmRldFNpbihlbnRyeS5oZWFkaW5nKSx5OmVudHJ5Lnkrc2lkZSpyYWRpdXMqZGV0Q29zKGVudHJ5LmhlYWRpbmcpfTtcbiAgICAgIGNvbnN0IGd4PWdvYWwueC1jZW50ZXIueCxneT1nb2FsLnktY2VudGVyLnksZGlzdGFuY2U9TWF0aC5oeXBvdChneCxneSk7XG4gICAgICBpZihkaXN0YW5jZTxyYWRpdXMrMWUtNyljb250aW51ZTtcbiAgICAgIGNvbnN0IHJhZGlhbD1NYXRoLmF0YW4yKGd5LGd4KS1zaWRlKk1hdGguYWNvcyhNYXRoLm1pbigxLHJhZGl1cy9kaXN0YW5jZSkpO1xuICAgICAgY29uc3QgaGVhZGluZz1yYWRpYWwrc2lkZSpNYXRoLlBJLzIsdHVybj1wb3NpdGl2ZUFuZ2xlKHNpZGUqaGVhZGluZ0RpZmZlcmVuY2UoZnJvbS5oZWFkaW5nLGhlYWRpbmcpKTtcbiAgICAgIC8vIEEgbmVhci1mdWxsIGNpcmNsZSBpcyBhIGJlcnRoaW5nIG1hbmV1dmVyOyBpdCBpcyBub3QgYSB1c2VmdWwgcm91dGUgdG9cbiAgICAgIC8vIGEgbmVhcmJ5IHBvaW50IGFuZCB3b3VsZCBsb29rIGxpa2Ugb3JiaXRpbmcgYSBtb3ZpbmcgdGFyZ2V0LlxuICAgICAgaWYodHVybj5NYXRoLlBJKjEuNSljb250aW51ZTtcbiAgICAgIGNvbnN0IHBvaW50czpTaGlwUG9zZVtdPVsuLi5sZWFkLC4uLnNpZ25lZENpcmNsZUFyYyhlbnRyeSxzaWRlKnR1cm4scmFkaXVzLHNwZWVkTGltaXQpXTtcbiAgICAgIGNvbnN0IHRhbmdlbnQ9cG9pbnRzLmF0KC0xKSE7XG4gICAgICAvLyBBIGxhcmdlIGh1bGwncyBmYXN0ZXN0IGRlcGFydHVyZSBhcmMgY2FuIGxlYXZlIGEgdmVyeSBzaG9ydCB0YW5nZW50XG4gICAgICAvLyBhbmQgYSBzdGVlcCBhcnJpdmFsIGhlYWRpbmcuIFByZWZlciBhbiBhcHByb2FjaCB3aXRoIGVub3VnaCBzZWEgcm9vbVxuICAgICAgLy8gZm9yIHRoZSBhbHJlYWR5IHF1ZXVlZCBiZW5kLCByYXRoZXIgdGhhbiBzdG9wcGluZyBhdCB0aGF0IGZpcnN0IG1hcmsuXG4gICAgICBjb25zdCBjYW5Sb3VuZD0hbmV4dCB8fCAhIXJvdW5kVm95YWdlQ29ybmVyKG1hcCx7Li4uc2hpcCxzYWlsaW5nOnsuLi5zaGlwLnNhaWxpbmchLHNwZWVkOnNwZWVkTGltaXR9fSx0YW5nZW50LGdvYWwsbmV4dCx0cmFmZmljKTtcbiAgICAgIGlmKE1hdGguaHlwb3QoZ29hbC54LXRhbmdlbnQueCxnb2FsLnktdGFuZ2VudC55KT4xZS03KXBvaW50cy5wdXNoKHsuLi5nb2FsLGhlYWRpbmc6dGFuZ2VudC5oZWFkaW5nLGN1cnZhdHVyZTowfSk7XG4gICAgICAvLyBPbmx5IGNhbmRpZGF0ZXMgaW5zaWRlIHRoZSBleGlzdGluZyBkZXRvdXIgYm91bmQgYXJlIGVsaWdpYmxlLlxuICAgICAgaWYobGVuZ3RoTGltaXQhPT11bmRlZmluZWQgJiYgdm95YWdlTGVuZ3RoKGZyb20scG9pbnRzKT5sZW5ndGhMaW1pdCljb250aW51ZTtcbiAgICAgIGNvbnN0IGNvc3Q9dm95YWdlVGltZShtYXAsc2hpcCxmcm9tLHBvaW50cyk7XG4gICAgICBpZihiZXN0Q2FuUm91bmQgJiYgIWNhblJvdW5kIHx8IGJlc3RDYW5Sb3VuZD09PWNhblJvdW5kICYmIGNvc3Q+PWJlc3RDb3N0LTFlLTcgfHwgIXZveWFnZUNvcnJpZG9yQ2xlYXIobWFwLHNoaXAsZnJvbSxwb2ludHMsdHJhZmZpYykpY29udGludWU7XG4gICAgICBiZXN0PXBvaW50cztiZXN0Q29zdD1jb3N0O2Jlc3RDYW5Sb3VuZD1jYW5Sb3VuZDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGJlc3Q7XG59XG5leHBvcnQgdHlwZSBWb3lhZ2VSZWZpbmVtZW50U3RhdGUgPSB7IGN1cnNvcjpTaGlwUG9zZTsgY29ybmVyczpTaGlwUG9zZVtdOyByZXN1bHQ6U2hpcFBvc2VbXTsgaW5kZXg6bnVtYmVyOyBjYW5kaWRhdGU6bnVtYmVyIH07XG5leHBvcnQgZnVuY3Rpb24gYmVnaW5Wb3lhZ2VSZWZpbmVtZW50KGZyb206U2hpcFBvc2UscG9pbnRzOlNoaXBQb3NlW10pOlZveWFnZVJlZmluZW1lbnRTdGF0ZSB7XG4gIGNvbnN0IHJlc3VsdDpTaGlwUG9zZVtdPVtdO1xuICBmb3IoOzspe1xuICBsZXQgcHJldmlvdXM9ZnJvbSxtYW5ldXZlcj0tMTtcbiAgZm9yKGxldCBpPTA7aTxwb2ludHMubGVuZ3RoO2krKyl7XG4gICAgY29uc3QgcG9pbnQ9cG9pbnRzW2ldITtcbiAgICBpZihwb2ludC5waXZvdCB8fCAocG9pbnQueC1wcmV2aW91cy54KSpkZXRDb3MocG9pbnQuaGVhZGluZykrKHBvaW50LnktcHJldmlvdXMueSkqZGV0U2luKHBvaW50LmhlYWRpbmcpPC0xZS01KXttYW5ldXZlcj1pO2JyZWFrO31cbiAgICBwcmV2aW91cz1wb2ludDtcbiAgfVxuICBpZihtYW5ldXZlcj49MCl7XG4gICAgLy8gQSBzaG9ydCByZXRyZWF0L3Bpdm90IG93bnMgaXRzIGV4YWN0IGF0dGl0dWRlLiBJdCBkb2VzIG5vdCByZXF1aXJlIHRoZVxuICAgIC8vIGVuc3VpbmcgZm9yd2FyZCBjb2FzdGFsIGNvcnJpZG9yIHRvIHJlbWFpbiBpbiB0aGUgYmVydGggZXhlY3V0b3IuXG4gICAgd2hpbGUobWFuZXV2ZXIrMTxwb2ludHMubGVuZ3RoKXtcbiAgICAgIGNvbnN0IHBvaW50PXBvaW50c1ttYW5ldXZlcisxXSEscHJpb3I9cG9pbnRzW21hbmV1dmVyXSE7XG4gICAgICBpZighcG9pbnQucGl2b3QgJiYgTWF0aC5oeXBvdChwb2ludC54LXByaW9yLngscG9pbnQueS1wcmlvci55KT4xZS03XG4gICAgICAgICYmIChwb2ludC54LXByaW9yLngpKmRldENvcyhwb2ludC5oZWFkaW5nKSsocG9pbnQueS1wcmlvci55KSpkZXRTaW4ocG9pbnQuaGVhZGluZyk+PS0xZS01KWJyZWFrO1xuICAgICAgbWFuZXV2ZXIrKztcbiAgICB9XG4gICAgY29uc3QgcHJlZml4PXBvaW50cy5zbGljZSgwLG1hbmV1dmVyKzEpLm1hcChwb2ludD0+KHsuLi5wb2ludCxleGFjdDp0cnVlfSkpO1xuICAgIHJlc3VsdC5wdXNoKC4uLnByZWZpeCk7ZnJvbT1wb2ludHNbbWFuZXV2ZXJdITtwb2ludHM9cG9pbnRzLnNsaWNlKG1hbmV1dmVyKzEpO2NvbnRpbnVlO1xuICB9XG4gIC8vIEtlZXAgdGhlIGVuZHBvaW50cyBvZiBzdHJhaWdodCBsYXR0aWNlIHJ1bnMgYW5kIGJvdGggcG9zZXMgb2YgZWFjaFxuICAvLyByZXF1aXJlZCB0dXJuLiBJZiBubyBzd2VwdCBmb3J3YXJkIHJlcGxhY2VtZW50IGZpdHMsIHRoZSBleGFjdCBtYW5ldXZlclxuICAvLyByZW1haW5zIGF2YWlsYWJsZSB1bmNoYW5nZWQgdG8gdGhlIGNvYXN0L2JlcnRoIGV4ZWN1dG9yLlxuICBjb25zdCBjb3JuZXJzPXBvaW50cy5maWx0ZXIoKHBvaW50LGkpPT57XG4gICAgY29uc3QgYT1wb2ludHNbaS0xXSA/PyBmcm9tLGI9cG9pbnRzW2krMV07XG4gICAgcmV0dXJuICFiIHx8IE1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKGEuaGVhZGluZyxwb2ludC5oZWFkaW5nKSk+MWUtN1xuICAgICAgfHwgTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UocG9pbnQuaGVhZGluZyxiLmhlYWRpbmcpKT4xZS03XG4gICAgICB8fCBNYXRoLmh5cG90KHBvaW50LngtYS54LHBvaW50LnktYS55KTwxZS03IHx8IE1hdGguaHlwb3QoYi54LXBvaW50LngsYi55LXBvaW50LnkpPDFlLTc7XG4gIH0pO1xuICByZXR1cm57Y3Vyc29yOmZyb20sY29ybmVycyxyZXN1bHQsaW5kZXg6MCxjYW5kaWRhdGU6Y29ybmVycy5sZW5ndGgtMX07XG4gIH1cbn1cbi8qKiBBIGZpeGVkIG51bWJlciBvZiBjb21wbGV0ZSBjb25uZWN0b3IgdHJpYWxzOyBldmVyeSBhY2NlcHRlZCBjdXJ2ZSByZXRhaW5zXG4gKiB0aGUgb3JpZ2luYWwgY2VudHJlIGFuZCBib3RoIHRyYWNraW5nLW1hcmdpbiBzd2VlcHMuICovXG5leHBvcnQgZnVuY3Rpb24gYWR2YW5jZVZveWFnZVJlZmluZW1lbnQobWFwOlNlYU1hcCxzaGlwOlVuaXQsc3RhdGU6Vm95YWdlUmVmaW5lbWVudFN0YXRlLHRyYWZmaWM6KGE6U2hpcFBvc2UsYjpTaGlwUG9zZSk9PmJvb2xlYW4sYXR0ZW1wdHM9SW5maW5pdHkpOmJvb2xlYW4ge1xuICBsZXQgdHJpZWQ9MDtcbiAgd2hpbGUoc3RhdGUuaW5kZXg8c3RhdGUuY29ybmVycy5sZW5ndGgpe1xuICAgIGlmKHN0YXRlLmNhbmRpZGF0ZTxzdGF0ZS5pbmRleCl7XG4gICAgICBzdGF0ZS5jdXJzb3I9c3RhdGUuY29ybmVyc1tzdGF0ZS5pbmRleCsrXSE7c3RhdGUucmVzdWx0LnB1c2goey4uLnN0YXRlLmN1cnNvcixleGFjdDp0cnVlfSk7XG4gICAgICBzdGF0ZS5jYW5kaWRhdGU9c3RhdGUuY29ybmVycy5sZW5ndGgtMTtjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgZ29hbD1zdGF0ZS5jb3JuZXJzW3N0YXRlLmNhbmRpZGF0ZV0hO1xuICAgIGlmKE1hdGguaHlwb3QoZ29hbC54LXN0YXRlLmN1cnNvci54LGdvYWwueS1zdGF0ZS5jdXJzb3IueSk8c2hpcFByb2ZpbGUoc2hpcCkhLmxlbmd0aCouNSl7c3RhdGUuY2FuZGlkYXRlLS07Y29udGludWU7fVxuICAgIGlmKHRyaWVkKys+PWF0dGVtcHRzKXJldHVybiBmYWxzZTtcbiAgICBjb25zdCBsZW5ndGhMaW1pdD12b3lhZ2VMZW5ndGgoc3RhdGUuY3Vyc29yLHN0YXRlLmNvcm5lcnMuc2xpY2Uoc3RhdGUuaW5kZXgsc3RhdGUuY2FuZGlkYXRlKzEpKSoxLjE7XG4gICAgY29uc3QgY2FuZGlkYXRlPWZvcndhcmRDb25uZWN0b3IobWFwLHNoaXAsc3RhdGUuY3Vyc29yLGdvYWwsdHJhZmZpYyx1bmRlZmluZWQsbGVuZ3RoTGltaXQpO1xuICAgIGNvbnN0IGZvbGxvd2luZz1zdGF0ZS5jb3JuZXJzW3N0YXRlLmNhbmRpZGF0ZSsxXTtcbiAgICBpZighY2FuZGlkYXRlIHx8IHZveWFnZUxlbmd0aChzdGF0ZS5jdXJzb3IsY2FuZGlkYXRlKT5sZW5ndGhMaW1pdFxuICAgICAgfHwgZm9sbG93aW5nICYmICFjb25uZWN0b3JDbGVhcihtYXAsc2hpcCxjYW5kaWRhdGUuYXQoLTEpISxbZm9sbG93aW5nXSx0cmFmZmljKSl7c3RhdGUuY2FuZGlkYXRlLS07Y29udGludWU7fVxuICAgIHN0YXRlLnJlc3VsdC5wdXNoKC4uLmNhbmRpZGF0ZSk7c3RhdGUuY3Vyc29yPWNhbmRpZGF0ZS5hdCgtMSkhO1xuICAgIHN0YXRlLmluZGV4PXN0YXRlLmNhbmRpZGF0ZSsxO3N0YXRlLmNhbmRpZGF0ZT1zdGF0ZS5jb3JuZXJzLmxlbmd0aC0xO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gc2ltcGxpZnlWb3lhZ2VSZWZlcmVuY2UobWFwOlNlYU1hcCxzaGlwOlVuaXQsZnJvbTpTaGlwUG9zZSxwb2ludHM6U2hpcFBvc2VbXSx0cmFmZmljOihhOlNoaXBQb3NlLGI6U2hpcFBvc2UpPT5ib29sZWFuKTpTaGlwUG9zZVtdIHtcbiAgY29uc3Qgc3RhdGU9YmVnaW5Wb3lhZ2VSZWZpbmVtZW50KGZyb20scG9pbnRzKTthZHZhbmNlVm95YWdlUmVmaW5lbWVudChtYXAsc2hpcCxzdGF0ZSx0cmFmZmljKTtyZXR1cm4gc3RhdGUucmVzdWx0O1xufVxuLyoqIENydWlzZSBwbGFubmluZyBpcyBzZXBhcmF0ZSBmcm9tIGV4YWN0IGRvY2tpbmcuIFN0YXJ0IHdpdGggYSBjb250aW51b3VzXG4gKiBmb3J3YXJkIGN1cnZlOyB1c2UgdGhlIGhlYWRpbmcgbGF0dGljZSBvbmx5IGFzIGEgc2FmZSBjb2FzdGFsIHJlZmVyZW5jZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwbGFuVm95YWdlUm91dGUobWFwOlNlYU1hcCxzaGlwOlVuaXQsZ29hbDpQb2ludCAmIHtoZWFkaW5nPzpudW1iZXJ9LHRyYWZmaWNDbGVhcjooZnJvbTpTaGlwUG9zZSx0bzpTaGlwUG9zZSk9PmJvb2xlYW49ZW1wdHlUcmFmZmljLGJ1ZGdldD1JbmZpbml0eSk6e3BvaW50czpTaGlwUG9zZVtdO3BhcnRpYWw6Ym9vbGVhbn0ge1xuICBjb25zdCBmcm9tPXt4OnNoaXAueCx5OnNoaXAueSxoZWFkaW5nOnNoaXAuc2FpbGluZz8uaGVhZGluZyA/PyAwfTtcbiAgaWYoZ29hbC5oZWFkaW5nIT09dW5kZWZpbmVkIHx8IE1hdGguaHlwb3QoZ29hbC54LWZyb20ueCxnb2FsLnktZnJvbS55KTw9c2hpcFByb2ZpbGUoc2hpcCkhLmxlbmd0aCouNSlcbiAgICByZXR1cm4gcGxhblNoaXBSb3V0ZShtYXAsc2hpcCxnb2FsLHRyYWZmaWNDbGVhcixidWRnZXQpO1xuICBjb25zdCBkaXJlY3Q9cGxhbkRpcmVjdFZveWFnZShtYXAsc2hpcCxnb2FsLHRyYWZmaWNDbGVhcik7XG4gIGlmKGRpcmVjdClyZXR1cm57cG9pbnRzOmRpcmVjdCxwYXJ0aWFsOmZhbHNlfTtcbiAgY29uc3QgcmVmZXJlbmNlPXBsYW5TaGlwUm91dGUobWFwLHNoaXAsZ29hbCx0cmFmZmljQ2xlYXIsYnVkZ2V0LHRydWUpO1xuICByZXR1cm57cG9pbnRzOnNpbXBsaWZ5Vm95YWdlUmVmZXJlbmNlKG1hcCxzaGlwLGZyb20scmVmZXJlbmNlLnBvaW50cyx0cmFmZmljQ2xlYXIpLHBhcnRpYWw6cmVmZXJlbmNlLnBhcnRpYWx9O1xufVxuXG4vKiogQSB2b3lhZ2UncyBkaXJlY3Qgc3RhZ2UsIHNlcGFyYXRlZCBmcm9tIGl0cyBoZWFkaW5nLWxhdHRpY2UgcmVmZXJlbmNlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBsYW5EaXJlY3RWb3lhZ2UobWFwOlNlYU1hcCxzaGlwOlVuaXQsZ29hbDpQb2ludCx0cmFmZmljOihhOlNoaXBQb3NlLGI6U2hpcFBvc2UpPT5ib29sZWFuKTpTaGlwUG9zZVtdfHVuZGVmaW5lZCB7XG4gIGNvbnN0IGZyb209e3g6c2hpcC54LHk6c2hpcC55LGhlYWRpbmc6c2hpcC5zYWlsaW5nPy5oZWFkaW5nPz8wfTtcbiAgY29uc3QgcXVldWVkPXNoaXAub3JkZXJRdWV1ZT8uWzBdLGN1cnJlbnQ9c2hpcC5vcmRlcjtcbiAgY29uc3QgbmV4dD1jdXJyZW50LnR5cGU9PT0nbW92ZScgJiYgY3VycmVudC5oZWFkaW5nPT09dW5kZWZpbmVkICYmIGN1cnJlbnQucmVuZGV6dm91c0Zvcj09PXVuZGVmaW5lZFxuICAgICYmIGN1cnJlbnQuZGVja1BvaW50PT09dW5kZWZpbmVkICYmIGN1cnJlbnQuZGVja1NoaXBJZD09PXVuZGVmaW5lZFxuICAgICYmIGN1cnJlbnQueD09PWdvYWwueCAmJiBjdXJyZW50Lnk9PT1nb2FsLnkgJiYgcXVldWVkPy50eXBlPT09J21vdmUnXG4gICAgJiYgcXVldWVkLmhlYWRpbmc9PT11bmRlZmluZWQgJiYgcXVldWVkLnJlbmRlenZvdXNGb3I9PT11bmRlZmluZWQgJiYgcXVldWVkLmRlY2tQb2ludD09PXVuZGVmaW5lZCAmJiBxdWV1ZWQuZGVja1NoaXBJZD09PXVuZGVmaW5lZFxuICAgICYmICEhcXVldWVkLmF2b2lkQ29tYmF0PT09ISFjdXJyZW50LmF2b2lkQ29tYmF0XG4gICAgJiYgIWNvdXJzZVBlcmZvcm1hbmNlKHNoaXAsbWFwLE1hdGguYXRhbjIocXVldWVkLnktZ29hbC55LHF1ZXVlZC54LWdvYWwueCkse2Fzc3VtZVRyaW1tZWQ6dHJ1ZX0pLm5vR28gPyBxdWV1ZWQgOiB1bmRlZmluZWQ7XG4gIHJldHVybiBmb3J3YXJkQ29ubmVjdG9yKG1hcCxzaGlwLGZyb20sZ29hbCx0cmFmZmljLG5leHQpO1xufVxuLyoqIEEgZGV0ZXJtaW5pc3RpYyBleHBhbnNpb24gYnVkZ2V0IGJvdW5kcyB0ZW1wb3JhcnkgdHJhZmZpYyBzZWFyY2hlcy4gUGFydGlhbFxuICogcm91dGVzIHJlbWFpbiBqb3VybmV5cywgbmV2ZXIgYXJyaXZhbHMgYXQgdGhlIHJlcXVlc3RlZCBkZXN0aW5hdGlvbi4gKi9cbmxldCByb3V0ZVNlYXJjaERlcHRoID0gMDtcbmV4cG9ydCBmdW5jdGlvbiBwbGFuU2hpcFJvdXRlKG1hcDogU2VhTWFwLCBzaGlwOiBVbml0LCBnb2FsOiBQb2ludCAmIHtoZWFkaW5nPzpudW1iZXJ9LCB0cmFmZmljQ2xlYXI6IChmcm9tOlNoaXBQb3NlLHRvOlNoaXBQb3NlKT0+Ym9vbGVhbiA9IGVtcHR5VHJhZmZpYywgYnVkZ2V0PUluZmluaXR5LCB2b3lhZ2U9ZmFsc2UpOiB7cG9pbnRzOlNoaXBQb3NlW107cGFydGlhbDpib29sZWFufSB7XG4gIHJvdXRlU2VhcmNoRGVwdGgrKztcbiAgdHJ5IHsgcmV0dXJuIHBsYW5TaGlwUm91dGVJbXBsKG1hcCxzaGlwLGdvYWwsdHJhZmZpY0NsZWFyLGJ1ZGdldCx2b3lhZ2Uscm91dGVTZWFyY2hEZXB0aD4xKSE7IH1cbiAgZmluYWxseSB7IHJvdXRlU2VhcmNoRGVwdGgtLTsgfVxufVxudHlwZSBSb3V0ZVJlc3VsdD17cG9pbnRzOlNoaXBQb3NlW107cGFydGlhbDpib29sZWFufTtcbi8qKiBTcGFyc2UsIGxvc3NsZXNzIGNvbnRpbnVhdGlvbi4gR2VvbWV0cnkgY2FjaGVzIHJlbWFpbiByZWNvbXB1dGFibGU7IG9ubHlcbiAqIHJlYWNoZWQgY29zdHMsIGV4YWN0IGhlYXAgb3JkZXIgYW5kIGRldGVybWluaXN0aWMgbG9vcCBjdXJzb3JzIGFyZSBzYXZlZC4gKi9cbmV4cG9ydCB0eXBlIFNoaXBSb3V0ZVNlYXJjaFN0YXRlPXtcbiAgcGhhc2U6J3ByZXBhcmUnfCdlbnRyYW5jZSd8J3NlYXJjaCd8J2ZhbGxiYWNrJ3wnZG9uZSc7IHRhcmdldD86U2hpcFBvc2U7IGRlZmVycmVkPzpib29sZWFuOyB0cmFmZmljQmxvY2tlZD86Ym9vbGVhbjtcbiAgbm9kZXM/OntpZDpudW1iZXI7Y29zdDpudW1iZXI7cGFyZW50Om51bWJlcn1bXTsgdHJhZmZpY0ZpdHM/OntpZDpudW1iZXI7Y2xlYXI6Ym9vbGVhbn1bXTtcbiAgaGVhcD86e2lkOm51bWJlcjtjb3N0Om51bWJlcjtzY29yZTpudW1iZXJ9W107IHByZWZpeGVzPzp7aWQ6bnVtYmVyO3BvaW50czpTaGlwUG9zZVtdfVtdO1xuICBlbnRyYW5jZXM/OntjZWxsOm51bWJlcjtwb2ludHM6U2hpcFBvc2VbXVtdfVtdOyBlbnRyYW5jZUN1cnNvcj86bnVtYmVyO1xuICBiZXN0PzpudW1iZXI7IGJlc3RHYXA/Om51bWJlcjsgdmlzaXRlZD86bnVtYmVyOyBwYXRoPzpTaGlwUG9zZVtdOyBmYWxsYmFjaz86U2hpcFJvdXRlU2VhcmNoU3RhdGU7IHJlc3VsdD86Um91dGVSZXN1bHQ7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGFkdmFuY2VTaGlwUm91dGVTZWFyY2gobWFwOlNlYU1hcCxzaGlwOlVuaXQsZ29hbDpQb2ludCAmIHtoZWFkaW5nPzpudW1iZXJ9LHRyYWZmaWNDbGVhcjooZnJvbTpTaGlwUG9zZSx0bzpTaGlwUG9zZSk9PmJvb2xlYW4sXG4gIGJ1ZGdldDpudW1iZXIsdm95YWdlOmJvb2xlYW4sc3RhdGU6U2hpcFJvdXRlU2VhcmNoU3RhdGUpOlJvdXRlUmVzdWx0fHVuZGVmaW5lZCB7XG4gIGlmKHN0YXRlLnBoYXNlPT09J2RvbmUnKXJldHVybiBzdGF0ZS5yZXN1bHQ7XG4gIC8vIEZhbGxiYWNrIG93bnMgbm8gYWN0aXZlIHdvcmtzcGFjZS4gUmVzdW1lIGl0IGF0IHRoaXMgY2FsbGVyJ3MgZGVwdGgsXG4gIC8vIHJldGFpbmluZyBuZXN0ZWQgaXNvbGF0aW9uIG9ubHkgZm9yIGEgcmVhbCByZWVudHJhbnQgdHJhZmZpYyBjYWxsYmFjay5cbiAgaWYoc3RhdGUucGhhc2U9PT0nZmFsbGJhY2snKXtcbiAgICBjb25zdCB1bm9ic3RydWN0ZWQ9YWR2YW5jZVNoaXBSb3V0ZVNlYXJjaChtYXAsc2hpcCxnb2FsLGVtcHR5VHJhZmZpYyxJbmZpbml0eSx2b3lhZ2Usc3RhdGUuZmFsbGJhY2shKTtcbiAgICBpZighdW5vYnN0cnVjdGVkKXJldHVybjtcbiAgICBjb25zdCBlbmQ9c3RhdGUucGF0aCEuYXQoLTEpID8/IHNoaXAscG9zc2libGU9dW5vYnN0cnVjdGVkLnBvaW50cy5hdCgtMSkgPz8gc2hpcDtcbiAgICBzdGF0ZS5yZXN1bHQ9e3BvaW50czpzdGF0ZS5wYXRoISxwYXJ0aWFsOiEhc3RhdGUuZGVmZXJyZWQgfHwgdW5vYnN0cnVjdGVkLnBhcnRpYWwgfHwgTWF0aC5oeXBvdChlbmQueC1wb3NzaWJsZS54LGVuZC55LXBvc3NpYmxlLnkpPjFlLTd9O1xuICAgIHN0YXRlLnBoYXNlPSdkb25lJztyZXR1cm4gc3RhdGUucmVzdWx0O1xuICB9XG4gIHJvdXRlU2VhcmNoRGVwdGgrKztcbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQ9cGxhblNoaXBSb3V0ZUltcGwobWFwLHNoaXAsZ29hbCx0cmFmZmljQ2xlYXIsYnVkZ2V0LHZveWFnZSxyb3V0ZVNlYXJjaERlcHRoPjEsc3RhdGUpO1xuICAgIGlmKHJlc3VsdCl7c3RhdGUucmVzdWx0PXJlc3VsdDtzdGF0ZS5waGFzZT0nZG9uZSc7fXJldHVybiByZXN1bHQ7XG4gIH1maW5hbGx5e3JvdXRlU2VhcmNoRGVwdGgtLTt9XG59XG5mdW5jdGlvbiBwbGFuU2hpcFJvdXRlSW1wbChtYXA6IFNlYU1hcCwgc2hpcDogVW5pdCwgZ29hbDogUG9pbnQgJiB7aGVhZGluZz86bnVtYmVyfSwgdHJhZmZpY0NsZWFyOiAoZnJvbTpTaGlwUG9zZSx0bzpTaGlwUG9zZSk9PmJvb2xlYW4sIGJ1ZGdldDpudW1iZXIsIHZveWFnZTpib29sZWFuLCBuZXN0ZWQ6Ym9vbGVhbixzdGF0ZT86U2hpcFJvdXRlU2VhcmNoU3RhdGUpOiBSb3V0ZVJlc3VsdHx1bmRlZmluZWQge1xuICAvLyBUaGUgcmVhbCB0cmFmZmljIHByb3ZpZGVyIGRlY2xhcmVzIGFuIGVtcHR5IGZyb3plbiBvYnN0YWNsZSBzZXQuIEN1c3RvbVxuICAvLyBjYWxsYmFja3Mgd2l0aG91dCB0aGF0IGRlY2xhcmF0aW9uIHN0aWxsIHJlY2VpdmUgZXZlcnkgb3JpZ2luYWwgY2hlY2suXG4gIGNvbnN0IG5vVHJhZmZpYyA9IHRyYWZmaWNDbGVhciA9PT0gZW1wdHlUcmFmZmljIHx8ICh0cmFmZmljQ2xlYXIgYXMge2hhc1RyYWZmaWM/OmJvb2xlYW59KS5oYXNUcmFmZmljID09PSBmYWxzZTtcbiAgY29uc3Qgb3JpZ2luYWxUcmFmZmljPXRyYWZmaWNDbGVhcjtsZXQgdHJhZmZpY0Jsb2NrZWQ9c3RhdGU/LnRyYWZmaWNCbG9ja2VkPz9mYWxzZTtcbiAgdHJhZmZpY0NsZWFyPW5vVHJhZmZpYyA/IGVtcHR5VHJhZmZpYyA6IChmcm9tLHRvKT0+e2NvbnN0IGNsZWFyPW9yaWdpbmFsVHJhZmZpYyhmcm9tLHRvKTt0cmFmZmljQmxvY2tlZCB8fD0gIWNsZWFyO3JldHVybiBjbGVhcjt9O1xuICBjb25zdCB0ID0gbWFwLnRlcnJhaW47XG4gIGlmICghdClcbiAgICByZXR1cm4ge3BvaW50czpbeyAuLi5nb2FsLCBoZWFkaW5nOiBNYXRoLnJvdW5kKE1hdGguYXRhbjIoZ29hbC55IC0gc2hpcC55LCBnb2FsLnggLSBzaGlwLngpICogMWU5KSAvIDFlOSB9XSxwYXJ0aWFsOmZhbHNlfTtcbiAgY29uc3QgZ3JpZCA9IGdyaWRGb3IobWFwLCBzaGlwKSwgc2l6ZSA9IGdyaWQuZml0cy5sZW5ndGg7XG4gIGNvbnN0IGxpbWl0cz1zaGlwTW90aW9uTGltaXRzKHNoaXApLGNydWlzZT1NYXRoLm1heCgxZS02LGNvdXJzZVBlcmZvcm1hbmNlKHNoaXAsbWFwLDAse2Fzc3VtZVRyaW1tZWQ6dHJ1ZX0pLm1heEZvcndhcmRTcGVlZCksdHVyblNwZWVkPU1hdGgubWF4KDFlLTYsbGltaXRzLnR1cm5SYXRlKTtcbiAgY29uc3QgY291cnNlU3BlZWRzPUFycmF5LmZyb20oe2xlbmd0aDpESVJFQ1RJT05TfSwoXyxoKT0+e1xuICAgIGNvbnN0IHBlcmZvcm1hbmNlPWNvdXJzZVBlcmZvcm1hbmNlKHNoaXAsbWFwLGgqQU5HTEUse2Fzc3VtZVRyaW1tZWQ6dHJ1ZX0pO1xuICAgIHJldHVybiB7Zm9yd2FyZDpNYXRoLm1heChwZXJmb3JtYW5jZS50YXJnZXRTcGVlZCxwZXJmb3JtYW5jZS5hdXhpbGlhcnlTcGVlZCkscmV2ZXJzZTpNYXRoLm1pbihsaW1pdHMucmV2ZXJzZVNwZWVkLHBlcmZvcm1hbmNlLmF1eGlsaWFyeVNwZWVkKX07XG4gIH0pO1xuICBjb25zdCBlZGdlV2VpZ2h0cyA9IGNvdXJzZVNwZWVkcy5tYXAoKHBlcmZvcm1hbmNlLGgpID0+IHtcbiAgICBjb25zdCBbZHgsZHldPVNURVBTW2hdISwgZGlzdGFuY2U9Z3JpZC5jZWxsKihkeCAmJiBkeSA/IE1hdGguU1FSVDIgOiAxKTtcbiAgICByZXR1cm4ge2ZvcndhcmQ6ZGlzdGFuY2UvTWF0aC5tYXgoMWUtNixwZXJmb3JtYW5jZS5mb3J3YXJkKSxyZXZlcnNlOmRpc3RhbmNlL01hdGgubWF4KDFlLTYscGVyZm9ybWFuY2UucmV2ZXJzZSl9O1xuICB9KTtcbiAgY29uc3QgbGF0dGljZSA9IGdyaWQ7XG4gIGNvbnN0IHBvc2UgPSAoaWQ6IG51bWJlcik6IFNoaXBQb3NlID0+IHsgY29uc3QgY2VsbCA9IE1hdGguZmxvb3IoaWQgLyBESVJFQ1RJT05TKTsgcmV0dXJuIHsgeDogKGNlbGwgJSBsYXR0aWNlLmNvbHMgKyAuNSkgKiBsYXR0aWNlLmNlbGwsIHk6IChNYXRoLmZsb29yKGNlbGwgLyBsYXR0aWNlLmNvbHMpICsgLjUpICogbGF0dGljZS5jZWxsLCBoZWFkaW5nOiAoaWQgJSBESVJFQ1RJT05TKSAqIEFOR0xFIH07IH07XG4gIGNvbnN0IHNhdmVkVHJhZmZpYz1uZXcgTWFwKHN0YXRlPy50cmFmZmljRml0cz8ubWFwKGVudHJ5PT5bZW50cnkuaWQsZW50cnkuY2xlYXJdKSk7XG4gIGNvbnN0IGZpdHMgPSAoaWQ6IG51bWJlcikgPT4ge1xuICAgIGlmICghZ3JpZC5maXRzW2lkXSlcbiAgICAgIGdyaWQuZml0c1tpZF0gPSBtYXNrRml0cyhtYXAsIGdyaWQsIGlkLCBncmlkLm1hc2tzW2lkICUgRElSRUNUSU9OU10hWzBdISkgPyAxIDogLTE7XG4gICAgaWYoZ3JpZC5maXRzW2lkXSE9PTEpcmV0dXJuIGZhbHNlO1xuICAgIGlmKG5vVHJhZmZpYylyZXR1cm4gdHJ1ZTtcbiAgICAvLyBUcmFmZmljIGNoYW5nZXMgYmV0d2VlbiBzZWFyY2hlcyBldmVuIG9uIHVuY2hhbmdlZCB0ZXJyYWluLiBTaWduZWRcbiAgICAvLyBnZW5lcmF0aW9ucyByZXRhaW4gbm8gc3RhbGUgcmVzdWx0LCBhbmQgYXZvaWQgYSBtYXAtc2l6ZWQgYWxsb2NhdGlvblxuICAgIC8vIGZvciBldmVyeSByZXBsYW4gKG9yIGFueSB0cmFmZmljIGFycmF5IG9uIHRoZSBkaXJlY3QtY29ubmVjdG9yIHBhdGgpLlxuICAgIGlmKHRyYWZmaWNGaXRzW2lkXSE9PWdlbmVyYXRpb24gJiYgdHJhZmZpY0ZpdHNbaWRdIT09LWdlbmVyYXRpb24pe2NvbnN0IGF0PXBvc2UoaWQpO2NvbnN0IGNsZWFyPXRyYWZmaWNDbGVhcihhdCxhdCk7dHJhZmZpY0ZpdHNbaWRdPWNsZWFyP2dlbmVyYXRpb246LWdlbmVyYXRpb247aWYoc3RhdGUpc2F2ZWRUcmFmZmljLnNldChpZCxjbGVhcik7fVxuICAgIHJldHVybiB0cmFmZmljRml0c1tpZF09PT1nZW5lcmF0aW9uO1xuICB9O1xuICBjb25zdCByZXF1ZXN0ZWQ9Z29hbC5oZWFkaW5nPT09dW5kZWZpbmVkP3VuZGVmaW5lZDp7eDpnb2FsLngseTpnb2FsLnksaGVhZGluZzpnb2FsLmhlYWRpbmd9O1xuICBsZXQgcHJlcGFyZWRUYXJnZXQ9c3RhdGU/LnRhcmdldCxkZWZlcnJlZD1zdGF0ZT8uZGVmZXJyZWQ/P2ZhbHNlO1xuICBjb25zdCBsZW5ndGggPSBzaGlwUHJvZmlsZShzaGlwKSEubGVuZ3RoO1xuICBjb25zdCBzdGFydCA9IHsgeDogc2hpcC54LCB5OiBzaGlwLnksIGhlYWRpbmc6IHNoaXAuc2FpbGluZz8uaGVhZGluZyA/PyAwIH07XG4gIGlmKCFwcmVwYXJlZFRhcmdldCl7XG4gICAgY29uc3QgdGVycmFpblRhcmdldD1yZXF1ZXN0ZWQgJiYgaHVsbEZpdHMobWFwLHNoaXAscmVxdWVzdGVkKSA/IHJlcXVlc3RlZCA6IG5lYXJlc3RTaGlwUG9zZShtYXAsc2hpcCxnb2FsKTtcbiAgICBwcmVwYXJlZFRhcmdldD10ZXJyYWluVGFyZ2V0ICYmIHRyYWZmaWNDbGVhcih0ZXJyYWluVGFyZ2V0LHRlcnJhaW5UYXJnZXQpID8gdGVycmFpblRhcmdldCA6IG5lYXJlc3RTaGlwUG9zZShtYXAsc2hpcCxnb2FsLHNoaXAscG9zZT0+dHJhZmZpY0NsZWFyKHBvc2UscG9zZSkpO1xuICAgIGNvbnN0IHRhcmdldD1wcmVwYXJlZFRhcmdldDtcbiAgICBkZWZlcnJlZD0hIXRlcnJhaW5UYXJnZXQgJiYgKCF0YXJnZXQgfHwgTWF0aC5oeXBvdCh0YXJnZXQueC10ZXJyYWluVGFyZ2V0LngsdGFyZ2V0LnktdGVycmFpblRhcmdldC55KT4xZS03XG4gICAgICB8fCBnb2FsLmhlYWRpbmchPT11bmRlZmluZWQgJiYgTWF0aC5hYnMoaGVhZGluZ0RpZmZlcmVuY2UodGFyZ2V0LmhlYWRpbmcsdGVycmFpblRhcmdldC5oZWFkaW5nKSk+MWUtNyk7XG4gICAgaWYoIXRhcmdldClyZXR1cm4ge3BvaW50czpbXSxwYXJ0aWFsOmRlZmVycmVkfTtcbiAgICBjb25zdCBkZXN0aW5hdGlvbj1yZXF1ZXN0ZWQ/dGFyZ2V0Ont4OnRhcmdldC54LHk6dGFyZ2V0Lnl9O1xuICAgIGNvbnN0IGRpcmVjdD1rZWVsQ29ubmVjdG9yKG1hcCxzaGlwLHN0YXJ0LGRlc3RpbmF0aW9uLHRyYWZmaWNDbGVhcik7XG4gICAgaWYoZGlyZWN0KXJldHVybiB7cG9pbnRzOmRpcmVjdC5maWx0ZXIoKHBvaW50LGkpPT5pIT09MCB8fCBNYXRoLmh5cG90KHBvaW50Lngtc3RhcnQueCxwb2ludC55LXN0YXJ0LnkpPjFlLTdcbiAgICAgIHx8IE1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKHN0YXJ0LmhlYWRpbmcscG9pbnQuaGVhZGluZykpPjFlLTcgfHwgZGlyZWN0Lmxlbmd0aD09PTEpLHBhcnRpYWw6ZGVmZXJyZWR9O1xuICAgIGNvbnN0IGFycml2YWw9YXJyaXZhbENvbm5lY3RvckZvcihtYXAsc2hpcCx0YXJnZXQsdHJhZmZpY0NsZWFyKShzdGFydCk7XG4gICAgaWYoYXJyaXZhbClyZXR1cm4ge3BvaW50czphcnJpdmFsLHBhcnRpYWw6ZGVmZXJyZWR9O1xuICAgIGNvbnN0IGRpcmVjdGlvbj1NYXRoLmF0YW4yKHRhcmdldC55LXN0YXJ0LnksdGFyZ2V0Lngtc3RhcnQueCk7XG4gICAgaWYoW2RpcmVjdGlvbixkaXJlY3Rpb24rTWF0aC5QSV0uZXZlcnkoaGVhZGluZz0+IWh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAsc3RhcnQsey4uLnN0YXJ0LGhlYWRpbmd9KSB8fCAhdHJhZmZpY0NsZWFyKHN0YXJ0LHsuLi5zdGFydCxoZWFkaW5nfSkpKXtcbiAgICAgIGNvbnN0IGRlcGFydHVyZT1kZXBhcnR1cmVSb3V0ZShtYXAsc2hpcCx0YXJnZXQsdHJhZmZpY0NsZWFyKTtcbiAgICAgIGlmKGRlcGFydHVyZSlyZXR1cm4ge3BvaW50czpkZXBhcnR1cmUscGFydGlhbDp0cnVlfTtcbiAgICB9XG4gICAgaWYoc3RhdGUpe3N0YXRlLnRhcmdldD10YXJnZXQ7c3RhdGUuZGVmZXJyZWQ9ZGVmZXJyZWQ7c3RhdGUudHJhZmZpY0Jsb2NrZWQ9dHJhZmZpY0Jsb2NrZWQ7c3RhdGUucGhhc2U9J2VudHJhbmNlJztyZXR1cm47fVxuICB9XG4gIGNvbnN0IHRhcmdldD1wcmVwYXJlZFRhcmdldCE7XG4gIGNvbnN0IGRlc3RpbmF0aW9uPXJlcXVlc3RlZD90YXJnZXQ6e3g6dGFyZ2V0LngseTp0YXJnZXQueX07XG4gIGNvbnN0IGFycml2ZT1hcnJpdmFsQ29ubmVjdG9yRm9yKG1hcCxzaGlwLHRhcmdldCx0cmFmZmljQ2xlYXIpO1xuICBjb25zdCB3b3Jrc3BhY2UgPSBzZWFyY2hXb3Jrc3BhY2Uoc2l6ZSxuZXN0ZWQpLCB7IGNvc3RzLCBwYXJlbnRzOiBwcmV2aW91cywgc3RhbXBzLCB0cmFmZmljRml0cyxcbiAgICBiYXNlUG90ZW50aWFscyxiYXNlU3RhbXBzLGdlbmVyYXRpb24gfSA9IHdvcmtzcGFjZSwgZnJvbnRpZXIgPSBuZXN0ZWQgPyBuZXcgRnJvbnRpZXIoKSA6IHJvdXRlRnJvbnRpZXIucmVzZXQoKTtcbiAgLy8gQSBsb2NhbCB0cmFmZmljIGJ1ZGdldCBhbmQgYSBzaG9ydCBiZXJ0aCBzZWFyY2ggc2hvdWxkIHN0YXkgbG9jYWwuIFRoZVxuICAvLyByZXVzYWJsZSBtYXAgZmllbGQgcGF5cyBmb3IgaXRzZWxmIG9uIGxvbmcsIHVuYm91bmRlZCBjb2FzdGFsIHZveWFnZXM7XG4gIC8vIGNhcCBpdHMgbWFwIHNpemUgYXMgd2VsbCBhcyBpdHMgcmV0YWluZWQgZGVzdGluYXRpb24gY291bnQuXG4gIGNvbnN0IHVzZURpc3RhbmNlcyA9IHZveWFnZSAmJiAhTnVtYmVyLmlzRmluaXRlKGJ1ZGdldCkgJiYgbGF0dGljZS5jb2xzICogbGF0dGljZS5yb3dzIDw9IDI2MjE0NFxuICAgICYmIE1hdGguaHlwb3QodGFyZ2V0LnggLSBzdGFydC54LCB0YXJnZXQueSAtIHN0YXJ0LnkpID4gbGF0dGljZS5jZWxsICogMjRcbiAgICAmJiAhb3BlbldhdGVyQm94KG1hcCwgTWF0aC5taW4oc3RhcnQueCwgdGFyZ2V0LngpIC0gbGF0dGljZS5jZWxsIC8gMiwgTWF0aC5taW4oc3RhcnQueSwgdGFyZ2V0LnkpIC0gbGF0dGljZS5jZWxsIC8gMixcbiAgICAgIE1hdGgubWF4KHN0YXJ0LngsIHRhcmdldC54KSArIGxhdHRpY2UuY2VsbCAvIDIsIE1hdGgubWF4KHN0YXJ0LnksIHRhcmdldC55KSArIGxhdHRpY2UuY2VsbCAvIDIpO1xuICBjb25zdCBkaXJlY3Rpb25Db3N0cyA9IGNvdXJzZVNwZWVkcy5tYXAoKHBlcmZvcm1hbmNlLCBoKSA9PiBjcnVpc2UgLyBNYXRoLm1heCgxZS02LCBwZXJmb3JtYW5jZS5mb3J3YXJkLCBjb3Vyc2VTcGVlZHNbKGggKyA0KSAlIERJUkVDVElPTlNdIS5yZXZlcnNlKSk7XG4gIGNvbnN0IGRpc3RhbmNlcyA9IHVzZURpc3RhbmNlcyA/IHRlcnJhaW5EaXN0YW5jZXMobWFwLCBncmlkLCBzdGFydCx0YXJnZXQsIGRpcmVjdGlvbkNvc3RzKSA6IHVuZGVmaW5lZDtcbiAgLy8gRGlyZWN0ZWQgc2hvcnRlc3QgcGF0aHMgb2JleSBkKHAsIGxhbmRtYXJrKSAtIGQocSwgbGFuZG1hcmspIDw9IGQocCwgcSkuXG4gIC8vIFRha2luZyB0aGUgbGFyZ2VzdCBwb3RlbnRpYWwgb2YgZXZlcnkgcG9zc2libGUgZmluYWwtY29ubmVjdG9yIHN0YXRlXG4gIC8vIHRoZXJlZm9yZSByZW1haW5zIGEgbG93ZXIgYm91bmQgZXZlbiB3aXRoIGFuIGFzeW1tZXRyaWMgd2luZCBwb2xhci5cbiAgY29uc3QgdGFyZ2V0Q29sID0gTWF0aC5mbG9vcih0YXJnZXQueCAvIGxhdHRpY2UuY2VsbCksIHRhcmdldFJvdyA9IE1hdGguZmxvb3IodGFyZ2V0LnkgLyBsYXR0aWNlLmNlbGwpO1xuICBsZXQgdGVybWluYWxQb3RlbnRpYWwgPSAwO1xuICBpZiAoZGlzdGFuY2VzKSBmb3IgKGxldCB5ID0gTWF0aC5tYXgoMCwgdGFyZ2V0Um93IC0gMik7IHkgPD0gTWF0aC5taW4obGF0dGljZS5yb3dzIC0gMSwgdGFyZ2V0Um93ICsgMik7IHkrKylcbiAgICBmb3IgKGxldCB4ID0gTWF0aC5tYXgoMCwgdGFyZ2V0Q29sIC0gMik7IHggPD0gTWF0aC5taW4obGF0dGljZS5jb2xzIC0gMSwgdGFyZ2V0Q29sICsgMik7IHgrKylcbiAgICAgIGlmIChncmlkLndhdGVyW3kgKiBncmlkLmNvbHMgKyB4XSA9PT0gMVxuICAgICAgICAmJiBNYXRoLmh5cG90KCh4ICsgLjUpICogbGF0dGljZS5jZWxsIC0gdGFyZ2V0LngsICh5ICsgLjUpICogbGF0dGljZS5jZWxsIC0gdGFyZ2V0LnkpIDw9IGxhdHRpY2UuY2VsbCAqIDEuNSlcbiAgICAgICAgdGVybWluYWxQb3RlbnRpYWwgPSBNYXRoLm1heCh0ZXJtaW5hbFBvdGVudGlhbCwgc2VhUG90ZW50aWFsQXQoZGlzdGFuY2VzLHgseSkpO1xuICBjb25zdCBiYXNlUG90ZW50aWFsID0gKHRpbGU6bnVtYmVyLHg6bnVtYmVyLHk6bnVtYmVyKSA9PiB7XG4gICAgaWYoYmFzZVN0YW1wc1t0aWxlXT09PWdlbmVyYXRpb24pcmV0dXJuIGJhc2VQb3RlbnRpYWxzW3RpbGVdITtcbiAgICBjb25zdCBkaXN0YW5jZSA9IGRpc3RhbmNlcyA/IHNlYVBvdGVudGlhbEF0KGRpc3RhbmNlcyx0aWxlJWxhdHRpY2UuY29scyxNYXRoLmZsb29yKHRpbGUvbGF0dGljZS5jb2xzKSkgOiAwO1xuICAgIGNvbnN0IGxvd2VyQm91bmQgPSBkaXN0YW5jZSAtIHRlcm1pbmFsUG90ZW50aWFsO1xuICAgIGJhc2VTdGFtcHNbdGlsZV09Z2VuZXJhdGlvbjtcbiAgICByZXR1cm4gYmFzZVBvdGVudGlhbHNbdGlsZV09TWF0aC5tYXgoTWF0aC5oeXBvdCh4IC0gdGFyZ2V0LngsIHkgLSB0YXJnZXQueSksIE51bWJlci5pc0Zpbml0ZShsb3dlckJvdW5kKSA/IGxvd2VyQm91bmQgOiAwKSAvIGNydWlzZTtcbiAgfTtcbiAgY29uc3QgaGV1cmlzdGljID0gKGlkOiBudW1iZXIsIHg6IG51bWJlciwgeTogbnVtYmVyKSA9PiBiYXNlUG90ZW50aWFsKE1hdGguZmxvb3IoaWQvRElSRUNUSU9OUykseCx5KTtcbiAgY29uc3QgY29zdCA9IChpZDogbnVtYmVyKSA9PiBzdGFtcHNbaWRdID09PSBnZW5lcmF0aW9uID8gY29zdHNbaWRdISA6IEluZmluaXR5O1xuICBjb25zdCByZWFjaGVkPW5ldyBNYXAoc3RhdGU/Lm5vZGVzPy5tYXAoZW50cnk9PltlbnRyeS5pZCxlbnRyeV0pKTtcbiAgZm9yKGNvbnN0IGVudHJ5IG9mIHJlYWNoZWQudmFsdWVzKCkpe3N0YW1wc1tlbnRyeS5pZF09Z2VuZXJhdGlvbjtjb3N0c1tlbnRyeS5pZF09ZW50cnkuY29zdDtwcmV2aW91c1tlbnRyeS5pZF09ZW50cnkucGFyZW50O31cbiAgZm9yKGNvbnN0IFtpZCxjbGVhcl0gb2Ygc2F2ZWRUcmFmZmljKXRyYWZmaWNGaXRzW2lkXT1jbGVhcj9nZW5lcmF0aW9uOi1nZW5lcmF0aW9uO1xuICBpZihzdGF0ZT8uaGVhcClmcm9udGllci5yZXN0b3JlKHN0YXRlLmhlYXApO1xuICBjb25zdCBzZXRDb3N0ID0gKGlkOiBudW1iZXIsIHZhbHVlOiBudW1iZXIsIHBhcmVudDogbnVtYmVyKSA9PiB7XG4gICAgc3RhbXBzW2lkXSA9IGdlbmVyYXRpb247IGNvc3RzW2lkXSA9IHZhbHVlOyBwcmV2aW91c1tpZF0gPSBwYXJlbnQ7XG4gICAgaWYoc3RhdGUpcmVhY2hlZC5zZXQoaWQse2lkLGNvc3Q6dmFsdWUscGFyZW50fSk7XG4gIH07XG4gIGNvbnN0IHByZWZpeGVzPW5ldyBNYXA8bnVtYmVyLFNoaXBQb3NlW10+KHN0YXRlPy5wcmVmaXhlcz8ubWFwKGVudHJ5PT5bZW50cnkuaWQsZW50cnkucG9pbnRzXSkpLFxuICAgIGVudHJhbmNlcz1uZXcgTWFwPG51bWJlcixTaGlwUG9zZVtdW10+KHN0YXRlPy5lbnRyYW5jZXM/Lm1hcChlbnRyeT0+W2VudHJ5LmNlbGwsZW50cnkucG9pbnRzXSkpO1xuICBjb25zdCBwYXVzZT0oKT0+e1xuICAgIHN0YXRlIS5ub2Rlcz1BcnJheS5mcm9tKHJlYWNoZWQudmFsdWVzKCkpO3N0YXRlIS50cmFmZmljRml0cz1BcnJheS5mcm9tKHNhdmVkVHJhZmZpYywoW2lkLGNsZWFyXSk9Pih7aWQsY2xlYXJ9KSk7XG4gICAgc3RhdGUhLmhlYXA9ZnJvbnRpZXIuc2F2ZSgpO3N0YXRlIS5wcmVmaXhlcz1BcnJheS5mcm9tKHByZWZpeGVzLChbaWQscG9pbnRzXSk9Pih7aWQscG9pbnRzfSkpO1xuICAgIHN0YXRlIS5lbnRyYW5jZXM9QXJyYXkuZnJvbShlbnRyYW5jZXMsKFtjZWxsLHBvaW50c10pPT4oe2NlbGwscG9pbnRzfSkpO3N0YXRlIS50cmFmZmljQmxvY2tlZD10cmFmZmljQmxvY2tlZDtcbiAgfTtcbiAgY29uc3QgY29sID0gTWF0aC5mbG9vcihzaGlwLnggLyBsYXR0aWNlLmNlbGwpLCByb3cgPSBNYXRoLmZsb29yKHNoaXAueSAvIGxhdHRpY2UuY2VsbCk7XG4gIGxldCBlbnRyYW5jZUN1cnNvcj0wLGVudHJhbmNlV29yaz0wO1xuICBpZighc3RhdGUgfHwgc3RhdGUucGhhc2U9PT0nZW50cmFuY2UnKWZvciAobGV0IHkgPSBNYXRoLm1heCgwLCByb3cgLSAxKTsgeSA8PSBNYXRoLm1pbihsYXR0aWNlLnJvd3MgLSAxLCByb3cgKyAxKTsgeSsrKVxuICAgIGZvciAobGV0IHggPSBNYXRoLm1heCgwLCBjb2wgLSAxKTsgeCA8PSBNYXRoLm1pbihsYXR0aWNlLmNvbHMgLSAxLCBjb2wgKyAxKTsgeCsrKVxuICAgICAgZm9yIChsZXQgaCA9IDA7IGggPCBESVJFQ1RJT05TOyBoKyspIHtcbiAgICAgICAgaWYoc3RhdGUgJiYgZW50cmFuY2VDdXJzb3IrKzwoc3RhdGUuZW50cmFuY2VDdXJzb3I/PzApKWNvbnRpbnVlO1xuICAgICAgICBpZihzdGF0ZSAmJiBlbnRyYW5jZVdvcmsrKz49MTYpe3N0YXRlLmVudHJhbmNlQ3Vyc29yPWVudHJhbmNlQ3Vyc29yLTE7cGF1c2UoKTtyZXR1cm47fVxuICAgICAgICBjb25zdCBpZCA9ICh5ICogbGF0dGljZS5jb2xzICsgeCkgKiBESVJFQ1RJT05TICsgaCwgcCA9IHBvc2UoaWQpO1xuICAgICAgICBpZiAoIWZpdHMoaWQpKVxuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAvLyBUaGUgZWlnaHQgaGVhZGluZ3MgYXQgb25lIGNlbGwgc2hhcmUgdGhlIHNhbWUgYWhlYWQvYXN0ZXJuIGVudHJhbmNlLlxuICAgICAgICAvLyBWYWxpZGF0ZSB0aG9zZSBjb250aW51b3VzIHN3ZWVwcyBvbmNlLCB0aGVuIHRlc3QgZWFjaCBmaW5hbCB5YXcuXG4gICAgICAgIGNvbnN0IGNlbGw9eSpsYXR0aWNlLmNvbHMreDtcbiAgICAgICAgaWYoIWVudHJhbmNlcy5oYXMoY2VsbCkpZW50cmFuY2VzLnNldChjZWxsLGtlZWxDYW5kaWRhdGVzKHNoaXAsc3RhcnQse3g6cC54LHk6cC55fSkuZmlsdGVyKHBvaW50cz0+Y29ubmVjdG9yQ2xlYXIobWFwLHNoaXAsc3RhcnQscG9pbnRzLHRyYWZmaWNDbGVhcikpKTtcbiAgICAgICAgbGV0IHByZWZpeDpTaGlwUG9zZVtdfHVuZGVmaW5lZCxnPUluZmluaXR5O1xuICAgICAgICBmb3IoY29uc3QgZW50cmFuY2Ugb2YgZW50cmFuY2VzLmdldChjZWxsKSEpe1xuICAgICAgICAgIGNvbnN0IGVuZD1lbnRyYW5jZS5hdCgtMSkgPz8gc3RhcnQ7XG4gICAgICAgICAgaWYoIWh1bGxQYXNzYWdlQ2xlYXIobWFwLHNoaXAsZW5kLHApIHx8ICF0cmFmZmljQ2xlYXIoZW5kLHApKWNvbnRpbnVlO1xuICAgICAgICAgIGNvbnN0IHBvaW50cz1bLi4uZW50cmFuY2UsLi4uKE1hdGguYWJzKGhlYWRpbmdEaWZmZXJlbmNlKGVuZC5oZWFkaW5nLHAuaGVhZGluZykpPjFlLTc/W3BdOltdKV0sdGltZT1yb3V0ZVRpbWUobWFwLHNoaXAsc3RhcnQscG9pbnRzKTtcbiAgICAgICAgICBpZih0aW1lPGcpe2c9dGltZTtwcmVmaXg9cG9pbnRzO31cbiAgICAgICAgfVxuICAgICAgICBpZighcHJlZml4KWNvbnRpbnVlO1xuICAgICAgICBzZXRDb3N0KGlkLGcsLTEpO3ByZWZpeGVzLnNldChpZCxwcmVmaXgpO1xuICAgICAgICBmcm9udGllci5wdXNoKGlkLCBnLCBnICsgaGV1cmlzdGljKGlkLCBwLngsIHAueSkpO1xuICAgICAgfVxuICBpZihzdGF0ZSAmJiBzdGF0ZS5waGFzZT09PSdlbnRyYW5jZScpe3N0YXRlLnBoYXNlPSdzZWFyY2gnO3BhdXNlKCk7cmV0dXJuO31cbiAgaWYoIWZyb250aWVyLmxlbmd0aCl7Y29uc3QgZGVwYXJ0dXJlPWRlcGFydHVyZVJvdXRlKG1hcCxzaGlwLHRhcmdldCx0cmFmZmljQ2xlYXIsdHJ1ZSk7cmV0dXJue3BvaW50czpkZXBhcnR1cmUgPz8gW10scGFydGlhbDohIWRlcGFydHVyZSB8fCBkZWZlcnJlZCB8fCB0cmFmZmljQmxvY2tlZH07fVxuICBsZXQgYmVzdCA9IHN0YXRlPy5iZXN0Pz8tMSwgYmVzdEdhcCA9IHN0YXRlPy5iZXN0R2FwPz9JbmZpbml0eSx2aXNpdGVkPXN0YXRlPy52aXNpdGVkPz8wLHBhcnRpYWw9ZmFsc2UsdGVybWluYWw6U2hpcFBvc2VbXXx1bmRlZmluZWQsZXhwYW5kZWQ9MDtcbiAgLy8gVGhpcyBoZWxwZXIgYmVsb25ncyB0byB0aGUgc2VhcmNoLCByYXRoZXIgdGhhbiBlYWNoIGV4cGFuZGVkIHN0YXRlLlxuICAvLyBLZWVwaW5nIG9uZSBjbG9zdXJlIGF2b2lkcyBhbGxvY2F0aW5nIGFuZCBuYW1pbmcgaXQgaHVuZHJlZHMgb2ZcbiAgLy8gdGhvdXNhbmRzIG9mIHRpbWVzIGR1cmluZyBhIGxvbmcgY29hc3RhbCBvcmRlci5cbiAgY29uc3QgdmlzaXQgPSAoaWQ6IG51bWJlciwgbm9kZUNvc3Q6IG51bWJlciwgcDogU2hpcFBvc2UgfCB1bmRlZmluZWQsIHRvOiBudW1iZXIsIHdlaWdodDogbnVtYmVyLCBzbG90OiBJbnQ4QXJyYXksIGluZGV4OiBudW1iZXIsIG1hc2s6IE9jY3VwYW5jeU1hc2spID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IG5vZGVDb3N0ICsgd2VpZ2h0O1xuICAgIGlmICh2YWx1ZSA+PSBjb3N0KHRvKSB8fCAhZml0cyh0bykpXG4gICAgICByZXR1cm47XG4gICAgaWYgKCFzbG90W2luZGV4XSlcbiAgICAgIHNsb3RbaW5kZXhdID0gbWFza0ZpdHMobWFwLCBncmlkLCBpZCwgbWFzaykgPyAxIDogLTE7XG4gICAgaWYgKHNsb3RbaW5kZXhdICE9PSAxKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHRpbGUgPSBNYXRoLmZsb29yKHRvIC8gRElSRUNUSU9OUyksIHB4ID0gKHRpbGUgJSBsYXR0aWNlLmNvbHMgKyAuNSkgKiBsYXR0aWNlLmNlbGwsIHB5ID0gKE1hdGguZmxvb3IodGlsZSAvIGxhdHRpY2UuY29scykgKyAuNSkgKiBsYXR0aWNlLmNlbGw7XG4gICAgaWYgKCFub1RyYWZmaWMgJiYgIXRyYWZmaWNDbGVhcihwISwge3g6cHgseTpweSxoZWFkaW5nOih0byAlIERJUkVDVElPTlMpKkFOR0xFfSkpXG4gICAgICByZXR1cm47XG4gICAgc2V0Q29zdCh0bywgdmFsdWUsIGlkKTtcbiAgICBmcm9udGllci5wdXNoKHRvLCB2YWx1ZSwgdmFsdWUgKyBoZXVyaXN0aWModG8sIHB4LCBweSkpO1xuICB9O1xuICB3aGlsZSAoZnJvbnRpZXIubGVuZ3RoKSB7XG4gICAgaWYoc3RhdGUgJiYgZXhwYW5kZWQ+PShub1RyYWZmaWM/NDA5NjoxMjgpKXtzdGF0ZS5iZXN0PWJlc3Q7aWYoTnVtYmVyLmlzRmluaXRlKGJlc3RHYXApKXN0YXRlLmJlc3RHYXA9YmVzdEdhcDtzdGF0ZS52aXNpdGVkPXZpc2l0ZWQ7cGF1c2UoKTtyZXR1cm47fVxuICAgIGNvbnN0IGlkID0gZnJvbnRpZXIucG9wKCk7XG4gICAgY29uc3Qgbm9kZUNvc3QgPSBjb3N0KGlkKTtcbiAgICBpZiAoZnJvbnRpZXIucG9wcGVkQ29zdCAhPT0gbm9kZUNvc3QpXG4gICAgICBjb250aW51ZTtcbiAgICBjb25zdCBoID0gaWQgJSBESVJFQ1RJT05TLCBjZWxsID0gTWF0aC5mbG9vcihpZCAvIERJUkVDVElPTlMpLCB4ID0gY2VsbCAlIGxhdHRpY2UuY29scywgeSA9IE1hdGguZmxvb3IoY2VsbCAvIGxhdHRpY2UuY29scyk7XG4gICAgY29uc3QgcHggPSAoeCsuNSkqbGF0dGljZS5jZWxsLCBweSA9ICh5Ky41KSpsYXR0aWNlLmNlbGw7XG4gICAgY29uc3QgcCA9IG5vVHJhZmZpYyA/IHVuZGVmaW5lZCA6IHt4OnB4LHk6cHksaGVhZGluZzpoKkFOR0xFfTtcbiAgICBleHBhbmRlZCsrO1xuICAgIGlmKCsrdmlzaXRlZD5idWRnZXQpe2Jlc3Q9aWQ7cGFydGlhbD10cnVlO2JyZWFrO31cbiAgICBjb25zdCBnYXAgPSBNYXRoLmh5cG90KHB4IC0gdGFyZ2V0LngsIHB5IC0gdGFyZ2V0LnkpO1xuICAgIGlmIChnYXAgPCBiZXN0R2FwIHx8IChnYXAgPT09IGJlc3RHYXAgJiYgY29zdChpZCkgPCAoYmVzdCA8IDAgPyBJbmZpbml0eSA6IGNvc3QoYmVzdCkpKSkge1xuICAgICAgYmVzdCA9IGlkO1xuICAgICAgYmVzdEdhcCA9IGdhcDtcbiAgICB9XG4gICAgaWYoZ2FwPD1sYXR0aWNlLmNlbGwqMS41KXtcbiAgICAgIGNvbnN0IGF0ID0gcCA/PyB7eDpweCx5OnB5LGhlYWRpbmc6aCpBTkdMRX07XG4gICAgICBjb25zdCBjb25uZWN0aW9uPWtlZWxDb25uZWN0b3IobWFwLHNoaXAsYXQsZGVzdGluYXRpb24sdHJhZmZpY0NsZWFyKSA/PyBhcnJpdmUoYXQpO1xuICAgICAgaWYoY29ubmVjdGlvbil7YmVzdD1pZDt0ZXJtaW5hbD1jb25uZWN0aW9uO2JyZWFrO31cbiAgICB9XG4gICAgdmlzaXQoaWQsIG5vZGVDb3N0LCBwLCBjZWxsICogRElSRUNUSU9OUyArIChoICsgMSkgJSBESVJFQ1RJT05TLCBBTkdMRSAvIHR1cm5TcGVlZCwgZ3JpZC50dXJucywgaWQgKiAyLCBncmlkLm1hc2tzW2hdIVsxXSEpO1xuICAgIHZpc2l0KGlkLCBub2RlQ29zdCwgcCwgY2VsbCAqIERJUkVDVElPTlMgKyAoaCArIERJUkVDVElPTlMgLSAxKSAlIERJUkVDVElPTlMsIEFOR0xFIC8gdHVyblNwZWVkLCBncmlkLnR1cm5zLCBpZCAqIDIgKyAxLCBncmlkLm1hc2tzW2hdIVsyXSEpO1xuICAgIC8vIE9ubHkgYWhlYWQvYXN0ZXJuIGVkZ2VzLiBBIGh1bGwgY2Fubm90IHN0cmFmZSBhbG9uZyB0aGUgcm91dGUuXG4gICAgZm9yIChjb25zdCBtYW5ldXZlciBvZiBbMCwyXSkge1xuICAgICAgLy8gQSB2b3lhZ2UgbWF5IGJhY2sgb3V0IG9mIGl0cyBkZXBhcnR1cmUsIGJ1dCBjYW5ub3QgY3J1aXNlIGFzdGVyblxuICAgICAgLy8gdGhyb3VnaCBhIHdob2xlIGNvYXN0IGNvcnJpZG9yIGp1c3QgYmVjYXVzZSB0aGUgd2luZCBjb3N0cyB0aWUuXG4gICAgICBjb25zdCBbZHgsIGR5XSA9IFNURVBTWyhoICsgbWFuZXV2ZXIgKiAyKSAlIERJUkVDVElPTlNdISwgbnggPSB4ICsgZHgsIG55ID0geSArIGR5O1xuICAgICAgaWYodm95YWdlICYmIG1hbmV1dmVyPT09Mil7XG4gICAgICAgIGNvbnN0IGF4PShueCsuNSkqbGF0dGljZS5jZWxsLXN0YXJ0LngsYXk9KG55Ky41KSpsYXR0aWNlLmNlbGwtc3RhcnQueTtcbiAgICAgICAgaWYoTWF0aC5hYnMoYXgpPmxlbmd0aCB8fCBNYXRoLmFicyhheSk+bGVuZ3RoIHx8IE1hdGguaHlwb3QoYXgsYXkpPmxlbmd0aCljb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChueCA+PSAwICYmIG55ID49IDAgJiYgbnggPCBsYXR0aWNlLmNvbHMgJiYgbnkgPCBsYXR0aWNlLnJvd3MpXG4gICAgICAgIHZpc2l0KGlkLCBub2RlQ29zdCwgcCwgKG55ICogbGF0dGljZS5jb2xzICsgbngpICogRElSRUNUSU9OUyArIGgsIG1hbmV1dmVyPT09Mj9lZGdlV2VpZ2h0c1toXSEucmV2ZXJzZTplZGdlV2VpZ2h0c1toXSEuZm9yd2FyZCwgZ3JpZC5tb3ZlcywgaWQgKiA0ICsgbWFuZXV2ZXIsIGdyaWQubWFza3NbaF0hW21hbmV1dmVyICsgM10hKTtcbiAgICB9XG4gIH1cbiAgaWYoc3RhdGUpc3RhdGUudmlzaXRlZD12aXNpdGVkO1xuICBpZiAoYmVzdCA8IDApXG4gICAgcmV0dXJuIHtwb2ludHM6W10scGFydGlhbDpmYWxzZX07XG4gIGNvbnN0IHBhdGg6IFNoaXBQb3NlW10gPSBbXTtcbiAgZm9yIChsZXQgYXQgPSBiZXN0OyBhdCA+PSAwOyBhdCA9IHByZXZpb3VzW2F0XSEpXG4gICAgcGF0aC5wdXNoKHBvc2UoYXQpKTtcbiAgcGF0aC5yZXZlcnNlKCk7XG4gIGNvbnN0IHJvb3Q9cGF0aFswXSE7XG4gIGNvbnN0IHJvb3RJZD0oTWF0aC5mbG9vcihyb290LnkvbGF0dGljZS5jZWxsKSpsYXR0aWNlLmNvbHMrTWF0aC5mbG9vcihyb290LngvbGF0dGljZS5jZWxsKSkqRElSRUNUSU9OUytNYXRoLnJvdW5kKHJvb3QuaGVhZGluZy9BTkdMRSklRElSRUNUSU9OUztcbiAgY29uc3QgcHJlZml4PXByZWZpeGVzLmdldChyb290SWQpID8/IFtyb290XTtcbiAgcGF0aC5zcGxpY2UoMCwxLC4uLnByZWZpeCk7XG4gIGlmKHRlcm1pbmFsKXBhdGgucHVzaCguLi50ZXJtaW5hbCk7XG4gIGlmKCF0ZXJtaW5hbCAmJiB0cmFmZmljQmxvY2tlZCAmJiAhcGFydGlhbCl7XG4gICAgLy8gRXhoYXVzdGluZyBhIHRlbXBvcmFyaWx5IG9jY3VwaWVkIGNvcnJpZG9yIGlzIG5vdCBhcnJpdmFsLiBDb21wYXJlIHRoZVxuICAgIC8vIHRlcnJhaW4tb25seSBlbmRwb2ludCBzbyBhIGdlbnVpbmVseSB1bnJlYWNoYWJsZSBpc2xhbmQvcG9uZCBzdGlsbFxuICAgIC8vIHJldGFpbnMgaXRzIG9yZGluYXJ5IG5lYXJlc3QtcmVhY2hhYmxlIGNvbXBsZXRpb24gc2VtYW50aWNzLlxuICAgIGlmKHN0YXRlKXtcbiAgICAgIHN0YXRlLnBoYXNlPSdmYWxsYmFjayc7c3RhdGUucGF0aD1wYXRoO3N0YXRlLmZhbGxiYWNrPXtwaGFzZToncHJlcGFyZSd9O3N0YXRlLmRlZmVycmVkPWRlZmVycmVkO1xuICAgICAgZGVsZXRlIHN0YXRlLm5vZGVzO2RlbGV0ZSBzdGF0ZS50cmFmZmljRml0cztkZWxldGUgc3RhdGUuaGVhcDtkZWxldGUgc3RhdGUucHJlZml4ZXM7ZGVsZXRlIHN0YXRlLmVudHJhbmNlcztcbiAgICAgIGRlbGV0ZSBzdGF0ZS5iZXN0O2RlbGV0ZSBzdGF0ZS5iZXN0R2FwO2RlbGV0ZSBzdGF0ZS52aXNpdGVkO2RlbGV0ZSBzdGF0ZS5lbnRyYW5jZUN1cnNvcjtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdW5vYnN0cnVjdGVkPXBsYW5TaGlwUm91dGUobWFwLHNoaXAsZ29hbCx1bmRlZmluZWQsSW5maW5pdHksdm95YWdlKSxlbmQ9cGF0aC5hdCgtMSkgPz8gc3RhcnQscG9zc2libGU9dW5vYnN0cnVjdGVkLnBvaW50cy5hdCgtMSkgPz8gc3RhcnQ7XG4gICAgcGFydGlhbD11bm9ic3RydWN0ZWQucGFydGlhbCB8fCBNYXRoLmh5cG90KGVuZC54LXBvc3NpYmxlLngsZW5kLnktcG9zc2libGUueSk+MWUtNztcbiAgfVxuICByZXR1cm4ge3BvaW50czpwYXRoLHBhcnRpYWw6cGFydGlhbCB8fCBkZWZlcnJlZH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsY0FBYztBQUN2QixTQUFTLFFBQVEsY0FBYztBQUMvQixTQUFTLG1CQUErQjtBQUN4QyxTQUFTLGFBQWEsWUFBWSxZQUFZLG9CQUFvQjtBQUVsRSxTQUFTLFlBQVksY0FBYyxlQUFlLGVBQWUsMEJBQTBCO0FBQzNGLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8scUJBQXFCO0FBQzVCLFNBQVMsNEJBQWdEO0FBQ3pELFNBQVMsV0FBVywwQkFBMEI7QUFDOUMsU0FBUyxtQkFBbUIsc0JBQXlDO0FBV3JFLFNBQVMsY0FBYyxNQUFjLElBQW9CO0FBQ3ZELFFBQU0sWUFBVSxHQUFHLGFBQWE7QUFDaEMsTUFBRyxLQUFLLElBQUksU0FBUyxJQUFFLEtBQUssUUFBTztBQUNuQyxRQUFNLElBQUUsS0FBSyxLQUFHLE9BQU8sR0FBRyxPQUFPLElBQUUsT0FBTyxLQUFLLE9BQU8sS0FBRztBQUN6RCxRQUFNLElBQUUsS0FBSyxLQUFHLE9BQU8sR0FBRyxPQUFPLElBQUUsT0FBTyxLQUFLLE9BQU8sS0FBRztBQUd6RCxTQUFPLEtBQUssTUFBTSxJQUFFLEdBQUcsR0FBRSxJQUFFLEdBQUcsQ0FBQyxJQUFFLE9BQUssWUFBVTtBQUNsRDtBQUdPLGdCQUFTLFdBQVcsTUFBZ0IsSUFBYyxVQUE0QjtBQUNuRixRQUFNLFVBQVEsS0FBSyxVQUFRLGtCQUFrQixLQUFLLFNBQVEsR0FBRyxPQUFPLElBQUU7QUFDdEUsTUFBRyxHQUFHLE9BQU07QUFBQyxVQUFNLFNBQU8sS0FBSyxJQUFFLEdBQUcsTUFBTSxLQUFHLE9BQU8sS0FBSyxPQUFPLEtBQUcsS0FBSyxJQUFFLEdBQUcsTUFBTSxLQUFHLE9BQU8sS0FBSyxPQUFPO0FBQUUsV0FBTSxFQUFDLEdBQUUsR0FBRyxNQUFNLElBQUUsUUFBTSxPQUFPLE9BQU8sR0FBRSxHQUFFLEdBQUcsTUFBTSxJQUFFLFFBQU0sT0FBTyxPQUFPLEdBQUUsUUFBTztBQUFBLEVBQUU7QUFDak0sUUFBTSxZQUFVLGNBQWMsTUFBSyxFQUFFO0FBQ3JDLE1BQUcsVUFBVSxRQUFNLEVBQUMsR0FBRSxLQUFLLEtBQUcsT0FBTyxPQUFPLElBQUUsT0FBTyxLQUFLLE9BQU8sS0FBRyxXQUFVLEdBQUUsS0FBSyxLQUFHLE9BQU8sT0FBTyxJQUFFLE9BQU8sS0FBSyxPQUFPLEtBQUcsV0FBVSxRQUFPO0FBQy9JLFNBQU0sRUFBQyxHQUFFLEtBQUssS0FBRyxHQUFHLElBQUUsS0FBSyxLQUFHLFVBQVMsR0FBRSxLQUFLLEtBQUcsR0FBRyxJQUFFLEtBQUssS0FBRyxVQUFTLFFBQU87QUFDaEY7QUFFQSxNQUFNLGNBQWMsb0JBQUksUUFLckI7QUFFSCxTQUFTLGFBQWEsS0FBYSxNQUFjLEtBQWEsT0FBZSxRQUFnQjtBQUMzRixNQUFJLE9BQU8sS0FBSyxNQUFNLEtBQUssUUFBUSxJQUFJLFNBQVMsU0FBUyxJQUFJO0FBQzNELFdBQU87QUFDVCxRQUFNLElBQUksSUFBSTtBQUNkLE1BQUksQ0FBQztBQUNILFdBQU87QUFDVCxNQUFJLFFBQVEsWUFBWSxJQUFJLENBQUM7QUFDN0IsTUFBSSxDQUFDLFNBQVMsTUFBTSxVQUFVLEVBQUUsU0FBUyxNQUFNLFNBQVMsRUFBRSxRQUFRLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDdkYsVUFBTUEsS0FBSSxFQUFFLE9BQU8sR0FBRyxPQUFPLElBQUksWUFBWUEsTUFBSyxFQUFFLE9BQU8sRUFBRTtBQUM3RCxhQUFTLElBQUksR0FBRyxJQUFJLEVBQUUsTUFBTSxLQUFLO0FBQy9CLFVBQUksTUFBTTtBQUNWLGVBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxNQUFNLEtBQUs7QUFDL0IsZUFBTyxZQUFZLEVBQUUsTUFBTSxJQUFJLEVBQUUsT0FBTyxDQUFDLEtBQUssR0FBRyxHQUFHLE1BQU0sSUFBSTtBQUM5RCxjQUFNLElBQUksS0FBS0EsS0FBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUlBLEtBQUksSUFBSSxDQUFDLElBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFDQSxZQUFRLEVBQUUsT0FBTyxFQUFFLE9BQU8sTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE1BQU0sS0FBSztBQUMzRCxnQkFBWSxJQUFJLEdBQUcsS0FBSztBQUFBLEVBQzFCO0FBQ0EsUUFBTSxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUcsS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksQ0FBQztBQUM1RixRQUFNLEtBQUssS0FBSyxJQUFJLEVBQUUsTUFBTSxLQUFLLEtBQUssUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLEtBQUssS0FBSyxJQUFJLEVBQUUsTUFBTSxLQUFLLEtBQUssU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLElBQUksRUFBRSxPQUFPLEdBQUcsSUFBSSxNQUFNO0FBQ3JJLFNBQU8sRUFBRSxLQUFLLElBQUksRUFBRSxJQUFLLEVBQUUsS0FBSyxJQUFJLEVBQUUsSUFBSyxFQUFFLEtBQUssSUFBSSxFQUFFLElBQUssRUFBRSxLQUFLLElBQUksRUFBRSxNQUFPO0FBQ25GO0FBQ0EsTUFBTSxhQUFhO0FBQ25CLE1BQU0sUUFBUSxLQUFLLEtBQUs7QUFDeEIsTUFBTSxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQzVFLGdCQUFTLGtCQUFrQixNQUFjLElBQVk7QUFDMUQsV0FBUyxLQUFLLE9BQU8sS0FBSyxPQUFPLElBQUksS0FBSyxNQUFNLElBQUksS0FBSyxPQUFPLElBQUksS0FBSyxNQUFNLEtBQUs7QUFDdEY7QUFDQSxTQUFTLFFBQVEsTUFBd0IsTUFBZ0I7QUFDdkQsUUFBTSxJQUFJLE9BQU8sS0FBSyxPQUFPLEdBQUcsSUFBSSxPQUFPLEtBQUssT0FBTztBQUN2RCxTQUFPLEtBQUssSUFBSSxRQUFNLEVBQUUsR0FBRyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLEdBQUcsR0FBRyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRTtBQUN6RjtBQUVBLFNBQVMsYUFBYSxLQUFhLFNBQTJCO0FBQzVELE1BQUksT0FBTyxVQUFVLFFBQVEsV0FBVyxNQUFNLFVBQVUsU0FBUztBQUNqRSxhQUFXLFNBQVMsU0FBUztBQUMzQixXQUFPLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUFHLFlBQVEsS0FBSyxJQUFJLE9BQU8sTUFBTSxDQUFDO0FBQy9ELFVBQU0sS0FBSyxJQUFJLEtBQUssTUFBTSxDQUFDO0FBQUcsYUFBUyxLQUFLLElBQUksUUFBUSxNQUFNLENBQUM7QUFBQSxFQUNqRTtBQUNBLE1BQUksT0FBTyxTQUFTLE1BQU0sU0FBUyxRQUFRLElBQUksUUFBUSxRQUFRLFNBQVMsSUFBSSxTQUFTO0FBQ25GLFdBQU87QUFDVCxRQUFNLFVBQVUsSUFBSTtBQUNwQixNQUFJLENBQUM7QUFDSCxXQUFPO0FBQ1QsTUFBSSxhQUFhLEtBQUssTUFBTSxLQUFLLE9BQU8sTUFBTTtBQUM1QyxXQUFPO0FBQ1QsUUFBTSxPQUFPLFFBQVE7QUFDckIsTUFBSTtBQUNKLFdBQVMsTUFBTSxLQUFLLE1BQU0sTUFBTSxJQUFJLEdBQUcsT0FBTyxLQUFLLE9BQU8sU0FBUyxRQUFRLElBQUksR0FBRztBQUNoRixhQUFTLE1BQU0sS0FBSyxNQUFNLE9BQU8sSUFBSSxHQUFHLE9BQU8sS0FBSyxPQUFPLFFBQVEsUUFBUSxJQUFJLEdBQUcsT0FBTztBQUN2RixZQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsUUFBUSxPQUFPLFFBQVEsT0FBTyxTQUFZLFFBQVEsTUFBTSxNQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ2xJLFVBQUksQ0FBQyxZQUFZLFFBQVEsR0FBRyxHQUFHLE9BQU8sbUJBQW1CLFNBQVMsY0FBYyxPQUFPLEdBQUcsTUFBTSxNQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3BILGVBQU87QUFBQSxJQUNYO0FBQ0YsU0FBTztBQUNUO0FBQ08sZ0JBQVMsU0FBUyxLQUFhLE1BQVksT0FBaUIsRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxTQUFTLEtBQUssU0FBUyxXQUFXLEVBQUUsR0FBRztBQUNoSSxRQUFNLFVBQVUsWUFBWSxJQUFJO0FBQ2hDLFNBQU8sUUFBUSxXQUFXLGFBQWEsS0FBSyxRQUFRLFFBQVEsTUFBTSxJQUFJLENBQUMsQ0FBQztBQUMxRTtBQUVPLGdCQUFTLGlCQUFpQixLQUFhLE1BQVksTUFBZ0IsSUFBYztBQUN0RixRQUFNLE9BQU8sWUFBWSxJQUFJLEVBQUc7QUFDaEMsUUFBTSxPQUFPLGtCQUFrQixLQUFLLFNBQVMsR0FBRyxPQUFPO0FBQ3ZELFFBQU0sWUFBVSxjQUFjLE1BQUssRUFBRTtBQUNyQyxRQUFNLGFBQWEsY0FBYyxJQUFJO0FBQ3JDLFFBQU0sUUFBUSxHQUFHLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBRSxHQUFHLE1BQU0sR0FBRSxLQUFLLElBQUUsR0FBRyxNQUFNLENBQUMsSUFBSSxZQUFZLElBQUUsS0FBSyxJQUFJLFNBQVMsSUFBSTtBQUMvRyxRQUFNLFNBQVMsYUFBYTtBQUk1QixRQUFNLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxHQUFFLENBQUMsRUFBRSxNQUFNLGNBQVk7QUFDcEQsVUFBTSxLQUFLLFdBQVcsTUFBSyxJQUFHLFFBQVEsR0FBRyxXQUFXLFdBQVcsS0FBSztBQUNwRSxXQUFPLEtBQUssTUFBTSxHQUFHLElBQUUsU0FBUyxHQUFFLEdBQUcsSUFBRSxTQUFTLENBQUMsSUFBRTtBQUFBLEVBQ3JELENBQUM7QUFDRCxRQUFNLGlCQUFpQixXQUFXLGFBQWEsUUFBTSxPQUFLLE9BQUssS0FBSyxRQUFRLE9BQU8sS0FBSztBQUN4RixNQUFJLGFBQWEsS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLGdCQUFnQixLQUFLLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLGdCQUFnQixLQUFLLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLGdCQUFnQixLQUFLLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLGNBQWM7QUFDdEwsV0FBTztBQUNULE1BQUcsU0FBUyxDQUFDLFNBQVMsS0FBSSxNQUFLLElBQUksS0FBSyxDQUFDLFNBQVMsS0FBSSxNQUFLLEVBQUUsR0FBRyxRQUFPO0FBR3ZFLFFBQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssVUFBVSxJQUFJLE1BQUssQ0FBQyxDQUFDO0FBR3BGLFFBQU0sUUFBUSxPQUFPLFVBQVUsT0FBTyxVQUFVLElBQUksSUFBSSxPQUFPO0FBQy9ELFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0FBQzlCLFVBQU0sSUFBSSxXQUFXLE1BQUssSUFBRyxJQUFFLEtBQUs7QUFDcEMsVUFBTSxJQUFJLFdBQVcsTUFBSyxLQUFJLElBQUUsS0FBRyxLQUFLO0FBQ3hDLFVBQU0sV0FBVyxXQUFXLENBQUMsR0FBRyxRQUFRLE1BQU0sQ0FBQyxHQUFHLEdBQUcsUUFBUSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3RFLFFBQUksQ0FBQyxhQUFhLEtBQUssUUFBUSxhQUFhLFVBQVUsS0FBSyxJQUFJLFFBQVE7QUFDckUsYUFBTztBQUFBLEVBQ1g7QUFDQSxTQUFPO0FBQ1Q7QUFFTyxnQkFBUyxTQUFTLEtBQWEsTUFBWSxPQUFxQjtBQUNyRSxRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxTQUFTLEtBQUssU0FBUyxXQUFXLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxPQUFPLFNBQVMsS0FBSyxRQUFRO0FBQ25ILE1BQUksaUJBQWlCLEtBQUssTUFBTSxNQUFNLEVBQUU7QUFDdEMsV0FBTztBQUNULE1BQUksTUFBTSxHQUFHLE9BQU87QUFDcEIsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsVUFBTSxPQUFPLE1BQU0sUUFBUTtBQUMzQixVQUFNLEtBQUssRUFBRSxHQUFHLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssS0FBSyxLQUFLLFNBQVMsS0FBSyxRQUFRO0FBQ3pHLFFBQUksaUJBQWlCLEtBQUssTUFBTSxNQUFNLEVBQUU7QUFDdEMsWUFBTTtBQUFBO0FBRU4sYUFBTztBQUFBLEVBQ1g7QUFDQSxTQUFPLEVBQUUsR0FBRyxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEtBQUssSUFBSTtBQUNoRjtBQUVPLGdCQUFTLGdCQUFnQixLQUFhLE1BQVksT0FBYyxZQUFtQixNQUFNLFVBQWlDLE1BQUksTUFBNEI7QUFDL0osUUFBTSxZQUFZLEtBQUssU0FBUyxXQUFXO0FBQzNDLFFBQU0sV0FBVyxXQUFXLEtBQUssVUFBVSxHQUFHLFVBQVUsR0FBRyxLQUFLLElBQUksWUFBWSxhQUFhLEtBQUssVUFBVSxHQUFHLFVBQVUsR0FBRyxLQUFLO0FBQ2pJLFFBQU0sV0FBVyxDQUFDLFdBQVcsR0FBRyxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsR0FBRyxDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssQ0FBQztBQUN2RixNQUFJLENBQUMsSUFBSSxTQUFTO0FBQ2hCLFVBQU0sT0FBTyxRQUFRLFlBQVksSUFBSSxFQUFHLE1BQU0sRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLFNBQVMsVUFBVSxDQUFDO0FBQ2hGLFVBQU0sSUFBSSxLQUFLLElBQUksQ0FBQyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksT0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUssSUFBSSxJQUFJLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLE9BQUssRUFBRSxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUNuSCxVQUFNLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLE9BQUssRUFBRSxDQUFDLENBQUMsR0FBRyxLQUFLLElBQUksSUFBSSxTQUFTLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxPQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDcEgsUUFBRyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsR0FBRyxTQUFTLFVBQVUsQ0FBQyxLQUFLLFFBQVEsRUFBQyxHQUFFLEdBQUUsU0FBUSxVQUFTLENBQUMsRUFBRSxRQUFNLEVBQUMsR0FBRSxHQUFFLFNBQVEsVUFBUztBQUNySCxhQUFRLFdBQVMsSUFBRyxZQUFVLFlBQVksSUFBSSxFQUFHLFNBQU8sR0FBRSxZQUFVLEdBQUcsVUFBUSxJQUFFLEdBQUUsSUFBRSxJQUFHLEtBQUk7QUFDMUYsWUFBTSxRQUFNLElBQUUsS0FBSyxLQUFHLEdBQUUsS0FBRyxFQUFDLEdBQUUsSUFBRSxXQUFTLE9BQU8sS0FBSyxHQUFFLEdBQUUsSUFBRSxXQUFTLE9BQU8sS0FBSyxHQUFFLFNBQVEsVUFBUztBQUNuRyxVQUFHLFNBQVMsS0FBSSxNQUFLLEVBQUUsS0FBSyxRQUFRLEVBQUUsRUFBRSxRQUFPO0FBQUEsSUFDakQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLGFBQVcsV0FBVztBQUNwQixRQUFJLFNBQVMsS0FBSyxNQUFNLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQyxLQUFLLFFBQVEsRUFBQyxHQUFHLE9BQU0sUUFBTyxDQUFDLEtBQUssV0FBVyxLQUFLLFVBQVUsT0FBTyxLQUFLO0FBQ3JILGFBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUTtBQUMvQixRQUFNLElBQUksSUFBSSxTQUFTLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUUsT0FBTyxHQUFHLEtBQUssTUFBTSxNQUFNLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUUsT0FBTyxHQUFHLEtBQUssTUFBTSxNQUFNLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNsSyxXQUFTLE9BQU8sR0FBRyxRQUFRLEtBQUssSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQUcsUUFBUTtBQUMzRCxRQUFJLE1BQTRCLFFBQVE7QUFDeEMsYUFBUyxJQUFJLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxHQUFHLEtBQUssS0FBSyxJQUFJLEVBQUUsT0FBTyxHQUFHLE1BQU0sSUFBSSxHQUFHO0FBQzNFLGVBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxNQUFNLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxFQUFFLE9BQU8sR0FBRyxNQUFNLElBQUksR0FBRyxLQUFLO0FBQ2hGLFlBQUksUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxNQUFNO0FBQzdEO0FBQ0YsY0FBTSxLQUFLLEVBQUUsSUFBSSxJQUFJLE9BQU0sRUFBRSxNQUFNLElBQUksSUFBSSxPQUFNLEVBQUUsS0FBSztBQUN4RCxZQUFJLENBQUMsWUFBWSxFQUFFLE1BQU0sSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLLEdBQUcsR0FBRyxPQUFPLENBQUMsV0FBVyxLQUFLLFVBQVUsSUFBSSxLQUFLO0FBQzNGO0FBQ0YsbUJBQVcsV0FBVyxVQUFVO0FBQzlCLGdCQUFNLFFBQVEsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxrQkFBa0IsV0FBVyxPQUFPLENBQUMsSUFBSTtBQUM3RyxjQUFJLFFBQVEsU0FBUyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsSUFBSSxRQUFRLENBQUMsS0FBSyxRQUFRLEVBQUMsR0FBRyxJQUFHLFFBQU8sQ0FBQyxHQUFHO0FBQ3hGLG1CQUFPLEVBQUUsR0FBRyxJQUFJLFFBQVE7QUFDeEIsb0JBQVE7QUFBQSxVQUNWO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDRixRQUFJO0FBQ0YsYUFBTztBQUFBLEVBQ1g7QUFDQSxTQUFPO0FBQ1Q7QUFhQSxNQUFNLFFBQVEsb0JBQUksUUFBc0M7QUFHeEQsU0FBUyxzQkFBc0IsTUFBYztBQUMzQyxTQUFPO0FBQUEsSUFBRSxPQUFPLElBQUksYUFBYSxJQUFJO0FBQUEsSUFBRyxTQUFTLElBQUksV0FBVyxJQUFJO0FBQUEsSUFBRyxRQUFRLElBQUksWUFBWSxJQUFJO0FBQUEsSUFBRyxhQUFhLElBQUksV0FBVyxJQUFJO0FBQUEsSUFDcEksZ0JBQWUsSUFBSSxhQUFhLE9BQUssVUFBVTtBQUFBLElBQUUsWUFBVyxJQUFJLFlBQVksT0FBSyxVQUFVO0FBQUEsSUFBRSxZQUFZO0FBQUEsRUFBRTtBQUMvRztBQUNBLElBQUksU0FBUyxzQkFBc0IsQ0FBQztBQUNwQyxTQUFTLGdCQUFnQixNQUFjLFNBQVMsT0FBTztBQUdyRCxNQUFJLFFBQVE7QUFBRSxVQUFNLFlBQVksc0JBQXNCLElBQUk7QUFBRyxjQUFVLGFBQWE7QUFBRyxXQUFPO0FBQUEsRUFBVztBQUN6RyxNQUFJLE9BQU8sTUFBTSxTQUFTO0FBQ3hCLGFBQVMsc0JBQXNCLElBQUk7QUFDckMsTUFBSSxFQUFFLE9BQU8sZUFBZSxZQUFZO0FBQ3RDLFdBQU8sT0FBTyxLQUFLLENBQUM7QUFDcEIsV0FBTyxZQUFZLEtBQUssQ0FBQztBQUN6QixXQUFPLFdBQVcsS0FBSyxDQUFDO0FBQ3hCLFdBQU8sYUFBYTtBQUFBLEVBQ3RCO0FBQ0EsU0FBTztBQUNUO0FBQ0EsTUFBTSxnQkFBZ0Isb0JBQUksSUFBK0I7QUFDekQsU0FBUyxTQUFTLE1BQVUsTUFBK0I7QUFDekQsUUFBTSxVQUFRLFlBQVksSUFBSSxHQUFHLE1BQUksR0FBRyxLQUFLLElBQUksSUFBSSxRQUFRLE1BQU0sSUFBSSxRQUFRLElBQUksSUFBSSxJQUFJO0FBQzNGLFFBQU0sU0FBTyxjQUFjLElBQUksR0FBRztBQUFFLE1BQUcsT0FBTyxRQUFPO0FBQ3JELFFBQU0sV0FBUyxTQUFPLEtBQUssZ0JBQWdCLFNBQU8sS0FBSyxrQkFBa0I7QUFDekUsUUFBTSxRQUFNLFlBQVksVUFBVSxJQUFJLE1BQUkscUJBQXFCLFNBQVMsS0FBSyxJQUFrQyxJQUMzRyxxQkFBcUIsUUFBUSxNQUFLLElBQUk7QUFHMUMsTUFBRyxjQUFjLFFBQU0sR0FBRyxlQUFjLE9BQU8sY0FBYyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQU07QUFDakYsZ0JBQWMsSUFBSSxLQUFJLEtBQUs7QUFBRSxTQUFPO0FBQ3RDO0FBQ0EsU0FBUyxRQUFRLEtBQWEsTUFBWTtBQUN4QyxRQUFNLElBQUksSUFBSSxTQUFVLE1BQU0sR0FBRyxLQUFLLElBQUksSUFBSSxZQUFZLElBQUksRUFBRyxNQUFNLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJO0FBQ2hJLE1BQUksUUFBUSxNQUFNLElBQUksQ0FBQztBQUN2QixNQUFJLENBQUMsT0FBTztBQUNWLFlBQVEsb0JBQUksSUFBSTtBQUNoQixVQUFNLElBQUksR0FBRyxLQUFLO0FBQUEsRUFDcEI7QUFDQSxNQUFJLE9BQU8sTUFBTSxJQUFJLEdBQUc7QUFDeEIsTUFBSSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUUsT0FBTztBQUduQyxVQUFNLE9BQU8sRUFBRSxNQUFNLE9BQU8sS0FBSyxLQUFLLElBQUksUUFBUSxJQUFJLEdBQUcsT0FBTyxLQUFLLEtBQUssSUFBSSxTQUFTLElBQUk7QUFDM0YsVUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixVQUFNLFFBQU0sU0FBUyxNQUFLLEVBQUUsSUFBSTtBQUNoQyxVQUFNLFFBQVEsSUFBSSxXQUFXLE9BQU8sSUFBSTtBQUN4QyxhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxNQUFLLEVBQUUsSUFBSSxNQUFNLElBQUUsT0FBSSxPQUFPLElBQUksUUFBUTtBQUNyRSxlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxNQUFLLEVBQUUsSUFBSSxNQUFNLElBQUUsT0FBSSxPQUFPLElBQUksT0FBTztBQUNwRSxjQUFNLElBQUUsT0FBSyxDQUFDLElBQUksWUFBWSxFQUFFLE1BQU0sSUFBRSxFQUFFLE9BQUssQ0FBQyxLQUFLLEdBQUcsR0FBRyxNQUFNLElBQUk7QUFDekUsV0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLE1BQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxNQUFNLElBQUksVUFBVSxJQUFJLEdBQUcsT0FBTyxJQUFJLFVBQVUsT0FBTyxDQUFDLEdBQUcsT0FBTyxJQUFJLFVBQVUsT0FBTyxDQUFDLEVBQUU7QUFDbkosUUFBSSxNQUFNLFFBQVE7QUFDaEIsWUFBTSxPQUFPLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFNO0FBQ3pDLFVBQU0sSUFBSSxLQUFLLElBQUk7QUFBQSxFQUNyQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxLQUFhLE1BQWUsSUFBWSxNQUFxQjtBQUM3RSxRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxHQUFHLE1BQU0sT0FBTyxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksTUFBTSxLQUFLO0FBQzFJLFFBQU0sQ0FBQyxNQUFNLEtBQUssT0FBTyxNQUFNLElBQUksS0FBSztBQUN4QyxNQUFJLElBQUksT0FBTyxTQUFTLElBQUksTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJLFFBQVEsUUFBUSxJQUFJLFNBQVMsSUFBSSxTQUFTO0FBQ25HLFdBQU87QUFHVCxNQUFJLGFBQWEsS0FBSyxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksT0FBTyxJQUFJLE1BQU07QUFDNUQsV0FBTztBQUNULFFBQU0sSUFBSSxJQUFJO0FBQ2QsV0FBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDN0MsVUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLENBQUMsR0FBSSxLQUFLLE1BQU0sS0FBSyxNQUFNLElBQUksQ0FBQztBQUM1RCxRQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxFQUFFLFFBQVEsQ0FBQyxZQUFZLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssR0FBRyxHQUFHO0FBQ3RHLGFBQU87QUFBQSxFQUNYO0FBQ0EsU0FBTztBQUNUO0FBQ0EsTUFBTSxTQUFTO0FBQUEsRUFDYixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDTCxNQUFNLElBQUksV0FBVyxJQUFJO0FBQUEsRUFDekIsUUFBUSxJQUFJLGFBQWEsSUFBSTtBQUFBLEVBQzdCLFNBQVMsSUFBSSxhQUFhLElBQUk7QUFBQSxFQUN0QyxRQUFRO0FBQ04sU0FBSyxTQUFTO0FBR2QsUUFBSSxLQUFLLElBQUksU0FBUyxPQUFPO0FBQzNCLFdBQUssTUFBTSxJQUFJLFdBQVcsS0FBSztBQUMvQixXQUFLLFFBQVEsSUFBSSxhQUFhLEtBQUs7QUFDbkMsV0FBSyxTQUFTLElBQUksYUFBYSxLQUFLO0FBQUEsSUFDdEM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsT0FBK0M7QUFDN0MsV0FBTyxNQUFNLEtBQUssRUFBQyxRQUFPLEtBQUssT0FBTSxHQUFFLENBQUMsR0FBRSxPQUFLLEVBQUMsSUFBRyxLQUFLLElBQUksQ0FBQyxHQUFHLE1BQUssS0FBSyxNQUFNLENBQUMsR0FBRyxPQUFNLEtBQUssT0FBTyxDQUFDLEVBQUUsRUFBRTtBQUFBLEVBQzdHO0FBQUEsRUFDQSxRQUFRLE9BQXVEO0FBQzdELFNBQUssTUFBTTtBQUNYLFVBQU0sV0FBUyxLQUFLLElBQUksTUFBSyxLQUFHLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUUsTUFBTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzlFLFFBQUcsS0FBSyxJQUFJLFNBQU8sVUFBUztBQUFDLFdBQUssTUFBSSxJQUFJLFdBQVcsUUFBUTtBQUFFLFdBQUssUUFBTSxJQUFJLGFBQWEsUUFBUTtBQUFFLFdBQUssU0FBTyxJQUFJLGFBQWEsUUFBUTtBQUFBLElBQUU7QUFHNUksU0FBSyxTQUFPLE1BQU07QUFDbEIsYUFBUSxJQUFFLEdBQUUsSUFBRSxNQUFNLFFBQU8sS0FBSTtBQUFDLFlBQU0sT0FBSyxNQUFNLENBQUM7QUFBRyxXQUFLLElBQUksQ0FBQyxJQUFFLEtBQUs7QUFBRyxXQUFLLE1BQU0sQ0FBQyxJQUFFLEtBQUs7QUFBSyxXQUFLLE9BQU8sQ0FBQyxJQUFFLEtBQUs7QUFBQSxJQUFNO0FBQzNILFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxLQUFLLElBQVksTUFBYyxPQUFlO0FBQzVDLFFBQUksS0FBSyxXQUFXLEtBQUssSUFBSSxRQUFRO0FBQ25DLFlBQU0sTUFBTSxJQUFJLFdBQVcsS0FBSyxTQUFTLENBQUMsR0FBRyxRQUFRLElBQUksYUFBYSxLQUFLLFNBQVMsQ0FBQyxHQUFHLFNBQVMsSUFBSSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2pJLFVBQUksSUFBSSxLQUFLLEdBQUc7QUFBRyxZQUFNLElBQUksS0FBSyxLQUFLO0FBQUcsYUFBTyxJQUFJLEtBQUssTUFBTTtBQUNoRSxXQUFLLE1BQU07QUFBSyxXQUFLLFFBQVE7QUFBTyxXQUFLLFNBQVM7QUFBQSxJQUNwRDtBQUNBLFFBQUksSUFBSSxLQUFLO0FBQ2IsV0FBTyxHQUFHO0FBQ1IsWUFBTSxTQUFVLElBQUksTUFBTztBQUMzQixVQUFJLENBQUMsS0FBSyxLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sTUFBTSxHQUFJLEtBQUssSUFBSSxNQUFNLENBQUU7QUFDL0Q7QUFDRixXQUFLLEtBQUssUUFBUSxDQUFDO0FBQ25CLFVBQUk7QUFBQSxJQUNOO0FBQ0EsU0FBSyxJQUFJLENBQUMsSUFBSTtBQUFJLFNBQUssTUFBTSxDQUFDLElBQUk7QUFBTSxTQUFLLE9BQU8sQ0FBQyxJQUFJO0FBQUEsRUFDM0Q7QUFBQSxFQUNRLEtBQUssTUFBYyxJQUFZO0FBQUUsU0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLElBQUksSUFBSTtBQUFJLFNBQUssTUFBTSxFQUFFLElBQUksS0FBSyxNQUFNLElBQUk7QUFBSSxTQUFLLE9BQU8sRUFBRSxJQUFJLEtBQUssT0FBTyxJQUFJO0FBQUEsRUFBSTtBQUFBLEVBQzNJLEtBQUssUUFBZ0IsS0FBYSxRQUFnQixLQUFhO0FBQUUsV0FBTyxTQUFTLFVBQVcsV0FBVyxVQUFVLE1BQU07QUFBQSxFQUFNO0FBQUEsRUFDckksTUFBTTtBQUNKLFVBQU0sU0FBUyxLQUFLLElBQUksQ0FBQyxHQUFJLE9BQU8sRUFBRSxLQUFLO0FBQzNDLFNBQUssYUFBYSxLQUFLLE1BQU0sQ0FBQztBQUM5QixVQUFNLEtBQUssS0FBSyxJQUFJLElBQUksR0FBSSxPQUFPLEtBQUssTUFBTSxJQUFJLEdBQUksUUFBUSxLQUFLLE9BQU8sSUFBSTtBQUM5RSxRQUFJLE1BQU07QUFDUixVQUFJLElBQUk7QUFDUixhQUFPLElBQUksSUFBSSxJQUFJLE1BQU07QUFDdkIsWUFBSSxRQUFRLElBQUksSUFBSTtBQUNwQixjQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQ3BDLGlCQUFTLE9BQU8sUUFBUSxHQUFHLE9BQU8sS0FBSztBQUNyQyxjQUFJLEtBQUssS0FBSyxLQUFLLE9BQU8sSUFBSSxHQUFJLEtBQUssSUFBSSxJQUFJLEdBQUksS0FBSyxPQUFPLEtBQUssR0FBSSxLQUFLLElBQUksS0FBSyxDQUFFO0FBQ3RGLG9CQUFRO0FBQ1osWUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sS0FBSyxHQUFJLEtBQUssSUFBSSxLQUFLLEdBQUksT0FBTyxFQUFFO0FBQzdEO0FBQ0YsYUFBSyxLQUFLLE9BQU8sQ0FBQztBQUNsQixZQUFJO0FBQUEsTUFDTjtBQUNBLFdBQUssSUFBSSxDQUFDLElBQUk7QUFBSSxXQUFLLE1BQU0sQ0FBQyxJQUFJO0FBQU0sV0FBSyxPQUFPLENBQUMsSUFBSTtBQUFBLElBQzNEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLE1BQU0sZ0JBQWdCLElBQUksU0FBUyxHQUFHLG1CQUFtQixJQUFJLFNBQVM7QUFDdEUsTUFBTSxlQUFlLE1BQU07QUFFM0IsTUFBTSxlQUFlLG9CQUFJLFFBQTJDO0FBTXBFLFNBQVMsaUJBQWlCLEtBQWEsTUFBZSxPQUFZLFFBQWUsZ0JBQTZEO0FBQzVJLFFBQU0sVUFBVSxJQUFJLFNBQVUsT0FBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLE9BQU8sS0FBSyxHQUFHLFNBQVMsS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLE9BQU8sS0FBSztBQUM5SSxRQUFNLFFBQU0sS0FBSyxNQUFNLE1BQU0sS0FBRyxLQUFLLE9BQUssS0FBSyxHQUFFLFFBQU0sS0FBSyxNQUFNLE1BQU0sS0FBRyxLQUFLLE9BQUssS0FBSztBQUMxRixRQUFNLE1BQU0sR0FBRyxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksZUFBZSxLQUFLLEdBQUcsQ0FBQztBQUMvSSxNQUFJLFFBQVEsYUFBYSxJQUFJLE9BQU87QUFDcEMsTUFBSSxDQUFDLE9BQU87QUFBRSxZQUFRLG9CQUFJLElBQUk7QUFBRyxpQkFBYSxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQUc7QUFDbkUsUUFBTSxTQUFTLE1BQU0sSUFBSSxHQUFHO0FBQzVCLE1BQUksUUFBUSxVQUFVLFFBQVEsTUFBTyxRQUFPLE9BQU87QUFDbkQsUUFBTSxPQUFPLENBQUMsR0FBVyxNQUFjLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFFBQVEsSUFBSSxLQUFLLFFBQVEsS0FBSyxNQUFNLElBQUUsS0FBSyxPQUFLLENBQUMsTUFBTTtBQUczSCxRQUFNLFdBQVcsU0FBUyxPQUFNLE1BQU0sV0FBVyxTQUFTLE9BQU07QUFDaEUsTUFBSSxPQUFPLElBQUksVUFBVTtBQUN6QixXQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsU0FBUyxPQUFPLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sU0FBUyxLQUFLLE9BQU8sQ0FBQyxHQUFHO0FBQzdGLGFBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxTQUFTLE9BQU8sQ0FBQyxHQUFHLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxTQUFTLEtBQUssT0FBTyxDQUFDLEdBQUcsS0FBSztBQUNsRyxVQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRztBQUNqQixZQUFNLEtBQUssSUFBSSxLQUFLLE9BQU8sR0FBRyxPQUFPLElBQUksTUFBSyxZQUFZLEtBQUssSUFBSSxNQUFLLFlBQVk7QUFDcEYsVUFBSSxNQUFNLFNBQVM7QUFBRSxlQUFPO0FBQUksa0JBQVU7QUFBQSxNQUFLO0FBQUEsSUFDakQ7QUFDRixNQUFHLE9BQUssRUFBRSxRQUFPO0FBQ2pCLFFBQU0sU0FBTztBQUFBLElBQUMsTUFBSyxLQUFLLElBQUksSUFBRyxLQUFLLElBQUksT0FBTSxNQUFNLElBQUUsS0FBRyxJQUFJO0FBQUEsSUFBRSxLQUFJLEtBQUssSUFBSSxJQUFHLEtBQUssSUFBSSxPQUFNLE1BQU0sSUFBRSxLQUFHLElBQUk7QUFBQSxJQUMzRyxPQUFNLEtBQUssSUFBSSxLQUFLLE9BQU0sS0FBSyxJQUFJLE9BQU0sTUFBTSxJQUFFLEtBQUcsSUFBSTtBQUFBLElBQUUsUUFBTyxLQUFLLElBQUksS0FBSyxPQUFNLEtBQUssSUFBSSxPQUFNLE1BQU0sSUFBRSxLQUFHLElBQUk7QUFBQSxFQUFDO0FBQ3RILFFBQU0sUUFBTTtBQUFBLElBQWtCLEtBQUs7QUFBQSxJQUFNLEtBQUs7QUFBQSxJQUFLLEtBQUs7QUFBQSxJQUFLLEtBQUs7QUFBQSxJQUFLO0FBQUEsSUFDckUsRUFBQyxHQUFFLE9BQUssS0FBSyxNQUFLLEdBQUUsS0FBSyxNQUFNLE9BQUssS0FBSyxJQUFJLEVBQUM7QUFBQSxJQUFFO0FBQUEsSUFBZTtBQUFBLEVBQWdCO0FBR2pGLE1BQUksTUFBTSxRQUFRLEtBQUssQ0FBQyxNQUFNLElBQUksR0FBRyxFQUFHLE9BQU0sT0FBTyxNQUFNLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBTTtBQUMvRSxRQUFNLElBQUksS0FBSyxFQUFFLE9BQU8sUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUM5QyxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFVBQVUsS0FBVyxNQUFVLE1BQWMsUUFBNEI7QUFDaEYsUUFBTSxTQUFPLGlCQUFpQixJQUFJO0FBQUUsTUFBSSxPQUFLLEdBQUUsV0FBUztBQUN4RCxhQUFVLFNBQVMsUUFBTztBQUN4QixVQUFNLE1BQUksS0FBSyxJQUFJLGtCQUFrQixTQUFTLFNBQVEsTUFBTSxPQUFPLENBQUM7QUFDcEUsVUFBTSxLQUFHLE1BQU0sSUFBRSxTQUFTLEdBQUUsS0FBRyxNQUFNLElBQUUsU0FBUztBQUNoRCxVQUFNLGNBQVksa0JBQWtCLE1BQUssS0FBSSxNQUFNLFNBQVEsRUFBQyxlQUFjLEtBQUksQ0FBQztBQUMvRSxVQUFNLFFBQU0sS0FBRyxPQUFPLE1BQU0sT0FBTyxJQUFFLEtBQUcsT0FBTyxNQUFNLE9BQU8sSUFBRSxRQUFNLEtBQUssSUFBSSxPQUFPLGNBQWEsWUFBWSxjQUFjLElBQUUsS0FBSyxJQUFJLFlBQVksYUFBWSxZQUFZLGNBQWM7QUFDeEwsWUFBTSxNQUFJLEtBQUssSUFBSSxNQUFLLE9BQU8sUUFBUSxJQUFFLEtBQUssTUFBTSxJQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksTUFBSyxLQUFLO0FBQzlFLGVBQVM7QUFBQSxFQUNYO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLE1BQVUsTUFBYyxNQUE2QztBQUMzRixRQUFNLE1BQUksS0FBSyxNQUFNLEtBQUssSUFBRSxLQUFLLEdBQUUsS0FBSyxJQUFFLEtBQUssQ0FBQztBQUNoRCxNQUFHLE1BQUksS0FBSyxRQUFPLENBQUMsS0FBSyxZQUFVLFVBQWEsS0FBSyxJQUFJLGtCQUFrQixLQUFLLFNBQVEsS0FBSyxPQUFPLENBQUMsSUFBRSxPQUFLLENBQUMsSUFBRSxDQUFDLEVBQUMsR0FBRyxNQUFLLFNBQVEsS0FBSyxRQUFPLENBQUMsQ0FBQztBQUMvSSxRQUFNLFlBQVUsS0FBSyxNQUFNLEtBQUssSUFBRSxLQUFLLEdBQUUsS0FBSyxJQUFFLEtBQUssQ0FBQztBQUV0RCxRQUFNLFNBQU8sWUFBWSxJQUFJLEVBQUc7QUFJaEMsUUFBTSxXQUFTLFFBQU0sS0FBSyxZQUFVLFNBQVUsU0FBTyxTQUFPLEtBQUcsQ0FBQyxXQUFVLFlBQVUsS0FBSyxFQUFFLElBQUUsQ0FBQyxTQUFTO0FBQ3ZHLFNBQU8sU0FBUyxJQUFJLGFBQVM7QUFDM0IsVUFBTSxTQUFPLEVBQUMsR0FBRSxLQUFLLEdBQUUsR0FBRSxLQUFLLEdBQUUsUUFBTyxHQUFFLE1BQUksRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssR0FBRSxRQUFPO0FBQ3ZFLFVBQU0sU0FBTyxLQUFLLElBQUksa0JBQWtCLEtBQUssU0FBUSxPQUFPLENBQUMsSUFBRSxPQUFLLENBQUMsR0FBRyxJQUFFLENBQUMsUUFBTyxHQUFHO0FBQ3JGLFFBQUcsS0FBSyxZQUFVLFVBQWEsS0FBSyxJQUFJLGtCQUFrQixTQUFRLEtBQUssT0FBTyxDQUFDLElBQUUsS0FBSyxRQUFPLEtBQUssRUFBQyxHQUFHLEtBQUksU0FBUSxLQUFLLFFBQU8sQ0FBQztBQUMvSCxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0g7QUFDQSxTQUFTLGVBQWUsS0FBVyxNQUFVLE1BQWMsUUFBa0IsU0FBMEM7QUFDckgsU0FBTyxPQUFPLE1BQU0sQ0FBQyxPQUFNLE1BQUk7QUFDN0IsVUFBTSxXQUFTLE9BQU8sSUFBRSxDQUFDLEtBQUs7QUFDOUIsV0FBTyxpQkFBaUIsS0FBSSxNQUFLLFVBQVMsS0FBSyxLQUFLLFFBQVEsVUFBUyxLQUFLO0FBQUEsRUFDNUUsQ0FBQztBQUNIO0FBQ0EsU0FBUyxjQUFjLEtBQVcsTUFBVSxNQUFjLE1BQStCLFNBQStEO0FBQ3RKLFNBQU8sZUFBZSxNQUFLLE1BQUssSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFFLE1BQUksVUFBVSxLQUFJLE1BQUssTUFBSyxDQUFDLElBQUUsVUFBVSxLQUFJLE1BQUssTUFBSyxDQUFDLENBQUMsRUFDcEcsS0FBSyxZQUFRLGVBQWUsS0FBSSxNQUFLLE1BQUssUUFBTyxPQUFPLENBQUM7QUFDOUQ7QUFHTyxnQkFBUyxjQUFjLEtBQVcsTUFBVSxNQUFjLFNBQXlDLGtCQUErQztBQUN2SixRQUFNLFFBQU0sRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssR0FBRSxTQUFRLEtBQUssU0FBUyxXQUFXLEVBQUM7QUFDakUsUUFBTSxLQUFHLEtBQUssSUFBRSxNQUFNLEdBQUUsS0FBRyxLQUFLLElBQUUsTUFBTSxHQUFFLE1BQUksS0FBSyxNQUFNLElBQUcsRUFBRSxHQUFFLFNBQU8sWUFBWSxJQUFJLEVBQUc7QUFDMUYsUUFBTSxjQUFZLGtCQUFrQixNQUFLLEtBQUksS0FBSyxNQUFNLElBQUcsRUFBRSxHQUFFLEVBQUMsZUFBYyxLQUFJLENBQUM7QUFDbkYsTUFBRyxNQUFJLFVBQVUsWUFBWSxRQUFRLFlBQVksaUJBQWUsWUFBWSxhQUN2RSxDQUFDLFlBQVksUUFBUSxZQUFZLGVBQWEsWUFBWSxrQkFBa0IsWUFBWSxtQkFBaUIsRUFBRTtBQUNoSCxRQUFNLE9BQUssT0FBTyxLQUFJLElBQUksR0FBRSxTQUFPLENBQUMsS0FBSyxPQUFLLFlBQVksV0FBVSxLQUFLLE9BQUssWUFBWSxTQUFTO0FBQ25HLFFBQU0sYUFBVyxPQUFPLElBQUksY0FBVSxFQUFDLEdBQUUsT0FBTyxPQUFPLEdBQUUsR0FBRSxPQUFPLE9BQU8sRUFBQyxFQUFFO0FBQzVFLFFBQU0sUUFBTSxDQUFDLEdBQVEsTUFBVSxFQUFFLElBQUUsRUFBRSxJQUFFLEVBQUUsSUFBRSxFQUFFO0FBRzdDLFFBQU0sWUFBVSxvQkFBb0IsTUFBTTtBQUMxQyxRQUFNLFFBQU0sQ0FBQyxHQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRSxNQUFJLEtBQUssSUFBSSxrQkFBa0IsV0FBVSxPQUFPLENBQUMsQ0FBRSxDQUFDLElBQUUsS0FBSyxJQUFJLGtCQUFrQixXQUFVLE9BQU8sQ0FBQyxDQUFFLENBQUMsQ0FBQztBQUNqSSxRQUFNLFlBQVUsQ0FBQyxHQUFHO0FBQ3BCLFdBQVEsV0FBUyxNQUFJLEdBQUUsWUFBVSxRQUFPLFlBQVUsRUFBRSxXQUFVLEtBQUssUUFBUTtBQUMzRSxNQUFHLFVBQVUsR0FBRyxFQUFFLElBQUcsU0FBTyxLQUFLLFdBQVUsS0FBSyxNQUFNO0FBR3RELFFBQU0sVUFBUSxxQkFBbUIsU0FDN0IsVUFBVSxRQUFRLGNBQVUsTUFBTSxJQUFJLFdBQU8sRUFBQyxVQUFTLEtBQUksRUFBRSxDQUFDLElBQzlELE1BQU0sUUFBUSxVQUFNLFVBQVUsSUFBSSxlQUFXLEVBQUMsVUFBUyxLQUFJLEVBQUUsQ0FBQztBQUNsRSxNQUFHLGlCQUFpQixJQUFJLEVBQUUsWUFBVSxLQUFLO0FBQ3pDLGFBQVUsRUFBQyxVQUFTLEtBQUksS0FBSyxTQUFRO0FBQ25DLFVBQU0sTUFBSSxFQUFDLEdBQUUsTUFBTSxJQUFFLEtBQUcsV0FBUyxLQUFJLEdBQUUsTUFBTSxJQUFFLEtBQUcsV0FBUyxJQUFHO0FBQzlELFVBQU0sUUFBTSxJQUFFLE1BQUssSUFBRSxXQUFXLElBQUksR0FBRyxJQUFFLFdBQVcsS0FBSyxHQUFHLE1BQUksTUFBTSxHQUFFLENBQUM7QUFDekUsUUFBSSxNQUEwQixXQUFTO0FBQ3ZDLFVBQU0sZUFBYSxLQUFLLElBQUksa0JBQWtCLE1BQU0sU0FBUSxPQUFPLElBQUksQ0FBRSxDQUFDLElBQUU7QUFDNUUsZUFBVSxpQkFBaUIsZUFBYSxlQUFlLEtBQUksSUFBSSxJQUFFLENBQUMsaUJBQWlCLElBQUksQ0FBQyxFQUFFLFlBQVUsVUFBVSxZQUFZLElBQUksR0FBRTtBQUM5SCxZQUFNLGFBQVcsZ0JBQWdCLE1BQUssTUFBTSxHQUFFLGVBQWEsZ0JBQWdCLE1BQUssYUFBYTtBQUM3RixZQUFNLE9BQUssZUFBYSxhQUFhLE1BQUssT0FBTSxZQUFZLElBQUUsQ0FBQztBQUMvRCxZQUFNLFVBQVEsVUFBVSxLQUFLLEdBQUcsRUFBRSxLQUFLLE9BQU0sT0FBTyxJQUFJLEdBQUcsZUFBYyxZQUFZO0FBQ3JGLFlBQU0sU0FBTyxRQUFRLEdBQUcsRUFBRSxLQUFLLEtBQUssR0FBRyxFQUFFLEtBQUs7QUFDOUMsWUFBTSxRQUFNLEVBQUMsR0FBRSxJQUFJLElBQUUsT0FBTyxHQUFFLEdBQUUsSUFBSSxJQUFFLE9BQU8sRUFBQztBQUM5QyxZQUFNLFFBQU0sTUFBTSxPQUFNLENBQUMsSUFBRSxLQUFJLFNBQU8sTUFBTSxHQUFFLEtBQUssSUFBRTtBQUNyRCxZQUFNLE9BQUssa0JBQWtCLE9BQU8sSUFBSSxHQUFHLE9BQU8sS0FBSyxDQUFFO0FBR3pELFlBQU0sVUFBUSxTQUFPLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxJQUFFLENBQUM7QUFDOUMsVUFBRyxTQUFPLFVBQVEsS0FBSyxVQUFRLFVBQVEsRUFBRTtBQUN6QyxZQUFNLFFBQWUsRUFBQyxHQUFFLE9BQU8sSUFBRSxFQUFFLEtBQUcsUUFBTSxVQUFTLEdBQUUsT0FBTyxJQUFFLEVBQUUsS0FBRyxRQUFNLFVBQVMsU0FBUSxPQUFPLElBQUksR0FBRyxXQUFVLEdBQUUsV0FBVTtBQUNoSSxZQUFNLE9BQUssVUFBVSxPQUFNLE9BQU8sS0FBSyxHQUFHLFFBQU8sVUFBVTtBQUMzRCxZQUFNLFNBQWdCLEVBQUMsR0FBRyxLQUFJLFNBQVEsT0FBTyxLQUFLLEdBQUcsV0FBVSxFQUFDO0FBQ2hFLFlBQU0sU0FBTyxDQUFDLEdBQUcsTUFBSyxHQUFHLFNBQVEsT0FBTSxHQUFHLE1BQUssTUFBTSxFQUFFLElBQUksWUFBUSxFQUFDLEdBQUcsT0FBTSxNQUFLLEtBQUksRUFBRTtBQUN4RixZQUFNLE9BQUssV0FBVyxLQUFJLE1BQUssT0FBTSxNQUFNO0FBQzNDLFVBQUcsUUFBTSxZQUFZLENBQUMsb0JBQW9CLEtBQUksTUFBSyxPQUFNLFFBQU8sT0FBTyxFQUFFO0FBQ3pFLGFBQUs7QUFBTyxpQkFBUztBQUFBLElBQ3ZCO0FBQ0EsUUFBRyxLQUFLLFFBQU87QUFBQSxFQUNqQjtBQUNGO0FBSU8sZ0JBQVMsa0JBQWtCLEtBQVcsTUFBVSxNQUFjLFNBQXlDLGtCQUErQztBQUMzSixRQUFNLFFBQWUsRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssR0FBRSxTQUFRLEtBQUssU0FBUyxXQUFXLEVBQUM7QUFDMUUsUUFBTSxVQUFRLEtBQUssTUFBTSxLQUFLLElBQUUsTUFBTSxHQUFFLEtBQUssSUFBRSxNQUFNLENBQUMsR0FBRSxjQUFZLGtCQUFrQixNQUFLLEtBQUksU0FBUSxFQUFDLGVBQWMsS0FBSSxDQUFDO0FBQzNILE1BQUcsWUFBWSxRQUFRLFlBQVksaUJBQWUsWUFBWSxhQUFhLGlCQUFpQixJQUFJLEVBQUUsWUFBVSxRQUFRLFlBQVksbUJBQWlCLEVBQUU7QUFDbkosUUFBTSxPQUFLLE9BQU8sS0FBSSxJQUFJLEdBQUUsU0FBTyxDQUFDLEtBQUssT0FBSyxZQUFZLFdBQVUsS0FBSyxPQUFLLFlBQVksU0FBUztBQUNuRyxRQUFNLFNBQU8sT0FBTyxPQUFPLGFBQVM7QUFDbEMsVUFBTSxRQUFNLGtCQUFrQixNQUFLLEtBQUksU0FBUSxFQUFDLGVBQWMsS0FBSSxDQUFDLEVBQUU7QUFDckUsV0FBTyxRQUFNLE9BQU8sa0JBQWtCLFNBQVEsT0FBTyxDQUFDLElBQUUsS0FBSyxJQUFJLFlBQVksYUFBWSxZQUFZLGNBQWMsSUFBRTtBQUFBLEVBQ3ZILENBQUM7QUFDRCxRQUFNLFlBQVUsb0JBQW9CLE1BQU07QUFDMUMsU0FBTyxLQUFLLENBQUMsR0FBRSxNQUFJLEtBQUssSUFBSSxrQkFBa0IsV0FBVSxDQUFDLENBQUMsSUFBRSxLQUFLLElBQUksa0JBQWtCLFdBQVUsQ0FBQyxDQUFDLENBQUM7QUFDcEcsUUFBTSxTQUFPLFlBQVksSUFBSSxFQUFHLFNBQU87QUFDdkMsYUFBVSxXQUFXLFFBQU87QUFDMUIsUUFBSSxNQUEwQixXQUFTO0FBQ3ZDLGVBQVUsVUFBVSxlQUFlLEtBQUksSUFBSSxHQUFFO0FBQzNDLFlBQU0sYUFBVyxnQkFBZ0IsTUFBSyxNQUFNLEdBQUUsT0FBSyxLQUFLLElBQUksa0JBQWtCLE1BQU0sU0FBUSxPQUFPLENBQUMsSUFBRSxPQUFLLGFBQWEsTUFBSyxPQUFNLFVBQVUsSUFBRSxDQUFDO0FBQ2hKLFlBQU0sTUFBSSxVQUFVLEtBQUssR0FBRyxFQUFFLEtBQUssT0FBTSxTQUFRLFFBQU8sVUFBVSxHQUFFLFFBQU0sSUFBSSxHQUFHLEVBQUUsS0FBSyxLQUFLLEdBQUcsRUFBRSxLQUFLO0FBQ3ZHLFlBQU0sU0FBZ0IsRUFBQyxHQUFFLE1BQU0sSUFBRSxTQUFPLE9BQU8sT0FBTyxHQUFFLEdBQUUsTUFBTSxJQUFFLFNBQU8sT0FBTyxPQUFPLEdBQUUsU0FBUSxXQUFVLEVBQUM7QUFDNUcsWUFBTSxTQUFPLENBQUMsR0FBRyxNQUFLLEdBQUcsS0FBSSxNQUFNLEVBQUUsSUFBSSxZQUFRLEVBQUMsR0FBRyxPQUFNLE1BQUssS0FBSSxFQUFFLEdBQUUsT0FBSyxXQUFXLEtBQUksTUFBSyxPQUFNLE1BQU07QUFDN0csVUFBRyxRQUFNLFlBQVksQ0FBQyxvQkFBb0IsS0FBSSxNQUFLLE9BQU0sUUFBTyxPQUFPLEVBQUU7QUFDekUsYUFBSztBQUFPLGlCQUFTO0FBQUEsSUFDdkI7QUFDQSxRQUFHLEtBQUssUUFBTztBQUFBLEVBQ2pCO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsS0FBVyxNQUFVLE1BQVcsU0FBeUMsZ0JBQWMsT0FBNEI7QUFDekksUUFBTSxRQUFNLEVBQUMsR0FBRSxLQUFLLEdBQUUsR0FBRSxLQUFLLEdBQUUsU0FBUSxLQUFLLFNBQVMsV0FBVyxFQUFDLEdBQUUsU0FBTyxZQUFZLElBQUksRUFBRztBQUM3RixRQUFNLFVBQVEsS0FBSyxNQUFNLEtBQUssSUFBRSxNQUFNLEdBQUUsS0FBSyxJQUFFLE1BQU0sQ0FBQztBQUN0RCxRQUFNLGNBQVksQ0FBQyxrQkFBa0IsTUFBTSxTQUFRLE9BQU8sR0FBRSxrQkFBa0IsTUFBTSxTQUFRLFVBQVEsS0FBSyxFQUFFLENBQUM7QUFDNUcsYUFBVSxjQUFjLFlBQVksWUFBVSxTQUFTLENBQUMsU0FBTyxHQUFFLENBQUMsU0FBTyxDQUFDLEdBQUU7QUFDMUUsUUFBRyxLQUFLLElBQUksVUFBVSxJQUFFLEtBQUs7QUFDN0IsVUFBTSxRQUFNLEtBQUssSUFBSSxDQUFDLEtBQUssS0FBRyxHQUFFLEtBQUssSUFBSSxLQUFLLEtBQUcsR0FBRSxVQUFVLENBQUM7QUFDOUQsVUFBTSxRQUFNLEVBQUMsR0FBRSxNQUFNLElBQUUsUUFBTSxPQUFPLE1BQU0sT0FBTyxHQUFFLEdBQUUsTUFBTSxJQUFFLFFBQU0sT0FBTyxNQUFNLE9BQU8sRUFBQztBQUN4RixVQUFNLFVBQVEsTUFBTSxVQUFRLE9BQU0sTUFBSSxFQUFDLEdBQUUsTUFBTSxJQUFFLFFBQU0sT0FBTyxPQUFPLEdBQUUsR0FBRSxNQUFNLElBQUUsUUFBTSxPQUFPLE9BQU8sR0FBRSxTQUFRLE1BQUs7QUFDcEgsUUFBRyxpQkFBaUIsS0FBSSxNQUFLLE9BQU0sR0FBRyxLQUFLLFFBQVEsT0FBTSxHQUFHLEVBQUUsUUFBTSxDQUFDLEdBQUc7QUFBQSxFQUMxRTtBQUdBLE1BQUk7QUFDSixhQUFVLGFBQWEsQ0FBQyxHQUFFLEVBQUUsRUFBRSxVQUFRLFdBQVMsSUFBSSxRQUFTLE1BQUssWUFBVSxTQUFPLEdBQUUsWUFBVSxJQUFJLFFBQVMsTUFBSztBQUM5RyxVQUFNLE1BQUksRUFBQyxHQUFFLE1BQU0sSUFBRSxZQUFVLFdBQVMsT0FBTyxNQUFNLE9BQU8sR0FBRSxHQUFFLE1BQU0sSUFBRSxZQUFVLFdBQVMsT0FBTyxNQUFNLE9BQU8sR0FBRSxTQUFRLE1BQU0sUUFBTztBQUN0SSxRQUFHLENBQUMsaUJBQWlCLEtBQUksTUFBSyxPQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsT0FBTSxHQUFHLEVBQUU7QUFDaEUsUUFBRyxjQUFjLEtBQUksTUFBSyxLQUFJLE1BQUssT0FBTyxFQUFFLFFBQU0sQ0FBQyxHQUFHO0FBQ3RELFFBQUcsaUJBQWlCLENBQUMsUUFBTztBQUMxQixZQUFNLE9BQUssSUFBSSxRQUFTLE1BQUssTUFBSSxLQUFLLE1BQU0sSUFBSSxJQUFFLElBQUksR0FBRSxNQUFJLEtBQUssTUFBTSxJQUFJLElBQUUsSUFBSTtBQUNqRixlQUFRLElBQUUsTUFBSSxHQUFFLEtBQUcsTUFBSSxLQUFLLENBQUMsUUFBTyxJQUFJLFVBQVEsSUFBRSxNQUFJLEdBQUUsS0FBRyxNQUFJLEtBQUssQ0FBQyxRQUFPLElBQUksVUFBUSxJQUFFLEdBQUUsSUFBRSxZQUFXLEtBQUk7QUFDM0csY0FBTSxXQUFTLEVBQUMsSUFBRyxJQUFFLE9BQUksTUFBSyxJQUFHLElBQUUsT0FBSSxNQUFLLFNBQVEsSUFBRSxNQUFLO0FBQzNELFlBQUcsU0FBUyxLQUFJLE1BQUssUUFBUSxLQUFLLGNBQWMsS0FBSSxNQUFLLEtBQUksVUFBUyxPQUFPLEdBQUU7QUFBQyxtQkFBTztBQUFJO0FBQUEsUUFBTTtBQUFBLE1BQ25HO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFJQSxNQUFHLE9BQU8sUUFBTSxDQUFDLEVBQUMsR0FBRyxRQUFPLE9BQU0sS0FBSSxDQUFDO0FBQ3pDO0FBSUEsU0FBUyxvQkFBb0IsS0FBVyxNQUFVLE1BQWMsU0FBMEM7QUFDeEcsUUFBTSxTQUFPLFlBQVksSUFBSSxFQUFHO0FBQ2hDLFFBQU0sT0FBa0QsQ0FBQztBQUN6RCxhQUFVLFNBQVMsQ0FBQyxLQUFLLEtBQUcsR0FBRSxDQUFDLEtBQUssS0FBRyxHQUFFLEtBQUssS0FBRyxHQUFFLENBQUMsS0FBSyxLQUFHLENBQUMsRUFBRSxZQUFVLFNBQVMsQ0FBQyxTQUFPLEdBQUUsQ0FBQyxTQUFPLENBQUMsR0FBRTtBQUNyRyxVQUFNLFFBQU0sRUFBQyxHQUFFLEtBQUssSUFBRSxRQUFNLE9BQU8sS0FBSyxPQUFPLEdBQUUsR0FBRSxLQUFLLElBQUUsUUFBTSxPQUFPLEtBQUssT0FBTyxFQUFDLEdBQUUsVUFBUSxLQUFLLFVBQVE7QUFDM0csVUFBTSxRQUFNLEVBQUMsR0FBRSxNQUFNLElBQUUsUUFBTSxPQUFPLE9BQU8sR0FBRSxHQUFFLE1BQU0sSUFBRSxRQUFNLE9BQU8sT0FBTyxHQUFFLFFBQU8sR0FBRSxNQUFJLEVBQUMsR0FBRyxNQUFLLE1BQUs7QUFDeEcsUUFBRyxDQUFDLFNBQVMsS0FBSSxNQUFLLEtBQUssS0FBSyxDQUFDLFFBQVEsT0FBTSxLQUFLLEVBQUU7QUFDdEQsUUFBRyxDQUFDLGlCQUFpQixLQUFJLE1BQUssT0FBTSxHQUFHLEtBQUssQ0FBQyxRQUFRLE9BQU0sR0FBRyxFQUFFO0FBQ2hFLFNBQUssS0FBSyxFQUFDLE9BQU0sS0FBSSxNQUFLLENBQUM7QUFBQSxFQUM3QjtBQUdBLFNBQU8sQ0FBQyxTQUFxQztBQUMzQyxRQUFJLE1BQTBCLFdBQVM7QUFDdkMsZUFBVSxFQUFDLE9BQU0sS0FBSSxNQUFLLEtBQUssTUFBSztBQUNsQyxZQUFNLGFBQVcsY0FBYyxLQUFJLE1BQUssTUFBSyxPQUFNLE9BQU87QUFBRSxVQUFHLENBQUMsV0FBVztBQUMzRSxZQUFNLE9BQUssV0FBVyxHQUFHLEVBQUUsS0FBSztBQUNoQyxVQUFHLENBQUMsaUJBQWlCLEtBQUksTUFBSyxNQUFLLEtBQUssS0FBSyxDQUFDLFFBQVEsTUFBSyxLQUFLLEVBQUU7QUFDbEUsWUFBTSxPQUFLLFVBQVUsS0FBSSxNQUFLLE1BQUssQ0FBQyxHQUFHLFlBQVcsR0FBSSxLQUFLLElBQUksa0JBQWtCLEtBQUssU0FBUSxNQUFNLE9BQU8sQ0FBQyxJQUFFLE9BQUssQ0FBQyxLQUFLLElBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUNuSSxVQUFHLFFBQU0sU0FBUztBQUNsQixpQkFBUztBQUFLLGFBQUssQ0FBQyxHQUFHLFlBQVcsR0FBSSxLQUFLLElBQUksa0JBQWtCLEtBQUssU0FBUSxNQUFNLE9BQU8sQ0FBQyxJQUFFLE9BQUssQ0FBQyxLQUFLLElBQUUsQ0FBQyxHQUFHLEdBQUc7QUFBQSxJQUNwSDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFTyxnQkFBUyxVQUFVLEtBQWEsTUFBWSxNQUFhLGVBQXFELGNBQTBCO0FBQzdJLFNBQU8sY0FBYyxLQUFJLE1BQUssTUFBSyxZQUFZLEVBQUU7QUFDbkQ7QUFHTyxnQkFBUyxpQkFBaUIsTUFBa0I7QUFDakQsUUFBTSxTQUFPLGlCQUFpQixJQUFJLEdBQUUsU0FBTyxZQUFZLElBQUksRUFBRztBQUM5RCxTQUFPLEtBQUssSUFBSSxTQUFPLE1BQUksT0FBTyxXQUFTLE9BQUssT0FBTyxRQUFNLE9BQU8sV0FBUyxDQUFDO0FBQ2hGO0FBQ0EsU0FBUyxZQUFZLE1BQW9CO0FBQ3ZDLFFBQU0sVUFBUSxZQUFZLElBQUksRUFBRyxTQUFPLE1BQUksVUFBUSxpQkFBaUIsSUFBSTtBQUN6RSxTQUFPLENBQUMsR0FBRyxvQkFBSSxJQUFJLENBQUMsU0FBUSxLQUFLLElBQUksU0FBUSxVQUFRLEdBQUUsR0FBRSxPQUFPLENBQUMsQ0FBQztBQUNwRTtBQUNBLFNBQVMsa0JBQWtCLE1BQW9CO0FBRzdDLFFBQU0sU0FBTyxZQUFZLElBQUksRUFBRztBQUNoQyxTQUFPLENBQUMsR0FBRyxvQkFBSSxJQUFJLENBQUMsR0FBRyxZQUFZLElBQUksRUFBRSxJQUFJLFlBQVEsS0FBSyxJQUFJLFFBQU8sTUFBTSxDQUFDLEdBQUUsU0FBTyxJQUFHLENBQUMsQ0FBQztBQUM1RjtBQUNBLFNBQVMsZUFBZSxLQUFXLE1BQW9CO0FBQ3JELFFBQU0sU0FBTyxpQkFBaUIsSUFBSSxHQUFFLFlBQVUsa0JBQWtCLE1BQUssR0FBRyxFQUFFO0FBSTFFLFFBQU0sV0FBUyxLQUFLLElBQUksWUFBWSxJQUFJLEVBQUcsU0FBTyxLQUFHLFlBQVUsS0FBSyxJQUFJLE1BQUssT0FBTyxRQUFRLENBQUM7QUFDN0YsU0FBTyxDQUFDLEdBQUcsb0JBQUksSUFBSSxDQUFDLEdBQUcsWUFBWSxJQUFJLEdBQUUsUUFBUSxDQUFDLENBQUM7QUFDckQ7QUFDQSxTQUFTLGdCQUFnQixNQUFVLFFBQXNCO0FBRXZELFNBQU8sS0FBSyxJQUFJLGlCQUFpQixJQUFJLEVBQUUsT0FBTSxTQUFPLGlCQUFpQixJQUFJLEVBQUUsV0FBUyxJQUFHO0FBQ3pGO0FBQ0EsU0FBUyxVQUFVLE1BQWMsU0FBZSxRQUFjLFlBQThCO0FBQzFGLFFBQU0sT0FBSyxrQkFBa0IsS0FBSyxTQUFRLE9BQU87QUFDakQsU0FBTyxnQkFBZ0IsTUFBSyxNQUFLLFFBQU8sVUFBVTtBQUNwRDtBQUNBLFNBQVMsZ0JBQWdCLE1BQWMsTUFBWSxRQUFjLFlBQThCO0FBQzdGLE1BQUcsS0FBSyxJQUFJLElBQUksSUFBRSxLQUFLLFFBQU8sQ0FBQztBQUMvQixRQUFNLFlBQVUsS0FBSyxLQUFLLElBQUksSUFBRSxRQUFPLFFBQU0sS0FBSyxJQUFJLEdBQUUsS0FBSyxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUcsS0FBSyxLQUFHLEdBQUcsQ0FBQztBQUM5RixRQUFNLFNBQWtCLENBQUM7QUFDekIsV0FBUSxJQUFFLEdBQUUsS0FBRyxPQUFNLEtBQUk7QUFDdkIsVUFBTSxVQUFRLEtBQUssVUFBUSxPQUFLLElBQUU7QUFDbEMsV0FBTyxLQUFLO0FBQUEsTUFBQyxHQUFFLEtBQUssS0FBRyxPQUFPLE9BQU8sSUFBRSxPQUFPLEtBQUssT0FBTyxLQUFHO0FBQUEsTUFDM0QsR0FBRSxLQUFLLEtBQUcsT0FBTyxPQUFPLElBQUUsT0FBTyxLQUFLLE9BQU8sS0FBRztBQUFBLE1BQVU7QUFBQSxNQUFRO0FBQUEsTUFBVTtBQUFBLElBQVUsQ0FBQztBQUFBLEVBQzNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLE1BQVUsTUFBYyxZQUE4QjtBQUMxRSxRQUFNLFFBQU0sS0FBSyxJQUFJLEdBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxHQUFFLGVBQWEsaUJBQWlCLElBQUksRUFBRTtBQUNyRixRQUFNLFdBQVMsS0FBSyxJQUFJLElBQUcsUUFBTSxRQUFNLGFBQVcsZUFBYSxJQUFFLEtBQUssSUFBSSxNQUFLLFlBQVksRUFBRTtBQUM3RixTQUFPLFdBQVMsT0FBSyxDQUFDLElBQUUsQ0FBQyxFQUFDLEdBQUUsS0FBSyxJQUFFLFdBQVMsT0FBTyxLQUFLLE9BQU8sR0FBRSxHQUFFLEtBQUssSUFBRSxXQUFTLE9BQU8sS0FBSyxPQUFPLEdBQUUsU0FBUSxLQUFLLFNBQVEsV0FBVSxHQUFFLFdBQVUsQ0FBQztBQUN0SjtBQUdBLFNBQVMsV0FBVyxLQUFXLE1BQVUsTUFBYyxRQUFtQztBQUN4RixRQUFNLGVBQWEsS0FBSyxJQUFJLE1BQUssaUJBQWlCLElBQUksRUFBRSxZQUFZO0FBQ3BFLE1BQUksT0FBSyxHQUFFLFFBQU0sS0FBSyxJQUFJLEdBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxHQUFFLFdBQVM7QUFDL0QsYUFBVSxTQUFTLFFBQU87QUFDeEIsVUFBTSxNQUFJLEtBQUssSUFBSSxrQkFBa0IsU0FBUyxTQUFRLE1BQU0sT0FBTyxDQUFDO0FBQ3BFLFVBQU0sV0FBUyxNQUFNLFlBQVUsTUFBSSxLQUFLLElBQUksTUFBTSxTQUFTLElBQUUsS0FBSyxNQUFNLE1BQU0sSUFBRSxTQUFTLEdBQUUsTUFBTSxJQUFFLFNBQVMsQ0FBQztBQUM3RyxVQUFNLGNBQVksa0JBQWtCLE1BQUssS0FBSSxTQUFTLFVBQVEsa0JBQWtCLFNBQVMsU0FBUSxNQUFNLE9BQU8sSUFBRSxHQUFFLEVBQUMsZUFBYyxLQUFJLENBQUM7QUFDdEksVUFBTSxNQUFJLEtBQUssSUFBSSxLQUFLLElBQUksWUFBWSxhQUFZLFlBQVksY0FBYyxHQUFFLE1BQU0sY0FBYyxRQUFRO0FBQzVHLFVBQU0sbUJBQWlCLEtBQUssSUFBSSxNQUFJLE1BQUksUUFBTSxLQUFLLEtBQUcsSUFBRTtBQUN4RCxRQUFHLFlBQVUsa0JBQWlCO0FBQzVCLFlBQU0sV0FBUyxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUUsUUFBTSxRQUFNLEtBQUssS0FBSyxNQUFJLEtBQUssSUFBRSxJQUFFLGVBQWEsUUFBUSxDQUFDO0FBQzdGLGNBQU0sS0FBSyxJQUFJLFdBQVMsS0FBSyxJQUFFO0FBQWEsY0FBTTtBQUFBLElBQ3BELE9BQU07QUFJSixjQUFNLEtBQUssSUFBSSxNQUFJLEtBQUssSUFBRSxnQkFBYyxXQUFTLG9CQUFrQixLQUFLLElBQUksTUFBSyxHQUFHO0FBQ3BGLGNBQU07QUFBQSxJQUNSO0FBQ0EsZUFBUztBQUFBLEVBQ1g7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxNQUFNLGdCQUFjLENBQUMsV0FBaUIsU0FBTyxJQUFFLEtBQUssTUFBSyxJQUFFLEtBQUssT0FBSyxJQUFFLEtBQUs7QUFDNUUsU0FBUyxhQUFhLE1BQVcsUUFBZ0M7QUFDL0QsTUFBSSxXQUFTLEdBQUUsV0FBUztBQUN4QixhQUFVLFNBQVMsUUFBTztBQUFDLGdCQUFVLEtBQUssTUFBTSxNQUFNLElBQUUsU0FBUyxHQUFFLE1BQU0sSUFBRSxTQUFTLENBQUM7QUFBRSxlQUFTO0FBQUEsRUFBTTtBQUN0RyxTQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixLQUFXLE1BQVUsTUFBYyxRQUFrQixTQUFrRDtBQUNsSSxNQUFHLENBQUMsZUFBZSxLQUFJLE1BQUssTUFBSyxRQUFPLE9BQU8sRUFBRSxRQUFPO0FBSXhELFFBQU0sU0FBTyxZQUFZLElBQUksRUFBRyxTQUFPO0FBQ3ZDLGFBQVUsUUFBUSxDQUFDLElBQUcsQ0FBQyxHQUFFO0FBQ3ZCLFVBQU0sU0FBTyxDQUFDLFdBQTJCO0FBQUEsTUFBQyxHQUFHO0FBQUEsTUFBTSxHQUFFLE1BQU0sSUFBRSxPQUFLLFNBQU8sT0FBTyxNQUFNLE9BQU87QUFBQSxNQUFFLEdBQUUsTUFBTSxJQUFFLE9BQUssU0FBTyxPQUFPLE1BQU0sT0FBTztBQUFBLE1BQ3ZJLEdBQUksTUFBTSxZQUFVLEVBQUMsV0FBVSxNQUFNLGFBQVcsSUFBRSxPQUFLLFNBQU8sTUFBTSxXQUFVLElBQUUsQ0FBQztBQUFBLElBQUU7QUFDckYsUUFBRyxDQUFDLGVBQWUsS0FBSSxNQUFLLE9BQU8sSUFBSSxHQUFFLE9BQU8sSUFBSSxNQUFNLEdBQUUsT0FBTyxFQUFFLFFBQU87QUFBQSxFQUM5RTtBQUNBLFNBQU87QUFDVDtBQUlPLGdCQUFTLGtCQUFrQixLQUFXLE1BQVUsTUFBYyxRQUFhLE1BQVcsVUFBeUMsTUFBSSxNQUEyQjtBQUNuSyxRQUFNLFdBQVMsS0FBSyxNQUFNLE9BQU8sSUFBRSxLQUFLLEdBQUUsT0FBTyxJQUFFLEtBQUssQ0FBQyxHQUFFLFdBQVMsS0FBSyxNQUFNLEtBQUssSUFBRSxPQUFPLEdBQUUsS0FBSyxJQUFFLE9BQU8sQ0FBQztBQUM5RyxRQUFNLE9BQUssa0JBQWtCLFVBQVMsUUFBUSxHQUFFLFNBQU8sS0FBSyxNQUFNLE9BQU8sSUFBRSxLQUFLLEdBQUUsT0FBTyxJQUFFLEtBQUssQ0FBQyxHQUFFLFFBQU0sS0FBSyxNQUFNLEtBQUssSUFBRSxPQUFPLEdBQUUsS0FBSyxJQUFFLE9BQU8sQ0FBQztBQUNuSixNQUFHLEtBQUssSUFBSSxrQkFBa0IsS0FBSyxTQUFRLFFBQVEsQ0FBQyxJQUFFLFFBQU8sS0FBSyxJQUFJLElBQUksSUFBRSxRQUFPLEtBQUssSUFBSSxJQUFJLElBQUUsS0FBSyxLQUFHLE9BQU0saUJBQWlCLElBQUksRUFBRSxZQUFVLEtBQUs7QUFDdEosTUFBSSxNQUEwQixXQUFTO0FBQ3ZDLGFBQVUsVUFBVSxrQkFBa0IsSUFBSSxHQUFFO0FBQzFDLFFBQUcsUUFBUSxTQUFPLFlBQVksSUFBSSxFQUFHLFNBQU8sS0FBSTtBQUNoRCxVQUFNLFVBQVEsU0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksSUFBRSxDQUFDLEdBQUUsYUFBVyxnQkFBZ0IsTUFBSyxNQUFNO0FBQ3RGLFVBQU0sVUFBUSxhQUFhLE1BQUssTUFBSyxVQUFVLEdBQUUsZ0JBQWMsUUFBUSxTQUFPLEtBQUssTUFBTSxRQUFRLENBQUMsRUFBRyxJQUFFLEtBQUssR0FBRSxRQUFRLENBQUMsRUFBRyxJQUFFLEtBQUssQ0FBQyxJQUFFO0FBQ3BJLFFBQUcsVUFBUSxnQkFBYyxLQUFHLFVBQVUsVUFBUSxLQUFHLE1BQU07QUFDdkQsVUFBTSxRQUFlLEVBQUMsR0FBRSxPQUFPLElBQUUsVUFBUSxPQUFPLFFBQVEsR0FBRSxHQUFFLE9BQU8sSUFBRSxVQUFRLE9BQU8sUUFBUSxHQUFFLFNBQVEsVUFBUyxXQUFVLEdBQUUsV0FBVTtBQUNySSxVQUFNLFNBQU8sQ0FBQyxPQUFNLEdBQUcsVUFBVSxPQUFNLFVBQVMsUUFBTyxVQUFVLEdBQUUsRUFBQyxHQUFHLE1BQUssU0FBUSxVQUFTLFdBQVUsRUFBQyxDQUFDO0FBQ3pHLFVBQU0sT0FBSyxXQUFXLEtBQUksTUFBSyxNQUFLLE1BQU07QUFDMUMsUUFBRyxRQUFNLFlBQVksQ0FBQyxvQkFBb0IsS0FBSSxNQUFLLE1BQUssUUFBTyxPQUFPLEVBQUU7QUFDeEUsV0FBSztBQUFPLGVBQVM7QUFBQSxFQUN2QjtBQUNBLFNBQU87QUFDVDtBQUlBLFNBQVMsaUJBQWlCLEtBQVcsTUFBVSxNQUFjLE1BQVcsU0FBeUMsTUFBWSxhQUEwQztBQUNySyxRQUFNLEtBQUcsS0FBSyxJQUFFLEtBQUssR0FBRSxLQUFHLEtBQUssSUFBRSxLQUFLLEdBQUUsTUFBSSxLQUFLLE1BQU0sSUFBRyxFQUFFO0FBQzVELE1BQUcsTUFBSSxLQUFLLFFBQU8sQ0FBQztBQUNwQixRQUFNLFlBQVUsS0FBSyxNQUFNLElBQUcsRUFBRSxHQUFFLFFBQU0sa0JBQWtCLEtBQUssU0FBUSxTQUFTO0FBQ2hGLE1BQUcsS0FBSyxJQUFJLEtBQUssSUFBRSxNQUFLO0FBQUMsVUFBTSxTQUFPLENBQUMsRUFBQyxHQUFHLE1BQUssU0FBUSxLQUFLLFFBQU8sQ0FBQztBQUFFLFdBQU8sZUFBZSxLQUFJLE1BQUssTUFBSyxRQUFPLE9BQU8sSUFBRSxTQUFPO0FBQUEsRUFBVTtBQUM1SSxNQUFHLGlCQUFpQixJQUFJLEVBQUUsWUFBVSxLQUFLO0FBQ3pDLE1BQUksTUFBMEIsV0FBUyxVQUFTLGVBQWE7QUFDN0QsYUFBVSxVQUFVLE9BQU8sa0JBQWtCLElBQUksSUFBSSxZQUFZLElBQUksR0FBRTtBQUNyRSxRQUFHLGdCQUFnQixTQUFPLFlBQVksSUFBSSxFQUFHLFNBQU8sS0FBSTtBQUN4RCxVQUFNLGFBQVcsZ0JBQWdCLE1BQUssTUFBTSxHQUFFLE9BQUssYUFBYSxNQUFLLE1BQUssVUFBVSxHQUFFLFFBQU0sS0FBSyxHQUFHLEVBQUUsS0FBSztBQUMzRyxlQUFVLFFBQVEsQ0FBQyxRQUFNLElBQUUsS0FBRyxHQUFFLFFBQU0sSUFBRSxJQUFFLEVBQUUsR0FBRTtBQUM1QyxZQUFNLFNBQU8sRUFBQyxHQUFFLE1BQU0sSUFBRSxPQUFLLFNBQU8sT0FBTyxNQUFNLE9BQU8sR0FBRSxHQUFFLE1BQU0sSUFBRSxPQUFLLFNBQU8sT0FBTyxNQUFNLE9BQU8sRUFBQztBQUNyRyxZQUFNLEtBQUcsS0FBSyxJQUFFLE9BQU8sR0FBRSxLQUFHLEtBQUssSUFBRSxPQUFPLEdBQUUsV0FBUyxLQUFLLE1BQU0sSUFBRyxFQUFFO0FBQ3JFLFVBQUcsV0FBUyxTQUFPLEtBQUs7QUFDeEIsWUFBTSxTQUFPLEtBQUssTUFBTSxJQUFHLEVBQUUsSUFBRSxPQUFLLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRSxTQUFPLFFBQVEsQ0FBQztBQUN6RSxZQUFNLFVBQVEsU0FBTyxPQUFLLEtBQUssS0FBRyxHQUFFLE9BQUssY0FBYyxPQUFLLGtCQUFrQixLQUFLLFNBQVEsT0FBTyxDQUFDO0FBR25HLFVBQUcsT0FBSyxLQUFLLEtBQUcsSUFBSTtBQUNwQixZQUFNLFNBQWtCLENBQUMsR0FBRyxNQUFLLEdBQUcsZ0JBQWdCLE9BQU0sT0FBSyxNQUFLLFFBQU8sVUFBVSxDQUFDO0FBQ3RGLFlBQU0sVUFBUSxPQUFPLEdBQUcsRUFBRTtBQUkxQixZQUFNLFdBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxrQkFBa0IsS0FBSSxFQUFDLEdBQUcsTUFBSyxTQUFRLEVBQUMsR0FBRyxLQUFLLFNBQVMsT0FBTSxXQUFVLEVBQUMsR0FBRSxTQUFRLE1BQUssTUFBSyxPQUFPO0FBQy9ILFVBQUcsS0FBSyxNQUFNLEtBQUssSUFBRSxRQUFRLEdBQUUsS0FBSyxJQUFFLFFBQVEsQ0FBQyxJQUFFLEtBQUssUUFBTyxLQUFLLEVBQUMsR0FBRyxNQUFLLFNBQVEsUUFBUSxTQUFRLFdBQVUsRUFBQyxDQUFDO0FBRS9HLFVBQUcsZ0JBQWMsVUFBYSxhQUFhLE1BQUssTUFBTSxJQUFFLFlBQVk7QUFDcEUsWUFBTSxPQUFLLFdBQVcsS0FBSSxNQUFLLE1BQUssTUFBTTtBQUMxQyxVQUFHLGdCQUFnQixDQUFDLFlBQVksaUJBQWUsWUFBWSxRQUFNLFdBQVMsUUFBUSxDQUFDLG9CQUFvQixLQUFJLE1BQUssTUFBSyxRQUFPLE9BQU8sRUFBRTtBQUNySSxhQUFLO0FBQU8saUJBQVM7QUFBSyxxQkFBYTtBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVPLGdCQUFTLHNCQUFzQixNQUFjLFFBQXlDO0FBQzNGLFFBQU0sU0FBa0IsQ0FBQztBQUN6QixhQUFPO0FBQ1AsUUFBSSxXQUFTLE1BQUssV0FBUztBQUMzQixhQUFRLElBQUUsR0FBRSxJQUFFLE9BQU8sUUFBTyxLQUFJO0FBQzlCLFlBQU0sUUFBTSxPQUFPLENBQUM7QUFDcEIsVUFBRyxNQUFNLFVBQVUsTUFBTSxJQUFFLFNBQVMsS0FBRyxPQUFPLE1BQU0sT0FBTyxLQUFHLE1BQU0sSUFBRSxTQUFTLEtBQUcsT0FBTyxNQUFNLE9BQU8sSUFBRSxPQUFNO0FBQUMsbUJBQVM7QUFBRTtBQUFBLE1BQU07QUFDaEksaUJBQVM7QUFBQSxJQUNYO0FBQ0EsUUFBRyxZQUFVLEdBQUU7QUFHYixhQUFNLFdBQVMsSUFBRSxPQUFPLFFBQU87QUFDN0IsY0FBTSxRQUFNLE9BQU8sV0FBUyxDQUFDLEdBQUcsUUFBTSxPQUFPLFFBQVE7QUFDckQsWUFBRyxDQUFDLE1BQU0sU0FBUyxLQUFLLE1BQU0sTUFBTSxJQUFFLE1BQU0sR0FBRSxNQUFNLElBQUUsTUFBTSxDQUFDLElBQUUsU0FDekQsTUFBTSxJQUFFLE1BQU0sS0FBRyxPQUFPLE1BQU0sT0FBTyxLQUFHLE1BQU0sSUFBRSxNQUFNLEtBQUcsT0FBTyxNQUFNLE9BQU8sS0FBRyxNQUFNO0FBQzVGO0FBQUEsTUFDRjtBQUNBLFlBQU0sU0FBTyxPQUFPLE1BQU0sR0FBRSxXQUFTLENBQUMsRUFBRSxJQUFJLFlBQVEsRUFBQyxHQUFHLE9BQU0sT0FBTSxLQUFJLEVBQUU7QUFDMUUsYUFBTyxLQUFLLEdBQUcsTUFBTTtBQUFFLGFBQUssT0FBTyxRQUFRO0FBQUcsZUFBTyxPQUFPLE1BQU0sV0FBUyxDQUFDO0FBQUU7QUFBQSxJQUNoRjtBQUlBLFVBQU0sVUFBUSxPQUFPLE9BQU8sQ0FBQyxPQUFNLE1BQUk7QUFDckMsWUFBTSxJQUFFLE9BQU8sSUFBRSxDQUFDLEtBQUssTUFBSyxJQUFFLE9BQU8sSUFBRSxDQUFDO0FBQ3hDLGFBQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxrQkFBa0IsRUFBRSxTQUFRLE1BQU0sT0FBTyxDQUFDLElBQUUsUUFDN0QsS0FBSyxJQUFJLGtCQUFrQixNQUFNLFNBQVEsRUFBRSxPQUFPLENBQUMsSUFBRSxRQUNyRCxLQUFLLE1BQU0sTUFBTSxJQUFFLEVBQUUsR0FBRSxNQUFNLElBQUUsRUFBRSxDQUFDLElBQUUsUUFBUSxLQUFLLE1BQU0sRUFBRSxJQUFFLE1BQU0sR0FBRSxFQUFFLElBQUUsTUFBTSxDQUFDLElBQUU7QUFBQSxJQUN2RixDQUFDO0FBQ0QsV0FBTSxFQUFDLFFBQU8sTUFBSyxTQUFRLFFBQU8sT0FBTSxHQUFFLFdBQVUsUUFBUSxTQUFPLEVBQUM7QUFBQSxFQUNwRTtBQUNGO0FBR08sZ0JBQVMsd0JBQXdCLEtBQVcsTUFBVSxPQUE0QixTQUF5QyxXQUFTLFVBQWtCO0FBQzNKLE1BQUksUUFBTTtBQUNWLFNBQU0sTUFBTSxRQUFNLE1BQU0sUUFBUSxRQUFPO0FBQ3JDLFFBQUcsTUFBTSxZQUFVLE1BQU0sT0FBTTtBQUM3QixZQUFNLFNBQU8sTUFBTSxRQUFRLE1BQU0sT0FBTztBQUFHLFlBQU0sT0FBTyxLQUFLLEVBQUMsR0FBRyxNQUFNLFFBQU8sT0FBTSxLQUFJLENBQUM7QUFDekYsWUFBTSxZQUFVLE1BQU0sUUFBUSxTQUFPO0FBQUU7QUFBQSxJQUN6QztBQUNBLFVBQU0sT0FBSyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3hDLFFBQUcsS0FBSyxNQUFNLEtBQUssSUFBRSxNQUFNLE9BQU8sR0FBRSxLQUFLLElBQUUsTUFBTSxPQUFPLENBQUMsSUFBRSxZQUFZLElBQUksRUFBRyxTQUFPLEtBQUc7QUFBQyxZQUFNO0FBQVk7QUFBQSxJQUFTO0FBQ3BILFFBQUcsV0FBUyxTQUFTLFFBQU87QUFDNUIsVUFBTSxjQUFZLGFBQWEsTUFBTSxRQUFPLE1BQU0sUUFBUSxNQUFNLE1BQU0sT0FBTSxNQUFNLFlBQVUsQ0FBQyxDQUFDLElBQUU7QUFDaEcsVUFBTSxZQUFVLGlCQUFpQixLQUFJLE1BQUssTUFBTSxRQUFPLE1BQUssU0FBUSxRQUFVLFdBQVc7QUFDekYsVUFBTSxZQUFVLE1BQU0sUUFBUSxNQUFNLFlBQVUsQ0FBQztBQUMvQyxRQUFHLENBQUMsYUFBYSxhQUFhLE1BQU0sUUFBTyxTQUFTLElBQUUsZUFDakQsYUFBYSxDQUFDLGVBQWUsS0FBSSxNQUFLLFVBQVUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEdBQUUsT0FBTyxHQUFFO0FBQUMsWUFBTTtBQUFZO0FBQUEsSUFBUztBQUM5RyxVQUFNLE9BQU8sS0FBSyxHQUFHLFNBQVM7QUFBRSxVQUFNLFNBQU8sVUFBVSxHQUFHLEVBQUU7QUFDNUQsVUFBTSxRQUFNLE1BQU0sWUFBVTtBQUFFLFVBQU0sWUFBVSxNQUFNLFFBQVEsU0FBTztBQUFBLEVBQ3JFO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0IsS0FBVyxNQUFVLE1BQWMsUUFBa0IsU0FBcUQ7QUFDekksUUFBTSxRQUFNLHNCQUFzQixNQUFLLE1BQU07QUFBRSwwQkFBd0IsS0FBSSxNQUFLLE9BQU0sT0FBTztBQUFFLFNBQU8sTUFBTTtBQUM5RztBQUdPLGdCQUFTLGdCQUFnQixLQUFXLE1BQVUsTUFBK0IsZUFBa0QsY0FBYSxTQUFPLFVBQThDO0FBQ3RNLFFBQU0sT0FBSyxFQUFDLEdBQUUsS0FBSyxHQUFFLEdBQUUsS0FBSyxHQUFFLFNBQVEsS0FBSyxTQUFTLFdBQVcsRUFBQztBQUNoRSxNQUFHLEtBQUssWUFBVSxVQUFhLEtBQUssTUFBTSxLQUFLLElBQUUsS0FBSyxHQUFFLEtBQUssSUFBRSxLQUFLLENBQUMsS0FBRyxZQUFZLElBQUksRUFBRyxTQUFPO0FBQ2hHLFdBQU8sY0FBYyxLQUFJLE1BQUssTUFBSyxjQUFhLE1BQU07QUFDeEQsUUFBTSxTQUFPLGlCQUFpQixLQUFJLE1BQUssTUFBSyxZQUFZO0FBQ3hELE1BQUcsT0FBTyxRQUFNLEVBQUMsUUFBTyxRQUFPLFNBQVEsTUFBSztBQUM1QyxRQUFNLFlBQVUsY0FBYyxLQUFJLE1BQUssTUFBSyxjQUFhLFFBQU8sSUFBSTtBQUNwRSxTQUFNLEVBQUMsUUFBTyx3QkFBd0IsS0FBSSxNQUFLLE1BQUssVUFBVSxRQUFPLFlBQVksR0FBRSxTQUFRLFVBQVUsUUFBTztBQUM5RztBQUdPLGdCQUFTLGlCQUFpQixLQUFXLE1BQVUsTUFBVyxTQUErRDtBQUM5SCxRQUFNLE9BQUssRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssR0FBRSxTQUFRLEtBQUssU0FBUyxXQUFTLEVBQUM7QUFDOUQsUUFBTSxTQUFPLEtBQUssYUFBYSxDQUFDLEdBQUUsVUFBUSxLQUFLO0FBQy9DLFFBQU0sT0FBSyxRQUFRLFNBQU8sVUFBVSxRQUFRLFlBQVUsVUFBYSxRQUFRLGtCQUFnQixVQUN0RixRQUFRLGNBQVksVUFBYSxRQUFRLGVBQWEsVUFDdEQsUUFBUSxNQUFJLEtBQUssS0FBSyxRQUFRLE1BQUksS0FBSyxLQUFLLFFBQVEsU0FBTyxVQUMzRCxPQUFPLFlBQVUsVUFBYSxPQUFPLGtCQUFnQixVQUFhLE9BQU8sY0FBWSxVQUFhLE9BQU8sZUFBYSxVQUN0SCxDQUFDLENBQUMsT0FBTyxnQkFBYyxDQUFDLENBQUMsUUFBUSxlQUNqQyxDQUFDLGtCQUFrQixNQUFLLEtBQUksS0FBSyxNQUFNLE9BQU8sSUFBRSxLQUFLLEdBQUUsT0FBTyxJQUFFLEtBQUssQ0FBQyxHQUFFLEVBQUMsZUFBYyxLQUFJLENBQUMsRUFBRSxPQUFPLFNBQVM7QUFDbkgsU0FBTyxpQkFBaUIsS0FBSSxNQUFLLE1BQUssTUFBSyxTQUFRLElBQUk7QUFDekQ7QUFHQSxJQUFJLG1CQUFtQjtBQUNoQixnQkFBUyxjQUFjLEtBQWEsTUFBWSxNQUFpQyxlQUFxRCxjQUFjLFNBQU8sVUFBVSxTQUFPLE9BQTRDO0FBQzdOO0FBQ0EsTUFBSTtBQUFFLFdBQU8sa0JBQWtCLEtBQUksTUFBSyxNQUFLLGNBQWEsUUFBTyxRQUFPLG1CQUFpQixDQUFDO0FBQUEsRUFBSSxVQUM5RjtBQUFVO0FBQUEsRUFBb0I7QUFDaEM7QUFXTyxnQkFBUyx1QkFBdUIsS0FBVyxNQUFVLE1BQStCLGNBQ3pGLFFBQWMsUUFBZSxPQUFrRDtBQUMvRSxNQUFHLE1BQU0sVUFBUSxPQUFPLFFBQU8sTUFBTTtBQUdyQyxNQUFHLE1BQU0sVUFBUSxZQUFXO0FBQzFCLFVBQU0sZUFBYSx1QkFBdUIsS0FBSSxNQUFLLE1BQUssY0FBYSxVQUFTLFFBQU8sTUFBTSxRQUFTO0FBQ3BHLFFBQUcsQ0FBQyxhQUFhO0FBQ2pCLFVBQU0sTUFBSSxNQUFNLEtBQU0sR0FBRyxFQUFFLEtBQUssTUFBSyxXQUFTLGFBQWEsT0FBTyxHQUFHLEVBQUUsS0FBSztBQUM1RSxVQUFNLFNBQU8sRUFBQyxRQUFPLE1BQU0sTUFBTSxTQUFRLENBQUMsQ0FBQyxNQUFNLFlBQVksYUFBYSxXQUFXLEtBQUssTUFBTSxJQUFJLElBQUUsU0FBUyxHQUFFLElBQUksSUFBRSxTQUFTLENBQUMsSUFBRSxLQUFJO0FBQ3ZJLFVBQU0sUUFBTTtBQUFPLFdBQU8sTUFBTTtBQUFBLEVBQ2xDO0FBQ0E7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFPLGtCQUFrQixLQUFJLE1BQUssTUFBSyxjQUFhLFFBQU8sUUFBTyxtQkFBaUIsR0FBRSxLQUFLO0FBQ2hHLFFBQUcsUUFBTztBQUFDLFlBQU0sU0FBTztBQUFPLFlBQU0sUUFBTTtBQUFBLElBQU87QUFBQyxXQUFPO0FBQUEsRUFDNUQsVUFBQztBQUFRO0FBQUEsRUFBbUI7QUFDOUI7QUFDQSxTQUFTLGtCQUFrQixLQUFhLE1BQVksTUFBaUMsY0FBb0QsUUFBZSxRQUFnQixRQUFlLE9BQW9EO0FBR3pPLFFBQU0sWUFBWSxpQkFBaUIsZ0JBQWlCLGFBQXVDLGVBQWU7QUFDMUcsUUFBTSxrQkFBZ0I7QUFBYSxNQUFJLGlCQUFlLE9BQU8sa0JBQWdCO0FBQzdFLGlCQUFhLFlBQVksZUFBZSxDQUFDLE1BQUssT0FBSztBQUFDLFVBQU0sUUFBTSxnQkFBZ0IsTUFBSyxFQUFFO0FBQUUsdUJBQW1CLENBQUM7QUFBTSxXQUFPO0FBQUEsRUFBTTtBQUNoSSxRQUFNLElBQUksSUFBSTtBQUNkLE1BQUksQ0FBQztBQUNILFdBQU8sRUFBQyxRQUFPLENBQUMsRUFBRSxHQUFHLE1BQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRSxTQUFRLE1BQUs7QUFDM0gsUUFBTSxPQUFPLFFBQVEsS0FBSyxJQUFJLEdBQUcsT0FBTyxLQUFLLEtBQUs7QUFDbEQsUUFBTSxTQUFPLGlCQUFpQixJQUFJLEdBQUUsU0FBTyxLQUFLLElBQUksTUFBSyxrQkFBa0IsTUFBSyxLQUFJLEdBQUUsRUFBQyxlQUFjLEtBQUksQ0FBQyxFQUFFLGVBQWUsR0FBRSxZQUFVLEtBQUssSUFBSSxNQUFLLE9BQU8sUUFBUTtBQUNwSyxRQUFNLGVBQWEsTUFBTSxLQUFLLEVBQUMsUUFBTyxXQUFVLEdBQUUsQ0FBQyxHQUFFLE1BQUk7QUFDdkQsVUFBTSxjQUFZLGtCQUFrQixNQUFLLEtBQUksSUFBRSxPQUFNLEVBQUMsZUFBYyxLQUFJLENBQUM7QUFDekUsV0FBTyxFQUFDLFNBQVEsS0FBSyxJQUFJLFlBQVksYUFBWSxZQUFZLGNBQWMsR0FBRSxTQUFRLEtBQUssSUFBSSxPQUFPLGNBQWEsWUFBWSxjQUFjLEVBQUM7QUFBQSxFQUMvSSxDQUFDO0FBQ0QsUUFBTSxjQUFjLGFBQWEsSUFBSSxDQUFDLGFBQVksTUFBTTtBQUN0RCxVQUFNLENBQUMsSUFBRyxFQUFFLElBQUUsTUFBTSxDQUFDLEdBQUksV0FBUyxLQUFLLFFBQU0sTUFBTSxLQUFLLEtBQUssUUFBUTtBQUNyRSxXQUFPLEVBQUMsU0FBUSxXQUFTLEtBQUssSUFBSSxNQUFLLFlBQVksT0FBTyxHQUFFLFNBQVEsV0FBUyxLQUFLLElBQUksTUFBSyxZQUFZLE9BQU8sRUFBQztBQUFBLEVBQ2pILENBQUM7QUFDRCxRQUFNLFVBQVU7QUFDaEIsUUFBTSxPQUFPLENBQUMsT0FBeUI7QUFBRSxVQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVTtBQUFHLFdBQU8sRUFBRSxJQUFJLE9BQU8sUUFBUSxPQUFPLE9BQU0sUUFBUSxNQUFNLElBQUksS0FBSyxNQUFNLE9BQU8sUUFBUSxJQUFJLElBQUksT0FBTSxRQUFRLE1BQU0sU0FBVSxLQUFLLGFBQWMsTUFBTTtBQUFBLEVBQUc7QUFDMU8sUUFBTSxlQUFhLElBQUksSUFBSSxPQUFPLGFBQWEsSUFBSSxXQUFPLENBQUMsTUFBTSxJQUFHLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFDakYsUUFBTSxPQUFPLENBQUMsT0FBZTtBQUMzQixRQUFJLENBQUMsS0FBSyxLQUFLLEVBQUU7QUFDZixXQUFLLEtBQUssRUFBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUksS0FBSyxNQUFNLEtBQUssVUFBVSxFQUFHLENBQUMsQ0FBRSxJQUFJLElBQUk7QUFDbEYsUUFBRyxLQUFLLEtBQUssRUFBRSxNQUFJLEVBQUUsUUFBTztBQUM1QixRQUFHLFVBQVUsUUFBTztBQUlwQixRQUFHLFlBQVksRUFBRSxNQUFJLGNBQWMsWUFBWSxFQUFFLE1BQUksQ0FBQyxZQUFXO0FBQUMsWUFBTSxLQUFHLEtBQUssRUFBRTtBQUFFLFlBQU0sUUFBTSxhQUFhLElBQUcsRUFBRTtBQUFFLGtCQUFZLEVBQUUsSUFBRSxRQUFNLGFBQVcsQ0FBQztBQUFXLFVBQUcsTUFBTSxjQUFhLElBQUksSUFBRyxLQUFLO0FBQUEsSUFBRTtBQUNyTSxXQUFPLFlBQVksRUFBRSxNQUFJO0FBQUEsRUFDM0I7QUFDQSxRQUFNLFlBQVUsS0FBSyxZQUFVLFNBQVUsU0FBVSxFQUFDLEdBQUUsS0FBSyxHQUFFLEdBQUUsS0FBSyxHQUFFLFNBQVEsS0FBSyxRQUFPO0FBQzFGLE1BQUksaUJBQWUsT0FBTyxRQUFPLFdBQVMsT0FBTyxZQUFVO0FBQzNELFFBQU0sU0FBUyxZQUFZLElBQUksRUFBRztBQUNsQyxRQUFNLFFBQVEsRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxTQUFTLEtBQUssU0FBUyxXQUFXLEVBQUU7QUFDMUUsTUFBRyxDQUFDLGdCQUFlO0FBQ2pCLFVBQU0sZ0JBQWMsYUFBYSxTQUFTLEtBQUksTUFBSyxTQUFTLElBQUksWUFBWSxnQkFBZ0IsS0FBSSxNQUFLLElBQUk7QUFDekcscUJBQWUsaUJBQWlCLGFBQWEsZUFBYyxhQUFhLElBQUksZ0JBQWdCLGdCQUFnQixLQUFJLE1BQUssTUFBSyxNQUFLLENBQUFDLFVBQU0sYUFBYUEsT0FBS0EsS0FBSSxDQUFDO0FBQzVKLFVBQU1DLFVBQU87QUFDYixlQUFTLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQ0EsV0FBVSxLQUFLLE1BQU1BLFFBQU8sSUFBRSxjQUFjLEdBQUVBLFFBQU8sSUFBRSxjQUFjLENBQUMsSUFBRSxRQUNqRyxLQUFLLFlBQVUsVUFBYSxLQUFLLElBQUksa0JBQWtCQSxRQUFPLFNBQVEsY0FBYyxPQUFPLENBQUMsSUFBRTtBQUNuRyxRQUFHLENBQUNBLFFBQU8sUUFBTyxFQUFDLFFBQU8sQ0FBQyxHQUFFLFNBQVEsU0FBUTtBQUM3QyxVQUFNQyxlQUFZLFlBQVVELFVBQU8sRUFBQyxHQUFFQSxRQUFPLEdBQUUsR0FBRUEsUUFBTyxFQUFDO0FBQ3pELFVBQU0sU0FBTyxjQUFjLEtBQUksTUFBSyxPQUFNQyxjQUFZLFlBQVk7QUFDbEUsUUFBRyxPQUFPLFFBQU8sRUFBQyxRQUFPLE9BQU8sT0FBTyxDQUFDLE9BQU0sTUFBSSxNQUFJLEtBQUssS0FBSyxNQUFNLE1BQU0sSUFBRSxNQUFNLEdBQUUsTUFBTSxJQUFFLE1BQU0sQ0FBQyxJQUFFLFFBQ2xHLEtBQUssSUFBSSxrQkFBa0IsTUFBTSxTQUFRLE1BQU0sT0FBTyxDQUFDLElBQUUsUUFBUSxPQUFPLFdBQVMsQ0FBQyxHQUFFLFNBQVEsU0FBUTtBQUN6RyxVQUFNLFVBQVEsb0JBQW9CLEtBQUksTUFBS0QsU0FBTyxZQUFZLEVBQUUsS0FBSztBQUNyRSxRQUFHLFFBQVEsUUFBTyxFQUFDLFFBQU8sU0FBUSxTQUFRLFNBQVE7QUFDbEQsVUFBTSxZQUFVLEtBQUssTUFBTUEsUUFBTyxJQUFFLE1BQU0sR0FBRUEsUUFBTyxJQUFFLE1BQU0sQ0FBQztBQUM1RCxRQUFHLENBQUMsV0FBVSxZQUFVLEtBQUssRUFBRSxFQUFFLE1BQU0sYUFBUyxDQUFDLGlCQUFpQixLQUFJLE1BQUssT0FBTSxFQUFDLEdBQUcsT0FBTSxRQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsT0FBTSxFQUFDLEdBQUcsT0FBTSxRQUFPLENBQUMsQ0FBQyxHQUFFO0FBQy9JLFlBQU0sWUFBVSxlQUFlLEtBQUksTUFBS0EsU0FBTyxZQUFZO0FBQzNELFVBQUcsVUFBVSxRQUFPLEVBQUMsUUFBTyxXQUFVLFNBQVEsS0FBSTtBQUFBLElBQ3BEO0FBQ0EsUUFBRyxPQUFNO0FBQUMsWUFBTSxTQUFPQTtBQUFPLFlBQU0sV0FBUztBQUFTLFlBQU0saUJBQWU7QUFBZSxZQUFNLFFBQU07QUFBVztBQUFBLElBQU87QUFBQSxFQUMxSDtBQUNBLFFBQU0sU0FBTztBQUNiLFFBQU0sY0FBWSxZQUFVLFNBQU8sRUFBQyxHQUFFLE9BQU8sR0FBRSxHQUFFLE9BQU8sRUFBQztBQUN6RCxRQUFNLFNBQU8sb0JBQW9CLEtBQUksTUFBSyxRQUFPLFlBQVk7QUFDN0QsUUFBTSxZQUFZLGdCQUFnQixNQUFLLE1BQU0sR0FBRztBQUFBLElBQUU7QUFBQSxJQUFPLFNBQVM7QUFBQSxJQUFVO0FBQUEsSUFBUTtBQUFBLElBQ2xGO0FBQUEsSUFBZTtBQUFBLElBQVc7QUFBQSxFQUFXLElBQUksV0FBVyxXQUFXLFNBQVMsSUFBSSxTQUFTLElBQUksY0FBYyxNQUFNO0FBSS9HLFFBQU0sZUFBZSxVQUFVLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxRQUFRLE9BQU8sUUFBUSxRQUFRLFVBQ3JGLEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxNQUFNLENBQUMsSUFBSSxRQUFRLE9BQU8sTUFDcEUsQ0FBQztBQUFBLElBQWE7QUFBQSxJQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLElBQUksUUFBUSxPQUFPO0FBQUEsSUFBRyxLQUFLLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLFFBQVEsT0FBTztBQUFBLElBQ2pILEtBQUssSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLElBQUksUUFBUSxPQUFPO0FBQUEsSUFBRyxLQUFLLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLFFBQVEsT0FBTztBQUFBLEVBQUM7QUFDbEcsUUFBTSxpQkFBaUIsYUFBYSxJQUFJLENBQUMsYUFBYSxNQUFNLFNBQVMsS0FBSyxJQUFJLE1BQU0sWUFBWSxTQUFTLGNBQWMsSUFBSSxLQUFLLFVBQVUsRUFBRyxPQUFPLENBQUM7QUFDckosUUFBTSxZQUFZLGVBQWUsaUJBQWlCLEtBQUssTUFBTSxPQUFNLFFBQVEsY0FBYyxJQUFJO0FBSTdGLFFBQU0sWUFBWSxLQUFLLE1BQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSxHQUFHLFlBQVksS0FBSyxNQUFNLE9BQU8sSUFBSSxRQUFRLElBQUk7QUFDckcsTUFBSSxvQkFBb0I7QUFDeEIsTUFBSTtBQUFXLGFBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxZQUFZLENBQUMsR0FBRyxLQUFLLEtBQUssSUFBSSxRQUFRLE9BQU8sR0FBRyxZQUFZLENBQUMsR0FBRztBQUN0RyxlQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsWUFBWSxDQUFDLEdBQUcsS0FBSyxLQUFLLElBQUksUUFBUSxPQUFPLEdBQUcsWUFBWSxDQUFDLEdBQUc7QUFDdkYsWUFBSSxLQUFLLE1BQU0sSUFBSSxLQUFLLE9BQU8sQ0FBQyxNQUFNLEtBQ2pDLEtBQUssT0FBTyxJQUFJLE9BQU0sUUFBUSxPQUFPLE9BQU8sSUFBSSxJQUFJLE9BQU0sUUFBUSxPQUFPLE9BQU8sQ0FBQyxLQUFLLFFBQVEsT0FBTztBQUN4Ryw4QkFBb0IsS0FBSyxJQUFJLG1CQUFtQixlQUFlLFdBQVUsR0FBRSxDQUFDLENBQUM7QUFBQTtBQUNuRixRQUFNLGdCQUFnQixDQUFDLE1BQVksR0FBUyxNQUFhO0FBQ3ZELFFBQUcsV0FBVyxJQUFJLE1BQUksV0FBVyxRQUFPLGVBQWUsSUFBSTtBQUMzRCxVQUFNLFdBQVcsWUFBWSxlQUFlLFdBQVUsT0FBSyxRQUFRLE1BQUssS0FBSyxNQUFNLE9BQUssUUFBUSxJQUFJLENBQUMsSUFBSTtBQUN6RyxVQUFNLGFBQWEsV0FBVztBQUM5QixlQUFXLElBQUksSUFBRTtBQUNqQixXQUFPLGVBQWUsSUFBSSxJQUFFLEtBQUssSUFBSSxLQUFLLE1BQU0sSUFBSSxPQUFPLEdBQUcsSUFBSSxPQUFPLENBQUMsR0FBRyxPQUFPLFNBQVMsVUFBVSxJQUFJLGFBQWEsQ0FBQyxJQUFJO0FBQUEsRUFDL0g7QUFDQSxRQUFNLFlBQVksQ0FBQyxJQUFZLEdBQVcsTUFBYyxjQUFjLEtBQUssTUFBTSxLQUFHLFVBQVUsR0FBRSxHQUFFLENBQUM7QUFDbkcsUUFBTSxPQUFPLENBQUMsT0FBZSxPQUFPLEVBQUUsTUFBTSxhQUFhLE1BQU0sRUFBRSxJQUFLO0FBQ3RFLFFBQU0sVUFBUSxJQUFJLElBQUksT0FBTyxPQUFPLElBQUksV0FBTyxDQUFDLE1BQU0sSUFBRyxLQUFLLENBQUMsQ0FBQztBQUNoRSxhQUFVLFNBQVMsUUFBUSxPQUFPLEdBQUU7QUFBQyxXQUFPLE1BQU0sRUFBRSxJQUFFO0FBQVcsVUFBTSxNQUFNLEVBQUUsSUFBRSxNQUFNO0FBQUssYUFBUyxNQUFNLEVBQUUsSUFBRSxNQUFNO0FBQUEsRUFBTztBQUM1SCxhQUFVLENBQUMsSUFBRyxLQUFLLEtBQUssYUFBYSxhQUFZLEVBQUUsSUFBRSxRQUFNLGFBQVcsQ0FBQztBQUN2RSxNQUFHLE9BQU8sS0FBSyxVQUFTLFFBQVEsTUFBTSxJQUFJO0FBQzFDLFFBQU0sVUFBVSxDQUFDLElBQVksT0FBZSxXQUFtQjtBQUM3RCxXQUFPLEVBQUUsSUFBSTtBQUFZLFVBQU0sRUFBRSxJQUFJO0FBQU8sYUFBUyxFQUFFLElBQUk7QUFDM0QsUUFBRyxNQUFNLFNBQVEsSUFBSSxJQUFHLEVBQUMsSUFBRyxNQUFLLE9BQU0sT0FBTSxDQUFDO0FBQUEsRUFDaEQ7QUFDQSxRQUFNLFdBQVMsSUFBSSxJQUF1QixPQUFPLFVBQVUsSUFBSSxXQUFPLENBQUMsTUFBTSxJQUFHLE1BQU0sTUFBTSxDQUFDLENBQUMsR0FDNUYsWUFBVSxJQUFJLElBQXlCLE9BQU8sV0FBVyxJQUFJLFdBQU8sQ0FBQyxNQUFNLE1BQUssTUFBTSxNQUFNLENBQUMsQ0FBQztBQUNoRyxRQUFNLFFBQU0sTUFBSTtBQUNkLFVBQU8sUUFBTSxNQUFNLEtBQUssUUFBUSxPQUFPLENBQUM7QUFBRSxVQUFPLGNBQVksTUFBTSxLQUFLLGNBQWEsQ0FBQyxDQUFDLElBQUcsS0FBSyxPQUFLLEVBQUMsSUFBRyxNQUFLLEVBQUU7QUFDL0csVUFBTyxPQUFLLFNBQVMsS0FBSztBQUFFLFVBQU8sV0FBUyxNQUFNLEtBQUssVUFBUyxDQUFDLENBQUMsSUFBRyxNQUFNLE9BQUssRUFBQyxJQUFHLE9BQU0sRUFBRTtBQUM1RixVQUFPLFlBQVUsTUFBTSxLQUFLLFdBQVUsQ0FBQyxDQUFDLE1BQUssTUFBTSxPQUFLLEVBQUMsTUFBSyxPQUFNLEVBQUU7QUFBRSxVQUFPLGlCQUFlO0FBQUEsRUFDaEc7QUFDQSxRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSSxRQUFRLElBQUksR0FBRyxNQUFNLEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxJQUFJO0FBQ3JGLE1BQUksaUJBQWUsR0FBRSxlQUFhO0FBQ2xDLE1BQUcsQ0FBQyxTQUFTLE1BQU0sVUFBUSxXQUFXLFVBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxNQUFNLENBQUMsR0FBRyxLQUFLLEtBQUssSUFBSSxRQUFRLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRztBQUNqSCxhQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsS0FBSyxLQUFLLElBQUksUUFBUSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUc7QUFDM0UsZUFBUyxJQUFJLEdBQUcsSUFBSSxZQUFZLEtBQUs7QUFDbkMsWUFBRyxTQUFTLG9CQUFrQixNQUFNLGtCQUFnQixHQUFHO0FBQ3ZELFlBQUcsU0FBUyxrQkFBZ0IsSUFBRztBQUFDLGdCQUFNLGlCQUFlLGlCQUFlO0FBQUUsZ0JBQU07QUFBRTtBQUFBLFFBQU87QUFDckYsY0FBTSxNQUFNLElBQUksUUFBUSxPQUFPLEtBQUssYUFBYSxHQUFHLElBQUksS0FBSyxFQUFFO0FBQy9ELFlBQUksQ0FBQyxLQUFLLEVBQUU7QUFDVjtBQUdGLGNBQU0sT0FBSyxJQUFFLFFBQVEsT0FBSztBQUMxQixZQUFHLENBQUMsVUFBVSxJQUFJLElBQUksRUFBRSxXQUFVLElBQUksTUFBSyxlQUFlLE1BQUssT0FBTSxFQUFDLEdBQUUsRUFBRSxHQUFFLEdBQUUsRUFBRSxFQUFDLENBQUMsRUFBRSxPQUFPLFlBQVEsZUFBZSxLQUFJLE1BQUssT0FBTSxRQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ3RKLFlBQUlFLFNBQTRCLElBQUU7QUFDbEMsbUJBQVUsWUFBWSxVQUFVLElBQUksSUFBSSxHQUFHO0FBQ3pDLGdCQUFNLE1BQUksU0FBUyxHQUFHLEVBQUUsS0FBSztBQUM3QixjQUFHLENBQUMsaUJBQWlCLEtBQUksTUFBSyxLQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsS0FBSSxDQUFDLEVBQUU7QUFDN0QsZ0JBQU0sU0FBTyxDQUFDLEdBQUcsVUFBUyxHQUFJLEtBQUssSUFBSSxrQkFBa0IsSUFBSSxTQUFRLEVBQUUsT0FBTyxDQUFDLElBQUUsT0FBSyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUUsR0FBRSxPQUFLLFVBQVUsS0FBSSxNQUFLLE9BQU0sTUFBTTtBQUNuSSxjQUFHLE9BQUssR0FBRTtBQUFDLGdCQUFFO0FBQUssWUFBQUEsVUFBTztBQUFBLFVBQU87QUFBQSxRQUNsQztBQUNBLFlBQUcsQ0FBQ0EsUUFBTztBQUNYLGdCQUFRLElBQUcsR0FBRSxFQUFFO0FBQUUsaUJBQVMsSUFBSSxJQUFHQSxPQUFNO0FBQ3ZDLGlCQUFTLEtBQUssSUFBSSxHQUFHLElBQUksVUFBVSxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUFBLE1BQ2xEO0FBQ0osTUFBRyxTQUFTLE1BQU0sVUFBUSxZQUFXO0FBQUMsVUFBTSxRQUFNO0FBQVMsVUFBTTtBQUFFO0FBQUEsRUFBTztBQUMxRSxNQUFHLENBQUMsU0FBUyxRQUFPO0FBQUMsVUFBTSxZQUFVLGVBQWUsS0FBSSxNQUFLLFFBQU8sY0FBYSxJQUFJO0FBQUUsV0FBTSxFQUFDLFFBQU8sYUFBYSxDQUFDLEdBQUUsU0FBUSxDQUFDLENBQUMsYUFBYSxZQUFZLGVBQWM7QUFBQSxFQUFFO0FBQ3hLLE1BQUksT0FBTyxPQUFPLFFBQU0sSUFBSSxVQUFVLE9BQU8sV0FBUyxVQUFTLFVBQVEsT0FBTyxXQUFTLEdBQUUsVUFBUSxPQUFNLFVBQThCLFdBQVM7QUFJOUksUUFBTSxRQUFRLENBQUMsSUFBWSxVQUFrQixHQUF5QixJQUFZLFFBQWdCLE1BQWlCLE9BQWUsU0FBd0I7QUFDeEosVUFBTSxRQUFRLFdBQVc7QUFDekIsUUFBSSxTQUFTLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFO0FBQy9CO0FBQ0YsUUFBSSxDQUFDLEtBQUssS0FBSztBQUNiLFdBQUssS0FBSyxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUk7QUFDcEQsUUFBSSxLQUFLLEtBQUssTUFBTTtBQUNsQjtBQUNGLFVBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLEdBQUcsTUFBTSxPQUFPLFFBQVEsT0FBTyxPQUFNLFFBQVEsTUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLFFBQVEsSUFBSSxJQUFJLE9BQU0sUUFBUTtBQUNoSixRQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsR0FBSSxFQUFDLEdBQUUsSUFBRyxHQUFFLElBQUcsU0FBUyxLQUFLLGFBQVksTUFBSyxDQUFDO0FBQzdFO0FBQ0YsWUFBUSxJQUFJLE9BQU8sRUFBRTtBQUNyQixhQUFTLEtBQUssSUFBSSxPQUFPLFFBQVEsVUFBVSxJQUFJLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDeEQ7QUFDQSxTQUFPLFNBQVMsUUFBUTtBQUN0QixRQUFHLFNBQVMsYUFBVyxZQUFVLE9BQUssTUFBSztBQUFDLFlBQU0sT0FBSztBQUFLLFVBQUcsT0FBTyxTQUFTLE9BQU8sRUFBRSxPQUFNLFVBQVE7QUFBUSxZQUFNLFVBQVE7QUFBUSxZQUFNO0FBQUU7QUFBQSxJQUFPO0FBQ25KLFVBQU0sS0FBSyxTQUFTLElBQUk7QUFDeEIsVUFBTSxXQUFXLEtBQUssRUFBRTtBQUN4QixRQUFJLFNBQVMsZUFBZTtBQUMxQjtBQUNGLFVBQU0sSUFBSSxLQUFLLFlBQVksT0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLEdBQUcsSUFBSSxPQUFPLFFBQVEsTUFBTSxJQUFJLEtBQUssTUFBTSxPQUFPLFFBQVEsSUFBSTtBQUMxSCxVQUFNLE1BQU0sSUFBRSxPQUFJLFFBQVEsTUFBTSxNQUFNLElBQUUsT0FBSSxRQUFRO0FBQ3BELFVBQU0sSUFBSSxZQUFZLFNBQVksRUFBQyxHQUFFLElBQUcsR0FBRSxJQUFHLFNBQVEsSUFBRSxNQUFLO0FBQzVEO0FBQ0EsUUFBRyxFQUFFLFVBQVEsUUFBTztBQUFDLGFBQUs7QUFBRyxnQkFBUTtBQUFLO0FBQUEsSUFBTTtBQUNoRCxVQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxDQUFDO0FBQ25ELFFBQUksTUFBTSxXQUFZLFFBQVEsV0FBVyxLQUFLLEVBQUUsS0FBSyxPQUFPLElBQUksV0FBVyxLQUFLLElBQUksSUFBSztBQUN2RixhQUFPO0FBQ1AsZ0JBQVU7QUFBQSxJQUNaO0FBQ0EsUUFBRyxPQUFLLFFBQVEsT0FBSyxLQUFJO0FBQ3ZCLFlBQU0sS0FBSyxLQUFLLEVBQUMsR0FBRSxJQUFHLEdBQUUsSUFBRyxTQUFRLElBQUUsTUFBSztBQUMxQyxZQUFNLGFBQVcsY0FBYyxLQUFJLE1BQUssSUFBRyxhQUFZLFlBQVksS0FBSyxPQUFPLEVBQUU7QUFDakYsVUFBRyxZQUFXO0FBQUMsZUFBSztBQUFHLG1CQUFTO0FBQVc7QUFBQSxNQUFNO0FBQUEsSUFDbkQ7QUFDQSxVQUFNLElBQUksVUFBVSxHQUFHLE9BQU8sY0FBYyxJQUFJLEtBQUssWUFBWSxRQUFRLFdBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLLE1BQU0sQ0FBQyxFQUFHLENBQUMsQ0FBRTtBQUMxSCxVQUFNLElBQUksVUFBVSxHQUFHLE9BQU8sY0FBYyxJQUFJLGFBQWEsS0FBSyxZQUFZLFFBQVEsV0FBVyxLQUFLLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLENBQUMsRUFBRyxDQUFDLENBQUU7QUFFM0ksZUFBVyxZQUFZLENBQUMsR0FBRSxDQUFDLEdBQUc7QUFHNUIsWUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLE9BQU8sSUFBSSxXQUFXLEtBQUssVUFBVSxHQUFJLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSTtBQUNoRixVQUFHLFVBQVUsYUFBVyxHQUFFO0FBQ3hCLGNBQU0sTUFBSSxLQUFHLE9BQUksUUFBUSxPQUFLLE1BQU0sR0FBRSxNQUFJLEtBQUcsT0FBSSxRQUFRLE9BQUssTUFBTTtBQUNwRSxZQUFHLEtBQUssSUFBSSxFQUFFLElBQUUsVUFBVSxLQUFLLElBQUksRUFBRSxJQUFFLFVBQVUsS0FBSyxNQUFNLElBQUcsRUFBRSxJQUFFLE9BQU87QUFBQSxNQUM1RTtBQUNBLFVBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVE7QUFDMUQsY0FBTSxJQUFJLFVBQVUsSUFBSSxLQUFLLFFBQVEsT0FBTyxNQUFNLGFBQWEsR0FBRyxhQUFXLElBQUUsWUFBWSxDQUFDLEVBQUcsVUFBUSxZQUFZLENBQUMsRUFBRyxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUksVUFBVSxLQUFLLE1BQU0sQ0FBQyxFQUFHLFdBQVcsQ0FBQyxDQUFFO0FBQUEsSUFDaE07QUFBQSxFQUNGO0FBQ0EsTUFBRyxNQUFNLE9BQU0sVUFBUTtBQUN2QixNQUFJLE9BQU87QUFDVCxXQUFPLEVBQUMsUUFBTyxDQUFDLEdBQUUsU0FBUSxNQUFLO0FBQ2pDLFFBQU0sT0FBbUIsQ0FBQztBQUMxQixXQUFTLEtBQUssTUFBTSxNQUFNLEdBQUcsS0FBSyxTQUFTLEVBQUU7QUFDM0MsU0FBSyxLQUFLLEtBQUssRUFBRSxDQUFDO0FBQ3BCLE9BQUssUUFBUTtBQUNiLFFBQU0sT0FBSyxLQUFLLENBQUM7QUFDakIsUUFBTSxVQUFRLEtBQUssTUFBTSxLQUFLLElBQUUsUUFBUSxJQUFJLElBQUUsUUFBUSxPQUFLLEtBQUssTUFBTSxLQUFLLElBQUUsUUFBUSxJQUFJLEtBQUcsYUFBVyxLQUFLLE1BQU0sS0FBSyxVQUFRLEtBQUssSUFBRTtBQUN0SSxRQUFNLFNBQU8sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUk7QUFDMUMsT0FBSyxPQUFPLEdBQUUsR0FBRSxHQUFHLE1BQU07QUFDekIsTUFBRyxTQUFTLE1BQUssS0FBSyxHQUFHLFFBQVE7QUFDakMsTUFBRyxDQUFDLFlBQVksa0JBQWtCLENBQUMsU0FBUTtBQUl6QyxRQUFHLE9BQU07QUFDUCxZQUFNLFFBQU07QUFBVyxZQUFNLE9BQUs7QUFBSyxZQUFNLFdBQVMsRUFBQyxPQUFNLFVBQVM7QUFBRSxZQUFNLFdBQVM7QUFDdkYsYUFBTyxNQUFNO0FBQU0sYUFBTyxNQUFNO0FBQVksYUFBTyxNQUFNO0FBQUssYUFBTyxNQUFNO0FBQVMsYUFBTyxNQUFNO0FBQ2pHLGFBQU8sTUFBTTtBQUFLLGFBQU8sTUFBTTtBQUFRLGFBQU8sTUFBTTtBQUFRLGFBQU8sTUFBTTtBQUN6RTtBQUFBLElBQ0Y7QUFDQSxVQUFNLGVBQWEsY0FBYyxLQUFJLE1BQUssTUFBSyxRQUFVLFVBQVMsTUFBTSxHQUFFLE1BQUksS0FBSyxHQUFHLEVBQUUsS0FBSyxPQUFNLFdBQVMsYUFBYSxPQUFPLEdBQUcsRUFBRSxLQUFLO0FBQzFJLGNBQVEsYUFBYSxXQUFXLEtBQUssTUFBTSxJQUFJLElBQUUsU0FBUyxHQUFFLElBQUksSUFBRSxTQUFTLENBQUMsSUFBRTtBQUFBLEVBQ2hGO0FBQ0EsU0FBTyxFQUFDLFFBQU8sTUFBSyxTQUFRLFdBQVcsU0FBUTtBQUNqRDsiLCJuYW1lcyI6WyJ3IiwicG9zZSIsInRhcmdldCIsImRlc3RpbmF0aW9uIiwicHJlZml4Il19