import { SHIP_CAMERA, localToWorld, shipProfile, shipScale } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { installedWeapons, mountedWeaponPose } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-equipment.ts";
export function drawCanvasShip(ctx, ship, at, items, afterDeck) {
  const profile = shipProfile(ship);
  if (!profile) return;
  const scale = shipScale(ship), height = deckVisualHeight(ship);
  const project = (p) => {
    const world = localToWorld(ship, p);
    return { x: at.x + world.x - ship.x, y: at.y + world.y - ship.y - height };
  };
  const polygon = (points, fill) => {
    ctx.beginPath();
    for (const [i, p] of points.entries()) {
      const q = project(p);
      i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
    }
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.stroke();
  };
  ctx.save();
  ctx.strokeStyle = "#8b7350";
  ctx.lineWidth = 2;
  polygon(profile.hull, "#302a20");
  polygon(profile.deck, "#6b5438");
  afterDeck?.();
  for (const [index, obstacle] of profile.obstacles.filter((o) => o.type === "mast").entries()) {
    const p = project(obstacle), mastHeight = ship.kind === "shipOfTheLine" ? ([118, 150, 136][index] ?? 150) * scale : profile.mastHeight;
    ctx.strokeStyle = "#3a3024";
    ctx.lineWidth = 3 * scale;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x, p.y - mastHeight * Math.tan(SHIP_CAMERA.tilt));
    ctx.stroke();
  }
  for (const item of installedWeapons({ items }, ship)) {
    const weapon = mountedWeaponPose(ship, item);
    if (!weapon) continue;
    const p = { x: at.x + weapon.pivot.x - ship.x, y: at.y + weapon.pivot.y - ship.y - weapon.pivotHeight * Math.tan(SHIP_CAMERA.tilt) };
    ctx.globalAlpha = item.durability === 0 ? 0.45 : 1;
    ctx.strokeStyle = weapon.art === "fireShip" ? "#b68349" : "#707c77";
    ctx.lineWidth = 7 * scale;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + Math.cos(weapon.heading) * 18 * scale, p.y + Math.sin(weapon.heading) * 18 * scale);
    ctx.stroke();
  }
  ctx.restore();
}
export function deckVisualHeight(ship) {
  return (shipProfile(ship)?.deckHeight ?? 0) * Math.tan(SHIP_CAMERA.tilt);
}
export function drawShipFlag(ctx, ship, at, color) {
  const profile = shipProfile(ship);
  if (!profile) return;
  const mast = profile.obstacles.filter((o) => o.type === "mast")[ship.kind === "shipOfTheLine" ? 1 : 0];
  if (!mast) return;
  const world = localToWorld(ship, mast), x = at.x + world.x - ship.x, y = at.y + world.y - ship.y - (profile.deckHeight + profile.mastHeight) * Math.tan(SHIP_CAMERA.tilt);
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = "#303536";
  ctx.lineWidth = 0.6;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + 20, y + 3);
  ctx.lineTo(x + 17, y + 14);
  ctx.lineTo(x, y + 11);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbnZhcy1zaGlwcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1NISVBfQ0FNRVJBLGxvY2FsVG9Xb3JsZCxzaGlwUHJvZmlsZSxzaGlwU2NhbGV9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5JztcbmltcG9ydCB7aW5zdGFsbGVkV2VhcG9ucyxtb3VudGVkV2VhcG9uUG9zZX0gZnJvbSAnLi4vLi4vc2hhcmVkL3NoaXAtZXF1aXBtZW50JztcbmltcG9ydCB0eXBlIHtVbml0LFdvcmxkSXRlbX0gZnJvbSAnLi4vLi4vc2hhcmVkL3R5cGVzJztcbnR5cGUgQnJ1c2g9Q2FudmFzUmVuZGVyaW5nQ29udGV4dDJEO1xudHlwZSBQb2ludD17eDpudW1iZXI7eTpudW1iZXJ9O1xuLyoqIExpZ2h0d2VpZ2h0IHBoeXNpY2FsIGh1bGwgZmFsbGJhY2suIEl0IGhhcyBubyBpbWFnZSBhdGxhcyBvciBhc3NldCByZXF1ZXN0cy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkcmF3Q2FudmFzU2hpcChjdHg6QnJ1c2gsc2hpcDpVbml0LGF0OlBvaW50LGl0ZW1zOnJlYWRvbmx5IFdvcmxkSXRlbVtdLGFmdGVyRGVjaz86KCk9PnZvaWQpe1xuICBjb25zdCBwcm9maWxlPXNoaXBQcm9maWxlKHNoaXApO2lmKCFwcm9maWxlKXJldHVybjtcbiAgY29uc3Qgc2NhbGU9c2hpcFNjYWxlKHNoaXApLGhlaWdodD1kZWNrVmlzdWFsSGVpZ2h0KHNoaXApO1xuICBjb25zdCBwcm9qZWN0PShwOlBvaW50KT0+e2NvbnN0IHdvcmxkPWxvY2FsVG9Xb3JsZChzaGlwLHApO3JldHVybnt4OmF0Lngrd29ybGQueC1zaGlwLngseTphdC55K3dvcmxkLnktc2hpcC55LWhlaWdodH07fTtcbiAgY29uc3QgcG9seWdvbj0ocG9pbnRzOnJlYWRvbmx5IFBvaW50W10sZmlsbDpzdHJpbmcpPT57Y3R4LmJlZ2luUGF0aCgpO2Zvcihjb25zdCBbaSxwXSBvZiBwb2ludHMuZW50cmllcygpKXtjb25zdCBxPXByb2plY3QocCk7aT9jdHgubGluZVRvKHEueCxxLnkpOmN0eC5tb3ZlVG8ocS54LHEueSk7fWN0eC5jbG9zZVBhdGgoKTtjdHguZmlsbFN0eWxlPWZpbGw7Y3R4LmZpbGwoKTtjdHguc3Ryb2tlKCk7fTtcbiAgY3R4LnNhdmUoKTtjdHguc3Ryb2tlU3R5bGU9JyM4YjczNTAnO2N0eC5saW5lV2lkdGg9Mjtwb2x5Z29uKHByb2ZpbGUuaHVsbCwnIzMwMmEyMCcpO3BvbHlnb24ocHJvZmlsZS5kZWNrLCcjNmI1NDM4Jyk7XG4gIGFmdGVyRGVjaz8uKCk7XG4gIGZvcihjb25zdCBbaW5kZXgsb2JzdGFjbGVdIG9mIHByb2ZpbGUub2JzdGFjbGVzLmZpbHRlcihvPT5vLnR5cGU9PT0nbWFzdCcpLmVudHJpZXMoKSl7Y29uc3QgcD1wcm9qZWN0KG9ic3RhY2xlKSxtYXN0SGVpZ2h0PXNoaXAua2luZD09PSdzaGlwT2ZUaGVMaW5lJz8oWzExOCwxNTAsMTM2XVtpbmRleF0/PzE1MCkqc2NhbGU6cHJvZmlsZS5tYXN0SGVpZ2h0O2N0eC5zdHJva2VTdHlsZT0nIzNhMzAyNCc7Y3R4LmxpbmVXaWR0aD0zKnNjYWxlO2N0eC5iZWdpblBhdGgoKTtjdHgubW92ZVRvKHAueCxwLnkpO2N0eC5saW5lVG8ocC54LHAueS1tYXN0SGVpZ2h0Kk1hdGgudGFuKFNISVBfQ0FNRVJBLnRpbHQpKTtjdHguc3Ryb2tlKCk7fVxuICBmb3IoY29uc3QgaXRlbSBvZiBpbnN0YWxsZWRXZWFwb25zKHtpdGVtc30sc2hpcCkpe2NvbnN0IHdlYXBvbj1tb3VudGVkV2VhcG9uUG9zZShzaGlwLGl0ZW0pO2lmKCF3ZWFwb24pY29udGludWU7Y29uc3QgcD17eDphdC54K3dlYXBvbi5waXZvdC54LXNoaXAueCx5OmF0Lnkrd2VhcG9uLnBpdm90Lnktc2hpcC55LXdlYXBvbi5waXZvdEhlaWdodCpNYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KX07XG4gICAgY3R4Lmdsb2JhbEFscGhhPWl0ZW0uZHVyYWJpbGl0eT09PTA/LjQ1OjE7Y3R4LnN0cm9rZVN0eWxlPXdlYXBvbi5hcnQ9PT0nZmlyZVNoaXAnPycjYjY4MzQ5JzonIzcwN2M3Nyc7Y3R4LmxpbmVXaWR0aD03KnNjYWxlO2N0eC5iZWdpblBhdGgoKTtjdHgubW92ZVRvKHAueCxwLnkpO2N0eC5saW5lVG8ocC54K01hdGguY29zKHdlYXBvbi5oZWFkaW5nKSoxOCpzY2FsZSxwLnkrTWF0aC5zaW4od2VhcG9uLmhlYWRpbmcpKjE4KnNjYWxlKTtjdHguc3Ryb2tlKCk7XG4gIH1cbiAgY3R4LnJlc3RvcmUoKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBkZWNrVmlzdWFsSGVpZ2h0KHNoaXA6VW5pdCl7cmV0dXJuIChzaGlwUHJvZmlsZShzaGlwKT8uZGVja0hlaWdodCA/PyAwKSpNYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KTt9XG5leHBvcnQgZnVuY3Rpb24gZHJhd1NoaXBGbGFnKGN0eDpCcnVzaCxzaGlwOlVuaXQsYXQ6UG9pbnQsY29sb3I6c3RyaW5nKSB7XG4gIGNvbnN0IHByb2ZpbGU9c2hpcFByb2ZpbGUoc2hpcCk7aWYoIXByb2ZpbGUpcmV0dXJuO1xuICBjb25zdCBtYXN0PXByb2ZpbGUub2JzdGFjbGVzLmZpbHRlcihvPT5vLnR5cGU9PT1cIm1hc3RcIilbc2hpcC5raW5kPT09J3NoaXBPZlRoZUxpbmUnPzE6MF07aWYoIW1hc3QpcmV0dXJuO1xuICBjb25zdCB3b3JsZD1sb2NhbFRvV29ybGQoc2hpcCxtYXN0KSx4PWF0Lngrd29ybGQueC1zaGlwLngseT1hdC55K3dvcmxkLnktc2hpcC55LShwcm9maWxlLmRlY2tIZWlnaHQrcHJvZmlsZS5tYXN0SGVpZ2h0KSpNYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KTtcbiAgY3R4LnNhdmUoKTtjdHguZmlsbFN0eWxlPWNvbG9yO2N0eC5zdHJva2VTdHlsZT1cIiMzMDM1MzZcIjtjdHgubGluZVdpZHRoPS42O1xuICBjdHguYmVnaW5QYXRoKCk7Y3R4Lm1vdmVUbyh4LHkpO2N0eC5saW5lVG8oeCsyMCx5KzMpO2N0eC5saW5lVG8oeCsxNyx5KzE0KTtjdHgubGluZVRvKHgseSsxMSk7Y3R4LmNsb3NlUGF0aCgpO2N0eC5maWxsKCk7Y3R4LnN0cm9rZSgpO2N0eC5yZXN0b3JlKCk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVEsYUFBWSxjQUFhLGFBQVksaUJBQWdCO0FBQzdELFNBQVEsa0JBQWlCLHlCQUF3QjtBQUsxQyxnQkFBUyxlQUFlLEtBQVUsTUFBVSxJQUFTLE9BQTJCLFdBQW9CO0FBQ3pHLFFBQU0sVUFBUSxZQUFZLElBQUk7QUFBRSxNQUFHLENBQUMsUUFBUTtBQUM1QyxRQUFNLFFBQU0sVUFBVSxJQUFJLEdBQUUsU0FBTyxpQkFBaUIsSUFBSTtBQUN4RCxRQUFNLFVBQVEsQ0FBQyxNQUFVO0FBQUMsVUFBTSxRQUFNLGFBQWEsTUFBSyxDQUFDO0FBQUUsV0FBTSxFQUFDLEdBQUUsR0FBRyxJQUFFLE1BQU0sSUFBRSxLQUFLLEdBQUUsR0FBRSxHQUFHLElBQUUsTUFBTSxJQUFFLEtBQUssSUFBRSxPQUFNO0FBQUEsRUFBRTtBQUN0SCxRQUFNLFVBQVEsQ0FBQyxRQUF3QixTQUFjO0FBQUMsUUFBSSxVQUFVO0FBQUUsZUFBVSxDQUFDLEdBQUUsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFFO0FBQUMsWUFBTSxJQUFFLFFBQVEsQ0FBQztBQUFFLFVBQUUsSUFBSSxPQUFPLEVBQUUsR0FBRSxFQUFFLENBQUMsSUFBRSxJQUFJLE9BQU8sRUFBRSxHQUFFLEVBQUUsQ0FBQztBQUFBLElBQUU7QUFBQyxRQUFJLFVBQVU7QUFBRSxRQUFJLFlBQVU7QUFBSyxRQUFJLEtBQUs7QUFBRSxRQUFJLE9BQU87QUFBQSxFQUFFO0FBQ3BPLE1BQUksS0FBSztBQUFFLE1BQUksY0FBWTtBQUFVLE1BQUksWUFBVTtBQUFFLFVBQVEsUUFBUSxNQUFLLFNBQVM7QUFBRSxVQUFRLFFBQVEsTUFBSyxTQUFTO0FBQ25ILGNBQVk7QUFDWixhQUFVLENBQUMsT0FBTSxRQUFRLEtBQUssUUFBUSxVQUFVLE9BQU8sT0FBRyxFQUFFLFNBQU8sTUFBTSxFQUFFLFFBQVEsR0FBRTtBQUFDLFVBQU0sSUFBRSxRQUFRLFFBQVEsR0FBRSxhQUFXLEtBQUssU0FBTyxtQkFBaUIsQ0FBQyxLQUFJLEtBQUksR0FBRyxFQUFFLEtBQUssS0FBRyxPQUFLLFFBQU0sUUFBUTtBQUFXLFFBQUksY0FBWTtBQUFVLFFBQUksWUFBVSxJQUFFO0FBQU0sUUFBSSxVQUFVO0FBQUUsUUFBSSxPQUFPLEVBQUUsR0FBRSxFQUFFLENBQUM7QUFBRSxRQUFJLE9BQU8sRUFBRSxHQUFFLEVBQUUsSUFBRSxhQUFXLEtBQUssSUFBSSxZQUFZLElBQUksQ0FBQztBQUFFLFFBQUksT0FBTztBQUFBLEVBQUU7QUFDdlcsYUFBVSxRQUFRLGlCQUFpQixFQUFDLE1BQUssR0FBRSxJQUFJLEdBQUU7QUFBQyxVQUFNLFNBQU8sa0JBQWtCLE1BQUssSUFBSTtBQUFFLFFBQUcsQ0FBQyxPQUFPO0FBQVMsVUFBTSxJQUFFLEVBQUMsR0FBRSxHQUFHLElBQUUsT0FBTyxNQUFNLElBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRyxJQUFFLE9BQU8sTUFBTSxJQUFFLEtBQUssSUFBRSxPQUFPLGNBQVksS0FBSyxJQUFJLFlBQVksSUFBSSxFQUFDO0FBQzlOLFFBQUksY0FBWSxLQUFLLGVBQWEsSUFBRSxPQUFJO0FBQUUsUUFBSSxjQUFZLE9BQU8sUUFBTSxhQUFXLFlBQVU7QUFBVSxRQUFJLFlBQVUsSUFBRTtBQUFNLFFBQUksVUFBVTtBQUFFLFFBQUksT0FBTyxFQUFFLEdBQUUsRUFBRSxDQUFDO0FBQUUsUUFBSSxPQUFPLEVBQUUsSUFBRSxLQUFLLElBQUksT0FBTyxPQUFPLElBQUUsS0FBRyxPQUFNLEVBQUUsSUFBRSxLQUFLLElBQUksT0FBTyxPQUFPLElBQUUsS0FBRyxLQUFLO0FBQUUsUUFBSSxPQUFPO0FBQUEsRUFDclE7QUFDQSxNQUFJLFFBQVE7QUFDZDtBQUNPLGdCQUFTLGlCQUFpQixNQUFVO0FBQUMsVUFBUSxZQUFZLElBQUksR0FBRyxjQUFjLEtBQUcsS0FBSyxJQUFJLFlBQVksSUFBSTtBQUFFO0FBQzVHLGdCQUFTLGFBQWEsS0FBVSxNQUFVLElBQVMsT0FBYztBQUN0RSxRQUFNLFVBQVEsWUFBWSxJQUFJO0FBQUUsTUFBRyxDQUFDLFFBQVE7QUFDNUMsUUFBTSxPQUFLLFFBQVEsVUFBVSxPQUFPLE9BQUcsRUFBRSxTQUFPLE1BQU0sRUFBRSxLQUFLLFNBQU8sa0JBQWdCLElBQUUsQ0FBQztBQUFFLE1BQUcsQ0FBQyxLQUFLO0FBQ2xHLFFBQU0sUUFBTSxhQUFhLE1BQUssSUFBSSxHQUFFLElBQUUsR0FBRyxJQUFFLE1BQU0sSUFBRSxLQUFLLEdBQUUsSUFBRSxHQUFHLElBQUUsTUFBTSxJQUFFLEtBQUssS0FBRyxRQUFRLGFBQVcsUUFBUSxjQUFZLEtBQUssSUFBSSxZQUFZLElBQUk7QUFDakosTUFBSSxLQUFLO0FBQUUsTUFBSSxZQUFVO0FBQU0sTUFBSSxjQUFZO0FBQVUsTUFBSSxZQUFVO0FBQ3ZFLE1BQUksVUFBVTtBQUFFLE1BQUksT0FBTyxHQUFFLENBQUM7QUFBRSxNQUFJLE9BQU8sSUFBRSxJQUFHLElBQUUsQ0FBQztBQUFFLE1BQUksT0FBTyxJQUFFLElBQUcsSUFBRSxFQUFFO0FBQUUsTUFBSSxPQUFPLEdBQUUsSUFBRSxFQUFFO0FBQUUsTUFBSSxVQUFVO0FBQUUsTUFBSSxLQUFLO0FBQUUsTUFBSSxPQUFPO0FBQUUsTUFBSSxRQUFRO0FBQ3BKOyIsIm5hbWVzIjpbXX0=