import { UNIT_DEFS } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/catalog.ts";
import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { releasePoseForEffect } from "/@fs/tmp/sketch-queue-source-42bd/src/client/unit-animation.ts";
import { projectActionFrame, projectPaperDirection } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/action-direction.ts";
import { resolveReleaseSocket } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/release-socket.ts";
import { appearanceFor, appearanceForKind, corpseAppearanceFor } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/unit-appearance.ts";
import { unitGlyphScale } from "/@fs/tmp/sketch-queue-source-42bd/src/client/glyphs.ts";
export class ProjectileOriginTracker {
  origins = /* @__PURE__ */ new Map();
  tick = -1;
  snapshot;
  effects;
  effectCount = -1;
  reset() {
    this.origins.clear();
    this.tick = -1;
    this.snapshot = void 0;
    this.effects = void 0;
    this.effectCount = -1;
  }
  update(snapshot, models, facing) {
    if (snapshot === this.snapshot && snapshot.tick === this.tick && snapshot.effects === this.effects && snapshot.effects.length === this.effectCount) return;
    if (snapshot.tick < this.tick) this.reset();
    this.tick = snapshot.tick;
    this.snapshot = snapshot;
    this.effects = snapshot.effects;
    this.effectCount = snapshot.effects.length;
    const active = /* @__PURE__ */ new Set();
    let units;
    for (const effect of snapshot.effects) {
      if (effect.type !== "projectile") continue;
      active.add(effect.id);
      if (this.origins.has(effect.id)) continue;
      const pose = releasePoseForEffect(effect);
      if (!pose || effect.fromX === void 0 || effect.fromY === void 0) {
        this.origins.set(effect.id, void 0);
        continue;
      }
      units ??= new Map(snapshot.units.map((unit2) => [unit2.id, unit2]));
      const unit = effect.sourceId ? units.get(effect.sourceId) : void 0;
      const corpse = !unit && effect.sourceId ? snapshot.corpses?.find((corpse2) => corpse2.unitId === effect.sourceId) : void 0;
      if (!unit && !corpse?.deck && (effect.fromHeight ?? 0) !== 0) {
        this.origins.set(effect.id, void 0);
        continue;
      }
      const kind = unit?.kind ?? corpse?.kind ?? effect.sourceKind;
      if (!kind || !(kind in UNIT_DEFS)) {
        this.origins.set(effect.id, void 0);
        continue;
      }
      const variant = unit?.variant ?? corpse?.variant, model = variant ? models?.(variant) : void 0;
      const radius = unit?.radius ?? corpse?.radius ?? UNIT_DEFS[kind].radius;
      const direction = pose.direction ? projectPaperDirection(pose.direction) : void 0;
      const fallback = effect.sourceId ? facing?.(effect.sourceId) ?? 1 : 1;
      const mirror = direction && Math.abs(direction.x) >= Math.max(1, Math.abs(direction.y) * 0.08) ? direction.x < 0 ? -1 : 1 : fallback;
      const base = appearanceForKind(kind, corpse?.ownerRace ?? snapshot.players[corpse?.owner ?? effect.owner ?? "neutral"]?.race);
      const captured = corpse ? corpseAppearanceFor(snapshot, corpse) : void 0;
      const presentation = unit ? appearanceFor(snapshot, unit) : {
        ...base,
        ...captured?.weapon ? { weapon: captured.weapon } : {},
        ...captured?.shield !== void 0 ? { shield: captured.shield } : {},
        ...captured?.shieldStyle ? { shieldStyle: captured.shieldStyle } : {}
      };
      const socket = resolveReleaseSocket({ kind, pose: projectActionFrame(pose, mirror), radius, presentation, ...model ? { model } : {} });
      if (!socket) {
        this.origins.set(effect.id, void 0);
        continue;
      }
      const tilt = Math.tan(SHIP_CAMERA.tilt), aboard = Boolean(unit?.deck ?? corpse?.deck), floor = (effect.fromHeight ?? 0) - (aboard ? 18 : 0), x = effect.fromX + socket.x * mirror, y = effect.fromY;
      this.origins.set(effect.id, { gpu: { x, y, height: floor + (socket.ground - socket.y) / tilt }, canvas: { x, y, height: floor + ((aboard ? 18 * unitGlyphScale(radius) : 0) - socket.y) / tilt } });
    }
    for (const id of this.origins.keys()) if (!active.has(id)) this.origins.delete(id);
  }
  origin(effect, space = "gpu") {
    return this.origins.get(effect.id)?.[space];
  }
  get size() {
    return this.origins.size;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3RpbGUtb3JpZ2lucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogQ2FwdHVyZSB0aGUgYXV0aG9yZWQgcmVsZWFzZSBzb2NrZXQgb25jZSBwZXIgYWN0dWFsIHByb2plY3RpbGUuIE1vdmVtZW50LFxuICogbGF0ZXIgZ2VhciBjaGFuZ2VzIGFuZCBsYXRlciBhbmltYXRpb24gcG9zZXMgY2Fubm90IHB1bGwgYSBtaXNzaWxlIGJhY2t3YXJkLiAqL1xuaW1wb3J0IHtVTklUX0RFRlN9IGZyb20gJy4uL3NoYXJlZC9jYXRhbG9nJztcbmltcG9ydCB7U0hJUF9DQU1FUkF9IGZyb20gJy4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5JztcbmltcG9ydCB0eXBlIHtHYW1lU25hcHNob3QsVW5pdEtpbmQsV29ybGRFZmZlY3R9IGZyb20gJy4uL3NoYXJlZC90eXBlcyc7XG5pbXBvcnQgdHlwZSB7VW5pdE1vZGVsfSBmcm9tICcuLi9zdG9yeS9jYXN0JztcbmltcG9ydCB7cmVsZWFzZVBvc2VGb3JFZmZlY3R9IGZyb20gJy4vdW5pdC1hbmltYXRpb24nO1xuaW1wb3J0IHtwcm9qZWN0QWN0aW9uRnJhbWUscHJvamVjdFBhcGVyRGlyZWN0aW9ufSBmcm9tICcuL2FydC9hY3Rpb24tZGlyZWN0aW9uJztcbmltcG9ydCB7cmVzb2x2ZVJlbGVhc2VTb2NrZXR9IGZyb20gJy4vYXJ0L3JlbGVhc2Utc29ja2V0JztcbmltcG9ydCB7YXBwZWFyYW5jZUZvcixhcHBlYXJhbmNlRm9yS2luZCxjb3Jwc2VBcHBlYXJhbmNlRm9yfSBmcm9tICcuL2FydC91bml0LWFwcGVhcmFuY2UnO1xuaW1wb3J0IHt1bml0R2x5cGhTY2FsZX0gZnJvbSAnLi9nbHlwaHMnO1xuZXhwb3J0IHR5cGUgUHJvamVjdGlsZU9yaWdpbj17eDpudW1iZXI7eTpudW1iZXI7aGVpZ2h0Om51bWJlcn07XG50eXBlIE9yaWdpbnM9e2dwdTpQcm9qZWN0aWxlT3JpZ2luO2NhbnZhczpQcm9qZWN0aWxlT3JpZ2lufTtcbmV4cG9ydCBjbGFzcyBQcm9qZWN0aWxlT3JpZ2luVHJhY2tlciB7XG4gcHJpdmF0ZSBvcmlnaW5zPW5ldyBNYXA8c3RyaW5nLE9yaWdpbnN8dW5kZWZpbmVkPigpO1xuIHByaXZhdGUgdGljaz0tMTtcbiBwcml2YXRlIHNuYXBzaG90OkdhbWVTbmFwc2hvdHx1bmRlZmluZWQ7XG4gcHJpdmF0ZSBlZmZlY3RzOldvcmxkRWZmZWN0W118dW5kZWZpbmVkO1xuIHByaXZhdGUgZWZmZWN0Q291bnQ9LTE7XG4gcmVzZXQoKXt0aGlzLm9yaWdpbnMuY2xlYXIoKTt0aGlzLnRpY2s9LTE7dGhpcy5zbmFwc2hvdD11bmRlZmluZWQ7dGhpcy5lZmZlY3RzPXVuZGVmaW5lZDt0aGlzLmVmZmVjdENvdW50PS0xO31cbiB1cGRhdGUoc25hcHNob3Q6R2FtZVNuYXBzaG90LG1vZGVscz86KHZhcmlhbnQ6c3RyaW5nKT0+VW5pdE1vZGVsfHVuZGVmaW5lZCxmYWNpbmc/OihpZDpzdHJpbmcpPT4xfC0xKXtcbiAgaWYoc25hcHNob3Q9PT10aGlzLnNuYXBzaG90JiZzbmFwc2hvdC50aWNrPT09dGhpcy50aWNrJiZzbmFwc2hvdC5lZmZlY3RzPT09dGhpcy5lZmZlY3RzJiZzbmFwc2hvdC5lZmZlY3RzLmxlbmd0aD09PXRoaXMuZWZmZWN0Q291bnQpcmV0dXJuO1xuICBpZihzbmFwc2hvdC50aWNrPHRoaXMudGljayl0aGlzLnJlc2V0KCk7dGhpcy50aWNrPXNuYXBzaG90LnRpY2s7dGhpcy5zbmFwc2hvdD1zbmFwc2hvdDt0aGlzLmVmZmVjdHM9c25hcHNob3QuZWZmZWN0czt0aGlzLmVmZmVjdENvdW50PXNuYXBzaG90LmVmZmVjdHMubGVuZ3RoO1xuICBjb25zdCBhY3RpdmU9bmV3IFNldDxzdHJpbmc+KCk7bGV0IHVuaXRzOk1hcDxzdHJpbmcsR2FtZVNuYXBzaG90Wyd1bml0cyddW251bWJlcl0+fHVuZGVmaW5lZDtcbiAgZm9yKGNvbnN0IGVmZmVjdCBvZiBzbmFwc2hvdC5lZmZlY3RzKXtcbiAgIGlmKGVmZmVjdC50eXBlIT09J3Byb2plY3RpbGUnKWNvbnRpbnVlO2FjdGl2ZS5hZGQoZWZmZWN0LmlkKTtpZih0aGlzLm9yaWdpbnMuaGFzKGVmZmVjdC5pZCkpY29udGludWU7XG4gICBjb25zdCBwb3NlPXJlbGVhc2VQb3NlRm9yRWZmZWN0KGVmZmVjdCk7XG4gICBpZighcG9zZXx8ZWZmZWN0LmZyb21YPT09dW5kZWZpbmVkfHxlZmZlY3QuZnJvbVk9PT11bmRlZmluZWQpe3RoaXMub3JpZ2lucy5zZXQoZWZmZWN0LmlkLHVuZGVmaW5lZCk7Y29udGludWU7fVxuICAgdW5pdHM/Pz1uZXcgTWFwKHNuYXBzaG90LnVuaXRzLm1hcCh1bml0PT5bdW5pdC5pZCx1bml0XSkpO1xuICAgY29uc3QgdW5pdD1lZmZlY3Quc291cmNlSWQ/dW5pdHMuZ2V0KGVmZmVjdC5zb3VyY2VJZCk6dW5kZWZpbmVkO1xuICAgY29uc3QgY29ycHNlPSF1bml0JiZlZmZlY3Quc291cmNlSWQ/c25hcHNob3QuY29ycHNlcz8uZmluZChjb3Jwc2U9PmNvcnBzZS51bml0SWQ9PT1lZmZlY3Quc291cmNlSWQpOnVuZGVmaW5lZDtcbiAgIC8vIEhpc3RvcmljYWwgY29ycHNlcyBtYXkgbGFjayBkZWNrIGZhY3RzLiBQcmVzZXJ2ZSB0aGUgZXZlbnQgaGFyZHBvaW50XG4gICAvLyByYXRoZXIgdGhhbiBndWVzc2luZyB3aGV0aGVyIGl0cyBlbGV2YXRpb24gaW5jbHVkZXMgYSBjcmV3IG9mZnNldC5cbiAgIGlmKCF1bml0JiYhY29ycHNlPy5kZWNrJiYoZWZmZWN0LmZyb21IZWlnaHQ/PzApIT09MCl7dGhpcy5vcmlnaW5zLnNldChlZmZlY3QuaWQsdW5kZWZpbmVkKTtjb250aW51ZTt9XG4gICBjb25zdCBraW5kPXVuaXQ/LmtpbmQ/P2NvcnBzZT8ua2luZD8/ZWZmZWN0LnNvdXJjZUtpbmQ7XG4gICBpZigha2luZHx8IShraW5kIGluIFVOSVRfREVGUykpe3RoaXMub3JpZ2lucy5zZXQoZWZmZWN0LmlkLHVuZGVmaW5lZCk7Y29udGludWU7fVxuICAgY29uc3QgdmFyaWFudD11bml0Py52YXJpYW50Pz9jb3Jwc2U/LnZhcmlhbnQsbW9kZWw9dmFyaWFudD9tb2RlbHM/Lih2YXJpYW50KTp1bmRlZmluZWQ7XG4gICBjb25zdCByYWRpdXM9dW5pdD8ucmFkaXVzPz9jb3Jwc2U/LnJhZGl1cz8/VU5JVF9ERUZTW2tpbmQgYXMgVW5pdEtpbmRdLnJhZGl1cztcbiAgIGNvbnN0IGRpcmVjdGlvbj1wb3NlLmRpcmVjdGlvbj9wcm9qZWN0UGFwZXJEaXJlY3Rpb24ocG9zZS5kaXJlY3Rpb24pOnVuZGVmaW5lZDtcbiAgIGNvbnN0IGZhbGxiYWNrPWVmZmVjdC5zb3VyY2VJZD9mYWNpbmc/LihlZmZlY3Quc291cmNlSWQpPz8xOjE7XG4gICBjb25zdCBtaXJyb3I9ZGlyZWN0aW9uJiZNYXRoLmFicyhkaXJlY3Rpb24ueCk+PU1hdGgubWF4KDEsTWF0aC5hYnMoZGlyZWN0aW9uLnkpKi4wOCk/KGRpcmVjdGlvbi54PDA/LTE6MSk6ZmFsbGJhY2s7XG4gICBjb25zdCBiYXNlPWFwcGVhcmFuY2VGb3JLaW5kKGtpbmQgYXMgVW5pdEtpbmQsY29ycHNlPy5vd25lclJhY2U/P3NuYXBzaG90LnBsYXllcnNbY29ycHNlPy5vd25lcj8/ZWZmZWN0Lm93bmVyPz8nbmV1dHJhbCddPy5yYWNlKTtcbiAgIGNvbnN0IGNhcHR1cmVkPWNvcnBzZT9jb3Jwc2VBcHBlYXJhbmNlRm9yKHNuYXBzaG90LGNvcnBzZSk6dW5kZWZpbmVkO1xuICAgLy8gUmV1c2UgZXF1aXBtZW50IGZhY3RzLCBub3QgdGhlIHJlbWFpbnMnIG11dGVkIGNsb3RoIHBhbGV0dGUsIGZvciB0aGVcbiAgIC8vIHN0YW5kaW5nIHJlbGVhc2UgcG9zZS4gRGVhdGggZmFjdHMgYXJlIHRoZSBiZXN0IGF2YWlsYWJsZSBmaXJzdC1zZWVuIGtpdC5cbiAgIGNvbnN0IHByZXNlbnRhdGlvbj11bml0P2FwcGVhcmFuY2VGb3Ioc25hcHNob3QsdW5pdCk6ey4uLmJhc2UsXG4gICAgLi4uKGNhcHR1cmVkPy53ZWFwb24/e3dlYXBvbjpjYXB0dXJlZC53ZWFwb259Ont9KSxcbiAgICAuLi4oY2FwdHVyZWQ/LnNoaWVsZCE9PXVuZGVmaW5lZD97c2hpZWxkOmNhcHR1cmVkLnNoaWVsZH06e30pLFxuICAgIC4uLihjYXB0dXJlZD8uc2hpZWxkU3R5bGU/e3NoaWVsZFN0eWxlOmNhcHR1cmVkLnNoaWVsZFN0eWxlfTp7fSksXG4gICB9O1xuICAgY29uc3Qgc29ja2V0PXJlc29sdmVSZWxlYXNlU29ja2V0KHtraW5kOmtpbmQgYXMgVW5pdEtpbmQscG9zZTpwcm9qZWN0QWN0aW9uRnJhbWUocG9zZSxtaXJyb3IpLHJhZGl1cyxwcmVzZW50YXRpb24sLi4uKG1vZGVsP3ttb2RlbH06e30pfSk7XG4gICBpZighc29ja2V0KXt0aGlzLm9yaWdpbnMuc2V0KGVmZmVjdC5pZCx1bmRlZmluZWQpO2NvbnRpbnVlO31cbiAgIGNvbnN0IHRpbHQ9TWF0aC50YW4oU0hJUF9DQU1FUkEudGlsdCksYWJvYXJkPUJvb2xlYW4odW5pdD8uZGVjaz8/Y29ycHNlPy5kZWNrKSxmbG9vcj0oZWZmZWN0LmZyb21IZWlnaHQ/PzApLShhYm9hcmQ/MTg6MCkseD1lZmZlY3QuZnJvbVgrc29ja2V0LngqbWlycm9yLHk9ZWZmZWN0LmZyb21ZO1xuICAgdGhpcy5vcmlnaW5zLnNldChlZmZlY3QuaWQse2dwdTp7eCx5LGhlaWdodDpmbG9vcisoc29ja2V0Lmdyb3VuZC1zb2NrZXQueSkvdGlsdH0sY2FudmFzOnt4LHksaGVpZ2h0OmZsb29yKygoYWJvYXJkPzE4KnVuaXRHbHlwaFNjYWxlKHJhZGl1cyk6MCktc29ja2V0LnkpL3RpbHR9fSk7XG4gIH1cbiAgZm9yKGNvbnN0IGlkIG9mIHRoaXMub3JpZ2lucy5rZXlzKCkpaWYoIWFjdGl2ZS5oYXMoaWQpKXRoaXMub3JpZ2lucy5kZWxldGUoaWQpO1xuIH1cbiBvcmlnaW4oZWZmZWN0OldvcmxkRWZmZWN0LHNwYWNlOidncHUnfCdjYW52YXMnPSdncHUnKXtyZXR1cm4gdGhpcy5vcmlnaW5zLmdldChlZmZlY3QuaWQpPy5bc3BhY2VdO31cbiBnZXQgc2l6ZSgpe3JldHVybiB0aGlzLm9yaWdpbnMuc2l6ZTt9XG59XG4iXSwibWFwcGluZ3MiOiJBQUVBLFNBQVEsaUJBQWdCO0FBQ3hCLFNBQVEsbUJBQWtCO0FBRzFCLFNBQVEsNEJBQTJCO0FBQ25DLFNBQVEsb0JBQW1CLDZCQUE0QjtBQUN2RCxTQUFRLDRCQUEyQjtBQUNuQyxTQUFRLGVBQWMsbUJBQWtCLDJCQUEwQjtBQUNsRSxTQUFRLHNCQUFxQjtBQUd0QixhQUFNLHdCQUF3QjtBQUFBLEVBQzVCLFVBQVEsb0JBQUksSUFBOEI7QUFBQSxFQUMxQyxPQUFLO0FBQUEsRUFDTDtBQUFBLEVBQ0E7QUFBQSxFQUNBLGNBQVk7QUFBQSxFQUNwQixRQUFPO0FBQUMsU0FBSyxRQUFRLE1BQU07QUFBRSxTQUFLLE9BQUs7QUFBRyxTQUFLLFdBQVM7QUFBVSxTQUFLLFVBQVE7QUFBVSxTQUFLLGNBQVk7QUFBQSxFQUFHO0FBQUEsRUFDN0csT0FBTyxVQUFzQixRQUE4QyxRQUEwQjtBQUNwRyxRQUFHLGFBQVcsS0FBSyxZQUFVLFNBQVMsU0FBTyxLQUFLLFFBQU0sU0FBUyxZQUFVLEtBQUssV0FBUyxTQUFTLFFBQVEsV0FBUyxLQUFLLFlBQVk7QUFDcEksUUFBRyxTQUFTLE9BQUssS0FBSyxLQUFLLE1BQUssTUFBTTtBQUFFLFNBQUssT0FBSyxTQUFTO0FBQUssU0FBSyxXQUFTO0FBQVMsU0FBSyxVQUFRLFNBQVM7QUFBUSxTQUFLLGNBQVksU0FBUyxRQUFRO0FBQ3ZKLFVBQU0sU0FBTyxvQkFBSSxJQUFZO0FBQUUsUUFBSTtBQUNuQyxlQUFVLFVBQVUsU0FBUyxTQUFRO0FBQ3BDLFVBQUcsT0FBTyxTQUFPLGFBQWE7QUFBUyxhQUFPLElBQUksT0FBTyxFQUFFO0FBQUUsVUFBRyxLQUFLLFFBQVEsSUFBSSxPQUFPLEVBQUUsRUFBRTtBQUM1RixZQUFNLE9BQUsscUJBQXFCLE1BQU07QUFDdEMsVUFBRyxDQUFDLFFBQU0sT0FBTyxVQUFRLFVBQVcsT0FBTyxVQUFRLFFBQVU7QUFBQyxhQUFLLFFBQVEsSUFBSSxPQUFPLElBQUcsTUFBUztBQUFFO0FBQUEsTUFBUztBQUM3RyxnQkFBUSxJQUFJLElBQUksU0FBUyxNQUFNLElBQUksQ0FBQUEsVUFBTSxDQUFDQSxNQUFLLElBQUdBLEtBQUksQ0FBQyxDQUFDO0FBQ3hELFlBQU0sT0FBSyxPQUFPLFdBQVMsTUFBTSxJQUFJLE9BQU8sUUFBUSxJQUFFO0FBQ3RELFlBQU0sU0FBTyxDQUFDLFFBQU0sT0FBTyxXQUFTLFNBQVMsU0FBUyxLQUFLLENBQUFDLFlBQVFBLFFBQU8sV0FBUyxPQUFPLFFBQVEsSUFBRTtBQUdwRyxVQUFHLENBQUMsUUFBTSxDQUFDLFFBQVEsU0FBTyxPQUFPLGNBQVksT0FBSyxHQUFFO0FBQUMsYUFBSyxRQUFRLElBQUksT0FBTyxJQUFHLE1BQVM7QUFBRTtBQUFBLE1BQVM7QUFDcEcsWUFBTSxPQUFLLE1BQU0sUUFBTSxRQUFRLFFBQU0sT0FBTztBQUM1QyxVQUFHLENBQUMsUUFBTSxFQUFFLFFBQVEsWUFBVztBQUFDLGFBQUssUUFBUSxJQUFJLE9BQU8sSUFBRyxNQUFTO0FBQUU7QUFBQSxNQUFTO0FBQy9FLFlBQU0sVUFBUSxNQUFNLFdBQVMsUUFBUSxTQUFRLFFBQU0sVUFBUSxTQUFTLE9BQU8sSUFBRTtBQUM3RSxZQUFNLFNBQU8sTUFBTSxVQUFRLFFBQVEsVUFBUSxVQUFVLElBQWdCLEVBQUU7QUFDdkUsWUFBTSxZQUFVLEtBQUssWUFBVSxzQkFBc0IsS0FBSyxTQUFTLElBQUU7QUFDckUsWUFBTSxXQUFTLE9BQU8sV0FBUyxTQUFTLE9BQU8sUUFBUSxLQUFHLElBQUU7QUFDNUQsWUFBTSxTQUFPLGFBQVcsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFHLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxVQUFVLENBQUMsSUFBRSxJQUFHLElBQUcsVUFBVSxJQUFFLElBQUUsS0FBRyxJQUFHO0FBQzFHLFlBQU0sT0FBSyxrQkFBa0IsTUFBaUIsUUFBUSxhQUFXLFNBQVMsUUFBUSxRQUFRLFNBQU8sT0FBTyxTQUFPLFNBQVMsR0FBRyxJQUFJO0FBQy9ILFlBQU0sV0FBUyxTQUFPLG9CQUFvQixVQUFTLE1BQU0sSUFBRTtBQUczRCxZQUFNLGVBQWEsT0FBSyxjQUFjLFVBQVMsSUFBSSxJQUFFO0FBQUEsUUFBQyxHQUFHO0FBQUEsUUFDeEQsR0FBSSxVQUFVLFNBQU8sRUFBQyxRQUFPLFNBQVMsT0FBTSxJQUFFLENBQUM7QUFBQSxRQUMvQyxHQUFJLFVBQVUsV0FBUyxTQUFVLEVBQUMsUUFBTyxTQUFTLE9BQU0sSUFBRSxDQUFDO0FBQUEsUUFDM0QsR0FBSSxVQUFVLGNBQVksRUFBQyxhQUFZLFNBQVMsWUFBVyxJQUFFLENBQUM7QUFBQSxNQUMvRDtBQUNBLFlBQU0sU0FBTyxxQkFBcUIsRUFBQyxNQUFzQixNQUFLLG1CQUFtQixNQUFLLE1BQU0sR0FBRSxRQUFPLGNBQWEsR0FBSSxRQUFNLEVBQUMsTUFBSyxJQUFFLENBQUMsRUFBRSxDQUFDO0FBQ3hJLFVBQUcsQ0FBQyxRQUFPO0FBQUMsYUFBSyxRQUFRLElBQUksT0FBTyxJQUFHLE1BQVM7QUFBRTtBQUFBLE1BQVM7QUFDM0QsWUFBTSxPQUFLLEtBQUssSUFBSSxZQUFZLElBQUksR0FBRSxTQUFPLFFBQVEsTUFBTSxRQUFNLFFBQVEsSUFBSSxHQUFFLFNBQU8sT0FBTyxjQUFZLE1BQUksU0FBTyxLQUFHLElBQUcsSUFBRSxPQUFPLFFBQU0sT0FBTyxJQUFFLFFBQU8sSUFBRSxPQUFPO0FBQ2xLLFdBQUssUUFBUSxJQUFJLE9BQU8sSUFBRyxFQUFDLEtBQUksRUFBQyxHQUFFLEdBQUUsUUFBTyxTQUFPLE9BQU8sU0FBTyxPQUFPLEtBQUcsS0FBSSxHQUFFLFFBQU8sRUFBQyxHQUFFLEdBQUUsUUFBTyxVQUFRLFNBQU8sS0FBRyxlQUFlLE1BQU0sSUFBRSxLQUFHLE9BQU8sS0FBRyxLQUFJLEVBQUMsQ0FBQztBQUFBLElBQ2pLO0FBQ0EsZUFBVSxNQUFNLEtBQUssUUFBUSxLQUFLLEVBQUUsS0FBRyxDQUFDLE9BQU8sSUFBSSxFQUFFLEVBQUUsTUFBSyxRQUFRLE9BQU8sRUFBRTtBQUFBLEVBQzlFO0FBQUEsRUFDQSxPQUFPLFFBQW1CLFFBQXFCLE9BQU07QUFBQyxXQUFPLEtBQUssUUFBUSxJQUFJLE9BQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxFQUFFO0FBQUEsRUFDbEcsSUFBSSxPQUFNO0FBQUMsV0FBTyxLQUFLLFFBQVE7QUFBQSxFQUFLO0FBQ3JDOyIsIm5hbWVzIjpbInVuaXQiLCJjb3Jwc2UiXX0=