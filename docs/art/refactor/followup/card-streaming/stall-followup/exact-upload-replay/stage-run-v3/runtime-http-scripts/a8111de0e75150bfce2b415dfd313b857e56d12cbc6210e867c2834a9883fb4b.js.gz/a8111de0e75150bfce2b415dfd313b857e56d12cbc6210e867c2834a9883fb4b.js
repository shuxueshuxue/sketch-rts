import * as THREE from "/.vite-cache/deps/three.js?v=f4e0d91e";
import { worldModels } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/model-library.ts";
import { installModelPortraits } from "/@fs/tmp/sketch-queue-source-42bd/src/client/model-portraits.ts";
import { createScratchCanvas } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/scratch-canvas.ts";
import { defaultRigPortrait } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/sail-rig.ts";
let geometry = /* @__PURE__ */ new WeakMap(), serial = 0;
const images = /* @__PURE__ */ new Map();
const borrowed = /* @__PURE__ */ new Map(), retired = /* @__PURE__ */ new Set();
function retire(canvas) {
  if (borrowed.has(canvas)) retired.add(canvas);
  else canvas.width = canvas.height = 1;
}
function retain(canvas) {
  borrowed.set(canvas, (borrowed.get(canvas) ?? 0) + 1);
}
function release(canvas) {
  const n = borrowed.get(canvas) ?? 0;
  if (n > 1) {
    borrowed.set(canvas, n - 1);
    return;
  }
  borrowed.delete(canvas);
  if (retired.delete(canvas)) retire(canvas);
}
export function modelPortraitStats() {
  const retained = new Set(images.values()), owned = /* @__PURE__ */ new Set([...retained, ...borrowed.keys(), ...retired]);
  const bytes = (canvases) => {
    let n = 0;
    for (const canvas of canvases) n += canvas.width * canvas.height * 4;
    return n;
  };
  return { entries: images.size, cacheBytes: bytes(retained), borrowedCanvases: borrowed.size, borrowedBytes: bytes(borrowed.keys()), retiredCanvases: retired.size, retiredBytes: bytes(retired), ownedCanvasBytes: bytes(owned) };
}
const sun = new THREE.Vector3(-0.6, 1, 0.6).normalize();
export function currentModelPortrait(key, color) {
  const model = worldModels.portraitModel(key);
  if (!model) return void 0;
  let projectedModel = geometry.get(model);
  if (!projectedModel) {
    const portrait = defaultRigPortrait(model);
    try {
      const portraitModel = portrait.model;
      portraitModel.updateMatrixWorld(true);
      const bounds = new THREE.Box3().setFromObject(portraitModel), center = bounds.getCenter(new THREE.Vector3());
      const camera = new THREE.OrthographicCamera();
      camera.position.copy(center).add(new THREE.Vector3(400, 420, 650));
      camera.lookAt(center);
      camera.updateMatrixWorld(true);
      const faces = [];
      let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
      portraitModel.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        const mesh = object, position = mesh.geometry.getAttribute("position"), index = mesh.geometry.index;
        const count = index?.count ?? position.count, materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        const projected = new THREE.Matrix4().multiplyMatrices(camera.matrixWorldInverse, mesh.matrixWorld);
        const normalMatrix = new THREE.Matrix3().getNormalMatrix(mesh.matrixWorld);
        for (let i = 0; i < count; i += 3) {
          const points = [0, 1, 2].map((n) => mesh.getVertexPosition(index ? index.getX(i + n) : i + n, new THREE.Vector3()));
          const normal = new THREE.Vector3().subVectors(points[1], points[0]).cross(new THREE.Vector3().subVectors(points[2], points[0])).applyNormalMatrix(normalMatrix).normalize();
          const screen = points.map((point) => point.applyMatrix4(projected));
          const group = mesh.geometry.groups.find((group2) => i >= group2.start && i < group2.start + group2.count);
          const material = materials[group?.materialIndex ?? 0];
          const xy = screen.flatMap((point) => {
            left = Math.min(left, point.x);
            right = Math.max(right, point.x);
            top = Math.min(top, -point.y);
            bottom = Math.max(bottom, -point.y);
            return [point.x, -point.y];
          });
          const light = 0.64 + 0.5 * Math.max(0, normal.dot(sun));
          faces.push({ points: xy, depth: screen.reduce((sum, point) => sum + point.z, 0) / 3, ink: `#${material.color.clone().multiplyScalar(light).getHexString(THREE.SRGBColorSpace)}`, team: material.name === "TeamColor", light });
        }
      });
      const scale = 240 / Math.max(right - left, bottom - top), cx = (left + right) / 2, cy = (top + bottom) / 2;
      for (const face of faces) face.points = face.points.map((value, i) => 128 + (value - (i % 2 ? cy : cx)) * scale);
      faces.sort((a, b) => a.depth - b.depth);
      projectedModel = { id: serial++, faces };
      geometry.set(model, projectedModel);
    } finally {
      portrait.dispose();
    }
  }
  const id = `${projectedModel.id}:${color}`, cached = images.get(id);
  if (cached) return cached;
  const canvas = createScratchCanvas(256, 256);
  try {
    const ctx = canvas.getContext("2d");
    const team = new THREE.Color(color), teamInks = /* @__PURE__ */ new Map();
    for (const face of projectedModel.faces) {
      const p = face.points;
      let ink = face.ink;
      if (face.team) {
        ink = teamInks.get(face.light) ?? `#${team.clone().multiplyScalar(face.light).getHexString(THREE.SRGBColorSpace)}`;
        teamInks.set(face.light, ink);
      }
      ctx.fillStyle = ink;
      ctx.beginPath();
      ctx.moveTo(p[0], p[1]);
      ctx.lineTo(p[2], p[3]);
      ctx.lineTo(p[4], p[5]);
      ctx.closePath();
      ctx.fill();
    }
    if (images.size >= 64) {
      const oldest = images.keys().next().value;
      const old = images.get(oldest);
      images.delete(oldest);
      retire(old);
    }
    images.set(id, canvas);
    return canvas;
  } catch (error) {
    retire(canvas);
    throw error;
  }
}
export function activateModelPortraits() {
  installModelPortraits(Object.assign(currentModelPortrait, { retain, release }));
}
export function clearModelPortraits() {
  geometry = /* @__PURE__ */ new WeakMap();
  for (const canvas of images.values()) retire(canvas);
  images.clear();
  installModelPortraits(void 0);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vZGVsLXBvcnRyYWl0cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBUSFJFRSBmcm9tICd0aHJlZSc7XG5pbXBvcnQge3dvcmxkTW9kZWxzfSBmcm9tICcuL21vZGVsLWxpYnJhcnknO1xuaW1wb3J0IHtpbnN0YWxsTW9kZWxQb3J0cmFpdHN9IGZyb20gJy4uL21vZGVsLXBvcnRyYWl0cyc7XG5pbXBvcnQge2NyZWF0ZVNjcmF0Y2hDYW52YXN9IGZyb20gJy4uL2FydC9zY3JhdGNoLWNhbnZhcyc7XG5pbXBvcnQge2RlZmF1bHRSaWdQb3J0cmFpdH0gZnJvbSAnLi9zYWlsLXJpZyc7XG50eXBlIEZhY2U9e3BvaW50czpudW1iZXJbXTtkZXB0aDpudW1iZXI7aW5rOnN0cmluZzt0ZWFtOmJvb2xlYW47bGlnaHQ6bnVtYmVyfTtcbmxldCBnZW9tZXRyeT1uZXcgV2Vha01hcDxUSFJFRS5PYmplY3QzRCx7aWQ6bnVtYmVyO2ZhY2VzOkZhY2VbXX0+KCksc2VyaWFsPTA7XG5jb25zdCBpbWFnZXM9bmV3IE1hcDxzdHJpbmcsSFRNTENhbnZhc0VsZW1lbnQ+KCk7XG5jb25zdCBib3Jyb3dlZD1uZXcgTWFwPEhUTUxDYW52YXNFbGVtZW50LG51bWJlcj4oKSxyZXRpcmVkPW5ldyBTZXQ8SFRNTENhbnZhc0VsZW1lbnQ+KCk7XG5mdW5jdGlvbiByZXRpcmUoY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXtpZihib3Jyb3dlZC5oYXMoY2FudmFzKSlyZXRpcmVkLmFkZChjYW52YXMpO2Vsc2UgY2FudmFzLndpZHRoPWNhbnZhcy5oZWlnaHQ9MTt9XG5mdW5jdGlvbiByZXRhaW4oY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXtib3Jyb3dlZC5zZXQoY2FudmFzLChib3Jyb3dlZC5nZXQoY2FudmFzKT8/MCkrMSk7fVxuZnVuY3Rpb24gcmVsZWFzZShjYW52YXM6SFRNTENhbnZhc0VsZW1lbnQpe2NvbnN0IG49Ym9ycm93ZWQuZ2V0KGNhbnZhcyk/PzA7aWYobj4xKXtib3Jyb3dlZC5zZXQoY2FudmFzLG4tMSk7cmV0dXJuO31ib3Jyb3dlZC5kZWxldGUoY2FudmFzKTtpZihyZXRpcmVkLmRlbGV0ZShjYW52YXMpKXJldGlyZShjYW52YXMpO31cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbFBvcnRyYWl0U3RhdHMoKXtcbiBjb25zdCByZXRhaW5lZD1uZXcgU2V0KGltYWdlcy52YWx1ZXMoKSksb3duZWQ9bmV3IFNldChbLi4ucmV0YWluZWQsLi4uYm9ycm93ZWQua2V5cygpLC4uLnJldGlyZWRdKTtcbiBjb25zdCBieXRlcz0oY2FudmFzZXM6SXRlcmFibGU8SFRNTENhbnZhc0VsZW1lbnQ+KT0+e2xldCBuPTA7Zm9yKGNvbnN0IGNhbnZhcyBvZiBjYW52YXNlcyluKz1jYW52YXMud2lkdGgqY2FudmFzLmhlaWdodCo0O3JldHVybiBuO307XG4gcmV0dXJue2VudHJpZXM6aW1hZ2VzLnNpemUsY2FjaGVCeXRlczpieXRlcyhyZXRhaW5lZCksYm9ycm93ZWRDYW52YXNlczpib3Jyb3dlZC5zaXplLGJvcnJvd2VkQnl0ZXM6Ynl0ZXMoYm9ycm93ZWQua2V5cygpKSxyZXRpcmVkQ2FudmFzZXM6cmV0aXJlZC5zaXplLHJldGlyZWRCeXRlczpieXRlcyhyZXRpcmVkKSxvd25lZENhbnZhc0J5dGVzOmJ5dGVzKG93bmVkKX07XG59XG5jb25zdCBzdW49bmV3IFRIUkVFLlZlY3RvcjMoLS42LDEsLjYpLm5vcm1hbGl6ZSgpO1xuXG4vKiogU21hbGwsIGNhY2hlZCBVSSBwcm9qZWN0aW9ucyBvZiB0aGUgbG9hZGVkIEdMQi4gVGhpcyBuZWVkcyBuZWl0aGVyIGFub3RoZXJcbiAqIFdlYkdMIGNvbnRleHQgbm9yIGEgR1BVIHJlYWRiYWNrIGFuZCByZW1haW5zIHVzYWJsZSBhZnRlciBjb250ZXh0IGxvc3MuICovXG4vKiogQm9ycm93ZWQgZm9yIGltbWVkaWF0ZSBjb25zdW1wdGlvbiBvbmx5LCB1bnRpbCB0aGUgbmV4dCBjYWxsL2NsZWFyLlxuICogUHJvZHVjdGlvbiBjb25zdW1lcnMgdXNlIGRyYXdNb2RlbFBvcnRyYWl0LCB3aGljaCBwaW5zIG5lc3RlZCBkcmF3cy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjdXJyZW50TW9kZWxQb3J0cmFpdChrZXk6c3RyaW5nLGNvbG9yOnN0cmluZyl7XG4gIGNvbnN0IG1vZGVsPXdvcmxkTW9kZWxzLnBvcnRyYWl0TW9kZWwoa2V5KTtpZighbW9kZWwpcmV0dXJuIHVuZGVmaW5lZDtcbiAgbGV0IHByb2plY3RlZE1vZGVsPWdlb21ldHJ5LmdldChtb2RlbCk7XG4gIGlmKCFwcm9qZWN0ZWRNb2RlbCl7XG4gICAgY29uc3QgcG9ydHJhaXQ9ZGVmYXVsdFJpZ1BvcnRyYWl0KG1vZGVsKTtcbiAgICB0cnl7XG4gICAgY29uc3QgcG9ydHJhaXRNb2RlbD1wb3J0cmFpdC5tb2RlbDtcbiAgICBwb3J0cmFpdE1vZGVsLnVwZGF0ZU1hdHJpeFdvcmxkKHRydWUpO1xuICAgIGNvbnN0IGJvdW5kcz1uZXcgVEhSRUUuQm94MygpLnNldEZyb21PYmplY3QocG9ydHJhaXRNb2RlbCksY2VudGVyPWJvdW5kcy5nZXRDZW50ZXIobmV3IFRIUkVFLlZlY3RvcjMoKSk7XG4gICAgY29uc3QgY2FtZXJhPW5ldyBUSFJFRS5PcnRob2dyYXBoaWNDYW1lcmEoKTtjYW1lcmEucG9zaXRpb24uY29weShjZW50ZXIpLmFkZChuZXcgVEhSRUUuVmVjdG9yMyg0MDAsNDIwLDY1MCkpO2NhbWVyYS5sb29rQXQoY2VudGVyKTtjYW1lcmEudXBkYXRlTWF0cml4V29ybGQodHJ1ZSk7XG4gICAgY29uc3QgZmFjZXM6RmFjZVtdPVtdO2xldCBsZWZ0PUluZmluaXR5LHRvcD1JbmZpbml0eSxyaWdodD0tSW5maW5pdHksYm90dG9tPS1JbmZpbml0eTtcbiAgICBwb3J0cmFpdE1vZGVsLnRyYXZlcnNlKG9iamVjdD0+e2lmKCEob2JqZWN0IGluc3RhbmNlb2YgVEhSRUUuTWVzaCkpcmV0dXJuO1xuICAgICAgY29uc3QgbWVzaD1vYmplY3QscG9zaXRpb249bWVzaC5nZW9tZXRyeS5nZXRBdHRyaWJ1dGUoJ3Bvc2l0aW9uJyksaW5kZXg9bWVzaC5nZW9tZXRyeS5pbmRleDtcbiAgICAgIGNvbnN0IGNvdW50PWluZGV4Py5jb3VudD8/cG9zaXRpb24uY291bnQsbWF0ZXJpYWxzPUFycmF5LmlzQXJyYXkobWVzaC5tYXRlcmlhbCk/bWVzaC5tYXRlcmlhbDpbbWVzaC5tYXRlcmlhbF07XG4gICAgICBjb25zdCBwcm9qZWN0ZWQ9bmV3IFRIUkVFLk1hdHJpeDQoKS5tdWx0aXBseU1hdHJpY2VzKGNhbWVyYS5tYXRyaXhXb3JsZEludmVyc2UsbWVzaC5tYXRyaXhXb3JsZCk7XG4gICAgICBjb25zdCBub3JtYWxNYXRyaXg9bmV3IFRIUkVFLk1hdHJpeDMoKS5nZXROb3JtYWxNYXRyaXgobWVzaC5tYXRyaXhXb3JsZCk7XG4gICAgICBmb3IobGV0IGk9MDtpPGNvdW50O2krPTMpe1xuICAgICAgICBjb25zdCBwb2ludHM9WzAsMSwyXS5tYXAobj0+bWVzaC5nZXRWZXJ0ZXhQb3NpdGlvbihpbmRleD9pbmRleC5nZXRYKGkrbik6aStuLG5ldyBUSFJFRS5WZWN0b3IzKCkpKTtcbiAgICAgICAgY29uc3Qgbm9ybWFsPW5ldyBUSFJFRS5WZWN0b3IzKCkuc3ViVmVjdG9ycyhwb2ludHNbMV0hLHBvaW50c1swXSEpLmNyb3NzKG5ldyBUSFJFRS5WZWN0b3IzKCkuc3ViVmVjdG9ycyhwb2ludHNbMl0hLHBvaW50c1swXSEpKS5hcHBseU5vcm1hbE1hdHJpeChub3JtYWxNYXRyaXgpLm5vcm1hbGl6ZSgpO1xuICAgICAgICBjb25zdCBzY3JlZW49cG9pbnRzLm1hcChwb2ludD0+cG9pbnQuYXBwbHlNYXRyaXg0KHByb2plY3RlZCkpO1xuICAgICAgICBjb25zdCBncm91cD1tZXNoLmdlb21ldHJ5Lmdyb3Vwcy5maW5kKChncm91cDp7c3RhcnQ6bnVtYmVyO2NvdW50Om51bWJlcjttYXRlcmlhbEluZGV4PzpudW1iZXJ9KT0+aT49Z3JvdXAuc3RhcnQgJiYgaTxncm91cC5zdGFydCtncm91cC5jb3VudCk7XG4gICAgICAgIGNvbnN0IG1hdGVyaWFsPW1hdGVyaWFsc1tncm91cD8ubWF0ZXJpYWxJbmRleD8/MF0gYXMgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWw7XG4gICAgICAgIGNvbnN0IHh5PXNjcmVlbi5mbGF0TWFwKHBvaW50PT57bGVmdD1NYXRoLm1pbihsZWZ0LHBvaW50LngpO3JpZ2h0PU1hdGgubWF4KHJpZ2h0LHBvaW50LngpO3RvcD1NYXRoLm1pbih0b3AsLXBvaW50LnkpO2JvdHRvbT1NYXRoLm1heChib3R0b20sLXBvaW50LnkpO3JldHVybltwb2ludC54LC1wb2ludC55XTt9KTtcbiAgICAgICAgY29uc3QgbGlnaHQ9LjY0Ky41Kk1hdGgubWF4KDAsbm9ybWFsLmRvdChzdW4pKTtcbiAgICAgICAgZmFjZXMucHVzaCh7cG9pbnRzOnh5LGRlcHRoOnNjcmVlbi5yZWR1Y2UoKHN1bSxwb2ludCk9PnN1bStwb2ludC56LDApLzMsaW5rOmAjJHttYXRlcmlhbC5jb2xvci5jbG9uZSgpLm11bHRpcGx5U2NhbGFyKGxpZ2h0KS5nZXRIZXhTdHJpbmcoVEhSRUUuU1JHQkNvbG9yU3BhY2UpfWAsdGVhbTptYXRlcmlhbC5uYW1lPT09J1RlYW1Db2xvcicsbGlnaHR9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBzY2FsZT0yNDAvTWF0aC5tYXgocmlnaHQtbGVmdCxib3R0b20tdG9wKSxjeD0obGVmdCtyaWdodCkvMixjeT0odG9wK2JvdHRvbSkvMjtcbiAgICBmb3IoY29uc3QgZmFjZSBvZiBmYWNlcylmYWNlLnBvaW50cz1mYWNlLnBvaW50cy5tYXAoKHZhbHVlLGkpPT4xMjgrKHZhbHVlLShpJTI/Y3k6Y3gpKSpzY2FsZSk7XG4gICAgZmFjZXMuc29ydCgoYSxiKT0+YS5kZXB0aC1iLmRlcHRoKTtwcm9qZWN0ZWRNb2RlbD17aWQ6c2VyaWFsKyssZmFjZXN9O2dlb21ldHJ5LnNldChtb2RlbCxwcm9qZWN0ZWRNb2RlbCk7XG4gICAgfWZpbmFsbHl7cG9ydHJhaXQuZGlzcG9zZSgpO31cbiAgfVxuICAvLyBQcm9qZWN0aW9uIGRhdGEgZm9sbG93cyB0aGUgZGVjb2RlZCBvYmplY3QsIHNvIGFuIGV4cGxpY2l0IG1vZGVsIHJlbG9hZFxuICAvLyBjYW5ub3QgcmV1c2Ugb2xkIGdlb21ldHJ5IGFuZCByZWxlYXNpbmcgbW9kZWxzIGFsc28gcmVsZWFzZXMgdGhlaXIgZmFjZXMuXG4gIGNvbnN0IGlkPWAke3Byb2plY3RlZE1vZGVsLmlkfToke2NvbG9yfWAsY2FjaGVkPWltYWdlcy5nZXQoaWQpO2lmKGNhY2hlZClyZXR1cm4gY2FjaGVkO1xuICBjb25zdCBjYW52YXM9Y3JlYXRlU2NyYXRjaENhbnZhcygyNTYsMjU2KTtcbiAgdHJ5e1xuICBjb25zdCBjdHg9Y2FudmFzLmdldENvbnRleHQoJzJkJykhO1xuICBjb25zdCB0ZWFtPW5ldyBUSFJFRS5Db2xvcihjb2xvciksdGVhbUlua3M9bmV3IE1hcDxudW1iZXIsc3RyaW5nPigpO1xuICBmb3IoY29uc3QgZmFjZSBvZiBwcm9qZWN0ZWRNb2RlbC5mYWNlcyl7Y29uc3QgcD1mYWNlLnBvaW50cztsZXQgaW5rPWZhY2UuaW5rO1xuICAgIGlmKGZhY2UudGVhbSl7aW5rPXRlYW1JbmtzLmdldChmYWNlLmxpZ2h0KT8/YCMke3RlYW0uY2xvbmUoKS5tdWx0aXBseVNjYWxhcihmYWNlLmxpZ2h0KS5nZXRIZXhTdHJpbmcoVEhSRUUuU1JHQkNvbG9yU3BhY2UpfWA7dGVhbUlua3Muc2V0KGZhY2UubGlnaHQsaW5rKTt9XG4gICAgY3R4LmZpbGxTdHlsZT1pbms7Y3R4LmJlZ2luUGF0aCgpO2N0eC5tb3ZlVG8ocFswXSEscFsxXSEpO2N0eC5saW5lVG8ocFsyXSEscFszXSEpO2N0eC5saW5lVG8ocFs0XSEscFs1XSEpO2N0eC5jbG9zZVBhdGgoKTtjdHguZmlsbCgpO1xuICB9XG4gIGlmKGltYWdlcy5zaXplPj02NCl7Y29uc3Qgb2xkZXN0PWltYWdlcy5rZXlzKCkubmV4dCgpLnZhbHVlITtjb25zdCBvbGQ9aW1hZ2VzLmdldChvbGRlc3QpITtpbWFnZXMuZGVsZXRlKG9sZGVzdCk7cmV0aXJlKG9sZCk7fWltYWdlcy5zZXQoaWQsY2FudmFzKTtyZXR1cm4gY2FudmFzO1xuICB9Y2F0Y2goZXJyb3Ipe3JldGlyZShjYW52YXMpO3Rocm93IGVycm9yO31cbn1cbmV4cG9ydCBmdW5jdGlvbiBhY3RpdmF0ZU1vZGVsUG9ydHJhaXRzKCl7aW5zdGFsbE1vZGVsUG9ydHJhaXRzKE9iamVjdC5hc3NpZ24oY3VycmVudE1vZGVsUG9ydHJhaXQse3JldGFpbixyZWxlYXNlfSkpO31cbmV4cG9ydCBmdW5jdGlvbiBjbGVhck1vZGVsUG9ydHJhaXRzKCl7Z2VvbWV0cnk9bmV3IFdlYWtNYXAoKTtmb3IoY29uc3QgY2FudmFzIG9mIGltYWdlcy52YWx1ZXMoKSlyZXRpcmUoY2FudmFzKTtpbWFnZXMuY2xlYXIoKTtpbnN0YWxsTW9kZWxQb3J0cmFpdHModW5kZWZpbmVkKTt9XG4iXSwibWFwcGluZ3MiOiJBQUFBLFlBQVksV0FBVztBQUN2QixTQUFRLG1CQUFrQjtBQUMxQixTQUFRLDZCQUE0QjtBQUNwQyxTQUFRLDJCQUEwQjtBQUNsQyxTQUFRLDBCQUF5QjtBQUVqQyxJQUFJLFdBQVMsb0JBQUksUUFBaUQsR0FBRSxTQUFPO0FBQzNFLE1BQU0sU0FBTyxvQkFBSSxJQUE4QjtBQUMvQyxNQUFNLFdBQVMsb0JBQUksSUFBOEIsR0FBRSxVQUFRLG9CQUFJLElBQXVCO0FBQ3RGLFNBQVMsT0FBTyxRQUF5QjtBQUFDLE1BQUcsU0FBUyxJQUFJLE1BQU0sRUFBRSxTQUFRLElBQUksTUFBTTtBQUFBLE1BQU8sUUFBTyxRQUFNLE9BQU8sU0FBTztBQUFFO0FBQ3hILFNBQVMsT0FBTyxRQUF5QjtBQUFDLFdBQVMsSUFBSSxTQUFRLFNBQVMsSUFBSSxNQUFNLEtBQUcsS0FBRyxDQUFDO0FBQUU7QUFDM0YsU0FBUyxRQUFRLFFBQXlCO0FBQUMsUUFBTSxJQUFFLFNBQVMsSUFBSSxNQUFNLEtBQUc7QUFBRSxNQUFHLElBQUUsR0FBRTtBQUFDLGFBQVMsSUFBSSxRQUFPLElBQUUsQ0FBQztBQUFFO0FBQUEsRUFBTztBQUFDLFdBQVMsT0FBTyxNQUFNO0FBQUUsTUFBRyxRQUFRLE9BQU8sTUFBTSxFQUFFLFFBQU8sTUFBTTtBQUFFO0FBQzlLLGdCQUFTLHFCQUFvQjtBQUNuQyxRQUFNLFdBQVMsSUFBSSxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUUsUUFBTSxvQkFBSSxJQUFJLENBQUMsR0FBRyxVQUFTLEdBQUcsU0FBUyxLQUFLLEdBQUUsR0FBRyxPQUFPLENBQUM7QUFDakcsUUFBTSxRQUFNLENBQUMsYUFBdUM7QUFBQyxRQUFJLElBQUU7QUFBRSxlQUFVLFVBQVUsU0FBUyxNQUFHLE9BQU8sUUFBTSxPQUFPLFNBQU87QUFBRSxXQUFPO0FBQUEsRUFBRTtBQUNuSSxTQUFNLEVBQUMsU0FBUSxPQUFPLE1BQUssWUFBVyxNQUFNLFFBQVEsR0FBRSxrQkFBaUIsU0FBUyxNQUFLLGVBQWMsTUFBTSxTQUFTLEtBQUssQ0FBQyxHQUFFLGlCQUFnQixRQUFRLE1BQUssY0FBYSxNQUFNLE9BQU8sR0FBRSxrQkFBaUIsTUFBTSxLQUFLLEVBQUM7QUFDak47QUFDQSxNQUFNLE1BQUksSUFBSSxNQUFNLFFBQVEsTUFBSSxHQUFFLEdBQUUsRUFBRSxVQUFVO0FBTXpDLGdCQUFTLHFCQUFxQixLQUFXLE9BQWE7QUFDM0QsUUFBTSxRQUFNLFlBQVksY0FBYyxHQUFHO0FBQUUsTUFBRyxDQUFDLE1BQU0sUUFBTztBQUM1RCxNQUFJLGlCQUFlLFNBQVMsSUFBSSxLQUFLO0FBQ3JDLE1BQUcsQ0FBQyxnQkFBZTtBQUNqQixVQUFNLFdBQVMsbUJBQW1CLEtBQUs7QUFDdkMsUUFBRztBQUNILFlBQU0sZ0JBQWMsU0FBUztBQUM3QixvQkFBYyxrQkFBa0IsSUFBSTtBQUNwQyxZQUFNLFNBQU8sSUFBSSxNQUFNLEtBQUssRUFBRSxjQUFjLGFBQWEsR0FBRSxTQUFPLE9BQU8sVUFBVSxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQ3RHLFlBQU0sU0FBTyxJQUFJLE1BQU0sbUJBQW1CO0FBQUUsYUFBTyxTQUFTLEtBQUssTUFBTSxFQUFFLElBQUksSUFBSSxNQUFNLFFBQVEsS0FBSSxLQUFJLEdBQUcsQ0FBQztBQUFFLGFBQU8sT0FBTyxNQUFNO0FBQUUsYUFBTyxrQkFBa0IsSUFBSTtBQUNoSyxZQUFNLFFBQWEsQ0FBQztBQUFFLFVBQUksT0FBSyxVQUFTLE1BQUksVUFBUyxRQUFNLFdBQVUsU0FBTztBQUM1RSxvQkFBYyxTQUFTLFlBQVE7QUFBQyxZQUFHLEVBQUUsa0JBQWtCLE1BQU0sTUFBTTtBQUNqRSxjQUFNLE9BQUssUUFBTyxXQUFTLEtBQUssU0FBUyxhQUFhLFVBQVUsR0FBRSxRQUFNLEtBQUssU0FBUztBQUN0RixjQUFNLFFBQU0sT0FBTyxTQUFPLFNBQVMsT0FBTSxZQUFVLE1BQU0sUUFBUSxLQUFLLFFBQVEsSUFBRSxLQUFLLFdBQVMsQ0FBQyxLQUFLLFFBQVE7QUFDNUcsY0FBTSxZQUFVLElBQUksTUFBTSxRQUFRLEVBQUUsaUJBQWlCLE9BQU8sb0JBQW1CLEtBQUssV0FBVztBQUMvRixjQUFNLGVBQWEsSUFBSSxNQUFNLFFBQVEsRUFBRSxnQkFBZ0IsS0FBSyxXQUFXO0FBQ3ZFLGlCQUFRLElBQUUsR0FBRSxJQUFFLE9BQU0sS0FBRyxHQUFFO0FBQ3ZCLGdCQUFNLFNBQU8sQ0FBQyxHQUFFLEdBQUUsQ0FBQyxFQUFFLElBQUksT0FBRyxLQUFLLGtCQUFrQixRQUFNLE1BQU0sS0FBSyxJQUFFLENBQUMsSUFBRSxJQUFFLEdBQUUsSUFBSSxNQUFNLFFBQVEsQ0FBQyxDQUFDO0FBQ2pHLGdCQUFNLFNBQU8sSUFBSSxNQUFNLFFBQVEsRUFBRSxXQUFXLE9BQU8sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFFLEVBQUUsTUFBTSxJQUFJLE1BQU0sUUFBUSxFQUFFLFdBQVcsT0FBTyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUUsQ0FBQyxFQUFFLGtCQUFrQixZQUFZLEVBQUUsVUFBVTtBQUMxSyxnQkFBTSxTQUFPLE9BQU8sSUFBSSxXQUFPLE1BQU0sYUFBYSxTQUFTLENBQUM7QUFDNUQsZ0JBQU0sUUFBTSxLQUFLLFNBQVMsT0FBTyxLQUFLLENBQUNBLFdBQTBELEtBQUdBLE9BQU0sU0FBUyxJQUFFQSxPQUFNLFFBQU1BLE9BQU0sS0FBSztBQUM1SSxnQkFBTSxXQUFTLFVBQVUsT0FBTyxpQkFBZSxDQUFDO0FBQ2hELGdCQUFNLEtBQUcsT0FBTyxRQUFRLFdBQU87QUFBQyxtQkFBSyxLQUFLLElBQUksTUFBSyxNQUFNLENBQUM7QUFBRSxvQkFBTSxLQUFLLElBQUksT0FBTSxNQUFNLENBQUM7QUFBRSxrQkFBSSxLQUFLLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQztBQUFFLHFCQUFPLEtBQUssSUFBSSxRQUFPLENBQUMsTUFBTSxDQUFDO0FBQUUsbUJBQU0sQ0FBQyxNQUFNLEdBQUUsQ0FBQyxNQUFNLENBQUM7QUFBQSxVQUFFLENBQUM7QUFDaEwsZ0JBQU0sUUFBTSxPQUFJLE1BQUcsS0FBSyxJQUFJLEdBQUUsT0FBTyxJQUFJLEdBQUcsQ0FBQztBQUM3QyxnQkFBTSxLQUFLLEVBQUMsUUFBTyxJQUFHLE9BQU0sT0FBTyxPQUFPLENBQUMsS0FBSSxVQUFRLE1BQUksTUFBTSxHQUFFLENBQUMsSUFBRSxHQUFFLEtBQUksSUFBSSxTQUFTLE1BQU0sTUFBTSxFQUFFLGVBQWUsS0FBSyxFQUFFLGFBQWEsTUFBTSxjQUFjLENBQUMsSUFBRyxNQUFLLFNBQVMsU0FBTyxhQUFZLE1BQUssQ0FBQztBQUFBLFFBQzNNO0FBQUEsTUFDRixDQUFDO0FBQ0QsWUFBTSxRQUFNLE1BQUksS0FBSyxJQUFJLFFBQU0sTUFBSyxTQUFPLEdBQUcsR0FBRSxNQUFJLE9BQUssU0FBTyxHQUFFLE1BQUksTUFBSSxVQUFRO0FBQ2xGLGlCQUFVLFFBQVEsTUFBTSxNQUFLLFNBQU8sS0FBSyxPQUFPLElBQUksQ0FBQyxPQUFNLE1BQUksT0FBSyxTQUFPLElBQUUsSUFBRSxLQUFHLE9BQUssS0FBSztBQUM1RixZQUFNLEtBQUssQ0FBQyxHQUFFLE1BQUksRUFBRSxRQUFNLEVBQUUsS0FBSztBQUFFLHVCQUFlLEVBQUMsSUFBRyxVQUFTLE1BQUs7QUFBRSxlQUFTLElBQUksT0FBTSxjQUFjO0FBQUEsSUFDdkcsVUFBQztBQUFRLGVBQVMsUUFBUTtBQUFBLElBQUU7QUFBQSxFQUM5QjtBQUdBLFFBQU0sS0FBRyxHQUFHLGVBQWUsRUFBRSxJQUFJLEtBQUssSUFBRyxTQUFPLE9BQU8sSUFBSSxFQUFFO0FBQUUsTUFBRyxPQUFPLFFBQU87QUFDaEYsUUFBTSxTQUFPLG9CQUFvQixLQUFJLEdBQUc7QUFDeEMsTUFBRztBQUNILFVBQU0sTUFBSSxPQUFPLFdBQVcsSUFBSTtBQUNoQyxVQUFNLE9BQUssSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFFLFdBQVMsb0JBQUksSUFBbUI7QUFDbEUsZUFBVSxRQUFRLGVBQWUsT0FBTTtBQUFDLFlBQU0sSUFBRSxLQUFLO0FBQU8sVUFBSSxNQUFJLEtBQUs7QUFDdkUsVUFBRyxLQUFLLE1BQUs7QUFBQyxjQUFJLFNBQVMsSUFBSSxLQUFLLEtBQUssS0FBRyxJQUFJLEtBQUssTUFBTSxFQUFFLGVBQWUsS0FBSyxLQUFLLEVBQUUsYUFBYSxNQUFNLGNBQWMsQ0FBQztBQUFHLGlCQUFTLElBQUksS0FBSyxPQUFNLEdBQUc7QUFBQSxNQUFFO0FBQzFKLFVBQUksWUFBVTtBQUFJLFVBQUksVUFBVTtBQUFFLFVBQUksT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRTtBQUFFLFVBQUksT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRTtBQUFFLFVBQUksT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRTtBQUFFLFVBQUksVUFBVTtBQUFFLFVBQUksS0FBSztBQUFBLElBQ3JJO0FBQ0EsUUFBRyxPQUFPLFFBQU0sSUFBRztBQUFDLFlBQU0sU0FBTyxPQUFPLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFBTyxZQUFNLE1BQUksT0FBTyxJQUFJLE1BQU07QUFBRyxhQUFPLE9BQU8sTUFBTTtBQUFFLGFBQU8sR0FBRztBQUFBLElBQUU7QUFBQyxXQUFPLElBQUksSUFBRyxNQUFNO0FBQUUsV0FBTztBQUFBLEVBQzNKLFNBQU8sT0FBTTtBQUFDLFdBQU8sTUFBTTtBQUFFLFVBQU07QUFBQSxFQUFNO0FBQzNDO0FBQ08sZ0JBQVMseUJBQXdCO0FBQUMsd0JBQXNCLE9BQU8sT0FBTyxzQkFBcUIsRUFBQyxRQUFPLFFBQU8sQ0FBQyxDQUFDO0FBQUU7QUFDOUcsZ0JBQVMsc0JBQXFCO0FBQUMsYUFBUyxvQkFBSSxRQUFRO0FBQUUsYUFBVSxVQUFVLE9BQU8sT0FBTyxFQUFFLFFBQU8sTUFBTTtBQUFFLFNBQU8sTUFBTTtBQUFFLHdCQUFzQixNQUFTO0FBQUU7IiwibmFtZXMiOlsiZ3JvdXAiXX0=