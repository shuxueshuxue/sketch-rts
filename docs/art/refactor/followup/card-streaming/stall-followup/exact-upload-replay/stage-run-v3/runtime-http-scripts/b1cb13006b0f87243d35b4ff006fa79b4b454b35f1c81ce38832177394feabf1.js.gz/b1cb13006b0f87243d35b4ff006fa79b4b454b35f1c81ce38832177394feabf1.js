import * as THREE from "/.vite-cache/deps/three.js?v=f4e0d91e";
import { GLTFLoader } from "/.vite-cache/deps/three_addons_loaders_GLTFLoader__js.js?v=f4e0d91e";
import { resources } from "/@fs/tmp/sketch-queue-source-42bd/src/client/resources.ts";
import { isShipKind } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { installedWeapons, mountedWeaponPose } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-equipment.ts";
import { attachShipRigParts } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/sail-rig.ts";
export { SITE_MODELS, MATCH_MODEL_KEYS as matchModelKeys } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/model-manifest.ts";
export function snapshotModelKeys(snapshot) {
  return [.../* @__PURE__ */ new Set([...snapshot.units.filter((unit) => isShipKind(unit.kind)).map((unit) => `ships/${unit.kind}`), ...snapshot.units.filter((unit) => isShipKind(unit.kind)).flatMap((ship) => installedWeapons(snapshot, ship).flatMap((item) => {
    const weapon = mountedWeaponPose(ship, item);
    return weapon ? [`ships/${weapon.art}`] : [];
  })), ...snapshot.buildings.map((building) => `buildings/${building.kind}`), ...snapshot.shops?.length ? ["buildings/shop"] : [], ...snapshot.mercenaryCamps.length ? ["buildings/camp"] : []])];
}
export class ModelLibrary {
  constructor(loader = new GLTFLoader()) {
    this.loader = loader;
  }
  models = /* @__PURE__ */ new Map();
  parts = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  generation = 0;
  async prepare(keys, phase) {
    await Promise.all(keys.map((key) => this.load(key, phase)));
  }
  load(key, phase) {
    const url = resources.url(`art/world3d/${key}.glb`);
    if (this.models.has(key)) {
      resources.recordUse(url, phase);
      return Promise.resolve();
    }
    let pending = this.pending.get(key);
    if (pending) {
      resources.recordUse(url, phase);
      return pending;
    }
    const data = resources.bytes(url, key, phase), generation = this.generation;
    pending = (async () => {
      const bytes = await data;
      if (generation !== this.generation) return;
      const result = await this.loader.parseAsync(bytes, resources.url("art/world3d/"));
      if (generation !== this.generation) {
        disposeModels([result.scene]);
        return;
      }
      try {
        attachShipRigParts(result.scene);
        result.scene.updateMatrixWorld(true);
        const parts = /* @__PURE__ */ new Map();
        result.scene.traverse((object) => {
          if (object.name && !parts.has(object.name)) parts.set(object.name, object);
          if (object instanceof THREE.Mesh) {
            object.castShadow = true;
            object.receiveShadow = true;
          }
        });
        this.models.set(key, result.scene);
        this.parts.set(key, parts);
      } catch (error) {
        disposeModels([result.scene]);
        throw error;
      }
    })().finally(() => {
      if (this.pending.get(key) === pending) this.pending.delete(key);
      resources.releaseBytes(url, data);
    });
    this.pending.set(key, pending);
    return pending;
  }
  component(key, name) {
    const source = this.parts.get(key)?.get(name);
    if (!source) return void 0;
    const object = source.clone(true);
    object.position.set(0, 0, 0);
    object.updateMatrixWorld(true);
    return object;
  }
  portraitModel(key) {
    return this.models.get(key);
  }
  cacheStats() {
    return { models: this.models.size, pending: this.pending.size };
  }
  dispose() {
    this.generation++;
    disposeModels(this.models.values());
    this.models.clear();
    this.parts.clear();
    this.pending.clear();
  }
}
function disposeModels(roots) {
  const geometries = /* @__PURE__ */ new Set(), materials = /* @__PURE__ */ new Set(), textures = /* @__PURE__ */ new Set();
  for (const root of roots) root.traverse((object) => {
    if (object instanceof THREE.Mesh) {
      geometries.add(object.geometry);
      for (const mat of Array.isArray(object.material) ? object.material : [object.material]) materials.add(mat);
    }
  });
  for (const material of materials) {
    for (const value of Object.values(material)) if (value instanceof THREE.Texture) textures.add(value);
    if (material instanceof THREE.ShaderMaterial) {
      for (const uniform of Object.values(material.uniforms)) for (const value of Array.isArray(uniform.value) ? uniform.value : [uniform.value]) if (value instanceof THREE.Texture) textures.add(value);
    }
  }
  const images = /* @__PURE__ */ new Set();
  for (const texture of textures) {
    for (const image of Array.isArray(texture.image) ? texture.image : [texture.image]) if (image && typeof image.close === "function") images.add(image);
    texture.dispose();
  }
  for (const image of images) image.close();
  for (const item of geometries) item.dispose();
  for (const item of materials) item.dispose();
}
export const worldModels = new ModelLibrary();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vZGVsLWxpYnJhcnkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuaW1wb3J0IHsgR0xURkxvYWRlciB9IGZyb20gJ3RocmVlL2FkZG9ucy9sb2FkZXJzL0dMVEZMb2FkZXIuanMnO1xuaW1wb3J0IHsgcmVzb3VyY2VzLHR5cGUgUmVzb3VyY2VQaGFzZSB9IGZyb20gJy4uL3Jlc291cmNlcyc7XG5pbXBvcnQgeyBpc1NoaXBLaW5kIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHsgaW5zdGFsbGVkV2VhcG9ucyxtb3VudGVkV2VhcG9uUG9zZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGlwLWVxdWlwbWVudCc7XG5pbXBvcnQgdHlwZSB7IEdhbWVTbmFwc2hvdCB9IGZyb20gJy4uLy4uL3NoYXJlZC90eXBlcyc7XG5pbXBvcnQgeyBhdHRhY2hTaGlwUmlnUGFydHMgfSBmcm9tICcuL3NhaWwtcmlnJztcblxuZXhwb3J0IHsgU0lURV9NT0RFTFMsIE1BVENIX01PREVMX0tFWVMgYXMgbWF0Y2hNb2RlbEtleXMgfSBmcm9tICcuLi9hcnQvbW9kZWwtbWFuaWZlc3QnO1xuZXhwb3J0IGZ1bmN0aW9uIHNuYXBzaG90TW9kZWxLZXlzKHNuYXBzaG90OkdhbWVTbmFwc2hvdCl7cmV0dXJuIFsuLi5uZXcgU2V0KFsuLi5zbmFwc2hvdC51bml0cy5maWx0ZXIodW5pdD0+aXNTaGlwS2luZCh1bml0LmtpbmQpKS5tYXAodW5pdD0+YHNoaXBzLyR7dW5pdC5raW5kfWApLC4uLnNuYXBzaG90LnVuaXRzLmZpbHRlcih1bml0PT5pc1NoaXBLaW5kKHVuaXQua2luZCkpLmZsYXRNYXAoc2hpcD0+aW5zdGFsbGVkV2VhcG9ucyhzbmFwc2hvdCxzaGlwKS5mbGF0TWFwKGl0ZW09Pntjb25zdCB3ZWFwb249bW91bnRlZFdlYXBvblBvc2Uoc2hpcCxpdGVtKTtyZXR1cm4gd2VhcG9uP1tgc2hpcHMvJHt3ZWFwb24uYXJ0fWBdOltdO30pKSwuLi5zbmFwc2hvdC5idWlsZGluZ3MubWFwKGJ1aWxkaW5nPT5gYnVpbGRpbmdzLyR7YnVpbGRpbmcua2luZH1gKSwuLi4oc25hcHNob3Quc2hvcHM/Lmxlbmd0aD9bJ2J1aWxkaW5ncy9zaG9wJ106W10pLC4uLihzbmFwc2hvdC5tZXJjZW5hcnlDYW1wcy5sZW5ndGg/WydidWlsZGluZ3MvY2FtcCddOltdKV0pXTt9XG5cbmV4cG9ydCBjbGFzcyBNb2RlbExpYnJhcnkge1xuICBwcml2YXRlIG1vZGVscz1uZXcgTWFwPHN0cmluZyxUSFJFRS5PYmplY3QzRD4oKTtcbiAgcHJpdmF0ZSBwYXJ0cz1uZXcgTWFwPHN0cmluZyxNYXA8c3RyaW5nLFRIUkVFLk9iamVjdDNEPj4oKTtcbiAgcHJpdmF0ZSBwZW5kaW5nPW5ldyBNYXA8c3RyaW5nLFByb21pc2U8dm9pZD4+KCk7XG4gIHByaXZhdGUgZ2VuZXJhdGlvbj0wO1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGxvYWRlcjpQaWNrPEdMVEZMb2FkZXIsJ3BhcnNlQXN5bmMnPj1uZXcgR0xURkxvYWRlcigpKXt9XG4gIGFzeW5jIHByZXBhcmUoa2V5czpyZWFkb25seSBzdHJpbmdbXSxwaGFzZTpSZXNvdXJjZVBoYXNlKXthd2FpdCBQcm9taXNlLmFsbChrZXlzLm1hcChrZXk9PnRoaXMubG9hZChrZXkscGhhc2UpKSk7fVxuICBwcml2YXRlIGxvYWQoa2V5OnN0cmluZyxwaGFzZTpSZXNvdXJjZVBoYXNlKXtcbiAgICBjb25zdCB1cmw9cmVzb3VyY2VzLnVybChgYXJ0L3dvcmxkM2QvJHtrZXl9LmdsYmApO1xuICAgIGlmKHRoaXMubW9kZWxzLmhhcyhrZXkpKXtyZXNvdXJjZXMucmVjb3JkVXNlKHVybCxwaGFzZSk7cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO31cbiAgICBsZXQgcGVuZGluZz10aGlzLnBlbmRpbmcuZ2V0KGtleSk7aWYocGVuZGluZyl7cmVzb3VyY2VzLnJlY29yZFVzZSh1cmwscGhhc2UpO3JldHVybiBwZW5kaW5nO31cbiAgICBjb25zdCBkYXRhPXJlc291cmNlcy5ieXRlcyh1cmwsa2V5LHBoYXNlKSxnZW5lcmF0aW9uPXRoaXMuZ2VuZXJhdGlvbjtwZW5kaW5nPShhc3luYygpPT57XG4gICAgICBjb25zdCBieXRlcz1hd2FpdCBkYXRhO1xuICAgICAgLy8gRGlzcG9zYWwgY2FuIGhhcHBlbiB3aGlsZSBlaXRoZXIgdGhlIHJlcXVlc3Qgb3IgcGFyc2luZyBpcyBwZW5kaW5nLlxuICAgICAgaWYoZ2VuZXJhdGlvbiE9PXRoaXMuZ2VuZXJhdGlvbilyZXR1cm47XG4gICAgICBjb25zdCByZXN1bHQ9YXdhaXQgdGhpcy5sb2FkZXIucGFyc2VBc3luYyhieXRlcyxyZXNvdXJjZXMudXJsKCdhcnQvd29ybGQzZC8nKSk7XG4gICAgICBpZihnZW5lcmF0aW9uIT09dGhpcy5nZW5lcmF0aW9uKXtkaXNwb3NlTW9kZWxzKFtyZXN1bHQuc2NlbmVdKTtyZXR1cm47fVxuICAgICAgdHJ5e1xuICAgICAgICBhdHRhY2hTaGlwUmlnUGFydHMocmVzdWx0LnNjZW5lKTtyZXN1bHQuc2NlbmUudXBkYXRlTWF0cml4V29ybGQodHJ1ZSk7XG4gICAgICAgIGNvbnN0IHBhcnRzPW5ldyBNYXA8c3RyaW5nLFRIUkVFLk9iamVjdDNEPigpO1xuICAgICAgICByZXN1bHQuc2NlbmUudHJhdmVyc2Uob2JqZWN0PT57aWYob2JqZWN0Lm5hbWUmJiFwYXJ0cy5oYXMob2JqZWN0Lm5hbWUpKXBhcnRzLnNldChvYmplY3QubmFtZSxvYmplY3QpO2lmKG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLk1lc2gpe29iamVjdC5jYXN0U2hhZG93PXRydWU7b2JqZWN0LnJlY2VpdmVTaGFkb3c9dHJ1ZTt9fSk7XG4gICAgICAgIHRoaXMubW9kZWxzLnNldChrZXkscmVzdWx0LnNjZW5lKTt0aGlzLnBhcnRzLnNldChrZXkscGFydHMpO1xuICAgICAgfWNhdGNoKGVycm9yKXtkaXNwb3NlTW9kZWxzKFtyZXN1bHQuc2NlbmVdKTt0aHJvdyBlcnJvcjt9XG4gICAgfSkoKS5maW5hbGx5KCgpPT57aWYodGhpcy5wZW5kaW5nLmdldChrZXkpPT09cGVuZGluZyl0aGlzLnBlbmRpbmcuZGVsZXRlKGtleSk7cmVzb3VyY2VzLnJlbGVhc2VCeXRlcyh1cmwsZGF0YSk7fSk7dGhpcy5wZW5kaW5nLnNldChrZXkscGVuZGluZyk7cmV0dXJuIHBlbmRpbmc7XG4gIH1cbiAgY29tcG9uZW50KGtleTpzdHJpbmcsbmFtZTpzdHJpbmcpe2NvbnN0IHNvdXJjZT10aGlzLnBhcnRzLmdldChrZXkpPy5nZXQobmFtZSk7aWYoIXNvdXJjZSlyZXR1cm4gdW5kZWZpbmVkO2NvbnN0IG9iamVjdD1zb3VyY2UuY2xvbmUodHJ1ZSk7b2JqZWN0LnBvc2l0aW9uLnNldCgwLDAsMCk7b2JqZWN0LnVwZGF0ZU1hdHJpeFdvcmxkKHRydWUpO3JldHVybiBvYmplY3Q7fVxuICBwb3J0cmFpdE1vZGVsKGtleTpzdHJpbmcpe3JldHVybiB0aGlzLm1vZGVscy5nZXQoa2V5KTt9XG4gIGNhY2hlU3RhdHMoKXtyZXR1cm57bW9kZWxzOnRoaXMubW9kZWxzLnNpemUscGVuZGluZzp0aGlzLnBlbmRpbmcuc2l6ZX07fVxuICBkaXNwb3NlKCl7dGhpcy5nZW5lcmF0aW9uKys7ZGlzcG9zZU1vZGVscyh0aGlzLm1vZGVscy52YWx1ZXMoKSk7dGhpcy5tb2RlbHMuY2xlYXIoKTt0aGlzLnBhcnRzLmNsZWFyKCk7dGhpcy5wZW5kaW5nLmNsZWFyKCk7fVxufVxuZnVuY3Rpb24gZGlzcG9zZU1vZGVscyhyb290czpJdGVyYWJsZTxUSFJFRS5PYmplY3QzRD4pe1xuICBjb25zdCBnZW9tZXRyaWVzPW5ldyBTZXQ8VEhSRUUuQnVmZmVyR2VvbWV0cnk+KCksbWF0ZXJpYWxzPW5ldyBTZXQ8VEhSRUUuTWF0ZXJpYWw+KCksdGV4dHVyZXM9bmV3IFNldDxUSFJFRS5UZXh0dXJlPigpO1xuICBmb3IoY29uc3Qgcm9vdCBvZiByb290cylyb290LnRyYXZlcnNlKG9iamVjdD0+e2lmKG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLk1lc2gpe2dlb21ldHJpZXMuYWRkKG9iamVjdC5nZW9tZXRyeSk7Zm9yKGNvbnN0IG1hdCBvZiBBcnJheS5pc0FycmF5KG9iamVjdC5tYXRlcmlhbCk/b2JqZWN0Lm1hdGVyaWFsOltvYmplY3QubWF0ZXJpYWxdKW1hdGVyaWFscy5hZGQobWF0KTt9fSk7XG4gIGZvcihjb25zdCBtYXRlcmlhbCBvZiBtYXRlcmlhbHMpe1xuICAgIGZvcihjb25zdCB2YWx1ZSBvZiBPYmplY3QudmFsdWVzKG1hdGVyaWFsKSlpZih2YWx1ZSBpbnN0YW5jZW9mIFRIUkVFLlRleHR1cmUpdGV4dHVyZXMuYWRkKHZhbHVlKTtcbiAgICBpZihtYXRlcmlhbCBpbnN0YW5jZW9mIFRIUkVFLlNoYWRlck1hdGVyaWFsKWZvcihjb25zdCB1bmlmb3JtIG9mIE9iamVjdC52YWx1ZXMobWF0ZXJpYWwudW5pZm9ybXMpKWZvcihjb25zdCB2YWx1ZSBvZiBBcnJheS5pc0FycmF5KHVuaWZvcm0udmFsdWUpP3VuaWZvcm0udmFsdWU6W3VuaWZvcm0udmFsdWVdKWlmKHZhbHVlIGluc3RhbmNlb2YgVEhSRUUuVGV4dHVyZSl0ZXh0dXJlcy5hZGQodmFsdWUpO1xuICB9XG4gIGNvbnN0IGltYWdlcz1uZXcgU2V0PHtjbG9zZTooKT0+dm9pZH0+KCk7XG4gIGZvcihjb25zdCB0ZXh0dXJlIG9mIHRleHR1cmVzKXtmb3IoY29uc3QgaW1hZ2Ugb2YgQXJyYXkuaXNBcnJheSh0ZXh0dXJlLmltYWdlKT90ZXh0dXJlLmltYWdlOlt0ZXh0dXJlLmltYWdlXSlpZihpbWFnZSYmdHlwZW9mIGltYWdlLmNsb3NlPT09J2Z1bmN0aW9uJylpbWFnZXMuYWRkKGltYWdlKTt0ZXh0dXJlLmRpc3Bvc2UoKTt9XG4gIGZvcihjb25zdCBpbWFnZSBvZiBpbWFnZXMpaW1hZ2UuY2xvc2UoKTtcbiAgZm9yKGNvbnN0IGl0ZW0gb2YgZ2VvbWV0cmllcylpdGVtLmRpc3Bvc2UoKTtmb3IoY29uc3QgaXRlbSBvZiBtYXRlcmlhbHMpaXRlbS5kaXNwb3NlKCk7XG59XG4vKiogV29ybGQgYWN0b3JzIGFuZCBVSSBzaGFyZSBkZWNvZGVkIGdlb21ldHJ5IGFzIHdlbGwgYXMgdGhlIHJlc291cmNlIHJlcXVlc3QuICovXG5leHBvcnQgY29uc3Qgd29ybGRNb2RlbHM9bmV3IE1vZGVsTGlicmFyeSgpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxZQUFZLFdBQVc7QUFDdkIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxpQkFBb0M7QUFDN0MsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBaUIseUJBQXlCO0FBRW5ELFNBQVMsMEJBQTBCO0FBRW5DLFNBQVMsYUFBYSxvQkFBb0Isc0JBQXNCO0FBQ3pELGdCQUFTLGtCQUFrQixVQUFzQjtBQUFDLFNBQU8sQ0FBQyxHQUFHLG9CQUFJLElBQUksQ0FBQyxHQUFHLFNBQVMsTUFBTSxPQUFPLFVBQU0sV0FBVyxLQUFLLElBQUksQ0FBQyxFQUFFLElBQUksVUFBTSxTQUFTLEtBQUssSUFBSSxFQUFFLEdBQUUsR0FBRyxTQUFTLE1BQU0sT0FBTyxVQUFNLFdBQVcsS0FBSyxJQUFJLENBQUMsRUFBRSxRQUFRLFVBQU0saUJBQWlCLFVBQVMsSUFBSSxFQUFFLFFBQVEsVUFBTTtBQUFDLFVBQU0sU0FBTyxrQkFBa0IsTUFBSyxJQUFJO0FBQUUsV0FBTyxTQUFPLENBQUMsU0FBUyxPQUFPLEdBQUcsRUFBRSxJQUFFLENBQUM7QUFBQSxFQUFFLENBQUMsQ0FBQyxHQUFFLEdBQUcsU0FBUyxVQUFVLElBQUksY0FBVSxhQUFhLFNBQVMsSUFBSSxFQUFFLEdBQUUsR0FBSSxTQUFTLE9BQU8sU0FBTyxDQUFDLGdCQUFnQixJQUFFLENBQUMsR0FBRyxHQUFJLFNBQVMsZUFBZSxTQUFPLENBQUMsZ0JBQWdCLElBQUUsQ0FBQyxDQUFFLENBQUMsQ0FBQztBQUFFO0FBRXZoQixhQUFNLGFBQWE7QUFBQSxFQUt4QixZQUFvQixTQUFxQyxJQUFJLFdBQVcsR0FBRTtBQUF0RDtBQUFBLEVBQXVEO0FBQUEsRUFKbkUsU0FBTyxvQkFBSSxJQUEyQjtBQUFBLEVBQ3RDLFFBQU0sb0JBQUksSUFBdUM7QUFBQSxFQUNqRCxVQUFRLG9CQUFJLElBQTBCO0FBQUEsRUFDdEMsYUFBVztBQUFBLEVBRW5CLE1BQU0sUUFBUSxNQUF1QixPQUFvQjtBQUFDLFVBQU0sUUFBUSxJQUFJLEtBQUssSUFBSSxTQUFLLEtBQUssS0FBSyxLQUFJLEtBQUssQ0FBQyxDQUFDO0FBQUEsRUFBRTtBQUFBLEVBQ3pHLEtBQUssS0FBVyxPQUFvQjtBQUMxQyxVQUFNLE1BQUksVUFBVSxJQUFJLGVBQWUsR0FBRyxNQUFNO0FBQ2hELFFBQUcsS0FBSyxPQUFPLElBQUksR0FBRyxHQUFFO0FBQUMsZ0JBQVUsVUFBVSxLQUFJLEtBQUs7QUFBRSxhQUFPLFFBQVEsUUFBUTtBQUFBLElBQUU7QUFDakYsUUFBSSxVQUFRLEtBQUssUUFBUSxJQUFJLEdBQUc7QUFBRSxRQUFHLFNBQVE7QUFBQyxnQkFBVSxVQUFVLEtBQUksS0FBSztBQUFFLGFBQU87QUFBQSxJQUFRO0FBQzVGLFVBQU0sT0FBSyxVQUFVLE1BQU0sS0FBSSxLQUFJLEtBQUssR0FBRSxhQUFXLEtBQUs7QUFBVyxlQUFTLFlBQVM7QUFDckYsWUFBTSxRQUFNLE1BQU07QUFFbEIsVUFBRyxlQUFhLEtBQUssV0FBVztBQUNoQyxZQUFNLFNBQU8sTUFBTSxLQUFLLE9BQU8sV0FBVyxPQUFNLFVBQVUsSUFBSSxjQUFjLENBQUM7QUFDN0UsVUFBRyxlQUFhLEtBQUssWUFBVztBQUFDLHNCQUFjLENBQUMsT0FBTyxLQUFLLENBQUM7QUFBRTtBQUFBLE1BQU87QUFDdEUsVUFBRztBQUNELDJCQUFtQixPQUFPLEtBQUs7QUFBRSxlQUFPLE1BQU0sa0JBQWtCLElBQUk7QUFDcEUsY0FBTSxRQUFNLG9CQUFJLElBQTJCO0FBQzNDLGVBQU8sTUFBTSxTQUFTLFlBQVE7QUFBQyxjQUFHLE9BQU8sUUFBTSxDQUFDLE1BQU0sSUFBSSxPQUFPLElBQUksRUFBRSxPQUFNLElBQUksT0FBTyxNQUFLLE1BQU07QUFBRSxjQUFHLGtCQUFrQixNQUFNLE1BQUs7QUFBQyxtQkFBTyxhQUFXO0FBQUssbUJBQU8sZ0JBQWM7QUFBQSxVQUFLO0FBQUEsUUFBQyxDQUFDO0FBQ3pMLGFBQUssT0FBTyxJQUFJLEtBQUksT0FBTyxLQUFLO0FBQUUsYUFBSyxNQUFNLElBQUksS0FBSSxLQUFLO0FBQUEsTUFDNUQsU0FBTyxPQUFNO0FBQUMsc0JBQWMsQ0FBQyxPQUFPLEtBQUssQ0FBQztBQUFFLGNBQU07QUFBQSxNQUFNO0FBQUEsSUFDMUQsR0FBRyxFQUFFLFFBQVEsTUFBSTtBQUFDLFVBQUcsS0FBSyxRQUFRLElBQUksR0FBRyxNQUFJLFFBQVEsTUFBSyxRQUFRLE9BQU8sR0FBRztBQUFFLGdCQUFVLGFBQWEsS0FBSSxJQUFJO0FBQUEsSUFBRSxDQUFDO0FBQUUsU0FBSyxRQUFRLElBQUksS0FBSSxPQUFPO0FBQUUsV0FBTztBQUFBLEVBQ3pKO0FBQUEsRUFDQSxVQUFVLEtBQVcsTUFBWTtBQUFDLFVBQU0sU0FBTyxLQUFLLE1BQU0sSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJO0FBQUUsUUFBRyxDQUFDLE9BQU8sUUFBTztBQUFVLFVBQU0sU0FBTyxPQUFPLE1BQU0sSUFBSTtBQUFFLFdBQU8sU0FBUyxJQUFJLEdBQUUsR0FBRSxDQUFDO0FBQUUsV0FBTyxrQkFBa0IsSUFBSTtBQUFFLFdBQU87QUFBQSxFQUFPO0FBQUEsRUFDbE4sY0FBYyxLQUFXO0FBQUMsV0FBTyxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQUEsRUFBRTtBQUFBLEVBQ3RELGFBQVk7QUFBQyxXQUFNLEVBQUMsUUFBTyxLQUFLLE9BQU8sTUFBSyxTQUFRLEtBQUssUUFBUSxLQUFJO0FBQUEsRUFBRTtBQUFBLEVBQ3ZFLFVBQVM7QUFBQyxTQUFLO0FBQWEsa0JBQWMsS0FBSyxPQUFPLE9BQU8sQ0FBQztBQUFFLFNBQUssT0FBTyxNQUFNO0FBQUUsU0FBSyxNQUFNLE1BQU07QUFBRSxTQUFLLFFBQVEsTUFBTTtBQUFBLEVBQUU7QUFDOUg7QUFDQSxTQUFTLGNBQWMsT0FBK0I7QUFDcEQsUUFBTSxhQUFXLG9CQUFJLElBQTBCLEdBQUUsWUFBVSxvQkFBSSxJQUFvQixHQUFFLFdBQVMsb0JBQUksSUFBbUI7QUFDckgsYUFBVSxRQUFRLE1BQU0sTUFBSyxTQUFTLFlBQVE7QUFBQyxRQUFHLGtCQUFrQixNQUFNLE1BQUs7QUFBQyxpQkFBVyxJQUFJLE9BQU8sUUFBUTtBQUFFLGlCQUFVLE9BQU8sTUFBTSxRQUFRLE9BQU8sUUFBUSxJQUFFLE9BQU8sV0FBUyxDQUFDLE9BQU8sUUFBUSxFQUFFLFdBQVUsSUFBSSxHQUFHO0FBQUEsSUFBRTtBQUFBLEVBQUMsQ0FBQztBQUN2TixhQUFVLFlBQVksV0FBVTtBQUM5QixlQUFVLFNBQVMsT0FBTyxPQUFPLFFBQVEsRUFBRSxLQUFHLGlCQUFpQixNQUFNLFFBQVEsVUFBUyxJQUFJLEtBQUs7QUFDL0YsUUFBRyxvQkFBb0IsTUFBTTtBQUFlLGlCQUFVLFdBQVcsT0FBTyxPQUFPLFNBQVMsUUFBUSxFQUFFLFlBQVUsU0FBUyxNQUFNLFFBQVEsUUFBUSxLQUFLLElBQUUsUUFBUSxRQUFNLENBQUMsUUFBUSxLQUFLLEVBQUUsS0FBRyxpQkFBaUIsTUFBTSxRQUFRLFVBQVMsSUFBSSxLQUFLO0FBQUE7QUFBQSxFQUN0TztBQUNBLFFBQU0sU0FBTyxvQkFBSSxJQUFzQjtBQUN2QyxhQUFVLFdBQVcsVUFBUztBQUFDLGVBQVUsU0FBUyxNQUFNLFFBQVEsUUFBUSxLQUFLLElBQUUsUUFBUSxRQUFNLENBQUMsUUFBUSxLQUFLLEVBQUUsS0FBRyxTQUFPLE9BQU8sTUFBTSxVQUFRLFdBQVcsUUFBTyxJQUFJLEtBQUs7QUFBRSxZQUFRLFFBQVE7QUFBQSxFQUFFO0FBQzNMLGFBQVUsU0FBUyxPQUFPLE9BQU0sTUFBTTtBQUN0QyxhQUFVLFFBQVEsV0FBVyxNQUFLLFFBQVE7QUFBRSxhQUFVLFFBQVEsVUFBVSxNQUFLLFFBQVE7QUFDdkY7QUFFTyxhQUFNLGNBQVksSUFBSSxhQUFhOyIsIm5hbWVzIjpbXX0=