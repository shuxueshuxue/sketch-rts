export class HaltedError extends Error {
  constructor(task) {
    super(`${task.label} was halted`);
    this.task = task;
  }
}
export class Task {
  constructor(kernel, id, label, parent, generator) {
    this.kernel = kernel;
    this.id = id;
    this.label = label;
    this.parent = parent;
    this.generator = generator;
  }
  state = "running";
  children = [];
  context = /* @__PURE__ */ new Map();
  outcome;
  // Set by the kernel: the wait the task is parked on, an error to throw into it before its next input, whether a halt
  // came while it was running, its cleanups and the joiners to wake when it settles.
  wait;
  interrupt;
  haltRequested = false;
  cleanups = [];
  joiners = [];
  // `yield* task` waits for the task and returns its result (or throws its error).
  [Symbol.iterator]() {
    return join(this);
  }
  halt() {
    this.kernel.halt(this);
  }
  // The nearest value an ancestor (or the task itself) provided for the context.
  lookup(key) {
    for (let task = this; task; task = task.parent) {
      if (task.context.has(key)) return task.context.get(key);
    }
    return void 0;
  }
}
export class Kernel {
  nextTaskId = 1;
  queue = [];
  running;
  draining = false;
  // A root task. It runs on the next drain.
  start(body, label) {
    const task = this.createTask(body, label, void 0);
    this.enqueue(task, { ok: true, value: void 0 });
    return task;
  }
  get idle() {
    return this.queue.length === 0;
  }
  // Runs every queued task until each waits again or ends. A task woken while the queue drains runs in the same drain.
  drain() {
    if (this.draining) return;
    this.draining = true;
    try {
      for (let entry = this.queue.shift(); entry; entry = this.queue.shift()) this.step(entry.task, entry.input);
    } finally {
      this.draining = false;
    }
  }
  halt(task) {
    if (task.state !== "running") return;
    if (task === this.running) {
      task.haltRequested = true;
      return;
    }
    const failures = [];
    for (const child of [...task.children].reverse()) {
      try {
        this.halt(child);
      } catch (error) {
        failures.push(error);
      }
    }
    this.disarm(task);
    try {
      const after = task.generator.return(void 0);
      if (!after.done) failures.push(new Error(`${task.label} waited while it was being halted: cleanup must finish at once`));
    } catch (error) {
      failures.push(error);
    }
    failures.push(...this.runCleanups(task));
    task.state = "halted";
    this.detach(task);
    for (const joiner of task.joiners.splice(0)) joiner.fail(new HaltedError(task));
    if (failures.length > 0) throw failures[0];
  }
  createTask(body, label, parent) {
    const task = new Task(this, this.nextTaskId++, label, parent, body());
    parent?.children.push(task);
    return task;
  }
  enqueue(task, input) {
    this.queue.push({ task, input });
  }
  step(task, input) {
    if (task.state !== "running") return;
    let next = input;
    if (task.interrupt) {
      next = { ok: false, error: task.interrupt.error };
      delete task.interrupt;
    }
    const outer = this.running;
    this.running = task;
    try {
      for (; ; ) {
        let result;
        try {
          result = next.ok ? task.generator.next(next.value) : task.generator.throw(next.error);
        } catch (error) {
          this.running = outer;
          this.fail(task, error);
          return;
        }
        if (task.haltRequested) {
          this.running = outer;
          task.haltRequested = false;
          this.haltOrFail(task);
          return;
        }
        if (result.done) {
          this.running = outer;
          this.complete(task, result.value);
          return;
        }
        const instruction = result.value;
        if (instruction.type === "current") {
          next = { ok: true, value: task };
        } else if (instruction.type === "spawn") {
          const child = this.createTask(instruction.body, instruction.label, task);
          this.enqueue(child, { ok: true, value: void 0 });
          next = { ok: true, value: child };
        } else {
          this.running = outer;
          this.arm(task, instruction.wait);
          return;
        }
      }
    } finally {
      this.running = outer;
    }
  }
  haltOrFail(task) {
    try {
      this.halt(task);
    } catch (error) {
      this.propagate(task, error);
    }
  }
  arm(task, wait) {
    let pending = true;
    let disarm;
    const settle = (input) => {
      if (!pending) return;
      pending = false;
      delete task.wait;
      disarm?.();
      if (task.state === "running") this.enqueue(task, input);
    };
    task.wait = {
      disarm: () => {
        if (!pending) return;
        pending = false;
        delete task.wait;
        disarm?.();
      }
    };
    disarm = wait({ resume: (value) => settle({ ok: true, value }), fail: (error) => settle({ ok: false, error }) });
    if (!pending) disarm?.();
  }
  disarm(task) {
    task.wait?.disarm();
  }
  complete(task, value) {
    const failures = this.closeChildren(task);
    failures.push(...this.runCleanups(task));
    if (failures.length > 0) {
      this.settleFailed(task, failures[0]);
      return;
    }
    task.state = "done";
    task.outcome = { ok: true, value };
    this.detach(task);
    for (const joiner of task.joiners.splice(0)) joiner.resume(value);
  }
  fail(task, error) {
    this.closeChildren(task);
    this.runCleanups(task);
    this.settleFailed(task, error);
  }
  settleFailed(task, error) {
    task.state = "failed";
    task.outcome = { ok: false, error };
    this.detach(task);
    const joiners = task.joiners.splice(0);
    for (const joiner of joiners) joiner.fail(error);
    this.propagate(task, error);
  }
  // A child's failure is its parent's: thrown into the parent where it waits (or before its next step, if it is already
  // queued), unless the parent is itself gone. A root's failure is kept for whoever started it.
  propagate(task, error) {
    const parent = task.parent;
    if (!parent || parent.state !== "running" || parent.interrupt) return;
    parent.interrupt = { error };
    if (parent.wait) {
      parent.wait.disarm();
      this.enqueue(parent, { ok: true, value: void 0 });
    }
  }
  closeChildren(task) {
    const failures = [];
    for (const child of [...task.children].reverse()) {
      try {
        this.halt(child);
      } catch (error) {
        failures.push(error);
      }
    }
    return failures;
  }
  runCleanups(task) {
    const failures = [];
    for (const cleanup of task.cleanups.splice(0).reverse()) {
      try {
        cleanup();
      } catch (error) {
        failures.push(error);
      }
    }
    return failures;
  }
  detach(task) {
    const siblings = task.parent?.children;
    if (!siblings) return;
    const index = siblings.indexOf(task);
    if (index >= 0) siblings.splice(index, 1);
  }
}
export function* suspend(wait) {
  return yield { type: "suspend", wait };
}
export function* spawn(body, label = body.name || "task") {
  return yield { type: "spawn", body, label };
}
export function* current() {
  return yield { type: "current" };
}
export function* join(task) {
  return yield* suspend((wake) => {
    const outcome = task.outcome;
    if (outcome) {
      if (outcome.ok) wake.resume(outcome.value);
      else wake.fail(outcome.error);
      return;
    }
    if (task.state === "halted") {
      wake.fail(new HaltedError(task));
      return;
    }
    task.joiners.push(wake);
    return () => {
      const index = task.joiners.indexOf(wake);
      if (index >= 0) task.joiners.splice(index, 1);
    };
  });
}
export function* never() {
  return yield* suspend(() => void 0);
}
export function* scope(body, label = body.name || "scope") {
  const task = yield* spawn(body, label);
  return yield* join(task);
}
export function* ensure(cleanup) {
  (yield* current()).cleanups.push(cleanup);
}
export function* race(branches) {
  const entries = Object.entries(branches);
  const tasks = [];
  try {
    for (const [kind, body] of entries) tasks.push(yield* spawn(body, `race:${kind}`));
    const winner = yield* suspend((wake) => {
      const disarms = tasks.map((task, index) => {
        const joiner = { resume: () => wake.resume(index), fail: (error) => wake.fail(error) };
        if (task.outcome) {
          if (task.outcome.ok) wake.resume(index);
          else wake.fail(task.outcome.error);
          return () => void 0;
        }
        task.joiners.push(joiner);
        return () => {
          const at = task.joiners.indexOf(joiner);
          if (at >= 0) task.joiners.splice(at, 1);
        };
      });
      return () => disarms.forEach((disarm) => disarm());
    });
    const outcome = tasks[winner].outcome;
    return { kind: entries[winner][0], value: outcome?.ok ? outcome.value : void 0 };
  } finally {
    for (const task of tasks) task.halt();
  }
}
export function* all(branches) {
  const entries = Object.entries(branches);
  const tasks = [];
  try {
    for (const [kind, body] of entries) tasks.push(yield* spawn(body, `all:${kind}`));
    const results = {};
    for (const [index, task] of tasks.entries()) results[entries[index][0]] = yield* join(task);
    return results;
  } finally {
    for (const task of tasks) task.halt();
  }
}
export function createContext(name) {
  const key = Symbol(name);
  return {
    key,
    name,
    *expect() {
      const value = (yield* current()).lookup(key);
      if (value === void 0) throw new Error(`No ${name} here: run this inside a story that provides one`);
      return value;
    },
    *find() {
      return (yield* current()).lookup(key);
    },
    *provide(value) {
      (yield* current()).context.set(key, value);
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImtlcm5lbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAQEBzdG9yeS1rZXJuZWwgLSBUaGUgbWFjaGluZSBjYW1wYWlnbiBzY3JpcHRzIHJ1biBvbi4gQSBzY3JpcHQgaXMgYW4gb3JkaW5hcnkgVHlwZVNjcmlwdCBnZW5lcmF0b3IgZnVuY3Rpb246IGl0cyBsb2NhbFxuLy8gdmFyaWFibGVzIGFyZSB0aGUgc2NlbmUncyBzdGF0ZSwgdGhlIGxpbmUgaXQgc3RhbmRzIG9uIGlzIHdoZXJlIHRoZSBzdG9yeSBpcywgYW5kIGV2ZXJ5IGB5aWVsZCpgIGlzIGEgcG9pbnQgd2hlcmUgaXRcbi8vIHdhaXRzIGZvciB0aGUgd29ybGQgKGEgbW9tZW50LCBhbiBldmVudCwgYSBsaW5lIHNwb2tlbiwgYSBjaG9pY2UgbWFkZSkuIFRoZSBrZXJuZWwga25vd3Mgb25seSB0aHJlZSBpbnN0cnVjdGlvbnM6XG4vL1xuLy8gICBzdXNwZW5kICAtIHdhaXQgdW50aWwgc29tZXRoaW5nIHdha2VzIHRoZSB0YXNrIChhIHRpbWVyLCBhbiBldmVudCwgYW5vdGhlciB0YXNrIGZpbmlzaGluZyk7XG4vLyAgIHNwYXduICAgIC0gc3RhcnQgYSBjaGlsZCB0YXNrLCB3aGljaCBydW5zIGFsb25nc2lkZSBpdHMgcGFyZW50IGFuZCBjYW4gbmV2ZXIgb3V0bGl2ZSBpdDtcbi8vICAgY3VycmVudCAgLSB0aGUgdGFzayBpdHNlbGYgKGZvciBpdHMgY29udGV4dCBhbmQgaXRzIGNsZWFudXBzKS5cbi8vXG4vLyBFdmVyeXRoaW5nIGVsc2UgKHRpbWUsIGV2ZW50cywgcmFjZXMsIHRoZSBzdGFnZSkgaXMgYnVpbHQgZnJvbSB0aGVzZSwgc28gdGhlIGtlcm5lbCBzdGF5cyBzbWFsbCBlbm91Z2ggdG8gcmVhc29uXG4vLyBhYm91dC4gVGhyZWUgcHJvcGVydGllcyB0aGUgY2FtcGFpZ24gcmVsaWVzIG9uOlxuLy9cbi8vIC0gU3RydWN0dXJlZCBjb25jdXJyZW5jeS4gVGFza3MgZm9ybSBhIHRyZWUuIEEgdGFzayB0aGF0IGZpbmlzaGVzIGhhbHRzIHRoZSBjaGlsZHJlbiBpdCBsZWZ0IHJ1bm5pbmc7IGhhbHRpbmcgYSB0YXNrXG4vLyAgIGhhbHRzIGl0cyBzdWJ0cmVlIGZpcnN0OyBhIGhhbHRlZCBnZW5lcmF0b3IgaXMgcmV0dXJuZWQgZnJvbSwgc28gaXRzIGBmaW5hbGx5YCBibG9ja3MgcnVuIChhIHNjZW5lJ3MgY2xlYW51cCBpcyBpdHNcbi8vICAgYGZpbmFsbHlgLCBub3QgYSB0cmlnZ2VyIHNvbWVvbmUgbXVzdCByZW1lbWJlciB0byBkaXNhYmxlKS4gQSBjaGlsZCdzIGZhaWx1cmUgaXMgdGhyb3duIGludG8gaXRzIHBhcmVudCB3aGVyZSBpdFxuLy8gICB3YWl0cywgYW5kIGNsaW1icyB1bnRpbCBzb21lb25lIGNhdGNoZXMgaXQ6IG5vIGVycm9yIGlzIGxvc3QgaW4gYSBiYWNrZ3JvdW5kIHRyaWdnZXIuXG4vLyAtIERldGVybWluaXNtLiBUaGVyZSBpcyBubyBldmVudCBsb29wIGJ1dCB0aGUga2VybmVsJ3Mgb3duIEZJRk8gcnVuIHF1ZXVlLCBkcmFpbmVkIGJ5IHRoZSBjYWxsZXIgKHRoZSBEaXJlY3RvcikgYXQgYVxuLy8gICBmaXhlZCBwb2ludCBvZiBlYWNoIHNpbXVsYXRpb24gdGljaywgYW5kIHdha2VzIGFyZSBxdWV1ZWQgaW4gdGhlIG9yZGVyIHRoZXkgaGFwcGVuLiBHaXZlbiB0aGUgc2FtZSB3YWtlcywgYSBzY3JpcHRcbi8vICAgcnVucyB0aGUgc2FtZSB3YXkgZXZlcnkgdGltZSwgd2hpY2ggaXMgd2hhdCBsZXRzIGEgc2F2ZSBiZSByZXN0b3JlZCBieSByZXBsYXlpbmcgaXQgKHNlZSBkaXJlY3RvcikuXG4vLyAtIENvbnRleHQgaXMgZHluYW1pY2FsbHkgc2NvcGVkIGFsb25nIHRoZSB0YXNrIHRyZWU6IGEgY2hpbGQgc2VlcyB3aGF0IGl0cyBhbmNlc3RvcnMgcHJvdmlkZWQgKHRoZSBjbG9jaywgdGhlIHdvcmxkKSxcbi8vICAgc28gYSBoZWxwZXIgY2FsbGVkIGFueXdoZXJlIGluIGEgc2NlbmUgcmVhY2hlcyB0aGVtIHdpdGhvdXQgaGF2aW5nIHRoZW0gcGFzc2VkIGRvd24gYnkgaGFuZC5cblxuZXhwb3J0IHR5cGUgT3BlcmF0aW9uPFQ+ID0gR2VuZXJhdG9yPEluc3RydWN0aW9uLCBULCB1bmtub3duPjtcblxuZXhwb3J0IHR5cGUgSW5zdHJ1Y3Rpb24gPVxuICB8IHsgcmVhZG9ubHkgdHlwZTogXCJzdXNwZW5kXCI7IHJlYWRvbmx5IHdhaXQ6IFdhaXQgfVxuICB8IHsgcmVhZG9ubHkgdHlwZTogXCJzcGF3blwiOyByZWFkb25seSBib2R5OiAoKSA9PiBPcGVyYXRpb248dW5rbm93bj47IHJlYWRvbmx5IGxhYmVsOiBzdHJpbmcgfVxuICB8IHsgcmVhZG9ubHkgdHlwZTogXCJjdXJyZW50XCIgfTtcblxuLy8gQXJtcyBhIHdhaXQ6IGB3YWtlYCBzZXR0bGVzIGl0LCBvbmNlLiBSZXR1cm5zIGhvdyB0byBkaXNhcm0gaXQ7IHRoZSBrZXJuZWwgZGlzYXJtcyBldmVyeSB3YWl0IGV4YWN0bHkgb25jZSwgd2hldGhlciBpdFxuLy8gd2FzIHdva2VuIG9yIHRoZSB0YXNrIHdhcyBoYWx0ZWQgd2hpbGUgaXQgd2FpdGVkLlxuZXhwb3J0IHR5cGUgV2FpdCA9ICh3YWtlOiBXYWtlKSA9PiAoKCkgPT4gdm9pZCkgfCB2b2lkO1xuZXhwb3J0IHR5cGUgV2FrZSA9IHsgcmVzdW1lKHZhbHVlOiB1bmtub3duKTogdm9pZDsgZmFpbChlcnJvcjogdW5rbm93bik6IHZvaWQgfTtcblxuZXhwb3J0IHR5cGUgVGFza1N0YXRlID0gXCJydW5uaW5nXCIgfCBcImRvbmVcIiB8IFwiZmFpbGVkXCIgfCBcImhhbHRlZFwiO1xuXG50eXBlIElucHV0ID0geyBvazogdHJ1ZTsgdmFsdWU6IHVua25vd24gfSB8IHsgb2s6IGZhbHNlOyBlcnJvcjogdW5rbm93biB9O1xudHlwZSBTZXR0bGVkPFQ+ID0geyBvazogdHJ1ZTsgdmFsdWU6IFQgfSB8IHsgb2s6IGZhbHNlOyBlcnJvcjogdW5rbm93biB9O1xuXG4vLyBUaHJvd24gaW50byB3aG9ldmVyIGpvaW5zIGEgdGFzayB0aGF0IHdhcyBoYWx0ZWQgYmVmb3JlIGl0IGZpbmlzaGVkLlxuZXhwb3J0IGNsYXNzIEhhbHRlZEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihyZWFkb25seSB0YXNrOiBUYXNrKSB7XG4gICAgc3VwZXIoYCR7dGFzay5sYWJlbH0gd2FzIGhhbHRlZGApO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBUYXNrPFQgPSB1bmtub3duPiBpbXBsZW1lbnRzIEl0ZXJhYmxlPEluc3RydWN0aW9uLCBULCB1bmtub3duPiB7XG4gIHN0YXRlOiBUYXNrU3RhdGUgPSBcInJ1bm5pbmdcIjtcbiAgcmVhZG9ubHkgY2hpbGRyZW46IFRhc2tbXSA9IFtdO1xuICByZWFkb25seSBjb250ZXh0ID0gbmV3IE1hcDxzeW1ib2wsIHVua25vd24+KCk7XG4gIG91dGNvbWU/OiBTZXR0bGVkPFQ+O1xuICAvLyBTZXQgYnkgdGhlIGtlcm5lbDogdGhlIHdhaXQgdGhlIHRhc2sgaXMgcGFya2VkIG9uLCBhbiBlcnJvciB0byB0aHJvdyBpbnRvIGl0IGJlZm9yZSBpdHMgbmV4dCBpbnB1dCwgd2hldGhlciBhIGhhbHRcbiAgLy8gY2FtZSB3aGlsZSBpdCB3YXMgcnVubmluZywgaXRzIGNsZWFudXBzIGFuZCB0aGUgam9pbmVycyB0byB3YWtlIHdoZW4gaXQgc2V0dGxlcy5cbiAgd2FpdD86IHsgZGlzYXJtKCk6IHZvaWQgfTtcbiAgaW50ZXJydXB0PzogeyBlcnJvcjogdW5rbm93biB9O1xuICBoYWx0UmVxdWVzdGVkID0gZmFsc2U7XG4gIHJlYWRvbmx5IGNsZWFudXBzOiAoKCkgPT4gdm9pZClbXSA9IFtdO1xuICByZWFkb25seSBqb2luZXJzOiBXYWtlW10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICByZWFkb25seSBrZXJuZWw6IEtlcm5lbCxcbiAgICByZWFkb25seSBpZDogbnVtYmVyLFxuICAgIHJlYWRvbmx5IGxhYmVsOiBzdHJpbmcsXG4gICAgcmVhZG9ubHkgcGFyZW50OiBUYXNrIHwgdW5kZWZpbmVkLFxuICAgIHJlYWRvbmx5IGdlbmVyYXRvcjogT3BlcmF0aW9uPFQ+LFxuICApIHt9XG5cbiAgLy8gYHlpZWxkKiB0YXNrYCB3YWl0cyBmb3IgdGhlIHRhc2sgYW5kIHJldHVybnMgaXRzIHJlc3VsdCAob3IgdGhyb3dzIGl0cyBlcnJvcikuXG4gIFtTeW1ib2wuaXRlcmF0b3JdKCk6IE9wZXJhdGlvbjxUPiB7XG4gICAgcmV0dXJuIGpvaW4odGhpcyk7XG4gIH1cblxuICBoYWx0KCkge1xuICAgIHRoaXMua2VybmVsLmhhbHQodGhpcyk7XG4gIH1cblxuICAvLyBUaGUgbmVhcmVzdCB2YWx1ZSBhbiBhbmNlc3RvciAob3IgdGhlIHRhc2sgaXRzZWxmKSBwcm92aWRlZCBmb3IgdGhlIGNvbnRleHQuXG4gIGxvb2t1cDxWPihrZXk6IHN5bWJvbCk6IFYgfCB1bmRlZmluZWQge1xuICAgIGZvciAobGV0IHRhc2s6IFRhc2sgfCB1bmRlZmluZWQgPSB0aGlzOyB0YXNrOyB0YXNrID0gdGFzay5wYXJlbnQpIHtcbiAgICAgIGlmICh0YXNrLmNvbnRleHQuaGFzKGtleSkpIHJldHVybiB0YXNrLmNvbnRleHQuZ2V0KGtleSkgYXMgVjtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgS2VybmVsIHtcbiAgcHJpdmF0ZSBuZXh0VGFza0lkID0gMTtcbiAgcHJpdmF0ZSByZWFkb25seSBxdWV1ZTogeyB0YXNrOiBUYXNrOyBpbnB1dDogSW5wdXQgfVtdID0gW107XG4gIHByaXZhdGUgcnVubmluZzogVGFzayB8IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBkcmFpbmluZyA9IGZhbHNlO1xuXG4gIC8vIEEgcm9vdCB0YXNrLiBJdCBydW5zIG9uIHRoZSBuZXh0IGRyYWluLlxuICBzdGFydDxUPihib2R5OiAoKSA9PiBPcGVyYXRpb248VD4sIGxhYmVsOiBzdHJpbmcpOiBUYXNrPFQ+IHtcbiAgICBjb25zdCB0YXNrID0gdGhpcy5jcmVhdGVUYXNrKGJvZHksIGxhYmVsLCB1bmRlZmluZWQpO1xuICAgIHRoaXMuZW5xdWV1ZSh0YXNrLCB7IG9rOiB0cnVlLCB2YWx1ZTogdW5kZWZpbmVkIH0pO1xuICAgIHJldHVybiB0YXNrO1xuICB9XG5cbiAgZ2V0IGlkbGUoKSB7XG4gICAgcmV0dXJuIHRoaXMucXVldWUubGVuZ3RoID09PSAwO1xuICB9XG5cbiAgLy8gUnVucyBldmVyeSBxdWV1ZWQgdGFzayB1bnRpbCBlYWNoIHdhaXRzIGFnYWluIG9yIGVuZHMuIEEgdGFzayB3b2tlbiB3aGlsZSB0aGUgcXVldWUgZHJhaW5zIHJ1bnMgaW4gdGhlIHNhbWUgZHJhaW4uXG4gIGRyYWluKCkge1xuICAgIGlmICh0aGlzLmRyYWluaW5nKSByZXR1cm47XG4gICAgdGhpcy5kcmFpbmluZyA9IHRydWU7XG4gICAgdHJ5IHtcbiAgICAgIGZvciAobGV0IGVudHJ5ID0gdGhpcy5xdWV1ZS5zaGlmdCgpOyBlbnRyeTsgZW50cnkgPSB0aGlzLnF1ZXVlLnNoaWZ0KCkpIHRoaXMuc3RlcChlbnRyeS50YXNrLCBlbnRyeS5pbnB1dCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuZHJhaW5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBoYWx0KHRhc2s6IFRhc2spIHtcbiAgICBpZiAodGFzay5zdGF0ZSAhPT0gXCJydW5uaW5nXCIpIHJldHVybjtcbiAgICAvLyBBIHRhc2sgY2Fubm90IGJlIHJldHVybmVkIGZyb20gd2hpbGUgaXRzIG93biBnZW5lcmF0b3IgcnVuczsgaXQgaXMgaGFsdGVkIHRoZSBtb21lbnQgaXQgbmV4dCB5aWVsZHMuXG4gICAgaWYgKHRhc2sgPT09IHRoaXMucnVubmluZykge1xuICAgICAgdGFzay5oYWx0UmVxdWVzdGVkID0gdHJ1ZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZmFpbHVyZXM6IHVua25vd25bXSA9IFtdO1xuICAgIGZvciAoY29uc3QgY2hpbGQgb2YgWy4uLnRhc2suY2hpbGRyZW5dLnJldmVyc2UoKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5oYWx0KGNoaWxkKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGZhaWx1cmVzLnB1c2goZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmRpc2FybSh0YXNrKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYWZ0ZXIgPSB0YXNrLmdlbmVyYXRvci5yZXR1cm4odW5kZWZpbmVkKTtcbiAgICAgIGlmICghYWZ0ZXIuZG9uZSkgZmFpbHVyZXMucHVzaChuZXcgRXJyb3IoYCR7dGFzay5sYWJlbH0gd2FpdGVkIHdoaWxlIGl0IHdhcyBiZWluZyBoYWx0ZWQ6IGNsZWFudXAgbXVzdCBmaW5pc2ggYXQgb25jZWApKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgZmFpbHVyZXMucHVzaChlcnJvcik7XG4gICAgfVxuICAgIGZhaWx1cmVzLnB1c2goLi4udGhpcy5ydW5DbGVhbnVwcyh0YXNrKSk7XG4gICAgdGFzay5zdGF0ZSA9IFwiaGFsdGVkXCI7XG4gICAgdGhpcy5kZXRhY2godGFzayk7XG4gICAgZm9yIChjb25zdCBqb2luZXIgb2YgdGFzay5qb2luZXJzLnNwbGljZSgwKSkgam9pbmVyLmZhaWwobmV3IEhhbHRlZEVycm9yKHRhc2spKTtcbiAgICBpZiAoZmFpbHVyZXMubGVuZ3RoID4gMCkgdGhyb3cgZmFpbHVyZXNbMF07XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVRhc2s8VD4oYm9keTogKCkgPT4gT3BlcmF0aW9uPFQ+LCBsYWJlbDogc3RyaW5nLCBwYXJlbnQ6IFRhc2sgfCB1bmRlZmluZWQpOiBUYXNrPFQ+IHtcbiAgICBjb25zdCB0YXNrID0gbmV3IFRhc2s8VD4odGhpcywgdGhpcy5uZXh0VGFza0lkKyssIGxhYmVsLCBwYXJlbnQsIGJvZHkoKSk7XG4gICAgcGFyZW50Py5jaGlsZHJlbi5wdXNoKHRhc2spO1xuICAgIHJldHVybiB0YXNrO1xuICB9XG5cbiAgcHJpdmF0ZSBlbnF1ZXVlKHRhc2s6IFRhc2ssIGlucHV0OiBJbnB1dCkge1xuICAgIHRoaXMucXVldWUucHVzaCh7IHRhc2ssIGlucHV0IH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGVwKHRhc2s6IFRhc2ssIGlucHV0OiBJbnB1dCkge1xuICAgIGlmICh0YXNrLnN0YXRlICE9PSBcInJ1bm5pbmdcIikgcmV0dXJuO1xuICAgIGxldCBuZXh0OiBJbnB1dCA9IGlucHV0O1xuICAgIGlmICh0YXNrLmludGVycnVwdCkge1xuICAgICAgbmV4dCA9IHsgb2s6IGZhbHNlLCBlcnJvcjogdGFzay5pbnRlcnJ1cHQuZXJyb3IgfTtcbiAgICAgIGRlbGV0ZSB0YXNrLmludGVycnVwdDtcbiAgICB9XG4gICAgY29uc3Qgb3V0ZXIgPSB0aGlzLnJ1bm5pbmc7XG4gICAgdGhpcy5ydW5uaW5nID0gdGFzaztcbiAgICB0cnkge1xuICAgICAgZm9yICg7Oykge1xuICAgICAgICBsZXQgcmVzdWx0OiBJdGVyYXRvclJlc3VsdDxJbnN0cnVjdGlvbiwgdW5rbm93bj47XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzdWx0ID0gbmV4dC5vayA/IHRhc2suZ2VuZXJhdG9yLm5leHQobmV4dC52YWx1ZSkgOiB0YXNrLmdlbmVyYXRvci50aHJvdyhuZXh0LmVycm9yKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB0aGlzLnJ1bm5pbmcgPSBvdXRlcjtcbiAgICAgICAgICB0aGlzLmZhaWwodGFzaywgZXJyb3IpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGFzay5oYWx0UmVxdWVzdGVkKSB7XG4gICAgICAgICAgdGhpcy5ydW5uaW5nID0gb3V0ZXI7XG4gICAgICAgICAgdGFzay5oYWx0UmVxdWVzdGVkID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5oYWx0T3JGYWlsKHRhc2spO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0LmRvbmUpIHtcbiAgICAgICAgICB0aGlzLnJ1bm5pbmcgPSBvdXRlcjtcbiAgICAgICAgICB0aGlzLmNvbXBsZXRlKHRhc2ssIHJlc3VsdC52YWx1ZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGluc3RydWN0aW9uID0gcmVzdWx0LnZhbHVlO1xuICAgICAgICBpZiAoaW5zdHJ1Y3Rpb24udHlwZSA9PT0gXCJjdXJyZW50XCIpIHtcbiAgICAgICAgICBuZXh0ID0geyBvazogdHJ1ZSwgdmFsdWU6IHRhc2sgfTtcbiAgICAgICAgfSBlbHNlIGlmIChpbnN0cnVjdGlvbi50eXBlID09PSBcInNwYXduXCIpIHtcbiAgICAgICAgICBjb25zdCBjaGlsZCA9IHRoaXMuY3JlYXRlVGFzayhpbnN0cnVjdGlvbi5ib2R5LCBpbnN0cnVjdGlvbi5sYWJlbCwgdGFzayk7XG4gICAgICAgICAgdGhpcy5lbnF1ZXVlKGNoaWxkLCB7IG9rOiB0cnVlLCB2YWx1ZTogdW5kZWZpbmVkIH0pO1xuICAgICAgICAgIG5leHQgPSB7IG9rOiB0cnVlLCB2YWx1ZTogY2hpbGQgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnJ1bm5pbmcgPSBvdXRlcjtcbiAgICAgICAgICB0aGlzLmFybSh0YXNrLCBpbnN0cnVjdGlvbi53YWl0KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5ydW5uaW5nID0gb3V0ZXI7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBoYWx0T3JGYWlsKHRhc2s6IFRhc2spIHtcbiAgICB0cnkge1xuICAgICAgdGhpcy5oYWx0KHRhc2spO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aGlzLnByb3BhZ2F0ZSh0YXNrLCBlcnJvcik7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhcm0odGFzazogVGFzaywgd2FpdDogV2FpdCkge1xuICAgIGxldCBwZW5kaW5nID0gdHJ1ZTtcbiAgICBsZXQgZGlzYXJtOiAoKCkgPT4gdm9pZCkgfCB2b2lkO1xuICAgIGNvbnN0IHNldHRsZSA9IChpbnB1dDogSW5wdXQpID0+IHtcbiAgICAgIGlmICghcGVuZGluZykgcmV0dXJuO1xuICAgICAgcGVuZGluZyA9IGZhbHNlO1xuICAgICAgZGVsZXRlIHRhc2sud2FpdDtcbiAgICAgIGRpc2FybT8uKCk7XG4gICAgICBpZiAodGFzay5zdGF0ZSA9PT0gXCJydW5uaW5nXCIpIHRoaXMuZW5xdWV1ZSh0YXNrLCBpbnB1dCk7XG4gICAgfTtcbiAgICB0YXNrLndhaXQgPSB7XG4gICAgICBkaXNhcm06ICgpID0+IHtcbiAgICAgICAgaWYgKCFwZW5kaW5nKSByZXR1cm47XG4gICAgICAgIHBlbmRpbmcgPSBmYWxzZTtcbiAgICAgICAgZGVsZXRlIHRhc2sud2FpdDtcbiAgICAgICAgZGlzYXJtPy4oKTtcbiAgICAgIH0sXG4gICAgfTtcbiAgICBkaXNhcm0gPSB3YWl0KHsgcmVzdW1lOiAodmFsdWUpID0+IHNldHRsZSh7IG9rOiB0cnVlLCB2YWx1ZSB9KSwgZmFpbDogKGVycm9yKSA9PiBzZXR0bGUoeyBvazogZmFsc2UsIGVycm9yIH0pIH0pO1xuICAgIC8vIFdva2VuIHdoaWxlIGFybWluZyAodGhlIHRoaW5nIHdhaXRlZCBmb3IgaGFkIGFscmVhZHkgaGFwcGVuZWQpOiB0aGUgd2FpdCBpcyBvdmVyIGJlZm9yZSBpdCBiZWdhbi5cbiAgICBpZiAoIXBlbmRpbmcpIGRpc2FybT8uKCk7XG4gIH1cblxuICBwcml2YXRlIGRpc2FybSh0YXNrOiBUYXNrKSB7XG4gICAgdGFzay53YWl0Py5kaXNhcm0oKTtcbiAgfVxuXG4gIHByaXZhdGUgY29tcGxldGUodGFzazogVGFzaywgdmFsdWU6IHVua25vd24pIHtcbiAgICBjb25zdCBmYWlsdXJlcyA9IHRoaXMuY2xvc2VDaGlsZHJlbih0YXNrKTtcbiAgICBmYWlsdXJlcy5wdXNoKC4uLnRoaXMucnVuQ2xlYW51cHModGFzaykpO1xuICAgIGlmIChmYWlsdXJlcy5sZW5ndGggPiAwKSB7XG4gICAgICB0aGlzLnNldHRsZUZhaWxlZCh0YXNrLCBmYWlsdXJlc1swXSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRhc2suc3RhdGUgPSBcImRvbmVcIjtcbiAgICB0YXNrLm91dGNvbWUgPSB7IG9rOiB0cnVlLCB2YWx1ZSB9O1xuICAgIHRoaXMuZGV0YWNoKHRhc2spO1xuICAgIGZvciAoY29uc3Qgam9pbmVyIG9mIHRhc2suam9pbmVycy5zcGxpY2UoMCkpIGpvaW5lci5yZXN1bWUodmFsdWUpO1xuICB9XG5cbiAgcHJpdmF0ZSBmYWlsKHRhc2s6IFRhc2ssIGVycm9yOiB1bmtub3duKSB7XG4gICAgdGhpcy5jbG9zZUNoaWxkcmVuKHRhc2spO1xuICAgIHRoaXMucnVuQ2xlYW51cHModGFzayk7XG4gICAgdGhpcy5zZXR0bGVGYWlsZWQodGFzaywgZXJyb3IpO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXR0bGVGYWlsZWQodGFzazogVGFzaywgZXJyb3I6IHVua25vd24pIHtcbiAgICB0YXNrLnN0YXRlID0gXCJmYWlsZWRcIjtcbiAgICB0YXNrLm91dGNvbWUgPSB7IG9rOiBmYWxzZSwgZXJyb3IgfTtcbiAgICB0aGlzLmRldGFjaCh0YXNrKTtcbiAgICBjb25zdCBqb2luZXJzID0gdGFzay5qb2luZXJzLnNwbGljZSgwKTtcbiAgICBmb3IgKGNvbnN0IGpvaW5lciBvZiBqb2luZXJzKSBqb2luZXIuZmFpbChlcnJvcik7XG4gICAgdGhpcy5wcm9wYWdhdGUodGFzaywgZXJyb3IpO1xuICB9XG5cbiAgLy8gQSBjaGlsZCdzIGZhaWx1cmUgaXMgaXRzIHBhcmVudCdzOiB0aHJvd24gaW50byB0aGUgcGFyZW50IHdoZXJlIGl0IHdhaXRzIChvciBiZWZvcmUgaXRzIG5leHQgc3RlcCwgaWYgaXQgaXMgYWxyZWFkeVxuICAvLyBxdWV1ZWQpLCB1bmxlc3MgdGhlIHBhcmVudCBpcyBpdHNlbGYgZ29uZS4gQSByb290J3MgZmFpbHVyZSBpcyBrZXB0IGZvciB3aG9ldmVyIHN0YXJ0ZWQgaXQuXG4gIHByaXZhdGUgcHJvcGFnYXRlKHRhc2s6IFRhc2ssIGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc3QgcGFyZW50ID0gdGFzay5wYXJlbnQ7XG4gICAgaWYgKCFwYXJlbnQgfHwgcGFyZW50LnN0YXRlICE9PSBcInJ1bm5pbmdcIiB8fCBwYXJlbnQuaW50ZXJydXB0KSByZXR1cm47XG4gICAgcGFyZW50LmludGVycnVwdCA9IHsgZXJyb3IgfTtcbiAgICBpZiAocGFyZW50LndhaXQpIHtcbiAgICAgIHBhcmVudC53YWl0LmRpc2FybSgpO1xuICAgICAgdGhpcy5lbnF1ZXVlKHBhcmVudCwgeyBvazogdHJ1ZSwgdmFsdWU6IHVuZGVmaW5lZCB9KTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNsb3NlQ2hpbGRyZW4odGFzazogVGFzayk6IHVua25vd25bXSB7XG4gICAgY29uc3QgZmFpbHVyZXM6IHVua25vd25bXSA9IFtdO1xuICAgIGZvciAoY29uc3QgY2hpbGQgb2YgWy4uLnRhc2suY2hpbGRyZW5dLnJldmVyc2UoKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5oYWx0KGNoaWxkKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGZhaWx1cmVzLnB1c2goZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFpbHVyZXM7XG4gIH1cblxuICBwcml2YXRlIHJ1bkNsZWFudXBzKHRhc2s6IFRhc2spOiB1bmtub3duW10ge1xuICAgIGNvbnN0IGZhaWx1cmVzOiB1bmtub3duW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IGNsZWFudXAgb2YgdGFzay5jbGVhbnVwcy5zcGxpY2UoMCkucmV2ZXJzZSgpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBmYWlsdXJlcy5wdXNoKGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhaWx1cmVzO1xuICB9XG5cbiAgcHJpdmF0ZSBkZXRhY2godGFzazogVGFzaykge1xuICAgIGNvbnN0IHNpYmxpbmdzID0gdGFzay5wYXJlbnQ/LmNoaWxkcmVuO1xuICAgIGlmICghc2libGluZ3MpIHJldHVybjtcbiAgICBjb25zdCBpbmRleCA9IHNpYmxpbmdzLmluZGV4T2YodGFzayk7XG4gICAgaWYgKGluZGV4ID49IDApIHNpYmxpbmdzLnNwbGljZShpbmRleCwgMSk7XG4gIH1cbn1cblxuLy8gLS0tLSBUaGUgdGhyZWUgaW5zdHJ1Y3Rpb25zLlxuXG5leHBvcnQgZnVuY3Rpb24qIHN1c3BlbmQ8VD4od2FpdDogV2FpdCk6IE9wZXJhdGlvbjxUPiB7XG4gIHJldHVybiAoeWllbGQgeyB0eXBlOiBcInN1c3BlbmRcIiwgd2FpdCB9KSBhcyBUO1xufVxuXG4vLyBTdGFydHMgYGJvZHlgIGFzIGEgY2hpbGQgb2YgdGhlIGN1cnJlbnQgdGFzayBhbmQgcmV0dXJucyBpdHMgaGFuZGxlIGF0IG9uY2U7IGB5aWVsZCogaGFuZGxlYCBqb2lucyBpdC5cbmV4cG9ydCBmdW5jdGlvbiogc3Bhd248VD4oYm9keTogKCkgPT4gT3BlcmF0aW9uPFQ+LCBsYWJlbCA9IGJvZHkubmFtZSB8fCBcInRhc2tcIik6IE9wZXJhdGlvbjxUYXNrPFQ+PiB7XG4gIHJldHVybiAoeWllbGQgeyB0eXBlOiBcInNwYXduXCIsIGJvZHksIGxhYmVsIH0pIGFzIFRhc2s8VD47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiogY3VycmVudCgpOiBPcGVyYXRpb248VGFzaz4ge1xuICByZXR1cm4gKHlpZWxkIHsgdHlwZTogXCJjdXJyZW50XCIgfSkgYXMgVGFzaztcbn1cblxuLy8gLS0tLSBCdWlsdCBmcm9tIHRoZW0uXG5cbmV4cG9ydCBmdW5jdGlvbiogam9pbjxUPih0YXNrOiBUYXNrPFQ+KTogT3BlcmF0aW9uPFQ+IHtcbiAgcmV0dXJuIHlpZWxkKiBzdXNwZW5kPFQ+KCh3YWtlKSA9PiB7XG4gICAgY29uc3Qgb3V0Y29tZSA9IHRhc2sub3V0Y29tZTtcbiAgICBpZiAob3V0Y29tZSkge1xuICAgICAgaWYgKG91dGNvbWUub2spIHdha2UucmVzdW1lKG91dGNvbWUudmFsdWUpO1xuICAgICAgZWxzZSB3YWtlLmZhaWwob3V0Y29tZS5lcnJvcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0YXNrLnN0YXRlID09PSBcImhhbHRlZFwiKSB7XG4gICAgICB3YWtlLmZhaWwobmV3IEhhbHRlZEVycm9yKHRhc2spKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGFzay5qb2luZXJzLnB1c2god2FrZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IGluZGV4ID0gdGFzay5qb2luZXJzLmluZGV4T2Yod2FrZSk7XG4gICAgICBpZiAoaW5kZXggPj0gMCkgdGFzay5qb2luZXJzLnNwbGljZShpbmRleCwgMSk7XG4gICAgfTtcbiAgfSk7XG59XG5cbi8vIFdhaXRzIGZvcmV2ZXIgKHVudGlsIGhhbHRlZCk6IHdoYXQgYSBiYWNrZ3JvdW5kIGJlaGF2aW91ciBkb2VzIG9uY2UgaXQgaGFzIG5vdGhpbmcgbGVmdCB0byBkby5cbmV4cG9ydCBmdW5jdGlvbiogbmV2ZXIoKTogT3BlcmF0aW9uPG5ldmVyPiB7XG4gIHJldHVybiB5aWVsZCogc3VzcGVuZDxuZXZlcj4oKCkgPT4gdW5kZWZpbmVkKTtcbn1cblxuLy8gUnVucyBgYm9keWAgYXMgYSBjaGlsZCBhbmQgd2FpdHMgZm9yIGl0OiB3aGF0ZXZlciBpdCBzcGF3bmVkIGlzIGhhbHRlZCB3aGVuIGl0IHJldHVybnMuIFRoZSBsZXhpY2FsIGJsb2NrIG9mXG4vLyBzdHJ1Y3R1cmVkIGNvbmN1cnJlbmN5OiBgeWllbGQqIHNjb3BlKGZ1bmN0aW9uKiAoKSB7IHlpZWxkKiBzcGF3bihhbWJpZW5jZSk7IHlpZWxkKiBiYXR0bGUoKTsgfSlgIGVuZHMgdGhlIGFtYmllbmNlIHdpdGhcbi8vIHRoZSBiYXR0bGUuXG5leHBvcnQgZnVuY3Rpb24qIHNjb3BlPFQ+KGJvZHk6ICgpID0+IE9wZXJhdGlvbjxUPiwgbGFiZWwgPSBib2R5Lm5hbWUgfHwgXCJzY29wZVwiKTogT3BlcmF0aW9uPFQ+IHtcbiAgY29uc3QgdGFzayA9IHlpZWxkKiBzcGF3bihib2R5LCBsYWJlbCk7XG4gIHJldHVybiB5aWVsZCogam9pbih0YXNrKTtcbn1cblxuLy8gUnVucyBgY2xlYW51cGAgd2hlbiB0aGUgY3VycmVudCB0YXNrIGVuZHMsIGhvd2V2ZXIgaXQgZW5kcyAobGFzdCByZWdpc3RlcmVkLCBmaXJzdCBydW4pOiBHbydzIGRlZmVyLCBhdCB0YXNrIHNjb3BlLlxuZXhwb3J0IGZ1bmN0aW9uKiBlbnN1cmUoY2xlYW51cDogKCkgPT4gdm9pZCk6IE9wZXJhdGlvbjx2b2lkPiB7XG4gICh5aWVsZCogY3VycmVudCgpKS5jbGVhbnVwcy5wdXNoKGNsZWFudXApO1xufVxuXG5leHBvcnQgdHlwZSBSYWNlQnJhbmNoZXMgPSBSZWNvcmQ8c3RyaW5nLCAoKSA9PiBPcGVyYXRpb248dW5rbm93bj4+O1xuZXhwb3J0IHR5cGUgUmFjZVJlc3VsdDxCIGV4dGVuZHMgUmFjZUJyYW5jaGVzPiA9IHsgW0sgaW4ga2V5b2YgQl06IHsga2luZDogSzsgdmFsdWU6IEJbS10gZXh0ZW5kcyAoKSA9PiBPcGVyYXRpb248aW5mZXIgVj4gPyBWIDogbmV2ZXIgfSB9W2tleW9mIEJdO1xuXG4vLyBSdW5zIHRoZSBicmFuY2hlcyBzaWRlIGJ5IHNpZGU7IHRoZSBmaXJzdCB0byBmaW5pc2ggd2lucyBhbmQgdGhlIG90aGVycyBhcmUgaGFsdGVkLiBUaGUgcmVzdWx0IHNheXMgd2hpY2ggd29uOlxuLy8gYHN3aXRjaCAob3V0Y29tZS5raW5kKWAgbmFycm93cyBgb3V0Y29tZS52YWx1ZWAgdG8gdGhhdCBicmFuY2gncyB0eXBlLlxuZXhwb3J0IGZ1bmN0aW9uKiByYWNlPEIgZXh0ZW5kcyBSYWNlQnJhbmNoZXM+KGJyYW5jaGVzOiBCKTogT3BlcmF0aW9uPFJhY2VSZXN1bHQ8Qj4+IHtcbiAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKGJyYW5jaGVzKTtcbiAgY29uc3QgdGFza3M6IFRhc2tbXSA9IFtdO1xuICB0cnkge1xuICAgIGZvciAoY29uc3QgW2tpbmQsIGJvZHldIG9mIGVudHJpZXMpIHRhc2tzLnB1c2goeWllbGQqIHNwYXduKGJvZHksIGByYWNlOiR7a2luZH1gKSk7XG4gICAgY29uc3Qgd2lubmVyID0geWllbGQqIHN1c3BlbmQ8bnVtYmVyPigod2FrZSkgPT4ge1xuICAgICAgY29uc3QgZGlzYXJtcyA9IHRhc2tzLm1hcCgodGFzaywgaW5kZXgpID0+IHtcbiAgICAgICAgY29uc3Qgam9pbmVyOiBXYWtlID0geyByZXN1bWU6ICgpID0+IHdha2UucmVzdW1lKGluZGV4KSwgZmFpbDogKGVycm9yKSA9PiB3YWtlLmZhaWwoZXJyb3IpIH07XG4gICAgICAgIGlmICh0YXNrLm91dGNvbWUpIHtcbiAgICAgICAgICBpZiAodGFzay5vdXRjb21lLm9rKSB3YWtlLnJlc3VtZShpbmRleCk7XG4gICAgICAgICAgZWxzZSB3YWtlLmZhaWwodGFzay5vdXRjb21lLmVycm9yKTtcbiAgICAgICAgICByZXR1cm4gKCkgPT4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHRhc2suam9pbmVycy5wdXNoKGpvaW5lcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgY29uc3QgYXQgPSB0YXNrLmpvaW5lcnMuaW5kZXhPZihqb2luZXIpO1xuICAgICAgICAgIGlmIChhdCA+PSAwKSB0YXNrLmpvaW5lcnMuc3BsaWNlKGF0LCAxKTtcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuICgpID0+IGRpc2FybXMuZm9yRWFjaCgoZGlzYXJtKSA9PiBkaXNhcm0oKSk7XG4gICAgfSk7XG4gICAgY29uc3Qgb3V0Y29tZSA9IHRhc2tzW3dpbm5lcl0hLm91dGNvbWU7XG4gICAgcmV0dXJuIHsga2luZDogZW50cmllc1t3aW5uZXJdIVswXSwgdmFsdWU6IG91dGNvbWU/Lm9rID8gb3V0Y29tZS52YWx1ZSA6IHVuZGVmaW5lZCB9IGFzIFJhY2VSZXN1bHQ8Qj47XG4gIH0gZmluYWxseSB7XG4gICAgZm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB0YXNrLmhhbHQoKTtcbiAgfVxufVxuXG5leHBvcnQgdHlwZSBBbGxSZXN1bHQ8QiBleHRlbmRzIFJhY2VCcmFuY2hlcz4gPSB7IFtLIGluIGtleW9mIEJdOiBCW0tdIGV4dGVuZHMgKCkgPT4gT3BlcmF0aW9uPGluZmVyIFY+ID8gViA6IG5ldmVyIH07XG5cbi8vIFJ1bnMgdGhlIGJyYW5jaGVzIHNpZGUgYnkgc2lkZSBhbmQgd2FpdHMgZm9yIGV2ZXJ5IG9uZTsgaWYgb25lIGZhaWxzIHRoZSByZXN0IGFyZSBoYWx0ZWQgYW5kIHRoZSBlcnJvciBpcyB0aHJvd24uXG5leHBvcnQgZnVuY3Rpb24qIGFsbDxCIGV4dGVuZHMgUmFjZUJyYW5jaGVzPihicmFuY2hlczogQik6IE9wZXJhdGlvbjxBbGxSZXN1bHQ8Qj4+IHtcbiAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKGJyYW5jaGVzKTtcbiAgY29uc3QgdGFza3M6IFRhc2tbXSA9IFtdO1xuICB0cnkge1xuICAgIGZvciAoY29uc3QgW2tpbmQsIGJvZHldIG9mIGVudHJpZXMpIHRhc2tzLnB1c2goeWllbGQqIHNwYXduKGJvZHksIGBhbGw6JHtraW5kfWApKTtcbiAgICBjb25zdCByZXN1bHRzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICAgIGZvciAoY29uc3QgW2luZGV4LCB0YXNrXSBvZiB0YXNrcy5lbnRyaWVzKCkpIHJlc3VsdHNbZW50cmllc1tpbmRleF0hWzBdXSA9IHlpZWxkKiBqb2luKHRhc2spO1xuICAgIHJldHVybiByZXN1bHRzIGFzIEFsbFJlc3VsdDxCPjtcbiAgfSBmaW5hbGx5IHtcbiAgICBmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHRhc2suaGFsdCgpO1xuICB9XG59XG5cbi8vIC0tLS0gQ29udGV4dDogYSB2YWx1ZSBhbiBhbmNlc3RvciBwcm92aWRlcyBhbmQgZXZlcnkgZGVzY2VuZGFudCBjYW4gcmVhZC5cblxuZXhwb3J0IHR5cGUgQ29udGV4dDxUPiA9IHtcbiAgcmVhZG9ubHkga2V5OiBzeW1ib2w7XG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbiAgLy8gVGhlIHZhbHVlLCBvciBhIGxvdWQgZmFpbHVyZSB3aGVuIG5vIGFuY2VzdG9yIHByb3ZpZGVkIG9uZS5cbiAgZXhwZWN0KCk6IE9wZXJhdGlvbjxUPjtcbiAgZmluZCgpOiBPcGVyYXRpb248VCB8IHVuZGVmaW5lZD47XG4gIC8vIFByb3ZpZGVzIHRoZSB2YWx1ZSB0byB0aGUgY3VycmVudCB0YXNrIGFuZCBldmVyeXRoaW5nIGl0IHNwYXducyBmcm9tIG5vdyBvbi5cbiAgcHJvdmlkZSh2YWx1ZTogVCk6IE9wZXJhdGlvbjx2b2lkPjtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVDb250ZXh0PFQ+KG5hbWU6IHN0cmluZyk6IENvbnRleHQ8VD4ge1xuICBjb25zdCBrZXkgPSBTeW1ib2wobmFtZSk7XG4gIHJldHVybiB7XG4gICAga2V5LFxuICAgIG5hbWUsXG4gICAgKmV4cGVjdCgpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gKHlpZWxkKiBjdXJyZW50KCkpLmxvb2t1cDxUPihrZXkpO1xuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHRocm93IG5ldyBFcnJvcihgTm8gJHtuYW1lfSBoZXJlOiBydW4gdGhpcyBpbnNpZGUgYSBzdG9yeSB0aGF0IHByb3ZpZGVzIG9uZWApO1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0sXG4gICAgKmZpbmQoKSB7XG4gICAgICByZXR1cm4gKHlpZWxkKiBjdXJyZW50KCkpLmxvb2t1cDxUPihrZXkpO1xuICAgIH0sXG4gICAgKnByb3ZpZGUodmFsdWU6IFQpIHtcbiAgICAgICh5aWVsZCogY3VycmVudCgpKS5jb250ZXh0LnNldChrZXksIHZhbHVlKTtcbiAgICB9LFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUF1Q08sYUFBTSxvQkFBb0IsTUFBTTtBQUFBLEVBQ3JDLFlBQXFCLE1BQVk7QUFDL0IsVUFBTSxHQUFHLEtBQUssS0FBSyxhQUFhO0FBRGI7QUFBQSxFQUVyQjtBQUNGO0FBRU8sYUFBTSxLQUErRDtBQUFBLEVBYTFFLFlBQ1csUUFDQSxJQUNBLE9BQ0EsUUFDQSxXQUNUO0FBTFM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLEVBQ1I7QUFBQSxFQWxCSCxRQUFtQjtBQUFBLEVBQ1YsV0FBbUIsQ0FBQztBQUFBLEVBQ3BCLFVBQVUsb0JBQUksSUFBcUI7QUFBQSxFQUM1QztBQUFBO0FBQUE7QUFBQSxFQUdBO0FBQUEsRUFDQTtBQUFBLEVBQ0EsZ0JBQWdCO0FBQUEsRUFDUCxXQUEyQixDQUFDO0FBQUEsRUFDNUIsVUFBa0IsQ0FBQztBQUFBO0FBQUEsRUFXNUIsQ0FBQyxPQUFPLFFBQVEsSUFBa0I7QUFDaEMsV0FBTyxLQUFLLElBQUk7QUFBQSxFQUNsQjtBQUFBLEVBRUEsT0FBTztBQUNMLFNBQUssT0FBTyxLQUFLLElBQUk7QUFBQSxFQUN2QjtBQUFBO0FBQUEsRUFHQSxPQUFVLEtBQTRCO0FBQ3BDLGFBQVMsT0FBeUIsTUFBTSxNQUFNLE9BQU8sS0FBSyxRQUFRO0FBQ2hFLFVBQUksS0FBSyxRQUFRLElBQUksR0FBRyxFQUFHLFFBQU8sS0FBSyxRQUFRLElBQUksR0FBRztBQUFBLElBQ3hEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVPLGFBQU0sT0FBTztBQUFBLEVBQ1YsYUFBYTtBQUFBLEVBQ0osUUFBd0MsQ0FBQztBQUFBLEVBQ2xEO0FBQUEsRUFDQSxXQUFXO0FBQUE7QUFBQSxFQUduQixNQUFTLE1BQTBCLE9BQXdCO0FBQ3pELFVBQU0sT0FBTyxLQUFLLFdBQVcsTUFBTSxPQUFPLE1BQVM7QUFDbkQsU0FBSyxRQUFRLE1BQU0sRUFBRSxJQUFJLE1BQU0sT0FBTyxPQUFVLENBQUM7QUFDakQsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLElBQUksT0FBTztBQUNULFdBQU8sS0FBSyxNQUFNLFdBQVc7QUFBQSxFQUMvQjtBQUFBO0FBQUEsRUFHQSxRQUFRO0FBQ04sUUFBSSxLQUFLLFNBQVU7QUFDbkIsU0FBSyxXQUFXO0FBQ2hCLFFBQUk7QUFDRixlQUFTLFFBQVEsS0FBSyxNQUFNLE1BQU0sR0FBRyxPQUFPLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRyxNQUFLLEtBQUssTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLElBQzNHLFVBQUU7QUFDQSxXQUFLLFdBQVc7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLEtBQUssTUFBWTtBQUNmLFFBQUksS0FBSyxVQUFVLFVBQVc7QUFFOUIsUUFBSSxTQUFTLEtBQUssU0FBUztBQUN6QixXQUFLLGdCQUFnQjtBQUNyQjtBQUFBLElBQ0Y7QUFDQSxVQUFNLFdBQXNCLENBQUM7QUFDN0IsZUFBVyxTQUFTLENBQUMsR0FBRyxLQUFLLFFBQVEsRUFBRSxRQUFRLEdBQUc7QUFDaEQsVUFBSTtBQUNGLGFBQUssS0FBSyxLQUFLO0FBQUEsTUFDakIsU0FBUyxPQUFPO0FBQ2QsaUJBQVMsS0FBSyxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQ0EsU0FBSyxPQUFPLElBQUk7QUFDaEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLFVBQVUsT0FBTyxNQUFTO0FBQzdDLFVBQUksQ0FBQyxNQUFNLEtBQU0sVUFBUyxLQUFLLElBQUksTUFBTSxHQUFHLEtBQUssS0FBSyxnRUFBZ0UsQ0FBQztBQUFBLElBQ3pILFNBQVMsT0FBTztBQUNkLGVBQVMsS0FBSyxLQUFLO0FBQUEsSUFDckI7QUFDQSxhQUFTLEtBQUssR0FBRyxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQ3ZDLFNBQUssUUFBUTtBQUNiLFNBQUssT0FBTyxJQUFJO0FBQ2hCLGVBQVcsVUFBVSxLQUFLLFFBQVEsT0FBTyxDQUFDLEVBQUcsUUFBTyxLQUFLLElBQUksWUFBWSxJQUFJLENBQUM7QUFDOUUsUUFBSSxTQUFTLFNBQVMsRUFBRyxPQUFNLFNBQVMsQ0FBQztBQUFBLEVBQzNDO0FBQUEsRUFFUSxXQUFjLE1BQTBCLE9BQWUsUUFBbUM7QUFDaEcsVUFBTSxPQUFPLElBQUksS0FBUSxNQUFNLEtBQUssY0FBYyxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQ3ZFLFlBQVEsU0FBUyxLQUFLLElBQUk7QUFDMUIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLFFBQVEsTUFBWSxPQUFjO0FBQ3hDLFNBQUssTUFBTSxLQUFLLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFBQSxFQUNqQztBQUFBLEVBRVEsS0FBSyxNQUFZLE9BQWM7QUFDckMsUUFBSSxLQUFLLFVBQVUsVUFBVztBQUM5QixRQUFJLE9BQWM7QUFDbEIsUUFBSSxLQUFLLFdBQVc7QUFDbEIsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLEtBQUssVUFBVSxNQUFNO0FBQ2hELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFDQSxVQUFNLFFBQVEsS0FBSztBQUNuQixTQUFLLFVBQVU7QUFDZixRQUFJO0FBQ0YsaUJBQVM7QUFDUCxZQUFJO0FBQ0osWUFBSTtBQUNGLG1CQUFTLEtBQUssS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFVBQVUsTUFBTSxLQUFLLEtBQUs7QUFBQSxRQUN0RixTQUFTLE9BQU87QUFDZCxlQUFLLFVBQVU7QUFDZixlQUFLLEtBQUssTUFBTSxLQUFLO0FBQ3JCO0FBQUEsUUFDRjtBQUNBLFlBQUksS0FBSyxlQUFlO0FBQ3RCLGVBQUssVUFBVTtBQUNmLGVBQUssZ0JBQWdCO0FBQ3JCLGVBQUssV0FBVyxJQUFJO0FBQ3BCO0FBQUEsUUFDRjtBQUNBLFlBQUksT0FBTyxNQUFNO0FBQ2YsZUFBSyxVQUFVO0FBQ2YsZUFBSyxTQUFTLE1BQU0sT0FBTyxLQUFLO0FBQ2hDO0FBQUEsUUFDRjtBQUNBLGNBQU0sY0FBYyxPQUFPO0FBQzNCLFlBQUksWUFBWSxTQUFTLFdBQVc7QUFDbEMsaUJBQU8sRUFBRSxJQUFJLE1BQU0sT0FBTyxLQUFLO0FBQUEsUUFDakMsV0FBVyxZQUFZLFNBQVMsU0FBUztBQUN2QyxnQkFBTSxRQUFRLEtBQUssV0FBVyxZQUFZLE1BQU0sWUFBWSxPQUFPLElBQUk7QUFDdkUsZUFBSyxRQUFRLE9BQU8sRUFBRSxJQUFJLE1BQU0sT0FBTyxPQUFVLENBQUM7QUFDbEQsaUJBQU8sRUFBRSxJQUFJLE1BQU0sT0FBTyxNQUFNO0FBQUEsUUFDbEMsT0FBTztBQUNMLGVBQUssVUFBVTtBQUNmLGVBQUssSUFBSSxNQUFNLFlBQVksSUFBSTtBQUMvQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixVQUFFO0FBQ0EsV0FBSyxVQUFVO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQUEsRUFFUSxXQUFXLE1BQVk7QUFDN0IsUUFBSTtBQUNGLFdBQUssS0FBSyxJQUFJO0FBQUEsSUFDaEIsU0FBUyxPQUFPO0FBQ2QsV0FBSyxVQUFVLE1BQU0sS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUFBLEVBRVEsSUFBSSxNQUFZLE1BQVk7QUFDbEMsUUFBSSxVQUFVO0FBQ2QsUUFBSTtBQUNKLFVBQU0sU0FBUyxDQUFDLFVBQWlCO0FBQy9CLFVBQUksQ0FBQyxRQUFTO0FBQ2QsZ0JBQVU7QUFDVixhQUFPLEtBQUs7QUFDWixlQUFTO0FBQ1QsVUFBSSxLQUFLLFVBQVUsVUFBVyxNQUFLLFFBQVEsTUFBTSxLQUFLO0FBQUEsSUFDeEQ7QUFDQSxTQUFLLE9BQU87QUFBQSxNQUNWLFFBQVEsTUFBTTtBQUNaLFlBQUksQ0FBQyxRQUFTO0FBQ2Qsa0JBQVU7QUFDVixlQUFPLEtBQUs7QUFDWixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsYUFBUyxLQUFLLEVBQUUsUUFBUSxDQUFDLFVBQVUsT0FBTyxFQUFFLElBQUksTUFBTSxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsVUFBVSxPQUFPLEVBQUUsSUFBSSxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFFL0csUUFBSSxDQUFDLFFBQVMsVUFBUztBQUFBLEVBQ3pCO0FBQUEsRUFFUSxPQUFPLE1BQVk7QUFDekIsU0FBSyxNQUFNLE9BQU87QUFBQSxFQUNwQjtBQUFBLEVBRVEsU0FBUyxNQUFZLE9BQWdCO0FBQzNDLFVBQU0sV0FBVyxLQUFLLGNBQWMsSUFBSTtBQUN4QyxhQUFTLEtBQUssR0FBRyxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQ3ZDLFFBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsV0FBSyxhQUFhLE1BQU0sU0FBUyxDQUFDLENBQUM7QUFDbkM7QUFBQSxJQUNGO0FBQ0EsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVLEVBQUUsSUFBSSxNQUFNLE1BQU07QUFDakMsU0FBSyxPQUFPLElBQUk7QUFDaEIsZUFBVyxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUMsRUFBRyxRQUFPLE9BQU8sS0FBSztBQUFBLEVBQ2xFO0FBQUEsRUFFUSxLQUFLLE1BQVksT0FBZ0I7QUFDdkMsU0FBSyxjQUFjLElBQUk7QUFDdkIsU0FBSyxZQUFZLElBQUk7QUFDckIsU0FBSyxhQUFhLE1BQU0sS0FBSztBQUFBLEVBQy9CO0FBQUEsRUFFUSxhQUFhLE1BQVksT0FBZ0I7QUFDL0MsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVLEVBQUUsSUFBSSxPQUFPLE1BQU07QUFDbEMsU0FBSyxPQUFPLElBQUk7QUFDaEIsVUFBTSxVQUFVLEtBQUssUUFBUSxPQUFPLENBQUM7QUFDckMsZUFBVyxVQUFVLFFBQVMsUUFBTyxLQUFLLEtBQUs7QUFDL0MsU0FBSyxVQUFVLE1BQU0sS0FBSztBQUFBLEVBQzVCO0FBQUE7QUFBQTtBQUFBLEVBSVEsVUFBVSxNQUFZLE9BQWdCO0FBQzVDLFVBQU0sU0FBUyxLQUFLO0FBQ3BCLFFBQUksQ0FBQyxVQUFVLE9BQU8sVUFBVSxhQUFhLE9BQU8sVUFBVztBQUMvRCxXQUFPLFlBQVksRUFBRSxNQUFNO0FBQzNCLFFBQUksT0FBTyxNQUFNO0FBQ2YsYUFBTyxLQUFLLE9BQU87QUFDbkIsV0FBSyxRQUFRLFFBQVEsRUFBRSxJQUFJLE1BQU0sT0FBTyxPQUFVLENBQUM7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFBQSxFQUVRLGNBQWMsTUFBdUI7QUFDM0MsVUFBTSxXQUFzQixDQUFDO0FBQzdCLGVBQVcsU0FBUyxDQUFDLEdBQUcsS0FBSyxRQUFRLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFVBQUk7QUFDRixhQUFLLEtBQUssS0FBSztBQUFBLE1BQ2pCLFNBQVMsT0FBTztBQUNkLGlCQUFTLEtBQUssS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxZQUFZLE1BQXVCO0FBQ3pDLFVBQU0sV0FBc0IsQ0FBQztBQUM3QixlQUFXLFdBQVcsS0FBSyxTQUFTLE9BQU8sQ0FBQyxFQUFFLFFBQVEsR0FBRztBQUN2RCxVQUFJO0FBQ0YsZ0JBQVE7QUFBQSxNQUNWLFNBQVMsT0FBTztBQUNkLGlCQUFTLEtBQUssS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxPQUFPLE1BQVk7QUFDekIsVUFBTSxXQUFXLEtBQUssUUFBUTtBQUM5QixRQUFJLENBQUMsU0FBVTtBQUNmLFVBQU0sUUFBUSxTQUFTLFFBQVEsSUFBSTtBQUNuQyxRQUFJLFNBQVMsRUFBRyxVQUFTLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDMUM7QUFDRjtBQUlPLGlCQUFVLFFBQVcsTUFBMEI7QUFDcEQsU0FBUSxNQUFNLEVBQUUsTUFBTSxXQUFXLEtBQUs7QUFDeEM7QUFHTyxpQkFBVSxNQUFTLE1BQTBCLFFBQVEsS0FBSyxRQUFRLFFBQTRCO0FBQ25HLFNBQVEsTUFBTSxFQUFFLE1BQU0sU0FBUyxNQUFNLE1BQU07QUFDN0M7QUFFTyxpQkFBVSxVQUEyQjtBQUMxQyxTQUFRLE1BQU0sRUFBRSxNQUFNLFVBQVU7QUFDbEM7QUFJTyxpQkFBVSxLQUFRLE1BQTZCO0FBQ3BELFNBQU8sT0FBTyxRQUFXLENBQUMsU0FBUztBQUNqQyxVQUFNLFVBQVUsS0FBSztBQUNyQixRQUFJLFNBQVM7QUFDWCxVQUFJLFFBQVEsR0FBSSxNQUFLLE9BQU8sUUFBUSxLQUFLO0FBQUEsVUFDcEMsTUFBSyxLQUFLLFFBQVEsS0FBSztBQUM1QjtBQUFBLElBQ0Y7QUFDQSxRQUFJLEtBQUssVUFBVSxVQUFVO0FBQzNCLFdBQUssS0FBSyxJQUFJLFlBQVksSUFBSSxDQUFDO0FBQy9CO0FBQUEsSUFDRjtBQUNBLFNBQUssUUFBUSxLQUFLLElBQUk7QUFDdEIsV0FBTyxNQUFNO0FBQ1gsWUFBTSxRQUFRLEtBQUssUUFBUSxRQUFRLElBQUk7QUFDdkMsVUFBSSxTQUFTLEVBQUcsTUFBSyxRQUFRLE9BQU8sT0FBTyxDQUFDO0FBQUEsSUFDOUM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUdPLGlCQUFVLFFBQTBCO0FBQ3pDLFNBQU8sT0FBTyxRQUFlLE1BQU0sTUFBUztBQUM5QztBQUtPLGlCQUFVLE1BQVMsTUFBMEIsUUFBUSxLQUFLLFFBQVEsU0FBdUI7QUFDOUYsUUFBTSxPQUFPLE9BQU8sTUFBTSxNQUFNLEtBQUs7QUFDckMsU0FBTyxPQUFPLEtBQUssSUFBSTtBQUN6QjtBQUdPLGlCQUFVLE9BQU8sU0FBc0M7QUFDNUQsR0FBQyxPQUFPLFFBQVEsR0FBRyxTQUFTLEtBQUssT0FBTztBQUMxQztBQU9PLGlCQUFVLEtBQTZCLFVBQXVDO0FBQ25GLFFBQU0sVUFBVSxPQUFPLFFBQVEsUUFBUTtBQUN2QyxRQUFNLFFBQWdCLENBQUM7QUFDdkIsTUFBSTtBQUNGLGVBQVcsQ0FBQyxNQUFNLElBQUksS0FBSyxRQUFTLE9BQU0sS0FBSyxPQUFPLE1BQU0sTUFBTSxRQUFRLElBQUksRUFBRSxDQUFDO0FBQ2pGLFVBQU0sU0FBUyxPQUFPLFFBQWdCLENBQUMsU0FBUztBQUM5QyxZQUFNLFVBQVUsTUFBTSxJQUFJLENBQUMsTUFBTSxVQUFVO0FBQ3pDLGNBQU0sU0FBZSxFQUFFLFFBQVEsTUFBTSxLQUFLLE9BQU8sS0FBSyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEtBQUssS0FBSyxLQUFLLEVBQUU7QUFDM0YsWUFBSSxLQUFLLFNBQVM7QUFDaEIsY0FBSSxLQUFLLFFBQVEsR0FBSSxNQUFLLE9BQU8sS0FBSztBQUFBLGNBQ2pDLE1BQUssS0FBSyxLQUFLLFFBQVEsS0FBSztBQUNqQyxpQkFBTyxNQUFNO0FBQUEsUUFDZjtBQUNBLGFBQUssUUFBUSxLQUFLLE1BQU07QUFDeEIsZUFBTyxNQUFNO0FBQ1gsZ0JBQU0sS0FBSyxLQUFLLFFBQVEsUUFBUSxNQUFNO0FBQ3RDLGNBQUksTUFBTSxFQUFHLE1BQUssUUFBUSxPQUFPLElBQUksQ0FBQztBQUFBLFFBQ3hDO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTyxNQUFNLFFBQVEsUUFBUSxDQUFDLFdBQVcsT0FBTyxDQUFDO0FBQUEsSUFDbkQsQ0FBQztBQUNELFVBQU0sVUFBVSxNQUFNLE1BQU0sRUFBRztBQUMvQixXQUFPLEVBQUUsTUFBTSxRQUFRLE1BQU0sRUFBRyxDQUFDLEdBQUcsT0FBTyxTQUFTLEtBQUssUUFBUSxRQUFRLE9BQVU7QUFBQSxFQUNyRixVQUFFO0FBQ0EsZUFBVyxRQUFRLE1BQU8sTUFBSyxLQUFLO0FBQUEsRUFDdEM7QUFDRjtBQUtPLGlCQUFVLElBQTRCLFVBQXNDO0FBQ2pGLFFBQU0sVUFBVSxPQUFPLFFBQVEsUUFBUTtBQUN2QyxRQUFNLFFBQWdCLENBQUM7QUFDdkIsTUFBSTtBQUNGLGVBQVcsQ0FBQyxNQUFNLElBQUksS0FBSyxRQUFTLE9BQU0sS0FBSyxPQUFPLE1BQU0sTUFBTSxPQUFPLElBQUksRUFBRSxDQUFDO0FBQ2hGLFVBQU0sVUFBbUMsQ0FBQztBQUMxQyxlQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssTUFBTSxRQUFRLEVBQUcsU0FBUSxRQUFRLEtBQUssRUFBRyxDQUFDLENBQUMsSUFBSSxPQUFPLEtBQUssSUFBSTtBQUMzRixXQUFPO0FBQUEsRUFDVCxVQUFFO0FBQ0EsZUFBVyxRQUFRLE1BQU8sTUFBSyxLQUFLO0FBQUEsRUFDdEM7QUFDRjtBQWNPLGdCQUFTLGNBQWlCLE1BQTBCO0FBQ3pELFFBQU0sTUFBTSxPQUFPLElBQUk7QUFDdkIsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLFNBQVM7QUFDUixZQUFNLFNBQVMsT0FBTyxRQUFRLEdBQUcsT0FBVSxHQUFHO0FBQzlDLFVBQUksVUFBVSxPQUFXLE9BQU0sSUFBSSxNQUFNLE1BQU0sSUFBSSxrREFBa0Q7QUFDckcsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLENBQUMsT0FBTztBQUNOLGNBQVEsT0FBTyxRQUFRLEdBQUcsT0FBVSxHQUFHO0FBQUEsSUFDekM7QUFBQSxJQUNBLENBQUMsUUFBUSxPQUFVO0FBQ2pCLE9BQUMsT0FBTyxRQUFRLEdBQUcsUUFBUSxJQUFJLEtBQUssS0FBSztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=