import { bloodSurfaceResolver } from "/@fs/tmp/sketch-queue-source-42bd/src/client/combat-surfaces.ts";
import { PresentationViewIndex } from "/@fs/tmp/sketch-queue-source-42bd/src/client/presentation-view.ts";
import { deckRemainsByShip, deckRemainsPose, remainsOpacity, remainsVariant } from "/@fs/tmp/sketch-queue-source-42bd/src/client/deck-remains.ts";
import { projectActionFrame, projectPaperDirection } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/action-direction.ts";
import { IDLE_FRAME } from "/@fs/tmp/sketch-queue-source-42bd/src/client/unit-animation.ts";
import { drawCombatGround, drawCombatBody, drawCombatAir } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/combat-effects.ts";
import { appearanceFor, corpseAppearanceFor } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/unit-appearance.ts";
import { itemEquipped, itemsFor } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/equipment.ts";
import { playerColor } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/player-colors.ts";
import { drawCanvasShip, deckVisualHeight, drawShipFlag } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/canvas-ships.ts";
import { isInCabin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-cabin.ts";
import { localToWorld, shipProfile, shareShipProfile, shipPassengers, SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { gangwaySurface } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-gangway.ts";
import { gangwayCrewVisualPose } from "/@fs/tmp/sketch-queue-source-42bd/src/client/ship-gangway-visual.ts";
import { healthBarColor, shouldShowHealthBar } from "/@fs/tmp/sketch-queue-source-42bd/src/client/health-bars.ts";
import { drawPaintedItem } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/items.ts";
import { drawAtlasCorpse, drawAtlasBuilding, drawAtlasCamp, drawAtlasGround, drawAtlasLandmark, drawAtlasMine, drawAtlasModel, drawAtlasObstacle, drawAtlasShop, drawAtlasUnit, obstacleArtTop } from "/@fs/tmp/sketch-queue-source-42bd/src/client/atlas-art.ts";
import { renderWorldEffects } from "/@fs/tmp/sketch-queue-source-42bd/src/client/effect-renderer.ts";
import { drawScorchedUnitFlames } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/canvas-effects.ts";
import { battlefieldEffectFrame, drawUnitStatusEffects } from "/@fs/tmp/sketch-queue-source-42bd/src/client/ability-effects.ts";
import { footprintSquare } from "/@fs/tmp/sketch-queue-source-42bd/src/client/footprint-view.ts";
import { creatureShadow } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/painted-creatures.ts";
import { unitGlyphScale } from "/@fs/tmp/sketch-queue-source-42bd/src/client/glyphs.ts";
import { drawLevelStar } from "/@fs/tmp/sketch-queue-source-42bd/src/client/level-star.ts";
import { shouldRenderBuildingRally } from "/@fs/tmp/sketch-queue-source-42bd/src/client/rally-visual.ts";
import { RELATION_INK, relationTo } from "/@fs/tmp/sketch-queue-source-42bd/src/client/relations.ts";
import { drawTerrain } from "/@fs/tmp/sketch-queue-source-42bd/src/client/terrain-art.ts";
import { generateTerrainLinework } from "/@fs/tmp/sketch-queue-source-42bd/src/client/terrain-texture.ts";
import { trainingQueueCountText } from "/@fs/tmp/sketch-queue-source-42bd/src/client/training-queue.ts";
import { drawStoryAir, drawStoryGround, drawStoryProps, drawStoryScreen } from "/@fs/tmp/sketch-queue-source-42bd/src/client/story-renderer.ts";
import { BUILDING_DEFS, UNIT_DEFS, unitMover } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/catalog.ts";
export function worldLabelsFor(i18n) {
  return {
    mercenaryStock: (stock) => i18n.t("canvas.mercenaryStock", { stock }),
    unitKind: (kind) => i18n.label(kind)
  };
}
const NO_SELECTION = /* @__PURE__ */ new Set();
const canvasViewIndexes = /* @__PURE__ */ new WeakMap();
export function drawWorld(frame) {
  const zoom = frame.view.zoom ?? 1;
  let viewIndex = frame.viewIndex ?? canvasViewIndexes.get(frame.ctx);
  if (!viewIndex) {
    viewIndex = new PresentationViewIndex();
    canvasViewIndexes.set(frame.ctx, viewIndex);
  }
  const ships = /* @__PURE__ */ new Map(), gangways = /* @__PURE__ */ new Map();
  const painter = {
    viewIndex,
    ships,
    gangways,
    actorPositions: frame.actorPositions,
    animation: frame.animation,
    reducedMotion: frame.reducedMotion ?? false,
    ctx: frame.ctx,
    snapshot: frame.snapshot,
    camera: { x: frame.view.x, y: frame.view.y },
    width: frame.view.width / zoom,
    height: frame.view.height / zoom,
    now: frame.now,
    facing: frame.facing,
    motion: frame.motion,
    labels: frame.labels,
    selectedIds: frame.selectedIds ?? NO_SELECTION,
    controlGroups: frame.controlGroups,
    selectedCampId: frame.selectedCampId,
    viewer: frame.viewer,
    hoveredId: frame.hoveredId,
    models: frame.models,
    buildingModels: frame.buildingModels,
    still: frame.still ?? false,
    engaged: NO_SELECTION
  };
  const { ctx, snapshot } = painter;
  painter.motion?.update(snapshot, painter.now);
  viewIndex.update(snapshot, painter.motion);
  if (!frame.actorPositions) {
    for (const ship of snapshot.units) if (shipProfile(ship)) {
      const displayed = { ...ship, ...painter.motion?.position(ship, painter.now), sailing: { ...ship.sailing, heading: painter.motion?.heading(ship, painter.now) ?? ship.sailing?.heading ?? 0 } };
      shareShipProfile(ship, displayed);
      ships.set(ship.id, displayed);
    }
    for (const source of ships.values()) {
      const target = source.sailing?.gangway && ships.get(source.sailing.gangway.targetId);
      const surface = target && gangwaySurface(source, target);
      if (surface) gangways.set(source.id, surface);
    }
  }
  painter.animation?.update(snapshot, painter.now, frame.story?.unitActions);
  if (!frame.reducedMotion && frame.pass !== "overlay") frame.wakes?.update(snapshot, painter.now);
  if (!frame.actorPositions) {
    trackUnitFacing(painter.facing, painter.snapshot, viewIndex.entities);
    painter.animation?.observeDirections(painter.now, (id, direction) => painter.facing.actionFacing(id, direction, projectPaperDirection), painter.reducedMotion);
  }
  if (!frame.physicalCombat) frame.combat?.update(snapshot, painter.now, bloodSurfaceResolver(snapshot, frame.animation, frame.facing, frame.models, frame.reducedMotion, frame.models ? 0.8 : 1), (areas) => viewIndex.queryBoundsUnion(areas));
  frame.projectiles?.update(snapshot, frame.models, (id) => frame.facing.releaseFacing(id));
  const combat = frame.combat?.frame(painter.now);
  if (combat && !frame.physicalCombat) {
    const body = /* @__PURE__ */ new Map();
    for (const mark of combat.body) {
      const list = body.get(mark.unitId) ?? [];
      list.push(mark);
      body.set(mark.unitId, list);
    }
    painter.combatBody = body;
  }
  const combatProjection = { worldToScreen: (point) => worldToScreen(painter, point), nearScreen: (point, pad) => nearScreen(painter, point, pad) };
  ctx.save();
  ctx.scale(zoom, zoom);
  if (frame.pass !== "overlay") {
    if (snapshot.map.terrain) {
      drawAtlasGround(ctx, painter.width, painter.height, painter.camera);
      drawTerrain(
        ctx,
        snapshot.map.terrain,
        painter.camera,
        painter.width,
        painter.height,
        frame.pass === "ground" || painter.reducedMotion ? void 0 : painter.now / 1e3
      );
    } else {
      drawPaperMap(ctx, snapshot.map.id, painter.camera, painter.width, painter.height);
    }
    if (!frame.reducedMotion) frame.wakes?.draw(ctx, { ...painter.camera, width: painter.width, height: painter.height }, painter.now);
    drawLandmarks(painter, snapshot.map.landmarks);
    if (!frame.depthSelection) drawGroundSelectionMarkers(painter);
    if (frame.story && frame.props) drawStoryProps(ctx, { ...frame.story, props: frame.story.props.filter((prop) => !frame.actorPositions?.has(`prop:${prop.id}`)) }, (point) => worldToScreen(painter, point), (point, pad) => nearScreen(painter, point, pad), frame.props, painter.now);
    drawResources(painter, snapshot.resources);
    drawMercenaryCamps(painter, snapshot.mercenaryCamps, false, frame.pass === "ground");
    if (snapshot.shops) drawShops(painter, snapshot.shops, false, frame.pass === "ground");
    drawObstacles(painter, snapshot.obstacles ?? []);
    drawItems(painter, snapshot.items);
    if (frame.story) drawStoryGround(ctx, frame.story, (point) => worldToScreen(painter, point), (point, pad) => nearScreen(painter, point, pad));
    if (combat) drawCombatGround(ctx, combat, combatProjection);
    for (const corpse of snapshot.corpses ?? []) {
      if (corpse.deck) continue;
      const point = worldToScreen(painter, corpse);
      if (!nearScreen(painter, point, 90)) continue;
      ctx.save();
      ctx.globalAlpha *= remainsOpacity(snapshot.tick, corpse.diedAtTick);
      const model = corpse.variant ? frame.models?.(corpse.variant) : void 0;
      drawAtlasCorpse(ctx, corpse.kind, point, model ? Math.max(0.72, corpse.radius / 18) : unitGlyphScale(corpse.radius), remainsVariant(corpse.id), model, corpse.variant, ownerInk(corpse.owner, snapshot), corpseAppearanceFor(snapshot, corpse));
      ctx.restore();
    }
  }
  if (frame.pass === "ground") {
    ctx.restore();
    return;
  }
  painter.engaged = viewIndex.engagedIds();
  painter.abilityEffects = battlefieldEffectFrame(snapshot);
  if (frame.pass === "overlay") {
    drawMercenaryCamps(painter, snapshot.mercenaryCamps, true);
    if (snapshot.shops) drawShops(painter, snapshot.shops, true);
  }
  if (!painter.still && frame.viewer) for (const worker of viewIndex.builders) {
    if (isInCabin(worker) || worker.owner !== frame.viewer || worker.order.type !== "build") continue;
    const order = worker.order, point = worldToScreen(painter, order);
    if (!nearScreen(painter, point, 120)) continue;
    ctx.save();
    ctx.globalAlpha = 0.24;
    drawAtlasBuilding(ctx, order.buildingKind, point, buildingGlyphSize(order.buildingKind), "#bca577");
    ctx.restore();
    if ((snapshot.players[frame.viewer]?.gold ?? 0) < BUILDING_DEFS[order.buildingKind].cost) {
      ctx.save();
      ctx.fillStyle = "#e1c28c";
      ctx.font = "12px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(frame.locale === "zh" ? "等待金币" : "Waiting for gold", point.x, point.y + 40);
      ctx.restore();
    }
  }
  if (frame.pass !== "overlay") drawGangways(painter);
  const candidateUnits = viewIndex.query(frame.view);
  if (frame.pass === "overlay") {
    drawBuildings(painter, snapshot.buildings, true);
    drawUnits(painter, candidateUnits, true);
  } else {
    const actors = [...snapshot.buildings, ...candidateUnits.filter((unit) => !unit.deck)].filter((a) => nearScreen(painter, worldToScreen(painter, a), Math.max(150, a.radius * 3))).sort((a, b) => a.y - b.y);
    for (const actor of actors) if ("order" in actor) {
      if (shipProfile(actor)) drawShipGroup(painter, actor);
      else drawUnits(painter, [actor]);
    } else drawBuildings(painter, [actor]);
  }
  if (!painter.still && painter.viewer) drawAimLines(painter);
  const unitsById = viewIndex.units;
  if (combat && !frame.physicalCombat) drawCombatGround(ctx, combat, combatProjection, true);
  if (combat && !frame.physicalCombat) drawCombatAir(ctx, combat, combatProjection, (id, height, position) => {
    const unit = unitsById.get(id);
    if (!unit || isInCabin(unit)) return null;
    const anchor = painter.actorPositions?.get(id);
    const at = anchor ? { x: anchor.x, y: anchor.bodyY } : drawnPosition(painter, unit);
    const ship = unit.deck ? painter.ships.get(unit.deck.shipId) : void 0;
    const model = unit.variant ? painter.models?.(unit.variant) : void 0;
    const floor = model ? 17 * Math.max(0.72, unit.radius / 18) : (creatureShadow(unit.kind)?.y ?? 17) * unitGlyphScale(unit.radius);
    return worldToScreen(painter, { x: at.x + position.x - unit.x, y: at.y + position.y - unit.y + floor - (anchor ? 0 : ship ? deckVisualHeight(ship) + 18 * unitGlyphScale(unit.radius) : 0) - height * Math.tan(SHIP_CAMERA.tilt) });
  }, painter.reducedMotion);
  renderWorldEffects({
    ctx,
    players: snapshot.players,
    effects: snapshot.effects.filter((effect) => !frame.physicalEffects?.has(effect.type) && !(effect.unitId && unitsById.has(effect.unitId) && isInCabin(unitsById.get(effect.unitId)))),
    worldToScreen: (point) => worldToScreen(painter, point),
    nearScreen: (point, pad) => nearScreen(painter, point, pad),
    viewer: painter.viewer,
    reducedMotion: painter.reducedMotion,
    combatTrails: Boolean(combat),
    projectileOrigin: (effect) => frame.projectiles?.origin(effect, frame.physicalCombat ? "gpu" : "canvas"),
    unit: (id) => unitsById.get(id),
    unitPosition: (id) => {
      const unit = unitsById.get(id);
      if (!unit || isInCabin(unit)) return void 0;
      const anchor = painter.actorPositions?.get(id);
      if (anchor) return { x: anchor.x, y: anchor.bodyY };
      const at = drawnPosition(painter, unit), parent = unit.deck ? painter.ships.get(unit.deck.shipId) : void 0;
      return parent ? { x: at.x, y: at.y - deckVisualHeight(parent) - 18 * unitGlyphScale(unit.radius) } : at;
    }
  });
  ctx.restore();
  if (frame.story) {
    const storyPainter = {
      ctx,
      view: frame.story,
      locale: frame.locale ?? "zh",
      width: frame.view.width,
      height: frame.view.height,
      zoom,
      project: (point) => {
        const at = worldToScreen(painter, point);
        return { x: at.x * zoom, y: at.y * zoom };
      },
      unitAt: (unitId) => {
        const unit = unitsById.get(unitId);
        return unit && !isInCabin(unit) ? { ...drawnPosition(painter, unit), radius: unit.radius } : void 0;
      }
    };
    drawStoryAir(storyPainter);
    drawStoryScreen(storyPainter);
  }
}
export function trackUnitFacing(facing, snapshot, knownPositions) {
  let positions;
  facing.updateSnapshot(snapshot, (id) => {
    if (knownPositions) return knownPositions.get(id);
    if (!positions) {
      positions = /* @__PURE__ */ new Map();
      for (const entity of snapshot.units) positions.set(entity.id, entity);
      for (const entity of snapshot.buildings) positions.set(entity.id, entity);
    }
    return positions.get(id);
  });
}
export function drawPaperMap(ctx, mapId, camera, width, height) {
  drawAtlasGround(ctx, width, height, camera);
  for (const stroke of generateTerrainLinework({ mapId, camera, width, height })) {
    drawTextureStroke(ctx, stroke);
  }
}
export function ownerInk(owner, snapshot) {
  return playerColor(owner, snapshot);
}
export function buildingGlyphSize(kind) {
  return Math.round(BUILDING_DEFS[kind].radius * 2.12);
}
function drawTextureStroke(ctx, stroke) {
  if (stroke.points.length === 0) return;
  ctx.strokeStyle = stroke.color;
  ctx.lineWidth = stroke.width;
  ctx.beginPath();
  ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
  for (const point of stroke.points.slice(1)) ctx.lineTo(point.x, point.y);
  ctx.stroke();
}
function drawLandmarks(painter, landmarks) {
  for (const landmark of landmarks) {
    const point = worldToScreen(painter, landmark);
    if (nearScreen(painter, point, landmark.size + 80)) drawAtlasLandmark(painter.ctx, landmark, point);
  }
}
function drawResources(painter, resources) {
  const { ctx } = painter;
  for (const resource of resources) {
    const point = worldToScreen(painter, resource);
    if (!nearScreen(painter, point, 80)) continue;
    drawAtlasMine(ctx, point);
    if (painter.still) continue;
    ctx.font = "600 11px ui-monospace, monospace";
    ctx.textAlign = "center";
    ctx.fillStyle = "#776443";
    ctx.fillText(Math.ceil(resource.amount).toLocaleString(), point.x, point.y + 45);
    ctx.textAlign = "start";
  }
}
function drawMercenaryCamps(painter, camps, overlayOnly = false, groundOnly = false) {
  const { ctx } = painter;
  for (const camp of camps) {
    const point = worldToScreen(painter, camp);
    if (!nearScreen(painter, point, 110)) continue;
    if (!overlayOnly && !painter.actorPositions?.has(camp.id)) drawAtlasCamp(ctx, point);
    if (groundOnly) continue;
    ctx.font = "11px ui-monospace, monospace";
    ctx.fillStyle = "#796644";
    ctx.textAlign = "center";
    ctx.fillText(painter.labels.mercenaryStock(camp.stock), point.x, point.y + 48);
    ctx.textAlign = "start";
    if (camp.cooldownRemaining > 0) drawProgress(ctx, point.x, point.y + 60, 1 - camp.cooldownRemaining / camp.cooldown);
  }
}
function drawObstacles(painter, obstacles) {
  for (const obstacle of obstacles) {
    const shake = hitFeedbackOffset(painter.snapshot, obstacle, painter.viewIndex.hits);
    const point = worldToScreen(painter, { x: obstacle.x + shake.x, y: obstacle.y + shake.y });
    if (!nearScreen(painter, point, obstacle.radius + 80)) continue;
    drawAtlasObstacle(painter.ctx, obstacle, point);
    if (!painter.still && obstacle.hp < obstacle.maxHp) drawHp(painter.ctx, point.x, point.y - obstacleArtTop(obstacle) - 10, obstacle.hp, obstacle.maxHp);
  }
}
function drawShops(painter, shops, overlayOnly = false, groundOnly = false) {
  const { ctx } = painter;
  for (const shop of shops) {
    const point = worldToScreen(painter, shop);
    if (!nearScreen(painter, point, 110)) continue;
    if (!overlayOnly && !painter.actorPositions?.has(shop.id)) drawAtlasShop(ctx, point);
  }
}
function drawBuildings(painter, buildings, overlayOnly = false) {
  const { ctx } = painter;
  const engaged = painter.engaged;
  for (const building of buildings) {
    const shake = hitFeedbackOffset(painter.snapshot, building, painter.viewIndex.hits);
    const point = worldToScreen(painter, { x: building.x + shake.x, y: building.y + shake.y });
    const selected = painter.selectedIds.has(building.id);
    const trainable = BUILDING_DEFS[building.kind].trains.length > 0;
    const rallyPoint = worldToScreen(painter, { x: building.rallyX, y: building.rallyY });
    const showRally = shouldRenderBuildingRally({ selected, trainable, owner: building.owner, viewer: painter.viewer });
    if (!nearScreen(painter, point, 120)) {
      if (showRally) drawBuildingRally(ctx, building, point, rallyPoint, ownerInk(building.owner, painter.snapshot));
      continue;
    }
    ctx.strokeStyle = ownerInk(building.owner, painter.snapshot);
    ctx.fillStyle = building.complete ? "rgba(255, 250, 226, 0.72)" : "rgba(255, 250, 226, 0.42)";
    ctx.lineWidth = selected ? 4 : 2;
    const size = buildingGlyphSize(building.kind);
    ctx.save();
    ctx.globalAlpha = building.complete ? 1 : 0.48;
    if (!overlayOnly) drawAtlasBuilding(ctx, painter.buildingModels?.[building.id] ?? building.kind, point, size, ownerInk(building.owner, painter.snapshot));
    ctx.restore();
    if (showRally) drawBuildingRally(ctx, building, point, rallyPoint, ownerInk(building.owner, painter.snapshot));
    if (shouldShowHealthBar({ hp: building.hp, maxHp: building.maxHp, selected, hovered: painter.hoveredId === building.id, engaged: engaged.has(building.id), constructing: !building.complete, still: painter.still })) drawHp(ctx, point.x, painter.actorPositions?.get(building.id)?.topY !== void 0 ? painter.actorPositions.get(building.id).topY - painter.camera.y - 7 : point.y - size * 0.78 - 5, building.hp, building.maxHp, 48);
    if (!building.complete) drawProgress(ctx, point.x, point.y + size * 0.6 + 10, building.buildProgress / building.buildTime);
    if (building.complete && building.queue[0]) {
      drawTrainingProgress(painter, point.x, point.y + size * 0.6 + 10, building.queue[0].remaining, building.queue[0].unitKind, building.queue.length);
    }
  }
}
function drawAimLines(painter) {
  const { ctx } = painter;
  for (const unit of painter.viewIndex.aiming) {
    const aim = unit.aim;
    if (isInCabin(unit) || unit.owner !== painter.viewer || !aim || !["attack", "attackMove", "hold", "aim", "cast"].includes(unit.order.type)) continue;
    const from = worldToScreen(painter, drawnPosition(painter, unit)), to = worldToScreen(painter, aim);
    if (!nearScreen(painter, from, 80) && !nearScreen(painter, to, 80)) continue;
    ctx.save();
    ctx.globalAlpha = painter.selectedIds.has(unit.id) ? 0.8 : 0.4;
    ctx.strokeStyle = aim.tracking ? "#c59b56" : "#72a98b";
    ctx.lineWidth = 1;
    ctx.setLineDash(aim.tracking ? [4, 4] : []);
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.arc(to.x, to.y, 4, 0, Math.PI * 2);
    ctx.moveTo(to.x - 7, to.y);
    ctx.lineTo(to.x + 7, to.y);
    ctx.moveTo(to.x, to.y - 7);
    ctx.lineTo(to.x, to.y + 7);
    ctx.stroke();
    ctx.restore();
  }
}
function drawBuildingRally(ctx, building, from, to, color) {
  ctx.save();
  const x = to.x, y = to.y;
  ctx.fillStyle = "#29272440";
  ctx.beginPath();
  ctx.ellipse(x + 3, y + 3, 10, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#49413a";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, y + 2);
  ctx.lineTo(x, y - 27);
  ctx.stroke();
  ctx.strokeStyle = "#d4c1a0";
  ctx.lineWidth = 0.65;
  ctx.beginPath();
  ctx.moveTo(x - 0.6, y);
  ctx.lineTo(x - 0.6, y - 27);
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x + 1, y - 26);
  ctx.lineTo(x + 17, y - 23);
  ctx.lineTo(x + 12, y - 18);
  ctx.lineTo(x + 17, y - 14);
  ctx.lineTo(x + 1, y - 17);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawShipGroup(painter, ship) {
  const point = worldToScreen(painter, drawnPosition(painter, ship));
  if (painter.motion && ship.sailing) ship = { ...ship, sailing: { ...ship.sailing, heading: painter.motion.heading(ship, painter.now) } };
  const crew = shipPassengers(painter.snapshot.units, ship).sort((a, b) => a.y - b.y);
  drawCanvasShip(painter.ctx, ship, point, painter.snapshot.items, () => {
    const at = drawnPosition(painter, ship);
    for (const corpse of deckRemainsByShip(painter.snapshot.corpses).get(ship.id) ?? []) {
      const pose = deckRemainsPose(corpse, ship, { ...at, heading: ship.sailing?.heading ?? 0 });
      if (!pose) continue;
      const center = worldToScreen(painter, { x: pose.x, y: pose.y - deckVisualHeight(ship) });
      const model = corpse.variant ? painter.models?.(corpse.variant) : void 0;
      painter.ctx.save();
      painter.ctx.translate(center.x, center.y);
      painter.ctx.rotate(pose.heading);
      painter.ctx.globalAlpha *= remainsOpacity(painter.snapshot.tick, corpse.diedAtTick);
      drawAtlasCorpse(painter.ctx, corpse.kind, { x: 0, y: 0 }, model ? Math.max(0.72, corpse.radius / 18) : unitGlyphScale(corpse.radius), remainsVariant(corpse.id), model, corpse.variant, ownerInk(corpse.owner, painter.snapshot), corpseAppearanceFor(painter.snapshot, corpse));
      painter.ctx.restore();
    }
    for (const passenger of crew) drawUnitSelectionMarker(painter, passenger);
  });
  drawShipFlag(painter.ctx, ship, point, ownerInk(ship.owner, painter.snapshot));
  drawItems(painter, painter.snapshot.items, ship);
  for (const passenger of crew) drawUnits(painter, [passenger]);
  drawUnits(painter, [ship], true);
}
function drawGangways(painter) {
  const { ctx } = painter;
  for (const [id, surface] of painter.gangways) {
    const source = painter.ships.get(id), target = painter.ships.get(source.sailing.gangway.targetId);
    const dx = surface.target.x - surface.source.x, dy = surface.target.y - surface.source.y, span2 = dx * dx + dy * dy;
    const project = (point) => {
      const t = Math.max(0, Math.min(1, ((point.x - surface.source.x) * dx + (point.y - surface.source.y) * dy) / span2));
      const height = deckVisualHeight(source) + (deckVisualHeight(target) - deckVisualHeight(source)) * t;
      return worldToScreen(painter, { x: point.x, y: point.y - height });
    };
    const center = project({ x: (surface.source.x + surface.target.x) / 2, y: (surface.source.y + surface.target.y) / 2 });
    if (!nearScreen(painter, center, 100)) continue;
    ctx.save();
    ctx.globalAlpha = surface.phase === "deploying" ? 0.48 : 1;
    ctx.fillStyle = "#9b7550";
    ctx.strokeStyle = "#4d3927";
    ctx.lineWidth = 2;
    ctx.beginPath();
    surface.polygon.forEach((point, index) => {
      const at = project(point);
      if (index) ctx.lineTo(at.x, at.y);
      else ctx.moveTo(at.x, at.y);
    });
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}
function drawUnits(painter, units, overlayOnly = false) {
  const { ctx, now } = painter;
  const engaged = painter.engaged;
  for (const unit of units) {
    if (isInCabin(unit)) continue;
    const shake = hitFeedbackOffset(painter.snapshot, unit, painter.viewIndex.hits);
    const anchor = painter.actorPositions?.get(unit.id);
    const at = anchor ? { x: anchor.x, y: anchor.bodyY } : drawnPosition(painter, unit);
    const ship = unit.deck ? painter.ships.get(unit.deck.shipId) : void 0;
    const bridge = !anchor && gangwayCrewVisualPose(unit, painter.ships, painter.gangways);
    const bodyHeight = 18 * unitGlyphScale(unit.radius) * (painter.models && !unit.variant ? 0.8 : 1);
    const height = anchor ? 0 : bridge ? bridge.height * Math.tan(SHIP_CAMERA.tilt) + bodyHeight : ship ? deckVisualHeight(ship) + bodyHeight : 0;
    const point = worldToScreen(painter, { x: at.x + shake.x, y: at.y + shake.y - height });
    const scale = unitGlyphScale(unit.radius) * (painter.models && !unit.variant ? 0.8 : 1);
    if (!nearScreen(painter, point, Math.max(60, unit.radius * 3))) continue;
    const selected = painter.selectedIds.has(unit.id);
    ctx.strokeStyle = ownerInk(unit.owner, painter.snapshot);
    ctx.fillStyle = unit.owner === "neutral" ? "#f0d9bd" : "#fffbe7";
    ctx.lineWidth = selected ? 4 : 2;
    if (hasCarriedItem(painter.snapshot, unit, "flameCloak")) drawFlameCloakAura(ctx, point, now, unit.radius);
    const model = unit.variant !== void 0 ? painter.models?.(unit.variant) : void 0;
    const blood = painter.combatBody?.get(unit.id);
    if (!overlayOnly || blood) {
      const rawPose = painter.reducedMotion || painter.still && unitMover(unit.kind) === "sea" ? IDLE_FRAME : painter.animation?.frame(unit, now) ?? IDLE_FRAME;
      const facing = painter.facing.actionFacing(unit.id, rawPose.direction ?? rawPose.carryDirection, projectPaperDirection);
      const pose = projectActionFrame(rawPose, facing);
      if (!overlayOnly && model) drawAtlasModel(ctx, unit.variant, model, point, Math.max(0.72, unit.radius / 18), String(ctx.strokeStyle), facing, pose, appearanceFor(painter.snapshot, unit));
      else if (!overlayOnly) drawAtlasUnit(ctx, unit.kind, point, scale, String(ctx.strokeStyle), facing, pose, appearanceFor(painter.snapshot, unit));
      if (blood) drawCombatBody(ctx, blood, { x: point.x, y: point.y + (model ? 17 * Math.max(0.72, unit.radius / 18) : (creatureShadow(unit.kind)?.y ?? 17) * scale) }, anchor?.facing ?? facing);
    }
    if (unit.id === "tide-admiral") {
      ctx.fillStyle = "#edd094";
      ctx.strokeStyle = "#26373d";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(point.x, point.y - 65);
      ctx.lineTo(point.x + 6, point.y - 57);
      ctx.lineTo(point.x, point.y - 49);
      ctx.lineTo(point.x - 6, point.y - 57);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    const scorch = painter.abilityEffects?.statuses.get(unit.id)?.find((effect) => effect.type === "scorch");
    if (scorch && scorch.remaining > 0) drawScorchedUnitFlames(ctx, point, unit.radius, painter.reducedMotion ? 0 : now, scorch.remaining);
    if (painter.abilityEffects) drawUnitStatusEffects(
      ctx,
      unit,
      painter.abilityEffects,
      point,
      { x: point.x, y: point.y + (creatureShadow(unit.kind)?.y ?? 17) * scale },
      { x: point.x, y: anchor ? anchor.topY - painter.camera.y + shake.y : point.y - 64 * scale },
      now,
      painter.reducedMotion,
      selected
    );
    if (unit.kind === "worker" && unit.carryingGold > 0) drawCarriedGold(ctx, point.x, point.y);
    if (unit.level > 0) drawLevelStar(ctx, point.x + unit.radius + 5, point.y - unit.radius - 5, unit.level);
    if (shouldShowHealthBar({ hp: unit.hp, maxHp: unit.maxHp, shipHull: Boolean(shipProfile(unit)), selected, hovered: painter.hoveredId === unit.id, engaged: engaged.has(unit.id), still: painter.still })) drawHp(ctx, point.x, point.y - Math.max(unit.radius * 1.8 + 6, 64 * scale + 6), unit.hp, unit.maxHp);
    if (selected && painter.controlGroups) {
      const digits = Object.entries(painter.controlGroups).filter(([, ids]) => ids.includes(unit.id)).map(([digit]) => digit).join("·");
      if (digits) {
        ctx.save();
        ctx.font = "11px sans-serif";
        ctx.textAlign = "left";
        ctx.lineWidth = 2;
        ctx.strokeStyle = "#17201caa";
        ctx.fillStyle = "#fff";
        ctx.strokeText(digits, point.x + unit.radius * 0.7, point.y + unit.radius + 10);
        ctx.fillText(digits, point.x + unit.radius * 0.7, point.y + unit.radius + 10);
        ctx.restore();
      }
    }
  }
}
function drawnPosition(painter, unit) {
  const anchor = unit.gangway && painter.actorPositions?.get(unit.id);
  if (anchor) return anchor;
  const bridge = gangwayCrewVisualPose(unit, painter.ships, painter.gangways);
  if (bridge) return bridge;
  if (unit.deck) {
    const ship = painter.ships.get(unit.deck.shipId);
    if (ship) {
      const parent = painter.motion ? painter.motion.position(ship, painter.now) : ship;
      const heading = painter.motion?.heading(ship, painter.now) ?? ship.sailing?.heading ?? 0, c = Math.cos(heading), s = Math.sin(heading);
      return { x: parent.x + unit.deck.x * c - unit.deck.y * s, y: parent.y + unit.deck.x * s + unit.deck.y * c };
    }
  }
  return painter.motion ? painter.motion.position(unit, painter.now) : unit;
}
function hasCarriedItem(snapshot, unit, kind) {
  return itemsFor(snapshot, unit).some((item) => item.kind === kind && itemEquipped(snapshot, unit, item));
}
function drawFlameCloakAura(ctx, point, now, radius) {
  const pulse = 0.55 + Math.sin(now / 140) * 0.14;
  ctx.save();
  ctx.strokeStyle = `rgba(150, 60, 54, ${pulse})`;
  ctx.fillStyle = "rgba(242, 137, 75, 0.12)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 13, radius + 14, (radius + 14) * 0.42, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "rgba(242, 137, 75, 0.72)";
  for (let index = 0; index < 5; index += 1) {
    const angle = now / 260 + index * 1.26;
    const x = point.x + Math.cos(angle) * (radius + 8);
    const y = point.y + 13 + Math.sin(angle) * (radius * 0.34);
    ctx.beginPath();
    ctx.moveTo(x, y + 5);
    ctx.quadraticCurveTo(x - 5, y - 3, x + 1, y - 11);
    ctx.quadraticCurveTo(x + 6, y - 3, x + 3, y + 5);
    ctx.stroke();
  }
  ctx.restore();
}
function drawItems(painter, items, ship) {
  for (const item of items) {
    if (item.carrierId || item.shipId) continue;
    if (ship ? item.deck?.shipId !== ship.id : item.deck) continue;
    const position = ship && item.deck ? localToWorld({ ...ship, ...drawnPosition(painter, ship) }, item.deck) : item;
    const point = worldToScreen(painter, position);
    if (ship) point.y -= deckVisualHeight(ship);
    if (!nearScreen(painter, point, 42)) continue;
    drawItemGlyph(painter.ctx, item, point, painter.now, false);
  }
}
function ringInk(painter, owner) {
  return painter.viewer ? RELATION_INK[relationTo(painter.snapshot, painter.viewer, owner)] : ownerInk(owner, painter.snapshot);
}
function drawGroundSelectionMarkers(painter) {
  for (const unit of painter.viewIndex.query({ x: painter.camera.x, y: painter.camera.y, width: painter.width, height: painter.height })) if (!unit.deck) drawUnitSelectionMarker(painter, unit);
  for (const building of painter.snapshot.buildings) {
    const selected = painter.selectedIds.has(building.id);
    if ((selected || painter.hoveredId === building.id) && nearScreen(painter, worldToScreen(painter, building), building.radius + 80))
      drawFoundationBoundary(painter, building, ringInk(painter, building.owner), selected);
  }
  for (const site of [...painter.snapshot.mercenaryCamps, ...painter.snapshot.shops ?? []]) {
    const selected = painter.selectedCampId === site.id;
    if ((selected || painter.hoveredId === site.id) && nearScreen(painter, worldToScreen(painter, site), site.radius + 80))
      drawFoundationBoundary(painter, site, "#96774a", selected);
  }
}
function drawUnitSelectionMarker(painter, unit) {
  const selected = painter.selectedIds.has(unit.id);
  if (unit.hp <= 0 || isInCabin(unit) || !selected && painter.hoveredId !== unit.id) return;
  const { ctx } = painter, at = drawnPosition(painter, unit), profile = shipProfile(unit);
  const parent = unit.deck && painter.ships.get(unit.deck.shipId), bridge = gangwayCrewVisualPose(unit, painter.ships, painter.gangways);
  const scale = unitGlyphScale(unit.radius) * (painter.models && !unit.variant ? 0.8 : 1);
  const height = bridge ? bridge.height * Math.tan(SHIP_CAMERA.tilt) : parent ? deckVisualHeight(parent) : 0;
  const point = worldToScreen(painter, { x: at.x, y: at.y - height });
  if (!nearScreen(painter, point, Math.max(60, unit.radius * 3))) return;
  ctx.save();
  ctx.strokeStyle = ringInk(painter, unit.owner);
  ctx.lineWidth = selected ? 3 : 2;
  ctx.beginPath();
  if (profile) {
    const heading = painter.motion?.heading(unit, painter.now) ?? unit.sailing?.heading ?? unit.facing ?? 0;
    const hull = { ...unit, x: at.x, y: at.y, sailing: { heading, speed: 0, load: 0, balance: 0 } };
    profile.hull.forEach((vertex, index) => {
      const p = worldToScreen(painter, localToWorld(hull, vertex));
      if (index === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    });
    ctx.closePath();
  } else {
    const bodyHeight = parent || bridge ? 18 * scale : 0, feet = point.y - bodyHeight + (creatureShadow(unit.kind)?.y ?? 17) * scale;
    const radius = (unit.bodyRadius ?? unit.radius) + 3;
    ctx.ellipse(point.x, feet, radius, radius * 0.55, 0, 0, Math.PI * 2);
  }
  ctx.stroke();
  ctx.restore();
}
function drawFoundationBoundary(painter, body, color, selected) {
  const { ctx } = painter, square = footprintSquare(painter.snapshot, body, body.radius), point = worldToScreen(painter, body);
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = selected ? 2.5 : 1.5;
  if (square) {
    const x = square.left * square.cell - painter.camera.x, y = square.top * square.cell - painter.camera.y;
    const w = (square.right - square.left + 1) * square.cell, h = (square.bottom - square.top + 1) * square.cell;
    ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
    if (selected) {
      ctx.globalAlpha = 0.06;
      ctx.fillStyle = color;
      ctx.fillRect(x + 1, y + 1, w - 2, h - 2);
    }
  } else {
    ctx.beginPath();
    ctx.ellipse(point.x, point.y, body.radius + 3, (body.radius + 3) * 0.55, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}
function drawCarriedGold(ctx, x, y) {
  ctx.save();
  ctx.strokeStyle = "#8a6418";
  ctx.fillStyle = "#f2d05c";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - 6, y - 24);
  ctx.lineTo(x + 2, y - 34);
  ctx.lineTo(x + 10, y - 23);
  ctx.lineTo(x + 1, y - 18);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawItemGlyph(ctx, item, point, _now, _carried) {
  drawPaintedItem(ctx, item.kind, point, 30, true, item.weaponKind);
}
function drawHp(ctx, x, y, hp, maxHp, width = 34) {
  const ratio = Math.max(0, Math.min(1, hp / Math.max(1, maxHp)));
  ctx.fillStyle = "#31483a";
  ctx.fillRect(x - width / 2 - 1, y - 1, width + 2, 5);
  ctx.fillStyle = healthBarColor(hp, maxHp);
  ctx.fillRect(x - width / 2, y, width * ratio, 3);
}
function drawProgress(ctx, x, y, ratio) {
  ctx.fillStyle = "rgba(35, 49, 38, 0.18)";
  ctx.fillRect(x - 28, y, 56, 5);
  ctx.fillStyle = "#315f87";
  ctx.fillRect(x - 28, y, 56 * Math.max(0, Math.min(1, ratio)), 5);
}
function drawTrainingProgress(painter, x, y, remaining, unitKind, queueLength) {
  const { ctx } = painter;
  const total = UNIT_DEFS[unitKind].trainTime;
  drawProgress(ctx, x, y, 1 - remaining / total);
  ctx.fillStyle = "#315f87";
  ctx.font = "9px ui-monospace, monospace";
  const countText = trainingQueueCountText(queueLength);
  ctx.fillText(`${painter.labels.unitKind(unitKind)}${countText ? ` ${countText}` : ""}`, x - 27, y + 16);
}
const HIT_SHAKE = 7;
const MAX_HIT_SHAKE = 2;
function hitFeedbackOffset(snapshot, entity, hits) {
  const hit = hits ? hits.get(entity.id) : snapshot.effects.find((effect) => effect.type === "hit" && effect.unitId === entity.id);
  if (!hit) return { x: 0, y: 0 };
  const amount = Math.min(MAX_HIT_SHAKE, HIT_SHAKE * (hit.damage ?? 0) / Math.max(1, entity.maxHp));
  const life = Math.max(0, Math.min(1, hit.remaining / hit.duration));
  const pulse = Math.sin((1 - life) * Math.PI * 2) * amount * life * life;
  return { x: pulse, y: -pulse * 0.35 };
}
function worldToScreen(painter, point) {
  return { x: point.x - painter.camera.x, y: point.y - painter.camera.y };
}
function nearScreen(painter, point, pad) {
  return point.x >= -pad && point.y >= -pad && point.x <= painter.width + pad && point.y <= painter.height + pad;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndvcmxkLXJlbmRlcmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Ymxvb2RTdXJmYWNlUmVzb2x2ZXJ9IGZyb20gJy4vY29tYmF0LXN1cmZhY2VzJztcbmltcG9ydCB7UHJlc2VudGF0aW9uVmlld0luZGV4fSBmcm9tICcuL3ByZXNlbnRhdGlvbi12aWV3JztcbmltcG9ydCB7IGRlY2tSZW1haW5zQnlTaGlwLCBkZWNrUmVtYWluc1Bvc2UsIHJlbWFpbnNPcGFjaXR5LCByZW1haW5zVmFyaWFudCB9IGZyb20gJy4vZGVjay1yZW1haW5zJztcbmltcG9ydCB0eXBlIHtQcm9qZWN0aWxlT3JpZ2luVHJhY2tlcn0gZnJvbSAnLi9wcm9qZWN0aWxlLW9yaWdpbnMnO1xuaW1wb3J0IHsgcHJvamVjdEFjdGlvbkZyYW1lLCBwcm9qZWN0UGFwZXJEaXJlY3Rpb24gfSBmcm9tICcuL2FydC9hY3Rpb24tZGlyZWN0aW9uJztcbmltcG9ydCB7IElETEVfRlJBTUUgfSBmcm9tICcuL3VuaXQtYW5pbWF0aW9uJztcbmltcG9ydCB7IGRyYXdDb21iYXRHcm91bmQsIGRyYXdDb21iYXRCb2R5LCBkcmF3Q29tYmF0QWlyIH0gZnJvbSBcIi4vYXJ0L2NvbWJhdC1lZmZlY3RzXCI7XG5pbXBvcnQgdHlwZSB7IENvbWJhdFByZXNlbnRhdGlvblRyYWNrZXIsIENvbWJhdFByZXNlbnRhdGlvbkZyYW1lIH0gZnJvbSBcIi4vY29tYmF0LXByZXNlbnRhdGlvblwiO1xuaW1wb3J0IHsgYXBwZWFyYW5jZUZvciwgY29ycHNlQXBwZWFyYW5jZUZvciB9IGZyb20gXCIuL2FydC91bml0LWFwcGVhcmFuY2VcIjtcbmltcG9ydCB7IGl0ZW1FcXVpcHBlZCwgaXRlbXNGb3IgfSBmcm9tIFwiLi4vc2hhcmVkL2VxdWlwbWVudFwiO1xuaW1wb3J0IHsgcGxheWVyQ29sb3IgfSBmcm9tICcuLi9zaGFyZWQvcGxheWVyLWNvbG9ycyc7XG5pbXBvcnQgeyBkcmF3Q2FudmFzU2hpcCxkZWNrVmlzdWFsSGVpZ2h0LGRyYXdTaGlwRmxhZyB9IGZyb20gXCIuL2FydC9jYW52YXMtc2hpcHNcIjtcbmltcG9ydCB7IGlzSW5DYWJpbiB9IGZyb20gJy4uL3NoYXJlZC9zaGlwLWNhYmluJztcbmltcG9ydCB7IGxvY2FsVG9Xb3JsZCxzaGlwUHJvZmlsZSxzaGFyZVNoaXBQcm9maWxlLHNoaXBQYXNzZW5nZXJzLFNISVBfQ0FNRVJBIH0gZnJvbSBcIi4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5XCI7XG5pbXBvcnQgeyBnYW5nd2F5U3VyZmFjZSwgdHlwZSBHYW5nd2F5U3VyZmFjZSB9IGZyb20gJy4uL3NoYXJlZC9zaGlwLWdhbmd3YXknO1xuaW1wb3J0IHsgZ2FuZ3dheUNyZXdWaXN1YWxQb3NlIH0gZnJvbSAnLi9zaGlwLWdhbmd3YXktdmlzdWFsJztcbmltcG9ydCB7IGhlYWx0aEJhckNvbG9yLCBzaG91bGRTaG93SGVhbHRoQmFyIH0gZnJvbSBcIi4vaGVhbHRoLWJhcnNcIjtcbmltcG9ydCB7IGRyYXdQYWludGVkSXRlbSB9IGZyb20gXCIuL2FydC9pdGVtc1wiO1xuaW1wb3J0IHR5cGUgeyBTaXRlTW9kZWxLaW5kIH0gZnJvbSBcIi4vYXJ0L2J1aWxkaW5nLW1vZGVsc1wiO1xuaW1wb3J0IHsgU0lNX1RJQ0tTX1BFUl9TRUNPTkQgfSBmcm9tIFwiLi4vc2hhcmVkL3RpbWVcIjtcbmltcG9ydCB7IGRyYXdBdGxhc0NvcnBzZSwgZHJhd0F0bGFzQnVpbGRpbmcsIGRyYXdBdGxhc0NhbXAsIGRyYXdBdGxhc0dyb3VuZCwgZHJhd0F0bGFzTGFuZG1hcmssIGRyYXdBdGxhc01pbmUsIGRyYXdBdGxhc01vZGVsLCBkcmF3QXRsYXNPYnN0YWNsZSwgZHJhd0F0bGFzU2hvcCwgZHJhd0F0bGFzVW5pdCwgb2JzdGFjbGVBcnRUb3AgfSBmcm9tIFwiLi9hdGxhcy1hcnRcIjtcbmltcG9ydCB7IHJlbmRlcldvcmxkRWZmZWN0cyB9IGZyb20gXCIuL2VmZmVjdC1yZW5kZXJlclwiO1xuaW1wb3J0IHsgZHJhd1Njb3JjaGVkVW5pdEZsYW1lcyB9IGZyb20gXCIuL2FydC9jYW52YXMtZWZmZWN0c1wiO1xuaW1wb3J0IHsgYmF0dGxlZmllbGRFZmZlY3RGcmFtZSwgZHJhd1VuaXRTdGF0dXNFZmZlY3RzIH0gZnJvbSAnLi9hYmlsaXR5LWVmZmVjdHMnO1xuaW1wb3J0IHsgZm9vdHByaW50U3F1YXJlIH0gZnJvbSBcIi4vZm9vdHByaW50LXZpZXdcIjtcbmltcG9ydCB7IGNyZWF0dXJlU2hhZG93IH0gZnJvbSBcIi4vYXJ0L3BhaW50ZWQtY3JlYXR1cmVzXCI7XG5pbXBvcnQgeyB1bml0R2x5cGhTY2FsZSB9IGZyb20gXCIuL2dseXBoc1wiO1xuaW1wb3J0IHR5cGUgeyBjcmVhdGVJMThuIH0gZnJvbSBcIi4vaTE4blwiO1xuaW1wb3J0IHsgZHJhd0xldmVsU3RhciB9IGZyb20gXCIuL2xldmVsLXN0YXJcIjtcbmltcG9ydCB7IHNob3VsZFJlbmRlckJ1aWxkaW5nUmFsbHkgfSBmcm9tIFwiLi9yYWxseS12aXN1YWxcIjtcbmltcG9ydCB7IFJFTEFUSU9OX0lOSywgcmVsYXRpb25UbyB9IGZyb20gXCIuL3JlbGF0aW9uc1wiO1xuaW1wb3J0IHsgZHJhd1RlcnJhaW4gfSBmcm9tIFwiLi90ZXJyYWluLWFydFwiO1xuaW1wb3J0IHsgZ2VuZXJhdGVUZXJyYWluTGluZXdvcmssIHR5cGUgVGV4dHVyZVN0cm9rZSB9IGZyb20gXCIuL3RlcnJhaW4tdGV4dHVyZVwiO1xuaW1wb3J0IHsgdHJhaW5pbmdRdWV1ZUNvdW50VGV4dCB9IGZyb20gXCIuL3RyYWluaW5nLXF1ZXVlXCI7XG5pbXBvcnQgdHlwZSB7IFVuaXRGYWNpbmdUcmFja2VyIH0gZnJvbSBcIi4vdW5pdC1mYWNpbmdcIjtcbmltcG9ydCB0eXBlIHsgVW5pdE1vdGlvblNtb290aGVyIH0gZnJvbSBcIi4vdW5pdC1tb3Rpb25cIjtcbmltcG9ydCB0eXBlIHsgVW5pdEFuaW1hdGlvblRyYWNrZXIgfSBmcm9tIFwiLi91bml0LWFuaW1hdGlvblwiO1xuaW1wb3J0IHR5cGUgeyBTaGlwV2FrZVRyYWNrZXIgfSBmcm9tICcuL3NoaXAtd2FrZXMnO1xuaW1wb3J0IHsgZHJhd1N0b3J5QWlyLCBkcmF3U3RvcnlHcm91bmQsIGRyYXdTdG9yeVByb3BzLCBkcmF3U3RvcnlTY3JlZW4gfSBmcm9tIFwiLi9zdG9yeS1yZW5kZXJlclwiO1xuaW1wb3J0IHR5cGUgeyBQcm9wUGFpbnRlciwgVW5pdE1vZGVsIH0gZnJvbSBcIi4uL3N0b3J5L2Nhc3RcIjtcbmltcG9ydCB0eXBlIHsgU3RhZ2VWaWV3IH0gZnJvbSBcIi4uL3N0b3J5L3N0YWdlXCI7XG5pbXBvcnQgeyBCVUlMRElOR19ERUZTLCBVTklUX0RFRlMsIHVuaXRNb3ZlciB9IGZyb20gXCIuLi9zaGFyZWQvY2F0YWxvZ1wiO1xuaW1wb3J0IHR5cGUgeyBCdWlsZGluZywgQnVpbGRpbmdLaW5kLCBHYW1lU25hcHNob3QsIE1hcElkLCBNZXJjZW5hcnlDYW1wLCBPYnN0YWNsZSwgT3duZXIsIFBsYXllcklkLCBSZXNvdXJjZU5vZGUsIFNob3AsIFRlcnJhaW5MYW5kbWFyaywgVHJhaW5hYmxlVW5pdEtpbmQsIFVuaXQsIFdvcmxkSXRlbSxXb3JsZEVmZmVjdCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcblxudHlwZSBQb2ludCA9IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfTtcbnR5cGUgQnJ1c2ggPSBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQ7XG5cbi8vIEBAQHdvcmxkLXJlbmRlcmVyIC0gT25lIGZyYW1lIG9mIHRoZSBiYXR0bGVmaWVsZCwgZHJhd24gZnJvbSBhIHNuYXBzaG90IHdpdGggbm8gRE9NOiB0aGUgYnJvd3NlciBjbGllbnQgYW5kIHRoZVxuLy8gaGVhZGxlc3MgcmVjb3JkZXIgYm90aCBjYWxsIGRyYXdXb3JsZCwgc28gYSBjaGFuZ2UgdG8gaG93IHRoZSB3b3JsZCBsb29rcyByZWFjaGVzIHJlY29yZGluZ3MgdG9vLlxuXG4vKiogV2hhdCB0aGUgdmlldyBsb29rcyBhdDogYHhgL2B5YCBpcyB0aGUgd29ybGQgcG9pbnQgYXQgdGhlIGNhbnZhcydzIHRvcC1sZWZ0OyBgem9vbWAgc2NhbGVzIHdvcmxkIHVuaXRzIHRvIHBpeGVscy4gKi9cbmV4cG9ydCB0eXBlIFdvcmxkVmlldyA9IHtcbiAgeDogbnVtYmVyO1xuICB5OiBudW1iZXI7XG4gIHdpZHRoOiBudW1iZXI7XG4gIGhlaWdodDogbnVtYmVyO1xuICB6b29tPzogbnVtYmVyO1xufTtcblxuLyoqIFRoZSBmZXcgd29yZHMgcGFpbnRlZCBpbnRvIHRoZSB3b3JsZCwgaW4gdGhlIHZpZXdlcidzIGxhbmd1YWdlLiAqL1xuZXhwb3J0IHR5cGUgV29ybGRMYWJlbHMgPSB7XG4gIG1lcmNlbmFyeVN0b2NrOiAoc3RvY2s6IG51bWJlcikgPT4gc3RyaW5nO1xuICB1bml0S2luZDogKGtpbmQ6IFRyYWluYWJsZVVuaXRLaW5kKSA9PiBzdHJpbmc7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gd29ybGRMYWJlbHNGb3IoaTE4bjogUmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlSTE4bj4pOiBXb3JsZExhYmVscyB7XG4gIHJldHVybiB7XG4gICAgbWVyY2VuYXJ5U3RvY2s6IChzdG9jaykgPT4gaTE4bi50KFwiY2FudmFzLm1lcmNlbmFyeVN0b2NrXCIsIHsgc3RvY2sgfSksXG4gICAgdW5pdEtpbmQ6IChraW5kKSA9PiBpMThuLmxhYmVsKGtpbmQpLFxuICB9O1xufVxuXG5leHBvcnQgdHlwZSBXb3JsZEZyYW1lID0ge1xuICAvKiogU2hhcmVkIHNuYXBzaG90IGluZGV4IGFjcm9zcyB0aGUgR1BVLCBncm91bmQgYW5kIGFubm90YXRpb24gcGFzc2VzLiAqL1xuICB2aWV3SW5kZXg/OlByZXNlbnRhdGlvblZpZXdJbmRleDtcbiAgLyoqIFRlcnJhaW4gYW5kIGFubm90YXRpb25zIGZsYW5rIHRoZSBzaGFyZWQgR1BVIGRlcHRoIGxheWVyLiBSZWNvcmRlci9mYWxsYmFja1xuICAgKiBjYWxsZXJzIG9taXQgdGhpcyBhbmQgcmV0YWluIHRoZSBjb21wbGV0ZSBDYW52YXMgcmVuZGVyZXIuICovXG4gIHBhc3M/OiAnZ3JvdW5kJyB8ICdvdmVybGF5JztcbiAgYWN0b3JQb3NpdGlvbnM/OiBSZWFkb25seU1hcDxzdHJpbmcse3g6bnVtYmVyO3k6bnVtYmVyO2JvZHlZOm51bWJlcjt0b3BZOm51bWJlcjtmYWNpbmc/OjF8LTF9PjtcbiAgcGh5c2ljYWxFZmZlY3RzPzogUmVhZG9ubHlTZXQ8V29ybGRFZmZlY3RbJ3R5cGUnXT47XG4gIHBoeXNpY2FsQ29tYmF0Pzpib29sZWFuO1xuICAvKiogU3VjY2Vzc2Z1bGx5IGRyYXduIEdQVSBncm91bmQvZGVjayBtYXJrZXJzIG93biB0aGVpciBkZXB0aCwgbm90IHRoZSBIVUQgY2FudmFzLiAqL1xuICBkZXB0aFNlbGVjdGlvbj86Ym9vbGVhbjtcbiAgLyoqIE9wdGlvbmFsIHBlci1tYXRjaCBwb3NlIGhpc3RvcnkuIE9taXQgZm9yIHN0YXRpYyBkaWFncmFtcyBhbmQgcG9ydHJhaXRzLiAqL1xuICBhbmltYXRpb24/OiBVbml0QW5pbWF0aW9uVHJhY2tlcjtcbiAgY29tYmF0PzogQ29tYmF0UHJlc2VudGF0aW9uVHJhY2tlcjtcbiAgcHJvamVjdGlsZXM/OlByb2plY3RpbGVPcmlnaW5UcmFja2VyO1xuICB3YWtlcz86IFNoaXBXYWtlVHJhY2tlcjtcbiAgcmVkdWNlZE1vdGlvbj86IGJvb2xlYW47XG4gIGN0eDogQnJ1c2g7XG4gIHNuYXBzaG90OiBHYW1lU25hcHNob3Q7XG4gIHZpZXc6IFdvcmxkVmlldztcbiAgLyoqIEFuaW1hdGlvbiBjbG9jayBpbiBtaWxsaXNlY29uZHMgKGZsYW1lcywgYXVyYXMsIGJvYmJpbmcgaXRlbXMpLiAqL1xuICBub3c6IG51bWJlcjtcbiAgZmFjaW5nOiBVbml0RmFjaW5nVHJhY2tlcjtcbiAgLyoqIEdsaWRlcyBjaGFyZ2luZyByaWRlcnMgYmV0d2VlbiBzbmFwc2hvdHMgYnkgYG5vd2AgKHNlZSB1bml0LW1vdGlvbik7IHdpdGhvdXQgaXQgdW5pdHMgYXJlIGRyYXduIGF0IHRoZWlyIHNuYXBzaG90IHNwb3RzLiAqL1xuICBtb3Rpb24/OiBVbml0TW90aW9uU21vb3RoZXI7XG4gIGxhYmVsczogV29ybGRMYWJlbHM7XG4gIHNlbGVjdGVkSWRzPzogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgY29udHJvbEdyb3Vwcz86IFJlYWRvbmx5PFJlY29yZDxzdHJpbmcsIHJlYWRvbmx5IHN0cmluZ1tdPj47XG4gIHNlbGVjdGVkQ2FtcElkPzogc3RyaW5nO1xuICAvKiogVGhlIHBsYXllciBsb29raW5nIG9uOiByaW5ncyBhcmUgaW4gZnJpZW5kLW9yLWZvZSBjb2xvdXJzIHRvIHRoZW0gKHNlZSBAQEByZWxhdGlvbi1pbmspOyB3aXRob3V0IG9uZSwgdGhlIG93bmVycycuICovXG4gIHZpZXdlcj86IFBsYXllcklkO1xuICAvKiogVGhlIHVuaXQgb3IgYnVpbGRpbmcgdW5kZXIgdGhlIHBvaW50ZXI6IHJpbmdlZCB0aGlubHksIGFzIGEgc2VsZWN0ZWQgb25lIGlzLiAqL1xuICBob3ZlcmVkSWQ/OiBzdHJpbmc7XG4gIC8qKiBBIGNhbXBhaWduJ3Mgb3duIHVuaXRzJyBtb2RlbHMsIGJ5IHZhcmlhbnQgKHNlZSBzdG9yeS9jYXN0KTsgd2l0aG91dCBpdCBhIHZhcmlhbnQgaXMgZHJhd24gYXMgaXRzIGJhc2Uga2luZC4gKi9cbiAgYnVpbGRpbmdNb2RlbHM/OiBSZWFkb25seTxSZWNvcmQ8c3RyaW5nLFNpdGVNb2RlbEtpbmQ+PjtcbiAgbW9kZWxzPzogKHZhcmlhbnQ6IHN0cmluZykgPT4gVW5pdE1vZGVsIHwgdW5kZWZpbmVkO1xuICAvKiogQSBjYW1wYWlnbidzIHNjZW5lcnkgcGFpbnRlcnMsIGJ5IHByb3Aga2luZCAoc2VlIHN0b3J5L3N0YWdlIHByb3BzKS4gKi9cbiAgcHJvcHM/OiAoa2luZDogc3RyaW5nKSA9PiBQcm9wUGFpbnRlciB8IHVuZGVmaW5lZDtcbiAgLyoqIFRoZSBzdG9yeSdzIHN0YWdlIChzZWUgc3Rvcnkvc3RhZ2UpOiBidWJibGVzLCB0aXRsZXMsIG9iamVjdGl2ZXMgYW5kIHRoZSByZXN0LCBkcmF3biBvdmVyIHRoZSB3b3JsZC4gKi9cbiAgc3Rvcnk/OiBTdGFnZVZpZXc7XG4gIGxvY2FsZT86IFwiemhcIiB8IFwiZW5cIjtcbiAgLyoqIEEgcGljdHVyZSBvZiB0aGUgd29ybGQgcmF0aGVyIHRoYW4gYSBtYXRjaCAoc2VlIEBAQG1lbnUtc2NlbmUpOiBubyBoZWFsdGggYmFycywgbm8gZ29sZCBjb3VudHMuICovXG4gIHN0aWxsPzogYm9vbGVhbjtcbn07XG5cbnR5cGUgUGFpbnRlciA9IHtcbiAgdmlld0luZGV4OlByZXNlbnRhdGlvblZpZXdJbmRleDtcbiAgc2hpcHM6IFJlYWRvbmx5TWFwPHN0cmluZywgVW5pdD47XG4gIGdhbmd3YXlzOiBSZWFkb25seU1hcDxzdHJpbmcsIEdhbmd3YXlTdXJmYWNlPjtcbiAgYWN0b3JQb3NpdGlvbnM6IFdvcmxkRnJhbWVbJ2FjdG9yUG9zaXRpb25zJ107XG4gIGFuaW1hdGlvbjogVW5pdEFuaW1hdGlvblRyYWNrZXIgfCB1bmRlZmluZWQ7XG4gIHJlZHVjZWRNb3Rpb246IGJvb2xlYW47XG4gIGN0eDogQnJ1c2g7XG4gIHNuYXBzaG90OiBHYW1lU25hcHNob3Q7XG4gIGNhbWVyYTogUG9pbnQ7XG4gIHdpZHRoOiBudW1iZXI7XG4gIGhlaWdodDogbnVtYmVyO1xuICBub3c6IG51bWJlcjtcbiAgZmFjaW5nOiBVbml0RmFjaW5nVHJhY2tlcjtcbiAgbW90aW9uOiBVbml0TW90aW9uU21vb3RoZXIgfCB1bmRlZmluZWQ7XG4gIGxhYmVsczogV29ybGRMYWJlbHM7XG4gIHNlbGVjdGVkSWRzOiBSZWFkb25seVNldDxzdHJpbmc+O1xuICBjb250cm9sR3JvdXBzOiBXb3JsZEZyYW1lW1wiY29udHJvbEdyb3Vwc1wiXTtcbiAgc2VsZWN0ZWRDYW1wSWQ6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgdmlld2VyOiBQbGF5ZXJJZCB8IHVuZGVmaW5lZDtcbiAgaG92ZXJlZElkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIG1vZGVsczogV29ybGRGcmFtZVtcIm1vZGVsc1wiXTtcbiAgYnVpbGRpbmdNb2RlbHM6IFdvcmxkRnJhbWVbXCJidWlsZGluZ01vZGVsc1wiXTtcbiAgc3RpbGw6IGJvb2xlYW47XG4gIGVuZ2FnZWQ6UmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgYWJpbGl0eUVmZmVjdHM/OlJldHVyblR5cGU8dHlwZW9mIGJhdHRsZWZpZWxkRWZmZWN0RnJhbWU+O1xuICBjb21iYXRCb2R5PzpSZWFkb25seU1hcDxzdHJpbmcsQ29tYmF0UHJlc2VudGF0aW9uRnJhbWVbXCJib2R5XCJdPjtcbn07XG5cbmNvbnN0IE5PX1NFTEVDVElPTjogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKTtcbmNvbnN0IGNhbnZhc1ZpZXdJbmRleGVzPW5ldyBXZWFrTWFwPEJydXNoLFByZXNlbnRhdGlvblZpZXdJbmRleD4oKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGRyYXdXb3JsZChmcmFtZTogV29ybGRGcmFtZSkge1xuICBjb25zdCB6b29tID0gZnJhbWUudmlldy56b29tID8/IDE7XG4gIGxldCB2aWV3SW5kZXg9ZnJhbWUudmlld0luZGV4Pz9jYW52YXNWaWV3SW5kZXhlcy5nZXQoZnJhbWUuY3R4KTtcbiAgaWYoIXZpZXdJbmRleCl7dmlld0luZGV4PW5ldyBQcmVzZW50YXRpb25WaWV3SW5kZXgoKTtjYW52YXNWaWV3SW5kZXhlcy5zZXQoZnJhbWUuY3R4LHZpZXdJbmRleCk7fVxuICBjb25zdCBzaGlwcyA9IG5ldyBNYXA8c3RyaW5nLCBVbml0PigpLCBnYW5nd2F5cyA9IG5ldyBNYXA8c3RyaW5nLCBHYW5nd2F5U3VyZmFjZT4oKTtcbiAgY29uc3QgcGFpbnRlcjogUGFpbnRlciA9IHtcbiAgICB2aWV3SW5kZXgsXG4gICAgc2hpcHMsXG4gICAgZ2FuZ3dheXMsXG4gICAgYWN0b3JQb3NpdGlvbnM6IGZyYW1lLmFjdG9yUG9zaXRpb25zLFxuICAgIGFuaW1hdGlvbjogZnJhbWUuYW5pbWF0aW9uLFxuICAgIHJlZHVjZWRNb3Rpb246IGZyYW1lLnJlZHVjZWRNb3Rpb24gPz8gZmFsc2UsXG4gICAgY3R4OiBmcmFtZS5jdHgsXG4gICAgc25hcHNob3Q6IGZyYW1lLnNuYXBzaG90LFxuICAgIGNhbWVyYTogeyB4OiBmcmFtZS52aWV3LngsIHk6IGZyYW1lLnZpZXcueSB9LFxuICAgIHdpZHRoOiBmcmFtZS52aWV3LndpZHRoIC8gem9vbSxcbiAgICBoZWlnaHQ6IGZyYW1lLnZpZXcuaGVpZ2h0IC8gem9vbSxcbiAgICBub3c6IGZyYW1lLm5vdyxcbiAgICBmYWNpbmc6IGZyYW1lLmZhY2luZyxcbiAgICBtb3Rpb246IGZyYW1lLm1vdGlvbixcbiAgICBsYWJlbHM6IGZyYW1lLmxhYmVscyxcbiAgICBzZWxlY3RlZElkczogZnJhbWUuc2VsZWN0ZWRJZHMgPz8gTk9fU0VMRUNUSU9OLFxuICAgIGNvbnRyb2xHcm91cHM6IGZyYW1lLmNvbnRyb2xHcm91cHMsXG4gICAgc2VsZWN0ZWRDYW1wSWQ6IGZyYW1lLnNlbGVjdGVkQ2FtcElkLFxuICAgIHZpZXdlcjogZnJhbWUudmlld2VyLFxuICAgIGhvdmVyZWRJZDogZnJhbWUuaG92ZXJlZElkLFxuICAgIG1vZGVsczogZnJhbWUubW9kZWxzLFxuICAgIGJ1aWxkaW5nTW9kZWxzOiBmcmFtZS5idWlsZGluZ01vZGVscyxcbiAgICBzdGlsbDogZnJhbWUuc3RpbGwgPz8gZmFsc2UsXG4gICAgZW5nYWdlZDpOT19TRUxFQ1RJT04sXG4gIH07XG4gIGNvbnN0IHsgY3R4LCBzbmFwc2hvdCB9ID0gcGFpbnRlcjtcbiAgcGFpbnRlci5tb3Rpb24/LnVwZGF0ZShzbmFwc2hvdCwgcGFpbnRlci5ub3cpO1xuICB2aWV3SW5kZXgudXBkYXRlKHNuYXBzaG90LHBhaW50ZXIubW90aW9uKTtcbiAgLy8gVGhlIEdQVSBwYXNzIGFscmVhZHkgc3VwcGxpZXMgY3JldyBwb3NpdGlvbnMuIFRoZSBDYW52YXMgZmFsbGJhY2sgb3duc1xuICAvLyBpdHMgYnJpZGdlIHByb29mIG9uY2UgcGVyIGJyaWRnZSBhbmQgc2hhcmVzIGl0IHdpdGggZXZlcnkgY3Jvc3NpbmcgcGVyc29uLlxuICBpZiAoIWZyYW1lLmFjdG9yUG9zaXRpb25zKSB7XG4gICAgZm9yIChjb25zdCBzaGlwIG9mIHNuYXBzaG90LnVuaXRzKSBpZiAoc2hpcFByb2ZpbGUoc2hpcCkpIHtcbiAgICAgIGNvbnN0IGRpc3BsYXllZCA9IHsgLi4uc2hpcCwgLi4ucGFpbnRlci5tb3Rpb24/LnBvc2l0aW9uKHNoaXAsIHBhaW50ZXIubm93KSwgc2FpbGluZzogeyAuLi5zaGlwLnNhaWxpbmchLCBoZWFkaW5nOiBwYWludGVyLm1vdGlvbj8uaGVhZGluZyhzaGlwLCBwYWludGVyLm5vdykgPz8gc2hpcC5zYWlsaW5nPy5oZWFkaW5nID8/IDAgfSB9O1xuICAgICAgc2hhcmVTaGlwUHJvZmlsZShzaGlwLCBkaXNwbGF5ZWQpOyBzaGlwcy5zZXQoc2hpcC5pZCwgZGlzcGxheWVkKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBzb3VyY2Ugb2Ygc2hpcHMudmFsdWVzKCkpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHNvdXJjZS5zYWlsaW5nPy5nYW5nd2F5ICYmIHNoaXBzLmdldChzb3VyY2Uuc2FpbGluZy5nYW5nd2F5LnRhcmdldElkKTtcbiAgICAgIGNvbnN0IHN1cmZhY2UgPSB0YXJnZXQgJiYgZ2FuZ3dheVN1cmZhY2Uoc291cmNlLCB0YXJnZXQpO1xuICAgICAgaWYgKHN1cmZhY2UpIGdhbmd3YXlzLnNldChzb3VyY2UuaWQsIHN1cmZhY2UpO1xuICAgIH1cbiAgfVxuICBwYWludGVyLmFuaW1hdGlvbj8udXBkYXRlKHNuYXBzaG90LCBwYWludGVyLm5vdywgZnJhbWUuc3Rvcnk/LnVuaXRBY3Rpb25zKTtcbiAgaWYoIWZyYW1lLnJlZHVjZWRNb3Rpb24gJiYgZnJhbWUucGFzcyE9PSdvdmVybGF5JylmcmFtZS53YWtlcz8udXBkYXRlKHNuYXBzaG90LHBhaW50ZXIubm93KTtcbiAgaWYoIWZyYW1lLmFjdG9yUG9zaXRpb25zKXtcbiAgICB0cmFja1VuaXRGYWNpbmcocGFpbnRlci5mYWNpbmcscGFpbnRlci5zbmFwc2hvdCx2aWV3SW5kZXguZW50aXRpZXMpO1xuICAgIHBhaW50ZXIuYW5pbWF0aW9uPy5vYnNlcnZlRGlyZWN0aW9ucyhwYWludGVyLm5vdywoaWQsZGlyZWN0aW9uKT0+cGFpbnRlci5mYWNpbmcuYWN0aW9uRmFjaW5nKGlkLGRpcmVjdGlvbixwcm9qZWN0UGFwZXJEaXJlY3Rpb24pLHBhaW50ZXIucmVkdWNlZE1vdGlvbik7XG4gIH1cbiAgaWYoIWZyYW1lLnBoeXNpY2FsQ29tYmF0KWZyYW1lLmNvbWJhdD8udXBkYXRlKHNuYXBzaG90LHBhaW50ZXIubm93LGJsb29kU3VyZmFjZVJlc29sdmVyKHNuYXBzaG90LGZyYW1lLmFuaW1hdGlvbixmcmFtZS5mYWNpbmcsZnJhbWUubW9kZWxzLGZyYW1lLnJlZHVjZWRNb3Rpb24sZnJhbWUubW9kZWxzPy44OjEpLGFyZWFzPT52aWV3SW5kZXgucXVlcnlCb3VuZHNVbmlvbihhcmVhcykpO1xuICBmcmFtZS5wcm9qZWN0aWxlcz8udXBkYXRlKHNuYXBzaG90LGZyYW1lLm1vZGVscyxpZD0+ZnJhbWUuZmFjaW5nLnJlbGVhc2VGYWNpbmcoaWQpKTtcbiAgY29uc3QgY29tYmF0PWZyYW1lLmNvbWJhdD8uZnJhbWUocGFpbnRlci5ub3cpO1xuICBpZihjb21iYXQmJiFmcmFtZS5waHlzaWNhbENvbWJhdCl7XG4gICAgY29uc3QgYm9keT1uZXcgTWFwPHN0cmluZyxDb21iYXRQcmVzZW50YXRpb25GcmFtZVtcImJvZHlcIl0+KCk7XG4gICAgZm9yKGNvbnN0IG1hcmsgb2YgY29tYmF0LmJvZHkpe2NvbnN0IGxpc3Q9Ym9keS5nZXQobWFyay51bml0SWQpPz9bXTtsaXN0LnB1c2gobWFyayk7Ym9keS5zZXQobWFyay51bml0SWQsbGlzdCk7fVxuICAgIHBhaW50ZXIuY29tYmF0Qm9keT1ib2R5O1xuICB9XG4gIGNvbnN0IGNvbWJhdFByb2plY3Rpb249e3dvcmxkVG9TY3JlZW46KHBvaW50OlBvaW50KT0+d29ybGRUb1NjcmVlbihwYWludGVyLHBvaW50KSxuZWFyU2NyZWVuOihwb2ludDpQb2ludCxwYWQ6bnVtYmVyKT0+bmVhclNjcmVlbihwYWludGVyLHBvaW50LHBhZCl9O1xuICBjdHguc2F2ZSgpO1xuICBjdHguc2NhbGUoem9vbSwgem9vbSk7XG4gIGlmKGZyYW1lLnBhc3MhPT0nb3ZlcmxheScpe1xuICBpZiAoc25hcHNob3QubWFwLnRlcnJhaW4pIHtcbiAgICAvLyBBIG1hcCB3aXRoIHRlcnJhaW4gaXMgaXRzIG93biBncm91bmQgKHNlZSBAQEB0ZXJyYWluLWFydCk6IHRoZSBwYXBlciB1bmRlciBpdCwgbm8gbWFwIGlkJ3MgbGluZXdvcmsuXG4gICAgZHJhd0F0bGFzR3JvdW5kKGN0eCwgcGFpbnRlci53aWR0aCwgcGFpbnRlci5oZWlnaHQsIHBhaW50ZXIuY2FtZXJhKTtcbiAgICBkcmF3VGVycmFpbihjdHgsIHNuYXBzaG90Lm1hcC50ZXJyYWluLCBwYWludGVyLmNhbWVyYSwgcGFpbnRlci53aWR0aCwgcGFpbnRlci5oZWlnaHQsXG4gICAgICBmcmFtZS5wYXNzID09PSAnZ3JvdW5kJyB8fCBwYWludGVyLnJlZHVjZWRNb3Rpb24gPyB1bmRlZmluZWQgOiBwYWludGVyLm5vdyAvIDEwMDApO1xuICB9IGVsc2Uge1xuICAgIGRyYXdQYXBlck1hcChjdHgsIHNuYXBzaG90Lm1hcC5pZCwgcGFpbnRlci5jYW1lcmEsIHBhaW50ZXIud2lkdGgsIHBhaW50ZXIuaGVpZ2h0KTtcbiAgfVxuICBpZighZnJhbWUucmVkdWNlZE1vdGlvbilmcmFtZS53YWtlcz8uZHJhdyhjdHgsey4uLnBhaW50ZXIuY2FtZXJhLHdpZHRoOnBhaW50ZXIud2lkdGgsaGVpZ2h0OnBhaW50ZXIuaGVpZ2h0fSxwYWludGVyLm5vdyk7XG4gIGRyYXdMYW5kbWFya3MocGFpbnRlciwgc25hcHNob3QubWFwLmxhbmRtYXJrcyk7XG4gIGlmKCFmcmFtZS5kZXB0aFNlbGVjdGlvbilkcmF3R3JvdW5kU2VsZWN0aW9uTWFya2VycyhwYWludGVyKTtcbiAgaWYgKGZyYW1lLnN0b3J5ICYmIGZyYW1lLnByb3BzKSBkcmF3U3RvcnlQcm9wcyhjdHgsIHsuLi5mcmFtZS5zdG9yeSxwcm9wczpmcmFtZS5zdG9yeS5wcm9wcy5maWx0ZXIocHJvcD0+IWZyYW1lLmFjdG9yUG9zaXRpb25zPy5oYXMoYHByb3A6JHtwcm9wLmlkfWApKX0sIChwb2ludCkgPT4gd29ybGRUb1NjcmVlbihwYWludGVyLCBwb2ludCksIChwb2ludCwgcGFkKSA9PiBuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCBwYWQpLCBmcmFtZS5wcm9wcywgcGFpbnRlci5ub3cpO1xuICBkcmF3UmVzb3VyY2VzKHBhaW50ZXIsIHNuYXBzaG90LnJlc291cmNlcyk7XG4gIGRyYXdNZXJjZW5hcnlDYW1wcyhwYWludGVyLCBzbmFwc2hvdC5tZXJjZW5hcnlDYW1wcyxmYWxzZSxmcmFtZS5wYXNzPT09J2dyb3VuZCcpO1xuICBpZiAoc25hcHNob3Quc2hvcHMpIGRyYXdTaG9wcyhwYWludGVyLCBzbmFwc2hvdC5zaG9wcyxmYWxzZSxmcmFtZS5wYXNzPT09J2dyb3VuZCcpO1xuICBkcmF3T2JzdGFjbGVzKHBhaW50ZXIsIHNuYXBzaG90Lm9ic3RhY2xlcyA/PyBbXSk7XG4gIGRyYXdJdGVtcyhwYWludGVyLCBzbmFwc2hvdC5pdGVtcyk7XG4gIGlmIChmcmFtZS5zdG9yeSkgZHJhd1N0b3J5R3JvdW5kKGN0eCwgZnJhbWUuc3RvcnksIChwb2ludCkgPT4gd29ybGRUb1NjcmVlbihwYWludGVyLCBwb2ludCksIChwb2ludCwgcGFkKSA9PiBuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCBwYWQpKTtcbiAgaWYoY29tYmF0KWRyYXdDb21iYXRHcm91bmQoY3R4LGNvbWJhdCxjb21iYXRQcm9qZWN0aW9uKTtcbiAgLy8gUGVyc2lzdGVudCBncm91bmQgbGF5ZXI6IHdlYXRoZXIgdG8gYSBmYWludCBza2V0Y2gsIG5ldmVyIGRpc2FwcGVhci5cbiAgZm9yKGNvbnN0IGNvcnBzZSBvZiBzbmFwc2hvdC5jb3Jwc2VzID8/IFtdKXtcbiAgICBpZihjb3Jwc2UuZGVjayljb250aW51ZTtcbiAgICBjb25zdCBwb2ludD13b3JsZFRvU2NyZWVuKHBhaW50ZXIsY29ycHNlKTtcbiAgICBpZighbmVhclNjcmVlbihwYWludGVyLHBvaW50LDkwKSljb250aW51ZTtcbiAgICBjdHguc2F2ZSgpO2N0eC5nbG9iYWxBbHBoYSo9cmVtYWluc09wYWNpdHkoc25hcHNob3QudGljayxjb3Jwc2UuZGllZEF0VGljayk7XG4gICAgY29uc3QgbW9kZWw9Y29ycHNlLnZhcmlhbnQgPyBmcmFtZS5tb2RlbHM/Lihjb3Jwc2UudmFyaWFudCkgOiB1bmRlZmluZWQ7XG4gICAgZHJhd0F0bGFzQ29ycHNlKGN0eCxjb3Jwc2Uua2luZCxwb2ludCxtb2RlbCA/IE1hdGgubWF4KC43Mixjb3Jwc2UucmFkaXVzLzE4KSA6IHVuaXRHbHlwaFNjYWxlKGNvcnBzZS5yYWRpdXMpLHJlbWFpbnNWYXJpYW50KGNvcnBzZS5pZCksbW9kZWwsY29ycHNlLnZhcmlhbnQsb3duZXJJbmsoY29ycHNlLm93bmVyLHNuYXBzaG90KSxjb3Jwc2VBcHBlYXJhbmNlRm9yKHNuYXBzaG90LGNvcnBzZSkpO2N0eC5yZXN0b3JlKCk7XG4gIH1cbiAgfVxuICBpZihmcmFtZS5wYXNzPT09J2dyb3VuZCcpe2N0eC5yZXN0b3JlKCk7cmV0dXJuO31cbiAgcGFpbnRlci5lbmdhZ2VkPXZpZXdJbmRleC5lbmdhZ2VkSWRzKCk7XG4gIHBhaW50ZXIuYWJpbGl0eUVmZmVjdHM9YmF0dGxlZmllbGRFZmZlY3RGcmFtZShzbmFwc2hvdCk7XG4gIGlmKGZyYW1lLnBhc3M9PT0nb3ZlcmxheScpe2RyYXdNZXJjZW5hcnlDYW1wcyhwYWludGVyLHNuYXBzaG90Lm1lcmNlbmFyeUNhbXBzLHRydWUpO2lmKHNuYXBzaG90LnNob3BzKWRyYXdTaG9wcyhwYWludGVyLHNuYXBzaG90LnNob3BzLHRydWUpO31cbiAgLy8gUGxhbnMgYXJlIGEgcHJpdmF0ZSBvdmVybGF5OiB0aGV5IG5ldmVyIGVudGVyIHRhcmdldCwgdmlzaWJpbGl0eSBvciBwYXRoaW5nIGluZGV4ZXMuXG4gIGlmICghcGFpbnRlci5zdGlsbCAmJiBmcmFtZS52aWV3ZXIpIGZvciAoY29uc3Qgd29ya2VyIG9mIHZpZXdJbmRleC5idWlsZGVycykge1xuICAgIGlmIChpc0luQ2FiaW4od29ya2VyKSB8fCB3b3JrZXIub3duZXIgIT09IGZyYW1lLnZpZXdlciB8fCB3b3JrZXIub3JkZXIudHlwZSAhPT0gXCJidWlsZFwiKSBjb250aW51ZTtcbiAgICBjb25zdCBvcmRlciA9IHdvcmtlci5vcmRlciwgcG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIG9yZGVyKTtcbiAgICBpZiAoIW5lYXJTY3JlZW4ocGFpbnRlciwgcG9pbnQsIDEyMCkpIGNvbnRpbnVlO1xuICAgIGN0eC5zYXZlKCk7IGN0eC5nbG9iYWxBbHBoYSA9IC4yNDtcbiAgICBkcmF3QXRsYXNCdWlsZGluZyhjdHgsIG9yZGVyLmJ1aWxkaW5nS2luZCwgcG9pbnQsIGJ1aWxkaW5nR2x5cGhTaXplKG9yZGVyLmJ1aWxkaW5nS2luZCksIFwiI2JjYTU3N1wiKTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICAgIGlmICgoc25hcHNob3QucGxheWVyc1tmcmFtZS52aWV3ZXJdPy5nb2xkID8/IDApIDwgQlVJTERJTkdfREVGU1tvcmRlci5idWlsZGluZ0tpbmRdLmNvc3QpIHtcbiAgICAgIGN0eC5zYXZlKCk7IGN0eC5maWxsU3R5bGU9XCIjZTFjMjhjXCI7IGN0eC5mb250PVwiMTJweCBzYW5zLXNlcmlmXCI7IGN0eC50ZXh0QWxpZ249XCJjZW50ZXJcIjtcbiAgICAgIGN0eC5maWxsVGV4dChmcmFtZS5sb2NhbGUgPT09IFwiemhcIiA/IFwi562J5b6F6YeR5biBXCIgOiBcIldhaXRpbmcgZm9yIGdvbGRcIiwgcG9pbnQueCwgcG9pbnQueSs0MCk7IGN0eC5yZXN0b3JlKCk7XG4gICAgfVxuICB9XG4gIC8vIFNvcnQgZmVldCwgc28gYSBzb2xkaWVyIGJlaGluZCBhIHRhbGwgYnVpbGRpbmcgaXMgYWN0dWFsbHkgb2NjbHVkZWQgYnkgaXQuXG4gIGlmIChmcmFtZS5wYXNzICE9PSAnb3ZlcmxheScpIGRyYXdHYW5nd2F5cyhwYWludGVyKTtcbiAgY29uc3QgY2FuZGlkYXRlVW5pdHM9dmlld0luZGV4LnF1ZXJ5KGZyYW1lLnZpZXcpO1xuICBpZihmcmFtZS5wYXNzPT09J292ZXJsYXknKXtkcmF3QnVpbGRpbmdzKHBhaW50ZXIsc25hcHNob3QuYnVpbGRpbmdzLHRydWUpO2RyYXdVbml0cyhwYWludGVyLGNhbmRpZGF0ZVVuaXRzLHRydWUpO31cbiAgZWxzZSB7XG4gICAgY29uc3QgYWN0b3JzPVsuLi5zbmFwc2hvdC5idWlsZGluZ3MsLi4uY2FuZGlkYXRlVW5pdHMuZmlsdGVyKHVuaXQ9PiF1bml0LmRlY2spXS5maWx0ZXIoYT0+bmVhclNjcmVlbihwYWludGVyLHdvcmxkVG9TY3JlZW4ocGFpbnRlcixhKSxNYXRoLm1heCgxNTAsYS5yYWRpdXMqMykpKS5zb3J0KChhLGIpPT5hLnktYi55KTtcbiAgICBmb3IoY29uc3QgYWN0b3Igb2YgYWN0b3JzKWlmKCdvcmRlcicgaW4gYWN0b3Ipe2lmKHNoaXBQcm9maWxlKGFjdG9yKSlkcmF3U2hpcEdyb3VwKHBhaW50ZXIsYWN0b3IpO2Vsc2UgZHJhd1VuaXRzKHBhaW50ZXIsW2FjdG9yXSk7fWVsc2UgZHJhd0J1aWxkaW5ncyhwYWludGVyLFthY3Rvcl0pO1xuICB9XG4gIGlmICghcGFpbnRlci5zdGlsbCAmJiBwYWludGVyLnZpZXdlcikgZHJhd0FpbUxpbmVzKHBhaW50ZXIpO1xuICAvLyBDYXJyaWVkIG9iamVjdHMgYmVsb25nIGluIHRoZSBpbnZlbnRvcnksIG5vdCBzdGFja2VkIG92ZXIgYSB1bml0J3MgaGVhZC5cbiAgY29uc3QgdW5pdHNCeUlkID0gdmlld0luZGV4LnVuaXRzO1xuICBpZihjb21iYXQmJiFmcmFtZS5waHlzaWNhbENvbWJhdClkcmF3Q29tYmF0R3JvdW5kKGN0eCxjb21iYXQsY29tYmF0UHJvamVjdGlvbix0cnVlKTtcbiAgaWYoY29tYmF0JiYhZnJhbWUucGh5c2ljYWxDb21iYXQpZHJhd0NvbWJhdEFpcihjdHgsY29tYmF0LGNvbWJhdFByb2plY3Rpb24sKGlkLGhlaWdodCxwb3NpdGlvbik9PntcbiAgICBjb25zdCB1bml0PXVuaXRzQnlJZC5nZXQoaWQpO2lmKCF1bml0fHxpc0luQ2FiaW4odW5pdCkpcmV0dXJuIG51bGw7XG4gICAgY29uc3QgYW5jaG9yPXBhaW50ZXIuYWN0b3JQb3NpdGlvbnM/LmdldChpZCk7XG4gICAgY29uc3QgYXQ9YW5jaG9yP3t4OmFuY2hvci54LHk6YW5jaG9yLmJvZHlZfTpkcmF3blBvc2l0aW9uKHBhaW50ZXIsdW5pdCk7XG4gICAgY29uc3Qgc2hpcD11bml0LmRlY2s/cGFpbnRlci5zaGlwcy5nZXQodW5pdC5kZWNrLnNoaXBJZCk6dW5kZWZpbmVkO1xuICAgIGNvbnN0IG1vZGVsPXVuaXQudmFyaWFudD9wYWludGVyLm1vZGVscz8uKHVuaXQudmFyaWFudCk6dW5kZWZpbmVkO1xuICAgIGNvbnN0IGZsb29yPW1vZGVsPzE3Kk1hdGgubWF4KC43Mix1bml0LnJhZGl1cy8xOCk6KGNyZWF0dXJlU2hhZG93KHVuaXQua2luZCk/Lnk/PzE3KSp1bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cyk7XG4gICAgcmV0dXJuIHdvcmxkVG9TY3JlZW4ocGFpbnRlcix7eDphdC54K3Bvc2l0aW9uLngtdW5pdC54LHk6YXQueStwb3NpdGlvbi55LXVuaXQueStmbG9vci0oYW5jaG9yPzA6c2hpcD9kZWNrVmlzdWFsSGVpZ2h0KHNoaXApKzE4KnVuaXRHbHlwaFNjYWxlKHVuaXQucmFkaXVzKTowKS1oZWlnaHQqTWF0aC50YW4oU0hJUF9DQU1FUkEudGlsdCl9KTtcbiAgfSxwYWludGVyLnJlZHVjZWRNb3Rpb24pO1xuICByZW5kZXJXb3JsZEVmZmVjdHMoe1xuICAgIGN0eCxcbiAgICBwbGF5ZXJzOnNuYXBzaG90LnBsYXllcnMsXG4gICAgZWZmZWN0czogc25hcHNob3QuZWZmZWN0cy5maWx0ZXIoZWZmZWN0PT4hZnJhbWUucGh5c2ljYWxFZmZlY3RzPy5oYXMoZWZmZWN0LnR5cGUpICYmICEoZWZmZWN0LnVuaXRJZCAmJiB1bml0c0J5SWQuaGFzKGVmZmVjdC51bml0SWQpICYmIGlzSW5DYWJpbih1bml0c0J5SWQuZ2V0KGVmZmVjdC51bml0SWQpISkpKSxcbiAgICB3b3JsZFRvU2NyZWVuOiAocG9pbnQpID0+IHdvcmxkVG9TY3JlZW4ocGFpbnRlciwgcG9pbnQpLFxuICAgIG5lYXJTY3JlZW46IChwb2ludCwgcGFkKSA9PiBuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCBwYWQpLFxuICAgIHZpZXdlcjpwYWludGVyLnZpZXdlcixcbiAgICByZWR1Y2VkTW90aW9uOnBhaW50ZXIucmVkdWNlZE1vdGlvbixcbiAgICBjb21iYXRUcmFpbHM6Qm9vbGVhbihjb21iYXQpLFxuICAgIHByb2plY3RpbGVPcmlnaW46ZWZmZWN0PT5mcmFtZS5wcm9qZWN0aWxlcz8ub3JpZ2luKGVmZmVjdCxmcmFtZS5waHlzaWNhbENvbWJhdD8nZ3B1JzonY2FudmFzJyksXG4gICAgdW5pdDooaWQpPT51bml0c0J5SWQuZ2V0KGlkKSxcbiAgICB1bml0UG9zaXRpb246IChpZCkgPT4ge1xuICAgICAgY29uc3QgdW5pdCA9IHVuaXRzQnlJZC5nZXQoaWQpO1xuICAgICAgaWYoIXVuaXQgfHwgaXNJbkNhYmluKHVuaXQpKXJldHVybiB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBhbmNob3I9cGFpbnRlci5hY3RvclBvc2l0aW9ucz8uZ2V0KGlkKTtcbiAgICAgIGlmKGFuY2hvcilyZXR1cm57eDphbmNob3IueCx5OmFuY2hvci5ib2R5WX07XG4gICAgICBjb25zdCBhdD1kcmF3blBvc2l0aW9uKHBhaW50ZXIsdW5pdCkscGFyZW50PXVuaXQuZGVjaz9wYWludGVyLnNoaXBzLmdldCh1bml0LmRlY2suc2hpcElkKTp1bmRlZmluZWQ7XG4gICAgICByZXR1cm4gcGFyZW50P3t4OmF0LngseTphdC55LWRlY2tWaXN1YWxIZWlnaHQocGFyZW50KS0xOCp1bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cyl9OmF0O1xuICAgIH0sXG4gIH0pO1xuICBjdHgucmVzdG9yZSgpO1xuICBpZiAoZnJhbWUuc3RvcnkpIHtcbiAgICBjb25zdCBzdG9yeVBhaW50ZXIgPSB7XG4gICAgICBjdHgsXG4gICAgICB2aWV3OiBmcmFtZS5zdG9yeSxcbiAgICAgIGxvY2FsZTogZnJhbWUubG9jYWxlID8/IFwiemhcIixcbiAgICAgIHdpZHRoOiBmcmFtZS52aWV3LndpZHRoLFxuICAgICAgaGVpZ2h0OiBmcmFtZS52aWV3LmhlaWdodCxcbiAgICAgIHpvb20sXG4gICAgICBwcm9qZWN0OiAocG9pbnQ6IFBvaW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGF0ID0gd29ybGRUb1NjcmVlbihwYWludGVyLCBwb2ludCk7XG4gICAgICAgIHJldHVybiB7IHg6IGF0LnggKiB6b29tLCB5OiBhdC55ICogem9vbSB9O1xuICAgICAgfSxcbiAgICAgIHVuaXRBdDogKHVuaXRJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IHVuaXQgPSB1bml0c0J5SWQuZ2V0KHVuaXRJZCk7XG4gICAgICAgIHJldHVybiB1bml0ICYmICFpc0luQ2FiaW4odW5pdCkgPyB7IC4uLmRyYXduUG9zaXRpb24ocGFpbnRlciwgdW5pdCksIHJhZGl1czogdW5pdC5yYWRpdXMgfSA6IHVuZGVmaW5lZDtcbiAgICAgIH0sXG4gICAgfTtcbiAgICBkcmF3U3RvcnlBaXIoc3RvcnlQYWludGVyKTtcbiAgICBkcmF3U3RvcnlTY3JlZW4oc3RvcnlQYWludGVyKTtcbiAgfVxufVxuXG4vKiogRmVlZHMgdGhlIHRyYWNrZXIgZXZlcnkgdW5pdCdzIGZhY2luZyBmb3IgdGhpcyBzbmFwc2hvdDsgY2FsbGluZyBpdCB0d2ljZSBmb3Igb25lIHNuYXBzaG90IGNoYW5nZXMgbm90aGluZy4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFja1VuaXRGYWNpbmcoZmFjaW5nOiBVbml0RmFjaW5nVHJhY2tlciwgc25hcHNob3Q6IEdhbWVTbmFwc2hvdCxrbm93blBvc2l0aW9ucz86UmVhZG9ubHlNYXA8c3RyaW5nLFBvaW50Pikge1xuICBsZXQgcG9zaXRpb25zOk1hcDxzdHJpbmcsUG9pbnQ+fHVuZGVmaW5lZDtcbiAgZmFjaW5nLnVwZGF0ZVNuYXBzaG90KHNuYXBzaG90LChpZCk9PntcbiAgICBpZihrbm93blBvc2l0aW9ucylyZXR1cm4ga25vd25Qb3NpdGlvbnMuZ2V0KGlkKTtcbiAgICBpZighcG9zaXRpb25zKXtwb3NpdGlvbnM9bmV3IE1hcCgpO2Zvcihjb25zdCBlbnRpdHkgb2Ygc25hcHNob3QudW5pdHMpcG9zaXRpb25zLnNldChlbnRpdHkuaWQsZW50aXR5KTtmb3IoY29uc3QgZW50aXR5IG9mIHNuYXBzaG90LmJ1aWxkaW5ncylwb3NpdGlvbnMuc2V0KGVudGl0eS5pZCxlbnRpdHkpO31cbiAgICByZXR1cm4gcG9zaXRpb25zLmdldChpZCk7XG4gIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHJhd1BhcGVyTWFwKGN0eDogQnJ1c2gsIG1hcElkOiBNYXBJZCwgY2FtZXJhOiBQb2ludCwgd2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIpIHtcbiAgZHJhd0F0bGFzR3JvdW5kKGN0eCwgd2lkdGgsIGhlaWdodCwgY2FtZXJhKTtcbiAgZm9yIChjb25zdCBzdHJva2Ugb2YgZ2VuZXJhdGVUZXJyYWluTGluZXdvcmsoeyBtYXBJZCwgY2FtZXJhLCB3aWR0aCwgaGVpZ2h0IH0pKSB7XG4gICAgZHJhd1RleHR1cmVTdHJva2UoY3R4LCBzdHJva2UpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBvd25lckluayhvd25lcjogT3duZXIgfCB1bmRlZmluZWQsIHNuYXBzaG90PzogUGljazxHYW1lU25hcHNob3QsICdwbGF5ZXJzJz4pIHsgcmV0dXJuIHBsYXllckNvbG9yKG93bmVyLCBzbmFwc2hvdCk7IH1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkaW5nR2x5cGhTaXplKGtpbmQ6IEJ1aWxkaW5nS2luZCkge1xuICByZXR1cm4gTWF0aC5yb3VuZChCVUlMRElOR19ERUZTW2tpbmRdLnJhZGl1cyAqIDIuMTIpO1xufVxuXG5mdW5jdGlvbiBkcmF3VGV4dHVyZVN0cm9rZShjdHg6IEJydXNoLCBzdHJva2U6IFRleHR1cmVTdHJva2UpIHtcbiAgaWYgKHN0cm9rZS5wb2ludHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGN0eC5zdHJva2VTdHlsZSA9IHN0cm9rZS5jb2xvcjtcbiAgY3R4LmxpbmVXaWR0aCA9IHN0cm9rZS53aWR0aDtcbiAgY3R4LmJlZ2luUGF0aCgpO1xuICBjdHgubW92ZVRvKHN0cm9rZS5wb2ludHNbMF0hLngsIHN0cm9rZS5wb2ludHNbMF0hLnkpO1xuICBmb3IgKGNvbnN0IHBvaW50IG9mIHN0cm9rZS5wb2ludHMuc2xpY2UoMSkpIGN0eC5saW5lVG8ocG9pbnQueCwgcG9pbnQueSk7XG4gIGN0eC5zdHJva2UoKTtcbn1cblxuZnVuY3Rpb24gZHJhd0xhbmRtYXJrcyhwYWludGVyOiBQYWludGVyLCBsYW5kbWFya3M6IFRlcnJhaW5MYW5kbWFya1tdKSB7XG4gIGZvciAoY29uc3QgbGFuZG1hcmsgb2YgbGFuZG1hcmtzKSB7XG4gICAgY29uc3QgcG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIGxhbmRtYXJrKTtcbiAgICBpZiAobmVhclNjcmVlbihwYWludGVyLCBwb2ludCwgbGFuZG1hcmsuc2l6ZSArIDgwKSkgZHJhd0F0bGFzTGFuZG1hcmsocGFpbnRlci5jdHgsIGxhbmRtYXJrLCBwb2ludCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZHJhd1Jlc291cmNlcyhwYWludGVyOiBQYWludGVyLCByZXNvdXJjZXM6IFJlc291cmNlTm9kZVtdKSB7XG4gIGNvbnN0IHsgY3R4IH0gPSBwYWludGVyO1xuICBmb3IgKGNvbnN0IHJlc291cmNlIG9mIHJlc291cmNlcykge1xuICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihwYWludGVyLCByZXNvdXJjZSk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCA4MCkpIGNvbnRpbnVlO1xuICAgIGRyYXdBdGxhc01pbmUoY3R4LCBwb2ludCk7XG4gICAgaWYgKHBhaW50ZXIuc3RpbGwpIGNvbnRpbnVlO1xuICAgIGN0eC5mb250ID0gXCI2MDAgMTFweCB1aS1tb25vc3BhY2UsIG1vbm9zcGFjZVwiO1xuICAgIGN0eC50ZXh0QWxpZ24gPSBcImNlbnRlclwiO1xuICAgIGN0eC5maWxsU3R5bGUgPSBcIiM3NzY0NDNcIjtcbiAgICBjdHguZmlsbFRleHQoTWF0aC5jZWlsKHJlc291cmNlLmFtb3VudCkudG9Mb2NhbGVTdHJpbmcoKSwgcG9pbnQueCwgcG9pbnQueSArIDQ1KTtcbiAgICBjdHgudGV4dEFsaWduID0gXCJzdGFydFwiO1xuICB9XG59XG5cbmZ1bmN0aW9uIGRyYXdNZXJjZW5hcnlDYW1wcyhwYWludGVyOiBQYWludGVyLCBjYW1wczogTWVyY2VuYXJ5Q2FtcFtdLG92ZXJsYXlPbmx5PWZhbHNlLGdyb3VuZE9ubHk9ZmFsc2UpIHtcbiAgY29uc3QgeyBjdHggfSA9IHBhaW50ZXI7XG4gIGZvciAoY29uc3QgY2FtcCBvZiBjYW1wcykge1xuICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihwYWludGVyLCBjYW1wKTtcbiAgICBpZiAoIW5lYXJTY3JlZW4ocGFpbnRlciwgcG9pbnQsIDExMCkpIGNvbnRpbnVlO1xuICAgIGlmKCFvdmVybGF5T25seSAmJiAhcGFpbnRlci5hY3RvclBvc2l0aW9ucz8uaGFzKGNhbXAuaWQpKWRyYXdBdGxhc0NhbXAoY3R4LCBwb2ludCk7XG4gICAgaWYoZ3JvdW5kT25seSljb250aW51ZTtcbiAgICBjdHguZm9udCA9IFwiMTFweCB1aS1tb25vc3BhY2UsIG1vbm9zcGFjZVwiO1xuICAgIGN0eC5maWxsU3R5bGUgPSBcIiM3OTY2NDRcIjtcbiAgICBjdHgudGV4dEFsaWduID0gXCJjZW50ZXJcIjtcbiAgICBjdHguZmlsbFRleHQocGFpbnRlci5sYWJlbHMubWVyY2VuYXJ5U3RvY2soY2FtcC5zdG9jayksIHBvaW50LngsIHBvaW50LnkgKyA0OCk7XG4gICAgY3R4LnRleHRBbGlnbiA9IFwic3RhcnRcIjtcbiAgICBpZiAoY2FtcC5jb29sZG93blJlbWFpbmluZyA+IDApIGRyYXdQcm9ncmVzcyhjdHgsIHBvaW50LngsIHBvaW50LnkgKyA2MCwgMSAtIGNhbXAuY29vbGRvd25SZW1haW5pbmcgLyBjYW1wLmNvb2xkb3duKTtcbiAgfVxufVxuXG4vLyBSb2NrcyBhbmQgZ2F0ZXMgYWNyb3NzIHRoZWlyIHdheXMgKHNlZSBAQEBvYnN0YWNsZS1hcnQpLCB0aGVpciBoZWFsdGggc2hvd24gb25jZSB0aGV5IGFyZSBzdHJ1Y2suXG5mdW5jdGlvbiBkcmF3T2JzdGFjbGVzKHBhaW50ZXI6IFBhaW50ZXIsIG9ic3RhY2xlczogT2JzdGFjbGVbXSkge1xuICBmb3IgKGNvbnN0IG9ic3RhY2xlIG9mIG9ic3RhY2xlcykge1xuICAgIGNvbnN0IHNoYWtlID0gaGl0RmVlZGJhY2tPZmZzZXQocGFpbnRlci5zbmFwc2hvdCwgb2JzdGFjbGUscGFpbnRlci52aWV3SW5kZXguaGl0cyk7XG4gICAgY29uc3QgcG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIHsgeDogb2JzdGFjbGUueCArIHNoYWtlLngsIHk6IG9ic3RhY2xlLnkgKyBzaGFrZS55IH0pO1xuICAgIGlmICghbmVhclNjcmVlbihwYWludGVyLCBwb2ludCwgb2JzdGFjbGUucmFkaXVzICsgODApKSBjb250aW51ZTtcbiAgICBkcmF3QXRsYXNPYnN0YWNsZShwYWludGVyLmN0eCwgb2JzdGFjbGUsIHBvaW50KTtcbiAgICBpZiAoIXBhaW50ZXIuc3RpbGwgJiYgb2JzdGFjbGUuaHAgPCBvYnN0YWNsZS5tYXhIcCkgZHJhd0hwKHBhaW50ZXIuY3R4LCBwb2ludC54LCBwb2ludC55IC0gb2JzdGFjbGVBcnRUb3Aob2JzdGFjbGUpIC0gMTAsIG9ic3RhY2xlLmhwLCBvYnN0YWNsZS5tYXhIcCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZHJhd1Nob3BzKHBhaW50ZXI6IFBhaW50ZXIsIHNob3BzOiBTaG9wW10sb3ZlcmxheU9ubHk9ZmFsc2UsZ3JvdW5kT25seT1mYWxzZSkge1xuICBjb25zdCB7IGN0eCB9ID0gcGFpbnRlcjtcbiAgZm9yIChjb25zdCBzaG9wIG9mIHNob3BzKSB7XG4gICAgY29uc3QgcG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIHNob3ApO1xuICAgIGlmICghbmVhclNjcmVlbihwYWludGVyLCBwb2ludCwgMTEwKSkgY29udGludWU7XG4gICAgaWYoIW92ZXJsYXlPbmx5ICYmICFwYWludGVyLmFjdG9yUG9zaXRpb25zPy5oYXMoc2hvcC5pZCkpZHJhd0F0bGFzU2hvcChjdHgsIHBvaW50KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3QnVpbGRpbmdzKHBhaW50ZXI6IFBhaW50ZXIsIGJ1aWxkaW5nczogQnVpbGRpbmdbXSxvdmVybGF5T25seT1mYWxzZSkge1xuICBjb25zdCB7IGN0eCB9ID0gcGFpbnRlcjtcbiAgY29uc3QgZW5nYWdlZCA9IHBhaW50ZXIuZW5nYWdlZDtcbiAgZm9yIChjb25zdCBidWlsZGluZyBvZiBidWlsZGluZ3MpIHtcbiAgICBjb25zdCBzaGFrZSA9IGhpdEZlZWRiYWNrT2Zmc2V0KHBhaW50ZXIuc25hcHNob3QsIGJ1aWxkaW5nLHBhaW50ZXIudmlld0luZGV4LmhpdHMpO1xuICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihwYWludGVyLCB7IHg6IGJ1aWxkaW5nLnggKyBzaGFrZS54LCB5OiBidWlsZGluZy55ICsgc2hha2UueSB9KTtcbiAgICBjb25zdCBzZWxlY3RlZCA9IHBhaW50ZXIuc2VsZWN0ZWRJZHMuaGFzKGJ1aWxkaW5nLmlkKTtcbiAgICBjb25zdCB0cmFpbmFibGUgPSBCVUlMRElOR19ERUZTW2J1aWxkaW5nLmtpbmRdLnRyYWlucy5sZW5ndGggPiAwO1xuICAgIGNvbnN0IHJhbGx5UG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIHsgeDogYnVpbGRpbmcucmFsbHlYLCB5OiBidWlsZGluZy5yYWxseVkgfSk7XG4gICAgY29uc3Qgc2hvd1JhbGx5ID0gc2hvdWxkUmVuZGVyQnVpbGRpbmdSYWxseSh7IHNlbGVjdGVkLCB0cmFpbmFibGUsIG93bmVyOmJ1aWxkaW5nLm93bmVyLCB2aWV3ZXI6cGFpbnRlci52aWV3ZXIgfSk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCAxMjApKSB7XG4gICAgICBpZiAoc2hvd1JhbGx5KSBkcmF3QnVpbGRpbmdSYWxseShjdHgsIGJ1aWxkaW5nLCBwb2ludCwgcmFsbHlQb2ludCwgb3duZXJJbmsoYnVpbGRpbmcub3duZXIsIHBhaW50ZXIuc25hcHNob3QpKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBvd25lckluayhidWlsZGluZy5vd25lciwgcGFpbnRlci5zbmFwc2hvdCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IGJ1aWxkaW5nLmNvbXBsZXRlID8gXCJyZ2JhKDI1NSwgMjUwLCAyMjYsIDAuNzIpXCIgOiBcInJnYmEoMjU1LCAyNTAsIDIyNiwgMC40MilcIjtcbiAgICBjdHgubGluZVdpZHRoID0gc2VsZWN0ZWQgPyA0IDogMjtcbiAgICBjb25zdCBzaXplID0gYnVpbGRpbmdHbHlwaFNpemUoYnVpbGRpbmcua2luZCk7XG4gICAgY3R4LnNhdmUoKTtcbiAgICBjdHguZ2xvYmFsQWxwaGEgPSBidWlsZGluZy5jb21wbGV0ZSA/IDEgOiAwLjQ4O1xuICAgIGlmKCFvdmVybGF5T25seSlkcmF3QXRsYXNCdWlsZGluZyhjdHgsIHBhaW50ZXIuYnVpbGRpbmdNb2RlbHM/LltidWlsZGluZy5pZF0gPz8gYnVpbGRpbmcua2luZCwgcG9pbnQsIHNpemUsIG93bmVySW5rKGJ1aWxkaW5nLm93bmVyLCBwYWludGVyLnNuYXBzaG90KSk7XG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgICBpZiAoc2hvd1JhbGx5KSBkcmF3QnVpbGRpbmdSYWxseShjdHgsIGJ1aWxkaW5nLCBwb2ludCwgcmFsbHlQb2ludCwgb3duZXJJbmsoYnVpbGRpbmcub3duZXIsIHBhaW50ZXIuc25hcHNob3QpKTtcbiAgICBpZiAoc2hvdWxkU2hvd0hlYWx0aEJhcih7IGhwOiBidWlsZGluZy5ocCwgbWF4SHA6IGJ1aWxkaW5nLm1heEhwLCBzZWxlY3RlZCwgaG92ZXJlZDogcGFpbnRlci5ob3ZlcmVkSWQgPT09IGJ1aWxkaW5nLmlkLCBlbmdhZ2VkOiBlbmdhZ2VkLmhhcyhidWlsZGluZy5pZCksIGNvbnN0cnVjdGluZzogIWJ1aWxkaW5nLmNvbXBsZXRlLCBzdGlsbDogcGFpbnRlci5zdGlsbCB9KSkgZHJhd0hwKGN0eCwgcG9pbnQueCwgcGFpbnRlci5hY3RvclBvc2l0aW9ucz8uZ2V0KGJ1aWxkaW5nLmlkKT8udG9wWSE9PXVuZGVmaW5lZD9wYWludGVyLmFjdG9yUG9zaXRpb25zLmdldChidWlsZGluZy5pZCkhLnRvcFktcGFpbnRlci5jYW1lcmEueS03OnBvaW50LnkgLSBzaXplICogMC43OCAtIDUsIGJ1aWxkaW5nLmhwLCBidWlsZGluZy5tYXhIcCwgNDgpO1xuICAgIGlmICghYnVpbGRpbmcuY29tcGxldGUpIGRyYXdQcm9ncmVzcyhjdHgsIHBvaW50LngsIHBvaW50LnkgKyBzaXplICogMC42ICsgMTAsIGJ1aWxkaW5nLmJ1aWxkUHJvZ3Jlc3MgLyBidWlsZGluZy5idWlsZFRpbWUpO1xuICAgIGlmIChidWlsZGluZy5jb21wbGV0ZSAmJiBidWlsZGluZy5xdWV1ZVswXSkge1xuICAgICAgZHJhd1RyYWluaW5nUHJvZ3Jlc3MocGFpbnRlciwgcG9pbnQueCwgcG9pbnQueSArIHNpemUgKiAwLjYgKyAxMCwgYnVpbGRpbmcucXVldWVbMF0ucmVtYWluaW5nLCBidWlsZGluZy5xdWV1ZVswXS51bml0S2luZCwgYnVpbGRpbmcucXVldWUubGVuZ3RoKTtcbiAgICB9XG4gIH1cbn1cblxuLyoqIFJldGljbGVzIGFyZSBhbiBvd25lci1vbmx5IG92ZXJsYXksIGluY2x1ZGluZyBkdXJpbmcgbXVsdGlwbGF5ZXIgYW5kIGFsbGllZCBzaGFyZWQgdmlzaW9uLiAqL1xuZnVuY3Rpb24gZHJhd0FpbUxpbmVzKHBhaW50ZXI6IFBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHggfSA9IHBhaW50ZXI7XG4gIGZvciAoY29uc3QgdW5pdCBvZiBwYWludGVyLnZpZXdJbmRleC5haW1pbmcpIHtcbiAgICBjb25zdCBhaW0gPSB1bml0LmFpbTtcbiAgICBpZiAoaXNJbkNhYmluKHVuaXQpIHx8IHVuaXQub3duZXIgIT09IHBhaW50ZXIudmlld2VyIHx8ICFhaW0gfHwgIVtcImF0dGFja1wiLCBcImF0dGFja01vdmVcIiwgXCJob2xkXCIsIFwiYWltXCIsIFwiY2FzdFwiXS5pbmNsdWRlcyh1bml0Lm9yZGVyLnR5cGUpKSBjb250aW51ZTtcbiAgICBjb25zdCBmcm9tID0gd29ybGRUb1NjcmVlbihwYWludGVyLCBkcmF3blBvc2l0aW9uKHBhaW50ZXIsIHVuaXQpKSwgdG8gPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIGFpbSk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIGZyb20sIDgwKSAmJiAhbmVhclNjcmVlbihwYWludGVyLCB0bywgODApKSBjb250aW51ZTtcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5nbG9iYWxBbHBoYSA9IHBhaW50ZXIuc2VsZWN0ZWRJZHMuaGFzKHVuaXQuaWQpID8gLjggOiAuNDtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBhaW0udHJhY2tpbmcgPyBcIiNjNTliNTZcIiA6IFwiIzcyYTk4YlwiO1xuICAgIGN0eC5saW5lV2lkdGggPSAxO1xuICAgIGN0eC5zZXRMaW5lRGFzaChhaW0udHJhY2tpbmcgPyBbNCwgNF0gOiBbXSk7XG4gICAgY3R4LmJlZ2luUGF0aCgpOyBjdHgubW92ZVRvKGZyb20ueCwgZnJvbS55KTsgY3R4LmxpbmVUbyh0by54LCB0by55KTsgY3R4LnN0cm9rZSgpO1xuICAgIGN0eC5zZXRMaW5lRGFzaChbXSk7XG4gICAgY3R4LmJlZ2luUGF0aCgpOyBjdHguYXJjKHRvLngsIHRvLnksIDQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICBjdHgubW92ZVRvKHRvLnggLSA3LCB0by55KTsgY3R4LmxpbmVUbyh0by54ICsgNywgdG8ueSk7XG4gICAgY3R4Lm1vdmVUbyh0by54LCB0by55IC0gNyk7IGN0eC5saW5lVG8odG8ueCwgdG8ueSArIDcpOyBjdHguc3Ryb2tlKCk7XG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3QnVpbGRpbmdSYWxseShjdHg6IEJydXNoLCBidWlsZGluZzogQnVpbGRpbmcsIGZyb206IFBvaW50LCB0bzogUG9pbnQsIGNvbG9yOiBzdHJpbmcpIHtcbiAgY3R4LnNhdmUoKTtcbiAgY29uc3QgeCA9IHRvLngsIHkgPSB0by55O1xuICBjdHguZmlsbFN0eWxlID0gXCIjMjkyNzI0NDBcIjtcbiAgY3R4LmJlZ2luUGF0aCgpOyBjdHguZWxsaXBzZSh4ICsgMywgeSArIDMsIDEwLCAzLCAwLCAwLCBNYXRoLlBJICogMik7IGN0eC5maWxsKCk7XG4gIGN0eC5zdHJva2VTdHlsZSA9IFwiIzQ5NDEzYVwiOyBjdHgubGluZVdpZHRoID0gMjtcbiAgY3R4LmJlZ2luUGF0aCgpOyBjdHgubW92ZVRvKHgsIHkgKyAyKTsgY3R4LmxpbmVUbyh4LCB5IC0gMjcpOyBjdHguc3Ryb2tlKCk7XG4gIGN0eC5zdHJva2VTdHlsZSA9IFwiI2Q0YzFhMFwiOyBjdHgubGluZVdpZHRoID0gLjY1O1xuICBjdHguYmVnaW5QYXRoKCk7IGN0eC5tb3ZlVG8oeCAtIC42LCB5KTsgY3R4LmxpbmVUbyh4IC0gLjYsIHkgLSAyNyk7IGN0eC5zdHJva2UoKTtcbiAgY3R4LmZpbGxTdHlsZSA9IGNvbG9yO1xuICBjdHguYmVnaW5QYXRoKCk7IGN0eC5tb3ZlVG8oeCArIDEsIHkgLSAyNik7IGN0eC5saW5lVG8oeCArIDE3LCB5IC0gMjMpO1xuICBjdHgubGluZVRvKHggKyAxMiwgeSAtIDE4KTsgY3R4LmxpbmVUbyh4ICsgMTcsIHkgLSAxNCk7IGN0eC5saW5lVG8oeCArIDEsIHkgLSAxNyk7IGN0eC5jbG9zZVBhdGgoKTsgY3R4LmZpbGwoKTsgY3R4LnN0cm9rZSgpO1xuICBjdHgucmVzdG9yZSgpO1xufVxuXG5mdW5jdGlvbiBkcmF3U2hpcEdyb3VwKHBhaW50ZXI6UGFpbnRlcixzaGlwOlVuaXQpIHtcbiAgY29uc3QgcG9pbnQ9d29ybGRUb1NjcmVlbihwYWludGVyLGRyYXduUG9zaXRpb24ocGFpbnRlcixzaGlwKSk7XG4gIGlmKHBhaW50ZXIubW90aW9uICYmIHNoaXAuc2FpbGluZylzaGlwPXsuLi5zaGlwLHNhaWxpbmc6ey4uLnNoaXAuc2FpbGluZyxoZWFkaW5nOnBhaW50ZXIubW90aW9uLmhlYWRpbmcoc2hpcCxwYWludGVyLm5vdyl9fTtcbiAgY29uc3QgY3Jldz1zaGlwUGFzc2VuZ2VycyhwYWludGVyLnNuYXBzaG90LnVuaXRzLHNoaXApLnNvcnQoKGEsYik9PmEueS1iLnkpO1xuICAvLyBBbGwgZGVjayByaW5ncyBwcmVjZWRlIGV2ZXJ5IHBhc3Nlbmdlciwgc28gb25lIHBlcnNvbidzIG1hcmtlciBjYW5ub3RcbiAgLy8gY292ZXIgYSBwcmV2aW91c2x5IGRyYXduIG5laWdoYm91ci4gVGhlIGRlY2sgaXRzZWxmIHJlbWFpbnMgdW5kZXJuZWF0aC5cbiAgZHJhd0NhbnZhc1NoaXAocGFpbnRlci5jdHgsc2hpcCxwb2ludCxwYWludGVyLnNuYXBzaG90Lml0ZW1zLCgpPT57XG4gICAgY29uc3QgYXQ9ZHJhd25Qb3NpdGlvbihwYWludGVyLHNoaXApO1xuICAgIGZvcihjb25zdCBjb3Jwc2Ugb2YgZGVja1JlbWFpbnNCeVNoaXAocGFpbnRlci5zbmFwc2hvdC5jb3Jwc2VzKS5nZXQoc2hpcC5pZCkgPz8gW10pe1xuICAgICAgY29uc3QgcG9zZT1kZWNrUmVtYWluc1Bvc2UoY29ycHNlLHNoaXAsey4uLmF0LGhlYWRpbmc6c2hpcC5zYWlsaW5nPy5oZWFkaW5nPz8wfSk7XG4gICAgICBpZighcG9zZSljb250aW51ZTtcbiAgICAgIGNvbnN0IGNlbnRlcj13b3JsZFRvU2NyZWVuKHBhaW50ZXIse3g6cG9zZS54LHk6cG9zZS55LWRlY2tWaXN1YWxIZWlnaHQoc2hpcCl9KTtcbiAgICAgIGNvbnN0IG1vZGVsPWNvcnBzZS52YXJpYW50P3BhaW50ZXIubW9kZWxzPy4oY29ycHNlLnZhcmlhbnQpOnVuZGVmaW5lZDtcbiAgICAgIHBhaW50ZXIuY3R4LnNhdmUoKTtwYWludGVyLmN0eC50cmFuc2xhdGUoY2VudGVyLngsY2VudGVyLnkpO3BhaW50ZXIuY3R4LnJvdGF0ZShwb3NlLmhlYWRpbmcpO1xuICAgICAgcGFpbnRlci5jdHguZ2xvYmFsQWxwaGEqPXJlbWFpbnNPcGFjaXR5KHBhaW50ZXIuc25hcHNob3QudGljayxjb3Jwc2UuZGllZEF0VGljayk7XG4gICAgICBkcmF3QXRsYXNDb3Jwc2UocGFpbnRlci5jdHgsY29ycHNlLmtpbmQse3g6MCx5OjB9LG1vZGVsP01hdGgubWF4KC43Mixjb3Jwc2UucmFkaXVzLzE4KTp1bml0R2x5cGhTY2FsZShjb3Jwc2UucmFkaXVzKSxyZW1haW5zVmFyaWFudChjb3Jwc2UuaWQpLG1vZGVsLGNvcnBzZS52YXJpYW50LG93bmVySW5rKGNvcnBzZS5vd25lcixwYWludGVyLnNuYXBzaG90KSxjb3Jwc2VBcHBlYXJhbmNlRm9yKHBhaW50ZXIuc25hcHNob3QsY29ycHNlKSk7XG4gICAgICBwYWludGVyLmN0eC5yZXN0b3JlKCk7XG4gICAgfVxuICAgIGZvcihjb25zdCBwYXNzZW5nZXIgb2YgY3JldylkcmF3VW5pdFNlbGVjdGlvbk1hcmtlcihwYWludGVyLHBhc3Nlbmdlcik7XG4gIH0pO1xuICBkcmF3U2hpcEZsYWcocGFpbnRlci5jdHgsc2hpcCxwb2ludCxvd25lckluayhzaGlwLm93bmVyLCBwYWludGVyLnNuYXBzaG90KSk7XG4gIGRyYXdJdGVtcyhwYWludGVyLHBhaW50ZXIuc25hcHNob3QuaXRlbXMsc2hpcCk7XG4gIGZvcihjb25zdCBwYXNzZW5nZXIgb2YgY3JldylkcmF3VW5pdHMocGFpbnRlcixbcGFzc2VuZ2VyXSk7XG4gIGRyYXdVbml0cyhwYWludGVyLFtzaGlwXSx0cnVlKTtcbn1cblxuZnVuY3Rpb24gZHJhd0dhbmd3YXlzKHBhaW50ZXI6IFBhaW50ZXIpIHtcbiAgY29uc3QgeyBjdHggfSA9IHBhaW50ZXI7XG4gIGZvciAoY29uc3QgW2lkLCBzdXJmYWNlXSBvZiBwYWludGVyLmdhbmd3YXlzKSB7XG4gICAgY29uc3Qgc291cmNlID0gcGFpbnRlci5zaGlwcy5nZXQoaWQpISwgdGFyZ2V0ID0gcGFpbnRlci5zaGlwcy5nZXQoc291cmNlLnNhaWxpbmchLmdhbmd3YXkhLnRhcmdldElkKSE7XG4gICAgY29uc3QgZHggPSBzdXJmYWNlLnRhcmdldC54IC0gc3VyZmFjZS5zb3VyY2UueCwgZHkgPSBzdXJmYWNlLnRhcmdldC55IC0gc3VyZmFjZS5zb3VyY2UueSwgc3BhbjIgPSBkeCAqIGR4ICsgZHkgKiBkeTtcbiAgICBjb25zdCBwcm9qZWN0ID0gKHBvaW50OiBQb2ludCkgPT4ge1xuICAgICAgY29uc3QgdCA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsICgocG9pbnQueCAtIHN1cmZhY2Uuc291cmNlLngpICogZHggKyAocG9pbnQueSAtIHN1cmZhY2Uuc291cmNlLnkpICogZHkpIC8gc3BhbjIpKTtcbiAgICAgIGNvbnN0IGhlaWdodCA9IGRlY2tWaXN1YWxIZWlnaHQoc291cmNlKSArIChkZWNrVmlzdWFsSGVpZ2h0KHRhcmdldCkgLSBkZWNrVmlzdWFsSGVpZ2h0KHNvdXJjZSkpICogdDtcbiAgICAgIHJldHVybiB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIHsgeDogcG9pbnQueCwgeTogcG9pbnQueSAtIGhlaWdodCB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGNlbnRlciA9IHByb2plY3QoeyB4OiAoc3VyZmFjZS5zb3VyY2UueCArIHN1cmZhY2UudGFyZ2V0LngpIC8gMiwgeTogKHN1cmZhY2Uuc291cmNlLnkgKyBzdXJmYWNlLnRhcmdldC55KSAvIDIgfSk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIGNlbnRlciwgMTAwKSkgY29udGludWU7XG4gICAgY3R4LnNhdmUoKTsgY3R4Lmdsb2JhbEFscGhhID0gc3VyZmFjZS5waGFzZSA9PT0gJ2RlcGxveWluZycgPyAuNDggOiAxO1xuICAgIGN0eC5maWxsU3R5bGUgPSAnIzliNzU1MCc7IGN0eC5zdHJva2VTdHlsZSA9ICcjNGQzOTI3JzsgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY3R4LmJlZ2luUGF0aCgpOyBzdXJmYWNlLnBvbHlnb24uZm9yRWFjaCgocG9pbnQsIGluZGV4KSA9PiB7IGNvbnN0IGF0ID0gcHJvamVjdChwb2ludCk7IGlmIChpbmRleCkgY3R4LmxpbmVUbyhhdC54LCBhdC55KTsgZWxzZSBjdHgubW92ZVRvKGF0LngsIGF0LnkpOyB9KTtcbiAgICBjdHguY2xvc2VQYXRoKCk7IGN0eC5maWxsKCk7IGN0eC5zdHJva2UoKTsgY3R4LnJlc3RvcmUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3VW5pdHMocGFpbnRlcjogUGFpbnRlciwgdW5pdHM6IHJlYWRvbmx5IFVuaXRbXSwgb3ZlcmxheU9ubHk9ZmFsc2UpIHtcbiAgY29uc3QgeyBjdHgsIG5vdyB9ID0gcGFpbnRlcjtcbiAgY29uc3QgZW5nYWdlZCA9IHBhaW50ZXIuZW5nYWdlZDtcbiAgZm9yIChjb25zdCB1bml0IG9mIHVuaXRzKSB7XG4gICAgaWYgKGlzSW5DYWJpbih1bml0KSkgY29udGludWU7XG4gICAgY29uc3Qgc2hha2UgPSBoaXRGZWVkYmFja09mZnNldChwYWludGVyLnNuYXBzaG90LCB1bml0LHBhaW50ZXIudmlld0luZGV4LmhpdHMpO1xuICAgIGNvbnN0IGFuY2hvcj1wYWludGVyLmFjdG9yUG9zaXRpb25zPy5nZXQodW5pdC5pZCk7XG4gICAgY29uc3QgYXQgPSBhbmNob3I/e3g6YW5jaG9yLngseTphbmNob3IuYm9keVl9OmRyYXduUG9zaXRpb24ocGFpbnRlciwgdW5pdCk7XG4gICAgY29uc3Qgc2hpcD11bml0LmRlY2sgPyBwYWludGVyLnNoaXBzLmdldCh1bml0LmRlY2suc2hpcElkKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBicmlkZ2UgPSAhYW5jaG9yICYmIGdhbmd3YXlDcmV3VmlzdWFsUG9zZSh1bml0LCBwYWludGVyLnNoaXBzLCBwYWludGVyLmdhbmd3YXlzKTtcbiAgICBjb25zdCBib2R5SGVpZ2h0ID0gMTgqdW5pdEdseXBoU2NhbGUodW5pdC5yYWRpdXMpKihwYWludGVyLm1vZGVscyAmJiAhdW5pdC52YXJpYW50ID8gLjggOiAxKTtcbiAgICBjb25zdCBoZWlnaHQ9YW5jaG9yPzA6YnJpZGdlID8gYnJpZGdlLmhlaWdodCAqIE1hdGgudGFuKFNISVBfQ0FNRVJBLnRpbHQpICsgYm9keUhlaWdodCA6IHNoaXAgPyBkZWNrVmlzdWFsSGVpZ2h0KHNoaXApK2JvZHlIZWlnaHQgOiAwO1xuICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihwYWludGVyLCB7IHg6IGF0LnggKyBzaGFrZS54LCB5OiBhdC55ICsgc2hha2UueS1oZWlnaHQgfSk7XG4gICAgY29uc3Qgc2NhbGUgPSB1bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cykgKiAocGFpbnRlci5tb2RlbHMgJiYgIXVuaXQudmFyaWFudCA/IC44IDogMSk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCBNYXRoLm1heCg2MCwgdW5pdC5yYWRpdXMgKiAzKSkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHNlbGVjdGVkID0gcGFpbnRlci5zZWxlY3RlZElkcy5oYXModW5pdC5pZCk7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gb3duZXJJbmsodW5pdC5vd25lciwgcGFpbnRlci5zbmFwc2hvdCk7XG4gICAgY3R4LmZpbGxTdHlsZSA9IHVuaXQub3duZXIgPT09IFwibmV1dHJhbFwiID8gXCIjZjBkOWJkXCIgOiBcIiNmZmZiZTdcIjtcbiAgICBjdHgubGluZVdpZHRoID0gc2VsZWN0ZWQgPyA0IDogMjtcbiAgICBpZiAoaGFzQ2FycmllZEl0ZW0ocGFpbnRlci5zbmFwc2hvdCwgdW5pdCwgXCJmbGFtZUNsb2FrXCIpKSBkcmF3RmxhbWVDbG9ha0F1cmEoY3R4LCBwb2ludCwgbm93LCB1bml0LnJhZGl1cyk7XG4gICAgY29uc3QgbW9kZWwgPSB1bml0LnZhcmlhbnQgIT09IHVuZGVmaW5lZCA/IHBhaW50ZXIubW9kZWxzPy4odW5pdC52YXJpYW50KSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBibG9vZD1wYWludGVyLmNvbWJhdEJvZHk/LmdldCh1bml0LmlkKTtcbiAgICBpZighb3ZlcmxheU9ubHl8fGJsb29kKXtcbiAgICAgIGNvbnN0IHJhd1Bvc2U9cGFpbnRlci5yZWR1Y2VkTW90aW9ufHwocGFpbnRlci5zdGlsbCYmdW5pdE1vdmVyKHVuaXQua2luZCk9PT1cInNlYVwiKT9JRExFX0ZSQU1FOnBhaW50ZXIuYW5pbWF0aW9uPy5mcmFtZSh1bml0LG5vdyk/P0lETEVfRlJBTUU7XG4gICAgICBjb25zdCBmYWNpbmc9cGFpbnRlci5mYWNpbmcuYWN0aW9uRmFjaW5nKHVuaXQuaWQscmF3UG9zZS5kaXJlY3Rpb24/P3Jhd1Bvc2UuY2FycnlEaXJlY3Rpb24scHJvamVjdFBhcGVyRGlyZWN0aW9uKTtcbiAgICAgIGNvbnN0IHBvc2U9cHJvamVjdEFjdGlvbkZyYW1lKHJhd1Bvc2UsZmFjaW5nKTtcbiAgICAgIGlmICghb3ZlcmxheU9ubHkgJiYgbW9kZWwpIGRyYXdBdGxhc01vZGVsKGN0eCwgdW5pdC52YXJpYW50ISwgbW9kZWwsIHBvaW50LCBNYXRoLm1heCgwLjcyLCB1bml0LnJhZGl1cyAvIDE4KSwgU3RyaW5nKGN0eC5zdHJva2VTdHlsZSksIGZhY2luZywgcG9zZSxhcHBlYXJhbmNlRm9yKHBhaW50ZXIuc25hcHNob3QsdW5pdCkpO1xuICAgICAgZWxzZSBpZighb3ZlcmxheU9ubHkpIGRyYXdBdGxhc1VuaXQoY3R4LCB1bml0LmtpbmQsIHBvaW50LCBzY2FsZSwgU3RyaW5nKGN0eC5zdHJva2VTdHlsZSksIGZhY2luZywgcG9zZSwgYXBwZWFyYW5jZUZvcihwYWludGVyLnNuYXBzaG90LHVuaXQpKTtcbiAgICAgIGlmKGJsb29kKWRyYXdDb21iYXRCb2R5KGN0eCxibG9vZCx7eDpwb2ludC54LHk6cG9pbnQueSsobW9kZWw/MTcqTWF0aC5tYXgoLjcyLHVuaXQucmFkaXVzLzE4KTooY3JlYXR1cmVTaGFkb3codW5pdC5raW5kKT8ueT8/MTcpKnNjYWxlKX0sYW5jaG9yPy5mYWNpbmc/P2ZhY2luZyk7XG4gICAgfVxuICAgIGlmKHVuaXQuaWQ9PT0ndGlkZS1hZG1pcmFsJyl7XG4gICAgICBjdHguZmlsbFN0eWxlPScjZWRkMDk0JztjdHguc3Ryb2tlU3R5bGU9JyMyNjM3M2QnO2N0eC5saW5lV2lkdGg9MjtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtjdHgubW92ZVRvKHBvaW50LngscG9pbnQueS02NSk7Y3R4LmxpbmVUbyhwb2ludC54KzYscG9pbnQueS01Nyk7Y3R4LmxpbmVUbyhwb2ludC54LHBvaW50LnktNDkpO2N0eC5saW5lVG8ocG9pbnQueC02LHBvaW50LnktNTcpO2N0eC5jbG9zZVBhdGgoKTtjdHguZmlsbCgpO2N0eC5zdHJva2UoKTtcbiAgICB9XG4gICAgY29uc3Qgc2NvcmNoID0gcGFpbnRlci5hYmlsaXR5RWZmZWN0cz8uc3RhdHVzZXMuZ2V0KHVuaXQuaWQpPy5maW5kKChlZmZlY3QpID0+IGVmZmVjdC50eXBlID09PSBcInNjb3JjaFwiKTtcbiAgICBpZiAoc2NvcmNoICYmIHNjb3JjaC5yZW1haW5pbmc+MCkgZHJhd1Njb3JjaGVkVW5pdEZsYW1lcyhjdHgsIHBvaW50LCB1bml0LnJhZGl1cywgcGFpbnRlci5yZWR1Y2VkTW90aW9uPzA6bm93LCBzY29yY2gucmVtYWluaW5nKTtcbiAgICBpZihwYWludGVyLmFiaWxpdHlFZmZlY3RzKWRyYXdVbml0U3RhdHVzRWZmZWN0cyhjdHgsdW5pdCxwYWludGVyLmFiaWxpdHlFZmZlY3RzLHBvaW50LFxuICAgICAge3g6cG9pbnQueCx5OnBvaW50LnkrKGNyZWF0dXJlU2hhZG93KHVuaXQua2luZCk/Lnk/PzE3KSpzY2FsZX0sXG4gICAgICB7eDpwb2ludC54LHk6YW5jaG9yP2FuY2hvci50b3BZLXBhaW50ZXIuY2FtZXJhLnkrc2hha2UueTpwb2ludC55LTY0KnNjYWxlfSxub3cscGFpbnRlci5yZWR1Y2VkTW90aW9uLHNlbGVjdGVkKTtcbiAgICBpZiAodW5pdC5raW5kID09PSBcIndvcmtlclwiICYmIHVuaXQuY2FycnlpbmdHb2xkID4gMCkgZHJhd0NhcnJpZWRHb2xkKGN0eCwgcG9pbnQueCwgcG9pbnQueSk7XG4gICAgaWYgKHVuaXQubGV2ZWwgPiAwKSBkcmF3TGV2ZWxTdGFyKGN0eCwgcG9pbnQueCArIHVuaXQucmFkaXVzICsgNSwgcG9pbnQueSAtIHVuaXQucmFkaXVzIC0gNSwgdW5pdC5sZXZlbCk7XG4gICAgaWYgKHNob3VsZFNob3dIZWFsdGhCYXIoeyBocDogdW5pdC5ocCwgbWF4SHA6IHVuaXQubWF4SHAsIHNoaXBIdWxsOiBCb29sZWFuKHNoaXBQcm9maWxlKHVuaXQpKSwgc2VsZWN0ZWQsIGhvdmVyZWQ6IHBhaW50ZXIuaG92ZXJlZElkID09PSB1bml0LmlkLCBlbmdhZ2VkOiBlbmdhZ2VkLmhhcyh1bml0LmlkKSwgc3RpbGw6IHBhaW50ZXIuc3RpbGwgfSkpIGRyYXdIcChjdHgsIHBvaW50LngsIHBvaW50LnkgLSBNYXRoLm1heCh1bml0LnJhZGl1cyAqIDEuOCArIDYsIDY0ICogc2NhbGUgKyA2KSwgdW5pdC5ocCwgdW5pdC5tYXhIcCk7XG4gICAgaWYgKHNlbGVjdGVkICYmIHBhaW50ZXIuY29udHJvbEdyb3Vwcykge1xuICAgICAgY29uc3QgZGlnaXRzID0gT2JqZWN0LmVudHJpZXMocGFpbnRlci5jb250cm9sR3JvdXBzKS5maWx0ZXIoKFssIGlkc10pID0+IGlkcy5pbmNsdWRlcyh1bml0LmlkKSkubWFwKChbZGlnaXRdKSA9PiBkaWdpdCkuam9pbihcIsK3XCIpO1xuICAgICAgaWYgKGRpZ2l0cykge1xuICAgICAgICBjdHguc2F2ZSgpOyBjdHguZm9udCA9IFwiMTFweCBzYW5zLXNlcmlmXCI7IGN0eC50ZXh0QWxpZ24gPSBcImxlZnRcIjtcbiAgICAgICAgY3R4LmxpbmVXaWR0aD0yOyBjdHguc3Ryb2tlU3R5bGU9XCIjMTcyMDFjYWFcIjsgY3R4LmZpbGxTdHlsZT1cIiNmZmZcIjtcbiAgICAgICAgY3R4LnN0cm9rZVRleHQoZGlnaXRzLHBvaW50LngrdW5pdC5yYWRpdXMqLjcscG9pbnQueSt1bml0LnJhZGl1cysxMCk7XG4gICAgICAgIGN0eC5maWxsVGV4dChkaWdpdHMscG9pbnQueCt1bml0LnJhZGl1cyouNyxwb2ludC55K3VuaXQucmFkaXVzKzEwKTsgY3R4LnJlc3RvcmUoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8gV2hlcmUgYSB1bml0IGlzIGRyYXduIHRoaXMgZnJhbWU6IGl0cyBzbmFwc2hvdCBzcG90LCBvciBvbiBpdHMgZ2xpZGUgd2hlbiBpdCBjaGFyZ2VzIChzZWUgdW5pdC1tb3Rpb24pLlxuZnVuY3Rpb24gZHJhd25Qb3NpdGlvbihwYWludGVyOiBQYWludGVyLCB1bml0OiBVbml0KTogUG9pbnQge1xuICBjb25zdCBhbmNob3IgPSB1bml0Lmdhbmd3YXkgJiYgcGFpbnRlci5hY3RvclBvc2l0aW9ucz8uZ2V0KHVuaXQuaWQpO1xuICBpZiAoYW5jaG9yKSByZXR1cm4gYW5jaG9yO1xuICBjb25zdCBicmlkZ2UgPSBnYW5nd2F5Q3Jld1Zpc3VhbFBvc2UodW5pdCwgcGFpbnRlci5zaGlwcywgcGFpbnRlci5nYW5nd2F5cyk7XG4gIGlmIChicmlkZ2UpIHJldHVybiBicmlkZ2U7XG4gIGlmICh1bml0LmRlY2spIHtcbiAgICBjb25zdCBzaGlwID0gcGFpbnRlci5zaGlwcy5nZXQodW5pdC5kZWNrLnNoaXBJZCk7XG4gICAgaWYgKHNoaXApIHtcbiAgICAgIGNvbnN0IHBhcmVudCA9IHBhaW50ZXIubW90aW9uID8gcGFpbnRlci5tb3Rpb24ucG9zaXRpb24oc2hpcCwgcGFpbnRlci5ub3cpIDogc2hpcDtcbiAgICAgIGNvbnN0IGhlYWRpbmcgPSBwYWludGVyLm1vdGlvbj8uaGVhZGluZyhzaGlwLHBhaW50ZXIubm93KSA/PyBzaGlwLnNhaWxpbmc/LmhlYWRpbmcgPz8gMCwgYyA9IE1hdGguY29zKGhlYWRpbmcpLCBzID0gTWF0aC5zaW4oaGVhZGluZyk7XG4gICAgICByZXR1cm4geyB4OiBwYXJlbnQueCArIHVuaXQuZGVjay54KmMtdW5pdC5kZWNrLnkqcywgeTogcGFyZW50LnkgKyB1bml0LmRlY2sueCpzK3VuaXQuZGVjay55KmMgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHBhaW50ZXIubW90aW9uID8gcGFpbnRlci5tb3Rpb24ucG9zaXRpb24odW5pdCwgcGFpbnRlci5ub3cpIDogdW5pdDtcbn1cblxuZnVuY3Rpb24gaGFzQ2FycmllZEl0ZW0oc25hcHNob3Q6IEdhbWVTbmFwc2hvdCwgdW5pdDogVW5pdCwga2luZDogV29ybGRJdGVtW1wia2luZFwiXSkge1xuICByZXR1cm4gaXRlbXNGb3Ioc25hcHNob3QsdW5pdCkuc29tZSgoaXRlbSkgPT4gaXRlbS5raW5kID09PSBraW5kICYmIGl0ZW1FcXVpcHBlZChzbmFwc2hvdCx1bml0LGl0ZW0pKTtcbn1cblxuZnVuY3Rpb24gZHJhd0ZsYW1lQ2xvYWtBdXJhKGN0eDogQnJ1c2gsIHBvaW50OiBQb2ludCwgbm93OiBudW1iZXIsIHJhZGl1czogbnVtYmVyKSB7XG4gIGNvbnN0IHB1bHNlID0gMC41NSArIE1hdGguc2luKG5vdyAvIDE0MCkgKiAwLjE0O1xuICBjdHguc2F2ZSgpO1xuICBjdHguc3Ryb2tlU3R5bGUgPSBgcmdiYSgxNTAsIDYwLCA1NCwgJHtwdWxzZX0pYDtcbiAgY3R4LmZpbGxTdHlsZSA9IFwicmdiYSgyNDIsIDEzNywgNzUsIDAuMTIpXCI7XG4gIGN0eC5saW5lV2lkdGggPSAyO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5lbGxpcHNlKHBvaW50LngsIHBvaW50LnkgKyAxMywgcmFkaXVzICsgMTQsIChyYWRpdXMgKyAxNCkgKiAwLjQyLCAwLCAwLCBNYXRoLlBJICogMik7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5zdHJva2UoKTtcbiAgY3R4LnN0cm9rZVN0eWxlID0gXCJyZ2JhKDI0MiwgMTM3LCA3NSwgMC43MilcIjtcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IDU7IGluZGV4ICs9IDEpIHtcbiAgICBjb25zdCBhbmdsZSA9IG5vdyAvIDI2MCArIGluZGV4ICogMS4yNjtcbiAgICBjb25zdCB4ID0gcG9pbnQueCArIE1hdGguY29zKGFuZ2xlKSAqIChyYWRpdXMgKyA4KTtcbiAgICBjb25zdCB5ID0gcG9pbnQueSArIDEzICsgTWF0aC5zaW4oYW5nbGUpICogKHJhZGl1cyAqIDAuMzQpO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHgsIHkgKyA1KTtcbiAgICBjdHgucXVhZHJhdGljQ3VydmVUbyh4IC0gNSwgeSAtIDMsIHggKyAxLCB5IC0gMTEpO1xuICAgIGN0eC5xdWFkcmF0aWNDdXJ2ZVRvKHggKyA2LCB5IC0gMywgeCArIDMsIHkgKyA1KTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gIH1cbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gZHJhd0l0ZW1zKHBhaW50ZXI6IFBhaW50ZXIsIGl0ZW1zOiBXb3JsZEl0ZW1bXSwgc2hpcD86IFVuaXQpIHtcbiAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgaWYgKGl0ZW0uY2FycmllcklkIHx8IGl0ZW0uc2hpcElkKSBjb250aW51ZTtcbiAgICBpZihzaGlwID8gaXRlbS5kZWNrPy5zaGlwSWQhPT1zaGlwLmlkIDogaXRlbS5kZWNrKWNvbnRpbnVlO1xuICAgIGNvbnN0IHBvc2l0aW9uPXNoaXAgJiYgaXRlbS5kZWNrID8gbG9jYWxUb1dvcmxkKHsuLi5zaGlwLC4uLmRyYXduUG9zaXRpb24ocGFpbnRlcixzaGlwKX0saXRlbS5kZWNrKSA6IGl0ZW07XG4gICAgY29uc3QgcG9pbnQgPSB3b3JsZFRvU2NyZWVuKHBhaW50ZXIsIHBvc2l0aW9uKTtcbiAgICBpZihzaGlwKXBvaW50LnktPWRlY2tWaXN1YWxIZWlnaHQoc2hpcCk7XG4gICAgaWYgKCFuZWFyU2NyZWVuKHBhaW50ZXIsIHBvaW50LCA0MikpIGNvbnRpbnVlO1xuICAgIGRyYXdJdGVtR2x5cGgocGFpbnRlci5jdHgsIGl0ZW0sIHBvaW50LCBwYWludGVyLm5vdywgZmFsc2UpO1xuICB9XG59XG5cbi8vIEEgcmluZydzIGNvbG91cjogZnJpZW5kIG9yIGZvZSB0byB0aGUgcGxheWVyIGxvb2tpbmcgb24gKHNlZSBAQEByZWxhdGlvbi1pbmspLCBvciB3aXRoIG5vIG9uZSBsb29raW5nLCB0aGUgb3duZXIncy5cbmZ1bmN0aW9uIHJpbmdJbmsocGFpbnRlcjogUGFpbnRlciwgb3duZXI6IE93bmVyKSB7XG4gIHJldHVybiBwYWludGVyLnZpZXdlciA/IFJFTEFUSU9OX0lOS1tyZWxhdGlvblRvKHBhaW50ZXIuc25hcHNob3QsIHBhaW50ZXIudmlld2VyLCBvd25lcildIDogb3duZXJJbmsob3duZXIsIHBhaW50ZXIuc25hcHNob3QpO1xufVxuXG5mdW5jdGlvbiBkcmF3R3JvdW5kU2VsZWN0aW9uTWFya2VycyhwYWludGVyOlBhaW50ZXIpIHtcbiAgZm9yKGNvbnN0IHVuaXQgb2YgcGFpbnRlci52aWV3SW5kZXgucXVlcnkoe3g6cGFpbnRlci5jYW1lcmEueCx5OnBhaW50ZXIuY2FtZXJhLnksd2lkdGg6cGFpbnRlci53aWR0aCxoZWlnaHQ6cGFpbnRlci5oZWlnaHR9KSlpZighdW5pdC5kZWNrKWRyYXdVbml0U2VsZWN0aW9uTWFya2VyKHBhaW50ZXIsdW5pdCk7XG4gIGZvcihjb25zdCBidWlsZGluZyBvZiBwYWludGVyLnNuYXBzaG90LmJ1aWxkaW5ncykge1xuICAgIGNvbnN0IHNlbGVjdGVkPXBhaW50ZXIuc2VsZWN0ZWRJZHMuaGFzKGJ1aWxkaW5nLmlkKTtcbiAgICBpZigoc2VsZWN0ZWQgfHwgcGFpbnRlci5ob3ZlcmVkSWQ9PT1idWlsZGluZy5pZCkgJiYgbmVhclNjcmVlbihwYWludGVyLHdvcmxkVG9TY3JlZW4ocGFpbnRlcixidWlsZGluZyksYnVpbGRpbmcucmFkaXVzKzgwKSlcbiAgICAgIGRyYXdGb3VuZGF0aW9uQm91bmRhcnkocGFpbnRlcixidWlsZGluZyxyaW5nSW5rKHBhaW50ZXIsYnVpbGRpbmcub3duZXIpLHNlbGVjdGVkKTtcbiAgfVxuICBmb3IoY29uc3Qgc2l0ZSBvZiBbLi4ucGFpbnRlci5zbmFwc2hvdC5tZXJjZW5hcnlDYW1wcywuLi4ocGFpbnRlci5zbmFwc2hvdC5zaG9wcz8/W10pXSkge1xuICAgIGNvbnN0IHNlbGVjdGVkPXBhaW50ZXIuc2VsZWN0ZWRDYW1wSWQ9PT1zaXRlLmlkO1xuICAgIGlmKChzZWxlY3RlZCB8fCBwYWludGVyLmhvdmVyZWRJZD09PXNpdGUuaWQpICYmIG5lYXJTY3JlZW4ocGFpbnRlcix3b3JsZFRvU2NyZWVuKHBhaW50ZXIsc2l0ZSksc2l0ZS5yYWRpdXMrODApKVxuICAgICAgZHJhd0ZvdW5kYXRpb25Cb3VuZGFyeShwYWludGVyLHNpdGUsJyM5Njc3NGEnLHNlbGVjdGVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkcmF3VW5pdFNlbGVjdGlvbk1hcmtlcihwYWludGVyOlBhaW50ZXIsdW5pdDpVbml0KSB7XG4gIGNvbnN0IHNlbGVjdGVkPXBhaW50ZXIuc2VsZWN0ZWRJZHMuaGFzKHVuaXQuaWQpO1xuICBpZih1bml0LmhwPD0wIHx8IGlzSW5DYWJpbih1bml0KSB8fCAoIXNlbGVjdGVkICYmIHBhaW50ZXIuaG92ZXJlZElkIT09dW5pdC5pZCkpcmV0dXJuO1xuICBjb25zdCB7Y3R4fT1wYWludGVyLGF0PWRyYXduUG9zaXRpb24ocGFpbnRlcix1bml0KSxwcm9maWxlPXNoaXBQcm9maWxlKHVuaXQpO1xuICBjb25zdCBwYXJlbnQ9dW5pdC5kZWNrICYmIHBhaW50ZXIuc2hpcHMuZ2V0KHVuaXQuZGVjay5zaGlwSWQpLGJyaWRnZT1nYW5nd2F5Q3Jld1Zpc3VhbFBvc2UodW5pdCxwYWludGVyLnNoaXBzLHBhaW50ZXIuZ2FuZ3dheXMpO1xuICBjb25zdCBzY2FsZT11bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cykqKHBhaW50ZXIubW9kZWxzICYmICF1bml0LnZhcmlhbnQgPyAuODoxKTtcbiAgY29uc3QgaGVpZ2h0PWJyaWRnZT9icmlkZ2UuaGVpZ2h0Kk1hdGgudGFuKFNISVBfQ0FNRVJBLnRpbHQpOnBhcmVudD9kZWNrVmlzdWFsSGVpZ2h0KHBhcmVudCk6MDtcbiAgY29uc3QgcG9pbnQ9d29ybGRUb1NjcmVlbihwYWludGVyLHt4OmF0LngseTphdC55LWhlaWdodH0pO1xuICBpZighbmVhclNjcmVlbihwYWludGVyLHBvaW50LE1hdGgubWF4KDYwLHVuaXQucmFkaXVzKjMpKSlyZXR1cm47XG4gIGN0eC5zYXZlKCk7Y3R4LnN0cm9rZVN0eWxlPXJpbmdJbmsocGFpbnRlcix1bml0Lm93bmVyKTtjdHgubGluZVdpZHRoPXNlbGVjdGVkPzM6MjtjdHguYmVnaW5QYXRoKCk7XG4gIGlmKHByb2ZpbGUpIHtcbiAgICBjb25zdCBoZWFkaW5nPXBhaW50ZXIubW90aW9uPy5oZWFkaW5nKHVuaXQscGFpbnRlci5ub3cpPz91bml0LnNhaWxpbmc/LmhlYWRpbmc/P3VuaXQuZmFjaW5nPz8wO1xuICAgIGNvbnN0IGh1bGw9ey4uLnVuaXQseDphdC54LHk6YXQueSxzYWlsaW5nOntoZWFkaW5nLHNwZWVkOjAsbG9hZDowLGJhbGFuY2U6MH19O1xuICAgIHByb2ZpbGUuaHVsbC5mb3JFYWNoKCh2ZXJ0ZXgsaW5kZXgpPT57Y29uc3QgcD13b3JsZFRvU2NyZWVuKHBhaW50ZXIsbG9jYWxUb1dvcmxkKGh1bGwsdmVydGV4KSk7aWYoaW5kZXg9PT0wKWN0eC5tb3ZlVG8ocC54LHAueSk7ZWxzZSBjdHgubGluZVRvKHAueCxwLnkpO30pO2N0eC5jbG9zZVBhdGgoKTtcbiAgfWVsc2Uge1xuICAgIC8vIExhbmQgc3ByaXRlcyB1c2UgYSBib2R5LW9yaWdpbjsgZWxldmF0ZWQgY3JldyB1c2UgYSBmZWV0LW9yaWdpbiBhZnRlclxuICAgIC8vIHRoZWlyIGRlY2svZ2FuZ3dheSBsaWZ0LiBLZWVwIGJvdGggZXhpc3RpbmcgcG9zZXMgd2hpbGUgY2hhbmdpbmcgbGF5ZXIuXG4gICAgY29uc3QgYm9keUhlaWdodD1wYXJlbnQgfHwgYnJpZGdlPzE4KnNjYWxlOjAsZmVldD1wb2ludC55LWJvZHlIZWlnaHQrKGNyZWF0dXJlU2hhZG93KHVuaXQua2luZCk/Lnk/PzE3KSpzY2FsZTtcbiAgICBjb25zdCByYWRpdXM9KHVuaXQuYm9keVJhZGl1cz8/dW5pdC5yYWRpdXMpKzM7Y3R4LmVsbGlwc2UocG9pbnQueCxmZWV0LHJhZGl1cyxyYWRpdXMqLjU1LDAsMCxNYXRoLlBJKjIpO1xuICB9XG4gIGN0eC5zdHJva2UoKTtjdHgucmVzdG9yZSgpO1xufVxuXG5mdW5jdGlvbiBkcmF3Rm91bmRhdGlvbkJvdW5kYXJ5KHBhaW50ZXI6UGFpbnRlcixib2R5Ont4Om51bWJlcjt5Om51bWJlcjtyYWRpdXM6bnVtYmVyfSxjb2xvcjpzdHJpbmcsc2VsZWN0ZWQ6Ym9vbGVhbil7XG4gIGNvbnN0IHtjdHh9PXBhaW50ZXIsc3F1YXJlPWZvb3RwcmludFNxdWFyZShwYWludGVyLnNuYXBzaG90LGJvZHksYm9keS5yYWRpdXMpLHBvaW50PXdvcmxkVG9TY3JlZW4ocGFpbnRlcixib2R5KTtcbiAgY3R4LnNhdmUoKTtjdHguc3Ryb2tlU3R5bGU9Y29sb3I7Y3R4LmxpbmVXaWR0aD1zZWxlY3RlZD8yLjU6MS41O1xuICBpZihzcXVhcmUpe1xuICAgIGNvbnN0IHg9c3F1YXJlLmxlZnQqc3F1YXJlLmNlbGwtcGFpbnRlci5jYW1lcmEueCx5PXNxdWFyZS50b3Aqc3F1YXJlLmNlbGwtcGFpbnRlci5jYW1lcmEueTtcbiAgICBjb25zdCB3PShzcXVhcmUucmlnaHQtc3F1YXJlLmxlZnQrMSkqc3F1YXJlLmNlbGwsaD0oc3F1YXJlLmJvdHRvbS1zcXVhcmUudG9wKzEpKnNxdWFyZS5jZWxsO1xuICAgIGN0eC5zdHJva2VSZWN0KHgrMSx5KzEsdy0yLGgtMik7XG4gICAgaWYoc2VsZWN0ZWQpe2N0eC5nbG9iYWxBbHBoYT0uMDY7Y3R4LmZpbGxTdHlsZT1jb2xvcjtjdHguZmlsbFJlY3QoeCsxLHkrMSx3LTIsaC0yKTt9XG4gIH0gZWxzZSB7Y3R4LmJlZ2luUGF0aCgpO2N0eC5lbGxpcHNlKHBvaW50LngscG9pbnQueSxib2R5LnJhZGl1cyszLChib2R5LnJhZGl1cyszKSouNTUsMCwwLE1hdGguUEkqMik7Y3R4LnN0cm9rZSgpO31cbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gZHJhd0NhcnJpZWRHb2xkKGN0eDogQnJ1c2gsIHg6IG51bWJlciwgeTogbnVtYmVyKSB7XG4gIGN0eC5zYXZlKCk7XG4gIGN0eC5zdHJva2VTdHlsZSA9IFwiIzhhNjQxOFwiO1xuICBjdHguZmlsbFN0eWxlID0gXCIjZjJkMDVjXCI7XG4gIGN0eC5saW5lV2lkdGggPSAyO1xuICBjdHguYmVnaW5QYXRoKCk7XG4gIGN0eC5tb3ZlVG8oeCAtIDYsIHkgLSAyNCk7XG4gIGN0eC5saW5lVG8oeCArIDIsIHkgLSAzNCk7XG4gIGN0eC5saW5lVG8oeCArIDEwLCB5IC0gMjMpO1xuICBjdHgubGluZVRvKHggKyAxLCB5IC0gMTgpO1xuICBjdHguY2xvc2VQYXRoKCk7XG4gIGN0eC5maWxsKCk7XG4gIGN0eC5zdHJva2UoKTtcbiAgY3R4LnJlc3RvcmUoKTtcbn1cblxuZnVuY3Rpb24gZHJhd0l0ZW1HbHlwaChjdHg6IEJydXNoLCBpdGVtOiBXb3JsZEl0ZW0sIHBvaW50OiBQb2ludCwgX25vdzogbnVtYmVyLCBfY2FycmllZDogYm9vbGVhbikge1xuICBkcmF3UGFpbnRlZEl0ZW0oY3R4LCBpdGVtLmtpbmQsIHBvaW50LCAzMCwgdHJ1ZSxpdGVtLndlYXBvbktpbmQpO1xufVxuXG5mdW5jdGlvbiBkcmF3SHAoY3R4OiBCcnVzaCwgeDogbnVtYmVyLCB5OiBudW1iZXIsIGhwOiBudW1iZXIsIG1heEhwOiBudW1iZXIsIHdpZHRoID0gMzQpIHtcbiAgY29uc3QgcmF0aW8gPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBocCAvIE1hdGgubWF4KDEsIG1heEhwKSkpO1xuICBjdHguZmlsbFN0eWxlID0gXCIjMzE0ODNhXCI7XG4gIGN0eC5maWxsUmVjdCh4IC0gd2lkdGggLyAyIC0gMSwgeSAtIDEsIHdpZHRoICsgMiwgNSk7XG4gIGN0eC5maWxsU3R5bGUgPSBoZWFsdGhCYXJDb2xvcihocCwgbWF4SHApO1xuICBjdHguZmlsbFJlY3QoeCAtIHdpZHRoIC8gMiwgeSwgd2lkdGggKiByYXRpbywgMyk7XG59XG5cbmZ1bmN0aW9uIGRyYXdQcm9ncmVzcyhjdHg6IEJydXNoLCB4OiBudW1iZXIsIHk6IG51bWJlciwgcmF0aW86IG51bWJlcikge1xuICBjdHguZmlsbFN0eWxlID0gXCJyZ2JhKDM1LCA0OSwgMzgsIDAuMTgpXCI7XG4gIGN0eC5maWxsUmVjdCh4IC0gMjgsIHksIDU2LCA1KTtcbiAgY3R4LmZpbGxTdHlsZSA9IFwiIzMxNWY4N1wiO1xuICBjdHguZmlsbFJlY3QoeCAtIDI4LCB5LCA1NiAqIE1hdGgubWF4KDAsIE1hdGgubWluKDEsIHJhdGlvKSksIDUpO1xufVxuXG5mdW5jdGlvbiBkcmF3VHJhaW5pbmdQcm9ncmVzcyhwYWludGVyOiBQYWludGVyLCB4OiBudW1iZXIsIHk6IG51bWJlciwgcmVtYWluaW5nOiBudW1iZXIsIHVuaXRLaW5kOiBUcmFpbmFibGVVbml0S2luZCwgcXVldWVMZW5ndGg6IG51bWJlcikge1xuICBjb25zdCB7IGN0eCB9ID0gcGFpbnRlcjtcbiAgY29uc3QgdG90YWwgPSBVTklUX0RFRlNbdW5pdEtpbmRdLnRyYWluVGltZTtcbiAgZHJhd1Byb2dyZXNzKGN0eCwgeCwgeSwgMSAtIHJlbWFpbmluZyAvIHRvdGFsKTtcbiAgY3R4LmZpbGxTdHlsZSA9IFwiIzMxNWY4N1wiO1xuICBjdHguZm9udCA9IFwiOXB4IHVpLW1vbm9zcGFjZSwgbW9ub3NwYWNlXCI7XG4gIGNvbnN0IGNvdW50VGV4dCA9IHRyYWluaW5nUXVldWVDb3VudFRleHQocXVldWVMZW5ndGgpO1xuICBjdHguZmlsbFRleHQoYCR7cGFpbnRlci5sYWJlbHMudW5pdEtpbmQodW5pdEtpbmQpfSR7Y291bnRUZXh0ID8gYCAke2NvdW50VGV4dH1gIDogXCJcIn1gLCB4IC0gMjcsIHkgKyAxNik7XG59XG5cbi8vIEBAQGhpdC1zaGFrZSAtIEEgc3VidGxlLCBkZWNheWluZyBjb250YWN0IHJlc3BvbnNlOyBzdHJvbmcgaGl0cyBjYW5ub3QgbW92ZVxuLy8gYSBzaWxob3VldHRlIGZhciBlbm91Z2ggdG8gcmVzZW1ibGUgcGF0aGluZyBvciBhIHNlY29uZCBhdHRhY2sgYW5pbWF0aW9uLlxuY29uc3QgSElUX1NIQUtFID0gNztcbmNvbnN0IE1BWF9ISVRfU0hBS0UgPSAyO1xuXG5mdW5jdGlvbiBoaXRGZWVkYmFja09mZnNldChzbmFwc2hvdDogR2FtZVNuYXBzaG90LCBlbnRpdHk6IFVuaXQgfCBCdWlsZGluZyB8IE9ic3RhY2xlLGhpdHM/OlJlYWRvbmx5TWFwPHN0cmluZyxXb3JsZEVmZmVjdD4pOiBQb2ludCB7XG4gIGNvbnN0IGhpdCA9IGhpdHM/aGl0cy5nZXQoZW50aXR5LmlkKTpzbmFwc2hvdC5lZmZlY3RzLmZpbmQoKGVmZmVjdCkgPT4gZWZmZWN0LnR5cGUgPT09IFwiaGl0XCIgJiYgZWZmZWN0LnVuaXRJZCA9PT0gZW50aXR5LmlkKTtcbiAgaWYgKCFoaXQpIHJldHVybiB7IHg6IDAsIHk6IDAgfTtcbiAgY29uc3QgYW1vdW50ID0gTWF0aC5taW4oTUFYX0hJVF9TSEFLRSwgKEhJVF9TSEFLRSAqIChoaXQuZGFtYWdlID8/IDApKSAvIE1hdGgubWF4KDEsIGVudGl0eS5tYXhIcCkpO1xuICBjb25zdCBsaWZlID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgaGl0LnJlbWFpbmluZyAvIGhpdC5kdXJhdGlvbikpO1xuICBjb25zdCBwdWxzZSA9IE1hdGguc2luKCgxLWxpZmUpICogTWF0aC5QSSAqIDIpICogYW1vdW50ICogbGlmZSAqIGxpZmU7XG4gIHJldHVybiB7IHg6IHB1bHNlLCB5OiAtcHVsc2UgKiAwLjM1IH07XG59XG5cbmZ1bmN0aW9uIHdvcmxkVG9TY3JlZW4ocGFpbnRlcjogUGFpbnRlciwgcG9pbnQ6IFBvaW50KTogUG9pbnQge1xuICByZXR1cm4geyB4OiBwb2ludC54IC0gcGFpbnRlci5jYW1lcmEueCwgeTogcG9pbnQueSAtIHBhaW50ZXIuY2FtZXJhLnkgfTtcbn1cblxuZnVuY3Rpb24gbmVhclNjcmVlbihwYWludGVyOiBQYWludGVyLCBwb2ludDogUG9pbnQsIHBhZDogbnVtYmVyKSB7XG4gIHJldHVybiBwb2ludC54ID49IC1wYWQgJiYgcG9pbnQueSA+PSAtcGFkICYmIHBvaW50LnggPD0gcGFpbnRlci53aWR0aCArIHBhZCAmJiBwb2ludC55IDw9IHBhaW50ZXIuaGVpZ2h0ICsgcGFkO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFRLDRCQUEyQjtBQUNuQyxTQUFRLDZCQUE0QjtBQUNwQyxTQUFTLG1CQUFtQixpQkFBaUIsZ0JBQWdCLHNCQUFzQjtBQUVuRixTQUFTLG9CQUFvQiw2QkFBNkI7QUFDMUQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0IsZ0JBQWdCLHFCQUFxQjtBQUVoRSxTQUFTLGVBQWUsMkJBQTJCO0FBQ25ELFNBQVMsY0FBYyxnQkFBZ0I7QUFDdkMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZSxrQkFBaUIsb0JBQW9CO0FBQzdELFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsY0FBYSxhQUFZLGtCQUFpQixnQkFBZSxtQkFBbUI7QUFDckYsU0FBUyxzQkFBMkM7QUFDcEQsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyxnQkFBZ0IsMkJBQTJCO0FBQ3BELFNBQVMsdUJBQXVCO0FBR2hDLFNBQVMsaUJBQWlCLG1CQUFtQixlQUFlLGlCQUFpQixtQkFBbUIsZUFBZSxnQkFBZ0IsbUJBQW1CLGVBQWUsZUFBZSxzQkFBc0I7QUFDdE0sU0FBUywwQkFBMEI7QUFDbkMsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyx3QkFBd0IsNkJBQTZCO0FBQzlELFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsc0JBQXNCO0FBRS9CLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsaUNBQWlDO0FBQzFDLFNBQVMsY0FBYyxrQkFBa0I7QUFDekMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUywrQkFBbUQ7QUFDNUQsU0FBUyw4QkFBOEI7QUFLdkMsU0FBUyxjQUFjLGlCQUFpQixnQkFBZ0IsdUJBQXVCO0FBRy9FLFNBQVMsZUFBZSxXQUFXLGlCQUFpQjtBQXdCN0MsZ0JBQVMsZUFBZSxNQUFrRDtBQUMvRSxTQUFPO0FBQUEsSUFDTCxnQkFBZ0IsQ0FBQyxVQUFVLEtBQUssRUFBRSx5QkFBeUIsRUFBRSxNQUFNLENBQUM7QUFBQSxJQUNwRSxVQUFVLENBQUMsU0FBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLEVBQ3JDO0FBQ0Y7QUE0RUEsTUFBTSxlQUFvQyxvQkFBSSxJQUFJO0FBQ2xELE1BQU0sb0JBQWtCLG9CQUFJLFFBQXFDO0FBRTFELGdCQUFTLFVBQVUsT0FBbUI7QUFDM0MsUUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRO0FBQ2hDLE1BQUksWUFBVSxNQUFNLGFBQVcsa0JBQWtCLElBQUksTUFBTSxHQUFHO0FBQzlELE1BQUcsQ0FBQyxXQUFVO0FBQUMsZ0JBQVUsSUFBSSxzQkFBc0I7QUFBRSxzQkFBa0IsSUFBSSxNQUFNLEtBQUksU0FBUztBQUFBLEVBQUU7QUFDaEcsUUFBTSxRQUFRLG9CQUFJLElBQWtCLEdBQUcsV0FBVyxvQkFBSSxJQUE0QjtBQUNsRixRQUFNLFVBQW1CO0FBQUEsSUFDdkI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCLE1BQU07QUFBQSxJQUN0QixXQUFXLE1BQU07QUFBQSxJQUNqQixlQUFlLE1BQU0saUJBQWlCO0FBQUEsSUFDdEMsS0FBSyxNQUFNO0FBQUEsSUFDWCxVQUFVLE1BQU07QUFBQSxJQUNoQixRQUFRLEVBQUUsR0FBRyxNQUFNLEtBQUssR0FBRyxHQUFHLE1BQU0sS0FBSyxFQUFFO0FBQUEsSUFDM0MsT0FBTyxNQUFNLEtBQUssUUFBUTtBQUFBLElBQzFCLFFBQVEsTUFBTSxLQUFLLFNBQVM7QUFBQSxJQUM1QixLQUFLLE1BQU07QUFBQSxJQUNYLFFBQVEsTUFBTTtBQUFBLElBQ2QsUUFBUSxNQUFNO0FBQUEsSUFDZCxRQUFRLE1BQU07QUFBQSxJQUNkLGFBQWEsTUFBTSxlQUFlO0FBQUEsSUFDbEMsZUFBZSxNQUFNO0FBQUEsSUFDckIsZ0JBQWdCLE1BQU07QUFBQSxJQUN0QixRQUFRLE1BQU07QUFBQSxJQUNkLFdBQVcsTUFBTTtBQUFBLElBQ2pCLFFBQVEsTUFBTTtBQUFBLElBQ2QsZ0JBQWdCLE1BQU07QUFBQSxJQUN0QixPQUFPLE1BQU0sU0FBUztBQUFBLElBQ3RCLFNBQVE7QUFBQSxFQUNWO0FBQ0EsUUFBTSxFQUFFLEtBQUssU0FBUyxJQUFJO0FBQzFCLFVBQVEsUUFBUSxPQUFPLFVBQVUsUUFBUSxHQUFHO0FBQzVDLFlBQVUsT0FBTyxVQUFTLFFBQVEsTUFBTTtBQUd4QyxNQUFJLENBQUMsTUFBTSxnQkFBZ0I7QUFDekIsZUFBVyxRQUFRLFNBQVMsTUFBTyxLQUFJLFlBQVksSUFBSSxHQUFHO0FBQ3hELFlBQU0sWUFBWSxFQUFFLEdBQUcsTUFBTSxHQUFHLFFBQVEsUUFBUSxTQUFTLE1BQU0sUUFBUSxHQUFHLEdBQUcsU0FBUyxFQUFFLEdBQUcsS0FBSyxTQUFVLFNBQVMsUUFBUSxRQUFRLFFBQVEsTUFBTSxRQUFRLEdBQUcsS0FBSyxLQUFLLFNBQVMsV0FBVyxFQUFFLEVBQUU7QUFDOUwsdUJBQWlCLE1BQU0sU0FBUztBQUFHLFlBQU0sSUFBSSxLQUFLLElBQUksU0FBUztBQUFBLElBQ2pFO0FBQ0EsZUFBVyxVQUFVLE1BQU0sT0FBTyxHQUFHO0FBQ25DLFlBQU0sU0FBUyxPQUFPLFNBQVMsV0FBVyxNQUFNLElBQUksT0FBTyxRQUFRLFFBQVEsUUFBUTtBQUNuRixZQUFNLFVBQVUsVUFBVSxlQUFlLFFBQVEsTUFBTTtBQUN2RCxVQUFJLFFBQVMsVUFBUyxJQUFJLE9BQU8sSUFBSSxPQUFPO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBQ0EsVUFBUSxXQUFXLE9BQU8sVUFBVSxRQUFRLEtBQUssTUFBTSxPQUFPLFdBQVc7QUFDekUsTUFBRyxDQUFDLE1BQU0saUJBQWlCLE1BQU0sU0FBTyxVQUFVLE9BQU0sT0FBTyxPQUFPLFVBQVMsUUFBUSxHQUFHO0FBQzFGLE1BQUcsQ0FBQyxNQUFNLGdCQUFlO0FBQ3ZCLG9CQUFnQixRQUFRLFFBQU8sUUFBUSxVQUFTLFVBQVUsUUFBUTtBQUNsRSxZQUFRLFdBQVcsa0JBQWtCLFFBQVEsS0FBSSxDQUFDLElBQUcsY0FBWSxRQUFRLE9BQU8sYUFBYSxJQUFHLFdBQVUscUJBQXFCLEdBQUUsUUFBUSxhQUFhO0FBQUEsRUFDeEo7QUFDQSxNQUFHLENBQUMsTUFBTSxlQUFlLE9BQU0sUUFBUSxPQUFPLFVBQVMsUUFBUSxLQUFJLHFCQUFxQixVQUFTLE1BQU0sV0FBVSxNQUFNLFFBQU8sTUFBTSxRQUFPLE1BQU0sZUFBYyxNQUFNLFNBQU8sTUFBRyxDQUFDLEdBQUUsV0FBTyxVQUFVLGlCQUFpQixLQUFLLENBQUM7QUFDMU4sUUFBTSxhQUFhLE9BQU8sVUFBUyxNQUFNLFFBQU8sUUFBSSxNQUFNLE9BQU8sY0FBYyxFQUFFLENBQUM7QUFDbEYsUUFBTSxTQUFPLE1BQU0sUUFBUSxNQUFNLFFBQVEsR0FBRztBQUM1QyxNQUFHLFVBQVEsQ0FBQyxNQUFNLGdCQUFlO0FBQy9CLFVBQU0sT0FBSyxvQkFBSSxJQUE0QztBQUMzRCxlQUFVLFFBQVEsT0FBTyxNQUFLO0FBQUMsWUFBTSxPQUFLLEtBQUssSUFBSSxLQUFLLE1BQU0sS0FBRyxDQUFDO0FBQUUsV0FBSyxLQUFLLElBQUk7QUFBRSxXQUFLLElBQUksS0FBSyxRQUFPLElBQUk7QUFBQSxJQUFFO0FBQy9HLFlBQVEsYUFBVztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxtQkFBaUIsRUFBQyxlQUFjLENBQUMsVUFBYyxjQUFjLFNBQVEsS0FBSyxHQUFFLFlBQVcsQ0FBQyxPQUFZLFFBQWEsV0FBVyxTQUFRLE9BQU0sR0FBRyxFQUFDO0FBQ3BKLE1BQUksS0FBSztBQUNULE1BQUksTUFBTSxNQUFNLElBQUk7QUFDcEIsTUFBRyxNQUFNLFNBQU8sV0FBVTtBQUMxQixRQUFJLFNBQVMsSUFBSSxTQUFTO0FBRXhCLHNCQUFnQixLQUFLLFFBQVEsT0FBTyxRQUFRLFFBQVEsUUFBUSxNQUFNO0FBQ2xFO0FBQUEsUUFBWTtBQUFBLFFBQUssU0FBUyxJQUFJO0FBQUEsUUFBUyxRQUFRO0FBQUEsUUFBUSxRQUFRO0FBQUEsUUFBTyxRQUFRO0FBQUEsUUFDNUUsTUFBTSxTQUFTLFlBQVksUUFBUSxnQkFBZ0IsU0FBWSxRQUFRLE1BQU07QUFBQSxNQUFJO0FBQUEsSUFDckYsT0FBTztBQUNMLG1CQUFhLEtBQUssU0FBUyxJQUFJLElBQUksUUFBUSxRQUFRLFFBQVEsT0FBTyxRQUFRLE1BQU07QUFBQSxJQUNsRjtBQUNBLFFBQUcsQ0FBQyxNQUFNLGNBQWMsT0FBTSxPQUFPLEtBQUssS0FBSSxFQUFDLEdBQUcsUUFBUSxRQUFPLE9BQU0sUUFBUSxPQUFNLFFBQU8sUUFBUSxPQUFNLEdBQUUsUUFBUSxHQUFHO0FBQ3ZILGtCQUFjLFNBQVMsU0FBUyxJQUFJLFNBQVM7QUFDN0MsUUFBRyxDQUFDLE1BQU0sZUFBZSw0QkFBMkIsT0FBTztBQUMzRCxRQUFJLE1BQU0sU0FBUyxNQUFNLE1BQU8sZ0JBQWUsS0FBSyxFQUFDLEdBQUcsTUFBTSxPQUFNLE9BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTyxVQUFNLENBQUMsTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBQyxHQUFHLENBQUMsVUFBVSxjQUFjLFNBQVMsS0FBSyxHQUFHLENBQUMsT0FBTyxRQUFRLFdBQVcsU0FBUyxPQUFPLEdBQUcsR0FBRyxNQUFNLE9BQU8sUUFBUSxHQUFHO0FBQzdRLGtCQUFjLFNBQVMsU0FBUyxTQUFTO0FBQ3pDLHVCQUFtQixTQUFTLFNBQVMsZ0JBQWUsT0FBTSxNQUFNLFNBQU8sUUFBUTtBQUMvRSxRQUFJLFNBQVMsTUFBTyxXQUFVLFNBQVMsU0FBUyxPQUFNLE9BQU0sTUFBTSxTQUFPLFFBQVE7QUFDakYsa0JBQWMsU0FBUyxTQUFTLGFBQWEsQ0FBQyxDQUFDO0FBQy9DLGNBQVUsU0FBUyxTQUFTLEtBQUs7QUFDakMsUUFBSSxNQUFNLE1BQU8saUJBQWdCLEtBQUssTUFBTSxPQUFPLENBQUMsVUFBVSxjQUFjLFNBQVMsS0FBSyxHQUFHLENBQUMsT0FBTyxRQUFRLFdBQVcsU0FBUyxPQUFPLEdBQUcsQ0FBQztBQUM1SSxRQUFHLE9BQU8sa0JBQWlCLEtBQUksUUFBTyxnQkFBZ0I7QUFFdEQsZUFBVSxVQUFVLFNBQVMsV0FBVyxDQUFDLEdBQUU7QUFDekMsVUFBRyxPQUFPLEtBQUs7QUFDZixZQUFNLFFBQU0sY0FBYyxTQUFRLE1BQU07QUFDeEMsVUFBRyxDQUFDLFdBQVcsU0FBUSxPQUFNLEVBQUUsRUFBRTtBQUNqQyxVQUFJLEtBQUs7QUFBRSxVQUFJLGVBQWEsZUFBZSxTQUFTLE1BQUssT0FBTyxVQUFVO0FBQzFFLFlBQU0sUUFBTSxPQUFPLFVBQVUsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0FBQzlELHNCQUFnQixLQUFJLE9BQU8sTUFBSyxPQUFNLFFBQVEsS0FBSyxJQUFJLE1BQUksT0FBTyxTQUFPLEVBQUUsSUFBSSxlQUFlLE9BQU8sTUFBTSxHQUFFLGVBQWUsT0FBTyxFQUFFLEdBQUUsT0FBTSxPQUFPLFNBQVEsU0FBUyxPQUFPLE9BQU0sUUFBUSxHQUFFLG9CQUFvQixVQUFTLE1BQU0sQ0FBQztBQUFFLFVBQUksUUFBUTtBQUFBLElBQ2hQO0FBQUEsRUFDQTtBQUNBLE1BQUcsTUFBTSxTQUFPLFVBQVM7QUFBQyxRQUFJLFFBQVE7QUFBRTtBQUFBLEVBQU87QUFDL0MsVUFBUSxVQUFRLFVBQVUsV0FBVztBQUNyQyxVQUFRLGlCQUFlLHVCQUF1QixRQUFRO0FBQ3RELE1BQUcsTUFBTSxTQUFPLFdBQVU7QUFBQyx1QkFBbUIsU0FBUSxTQUFTLGdCQUFlLElBQUk7QUFBRSxRQUFHLFNBQVMsTUFBTSxXQUFVLFNBQVEsU0FBUyxPQUFNLElBQUk7QUFBQSxFQUFFO0FBRTdJLE1BQUksQ0FBQyxRQUFRLFNBQVMsTUFBTSxPQUFRLFlBQVcsVUFBVSxVQUFVLFVBQVU7QUFDM0UsUUFBSSxVQUFVLE1BQU0sS0FBSyxPQUFPLFVBQVUsTUFBTSxVQUFVLE9BQU8sTUFBTSxTQUFTLFFBQVM7QUFDekYsVUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLGNBQWMsU0FBUyxLQUFLO0FBQ2hFLFFBQUksQ0FBQyxXQUFXLFNBQVMsT0FBTyxHQUFHLEVBQUc7QUFDdEMsUUFBSSxLQUFLO0FBQUcsUUFBSSxjQUFjO0FBQzlCLHNCQUFrQixLQUFLLE1BQU0sY0FBYyxPQUFPLGtCQUFrQixNQUFNLFlBQVksR0FBRyxTQUFTO0FBQ2xHLFFBQUksUUFBUTtBQUNaLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTSxHQUFHLFFBQVEsS0FBSyxjQUFjLE1BQU0sWUFBWSxFQUFFLE1BQU07QUFDeEYsVUFBSSxLQUFLO0FBQUcsVUFBSSxZQUFVO0FBQVcsVUFBSSxPQUFLO0FBQW1CLFVBQUksWUFBVTtBQUMvRSxVQUFJLFNBQVMsTUFBTSxXQUFXLE9BQU8sU0FBUyxvQkFBb0IsTUFBTSxHQUFHLE1BQU0sSUFBRSxFQUFFO0FBQUcsVUFBSSxRQUFRO0FBQUEsSUFDdEc7QUFBQSxFQUNGO0FBRUEsTUFBSSxNQUFNLFNBQVMsVUFBVyxjQUFhLE9BQU87QUFDbEQsUUFBTSxpQkFBZSxVQUFVLE1BQU0sTUFBTSxJQUFJO0FBQy9DLE1BQUcsTUFBTSxTQUFPLFdBQVU7QUFBQyxrQkFBYyxTQUFRLFNBQVMsV0FBVSxJQUFJO0FBQUUsY0FBVSxTQUFRLGdCQUFlLElBQUk7QUFBQSxFQUFFLE9BQzVHO0FBQ0gsVUFBTSxTQUFPLENBQUMsR0FBRyxTQUFTLFdBQVUsR0FBRyxlQUFlLE9BQU8sVUFBTSxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUUsT0FBTyxPQUFHLFdBQVcsU0FBUSxjQUFjLFNBQVEsQ0FBQyxHQUFFLEtBQUssSUFBSSxLQUFJLEVBQUUsU0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFFLE1BQUksRUFBRSxJQUFFLEVBQUUsQ0FBQztBQUNwTCxlQUFVLFNBQVMsT0FBTyxLQUFHLFdBQVcsT0FBTTtBQUFDLFVBQUcsWUFBWSxLQUFLLEVBQUUsZUFBYyxTQUFRLEtBQUs7QUFBQSxVQUFPLFdBQVUsU0FBUSxDQUFDLEtBQUssQ0FBQztBQUFBLElBQUUsTUFBTSxlQUFjLFNBQVEsQ0FBQyxLQUFLLENBQUM7QUFBQSxFQUN2SztBQUNBLE1BQUksQ0FBQyxRQUFRLFNBQVMsUUFBUSxPQUFRLGNBQWEsT0FBTztBQUUxRCxRQUFNLFlBQVksVUFBVTtBQUM1QixNQUFHLFVBQVEsQ0FBQyxNQUFNLGVBQWUsa0JBQWlCLEtBQUksUUFBTyxrQkFBaUIsSUFBSTtBQUNsRixNQUFHLFVBQVEsQ0FBQyxNQUFNLGVBQWUsZUFBYyxLQUFJLFFBQU8sa0JBQWlCLENBQUMsSUFBRyxRQUFPLGFBQVc7QUFDL0YsVUFBTSxPQUFLLFVBQVUsSUFBSSxFQUFFO0FBQUUsUUFBRyxDQUFDLFFBQU0sVUFBVSxJQUFJLEVBQUUsUUFBTztBQUM5RCxVQUFNLFNBQU8sUUFBUSxnQkFBZ0IsSUFBSSxFQUFFO0FBQzNDLFVBQU0sS0FBRyxTQUFPLEVBQUMsR0FBRSxPQUFPLEdBQUUsR0FBRSxPQUFPLE1BQUssSUFBRSxjQUFjLFNBQVEsSUFBSTtBQUN0RSxVQUFNLE9BQUssS0FBSyxPQUFLLFFBQVEsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNLElBQUU7QUFDekQsVUFBTSxRQUFNLEtBQUssVUFBUSxRQUFRLFNBQVMsS0FBSyxPQUFPLElBQUU7QUFDeEQsVUFBTSxRQUFNLFFBQU0sS0FBRyxLQUFLLElBQUksTUFBSSxLQUFLLFNBQU8sRUFBRSxLQUFHLGVBQWUsS0FBSyxJQUFJLEdBQUcsS0FBRyxNQUFJLGVBQWUsS0FBSyxNQUFNO0FBQy9HLFdBQU8sY0FBYyxTQUFRLEVBQUMsR0FBRSxHQUFHLElBQUUsU0FBUyxJQUFFLEtBQUssR0FBRSxHQUFFLEdBQUcsSUFBRSxTQUFTLElBQUUsS0FBSyxJQUFFLFNBQU8sU0FBTyxJQUFFLE9BQUssaUJBQWlCLElBQUksSUFBRSxLQUFHLGVBQWUsS0FBSyxNQUFNLElBQUUsS0FBRyxTQUFPLEtBQUssSUFBSSxZQUFZLElBQUksRUFBQyxDQUFDO0FBQUEsRUFDbE0sR0FBRSxRQUFRLGFBQWE7QUFDdkIscUJBQW1CO0FBQUEsSUFDakI7QUFBQSxJQUNBLFNBQVEsU0FBUztBQUFBLElBQ2pCLFNBQVMsU0FBUyxRQUFRLE9BQU8sWUFBUSxDQUFDLE1BQU0saUJBQWlCLElBQUksT0FBTyxJQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsVUFBVSxJQUFJLE9BQU8sTUFBTSxLQUFLLFVBQVUsVUFBVSxJQUFJLE9BQU8sTUFBTSxDQUFFLEVBQUU7QUFBQSxJQUNqTCxlQUFlLENBQUMsVUFBVSxjQUFjLFNBQVMsS0FBSztBQUFBLElBQ3RELFlBQVksQ0FBQyxPQUFPLFFBQVEsV0FBVyxTQUFTLE9BQU8sR0FBRztBQUFBLElBQzFELFFBQU8sUUFBUTtBQUFBLElBQ2YsZUFBYyxRQUFRO0FBQUEsSUFDdEIsY0FBYSxRQUFRLE1BQU07QUFBQSxJQUMzQixrQkFBaUIsWUFBUSxNQUFNLGFBQWEsT0FBTyxRQUFPLE1BQU0saUJBQWUsUUFBTSxRQUFRO0FBQUEsSUFDN0YsTUFBSyxDQUFDLE9BQUssVUFBVSxJQUFJLEVBQUU7QUFBQSxJQUMzQixjQUFjLENBQUMsT0FBTztBQUNwQixZQUFNLE9BQU8sVUFBVSxJQUFJLEVBQUU7QUFDN0IsVUFBRyxDQUFDLFFBQVEsVUFBVSxJQUFJLEVBQUUsUUFBTztBQUNuQyxZQUFNLFNBQU8sUUFBUSxnQkFBZ0IsSUFBSSxFQUFFO0FBQzNDLFVBQUcsT0FBTyxRQUFNLEVBQUMsR0FBRSxPQUFPLEdBQUUsR0FBRSxPQUFPLE1BQUs7QUFDMUMsWUFBTSxLQUFHLGNBQWMsU0FBUSxJQUFJLEdBQUUsU0FBTyxLQUFLLE9BQUssUUFBUSxNQUFNLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBRTtBQUMxRixhQUFPLFNBQU8sRUFBQyxHQUFFLEdBQUcsR0FBRSxHQUFFLEdBQUcsSUFBRSxpQkFBaUIsTUFBTSxJQUFFLEtBQUcsZUFBZSxLQUFLLE1BQU0sRUFBQyxJQUFFO0FBQUEsSUFDeEY7QUFBQSxFQUNGLENBQUM7QUFDRCxNQUFJLFFBQVE7QUFDWixNQUFJLE1BQU0sT0FBTztBQUNmLFVBQU0sZUFBZTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLFFBQVEsTUFBTSxVQUFVO0FBQUEsTUFDeEIsT0FBTyxNQUFNLEtBQUs7QUFBQSxNQUNsQixRQUFRLE1BQU0sS0FBSztBQUFBLE1BQ25CO0FBQUEsTUFDQSxTQUFTLENBQUMsVUFBaUI7QUFDekIsY0FBTSxLQUFLLGNBQWMsU0FBUyxLQUFLO0FBQ3ZDLGVBQU8sRUFBRSxHQUFHLEdBQUcsSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLEtBQUs7QUFBQSxNQUMxQztBQUFBLE1BQ0EsUUFBUSxDQUFDLFdBQW1CO0FBQzFCLGNBQU0sT0FBTyxVQUFVLElBQUksTUFBTTtBQUNqQyxlQUFPLFFBQVEsQ0FBQyxVQUFVLElBQUksSUFBSSxFQUFFLEdBQUcsY0FBYyxTQUFTLElBQUksR0FBRyxRQUFRLEtBQUssT0FBTyxJQUFJO0FBQUEsTUFDL0Y7QUFBQSxJQUNGO0FBQ0EsaUJBQWEsWUFBWTtBQUN6QixvQkFBZ0IsWUFBWTtBQUFBLEVBQzlCO0FBQ0Y7QUFHTyxnQkFBUyxnQkFBZ0IsUUFBMkIsVUFBdUIsZ0JBQTJDO0FBQzNILE1BQUk7QUFDSixTQUFPLGVBQWUsVUFBUyxDQUFDLE9BQUs7QUFDbkMsUUFBRyxlQUFlLFFBQU8sZUFBZSxJQUFJLEVBQUU7QUFDOUMsUUFBRyxDQUFDLFdBQVU7QUFBQyxrQkFBVSxvQkFBSSxJQUFJO0FBQUUsaUJBQVUsVUFBVSxTQUFTLE1BQU0sV0FBVSxJQUFJLE9BQU8sSUFBRyxNQUFNO0FBQUUsaUJBQVUsVUFBVSxTQUFTLFVBQVUsV0FBVSxJQUFJLE9BQU8sSUFBRyxNQUFNO0FBQUEsSUFBRTtBQUM3SyxXQUFPLFVBQVUsSUFBSSxFQUFFO0FBQUEsRUFDekIsQ0FBQztBQUNIO0FBRU8sZ0JBQVMsYUFBYSxLQUFZLE9BQWMsUUFBZSxPQUFlLFFBQWdCO0FBQ25HLGtCQUFnQixLQUFLLE9BQU8sUUFBUSxNQUFNO0FBQzFDLGFBQVcsVUFBVSx3QkFBd0IsRUFBRSxPQUFPLFFBQVEsT0FBTyxPQUFPLENBQUMsR0FBRztBQUM5RSxzQkFBa0IsS0FBSyxNQUFNO0FBQUEsRUFDL0I7QUFDRjtBQUVPLGdCQUFTLFNBQVMsT0FBMEIsVUFBMEM7QUFBRSxTQUFPLFlBQVksT0FBTyxRQUFRO0FBQUc7QUFFN0gsZ0JBQVMsa0JBQWtCLE1BQW9CO0FBQ3BELFNBQU8sS0FBSyxNQUFNLGNBQWMsSUFBSSxFQUFFLFNBQVMsSUFBSTtBQUNyRDtBQUVBLFNBQVMsa0JBQWtCLEtBQVksUUFBdUI7QUFDNUQsTUFBSSxPQUFPLE9BQU8sV0FBVyxFQUFHO0FBQ2hDLE1BQUksY0FBYyxPQUFPO0FBQ3pCLE1BQUksWUFBWSxPQUFPO0FBQ3ZCLE1BQUksVUFBVTtBQUNkLE1BQUksT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLEdBQUcsT0FBTyxPQUFPLENBQUMsRUFBRyxDQUFDO0FBQ25ELGFBQVcsU0FBUyxPQUFPLE9BQU8sTUFBTSxDQUFDLEVBQUcsS0FBSSxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFDdkUsTUFBSSxPQUFPO0FBQ2I7QUFFQSxTQUFTLGNBQWMsU0FBa0IsV0FBOEI7QUFDckUsYUFBVyxZQUFZLFdBQVc7QUFDaEMsVUFBTSxRQUFRLGNBQWMsU0FBUyxRQUFRO0FBQzdDLFFBQUksV0FBVyxTQUFTLE9BQU8sU0FBUyxPQUFPLEVBQUUsRUFBRyxtQkFBa0IsUUFBUSxLQUFLLFVBQVUsS0FBSztBQUFBLEVBQ3BHO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsU0FBa0IsV0FBMkI7QUFDbEUsUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixhQUFXLFlBQVksV0FBVztBQUNoQyxVQUFNLFFBQVEsY0FBYyxTQUFTLFFBQVE7QUFDN0MsUUFBSSxDQUFDLFdBQVcsU0FBUyxPQUFPLEVBQUUsRUFBRztBQUNyQyxrQkFBYyxLQUFLLEtBQUs7QUFDeEIsUUFBSSxRQUFRLE1BQU87QUFDbkIsUUFBSSxPQUFPO0FBQ1gsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUNoQixRQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsTUFBTSxFQUFFLGVBQWUsR0FBRyxNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUU7QUFDL0UsUUFBSSxZQUFZO0FBQUEsRUFDbEI7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLFNBQWtCLE9BQXVCLGNBQVksT0FBTSxhQUFXLE9BQU87QUFDdkcsUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixhQUFXLFFBQVEsT0FBTztBQUN4QixVQUFNLFFBQVEsY0FBYyxTQUFTLElBQUk7QUFDekMsUUFBSSxDQUFDLFdBQVcsU0FBUyxPQUFPLEdBQUcsRUFBRztBQUN0QyxRQUFHLENBQUMsZUFBZSxDQUFDLFFBQVEsZ0JBQWdCLElBQUksS0FBSyxFQUFFLEVBQUUsZUFBYyxLQUFLLEtBQUs7QUFDakYsUUFBRyxXQUFXO0FBQ2QsUUFBSSxPQUFPO0FBQ1gsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUNoQixRQUFJLFNBQVMsUUFBUSxPQUFPLGVBQWUsS0FBSyxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQzdFLFFBQUksWUFBWTtBQUNoQixRQUFJLEtBQUssb0JBQW9CLEVBQUcsY0FBYSxLQUFLLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSSxJQUFJLEtBQUssb0JBQW9CLEtBQUssUUFBUTtBQUFBLEVBQ3JIO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsU0FBa0IsV0FBdUI7QUFDOUQsYUFBVyxZQUFZLFdBQVc7QUFDaEMsVUFBTSxRQUFRLGtCQUFrQixRQUFRLFVBQVUsVUFBUyxRQUFRLFVBQVUsSUFBSTtBQUNqRixVQUFNLFFBQVEsY0FBYyxTQUFTLEVBQUUsR0FBRyxTQUFTLElBQUksTUFBTSxHQUFHLEdBQUcsU0FBUyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ3pGLFFBQUksQ0FBQyxXQUFXLFNBQVMsT0FBTyxTQUFTLFNBQVMsRUFBRSxFQUFHO0FBQ3ZELHNCQUFrQixRQUFRLEtBQUssVUFBVSxLQUFLO0FBQzlDLFFBQUksQ0FBQyxRQUFRLFNBQVMsU0FBUyxLQUFLLFNBQVMsTUFBTyxRQUFPLFFBQVEsS0FBSyxNQUFNLEdBQUcsTUFBTSxJQUFJLGVBQWUsUUFBUSxJQUFJLElBQUksU0FBUyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQ3ZKO0FBQ0Y7QUFFQSxTQUFTLFVBQVUsU0FBa0IsT0FBYyxjQUFZLE9BQU0sYUFBVyxPQUFPO0FBQ3JGLFFBQU0sRUFBRSxJQUFJLElBQUk7QUFDaEIsYUFBVyxRQUFRLE9BQU87QUFDeEIsVUFBTSxRQUFRLGNBQWMsU0FBUyxJQUFJO0FBQ3pDLFFBQUksQ0FBQyxXQUFXLFNBQVMsT0FBTyxHQUFHLEVBQUc7QUFDdEMsUUFBRyxDQUFDLGVBQWUsQ0FBQyxRQUFRLGdCQUFnQixJQUFJLEtBQUssRUFBRSxFQUFFLGVBQWMsS0FBSyxLQUFLO0FBQUEsRUFDbkY7QUFDRjtBQUVBLFNBQVMsY0FBYyxTQUFrQixXQUFzQixjQUFZLE9BQU87QUFDaEYsUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixRQUFNLFVBQVUsUUFBUTtBQUN4QixhQUFXLFlBQVksV0FBVztBQUNoQyxVQUFNLFFBQVEsa0JBQWtCLFFBQVEsVUFBVSxVQUFTLFFBQVEsVUFBVSxJQUFJO0FBQ2pGLFVBQU0sUUFBUSxjQUFjLFNBQVMsRUFBRSxHQUFHLFNBQVMsSUFBSSxNQUFNLEdBQUcsR0FBRyxTQUFTLElBQUksTUFBTSxFQUFFLENBQUM7QUFDekYsVUFBTSxXQUFXLFFBQVEsWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNwRCxVQUFNLFlBQVksY0FBYyxTQUFTLElBQUksRUFBRSxPQUFPLFNBQVM7QUFDL0QsVUFBTSxhQUFhLGNBQWMsU0FBUyxFQUFFLEdBQUcsU0FBUyxRQUFRLEdBQUcsU0FBUyxPQUFPLENBQUM7QUFDcEYsVUFBTSxZQUFZLDBCQUEwQixFQUFFLFVBQVUsV0FBVyxPQUFNLFNBQVMsT0FBTyxRQUFPLFFBQVEsT0FBTyxDQUFDO0FBQ2hILFFBQUksQ0FBQyxXQUFXLFNBQVMsT0FBTyxHQUFHLEdBQUc7QUFDcEMsVUFBSSxVQUFXLG1CQUFrQixLQUFLLFVBQVUsT0FBTyxZQUFZLFNBQVMsU0FBUyxPQUFPLFFBQVEsUUFBUSxDQUFDO0FBQzdHO0FBQUEsSUFDRjtBQUNBLFFBQUksY0FBYyxTQUFTLFNBQVMsT0FBTyxRQUFRLFFBQVE7QUFDM0QsUUFBSSxZQUFZLFNBQVMsV0FBVyw4QkFBOEI7QUFDbEUsUUFBSSxZQUFZLFdBQVcsSUFBSTtBQUMvQixVQUFNLE9BQU8sa0JBQWtCLFNBQVMsSUFBSTtBQUM1QyxRQUFJLEtBQUs7QUFDVCxRQUFJLGNBQWMsU0FBUyxXQUFXLElBQUk7QUFDMUMsUUFBRyxDQUFDLFlBQVksbUJBQWtCLEtBQUssUUFBUSxpQkFBaUIsU0FBUyxFQUFFLEtBQUssU0FBUyxNQUFNLE9BQU8sTUFBTSxTQUFTLFNBQVMsT0FBTyxRQUFRLFFBQVEsQ0FBQztBQUN0SixRQUFJLFFBQVE7QUFDWixRQUFJLFVBQVcsbUJBQWtCLEtBQUssVUFBVSxPQUFPLFlBQVksU0FBUyxTQUFTLE9BQU8sUUFBUSxRQUFRLENBQUM7QUFDN0csUUFBSSxvQkFBb0IsRUFBRSxJQUFJLFNBQVMsSUFBSSxPQUFPLFNBQVMsT0FBTyxVQUFVLFNBQVMsUUFBUSxjQUFjLFNBQVMsSUFBSSxTQUFTLFFBQVEsSUFBSSxTQUFTLEVBQUUsR0FBRyxjQUFjLENBQUMsU0FBUyxVQUFVLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRyxRQUFPLEtBQUssTUFBTSxHQUFHLFFBQVEsZ0JBQWdCLElBQUksU0FBUyxFQUFFLEdBQUcsU0FBTyxTQUFVLFFBQVEsZUFBZSxJQUFJLFNBQVMsRUFBRSxFQUFHLE9BQUssUUFBUSxPQUFPLElBQUUsSUFBRSxNQUFNLElBQUksT0FBTyxPQUFPLEdBQUcsU0FBUyxJQUFJLFNBQVMsT0FBTyxFQUFFO0FBQ2phLFFBQUksQ0FBQyxTQUFTLFNBQVUsY0FBYSxLQUFLLE1BQU0sR0FBRyxNQUFNLElBQUksT0FBTyxNQUFNLElBQUksU0FBUyxnQkFBZ0IsU0FBUyxTQUFTO0FBQ3pILFFBQUksU0FBUyxZQUFZLFNBQVMsTUFBTSxDQUFDLEdBQUc7QUFDMUMsMkJBQXFCLFNBQVMsTUFBTSxHQUFHLE1BQU0sSUFBSSxPQUFPLE1BQU0sSUFBSSxTQUFTLE1BQU0sQ0FBQyxFQUFFLFdBQVcsU0FBUyxNQUFNLENBQUMsRUFBRSxVQUFVLFNBQVMsTUFBTSxNQUFNO0FBQUEsSUFDbEo7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGFBQWEsU0FBa0I7QUFDdEMsUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixhQUFXLFFBQVEsUUFBUSxVQUFVLFFBQVE7QUFDM0MsVUFBTSxNQUFNLEtBQUs7QUFDakIsUUFBSSxVQUFVLElBQUksS0FBSyxLQUFLLFVBQVUsUUFBUSxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsVUFBVSxjQUFjLFFBQVEsT0FBTyxNQUFNLEVBQUUsU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFHO0FBQzVJLFVBQU0sT0FBTyxjQUFjLFNBQVMsY0FBYyxTQUFTLElBQUksQ0FBQyxHQUFHLEtBQUssY0FBYyxTQUFTLEdBQUc7QUFDbEcsUUFBSSxDQUFDLFdBQVcsU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDLFdBQVcsU0FBUyxJQUFJLEVBQUUsRUFBRztBQUNwRSxRQUFJLEtBQUs7QUFDVCxRQUFJLGNBQWMsUUFBUSxZQUFZLElBQUksS0FBSyxFQUFFLElBQUksTUFBSztBQUMxRCxRQUFJLGNBQWMsSUFBSSxXQUFXLFlBQVk7QUFDN0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWSxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUMsUUFBSSxVQUFVO0FBQUcsUUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLENBQUM7QUFBRyxRQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUFHLFFBQUksT0FBTztBQUNoRixRQUFJLFlBQVksQ0FBQyxDQUFDO0FBQ2xCLFFBQUksVUFBVTtBQUFHLFFBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN0RCxRQUFJLE9BQU8sR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO0FBQUcsUUFBSSxPQUFPLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQztBQUNyRCxRQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0FBQUcsUUFBSSxPQUFPLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztBQUFHLFFBQUksT0FBTztBQUNuRSxRQUFJLFFBQVE7QUFBQSxFQUNkO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixLQUFZLFVBQW9CLE1BQWEsSUFBVyxPQUFlO0FBQ2hHLE1BQUksS0FBSztBQUNULFFBQU0sSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHO0FBQ3ZCLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFBRyxNQUFJLFFBQVEsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQUcsTUFBSSxLQUFLO0FBQy9FLE1BQUksY0FBYztBQUFXLE1BQUksWUFBWTtBQUM3QyxNQUFJLFVBQVU7QUFBRyxNQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFBRyxNQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUU7QUFBRyxNQUFJLE9BQU87QUFDekUsTUFBSSxjQUFjO0FBQVcsTUFBSSxZQUFZO0FBQzdDLE1BQUksVUFBVTtBQUFHLE1BQUksT0FBTyxJQUFJLEtBQUksQ0FBQztBQUFHLE1BQUksT0FBTyxJQUFJLEtBQUksSUFBSSxFQUFFO0FBQUcsTUFBSSxPQUFPO0FBQy9FLE1BQUksWUFBWTtBQUNoQixNQUFJLFVBQVU7QUFBRyxNQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksRUFBRTtBQUFHLE1BQUksT0FBTyxJQUFJLElBQUksSUFBSSxFQUFFO0FBQ3JFLE1BQUksT0FBTyxJQUFJLElBQUksSUFBSSxFQUFFO0FBQUcsTUFBSSxPQUFPLElBQUksSUFBSSxJQUFJLEVBQUU7QUFBRyxNQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksRUFBRTtBQUFHLE1BQUksVUFBVTtBQUFHLE1BQUksS0FBSztBQUFHLE1BQUksT0FBTztBQUMzSCxNQUFJLFFBQVE7QUFDZDtBQUVBLFNBQVMsY0FBYyxTQUFnQixNQUFXO0FBQ2hELFFBQU0sUUFBTSxjQUFjLFNBQVEsY0FBYyxTQUFRLElBQUksQ0FBQztBQUM3RCxNQUFHLFFBQVEsVUFBVSxLQUFLLFFBQVEsUUFBSyxFQUFDLEdBQUcsTUFBSyxTQUFRLEVBQUMsR0FBRyxLQUFLLFNBQVEsU0FBUSxRQUFRLE9BQU8sUUFBUSxNQUFLLFFBQVEsR0FBRyxFQUFDLEVBQUM7QUFDMUgsUUFBTSxPQUFLLGVBQWUsUUFBUSxTQUFTLE9BQU0sSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFFLE1BQUksRUFBRSxJQUFFLEVBQUUsQ0FBQztBQUcxRSxpQkFBZSxRQUFRLEtBQUksTUFBSyxPQUFNLFFBQVEsU0FBUyxPQUFNLE1BQUk7QUFDL0QsVUFBTSxLQUFHLGNBQWMsU0FBUSxJQUFJO0FBQ25DLGVBQVUsVUFBVSxrQkFBa0IsUUFBUSxTQUFTLE9BQU8sRUFBRSxJQUFJLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRTtBQUNqRixZQUFNLE9BQUssZ0JBQWdCLFFBQU8sTUFBSyxFQUFDLEdBQUcsSUFBRyxTQUFRLEtBQUssU0FBUyxXQUFTLEVBQUMsQ0FBQztBQUMvRSxVQUFHLENBQUMsS0FBSztBQUNULFlBQU0sU0FBTyxjQUFjLFNBQVEsRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssSUFBRSxpQkFBaUIsSUFBSSxFQUFDLENBQUM7QUFDN0UsWUFBTSxRQUFNLE9BQU8sVUFBUSxRQUFRLFNBQVMsT0FBTyxPQUFPLElBQUU7QUFDNUQsY0FBUSxJQUFJLEtBQUs7QUFBRSxjQUFRLElBQUksVUFBVSxPQUFPLEdBQUUsT0FBTyxDQUFDO0FBQUUsY0FBUSxJQUFJLE9BQU8sS0FBSyxPQUFPO0FBQzNGLGNBQVEsSUFBSSxlQUFhLGVBQWUsUUFBUSxTQUFTLE1BQUssT0FBTyxVQUFVO0FBQy9FLHNCQUFnQixRQUFRLEtBQUksT0FBTyxNQUFLLEVBQUMsR0FBRSxHQUFFLEdBQUUsRUFBQyxHQUFFLFFBQU0sS0FBSyxJQUFJLE1BQUksT0FBTyxTQUFPLEVBQUUsSUFBRSxlQUFlLE9BQU8sTUFBTSxHQUFFLGVBQWUsT0FBTyxFQUFFLEdBQUUsT0FBTSxPQUFPLFNBQVEsU0FBUyxPQUFPLE9BQU0sUUFBUSxRQUFRLEdBQUUsb0JBQW9CLFFBQVEsVUFBUyxNQUFNLENBQUM7QUFDeFAsY0FBUSxJQUFJLFFBQVE7QUFBQSxJQUN0QjtBQUNBLGVBQVUsYUFBYSxLQUFLLHlCQUF3QixTQUFRLFNBQVM7QUFBQSxFQUN2RSxDQUFDO0FBQ0QsZUFBYSxRQUFRLEtBQUksTUFBSyxPQUFNLFNBQVMsS0FBSyxPQUFPLFFBQVEsUUFBUSxDQUFDO0FBQzFFLFlBQVUsU0FBUSxRQUFRLFNBQVMsT0FBTSxJQUFJO0FBQzdDLGFBQVUsYUFBYSxLQUFLLFdBQVUsU0FBUSxDQUFDLFNBQVMsQ0FBQztBQUN6RCxZQUFVLFNBQVEsQ0FBQyxJQUFJLEdBQUUsSUFBSTtBQUMvQjtBQUVBLFNBQVMsYUFBYSxTQUFrQjtBQUN0QyxRQUFNLEVBQUUsSUFBSSxJQUFJO0FBQ2hCLGFBQVcsQ0FBQyxJQUFJLE9BQU8sS0FBSyxRQUFRLFVBQVU7QUFDNUMsVUFBTSxTQUFTLFFBQVEsTUFBTSxJQUFJLEVBQUUsR0FBSSxTQUFTLFFBQVEsTUFBTSxJQUFJLE9BQU8sUUFBUyxRQUFTLFFBQVE7QUFDbkcsVUFBTSxLQUFLLFFBQVEsT0FBTyxJQUFJLFFBQVEsT0FBTyxHQUFHLEtBQUssUUFBUSxPQUFPLElBQUksUUFBUSxPQUFPLEdBQUcsUUFBUSxLQUFLLEtBQUssS0FBSztBQUNqSCxVQUFNLFVBQVUsQ0FBQyxVQUFpQjtBQUNoQyxZQUFNLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0sTUFBTSxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQ2xILFlBQU0sU0FBUyxpQkFBaUIsTUFBTSxLQUFLLGlCQUFpQixNQUFNLElBQUksaUJBQWlCLE1BQU0sS0FBSztBQUNsRyxhQUFPLGNBQWMsU0FBUyxFQUFFLEdBQUcsTUFBTSxHQUFHLEdBQUcsTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLElBQ25FO0FBQ0EsVUFBTSxTQUFTLFFBQVEsRUFBRSxJQUFJLFFBQVEsT0FBTyxJQUFJLFFBQVEsT0FBTyxLQUFLLEdBQUcsSUFBSSxRQUFRLE9BQU8sSUFBSSxRQUFRLE9BQU8sS0FBSyxFQUFFLENBQUM7QUFDckgsUUFBSSxDQUFDLFdBQVcsU0FBUyxRQUFRLEdBQUcsRUFBRztBQUN2QyxRQUFJLEtBQUs7QUFBRyxRQUFJLGNBQWMsUUFBUSxVQUFVLGNBQWMsT0FBTTtBQUNwRSxRQUFJLFlBQVk7QUFBVyxRQUFJLGNBQWM7QUFBVyxRQUFJLFlBQVk7QUFDeEUsUUFBSSxVQUFVO0FBQUcsWUFBUSxRQUFRLFFBQVEsQ0FBQyxPQUFPLFVBQVU7QUFBRSxZQUFNLEtBQUssUUFBUSxLQUFLO0FBQUcsVUFBSSxNQUFPLEtBQUksT0FBTyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQUEsVUFBUSxLQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQUcsQ0FBQztBQUN6SixRQUFJLFVBQVU7QUFBRyxRQUFJLEtBQUs7QUFBRyxRQUFJLE9BQU87QUFBRyxRQUFJLFFBQVE7QUFBQSxFQUN6RDtBQUNGO0FBRUEsU0FBUyxVQUFVLFNBQWtCLE9BQXdCLGNBQVksT0FBTztBQUM5RSxRQUFNLEVBQUUsS0FBSyxJQUFJLElBQUk7QUFDckIsUUFBTSxVQUFVLFFBQVE7QUFDeEIsYUFBVyxRQUFRLE9BQU87QUFDeEIsUUFBSSxVQUFVLElBQUksRUFBRztBQUNyQixVQUFNLFFBQVEsa0JBQWtCLFFBQVEsVUFBVSxNQUFLLFFBQVEsVUFBVSxJQUFJO0FBQzdFLFVBQU0sU0FBTyxRQUFRLGdCQUFnQixJQUFJLEtBQUssRUFBRTtBQUNoRCxVQUFNLEtBQUssU0FBTyxFQUFDLEdBQUUsT0FBTyxHQUFFLEdBQUUsT0FBTyxNQUFLLElBQUUsY0FBYyxTQUFTLElBQUk7QUFDekUsVUFBTSxPQUFLLEtBQUssT0FBTyxRQUFRLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJO0FBQzdELFVBQU0sU0FBUyxDQUFDLFVBQVUsc0JBQXNCLE1BQU0sUUFBUSxPQUFPLFFBQVEsUUFBUTtBQUNyRixVQUFNLGFBQWEsS0FBRyxlQUFlLEtBQUssTUFBTSxLQUFHLFFBQVEsVUFBVSxDQUFDLEtBQUssVUFBVSxNQUFLO0FBQzFGLFVBQU0sU0FBTyxTQUFPLElBQUUsU0FBUyxPQUFPLFNBQVMsS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLGFBQWEsT0FBTyxpQkFBaUIsSUFBSSxJQUFFLGFBQWE7QUFDcEksVUFBTSxRQUFRLGNBQWMsU0FBUyxFQUFFLEdBQUcsR0FBRyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxNQUFNLElBQUUsT0FBTyxDQUFDO0FBQ3BGLFVBQU0sUUFBUSxlQUFlLEtBQUssTUFBTSxLQUFLLFFBQVEsVUFBVSxDQUFDLEtBQUssVUFBVSxNQUFLO0FBQ3BGLFFBQUksQ0FBQyxXQUFXLFNBQVMsT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQUc7QUFDaEUsVUFBTSxXQUFXLFFBQVEsWUFBWSxJQUFJLEtBQUssRUFBRTtBQUNoRCxRQUFJLGNBQWMsU0FBUyxLQUFLLE9BQU8sUUFBUSxRQUFRO0FBQ3ZELFFBQUksWUFBWSxLQUFLLFVBQVUsWUFBWSxZQUFZO0FBQ3ZELFFBQUksWUFBWSxXQUFXLElBQUk7QUFDL0IsUUFBSSxlQUFlLFFBQVEsVUFBVSxNQUFNLFlBQVksRUFBRyxvQkFBbUIsS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO0FBQ3pHLFVBQU0sUUFBUSxLQUFLLFlBQVksU0FBWSxRQUFRLFNBQVMsS0FBSyxPQUFPLElBQUk7QUFDNUUsVUFBTSxRQUFNLFFBQVEsWUFBWSxJQUFJLEtBQUssRUFBRTtBQUMzQyxRQUFHLENBQUMsZUFBYSxPQUFNO0FBQ3JCLFlBQU0sVUFBUSxRQUFRLGlCQUFnQixRQUFRLFNBQU8sVUFBVSxLQUFLLElBQUksTUFBSSxRQUFPLGFBQVcsUUFBUSxXQUFXLE1BQU0sTUFBSyxHQUFHLEtBQUc7QUFDbEksWUFBTSxTQUFPLFFBQVEsT0FBTyxhQUFhLEtBQUssSUFBRyxRQUFRLGFBQVcsUUFBUSxnQkFBZSxxQkFBcUI7QUFDaEgsWUFBTSxPQUFLLG1CQUFtQixTQUFRLE1BQU07QUFDNUMsVUFBSSxDQUFDLGVBQWUsTUFBTyxnQkFBZSxLQUFLLEtBQUssU0FBVSxPQUFPLE9BQU8sS0FBSyxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUUsR0FBRyxPQUFPLElBQUksV0FBVyxHQUFHLFFBQVEsTUFBSyxjQUFjLFFBQVEsVUFBUyxJQUFJLENBQUM7QUFBQSxlQUNoTCxDQUFDLFlBQWEsZUFBYyxLQUFLLEtBQUssTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJLFdBQVcsR0FBRyxRQUFRLE1BQU0sY0FBYyxRQUFRLFVBQVMsSUFBSSxDQUFDO0FBQzdJLFVBQUcsTUFBTSxnQkFBZSxLQUFJLE9BQU0sRUFBQyxHQUFFLE1BQU0sR0FBRSxHQUFFLE1BQU0sS0FBRyxRQUFNLEtBQUcsS0FBSyxJQUFJLE1BQUksS0FBSyxTQUFPLEVBQUUsS0FBRyxlQUFlLEtBQUssSUFBSSxHQUFHLEtBQUcsTUFBSSxPQUFNLEdBQUUsUUFBUSxVQUFRLE1BQU07QUFBQSxJQUNqSztBQUNBLFFBQUcsS0FBSyxPQUFLLGdCQUFlO0FBQzFCLFVBQUksWUFBVTtBQUFVLFVBQUksY0FBWTtBQUFVLFVBQUksWUFBVTtBQUNoRSxVQUFJLFVBQVU7QUFBRSxVQUFJLE9BQU8sTUFBTSxHQUFFLE1BQU0sSUFBRSxFQUFFO0FBQUUsVUFBSSxPQUFPLE1BQU0sSUFBRSxHQUFFLE1BQU0sSUFBRSxFQUFFO0FBQUUsVUFBSSxPQUFPLE1BQU0sR0FBRSxNQUFNLElBQUUsRUFBRTtBQUFFLFVBQUksT0FBTyxNQUFNLElBQUUsR0FBRSxNQUFNLElBQUUsRUFBRTtBQUFFLFVBQUksVUFBVTtBQUFFLFVBQUksS0FBSztBQUFFLFVBQUksT0FBTztBQUFBLElBQ3hMO0FBQ0EsVUFBTSxTQUFTLFFBQVEsZ0JBQWdCLFNBQVMsSUFBSSxLQUFLLEVBQUUsR0FBRyxLQUFLLENBQUMsV0FBVyxPQUFPLFNBQVMsUUFBUTtBQUN2RyxRQUFJLFVBQVUsT0FBTyxZQUFVLEVBQUcsd0JBQXVCLEtBQUssT0FBTyxLQUFLLFFBQVEsUUFBUSxnQkFBYyxJQUFFLEtBQUssT0FBTyxTQUFTO0FBQy9ILFFBQUcsUUFBUSxlQUFlO0FBQUEsTUFBc0I7QUFBQSxNQUFJO0FBQUEsTUFBSyxRQUFRO0FBQUEsTUFBZTtBQUFBLE1BQzlFLEVBQUMsR0FBRSxNQUFNLEdBQUUsR0FBRSxNQUFNLEtBQUcsZUFBZSxLQUFLLElBQUksR0FBRyxLQUFHLE1BQUksTUFBSztBQUFBLE1BQzdELEVBQUMsR0FBRSxNQUFNLEdBQUUsR0FBRSxTQUFPLE9BQU8sT0FBSyxRQUFRLE9BQU8sSUFBRSxNQUFNLElBQUUsTUFBTSxJQUFFLEtBQUcsTUFBSztBQUFBLE1BQUU7QUFBQSxNQUFJLFFBQVE7QUFBQSxNQUFjO0FBQUEsSUFBUTtBQUMvRyxRQUFJLEtBQUssU0FBUyxZQUFZLEtBQUssZUFBZSxFQUFHLGlCQUFnQixLQUFLLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFDMUYsUUFBSSxLQUFLLFFBQVEsRUFBRyxlQUFjLEtBQUssTUFBTSxJQUFJLEtBQUssU0FBUyxHQUFHLE1BQU0sSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLLEtBQUs7QUFDdkcsUUFBSSxvQkFBb0IsRUFBRSxJQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssT0FBTyxVQUFVLFFBQVEsWUFBWSxJQUFJLENBQUMsR0FBRyxVQUFVLFNBQVMsUUFBUSxjQUFjLEtBQUssSUFBSSxTQUFTLFFBQVEsSUFBSSxLQUFLLEVBQUUsR0FBRyxPQUFPLFFBQVEsTUFBTSxDQUFDLEVBQUcsUUFBTyxLQUFLLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssU0FBUyxNQUFNLEdBQUcsS0FBSyxRQUFRLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLO0FBQzdTLFFBQUksWUFBWSxRQUFRLGVBQWU7QUFDckMsWUFBTSxTQUFTLE9BQU8sUUFBUSxRQUFRLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsTUFBTSxJQUFJLFNBQVMsS0FBSyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxLQUFLLE1BQU0sS0FBSyxFQUFFLEtBQUssR0FBRztBQUNoSSxVQUFJLFFBQVE7QUFDVixZQUFJLEtBQUs7QUFBRyxZQUFJLE9BQU87QUFBbUIsWUFBSSxZQUFZO0FBQzFELFlBQUksWUFBVTtBQUFHLFlBQUksY0FBWTtBQUFhLFlBQUksWUFBVTtBQUM1RCxZQUFJLFdBQVcsUUFBTyxNQUFNLElBQUUsS0FBSyxTQUFPLEtBQUcsTUFBTSxJQUFFLEtBQUssU0FBTyxFQUFFO0FBQ25FLFlBQUksU0FBUyxRQUFPLE1BQU0sSUFBRSxLQUFLLFNBQU8sS0FBRyxNQUFNLElBQUUsS0FBSyxTQUFPLEVBQUU7QUFBRyxZQUFJLFFBQVE7QUFBQSxNQUNsRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsU0FBa0IsTUFBbUI7QUFDMUQsUUFBTSxTQUFTLEtBQUssV0FBVyxRQUFRLGdCQUFnQixJQUFJLEtBQUssRUFBRTtBQUNsRSxNQUFJLE9BQVEsUUFBTztBQUNuQixRQUFNLFNBQVMsc0JBQXNCLE1BQU0sUUFBUSxPQUFPLFFBQVEsUUFBUTtBQUMxRSxNQUFJLE9BQVEsUUFBTztBQUNuQixNQUFJLEtBQUssTUFBTTtBQUNiLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTTtBQUMvQyxRQUFJLE1BQU07QUFDUixZQUFNLFNBQVMsUUFBUSxTQUFTLFFBQVEsT0FBTyxTQUFTLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDN0UsWUFBTSxVQUFVLFFBQVEsUUFBUSxRQUFRLE1BQUssUUFBUSxHQUFHLEtBQUssS0FBSyxTQUFTLFdBQVcsR0FBRyxJQUFJLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSSxLQUFLLElBQUksT0FBTztBQUNwSSxhQUFPLEVBQUUsR0FBRyxPQUFPLElBQUksS0FBSyxLQUFLLElBQUUsSUFBRSxLQUFLLEtBQUssSUFBRSxHQUFHLEdBQUcsT0FBTyxJQUFJLEtBQUssS0FBSyxJQUFFLElBQUUsS0FBSyxLQUFLLElBQUUsRUFBRTtBQUFBLElBQ2hHO0FBQUEsRUFDRjtBQUNBLFNBQU8sUUFBUSxTQUFTLFFBQVEsT0FBTyxTQUFTLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDdkU7QUFFQSxTQUFTLGVBQWUsVUFBd0IsTUFBWSxNQUF5QjtBQUNuRixTQUFPLFNBQVMsVUFBUyxJQUFJLEVBQUUsS0FBSyxDQUFDLFNBQVMsS0FBSyxTQUFTLFFBQVEsYUFBYSxVQUFTLE1BQUssSUFBSSxDQUFDO0FBQ3RHO0FBRUEsU0FBUyxtQkFBbUIsS0FBWSxPQUFjLEtBQWEsUUFBZ0I7QUFDakYsUUFBTSxRQUFRLE9BQU8sS0FBSyxJQUFJLE1BQU0sR0FBRyxJQUFJO0FBQzNDLE1BQUksS0FBSztBQUNULE1BQUksY0FBYyxxQkFBcUIsS0FBSztBQUM1QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUNkLE1BQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsTUFBTSxNQUFNLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN2RixNQUFJLEtBQUs7QUFDVCxNQUFJLE9BQU87QUFDWCxNQUFJLGNBQWM7QUFDbEIsV0FBUyxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUN6QyxVQUFNLFFBQVEsTUFBTSxNQUFNLFFBQVE7QUFDbEMsVUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLFNBQVM7QUFDaEQsVUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssU0FBUztBQUNyRCxRQUFJLFVBQVU7QUFDZCxRQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDbkIsUUFBSSxpQkFBaUIsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQ2hELFFBQUksaUJBQWlCLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztBQUMvQyxRQUFJLE9BQU87QUFBQSxFQUNiO0FBQ0EsTUFBSSxRQUFRO0FBQ2Q7QUFFQSxTQUFTLFVBQVUsU0FBa0IsT0FBb0IsTUFBYTtBQUNwRSxhQUFXLFFBQVEsT0FBTztBQUN4QixRQUFJLEtBQUssYUFBYSxLQUFLLE9BQVE7QUFDbkMsUUFBRyxPQUFPLEtBQUssTUFBTSxXQUFTLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFDbEQsVUFBTSxXQUFTLFFBQVEsS0FBSyxPQUFPLGFBQWEsRUFBQyxHQUFHLE1BQUssR0FBRyxjQUFjLFNBQVEsSUFBSSxFQUFDLEdBQUUsS0FBSyxJQUFJLElBQUk7QUFDdEcsVUFBTSxRQUFRLGNBQWMsU0FBUyxRQUFRO0FBQzdDLFFBQUcsS0FBSyxPQUFNLEtBQUcsaUJBQWlCLElBQUk7QUFDdEMsUUFBSSxDQUFDLFdBQVcsU0FBUyxPQUFPLEVBQUUsRUFBRztBQUNyQyxrQkFBYyxRQUFRLEtBQUssTUFBTSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQUEsRUFDNUQ7QUFDRjtBQUdBLFNBQVMsUUFBUSxTQUFrQixPQUFjO0FBQy9DLFNBQU8sUUFBUSxTQUFTLGFBQWEsV0FBVyxRQUFRLFVBQVUsUUFBUSxRQUFRLEtBQUssQ0FBQyxJQUFJLFNBQVMsT0FBTyxRQUFRLFFBQVE7QUFDOUg7QUFFQSxTQUFTLDJCQUEyQixTQUFpQjtBQUNuRCxhQUFVLFFBQVEsUUFBUSxVQUFVLE1BQU0sRUFBQyxHQUFFLFFBQVEsT0FBTyxHQUFFLEdBQUUsUUFBUSxPQUFPLEdBQUUsT0FBTSxRQUFRLE9BQU0sUUFBTyxRQUFRLE9BQU0sQ0FBQyxFQUFFLEtBQUcsQ0FBQyxLQUFLLEtBQUsseUJBQXdCLFNBQVEsSUFBSTtBQUMvSyxhQUFVLFlBQVksUUFBUSxTQUFTLFdBQVc7QUFDaEQsVUFBTSxXQUFTLFFBQVEsWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNsRCxTQUFJLFlBQVksUUFBUSxjQUFZLFNBQVMsT0FBTyxXQUFXLFNBQVEsY0FBYyxTQUFRLFFBQVEsR0FBRSxTQUFTLFNBQU8sRUFBRTtBQUN2SCw2QkFBdUIsU0FBUSxVQUFTLFFBQVEsU0FBUSxTQUFTLEtBQUssR0FBRSxRQUFRO0FBQUEsRUFDcEY7QUFDQSxhQUFVLFFBQVEsQ0FBQyxHQUFHLFFBQVEsU0FBUyxnQkFBZSxHQUFJLFFBQVEsU0FBUyxTQUFPLENBQUMsQ0FBRSxHQUFHO0FBQ3RGLFVBQU0sV0FBUyxRQUFRLG1CQUFpQixLQUFLO0FBQzdDLFNBQUksWUFBWSxRQUFRLGNBQVksS0FBSyxPQUFPLFdBQVcsU0FBUSxjQUFjLFNBQVEsSUFBSSxHQUFFLEtBQUssU0FBTyxFQUFFO0FBQzNHLDZCQUF1QixTQUFRLE1BQUssV0FBVSxRQUFRO0FBQUEsRUFDMUQ7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLFNBQWdCLE1BQVc7QUFDMUQsUUFBTSxXQUFTLFFBQVEsWUFBWSxJQUFJLEtBQUssRUFBRTtBQUM5QyxNQUFHLEtBQUssTUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFNLENBQUMsWUFBWSxRQUFRLGNBQVksS0FBSyxHQUFJO0FBQy9FLFFBQU0sRUFBQyxJQUFHLElBQUUsU0FBUSxLQUFHLGNBQWMsU0FBUSxJQUFJLEdBQUUsVUFBUSxZQUFZLElBQUk7QUFDM0UsUUFBTSxTQUFPLEtBQUssUUFBUSxRQUFRLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTSxHQUFFLFNBQU8sc0JBQXNCLE1BQUssUUFBUSxPQUFNLFFBQVEsUUFBUTtBQUM5SCxRQUFNLFFBQU0sZUFBZSxLQUFLLE1BQU0sS0FBRyxRQUFRLFVBQVUsQ0FBQyxLQUFLLFVBQVUsTUFBRztBQUM5RSxRQUFNLFNBQU8sU0FBTyxPQUFPLFNBQU8sS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFFLFNBQU8saUJBQWlCLE1BQU0sSUFBRTtBQUM3RixRQUFNLFFBQU0sY0FBYyxTQUFRLEVBQUMsR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLElBQUUsT0FBTSxDQUFDO0FBQ3hELE1BQUcsQ0FBQyxXQUFXLFNBQVEsT0FBTSxLQUFLLElBQUksSUFBRyxLQUFLLFNBQU8sQ0FBQyxDQUFDLEVBQUU7QUFDekQsTUFBSSxLQUFLO0FBQUUsTUFBSSxjQUFZLFFBQVEsU0FBUSxLQUFLLEtBQUs7QUFBRSxNQUFJLFlBQVUsV0FBUyxJQUFFO0FBQUUsTUFBSSxVQUFVO0FBQ2hHLE1BQUcsU0FBUztBQUNWLFVBQU0sVUFBUSxRQUFRLFFBQVEsUUFBUSxNQUFLLFFBQVEsR0FBRyxLQUFHLEtBQUssU0FBUyxXQUFTLEtBQUssVUFBUTtBQUM3RixVQUFNLE9BQUssRUFBQyxHQUFHLE1BQUssR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLEdBQUUsU0FBUSxFQUFDLFNBQVEsT0FBTSxHQUFFLE1BQUssR0FBRSxTQUFRLEVBQUMsRUFBQztBQUM1RSxZQUFRLEtBQUssUUFBUSxDQUFDLFFBQU8sVUFBUTtBQUFDLFlBQU0sSUFBRSxjQUFjLFNBQVEsYUFBYSxNQUFLLE1BQU0sQ0FBQztBQUFFLFVBQUcsVUFBUSxFQUFFLEtBQUksT0FBTyxFQUFFLEdBQUUsRUFBRSxDQUFDO0FBQUEsVUFBTyxLQUFJLE9BQU8sRUFBRSxHQUFFLEVBQUUsQ0FBQztBQUFBLElBQUUsQ0FBQztBQUFFLFFBQUksVUFBVTtBQUFBLEVBQzVLLE9BQU07QUFHSixVQUFNLGFBQVcsVUFBVSxTQUFPLEtBQUcsUUFBTSxHQUFFLE9BQUssTUFBTSxJQUFFLGNBQVksZUFBZSxLQUFLLElBQUksR0FBRyxLQUFHLE1BQUk7QUFDeEcsVUFBTSxVQUFRLEtBQUssY0FBWSxLQUFLLFVBQVE7QUFBRSxRQUFJLFFBQVEsTUFBTSxHQUFFLE1BQUssUUFBTyxTQUFPLE1BQUksR0FBRSxHQUFFLEtBQUssS0FBRyxDQUFDO0FBQUEsRUFDeEc7QUFDQSxNQUFJLE9BQU87QUFBRSxNQUFJLFFBQVE7QUFDM0I7QUFFQSxTQUFTLHVCQUF1QixTQUFnQixNQUF1QyxPQUFhLFVBQWlCO0FBQ25ILFFBQU0sRUFBQyxJQUFHLElBQUUsU0FBUSxTQUFPLGdCQUFnQixRQUFRLFVBQVMsTUFBSyxLQUFLLE1BQU0sR0FBRSxRQUFNLGNBQWMsU0FBUSxJQUFJO0FBQzlHLE1BQUksS0FBSztBQUFFLE1BQUksY0FBWTtBQUFNLE1BQUksWUFBVSxXQUFTLE1BQUk7QUFDNUQsTUFBRyxRQUFPO0FBQ1IsVUFBTSxJQUFFLE9BQU8sT0FBSyxPQUFPLE9BQUssUUFBUSxPQUFPLEdBQUUsSUFBRSxPQUFPLE1BQUksT0FBTyxPQUFLLFFBQVEsT0FBTztBQUN6RixVQUFNLEtBQUcsT0FBTyxRQUFNLE9BQU8sT0FBSyxLQUFHLE9BQU8sTUFBSyxLQUFHLE9BQU8sU0FBTyxPQUFPLE1BQUksS0FBRyxPQUFPO0FBQ3ZGLFFBQUksV0FBVyxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsR0FBRSxJQUFFLENBQUM7QUFDOUIsUUFBRyxVQUFTO0FBQUMsVUFBSSxjQUFZO0FBQUksVUFBSSxZQUFVO0FBQU0sVUFBSSxTQUFTLElBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsQ0FBQztBQUFBLElBQUU7QUFBQSxFQUNyRixPQUFPO0FBQUMsUUFBSSxVQUFVO0FBQUUsUUFBSSxRQUFRLE1BQU0sR0FBRSxNQUFNLEdBQUUsS0FBSyxTQUFPLElBQUcsS0FBSyxTQUFPLEtBQUcsTUFBSSxHQUFFLEdBQUUsS0FBSyxLQUFHLENBQUM7QUFBRSxRQUFJLE9BQU87QUFBQSxFQUFFO0FBQ2xILE1BQUksUUFBUTtBQUNkO0FBRUEsU0FBUyxnQkFBZ0IsS0FBWSxHQUFXLEdBQVc7QUFDekQsTUFBSSxLQUFLO0FBQ1QsTUFBSSxjQUFjO0FBQ2xCLE1BQUksWUFBWTtBQUNoQixNQUFJLFlBQVk7QUFDaEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDeEIsTUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDeEIsTUFBSSxPQUFPLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDekIsTUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDeEIsTUFBSSxVQUFVO0FBQ2QsTUFBSSxLQUFLO0FBQ1QsTUFBSSxPQUFPO0FBQ1gsTUFBSSxRQUFRO0FBQ2Q7QUFFQSxTQUFTLGNBQWMsS0FBWSxNQUFpQixPQUFjLE1BQWMsVUFBbUI7QUFDakcsa0JBQWdCLEtBQUssS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFLLEtBQUssVUFBVTtBQUNqRTtBQUVBLFNBQVMsT0FBTyxLQUFZLEdBQVcsR0FBVyxJQUFZLE9BQWUsUUFBUSxJQUFJO0FBQ3ZGLFFBQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQzlELE1BQUksWUFBWTtBQUNoQixNQUFJLFNBQVMsSUFBSSxRQUFRLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLENBQUM7QUFDbkQsTUFBSSxZQUFZLGVBQWUsSUFBSSxLQUFLO0FBQ3hDLE1BQUksU0FBUyxJQUFJLFFBQVEsR0FBRyxHQUFHLFFBQVEsT0FBTyxDQUFDO0FBQ2pEO0FBRUEsU0FBUyxhQUFhLEtBQVksR0FBVyxHQUFXLE9BQWU7QUFDckUsTUFBSSxZQUFZO0FBQ2hCLE1BQUksU0FBUyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7QUFDN0IsTUFBSSxZQUFZO0FBQ2hCLE1BQUksU0FBUyxJQUFJLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDakU7QUFFQSxTQUFTLHFCQUFxQixTQUFrQixHQUFXLEdBQVcsV0FBbUIsVUFBNkIsYUFBcUI7QUFDekksUUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixRQUFNLFFBQVEsVUFBVSxRQUFRLEVBQUU7QUFDbEMsZUFBYSxLQUFLLEdBQUcsR0FBRyxJQUFJLFlBQVksS0FBSztBQUM3QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxPQUFPO0FBQ1gsUUFBTSxZQUFZLHVCQUF1QixXQUFXO0FBQ3BELE1BQUksU0FBUyxHQUFHLFFBQVEsT0FBTyxTQUFTLFFBQVEsQ0FBQyxHQUFHLFlBQVksSUFBSSxTQUFTLEtBQUssRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDeEc7QUFJQSxNQUFNLFlBQVk7QUFDbEIsTUFBTSxnQkFBZ0I7QUFFdEIsU0FBUyxrQkFBa0IsVUFBd0IsUUFBbUMsTUFBOEM7QUFDbEksUUFBTSxNQUFNLE9BQUssS0FBSyxJQUFJLE9BQU8sRUFBRSxJQUFFLFNBQVMsUUFBUSxLQUFLLENBQUMsV0FBVyxPQUFPLFNBQVMsU0FBUyxPQUFPLFdBQVcsT0FBTyxFQUFFO0FBQzNILE1BQUksQ0FBQyxJQUFLLFFBQU8sRUFBRSxHQUFHLEdBQUcsR0FBRyxFQUFFO0FBQzlCLFFBQU0sU0FBUyxLQUFLLElBQUksZUFBZ0IsYUFBYSxJQUFJLFVBQVUsS0FBTSxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssQ0FBQztBQUNsRyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxZQUFZLElBQUksUUFBUSxDQUFDO0FBQ2xFLFFBQU0sUUFBUSxLQUFLLEtBQUssSUFBRSxRQUFRLEtBQUssS0FBSyxDQUFDLElBQUksU0FBUyxPQUFPO0FBQ2pFLFNBQU8sRUFBRSxHQUFHLE9BQU8sR0FBRyxDQUFDLFFBQVEsS0FBSztBQUN0QztBQUVBLFNBQVMsY0FBYyxTQUFrQixPQUFxQjtBQUM1RCxTQUFPLEVBQUUsR0FBRyxNQUFNLElBQUksUUFBUSxPQUFPLEdBQUcsR0FBRyxNQUFNLElBQUksUUFBUSxPQUFPLEVBQUU7QUFDeEU7QUFFQSxTQUFTLFdBQVcsU0FBa0IsT0FBYyxLQUFhO0FBQy9ELFNBQU8sTUFBTSxLQUFLLENBQUMsT0FBTyxNQUFNLEtBQUssQ0FBQyxPQUFPLE1BQU0sS0FBSyxRQUFRLFFBQVEsT0FBTyxNQUFNLEtBQUssUUFBUSxTQUFTO0FBQzdHOyIsIm5hbWVzIjpbXX0=