export const GROVE_UNITS = {
  footman: {
    name: { en: "Footman", zh: "步兵" },
    description: { en: "Front-line melee soldier for early fights and body-blocking fragile units.", zh: "前排近战士兵，用于早期交战并保护脆弱单位。" },
    command: { icon: "△", hotkey: "f" },
    glyph: { silhouette: "shield-triangle", marks: ["shieldBar", "shortSword", "scar"] },
    art: { tier: "basic", bearing: "foot", faction: "grove" }
  },
  archer: {
    name: { en: "Archer", zh: "弓箭手" },
    description: { en: "A steady ranged firing line behind melee protection. Moving too far forces a fresh aim.", zh: "远程阵线单位，适合在近战保护下持续射击；大幅移动后需要重新瞄准。" },
    command: { icon: "⋉", hotkey: "a" },
    glyph: { silhouette: "bow-crest", marks: ["bow", "arrow", "satchel"] },
    art: { tier: "basic", bearing: "foot", faction: "grove" }
  },
  horseArcher: {
    name: { en: "Horse Archer", zh: "骑射手" },
    description: { en: "Fast mounted skirmisher. Can keep aim while moving farther between shots, trading damage per gold for mobility.", zh: "高速骑射单位，可在更大的位移范围内保留瞄准；用较低的攻价比换取风筝和机动优势。" },
    command: { icon: "⋉", hotkey: "h" },
    glyph: { silhouette: "bow-crest", marks: ["bow", "arrow", "reins"] },
    art: { tier: "advanced", bearing: "mounted", faction: "grove" }
  },
  raider: {
    name: { en: "Raider", zh: "掠袭者" },
    description: { en: "Fast melee harasser for chasing workers and punishing isolated targets.", zh: "高速近战骚扰单位，用于追击农民并惩罚落单目标。" },
    command: { icon: "◇", hotkey: "r" },
    glyph: { silhouette: "raider-kite", marks: ["reins", "spur", "shortSword"] },
    art: { tier: "basic", bearing: "mounted", faction: "grove" }
  },
  lancer: {
    name: { en: "Lancer", zh: "长枪兵" },
    description: { en: "Reach melee fighter with a slightly longer attack range than ordinary infantry.", zh: "长柄近战单位，攻击距离比普通步兵稍长。" },
    command: { icon: "↗", hotkey: "l" },
    glyph: { silhouette: "lancer-pennant", marks: ["longSpear", "flag", "shieldBar"] },
    art: { tier: "basic", bearing: "foot", faction: "grove" }
  },
  knight: {
    name: { en: "Knight", zh: "骑士" },
    description: { en: "Heavy cavalry for decisive fights and base pressure.", zh: "重骑兵，用于决定性会战和基地压制。" },
    command: { icon: "♜", hotkey: "k" },
    glyph: { silhouette: "knight-helm", marks: ["visor", "towerShield", "shortSword"] },
    art: { tier: "elite", bearing: "mounted", faction: "grove" }
  },
  witch: {
    name: { en: "Witch", zh: "女巫" },
    description: { en: "Debuff caster that weakens enemy damage through curse; also damages summoned targets.", zh: "减益施法者，通过诅咒削弱敌方伤害；还能直接伤害被诅咒的召唤物。" },
    command: { icon: "☾", hotkey: "c" },
    glyph: { silhouette: "witch-crescent", marks: ["crescent", "curseSlash", "spark"] },
    art: { tier: "advanced", bearing: "foot", faction: "grove" }
  },
  golem: {
    name: { en: "Golem", zh: "魔像" },
    description: { en: "Slow heavy siege body with high health and strong melee damage.", zh: "缓慢的重型攻坚单位，生命值高，近战伤害强。" },
    command: { icon: "▣", hotkey: "g" },
    glyph: { silhouette: "golem-block", marks: ["rune", "blockSeams", "scar"] },
    art: { tier: "elite", bearing: "construct", faction: "grove" }
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaXRzLWdyb3ZlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgVHJhaW5hYmxlVW5pdEtpbmQgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IFRyYWluZWRVbml0Q2FyZCB9IGZyb20gXCIuL2NhcmRzXCI7XG5cbmV4cG9ydCBjb25zdCBHUk9WRV9VTklUUyA9IHtcbiAgZm9vdG1hbjoge1xuICAgIG5hbWU6IHsgZW46IFwiRm9vdG1hblwiLCB6aDogXCLmraXlhbVcIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIkZyb250LWxpbmUgbWVsZWUgc29sZGllciBmb3IgZWFybHkgZmlnaHRzIGFuZCBib2R5LWJsb2NraW5nIGZyYWdpbGUgdW5pdHMuXCIsIHpoOiBcIuWJjeaOkui/keaImOWjq+WFte+8jOeUqOS6juaXqeacn+S6pOaImOW5tuS/neaKpOiEhuW8seWNleS9jeOAglwiIH0sXG4gICAgY29tbWFuZDogeyBpY29uOiBcIuKWs1wiLCBob3RrZXk6IFwiZlwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJzaGllbGQtdHJpYW5nbGVcIiwgbWFya3M6IFtcInNoaWVsZEJhclwiLCBcInNob3J0U3dvcmRcIiwgXCJzY2FyXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYmFzaWNcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwiZ3JvdmVcIiB9LFxuICB9LFxuICBhcmNoZXI6IHtcbiAgICBuYW1lOiB7IGVuOiBcIkFyY2hlclwiLCB6aDogXCLlvJPnrq3miYtcIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIkEgc3RlYWR5IHJhbmdlZCBmaXJpbmcgbGluZSBiZWhpbmQgbWVsZWUgcHJvdGVjdGlvbi4gTW92aW5nIHRvbyBmYXIgZm9yY2VzIGEgZnJlc2ggYWltLlwiLCB6aDogXCLov5znqIvpmLXnur/ljZXkvY3vvIzpgILlkIjlnKjov5HmiJjkv53miqTkuIvmjIHnu63lsITlh7vvvJvlpKfluYXnp7vliqjlkI7pnIDopoHph43mlrDnnoTlh4bjgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLii4lcIiwgaG90a2V5OiBcImFcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwiYm93LWNyZXN0XCIsIG1hcmtzOiBbXCJib3dcIiwgXCJhcnJvd1wiLCBcInNhdGNoZWxcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJiYXNpY1wiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJncm92ZVwiIH0sXG4gIH0sXG4gIGhvcnNlQXJjaGVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJIb3JzZSBBcmNoZXJcIiwgemg6IFwi6aqR5bCE5omLXCIgfSxcbiAgICBkZXNjcmlwdGlvbjogeyBlbjogXCJGYXN0IG1vdW50ZWQgc2tpcm1pc2hlci4gQ2FuIGtlZXAgYWltIHdoaWxlIG1vdmluZyBmYXJ0aGVyIGJldHdlZW4gc2hvdHMsIHRyYWRpbmcgZGFtYWdlIHBlciBnb2xkIGZvciBtb2JpbGl0eS5cIiwgemg6IFwi6auY6YCf6aqR5bCE5Y2V5L2N77yM5Y+v5Zyo5pu05aSn55qE5L2N56e76IyD5Zu05YaF5L+d55WZ556E5YeG77yb55So6L6D5L2O55qE5pS75Lu35q+U5o2i5Y+W6aOO562d5ZKM5py65Yqo5LyY5Yq/44CCXCIgfSxcbiAgICBjb21tYW5kOiB7IGljb246IFwi4ouJXCIsIGhvdGtleTogXCJoXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcImJvdy1jcmVzdFwiLCBtYXJrczogW1wiYm93XCIsIFwiYXJyb3dcIiwgXCJyZWluc1wiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImFkdmFuY2VkXCIsIGJlYXJpbmc6IFwibW91bnRlZFwiLCBmYWN0aW9uOiBcImdyb3ZlXCIgfSxcbiAgfSxcbiAgcmFpZGVyOiB7XG4gICAgbmFtZTogeyBlbjogXCJSYWlkZXJcIiwgemg6IFwi5o6g6KKt6ICFXCIgfSxcbiAgICBkZXNjcmlwdGlvbjogeyBlbjogXCJGYXN0IG1lbGVlIGhhcmFzc2VyIGZvciBjaGFzaW5nIHdvcmtlcnMgYW5kIHB1bmlzaGluZyBpc29sYXRlZCB0YXJnZXRzLlwiLCB6aDogXCLpq5jpgJ/ov5HmiJjpqprmibDljZXkvY3vvIznlKjkuo7ov73lh7vlhpzmsJHlubbmg6nnvZrokL3ljZXnm67moIfjgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLil4dcIiwgaG90a2V5OiBcInJcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwicmFpZGVyLWtpdGVcIiwgbWFya3M6IFtcInJlaW5zXCIsIFwic3B1clwiLCBcInNob3J0U3dvcmRcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJiYXNpY1wiLCBiZWFyaW5nOiBcIm1vdW50ZWRcIiwgZmFjdGlvbjogXCJncm92ZVwiIH0sXG4gIH0sXG4gIGxhbmNlcjoge1xuICAgIG5hbWU6IHsgZW46IFwiTGFuY2VyXCIsIHpoOiBcIumVv+aequWFtVwiIH0sXG4gICAgZGVzY3JpcHRpb246IHsgZW46IFwiUmVhY2ggbWVsZWUgZmlnaHRlciB3aXRoIGEgc2xpZ2h0bHkgbG9uZ2VyIGF0dGFjayByYW5nZSB0aGFuIG9yZGluYXJ5IGluZmFudHJ5LlwiLCB6aDogXCLplb/mn4Tov5HmiJjljZXkvY3vvIzmlLvlh7vot53nprvmr5Tmma7pgJrmraXlhbXnqI3plb/jgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLihpdcIiwgaG90a2V5OiBcImxcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwibGFuY2VyLXBlbm5hbnRcIiwgbWFya3M6IFtcImxvbmdTcGVhclwiLCBcImZsYWdcIiwgXCJzaGllbGRCYXJcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJiYXNpY1wiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJncm92ZVwiIH0sXG4gIH0sXG4gIGtuaWdodDoge1xuICAgIG5hbWU6IHsgZW46IFwiS25pZ2h0XCIsIHpoOiBcIumqkeWjq1wiIH0sXG4gICAgZGVzY3JpcHRpb246IHsgZW46IFwiSGVhdnkgY2F2YWxyeSBmb3IgZGVjaXNpdmUgZmlnaHRzIGFuZCBiYXNlIHByZXNzdXJlLlwiLCB6aDogXCLph43pqpHlhbXvvIznlKjkuo7lhrPlrprmgKfkvJrmiJjlkozln7rlnLDljovliLbjgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLimZxcIiwgaG90a2V5OiBcImtcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwia25pZ2h0LWhlbG1cIiwgbWFya3M6IFtcInZpc29yXCIsIFwidG93ZXJTaGllbGRcIiwgXCJzaG9ydFN3b3JkXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiZWxpdGVcIiwgYmVhcmluZzogXCJtb3VudGVkXCIsIGZhY3Rpb246IFwiZ3JvdmVcIiB9LFxuICB9LFxuICB3aXRjaDoge1xuICAgIG5hbWU6IHsgZW46IFwiV2l0Y2hcIiwgemg6IFwi5aWz5berXCIgfSxcbiAgICBkZXNjcmlwdGlvbjogeyBlbjogXCJEZWJ1ZmYgY2FzdGVyIHRoYXQgd2Vha2VucyBlbmVteSBkYW1hZ2UgdGhyb3VnaCBjdXJzZTsgYWxzbyBkYW1hZ2VzIHN1bW1vbmVkIHRhcmdldHMuXCIsIHpoOiBcIuWHj+ebiuaWveazleiAhe+8jOmAmui/h+ivheWSkuWJiuW8seaVjOaWueS8pOWus++8m+i/mOiDveebtOaOpeS8pOWus+iiq+ivheWSkueahOWPrOWUpOeJqeOAglwiIH0sXG4gICAgY29tbWFuZDogeyBpY29uOiBcIuKYvlwiLCBob3RrZXk6IFwiY1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aXRjaC1jcmVzY2VudFwiLCBtYXJrczogW1wiY3Jlc2NlbnRcIiwgXCJjdXJzZVNsYXNoXCIsIFwic3BhcmtcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJhZHZhbmNlZFwiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJncm92ZVwiIH0sXG4gIH0sXG4gIGdvbGVtOiB7XG4gICAgbmFtZTogeyBlbjogXCJHb2xlbVwiLCB6aDogXCLprZTlg49cIiB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IGVuOiBcIlNsb3cgaGVhdnkgc2llZ2UgYm9keSB3aXRoIGhpZ2ggaGVhbHRoIGFuZCBzdHJvbmcgbWVsZWUgZGFtYWdlLlwiLCB6aDogXCLnvJPmhaLnmoTph43lnovmlLvlnZrljZXkvY3vvIznlJ/lkb3lgLzpq5jvvIzov5HmiJjkvKTlrrPlvLrjgIJcIiB9LFxuICAgIGNvbW1hbmQ6IHsgaWNvbjogXCLilqNcIiwgaG90a2V5OiBcImdcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwiZ29sZW0tYmxvY2tcIiwgbWFya3M6IFtcInJ1bmVcIiwgXCJibG9ja1NlYW1zXCIsIFwic2NhclwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiY29uc3RydWN0XCIsIGZhY3Rpb246IFwiZ3JvdmVcIiB9LFxuICB9LFxufSBzYXRpc2ZpZXMgUGFydGlhbDxSZWNvcmQ8VHJhaW5hYmxlVW5pdEtpbmQsIFRyYWluZWRVbml0Q2FyZD4+O1xuIl0sIm1hcHBpbmdzIjoiQUFHTyxhQUFNLGNBQWM7QUFBQSxFQUN6QixTQUFTO0FBQUEsSUFDUCxNQUFNLEVBQUUsSUFBSSxXQUFXLElBQUksS0FBSztBQUFBLElBQ2hDLGFBQWEsRUFBRSxJQUFJLDhFQUE4RSxJQUFJLHdCQUF3QjtBQUFBLElBQzdILFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksbUJBQW1CLE9BQU8sQ0FBQyxhQUFhLGNBQWMsTUFBTSxFQUFFO0FBQUEsSUFDbkYsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLFFBQVE7QUFBQSxJQUNOLE1BQU0sRUFBRSxJQUFJLFVBQVUsSUFBSSxNQUFNO0FBQUEsSUFDaEMsYUFBYSxFQUFFLElBQUksMkZBQTJGLElBQUksbUNBQW1DO0FBQUEsSUFDckosU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUNsQyxPQUFPLEVBQUUsWUFBWSxhQUFhLE9BQU8sQ0FBQyxPQUFPLFNBQVMsU0FBUyxFQUFFO0FBQUEsSUFDckUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLGFBQWE7QUFBQSxJQUNYLE1BQU0sRUFBRSxJQUFJLGdCQUFnQixJQUFJLE1BQU07QUFBQSxJQUN0QyxhQUFhLEVBQUUsSUFBSSxtSEFBbUgsSUFBSSwwQ0FBMEM7QUFBQSxJQUNwTCxTQUFTLEVBQUUsTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUFBLElBQ2xDLE9BQU8sRUFBRSxZQUFZLGFBQWEsT0FBTyxDQUFDLE9BQU8sU0FBUyxPQUFPLEVBQUU7QUFBQSxJQUNuRSxLQUFLLEVBQUUsTUFBTSxZQUFZLFNBQVMsV0FBVyxTQUFTLFFBQVE7QUFBQSxFQUNoRTtBQUFBLEVBQ0EsUUFBUTtBQUFBLElBQ04sTUFBTSxFQUFFLElBQUksVUFBVSxJQUFJLE1BQU07QUFBQSxJQUNoQyxhQUFhLEVBQUUsSUFBSSwyRUFBMkUsSUFBSSwwQkFBMEI7QUFBQSxJQUM1SCxTQUFTLEVBQUUsTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUFBLElBQ2xDLE9BQU8sRUFBRSxZQUFZLGVBQWUsT0FBTyxDQUFDLFNBQVMsUUFBUSxZQUFZLEVBQUU7QUFBQSxJQUMzRSxLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsV0FBVyxTQUFTLFFBQVE7QUFBQSxFQUM3RDtBQUFBLEVBQ0EsUUFBUTtBQUFBLElBQ04sTUFBTSxFQUFFLElBQUksVUFBVSxJQUFJLE1BQU07QUFBQSxJQUNoQyxhQUFhLEVBQUUsSUFBSSxtRkFBbUYsSUFBSSxzQkFBc0I7QUFBQSxJQUNoSSxTQUFTLEVBQUUsTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUFBLElBQ2xDLE9BQU8sRUFBRSxZQUFZLGtCQUFrQixPQUFPLENBQUMsYUFBYSxRQUFRLFdBQVcsRUFBRTtBQUFBLElBQ2pGLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUFBLEVBQzFEO0FBQUEsRUFDQSxRQUFRO0FBQUEsSUFDTixNQUFNLEVBQUUsSUFBSSxVQUFVLElBQUksS0FBSztBQUFBLElBQy9CLGFBQWEsRUFBRSxJQUFJLHdEQUF3RCxJQUFJLG9CQUFvQjtBQUFBLElBQ25HLFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksZUFBZSxPQUFPLENBQUMsU0FBUyxlQUFlLFlBQVksRUFBRTtBQUFBLElBQ2xGLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxXQUFXLFNBQVMsUUFBUTtBQUFBLEVBQzdEO0FBQUEsRUFDQSxPQUFPO0FBQUEsSUFDTCxNQUFNLEVBQUUsSUFBSSxTQUFTLElBQUksS0FBSztBQUFBLElBQzlCLGFBQWEsRUFBRSxJQUFJLHlGQUF5RixJQUFJLGtDQUFrQztBQUFBLElBQ2xKLFNBQVMsRUFBRSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsSUFDbEMsT0FBTyxFQUFFLFlBQVksa0JBQWtCLE9BQU8sQ0FBQyxZQUFZLGNBQWMsT0FBTyxFQUFFO0FBQUEsSUFDbEYsS0FBSyxFQUFFLE1BQU0sWUFBWSxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQUEsRUFDN0Q7QUFBQSxFQUNBLE9BQU87QUFBQSxJQUNMLE1BQU0sRUFBRSxJQUFJLFNBQVMsSUFBSSxLQUFLO0FBQUEsSUFDOUIsYUFBYSxFQUFFLElBQUksbUVBQW1FLElBQUksd0JBQXdCO0FBQUEsSUFDbEgsU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUNsQyxPQUFPLEVBQUUsWUFBWSxlQUFlLE9BQU8sQ0FBQyxRQUFRLGNBQWMsTUFBTSxFQUFFO0FBQUEsSUFDMUUsS0FBSyxFQUFFLE1BQU0sU0FBUyxTQUFTLGFBQWEsU0FBUyxRQUFRO0FBQUEsRUFDL0Q7QUFDRjsiLCJuYW1lcyI6W119