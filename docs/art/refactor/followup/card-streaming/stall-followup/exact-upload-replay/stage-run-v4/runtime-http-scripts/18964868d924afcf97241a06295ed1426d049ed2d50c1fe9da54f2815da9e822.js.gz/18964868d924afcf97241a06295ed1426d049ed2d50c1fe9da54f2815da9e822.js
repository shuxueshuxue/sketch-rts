import { bloodSurfaceResolver } from "/@fs/tmp/sketch-queue-source-42bd/src/client/combat-surfaces.ts";
import { PresentationViewIndex } from "/@fs/tmp/sketch-queue-source-42bd/src/client/presentation-view.ts";
import { deckRemainsMatrix } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/deck-remains.ts";
import { deckRemainsByShip, deckRemainsPose, remainsOpacity, remainsVariant } from "/@fs/tmp/sketch-queue-source-42bd/src/client/deck-remains.ts";
import { drawAtlasCorpse } from "/@fs/tmp/sketch-queue-source-42bd/src/client/atlas-art.ts";
import { corpseAppearanceKey } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/corpses.ts";
import { projectActionFrame, actionPaintSize } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/action-direction.ts";
import { unitPaintKey } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/paint-identity.ts";
import { CombatInk } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/combat-ink.ts";
import * as THREE from "/.vite-cache/deps/three.js?v=a06372f0";
import { worldModels, matchModelKeys, snapshotModelKeys } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/model-library.ts";
import { activateModelPortraits } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/model-portraits.ts";
import { ActorBatches } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/batches.ts";
import { PaintedCardBatches, DEFAULT_CARD_BANKS } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/painted-card-batches.ts";
import { cardBaseMip } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/card-mip-residency.ts";
import { SelectionMarkers } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/selection-markers.ts";
import { SailPoseTracker, shipRigModel } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/sail-rig.ts";
import { CrewFacingTracker, uprightCrewRotation } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/crew-pose.ts";
import { configureWorldCamera, screenOnPlane } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/projection.ts";
import { flightPose } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/flight-pose.ts";
import { paintedHit } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/painted-hit.ts";
import { WaterSurface } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world3d/water.ts";
import { creatureShadow } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/painted-creatures.ts";
import { spellOrbPalette } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/effect-presentation.ts";
import { paintFigure } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/painted-units.ts";
import { appearanceFor, appearanceKey, corpseAppearanceFor } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/unit-appearance.ts";
import { unitGlyphScale } from "/@fs/tmp/sketch-queue-source-42bd/src/client/glyphs.ts";
import { footprintSquare } from "/@fs/tmp/sketch-queue-source-42bd/src/client/footprint-view.ts";
import { relationTo, RELATION_INK } from "/@fs/tmp/sketch-queue-source-42bd/src/client/relations.ts";
import { ownerInk, trackUnitFacing } from "/@fs/tmp/sketch-queue-source-42bd/src/client/world-renderer.ts";
import { interactionTargetId } from "/@fs/tmp/sketch-queue-source-42bd/src/client/unit-facing.ts";
import { installedWeapons, mountedWeaponPose } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-equipment.ts";
import { shipProfile, shareShipProfile, shipScale, localToWorld, SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { isInCabin } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-cabin.ts";
import { gangwaySurface } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-gangway.ts";
import { gangwayCrewVisualPose } from "/@fs/tmp/sketch-queue-source-42bd/src/client/ship-gangway-visual.ts";
import { SIM_TICKS_PER_SECOND } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
export const PHYSICAL_EFFECTS = /* @__PURE__ */ new Set(["shellFlight", "siegeBolt", "projectile", "muzzleFlash"]);
const TILT = Math.tan(SHIP_CAMERA.tilt), UP = new THREE.Vector3(0, 1, 0);
class ActorPositions extends Map {
  constructor(locate) {
    super();
    this.locate = locate;
  }
  get(id) {
    return super.get(id) ?? this.locate(id);
  }
}
export class World3DLayer {
  constructor(renderer) {
    this.renderer = renderer;
    const maxTextureBanks = Math.min(DEFAULT_CARD_BANKS, Math.max(1, (renderer?.capabilities.maxTextures ?? 16) - 4));
    this.cards = new PaintedCardBatches(this.scene, Math.min(8, renderer?.capabilities.getMaxAnisotropy() ?? 1), { maxTextureBanks });
    this.remainsCards = new PaintedCardBatches(this.scene, Math.min(8, renderer?.capabilities.getMaxAnisotropy() ?? 1), { transparent: true, depthWrite: false, alphaTest: 0.01, castShadow: false, pickable: false, renderOrder: -1, maxTextureBanks });
    this.flag.material.name = "TeamColor";
    this.magic.name = "SpellOrb";
    this.magic.material.name = "TeamColor";
    this.gangway.name = "ShipGangway";
    this.scene.add(new THREE.HemisphereLight("#ddd7c5", "#263c3a", 1.25));
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -4e-4;
    this.sun.shadow.normalBias = 0.35;
    this.scene.add(this.sun, this.sun.target);
    this.shadow.rotation.x = -Math.PI / 2;
    this.shadow.receiveShadow = true;
    this.scene.add(this.shadow);
  }
  /** Visible positions are eager; offscreen UI/effect lookups stay exact and
   * are evaluated on demand instead of projecting the whole army each RAF. */
  positions = new ActorPositions((id) => this.offscreenPosition(id));
  viewIndex = new PresentationViewIndex();
  activeIndex = this.viewIndex;
  currentFrame;
  posed = 0;
  directionVisits = 0;
  cardMipBases = [0, 0, 0, 0, 0];
  viewStats() {
    return { ...this.activeIndex.stats(), posed: this.posed, directionVisits: this.directionVisits, positions: this.positions.size, cardMipBases: [...this.cardMipBases] };
  }
  camera = new THREE.OrthographicCamera();
  scene = new THREE.Scene();
  water = new WaterSurface(this.scene);
  library = worldModels;
  batches = new ActorBatches(this.scene);
  selection = new SelectionMarkers(this.scene);
  combatInk = new CombatInk(this.scene);
  combatAnchors = /* @__PURE__ */ new Map();
  combatStats() {
    return this.combatInk.stats();
  }
  templates = /* @__PURE__ */ new Map();
  bounds = /* @__PURE__ */ new Map();
  cards;
  remainsCards;
  remainsStats() {
    return this.remainsCards.stats();
  }
  cardStats() {
    return this.cards.stats();
  }
  transforms = [];
  transformCount = 0;
  transformPosition = new THREE.Vector3();
  transformRotation = new THREE.Quaternion();
  transformScale = new THREE.Vector3();
  projectedOrigin = new THREE.Vector3();
  projectedDirection = new THREE.Vector3();
  missileRotation = new THREE.Quaternion();
  missileDirection = new THREE.Vector3();
  missileAxis = new THREE.Vector3(1, 0, 0);
  entities = /* @__PURE__ */ new Map();
  ships = /* @__PURE__ */ new Map();
  shipPoses = /* @__PURE__ */ new Map();
  gangwaySurfaces = /* @__PURE__ */ new Map();
  recoil = /* @__PURE__ */ new Map();
  indexedUnits;
  indexedBuildings;
  indexedEffects;
  indexCounts = "";
  facing = new CrewFacingTracker();
  sailMotion = new SailPoseTracker();
  rigModels = /* @__PURE__ */ new Map();
  rigPoses = /* @__PURE__ */ new Map();
  deckMotion = /* @__PURE__ */ new Map();
  snapshot;
  lastTick = -1;
  at = 0;
  frame = 0;
  viewport = "";
  view;
  disposed = false;
  contextLost = false;
  eventCanvas;
  onContextLost = (event) => {
    event.preventDefault();
    this.contextLost = true;
    this.releaseContextResources();
    this.cards.invalidateGPU();
    this.remainsCards.invalidateGPU();
  };
  onContextRestored = () => {
    this.contextLost = false;
  };
  sun = new THREE.DirectionalLight("#f1dcc0", 2.5);
  colorMipPass = { camera: this.camera, physicalWidth: 0, physicalHeight: 0 };
  shadowMipPass = { camera: this.sun.shadow.camera, physicalWidth: 0, physicalHeight: 0 };
  colorMipPasses = [this.colorMipPass];
  actorMipPasses = [this.colorMipPass, this.shadowMipPass];
  mipInput = { sourceSize: 1, tileSize: 1, foot: 0, matrix: new THREE.Matrix4(), passes: this.actorMipPasses };
  shadow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShadowMaterial({ opacity: 0.24 }));
  ball = new THREE.Mesh(new THREE.SphereGeometry(3, 8, 6), new THREE.MeshStandardMaterial({ color: "#414945", roughness: 1 }));
  bolt = new THREE.Mesh(new THREE.ConeGeometry(1.5, 24, 4).rotateZ(-Math.PI / 2).translate(-9, 0, 0), new THREE.MeshStandardMaterial({ color: "#c0b391", roughness: 1 }));
  magic = new THREE.Mesh(new THREE.SphereGeometry(3, 8, 6), new THREE.MeshBasicMaterial({ color: "#86c3dc", toneMapped: false }));
  fire = new THREE.Mesh(new THREE.SphereGeometry(4, 8, 6), new THREE.MeshBasicMaterial({ color: "#e5ad55", toneMapped: false }));
  flag = new THREE.Mesh(new THREE.PlaneGeometry(20, 13).translate(10, -6.5, 0), new THREE.MeshBasicMaterial({ color: "#88977c", side: THREE.DoubleSide, toneMapped: false }));
  flash = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 6), new THREE.MeshBasicMaterial({ color: "#ffcf74", toneMapped: false }));
  gangway = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: "#9b7550", roughness: 1 }));
  bridgeAlong = new THREE.Vector3();
  bridgeAcross = new THREE.Vector3();
  bridgeUp = new THREE.Vector3();
  /** Detach the old renderer's public dispose listeners while its context is
   * lost. Otherwise later reset/dispose attempts to delete pre-loss VAOs and
   * buffers in the restored context. Scene meshes own their resource views;
   * global decoded model templates are never traversed or disposed here. CPU
   * geometry/texture data remains available for normal restoration uploads. */
  releaseContextResources() {
    const geometries = /* @__PURE__ */ new Set(), materials = /* @__PURE__ */ new Set(), textures = /* @__PURE__ */ new Set();
    this.scene.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.dispose();
        geometries.add(object.geometry);
        for (const material of Array.isArray(object.material) ? object.material : [object.material]) materials.add(material);
        if (object.customDepthMaterial) materials.add(object.customDepthMaterial);
        if (object.customDistanceMaterial) materials.add(object.customDistanceMaterial);
      }
      if (object instanceof THREE.DirectionalLight || object instanceof THREE.PointLight || object instanceof THREE.SpotLight) {
        object.shadow.dispose();
        object.shadow.map = object.shadow.mapPass = null;
      }
    });
    for (const material of materials) {
      for (const value of Object.values(material)) if (value instanceof THREE.Texture) textures.add(value);
      if (material instanceof THREE.ShaderMaterial) for (const uniform of Object.values(material.uniforms)) {
        const values = Array.isArray(uniform.value) ? uniform.value : [uniform.value];
        for (const value of values) if (value instanceof THREE.Texture) textures.add(value);
      }
      material.dispose();
    }
    for (const geometry of geometries) geometry.dispose();
    for (const texture of textures) texture.dispose();
  }
  static create(canvas, context) {
    const renderer = new THREE.WebGLRenderer({ canvas, context, alpha: true, antialias: true });
    renderer.setClearColor(0, 0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.9;
    const layer = new World3DLayer(renderer);
    layer.eventCanvas = canvas;
    canvas.addEventListener("webglcontextlost", layer.onContextLost);
    canvas.addEventListener("webglcontextrestored", layer.onContextRestored);
    return layer;
  }
  async prepare(snapshot, phase, sites = []) {
    if (this.disposed) return;
    await this.library.prepare(phase === "match" ? matchModelKeys : [...snapshotModelKeys(snapshot), ...sites.map((kind) => `buildings/${kind}`)], phase);
    if (!this.disposed) activateModelPortraits();
  }
  template(key, name) {
    const id = `${key}:${name}`;
    let model = this.templates.get(id);
    if (!model) {
      model = this.library.component(key, name);
      if (model) this.templates.set(id, model);
    }
    return model;
  }
  reset() {
    this.lastTick = -1;
    this.snapshot = void 0;
    this.indexedUnits = this.indexedBuildings = this.indexedEffects = void 0;
    this.indexCounts = "";
    this.view = void 0;
    this.currentFrame = void 0;
    this.viewIndex.reset();
    this.activeIndex = this.viewIndex;
    this.positions.clear();
    this.combatAnchors.clear();
    this.combatInk.clear();
    this.entities = /* @__PURE__ */ new Map();
    this.ships.clear();
    this.shipPoses.clear();
    this.gangwaySurfaces.clear();
    this.recoil.clear();
    this.deckMotion.clear();
    this.facing = new CrewFacingTracker();
    this.sailMotion.reset();
    this.rigPoses.clear();
    this.transforms.length = 0;
    this.transformCount = 0;
    this.batches.dispose();
    this.cards.dispose();
    this.remainsCards.dispose();
    this.selection.clear();
    this.water.prepare(void 0);
  }
  offscreenPosition(id) {
    const frame = this.currentFrame, unit = this.activeIndex.units.get(id);
    if (!frame || !unit || unit.deck || isInCabin(unit) || shipProfile(unit)) return void 0;
    const at = frame.motion?.position(unit, frame.now) ?? unit, model = unit.variant === void 0 ? void 0 : frame.models?.(unit.variant);
    const scale = model ? Math.max(0.72, unit.radius / 18) : unitGlyphScale(unit.radius), foot = model ? 17 : creatureShadow(unit.kind)?.y ?? 17, bodyY = at.y - foot * scale;
    const result = { x: at.x, y: at.y, bodyY, topY: bodyY - 64 * scale, facing: frame.facing.releaseFacing(id) };
    this.positions.set(id, result);
    return result;
  }
  pose(x, y, height, heading = 0, scale = 1, rotation) {
    let matrix = this.transforms[this.transformCount];
    if (!matrix) {
      matrix = new THREE.Matrix4();
      this.transforms[this.transformCount] = matrix;
    }
    this.transformCount++;
    return matrix.compose(this.transformPosition.set(x, height, y), rotation ?? this.transformRotation.setFromAxisAngle(UP, -heading), this.transformScale.setScalar(scale));
  }
  residentMip(tileSize, density, matrix, foot, castsShadow = true) {
    const input = this.mipInput;
    input.sourceSize = tileSize * density;
    input.tileSize = tileSize;
    input.matrix = matrix;
    input.foot = foot;
    input.passes = castsShadow ? this.actorMipPasses : this.colorMipPasses;
    const base = cardBaseMip(input);
    this.cardMipBases[base]++;
    return base;
  }
  deckPosition(unit, now) {
    const track = this.deckMotion.get(unit.id);
    if (!track || track.shipId !== unit.deck.shipId) return unit.deck;
    const t = Math.max(0, Math.min(1, (now - track.at) * SIM_TICKS_PER_SECOND / 1e3));
    return { x: track.fromX + (track.x - track.fromX) * t, y: track.fromY + (track.y - track.fromY) * t };
  }
  draw(frame) {
    const renderer = this.renderer;
    if (this.disposed || this.contextLost || !renderer) return;
    this.frame++;
    this.transformCount = 0;
    this.view = frame.view;
    this.currentFrame = frame;
    this.posed = 0;
    this.cardMipBases.fill(0);
    const { snapshot, now } = frame;
    const zoom = frame.view.zoom ?? 1;
    const pixelRatio = Math.min(devicePixelRatio, 2), viewport = `${frame.view.width}:${frame.view.height}:${pixelRatio}`;
    if (viewport !== this.viewport) {
      renderer.setPixelRatio(pixelRatio);
      renderer.setSize(frame.view.width, frame.view.height, false);
      this.viewport = viewport;
    }
    this.colorMipPass.physicalWidth = Math.floor(frame.view.width * pixelRatio);
    this.colorMipPass.physicalHeight = Math.floor(frame.view.height * pixelRatio);
    configureWorldCamera(this.camera, frame.view);
    this.water.prepare(snapshot.map.terrain);
    this.water.update(now, frame.reducedMotion);
    const cx = frame.view.x + frame.view.width / (2 * zoom), cy = frame.view.y + frame.view.height / (2 * zoom), extent = Math.max(frame.view.width, frame.view.height) / zoom + 400;
    this.shadow.position.set(cx, -0.1, cy);
    this.shadow.scale.set(extent, extent, 1);
    this.sun.position.set(cx - 450, 650, cy + 250);
    this.sun.target.position.set(cx, 0, cy);
    const shadow = this.sun.shadow.camera;
    shadow.left = shadow.bottom = -extent / 2;
    shadow.right = shadow.top = extent / 2;
    shadow.near = 1;
    shadow.far = 3e3;
    shadow.updateProjectionMatrix();
    this.sun.updateWorldMatrix(true, false);
    this.sun.target.updateWorldMatrix(true, false);
    this.sun.shadow.updateMatrices(this.sun);
    this.shadowMipPass.physicalWidth = this.sun.shadow.mapSize.x;
    this.shadowMipPass.physicalHeight = this.sun.shadow.mapSize.y;
    frame.projectiles?.update(snapshot, frame.models, (id) => frame.facing.releaseFacing(id));
    frame.animation?.update(snapshot, now, frame.story?.unitActions);
    frame.motion?.update(snapshot, now);
    this.activeIndex = frame.viewIndex ?? this.viewIndex;
    this.activeIndex.update(snapshot, frame.motion);
    this.entities = this.activeIndex.entities;
    const indexCounts = `${snapshot.units.length}:${snapshot.buildings.length}:${snapshot.effects.length}`;
    if (snapshot !== this.snapshot || snapshot.tick !== this.lastTick || snapshot.units !== this.indexedUnits || snapshot.buildings !== this.indexedBuildings || snapshot.effects !== this.indexedEffects || indexCounts !== this.indexCounts) {
      this.ships.clear();
      this.recoil.clear();
      for (const unit of this.activeIndex.ships) this.ships.set(unit.id, unit);
      for (const effect of snapshot.effects) if (effect.type === "muzzleFlash" && effect.itemId && !this.recoil.has(effect.itemId)) this.recoil.set(effect.itemId, effect);
      this.snapshot = snapshot;
      this.indexedUnits = snapshot.units;
      this.indexedBuildings = snapshot.buildings;
      this.indexedEffects = snapshot.effects;
      this.indexCounts = indexCounts;
    }
    this.sailMotion.update({ tick: snapshot.tick, units: this.activeIndex.sailing }, now);
    trackUnitFacing(frame.facing, snapshot, this.activeIndex.entities);
    frame.combat?.update(snapshot, now, bloodSurfaceResolver(snapshot, frame.animation, frame.facing, frame.models, frame.reducedMotion), (areas) => this.activeIndex.queryBoundsUnion(areas));
    if (snapshot.tick !== this.lastTick) {
      this.facing.update({ units: this.activeIndex.crew });
      const continuous = snapshot.tick === this.lastTick + 1;
      for (const unit of this.activeIndex.crew) if (unit.deck) {
        const old = this.deckMotion.get(unit.id), start = continuous && old?.shipId === unit.deck.shipId ? this.deckPosition(unit, now) : unit.deck;
        this.deckMotion.set(unit.id, { shipId: unit.deck.shipId, x: unit.deck.x, y: unit.deck.y, fromX: start.x, fromY: start.y, at: now });
      }
      this.lastTick = snapshot.tick;
      this.at = now;
    }
    const { entities, ships } = this;
    const right = new THREE.Vector3().setFromMatrixColumn(this.camera.matrixWorld, 0), rotation = uprightCrewRotation(this.camera);
    this.projectedOrigin.set(0, 0, 0).project(this.camera);
    const projectVector = (direction) => {
      this.projectedDirection.set(direction.x, direction.height ?? 0, direction.y).project(this.camera).sub(this.projectedOrigin);
      return { x: this.projectedDirection.x * frame.view.width / 2, y: -this.projectedDirection.y * frame.view.height / 2 };
    };
    this.directionVisits = frame.animation?.observeDirections(now, (id, direction) => {
      const unit = this.activeIndex.units.get(id);
      if (!unit?.deck && !ships.has(id)) frame.facing.actionFacing(id, direction, projectVector);
    }, frame.reducedMotion) ?? 0;
    const visible = (x, y, pad = 180) => x >= frame.view.x - pad && y >= frame.view.y - pad && x <= frame.view.x + frame.view.width / zoom + pad && y <= frame.view.y + frame.view.height / zoom + pad;
    this.positions.clear();
    this.combatAnchors.clear();
    this.shipPoses.clear();
    this.gangwaySurfaces.clear();
    this.batches.begin();
    this.cards.begin();
    this.remainsCards.begin();
    this.selection.begin();
    for (const site of [...snapshot.mercenaryCamps.map((site2) => ({ ...site2, model: "camp", scale: site2.radius / 32 })), ...(snapshot.shops ?? []).map((site2) => ({ ...site2, model: "shop", scale: site2.radius / 32 })), ...(frame.story?.props ?? []).filter((site2) => ["statue", "well", "beacon", "citadel"].includes(site2.kind)).map((site2) => ({ ...site2, id: `prop:${site2.id}`, model: site2.kind }))]) {
      const model = this.template(`buildings/${site.model}`, "Building");
      if (!model) continue;
      this.positions.set(site.id, { x: site.x, y: site.y, bodyY: site.y, topY: site.y - 90 * site.scale });
      if (visible(site.x, site.y)) {
        if (frame.selectedCampId === site.id || frame.hoveredId === site.id) this.foundationMarker(frame, { ...site, radius: "radius" in site ? site.radius : 32 * site.scale }, "#96774a", frame.selectedCampId === site.id);
        this.batches.add(`site:${site.model}`, model, this.pose(site.x, site.y, 0, 0, site.scale), site.id, "#a79b7f");
      }
    }
    for (const building of snapshot.buildings) {
      const modelKey = `buildings/${frame.buildingModels?.[building.id] ?? building.kind}`, model = this.template(modelKey, "Building");
      if (!model) continue;
      let bounds = this.bounds.get(modelKey);
      if (!bounds) {
        bounds = new THREE.Box3().setFromObject(model);
        this.bounds.set(modelKey, bounds);
      }
      const size = bounds.getSize(new THREE.Vector3()), square = footprintSquare(snapshot, building, building.radius);
      const extent2 = square ? (square.right - square.left + 1) * square.cell * 0.88 : building.radius * 2;
      const scale = extent2 / Math.max(size.x, size.z), height = size.y * scale;
      this.positions.set(building.id, { x: building.x, y: building.y, bodyY: building.y, topY: building.y - height * TILT });
      if (!visible(building.x, building.y, height * TILT + 180)) continue;
      const selected = frame.selectedIds?.has(building.id) ?? false;
      if (building.hp > 0 && (selected || frame.hoveredId === building.id)) this.foundationMarker(frame, building, this.markerInk(frame, building.owner), selected);
      this.batches.add(`building:${modelKey}:${ownerInk(building.owner, snapshot)}:${building.complete}`, model, this.pose(building.x, building.y, -bounds.min.y * scale, 0, scale), building.id, ownerInk(building.owner, snapshot), !building.complete);
    }
    const revealedShips = /* @__PURE__ */ new Set();
    for (const id of frame.selectedIds ?? []) {
      const unit = entities.get(id);
      if (!unit || !("order" in unit)) continue;
      if (unit.deck) revealedShips.add(unit.deck.shipId);
      else if (ships.has(unit.id)) revealedShips.add(unit.id);
    }
    for (const ship of ships.values()) {
      const at = frame.motion?.position(ship, now) ?? ship, heading = frame.motion?.heading(ship, now) ?? ship.sailing?.heading ?? 0, scale = shipScale(ship), profile = shipProfile(ship);
      const displayed = { ...ship, x: at.x, y: at.y, sailing: { ...ship.sailing, heading } };
      shareShipProfile(ship, displayed);
      this.shipPoses.set(ship.id, displayed);
      this.positions.set(ship.id, { x: at.x, y: at.y, bodyY: at.y, topY: at.y - (profile.deckHeight + profile.mastHeight) * TILT });
      if (!visible(at.x, at.y, profile.length * scale + profile.mastHeight)) continue;
      const selected = frame.selectedIds?.has(ship.id) ?? false;
      if (ship.hp > 0 && (selected || frame.hoveredId === ship.id)) this.selection.hull(ship.kind, profile.hull, scale, this.pose(at.x, at.y, 0.15, heading, scale), this.markerInk(frame, ship.owner), selected);
      const reveal = revealedShips.has(ship.id);
      const hull = this.template(`ships/${ship.kind}`, "Hull");
      if (hull) {
        const key = `ships/${ship.kind}`, transform = this.pose(at.x, at.y, 0, heading, scale);
        if (!this.rigModels.has(key)) this.rigModels.set(key, shipRigModel(hull));
        const rig = this.rigModels.get(key);
        let display = this.rigPoses.get(ship.id);
        if (rig && display?.model !== rig) {
          display = { model: rig, pose: rig.createPose(), worldRopes: rig.ropes.map(() => new THREE.Matrix4()) };
          this.rigPoses.set(ship.id, display);
        }
        const animation = display?.pose.update(this.sailMotion.pose(ship, now));
        this.batches.add(`ship:${ship.kind}:${Boolean(reveal)}`, hull, transform, ship.id, void 0, false, reveal, animation);
        const ensign = this.template(`ships/${ship.kind}`, "OwnerFlag");
        if (ensign) this.batches.add(`ship-ensign:${ship.kind}:${ownerInk(ship.owner, snapshot)}`, ensign, transform, ship.id, ownerInk(ship.owner, snapshot));
        if (display) for (let i = 0; i < display.pose.ropes.length; i++) {
          const rope = display.pose.ropes[i];
          if (!rope.visible) continue;
          const matrix = display.worldRopes[i].multiplyMatrices(transform, rope.matrix);
          this.batches.add(`rig-rope:${ship.kind}:${rope.material}:${Boolean(reveal)}`, rope.template, matrix, ship.id, void 0, false, reveal);
        }
      }
      const masts = profile.obstacles.filter((obstacle) => obstacle.type === "mast"), mast = masts[ship.kind === "shipOfTheLine" ? 1 : 0];
      if (mast) {
        const mastAt = localToWorld({ ...ship, x: at.x, y: at.y, sailing: { ...ship.sailing, heading } }, mast);
        this.batches.add(`flag:${ownerInk(ship.owner, snapshot)}`, this.flag, this.pose(mastAt.x, mastAt.y, profile.deckHeight + profile.mastHeight, 0, scale, rotation), ship.id, ownerInk(ship.owner, snapshot));
      }
      for (const item of installedWeapons(snapshot, ship)) {
        const weapon = mountedWeaponPose(displayed, item), gun = weapon && this.template(`ships/${weapon.art}`, "Gun");
        if (!weapon || !gun) continue;
        const recoil = this.recoil.get(item.id);
        const age = recoil ? (recoil.duration - recoil.remaining) / SIM_TICKS_PER_SECOND : 1;
        const back = weapon.art === "fireShip" ? 0 : 4 * scale * Math.max(0, age < 0.08 ? age / 0.08 : 1 - (age - 0.08) / 0.38);
        this.batches.add(`gun:${weapon.art}:${item.durability === 0}`, gun, this.pose(weapon.pivot.x - Math.cos(weapon.heading) * back, weapon.pivot.y - Math.sin(weapon.heading) * back, weapon.pivotHeight, weapon.heading, scale), ship.id, void 0, item.durability === 0);
      }
    }
    for (const source of this.shipPoses.values()) {
      const target = source.sailing?.gangway && this.shipPoses.get(source.sailing.gangway.targetId);
      const surface = target && gangwaySurface(source, target);
      if (!surface) continue;
      this.gangwaySurfaces.set(source.id, surface);
      const x = (surface.source.x + surface.target.x) / 2, y = (surface.source.y + surface.target.y) / 2;
      if (!visible(x, y, 100)) continue;
      const a = shipProfile(source).deckHeight, b = shipProfile(target).deckHeight;
      const dx = surface.target.x - surface.source.x, dy = surface.target.y - surface.source.y;
      this.bridgeAlong.set(dx, b - a, dy);
      const span = this.bridgeAlong.length();
      this.bridgeAlong.normalize();
      this.bridgeAcross.set(-dy, 0, dx).normalize();
      this.bridgeUp.crossVectors(this.bridgeAcross, this.bridgeAlong).normalize();
      const matrix = this.pose(0, 0, 0).makeBasis(this.bridgeAlong, this.bridgeUp, this.bridgeAcross).setPosition(x, (a + b) / 2 - 1, y).scale(this.transformScale.set(span, 2, surface.width));
      this.batches.add(`ship-gangway:${surface.phase}`, this.gangway, matrix, source.id, void 0, surface.phase === "deploying");
    }
    for (const id of this.rigPoses.keys()) if (!ships.has(id)) this.rigPoses.delete(id);
    const liveCrew = /* @__PURE__ */ new Set();
    for (const unit of this.activeIndex.query(frame.view)) {
      if (ships.has(unit.id) || isInCabin(unit)) continue;
      let at = frame.motion?.position(unit, now) ?? unit, height = 0, facing = frame.facing.facing(unit.id);
      let bridge;
      const ship = unit.deck && ships.get(unit.deck.shipId);
      if (ship) {
        liveCrew.add(unit.id);
        const parent = frame.motion?.position(ship, now) ?? ship, heading = frame.motion?.heading(ship, now) ?? ship.sailing?.heading ?? 0;
        bridge = gangwayCrewVisualPose(unit, this.shipPoses, this.gangwaySurfaces);
        if (bridge) {
          at = bridge;
          height = bridge.height;
        } else {
          const deck = this.deckPosition(unit, now), c = Math.cos(heading), s = Math.sin(heading);
          at = { x: parent.x + deck.x * c - deck.y * s, y: parent.y + deck.x * s + deck.y * c };
          height = shipProfile(ship).deckHeight;
        }
        const id = interactionTargetId(unit.order), aiming = unit.aim && ["attack", "attackMove", "hold", "aim", "cast"].includes(unit.order.type);
        facing = this.facing.facing(unit, heading, right, aiming ? unit.aim : id ? entities.get(id) : void 0);
      }
      const model = unit.variant === void 0 ? void 0 : frame.models?.(unit.variant);
      let rawAnimation;
      if (unit.deck) {
        rawAnimation = frame.reducedMotion ? { mode: "idle", frame: 0 } : frame.animation?.frame(unit, now) ?? { mode: "idle", frame: 0 };
        facing = frame.facing.actionFacing(unit.id, rawAnimation.direction ?? rawAnimation.carryDirection, projectVector, facing);
      }
      const scale = model ? Math.max(0.72, unit.radius / 18) : unitGlyphScale(unit.radius), foot = model ? 17 : creatureShadow(unit.kind)?.y ?? 17, bodyY = at.y - height * TILT - foot * scale;
      this.positions.set(unit.id, { x: at.x, y: at.y, bodyY, topY: bodyY - 64 * scale, facing });
      if (!visible(at.x, bodyY)) continue;
      rawAnimation ??= frame.reducedMotion ? { mode: "idle", frame: 0 } : frame.animation?.frame(unit, now) ?? { mode: "idle", frame: 0 };
      facing = frame.facing.actionFacing(unit.id, rawAnimation.direction ?? rawAnimation.carryDirection, projectVector, facing);
      const animation = projectActionFrame(rawAnimation, facing, projectVector);
      this.posed++;
      this.positions.get(unit.id).facing = facing;
      this.combatAnchors.set(unit.id, { x: at.x, y: at.y, floor: height, facing, sourceX: unit.x, sourceY: unit.y });
      const selected = frame.selectedIds?.has(unit.id) ?? false;
      if (unit.hp > 0 && (selected || frame.hoveredId === unit.id)) {
        let marker = this.pose(at.x, at.y, height + 0.15);
        const crossing = unit.gangway, surface = bridge && crossing && this.gangwaySurfaces.get(crossing.sourceId);
        if (surface && crossing) {
          const source = this.shipPoses.get(crossing.sourceId), target = this.shipPoses.get(crossing.targetId);
          const dx = surface.target.x - surface.source.x, dy = surface.target.y - surface.source.y;
          this.bridgeAlong.set(dx, shipProfile(target).deckHeight - shipProfile(source).deckHeight, dy).normalize();
          this.bridgeAcross.set(-dy, 0, dx).normalize();
          this.bridgeUp.crossVectors(this.bridgeAcross, this.bridgeAlong).normalize();
          marker = marker.makeBasis(this.bridgeAlong, this.bridgeUp, this.bridgeAcross).setPosition(at.x + this.bridgeUp.x * 0.15, height + this.bridgeUp.y * 0.15, at.y + this.bridgeUp.z * 0.15);
        }
        const radius = (unit.bodyRadius ?? unit.radius) + 3;
        this.selection.ellipse(marker, radius, radius * 0.55, this.markerInk(frame, unit.owner), selected);
      }
      const appearance = appearanceFor(snapshot, unit);
      const density = zoom < 0.65 ? 2 : 4, key = `${unitPaintKey(unit.kind, ownerInk(unit.owner, snapshot), animation, unit.variant)}:${facing}:${density}:${appearanceKey(appearance)}`;
      const transform = this.pose(at.x, at.y, height, 0, scale, rotation);
      const tileSize = model?.paint.paintSize?.(animation) ?? actionPaintSize(animation, unit.kind), baseMip = this.residentMip(tileSize, density, transform, foot);
      this.cards.add(key, density, (ctx) => {
        ctx.scale(facing, 1);
        if (model) model.paint(ctx, ownerInk(unit.owner, snapshot), animation, facing, appearance);
        else paintFigure(ctx, unit.kind, ownerInk(unit.owner, snapshot), animation, facing, appearance);
      }, transform, unit.id, foot, tileSize, 1, baseMip);
    }
    for (const [shipId, corpses] of deckRemainsByShip(snapshot.corpses)) {
      const ship = this.shipPoses.get(shipId);
      if (!ship || ship.hp <= 0) continue;
      for (const corpse of corpses) {
        const pose = deckRemainsPose(corpse, ship);
        if (!pose || !visible(pose.x, pose.y - pose.height * TILT, 128)) continue;
        const model = corpse.variant ? frame.models?.(corpse.variant) : void 0;
        const scale = model ? Math.max(0.72, corpse.radius / 18) : unitGlyphScale(corpse.radius);
        const appearance = corpseAppearanceFor(snapshot, corpse), color = ownerInk(corpse.owner, snapshot), variant = remainsVariant(corpse.id);
        const key = `corpse:${corpse.kind}:${corpse.variant ?? ""}:${color}:${corpseAppearanceKey(appearance)}:${variant}`;
        const transform = deckRemainsMatrix(this.pose(0, 0, 0), pose, scale);
        const density = zoom < 0.65 ? 2 : 4, baseMip = this.residentMip(128, density, transform, 0, false);
        this.remainsCards.add(key, density, (ctx) => {
          drawAtlasCorpse(ctx, corpse.kind, { x: 0, y: -7 }, 1, variant, model, corpse.variant, color, appearance);
        }, transform, corpse.id, 0, 128, remainsOpacity(snapshot.tick, corpse.diedAtTick), baseMip);
      }
    }
    for (const id of this.deckMotion.keys()) if (!liveCrew.has(id)) this.deckMotion.delete(id);
    for (const effect of snapshot.effects) {
      if (!PHYSICAL_EFFECTS.has(effect.type)) continue;
      const origin = frame.projectiles?.origin(effect);
      const shot = flightPose(effect, now - this.at, origin);
      const model = shot.look === "flash" ? this.flash : shot.look === "orb" ? this.magic : shot.look === "fire" ? this.fire : ["arrow", "spear", "streak"].includes(shot.look) ? this.bolt : this.ball;
      const glow = shot.look === "orb" ? spellOrbPalette(effect.sourceKind, effect.owner ? snapshot.players[effect.owner]?.race : void 0).glow : void 0;
      const color = glow ? `rgb(${glow.r},${glow.g},${glow.b})` : void 0;
      if (visible(shot.x, shot.y)) {
        let x = shot.x, y = shot.y, height = shot.height, rotation2;
        if (origin && model === this.bolt) {
          const cp = Math.cos(shot.pitch);
          this.missileDirection.set(Math.cos(shot.heading) * cp, Math.sin(shot.pitch), Math.sin(shot.heading) * cp);
          rotation2 = this.missileRotation.setFromUnitVectors(this.missileAxis, this.missileDirection);
          x -= this.missileDirection.x * 3;
          y -= this.missileDirection.z * 3;
          height -= this.missileDirection.y * 3;
        }
        this.batches.add(`effect:${shot.look}:${color ?? ""}`, model, this.pose(x, y, height, shot.heading, shot.scale, rotation2), effect.id, color);
      }
    }
    this.batches.finish();
    this.cards.finish(renderer);
    this.remainsCards.finish(renderer);
    this.selection.finish();
    if (frame.combat) this.combatInk.update(frame.combat.frame(now), this.combatAnchors, frame.reducedMotion, frame.view);
    else this.combatInk.clear();
    this.transforms.length = this.transformCount;
    renderer.render(this.scene, this.camera);
  }
  pick(point) {
    if (!this.view) return void 0;
    const ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2(point.x / this.view.width * 2 - 1, 1 - point.y / this.view.height * 2), this.camera);
    for (const hit of ray.intersectObjects([...this.batches.objects(), ...this.cards.objects()], false)) {
      const material = hit.object.material;
      const first = Array.isArray(material) ? material[hit.face?.materialIndex ?? 0] : material;
      if (first?.name.startsWith("unbleached sail") && first.transparent && first.opacity < 0.5) continue;
      if (hit.object.userData.paintedHit && !hit.object.userData.paintedHit(hit.instanceId ?? 0, hit.uv)) continue;
      if (!paintedHit(first?.map ?? void 0, hit.uv)) continue;
      const id = hit.object.userData.ids?.[hit.instanceId ?? 0];
      if (id && this.positions.has(id)) return { id, height: hit.point.y };
    }
    return void 0;
  }
  plane(point, height) {
    return this.view ? screenOnPlane(this.camera, this.view, point, height) : void 0;
  }
  markerInk(frame, owner) {
    return frame.viewer ? RELATION_INK[relationTo(frame.snapshot, frame.viewer, owner)] : ownerInk(owner, frame.snapshot);
  }
  foundationMarker(frame, body, color, selected) {
    const square = footprintSquare(frame.snapshot, body, body.radius);
    if (square) {
      const width = (square.right - square.left + 1) * square.cell, depth = (square.bottom - square.top + 1) * square.cell;
      this.selection.rectangle(this.pose(square.left * square.cell + width / 2, square.top * square.cell + depth / 2, 0.15), width / 2 - 1, depth / 2 - 1, color, selected);
    } else this.selection.ellipse(this.pose(body.x, body.y, 0.15), body.radius + 3, (body.radius + 3) * 0.55, color, selected);
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.eventCanvas?.removeEventListener("webglcontextlost", this.onContextLost);
    this.eventCanvas?.removeEventListener("webglcontextrestored", this.onContextRestored);
    this.eventCanvas = void 0;
    this.reset();
    this.selection.dispose();
    this.combatInk.dispose();
    this.water.dispose();
    for (const rig of this.rigModels.values()) rig?.dispose();
    this.rigModels.clear();
    this.templates.clear();
    this.bounds.clear();
    for (const mesh of [this.shadow, this.ball, this.bolt, this.magic, this.fire, this.flag, this.flash, this.gangway]) {
      mesh.geometry.dispose();
      mesh.material.dispose();
    }
    this.sun.shadow.dispose();
    this.sun.shadow.map = this.sun.shadow.mapPass = null;
    this.scene.clear();
    const renderer = this.renderer;
    this.renderer = void 0;
    renderer?.dispose();
    renderer?.forceContextLoss();
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndvcmxkLWxheWVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Ymxvb2RTdXJmYWNlUmVzb2x2ZXJ9IGZyb20gJy4uL2NvbWJhdC1zdXJmYWNlcyc7XG5pbXBvcnQge1ByZXNlbnRhdGlvblZpZXdJbmRleH0gZnJvbSAnLi4vcHJlc2VudGF0aW9uLXZpZXcnO1xuaW1wb3J0IHsgZGVja1JlbWFpbnNNYXRyaXggfSBmcm9tICcuL2RlY2stcmVtYWlucyc7XG5pbXBvcnQgeyBkZWNrUmVtYWluc0J5U2hpcCwgZGVja1JlbWFpbnNQb3NlLCByZW1haW5zT3BhY2l0eSwgcmVtYWluc1ZhcmlhbnQgfSBmcm9tICcuLi9kZWNrLXJlbWFpbnMnO1xuaW1wb3J0IHsgZHJhd0F0bGFzQ29ycHNlIH0gZnJvbSAnLi4vYXRsYXMtYXJ0JztcbmltcG9ydCB7IGNvcnBzZUFwcGVhcmFuY2VLZXkgfSBmcm9tICcuLi9hcnQvY29ycHNlcyc7XG5pbXBvcnQgdHlwZSB7VW5pdEFuaW1hdGlvbkZyYW1lfSBmcm9tICcuLi91bml0LWFuaW1hdGlvbic7XG5pbXBvcnQge3Byb2plY3RBY3Rpb25GcmFtZSxhY3Rpb25QYWludFNpemV9IGZyb20gJy4uL2FydC9hY3Rpb24tZGlyZWN0aW9uJztcbmltcG9ydCB7dW5pdFBhaW50S2V5fSBmcm9tICcuLi9hcnQvcGFpbnQtaWRlbnRpdHknO1xuaW1wb3J0IHtDb21iYXRJbmssdHlwZSBDb21iYXRBbmNob3J9IGZyb20gJy4vY29tYmF0LWluayc7XG5pbXBvcnQgKiBhcyBUSFJFRSBmcm9tICd0aHJlZSc7XG5pbXBvcnQgeyB3b3JsZE1vZGVscyxtYXRjaE1vZGVsS2V5cyxzbmFwc2hvdE1vZGVsS2V5cyB9IGZyb20gJy4vbW9kZWwtbGlicmFyeSc7XG5pbXBvcnQgeyBhY3RpdmF0ZU1vZGVsUG9ydHJhaXRzIH0gZnJvbSAnLi9tb2RlbC1wb3J0cmFpdHMnO1xuaW1wb3J0IHsgQWN0b3JCYXRjaGVzIH0gZnJvbSAnLi9iYXRjaGVzJztcbmltcG9ydCB7IFBhaW50ZWRDYXJkQmF0Y2hlcyxERUZBVUxUX0NBUkRfQkFOS1MgfSBmcm9tICcuL3BhaW50ZWQtY2FyZC1iYXRjaGVzJztcbmltcG9ydCB7Y2FyZEJhc2VNaXAsdHlwZSBDYXJkTWlwUGFzcyx0eXBlIENhcmRNaXBSZXNpZGVuY3lJbnB1dH0gZnJvbSAnLi9jYXJkLW1pcC1yZXNpZGVuY3knO1xuaW1wb3J0IHsgU2VsZWN0aW9uTWFya2VycyB9IGZyb20gJy4vc2VsZWN0aW9uLW1hcmtlcnMnO1xuaW1wb3J0IHsgU2FpbFBvc2VUcmFja2VyLHNoaXBSaWdNb2RlbCx0eXBlIFNoaXBSaWdNb2RlbCx0eXBlIFNoaXBSaWdQb3NlIH0gZnJvbSAnLi9zYWlsLXJpZyc7XG5pbXBvcnQgeyBDcmV3RmFjaW5nVHJhY2tlcix1cHJpZ2h0Q3Jld1JvdGF0aW9uIH0gZnJvbSAnLi9jcmV3LXBvc2UnO1xuaW1wb3J0IHsgY29uZmlndXJlV29ybGRDYW1lcmEsc2NyZWVuT25QbGFuZSB9IGZyb20gJy4vcHJvamVjdGlvbic7XG5pbXBvcnQgeyBmbGlnaHRQb3NlIH0gZnJvbSAnLi9mbGlnaHQtcG9zZSc7XG5pbXBvcnQgeyBwYWludGVkSGl0IH0gZnJvbSAnLi9wYWludGVkLWhpdCc7XG5pbXBvcnQgeyBXYXRlclN1cmZhY2UgfSBmcm9tICcuL3dhdGVyJztcbmltcG9ydCB7IGNyZWF0dXJlU2hhZG93IH0gZnJvbSAnLi4vYXJ0L3BhaW50ZWQtY3JlYXR1cmVzJztcbmltcG9ydCB7IHNwZWxsT3JiUGFsZXR0ZSB9IGZyb20gJy4uL2FydC9lZmZlY3QtcHJlc2VudGF0aW9uJztcbmltcG9ydCB7IHBhaW50RmlndXJlIH0gZnJvbSAnLi4vYXJ0L3BhaW50ZWQtdW5pdHMnO1xuaW1wb3J0IHsgYXBwZWFyYW5jZUZvcixhcHBlYXJhbmNlS2V5LGNvcnBzZUFwcGVhcmFuY2VGb3IgfSBmcm9tICcuLi9hcnQvdW5pdC1hcHBlYXJhbmNlJztcbmltcG9ydCB7IHVuaXRHbHlwaFNjYWxlIH0gZnJvbSAnLi4vZ2x5cGhzJztcbmltcG9ydCB7IGZvb3RwcmludFNxdWFyZSB9IGZyb20gJy4uL2Zvb3RwcmludC12aWV3JztcbmltcG9ydCB7IHJlbGF0aW9uVG8sUkVMQVRJT05fSU5LIH0gZnJvbSAnLi4vcmVsYXRpb25zJztcbmltcG9ydCB7IG93bmVySW5rLHRyYWNrVW5pdEZhY2luZyx0eXBlIFdvcmxkRnJhbWUgfSBmcm9tICcuLi93b3JsZC1yZW5kZXJlcic7XG5pbXBvcnQgeyBpbnRlcmFjdGlvblRhcmdldElkIH0gZnJvbSAnLi4vdW5pdC1mYWNpbmcnO1xuaW1wb3J0IHsgaW5zdGFsbGVkV2VhcG9ucyxtb3VudGVkV2VhcG9uUG9zZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGlwLWVxdWlwbWVudCc7XG5pbXBvcnQgeyBzaGlwUHJvZmlsZSxzaGFyZVNoaXBQcm9maWxlLHNoaXBTY2FsZSxsb2NhbFRvV29ybGQsU0hJUF9DQU1FUkEgfSBmcm9tICcuLi8uLi9zaGFyZWQvc2hpcC1nZW9tZXRyeSc7XG5pbXBvcnQgeyBpc0luQ2FiaW4gfSBmcm9tICcuLi8uLi9zaGFyZWQvc2hpcC1jYWJpbic7XG5pbXBvcnQgeyBnYW5nd2F5U3VyZmFjZSwgdHlwZSBHYW5nd2F5U3VyZmFjZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGlwLWdhbmd3YXknO1xuaW1wb3J0IHsgZ2FuZ3dheUNyZXdWaXN1YWxQb3NlIH0gZnJvbSAnLi4vc2hpcC1nYW5nd2F5LXZpc3VhbCc7XG5pbXBvcnQgeyBTSU1fVElDS1NfUEVSX1NFQ09ORCB9IGZyb20gJy4uLy4uL3NoYXJlZC90aW1lJztcbmltcG9ydCB0eXBlIHsgUmVzb3VyY2VQaGFzZSB9IGZyb20gJy4uL3Jlc291cmNlcyc7XG5pbXBvcnQgdHlwZSB7IEdhbWVTbmFwc2hvdCxPd25lcixVbml0IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3R5cGVzJztcblxuZXhwb3J0IHR5cGUgQWN0b3JQb3NpdGlvbj17eDpudW1iZXI7eTpudW1iZXI7Ym9keVk6bnVtYmVyO3RvcFk6bnVtYmVyO2ZhY2luZz86MXwtMX07XG5leHBvcnQgY29uc3QgUEhZU0lDQUxfRUZGRUNUUz1uZXcgU2V0PEdhbWVTbmFwc2hvdFsnZWZmZWN0cyddW251bWJlcl1bJ3R5cGUnXT4oWydzaGVsbEZsaWdodCcsJ3NpZWdlQm9sdCcsJ3Byb2plY3RpbGUnLCdtdXp6bGVGbGFzaCddKTtcbmNvbnN0IFRJTFQ9TWF0aC50YW4oU0hJUF9DQU1FUkEudGlsdCksVVA9bmV3IFRIUkVFLlZlY3RvcjMoMCwxLDApO1xuY2xhc3MgQWN0b3JQb3NpdGlvbnMgZXh0ZW5kcyBNYXA8c3RyaW5nLEFjdG9yUG9zaXRpb24+e1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGxvY2F0ZTooaWQ6c3RyaW5nKT0+QWN0b3JQb3NpdGlvbnx1bmRlZmluZWQpe3N1cGVyKCk7fVxuICBvdmVycmlkZSBnZXQoaWQ6c3RyaW5nKXtyZXR1cm4gc3VwZXIuZ2V0KGlkKT8/dGhpcy5sb2NhdGUoaWQpO31cbn1cblxuZXhwb3J0IGNsYXNzIFdvcmxkM0RMYXllciB7XG4gIC8qKiBWaXNpYmxlIHBvc2l0aW9ucyBhcmUgZWFnZXI7IG9mZnNjcmVlbiBVSS9lZmZlY3QgbG9va3VwcyBzdGF5IGV4YWN0IGFuZFxuICAgKiBhcmUgZXZhbHVhdGVkIG9uIGRlbWFuZCBpbnN0ZWFkIG9mIHByb2plY3RpbmcgdGhlIHdob2xlIGFybXkgZWFjaCBSQUYuICovXG4gIHJlYWRvbmx5IHBvc2l0aW9ucz1uZXcgQWN0b3JQb3NpdGlvbnMoaWQ9PnRoaXMub2Zmc2NyZWVuUG9zaXRpb24oaWQpKTtcbiAgcHJpdmF0ZSB2aWV3SW5kZXg9bmV3IFByZXNlbnRhdGlvblZpZXdJbmRleCgpO1xuICBwcml2YXRlIGFjdGl2ZUluZGV4PXRoaXMudmlld0luZGV4O1xuICBwcml2YXRlIGN1cnJlbnRGcmFtZTpXb3JsZEZyYW1lfHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBwb3NlZD0wO1xuICBwcml2YXRlIGRpcmVjdGlvblZpc2l0cz0wO1xuICBwcml2YXRlIGNhcmRNaXBCYXNlcz1bMCwwLDAsMCwwXTtcbiAgdmlld1N0YXRzKCl7cmV0dXJuey4uLnRoaXMuYWN0aXZlSW5kZXguc3RhdHMoKSxwb3NlZDp0aGlzLnBvc2VkLGRpcmVjdGlvblZpc2l0czp0aGlzLmRpcmVjdGlvblZpc2l0cyxwb3NpdGlvbnM6dGhpcy5wb3NpdGlvbnMuc2l6ZSxjYXJkTWlwQmFzZXM6Wy4uLnRoaXMuY2FyZE1pcEJhc2VzXX07fVxuICByZWFkb25seSBjYW1lcmE9bmV3IFRIUkVFLk9ydGhvZ3JhcGhpY0NhbWVyYSgpO1xuICBwcml2YXRlIHNjZW5lPW5ldyBUSFJFRS5TY2VuZSgpO1xuICBwcml2YXRlIHdhdGVyPW5ldyBXYXRlclN1cmZhY2UodGhpcy5zY2VuZSk7XG4gIHByaXZhdGUgbGlicmFyeT13b3JsZE1vZGVscztcbiAgcHJpdmF0ZSBiYXRjaGVzPW5ldyBBY3RvckJhdGNoZXModGhpcy5zY2VuZSk7XG4gIHByaXZhdGUgc2VsZWN0aW9uPW5ldyBTZWxlY3Rpb25NYXJrZXJzKHRoaXMuc2NlbmUpO1xuICBwcml2YXRlIGNvbWJhdEluaz1uZXcgQ29tYmF0SW5rKHRoaXMuc2NlbmUpO1xuICBwcml2YXRlIGNvbWJhdEFuY2hvcnM9bmV3IE1hcDxzdHJpbmcsQ29tYmF0QW5jaG9yPigpO1xuICBjb21iYXRTdGF0cygpe3JldHVybiB0aGlzLmNvbWJhdEluay5zdGF0cygpO31cbiAgcHJpdmF0ZSB0ZW1wbGF0ZXM9bmV3IE1hcDxzdHJpbmcsVEhSRUUuT2JqZWN0M0Q+KCk7XG4gIHByaXZhdGUgYm91bmRzPW5ldyBNYXA8c3RyaW5nLFRIUkVFLkJveDM+KCk7XG4gIHByaXZhdGUgY2FyZHM6UGFpbnRlZENhcmRCYXRjaGVzO1xuICBwcml2YXRlIHJlbWFpbnNDYXJkczpQYWludGVkQ2FyZEJhdGNoZXM7XG4gIHJlbWFpbnNTdGF0cygpe3JldHVybiB0aGlzLnJlbWFpbnNDYXJkcy5zdGF0cygpO31cbiAgY2FyZFN0YXRzKCl7cmV0dXJuIHRoaXMuY2FyZHMuc3RhdHMoKTt9XG4gIHByaXZhdGUgdHJhbnNmb3JtczpUSFJFRS5NYXRyaXg0W109W107XG4gIHByaXZhdGUgdHJhbnNmb3JtQ291bnQ9MDtcbiAgcHJpdmF0ZSB0cmFuc2Zvcm1Qb3NpdGlvbj1uZXcgVEhSRUUuVmVjdG9yMygpO1xuICBwcml2YXRlIHRyYW5zZm9ybVJvdGF0aW9uPW5ldyBUSFJFRS5RdWF0ZXJuaW9uKCk7XG4gIHByaXZhdGUgdHJhbnNmb3JtU2NhbGU9bmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgcHJpdmF0ZSBwcm9qZWN0ZWRPcmlnaW49bmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgcHJpdmF0ZSBwcm9qZWN0ZWREaXJlY3Rpb249bmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgcHJpdmF0ZSBtaXNzaWxlUm90YXRpb249bmV3IFRIUkVFLlF1YXRlcm5pb24oKTtcbiAgcHJpdmF0ZSBtaXNzaWxlRGlyZWN0aW9uPW5ldyBUSFJFRS5WZWN0b3IzKCk7XG4gIHByaXZhdGUgbWlzc2lsZUF4aXM9bmV3IFRIUkVFLlZlY3RvcjMoMSwwLDApO1xuICBwcml2YXRlIGVudGl0aWVzPW5ldyBNYXA8c3RyaW5nLEdhbWVTbmFwc2hvdFsndW5pdHMnXVtudW1iZXJdfEdhbWVTbmFwc2hvdFsnYnVpbGRpbmdzJ11bbnVtYmVyXT4oKTtcbiAgcHJpdmF0ZSBzaGlwcz1uZXcgTWFwPHN0cmluZyxVbml0PigpO1xuICBwcml2YXRlIHNoaXBQb3Nlcz1uZXcgTWFwPHN0cmluZyxVbml0PigpO1xuICBwcml2YXRlIGdhbmd3YXlTdXJmYWNlcz1uZXcgTWFwPHN0cmluZyxHYW5nd2F5U3VyZmFjZT4oKTtcbiAgcHJpdmF0ZSByZWNvaWw9bmV3IE1hcDxzdHJpbmcsR2FtZVNuYXBzaG90WydlZmZlY3RzJ11bbnVtYmVyXT4oKTtcbiAgcHJpdmF0ZSBpbmRleGVkVW5pdHM6R2FtZVNuYXBzaG90Wyd1bml0cyddfHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBpbmRleGVkQnVpbGRpbmdzOkdhbWVTbmFwc2hvdFsnYnVpbGRpbmdzJ118dW5kZWZpbmVkO1xuICBwcml2YXRlIGluZGV4ZWRFZmZlY3RzOkdhbWVTbmFwc2hvdFsnZWZmZWN0cyddfHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBpbmRleENvdW50cz0nJztcbiAgcHJpdmF0ZSBmYWNpbmc9bmV3IENyZXdGYWNpbmdUcmFja2VyKCk7XG4gIHByaXZhdGUgc2FpbE1vdGlvbj1uZXcgU2FpbFBvc2VUcmFja2VyKCk7XG4gIHByaXZhdGUgcmlnTW9kZWxzPW5ldyBNYXA8c3RyaW5nLFNoaXBSaWdNb2RlbHx1bmRlZmluZWQ+KCk7XG4gIHByaXZhdGUgcmlnUG9zZXM9bmV3IE1hcDxzdHJpbmcse21vZGVsOlNoaXBSaWdNb2RlbDtwb3NlOlNoaXBSaWdQb3NlO3dvcmxkUm9wZXM6VEhSRUUuTWF0cml4NFtdfT4oKTtcbiAgcHJpdmF0ZSBkZWNrTW90aW9uPW5ldyBNYXA8c3RyaW5nLHtzaGlwSWQ6c3RyaW5nO3g6bnVtYmVyO3k6bnVtYmVyO2Zyb21YOm51bWJlcjtmcm9tWTpudW1iZXI7YXQ6bnVtYmVyfT4oKTtcbiAgcHJpdmF0ZSBzbmFwc2hvdDpHYW1lU25hcHNob3R8dW5kZWZpbmVkO1xuICBwcml2YXRlIGxhc3RUaWNrPS0xO1xuICBwcml2YXRlIGF0PTA7XG4gIHByaXZhdGUgZnJhbWU9MDtcbiAgcHJpdmF0ZSB2aWV3cG9ydD0nJztcbiAgcHJpdmF0ZSB2aWV3OldvcmxkRnJhbWVbJ3ZpZXcnXXx1bmRlZmluZWQ7XG4gIHByaXZhdGUgZGlzcG9zZWQ9ZmFsc2U7XG4gIHByaXZhdGUgY29udGV4dExvc3Q9ZmFsc2U7XG4gIHByaXZhdGUgZXZlbnRDYW52YXM6SFRNTENhbnZhc0VsZW1lbnR8dW5kZWZpbmVkO1xuICBwcml2YXRlIG9uQ29udGV4dExvc3Q9KGV2ZW50OkV2ZW50KT0+e2V2ZW50LnByZXZlbnREZWZhdWx0KCk7dGhpcy5jb250ZXh0TG9zdD10cnVlO3RoaXMucmVsZWFzZUNvbnRleHRSZXNvdXJjZXMoKTt0aGlzLmNhcmRzLmludmFsaWRhdGVHUFUoKTt0aGlzLnJlbWFpbnNDYXJkcy5pbnZhbGlkYXRlR1BVKCk7fTtcbiAgcHJpdmF0ZSBvbkNvbnRleHRSZXN0b3JlZD0oKT0+e3RoaXMuY29udGV4dExvc3Q9ZmFsc2U7fTtcbiAgcHJpdmF0ZSBzdW49bmV3IFRIUkVFLkRpcmVjdGlvbmFsTGlnaHQoJyNmMWRjYzAnLDIuNSk7XG4gIHByaXZhdGUgY29sb3JNaXBQYXNzOkNhcmRNaXBQYXNzPXtjYW1lcmE6dGhpcy5jYW1lcmEscGh5c2ljYWxXaWR0aDowLHBoeXNpY2FsSGVpZ2h0OjB9O1xuICBwcml2YXRlIHNoYWRvd01pcFBhc3M6Q2FyZE1pcFBhc3M9e2NhbWVyYTp0aGlzLnN1bi5zaGFkb3cuY2FtZXJhLHBoeXNpY2FsV2lkdGg6MCxwaHlzaWNhbEhlaWdodDowfTtcbiAgcHJpdmF0ZSBjb2xvck1pcFBhc3Nlcz1bdGhpcy5jb2xvck1pcFBhc3NdO1xuICBwcml2YXRlIGFjdG9yTWlwUGFzc2VzPVt0aGlzLmNvbG9yTWlwUGFzcyx0aGlzLnNoYWRvd01pcFBhc3NdO1xuICBwcml2YXRlIG1pcElucHV0OkNhcmRNaXBSZXNpZGVuY3lJbnB1dD17c291cmNlU2l6ZToxLHRpbGVTaXplOjEsZm9vdDowLG1hdHJpeDpuZXcgVEhSRUUuTWF0cml4NCgpLHBhc3Nlczp0aGlzLmFjdG9yTWlwUGFzc2VzfTtcbiAgcHJpdmF0ZSBzaGFkb3c9bmV3IFRIUkVFLk1lc2gobmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMSwxKSxuZXcgVEhSRUUuU2hhZG93TWF0ZXJpYWwoe29wYWNpdHk6LjI0fSkpO1xuICBwcml2YXRlIGJhbGw9bmV3IFRIUkVFLk1lc2gobmV3IFRIUkVFLlNwaGVyZUdlb21ldHJ5KDMsOCw2KSxuZXcgVEhSRUUuTWVzaFN0YW5kYXJkTWF0ZXJpYWwoe2NvbG9yOicjNDE0OTQ1Jyxyb3VnaG5lc3M6MX0pKTtcbiAgcHJpdmF0ZSBib2x0PW5ldyBUSFJFRS5NZXNoKG5ldyBUSFJFRS5Db25lR2VvbWV0cnkoMS41LDI0LDQpLnJvdGF0ZVooLU1hdGguUEkvMikudHJhbnNsYXRlKC05LDAsMCksbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtjb2xvcjonI2MwYjM5MScscm91Z2huZXNzOjF9KSk7XG4gIHByaXZhdGUgbWFnaWM9bmV3IFRIUkVFLk1lc2gobmV3IFRIUkVFLlNwaGVyZUdlb21ldHJ5KDMsOCw2KSxuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoe2NvbG9yOicjODZjM2RjJyx0b25lTWFwcGVkOmZhbHNlfSkpO1xuICBwcml2YXRlIGZpcmU9bmV3IFRIUkVFLk1lc2gobmV3IFRIUkVFLlNwaGVyZUdlb21ldHJ5KDQsOCw2KSxuZXcgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwoe2NvbG9yOicjZTVhZDU1Jyx0b25lTWFwcGVkOmZhbHNlfSkpO1xuICBwcml2YXRlIGZsYWc9bmV3IFRIUkVFLk1lc2gobmV3IFRIUkVFLlBsYW5lR2VvbWV0cnkoMjAsMTMpLnRyYW5zbGF0ZSgxMCwtNi41LDApLG5ldyBUSFJFRS5NZXNoQmFzaWNNYXRlcmlhbCh7Y29sb3I6JyM4ODk3N2MnLHNpZGU6VEhSRUUuRG91YmxlU2lkZSx0b25lTWFwcGVkOmZhbHNlfSkpO1xuICBwcml2YXRlIGZsYXNoPW5ldyBUSFJFRS5NZXNoKG5ldyBUSFJFRS5TcGhlcmVHZW9tZXRyeSgxLDgsNiksbmV3IFRIUkVFLk1lc2hCYXNpY01hdGVyaWFsKHtjb2xvcjonI2ZmY2Y3NCcsdG9uZU1hcHBlZDpmYWxzZX0pKTtcbiAgcHJpdmF0ZSBnYW5nd2F5PW5ldyBUSFJFRS5NZXNoKG5ldyBUSFJFRS5Cb3hHZW9tZXRyeSgxLDEsMSksbmV3IFRIUkVFLk1lc2hTdGFuZGFyZE1hdGVyaWFsKHtjb2xvcjonIzliNzU1MCcscm91Z2huZXNzOjF9KSk7XG4gIHByaXZhdGUgYnJpZGdlQWxvbmc9bmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgcHJpdmF0ZSBicmlkZ2VBY3Jvc3M9bmV3IFRIUkVFLlZlY3RvcjMoKTtcbiAgcHJpdmF0ZSBicmlkZ2VVcD1uZXcgVEhSRUUuVmVjdG9yMygpO1xuICBwcml2YXRlIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVuZGVyZXI6VEhSRUUuV2ViR0xSZW5kZXJlcnx1bmRlZmluZWQpe1xuICAgIGNvbnN0IG1heFRleHR1cmVCYW5rcz1NYXRoLm1pbihERUZBVUxUX0NBUkRfQkFOS1MsTWF0aC5tYXgoMSwocmVuZGVyZXI/LmNhcGFiaWxpdGllcy5tYXhUZXh0dXJlcz8/MTYpLTQpKTtcbiAgICB0aGlzLmNhcmRzPW5ldyBQYWludGVkQ2FyZEJhdGNoZXModGhpcy5zY2VuZSxNYXRoLm1pbig4LHJlbmRlcmVyPy5jYXBhYmlsaXRpZXMuZ2V0TWF4QW5pc290cm9weSgpPz8xKSx7bWF4VGV4dHVyZUJhbmtzfSk7XG4gICAgdGhpcy5yZW1haW5zQ2FyZHM9bmV3IFBhaW50ZWRDYXJkQmF0Y2hlcyh0aGlzLnNjZW5lLE1hdGgubWluKDgscmVuZGVyZXI/LmNhcGFiaWxpdGllcy5nZXRNYXhBbmlzb3Ryb3B5KCk/PzEpLHt0cmFuc3BhcmVudDp0cnVlLGRlcHRoV3JpdGU6ZmFsc2UsYWxwaGFUZXN0Oi4wMSxjYXN0U2hhZG93OmZhbHNlLHBpY2thYmxlOmZhbHNlLHJlbmRlck9yZGVyOi0xLG1heFRleHR1cmVCYW5rc30pO1xuICAgIHRoaXMuZmxhZy5tYXRlcmlhbC5uYW1lPSdUZWFtQ29sb3InO1xuICAgIHRoaXMubWFnaWMubmFtZT0nU3BlbGxPcmInO3RoaXMubWFnaWMubWF0ZXJpYWwubmFtZT0nVGVhbUNvbG9yJztcbiAgICB0aGlzLmdhbmd3YXkubmFtZT0nU2hpcEdhbmd3YXknO1xuICAgIHRoaXMuc2NlbmUuYWRkKG5ldyBUSFJFRS5IZW1pc3BoZXJlTGlnaHQoJyNkZGQ3YzUnLCcjMjYzYzNhJywxLjI1KSk7XG4gICAgdGhpcy5zdW4uY2FzdFNoYWRvdz10cnVlO3RoaXMuc3VuLnNoYWRvdy5tYXBTaXplLnNldCgyMDQ4LDIwNDgpO3RoaXMuc3VuLnNoYWRvdy5iaWFzPS0uMDAwNDt0aGlzLnN1bi5zaGFkb3cubm9ybWFsQmlhcz0uMzU7XG4gICAgdGhpcy5zY2VuZS5hZGQodGhpcy5zdW4sdGhpcy5zdW4udGFyZ2V0KTt0aGlzLnNoYWRvdy5yb3RhdGlvbi54PS1NYXRoLlBJLzI7dGhpcy5zaGFkb3cucmVjZWl2ZVNoYWRvdz10cnVlO3RoaXMuc2NlbmUuYWRkKHRoaXMuc2hhZG93KTtcbiAgfVxuICAvKiogRGV0YWNoIHRoZSBvbGQgcmVuZGVyZXIncyBwdWJsaWMgZGlzcG9zZSBsaXN0ZW5lcnMgd2hpbGUgaXRzIGNvbnRleHQgaXNcbiAgICogbG9zdC4gT3RoZXJ3aXNlIGxhdGVyIHJlc2V0L2Rpc3Bvc2UgYXR0ZW1wdHMgdG8gZGVsZXRlIHByZS1sb3NzIFZBT3MgYW5kXG4gICAqIGJ1ZmZlcnMgaW4gdGhlIHJlc3RvcmVkIGNvbnRleHQuIFNjZW5lIG1lc2hlcyBvd24gdGhlaXIgcmVzb3VyY2Ugdmlld3M7XG4gICAqIGdsb2JhbCBkZWNvZGVkIG1vZGVsIHRlbXBsYXRlcyBhcmUgbmV2ZXIgdHJhdmVyc2VkIG9yIGRpc3Bvc2VkIGhlcmUuIENQVVxuICAgKiBnZW9tZXRyeS90ZXh0dXJlIGRhdGEgcmVtYWlucyBhdmFpbGFibGUgZm9yIG5vcm1hbCByZXN0b3JhdGlvbiB1cGxvYWRzLiAqL1xuICBwcml2YXRlIHJlbGVhc2VDb250ZXh0UmVzb3VyY2VzKCl7XG4gICAgY29uc3QgZ2VvbWV0cmllcz1uZXcgU2V0PFRIUkVFLkJ1ZmZlckdlb21ldHJ5PigpLG1hdGVyaWFscz1uZXcgU2V0PFRIUkVFLk1hdGVyaWFsPigpLHRleHR1cmVzPW5ldyBTZXQ8VEhSRUUuVGV4dHVyZT4oKTtcbiAgICB0aGlzLnNjZW5lLnRyYXZlcnNlKG9iamVjdD0+e1xuICAgICAgaWYob2JqZWN0IGluc3RhbmNlb2YgVEhSRUUuTWVzaCl7XG4gICAgICAgIG9iamVjdC5kaXNwb3NlKCk7Z2VvbWV0cmllcy5hZGQob2JqZWN0Lmdlb21ldHJ5KTtcbiAgICAgICAgZm9yKGNvbnN0IG1hdGVyaWFsIG9mIEFycmF5LmlzQXJyYXkob2JqZWN0Lm1hdGVyaWFsKT9vYmplY3QubWF0ZXJpYWw6W29iamVjdC5tYXRlcmlhbF0pbWF0ZXJpYWxzLmFkZChtYXRlcmlhbCk7XG4gICAgICAgIGlmKG9iamVjdC5jdXN0b21EZXB0aE1hdGVyaWFsKW1hdGVyaWFscy5hZGQob2JqZWN0LmN1c3RvbURlcHRoTWF0ZXJpYWwpO1xuICAgICAgICBpZihvYmplY3QuY3VzdG9tRGlzdGFuY2VNYXRlcmlhbCltYXRlcmlhbHMuYWRkKG9iamVjdC5jdXN0b21EaXN0YW5jZU1hdGVyaWFsKTtcbiAgICAgIH1cbiAgICAgIGlmKG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLkRpcmVjdGlvbmFsTGlnaHR8fG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLlBvaW50TGlnaHR8fG9iamVjdCBpbnN0YW5jZW9mIFRIUkVFLlNwb3RMaWdodCl7b2JqZWN0LnNoYWRvdy5kaXNwb3NlKCk7b2JqZWN0LnNoYWRvdy5tYXA9b2JqZWN0LnNoYWRvdy5tYXBQYXNzPW51bGw7fVxuICAgIH0pO1xuICAgIGZvcihjb25zdCBtYXRlcmlhbCBvZiBtYXRlcmlhbHMpe1xuICAgICAgZm9yKGNvbnN0IHZhbHVlIG9mIE9iamVjdC52YWx1ZXMobWF0ZXJpYWwpKWlmKHZhbHVlIGluc3RhbmNlb2YgVEhSRUUuVGV4dHVyZSl0ZXh0dXJlcy5hZGQodmFsdWUpO1xuICAgICAgaWYobWF0ZXJpYWwgaW5zdGFuY2VvZiBUSFJFRS5TaGFkZXJNYXRlcmlhbClmb3IoY29uc3QgdW5pZm9ybSBvZiBPYmplY3QudmFsdWVzKG1hdGVyaWFsLnVuaWZvcm1zKSl7XG4gICAgICAgIGNvbnN0IHZhbHVlcz1BcnJheS5pc0FycmF5KHVuaWZvcm0udmFsdWUpP3VuaWZvcm0udmFsdWU6W3VuaWZvcm0udmFsdWVdO2Zvcihjb25zdCB2YWx1ZSBvZiB2YWx1ZXMpaWYodmFsdWUgaW5zdGFuY2VvZiBUSFJFRS5UZXh0dXJlKXRleHR1cmVzLmFkZCh2YWx1ZSk7XG4gICAgICB9XG4gICAgICBtYXRlcmlhbC5kaXNwb3NlKCk7XG4gICAgfVxuICAgIGZvcihjb25zdCBnZW9tZXRyeSBvZiBnZW9tZXRyaWVzKWdlb21ldHJ5LmRpc3Bvc2UoKTtcbiAgICBmb3IoY29uc3QgdGV4dHVyZSBvZiB0ZXh0dXJlcyl0ZXh0dXJlLmRpc3Bvc2UoKTtcbiAgfVxuICBzdGF0aWMgY3JlYXRlKGNhbnZhczpIVE1MQ2FudmFzRWxlbWVudCxjb250ZXh0OldlYkdMMlJlbmRlcmluZ0NvbnRleHQpe1xuICAgIGNvbnN0IHJlbmRlcmVyPW5ldyBUSFJFRS5XZWJHTFJlbmRlcmVyKHtjYW52YXMsY29udGV4dCxhbHBoYTp0cnVlLGFudGlhbGlhczp0cnVlfSk7XG4gICAgcmVuZGVyZXIuc2V0Q2xlYXJDb2xvcigwLDApO3JlbmRlcmVyLnNoYWRvd01hcC5lbmFibGVkPXRydWU7cmVuZGVyZXIuc2hhZG93TWFwLnR5cGU9VEhSRUUuUENGU2hhZG93TWFwO1xuICAgIHJlbmRlcmVyLnRvbmVNYXBwaW5nPVRIUkVFLkFDRVNGaWxtaWNUb25lTWFwcGluZztyZW5kZXJlci50b25lTWFwcGluZ0V4cG9zdXJlPS45O1xuICAgIGNvbnN0IGxheWVyPW5ldyBXb3JsZDNETGF5ZXIocmVuZGVyZXIpO2xheWVyLmV2ZW50Q2FudmFzPWNhbnZhcztcbiAgICBjYW52YXMuYWRkRXZlbnRMaXN0ZW5lcignd2ViZ2xjb250ZXh0bG9zdCcsbGF5ZXIub25Db250ZXh0TG9zdCk7Y2FudmFzLmFkZEV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dHJlc3RvcmVkJyxsYXllci5vbkNvbnRleHRSZXN0b3JlZCk7XG4gICAgcmV0dXJuIGxheWVyO1xuICB9XG4gIGFzeW5jIHByZXBhcmUoc25hcHNob3Q6R2FtZVNuYXBzaG90LHBoYXNlOlJlc291cmNlUGhhc2Usc2l0ZXM6cmVhZG9ubHkgc3RyaW5nW109W10pe2lmKHRoaXMuZGlzcG9zZWQpcmV0dXJuO2F3YWl0IHRoaXMubGlicmFyeS5wcmVwYXJlKHBoYXNlPT09J21hdGNoJz9tYXRjaE1vZGVsS2V5czpbLi4uc25hcHNob3RNb2RlbEtleXMoc25hcHNob3QpLC4uLnNpdGVzLm1hcChraW5kPT5gYnVpbGRpbmdzLyR7a2luZH1gKV0scGhhc2UpO2lmKCF0aGlzLmRpc3Bvc2VkKWFjdGl2YXRlTW9kZWxQb3J0cmFpdHMoKTt9XG4gIHByaXZhdGUgdGVtcGxhdGUoa2V5OnN0cmluZyxuYW1lOnN0cmluZyl7Y29uc3QgaWQ9YCR7a2V5fToke25hbWV9YDtsZXQgbW9kZWw9dGhpcy50ZW1wbGF0ZXMuZ2V0KGlkKTtpZighbW9kZWwpe21vZGVsPXRoaXMubGlicmFyeS5jb21wb25lbnQoa2V5LG5hbWUpO2lmKG1vZGVsKXRoaXMudGVtcGxhdGVzLnNldChpZCxtb2RlbCk7fXJldHVybiBtb2RlbDt9XG4gIHJlc2V0KCl7dGhpcy5sYXN0VGljaz0tMTt0aGlzLnNuYXBzaG90PXVuZGVmaW5lZDt0aGlzLmluZGV4ZWRVbml0cz10aGlzLmluZGV4ZWRCdWlsZGluZ3M9dGhpcy5pbmRleGVkRWZmZWN0cz11bmRlZmluZWQ7dGhpcy5pbmRleENvdW50cz0nJzt0aGlzLnZpZXc9dW5kZWZpbmVkO3RoaXMuY3VycmVudEZyYW1lPXVuZGVmaW5lZDt0aGlzLnZpZXdJbmRleC5yZXNldCgpO3RoaXMuYWN0aXZlSW5kZXg9dGhpcy52aWV3SW5kZXg7dGhpcy5wb3NpdGlvbnMuY2xlYXIoKTt0aGlzLmNvbWJhdEFuY2hvcnMuY2xlYXIoKTt0aGlzLmNvbWJhdEluay5jbGVhcigpO3RoaXMuZW50aXRpZXM9bmV3IE1hcCgpO3RoaXMuc2hpcHMuY2xlYXIoKTt0aGlzLnNoaXBQb3Nlcy5jbGVhcigpO3RoaXMuZ2FuZ3dheVN1cmZhY2VzLmNsZWFyKCk7dGhpcy5yZWNvaWwuY2xlYXIoKTt0aGlzLmRlY2tNb3Rpb24uY2xlYXIoKTt0aGlzLmZhY2luZz1uZXcgQ3Jld0ZhY2luZ1RyYWNrZXIoKTt0aGlzLnNhaWxNb3Rpb24ucmVzZXQoKTt0aGlzLnJpZ1Bvc2VzLmNsZWFyKCk7dGhpcy50cmFuc2Zvcm1zLmxlbmd0aD0wO3RoaXMudHJhbnNmb3JtQ291bnQ9MDt0aGlzLmJhdGNoZXMuZGlzcG9zZSgpO3RoaXMuY2FyZHMuZGlzcG9zZSgpO3RoaXMucmVtYWluc0NhcmRzLmRpc3Bvc2UoKTt0aGlzLnNlbGVjdGlvbi5jbGVhcigpO3RoaXMud2F0ZXIucHJlcGFyZSh1bmRlZmluZWQpO31cbiAgcHJpdmF0ZSBvZmZzY3JlZW5Qb3NpdGlvbihpZDpzdHJpbmcpOkFjdG9yUG9zaXRpb258dW5kZWZpbmVke1xuICAgIGNvbnN0IGZyYW1lPXRoaXMuY3VycmVudEZyYW1lLHVuaXQ9dGhpcy5hY3RpdmVJbmRleC51bml0cy5nZXQoaWQpO1xuICAgIGlmKCFmcmFtZXx8IXVuaXR8fHVuaXQuZGVja3x8aXNJbkNhYmluKHVuaXQpfHxzaGlwUHJvZmlsZSh1bml0KSlyZXR1cm4gdW5kZWZpbmVkO1xuICAgIGNvbnN0IGF0PWZyYW1lLm1vdGlvbj8ucG9zaXRpb24odW5pdCxmcmFtZS5ub3cpPz91bml0LG1vZGVsPXVuaXQudmFyaWFudD09PXVuZGVmaW5lZD91bmRlZmluZWQ6ZnJhbWUubW9kZWxzPy4odW5pdC52YXJpYW50KTtcbiAgICBjb25zdCBzY2FsZT1tb2RlbD9NYXRoLm1heCguNzIsdW5pdC5yYWRpdXMvMTgpOnVuaXRHbHlwaFNjYWxlKHVuaXQucmFkaXVzKSxmb290PW1vZGVsPzE3OmNyZWF0dXJlU2hhZG93KHVuaXQua2luZCk/Lnk/PzE3LGJvZHlZPWF0LnktZm9vdCpzY2FsZTtcbiAgICBjb25zdCByZXN1bHQ9e3g6YXQueCx5OmF0LnksYm9keVksdG9wWTpib2R5WS02NCpzY2FsZSxmYWNpbmc6ZnJhbWUuZmFjaW5nLnJlbGVhc2VGYWNpbmcoaWQpfTtcbiAgICB0aGlzLnBvc2l0aW9ucy5zZXQoaWQscmVzdWx0KTtyZXR1cm4gcmVzdWx0O1xuICB9XG4gIHByaXZhdGUgcG9zZSh4Om51bWJlcix5Om51bWJlcixoZWlnaHQ6bnVtYmVyLGhlYWRpbmc9MCxzY2FsZT0xLHJvdGF0aW9uPzpUSFJFRS5RdWF0ZXJuaW9uKXtcbiAgICBsZXQgbWF0cml4PXRoaXMudHJhbnNmb3Jtc1t0aGlzLnRyYW5zZm9ybUNvdW50XTtcbiAgICBpZighbWF0cml4KXttYXRyaXg9bmV3IFRIUkVFLk1hdHJpeDQoKTt0aGlzLnRyYW5zZm9ybXNbdGhpcy50cmFuc2Zvcm1Db3VudF09bWF0cml4O31cbiAgICB0aGlzLnRyYW5zZm9ybUNvdW50Kys7XG4gICAgcmV0dXJuIG1hdHJpeC5jb21wb3NlKHRoaXMudHJhbnNmb3JtUG9zaXRpb24uc2V0KHgsaGVpZ2h0LHkpLHJvdGF0aW9uPz90aGlzLnRyYW5zZm9ybVJvdGF0aW9uLnNldEZyb21BeGlzQW5nbGUoVVAsLWhlYWRpbmcpLHRoaXMudHJhbnNmb3JtU2NhbGUuc2V0U2NhbGFyKHNjYWxlKSk7XG4gIH1cbiAgcHJpdmF0ZSByZXNpZGVudE1pcCh0aWxlU2l6ZTpudW1iZXIsZGVuc2l0eTpudW1iZXIsbWF0cml4OlRIUkVFLk1hdHJpeDQsZm9vdDpudW1iZXIsY2FzdHNTaGFkb3c9dHJ1ZSl7XG4gICAgY29uc3QgaW5wdXQ9dGhpcy5taXBJbnB1dDtpbnB1dC5zb3VyY2VTaXplPXRpbGVTaXplKmRlbnNpdHk7aW5wdXQudGlsZVNpemU9dGlsZVNpemU7aW5wdXQubWF0cml4PW1hdHJpeDtpbnB1dC5mb290PWZvb3Q7aW5wdXQucGFzc2VzPWNhc3RzU2hhZG93P3RoaXMuYWN0b3JNaXBQYXNzZXM6dGhpcy5jb2xvck1pcFBhc3NlcztcbiAgICBjb25zdCBiYXNlPWNhcmRCYXNlTWlwKGlucHV0KTt0aGlzLmNhcmRNaXBCYXNlc1tiYXNlXSErKztyZXR1cm4gYmFzZTtcbiAgfVxuICBwcml2YXRlIGRlY2tQb3NpdGlvbih1bml0OlVuaXQsbm93Om51bWJlcil7XG4gICAgY29uc3QgdHJhY2s9dGhpcy5kZWNrTW90aW9uLmdldCh1bml0LmlkKTtcbiAgICAvLyBSZXR1cm5pbmcgZnJvbSBzaGVsdGVyIGNhbiBjaGFuZ2UgYSBjb21tYW5kIHNuYXBzaG90IGJlZm9yZSBpdHMgbmV4dFxuICAgIC8vIHRpY2suIEhpZGRlbiBjcmV3IGhhdmUgbm8gaW50ZXJwb2xhdGlvbiB0cmFjazsgdXNlIHRoZWlyIGFjdHVhbCBleGl0LlxuICAgIGlmKCF0cmFjayB8fCB0cmFjay5zaGlwSWQhPT11bml0LmRlY2shLnNoaXBJZClyZXR1cm4gdW5pdC5kZWNrITtcbiAgICBjb25zdCB0PU1hdGgubWF4KDAsTWF0aC5taW4oMSwobm93LXRyYWNrLmF0KSpTSU1fVElDS1NfUEVSX1NFQ09ORC8xMDAwKSk7XG4gICAgcmV0dXJue3g6dHJhY2suZnJvbVgrKHRyYWNrLngtdHJhY2suZnJvbVgpKnQseTp0cmFjay5mcm9tWSsodHJhY2sueS10cmFjay5mcm9tWSkqdH07XG4gIH1cbiAgZHJhdyhmcmFtZTpXb3JsZEZyYW1lKXtcbiAgICBjb25zdCByZW5kZXJlcj10aGlzLnJlbmRlcmVyO2lmKHRoaXMuZGlzcG9zZWR8fHRoaXMuY29udGV4dExvc3R8fCFyZW5kZXJlcilyZXR1cm47XG4gICAgdGhpcy5mcmFtZSsrO3RoaXMudHJhbnNmb3JtQ291bnQ9MDt0aGlzLnZpZXc9ZnJhbWUudmlldzt0aGlzLmN1cnJlbnRGcmFtZT1mcmFtZTt0aGlzLnBvc2VkPTA7dGhpcy5jYXJkTWlwQmFzZXMuZmlsbCgwKTtcbiAgICBjb25zdCB7c25hcHNob3Qsbm93fT1mcmFtZTtjb25zdCB6b29tPWZyYW1lLnZpZXcuem9vbT8/MTtcbiAgICBjb25zdCBwaXhlbFJhdGlvPU1hdGgubWluKGRldmljZVBpeGVsUmF0aW8sMiksdmlld3BvcnQ9YCR7ZnJhbWUudmlldy53aWR0aH06JHtmcmFtZS52aWV3LmhlaWdodH06JHtwaXhlbFJhdGlvfWA7XG4gICAgaWYodmlld3BvcnQhPT10aGlzLnZpZXdwb3J0KXtyZW5kZXJlci5zZXRQaXhlbFJhdGlvKHBpeGVsUmF0aW8pO3JlbmRlcmVyLnNldFNpemUoZnJhbWUudmlldy53aWR0aCxmcmFtZS52aWV3LmhlaWdodCxmYWxzZSk7dGhpcy52aWV3cG9ydD12aWV3cG9ydDt9XG4gICAgdGhpcy5jb2xvck1pcFBhc3MucGh5c2ljYWxXaWR0aD1NYXRoLmZsb29yKGZyYW1lLnZpZXcud2lkdGgqcGl4ZWxSYXRpbyk7dGhpcy5jb2xvck1pcFBhc3MucGh5c2ljYWxIZWlnaHQ9TWF0aC5mbG9vcihmcmFtZS52aWV3LmhlaWdodCpwaXhlbFJhdGlvKTtcbiAgICBjb25maWd1cmVXb3JsZENhbWVyYSh0aGlzLmNhbWVyYSxmcmFtZS52aWV3KTtcbiAgICAvLyBQcmVsb2FkaW5nIG1hdGNoIG1vZGVscyBtYXkgdXNlIHRoZSBob21lIHNuYXBzaG90LiBPbmx5IHRoZSBmcmFtZSBiZWluZ1xuICAgIC8vIHJlbmRlcmVkIGlzIGFsbG93ZWQgdG8gYmluZCBzY2VuZSB0ZXJyYWluLCBpbmNsdWRpbmcgYWZ0ZXIgYSBtYXAgY2hhbmdlLlxuICAgIHRoaXMud2F0ZXIucHJlcGFyZShzbmFwc2hvdC5tYXAudGVycmFpbik7XG4gICAgdGhpcy53YXRlci51cGRhdGUobm93LGZyYW1lLnJlZHVjZWRNb3Rpb24pO1xuICAgIGNvbnN0IGN4PWZyYW1lLnZpZXcueCtmcmFtZS52aWV3LndpZHRoLygyKnpvb20pLGN5PWZyYW1lLnZpZXcueStmcmFtZS52aWV3LmhlaWdodC8oMip6b29tKSxleHRlbnQ9TWF0aC5tYXgoZnJhbWUudmlldy53aWR0aCxmcmFtZS52aWV3LmhlaWdodCkvem9vbSs0MDA7XG4gICAgdGhpcy5zaGFkb3cucG9zaXRpb24uc2V0KGN4LC0uMSxjeSk7dGhpcy5zaGFkb3cuc2NhbGUuc2V0KGV4dGVudCxleHRlbnQsMSk7XG4gICAgdGhpcy5zdW4ucG9zaXRpb24uc2V0KGN4LTQ1MCw2NTAsY3krMjUwKTt0aGlzLnN1bi50YXJnZXQucG9zaXRpb24uc2V0KGN4LDAsY3kpO1xuICAgIGNvbnN0IHNoYWRvdz10aGlzLnN1bi5zaGFkb3cuY2FtZXJhO3NoYWRvdy5sZWZ0PXNoYWRvdy5ib3R0b209LWV4dGVudC8yO3NoYWRvdy5yaWdodD1zaGFkb3cudG9wPWV4dGVudC8yO3NoYWRvdy5uZWFyPTE7c2hhZG93LmZhcj0zMDAwO3NoYWRvdy51cGRhdGVQcm9qZWN0aW9uTWF0cml4KCk7XG4gICAgLy8gRXZhbHVhdGUgdGhlIHNhbWUgcHVibGljIHNoYWRvdyBjYW1lcmEgdGhlIHJlbmRlcmVyIHdpbGwgc2FtcGxlLiBBIHNtYWxsXG4gICAgLy8gY29sb3IgZm9vdHByaW50IGFsb25lIGlzIGluc3VmZmljaWVudDogdGhlIDIwNDhweCBzaGFkb3cgY2FuIG5lZWQgZGV0YWlsLlxuICAgIHRoaXMuc3VuLnVwZGF0ZVdvcmxkTWF0cml4KHRydWUsZmFsc2UpO3RoaXMuc3VuLnRhcmdldC51cGRhdGVXb3JsZE1hdHJpeCh0cnVlLGZhbHNlKTt0aGlzLnN1bi5zaGFkb3cudXBkYXRlTWF0cmljZXModGhpcy5zdW4pO1xuICAgIHRoaXMuc2hhZG93TWlwUGFzcy5waHlzaWNhbFdpZHRoPXRoaXMuc3VuLnNoYWRvdy5tYXBTaXplLng7dGhpcy5zaGFkb3dNaXBQYXNzLnBoeXNpY2FsSGVpZ2h0PXRoaXMuc3VuLnNoYWRvdy5tYXBTaXplLnk7XG4gICAgZnJhbWUucHJvamVjdGlsZXM/LnVwZGF0ZShzbmFwc2hvdCxmcmFtZS5tb2RlbHMsaWQ9PmZyYW1lLmZhY2luZy5yZWxlYXNlRmFjaW5nKGlkKSk7XG4gICAgZnJhbWUuYW5pbWF0aW9uPy51cGRhdGUoc25hcHNob3Qsbm93LGZyYW1lLnN0b3J5Py51bml0QWN0aW9ucyk7ZnJhbWUubW90aW9uPy51cGRhdGUoc25hcHNob3Qsbm93KTtcbiAgICB0aGlzLmFjdGl2ZUluZGV4PWZyYW1lLnZpZXdJbmRleD8/dGhpcy52aWV3SW5kZXg7dGhpcy5hY3RpdmVJbmRleC51cGRhdGUoc25hcHNob3QsZnJhbWUubW90aW9uKTtcbiAgICB0aGlzLmVudGl0aWVzPXRoaXMuYWN0aXZlSW5kZXguZW50aXRpZXM7XG4gICAgLy8gQ29tbWFuZHMgY2FuIHJlcGxhY2UgYSBzbmFwc2hvdCB3aXRob3V0IGFkdmFuY2luZyBpdHMgdGljazsgcmVjb3JkaW5nc1xuICAgIC8vIGNhbiBhZHZhbmNlIGEgbXV0YWJsZSBzbmFwc2hvdCBvciByZXBsYWNlIGFycmF5cy4gUmV1c2UgdGhlIHNoYXJlZCBlbnRpdHlcbiAgICAvLyBpbmRleCBpbnN0ZWFkIG9mIGNvbnN0cnVjdGluZyBhbm90aGVyIGFsbC13b3JsZCBtYXAgZm9yIHRoaXMgbGF5ZXIuXG4gICAgY29uc3QgaW5kZXhDb3VudHM9YCR7c25hcHNob3QudW5pdHMubGVuZ3RofToke3NuYXBzaG90LmJ1aWxkaW5ncy5sZW5ndGh9OiR7c25hcHNob3QuZWZmZWN0cy5sZW5ndGh9YDtcbiAgICBpZihzbmFwc2hvdCE9PXRoaXMuc25hcHNob3R8fHNuYXBzaG90LnRpY2shPT10aGlzLmxhc3RUaWNrfHxzbmFwc2hvdC51bml0cyE9PXRoaXMuaW5kZXhlZFVuaXRzfHxzbmFwc2hvdC5idWlsZGluZ3MhPT10aGlzLmluZGV4ZWRCdWlsZGluZ3N8fHNuYXBzaG90LmVmZmVjdHMhPT10aGlzLmluZGV4ZWRFZmZlY3RzfHxpbmRleENvdW50cyE9PXRoaXMuaW5kZXhDb3VudHMpe1xuICAgICAgdGhpcy5zaGlwcy5jbGVhcigpO3RoaXMucmVjb2lsLmNsZWFyKCk7XG4gICAgICBmb3IoY29uc3QgdW5pdCBvZiB0aGlzLmFjdGl2ZUluZGV4LnNoaXBzKXRoaXMuc2hpcHMuc2V0KHVuaXQuaWQsdW5pdCk7XG4gICAgICBmb3IoY29uc3QgZWZmZWN0IG9mIHNuYXBzaG90LmVmZmVjdHMpaWYoZWZmZWN0LnR5cGU9PT0nbXV6emxlRmxhc2gnJiZlZmZlY3QuaXRlbUlkJiYhdGhpcy5yZWNvaWwuaGFzKGVmZmVjdC5pdGVtSWQpKXRoaXMucmVjb2lsLnNldChlZmZlY3QuaXRlbUlkLGVmZmVjdCk7XG4gICAgICB0aGlzLnNuYXBzaG90PXNuYXBzaG90O3RoaXMuaW5kZXhlZFVuaXRzPXNuYXBzaG90LnVuaXRzO3RoaXMuaW5kZXhlZEJ1aWxkaW5ncz1zbmFwc2hvdC5idWlsZGluZ3M7dGhpcy5pbmRleGVkRWZmZWN0cz1zbmFwc2hvdC5lZmZlY3RzO3RoaXMuaW5kZXhDb3VudHM9aW5kZXhDb3VudHM7XG4gICAgfVxuICAgIHRoaXMuc2FpbE1vdGlvbi51cGRhdGUoe3RpY2s6c25hcHNob3QudGljayx1bml0czp0aGlzLmFjdGl2ZUluZGV4LnNhaWxpbmd9LG5vdyk7XG4gICAgdHJhY2tVbml0RmFjaW5nKGZyYW1lLmZhY2luZyxzbmFwc2hvdCx0aGlzLmFjdGl2ZUluZGV4LmVudGl0aWVzKTtcbiAgICBmcmFtZS5jb21iYXQ/LnVwZGF0ZShzbmFwc2hvdCxub3csYmxvb2RTdXJmYWNlUmVzb2x2ZXIoc25hcHNob3QsZnJhbWUuYW5pbWF0aW9uLGZyYW1lLmZhY2luZyxmcmFtZS5tb2RlbHMsZnJhbWUucmVkdWNlZE1vdGlvbiksYXJlYXM9PnRoaXMuYWN0aXZlSW5kZXgucXVlcnlCb3VuZHNVbmlvbihhcmVhcykpO1xuICAgIGlmKHNuYXBzaG90LnRpY2shPT10aGlzLmxhc3RUaWNrKXtcbiAgICAgIHRoaXMuZmFjaW5nLnVwZGF0ZSh7dW5pdHM6dGhpcy5hY3RpdmVJbmRleC5jcmV3fSk7Y29uc3QgY29udGludW91cz1zbmFwc2hvdC50aWNrPT09dGhpcy5sYXN0VGljaysxO1xuICAgICAgZm9yKGNvbnN0IHVuaXQgb2YgdGhpcy5hY3RpdmVJbmRleC5jcmV3KWlmKHVuaXQuZGVjayl7Y29uc3Qgb2xkPXRoaXMuZGVja01vdGlvbi5nZXQodW5pdC5pZCksc3RhcnQ9Y29udGludW91cyYmb2xkPy5zaGlwSWQ9PT11bml0LmRlY2suc2hpcElkP3RoaXMuZGVja1Bvc2l0aW9uKHVuaXQsbm93KTp1bml0LmRlY2s7XG4gICAgICAgIHRoaXMuZGVja01vdGlvbi5zZXQodW5pdC5pZCx7c2hpcElkOnVuaXQuZGVjay5zaGlwSWQseDp1bml0LmRlY2sueCx5OnVuaXQuZGVjay55LGZyb21YOnN0YXJ0LngsZnJvbVk6c3RhcnQueSxhdDpub3d9KTt9XG4gICAgICB0aGlzLmxhc3RUaWNrPXNuYXBzaG90LnRpY2s7dGhpcy5hdD1ub3c7XG4gICAgfVxuICAgIGNvbnN0IHtlbnRpdGllcyxzaGlwc309dGhpcztcbiAgICBjb25zdCByaWdodD1uZXcgVEhSRUUuVmVjdG9yMygpLnNldEZyb21NYXRyaXhDb2x1bW4odGhpcy5jYW1lcmEubWF0cml4V29ybGQsMCkscm90YXRpb249dXByaWdodENyZXdSb3RhdGlvbih0aGlzLmNhbWVyYSk7XG4gICAgdGhpcy5wcm9qZWN0ZWRPcmlnaW4uc2V0KDAsMCwwKS5wcm9qZWN0KHRoaXMuY2FtZXJhKTtcbiAgICBjb25zdCBwcm9qZWN0VmVjdG9yPShkaXJlY3Rpb246e3g6bnVtYmVyO3k6bnVtYmVyO2hlaWdodD86bnVtYmVyfSk9PntcbiAgICAgIHRoaXMucHJvamVjdGVkRGlyZWN0aW9uLnNldChkaXJlY3Rpb24ueCxkaXJlY3Rpb24uaGVpZ2h0Pz8wLGRpcmVjdGlvbi55KS5wcm9qZWN0KHRoaXMuY2FtZXJhKS5zdWIodGhpcy5wcm9qZWN0ZWRPcmlnaW4pO1xuICAgICAgcmV0dXJue3g6dGhpcy5wcm9qZWN0ZWREaXJlY3Rpb24ueCpmcmFtZS52aWV3LndpZHRoLzIseTotdGhpcy5wcm9qZWN0ZWREaXJlY3Rpb24ueSpmcmFtZS52aWV3LmhlaWdodC8yfTtcbiAgICB9O1xuICAgIHRoaXMuZGlyZWN0aW9uVmlzaXRzPWZyYW1lLmFuaW1hdGlvbj8ub2JzZXJ2ZURpcmVjdGlvbnMobm93LChpZCxkaXJlY3Rpb24pPT57XG4gICAgICBjb25zdCB1bml0PXRoaXMuYWN0aXZlSW5kZXgudW5pdHMuZ2V0KGlkKTtcbiAgICAgIC8vIENyZXcgdXNlIHRoZWlyIGRlY2sgaGVhZGluZyBhcyB0aGUgZmFsbGJhY2sgZm9yIHZlcnRpY2FsIHJlbGVhc2VzLlxuICAgICAgLy8gVGhleSByZXRhaW4gdGhlIGV4YWN0IHByZS1jdWxsIGFjdGlvbiBwYXRoIGJlbG93OyBhIGdyb3VuZC1zaWRlIGxvY2tcbiAgICAgIC8vIGhlcmUgd291bGQgc3RlYWwgdGhhdCBmaXJzdCByZWxlYXNlJ3MgY29ycmVjdCBtaXJyb3IuXG4gICAgICBpZighdW5pdD8uZGVjayYmIXNoaXBzLmhhcyhpZCkpZnJhbWUuZmFjaW5nLmFjdGlvbkZhY2luZyhpZCxkaXJlY3Rpb24scHJvamVjdFZlY3Rvcik7XG4gICAgfSxmcmFtZS5yZWR1Y2VkTW90aW9uKT8/MDtcbiAgICBjb25zdCB2aXNpYmxlPSh4Om51bWJlcix5Om51bWJlcixwYWQ9MTgwKT0+eD49ZnJhbWUudmlldy54LXBhZCAmJiB5Pj1mcmFtZS52aWV3LnktcGFkICYmIHg8PWZyYW1lLnZpZXcueCtmcmFtZS52aWV3LndpZHRoL3pvb20rcGFkICYmIHk8PWZyYW1lLnZpZXcueStmcmFtZS52aWV3LmhlaWdodC96b29tK3BhZDtcbiAgICB0aGlzLnBvc2l0aW9ucy5jbGVhcigpO3RoaXMuY29tYmF0QW5jaG9ycy5jbGVhcigpO3RoaXMuc2hpcFBvc2VzLmNsZWFyKCk7dGhpcy5nYW5nd2F5U3VyZmFjZXMuY2xlYXIoKTt0aGlzLmJhdGNoZXMuYmVnaW4oKTt0aGlzLmNhcmRzLmJlZ2luKCk7dGhpcy5yZW1haW5zQ2FyZHMuYmVnaW4oKTt0aGlzLnNlbGVjdGlvbi5iZWdpbigpO1xuICAgIGZvcihjb25zdCBzaXRlIG9mIFsuLi5zbmFwc2hvdC5tZXJjZW5hcnlDYW1wcy5tYXAoc2l0ZT0+KHsuLi5zaXRlLG1vZGVsOidjYW1wJyxzY2FsZTpzaXRlLnJhZGl1cy8zMn0pKSwuLi4oc25hcHNob3Quc2hvcHM/P1tdKS5tYXAoc2l0ZT0+KHsuLi5zaXRlLG1vZGVsOidzaG9wJyxzY2FsZTpzaXRlLnJhZGl1cy8zMn0pKSwuLi4oZnJhbWUuc3Rvcnk/LnByb3BzPz9bXSkuZmlsdGVyKHNpdGU9Plsnc3RhdHVlJywnd2VsbCcsJ2JlYWNvbicsJ2NpdGFkZWwnXS5pbmNsdWRlcyhzaXRlLmtpbmQpKS5tYXAoc2l0ZT0+KHsuLi5zaXRlLGlkOmBwcm9wOiR7c2l0ZS5pZH1gLG1vZGVsOnNpdGUua2luZH0pKV0pe1xuICAgICAgY29uc3QgbW9kZWw9dGhpcy50ZW1wbGF0ZShgYnVpbGRpbmdzLyR7c2l0ZS5tb2RlbH1gLCdCdWlsZGluZycpO2lmKCFtb2RlbCljb250aW51ZTtcbiAgICAgIHRoaXMucG9zaXRpb25zLnNldChzaXRlLmlkLHt4OnNpdGUueCx5OnNpdGUueSxib2R5WTpzaXRlLnksdG9wWTpzaXRlLnktOTAqc2l0ZS5zY2FsZX0pO1xuICAgICAgaWYodmlzaWJsZShzaXRlLngsc2l0ZS55KSl7XG4gICAgICAgIGlmKGZyYW1lLnNlbGVjdGVkQ2FtcElkPT09c2l0ZS5pZCB8fCBmcmFtZS5ob3ZlcmVkSWQ9PT1zaXRlLmlkKXRoaXMuZm91bmRhdGlvbk1hcmtlcihmcmFtZSx7Li4uc2l0ZSxyYWRpdXM6J3JhZGl1cycgaW4gc2l0ZT9zaXRlLnJhZGl1czozMipzaXRlLnNjYWxlfSwnIzk2Nzc0YScsZnJhbWUuc2VsZWN0ZWRDYW1wSWQ9PT1zaXRlLmlkKTtcbiAgICAgICAgdGhpcy5iYXRjaGVzLmFkZChgc2l0ZToke3NpdGUubW9kZWx9YCxtb2RlbCx0aGlzLnBvc2Uoc2l0ZS54LHNpdGUueSwwLDAsc2l0ZS5zY2FsZSksc2l0ZS5pZCwnI2E3OWI3ZicpO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IoY29uc3QgYnVpbGRpbmcgb2Ygc25hcHNob3QuYnVpbGRpbmdzKXtcbiAgICAgIGNvbnN0IG1vZGVsS2V5PWBidWlsZGluZ3MvJHtmcmFtZS5idWlsZGluZ01vZGVscz8uW2J1aWxkaW5nLmlkXT8/YnVpbGRpbmcua2luZH1gLG1vZGVsPXRoaXMudGVtcGxhdGUobW9kZWxLZXksJ0J1aWxkaW5nJyk7aWYoIW1vZGVsKWNvbnRpbnVlO1xuICAgICAgbGV0IGJvdW5kcz10aGlzLmJvdW5kcy5nZXQobW9kZWxLZXkpO2lmKCFib3VuZHMpe2JvdW5kcz1uZXcgVEhSRUUuQm94MygpLnNldEZyb21PYmplY3QobW9kZWwpO3RoaXMuYm91bmRzLnNldChtb2RlbEtleSxib3VuZHMpO31cbiAgICAgIGNvbnN0IHNpemU9Ym91bmRzLmdldFNpemUobmV3IFRIUkVFLlZlY3RvcjMoKSksc3F1YXJlPWZvb3RwcmludFNxdWFyZShzbmFwc2hvdCxidWlsZGluZyxidWlsZGluZy5yYWRpdXMpO1xuICAgICAgY29uc3QgZXh0ZW50PXNxdWFyZT8oc3F1YXJlLnJpZ2h0LXNxdWFyZS5sZWZ0KzEpKnNxdWFyZS5jZWxsKi44ODpidWlsZGluZy5yYWRpdXMqMjtcbiAgICAgIGNvbnN0IHNjYWxlPWV4dGVudC9NYXRoLm1heChzaXplLngsc2l6ZS56KSxoZWlnaHQ9c2l6ZS55KnNjYWxlO1xuICAgICAgdGhpcy5wb3NpdGlvbnMuc2V0KGJ1aWxkaW5nLmlkLHt4OmJ1aWxkaW5nLngseTpidWlsZGluZy55LGJvZHlZOmJ1aWxkaW5nLnksdG9wWTpidWlsZGluZy55LWhlaWdodCpUSUxUfSk7XG4gICAgICBpZighdmlzaWJsZShidWlsZGluZy54LGJ1aWxkaW5nLnksaGVpZ2h0KlRJTFQrMTgwKSljb250aW51ZTtcbiAgICAgIGNvbnN0IHNlbGVjdGVkPWZyYW1lLnNlbGVjdGVkSWRzPy5oYXMoYnVpbGRpbmcuaWQpPz9mYWxzZTtcbiAgICAgIGlmKGJ1aWxkaW5nLmhwPjAgJiYgKHNlbGVjdGVkIHx8IGZyYW1lLmhvdmVyZWRJZD09PWJ1aWxkaW5nLmlkKSl0aGlzLmZvdW5kYXRpb25NYXJrZXIoZnJhbWUsYnVpbGRpbmcsdGhpcy5tYXJrZXJJbmsoZnJhbWUsYnVpbGRpbmcub3duZXIpLHNlbGVjdGVkKTtcbiAgICAgIHRoaXMuYmF0Y2hlcy5hZGQoYGJ1aWxkaW5nOiR7bW9kZWxLZXl9OiR7b3duZXJJbmsoYnVpbGRpbmcub3duZXIsIHNuYXBzaG90KX06JHtidWlsZGluZy5jb21wbGV0ZX1gLG1vZGVsLHRoaXMucG9zZShidWlsZGluZy54LGJ1aWxkaW5nLnksLWJvdW5kcy5taW4ueSpzY2FsZSwwLHNjYWxlKSxidWlsZGluZy5pZCxvd25lckluayhidWlsZGluZy5vd25lciwgc25hcHNob3QpLCFidWlsZGluZy5jb21wbGV0ZSk7XG4gICAgfVxuICAgIGNvbnN0IHJldmVhbGVkU2hpcHM9bmV3IFNldDxzdHJpbmc+KCk7XG4gICAgZm9yKGNvbnN0IGlkIG9mIGZyYW1lLnNlbGVjdGVkSWRzPz9bXSl7Y29uc3QgdW5pdD1lbnRpdGllcy5nZXQoaWQpO2lmKCF1bml0fHwhKCdvcmRlcicgaW4gdW5pdCkpY29udGludWU7aWYodW5pdC5kZWNrKXJldmVhbGVkU2hpcHMuYWRkKHVuaXQuZGVjay5zaGlwSWQpO2Vsc2UgaWYoc2hpcHMuaGFzKHVuaXQuaWQpKXJldmVhbGVkU2hpcHMuYWRkKHVuaXQuaWQpO31cbiAgICBmb3IoY29uc3Qgc2hpcCBvZiBzaGlwcy52YWx1ZXMoKSl7XG4gICAgICBjb25zdCBhdD1mcmFtZS5tb3Rpb24/LnBvc2l0aW9uKHNoaXAsbm93KT8/c2hpcCxoZWFkaW5nPWZyYW1lLm1vdGlvbj8uaGVhZGluZyhzaGlwLG5vdyk/P3NoaXAuc2FpbGluZz8uaGVhZGluZz8/MCxzY2FsZT1zaGlwU2NhbGUoc2hpcCkscHJvZmlsZT1zaGlwUHJvZmlsZShzaGlwKSE7XG4gICAgICBjb25zdCBkaXNwbGF5ZWQ9ey4uLnNoaXAseDphdC54LHk6YXQueSxzYWlsaW5nOnsuLi5zaGlwLnNhaWxpbmchLGhlYWRpbmd9fTtcbiAgICAgIHNoYXJlU2hpcFByb2ZpbGUoc2hpcCxkaXNwbGF5ZWQpO1xuICAgICAgdGhpcy5zaGlwUG9zZXMuc2V0KHNoaXAuaWQsZGlzcGxheWVkKTtcbiAgICAgIHRoaXMucG9zaXRpb25zLnNldChzaGlwLmlkLHt4OmF0LngseTphdC55LGJvZHlZOmF0LnksdG9wWTphdC55LShwcm9maWxlLmRlY2tIZWlnaHQrcHJvZmlsZS5tYXN0SGVpZ2h0KSpUSUxUfSk7XG4gICAgICBpZighdmlzaWJsZShhdC54LGF0LnkscHJvZmlsZS5sZW5ndGgqc2NhbGUrcHJvZmlsZS5tYXN0SGVpZ2h0KSljb250aW51ZTtcbiAgICAgIGNvbnN0IHNlbGVjdGVkPWZyYW1lLnNlbGVjdGVkSWRzPy5oYXMoc2hpcC5pZCk/P2ZhbHNlO1xuICAgICAgaWYoc2hpcC5ocD4wICYmIChzZWxlY3RlZCB8fCBmcmFtZS5ob3ZlcmVkSWQ9PT1zaGlwLmlkKSl0aGlzLnNlbGVjdGlvbi5odWxsKHNoaXAua2luZCxwcm9maWxlLmh1bGwsc2NhbGUsdGhpcy5wb3NlKGF0LngsYXQueSwuMTUsaGVhZGluZyxzY2FsZSksdGhpcy5tYXJrZXJJbmsoZnJhbWUsc2hpcC5vd25lciksc2VsZWN0ZWQpO1xuICAgICAgY29uc3QgcmV2ZWFsPXJldmVhbGVkU2hpcHMuaGFzKHNoaXAuaWQpO1xuICAgICAgY29uc3QgaHVsbD10aGlzLnRlbXBsYXRlKGBzaGlwcy8ke3NoaXAua2luZH1gLCdIdWxsJyk7XG4gICAgICBpZihodWxsKXtcbiAgICAgICAgY29uc3Qga2V5PWBzaGlwcy8ke3NoaXAua2luZH1gLHRyYW5zZm9ybT10aGlzLnBvc2UoYXQueCxhdC55LDAsaGVhZGluZyxzY2FsZSk7XG4gICAgICAgIGlmKCF0aGlzLnJpZ01vZGVscy5oYXMoa2V5KSl0aGlzLnJpZ01vZGVscy5zZXQoa2V5LHNoaXBSaWdNb2RlbChodWxsKSk7XG4gICAgICAgIGNvbnN0IHJpZz10aGlzLnJpZ01vZGVscy5nZXQoa2V5KTtcbiAgICAgICAgbGV0IGRpc3BsYXk9dGhpcy5yaWdQb3Nlcy5nZXQoc2hpcC5pZCk7XG4gICAgICAgIGlmKHJpZyYmZGlzcGxheT8ubW9kZWwhPT1yaWcpe2Rpc3BsYXk9e21vZGVsOnJpZyxwb3NlOnJpZy5jcmVhdGVQb3NlKCksd29ybGRSb3BlczpyaWcucm9wZXMubWFwKCgpPT5uZXcgVEhSRUUuTWF0cml4NCgpKX07dGhpcy5yaWdQb3Nlcy5zZXQoc2hpcC5pZCxkaXNwbGF5KTt9XG4gICAgICAgIGNvbnN0IGFuaW1hdGlvbj1kaXNwbGF5Py5wb3NlLnVwZGF0ZSh0aGlzLnNhaWxNb3Rpb24ucG9zZShzaGlwLG5vdykpO1xuICAgICAgICB0aGlzLmJhdGNoZXMuYWRkKGBzaGlwOiR7c2hpcC5raW5kfToke0Jvb2xlYW4ocmV2ZWFsKX1gLGh1bGwsdHJhbnNmb3JtLHNoaXAuaWQsdW5kZWZpbmVkLGZhbHNlLHJldmVhbCxhbmltYXRpb24pO1xuICAgICAgICBjb25zdCBlbnNpZ249dGhpcy50ZW1wbGF0ZShgc2hpcHMvJHtzaGlwLmtpbmR9YCwnT3duZXJGbGFnJyk7XG4gICAgICAgIGlmKGVuc2lnbil0aGlzLmJhdGNoZXMuYWRkKGBzaGlwLWVuc2lnbjoke3NoaXAua2luZH06JHtvd25lckluayhzaGlwLm93bmVyLCBzbmFwc2hvdCl9YCxlbnNpZ24sdHJhbnNmb3JtLHNoaXAuaWQsb3duZXJJbmsoc2hpcC5vd25lciwgc25hcHNob3QpKTtcbiAgICAgICAgaWYoZGlzcGxheSlmb3IobGV0IGk9MDtpPGRpc3BsYXkucG9zZS5yb3Blcy5sZW5ndGg7aSsrKXtcbiAgICAgICAgICBjb25zdCByb3BlPWRpc3BsYXkucG9zZS5yb3Blc1tpXSE7aWYoIXJvcGUudmlzaWJsZSljb250aW51ZTtcbiAgICAgICAgICBjb25zdCBtYXRyaXg9ZGlzcGxheS53b3JsZFJvcGVzW2ldIS5tdWx0aXBseU1hdHJpY2VzKHRyYW5zZm9ybSxyb3BlLm1hdHJpeCk7XG4gICAgICAgICAgdGhpcy5iYXRjaGVzLmFkZChgcmlnLXJvcGU6JHtzaGlwLmtpbmR9OiR7cm9wZS5tYXRlcmlhbH06JHtCb29sZWFuKHJldmVhbCl9YCxyb3BlLnRlbXBsYXRlLG1hdHJpeCxzaGlwLmlkLHVuZGVmaW5lZCxmYWxzZSxyZXZlYWwpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCBtYXN0cz1wcm9maWxlLm9ic3RhY2xlcy5maWx0ZXIob2JzdGFjbGU9Pm9ic3RhY2xlLnR5cGU9PT0nbWFzdCcpLG1hc3Q9bWFzdHNbc2hpcC5raW5kPT09J3NoaXBPZlRoZUxpbmUnPzE6MF07XG4gICAgICBpZihtYXN0KXtjb25zdCBtYXN0QXQ9bG9jYWxUb1dvcmxkKHsuLi5zaGlwLHg6YXQueCx5OmF0Lnksc2FpbGluZzp7Li4uc2hpcC5zYWlsaW5nISxoZWFkaW5nfX0sbWFzdCk7dGhpcy5iYXRjaGVzLmFkZChgZmxhZzoke293bmVySW5rKHNoaXAub3duZXIsIHNuYXBzaG90KX1gLHRoaXMuZmxhZyx0aGlzLnBvc2UobWFzdEF0LngsbWFzdEF0LnkscHJvZmlsZS5kZWNrSGVpZ2h0K3Byb2ZpbGUubWFzdEhlaWdodCwwLHNjYWxlLHJvdGF0aW9uKSxzaGlwLmlkLG93bmVySW5rKHNoaXAub3duZXIsIHNuYXBzaG90KSk7fVxuICAgICAgZm9yKGNvbnN0IGl0ZW0gb2YgaW5zdGFsbGVkV2VhcG9ucyhzbmFwc2hvdCxzaGlwKSl7XG4gICAgICAgIGNvbnN0IHdlYXBvbj1tb3VudGVkV2VhcG9uUG9zZShkaXNwbGF5ZWQsaXRlbSksZ3VuPXdlYXBvbiYmdGhpcy50ZW1wbGF0ZShgc2hpcHMvJHt3ZWFwb24uYXJ0fWAsJ0d1bicpO2lmKCF3ZWFwb258fCFndW4pY29udGludWU7XG4gICAgICAgIGNvbnN0IHJlY29pbD10aGlzLnJlY29pbC5nZXQoaXRlbS5pZCk7XG4gICAgICAgIGNvbnN0IGFnZT1yZWNvaWw/KHJlY29pbC5kdXJhdGlvbi1yZWNvaWwucmVtYWluaW5nKS9TSU1fVElDS1NfUEVSX1NFQ09ORDoxO1xuICAgICAgICBjb25zdCBiYWNrPXdlYXBvbi5hcnQ9PT0nZmlyZVNoaXAnPzA6NCpzY2FsZSpNYXRoLm1heCgwLGFnZTwuMDg/YWdlLy4wODoxLShhZ2UtLjA4KS8uMzgpO1xuICAgICAgICB0aGlzLmJhdGNoZXMuYWRkKGBndW46JHt3ZWFwb24uYXJ0fToke2l0ZW0uZHVyYWJpbGl0eT09PTB9YCxndW4sdGhpcy5wb3NlKHdlYXBvbi5waXZvdC54LU1hdGguY29zKHdlYXBvbi5oZWFkaW5nKSpiYWNrLHdlYXBvbi5waXZvdC55LU1hdGguc2luKHdlYXBvbi5oZWFkaW5nKSpiYWNrLHdlYXBvbi5waXZvdEhlaWdodCx3ZWFwb24uaGVhZGluZyxzY2FsZSksc2hpcC5pZCx1bmRlZmluZWQsaXRlbS5kdXJhYmlsaXR5PT09MCk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvcihjb25zdCBzb3VyY2Ugb2YgdGhpcy5zaGlwUG9zZXMudmFsdWVzKCkpe1xuICAgICAgY29uc3QgdGFyZ2V0PXNvdXJjZS5zYWlsaW5nPy5nYW5nd2F5ICYmIHRoaXMuc2hpcFBvc2VzLmdldChzb3VyY2Uuc2FpbGluZy5nYW5nd2F5LnRhcmdldElkKTtcbiAgICAgIGNvbnN0IHN1cmZhY2U9dGFyZ2V0ICYmIGdhbmd3YXlTdXJmYWNlKHNvdXJjZSx0YXJnZXQpO2lmKCFzdXJmYWNlKWNvbnRpbnVlO1xuICAgICAgdGhpcy5nYW5nd2F5U3VyZmFjZXMuc2V0KHNvdXJjZS5pZCxzdXJmYWNlKTtcbiAgICAgIGNvbnN0IHg9KHN1cmZhY2Uuc291cmNlLngrc3VyZmFjZS50YXJnZXQueCkvMix5PShzdXJmYWNlLnNvdXJjZS55K3N1cmZhY2UudGFyZ2V0LnkpLzI7XG4gICAgICBpZighdmlzaWJsZSh4LHksMTAwKSljb250aW51ZTtcbiAgICAgIGNvbnN0IGE9c2hpcFByb2ZpbGUoc291cmNlKSEuZGVja0hlaWdodCxiPXNoaXBQcm9maWxlKHRhcmdldCkhLmRlY2tIZWlnaHQ7XG4gICAgICBjb25zdCBkeD1zdXJmYWNlLnRhcmdldC54LXN1cmZhY2Uuc291cmNlLngsZHk9c3VyZmFjZS50YXJnZXQueS1zdXJmYWNlLnNvdXJjZS55O1xuICAgICAgdGhpcy5icmlkZ2VBbG9uZy5zZXQoZHgsYi1hLGR5KTtjb25zdCBzcGFuPXRoaXMuYnJpZGdlQWxvbmcubGVuZ3RoKCk7dGhpcy5icmlkZ2VBbG9uZy5ub3JtYWxpemUoKTtcbiAgICAgIHRoaXMuYnJpZGdlQWNyb3NzLnNldCgtZHksMCxkeCkubm9ybWFsaXplKCk7dGhpcy5icmlkZ2VVcC5jcm9zc1ZlY3RvcnModGhpcy5icmlkZ2VBY3Jvc3MsdGhpcy5icmlkZ2VBbG9uZykubm9ybWFsaXplKCk7XG4gICAgICBjb25zdCBtYXRyaXg9dGhpcy5wb3NlKDAsMCwwKS5tYWtlQmFzaXModGhpcy5icmlkZ2VBbG9uZyx0aGlzLmJyaWRnZVVwLHRoaXMuYnJpZGdlQWNyb3NzKS5zZXRQb3NpdGlvbih4LChhK2IpLzItMSx5KVxuICAgICAgICAuc2NhbGUodGhpcy50cmFuc2Zvcm1TY2FsZS5zZXQoc3BhbiwyLHN1cmZhY2Uud2lkdGgpKTtcbiAgICAgIHRoaXMuYmF0Y2hlcy5hZGQoYHNoaXAtZ2FuZ3dheToke3N1cmZhY2UucGhhc2V9YCx0aGlzLmdhbmd3YXksbWF0cml4LHNvdXJjZS5pZCx1bmRlZmluZWQsc3VyZmFjZS5waGFzZT09PSdkZXBsb3lpbmcnKTtcbiAgICB9XG4gICAgZm9yKGNvbnN0IGlkIG9mIHRoaXMucmlnUG9zZXMua2V5cygpKWlmKCFzaGlwcy5oYXMoaWQpKXRoaXMucmlnUG9zZXMuZGVsZXRlKGlkKTtcbiAgICBjb25zdCBsaXZlQ3Jldz1uZXcgU2V0PHN0cmluZz4oKTtcbiAgICBmb3IoY29uc3QgdW5pdCBvZiB0aGlzLmFjdGl2ZUluZGV4LnF1ZXJ5KGZyYW1lLnZpZXcpKXtcbiAgICAgIGlmKHNoaXBzLmhhcyh1bml0LmlkKXx8aXNJbkNhYmluKHVuaXQpKWNvbnRpbnVlO1xuICAgICAgbGV0IGF0PWZyYW1lLm1vdGlvbj8ucG9zaXRpb24odW5pdCxub3cpPz91bml0LGhlaWdodD0wLGZhY2luZz1mcmFtZS5mYWNpbmcuZmFjaW5nKHVuaXQuaWQpO1xuICAgICAgbGV0IGJyaWRnZTpSZXR1cm5UeXBlPHR5cGVvZiBnYW5nd2F5Q3Jld1Zpc3VhbFBvc2U+O1xuICAgICAgY29uc3Qgc2hpcD11bml0LmRlY2smJnNoaXBzLmdldCh1bml0LmRlY2suc2hpcElkKTtcbiAgICAgIGlmKHNoaXApe1xuICAgICAgICBsaXZlQ3Jldy5hZGQodW5pdC5pZCk7Y29uc3QgcGFyZW50PWZyYW1lLm1vdGlvbj8ucG9zaXRpb24oc2hpcCxub3cpPz9zaGlwLGhlYWRpbmc9ZnJhbWUubW90aW9uPy5oZWFkaW5nKHNoaXAsbm93KT8/c2hpcC5zYWlsaW5nPy5oZWFkaW5nPz8wO1xuICAgICAgICBicmlkZ2U9Z2FuZ3dheUNyZXdWaXN1YWxQb3NlKHVuaXQsdGhpcy5zaGlwUG9zZXMsdGhpcy5nYW5nd2F5U3VyZmFjZXMpO1xuICAgICAgICBpZihicmlkZ2Upe2F0PWJyaWRnZTtoZWlnaHQ9YnJpZGdlLmhlaWdodDt9XG4gICAgICAgIGVsc2V7Y29uc3QgZGVjaz10aGlzLmRlY2tQb3NpdGlvbih1bml0LG5vdyksYz1NYXRoLmNvcyhoZWFkaW5nKSxzPU1hdGguc2luKGhlYWRpbmcpO2F0PXt4OnBhcmVudC54K2RlY2sueCpjLWRlY2sueSpzLHk6cGFyZW50LnkrZGVjay54KnMrZGVjay55KmN9O2hlaWdodD1zaGlwUHJvZmlsZShzaGlwKSEuZGVja0hlaWdodDt9XG4gICAgICAgIGNvbnN0IGlkPWludGVyYWN0aW9uVGFyZ2V0SWQodW5pdC5vcmRlciksYWltaW5nPXVuaXQuYWltJiZbJ2F0dGFjaycsJ2F0dGFja01vdmUnLCdob2xkJywnYWltJywnY2FzdCddLmluY2x1ZGVzKHVuaXQub3JkZXIudHlwZSk7XG4gICAgICAgIGZhY2luZz10aGlzLmZhY2luZy5mYWNpbmcodW5pdCxoZWFkaW5nLHJpZ2h0LGFpbWluZz91bml0LmFpbTppZD9lbnRpdGllcy5nZXQoaWQpOnVuZGVmaW5lZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBtb2RlbD11bml0LnZhcmlhbnQ9PT11bmRlZmluZWQ/dW5kZWZpbmVkOmZyYW1lLm1vZGVscz8uKHVuaXQudmFyaWFudCk7XG4gICAgICBsZXQgcmF3QW5pbWF0aW9uOlVuaXRBbmltYXRpb25GcmFtZXx1bmRlZmluZWQ7XG4gICAgICBpZih1bml0LmRlY2spe1xuICAgICAgICByYXdBbmltYXRpb249ZnJhbWUucmVkdWNlZE1vdGlvbj97bW9kZTonaWRsZScsZnJhbWU6MH06ZnJhbWUuYW5pbWF0aW9uPy5mcmFtZSh1bml0LG5vdyk/P3ttb2RlOidpZGxlJyxmcmFtZTowfTtcbiAgICAgICAgZmFjaW5nPWZyYW1lLmZhY2luZy5hY3Rpb25GYWNpbmcodW5pdC5pZCxyYXdBbmltYXRpb24uZGlyZWN0aW9uPz9yYXdBbmltYXRpb24uY2FycnlEaXJlY3Rpb24scHJvamVjdFZlY3RvcixmYWNpbmcpO1xuICAgICAgfVxuICAgICAgY29uc3Qgc2NhbGU9bW9kZWw/TWF0aC5tYXgoLjcyLHVuaXQucmFkaXVzLzE4KTp1bml0R2x5cGhTY2FsZSh1bml0LnJhZGl1cyksZm9vdD1tb2RlbD8xNzpjcmVhdHVyZVNoYWRvdyh1bml0LmtpbmQpPy55Pz8xNyxib2R5WT1hdC55LWhlaWdodCpUSUxULWZvb3Qqc2NhbGU7XG4gICAgICB0aGlzLnBvc2l0aW9ucy5zZXQodW5pdC5pZCx7eDphdC54LHk6YXQueSxib2R5WSx0b3BZOmJvZHlZLTY0KnNjYWxlLGZhY2luZ30pO1xuICAgICAgaWYoIXZpc2libGUoYXQueCxib2R5WSkpY29udGludWU7XG4gICAgICByYXdBbmltYXRpb24/Pz1mcmFtZS5yZWR1Y2VkTW90aW9uP3ttb2RlOidpZGxlJyBhcyBjb25zdCxmcmFtZTowfTpmcmFtZS5hbmltYXRpb24/LmZyYW1lKHVuaXQsbm93KT8/e21vZGU6J2lkbGUnIGFzIGNvbnN0LGZyYW1lOjB9O1xuICAgICAgZmFjaW5nPWZyYW1lLmZhY2luZy5hY3Rpb25GYWNpbmcodW5pdC5pZCxyYXdBbmltYXRpb24uZGlyZWN0aW9uPz9yYXdBbmltYXRpb24uY2FycnlEaXJlY3Rpb24scHJvamVjdFZlY3RvcixmYWNpbmcpO1xuICAgICAgY29uc3QgYW5pbWF0aW9uPXByb2plY3RBY3Rpb25GcmFtZShyYXdBbmltYXRpb24sZmFjaW5nLHByb2plY3RWZWN0b3IpO3RoaXMucG9zZWQrKztcbiAgICAgIHRoaXMucG9zaXRpb25zLmdldCh1bml0LmlkKSEuZmFjaW5nPWZhY2luZztcbiAgICAgIHRoaXMuY29tYmF0QW5jaG9ycy5zZXQodW5pdC5pZCx7eDphdC54LHk6YXQueSxmbG9vcjpoZWlnaHQsZmFjaW5nLHNvdXJjZVg6dW5pdC54LHNvdXJjZVk6dW5pdC55fSk7XG4gICAgICBjb25zdCBzZWxlY3RlZD1mcmFtZS5zZWxlY3RlZElkcz8uaGFzKHVuaXQuaWQpPz9mYWxzZTtcbiAgICAgIGlmKHVuaXQuaHA+MCAmJiAoc2VsZWN0ZWQgfHwgZnJhbWUuaG92ZXJlZElkPT09dW5pdC5pZCkpe1xuICAgICAgICBsZXQgbWFya2VyPXRoaXMucG9zZShhdC54LGF0LnksaGVpZ2h0Ky4xNSk7XG4gICAgICAgIGNvbnN0IGNyb3NzaW5nPXVuaXQuZ2FuZ3dheSxzdXJmYWNlPWJyaWRnZSAmJiBjcm9zc2luZyAmJiB0aGlzLmdhbmd3YXlTdXJmYWNlcy5nZXQoY3Jvc3Npbmcuc291cmNlSWQpO1xuICAgICAgICBpZihzdXJmYWNlICYmIGNyb3NzaW5nKXtcbiAgICAgICAgICBjb25zdCBzb3VyY2U9dGhpcy5zaGlwUG9zZXMuZ2V0KGNyb3NzaW5nLnNvdXJjZUlkKSEsdGFyZ2V0PXRoaXMuc2hpcFBvc2VzLmdldChjcm9zc2luZy50YXJnZXRJZCkhO1xuICAgICAgICAgIGNvbnN0IGR4PXN1cmZhY2UudGFyZ2V0Lngtc3VyZmFjZS5zb3VyY2UueCxkeT1zdXJmYWNlLnRhcmdldC55LXN1cmZhY2Uuc291cmNlLnk7XG4gICAgICAgICAgdGhpcy5icmlkZ2VBbG9uZy5zZXQoZHgsc2hpcFByb2ZpbGUodGFyZ2V0KSEuZGVja0hlaWdodC1zaGlwUHJvZmlsZShzb3VyY2UpIS5kZWNrSGVpZ2h0LGR5KS5ub3JtYWxpemUoKTtcbiAgICAgICAgICB0aGlzLmJyaWRnZUFjcm9zcy5zZXQoLWR5LDAsZHgpLm5vcm1hbGl6ZSgpO3RoaXMuYnJpZGdlVXAuY3Jvc3NWZWN0b3JzKHRoaXMuYnJpZGdlQWNyb3NzLHRoaXMuYnJpZGdlQWxvbmcpLm5vcm1hbGl6ZSgpO1xuICAgICAgICAgIG1hcmtlcj1tYXJrZXIubWFrZUJhc2lzKHRoaXMuYnJpZGdlQWxvbmcsdGhpcy5icmlkZ2VVcCx0aGlzLmJyaWRnZUFjcm9zcylcbiAgICAgICAgICAgIC5zZXRQb3NpdGlvbihhdC54K3RoaXMuYnJpZGdlVXAueCouMTUsaGVpZ2h0K3RoaXMuYnJpZGdlVXAueSouMTUsYXQueSt0aGlzLmJyaWRnZVVwLnoqLjE1KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByYWRpdXM9KHVuaXQuYm9keVJhZGl1cz8/dW5pdC5yYWRpdXMpKzM7XG4gICAgICAgIHRoaXMuc2VsZWN0aW9uLmVsbGlwc2UobWFya2VyLHJhZGl1cyxyYWRpdXMqLjU1LHRoaXMubWFya2VySW5rKGZyYW1lLHVuaXQub3duZXIpLHNlbGVjdGVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGFwcGVhcmFuY2U9YXBwZWFyYW5jZUZvcihzbmFwc2hvdCx1bml0KTtcbiAgICAgIGNvbnN0IGRlbnNpdHk9em9vbTwuNjU/Mjo0LGtleT1gJHt1bml0UGFpbnRLZXkodW5pdC5raW5kLG93bmVySW5rKHVuaXQub3duZXIsc25hcHNob3QpLGFuaW1hdGlvbix1bml0LnZhcmlhbnQpfToke2ZhY2luZ306JHtkZW5zaXR5fToke2FwcGVhcmFuY2VLZXkoYXBwZWFyYW5jZSl9YDtcbiAgICAgIGNvbnN0IHRyYW5zZm9ybT10aGlzLnBvc2UoYXQueCxhdC55LGhlaWdodCwwLHNjYWxlLHJvdGF0aW9uKTtcbiAgICAgIGNvbnN0IHRpbGVTaXplPW1vZGVsPy5wYWludC5wYWludFNpemU/LihhbmltYXRpb24pPz9hY3Rpb25QYWludFNpemUoYW5pbWF0aW9uLHVuaXQua2luZCksYmFzZU1pcD10aGlzLnJlc2lkZW50TWlwKHRpbGVTaXplLGRlbnNpdHksdHJhbnNmb3JtLGZvb3QpO1xuICAgICAgdGhpcy5jYXJkcy5hZGQoa2V5LGRlbnNpdHksY3R4PT57XG4gICAgICAgIGN0eC5zY2FsZShmYWNpbmcsMSk7XG4gICAgICAgIGlmKG1vZGVsKW1vZGVsLnBhaW50KGN0eCxvd25lckluayh1bml0Lm93bmVyLHNuYXBzaG90KSxhbmltYXRpb24sZmFjaW5nLGFwcGVhcmFuY2UpO1xuICAgICAgICBlbHNlIHBhaW50RmlndXJlKGN0eCx1bml0LmtpbmQsb3duZXJJbmsodW5pdC5vd25lcixzbmFwc2hvdCksYW5pbWF0aW9uLGZhY2luZyxhcHBlYXJhbmNlKTtcbiAgICAgIH0sdHJhbnNmb3JtLHVuaXQuaWQsZm9vdCx0aWxlU2l6ZSwxLGJhc2VNaXApO1xuICAgIH1cbiAgICBmb3IoY29uc3QgW3NoaXBJZCxjb3Jwc2VzXSBvZiBkZWNrUmVtYWluc0J5U2hpcChzbmFwc2hvdC5jb3Jwc2VzKSl7XG4gICAgICBjb25zdCBzaGlwPXRoaXMuc2hpcFBvc2VzLmdldChzaGlwSWQpO2lmKCFzaGlwfHxzaGlwLmhwPD0wKWNvbnRpbnVlO1xuICAgICAgZm9yKGNvbnN0IGNvcnBzZSBvZiBjb3Jwc2VzKXtcbiAgICAgIGNvbnN0IHBvc2U9ZGVja1JlbWFpbnNQb3NlKGNvcnBzZSxzaGlwKTtcbiAgICAgIGlmKCFwb3NlfHwhdmlzaWJsZShwb3NlLngscG9zZS55LXBvc2UuaGVpZ2h0KlRJTFQsMTI4KSljb250aW51ZTtcbiAgICAgIGNvbnN0IG1vZGVsPWNvcnBzZS52YXJpYW50P2ZyYW1lLm1vZGVscz8uKGNvcnBzZS52YXJpYW50KTp1bmRlZmluZWQ7XG4gICAgICBjb25zdCBzY2FsZT1tb2RlbD9NYXRoLm1heCguNzIsY29ycHNlLnJhZGl1cy8xOCk6dW5pdEdseXBoU2NhbGUoY29ycHNlLnJhZGl1cyk7XG4gICAgICBjb25zdCBhcHBlYXJhbmNlPWNvcnBzZUFwcGVhcmFuY2VGb3Ioc25hcHNob3QsY29ycHNlKSxjb2xvcj1vd25lckluayhjb3Jwc2Uub3duZXIsc25hcHNob3QpLHZhcmlhbnQ9cmVtYWluc1ZhcmlhbnQoY29ycHNlLmlkKTtcbiAgICAgIGNvbnN0IGtleT1gY29ycHNlOiR7Y29ycHNlLmtpbmR9OiR7Y29ycHNlLnZhcmlhbnQ/PycnfToke2NvbG9yfToke2NvcnBzZUFwcGVhcmFuY2VLZXkoYXBwZWFyYW5jZSl9OiR7dmFyaWFudH1gO1xuICAgICAgY29uc3QgdHJhbnNmb3JtPWRlY2tSZW1haW5zTWF0cml4KHRoaXMucG9zZSgwLDAsMCkscG9zZSxzY2FsZSk7XG4gICAgICBjb25zdCBkZW5zaXR5PXpvb208LjY1PzI6NCxiYXNlTWlwPXRoaXMucmVzaWRlbnRNaXAoMTI4LGRlbnNpdHksdHJhbnNmb3JtLDAsZmFsc2UpO1xuICAgICAgdGhpcy5yZW1haW5zQ2FyZHMuYWRkKGtleSxkZW5zaXR5LGN0eD0+e1xuICAgICAgICAvLyBUaGUgZml4ZWQgc2V2ZW4tcGl4ZWwgYmFzZWxpbmUgaXMgYWxyZWFkeSBpbiB0aGUgd29ybGQgdHJhbnNmb3JtLlxuICAgICAgICBkcmF3QXRsYXNDb3Jwc2UoY3R4LGNvcnBzZS5raW5kLHt4OjAseTotN30sMSx2YXJpYW50LG1vZGVsLGNvcnBzZS52YXJpYW50LGNvbG9yLGFwcGVhcmFuY2UpO1xuICAgICAgfSx0cmFuc2Zvcm0sY29ycHNlLmlkLDAsMTI4LHJlbWFpbnNPcGFjaXR5KHNuYXBzaG90LnRpY2ssY29ycHNlLmRpZWRBdFRpY2spLGJhc2VNaXApO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IoY29uc3QgaWQgb2YgdGhpcy5kZWNrTW90aW9uLmtleXMoKSlpZighbGl2ZUNyZXcuaGFzKGlkKSl0aGlzLmRlY2tNb3Rpb24uZGVsZXRlKGlkKTtcbiAgICBmb3IoY29uc3QgZWZmZWN0IG9mIHNuYXBzaG90LmVmZmVjdHMpe1xuICAgICAgaWYoIVBIWVNJQ0FMX0VGRkVDVFMuaGFzKGVmZmVjdC50eXBlKSljb250aW51ZTtcbiAgICAgIGNvbnN0IG9yaWdpbj1mcmFtZS5wcm9qZWN0aWxlcz8ub3JpZ2luKGVmZmVjdCk7XG4gICAgICBjb25zdCBzaG90PWZsaWdodFBvc2UoZWZmZWN0LG5vdy10aGlzLmF0LG9yaWdpbik7XG4gICAgICBjb25zdCBtb2RlbD1zaG90Lmxvb2s9PT0nZmxhc2gnP3RoaXMuZmxhc2g6c2hvdC5sb29rPT09J29yYic/dGhpcy5tYWdpYzpzaG90Lmxvb2s9PT0nZmlyZSc/dGhpcy5maXJlOlsnYXJyb3cnLCdzcGVhcicsJ3N0cmVhayddLmluY2x1ZGVzKHNob3QubG9vayk/dGhpcy5ib2x0OnRoaXMuYmFsbDtcbiAgICAgIGNvbnN0IGdsb3c9c2hvdC5sb29rPT09J29yYic/c3BlbGxPcmJQYWxldHRlKGVmZmVjdC5zb3VyY2VLaW5kLGVmZmVjdC5vd25lcj9zbmFwc2hvdC5wbGF5ZXJzW2VmZmVjdC5vd25lcl0/LnJhY2U6dW5kZWZpbmVkKS5nbG93OnVuZGVmaW5lZDtcbiAgICAgIGNvbnN0IGNvbG9yPWdsb3c/YHJnYigke2dsb3cucn0sJHtnbG93Lmd9LCR7Z2xvdy5ifSlgOnVuZGVmaW5lZDtcbiAgICAgIGlmKHZpc2libGUoc2hvdC54LHNob3QueSkpe1xuICAgICAgICBsZXQgeD1zaG90LngseT1zaG90LnksaGVpZ2h0PXNob3QuaGVpZ2h0LHJvdGF0aW9uOlRIUkVFLlF1YXRlcm5pb258dW5kZWZpbmVkO1xuICAgICAgICBpZihvcmlnaW4mJm1vZGVsPT09dGhpcy5ib2x0KXtcbiAgICAgICAgICBjb25zdCBjcD1NYXRoLmNvcyhzaG90LnBpdGNoKTt0aGlzLm1pc3NpbGVEaXJlY3Rpb24uc2V0KE1hdGguY29zKHNob3QuaGVhZGluZykqY3AsTWF0aC5zaW4oc2hvdC5waXRjaCksTWF0aC5zaW4oc2hvdC5oZWFkaW5nKSpjcCk7XG4gICAgICAgICAgcm90YXRpb249dGhpcy5taXNzaWxlUm90YXRpb24uc2V0RnJvbVVuaXRWZWN0b3JzKHRoaXMubWlzc2lsZUF4aXMsdGhpcy5taXNzaWxlRGlyZWN0aW9uKTtcbiAgICAgICAgICAvLyBDb25lR2VvbWV0cnkncyBhdXRob3JlZCB0aXAgaXMgKzMgb24gaXRzIGxvY2FsIFggYXhpcy4gVGhlIHZpc3VhbFxuICAgICAgICAgIC8vIGZsaWdodCBwYXRoIGlzIHRpcC1hbmNob3JlZCBqdXN0IGxpa2UgQ2FudmFzIGFycm93RnJhbWUuXG4gICAgICAgICAgeC09dGhpcy5taXNzaWxlRGlyZWN0aW9uLngqMzt5LT10aGlzLm1pc3NpbGVEaXJlY3Rpb24ueiozO2hlaWdodC09dGhpcy5taXNzaWxlRGlyZWN0aW9uLnkqMztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmJhdGNoZXMuYWRkKGBlZmZlY3Q6JHtzaG90Lmxvb2t9OiR7Y29sb3I/PycnfWAsbW9kZWwsdGhpcy5wb3NlKHgseSxoZWlnaHQsc2hvdC5oZWFkaW5nLHNob3Quc2NhbGUscm90YXRpb24pLGVmZmVjdC5pZCxjb2xvcik7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuYmF0Y2hlcy5maW5pc2goKTt0aGlzLmNhcmRzLmZpbmlzaChyZW5kZXJlcik7dGhpcy5yZW1haW5zQ2FyZHMuZmluaXNoKHJlbmRlcmVyKTt0aGlzLnNlbGVjdGlvbi5maW5pc2goKTtcbiAgICBpZihmcmFtZS5jb21iYXQpdGhpcy5jb21iYXRJbmsudXBkYXRlKGZyYW1lLmNvbWJhdC5mcmFtZShub3cpLHRoaXMuY29tYmF0QW5jaG9ycyxmcmFtZS5yZWR1Y2VkTW90aW9uLGZyYW1lLnZpZXcpO2Vsc2UgdGhpcy5jb21iYXRJbmsuY2xlYXIoKTtcbiAgICB0aGlzLnRyYW5zZm9ybXMubGVuZ3RoPXRoaXMudHJhbnNmb3JtQ291bnQ7XG4gICAgcmVuZGVyZXIucmVuZGVyKHRoaXMuc2NlbmUsdGhpcy5jYW1lcmEpO1xuICB9XG4gIHBpY2socG9pbnQ6e3g6bnVtYmVyO3k6bnVtYmVyfSl7aWYoIXRoaXMudmlldylyZXR1cm4gdW5kZWZpbmVkO2NvbnN0IHJheT1uZXcgVEhSRUUuUmF5Y2FzdGVyKCk7cmF5LnNldEZyb21DYW1lcmEobmV3IFRIUkVFLlZlY3RvcjIocG9pbnQueC90aGlzLnZpZXcud2lkdGgqMi0xLDEtcG9pbnQueS90aGlzLnZpZXcuaGVpZ2h0KjIpLHRoaXMuY2FtZXJhKTtcbiAgICBmb3IoY29uc3QgaGl0IG9mIHJheS5pbnRlcnNlY3RPYmplY3RzKFsuLi50aGlzLmJhdGNoZXMub2JqZWN0cygpLC4uLnRoaXMuY2FyZHMub2JqZWN0cygpXSxmYWxzZSkpe1xuICAgICAgY29uc3QgbWF0ZXJpYWw9KGhpdC5vYmplY3QgYXMgVEhSRUUuTWVzaCkubWF0ZXJpYWw7Y29uc3QgZmlyc3Q9QXJyYXkuaXNBcnJheShtYXRlcmlhbCk/bWF0ZXJpYWxbaGl0LmZhY2U/Lm1hdGVyaWFsSW5kZXg/PzBdOm1hdGVyaWFsO1xuICAgICAgLy8gQSBzZWxlY3RlZCBzaGlwIGV4cG9zZXMgdGhlIGRlY2sgZm9yIGNyZXcgY29tbWFuZHMuIEl0cyB0cmFuc2x1Y2VudFxuICAgICAgLy8gY2xvdGggbXVzdCBub3QgaW50ZXJjZXB0IHRoZSB2aXNpYmxlIGNyZXcgYmVoaW5kIHRoZSBkZWZvcm1lZCBzYWlsLlxuICAgICAgaWYoZmlyc3Q/Lm5hbWUuc3RhcnRzV2l0aCgndW5ibGVhY2hlZCBzYWlsJykmJmZpcnN0LnRyYW5zcGFyZW50JiZmaXJzdC5vcGFjaXR5PC41KWNvbnRpbnVlO1xuICAgICAgaWYoaGl0Lm9iamVjdC51c2VyRGF0YS5wYWludGVkSGl0JiYhaGl0Lm9iamVjdC51c2VyRGF0YS5wYWludGVkSGl0KGhpdC5pbnN0YW5jZUlkPz8wLGhpdC51dikpY29udGludWU7XG4gICAgICBpZighcGFpbnRlZEhpdCgoZmlyc3QgYXMgVEhSRUUuTWVzaEJhc2ljTWF0ZXJpYWwpPy5tYXA/P3VuZGVmaW5lZCxoaXQudXYpKWNvbnRpbnVlO1xuICAgICAgY29uc3QgaWQ9aGl0Lm9iamVjdC51c2VyRGF0YS5pZHM/LltoaXQuaW5zdGFuY2VJZD8/MF0gYXMgc3RyaW5nfHVuZGVmaW5lZDtpZihpZCAmJiB0aGlzLnBvc2l0aW9ucy5oYXMoaWQpKXJldHVybntpZCxoZWlnaHQ6aGl0LnBvaW50Lnl9O1xuICAgIH1yZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHBsYW5lKHBvaW50Ont4Om51bWJlcjt5Om51bWJlcn0saGVpZ2h0Om51bWJlcil7cmV0dXJuIHRoaXMudmlldz9zY3JlZW5PblBsYW5lKHRoaXMuY2FtZXJhLHRoaXMudmlldyxwb2ludCxoZWlnaHQpOnVuZGVmaW5lZDt9XG4gIHByaXZhdGUgbWFya2VySW5rKGZyYW1lOldvcmxkRnJhbWUsb3duZXI6T3duZXIpe3JldHVybiBmcmFtZS52aWV3ZXI/UkVMQVRJT05fSU5LW3JlbGF0aW9uVG8oZnJhbWUuc25hcHNob3QsZnJhbWUudmlld2VyLG93bmVyKV06b3duZXJJbmsob3duZXIsZnJhbWUuc25hcHNob3QpO31cbiAgcHJpdmF0ZSBmb3VuZGF0aW9uTWFya2VyKGZyYW1lOldvcmxkRnJhbWUsYm9keTp7eDpudW1iZXI7eTpudW1iZXI7cmFkaXVzOm51bWJlcn0sY29sb3I6c3RyaW5nLHNlbGVjdGVkOmJvb2xlYW4pe1xuICAgIGNvbnN0IHNxdWFyZT1mb290cHJpbnRTcXVhcmUoZnJhbWUuc25hcHNob3QsYm9keSxib2R5LnJhZGl1cyk7XG4gICAgaWYoc3F1YXJlKXtcbiAgICAgIGNvbnN0IHdpZHRoPShzcXVhcmUucmlnaHQtc3F1YXJlLmxlZnQrMSkqc3F1YXJlLmNlbGwsZGVwdGg9KHNxdWFyZS5ib3R0b20tc3F1YXJlLnRvcCsxKSpzcXVhcmUuY2VsbDtcbiAgICAgIHRoaXMuc2VsZWN0aW9uLnJlY3RhbmdsZSh0aGlzLnBvc2Uoc3F1YXJlLmxlZnQqc3F1YXJlLmNlbGwrd2lkdGgvMixzcXVhcmUudG9wKnNxdWFyZS5jZWxsK2RlcHRoLzIsLjE1KSx3aWR0aC8yLTEsZGVwdGgvMi0xLGNvbG9yLHNlbGVjdGVkKTtcbiAgICB9ZWxzZSB0aGlzLnNlbGVjdGlvbi5lbGxpcHNlKHRoaXMucG9zZShib2R5LngsYm9keS55LC4xNSksYm9keS5yYWRpdXMrMywoYm9keS5yYWRpdXMrMykqLjU1LGNvbG9yLHNlbGVjdGVkKTtcbiAgfVxuICBkaXNwb3NlKCl7XG4gICAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5kaXNwb3NlZD10cnVlO1xuICAgIHRoaXMuZXZlbnRDYW52YXM/LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3dlYmdsY29udGV4dGxvc3QnLHRoaXMub25Db250ZXh0TG9zdCk7dGhpcy5ldmVudENhbnZhcz8ucmVtb3ZlRXZlbnRMaXN0ZW5lcignd2ViZ2xjb250ZXh0cmVzdG9yZWQnLHRoaXMub25Db250ZXh0UmVzdG9yZWQpO3RoaXMuZXZlbnRDYW52YXM9dW5kZWZpbmVkO3RoaXMucmVzZXQoKTtcbiAgICB0aGlzLnNlbGVjdGlvbi5kaXNwb3NlKCk7dGhpcy5jb21iYXRJbmsuZGlzcG9zZSgpO1xuICAgIHRoaXMud2F0ZXIuZGlzcG9zZSgpO2Zvcihjb25zdCByaWcgb2YgdGhpcy5yaWdNb2RlbHMudmFsdWVzKCkpcmlnPy5kaXNwb3NlKCk7dGhpcy5yaWdNb2RlbHMuY2xlYXIoKTtcbiAgICAvLyBEZWNvZGVkIG1vZGVscyBhcmUgdGhlIGFwcGxpY2F0aW9uIGNhY2hlIHNoYXJlZCBieSBvdGhlciBsYXllcnMgYW5kIFVJXG4gICAgLy8gcG9ydHJhaXRzLiBUaGlzIGxheWVyIG93bnMgb25seSBpbnN0YW5jZXMsIHJpZ3MsIGNhcmRzIGFuZCByZW5kZXIgdGFyZ2V0cy5cbiAgICB0aGlzLnRlbXBsYXRlcy5jbGVhcigpO3RoaXMuYm91bmRzLmNsZWFyKCk7XG4gICAgZm9yKGNvbnN0IG1lc2ggb2YgW3RoaXMuc2hhZG93LHRoaXMuYmFsbCx0aGlzLmJvbHQsdGhpcy5tYWdpYyx0aGlzLmZpcmUsdGhpcy5mbGFnLHRoaXMuZmxhc2gsdGhpcy5nYW5nd2F5XSl7bWVzaC5nZW9tZXRyeS5kaXNwb3NlKCk7KG1lc2gubWF0ZXJpYWwgYXMgVEhSRUUuTWF0ZXJpYWwpLmRpc3Bvc2UoKTt9XG4gICAgdGhpcy5zdW4uc2hhZG93LmRpc3Bvc2UoKTt0aGlzLnN1bi5zaGFkb3cubWFwPXRoaXMuc3VuLnNoYWRvdy5tYXBQYXNzPW51bGw7dGhpcy5zY2VuZS5jbGVhcigpO1xuICAgIGNvbnN0IHJlbmRlcmVyPXRoaXMucmVuZGVyZXI7dGhpcy5yZW5kZXJlcj11bmRlZmluZWQ7XG4gICAgcmVuZGVyZXI/LmRpc3Bvc2UoKTtyZW5kZXJlcj8uZm9yY2VDb250ZXh0TG9zcygpO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVEsNEJBQTJCO0FBQ25DLFNBQVEsNkJBQTRCO0FBQ3BDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsbUJBQW1CLGlCQUFpQixnQkFBZ0Isc0JBQXNCO0FBQ25GLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsMkJBQTJCO0FBRXBDLFNBQVEsb0JBQW1CLHVCQUFzQjtBQUNqRCxTQUFRLG9CQUFtQjtBQUMzQixTQUFRLGlCQUFrQztBQUMxQyxZQUFZLFdBQVc7QUFDdkIsU0FBUyxhQUFZLGdCQUFlLHlCQUF5QjtBQUM3RCxTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFtQiwwQkFBMEI7QUFDdEQsU0FBUSxtQkFBOEQ7QUFDdEUsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxpQkFBZ0Isb0JBQXVEO0FBQ2hGLFNBQVMsbUJBQWtCLDJCQUEyQjtBQUN0RCxTQUFTLHNCQUFxQixxQkFBcUI7QUFDbkQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxlQUFjLGVBQWMsMkJBQTJCO0FBQ2hFLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsWUFBVyxvQkFBb0I7QUFDeEMsU0FBUyxVQUFTLHVCQUF1QztBQUN6RCxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLGtCQUFpQix5QkFBeUI7QUFDbkQsU0FBUyxhQUFZLGtCQUFpQixXQUFVLGNBQWEsbUJBQW1CO0FBQ2hGLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsc0JBQTJDO0FBQ3BELFNBQVMsNkJBQTZCO0FBQ3RDLFNBQVMsNEJBQTRCO0FBSzlCLGFBQU0sbUJBQWlCLG9CQUFJLElBQTZDLENBQUMsZUFBYyxhQUFZLGNBQWEsYUFBYSxDQUFDO0FBQ3JJLE1BQU0sT0FBSyxLQUFLLElBQUksWUFBWSxJQUFJLEdBQUUsS0FBRyxJQUFJLE1BQU0sUUFBUSxHQUFFLEdBQUUsQ0FBQztBQUNoRSxNQUFNLHVCQUF1QixJQUF5QjtBQUFBLEVBQ3BELFlBQW9CLFFBQTRDO0FBQUMsVUFBTTtBQUFuRDtBQUFBLEVBQXFEO0FBQUEsRUFDaEUsSUFBSSxJQUFVO0FBQUMsV0FBTyxNQUFNLElBQUksRUFBRSxLQUFHLEtBQUssT0FBTyxFQUFFO0FBQUEsRUFBRTtBQUNoRTtBQUVPLGFBQU0sYUFBYTtBQUFBLEVBOEVoQixZQUFvQixVQUF1QztBQUF2QztBQUMxQixVQUFNLGtCQUFnQixLQUFLLElBQUksb0JBQW1CLEtBQUssSUFBSSxJQUFHLFVBQVUsYUFBYSxlQUFhLE1BQUksQ0FBQyxDQUFDO0FBQ3hHLFNBQUssUUFBTSxJQUFJLG1CQUFtQixLQUFLLE9BQU0sS0FBSyxJQUFJLEdBQUUsVUFBVSxhQUFhLGlCQUFpQixLQUFHLENBQUMsR0FBRSxFQUFDLGdCQUFlLENBQUM7QUFDdkgsU0FBSyxlQUFhLElBQUksbUJBQW1CLEtBQUssT0FBTSxLQUFLLElBQUksR0FBRSxVQUFVLGFBQWEsaUJBQWlCLEtBQUcsQ0FBQyxHQUFFLEVBQUMsYUFBWSxNQUFLLFlBQVcsT0FBTSxXQUFVLE1BQUksWUFBVyxPQUFNLFVBQVMsT0FBTSxhQUFZLElBQUcsZ0JBQWUsQ0FBQztBQUM3TixTQUFLLEtBQUssU0FBUyxPQUFLO0FBQ3hCLFNBQUssTUFBTSxPQUFLO0FBQVcsU0FBSyxNQUFNLFNBQVMsT0FBSztBQUNwRCxTQUFLLFFBQVEsT0FBSztBQUNsQixTQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sZ0JBQWdCLFdBQVUsV0FBVSxJQUFJLENBQUM7QUFDbEUsU0FBSyxJQUFJLGFBQVc7QUFBSyxTQUFLLElBQUksT0FBTyxRQUFRLElBQUksTUFBSyxJQUFJO0FBQUUsU0FBSyxJQUFJLE9BQU8sT0FBSztBQUFPLFNBQUssSUFBSSxPQUFPLGFBQVc7QUFDdkgsU0FBSyxNQUFNLElBQUksS0FBSyxLQUFJLEtBQUssSUFBSSxNQUFNO0FBQUUsU0FBSyxPQUFPLFNBQVMsSUFBRSxDQUFDLEtBQUssS0FBRztBQUFFLFNBQUssT0FBTyxnQkFBYztBQUFLLFNBQUssTUFBTSxJQUFJLEtBQUssTUFBTTtBQUFBLEVBQ3RJO0FBQUE7QUFBQTtBQUFBLEVBckZTLFlBQVUsSUFBSSxlQUFlLFFBQUksS0FBSyxrQkFBa0IsRUFBRSxDQUFDO0FBQUEsRUFDNUQsWUFBVSxJQUFJLHNCQUFzQjtBQUFBLEVBQ3BDLGNBQVksS0FBSztBQUFBLEVBQ2pCO0FBQUEsRUFDQSxRQUFNO0FBQUEsRUFDTixrQkFBZ0I7QUFBQSxFQUNoQixlQUFhLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDO0FBQUEsRUFDL0IsWUFBVztBQUFDLFdBQU0sRUFBQyxHQUFHLEtBQUssWUFBWSxNQUFNLEdBQUUsT0FBTSxLQUFLLE9BQU0saUJBQWdCLEtBQUssaUJBQWdCLFdBQVUsS0FBSyxVQUFVLE1BQUssY0FBYSxDQUFDLEdBQUcsS0FBSyxZQUFZLEVBQUM7QUFBQSxFQUFFO0FBQUEsRUFDL0osU0FBTyxJQUFJLE1BQU0sbUJBQW1CO0FBQUEsRUFDckMsUUFBTSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQ3RCLFFBQU0sSUFBSSxhQUFhLEtBQUssS0FBSztBQUFBLEVBQ2pDLFVBQVE7QUFBQSxFQUNSLFVBQVEsSUFBSSxhQUFhLEtBQUssS0FBSztBQUFBLEVBQ25DLFlBQVUsSUFBSSxpQkFBaUIsS0FBSyxLQUFLO0FBQUEsRUFDekMsWUFBVSxJQUFJLFVBQVUsS0FBSyxLQUFLO0FBQUEsRUFDbEMsZ0JBQWMsb0JBQUksSUFBeUI7QUFBQSxFQUNuRCxjQUFhO0FBQUMsV0FBTyxLQUFLLFVBQVUsTUFBTTtBQUFBLEVBQUU7QUFBQSxFQUNwQyxZQUFVLG9CQUFJLElBQTJCO0FBQUEsRUFDekMsU0FBTyxvQkFBSSxJQUF1QjtBQUFBLEVBQ2xDO0FBQUEsRUFDQTtBQUFBLEVBQ1IsZUFBYztBQUFDLFdBQU8sS0FBSyxhQUFhLE1BQU07QUFBQSxFQUFFO0FBQUEsRUFDaEQsWUFBVztBQUFDLFdBQU8sS0FBSyxNQUFNLE1BQU07QUFBQSxFQUFFO0FBQUEsRUFDOUIsYUFBMkIsQ0FBQztBQUFBLEVBQzVCLGlCQUFlO0FBQUEsRUFDZixvQkFBa0IsSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUNwQyxvQkFBa0IsSUFBSSxNQUFNLFdBQVc7QUFBQSxFQUN2QyxpQkFBZSxJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQ2pDLGtCQUFnQixJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQ2xDLHFCQUFtQixJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQ3JDLGtCQUFnQixJQUFJLE1BQU0sV0FBVztBQUFBLEVBQ3JDLG1CQUFpQixJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQ25DLGNBQVksSUFBSSxNQUFNLFFBQVEsR0FBRSxHQUFFLENBQUM7QUFBQSxFQUNuQyxXQUFTLG9CQUFJLElBQTRFO0FBQUEsRUFDekYsUUFBTSxvQkFBSSxJQUFpQjtBQUFBLEVBQzNCLFlBQVUsb0JBQUksSUFBaUI7QUFBQSxFQUMvQixrQkFBZ0Isb0JBQUksSUFBMkI7QUFBQSxFQUMvQyxTQUFPLG9CQUFJLElBQTRDO0FBQUEsRUFDdkQ7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0EsY0FBWTtBQUFBLEVBQ1osU0FBTyxJQUFJLGtCQUFrQjtBQUFBLEVBQzdCLGFBQVcsSUFBSSxnQkFBZ0I7QUFBQSxFQUMvQixZQUFVLG9CQUFJLElBQW1DO0FBQUEsRUFDakQsV0FBUyxvQkFBSSxJQUE2RTtBQUFBLEVBQzFGLGFBQVcsb0JBQUksSUFBa0Y7QUFBQSxFQUNqRztBQUFBLEVBQ0EsV0FBUztBQUFBLEVBQ1QsS0FBRztBQUFBLEVBQ0gsUUFBTTtBQUFBLEVBQ04sV0FBUztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVM7QUFBQSxFQUNULGNBQVk7QUFBQSxFQUNaO0FBQUEsRUFDQSxnQkFBYyxDQUFDLFVBQWM7QUFBQyxVQUFNLGVBQWU7QUFBRSxTQUFLLGNBQVk7QUFBSyxTQUFLLHdCQUF3QjtBQUFFLFNBQUssTUFBTSxjQUFjO0FBQUUsU0FBSyxhQUFhLGNBQWM7QUFBQSxFQUFFO0FBQUEsRUFDdkssb0JBQWtCLE1BQUk7QUFBQyxTQUFLLGNBQVk7QUFBQSxFQUFNO0FBQUEsRUFDOUMsTUFBSSxJQUFJLE1BQU0saUJBQWlCLFdBQVUsR0FBRztBQUFBLEVBQzVDLGVBQXlCLEVBQUMsUUFBTyxLQUFLLFFBQU8sZUFBYyxHQUFFLGdCQUFlLEVBQUM7QUFBQSxFQUM3RSxnQkFBMEIsRUFBQyxRQUFPLEtBQUssSUFBSSxPQUFPLFFBQU8sZUFBYyxHQUFFLGdCQUFlLEVBQUM7QUFBQSxFQUN6RixpQkFBZSxDQUFDLEtBQUssWUFBWTtBQUFBLEVBQ2pDLGlCQUFlLENBQUMsS0FBSyxjQUFhLEtBQUssYUFBYTtBQUFBLEVBQ3BELFdBQStCLEVBQUMsWUFBVyxHQUFFLFVBQVMsR0FBRSxNQUFLLEdBQUUsUUFBTyxJQUFJLE1BQU0sUUFBUSxHQUFFLFFBQU8sS0FBSyxlQUFjO0FBQUEsRUFDcEgsU0FBTyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sY0FBYyxHQUFFLENBQUMsR0FBRSxJQUFJLE1BQU0sZUFBZSxFQUFDLFNBQVEsS0FBRyxDQUFDLENBQUM7QUFBQSxFQUMxRixPQUFLLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxlQUFlLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBSSxNQUFNLHFCQUFxQixFQUFDLE9BQU0sV0FBVSxXQUFVLEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFDakgsT0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxLQUFJLElBQUcsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxLQUFLLEtBQUcsQ0FBQyxFQUFFLFVBQVUsSUFBRyxHQUFFLENBQUMsR0FBRSxJQUFJLE1BQU0scUJBQXFCLEVBQUMsT0FBTSxXQUFVLFdBQVUsRUFBQyxDQUFDLENBQUM7QUFBQSxFQUN4SixRQUFNLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxlQUFlLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBSSxNQUFNLGtCQUFrQixFQUFDLE9BQU0sV0FBVSxZQUFXLE1BQUssQ0FBQyxDQUFDO0FBQUEsRUFDcEgsT0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sZUFBZSxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUksTUFBTSxrQkFBa0IsRUFBQyxPQUFNLFdBQVUsWUFBVyxNQUFLLENBQUMsQ0FBQztBQUFBLEVBQ25ILE9BQUssSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLGNBQWMsSUFBRyxFQUFFLEVBQUUsVUFBVSxJQUFHLE1BQUssQ0FBQyxHQUFFLElBQUksTUFBTSxrQkFBa0IsRUFBQyxPQUFNLFdBQVUsTUFBSyxNQUFNLFlBQVcsWUFBVyxNQUFLLENBQUMsQ0FBQztBQUFBLEVBQzdKLFFBQU0sSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLGVBQWUsR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFJLE1BQU0sa0JBQWtCLEVBQUMsT0FBTSxXQUFVLFlBQVcsTUFBSyxDQUFDLENBQUM7QUFBQSxFQUNwSCxVQUFRLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxZQUFZLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBSSxNQUFNLHFCQUFxQixFQUFDLE9BQU0sV0FBVSxXQUFVLEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFDakgsY0FBWSxJQUFJLE1BQU0sUUFBUTtBQUFBLEVBQzlCLGVBQWEsSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUMvQixXQUFTLElBQUksTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUIzQiwwQkFBeUI7QUFDL0IsVUFBTSxhQUFXLG9CQUFJLElBQTBCLEdBQUUsWUFBVSxvQkFBSSxJQUFvQixHQUFFLFdBQVMsb0JBQUksSUFBbUI7QUFDckgsU0FBSyxNQUFNLFNBQVMsWUFBUTtBQUMxQixVQUFHLGtCQUFrQixNQUFNLE1BQUs7QUFDOUIsZUFBTyxRQUFRO0FBQUUsbUJBQVcsSUFBSSxPQUFPLFFBQVE7QUFDL0MsbUJBQVUsWUFBWSxNQUFNLFFBQVEsT0FBTyxRQUFRLElBQUUsT0FBTyxXQUFTLENBQUMsT0FBTyxRQUFRLEVBQUUsV0FBVSxJQUFJLFFBQVE7QUFDN0csWUFBRyxPQUFPLG9CQUFvQixXQUFVLElBQUksT0FBTyxtQkFBbUI7QUFDdEUsWUFBRyxPQUFPLHVCQUF1QixXQUFVLElBQUksT0FBTyxzQkFBc0I7QUFBQSxNQUM5RTtBQUNBLFVBQUcsa0JBQWtCLE1BQU0sb0JBQWtCLGtCQUFrQixNQUFNLGNBQVksa0JBQWtCLE1BQU0sV0FBVTtBQUFDLGVBQU8sT0FBTyxRQUFRO0FBQUUsZUFBTyxPQUFPLE1BQUksT0FBTyxPQUFPLFVBQVE7QUFBQSxNQUFLO0FBQUEsSUFDM0wsQ0FBQztBQUNELGVBQVUsWUFBWSxXQUFVO0FBQzlCLGlCQUFVLFNBQVMsT0FBTyxPQUFPLFFBQVEsRUFBRSxLQUFHLGlCQUFpQixNQUFNLFFBQVEsVUFBUyxJQUFJLEtBQUs7QUFDL0YsVUFBRyxvQkFBb0IsTUFBTSxlQUFlLFlBQVUsV0FBVyxPQUFPLE9BQU8sU0FBUyxRQUFRLEdBQUU7QUFDaEcsY0FBTSxTQUFPLE1BQU0sUUFBUSxRQUFRLEtBQUssSUFBRSxRQUFRLFFBQU0sQ0FBQyxRQUFRLEtBQUs7QUFBRSxtQkFBVSxTQUFTLE9BQU8sS0FBRyxpQkFBaUIsTUFBTSxRQUFRLFVBQVMsSUFBSSxLQUFLO0FBQUEsTUFDeEo7QUFDQSxlQUFTLFFBQVE7QUFBQSxJQUNuQjtBQUNBLGVBQVUsWUFBWSxXQUFXLFVBQVMsUUFBUTtBQUNsRCxlQUFVLFdBQVcsU0FBUyxTQUFRLFFBQVE7QUFBQSxFQUNoRDtBQUFBLEVBQ0EsT0FBTyxPQUFPLFFBQXlCLFNBQStCO0FBQ3BFLFVBQU0sV0FBUyxJQUFJLE1BQU0sY0FBYyxFQUFDLFFBQU8sU0FBUSxPQUFNLE1BQUssV0FBVSxLQUFJLENBQUM7QUFDakYsYUFBUyxjQUFjLEdBQUUsQ0FBQztBQUFFLGFBQVMsVUFBVSxVQUFRO0FBQUssYUFBUyxVQUFVLE9BQUssTUFBTTtBQUMxRixhQUFTLGNBQVksTUFBTTtBQUFzQixhQUFTLHNCQUFvQjtBQUM5RSxVQUFNLFFBQU0sSUFBSSxhQUFhLFFBQVE7QUFBRSxVQUFNLGNBQVk7QUFDekQsV0FBTyxpQkFBaUIsb0JBQW1CLE1BQU0sYUFBYTtBQUFFLFdBQU8saUJBQWlCLHdCQUF1QixNQUFNLGlCQUFpQjtBQUN0SSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsTUFBTSxRQUFRLFVBQXNCLE9BQW9CLFFBQXdCLENBQUMsR0FBRTtBQUFDLFFBQUcsS0FBSyxTQUFTO0FBQU8sVUFBTSxLQUFLLFFBQVEsUUFBUSxVQUFRLFVBQVEsaUJBQWUsQ0FBQyxHQUFHLGtCQUFrQixRQUFRLEdBQUUsR0FBRyxNQUFNLElBQUksVUFBTSxhQUFhLElBQUksRUFBRSxDQUFDLEdBQUUsS0FBSztBQUFFLFFBQUcsQ0FBQyxLQUFLLFNBQVMsd0JBQXVCO0FBQUEsRUFBRTtBQUFBLEVBQ3pSLFNBQVMsS0FBVyxNQUFZO0FBQUMsVUFBTSxLQUFHLEdBQUcsR0FBRyxJQUFJLElBQUk7QUFBRyxRQUFJLFFBQU0sS0FBSyxVQUFVLElBQUksRUFBRTtBQUFFLFFBQUcsQ0FBQyxPQUFNO0FBQUMsY0FBTSxLQUFLLFFBQVEsVUFBVSxLQUFJLElBQUk7QUFBRSxVQUFHLE1BQU0sTUFBSyxVQUFVLElBQUksSUFBRyxLQUFLO0FBQUEsSUFBRTtBQUFDLFdBQU87QUFBQSxFQUFNO0FBQUEsRUFDMU0sUUFBTztBQUFDLFNBQUssV0FBUztBQUFHLFNBQUssV0FBUztBQUFVLFNBQUssZUFBYSxLQUFLLG1CQUFpQixLQUFLLGlCQUFlO0FBQVUsU0FBSyxjQUFZO0FBQUcsU0FBSyxPQUFLO0FBQVUsU0FBSyxlQUFhO0FBQVUsU0FBSyxVQUFVLE1BQU07QUFBRSxTQUFLLGNBQVksS0FBSztBQUFVLFNBQUssVUFBVSxNQUFNO0FBQUUsU0FBSyxjQUFjLE1BQU07QUFBRSxTQUFLLFVBQVUsTUFBTTtBQUFFLFNBQUssV0FBUyxvQkFBSSxJQUFJO0FBQUUsU0FBSyxNQUFNLE1BQU07QUFBRSxTQUFLLFVBQVUsTUFBTTtBQUFFLFNBQUssZ0JBQWdCLE1BQU07QUFBRSxTQUFLLE9BQU8sTUFBTTtBQUFFLFNBQUssV0FBVyxNQUFNO0FBQUUsU0FBSyxTQUFPLElBQUksa0JBQWtCO0FBQUUsU0FBSyxXQUFXLE1BQU07QUFBRSxTQUFLLFNBQVMsTUFBTTtBQUFFLFNBQUssV0FBVyxTQUFPO0FBQUUsU0FBSyxpQkFBZTtBQUFFLFNBQUssUUFBUSxRQUFRO0FBQUUsU0FBSyxNQUFNLFFBQVE7QUFBRSxTQUFLLGFBQWEsUUFBUTtBQUFFLFNBQUssVUFBVSxNQUFNO0FBQUUsU0FBSyxNQUFNLFFBQVEsTUFBUztBQUFBLEVBQUU7QUFBQSxFQUM1ckIsa0JBQWtCLElBQWtDO0FBQzFELFVBQU0sUUFBTSxLQUFLLGNBQWEsT0FBSyxLQUFLLFlBQVksTUFBTSxJQUFJLEVBQUU7QUFDaEUsUUFBRyxDQUFDLFNBQU8sQ0FBQyxRQUFNLEtBQUssUUFBTSxVQUFVLElBQUksS0FBRyxZQUFZLElBQUksRUFBRSxRQUFPO0FBQ3ZFLFVBQU0sS0FBRyxNQUFNLFFBQVEsU0FBUyxNQUFLLE1BQU0sR0FBRyxLQUFHLE1BQUssUUFBTSxLQUFLLFlBQVUsU0FBVSxTQUFVLE1BQU0sU0FBUyxLQUFLLE9BQU87QUFDMUgsVUFBTSxRQUFNLFFBQU0sS0FBSyxJQUFJLE1BQUksS0FBSyxTQUFPLEVBQUUsSUFBRSxlQUFlLEtBQUssTUFBTSxHQUFFLE9BQUssUUFBTSxLQUFHLGVBQWUsS0FBSyxJQUFJLEdBQUcsS0FBRyxJQUFHLFFBQU0sR0FBRyxJQUFFLE9BQUs7QUFDMUksVUFBTSxTQUFPLEVBQUMsR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLEdBQUUsT0FBTSxNQUFLLFFBQU0sS0FBRyxPQUFNLFFBQU8sTUFBTSxPQUFPLGNBQWMsRUFBRSxFQUFDO0FBQzNGLFNBQUssVUFBVSxJQUFJLElBQUcsTUFBTTtBQUFFLFdBQU87QUFBQSxFQUN2QztBQUFBLEVBQ1EsS0FBSyxHQUFTLEdBQVMsUUFBYyxVQUFRLEdBQUUsUUFBTSxHQUFFLFVBQTJCO0FBQ3hGLFFBQUksU0FBTyxLQUFLLFdBQVcsS0FBSyxjQUFjO0FBQzlDLFFBQUcsQ0FBQyxRQUFPO0FBQUMsZUFBTyxJQUFJLE1BQU0sUUFBUTtBQUFFLFdBQUssV0FBVyxLQUFLLGNBQWMsSUFBRTtBQUFBLElBQU87QUFDbkYsU0FBSztBQUNMLFdBQU8sT0FBTyxRQUFRLEtBQUssa0JBQWtCLElBQUksR0FBRSxRQUFPLENBQUMsR0FBRSxZQUFVLEtBQUssa0JBQWtCLGlCQUFpQixJQUFHLENBQUMsT0FBTyxHQUFFLEtBQUssZUFBZSxVQUFVLEtBQUssQ0FBQztBQUFBLEVBQ2xLO0FBQUEsRUFDUSxZQUFZLFVBQWdCLFNBQWUsUUFBcUIsTUFBWSxjQUFZLE1BQUs7QUFDbkcsVUFBTSxRQUFNLEtBQUs7QUFBUyxVQUFNLGFBQVcsV0FBUztBQUFRLFVBQU0sV0FBUztBQUFTLFVBQU0sU0FBTztBQUFPLFVBQU0sT0FBSztBQUFLLFVBQU0sU0FBTyxjQUFZLEtBQUssaUJBQWUsS0FBSztBQUMxSyxVQUFNLE9BQUssWUFBWSxLQUFLO0FBQUUsU0FBSyxhQUFhLElBQUk7QUFBSyxXQUFPO0FBQUEsRUFDbEU7QUFBQSxFQUNRLGFBQWEsTUFBVSxLQUFXO0FBQ3hDLFVBQU0sUUFBTSxLQUFLLFdBQVcsSUFBSSxLQUFLLEVBQUU7QUFHdkMsUUFBRyxDQUFDLFNBQVMsTUFBTSxXQUFTLEtBQUssS0FBTSxPQUFPLFFBQU8sS0FBSztBQUMxRCxVQUFNLElBQUUsS0FBSyxJQUFJLEdBQUUsS0FBSyxJQUFJLElBQUcsTUFBSSxNQUFNLE1BQUksdUJBQXFCLEdBQUksQ0FBQztBQUN2RSxXQUFNLEVBQUMsR0FBRSxNQUFNLFNBQU8sTUFBTSxJQUFFLE1BQU0sU0FBTyxHQUFFLEdBQUUsTUFBTSxTQUFPLE1BQU0sSUFBRSxNQUFNLFNBQU8sRUFBQztBQUFBLEVBQ3BGO0FBQUEsRUFDQSxLQUFLLE9BQWlCO0FBQ3BCLFVBQU0sV0FBUyxLQUFLO0FBQVMsUUFBRyxLQUFLLFlBQVUsS0FBSyxlQUFhLENBQUMsU0FBUztBQUMzRSxTQUFLO0FBQVEsU0FBSyxpQkFBZTtBQUFFLFNBQUssT0FBSyxNQUFNO0FBQUssU0FBSyxlQUFhO0FBQU0sU0FBSyxRQUFNO0FBQUUsU0FBSyxhQUFhLEtBQUssQ0FBQztBQUNySCxVQUFNLEVBQUMsVUFBUyxJQUFHLElBQUU7QUFBTSxVQUFNLE9BQUssTUFBTSxLQUFLLFFBQU07QUFDdkQsVUFBTSxhQUFXLEtBQUssSUFBSSxrQkFBaUIsQ0FBQyxHQUFFLFdBQVMsR0FBRyxNQUFNLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksVUFBVTtBQUM3RyxRQUFHLGFBQVcsS0FBSyxVQUFTO0FBQUMsZUFBUyxjQUFjLFVBQVU7QUFBRSxlQUFTLFFBQVEsTUFBTSxLQUFLLE9BQU0sTUFBTSxLQUFLLFFBQU8sS0FBSztBQUFFLFdBQUssV0FBUztBQUFBLElBQVM7QUFDbEosU0FBSyxhQUFhLGdCQUFjLEtBQUssTUFBTSxNQUFNLEtBQUssUUFBTSxVQUFVO0FBQUUsU0FBSyxhQUFhLGlCQUFlLEtBQUssTUFBTSxNQUFNLEtBQUssU0FBTyxVQUFVO0FBQ2hKLHlCQUFxQixLQUFLLFFBQU8sTUFBTSxJQUFJO0FBRzNDLFNBQUssTUFBTSxRQUFRLFNBQVMsSUFBSSxPQUFPO0FBQ3ZDLFNBQUssTUFBTSxPQUFPLEtBQUksTUFBTSxhQUFhO0FBQ3pDLFVBQU0sS0FBRyxNQUFNLEtBQUssSUFBRSxNQUFNLEtBQUssU0FBTyxJQUFFLE9BQU0sS0FBRyxNQUFNLEtBQUssSUFBRSxNQUFNLEtBQUssVUFBUSxJQUFFLE9BQU0sU0FBTyxLQUFLLElBQUksTUFBTSxLQUFLLE9BQU0sTUFBTSxLQUFLLE1BQU0sSUFBRSxPQUFLO0FBQ3BKLFNBQUssT0FBTyxTQUFTLElBQUksSUFBRyxNQUFJLEVBQUU7QUFBRSxTQUFLLE9BQU8sTUFBTSxJQUFJLFFBQU8sUUFBTyxDQUFDO0FBQ3pFLFNBQUssSUFBSSxTQUFTLElBQUksS0FBRyxLQUFJLEtBQUksS0FBRyxHQUFHO0FBQUUsU0FBSyxJQUFJLE9BQU8sU0FBUyxJQUFJLElBQUcsR0FBRSxFQUFFO0FBQzdFLFVBQU0sU0FBTyxLQUFLLElBQUksT0FBTztBQUFPLFdBQU8sT0FBSyxPQUFPLFNBQU8sQ0FBQyxTQUFPO0FBQUUsV0FBTyxRQUFNLE9BQU8sTUFBSSxTQUFPO0FBQUUsV0FBTyxPQUFLO0FBQUUsV0FBTyxNQUFJO0FBQUssV0FBTyx1QkFBdUI7QUFHckssU0FBSyxJQUFJLGtCQUFrQixNQUFLLEtBQUs7QUFBRSxTQUFLLElBQUksT0FBTyxrQkFBa0IsTUFBSyxLQUFLO0FBQUUsU0FBSyxJQUFJLE9BQU8sZUFBZSxLQUFLLEdBQUc7QUFDNUgsU0FBSyxjQUFjLGdCQUFjLEtBQUssSUFBSSxPQUFPLFFBQVE7QUFBRSxTQUFLLGNBQWMsaUJBQWUsS0FBSyxJQUFJLE9BQU8sUUFBUTtBQUNySCxVQUFNLGFBQWEsT0FBTyxVQUFTLE1BQU0sUUFBTyxRQUFJLE1BQU0sT0FBTyxjQUFjLEVBQUUsQ0FBQztBQUNsRixVQUFNLFdBQVcsT0FBTyxVQUFTLEtBQUksTUFBTSxPQUFPLFdBQVc7QUFBRSxVQUFNLFFBQVEsT0FBTyxVQUFTLEdBQUc7QUFDaEcsU0FBSyxjQUFZLE1BQU0sYUFBVyxLQUFLO0FBQVUsU0FBSyxZQUFZLE9BQU8sVUFBUyxNQUFNLE1BQU07QUFDOUYsU0FBSyxXQUFTLEtBQUssWUFBWTtBQUkvQixVQUFNLGNBQVksR0FBRyxTQUFTLE1BQU0sTUFBTSxJQUFJLFNBQVMsVUFBVSxNQUFNLElBQUksU0FBUyxRQUFRLE1BQU07QUFDbEcsUUFBRyxhQUFXLEtBQUssWUFBVSxTQUFTLFNBQU8sS0FBSyxZQUFVLFNBQVMsVUFBUSxLQUFLLGdCQUFjLFNBQVMsY0FBWSxLQUFLLG9CQUFrQixTQUFTLFlBQVUsS0FBSyxrQkFBZ0IsZ0JBQWMsS0FBSyxhQUFZO0FBQ2pOLFdBQUssTUFBTSxNQUFNO0FBQUUsV0FBSyxPQUFPLE1BQU07QUFDckMsaUJBQVUsUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFLLE1BQU0sSUFBSSxLQUFLLElBQUcsSUFBSTtBQUNwRSxpQkFBVSxVQUFVLFNBQVMsUUFBUSxLQUFHLE9BQU8sU0FBTyxpQkFBZSxPQUFPLFVBQVEsQ0FBQyxLQUFLLE9BQU8sSUFBSSxPQUFPLE1BQU0sRUFBRSxNQUFLLE9BQU8sSUFBSSxPQUFPLFFBQU8sTUFBTTtBQUN4SixXQUFLLFdBQVM7QUFBUyxXQUFLLGVBQWEsU0FBUztBQUFNLFdBQUssbUJBQWlCLFNBQVM7QUFBVSxXQUFLLGlCQUFlLFNBQVM7QUFBUSxXQUFLLGNBQVk7QUFBQSxJQUN6SjtBQUNBLFNBQUssV0FBVyxPQUFPLEVBQUMsTUFBSyxTQUFTLE1BQUssT0FBTSxLQUFLLFlBQVksUUFBTyxHQUFFLEdBQUc7QUFDOUUsb0JBQWdCLE1BQU0sUUFBTyxVQUFTLEtBQUssWUFBWSxRQUFRO0FBQy9ELFVBQU0sUUFBUSxPQUFPLFVBQVMsS0FBSSxxQkFBcUIsVUFBUyxNQUFNLFdBQVUsTUFBTSxRQUFPLE1BQU0sUUFBTyxNQUFNLGFBQWEsR0FBRSxXQUFPLEtBQUssWUFBWSxpQkFBaUIsS0FBSyxDQUFDO0FBQzlLLFFBQUcsU0FBUyxTQUFPLEtBQUssVUFBUztBQUMvQixXQUFLLE9BQU8sT0FBTyxFQUFDLE9BQU0sS0FBSyxZQUFZLEtBQUksQ0FBQztBQUFFLFlBQU0sYUFBVyxTQUFTLFNBQU8sS0FBSyxXQUFTO0FBQ2pHLGlCQUFVLFFBQVEsS0FBSyxZQUFZLEtBQUssS0FBRyxLQUFLLE1BQUs7QUFBQyxjQUFNLE1BQUksS0FBSyxXQUFXLElBQUksS0FBSyxFQUFFLEdBQUUsUUFBTSxjQUFZLEtBQUssV0FBUyxLQUFLLEtBQUssU0FBTyxLQUFLLGFBQWEsTUFBSyxHQUFHLElBQUUsS0FBSztBQUM3SyxhQUFLLFdBQVcsSUFBSSxLQUFLLElBQUcsRUFBQyxRQUFPLEtBQUssS0FBSyxRQUFPLEdBQUUsS0FBSyxLQUFLLEdBQUUsR0FBRSxLQUFLLEtBQUssR0FBRSxPQUFNLE1BQU0sR0FBRSxPQUFNLE1BQU0sR0FBRSxJQUFHLElBQUcsQ0FBQztBQUFBLE1BQUU7QUFDeEgsV0FBSyxXQUFTLFNBQVM7QUFBSyxXQUFLLEtBQUc7QUFBQSxJQUN0QztBQUNBLFVBQU0sRUFBQyxVQUFTLE1BQUssSUFBRTtBQUN2QixVQUFNLFFBQU0sSUFBSSxNQUFNLFFBQVEsRUFBRSxvQkFBb0IsS0FBSyxPQUFPLGFBQVksQ0FBQyxHQUFFLFdBQVMsb0JBQW9CLEtBQUssTUFBTTtBQUN2SCxTQUFLLGdCQUFnQixJQUFJLEdBQUUsR0FBRSxDQUFDLEVBQUUsUUFBUSxLQUFLLE1BQU07QUFDbkQsVUFBTSxnQkFBYyxDQUFDLGNBQStDO0FBQ2xFLFdBQUssbUJBQW1CLElBQUksVUFBVSxHQUFFLFVBQVUsVUFBUSxHQUFFLFVBQVUsQ0FBQyxFQUFFLFFBQVEsS0FBSyxNQUFNLEVBQUUsSUFBSSxLQUFLLGVBQWU7QUFDdEgsYUFBTSxFQUFDLEdBQUUsS0FBSyxtQkFBbUIsSUFBRSxNQUFNLEtBQUssUUFBTSxHQUFFLEdBQUUsQ0FBQyxLQUFLLG1CQUFtQixJQUFFLE1BQU0sS0FBSyxTQUFPLEVBQUM7QUFBQSxJQUN4RztBQUNBLFNBQUssa0JBQWdCLE1BQU0sV0FBVyxrQkFBa0IsS0FBSSxDQUFDLElBQUcsY0FBWTtBQUMxRSxZQUFNLE9BQUssS0FBSyxZQUFZLE1BQU0sSUFBSSxFQUFFO0FBSXhDLFVBQUcsQ0FBQyxNQUFNLFFBQU0sQ0FBQyxNQUFNLElBQUksRUFBRSxFQUFFLE9BQU0sT0FBTyxhQUFhLElBQUcsV0FBVSxhQUFhO0FBQUEsSUFDckYsR0FBRSxNQUFNLGFBQWEsS0FBRztBQUN4QixVQUFNLFVBQVEsQ0FBQyxHQUFTLEdBQVMsTUFBSSxRQUFNLEtBQUcsTUFBTSxLQUFLLElBQUUsT0FBTyxLQUFHLE1BQU0sS0FBSyxJQUFFLE9BQU8sS0FBRyxNQUFNLEtBQUssSUFBRSxNQUFNLEtBQUssUUFBTSxPQUFLLE9BQU8sS0FBRyxNQUFNLEtBQUssSUFBRSxNQUFNLEtBQUssU0FBTyxPQUFLO0FBQzdLLFNBQUssVUFBVSxNQUFNO0FBQUUsU0FBSyxjQUFjLE1BQU07QUFBRSxTQUFLLFVBQVUsTUFBTTtBQUFFLFNBQUssZ0JBQWdCLE1BQU07QUFBRSxTQUFLLFFBQVEsTUFBTTtBQUFFLFNBQUssTUFBTSxNQUFNO0FBQUUsU0FBSyxhQUFhLE1BQU07QUFBRSxTQUFLLFVBQVUsTUFBTTtBQUM3TCxlQUFVLFFBQVEsQ0FBQyxHQUFHLFNBQVMsZUFBZSxJQUFJLENBQUFBLFdBQU8sRUFBQyxHQUFHQSxPQUFLLE9BQU0sUUFBTyxPQUFNQSxNQUFLLFNBQU8sR0FBRSxFQUFFLEdBQUUsSUFBSSxTQUFTLFNBQU8sQ0FBQyxHQUFHLElBQUksQ0FBQUEsV0FBTyxFQUFDLEdBQUdBLE9BQUssT0FBTSxRQUFPLE9BQU1BLE1BQUssU0FBTyxHQUFFLEVBQUUsR0FBRSxJQUFJLE1BQU0sT0FBTyxTQUFPLENBQUMsR0FBRyxPQUFPLENBQUFBLFVBQU0sQ0FBQyxVQUFTLFFBQU8sVUFBUyxTQUFTLEVBQUUsU0FBU0EsTUFBSyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUFBLFdBQU8sRUFBQyxHQUFHQSxPQUFLLElBQUcsUUFBUUEsTUFBSyxFQUFFLElBQUcsT0FBTUEsTUFBSyxLQUFJLEVBQUUsQ0FBQyxHQUFFO0FBQ3RWLFlBQU0sUUFBTSxLQUFLLFNBQVMsYUFBYSxLQUFLLEtBQUssSUFBRyxVQUFVO0FBQUUsVUFBRyxDQUFDLE1BQU07QUFDMUUsV0FBSyxVQUFVLElBQUksS0FBSyxJQUFHLEVBQUMsR0FBRSxLQUFLLEdBQUUsR0FBRSxLQUFLLEdBQUUsT0FBTSxLQUFLLEdBQUUsTUFBSyxLQUFLLElBQUUsS0FBRyxLQUFLLE1BQUssQ0FBQztBQUNyRixVQUFHLFFBQVEsS0FBSyxHQUFFLEtBQUssQ0FBQyxHQUFFO0FBQ3hCLFlBQUcsTUFBTSxtQkFBaUIsS0FBSyxNQUFNLE1BQU0sY0FBWSxLQUFLLEdBQUcsTUFBSyxpQkFBaUIsT0FBTSxFQUFDLEdBQUcsTUFBSyxRQUFPLFlBQVksT0FBSyxLQUFLLFNBQU8sS0FBRyxLQUFLLE1BQUssR0FBRSxXQUFVLE1BQU0sbUJBQWlCLEtBQUssRUFBRTtBQUMvTCxhQUFLLFFBQVEsSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFHLE9BQU0sS0FBSyxLQUFLLEtBQUssR0FBRSxLQUFLLEdBQUUsR0FBRSxHQUFFLEtBQUssS0FBSyxHQUFFLEtBQUssSUFBRyxTQUFTO0FBQUEsTUFDdkc7QUFBQSxJQUNGO0FBQ0EsZUFBVSxZQUFZLFNBQVMsV0FBVTtBQUN2QyxZQUFNLFdBQVMsYUFBYSxNQUFNLGlCQUFpQixTQUFTLEVBQUUsS0FBRyxTQUFTLElBQUksSUFBRyxRQUFNLEtBQUssU0FBUyxVQUFTLFVBQVU7QUFBRSxVQUFHLENBQUMsTUFBTTtBQUNwSSxVQUFJLFNBQU8sS0FBSyxPQUFPLElBQUksUUFBUTtBQUFFLFVBQUcsQ0FBQyxRQUFPO0FBQUMsaUJBQU8sSUFBSSxNQUFNLEtBQUssRUFBRSxjQUFjLEtBQUs7QUFBRSxhQUFLLE9BQU8sSUFBSSxVQUFTLE1BQU07QUFBQSxNQUFFO0FBQy9ILFlBQU0sT0FBSyxPQUFPLFFBQVEsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFFLFNBQU8sZ0JBQWdCLFVBQVMsVUFBUyxTQUFTLE1BQU07QUFDdkcsWUFBTUMsVUFBTyxVQUFRLE9BQU8sUUFBTSxPQUFPLE9BQUssS0FBRyxPQUFPLE9BQUssT0FBSSxTQUFTLFNBQU87QUFDakYsWUFBTSxRQUFNQSxVQUFPLEtBQUssSUFBSSxLQUFLLEdBQUUsS0FBSyxDQUFDLEdBQUUsU0FBTyxLQUFLLElBQUU7QUFDekQsV0FBSyxVQUFVLElBQUksU0FBUyxJQUFHLEVBQUMsR0FBRSxTQUFTLEdBQUUsR0FBRSxTQUFTLEdBQUUsT0FBTSxTQUFTLEdBQUUsTUFBSyxTQUFTLElBQUUsU0FBTyxLQUFJLENBQUM7QUFDdkcsVUFBRyxDQUFDLFFBQVEsU0FBUyxHQUFFLFNBQVMsR0FBRSxTQUFPLE9BQUssR0FBRyxFQUFFO0FBQ25ELFlBQU0sV0FBUyxNQUFNLGFBQWEsSUFBSSxTQUFTLEVBQUUsS0FBRztBQUNwRCxVQUFHLFNBQVMsS0FBRyxNQUFNLFlBQVksTUFBTSxjQUFZLFNBQVMsSUFBSSxNQUFLLGlCQUFpQixPQUFNLFVBQVMsS0FBSyxVQUFVLE9BQU0sU0FBUyxLQUFLLEdBQUUsUUFBUTtBQUNsSixXQUFLLFFBQVEsSUFBSSxZQUFZLFFBQVEsSUFBSSxTQUFTLFNBQVMsT0FBTyxRQUFRLENBQUMsSUFBSSxTQUFTLFFBQVEsSUFBRyxPQUFNLEtBQUssS0FBSyxTQUFTLEdBQUUsU0FBUyxHQUFFLENBQUMsT0FBTyxJQUFJLElBQUUsT0FBTSxHQUFFLEtBQUssR0FBRSxTQUFTLElBQUcsU0FBUyxTQUFTLE9BQU8sUUFBUSxHQUFFLENBQUMsU0FBUyxRQUFRO0FBQUEsSUFDek87QUFDQSxVQUFNLGdCQUFjLG9CQUFJLElBQVk7QUFDcEMsZUFBVSxNQUFNLE1BQU0sZUFBYSxDQUFDLEdBQUU7QUFBQyxZQUFNLE9BQUssU0FBUyxJQUFJLEVBQUU7QUFBRSxVQUFHLENBQUMsUUFBTSxFQUFFLFdBQVcsTUFBTTtBQUFTLFVBQUcsS0FBSyxLQUFLLGVBQWMsSUFBSSxLQUFLLEtBQUssTUFBTTtBQUFBLGVBQVUsTUFBTSxJQUFJLEtBQUssRUFBRSxFQUFFLGVBQWMsSUFBSSxLQUFLLEVBQUU7QUFBQSxJQUFFO0FBQ2hOLGVBQVUsUUFBUSxNQUFNLE9BQU8sR0FBRTtBQUMvQixZQUFNLEtBQUcsTUFBTSxRQUFRLFNBQVMsTUFBSyxHQUFHLEtBQUcsTUFBSyxVQUFRLE1BQU0sUUFBUSxRQUFRLE1BQUssR0FBRyxLQUFHLEtBQUssU0FBUyxXQUFTLEdBQUUsUUFBTSxVQUFVLElBQUksR0FBRSxVQUFRLFlBQVksSUFBSTtBQUNoSyxZQUFNLFlBQVUsRUFBQyxHQUFHLE1BQUssR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLEdBQUUsU0FBUSxFQUFDLEdBQUcsS0FBSyxTQUFTLFFBQU8sRUFBQztBQUN6RSx1QkFBaUIsTUFBSyxTQUFTO0FBQy9CLFdBQUssVUFBVSxJQUFJLEtBQUssSUFBRyxTQUFTO0FBQ3BDLFdBQUssVUFBVSxJQUFJLEtBQUssSUFBRyxFQUFDLEdBQUUsR0FBRyxHQUFFLEdBQUUsR0FBRyxHQUFFLE9BQU0sR0FBRyxHQUFFLE1BQUssR0FBRyxLQUFHLFFBQVEsYUFBVyxRQUFRLGNBQVksS0FBSSxDQUFDO0FBQzVHLFVBQUcsQ0FBQyxRQUFRLEdBQUcsR0FBRSxHQUFHLEdBQUUsUUFBUSxTQUFPLFFBQU0sUUFBUSxVQUFVLEVBQUU7QUFDL0QsWUFBTSxXQUFTLE1BQU0sYUFBYSxJQUFJLEtBQUssRUFBRSxLQUFHO0FBQ2hELFVBQUcsS0FBSyxLQUFHLE1BQU0sWUFBWSxNQUFNLGNBQVksS0FBSyxJQUFJLE1BQUssVUFBVSxLQUFLLEtBQUssTUFBSyxRQUFRLE1BQUssT0FBTSxLQUFLLEtBQUssR0FBRyxHQUFFLEdBQUcsR0FBRSxNQUFJLFNBQVEsS0FBSyxHQUFFLEtBQUssVUFBVSxPQUFNLEtBQUssS0FBSyxHQUFFLFFBQVE7QUFDekwsWUFBTSxTQUFPLGNBQWMsSUFBSSxLQUFLLEVBQUU7QUFDdEMsWUFBTSxPQUFLLEtBQUssU0FBUyxTQUFTLEtBQUssSUFBSSxJQUFHLE1BQU07QUFDcEQsVUFBRyxNQUFLO0FBQ04sY0FBTSxNQUFJLFNBQVMsS0FBSyxJQUFJLElBQUcsWUFBVSxLQUFLLEtBQUssR0FBRyxHQUFFLEdBQUcsR0FBRSxHQUFFLFNBQVEsS0FBSztBQUM1RSxZQUFHLENBQUMsS0FBSyxVQUFVLElBQUksR0FBRyxFQUFFLE1BQUssVUFBVSxJQUFJLEtBQUksYUFBYSxJQUFJLENBQUM7QUFDckUsY0FBTSxNQUFJLEtBQUssVUFBVSxJQUFJLEdBQUc7QUFDaEMsWUFBSSxVQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssRUFBRTtBQUNyQyxZQUFHLE9BQUssU0FBUyxVQUFRLEtBQUk7QUFBQyxvQkFBUSxFQUFDLE9BQU0sS0FBSSxNQUFLLElBQUksV0FBVyxHQUFFLFlBQVcsSUFBSSxNQUFNLElBQUksTUFBSSxJQUFJLE1BQU0sUUFBUSxDQUFDLEVBQUM7QUFBRSxlQUFLLFNBQVMsSUFBSSxLQUFLLElBQUcsT0FBTztBQUFBLFFBQUU7QUFDN0osY0FBTSxZQUFVLFNBQVMsS0FBSyxPQUFPLEtBQUssV0FBVyxLQUFLLE1BQUssR0FBRyxDQUFDO0FBQ25FLGFBQUssUUFBUSxJQUFJLFFBQVEsS0FBSyxJQUFJLElBQUksUUFBUSxNQUFNLENBQUMsSUFBRyxNQUFLLFdBQVUsS0FBSyxJQUFHLFFBQVUsT0FBTSxRQUFPLFNBQVM7QUFDL0csY0FBTSxTQUFPLEtBQUssU0FBUyxTQUFTLEtBQUssSUFBSSxJQUFHLFdBQVc7QUFDM0QsWUFBRyxPQUFPLE1BQUssUUFBUSxJQUFJLGVBQWUsS0FBSyxJQUFJLElBQUksU0FBUyxLQUFLLE9BQU8sUUFBUSxDQUFDLElBQUcsUUFBTyxXQUFVLEtBQUssSUFBRyxTQUFTLEtBQUssT0FBTyxRQUFRLENBQUM7QUFDL0ksWUFBRyxRQUFRLFVBQVEsSUFBRSxHQUFFLElBQUUsUUFBUSxLQUFLLE1BQU0sUUFBTyxLQUFJO0FBQ3JELGdCQUFNLE9BQUssUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUFHLGNBQUcsQ0FBQyxLQUFLLFFBQVE7QUFDbkQsZ0JBQU0sU0FBTyxRQUFRLFdBQVcsQ0FBQyxFQUFHLGlCQUFpQixXQUFVLEtBQUssTUFBTTtBQUMxRSxlQUFLLFFBQVEsSUFBSSxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssUUFBUSxJQUFJLFFBQVEsTUFBTSxDQUFDLElBQUcsS0FBSyxVQUFTLFFBQU8sS0FBSyxJQUFHLFFBQVUsT0FBTSxNQUFNO0FBQUEsUUFDbEk7QUFBQSxNQUNGO0FBQ0EsWUFBTSxRQUFNLFFBQVEsVUFBVSxPQUFPLGNBQVUsU0FBUyxTQUFPLE1BQU0sR0FBRSxPQUFLLE1BQU0sS0FBSyxTQUFPLGtCQUFnQixJQUFFLENBQUM7QUFDakgsVUFBRyxNQUFLO0FBQUMsY0FBTSxTQUFPLGFBQWEsRUFBQyxHQUFHLE1BQUssR0FBRSxHQUFHLEdBQUUsR0FBRSxHQUFHLEdBQUUsU0FBUSxFQUFDLEdBQUcsS0FBSyxTQUFTLFFBQU8sRUFBQyxHQUFFLElBQUk7QUFBRSxhQUFLLFFBQVEsSUFBSSxRQUFRLFNBQVMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxJQUFHLEtBQUssTUFBSyxLQUFLLEtBQUssT0FBTyxHQUFFLE9BQU8sR0FBRSxRQUFRLGFBQVcsUUFBUSxZQUFXLEdBQUUsT0FBTSxRQUFRLEdBQUUsS0FBSyxJQUFHLFNBQVMsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUFBLE1BQUU7QUFDcFMsaUJBQVUsUUFBUSxpQkFBaUIsVUFBUyxJQUFJLEdBQUU7QUFDaEQsY0FBTSxTQUFPLGtCQUFrQixXQUFVLElBQUksR0FBRSxNQUFJLFVBQVEsS0FBSyxTQUFTLFNBQVMsT0FBTyxHQUFHLElBQUcsS0FBSztBQUFFLFlBQUcsQ0FBQyxVQUFRLENBQUMsSUFBSTtBQUN2SCxjQUFNLFNBQU8sS0FBSyxPQUFPLElBQUksS0FBSyxFQUFFO0FBQ3BDLGNBQU0sTUFBSSxVQUFRLE9BQU8sV0FBUyxPQUFPLGFBQVcsdUJBQXFCO0FBQ3pFLGNBQU0sT0FBSyxPQUFPLFFBQU0sYUFBVyxJQUFFLElBQUUsUUFBTSxLQUFLLElBQUksR0FBRSxNQUFJLE9BQUksTUFBSSxPQUFJLEtBQUcsTUFBSSxRQUFLLElBQUc7QUFDdkYsYUFBSyxRQUFRLElBQUksT0FBTyxPQUFPLEdBQUcsSUFBSSxLQUFLLGVBQWEsQ0FBQyxJQUFHLEtBQUksS0FBSyxLQUFLLE9BQU8sTUFBTSxJQUFFLEtBQUssSUFBSSxPQUFPLE9BQU8sSUFBRSxNQUFLLE9BQU8sTUFBTSxJQUFFLEtBQUssSUFBSSxPQUFPLE9BQU8sSUFBRSxNQUFLLE9BQU8sYUFBWSxPQUFPLFNBQVEsS0FBSyxHQUFFLEtBQUssSUFBRyxRQUFVLEtBQUssZUFBYSxDQUFDO0FBQUEsTUFDcFA7QUFBQSxJQUNGO0FBQ0EsZUFBVSxVQUFVLEtBQUssVUFBVSxPQUFPLEdBQUU7QUFDMUMsWUFBTSxTQUFPLE9BQU8sU0FBUyxXQUFXLEtBQUssVUFBVSxJQUFJLE9BQU8sUUFBUSxRQUFRLFFBQVE7QUFDMUYsWUFBTSxVQUFRLFVBQVUsZUFBZSxRQUFPLE1BQU07QUFBRSxVQUFHLENBQUMsUUFBUTtBQUNsRSxXQUFLLGdCQUFnQixJQUFJLE9BQU8sSUFBRyxPQUFPO0FBQzFDLFlBQU0sS0FBRyxRQUFRLE9BQU8sSUFBRSxRQUFRLE9BQU8sS0FBRyxHQUFFLEtBQUcsUUFBUSxPQUFPLElBQUUsUUFBUSxPQUFPLEtBQUc7QUFDcEYsVUFBRyxDQUFDLFFBQVEsR0FBRSxHQUFFLEdBQUcsRUFBRTtBQUNyQixZQUFNLElBQUUsWUFBWSxNQUFNLEVBQUcsWUFBVyxJQUFFLFlBQVksTUFBTSxFQUFHO0FBQy9ELFlBQU0sS0FBRyxRQUFRLE9BQU8sSUFBRSxRQUFRLE9BQU8sR0FBRSxLQUFHLFFBQVEsT0FBTyxJQUFFLFFBQVEsT0FBTztBQUM5RSxXQUFLLFlBQVksSUFBSSxJQUFHLElBQUUsR0FBRSxFQUFFO0FBQUUsWUFBTSxPQUFLLEtBQUssWUFBWSxPQUFPO0FBQUUsV0FBSyxZQUFZLFVBQVU7QUFDaEcsV0FBSyxhQUFhLElBQUksQ0FBQyxJQUFHLEdBQUUsRUFBRSxFQUFFLFVBQVU7QUFBRSxXQUFLLFNBQVMsYUFBYSxLQUFLLGNBQWEsS0FBSyxXQUFXLEVBQUUsVUFBVTtBQUNySCxZQUFNLFNBQU8sS0FBSyxLQUFLLEdBQUUsR0FBRSxDQUFDLEVBQUUsVUFBVSxLQUFLLGFBQVksS0FBSyxVQUFTLEtBQUssWUFBWSxFQUFFLFlBQVksSUFBRyxJQUFFLEtBQUcsSUFBRSxHQUFFLENBQUMsRUFDaEgsTUFBTSxLQUFLLGVBQWUsSUFBSSxNQUFLLEdBQUUsUUFBUSxLQUFLLENBQUM7QUFDdEQsV0FBSyxRQUFRLElBQUksZ0JBQWdCLFFBQVEsS0FBSyxJQUFHLEtBQUssU0FBUSxRQUFPLE9BQU8sSUFBRyxRQUFVLFFBQVEsVUFBUSxXQUFXO0FBQUEsSUFDdEg7QUFDQSxlQUFVLE1BQU0sS0FBSyxTQUFTLEtBQUssRUFBRSxLQUFHLENBQUMsTUFBTSxJQUFJLEVBQUUsRUFBRSxNQUFLLFNBQVMsT0FBTyxFQUFFO0FBQzlFLFVBQU0sV0FBUyxvQkFBSSxJQUFZO0FBQy9CLGVBQVUsUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLElBQUksR0FBRTtBQUNuRCxVQUFHLE1BQU0sSUFBSSxLQUFLLEVBQUUsS0FBRyxVQUFVLElBQUksRUFBRTtBQUN2QyxVQUFJLEtBQUcsTUFBTSxRQUFRLFNBQVMsTUFBSyxHQUFHLEtBQUcsTUFBSyxTQUFPLEdBQUUsU0FBTyxNQUFNLE9BQU8sT0FBTyxLQUFLLEVBQUU7QUFDekYsVUFBSTtBQUNKLFlBQU0sT0FBSyxLQUFLLFFBQU0sTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNO0FBQ2hELFVBQUcsTUFBSztBQUNOLGlCQUFTLElBQUksS0FBSyxFQUFFO0FBQUUsY0FBTSxTQUFPLE1BQU0sUUFBUSxTQUFTLE1BQUssR0FBRyxLQUFHLE1BQUssVUFBUSxNQUFNLFFBQVEsUUFBUSxNQUFLLEdBQUcsS0FBRyxLQUFLLFNBQVMsV0FBUztBQUMxSSxpQkFBTyxzQkFBc0IsTUFBSyxLQUFLLFdBQVUsS0FBSyxlQUFlO0FBQ3JFLFlBQUcsUUFBTztBQUFDLGVBQUc7QUFBTyxtQkFBTyxPQUFPO0FBQUEsUUFBTyxPQUN0QztBQUFDLGdCQUFNLE9BQUssS0FBSyxhQUFhLE1BQUssR0FBRyxHQUFFLElBQUUsS0FBSyxJQUFJLE9BQU8sR0FBRSxJQUFFLEtBQUssSUFBSSxPQUFPO0FBQUUsZUFBRyxFQUFDLEdBQUUsT0FBTyxJQUFFLEtBQUssSUFBRSxJQUFFLEtBQUssSUFBRSxHQUFFLEdBQUUsT0FBTyxJQUFFLEtBQUssSUFBRSxJQUFFLEtBQUssSUFBRSxFQUFDO0FBQUUsbUJBQU8sWUFBWSxJQUFJLEVBQUc7QUFBQSxRQUFXO0FBQ3hMLGNBQU0sS0FBRyxvQkFBb0IsS0FBSyxLQUFLLEdBQUUsU0FBTyxLQUFLLE9BQUssQ0FBQyxVQUFTLGNBQWEsUUFBTyxPQUFNLE1BQU0sRUFBRSxTQUFTLEtBQUssTUFBTSxJQUFJO0FBQzlILGlCQUFPLEtBQUssT0FBTyxPQUFPLE1BQUssU0FBUSxPQUFNLFNBQU8sS0FBSyxNQUFJLEtBQUcsU0FBUyxJQUFJLEVBQUUsSUFBRSxNQUFTO0FBQUEsTUFDNUY7QUFDQSxZQUFNLFFBQU0sS0FBSyxZQUFVLFNBQVUsU0FBVSxNQUFNLFNBQVMsS0FBSyxPQUFPO0FBQzFFLFVBQUk7QUFDSixVQUFHLEtBQUssTUFBSztBQUNYLHVCQUFhLE1BQU0sZ0JBQWMsRUFBQyxNQUFLLFFBQU8sT0FBTSxFQUFDLElBQUUsTUFBTSxXQUFXLE1BQU0sTUFBSyxHQUFHLEtBQUcsRUFBQyxNQUFLLFFBQU8sT0FBTSxFQUFDO0FBQzdHLGlCQUFPLE1BQU0sT0FBTyxhQUFhLEtBQUssSUFBRyxhQUFhLGFBQVcsYUFBYSxnQkFBZSxlQUFjLE1BQU07QUFBQSxNQUNuSDtBQUNBLFlBQU0sUUFBTSxRQUFNLEtBQUssSUFBSSxNQUFJLEtBQUssU0FBTyxFQUFFLElBQUUsZUFBZSxLQUFLLE1BQU0sR0FBRSxPQUFLLFFBQU0sS0FBRyxlQUFlLEtBQUssSUFBSSxHQUFHLEtBQUcsSUFBRyxRQUFNLEdBQUcsSUFBRSxTQUFPLE9BQUssT0FBSztBQUN0SixXQUFLLFVBQVUsSUFBSSxLQUFLLElBQUcsRUFBQyxHQUFFLEdBQUcsR0FBRSxHQUFFLEdBQUcsR0FBRSxPQUFNLE1BQUssUUFBTSxLQUFHLE9BQU0sT0FBTSxDQUFDO0FBQzNFLFVBQUcsQ0FBQyxRQUFRLEdBQUcsR0FBRSxLQUFLLEVBQUU7QUFDeEIsdUJBQWUsTUFBTSxnQkFBYyxFQUFDLE1BQUssUUFBZ0IsT0FBTSxFQUFDLElBQUUsTUFBTSxXQUFXLE1BQU0sTUFBSyxHQUFHLEtBQUcsRUFBQyxNQUFLLFFBQWdCLE9BQU0sRUFBQztBQUNqSSxlQUFPLE1BQU0sT0FBTyxhQUFhLEtBQUssSUFBRyxhQUFhLGFBQVcsYUFBYSxnQkFBZSxlQUFjLE1BQU07QUFDakgsWUFBTSxZQUFVLG1CQUFtQixjQUFhLFFBQU8sYUFBYTtBQUFFLFdBQUs7QUFDM0UsV0FBSyxVQUFVLElBQUksS0FBSyxFQUFFLEVBQUcsU0FBTztBQUNwQyxXQUFLLGNBQWMsSUFBSSxLQUFLLElBQUcsRUFBQyxHQUFFLEdBQUcsR0FBRSxHQUFFLEdBQUcsR0FBRSxPQUFNLFFBQU8sUUFBTyxTQUFRLEtBQUssR0FBRSxTQUFRLEtBQUssRUFBQyxDQUFDO0FBQ2hHLFlBQU0sV0FBUyxNQUFNLGFBQWEsSUFBSSxLQUFLLEVBQUUsS0FBRztBQUNoRCxVQUFHLEtBQUssS0FBRyxNQUFNLFlBQVksTUFBTSxjQUFZLEtBQUssS0FBSTtBQUN0RCxZQUFJLFNBQU8sS0FBSyxLQUFLLEdBQUcsR0FBRSxHQUFHLEdBQUUsU0FBTyxJQUFHO0FBQ3pDLGNBQU0sV0FBUyxLQUFLLFNBQVEsVUFBUSxVQUFVLFlBQVksS0FBSyxnQkFBZ0IsSUFBSSxTQUFTLFFBQVE7QUFDcEcsWUFBRyxXQUFXLFVBQVM7QUFDckIsZ0JBQU0sU0FBTyxLQUFLLFVBQVUsSUFBSSxTQUFTLFFBQVEsR0FBRyxTQUFPLEtBQUssVUFBVSxJQUFJLFNBQVMsUUFBUTtBQUMvRixnQkFBTSxLQUFHLFFBQVEsT0FBTyxJQUFFLFFBQVEsT0FBTyxHQUFFLEtBQUcsUUFBUSxPQUFPLElBQUUsUUFBUSxPQUFPO0FBQzlFLGVBQUssWUFBWSxJQUFJLElBQUcsWUFBWSxNQUFNLEVBQUcsYUFBVyxZQUFZLE1BQU0sRUFBRyxZQUFXLEVBQUUsRUFBRSxVQUFVO0FBQ3RHLGVBQUssYUFBYSxJQUFJLENBQUMsSUFBRyxHQUFFLEVBQUUsRUFBRSxVQUFVO0FBQUUsZUFBSyxTQUFTLGFBQWEsS0FBSyxjQUFhLEtBQUssV0FBVyxFQUFFLFVBQVU7QUFDckgsbUJBQU8sT0FBTyxVQUFVLEtBQUssYUFBWSxLQUFLLFVBQVMsS0FBSyxZQUFZLEVBQ3JFLFlBQVksR0FBRyxJQUFFLEtBQUssU0FBUyxJQUFFLE1BQUksU0FBTyxLQUFLLFNBQVMsSUFBRSxNQUFJLEdBQUcsSUFBRSxLQUFLLFNBQVMsSUFBRSxJQUFHO0FBQUEsUUFDN0Y7QUFDQSxjQUFNLFVBQVEsS0FBSyxjQUFZLEtBQUssVUFBUTtBQUM1QyxhQUFLLFVBQVUsUUFBUSxRQUFPLFFBQU8sU0FBTyxNQUFJLEtBQUssVUFBVSxPQUFNLEtBQUssS0FBSyxHQUFFLFFBQVE7QUFBQSxNQUMzRjtBQUNBLFlBQU0sYUFBVyxjQUFjLFVBQVMsSUFBSTtBQUM1QyxZQUFNLFVBQVEsT0FBSyxPQUFJLElBQUUsR0FBRSxNQUFJLEdBQUcsYUFBYSxLQUFLLE1BQUssU0FBUyxLQUFLLE9BQU0sUUFBUSxHQUFFLFdBQVUsS0FBSyxPQUFPLENBQUMsSUFBSSxNQUFNLElBQUksT0FBTyxJQUFJLGNBQWMsVUFBVSxDQUFDO0FBQ2hLLFlBQU0sWUFBVSxLQUFLLEtBQUssR0FBRyxHQUFFLEdBQUcsR0FBRSxRQUFPLEdBQUUsT0FBTSxRQUFRO0FBQzNELFlBQU0sV0FBUyxPQUFPLE1BQU0sWUFBWSxTQUFTLEtBQUcsZ0JBQWdCLFdBQVUsS0FBSyxJQUFJLEdBQUUsVUFBUSxLQUFLLFlBQVksVUFBUyxTQUFRLFdBQVUsSUFBSTtBQUNqSixXQUFLLE1BQU0sSUFBSSxLQUFJLFNBQVEsU0FBSztBQUM5QixZQUFJLE1BQU0sUUFBTyxDQUFDO0FBQ2xCLFlBQUcsTUFBTSxPQUFNLE1BQU0sS0FBSSxTQUFTLEtBQUssT0FBTSxRQUFRLEdBQUUsV0FBVSxRQUFPLFVBQVU7QUFBQSxZQUM3RSxhQUFZLEtBQUksS0FBSyxNQUFLLFNBQVMsS0FBSyxPQUFNLFFBQVEsR0FBRSxXQUFVLFFBQU8sVUFBVTtBQUFBLE1BQzFGLEdBQUUsV0FBVSxLQUFLLElBQUcsTUFBSyxVQUFTLEdBQUUsT0FBTztBQUFBLElBQzdDO0FBQ0EsZUFBVSxDQUFDLFFBQU8sT0FBTyxLQUFLLGtCQUFrQixTQUFTLE9BQU8sR0FBRTtBQUNoRSxZQUFNLE9BQUssS0FBSyxVQUFVLElBQUksTUFBTTtBQUFFLFVBQUcsQ0FBQyxRQUFNLEtBQUssTUFBSSxFQUFFO0FBQzNELGlCQUFVLFVBQVUsU0FBUTtBQUM1QixjQUFNLE9BQUssZ0JBQWdCLFFBQU8sSUFBSTtBQUN0QyxZQUFHLENBQUMsUUFBTSxDQUFDLFFBQVEsS0FBSyxHQUFFLEtBQUssSUFBRSxLQUFLLFNBQU8sTUFBSyxHQUFHLEVBQUU7QUFDdkQsY0FBTSxRQUFNLE9BQU8sVUFBUSxNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUU7QUFDMUQsY0FBTSxRQUFNLFFBQU0sS0FBSyxJQUFJLE1BQUksT0FBTyxTQUFPLEVBQUUsSUFBRSxlQUFlLE9BQU8sTUFBTTtBQUM3RSxjQUFNLGFBQVcsb0JBQW9CLFVBQVMsTUFBTSxHQUFFLFFBQU0sU0FBUyxPQUFPLE9BQU0sUUFBUSxHQUFFLFVBQVEsZUFBZSxPQUFPLEVBQUU7QUFDNUgsY0FBTSxNQUFJLFVBQVUsT0FBTyxJQUFJLElBQUksT0FBTyxXQUFTLEVBQUUsSUFBSSxLQUFLLElBQUksb0JBQW9CLFVBQVUsQ0FBQyxJQUFJLE9BQU87QUFDNUcsY0FBTSxZQUFVLGtCQUFrQixLQUFLLEtBQUssR0FBRSxHQUFFLENBQUMsR0FBRSxNQUFLLEtBQUs7QUFDN0QsY0FBTSxVQUFRLE9BQUssT0FBSSxJQUFFLEdBQUUsVUFBUSxLQUFLLFlBQVksS0FBSSxTQUFRLFdBQVUsR0FBRSxLQUFLO0FBQ2pGLGFBQUssYUFBYSxJQUFJLEtBQUksU0FBUSxTQUFLO0FBRXJDLDBCQUFnQixLQUFJLE9BQU8sTUFBSyxFQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLFNBQVEsT0FBTSxPQUFPLFNBQVEsT0FBTSxVQUFVO0FBQUEsUUFDNUYsR0FBRSxXQUFVLE9BQU8sSUFBRyxHQUFFLEtBQUksZUFBZSxTQUFTLE1BQUssT0FBTyxVQUFVLEdBQUUsT0FBTztBQUFBLE1BQ25GO0FBQUEsSUFDRjtBQUNBLGVBQVUsTUFBTSxLQUFLLFdBQVcsS0FBSyxFQUFFLEtBQUcsQ0FBQyxTQUFTLElBQUksRUFBRSxFQUFFLE1BQUssV0FBVyxPQUFPLEVBQUU7QUFDckYsZUFBVSxVQUFVLFNBQVMsU0FBUTtBQUNuQyxVQUFHLENBQUMsaUJBQWlCLElBQUksT0FBTyxJQUFJLEVBQUU7QUFDdEMsWUFBTSxTQUFPLE1BQU0sYUFBYSxPQUFPLE1BQU07QUFDN0MsWUFBTSxPQUFLLFdBQVcsUUFBTyxNQUFJLEtBQUssSUFBRyxNQUFNO0FBQy9DLFlBQU0sUUFBTSxLQUFLLFNBQU8sVUFBUSxLQUFLLFFBQU0sS0FBSyxTQUFPLFFBQU0sS0FBSyxRQUFNLEtBQUssU0FBTyxTQUFPLEtBQUssT0FBSyxDQUFDLFNBQVEsU0FBUSxRQUFRLEVBQUUsU0FBUyxLQUFLLElBQUksSUFBRSxLQUFLLE9BQUssS0FBSztBQUNuSyxZQUFNLE9BQUssS0FBSyxTQUFPLFFBQU0sZ0JBQWdCLE9BQU8sWUFBVyxPQUFPLFFBQU0sU0FBUyxRQUFRLE9BQU8sS0FBSyxHQUFHLE9BQUssTUFBUyxFQUFFLE9BQUs7QUFDakksWUFBTSxRQUFNLE9BQUssT0FBTyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBSTtBQUN0RCxVQUFHLFFBQVEsS0FBSyxHQUFFLEtBQUssQ0FBQyxHQUFFO0FBQ3hCLFlBQUksSUFBRSxLQUFLLEdBQUUsSUFBRSxLQUFLLEdBQUUsU0FBTyxLQUFLLFFBQU9DO0FBQ3pDLFlBQUcsVUFBUSxVQUFRLEtBQUssTUFBSztBQUMzQixnQkFBTSxLQUFHLEtBQUssSUFBSSxLQUFLLEtBQUs7QUFBRSxlQUFLLGlCQUFpQixJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBRSxJQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssR0FBRSxLQUFLLElBQUksS0FBSyxPQUFPLElBQUUsRUFBRTtBQUNoSSxVQUFBQSxZQUFTLEtBQUssZ0JBQWdCLG1CQUFtQixLQUFLLGFBQVksS0FBSyxnQkFBZ0I7QUFHdkYsZUFBRyxLQUFLLGlCQUFpQixJQUFFO0FBQUUsZUFBRyxLQUFLLGlCQUFpQixJQUFFO0FBQUUsb0JBQVEsS0FBSyxpQkFBaUIsSUFBRTtBQUFBLFFBQzVGO0FBQ0EsYUFBSyxRQUFRLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxTQUFPLEVBQUUsSUFBRyxPQUFNLEtBQUssS0FBSyxHQUFFLEdBQUUsUUFBTyxLQUFLLFNBQVEsS0FBSyxPQUFNQSxTQUFRLEdBQUUsT0FBTyxJQUFHLEtBQUs7QUFBQSxNQUNsSTtBQUFBLElBQ0Y7QUFDQSxTQUFLLFFBQVEsT0FBTztBQUFFLFNBQUssTUFBTSxPQUFPLFFBQVE7QUFBRSxTQUFLLGFBQWEsT0FBTyxRQUFRO0FBQUUsU0FBSyxVQUFVLE9BQU87QUFDM0csUUFBRyxNQUFNLE9BQU8sTUFBSyxVQUFVLE9BQU8sTUFBTSxPQUFPLE1BQU0sR0FBRyxHQUFFLEtBQUssZUFBYyxNQUFNLGVBQWMsTUFBTSxJQUFJO0FBQUEsUUFBTyxNQUFLLFVBQVUsTUFBTTtBQUMzSSxTQUFLLFdBQVcsU0FBTyxLQUFLO0FBQzVCLGFBQVMsT0FBTyxLQUFLLE9BQU0sS0FBSyxNQUFNO0FBQUEsRUFDeEM7QUFBQSxFQUNBLEtBQUssT0FBMEI7QUFBQyxRQUFHLENBQUMsS0FBSyxLQUFLLFFBQU87QUFBVSxVQUFNLE1BQUksSUFBSSxNQUFNLFVBQVU7QUFBRSxRQUFJLGNBQWMsSUFBSSxNQUFNLFFBQVEsTUFBTSxJQUFFLEtBQUssS0FBSyxRQUFNLElBQUUsR0FBRSxJQUFFLE1BQU0sSUFBRSxLQUFLLEtBQUssU0FBTyxDQUFDLEdBQUUsS0FBSyxNQUFNO0FBQ3RNLGVBQVUsT0FBTyxJQUFJLGlCQUFpQixDQUFDLEdBQUcsS0FBSyxRQUFRLFFBQVEsR0FBRSxHQUFHLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRSxLQUFLLEdBQUU7QUFDL0YsWUFBTSxXQUFVLElBQUksT0FBc0I7QUFBUyxZQUFNLFFBQU0sTUFBTSxRQUFRLFFBQVEsSUFBRSxTQUFTLElBQUksTUFBTSxpQkFBZSxDQUFDLElBQUU7QUFHNUgsVUFBRyxPQUFPLEtBQUssV0FBVyxpQkFBaUIsS0FBRyxNQUFNLGVBQWEsTUFBTSxVQUFRLElBQUc7QUFDbEYsVUFBRyxJQUFJLE9BQU8sU0FBUyxjQUFZLENBQUMsSUFBSSxPQUFPLFNBQVMsV0FBVyxJQUFJLGNBQVksR0FBRSxJQUFJLEVBQUUsRUFBRTtBQUM3RixVQUFHLENBQUMsV0FBWSxPQUFtQyxPQUFLLFFBQVUsSUFBSSxFQUFFLEVBQUU7QUFDMUUsWUFBTSxLQUFHLElBQUksT0FBTyxTQUFTLE1BQU0sSUFBSSxjQUFZLENBQUM7QUFBc0IsVUFBRyxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsRUFBRSxRQUFNLEVBQUMsSUFBRyxRQUFPLElBQUksTUFBTSxFQUFDO0FBQUEsSUFDeEk7QUFBQyxXQUFPO0FBQUEsRUFDVjtBQUFBLEVBQ0EsTUFBTSxPQUEwQixRQUFjO0FBQUMsV0FBTyxLQUFLLE9BQUssY0FBYyxLQUFLLFFBQU8sS0FBSyxNQUFLLE9BQU0sTUFBTSxJQUFFO0FBQUEsRUFBVTtBQUFBLEVBQ3BILFVBQVUsT0FBaUIsT0FBWTtBQUFDLFdBQU8sTUFBTSxTQUFPLGFBQWEsV0FBVyxNQUFNLFVBQVMsTUFBTSxRQUFPLEtBQUssQ0FBQyxJQUFFLFNBQVMsT0FBTSxNQUFNLFFBQVE7QUFBQSxFQUFFO0FBQUEsRUFDdkosaUJBQWlCLE9BQWlCLE1BQXVDLE9BQWEsVUFBaUI7QUFDN0csVUFBTSxTQUFPLGdCQUFnQixNQUFNLFVBQVMsTUFBSyxLQUFLLE1BQU07QUFDNUQsUUFBRyxRQUFPO0FBQ1IsWUFBTSxTQUFPLE9BQU8sUUFBTSxPQUFPLE9BQUssS0FBRyxPQUFPLE1BQUssU0FBTyxPQUFPLFNBQU8sT0FBTyxNQUFJLEtBQUcsT0FBTztBQUMvRixXQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUssT0FBTyxPQUFLLE9BQU8sT0FBSyxRQUFNLEdBQUUsT0FBTyxNQUFJLE9BQU8sT0FBSyxRQUFNLEdBQUUsSUFBRyxHQUFFLFFBQU0sSUFBRSxHQUFFLFFBQU0sSUFBRSxHQUFFLE9BQU0sUUFBUTtBQUFBLElBQzNJLE1BQU0sTUFBSyxVQUFVLFFBQVEsS0FBSyxLQUFLLEtBQUssR0FBRSxLQUFLLEdBQUUsSUFBRyxHQUFFLEtBQUssU0FBTyxJQUFHLEtBQUssU0FBTyxLQUFHLE1BQUksT0FBTSxRQUFRO0FBQUEsRUFDNUc7QUFBQSxFQUNBLFVBQVM7QUFDUCxRQUFHLEtBQUssU0FBUztBQUFPLFNBQUssV0FBUztBQUN0QyxTQUFLLGFBQWEsb0JBQW9CLG9CQUFtQixLQUFLLGFBQWE7QUFBRSxTQUFLLGFBQWEsb0JBQW9CLHdCQUF1QixLQUFLLGlCQUFpQjtBQUFFLFNBQUssY0FBWTtBQUFVLFNBQUssTUFBTTtBQUN4TSxTQUFLLFVBQVUsUUFBUTtBQUFFLFNBQUssVUFBVSxRQUFRO0FBQ2hELFNBQUssTUFBTSxRQUFRO0FBQUUsZUFBVSxPQUFPLEtBQUssVUFBVSxPQUFPLEVBQUUsTUFBSyxRQUFRO0FBQUUsU0FBSyxVQUFVLE1BQU07QUFHbEcsU0FBSyxVQUFVLE1BQU07QUFBRSxTQUFLLE9BQU8sTUFBTTtBQUN6QyxlQUFVLFFBQVEsQ0FBQyxLQUFLLFFBQU8sS0FBSyxNQUFLLEtBQUssTUFBSyxLQUFLLE9BQU0sS0FBSyxNQUFLLEtBQUssTUFBSyxLQUFLLE9BQU0sS0FBSyxPQUFPLEdBQUU7QUFBQyxXQUFLLFNBQVMsUUFBUTtBQUFFLE1BQUMsS0FBSyxTQUE0QixRQUFRO0FBQUEsSUFBRTtBQUNoTCxTQUFLLElBQUksT0FBTyxRQUFRO0FBQUUsU0FBSyxJQUFJLE9BQU8sTUFBSSxLQUFLLElBQUksT0FBTyxVQUFRO0FBQUssU0FBSyxNQUFNLE1BQU07QUFDNUYsVUFBTSxXQUFTLEtBQUs7QUFBUyxTQUFLLFdBQVM7QUFDM0MsY0FBVSxRQUFRO0FBQUUsY0FBVSxpQkFBaUI7QUFBQSxFQUNqRDtBQUNGOyIsIm5hbWVzIjpbInNpdGUiLCJleHRlbnQiLCJyb3RhdGlvbiJdfQ==