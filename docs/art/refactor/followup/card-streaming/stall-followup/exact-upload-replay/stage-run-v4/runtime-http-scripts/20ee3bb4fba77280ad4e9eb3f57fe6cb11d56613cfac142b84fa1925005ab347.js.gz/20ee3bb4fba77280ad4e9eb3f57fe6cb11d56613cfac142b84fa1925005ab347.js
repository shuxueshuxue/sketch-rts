export const NEUTRAL_UNITS = {
  spirit: {
    name: { en: "Spirit", zh: "灵体" },
    glyph: { silhouette: "spirit-wisp", marks: ["tail", "spark", "halo"] },
    art: { tier: "basic", bearing: "spirit", faction: "summoned" }
  },
  mercenary: {
    name: { en: "Mercenary", zh: "雇佣兵" },
    glyph: { silhouette: "mercenary-badge", marks: ["coinSlash", "shortSword", "scar"] },
    art: { tier: "advanced", bearing: "foot", faction: "hired" }
  },
  contractArcher: {
    name: { en: "Contract Archer", zh: "契约弓手" },
    glyph: { silhouette: "mercenary-badge", marks: ["coinSlash", "bow", "arrow"] },
    art: { tier: "advanced", bearing: "foot", faction: "hired" }
  },
  fieldMedic: {
    name: { en: "Field Medic", zh: "战地医师" },
    glyph: { silhouette: "mercenary-badge", marks: ["coinSlash", "halo", "cross"] },
    art: { tier: "advanced", bearing: "foot", faction: "hired" }
  },
  wildling: {
    name: { en: "Wildling", zh: "林间野人" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "scar", "curseSlash"] },
    art: { tier: "basic", bearing: "foot", faction: "wild" }
  },
  mossGnawer: {
    name: { en: "Moss Gnawer", zh: "苔鼠" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "scar", "shortSword"] },
    art: { tier: "basic", bearing: "beast", faction: "wild" }
  },
  thornSlinger: {
    name: { en: "Thorn Slinger", zh: "荆刺射手" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "bow", "arrow"] },
    art: { tier: "advanced", bearing: "foot", faction: "wild" }
  },
  barkMender: {
    name: { en: "Bark Mender", zh: "树皮医者" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "halo", "cross"] },
    art: { tier: "advanced", bearing: "foot", faction: "wild" }
  },
  stonebackBrute: {
    name: { en: "Stoneback Brute", zh: "石背蛮兽" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "blockSeams", "shieldBar"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  },
  gladeWitch: {
    name: { en: "Glade Witch", zh: "林间女巫" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "crescent", "curseSlash"] },
    art: { tier: "elite", bearing: "foot", faction: "wild" }
  },
  ancientStag: {
    name: { en: "Ancient Stag", zh: "远古巨鹿" },
    glyph: { silhouette: "wildling-thorns", marks: ["thornFork", "visor", "halo"] },
    art: { tier: "elite", bearing: "beast", faction: "wild" }
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaXRzLW5ldXRyYWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBVbml0S2luZCB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB0eXBlIHsgVW5pdENhcmQgfSBmcm9tIFwiLi9jYXJkc1wiO1xuXG5leHBvcnQgY29uc3QgTkVVVFJBTF9VTklUUyA9IHtcbiAgc3Bpcml0OiB7XG4gICAgbmFtZTogeyBlbjogXCJTcGlyaXRcIiwgemg6IFwi54G15L2TXCIgfSxcbiAgICBnbHlwaDogeyBzaWxob3VldHRlOiBcInNwaXJpdC13aXNwXCIsIG1hcmtzOiBbXCJ0YWlsXCIsIFwic3BhcmtcIiwgXCJoYWxvXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYmFzaWNcIiwgYmVhcmluZzogXCJzcGlyaXRcIiwgZmFjdGlvbjogXCJzdW1tb25lZFwiIH0sXG4gIH0sXG4gIG1lcmNlbmFyeToge1xuICAgIG5hbWU6IHsgZW46IFwiTWVyY2VuYXJ5XCIsIHpoOiBcIumbh+S9o+WFtVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJtZXJjZW5hcnktYmFkZ2VcIiwgbWFya3M6IFtcImNvaW5TbGFzaFwiLCBcInNob3J0U3dvcmRcIiwgXCJzY2FyXCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwiaGlyZWRcIiB9LFxuICB9LFxuICBjb250cmFjdEFyY2hlcjoge1xuICAgIG5hbWU6IHsgZW46IFwiQ29udHJhY3QgQXJjaGVyXCIsIHpoOiBcIuWlkee6puW8k+aJi1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJtZXJjZW5hcnktYmFkZ2VcIiwgbWFya3M6IFtcImNvaW5TbGFzaFwiLCBcImJvd1wiLCBcImFycm93XCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwiaGlyZWRcIiB9LFxuICB9LFxuICBmaWVsZE1lZGljOiB7XG4gICAgbmFtZTogeyBlbjogXCJGaWVsZCBNZWRpY1wiLCB6aDogXCLmiJjlnLDljLvluIhcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwibWVyY2VuYXJ5LWJhZGdlXCIsIG1hcmtzOiBbXCJjb2luU2xhc2hcIiwgXCJoYWxvXCIsIFwiY3Jvc3NcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJhZHZhbmNlZFwiLCBiZWFyaW5nOiBcImZvb3RcIiwgZmFjdGlvbjogXCJoaXJlZFwiIH0sXG4gIH0sXG4gIHdpbGRsaW5nOiB7XG4gICAgbmFtZTogeyBlbjogXCJXaWxkbGluZ1wiLCB6aDogXCLmnpfpl7Tph47kurpcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwid2lsZGxpbmctdGhvcm5zXCIsIG1hcmtzOiBbXCJ0aG9ybkZvcmtcIiwgXCJzY2FyXCIsIFwiY3Vyc2VTbGFzaFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImJhc2ljXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBtb3NzR25hd2VyOiB7XG4gICAgbmFtZTogeyBlbjogXCJNb3NzIEduYXdlclwiLCB6aDogXCLoi5TpvKBcIiB9LFxuICAgIGdseXBoOiB7IHNpbGhvdWV0dGU6IFwid2lsZGxpbmctdGhvcm5zXCIsIG1hcmtzOiBbXCJ0aG9ybkZvcmtcIiwgXCJzY2FyXCIsIFwic2hvcnRTd29yZFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImJhc2ljXCIsIGJlYXJpbmc6IFwiYmVhc3RcIiwgZmFjdGlvbjogXCJ3aWxkXCIgfSxcbiAgfSxcbiAgdGhvcm5TbGluZ2VyOiB7XG4gICAgbmFtZTogeyBlbjogXCJUaG9ybiBTbGluZ2VyXCIsIHpoOiBcIuiNhuWIuuWwhOaJi1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRob3JuRm9ya1wiLCBcImJvd1wiLCBcImFycm93XCJdIH0sXG4gICAgYXJ0OiB7IHRpZXI6IFwiYWR2YW5jZWRcIiwgYmVhcmluZzogXCJmb290XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIGJhcmtNZW5kZXI6IHtcbiAgICBuYW1lOiB7IGVuOiBcIkJhcmsgTWVuZGVyXCIsIHpoOiBcIuagkeearuWMu+iAhVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRob3JuRm9ya1wiLCBcImhhbG9cIiwgXCJjcm9zc1wiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImFkdmFuY2VkXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBzdG9uZWJhY2tCcnV0ZToge1xuICAgIG5hbWU6IHsgZW46IFwiU3RvbmViYWNrIEJydXRlXCIsIHpoOiBcIuefs+iDjOibruWFvVwiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRob3JuRm9ya1wiLCBcImJsb2NrU2VhbXNcIiwgXCJzaGllbGRCYXJcIl0gfSxcbiAgICBhcnQ6IHsgdGllcjogXCJlbGl0ZVwiLCBiZWFyaW5nOiBcImJlYXN0XCIsIGZhY3Rpb246IFwid2lsZFwiIH0sXG4gIH0sXG4gIGdsYWRlV2l0Y2g6IHtcbiAgICBuYW1lOiB7IGVuOiBcIkdsYWRlIFdpdGNoXCIsIHpoOiBcIuael+mXtOWls+W3q1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRob3JuRm9ya1wiLCBcImNyZXNjZW50XCIsIFwiY3Vyc2VTbGFzaFwiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiZm9vdFwiLCBmYWN0aW9uOiBcIndpbGRcIiB9LFxuICB9LFxuICBhbmNpZW50U3RhZzoge1xuICAgIG5hbWU6IHsgZW46IFwiQW5jaWVudCBTdGFnXCIsIHpoOiBcIui/nOWPpOW3qOm5v1wiIH0sXG4gICAgZ2x5cGg6IHsgc2lsaG91ZXR0ZTogXCJ3aWxkbGluZy10aG9ybnNcIiwgbWFya3M6IFtcInRob3JuRm9ya1wiLCBcInZpc29yXCIsIFwiaGFsb1wiXSB9LFxuICAgIGFydDogeyB0aWVyOiBcImVsaXRlXCIsIGJlYXJpbmc6IFwiYmVhc3RcIiwgZmFjdGlvbjogXCJ3aWxkXCIgfSxcbiAgfSxcbn0gc2F0aXNmaWVzIFBhcnRpYWw8UmVjb3JkPFVuaXRLaW5kLCBVbml0Q2FyZD4+O1xuIl0sIm1hcHBpbmdzIjoiQUFHTyxhQUFNLGdCQUFnQjtBQUFBLEVBQzNCLFFBQVE7QUFBQSxJQUNOLE1BQU0sRUFBRSxJQUFJLFVBQVUsSUFBSSxLQUFLO0FBQUEsSUFDL0IsT0FBTyxFQUFFLFlBQVksZUFBZSxPQUFPLENBQUMsUUFBUSxTQUFTLE1BQU0sRUFBRTtBQUFBLElBQ3JFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxVQUFVLFNBQVMsV0FBVztBQUFBLEVBQy9EO0FBQUEsRUFDQSxXQUFXO0FBQUEsSUFDVCxNQUFNLEVBQUUsSUFBSSxhQUFhLElBQUksTUFBTTtBQUFBLElBQ25DLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsYUFBYSxjQUFjLE1BQU0sRUFBRTtBQUFBLElBQ25GLEtBQUssRUFBRSxNQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUFBLEVBQzdEO0FBQUEsRUFDQSxnQkFBZ0I7QUFBQSxJQUNkLE1BQU0sRUFBRSxJQUFJLG1CQUFtQixJQUFJLE9BQU87QUFBQSxJQUMxQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsT0FBTyxPQUFPLEVBQUU7QUFBQSxJQUM3RSxLQUFLLEVBQUUsTUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFBQSxFQUM3RDtBQUFBLEVBQ0EsWUFBWTtBQUFBLElBQ1YsTUFBTSxFQUFFLElBQUksZUFBZSxJQUFJLE9BQU87QUFBQSxJQUN0QyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsUUFBUSxPQUFPLEVBQUU7QUFBQSxJQUM5RSxLQUFLLEVBQUUsTUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFBQSxFQUM3RDtBQUFBLEVBQ0EsVUFBVTtBQUFBLElBQ1IsTUFBTSxFQUFFLElBQUksWUFBWSxJQUFJLE9BQU87QUFBQSxJQUNuQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsUUFBUSxZQUFZLEVBQUU7QUFBQSxJQUNuRixLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsUUFBUSxTQUFTLE9BQU87QUFBQSxFQUN6RDtBQUFBLEVBQ0EsWUFBWTtBQUFBLElBQ1YsTUFBTSxFQUFFLElBQUksZUFBZSxJQUFJLEtBQUs7QUFBQSxJQUNwQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsUUFBUSxZQUFZLEVBQUU7QUFBQSxJQUNuRixLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsU0FBUyxTQUFTLE9BQU87QUFBQSxFQUMxRDtBQUFBLEVBQ0EsY0FBYztBQUFBLElBQ1osTUFBTSxFQUFFLElBQUksaUJBQWlCLElBQUksT0FBTztBQUFBLElBQ3hDLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsYUFBYSxPQUFPLE9BQU8sRUFBRTtBQUFBLElBQzdFLEtBQUssRUFBRSxNQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsT0FBTztBQUFBLEVBQzVEO0FBQUEsRUFDQSxZQUFZO0FBQUEsSUFDVixNQUFNLEVBQUUsSUFBSSxlQUFlLElBQUksT0FBTztBQUFBLElBQ3RDLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsYUFBYSxRQUFRLE9BQU8sRUFBRTtBQUFBLElBQzlFLEtBQUssRUFBRSxNQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsT0FBTztBQUFBLEVBQzVEO0FBQUEsRUFDQSxnQkFBZ0I7QUFBQSxJQUNkLE1BQU0sRUFBRSxJQUFJLG1CQUFtQixJQUFJLE9BQU87QUFBQSxJQUMxQyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsY0FBYyxXQUFXLEVBQUU7QUFBQSxJQUN4RixLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsU0FBUyxTQUFTLE9BQU87QUFBQSxFQUMxRDtBQUFBLEVBQ0EsWUFBWTtBQUFBLElBQ1YsTUFBTSxFQUFFLElBQUksZUFBZSxJQUFJLE9BQU87QUFBQSxJQUN0QyxPQUFPLEVBQUUsWUFBWSxtQkFBbUIsT0FBTyxDQUFDLGFBQWEsWUFBWSxZQUFZLEVBQUU7QUFBQSxJQUN2RixLQUFLLEVBQUUsTUFBTSxTQUFTLFNBQVMsUUFBUSxTQUFTLE9BQU87QUFBQSxFQUN6RDtBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsTUFBTSxFQUFFLElBQUksZ0JBQWdCLElBQUksT0FBTztBQUFBLElBQ3ZDLE9BQU8sRUFBRSxZQUFZLG1CQUFtQixPQUFPLENBQUMsYUFBYSxTQUFTLE1BQU0sRUFBRTtBQUFBLElBQzlFLEtBQUssRUFBRSxNQUFNLFNBQVMsU0FBUyxTQUFTLFNBQVMsT0FBTztBQUFBLEVBQzFEO0FBQ0Y7IiwibmFtZXMiOltdfQ==