import { drawChainLightningEffect, drawHealEffect, drawSummonEffect, drawCurseEffect, drawStormEffect, drawGuardianFieldEffect, drawExperienceBurstEffect, drawFlameBurnEffect, drawPhysicalMissile, drawArrow, drawSpellOrb, drawProjectileTrail, drawChargeTrail, drawChargeImpact, drawGoldBountyEffect } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/canvas-effects.ts";
import { estimatedRider, riderRadius, hasEffectVector, chargeTrailFrame, chargeImpactFrame, projectileLook, launchPoint, arrowFrame, isUnitKind, TOWER_ARROW_SCALE, spellOrbPalette } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/effect-presentation.ts";
import { drawWarfareEffect } from "/@fs/tmp/sketch-queue-source-42bd/src/client/warfare-effects.ts";
import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { drawVeteranCastEffect } from "/@fs/tmp/sketch-queue-source-42bd/src/client/ability-effects.ts";
import { shouldRenderCommandFeedback } from "/@fs/tmp/sketch-queue-source-42bd/src/client/command-feedback.ts";
export function renderWorldEffects(options) {
  const { ctx, effects, worldToScreen, nearScreen, unitPosition } = options;
  const renderer = { ctx, worldToScreen };
  for (const effect of effects) {
    if (effect.remaining <= 0 || !shouldRenderCommandFeedback(effect, options.viewer)) continue;
    if (drawWarfareEffect(ctx, effect, worldToScreen, nearScreen)) continue;
    if (effect.type === "chargeTrail" && hasEffectVector(effect)) {
      if (options.combatTrails) continue;
      const from = worldToScreen({ x: effect.fromX, y: effect.fromY });
      const to = worldToScreen({ x: effect.toX, y: effect.toY });
      const life2 = effect.remaining / effect.duration;
      const followed = effect.unitId ? unitPosition?.(effect.unitId) : void 0;
      const rider = followed ? worldToScreen(followed) : estimatedRider(from, to, life2, effect.sourceKind);
      if (!nearScreen(rider, 140) && !nearScreen(from, 140)) continue;
      drawChargeTrail(ctx, chargeTrailFrame(from, rider, to, life2, riderRadius(effect.sourceKind)));
      continue;
    }
    if (effect.type === "chargeImpact" && hasEffectVector(effect)) {
      const point2 = worldToScreen(effect);
      if (!nearScreen(point2, 90)) continue;
      const from = worldToScreen({ x: effect.fromX, y: effect.fromY });
      drawChargeImpact(ctx, chargeImpactFrame(point2, from, effect.remaining / effect.duration));
      continue;
    }
    if (effect.type === "projectile" && hasEffectVector(effect)) {
      const origin = options.projectileOrigin?.(effect);
      const from = worldToScreen({ x: origin?.x ?? effect.fromX, y: (origin?.y ?? effect.fromY) - (origin?.height ?? effect.fromHeight ?? 0) * Math.tan(SHIP_CAMERA.tilt) });
      const to = worldToScreen({ x: effect.toX, y: effect.toY - (effect.toHeight ?? 0) * Math.tan(SHIP_CAMERA.tilt) });
      if (!nearScreen(to, 90) && !nearScreen(from, 90)) continue;
      const progress = 1 - effect.remaining / effect.duration;
      const look = projectileLook(effect.sourceKind, effect.attackKind);
      if (look !== "streak") {
        const sourceKind = effect.sourceKind;
        const launch = origin ? from : sourceKind ? launchPoint(from, to, sourceKind) : from;
        if (look === "arrow") drawArrow(ctx, arrowFrame(launch, to, progress, !sourceKind || isUnitKind(sourceKind) ? 1 : TOWER_ARROW_SCALE));
        else if (look === "orb") drawSpellOrb(ctx, launch, to, progress, spellOrbPalette(sourceKind, effect.owner ? options.players?.[effect.owner]?.race : void 0));
        else drawPhysicalMissile(ctx, launch, to, progress, look);
        continue;
      }
      const head = {
        x: from.x + (to.x - from.x) * progress,
        y: from.y + (to.y - from.y) * progress
      };
      drawProjectileTrail(ctx, from, to, head, progress, effect.remaining / effect.duration);
      continue;
    }
    if (effect.type === "melee" || effect.type === "repair" || effect.type === "build") continue;
    if (effect.type === "chainLightning" && hasEffectVector(effect)) {
      const from = worldToScreen({ x: effect.fromX, y: effect.fromY });
      const to = worldToScreen({ x: effect.toX, y: effect.toY });
      if (!nearScreen(to, 120) && !nearScreen(from, 120)) continue;
      drawChainLightningEffect(ctx, effect, from, to);
      continue;
    }
    const point = worldToScreen(effect);
    const pad = effect.type === "guardianField" || effect.type === "storm" ? (effect.radius ?? (effect.type === "guardianField" ? 280 : 145)) + 80 : 90;
    if (!nearScreen(point, pad)) continue;
    const life = effect.remaining / effect.duration;
    const radius = 9 + (1 - life) * 22;
    const caster = effect.unitId ? options.unit?.(effect.unitId) : void 0;
    const casterPoint = effect.radius && effect.unitId ? unitPosition?.(effect.unitId) : void 0;
    if (drawVeteranCastEffect(ctx, effect, caster, casterPoint ? worldToScreen(casterPoint) : point, options.reducedMotion)) continue;
    if (effect.type === "hit") {
      if (life < 0.55) continue;
      ctx.save();
      ctx.globalAlpha *= (life - 0.55) / 0.45 * 0.7;
      ctx.strokeStyle = "#e4d2aa";
      ctx.lineWidth = 1.3;
      const at = effect.unitId ? unitPosition?.(effect.unitId) : void 0;
      const contact = at ? worldToScreen(at) : point;
      ctx.beginPath();
      ctx.moveTo(contact.x - 2, contact.y - 10);
      ctx.lineTo(contact.x + 2, contact.y - 14);
      ctx.moveTo(contact.x + 1, contact.y - 10);
      ctx.lineTo(contact.x + 3, contact.y - 9);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "attackTarget" || effect.type === "queuedAttackTarget") {
      const pulse = life * 0.5;
      ctx.setLineDash(effect.type === "queuedAttackTarget" ? [5, 5] : []);
      ctx.strokeStyle = effect.type === "queuedAttackTarget" ? `rgba(155, 47, 47, ${pulse * 0.58})` : `rgba(155, 47, 47, ${pulse})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(point.x, point.y + 10, 14, 6, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      continue;
    }
    if (effect.type === "boardingBlocked") {
      ctx.save();
      ctx.strokeStyle = "#c37639";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(point.x - 5, point.y - 12);
      ctx.lineTo(point.x + 5, point.y - 2);
      ctx.moveTo(point.x + 5, point.y - 12);
      ctx.lineTo(point.x - 5, point.y - 2);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "heal") {
      drawHealEffect(renderer, effect, point, life);
      continue;
    }
    if (effect.type === "summon") {
      drawSummonEffect(ctx, point, life);
      continue;
    }
    if (effect.type === "itemReceived") {
      ctx.save();
      ctx.globalAlpha = life;
      ctx.strokeStyle = "#ebce7e";
      ctx.fillStyle = "#6b502b";
      ctx.lineWidth = 2;
      const y = point.y - 28 - (1 - life) * 20;
      ctx.beginPath();
      ctx.ellipse(point.x, point.y, 18 + (1 - life) * 20, 9 + (1 - life) * 10, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillRect(point.x - 8, y - 6, 16, 12);
      ctx.strokeRect(point.x - 8, y - 6, 16, 12);
      ctx.beginPath();
      ctx.moveTo(point.x - 8, y - 1);
      ctx.lineTo(point.x + 8, y - 1);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "curse") {
      drawCurseEffect(ctx, point, life);
      continue;
    }
    if (effect.type === "storm") {
      drawStormEffect(ctx, effect, point, life);
      continue;
    }
    if (effect.type === "guardianField") {
      drawGuardianFieldEffect(ctx, effect, point, life);
      continue;
    }
    if (effect.type === "goldBounty") {
      drawGoldBountyEffect(ctx, point, life, effect.amount ?? 0);
      continue;
    }
    if (effect.type === "experienceBurst") {
      drawExperienceBurstEffect(ctx, point, life);
      continue;
    }
    if (effect.type === "stomp") {
      ctx.save();
      ctx.strokeStyle = `rgba(122, 96, 60, ${0.7 * life})`;
      ctx.lineWidth = 4;
      const reach = (effect.radius ?? 160) * (1.1 - life * 0.6);
      ctx.beginPath();
      ctx.ellipse(point.x, point.y + 6, reach, reach * 0.45, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "web") {
      ctx.save();
      ctx.strokeStyle = `rgba(235, 232, 220, ${0.85 * Math.min(1, life * 3)})`;
      ctx.lineWidth = 1.4;
      for (let spoke = 0; spoke < 6; spoke += 1) {
        const angle = spoke / 6 * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(point.x, point.y + 4);
        ctx.lineTo(point.x + Math.cos(angle) * 18, point.y + 4 + Math.sin(angle) * 9);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.ellipse(point.x, point.y + 4, 11, 5.5, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "bloodlust") {
      ctx.save();
      ctx.strokeStyle = `rgba(181, 52, 40, ${life})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(point.x, point.y - 10, radius * 0.8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      continue;
    }
    if (effect.type === "flameBurn" || effect.type === "scorch") {
      drawFlameBurnEffect(ctx, point, life, effect.remaining);
      continue;
    }
    ctx.lineWidth = 2;
    ctx.save();
    ctx.setLineDash(isQueuedEffect(effect.type) ? [4, 5] : []);
    ctx.strokeStyle = effect.type === "mine" || effect.type === "queuedMine" ? "#b9861b" : effect.type === "attack" || effect.type === "queuedAttack" ? "#9b2f2f" : "#243126";
    if (isQueuedEffect(effect.type)) ctx.globalAlpha *= 0.58;
    ctx.beginPath();
    ctx.globalAlpha *= life * 0.6;
    ctx.arc(point.x, point.y, 8 + (1 - life) * 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}
function isQueuedEffect(type) {
  return type === "queuedMove" || type === "queuedMine" || type === "queuedRepair" || type === "queuedAttack" || type === "queuedAttackTarget";
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVmZmVjdC1yZW5kZXJlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7UHJvamVjdGlsZU9yaWdpbn0gZnJvbSAnLi9wcm9qZWN0aWxlLW9yaWdpbnMnO1xuaW1wb3J0IHsgZHJhd0NoYWluTGlnaHRuaW5nRWZmZWN0LCBkcmF3SGVhbEVmZmVjdCwgZHJhd1N1bW1vbkVmZmVjdCwgZHJhd0N1cnNlRWZmZWN0LCBkcmF3U3Rvcm1FZmZlY3QsIGRyYXdHdWFyZGlhbkZpZWxkRWZmZWN0LCBkcmF3RXhwZXJpZW5jZUJ1cnN0RWZmZWN0LCBkcmF3RmxhbWVCdXJuRWZmZWN0LCBkcmF3UGh5c2ljYWxNaXNzaWxlLCBkcmF3QXJyb3csIGRyYXdTcGVsbE9yYiwgZHJhd1Byb2plY3RpbGVUcmFpbCwgZHJhd0NoYXJnZVRyYWlsLCBkcmF3Q2hhcmdlSW1wYWN0LCBkcmF3R29sZEJvdW50eUVmZmVjdCB9IGZyb20gXCIuL2FydC9jYW52YXMtZWZmZWN0c1wiO1xuaW1wb3J0IHsgZXN0aW1hdGVkUmlkZXIsIHJpZGVyUmFkaXVzLCBoYXNFZmZlY3RWZWN0b3IsIGNoYXJnZVRyYWlsRnJhbWUsIGNoYXJnZUltcGFjdEZyYW1lLCBwcm9qZWN0aWxlTG9vaywgbGF1bmNoUG9pbnQsIGFycm93RnJhbWUsIGlzVW5pdEtpbmQsIFRPV0VSX0FSUk9XX1NDQUxFLCBzcGVsbE9yYlBhbGV0dGUgfSBmcm9tIFwiLi9hcnQvZWZmZWN0LXByZXNlbnRhdGlvblwiO1xuaW1wb3J0IHsgZHJhd1dhcmZhcmVFZmZlY3QgfSBmcm9tIFwiLi93YXJmYXJlLWVmZmVjdHNcIjtcbmltcG9ydCB7IFNISVBfQ0FNRVJBIH0gZnJvbSBcIi4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5XCI7XG5pbXBvcnQgeyBkcmF3VmV0ZXJhbkNhc3RFZmZlY3QgfSBmcm9tICcuL2FiaWxpdHktZWZmZWN0cyc7XG5pbXBvcnQgeyBzaG91bGRSZW5kZXJDb21tYW5kRmVlZGJhY2sgfSBmcm9tICcuL2NvbW1hbmQtZmVlZGJhY2snO1xuaW1wb3J0IHR5cGUgeyBHYW1lU25hcHNob3QsIFBsYXllcklkLCBVbml0LCBXb3JsZEVmZmVjdCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcblxudHlwZSBQb2ludCA9IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfTtcblxudHlwZSBSZW5kZXJXb3JsZEVmZmVjdHNPcHRpb25zID0ge1xuICBjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRDtcbiAgZWZmZWN0czogV29ybGRFZmZlY3RbXTtcbiAgd29ybGRUb1NjcmVlbjogKHBvaW50OiBQb2ludCkgPT4gUG9pbnQ7XG4gIG5lYXJTY3JlZW46IChwb2ludDogUG9pbnQsIHBhZDogbnVtYmVyKSA9PiBib29sZWFuO1xuICAvKiogV2hlcmUgYSB1bml0IGlzIGRyYXduICh3b3JsZCBwb2ludCksIGZvciBlZmZlY3RzIHRoYXQgZm9sbG93IG9uZSAoYSBjaGFyZ2luZyByaWRlcidzIHRyYWlsKS4gKi9cbiAgdW5pdFBvc2l0aW9uPzogKHVuaXRJZDogc3RyaW5nKSA9PiBQb2ludCB8IHVuZGVmaW5lZDtcbiAgdW5pdD86ICh1bml0SWQ6c3RyaW5nKT0+VW5pdHx1bmRlZmluZWQ7XG4gIHZpZXdlcj86UGxheWVySWQgfCB1bmRlZmluZWQ7XG4gIHBsYXllcnM/OkdhbWVTbmFwc2hvdFtcInBsYXllcnNcIl07XG4gIHJlZHVjZWRNb3Rpb24/OmJvb2xlYW47XG4gIC8qKiBUaGUgZXZlbnQtZHJpdmVuIHByZXNlbnRhdGlvbiB0cmFja2VyIGFscmVhZHkgZHJhd3MgZGlyZWN0aW9uYWwgY2hhcmdlIGFjY2VudHMuICovXG4gIGNvbWJhdFRyYWlscz86Ym9vbGVhbjtcbiAgcHJvamVjdGlsZU9yaWdpbj86KGVmZmVjdDpXb3JsZEVmZmVjdCk9PlByb2plY3RpbGVPcmlnaW58dW5kZWZpbmVkO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIHJlbmRlcldvcmxkRWZmZWN0cyhvcHRpb25zOiBSZW5kZXJXb3JsZEVmZmVjdHNPcHRpb25zKSB7XG4gIGNvbnN0IHsgY3R4LCBlZmZlY3RzLCB3b3JsZFRvU2NyZWVuLCBuZWFyU2NyZWVuLCB1bml0UG9zaXRpb24gfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHJlbmRlcmVyID0geyBjdHgsIHdvcmxkVG9TY3JlZW4gfTtcbiAgZm9yIChjb25zdCBlZmZlY3Qgb2YgZWZmZWN0cykge1xuICAgIGlmKGVmZmVjdC5yZW1haW5pbmc8PTAgfHwgIXNob3VsZFJlbmRlckNvbW1hbmRGZWVkYmFjayhlZmZlY3Qsb3B0aW9ucy52aWV3ZXIpKWNvbnRpbnVlO1xuICAgIGlmIChkcmF3V2FyZmFyZUVmZmVjdChjdHgsZWZmZWN0LHdvcmxkVG9TY3JlZW4sbmVhclNjcmVlbikpIGNvbnRpbnVlO1xuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJjaGFyZ2VUcmFpbFwiICYmIGhhc0VmZmVjdFZlY3RvcihlZmZlY3QpKSB7XG4gICAgICBpZihvcHRpb25zLmNvbWJhdFRyYWlscyljb250aW51ZTtcbiAgICAgIGNvbnN0IGZyb20gPSB3b3JsZFRvU2NyZWVuKHsgeDogZWZmZWN0LmZyb21YLCB5OiBlZmZlY3QuZnJvbVkgfSk7XG4gICAgICBjb25zdCB0byA9IHdvcmxkVG9TY3JlZW4oeyB4OiBlZmZlY3QudG9YLCB5OiBlZmZlY3QudG9ZIH0pO1xuICAgICAgY29uc3QgbGlmZSA9IGVmZmVjdC5yZW1haW5pbmcgLyBlZmZlY3QuZHVyYXRpb247XG4gICAgICBjb25zdCBmb2xsb3dlZCA9IGVmZmVjdC51bml0SWQgPyB1bml0UG9zaXRpb24/LihlZmZlY3QudW5pdElkKSA6IHVuZGVmaW5lZDtcbiAgICAgIGNvbnN0IHJpZGVyID0gZm9sbG93ZWQgPyB3b3JsZFRvU2NyZWVuKGZvbGxvd2VkKSA6IGVzdGltYXRlZFJpZGVyKGZyb20sIHRvLCBsaWZlLCBlZmZlY3Quc291cmNlS2luZCk7XG4gICAgICBpZiAoIW5lYXJTY3JlZW4ocmlkZXIsIDE0MCkgJiYgIW5lYXJTY3JlZW4oZnJvbSwgMTQwKSkgY29udGludWU7XG4gICAgICBkcmF3Q2hhcmdlVHJhaWwoY3R4LCBjaGFyZ2VUcmFpbEZyYW1lKGZyb20sIHJpZGVyLCB0bywgbGlmZSwgcmlkZXJSYWRpdXMoZWZmZWN0LnNvdXJjZUtpbmQpKSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoZWZmZWN0LnR5cGUgPT09IFwiY2hhcmdlSW1wYWN0XCIgJiYgaGFzRWZmZWN0VmVjdG9yKGVmZmVjdCkpIHtcbiAgICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihlZmZlY3QpO1xuICAgICAgaWYgKCFuZWFyU2NyZWVuKHBvaW50LCA5MCkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgZnJvbSA9IHdvcmxkVG9TY3JlZW4oeyB4OiBlZmZlY3QuZnJvbVgsIHk6IGVmZmVjdC5mcm9tWSB9KTtcbiAgICAgIGRyYXdDaGFyZ2VJbXBhY3QoY3R4LCBjaGFyZ2VJbXBhY3RGcmFtZShwb2ludCwgZnJvbSwgZWZmZWN0LnJlbWFpbmluZyAvIGVmZmVjdC5kdXJhdGlvbikpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcInByb2plY3RpbGVcIiAmJiBoYXNFZmZlY3RWZWN0b3IoZWZmZWN0KSkge1xuICAgICAgY29uc3Qgb3JpZ2luPW9wdGlvbnMucHJvamVjdGlsZU9yaWdpbj8uKGVmZmVjdCk7XG4gICAgICBjb25zdCBmcm9tID0gd29ybGRUb1NjcmVlbih7IHg6IG9yaWdpbj8ueD8/ZWZmZWN0LmZyb21YLCB5OiAob3JpZ2luPy55Pz9lZmZlY3QuZnJvbVkpLShvcmlnaW4/LmhlaWdodD8/ZWZmZWN0LmZyb21IZWlnaHQ/PzApKk1hdGgudGFuKFNISVBfQ0FNRVJBLnRpbHQpIH0pO1xuICAgICAgY29uc3QgdG8gPSB3b3JsZFRvU2NyZWVuKHsgeDogZWZmZWN0LnRvWCwgeTogZWZmZWN0LnRvWS0oZWZmZWN0LnRvSGVpZ2h0ID8/IDApKk1hdGgudGFuKFNISVBfQ0FNRVJBLnRpbHQpIH0pO1xuICAgICAgaWYgKCFuZWFyU2NyZWVuKHRvLCA5MCkgJiYgIW5lYXJTY3JlZW4oZnJvbSwgOTApKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IHByb2dyZXNzID0gMSAtIGVmZmVjdC5yZW1haW5pbmcgLyBlZmZlY3QuZHVyYXRpb247XG4gICAgICBjb25zdCBsb29rID0gcHJvamVjdGlsZUxvb2soZWZmZWN0LnNvdXJjZUtpbmQsZWZmZWN0LmF0dGFja0tpbmQpO1xuICAgICAgaWYgKGxvb2sgIT09IFwic3RyZWFrXCIpIHtcbiAgICAgICAgY29uc3Qgc291cmNlS2luZCA9IGVmZmVjdC5zb3VyY2VLaW5kO1xuICAgICAgICBjb25zdCBsYXVuY2ggPSBvcmlnaW4gPyBmcm9tIDogc291cmNlS2luZCA/IGxhdW5jaFBvaW50KGZyb20sIHRvLCBzb3VyY2VLaW5kKSA6IGZyb207XG4gICAgICAgIGlmIChsb29rID09PSBcImFycm93XCIpIGRyYXdBcnJvdyhjdHgsIGFycm93RnJhbWUobGF1bmNoLCB0bywgcHJvZ3Jlc3MsICFzb3VyY2VLaW5kIHx8IGlzVW5pdEtpbmQoc291cmNlS2luZCkgPyAxIDogVE9XRVJfQVJST1dfU0NBTEUpKTtcbiAgICAgICAgZWxzZSBpZiAobG9vayA9PT0gXCJvcmJcIikgZHJhd1NwZWxsT3JiKGN0eCwgbGF1bmNoLCB0bywgcHJvZ3Jlc3MsIHNwZWxsT3JiUGFsZXR0ZShzb3VyY2VLaW5kLCBlZmZlY3Qub3duZXIgPyBvcHRpb25zLnBsYXllcnM/LltlZmZlY3Qub3duZXJdPy5yYWNlIDogdW5kZWZpbmVkKSk7XG4gICAgICAgIGVsc2UgZHJhd1BoeXNpY2FsTWlzc2lsZShjdHgsIGxhdW5jaCwgdG8sIHByb2dyZXNzLCBsb29rKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCBoZWFkID0ge1xuICAgICAgICB4OiBmcm9tLnggKyAodG8ueCAtIGZyb20ueCkgKiBwcm9ncmVzcyxcbiAgICAgICAgeTogZnJvbS55ICsgKHRvLnkgLSBmcm9tLnkpICogcHJvZ3Jlc3MsXG4gICAgICB9O1xuICAgICAgZHJhd1Byb2plY3RpbGVUcmFpbChjdHgsIGZyb20sIHRvLCBoZWFkLCBwcm9ncmVzcywgZWZmZWN0LnJlbWFpbmluZyAvIGVmZmVjdC5kdXJhdGlvbik7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICAvLyBUaGUgdW5pdCBwb3NlIGNhcnJpZXMgd2VhcG9uIHN3aW5ncyBhbmQgcmVhbCB3b3JrIHN0cm9rZXMuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcIm1lbGVlXCIgfHwgZWZmZWN0LnR5cGUgPT09IFwicmVwYWlyXCIgfHwgZWZmZWN0LnR5cGUgPT09IFwiYnVpbGRcIikgY29udGludWU7XG5cbiAgICBpZiAoZWZmZWN0LnR5cGUgPT09IFwiY2hhaW5MaWdodG5pbmdcIiAmJiBoYXNFZmZlY3RWZWN0b3IoZWZmZWN0KSkge1xuICAgICAgY29uc3QgZnJvbSA9IHdvcmxkVG9TY3JlZW4oeyB4OiBlZmZlY3QuZnJvbVgsIHk6IGVmZmVjdC5mcm9tWSB9KTtcbiAgICAgIGNvbnN0IHRvID0gd29ybGRUb1NjcmVlbih7IHg6IGVmZmVjdC50b1gsIHk6IGVmZmVjdC50b1kgfSk7XG4gICAgICBpZiAoIW5lYXJTY3JlZW4odG8sIDEyMCkgJiYgIW5lYXJTY3JlZW4oZnJvbSwgMTIwKSkgY29udGludWU7XG4gICAgICBkcmF3Q2hhaW5MaWdodG5pbmdFZmZlY3QoY3R4LCBlZmZlY3QsIGZyb20sIHRvKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGNvbnN0IHBvaW50ID0gd29ybGRUb1NjcmVlbihlZmZlY3QpO1xuICAgIGNvbnN0IHBhZCA9IGVmZmVjdC50eXBlID09PSBcImd1YXJkaWFuRmllbGRcIiB8fCBlZmZlY3QudHlwZSA9PT0gXCJzdG9ybVwiID8gKGVmZmVjdC5yYWRpdXMgPz8gKGVmZmVjdC50eXBlID09PSBcImd1YXJkaWFuRmllbGRcIiA/IDI4MCA6IDE0NSkpICsgODAgOiA5MDtcbiAgICBpZiAoIW5lYXJTY3JlZW4ocG9pbnQsIHBhZCkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxpZmUgPSBlZmZlY3QucmVtYWluaW5nIC8gZWZmZWN0LmR1cmF0aW9uO1xuICAgIGNvbnN0IHJhZGl1cyA9IDkgKyAoMSAtIGxpZmUpICogMjI7XG4gICAgY29uc3QgY2FzdGVyPWVmZmVjdC51bml0SWQ/b3B0aW9ucy51bml0Py4oZWZmZWN0LnVuaXRJZCk6dW5kZWZpbmVkO1xuICAgIGNvbnN0IGNhc3RlclBvaW50PWVmZmVjdC5yYWRpdXMgJiYgZWZmZWN0LnVuaXRJZCA/IHVuaXRQb3NpdGlvbj8uKGVmZmVjdC51bml0SWQpIDogdW5kZWZpbmVkO1xuICAgIGlmKGRyYXdWZXRlcmFuQ2FzdEVmZmVjdChjdHgsZWZmZWN0LGNhc3RlcixjYXN0ZXJQb2ludD93b3JsZFRvU2NyZWVuKGNhc3RlclBvaW50KTpwb2ludCxvcHRpb25zLnJlZHVjZWRNb3Rpb24pKWNvbnRpbnVlO1xuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcImhpdFwiKSB7XG4gICAgICAvLyBCcmllZiwgbG9jYWwgY29udGFjdCBnbGludCwgbm8gZXhwYW5kaW5nIGNyb3NzIGFjcm9zcyBhZGphY2VudCB0cm9vcHMuXG4gICAgICBpZiAobGlmZSA8IC41NSkgY29udGludWU7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4Lmdsb2JhbEFscGhhICo9IChsaWZlLS41NSkvLjQ1Ki43O1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gXCIjZTRkMmFhXCI7IGN0eC5saW5lV2lkdGggPSAxLjM7XG4gICAgICBjb25zdCBhdCA9IGVmZmVjdC51bml0SWQgPyB1bml0UG9zaXRpb24/LihlZmZlY3QudW5pdElkKSA6IHVuZGVmaW5lZDtcbiAgICAgIGNvbnN0IGNvbnRhY3QgPSBhdCA/IHdvcmxkVG9TY3JlZW4oYXQpIDogcG9pbnQ7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHgubW92ZVRvKGNvbnRhY3QueC0yLGNvbnRhY3QueS0xMCk7Y3R4LmxpbmVUbyhjb250YWN0LngrMixjb250YWN0LnktMTQpO1xuICAgICAgY3R4Lm1vdmVUbyhjb250YWN0LngrMSxjb250YWN0LnktMTApO2N0eC5saW5lVG8oY29udGFjdC54KzMsY29udGFjdC55LTkpO1xuICAgICAgY3R4LnN0cm9rZSgpO2N0eC5yZXN0b3JlKCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoZWZmZWN0LnR5cGUgPT09IFwiYXR0YWNrVGFyZ2V0XCIgfHwgZWZmZWN0LnR5cGUgPT09IFwicXVldWVkQXR0YWNrVGFyZ2V0XCIpIHtcbiAgICAgIGNvbnN0IHB1bHNlID0gbGlmZSAqIC41O1xuICAgICAgY3R4LnNldExpbmVEYXNoKGVmZmVjdC50eXBlID09PSBcInF1ZXVlZEF0dGFja1RhcmdldFwiID8gWzUsIDVdIDogW10pO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gZWZmZWN0LnR5cGUgPT09IFwicXVldWVkQXR0YWNrVGFyZ2V0XCIgPyBgcmdiYSgxNTUsIDQ3LCA0NywgJHtwdWxzZSAqIDAuNTh9KWAgOiBgcmdiYSgxNTUsIDQ3LCA0NywgJHtwdWxzZX0pYDtcbiAgICAgIGN0eC5saW5lV2lkdGggPSAzO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LmVsbGlwc2UocG9pbnQueCwgcG9pbnQueSArIDEwLCAxNCwgNiwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgY3R4LnNldExpbmVEYXNoKFtdKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJib2FyZGluZ0Jsb2NrZWRcIikge1xuICAgICAgY3R4LnNhdmUoKTtcbiAgICAgIGN0eC5zdHJva2VTdHlsZSA9IFwiI2MzNzYzOVwiOyBjdHgubGluZVdpZHRoID0gMjtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTsgY3R4Lm1vdmVUbyhwb2ludC54LTUscG9pbnQueS0xMik7IGN0eC5saW5lVG8ocG9pbnQueCs1LHBvaW50LnktMik7XG4gICAgICBjdHgubW92ZVRvKHBvaW50LngrNSxwb2ludC55LTEyKTsgY3R4LmxpbmVUbyhwb2ludC54LTUscG9pbnQueS0yKTsgY3R4LnN0cm9rZSgpOyBjdHgucmVzdG9yZSgpOyBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcImhlYWxcIikge1xuICAgICAgZHJhd0hlYWxFZmZlY3QocmVuZGVyZXIsIGVmZmVjdCwgcG9pbnQsIGxpZmUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcInN1bW1vblwiKSB7XG4gICAgICBkcmF3U3VtbW9uRWZmZWN0KGN0eCwgcG9pbnQsIGxpZmUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYoZWZmZWN0LnR5cGU9PT1cIml0ZW1SZWNlaXZlZFwiKXtcbiAgICAgIGN0eC5zYXZlKCk7Y3R4Lmdsb2JhbEFscGhhPWxpZmU7Y3R4LnN0cm9rZVN0eWxlPVwiI2ViY2U3ZVwiO2N0eC5maWxsU3R5bGU9XCIjNmI1MDJiXCI7Y3R4LmxpbmVXaWR0aD0yO1xuICAgICAgY29uc3QgeT1wb2ludC55LTI4LSgxLWxpZmUpKjIwO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO2N0eC5lbGxpcHNlKHBvaW50LngscG9pbnQueSwxOCsoMS1saWZlKSoyMCw5KygxLWxpZmUpKjEwLDAsMCxNYXRoLlBJKjIpO2N0eC5zdHJva2UoKTtcbiAgICAgIGN0eC5maWxsUmVjdChwb2ludC54LTgseS02LDE2LDEyKTtjdHguc3Ryb2tlUmVjdChwb2ludC54LTgseS02LDE2LDEyKTtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtjdHgubW92ZVRvKHBvaW50LngtOCx5LTEpO2N0eC5saW5lVG8ocG9pbnQueCs4LHktMSk7Y3R4LnN0cm9rZSgpO2N0eC5yZXN0b3JlKCk7Y29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcImN1cnNlXCIpIHtcbiAgICAgIGRyYXdDdXJzZUVmZmVjdChjdHgsIHBvaW50LCBsaWZlKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJzdG9ybVwiKSB7XG4gICAgICBkcmF3U3Rvcm1FZmZlY3QoY3R4LCBlZmZlY3QsIHBvaW50LCBsaWZlKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJndWFyZGlhbkZpZWxkXCIpIHtcbiAgICAgIGRyYXdHdWFyZGlhbkZpZWxkRWZmZWN0KGN0eCwgZWZmZWN0LCBwb2ludCwgbGlmZSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoZWZmZWN0LnR5cGUgPT09IFwiZ29sZEJvdW50eVwiKSB7XG4gICAgICBkcmF3R29sZEJvdW50eUVmZmVjdChjdHgsIHBvaW50LCBsaWZlLCBlZmZlY3QuYW1vdW50ID8/IDApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcImV4cGVyaWVuY2VCdXJzdFwiKSB7XG4gICAgICBkcmF3RXhwZXJpZW5jZUJ1cnN0RWZmZWN0KGN0eCwgcG9pbnQsIGxpZmUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgLy8gVGhlIGNyZWVwcycgcG93ZXJzIChzZWUgQEBAY3JlZXAtYWJpbGl0aWVzKTogYSBzdG9tcCdzIGR1c3QgcmluZywgYSB3ZWIncyBzdHJhbmRzLCBibG9vZGx1c3QncyByZWQgZmxhcmUuXG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcInN0b21wXCIpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSBgcmdiYSgxMjIsIDk2LCA2MCwgJHswLjcgKiBsaWZlfSlgO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDQ7XG4gICAgICBjb25zdCByZWFjaCA9IChlZmZlY3QucmFkaXVzID8/IDE2MCkgKiAoMS4xIC0gbGlmZSAqIDAuNik7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHguZWxsaXBzZShwb2ludC54LCBwb2ludC55ICsgNiwgcmVhY2gsIHJlYWNoICogMC40NSwgMCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoZWZmZWN0LnR5cGUgPT09IFwid2ViXCIpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSBgcmdiYSgyMzUsIDIzMiwgMjIwLCAkezAuODUgKiBNYXRoLm1pbigxLCBsaWZlICogMyl9KWA7XG4gICAgICBjdHgubGluZVdpZHRoID0gMS40O1xuICAgICAgZm9yIChsZXQgc3Bva2UgPSAwOyBzcG9rZSA8IDY7IHNwb2tlICs9IDEpIHtcbiAgICAgICAgY29uc3QgYW5nbGUgPSAoc3Bva2UgLyA2KSAqIE1hdGguUEkgKiAyO1xuICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIGN0eC5tb3ZlVG8ocG9pbnQueCwgcG9pbnQueSArIDQpO1xuICAgICAgICBjdHgubGluZVRvKHBvaW50LnggKyBNYXRoLmNvcyhhbmdsZSkgKiAxOCwgcG9pbnQueSArIDQgKyBNYXRoLnNpbihhbmdsZSkgKiA5KTtcbiAgICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgfVxuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LmVsbGlwc2UocG9pbnQueCwgcG9pbnQueSArIDQsIDExLCA1LjUsIDAsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgIGN0eC5zdHJva2UoKTtcbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGVmZmVjdC50eXBlID09PSBcImJsb29kbHVzdFwiKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gYHJnYmEoMTgxLCA1MiwgNDAsICR7bGlmZX0pYDtcbiAgICAgIGN0eC5saW5lV2lkdGggPSAzO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LmFyYyhwb2ludC54LCBwb2ludC55IC0gMTAsIHJhZGl1cyAqIDAuOCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChlZmZlY3QudHlwZSA9PT0gXCJmbGFtZUJ1cm5cIiB8fCBlZmZlY3QudHlwZSA9PT0gXCJzY29yY2hcIikge1xuICAgICAgZHJhd0ZsYW1lQnVybkVmZmVjdChjdHgsIHBvaW50LCBsaWZlLCBlZmZlY3QucmVtYWluaW5nKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGN0eC5saW5lV2lkdGggPSAyO1xuICAgIGN0eC5zYXZlKCk7XG4gICAgY3R4LnNldExpbmVEYXNoKGlzUXVldWVkRWZmZWN0KGVmZmVjdC50eXBlKSA/IFs0LCA1XSA6IFtdKTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSBlZmZlY3QudHlwZSA9PT0gXCJtaW5lXCIgfHwgZWZmZWN0LnR5cGUgPT09IFwicXVldWVkTWluZVwiID8gXCIjYjk4NjFiXCIgOiBlZmZlY3QudHlwZSA9PT0gXCJhdHRhY2tcIiB8fCBlZmZlY3QudHlwZSA9PT0gXCJxdWV1ZWRBdHRhY2tcIiA/IFwiIzliMmYyZlwiIDogXCIjMjQzMTI2XCI7XG4gICAgaWYgKGlzUXVldWVkRWZmZWN0KGVmZmVjdC50eXBlKSkgY3R4Lmdsb2JhbEFscGhhICo9IDAuNTg7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5nbG9iYWxBbHBoYSAqPSBsaWZlICogLjY7XG4gICAgY3R4LmFyYyhwb2ludC54LCBwb2ludC55LCA4ICsgKDEtbGlmZSkqMywgMCwgTWF0aC5QSSAqIDIpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGlzUXVldWVkRWZmZWN0KHR5cGU6IFdvcmxkRWZmZWN0W1widHlwZVwiXSkge1xuICByZXR1cm4gdHlwZSA9PT0gXCJxdWV1ZWRNb3ZlXCIgfHwgdHlwZSA9PT0gXCJxdWV1ZWRNaW5lXCIgfHwgdHlwZSA9PT0gXCJxdWV1ZWRSZXBhaXJcIiB8fCB0eXBlID09PSBcInF1ZXVlZEF0dGFja1wiIHx8IHR5cGUgPT09IFwicXVldWVkQXR0YWNrVGFyZ2V0XCI7XG59XG4iXSwibWFwcGluZ3MiOiJBQUNBLFNBQVMsMEJBQTBCLGdCQUFnQixrQkFBa0IsaUJBQWlCLGlCQUFpQix5QkFBeUIsMkJBQTJCLHFCQUFxQixxQkFBcUIsV0FBVyxjQUFjLHFCQUFxQixpQkFBaUIsa0JBQWtCLDRCQUE0QjtBQUNsVCxTQUFTLGdCQUFnQixhQUFhLGlCQUFpQixrQkFBa0IsbUJBQW1CLGdCQUFnQixhQUFhLFlBQVksWUFBWSxtQkFBbUIsdUJBQXVCO0FBQzNMLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsNkJBQTZCO0FBQ3RDLFNBQVMsbUNBQW1DO0FBcUJyQyxnQkFBUyxtQkFBbUIsU0FBb0M7QUFDckUsUUFBTSxFQUFFLEtBQUssU0FBUyxlQUFlLFlBQVksYUFBYSxJQUFJO0FBQ2xFLFFBQU0sV0FBVyxFQUFFLEtBQUssY0FBYztBQUN0QyxhQUFXLFVBQVUsU0FBUztBQUM1QixRQUFHLE9BQU8sYUFBVyxLQUFLLENBQUMsNEJBQTRCLFFBQU8sUUFBUSxNQUFNLEVBQUU7QUFDOUUsUUFBSSxrQkFBa0IsS0FBSSxRQUFPLGVBQWMsVUFBVSxFQUFHO0FBQzVELFFBQUksT0FBTyxTQUFTLGlCQUFpQixnQkFBZ0IsTUFBTSxHQUFHO0FBQzVELFVBQUcsUUFBUSxhQUFhO0FBQ3hCLFlBQU0sT0FBTyxjQUFjLEVBQUUsR0FBRyxPQUFPLE9BQU8sR0FBRyxPQUFPLE1BQU0sQ0FBQztBQUMvRCxZQUFNLEtBQUssY0FBYyxFQUFFLEdBQUcsT0FBTyxLQUFLLEdBQUcsT0FBTyxJQUFJLENBQUM7QUFDekQsWUFBTUEsUUFBTyxPQUFPLFlBQVksT0FBTztBQUN2QyxZQUFNLFdBQVcsT0FBTyxTQUFTLGVBQWUsT0FBTyxNQUFNLElBQUk7QUFDakUsWUFBTSxRQUFRLFdBQVcsY0FBYyxRQUFRLElBQUksZUFBZSxNQUFNLElBQUlBLE9BQU0sT0FBTyxVQUFVO0FBQ25HLFVBQUksQ0FBQyxXQUFXLE9BQU8sR0FBRyxLQUFLLENBQUMsV0FBVyxNQUFNLEdBQUcsRUFBRztBQUN2RCxzQkFBZ0IsS0FBSyxpQkFBaUIsTUFBTSxPQUFPLElBQUlBLE9BQU0sWUFBWSxPQUFPLFVBQVUsQ0FBQyxDQUFDO0FBQzVGO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLGtCQUFrQixnQkFBZ0IsTUFBTSxHQUFHO0FBQzdELFlBQU1DLFNBQVEsY0FBYyxNQUFNO0FBQ2xDLFVBQUksQ0FBQyxXQUFXQSxRQUFPLEVBQUUsRUFBRztBQUM1QixZQUFNLE9BQU8sY0FBYyxFQUFFLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxNQUFNLENBQUM7QUFDL0QsdUJBQWlCLEtBQUssa0JBQWtCQSxRQUFPLE1BQU0sT0FBTyxZQUFZLE9BQU8sUUFBUSxDQUFDO0FBQ3hGO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLGdCQUFnQixnQkFBZ0IsTUFBTSxHQUFHO0FBQzNELFlBQU0sU0FBTyxRQUFRLG1CQUFtQixNQUFNO0FBQzlDLFlBQU0sT0FBTyxjQUFjLEVBQUUsR0FBRyxRQUFRLEtBQUcsT0FBTyxPQUFPLElBQUksUUFBUSxLQUFHLE9BQU8sVUFBUSxRQUFRLFVBQVEsT0FBTyxjQUFZLEtBQUcsS0FBSyxJQUFJLFlBQVksSUFBSSxFQUFFLENBQUM7QUFDekosWUFBTSxLQUFLLGNBQWMsRUFBRSxHQUFHLE9BQU8sS0FBSyxHQUFHLE9BQU8sT0FBSyxPQUFPLFlBQVksS0FBRyxLQUFLLElBQUksWUFBWSxJQUFJLEVBQUUsQ0FBQztBQUMzRyxVQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsS0FBSyxDQUFDLFdBQVcsTUFBTSxFQUFFLEVBQUc7QUFDbEQsWUFBTSxXQUFXLElBQUksT0FBTyxZQUFZLE9BQU87QUFDL0MsWUFBTSxPQUFPLGVBQWUsT0FBTyxZQUFXLE9BQU8sVUFBVTtBQUMvRCxVQUFJLFNBQVMsVUFBVTtBQUNyQixjQUFNLGFBQWEsT0FBTztBQUMxQixjQUFNLFNBQVMsU0FBUyxPQUFPLGFBQWEsWUFBWSxNQUFNLElBQUksVUFBVSxJQUFJO0FBQ2hGLFlBQUksU0FBUyxRQUFTLFdBQVUsS0FBSyxXQUFXLFFBQVEsSUFBSSxVQUFVLENBQUMsY0FBYyxXQUFXLFVBQVUsSUFBSSxJQUFJLGlCQUFpQixDQUFDO0FBQUEsaUJBQzNILFNBQVMsTUFBTyxjQUFhLEtBQUssUUFBUSxJQUFJLFVBQVUsZ0JBQWdCLFlBQVksT0FBTyxRQUFRLFFBQVEsVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPLE1BQVMsQ0FBQztBQUFBLFlBQ3pKLHFCQUFvQixLQUFLLFFBQVEsSUFBSSxVQUFVLElBQUk7QUFDeEQ7QUFBQSxNQUNGO0FBQ0EsWUFBTSxPQUFPO0FBQUEsUUFDWCxHQUFHLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLO0FBQUEsUUFDOUIsR0FBRyxLQUFLLEtBQUssR0FBRyxJQUFJLEtBQUssS0FBSztBQUFBLE1BQ2hDO0FBQ0EsMEJBQW9CLEtBQUssTUFBTSxJQUFJLE1BQU0sVUFBVSxPQUFPLFlBQVksT0FBTyxRQUFRO0FBQ3JGO0FBQUEsSUFDRjtBQUdBLFFBQUksT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFFBQVM7QUFFcEYsUUFBSSxPQUFPLFNBQVMsb0JBQW9CLGdCQUFnQixNQUFNLEdBQUc7QUFDL0QsWUFBTSxPQUFPLGNBQWMsRUFBRSxHQUFHLE9BQU8sT0FBTyxHQUFHLE9BQU8sTUFBTSxDQUFDO0FBQy9ELFlBQU0sS0FBSyxjQUFjLEVBQUUsR0FBRyxPQUFPLEtBQUssR0FBRyxPQUFPLElBQUksQ0FBQztBQUN6RCxVQUFJLENBQUMsV0FBVyxJQUFJLEdBQUcsS0FBSyxDQUFDLFdBQVcsTUFBTSxHQUFHLEVBQUc7QUFDcEQsK0JBQXlCLEtBQUssUUFBUSxNQUFNLEVBQUU7QUFDOUM7QUFBQSxJQUNGO0FBRUEsVUFBTSxRQUFRLGNBQWMsTUFBTTtBQUNsQyxVQUFNLE1BQU0sT0FBTyxTQUFTLG1CQUFtQixPQUFPLFNBQVMsV0FBVyxPQUFPLFdBQVcsT0FBTyxTQUFTLGtCQUFrQixNQUFNLFFBQVEsS0FBSztBQUNqSixRQUFJLENBQUMsV0FBVyxPQUFPLEdBQUcsRUFBRztBQUM3QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU87QUFDdkMsVUFBTSxTQUFTLEtBQUssSUFBSSxRQUFRO0FBQ2hDLFVBQU0sU0FBTyxPQUFPLFNBQU8sUUFBUSxPQUFPLE9BQU8sTUFBTSxJQUFFO0FBQ3pELFVBQU0sY0FBWSxPQUFPLFVBQVUsT0FBTyxTQUFTLGVBQWUsT0FBTyxNQUFNLElBQUk7QUFDbkYsUUFBRyxzQkFBc0IsS0FBSSxRQUFPLFFBQU8sY0FBWSxjQUFjLFdBQVcsSUFBRSxPQUFNLFFBQVEsYUFBYSxFQUFFO0FBRS9HLFFBQUksT0FBTyxTQUFTLE9BQU87QUFFekIsVUFBSSxPQUFPLEtBQUs7QUFDaEIsVUFBSSxLQUFLO0FBQ1QsVUFBSSxnQkFBZ0IsT0FBSyxRQUFLLE9BQUk7QUFDbEMsVUFBSSxjQUFjO0FBQVcsVUFBSSxZQUFZO0FBQzdDLFlBQU0sS0FBSyxPQUFPLFNBQVMsZUFBZSxPQUFPLE1BQU0sSUFBSTtBQUMzRCxZQUFNLFVBQVUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUN6QyxVQUFJLFVBQVU7QUFDZCxVQUFJLE9BQU8sUUFBUSxJQUFFLEdBQUUsUUFBUSxJQUFFLEVBQUU7QUFBRSxVQUFJLE9BQU8sUUFBUSxJQUFFLEdBQUUsUUFBUSxJQUFFLEVBQUU7QUFDeEUsVUFBSSxPQUFPLFFBQVEsSUFBRSxHQUFFLFFBQVEsSUFBRSxFQUFFO0FBQUUsVUFBSSxPQUFPLFFBQVEsSUFBRSxHQUFFLFFBQVEsSUFBRSxDQUFDO0FBQ3ZFLFVBQUksT0FBTztBQUFFLFVBQUksUUFBUTtBQUN6QjtBQUFBLElBQ0Y7QUFFQSxRQUFJLE9BQU8sU0FBUyxrQkFBa0IsT0FBTyxTQUFTLHNCQUFzQjtBQUMxRSxZQUFNLFFBQVEsT0FBTztBQUNyQixVQUFJLFlBQVksT0FBTyxTQUFTLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsRSxVQUFJLGNBQWMsT0FBTyxTQUFTLHVCQUF1QixxQkFBcUIsUUFBUSxJQUFJLE1BQU0scUJBQXFCLEtBQUs7QUFDMUgsVUFBSSxZQUFZO0FBQ2hCLFVBQUksVUFBVTtBQUNkLFVBQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUMzRCxVQUFJLE9BQU87QUFDWCxVQUFJLFlBQVksQ0FBQyxDQUFDO0FBQ2xCO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLG1CQUFtQjtBQUNyQyxVQUFJLEtBQUs7QUFDVCxVQUFJLGNBQWM7QUFBVyxVQUFJLFlBQVk7QUFDN0MsVUFBSSxVQUFVO0FBQUcsVUFBSSxPQUFPLE1BQU0sSUFBRSxHQUFFLE1BQU0sSUFBRSxFQUFFO0FBQUcsVUFBSSxPQUFPLE1BQU0sSUFBRSxHQUFFLE1BQU0sSUFBRSxDQUFDO0FBQ2pGLFVBQUksT0FBTyxNQUFNLElBQUUsR0FBRSxNQUFNLElBQUUsRUFBRTtBQUFHLFVBQUksT0FBTyxNQUFNLElBQUUsR0FBRSxNQUFNLElBQUUsQ0FBQztBQUFHLFVBQUksT0FBTztBQUFHLFVBQUksUUFBUTtBQUFHO0FBQUEsSUFDbEc7QUFDQSxRQUFJLE9BQU8sU0FBUyxRQUFRO0FBQzFCLHFCQUFlLFVBQVUsUUFBUSxPQUFPLElBQUk7QUFDNUM7QUFBQSxJQUNGO0FBRUEsUUFBSSxPQUFPLFNBQVMsVUFBVTtBQUM1Qix1QkFBaUIsS0FBSyxPQUFPLElBQUk7QUFDakM7QUFBQSxJQUNGO0FBRUEsUUFBRyxPQUFPLFNBQU8sZ0JBQWU7QUFDOUIsVUFBSSxLQUFLO0FBQUUsVUFBSSxjQUFZO0FBQUssVUFBSSxjQUFZO0FBQVUsVUFBSSxZQUFVO0FBQVUsVUFBSSxZQUFVO0FBQ2hHLFlBQU0sSUFBRSxNQUFNLElBQUUsTUFBSSxJQUFFLFFBQU07QUFDNUIsVUFBSSxVQUFVO0FBQUUsVUFBSSxRQUFRLE1BQU0sR0FBRSxNQUFNLEdBQUUsTUFBSSxJQUFFLFFBQU0sSUFBRyxLQUFHLElBQUUsUUFBTSxJQUFHLEdBQUUsR0FBRSxLQUFLLEtBQUcsQ0FBQztBQUFFLFVBQUksT0FBTztBQUNuRyxVQUFJLFNBQVMsTUFBTSxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUcsRUFBRTtBQUFFLFVBQUksV0FBVyxNQUFNLElBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRyxFQUFFO0FBQ3BFLFVBQUksVUFBVTtBQUFFLFVBQUksT0FBTyxNQUFNLElBQUUsR0FBRSxJQUFFLENBQUM7QUFBRSxVQUFJLE9BQU8sTUFBTSxJQUFFLEdBQUUsSUFBRSxDQUFDO0FBQUUsVUFBSSxPQUFPO0FBQUUsVUFBSSxRQUFRO0FBQUU7QUFBQSxJQUNqRztBQUVBLFFBQUksT0FBTyxTQUFTLFNBQVM7QUFDM0Isc0JBQWdCLEtBQUssT0FBTyxJQUFJO0FBQ2hDO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLFNBQVM7QUFDM0Isc0JBQWdCLEtBQUssUUFBUSxPQUFPLElBQUk7QUFDeEM7QUFBQSxJQUNGO0FBRUEsUUFBSSxPQUFPLFNBQVMsaUJBQWlCO0FBQ25DLDhCQUF3QixLQUFLLFFBQVEsT0FBTyxJQUFJO0FBQ2hEO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLGNBQWM7QUFDaEMsMkJBQXFCLEtBQUssT0FBTyxNQUFNLE9BQU8sVUFBVSxDQUFDO0FBQ3pEO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLG1CQUFtQjtBQUNyQyxnQ0FBMEIsS0FBSyxPQUFPLElBQUk7QUFDMUM7QUFBQSxJQUNGO0FBR0EsUUFBSSxPQUFPLFNBQVMsU0FBUztBQUMzQixVQUFJLEtBQUs7QUFDVCxVQUFJLGNBQWMscUJBQXFCLE1BQU0sSUFBSTtBQUNqRCxVQUFJLFlBQVk7QUFDaEIsWUFBTSxTQUFTLE9BQU8sVUFBVSxRQUFRLE1BQU0sT0FBTztBQUNyRCxVQUFJLFVBQVU7QUFDZCxVQUFJLFFBQVEsTUFBTSxHQUFHLE1BQU0sSUFBSSxHQUFHLE9BQU8sUUFBUSxNQUFNLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN4RSxVQUFJLE9BQU87QUFDWCxVQUFJLFFBQVE7QUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sU0FBUyxPQUFPO0FBQ3pCLFVBQUksS0FBSztBQUNULFVBQUksY0FBYyx1QkFBdUIsT0FBTyxLQUFLLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQztBQUNyRSxVQUFJLFlBQVk7QUFDaEIsZUFBUyxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUN6QyxjQUFNLFFBQVMsUUFBUSxJQUFLLEtBQUssS0FBSztBQUN0QyxZQUFJLFVBQVU7QUFDZCxZQUFJLE9BQU8sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQy9CLFlBQUksT0FBTyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksQ0FBQztBQUM1RSxZQUFJLE9BQU87QUFBQSxNQUNiO0FBQ0EsVUFBSSxVQUFVO0FBQ2QsVUFBSSxRQUFRLE1BQU0sR0FBRyxNQUFNLElBQUksR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzVELFVBQUksT0FBTztBQUNYLFVBQUksUUFBUTtBQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxTQUFTLGFBQWE7QUFDL0IsVUFBSSxLQUFLO0FBQ1QsVUFBSSxjQUFjLHFCQUFxQixJQUFJO0FBQzNDLFVBQUksWUFBWTtBQUNoQixVQUFJLFVBQVU7QUFDZCxVQUFJLElBQUksTUFBTSxHQUFHLE1BQU0sSUFBSSxJQUFJLFNBQVMsS0FBSyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQzNELFVBQUksT0FBTztBQUNYLFVBQUksUUFBUTtBQUNaO0FBQUEsSUFDRjtBQUVBLFFBQUksT0FBTyxTQUFTLGVBQWUsT0FBTyxTQUFTLFVBQVU7QUFDM0QsMEJBQW9CLEtBQUssT0FBTyxNQUFNLE9BQU8sU0FBUztBQUN0RDtBQUFBLElBQ0Y7QUFFQSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxLQUFLO0FBQ1QsUUFBSSxZQUFZLGVBQWUsT0FBTyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekQsUUFBSSxjQUFjLE9BQU8sU0FBUyxVQUFVLE9BQU8sU0FBUyxlQUFlLFlBQVksT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLGlCQUFpQixZQUFZO0FBQ2hLLFFBQUksZUFBZSxPQUFPLElBQUksRUFBRyxLQUFJLGVBQWU7QUFDcEQsUUFBSSxVQUFVO0FBQ2QsUUFBSSxlQUFlLE9BQU87QUFDMUIsUUFBSSxJQUFJLE1BQU0sR0FBRyxNQUFNLEdBQUcsS0FBSyxJQUFFLFFBQU0sR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0FBQ3hELFFBQUksT0FBTztBQUNYLFFBQUksUUFBUTtBQUFBLEVBQ2Q7QUFDRjtBQUVBLFNBQVMsZUFBZSxNQUEyQjtBQUNqRCxTQUFPLFNBQVMsZ0JBQWdCLFNBQVMsZ0JBQWdCLFNBQVMsa0JBQWtCLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUg7IiwibmFtZXMiOlsibGlmZSIsInBvaW50Il19