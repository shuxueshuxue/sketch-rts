import { createScratchCanvas } from "/@fs/tmp/sketch-queue-source-42bd/src/client/art/scratch-canvas.ts";
export class FittedPortraitCache {
  constructor(budget = 12 * 1024 * 1024, limit = 96) {
    this.budget = budget;
    this.limit = limit;
  }
  cache = /* @__PURE__ */ new Map();
  work = [];
  leased = /* @__PURE__ */ new Map();
  retired = /* @__PURE__ */ new Set();
  epoch = 0;
  retire(canvas) {
    if (this.leased.has(canvas)) this.retired.add(canvas);
    else canvas.width = canvas.height = 1;
  }
  lease(canvas) {
    this.leased.set(canvas, (this.leased.get(canvas) ?? 0) + 1);
  }
  release(canvas) {
    const count = this.leased.get(canvas) ?? 0;
    if (count > 1) {
      this.leased.set(canvas, count - 1);
      return;
    }
    this.leased.delete(canvas);
    if (this.retired.delete(canvas)) this.retire(canvas);
  }
  draw(ctx, key, paint, x, y, width, height, bust = false, domain = 128) {
    const workSize = domain * 4;
    let art = this.cache.get(key), source;
    const epoch = this.epoch;
    try {
      if (!art) {
        const reusable = this.work.findIndex((canvas) => canvas.width === workSize);
        source = reusable < 0 ? createScratchCanvas(workSize, workSize) : this.work.splice(reusable, 1)[0];
        this.lease(source);
        const brush = source.getContext("2d");
        if (typeof brush.reset === "function") brush.reset();
        else source.width = workSize;
        brush.translate(workSize / 2, workSize / 2);
        brush.scale(4, 4);
        paint(brush);
        const data = brush.getImageData(0, 0, workSize, workSize).data;
        const bounds = (limit = workSize) => {
          let left = workSize, top = workSize, right = 0, bottom = 0;
          for (let py = 0; py < limit; py++) for (let px = 0; px < workSize; px++) if (data[(py * workSize + px) * 4 + 3] > 8) {
            left = Math.min(left, px);
            right = Math.max(right, px);
            top = Math.min(top, py);
            bottom = Math.max(bottom, py);
          }
          return { x: left, y: top, width: Math.max(1, right - left + 1), height: Math.max(1, bottom - top + 1) };
        };
        let box = bounds();
        if (bust) box = bounds(Math.round(box.y + box.height * 0.65));
        const cropped = createScratchCanvas(box.width, box.height);
        this.lease(cropped);
        art = { canvas: cropped, x: 0, y: 0, width: box.width, height: box.height };
        cropped.getContext("2d").drawImage(source, box.x, box.y, box.width, box.height, 0, 0, box.width, box.height);
        const prior = this.cache.get(key);
        if (epoch === this.epoch && prior) {
          this.cache.delete(key);
          this.retire(prior.canvas);
        }
        let pixels = [...this.cache.values()].reduce((sum, value) => sum + value.width * value.height, 0);
        const cost = box.width * box.height;
        while (epoch === this.epoch && this.cache.size && (this.cache.size >= this.limit || pixels + cost > this.budget)) {
          const oldest = this.cache.keys().next().value, value = this.cache.get(oldest);
          pixels -= value.width * value.height;
          this.cache.delete(oldest);
          this.retire(value.canvas);
        }
        if (epoch === this.epoch && cost <= this.budget && this.limit > 0) this.cache.set(key, art);
        else this.retire(cropped);
      } else this.lease(art.canvas);
      const scale = Math.min(width / art.width, height / art.height) * 0.94, w = art.width * scale, h = art.height * scale;
      ctx.drawImage(art.canvas, art.x, art.y, art.width, art.height, x + (width - w) / 2, y + (height - h) / 2, w, h);
    } finally {
      if (art) {
        if (this.cache.get(key) !== art) this.retire(art.canvas);
        this.release(art.canvas);
      }
      if (source) {
        this.release(source);
        if (epoch === this.epoch && this.work.length < 4) this.work.push(source);
        else this.retire(source);
      }
    }
  }
  clear() {
    this.epoch++;
    for (const art of this.cache.values()) this.retire(art.canvas);
    for (const canvas of this.work) this.retire(canvas);
    this.cache.clear();
    this.work.length = 0;
  }
  stats() {
    const cached = new Set([...this.cache.values()].map((art) => art.canvas));
    const owned = /* @__PURE__ */ new Set([...cached, ...this.work, ...this.leased.keys(), ...this.retired]);
    const bytes = (canvases) => {
      let n = 0;
      for (const canvas of canvases) n += canvas.width * canvas.height * 4;
      return n;
    };
    return { entries: this.cache.size, cacheBytes: bytes(cached), workCanvases: this.work.length, workBytes: bytes(this.work), leasedCanvases: this.leased.size, leasedBytes: bytes(this.leased.keys()), retiredCanvases: this.retired.size, retiredBytes: bytes(this.retired), ownedCanvasBytes: bytes(owned) };
  }
}
const portraits = new FittedPortraitCache();
export const drawFittedPortrait = portraits.draw.bind(portraits);
export const clearFittedPortraits = () => portraits.clear();
export const fittedPortraitStats = () => portraits.stats();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBvcnRyYWl0LWZpdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2NyZWF0ZVNjcmF0Y2hDYW52YXN9IGZyb20gJy4vc2NyYXRjaC1jYW52YXMnO1xudHlwZSBBcnQ9e2NhbnZhczpIVE1MQ2FudmFzRWxlbWVudDt4Om51bWJlcjt5Om51bWJlcjt3aWR0aDpudW1iZXI7aGVpZ2h0Om51bWJlcn07XG5cbi8qKiBPd25zIG9ubHkgVUkgcG9ydHJhaXQgcGl4ZWxzLiBEcmF3cyBmaW5pc2ggc3luY2hyb25vdXNseTsgbmVzdGVkIHBhaW50ZXJzXG4gKiByZWNlaXZlIHNlcGFyYXRlIHdvcmsgc3VyZmFjZXMgYW5kIGNhbm5vdCByZXRpcmUgYSBwYXJlbnQncyBib3Jyb3dlZCBpbWFnZS4gKi9cbmV4cG9ydCBjbGFzcyBGaXR0ZWRQb3J0cmFpdENhY2hlIHtcbiAgcHJpdmF0ZSBjYWNoZT1uZXcgTWFwPHN0cmluZyxBcnQ+KCk7XG4gIHByaXZhdGUgd29yazpIVE1MQ2FudmFzRWxlbWVudFtdPVtdO1xuICBwcml2YXRlIGxlYXNlZD1uZXcgTWFwPEhUTUxDYW52YXNFbGVtZW50LG51bWJlcj4oKTtcbiAgcHJpdmF0ZSByZXRpcmVkPW5ldyBTZXQ8SFRNTENhbnZhc0VsZW1lbnQ+KCk7XG4gIHByaXZhdGUgZXBvY2g9MDtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBidWRnZXQ9MTIqMTAyNCoxMDI0LHByaXZhdGUgbGltaXQ9OTYpe31cbiAgcHJpdmF0ZSByZXRpcmUoY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXtcbiAgICBpZih0aGlzLmxlYXNlZC5oYXMoY2FudmFzKSl0aGlzLnJldGlyZWQuYWRkKGNhbnZhcyk7XG4gICAgZWxzZSBjYW52YXMud2lkdGg9Y2FudmFzLmhlaWdodD0xO1xuICB9XG4gIHByaXZhdGUgbGVhc2UoY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXt0aGlzLmxlYXNlZC5zZXQoY2FudmFzLCh0aGlzLmxlYXNlZC5nZXQoY2FudmFzKT8/MCkrMSk7fVxuICBwcml2YXRlIHJlbGVhc2UoY2FudmFzOkhUTUxDYW52YXNFbGVtZW50KXtcbiAgICBjb25zdCBjb3VudD10aGlzLmxlYXNlZC5nZXQoY2FudmFzKT8/MDtpZihjb3VudD4xKXt0aGlzLmxlYXNlZC5zZXQoY2FudmFzLGNvdW50LTEpO3JldHVybjt9XG4gICAgdGhpcy5sZWFzZWQuZGVsZXRlKGNhbnZhcyk7XG4gICAgaWYodGhpcy5yZXRpcmVkLmRlbGV0ZShjYW52YXMpKXRoaXMucmV0aXJlKGNhbnZhcyk7XG4gIH1cbiAgZHJhdyhjdHg6Q2FudmFzUmVuZGVyaW5nQ29udGV4dDJELGtleTpzdHJpbmcscGFpbnQ6KGN0eDpDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQpPT52b2lkLHg6bnVtYmVyLHk6bnVtYmVyLHdpZHRoOm51bWJlcixoZWlnaHQ6bnVtYmVyLGJ1c3Q9ZmFsc2UsZG9tYWluPTEyOCl7XG4gICAgY29uc3Qgd29ya1NpemU9ZG9tYWluKjQ7XG4gICAgbGV0IGFydD10aGlzLmNhY2hlLmdldChrZXkpLHNvdXJjZTpIVE1MQ2FudmFzRWxlbWVudHx1bmRlZmluZWQ7XG4gICAgY29uc3QgZXBvY2g9dGhpcy5lcG9jaDtcbiAgICB0cnl7XG4gICAgICBpZighYXJ0KXtcbiAgICAgICAgY29uc3QgcmV1c2FibGU9dGhpcy53b3JrLmZpbmRJbmRleChjYW52YXM9PmNhbnZhcy53aWR0aD09PXdvcmtTaXplKTtcbiAgICAgICAgc291cmNlPXJldXNhYmxlPDA/Y3JlYXRlU2NyYXRjaENhbnZhcyh3b3JrU2l6ZSx3b3JrU2l6ZSk6dGhpcy53b3JrLnNwbGljZShyZXVzYWJsZSwxKVswXSE7dGhpcy5sZWFzZShzb3VyY2UpO1xuICAgICAgICBjb25zdCBicnVzaD1zb3VyY2UuZ2V0Q29udGV4dCgnMmQnKSE7XG4gICAgICAgIC8vIEtlZXAgdGhlIG9yaWdpbmFsIGZyZXNoLWNhbnZhcyBkZWZhdWx0cywgaW5jbHVkaW5nIG1pdGVyIGpvaW5zIGFuZFxuICAgICAgICAvLyB0aGUgYWxwaGE+OC9idXN0IG1lYXN1cmVtZW50LiBEbyBub3QgYm9ycm93IHdvcmxkIHJhc3RlciBzZXR0aW5ncy5cbiAgICAgICAgaWYodHlwZW9mIGJydXNoLnJlc2V0PT09J2Z1bmN0aW9uJylicnVzaC5yZXNldCgpO2Vsc2Ugc291cmNlLndpZHRoPXdvcmtTaXplO1xuICAgICAgICBicnVzaC50cmFuc2xhdGUod29ya1NpemUvMix3b3JrU2l6ZS8yKTticnVzaC5zY2FsZSg0LDQpO3BhaW50KGJydXNoKTtcbiAgICAgICAgY29uc3QgZGF0YT1icnVzaC5nZXRJbWFnZURhdGEoMCwwLHdvcmtTaXplLHdvcmtTaXplKS5kYXRhO1xuICAgICAgICBjb25zdCBib3VuZHM9KGxpbWl0PXdvcmtTaXplKT0+e2xldCBsZWZ0PXdvcmtTaXplLHRvcD13b3JrU2l6ZSxyaWdodD0wLGJvdHRvbT0wO1xuICAgICAgICAgIGZvcihsZXQgcHk9MDtweTxsaW1pdDtweSsrKWZvcihsZXQgcHg9MDtweDx3b3JrU2l6ZTtweCsrKWlmKGRhdGFbKHB5KndvcmtTaXplK3B4KSo0KzNdIT44KXtsZWZ0PU1hdGgubWluKGxlZnQscHgpO3JpZ2h0PU1hdGgubWF4KHJpZ2h0LHB4KTt0b3A9TWF0aC5taW4odG9wLHB5KTtib3R0b209TWF0aC5tYXgoYm90dG9tLHB5KTt9XG4gICAgICAgICAgcmV0dXJue3g6bGVmdCx5OnRvcCx3aWR0aDpNYXRoLm1heCgxLHJpZ2h0LWxlZnQrMSksaGVpZ2h0Ok1hdGgubWF4KDEsYm90dG9tLXRvcCsxKX07XG4gICAgICAgIH07XG4gICAgICAgIGxldCBib3g9Ym91bmRzKCk7aWYoYnVzdClib3g9Ym91bmRzKE1hdGgucm91bmQoYm94LnkrYm94LmhlaWdodCouNjUpKTtcbiAgICAgICAgY29uc3QgY3JvcHBlZD1jcmVhdGVTY3JhdGNoQ2FudmFzKGJveC53aWR0aCxib3guaGVpZ2h0KTt0aGlzLmxlYXNlKGNyb3BwZWQpO1xuICAgICAgICBhcnQ9e2NhbnZhczpjcm9wcGVkLHg6MCx5OjAsd2lkdGg6Ym94LndpZHRoLGhlaWdodDpib3guaGVpZ2h0fTtcbiAgICAgICAgY3JvcHBlZC5nZXRDb250ZXh0KCcyZCcpIS5kcmF3SW1hZ2Uoc291cmNlLGJveC54LGJveC55LGJveC53aWR0aCxib3guaGVpZ2h0LDAsMCxib3gud2lkdGgsYm94LmhlaWdodCk7XG4gICAgICAgIGNvbnN0IHByaW9yPXRoaXMuY2FjaGUuZ2V0KGtleSk7XG4gICAgICAgIGlmKGVwb2NoPT09dGhpcy5lcG9jaCAmJiBwcmlvcil7dGhpcy5jYWNoZS5kZWxldGUoa2V5KTt0aGlzLnJldGlyZShwcmlvci5jYW52YXMpO31cbiAgICAgICAgbGV0IHBpeGVscz1bLi4udGhpcy5jYWNoZS52YWx1ZXMoKV0ucmVkdWNlKChzdW0sdmFsdWUpPT5zdW0rdmFsdWUud2lkdGgqdmFsdWUuaGVpZ2h0LDApO1xuICAgICAgICBjb25zdCBjb3N0PWJveC53aWR0aCpib3guaGVpZ2h0O1xuICAgICAgICB3aGlsZShlcG9jaD09PXRoaXMuZXBvY2ggJiYgdGhpcy5jYWNoZS5zaXplICYmICh0aGlzLmNhY2hlLnNpemU+PXRoaXMubGltaXQgfHwgcGl4ZWxzK2Nvc3Q+dGhpcy5idWRnZXQpKXtcbiAgICAgICAgICBjb25zdCBvbGRlc3Q9dGhpcy5jYWNoZS5rZXlzKCkubmV4dCgpLnZhbHVlISx2YWx1ZT10aGlzLmNhY2hlLmdldChvbGRlc3QpITtcbiAgICAgICAgICBwaXhlbHMtPXZhbHVlLndpZHRoKnZhbHVlLmhlaWdodDt0aGlzLmNhY2hlLmRlbGV0ZShvbGRlc3QpO3RoaXMucmV0aXJlKHZhbHVlLmNhbnZhcyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYoZXBvY2g9PT10aGlzLmVwb2NoICYmIGNvc3Q8PXRoaXMuYnVkZ2V0ICYmIHRoaXMubGltaXQ+MCl0aGlzLmNhY2hlLnNldChrZXksYXJ0KTtcbiAgICAgICAgZWxzZSB0aGlzLnJldGlyZShjcm9wcGVkKTtcbiAgICAgIH1lbHNlIHRoaXMubGVhc2UoYXJ0LmNhbnZhcyk7XG4gICAgICBjb25zdCBzY2FsZT1NYXRoLm1pbih3aWR0aC9hcnQud2lkdGgsaGVpZ2h0L2FydC5oZWlnaHQpKi45NCx3PWFydC53aWR0aCpzY2FsZSxoPWFydC5oZWlnaHQqc2NhbGU7XG4gICAgICBjdHguZHJhd0ltYWdlKGFydC5jYW52YXMsYXJ0LngsYXJ0LnksYXJ0LndpZHRoLGFydC5oZWlnaHQseCsod2lkdGgtdykvMix5KyhoZWlnaHQtaCkvMix3LGgpO1xuICAgIH1maW5hbGx5e1xuICAgICAgaWYoYXJ0KXtpZih0aGlzLmNhY2hlLmdldChrZXkpIT09YXJ0KXRoaXMucmV0aXJlKGFydC5jYW52YXMpO3RoaXMucmVsZWFzZShhcnQuY2FudmFzKTt9XG4gICAgICBpZihzb3VyY2Upe3RoaXMucmVsZWFzZShzb3VyY2UpO2lmKGVwb2NoPT09dGhpcy5lcG9jaCAmJiB0aGlzLndvcmsubGVuZ3RoPDQpdGhpcy53b3JrLnB1c2goc291cmNlKTtlbHNlIHRoaXMucmV0aXJlKHNvdXJjZSk7fVxuICAgIH1cbiAgfVxuICBjbGVhcigpe1xuICAgIHRoaXMuZXBvY2grKztcbiAgICBmb3IoY29uc3QgYXJ0IG9mIHRoaXMuY2FjaGUudmFsdWVzKCkpdGhpcy5yZXRpcmUoYXJ0LmNhbnZhcyk7XG4gICAgZm9yKGNvbnN0IGNhbnZhcyBvZiB0aGlzLndvcmspdGhpcy5yZXRpcmUoY2FudmFzKTtcbiAgICB0aGlzLmNhY2hlLmNsZWFyKCk7dGhpcy53b3JrLmxlbmd0aD0wO1xuICB9XG4gIHN0YXRzKCl7XG4gICAgY29uc3QgY2FjaGVkPW5ldyBTZXQoWy4uLnRoaXMuY2FjaGUudmFsdWVzKCldLm1hcChhcnQ9PmFydC5jYW52YXMpKTtcbiAgICBjb25zdCBvd25lZD1uZXcgU2V0KFsuLi5jYWNoZWQsLi4udGhpcy53b3JrLC4uLnRoaXMubGVhc2VkLmtleXMoKSwuLi50aGlzLnJldGlyZWRdKTtcbiAgICBjb25zdCBieXRlcz0oY2FudmFzZXM6SXRlcmFibGU8SFRNTENhbnZhc0VsZW1lbnQ+KT0+e2xldCBuPTA7Zm9yKGNvbnN0IGNhbnZhcyBvZiBjYW52YXNlcyluKz1jYW52YXMud2lkdGgqY2FudmFzLmhlaWdodCo0O3JldHVybiBuO307XG4gICAgcmV0dXJue2VudHJpZXM6dGhpcy5jYWNoZS5zaXplLGNhY2hlQnl0ZXM6Ynl0ZXMoY2FjaGVkKSx3b3JrQ2FudmFzZXM6dGhpcy53b3JrLmxlbmd0aCx3b3JrQnl0ZXM6Ynl0ZXModGhpcy53b3JrKSxsZWFzZWRDYW52YXNlczp0aGlzLmxlYXNlZC5zaXplLGxlYXNlZEJ5dGVzOmJ5dGVzKHRoaXMubGVhc2VkLmtleXMoKSkscmV0aXJlZENhbnZhc2VzOnRoaXMucmV0aXJlZC5zaXplLHJldGlyZWRCeXRlczpieXRlcyh0aGlzLnJldGlyZWQpLG93bmVkQ2FudmFzQnl0ZXM6Ynl0ZXMob3duZWQpfTtcbiAgfVxufVxuY29uc3QgcG9ydHJhaXRzPW5ldyBGaXR0ZWRQb3J0cmFpdENhY2hlKCk7XG4vKiogTWVhc3VyZSBwYWludGVkIHBpeGVscyBvbmNlLCB0aGVuIGZpdCB0aGUgc3ViamVjdCB0byBhbnkgVUkgcmVjdGFuZ2xlLiAqL1xuZXhwb3J0IGNvbnN0IGRyYXdGaXR0ZWRQb3J0cmFpdD1wb3J0cmFpdHMuZHJhdy5iaW5kKHBvcnRyYWl0cyk7XG5leHBvcnQgY29uc3QgY2xlYXJGaXR0ZWRQb3J0cmFpdHM9KCk9PnBvcnRyYWl0cy5jbGVhcigpO1xuZXhwb3J0IGNvbnN0IGZpdHRlZFBvcnRyYWl0U3RhdHM9KCk9PnBvcnRyYWl0cy5zdGF0cygpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFRLDJCQUEwQjtBQUszQixhQUFNLG9CQUFvQjtBQUFBLEVBTS9CLFlBQW9CLFNBQU8sS0FBRyxPQUFLLE1BQWEsUUFBTSxJQUFHO0FBQXJDO0FBQTRCO0FBQUEsRUFBVTtBQUFBLEVBTGxELFFBQU0sb0JBQUksSUFBZ0I7QUFBQSxFQUMxQixPQUF5QixDQUFDO0FBQUEsRUFDMUIsU0FBTyxvQkFBSSxJQUE4QjtBQUFBLEVBQ3pDLFVBQVEsb0JBQUksSUFBdUI7QUFBQSxFQUNuQyxRQUFNO0FBQUEsRUFFTixPQUFPLFFBQXlCO0FBQ3RDLFFBQUcsS0FBSyxPQUFPLElBQUksTUFBTSxFQUFFLE1BQUssUUFBUSxJQUFJLE1BQU07QUFBQSxRQUM3QyxRQUFPLFFBQU0sT0FBTyxTQUFPO0FBQUEsRUFDbEM7QUFBQSxFQUNRLE1BQU0sUUFBeUI7QUFBQyxTQUFLLE9BQU8sSUFBSSxTQUFRLEtBQUssT0FBTyxJQUFJLE1BQU0sS0FBRyxLQUFHLENBQUM7QUFBQSxFQUFFO0FBQUEsRUFDdkYsUUFBUSxRQUF5QjtBQUN2QyxVQUFNLFFBQU0sS0FBSyxPQUFPLElBQUksTUFBTSxLQUFHO0FBQUUsUUFBRyxRQUFNLEdBQUU7QUFBQyxXQUFLLE9BQU8sSUFBSSxRQUFPLFFBQU0sQ0FBQztBQUFFO0FBQUEsSUFBTztBQUMxRixTQUFLLE9BQU8sT0FBTyxNQUFNO0FBQ3pCLFFBQUcsS0FBSyxRQUFRLE9BQU8sTUFBTSxFQUFFLE1BQUssT0FBTyxNQUFNO0FBQUEsRUFDbkQ7QUFBQSxFQUNBLEtBQUssS0FBNkIsS0FBVyxPQUEyQyxHQUFTLEdBQVMsT0FBYSxRQUFjLE9BQUssT0FBTSxTQUFPLEtBQUk7QUFDekosVUFBTSxXQUFTLFNBQU87QUFDdEIsUUFBSSxNQUFJLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRTtBQUM1QixVQUFNLFFBQU0sS0FBSztBQUNqQixRQUFHO0FBQ0QsVUFBRyxDQUFDLEtBQUk7QUFDTixjQUFNLFdBQVMsS0FBSyxLQUFLLFVBQVUsWUFBUSxPQUFPLFVBQVEsUUFBUTtBQUNsRSxpQkFBTyxXQUFTLElBQUUsb0JBQW9CLFVBQVMsUUFBUSxJQUFFLEtBQUssS0FBSyxPQUFPLFVBQVMsQ0FBQyxFQUFFLENBQUM7QUFBRyxhQUFLLE1BQU0sTUFBTTtBQUMzRyxjQUFNLFFBQU0sT0FBTyxXQUFXLElBQUk7QUFHbEMsWUFBRyxPQUFPLE1BQU0sVUFBUSxXQUFXLE9BQU0sTUFBTTtBQUFBLFlBQU8sUUFBTyxRQUFNO0FBQ25FLGNBQU0sVUFBVSxXQUFTLEdBQUUsV0FBUyxDQUFDO0FBQUUsY0FBTSxNQUFNLEdBQUUsQ0FBQztBQUFFLGNBQU0sS0FBSztBQUNuRSxjQUFNLE9BQUssTUFBTSxhQUFhLEdBQUUsR0FBRSxVQUFTLFFBQVEsRUFBRTtBQUNyRCxjQUFNLFNBQU8sQ0FBQyxRQUFNLGFBQVc7QUFBQyxjQUFJLE9BQUssVUFBUyxNQUFJLFVBQVMsUUFBTSxHQUFFLFNBQU87QUFDNUUsbUJBQVEsS0FBRyxHQUFFLEtBQUcsT0FBTSxLQUFLLFVBQVEsS0FBRyxHQUFFLEtBQUcsVUFBUyxLQUFLLEtBQUcsTUFBTSxLQUFHLFdBQVMsTUFBSSxJQUFFLENBQUMsSUFBRyxHQUFFO0FBQUMsbUJBQUssS0FBSyxJQUFJLE1BQUssRUFBRTtBQUFFLG9CQUFNLEtBQUssSUFBSSxPQUFNLEVBQUU7QUFBRSxrQkFBSSxLQUFLLElBQUksS0FBSSxFQUFFO0FBQUUscUJBQU8sS0FBSyxJQUFJLFFBQU8sRUFBRTtBQUFBLFVBQUU7QUFDM0wsaUJBQU0sRUFBQyxHQUFFLE1BQUssR0FBRSxLQUFJLE9BQU0sS0FBSyxJQUFJLEdBQUUsUUFBTSxPQUFLLENBQUMsR0FBRSxRQUFPLEtBQUssSUFBSSxHQUFFLFNBQU8sTUFBSSxDQUFDLEVBQUM7QUFBQSxRQUNwRjtBQUNBLFlBQUksTUFBSSxPQUFPO0FBQUUsWUFBRyxLQUFLLE9BQUksT0FBTyxLQUFLLE1BQU0sSUFBSSxJQUFFLElBQUksU0FBTyxJQUFHLENBQUM7QUFDcEUsY0FBTSxVQUFRLG9CQUFvQixJQUFJLE9BQU0sSUFBSSxNQUFNO0FBQUUsYUFBSyxNQUFNLE9BQU87QUFDMUUsY0FBSSxFQUFDLFFBQU8sU0FBUSxHQUFFLEdBQUUsR0FBRSxHQUFFLE9BQU0sSUFBSSxPQUFNLFFBQU8sSUFBSSxPQUFNO0FBQzdELGdCQUFRLFdBQVcsSUFBSSxFQUFHLFVBQVUsUUFBTyxJQUFJLEdBQUUsSUFBSSxHQUFFLElBQUksT0FBTSxJQUFJLFFBQU8sR0FBRSxHQUFFLElBQUksT0FBTSxJQUFJLE1BQU07QUFDcEcsY0FBTSxRQUFNLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDOUIsWUFBRyxVQUFRLEtBQUssU0FBUyxPQUFNO0FBQUMsZUFBSyxNQUFNLE9BQU8sR0FBRztBQUFFLGVBQUssT0FBTyxNQUFNLE1BQU07QUFBQSxRQUFFO0FBQ2pGLFlBQUksU0FBTyxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFJLFVBQVEsTUFBSSxNQUFNLFFBQU0sTUFBTSxRQUFPLENBQUM7QUFDdEYsY0FBTSxPQUFLLElBQUksUUFBTSxJQUFJO0FBQ3pCLGVBQU0sVUFBUSxLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxNQUFNLFFBQU0sS0FBSyxTQUFTLFNBQU8sT0FBSyxLQUFLLFNBQVE7QUFDdEcsZ0JBQU0sU0FBTyxLQUFLLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLFFBQU0sS0FBSyxNQUFNLElBQUksTUFBTTtBQUN4RSxvQkFBUSxNQUFNLFFBQU0sTUFBTTtBQUFPLGVBQUssTUFBTSxPQUFPLE1BQU07QUFBRSxlQUFLLE9BQU8sTUFBTSxNQUFNO0FBQUEsUUFDckY7QUFDQSxZQUFHLFVBQVEsS0FBSyxTQUFTLFFBQU0sS0FBSyxVQUFVLEtBQUssUUFBTSxFQUFFLE1BQUssTUFBTSxJQUFJLEtBQUksR0FBRztBQUFBLFlBQzVFLE1BQUssT0FBTyxPQUFPO0FBQUEsTUFDMUIsTUFBTSxNQUFLLE1BQU0sSUFBSSxNQUFNO0FBQzNCLFlBQU0sUUFBTSxLQUFLLElBQUksUUFBTSxJQUFJLE9BQU0sU0FBTyxJQUFJLE1BQU0sSUFBRSxNQUFJLElBQUUsSUFBSSxRQUFNLE9BQU0sSUFBRSxJQUFJLFNBQU87QUFDM0YsVUFBSSxVQUFVLElBQUksUUFBTyxJQUFJLEdBQUUsSUFBSSxHQUFFLElBQUksT0FBTSxJQUFJLFFBQU8sS0FBRyxRQUFNLEtBQUcsR0FBRSxLQUFHLFNBQU8sS0FBRyxHQUFFLEdBQUUsQ0FBQztBQUFBLElBQzVGLFVBQUM7QUFDQyxVQUFHLEtBQUk7QUFBQyxZQUFHLEtBQUssTUFBTSxJQUFJLEdBQUcsTUFBSSxJQUFJLE1BQUssT0FBTyxJQUFJLE1BQU07QUFBRSxhQUFLLFFBQVEsSUFBSSxNQUFNO0FBQUEsTUFBRTtBQUN0RixVQUFHLFFBQU87QUFBQyxhQUFLLFFBQVEsTUFBTTtBQUFFLFlBQUcsVUFBUSxLQUFLLFNBQVMsS0FBSyxLQUFLLFNBQU8sRUFBRSxNQUFLLEtBQUssS0FBSyxNQUFNO0FBQUEsWUFBTyxNQUFLLE9BQU8sTUFBTTtBQUFBLE1BQUU7QUFBQSxJQUM5SDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFFBQU87QUFDTCxTQUFLO0FBQ0wsZUFBVSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUUsTUFBSyxPQUFPLElBQUksTUFBTTtBQUMzRCxlQUFVLFVBQVUsS0FBSyxLQUFLLE1BQUssT0FBTyxNQUFNO0FBQ2hELFNBQUssTUFBTSxNQUFNO0FBQUUsU0FBSyxLQUFLLFNBQU87QUFBQSxFQUN0QztBQUFBLEVBQ0EsUUFBTztBQUNMLFVBQU0sU0FBTyxJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssTUFBTSxPQUFPLENBQUMsRUFBRSxJQUFJLFNBQUssSUFBSSxNQUFNLENBQUM7QUFDbEUsVUFBTSxRQUFNLG9CQUFJLElBQUksQ0FBQyxHQUFHLFFBQU8sR0FBRyxLQUFLLE1BQUssR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFFLEdBQUcsS0FBSyxPQUFPLENBQUM7QUFDbEYsVUFBTSxRQUFNLENBQUMsYUFBdUM7QUFBQyxVQUFJLElBQUU7QUFBRSxpQkFBVSxVQUFVLFNBQVMsTUFBRyxPQUFPLFFBQU0sT0FBTyxTQUFPO0FBQUUsYUFBTztBQUFBLElBQUU7QUFDbkksV0FBTSxFQUFDLFNBQVEsS0FBSyxNQUFNLE1BQUssWUFBVyxNQUFNLE1BQU0sR0FBRSxjQUFhLEtBQUssS0FBSyxRQUFPLFdBQVUsTUFBTSxLQUFLLElBQUksR0FBRSxnQkFBZSxLQUFLLE9BQU8sTUFBSyxhQUFZLE1BQU0sS0FBSyxPQUFPLEtBQUssQ0FBQyxHQUFFLGlCQUFnQixLQUFLLFFBQVEsTUFBSyxjQUFhLE1BQU0sS0FBSyxPQUFPLEdBQUUsa0JBQWlCLE1BQU0sS0FBSyxFQUFDO0FBQUEsRUFDelI7QUFDRjtBQUNBLE1BQU0sWUFBVSxJQUFJLG9CQUFvQjtBQUVqQyxhQUFNLHFCQUFtQixVQUFVLEtBQUssS0FBSyxTQUFTO0FBQ3RELGFBQU0sdUJBQXFCLE1BQUksVUFBVSxNQUFNO0FBQy9DLGFBQU0sc0JBQW9CLE1BQUksVUFBVSxNQUFNOyIsIm5hbWVzIjpbXX0=