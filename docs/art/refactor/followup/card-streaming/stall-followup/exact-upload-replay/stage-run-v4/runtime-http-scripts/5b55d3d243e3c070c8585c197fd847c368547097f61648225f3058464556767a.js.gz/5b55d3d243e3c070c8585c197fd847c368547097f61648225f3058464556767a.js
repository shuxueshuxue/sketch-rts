export class CardRasterCache {
  constructor(budget = 16 * 1024 * 1024) {
    this.budget = budget;
  }
  entries = /* @__PURE__ */ new Map();
  bytes = 0;
  scratch = new Uint32Array(0);
  hits = 0;
  misses = 0;
  evictions = 0;
  bypass = 0;
  backoffs = 0;
  churnBytes = 0;
  windowWorkMs = 0;
  windowSavedMs = 0;
  workMs = 0;
  savedMs = 0;
  get(key) {
    if (this.bypass > 0) {
      this.bypass--;
      this.misses++;
      return void 0;
    }
    const entry = this.entries.get(key);
    if (!entry) {
      this.misses++;
      return void 0;
    }
    const start = performance.now();
    this.hits++;
    this.entries.delete(key);
    this.entries.set(key, entry);
    const rgba = new Uint8ClampedArray(entry.width * entry.height * 4), words = new Uint32Array(rgba.buffer);
    let source = 0;
    for (let i = 0; i < entry.spans.length; i += 2) {
      let destination = entry.spans[i] / 4;
      const end = destination + entry.spans[i + 1] / 4;
      while (destination < end) {
        const code = entry.pixels[source++], count = code & 2147483647;
        if (code >>> 31) words.fill(entry.pixels[source++], destination, destination + count);
        else {
          words.set(entry.pixels.subarray(source, source + count), destination);
          source += count;
        }
        destination += count;
      }
    }
    const work = performance.now() - start;
    this.workMs += work;
    this.windowWorkMs += work;
    this.savedMs += entry.paintMs;
    this.windowSavedMs += entry.paintMs;
    return rgba;
  }
  put(key, rgba, width, height, paintMs = 0) {
    if (this.bypass > 0 || !this.budget || this.entries.has(key)) return;
    const start = performance.now();
    try {
      const words = new Uint32Array(rgba.byteOffset % 4 === 0 ? rgba.buffer : rgba.slice().buffer, rgba.byteOffset % 4 === 0 ? rgba.byteOffset : 0, rgba.byteLength / 4);
      const nonzero = (pixel) => words[pixel] !== 0;
      const spans = [];
      let count = 0;
      for (let y = 0; y < height; y++) {
        const row = y * width;
        let left = 0, right = width - 1;
        while (left < width && !nonzero(row + left)) left++;
        if (left === width) continue;
        while (right > left && !nonzero(row + right)) right--;
        const length = (right - left + 1) * 4;
        spans.push((row + left) * 4, length);
        count += length;
      }
      if (spans.length * 8 > this.budget) return;
      const capacity = count / 4 + spans.length / 2;
      if (this.scratch.length < capacity) this.scratch = new Uint32Array(2 ** Math.ceil(Math.log2(capacity)));
      let written = 0;
      for (let i = 0; i < spans.length; i += 2) {
        let cursor = spans[i] / 4;
        const end = cursor + spans[i + 1] / 4;
        while (cursor < end) {
          let run = 1;
          while (cursor + run < end && words[cursor + run] === words[cursor]) run++;
          if (run >= 3) {
            this.scratch[written++] = (run | 2147483648) >>> 0;
            this.scratch[written++] = words[cursor];
            cursor += run;
          } else {
            const first = cursor;
            cursor += run;
            while (cursor < end) {
              if (cursor + 2 < end && words[cursor] === words[cursor + 1] && words[cursor] === words[cursor + 2]) break;
              cursor++;
            }
            this.scratch[written++] = cursor - first;
            this.scratch.set(words.subarray(first, cursor), written);
            written += cursor - first;
          }
        }
      }
      const bytes = written * 4 + spans.length * 4;
      if (bytes > this.budget) return;
      while (this.bytes + bytes > this.budget && this.entries.size) {
        const oldest = this.entries.keys().next().value, entry = this.entries.get(oldest);
        this.bytes -= entry.bytes;
        this.churnBytes += entry.bytes;
        this.entries.delete(oldest);
        this.evictions++;
      }
      if (this.entries.size >= 1024) {
        const oldest = this.entries.keys().next().value;
        this.churnBytes += this.entries.get(oldest).bytes;
        this.bytes -= this.entries.get(oldest).bytes;
        this.entries.delete(oldest);
        this.evictions++;
      }
      const pixels = this.scratch.slice(0, written);
      this.entries.set(key, { width, height, spans: new Uint32Array(spans), pixels, bytes, paintMs });
      this.bytes += bytes;
    } finally {
      const work = performance.now() - start;
      this.workMs += work;
      this.windowWorkMs += work;
      if (this.churnBytes >= this.budget * 2 && this.windowSavedMs < this.windowWorkMs) {
        this.release();
        this.bypass = Math.min(16384, 4096 * 2 ** this.backoffs);
        this.backoffs++;
        this.churnBytes = this.windowWorkMs = this.windowSavedMs = 0;
      }
    }
  }
  release() {
    this.entries.clear();
    this.bytes = 0;
    this.scratch = new Uint32Array(0);
  }
  clear() {
    this.release();
    this.bypass = this.backoffs = this.churnBytes = this.windowWorkMs = this.windowSavedMs = 0;
  }
  stats() {
    return { backoffs: this.backoffs, bypassRequests: this.bypass, workMs: this.workMs, avoidedPaintMs: this.savedMs, bytes: this.bytes, scratchBytes: this.scratch.byteLength, ownedBytes: this.bytes + this.scratch.byteLength, entries: this.entries.size, hits: this.hits, misses: this.misses, evictions: this.evictions, budget: this.budget };
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcmQtcmFzdGVyLWNhY2hlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBMb3NzbGVzcyBDUFUgcmVjb3Zlcnkgb2YgZXhwZW5zaXZlIGNhcmRzIGV2aWN0ZWQgZnJvbSB0aGUgc21hbGxlciBHUFUgY2FjaGUuXG4gKiBPbmx5IHplcm8gUkdCQSBwYWRkaW5nIGlzIG9taXR0ZWQuIE5vIHJlc2FtcGxpbmcsIGZpbHRlcmluZyBvciBhbHBoYSBjdXRvZmYuICovXG50eXBlIFJhc3Rlcj17d2lkdGg6bnVtYmVyO2hlaWdodDpudW1iZXI7c3BhbnM6VWludDMyQXJyYXk7cGl4ZWxzOlVpbnQzMkFycmF5O2J5dGVzOm51bWJlcjtwYWludE1zOm51bWJlcn07XG5leHBvcnQgY2xhc3MgQ2FyZFJhc3RlckNhY2hlIHtcbiBwcml2YXRlIGVudHJpZXM9bmV3IE1hcDxzdHJpbmcsUmFzdGVyPigpO1xuIHByaXZhdGUgYnl0ZXM9MDtcbiBwcml2YXRlIHNjcmF0Y2g9bmV3IFVpbnQzMkFycmF5KDApO1xuIHByaXZhdGUgaGl0cz0wO1xuIHByaXZhdGUgbWlzc2VzPTA7XG4gcHJpdmF0ZSBldmljdGlvbnM9MDtcbiBwcml2YXRlIGJ5cGFzcz0wO1xuIHByaXZhdGUgYmFja29mZnM9MDtcbiBwcml2YXRlIGNodXJuQnl0ZXM9MDtcbiBwcml2YXRlIHdpbmRvd1dvcmtNcz0wO1xuIHByaXZhdGUgd2luZG93U2F2ZWRNcz0wO1xuIHByaXZhdGUgd29ya01zPTA7XG4gcHJpdmF0ZSBzYXZlZE1zPTA7XG4gY29uc3RydWN0b3IocHJpdmF0ZSBidWRnZXQ9MTYqMTAyNCoxMDI0KXt9XG4gZ2V0KGtleTpzdHJpbmcpe1xuICBpZih0aGlzLmJ5cGFzcz4wKXt0aGlzLmJ5cGFzcy0tO3RoaXMubWlzc2VzKys7cmV0dXJuIHVuZGVmaW5lZDt9XG4gIGNvbnN0IGVudHJ5PXRoaXMuZW50cmllcy5nZXQoa2V5KTtpZighZW50cnkpe3RoaXMubWlzc2VzKys7cmV0dXJuIHVuZGVmaW5lZDt9XG4gIGNvbnN0IHN0YXJ0PXBlcmZvcm1hbmNlLm5vdygpO3RoaXMuaGl0cysrO3RoaXMuZW50cmllcy5kZWxldGUoa2V5KTt0aGlzLmVudHJpZXMuc2V0KGtleSxlbnRyeSk7XG4gIGNvbnN0IHJnYmE9bmV3IFVpbnQ4Q2xhbXBlZEFycmF5KGVudHJ5LndpZHRoKmVudHJ5LmhlaWdodCo0KSx3b3Jkcz1uZXcgVWludDMyQXJyYXkocmdiYS5idWZmZXIpO2xldCBzb3VyY2U9MDtcbiAgZm9yKGxldCBpPTA7aTxlbnRyeS5zcGFucy5sZW5ndGg7aSs9Mil7XG4gICBsZXQgZGVzdGluYXRpb249ZW50cnkuc3BhbnNbaV0hLzQ7Y29uc3QgZW5kPWRlc3RpbmF0aW9uK2VudHJ5LnNwYW5zW2krMV0hLzQ7XG4gICB3aGlsZShkZXN0aW5hdGlvbjxlbmQpe2NvbnN0IGNvZGU9ZW50cnkucGl4ZWxzW3NvdXJjZSsrXSEsY291bnQ9Y29kZSYweDdmZmZmZmZmO1xuICAgIGlmKGNvZGU+Pj4zMSl3b3Jkcy5maWxsKGVudHJ5LnBpeGVsc1tzb3VyY2UrK10hLGRlc3RpbmF0aW9uLGRlc3RpbmF0aW9uK2NvdW50KTtcbiAgICBlbHNle3dvcmRzLnNldChlbnRyeS5waXhlbHMuc3ViYXJyYXkoc291cmNlLHNvdXJjZStjb3VudCksZGVzdGluYXRpb24pO3NvdXJjZSs9Y291bnQ7fVxuICAgIGRlc3RpbmF0aW9uKz1jb3VudDtcbiAgIH1cbiAgfVxuICBjb25zdCB3b3JrPXBlcmZvcm1hbmNlLm5vdygpLXN0YXJ0O3RoaXMud29ya01zKz13b3JrO3RoaXMud2luZG93V29ya01zKz13b3JrO3RoaXMuc2F2ZWRNcys9ZW50cnkucGFpbnRNczt0aGlzLndpbmRvd1NhdmVkTXMrPWVudHJ5LnBhaW50TXM7XG4gIHJldHVybiByZ2JhO1xuIH1cbiBwdXQoa2V5OnN0cmluZyxyZ2JhOlVpbnQ4Q2xhbXBlZEFycmF5LHdpZHRoOm51bWJlcixoZWlnaHQ6bnVtYmVyLHBhaW50TXM9MCl7XG4gIGlmKHRoaXMuYnlwYXNzPjB8fCF0aGlzLmJ1ZGdldHx8dGhpcy5lbnRyaWVzLmhhcyhrZXkpKXJldHVybjtcbiAgY29uc3Qgc3RhcnQ9cGVyZm9ybWFuY2Uubm93KCk7dHJ5e1xuICBjb25zdCB3b3Jkcz1uZXcgVWludDMyQXJyYXkocmdiYS5ieXRlT2Zmc2V0JTQ9PT0wP3JnYmEuYnVmZmVyOnJnYmEuc2xpY2UoKS5idWZmZXIscmdiYS5ieXRlT2Zmc2V0JTQ9PT0wP3JnYmEuYnl0ZU9mZnNldDowLHJnYmEuYnl0ZUxlbmd0aC80KTtcbiAgY29uc3Qgbm9uemVybz0ocGl4ZWw6bnVtYmVyKT0+d29yZHNbcGl4ZWxdIT09MDtcbiAgY29uc3Qgc3BhbnM6bnVtYmVyW109W107bGV0IGNvdW50PTA7XG4gIGZvcihsZXQgeT0wO3k8aGVpZ2h0O3krKyl7XG4gICBjb25zdCByb3c9eSp3aWR0aDtsZXQgbGVmdD0wLHJpZ2h0PXdpZHRoLTE7XG4gICB3aGlsZShsZWZ0PHdpZHRoJiYhbm9uemVybyhyb3crbGVmdCkpbGVmdCsrO1xuICAgaWYobGVmdD09PXdpZHRoKWNvbnRpbnVlO1xuICAgd2hpbGUocmlnaHQ+bGVmdCYmIW5vbnplcm8ocm93K3JpZ2h0KSlyaWdodC0tO1xuICAgY29uc3QgbGVuZ3RoPShyaWdodC1sZWZ0KzEpKjQ7c3BhbnMucHVzaCgocm93K2xlZnQpKjQsbGVuZ3RoKTtjb3VudCs9bGVuZ3RoO1xuICB9XG4gIGlmKHNwYW5zLmxlbmd0aCo4PnRoaXMuYnVkZ2V0KXJldHVybjtcbiAgY29uc3QgY2FwYWNpdHk9Y291bnQvNCtzcGFucy5sZW5ndGgvMjtcbiAgaWYodGhpcy5zY3JhdGNoLmxlbmd0aDxjYXBhY2l0eSl0aGlzLnNjcmF0Y2g9bmV3IFVpbnQzMkFycmF5KDIqKk1hdGguY2VpbChNYXRoLmxvZzIoY2FwYWNpdHkpKSk7XG4gIGxldCB3cml0dGVuPTA7XG4gIGZvcihsZXQgaT0wO2k8c3BhbnMubGVuZ3RoO2krPTIpe1xuICAgbGV0IGN1cnNvcj1zcGFuc1tpXSEvNDtjb25zdCBlbmQ9Y3Vyc29yK3NwYW5zW2krMV0hLzQ7XG4gICB3aGlsZShjdXJzb3I8ZW5kKXtcbiAgICBsZXQgcnVuPTE7d2hpbGUoY3Vyc29yK3J1bjxlbmQmJndvcmRzW2N1cnNvcitydW5dPT09d29yZHNbY3Vyc29yXSlydW4rKztcbiAgICBpZihydW4+PTMpe3RoaXMuc2NyYXRjaFt3cml0dGVuKytdPShydW58MHg4MDAwMDAwMCk+Pj4wO3RoaXMuc2NyYXRjaFt3cml0dGVuKytdPXdvcmRzW2N1cnNvcl0hO2N1cnNvcis9cnVuO31cbiAgICBlbHNle1xuICAgICBjb25zdCBmaXJzdD1jdXJzb3I7Y3Vyc29yKz1ydW47XG4gICAgIHdoaWxlKGN1cnNvcjxlbmQpe2lmKGN1cnNvcisyPGVuZCYmd29yZHNbY3Vyc29yXT09PXdvcmRzW2N1cnNvcisxXSYmd29yZHNbY3Vyc29yXT09PXdvcmRzW2N1cnNvcisyXSlicmVhaztjdXJzb3IrKzt9XG4gICAgIHRoaXMuc2NyYXRjaFt3cml0dGVuKytdPWN1cnNvci1maXJzdDt0aGlzLnNjcmF0Y2guc2V0KHdvcmRzLnN1YmFycmF5KGZpcnN0LGN1cnNvciksd3JpdHRlbik7d3JpdHRlbis9Y3Vyc29yLWZpcnN0O1xuICAgIH1cbiAgIH1cbiAgfVxuICBjb25zdCBieXRlcz13cml0dGVuKjQrc3BhbnMubGVuZ3RoKjQ7aWYoYnl0ZXM+dGhpcy5idWRnZXQpcmV0dXJuO1xuICB3aGlsZSh0aGlzLmJ5dGVzK2J5dGVzPnRoaXMuYnVkZ2V0JiZ0aGlzLmVudHJpZXMuc2l6ZSl7Y29uc3Qgb2xkZXN0PXRoaXMuZW50cmllcy5rZXlzKCkubmV4dCgpLnZhbHVlISxlbnRyeT10aGlzLmVudHJpZXMuZ2V0KG9sZGVzdCkhO3RoaXMuYnl0ZXMtPWVudHJ5LmJ5dGVzO3RoaXMuY2h1cm5CeXRlcys9ZW50cnkuYnl0ZXM7dGhpcy5lbnRyaWVzLmRlbGV0ZShvbGRlc3QpO3RoaXMuZXZpY3Rpb25zKys7fVxuICAvLyBBbHNvIGJvdW5kIG1ldGFkYXRhIGZvciBlbXB0eSBvciB0aW55IGVudHJpZXMuXG4gIGlmKHRoaXMuZW50cmllcy5zaXplPj0xMDI0KXtjb25zdCBvbGRlc3Q9dGhpcy5lbnRyaWVzLmtleXMoKS5uZXh0KCkudmFsdWUhO3RoaXMuY2h1cm5CeXRlcys9dGhpcy5lbnRyaWVzLmdldChvbGRlc3QpIS5ieXRlczt0aGlzLmJ5dGVzLT10aGlzLmVudHJpZXMuZ2V0KG9sZGVzdCkhLmJ5dGVzO3RoaXMuZW50cmllcy5kZWxldGUob2xkZXN0KTt0aGlzLmV2aWN0aW9ucysrO31cbiAgY29uc3QgcGl4ZWxzPXRoaXMuc2NyYXRjaC5zbGljZSgwLHdyaXR0ZW4pO1xuICB0aGlzLmVudHJpZXMuc2V0KGtleSx7d2lkdGgsaGVpZ2h0LHNwYW5zOm5ldyBVaW50MzJBcnJheShzcGFucykscGl4ZWxzLGJ5dGVzLHBhaW50TXN9KTt0aGlzLmJ5dGVzKz1ieXRlcztcbiAgfWZpbmFsbHl7XG4gICBjb25zdCB3b3JrPXBlcmZvcm1hbmNlLm5vdygpLXN0YXJ0O3RoaXMud29ya01zKz13b3JrO3RoaXMud2luZG93V29ya01zKz13b3JrO1xuICAgLy8gQWZ0ZXIgdHdvIGNvbXBsZXRlIHR1cm5vdmVycywga2VlcCBwYXlpbmcgZm9yIGNvbXByZXNzaW9uIG9ubHkgd2hlblxuICAgLy8gbWVhc3VyZWQgYXZvaWRlZCBkcmF3aW5nIHdvcmsgcGF5cyBmb3IgZW5jb2RpbmcgYW5kIHJlY29uc3RydWN0aW9uLlxuICAgaWYodGhpcy5jaHVybkJ5dGVzPj10aGlzLmJ1ZGdldCoyJiZ0aGlzLndpbmRvd1NhdmVkTXM8dGhpcy53aW5kb3dXb3JrTXMpe1xuICAgIHRoaXMucmVsZWFzZSgpO3RoaXMuYnlwYXNzPU1hdGgubWluKDE2Mzg0LDQwOTYqMioqdGhpcy5iYWNrb2Zmcyk7dGhpcy5iYWNrb2ZmcysrO1xuICAgIHRoaXMuY2h1cm5CeXRlcz10aGlzLndpbmRvd1dvcmtNcz10aGlzLndpbmRvd1NhdmVkTXM9MDtcbiAgIH1cbiAgfVxuIH1cbiBwcml2YXRlIHJlbGVhc2UoKXt0aGlzLmVudHJpZXMuY2xlYXIoKTt0aGlzLmJ5dGVzPTA7dGhpcy5zY3JhdGNoPW5ldyBVaW50MzJBcnJheSgwKTt9XG4gY2xlYXIoKXt0aGlzLnJlbGVhc2UoKTt0aGlzLmJ5cGFzcz10aGlzLmJhY2tvZmZzPXRoaXMuY2h1cm5CeXRlcz10aGlzLndpbmRvd1dvcmtNcz10aGlzLndpbmRvd1NhdmVkTXM9MDt9XG4gc3RhdHMoKXtyZXR1cm57YmFja29mZnM6dGhpcy5iYWNrb2ZmcyxieXBhc3NSZXF1ZXN0czp0aGlzLmJ5cGFzcyx3b3JrTXM6dGhpcy53b3JrTXMsYXZvaWRlZFBhaW50TXM6dGhpcy5zYXZlZE1zLGJ5dGVzOnRoaXMuYnl0ZXMsc2NyYXRjaEJ5dGVzOnRoaXMuc2NyYXRjaC5ieXRlTGVuZ3RoLG93bmVkQnl0ZXM6dGhpcy5ieXRlcyt0aGlzLnNjcmF0Y2guYnl0ZUxlbmd0aCxlbnRyaWVzOnRoaXMuZW50cmllcy5zaXplLGhpdHM6dGhpcy5oaXRzLG1pc3Nlczp0aGlzLm1pc3NlcyxldmljdGlvbnM6dGhpcy5ldmljdGlvbnMsYnVkZ2V0OnRoaXMuYnVkZ2V0fTt9XG59XG4iXSwibWFwcGluZ3MiOiJBQUdPLGFBQU0sZ0JBQWdCO0FBQUEsRUFjNUIsWUFBb0IsU0FBTyxLQUFHLE9BQUssTUFBSztBQUFwQjtBQUFBLEVBQXFCO0FBQUEsRUFiakMsVUFBUSxvQkFBSSxJQUFtQjtBQUFBLEVBQy9CLFFBQU07QUFBQSxFQUNOLFVBQVEsSUFBSSxZQUFZLENBQUM7QUFBQSxFQUN6QixPQUFLO0FBQUEsRUFDTCxTQUFPO0FBQUEsRUFDUCxZQUFVO0FBQUEsRUFDVixTQUFPO0FBQUEsRUFDUCxXQUFTO0FBQUEsRUFDVCxhQUFXO0FBQUEsRUFDWCxlQUFhO0FBQUEsRUFDYixnQkFBYztBQUFBLEVBQ2QsU0FBTztBQUFBLEVBQ1AsVUFBUTtBQUFBLEVBRWhCLElBQUksS0FBVztBQUNkLFFBQUcsS0FBSyxTQUFPLEdBQUU7QUFBQyxXQUFLO0FBQVMsV0FBSztBQUFTLGFBQU87QUFBQSxJQUFVO0FBQy9ELFVBQU0sUUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQUUsUUFBRyxDQUFDLE9BQU07QUFBQyxXQUFLO0FBQVMsYUFBTztBQUFBLElBQVU7QUFDNUUsVUFBTSxRQUFNLFlBQVksSUFBSTtBQUFFLFNBQUs7QUFBTyxTQUFLLFFBQVEsT0FBTyxHQUFHO0FBQUUsU0FBSyxRQUFRLElBQUksS0FBSSxLQUFLO0FBQzdGLFVBQU0sT0FBSyxJQUFJLGtCQUFrQixNQUFNLFFBQU0sTUFBTSxTQUFPLENBQUMsR0FBRSxRQUFNLElBQUksWUFBWSxLQUFLLE1BQU07QUFBRSxRQUFJLFNBQU87QUFDM0csYUFBUSxJQUFFLEdBQUUsSUFBRSxNQUFNLE1BQU0sUUFBTyxLQUFHLEdBQUU7QUFDckMsVUFBSSxjQUFZLE1BQU0sTUFBTSxDQUFDLElBQUc7QUFBRSxZQUFNLE1BQUksY0FBWSxNQUFNLE1BQU0sSUFBRSxDQUFDLElBQUc7QUFDMUUsYUFBTSxjQUFZLEtBQUk7QUFBQyxjQUFNLE9BQUssTUFBTSxPQUFPLFFBQVEsR0FBRyxRQUFNLE9BQUs7QUFDcEUsWUFBRyxTQUFPLEdBQUcsT0FBTSxLQUFLLE1BQU0sT0FBTyxRQUFRLEdBQUcsYUFBWSxjQUFZLEtBQUs7QUFBQSxhQUN6RTtBQUFDLGdCQUFNLElBQUksTUFBTSxPQUFPLFNBQVMsUUFBTyxTQUFPLEtBQUssR0FBRSxXQUFXO0FBQUUsb0JBQVE7QUFBQSxRQUFNO0FBQ3JGLHVCQUFhO0FBQUEsTUFDZDtBQUFBLElBQ0Q7QUFDQSxVQUFNLE9BQUssWUFBWSxJQUFJLElBQUU7QUFBTSxTQUFLLFVBQVE7QUFBSyxTQUFLLGdCQUFjO0FBQUssU0FBSyxXQUFTLE1BQU07QUFBUSxTQUFLLGlCQUFlLE1BQU07QUFDbkksV0FBTztBQUFBLEVBQ1I7QUFBQSxFQUNBLElBQUksS0FBVyxNQUF1QixPQUFhLFFBQWMsVUFBUSxHQUFFO0FBQzFFLFFBQUcsS0FBSyxTQUFPLEtBQUcsQ0FBQyxLQUFLLFVBQVEsS0FBSyxRQUFRLElBQUksR0FBRyxFQUFFO0FBQ3RELFVBQU0sUUFBTSxZQUFZLElBQUk7QUFBRSxRQUFHO0FBQ2pDLFlBQU0sUUFBTSxJQUFJLFlBQVksS0FBSyxhQUFXLE1BQUksSUFBRSxLQUFLLFNBQU8sS0FBSyxNQUFNLEVBQUUsUUFBTyxLQUFLLGFBQVcsTUFBSSxJQUFFLEtBQUssYUFBVyxHQUFFLEtBQUssYUFBVyxDQUFDO0FBQzNJLFlBQU0sVUFBUSxDQUFDLFVBQWUsTUFBTSxLQUFLLE1BQUk7QUFDN0MsWUFBTSxRQUFlLENBQUM7QUFBRSxVQUFJLFFBQU07QUFDbEMsZUFBUSxJQUFFLEdBQUUsSUFBRSxRQUFPLEtBQUk7QUFDeEIsY0FBTSxNQUFJLElBQUU7QUFBTSxZQUFJLE9BQUssR0FBRSxRQUFNLFFBQU07QUFDekMsZUFBTSxPQUFLLFNBQU8sQ0FBQyxRQUFRLE1BQUksSUFBSSxFQUFFO0FBQ3JDLFlBQUcsU0FBTyxNQUFNO0FBQ2hCLGVBQU0sUUFBTSxRQUFNLENBQUMsUUFBUSxNQUFJLEtBQUssRUFBRTtBQUN0QyxjQUFNLFVBQVEsUUFBTSxPQUFLLEtBQUc7QUFBRSxjQUFNLE1BQU0sTUFBSSxRQUFNLEdBQUUsTUFBTTtBQUFFLGlCQUFPO0FBQUEsTUFDdEU7QUFDQSxVQUFHLE1BQU0sU0FBTyxJQUFFLEtBQUssT0FBTztBQUM5QixZQUFNLFdBQVMsUUFBTSxJQUFFLE1BQU0sU0FBTztBQUNwQyxVQUFHLEtBQUssUUFBUSxTQUFPLFNBQVMsTUFBSyxVQUFRLElBQUksWUFBWSxLQUFHLEtBQUssS0FBSyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUM7QUFDOUYsVUFBSSxVQUFRO0FBQ1osZUFBUSxJQUFFLEdBQUUsSUFBRSxNQUFNLFFBQU8sS0FBRyxHQUFFO0FBQy9CLFlBQUksU0FBTyxNQUFNLENBQUMsSUFBRztBQUFFLGNBQU0sTUFBSSxTQUFPLE1BQU0sSUFBRSxDQUFDLElBQUc7QUFDcEQsZUFBTSxTQUFPLEtBQUk7QUFDaEIsY0FBSSxNQUFJO0FBQUUsaUJBQU0sU0FBTyxNQUFJLE9BQUssTUFBTSxTQUFPLEdBQUcsTUFBSSxNQUFNLE1BQU0sRUFBRTtBQUNsRSxjQUFHLE9BQUssR0FBRTtBQUFDLGlCQUFLLFFBQVEsU0FBUyxLQUFHLE1BQUksZ0JBQWM7QUFBRSxpQkFBSyxRQUFRLFNBQVMsSUFBRSxNQUFNLE1BQU07QUFBRyxzQkFBUTtBQUFBLFVBQUksT0FDdkc7QUFDSCxrQkFBTSxRQUFNO0FBQU8sc0JBQVE7QUFDM0IsbUJBQU0sU0FBTyxLQUFJO0FBQUMsa0JBQUcsU0FBTyxJQUFFLE9BQUssTUFBTSxNQUFNLE1BQUksTUFBTSxTQUFPLENBQUMsS0FBRyxNQUFNLE1BQU0sTUFBSSxNQUFNLFNBQU8sQ0FBQyxFQUFFO0FBQU07QUFBQSxZQUFTO0FBQ25ILGlCQUFLLFFBQVEsU0FBUyxJQUFFLFNBQU87QUFBTSxpQkFBSyxRQUFRLElBQUksTUFBTSxTQUFTLE9BQU0sTUFBTSxHQUFFLE9BQU87QUFBRSx1QkFBUyxTQUFPO0FBQUEsVUFDN0c7QUFBQSxRQUNEO0FBQUEsTUFDRDtBQUNBLFlBQU0sUUFBTSxVQUFRLElBQUUsTUFBTSxTQUFPO0FBQUUsVUFBRyxRQUFNLEtBQUssT0FBTztBQUMxRCxhQUFNLEtBQUssUUFBTSxRQUFNLEtBQUssVUFBUSxLQUFLLFFBQVEsTUFBSztBQUFDLGNBQU0sU0FBTyxLQUFLLFFBQVEsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLFFBQU0sS0FBSyxRQUFRLElBQUksTUFBTTtBQUFHLGFBQUssU0FBTyxNQUFNO0FBQU0sYUFBSyxjQUFZLE1BQU07QUFBTSxhQUFLLFFBQVEsT0FBTyxNQUFNO0FBQUUsYUFBSztBQUFBLE1BQVk7QUFFeE8sVUFBRyxLQUFLLFFBQVEsUUFBTSxNQUFLO0FBQUMsY0FBTSxTQUFPLEtBQUssUUFBUSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQU8sYUFBSyxjQUFZLEtBQUssUUFBUSxJQUFJLE1BQU0sRUFBRztBQUFNLGFBQUssU0FBTyxLQUFLLFFBQVEsSUFBSSxNQUFNLEVBQUc7QUFBTSxhQUFLLFFBQVEsT0FBTyxNQUFNO0FBQUUsYUFBSztBQUFBLE1BQVk7QUFDck4sWUFBTSxTQUFPLEtBQUssUUFBUSxNQUFNLEdBQUUsT0FBTztBQUN6QyxXQUFLLFFBQVEsSUFBSSxLQUFJLEVBQUMsT0FBTSxRQUFPLE9BQU0sSUFBSSxZQUFZLEtBQUssR0FBRSxRQUFPLE9BQU0sUUFBTyxDQUFDO0FBQUUsV0FBSyxTQUFPO0FBQUEsSUFDbkcsVUFBQztBQUNBLFlBQU0sT0FBSyxZQUFZLElBQUksSUFBRTtBQUFNLFdBQUssVUFBUTtBQUFLLFdBQUssZ0JBQWM7QUFHeEUsVUFBRyxLQUFLLGNBQVksS0FBSyxTQUFPLEtBQUcsS0FBSyxnQkFBYyxLQUFLLGNBQWE7QUFDdkUsYUFBSyxRQUFRO0FBQUUsYUFBSyxTQUFPLEtBQUssSUFBSSxPQUFNLE9BQUssS0FBRyxLQUFLLFFBQVE7QUFBRSxhQUFLO0FBQ3RFLGFBQUssYUFBVyxLQUFLLGVBQWEsS0FBSyxnQkFBYztBQUFBLE1BQ3REO0FBQUEsSUFDRDtBQUFBLEVBQ0Q7QUFBQSxFQUNRLFVBQVM7QUFBQyxTQUFLLFFBQVEsTUFBTTtBQUFFLFNBQUssUUFBTTtBQUFFLFNBQUssVUFBUSxJQUFJLFlBQVksQ0FBQztBQUFBLEVBQUU7QUFBQSxFQUNwRixRQUFPO0FBQUMsU0FBSyxRQUFRO0FBQUUsU0FBSyxTQUFPLEtBQUssV0FBUyxLQUFLLGFBQVcsS0FBSyxlQUFhLEtBQUssZ0JBQWM7QUFBQSxFQUFFO0FBQUEsRUFDeEcsUUFBTztBQUFDLFdBQU0sRUFBQyxVQUFTLEtBQUssVUFBUyxnQkFBZSxLQUFLLFFBQU8sUUFBTyxLQUFLLFFBQU8sZ0JBQWUsS0FBSyxTQUFRLE9BQU0sS0FBSyxPQUFNLGNBQWEsS0FBSyxRQUFRLFlBQVcsWUFBVyxLQUFLLFFBQU0sS0FBSyxRQUFRLFlBQVcsU0FBUSxLQUFLLFFBQVEsTUFBSyxNQUFLLEtBQUssTUFBSyxRQUFPLEtBQUssUUFBTyxXQUFVLEtBQUssV0FBVSxRQUFPLEtBQUssT0FBTTtBQUFBLEVBQUU7QUFDOVQ7IiwibmFtZXMiOltdfQ==