import * as THREE from "/.vite-cache/deps/three.js?v=a06372f0";
import { SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { COMBAT_PRESENTATION_LIMITS as LIMITS } from "/@fs/tmp/sketch-queue-source-42bd/src/client/combat-presentation.ts";
const TILT = Math.tan(SHIP_CAMERA.tilt);
export const COMBAT_INK_LIMIT = (LIMITS.bursts + LIMITS.residueBursts) * LIMITS.dropletsPerBurst + LIMITS.bursts * LIMITS.dropletsPerBurst + LIMITS.bursts + LIMITS.speedLines + LIMITS.transferredMarks;
const VERTEX = `
attribute vec2 inkData;
varying vec2 localInk;
varying vec2 ink;
varying vec3 colorInk;
void main(){localInk=position.xy;ink=inkData;colorInk=instanceColor;
 gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(position,1.0);}
`;
const FRAGMENT = `
varying vec2 localInk;
varying vec2 ink;
varying vec3 colorInk;
void main(){
 vec2 p=localInk;
 float edge;
 if(ink.y>0.5){
  float curve=.16*(1.0-p.x*p.x);
  edge=max(abs(p.y-curve)-(.16+.14*(1.0-abs(p.x))),abs(p.x)-.97);
 }else{
  float grain=.035*sin(p.x*17.0+p.y*9.0)*sin(p.y*13.0-p.x*5.0);
  edge=length(p)-.91+grain;
 }
 float aa=max(.025,fwidth(edge));
 float alpha=(1.0-smoothstep(-aa,aa,edge))*ink.x;
 if(alpha<.008)discard;
 gl_FragColor=vec4(colorInk,alpha);
 #include <colorspace_fragment>
}
`;
export class CombatInk {
  constructor(scene) {
    this.scene = scene;
  }
  material = new THREE.ShaderMaterial({ vertexShader: VERTEX, fragmentShader: FRAGMENT, transparent: true, depthTest: true, depthWrite: false, toneMapped: false, side: THREE.DoubleSide });
  mesh;
  data;
  matrix = new THREE.Matrix4();
  color = new THREE.Color();
  count = 0;
  capacity = 0;
  overflow = 0;
  culled = 0;
  culling = false;
  left = 0;
  top = 0;
  right = 0;
  bottom = 0;
  disposed = false;
  kinds = { air: 0, body: 0, deck: 0, speed: 0 };
  ensure(required) {
    if (required <= this.capacity) return;
    const capacity = Math.min(2 ** Math.ceil(Math.log2(Math.max(16, required))), 2 ** Math.ceil(Math.log2(COMBAT_INK_LIMIT)));
    const geometry = new THREE.PlaneGeometry(2, 2);
    const data = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 2), 2).setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute("inkData", data);
    const mesh = new THREE.InstancedMesh(geometry, this.material, capacity);
    mesh.name = "CombatInk";
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.frustumCulled = false;
    mesh.raycast = () => {
    };
    if (this.mesh) {
      const old = this.mesh;
      for (let i = 0; i < this.count; i++) {
        old.getMatrixAt(i, this.matrix);
        mesh.setMatrixAt(i, this.matrix);
        old.getColorAt(i, this.color);
        mesh.setColorAt(i, this.color);
        data.setXY(i, this.data.getX(i), this.data.getY(i));
      }
      this.scene.remove(old);
      old.dispose();
      old.geometry.dispose();
    }
    this.scene.add(mesh);
    this.mesh = mesh;
    this.data = data;
    this.capacity = capacity;
  }
  add(x, y, height, rx, ry, angle, alpha, kind, flat = false) {
    const c = Math.cos(angle), s = Math.sin(angle);
    if (this.culling) {
      const projectedY = y - (height + (flat ? 0.12 : 0)) * TILT;
      const width = Math.abs(c * rx) + Math.abs(s * ry), heightExtent = Math.abs(s * rx) + Math.abs(c * ry);
      if (x + width < this.left || x - width > this.right || projectedY + heightExtent < this.top || projectedY - heightExtent > this.bottom) {
        this.culled++;
        return;
      }
    }
    if (this.count >= COMBAT_INK_LIMIT) {
      this.overflow++;
      return;
    }
    this.ensure(this.count + 1);
    if (flat) this.matrix.set(c * rx, -s * ry, 0, x, 0, 0, 1, height + 0.12, s * rx, c * ry, 0, y, 0, 0, 0, 1);
    else {
      this.matrix.set(c * rx, -s * ry, 0, x, -s * rx / TILT, -c * ry / TILT, 0, height + 0.12 * Math.cos(SHIP_CAMERA.tilt), 0, 0, 1, y + 0.12 * Math.sin(SHIP_CAMERA.tilt), 0, 0, 0, 1);
    }
    this.mesh.setMatrixAt(this.count, this.matrix);
    this.color.set(kind === "speed" ? "#514b40" : kind === "deck" ? "#713a32" : kind === "body" ? "#883e34" : "#9b4436");
    this.mesh.setColorAt(this.count, this.color);
    this.data.setXY(this.count, alpha, kind === "speed" ? 1 : 0);
    this.count++;
    this.kinds[kind]++;
  }
  update(frame, anchors, reducedMotion = false, view) {
    if (this.disposed) return;
    this.clear();
    this.culling = !!view;
    if (view) {
      const zoom = view.zoom ?? 1, pad = 2 / zoom;
      this.left = view.x - pad;
      this.top = view.y - pad;
      this.right = view.x + view.width / zoom + pad;
      this.bottom = view.y + view.height / zoom + pad;
    }
    for (const mark of frame.ground) if (mark.height > 0) this.add(mark.x, mark.y, mark.height, mark.radius, mark.radius * 0.48, mark.angle, mark.alpha * 0.72, "deck", true);
    for (const mark of frame.body) {
      const at = anchors.get(mark.unitId);
      if (!at) continue;
      this.add(at.x + mark.localX * at.facing, at.y, at.floor - mark.localY / TILT, mark.width ?? mark.radius * 0.65, mark.radius, mark.angle * at.facing, mark.alpha * 0.77, "body");
    }
    for (const drop of frame.droplets) {
      const speed = Math.hypot(drop.vx, drop.vy - drop.vz * TILT), angle = Math.atan2(drop.vy - drop.vz * TILT, drop.vx);
      this.add(drop.x, drop.y, drop.height, drop.radius * (reducedMotion ? 1 : 1 + Math.min(0.85, speed / 180)), drop.radius * 0.7, angle, drop.alpha * 0.82, "air");
    }
    if (!reducedMotion) for (const line of frame.speedLines) {
      const at = anchors.get(line.unitId);
      if (!at) continue;
      const back = 8 + line.length / 2;
      this.add(line.x + at.x - (at.sourceX ?? at.x) - line.dx * back, line.y + at.y - (at.sourceY ?? at.y) - line.dy * back, at.floor + line.height, line.length / 2, line.width * 2, Math.atan2(line.dy, line.dx), line.alpha * 0.58, "speed");
    }
    if (this.mesh) {
      this.mesh.count = this.count;
      this.mesh.visible = this.count > 0;
      this.mesh.instanceMatrix.needsUpdate = true;
      if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
      this.data.needsUpdate = true;
    }
  }
  clear() {
    this.count = 0;
    this.overflow = 0;
    this.culled = 0;
    this.kinds.air = this.kinds.body = this.kinds.deck = this.kinds.speed = 0;
    if (this.mesh) {
      this.mesh.count = 0;
      this.mesh.visible = false;
    }
  }
  stats() {
    return { count: this.count, capacity: this.capacity, drawCalls: this.count ? 1 : 0, bufferBytes: this.capacity * (16 + 3 + 2) * 4, limit: COMBAT_INK_LIMIT, overflow: this.overflow, culled: this.culled, ...this.kinds, disposed: this.disposed };
  }
  dispose() {
    if (this.disposed) return;
    this.clear();
    this.disposed = true;
    if (this.mesh) {
      this.scene.remove(this.mesh);
      this.mesh.dispose();
      this.mesh.geometry.dispose();
      this.mesh = void 0;
    }
    this.data = void 0;
    this.capacity = 0;
    this.material.dispose();
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbWJhdC1pbmsudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqIEEgYm91bmRlZCB0cmFuc3BhcmVudCBiYXRjaCBpbiB0aGUgYWN0b3JzJyByZWFsIGRlcHRoIGJ1ZmZlci4gTm8gcmVhZGJhY2ssXG4gKiBwZXItdW5pdCB0ZXh0dXJlcywgc2hhZG93cywgcGlja2luZywgb3Igc2ltdWxhdGlvbiBzdGF0ZS4gKi9cbmltcG9ydCAqIGFzIFRIUkVFIGZyb20gJ3RocmVlJztcbmltcG9ydCB7U0hJUF9DQU1FUkF9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGlwLWdlb21ldHJ5JztcbmltcG9ydCB7Q09NQkFUX1BSRVNFTlRBVElPTl9MSU1JVFMgYXMgTElNSVRTLHR5cGUgQ29tYmF0UHJlc2VudGF0aW9uRnJhbWV9IGZyb20gJy4uL2NvbWJhdC1wcmVzZW50YXRpb24nO1xuaW1wb3J0IHR5cGUge1dvcmxkVmlld30gZnJvbSAnLi9wcm9qZWN0aW9uJztcblxuY29uc3QgVElMVD1NYXRoLnRhbihTSElQX0NBTUVSQS50aWx0KTtcbmV4cG9ydCBjb25zdCBDT01CQVRfSU5LX0xJTUlUPShMSU1JVFMuYnVyc3RzK0xJTUlUUy5yZXNpZHVlQnVyc3RzKSpMSU1JVFMuZHJvcGxldHNQZXJCdXJzdCtMSU1JVFMuYnVyc3RzKkxJTUlUUy5kcm9wbGV0c1BlckJ1cnN0K0xJTUlUUy5idXJzdHMrTElNSVRTLnNwZWVkTGluZXMrTElNSVRTLnRyYW5zZmVycmVkTWFya3M7XG5leHBvcnQgdHlwZSBDb21iYXRBbmNob3I9e3g6bnVtYmVyO3k6bnVtYmVyO2Zsb29yOm51bWJlcjtmYWNpbmc6MXwtMTtzb3VyY2VYPzpudW1iZXI7c291cmNlWT86bnVtYmVyfTtcbmNvbnN0IFZFUlRFWD1gXG5hdHRyaWJ1dGUgdmVjMiBpbmtEYXRhO1xudmFyeWluZyB2ZWMyIGxvY2FsSW5rO1xudmFyeWluZyB2ZWMyIGluaztcbnZhcnlpbmcgdmVjMyBjb2xvckluaztcbnZvaWQgbWFpbigpe2xvY2FsSW5rPXBvc2l0aW9uLnh5O2luaz1pbmtEYXRhO2NvbG9ySW5rPWluc3RhbmNlQ29sb3I7XG4gZ2xfUG9zaXRpb249cHJvamVjdGlvbk1hdHJpeCptb2RlbFZpZXdNYXRyaXgqaW5zdGFuY2VNYXRyaXgqdmVjNChwb3NpdGlvbiwxLjApO31cbmA7XG5jb25zdCBGUkFHTUVOVD1gXG52YXJ5aW5nIHZlYzIgbG9jYWxJbms7XG52YXJ5aW5nIHZlYzIgaW5rO1xudmFyeWluZyB2ZWMzIGNvbG9ySW5rO1xudm9pZCBtYWluKCl7XG4gdmVjMiBwPWxvY2FsSW5rO1xuIGZsb2F0IGVkZ2U7XG4gaWYoaW5rLnk+MC41KXtcbiAgZmxvYXQgY3VydmU9LjE2KigxLjAtcC54KnAueCk7XG4gIGVkZ2U9bWF4KGFicyhwLnktY3VydmUpLSguMTYrLjE0KigxLjAtYWJzKHAueCkpKSxhYnMocC54KS0uOTcpO1xuIH1lbHNle1xuICBmbG9hdCBncmFpbj0uMDM1KnNpbihwLngqMTcuMCtwLnkqOS4wKSpzaW4ocC55KjEzLjAtcC54KjUuMCk7XG4gIGVkZ2U9bGVuZ3RoKHApLS45MStncmFpbjtcbiB9XG4gZmxvYXQgYWE9bWF4KC4wMjUsZndpZHRoKGVkZ2UpKTtcbiBmbG9hdCBhbHBoYT0oMS4wLXNtb290aHN0ZXAoLWFhLGFhLGVkZ2UpKSppbmsueDtcbiBpZihhbHBoYTwuMDA4KWRpc2NhcmQ7XG4gZ2xfRnJhZ0NvbG9yPXZlYzQoY29sb3JJbmssYWxwaGEpO1xuICNpbmNsdWRlIDxjb2xvcnNwYWNlX2ZyYWdtZW50PlxufVxuYDtcbmV4cG9ydCBjbGFzcyBDb21iYXRJbmsge1xuIHByaXZhdGUgbWF0ZXJpYWw9bmV3IFRIUkVFLlNoYWRlck1hdGVyaWFsKHt2ZXJ0ZXhTaGFkZXI6VkVSVEVYLGZyYWdtZW50U2hhZGVyOkZSQUdNRU5ULHRyYW5zcGFyZW50OnRydWUsZGVwdGhUZXN0OnRydWUsZGVwdGhXcml0ZTpmYWxzZSx0b25lTWFwcGVkOmZhbHNlLHNpZGU6VEhSRUUuRG91YmxlU2lkZX0pO1xuIHByaXZhdGUgbWVzaDpUSFJFRS5JbnN0YW5jZWRNZXNofHVuZGVmaW5lZDtcbiBwcml2YXRlIGRhdGE6VEhSRUUuSW5zdGFuY2VkQnVmZmVyQXR0cmlidXRlfHVuZGVmaW5lZDtcbiBwcml2YXRlIG1hdHJpeD1uZXcgVEhSRUUuTWF0cml4NCgpO1xuIHByaXZhdGUgY29sb3I9bmV3IFRIUkVFLkNvbG9yKCk7XG4gcHJpdmF0ZSBjb3VudD0wO1xuIHByaXZhdGUgY2FwYWNpdHk9MDtcbiBwcml2YXRlIG92ZXJmbG93PTA7XG4gcHJpdmF0ZSBjdWxsZWQ9MDtcbiBwcml2YXRlIGN1bGxpbmc9ZmFsc2U7XG4gcHJpdmF0ZSBsZWZ0PTA7XG4gcHJpdmF0ZSB0b3A9MDtcbiBwcml2YXRlIHJpZ2h0PTA7XG4gcHJpdmF0ZSBib3R0b209MDtcbiBwcml2YXRlIGRpc3Bvc2VkPWZhbHNlO1xuIHByaXZhdGUga2luZHM9e2FpcjowLGJvZHk6MCxkZWNrOjAsc3BlZWQ6MH07XG4gY29uc3RydWN0b3IocHJpdmF0ZSBzY2VuZTpUSFJFRS5TY2VuZSl7fVxuIHByaXZhdGUgZW5zdXJlKHJlcXVpcmVkOm51bWJlcil7XG4gIGlmKHJlcXVpcmVkPD10aGlzLmNhcGFjaXR5KXJldHVybjtcbiAgY29uc3QgY2FwYWNpdHk9TWF0aC5taW4oMioqTWF0aC5jZWlsKE1hdGgubG9nMihNYXRoLm1heCgxNixyZXF1aXJlZCkpKSwyKipNYXRoLmNlaWwoTWF0aC5sb2cyKENPTUJBVF9JTktfTElNSVQpKSk7XG4gIGNvbnN0IGdlb21ldHJ5PW5ldyBUSFJFRS5QbGFuZUdlb21ldHJ5KDIsMik7XG4gIGNvbnN0IGRhdGE9bmV3IFRIUkVFLkluc3RhbmNlZEJ1ZmZlckF0dHJpYnV0ZShuZXcgRmxvYXQzMkFycmF5KGNhcGFjaXR5KjIpLDIpLnNldFVzYWdlKFRIUkVFLkR5bmFtaWNEcmF3VXNhZ2UpO2dlb21ldHJ5LnNldEF0dHJpYnV0ZSgnaW5rRGF0YScsZGF0YSk7XG4gIGNvbnN0IG1lc2g9bmV3IFRIUkVFLkluc3RhbmNlZE1lc2goZ2VvbWV0cnksdGhpcy5tYXRlcmlhbCxjYXBhY2l0eSk7bWVzaC5uYW1lPSdDb21iYXRJbmsnO21lc2guaW5zdGFuY2VNYXRyaXguc2V0VXNhZ2UoVEhSRUUuRHluYW1pY0RyYXdVc2FnZSk7bWVzaC5mcnVzdHVtQ3VsbGVkPWZhbHNlO21lc2gucmF5Y2FzdD0oKT0+e307XG4gIGlmKHRoaXMubWVzaCl7XG4gICBjb25zdCBvbGQ9dGhpcy5tZXNoO2ZvcihsZXQgaT0wO2k8dGhpcy5jb3VudDtpKyspe29sZC5nZXRNYXRyaXhBdChpLHRoaXMubWF0cml4KTttZXNoLnNldE1hdHJpeEF0KGksdGhpcy5tYXRyaXgpO29sZC5nZXRDb2xvckF0KGksdGhpcy5jb2xvcik7bWVzaC5zZXRDb2xvckF0KGksdGhpcy5jb2xvcik7ZGF0YS5zZXRYWShpLHRoaXMuZGF0YSEuZ2V0WChpKSx0aGlzLmRhdGEhLmdldFkoaSkpO31cbiAgIHRoaXMuc2NlbmUucmVtb3ZlKG9sZCk7b2xkLmRpc3Bvc2UoKTtvbGQuZ2VvbWV0cnkuZGlzcG9zZSgpO1xuICB9XG4gIHRoaXMuc2NlbmUuYWRkKG1lc2gpO3RoaXMubWVzaD1tZXNoO3RoaXMuZGF0YT1kYXRhO3RoaXMuY2FwYWNpdHk9Y2FwYWNpdHk7XG4gfVxuIHByaXZhdGUgYWRkKHg6bnVtYmVyLHk6bnVtYmVyLGhlaWdodDpudW1iZXIscng6bnVtYmVyLHJ5Om51bWJlcixhbmdsZTpudW1iZXIsYWxwaGE6bnVtYmVyLGtpbmQ6a2V5b2YgQ29tYmF0SW5rWydraW5kcyddLGZsYXQ9ZmFsc2Upe1xuICBjb25zdCBjPU1hdGguY29zKGFuZ2xlKSxzPU1hdGguc2luKGFuZ2xlKTtcbiAgaWYodGhpcy5jdWxsaW5nKXtcbiAgIC8vIFRoZSBvYmxpcXVlIGNhbWVyYSBwcm9qZWN0cyAoeCxoZWlnaHQseSkgdG8gKHgseS1oZWlnaHQqVElMVCkuXG4gICAvLyBCaWxsYm9hcmRzJyB0aW55IGRpc3BsYWNlbWVudCB0b3dhcmQgdGhlIGV5ZSBjYW5jZWxzIGluIHByb2plY3Rpb247XG4gICAvLyBmbGF0IGRlY2sgaW5rIGluc3RlYWQgaGFzIHRoZSBhY3R1YWwgLjEyIGhlaWdodCBsaWZ0LiBVc2UgdGhlIGNvbXBsZXRlXG4gICAvLyByb3RhdGVkIHF1YWQgc28gYSBoaWdoIGRyb3Agb3IgbGFyZ2UgbWFyayBjcm9zc2luZyB0aGUgZWRnZSBzdXJ2aXZlcy5cbiAgIGNvbnN0IHByb2plY3RlZFk9eS0oaGVpZ2h0KyhmbGF0ID8gLjEyIDogMCkpKlRJTFQ7XG4gICBjb25zdCB3aWR0aD1NYXRoLmFicyhjKnJ4KStNYXRoLmFicyhzKnJ5KSxoZWlnaHRFeHRlbnQ9TWF0aC5hYnMocypyeCkrTWF0aC5hYnMoYypyeSk7XG4gICBpZih4K3dpZHRoPHRoaXMubGVmdHx8eC13aWR0aD50aGlzLnJpZ2h0fHxwcm9qZWN0ZWRZK2hlaWdodEV4dGVudDx0aGlzLnRvcHx8cHJvamVjdGVkWS1oZWlnaHRFeHRlbnQ+dGhpcy5ib3R0b20pe3RoaXMuY3VsbGVkKys7cmV0dXJuO31cbiAgfVxuICBpZih0aGlzLmNvdW50Pj1DT01CQVRfSU5LX0xJTUlUKXt0aGlzLm92ZXJmbG93Kys7cmV0dXJuO31cbiAgdGhpcy5lbnN1cmUodGhpcy5jb3VudCsxKTtcbiAgaWYoZmxhdCl0aGlzLm1hdHJpeC5zZXQoYypyeCwtcypyeSwwLHgsMCwwLDEsaGVpZ2h0Ky4xMixzKnJ4LGMqcnksMCx5LDAsMCwwLDEpO1xuICBlbHNle1xuICAgLy8gQSB0aW55IGRpc3BsYWNlbWVudCB0b3dhcmQgdGhlIGV5ZSBwcmVzZXJ2ZXMgdGhlIHByb2plY3RlZCBwb3NpdGlvbiBhbmRcbiAgIC8vIGF2b2lkcyBmaWdodGluZyB0aGUgd2VhcmVyJ3MgY3V0b3V0IGNhcmQsIHdpdGhvdXQgY3Jvc3NpbmcgbmVhcmJ5IHdhbGxzLlxuICAgdGhpcy5tYXRyaXguc2V0KGMqcngsLXMqcnksMCx4LC1zKnJ4L1RJTFQsLWMqcnkvVElMVCwwLGhlaWdodCsuMTIqTWF0aC5jb3MoU0hJUF9DQU1FUkEudGlsdCksMCwwLDEseSsuMTIqTWF0aC5zaW4oU0hJUF9DQU1FUkEudGlsdCksMCwwLDAsMSk7XG4gIH1cbiAgdGhpcy5tZXNoIS5zZXRNYXRyaXhBdCh0aGlzLmNvdW50LHRoaXMubWF0cml4KTtcbiAgdGhpcy5jb2xvci5zZXQoa2luZD09PSdzcGVlZCc/JyM1MTRiNDAnOmtpbmQ9PT0nZGVjayc/JyM3MTNhMzInOmtpbmQ9PT0nYm9keSc/JyM4ODNlMzQnOicjOWI0NDM2Jyk7dGhpcy5tZXNoIS5zZXRDb2xvckF0KHRoaXMuY291bnQsdGhpcy5jb2xvcik7XG4gIHRoaXMuZGF0YSEuc2V0WFkodGhpcy5jb3VudCxhbHBoYSxraW5kPT09J3NwZWVkJz8xOjApO3RoaXMuY291bnQrKzt0aGlzLmtpbmRzW2tpbmRdKys7XG4gfVxuIHVwZGF0ZShmcmFtZTpDb21iYXRQcmVzZW50YXRpb25GcmFtZSxhbmNob3JzOlJlYWRvbmx5TWFwPHN0cmluZyxDb21iYXRBbmNob3I+LHJlZHVjZWRNb3Rpb249ZmFsc2Usdmlldz86V29ybGRWaWV3KXtcbiAgaWYodGhpcy5kaXNwb3NlZClyZXR1cm47dGhpcy5jbGVhcigpO1xuICB0aGlzLmN1bGxpbmc9ISF2aWV3O1xuICBpZih2aWV3KXtjb25zdCB6b29tPXZpZXcuem9vbT8/MSxwYWQ9Mi96b29tO1xuICAgdGhpcy5sZWZ0PXZpZXcueC1wYWQ7dGhpcy50b3A9dmlldy55LXBhZDt0aGlzLnJpZ2h0PXZpZXcueCt2aWV3LndpZHRoL3pvb20rcGFkO3RoaXMuYm90dG9tPXZpZXcueSt2aWV3LmhlaWdodC96b29tK3BhZDtcbiAgfVxuICBmb3IoY29uc3QgbWFyayBvZiBmcmFtZS5ncm91bmQpaWYobWFyay5oZWlnaHQ+MCl0aGlzLmFkZChtYXJrLngsbWFyay55LG1hcmsuaGVpZ2h0LG1hcmsucmFkaXVzLG1hcmsucmFkaXVzKi40OCxtYXJrLmFuZ2xlLG1hcmsuYWxwaGEqLjcyLCdkZWNrJyx0cnVlKTtcbiAgZm9yKGNvbnN0IG1hcmsgb2YgZnJhbWUuYm9keSl7Y29uc3QgYXQ9YW5jaG9ycy5nZXQobWFyay51bml0SWQpO2lmKCFhdCljb250aW51ZTtcbiAgIHRoaXMuYWRkKGF0LngrbWFyay5sb2NhbFgqYXQuZmFjaW5nLGF0LnksYXQuZmxvb3ItbWFyay5sb2NhbFkvVElMVCxtYXJrLndpZHRoPz9tYXJrLnJhZGl1cyouNjUsbWFyay5yYWRpdXMsbWFyay5hbmdsZSphdC5mYWNpbmcsbWFyay5hbHBoYSouNzcsJ2JvZHknKTt9XG4gIGZvcihjb25zdCBkcm9wIG9mIGZyYW1lLmRyb3BsZXRzKXtjb25zdCBzcGVlZD1NYXRoLmh5cG90KGRyb3AudngsZHJvcC52eS1kcm9wLnZ6KlRJTFQpLGFuZ2xlPU1hdGguYXRhbjIoZHJvcC52eS1kcm9wLnZ6KlRJTFQsZHJvcC52eCk7XG4gICB0aGlzLmFkZChkcm9wLngsZHJvcC55LGRyb3AuaGVpZ2h0LGRyb3AucmFkaXVzKihyZWR1Y2VkTW90aW9uPzE6MStNYXRoLm1pbiguODUsc3BlZWQvMTgwKSksZHJvcC5yYWRpdXMqLjcsYW5nbGUsZHJvcC5hbHBoYSouODIsJ2FpcicpO31cbiAgaWYoIXJlZHVjZWRNb3Rpb24pZm9yKGNvbnN0IGxpbmUgb2YgZnJhbWUuc3BlZWRMaW5lcyl7Y29uc3QgYXQ9YW5jaG9ycy5nZXQobGluZS51bml0SWQpO2lmKCFhdCljb250aW51ZTtcbiAgIGNvbnN0IGJhY2s9OCtsaW5lLmxlbmd0aC8yO1xuICAgdGhpcy5hZGQobGluZS54K2F0LngtKGF0LnNvdXJjZVg/P2F0LngpLWxpbmUuZHgqYmFjayxsaW5lLnkrYXQueS0oYXQuc291cmNlWT8/YXQueSktbGluZS5keSpiYWNrLGF0LmZsb29yK2xpbmUuaGVpZ2h0LGxpbmUubGVuZ3RoLzIsbGluZS53aWR0aCoyLE1hdGguYXRhbjIobGluZS5keSxsaW5lLmR4KSxsaW5lLmFscGhhKi41OCwnc3BlZWQnKTt9XG4gIGlmKHRoaXMubWVzaCl7dGhpcy5tZXNoLmNvdW50PXRoaXMuY291bnQ7dGhpcy5tZXNoLnZpc2libGU9dGhpcy5jb3VudD4wO3RoaXMubWVzaC5pbnN0YW5jZU1hdHJpeC5uZWVkc1VwZGF0ZT10cnVlO2lmKHRoaXMubWVzaC5pbnN0YW5jZUNvbG9yKXRoaXMubWVzaC5pbnN0YW5jZUNvbG9yLm5lZWRzVXBkYXRlPXRydWU7dGhpcy5kYXRhIS5uZWVkc1VwZGF0ZT10cnVlO31cbiB9XG4gY2xlYXIoKXt0aGlzLmNvdW50PTA7dGhpcy5vdmVyZmxvdz0wO3RoaXMuY3VsbGVkPTA7dGhpcy5raW5kcy5haXI9dGhpcy5raW5kcy5ib2R5PXRoaXMua2luZHMuZGVjaz10aGlzLmtpbmRzLnNwZWVkPTA7aWYodGhpcy5tZXNoKXt0aGlzLm1lc2guY291bnQ9MDt0aGlzLm1lc2gudmlzaWJsZT1mYWxzZTt9fVxuIHN0YXRzKCl7cmV0dXJue2NvdW50OnRoaXMuY291bnQsY2FwYWNpdHk6dGhpcy5jYXBhY2l0eSxkcmF3Q2FsbHM6dGhpcy5jb3VudD8xOjAsYnVmZmVyQnl0ZXM6dGhpcy5jYXBhY2l0eSooMTYrMysyKSo0LGxpbWl0OkNPTUJBVF9JTktfTElNSVQsb3ZlcmZsb3c6dGhpcy5vdmVyZmxvdyxjdWxsZWQ6dGhpcy5jdWxsZWQsLi4udGhpcy5raW5kcyxkaXNwb3NlZDp0aGlzLmRpc3Bvc2VkfTt9XG4gZGlzcG9zZSgpe2lmKHRoaXMuZGlzcG9zZWQpcmV0dXJuO3RoaXMuY2xlYXIoKTt0aGlzLmRpc3Bvc2VkPXRydWU7aWYodGhpcy5tZXNoKXt0aGlzLnNjZW5lLnJlbW92ZSh0aGlzLm1lc2gpO3RoaXMubWVzaC5kaXNwb3NlKCk7dGhpcy5tZXNoLmdlb21ldHJ5LmRpc3Bvc2UoKTt0aGlzLm1lc2g9dW5kZWZpbmVkO310aGlzLmRhdGE9dW5kZWZpbmVkO3RoaXMuY2FwYWNpdHk9MDt0aGlzLm1hdGVyaWFsLmRpc3Bvc2UoKTt9XG59XG4iXSwibWFwcGluZ3MiOiJBQUVBLFlBQVksV0FBVztBQUN2QixTQUFRLG1CQUFrQjtBQUMxQixTQUFRLDhCQUE4QixjQUEwQztBQUdoRixNQUFNLE9BQUssS0FBSyxJQUFJLFlBQVksSUFBSTtBQUM3QixhQUFNLG9CQUFrQixPQUFPLFNBQU8sT0FBTyxpQkFBZSxPQUFPLG1CQUFpQixPQUFPLFNBQU8sT0FBTyxtQkFBaUIsT0FBTyxTQUFPLE9BQU8sYUFBVyxPQUFPO0FBRXhLLE1BQU0sU0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUWIsTUFBTSxXQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFCUixhQUFNLFVBQVU7QUFBQSxFQWlCdEIsWUFBb0IsT0FBa0I7QUFBbEI7QUFBQSxFQUFtQjtBQUFBLEVBaEIvQixXQUFTLElBQUksTUFBTSxlQUFlLEVBQUMsY0FBYSxRQUFPLGdCQUFlLFVBQVMsYUFBWSxNQUFLLFdBQVUsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLE1BQUssTUFBTSxXQUFVLENBQUM7QUFBQSxFQUN2SztBQUFBLEVBQ0E7QUFBQSxFQUNBLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUN6QixRQUFNLElBQUksTUFBTSxNQUFNO0FBQUEsRUFDdEIsUUFBTTtBQUFBLEVBQ04sV0FBUztBQUFBLEVBQ1QsV0FBUztBQUFBLEVBQ1QsU0FBTztBQUFBLEVBQ1AsVUFBUTtBQUFBLEVBQ1IsT0FBSztBQUFBLEVBQ0wsTUFBSTtBQUFBLEVBQ0osUUFBTTtBQUFBLEVBQ04sU0FBTztBQUFBLEVBQ1AsV0FBUztBQUFBLEVBQ1QsUUFBTSxFQUFDLEtBQUksR0FBRSxNQUFLLEdBQUUsTUFBSyxHQUFFLE9BQU0sRUFBQztBQUFBLEVBRWxDLE9BQU8sVUFBZ0I7QUFDOUIsUUFBRyxZQUFVLEtBQUssU0FBUztBQUMzQixVQUFNLFdBQVMsS0FBSyxJQUFJLEtBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksSUFBRyxRQUFRLENBQUMsQ0FBQyxHQUFFLEtBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ2hILFVBQU0sV0FBUyxJQUFJLE1BQU0sY0FBYyxHQUFFLENBQUM7QUFDMUMsVUFBTSxPQUFLLElBQUksTUFBTSx5QkFBeUIsSUFBSSxhQUFhLFdBQVMsQ0FBQyxHQUFFLENBQUMsRUFBRSxTQUFTLE1BQU0sZ0JBQWdCO0FBQUUsYUFBUyxhQUFhLFdBQVUsSUFBSTtBQUNuSixVQUFNLE9BQUssSUFBSSxNQUFNLGNBQWMsVUFBUyxLQUFLLFVBQVMsUUFBUTtBQUFFLFNBQUssT0FBSztBQUFZLFNBQUssZUFBZSxTQUFTLE1BQU0sZ0JBQWdCO0FBQUUsU0FBSyxnQkFBYztBQUFNLFNBQUssVUFBUSxNQUFJO0FBQUEsSUFBQztBQUMxTCxRQUFHLEtBQUssTUFBSztBQUNaLFlBQU0sTUFBSSxLQUFLO0FBQUssZUFBUSxJQUFFLEdBQUUsSUFBRSxLQUFLLE9BQU0sS0FBSTtBQUFDLFlBQUksWUFBWSxHQUFFLEtBQUssTUFBTTtBQUFFLGFBQUssWUFBWSxHQUFFLEtBQUssTUFBTTtBQUFFLFlBQUksV0FBVyxHQUFFLEtBQUssS0FBSztBQUFFLGFBQUssV0FBVyxHQUFFLEtBQUssS0FBSztBQUFFLGFBQUssTUFBTSxHQUFFLEtBQUssS0FBTSxLQUFLLENBQUMsR0FBRSxLQUFLLEtBQU0sS0FBSyxDQUFDLENBQUM7QUFBQSxNQUFFO0FBQ2hPLFdBQUssTUFBTSxPQUFPLEdBQUc7QUFBRSxVQUFJLFFBQVE7QUFBRSxVQUFJLFNBQVMsUUFBUTtBQUFBLElBQzNEO0FBQ0EsU0FBSyxNQUFNLElBQUksSUFBSTtBQUFFLFNBQUssT0FBSztBQUFLLFNBQUssT0FBSztBQUFLLFNBQUssV0FBUztBQUFBLEVBQ2xFO0FBQUEsRUFDUSxJQUFJLEdBQVMsR0FBUyxRQUFjLElBQVUsSUFBVSxPQUFhLE9BQWEsTUFBOEIsT0FBSyxPQUFNO0FBQ2xJLFVBQU0sSUFBRSxLQUFLLElBQUksS0FBSyxHQUFFLElBQUUsS0FBSyxJQUFJLEtBQUs7QUFDeEMsUUFBRyxLQUFLLFNBQVE7QUFLZixZQUFNLGFBQVcsS0FBRyxVQUFRLE9BQU8sT0FBTSxNQUFJO0FBQzdDLFlBQU0sUUFBTSxLQUFLLElBQUksSUFBRSxFQUFFLElBQUUsS0FBSyxJQUFJLElBQUUsRUFBRSxHQUFFLGVBQWEsS0FBSyxJQUFJLElBQUUsRUFBRSxJQUFFLEtBQUssSUFBSSxJQUFFLEVBQUU7QUFDbkYsVUFBRyxJQUFFLFFBQU0sS0FBSyxRQUFNLElBQUUsUUFBTSxLQUFLLFNBQU8sYUFBVyxlQUFhLEtBQUssT0FBSyxhQUFXLGVBQWEsS0FBSyxRQUFPO0FBQUMsYUFBSztBQUFTO0FBQUEsTUFBTztBQUFBLElBQ3ZJO0FBQ0EsUUFBRyxLQUFLLFNBQU8sa0JBQWlCO0FBQUMsV0FBSztBQUFXO0FBQUEsSUFBTztBQUN4RCxTQUFLLE9BQU8sS0FBSyxRQUFNLENBQUM7QUFDeEIsUUFBRyxLQUFLLE1BQUssT0FBTyxJQUFJLElBQUUsSUFBRyxDQUFDLElBQUUsSUFBRyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsU0FBTyxNQUFJLElBQUUsSUFBRyxJQUFFLElBQUcsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUM7QUFBQSxTQUN6RTtBQUdILFdBQUssT0FBTyxJQUFJLElBQUUsSUFBRyxDQUFDLElBQUUsSUFBRyxHQUFFLEdBQUUsQ0FBQyxJQUFFLEtBQUcsTUFBSyxDQUFDLElBQUUsS0FBRyxNQUFLLEdBQUUsU0FBTyxPQUFJLEtBQUssSUFBSSxZQUFZLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFFLE9BQUksS0FBSyxJQUFJLFlBQVksSUFBSSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUM7QUFBQSxJQUM1STtBQUNBLFNBQUssS0FBTSxZQUFZLEtBQUssT0FBTSxLQUFLLE1BQU07QUFDN0MsU0FBSyxNQUFNLElBQUksU0FBTyxVQUFRLFlBQVUsU0FBTyxTQUFPLFlBQVUsU0FBTyxTQUFPLFlBQVUsU0FBUztBQUFFLFNBQUssS0FBTSxXQUFXLEtBQUssT0FBTSxLQUFLLEtBQUs7QUFDOUksU0FBSyxLQUFNLE1BQU0sS0FBSyxPQUFNLE9BQU0sU0FBTyxVQUFRLElBQUUsQ0FBQztBQUFFLFNBQUs7QUFBUSxTQUFLLE1BQU0sSUFBSTtBQUFBLEVBQ25GO0FBQUEsRUFDQSxPQUFPLE9BQThCLFNBQXlDLGdCQUFjLE9BQU0sTUFBZ0I7QUFDakgsUUFBRyxLQUFLLFNBQVM7QUFBTyxTQUFLLE1BQU07QUFDbkMsU0FBSyxVQUFRLENBQUMsQ0FBQztBQUNmLFFBQUcsTUFBSztBQUFDLFlBQU0sT0FBSyxLQUFLLFFBQU0sR0FBRSxNQUFJLElBQUU7QUFDdEMsV0FBSyxPQUFLLEtBQUssSUFBRTtBQUFJLFdBQUssTUFBSSxLQUFLLElBQUU7QUFBSSxXQUFLLFFBQU0sS0FBSyxJQUFFLEtBQUssUUFBTSxPQUFLO0FBQUksV0FBSyxTQUFPLEtBQUssSUFBRSxLQUFLLFNBQU8sT0FBSztBQUFBLElBQ3BIO0FBQ0EsZUFBVSxRQUFRLE1BQU0sT0FBTyxLQUFHLEtBQUssU0FBTyxFQUFFLE1BQUssSUFBSSxLQUFLLEdBQUUsS0FBSyxHQUFFLEtBQUssUUFBTyxLQUFLLFFBQU8sS0FBSyxTQUFPLE1BQUksS0FBSyxPQUFNLEtBQUssUUFBTSxNQUFJLFFBQU8sSUFBSTtBQUNwSixlQUFVLFFBQVEsTUFBTSxNQUFLO0FBQUMsWUFBTSxLQUFHLFFBQVEsSUFBSSxLQUFLLE1BQU07QUFBRSxVQUFHLENBQUMsR0FBRztBQUN0RSxXQUFLLElBQUksR0FBRyxJQUFFLEtBQUssU0FBTyxHQUFHLFFBQU8sR0FBRyxHQUFFLEdBQUcsUUFBTSxLQUFLLFNBQU8sTUFBSyxLQUFLLFNBQU8sS0FBSyxTQUFPLE1BQUksS0FBSyxRQUFPLEtBQUssUUFBTSxHQUFHLFFBQU8sS0FBSyxRQUFNLE1BQUksTUFBTTtBQUFBLElBQUU7QUFDeEosZUFBVSxRQUFRLE1BQU0sVUFBUztBQUFDLFlBQU0sUUFBTSxLQUFLLE1BQU0sS0FBSyxJQUFHLEtBQUssS0FBRyxLQUFLLEtBQUcsSUFBSSxHQUFFLFFBQU0sS0FBSyxNQUFNLEtBQUssS0FBRyxLQUFLLEtBQUcsTUFBSyxLQUFLLEVBQUU7QUFDbkksV0FBSyxJQUFJLEtBQUssR0FBRSxLQUFLLEdBQUUsS0FBSyxRQUFPLEtBQUssVUFBUSxnQkFBYyxJQUFFLElBQUUsS0FBSyxJQUFJLE1BQUksUUFBTSxHQUFHLElBQUcsS0FBSyxTQUFPLEtBQUcsT0FBTSxLQUFLLFFBQU0sTUFBSSxLQUFLO0FBQUEsSUFBRTtBQUN2SSxRQUFHLENBQUMsY0FBYyxZQUFVLFFBQVEsTUFBTSxZQUFXO0FBQUMsWUFBTSxLQUFHLFFBQVEsSUFBSSxLQUFLLE1BQU07QUFBRSxVQUFHLENBQUMsR0FBRztBQUM5RixZQUFNLE9BQUssSUFBRSxLQUFLLFNBQU87QUFDekIsV0FBSyxJQUFJLEtBQUssSUFBRSxHQUFHLEtBQUcsR0FBRyxXQUFTLEdBQUcsS0FBRyxLQUFLLEtBQUcsTUFBSyxLQUFLLElBQUUsR0FBRyxLQUFHLEdBQUcsV0FBUyxHQUFHLEtBQUcsS0FBSyxLQUFHLE1BQUssR0FBRyxRQUFNLEtBQUssUUFBTyxLQUFLLFNBQU8sR0FBRSxLQUFLLFFBQU0sR0FBRSxLQUFLLE1BQU0sS0FBSyxJQUFHLEtBQUssRUFBRSxHQUFFLEtBQUssUUFBTSxNQUFJLE9BQU87QUFBQSxJQUFFO0FBQ3RNLFFBQUcsS0FBSyxNQUFLO0FBQUMsV0FBSyxLQUFLLFFBQU0sS0FBSztBQUFNLFdBQUssS0FBSyxVQUFRLEtBQUssUUFBTTtBQUFFLFdBQUssS0FBSyxlQUFlLGNBQVk7QUFBSyxVQUFHLEtBQUssS0FBSyxjQUFjLE1BQUssS0FBSyxjQUFjLGNBQVk7QUFBSyxXQUFLLEtBQU0sY0FBWTtBQUFBLElBQUs7QUFBQSxFQUNuTjtBQUFBLEVBQ0EsUUFBTztBQUFDLFNBQUssUUFBTTtBQUFFLFNBQUssV0FBUztBQUFFLFNBQUssU0FBTztBQUFFLFNBQUssTUFBTSxNQUFJLEtBQUssTUFBTSxPQUFLLEtBQUssTUFBTSxPQUFLLEtBQUssTUFBTSxRQUFNO0FBQUUsUUFBRyxLQUFLLE1BQUs7QUFBQyxXQUFLLEtBQUssUUFBTTtBQUFFLFdBQUssS0FBSyxVQUFRO0FBQUEsSUFBTTtBQUFBLEVBQUM7QUFBQSxFQUM5SyxRQUFPO0FBQUMsV0FBTSxFQUFDLE9BQU0sS0FBSyxPQUFNLFVBQVMsS0FBSyxVQUFTLFdBQVUsS0FBSyxRQUFNLElBQUUsR0FBRSxhQUFZLEtBQUssWUFBVSxLQUFHLElBQUUsS0FBRyxHQUFFLE9BQU0sa0JBQWlCLFVBQVMsS0FBSyxVQUFTLFFBQU8sS0FBSyxRQUFPLEdBQUcsS0FBSyxPQUFNLFVBQVMsS0FBSyxTQUFRO0FBQUEsRUFBRTtBQUFBLEVBQzVOLFVBQVM7QUFBQyxRQUFHLEtBQUssU0FBUztBQUFPLFNBQUssTUFBTTtBQUFFLFNBQUssV0FBUztBQUFLLFFBQUcsS0FBSyxNQUFLO0FBQUMsV0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJO0FBQUUsV0FBSyxLQUFLLFFBQVE7QUFBRSxXQUFLLEtBQUssU0FBUyxRQUFRO0FBQUUsV0FBSyxPQUFLO0FBQUEsSUFBVTtBQUFDLFNBQUssT0FBSztBQUFVLFNBQUssV0FBUztBQUFFLFNBQUssU0FBUyxRQUFRO0FBQUEsRUFBRTtBQUNoUDsiLCJuYW1lcyI6W119