import { BloodContacts, bloodReceiverBounds } from "/@fs/tmp/sketch-queue-source-42bd/src/client/blood-contact.ts";
import { BLOOD_HEIGHT_PROJECTION as TILT } from "/@fs/tmp/sketch-queue-source-42bd/src/client/combat-surfaces.ts";
import { circleInPolygon, shipProfile, SHIP_CAMERA } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { SIM_TICKS_PER_SECOND } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/time.ts";
const TICK_MS = 1e3 / SIM_TICKS_PER_SECOND;
const GRAVITY = 180;
const LIFE = 9;
const BODY_LIFE = 6;
export const COMBAT_PRESENTATION_LIMITS = Object.freeze({ bursts: 48, residueBursts: 96, dropletsPerBurst: 10, speedLines: 128, seenEvents: 2048, transferredMarks: 192 });
export function isBloodHit(effect) {
  return effect.type === "hit" && effect.targetUnitClass === "nonMechanical" && !!effect.targetKind && effect.targetKind !== "spirit" && Number.isFinite(effect.damage) && effect.damage > 0 && Number.isFinite(effect.targetHpAfter) && effect.targetHpAfter <= effect.damage * 2 && Number.isFinite(effect.targetMaxHp) && effect.targetMaxHp > 0;
}
export class CombatPresentationTracker {
  tick;
  receivedAt = 0;
  effects;
  effectCount = -1;
  frameNow;
  overflowThrough = -1;
  scratch = { x: 0, y: 0 };
  bursts = [];
  residue = [];
  seen = /* @__PURE__ */ new Map();
  positions = /* @__PURE__ */ new Map();
  units = /* @__PURE__ */ new Map();
  lines = [];
  transferred = [];
  surfaces;
  surfaceNow;
  surfaceFrame = /* @__PURE__ */ new Map();
  output = { droplets: [], ground: [], body: [], speedLines: [] };
  reset() {
    this.tick = void 0;
    this.effects = void 0;
    this.effectCount = -1;
    this.receivedAt = 0;
    this.frameNow = void 0;
    this.overflowThrough = -1;
    this.bursts.length = 0;
    this.residue.length = 0;
    this.seen.clear();
    this.positions.clear();
    this.units.clear();
    this.lines.length = 0;
    this.transferred.length = 0;
    this.surfaces = void 0;
    this.surfaceFrame.clear();
    this.surfaceNow = void 0;
    this.output.droplets.length = 0;
    this.output.ground.length = 0;
    this.output.body.length = 0;
    this.output.speedLines.length = 0;
  }
  update(snapshot, now, surfaces, receivers) {
    if (this.tick !== void 0 && snapshot.tick < this.tick) this.reset();
    this.surfaces = surfaces;
    const sameTick = snapshot.tick === this.tick;
    if (sameTick && snapshot.effects === this.effects && snapshot.effects.length === this.effectCount) return;
    this.effects = snapshot.effects;
    this.effectCount = snapshot.effects.length;
    this.frameNow = void 0;
    this.surfaceFrame.clear();
    this.surfaceNow = now;
    const gap = this.tick === void 0 ? 0 : snapshot.tick - this.tick;
    this.tick = snapshot.tick;
    if (!sameTick) this.receivedAt = now;
    this.units.clear();
    for (const unit of snapshot.units) this.units.set(unit.id, unit);
    this.bursts = this.bursts.filter((burst) => (snapshot.tick - burst.tick) / SIM_TICKS_PER_SECOND < LIFE);
    this.residue = this.residue.filter((burst) => (snapshot.tick - burst.tick) / SIM_TICKS_PER_SECOND < LIFE);
    for (const [id, tick] of this.seen) if (snapshot.tick - tick > LIFE * SIM_TICKS_PER_SECOND) this.seen.delete(id);
    const previouslyOverflowed = this.overflowThrough;
    for (const effect of snapshot.effects) {
      if (!isBloodHit(effect) || this.seen.has(effect.id)) continue;
      const tick = snapshot.tick - Math.max(0, effect.duration - effect.remaining);
      if (snapshot.tick - tick >= LIFE * SIM_TICKS_PER_SECOND || tick <= previouslyOverflowed) continue;
      this.seen.set(effect.id, tick);
      this.bursts.push(makeBurst(effect, tick));
      if (this.bursts.length > COMBAT_PRESENTATION_LIMITS.bursts) {
        this.residue.push(this.bursts.shift());
        if (this.residue.length > COMBAT_PRESENTATION_LIMITS.residueBursts) this.residue.shift();
      }
      if (this.seen.size > COMBAT_PRESENTATION_LIMITS.seenEvents) {
        this.seen.delete(this.seen.keys().next().value);
        this.overflowThrough = snapshot.tick;
      }
    }
    this.transferBlood(snapshot.tick, now, receivers);
    if (sameTick) return;
    this.lines.length = 0;
    const next = /* @__PURE__ */ new Map();
    for (const unit of snapshot.units) {
      const previous = this.positions.get(unit.id);
      next.set(unit.id, { x: unit.x, y: unit.y, ...unit.deck ? { deck: { ...unit.deck } } : {} });
      if (!previous || gap <= 0 || gap > 4 || unit.hp <= 0 || unit.effects.some((e) => e.type === "stun")) continue;
      const aboard = unit.deck || previous.deck;
      if (aboard && unit.deck?.shipId !== previous.deck?.shipId) continue;
      let dx = aboard ? unit.deck.x - previous.deck.x : unit.x - previous.x;
      let dy = aboard ? unit.deck.y - previous.deck.y : unit.y - previous.y;
      if (unit.deck) {
        const heading = this.units.get(unit.deck.shipId)?.sailing?.heading ?? 0, c = Math.cos(heading), s = Math.sin(heading);
        const localDx = dx;
        dx = dx * c - dy * s;
        dy = localDx * s + dy * c;
      }
      const distance = Math.hypot(dx, dy), speed = distance * SIM_TICKS_PER_SECOND / gap;
      const forced = (unit.pushX !== void 0 || unit.pushY !== void 0) && speed > Math.max(35, unit.speed * 1.15);
      const charging = unit.order.type === "charge" && speed > Math.max(20, unit.speed * 0.7);
      if (!charging && !forced || distance < 0.1 || speed > 1200) continue;
      const normX = dx / distance, normY = dy / distance;
      const strength = Math.min(1, speed / 300);
      for (let i = 0; i < 3 && this.lines.length < COMBAT_PRESENTATION_LIMITS.speedLines; i++) {
        const side = (i - 1) * unit.radius * 0.65;
        this.lines.push({ unitId: unit.id, x: unit.x - normY * side, y: unit.y + normX * side, dx: normX, dy: normY, length: Math.min(75, 12 + speed * 0.13) * (i === 1 ? 1 : 0.73), width: 0.65 + strength * 0.6, height: unit.radius * (0.35 + i * 0.38), alpha: 0.18 + strength * 0.35 });
      }
    }
    this.positions = next;
  }
  surfaceFor(unit, now) {
    if (!this.surfaces) return void 0;
    if (this.surfaceNow !== now) {
      this.surfaceFrame.clear();
      this.surfaceNow = now;
    }
    let surface = this.surfaceFrame.get(unit.id);
    if (!surface) {
      surface = this.surfaces(unit, now);
      this.surfaceFrame.set(unit.id, surface);
    }
    return surface;
  }
  transferBlood(tick, now, receivers) {
    this.transferred = this.transferred.filter((stain) => {
      const unit = this.units.get(stain.mark.unitId);
      if (!unit || unit.hp <= 0 || tick - stain.tick >= BODY_LIFE * SIM_TICKS_PER_SECOND) return false;
      return !stain.weapon || !this.surfaces || this.surfaceFor(unit, now)?.weapon?.key === stain.weapon.key;
    });
    const active = this.bursts.filter((burst) => burst.drops.some((drop) => !drop.caught && burst.checkedAge < drop.landTime));
    if (!active.length) return;
    const resolve = this.surfaces ? (unit, time) => this.surfaceFor(unit, time) : void 0;
    let candidates = this.units.values();
    if (receivers) {
      const bounds = [];
      for (const burst of active) {
        const age = Math.max(0, (tick - burst.tick) / SIM_TICKS_PER_SECOND);
        const hull = burst.deck ? this.units.get(burst.deck.shipId) : void 0, profile = hull && hull.hp > 0 ? shipProfile(hull) : void 0;
        if (burst.deck && !profile) continue;
        const heading = hull?.sailing?.heading ?? 0, c = Math.cos(heading), s = Math.sin(heading);
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const drop of burst.drops) {
          if (drop.caught || burst.checkedAge > drop.landTime) continue;
          const end = Math.min(age, drop.landTime), start = Math.min(burst.checkedAge, end);
          for (let endpoint = 0; endpoint < 2; endpoint++) {
            const t = endpoint === 0 ? start : end;
            const x = burst.x + drop.ox + drop.vx * t, y = burst.y + drop.oy + drop.vy * t;
            const worldX = hull ? hull.x + x * c - y * s : x, worldY = hull ? hull.y + x * s + y * c : y;
            minX = Math.min(minX, worldX);
            minY = Math.min(minY, worldY);
            maxX = Math.max(maxX, worldX);
            maxY = Math.max(maxY, worldY);
          }
        }
        bounds.push(bloodReceiverBounds(minX, minY, maxX, maxY));
      }
      if (!bounds.length) return;
      candidates = receivers(bounds);
    }
    const contacts = new BloodContacts(candidates, resolve, now);
    for (const burst of active) {
      const age = Math.max(0, (tick - burst.tick) / SIM_TICKS_PER_SECOND);
      const hull = burst.deck ? this.units.get(burst.deck.shipId) : void 0, profile = hull && hull.hp > 0 ? shipProfile(hull) : void 0;
      if (burst.deck && !profile) continue;
      const heading = hull?.sailing?.heading ?? 0, c = Math.cos(heading), s = Math.sin(heading);
      for (const drop of burst.drops) {
        if (drop.caught || burst.checkedAge > drop.landTime) continue;
        const end = Math.min(age, drop.landTime), start = Math.min(burst.checkedAge, end);
        const point = (t) => {
          const x = burst.x + drop.ox + drop.vx * t, y = burst.y + drop.oy + drop.vy * t;
          return { x: hull ? hull.x + x * c - y * s : x, y: hull ? hull.y + x * s + y * c : y, z: (profile?.deckHeight ?? burst.floor) + Math.max(0, drop.height + drop.vz * t - 0.5 * GRAVITY * t * t) };
        };
        const steps = Math.max(1, Math.ceil((end - start) * SIM_TICKS_PER_SECOND));
        for (let i = 0; i < steps; i++) {
          const t0 = start + (end - start) * i / steps, t1 = start + (end - start) * (i + 1) / steps;
          const contact = contacts.contact(point(t0), point(t1), drop.radius, burst.unitId, burst.contacts);
          if (!contact) continue;
          const mark = {
            unitId: contact.unit.id,
            x: contact.unit.x,
            y: contact.unit.y,
            height: contact.point.z,
            localX: (contact.point.x - contact.unit.x) * contact.surface.facing,
            localY: -(contact.point.z - contact.surface.floor) * TILT,
            radius: Math.min(3.8, drop.radius * 1.2),
            angle: drop.angle,
            alpha: 0.8,
            ...contact.weapon ? { surface: "weapon", width: contact.weapon.width * 0.8 } : {}
          };
          this.transferred.push({ tick: burst.tick + (t0 + (t1 - t0) * contact.distance) * SIM_TICKS_PER_SECOND, mark, ...contact.weapon ? { weapon: contact.weapon } : {} });
          if (this.transferred.length > COMBAT_PRESENTATION_LIMITS.transferredMarks) this.transferred.shift();
          burst.contacts.add(`${contact.unit.id}:${contact.weapon ? "weapon" : "body"}`);
          drop.caught = true;
          break;
        }
      }
      burst.checkedAge = age;
    }
  }
  /** Returned records are reused until the next call; render immediately or
   * copy for retained captures. Never drives the simulation or an RNG. */
  frame(now) {
    const out = this.output;
    if (this.frameNow === now) return out;
    this.frameNow = now;
    out.droplets.length = 0;
    out.ground.length = 0;
    out.body.length = 0;
    out.speedLines.length = 0;
    if (this.tick === void 0) return out;
    const fraction = Math.max(0, Math.min(1, (now - this.receivedAt) / TICK_MS));
    const clock = this.tick + fraction;
    for (let index = 0; index < this.residue.length + this.bursts.length; index++) {
      const active = index >= this.residue.length;
      const burst = active ? this.bursts[index - this.residue.length] : this.residue[index];
      const age = Math.max(0, (clock - burst.tick) / SIM_TICKS_PER_SECOND);
      if (age >= LIFE) continue;
      const unit = this.units.get(burst.unitId);
      if (active && unit && unit.hp > 0 && age < BODY_LIFE) {
        const p = burst.mark;
        p.x = unit.x;
        p.y = unit.y;
        p.alpha = 0.65 * fade(age, 3, BODY_LIFE);
        out.body.push(p);
      }
      const hull = burst.deck ? this.units.get(burst.deck.shipId) : void 0;
      const profile = hull && hull.hp > 0 ? shipProfile(hull) : void 0;
      if (burst.deck && !profile) continue;
      const heading = hull?.sailing?.heading ?? 0, c = Math.cos(heading), s = Math.sin(heading);
      for (const drop of burst.drops) {
        if (drop.caught) continue;
        const t = Math.min(age, drop.landTime);
        const localX = burst.x + drop.ox + drop.vx * t, localY = burst.y + drop.oy + drop.vy * t;
        this.scratch.x = localX;
        this.scratch.y = localY;
        if (profile && !circleInPolygon(this.scratch, drop.radius, profile.deck)) continue;
        const x = hull ? hull.x + localX * c - localY * s : localX;
        const y = hull ? hull.y + localX * s + localY * c : localY;
        if (age < drop.landTime) {
          if (!active) continue;
          const p = drop.air;
          p.x = x;
          p.y = y;
          p.height = (profile?.deckHeight ?? burst.floor) + Math.max(0, drop.height + drop.vz * age - 0.5 * GRAVITY * age * age);
          p.vx = drop.vx * c - drop.vy * s;
          p.vy = drop.vx * s + drop.vy * c;
          p.vz = drop.vz - GRAVITY * age;
          out.droplets.push(p);
        } else {
          const p = drop.ground;
          p.x = x;
          p.y = y;
          p.height = profile?.deckHeight ?? burst.floor;
          p.angle = drop.angle + (hull?.sailing?.heading ?? 0);
          p.alpha = 0.58 * fade(age, 5, LIFE);
          out.ground.push(p);
        }
      }
    }
    for (const stain of this.transferred) {
      const age = (clock - stain.tick) / SIM_TICKS_PER_SECOND, unit = this.units.get(stain.mark.unitId);
      if (!unit || unit.hp <= 0 || age >= BODY_LIFE) continue;
      const mark = stain.mark;
      if (stain.weapon) {
        const weapon = this.surfaceFor(unit, now)?.weapon;
        if (!weapon || weapon.key !== stain.weapon.key) continue;
        const segment = weapon.segments[stain.weapon.segment];
        if (!segment) continue;
        mark.localX = segment.a[0] + (segment.b[0] - segment.a[0]) * stain.weapon.t;
        mark.localY = segment.a[1] + (segment.b[1] - segment.a[1]) * stain.weapon.t;
        mark.angle = Math.atan2(segment.b[1] - segment.a[1], segment.b[0] - segment.a[0]) + Math.PI / 2;
        mark.width = segment.width * 0.8;
      }
      mark.x = unit.x;
      mark.y = unit.y;
      mark.alpha = 0.8 * fade(age, 3, BODY_LIFE);
      out.body.push(mark);
    }
    for (const line of this.lines) out.speedLines.push(line);
    return out;
  }
}
const fade = (age, start, end) => Math.max(0, Math.min(1, (end - age) / (end - start)));
function makeBurst(effect, tick) {
  const random = seeded(effect.id + ":" + tick);
  const radius = Math.max(6, Math.min(60, effect.targetRadius ?? 17));
  const severity = Math.min(1, effect.damage / effect.targetMaxHp);
  const count = Math.min(COMBAT_PRESENTATION_LIMITS.dropletsPerBurst, 3 + Math.floor(Math.sqrt(severity) * 7));
  const from = Number.isFinite(effect.fromX) && Number.isFinite(effect.fromY);
  const direction = (from ? Math.atan2(effect.y - effect.fromY, effect.x - effect.fromX) : 0) - (effect.targetDeck?.heading ?? 0);
  const floor = effect.targetDeck ? Math.max(0, (effect.toHeight ?? 18) - 18) : 0;
  const originX = effect.targetDeck?.x ?? effect.x, originY = effect.targetDeck?.y ?? effect.y;
  const drops = [];
  const height = radius * (1.7 + random() * 0.45);
  for (let i = 0; i < count; i++) {
    const angle = from ? direction + (i % 4 === 3 ? Math.PI : 0) + (random() - 0.5) * 1.5 : random() * Math.PI * 2;
    const speed = (18 + Math.sqrt(severity) * 65) * (0.5 + random() * 0.65);
    const vx = Math.cos(angle) * speed, vy = Math.sin(angle) * speed;
    const vz = 10 + random() * 32;
    const landTime = (vz + Math.sqrt(vz * vz + 2 * GRAVITY * height)) / GRAVITY;
    const size = 0.65 + Math.sqrt(severity) * (1 + random() * 1.7);
    const ox = (random() - 0.5) * radius * 0.28, oy = (random() - 0.5) * radius * 0.28;
    drops.push({
      ox,
      oy,
      vx,
      vy,
      vz,
      height,
      landTime,
      radius: size,
      angle,
      air: { x: effect.x, y: effect.y, height: floor + height, vx, vy, vz, radius: size, alpha: 0.86 },
      ground: { x: originX + vx * landTime, y: originY + vy * landTime, height: floor, radius: size * 1.5, angle, alpha: 0.58 }
    });
  }
  return {
    contacts: /* @__PURE__ */ new Set(),
    checkedAge: 0,
    id: effect.id,
    tick,
    unitId: effect.unitId ?? "",
    x: originX,
    y: originY,
    ...effect.targetDeck ? { deck: effect.targetDeck } : {},
    floor,
    drops,
    mark: { unitId: effect.unitId ?? "", x: effect.x, y: effect.y, height, localX: (random() - 0.5) * radius * 0.5, localY: -height * Math.tan(SHIP_CAMERA.tilt), radius: 1.4 + severity * 2.6, angle: random() * Math.PI, alpha: 0.65 }
  };
}
function seeded(text) {
  let state = 2166136261;
  for (let i = 0; i < text.length; i++) state = Math.imul(state ^ text.charCodeAt(i), 16777619);
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbWJhdC1wcmVzZW50YXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqIERldGVybWluaXN0aWMsIGJvdW5kZWQgY2xpZW50LW9ubHkgaGl0IGRlYnJpcy4gU2ltdWxhdGlvbiBlbWl0cyBmYWN0cywgbmV2ZXJcbiAqIHBhcnRpY2xlczsgYWxsIHBvc2l0aW9ucyBhcmUgd29ybGQgdW5pdHMgYW5kIGhlaWdodCBwb2ludHMgdXAgZnJvbSB0aGUgZmxvb3IuICovXG5pbXBvcnQge0Jsb29kQ29udGFjdHMsYmxvb2RSZWNlaXZlckJvdW5kcyx0eXBlIEJsb29kUG9pbnQsdHlwZSBCbG9vZFJlY2VpdmVyQm91bmRzfSBmcm9tICcuL2Jsb29kLWNvbnRhY3QnO1xuaW1wb3J0IHtCTE9PRF9IRUlHSFRfUFJPSkVDVElPTiBhcyBUSUxULHR5cGUgQmxvb2RTdXJmYWNlUmVzb2x2ZXJ9IGZyb20gJy4vY29tYmF0LXN1cmZhY2VzJztcbmltcG9ydCB7IGNpcmNsZUluUG9seWdvbiwgc2hpcFByb2ZpbGUsIFNISVBfQ0FNRVJBIH0gZnJvbSAnLi4vc2hhcmVkL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHsgU0lNX1RJQ0tTX1BFUl9TRUNPTkQgfSBmcm9tICcuLi9zaGFyZWQvdGltZSc7XG5pbXBvcnQgdHlwZSB7IEdhbWVTbmFwc2hvdCwgVW5pdCwgV29ybGRFZmZlY3QgfSBmcm9tICcuLi9zaGFyZWQvdHlwZXMnO1xuXG5leHBvcnQgdHlwZSBCbG9vZERyb3BsZXQgPSB7IHg6bnVtYmVyOyB5Om51bWJlcjsgaGVpZ2h0Om51bWJlcjsgdng6bnVtYmVyOyB2eTpudW1iZXI7IHZ6Om51bWJlcjsgcmFkaXVzOm51bWJlcjsgYWxwaGE6bnVtYmVyIH07XG5leHBvcnQgdHlwZSBHcm91bmRCbG9vZCA9IHsgeDpudW1iZXI7IHk6bnVtYmVyOyBoZWlnaHQ6bnVtYmVyOyByYWRpdXM6bnVtYmVyOyBhbmdsZTpudW1iZXI7IGFscGhhOm51bWJlciB9O1xuLyoqIGxvY2FsWC9sb2NhbFkgYXJlIGRyYXdpbmcgb2Zmc2V0cyAoc2NyZWVuLXdvcmxkIHVuaXRzKSBmcm9tIHRoZSB1bml0J3MgZmVldC5cbiAqIE1pcnJvciBsb2NhbFggd2l0aCBjdXJyZW50IGZhY2luZzsgbG9jYWxZIHByb2plY3RzIHBoeXNpY2FsIGhlaWdodCBieSBjYW1lcmEgdGlsdC4gKi9cbmV4cG9ydCB0eXBlIEJvZHlCbG9vZCA9IEdyb3VuZEJsb29kICYgeyB1bml0SWQ6c3RyaW5nOyBoZWlnaHQ6bnVtYmVyOyBsb2NhbFg6bnVtYmVyOyBsb2NhbFk6bnVtYmVyOyBzdXJmYWNlPzond2VhcG9uJzsgd2lkdGg/Om51bWJlciB9O1xuZXhwb3J0IHR5cGUgQ29tYmF0U3BlZWRMaW5lID0geyB1bml0SWQ6c3RyaW5nOyB4Om51bWJlcjsgeTpudW1iZXI7IGR4Om51bWJlcjsgZHk6bnVtYmVyOyBsZW5ndGg6bnVtYmVyOyB3aWR0aDpudW1iZXI7IGhlaWdodDpudW1iZXI7IGFscGhhOm51bWJlciB9O1xuZXhwb3J0IHR5cGUgQ29tYmF0UHJlc2VudGF0aW9uRnJhbWUgPSB7IGRyb3BsZXRzOkJsb29kRHJvcGxldFtdOyBncm91bmQ6R3JvdW5kQmxvb2RbXTsgYm9keTpCb2R5Qmxvb2RbXTsgc3BlZWRMaW5lczpDb21iYXRTcGVlZExpbmVbXSB9O1xuLyoqIFF1ZXJ5IHRoZSB3aG9sZSB3b3JsZCwgaW5kZXBlbmRlbnRseSBvZiB0aGUgY2FtZXJhLiBQcmVzZXJ2ZSB0aGUgY3VycmVudFxuICogc25hcHNob3QncyB1bml0IG9yZGVyIHNvIGVxdWFsLWRpc3RhbmNlIGNvbnRhY3RzIGtlZXAgdGhlIHNhbWUgcmVjZWl2ZXIuICovXG5leHBvcnQgdHlwZSBCbG9vZFJlY2VpdmVyUXVlcnk9KGJvdW5kczpyZWFkb25seSBCbG9vZFJlY2VpdmVyQm91bmRzW10pPT5JdGVyYWJsZTxVbml0PjtcbnR5cGUgU25hcHNob3QgPSBQaWNrPEdhbWVTbmFwc2hvdCwndGljayd8J3VuaXRzJ3wnZWZmZWN0cyc+O1xudHlwZSBEcm9wID0geyBjYXVnaHQ/OmJvb2xlYW47IG94Om51bWJlcjtveTpudW1iZXI7IHZ4Om51bWJlcjsgdnk6bnVtYmVyOyB2ejpudW1iZXI7IGhlaWdodDpudW1iZXI7IGxhbmRUaW1lOm51bWJlcjsgcmFkaXVzOm51bWJlcjsgYW5nbGU6bnVtYmVyOyBhaXI6Qmxvb2REcm9wbGV0OyBncm91bmQ6R3JvdW5kQmxvb2QgfTtcbnR5cGUgQnVyc3QgPSB7IGNvbnRhY3RzOlNldDxzdHJpbmc+OyBjaGVja2VkQWdlOm51bWJlcjsgaWQ6c3RyaW5nOyB0aWNrOm51bWJlcjsgdW5pdElkOnN0cmluZzsgeDpudW1iZXI7IHk6bnVtYmVyOyBkZWNrPzpOb25OdWxsYWJsZTxXb3JsZEVmZmVjdFsndGFyZ2V0RGVjayddPjsgZmxvb3I6bnVtYmVyOyBkcm9wczpEcm9wW107IG1hcms6Qm9keUJsb29kIH07XG50eXBlIFRyYW5zZmVycmVkQmxvb2Q9e3RpY2s6bnVtYmVyO21hcms6Qm9keUJsb29kO3dlYXBvbj86e2tleTpzdHJpbmc7c2VnbWVudDpudW1iZXI7dDpudW1iZXJ9fTtcbnR5cGUgUG9zaXRpb24gPSB7IHg6bnVtYmVyOyB5Om51bWJlcjsgZGVjaz86e3g6bnVtYmVyO3k6bnVtYmVyO3NoaXBJZDpzdHJpbmd9IH07XG5jb25zdCBUSUNLX01TPTEwMDAvU0lNX1RJQ0tTX1BFUl9TRUNPTkQ7XG5jb25zdCBHUkFWSVRZPTE4MDtcbmNvbnN0IExJRkU9OTtcbmNvbnN0IEJPRFlfTElGRT02O1xuZXhwb3J0IGNvbnN0IENPTUJBVF9QUkVTRU5UQVRJT05fTElNSVRTPU9iamVjdC5mcmVlemUoeyBidXJzdHM6NDgsIHJlc2lkdWVCdXJzdHM6OTYsIGRyb3BsZXRzUGVyQnVyc3Q6MTAsIHNwZWVkTGluZXM6MTI4LCBzZWVuRXZlbnRzOjIwNDgsIHRyYW5zZmVycmVkTWFya3M6MTkyIH0pO1xuXG4vKiogUGh5c2ljYWwgbm9uLW1lY2hhbmljYWwgdGFyZ2V0cyBibGVlZCBvbmx5IG9uIGEgbGV0aGFsIG9yIGdlbnVpbmVseSBjbG9zZS1cbiAqIHRvLWxldGhhbCBoaXQuIFNwaXJpdHMgaGF2ZSBubyBibG9vZDsgdGhlaXIgY29tYmF0IGNsYXNzIHJlbWFpbnMgdW5jaGFuZ2VkLlxuICogTWlzc2luZyBvbGQtc2F2ZSBtZXRhZGF0YSBpcyBub3QgZ3Vlc3NlZCBmcm9tIGEgbGF0ZXIgbGl2ZSB1bml0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQmxvb2RIaXQoZWZmZWN0OldvcmxkRWZmZWN0KTpib29sZWFuIHtcbiAgcmV0dXJuIGVmZmVjdC50eXBlPT09J2hpdCcgJiYgZWZmZWN0LnRhcmdldFVuaXRDbGFzcz09PSdub25NZWNoYW5pY2FsJyAmJiAhIWVmZmVjdC50YXJnZXRLaW5kXG4gICAgJiYgZWZmZWN0LnRhcmdldEtpbmQhPT0nc3Bpcml0J1xuICAgICYmIE51bWJlci5pc0Zpbml0ZShlZmZlY3QuZGFtYWdlKSAmJiBlZmZlY3QuZGFtYWdlIT4wXG4gICAgJiYgTnVtYmVyLmlzRmluaXRlKGVmZmVjdC50YXJnZXRIcEFmdGVyKSAmJiBlZmZlY3QudGFyZ2V0SHBBZnRlciE8PWVmZmVjdC5kYW1hZ2UhKjJcbiAgICAmJiBOdW1iZXIuaXNGaW5pdGUoZWZmZWN0LnRhcmdldE1heEhwKSAmJiBlZmZlY3QudGFyZ2V0TWF4SHAhPjA7XG59XG5cbmV4cG9ydCBjbGFzcyBDb21iYXRQcmVzZW50YXRpb25UcmFja2VyIHtcbiAgcHJpdmF0ZSB0aWNrOm51bWJlcnx1bmRlZmluZWQ7XG4gIHByaXZhdGUgcmVjZWl2ZWRBdD0wO1xuICBwcml2YXRlIGVmZmVjdHM6IHJlYWRvbmx5IFdvcmxkRWZmZWN0W10gfCB1bmRlZmluZWQ7XG4gIHByaXZhdGUgZWZmZWN0Q291bnQ9LTE7XG4gIHByaXZhdGUgZnJhbWVOb3c6bnVtYmVyfHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBvdmVyZmxvd1Rocm91Z2g9LTE7XG4gIHByaXZhdGUgc2NyYXRjaD17eDowLHk6MH07XG4gIHByaXZhdGUgYnVyc3RzOkJ1cnN0W109W107XG4gIHByaXZhdGUgcmVzaWR1ZTpCdXJzdFtdPVtdO1xuICBwcml2YXRlIHNlZW49bmV3IE1hcDxzdHJpbmcsbnVtYmVyPigpO1xuICBwcml2YXRlIHBvc2l0aW9ucz1uZXcgTWFwPHN0cmluZyxQb3NpdGlvbj4oKTtcbiAgcHJpdmF0ZSB1bml0cz1uZXcgTWFwPHN0cmluZyxVbml0PigpO1xuICBwcml2YXRlIGxpbmVzOkNvbWJhdFNwZWVkTGluZVtdPVtdO1xuICBwcml2YXRlIHRyYW5zZmVycmVkOlRyYW5zZmVycmVkQmxvb2RbXT1bXTtcbiAgcHJpdmF0ZSBzdXJmYWNlczpCbG9vZFN1cmZhY2VSZXNvbHZlcnx1bmRlZmluZWQ7XG4gIHByaXZhdGUgc3VyZmFjZU5vdzpudW1iZXJ8dW5kZWZpbmVkO1xuICBwcml2YXRlIHN1cmZhY2VGcmFtZT1uZXcgTWFwPHN0cmluZyxSZXR1cm5UeXBlPEJsb29kU3VyZmFjZVJlc29sdmVyPj4oKTtcbiAgcHJpdmF0ZSBvdXRwdXQ6Q29tYmF0UHJlc2VudGF0aW9uRnJhbWU9e2Ryb3BsZXRzOltdLGdyb3VuZDpbXSxib2R5OltdLHNwZWVkTGluZXM6W119O1xuXG4gIHJlc2V0KCkge1xuICAgIHRoaXMudGljaz11bmRlZmluZWQ7dGhpcy5lZmZlY3RzPXVuZGVmaW5lZDt0aGlzLmVmZmVjdENvdW50PS0xO3RoaXMucmVjZWl2ZWRBdD0wO3RoaXMuZnJhbWVOb3c9dW5kZWZpbmVkO3RoaXMub3ZlcmZsb3dUaHJvdWdoPS0xO3RoaXMuYnVyc3RzLmxlbmd0aD0wO3RoaXMucmVzaWR1ZS5sZW5ndGg9MDt0aGlzLnNlZW4uY2xlYXIoKTt0aGlzLnBvc2l0aW9ucy5jbGVhcigpO3RoaXMudW5pdHMuY2xlYXIoKTt0aGlzLmxpbmVzLmxlbmd0aD0wO3RoaXMudHJhbnNmZXJyZWQubGVuZ3RoPTA7dGhpcy5zdXJmYWNlcz11bmRlZmluZWQ7dGhpcy5zdXJmYWNlRnJhbWUuY2xlYXIoKTt0aGlzLnN1cmZhY2VOb3c9dW5kZWZpbmVkO1xuICAgIHRoaXMub3V0cHV0LmRyb3BsZXRzLmxlbmd0aD0wO3RoaXMub3V0cHV0Lmdyb3VuZC5sZW5ndGg9MDt0aGlzLm91dHB1dC5ib2R5Lmxlbmd0aD0wO3RoaXMub3V0cHV0LnNwZWVkTGluZXMubGVuZ3RoPTA7XG4gIH1cblxuICB1cGRhdGUoc25hcHNob3Q6U25hcHNob3Qsbm93Om51bWJlcixzdXJmYWNlcz86Qmxvb2RTdXJmYWNlUmVzb2x2ZXIscmVjZWl2ZXJzPzpCbG9vZFJlY2VpdmVyUXVlcnkpIHtcbiAgICBpZih0aGlzLnRpY2shPT11bmRlZmluZWQgJiYgc25hcHNob3QudGljazx0aGlzLnRpY2spdGhpcy5yZXNldCgpO1xuICAgIHRoaXMuc3VyZmFjZXM9c3VyZmFjZXM7XG4gICAgY29uc3Qgc2FtZVRpY2s9c25hcHNob3QudGljaz09PXRoaXMudGljaztcbiAgICBpZihzYW1lVGljayYmc25hcHNob3QuZWZmZWN0cz09PXRoaXMuZWZmZWN0cyYmc25hcHNob3QuZWZmZWN0cy5sZW5ndGg9PT10aGlzLmVmZmVjdENvdW50KXJldHVybjtcbiAgICB0aGlzLmVmZmVjdHM9c25hcHNob3QuZWZmZWN0czt0aGlzLmVmZmVjdENvdW50PXNuYXBzaG90LmVmZmVjdHMubGVuZ3RoO1xuICAgIHRoaXMuZnJhbWVOb3c9dW5kZWZpbmVkO3RoaXMuc3VyZmFjZUZyYW1lLmNsZWFyKCk7dGhpcy5zdXJmYWNlTm93PW5vdztcbiAgICBjb25zdCBnYXA9dGhpcy50aWNrPT09dW5kZWZpbmVkPzA6c25hcHNob3QudGljay10aGlzLnRpY2s7XG4gICAgdGhpcy50aWNrPXNuYXBzaG90LnRpY2s7aWYoIXNhbWVUaWNrKXRoaXMucmVjZWl2ZWRBdD1ub3c7XG4gICAgdGhpcy51bml0cy5jbGVhcigpO2Zvcihjb25zdCB1bml0IG9mIHNuYXBzaG90LnVuaXRzKXRoaXMudW5pdHMuc2V0KHVuaXQuaWQsdW5pdCk7XG4gICAgdGhpcy5idXJzdHM9dGhpcy5idXJzdHMuZmlsdGVyKGJ1cnN0PT4oc25hcHNob3QudGljay1idXJzdC50aWNrKS9TSU1fVElDS1NfUEVSX1NFQ09ORDxMSUZFKTtcbiAgICB0aGlzLnJlc2lkdWU9dGhpcy5yZXNpZHVlLmZpbHRlcihidXJzdD0+KHNuYXBzaG90LnRpY2stYnVyc3QudGljaykvU0lNX1RJQ0tTX1BFUl9TRUNPTkQ8TElGRSk7XG4gICAgZm9yKGNvbnN0IFtpZCx0aWNrXSBvZiB0aGlzLnNlZW4paWYoc25hcHNob3QudGljay10aWNrPkxJRkUqU0lNX1RJQ0tTX1BFUl9TRUNPTkQpdGhpcy5zZWVuLmRlbGV0ZShpZCk7XG4gICAgY29uc3QgcHJldmlvdXNseU92ZXJmbG93ZWQ9dGhpcy5vdmVyZmxvd1Rocm91Z2g7XG4gICAgZm9yKGNvbnN0IGVmZmVjdCBvZiBzbmFwc2hvdC5lZmZlY3RzKSB7XG4gICAgICBpZighaXNCbG9vZEhpdChlZmZlY3QpfHx0aGlzLnNlZW4uaGFzKGVmZmVjdC5pZCkpY29udGludWU7XG4gICAgICBjb25zdCB0aWNrPXNuYXBzaG90LnRpY2stTWF0aC5tYXgoMCxlZmZlY3QuZHVyYXRpb24tZWZmZWN0LnJlbWFpbmluZyk7XG4gICAgICBpZihzbmFwc2hvdC50aWNrLXRpY2s+PUxJRkUqU0lNX1RJQ0tTX1BFUl9TRUNPTkR8fHRpY2s8PXByZXZpb3VzbHlPdmVyZmxvd2VkKWNvbnRpbnVlO1xuICAgICAgdGhpcy5zZWVuLnNldChlZmZlY3QuaWQsdGljayk7XG4gICAgICB0aGlzLmJ1cnN0cy5wdXNoKG1ha2VCdXJzdChlZmZlY3QsdGljaykpO1xuICAgICAgaWYodGhpcy5idXJzdHMubGVuZ3RoPkNPTUJBVF9QUkVTRU5UQVRJT05fTElNSVRTLmJ1cnN0cykge1xuICAgICAgICB0aGlzLnJlc2lkdWUucHVzaCh0aGlzLmJ1cnN0cy5zaGlmdCgpISk7XG4gICAgICAgIGlmKHRoaXMucmVzaWR1ZS5sZW5ndGg+Q09NQkFUX1BSRVNFTlRBVElPTl9MSU1JVFMucmVzaWR1ZUJ1cnN0cyl0aGlzLnJlc2lkdWUuc2hpZnQoKTtcbiAgICAgIH1cbiAgICAgIGlmKHRoaXMuc2Vlbi5zaXplPkNPTUJBVF9QUkVTRU5UQVRJT05fTElNSVRTLnNlZW5FdmVudHMpIHsgdGhpcy5zZWVuLmRlbGV0ZSh0aGlzLnNlZW4ua2V5cygpLm5leHQoKS52YWx1ZSEpO3RoaXMub3ZlcmZsb3dUaHJvdWdoPXNuYXBzaG90LnRpY2s7IH1cbiAgICB9XG4gICAgdGhpcy50cmFuc2ZlckJsb29kKHNuYXBzaG90LnRpY2ssbm93LHJlY2VpdmVycyk7XG4gICAgLy8gQSBoaXQgY2FuIGFycml2ZSBiZXR3ZWVuIGRyYXdzIG9mIHRoZSBzYW1lIHRpY2suIENvbnN1bWUgaXQgd2l0aG91dFxuICAgIC8vIHRyZWF0aW5nIGFuIHVuY2hhbmdlZCBwb3NpdGlvbiBhcyBhIG5ldyBtb3Rpb24gb2JzZXJ2YXRpb24uXG4gICAgaWYoc2FtZVRpY2spcmV0dXJuO1xuICAgIHRoaXMubGluZXMubGVuZ3RoPTA7XG4gICAgY29uc3QgbmV4dD1uZXcgTWFwPHN0cmluZyxQb3NpdGlvbj4oKTtcbiAgICBmb3IoY29uc3QgdW5pdCBvZiBzbmFwc2hvdC51bml0cykge1xuICAgICAgY29uc3QgcHJldmlvdXM9dGhpcy5wb3NpdGlvbnMuZ2V0KHVuaXQuaWQpO1xuICAgICAgbmV4dC5zZXQodW5pdC5pZCx7eDp1bml0LngseTp1bml0LnksLi4uKHVuaXQuZGVjaz97ZGVjazp7Li4udW5pdC5kZWNrfX06e30pfSk7XG4gICAgICBpZighcHJldmlvdXN8fGdhcDw9MHx8Z2FwPjR8fHVuaXQuaHA8PTB8fHVuaXQuZWZmZWN0cy5zb21lKGU9PmUudHlwZT09PSdzdHVuJykpY29udGludWU7XG4gICAgICAvLyBDcmV3IG1vdGlvbiBpcyByZWxhdGl2ZSB0byB0aGUgZGVjaywgbmV2ZXIgdGhlIHNoaXAgY2FycnlpbmcgaXQuXG4gICAgICBjb25zdCBhYm9hcmQ9dW5pdC5kZWNrfHxwcmV2aW91cy5kZWNrO1xuICAgICAgaWYoYWJvYXJkJiZ1bml0LmRlY2s/LnNoaXBJZCE9PXByZXZpb3VzLmRlY2s/LnNoaXBJZCljb250aW51ZTtcbiAgICAgIGxldCBkeD1hYm9hcmQ/dW5pdC5kZWNrIS54LXByZXZpb3VzLmRlY2shLng6dW5pdC54LXByZXZpb3VzLng7XG4gICAgICBsZXQgZHk9YWJvYXJkP3VuaXQuZGVjayEueS1wcmV2aW91cy5kZWNrIS55OnVuaXQueS1wcmV2aW91cy55O1xuICAgICAgaWYodW5pdC5kZWNrKSB7XG4gICAgICAgIGNvbnN0IGhlYWRpbmc9dGhpcy51bml0cy5nZXQodW5pdC5kZWNrLnNoaXBJZCk/LnNhaWxpbmc/LmhlYWRpbmc/PzAsYz1NYXRoLmNvcyhoZWFkaW5nKSxzPU1hdGguc2luKGhlYWRpbmcpO1xuICAgICAgICBjb25zdCBsb2NhbER4PWR4O2R4PWR4KmMtZHkqcztkeT1sb2NhbER4KnMrZHkqYztcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRpc3RhbmNlPU1hdGguaHlwb3QoZHgsZHkpLCBzcGVlZD1kaXN0YW5jZSpTSU1fVElDS1NfUEVSX1NFQ09ORC9nYXA7XG4gICAgICBjb25zdCBmb3JjZWQ9KHVuaXQucHVzaFghPT11bmRlZmluZWR8fHVuaXQucHVzaFkhPT11bmRlZmluZWQpJiZzcGVlZD5NYXRoLm1heCgzNSx1bml0LnNwZWVkKjEuMTUpO1xuICAgICAgY29uc3QgY2hhcmdpbmc9dW5pdC5vcmRlci50eXBlPT09J2NoYXJnZScmJnNwZWVkPk1hdGgubWF4KDIwLHVuaXQuc3BlZWQqLjcpO1xuICAgICAgaWYoKCFjaGFyZ2luZyYmIWZvcmNlZCl8fGRpc3RhbmNlPC4xfHxzcGVlZD4xMjAwKWNvbnRpbnVlOyAvLyBpZ25vcmUgdGVsZXBvcnRzXG4gICAgICBjb25zdCBub3JtWD1keC9kaXN0YW5jZSxub3JtWT1keS9kaXN0YW5jZTtcbiAgICAgIGNvbnN0IHN0cmVuZ3RoPU1hdGgubWluKDEsc3BlZWQvMzAwKTtcbiAgICAgIGZvcihsZXQgaT0wO2k8MyYmdGhpcy5saW5lcy5sZW5ndGg8Q09NQkFUX1BSRVNFTlRBVElPTl9MSU1JVFMuc3BlZWRMaW5lcztpKyspIHtcbiAgICAgICAgY29uc3Qgc2lkZT0oaS0xKSp1bml0LnJhZGl1cyouNjU7XG4gICAgICAgIHRoaXMubGluZXMucHVzaCh7dW5pdElkOnVuaXQuaWQseDp1bml0Lngtbm9ybVkqc2lkZSx5OnVuaXQueStub3JtWCpzaWRlLGR4Om5vcm1YLGR5Om5vcm1ZLGxlbmd0aDpNYXRoLm1pbig3NSwxMitzcGVlZCouMTMpKihpPT09MT8xOi43Myksd2lkdGg6LjY1K3N0cmVuZ3RoKi42LGhlaWdodDp1bml0LnJhZGl1cyooLjM1K2kqLjM4KSxhbHBoYTouMTgrc3RyZW5ndGgqLjM1fSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMucG9zaXRpb25zPW5leHQ7XG4gIH1cblxuICBwcml2YXRlIHN1cmZhY2VGb3IodW5pdDpVbml0LG5vdzpudW1iZXIpe1xuICAgIGlmKCF0aGlzLnN1cmZhY2VzKXJldHVybiB1bmRlZmluZWQ7XG4gICAgaWYodGhpcy5zdXJmYWNlTm93IT09bm93KXt0aGlzLnN1cmZhY2VGcmFtZS5jbGVhcigpO3RoaXMuc3VyZmFjZU5vdz1ub3c7fVxuICAgIGxldCBzdXJmYWNlPXRoaXMuc3VyZmFjZUZyYW1lLmdldCh1bml0LmlkKTtcbiAgICBpZighc3VyZmFjZSl7c3VyZmFjZT10aGlzLnN1cmZhY2VzKHVuaXQsbm93KTt0aGlzLnN1cmZhY2VGcmFtZS5zZXQodW5pdC5pZCxzdXJmYWNlKTt9XG4gICAgcmV0dXJuIHN1cmZhY2U7XG4gIH1cblxuICBwcml2YXRlIHRyYW5zZmVyQmxvb2QodGljazpudW1iZXIsbm93Om51bWJlcixyZWNlaXZlcnM/OkJsb29kUmVjZWl2ZXJRdWVyeSl7XG4gICAgdGhpcy50cmFuc2ZlcnJlZD10aGlzLnRyYW5zZmVycmVkLmZpbHRlcihzdGFpbj0+e1xuICAgICAgY29uc3QgdW5pdD10aGlzLnVuaXRzLmdldChzdGFpbi5tYXJrLnVuaXRJZCk7XG4gICAgICBpZighdW5pdHx8dW5pdC5ocDw9MHx8dGljay1zdGFpbi50aWNrPj1CT0RZX0xJRkUqU0lNX1RJQ0tTX1BFUl9TRUNPTkQpcmV0dXJuIGZhbHNlO1xuICAgICAgLy8gQSB0aHJvd24vZHJvcHBlZC9yZXBsYWNlZCB3ZWFwb24gZG9lcyBub3QgbGVuZCBpdHMgb2xkIHN0YWluIHRvIHRoZVxuICAgICAgLy8gbmV4dCBwaWVjZSBvZiBlcXVpcG1lbnQuIENoZWNrIG9uIHNuYXBzaG90cywgbm90IG9uIHJlbmRlcmVkIGZyYW1lcy5cbiAgICAgIHJldHVybiAhc3RhaW4ud2VhcG9ufHwhdGhpcy5zdXJmYWNlc3x8dGhpcy5zdXJmYWNlRm9yKHVuaXQsbm93KT8ud2VhcG9uPy5rZXk9PT1zdGFpbi53ZWFwb24ua2V5O1xuICAgIH0pO1xuICAgIGNvbnN0IGFjdGl2ZT10aGlzLmJ1cnN0cy5maWx0ZXIoYnVyc3Q9PmJ1cnN0LmRyb3BzLnNvbWUoZHJvcD0+IWRyb3AuY2F1Z2h0JiZidXJzdC5jaGVja2VkQWdlPGRyb3AubGFuZFRpbWUpKTtcbiAgICBpZighYWN0aXZlLmxlbmd0aClyZXR1cm47XG4gICAgY29uc3QgcmVzb2x2ZT10aGlzLnN1cmZhY2VzPyh1bml0OlVuaXQsdGltZTpudW1iZXIpPT50aGlzLnN1cmZhY2VGb3IodW5pdCx0aW1lKSE6dW5kZWZpbmVkO1xuICAgIGxldCBjYW5kaWRhdGVzOkl0ZXJhYmxlPFVuaXQ+PXRoaXMudW5pdHMudmFsdWVzKCk7XG4gICAgaWYocmVjZWl2ZXJzKXtcbiAgICAgIGNvbnN0IGJvdW5kczpCbG9vZFJlY2VpdmVyQm91bmRzW109W107XG4gICAgICBmb3IoY29uc3QgYnVyc3Qgb2YgYWN0aXZlKXtcbiAgICAgICAgY29uc3QgYWdlPU1hdGgubWF4KDAsKHRpY2stYnVyc3QudGljaykvU0lNX1RJQ0tTX1BFUl9TRUNPTkQpO1xuICAgICAgICBjb25zdCBodWxsPWJ1cnN0LmRlY2s/dGhpcy51bml0cy5nZXQoYnVyc3QuZGVjay5zaGlwSWQpOnVuZGVmaW5lZCxwcm9maWxlPWh1bGwmJmh1bGwuaHA+MD9zaGlwUHJvZmlsZShodWxsKTp1bmRlZmluZWQ7XG4gICAgICAgIGlmKGJ1cnN0LmRlY2smJiFwcm9maWxlKWNvbnRpbnVlO1xuICAgICAgICBjb25zdCBoZWFkaW5nPWh1bGw/LnNhaWxpbmc/LmhlYWRpbmc/PzAsYz1NYXRoLmNvcyhoZWFkaW5nKSxzPU1hdGguc2luKGhlYWRpbmcpO1xuICAgICAgICBsZXQgbWluWD1JbmZpbml0eSxtaW5ZPUluZmluaXR5LG1heFg9LUluZmluaXR5LG1heFk9LUluZmluaXR5O1xuICAgICAgICBmb3IoY29uc3QgZHJvcCBvZiBidXJzdC5kcm9wcyl7XG4gICAgICAgICAgaWYoZHJvcC5jYXVnaHR8fGJ1cnN0LmNoZWNrZWRBZ2U+ZHJvcC5sYW5kVGltZSljb250aW51ZTtcbiAgICAgICAgICBjb25zdCBlbmQ9TWF0aC5taW4oYWdlLGRyb3AubGFuZFRpbWUpLHN0YXJ0PU1hdGgubWluKGJ1cnN0LmNoZWNrZWRBZ2UsZW5kKTtcbiAgICAgICAgICAvLyBYWSBpcyBsaW5lYXIgdGhyb3VnaG91dCB0aGUgZmxpZ2h0LiBUaGUgdHdvIGVuZHBvaW50cyBjb3ZlciBhbGxcbiAgICAgICAgICAvLyBzaW11bGF0aW9uLXNpemVkIGNvbnRhY3Qgc2VnbWVudHMsIGluY2x1ZGluZyBza2lwcGVkIHRpY2tzLiBVc2VcbiAgICAgICAgICAvLyB0aGUgc2FtZSBjdXJyZW50IGh1bGwgdHJhbnNmb3JtIGFzIHRoZSBjb250YWN0IHBvaW50cyBiZWxvdy5cbiAgICAgICAgICBmb3IobGV0IGVuZHBvaW50PTA7ZW5kcG9pbnQ8MjtlbmRwb2ludCsrKXtcbiAgICAgICAgICAgIGNvbnN0IHQ9ZW5kcG9pbnQ9PT0wP3N0YXJ0OmVuZDtcbiAgICAgICAgICAgIGNvbnN0IHg9YnVyc3QueCtkcm9wLm94K2Ryb3AudngqdCx5PWJ1cnN0LnkrZHJvcC5veStkcm9wLnZ5KnQ7XG4gICAgICAgICAgICBjb25zdCB3b3JsZFg9aHVsbD9odWxsLngreCpjLXkqczp4LHdvcmxkWT1odWxsP2h1bGwueSt4KnMreSpjOnk7XG4gICAgICAgICAgICBtaW5YPU1hdGgubWluKG1pblgsd29ybGRYKTttaW5ZPU1hdGgubWluKG1pblksd29ybGRZKTttYXhYPU1hdGgubWF4KG1heFgsd29ybGRYKTttYXhZPU1hdGgubWF4KG1heFksd29ybGRZKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgYm91bmRzLnB1c2goYmxvb2RSZWNlaXZlckJvdW5kcyhtaW5YLG1pblksbWF4WCxtYXhZKSk7XG4gICAgICB9XG4gICAgICBpZighYm91bmRzLmxlbmd0aClyZXR1cm47XG4gICAgICBjYW5kaWRhdGVzPXJlY2VpdmVycyhib3VuZHMpO1xuICAgIH1cbiAgICAvLyBPbmUgdW5pb24gZ3JpZCBzaGFyZXMgZWFjaCByZWNlaXZlcidzIGNhcHN1bGVzIGFjcm9zcyBhbGwgZHJvcGxldHMgYW5kXG4gICAgLy8gc2ltdWx0YW5lb3VzIGJ1cnN0cywgYXMgdGhlIG9yaWdpbmFsIHdob2xlLXdvcmxkIGNvbnRhY3QgcGFzcyBkaWQuXG4gICAgY29uc3QgY29udGFjdHM9bmV3IEJsb29kQ29udGFjdHMoY2FuZGlkYXRlcyxyZXNvbHZlLG5vdyk7XG4gICAgZm9yKGNvbnN0IGJ1cnN0IG9mIGFjdGl2ZSl7XG4gICAgICBjb25zdCBhZ2U9TWF0aC5tYXgoMCwodGljay1idXJzdC50aWNrKS9TSU1fVElDS1NfUEVSX1NFQ09ORCk7XG4gICAgICBjb25zdCBodWxsPWJ1cnN0LmRlY2s/dGhpcy51bml0cy5nZXQoYnVyc3QuZGVjay5zaGlwSWQpOnVuZGVmaW5lZCxwcm9maWxlPWh1bGwmJmh1bGwuaHA+MD9zaGlwUHJvZmlsZShodWxsKTp1bmRlZmluZWQ7XG4gICAgICBpZihidXJzdC5kZWNrJiYhcHJvZmlsZSljb250aW51ZTtcbiAgICAgIGNvbnN0IGhlYWRpbmc9aHVsbD8uc2FpbGluZz8uaGVhZGluZz8/MCxjPU1hdGguY29zKGhlYWRpbmcpLHM9TWF0aC5zaW4oaGVhZGluZyk7XG4gICAgICBmb3IoY29uc3QgZHJvcCBvZiBidXJzdC5kcm9wcyl7XG4gICAgICAgIGlmKGRyb3AuY2F1Z2h0fHxidXJzdC5jaGVja2VkQWdlPmRyb3AubGFuZFRpbWUpY29udGludWU7XG4gICAgICAgIGNvbnN0IGVuZD1NYXRoLm1pbihhZ2UsZHJvcC5sYW5kVGltZSksc3RhcnQ9TWF0aC5taW4oYnVyc3QuY2hlY2tlZEFnZSxlbmQpO1xuICAgICAgICBjb25zdCBwb2ludD0odDpudW1iZXIpOkJsb29kUG9pbnQ9PntcbiAgICAgICAgICBjb25zdCB4PWJ1cnN0LngrZHJvcC5veCtkcm9wLnZ4KnQseT1idXJzdC55K2Ryb3Aub3krZHJvcC52eSp0O1xuICAgICAgICAgIHJldHVybnt4Omh1bGw/aHVsbC54K3gqYy15KnM6eCx5Omh1bGw/aHVsbC55K3gqcyt5KmM6eSx6Oihwcm9maWxlPy5kZWNrSGVpZ2h0Pz9idXJzdC5mbG9vcikrTWF0aC5tYXgoMCxkcm9wLmhlaWdodCtkcm9wLnZ6KnQtLjUqR1JBVklUWSp0KnQpfTtcbiAgICAgICAgfTtcbiAgICAgICAgLy8gQXQgbW9zdCB0aGUgc2hvcnQgYmFsbGlzdGljIGZsaWdodCwgc2FtcGxlZCBpbiBzaW11bGF0aW9uLXNpemVkXG4gICAgICAgIC8vIGludGVydmFscyBldmVuIHdoZW4gcmVuZGVyaW5nIHNraXBwZWQgdGlja3MuIE5ldmVyIGRlcGVuZHMgb24gUkFGLlxuICAgICAgICBjb25zdCBzdGVwcz1NYXRoLm1heCgxLE1hdGguY2VpbCgoZW5kLXN0YXJ0KSpTSU1fVElDS1NfUEVSX1NFQ09ORCkpO1xuICAgICAgICBmb3IobGV0IGk9MDtpPHN0ZXBzO2krKyl7XG4gICAgICAgICAgY29uc3QgdDA9c3RhcnQrKGVuZC1zdGFydCkqaS9zdGVwcyx0MT1zdGFydCsoZW5kLXN0YXJ0KSooaSsxKS9zdGVwcztcbiAgICAgICAgICBjb25zdCBjb250YWN0PWNvbnRhY3RzLmNvbnRhY3QocG9pbnQodDApLHBvaW50KHQxKSxkcm9wLnJhZGl1cyxidXJzdC51bml0SWQsYnVyc3QuY29udGFjdHMpO2lmKCFjb250YWN0KWNvbnRpbnVlO1xuICAgICAgICAgIGNvbnN0IG1hcms6Qm9keUJsb29kPXt1bml0SWQ6Y29udGFjdC51bml0LmlkLHg6Y29udGFjdC51bml0LngseTpjb250YWN0LnVuaXQueSxoZWlnaHQ6Y29udGFjdC5wb2ludC56LFxuICAgICAgICAgICAgbG9jYWxYOihjb250YWN0LnBvaW50LngtY29udGFjdC51bml0LngpKmNvbnRhY3Quc3VyZmFjZS5mYWNpbmcsbG9jYWxZOi0oY29udGFjdC5wb2ludC56LWNvbnRhY3Quc3VyZmFjZS5mbG9vcikqVElMVCxcbiAgICAgICAgICAgIHJhZGl1czpNYXRoLm1pbigzLjgsZHJvcC5yYWRpdXMqMS4yKSxhbmdsZTpkcm9wLmFuZ2xlLGFscGhhOi44LC4uLihjb250YWN0LndlYXBvbj97c3VyZmFjZTond2VhcG9uJyBhcyBjb25zdCx3aWR0aDpjb250YWN0LndlYXBvbi53aWR0aCouOH06e30pfTtcbiAgICAgICAgICB0aGlzLnRyYW5zZmVycmVkLnB1c2goe3RpY2s6YnVyc3QudGljaysodDArKHQxLXQwKSpjb250YWN0LmRpc3RhbmNlKSpTSU1fVElDS1NfUEVSX1NFQ09ORCxtYXJrLC4uLihjb250YWN0LndlYXBvbj97d2VhcG9uOmNvbnRhY3Qud2VhcG9ufTp7fSl9KTtcbiAgICAgICAgICBpZih0aGlzLnRyYW5zZmVycmVkLmxlbmd0aD5DT01CQVRfUFJFU0VOVEFUSU9OX0xJTUlUUy50cmFuc2ZlcnJlZE1hcmtzKXRoaXMudHJhbnNmZXJyZWQuc2hpZnQoKTtcbiAgICAgICAgICBidXJzdC5jb250YWN0cy5hZGQoYCR7Y29udGFjdC51bml0LmlkfToke2NvbnRhY3Qud2VhcG9uPyd3ZWFwb24nOidib2R5J31gKTtcbiAgICAgICAgICBkcm9wLmNhdWdodD10cnVlO2JyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBidXJzdC5jaGVja2VkQWdlPWFnZTtcbiAgICB9XG4gIH1cblxuICAvKiogUmV0dXJuZWQgcmVjb3JkcyBhcmUgcmV1c2VkIHVudGlsIHRoZSBuZXh0IGNhbGw7IHJlbmRlciBpbW1lZGlhdGVseSBvclxuICAgKiBjb3B5IGZvciByZXRhaW5lZCBjYXB0dXJlcy4gTmV2ZXIgZHJpdmVzIHRoZSBzaW11bGF0aW9uIG9yIGFuIFJORy4gKi9cbiAgZnJhbWUobm93Om51bWJlcik6Q29tYmF0UHJlc2VudGF0aW9uRnJhbWUge1xuICAgIGNvbnN0IG91dD10aGlzLm91dHB1dDtcbiAgICBpZih0aGlzLmZyYW1lTm93PT09bm93KXJldHVybiBvdXQ7XG4gICAgdGhpcy5mcmFtZU5vdz1ub3c7XG4gICAgb3V0LmRyb3BsZXRzLmxlbmd0aD0wO291dC5ncm91bmQubGVuZ3RoPTA7b3V0LmJvZHkubGVuZ3RoPTA7b3V0LnNwZWVkTGluZXMubGVuZ3RoPTA7XG4gICAgaWYodGhpcy50aWNrPT09dW5kZWZpbmVkKXJldHVybiBvdXQ7XG4gICAgY29uc3QgZnJhY3Rpb249TWF0aC5tYXgoMCxNYXRoLm1pbigxLChub3ctdGhpcy5yZWNlaXZlZEF0KS9USUNLX01TKSk7XG4gICAgY29uc3QgY2xvY2s9dGhpcy50aWNrK2ZyYWN0aW9uO1xuICAgIGZvcihsZXQgaW5kZXg9MDtpbmRleDx0aGlzLnJlc2lkdWUubGVuZ3RoK3RoaXMuYnVyc3RzLmxlbmd0aDtpbmRleCsrKSB7XG4gICAgICBjb25zdCBhY3RpdmU9aW5kZXg+PXRoaXMucmVzaWR1ZS5sZW5ndGg7XG4gICAgICBjb25zdCBidXJzdD1hY3RpdmU/dGhpcy5idXJzdHNbaW5kZXgtdGhpcy5yZXNpZHVlLmxlbmd0aF0hOnRoaXMucmVzaWR1ZVtpbmRleF0hO1xuICAgICAgY29uc3QgYWdlPU1hdGgubWF4KDAsKGNsb2NrLWJ1cnN0LnRpY2spL1NJTV9USUNLU19QRVJfU0VDT05EKTtcbiAgICAgIGlmKGFnZT49TElGRSljb250aW51ZTtcbiAgICAgIC8vIFRoZSB3b3VuZCBiZWxvbmdzIHRvIHRoZSBzdXJ2aXZpbmcgYWN0b3IsIGluZGVwZW5kZW50bHkgb2YgdGhlXG4gICAgICAvLyBzdXJmYWNlIG9uIHdoaWNoIHRoZSBoaXQgaGFwcGVuZWQgKHRoZXkgbWF5IHNpbmNlIGhhdmUgZGlzZW1iYXJrZWQpLlxuICAgICAgY29uc3QgdW5pdD10aGlzLnVuaXRzLmdldChidXJzdC51bml0SWQpO1xuICAgICAgaWYoYWN0aXZlJiZ1bml0JiZ1bml0LmhwPjAmJmFnZTxCT0RZX0xJRkUpIHtcbiAgICAgICAgY29uc3QgcD1idXJzdC5tYXJrO3AueD11bml0Lng7cC55PXVuaXQueTtwLmFscGhhPS42NSpmYWRlKGFnZSwzLEJPRFlfTElGRSk7b3V0LmJvZHkucHVzaChwKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGh1bGw9YnVyc3QuZGVjaz90aGlzLnVuaXRzLmdldChidXJzdC5kZWNrLnNoaXBJZCk6dW5kZWZpbmVkO1xuICAgICAgY29uc3QgcHJvZmlsZT1odWxsJiZodWxsLmhwPjA/c2hpcFByb2ZpbGUoaHVsbCk6dW5kZWZpbmVkO1xuICAgICAgaWYoYnVyc3QuZGVjayYmIXByb2ZpbGUpY29udGludWU7XG4gICAgICBjb25zdCBoZWFkaW5nPWh1bGw/LnNhaWxpbmc/LmhlYWRpbmc/PzAsYz1NYXRoLmNvcyhoZWFkaW5nKSxzPU1hdGguc2luKGhlYWRpbmcpO1xuICAgICAgZm9yKGNvbnN0IGRyb3Agb2YgYnVyc3QuZHJvcHMpIHtcbiAgICAgICAgaWYoZHJvcC5jYXVnaHQpY29udGludWU7XG4gICAgICAgIGNvbnN0IHQ9TWF0aC5taW4oYWdlLGRyb3AubGFuZFRpbWUpO1xuICAgICAgICBjb25zdCBsb2NhbFg9YnVyc3QueCtkcm9wLm94K2Ryb3AudngqdCxsb2NhbFk9YnVyc3QueStkcm9wLm95K2Ryb3AudnkqdDtcbiAgICAgICAgdGhpcy5zY3JhdGNoLng9bG9jYWxYO3RoaXMuc2NyYXRjaC55PWxvY2FsWTtcbiAgICAgICAgaWYocHJvZmlsZSYmIWNpcmNsZUluUG9seWdvbih0aGlzLnNjcmF0Y2gsZHJvcC5yYWRpdXMscHJvZmlsZS5kZWNrKSljb250aW51ZTtcbiAgICAgICAgY29uc3QgeD1odWxsP2h1bGwueCtsb2NhbFgqYy1sb2NhbFkqczpsb2NhbFg7XG4gICAgICAgIGNvbnN0IHk9aHVsbD9odWxsLnkrbG9jYWxYKnMrbG9jYWxZKmM6bG9jYWxZO1xuICAgICAgICBpZihhZ2U8ZHJvcC5sYW5kVGltZSkge1xuICAgICAgICAgIGlmKCFhY3RpdmUpY29udGludWU7XG4gICAgICAgICAgY29uc3QgcD1kcm9wLmFpcjtcbiAgICAgICAgICBwLng9eDtwLnk9eTtcbiAgICAgICAgICBwLmhlaWdodD0ocHJvZmlsZT8uZGVja0hlaWdodD8/YnVyc3QuZmxvb3IpK01hdGgubWF4KDAsZHJvcC5oZWlnaHQrZHJvcC52eiphZ2UtLjUqR1JBVklUWSphZ2UqYWdlKTtcbiAgICAgICAgICBwLnZ4PWRyb3AudngqYy1kcm9wLnZ5KnM7cC52eT1kcm9wLnZ4KnMrZHJvcC52eSpjO1xuICAgICAgICAgIHAudno9ZHJvcC52ei1HUkFWSVRZKmFnZTtcbiAgICAgICAgICBvdXQuZHJvcGxldHMucHVzaChwKTtcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgY29uc3QgcD1kcm9wLmdyb3VuZDtwLng9eDtwLnk9eTtwLmhlaWdodD1wcm9maWxlPy5kZWNrSGVpZ2h0Pz9idXJzdC5mbG9vcjtwLmFuZ2xlPWRyb3AuYW5nbGUrKGh1bGw/LnNhaWxpbmc/LmhlYWRpbmc/PzApO1xuICAgICAgICAgIHAuYWxwaGE9LjU4KmZhZGUoYWdlLDUsTElGRSk7XG4gICAgICAgICAgb3V0Lmdyb3VuZC5wdXNoKHApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGZvcihjb25zdCBzdGFpbiBvZiB0aGlzLnRyYW5zZmVycmVkKXtcbiAgICAgIGNvbnN0IGFnZT0oY2xvY2stc3RhaW4udGljaykvU0lNX1RJQ0tTX1BFUl9TRUNPTkQsdW5pdD10aGlzLnVuaXRzLmdldChzdGFpbi5tYXJrLnVuaXRJZCk7XG4gICAgICBpZighdW5pdHx8dW5pdC5ocDw9MHx8YWdlPj1CT0RZX0xJRkUpY29udGludWU7XG4gICAgICBjb25zdCBtYXJrPXN0YWluLm1hcms7XG4gICAgICBpZihzdGFpbi53ZWFwb24pe1xuICAgICAgICBjb25zdCB3ZWFwb249dGhpcy5zdXJmYWNlRm9yKHVuaXQsbm93KT8ud2VhcG9uO1xuICAgICAgICBpZighd2VhcG9ufHx3ZWFwb24ua2V5IT09c3RhaW4ud2VhcG9uLmtleSljb250aW51ZTtcbiAgICAgICAgY29uc3Qgc2VnbWVudD13ZWFwb24uc2VnbWVudHNbc3RhaW4ud2VhcG9uLnNlZ21lbnRdO2lmKCFzZWdtZW50KWNvbnRpbnVlO1xuICAgICAgICBtYXJrLmxvY2FsWD1zZWdtZW50LmFbMF0rKHNlZ21lbnQuYlswXS1zZWdtZW50LmFbMF0pKnN0YWluLndlYXBvbi50O1xuICAgICAgICBtYXJrLmxvY2FsWT1zZWdtZW50LmFbMV0rKHNlZ21lbnQuYlsxXS1zZWdtZW50LmFbMV0pKnN0YWluLndlYXBvbi50O1xuICAgICAgICBtYXJrLmFuZ2xlPU1hdGguYXRhbjIoc2VnbWVudC5iWzFdLXNlZ21lbnQuYVsxXSxzZWdtZW50LmJbMF0tc2VnbWVudC5hWzBdKStNYXRoLlBJLzI7XG4gICAgICAgIG1hcmsud2lkdGg9c2VnbWVudC53aWR0aCouODtcbiAgICAgIH1cbiAgICAgIG1hcmsueD11bml0Lng7bWFyay55PXVuaXQueTttYXJrLmFscGhhPS44KmZhZGUoYWdlLDMsQk9EWV9MSUZFKTtvdXQuYm9keS5wdXNoKG1hcmspO1xuICAgIH1cbiAgICBmb3IoY29uc3QgbGluZSBvZiB0aGlzLmxpbmVzKW91dC5zcGVlZExpbmVzLnB1c2gobGluZSk7XG4gICAgcmV0dXJuIG91dDtcbiAgfVxufVxuXG5jb25zdCBmYWRlPShhZ2U6bnVtYmVyLHN0YXJ0Om51bWJlcixlbmQ6bnVtYmVyKT0+TWF0aC5tYXgoMCxNYXRoLm1pbigxLChlbmQtYWdlKS8oZW5kLXN0YXJ0KSkpO1xuZnVuY3Rpb24gbWFrZUJ1cnN0KGVmZmVjdDpXb3JsZEVmZmVjdCx0aWNrOm51bWJlcik6QnVyc3Qge1xuICBjb25zdCByYW5kb209c2VlZGVkKGVmZmVjdC5pZCsnOicrdGljayk7XG4gIGNvbnN0IHJhZGl1cz1NYXRoLm1heCg2LE1hdGgubWluKDYwLGVmZmVjdC50YXJnZXRSYWRpdXM/PzE3KSk7XG4gIGNvbnN0IHNldmVyaXR5PU1hdGgubWluKDEsZWZmZWN0LmRhbWFnZSEvZWZmZWN0LnRhcmdldE1heEhwISk7XG4gIGNvbnN0IGNvdW50PU1hdGgubWluKENPTUJBVF9QUkVTRU5UQVRJT05fTElNSVRTLmRyb3BsZXRzUGVyQnVyc3QsMytNYXRoLmZsb29yKE1hdGguc3FydChzZXZlcml0eSkqNykpO1xuICBjb25zdCBmcm9tPU51bWJlci5pc0Zpbml0ZShlZmZlY3QuZnJvbVgpJiZOdW1iZXIuaXNGaW5pdGUoZWZmZWN0LmZyb21ZKTtcbiAgY29uc3QgZGlyZWN0aW9uPShmcm9tP01hdGguYXRhbjIoZWZmZWN0LnktZWZmZWN0LmZyb21ZISxlZmZlY3QueC1lZmZlY3QuZnJvbVghKTowKS0oZWZmZWN0LnRhcmdldERlY2s/LmhlYWRpbmc/PzApO1xuICBjb25zdCBmbG9vcj1lZmZlY3QudGFyZ2V0RGVjaz9NYXRoLm1heCgwLChlZmZlY3QudG9IZWlnaHQ/PzE4KS0xOCk6MDtcbiAgY29uc3Qgb3JpZ2luWD1lZmZlY3QudGFyZ2V0RGVjaz8ueD8/ZWZmZWN0Lngsb3JpZ2luWT1lZmZlY3QudGFyZ2V0RGVjaz8ueT8/ZWZmZWN0Lnk7XG4gIGNvbnN0IGRyb3BzOkRyb3BbXT1bXTtcbiAgY29uc3QgaGVpZ2h0PXJhZGl1cyooMS43K3JhbmRvbSgpKi40NSk7XG4gIGZvcihsZXQgaT0wO2k8Y291bnQ7aSsrKSB7XG4gICAgY29uc3QgYW5nbGU9ZnJvbT9kaXJlY3Rpb24rKGklND09PTM/TWF0aC5QSTowKSsocmFuZG9tKCktLjUpKjEuNTpyYW5kb20oKSpNYXRoLlBJKjI7XG4gICAgY29uc3Qgc3BlZWQ9KDE4K01hdGguc3FydChzZXZlcml0eSkqNjUpKiguNStyYW5kb20oKSouNjUpO1xuICAgIGNvbnN0IHZ4PU1hdGguY29zKGFuZ2xlKSpzcGVlZCx2eT1NYXRoLnNpbihhbmdsZSkqc3BlZWQ7XG4gICAgY29uc3Qgdno9MTArcmFuZG9tKCkqMzI7XG4gICAgY29uc3QgbGFuZFRpbWU9KHZ6K01hdGguc3FydCh2eip2eisyKkdSQVZJVFkqaGVpZ2h0KSkvR1JBVklUWTtcbiAgICBjb25zdCBzaXplPS42NStNYXRoLnNxcnQoc2V2ZXJpdHkpKigxK3JhbmRvbSgpKjEuNyk7XG4gICAgY29uc3Qgb3g9KHJhbmRvbSgpLS41KSpyYWRpdXMqLjI4LG95PShyYW5kb20oKS0uNSkqcmFkaXVzKi4yODtcbiAgICBkcm9wcy5wdXNoKHtveCxveSx2eCx2eSx2eixoZWlnaHQsbGFuZFRpbWUscmFkaXVzOnNpemUsYW5nbGUsXG4gICAgICBhaXI6e3g6ZWZmZWN0LngseTplZmZlY3QueSxoZWlnaHQ6Zmxvb3IraGVpZ2h0LHZ4LHZ5LHZ6LHJhZGl1czpzaXplLGFscGhhOi44Nn0sXG4gICAgICBncm91bmQ6e3g6b3JpZ2luWCt2eCpsYW5kVGltZSx5Om9yaWdpblkrdnkqbGFuZFRpbWUsaGVpZ2h0OmZsb29yLHJhZGl1czpzaXplKjEuNSxhbmdsZSxhbHBoYTouNTh9LFxuICAgIH0pO1xuICB9XG4gIHJldHVybiB7Y29udGFjdHM6bmV3IFNldCgpLGNoZWNrZWRBZ2U6MCxpZDplZmZlY3QuaWQsdGljayx1bml0SWQ6ZWZmZWN0LnVuaXRJZD8/JycseDpvcmlnaW5YLHk6b3JpZ2luWSwuLi4oZWZmZWN0LnRhcmdldERlY2s/e2RlY2s6ZWZmZWN0LnRhcmdldERlY2t9Ont9KSxmbG9vcixkcm9wcyxcbiAgICBtYXJrOnt1bml0SWQ6ZWZmZWN0LnVuaXRJZD8/JycseDplZmZlY3QueCx5OmVmZmVjdC55LGhlaWdodCxsb2NhbFg6KHJhbmRvbSgpLS41KSpyYWRpdXMqLjUsbG9jYWxZOi1oZWlnaHQqTWF0aC50YW4oU0hJUF9DQU1FUkEudGlsdCkscmFkaXVzOjEuNCtzZXZlcml0eSoyLjYsYW5nbGU6cmFuZG9tKCkqTWF0aC5QSSxhbHBoYTouNjV9fTtcbn1cbmZ1bmN0aW9uIHNlZWRlZCh0ZXh0OnN0cmluZyk6KCk9Pm51bWJlciB7XG4gIGxldCBzdGF0ZT0yMTY2MTM2MjYxO1xuICBmb3IobGV0IGk9MDtpPHRleHQubGVuZ3RoO2krKylzdGF0ZT1NYXRoLmltdWwoc3RhdGVedGV4dC5jaGFyQ29kZUF0KGkpLDE2Nzc3NjE5KTtcbiAgcmV0dXJuICgpPT57c3RhdGVePXN0YXRlPDwxMztzdGF0ZV49c3RhdGU+Pj4xNztzdGF0ZV49c3RhdGU8PDU7cmV0dXJuKHN0YXRlPj4+MCkvNDI5NDk2NzI5Njt9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFFQSxTQUFRLGVBQWMsMkJBQW1FO0FBQ3pGLFNBQVEsMkJBQTJCLFlBQXFDO0FBQ3hFLFNBQVMsaUJBQWlCLGFBQWEsbUJBQW1CO0FBQzFELFNBQVMsNEJBQTRCO0FBa0JyQyxNQUFNLFVBQVEsTUFBSztBQUNuQixNQUFNLFVBQVE7QUFDZCxNQUFNLE9BQUs7QUFDWCxNQUFNLFlBQVU7QUFDVCxhQUFNLDZCQUEyQixPQUFPLE9BQU8sRUFBRSxRQUFPLElBQUksZUFBYyxJQUFJLGtCQUFpQixJQUFJLFlBQVcsS0FBSyxZQUFXLE1BQU0sa0JBQWlCLElBQUksQ0FBQztBQUsxSixnQkFBUyxXQUFXLFFBQTRCO0FBQ3JELFNBQU8sT0FBTyxTQUFPLFNBQVMsT0FBTyxvQkFBa0IsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLGNBQzlFLE9BQU8sZUFBYSxZQUNwQixPQUFPLFNBQVMsT0FBTyxNQUFNLEtBQUssT0FBTyxTQUFRLEtBQ2pELE9BQU8sU0FBUyxPQUFPLGFBQWEsS0FBSyxPQUFPLGlCQUFnQixPQUFPLFNBQVEsS0FDL0UsT0FBTyxTQUFTLE9BQU8sV0FBVyxLQUFLLE9BQU8sY0FBYTtBQUNsRTtBQUVPLGFBQU0sMEJBQTBCO0FBQUEsRUFDN0I7QUFBQSxFQUNBLGFBQVc7QUFBQSxFQUNYO0FBQUEsRUFDQSxjQUFZO0FBQUEsRUFDWjtBQUFBLEVBQ0Esa0JBQWdCO0FBQUEsRUFDaEIsVUFBUSxFQUFDLEdBQUUsR0FBRSxHQUFFLEVBQUM7QUFBQSxFQUNoQixTQUFlLENBQUM7QUFBQSxFQUNoQixVQUFnQixDQUFDO0FBQUEsRUFDakIsT0FBSyxvQkFBSSxJQUFtQjtBQUFBLEVBQzVCLFlBQVUsb0JBQUksSUFBcUI7QUFBQSxFQUNuQyxRQUFNLG9CQUFJLElBQWlCO0FBQUEsRUFDM0IsUUFBd0IsQ0FBQztBQUFBLEVBQ3pCLGNBQStCLENBQUM7QUFBQSxFQUNoQztBQUFBLEVBQ0E7QUFBQSxFQUNBLGVBQWEsb0JBQUksSUFBNkM7QUFBQSxFQUM5RCxTQUErQixFQUFDLFVBQVMsQ0FBQyxHQUFFLFFBQU8sQ0FBQyxHQUFFLE1BQUssQ0FBQyxHQUFFLFlBQVcsQ0FBQyxFQUFDO0FBQUEsRUFFbkYsUUFBUTtBQUNOLFNBQUssT0FBSztBQUFVLFNBQUssVUFBUTtBQUFVLFNBQUssY0FBWTtBQUFHLFNBQUssYUFBVztBQUFFLFNBQUssV0FBUztBQUFVLFNBQUssa0JBQWdCO0FBQUcsU0FBSyxPQUFPLFNBQU87QUFBRSxTQUFLLFFBQVEsU0FBTztBQUFFLFNBQUssS0FBSyxNQUFNO0FBQUUsU0FBSyxVQUFVLE1BQU07QUFBRSxTQUFLLE1BQU0sTUFBTTtBQUFFLFNBQUssTUFBTSxTQUFPO0FBQUUsU0FBSyxZQUFZLFNBQU87QUFBRSxTQUFLLFdBQVM7QUFBVSxTQUFLLGFBQWEsTUFBTTtBQUFFLFNBQUssYUFBVztBQUN4VixTQUFLLE9BQU8sU0FBUyxTQUFPO0FBQUUsU0FBSyxPQUFPLE9BQU8sU0FBTztBQUFFLFNBQUssT0FBTyxLQUFLLFNBQU87QUFBRSxTQUFLLE9BQU8sV0FBVyxTQUFPO0FBQUEsRUFDcEg7QUFBQSxFQUVBLE9BQU8sVUFBa0IsS0FBVyxVQUErQixXQUErQjtBQUNoRyxRQUFHLEtBQUssU0FBTyxVQUFhLFNBQVMsT0FBSyxLQUFLLEtBQUssTUFBSyxNQUFNO0FBQy9ELFNBQUssV0FBUztBQUNkLFVBQU0sV0FBUyxTQUFTLFNBQU8sS0FBSztBQUNwQyxRQUFHLFlBQVUsU0FBUyxZQUFVLEtBQUssV0FBUyxTQUFTLFFBQVEsV0FBUyxLQUFLLFlBQVk7QUFDekYsU0FBSyxVQUFRLFNBQVM7QUFBUSxTQUFLLGNBQVksU0FBUyxRQUFRO0FBQ2hFLFNBQUssV0FBUztBQUFVLFNBQUssYUFBYSxNQUFNO0FBQUUsU0FBSyxhQUFXO0FBQ2xFLFVBQU0sTUFBSSxLQUFLLFNBQU8sU0FBVSxJQUFFLFNBQVMsT0FBSyxLQUFLO0FBQ3JELFNBQUssT0FBSyxTQUFTO0FBQUssUUFBRyxDQUFDLFNBQVMsTUFBSyxhQUFXO0FBQ3JELFNBQUssTUFBTSxNQUFNO0FBQUUsZUFBVSxRQUFRLFNBQVMsTUFBTSxNQUFLLE1BQU0sSUFBSSxLQUFLLElBQUcsSUFBSTtBQUMvRSxTQUFLLFNBQU8sS0FBSyxPQUFPLE9BQU8sWUFBUSxTQUFTLE9BQUssTUFBTSxRQUFNLHVCQUFxQixJQUFJO0FBQzFGLFNBQUssVUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFRLFNBQVMsT0FBSyxNQUFNLFFBQU0sdUJBQXFCLElBQUk7QUFDNUYsZUFBVSxDQUFDLElBQUcsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFHLFNBQVMsT0FBSyxPQUFLLE9BQUsscUJBQXFCLE1BQUssS0FBSyxPQUFPLEVBQUU7QUFDcEcsVUFBTSx1QkFBcUIsS0FBSztBQUNoQyxlQUFVLFVBQVUsU0FBUyxTQUFTO0FBQ3BDLFVBQUcsQ0FBQyxXQUFXLE1BQU0sS0FBRyxLQUFLLEtBQUssSUFBSSxPQUFPLEVBQUUsRUFBRTtBQUNqRCxZQUFNLE9BQUssU0FBUyxPQUFLLEtBQUssSUFBSSxHQUFFLE9BQU8sV0FBUyxPQUFPLFNBQVM7QUFDcEUsVUFBRyxTQUFTLE9BQUssUUFBTSxPQUFLLHdCQUFzQixRQUFNLHFCQUFxQjtBQUM3RSxXQUFLLEtBQUssSUFBSSxPQUFPLElBQUcsSUFBSTtBQUM1QixXQUFLLE9BQU8sS0FBSyxVQUFVLFFBQU8sSUFBSSxDQUFDO0FBQ3ZDLFVBQUcsS0FBSyxPQUFPLFNBQU8sMkJBQTJCLFFBQVE7QUFDdkQsYUFBSyxRQUFRLEtBQUssS0FBSyxPQUFPLE1BQU0sQ0FBRTtBQUN0QyxZQUFHLEtBQUssUUFBUSxTQUFPLDJCQUEyQixjQUFjLE1BQUssUUFBUSxNQUFNO0FBQUEsTUFDckY7QUFDQSxVQUFHLEtBQUssS0FBSyxPQUFLLDJCQUEyQixZQUFZO0FBQUUsYUFBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBTTtBQUFFLGFBQUssa0JBQWdCLFNBQVM7QUFBQSxNQUFNO0FBQUEsSUFDbEo7QUFDQSxTQUFLLGNBQWMsU0FBUyxNQUFLLEtBQUksU0FBUztBQUc5QyxRQUFHLFNBQVM7QUFDWixTQUFLLE1BQU0sU0FBTztBQUNsQixVQUFNLE9BQUssb0JBQUksSUFBcUI7QUFDcEMsZUFBVSxRQUFRLFNBQVMsT0FBTztBQUNoQyxZQUFNLFdBQVMsS0FBSyxVQUFVLElBQUksS0FBSyxFQUFFO0FBQ3pDLFdBQUssSUFBSSxLQUFLLElBQUcsRUFBQyxHQUFFLEtBQUssR0FBRSxHQUFFLEtBQUssR0FBRSxHQUFJLEtBQUssT0FBSyxFQUFDLE1BQUssRUFBQyxHQUFHLEtBQUssS0FBSSxFQUFDLElBQUUsQ0FBQyxFQUFFLENBQUM7QUFDNUUsVUFBRyxDQUFDLFlBQVUsT0FBSyxLQUFHLE1BQUksS0FBRyxLQUFLLE1BQUksS0FBRyxLQUFLLFFBQVEsS0FBSyxPQUFHLEVBQUUsU0FBTyxNQUFNLEVBQUU7QUFFL0UsWUFBTSxTQUFPLEtBQUssUUFBTSxTQUFTO0FBQ2pDLFVBQUcsVUFBUSxLQUFLLE1BQU0sV0FBUyxTQUFTLE1BQU0sT0FBTztBQUNyRCxVQUFJLEtBQUcsU0FBTyxLQUFLLEtBQU0sSUFBRSxTQUFTLEtBQU0sSUFBRSxLQUFLLElBQUUsU0FBUztBQUM1RCxVQUFJLEtBQUcsU0FBTyxLQUFLLEtBQU0sSUFBRSxTQUFTLEtBQU0sSUFBRSxLQUFLLElBQUUsU0FBUztBQUM1RCxVQUFHLEtBQUssTUFBTTtBQUNaLGNBQU0sVUFBUSxLQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTSxHQUFHLFNBQVMsV0FBUyxHQUFFLElBQUUsS0FBSyxJQUFJLE9BQU8sR0FBRSxJQUFFLEtBQUssSUFBSSxPQUFPO0FBQzFHLGNBQU0sVUFBUTtBQUFHLGFBQUcsS0FBRyxJQUFFLEtBQUc7QUFBRSxhQUFHLFVBQVEsSUFBRSxLQUFHO0FBQUEsTUFDaEQ7QUFDQSxZQUFNLFdBQVMsS0FBSyxNQUFNLElBQUcsRUFBRSxHQUFHLFFBQU0sV0FBUyx1QkFBcUI7QUFDdEUsWUFBTSxVQUFRLEtBQUssVUFBUSxVQUFXLEtBQUssVUFBUSxXQUFZLFFBQU0sS0FBSyxJQUFJLElBQUcsS0FBSyxRQUFNLElBQUk7QUFDaEcsWUFBTSxXQUFTLEtBQUssTUFBTSxTQUFPLFlBQVUsUUFBTSxLQUFLLElBQUksSUFBRyxLQUFLLFFBQU0sR0FBRTtBQUMxRSxVQUFJLENBQUMsWUFBVSxDQUFDLFVBQVMsV0FBUyxPQUFJLFFBQU0sS0FBSztBQUNqRCxZQUFNLFFBQU0sS0FBRyxVQUFTLFFBQU0sS0FBRztBQUNqQyxZQUFNLFdBQVMsS0FBSyxJQUFJLEdBQUUsUUFBTSxHQUFHO0FBQ25DLGVBQVEsSUFBRSxHQUFFLElBQUUsS0FBRyxLQUFLLE1BQU0sU0FBTywyQkFBMkIsWUFBVyxLQUFLO0FBQzVFLGNBQU0sUUFBTSxJQUFFLEtBQUcsS0FBSyxTQUFPO0FBQzdCLGFBQUssTUFBTSxLQUFLLEVBQUMsUUFBTyxLQUFLLElBQUcsR0FBRSxLQUFLLElBQUUsUUFBTSxNQUFLLEdBQUUsS0FBSyxJQUFFLFFBQU0sTUFBSyxJQUFHLE9BQU0sSUFBRyxPQUFNLFFBQU8sS0FBSyxJQUFJLElBQUcsS0FBRyxRQUFNLElBQUcsS0FBRyxNQUFJLElBQUUsSUFBRSxPQUFLLE9BQU0sT0FBSSxXQUFTLEtBQUcsUUFBTyxLQUFLLFVBQVEsT0FBSSxJQUFFLE9BQUssT0FBTSxPQUFJLFdBQVMsS0FBRyxDQUFDO0FBQUEsTUFDdk47QUFBQSxJQUNGO0FBQ0EsU0FBSyxZQUFVO0FBQUEsRUFDakI7QUFBQSxFQUVRLFdBQVcsTUFBVSxLQUFXO0FBQ3RDLFFBQUcsQ0FBQyxLQUFLLFNBQVMsUUFBTztBQUN6QixRQUFHLEtBQUssZUFBYSxLQUFJO0FBQUMsV0FBSyxhQUFhLE1BQU07QUFBRSxXQUFLLGFBQVc7QUFBQSxJQUFJO0FBQ3hFLFFBQUksVUFBUSxLQUFLLGFBQWEsSUFBSSxLQUFLLEVBQUU7QUFDekMsUUFBRyxDQUFDLFNBQVE7QUFBQyxnQkFBUSxLQUFLLFNBQVMsTUFBSyxHQUFHO0FBQUUsV0FBSyxhQUFhLElBQUksS0FBSyxJQUFHLE9BQU87QUFBQSxJQUFFO0FBQ3BGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxjQUFjLE1BQVksS0FBVyxXQUE4QjtBQUN6RSxTQUFLLGNBQVksS0FBSyxZQUFZLE9BQU8sV0FBTztBQUM5QyxZQUFNLE9BQUssS0FBSyxNQUFNLElBQUksTUFBTSxLQUFLLE1BQU07QUFDM0MsVUFBRyxDQUFDLFFBQU0sS0FBSyxNQUFJLEtBQUcsT0FBSyxNQUFNLFFBQU0sWUFBVSxxQkFBcUIsUUFBTztBQUc3RSxhQUFPLENBQUMsTUFBTSxVQUFRLENBQUMsS0FBSyxZQUFVLEtBQUssV0FBVyxNQUFLLEdBQUcsR0FBRyxRQUFRLFFBQU0sTUFBTSxPQUFPO0FBQUEsSUFDOUYsQ0FBQztBQUNELFVBQU0sU0FBTyxLQUFLLE9BQU8sT0FBTyxXQUFPLE1BQU0sTUFBTSxLQUFLLFVBQU0sQ0FBQyxLQUFLLFVBQVEsTUFBTSxhQUFXLEtBQUssUUFBUSxDQUFDO0FBQzNHLFFBQUcsQ0FBQyxPQUFPLE9BQU87QUFDbEIsVUFBTSxVQUFRLEtBQUssV0FBUyxDQUFDLE1BQVUsU0FBYyxLQUFLLFdBQVcsTUFBSyxJQUFJLElBQUc7QUFDakYsUUFBSSxhQUEwQixLQUFLLE1BQU0sT0FBTztBQUNoRCxRQUFHLFdBQVU7QUFDWCxZQUFNLFNBQTZCLENBQUM7QUFDcEMsaUJBQVUsU0FBUyxRQUFPO0FBQ3hCLGNBQU0sTUFBSSxLQUFLLElBQUksSUFBRyxPQUFLLE1BQU0sUUFBTSxvQkFBb0I7QUFDM0QsY0FBTSxPQUFLLE1BQU0sT0FBSyxLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFFLFFBQVUsVUFBUSxRQUFNLEtBQUssS0FBRyxJQUFFLFlBQVksSUFBSSxJQUFFO0FBQzVHLFlBQUcsTUFBTSxRQUFNLENBQUMsUUFBUTtBQUN4QixjQUFNLFVBQVEsTUFBTSxTQUFTLFdBQVMsR0FBRSxJQUFFLEtBQUssSUFBSSxPQUFPLEdBQUUsSUFBRSxLQUFLLElBQUksT0FBTztBQUM5RSxZQUFJLE9BQUssVUFBUyxPQUFLLFVBQVMsT0FBSyxXQUFVLE9BQUs7QUFDcEQsbUJBQVUsUUFBUSxNQUFNLE9BQU07QUFDNUIsY0FBRyxLQUFLLFVBQVEsTUFBTSxhQUFXLEtBQUssU0FBUztBQUMvQyxnQkFBTSxNQUFJLEtBQUssSUFBSSxLQUFJLEtBQUssUUFBUSxHQUFFLFFBQU0sS0FBSyxJQUFJLE1BQU0sWUFBVyxHQUFHO0FBSXpFLG1CQUFRLFdBQVMsR0FBRSxXQUFTLEdBQUUsWUFBVztBQUN2QyxrQkFBTSxJQUFFLGFBQVcsSUFBRSxRQUFNO0FBQzNCLGtCQUFNLElBQUUsTUFBTSxJQUFFLEtBQUssS0FBRyxLQUFLLEtBQUcsR0FBRSxJQUFFLE1BQU0sSUFBRSxLQUFLLEtBQUcsS0FBSyxLQUFHO0FBQzVELGtCQUFNLFNBQU8sT0FBSyxLQUFLLElBQUUsSUFBRSxJQUFFLElBQUUsSUFBRSxHQUFFLFNBQU8sT0FBSyxLQUFLLElBQUUsSUFBRSxJQUFFLElBQUUsSUFBRTtBQUM5RCxtQkFBSyxLQUFLLElBQUksTUFBSyxNQUFNO0FBQUUsbUJBQUssS0FBSyxJQUFJLE1BQUssTUFBTTtBQUFFLG1CQUFLLEtBQUssSUFBSSxNQUFLLE1BQU07QUFBRSxtQkFBSyxLQUFLLElBQUksTUFBSyxNQUFNO0FBQUEsVUFDNUc7QUFBQSxRQUNGO0FBQ0EsZUFBTyxLQUFLLG9CQUFvQixNQUFLLE1BQUssTUFBSyxJQUFJLENBQUM7QUFBQSxNQUN0RDtBQUNBLFVBQUcsQ0FBQyxPQUFPLE9BQU87QUFDbEIsbUJBQVcsVUFBVSxNQUFNO0FBQUEsSUFDN0I7QUFHQSxVQUFNLFdBQVMsSUFBSSxjQUFjLFlBQVcsU0FBUSxHQUFHO0FBQ3ZELGVBQVUsU0FBUyxRQUFPO0FBQ3hCLFlBQU0sTUFBSSxLQUFLLElBQUksSUFBRyxPQUFLLE1BQU0sUUFBTSxvQkFBb0I7QUFDM0QsWUFBTSxPQUFLLE1BQU0sT0FBSyxLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFFLFFBQVUsVUFBUSxRQUFNLEtBQUssS0FBRyxJQUFFLFlBQVksSUFBSSxJQUFFO0FBQzVHLFVBQUcsTUFBTSxRQUFNLENBQUMsUUFBUTtBQUN4QixZQUFNLFVBQVEsTUFBTSxTQUFTLFdBQVMsR0FBRSxJQUFFLEtBQUssSUFBSSxPQUFPLEdBQUUsSUFBRSxLQUFLLElBQUksT0FBTztBQUM5RSxpQkFBVSxRQUFRLE1BQU0sT0FBTTtBQUM1QixZQUFHLEtBQUssVUFBUSxNQUFNLGFBQVcsS0FBSyxTQUFTO0FBQy9DLGNBQU0sTUFBSSxLQUFLLElBQUksS0FBSSxLQUFLLFFBQVEsR0FBRSxRQUFNLEtBQUssSUFBSSxNQUFNLFlBQVcsR0FBRztBQUN6RSxjQUFNLFFBQU0sQ0FBQyxNQUFzQjtBQUNqQyxnQkFBTSxJQUFFLE1BQU0sSUFBRSxLQUFLLEtBQUcsS0FBSyxLQUFHLEdBQUUsSUFBRSxNQUFNLElBQUUsS0FBSyxLQUFHLEtBQUssS0FBRztBQUM1RCxpQkFBTSxFQUFDLEdBQUUsT0FBSyxLQUFLLElBQUUsSUFBRSxJQUFFLElBQUUsSUFBRSxHQUFFLEdBQUUsT0FBSyxLQUFLLElBQUUsSUFBRSxJQUFFLElBQUUsSUFBRSxHQUFFLElBQUcsU0FBUyxjQUFZLE1BQU0sU0FBTyxLQUFLLElBQUksR0FBRSxLQUFLLFNBQU8sS0FBSyxLQUFHLElBQUUsTUFBRyxVQUFRLElBQUUsQ0FBQyxFQUFDO0FBQUEsUUFDOUk7QUFHQSxjQUFNLFFBQU0sS0FBSyxJQUFJLEdBQUUsS0FBSyxNQUFNLE1BQUksU0FBTyxvQkFBb0IsQ0FBQztBQUNsRSxpQkFBUSxJQUFFLEdBQUUsSUFBRSxPQUFNLEtBQUk7QUFDdEIsZ0JBQU0sS0FBRyxTQUFPLE1BQUksU0FBTyxJQUFFLE9BQU0sS0FBRyxTQUFPLE1BQUksVUFBUSxJQUFFLEtBQUc7QUFDOUQsZ0JBQU0sVUFBUSxTQUFTLFFBQVEsTUFBTSxFQUFFLEdBQUUsTUFBTSxFQUFFLEdBQUUsS0FBSyxRQUFPLE1BQU0sUUFBTyxNQUFNLFFBQVE7QUFBRSxjQUFHLENBQUMsUUFBUTtBQUN4RyxnQkFBTSxPQUFlO0FBQUEsWUFBQyxRQUFPLFFBQVEsS0FBSztBQUFBLFlBQUcsR0FBRSxRQUFRLEtBQUs7QUFBQSxZQUFFLEdBQUUsUUFBUSxLQUFLO0FBQUEsWUFBRSxRQUFPLFFBQVEsTUFBTTtBQUFBLFlBQ2xHLFNBQVEsUUFBUSxNQUFNLElBQUUsUUFBUSxLQUFLLEtBQUcsUUFBUSxRQUFRO0FBQUEsWUFBTyxRQUFPLEVBQUUsUUFBUSxNQUFNLElBQUUsUUFBUSxRQUFRLFNBQU87QUFBQSxZQUMvRyxRQUFPLEtBQUssSUFBSSxLQUFJLEtBQUssU0FBTyxHQUFHO0FBQUEsWUFBRSxPQUFNLEtBQUs7QUFBQSxZQUFNLE9BQU07QUFBQSxZQUFHLEdBQUksUUFBUSxTQUFPLEVBQUMsU0FBUSxVQUFrQixPQUFNLFFBQVEsT0FBTyxRQUFNLElBQUUsSUFBRSxDQUFDO0FBQUEsVUFBRTtBQUNqSixlQUFLLFlBQVksS0FBSyxFQUFDLE1BQUssTUFBTSxRQUFNLE1BQUksS0FBRyxNQUFJLFFBQVEsWUFBVSxzQkFBcUIsTUFBSyxHQUFJLFFBQVEsU0FBTyxFQUFDLFFBQU8sUUFBUSxPQUFNLElBQUUsQ0FBQyxFQUFFLENBQUM7QUFDOUksY0FBRyxLQUFLLFlBQVksU0FBTywyQkFBMkIsaUJBQWlCLE1BQUssWUFBWSxNQUFNO0FBQzlGLGdCQUFNLFNBQVMsSUFBSSxHQUFHLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxTQUFPLFdBQVMsTUFBTSxFQUFFO0FBQ3pFLGVBQUssU0FBTztBQUFLO0FBQUEsUUFDbkI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxhQUFXO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBLEVBSUEsTUFBTSxLQUFvQztBQUN4QyxVQUFNLE1BQUksS0FBSztBQUNmLFFBQUcsS0FBSyxhQUFXLElBQUksUUFBTztBQUM5QixTQUFLLFdBQVM7QUFDZCxRQUFJLFNBQVMsU0FBTztBQUFFLFFBQUksT0FBTyxTQUFPO0FBQUUsUUFBSSxLQUFLLFNBQU87QUFBRSxRQUFJLFdBQVcsU0FBTztBQUNsRixRQUFHLEtBQUssU0FBTyxPQUFVLFFBQU87QUFDaEMsVUFBTSxXQUFTLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxJQUFHLE1BQUksS0FBSyxjQUFZLE9BQU8sQ0FBQztBQUNuRSxVQUFNLFFBQU0sS0FBSyxPQUFLO0FBQ3RCLGFBQVEsUUFBTSxHQUFFLFFBQU0sS0FBSyxRQUFRLFNBQU8sS0FBSyxPQUFPLFFBQU8sU0FBUztBQUNwRSxZQUFNLFNBQU8sU0FBTyxLQUFLLFFBQVE7QUFDakMsWUFBTSxRQUFNLFNBQU8sS0FBSyxPQUFPLFFBQU0sS0FBSyxRQUFRLE1BQU0sSUFBRyxLQUFLLFFBQVEsS0FBSztBQUM3RSxZQUFNLE1BQUksS0FBSyxJQUFJLElBQUcsUUFBTSxNQUFNLFFBQU0sb0JBQW9CO0FBQzVELFVBQUcsT0FBSyxLQUFLO0FBR2IsWUFBTSxPQUFLLEtBQUssTUFBTSxJQUFJLE1BQU0sTUFBTTtBQUN0QyxVQUFHLFVBQVEsUUFBTSxLQUFLLEtBQUcsS0FBRyxNQUFJLFdBQVc7QUFDekMsY0FBTSxJQUFFLE1BQU07QUFBSyxVQUFFLElBQUUsS0FBSztBQUFFLFVBQUUsSUFBRSxLQUFLO0FBQUUsVUFBRSxRQUFNLE9BQUksS0FBSyxLQUFJLEdBQUUsU0FBUztBQUFFLFlBQUksS0FBSyxLQUFLLENBQUM7QUFBQSxNQUM1RjtBQUNBLFlBQU0sT0FBSyxNQUFNLE9BQUssS0FBSyxNQUFNLElBQUksTUFBTSxLQUFLLE1BQU0sSUFBRTtBQUN4RCxZQUFNLFVBQVEsUUFBTSxLQUFLLEtBQUcsSUFBRSxZQUFZLElBQUksSUFBRTtBQUNoRCxVQUFHLE1BQU0sUUFBTSxDQUFDLFFBQVE7QUFDeEIsWUFBTSxVQUFRLE1BQU0sU0FBUyxXQUFTLEdBQUUsSUFBRSxLQUFLLElBQUksT0FBTyxHQUFFLElBQUUsS0FBSyxJQUFJLE9BQU87QUFDOUUsaUJBQVUsUUFBUSxNQUFNLE9BQU87QUFDN0IsWUFBRyxLQUFLLE9BQU87QUFDZixjQUFNLElBQUUsS0FBSyxJQUFJLEtBQUksS0FBSyxRQUFRO0FBQ2xDLGNBQU0sU0FBTyxNQUFNLElBQUUsS0FBSyxLQUFHLEtBQUssS0FBRyxHQUFFLFNBQU8sTUFBTSxJQUFFLEtBQUssS0FBRyxLQUFLLEtBQUc7QUFDdEUsYUFBSyxRQUFRLElBQUU7QUFBTyxhQUFLLFFBQVEsSUFBRTtBQUNyQyxZQUFHLFdBQVMsQ0FBQyxnQkFBZ0IsS0FBSyxTQUFRLEtBQUssUUFBTyxRQUFRLElBQUksRUFBRTtBQUNwRSxjQUFNLElBQUUsT0FBSyxLQUFLLElBQUUsU0FBTyxJQUFFLFNBQU8sSUFBRTtBQUN0QyxjQUFNLElBQUUsT0FBSyxLQUFLLElBQUUsU0FBTyxJQUFFLFNBQU8sSUFBRTtBQUN0QyxZQUFHLE1BQUksS0FBSyxVQUFVO0FBQ3BCLGNBQUcsQ0FBQyxPQUFPO0FBQ1gsZ0JBQU0sSUFBRSxLQUFLO0FBQ2IsWUFBRSxJQUFFO0FBQUUsWUFBRSxJQUFFO0FBQ1YsWUFBRSxVQUFRLFNBQVMsY0FBWSxNQUFNLFNBQU8sS0FBSyxJQUFJLEdBQUUsS0FBSyxTQUFPLEtBQUssS0FBRyxNQUFJLE1BQUcsVUFBUSxNQUFJLEdBQUc7QUFDakcsWUFBRSxLQUFHLEtBQUssS0FBRyxJQUFFLEtBQUssS0FBRztBQUFFLFlBQUUsS0FBRyxLQUFLLEtBQUcsSUFBRSxLQUFLLEtBQUc7QUFDaEQsWUFBRSxLQUFHLEtBQUssS0FBRyxVQUFRO0FBQ3JCLGNBQUksU0FBUyxLQUFLLENBQUM7QUFBQSxRQUNyQixPQUFLO0FBQ0gsZ0JBQU0sSUFBRSxLQUFLO0FBQU8sWUFBRSxJQUFFO0FBQUUsWUFBRSxJQUFFO0FBQUUsWUFBRSxTQUFPLFNBQVMsY0FBWSxNQUFNO0FBQU0sWUFBRSxRQUFNLEtBQUssU0FBTyxNQUFNLFNBQVMsV0FBUztBQUN0SCxZQUFFLFFBQU0sT0FBSSxLQUFLLEtBQUksR0FBRSxJQUFJO0FBQzNCLGNBQUksT0FBTyxLQUFLLENBQUM7QUFBQSxRQUNuQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsZUFBVSxTQUFTLEtBQUssYUFBWTtBQUNsQyxZQUFNLE9BQUssUUFBTSxNQUFNLFFBQU0sc0JBQXFCLE9BQUssS0FBSyxNQUFNLElBQUksTUFBTSxLQUFLLE1BQU07QUFDdkYsVUFBRyxDQUFDLFFBQU0sS0FBSyxNQUFJLEtBQUcsT0FBSyxVQUFVO0FBQ3JDLFlBQU0sT0FBSyxNQUFNO0FBQ2pCLFVBQUcsTUFBTSxRQUFPO0FBQ2QsY0FBTSxTQUFPLEtBQUssV0FBVyxNQUFLLEdBQUcsR0FBRztBQUN4QyxZQUFHLENBQUMsVUFBUSxPQUFPLFFBQU0sTUFBTSxPQUFPLElBQUk7QUFDMUMsY0FBTSxVQUFRLE9BQU8sU0FBUyxNQUFNLE9BQU8sT0FBTztBQUFFLFlBQUcsQ0FBQyxRQUFRO0FBQ2hFLGFBQUssU0FBTyxRQUFRLEVBQUUsQ0FBQyxLQUFHLFFBQVEsRUFBRSxDQUFDLElBQUUsUUFBUSxFQUFFLENBQUMsS0FBRyxNQUFNLE9BQU87QUFDbEUsYUFBSyxTQUFPLFFBQVEsRUFBRSxDQUFDLEtBQUcsUUFBUSxFQUFFLENBQUMsSUFBRSxRQUFRLEVBQUUsQ0FBQyxLQUFHLE1BQU0sT0FBTztBQUNsRSxhQUFLLFFBQU0sS0FBSyxNQUFNLFFBQVEsRUFBRSxDQUFDLElBQUUsUUFBUSxFQUFFLENBQUMsR0FBRSxRQUFRLEVBQUUsQ0FBQyxJQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBRSxLQUFLLEtBQUc7QUFDbkYsYUFBSyxRQUFNLFFBQVEsUUFBTTtBQUFBLE1BQzNCO0FBQ0EsV0FBSyxJQUFFLEtBQUs7QUFBRSxXQUFLLElBQUUsS0FBSztBQUFFLFdBQUssUUFBTSxNQUFHLEtBQUssS0FBSSxHQUFFLFNBQVM7QUFBRSxVQUFJLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDcEY7QUFDQSxlQUFVLFFBQVEsS0FBSyxNQUFNLEtBQUksV0FBVyxLQUFLLElBQUk7QUFDckQsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLE1BQU0sT0FBSyxDQUFDLEtBQVcsT0FBYSxRQUFhLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSSxJQUFHLE1BQUksUUFBTSxNQUFJLE1BQU0sQ0FBQztBQUM3RixTQUFTLFVBQVUsUUFBbUIsTUFBbUI7QUFDdkQsUUFBTSxTQUFPLE9BQU8sT0FBTyxLQUFHLE1BQUksSUFBSTtBQUN0QyxRQUFNLFNBQU8sS0FBSyxJQUFJLEdBQUUsS0FBSyxJQUFJLElBQUcsT0FBTyxnQkFBYyxFQUFFLENBQUM7QUFDNUQsUUFBTSxXQUFTLEtBQUssSUFBSSxHQUFFLE9BQU8sU0FBUSxPQUFPLFdBQVk7QUFDNUQsUUFBTSxRQUFNLEtBQUssSUFBSSwyQkFBMkIsa0JBQWlCLElBQUUsS0FBSyxNQUFNLEtBQUssS0FBSyxRQUFRLElBQUUsQ0FBQyxDQUFDO0FBQ3BHLFFBQU0sT0FBSyxPQUFPLFNBQVMsT0FBTyxLQUFLLEtBQUcsT0FBTyxTQUFTLE9BQU8sS0FBSztBQUN0RSxRQUFNLGFBQVcsT0FBSyxLQUFLLE1BQU0sT0FBTyxJQUFFLE9BQU8sT0FBTyxPQUFPLElBQUUsT0FBTyxLQUFNLElBQUUsTUFBSSxPQUFPLFlBQVksV0FBUztBQUNoSCxRQUFNLFFBQU0sT0FBTyxhQUFXLEtBQUssSUFBSSxJQUFHLE9BQU8sWUFBVSxNQUFJLEVBQUUsSUFBRTtBQUNuRSxRQUFNLFVBQVEsT0FBTyxZQUFZLEtBQUcsT0FBTyxHQUFFLFVBQVEsT0FBTyxZQUFZLEtBQUcsT0FBTztBQUNsRixRQUFNLFFBQWEsQ0FBQztBQUNwQixRQUFNLFNBQU8sVUFBUSxNQUFJLE9BQU8sSUFBRTtBQUNsQyxXQUFRLElBQUUsR0FBRSxJQUFFLE9BQU0sS0FBSztBQUN2QixVQUFNLFFBQU0sT0FBSyxhQUFXLElBQUUsTUFBSSxJQUFFLEtBQUssS0FBRyxNQUFJLE9BQU8sSUFBRSxPQUFJLE1BQUksT0FBTyxJQUFFLEtBQUssS0FBRztBQUNsRixVQUFNLFNBQU8sS0FBRyxLQUFLLEtBQUssUUFBUSxJQUFFLE9BQUssTUFBRyxPQUFPLElBQUU7QUFDckQsVUFBTSxLQUFHLEtBQUssSUFBSSxLQUFLLElBQUUsT0FBTSxLQUFHLEtBQUssSUFBSSxLQUFLLElBQUU7QUFDbEQsVUFBTSxLQUFHLEtBQUcsT0FBTyxJQUFFO0FBQ3JCLFVBQU0sWUFBVSxLQUFHLEtBQUssS0FBSyxLQUFHLEtBQUcsSUFBRSxVQUFRLE1BQU0sS0FBRztBQUN0RCxVQUFNLE9BQUssT0FBSSxLQUFLLEtBQUssUUFBUSxLQUFHLElBQUUsT0FBTyxJQUFFO0FBQy9DLFVBQU0sTUFBSSxPQUFPLElBQUUsT0FBSSxTQUFPLE1BQUksTUFBSSxPQUFPLElBQUUsT0FBSSxTQUFPO0FBQzFELFVBQU0sS0FBSztBQUFBLE1BQUM7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQU87QUFBQSxNQUFTLFFBQU87QUFBQSxNQUFLO0FBQUEsTUFDckQsS0FBSSxFQUFDLEdBQUUsT0FBTyxHQUFFLEdBQUUsT0FBTyxHQUFFLFFBQU8sUUFBTSxRQUFPLElBQUcsSUFBRyxJQUFHLFFBQU8sTUFBSyxPQUFNLEtBQUc7QUFBQSxNQUM3RSxRQUFPLEVBQUMsR0FBRSxVQUFRLEtBQUcsVUFBUyxHQUFFLFVBQVEsS0FBRyxVQUFTLFFBQU8sT0FBTSxRQUFPLE9BQUssS0FBSSxPQUFNLE9BQU0sS0FBRztBQUFBLElBQ2xHLENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTztBQUFBLElBQUMsVUFBUyxvQkFBSSxJQUFJO0FBQUEsSUFBRSxZQUFXO0FBQUEsSUFBRSxJQUFHLE9BQU87QUFBQSxJQUFHO0FBQUEsSUFBSyxRQUFPLE9BQU8sVUFBUTtBQUFBLElBQUcsR0FBRTtBQUFBLElBQVEsR0FBRTtBQUFBLElBQVEsR0FBSSxPQUFPLGFBQVcsRUFBQyxNQUFLLE9BQU8sV0FBVSxJQUFFLENBQUM7QUFBQSxJQUFHO0FBQUEsSUFBTTtBQUFBLElBQzlKLE1BQUssRUFBQyxRQUFPLE9BQU8sVUFBUSxJQUFHLEdBQUUsT0FBTyxHQUFFLEdBQUUsT0FBTyxHQUFFLFFBQU8sU0FBUSxPQUFPLElBQUUsT0FBSSxTQUFPLEtBQUcsUUFBTyxDQUFDLFNBQU8sS0FBSyxJQUFJLFlBQVksSUFBSSxHQUFFLFFBQU8sTUFBSSxXQUFTLEtBQUksT0FBTSxPQUFPLElBQUUsS0FBSyxJQUFHLE9BQU0sS0FBRztBQUFBLEVBQUM7QUFDbE07QUFDQSxTQUFTLE9BQU8sTUFBd0I7QUFDdEMsTUFBSSxRQUFNO0FBQ1YsV0FBUSxJQUFFLEdBQUUsSUFBRSxLQUFLLFFBQU8sSUFBSSxTQUFNLEtBQUssS0FBSyxRQUFNLEtBQUssV0FBVyxDQUFDLEdBQUUsUUFBUTtBQUMvRSxTQUFPLE1BQUk7QUFBQyxhQUFPLFNBQU87QUFBRyxhQUFPLFVBQVE7QUFBRyxhQUFPLFNBQU87QUFBRSxZQUFPLFVBQVEsS0FBRztBQUFBLEVBQVc7QUFDOUY7IiwibmFtZXMiOltdfQ==