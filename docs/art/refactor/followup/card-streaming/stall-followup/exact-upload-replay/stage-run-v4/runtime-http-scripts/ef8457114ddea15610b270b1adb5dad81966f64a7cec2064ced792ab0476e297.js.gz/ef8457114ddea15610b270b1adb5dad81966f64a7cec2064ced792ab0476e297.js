import { invalidateItemIndex } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/item-index.ts";
import { diskInConvex } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/navigation-math.ts";
import { localToWorld, shipProfile, worldToLocal } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/ship-geometry.ts";
import { CELL_GROUND } from "/@fs/tmp/sketch-queue-source-42bd/src/shared/terrain.ts";
export function settleGroundItems(items, units, map) {
  if (items.length === 0) return false;
  const ships = units.filter((unit) => unit.hp > 0 && shipProfile(unit));
  let changed = false;
  const kept = items.filter((item) => {
    if (item.carrierId || item.shipId) {
      if (item.deck) {
        delete item.deck;
        changed = true;
      }
      return true;
    }
    const parent = item.deck && ships.find((ship) => ship.id === item.deck.shipId);
    if (parent) {
      Object.assign(item, localToWorld(parent, item.deck));
      return true;
    }
    if (item.deck) {
      delete item.deck;
      changed = true;
    }
    const support = ships.find((ship) => diskInConvex(worldToLocal(ship, item), 2, shipProfile(ship).deck));
    if (support) {
      item.deck = { shipId: support.id, ...worldToLocal(support, item) };
      changed = true;
      return true;
    }
    const terrain = map.terrain;
    if (!terrain) return true;
    const col = Math.floor(item.x / terrain.cell), row = Math.floor(item.y / terrain.cell);
    if (!CELL_GROUND[terrain.cells[row * terrain.cols + col] ?? "."]?.sea) return true;
    changed = true;
    return false;
  });
  if (kept.length !== items.length) items.splice(0, items.length, ...kept);
  if (changed) invalidateItemIndex(items);
  return changed;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIml0ZW0tc3VyZmFjZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaW52YWxpZGF0ZUl0ZW1JbmRleCB9IGZyb20gJy4vaXRlbS1pbmRleCc7XG5pbXBvcnQgeyBkaXNrSW5Db252ZXggfSBmcm9tICcuL25hdmlnYXRpb24tbWF0aCc7XG5pbXBvcnQgeyBsb2NhbFRvV29ybGQsIHNoaXBQcm9maWxlLCB3b3JsZFRvTG9jYWwgfSBmcm9tICcuL3NoaXAtZ2VvbWV0cnknO1xuaW1wb3J0IHsgQ0VMTF9HUk9VTkQgfSBmcm9tICcuL3RlcnJhaW4nO1xuaW1wb3J0IHR5cGUgeyBHYW1lTWFwLCBVbml0LCBXb3JsZEl0ZW0gfSBmcm9tICcuL3R5cGVzJztcblxuLyoqIExvb3NlIGl0ZW1zIG5lZWQgYWN0dWFsIHN1cHBvcnQuIEEgZGVjayBjYXJyaWVzIGl0cyBmbG9vciBvYmplY3RzOyB3YXRlclxuICogZGVzdHJveXMgdGhlbSwgaW5jbHVkaW5nIGVxdWlwbWVudCByZWxlYXNlZCBieSBhIHNpbmtpbmcgaHVsbC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXR0bGVHcm91bmRJdGVtcyhpdGVtczogV29ybGRJdGVtW10sIHVuaXRzOiByZWFkb25seSBVbml0W10sIG1hcDogR2FtZU1hcCkge1xuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHNoaXBzPXVuaXRzLmZpbHRlcih1bml0PT51bml0LmhwPjAgJiYgc2hpcFByb2ZpbGUodW5pdCkpO1xuICBsZXQgY2hhbmdlZD1mYWxzZTtcbiAgY29uc3Qga2VwdD1pdGVtcy5maWx0ZXIoaXRlbT0+e1xuICAgIGlmKGl0ZW0uY2FycmllcklkIHx8IGl0ZW0uc2hpcElkKXtpZihpdGVtLmRlY2spe2RlbGV0ZSBpdGVtLmRlY2s7Y2hhbmdlZD10cnVlO31yZXR1cm4gdHJ1ZTt9XG4gICAgY29uc3QgcGFyZW50PWl0ZW0uZGVjayAmJiBzaGlwcy5maW5kKHNoaXA9PnNoaXAuaWQ9PT1pdGVtLmRlY2shLnNoaXBJZCk7XG4gICAgaWYocGFyZW50KXtPYmplY3QuYXNzaWduKGl0ZW0sbG9jYWxUb1dvcmxkKHBhcmVudCxpdGVtLmRlY2shKSk7cmV0dXJuIHRydWU7fVxuICAgIGlmKGl0ZW0uZGVjayl7ZGVsZXRlIGl0ZW0uZGVjaztjaGFuZ2VkPXRydWU7fVxuICAgIGNvbnN0IHN1cHBvcnQ9c2hpcHMuZmluZChzaGlwPT5kaXNrSW5Db252ZXgod29ybGRUb0xvY2FsKHNoaXAsaXRlbSksMixzaGlwUHJvZmlsZShzaGlwKSEuZGVjaykpO1xuICAgIGlmKHN1cHBvcnQpe2l0ZW0uZGVjaz17c2hpcElkOnN1cHBvcnQuaWQsLi4ud29ybGRUb0xvY2FsKHN1cHBvcnQsaXRlbSl9O2NoYW5nZWQ9dHJ1ZTtyZXR1cm4gdHJ1ZTt9XG4gICAgY29uc3QgdGVycmFpbj1tYXAudGVycmFpbjtcbiAgICBpZighdGVycmFpbilyZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCBjb2w9TWF0aC5mbG9vcihpdGVtLngvdGVycmFpbi5jZWxsKSxyb3c9TWF0aC5mbG9vcihpdGVtLnkvdGVycmFpbi5jZWxsKTtcbiAgICBpZighQ0VMTF9HUk9VTkRbdGVycmFpbi5jZWxsc1tyb3cqdGVycmFpbi5jb2xzK2NvbF0gPz8gJy4nXT8uc2VhKXJldHVybiB0cnVlO1xuICAgIGNoYW5nZWQ9dHJ1ZTtyZXR1cm4gZmFsc2U7XG4gIH0pO1xuICBpZihrZXB0Lmxlbmd0aCE9PWl0ZW1zLmxlbmd0aClpdGVtcy5zcGxpY2UoMCxpdGVtcy5sZW5ndGgsLi4ua2VwdCk7XG4gIGlmKGNoYW5nZWQpaW52YWxpZGF0ZUl0ZW1JbmRleChpdGVtcyk7XG4gIHJldHVybiBjaGFuZ2VkO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGNBQWMsYUFBYSxvQkFBb0I7QUFDeEQsU0FBUyxtQkFBbUI7QUFLckIsZ0JBQVMsa0JBQWtCLE9BQW9CLE9BQXdCLEtBQWM7QUFDMUYsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sUUFBTSxNQUFNLE9BQU8sVUFBTSxLQUFLLEtBQUcsS0FBSyxZQUFZLElBQUksQ0FBQztBQUM3RCxNQUFJLFVBQVE7QUFDWixRQUFNLE9BQUssTUFBTSxPQUFPLFVBQU07QUFDNUIsUUFBRyxLQUFLLGFBQWEsS0FBSyxRQUFPO0FBQUMsVUFBRyxLQUFLLE1BQUs7QUFBQyxlQUFPLEtBQUs7QUFBSyxrQkFBUTtBQUFBLE1BQUs7QUFBQyxhQUFPO0FBQUEsSUFBSztBQUMzRixVQUFNLFNBQU8sS0FBSyxRQUFRLE1BQU0sS0FBSyxVQUFNLEtBQUssT0FBSyxLQUFLLEtBQU0sTUFBTTtBQUN0RSxRQUFHLFFBQU87QUFBQyxhQUFPLE9BQU8sTUFBSyxhQUFhLFFBQU8sS0FBSyxJQUFLLENBQUM7QUFBRSxhQUFPO0FBQUEsSUFBSztBQUMzRSxRQUFHLEtBQUssTUFBSztBQUFDLGFBQU8sS0FBSztBQUFLLGdCQUFRO0FBQUEsSUFBSztBQUM1QyxVQUFNLFVBQVEsTUFBTSxLQUFLLFVBQU0sYUFBYSxhQUFhLE1BQUssSUFBSSxHQUFFLEdBQUUsWUFBWSxJQUFJLEVBQUcsSUFBSSxDQUFDO0FBQzlGLFFBQUcsU0FBUTtBQUFDLFdBQUssT0FBSyxFQUFDLFFBQU8sUUFBUSxJQUFHLEdBQUcsYUFBYSxTQUFRLElBQUksRUFBQztBQUFFLGdCQUFRO0FBQUssYUFBTztBQUFBLElBQUs7QUFDakcsVUFBTSxVQUFRLElBQUk7QUFDbEIsUUFBRyxDQUFDLFFBQVEsUUFBTztBQUNuQixVQUFNLE1BQUksS0FBSyxNQUFNLEtBQUssSUFBRSxRQUFRLElBQUksR0FBRSxNQUFJLEtBQUssTUFBTSxLQUFLLElBQUUsUUFBUSxJQUFJO0FBQzVFLFFBQUcsQ0FBQyxZQUFZLFFBQVEsTUFBTSxNQUFJLFFBQVEsT0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLElBQUksUUFBTztBQUN4RSxjQUFRO0FBQUssV0FBTztBQUFBLEVBQ3RCLENBQUM7QUFDRCxNQUFHLEtBQUssV0FBUyxNQUFNLE9BQU8sT0FBTSxPQUFPLEdBQUUsTUFBTSxRQUFPLEdBQUcsSUFBSTtBQUNqRSxNQUFHLFFBQVEscUJBQW9CLEtBQUs7QUFDcEMsU0FBTztBQUNUOyIsIm5hbWVzIjpbXX0=