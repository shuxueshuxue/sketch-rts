import { describe, expect, it } from 'vitest';
import { boardUnit, deckPlacement } from '../../shared/decks';
import { createGame, issuePlayerCommand, snapshotGame, stepGame } from '../../shared/sim';
import { sameGround } from '../../shared/terrain';
import { seconds } from '../../shared/time';
import { cabinDoor, enterCabinStep, isCabinProtected, isInCabin } from '../../shared/ship-cabin';
import { canReach } from '../../shared/naval';
import { hullContact, localToWorld, shipPassengers } from '../../shared/ship-geometry';
import { hullFits } from '../../shared/ship-navigation';
import type { RaceId } from '../../shared/types';
import { BOOTSTRAP_VERSIONS, bootstrapPolicyContext } from '../bootstrap_1/policy';
import { createAiPolicyMemory } from '../memory';
import { planNavalTactics } from './naval';
import { effectiveCombatRating, strengthOf } from './v6/strength';
import { attackMargin } from './v6/general';

function crossing(race: RaceId, phase: 'loading' | 'sailing', players = ['player', 'enemy']) {
  const game = createGame('bareDuel', { players, races: { player: race }, scenario: {
    players: { player: { gold: 500 } },
    replaceDefaultUnits: true, replaceDefaultBuildings: true, replaceDefaultResources: true,
    replaceDefaultMercenaryCamps: true, replaceDefaultLandmarks: true,
    addBuildings: [{ id: 'home', owner: 'player', kind: 'townHall', x: 112, y: 112 }],
    addResources: [{ id: 'island', kind: 'goldMine', x: 2256, y: 400, amount: 6000 }],
  } });
  const cols = 80, rows = 36, cell = 32;
  const cells = Array.from({ length: rows }, (_, row) => Array.from({ length: cols }, (_, col) => {
    const island = col >= 66 && col <= 76 && row >= 8 && row <= 24;
    const shore = col >= 65 && col <= 77 && row >= 7 && row <= 25;
    return col <= 8 || island ? '.' : col === 9 || shore ? ',' : '~';
  }).join('')).join('');
  game.map = { ...game.map, width: cols * cell, height: rows * cell, terrain: { cell, cols, rows, cells } };
  game.scriptedVictory = true;
  const boat = game.spawnUnit('player', 'transport', phase === 'loading' ? 400 : 1600, 528);
  const passenger = game.spawnUnit('player', 'footman', boat.x, boat.y);
  expect(boardUnit(boat, passenger, game.units)).toBe(true);
  const enemy = game.spawnUnit('enemy', 'warship', 1920, 720);
  enemy.order = { type: 'hold', x: enemy.x, y: enemy.y };
  const memory = createAiPolicyMemory();
  const mission = { purpose: 'settle' as const, targetId: 'island', from: { x: 304, y: 528 },
    to: { x: 2096, y: 528 }, phase, crewIds: [], sinceTick: game.tick };
  memory.naval = { island: { tick: game.tick, plan: { mineId: 'island', landing: mission.to } },
    ferries: { [boat.id]: mission } };
  // Keep a worker aboard so the colony is a legitimate departure.
  const worker = game.spawnUnit('player', 'worker', boat.x, boat.y);
  expect(boardUnit(boat, worker, game.units)).toBe(true);
  return { game, boat, passenger, worker, enemy, memory, mission };
}

describe('actual convoy cover', () => {
  for (const version of BOOTSTRAP_VERSIONS) for (const race of ['grove', 'ember'] as const) {
    it(`${version}/${race} crosses with nearby guns and returns when those escorts withdraw`, () => {
      const { game, boat, memory, mission } = crossing(race, 'sailing');
      const escorts = [game.spawnUnit('player', 'warship', 1500, 700),
        game.spawnUnit('player', 'warship', 1450, 950), game.spawnUnit('player', 'warship', 1700, 1000)];
      const context = () => bootstrapPolicyContext(snapshotGame(game), 'player', version, { memory });
      const supported = planNavalTactics(snapshotGame(game), 'player', context());
      expect(mission.phase).toBe('sailing');
      expect(supported).toContainEqual({ type: 'unload', unitIds: [boat.id], ...mission.to });
      for (const command of supported) issuePlayerCommand(game, 'player', command);
      stepGame(game);
      for (const escort of escorts) escort.hp = escort.maxHp * .3;
      const retreat = planNavalTactics(snapshotGame(game), 'player', context());
      expect(mission.phase).toBe('return');
      expect(retreat).toContainEqual({ type: 'unload', unitIds: [boat.id], ...mission.from, avoidCombat: true });
      for (const command of retreat) issuePlayerCommand(game, 'player', command);
      expect(boat.order).toMatchObject({ type: 'unload', ...mission.from, avoidCombat: true });
    });
  }

  it.each(['loading', 'sailing'] as const)('does not count a remote healthy fleet during %s', phase => {
    const { game, boat, memory, mission } = crossing('grove', phase);
    for (const [x, y] of [[500, 700], [500, 950], [700, 1000]]) game.spawnUnit('player', 'warship', x!, y!);
    const commands = planNavalTactics(snapshotGame(game), 'player', bootstrapPolicyContext(snapshotGame(game), 'player', 'v9_knight', { memory }));
    expect(mission.phase).toBe(phase === 'sailing' ? 'return' : 'loading');
    expect(commands).not.toContainEqual({ type: 'unload', unitIds: [boat.id], ...mission.to });
    for (const command of commands) issuePlayerCommand(game, 'player', command);
  });

  it.each(['loading','sailing'] as const)('counts the same local escort crew only while exposed during %s',phase=>{
    const {game,boat,enemy,memory,mission}=crossing('grove',phase);
    const escort=game.spawnUnit('player','warship',1696,944);
    escort.hp=escort.maxHp*.5;
    expect(hullFits(game.map,escort)).toBe(true);
    expect(hullContact(escort,enemy)).toBeUndefined();
    const archers=[game.spawnUnit('player','archer',escort.x,escort.y),game.spawnUnit('player','archer',escort.x,escort.y)];
    for(const archer of archers) {
      expect(boardUnit(escort,archer,game.units)).toBe(true);
      expect(canReach(game.map,archer,enemy,game.units)).toBe(true);
    }
    issuePlayerCommand(game,'player',{type:'holdPosition',unitIds:archers.map(archer=>archer.id)});
    const exposedSnapshot=snapshotGame(game),context=bootstrapPolicyContext(exposedSnapshot,'player','v9_archer',{memory});
    const bareGun=effectiveCombatRating(exposedSnapshot,escort),opposition=effectiveCombatRating(exposedSnapshot,enemy)*attackMargin(context);
    // Establish both sides of the decision with the actual hull and crew stats:
    // this healthy but damaged gun needs its reachable archers to cover the trip.
    expect(opposition).toBeGreaterThan(bareGun);
    expect(opposition).toBeLessThan(bareGun+strengthOf(archers));
    const exposed=planNavalTactics(exposedSnapshot,'player',context);
    expect(mission.phase).toBe('sailing');
    expect(exposed).toContainEqual({type:'unload',unitIds:[boat.id],...mission.to});

    for(const archer of archers) {
      const door=deckPlacement(escort,archer,game.units,cabinDoor(escort),true,2);
      expect(door).toBeDefined();
      archer.deck={shipId:escort.id,...door!};Object.assign(archer,localToWorld(escort,door!));
      issuePlayerCommand(game,'player',{type:'enterCabin',unitIds:[archer.id]});enterCabinStep(game,archer);
      expect(isInCabin(archer)).toBe(true);expect(isCabinProtected(game,archer)).toBe(true);
    }
    expect(shipPassengers(game.units,escort)).toHaveLength(archers.length);
    mission.phase=phase;
    const shelteredSnapshot=snapshotGame(game);
    const sheltered=planNavalTactics(shelteredSnapshot,'player',bootstrapPolicyContext(shelteredSnapshot,'player','v9_archer',{memory}));
    expect(mission.phase).toBe(phase==='sailing'?'return':'loading');
    expect(sheltered).not.toContainEqual({type:'unload',unitIds:[boat.id],...mission.to});
    if(phase==='sailing')expect(sheltered).toContainEqual({type:'unload',unitIds:[boat.id],...mission.from,avoidCombat:true});
  });

  it('counts allied support but not hostile boarders on the same weak escort', () => {
    const { game, boat, enemy, memory, mission } = crossing('grove', 'sailing', ['player', 'enemy', 'ally']);
    const escort = game.spawnUnit('player', 'warship', 1696, 944);
    escort.hp = escort.maxHp * .5;
    expect(hullFits(game.map, escort)).toBe(true);
    expect(hullContact(escort, enemy)).toBeUndefined();
    // A living original guard keeps this an owned escort under boarding,
    // rather than a captured hull which has already changed sides.
    const guard = game.spawnUnit('player', 'footman', escort.x, escort.y);
    guard.hp = guard.maxHp * .1;
    const archers = [game.spawnUnit('enemy', 'archer', escort.x, escort.y),
      game.spawnUnit('enemy', 'archer', escort.x, escort.y)];
    for (const crew of [guard, ...archers]) expect(boardUnit(escort, crew, game.units)).toBe(true);
    const snapshot = snapshotGame(game);
    const teams = { player: 'blue', ally: 'blue', enemy: 'red' };
    const context = bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory, teams });
    const weakCover = effectiveCombatRating(snapshot, escort) + strengthOf([guard]);
    const opposition = effectiveCombatRating(snapshot, enemy) * attackMargin(context);
    expect(opposition).toBeGreaterThan(weakCover);
    expect(opposition).toBeLessThan(weakCover + strengthOf(archers));

    for (const owner of ['enemy', 'neutral', 'ally']) {
      for (const archer of archers) archer.owner = owner;
      mission.phase = 'sailing';
      const current = snapshotGame(game);
      const commands = planNavalTactics(current, 'player', bootstrapPolicyContext(current, 'player', 'v9_archer', { memory, teams }));
      expect(escort.owner).toBe('player');
      expect(guard.hp).toBeGreaterThan(0);
      expect(guard.deck?.shipId).toBe(escort.id);
      expect(shipPassengers(game.units, escort)).toHaveLength(3);
      if (owner === 'ally') {
        expect(mission.phase).toBe('sailing');
        expect(commands).toContainEqual({ type: 'unload', unitIds: [boat.id], ...mission.to });
      } else {
        expect(mission.phase).toBe('return');
        expect(commands).toContainEqual({ type: 'unload', unitIds: [boat.id], ...mission.from, avoidCombat: true });
      }
    }
  });

  it('lands its living passengers back at the departure coast after losing cover', () => {
    const { game, boat, passenger, worker, memory, mission } = crossing('grove', 'sailing');
    for (let tick = 0; tick < seconds(100) && worker.deck; tick++) {
      if (tick % 15 === 0) {
        const snapshot = snapshotGame(game);
        for (const command of planNavalTactics(snapshot, 'player', bootstrapPolicyContext(snapshot, 'player', 'v9_archer', { memory })))
          issuePlayerCommand(game, 'player', command);
      }
      stepGame(game);
    }
    expect(game.units).toContain(boat);
    expect(game.units).toContain(passenger);
    expect(game.units).toContain(worker);
    expect(worker.deck).toBeUndefined();
    expect(passenger.deck).toBeUndefined();
    expect(sameGround(game.map, worker, mission.from)).toBe(true);
    expect(sameGround(game.map, passenger, mission.from)).toBe(true);
  }, 15000);
});
