import { describe, expect, it } from "vitest";
import { createGame,snapshotGame } from "../../shared/sim";
import { sketchScene } from "../../sdk/scene";
import { createAiPolicyMemory } from "../memory";
import { planAbilityCommands, planFocusFireCommand } from "./spell-tactics";

describe("AI spell and focus tactics", () => {
  for(const version of ['v5','v7','v8'] as const)it(`${version} neither heals nor regroups toward damaged hulls`,()=>{
    const game=createGame('bareDuel',{aiPlayers:[]});game.units=[];game.buildings=[];game.resources=[];delete game.map.terrain;
    game.spawnUnit('player','priest',600,600);const ship=game.spawnUnit('player','transport',700,600);ship.hp=10;
    expect(planAbilityCommands(snapshotGame(game),'player',{version})).toEqual([]);
    ship.x=1050;expect(planAbilityCommands(snapshotGame(game),'player',{version})).toEqual([]);
  });
  it("casts heal on a nearby wounded allied unit", () => {
    const game = sketchScene("spell-tactics-heal")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .townHall("v2", 500, 500)
      .unit("v2", "priest", 540, 500, { id: "priest" })
      .unit("v2", "footman", 570, 500, { id: "wounded", hp: 30 })
      .build()
      .createGame();

    expect(planAbilityCommands(snapshotGame(game), "v2", { version: "v2" })[0]).toEqual({ type: "cast", unitId: "priest", ability: "heal", targetId: "wounded" });
  });

  it("casts heal on the most critical nearby wounded allied unit", () => {
    const game = sketchScene("spell-tactics-heal-critical-target")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .townHall("v2", 500, 500)
      .unit("v2", "priest", 540, 500, { id: "priest" })
      .unit("v2", "footman", 570, 500, { id: "mild-wound", hp: 90 })
      .unit("v2", "footman", 600, 500, { id: "critical-wound", hp: 18 })
      .build()
      .createGame();

    expect(planAbilityCommands(snapshotGame(game), "v2", { version: "v2" })[0]).toEqual({ type: "cast", unitId: "priest", ability: "heal", targetId: "critical-wound" });
  });

  it("V8 heals the soldier it would miss most: a hurt veteran ahead of an equally hurt rookie, a rookie near death ahead of a scratched veteran", () => {
    const plan = (veteranHp: number, rookieHp: number) => {
      const game = sketchScene("spell-tactics-v8-heal-worth")
        .map("bareDuel")
        .replaceDefaults()
        .player("v8", { team: "north", race: "grove" })
        .townHall("v8", 500, 500)
        .unit("v8", "priest", 540, 500, { id: "priest" })
        .unit("v8", "raider", 570, 500, { id: "veteran" })
        .unit("v8", "raider", 600, 500, { id: "rookie" })
        .unit("v8", "worker", 560, 530, { id: "worker", hp: 10 })
        .build()
        .createGame();
      const veteran = game.units.find((unit) => unit.id === "veteran")!;
      const rookie = game.units.find((unit) => unit.id === "rookie")!;
      veteran.level = 3;
      veteran.maxHp = Math.round(rookie.maxHp * 1.75);
      veteran.hp = Math.round(veteran.maxHp * veteranHp);
      rookie.hp = Math.round(rookie.maxHp * rookieHp);
      const cast = (options: { version: "v2"; requestedVersion?: "v8" }) => planAbilityCommands(snapshotGame(game), "v8", options).find((command) => command.type === "cast");
      return { v8: cast({ version: "v2", requestedVersion: "v8" }), shared: cast({ version: "v2" }) };
    };
    expect(plan(0.5, 0.5).v8).toMatchObject({ unitId: "priest", ability: "heal", targetId: "veteran" });
    expect(plan(0.75, 0.2).v8).toMatchObject({ targetId: "rookie" });
    expect(plan(0.5, 0.45).shared).toMatchObject({ targetId: "worker" });
    expect(plan(0.5, 0.45).v8).toMatchObject({ targetId: "veteran" });
  });

  it("moves an idle healer toward a safe wounded group outside heal range", () => {
    const game = sketchScene("spell-tactics-healer-regroups-to-wounded")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north", race: "grove" })
      .player("v1", { team: "south", race: "grove" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3500, 3500)
      .unit("v2", "fieldMedic", 1300, 900, { id: "medic" })
      .unit("v2", "footman", 620, 560, { id: "wounded-a", hp: 38 })
      .unit("v2", "lancer", 650, 590, { id: "wounded-b", hp: 42 })
      .unit("v1", "footman", 3300, 3300)
      .build()
      .createGame();

    const command = planAbilityCommands(snapshotGame(game), "v2", { version: "v2", teams: game.teams })[0];

    expect(command).toMatchObject({ type: "move", unitIds: ["medic"] });
    expect(command?.type === "move" ? command.x : 0).toBeCloseTo(635, -1);
    expect(command?.type === "move" ? command.y : 0).toBeCloseTo(575, -1);
  });

  it("retargets a moving healer when the wounded group has fallen back from the old regroup point", () => {
    const game = sketchScene("spell-tactics-healer-retargets-wounded")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north", race: "grove" })
      .player("v1", { team: "south", race: "grove" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3500, 3500)
      .unit("v2", "fieldMedic", 1300, 900, { id: "medic", order: { type: "move", x: 1170, y: 840 } })
      .unit("v2", "footman", 620, 560, { id: "wounded-a", hp: 38 })
      .unit("v2", "lancer", 650, 590, { id: "wounded-b", hp: 42 })
      .unit("v1", "footman", 3300, 3300)
      .build()
      .createGame();

    const command = planAbilityCommands(snapshotGame(game), "v2", { version: "v2", teams: game.teams })[0];

    expect(command).toMatchObject({ type: "move", unitIds: ["medic"] });
    expect(command?.type === "move" ? command.x : 0).toBeCloseTo(635, -1);
    expect(command?.type === "move" ? command.y : 0).toBeCloseTo(575, -1);
  });

  it("casts ember-specific support abilities through the same spell planner", () => {
    const game = sketchScene("spell-tactics-ember-abilities")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north", race: "ember" })
      .player("v1", { team: "south", race: "grove" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3500, 3500)
      .unit("v2", "priest", 540, 500, { id: "acolyte" })
      .unit("v2", "summoner", 580, 500, { id: "caller" })
      .unit("v2", "ashHexer", 620, 500, { id: "hexer" })
      .unit("v2", "emberRavager", 570, 500, { id: "wounded", hp: 30 })
      .unit("v1", "footman", 710, 500, { id: "target" })
      .build()
      .createGame();

    expect(planAbilityCommands(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual([
      { type: "cast", unitId: "acolyte", ability: "heal", targetId: "wounded" },
      { type: "cast", unitId: "caller", ability: "summon", x: 634, y: 528 },
      { type: "cast", unitId: "hexer", ability: "ashCurse", targetId: "target" },
    ]);
  });

  it("prefers ash curse on scorched targets when ember has set up the burn window", () => {
    const game = sketchScene("spell-tactics-ash-curse-scorch-window")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north", race: "ember" })
      .player("v1", { team: "south", race: "grove" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3500, 3500)
      .unit("v2", "ashHexer", 620, 500, { id: "hexer" })
      .unit("v1", "footman", 710, 500, { id: "near-plain" })
      .unit("v1", "raider", 780, 500, { id: "scorched-target" })
      .build()
      .createGame();
    game.units.find((unit) => unit.id === "scorched-target")!.effects.push({ type: "scorch", remaining: 100 });

    expect(planAbilityCommands(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual([
      { type: "cast", unitId: "hexer", ability: "ashCurse", targetId: "scorched-target" },
    ]);
  });

  it("does not recast curse on the nearest already-cursed target when another target is valid", () => {
    const game = sketchScene("spell-tactics-curse-valid-target")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north", race: "grove" })
      .player("v1", { team: "south", race: "grove" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3500, 3500)
      .unit("v2", "witch", 620, 500, { id: "witch" })
      .unit("v1", "footman", 710, 500, { id: "already-cursed" })
      .unit("v1", "raider", 780, 500, { id: "valid-target" })
      .build()
      .createGame();
    game.units.find((unit) => unit.id === "already-cursed")!.effects.push({ type: "curse", remaining: 100 });

    expect(planAbilityCommands(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual([
      { type: "cast", unitId: "witch", ability: "curse", targetId: "valid-target" },
    ]);
  });

  it("focuses nearby v2 fighters onto one enemy target", () => {
    const game = sketchScene("spell-tactics-focus")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .unit("v2", "footman", 540, 500, { id: "footman" })
      .unit("v2", "archer", 560, 500, { id: "archer" })
      .unit("v1", "lancer", 620, 500, { id: "target", hp: 20 })
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual({ type: "attack", unitIds: ["footman", "archer"], targetId: "target" });
  });

  it("does not pull retreat-claimed fighters back into focus fire", () => {
    const game = sketchScene("spell-tactics-focus-respects-retreat-claims")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v2", "footman", 660, 780, { id: "healthy-footman" })
      .unit("v2", "archer", 650, 830, { id: "healthy-archer" })
      .unit("v2", "lancer", 690, 805, { id: "retreat-lancer", hp: 58 })
      .unit("v1", "archer", 735, 805, { id: "target", hp: 35 })
      .build()
      .createGame();
    const memory = createAiPolicyMemory();
    memory.unitClaims["retreat-lancer"] = { kind: "retreat", targetId: "retreat", x: 150, y: 200, sinceTick: 0, expiresTick: 900 };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat", memory })).toEqual({
      type: "attack",
      unitIds: ["healthy-footman", "healthy-archer"],
      targetId: "target",
    });
  });

  it("lets a v5 two-base mercenary squad chase the ranged unit attacking its arrived camp group", () => {
    const game = sketchScene("spell-tactics-v5-arrived-merc-counterfire")
      .map("openClaims")
      .replaceDefaults()
      .player("v5", { team: "south", race: "grove" })
      .player("v3", { team: "north", race: "ember" })
      .player("v4-tr", { team: "north", race: "grove" })
      .goldMine("v5-main-mine", 500, 500, 4_000)
      .goldMine("v5-natural-mine", 900, 500, 4_000)
      .townHall("v5", 500, 500)
      .townHall("v5", 900, 500)
      .townHall("v3", 3300, 3300)
      .townHall("v4-tr", 3400, 3700)
      .unit("v5", "footman", 1160, 980, { id: "claimed-a", order: { type: "attackMove", x: 1180, y: 980 } })
      .unit("v5", "footman", 1190, 1000, { id: "claimed-b", order: { type: "attackMove", x: 1180, y: 980 } })
      .unit("v5", "lancer", 1220, 1020, { id: "claimed-c", order: { type: "attackMove", x: 1180, y: 980 } })
      .unit("v5", "archer", 1240, 1040, { id: "claimed-d", order: { type: "attackMove", x: 1180, y: 980 } })
      .unit("v3", "contractArcher", 1580, 1000, { id: "ranged-poker", order: { type: "attack", targetId: "claimed-a" } })
      .mercenaryCamp("cleared-field-tent", 1180, 980, { hireKind: "contractArcher", cost: 160, stock: 1, cooldownRemaining: 0 })
      .build()
      .createGame();
    const memory = createAiPolicyMemory();
    for (const unitId of ["claimed-a", "claimed-b", "claimed-c", "claimed-d"]) {
      memory.unitClaims[unitId] = { kind: "mercenary", targetId: "cleared-field-tent", x: 1180, y: 980, sinceTick: 0, expiresTick: 900 };
    }

    expect(planFocusFireCommand(snapshotGame(game), "v5", { version: "v2", requestedVersion: "v5", teams: game.teams, memory })).toEqual({
      type: "attack",
      unitIds: ["claimed-a", "claimed-b", "claimed-c", "claimed-d"],
      targetId: "ranged-poker",
    });
  });

  it("keeps focusing a remembered live target instead of scattering damage every frame", () => {
    const game = sketchScene("spell-tactics-remembered-focus")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v2", "footman", 650, 780, { id: "footman" })
      .unit("v2", "archer", 640, 830, { id: "archer" })
      .unit("v1", "lancer", 720, 800, { id: "remembered-target" })
      .unit("v1", "raider", 700, 760, { id: "fresh-low-target", hp: 20 })
      .build()
      .createGame();
    const memory = createAiPolicyMemory();
    memory.strategicPlan = { focusTargetOwner: "v1", focusTargetId: "remembered-target", focusTargetSinceTick: 0, focusTargetUpdatedTick: 0 };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat", memory })).toEqual({
      type: "attack",
      unitIds: ["footman", "archer"],
      targetId: "remembered-target",
    });
  });

  it("lets melee focus memory yield to a one-shot finisher", () => {
    const game = sketchScene("spell-tactics-melee-finisher-before-memory")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .unit("v2", "archer", 760, 790, { id: "archer", order: { type: "attack", targetId: "remembered-merc" } })
      .unit("v2", "contractArcher", 780, 820, { id: "contract-archer", order: { type: "attack", targetId: "remembered-merc" } })
      .unit("v1", "mercenary", 930, 805, { id: "remembered-merc", hp: 120 })
      .unit("v1", "mercenary", 950, 820, { id: "one-shot-merc", hp: 1 })
      .build()
      .createGame();
    const memory = createAiPolicyMemory();
    memory.strategicPlan = { focusTargetOwner: "v1", focusTargetId: "remembered-merc", focusTargetSinceTick: 0, focusTargetUpdatedTick: 0 };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, memory })).toEqual({
      type: "attack",
      unitIds: ["archer", "contract-archer"],
      targetId: "one-shot-merc",
    });
  });

  it("drops a remembered focus target when only a small tail can still fight it", () => {
    const scene = sketchScene("spell-tactics-drop-stale-focus-tail")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v2", "raider", 1340, 800, { id: "tail-raider-a" })
      .unit("v2", "lancer", 1360, 830, { id: "tail-lancer-b" })
      .unit("v1", "raider", 1480, 810, { id: "remembered-runner", hp: 24 })
      .unit("v1", "archer", 760, 790, { id: "front-archer", hp: 55 });
    for (let index = 0; index < 10; index += 1) scene.unit("v2", index % 3 === 0 ? "archer" : "footman", 680 + index * 8, 730 + index * 12, { id: `front-fighter-${index + 1}` });
    const game = scene.build().createGame();
    const memory = createAiPolicyMemory();
    memory.strategicPlan = { focusTargetOwner: "v1", focusTargetId: "remembered-runner", focusTargetSinceTick: 0, focusTargetUpdatedTick: 120 };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat", memory })).toEqual({
      type: "attack",
      unitIds: Array.from({ length: 10 }, (_, index) => `front-fighter-${index + 1}`),
      targetId: "front-archer",
    });
  });

  it("keeps a four-unit combat tail on a remembered wounded target it can finish", () => {
    const scene = sketchScene("spell-tactics-keep-wounded-focus-tail")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v2", "archer", 630, 700, { id: "tail-archer-a" })
      .unit("v2", "archer", 640, 760, { id: "tail-archer-b" })
      .unit("v2", "archer", 650, 820, { id: "tail-archer-c" })
      .unit("v2", "raider", 830, 805, { id: "tail-raider" })
      .unit("v1", "raider", 900, 805, { id: "remembered-raider", hp: 31 })
      .unit("v1", "archer", 895, 760, { id: "fresh-wounded-archer", hp: 28 });
    for (let index = 0; index < 6; index += 1) scene.unit("v2", index % 2 === 0 ? "footman" : "lancer", 680 + index * 14, 970 + index * 18, { id: `front-fighter-${index + 1}` });
    const game = scene.build().createGame();
    const memory = createAiPolicyMemory();
    memory.strategicPlan = { focusTargetOwner: "v1", focusTargetId: "remembered-raider", focusTargetSinceTick: 60, focusTargetUpdatedTick: 105 };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat", memory })).toEqual({
      type: "attack",
      unitIds: ["tail-archer-a", "tail-archer-b", "tail-archer-c", "tail-raider"],
      targetId: "remembered-raider",
    });
  });

  it("targets high-value combat casters before ordinary front-line damage dealers", () => {
    const game = sketchScene("spell-tactics-caster-focus-priority")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v2", "knight", 680, 760, { id: "knight" })
      .unit("v2", "golem", 700, 800, { id: "golem" })
      .unit("v2", "archer", 680, 840, { id: "archer" })
      .unit("v1", "lancer", 760, 800, { id: "front-lancer" })
      .unit("v1", "summoner", 790, 820, { id: "summoner" })
      .unit("v1", "priest", 810, 780, { id: "priest" })
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat" })).toEqual({
      type: "attack",
      unitIds: ["knight", "golem", "archer"],
      targetId: "summoner",
    });
  });

  it("does not pin a small ranged group into a stronger local enemy squad", () => {
    const game = sketchScene("spell-tactics-no-disadvantaged-ranged-focus")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .unit("v2", "contractArcher", 820, 760, { id: "archer-a" })
      .unit("v2", "contractArcher", 850, 780, { id: "archer-b" })
      .unit("v2", "contractArcher", 880, 800, { id: "archer-c" })
      .unit("v1", "mercenary", 930, 820, { id: "target", hp: 95 })
      .unit("v1", "mercenary", 960, 850)
      .unit("v1", "footman", 990, 880)
      .unit("v1", "fieldMedic", 1020, 910)
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toBeUndefined();
  });

  it("does not pull a partial tail into a supported healer focus", () => {
    const scene = sketchScene("spell-tactics-no-supported-healer-tail-focus")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .townHall("v1", 3300, 3300)
      .unit("v2", "footman", 1120, 1600, { id: "tail-footman-a" })
      .unit("v2", "footman", 1145, 1630, { id: "tail-footman-b" })
      .unit("v2", "lancer", 1165, 1605, { id: "tail-lancer" })
      .unit("v2", "contractArcher", 1040, 1620, { id: "tail-contract" });
    for (let index = 0; index < 4; index += 1) scene.unit("v2", index % 2 === 0 ? "footman" : "lancer", 520 + index * 28, 2060 + index * 12, { id: `rear-fighter-${index + 1}` });
    scene
      .unit("v1", "fieldMedic", 1220, 1624, { id: "supported-medic" })
      .unit("v1", "contractArcher", 1400, 1650)
      .unit("v1", "contractArcher", 1420, 1680)
      .unit("v1", "mercenary", 1680, 1920)
      .unit("v1", "mercenary", 1720, 1950)
      .unit("v1", "lancer", 1760, 1980)
      .unit("v1", "footman", 1800, 2010);
    const game = scene.build().createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toBeUndefined();
  });

  it("lets a small nearby group pick off a critically wounded target", () => {
    const game = sketchScene("spell-tactics-critical-pickoff")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .unit("v2", "archer", 760, 790, { id: "archer" })
      .unit("v2", "contractArcher", 780, 820, { id: "contract-archer" })
      .unit("v2", "fieldMedic", 820, 800, { id: "field-medic" })
      .unit("v1", "archer", 930, 805, { id: "critical-archer", hp: 8 })
      .unit("v1", "mercenary", 960, 820)
      .unit("v1", "footman", 990, 850)
      .unit("v1", "fieldMedic", 1020, 880)
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual({
      type: "attack",
      unitIds: ["archer", "contract-archer", "field-medic"],
      targetId: "critical-archer",
    });
  });

  it("lets one ranged survivor finish a killable target already in range", () => {
    const game = sketchScene("spell-tactics-solo-finisher")
      .map("bareDuel")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 500, 500)
      .unit("v2", "archer", 660, 720, { id: "last-archer" })
      .unit("v1", "summoner", 940, 760, { id: "killable-summoner", hp: 6 })
      .unit("v1", "contractArcher", 900, 720, { id: "healthy-archer", hp: 81 })
      .unit("v1", "priest", 910, 780, { id: "wounded-priest", hp: 40 })
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual({
      type: "attack",
      unitIds: ["last-archer"],
      targetId: "killable-summoner",
    });
  });

  it("does not pin a tiny combat squad into focus fire while it is outnumbered", () => {
    const game = sketchScene("spell-tactics-combat-focus")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .unit("v2", "footman", 700, 760, { id: "front-a" })
      .unit("v2", "lancer", 700, 800, { id: "front-b" })
      .unit("v2", "archer", 680, 840, { id: "back-a" })
      .townHall("v1", 1450, 800)
      .unit("v1", "mercenary", 760, 760, { id: "wounded-target", hp: 40 })
      .unit("v1", "footman", 790, 800)
      .unit("v1", "footman", 810, 840)
      .unit("v1", "archer", 830, 880)
      .unit("v1", "raider", 850, 920)
      .build()
      .createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat" })).toBeUndefined();
  });

  it("keeps a medium squad focused on a wounded target while outnumbered in every lane", () => {
    const scene = sketchScene("spell-tactics-combat-medium-group-focus")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v1", "archer", 790, 790, { id: "wounded-archer", hp: 30 });
    for (let index = 0; index < 6; index += 1) scene.unit("v2", index % 2 === 0 ? "archer" : "footman", 680 + index * 12, 740 + index * 18, { id: `v2-fighter-${index + 1}` });
    for (let index = 0; index < 10; index += 1) scene.unit("v1", index % 3 === 0 ? "archer" : "footman", 820 + index * 8, 760 + index * 12, { id: `v1-guard-${index + 1}` });
    const game = scene.build().createGame();

    const expected = {
      type: "attack",
      unitIds: Array.from({ length: 6 }, (_, index) => `v2-fighter-${index + 1}`),
      targetId: "wounded-archer",
    };

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams })).toEqual(expected);
    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat" })).toEqual(expected);
  });

  it("uses focus fire for a full combat group even when the local enemy army is larger", () => {
    const scene = sketchScene("spell-tactics-combat-full-group-focus")
      .map("combatArena")
      .replaceDefaults()
      .player("v2", { team: "north" })
      .player("v1", { team: "south" })
      .townHall("v2", 150, 800)
      .townHall("v1", 1450, 800)
      .unit("v1", "mercenary", 820, 760, { id: "wounded-target", hp: 40 });
    for (let index = 0; index < 12; index += 1) scene.unit("v2", index % 3 === 0 ? "archer" : "footman", 690 + index * 6, 730 + index * 12, { id: `v2-fighter-${index + 1}` });
    for (let index = 0; index < 16; index += 1) scene.unit("v1", index % 4 === 0 ? "fieldMedic" : "footman", 850 + index * 5, 790 + index * 10, { id: `v1-guard-${index + 1}` });
    const game = scene.build().createGame();

    expect(planFocusFireCommand(snapshotGame(game), "v2", { version: "v2", teams: game.teams, policyMode: "combat" })).toEqual({
      type: "attack",
      unitIds: Array.from({ length: 12 }, (_, index) => `v2-fighter-${index + 1}`),
      targetId: "wounded-target",
    });
  });

});
