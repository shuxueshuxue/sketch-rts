import { UNIT_DEFS, canTrainAt, trainableUnitsAt } from "../../shared/catalog";
import { canReceiveHealing } from "../../shared/healing";
import type { Building, GameSnapshot, PlayerId, TrainableUnitKind } from "../../shared/types";
import { isOpponentOwner } from "./ownership";
import { distance } from "./spatial";
import { combatUnits, completeBuildings, units } from "./snapshot";
import { aiPlaybook } from "./playbook";
import { playerState, soldiersWorth, tierUnlocked } from "./world-model";
import type { PresetAiPolicyOptions } from "./types";
import { isV5HybridPolicy, isV5ShooterCorePolicy } from "./versions";

// A choice whose tier is still locked falls back to what the same building can already make (a spire's spark archers
// before its casters), or to nothing.
export function trainingChoice(snapshot: GameSnapshot, owner: PlayerId, building: Building, options: PresetAiPolicyOptions = {}): TrainableUnitKind | undefined {
  const choice = preferredTrainingChoice(snapshot, owner, building, options);
  const race = playerState(snapshot, owner).race;
  if (!choice || !canTrainAt(race, building.kind, choice)) return undefined;
  if (tierUnlocked(snapshot, owner, choice)) return choice;
  return trainableUnitsAt(race, building.kind).find((kind) => kind !== "worker" && tierUnlocked(snapshot, owner, kind));
}

function preferredTrainingChoice(snapshot: GameSnapshot, owner: PlayerId, building: Building, options: PresetAiPolicyOptions): TrainableUnitKind | undefined {
  const race = playerState(snapshot, owner).race;
  if (isV5ShooterCorePolicy(options)) {
    const rangedCore = v5RangedCoreChoice(snapshot, owner, building, options);
    if (rangedCore !== "default") return rangedCore;
  }
  if (building.kind === "emberForge") return emberForgeChoice(snapshot, owner);
  if (building.kind === "cinderSpire") return emberSpireChoice(snapshot, owner, options);
  if (building.kind === "barracks") return soldierChoice(snapshot, owner);
  if (building.kind === "archeryRange") return "archer";
  if (building.kind === "stables") {
    const army = combatUnits(snapshot, owner);
    if (isV5HybridPolicy(options) && army.length >= 6 && army.filter(unit => unit.kind === "horseArcher").length < Math.max(1, Math.floor(army.length / 6))) return "horseArcher";
    const knights = units(snapshot, owner).filter((unit) => unit.kind === "knight").length;
    const raiders = units(snapshot, owner).filter((unit) => unit.kind === "raider").length;
    const preferred = aiPlaybook(race).unitsByBuilding.stables?.[0] ?? "raider";
    if (preferred === "raider" && raiders < 3) return "raider";
    return knights < 2 && shouldTrainKnight(snapshot, owner, options) ? "knight" : "raider";
  }
  if (building.kind === "sanctum") {
    const priests = units(snapshot, owner).filter((unit) => unit.kind === "priest").length;
    const summoners = units(snapshot, owner).filter((unit) => unit.kind === "summoner").length;
    const witches = units(snapshot, owner).filter((unit) => unit.kind === "witch").length;
    const casterTarget = v2LateCasterTarget(snapshot, owner, options);
    if (shouldPrioritizeWoundedPriestTraining(snapshot, owner, options) && priests < casterTarget.priests) return "priest";
    if (priests < 1 && casterTarget.priests > 0) return "priest";
    if (summoners < 1 && casterTarget.summoners > 0) return "summoner";
    if (witches < 1 && casterTarget.witches > 0) return "witch";
    if (casterTarget.summoners > 1 && priests >= 1 && summoners >= 1 && witches >= 1) {
      if (summoners < casterTarget.summoners) return "summoner";
      if (witches < casterTarget.witches) return "witch";
      if (priests < casterTarget.priests) return "priest";
    }
    const sanctumUnits = aiPlaybook(race).unitsByBuilding.sanctum ?? ["priest", "summoner", "witch"];
    for (const kind of sanctumUnits) {
      if (kind === "priest" && priests < casterTarget.priests) return "priest";
      if (kind === "summoner" && summoners < casterTarget.summoners) return "summoner";
      if (kind === "witch" && witches < casterTarget.witches) return "witch";
    }
    return sanctumUnits[0] ?? "priest";
  }
  if (building.kind === "workshop") return race === "grove" ? (tierUnlocked(snapshot, owner, "golem") ? "golem" : "ballista") : "catapult";
  return undefined;
}

// V5 keeps a shooter core. A small screen becomes worthwhile when enemies repeatedly reach that line under aiming.
function v5RangedCoreChoice(snapshot: GameSnapshot, owner: PlayerId, building: Building, options: PresetAiPolicyOptions): TrainableUnitKind | undefined | "default" {
  const army = combatUnits(snapshot, owner);
  const shooterBuilding = playerState(snapshot, owner).race === "ember" ? "cinderSpire" : "archeryRange";
  if (building.kind === "barracks" || building.kind === "emberForge") {
    if (!completeBuildings(snapshot, owner, shooterBuilding).length) return "default";
    const front = army.filter(unit => unit.attackRange <= 100).length;
    const pressed = snapshot.units.some(enemy => isOpponentOwner(snapshot, owner, enemy.owner, options) && enemy.kind !== "worker" && enemy.attackRange <= 100
      && army.some(unit => unit.attackRange > 100 && distance(unit, enemy) < 300));
    return army.length >= 6 && pressed && front < Math.max(2, Math.floor(army.length / 4)) ? "default" : undefined;
  }
  if (building.kind === "cinderSpire") {
    if (army.length < 6) return "sparkArcher";
    const count = (kind: TrainableUnitKind) => army.filter(unit => unit.kind === kind).length;
    if (count("priest") < 1) return "priest";
    if (army.length >= 8 && count("sparkArcher") >= army.length * .6) {
      if (count("ashHexer") < 1) return "ashHexer";
      if (count("summoner") < 1) return "summoner";
    }
    return "sparkArcher";
  }
  return "default";
}

function emberForgeChoice(snapshot: GameSnapshot, owner: PlayerId): TrainableUnitKind {
  const army = combatUnits(snapshot, owner);
  const ravagers = army.filter((unit) => unit.kind === "emberRavager").length;
  const runners = army.filter((unit) => unit.kind === "cinderRunner").length;
  const wardens = army.filter((unit) => unit.kind === "ashWarden").length;
  if (army.length >= 6 && wardens < Math.max(1, Math.floor(army.length / 6))) return "ashWarden";
  if (ravagers < 1) return "emberRavager";
  if (runners < 1) return "cinderRunner";
  if (runners < Math.max(1, Math.ceil(ravagers / 2))) return "cinderRunner";
  return ravagers <= runners ? "emberRavager" : "cinderRunner";
}

function emberSpireChoice(snapshot: GameSnapshot, owner: PlayerId, options: PresetAiPolicyOptions): TrainableUnitKind {
  const army = combatUnits(snapshot, owner);
  const sparkArchers = army.filter((unit) => unit.kind === "sparkArcher").length;
  const acolytes = army.filter((unit) => unit.kind === "priest").length;
  const hexers = army.filter((unit) => unit.kind === "ashHexer").length;
  const callers = army.filter((unit) => unit.kind === "summoner").length;
  const supportTarget = options.version === "v2" && army.length >= 8 ? 2 : 1;
  if (isV5HybridPolicy(options) && shouldPrioritizeWoundedPriestTraining(snapshot, owner, options) && acolytes < supportTarget) return "priest";
  if (sparkArchers < 1) return "sparkArcher";
  if (shouldPrioritizeWoundedPriestTraining(snapshot, owner, options) && acolytes < supportTarget) return "priest";
  if (acolytes < 1) return "priest";
  if (hexers < 1) return "ashHexer";
  if (callers < 1) return "summoner";
  if (options.version === "v2" && callers < supportTarget) return "summoner";
  if (options.version === "v2" && hexers < supportTarget) return "ashHexer";
  if (sparkArchers < army.length / 3) return "sparkArcher";
  return "priest";
}

function shouldTrainKnight(snapshot: GameSnapshot, owner: PlayerId, options: PresetAiPolicyOptions) {
  const gold = playerState(snapshot, owner).gold;
  if (gold > soldiersWorth(5.2)) return true;
  if (options.version !== "v2") return false;
  return completeBuildings(snapshot, owner, "townHall").length >= 2 && combatUnits(snapshot, owner).length >= 10 && gold >= UNIT_DEFS.knight.cost;
}

export function shouldPrioritizeWoundedPriestTraining(snapshot: GameSnapshot, owner: PlayerId, options: PresetAiPolicyOptions = {}) {
  if (options.version !== "v2") return false;
  const healers = units(snapshot, owner).filter((unit) => unit.kind === "priest" || unit.kind === "fieldMedic").length;
  if (healers >= 2) return false;
  return combatUnits(snapshot, owner).filter((unit) => canReceiveHealing(unit, snapshot) && unit.kind !== "priest" && unit.kind !== "fieldMedic" && unit.hp < unit.maxHp * 0.62).length >= 3;
}

function v2LateCasterTarget(snapshot: GameSnapshot, owner: PlayerId, options: PresetAiPolicyOptions) {
  if (options.version !== "v2") return { priests: 1, summoners: 1, witches: 1 };
  const army = combatUnits(snapshot, owner);
  const gold = playerState(snapshot, owner).gold;
  if (army.length < 8 && gold < soldiersWorth(4.8)) return { priests: 1, summoners: 1, witches: 1 };
  return { priests: 2, summoners: 2, witches: 2 };
}

export function soldierChoice(snapshot: GameSnapshot, owner: PlayerId): TrainableUnitKind {
  if (playerState(snapshot, owner).race === "ember") return emberForgeChoice(snapshot, owner);
  const army = combatUnits(snapshot, owner);
  const footmen = army.filter((unit) => unit.kind === "footman").length;
  const lancers = army.filter((unit) => unit.kind === "lancer").length;
  if (footmen < 2) return "footman";
  if (lancers < Math.ceil(footmen / 2)) return "lancer";
  return "footman";
}
