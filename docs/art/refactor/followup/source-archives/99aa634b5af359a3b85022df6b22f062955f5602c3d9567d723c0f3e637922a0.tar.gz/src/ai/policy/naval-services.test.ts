import { describe, expect, it } from "vitest";
import {
  createGame,
  issuePlayerCommand,
  snapshotGame,
  stepGame,
} from "../../shared/sim";
import { boardUnit, syncDecks } from "../../shared/decks";
import { seconds } from "../../shared/time";
import { combatCapability } from "../../shared/combat-capabilities";
import { installedWeapons } from "../../shared/ship-equipment";
import { hullContact } from "../../shared/ship-geometry";
import { hullFits } from "../../shared/ship-navigation";
import { createAiPolicyMemory } from "../memory";
import { navalServices } from "./naval-services";
import { fleetStations } from "./fleet-formation";
import { createBuilding } from '../../shared/map';

function sea() {
  const game = createGame("bareDuel", { aiPlayers: [] });
  game.units = [];
  game.buildings = [];
  game.resources = [];
  game.map.terrain = {
    cell: 40,
    cols: 100,
    rows: 100,
    cells: "~".repeat(10000),
  };
  game.map.width = game.map.height = 4000;
  game.scriptedVictory = true;
  game.players.player!.gold = 3000;
  return game;
}
describe("physical naval service tasks", () => {
  it("reserves a boarding crew and both endpoints even when its own hull is missing", () => {
    const game = sea();
    const crew = game.spawnUnit("player", "worker", 900, 900);
    const hostile = game.spawnUnit("enemy", "transport", 1200, 900);
    crew.deck = { shipId: "departed-hull", x: 0, y: 0 };
    crew.order = { type: "board", transportId: hostile.id };
    const snapshot = snapshotGame(game);
    const before = JSON.stringify(snapshot);
    const options = { version: "v5" as const, memory: createAiPolicyMemory() };
    const memoryBefore = JSON.stringify(options.memory);
    const service = navalServices(snapshot, "player", options);
    expect(service.reserved).toEqual(new Set([crew.id, "departed-hull", hostile.id]));
    expect(service.commands).toEqual([]);
    expect(JSON.stringify(snapshot)).toBe(before);
    expect(JSON.stringify(options.memory)).toBe(memoryBefore);
  });
  for (const version of ["v5", "v7", "v8"] as const) {
    it(`${version} sends a repair worker across decks and the shared simulation repairs the hull`, () => {
      const game = sea(),
        source = game.spawnUnit("player", "warship", 900, 900),
        target = game.spawnUnit("player", "warship", 1160, 900);
      const worker = game.spawnUnit("player", "worker", 900, 900);
      expect(boardUnit(source, worker, game.units)).toBe(true);
      syncDecks(game.units);
      target.order = { type: "move", x: 1400, y: 1100 };
      target.hp = Math.floor(target.maxHp * 0.45);
      const before = target.hp;
      const options = { version, memory: createAiPolicyMemory() };
      const service = navalServices(snapshotGame(game), "player", options);
      expect(service.reserved).toEqual(
        new Set([source.id, target.id, worker.id]),
      );
      for (const command of service.commands)
        issuePlayerCommand(game, "player", command);
      // The final approach uses low-speed maneuver assistance before the worker crosses.
      for (let tick = 0; tick < seconds(60) && target.hp <= before; tick++) {
        stepGame(game);
        expect(hullFits(game.map, source)).toBe(true);
        expect(hullFits(game.map, target)).toBe(true);
        expect(hullContact(source, target)?.overlap ?? 0).toBeLessThan(.1);
      }
      expect(worker.deck?.shipId).toBe(target.id);
      expect(target.hp).toBeGreaterThan(before);
    });
    it(`${version} captures an empty enemy hull without its own automatic guns sinking the prize`, () => {
      const game = sea(),
        source = game.spawnUnit("player", "warship", 900, 900),
        prize = game.spawnUnit("enemy", "transport", 1160, 900);
      prize.hp = 60;
      const crew = game.spawnUnit("player", "footman", 900, 900);
      expect(boardUnit(source, crew, game.units)).toBe(true);
      syncDecks(game.units);
      const service = navalServices(snapshotGame(game), "player", {
        version,
        memory: createAiPolicyMemory(),
      });
      expect(service.commands).toContainEqual({
        type: "board",
        unitIds: [crew.id],
        transportId: prize.id,
      });
      for (const command of service.commands)
        issuePlayerCommand(game, "player", command);
      for (let tick = 0; tick < seconds(35) && prize.owner !== "player"; tick++)
        stepGame(game);
      expect(game.units).toContain(prize);
      expect(prize.owner).toBe("player");
      expect(crew.deck?.shipId).toBe(prize.id);
    });
  }
  it.each(['new', 'ongoing'] as const)('brings a held ship alongside its %s shore boarding task', task => {
    const game = sea();
    game.map.terrain!.cells = Array.from({ length: 100 }, () => '.'.repeat(25) + ',' + '~'.repeat(74)).join('');
    game.buildings.push(createBuilding('dock', 'player', 'shipyard', 1000, 600, true));
    const ship = game.spawnUnit('player', 'warship', 1250, 900);
    game.spawnUnit('player', 'warship', 1800, 1500);
    const workers = Array.from({ length: 7 }, (_, i) => game.spawnUnit('player', 'worker', 900, 750 + i * 40));
    const engineer = workers[4]!;
    ship.order = { type: 'hold', x: ship.x, y: ship.y };
    if (task === 'ongoing') {
      issuePlayerCommand(game, 'player', { type: 'board', unitIds: [engineer.id], transportId: ship.id });
      for (let tick = 0; tick < seconds(5); tick++) stepGame(game);
      expect(engineer.deck).toBeUndefined();
      expect(ship.order.type).toBe('hold');
      expect(ship.x).toBe(1250); expect(ship.y).toBe(900);
      expect(ship.sailing!.sail!.set).toBe(0);
    }
    const services = navalServices(snapshotGame(game), 'player', { version: 'v8', memory: createAiPolicyMemory() });
    for (const command of services.commands) issuePlayerCommand(game, 'player', command);
    let approachSail = 0, travel = 0, totalYaw = 0;
    // The aligned berth can use a short astern approach at auxiliary speed.
    // Bound distance and turning as well as completion time.
    for (let tick = 0; tick < seconds(30); tick++) {
      const before = {x:ship.x,y:ship.y,heading:ship.sailing!.heading};
      stepGame(game);
      travel += Math.hypot(ship.x-before.x,ship.y-before.y);
      const turn=ship.sailing!.heading-before.heading;totalYaw+=Math.abs(Math.atan2(Math.sin(turn),Math.cos(turn)));
      expect(hullFits(game.map,ship)).toBe(true);
      if (!engineer.deck) approachSail = Math.max(approachSail, ship.sailing!.sail?.set ?? 0);
    }
    expect(travel).toBeLessThan(300); expect(totalYaw).toBeLessThan(Math.PI);
    expect(approachSail).toBeGreaterThan(.1);
    expect(engineer.deck?.shipId).toBe(ship.id);
  });
  it("honors an explicit player attack on a hull being boarded", () => {
    const game = sea(),
      ship = game.spawnUnit("player", "warship", 900, 900),
      prize = game.spawnUnit("enemy", "transport", 1150, 900),
      crew = game.spawnUnit("player", "footman", 900, 900);
    boardUnit(ship, crew, game.units);
    syncDecks(game.units);
    crew.order = { type: "board", transportId: prize.id };
    const hp = prize.hp;
    issuePlayerCommand(game, "player", {
      type: "attack",
      unitIds: [ship.id],
      targetId: prize.id,
    });
    for (let tick = 0; tick < seconds(3); tick++) stepGame(game);
    expect(prize.hp).toBeLessThan(hp);
  });
  it("counts working mounted guns, with no phantom attack from an unarmed hull", () => {
    const game = sea(),
      hull = game.spawnUnit("player", "transport", 900, 900),
      fighter = game.spawnUnit("player", "warship", 1300, 900);
    expect(combatCapability(snapshotGame(game), hull)).toEqual({
      armed: false,
      range: 0,
      dps: 0,
    });
    const gun = installedWeapons(game, fighter)[0]!,
      dps = combatCapability(snapshotGame(game), fighter).dps;
    game.items.push({ ...gun, id: "second", mountId: "port0" });
    expect(combatCapability(snapshotGame(game), fighter).dps).toBe(dps * 2);
    gun.durability = 0;
    expect(combatCapability(snapshotGame(game), fighter).dps).toBe(dps);
  });
  it("gathers separated ships, launches together and does not restart on every command", () => {
    const game = sea(),
      fleet = [900, 1700, 2500].map((x) =>
        game.spawnUnit("player", "warship", x, 900),
      );
    const memory = {},
      goal = { x: 3000, y: 3000 };
    const stations = fleetStations(snapshotGame(game), fleet, goal, memory);
    expect(stations.size).toBe(3);
    expect(
      new Set([...stations.values()].map((p) => `${p.x},${p.y}`)).size,
    ).toBe(3);
    const state = memory as import("../memory").NavalPlanMemory;
    expect(state.muster?.launched).toBe(false);
    for (const ship of fleet) {
      ship.x = 1700;
      ship.y = 900;
    }
    game.tick += seconds(5);
    fleetStations(snapshotGame(game), fleet, goal, state);
    expect(state.muster?.launched).toBe(true);
    expect(state.muster?.sinceTick).toBe(0);
  });
});
