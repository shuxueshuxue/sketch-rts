import { describe, expect, it } from "vitest";
import { applySelectionClick, applySelectionPick, selectInScreenBox, selectNearbySameKindUnits } from "./selection-controls";
import { unitAt, unitPointerPosition } from "./relations";
import { syncFrontendWorldView } from "./frontend-world-view";
import { createGame, snapshotGame } from "../shared/sim";
import { boardUnit, syncDecks } from "../shared/decks";
import type { GameAdapter } from "./game-adapter";
import type { Building, GameSnapshot, PlayerState, Unit } from "../shared/types";

const player: PlayerState = {
  race: "grove",
  gold: 500,
  supplyUsed: 0,
  supplyCap: 10,
  upgrades: { weaponTraining: 0, reinforcedPlating: 0, buildingDurability: 0, speedTraining: 0, rangeTraining: 0, leadership: 0 },
};

describe("selection controls", () => {
  it("box-selects units before buildings when both are inside the rectangle", () => {
    const snapshot = snapshotWith({
      units: [unit("worker-1", 100, 100), unit("archer-1", 130, 110)],
      buildings: [building("barracks-1", 110, 120)],
    });

    const result = selectInScreenBox(snapshot, "player", rect(60, 60, 180, 180), (point) => point, emptySelection(), false);

    expect([...result.selectedIds]).toEqual(["worker-1", "archer-1"]);
    expect(result.focusedSelectionId).toBe("worker-1");
  });

  it("box-selects a crew member at its elevated visible body instead of its ground coordinate", () => {
    const snapshot=snapshotWith({units:[unit("crew",100,180),unit("land",100,180)]});
    const result=selectInScreenBox(snapshot,"player",rect(70,70,130,110),point=>point,emptySelection(),false,unit=>unit.id==="crew"?{x:100,y:90}:unit);
    expect([...result.selectedIds]).toEqual(["crew"]);
  });

  it('keeps sheltered crew out of battlefield box and same-kind selection, including a breached cabin',()=>{
    const hidden={...unit('hidden',100,100,'player','priest'),deck:{shipId:'ship',x:0,y:0},cabin:{shipId:'ship',breached:true as const}};
    const snapshot=snapshotWith({units:[hidden,unit('visible',110,100,'player','priest')]});
    expect([...selectInScreenBox(snapshot,'player',rect(60,60,180,180),point=>point,emptySelection(),false).selectedIds]).toEqual(['visible']);
    expect([...selectNearbySameKindUnits(snapshot,'player','visible',900,emptySelection(),false).selectedIds]).toEqual(['visible']);
  });

  it("box-selects only one building when no units are inside the rectangle", () => {
    const snapshot = snapshotWith({
      buildings: [building("townhall-1", 100, 100, "townHall"), building("barracks-1", 140, 100)],
    });

    const result = selectInScreenBox(snapshot, "player", rect(60, 60, 180, 180), (point) => point, emptySelection(), false);

    expect([...result.selectedIds]).toEqual(["townhall-1"]);
    expect(result.focusedSelectionId).toBe("townhall-1");
  });

  it("shift-adds a picked unit or building into the current selection", () => {
    const previous = { selectedIds: new Set(["worker-1"]), focusedSelectionId: "worker-1" };

    const result = applySelectionPick(previous, ["barracks-1"], true);

    expect([...result.selectedIds]).toEqual(["worker-1", "barracks-1"]);
    expect(result.focusedSelectionId).toBe("barracks-1");
  });

  it("removes just the Shift-clicked unit and keeps the remaining command focus", () => {
    const previous = { selectedIds: new Set(["worker-1", "worker-2", "archer-1"]), focusedSelectionId: "archer-1" };
    const result = applySelectionClick(previous, "worker-2", true);
    expect([...result.selectedIds]).toEqual(["worker-1", "archer-1"]);
    expect(result.focusedSelectionId).toBe("archer-1");
    expect([...previous.selectedIds]).toEqual(["worker-1", "worker-2", "archer-1"]);
  });

  it("moves command focus after removing its unit and clears it after the last removal", () => {
    const previous = { selectedIds: new Set(["worker-1", "archer-1"]), focusedSelectionId: "archer-1" };
    const remaining = applySelectionClick(previous, "archer-1", true);
    expect(remaining.focusedSelectionId).toBe("worker-1");
    const empty = applySelectionClick(remaining, "worker-1", true);
    expect(empty.selectedIds.size).toBe(0);
    expect(empty.focusedSelectionId).toBeUndefined();
  });

  it("adds an unselected Shift-clicked unit and preserves normal replacement on plain clicks", () => {
    const previous = { selectedIds: new Set(["worker-1"]), focusedSelectionId: "worker-1" };
    const added = applySelectionClick(previous, "archer-1", true);
    expect([...added.selectedIds]).toEqual(["worker-1", "archer-1"]);
    expect(added.focusedSelectionId).toBe("archer-1");
    const replaced = applySelectionClick(added, "archer-1", false);
    expect([...replaced.selectedIds]).toEqual(["archer-1"]);
  });

  it("keeps Shift-drag additive when its box includes units already selected", () => {
    const snapshot = snapshotWith({ units: [unit("worker-1", 100, 100), unit("worker-2", 130, 110)] });
    const previous = { selectedIds: new Set(["worker-1", "archer-1"]), focusedSelectionId: "archer-1" };
    const result = selectInScreenBox(snapshot, "player", rect(60, 60, 180, 180), point => point, previous, true);
    expect([...result.selectedIds]).toEqual(["worker-1", "archer-1", "worker-2"]);
  });

  it("deselects the visible deck crew hit instead of its hull and stays deselected on the next frame", () => {
    const game = createGame("bareDuel", { aiPlayers: [] });
    game.units = []; delete game.map.terrain;
    const ship = game.spawnUnit("player", "transport", 800, 800);
    const crew = game.spawnUnit("player", "worker", 800, 800);
    const soldier = game.spawnUnit("player", "footman", 1100, 800);
    expect(boardUnit(ship, crew, game.units)).toBe(true);
    syncDecks(game.units);
    const snapshot = snapshotGame(game);
    const hit = unitAt(snapshot.units, unitPointerPosition(snapshot.units, crew), () => true);
    expect(hit?.id).toBe(crew.id);
    const selected = applySelectionClick({ selectedIds: new Set([ship.id, crew.id, soldier.id]), focusedSelectionId: crew.id }, hit!.id, true);
    const adapter = { currentSnapshot: () => snapshot, updateToRenderTime: () => false } as GameAdapter;
    const normalized = syncFrontendWorldView(adapter, { ...selected, owner: "player", snapshot, selectedCampId: undefined, controlGroups: {} });
    expect([...normalized.selectedIds]).toEqual([ship.id, soldier.id]);
    expect(normalized.focusedSelectionId).toBe(ship.id);
    expect(normalized.selectedIds.has(crew.id)).toBe(false);
  });

  it("double-click selects nearby same-kind friendly units around the clicked unit", () => {
    const snapshot = snapshotWith({
      units: [
        unit("anchor", 1000, 1000, "player", "footman"),
        unit("near-footman", 1300, 1000, "player", "footman"),
        unit("far-footman", 2200, 1000, "player", "footman"),
        unit("near-archer", 1100, 1000, "player", "archer"),
        unit("enemy-footman", 1050, 1000, "enemy", "footman"),
      ],
    });

    const result = selectNearbySameKindUnits(snapshot, "player", "anchor", 900, emptySelection(), false);

    expect([...result.selectedIds]).toEqual(["anchor", "near-footman"]);
    expect(result.focusedSelectionId).toBe("anchor");
  });
});

function emptySelection() {
  return { selectedIds: new Set<string>(), focusedSelectionId: undefined };
}

function rect(left: number, top: number, right: number, bottom: number) {
  return { left, top, right, bottom };
}

function snapshotWith(input: { units?: Unit[]; buildings?: Building[] }): GameSnapshot {
  return {
    tick: 0,
    map: { id: "bareDuel", name: "Bare Duel", width: 4096, height: 4096, landmarks: [] },
    players: { player, enemy: { ...player, race: "ember" }, enemy2: { ...player, race: "ember" } },
    units: input.units ?? [],
    buildings: input.buildings ?? [],
    resources: [],
    mercenaryCamps: [],
    items: [],
    projectiles: [],
    effects: [],
    match: {
      winner: null,
      endedAtTick: null,
      stats: {
        unitsKilled: ownerStats(),
        unitsLost: ownerStats(),
        buildingsDestroyed: playerStats(),
        nonBaseBuildingsDestroyed: playerStats(),
        neutralUnitsKilled: playerStats(),
        unitsKilledByNeutral: playerStats(),
        mercenaryKills: playerStats(),
        goldSpent: playerStats(),
      },
    },
  };
}

function ownerStats() {
  return { player: 0, enemy: 0, enemy2: 0, neutral: 0 };
}

function playerStats() {
  return { player: 0, enemy: 0, enemy2: 0 };
}

function unit(id: string, x: number, y: number, owner: Unit["owner"] = "player", kind: Unit["kind"] = "worker"): Unit {
  return {
    id,
    owner,
    kind,
    x,
    y,
    hp: 100,
    maxHp: 100,
    speed: 3,
    attackDamage: 10,
    attackRange: 50,
    attackCooldown: 10,
    cooldown: 0,
    radius: 15,
    carryingGold: 0,
    kills: 0,
    xp: 0,
    level: 0,
    effects: [],
    order: { type: "idle" },
  };
}

function building(id: string, x: number, y: number, kind: Building["kind"] = "barracks"): Building {
  return {
    id,
    owner: "player",
    kind,
    x,
    y,
    hp: 100,
    maxHp: 100,
    radius: 30,
    buildProgress: 1,
    buildTime: 1,
    complete: true,
    attackDamage: 0,
    attackRange: 0,
    attackCooldown: 1,
    cooldown: 0,
    rallyX: x,
    rallyY: y,
    queue: [],
    researchQueue: [],
  };
}
