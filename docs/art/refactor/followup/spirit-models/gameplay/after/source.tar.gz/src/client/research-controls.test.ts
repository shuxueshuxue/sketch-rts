import { describe, expect, it } from "vitest";
import { researchCommandButtonsForSelection, researchProgressButtonsForSelection } from "./research-controls";
import type { Building, PlayerState } from "../shared/types";

const barracks: Building = {
  id: "barracks-1",
  owner: "player",
  kind: "barracks",
  x: 0,
  y: 0,
  hp: 620,
  maxHp: 620,
  radius: 40,
  complete: true,
  buildProgress: 0,
  buildTime: 0,
  attackDamage: 0,
  attackRange: 0,
  attackCooldown: 1,
  cooldown: 0,
  rallyX: 0,
  rallyY: 0,
  queue: [],
  researchQueue: [],
};

const townHall: Building = {
  ...barracks,
  id: "townhall-1",
  kind: "townHall",
  hp: 900,
  maxHp: 900,
};

const stables: Building = {
  ...barracks,
  id: "stables-1",
  kind: "stables",
  hp: 560,
  maxHp: 560,
};

const sanctum: Building = {
  ...barracks,
  id: "sanctum-1",
  kind: "sanctum",
  hp: 500,
  maxHp: 500,
};

const workshop: Building = {
  ...barracks,
  id: "workshop-1",
  kind: "workshop",
  hp: 580,
  maxHp: 580,
};

const player: PlayerState = {
  race: "grove",
  gold: 500,
  supplyUsed: 3,
  supplyCap: 10,
  upgrades: { weaponTraining: 0, reinforcedPlating: 0, buildingDurability: 0, speedTraining: 0, rangeTraining: 0, leadership: 0 },
};

const emberForge: Building = {
  ...barracks,
  id: "ember-forge-1",
  kind: "emberForge",
  hp: 560,
  maxHp: 560,
};

const cinderSpire: Building = {
  ...barracks,
  id: "cinder-spire-1",
  kind: "cinderSpire",
  hp: 500,
  maxHp: 500,
};

const emberPlayer: PlayerState = {
  ...player,
  race: "ember",
};

describe("research controls", () => {
  it("uses the race/building production graph for mixed captured building selections",()=>{
    expect(researchCommandButtonsForSelection([cinderSpire],player)).toEqual([]);
    expect(researchCommandButtonsForSelection([sanctum],emberPlayer)).toEqual([]);
    expect(researchCommandButtonsForSelection([cinderSpire,sanctum],player).find(command=>command.upgradeKind==='leadership')?.buildingId).toBe(sanctum.id);
    expect(researchCommandButtonsForSelection([sanctum,cinderSpire],emberPlayer).find(command=>command.upgradeKind==='leadership')?.buildingId).toBe(cinderSpire.id);
  });
  it("shows research buttons for an eligible selected barracks", () => {
    const commands = researchCommandButtonsForSelection([barracks], player);

    expect(commands).toEqual([
      { label: "Weapon Training", icon: "⚔", hotkey: "w", upgradeKind: "weaponTraining", buildingId: "barracks-1" },
      { label: "Reinforced Plating", icon: "▣", hotkey: "p", upgradeKind: "reinforcedPlating", buildingId: "barracks-1" },
    ]);
  });

  it("shows shared combat research buttons for an eligible selected ember forge", () => {
    const commands = researchCommandButtonsForSelection([emberForge], emberPlayer);

    expect(commands).toEqual([
      { label: "Weapon Training", icon: "⚔", hotkey: "w", upgradeKind: "weaponTraining", buildingId: "ember-forge-1" },
      { label: "Reinforced Plating", icon: "▣", hotkey: "p", upgradeKind: "reinforcedPlating", buildingId: "ember-forge-1" },
    ]);
  });

  it("shows building durability for an eligible selected town hall", () => {
    const commands = researchCommandButtonsForSelection([townHall], player);

    expect(commands).toEqual([
      { label: "Building Durability", icon: "▥", hotkey: "d", upgradeKind: "buildingDurability", buildingId: "townhall-1" },
    ]);
  });

  it("shows late grove research on the late production buildings", () => {
    const commands = researchCommandButtonsForSelection([stables, sanctum, workshop], player);

    expect(commands).toEqual([
      { label: "Mobility Training", icon: "↟", hotkey: "m", upgradeKind: "speedTraining", buildingId: "stables-1" },
      { label: "Range Training", icon: "⌖", hotkey: "r", upgradeKind: "rangeTraining", buildingId: "workshop-1" },
      { label: "Leadership", icon: "★", hotkey: "l", upgradeKind: "leadership", buildingId: "sanctum-1" },
    ]);
  });

  it("shows late ember research on the cinder spire", () => {
    const commands = researchCommandButtonsForSelection([cinderSpire], emberPlayer);

    expect(commands).toEqual([
      { label: "Mobility Training", icon: "↟", hotkey: "m", upgradeKind: "speedTraining", buildingId: "cinder-spire-1" },
      { label: "Range Training", icon: "⌖", hotkey: "r", upgradeKind: "rangeTraining", buildingId: "cinder-spire-1" },
      { label: "Leadership", icon: "★", hotkey: "l", upgradeKind: "leadership", buildingId: "cinder-spire-1" },
    ]);
  });

  it("keeps selected building research visible as progress buttons", () => {
    const commands = researchProgressButtonsForSelection([
      {
        ...barracks,
        researchQueue: [
          { upgradeKind: "weaponTraining", targetLevel: 1, remaining: 100 },
          { upgradeKind: "reinforcedPlating", targetLevel: 1, remaining: 810 },
        ],
      },
    ], player);

    expect(commands[0]).toMatchObject({
      label: "Weapon Training",
      upgradeKind: "weaponTraining",
      buildingId: "barracks-1",
      targetLevel: 1,
      status: "researching",
    });
    expect(commands[0]?.progress).toBeGreaterThan(0);
    expect(commands[1]).toMatchObject({
      label: "Reinforced Plating",
      upgradeKind: "reinforcedPlating",
      status: "queued",
      progress: 0,
    });
  });
});
