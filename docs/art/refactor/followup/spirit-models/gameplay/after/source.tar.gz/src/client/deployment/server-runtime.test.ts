import { RULES_VERSION } from "../../shared/rules-version";
import { describe, expect, it } from "vitest";
import type { ClientNetMessage, ServerNetMessage } from "../../shared/net/types";
import { decodeServerNetMessage, encodeNetMessage } from "../../shared/net/codec";
import { createRoomHost } from "../../server/room-host";
import { RoomNetHub, type RoomNetSocket } from "../../server/room-net";
import { createRoom, updateRoomSlot } from "../../shared/rooms";
import type { NetTransport } from "../net/transport";
import { ServerDeploymentRuntime, createRoomWebSocketUrl } from "./server-runtime";

describe("server deployment runtime", () => {
  it("boots server deployment without opening a global session gameplay socket", () => {
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => new FakeTransport(),
    });

    const adapter = runtime.initialAdapter();

    expect(adapter.currentSnapshot()).toBeUndefined();
    expect(() => adapter.sendCommand({ type: "move", unitIds: ["worker"], x: 10, y: 20 })).toThrow("No active match");
  });

  it("uses existing room API paths for room setup", async () => {
    const calls: { path: string; body?: unknown }[] = [];
    const runtime = new ServerDeploymentRuntime({
      publicBasePath: "/",
      fetchJson: async <T>(path: string, body?: unknown) => {
        calls.push({ path, body });
        return { id: "room-1", slots: [] } as T;
      },
      createRoomTransport: () => new FakeTransport(),
    });

    await runtime.listRooms("user-1");
    await runtime.createRoom({ id: "room-1", host: { id: "user-1", name: "User" } });
    await runtime.updateRoomMap("room-1", "bareDuel");

    expect(calls.map((call) => call.path)).toEqual(["/api/rooms?userId=user-1", "/api/rooms", "/api/rooms/room-1/map"]);
  });

  it("routes room API and websocket URLs through the deployment base path", async () => {
    const calls: { path: string; body?: unknown }[] = [];
    const runtime = new ServerDeploymentRuntime({
      publicBasePath: "/sketch-rts/",
      fetchJson: async <T>(path: string, body?: unknown) => {
        calls.push({ path, body });
        return { id: "room-1", slots: [] } as T;
      },
      createRoomTransport: () => new FakeTransport(),
    });

    await runtime.listRooms("user-1");
    await runtime.createRoom({ id: "room-1", host: { id: "user-1", name: "User" } });

    expect(calls.map((call) => call.path)).toEqual(["/sketch-rts/api/rooms?userId=user-1", "/sketch-rts/api/rooms"]);
    expect(createRoomWebSocketUrl("/sketch-rts/", "room 1", { protocol: "https:", host: "lexicalmathical.com" })).toBe("wss://lexicalmathical.com/sketch-rts/ws/rooms/room%201");
  });

  it("watches pre-match room lifecycle updates through the deployment base path", () => {
    const sources: FakeRoomEventSource[] = [];
    const host = { id: "host", name: "Host" };
    const room = createRoom({ id: "room watch", host, humanCount: 2, aiCount: 0 });
    const joined = updateRoomSlot(room, "slot-2", { controller: "human", userId: "guest", name: "Guest", ready: true });
    const runtime = new ServerDeploymentRuntime({
      publicBasePath: "/sketch-rts/",
      createRoomEventSource: (path) => {
        const source = new FakeRoomEventSource(path);
        sources.push(source);
        return source;
      },
    });
    const updates: string[] = [];

    const unsubscribe = runtime.watchRoom(room.id, (nextRoom) => updates.push(nextRoom.slots.map((slot) => slot.name).join(",")));
    sources[0]!.emit(joined);
    unsubscribe();

    expect(sources[0]!.path).toBe("/sketch-rts/api/rooms/room%20watch/events");
    expect(updates).toEqual(["Host,Guest"]);
    expect(sources[0]!.closed).toBe(true);
  });

  it("starts as the slot owned by the current user", async () => {
    const host = { id: "host", name: "Host" };
    const guest = { id: "guest", name: "Guest" };
    const open = createRoom({ id: "room-2", host, humanCount: 2, aiCount: 1 });
    const joined = updateRoomSlot(open, "slot-2", { controller: "human", userId: guest.id, name: guest.name, ready: true });
    const startedRoom = { ...joined, status: "inMatch" as const };
    const transport = new FakeTransport();
    const runtime = new ServerDeploymentRuntime({
      fetchJson: async <T>() => startedRoom as T,
      createRoomTransport: () => transport,
    });

    const started = await runtime.startRoom(startedRoom.id, guest);

    expect(started.playerId).toBe("enemy");
  });

  it("creates the lockstep client game from the room setup teams and races", () => {
    const host = { id: "host", name: "Host" };
    const open = createRoom({ id: "room-teams", host, mapId: "bareDuel", humanCount: 1, aiCount: 2 });
    const northAlly = updateRoomSlot(open, "slot-2", { team: "north", race: "grove" });
    const southEnemy = updateRoomSlot(northAlly, "slot-3", { team: "south", race: "grove" });
    const startedRoom = { ...southEnemy, status: "inMatch" as const };
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => new FakeTransport(),
    });

    const started = runtime.connectRoom(startedRoom, "player", false, () => {});

    expect(started.snapshot.players.enemy?.race).toBe("grove");
    expect(started.snapshot.players.enemy2?.race).toBe("grove");
  });

  it("connects spectators through the same room lockstep adapter without command authority", () => {
    const host = { id: "host", name: "Host" };
    const open = createRoom({ id: "room-spectator", host, mapId: "bareDuel", humanCount: 1, aiCount: 1 });
    const startedRoom = { ...open, status: "inMatch" as const };
    const transport = new FakeTransport();
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => transport,
    });

    const started = runtime.connectRoom(startedRoom, "spectator-viewer", true, () => {});

    expect(transport.sent).toEqual([{ type: "join", rulesVersion: RULES_VERSION, roomId: startedRoom.id, playerId: "spectator-viewer" }]);
    transport.emit({ type: "hello", rulesVersion: RULES_VERSION, roomId: startedRoom.id, playerId: "spectator-viewer", tick: 28, epoch: 3 });
    expect(transport.sent).toContainEqual(expect.objectContaining({ type: "requestCheckpoint", roomId: startedRoom.id, playerId: "spectator-viewer", reason: "initial-sync", clientTick: 0, epoch: 3 }));
    expect(() => started.adapter.sendCommand({ type: "move", unitIds: ["worker"], x: 10, y: 20 })).toThrow("Spectators cannot issue commands");
  });

  it("reconnects to an advanced replacement match after learning the real server epoch", () => {
    const host = { id: "host", name: "Host" };
    const roomHost = createRoomHost({ autoTick: false });
    const room = roomHost.createRoom({ id: "room-reconnect-replacement", host, mapId: "pineshade", humanCount: 1, aiCount: 1 });
    roomHost.startRoom(room.id);
    const hub = new RoomNetHub({ roomHost });
    // Subscribe before replacement so the real hub advances its epoch, as an existing match socket does.
    hub.connect(room.id, { send() {}, on() {} });
    roomHost.resetRoom(room.id, "bareDuel", {
      aiPlayers: [],
      scenario: { addBuildings: [{ id: "reconnect-research-barracks", owner: "player", kind: "barracks", x: 1200, y: 976, complete: true }] },
    });
    roomHost.tickRoom(room.id, 13);
    const transport = new HubTransport(hub, room.id);
    const runtime = new ServerDeploymentRuntime({ createRoomTransport: () => transport });
    const started = runtime.connectRoom(roomHost.getRoom(room.id), "player", false, () => {});

    expect(started.snapshot.tick).toBe(0);
    expect(started.snapshot.buildings.some(building => building.id === "reconnect-research-barracks")).toBe(false);
    transport.deliverServerMessages();

    expect(started.adapter.currentSnapshot()).toEqual(roomHost.snapshot(room.id));
    expect(started.adapter.currentSnapshot()?.buildings.some(building => building.id === "reconnect-research-barracks")).toBe(true);
    expect(transport.sent).toContainEqual(expect.objectContaining({ type: "requestCheckpoint", reason: "initial-sync", epoch: 1 }));
    expect(hub.syncSummaryForRoom(room.id).checkpointRequests.initial).toBe(1);
    expect(hub.syncSummaryForRoom(room.id).byKind["checkpoint-restore"]).toBe(1);
  });

  it("surfaces lockstep room command errors through the runtime error callback", () => {
    const host = { id: "host", name: "Host" };
    const open = createRoom({ id: "room-errors", host, mapId: "bareDuel", humanCount: 1, aiCount: 1 });
    const startedRoom = { ...open, status: "inMatch" as const };
    const transport = new FakeTransport();
    const errors: string[] = [];
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => transport,
      onRuntimeError: (message) => errors.push(message),
    });

    runtime.connectRoom(startedRoom, "player", false, () => {});
    transport.emit({ type: "error", roomId: startedRoom.id, message: "farm placement is too close to townHall" });

    expect(errors).toEqual(["farm placement is too close to townHall"]);
  });

  it("sends match commands through the room lockstep transport without local sim mutation", () => {
    const host = { id: "host", name: "Host" };
    const open = createRoom({ id: "room-lockstep-command", host, mapId: "bareDuel", humanCount: 1, aiCount: 1 });
    const startedRoom = { ...open, status: "inMatch" as const };
    const transport = new FakeTransport();
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => transport,
    });
    const started = runtime.connectRoom(startedRoom, "player", false, () => {});
    const worker = started.snapshot.units.find((unit) => unit.owner === "player" && unit.kind === "worker");
    expect(worker).toBeDefined();

    const command = { type: "move" as const, unitIds: [worker!.id], x: worker!.x + 120, y: worker!.y };
    started.adapter.sendCommand(command);

    const localSnapshot = started.adapter.currentSnapshot();
    expect(localSnapshot).toBeDefined();
    expect(localSnapshot?.tick).toBe(0);
    expect(localSnapshot?.units.find((unit) => unit.id === worker!.id)?.order).toEqual({ type: "idle" });
    expect(transport.sent).toContainEqual({ type: "command", roomId: startedRoom.id, playerId: "player", clientSeq: 0, command, epoch: 0 });
  });

  it("routes public chat through the room transport without using match commands", () => {
    const host = { id: "host", name: "Host" };
    const open = createRoom({ id: "room-chat", host, mapId: "bareDuel", humanCount: 1, aiCount: 1 });
    const startedRoom = { ...open, status: "inMatch" as const };
    const transport = new FakeTransport();
    const runtime = new ServerDeploymentRuntime({
      createRoomTransport: () => transport,
    });
    const started = runtime.connectRoom(startedRoom, "player", false, () => {});
    const received: string[] = [];
    started.chat.onMessage((message) => received.push(`${message.senderName}: ${message.text}`));

    started.chat.send(" push mid ", "Ada");
    transport.emit({ type: "chat", message: { id: "chat-room-chat-1", roomId: startedRoom.id, playerId: "player", senderName: "Ada", text: "push mid", sentAt: 1200 } });

    expect(transport.sent).toContainEqual({ type: "chat", roomId: startedRoom.id, playerId: "player", senderName: "Ada", text: "push mid" });
    expect(transport.sent.some((message) => message.type === "command")).toBe(false);
    expect(received).toEqual(["Ada: push mid"]);
  });
});

class FakeTransport implements NetTransport {
  sent: ClientNetMessage[] = [];
  private handlers: ((message: ServerNetMessage) => void)[] = [];

  send(message: ClientNetMessage): void {
    this.sent.push(message);
  }
  onMessage(handler: (message: ServerNetMessage) => void): void {
    this.handlers.push(handler);
  }
  close(): void {}
  emit(message: ServerNetMessage): void {
    for (const handler of this.handlers) handler(message);
  }
}

class FakeRoomEventSource {
  closed = false;
  private handlers: ((event: { data: string }) => void)[] = [];

  constructor(readonly path: string) {}

  addEventListener(type: "message" | "error", handler: (event: { data: string }) => void): void {
    if (type === "message") this.handlers.push(handler);
  }

  close(): void {
    this.closed = true;
  }

  emit(room: unknown): void {
    for (const handler of this.handlers) handler({ data: JSON.stringify(room) });
  }
}

/** Queue actual hub packets until the next event turn, preserving the browser socket's handshake ordering. */
class HubTransport implements NetTransport {
  readonly sent: ClientNetMessage[] = [];
  private readonly messages: ServerNetMessage[] = [];
  private readonly handlers: ((message: ServerNetMessage) => void)[] = [];
  private receive: ((raw: string) => void) | undefined;

  constructor(hub: RoomNetHub, roomId: string) {
    const socket: RoomNetSocket = {
      send: raw => { this.messages.push(decodeServerNetMessage(raw)); },
      on: (event, handler) => { if (event === "message") this.receive = handler as (raw: string) => void; },
    };
    hub.connect(roomId, socket);
  }

  send(message: ClientNetMessage) { this.sent.push(message); this.receive?.(encodeNetMessage(message)); }
  onMessage(handler: (message: ServerNetMessage) => void) { this.handlers.push(handler); }
  close() {}
  deliverServerMessages() {
    let message: ServerNetMessage | undefined;
    while ((message = this.messages.shift())) for (const handler of this.handlers) handler(message);
  }
}
