import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
import type {GameSnapshot} from '../shared/types';
import type {WorldFrame} from './world-renderer';

const mocks=vi.hoisted(()=>({
  warm:vi.fn(async(_key:string,_phase:string)=>{}),image:vi.fn(async(_key:string,_phase:string)=>{}),draw:vi.fn(),
  panel:{renderer:'',preparing:vi.fn()},
  layer:{prepare:vi.fn(async()=>{}),prepareRemains:vi.fn(),reset:vi.fn(),dispose:vi.fn(),draw:vi.fn(),pick:vi.fn(),positions:new Map()},
  create:vi.fn(),
}));
vi.mock('./resources',()=>({resources:{warm:mocks.warm},resourceText:(_zh:string,en:string)=>en}));
vi.mock('./world3d/model-library',()=>({worldModels:{prepare:async(keys:string[],phase:string)=>Promise.all(keys.map(key=>mocks.image(key,phase)))},matchModelKeys:['ships/warship','buildings/farm'],snapshotModelKeys:(scene:GameSnapshot)=>scene.buildings.map(building=>`buildings/${building.kind}`)}));
vi.mock('./world3d/model-portraits',()=>({activateModelPortraits:vi.fn()}));
vi.mock('./resource-panel',()=>({resourcePanel:()=>mocks.panel}));
vi.mock('./world-renderer',()=>({drawWorld:mocks.draw}));
vi.mock('./world3d/world-layer',()=>({World3DLayer:{create:mocks.create},PHYSICAL_EFFECTS:new Set()}));
import {WorldPresentation} from './world-presentation';

const context2d={setTransform(){},clearRect(){},save(){},restore(){}};
class Element extends EventTarget {
  className='';hidden=false;width=800;height=600;children:Element[]=[];
  context:WebGL2RenderingContext|null={} as WebGL2RenderingContext;
  append(...children:Element[]){this.children.push(...children);}
  before(){}
  remove(){}
  getContext(kind:string){return kind==='2d'?context2d:this.context;}
}
let elements:Element[];
beforeEach(()=>{
  vi.clearAllMocks();mocks.panel.renderer='';
  mocks.warm.mockImplementation(async()=>{});mocks.image.mockImplementation(async()=>{});
  mocks.layer.prepare.mockImplementation(async()=>{});mocks.layer.draw.mockImplementation(()=>{});
  mocks.create.mockImplementation(()=>mocks.layer);
  elements=[];
  vi.stubGlobal('document',{createElement:()=>{const element=new Element();elements.push(element);return element;}});
  vi.stubGlobal('devicePixelRatio',1);
});
afterEach(()=>vi.unstubAllGlobals());
function snapshot(kind:'farm'|'barracks'='farm'){
  return{tick:0,units:[],buildings:[{id:kind,kind}],shops:[],mercenaryCamps:[]} as unknown as GameSnapshot;
}
function frame(scene:GameSnapshot):WorldFrame{
  return{snapshot:scene,view:{x:0,y:0,width:800,height:600},ctx:context2d,now:0} as unknown as WorldFrame;
}
function actors(){return elements.find(element=>element.className==='world-actors')!;}
function lose(){const event=new Event('webglcontextlost',{cancelable:true});actors().dispatchEvent(event);expect(event.defaultPrevented).toBe(true);}

describe('current scene graphics recovery (GPU mocked)',()=>{
  it('prepares finite home remains after reset and preserves the recipe through current-scene graphics recovery',async()=>{
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const artPreparation={corpses:[{id:'future-remains',unitId:'future-unit',kind:'footman' as const,owner:'player',x:0,y:0,radius:18,diedAtTick:60,deck:{shipId:'ship',x:0,y:0}}],models:()=>undefined};
    const initial=snapshot();
    await presentation.prepare(initial,'home',[],artPreparation);
    expect(mocks.layer.prepareRemains).toHaveBeenCalledWith(initial,artPreparation);
    expect(mocks.layer.reset.mock.invocationCallOrder[0]).toBeLessThan(mocks.layer.prepareRemains.mock.invocationCallOrder[0]!);
    const current=snapshot('barracks');presentation.draw(frame(current),'home');
    lose();actors().dispatchEvent(new Event('webglcontextrestored'));
    await vi.waitFor(()=>expect(presentation.is3D).toBe(true));
    expect(mocks.layer.prepareRemains).toHaveBeenLastCalledWith(current,artPreparation);
    expect(mocks.layer.prepareRemains).toHaveBeenCalledTimes(2);
    await presentation.prepare(snapshot(),'match',[],artPreparation);
    expect(mocks.layer.prepareRemains).toHaveBeenCalledTimes(2);
  });
  it('never prepaints future remains from an obsolete preparation',async()=>{
    let release!:()=>void;
    mocks.layer.prepare.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const stale={corpses:[]};
    const old=presentation.prepare(snapshot(),'home',[],stale);
    await vi.waitFor(()=>expect(mocks.layer.prepare).toHaveBeenCalledOnce());
    await presentation.prepare(snapshot('barracks'),'home');
    release();await old;
    expect(mocks.layer.prepareRemains).not.toHaveBeenCalled();expect(presentation.is3D).toBe(true);
  });
  it('warms only current home scenery after context loss, then restores the latest scene instead of the initial scene',async()=>{
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    await presentation.prepare(snapshot(),'home');
    const current=snapshot('barracks');presentation.draw(frame(current),'home');
    mocks.image.mockClear();lose();
    await vi.waitFor(()=>expect(mocks.image).toHaveBeenCalledWith('buildings/barracks','home'));
    expect(mocks.image).not.toHaveBeenCalledWith('buildings/farm','home');
    expect(mocks.image.mock.calls.every(call=>call[1]==='home')).toBe(true);
    expect(presentation.is3D).toBe(false);
    actors().dispatchEvent(new Event('webglcontextrestored'));
    await vi.waitFor(()=>expect(presentation.is3D).toBe(true));
    expect(mocks.layer.prepare).toHaveBeenLastCalledWith(current,'home',[]);
    expect(mocks.create).toHaveBeenCalledTimes(1);
  });
  it('tracks the home phase when returning from a match and prepares current architecture overrides for Canvas',async()=>{
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    await presentation.prepare(snapshot(),'match');
    const home:WorldFrame={...frame(snapshot('barracks')),buildingModels:{barracks:'citadel'}};
    presentation.draw(home,'home');mocks.image.mockClear();lose();
    await vi.waitFor(()=>expect(mocks.image).toHaveBeenCalledWith('buildings/citadel','home'));
    expect(mocks.image.mock.calls.every(call=>call[1]==='home')).toBe(true);
    expect(mocks.image).not.toHaveBeenCalledWith('portraits/warship','match');
  });
  it('keeps a failed draw on Canvas across scene preparation until the graphics context is restored',async()=>{
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    await presentation.prepare(snapshot(),'home');
    const error=vi.spyOn(console,'error').mockImplementation(()=>{});
    mocks.layer.draw.mockImplementationOnce(()=>{throw new Error('GPU lost');});
    presentation.draw(frame(snapshot('barracks')),'home');
    await presentation.prepare(snapshot(),'home');
    expect(presentation.is3D).toBe(false);expect(mocks.layer.prepare).toHaveBeenCalledTimes(1);
    expect(mocks.draw).toHaveBeenCalled();
    expect(mocks.image.mock.calls.every(call=>call[1]==='home')).toBe(true);error.mockRestore();
  });
  it('shares asynchronous GPU initialization and never activates an obsolete preparation',async()=>{
    let release!:()=>void;
    mocks.warm.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const old=presentation.prepare(snapshot(),'home'),current=snapshot('barracks');
    const latest=presentation.prepare(current,'home');release();await Promise.all([old,latest]);
    expect(mocks.create).toHaveBeenCalledTimes(1);
    expect(mocks.layer.prepare).toHaveBeenCalledTimes(1);
    expect(mocks.layer.prepare).toHaveBeenCalledWith(current,'home',[]);
    expect(presentation.is3D).toBe(true);
  });
  it('does not let in-flight model preparation reactivate a lost context',async()=>{
    let release!:()=>void;
    mocks.layer.prepare.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const work=presentation.prepare(snapshot(),'home');
    await vi.waitFor(()=>expect(mocks.layer.prepare).toHaveBeenCalledTimes(1));
    lose();release();await work;
    expect(presentation.is3D).toBe(false);expect(mocks.layer.reset).not.toHaveBeenCalled();
    expect(mocks.image.mock.calls.every(call=>call[1]==='home')).toBe(true);
  });
  it('does not reset or replace the active scene when older model preparation finishes later',async()=>{
    let release!:()=>void;
    mocks.layer.prepare.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const old=presentation.prepare(snapshot(),'home');
    await vi.waitFor(()=>expect(mocks.layer.prepare).toHaveBeenCalledTimes(1));
    await presentation.prepare(snapshot('barracks'),'home');
    expect(presentation.is3D).toBe(true);expect(mocks.layer.reset).toHaveBeenCalledTimes(1);
    release();await old;expect(presentation.is3D).toBe(true);expect(mocks.layer.reset).toHaveBeenCalledTimes(1);
  });
  it('does not create a renderer after disposal during asynchronous initialization',async()=>{
    let release!:()=>void;mocks.warm.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const work=presentation.prepare(snapshot(),'home');presentation.dispose();release();await work;
    expect(mocks.create).not.toHaveBeenCalled();expect(presentation.is3D).toBe(false);
    expect(elements.find(element=>element.className==='world-ground')!.width).toBe(0);
    expect(actors().width).toBe(0);
  });
  it('releases a prepared layer and its context listeners even if model preparation is pending',async()=>{
    let release!:()=>void;mocks.layer.prepare.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const work=presentation.prepare(snapshot(),'home');
    await vi.waitFor(()=>expect(mocks.layer.prepare).toHaveBeenCalledOnce());
    const remove=vi.spyOn(elements.find(element=>element.className==='world-underlay')!,'remove');
    presentation.dispose();presentation.dispose();release();await work;
    expect(mocks.layer.dispose).toHaveBeenCalledOnce();expect(mocks.layer.reset).not.toHaveBeenCalled();expect(remove).toHaveBeenCalledOnce();
    const lost=new Event('webglcontextlost',{cancelable:true});actors().dispatchEvent(lost);actors().dispatchEvent(new Event('webglcontextrestored'));
    expect(lost.defaultPrevented).toBe(false);
    await presentation.prepare(snapshot(),'home');presentation.draw(frame(snapshot()));
    expect(mocks.layer.draw).not.toHaveBeenCalled();expect(mocks.draw).not.toHaveBeenCalled();expect(presentation.is3D).toBe(false);
  });
  it('releases the old scene at reset rather than retaining it for later context recovery',async()=>{
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    await presentation.prepare(snapshot('barracks'),'home');mocks.image.mockClear();presentation.reset();lose();
    await Promise.resolve();expect(mocks.image).not.toHaveBeenCalled();
  });
  it('invalidates pending scene preparation when resetting to another world',async()=>{
    let release!:()=>void;mocks.layer.prepare.mockImplementationOnce(()=>new Promise<void>(resolve=>{release=resolve;}));
    const presentation=new WorldPresentation(new Element() as unknown as HTMLCanvasElement);
    const work=presentation.prepare(snapshot(),'home');await vi.waitFor(()=>expect(mocks.layer.prepare).toHaveBeenCalledOnce());
    presentation.reset();release();await work;
    expect(presentation.is3D).toBe(false);expect(mocks.layer.reset).toHaveBeenCalledOnce();
  });
});
