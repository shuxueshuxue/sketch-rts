/** Public, unmodified production homepage visual acceptance. No Vite/source hooks. */
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { dirname, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ownFile = fileURLToPath(import.meta.url);
const arg = name => { const i = process.argv.indexOf('--' + name); return i < 0 ? undefined : process.argv[i + 1]; };
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const scenarios = {
  fleet: { length: 60, name: /海盗夺船|Pirate Boarding/, phases: [[2.6,'broadside'],[9,'hits'],[13,'repair'],[25,'gangway'],[32,'boarding'],[38,'melee'],[47,'capture']] },
  capital: { length: 90, name: /王城|The Capital/, phases: [[2,'early-street'],[45,'middle-street'],[80,'late-street']] },
  woods: { length: 52, name: /林间血战|Army and Wild Horde/, phases: [[6.1,'army-approach'],[13.5,'contact'],[16.7,'horde-clash'],[31.8,'late-fight']] },
};
const sizes = { desktop: [1440,900], mobile: [390,844] };
const list = (name, fallback, known) => {
  const values = (arg(name) ?? fallback).split(',');
  if (!values.length || values.some(value => !known.includes(value)) || new Set(values).size !== values.length) throw new Error('Invalid --' + name);
  return values;
};
const url = new URL(arg('url') ?? 'https://lexicalmathical.com/sketch-rts/');
if (url.protocol !== 'https:') throw new Error('Public acceptance requires HTTPS');
const mainSha = arg('main-sha');
if (!/^[0-9a-f]{40}$/.test(mainSha ?? '')) throw new Error('--main-sha requires the final full Git SHA');
if (!arg('out')) throw new Error('--out requires a fresh evidence directory');
const output = resolve(arg('out'));
const toolRoot = resolve(arg('tool-root') ?? '/workspace/sketch-rts-homepage-board');
const require = createRequire(resolve(toolRoot, 'package.json'));
const WebSocket = require('ws');
const selectedScenes = list('scenes', 'fleet,capital,woods', Object.keys(scenarios));
const selectedSizes = list('sizes', 'desktop,mobile', Object.keys(sizes));
const modes = list('modes', 'normal,reduced', ['normal','reduced']);
const distRoot = arg('dist-root') && resolve(arg('dist-root'));
const reducedLate = arg('reduced-late') === undefined ? null : Number(arg('reduced-late'));
if (reducedLate !== null && (!Number.isFinite(reducedLate) || reducedLate < 95 || reducedLate > 360)) throw new Error('--reduced-late must be 95..360 seconds, e.g. 300');
const skipUi = arg('skip-ui') === 'true';
const fullMobile = arg('full-mobile') === 'true';
const expected = {};
async function collectDist(directory, prefix = '') {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const file = prefix + entry.name, path = resolve(directory, entry.name);
    if (entry.isDirectory()) await collectDist(path, file + '/');
    else if (entry.isFile()) { const bytes = await readFile(path); expected[file] = { bytes: bytes.length, sha256: sha(bytes) }; }
  }
}
if (distRoot) await collectDist(distRoot);
await mkdir(output); // Preserve every prior attempt; no overwrite/resume.
const toolBytes = await readFile(ownFile), toolSha256 = sha(toolBytes);
await writeFile(resolve(output, 'executed-tool.mjs'), toolBytes);
const method = {
  publicBundle: 'Unmodified HTTPS production responses; no module rewriting, clock seeks, virtual time or renderer debug interfaces.',
  timing: 'Natural performance.now time from first visible ready home composition. This follows resource preparation and may trail startPresentation by one paint; requested seconds are phase hints, not exact simulation tick evidence.',
  gpu: 'Existing world-actors WebGL2 context fenceSync/flush/clientWaitSync; whole-page PNG compositor capture.',
  reduced: 'Media condition applied before navigation. Desktop initial and natural elapsed length+0.2 seconds, or explicit --reduced-late. Mobile initial only unless --full-mobile. Not a performance measurement.',
  limits: ['SwiftShader WebGL2 environment, not hardware FPS.', 'GPU fence completes prior submissions; animation continues normally during fence and screenshot. Capture start/end actual elapsed is recorded.', 'Scene roles/events require actual screenshot review; automated checks do not identify soldiers, workers, flags or tavern artwork.', 'The supplied Git SHA alone cannot prove server revision. Dist response hashes and the root lane server deployment receipt provide version identification.'],
};
const inputs = { utc: new Date().toISOString(), url: url.href, expectedMainSha: mainSha, argv: process.argv, toolSha256, selectedScenes, selectedSizes, modes, reducedLate, skipUi, fullMobile, distRoot, expectedDist: expected, method };
await writeFile(resolve(output, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n');
const results = [], checks = [];
let current;
const check = (name, pass, detail = {}) => { const item = { name, pass: !!pass, ...detail }; checks.push(item); return item; };

const bootstrap = scene => `(() => {
  localStorage.setItem('sketch-rts-menu-scene', ${JSON.stringify(scene)});
  const p = window.__publicHomeProof = { readyNow: null, resourceStates: [], contextEvents: [] };
  const inspect = () => {
    const resource = document.querySelector('.resource-screen'), stack = document.querySelector('.world-underlay');
    const menu = document.querySelector('[data-main-menu]'), shell = document.querySelector('.game-shell');
    const c = document.querySelector('.world-actors');
    if (resource && p.resourceHidden !== resource.hidden) { p.resourceHidden = resource.hidden; p.resourceStates.push({ now: performance.now(), hidden: resource.hidden }); }
    if (p.readyNow === null && resource?.hidden && stack && !stack.hidden && c?.width > 0 && menu?.dataset.menuView === 'home' && !menu.classList.contains('hidden') && shell?.classList.contains('menu-open')) p.readyNow = performance.now();
  };
  new MutationObserver(inspect).observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden','class','data-menu-view','width','height'] });
  document.addEventListener('DOMContentLoaded', inspect, { once: true });
  document.addEventListener('webglcontextlost', e => p.contextEvents.push({ type: e.type, now: performance.now(), canvas: e.target.className }), true);
  document.addEventListener('webglcontextrestored', e => p.contextEvents.push({ type: e.type, now: performance.now(), canvas: e.target.className }), true);
})();`;
const stateExpression = `(() => {
  const p = __publicHomeProof, rect = e => { if (!e) return null; const r = e.getBoundingClientRect(); return { x:r.x,y:r.y,width:r.width,height:r.height }; };
  const canvas = document.querySelector('.game-canvas'), actors = document.querySelector('.world-actors'), stack = document.querySelector('.world-underlay');
  const gl = actors?.getContext('webgl2'), ext = gl?.getExtension('WEBGL_debug_renderer_info');
  return { pageNow:performance.now(), readyNow:p.readyNow, elapsed:p.readyNow===null?null:(performance.now()-p.readyNow)/1000, scene:localStorage.getItem('sketch-rts-menu-scene'), sceneLabel:document.querySelector('[data-scene-switch]')?.textContent.trim(), reduced:matchMedia('(prefers-reduced-motion: reduce)').matches, menuView:document.querySelector('[data-main-menu]')?.dataset.menuView, menu:rect(document.querySelector('.menu-window')), sceneSwitch:rect(document.querySelector('[data-scene-switch]')), buttons:[...document.querySelectorAll('[data-open-create],[data-open-room-browser],[data-open-profile]')].map(e=>({text:e.textContent.trim(),disabled:e.disabled,...rect(e)})), resourceHidden:document.querySelector('.resource-screen')?.hidden, resourceSummary:document.querySelector('.resource-summary')?.textContent, viewport:[innerWidth,innerHeight], dpr:devicePixelRatio, scrollWidth:document.documentElement.scrollWidth, gameCanvas:canvas?{width:canvas.width,height:canvas.height,rect:rect(canvas)}:null, actors:actors?{width:actors.width,height:actors.height,rect:rect(actors)}:null, stackVisible:!!stack&&!stack.hidden, gl:gl?{lost:gl.isContextLost(),version:gl.getParameter(gl.VERSION),renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),vendor:ext?gl.getParameter(ext.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR)}:null, contextEvents:p.contextEvents, resourceStates:p.resourceStates };
})()`;
const overlayExpression = `(() => {
  const c=document.querySelector('.game-canvas'), ctx=c.getContext('2d');
  const zones=innerWidth<600?[{x:.15,y:.1,w:.7,h:.45}]:[{x:.58,y:.18,w:.35,h:.55}];
  const values=zones.map(zone=>{const x=Math.floor(c.width*zone.x),y=Math.floor(c.height*zone.y),w=Math.floor(c.width*zone.w),h=Math.floor(c.height*zone.h),data=ctx.getImageData(x,y,w,h).data;let cover=0;for(let i=0;i<data.length;i+=4)if(data[i+3]>250&&Math.abs(data[i]-12)<=2&&Math.abs(data[i+1]-7)<=2&&Math.abs(data[i+2]-3)<=2)cover++;return{zone,fadeCoverRatio:cover/(data.length/4)};});
  return{regions:values,fadeCoverRatio:Math.max(...values.map(v=>v.fadeCoverRatio))};
})()`;

async function launch(scene, size, mode, caseId) {
  const scratch = await mkdtemp('/workspace/homepage-public-browser-');
  const log = [], network = [], failures = [], consoleEntries = [], exceptions = [], bodies = [], pending = new Map(), requests = new Map();
  let serial = 0, socket, browser, closing = false, closeStarted = false;
  try {
    browser = spawn('/usr/bin/chromium', ['--headless','--no-sandbox','--disable-dev-shm-usage','--disable-background-timer-throttling','--disable-renderer-backgrounding','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--remote-debugging-port=0',`--user-data-dir=${scratch}/chromium`,'about:blank'], { stdio: ['ignore','ignore','pipe'] });
    const endpoint = await new Promise((done,reject) => {
      const timer=setTimeout(()=>reject(new Error('Chromium startup timeout')),30000);
      browser.once('error',error=>{clearTimeout(timer);reject(error);});
      browser.stderr.on('data',bytes=>{log.push(String(bytes));const m=String(bytes).match(/DevTools listening on (ws:\/\/\S+)/);if(m){clearTimeout(timer);done(m[1]);}});
    });
    socket = new WebSocket(endpoint);
    await new Promise((done,reject)=>{socket.once('open',done);socket.once('error',reject);});
    const command=(method,params={},sessionId)=>new Promise((done,reject)=>{
      const id=++serial,timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout '+method));},420000);
      pending.set(id,{done,reject,timer});socket.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));
    });
    socket.on('message',bytes=>{
      const data=JSON.parse(String(bytes));if(!data.id)return;
      const p=pending.get(data.id);if(p){pending.delete(data.id);clearTimeout(p.timer);data.error?p.reject(new Error(JSON.stringify(data.error))):p.done(data.result);}
    });
    socket.on('close',()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error('CDP connection closed'));}pending.clear();});
    const {targetId}=await command('Target.createTarget',{url:'about:blank'}),{sessionId}=await command('Target.attachToTarget',{targetId,flatten:true});
    const page=(method,params={})=>command(method,params,sessionId);
    socket.on('message',bytes=>{
      const data=JSON.parse(String(bytes));
      if(data.id)return;
      if(data.sessionId!==sessionId)return;
      const p=data.params;
      if(data.method==='Runtime.exceptionThrown')exceptions.push({message:p.exceptionDetails.exception?.description??p.exceptionDetails.text,scope:closing?'browser-close':'observation'});
      if(data.method==='Runtime.consoleAPICalled')consoleEntries.push({type:p.type,args:p.args.map(a=>a.value??a.description),timestamp:p.timestamp,scope:closing?'browser-close':'observation'});
      if(data.method==='Network.requestWillBeSent')requests.set(p.requestId,{url:p.request.url,type:p.type});
      if(data.method==='Network.responseReceived'){
        const r=p.response,record={requestId:p.requestId,url:r.url,status:r.status,mimeType:r.mimeType,type:p.type,fromDiskCache:r.fromDiskCache,fromServiceWorker:r.fromServiceWorker};
        network.push(record);requests.set(p.requestId,{...requests.get(p.requestId),record});
      }
      if(data.method==='Network.loadingFailed')failures.push({...p,url:requests.get(p.requestId)?.url,scope:closing?'browser-close':'observation'});
      if(data.method==='Network.loadingFinished'){
        const record=requests.get(p.requestId)?.record;if(!record)return;
        let path;try{const u=new URL(record.url);if(u.origin!==url.origin||!u.pathname.startsWith(url.pathname))return;path=decodeURIComponent(u.pathname.slice(url.pathname.length))||'index.html';}catch{return;}
        record.relativePath=path;if(expected[path])record.expected={...expected[path],match:false};
        const promise=page('Network.getResponseBody',{requestId:p.requestId}).then(body=>{
          const bytes=Buffer.from(body.body,body.base64Encoded?'base64':'utf8');record.body={bytes:bytes.length,sha256:sha(bytes),relativePath:path};
          if(expected[path])record.expected={...expected[path],match:record.body.sha256===expected[path].sha256&&record.body.bytes===expected[path].bytes};
        }).catch(error=>{record.bodyReadError=error.message;});bodies.push(promise);
      }
    });
    const evaluate=async expression=>{const r=await page('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;};
    const wait=condition=>evaluate(`new Promise((done,reject)=>{const deadline=performance.now()+120000;function poll(){if(${condition})return done(true);if(performance.now()>deadline)return reject(new Error('Public home condition timeout'));setTimeout(poll,100)}poll()})`);
    await page('Page.enable');await page('Runtime.enable');await page('Network.enable');await page('Network.setCacheDisabled',{cacheDisabled:true});
    const [width,height]=sizes[size];
    await page('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:size==='mobile'});
    if(size==='mobile')await page('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1});
    await page('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:mode==='reduced'?'reduce':'no-preference'}]});
    await page('Page.addScriptToEvaluateOnNewDocument',{source:bootstrap(scene)});
    const homeReady=()=>wait(`typeof window.__publicHomeProof?.readyNow==='number'&&document.querySelector('.resource-screen')?.hidden===true&&document.querySelector('.world-underlay')?.hidden===false&&document.querySelector('[data-main-menu]')?.dataset.menuView==='home'&&document.querySelector('.game-shell')?.classList.contains('menu-open')&&document.querySelector('.world-actors')?.width===Math.round(innerWidth*Math.min(devicePixelRatio,2))&&document.querySelector('.world-actors')?.height===Math.round(innerHeight*Math.min(devicePixelRatio,2))`);
    await page('Page.navigate',{url:url.href});await homeReady();await evaluate('document.fonts.ready.then(()=>true)');
    const settle=()=>evaluate('new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>done(true)))))');
    await settle();
    const state=()=>evaluate(stateExpression);
    const browserInfo=await command('Browser.getVersion');
    const waitElapsed=second=>evaluate(`new Promise((done,reject)=>{const deadline=performance.now()+${Math.max(120000,(second+30)*1000)};function poll(){const p=__publicHomeProof;if(p.readyNow!==null&&(performance.now()-p.readyNow)/1000>=${second})return done(true);if(performance.now()>deadline)return reject(new Error('Natural age timeout'));setTimeout(poll,50)}poll()})`);
    const screenshot=async file=>{
      const before=await state();
      const gpu=await evaluate(`(async()=>{const gl=document.querySelector('.world-actors')?.getContext('webgl2');if(!gl||gl.isContextLost())throw new Error('Live WebGL2 unavailable');const start=performance.now(),sync=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);if(!sync)throw new Error('GPU fence creation failed');gl.flush();let polls=0;try{for(;;){const status=gl.clientWaitSync(sync,0,0);polls++;if(status===gl.ALREADY_SIGNALED||status===gl.CONDITION_SATISFIED)return{available:true,waitMs:performance.now()-start,polls,status};if(status===gl.WAIT_FAILED||gl.isContextLost())throw new Error('GPU fence failed');if(performance.now()-start>90000)throw new Error('GPU fence timeout');await new Promise(done=>setTimeout(done,0));}}finally{gl.deleteSync(sync)}})()`);
      const shot=await page('Page.captureScreenshot',{format:'png'}),bytes=Buffer.from(shot.data,'base64');await writeFile(resolve(output,file),bytes);
      return{file,bytes:bytes.length,sha256:sha(bytes),gpuCompletion:gpu,before,after:await state()};
    };
    const click=async(selector,method)=>{
      const point=await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw new Error('Missing UI selector');const r=e.getBoundingClientRect();if(r.width<=0||r.height<=0)throw new Error('Invisible control');return{x:r.x+r.width/2,y:r.y+r.height/2}})()`);
      if(method==='keyboard'){
        await evaluate(`document.querySelector(${JSON.stringify(selector)}).focus()`);
        await page('Input.dispatchKeyEvent',{type:'rawKeyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});await page('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});
      }else if(method==='touch'){
        await page('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...point,id:0,radiusX:1,radiusY:1,force:1}]});await page('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
      }else{
        await page('Input.dispatchMouseEvent',{type:'mousePressed',...point,button:'left',clickCount:1});await page('Input.dispatchMouseEvent',{type:'mouseReleased',...point,button:'left',clickCount:1});
      }
    };
    return { page,evaluate,state,wait,waitElapsed,settle,screenshot,click,homeReady,browserInfo,network,failures,consoleEntries,exceptions,bodies,
      async close(){if(closeStarted)return;closeStarted=true;await Promise.allSettled(bodies);closing=true;try{await command('Browser.close');}catch{}socket.close();if(browser.exitCode===null){await new Promise(done=>{const timer=setTimeout(()=>{browser.kill('SIGKILL');done();},5000);browser.once('exit',()=>{clearTimeout(timer);done();});});}await writeFile(resolve(output,caseId+'-chromium.stderr.txt'),log.join(''));await rm(scratch,{recursive:true,force:true});}
    };
  }catch(error){socket?.close();browser?.kill('SIGKILL');await Promise.allSettled(bodies);await writeFile(resolve(output,caseId+'-launch-failure.json'),JSON.stringify({automatedPass:false,error:error.stack,network,failures,console:consoleEntries,exceptions},null,2)+'\n');await writeFile(resolve(output,caseId+'-chromium.stderr.txt'),log.join(''));await rm(scratch,{recursive:true,force:true});throw error;}
}

async function persist(file, extra={}) {
  const evidence={...inputs,utcEnd:new Date().toISOString(),automatedPass:checks.every(c=>c.pass),visualReview:'Pending actual image inspection; no automatic role/event/artwork acceptance.',checks,results,...extra};
  await writeFile(resolve(output,file),JSON.stringify(evidence,null,2)+'\n');return evidence;
}
try{
  for(const size of selectedSizes)for(const mode of modes)for(const scene of selectedScenes){
    const id=`${scene}-${size}-${mode}`;console.log(JSON.stringify({event:'case-start',id,utc:new Date().toISOString()}));
    const session=await launch(scene,size,mode,id);current=session;
    const result={id,scene,size,mode,browser:session.browserInfo,initial:null,captures:[],ui:[],network:session.network,networkFailures:session.failures,console:session.consoleEntries,exceptions:session.exceptions};results.push(result);
    try{
      result.initial=await session.state();
      check('initial-webgl-ready',result.initial.stackVisible&&result.initial.gl&&!result.initial.gl.lost,{id});
      check('media-condition',result.initial.reduced===(mode==='reduced'),{id});
      check('selected-scene',result.initial.scene===scene&&scenarios[scene].name.test(result.initial.sceneLabel),{id,sceneLabel:result.initial.sceneLabel});
      check('no-horizontal-overflow',result.initial.scrollWidth<=sizes[size][0],{id,scrollWidth:result.initial.scrollWidth});
      check('home-menu-controls-visible',result.initial.buttons.length===3&&result.initial.buttons.every(b=>b.width>0&&b.height>0&&!b.disabled&&b.x>=0&&b.y>=0&&b.x+b.width<=sizes[size][0]+1&&b.y+b.height<=sizes[size][1]+1),{id,buttons:result.initial.buttons});
      const phases=size==='mobile'&&!fullMobile?(mode==='normal'?[[.2,'initial'],[2,'stable']]:[[2,'static-initial']]):(mode==='normal'?scenarios[scene].phases:[[2,'static-initial'],[reducedLate??scenarios[scene].length+.2,'static-after-end']]);
      for(const [second,phase] of phases){
        await session.waitElapsed(second);await session.settle();
        const observation={requestedSecond:second,phase,state:await session.state(),overlay:await session.evaluate(overlayExpression)};
        observation.capture=await session.screenshot(`${id}-${phase}.png`);result.captures.push(observation);
        check('capture-keeps-webgl',observation.capture.before.stackVisible&&observation.capture.after.stackVisible&&observation.capture.gpuCompletion.available,{id,phase});
        if(phase!=='initial')check('background-not-fully-faded',observation.overlay.fadeCoverRatio<.95,{id,phase,fadeCoverRatio:observation.overlay.fadeCoverRatio});
        if(mode==='normal')check('phase-observed-within-tolerance',observation.capture.before.elapsed-second<=2,{id,phase,requestedSecond:second,actualSecond:observation.capture.before.elapsed,toleranceSeconds:2});
        console.log(JSON.stringify({event:'capture',id,phase,file:observation.capture.file,elapsed:observation.capture.before.elapsed,sha256:observation.capture.sha256}));
        await persist('partial-proof.json');
      }
      if(!skipUi){
        const techniques=[size==='mobile'?'touch':'pointer',...(size==='desktop'&&mode==='normal'&&scene==='capital'?['keyboard']:[])];
        for(const technique of techniques){
          const before=await session.state();await session.click('[data-scene-switch]',technique);
          await session.wait(`localStorage.getItem('sketch-rts-menu-scene')!==${JSON.stringify(before.scene)}`);await session.homeReady();await session.settle();
          const after=await session.state();result.ui.push({technique,beforeScene:before.scene,after});
          check('scene-switch-'+technique,after.scene!==before.scene&&scenarios[after.scene]?.name.test(after.sceneLabel)&&after.stackVisible,{id});
        }
      }
      result.final=await session.state();await Promise.allSettled(session.bodies);
      result.network=session.network;result.networkFailures=session.failures;result.console=session.consoleEntries;result.exceptions=session.exceptions;
    }finally{await session.close();current=undefined;}
    // Generate checks after draining/closing so recorded observation events cannot
    // silently arrive after the corresponding success assertion.
    check('no-context-loss',result.final.contextEvents.length===0,{id,events:result.final.contextEvents});
    check('no-page-exceptions',!session.exceptions.some(e=>e.scope==='observation'),{id,exceptions:session.exceptions});
    check('no-console-errors',!session.consoleEntries.some(e=>e.type==='error'&&e.scope==='observation'),{id});
    check('no-network-failures',!session.failures.some(f=>f.scope==='observation'),{id,failures:session.failures});
    check('no-http-resource-errors',!session.network.some(r=>r.status>=400),{id});
    const matches=session.network.filter(r=>r.expected), mismatches=matches.filter(r=>!r.expected.match);
    const unknownStatic=session.network.filter(r=>{try{const u=new URL(r.url);return u.origin===url.origin&&!r.expected&&(['Document','Script','Stylesheet'].includes(r.type)||/^(assets|art\/world3d)\//.test(r.relativePath??''));}catch{return false;}});
    result.distVerification={available:!!distRoot,matchedResponses:matches.length,mismatches,unknownStaticResponses:unknownStatic,jsResponses:matches.filter(r=>r.type==='Script').length};
    if(distRoot){
      check('public-assets-exact-build',matches.length>0&&mismatches.length===0,{id,mismatches});
      check('no-unknown-static-responses',unknownStatic.length===0,{id,unknownStaticResponses:unknownStatic});
      check('entry-script-matches-build',matches.some(r=>r.type==='Script'&&r.expected.match),{id});
      check('entry-html-matches-build',matches.some(r=>r.relativePath==='index.html'&&r.expected.match),{id});
    }
    await writeFile(resolve(output,id+'.json'),JSON.stringify(result,null,2)+'\n');await persist('partial-proof.json');
    console.log(JSON.stringify({event:'case-complete',id,checks:checks.length,captures:result.captures.length}));
  }
  if(distRoot){const changed=[];for(const [path,before] of Object.entries(expected)){const bytes=await readFile(resolve(distRoot,path));if(bytes.length!==before.bytes||sha(bytes)!==before.sha256)changed.push(path);}check('expected-dist-unchanged',changed.length===0,{changed});}
  const proof=await persist('proof.json');console.log(JSON.stringify({event:'complete',automatedPass:proof.automatedPass,cases:results.length,captures:results.reduce((n,r)=>n+r.captures.length,0),checks:checks.length,failed:checks.filter(c=>!c.pass),output}));if(!proof.automatedPass)process.exitCode=1;
}catch(error){
  try{await current?.close();}catch(closeError){console.error(closeError);}
  await persist('failure.json',{automatedPass:false,executionStatus:'failed',error:error.stack});console.error(error);process.exitCode=1;
}
