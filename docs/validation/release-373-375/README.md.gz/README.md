# PR #373 / #374 / #375 local integration

Local temporary worktree: `/workspace/sketch-rts-release-373-375`.

Merged, in order, exact heads `3dc92d62311dbfc0fa27b01c17c098e9b3750904`, `e62aa4a6ba15e01ea40bf4e2167f8a376cfa3b36`, `a7d8037f029a942aa797cc5b7830de1d911531a3` into detached clean baseline `a0524c2c9b32d4b92084d4f9478729eb562f7d29`, with no conflict. No remote merge, push or deployment was performed by this lane.

Committed combined HEAD is `2e7538e31fd045646e7ae6a28aefd33ae979d6a5`, tree `8b99ead5c9bf1c29c0ef377d44915b335cbdf313`. The only final working change is the authorized two-line probe test correction. Tested prospective tree including that correction is **`93944abd1f38f05afdc7c875fd955eef98eb1291`**, computed with a separate `GIT_INDEX_FILE`; the real working index was not modified. Root will commit and push the correction from the existing performance branch.

## Actual validation

- 249 guardian/version/save/replay/story/server/client and unchanged AI item cases passed.
- 142 homepage/presentation/GPU scene/resource/audio cases passed. This includes the requested nine homepage/rendering spec files, plus existing resource and audio coverage.
- 116 terrain, distance/coast/readiness/query/SAT and probe cases passed after the test-only version correction. The initial 115-pass / 1-fail output remains preserved.
- One existing guardian immunity case passed; 113 unrelated tests in that file were explicitly skipped by the documented name filter.
- Seven SDK package boundary cases passed.
- **515 different Vitest cases pass in the combined source**, counting repeated probe cases once.
- Two additional direct actual `LockstepClient` transport checks pass: rules-2 checkpoint closes before applying any state/checksum change; rules-3 checkpoint is accepted. The external harness does not edit production or test source.
- The same nine probe cases also pass separately in the original rules-2 performance branch after the strict current-version correction.
- `npm run build:production` passes, including TypeScript, Vite and server bundle. A final `tsc --noEmit` passes after the test-only correction; runtime implementation did not change after the production build.

## Classified integration failure

`scripts/six-player-tick-probe.test.ts` tested `process.cwd()` current source but hardcoded the metadata expectation to rules 2. The combined user-authorized guardian runtime correctly reports rules 3. Root authorized importing the current `RULES_VERSION` and keeping a strict `toBe(RULES_VERSION)` assertion. No other assertion, instrumented/plain command comparison, checksum comparison, planning phase, runtime code or historical evidence was changed. `probe-test-before.ts.txt`, its SHA in `test-contract-correction.json`, the original failing log, and the reviewable patch are preserved. Both rules-2 and rules-3 executions now pass all nine original probe cases.

All three production domains exactly match their original PR implementation bytes. Each historical evidence subtree matches the original Git tree; these are historical capture manifests, not claims that combined rules-3 sources match every older capture SHA. In particular, the existing rules-2 14,400-tick command log and checksum were neither rerun nor relabeled as a rules-3 outcome. No full AI matrix or repeated performance benchmark was run. The AI guardian-use estimate stays 260 and remains a separately documented product decision.

`commands.jsonl` records actual commands, directories, UTC timestamps, exit codes and raw logs. `integration-result.json` records the exact trees, passing counts and scope. `manifest.json` covers closed review files. The temporary derived `proposed-combined.index` is intentionally excluded; its commands and resulting tree are retained.
