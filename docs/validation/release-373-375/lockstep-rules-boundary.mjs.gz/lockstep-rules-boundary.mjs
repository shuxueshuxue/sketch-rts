import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const root=resolve(process.argv[2]);
const load=file=>import(pathToFileURL(resolve(root,file)).href);
const [{createGame,snapshotGame},{SimulationEngine},{checksumGame},{LockstepClient},{RULES_VERSION}]=await Promise.all([
  load('src/shared/sim.ts'),load('src/shared/sim/engine.ts'),load('src/shared/sim/checksum.ts'),
  load('src/client/net/lockstep-client.ts'),load('src/shared/rules-version.ts')]);
assert.equal(RULES_VERSION,3);
class FakeTransport{
  sent=[];closed=false;handler;
  send(message){this.sent.push(message);}
  onMessage(handler){this.handler=handler;}
  close(){this.closed=true;}
  emit(message){this.handler?.(message);}
}
const results=[];
for(const rulesVersion of [2,3]){
  const game=createGame('bareDuel',{aiPlayers:[]}),transport=new FakeTransport(),errors=[];
  const before=checksumGame(game),beforeSnapshot=JSON.stringify(snapshotGame(game));
  const client=new LockstepClient({roomId:'release-check',playerId:'player',engine:new SimulationEngine(game),transport,onError:message=>errors.push(message)});
  const snapshot=snapshotGame(game);snapshot.tick+=100;
  transport.emit({type:'checkpoint',rulesVersion,checkpoint:{roomId:'release-check',tick:snapshot.tick,snapshot,nextId:game.nextId},epoch:1});
  if(rulesVersion===2){
    assert.equal(transport.closed,true);assert.match(errors[0],/rules version 2.*requires 3/);
    assert.equal(checksumGame(game),before);assert.equal(JSON.stringify(snapshotGame(game)),beforeSnapshot);
  }else{
    assert.equal(transport.closed,false);assert.deepEqual(errors,[]);assert.equal(client.currentSnapshot().tick,100);
  }
  results.push({rulesVersion,rejectedBeforeApply:rulesVersion===2,transportClosed:transport.closed,errors,tick:client.currentSnapshot().tick});
  client.close();
}
const report={passed:true,method:'Actual LockstepClient transport callback using the existing fake-transport seam; old rules-2 checkpoint rejected before simulation mutation and current rules-3 checkpoint accepted; no production/test source edit.',results,sourceSha256:Object.fromEntries(['src/shared/rules-version.ts','src/client/net/lockstep-client.ts'].map(file=>[file,createHash('sha256').update(readFileSync(resolve(root,file))).digest('hex')]))};
writeFileSync(new URL('./lockstep-rules-boundary.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
