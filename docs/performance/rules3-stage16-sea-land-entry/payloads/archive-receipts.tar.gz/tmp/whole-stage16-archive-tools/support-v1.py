"""Small Git-only supporting layers; standard gzip, tar; no duplicate payload spool."""
import base64,gzip,io,json,stat,sys,tarfile
from pathlib import Path
T=Path(__file__).resolve().parent;Q=Path('/tmp/whole-stage16-resume-source-v1');sys.path.insert(0,str(T));import core
sys.path.insert(0,str(Q));import adapter
from core import P,S,sha,oid,zipped,write
phase=sys.argv[1];adapter.LABEL='support-'+phase;m=json.loads((P/'manifest.json').read_bytes())
def store(relative,decoded,extra):
 packed=zipped(decoded);assert len(packed)<=850000;key=oid('blob',packed);assert adapter.command(['hash-object','-w','--stdin'],packed).decode().strip()==key;name=S+'/'+relative;adapter.command(['update-index','-z','--index-info'],('100644 '+key+'\t'+name+'\0').encode());adapter.command(['update-index','--skip-worktree','-z','--stdin'],(name+'\0').encode());r={'storedPath':relative,'storedGitBlobOid':key,'storedBytes':len(packed),'storedSha256':sha(packed),'decodedBytes':len(decoded),'decodedSha256':sha(decoded),**extra};m.setdefault('gitOnlySupportingFiles',[]).append(r);return r
if phase=='source':
 p=P/'source241-readback.json';b=p.read_bytes();x=json.loads(b);r=store('payloads/source241-readback.json.gz',b,{'format':'gzip JSON, complete source head/path/n/SHA statement'});write(p,{'complete':True,'sourceRecords':len(x['sourceRows']),'actualDistinctGitBodyCommands':x['actualCommands'],'allFullGitBodiesEqualCapturedSources':True,'fullStatementGitOnly':r,'sourceRowsReconstructibleFromTenOriginalEnvironmentSourceInputs':True});print(json.dumps(r))
elif phase=='receipts':
 primary={base64.b64decode(r['originalPathBase64']).decode() for r in m['files']};o=io.BytesIO();members=[]
 with tarfile.open(fileobj=o,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for root in [T,Q,Path('/tmp/stage16-index-space-independent-v1')]:
   for p in sorted(root.rglob('*')):
    if not p.is_file() or p.is_symlink() or str(p) in primary or p.name.startswith('support-receipts') or p.name.startswith('receipts-04'):continue
    b=p.read_bytes();i=tarfile.TarInfo(str(p).lstrip('/'));i.size=len(b);i.mode=stat.S_IMODE(p.stat().st_mode);tar.addfile(i,io.BytesIO(b));members.append([str(p),len(b),sha(b),i.mode])
 decoded=o.getvalue();r=store('payloads/archive-receipts.tar.gz',decoded,{'format':'gzip tar; complete original source/log members','memberCount':len(members)});write(P/'archive-receipts-index.json',{'members':members,'allFullBytesAndModesRetained':True});print(json.dumps(r))
else:raise AssertionError(phase)
m['supportingFiles']=sorted(p.name for p in P.iterdir() if p.is_file() and p.name!='manifest.json');write(P/'manifest.json',m)
