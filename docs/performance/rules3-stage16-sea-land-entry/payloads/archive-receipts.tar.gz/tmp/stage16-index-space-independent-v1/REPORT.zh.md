1 MiB 的 index + lock 增长保守上界不可证。

当前 index 分配 32,768 B，sharedindex 分配 1,642,496 B，合计 1,675,264 B；index.lock 不存在。纯二进制解码得到 20,190 条原索引记录（17 overlay + 20,173 shared），删除及替换位图均为空。20,189 条 100644、1 条 100755，全部 stage 0；20,080 条 skip-worktree、110 条普通，assume-valid 与 intent-to-add 均为 0。完整 stage/flags 记录的长度和 SHA256 与 OLD-STATE 完全一致；审查前后 index/shared 内容 SHA256 未变。

最新版约 981 canonical + 20 metadata = 1,001 条新增记录的 retained-base overlay 可能很小，但这是有条件估算。只要未来写入生成新 sharedindex 且保留旧件，单新 shared 文件就可能超过 1 MiB；当前条目计数和空替换位图不能排除所有中间写入及锁文件峰值。因此不为缩减预算签发 PASS。

可考虑在所有相关写索引命令上显式 per-command splitIndex.maxPercentChange=100，并核旧 shared 名称/内容及对 index、sharedindex、lock 做分配量硬 guard；这仍是待授权、待验证条件方案。本审查没有写配置、索引、原 T、执行引擎或建立临时索引。Git 可能更新 shared mtime，名称/内容不变不能说成全部元数据不变。

仅本车道完成后 ALLTOOLS STOP；其他 archive SOURCE 车道可能仍在工作。
