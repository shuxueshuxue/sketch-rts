"""Resume archive mapping only; never execute application/cold/profiling code."""
import base64,gzip,importlib.util,json,stat,sys
from pathlib import Path
T=Path('/tmp/whole-stage16-archive-tools');sys.path.insert(0,str(T));import core
sys.path.insert(0,str(Path(__file__).resolve().parent));import adapter
core.command=adapter.command
spec=importlib.util.spec_from_file_location('frozen_capture',T/'capture-git.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);cap.command=adapter.command
P=core.P;assert P.is_dir() and not list(P.iterdir()),'Partial scope must still be empty'
assert adapter.command(['ls-files','--stage','-z','--',core.S])==b'','New index entries exist'
state=json.loads(gzip.decompress((T/'OLD-STATE.json.gz').read_bytes()));core.old_check(state)
old=base64.b64decode(state['patternsBase64']);expected=old+('/'+core.S+'/\n!/'+core.S+'/payloads/\n').encode();assert (core.R/'.git/info/sparse-checkout').read_bytes()==expected
assert gzip.decompress((T/'before-patterns.txt.gz').read_bytes())==old and gzip.decompress((T/'after-patterns.txt.gz').read_bytes())==expected
inv=core.inv_load();rows=[]
for r in inv['files']:
 n,h,_,_=inv['objects'][r[2]];rows.append([str(core.source_path(inv,r)),n,h,r[3],'frozen-originals-with-delta'])
own=json.loads((T/'archive-source-files.json').read_bytes());rows+=own
keys={(r[0],r[1]) for r in json.loads((T/'write-measurement.json').read_bytes())['objects']};assert {(r[1],r[2]) for r in rows}<=keys
for p,n,h,mode,group in own:core.full_read(Path(p),n,h,mode)
# The original capture function rechecks every source and every existing gzip
# body, rebuilds explicit aliases, then writes only the two declared index batches.
m=cap.capture(rows)
for name in ['core.py','verify-git.py','rehydrate-local-heads.py']:(P/name).write_bytes((T/name).read_bytes())
(P/'README.zh.md').write_bytes((T/'README.zh.draft.md').read_bytes())
for name in ['ROOT-DECISION.json','REPORT.zh.md']:(P/name).write_bytes((Path('/tmp/sea-land-hot-entry-followup-decision-v1')/name).read_bytes())
m['supportingFiles']=[p.name for p in P.iterdir() if p.is_file() and p.name!='manifest.json'];core.write(P/'manifest.json',m)
print(json.dumps({'complete':True,'paths':len(m['files']),'canonical':sum('aliasOf' not in r for r in m['files']),'aliases':sum('aliasOf' in r for r in m['files']),'old':core.old_check(state),'failedAttemptAnd65FrozenSourcesUnchanged':True,'applicationExecuted':False}))
