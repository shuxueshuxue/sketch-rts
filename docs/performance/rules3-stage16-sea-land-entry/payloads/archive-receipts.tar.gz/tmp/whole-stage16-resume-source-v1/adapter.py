"""New-prefix journal; full argv/n/SHA, Git blob stdout stays at its full OID."""
import base64,datetime,hashlib,json,os,subprocess
from pathlib import Path
T=Path('/tmp/whole-stage16-archive-tools');LABEL='resume-capture-02'
def sha(b):return hashlib.sha256(b).hexdigest()
def command(args,data=None,repo=None,journal=None):
 import core
 writeIndex=args[0] in ['update-index','add','commit']
 flags=['-c','splitIndex.maxPercentChange=100'] if writeIndex else []
 argv=core.GIT+flags+args if repo is None else core.GIT[:-2]+['-C',str(repo)]+flags+args
 sharedPins=json.loads((Path(__file__).resolve().parent/'RESUME-PLAN.json').read_bytes())['oldSharedIndexPins'] if writeIndex else []
 for name,n,h in sharedPins:
  b=Path(name).read_bytes();assert len(b)==n and sha(b)==h
 now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
 header=T/(LABEL+'-command-context.json')
 if not header.exists():header.write_text(json.dumps({'cwd':os.getcwd(),'timestamps':'ISO8601 UTC','argv':'complete per row','blobStdout':'full bytes at stdoutGitBlobOid; verify stdoutBytes/SHA','otherLargeStdout':'fixed old Git tree/present pins and primary manifest reconstruct full stage/flags in operation order'},separators=(',',':'))+'\n')
 start=now();p=subprocess.run(argv,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 r={'argv':argv,'start':start,'end':now(),'exit':p.returncode,'stdinBytes':len(data or b''),'stdinSha256':sha(data or b''),'stdoutBytes':len(p.stdout),'stdoutSha256':sha(p.stdout),'stderrBase64':base64.b64encode(p.stderr).decode()}
 if args[:2]==['cat-file','blob']:r['stdoutGitBlobOid']=args[-1]
 elif len(p.stdout)<=4096:r['stdoutBase64']=base64.b64encode(p.stdout).decode()
 else:r['stdoutLosslessReference']={'fixedOldHead':core.OLD,'kind':args,'primaryManifest':'docs/performance/rules3-stage16-sea-land-entry/manifest.json','oldPresentPins':'SOURCE-OLDSTATE-PASS.json','beforeIndexOrPrimaryPayloadIndex':True}
 if data and args[0]=='hash-object' and p.returncode==0:r['stdinGitBlobOid']=p.stdout.decode().strip()
 elif data and args[0]=='update-index':
  import gzip
  f=T/(LABEL+'-'+('skip' if '--skip-worktree' in args else 'index')+'.stdin.gz');assert not f.exists();f.write_bytes(gzip.compress(data,mtime=0));r['stdinGzipReceipt']=f.name
 with (T/(LABEL+'-commands.jsonl')).open('a') as f:f.write(json.dumps(r,separators=(',',':'))+'\n')
 assert p.returncode==0,(argv,p.returncode,p.stderr)
 for name,n,h in sharedPins:
  b=Path(name).read_bytes();assert len(b)==n and sha(b)==h
 return p.stdout
