#!/usr/bin/env python3
"""Record exact independent archive commands without overwriting attempts."""
import datetime
import hashlib
import json
import os
import resource
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
cwd = Path(os.environ.get("STAGE3_STEP_CWD", str(ROOT)))
step = sys.argv[1]
argv = sys.argv[2:]
target = ROOT / (step + '-execution.json')
if target.exists():
    raise ValueError('Refuse to overwrite attempt ' + step)
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.perf_counter()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
stdout = ROOT / (step + '.stdout.log')
stderr = ROOT / (step + '.stderr.log')
with stdout.open('xb') as a, stderr.open('xb') as b:
    result = subprocess.run(argv, cwd=cwd, stdout=a, stderr=b)
after = resource.getrusage(resource.RUSAGE_CHILDREN)
row = {'schema':1, 'argv':argv, 'cwd':str(cwd), 'startedAt':start,
       'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'wallSeconds':time.perf_counter()-clock, 'exitCode':result.returncode,
       'childUserSeconds':after.ru_utime-before.ru_utime,
       'childSystemSeconds':after.ru_stime-before.ru_stime}
for name, path in [('stdout',stdout),('stderr',stderr)]:
    body = path.read_bytes()
    row[name] = {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
target.write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(row,ensure_ascii=False))
print(stdout.read_text())
print(stderr.read_text())
sys.exit(result.returncode)
