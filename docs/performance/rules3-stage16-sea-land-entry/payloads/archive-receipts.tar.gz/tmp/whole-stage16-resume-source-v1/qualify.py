"""Read-only resume qualification, preserving the failed attempt and own65 bytes."""
import base64,gzip,hashlib,json,sys
from pathlib import Path
Q=Path(__file__).resolve().parent;T=Path('/tmp/whole-stage16-archive-tools');sys.path.insert(0,str(T));import core
sys.path.insert(0,str(Q));import adapter
adapter.T=Q;adapter.LABEL='source-qualify';core.command=adapter.command
assert core.P.is_dir() and not list(core.P.iterdir());assert adapter.command(['ls-files','--stage','-z','--',core.S])==b''
s=json.loads(gzip.decompress((T/'OLD-STATE.json.gz').read_bytes()));old=core.old_check(s);before=base64.b64decode(s['patternsBase64']);after=before+('/'+core.S+'/\n!/'+core.S+'/payloads/\n').encode();assert (core.R/'.git/info/sparse-checkout').read_bytes()==after and gzip.decompress((T/'before-patterns.txt.gz').read_bytes())==before and gzip.decompress((T/'after-patterns.txt.gz').read_bytes())==after
own=json.loads((T/'archive-source-files.json').read_bytes())
for p,n,h,mode,group in own:core.full_read(Path(p),n,h,mode)
inv=core.inv_load();keys={(inv['objects'][r[2]][0],inv['objects'][r[2]][1]) for r in inv['files']};keys.update((r[1],r[2]) for r in own);expected={(r[0],r[1]) for r in json.loads((T/'write-measurement.json').read_bytes())['objects']};assert keys<=expected
r={'complete':True,'scopeEmpty':True,'newIndexEntries':0,'old':old,'beforePatternsSha256':core.sha(before),'currentPatternsEqualsFirstBeforePlusExactScopeDelta':True,'all65OwnSnapshotFullBytesModesExact':True,'expectedCoversAll1432OriginalRows':True,'failedCaptureExitCode':json.loads((T/'capture-01-execution.json').read_bytes())['exitCode'],'failedCaptureAndJournalUnchanged':True,'newMutationExecuted':False};(Q/'QUALIFICATION.json').write_text(json.dumps(r,separators=(',',':'))+'\n');print(json.dumps(r))
