"""SOURCE-only exact manifest size plus conservative journal and index provisions."""
import base64,gzip,hashlib,json,math,shutil,stat,sys,zlib
from pathlib import Path
T=Path('/tmp/whole-stage16-archive-tools');Q=Path(__file__).resolve().parent;sys.path.insert(0,str(T));import core
inv=core.inv_load();rows=[]
for r in inv['files']:
 n,h,_,_=inv['objects'][r[2]];rows.append([str(core.source_path(inv,r)),n,h,r[3],'frozen-originals-with-delta'])
rows+=json.loads((T/'archive-source-files.json').read_bytes());meas=json.loads((T/'write-measurement.json').read_bytes());expected={tuple(r[:2]):r[2:5] for r in meas['objects']};canon={};files=[];small=0
for path,n,h,mode,group in rows:
 gn,gh,key=expected[n,h];r={'group':group,'originalPathBase64':base64.b64encode(path.encode()).decode(),'originalBytes':n,'originalSha256':h,'originalMode':oct(mode),'storedPath':'','encoding':'gzip','storedBytes':gn,'storedSha256':gh,'storedGitBlobOid':key}
 if (n,h) in canon:
  first=canon[n,h];r['storedPath']=first['storedPath'];r['aliasOf']=first['payloadId'];r['duplicateVerifiedByFullByteComparison']=True
 else:
  number=len(canon)+1;r['payloadId']=f'p{number:04d}';r['storedPath']=f'payloads/id{number:04d}.bin.gz';canon[n,h]=r
  if gn<16384:small+=gn
 files.append(r)
m={'schema':3,'identity':'Stage16 rejected candidate evidence','files':files,'supportingFiles':['README.zh.md','core.py','verify-git.py','rehydrate-local-heads.py','ROOT-DECISION.json','REPORT.zh.md','analysis.json','verified-closure.json','storage-method.json','resume-source.json.gz'],'appendHistory':[{'utc':'0'*40,'sourcePaths':len(rows)}]};body=json.dumps(m,separators=(',',':')).encode();allocation=lambda n:math.ceil(n/4096)*4096
manifestPhysical=allocation(len(body));manifestGit=allocation(len(zlib.compress(b'blob '+str(len(body)).encode()+b'\0'+body,6)))
# Actual payload/manifest metadata plus explicitly reserved future publication
# bundles, scripts, state pins and Git objects, including a second manifest blob.
meta=manifestPhysical+2*manifestGit+768*1024
currentT=sum(p.stat().st_blocks*512 for p in T.rglob('*') if p.is_file());newSource=sum(p.stat().st_blocks*512 for p in Q.rglob('*') if p.is_file());journalBound=2*len(canon)*700;futureTools=384*1024;toolsBound=currentT+newSource+64*1024+journalBound+futureTools
r={'sourceOnlyNoMutation':True,'canonical':len(canon),'sourcePaths':len(rows),'smallExistingPackedBodiesIfNaivelyBase64Bytes':small,'base64CopiesAvoidedUpperBytes':4*math.ceil(small/3),'originalFailedJournalHadBlobBodyBase64Copies':0,'originalFailureCause':'Repeated full argv/UTC/n/hash rows, not gzip stdout bodies.','originalTAllocatedBytesNow':currentT,'newSourceAllocatedBytesNow':newSource,'independentIndexReviewProvisionBytes':65536,'newFullArgvJournalBoundBytes':journalBound,'perRecordConservative700BytesTwoPerCanonical':True,'futureReadbacksQuietCommitPushTlsToolsProvisionBytes':futureTools,'proposedTools5MiBBoundBytes':toolsBound,'tools5MiB':5*1048576,'manifestPhysicalBytes':manifestPhysical,'manifestGitObjectMeasuredBytes':manifestGit,'futureMetadataPublicationScriptsAndObjectsProvisionBytes':768*1024,'metadataMeasuredAndProvisionedBytes':meta,'metadata2MiB':2*1048576,'index1MiBNeedsIndependentReadback':True,'indexCurrentAllocatedBytes':(core.R/'.git/index').stat().st_blocks*512,'sharedCurrentAllocatedBytes':sum(p.stat().st_blocks*512 for p in (core.R/'.git').glob('sharedindex*') if p.is_file()),'currentFreeBytes':shutil.disk_usage('/tmp').free,'resumeMutationNotExecuted':True}
assert meta<=2*1048576,r
(Q/'MEASUREMENT.json').write_text(json.dumps(r,separators=(',',':'))+'\n');print(json.dumps(r))
