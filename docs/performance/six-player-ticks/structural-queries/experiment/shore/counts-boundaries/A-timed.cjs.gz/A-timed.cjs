"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/naval.ts
var naval_exports = {};
__export(naval_exports, {
  cancelFerry: () => cancelFerry,
  coastOnWater: () => coastOnWater,
  colonyNavalWant: () => colonyNavalWant,
  colonyNavalWantWithMineEligibility: () => colonyNavalWantWithMineEligibility,
  facts: () => facts,
  navalBudgetReserve: () => navalBudgetReserve,
  navalReservePurchase: () => navalReservePurchase,
  navalUnitIds: () => navalUnitIds,
  navalWant: () => navalWant,
  original: () => __shoreExperimentOriginal,
  planNavalEconomy: () => planNavalEconomy,
  planNavalTactics: () => planNavalTactics,
  planNavalTacticsWithAssignments: () => planNavalTacticsWithAssignments,
  reset: () => __shoreExperimentReset,
  run: () => shoreSpot,
  stats: () => __shoreExperimentStats
});
module.exports = __toCommonJS(naval_exports);

// ../sketch-rts-six-player-structural-before-0f31/src/shared/generated/ship-geometry.json
var ship_geometry_default = {
  sourceSha256: "22acecf80139ea9f084dbc3411a61d94128d400092ef1428e3a45ee86f5ea01e",
  camera: {
    tilt: 0.72,
    frameSize: 384,
    worldSize: 360,
    directions: 32,
    anchorY: 24
  },
  ships: {
    cutter: {
      length: 116,
      beam: 46,
      deckHeight: 18,
      hullMass: 7e3,
      loadCapacity: 450,
      acceleration: 72,
      turnRate: 0.628318531,
      obstacles: [
        {
          x: -35,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -39,
          y: 0,
          radius: 14,
          type: "cabin"
        }
      ],
      weaponMount: [
        31,
        0,
        11
      ],
      mastHeight: 78,
      weaponPivot: null,
      hull: [
        [
          -58,
          -12.88
        ],
        [
          -51.04,
          -18.86
        ],
        [
          -31.900000000000002,
          -23
        ],
        [
          0,
          -23
        ],
        [
          23.200000000000003,
          -20.7
        ],
        [
          42.339999999999996,
          -12.88
        ],
        [
          58,
          0
        ],
        [
          42.339999999999996,
          12.88
        ],
        [
          23.200000000000003,
          20.7
        ],
        [
          0,
          23
        ],
        [
          -31.900000000000002,
          23
        ],
        [
          -51.04,
          18.86
        ],
        [
          -58,
          12.88
        ]
      ],
      deck: [
        [
          -53,
          -10.080000000000002
        ],
        [
          -46.64,
          -14.76
        ],
        [
          -29.150000000000002,
          -18
        ],
        [
          0,
          -18
        ],
        [
          21.200000000000003,
          -16.2
        ],
        [
          38.69,
          -10.080000000000002
        ],
        [
          53,
          0
        ],
        [
          38.69,
          10.080000000000002
        ],
        [
          21.200000000000003,
          16.2
        ],
        [
          0,
          18
        ],
        [
          -29.150000000000002,
          18
        ],
        [
          -46.64,
          14.76
        ],
        [
          -53,
          10.080000000000002
        ]
      ]
    },
    transport: {
      length: 184,
      beam: 80,
      deckHeight: 26,
      hullMass: 14e3,
      loadCapacity: 1800,
      acceleration: 48,
      turnRate: 0.383972435,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 64,
      weaponPivot: null,
      hull: [
        [
          -92,
          -22.400000000000002
        ],
        [
          -80.96,
          -32.8
        ],
        [
          -50.6,
          -40
        ],
        [
          0,
          -40
        ],
        [
          36.800000000000004,
          -36
        ],
        [
          67.16,
          -22.400000000000002
        ],
        [
          92,
          0
        ],
        [
          67.16,
          22.400000000000002
        ],
        [
          36.800000000000004,
          36
        ],
        [
          0,
          40
        ],
        [
          -50.6,
          40
        ],
        [
          -80.96,
          32.8
        ],
        [
          -92,
          22.400000000000002
        ]
      ],
      deck: [
        [
          -87,
          -19.6
        ],
        [
          -76.56,
          -28.7
        ],
        [
          -47.85,
          -35
        ],
        [
          0,
          -35
        ],
        [
          34.800000000000004,
          -31.5
        ],
        [
          63.51,
          -19.6
        ],
        [
          87,
          0
        ],
        [
          63.51,
          19.6
        ],
        [
          34.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -47.85,
          35
        ],
        [
          -76.56,
          28.7
        ],
        [
          -87,
          19.6
        ]
      ]
    },
    warship: {
      length: 170,
      beam: 72,
      deckHeight: 28,
      hullMass: 23e3,
      loadCapacity: 850,
      acceleration: 44,
      turnRate: 0.314159265,
      obstacles: [
        {
          x: -45,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 34,
          y: 0,
          radius: 16,
          type: "gun"
        },
        {
          x: -58,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        60,
        0,
        35
      ],
      mastHeight: 102,
      weaponPivot: [
        34,
        0,
        28
      ],
      hull: [
        [
          -85,
          -20.160000000000004
        ],
        [
          -74.8,
          -29.52
        ],
        [
          -46.75000000000001,
          -36
        ],
        [
          0,
          -36
        ],
        [
          34,
          -32.4
        ],
        [
          62.05,
          -20.160000000000004
        ],
        [
          85,
          0
        ],
        [
          62.05,
          20.160000000000004
        ],
        [
          34,
          32.4
        ],
        [
          0,
          36
        ],
        [
          -46.75000000000001,
          36
        ],
        [
          -74.8,
          29.52
        ],
        [
          -85,
          20.160000000000004
        ]
      ],
      deck: [
        [
          -80,
          -17.360000000000003
        ],
        [
          -70.4,
          -25.419999999999998
        ],
        [
          -44,
          -31
        ],
        [
          0,
          -31
        ],
        [
          32,
          -27.900000000000002
        ],
        [
          58.4,
          -17.360000000000003
        ],
        [
          80,
          0
        ],
        [
          58.4,
          17.360000000000003
        ],
        [
          32,
          27.900000000000002
        ],
        [
          0,
          31
        ],
        [
          -44,
          31
        ],
        [
          -70.4,
          25.419999999999998
        ],
        [
          -80,
          17.360000000000003
        ]
      ]
    },
    bombardShip: {
      length: 184,
      beam: 70,
      deckHeight: 30,
      hullMass: 31e3,
      loadCapacity: 1300,
      acceleration: 30,
      turnRate: 0.226892803,
      obstacles: [
        {
          x: -50,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 30,
          y: 0,
          radius: 23,
          type: "mortar"
        },
        {
          x: -63,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        38,
        0,
        54
      ],
      mastHeight: 58,
      weaponPivot: [
        30,
        0,
        30
      ],
      hull: [
        [
          -92,
          -19.6
        ],
        [
          -80.96,
          -28.7
        ],
        [
          -50.6,
          -35
        ],
        [
          0,
          -35
        ],
        [
          36.800000000000004,
          -31.5
        ],
        [
          67.16,
          -19.6
        ],
        [
          92,
          0
        ],
        [
          67.16,
          19.6
        ],
        [
          36.800000000000004,
          31.5
        ],
        [
          0,
          35
        ],
        [
          -50.6,
          35
        ],
        [
          -80.96,
          28.7
        ],
        [
          -92,
          19.6
        ]
      ],
      deck: [
        [
          -87,
          -16.8
        ],
        [
          -76.56,
          -24.599999999999998
        ],
        [
          -47.85,
          -30
        ],
        [
          0,
          -30
        ],
        [
          34.800000000000004,
          -27
        ],
        [
          63.51,
          -16.8
        ],
        [
          87,
          0
        ],
        [
          63.51,
          16.8
        ],
        [
          34.800000000000004,
          27
        ],
        [
          0,
          30
        ],
        [
          -47.85,
          30
        ],
        [
          -76.56,
          24.599999999999998
        ],
        [
          -87,
          16.8
        ]
      ]
    },
    fireShip: {
      length: 158,
      beam: 60,
      deckHeight: 26,
      hullMass: 19e3,
      loadCapacity: 700,
      acceleration: 56,
      turnRate: 0.453785606,
      obstacles: [
        {
          x: -41,
          y: 0,
          radius: 6,
          type: "mast"
        },
        {
          x: 25,
          y: 0,
          radius: 18,
          type: "flame"
        },
        {
          x: -54,
          y: 0,
          radius: 23,
          type: "cabin"
        }
      ],
      weaponMount: [
        67,
        0,
        32
      ],
      mastHeight: 44,
      weaponPivot: [
        25,
        0,
        26
      ],
      hull: [
        [
          -79,
          -16.8
        ],
        [
          -69.52,
          -24.599999999999998
        ],
        [
          -43.45,
          -30
        ],
        [
          0,
          -30
        ],
        [
          31.6,
          -27
        ],
        [
          57.67,
          -16.8
        ],
        [
          79,
          0
        ],
        [
          57.67,
          16.8
        ],
        [
          31.6,
          27
        ],
        [
          0,
          30
        ],
        [
          -43.45,
          30
        ],
        [
          -69.52,
          24.599999999999998
        ],
        [
          -79,
          16.8
        ]
      ],
      deck: [
        [
          -74,
          -14.000000000000002
        ],
        [
          -65.12,
          -20.5
        ],
        [
          -40.7,
          -25
        ],
        [
          0,
          -25
        ],
        [
          29.6,
          -22.5
        ],
        [
          54.019999999999996,
          -14.000000000000002
        ],
        [
          74,
          0
        ],
        [
          54.019999999999996,
          14.000000000000002
        ],
        [
          29.6,
          22.5
        ],
        [
          0,
          25
        ],
        [
          -40.7,
          25
        ],
        [
          -65.12,
          20.5
        ],
        [
          -74,
          14.000000000000002
        ]
      ]
    },
    carrier: {
      length: 224,
      beam: 106,
      deckHeight: 32,
      hullMass: 55e3,
      loadCapacity: 5200,
      acceleration: 32,
      turnRate: 0.20943951,
      obstacles: [
        {
          x: -60,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: 26,
          y: 0,
          radius: 8,
          type: "mast"
        },
        {
          x: -76,
          y: 0,
          radius: 26,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 128,
      weaponPivot: null,
      hull: [
        [
          -112,
          -29.680000000000003
        ],
        [
          -98.56,
          -43.46
        ],
        [
          -61.60000000000001,
          -53
        ],
        [
          0,
          -53
        ],
        [
          44.800000000000004,
          -47.7
        ],
        [
          81.75999999999999,
          -29.680000000000003
        ],
        [
          112,
          0
        ],
        [
          81.75999999999999,
          29.680000000000003
        ],
        [
          44.800000000000004,
          47.7
        ],
        [
          0,
          53
        ],
        [
          -61.60000000000001,
          53
        ],
        [
          -98.56,
          43.46
        ],
        [
          -112,
          29.680000000000003
        ]
      ],
      deck: [
        [
          -107,
          -26.880000000000003
        ],
        [
          -94.16,
          -39.36
        ],
        [
          -58.85,
          -48
        ],
        [
          0,
          -48
        ],
        [
          42.800000000000004,
          -43.2
        ],
        [
          78.11,
          -26.880000000000003
        ],
        [
          107,
          0
        ],
        [
          78.11,
          26.880000000000003
        ],
        [
          42.800000000000004,
          43.2
        ],
        [
          0,
          48
        ],
        [
          -58.85,
          48
        ],
        [
          -94.16,
          39.36
        ],
        [
          -107,
          26.880000000000003
        ]
      ]
    },
    shipOfTheLine: {
      length: 292,
      beam: 144,
      deckHeight: 38,
      hullMass: 72e3,
      loadCapacity: 3800,
      acceleration: 24,
      turnRate: 0.148352986,
      obstacles: [
        {
          x: -53,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -10,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: 76,
          y: 0,
          radius: 4,
          type: "mast"
        },
        {
          x: -126,
          y: 0,
          radius: 20,
          type: "cabin"
        }
      ],
      weaponMount: null,
      mastHeight: 150,
      mastHeights: [
        118,
        150,
        136
      ],
      mastBeamScales: [
        0.79,
        1,
        0.88
      ],
      weaponPivot: null,
      hull: [
        [
          -146,
          -40.32000000000001
        ],
        [
          -128.48,
          -59.04
        ],
        [
          -80.30000000000001,
          -72
        ],
        [
          0,
          -72
        ],
        [
          58.400000000000006,
          -64.8
        ],
        [
          106.58,
          -40.32000000000001
        ],
        [
          146,
          0
        ],
        [
          106.58,
          40.32000000000001
        ],
        [
          58.400000000000006,
          64.8
        ],
        [
          0,
          72
        ],
        [
          -80.30000000000001,
          72
        ],
        [
          -128.48,
          59.04
        ],
        [
          -146,
          40.32000000000001
        ]
      ],
      deck: [
        [
          -141,
          -37.52
        ],
        [
          -124.08,
          -54.94
        ],
        [
          -77.55000000000001,
          -67
        ],
        [
          0,
          -67
        ],
        [
          56.400000000000006,
          -60.300000000000004
        ],
        [
          102.92999999999999,
          -37.52
        ],
        [
          141,
          0
        ],
        [
          102.92999999999999,
          37.52
        ],
        [
          56.400000000000006,
          60.300000000000004
        ],
        [
          0,
          67
        ],
        [
          -77.55000000000001,
          67
        ],
        [
          -124.08,
          54.94
        ],
        [
          -141,
          37.52
        ]
      ]
    }
  }
};

// ../sketch-rts-six-player-structural-before-0f31/src/shared/det-math.ts
var S1 = -0.16666666666666632;
var S2 = 0.00833333333332249;
var S3 = -1984126982985795e-19;
var S4 = 27557313707070068e-22;
var S5 = -25050760253406863e-24;
var S6 = 158969099521155e-24;
var C1 = 0.0416666666666666;
var C2 = -0.001388888888887411;
var C3 = 2480158728947673e-20;
var C4 = -27557314351390663e-23;
var C5 = 2087572321298175e-24;
var C6 = -11359647557788195e-27;
var INV_PIO2 = 0.6366197723675814;
var PIO2_1 = 1.5707963267341256;
var PIO2_1T = 6077100506506192e-26;
var PIO2_2 = 6077100506303966e-26;
var PIO2_2T = 20222662487959506e-37;
var PI_4 = 0.7853981633974483;
var MAX_ARGUMENT = 823549.6;
function kernelSin(x, y, hasTail) {
  const z = x * x;
  const w = z * z;
  const r = S2 + z * (S3 + z * S4) + z * w * (S5 + z * S6);
  const v = z * x;
  if (!hasTail) return x + v * (S1 + z * r);
  return x - (z * (0.5 * y - v * r) - y - v * S1);
}
function kernelCos(x, y) {
  const z = x * x;
  const w = z * z;
  const r = z * (C1 + z * (C2 + z * C3)) + w * w * (C4 + z * (C5 + z * C6));
  const hz = 0.5 * z;
  const u = 1 - hz;
  return u + (1 - u - hz + (z * r - x * y));
}
function reduce(x) {
  if (!(Math.abs(x) <= MAX_ARGUMENT)) throw new Error(`det-math: angle ${x} outside the supported range`);
  const n = Math.round(x * INV_PIO2);
  const first = x - n * PIO2_1;
  let w = n * PIO2_1T;
  const r = first - n * PIO2_2;
  w = n * PIO2_2T - (first - r - n * PIO2_2);
  const head = r - w;
  return { n, head, tail: r - head - w };
}
function detSin(x) {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (Math.abs(x) <= PI_4) return x === 0 ? x : kernelSin(x, 0, false);
  const { n, head, tail } = reduce(x);
  switch (n & 3) {
    case 0:
      return kernelSin(head, tail, true);
    case 1:
      return kernelCos(head, tail);
    case 2:
      return -kernelSin(head, tail, true);
    default:
      return -kernelCos(head, tail);
  }
}
function detCos(x) {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (Math.abs(x) <= PI_4) return kernelCos(x, 0);
  const { n, head, tail } = reduce(x);
  switch (n & 3) {
    case 0:
      return kernelCos(head, tail);
    case 1:
      return -kernelSin(head, tail, true);
    case 2:
      return -kernelCos(head, tail);
    default:
      return kernelSin(head, tail, true);
  }
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-geometry.ts
var shipGeometry = ship_geometry_default.ships;
var SHIP_CAMERA = ship_geometry_default.camera;
var SHIP_KINDS = Object.keys(shipGeometry);
var SHIP_SIZE_MULTIPLIER = 1.2;
var AUTHORED_DEFAULT_SHIP_SCALE = 1.1;
var DEFAULT_SHIP_SCALE = AUTHORED_DEFAULT_SHIP_SCALE * SHIP_SIZE_MULTIPLIER;
function isShipKind(kind) {
  return kind in shipGeometry;
}
function authoredShipScale(ship) {
  return ship.deckScale ?? (ship.cargoCapacity === void 0 ? AUTHORED_DEFAULT_SHIP_SCALE : Math.sqrt(ship.cargoCapacity / (ship.kind === "carrier" ? 24 : 8)));
}
function shipScale(ship) {
  return authoredShipScale(ship) * SHIP_SIZE_MULTIPLIER;
}
var profiles = /* @__PURE__ */ new WeakMap();
function shipProfile(ship) {
  if (!isShipKind(ship.kind)) return void 0;
  const scale2 = shipScale(ship), cached2 = profiles.get(ship);
  if (cached2 && cached2.kind === ship.kind && cached2.scale === scale2 && cached2.fittings === ship.fittings) return cached2.profile;
  const profile = computeShipProfile(ship, ship.kind, scale2);
  profiles.set(ship, { kind: ship.kind, scale: scale2, fittings: ship.fittings, profile });
  return profile;
}
function computeShipProfile(ship, kind, scale2) {
  const raw = shipGeometry[kind];
  return {
    ...raw,
    length: raw.length * scale2,
    beam: raw.beam * scale2,
    deckHeight: raw.deckHeight * scale2,
    mastHeight: raw.mastHeight * scale2,
    hullMass: raw.hullMass * scale2 ** 3,
    loadCapacity: raw.loadCapacity * scale2 ** 2,
    hull: raw.hull.map(([x, y]) => ({ x: x * scale2, y: y * scale2 })),
    deck: raw.deck.map(([x, y]) => ({ x: x * scale2, y: y * scale2 })),
    weaponMount: raw.weaponMount?.map((value) => value * scale2) ?? null,
    weaponPivot: raw.weaponPivot?.map((value) => value * scale2) ?? null,
    obstacles: [...raw.obstacles.filter((o) => !["gun", "mortar", "flame"].includes(o.type) || !ship.fittings), ...(ship.fittings ?? []).map((fitting) => ({ ...fitting, type: "weapon" }))].map((o) => ({ ...o, x: o.x * ("accepts" in o ? 1 : scale2), y: o.y * ("accepts" in o ? 1 : scale2), radius: o.radius * ("accepts" in o ? 1 : scale2) }))
  };
}
var shipLists = /* @__PURE__ */ new WeakMap();
function shipsIn(units2) {
  const cached2 = shipLists.get(units2);
  if (cached2?.length === units2.length) return cached2.ships;
  const ships = units2.filter((unit) => isShipKind(unit.kind));
  shipLists.set(units2, { length: units2.length, ships });
  return ships;
}
function localToWorld(ship, point) {
  const angle2 = ship.sailing?.heading ?? 0, c = detCos(angle2), s = detSin(angle2);
  return { x: ship.x + point.x * c - point.y * s, y: ship.y + point.x * s + point.y * c };
}
function worldToLocal(ship, point) {
  const angle2 = ship.sailing?.heading ?? 0, c = detCos(angle2), s = detSin(angle2), x = point.x - ship.x, y = point.y - ship.y;
  return { x: x * c + y * s, y: -x * s + y * c };
}
function circleInPolygon(point, radius, polygon) {
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], dx = b.x - a.x, dy = b.y - a.y;
    if ((dx * (point.y - a.y) - dy * (point.x - a.x)) / Math.hypot(dx, dy) < radius - 1e-6) return false;
  }
  return true;
}
function shipPassengers(units2, ship) {
  return units2.filter((unit) => unit.deck?.shipId === ship.id);
}
function distanceToHull(ship, world) {
  const profile = shipProfile(ship);
  if (!profile) return Math.hypot(world.x - ship.x, world.y - ship.y);
  const point = worldToLocal(ship, world);
  if (circleInPolygon(point, 0, profile.hull)) return 0;
  let gap = Infinity;
  for (let i = 0; i < profile.hull.length; i++) {
    const a = profile.hull[i], b = profile.hull[(i + 1) % profile.hull.length], dx = b.x - a.x, dy = b.y - a.y;
    const t = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy)));
    gap = Math.min(gap, Math.hypot(point.x - a.x - dx * t, point.y - a.y - dy * t));
  }
  return gap;
}
function hullGap(a, b) {
  const aa = shipProfile(a), bb = shipProfile(b);
  if (!aa || !bb) return Infinity;
  if (hullContact(a, b)) return 0;
  return Math.min(...aa.hull.map((point) => distanceToHull(b, localToWorld(a, point))), ...bb.hull.map((point) => distanceToHull(a, localToWorld(b, point))));
}
function hullContact(a, b) {
  const aa = shipProfile(a), bb = shipProfile(b);
  if (!aa || !bb) return void 0;
  const ap = aa.hull.map((p) => localToWorld(a, p)), bp = bb.hull.map((p) => localToWorld(b, p));
  let overlap = Infinity, normal = { x: 1, y: 0 };
  for (const polygon of [ap, bp]) for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i], q = polygon[(i + 1) % polygon.length], length = Math.hypot(q.x - p.x, q.y - p.y);
    const axis = { x: -(q.y - p.y) / length, y: (q.x - p.x) / length };
    const av = ap.map((p2) => p2.x * axis.x + p2.y * axis.y), bv = bp.map((p2) => p2.x * axis.x + p2.y * axis.y);
    const forward = Math.max(...av) - Math.min(...bv), backward = Math.max(...bv) - Math.min(...av);
    const depth = Math.min(forward, backward);
    if (depth <= 0) return void 0;
    if (depth < overlap) {
      overlap = depth;
      normal = forward <= backward ? axis : { x: -axis.x, y: -axis.y };
    }
  }
  return { ...normal, overlap };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-handling.ts
var partMaxima = /* @__PURE__ */ new WeakMap();
function shipPartMax(ship) {
  const profile = shipProfile(ship);
  const cached2 = partMaxima.get(profile);
  if (cached2?.maxHp === ship.maxHp) return cached2.parts;
  const parts = Object.freeze({
    rigging: Math.round(profile.length * 0.55),
    rudder: Math.round(profile.beam * 0.8),
    cabin: ship.kind === "cutter" ? 0 : Math.round(ship.maxHp * 0.4)
  });
  partMaxima.set(profile, { maxHp: ship.maxHp, parts });
  return parts;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/item-index.ts
var indexes = /* @__PURE__ */ new WeakMap();
function itemIndex(items) {
  let index = indexes.get(items);
  if (index?.count === items.length)
    return index;
  index = { count: items.length, byId: /* @__PURE__ */ new Map(), byCarrier: /* @__PURE__ */ new Map(), byShip: /* @__PURE__ */ new Map() };
  for (const item of items) {
    index.byId.set(item.id, item);
    for (const [id, map] of [[item.carrierId, index.byCarrier], [item.shipId, index.byShip]]) {
      if (!id)
        continue;
      const list = map.get(id);
      if (list)
        list.push(item);
      else
        map.set(id, [item]);
    }
  }
  indexes.set(items, index);
  return index;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/hypot.ts
function hypot2(x, y) {
  const absX = Math.abs(x), absY = Math.abs(y);
  if (absX === Infinity || absY === Infinity) return Infinity;
  const max = Math.max(absX, absY);
  if (max === 0) return 0;
  const a = absX / max, b = absY / max;
  return Math.sqrt(a * a + b * b) * max;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/time.ts
var SIM_TICKS_PER_SECOND = 20;
function seconds(value) {
  return Math.max(1, Math.round(value * SIM_TICKS_PER_SECOND));
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/wind-field.ts
var DEFAULT_WIND = { direction: Math.PI / 4, speed: 80 };
var WIND_CHANGE_INTERVAL_TICKS = seconds(8 * 60);

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-wind.ts
var SAIL_RULES = {
  trimRate: Math.PI / 3,
  setRate: 0.8,
  billowRate: 2,
  auxiliaryShare: 0.2,
  // RTS courses deliberately sail closer than historical square-riggers.
  // Each rig retains its own no-go sector without making an upwind order
  // spend almost all its travel crossing sideways across the map.
  lateen: { noGoAngle: Math.PI * 38 / 180, maxAngle: Math.PI * 65 / 180 },
  lug: { noGoAngle: Math.PI * 43 / 180, maxAngle: Math.PI * 65 / 180 },
  square: { noGoAngle: Math.PI * 48 / 180, maxAngle: Math.PI * 50 / 180 }
};
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
var POLAR_KNOTS = {
  lateen: [[SAIL_RULES.lateen.noGoAngle, 0], [SAIL_RULES.lateen.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.66]],
  lug: [[SAIL_RULES.lug.noGoAngle, 0], [SAIL_RULES.lug.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.78]],
  square: [[SAIL_RULES.square.noGoAngle, 0], [SAIL_RULES.square.noGoAngle + Math.PI / 15, 0.84], [Math.PI / 2, 0.96], [Math.PI * 2 / 3, 1], [Math.PI, 0.97]]
};
function polar(rig, angle2) {
  const noGo = SAIL_RULES[rig].noGoAngle;
  if (angle2 <= noGo) return 0;
  const knots = POLAR_KNOTS[rig];
  for (let i = 1; i < knots.length; i++) {
    const [end, high] = knots[i], [start, low] = knots[i - 1];
    if (angle2 <= end) {
      const t = clamp((angle2 - start) / (end - start), 0, 1);
      return low + (high - low) * t * t * (3 - 2 * t);
    }
  }
  return knots.at(-1)[1];
}
function bestBeatAngle(rig) {
  let best = SAIL_RULES[rig].noGoAngle, bestVmg = 0;
  for (let degree = 1; degree < 90; degree++) {
    const angle2 = degree * Math.PI / 180, vmg = polar(rig, angle2) * detCos(angle2);
    if (vmg > bestVmg) {
      bestVmg = vmg;
      best = angle2;
    }
  }
  return best;
}
var BEAT_ANGLES = { lateen: bestBeatAngle("lateen"), lug: bestBeatAngle("lug"), square: bestBeatAngle("square") };

// ../sketch-rts-six-player-structural-before-0f31/src/shared/terrain.ts
var CELL_GROUND = {
  ".": { land: true, sea: false, pace: 1, drag: 1 },
  ",": { land: true, sea: true, pace: 0.75, drag: 1.6 },
  m: { land: true, sea: false, pace: 0.6, drag: 2 },
  "=": { land: true, sea: false, pace: 1, drag: 1 },
  T: { land: false, sea: false, pace: 0, drag: 1 },
  "#": { land: false, sea: false, pace: 0, drag: 1 },
  "~": { land: false, sea: true, pace: 0, drag: 1 }
};
var PASSABLE = {
  land: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].land)),
  sea: new Set(Object.keys(CELL_GROUND).filter((char) => CELL_GROUND[char].sea))
};
var UNREACHED = 1073741823;
var UNKNOWN = -2;
var STRAIGHT = 5;
var DIAGONAL = 7;
var FIELD_CACHE = 128;
var GOAL_FIELD_CACHE = 8192;
var SECTOR = 10;
var MAX_REGIONS = 64;
var GROUND_WEIGHT = 4;
var BUCKETS = 64;
var GOAL_REACH = 3;
function isWalkable(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
function isOpenGround(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = routing(map, terrain, mover);
  return state.walk[padAt(state, x, y)] === 1;
}
function cellCenter(terrain, index) {
  const col = index % terrain.cols;
  const row = (index - col) / terrain.cols;
  return { x: (col + 0.5) * terrain.cell, y: (row + 0.5) * terrain.cell };
}
function isFootprintBuildable(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, "land");
  return everyFootprintCell(terrain, x, y, radius, (at2, cell) => state.walk[at2] === 1 && terrain.cells[cell] !== "," && terrain.levels?.[cell] !== "2");
}
function isShoreFootprint(map, x, y, radius) {
  const terrain = map.terrain;
  if (!terrain) return false;
  const land = runtime(terrain, "land");
  const sea = runtime(terrain, "sea");
  const { labels, deep } = wholesOf(sea);
  let dry = false;
  let wet = false;
  const fits = everyFootprintCell(terrain, x, y, radius, (at2, cell) => {
    if (land.walk[at2] === 1) dry = true;
    if (sea.walk[at2] === 1 && deep[labels[at2]] >= OPEN_WATER) wet = true;
    return (sea.walk[at2] === 1 || land.walk[at2] === 1) && terrain.levels?.[cell] !== "2";
  });
  return fits && dry && wet;
}
var OPEN_WATER = 64;
function shoreSpots(map, radius) {
  const terrain = map.terrain;
  if (!terrain) return [];
  const sea = runtime(terrain, "sea");
  const known = (sea.shores ??= /* @__PURE__ */ new Map()).get(radius);
  if (known) return known;
  const spots = [];
  const { labels, deep } = wholesOf(sea);
  if (deep.some((cells) => cells >= OPEN_WATER)) {
    const land = runtime(terrain, "land"), width = terrain.cols + 1;
    const dry = new Uint32Array(width * (terrain.rows + 1));
    const wet = new Uint32Array(dry.length), blocked = new Uint32Array(dry.length);
    for (let row = 0; row < terrain.rows; row++) {
      let d = 0, w = 0, b = 0;
      for (let col = 0; col < terrain.cols; col++) {
        const cell = row * terrain.cols + col, at2 = (row + 1) * (terrain.cols + 2) + col + 1;
        d += land.walk[at2] === 1 ? 1 : 0;
        w += sea.walk[at2] === 1 && deep[labels[at2]] >= OPEN_WATER ? 1 : 0;
        b += land.walk[at2] !== 1 && sea.walk[at2] !== 1 || terrain.levels?.[cell] === "2" ? 1 : 0;
        const out = (row + 1) * width + col + 1;
        dry[out] = dry[out - width] + d;
        wet[out] = wet[out - width] + w;
        blocked[out] = blocked[out - width] + b;
      }
    }
    const half = footprintHalf(radius, terrain.cell);
    const first = Math.ceil((terrain.cell / 2 - half) / terrain.cell - 0.5);
    const last = Math.ceil((terrain.cell / 2 + half) / terrain.cell - 0.5) - 1;
    const total = (field, left, top, right, bottom) => field[bottom * width + right] - field[top * width + right] - field[bottom * width + left] + field[top * width + left];
    for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
      const col = index % terrain.cols, row = Math.floor(index / terrain.cols);
      const left = col + first, top = row + first, right = col + last + 1, bottom = row + last + 1;
      if (left < 0 || top < 0 || right > terrain.cols || bottom > terrain.rows) continue;
      if (!total(blocked, left, top, right, bottom) && total(dry, left, top, right, bottom) && total(wet, left, top, right, bottom))
        spots.push(cellCenter(terrain, index));
    }
  }
  sea.shores.set(radius, spots);
  return spots;
}
function footprintHalf(radius, cell) {
  return Math.ceil(2 * radius / cell) * cell / 2;
}
function snapToFootprint(map, radius, point) {
  const terrain = map.terrain;
  if (!terrain) return { x: point.x, y: point.y };
  const cell = terrain.cell;
  const offset = Math.ceil(2 * radius / cell) % 2 === 1 ? cell / 2 : 0;
  return { x: Math.round((point.x - offset) / cell) * cell + offset, y: Math.round((point.y - offset) / cell) * cell + offset };
}
function footprintCells(cell, x, y, radius) {
  const half = footprintHalf(radius, cell);
  const first = (from) => Math.ceil(from / cell - 0.5);
  return { left: first(x - half), right: first(x + half) - 1, top: first(y - half), bottom: first(y + half) - 1 };
}
function everyFootprintCell(terrain, x, y, radius, passes) {
  const size = terrain.cell;
  const width = terrain.cols + 2;
  const { left, right, top, bottom } = footprintCells(size, x, y, radius);
  for (let row = top; row <= bottom; row += 1) {
    for (let col = left; col <= right; col += 1) {
      if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return false;
      if (!passes((row + 1) * width + col + 1, row * terrain.cols + col)) return false;
    }
  }
  return true;
}
function walkableGoal(map, x, y, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return { x, y };
  const state = runtime(terrain, mover);
  const cx = Math.min(Math.max(x, 0), map.width);
  const cy = Math.min(Math.max(y, 0), map.height);
  const at2 = padAt(state, Math.min(cx, terrain.cols * terrain.cell - 1e-3), Math.min(cy, terrain.rows * terrain.cell - 1e-3));
  if (state.walk[at2] === 1) return { x: cx, y: cy };
  const nearest = nearestWalkable(state, at2);
  return nearest < 0 ? { x: cx, y: cy } : centerOf(state, nearest);
}
function walkDestination(map, from, goal, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return goal;
  const ground = runtime(terrain, mover);
  const state = routing(map, terrain, mover);
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (start < 0 || target < 0 || ground.walk[target] !== 1) return goal;
  const near = nearestWalkable(state, start);
  if (near < 0) return goal;
  const tiles = tilesOf(state);
  const aim = reachableTarget(state, ground, tiles, near, target);
  if (state.walk[aim] === 1) return aim === target ? goal : centerOf(state, aim);
  const field = goalFieldOf(state, ground, tiles, aim).field;
  const index = local(field.box, near, state.width);
  if (index < 0 || field.dist[index] >= UNREACHED) return goal;
  let at2 = near;
  for (let next = downhill(state, field, at2); next >= 0; next = downhill(state, field, at2)) at2 = next;
  return centerOf(state, at2);
}
function tilesOf(state) {
  if (state.tiles) return state.tiles;
  const { terrain } = state;
  const columns = Math.ceil(terrain.cols / SECTOR);
  const rows = Math.ceil(terrain.rows / SECTOR);
  const tiles = {
    columns,
    rows,
    nodes: /* @__PURE__ */ new Map(),
    borders: /* @__PURE__ */ new Map(),
    region: new Int32Array(state.walk.length).fill(-1),
    island: new Int32Array(state.walk.length).fill(-1),
    goals: /* @__PURE__ */ new Map(),
    exits: /* @__PURE__ */ new Map(),
    nearest: /* @__PURE__ */ new Map()
  };
  state.tiles = tiles;
  const all = Array.from({ length: columns * rows }, (_, sector) => sector);
  for (const sector of all) labelRegions(state, tiles, sector);
  for (const sector of all) for (const lower of [0, 1]) layWindows(state, tiles, sector * 2 + lower);
  for (const sector of all) linkSector(state, tiles, sector);
  labelIslands(state, tiles);
  return tiles;
}
function sectorBox(state, tiles, sector) {
  const col = sector % tiles.columns * SECTOR;
  const row = Math.floor(sector / tiles.columns) * SECTOR;
  return { left: col + 1, top: row + 1, width: Math.min(SECTOR, state.terrain.cols - col), height: Math.min(SECTOR, state.terrain.rows - row) };
}
function sectorOf(state, tiles, at2) {
  const col = at2 % state.width - 1;
  const row = Math.floor(at2 / state.width) - 1;
  return Math.floor(row / SECTOR) * tiles.columns + Math.floor(col / SECTOR);
}
function local(box, at2, width) {
  const col = at2 % width;
  const row = (at2 - col) / width;
  if (col < box.left || row < box.top || col >= box.left + box.width || row >= box.top + box.height) return -1;
  return (row - box.top) * box.width + (col - box.left);
}
function labelRegions(state, tiles, sector) {
  const { walk, offsets, width } = state;
  const box = sectorBox(state, tiles, sector);
  for (let row = box.top; row < box.top + box.height; row += 1) for (let col = box.left; col < box.left + box.width; col += 1) tiles.region[row * width + col] = -1;
  let count = 0;
  for (let row = box.top; row < box.top + box.height; row += 1) {
    for (let col = box.left; col < box.left + box.width; col += 1) {
      const seed = row * width + col;
      if (walk[seed] !== 1 || tiles.region[seed] !== -1) continue;
      const label = sector * MAX_REGIONS + Math.min(count, MAX_REGIONS - 1);
      count += 1;
      tiles.region[seed] = label;
      for (let index = 0, queue = [seed]; index < queue.length; index += 1) {
        const at2 = queue[index];
        for (let direction = 0; direction < 8; direction += 1) {
          const next = at2 + offsets[direction];
          if (walk[next] !== 1 || tiles.region[next] !== -1 || local(box, next, width) < 0 || !stepAllowed(state, at2, direction)) continue;
          tiles.region[next] = label;
          queue.push(next);
        }
      }
    }
  }
}
function labelIslands(state, tiles) {
  const { walk, offsets } = state;
  tiles.island.fill(-1);
  const queue = new Int32Array(walk.length);
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || tiles.island[seed] !== -1) continue;
    tiles.island[seed] = seed;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at2 = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at2 + offsets[direction];
        if (walk[next] !== 1 || tiles.island[next] !== -1 || !stepAllowed(state, at2, direction)) continue;
        tiles.island[next] = seed;
        queue[tail++] = next;
      }
    }
  }
}
function layWindows(state, tiles, border) {
  const sector = border >> 1;
  const lower = border & 1;
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [];
  tiles.borders.set(border, keys);
  if (lower ? row + 1 >= tiles.rows : col + 1 >= tiles.columns) return;
  const { walk, width } = state;
  const box = sectorBox(state, tiles, sector);
  const across = lower ? width : 1;
  const span = lower ? box.width : box.height;
  const first = lower ? (box.top + box.height - 1) * width + box.left : box.top * width + box.left + box.width - 1;
  const along = lower ? 1 : width;
  let run = [];
  const close = () => {
    if (run.length === 0) return;
    const key = run[0] * 4 + lower * 2;
    keys.push(key);
    const blank = () => ({ box, dist: new Int32Array(0), next: new Int32Array(0) });
    tiles.nodes.set(key, { key, sector, cells: run, across, field: blank(), edges: [] });
    const other = lower ? sector + tiles.columns : sector + 1;
    tiles.nodes.set(key + 1, { key: key + 1, sector: other, cells: run.map((cell) => cell + across), across: -across, field: blank(), edges: [] });
    run = [];
  };
  for (let step = 0; step < span; step += 1) {
    const at2 = first + step * along;
    if (walk[at2] === 1 && walk[at2 + across] === 1) run.push(at2);
    else close();
  }
  close();
}
function sectorNodes(tiles, sector) {
  const col = sector % tiles.columns;
  const row = Math.floor(sector / tiles.columns);
  const keys = [...tiles.borders.get(sector * 2) ?? [], ...tiles.borders.get(sector * 2 + 1) ?? []];
  if (col > 0) keys.push(...(tiles.borders.get((sector - 1) * 2) ?? []).map((key) => key + 1));
  if (row > 0) keys.push(...(tiles.borders.get((sector - tiles.columns) * 2 + 1) ?? []).map((key) => key + 1));
  return keys.sort((a, b) => a - b).map((key) => tiles.nodes.get(key));
}
function linkSector(state, tiles, sector) {
  const box = sectorBox(state, tiles, sector);
  const nodes = sectorNodes(tiles, sector);
  for (const node of nodes) node.field = growBox(state, box, node.cells);
  for (const from of nodes) {
    from.edges = [];
    for (const to of nodes) {
      if (to === from) continue;
      let cost = UNREACHED;
      for (const cell of from.cells) cost = Math.min(cost, to.field.dist[local(box, cell, state.width)]);
      if (cost < UNREACHED) from.edges.push({ to: to.key, cost });
    }
  }
}
var STEP_COLS = [1, 0, -1, 0, 1, -1, -1, 1];
var STEP_ROWS = [0, 1, 0, -1, 1, 1, -1, -1];
function growBox(state, box, seeds, costs) {
  const size = box.width * box.height;
  return growBoxInto(state, box, seeds, costs, { dist: new Int32Array(size), next: new Int32Array(size) });
}
function growBoxInto(state, box, seeds, costs, arrays) {
  const { walk, offsets, width, weight } = state;
  const columns = box.width;
  const rows = box.height;
  const localOffsets = [1, columns, -1, -columns, columns + 1, columns - 1, -columns - 1, -columns + 1];
  const origin = box.top * width + box.left;
  const { dist, next } = arrays;
  dist.fill(UNREACHED);
  next.fill(UNKNOWN);
  const buckets = state.boxBuckets;
  const order = seeds.map((_, index) => index);
  if (costs) order.sort((a, b) => costs[a] - costs[b] || a - b);
  const costOf = (index) => costs ? costs[order[index]] : 0;
  let seeded = 0;
  let pending = 0;
  for (let cost = order.length > 0 ? costOf(0) : 0; pending > 0 || seeded < order.length; cost += 1) {
    if (pending === 0) cost = costOf(seeded);
    for (; seeded < order.length && costOf(seeded) === cost; seeded += 1) {
      const index = local(box, seeds[order[seeded]], width);
      if (index < 0 || cost >= dist[index]) continue;
      dist[index] = cost;
      buckets[cost % BUCKETS].push(index);
      pending += 1;
    }
    const bucket = buckets[cost % BUCKETS];
    while (bucket.length > 0) {
      const index = bucket.pop();
      pending -= 1;
      if (dist[index] !== cost) continue;
      const col = index % columns;
      const row = (index - col) / columns;
      const at2 = origin + row * width + col;
      let directions = 255;
      if (col === 0) directions &= ~100;
      if (col === columns - 1) directions &= ~145;
      if (row === 0) directions &= ~200;
      if (row === rows - 1) directions &= ~50;
      for (let direction = 0; direction < 8; direction += 1) {
        if ((directions & 1 << direction) === 0) continue;
        const step = at2 + offsets[direction];
        if (walk[step] !== 1) continue;
        const there = index + localOffsets[direction];
        const reached = cost + (direction < 4 ? STRAIGHT : DIAGONAL) * weight[step];
        if (reached >= dist[there] || !stepAllowed(state, at2, direction)) continue;
        dist[there] = reached;
        buckets[reached % BUCKETS].push(there);
        pending += 1;
      }
    }
  }
  return { box, dist, next };
}
function downhill(state, field, at2) {
  const { walk, offsets, width } = state;
  const { box } = field;
  const index = local(box, at2, width);
  if (index < 0) return -1;
  const known = field.next[index];
  if (known !== UNKNOWN) return known;
  const col = index % box.width;
  const row = (index - col) / box.width;
  let best = -1;
  let bestCost = field.dist[index];
  for (let direction = 0; direction < 8; direction += 1) {
    const stepCol = col + STEP_COLS[direction];
    const stepRow = row + STEP_ROWS[direction];
    if (stepCol < 0 || stepRow < 0 || stepCol >= box.width || stepRow >= box.height) continue;
    const step = at2 + offsets[direction];
    const there = stepRow * box.width + stepCol;
    if (walk[step] !== 1 || field.dist[there] >= bestCost || !stepAllowed(state, at2, direction)) continue;
    bestCost = field.dist[there];
    best = step;
  }
  field.next[index] = best;
  return best;
}
function goalFieldOf(state, ground, tiles, target) {
  const known = tiles.goals.get(target);
  if (known) {
    tiles.goals.delete(target);
    tiles.goals.set(target, known);
    return known;
  }
  const sector = sectorOf(state, tiles, target);
  const col = sector % tiles.columns * SECTOR;
  const row = Math.floor(sector / tiles.columns) * SECTOR;
  const left = Math.max(0, col - SECTOR);
  const top = Math.max(0, row - SECTOR);
  const box = { left: left + 1, top: top + 1, width: Math.min(state.terrain.cols, col + 2 * SECTOR) - left, height: Math.min(state.terrain.rows, row + 2 * SECTOR) - top };
  const { seeds, costs } = goalSeeds(state, ground, target, box);
  const goal = { field: growBox(state, box, seeds, costs), seeds };
  if (tiles.goals.size >= GOAL_FIELD_CACHE) tiles.goals.delete(tiles.goals.keys().next().value);
  tiles.goals.set(target, goal);
  return goal;
}
function goalSeeds(state, ground, target, box) {
  if (state.walk[target] === 1) return { seeds: [target], costs: [0] };
  const { width, offsets } = state;
  const targetCol = target % width;
  const targetRow = Math.floor(target / width);
  const square = { left: targetCol - GOAL_REACH, top: targetRow - GOAL_REACH, width: 2 * GOAL_REACH + 1, height: 2 * GOAL_REACH + 1 };
  const seeds = [];
  const costs = [];
  const joined = /* @__PURE__ */ new Set([target]);
  for (let index = 0, queue = [target]; index < queue.length; index += 1) {
    const at2 = queue[index];
    if (state.walk[at2] === 1) {
      if (local(box, at2, width) >= 0) {
        seeds.push(at2);
        costs.push(Math.round(STRAIGHT * GROUND_WEIGHT * Math.sqrt((at2 % width - targetCol) ** 2 + (Math.floor(at2 / width) - targetRow) ** 2)));
      }
      continue;
    }
    for (let direction = 0; direction < 8; direction += 1) {
      const next = at2 + offsets[direction];
      if (joined.has(next) || ground.walk[next] !== 1 || !stepAllowed(ground, at2, direction) || local(square, next, width) < 0) continue;
      joined.add(next);
      queue.push(next);
    }
  }
  return { seeds, costs };
}
function reachableTarget(state, ground, tiles, near, target) {
  const island = tiles.island[near];
  if (state.walk[target] === 1 && tiles.island[target] === island) return target;
  if (goalFieldOf(state, ground, tiles, target).seeds.some((seed) => tiles.island[seed] === island)) return target;
  const key = target * state.walk.length + island;
  const known = tiles.nearest.get(key);
  if (known !== void 0) return known;
  const { terrain, width } = state;
  const col = target % width - 1;
  const row = Math.floor(target / width) - 1;
  let best = near;
  let bestDistance = Infinity;
  const consider = (c, r) => {
    if (c < 0 || r < 0 || c >= terrain.cols || r >= terrain.rows) return;
    const at2 = pad(state, c, r);
    if (tiles.island[at2] !== island) return;
    const gap = (c - col) ** 2 + (r - row) ** 2;
    if (gap < bestDistance || gap === bestDistance && at2 < best) {
      bestDistance = gap;
      best = at2;
    }
  };
  for (let ring = 1; ring <= Math.max(terrain.cols, terrain.rows) && ring * ring <= bestDistance; ring += 1) {
    const top = row - ring, bottom = row + ring;
    for (let c = col - ring; c <= col + ring; c += 1) {
      consider(c, top);
      consider(c, bottom);
    }
    for (let r = top + 1; r < bottom; r += 1) {
      consider(col - ring, r);
      consider(col + ring, r);
    }
  }
  if (tiles.nearest.size > 4096) tiles.nearest.clear();
  tiles.nearest.set(key, best);
  return best;
}
function walkingDistance(map, from, goal, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return Math.sqrt((from.x - goal.x) ** 2 + (from.y - goal.y) ** 2);
  const state = runtime(terrain, mover);
  const start = padAt(state, from.x, from.y);
  const target = padAt(state, goal.x, goal.y);
  if (state.walk[start] !== 1 || state.walk[target] !== 1) return void 0;
  const cost = exactField(state, target).dist[start];
  return cost >= UNREACHED ? void 0 : cost * terrain.cell / STRAIGHT;
}
function sameGround(map, a, b, mover = "land") {
  const terrain = map.terrain;
  if (!terrain) return true;
  const state = runtime(terrain, mover);
  const { labels } = wholesOf(state);
  const from = padAt(state, a.x, a.y);
  const to = padAt(state, b.x, b.y);
  return from >= 0 && to >= 0 && labels[from] !== 0 && labels[from] === labels[to];
}
function groundWholes(map, mover = "land") {
  return map.terrain ? wholesOf(runtime(map.terrain, mover)).count : 1;
}
function wholesOf(state) {
  if (state.wholes) return state.wholes;
  const { walk, offsets, terrain, width } = state;
  const labels = new Int32Array(walk.length);
  const queue = new Int32Array(walk.length);
  let count = 0;
  for (let seed = 0; seed < walk.length; seed += 1) {
    if (walk[seed] !== 1 || labels[seed] !== 0) continue;
    count += 1;
    labels[seed] = count;
    let tail = 0;
    queue[tail++] = seed;
    for (let head = 0; head < tail; head += 1) {
      const at2 = queue[head];
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at2 + offsets[direction];
        if (walk[next] !== 1 || labels[next] !== 0 || !stepAllowed(state, at2, direction)) continue;
        labels[next] = count;
        queue[tail++] = next;
      }
    }
  }
  const deep = new Int32Array(count + 1);
  for (let index = 0; index < terrain.cols * terrain.rows; index += 1) {
    if (terrain.cells[index] !== "~") continue;
    const col = index % terrain.cols;
    deep[labels[((index - col) / terrain.cols + 1) * width + col + 1]] += 1;
  }
  deep[0] = 0;
  state.wholes = { labels, count, deep };
  return state.wholes;
}
var overlays = /* @__PURE__ */ new WeakMap();
function routing(map, terrain, mover) {
  if (mover === "land") {
    const overlay = overlays.get(map);
    if (overlay && overlay.terrain === terrain) return overlay.state;
  }
  return runtime(terrain, mover);
}
var runtimes = /* @__PURE__ */ new WeakMap();
var lastTerrain;
var lastRuntimes = {};
function runtime(terrain, mover) {
  if (terrain !== lastTerrain) {
    lastTerrain = terrain;
    lastRuntimes = runtimes.get(terrain) ?? {};
    runtimes.set(terrain, lastRuntimes);
  }
  return mover === "land" ? lastRuntimes.land ??= createRuntime(terrain, "land") : lastRuntimes.sea ??= createRuntime(terrain, "sea");
}
function createRuntime(terrain, mover) {
  const width = terrain.cols + 2;
  const count = width * (terrain.rows + 2);
  const walk = new Uint8Array(count);
  const weight = new Uint8Array(count);
  const passable = PASSABLE[mover];
  for (let row = 0; row < terrain.rows; row += 1) {
    for (let col = 0; col < terrain.cols; col += 1) {
      const char = terrain.cells[row * terrain.cols + col];
      if (!passable.has(char)) continue;
      const at2 = (row + 1) * width + col + 1;
      walk[at2] = 1;
      weight[at2] = mover === "sea" ? GROUND_WEIGHT : Math.round(GROUND_WEIGHT / (CELL_GROUND[char]?.pace ?? 1));
    }
  }
  const offsets = Int32Array.from([1, width, -1, -width, width + 1, width - 1, -width - 1, -width + 1]);
  const state = {
    terrain,
    width,
    walk,
    weight,
    fields: /* @__PURE__ */ new Map(),
    clock: 0,
    spare: [],
    nearest: /* @__PURE__ */ new Map(),
    tops: new Int32Array(8),
    boxBuckets: Array.from({ length: BUCKETS }, () => []),
    offsets
  };
  return state;
}
function pad(state, col, row) {
  return (row + 1) * state.width + col + 1;
}
function padAt(state, x, y) {
  const { terrain } = state;
  const col = Math.floor(x / terrain.cell);
  const row = Math.floor(y / terrain.cell);
  if (col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows) return -1;
  return (row + 1) * state.width + col + 1;
}
function centerOf(state, at2) {
  const col = at2 % state.width - 1;
  const row = Math.floor(at2 / state.width) - 1;
  return { x: (col + 0.5) * state.terrain.cell, y: (row + 0.5) * state.terrain.cell };
}
function stepAllowed(state, at2, direction) {
  if (direction < 4) return true;
  const { walk, width } = state;
  const dx = direction === 4 || direction === 7 ? 1 : -1;
  const dy = direction === 4 || direction === 5 ? width : -width;
  return walk[at2 + dx] === 1 && walk[at2 + dy] === 1;
}
function exactField(state, target) {
  return cached(state, target, () => grow(state, [target]));
}
function cached(state, key, build) {
  state.clock += 1;
  const known = state.fields.get(key);
  if (known) {
    known.used = state.clock;
    return known;
  }
  if (state.fields.size >= FIELD_CACHE) {
    let oldest;
    let oldestUse = Infinity;
    for (const [candidate, field2] of state.fields) {
      if (field2.used < oldestUse) {
        oldestUse = field2.used;
        oldest = candidate;
      }
    }
    state.spare.push(state.fields.get(oldest));
    state.fields.delete(oldest);
  }
  const field = build();
  field.used = state.clock;
  state.fields.set(key, field);
  return field;
}
function grow(state, sources) {
  const { walk, offsets, tops } = state;
  const buckets = state.buckets ??= Array.from({ length: 8 }, () => new Int32Array(walk.length));
  const field = state.spare.pop() ?? { dist: new Int32Array(walk.length), next: new Int32Array(walk.length), used: 0 };
  const dist = field.dist;
  dist.fill(UNREACHED);
  field.next.fill(UNKNOWN);
  tops.fill(0);
  let pending = 0;
  for (const source of sources) {
    dist[source] = 0;
    buckets[0][tops[0]++] = source;
    pending += 1;
  }
  for (let cost = 0; pending > 0; cost += 1) {
    const slot = cost & 7;
    const bucket = buckets[slot];
    while (tops[slot] > 0) {
      const at2 = bucket[--tops[slot]];
      pending -= 1;
      if (dist[at2] !== cost) continue;
      for (let direction = 0; direction < 8; direction += 1) {
        const next = at2 + offsets[direction];
        if (walk[next] !== 1) continue;
        const reached = cost + (direction < 4 ? STRAIGHT : DIAGONAL);
        if (reached >= dist[next] || !stepAllowed(state, at2, direction)) continue;
        dist[next] = reached;
        const into = reached & 7;
        buckets[into][tops[into]++] = next;
        pending += 1;
      }
    }
  }
  return field;
}
function nearestWalkable(state, at2) {
  if (at2 >= 0 && state.walk[at2] === 1) return at2;
  const known = state.nearest.get(at2);
  if (known !== void 0) return known;
  const { terrain, width } = state;
  const col = at2 < 0 ? 0 : at2 % width - 1;
  const row = at2 < 0 ? 0 : Math.floor(at2 / width) - 1;
  let best = -1;
  let bestDistance = Infinity;
  const limit = Math.max(terrain.cols, terrain.rows);
  for (let ring = 1; ring <= limit; ring += 1) {
    if (ring * ring > bestDistance) break;
    for (let r = row - ring; r <= row + ring; r += 1) {
      for (let c = col - ring; c <= col + ring; c += 1) {
        if (Math.max(Math.abs(c - col), Math.abs(r - row)) !== ring) continue;
        if (c < 0 || r < 0 || c >= terrain.cols || r >= terrain.rows) continue;
        const index = pad(state, c, r);
        if (state.walk[index] !== 1) continue;
        const gap = (c - col) * (c - col) + (r - row) * (r - row);
        if (gap < bestDistance || gap === bestDistance && index < best) {
          bestDistance = gap;
          best = index;
        }
      }
    }
  }
  if (state.nearest.size > 4096) state.nearest.clear();
  state.nearest.set(at2, best);
  return best;
}
var __shoreExperimentCounts = { walking: 0, walkingBlocked: 0, exactField: 0, grow: 0, factory: 0, multiQuery: 0, multiBuild: 0 };
function __shoreExperimentReset() {
  for (const key of Object.keys(__shoreExperimentCounts)) __shoreExperimentCounts[key] = 0;
}
function __shoreExperimentStats() {
  return { ...__shoreExperimentCounts };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/navigation-math.ts
var planes = /* @__PURE__ */ new WeakMap();
var supportCandidates = /* @__PURE__ */ new WeakSet();
function supportScale(polygon) {
  if (!supportCandidates.has(polygon) || polygon.length < 12) return;
  let scale2 = 0;
  for (const p of polygon) {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) return;
    scale2 = Math.max(scale2, Math.abs(p.x), Math.abs(p.y));
  }
  if (scale2 < 1e-100 || scale2 > 1e100) return;
  let wraps = 0;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], c = polygon[(i + 2) % polygon.length];
    const ax = b.x - a.x, ay = b.y - a.y, bx = c.x - b.x, by = c.y - b.y;
    const left = ax * by, right = ay * bx;
    const error = 16 * Number.EPSILON * (Math.abs(left) + Math.abs(right) + scale2 * (Math.abs(ax) + Math.abs(ay) + Math.abs(bx) + Math.abs(by))) + 16 * Number.MIN_VALUE;
    if (!(left - right > error)) return;
    const upperA = ay > 0 || ay === 0 && ax > 0;
    const upperB = by > 0 || by === 0 && bx > 0;
    if (!upperA && upperB) wraps++;
  }
  if (wraps !== 1) return;
  return scale2;
}
function projectionSupport(polygon, x, y, start, scale2, minimum, state) {
  const first = polygon[start];
  let index = start, value = first.x * x + first.y * y;
  const error = 8 * Number.EPSILON * scale2 * (Math.abs(x) + Math.abs(y)) + 32 * Number.MIN_VALUE;
  for (let direction = -1; direction <= 1; direction += 2) {
    let cursor = start;
    for (let visited = 1; visited < polygon.length; visited++) {
      cursor += direction;
      if (cursor < 0) cursor += polygon.length;
      else if (cursor === polygon.length) cursor = 0;
      const point = polygon[cursor], projection = point.x * x + point.y * y;
      if (minimum) {
        if (projection < value) index = cursor;
        value = Math.min(value, projection);
        if (projection > value + error) break;
      } else {
        if (projection > value) index = cursor;
        value = Math.max(value, projection);
        if (projection < value - error) break;
      }
    }
  }
  state.index = index;
  return value;
}
function polygonPlaneState(polygon) {
  let state = planes.get(polygon);
  if (!state) {
    state = { result: [], scale: supportScale(polygon), minIndex: 0, maxIndex: 0, index: 0, maxima: 0 };
    planes.set(polygon, state);
  }
  return state;
}
function appendSupportingPlane(polygon, state) {
  const i = state.result.length;
  const a = polygon[i], b = polygon[(i + 1) % polygon.length], x = a.y - b.y, y = b.x - a.x;
  let min = Infinity;
  if (state.scale !== void 0 && i) {
    min = projectionSupport(polygon, x, y, state.minIndex, state.scale, true, state);
    state.minIndex = state.index;
  } else if (state.scale !== void 0) {
    for (let j = 0; j < polygon.length; j++) {
      const p = polygon[j], v = p.x * x + p.y * y;
      if (v < min) state.minIndex = j;
      min = Math.min(min, v);
    }
  } else {
    for (const p of polygon) {
      const v = p.x * x + p.y * y;
      min = Math.min(min, v);
    }
  }
  const plane = { x, y, min, max: NaN };
  state.result.push(plane);
  return plane;
}
function polygonSupportingPlanes(polygon) {
  const state = polygonPlaneState(polygon);
  while (state.result.length < polygon.length) appendSupportingPlane(polygon, state);
  return state.result;
}
function polygonPlanes(polygon) {
  const state = polygonPlaneState(polygon);
  polygonSupportingPlanes(polygon);
  while (state.maxima < polygon.length) appendPlaneMaximum(polygon, state);
  return state.result;
}
function appendPlaneMaximum(polygon, state) {
  const i = state.maxima, plane = state.result[i], x = plane.x, y = plane.y;
  let max = -Infinity;
  if (state.scale !== void 0 && i) {
    max = projectionSupport(polygon, x, y, state.maxIndex, state.scale, false, state);
    state.maxIndex = state.index;
  } else if (state.scale !== void 0) {
    for (let j = 0; j < polygon.length; j++) {
      const p = polygon[j], v = p.x * x + p.y * y;
      if (v > max) state.maxIndex = j;
      max = Math.max(max, v);
    }
  } else {
    for (const p of polygon) {
      const v = p.x * x + p.y * y;
      max = Math.max(max, v);
    }
  }
  plane.max = max;
  state.maxima++;
}
function polygonTouchesCellForPolygon(polygon, left, top, cell) {
  const state = polygonPlaneState(polygon);
  for (let i = 0; i < polygon.length; i++) {
    const p = state.result[i] ?? appendSupportingPlane(polygon, state);
    if (state.maxima === i) appendPlaneMaximum(polygon, state);
    const min = (p.x >= 0 ? left : left + cell) * p.x + (p.y >= 0 ? top : top + cell) * p.y;
    const max = min + cell * (Math.abs(p.x) + Math.abs(p.y));
    if (p.max <= min + 1e-7 || max <= p.min + 1e-7) return false;
  }
  return true;
}
function pointSegmentDistanceSquared(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, l = dx * dx + dy * dy;
  const t = l ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l)) : 0;
  return (p.x - a.x - dx * t) ** 2 + (p.y - a.y - dy * t) ** 2;
}
function capsuleClearsCircles(a, b, radius, obstacles) {
  return obstacles.every((o) => pointSegmentDistanceSquared(o, a, b) >= (o.radius + radius) ** 2 - 1e-7);
}
function diskInConvex(p, radius, polygon) {
  return polygonPlanes(polygon).every((axis) => p.x * axis.x + p.y * axis.y >= axis.min + radius * Math.hypot(axis.x, axis.y) - 1e-6);
}
function convexHull(points) {
  const sorted = [...points].sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  const half = (first, limit, step) => {
    const out = [];
    for (let i = first; i !== limit; i += step) {
      const p = sorted[i];
      const last = out[out.length - 1];
      if (last && (p.x - last.x) ** 2 + (p.y - last.y) ** 2 < 1e-16) continue;
      while (out.length > 1) {
        const a = out[out.length - 2], b = out[out.length - 1];
        const turn = cross(a, b, p), abX = b.x - a.x, abY = b.y - a.y, bpX = p.x - b.x, bpY = p.y - b.y;
        if (turn > 0 && turn * turn > 1e-20 * (abX * abX + abY * abY) * (bpX * bpX + bpY * bpY)) break;
        out.pop();
      }
      out.push(p);
    }
    return out;
  };
  const lower = half(0, sorted.length, 1), upper = half(sorted.length - 1, -1, -1);
  lower.pop();
  upper.pop();
  const result = lower;
  for (const point of upper) result.push(point);
  if (result.length > 1 && (result[0].x - result[result.length - 1].x) ** 2 + (result[0].y - result[result.length - 1].y) ** 2 < 1e-16) result.pop();
  supportCandidates.add(result);
  return result;
}
function segmentDistanceSquared(a, b, c, d) {
  const cross = (p, q, r) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
  if (cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0 && Math.max(Math.min(a.x, b.x), Math.min(c.x, d.x)) <= Math.min(Math.max(a.x, b.x), Math.max(c.x, d.x)) && Math.max(Math.min(a.y, b.y), Math.min(c.y, d.y)) <= Math.min(Math.max(a.y, b.y), Math.max(c.y, d.y)))
    return 0;
  return Math.min(pointSegmentDistanceSquared(a, c, d), pointSegmentDistanceSquared(b, c, d), pointSegmentDistanceSquared(c, a, b), pointSegmentDistanceSquared(d, a, b));
}
function clipToConvex(a, b, polygon) {
  let low = 0, high = 1;
  const dx = b.x - a.x, dy = b.y - a.y;
  const state = polygonPlaneState(polygon);
  for (let i = 0; i < polygon.length; i++) {
    const plane = state.result[i] ?? appendSupportingPlane(polygon, state);
    const d = dx * plane.x + dy * plane.y, need = plane.min - a.x * plane.x - a.y * plane.y;
    if (Math.abs(d) < 1e-10) {
      if (need > 1e-7)
        return;
      continue;
    }
    if (d > 0)
      low = Math.max(low, need / d);
    else
      high = Math.min(high, need / d);
    if (low > high + 1e-9)
      return;
  }
  return [low, high];
}
function expandConvex(polygon, amount) {
  const ps = polygonSupportingPlanes(polygon);
  if (!ps.length) return [];
  const result = [];
  let a = ps[ps.length - 1], am = a.min - amount * Math.hypot(a.x, a.y);
  for (const b of ps) {
    const bm = b.min - amount * Math.hypot(b.x, b.y), det = a.x * b.y - a.y * b.x;
    result.push({ x: (am * b.y - a.y * bm) / det, y: (a.x * bm - am * b.x) / det });
    a = b;
    am = bm;
  }
  if (amount >= 0 && Number.isFinite(amount)) supportCandidates.add(result);
  return result;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/navigation-masks.ts
var angle = Math.PI / 4;

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-navigation.ts
var waterFields = /* @__PURE__ */ new WeakMap();
function openWaterBox(map, left, top, right, bottom) {
  if (left < 0 || top < 0 || right > map.width || bottom > map.height)
    return false;
  const t = map.terrain;
  if (!t)
    return true;
  let field = waterFields.get(t);
  if (!field || field.cells !== t.cells || field.cols !== t.cols || field.rows !== t.rows) {
    const w2 = t.cols + 1, sums = new Uint32Array(w2 * (t.rows + 1));
    for (let y = 0; y < t.rows; y++) {
      let row = 0;
      for (let x = 0; x < t.cols; x++) {
        row += CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea ? 0 : 1;
        sums[(y + 1) * w2 + x + 1] = sums[y * w2 + x + 1] + row;
      }
    }
    field = { cells: t.cells, cols: t.cols, rows: t.rows, sums };
    waterFields.set(t, field);
  }
  const x0 = Math.max(0, Math.floor(left / t.cell)), y0 = Math.max(0, Math.floor(top / t.cell));
  const x1 = Math.min(t.cols, Math.ceil(right / t.cell)), y1 = Math.min(t.rows, Math.ceil(bottom / t.cell)), w = t.cols + 1, s = field.sums;
  return s[y1 * w + x1] - s[y0 * w + x1] - s[y1 * w + x0] + s[y0 * w + x0] === 0;
}
var DIRECTIONS = 8;
var ANGLE = Math.PI / 4;
function headingDifference(from, to) {
  return ((to - from + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
}
function outline(hull, pose) {
  const c = detCos(pose.heading), s = detSin(pose.heading);
  return hull.map((p) => ({ x: pose.x + p.x * c - p.y * s, y: pose.y + p.x * s + p.y * c }));
}
function clearOutline(map, polygon) {
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (const point of polygon) {
    left = Math.min(left, point.x);
    right = Math.max(right, point.x);
    top = Math.min(top, point.y);
    bottom = Math.max(bottom, point.y);
  }
  if (left < -1e-7 || top < -1e-7 || right > map.width + 1e-7 || bottom > map.height + 1e-7)
    return false;
  const terrain = map.terrain;
  if (!terrain)
    return true;
  if (openWaterBox(map, left, top, right, bottom))
    return true;
  const cell = terrain.cell;
  for (let row = Math.floor(top / cell); row <= Math.floor((bottom - 1e-7) / cell); row++)
    for (let col = Math.floor(left / cell); col <= Math.floor((right - 1e-7) / cell); col++) {
      const char = col < 0 || row < 0 || col >= terrain.cols || row >= terrain.rows ? void 0 : terrain.cells[row * terrain.cols + col];
      if (!CELL_GROUND[char ?? "."]?.sea && polygonTouchesCellForPolygon(polygon, col * cell, row * cell, cell))
        return false;
    }
  return true;
}
function hullFits(map, ship, pose = { x: ship.x, y: ship.y, heading: ship.sailing?.heading ?? 0 }) {
  const profile = shipProfile(ship);
  return Boolean(profile && clearOutline(map, outline(profile.hull, pose)));
}
function nearestShipPose(map, ship, point, seaOrigin = ship, accepts = () => true) {
  const preferred = ship.sailing?.heading ?? 0;
  const seaStart = isWalkable(map, seaOrigin.x, seaOrigin.y, "sea") ? seaOrigin : walkableGoal(map, seaOrigin.x, seaOrigin.y, "sea");
  const headings = [preferred, ...Array.from({ length: DIRECTIONS }, (_, i) => i * ANGLE)];
  if (!map.terrain) {
    const hull = outline(shipProfile(ship).hull, { x: 0, y: 0, heading: preferred });
    const x = Math.max(-Math.min(...hull.map((p) => p.x)), Math.min(map.width - Math.max(...hull.map((p) => p.x)), point.x));
    const y = Math.max(-Math.min(...hull.map((p) => p.y)), Math.min(map.height - Math.max(...hull.map((p) => p.y)), point.y));
    if (hullFits(map, ship, { x, y, heading: preferred }) && accepts({ x, y, heading: preferred })) return { x, y, heading: preferred };
    for (let distance4 = 16; distance4 <= shipProfile(ship).length * 4; distance4 += 16) for (let i = 0; i < 16; i++) {
      const angle2 = i * Math.PI / 8, at2 = { x: x + distance4 * detCos(angle2), y: y + distance4 * detSin(angle2), heading: preferred };
      if (hullFits(map, ship, at2) && accepts(at2)) return at2;
    }
    return void 0;
  }
  for (const heading of headings)
    if (hullFits(map, ship, { ...point, heading }) && accepts({ ...point, heading }) && sameGround(map, seaStart, point, "sea"))
      return { ...point, heading };
  const t = map.terrain, col = Math.max(0, Math.min(t.cols - 1, Math.floor(point.x / t.cell))), row = Math.max(0, Math.min(t.rows - 1, Math.floor(point.y / t.cell)));
  for (let ring = 0; ring <= Math.max(t.cols, t.rows); ring++) {
    let best, score = Infinity;
    for (let y = Math.max(0, row - ring); y <= Math.min(t.rows - 1, row + ring); y++)
      for (let x = Math.max(0, col - ring); x <= Math.min(t.cols - 1, col + ring); x++) {
        if (ring && Math.max(Math.abs(x - col), Math.abs(y - row)) !== ring)
          continue;
        const at2 = { x: (x + 0.5) * t.cell, y: (y + 0.5) * t.cell };
        if (!CELL_GROUND[t.cells[y * t.cols + x] ?? "."]?.sea || !sameGround(map, seaStart, at2, "sea"))
          continue;
        for (const heading of headings) {
          const value = Math.hypot(at2.x - point.x, at2.y - point.y) + Math.abs(headingDifference(preferred, heading)) * 1e-3;
          if (value < score && hullFits(map, ship, { ...at2, heading }) && accepts({ ...at2, heading })) {
            best = { ...at2, heading };
            score = value;
          }
        }
      }
    if (best)
      return best;
  }
  return void 0;
}
function createSearchWorkspace(size) {
  return {
    costs: new Float64Array(size),
    parents: new Int32Array(size),
    stamps: new Uint32Array(size),
    trafficFits: new Int32Array(size),
    basePotentials: new Float64Array(size / DIRECTIONS),
    baseStamps: new Uint32Array(size / DIRECTIONS),
    generation: 0
  };
}
var search = createSearchWorkspace(0);
var Frontier = class {
  length = 0;
  poppedCost = 0;
  ids = new Int32Array(1024);
  costs = new Float64Array(1024);
  scores = new Float64Array(1024);
  reset() {
    this.length = 0;
    if (this.ids.length > 65536) {
      this.ids = new Int32Array(65536);
      this.costs = new Float64Array(65536);
      this.scores = new Float64Array(65536);
    }
    return this;
  }
  save() {
    return Array.from({ length: this.length }, (_, i) => ({ id: this.ids[i], cost: this.costs[i], score: this.scores[i] }));
  }
  restore(slots) {
    this.reset();
    const capacity = Math.max(1024, 2 ** Math.ceil(Math.log2(Math.max(1, slots.length))));
    if (this.ids.length < capacity) {
      this.ids = new Int32Array(capacity);
      this.costs = new Float64Array(capacity);
      this.scores = new Float64Array(capacity);
    }
    this.length = slots.length;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      this.ids[i] = slot.id;
      this.costs[i] = slot.cost;
      this.scores[i] = slot.score;
    }
    return this;
  }
  push(id, cost, score) {
    if (this.length === this.ids.length) {
      const ids = new Int32Array(this.length * 2), costs = new Float64Array(this.length * 2), scores = new Float64Array(this.length * 2);
      ids.set(this.ids);
      costs.set(this.costs);
      scores.set(this.scores);
      this.ids = ids;
      this.costs = costs;
      this.scores = scores;
    }
    let i = this.length++;
    while (i) {
      const parent = i - 1 >>> 2;
      if (!this.less(score, id, this.scores[parent], this.ids[parent]))
        break;
      this.copy(parent, i);
      i = parent;
    }
    this.ids[i] = id;
    this.costs[i] = cost;
    this.scores[i] = score;
  }
  copy(from, to) {
    this.ids[to] = this.ids[from];
    this.costs[to] = this.costs[from];
    this.scores[to] = this.scores[from];
  }
  less(aScore, aId, bScore, bId) {
    return aScore < bScore || aScore === bScore && aId < bId;
  }
  pop() {
    const result = this.ids[0], last = --this.length;
    this.poppedCost = this.costs[0];
    const id = this.ids[last], cost = this.costs[last], score = this.scores[last];
    if (last) {
      let i = 0;
      while (i * 4 + 1 < last) {
        let child = i * 4 + 1;
        const end = Math.min(last, child + 4);
        for (let next = child + 1; next < end; next++)
          if (this.less(this.scores[next], this.ids[next], this.scores[child], this.ids[child]))
            child = next;
        if (!this.less(this.scores[child], this.ids[child], score, id))
          break;
        this.copy(child, i);
        i = child;
      }
      this.ids[i] = id;
      this.costs[i] = cost;
      this.scores[i] = score;
    }
    return result;
  }
};
var routeFrontier = new Frontier();
var distanceFrontier = new Frontier();

// ../sketch-rts-six-player-structural-before-0f31/src/shared/veteran-skills.ts
var VETERAN_ACTIVE_SKILL_IDS = ["veteranRally", "veteranHealingWave", "veteranInnerFire"];
var VETERAN_SKILLS = {
  veteranResilience: {
    id: "veteranResilience",
    name: { zh: "\u767E\u6218\u4E4B\u8EAF", en: "Battle Hardened" },
    icon: "\u25C6",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\u3002", en: "Passive: take 25% less damage." },
    effect: { type: "passive", modifiers: { damageReduction: 0.25 } }
  },
  veteranMobility: {
    id: "veteranMobility",
    name: { zh: "\u8FC5\u6377\u884C\u52A8", en: "Swift Movement" },
    icon: "\u27A4",
    pool: "common",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 30%\u3002", en: "Passive: gain 30% movement speed." },
    effect: { type: "passive", modifiers: { moveSpeedMultiplier: 1.3 } }
  },
  veteranCommand: {
    id: "veteranCommand",
    name: { zh: "\u534F\u540C\u4F5C\u6218", en: "Coordinated Assault" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 35%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 35% attack speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { attackSpeedMultiplier: 1.35 } }
  },
  veteranVigilance: {
    id: "veteranVigilance",
    name: { zh: "\u8B66\u6212\u4E92\u52A9", en: "Watchful Company" },
    icon: "\u25C7",
    pool: "common",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 18%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 160, including self, take 18% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 160, modifiers: { damageReduction: 0.18 } }
  },
  veteranRally: {
    id: "veteranRally",
    name: { zh: "\u6218\u6597\u53F7\u4EE4", en: "Rallying Cry" },
    icon: "\u2691",
    pool: "common",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A160 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 60%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002", en: "Active / autocast: up to 5 allies within 160 gain 60% attack speed for 8 seconds. Cooldown: 24 seconds." },
    effect: { type: "active", action: "buff", radius: 160, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { attackSpeedMultiplier: 1.6 } }
  },
  veteranPhalanx: {
    id: "veteranPhalanx",
    name: { zh: "\u575A\u5B88\u9635\u7EBF", en: "Hold the Line" },
    icon: "\u25A3",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A130 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 25%\uFF1B\u9632\u62A4\u5149\u73AF\u53EA\u53D6\u6700\u5F3A\u3002", en: "Aura: allies within 130, including self, take 25% less damage. Only the strongest protection aura applies." },
    effect: { type: "aura", radius: 130, modifiers: { damageReduction: 0.25 } }
  },
  veteranSteadyAim: {
    id: "veteranSteadyAim",
    name: { zh: "\u6C89\u7740\u7784\u51C6", en: "Steady Aim" },
    icon: "\u25CE",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u7784\u51C6\u901F\u5EA6\u63D0\u9AD8 80%\uFF0C\u653B\u51FB\u901F\u5EA6\u63D0\u9AD8 20%\uFF1B\u79FB\u52A8\u4ECD\u9075\u5B88\u539F\u6709\u7784\u51C6\u9650\u5236\u3002", en: "Passive: gain 80% aiming speed and 20% attack speed. Movement retains its normal effect on aim." },
    effect: { type: "passive", modifiers: { aimSpeedMultiplier: 1.8, attackSpeedMultiplier: 1.2 } }
  },
  veteranMarch: {
    id: "veteranMarch",
    name: { zh: "\u884C\u519B\u9886\u961F", en: "March Leader" },
    icon: "\xBB",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A160 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u79FB\u52A8\u901F\u5EA6\u63D0\u9AD8 25%\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\u3002", en: "Aura: allies within 160, including self, gain 25% movement speed. Identical auras do not stack." },
    effect: { type: "aura", radius: 160, modifiers: { moveSpeedMultiplier: 1.25 } }
  },
  veteranHealingWave: {
    id: "veteranHealingWave",
    name: { zh: "\u7FA4\u4F53\u6062\u590D", en: "Restoring Wave" },
    icon: "\u271A",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A\u6062\u590D 180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u5404 90 \u70B9\u751F\u547D\uFF0C\u4F18\u5148\u4F24\u8005\uFF1B\u51B7\u5374 18 \u79D2\u3002\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Active / autocast: heal up to 5 allies within 180 for 90 health each, prioritizing wounded units. Cooldown: 18 seconds. Does not affect mechanical units." },
    effect: { type: "active", action: "heal", targets: { unitClasses: ["nonMechanical"] }, radius: 180, maxTargets: 5, cooldown: seconds(18), healAmount: 90 }
  },
  veteranInnerFire: {
    id: "veteranInnerFire",
    name: { zh: "\u5FC3\u7075\u4E4B\u706B", en: "Inner Fire" },
    icon: "\u2726",
    pool: "specialist",
    description: { zh: "\u4E3B\u52A8\uFF0F\u81EA\u52A8\u65BD\u653E\uFF1A180 \u8303\u56F4\u5185\u81F3\u591A 5 \u540D\u53CB\u519B\u53D7\u5230\u7684\u4F24\u5BB3\u964D\u4F4E 35%\uFF0C\u6301\u7EED 8 \u79D2\uFF1B\u51B7\u5374 24 \u79D2\u3002\u77ED\u65F6\u9632\u62A4\u53EA\u53D6\u6700\u5F3A\u3002", en: "Active / autocast: up to 5 allies within 180 take 35% less damage for 8 seconds. Cooldown: 24 seconds. Only the strongest temporary ward applies." },
    effect: { type: "active", action: "buff", radius: 180, maxTargets: 5, cooldown: seconds(24), duration: seconds(8), modifiers: { damageReduction: 0.35 } }
  },
  veteranRenewal: {
    id: "veteranRenewal",
    name: { zh: "\u4F11\u517B\u5E87\u62A4", en: "Renewing Presence" },
    icon: "\u274B",
    pool: "specialist",
    description: { zh: "\u5149\u73AF\uFF1A150 \u8303\u56F4\u5185\u53CB\u519B\uFF08\u542B\u81EA\u8EAB\uFF09\u6BCF\u79D2\u6062\u590D 3 \u70B9\u751F\u547D\uFF1B\u540C\u7C7B\u5149\u73AF\u4E0D\u53E0\u52A0\uFF0C\u4E0D\u4F5C\u7528\u4E8E\u673A\u68B0\u5355\u4F4D\u3002", en: "Aura: allies within 150, including self, restore 3 health per second. Identical auras do not stack. Does not affect mechanical units." },
    effect: { type: "aura", targets: { unitClasses: ["nonMechanical"] }, radius: 150, modifiers: { regenPerSecond: 3 } }
  },
  veteranSiegeDrill: {
    id: "veteranSiegeDrill",
    name: { zh: "\u6D4B\u8DDD\u8BAD\u7EC3", en: "Rangefinding" },
    icon: "\u2316",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u81EA\u8EAB\u653B\u51FB\u5C04\u7A0B\u63D0\u9AD8 10%\uFF1B\u6700\u5C0F\u5C04\u7A0B\u4FDD\u6301\u4E0D\u53D8\u3002", en: "Passive: gain 10% attack range. Minimum range is unchanged." },
    effect: { type: "passive", modifiers: { attackRangeMultiplier: 1.1 } }
  },
  veteranEndurance: {
    id: "veteranEndurance",
    name: { zh: "\u575A\u97E7\u6062\u590D", en: "Enduring Recovery" },
    icon: "\u2665",
    pool: "specialist",
    description: { zh: "\u88AB\u52A8\uFF1A\u975E\u673A\u68B0\u5355\u4F4D\u81EA\u8EAB\u6BCF\u79D2\u6062\u590D 6 \u70B9\u751F\u547D\u3002", en: "Passive: non-mechanical units restore 6 health per second." },
    effect: { type: "passive", targets: { unitClasses: ["nonMechanical"] }, modifiers: { regenPerSecond: 6 } }
  }
};
function isVeteranSkillId(value) {
  return typeof value === "string" && Object.hasOwn(VETERAN_SKILLS, value);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/veteran-stats.ts
function veteranWeaponRange(unit, baseRange) {
  if (!isVeteranSkillId(unit.veteranSkill)) return baseRange;
  const effect = VETERAN_SKILLS[unit.veteranSkill].effect;
  return baseRange * (effect.type === "passive" ? effect.modifiers.attackRangeMultiplier ?? 1 : 1);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-equipment.ts
var SHIP_HULL_COST = { cutter: 160, transport: 240, warship: 320, bombardShip: 470, fireShip: 340, carrier: 420, shipOfTheLine: 1080 };
var SHIP_WEAPONS = {
  shipCannon: { cost: 220, mass: 160, hp: 90, damage: 20, range: 312, cooldown: seconds(2), aimSpeed: 440, weapon: { presentation: "cannon", delivery: "bolt", radius: 8, blastRadius: 48, maxHits: 1, navalMultiplier: 2, hullDamageShare: 1.25 }, art: "warship" },
  shipMortar: { cost: 330, mass: 240, hp: 100, damage: 36, range: 576, cooldown: seconds(3.6), aimSpeed: 400, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2, navalMultiplier: 1.7, hullDamageShare: 1.5 }, art: "bombardShip" },
  flameProjector: { cost: 180, mass: 120, hp: 80, damage: 10, range: 144, cooldown: seconds(1.2), aimSpeed: 480, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 }, art: "fireShip" }
};
function shipMounts(ship) {
  const profile = shipProfile(ship);
  if (!profile) return [];
  let mounts = mountProfiles.get(profile);
  if (!mounts) {
    const computed = computeShipMounts(ship);
    for (const mount of computed) {
      Object.freeze(mount.accepts);
      Object.freeze(mount);
    }
    mounts = Object.freeze(computed);
    mountProfiles.set(profile, mounts);
  }
  return mounts;
}
var mountProfiles = /* @__PURE__ */ new WeakMap();
function computeShipMounts(ship) {
  const p = shipProfile(ship);
  if (!p)
    return [];
  const scale2 = shipScale(ship);
  const mount = (id, x, y, bearing, halfArc, accepts) => ({ id, x: x * scale2, y: y * scale2, radius: 12 * scale2, bearing, halfArc, accepts });
  const all = ["shipCannon", "shipMortar", "flameProjector"];
  const bow = (x, accepts = all) => mount("bow", x, 0, 0, Math.PI / 6, accepts);
  if (ship.kind === "cutter")
    return [bow(28, ["shipCannon"])];
  if (ship.kind === "transport")
    return [bow(32, ["shipCannon", "flameProjector"])];
  const side = ["shipCannon", "flameProjector"];
  if (ship.kind === "shipOfTheLine") {
    const positions2 = [[-74, 53], [-32, 54], [10, 53], [50, 48.9]];
    return positions2.flatMap(([x, breadth2], i) => [
      mount(`port${i}`, x, -breadth2, -Math.PI / 2, 35 * Math.PI / 180, ["shipCannon"]),
      mount(`starboard${i}`, x, breadth2, Math.PI / 2, 35 * Math.PI / 180, ["shipCannon"])
    ]);
  }
  const positions = ship.kind === "carrier" ? [35, 0, -35] : ship.kind === "warship" ? [15, -15] : [-10];
  const breadth = ship.kind === "carrier" ? 38 : 23;
  return [bow(ship.kind === "carrier" ? 80 : p.weaponPivot[0] / scale2), ...positions.flatMap((x, i) => [
    mount(`port${i}`, x, -breadth, -Math.PI / 2, 35 * Math.PI / 180, side),
    mount(`starboard${i}`, x, breadth, Math.PI / 2, 35 * Math.PI / 180, side)
  ])];
}
function isShipEquipment(kind) {
  return kind in SHIP_WEAPONS;
}
function installedWeapons(snapshot, ship) {
  return (itemIndex(snapshot.items).byShip.get(ship.id) ?? []).filter((item) => item.mountId && isShipEquipment(item.kind));
}
function shipNeedsRepair(snapshot, ship) {
  const max = shipPartMax(ship);
  return ship.hp < ship.maxHp || (ship.shipParts?.rigging ?? max.rigging) < max.rigging || (ship.shipParts?.rudder ?? max.rudder) < max.rudder || (ship.shipParts?.cabin ?? max.cabin) < max.cabin || installedWeapons(snapshot, ship).some((item) => (item.durability ?? SHIP_WEAPONS[item.kind].hp) < SHIP_WEAPONS[item.kind].hp);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/unit-value.ts
var VETERANCY_GAIN_PER_STAR = 1 / 3;
function unitValue(def) {
  return def.cost > 0 ? def.cost : (def.creepFoodPower ?? 2) * 36 * (def.threat ?? 1);
}
function creepGoldBounty(foodPower, threat = 1) {
  return Math.max(20, Math.round((20 * foodPower + 1.25 * foodPower ** 2) * threat / 5) * 5);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/damage-types.ts
var DAMAGE_PROFILES = {
  MELEE_CUT: { school: "physical", delivery: "melee", physicalType: "cut", origin: "unit" },
  MELEE_PIERCE: { school: "physical", delivery: "melee", physicalType: "pierce", origin: "unit" },
  MELEE_BLUNT: { school: "physical", delivery: "melee", physicalType: "blunt", origin: "unit" },
  RANGED_PIERCE: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "unit" },
  RANGED_BLUNT: { school: "physical", delivery: "ranged", physicalType: "blunt", origin: "unit" },
  FIRE_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", element: "fire", origin: "unit" },
  MAGIC_MELEE: { school: "magic", delivery: "melee", element: "arcane", origin: "unit" },
  MAGIC_RANGED: { school: "magic", delivery: "ranged", element: "arcane", origin: "unit" },
  FIRE_RANGED: { school: "magic", delivery: "ranged", element: "fire", origin: "unit" },
  TOWER_ARROW: { school: "physical", delivery: "ranged", physicalType: "pierce", origin: "tower" },
  ARCANE: { school: "magic", delivery: "effect", element: "arcane", origin: "spell" },
  BURNING: { school: "magic", delivery: "effect", element: "fire", origin: "spell" },
  POISON: { school: "magic", delivery: "effect", element: "poison", origin: "spell" },
  LIGHTNING: { school: "magic", delivery: "ranged", element: "lightning", origin: "spell" },
  STORM: { school: "magic", delivery: "effect", element: "lightning", origin: "spell" },
  EXPLOSION: { school: "physical", delivery: "effect", physicalType: "blunt", origin: "spell" }
};
var P = DAMAGE_PROFILES;
var UNIT_DAMAGE_PROFILES = {
  worker: P.MELEE_CUT,
  footman: P.MELEE_CUT,
  archer: P.RANGED_PIERCE,
  horseArcher: P.RANGED_PIERCE,
  raider: P.MELEE_CUT,
  lancer: P.MELEE_PIERCE,
  ashWarden: P.MELEE_PIERCE,
  emberRavager: P.MELEE_CUT,
  cinderRunner: P.MELEE_CUT,
  sparkArcher: P.FIRE_ARROW,
  ashHexer: P.MAGIC_RANGED,
  knight: P.MELEE_CUT,
  priest: P.MAGIC_RANGED,
  summoner: P.MAGIC_RANGED,
  witch: P.MAGIC_RANGED,
  golem: P.MELEE_BLUNT,
  ashChieftain: P.MELEE_CUT,
  cinderRevenant: P.MELEE_CUT,
  spirit: P.MAGIC_MELEE,
  mercenary: P.MELEE_CUT,
  contractArcher: P.RANGED_PIERCE,
  fieldMedic: P.MAGIC_RANGED,
  wildling: P.MELEE_BLUNT,
  mossGnawer: P.MELEE_PIERCE,
  thornSlinger: P.RANGED_PIERCE,
  barkMender: P.MAGIC_RANGED,
  stonebackBrute: P.MELEE_BLUNT,
  gladeWitch: P.MAGIC_RANGED,
  // Bare transport/carrier hulls cannot attack; a mounted gun supplies its own profile.
  transport: P.MELEE_BLUNT,
  warship: P.RANGED_BLUNT,
  shipOfTheLine: P.RANGED_BLUNT,
  cutter: P.RANGED_PIERCE,
  bombardShip: P.RANGED_BLUNT,
  fireShip: P.FIRE_RANGED,
  carrier: P.MELEE_BLUNT,
  siegeRam: P.MELEE_BLUNT,
  ballista: P.RANGED_PIERCE,
  catapult: P.RANGED_BLUNT,
  organGun: P.RANGED_PIERCE,
  ancientStag: P.MELEE_PIERCE,
  murlocPeon: P.MELEE_PIERCE,
  murlocHunter: P.RANGED_PIERCE,
  tidePriest: P.MAGIC_RANGED,
  deepSnapper: P.MELEE_PIERCE,
  rubbleGolem: P.MELEE_BLUNT,
  rockGolem: P.MELEE_BLUNT,
  graniteGolem: P.MELEE_BLUNT,
  ogreWarrior: P.MELEE_BLUNT,
  ogreMage: P.MAGIC_RANGED,
  ogreLord: P.MELEE_BLUNT,
  spiderling: P.MELEE_PIERCE,
  venomSpider: P.MELEE_PIERCE,
  spiderQueen: P.MELEE_PIERCE,
  dragonWhelp: P.FIRE_RANGED,
  redDragon: P.FIRE_RANGED
};
var WEAPON_DAMAGE_PROFILES = {
  melee: P.MELEE_BLUNT,
  arrow: P.RANGED_PIERCE,
  spear: P.RANGED_PIERCE,
  stone: P.RANGED_BLUNT,
  magic: P.MAGIC_RANGED,
  fire: P.FIRE_RANGED,
  bolt: P.RANGED_PIERCE,
  cannon: P.RANGED_BLUNT,
  mortar: P.RANGED_BLUNT,
  flame: P.FIRE_RANGED,
  grapeshot: P.RANGED_PIERCE
};
var ITEM_DAMAGE_PROFILES = {
  greatSword: P.MELEE_CUT,
  shipCannon: P.RANGED_BLUNT,
  shipMortar: P.RANGED_BLUNT,
  flameProjector: P.FIRE_RANGED,
  flameCloak: P.BURNING,
  lightningRod: P.LIGHTNING,
  stormStaff: P.STORM,
  breachCharge: P.EXPLOSION
};
var ABILITY_DAMAGE_PROFILES = {
  curse: P.ARCANE,
  ashCurse: P.ARCANE,
  pinningBolt: P.RANGED_PIERCE,
  incendiaryFlume: P.FIRE_RANGED
};

// ../sketch-rts-six-player-structural-before-0f31/src/shared/damage-reduction.ts
var HEAVY_ARMOR_DAMAGE = { rangedUnit: 0.5, tower: 0.7 };
var DAMAGE_REDUCTION_RULES = {
  armor: { stacking: "highest", cap: 1 },
  equipment: { stacking: "add", cap: 0.3 },
  passive: { stacking: "highest", cap: 1 },
  aura: { stacking: "highest", cap: 1 },
  ward: { stacking: "highest", cap: 1 }
};
var GROUPS = Object.keys(DAMAGE_REDUCTION_RULES);

// ../sketch-rts-six-player-structural-before-0f31/src/shared/transport-role.ts
var TRANSPORT_COMBAT = {
  rangedDamageTaken: HEAVY_ARMOR_DAMAGE.tower,
  passengerDamageMultiplier: 0.5
};
function isTransportKind(kind) {
  return kind === "transport" || kind === "carrier";
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/catalog.ts
var SLOW_TICKS = seconds(3);
var POISON_TICKS = seconds(4);
var TIER_SUPPLY_CAP = { 2: 42, 3: 60 };
var UNIT_RULES = {
  worker: { hp: 70, speed: 60, radius: 15, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.7), cost: 75, trainTime: seconds(7), supplyUsed: 1, abilities: [] },
  footman: { hp: 145, speed: 62, radius: 18, attackDamage: 16, attackRange: 48, attackCooldown: seconds(1.1), cost: 100, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  archer: { hp: 83, speed: 60, radius: 16, attackDamage: 13, attackRange: 319.2, aimSpeed: 480, attackCooldown: seconds(1.5), cost: 115, trainTime: seconds(7.75), supplyUsed: 2, abilities: [] },
  // The cavalry strikes from the saddle with a reach a little under the lancer's 74 (it had a footman's, 48 and 52).
  horseArcher: { hp: 109, speed: 90, radius: 19, attackDamage: 10, attackRange: 264, aimSpeed: 600, attackCooldown: seconds(1.5), cost: 150, trainTime: seconds(10), supplyUsed: 2, abilities: [], tier: 2, aimMoveTolerance: 72 },
  raider: { hp: 115, speed: 82, radius: 18, attackDamage: 14, attackRange: 72, attackCooldown: seconds(1), cost: 115, trainTime: seconds(8.5), supplyUsed: 2, abilities: ["charge"], tier: 2 },
  lancer: { hp: 130, speed: 68, radius: 18, attackDamage: 18, attackRange: 74, attackCooldown: seconds(1.4), cost: 110, trainTime: seconds(8.75), supplyUsed: 2, abilities: [] },
  ashWarden: { hp: 165, speed: 60, radius: 19, attackDamage: 15, attackRange: 52, attackCooldown: seconds(1.15), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  emberRavager: { hp: 118, speed: 76, radius: 18, attackDamage: 20, attackRange: 52, attackCooldown: seconds(1.25), cost: 120, trainTime: seconds(9), supplyUsed: 2, abilities: [] },
  cinderRunner: { hp: 96, speed: 87, radius: 17, attackDamage: 14, attackRange: 48, attackCooldown: seconds(0.95), cost: 110, trainTime: seconds(8), supplyUsed: 2, abilities: [] },
  sparkArcher: { hp: 85, speed: 63, radius: 16, attackDamage: 9, attackRange: 288, aimSpeed: 540, attackCooldown: seconds(1.35), cost: 110, trainTime: seconds(7.25), supplyUsed: 2, abilities: [] },
  ashHexer: { hp: 82, speed: 64, radius: 16, attackDamage: 7, attackRange: 240, aimSpeed: 520, attackCooldown: seconds(1.7), cost: 140, trainTime: seconds(9), supplyUsed: 2, abilities: ["ashCurse"], tier: 2 },
  knight: { hp: 220, speed: 72, radius: 22, attackDamage: 24, attackRange: 72, attackCooldown: seconds(1.3), cost: 190, trainTime: seconds(11.5), supplyUsed: 3, abilities: ["charge"], armor: "heavy", tier: 3 },
  priest: { hp: 90, speed: 60, radius: 16, attackDamage: 7, attackRange: 201.6, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 135, trainTime: seconds(9.25), supplyUsed: 2, abilities: ["heal"], tier: 2 },
  summoner: { hp: 95, speed: 56, radius: 17, attackDamage: 8, attackRange: 218.4, aimSpeed: 400, attackCooldown: seconds(1.9), cost: 180, trainTime: seconds(10.5), supplyUsed: 2, abilities: ["summon"], tier: 2 },
  witch: { hp: 92, speed: 62, radius: 16, attackDamage: 8, attackRange: 252, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 145, trainTime: seconds(9.75), supplyUsed: 2, abilities: ["curse"], tier: 2 },
  golem: { unitClass: "mechanical", hp: 340, speed: 42, radius: 28, attackDamage: 34, attackRange: 58, attackCooldown: seconds(2.1), cost: 230, trainTime: seconds(14), supplyUsed: 4, abilities: [], armor: "heavy", tier: 3 },
  // Ember's heavies, raised in the ashen hall and heavy-armored like the grove's knight and golem, but built for
  // other jobs. The chieftain hunts casters and what they summon (half again as much damage to both); the revenant is
  // light for an elite and burns its wounds away, back to full health in about twenty seconds.
  ashChieftain: { hp: 210, speed: 66, radius: 20, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.2), cost: 190, trainTime: seconds(11), supplyUsed: 3, abilities: [], armor: "heavy", casterSlayer: 1.5, tier: 3 },
  cinderRevenant: { hp: 150, speed: 70, radius: 19, attackDamage: 21, attackRange: 52, attackCooldown: seconds(1.15), cost: 210, trainTime: seconds(12), supplyUsed: 3, abilities: [], armor: "heavy", regenPerSecond: 7, tier: 3 },
  spirit: { hp: 85, speed: 70, radius: 15, attackDamage: 13, attackRange: 55, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, abilities: [] },
  mercenary: { hp: 155, speed: 74, radius: 18, attackDamage: 28, attackRange: 62, attackCooldown: seconds(0.9), cost: 160, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  contractArcher: { hp: 93, speed: 64, radius: 16, attackDamage: 19, attackRange: 352.8, aimSpeed: 600, attackCooldown: seconds(1.35), cost: 145, trainTime: seconds(0.05), supplyUsed: 2, abilities: [] },
  fieldMedic: { hp: 105, speed: 62, radius: 16, attackDamage: 8, attackRange: 210.4, aimSpeed: 480, attackCooldown: seconds(1.7), cost: 155, trainTime: seconds(0.05), supplyUsed: 2, abilities: ["heal"] },
  wildling: { hp: 76, speed: 76, radius: 15, attackDamage: 10, attackRange: 42, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  mossGnawer: { hp: 54, speed: 84, radius: 13, attackDamage: 8, attackRange: 34, attackCooldown: seconds(1.3), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  thornSlinger: { hp: 83, speed: 68, radius: 18, attackDamage: 13, attackRange: 132, aimSpeed: 400, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [] },
  barkMender: { hp: 68, speed: 64, radius: 18, attackDamage: 7, attackRange: 88, aimSpeed: 400, attackCooldown: seconds(2.1), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: ["heal"] },
  stonebackBrute: { hp: 210, speed: 72, radius: 24, attackDamage: 28, attackRange: 48, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  gladeWitch: { hp: 110, speed: 66, radius: 22, attackDamage: 13, attackRange: 120, aimSpeed: 440, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["curse"] },
  // @@@ships - Both races can board every ship. Troop ferry passengers deal half damage;
  // warships have sturdier hulls and a cannon. Deck space and mass determine crew capacity.
  transport: { unitClass: "mechanical", hp: 270, speed: 64, radius: 30, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.transport, trainTime: seconds(12), supplyUsed: 1, abilities: [], naval: true, ...TRANSPORT_COMBAT },
  warship: { unitClass: "mechanical", hp: 320, speed: 60, radius: 28, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.warship + SHIP_WEAPONS.shipCannon.cost, trainTime: seconds(14), supplyUsed: 3, abilities: [], naval: true, weapon: SHIP_WEAPONS.shipCannon.weapon },
  // Four removable cannons are included in the purchase; the hull has no extra intrinsic shot.
  shipOfTheLine: { unitClass: "mechanical", hp: 740, speed: 46, radius: 48, attackDamage: 20, attackRange: 312, aimSpeed: 440, attackCooldown: seconds(2), cost: SHIP_HULL_COST.shipOfTheLine + SHIP_WEAPONS.shipCannon.cost * 4, trainTime: seconds(30), supplyUsed: 7, abilities: [], naval: true, armor: "heavy", tier: 3, weapon: SHIP_WEAPONS.shipCannon.weapon },
  cutter: { unitClass: "mechanical", hp: 110, speed: 84, radius: 24, attackDamage: 10, attackRange: 264, aimSpeed: 540, attackCooldown: seconds(1.3), cost: SHIP_HULL_COST.cutter, trainTime: seconds(9), supplyUsed: 2, abilities: [], naval: true, intrinsicAttack: true },
  bombardShip: { unitClass: "mechanical", hp: 260, speed: 44, radius: 32, attackDamage: 36, attackRange: 576, aimSpeed: 400, attackCooldown: seconds(3.6), cost: SHIP_HULL_COST.bombardShip + SHIP_WEAPONS.shipMortar.cost, trainTime: seconds(19), supplyUsed: 4, abilities: [], naval: true, tier: 2, weapon: { presentation: "mortar", delivery: "shell", radius: 75, minRange: 180, buildingMultiplier: 2 } },
  fireShip: { unitClass: "mechanical", hp: 340, speed: 70, radius: 28, attackDamage: 10, attackRange: 144, aimSpeed: 480, attackCooldown: seconds(1.2), cost: SHIP_HULL_COST.fireShip + SHIP_WEAPONS.flameProjector.cost, trainTime: seconds(15), supplyUsed: 3, abilities: ["incendiaryFlume"], naval: true, weapon: { presentation: "flame", delivery: "cone", coneAngle: 0.85, buildingMultiplier: 0.7 } },
  carrier: { unitClass: "mechanical", hp: 480, speed: 54, radius: 38, attackDamage: 0, attackRange: 0, attackCooldown: seconds(1), cost: SHIP_HULL_COST.carrier, trainTime: seconds(18), supplyUsed: 3, abilities: [], naval: true, ...TRANSPORT_COMBAT, tier: 2 },
  siegeRam: { unitClass: "mechanical", hp: 420, speed: 50, radius: 26, attackDamage: 22, attackRange: 64, attackCooldown: seconds(1.8), cost: 240, trainTime: seconds(16), supplyUsed: 3, abilities: [], armor: "heavy", tier: 2, weapon: { presentation: "melee", delivery: "ram", buildingMultiplier: 3.3 } },
  ballista: { unitClass: "mechanical", hp: 150, speed: 46, radius: 24, attackDamage: 27, attackRange: 472, aimSpeed: 420, attackCooldown: seconds(2.4), cost: 300, trainTime: seconds(15), supplyUsed: 3, abilities: ["pinningBolt"], tier: 2, weapon: { presentation: "bolt", delivery: "bolt", radius: 18, maxHits: 3, pierceShare: 0.7, buildingMultiplier: 0.75, navalMultiplier: 1.4 } },
  catapult: { unitClass: "mechanical", hp: 180, speed: 38, radius: 27, attackDamage: 38, attackRange: 608, aimSpeed: 360, attackCooldown: seconds(3.8), cost: 390, trainTime: seconds(19), supplyUsed: 4, abilities: [], tier: 2, weapon: { presentation: "stone", delivery: "shell", radius: 90, minRange: 180, buildingMultiplier: 2 } },
  organGun: { unitClass: "mechanical", hp: 190, speed: 46, radius: 25, attackDamage: 12, attackRange: 304, aimSpeed: 480, attackCooldown: seconds(2.5), cost: 350, trainTime: seconds(17), supplyUsed: 3, abilities: [], tier: 2, weapon: { presentation: "grapeshot", delivery: "cone", coneAngle: 0.42, burst: 3, buildingMultiplier: 0.45 } },
  ancientStag: { hp: 360, speed: 88, radius: 32, attackDamage: 38, attackRange: 68, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [] },
  // @@@creep-families - The camp families (see shared/camps.ts), a creep's level its food power, bounty and experience by
  // level (20/35/50/68/85/100/130 gold at levels 1-8). A tier's camps are as hard as the old wildling camps of that tier:
  // health and damage were set so that a squad of two footmen to an archer sized to the tier (3, 5, 7) loses as much,
  // for the camp's level, clearing the new templates as the old ones, within a tenth on average (green 0.96, orange
  // 1.09, red 1.06); a power changes how a camp fights, not how hard it is. Each has one trait or ability at most (see
  // @@@creep-traits), and none reaches past a tower's 480, so no creep wakes from farther than today. None is wider
  // than 28: a blow's reach is measured from center to center, and a footman (radius 18, reach 48) could not strike a
  // wider one through their bodies.
  murlocPeon: { hp: 80, speed: 72, radius: 14, attackDamage: 11, attackRange: 40, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  murlocHunter: { hp: 98, speed: 72, radius: 15, attackDamage: 13, attackRange: 120, aimSpeed: 480, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], slowOnHit: true, threat: 1.05 },
  tidePriest: { hp: 100, speed: 64, radius: 17, attackDamage: 10, attackRange: 160, aimSpeed: 440, attackCooldown: seconds(1.9), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: ["heal"] },
  deepSnapper: { hp: 350, speed: 70, radius: 26, attackDamage: 31, attackRange: 52, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: [], armor: "heavy", threat: 1.25 },
  rubbleGolem: { unitClass: "mechanical", hp: 190, speed: 50, radius: 22, attackDamage: 22, attackRange: 48, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [], armor: "heavy" },
  rockGolem: { unitClass: "mechanical", hp: 235, speed: 50, radius: 25, attackDamage: 25, attackRange: 52, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [], armor: "heavy", threat: 1.3 },
  graniteGolem: { unitClass: "mechanical", hp: 390, speed: 48, radius: 28, attackDamage: 35, attackRange: 58, attackCooldown: seconds(2.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: ["stomp"], armor: "heavy", threat: 1.3 },
  ogreWarrior: { hp: 178, speed: 68, radius: 22, attackDamage: 22, attackRange: 52, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 3, abilities: [] },
  ogreMage: { hp: 145, speed: 64, radius: 22, attackDamage: 15, attackRange: 160, aimSpeed: 400, attackCooldown: seconds(1.8), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: ["bloodlust"], threat: 1.15 },
  ogreLord: { hp: 380, speed: 68, radius: 28, attackDamage: 34, attackRange: 56, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 6, abilities: [], threat: 1.35 },
  spiderling: { hp: 65, speed: 88, radius: 12, attackDamage: 10, attackRange: 36, attackCooldown: seconds(1.2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 1, abilities: [] },
  venomSpider: { hp: 105, speed: 84, radius: 15, attackDamage: 13, attackRange: 44, attackCooldown: seconds(1.5), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 2, abilities: [], poisonOnHit: true, threat: 1.7 },
  spiderQueen: { hp: 350, speed: 80, radius: 26, attackDamage: 33, attackRange: 52, attackCooldown: seconds(1.7), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 5, abilities: ["web"] },
  dragonWhelp: { hp: 170, speed: 84, radius: 22, attackDamage: 17, attackRange: 144, aimSpeed: 540, attackCooldown: seconds(1.6), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 4, abilities: [] },
  redDragon: { hp: 600, speed: 80, radius: 28, attackDamage: 42, attackRange: 176, aimSpeed: 480, attackCooldown: seconds(2), cost: 0, trainTime: seconds(0.05), supplyUsed: 0, creepFoodPower: 8, abilities: [], splash: true, threat: 1.3 }
};
var UNIT_DEFS = Object.fromEntries(
  Object.entries(UNIT_RULES).map(([kind, row]) => {
    const def = { unitClass: "nonMechanical", ...row, xpReward: 0 };
    def.xpReward = kind === "spirit" ? 0 : Math.round(unitValue(def) / 3);
    if (def.creepFoodPower) def.goldBounty = creepGoldBounty(def.creepFoodPower, def.threat);
    return [kind, def];
  })
);
function unitRules(game, unit) {
  if (unit.variant === void 0 || !game.variants) return UNIT_DEFS[unit.kind];
  const rules = game.variants[unit.variant];
  if (!rules) throw new Error(`Unknown unit variant ${unit.variant}`);
  return rules;
}
function requiredSupplyCap(kind) {
  const tier = UNIT_DEFS[kind].tier;
  return tier ? TIER_SUPPLY_CAP[tier] : 0;
}
var UNIT_KINDS = Object.keys(UNIT_DEFS);
var NAVAL_KINDS = new Set(UNIT_KINDS.filter((kind) => UNIT_DEFS[kind].naval));
function unitMover(kind) {
  return NAVAL_KINDS.has(kind) ? "sea" : "land";
}
var ABILITY_KINDS = ["heal", "summon", "curse", "ashCurse", "charge", "stomp", "bloodlust", "web", "pinningBolt", "incendiaryFlume", ...VETERAN_ACTIVE_SKILL_IDS];
var CURSE_SUMMONED_DAMAGE = 100;
var ABILITY_DEFS = {
  ...Object.fromEntries(VETERAN_ACTIVE_SKILL_IDS.map((skill) => {
    const effect = VETERAN_SKILLS[skill].effect;
    if (effect.type !== "active") throw new Error(`Veteran ability ${skill} must be active`);
    return [skill, {
      behavior: "veteran",
      skill,
      range: effect.radius,
      plannerRange: effect.radius,
      cooldown: effect.cooldown,
      effectType: effect.action === "heal" ? "heal" : effect.modifiers.damageReduction ? "guardianField" : "bloodlust",
      autocast: "on",
      ...effect.targets ? { targets: effect.targets } : {}
    }];
  })),
  pinningBolt: { behavior: "weapon", target: "enemy", weapon: { presentation: "bolt", delivery: "bolt", radius: 20, maxHits: 3, pierceShare: 0.7 }, range: 472, plannerRange: 472, cooldown: seconds(14), damage: 36, rootTicks: seconds(2), effectType: "siegeBolt", autocast: "none" },
  incendiaryFlume: { behavior: "weapon", target: "point", weapon: { presentation: "fire", delivery: "shell", radius: 85, buildingMultiplier: 0.7 }, range: 224, plannerRange: 224, cooldown: seconds(18), damage: 14, burnTicks: seconds(4), effectType: "burningGround", autocast: "none" },
  // With spells on their own cooldowns (see ability-cooldowns) a healer heals through every fight. At one heal every 6s,
  // 9 health a second, two mirrored default AIs fought for 41 minutes on verdantCrossroads (12.7 before) and never ended on
  // wildMarches. Every 12s is Warcraft III's measure: a priest's mana holds it to about a third of a footman's damage.
  heal: { behavior: "heal", targets: { unitClasses: ["nonMechanical"] }, range: 240, plannerRange: 220, cooldown: seconds(12), healAmount: 55, effectType: "heal", autocast: "on" },
  summon: { behavior: "summon", range: 260, plannerRange: 240, cooldown: seconds(40), summonKind: "spirit", summonDuration: seconds(60), effectType: "summon", autocast: "on" },
  curse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.4, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "curse", autocast: "on" },
  ashCurse: { behavior: "curse", range: 280, plannerRange: 260, cooldown: seconds(7.5), effectDuration: seconds(18), damageMultiplier: 0.45, scorchedDamageMultiplier: 0.3, summonedDamage: CURSE_SUMMONED_DAMAGE, statusType: "curse", effectType: "scorch", autocast: "on" },
  // The cavalry's charge: from 180 to 300 away, a slide that would carry the rider `drive` past the unit it meets (see
  // @@@charge), and a blow of twice the weapon's.
  charge: { behavior: "charge", minRange: 180, range: 300, plannerRange: 288, cooldown: seconds(15), damageMultiplier: 2, drive: 100, effectType: "chargeTrail", autocast: "on" },
  // @@@creep-abilities - The creeps' own, cast by themselves only: a granite golem's stomp stuns every enemy unit within
  // 160 for 1.5s, every 12s; an ogre mage's bloodlust quickens a fighting ally's blows by 30% for 15s, every 20s; a spider
  // queen's web roots one enemy within 220 in place for 2s, every 10s.
  stomp: { behavior: "stomp", range: 160, plannerRange: 150, cooldown: seconds(12), effectDuration: seconds(1.5), effectType: "stomp", autocast: "on" },
  bloodlust: { behavior: "bloodlust", range: 300, plannerRange: 280, cooldown: seconds(20), effectDuration: seconds(15), attackSpeed: 1.3, effectType: "bloodlust", autocast: "on" },
  web: { behavior: "web", range: 220, plannerRange: 200, cooldown: seconds(10), effectDuration: seconds(2), effectType: "web", autocast: "on" }
};
var BUILDING_RULES = {
  townHall: { hp: 900, radius: 48, cost: 400, buildTime: seconds(28), researches: ["buildingDurability"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 8 },
  barracks: { race: "grove", hp: 620, radius: 40, cost: 170, buildTime: seconds(11), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  archeryRange: { race: "grove", hp: 520, radius: 38, cost: 150, buildTime: seconds(10), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  stables: { race: "grove", hp: 560, radius: 42, cost: 175, buildTime: seconds(11.5), researches: ["speedTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  sanctum: { race: "grove", hp: 500, radius: 38, cost: 175, buildTime: seconds(11.25), researches: ["leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  workshop: { hp: 580, radius: 42, cost: 205, buildTime: seconds(12.5), researches: ["rangeTraining"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  defenseTower: { neutralDamageMultiplier: 0.5, hp: 200, radius: 30, cost: 125, buildTime: seconds(6.5), researches: [], attackDamage: 16, attackRange: 480, attackCooldown: seconds(1.5), supplyProvided: 0 },
  moonWell: { race: "grove", hp: 300, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  emberForge: { race: "ember", hp: 560, radius: 40, cost: 165, buildTime: seconds(10.5), researches: ["weaponTraining", "reinforcedPlating"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  cinderSpire: { race: "ember", hp: 500, radius: 38, cost: 170, buildTime: seconds(10.75), researches: ["speedTraining", "rangeTraining", "leadership"], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  emberShrine: { race: "ember", hp: 280, radius: 30, cost: 115, buildTime: seconds(8.5), researches: [], attackDamage: 0, attackRange: 210, attackCooldown: seconds(1.5), supplyProvided: 0 },
  // Ember's heavy-unit hall, its stables and workshop in one: one building for both heavies, priced above either.
  ashenHall: { race: "ember", hp: 600, radius: 42, cost: 215, buildTime: seconds(13), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0 },
  // Supply is the tech (see unit-tiers), so it is dear: a farm's 6 cost 120, a hall's 8 are priced the same inside its 400.
  farm: { hp: 320, radius: 30, cost: 120, buildTime: seconds(7), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 6 },
  // Ships are built here (see @@@naval); every race builds it, as it does a tower or a farm.
  shipyard: { hp: 600, radius: 44, cost: 170, buildTime: seconds(12), researches: [], attackDamage: 0, attackRange: 0, attackCooldown: seconds(0.05), supplyProvided: 0, shore: true }
};
var BUILDABLE_BUILDING_KINDS = Object.keys(BUILDING_RULES);
var COMMON_PRODUCTION = {
  worker: { at: "townHall" },
  transport: { at: "shipyard" },
  warship: { at: "shipyard" },
  shipOfTheLine: { at: "shipyard" },
  cutter: { at: "shipyard" },
  bombardShip: { at: "shipyard" },
  fireShip: { at: "shipyard" },
  carrier: { at: "shipyard" }
};
var RACE_TECH_RULES = {
  grove: { units: {
    ...COMMON_PRODUCTION,
    footman: { at: "barracks" },
    lancer: { at: "barracks" },
    archer: { at: "archeryRange" },
    horseArcher: { at: "stables" },
    raider: { at: "stables" },
    knight: { at: "stables" },
    priest: { at: "sanctum" },
    summoner: { at: "sanctum" },
    witch: { at: "sanctum" },
    golem: { at: "workshop" },
    ballista: { at: "workshop" }
  } },
  ember: { units: {
    ...COMMON_PRODUCTION,
    ashWarden: { at: "emberForge" },
    emberRavager: { at: "emberForge" },
    cinderRunner: { at: "emberForge" },
    sparkArcher: { at: "cinderSpire" },
    priest: { at: "cinderSpire" },
    ashHexer: { at: "cinderSpire" },
    summoner: { at: "cinderSpire" },
    ashChieftain: { at: "ashenHall" },
    cinderRevenant: { at: "ashenHall" },
    siegeRam: { at: "workshop" },
    catapult: { at: "workshop" },
    organGun: { at: "workshop" }
  } }
};
var PRODUCTION = {
  grove: RACE_TECH_RULES.grove.units,
  ember: RACE_TECH_RULES.ember.units
};
function trainingBuildingFor(race, kind) {
  return PRODUCTION[race][kind]?.at;
}
function canTrainAt(race, building, kind) {
  return trainingBuildingFor(race, kind) === building;
}
var TRAINABLE_UNIT_KINDS = UNIT_KINDS.filter(
  (kind) => canTrainForAnyRace(kind)
);
function canTrainForAnyRace(kind) {
  return Object.values(PRODUCTION).some((units2) => units2[kind] !== void 0);
}
var TRAINING_BY_RACE = Object.fromEntries(
  Object.keys(PRODUCTION).map((race) => [race, Object.fromEntries(
    BUILDABLE_BUILDING_KINDS.map((building) => [
      building,
      Object.freeze(TRAINABLE_UNIT_KINDS.filter((kind) => canTrainAt(race, building, kind)))
    ])
  )])
);
var BUILDING_DEFS = Object.fromEntries(
  BUILDABLE_BUILDING_KINDS.map((kind) => [kind, { ...BUILDING_RULES[kind], trains: TRAINABLE_UNIT_KINDS.filter((unit) => Object.values(PRODUCTION).some((units2) => units2[unit]?.at === kind)) }])
);
var ORDINARY_COMBAT_UNITS = TRAINABLE_UNIT_KINDS.filter((kind) => kind !== "worker");
var UPGRADE_RULES = {
  weaponTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 150, researchTime: seconds(34.5), attackMultiplier: 1.15 },
      { cost: 175, researchTime: seconds(46.5), attackMultiplier: 1.3 },
      { cost: 200, researchTime: seconds(60), attackMultiplier: 1.45 }
    ]
  },
  reinforcedPlating: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 180, researchTime: seconds(40.5), maxHpMultiplier: 1.15 },
      { cost: 210, researchTime: seconds(52.5), maxHpMultiplier: 1.3 },
      { cost: 240, researchTime: seconds(66), maxHpMultiplier: 1.45 }
    ]
  },
  buildingDurability: {
    affectedUnitKinds: [],
    levels: [
      { cost: 200, researchTime: seconds(54), buildingMaxHpMultiplier: 1.2 }
    ]
  },
  // A tenth faster a level: at a quarter a level (1.25, 1.38, 1.5) a footman at the third outran a raider untrained (4.5
  // against 82), and the riders' speed was theirs no more.
  speedTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 185, researchTime: seconds(46), speedMultiplier: 1.1 },
      { cost: 285, researchTime: seconds(60), speedMultiplier: 1.2 },
      { cost: 420, researchTime: seconds(76), speedMultiplier: 1.3 }
    ]
  },
  rangeTraining: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    levels: [
      { cost: 195, researchTime: seconds(48), attackRangeMultiplier: 1.15 },
      { cost: 305, researchTime: seconds(64), attackRangeMultiplier: 1.25 },
      { cost: 450, researchTime: seconds(82), attackRangeMultiplier: 1.35 }
    ]
  },
  leadership: {
    affectedUnitKinds: ORDINARY_COMBAT_UNITS,
    // @@@leadership-by-stars - A second and a third star are worth more than the first. One star regenerates 1, 2 and 3
    // health a second by the research's level, as it always did; two stars 3, 5 and 7; three stars 6, 9 and 12. A single
    // three-star veteran repays the first level on its own: 6 a second for 200 gold, where a moon well gives 3.3 for 115.
    // Each later level adds one a second per star, for armies with many veterans. At one a second per star for 220 gold,
    // the two to four stars a gauntlet army carries at 5-13 minutes regenerated half of what a well bought for the gold.
    levels: [
      { cost: 200, researchTime: seconds(52), veteranRegenByStars: [1, 3, 6] },
      { cost: 300, researchTime: seconds(70), veteranRegenByStars: [2, 5, 9] },
      { cost: 450, researchTime: seconds(90), veteranRegenByStars: [3, 7, 12] }
    ]
  }
};
var UPGRADE_KINDS = ["weaponTraining", "reinforcedPlating", "buildingDurability", "speedTraining", "rangeTraining", "leadership"];
var UPGRADE_DEFS = Object.fromEntries(
  UPGRADE_KINDS.map((kind) => [kind, {
    ...UPGRADE_RULES[kind],
    researchBuildingKinds: BUILDABLE_BUILDING_KINDS.filter((building) => BUILDING_DEFS[building].researches.includes(kind))
  }])
);
function canResearchAt(race, building, upgrade) {
  const rules = BUILDING_DEFS[building];
  return (rules.race === void 0 || rules.race === race) && rules.researches.includes(upgrade);
}
function raceDef(id, name, note) {
  const owns = (race) => race === void 0 || race === id;
  return {
    id,
    name,
    note,
    trainableUnits: TRAINABLE_UNIT_KINDS.filter((kind) => trainingBuildingFor(id, kind) !== void 0),
    buildableBuildings: BUILDABLE_BUILDING_KINDS.filter((kind) => owns(BUILDING_DEFS[kind].race)),
    upgrades: UPGRADE_KINDS.filter((upgrade) => BUILDABLE_BUILDING_KINDS.some((building) => canResearchAt(id, building, upgrade)))
  };
}
var RACE_DEFS = {
  grove: raceDef("grove", "Grove Kin", "Durable line holders, conventional ranged units, heavy tech, and moon-well recovery."),
  ember: raceDef("ember", "Ember Pact", "Faster fragile fighters, early support casters, ashen-hall heavies, and ember-shrine recovery.")
};

// ../sketch-rts-six-player-structural-before-0f31/src/shared/physical-body.ts
var MASSES = {
  worker: 75,
  footman: 105,
  archer: 85,
  sparkArcher: 85,
  contractArcher: 90,
  knight: 680,
  lancer: 120,
  raider: 600,
  horseArcher: 560,
  siegeRam: 2200,
  ballista: 1100,
  catapult: 1200,
  organGun: 1600,
  golem: 2600,
  ashChieftain: 180,
  cinderRevenant: 220,
  rubbleGolem: 1100,
  rockGolem: 2800,
  graniteGolem: 6500,
  ogreWarrior: 320,
  ogreMage: 300,
  ogreLord: 550,
  ancientStag: 500,
  dragonWhelp: 350,
  redDragon: 3500
};
function bodyMass(unit) {
  const ship = shipProfile(unit);
  return ship ? ship.hullMass + (unit.sailing?.load ?? 0) : (unit.gearMass ?? 0) + Math.round((MASSES[unit.kind] ?? 85 * (UNIT_DEFS[unit.kind].radius / UNIT_DEFS.archer.radius) ** 3) * ((unit.bodyRadius ?? unit.radius) / UNIT_DEFS[unit.kind].radius) ** 3);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-collisions.ts
var SHIP_IMPACT_SAFE_SPEED = 10;
function unitBody(body) {
  return "order" in body;
}
function velocity(body) {
  if (!unitBody(body)) return { x: 0, y: 0 };
  const motion = body.sailing, speed = motion?.speed ?? 0, heading = motion?.heading ?? 0;
  if (motion && speed <= 1e-7 && body.pushX === void 0) return { x: 0, y: 0 };
  return { x: motion?.velocityX ?? speed * detCos(heading) + (body.pushX ?? 0), y: motion?.velocityY ?? speed * detSin(heading) + (body.pushY ?? 0) };
}
function shipPointVelocity(ship, point, linear = velocity(ship), yawRate = ship.sailing?.yawRate ?? 0) {
  return { x: linear.x - yawRate * (point.y - ship.y), y: linear.y + yawRate * (point.x - ship.x) };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/mining.ts
var GOLD_MINE_RULES = {
  radius: 42,
  entryRange: 44,
  dropRange: 74,
  workstations: 5,
  // Standard worker budget; admission timing determines actual saturation.
  goldPerTrip: 10,
  // Keep the 400 gold/minute admission cap after shortening the hauling lane.
  // At a 216-unit hall distance, a 60-unit/s worker cycles in about 6.5s:
  // 3.2s working + 2 * (216 - 44 - 74) / 60 travelling. Five workers
  // saturate the 1.5s admission interval; a sixth can still help longer routes.
  gatherSeconds: 3.2,
  entrySeconds: 1.5,
  townHallDistance: 210,
  mainDistance: 216,
  baseRange: 320
};

// ../sketch-rts-six-player-structural-before-0f31/src/shared/build-placement.ts
var BUILDING_PLACEMENT_GAP = 4;
function buildingPlacementBlocker(snapshot, kind, point) {
  const radius = BUILDING_DEFS[kind].radius;
  const map = snapshot.map;
  let near = (body) => distance(point, body) < radius + body.radius + BUILDING_PLACEMENT_GAP;
  if (map?.terrain) {
    const cell = map.terrain.cell;
    const at2 = snapToFootprint(map, radius, point);
    const own = footprintCells(cell, at2.x, at2.y, radius);
    near = (body) => {
      const other = footprintCells(cell, body.x, body.y, body.radius);
      return own.left <= other.right && other.left <= own.right && own.top <= other.bottom && other.top <= own.bottom;
    };
  }
  const blocker = snapshot.buildings.find(near) ?? snapshot.obstacles?.find(near);
  if (blocker) return blocker;
  return snapshot.resources?.find((resource) => resourceBlocksPlacement(map, kind, point, resource));
}
function resourceBlocksPlacement(map, kind, point, resource) {
  const radius = BUILDING_DEFS[kind].radius;
  const at2 = map ? snapToFootprint(map, radius, point) : point;
  if (kind === "townHall" && distance(at2, resource) < GOLD_MINE_RULES.townHallDistance) return true;
  const half = map?.terrain ? footprintHalf(radius, map.terrain.cell) : radius;
  const dx = Math.max(0, Math.abs(resource.x - at2.x) - half);
  const dy = Math.max(0, Math.abs(resource.y - at2.y) - half);
  return Math.hypot(dx, dy) < GOLD_MINE_RULES.radius + BUILDING_PLACEMENT_GAP;
}
function terrainBlocksPlacement(map, kind, point) {
  if (map === void 0) return false;
  const { radius, shore } = BUILDING_DEFS[kind];
  const at2 = snapToFootprint(map, radius, point);
  return shore ? !isShoreFootprint(map, at2.x, at2.y, radius) : !isFootprintBuildable(map, at2.x, at2.y, radius);
}
function isBuildPlacementClear(snapshot, kind, point) {
  return !terrainBlocksPlacement(snapshot.map, kind, point) && !buildingPlacementBlocker(snapshot, kind, point);
}
function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/mining-site.ts
var candidatesByMap = /* @__PURE__ */ new WeakMap();
function miningHallSite(snapshot, mine, preferred = mine) {
  const radius = BUILDING_DEFS.townHall.radius;
  const cell = snapshot.map.terrain?.cell ?? 16;
  let cache4 = candidatesByMap.get(snapshot.map);
  if (!cache4) {
    cache4 = /* @__PURE__ */ new Map();
    candidatesByMap.set(snapshot.map, cache4);
  }
  const key = `${mine.x}:${mine.y}:${preferred.x}:${preferred.y}`;
  let points = cache4.get(key);
  if (!points) {
    points = [];
    const center = snapToFootprint(snapshot.map, radius, mine);
    const steps = Math.ceil(300 / cell);
    for (let row = -steps; row <= steps; row++) {
      for (let col = -steps; col <= steps; col++) {
        const point = { x: center.x + col * cell, y: center.y + row * cell };
        if (Math.hypot(point.x - mine.x, point.y - mine.y) > 300) continue;
        if (point.x - radius < 0 || point.y - radius < 0 || point.x + radius > snapshot.map.width || point.y + radius > snapshot.map.height) continue;
        if (!isFootprintBuildable(snapshot.map, point.x, point.y, radius)) continue;
        if (resourceBlocksPlacement(snapshot.map, "townHall", point, mine)) continue;
        points.push(point);
      }
    }
    points.sort((a, b) => (a.x - preferred.x) ** 2 + (a.y - preferred.y) ** 2 - ((b.x - preferred.x) ** 2 + (b.y - preferred.y) ** 2));
    cache4.set(key, points);
  }
  return points.find((point) => sameGround(snapshot.map, point, mine) && isBuildPlacementClear(snapshot, "townHall", point));
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/route-selection.ts
function nearestByRoute(map, candidates, destination, mover) {
  let best;
  let shortest = Infinity;
  for (const candidate of candidates) {
    const route = walkingDistance(map, candidate, destination, mover);
    if (route !== void 0 && route < shortest) {
      best = candidate;
      shortest = route;
    }
  }
  return best;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/equipment.ts
var CARRY_SLOTS = ["carry0", "carry1", "carry2", "carry3"];
var ITEM_TRANSFER_REACH = 72;
var ITEM_DEFS = {
  shipCannon: { hands: 2, mass: SHIP_WEAPONS.shipCannon.mass, span: 4, passive: true },
  shipMortar: { hands: 2, mass: SHIP_WEAPONS.shipMortar.mass, span: 4, passive: true },
  flameProjector: { hands: 2, mass: SHIP_WEAPONS.flameProjector.mass, span: 4, passive: true },
  issuedWeapon: { hands: 1, mass: 4, passive: true },
  flameCloak: { slot: "body", mass: 3, passive: true },
  speedBoots: { slot: "feet", mass: 2, passive: true },
  regenRing: { slot: "head", mass: 1, passive: true },
  leatherArmor: { slot: "body", mass: 8, protection: 0.08, passive: true },
  roundShield: { hands: 1, mass: 5, protection: 0.12, passive: true },
  greatSword: { hands: 2, mass: 6, weapon: { damage: 22, range: 48, cooldown: seconds(1.8) }, passive: true },
  lightningRod: { hands: 1, mass: 3 },
  stormStaff: { hands: 2, mass: 5 },
  guardianScroll: { hands: 1, mass: 0.3 },
  healingScroll: { hands: 1, mass: 0.3 },
  experienceBook: { hands: 1, mass: 1 },
  breachCharge: { hands: 1, mass: 6 },
  ivoryTower: { hands: 1, mass: 2 }
};
var HUMANOIDS = /* @__PURE__ */ new Set(["worker", "footman", "archer", "knight", "lancer", "raider", "sparkArcher", "horseArcher", "priest", "witch", "ashChieftain", "cinderRevenant", "mercenary", "contractArcher", "fieldMedic"]);
function canEquip(unit) {
  return HUMANOIDS.has(unit.kind) || unit.owner !== "neutral" && !SHIP_KINDS.includes(unit.kind) && unit.radius <= 22;
}
function isCarrySlot(slot) {
  return CARRY_SLOTS.includes(slot);
}
function itemsFor(snapshot, unit) {
  return itemIndex(snapshot.items).byCarrier.get(unit.id) ?? [];
}
function itemSlot(snapshot, unit, item) {
  if (item.slot)
    return item.slot;
  const occupied = /* @__PURE__ */ new Set();
  for (const candidate of itemsFor(snapshot, unit)) {
    const worn = ITEM_DEFS[candidate.kind].slot;
    const slot = candidate.slot ?? (worn && !occupied.has(worn) ? worn : CARRY_SLOTS.find((slot2) => !occupied.has(slot2)));
    if (candidate.id === item.id)
      return slot;
    if (slot)
      occupied.add(slot);
  }
  return void 0;
}
function freeItemSlot(snapshot, unit, kind) {
  const carried = itemsFor(snapshot, unit);
  const occupied = new Set(carried.flatMap((item) => ITEM_DEFS[item.kind].span === 4 ? [...CARRY_SLOTS] : [itemSlot(snapshot, unit, item)]));
  if (ITEM_DEFS[kind].span === 4)
    return CARRY_SLOTS.every((slot) => !occupied.has(slot)) ? "carry0" : void 0;
  const worn = ITEM_DEFS[kind].slot;
  if (worn && !occupied.has(worn))
    return worn;
  return CARRY_SLOTS.find((slot) => !occupied.has(slot));
}
function activeItem(snapshot, unit, hand) {
  const id = unit.hands?.[hand];
  const item = id ? itemIndex(snapshot.items).byId.get(id) : void 0;
  return item?.carrierId === unit.id ? item : void 0;
}
var defaultKits = /* @__PURE__ */ new WeakMap();
function weaponRules(snapshot, unit) {
  const base = unitRules(snapshot, unit), kit = defaultKits.get(unit);
  if (kit && kit.items === snapshot.items && kit.item.id === unit.hands?.right && kit.item.carrierId === unit.id && kit.item.kind === "issuedWeapon" && kit.item.weaponKind === unit.kind)
    return base;
  if (SHIP_KINDS.includes(unit.kind) && unit.fittings && !base.intrinsicAttack) {
    const weapon = (itemIndex(snapshot.items).byShip.get(unit.id) ?? []).filter((item2) => item2.mountId && isShipEquipment(item2.kind) && (item2.durability ?? 1) > 0).sort((a, b) => SHIP_WEAPONS[b.kind].range - SHIP_WEAPONS[a.kind].range)[0];
    if (weapon) {
      const profile = SHIP_WEAPONS[weapon.kind];
      return { ...base, attackDamage: profile.damage, attackRange: profile.range, attackCooldown: profile.cooldown, weapon: profile.weapon, aimSpeed: profile.aimSpeed };
    }
    return { ...base, attackDamage: 0, attackRange: 0 };
  }
  if (!unit.hands || !canEquip(unit))
    return base;
  const item = activeItem(snapshot, unit, "right");
  if (!item || !ITEM_DEFS[item.kind].weapon && item.kind !== "issuedWeapon")
    return base;
  if (item?.kind === "issuedWeapon" && item.weaponKind === unit.kind) {
    defaultKits.set(unit, { items: snapshot.items, item });
    return base;
  }
  const { weapon: _weapon, aimSpeed: _aim, aimMoveTolerance: _tolerance, ...body } = base;
  if (item?.kind === "issuedWeapon" && item.weaponKind) {
    const profile = UNIT_DEFS[item.weaponKind];
    return { ...body, attackDamage: profile.attackDamage, attackRange: profile.attackRange, attackCooldown: profile.attackCooldown, ...profile.weapon ? { weapon: profile.weapon } : {}, ...profile.aimSpeed ? { aimSpeed: profile.aimSpeed } : {}, ...profile.aimMoveTolerance ? { aimMoveTolerance: profile.aimMoveTolerance } : {} };
  }
  const selected = item && ITEM_DEFS[item.kind].weapon;
  return selected ? { ...body, attackDamage: selected.damage, attackRange: selected.range, attackCooldown: selected.cooldown } : base;
}
function shipHoldSlots(ship) {
  const profile = shipProfile(ship);
  return profile ? Math.max(4, Math.floor(profile.loadCapacity / 100)) : 0;
}
function shipItemMass(snapshot, ship) {
  return (itemIndex(snapshot.items).byShip.get(ship.id) ?? []).reduce((sum, item) => sum + ITEM_DEFS[item.kind].mass, 0) + snapshot.items.filter((item) => !item.shipId && !item.carrierId && item.deck?.shipId === ship.id).reduce((sum, item) => sum + ITEM_DEFS[item.kind].mass, 0);
}
function canExchange(snapshot, unit, ship) {
  return unit.deck?.shipId === ship.id || distanceToHull(ship, unit) <= ITEM_TRANSFER_REACH + unit.radius;
}
function transferRefusal(snapshot, owner, itemId, destination) {
  const item = snapshot.items.find((item2) => item2.id === itemId);
  if (!item)
    return "Item is no longer available";
  const source = snapshot.units.find((unit) => unit.id === (item.carrierId ?? item.shipId));
  if (!source || source.owner !== owner)
    return "You can only move your own equipment";
  const target = snapshot.units.find((unit) => unit.id === ("unitId" in destination ? destination.unitId : destination.shipId));
  if (!target || target.owner !== owner || target.hp <= 0)
    return "Destination is no longer available";
  if (source.id !== target.id) {
    const ship = shipProfile(source) ? source : shipProfile(target) ? target : void 0, unit = ship === source ? target : source;
    if (ship ? !canExchange(snapshot, unit, ship) : source.deck?.shipId !== target.deck?.shipId || Math.hypot(source.x - target.x, source.y - target.y) > ITEM_TRANSFER_REACH)
      return "Move closer before exchanging items";
  }
  if ("unitId" in destination) {
    if (!canEquip(target))
      return "This unit cannot wear equipment";
    if (!isCarrySlot(destination.slot) && ITEM_DEFS[item.kind].slot !== destination.slot)
      return "This item does not fit that equipment position";
    const carried = itemsFor(snapshot, target).filter((other) => other.id !== item.id);
    if (ITEM_DEFS[item.kind].span === 4 && (destination.slot !== "carry0" || carried.some((other) => isCarrySlot(itemSlot(snapshot, target, other)))))
      return "A heavy weapon needs all four carrying positions";
    const occupied = carried.some((other) => ITEM_DEFS[other.kind].span === 4 && isCarrySlot(destination.slot) || itemSlot(snapshot, target, other) === destination.slot);
    if (occupied)
      return "That position is occupied; move its item first";
  } else {
    if (!shipProfile(target))
      return "This destination has no hold or weapon fittings";
    if ("mountId" in destination) {
      const mount = shipMounts(target).find((mount2) => mount2.id === destination.mountId);
      if (!mount || !isShipEquipment(item.kind) || !mount.accepts.includes(item.kind))
        return "This weapon does not fit this ship position";
      if (snapshot.items.some((other) => other.id !== item.id && other.shipId === target.id && other.mountId === mount.id))
        return "This fitting is occupied";
      if (snapshot.units.some((unit) => unit.deck?.shipId === target.id && Math.hypot(unit.deck.x - mount.x, unit.deck.y - mount.y) < unit.radius + mount.radius + 1))
        return "Clear the deck around this fitting first";
    } else {
      const span = ITEM_DEFS[item.kind].span ?? 1;
      if (!Number.isInteger(destination.slot) || destination.slot < 0 || destination.slot + span > shipHoldSlots(target))
        return "No room in the hold";
      const occupied = new Set(snapshot.items.filter((other) => other.id !== item.id && other.shipId === target.id && other.holdSlot !== void 0).flatMap((other) => Array.from({ length: ITEM_DEFS[other.kind].span ?? 1 }, (_, i) => other.holdSlot + i)));
      if (Array.from({ length: span }, (_, i) => destination.slot + i).some((slot) => occupied.has(slot)))
        return "That hold position is occupied";
    }
    const profile = shipProfile(target);
    const load = snapshot.units.filter((unit) => unit.deck?.shipId === target.id).reduce((sum, unit) => sum + bodyMass(unit), 0) + shipItemMass(snapshot, target);
    const alreadyAboard = item.shipId === target.id || source.deck?.shipId === target.id;
    if (load + (alreadyAboard ? 0 : ITEM_DEFS[item.kind].mass) > profile.loadCapacity)
      return "The ship cannot carry more weight";
  }
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/combat-capabilities.ts
function combatCapability(snapshot, unit) {
  if (!("order" in unit))
    return {
      armed: unit.attackDamage > 0,
      range: unit.attackRange,
      dps: unit.attackDamage * SIM_TICKS_PER_SECOND / Math.max(1, unit.attackCooldown)
    };
  const rules = weaponRules(snapshot, unit);
  if (!shipProfile(unit))
    return {
      armed: unit.attackDamage > 0,
      range: Math.max(0, unit.attackRange),
      dps: 0 + unit.attackDamage * SIM_TICKS_PER_SECOND / Math.max(1, rules.attackCooldown)
    };
  const intrinsic = {
    damage: shipProfile(unit) ? rules.attackDamage : unit.attackDamage,
    range: shipProfile(unit) ? veteranWeaponRange(unit, rules.attackRange) : unit.attackRange,
    cooldown: rules.attackCooldown
  };
  const weapons = shipProfile(unit) && unit.fittings ? installedWeapons(snapshot, unit).filter((item) => (item.durability ?? 1) > 0).map((item) => {
    const def = SHIP_WEAPONS[item.kind];
    return {
      damage: def.damage,
      range: veteranWeaponRange(unit, def.range),
      cooldown: def.cooldown
    };
  }) : [intrinsic];
  if (shipProfile(unit) && unit.fittings && rules.intrinsicAttack) weapons.push(intrinsic);
  return {
    armed: weapons.some((weapon) => weapon.damage > 0),
    range: Math.max(0, ...weapons.map((weapon) => weapon.range)),
    dps: weapons.reduce(
      (sum, weapon) => sum + weapon.damage * SIM_TICKS_PER_SECOND / Math.max(1, weapon.cooldown),
      0
    )
  };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/support-surface.ts
var at = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
var edge = (a, b) => ({ a, b, left: Math.min(a.x, b.x), top: Math.min(a.y, b.y), right: Math.max(a.x, b.x), bottom: Math.max(a.y, b.y) });
function supportSurface(polygons, ground, bounds) {
  const boundary = [], landBoundary = [];
  const land = (p) => !!ground && ground.open(Math.floor(p.x / ground.cell), Math.floor(p.y / ground.cell));
  const exposed = (a, b, owner, allowGround) => {
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    if (!len)
      return;
    const shift = { x: (b.y - a.y) / len * 1e-5, y: -(b.x - a.x) / len * 1e-5 };
    const aa = { x: a.x + shift.x, y: a.y + shift.y }, bb = { x: b.x + shift.x, y: b.y + shift.y };
    const cuts = [];
    for (let i = 0; i < polygons.length; i++)
      if (i !== owner) {
        const interval = clipToConvex(aa, bb, polygons[i]);
        if (interval)
          cuts.push(interval);
      }
    if (allowGround && ground) {
      const split = [0, 1];
      for (const axis of ["x", "y"])
        if (aa[axis] !== bb[axis]) {
          for (let line = (Math.floor(Math.min(aa[axis], bb[axis]) / ground.cell) + 1) * ground.cell; line < Math.max(aa[axis], bb[axis]); line += ground.cell)
            split.push((line - aa[axis]) / (bb[axis] - aa[axis]));
        }
      split.sort((a2, b2) => a2 - b2);
      for (let i = 1; i < split.length; i++)
        if (land(at(aa, bb, (split[i - 1] + split[i]) / 2)))
          cuts.push([split[i - 1], split[i]]);
    }
    cuts.sort((a2, b2) => a2[0] - b2[0]);
    let start = 0;
    for (const [low, high] of cuts) {
      if (low > start + 1e-9)
        boundary.push(edge(at(a, b, start), at(a, b, low)));
      start = Math.max(start, high);
    }
    if (start < 1 - 1e-9)
      boundary.push(edge(at(a, b, start), b));
  };
  for (let owner = 0; owner < polygons.length; owner++) {
    const poly = polygons[owner];
    for (let i = 0; i < poly.length; i++)
      exposed(poly[i], poly[(i + 1) % poly.length], owner, true);
  }
  if (ground) {
    const { cell } = ground;
    for (let row = Math.max(0, Math.floor(bounds.top / cell)); row < Math.min(ground.rows, Math.ceil(bounds.bottom / cell)); row++)
      for (let col = Math.max(0, Math.floor(bounds.left / cell)); col < Math.min(ground.cols, Math.ceil(bounds.right / cell)); col++)
        if (ground.open(col, row)) {
          const x = col * cell, y = row * cell;
          for (const [dx, dy, a, b] of [[0, -1, { x, y }, { x: x + cell, y }], [1, 0, { x: x + cell, y }, { x: x + cell, y: y + cell }], [0, 1, { x: x + cell, y: y + cell }, { x, y: y + cell }], [-1, 0, { x, y: y + cell }, { x, y }]])
            if (!ground.open(col + dx, row + dy)) {
              landBoundary.push(edge(a, b));
              exposed(a, b, -1, false);
            }
        }
  }
  const supported = (p) => land(p) || polygons.some((poly) => diskInConvex(p, 0, poly));
  const diskClear = (p, r, edges) => {
    const left = p.x - r, right = p.x + r, top = p.y - r, bottom = p.y + r, rr = r * r - 1e-7;
    for (const e of edges)
      if (e.right >= left && e.left <= right && e.bottom >= top && e.top <= bottom && pointSegmentDistanceSquared(p, e.a, e.b) < rr)
        return false;
    return true;
  };
  const capsuleClear = (a, b, r) => {
    const left = Math.min(a.x, b.x) - r, right = Math.max(a.x, b.x) + r, top = Math.min(a.y, b.y) - r, bottom = Math.max(a.y, b.y) + r, rr = r * r - 1e-7;
    for (const e of boundary)
      if (e.right >= left && e.left <= right && e.bottom >= top && e.top <= bottom && segmentDistanceSquared(a, b, e.a, e.b) < rr)
        return false;
    return true;
  };
  return {
    boundary,
    diskFits: (p, r) => supported(p) && diskClear(p, r, boundary),
    diskOnLand: (p, r) => land(p) && diskClear(p, r, landBoundary),
    capsuleFits: (a, b, r) => supported(a) && supported(b) && capsuleClear(a, b, r)
  };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-gangway.ts
var GANGWAY_MAX_GAP = 36;
var GANGWAY_MAX_RADIUS = 20;
var GANGWAY_SETUP_TICKS = seconds(3);
var GANGWAY_COOLDOWN_TICKS = seconds(20);
var MAX_HEADING_DELTA = 0.15;
var SPAN_SLACK = 12;
var crewRules = /* @__PURE__ */ new WeakMap();
var surfaces = /* @__PURE__ */ new WeakMap();
function bindGangwayCrewRules(units2, snapshot) {
  for (const source of shipsIn(units2)) if (source.sailing?.gangway) crewRules.set(source, snapshot);
}
function gangwayCrewEligible(unit, snapshot = {}) {
  if (unit.variant !== void 0 && !snapshot.variants?.[unit.variant]) return false;
  return unit.hp > 0 && !isInCabin(unit) && unit.radius <= GANGWAY_MAX_RADIUS && isCabinCrew(snapshot, unit);
}
function shipBoardingTargetRefusal(source, target) {
  const a = shipProfile(source), b = shipProfile(target);
  if (source === target || source.id === target.id || source.hp <= 0 || target.hp <= 0 || !a || !b || !target.sailing) return "target";
  if (Math.abs(a.deckHeight - b.deckHeight) > GANGWAY_MAX_RADIUS * 2) return "height";
  return void 0;
}
function linearVelocity(ship) {
  const motion = ship.sailing, heading = motion.heading;
  return { x: motion.velocityX ?? motion.speed * detCos(heading) + (ship.pushX ?? 0), y: motion.velocityY ?? motion.speed * detSin(heading) + (ship.pushY ?? 0) };
}
function relativeSpeed(source, target, a, b) {
  const av = shipPointVelocity(source, a, linearVelocity(source)), bv = shipPointVelocity(target, b, linearVelocity(target));
  return Math.hypot(av.x - bv.x, av.y - bv.y);
}
function polygonFor(a, b, width) {
  const length = Math.hypot(b.x - a.x, b.y - a.y);
  if (length < 1e-6) return [];
  const nx = -(b.y - a.y) / length * width / 2, ny = (b.x - a.x) / length * width / 2;
  return convexHull([{ x: a.x + nx, y: a.y + ny }, { x: a.x - nx, y: a.y - ny }, { x: b.x + nx, y: b.y + ny }, { x: b.x - nx, y: b.y - ny }]);
}
function floorSupports(source, target, a, b, width) {
  const polygon = polygonFor(a, b, width);
  if (!polygon.length) return false;
  const hulls = [source, target].map((ship) => shipProfile(ship).hull.map((p) => localToWorld(ship, p)));
  const floor = supportSurface([...hulls, polygon], void 0, { left: 0, top: 0, right: 0, bottom: 0 });
  const obstacles = [source, target].flatMap((ship) => shipProfile(ship).obstacles.map((o) => ({ ...localToWorld(ship, o), radius: o.radius })));
  return floor.capsuleFits(a, b, GANGWAY_MAX_RADIUS + 1) && capsuleClearsCircles(a, b, GANGWAY_MAX_RADIUS + 1, obstacles);
}
function gangwaySurface(source, target, state = source.sailing?.gangway) {
  if (!state || state.phase === "approach") return void 0;
  const pose = (ship) => [ship.id, ship.hp, ship.x, ship.y, ship.sailing?.heading, ship.sailing?.speed, ship.sailing?.velocityX, ship.sailing?.velocityY, ship.sailing?.yawRate, ship.pushX, ship.pushY].join(",");
  const key = `${pose(source)}/${pose(target)}/${state.targetId},${state.phase},${state.hp},${state.sourceAnchor.x},${state.sourceAnchor.y},${state.targetAnchor.x},${state.targetAnchor.y},${state.width},${state.initialSpan},${state.initialHeadingDelta}`;
  const a = shipProfile(source), b = shipProfile(target), cached2 = surfaces.get(state);
  if (cached2?.key === key && cached2.a === a && cached2.b === b) return cached2.surface;
  const surface = computeGangwaySurface(source, target, state);
  surfaces.set(state, { a, b, key, surface });
  return surface;
}
function computeGangwaySurface(source, target, state) {
  if (state.phase === "approach" || state.targetId !== target.id || state.hp <= 0 || shipBoardingTargetRefusal(source, target) || hullGap(source, target) > GANGWAY_MAX_GAP) return void 0;
  const delta = headingDifference(source.sailing.heading, target.sailing.heading);
  if (Math.abs(delta) > MAX_HEADING_DELTA || Math.abs(headingDifference(state.initialHeadingDelta, delta)) > MAX_HEADING_DELTA) return void 0;
  const a = localToWorld(source, state.sourceAnchor), b = localToWorld(target, state.targetAnchor), span = Math.hypot(a.x - b.x, a.y - b.y);
  if (Math.abs(span - state.initialSpan) > SPAN_SLACK || relativeSpeed(source, target, a, b) > SHIP_IMPACT_SAFE_SPEED + 1e-6 || !floorSupports(source, target, a, b, state.width)) return void 0;
  return { source: a, target: b, polygon: polygonFor(a, b, state.width), width: state.width, phase: state.phase };
}
function gangwayBetween(a, b, passenger) {
  for (const [source, target] of [[a, b], [b, a]]) {
    if (source.sailing?.gangway?.phase !== "ready" || source.sailing.gangway.targetId !== target.id) continue;
    const context = crewRules.get(source);
    if (passenger.variant !== void 0 && !context) continue;
    if (!gangwayCrewEligible(passenger, context ?? {})) continue;
    const surface = gangwaySurface(source, target);
    if (surface?.phase === "ready") return { source, target, surface };
  }
  return void 0;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/unit-targeting.ts
function unitClassOf(unit, snapshot = {}) {
  return unitRules(snapshot, unit).unitClass ?? UNIT_DEFS[unit.kind].unitClass;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-cabin.ts
var NON_WALKING_CREW = /* @__PURE__ */ new Set(["knight", "raider", "horseArcher", "spirit", "ancientStag", "dragonWhelp", "redDragon", "mossGnawer", "stonebackBrute", "deepSnapper", "spiderling", "venomSpider", "spiderQueen"]);
function isInCabin(unit) {
  return !!unit.cabin && unit.cabin.shipId === unit.deck?.shipId;
}
function isCabinCrew(snapshot, unit) {
  return unitMover(unit.kind) === "land" && unitClassOf(unit, snapshot) === "nonMechanical" && !NON_WALKING_CREW.has(unit.kind);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/decks.ts
function deckLoad(units2, ship) {
  return (ship.holdMass ?? 0) + shipPassengers(units2, ship).reduce((sum, unit) => sum + bodyMass(unit), 0);
}
function deckPointFits(ship, passenger, point, units2, occupied = true) {
  const profile = shipProfile(ship);
  if (!profile || !diskInConvex(point, passenger.radius + 1, profile.deck)) return false;
  if (profile.obstacles.some((o) => Math.hypot(point.x - o.x, point.y - o.y) < o.radius + passenger.radius + 1 - 1e-6)) return false;
  return !occupied || !shipPassengers(units2, ship).some((other) => other.hp > 0 && !isInCabin(other) && other.id !== passenger.id && Math.hypot(point.x - other.deck.x, point.y - other.deck.y) < passenger.radius + other.radius + 1 - 1e-6);
}
function deckPlacement(ship, passenger, units2, preferred = { x: 0, y: 0 }, occupied = true, spacing = 4) {
  const profile = shipProfile(ship);
  if (!profile) return void 0;
  if (deckPointFits(ship, passenger, preferred, units2, occupied)) return preferred;
  let best, score = Infinity;
  for (let y = -profile.beam / 2; y <= profile.beam / 2; y += spacing) for (let x = -profile.length / 2; x <= profile.length / 2; x += spacing) {
    const point = { x, y }, value = (x - preferred.x) ** 2 + (y - preferred.y) ** 2;
    if (value < score && deckPointFits(ship, passenger, point, units2, occupied)) {
      best = point;
      score = value;
    }
  }
  return best;
}
function canBoard(ship, passenger, units2) {
  const profile = shipProfile(ship);
  if (!profile || shipProfile(passenger) || isInCabin(passenger)) return false;
  if (passenger.deck) {
    const source = units2.find((unit) => unit.id === passenger.deck.shipId), sourceProfile = source && shipProfile(source);
    if (!sourceProfile || source.id === ship.id || Math.abs(profile.deckHeight - sourceProfile.deckHeight) > passenger.radius * 2 && !gangwayBetween(source, ship, passenger)) return false;
  } else if (ship.owner !== passenger.owner) return false;
  return deckLoad(units2, ship) + bodyMass(passenger) <= profile.loadCapacity && !!deckPlacement(ship, passenger, units2);
}
function boardUnit(ship, passenger, units2) {
  const profile = shipProfile(ship);
  if (!profile || passenger.deck || deckLoad(units2, ship) + bodyMass(passenger) > profile.loadCapacity) return false;
  const point = deckPlacement(ship, passenger, units2, { x: -profile.length / 2, y: -profile.beam / 2 }, true, 2);
  if (!point) return false;
  passenger.deck = { shipId: ship.id, ...point };
  passenger.aim = void 0;
  Object.assign(passenger, localToWorld(ship, point));
  return true;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/spatial.ts
function nearestEntity(entities, from) {
  let nearest, gap = Infinity;
  entities.forEach((entity) => {
    const next = distance2(entity, from);
    if (nearest === void 0 || next < gap) {
      nearest = entity;
      gap = next;
    }
  });
  return nearest;
}
function averagePoint(points) {
  const total = { x: 0, y: 0 };
  points.forEach((point) => {
    total.x += point.x / points.length;
    total.y += point.y / points.length;
  });
  return total;
}
function distance2(a, b) {
  return hypot2(a.x - b.x, a.y - b.y);
}
var RANGE_GRID_MIN_ITEMS = 32;
function withinRangeOf(items, range) {
  const plain = (point) => items.filter((item) => withinRange(item, point, range));
  if (items.length < RANGE_GRID_MIN_ITEMS) return plain;
  const cell = range + 1;
  let grid;
  return (point) => {
    const cx = Math.floor(point.x / cell);
    const cy = Math.floor(point.y / cell);
    if (!Number.isFinite(cx) || !Number.isFinite(cy)) return plain(point);
    grid ??= pointGrid(items.map((_, index) => index), (index) => items[index], cell);
    const hits = [];
    for (let x = cx - 1; x <= cx + 1; x += 1) {
      for (let y = cy - 1; y <= cy + 1; y += 1) {
        for (const index of grid.cells.get(gridCellKey(x, y)) ?? []) if (withinRange(items[index], point, range)) hits.push(index);
      }
    }
    for (const index of grid.offGrid) if (withinRange(items[index], point, range)) hits.push(index);
    return hits.sort((a, b) => a - b).map((index) => items[index]);
  };
}
function withinRange(a, b, range) {
  const dx = a.x - b.x, dy = a.y - b.y;
  if (Math.abs(dx) > range || Math.abs(dy) > range) return false;
  return hypot2(dx, dy) <= range;
}
function pointGrid(entries, at2, cell) {
  const cells = /* @__PURE__ */ new Map();
  const offGrid = [];
  for (const entry of entries) {
    const x = Math.floor(at2(entry).x / cell);
    const y = Math.floor(at2(entry).y / cell);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      offGrid.push(entry);
      continue;
    }
    const key = gridCellKey(x, y);
    const bucket = cells.get(key);
    if (bucket) bucket.push(entry);
    else cells.set(key, [entry]);
  }
  return { cells, offGrid };
}
function gridCellKey(x, y) {
  return x * 4096 + y;
}
function clamp2(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// ../sketch-rts-six-player-structural-before-0f31/src/sdk/snapshot/range-index.ts
var RANGE_CELL = 256;
var RANGE_INDEX_MIN_ITEMS = 32;
function createRangeIndex(items) {
  const plain = (point, range, matches) => matches ? items.filter((item) => withinRange2(item, point, range) && matches(item)) : items.filter((item) => withinRange2(item, point, range));
  if (items.length < RANGE_INDEX_MIN_ITEMS) return plain;
  let grid;
  return (point, range, matches) => {
    const span = Math.ceil((range + 1) / RANGE_CELL);
    const cx = Math.floor(point.x / RANGE_CELL);
    const cy = Math.floor(point.y / RANGE_CELL);
    if (!Number.isFinite(span) || !Number.isFinite(cx) || !Number.isFinite(cy) || (2 * span + 1) ** 2 > items.length) return plain(point, range, matches);
    grid ??= indexCells(items);
    const hits = [];
    for (let x = cx - span; x <= cx + span; x += 1) {
      for (let y = cy - span; y <= cy + span; y += 1) {
        for (const index of grid.cells.get(cellKey(x, y)) ?? []) if (withinRange2(items[index], point, range)) hits.push(index);
      }
    }
    for (const index of grid.offGrid) if (withinRange2(items[index], point, range)) hits.push(index);
    hits.sort((a, b) => a - b);
    if (!matches) return hits.map((index) => items[index]);
    const selected = [];
    for (const index of hits) {
      const item = items[index];
      if (matches(item)) selected.push(item);
    }
    return selected;
  };
}
function indexCells(items) {
  const cells = /* @__PURE__ */ new Map();
  const offGrid = [];
  for (let index = 0; index < items.length; index += 1) {
    const x = Math.floor(items[index].x / RANGE_CELL);
    const y = Math.floor(items[index].y / RANGE_CELL);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      offGrid.push(index);
      continue;
    }
    const key = cellKey(x, y);
    const bucket = cells.get(key);
    if (bucket) bucket.push(index);
    else cells.set(key, [index]);
  }
  return { cells, offGrid };
}
function cellKey(x, y) {
  return x * 4096 + y;
}
function withinRange2(a, b, range) {
  const dx = a.x - b.x, dy = a.y - b.y;
  if (Math.abs(dx) > range || Math.abs(dy) > range) return false;
  return hypot2(dx, dy) <= range;
}

// ../sketch-rts-six-player-structural-before-0f31/src/sdk/snapshot/query.ts
function createSnapshotQuery(snapshot, options = {}) {
  bindGangwayCrewRules(snapshot.units, snapshot);
  const teamFor = (owner) => owner === "neutral" ? "neutral" : options.teams?.[owner] ?? owner;
  const isOpponent = (owner, other) => other !== "neutral" && teamFor(owner) !== teamFor(other);
  const visibleItems = options.excludeIssuedWeapons ? snapshot.items.filter((item) => item.kind !== "issuedWeapon") : snapshot.items;
  let ground;
  const carriedByOwner = /* @__PURE__ */ new Map();
  let activePlayers;
  const cachedActivePlayers = () => activePlayers ??= Object.keys(snapshot.players).filter((owner) => snapshot.units.some((unit) => unit.owner === owner) || snapshot.buildings.some((building) => building.owner === owner));
  const unitsByOwner = /* @__PURE__ */ new Map();
  const combatUnitsByOwner = /* @__PURE__ */ new Map();
  const buildingsByOwner = /* @__PURE__ */ new Map();
  const completeBuildingsByOwner = /* @__PURE__ */ new Map();
  const hostileCombatUnitsByOwner = /* @__PURE__ */ new Map();
  const viewByOwner = /* @__PURE__ */ new Map();
  let unitsById;
  let buildingsById;
  let neutralUnits;
  const nearIndexes = /* @__PURE__ */ new Map();
  const combatUnit = (unit) => unit.kind !== "worker";
  const unitsNear = (key, matches) => {
    let near = nearIndexes.get(key);
    if (!near) nearIndexes.set(key, near = createRangeIndex(snapshot.units.filter(matches)));
    return near;
  };
  const cachedPlayerView = (owner, query) => {
    let view = viewByOwner.get(owner);
    if (!view) {
      const ownTeam = teamFor(owner);
      const entities = playerEntityViews(snapshot, owner, ownTeam, teamFor);
      view = {
        owner,
        team: ownTeam,
        ...entities,
        resources: entitySet(snapshot.resources),
        mercenaryCamps: entitySet(snapshot.mercenaryCamps),
        items: { ground: query.groundItems(), carried: query.carriedItemsFor(owner) }
      };
      viewByOwner.set(owner, view);
    }
    return view;
  };
  return {
    snapshot,
    teamFor,
    isOpponent,
    activePlayerIds() {
      return cachedActivePlayers().slice();
    },
    opponentPlayerIds(owner) {
      return cachedActivePlayers().filter((candidate) => isOpponent(owner, candidate));
    },
    unitById(id) {
      unitsById ??= firstById(snapshot.units);
      return unitsById.get(id);
    },
    buildingById(id) {
      buildingsById ??= firstById(snapshot.buildings);
      return buildingsById.get(id);
    },
    resourceById(id) {
      return snapshot.resources.find((resource) => resource.id === id);
    },
    mercenaryCampById(id) {
      return snapshot.mercenaryCamps.find((camp) => camp.id === id);
    },
    itemById(id) {
      return snapshot.items.find((item) => item.id === id);
    },
    targetById(id) {
      return this.unitById(id) ?? this.buildingById(id) ?? this.resourceById(id) ?? this.mercenaryCampById(id) ?? this.itemById(id);
    },
    resources() {
      return snapshot.resources;
    },
    activeResources() {
      return snapshot.resources.filter((resource) => resource.amount > 0);
    },
    mercenaryCamps() {
      return snapshot.mercenaryCamps;
    },
    items() {
      return visibleItems;
    },
    groundItems() {
      ground ??= visibleItems.filter((item) => !item.carrierId && !item.shipId);
      return ground.slice();
    },
    carriedItemsFor(owner) {
      let carried = carriedByOwner.get(owner);
      if (!carried) {
        const ownUnitIds = new Set(this.unitsFor(owner).map((unit) => unit.id));
        carried = visibleItems.filter((item) => item.carrierId && ownUnitIds.has(item.carrierId));
        carriedByOwner.set(owner, carried);
      }
      return carried.slice();
    },
    buildings() {
      return snapshot.buildings;
    },
    unitsFor(owner) {
      let units2 = unitsByOwner.get(owner);
      if (!units2) unitsByOwner.set(owner, units2 = snapshot.units.filter((unit) => unit.owner === owner));
      return units2.slice();
    },
    combatUnitsFor(owner) {
      let units2 = combatUnitsByOwner.get(owner);
      if (!units2) combatUnitsByOwner.set(owner, units2 = this.unitsFor(owner).filter((unit) => unit.kind !== "worker"));
      return units2.slice();
    },
    buildingsFor(owner) {
      let buildings2 = buildingsByOwner.get(owner);
      if (!buildings2) buildingsByOwner.set(owner, buildings2 = snapshot.buildings.filter((building) => building.owner === owner));
      return buildings2.slice();
    },
    completeBuildingsFor(owner, kind) {
      let byKind = completeBuildingsByOwner.get(owner);
      if (!byKind) completeBuildingsByOwner.set(owner, byKind = /* @__PURE__ */ new Map());
      let buildings2 = byKind.get(kind);
      if (!buildings2) byKind.set(kind, buildings2 = this.buildingsFor(owner).filter((building) => building.complete && (kind === void 0 || building.kind === kind)));
      return buildings2.slice();
    },
    neutralUnitsNear(point, range) {
      neutralUnits ??= snapshot.units.filter((unit) => unit.owner === "neutral");
      return neutralUnits.filter((unit) => distance3(unit, point) <= range);
    },
    opponentUnitsNear(owner, point, range) {
      return unitsNear(`opponent ${owner}`, (unit) => isOpponent(owner, unit.owner))(point, range);
    },
    opponentCombatUnitsNear(owner, point, range) {
      return unitsNear(`opponent ${owner}`, (unit) => isOpponent(owner, unit.owner))(point, range, combatUnit);
    },
    opponentBuildingsNear(owner, point, range) {
      return snapshot.buildings.filter((building) => isOpponent(owner, building.owner) && distance3(building, point) <= range);
    },
    hostileUnitsNear(owner, point, range) {
      return unitsNear(`hostile ${owner}`, (unit) => isOpponent(owner, unit.owner) || unit.owner === "neutral")(point, range);
    },
    hostileCombatUnitsFor(owner) {
      let units2 = hostileCombatUnitsByOwner.get(owner);
      if (!units2) hostileCombatUnitsByOwner.set(owner, units2 = snapshot.units.filter((unit) => (isOpponent(owner, unit.owner) || unit.owner === "neutral") && unit.kind !== "worker"));
      return units2.slice();
    },
    playerUnits(owner, relation, kind) {
      const view = cachedPlayerView(owner, this)[relation];
      return (kind === "worker" ? view.workers : kind === "combat" ? view.combatUnits : view.units).slice();
    },
    playerBuildings(owner, relation, completeOnly) {
      const view = cachedPlayerView(owner, this)[relation];
      return (completeOnly ? view.completeBuildings : view.buildings).slice();
    },
    neutralUnitsFor(owner) {
      return cachedPlayerView(owner, this).neutral.units.slice();
    },
    forPlayer(owner) {
      const view = cachedPlayerView(owner, this);
      return {
        owner: view.owner,
        team: view.team,
        own: copyEntityView(view.own),
        allied: copyEntityView(view.allied),
        enemy: copyEntityView(view.enemy),
        neutral: { units: view.neutral.units.slice() },
        resources: entitySet(snapshot.resources),
        mercenaryCamps: entitySet(snapshot.mercenaryCamps),
        items: { ground: view.items.ground.slice(), carried: view.items.carried.slice() }
      };
    }
  };
}
function firstById(entities) {
  const byId = /* @__PURE__ */ new Map();
  for (const entity of entities) if (!byId.has(entity.id)) byId.set(entity.id, entity);
  return byId;
}
function playerEntityViews(snapshot, owner, ownTeam, teamFor) {
  const emptyView = () => ({ units: [], workers: [], combatUnits: [], buildings: [], completeBuildings: [] });
  const own = emptyView(), allied = emptyView(), enemy = emptyView();
  const neutral = [];
  const addUnit = (view, unit) => {
    view.units.push(unit);
    (unit.kind === "worker" ? view.workers : view.combatUnits).push(unit);
  };
  const addBuilding = (view, building) => {
    view.buildings.push(building);
    if (building.complete) view.completeBuildings.push(building);
  };
  snapshot.units.forEach((unit) => {
    const candidate = unit.owner;
    if (candidate === "neutral") neutral.push(unit);
    if (candidate === owner) addUnit(own, unit);
    if (candidate !== "neutral") {
      const team = teamFor(candidate);
      if (candidate !== owner && team === ownTeam) addUnit(allied, unit);
      if (team !== ownTeam) addUnit(enemy, unit);
    }
  });
  snapshot.buildings.forEach((building) => {
    const candidate = building.owner;
    if (candidate === owner) addBuilding(own, building);
    if (candidate !== "neutral") {
      const team = teamFor(candidate);
      if (candidate !== owner && team === ownTeam) addBuilding(allied, building);
      if (team !== ownTeam) addBuilding(enemy, building);
    }
  });
  return { own, allied, enemy, neutral: { units: neutral } };
}
function copyEntityView(view) {
  return {
    units: view.units.slice(),
    workers: view.workers.slice(),
    combatUnits: view.combatUnits.slice(),
    buildings: view.buildings.slice(),
    completeBuildings: view.completeBuildings.slice()
  };
}
function entitySet(all) {
  return {
    all,
    nearestTo(point) {
      return nearestEntity2(all, point);
    }
  };
}
function nearestEntity2(candidates, point) {
  return candidates.map((candidate) => ({ candidate, distance: distance3(candidate, point) })).sort((a, b) => a.distance - b.distance)[0]?.candidate;
}
function distance3(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/ground.ts
function sameGroundAs(snapshot, home, point) {
  return groundWholes(snapshot.map) <= 1 || sameGround(snapshot.map, home, point);
}
function withoutShips(snapshot, units2) {
  return shipsAfloat(snapshot) ? units2.filter((unit) => unitMover(unit.kind) === "land" && !unit.deck) : units2;
}
var afloat = /* @__PURE__ */ new WeakMap();
function shipsAfloat(snapshot) {
  let known = afloat.get(snapshot);
  if (known === void 0) {
    known = snapshot.units.some((unit) => unitMover(unit.kind) === "sea");
    afloat.set(snapshot, known);
  }
  return known;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/snapshot.ts
var noTeamsQueryKey = {};
var snapshotQueryCache = /* @__PURE__ */ new WeakMap();
var budgetWorlds = /* @__PURE__ */ new WeakMap();
var lastQuery;
function aiSnapshotQuery(snapshot, teams) {
  const key = teams ?? noTeamsQueryKey;
  if (lastQuery && lastQuery.snapshot === snapshot && lastQuery.key === key) return lastQuery.query;
  let byTeams = snapshotQueryCache.get(snapshot);
  if (!byTeams) {
    byTeams = /* @__PURE__ */ new WeakMap();
    snapshotQueryCache.set(snapshot, byTeams);
  }
  let query = byTeams.get(key);
  if (!query) {
    const world = budgetWorlds.get(snapshot);
    if (teams && Object.entries(teams).every(([owner, team]) => owner === team)) query = aiSnapshotQuery(snapshot);
    else if (world) query = { ...aiSnapshotQuery(world, teams), snapshot };
    else query = createSnapshotQuery(snapshot, { ...teams ? { teams } : {}, excludeIssuedWeapons: true });
    byTeams.set(key, query);
  }
  lastQuery = { snapshot, key, query };
  return query;
}
function activePlayerIds(snapshot) {
  return aiSnapshotQuery(snapshot).activePlayerIds();
}
function buildings(snapshot, owner) {
  return aiSnapshotQuery(snapshot).buildingsFor(owner);
}
function units(snapshot, owner) {
  return aiSnapshotQuery(snapshot).unitsFor(owner);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/ownership.ts
function opponentPlayerIds(snapshot, owner, options) {
  return activePlayerIds(snapshot).filter((candidate) => isOpponentOwner(snapshot, owner, candidate, options));
}
function isEnemyOwner(snapshot, owner, other, options) {
  if (other === "neutral") return true;
  return isOpponentOwner(snapshot, owner, other, options);
}
function isOpponentOwner(snapshot, owner, other, options) {
  if (other === "neutral") return false;
  return aiSnapshotQuery(snapshot, options.teams).isOpponent(owner, other);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/naval-services.ts
var cache = /* @__PURE__ */ new WeakMap();
function navalServices(snapshot, owner, options) {
  let byOwner = cache.get(snapshot);
  if (!byOwner) {
    byOwner = /* @__PURE__ */ new Map();
    cache.set(snapshot, byOwner);
  }
  const known = byOwner.get(owner);
  if (known) return known;
  const result = { commands: [], reserved: /* @__PURE__ */ new Set() };
  byOwner.set(owner, result);
  const own = snapshot.units.filter(
    (unit) => unit.owner === owner && unit.hp > 0
  ), ships = own.filter((unit) => isShipKind(unit.kind));
  const working = (ship) => combatCapability(snapshot, ship).armed;
  const blocked = (ship) => result.reserved.has(ship.id) || options.memory.naval?.outfit?.shipId === ship.id || Boolean(options.memory.naval?.ferries?.[ship.id]);
  const safe = (point, range) => !foes.some(
    (foe) => combatCapability(snapshot, foe).armed && distance2(foe, point) < range
  );
  const awaitBoarding = (target) => {
    if (target.owner === owner && target.order.type !== "idle")
      result.commands.push({ type: "stop", unitIds: [target.id] });
  };
  const transfer = (crew, target) => {
    result.reserved.add(crew.id);
    result.reserved.add(target.id);
    if (crew.deck) result.reserved.add(crew.deck.shipId);
    awaitBoarding(target);
    result.commands.push({
      type: "board",
      unitIds: [crew.id],
      transportId: target.id
    });
  };
  for (const crew of own)
    if (crew.order.type === "board" && !options.memory.naval?.ferries?.[crew.order.transportId]) {
      result.reserved.add(crew.id);
      if (crew.deck) result.reserved.add(crew.deck.shipId);
      result.reserved.add(crew.order.transportId);
      const target = ships.find((ship) => crew.order.type === "board" && ship.id === crew.order.transportId);
      if (target) awaitBoarding(target);
    }
  if (ships.length === 0) return result;
  const foes = snapshot.units.filter(
    (unit) => unit.hp > 0 && isEnemyOwner(snapshot, owner, unit.owner, options)
  );
  if ((snapshot.players[owner]?.gold ?? 0) > 30)
    for (const ship of [...ships].sort(
      (a, b) => a.hp / a.maxHp - b.hp / b.maxHp
    )) {
      if (blocked(ship) || !shipNeedsRepair(snapshot, ship) || shipPassengers(snapshot.units, ship).some(
        (crew) => crew.owner === owner && crew.kind === "worker" && !isInCabin(crew)
      ))
        continue;
      const worker = own.filter(
        (crew) => crew.kind === "worker" && crew.deck && !isInCabin(crew) && !result.reserved.has(crew.id) && crew.order.type !== "board" && canBoard(ship, crew, snapshot.units)
      ).filter((crew) => {
        const source = ships.find(
          (source2) => source2.id === crew.deck.shipId
        );
        return source && !blocked(source) && source.hp / source.maxHp >= 0.75 && sameGround(snapshot.map, source, ship, "sea") && distance2(source, ship) < 1400;
      }).sort((a, b) => distance2(a, ship) - distance2(b, ship))[0];
      if (worker && (safe(ship, 500) || ship.hp / ship.maxHp < 0.6))
        transfer(worker, ship);
    }
  for (const ship of ships.filter(
    (ship2) => !blocked(ship2) && working(ship2) && ship2.hp / ship2.maxHp >= 0.8
  )) {
    const crew = shipPassengers(snapshot.units, ship).find(
      (crew2) => crew2.owner === owner && crew2.kind !== "worker" && crew2.attackRange <= 80 && !isInCabin(crew2) && !result.reserved.has(crew2.id) && crew2.order.type !== "board"
    );
    if (!crew) continue;
    const prize = foes.filter(shipProfile).filter(
      (prize2) => !result.reserved.has(prize2.id) && !shipPassengers(snapshot.units, prize2).length && distance2(ship, prize2) < 650 && sameGround(snapshot.map, ship, prize2, "sea") && canBoard(prize2, crew, snapshot.units)
    ).filter(
      (prize2) => !foes.some(
        (other) => other.id !== prize2.id && combatCapability(snapshot, other).armed && distance2(prize2, other) < 500
      )
    ).sort((a, b) => distance2(ship, a) - distance2(ship, b))[0];
    if (prize) transfer(crew, prize);
  }
  const dock = snapshot.buildings.find(
    (building) => building.owner === owner && building.kind === "shipyard" && building.complete
  );
  const harborGround = dock && walkableGoal(snapshot.map, dock.x, dock.y, "land");
  const workers = own.filter(
    (crew) => crew.kind === "worker" && !crew.deck && Boolean(harborGround && sameGround(snapshot.map, crew, harborGround)) && ["idle", "mine"].includes(crew.order.type)
  );
  if (dock && ships.length >= 2 && workers.length >= 7) {
    const ship = ships.filter(
      (ship2) => !blocked(ship2) && working(ship2) && distance2(ship2, dock) < 600 && safe(ship2, 500) && !shipPassengers(snapshot.units, ship2).some(
        (crew) => crew.kind === "worker"
      )
    ).sort((a, b) => b.maxHp - a.maxHp)[0];
    const worker = ship && workers.filter(
      (worker2) => !result.reserved.has(worker2.id) && !worker2.mineSlot && distance2(worker2, dock) < 650 && canBoard(ship, worker2, snapshot.units)
    ).sort((a, b) => distance2(a, ship) - distance2(b, ship))[0];
    if (ship && worker) transfer(worker, ship);
  }
  return result;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/fleet-formation.ts
function fleetStations(snapshot, ships, goal, memory) {
  const stations = /* @__PURE__ */ new Map();
  if (!goal || ships.length < 3) {
    delete memory.muster;
    return stations;
  }
  const fleet = ships.filter(
    (ship) => sameGround(snapshot.map, ship, goal, "sea")
  );
  if (fleet.length < 3) return stations;
  const center = {
    x: fleet.reduce((s, ship) => s + ship.x, 0) / fleet.length,
    y: fleet.reduce((s, ship) => s + ship.y, 0) / fleet.length
  };
  const leader = [...fleet].sort(
    (a, b) => b.maxHp - a.maxHp || distance2(a, center) - distance2(b, center) || a.id.localeCompare(b.id)
  )[0];
  if (!memory.muster || distance2(memory.muster.goal, goal) > 300 || !fleet.some((ship) => ship.id === memory.muster.leader)) {
    const at2 = nearestShipPose(snapshot.map, leader, leader) ?? leader;
    memory.muster = {
      at: { x: at2.x, y: at2.y },
      goal: { x: goal.x, y: goal.y },
      leader: leader.id,
      sinceTick: snapshot.tick,
      launched: false,
      heading: Math.atan2(goal.y - at2.y, goal.x - at2.x)
    };
  }
  const muster = memory.muster;
  if (fleet.filter((ship) => distance2(ship, muster.at) < 450).length / fleet.length >= 0.75 || snapshot.tick - muster.sinceTick > seconds(30))
    muster.launched = true;
  const anchor = muster.launched ? goal : muster.at, heading = muster.heading ??= Math.atan2(goal.y - muster.at.y, goal.x - muster.at.x);
  const beam = Math.max(...fleet.map((ship) => shipProfile(ship).beam)) + 70, length = Math.max(...fleet.map((ship) => shipProfile(ship).length)) + 70;
  const ordered = [...fleet].sort((a, b) => Number(b.id === muster.leader) - Number(a.id === muster.leader) || a.id.localeCompare(b.id));
  ordered.forEach((ship, i) => {
    const side = [0, -1, 1][i % 3] * beam, back = Math.floor(i / 3) * length;
    const at2 = nearestShipPose(snapshot.map, ship, {
      x: anchor.x - Math.sin(heading) * side - Math.cos(heading) * back,
      y: anchor.y + Math.cos(heading) * side - Math.sin(heading) * back
    });
    if (at2) stations.set(ship.id, at2);
  });
  return stations;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/combat-target.ts
function combatTargetScore(target, gap, threat = "none", remainingHp = target.hp) {
  if (remainingHp <= 0) return -Infinity;
  const unit = "order" in target;
  const value = unit ? target.kind === "worker" ? 260 : 430 : target.attackDamage > 0 ? 360 : target.kind === "townHall" ? 120 : 220;
  const vulnerable = unit ? Math.min(120, Math.max(0, target.maxHp - remainingHp) * 1.4) : 0;
  const weapon = target.attackDamage * 2 + (unit && target.attackRange > 100 ? 20 : 0);
  return value + vulnerable + weapon + (threat === "self" ? 150 : threat === "ally" ? 90 : 0) - gap * 0.9;
}
function shouldSwitchCombatTarget(currentScore, nextScore) {
  return nextScore > currentScore + 60;
}
function combatVictimId(target) {
  if (!("order" in target)) return void 0;
  const order = target.order;
  return order.type === "attack" || order.type === "attackMove" || order.type === "cast" || order.type === "charge" ? order.targetId : void 0;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/fleet-engagement.ts
function fleetTarget(ship, candidates, memory) {
  const orders = memory.combat ??= {};
  const saved = orders[ship.id];
  const current = candidates.find((target) => target.id === saved?.targetId);
  let best, bestScore = -Infinity;
  for (const candidate of candidates) {
    const score = combatTargetScore(candidate, distance2(ship, candidate));
    if (score > bestScore || score === bestScore && candidate.id < (best?.id ?? "\uFFFF")) {
      best = candidate;
      bestScore = score;
    }
  }
  if (current && best && !shouldSwitchCombatTarget(combatTargetScore(current, distance2(ship, current)), bestScore)) best = current;
  if (!best) {
    delete orders[ship.id];
    return;
  }
  if (!saved) orders[ship.id] = { targetId: best.id };
  else saved.targetId = best.id;
  return best;
}
function fleetAttackCommand(ship, target, memory) {
  const state = memory.combat[ship.id];
  if ((ship.order.type === "attack" || ship.order.type === "attackMove") && ship.order.targetId === target.id || ship.order.type === "attackMove" && state.commandTargetId === target.id) return;
  state.commandTargetId = target.id;
  return { type: "attackMove", unitIds: [ship.id], x: target.x, y: target.y };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/aiming.ts
var AIM_SPEED_MULTIPLIER = 2 / 3;

// ../sketch-rts-six-player-structural-before-0f31/src/shared/connected-decks.ts
var CONTACT_CLEARANCE = 0.5;
function seamPoints(a, b) {
  const points = [];
  for (const [hull, other] of [[a, b], [b, a]]) for (let i = 0; i < hull.length; i++) {
    const from = hull[i], to = hull[(i + 1) % hull.length], interval = clipToConvex(from, to, other);
    if (!interval) continue;
    for (const fraction of [0.25, 0.5, 0.75]) {
      const t = interval[0] + (interval[1] - interval[0]) * fraction;
      points.push({ x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t });
    }
  }
  return points;
}
function shipShorePoints(ship, map) {
  const profile = shipProfile(ship);
  if (!profile || !map.terrain)
    return [];
  const points = [];
  for (let i = 0; i < profile.hull.length; i++) {
    const a = profile.hull[i], b = profile.hull[(i + 1) % profile.hull.length], steps = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 10));
    for (let j = 0; j <= steps; j++) {
      const at2 = localToWorld(ship, { x: a.x + (b.x - a.x) * j / steps, y: a.y + (b.y - a.y) * j / steps });
      if (isOpenGround(map, at2.x, at2.y, "land"))
        points.push(at2);
    }
  }
  return points;
}
function decksTouch(a, b, passenger) {
  const aa = shipProfile(a), bb = shipProfile(b);
  return Boolean(a.hp > 0 && b.hp > 0 && aa && bb && Math.abs(aa.deckHeight - bb.deckHeight) <= passenger.radius * 2 && Math.hypot(a.x - b.x, a.y - b.y) < (aa.length + bb.length) / 2 && hullGap(a, b) <= CONTACT_CLEARANCE);
}
function supportedSeamPoints(a, b, passenger) {
  if (!decksTouch(a, b, passenger)) return [];
  const hulls = [a, b].map((ship) => expandConvex(shipProfile(ship).hull.map((point) => localToWorld(ship, point)), CONTACT_CLEARANCE / 2));
  const floor = supportSurface(hulls, void 0, { left: 0, top: 0, right: 0, bottom: 0 });
  const obstacles = [a, b].flatMap((ship) => shipProfile(ship).obstacles.map((obstacle) => ({ ...localToWorld(ship, obstacle), radius: obstacle.radius })));
  return seamPoints(hulls[0], hulls[1]).filter((point) => floor.diskFits(point, passenger.radius + 1) && capsuleClearsCircles(point, point, passenger.radius + 1, obstacles));
}
function seamVelocity(ship, point) {
  const motion = ship.sailing, heading = motion?.heading ?? 0, speed = motion?.speed ?? 0;
  return shipPointVelocity(ship, point, {
    x: motion?.velocityX ?? speed * detCos(heading) + (ship.pushX ?? 0),
    y: motion?.velocityY ?? speed * detSin(heading) + (ship.pushY ?? 0)
  });
}
function decksAllowCrossing(a, b, passenger) {
  const points = supportedSeamPoints(a, b, passenger);
  return points.length > 0 && points.every((point) => {
    const av = seamVelocity(a, point), bv = seamVelocity(b, point);
    return Math.hypot(av.x - bv.x, av.y - bv.y) <= SHIP_IMPACT_SAFE_SPEED + 1e-6;
  });
}
function decksCanTransfer(a, b, passenger) {
  return decksAllowCrossing(a, b, passenger) || !!gangwayBetween(a, b, passenger);
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/naval.ts
function canReach(map, attacker, target, units2 = [], attackRange = attacker.attackRange) {
  if (isInCabin(attacker) || "order" in target && isInCabin(target)) return false;
  const targetDeck = "order" in target && target.deck && units2.find((ship) => ship.id === target.deck.shipId);
  if (attacker.deck) {
    if ("deck" in target && target.deck?.shipId === attacker.deck.shipId) return true;
    const ship = units2.find((unit) => unit.id === attacker.deck.shipId);
    if (ship && targetDeck && decksCanTransfer(ship, targetDeck, attacker)) return true;
    if (ship && !targetDeck && shipShorePoints(ship, map).some((point) => sameGround(map, point, target, "land"))) return true;
    const stand2 = ship && deckPlacement(ship, attacker, units2, worldToLocal(ship, target), false);
    const at2 = ship && stand2 ? localToWorld(ship, stand2) : attacker;
    return ("order" in target && shipProfile(target) ? distanceToHull(target, at2) : Math.hypot(at2.x - target.x, at2.y - target.y) - ("order" in target ? 0 : target.radius)) <= attackRange;
  }
  if (!map.terrain) return true;
  if (targetDeck && unitMover(attacker.kind) === "land" && shipShorePoints(targetDeck, map).some((point) => sameGround(map, attacker, point, "land"))) return true;
  const mover = unitMover(attacker.kind);
  if (isWalkable(map, target.x, target.y, mover) && sameGround(map, attacker, target, mover)) return true;
  const stand = walkDestination(map, attacker, walkableGoal(map, target.x, target.y, mover), mover);
  return ("order" in target && shipProfile(target) ? distanceToHull(target, stand) : Math.hypot(stand.x - target.x, stand.y - target.y) - ("order" in target ? 0 : target.radius)) <= attackRange;
}
var BOARDING_GAP = 24;
function carries(unit) {
  return shipProfile(unit)?.loadCapacity ?? 0;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/purchase.ts
var PURCHASE_REACH = 120;
function purchaseRecipientInRange(unit, seller) {
  const gap = shipProfile(unit) ? distanceToHull(unit, seller) : Math.hypot(unit.x - seller.x, unit.y - seller.y) - unit.radius;
  return gap <= seller.radius + PURCHASE_REACH;
}
function purchasePlacement(snapshot, owner, seller, kind, recipientId) {
  const recipient = snapshot.units.find((unit) => unit.id === recipientId && unit.hp > 0 && unit.owner === owner);
  if (!recipient)
    return { refusal: "Choose a living unit or ship of yours" };
  if (isInCabin(recipient))
    return { refusal: "Leave the cabin before receiving equipment" };
  const profile = shipProfile(recipient);
  if (!purchaseRecipientInRange(recipient, seller))
    return { refusal: "Move the recipient closer to the seller" };
  const ship = profile ? recipient : snapshot.units.find((unit) => unit.id === recipient.deck?.shipId);
  if (ship && shipProfile(ship)) {
    const load = snapshot.units.filter((unit) => unit.deck?.shipId === ship.id).reduce((sum, unit) => sum + bodyMass(unit), 0) + shipItemMass(snapshot, ship);
    if (load + ITEM_DEFS[kind].mass > shipProfile(ship).loadCapacity)
      return { refusal: "The ship cannot carry more weight" };
  }
  if (profile) {
    const occupied = new Set(snapshot.items.filter((item) => item.shipId === recipient.id && item.holdSlot !== void 0).flatMap((item) => Array.from({ length: ITEM_DEFS[item.kind].span ?? 1 }, (_, i) => item.holdSlot + i)));
    const span = ITEM_DEFS[kind].span ?? 1, slots = shipHoldSlots(recipient);
    for (let slot2 = 0; slot2 + span <= slots; slot2++)
      if (Array.from({ length: span }, (_, i) => slot2 + i).every((i) => !occupied.has(i)))
        return { placement: { shipId: recipient.id, slot: slot2 } };
    return { refusal: span === 4 ? "The hold needs four consecutive free positions" : "The hold has no free position" };
  }
  if (!canEquip(recipient))
    return { refusal: "This unit cannot carry equipment" };
  const slot = freeItemSlot(snapshot, recipient, kind);
  return slot ? { placement: { unitId: recipient.id, slot } } : { refusal: "The recipient has no compatible free position" };
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/shop.ts
var SHOP_GOODS = [
  { kind: "leatherArmor", cost: 120, maxStock: 1, restock: seconds(90) },
  { kind: "roundShield", cost: 90, maxStock: 1, restock: seconds(90) },
  { kind: "greatSword", cost: 140, maxStock: 1, restock: seconds(120) },
  { kind: "speedBoots", cost: 100, maxStock: 1, restock: seconds(90) },
  { kind: "regenRing", cost: 75, maxStock: 1, restock: seconds(90) },
  { kind: "healingScroll", cost: 100, maxStock: 2, restock: seconds(45) },
  { kind: "guardianScroll", cost: 200, maxStock: 1, restock: seconds(120) },
  { kind: "ivoryTower", cost: 200, maxStock: 1, restock: seconds(120) }
];

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-defense.ts
function combatHull(ship) {
  return Boolean(shipProfile(ship)) && !isTransportKind(ship.kind);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/transfer-lanes.ts
var cache2 = /* @__PURE__ */ new WeakMap();
function clearTransferLanes(snapshot, owner) {
  let owners = cache2.get(snapshot);
  if (!owners) {
    owners = /* @__PURE__ */ new Map();
    cache2.set(snapshot, owners);
  }
  const known = owners.get(owner);
  if (known) return known;
  const own = snapshot.units.filter((unit) => unit.owner === owner && !unit.deck && unitMover(unit.kind) === "land");
  const commands = [], assigned = /* @__PURE__ */ new Set();
  const destinations = [];
  for (const passenger of own) {
    const order = passenger.order;
    if (order.type !== "board" || !order.berth) continue;
    const boat = snapshot.units.find((unit) => unit.id === order.transportId);
    if (!boat) continue;
    const shore = order.berth.shore ?? order.berth;
    if (distance2(passenger, shore) > 300) continue;
    const dx = passenger.x - shore.x, dy = passenger.y - shore.y, length = Math.hypot(dx, dy) || 1;
    for (const unit of own) {
      if (assigned.has(unit.id) || unit.kind === "worker" || distance2(unit, shore) > 220) continue;
      if (unit.order.type === "move" && unit.order.avoidCombat) {
        assigned.add(unit.id);
        commands.push({ type: "move", unitIds: [unit.id], x: unit.order.x, y: unit.order.y, avoidCombat: true });
        continue;
      }
      if (!["idle", "hold"].includes(unit.order.type)) continue;
      let goal;
      for (const reach of [250, 330, 410]) {
        for (const lateral of [0, 80, -80, 160, -160]) {
          const point = walkDestination(snapshot.map, unit, { x: shore.x + dx / length * reach - dy / length * lateral, y: shore.y + dy / length * reach + dx / length * lateral });
          if (!isWalkable(snapshot.map, point.x, point.y) || distance2(point, shore) < 220 || distanceToHull(boat, point) < unit.radius + 80) continue;
          if (destinations.some((d) => distance2(d, point) < d.radius + unit.radius + 8)) continue;
          if (snapshot.units.some((other) => other.id !== unit.id && !other.deck && distance2(other, point) < other.radius + unit.radius + 8)) continue;
          goal = point;
          break;
        }
        if (goal) break;
      }
      if (!goal) continue;
      assigned.add(unit.id);
      destinations.push({ ...goal, radius: unit.radius });
      commands.push({ type: "move", unitIds: [unit.id], ...goal, avoidCombat: true });
    }
  }
  owners.set(owner, commands);
  return commands;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/convoy-load.ts
function convoyCanCarry(snapshot, boats, passengers) {
  const hulls = new Set(boats.map((boat) => boat.id));
  const reserved = snapshot.units.filter((unit) => unit.deck && hulls.has(unit.deck.shipId));
  const seen = new Set(reserved.map((unit) => unit.id));
  const candidates = passengers.filter((unit) => !seen.has(unit.id) && Boolean(seen.add(unit.id))).sort((a, b) => b.radius - a.radius || a.id.localeCompare(b.id));
  for (const unit of candidates) {
    let fits = false;
    for (const boat of boats) {
      const copy = { ...unit, deck: void 0 };
      if (!boardUnit(boat, copy, reserved)) continue;
      reserved.push(copy);
      fits = true;
      break;
    }
    if (!fits) return false;
  }
  return true;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/world-model.ts
function canSupply(snapshot, owner, unitKind) {
  return projectedSupplyUsed(snapshot, owner) + UNIT_DEFS[unitKind].supplyUsed <= playerState(snapshot, owner).supplyCap;
}
function playerState(snapshot, owner) {
  const player = snapshot.players[owner];
  if (!player) throw new Error(`Unknown player ${owner}`);
  return player;
}
function projectedSupplyUsed(snapshot, owner) {
  const queued = buildings(snapshot, owner).flatMap((building) => building.queue).reduce((total, job) => total + UNIT_DEFS[job.unitKind].supplyUsed, 0);
  const supply = (unit) => UNIT_DEFS[unit.kind].supplyUsed + (unit.cargo ?? []).reduce((total, passenger) => total + supply(passenger), 0);
  return units(snapshot, owner).reduce((total, unit) => total + supply(unit), 0) + queued;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/build-layout.ts
var PASSAGE = 48;
var MINE_LANE = 450;
var LANE_WIDTH = 24;
function roomyPlacement(snapshot, kind, point) {
  if (!snapshot.map.terrain) return isBuildPlacementClear(snapshot, kind, point);
  const radius = BUILDING_DEFS[kind].radius;
  for (const building of snapshot.buildings) {
    const reach = radius + building.radius + PASSAGE;
    const dx = point.x - building.x;
    const dy = point.y - building.y;
    if (dx * dx + dy * dy < reach * reach) return false;
  }
  for (const [hall, mine] of mineLanes(snapshot)) if (segmentDistance(point, hall, mine) < radius + LANE_WIDTH) return false;
  if (kind !== "townHall" && kind !== "defenseTower" && !clearOfTerrain(snapshot, point, radius + PASSAGE)) return false;
  return isBuildPlacementClear(snapshot, kind, point);
}
function clearOfTerrain(snapshot, point, reach) {
  const terrain = snapshot.map.terrain;
  const size = terrain.cell;
  for (let row = Math.floor((point.y - reach) / size); row <= Math.floor((point.y + reach) / size); row += 1) {
    for (let col = Math.floor((point.x - reach) / size); col <= Math.floor((point.x + reach) / size); col += 1) {
      const x = (col + 0.5) * size;
      const y = (row + 0.5) * size;
      if ((x - point.x) ** 2 + (y - point.y) ** 2 >= reach * reach) continue;
      if (!isWalkable(snapshot.map, x, y)) return false;
    }
  }
  return true;
}
var lanesBySnapshot = /* @__PURE__ */ new WeakMap();
function mineLanes(snapshot) {
  const known = lanesBySnapshot.get(snapshot);
  if (known) return known;
  const lanes = [];
  for (const hall of snapshot.buildings) {
    if (hall.kind !== "townHall") continue;
    for (const mine of snapshot.resources) if (mine.amount > 0 && distance2(hall, mine) <= MINE_LANE) lanes.push([hall, mine]);
  }
  lanesBySnapshot.set(snapshot, lanes);
  return lanes;
}
function segmentDistance(point, a, b) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const length2 = dx * dx + dy * dy || 1;
  const t = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / length2));
  return Math.hypot(point.x - (a.x + t * dx), point.y - (a.y + t * dy));
}
function legalBuildPointNear(snapshot, kind, preferred) {
  if (kind === "townHall") {
    const mine = nearestEntity(snapshot.resources.filter((resource) => resource.amount > 0), preferred);
    if (mine && distance2(mine, preferred) <= GOLD_MINE_RULES.baseRange) {
      const site = miningHallSite(snapshot, mine, preferred);
      if (site) return site;
    }
  }
  if (roomyPlacement(snapshot, kind, preferred)) return preferred;
  const offsets = [72, 104, 140, 180, 230, 290, 360, 440, 520, 640, 800, 1e3].flatMap(
    (radius) => Array.from({ length: 16 }, (_, index) => {
      const angle2 = index / 16 * Math.PI * 2;
      return { x: detCos(angle2) * radius, y: detSin(angle2) * radius };
    })
  );
  return offsets.map((offset) => ({ x: clamp2(preferred.x + offset.x, 0, snapshot.map.width), y: clamp2(preferred.y + offset.y, 0, snapshot.map.height) })).find((point) => roomyPlacement(snapshot, kind, point)) ?? preferred;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/mine-claims.ts
function mineClaimedByAlly(snapshot, owner, mine, options) {
  const ally = (other) => other !== owner && other !== "neutral" && !isOpponentOwner(snapshot, owner, other, options);
  return snapshot.buildings.some((hall) => hall.kind === "townHall" && ally(hall.owner) && distance2(hall, mine) <= GOLD_MINE_RULES.baseRange) || snapshot.units.some((unit) => unit.kind === "worker" && ally(unit.owner) && unit.order.type === "mine" && unit.order.resourceId === mine.id);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v6/strength.ts
var TOWER_STRENGTH = 1.3;
var CASTER_STRENGTH = { summoner: 0.6, priest: 0.8, fieldMedic: 0.9, witch: 0.9, ashHexer: 0.9 };
var FOOTMAN_RATING = Math.sqrt(UNIT_DEFS.footman.hp * (UNIT_DEFS.footman.attackDamage / (UNIT_DEFS.footman.attackCooldown / SIM_TICKS_PER_SECOND)));
function combatRating(unit) {
  if (unit.kind === "worker") return 0;
  const base = CASTER_STRENGTH[unit.kind] ?? Math.sqrt(unit.maxHp * (unit.attackDamage / Math.max(1, unit.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
  return base * Math.max(0.1, unit.hp / Math.max(1, unit.maxHp)) * (UNIT_DEFS[unit.kind].threat ?? 1);
}
function effectiveCombatRating(snapshot, unit) {
  const weapon = combatCapability(snapshot, unit);
  return combatRating({ ...unit, attackDamage: weapon.dps, attackCooldown: SIM_TICKS_PER_SECOND });
}
function structureRating(building) {
  if (building.attackDamage <= 0) return 0;
  return Math.sqrt(building.hp * (building.attackDamage / Math.max(1, building.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
}
function unitStrength(unit) {
  if (unit.kind === "worker") return 0;
  const cost = UNIT_DEFS[unit.kind].cost;
  const base = CASTER_STRENGTH[unit.kind] ?? (cost > 0 ? cost / 100 : void 0) ?? Math.sqrt(unit.maxHp * (unit.attackDamage / Math.max(1, unit.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
  return base * Math.max(0.1, unit.hp / Math.max(1, unit.maxHp)) * (1 + VETERANCY_GAIN_PER_STAR * unit.level) * (UNIT_DEFS[unit.kind].threat ?? 1);
}
var SPIRIT_STRENGTH = Math.sqrt(UNIT_DEFS.spirit.hp * (UNIT_DEFS.spirit.attackDamage / (UNIT_DEFS.spirit.attackCooldown / SIM_TICKS_PER_SECOND))) / FOOTMAN_RATING;
var SUMMON = ABILITY_DEFS.summon;
var SPIRITS_PER_CASTER = SUMMON.behavior === "summon" ? SUMMON.summonDuration / SUMMON.cooldown : 1;
function strengthOf(units2) {
  return units2.reduce((total, unit) => total + unitStrength(unit), 0);
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/naval-mines.ts
function chooseNavalMine(snapshot, owner, candidates, options) {
  const fleet = snapshot.units.filter((unit) => unit.owner === owner && isTransportKind(unit.kind) && unit.hp > 0);
  const threats = [
    ...snapshot.units.filter((unit) => unit.hp > 0 && isEnemyOwner(snapshot, owner, unit.owner, options) && combatCapability(snapshot, unit).armed).map((unit) => ({ body: unit, rating: effectiveCombatRating(snapshot, unit) })),
    ...snapshot.buildings.filter((building) => building.hp > 0 && building.attackDamage > 0 && isEnemyOwner(snapshot, owner, building.owner, options)).map((building) => ({ body: building, rating: structureRating(building) }))
  ];
  return candidates.map((candidate) => {
    const origin = nearestByRoute(snapshot.map, [...fleet, candidate.departure], candidate.landing, "sea");
    const road = walkingDistance(snapshot.map, origin, candidate.landing, "sea");
    const threat = threats.filter(({ body }) => distance2(body, candidate.mine) < 400).reduce((score, { rating }) => score + rating, 0);
    return { candidate, threat, road };
  }).sort((a, b) => a.threat - b.threat || a.road - b.road)[0]?.candidate;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/map-pool.ts
var MAP_POOL = [
  { id: "sapphireArchipelago", name: { en: "Sapphire Archipelago", zh: "\u84DD\u5B9D\u7FA4\u5C9B" }, players: 6, layout: { seed: "pool-sapphire-1", kind: "ring", idea: "islandStarts", size: 10240 } },
  { id: "grandEstuary", name: { en: "Grand Estuary", zh: "\u516B\u65B9\u6CB3\u6E7E" }, players: 8, layout: { seed: "pool-grandEstuary-1", kind: "sides", idea: "riverValley", size: 10240 } },
  { id: "brokenSea", name: { en: "Broken Sea", zh: "\u788E\u6D77" }, players: 4, layout: { seed: "pool-brokenSea-1", kind: "ring", idea: "islandStarts" } },
  { id: "templeSpring", name: { en: "Temple Spring", zh: "\u795E\u6CC9\u6BBF" }, players: 4, layout: { seed: "pool-templeSpring-1", kind: "ring", idea: "fountainRing", size: 6656 } },
  { id: "turtleLake", name: { en: "Turtle Lake", zh: "\u9F9F\u6E56" }, players: 4, layout: { seed: "pool-turtleLake-1", kind: "ring", idea: "turtleIsle" } },
  { id: "elderwood", name: { en: "Elderwood", zh: "\u53E4\u6728\u6797" }, players: 4, layout: { seed: "pool-elderwood-1", kind: "ring", idea: "twistedPaths" } },
  { id: "ringwater", name: { en: "Ringwater", zh: "\u73AF\u6D77" }, players: 4, layout: { seed: "pool-ringwater-1", kind: "ring", idea: "outerSea" } },
  { id: "loneMarket", name: { en: "Lone Market", zh: "\u5B64\u5E02" }, players: 2, layout: { seed: "pool-loneMarket-1", kind: "ring", idea: "oneMarket" } },
  { id: "reedwater", name: { en: "Reedwater", zh: "\u82A6\u82C7\u6CFD" }, players: 2, layout: { seed: "pool-reedwater-1", kind: "ring", idea: "floodedValley" } },
  { id: "veiledHill", name: { en: "Veiled Hill", zh: "\u96FE\u4E18" }, players: 2, layout: { seed: "pool-veiledHill-1", kind: "ring", idea: "hiddenHill" } },
  { id: "greystonePass", name: { en: "Greystone Pass", zh: "\u7070\u5CA9\u9698\u53E3" }, players: 2, layout: { seed: "pool-greystonePass-1", kind: "ring", idea: "bridgeStand" } },
  { id: "pineshade", name: { en: "Pineshade", zh: "\u677E\u5F71\u6797" }, players: 2, layout: { seed: "pool-pineshade-1", kind: "ring", idea: "deepJungle" } },
  { id: "gullIsland", name: { en: "Gull Island", zh: "\u9E25\u5C9B" }, players: 2, layout: { seed: "pool-gullIsland-1", kind: "ring", idea: "northIsles", size: 6656 } },
  { id: "stillwater", name: { en: "Stillwater", zh: "\u9759\u6C34\u539F" }, players: 4, layout: { seed: "pool-stillwater-1", kind: "sides", idea: "riverValley" } },
  { id: "twoShores", name: { en: "Two Shores", zh: "\u53CC\u5CB8" }, players: 4, layout: { seed: "pool-twoShores-1", kind: "sides", idea: "twoShores" } }
];

// ../sketch-rts-six-player-structural-before-0f31/src/shared/map-ids.ts
var BASE_MAP_IDS = ["verdantCrossroads", "bareDuel", "openClaims", "campRush", "combatArena", "goldGrid", "mercPocket"];
var LADDER_MAP_ID = "ladder";
var MAP_IDS = [...BASE_MAP_IDS, LADDER_MAP_ID, "grandThirty", ...MAP_POOL.map((map) => map.id)];
var LADDER_SLOT_IDS = Array.from({ length: 64 }, (_, index) => `ladder-${String(index + 1).padStart(2, "0")}`);

// ../sketch-rts-six-player-structural-before-0f31/src/shared/map.ts
var DEFAULT_MAP_ID = "verdantCrossroads";
var STANDARD_MAP_SIZE = 4096;
var COMBAT_ARENA_MAP_SIZE = 1600;
var AUTHOR_MAP_SIZE = 8192;
var MAP_SCALE = STANDARD_MAP_SIZE / AUTHOR_MAP_SIZE;
var MAP_SCENARIOS = [
  { id: "ladder", name: "Ladder Map", note: "Every game draws a new War3-style ladder map: each main on a plateau with one ramp, a natural of its own, guarded contested mines, mercenary posts and a hard middle, walled by forest, rock and water.", tags: ["generated", "terrain", "expansions", "wild camps", "mercs"] },
  ...MAP_POOL.map((map) => ({ id: map.id, name: map.name.en, note: `A ${map.players}-player War3-style ladder map, ${map.layout.kind === "sides" ? "two teams facing each other across it" : "every start on one ring"}.`, tags: ["pool", `${map.players} players`, map.layout.kind, ..."idea" in map.layout ? [map.layout.idea] : []] })),
  { id: "verdantCrossroads", name: "Verdant Crossroads", note: "Compact ladder-style map with expansions, wild camps, and a mercenary crossroad.", tags: ["4096", "expansions", "wild camps", "mercs"] },
  { id: "bareDuel", name: "Bare Duel", note: "A cleaner duel layout for AI pressure tests without neutral distractions.", tags: ["4096", "few camps", "fast contact"] },
  { id: "openClaims", name: "Open Claims", note: "Expansion-focused economy map with no neutral camps blocking the mines.", tags: ["4096", "expansions", "no wild camps"] },
  { id: "campRush", name: "Camp Rush", note: "No-expansion pressure map where neutral camps and mercenaries shape the route.", tags: ["4096", "no expansions", "wild camps"] },
  { id: "combatArena", name: "Combat Arena", note: "Small benchmark arena for mixed-army micro without economy or neutral routing.", tags: ["1600", "combat", "micro"] },
  { id: "goldGrid", name: "Gold Grid", note: "V5 economy research map with sixteen open gold points for expansion stress tests.", tags: ["4096", "research", "many mines", "no wild camps"] },
  { id: "mercPocket", name: "Merc Pocket", note: "V5 economy research map with nearby unguarded mercenary camps for hire-tempo stress tests.", tags: ["4096", "research", "mercs", "no wild camps"] },
  { id: "grandThirty", name: "Grand Thirty", note: "Super-large 15v15 stress battlefield with many starts, lanes, mines, camps, and room-scale minimap proof.", tags: ["12288", "15v15", "stress", "many camps"] }
];
function createMap(id = DEFAULT_MAP_ID) {
  const scenario = scenarioFor(id);
  const mapSize = mapSizeFor(id);
  return {
    id,
    name: scenario.name,
    width: mapSize,
    height: mapSize,
    landmarks: scenarioLandmarks(id)
  };
}
var SAMPLE_MAP = createMap(DEFAULT_MAP_ID);
function mapSizeFor(id) {
  if (id === "grandThirty") return STANDARD_MAP_SIZE * 3;
  if (id === "combatArena") return COMBAT_ARENA_MAP_SIZE;
  return STANDARD_MAP_SIZE;
}
function scenarioLandmarks(id) {
  const landmarks = [
    { id: "road-west-1", kind: "road", x: 1180, y: 1240, size: 420, rotation: 0.3 },
    { id: "road-mid-1", kind: "road", x: 2380, y: 2440, size: 520, rotation: 0.8 },
    { id: "road-mid-2", kind: "road", x: 3980, y: 3900, size: 660, rotation: 0.7 },
    { id: "road-east-1", kind: "road", x: 6100, y: 6020, size: 520, rotation: 0.8 },
    { id: "grove-player", kind: "grove", x: 650, y: 1460, size: 340, rotation: 0.1 },
    { id: "grove-north", kind: "grove", x: 3360, y: 1040, size: 420, rotation: 1.2 },
    { id: "grove-center", kind: "grove", x: 4820, y: 3480, size: 360, rotation: 0.4 },
    { id: "grove-enemy", kind: "grove", x: 6880, y: 6520, size: 420, rotation: 0.7 },
    { id: "ridge-north", kind: "ridge", x: 4100, y: 980, size: 500, rotation: 0.2 },
    { id: "ridge-west", kind: "ridge", x: 1740, y: 3180, size: 460, rotation: 1.4 },
    { id: "ridge-south", kind: "ridge", x: 3960, y: 6640, size: 540, rotation: 0.4 },
    { id: "ruin-center-a", kind: "ruin", x: 4096, y: 4200, size: 260, rotation: 0.1 },
    { id: "ruin-center-b", kind: "ruin", x: 4416, y: 4460, size: 220, rotation: 0.6 },
    { id: "ditch-west", kind: "ditch", x: 2540, y: 4520, size: 560, rotation: 0.15 },
    { id: "ditch-east", kind: "ditch", x: 5700, y: 3320, size: 620, rotation: -0.2 },
    { id: "camp-north", kind: "campMark", x: 3980, y: 1540, size: 220, rotation: 0.2 },
    { id: "camp-center", kind: "campMark", x: 4096, y: 4200, size: 260, rotation: 0.7 },
    { id: "camp-south", kind: "campMark", x: 3700, y: 6080, size: 240, rotation: 0.5 },
    { id: "scar-player", kind: "mineScar", x: 1180, y: 920, size: 220, rotation: 0.4 },
    { id: "scar-enemy", kind: "mineScar", x: 7e3, y: 7140, size: 240, rotation: 0.4 },
    { id: "scar-center", kind: "mineScar", x: 4096, y: 4200, size: 180, rotation: 0.2 },
    { id: "stone-crossroad", kind: "bannerStone", x: 4020, y: 4020, size: 180, rotation: 0.1 },
    { id: "stone-west", kind: "bannerStone", x: 2060, y: 2200, size: 140, rotation: 0.3 },
    { id: "stone-east", kind: "bannerStone", x: 5920, y: 5900, size: 140, rotation: 0.3 }
  ];
  const scaled = landmarks.map(scaleLandmark);
  if (id === "combatArena") return [];
  if (id === "bareDuel") return scaled.filter((landmark) => landmark.kind !== "campMark").slice(0, 20);
  if (id === "openClaims") return scaled.filter((landmark) => landmark.kind !== "campMark");
  if (id === "campRush") return scaled.filter((landmark) => landmark.kind !== "mineScar" || landmark.id === "scar-player" || landmark.id === "scar-enemy");
  if (id === "grandThirty") return grandThirtyLandmarks();
  return scaled;
}
function scenarioFor(id) {
  const scenario = MAP_SCENARIOS.find((candidate) => candidate.id === id);
  if (!scenario) throw new Error(`Unknown map scenario ${id}`);
  return scenario;
}
function scale(value) {
  return value * MAP_SCALE;
}
function scaleLandmark(landmark) {
  return { ...landmark, x: scale(landmark.x), y: scale(landmark.y), size: scale(landmark.size) };
}
function grandThirtyLandmarks() {
  const mapSize = STANDARD_MAP_SIZE * 3;
  const landmarks = [];
  for (let i = 0; i < 15; i += 1) {
    const y = mapSize * ((i + 1) / 16);
    landmarks.push(
      { id: `grand-road-${i}`, kind: "road", x: mapSize / 2, y, size: 720, rotation: i % 2 === 0 ? 0.1 : -0.1 },
      { id: `grand-grove-west-${i}`, kind: "grove", x: mapSize * 0.27, y: y + 120, size: 260, rotation: i * 0.2 },
      { id: `grand-ridge-east-${i}`, kind: "ridge", x: mapSize * 0.73, y: y - 120, size: 280, rotation: -i * 0.18 },
      { id: `grand-camp-${i}`, kind: "campMark", x: mapSize * (i % 2 === 0 ? 0.42 : 0.58), y, size: 180, rotation: i * 0.31 }
    );
  }
  for (let i = 0; i < 10; i += 1) {
    landmarks.push({ id: `grand-ruin-${i}`, kind: "ruin", x: mapSize * (0.35 + i % 5 * 0.075), y: mapSize * (0.15 + Math.floor(i / 5) * 0.7), size: 240, rotation: i * 0.21 });
  }
  return landmarks;
}

// ../sketch-rts-six-player-structural-before-0f31/src/shared/generated-map.ts
var TERRAIN_CELL = 32;
var MINE_BASE_CLEARING = GOLD_MINE_RULES.baseRange + footprintHalf(BUILDING_DEFS.townHall.radius, TERRAIN_CELL) + TERRAIN_CELL;
var ISLAND_RADIUS = MINE_BASE_CLEARING + 40;

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/versions.ts
function isV8Policy(options) {
  return options.requestedVersion === "v8" || options.requestedVersion === "v9";
}
function isV9Policy(options) {
  return options.requestedVersion === "v9";
}
var SHOOTER_UNIT_KINDS = /* @__PURE__ */ new Set(["archer", "horseArcher", "sparkArcher", "contractArcher"]);
var SUMMONING_UNIT_KINDS = new Set(
  Object.keys(UNIT_DEFS).filter((kind) => UNIT_DEFS[kind].abilities.some((ability) => ABILITY_DEFS[ability].behavior === "summon"))
);
var V8_FORBIDDEN_UNIT_KINDS = /* @__PURE__ */ new Set([...SHOOTER_UNIT_KINDS, ...SUMMONING_UNIT_KINDS]);

// ../sketch-rts-six-player-structural-before-0f31/src/shared/player-colors.ts
var PLAYER_COLORS = [
  "#477b91",
  "#a85644",
  "#5d8b4c",
  "#7f3a70",
  "#b97927",
  "#2f766f",
  "#c56a32",
  "#409ba9",
  "#b7638f",
  "#899c43",
  "#625eaa",
  "#c4ab43",
  "#45a57d",
  "#a084ba",
  "#cf6a69",
  "#8d5a46",
  "#4365b0",
  "#ab4f9b",
  "#71a6b8",
  "#b7a476",
  "#56846f",
  "#9b6c59",
  "#6e769b",
  "#9a9e69"
];
var DEFAULT_COLORS = {
  player: PLAYER_COLORS[0],
  enemy: PLAYER_COLORS[1],
  enemy2: PLAYER_COLORS[2],
  fleet: "#799199",
  crown: "#a45c4b"
};

// ../sketch-rts-six-player-structural-before-0f31/src/shared/spark-fire.ts
var SPARK_FIRE = { chance: 0.15, radius: 38, duration: seconds(6), damage: 1, tickEvery: seconds(0.5) };

// ../sketch-rts-six-player-structural-before-0f31/src/shared/item-rules.ts
var LIGHTNING_ROD = { range: 280, damage: 84, hits: 3, bounceRange: 170, decay: 0.68, minimumDamage: 18, cooldown: seconds(18) };
var STORM_STAFF = { range: 320, radius: 145, impactDamage: 24, pulseDamage: 6, pulseEvery: seconds(1.2), duration: seconds(4.8), cooldown: seconds(27) };
var FLAME_CLOAK = { radius: 90, damage: 12, interval: seconds(2) };
var GUARDIAN_SCROLL = { radius: 280, duration: seconds(7) };

// ../sketch-rts-six-player-structural-before-0f31/src/shared/ship-pursuit.ts
var STATION_OFFSETS = [0, ...Array.from({ length: 11 }, (_, index) => [(index + 1) * Math.PI / 12, -(index + 1) * Math.PI / 12]).flat(), Math.PI];

// ../sketch-rts-six-player-structural-before-0f31/src/shared/sim.ts
var MINE_RANGE = GOLD_MINE_RULES.entryRange;
var TOWN_HALL_DROP_RANGE = GOLD_MINE_RULES.dropRange;
var GOLD_PER_TRIP = GOLD_MINE_RULES.goldPerTrip;
var GATHER_DURATION = seconds(GOLD_MINE_RULES.gatherSeconds);
var GOLD_MINE_ENTRY_COOLDOWN = seconds(GOLD_MINE_RULES.entrySeconds);
var SCORCH_DURATION = seconds(8);
var FLAME_CLOAK_VISUAL_DURATION = seconds(1.7);
var MOON_WELL_HEAL_EFFECT_DURATION = seconds(1.1);
var REPAIR_HP_PER_SECOND = UNIT_DEFS.footman.attackDamage / (UNIT_DEFS.footman.attackCooldown / seconds(1));
var REPAIR_HAMMER_EFFECT_DURATION = seconds(3);
var AUTO_ACQUIRE_RANGE = 230;
var MAX_BUILDING_RADIUS = Math.max(...Object.values(BUILDING_DEFS).map((def) => def.radius));
var MAX_UNIT_RADIUS = Math.max(...Object.values(UNIT_DEFS).map((def) => def.radius));

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v6/intel.ts
var HOME_RANGE = 900;
var PUSH_RANGE = 1300;
var CREEP_CONTACT = 320;
var BASE_WORKER_RANGE = 520;
var BASE_DEFENSE_RANGE = 700;
var INTRUSION_RANGE = 750;
var INTRUDER_GROUP_RANGE = 1e3;
var cache3 = /* @__PURE__ */ new WeakMap();
function readV6Intel(snapshot, owner, options) {
  const perSnapshot = cache3.get(snapshot) ?? /* @__PURE__ */ new Map();
  cache3.set(snapshot, perSnapshot);
  const cached2 = perSnapshot.get(owner);
  if (cached2) return cached2;
  const ownHalls = buildings(snapshot, owner).filter((building) => building.kind === "townHall" && building.complete);
  const ownBuildings = buildings(snapshot, owner);
  const army = withoutShips(snapshot, units(snapshot, owner).filter((unit) => unit.kind !== "worker"));
  const home = ownHalls[0] ?? ownBuildings[0] ?? { x: snapshot.map.width / 2, y: snapshot.map.height / 2 };
  const neutrals = snapshot.units.filter((unit) => unit.owner === "neutral");
  const enemies = opponentPlayerIds(snapshot, owner, options).map((enemy) => readEnemy(snapshot, enemy, ownBuildings, neutrals));
  const intrusion = readIntrusion(ownBuildings, enemies, isV9Policy(options));
  const intel = {
    tick: snapshot.tick,
    home: { x: home.x, y: home.y },
    ownHalls,
    ownTowers: ownBuildings.filter((building) => building.kind === "defenseTower" && building.complete),
    army,
    ...army.length > 0 ? { armyCenter: averagePoint(army) } : {},
    power: strengthOf(army),
    enemies,
    ...intrusion ? { intrusion } : {}
  };
  perSnapshot.set(owner, intel);
  return intel;
}
function readEnemy(snapshot, enemy, ownBuildings, neutrals) {
  const home = ownBuildings.find((building) => building.kind === "townHall" && building.complete) ?? ownBuildings[0];
  const all = withoutShips(snapshot, units(snapshot, enemy)).filter((unit) => !home || sameGroundAs(snapshot, home, unit));
  const army = all.filter((unit) => unit.kind !== "worker");
  const workers = all.filter((unit) => unit.kind === "worker");
  const enemyBuildings2 = buildings(snapshot, enemy).filter((building) => !home || sameGroundAs(snapshot, home, building));
  const halls = enemyBuildings2.filter((building) => building.kind === "townHall");
  const center = army.length > 0 ? averagePoint(army) : void 0;
  const bases = halls.map((hall) => {
    const towers = enemyBuildings2.filter((building) => building.kind === "defenseTower" && building.complete && distance2(building, hall) <= BASE_DEFENSE_RANGE);
    const defenders = army.filter((unit) => distance2(unit, hall) <= BASE_DEFENSE_RANGE);
    return { hall, owner: enemy, workers: workers.filter((worker) => distance2(worker, hall) <= BASE_WORKER_RANGE), towers, defenders, defense: strengthOf(defenders) + towers.length * TOWER_STRENGTH };
  });
  return { owner: enemy, army, ...center ? { center } : {}, power: strengthOf(army), state: enemyState(army, center, halls, ownBuildings, neutrals), bases, buildings: enemyBuildings2, workers };
}
function readIntrusion(ownBuildings, enemies, homeAware) {
  const nearest = (unit, points) => points.reduce((best, point) => Math.min(best, distance2(unit, point)), Infinity);
  const atHome = (unit, enemy) => nearest(unit, enemy.bases.map((base) => base.hall)) < nearest(unit, ownBuildings);
  const army = enemies.flatMap((enemy) => homeAware ? enemy.army.filter((unit) => !atHome(unit, enemy)) : enemy.army);
  const armyNear = withinRangeOf(army, INTRUSION_RANGE);
  const attacked = ownBuildings.map((building) => ({ building, threat: strengthOf(armyNear(building)) })).filter(({ threat }) => threat > 0).sort((a, b) => b.threat - a.threat)[0];
  if (!attacked) return void 0;
  const attackers = army.filter((unit) => distance2(unit, attacked.building) <= INTRUDER_GROUP_RANGE);
  return { building: attacked.building, attackers, threat: strengthOf(attackers) };
}
function enemyState(army, center, halls, ownBuildings, neutrals) {
  if (!center || army.length === 0) return "none";
  if (ownBuildings.some((building) => distance2(building, center) <= PUSH_RANGE)) return "pushing";
  const armyNear = withinRangeOf(army, CREEP_CONTACT);
  const inCreepContact = new Set(neutrals.flatMap((neutral) => armyNear(neutral))).size;
  if (inCreepContact >= Math.max(2, army.length * 0.4)) return "creeping";
  if (halls.some((hall) => distance2(hall, center) <= HOME_RANGE)) return "home";
  return "away";
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v7/creep.ts
var GATHER_TICKS = 25 * 20;
var RETRY_TICKS = 30 * 20;
var CREEP_STAGING_TURNS = [0, 30, -30, 60, -60, 90, -90].map((degrees) => degrees * Math.PI / 180);

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v8/doctrine.ts
var RAIDERS = { kinds: ["raider", "knight"], size: 4, cooldownSeconds: 90 };
var MAIN_TOWERS = { towers: "main", count: 1, priority: 61 };
var NATURAL_TOWER = { towers: "outposts", count: 1, priority: 61 };
var V8_STRATEGIES = [
  {
    // Raiders that charge, priests and witches behind them, and from the second phase knights ahead of all else: the
    // economy buys the farms to the elite bar for them. Left in the third phase, which opens at supply 70 while V8 stood
    // near 40, knights never came (none in 56 games by 12:00); wanted from the second, they came in 31 of 55 by 10:00,
    // and the grove line won 614 of 1000 games against 541.
    id: "grove-cavalry-line",
    race: "grove",
    weight: 1,
    phases: [
      {
        wants: [
          { unit: "priest", count: 2, priority: 65 },
          MAIN_TOWERS,
          { bases: 2, priority: 60 },
          NATURAL_TOWER,
          { unit: "raider", count: 6, priority: 58 },
          { unit: "witch", count: 2, priority: 56 }
        ],
        advanceShare: 0.75,
        advanceSupply: 42
      },
      {
        wants: [
          { bases: 2, priority: 66 },
          { unit: "knight", count: 6, priority: 61 },
          { unit: "raider", count: 8, priority: 58 },
          { unit: "priest", count: 3, priority: 56 },
          { unit: "witch", count: 3, priority: 55 },
          { building: "stables", count: 2, priority: 52 },
          { upgrade: "weaponTraining", level: 1, priority: 51 },
          { bases: 3, priority: 45 }
        ],
        advanceShare: 0.75,
        advanceSupply: 70
      },
      {
        wants: [
          { unit: "knight", count: 12, priority: 57 },
          { unit: "raider", count: 12, priority: 55 },
          { unit: "priest", count: 4, priority: 53 },
          { unit: "witch", count: 4, priority: 53 },
          { upgrade: "weaponTraining", level: 2, priority: 51 },
          { upgrade: "reinforcedPlating", level: 2, priority: 50 },
          { bases: 3, priority: 50 },
          { towers: "outposts", count: 1, priority: 44 },
          { bases: 4, priority: 35 }
        ],
        advanceShare: 1,
        advanceSupply: 1e3
      }
    ],
    raids: [RAIDERS],
    // @@@v8-lancer-stand-in - The opening's soldier is the lancer, not the footman: chasing V5's archers, footmen hit the
    // one they chased 6% of the time, the slowest of V8's fighters (3.1 to the archers' 3.0); the lancer walks 3.4 and
    // strikes from 74. With it V8 won 1225 of 2000 games against 1195 (297 of 500 on unseen seeds against 292).
    standIn: "lancer",
    opensOnState: true,
    // @@@v8-grove-rising-strike - Since a hall under construction starts at a tenth of its health (see construction-hp),
    // the cavalry line strikes rising halls too: it held its lancers at the rally from 3:19 to 5:30 while V7's center
    // hall rose from 90 (umberCauseway, 4:30); by hand five lancers razed it by 4:50 without a loss and the AI won the
    // game it had lost. Nudged tune games 6737 -> 6889 of 8000 (grove 3399 -> 3551, ember unchanged).
    risingStrike: true
  },
  {
    // Ravagers, acolytes and hexers, with ash chieftains as soon as the tier opens; cinder revenants later.
    id: "ember-ravager-line",
    race: "ember",
    weight: 1,
    phases: [
      {
        wants: [
          { unit: "priest", count: 2, priority: 65 },
          MAIN_TOWERS,
          { bases: 2, priority: 60 },
          NATURAL_TOWER,
          { unit: "emberRavager", count: 8, priority: 58 },
          { unit: "ashHexer", count: 2, priority: 56 }
        ],
        advanceShare: 0.75,
        advanceSupply: 42
      },
      {
        wants: [
          { bases: 2, priority: 66 },
          { unit: "ashChieftain", count: 6, priority: 61 },
          { unit: "emberRavager", count: 10, priority: 58 },
          { unit: "priest", count: 3, priority: 56 },
          { unit: "ashHexer", count: 3, priority: 55 },
          { building: "emberForge", count: 2, priority: 52 },
          { upgrade: "reinforcedPlating", level: 1, priority: 51 },
          { bases: 3, priority: 45 }
        ],
        advanceShare: 0.75,
        advanceSupply: 70
      },
      {
        wants: [
          { unit: "emberRavager", count: 16, priority: 55 },
          { unit: "ashChieftain", count: 10, priority: 57 },
          { unit: "cinderRevenant", count: 6, priority: 54 },
          { unit: "priest", count: 4, priority: 53 },
          { unit: "ashHexer", count: 4, priority: 53 },
          { upgrade: "weaponTraining", level: 2, priority: 51 },
          { upgrade: "reinforcedPlating", level: 2, priority: 50 },
          { bases: 3, priority: 50 },
          { towers: "outposts", count: 1, priority: 44 },
          { bases: 4, priority: 35 }
        ],
        advanceShare: 1,
        advanceSupply: 1e3
      }
    ],
    raids: [],
    standIn: "emberRavager",
    opensOnState: true,
    // @@@v8-ember-rising-strike - The ravager line strikes rising halls. While a rising hall still had its full health,
    // over 8000 nudged replays of the tune seeds towers first plus the strike won 92 more ember games and 33 fewer grove
    // games than the baseline, towers first alone 17 and 28 more; with the strike in the ravager line only, 8000 nudged
    // replays of 40 unseen seeds won 207 more (ember 175, grove 32). The cavalry line took it later (see
    // v8-grove-rising-strike).
    risingStrike: true
  }
];

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v9/doctrine.ts
var RESEARCH_HALL = { grove: "barracks", ember: "emberForge" };
var UPGRADE_PHASES = 3;
var EARLY_SOLDIERS = [
  { count: 8, priority: 59 },
  { count: 10, priority: 55 }
];
var V9_BASES = [
  { bases: 3, priority: 65 },
  { bases: 4, priority: 61 }
];
var HOLD_UPGRADES = [
  { upgrade: "buildingDurability", level: 1, priority: 58 },
  { upgrade: "speedTraining", level: 1, priority: 54 }
];
function v9Phases(strategy) {
  const hall = RESEARCH_HALL[strategy.race];
  return strategy.phases.map((phase, index) => {
    const bases = [...phase.wants.filter((want) => (!("bases" in want) || want.bases < 3) && !("upgrade" in want && HOLD_UPGRADES.some((hold) => hold.upgrade === want.upgrade))), ...V9_BASES, ...HOLD_UPGRADES];
    if (index >= UPGRADE_PHASES) return { ...phase, wants: bases };
    const level = index + 1;
    const priority = 62 - index;
    const soldiers = EARLY_SOLDIERS[index];
    return {
      ...phase,
      wants: [
        ...bases.filter((want) => !("upgrade" in want) || want.upgrade !== "weaponTraining" && want.upgrade !== "reinforcedPlating"),
        { upgrade: "weaponTraining", level, priority },
        { upgrade: "reinforcedPlating", level, priority },
        { building: hall, count: 2, priority },
        ...soldiers ? [{ unit: strategy.standIn, count: soldiers.count, priority: soldiers.priority }] : []
      ]
    };
  });
}
function fortressPhase(strategy) {
  return {
    wants: [
      { bases: 2, priority: 66 },
      { towers: "outposts", count: 6, priority: 64 },
      { unit: strategy.standIn, count: 16, priority: 62 },
      { towers: "main", count: 3, priority: 60 },
      { bases: 3, priority: 65 },
      { bases: 4, priority: 61 }
    ],
    advanceShare: 0.75,
    advanceSupply: 44
  };
}
var V9_STRATEGIES = V8_STRATEGIES.map((strategy) => ({ ...strategy, risingStrike: false, opensOnState: false, phases: [fortressPhase(strategy), ...v9Phases(strategy)] }));

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v9/march.ts
var ARRIVED = 350;

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v9/front.ts
var CREEP_CLEARANCE = ARRIVED + AUTO_ACQUIRE_RANGE;
var CAMP_CLEARANCE = BUILDING_DEFS.defenseTower.attackRange + 60;

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/v6/general.ts
var GATHER_TICKS2 = 45 * 20;
var ATTACK_MARGIN = 1.3;
var V8_ATTACK_MARGIN = 1.6;
function attackMargin(options) {
  return isV8Policy(options) ? V8_ATTACK_MARGIN : ATTACK_MARGIN;
}
var IDLE_TICKS = 90 * 20;
var REGROUP_TICKS = 30 * 20;
var V9_STALE_TICKS = 3 * 90 * 20;

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/engagements.ts
function engagementTargets(snapshot, owner, options) {
  const entities = new Map([...snapshot.units, ...snapshot.buildings].map((entity) => [entity.id, entity]));
  const own = snapshot.units.filter((unit) => unit.owner === owner && unit.kind !== "worker" && unit.attackDamage > 0);
  const foes = [...entities.values()].filter((target) => target.hp > 0 && isEnemyOwner(snapshot, owner, target.owner, options));
  const pending = /* @__PURE__ */ new Map();
  for (const shot of snapshot.projectiles) if (shot.owner === owner) pending.set(shot.targetId, (pending.get(shot.targetId) ?? 0) + shot.damage);
  const result = /* @__PURE__ */ new Map();
  for (const fighter of own) {
    const order = fighter.order;
    if (fighter.hp < fighter.maxHp * 0.4 || !(order.type === "attack" || order.type === "attackMove") || !order.targetId) continue;
    const current = entities.get(order.targetId);
    if (!current) continue;
    const near = own.filter((unit) => unit !== fighter && distance2(unit, fighter) < 250);
    const screened = near.filter((unit) => unit.attackRange <= 100 && unitMover(unit.kind) === unitMover(fighter.kind)).length >= 2;
    const threat = (target2) => {
      const victim = entities.get(combatVictimId(target2) ?? "");
      return victim && !isEnemyOwner(snapshot, owner, victim.owner, options) && distance2(victim, fighter) < 350 ? victim.id === fighter.id ? "self" : "ally" : "none";
    };
    const score = (target2) => {
      const gap = Math.max(0, distance2(fighter, target2) - ("order" in target2 ? 0 : target2.radius));
      const effort = UNIT_DEFS[fighter.kind].weapon ? Math.max(0, gap - fighter.attackRange) + Math.min(gap, fighter.attackRange) * 0.25 : gap;
      const base = combatTargetScore(target2, effort, threat(target2), target2.hp - (pending.get(target2.id) ?? 0));
      const siege = (UNIT_DEFS[fighter.kind].weapon?.buildingMultiplier ?? 1) >= 1.5;
      return base + (siege && !("order" in target2) ? 220 + (screened ? 150 : 0) : 0);
    };
    const general = options.memory.v6?.general;
    const local2 = foes.filter((target2) => {
      const reach = "order" in target2 ? Math.max(fighter.attackRange + 80, target2.attackRange + target2.speed * 2 + 50) : fighter.attackRange + target2.radius + 80;
      if (distance2(fighter, target2) > Math.min(600, reach) || !canReach(snapshot.map, fighter, target2)) return false;
      if (unitMover(fighter.kind) === "land" && general?.target && ["guard", "hold", "defend"].includes(general.mode) && distance2(target2, general.target) > (general.leash ?? 450)) return false;
      return true;
    });
    const danger = local2.filter((target2) => "order" in target2 && target2.kind !== "worker" && target2.attackDamage > 0);
    if (strengthOf(own.filter((unit) => distance2(unit, fighter) < 550)) < strengthOf(danger) * 0.8) continue;
    const candidate = local2.sort((a, b) => score(b) - score(a) || a.id.localeCompare(b.id))[0];
    const currentScore = canReach(snapshot.map, fighter, current) ? score(current) : -Infinity;
    const target = candidate && shouldSwitchCombatTarget(currentScore, score(candidate)) ? candidate : current;
    if (target.id !== current.id || local2.some((enemy) => "order" in enemy && enemy.attackDamage > 0 && (enemy.id === target.id || threat(enemy) !== "none"))) result.set(fighter.id, target);
  }
  return result;
}

// ../sketch-rts-six-player-structural-before-0f31/src/ai/policy/naval.ts
function ferryCapacity(unit) {
  return isTransportKind(unit.kind) ? carries(unit) : 0;
}
var WARSHIPS = 2;
var OUTFIT_RESERVE = 200;
var HOME_WATERS = 900;
var HALL_BERTH = 160;
var OFFSHORE_STEPS = 8;
var GUN_MARGIN = 100;
var TOWER_COVER = BUILDING_DEFS.defenseTower.attackRange;
var HURT = 0.4;
function navalBudgetReserve(snapshot, owner, options) {
  if (!snapshot.map.terrain || groundWholes(snapshot.map) <= 1)
    return 0;
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall");
  const home = halls[0];
  if (!home || !units(snapshot, owner).some((unit) => unit.kind === "worker"))
    return 0;
  if (snapshot.units.some((unit) => unit.kind !== "worker" && combatCapability(snapshot, unit).armed && isOpponentOwner(snapshot, owner, unit.owner, options) && halls.some((hall) => sameGround(snapshot.map, hall, unit) && distance2(hall, unit) < 700))) return 0;
  const remote = snapshot.resources.filter((mine) => mine.amount > 0 && !sameGround(snapshot.map, mine, home) && !halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange) && !mineClaimedByAlly(snapshot, owner, mine, options));
  if (!remote.length)
    return 0;
  const settling = Object.values(options.memory?.naval?.ferries ?? {}).some((mission) => mission.purpose === "settle" && mission.phase !== "return" && remote.some((mine) => mine.id === mission.targetId));
  const remaining = snapshot.resources.filter((mine) => mine.amount > 0 && halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange)).reduce((sum, mine) => sum + mine.amount, 0);
  const pendingHall = units(snapshot, owner).some((unit) => unit.order.type === "build" && unit.order.buildingKind === "townHall");
  const approachingDepletion = remaining < 2500 && !localExpansionAvailable(snapshot, owner, options);
  return ((settling || approachingDepletion) && !pendingHall ? BUILDING_DEFS.townHall.cost : 0) + (approachingDepletion && !units(snapshot, owner).some((unit) => ferryCapacity(unit) > 0) ? UNIT_DEFS.transport.cost : 0);
}
var navalReservePurchase = (id) => ["naval:islandHall", "naval:transport", "naval:shipyard", "naval:population"].includes(id);
function navalWant(snapshot, owner, options) {
  return planNavalWant(snapshot, owner, options, "all", () => true);
}
function colonyNavalWant(snapshot, owner, options) {
  return planNavalWant(snapshot, owner, options, "colonies", () => true);
}
function colonyNavalWantWithMineEligibility(snapshot, owner, options, eligible) {
  return planNavalWant(snapshot, owner, options, "colonies", eligible);
}
function planNavalWant(snapshot, owner, options, land, eligible) {
  const outfit = outfitting(snapshot, owner, options);
  if (outfit && !outfit.itemId && playerState(snapshot, owner).gold >= SHIP_WEAPONS[outfit.kind].cost + navalBudgetReserve(snapshot, owner, options) + OUTFIT_RESERVE) {
    const dock = buildings(snapshot, owner).find((building) => building.kind === "shipyard" && building.complete);
    if (dock && "placement" in purchasePlacement(snapshot, owner, dock, outfit.kind, outfit.shipId)) return { id: "naval:gun", cost: SHIP_WEAPONS[outfit.kind].cost, issue: () => ({ type: "buyShipEquipment", buildingId: dock.id, item: outfit.kind, recipientId: outfit.shipId }) };
  }
  const plan = islandPlan(snapshot, owner, options, eligible);
  const capital = settlementHallWant(snapshot, owner, plan);
  if (capital) return capital;
  const foothold = footholdWant(snapshot, owner);
  if (foothold)
    return { ...foothold, closeout: true };
  const threat = enemyShipsNear(snapshot, owner, options);
  if (!threat.length && groundWholes(snapshot.map) > 1 && localExpansionAvailable(snapshot, owner, options)) return localExpansionWant(snapshot, owner, options, land);
  const assault = assaultPlan(snapshot, owner, options);
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall" && building.complete);
  if (!halls.length)
    return void 0;
  const water = assault?.landing ?? plan?.landing ?? raidPlan(snapshot, owner, options)?.water ?? threat[0];
  if (!water)
    return void 0;
  const home = halls[0];
  const closeout = Boolean(assault && home && lastFight(snapshot, owner, options, home));
  const want = navalStep(snapshot, owner, options, plan ? void 0 : assault, plan, plan?.landing ?? water, halls);
  return want && closeout ? { ...want, closeout: true } : want;
}
function footholdWant(snapshot, owner) {
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall" && building.complete);
  const home = halls[0];
  if (!home)
    return void 0;
  for (const hall of halls.filter((hall2) => !sameGround(snapshot.map, hall2, home))) {
    const workers = units(snapshot, owner).filter((unit) => unit.kind === "worker" && sameGround(snapshot.map, unit, hall) && (unit.order.type === "mine" || unit.order.type === "idle"));
    const posts = buildings(snapshot, owner).filter((building) => sameGround(snapshot.map, building, hall));
    const race = snapshot.players[owner].race;
    const kind = race === "grove" ? "barracks" : "emberForge";
    const producer = posts.find((building) => building.kind === kind);
    if (!producer && workers.length)
      return { id: "naval:footholdProducer", cost: BUILDING_DEFS[kind].cost, issue: (used) => {
        if (used.size || units(snapshot, owner).some((unit) => unit.order.type === "build"))
          return void 0;
        const site = legalBuildPointNear(snapshot, kind, { x: hall.x + 180, y: hall.y + 100 });
        if (!sameGround(snapshot.map, site, hall) || !isBuildPlacementClear(snapshot, kind, site))
          return void 0;
        used.add(workers[0].id);
        return { type: "build", unitId: workers[0].id, buildingKind: kind, ...site };
      } };
    const army = units(snapshot, owner).filter((unit) => unit.kind !== "worker" && unitMover(unit.kind) === "land" && sameGround(snapshot.map, unit, hall));
    const troop = race === "grove" ? "footman" : "emberRavager";
    if (producer?.complete && !producer.queue.length && army.length < 8 && canSupply(snapshot, owner, troop))
      return { id: "naval:footholdArmy", cost: UNIT_DEFS[troop].cost, issue: () => ({ type: "train", buildingId: producer.id, unitKind: troop }) };
    if (!posts.some((building) => building.kind === "defenseTower" && distance2(building, hall) < 450) && workers.length)
      return { id: "naval:footholdTower", cost: BUILDING_DEFS.defenseTower.cost, issue: (used) => {
        if (used.size || units(snapshot, owner).some((unit) => unit.order.type === "build"))
          return void 0;
        const site = legalBuildPointNear(snapshot, "defenseTower", { x: hall.x - 160, y: hall.y + 110 });
        if (!sameGround(snapshot.map, site, hall) || !isBuildPlacementClear(snapshot, "defenseTower", site))
          return void 0;
        used.add(workers[0].id);
        return { type: "build", unitId: workers[0].id, buildingKind: "defenseTower", ...site };
      } };
  }
  return void 0;
}
function settlementHallWant(snapshot, owner, plan) {
  if (plan && !islandHallOf(snapshot, owner, plan) && !snapshot.units.some((unit) => unit.owner === "neutral" && distance2(unit, plan.mine) < 300)) {
    const site = hallSite(snapshot, plan.mine);
    const builder = site && nearestByRoute(snapshot.map, units(snapshot, owner).filter((unit) => unit.kind === "worker" && !unit.deck && unit.order.type !== "build" && sameGround(snapshot.map, unit, plan.mine)), site, "land");
    if (builder && site)
      return { id: "naval:islandHall", cost: BUILDING_DEFS.townHall.cost, issue: (used) => {
        if (used.has(builder.id) || builder.order.type === "build")
          return void 0;
        used.add(builder.id);
        return { type: "build", unitId: builder.id, buildingKind: "townHall", ...site };
      } };
  }
  return void 0;
}
function navalStep(snapshot, owner, options, assault, plan, water, halls) {
  const capital = settlementHallWant(snapshot, owner, plan);
  if (capital) return capital;
  const engineers = units(snapshot, owner).filter((unit) => unit.kind === "worker");
  if ((plan || assault) && engineers.length < 6) {
    const hall = halls.find((hall2) => hall2.complete && !hall2.queue.length);
    if (hall && canSupply(snapshot, owner, "worker"))
      return { id: "naval:engineer", cost: UNIT_DEFS.worker.cost, issue: () => ({ type: "train", buildingId: hall.id, unitKind: "worker" }) };
  }
  const yard = shipyardOf(snapshot, owner, water);
  if (!yard && !shoreSpot(snapshot, owner, water, options)) {
    if (buildings(snapshot, owner).some((building) => building.kind === "defenseTower" && !building.complete))
      return void 0;
    const site = shoreSpot(snapshot, owner, water, options, true);
    const hall = site && nearestByRoute(snapshot.map, halls, site, "land");
    const gun = site && nearestOf(snapshot.units.filter((unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && isEnemyOwner(snapshot, owner, unit.owner, options)), site);
    const workers = units(snapshot, owner).filter((unit) => unit.kind === "worker" && (unit.order.type === "mine" || unit.order.type === "idle"));
    return hall && gun ? coastTower(snapshot, hall, gun, workers, site) : void 0;
  }
  if (!yard) {
    return {
      id: "naval:shipyard",
      cost: BUILDING_DEFS.shipyard.cost,
      issue: (builders) => {
        if (builders.size || units(snapshot, owner).some((unit) => unit.order.type === "build"))
          return void 0;
        const spot = shoreSpot(snapshot, owner, water, options);
        const builder = spot && nearestWorker(snapshot, owner, spot, builders);
        if (!spot || !builder)
          return void 0;
        builders.add(builder.id);
        return { type: "build", unitId: builder.id, buildingKind: "shipyard", x: spot.x, y: spot.y };
      }
    };
  }
  const fleet = units(snapshot, owner);
  const armed = fleet.filter((unit) => combatHull(unit) && combatCapability(snapshot, unit).armed && sameGround(snapshot.map, unit, water, "sea"));
  const warships = armed.length;
  const transported = fleet.some((unit) => ferryCapacity(unit) > 0 && sameGround(snapshot.map, unit, water, "sea"));
  const convoy = fleet.filter((unit) => ferryCapacity(unit) > 0 && sameGround(snapshot.map, unit, water, "sea"));
  const held = outgunned(snapshot, owner, options, water, armed);
  const nearTowers = enemyTowers(snapshot, owner, options).some((tower) => distance2(tower, water) < 1100) || Boolean(assault && distance2(assault.target, water) - assault.target.radius > UNIT_DEFS.warship.attackRange);
  const enemyFleet = snapshot.units.filter((unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && isOpponentOwner(snapshot, owner, unit.owner, options) && sameGround(snapshot.map, unit, water, "sea") && distance2(unit, water) < 1800);
  const advanced = playerState(snapshot, owner).supplyCap >= requiredSupplyCap("bombardShip");
  const waiting = assault ? fleet.filter((unit) => !unit.deck && unitMover(unit.kind) === "land" && unit.kind !== "worker" && !unit.expiresTick && !sameGround(snapshot.map, unit, assault.target)) : [];
  const passengers = convoy.flatMap((unit) => shipPassengers(snapshot.units, unit));
  const crossing = [...waiting, ...passengers];
  const defense = assault ? landingDefense(snapshot, owner, options, assault.landing) : 0;
  const committedAssault = assault && convoy.some((unit) => navalMemory(options).ferries?.[unit.id]?.purpose === "assault" && navalMemory(options).ferries?.[unit.id]?.targetId === assault.target.id);
  const moreLift = assault && (!plan || committedAssault) && transported && crossing.reduce((n, unit) => n + effectiveCombatRating(snapshot, unit), 0) >= defense * 1.4 && !convoyCanCarry(snapshot, convoy, crossing);
  const guardedIsland = plan && snapshot.units.filter((unit) => unit.owner === "neutral" && distance2(unit, plan.mine) < 600).reduce((n, unit) => n + effectiveCombatRating(snapshot, unit), 0) > 3;
  const activeBases = halls.filter((hall) => snapshot.resources.some((mine) => mine.amount > 0 && distance2(mine, hall) < GOLD_MINE_RULES.baseRange)).length;
  const fleetTarget2 = Math.min(8, Math.max(WARSHIPS, activeBases > 2 ? activeBases + 1 : WARSHIPS, enemyFleet.length + 1));
  const ship = held ? warships < Math.max(6, fleetTarget2) ? "warship" : void 0 : !transported && (plan || assault) ? "transport" : moreLift ? advanced ? "carrier" : "transport" : advanced && guardedIsland && !fleet.some((unit) => unit.kind === "carrier" && sameGround(snapshot.map, unit, water, "sea")) ? "carrier" : warships < fleetTarget2 ? "warship" : advanced && nearTowers && !armed.some((unit) => unit.kind === "bombardShip") ? "bombardShip" : enemyFleet.length >= 3 && !armed.some((unit) => unit.kind === "fireShip") ? "fireShip" : warships >= 2 && !fleet.some((unit) => unit.kind === "cutter") ? "cutter" : advanced && assault && !fleet.some((unit) => unit.kind === "carrier") && fleet.filter((unit) => unitMover(unit.kind) === "land" && unit.kind !== "worker").length > 10 ? "carrier" : void 0;
  if (ship && yard.complete && yard.queue.length === 0) {
    if (canSupply(snapshot, owner, ship))
      return { id: `naval:${ship}`, cost: UNIT_DEFS[ship].cost, issue: () => ({ type: "train", buildingId: yard.id, unitKind: ship }) };
    const farmPending = buildings(snapshot, owner).some((building) => building.kind === "farm" && !building.complete) || units(snapshot, owner).some((unit) => unit.order.type === "build" && unit.order.buildingKind === "farm");
    const builder = units(snapshot, owner).find((unit) => unit.kind === "worker" && !unit.deck && (unit.order.type === "mine" || unit.order.type === "idle") && sameGround(snapshot.map, unit, halls[0]));
    const site = builder && legalBuildPointNear(snapshot, "farm", { x: halls[0].x + 170, y: halls[0].y - 130 });
    if (!farmPending && builder && site && isBuildPlacementClear(snapshot, "farm", site))
      return { id: "naval:population", cost: BUILDING_DEFS.farm.cost, issue: (used) => {
        if (used.has(builder.id)) return void 0;
        used.add(builder.id);
        return { type: "build", unitId: builder.id, buildingKind: "farm", ...site };
      } };
  }
  return void 0;
}
function navalStrength(snapshot, ships) {
  return ships.reduce((sum, ship) => sum + effectiveCombatRating(snapshot, ship), 0);
}
function coveringFleet(fleet, water) {
  return fleet.filter((ship) => distance2(ship, water) < HOME_WATERS && ship.hp >= ship.maxHp * HURT);
}
function outgunned(snapshot, owner, options, water, fleet) {
  const afloat2 = (unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && sameGround(snapshot.map, unit, water, "sea");
  const theirs = snapshot.units.filter((unit) => afloat2(unit) && distance2(unit, water) < HOME_WATERS && isEnemyOwner(snapshot, owner, unit.owner, options));
  if (theirs.length === 0)
    return false;
  const ours = fleet.filter((unit) => combatHull(unit) && afloat2(unit));
  const crew = ours.flatMap((ship) => shipPassengers(snapshot.units, ship)).filter((unit) => unit.hp > 0 && !isInCabin(unit) && !isEnemyOwner(snapshot, owner, unit.owner, options));
  return navalStrength(snapshot, theirs) * attackMargin(options) > navalStrength(snapshot, ours) + strengthOf(crew);
}
function planNavalEconomy(snapshot, owner, options) {
  const want = navalWant(snapshot, owner, options);
  const reserve = want && !navalReservePurchase(want.id) ? navalBudgetReserve(snapshot, owner, options) : 0;
  return want && playerState(snapshot, owner).gold - reserve >= want.cost ? want.issue(/* @__PURE__ */ new Set()) : void 0;
}
function planNavalTactics(snapshot, owner, options) {
  return planNavalTacticsWithAssignments(snapshot, owner, options, {
    orderCrew: (soldiers, _shore, boat) => soldiers.sort((a, b) => distance2(a, boat) - distance2(b, boat)),
    mineEligible: () => true,
    targetAvailable: () => true,
    transportReady: () => true,
    troopAvailable: () => true
  });
}
function planNavalTacticsWithAssignments(snapshot, owner, options, assignments) {
  const { orderCrew, mineEligible: eligible, targetAvailable, transportReady, troopAvailable } = assignments;
  const own = units(snapshot, owner);
  const plan = islandPlan(snapshot, owner, options, eligible);
  const assault = assaultPlan(snapshot, owner, options);
  const outfit = outfitting(snapshot, owner, options);
  const services = navalServices(snapshot, owner, options);
  const commands = [...clearTransferLanes(snapshot, owner), ...services.commands];
  if (outfit && !services.reserved.has(outfit.shipId)) commands.push(...outfitCommands(snapshot, owner, outfit));
  const harbor = buildings(snapshot, owner).find((building) => building.kind === "shipyard");
  let combatFoes;
  const foesForCombat = () => combatFoes ??= [...snapshot.units, ...snapshot.buildings].filter((target) => isEnemyOwner(snapshot, owner, target.owner, options));
  const convoy = own.filter((unit) => ferryCapacity(unit) > 0 && shipPassengers(snapshot.units, unit).length && navalMemory(options).ferries?.[unit.id]?.purpose !== "creep");
  const fighters = own.filter((unit) => combatHull(unit) && combatCapability(snapshot, unit).armed && !services.reserved.has(unit.id) && unit.id !== outfit?.shipId && !navalMemory(options).ferries?.[unit.id]);
  for (const id of Object.keys(navalMemory(options).combat ?? {})) if (!fighters.some((ship) => ship.id === id)) delete navalMemory(options).combat[id];
  const escortShips = fighters.filter((unit) => unit.kind !== "bombardShip");
  const escorts = /* @__PURE__ */ new Map();
  for (const ship of escortShips) {
    const boat = [...convoy].filter((boat2) => sameGround(snapshot.map, ship, boat2, "sea") && distance2(ship, boat2) < 1800 && [...escorts.values()].filter((escorted) => escorted.id === boat2.id).length < 2).sort((a, b) => [...escorts.values()].filter((boat2) => boat2.id === a.id).length - [...escorts.values()].filter((boat2) => boat2.id === b.id).length || distance2(ship, a) - distance2(ship, b))[0];
    if (boat) escorts.set(ship.id, boat);
  }
  const assigned = /* @__PURE__ */ new Set();
  const fleetGoal = assault ? offshore(snapshot, assault.landing, assault.target) : plan ? offshore(snapshot, plan.landing, plan.mine) : raidPlan(snapshot, owner, options)?.water;
  const stations = fleetStations(snapshot, fighters.filter((ship) => !escorts.has(ship.id) && ship.hp >= ship.maxHp * HURT), fleetGoal, navalMemory(options));
  for (const ship of fighters) {
    const foes = foesForCombat();
    const waiting = own.filter((unit) => unit.order.type === "board" && unit.order.transportId === ship.id);
    const aboard = shipPassengers(snapshot.units, ship);
    const safe = !foes.some((foe) => combatCapability(snapshot, foe).armed && distance2(foe, ship) < 600);
    if (harbor && safe && distance2(ship, harbor) < 650 && aboard.length + waiting.length < 2) {
      const candidates2 = own.filter((unit) => !unit.deck && !isInCabin(unit) && !assigned.has(unit.id) && unit.order.type !== "board" && (unit.order.type === "idle" || unit.order.type === "hold") && unitMover(unit.kind) === "land" && unit.kind !== "worker" && !unit.expiresTick && distance2(unit, harbor) < 600);
      const reserve = own.filter((unit) => !unit.deck && unit.kind !== "worker" && unitMover(unit.kind) === "land" && unit.order.type !== "board").length - 2;
      const reserved = [...snapshot.units];
      for (const unit of waiting) {
        const copy = { ...unit };
        if (boardUnit(ship, copy, reserved)) reserved.push(copy);
      }
      const recruits = candidates2.sort((a, b) => Number(UNIT_DEFS[b.kind].abilities.includes("heal")) - Number(UNIT_DEFS[a.kind].abilities.includes("heal")) || distance2(a, ship) - distance2(b, ship)).filter((unit) => {
        if (reserved.filter((unit2) => unit2.deck?.shipId === ship.id).length >= 2 || assigned.size >= reserve) return false;
        const copy = { ...unit };
        if (!boardUnit(ship, copy, reserved)) return false;
        reserved.push(copy);
        assigned.add(unit.id);
        return true;
      });
      if (recruits.length) {
        commands.push({ type: "board", unitIds: recruits.map((unit) => unit.id), transportId: ship.id });
        continue;
      }
    }
    if (waiting.length && safe) {
      if (ship.order.type !== "idle") commands.push({ type: "stop", unitIds: [ship.id] });
      continue;
    }
    const firingRange = combatCapability(snapshot, ship).range;
    const local2 = foes.filter((target2) => distance2(ship, target2) < Math.max(900, firingRange + 150) && canReach(snapshot.map, ship, target2, snapshot.units, firingRange));
    const danger = local2.filter((target2) => "order" in target2 && combatCapability(snapshot, target2).armed);
    const home2 = harbor && walkableGoal(snapshot.map, harbor.x, harbor.y, "sea");
    if (ship.hp < ship.maxHp * HURT && home2 && distance2(ship, home2) > 250) {
      if (needsMove(ship, home2))
        commands.push({ type: "move", unitIds: [ship.id], ...home2, avoidCombat: true });
      continue;
    }
    const targets = local2.filter((target2) => targetAvailable(target2) && (ship.kind === "bombardShip" || !covered(target2, enemyTowers(snapshot, owner, options)))).sort((a, b) => (ship.kind === "bombardShip" ? Number("order" in a) - Number("order" in b) : Number(!("order" in a)) - Number(!("order" in b))) || distance2(a, ship) - distance2(b, ship));
    const boat = escorts.get(ship.id);
    const mission = boat ? navalMemory(options).ferries?.[boat.id] : void 0;
    const station = boat ? mission?.phase === "loading" ? offshore(snapshot, mission.to, foes.find((target2) => target2.id === mission.targetId) ?? mission.to) : boat : stations.get(ship.id) ?? fleetGoal ?? home2;
    const attackers = boat ? danger.filter((target2) => "order" in target2 && (distance2(target2, boat) < combatCapability(snapshot, target2).range + 160 || target2.order.type === "attack" && target2.order.targetId === boat.id)) : [];
    const gathering = stations.has(ship.id) && !navalMemory(options).muster?.launched;
    const threats = danger.filter((target2) => "order" in target2 && unitMover(target2.kind) === "sea" && (!gathering || distance2(ship, target2) < combatCapability(snapshot, ship).range + 100) && (!boat || distance2(target2, boat) < 700 || station && distance2(target2, station) < 700));
    const candidates = attackers.length ? attackers : threats.length ? threats : !gathering && (!boat || station && distance2(ship, station) < 250) ? targets.filter((target2) => !boat || station && distance2(target2, station) < 450) : [];
    const target = fleetTarget(ship, candidates, navalMemory(options));
    if (target) {
      const command = fleetAttackCommand(ship, target, navalMemory(options));
      if (command) commands.push(command);
    } else if (!target) {
      const companions = boat ? [...escorts].filter(([, escorted]) => escorted.id === boat.id).map(([id]) => id) : [];
      const index = companions.indexOf(ship.id);
      const spacing = boat ? (shipProfile(boat).length + shipProfile(ship).length) / 2 + 60 : 0;
      const angle2 = (boat?.sailing?.heading ?? 0) + (index % 2 ? -1 : 1) * Math.PI / 2;
      const destination = boat && station === boat ? nearestShipPose(snapshot.map, ship, { x: boat.x + Math.cos(angle2) * spacing, y: boat.y + Math.sin(angle2) * spacing }) : station;
      if (destination && distance2(ship, destination) > (boat ? 70 : 200) && needsMove(ship, destination))
        commands.push({ type: "move", unitIds: [ship.id], x: destination.x, y: destination.y });
    }
  }
  const home = buildings(snapshot, owner).find((building) => building.kind === "townHall");
  const expedition = own.filter((unit) => !unit.deck && unitMover(unit.kind) === "land" && unit.kind !== "worker" && home && !sameGround(snapshot.map, unit, home) && unit.order.type !== "board" && troopAvailable(unit));
  const handled = /* @__PURE__ */ new Set();
  const interventions = expedition.length ? engagementTargets(snapshot, owner, options) : void 0;
  for (const troop of expedition) {
    const target = interventions.get(troop.id);
    if (target && (troop.order.type !== "attackMove" || distance2(troop.order, target) > 80)) commands.push({ type: "attackMove", unitIds: [troop.id], x: target.x, y: target.y });
  }
  for (const anchor of expedition) {
    if (handled.has(anchor.id)) continue;
    const troops = expedition.filter((unit) => sameGround(snapshot.map, unit, anchor));
    for (const unit of troops) handled.add(unit.id);
    const center = { x: troops.reduce((n, u) => n + u.x, 0) / troops.length, y: troops.reduce((n, u) => n + u.y, 0) / troops.length };
    const power = troops.reduce((n, u) => n + effectiveCombatRating(snapshot, u), 0);
    const localFoes = foesForCombat().filter((target2) => sameGround(snapshot.map, anchor, target2));
    const canFight = (point) => {
      const defense = localFoes.filter((target2) => distance2(target2, point) < 400).reduce((n, target2) => n + ("order" in target2 ? effectiveCombatRating(snapshot, target2) : target2.attackDamage > 0 ? TOWER_STRENGTH : 0), 0);
      return power >= defense * 1.35;
    };
    const mine = snapshot.resources.filter((mine2) => mine2.amount > 0 && eligible(mine2) && sameGround(snapshot.map, anchor, mine2) && !buildings(snapshot, owner).some((hall) => hall.kind === "townHall" && distance2(hall, mine2) < GOLD_MINE_RULES.baseRange) && localFoes.some((target2) => distance2(target2, mine2) < 400) && canFight(mine2)).sort((a, b) => distance2(center, a) - distance2(center, b))[0];
    const target = mine ?? localFoes.filter((target2) => targetAvailable(target2) && canFight(target2)).sort((a, b) => distance2(center, a) - distance2(center, b))[0];
    if (!target) continue;
    const ready = troops.filter((unit) => unit.order.type !== "cast" && unit.order.type !== "attack" && (unit.order.type !== "attackMove" || distance2(unit.order, target) > 80));
    if (ready.length) commands.push({ type: "attackMove", unitIds: ready.map((unit) => unit.id), x: target.x, y: target.y });
  }
  for (const transport of own.filter((unit) => ferryCapacity(unit) > 0 && unit.id !== outfit?.shipId && !services.reserved.has(unit.id)))
    commands.push(...ferryCommands(snapshot, owner, options, transport, plan, assault, orderCrew, transportReady));
  for (const worker of own.filter((unit) => unit.deck && !isInCabin(unit) && unit.kind === "worker" && unit.order.type === "idle")) {
    const hull = own.find((ship) => ship.id === worker.deck.shipId);
    if (hull && shipNeedsRepair(snapshot, hull) && playerState(snapshot, owner).gold > 50)
      commands.push({ type: "repairShip", unitIds: [worker.id], targetId: hull.id });
  }
  return commands;
}
function navalUnitIds(snapshot, owner, options, claimLanded) {
  const outfit = outfitting(snapshot, owner, options);
  const claimed = new Set(navalServices(snapshot, owner, options).reserved);
  for (const command of clearTransferLanes(snapshot, owner)) if ("unitIds" in command) for (const id of command.unitIds) claimed.add(id);
  if (outfit) {
    if (outfit.workerId) claimed.add(outfit.workerId);
    claimed.add(outfit.shipId);
  }
  if (groundWholes(snapshot.map) <= 1 && !shipsAfloat(snapshot))
    return claimed;
  const home = buildings(snapshot, owner).find((building) => building.kind === "townHall");
  const ferries = navalMemory(options).ferries ?? {};
  for (const id of Object.keys(ferries))
    if (!snapshot.units.some((unit) => unit.id === id && unit.owner === owner))
      delete ferries[id];
  for (const unit of units(snapshot, owner)) {
    const landed = home && unitMover(unit.kind) === "land" && unit.kind !== "worker" && !sameGround(snapshot.map, unit, home);
    if (unitMover(unit.kind) === "sea" || unit.deck || unit.order.type === "board" || landed && claimLanded(unit) || Object.values(ferries).some((ferry) => ferry.crewIds.includes(unit.id)))
      claimed.add(unit.id);
  }
  return claimed;
}
function ferryCommands(snapshot, owner, options, boat, island, assault, orderCrew, ready) {
  const memory = navalMemory(options);
  const ferries = memory.ferries ??= {};
  let mission = ferries[boat.id];
  const own = units(snapshot, owner), map = snapshot.map;
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall" && building.complete);
  if (!halls.length)
    return [];
  if ((memory.ferryRetryUntil?.[boat.id] ?? 0) > snapshot.tick) return [];
  if (!mission) {
    if (!ready(boat)) return [];
    const evacuation = evacuationRoute(snapshot, owner, options, boat, halls);
    const rich = snapshot.resources.filter((mine) => mine.amount > 0 && halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange) && own.filter((unit) => !unit.deck && unit.order.type === "mine" && unit.order.resourceId === mine.id).length < GOLD_MINE_RULES.workstations);
    const dryWorkers = own.filter((unit) => !unit.deck && unit.kind === "worker" && unit.order.type === "idle" && !rich.some((mine) => sameGround(map, mine, unit)) && !(playerState(snapshot, owner).gold >= BUILDING_DEFS.townHall.cost && snapshot.resources.some((mine) => mine.amount > 0 && sameGround(map, mine, unit))));
    const relocation = dryWorkers.flatMap((worker) => rich.map((mine) => ({ worker, mine, from: coastOnWater(snapshot, worker, boat), to: coastOnWater(snapshot, mine, boat) }))).filter((route) => route.from && route.to && !sameGround(map, route.worker, route.mine)).sort((a, b) => distance2(a.worker, boat) - distance2(b.worker, boat))[0];
    const target2 = evacuation?.hall ?? relocation?.mine ?? island?.mine ?? assault?.target;
    if (!target2)
      return [];
    const sources = [...halls, ...own.filter((unit) => !unit.deck && unitMover(unit.kind) === "land" && unit.kind !== "worker" && unit.expiresTick === void 0)];
    const candidates = sources.filter((point) => !sameGround(map, point, target2) && coastOnWater(snapshot, point, boat));
    const readiness = (point) => own.filter((unit) => !unit.deck && sameGround(map, unit, point) && unitMover(unit.kind) === "land" && (island ? unit.kind === "worker" : unit.kind !== "worker")).reduce((n, unit) => n + bodyMass(unit), 0);
    const base = evacuation?.source ?? relocation?.worker ?? candidates.sort((a, b) => Math.min(24, readiness(b)) - Math.min(24, readiness(a)) || distance2(a, boat) + distance2(a, target2) - (distance2(b, boat) + distance2(b, target2)))[0];
    if (!base)
      return [];
    const shore = evacuation?.from ?? relocation?.from ?? coastOnWater(snapshot, base, boat);
    const landing = evacuation?.to ?? relocation?.to ?? coastOnWater(snapshot, target2, boat);
    if (!shore || !landing)
      return [];
    mission = ferries[boat.id] = { purpose: evacuation ? "evacuate" : relocation ? "rebase" : island ? "settle" : "assault", targetId: target2.id, from: shore, to: landing, phase: "loading", crewIds: [], sinceTick: snapshot.tick };
  }
  if (mission.purpose === "settle" && mission.phase === "loading" && island && mission.targetId !== island.mine.id) {
    const landing = coastOnWater(snapshot, island.mine, boat);
    if (landing) {
      mission.targetId = island.mine.id;
      mission.to = landing;
      mission.sinceTick = snapshot.tick;
      delete mission.progress;
    }
  }
  const aboardIds = shipPassengers(snapshot.units, boat).map((unit) => unit.id).join("|"), progress = mission.progress;
  if (!progress || progress.phase !== mission.phase || progress.crew !== aboardIds || distance2(boat, progress) > 32 || Math.abs(headingDifference(progress.heading, boat.sailing.heading)) * shipProfile(boat).length / 2 > 32)
    mission.progress = { tick: snapshot.tick, x: boat.x, y: boat.y, heading: boat.sailing.heading, phase: mission.phase, crew: aboardIds };
  else if (snapshot.tick - progress.tick > seconds(40)) {
    (memory.ferryRetryUntil ??= {})[boat.id] = snapshot.tick + seconds(20);
    if (mission.phase === "return" && !aboardIds) {
      delete ferries[boat.id];
      return [{ type: "stop", unitIds: [boat.id] }];
    }
    mission.progress = { tick: snapshot.tick, x: boat.x, y: boat.y, heading: boat.sailing.heading, phase: "return", crew: aboardIds };
    return cancelFerry(snapshot, boat, mission, options);
  }
  if (mission.phase === "return") {
    if (shipPassengers(snapshot.units, boat).some((unit) => unit.expiresTick === void 0)) return boat.order.type === "unload" && distance2(boat.order, mission.from) < 80 ? [] : [{ type: "unload", unitIds: [boat.id], ...mission.from, avoidCombat: true }];
    delete ferries[boat.id];
    return boat.order.type === "idle" ? [] : [{ type: "stop", unitIds: [boat.id] }];
  }
  if (mission.purpose === "settle") {
    const mine = snapshot.resources.find((resource) => resource.id === mission.targetId);
    const held = mine && (mineClaimedByAlly(snapshot, owner, mine, options) || snapshot.buildings.some((building) => distance2(building, mine) < 400 && isOpponentOwner(snapshot, owner, building.owner, options)));
    if (held) {
      return cancelFerry(snapshot, boat, mission, options);
    }
  }
  if (mission.purpose === "settle") {
    const mine = snapshot.resources.find((resource) => resource.id === mission.targetId);
    if (!mine || mine.amount <= 0 || !island || buildings(snapshot, owner).some((building) => building.kind === "townHall" && distance2(building, mine) < GOLD_MINE_RULES.baseRange)) {
      return cancelFerry(snapshot, boat, mission, options);
    }
  }
  const target = mission.purpose === "assault" || mission.purpose === "evacuate" ? snapshot.buildings.find((building) => building.id === mission.targetId) : snapshot.resources.find((resource) => resource.id === mission.targetId);
  if (!target) {
    return cancelFerry(snapshot, boat, mission, options);
  }
  const commands = [];
  if (mission.phase === "sailing") {
    if (outgunned(snapshot, owner, options, boat, coveringFleet(own, boat)))
      return cancelFerry(snapshot, boat, mission, options);
    if (!shipPassengers(snapshot.units, boat).length) {
      mission.phase = "return";
      mission.crewIds = [];
      return commands;
    }
    if ((mission.purpose === "assault" || mission.purpose === "settle") && !landingSafe(snapshot, owner, options, boat, mission.purpose === "assault" ? mission.to : target)) return cancelFerry(snapshot, boat, mission, options);
    if (boat.order.type !== "unload")
      commands.push({ type: "unload", unitIds: [boat.id], ...mission.to });
    return commands;
  }
  const waiting = own.filter((unit) => unit.order.type === "board" && unit.order.transportId === boat.id);
  const loadGround = walkableGoal(map, mission.from.x, mission.from.y);
  if (distanceToHull(boat, loadGround) > UNIT_DEFS.worker.radius + BOARDING_GAP && !shipPassengers(snapshot.units, boat).length && !waiting.length) {
    if (needsMove(boat, mission.from))
      commands.push({ type: "move", unitIds: [boat.id], ...mission.from, avoidCombat: true });
    return commands;
  }
  if (mission.purpose === "settle" && shipPassengers(snapshot.units, boat).length && !shipPassengers(snapshot.units, boat).some((unit) => unit.kind === "worker") && shipPassengers(snapshot.units, boat).reduce((n, unit) => n + bodyMass(unit), 0) >= ferryCapacity(boat) - 1) {
    return [{ type: "unload", unitIds: [boat.id], ...mission.from, avoidCombat: true }];
  }
  const boarding = own.filter((unit) => unit.order.type === "board" && unit.order.transportId === boat.id);
  const cargo = shipPassengers(snapshot.units, boat);
  const attached = new Set([...cargo, ...boarding].map((unit) => unit.id));
  mission.crewIds = mission.crewIds.filter((id) => attached.has(id));
  let room = ferryCapacity(boat) - [...cargo, ...boarding].reduce((n, unit) => n + bodyMass(unit), 0);
  const workers = own.filter((unit) => !unit.deck && !attached.has(unit.id) && unit.kind === "worker" && sameGround(map, unit, loadGround) && (unit.order.type === "mine" || unit.order.type === "idle"));
  const crew = [];
  const workerCount = [...cargo, ...boarding].filter((unit) => unit.kind === "worker").length;
  const reserveMiners = snapshot.resources.some((mine) => mine.amount > 0 && sameGround(map, mine, loadGround) && halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange)) ? 3 : 0;
  if (mission.purpose === "evacuate")
    crew.push(...own.filter((unit) => !unit.deck && unit.kind === "worker" && sameGround(map, unit, loadGround) && !attached.has(unit.id) && unit.order.type !== "board").slice(0, Math.min(2, Math.floor(room / 75))));
  else if (mission.purpose === "rebase")
    crew.push(...workers.slice(0, Math.max(0, Math.floor(room / 75))));
  else if (mission.purpose === "settle" && workerCount < 2 && workers.length > reserveMiners)
    crew.push(...workers.slice(0, Math.min(2 - workerCount, workers.length - reserveMiners, Math.floor(room / 75))));
  else if (mission.purpose === "assault" && !workerCount && workers.length >= 6 && room > 0)
    crew.push(workers[0]);
  room -= crew.reduce((mass, unit) => mass + bodyMass(unit), 0);
  if (mission.purpose === "settle")
    room -= 75 * Math.max(0, 2 - workerCount - crew.filter((unit) => unit.kind === "worker").length);
  const soldiers = orderCrew(own.filter((unit) => !unit.deck && unit.kind !== "worker" && unitMover(unit.kind) === "land" && !unit.expiresTick && !attached.has(unit.id) && sameGround(map, unit, loadGround) && unit.order.type !== "board" && unit.order.type !== "cast"), loadGround, boat);
  const engineersAboard = cargo.filter((unit) => unit.kind === "worker").length;
  const engineersReady = mission.purpose !== "settle" || engineersAboard >= 2 || engineersAboard >= 1 && (workerCount < 2 || snapshot.tick - mission.progress.tick > seconds(20));
  const threats = snapshot.units.filter((unit) => isOpponentOwner(snapshot, owner, unit.owner, options) && sameGround(map, unit, loadGround) && combatCapability(snapshot, unit).armed);
  let strengthLeft = strengthOf(soldiers);
  for (const soldier of mission.purpose === "rebase" || !engineersReady ? [] : soldiers) {
    if (bodyMass(soldier) > room || mission.purpose !== "evacuate" && strengthLeft - unitStrengthForFerry(soldier) < strengthOf(threats) * 1.3)
      continue;
    crew.push(soldier);
    room -= bodyMass(soldier);
    strengthLeft -= unitStrengthForFerry(soldier);
  }
  if (crew.length) {
    const reserved = [...snapshot.units];
    for (const waiting2 of boarding) {
      const copy = { ...waiting2 };
      if (boardUnit(boat, copy, reserved)) reserved.push(copy);
    }
    const fitting = crew.filter((passenger) => {
      const copy = { ...passenger };
      if (!boardUnit(boat, copy, reserved)) return false;
      reserved.push(copy);
      return true;
    });
    crew.splice(0, crew.length, ...fitting);
    mission.crewIds.push(...crew.map((unit) => unit.id));
    if (crew.length) commands.push({ type: "board", unitIds: crew.map((unit) => unit.id), transportId: boat.id });
    if (boat.order.type === "move") commands.push({ type: "stop", unitIds: [boat.id] });
  }
  const hasWorkers = cargo.some((unit) => unit.kind === "worker");
  const hasSoldiers = cargo.some((unit) => unit.kind !== "worker");
  const guardsRemain = target && snapshot.units.some((unit) => unit.owner === "neutral" && distance2(unit, target) < 400);
  if (outgunned(snapshot, owner, options, mission.to, coveringFleet(own, mission.to)))
    return commands;
  if ((mission.purpose === "settle" || mission.purpose === "assault") && !landingSafe(snapshot, owner, options, boat, mission.purpose === "assault" ? mission.to : target)) {
    if (cargo.length && snapshot.tick - mission.sinceTick > seconds(120)) return cancelFerry(snapshot, boat, mission, options);
    return commands;
  }
  if (boarding.length && cargo.length && snapshot.tick - mission.progress.tick > seconds(20) && (mission.purpose !== "settle" || hasWorkers) && (mission.purpose === "rebase" || hasSoldiers || !guardsRemain)) {
    mission.phase = "sailing";
    mission.crewIds = [];
    return [{ type: "stop", unitIds: boarding.map((unit) => unit.id) }, { type: "unload", unitIds: [boat.id], ...mission.to }];
  }
  if (cargo.length && !boarding.length && !crew.length && (mission.purpose !== "settle" || hasWorkers) && (mission.purpose === "rebase" || hasSoldiers || target && !snapshot.units.some((unit) => unit.owner === "neutral" && distance2(unit, target) < 400))) {
    mission.phase = "sailing";
    mission.crewIds = [];
    commands.push({ type: "unload", unitIds: [boat.id], ...mission.to });
  }
  return commands;
}
function unitStrengthForFerry(unit) {
  return strengthOf([unit]);
}
function cancelFerry(snapshot, boat, mission, options) {
  const boarding = snapshot.units.filter((unit) => unit.order.type === "board" && unit.order.transportId === boat.id);
  mission.phase = "return";
  mission.crewIds = [];
  const memory = navalMemory(options);
  if (mission.purpose === "settle" && memory.island?.plan?.mineId === mission.targetId && !Object.entries(memory.ferries ?? {}).some(([id, other]) => id !== boat.id && other.targetId === mission.targetId && other.phase === "sailing"))
    delete memory.island;
  return [
    ...boarding.length ? [{ type: "stop", unitIds: boarding.map((unit) => unit.id) }] : [],
    ...shipPassengers(snapshot.units, boat).length ? [{ type: "unload", unitIds: [boat.id], ...mission.from, avoidCombat: true }] : []
  ];
}
function evacuationRoute(snapshot, owner, options, boat, halls) {
  if (shipPassengers(snapshot.units, boat).length) return void 0;
  const own = units(snapshot, owner).filter((unit) => unitMover(unit.kind) === "land" && !unit.expiresTick && unit.order.type !== "board");
  const enemies = snapshot.units.filter((unit) => isOpponentOwner(snapshot, owner, unit.owner, options) && combatCapability(snapshot, unit).armed && unitMover(unit.kind) === "land");
  const home = halls[0];
  for (const source of own.filter((unit) => !sameGround(snapshot.map, unit, home))) {
    const local2 = own.filter((unit) => sameGround(snapshot.map, source, unit) && distance2(source, unit) < 850);
    const threat = enemies.filter((unit) => sameGround(snapshot.map, source, unit) && distance2(source, unit) < 700);
    if (!threat.length || strengthOf(threat) < strengthOf(local2) * 1.4) continue;
    const from = coastOnWater(snapshot, source, boat);
    if (!from) continue;
    const destination = halls.filter((hall) => !sameGround(snapshot.map, hall, source) && !enemies.some((unit) => sameGround(snapshot.map, unit, hall) && distance2(unit, hall) < 700)).map((hall) => ({ hall, to: coastOnWater(snapshot, hall, boat) })).find((entry) => entry.to);
    if (destination?.to) return { source, from, hall: destination.hall, to: destination.to };
  }
  return void 0;
}
function landingSafe(snapshot, owner, options, boat, target) {
  const guards = snapshot.units.filter((unit) => combatCapability(snapshot, unit).armed && distance2(unit, target) < 400 && sameGround(snapshot.map, unit, target) && (unit.owner === "neutral" || isOpponentOwner(snapshot, owner, unit.owner, options)));
  const defenders = landingDefense(snapshot, owner, options, target);
  if (!defenders) return true;
  const landed = units(snapshot, owner).filter((unit) => unitMover(unit.kind) === "land" && sameGround(snapshot.map, unit, target) && distance2(unit, target) < 700);
  const support = units(snapshot, owner).filter((unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && guards.some((guard) => distance2(unit, guard) <= combatCapability(snapshot, unit).range + guard.radius && canReach(snapshot.map, unit, guard, snapshot.units, combatCapability(snapshot, unit).range)));
  const convoy = units(snapshot, owner).filter((unit) => ferryCapacity(unit) > 0 && sameGround(snapshot.map, unit, boat, "sea") && navalMemory(options).ferries?.[unit.id]?.targetId === navalMemory(options).ferries?.[boat.id]?.targetId);
  return [...convoy.flatMap((unit) => shipPassengers(snapshot.units, unit)), ...landed, ...support].reduce((n, unit) => n + effectiveCombatRating(snapshot, unit), 0) >= defenders * 1.4;
}
function landingDefense(snapshot, owner, options, target) {
  const guards = snapshot.units.filter((unit) => combatCapability(snapshot, unit).armed && distance2(unit, target) < 400 && sameGround(snapshot.map, unit, target) && (unit.owner === "neutral" || isOpponentOwner(snapshot, owner, unit.owner, options)));
  const towers = enemyTowers(snapshot, owner, options).filter((tower) => sameGround(snapshot.map, tower, target) && distance2(tower, target) < 600);
  return guards.reduce((n, unit) => n + effectiveCombatRating(snapshot, unit), 0) + towers.length * TOWER_STRENGTH;
}
function localExpansionAvailable(snapshot, owner, options) {
  const halls = buildings(snapshot, owner).filter((hall) => hall.kind === "townHall" && hall.complete);
  return snapshot.resources.some((mine) => mine.amount > 0 && halls.some((hall) => sameGround(snapshot.map, hall, mine)) && !halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange) && !mineClaimedByAlly(snapshot, owner, mine, options) && !snapshot.buildings.some((hall) => hall.kind === "townHall" && distance2(hall, mine) < 400 && isOpponentOwner(snapshot, owner, hall.owner, options)) && !snapshot.units.some((unit) => combatCapability(snapshot, unit).armed && distance2(unit, mine) < 400 && isOpponentOwner(snapshot, owner, unit.owner, options)) && !snapshot.units.some((unit) => unit.owner === "neutral" && sameGround(snapshot.map, unit, mine) && distance2(unit, mine) < 400));
}
function localExpansionWant(snapshot, owner, options, land) {
  const halls = buildings(snapshot, owner).filter((hall) => hall.kind === "townHall");
  if (halls.some((hall) => !hall.complete) || units(snapshot, owner).some((unit) => unit.order.type === "build")) return void 0;
  const mines = snapshot.resources.filter((mine) => mine.amount > 0 && halls.some((hall) => hall.complete && sameGround(snapshot.map, hall, mine) && (land === "all" || !sameGround(snapshot.map, hall, halls[0]))) && !halls.some((hall) => distance2(hall, mine) < GOLD_MINE_RULES.baseRange) && !mineClaimedByAlly(snapshot, owner, mine, options) && !snapshot.units.some((unit) => combatCapability(snapshot, unit).armed && distance2(unit, mine) < 400 && isEnemyOwner(snapshot, owner, unit.owner, options)) && !snapshot.buildings.some((building) => distance2(building, mine) < 400 && isOpponentOwner(snapshot, owner, building.owner, options))).sort((a, b) => Math.min(...halls.map((hall) => distance2(hall, a))) - Math.min(...halls.map((hall) => distance2(hall, b))));
  for (const mine of mines) {
    const site = hallSite(snapshot, mine), worker = site && nearestWorker(snapshot, owner, site, /* @__PURE__ */ new Set());
    if (!site || !worker || !sameGround(snapshot.map, worker, mine)) continue;
    return { id: "naval:islandHall", cost: BUILDING_DEFS.townHall.cost, issue: (used) => {
      if (used.size) return void 0;
      used.add(worker.id);
      return { type: "build", unitId: worker.id, buildingKind: "townHall", ...site };
    } };
  }
  return void 0;
}
function needsMove(unit, point) {
  return unit.order.type !== "move" || distance2(unit.order, point) > 80;
}
function coastOnWater(snapshot, ground, water) {
  const map = snapshot.map;
  const nearest = walkableGoal(map, ground.x, ground.y, "sea");
  if (sameGround(map, nearest, water, "sea"))
    return nearest;
  const shore = shoreSpots(map, BUILDING_DEFS.shipyard.radius).filter((point) => sameGround(map, point, ground) && sameGround(map, walkableGoal(map, point.x, point.y, "sea"), water, "sea")).sort((a, b) => distance2(a, ground) - distance2(b, ground))[0];
  return shore && walkableGoal(map, shore.x, shore.y, "sea");
}
function offshore(snapshot, landing, from) {
  const map = snapshot.map;
  const step = map.terrain?.cell ?? 32;
  const length = distance2(landing, from) || 1;
  for (let k = 1; k <= OFFSHORE_STEPS; k += 1) {
    const point = { x: landing.x + (landing.x - from.x) / length * step * k, y: landing.y + (landing.y - from.y) / length * step * k };
    if (isWalkable(map, point.x, point.y, "sea") && !isWalkable(map, point.x, point.y))
      return point;
  }
  return landing;
}
function coastTower(snapshot, ground, ship, workers, shore) {
  const site = towerSite(snapshot, ground, ship) ?? shoreTower(snapshot, ground, shore);
  if (!site)
    return void 0;
  return {
    id: "naval:coastTower",
    cost: BUILDING_DEFS.defenseTower.cost,
    issue: (builders) => {
      if (builders.size || workers.some((unit) => unit.order.type === "build"))
        return void 0;
      const builder = nearestByRoute(snapshot.map, workers.filter((worker) => !builders.has(worker.id)), site, "land");
      if (!builder)
        return void 0;
      builders.add(builder.id);
      return { type: "build", unitId: builder.id, buildingKind: "defenseTower", x: site.x, y: site.y };
    }
  };
}
function shoreTower(snapshot, ground, shore) {
  const at2 = legalBuildPointNear(snapshot, "defenseTower", shore);
  return sameGround(snapshot.map, at2, ground) && isBuildPlacementClear(snapshot, "defenseTower", at2) && distance2(at2, shore) <= TOWER_COVER ? at2 : void 0;
}
function towerSite(snapshot, ground, ship) {
  const length = distance2(ground, ship) || 1;
  const beyond = UNIT_DEFS.warship.attackRange + BUILDING_DEFS.defenseTower.radius;
  const midway = (beyond + TOWER_COVER) / 2;
  const at2 = legalBuildPointNear(snapshot, "defenseTower", { x: ship.x + (ground.x - ship.x) / length * midway, y: ship.y + (ground.y - ship.y) / length * midway });
  const reach = distance2(at2, ship);
  return sameGround(snapshot.map, at2, ground) && isBuildPlacementClear(snapshot, "defenseTower", at2) && reach > beyond && reach <= TOWER_COVER ? at2 : void 0;
}
function islandHallOf(snapshot, owner, plan) {
  return buildings(snapshot, owner).find((building) => building.kind === "townHall" && distance2(building, plan.mine) <= GOLD_MINE_RULES.baseRange);
}
function hallSite(snapshot, mine) {
  return miningHallSite(snapshot, mine);
}
var PLAN_RETRY = seconds(20);
function outfitting(snapshot, owner, options) {
  const memory = navalMemory(options);
  const dock = buildings(snapshot, owner).find((building) => building.kind === "shipyard" && building.complete);
  if (!dock) {
    delete memory.outfit;
    return;
  }
  const own = units(snapshot, owner);
  const dangerous = (ship) => snapshot.units.some((unit) => isEnemyOwner(snapshot, owner, unit.owner, options) && combatCapability(snapshot, unit).armed && distance2(unit, ship) < 650);
  let job = memory.outfit;
  if (job) {
    const ship = own.find((unit) => unit.id === job.shipId), worker = own.find((unit) => unit.id === job.workerId);
    const filled = ship && snapshot.items.some((item) => item.shipId === ship.id && item.mountId === job.mountId);
    if (!ship || job.workerId && !worker || dangerous(ship) || filled) {
      delete memory.outfit;
      job = void 0;
    } else {
      const progress = job.progress;
      if (!progress || distance2(ship, progress) > 16 || worker && Math.hypot(worker.x - progress.workerX, worker.y - progress.workerY) > 16 || progress.itemId !== job.itemId)
        job.progress = { tick: snapshot.tick, x: ship.x, y: ship.y, workerX: worker?.x ?? ship.x, workerY: worker?.y ?? ship.y, ...job.itemId ? { itemId: job.itemId } : {} };
      else if (snapshot.tick - progress.tick > seconds(30)) {
        delete memory.outfit;
        memory.outfitRetryUntil = snapshot.tick + seconds(20);
        return;
      }
    }
  }
  if (!job) {
    if ((memory.outfitRetryUntil ?? 0) > snapshot.tick) return;
    if (own.filter((unit) => unit.kind !== "worker" && unitMover(unit.kind) === "land").length < 6) return;
    const candidates = own.filter((ship) => shipProfile(ship) && distance2(ship, dock) < 900 && ship.hp >= ship.maxHp * 0.65 && !dangerous(ship) && !memory.ferries?.[ship.id] && installedWeapons(snapshot, ship).length < (ship.kind === "shipOfTheLine" ? 8 : ship.kind === "carrier" ? 5 : ship.kind === "warship" ? 3 : ship.kind === "transport" || ship.kind === "cutter" ? 1 : 2)).sort((a, b) => Number(["warship", "carrier", "shipOfTheLine"].includes(b.kind)) - Number(["warship", "carrier", "shipOfTheLine"].includes(a.kind)) || installedWeapons(snapshot, a).length - installedWeapons(snapshot, b).length || b.maxHp - a.maxHp);
    for (const ship of candidates) {
      const mount = shipMounts(ship).find((mount2) => !snapshot.items.some((item) => item.shipId === ship.id && item.mountId === mount2.id) && (mount2.accepts.includes("shipCannon") || mount2.accepts.includes("shipMortar")));
      if (!mount) continue;
      const kind = mount.accepts.includes("shipCannon") ? "shipCannon" : "shipMortar";
      const worker = own.filter((unit) => unit.kind === "worker" && canEquip(unit) && !unit.deck && unit.order.type !== "build" && distance2(unit, dock) < 550 && !itemsFor(snapshot, unit).length).sort((a, b) => distance2(a, dock) - distance2(b, dock))[0];
      const available = snapshot.items.some((item) => item.kind === kind && (item.shipId === ship.id && !item.mountId || worker && !item.carrierId && !item.shipId && distance2(item, dock) < 300));
      if (!available && playerState(snapshot, owner).gold < SHIP_WEAPONS[kind].cost + navalBudgetReserve(snapshot, owner, options) + OUTFIT_RESERVE) continue;
      const groundGun = worker && snapshot.items.some((item) => item.kind === kind && !item.carrierId && !item.shipId && distance2(item, dock) < 300);
      job = memory.outfit = { shipId: ship.id, ...groundGun ? { workerId: worker.id } : {}, mountId: mount.id, kind };
      break;
    }
  }
  if (job) {
    const item = snapshot.items.find((item2) => item2.id === job.itemId && (job.workerId && item2.carrierId === job.workerId || item2.shipId === job.shipId || job.workerId && !item2.carrierId && !item2.shipId)) ?? snapshot.items.find((item2) => item2.kind === job.kind && !item2.mountId && (job.workerId && item2.carrierId === job.workerId || item2.shipId === job.shipId || job.workerId && !item2.carrierId && !item2.shipId && distance2(item2, dock) < 300));
    if (item) job.itemId = item.id;
    else delete job.itemId;
    if (!item && playerState(snapshot, owner).gold < SHIP_WEAPONS[job.kind].cost + navalBudgetReserve(snapshot, owner, options) + OUTFIT_RESERVE) {
      delete memory.outfit;
      return;
    }
  }
  return job;
}
function outfitCommands(snapshot, owner, job) {
  const worker = snapshot.units.find((unit) => unit.id === job.workerId), ship = snapshot.units.find((unit) => unit.id === job.shipId);
  const dock = buildings(snapshot, owner).find((building) => building.kind === "shipyard" && building.complete);
  const commands = [];
  const item = snapshot.items.find((item2) => item2.id === job.itemId);
  if (!item) {
    if (!("placement" in purchasePlacement(snapshot, owner, dock, job.kind, ship.id)) && needsMove(ship, dock)) commands.push({ type: "move", unitIds: [ship.id], x: dock.x, y: dock.y });
    return commands;
  }
  if (!item.carrierId && !item.shipId) {
    if (worker && freeItemSlot(snapshot, worker, item.kind) && (worker.order.type !== "pickupItem" || worker.order.itemId !== item.id)) commands.push({ type: "pickupItem", unitId: worker.id, itemId: item.id });
    return commands;
  }
  const destination = { shipId: ship.id, mountId: job.mountId };
  if (item.shipId === ship.id || worker && canExchange(snapshot, worker, ship)) {
    const mount = shipMounts(ship).find((m) => m.id === job.mountId);
    const blocked = snapshot.units.filter((unit) => unit.deck?.shipId === ship.id && Math.hypot(unit.deck.x - mount.x, unit.deck.y - mount.y) < unit.radius + mount.radius + 1);
    for (const crew of blocked.filter((unit) => unit.owner === owner)) {
      const spot = deckPlacement(ship, crew, snapshot.units, { x: -shipProfile(ship).length * 0.25, y: 0 });
      if (spot) commands.push({ type: "move", unitIds: [crew.id], ...localToWorld(ship, spot) });
    }
    if (!blocked.length && !transferRefusal(snapshot, owner, item.id, destination)) commands.push({ type: "transferItem", itemId: item.id, destination });
  } else if (worker && (worker.order.type !== "board" || worker.order.transportId !== ship.id)) commands.push({ type: "board", unitIds: [worker.id], transportId: ship.id });
  return commands;
}
function navalMemory(options) {
  return options.memory.naval ??= {};
}
function islandPlan(snapshot, owner, options, eligible) {
  const map = snapshot.map;
  if (!map.terrain || groundWholes(map) <= 1)
    return void 0;
  const home = buildings(snapshot, owner).find((building) => building.kind === "townHall");
  if (!home)
    return void 0;
  if (localExpansionAvailable(snapshot, owner, options)) return void 0;
  const ownedHalls = buildings(snapshot, owner).filter((hall) => hall.kind === "townHall" && hall.complete);
  const memory = navalMemory(options);
  const settling = Object.values(memory.ferries ?? {}).some((mission) => mission.purpose === "settle" && mission.phase !== "return");
  const localGold = snapshot.resources.filter((mine) => mine.amount > 0 && ownedHalls.some((hall) => sameGround(map, hall, mine) && distance2(hall, mine) < GOLD_MINE_RULES.baseRange)).reduce((n, mine) => n + mine.amount, 0);
  if (!settling && ownedHalls.length < 2 && localGold > 1800 && playerState(snapshot, owner).supplyUsed < 20) return void 0;
  const income = units(snapshot, owner).some((unit) => unit.kind === "worker" && snapshot.resources.some((mine) => mine.amount > 0 && sameGround(map, unit, mine) && buildings(snapshot, owner).some((hall) => hall.kind === "townHall" && hall.complete && distance2(hall, mine) < GOLD_MINE_RULES.baseRange)));
  if (!income && playerState(snapshot, owner).gold < BUILDING_DEFS.townHall.cost)
    return void 0;
  let known = memory.island;
  const heldByUs = (mine) => buildings(snapshot, owner).some((building) => building.kind === "townHall" && distance2(building, mine) <= GOLD_MINE_RULES.baseRange);
  if (known?.plan) {
    const mine = snapshot.resources.find((mine2) => mine2.id === known.plan.mineId);
    if (!mine || mine.amount <= 0 || heldByUs(mine) || !eligible(mine) || mineClaimedByAlly(snapshot, owner, mine, options) || snapshot.buildings.some((building) => building.kind === "townHall" && distance2(building, mine) < 400 && isOpponentOwner(snapshot, owner, building.owner, options)))
      known = void 0;
  }
  const sailing = Object.values(memory.ferries ?? {}).some((mission) => mission.purpose === "settle" && mission.phase === "sailing");
  if (!known || !sailing && snapshot.tick - known.tick >= PLAN_RETRY) {
    const held = (mine) => snapshot.buildings.some((building) => building.kind === "townHall" && distance2(building, mine) <= 400 && isOpponentOwner(snapshot, owner, building.owner, options));
    const coasts = [];
    const candidates = snapshot.resources.filter((mine) => mine.amount > 0 && eligible(mine) && !sameGround(map, home, mine) && !held(mine) && !heldByUs(mine) && !mineClaimedByAlly(snapshot, owner, mine, options)).map((mine) => ({ mine, landing: walkableGoal(map, mine.x, mine.y, "sea") })).flatMap((entry) => {
      if (!isWalkable(map, entry.landing.x, entry.landing.y, "sea")) return [];
      let coast = coasts.find((candidate) => sameGround(map, candidate.water, entry.landing, "sea"));
      if (!coast) {
        coast = { water: entry.landing, shore: shoreSpot(snapshot, owner, entry.landing, options, true) };
        coasts.push(coast);
      }
      const shore = coast.shore;
      const departure = shore && coastOnWater(snapshot, shore, entry.landing);
      return departure ? [{ ...entry, departure }] : [];
    });
    const plan2 = chooseNavalMine(snapshot, owner, candidates, options);
    known = { tick: snapshot.tick, ...plan2 ? { plan: { mineId: plan2.mine.id, landing: { x: plan2.landing.x, y: plan2.landing.y } } } : {} };
    memory.island = known;
  }
  const plan = known.plan;
  const live = plan && snapshot.resources.find((mine) => mine.id === plan.mineId && mine.amount > 0);
  return plan && live ? { mine: live, landing: plan.landing } : void 0;
}
function assaultPlan(snapshot, owner, options) {
  const map = snapshot.map;
  if (!map.terrain || groundWholes(map) <= 1)
    return void 0;
  const home = buildings(snapshot, owner).find((building) => building.kind === "townHall");
  if (!home)
    return void 0;
  const memory = navalMemory(options);
  let known = memory.assault;
  const standing = known?.plan && snapshot.buildings.some((building) => building.id === known.plan.targetId);
  if (!known || snapshot.tick - known.tick >= PLAN_RETRY || known.plan && !standing) {
    const foes = snapshot.buildings.filter((building) => isOpponentOwner(snapshot, owner, building.owner, options));
    const ashore = new Set(foes.filter((building) => sameGround(map, home, building)).map((building) => building.owner));
    const targets = foes.filter((building) => !ashore.has(building.owner) || building.kind === "townHall" && !sameGround(map, home, building));
    let assault;
    if (targets.length > 0) {
      for (const target of targets.sort((a, b) => distance2(a, home) - distance2(b, home))) {
        const landing = walkableGoal(map, target.x, target.y, "sea");
        if (!isWalkable(map, landing.x, landing.y, "sea"))
          continue;
        if (shipyardOf(snapshot, owner, landing) || shoreSpot(snapshot, owner, landing, options, true)) {
          assault = { target, landing };
          break;
        }
      }
    }
    known = { tick: snapshot.tick, ...assault ? { plan: { targetId: assault.target.id, landing: { x: assault.landing.x, y: assault.landing.y } } } : {} };
    memory.assault = known;
  }
  const live = known.plan && snapshot.buildings.find((building) => building.id === known.plan.targetId);
  if (!known.plan || !live)
    return void 0;
  const free = lastFight(snapshot, owner, options, home) || soleOpponent(snapshot, owner, options);
  return free || readyToCross(snapshot, owner, options, home, live) ? { target: live, landing: known.plan.landing } : void 0;
}
function soleOpponent(snapshot, owner, options) {
  return new Set(snapshot.buildings.filter((building) => isOpponentOwner(snapshot, owner, building.owner, options)).map((building) => building.owner)).size <= 1;
}
function lastFight(snapshot, owner, options, home) {
  return !snapshot.buildings.some((building) => building.kind === "townHall" && isOpponentOwner(snapshot, owner, building.owner, options) && sameGround(snapshot.map, building, home));
}
function readyToCross(snapshot, owner, options, home, target) {
  if (readV6Intel(snapshot, owner, options).intrusion)
    return false;
  const map = snapshot.map;
  const soldiers = units(snapshot, owner).filter((unit) => unitMover(unit.kind) === "land" && unit.kind !== "worker" && sameGround(map, unit, home));
  const defenders = snapshot.units.filter((unit) => unitMover(unit.kind) === "land" && unit.kind !== "worker" && isOpponentOwner(snapshot, owner, unit.owner, options) && sameGround(map, unit, target));
  const towers = snapshot.buildings.filter((building) => building.kind === "defenseTower" && building.complete && isOpponentOwner(snapshot, owner, building.owner, options) && sameGround(map, building, target)).length;
  return strengthOf(soldiers) >= (strengthOf(defenders) + towers * TOWER_STRENGTH) * attackMargin(options);
}
function raidPlan(snapshot, owner, options) {
  const map = snapshot.map;
  if (!map.terrain || shoreSpots(map, BUILDING_DEFS.shipyard.radius).length === 0)
    return void 0;
  const home = buildings(snapshot, owner).find((building) => building.kind === "townHall");
  if (!home)
    return void 0;
  const memory = navalMemory(options);
  let known = memory.raid;
  if (!known || snapshot.tick - known.tick >= PLAN_RETRY) {
    const towers = enemyTowers(snapshot, owner, options);
    const yards = buildings(snapshot, owner).filter((building) => building.kind === "shipyard");
    const doors = snapshot.buildings.filter((building) => building.kind === "townHall" && isOpponentOwner(snapshot, owner, building.owner, options) && !covered(building, towers)).map((hall) => ({ hall, water: doorstep(snapshot, hall) })).filter((door) => door.water !== void 0).map((door) => ({ ...door, served: yards.some((yard) => sameGround(map, walkableGoal(map, yard.x, yard.y, "sea"), door.water, "sea")) })).sort((a, b) => Number(b.served) - Number(a.served) || distance2(a.hall, home) - distance2(b.hall, home));
    const shoreless = [];
    let raid;
    for (const { water, served } of doors) {
      if (shoreless.some((dry) => sameGround(map, dry, water, "sea")))
        continue;
      if (!served && !shoreSpot(snapshot, owner, water, options)) {
        shoreless.push(water);
        continue;
      }
      raid = { water };
      break;
    }
    known = { tick: snapshot.tick, ...raid ? { water: { x: raid.water.x, y: raid.water.y } } : {} };
    memory.raid = known;
  }
  return known.water ? { water: known.water } : void 0;
}
function doorstep(snapshot, thing) {
  const map = snapshot.map;
  const water = walkableGoal(map, thing.x, thing.y, "sea");
  if (!isWalkable(map, water.x, water.y, "sea"))
    return void 0;
  const wall = "order" in thing ? 0 : thing.radius;
  return distance2(water, thing) - wall <= UNIT_DEFS.warship.attackRange ? water : void 0;
}
function enemyTowers(snapshot, owner, options) {
  return snapshot.buildings.filter((building) => building.kind === "defenseTower" && building.complete && isOpponentOwner(snapshot, owner, building.owner, options));
}
function covered(thing, towers, radius = 0) {
  return towers.some((tower) => distance2(tower, thing) <= TOWER_COVER + radius);
}
function shipyardOf(snapshot, owner, water) {
  return buildings(snapshot, owner).find((building) => building.kind === "shipyard" && sameGround(snapshot.map, walkableGoal(snapshot.map, building.x, building.y, "sea"), water, "sea"));
}
function shoreSpot(snapshot, owner, water, options, despiteGuns = false) {
  const map = snapshot.map;
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall");
  const home = halls[0];
  if (!home)
    return void 0;
  const ours = halls;
  const theirs = snapshot.buildings.filter((building) => building.kind === "townHall" && isOpponentOwner(snapshot, owner, building.owner, options));
  const gapOf = (spot, from) => Math.min(Infinity, ...from.map((hall) => walkingDistance(map, spot, hall) ?? Infinity));
  const guns = snapshot.units.filter((unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && isEnemyOwner(snapshot, owner, unit.owner, options));
  const towers = buildings(snapshot, owner).filter((building) => building.kind === "defenseTower" && building.complete);
  const held = guns.some((ship) => sameGround(map, ship, water, "sea"));
  const enemy = enemyTowers(snapshot, owner, options);
  const reaches = (ship, spot) => distance2(ship, spot) <= combatCapability(snapshot, ship).range + BUILDING_DEFS.shipyard.radius + GUN_MARGIN;
  let best, bestGap = Infinity;
  for (const spot of shoreSpots(map, BUILDING_DEFS.shipyard.radius)) {
    const gap = gapOf(spot, ours);
    if (gap < HALL_BERTH || gap >= bestGap || gap >= gapOf(spot, theirs) || covered(spot, enemy, BUILDING_DEFS.shipyard.radius)) continue;
    if (!despiteGuns && !(covered(spot, towers) && !guns.some((ship) => reaches(ship, spot) && !covered(ship, towers)) || !held && !guns.some((ship) => reaches(ship, spot)))) continue;
    if (!halls.some((hall) => sameGround(map, spot, hall)) || !isBuildPlacementClear(snapshot, "shipyard", spot))
      continue;
    if (sameGround(map, walkableGoal(map, spot.x, spot.y, "sea"), water, "sea")) {
      best = spot;
      bestGap = gap;
    }
  }
  return best;
}
function enemyShipsNear(snapshot, owner, options) {
  if (!shipsAfloat(snapshot))
    return [];
  const ships = snapshot.units.filter((unit) => unitMover(unit.kind) === "sea" && unit.owner !== "neutral" && isEnemyOwner(snapshot, owner, unit.owner, options));
  if (ships.length === 0)
    return ships;
  const posts = buildings(snapshot, owner).filter((building) => building.kind === "townHall" || building.kind === "shipyard");
  return ships.filter((ship) => posts.some((post) => distance2(ship, post) <= HOME_WATERS));
}
function nearestWorker(snapshot, owner, point, builders) {
  return nearestByRoute(snapshot.map, units(snapshot, owner).filter((unit) => !unit.deck && unit.kind === "worker" && (unit.order.type === "mine" || unit.order.type === "idle") && !builders.has(unit.id) && sameGround(snapshot.map, unit, point)), point, "land");
}
function nearestOf(things, from) {
  let best;
  for (const thing of things)
    if (!best || distance2(thing, from) < distance2(best, from))
      best = thing;
  return best;
}
function __shoreExperimentOriginal(snapshot, owner, water, options, despiteGuns = false) {
  const map = snapshot.map;
  const halls = buildings(snapshot, owner).filter((building) => building.kind === "townHall");
  const home = halls[0];
  if (!home)
    return void 0;
  const ours = halls;
  const theirs = snapshot.buildings.filter((building) => building.kind === "townHall" && isOpponentOwner(snapshot, owner, building.owner, options));
  const gapOf = (spot, from) => Math.min(Infinity, ...from.map((hall) => walkingDistance(map, spot, hall) ?? Infinity));
  const guns = snapshot.units.filter((unit) => unitMover(unit.kind) === "sea" && combatCapability(snapshot, unit).armed && isEnemyOwner(snapshot, owner, unit.owner, options));
  const towers = buildings(snapshot, owner).filter((building) => building.kind === "defenseTower" && building.complete);
  const held = guns.some((ship) => sameGround(map, ship, water, "sea"));
  const enemy = enemyTowers(snapshot, owner, options);
  const reaches = (ship, spot) => distance2(ship, spot) <= combatCapability(snapshot, ship).range + BUILDING_DEFS.shipyard.radius + GUN_MARGIN;
  let best, bestGap = Infinity;
  for (const spot of shoreSpots(map, BUILDING_DEFS.shipyard.radius)) {
    const gap = gapOf(spot, ours);
    if (gap < HALL_BERTH || gap >= bestGap || gap >= gapOf(spot, theirs) || covered(spot, enemy, BUILDING_DEFS.shipyard.radius)) continue;
    if (!despiteGuns && !(covered(spot, towers) && !guns.some((ship) => reaches(ship, spot) && !covered(ship, towers)) || !held && !guns.some((ship) => reaches(ship, spot)))) continue;
    if (!halls.some((hall) => sameGround(map, spot, hall)) || !isBuildPlacementClear(snapshot, "shipyard", spot))
      continue;
    if (sameGround(map, walkableGoal(map, spot.x, spot.y, "sea"), water, "sea")) {
      best = spot;
      bestGap = gap;
    }
  }
  return best;
}
function facts(snapshot, owner, water, options) {
  const ours = buildings(snapshot, owner).filter((building) => building.kind === "townHall");
  const theirs = snapshot.buildings.filter((building) => building.kind === "townHall" && isOpponentOwner(snapshot, owner, building.owner, options));
  const spots = shoreSpots(snapshot.map, BUILDING_DEFS.shipyard.radius);
  return {
    shores: spots.length,
    landWalkableCenters: spots.filter((spot) => isWalkable(snapshot.map, spot.x, spot.y)).length,
    invalidLandCenters: spots.filter((spot) => !isWalkable(snapshot.map, spot.x, spot.y)).length,
    ours: ours.map((hall) => ({ id: hall.id, x: hall.x, y: hall.y })),
    theirs: theirs.map((hall) => ({ id: hall.id, x: hall.x, y: hall.y }))
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cancelFerry,
  coastOnWater,
  colonyNavalWant,
  colonyNavalWantWithMineEligibility,
  facts,
  navalBudgetReserve,
  navalReservePurchase,
  navalUnitIds,
  navalWant,
  original,
  planNavalEconomy,
  planNavalTactics,
  planNavalTacticsWithAssignments,
  reset,
  run,
  stats
});
